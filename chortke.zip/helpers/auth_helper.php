<?php

use Core\Session;

if (!function_exists('auth')) {
    function auth(): ?\stdClass
    {
        $userId = user_id();
        if (!$userId) return null;
        
        return app(\App\Services\User\UserService::class)->findById($userId);
    }
}

if (!function_exists('auth_user')) {
    function auth_user(): ?\stdClass
    {
        return auth();
    }
}

function user_id(): ?int
{
    $session = Session::getInstance();
    $id = $session->get('user_id');
    return $id ? (int)$id : null;
}

if (!function_exists('is_admin')) {
    function is_admin(): bool
    {
        $userId = user_id();
        if (!$userId) {
            return false;
        }

        // FIX-R2-08: نقش فقط هنگام login در session ذخیره می‌شود و updateUser
        // session را invalidate نمی‌کند؛ اتکای صرف به session یعنی demote تا پایان
        // سشن اثر نمی‌کند (به‌ویژه روی مسیرهای عمومی مثل /file/view که به is_admin()
        // تکیه‌اند). اکنون نقش از DB بازخوانی می‌شود (کش per-request برای پرهیز از
        // کوئری تکراری)؛ در خطای DB به مقدار session برمی‌گردیم (رفتار قبلی) تا
        // هیچ مسیری در نبود DB کرش نکند.
        static $perRequestCache = [];
        if (array_key_exists($userId, $perRequestCache)) {
            return $perRequestCache[$userId];
        }

        $role = null;
        try {
            $user = app(\App\Services\User\UserService::class)->findById($userId);
            $role = is_object($user) ? ($user->role ?? null) : null;
        } catch (\Throwable $e) {
            // 🔒 S7-FIX (S7-F04): خطای lookup دیگر به نقشِ کهنهٔ سشن fail-open نمی‌شود؛
            // نشستِ ادمینی که نقشش تنزل/ابطال شده، در خطای DB روی مسیرهای عمومی
            // (مثل /file/view که به is_admin() تکیه دارد) دیگر admin تلقی نمی‌شود.
            // fail-closed = هم‌قرارداد با FIX-R19-A7-3 در AuthMiddleware/AdminMiddleware.
            try {
                app(\App\Contracts\LoggerInterface::class)->warning('auth.is_admin.lookup_failed_deny', [
                    'user_id' => $userId,
                    'error'   => $e->getMessage(),
                ]);
            } catch (\Throwable $logEx) {
            }
            return false;
        }

        $isAdmin = in_array($role, ['admin', 'super_admin'], true);
        $perRequestCache[$userId] = $isAdmin;
        return $isAdmin;
    }
}

/**
 * Centralized password verification helper
 */
if (!function_exists('verify_user_password')) {
    function verify_user_password(string $password, string $hash, ?int $userId = null): bool
    {
        if ($password === '') return false;
        
        $inputPassword = base64_encode(hash('sha384', $password, true));
        
        if (password_verify($inputPassword, $hash)) {
            return true;
        }

        // Fallback for legacy passwords
        if (password_verify($password, $hash)) {
            if ($userId) {
                // Resolve UserService via Container to trigger auto-rehash
                try {
                    $userService = \Core\Application::getInstance()->container->make(\App\Services\User\UserService::class);
                    $userService->changePassword($userId, $password);
                } catch (\Throwable $e) {
                    // Silently fail if UserService cannot be resolved (e.g. during early boot)
                }
            }
            return true;
        }

        return false;
    }
}
