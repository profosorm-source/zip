<?php

/**
 * توابع کمکی ظاهر سایت و سئو
 */

if (!function_exists('site_logo')) {
    function site_logo(string $type = 'main'): ?string
    {
        $key = $type === 'main' ? 'site_logo' : 'site_logo_' . $type;
        $path = setting($key);
        return is_string($path) && $path !== '' ? url($path) : null;
    }
}

if (!function_exists('site_logo_icon')) {
    /**
     * 🛡️ X175 — نشانِ «مربعی» لوگو برای فضاهای کوچک (ناوبار، سایدبار، فوتر).
     *
     * لوگوی کامل معمولاً بنری افقی است (وردمارک + شعار) و در ارتفاع ۳۰~۴۰px
     * شعارش به نویز ناخوانا تبدیل می‌شود؛ جاهای کوچک باید «نشان» را نشان
     * دهند نه بنر کامل را (مناسب‌سازی واقعی، نه کپی‌پیست یک فایل همه‌جا).
     *
     * مشتقِ آیکون در public/assets/images/logo-icon.png نگهداری می‌شود و
     * بعد از هر آپلودِ site_logo از پنل ادمین به‌صورت خودکار از روی همان
     * فایل خام بازتولید می‌شود (SystemSettingController → deriveLogoSet).
     */
    function site_logo_icon(): ?string
    {
        static $cached = false;
        static $icon = null;
        if ($cached) {
            return $icon;
        }
        $cached = true;
        // آیکون فقط وقتی معنا دارد که لوگوی اصلی تنظیم شده باشد
        if (!setting('site_logo')) {
            return $icon = null;
        }
        $abs = dirname(__DIR__) . '/public/assets/images/logo-icon.png';
        return $icon = is_file($abs) ? url('assets/images/logo-icon.png') : null;
    }
}

if (!function_exists('site_logo_full')) {
    /**
     * 🛡️ X175 — بنر کامل لوگو با «پس‌زمینهٔ شفاف» برای زمینه‌های بزرگ
     * (صفحات ورود/ثبت‌نام، هدر ایمیل، لاگین ادمین).
     *
     * چرا نه site_logo('main') مستقیم؟ مقدار آن به «فایل خام آپلودی» اشاره
     * می‌کند که معمولاً پس‌زمینهٔ سفیدِ مات دارد؛ روی هر زمینهٔ غیرسفید
     * (فوتر تیره، هدر گرادیانی ایمیل) یک جعبهٔ سفید افتادگی می‌اندازد.
     * نسخهٔ شفاف مشتق در assets/images/logo.png نگهداری و بعد از هر آپلود
     * از پنل ادمین خودکار بازتولید می‌شود (deriveLogoSet).
     */
    function site_logo_full(): ?string
    {
        if (!setting('site_logo')) {
            return null;
        }
        $abs = dirname(__DIR__) . '/public/assets/images/logo.png';
        return is_file($abs) ? url('assets/images/logo.png') : site_logo('main');
    }
}

if (!function_exists('site_favicon')) {
    function site_favicon(string $type = 'default'): ?string
    {
        $key = $type === 'default' ? 'site_favicon' : 'site_favicon_' . $type;
        $path = setting($key);
        return is_string($path) && $path !== '' ? url($path) : null;
    }
}

if (!function_exists('site_og_image')) {
    function site_og_image(): ?string
    {
        $path = setting('site_og_image');
        return is_string($path) && $path !== '' ? url($path) : null;
    }
}

if (!function_exists('render_site_favicons')) {
    function render_site_favicons(): string
    {
        $html = '';
        if ($favicon = site_favicon()) {
            $html .= '<link rel="icon" type="image/x-icon" href="' . e($favicon) . '">' . "\n";
            $html .= '<link rel="icon" type="image/png" href="' . e($favicon) . '">' . "\n";
        }
        if ($appleFavicon = site_favicon('apple')) {
            $html .= '<link rel="apple-touch-icon" href="' . e($appleFavicon) . '">' . "\n";
        }
        return $html;
    }
}

if (!function_exists('render_site_og_tags')) {
    function render_site_og_tags(?string $title = null, ?string $description = null, ?string $customImage = null): string
    {
        $html = '';
        $ogTitle = $title ?? setting('site_name', 'وب‌سایت');
        $html .= '<meta property="og:title" content="' . e($ogTitle) . '">' . "\n";
        if ($description) $html .= '<meta property="og:description" content="' . e($description) . '">' . "\n";
        $image = $customImage ?: site_og_image();
        if ($image) $html .= '<meta property="og:image" content="' . e($image) . '">' . "\n";
        $html .= '<meta property="og:type" content="website">' . "\n";
        
        $requestUri = $_SERVER['REQUEST_URI'] ?? '/';
        $currentUrl = app(\Core\UrlGenerator::class)->to(
            is_string($requestUri) ? $requestUri : '/'
        );
        $html .= '<meta property="og:url" content="' . e($currentUrl) . '">' . "\n";
        
        $html .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
        $html .= '<meta name="twitter:title" content="' . e($ogTitle) . '">' . "\n";
        if ($description) $html .= '<meta name="twitter:description" content="' . e($description) . '">' . "\n";
        if ($image) $html .= '<meta name="twitter:image" content="' . e($image) . '">' . "\n";
        
        return $html;
    }
}
