<?php

if (!function_exists('captcha')) {
    /**
     * تولید CAPTCHA
     */
    function captcha(?string $type = null): array
    {
        $service = app(\App\Services\CaptchaService::class);
        return $service->generate($type);
    }
}

if (!function_exists('captcha_field')) {
    /**
     * فیلد CAPTCHA برای فرم
     */
    function captcha_field(?string $type = null): string
    {
        $service = app(\App\Services\CaptchaService::class);
        
        if (!$service->isEnabled()) {
            return '';
        }
        
        $captcha = $service->generate($type);
        
        ob_start();
        
        // ID یکتا برای هر فیلد کپچا در صفحه
        $captchaId = 'captcha_' . bin2hex(random_bytes(4));

        switch ($captcha['type']) {
            case 'math':
                $refreshUrl = url('captcha/refresh?type=math');
                ?>
                <div class="form-group captcha-container" id="<?= e($captchaId) ?>_wrap"
                     data-refresh-url="<?= e($refreshUrl) ?>"
                     data-type="math">
                    <div class="captcha-row captcha-row--math">
                            <label class="captcha-label" for="<?= e($captchaId) ?>_response">حل کنید:</label>
                        <!-- bdi dir=ltr: فرمول ریاضی باید همیشه چپ‌به‌راست رندر شود؛
                             در زمینه RTL الگوریتم bidi عبارت «26 - 12» را برعکس نشان می‌داد -->
                        <span id="<?= e($captchaId) ?>_question" class="captcha-question" dir="ltr">
                            <bdi dir="ltr"><?= e($captcha['question']) ?></bdi>
                        </span>
                        <button type="button"
                                data-captcha-refresh="<?= e($captchaId) ?>"
                                class="captcha-refresh-btn"
                                title="تعویض کپچا">&#x21BB;</button>
                    </div>
                    <input type="hidden" name="captcha_token" id="<?= e($captchaId )?>_token" value="<?= e($captcha['token']) ?>">
                    <input type="text" name="captcha_response" id="<?= e($captchaId) ?>_response" class="form-control" required autocomplete="off" placeholder="جواب را وارد کنید">
                </div>
                <?php
                break;

            case 'image':
                $image    = (string)($captcha['image'] ?? '');
                $filename = basename(ltrim($image, '/'));
                $imgUrl   = url('file/view/captcha/' . $filename) . '?t=' . time();
                $refreshUrl = url('captcha/refresh?type=image');
                ?>
                <div class="form-group captcha-container" id="<?= e($captchaId) ?>_wrap"
                     data-refresh-url="<?= e($refreshUrl) ?>"
                     data-type="image">
                    <label for="<?= e($captchaId) ?>_response">کد تصویر را وارد کنید:</label>
                    <div class="captcha-row captcha-row--image">
                        <img id="<?= e($captchaId) ?>_img"
                             src="<?= e($imgUrl) ?>"
                             alt="CAPTCHA"
                             class="captcha-image">
                        <button type="button"
                                data-captcha-refresh="<?= e($captchaId) ?>"
                                class="captcha-refresh-btn"
                                title="تعویض کپچا">&#x21BB;</button>
                    </div>
                    <input type="hidden" name="captcha_token" id="<?= e($captchaId )?>_token" value="<?= e($captcha['token']) ?>">
                    <input type="text" name="captcha_response" id="<?= e($captchaId) ?>_response" class="form-control" required autocomplete="off" placeholder="کد تصویر">
                </div>
                <?php
                break;
            
            case 'recaptcha_v2':
                ?>
                <div class="form-group captcha-container">
                    <div class="g-recaptcha" data-sitekey="<?= e($captcha['site_key']) ?>"></div>
                </div>
                <script nonce="<?= e(csp_nonce()) ?>" src="https://www.google.com/recaptcha/api.js" async defer></script>
                <?php
                break;
            
            case 'recaptcha_v3':
                ?>
                <input type="hidden" id="recaptcha_response" name="recaptcha_response">
                <script nonce="<?= e(csp_nonce()) ?>" src="https://www.google.com/recaptcha/api.js?render=<?= e($captcha['site_key']) ?>"></script>
                <script nonce="<?= e(csp_nonce()) ?>">
                grecaptcha.ready(function() {
                    grecaptcha.execute('<?= e($captcha['site_key']) ?>', {action: 'submit'}).then(function(token) {
                        document.getElementById('recaptcha_response').value = token;
                    });
                });
                </script>
                <?php
                break;
            
            case 'behavioral':
                // ═══ W4-C — ویجت رفتاری خودکفا ═══
                // قرارداد پارامترها (مطابق CaptchaService::verify/verifyBehavioral):
                //   captcha_token      → توکن HMAC (payload.sig)
                //   behavioral_state   → state امضاشده از /captcha/behavioral/ping
                //                        (سمت کلاینت پر می‌شود؛ خالی = fail-closed)
                //   behavioral_score   → امتیاز مشورتی کلاینت (۰..۱۰۰)
                //   events             → JSON رویدادهای خام (سقف ۵۰۰ رویداد / ۸KB)
                //   captcha_response   → مارکر ثابت «behavioral» — شاخهٔ رفتاریِ
                //                        سرویس آن را نادیده می‌گیرد؛ فقط برای
                //                        سایت‌های عمومی verify() که فیلد response
                //                        غیرخالی را پیش‌شرط می‌دانند
                //                        (ContactService::sendMessage) لازم است.
                // کالکتور (behavioral-captcha.js) با nonce لود می‌شود؛ بدون JS
                // ورودی‌ها خالی می‌مانند و سرور fail-closed رد می‌کند.
                if (!defined('CHORTKE_BEHAVIORAL_CAPTCHA_JS')) {
                    define('CHORTKE_BEHAVIORAL_CAPTCHA_JS', '1');
                    ?>
                    <script nonce="<?= e(csp_nonce()) ?>" src="<?= e(asset('assets/js/shared/behavioral-captcha.js')) ?>?v=<?= e(asset_ver()) ?>" defer></script>
                    <?php
                }
                ?>
                <div class="form-group captcha-container" data-behavioral="1"
                     data-ping-url="<?= e(url('captcha/behavioral/ping')) ?>">
                    <input type="hidden" name="captcha_token" value="<?= e($captcha['token']) ?>">
                    <input type="hidden" name="behavioral_state" value="">
                    <input type="hidden" name="behavioral_score" value="">
                    <input type="hidden" name="events" value="">
                    <input type="hidden" name="captcha_response" value="behavioral">
                    <div class="alert alert-info captcha-behavioral-alert">
                        <i class="material-icons captcha-behavioral-icon">touch_app</i>
                        <?= e($captcha['instruction']) ?>
                    </div>
                </div>
                <?php
                break;
        }
        
        return ob_get_clean();
    }
}

if (!function_exists('verify_captcha')) {
    /**
     * بررسی CAPTCHA
     */
    function verify_captcha(): bool
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            return false;
        }

        $service = app(\App\Services\CaptchaService::class);

        if (!$service->isEnabled()) {
            return true;
        }

        $token = $_POST['captcha_token'] ?? '';
        $response = $_POST['captcha_response'] ?? '';
        $recaptchaResponse = $_POST['g-recaptcha-response'] ?? $_POST['recaptcha_response'] ?? null;
        $behavioralState = $_POST['behavioral_state'] ?? '';

        $token = is_string($token) ? trim($token) : '';
        $response = is_string($response) ? trim($response) : '';
        $recaptchaResponse = is_string($recaptchaResponse) ? trim($recaptchaResponse) : null;
        $behavioralState = is_string($behavioralState) ? trim($behavioralState) : '';

        return $service->verify($token, $response, $recaptchaResponse, $behavioralState);
    }
}


if (!function_exists('captcha_refresh_script')) {
    function captcha_refresh_script(): string
    {
        $nonce = function_exists('csp_nonce') ? csp_nonce() : '';
        $nonceAttr = $nonce !== '' ? ' nonce="' . e($nonce) . '"' : '';
        return <<<JSCRIPT
<script{$nonceAttr}>
(function() {
    if (window._captchaRefreshInit) return;
    window._captchaRefreshInit = true;

    document.addEventListener('click', function(e) {
        var btn = e.target.closest('[data-captcha-refresh]');
        if (!btn) return;
        e.preventDefault();

        var id  = btn.getAttribute('data-captcha-refresh');
        var wrap = document.getElementById(id + '_wrap');
        if (!wrap) return;

        var url  = wrap.getAttribute('data-refresh-url');
        var type = wrap.getAttribute('data-type');
        if (!url) return;

        btn.style.opacity = '0.4';
        btn.disabled = true;

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (type === 'math') {
                var q = document.getElementById(id + '_question');
                if (q && data.question) {
                    // bdi داخلی را به‌روزرسانی کن تا جهت ltr حفظ شود
                    var bdi = q.querySelector('bdi') || q;
                    bdi.textContent = data.question;
                }
                var t = document.getElementById(id + '_token');
                if (t && data.token) t.value = data.token;
            } else {
                var img = document.getElementById(id + '_img');
                if (img && data.image_url) img.src = data.image_url + '?t=' + Date.now();
                var t = document.getElementById(id + '_token');
                if (t && data.token) t.value = data.token;
            }
            var inp = wrap.querySelector('input[name="captcha_response"]');
            if (inp) inp.value = '';
        })
        .catch(function() {})
        .finally(function() {
            btn.style.opacity = '1';
            btn.disabled = false;
        });
    });
})();
</script>
JSCRIPT;
    }
}
