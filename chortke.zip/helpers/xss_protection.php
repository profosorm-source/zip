<?php

/**
 * XSS Protection Helpers
 * 
 * توابع کمکی برای جلوگیری از حملات XSS
 */

if (!function_exists('xss_clean')) {
    /**
     * پاکسازی کامل از تگ‌های HTML و اسکریپت‌ها
     *
     * FIX-R36-W3 (F-A9a-05): این تابع ضدالگوی blacklist است (نگرِ «strip/جایگزینی
     * به‌جای context-escape») و الگوهای encoded/entity-شده را عبور می‌دهد.
     * امروز صفر caller دارد؛ قرارداد برای هر caller آینده:
     *  - خروجی این تابع هرگز HTML امنِ «rich» نیست؛ برای چاپِ متن ساده فقط e() کافی است.
     *  - برای محتوای rich-text از sanitizer allowlist-based واقعی استفاده شود، نه این تابع.
     * گپ‌های شناخته‌شده (بدون caller زنده، فقط ضد-تله): entity-decoding مرورگر و
     * whitespace-دسیکه‌ها — دومی اکنون بسته شد؛ اولی با htmlspecialcharsِ پایانیِ
     * double_encode خنثی می‌شود (خروجی context-escape است، نه محتوای قابل‌اعتماد).
     */
    function xss_clean(string $data): string
    {
        // حذف null bytes
        $data = str_replace(chr(0), '', $data);
        
        // حذف backslashes
        $data = str_replace("\\", "\\\\", $data);
        
        // تبدیل تگ‌های HTML خطرناک
        $data = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $data) ?? $data;
        $data = preg_replace('/<iframe\b[^>]*>(.*?)<\/iframe>/is', '', $data) ?? $data;
        $data = preg_replace('/<object\b[^>]*>(.*?)<\/object>/is', '', $data) ?? $data;
        $data = preg_replace('/<embed\b[^>]*>(.*?)<\/embed>/is', '', $data) ?? $data;
        
        // حذف event handlers
        $data = preg_replace('/on\w+\s*=\s*["\']?[^"\']*["\']?/i', '', $data) ?? $data;
        
        // حذف javascript: در لینک‌ها
        $data = preg_replace('/javascript:/i', '', $data) ?? $data;
        $data = preg_replace('/vbscript:/i', '', $data) ?? $data;
        
        // HTML special chars
        $data = htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8', true);
        
        return $data;
    }
}

// escape_js moved to helpers/security.php (single definition)
// W4-A (F-A24a-04 cleanup): escape_attr مرده با ساین-آف کارفرما حذف شد — کانونی: e().

// escape_url moved to helpers/security.php (single definition + protocol validation)


if (!function_exists('safe_html')) {
    /**
     * اجازه دادن به برخی تگ‌های امن HTML
     * برای محتواهایی که نیاز به فرمت‌بندی دارند (مثل پست‌ها، کامنت‌ها)
     *
     * FIX-R36-W3 (F-A9a-05): دو گپ بسته شد —
     *  ① entity/whitespace-دسیکه در href: قبلاً فقط فرم literal «javascript:|vbscript:|data:»
     *    پاک می‌شد؛ اکنون href قبل از سنجشِ scheme دکد و trim می‌شود و هر href با
     *    schemeِ خارج از http/https/نسبی به‌کلی حذف می‌شود (به‌جای نگه‌داشتنِ تگ با
     *    regexِ خطی که قابل دورزدن بود).
     *  ② خروجی همچنان strip_tags-based است؛ برای هر مصارف جدی rich-text، sanitizer
     *    allowlist-based اختصاصی لازم است (این تابع caller زنده ندارد — تلهٔ آینده).
     */
    function safe_html(string $data): string
    {
        // تگ‌های مجاز
        $allowed_tags = '<p><br><strong><em><u><a><ul><ol><li><blockquote><code><pre>';

        // حذف تگ‌های غیرمجاز
        $data = strip_tags($data, $allowed_tags);

        // پاکسازی attribute های خطرناک — مقدار quoted کامل مصرف می‌شود تا کوتیشن
        // بسته‌شده باقی نماند (الگوی قدیمی عیناً با مرزِ attribute-boundary تقویت شد)
        $data = preg_replace('/\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]*)/i', '', $data) ?? $data;

        // فقط href برای تگ a — مقادیر href (quoted/unquoted) را استخراج، دکد/trim و
        // سنجشِ scheme کن؛ scheme خارج از http/https ⇒ کل تگ ساده می‌شود
        if (preg_match_all('/<a\b[^>]*?\shref\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s>]*))[^>]*>/is', $data, $m, PREG_SET_ORDER)) {
            foreach ($m as $hit) {
                $href = ($hit[2] ?? '') !== '' ? $hit[2]
                    : (($hit[3] ?? '') !== '' ? $hit[3]
                    : str_value($hit[4] ?? ''));
                $href = html_entity_decode($href, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $href = preg_replace('/[\x00-\x20\x7f]+/u', '', $href) ?? $href; // دسیکهٔ فاصله/کنترل‌کاراکتر در « javascript:»
                $scheme = strtolower((string)(parse_url($href, PHP_URL_SCHEME) ?: ''));
                if ($scheme !== '' && !in_array($scheme, ['http', 'https'], true)) {
                    // href خطرناک ⇒ کل تگ a به تگِ بدون-attribute تبدیل می‌شود
                    $data = str_replace($hit[0], '<a>', $data);
                }
            }
        }

        // هر تگ a بدون href (یا با attribute های غیرمجاز باقیمانده) ساده می‌شود
        $data = preg_replace('/<a\s+(?!href)[^>]*>/i', '<a>', $data) ?? $data;

        return $data;
    }
}

if (!function_exists('is_safe_redirect')) {
    /**
     * بررسی امن بودن URL برای redirect
     *
     * FIX-R36-W3 (F-A9a-05): گپِ « javascript:…» بسته شد — مثلثِ sanitize_url:
     * کاراکترهای کنترل/whitespace پیش از سنجشِ scheme بریده می‌شوند و پس از حذفِ
     * آنها هر URL با schemeِ مخرب (javascript/data/vbscript/php/...) رد می‌شود،
     * نه فقط سه prefix literal قبلی.
     */
    function is_safe_redirect(string $url): bool
    {
        // جلوگیری از schemeهای مخرب — پس از حذف whitespace/کنترل‌کاراکترهای پیشوندی
        // (مرورگرها « javascript:» را مثل «javascript:» تفسیر می‌کنند؛ regexِ قبلی فقط
        // فرم literal را از ابتدای رشته می‌بست)
        $probe = preg_replace('/[\x00-\x20\x7f]+/u', '', $url) ?? $url;
        if (preg_match('/^(javascript|data|vbscript|php|file|blob|about):/i', $probe)) {
            return false;
        }

        // اجازه فقط به URL های نسبی یا همین دامنه
        if (strpos($url, '://') !== false) {
            $parsed = parse_url($url);
            if (!is_array($parsed) || !isset($parsed['scheme'], $parsed['host'])) {
                return false;
            }
            $port = $parsed['port'] ?? null;
            $candidateOrigin = strtolower(
                $parsed['scheme'] . '://' . $parsed['host'] . (is_int($port) ? ':' . $port : '')
            );
            if (!hash_equals(strtolower(app(\Core\UrlGenerator::class)->origin()), $candidateOrigin)) {
                return false;
            }
        }
        
        return true;
    }
}



// csp_nonce moved to helpers/security.php (single definition)

// W4-A (F-A24a-04 cleanup): validate_email_domain مرده با ساین-آف کارفرما حذف شد —
// اعتبارسنجی ایمیل زندهٔ کانونی در لایهٔ Validator است.
