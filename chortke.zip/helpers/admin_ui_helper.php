<?php

declare(strict_types=1);

/**
 * admin_ui_helper.php — رابطِ نمایشیِ مجوزِ ادمین (FIX-X94، بازآرایی ریشه‌ای FIX-X98)
 * ---------------------------------------------------------------
 * مشکل: اکشن‌های ادمین سمت سرور fail-closed محافظت می‌شوند (AdminPermissionGuard
 * + PermissionMiddleware) اما دکمه‌ها/لینک‌های UI برای همه رندر می‌شدند و کاربرِ
 * بدون مجوز با کلیک فقط 403 می‌گرفت (الگوی گزارش‌شدهٔ K-13: «+ نقش جدید» برای support).
 *
 * اصل تک-منبع-حقیقت (نسخهٔ X98 — بدون هیچ الگوریتم موازی):
 *   ① «مسیر → مجوز»: جدول زندهٔ Router (app()->router->getRoutes()) — همان جدولی که
 *      dispatch با آن تطبیق می‌دهد — و سپس AdminPermissionGuard::permissionForAction()
 *      یعنی دقیقاً همان قاعده‌ای که گارد در زمان اجرا اعمال می‌کند.
 *      (نسخهٔ قبلی فایل‌های روت را با regex می‌خواند و مجبور بود alias→FQCN را خودش حل کند؛
 *       اینک جدول زنده نام کلاس‌ها را واقعی و حل‌شده دارد — مشکل AdminRoleController از اساس حذف شد.)
 *   ② «کاربر → مجوز»: PermissionMiddleware::check (DB-authoritative).
 *   ③ unmapped → فقط سوپرادمین می‌بیند (fail-closed، هم‌راستا با گارد).
 *
 * فقط GET (ناوبری) یا اسلاگ صریح؛ برای دکمه‌های اکشن در ویوها admin_can() با
 * همان اسلاگی که روتِ هدف دارد به‌کار می‌رود.
 */

use App\Middleware\AdminPermissionGuard;
use App\Middleware\PermissionMiddleware;

/**
 * آیا کاربرِ جاریِ پنل ادمین مجوزِ صریح دارد؟ (super_admin همیشه true)
 *
 * 🛡️ FIX-S9-08 (گزارش بخش ۹): memo درخواستی — سایدبار ~۶۷ لینک دارد و
 * هر admin_can یک نمونهٔ تازه از PermissionMiddleware + isSuperAdmin query +
 * خواندنِ Redis تولید می‌کرد (ده‌ها تا صدها پرس‌وجوی تکراری در هر صفحه).
 * کلیدِ memo شامل REQUEST_TIME_FLOAT است تا هیچ‌گاه بین دو درخواستِ متوالی
 * در یک پروسه (php -S / worker) کهنه نشود — درخواستِ جدید = fingerprint جدید.
 */
function admin_can(string $permission): bool
{
    static $memo = [];
    $fp = $_SERVER['REQUEST_TIME_FLOAT'] ?? '';
    $key = $fp . '|' . $permission;
    if (array_key_exists($key, $memo)) {
        return $memo[$key];
    }
    try {
        return $memo[$key] = PermissionMiddleware::check($permission);
    } catch (\Throwable) {
        return $memo[$key] = false;
    }
}

/**
 * جدول مجوزِ مسیرهای ادمین — یک‌بار در هر ریکوئست از Router زنده استخراج می‌شود.
 * @return array{byPath: array<string,string>, patterns: array<int,array{method:string,path:string,perm:?string}>}
 */
function admin_route_perms(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $empty = ['byPath' => [], 'patterns' => []];
    try {
        $routes = app()->router->getRoutes();
    } catch (\Throwable) {
        // بوت ناقص/CLI بدون روتر → fail-closed: هیچ‌چیز نگاشت‌شده نیست
        return $cache = $empty;
    }

    $byPath   = [];
    $patterns = [];

    foreach ($routes as $verb => $list) {
        foreach ($list as $entry) {
            $route = $entry['route'] ?? null;
            if (!$route instanceof \Core\Route) continue;

            $path = rtrim((string) $route->getUri(), '/') ?: '/';
            if (!str_starts_with($path, '/admin/')) continue;

            // فقط اکشنِ [FQCN, method] قابل نگاشت است (closure → unmapped، مثل خود گارد)
            $action = $route->getAction();
            if (!is_array($action) || count($action) !== 2
                || !is_string($action[0]) || !is_string($action[1])) {
                continue;
            }

            // همان قاعدهٔ گارد: config/admin_permissions.php (کلید = نام کوتاهِ کلاسِ واقعی)
            $perm = AdminPermissionGuard::permissionForAction($action[0], $action[1]);

            if (str_contains($path, '{')) {
                $patterns[] = ['method' => $verb, 'path' => $path, 'perm' => $perm];
            } else {
                // اولین ثبت برنده است — همان سمنتیک dispatch روتر (ترتیب ثبت = ترتیب جدول)
                $key = $verb . ' ' . $path;
                if (!array_key_exists($key, $byPath)) $byPath[$key] = $perm;
            }
        }
    }

    // طولانی‌ترین الگو اول‌تر برای prefix-match
    usort($patterns, fn ($a, $b) => strlen($b['path']) <=> strlen($a['path']));

    return $cache = ['byPath' => $byPath, 'patterns' => $patterns];
}

/**
 * مجوزِ لازم برای یک مسیر ادمین — از قاعدهٔ مشترکِ AdminPermissionGuard::permissionForAction
 */
function admin_route_permission(string $path, string $method = 'GET'): ?string
{
    $perms = admin_route_perms();
    $p = rtrim(parse_url($path, PHP_URL_PATH) ?: $path, '/') ?: '/';

    if (array_key_exists($method . ' ' . $p, $perms['byPath'])) {
        return $perms['byPath'][$method . ' ' . $p];
    }
    foreach ($perms['patterns'] as $pat) {
        if ($pat['method'] !== $method) continue;
        // FIX-X94b: اول {param} را توکن کن، بعد preg_quote (وگرنه براکت‌های escaped جایگزین نمی‌شوند)
        $regex = '#^' . str_replace('__PARAM__', '[^/]+', preg_quote((string) preg_replace('#\{[^}]+\}#', '__PARAM__', $pat['path']), '#')) . '$#';
        if (preg_match($regex, $p)) {
            return $pat['perm'];
        }
    }
    return null; // unmapped → گارد برای غیرسوپر 403 می‌دهد
}

/**
 * آیا آیتم ناوبری برای کاربر جاری نمایش داده شود؟
 * (unmapped برای غیرسوپر = پنهان — fail-closed هم‌راستا با گارد)
 */
function admin_route_allowed(string $path, string $method = 'GET'): bool
{
    // 🛡️ FIX-S9-08: memo درخواستی برای مسیرها (مثل admin_can) — سایدبار/ویوها
    // همین تابع را برای هر لینک صدا می‌زنند.
    static $memo = [];
    $fp = $_SERVER['REQUEST_TIME_FLOAT'] ?? '';
    $memoKey = $fp . '|' . $method . '|' . $path;
    if (array_key_exists($memoKey, $memo)) {
        return $memo[$memoKey];
    }

    $perm = admin_route_permission($path, $method);
    if ($perm === null) {
        // unmapped → گارد برای غیرسوپر 403 می‌دهد؛ ناوبری هم فقط برای سوپر نمایش داده شود
        // FIX-X94e: فراخوانی از طریق کانتینر (متد instance است — صدا زدن استاتیک Error می‌دهد و در catch بی‌صدا false می‌شد)
        try {
            return $memo[$memoKey] = app(\App\Services\Shared\PolicyService::class)->isSuperAdminById(
                int_value(\Core\Session::getInstance()->get('user_id'))
            );
        } catch (\Throwable) {
            return $memo[$memoKey] = false;
        }
    }
    return $memo[$memoKey] = admin_can($perm);
}

/**
 * آیا حداقل یکی از مسیرهای زیرمنو برای کاربر جاری باز است؟ (برای has-sub های سایدبار)
 * @param string[] $paths
 */
function admin_nav_visible(array $paths): bool
{
    foreach ($paths as $p) {
        if (admin_route_allowed($p)) {
            return true;
        }
    }
    return false;
}
