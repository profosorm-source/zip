<?php

// ═══════════════════════════════════════════════════════════════════════════
// Label & Display Helper Functions
// ═══════════════════════════════════════════════════════════════════════════

if (!function_exists('social_status_label')) {
    function social_status_label(?string $status): string
    {
        $labels = [
            'verified' => 'تایید شده',
            'pending'  => 'در انتظار بررسی',
            'rejected' => 'رد شده',
        ];
        // FIX-R36-W3 (F-A9a-04): fallback مقدار-ناشناخته escape می‌شود (الگوی
        // FIX-S21-2/banner_type_label) — status از ورودی بیرونی می‌آید و یک ویوی
        // آینده که بدون e() چاپ کند نباید stored-XSS بگیرد. مقادیر شناخته‌شده عین قبل.
        return $labels[(string)$status] ?? e((string)$status ?: 'نامشخص');
    }
}

if (!function_exists('task_execution_status_label')) {
    function task_execution_status_label(?string $status): string
    {
        $labels = [
            'pending'   => 'در انتظار',
            'submitted' => 'ارسال شده',
            'approved'  => 'تایید شده',
            'rejected'  => 'رد شده',
            'expired'   => 'منقضی',
        ];
        return $labels[(string)$status] ?? e((string)$status ?: 'نامشخص');
    }
}

if (!function_exists('task_execution_status_badge')) {
    function task_execution_status_badge(?string $status): string
    {
        $badges = [
            'pending'   => 'badge-warning',
            'submitted' => 'badge-info',
            'approved'  => 'badge-success',
            'rejected'  => 'badge-danger',
        ];
        return $badges[(string)$status] ?? 'badge-secondary';
    }
}

if (!function_exists('social_status_badge')) {
    function social_status_badge(?string $status): string
    {
        $badges = [
            'verified' => 'badge-success',
            'pending'  => 'badge-warning',
            'rejected' => 'badge-danger',
        ];
        return $badges[(string)$status] ?? 'badge-secondary';
    }
}

if (!function_exists('task_dispute_status_label')) {
    function task_dispute_status_label(?string $status): string
    {
        $labels = [
            'pending'  => 'در انتظار بررسی',
            'resolved' => 'حل شده',
            'rejected' => 'رد شده',
            'closed'   => 'بسته شده',
        ];
        return $labels[(string)$status] ?? e((string)$status ?: 'نامشخص');
    }
}

if (!function_exists('ad_task_type_label')) {
    function ad_task_type_label(?string $type): string
    {
        $labels = [
            'custom' => 'سفارشی',
            'social' => 'شبکه اجتماعی',
            'seo'    => 'بازدید سئو',
            'banner' => 'بنری',
            'adtube' => 'ویدیو پاداش',
        ];
        return $labels[(string)$type] ?? e((string)$type ?: 'عمومی');
    }
}

/**
 * نام فارسی شبکه‌های اجتماعی
 */
if (!function_exists('social_platform_label')) {
    function social_platform_label(?string $platform): string
    {
        $platform = strtolower((string)$platform);
        // FIX-F21-02-LT (بستهٔ ۷): نقشهٔ label هاردکد حذف شد — منبع واحد
        // SocialPlatform (شامل aparat/linkedin/other برای سازگاری با ENUM ستون
        // DB و دامنهٔ تسک اجتماعی). توییتر به «توییتر (X)» یکدست شد (قبلاً این
        // helper «توییتر / X» و مدل «توییتر (X)» داشت — دریفت نمایش).
        // FIX-R36-W3 (F-A9a-04): ورودی lowercase می‌شود ولی عین همان مقدارِ خام
        // ناشناخته برنمی‌گردد — escape در مبدأ (الگوی FIX-S21-2).
        $enum = \App\Enums\SocialPlatform::tryFrom($platform);
        if ($enum !== null) {
            return $enum->label();
        }
        return e($platform ?: 'شبکه اجتماعی');
    }
}

/**
 * 🔒 FIX-KYC-ENUM (مصوب مالک: Enum مشترک KYC ادمین + کاربر): برچسب فارسی
 * وضعیت KYC — منبع واحد = KycStatus (هم‌تراز ENUM ستون kyc_verifications.status،
 * مایگریشن 2026_10_04_0001 با ۵ مقدار شامل expired).
 * هلپر = wrapper نمایشیِ نازک دور Enum: resolve امن رشتهٔ خام DB (NULL/تاریخی/
 * ناشناخته → null) و فالبکِ escape‌شده — ویویی که بدون e() چاپ کند stored-XSS
 * نمی‌گیرد (الگوی social_platform_label / FIX-R36-W3).
 */
if (!function_exists('kyc_status_label')) {
    function kyc_status_label(?string $status): string
    {
        $enum = \App\Enums\KycStatus::tryFromString($status);
        if ($enum !== null) {
            return $enum->label();
        }
        return e((string)$status ?: 'نامشخص');
    }
}

/**
 * کلاس CSS badge وضعیت KYC — همان منبع واحد (KycStatus::badge()).
 * مقدار ناشناخته → badge-secondary (خنثی، نه قرمزِ گمراه‌کننده).
 */
if (!function_exists('kyc_status_badge')) {
    function kyc_status_badge(?string $status): string
    {
        $enum = \App\Enums\KycStatus::tryFromString($status);
        return $enum !== null ? $enum->badge() : 'badge-secondary';
    }
}

/**
 * 🔒 FIX-KYC-ENUM: برچسب فارسی «پرچم KYC سطح کاربر» (users.kyc_status —
 * VARCHAR با مقدار اضافهٔ 'unverified' و ورودی‌های قدیمی 'none'؛ برخلاف
 * ستون enum جدول kyc_verifications). ۵ مقدار مشترک به KycStatus delegate
 * می‌شوند تا هرگز از منبع برچسب‌ها واگرا نشوند؛ فقط دو مقدارِ «احراز نشده»
 * این‌جا ترجمه می‌شوند. فالبک همیشه escape‌شده است.
 */
if (!function_exists('user_kyc_status_label')) {
    function user_kyc_status_label(?string $status): string
    {
        $status = strtolower((string)$status);
        if ($status === '' || in_array($status, ['none', 'unverified'], true)) {
            return 'احراز نشده';
        }
        return kyc_status_label($status);
    }
}

/**
 * کلاس CSS badge پرچم KYC سطح کاربر — هم‌تراز user_kyc_status_label.
 */
if (!function_exists('user_kyc_status_badge')) {
    function user_kyc_status_badge(?string $status): string
    {
        $status = strtolower((string)$status);
        if ($status === '' || in_array($status, ['none', 'unverified'], true)) {
            return 'badge-secondary';
        }
        return kyc_status_badge($status);
    }
}

/**
 * فرمت‌دهی زمان خروجی — جلالی با اعداد فارسی (FIX-R27-C، تک‌منبع)
 * خالی → «—»؛ عدد → تایم‌ستمپ جلالی؛ رشته → strtotime و جلالی؛
 * تجزیه‌نشدنی → همان رشتهٔ اصلی (بدون کرش).
 */
if (!function_exists('format_time')) {
    function format_time(mixed $time): string
    {
        if (!$time) return '—';
        if (is_numeric($time)) {
            return to_jalali((int)$time, 'Y/m/d H:i') ?: '—';
        }
        $ts = strtotime((string)$time);
        if ($ts === false) {
            return (string)$time;
        }
        return to_jalali($ts, 'Y/m/d H:i') ?: '—';
    }
}

/**
 * badge کلاس وضعیت اختلافات تسک
 */
if (!function_exists('task_dispute_status_badge')) {
    function task_dispute_status_badge(?string $status): string
    {
        $badges = [
            'pending'  => 'badge-warning',
            'resolved' => 'badge-success',
            'rejected' => 'badge-danger',
            'closed'   => 'badge-secondary',
        ];
        return $badges[(string)$status] ?? 'badge-info';
    }
}

/**
 * نام فارسی وضعیت اجرای SEO
 */
if (!function_exists('seo_execution_status_label')) {
    function seo_execution_status_label(string $status): string
    {
        $labels = [
            'pending'   => 'در انتظار',
            'approved'  => 'تایید شده',
            'rejected'  => 'رد شده',
            'expired'   => 'منقضی',
        ];
        // FIX-R36-W3 (F-A9a-04): fallback خام → e() (الگوی FIX-S21-2).
        return $labels[$status] ?? e($status);
    }
}

/**
 * کلاس CSS badge وضعیت اجرای SEO
 */
if (!function_exists('seo_execution_status_badge')) {
    function seo_execution_status_badge(string $status): string
    {
        $badges = [
            'pending'  => 'warning',
            'approved' => 'success',
            'rejected' => 'danger',
            'expired'  => 'secondary',
        ];
        return $badges[$status] ?? 'secondary';
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Map helpers (برای views که به array نیاز دارند)
// ═══════════════════════════════════════════════════════════════════════════

if (!function_exists('custom_task_status_labels_map')) {
    /**
     * FIX-STATUS-ENUM: هلپر نمایشی نازک دور CustomTaskStatus (الگوی مصوب:
     * Enum + هلپر delegate). قرارداد بستهٔ ۸ کلیدی (با مستعار تاریخی
     * review_pending) حفظ شده — ردیف‌های قدیمی هم برچسب می‌گیرند.
     */
    function custom_task_status_labels_map(): array  { return \App\Enums\CustomTaskStatus::labelsMapWithAlias(); }
}
if (!function_exists('custom_task_status_classes_map')) {
    /** FIX-STATUS-ENUM: delegate به CustomTaskStatus::badgesMapWithAlias() (منبع واحد). */
    function custom_task_status_classes_map(): array { return \App\Enums\CustomTaskStatus::badgesMapWithAlias(); }
}
if (!function_exists('custom_task_types')) {
    function custom_task_types(): array { return ['custom'=>'سفارشی','follow'=>'فالو','like'=>'لایک','comment'=>'کامنت','subscribe'=>'سابسکرایب','view'=>'بازدید','join'=>'عضویت','signup'=>'ثبت‌نام','install'=>'نصب اپلیکیشن','survey'=>'نظرسنجی','content'=>'تولید محتوا','seo'=>'سئو','social'=>'شبکه اجتماعی']; }
}
// DEADCODE-STORYORDER-HELPERS (2026-10-21، مصوب مالک): دو هلپر مردهٔ
// story_order_status_labels_map/classes_map (۵ کلیدی: pending/active/completed/
// cancelled/rejected) که هیچ مصرف‌کننده‌ای در کل درخت نداشتند حذف شدند.
// منبع واحد برچسب/کلاس StoryOrder: app/Enums/StoryOrderStatus.php از طریق
// StoryOrder::statusLabels()/statusClasses().
