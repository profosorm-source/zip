<?php

/**
 * توابع کمکی امنیتی
 *
 * W4-A (F-A24a-04 cleanup): خانوادهٔ مردهٔ escape_html/escape_js/escape_url/escape_css/
 * sanitize/is_valid_ip/get_real_ip/secure_hash/is_strong_password با ساین-آف کارفرما حذف شد.
 * کانونی‌ها: e()/sanitize_url، JSON-encode، get_client_ip، hash_hmac+secure_key، PasswordPolicy.
 */

if (!function_exists('client_ip')) {
    function client_ip(): string
    {
        return get_client_ip();
    }
}

if (!function_exists('get_user_agent')) {
    function get_user_agent(): string
    {
        return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    }
}

if (!function_exists('secure_key')) {
    function secure_key(): string
    {
        $configured = config('app.key');
        $key = is_string($configured) && $configured !== ''
            ? $configured
            : env('APP_KEY', '');
        if (!is_string($key) || strlen($key) < 32 || $key === 'default_key') {
            throw new \RuntimeException('Secure application key (APP_KEY) is not properly configured.');
        }
        return (string)$key;
    }
}

if (!function_exists('ip_in_range')) {
    function ip_in_range(string $ip, string $range): bool
    {
        if (strpos($range, '/') === false) {
            return $ip === $range;
        }
        
        list($subnet, $bits) = explode('/', $range);
        $bits = (int)$bits;
        
        // Check if it's IPv6
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $ipBin = inet_pton($ip);
            $subnetBin = inet_pton($subnet);
            if ($ipBin === false || $subnetBin === false) {
                return false;
            }
            
            $ipHex = bin2hex($ipBin);
            $subnetHex = bin2hex($subnetBin);
            
            $ipBits = '';
            $subnetBits = '';
            
            for ($i = 0; $i < 32; $i++) {
                $ipBits .= str_pad(base_convert($ipHex[$i], 16, 2), 4, '0', STR_PAD_LEFT);
                $subnetBits .= str_pad(base_convert($subnetHex[$i], 16, 2), 4, '0', STR_PAD_LEFT);
            }
            
            return substr($ipBits, 0, $bits) === substr($subnetBits, 0, $bits);
        }
        
        // Check if it's IPv4
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $ipLong = ip2long($ip);
            $subnetLong = ip2long($subnet);
            if ($ipLong === false || $subnetLong === false) {
                return false;
            }
            
            $mask = (int)(~((1 << (32 - $bits)) - 1));
            if ($bits === 0) {
                $mask = 0;
            }
            
            return ($ipLong & $mask) === ($subnetLong & $mask);
        }

        return false;
    }
}

if (!function_exists('is_trusted_proxy_peer')) {
    /**
     * FIX-M1M4 + FIX-M2M16 (گزارش‌های ماژول ۱ و ۲): سیاست واحدِ trusted-proxy —
     * تک منبع حقیقت برای همهٔ مصرف‌کننده‌های هدرهای فورواردشده (Client-IP،
     * X-Forwarded-Proto، X-Forwarded-Host، UrlGenerator origin، HttpsMiddleware،
     * front-controller). قبلاً هر مسیر policy خودش را داشت:
     *   - helpers/security.php گات opt-in مستقل TRUST_PROXY_HEADERS داشت
     *   - Request::isSecure فقط peer check با پیش‌فرض متفاوت
     *   - public/index.php رنج خصوصی هاردکد (172.* وسیع‌تر از RFC1918 172.16/12)
     *   - UrlGenerator هیچ گاتی نداشت
     *
     * قرارداد: peer مستقیم (REMOTE_ADDR) باید در app.trusted_proxies (پیش‌فرض
     * loopback) باشد؛ فهرست خالی یعنی هیچ proxy معتبر نیست (fail-closed).
     * هدرهای سمت‌کلاینت (Client-IP) گات سخت‌گیرانهٔ TRUST_PROXY_HEADERS جداگانه
     * دارند (در get_client_ip) — این تابع فقط «اعتماد به peer» را تعریف می‌کند.
     */
    function is_trusted_proxy_peer(?string $remoteAddr = null): bool
    {
        $remoteAddr = $remoteAddr ?? ($_SERVER['REMOTE_ADDR'] ?? '');
        if (!filter_var($remoteAddr, FILTER_VALIDATE_IP)) {
            return false;
        }

        /** @var array<int, string> $trustedProxies */
        $trustedProxies = (array)config('app.trusted_proxies', ['127.0.0.1']);
        if ($trustedProxies === []) {
            return false;
        }

        foreach ($trustedProxies as $proxy) {
            if (ip_in_range($remoteAddr, trim(str_value($proxy)))) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('is_allowed_origin_host')) {
    /**
     * FIX-M1M4 (گزارش ماژول ۱، M4): allowlist هاست برای origin حساس در محیط‌های
     * غیر-production (مبنای CSRF origin-check و redirect same-origin).
     * FIX-M1BR05 (سناریوی مرورگری M1-BR-05): اگر app.allowed_hosts پیکربندی نشده
     * باشد، به‌جای fail-open (پذیرش هر Host — باعث بازتاب Host مهاجم در URLهای
     * مطلق صفحه می‌شد) به مجموعهٔ امن پیش‌فرض loopback + میزبان APP_URL
     * fail-closed می‌شود؛ میزبان‌های دیگر (پیش‌نمایش/پراکسی) باید صریح در
     * APP_ALLOWED_HOSTS اعلام شوند.
     */
    function is_allowed_origin_host(string $host): bool
    {
        $host = strtolower(preg_replace('/:\d{1,5}$/', '', $host) ?? $host);
        $allowed = array_filter(array_map('trim', (array)config('app.allowed_hosts', [])));
        if ($allowed === []) {
            // FIX-M1BR05: allowlist پیکربندی‌نشده ⇒ fail-closed به مجموعهٔ امن پیش‌فرض
            // (loopback + میزبان canonical APP_URL). رفتار قبلی fail-open بود و Host
            // مهاجم در URLهای مطلق صفحه بازتاب می‌یافت (سناریوی مرورگری M1-BR-05:
            // http://evil.example.com/login در خروجی رندر شده بود). برای میزبان‌های
            // پیش‌نمایش/پراکسی غیر-loopback، APP_ALLOWED_HOSTS باید صریح تنظیم شود.
            $allowed = ['localhost', '127.0.0.1', '::1'];
            $appHost = strtolower((string)parse_url((string)config('app.url', ''), PHP_URL_HOST));
            if ($appHost !== '' && !in_array($appHost, $allowed, true)) {
                $allowed[] = $appHost;
            }
        }
        foreach ($allowed as $candidate) {
            if (strtolower(trim((string)$candidate)) === $host) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('is_acceptable_secret')) {
    /**
     * FIX-M1M18 (گزارش ماژول ۱، M18): قرارداد واحد قوت secret — فقط طول ≥۳۲
     * قبلاً ملاک بود و مقدار تکراری/حدس‌پذیر ۳۲ کاراکتری هم قبول می‌شد.
     * ① طول ≥ ۳۲؛ ② قالب hex یا base64-charset (بدون کنترل‌کده/فارسی/فاصله)؛
     * ③ حداقل تنوع کاراکتر (secret تصادفی واقعی distinct بالا دارد؛ «aaaa…»
     * و الگوهای تکراری رد می‌شوند). مقدار جاری .env با هر سه شرط سازگار است.
     */
    function is_acceptable_secret(string $secret): bool
    {
        $len = strlen($secret);
        if ($len < 32) {
            return false;
        }
        $normalized = strtolower($secret);
        if ($normalized === 'default_key' || $normalized === 'change_me' || $normalized === 'secret') {
            return false;
        }
        // قالب: hex مستقیم/uuid-like یا base64/base64url با جداکننده‌های متعارف
        $isHex = preg_match('/^[a-f0-9\-]{32,}$/i', $secret) === 1;
        $isB64 = preg_match('/^[A-Za-z0-9+\/=_\-\.]{32,}$/', $secret) === 1;
        if (!$isHex && !$isB64) {
            return false;
        }
        // حداقل تنوع کاراکتر — آستانهٔ ۱۲ ردِ الگوهای بدوی بدون شکستن secretهای واقعی
        if (count(count_chars($secret, 1)) < 12) {
            return false;
        }
        return true;
    }
}

if (!function_exists('get_client_ip')) {
    /**
     * FIX-36/F-A9b-01 (راند R36-W2-D): هدرهای فورواردشدهٔ Client-IP (CF-Connecting-IP /
     * True-Client-IP / X-Real-IP / X-Forwarded-For) فقط وقتی خوانده می‌شوند که:
     *   ① peer مستقیم (REMOTE_ADDR) در trusted_proxies باشد (گات قدیمی — حفظ شد)، «و»
     *   ② TRUST_PROXY_HEADERS=true به‌صراحت در env ست شده باشد (گات جدید — پیش‌فرض OFF).
     *
     * پیش از این فیکس، شرط ① به‌صورت ضمنی localhost/CDN بود (TRUSTED_PROXIES پیش‌فرض
     * 127.0.0.1)؛ یعنی با هر peer معتمدِ غیر-CF که هدرهای سمت‌کلاینت را overwrite
     * نمی‌کرد (nginx ساده/LB)، کلاینت می‌توانست CF-Connecting-IP/X-Real-IP خودش را
     * جعل کند → بایپس rate-limit/سیگنال تقلب (گیت IP پرداخت fail-closed است و نمی‌شکست).
     * پیش‌فرض OFF یعنی بدون opt-in صریح، منبع حقیقت همیشه REMOTE_ADDR است.
     *
     * دیپلوی CF موجود (پشت tunnel لوکال): پس از ارزیابی اینکه peerِ لبه هدرهای
     * کلاینت را strip/overwrite می‌کند، TRUST_PROXY_HEADERS=true را در env ست کنید
     * تا رفتار قبلی (خواندن زنجیرهٔ هدر با پیمایش راست‌به‌چپ) دقیقاً برگردد.
     */
    function get_client_ip(): string
    {
        $remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        $trustProxyHeaders = filter_var(
            env('TRUST_PROXY_HEADERS', config('app.trust_proxy_headers', false)),
            FILTER_VALIDATE_BOOLEAN
        );
        if (!$trustProxyHeaders) {
            return filter_var($remoteAddr, FILTER_VALIDATE_IP) ? $remoteAddr : '0.0.0.0';
        }

        $trustedProxies = (array)config('app.trusted_proxies', []);
        if (empty($trustedProxies)) {
            $trustedProxies = ['127.0.0.1', '::1'];
        }

        $isTrusted = false;
        foreach ($trustedProxies as $proxy) {
            if (ip_in_range($remoteAddr, $proxy)) {
                $isTrusted = true;
                break;
            }
        }

        if (!$isTrusted) {
            return filter_var($remoteAddr, FILTER_VALIDATE_IP) ? $remoteAddr : '0.0.0.0';
        }

        $forwardedHeaders = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_TRUE_CLIENT_IP', 
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR'
        ];
        
        foreach ($forwardedHeaders as $header) {
            if (!empty($_SERVER[$header])) {
                $ips = array_map('trim', explode(',', $_SERVER[$header]));
                
                foreach (array_reverse($ips) as $ip) {
                    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
                        continue;
                    }
                    
                    $ipTrusted = false;
                    foreach ($trustedProxies as $proxy) {
                        if (ip_in_range($ip, $proxy)) {
                            $ipTrusted = true;
                            break;
                        }
                    }
                    if (!$ipTrusted) {
                        return $ip;
                    }
                }
            }
        }
        
        return filter_var($remoteAddr, FILTER_VALIDATE_IP) ? $remoteAddr : '0.0.0.0';
    }
}

if (!function_exists('generate_device_fingerprint')) {
    function generate_device_fingerprint(): string
    {
        $ip = get_client_ip();
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        $acceptLang = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'unknown';

        // Extract stable browser family
        $browserFamily = 'unknown';
        if (preg_match('/(Chrome|Firefox|Safari|Edge|Opera)/i', $userAgent, $m)) {
            $browserFamily = $m[1];
        }

        // Mask IP for mobile subnet stability (/24 for IPv4, /48 for IPv6)
        $ipMasked = $ip;
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $parts = explode('.', $ip);
            if (count($parts) === 4) {
                $ipMasked = $parts[0] . '.' . $parts[1] . '.' . $parts[2] . '.0';
            }
        } elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $parts = explode(':', $ip);
            $ipMasked = implode(':', array_slice($parts, 0, 3)) . ':0:0:0:0:0';
        }

        // FIX-R36-W3 (F-A24a-09): session_id از ترکیب هش حذف شد (نسخهٔ v2 fingerprint) —
        // با session_id در هش، همان دستگاه در هر نشست/رفرش اثر انگشت متفاوت می‌ساخت:
        // (۱) کلید rate-limit مبتنی بر fingerprint (مثلاً SearchController) با هر
        // رفرش نشست دور زدنی می‌شد؛ (۲) device_fingerprint ثبت‌شده در
        // تراکنش‌ها/KYC بین نشست‌های یک کاربر قابل هم‌بستگی نبود. مسیر real
        // device-block/ATO از BrowserFingerprintService سمت کلاینت می‌گذرد (دامنهٔ
        // A10) و با این تغییر بی‌تأثیر است. ⚠️ سازگاری: مقادیر ذخیره‌شدهٔ قبلی با
        // نسخهٔ جدید match نمی‌شوند (انتظار‌رفته و مقصود فیکس است).
        $components = [
            $ipMasked,
            $browserFamily,
            substr($acceptLang, 0, 5),
            secure_key(), // Application key salt
        ];

        return hash('sha256', implode('|', $components));
    }
}

if (!function_exists('get_request_id')) {
    function get_request_id(bool $reset = false): string
    {
        static $requestId = null;
        if ($requestId === null || $reset) {
            // FIX-S4-PIN (هم‌راستاسازی): REQUEST_ID سمت-سرور — مقداری که bootstrap
            // (FIX-S4-7) با الگوی canonical اعتبارسنجی و TracingMiddleware پس از
            // sanitize در آن می‌نویسد — بر هدر خام کلاینت مقدم است. پیش از این
            // هدر اولویت داشت و مقدار resolve-شدهٔ middleware را دور می‌زد.
            $serverResolved = $_SERVER['REQUEST_ID'] ?? null;
            if (is_string($serverResolved)
                && $serverResolved !== ''
                && preg_match('/^[\w.\-:]{1,128}$/', $serverResolved) === 1
            ) {
                $requestId = $serverResolved;
            } elseif (isset($_SERVER['HTTP_X_REQUEST_ID']) && preg_match('/^[a-zA-Z0-9\-_]{8,64}$/', $_SERVER['HTTP_X_REQUEST_ID'])) {
                $requestId = $_SERVER['HTTP_X_REQUEST_ID'];
            } else {
                $requestId = sprintf('REQ_%s_%s', date('YmdHis'), bin2hex(random_bytes(8)));
            }
            $_SERVER['REQUEST_ID'] = $requestId;
        }
        return $requestId;
    }
}

if (!function_exists('get_trace_context')) {
    function get_trace_context(): array
    {
        // FIX-S4-1: هدرهای ردیابیِ کنترل‌شده توسط کاربر (X-Trace-Id/X-Span-Id/X-Parent-Span-Id)
        // قبلاً بدون اعتبارسنجی به context لاگ‌ها و هدرهای پاسخ جریان می‌یافتند؛ در حالی که
        // get_request_id برای X-Request-Id الگوی سخت‌گیرانه دارد. الگوی canonical این‌جا
        // هم‌راستا با ExceptionHandler::fallbackTraceId است: طول ≤۱۲۸ و فقط
        // حروف/رقم/زیرخط/نقطه/خط‌تیره/دونقطه. مقدار نامعتبر → تولید/حذف امن
        // (ضد تزریق لاگ، ضد سیل‌آب حجمی، حفظ UTF-8 معتبر برای json_encode).
        $sanitize = static function (mixed $candidate): ?string {
            if (!is_string($candidate)) {
                return null;
            }
            $candidate = trim($candidate);
            return ($candidate !== '' && preg_match('/^[\w.\-:]{1,128}$/', $candidate) === 1)
                ? $candidate
                : null;
        };

        $traceId = $sanitize($_SERVER['HTTP_X_TRACE_ID'] ?? null)
            ?? $sanitize($_SERVER['REQUEST_ID'] ?? null)
            ?? get_request_id();
        $spanId = $sanitize($_SERVER['HTTP_X_SPAN_ID'] ?? null) ?? bin2hex(random_bytes(8));
        $parentSpanId = $sanitize($_SERVER['HTTP_X_PARENT_SPAN_ID'] ?? null);

        return [
            'trace_id' => $traceId,
            'span_id' => $spanId,
            'parent_span_id' => $parentSpanId,
        ];
    }
}

if (!function_exists('trace_headers')) {
    function trace_headers(array $headers = []): array
    {
        $context = get_trace_context();
        $default = [
            'X-Request-Id: ' . ($_SERVER['REQUEST_ID'] ?? get_request_id()),
            'X-Trace-Id: ' . $context['trace_id'],
            'X-Span-Id: ' . $context['span_id'],
        ];
        if (!empty($context['parent_span_id'])) {
            $default[] = 'X-Parent-Span-Id: ' . $context['parent_span_id'];
        }

        return array_merge($default, $headers);
    }
}

if (!function_exists('sanitize_url')) {
    function sanitize_url(mixed $url): string
    {
        if (empty($url)) return '#';
        $url = trim((string)$url);

        // R33 (دفاع عمقی): کاراکتر کنترلی در URL مشروع نیست؛ مرورگرها \t/\n/\r را از
        // href حذف می‌کنند (ترفند java\tscript:) — صریح رد می‌شود.
        if (preg_match('/[\x00-\x1F\x7F]/', $url)) {
            return '#';
        }

        $parsed = parse_url($url);
        $scheme = isset($parsed['scheme']) ? strtolower($parsed['scheme']) : '';

        if (!in_array($scheme, ['http', 'https'])) {
            return '#';
        }

        return htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 🛡️ FIX-R3-F5 (P2 — R3 Ads/AdTube): اعتبارسنجی واقعی لینک یوتیوب با allowlist
// ───────────────────────────────────────────────────────────────────────────
// الگوی قبلی (فقط regex «youtube.com یا youtu.be در هر جای رشته») دامنه‌های
// مهاجم مثل https://evil.tld/?x=youtube.com را می‌پذیرفت؛ sanitize_url هم فقط
// scheme را محدود می‌کند نه host را. این دو تابع منبع واحد allowlist هستند:
//  - youtube_video_id:  استخراج شناسهٔ ۱۱ کاراکتری فقط از هاست‌های مجاز (https)
//    و مسیرهای کانونی (/watch?v=، youtu.be/<id>، /shorts، /embed، /live)
//  - youtube_watch_link_allowed: اجازهٔ «لینک خارجی» (fallback) فقط روی
//    همان هاست‌های مجاز با https — مصرف‌کننده: views/user/adtube/execute.php
// توجه: sanitize_url دست‌نخورده ماند؛ سایر مصرف‌کننده‌ها (لینک اثبات/پروفایل/…)
// URLهای دلخواهِ مشروع دارند و نباید به allowlist یوتیوب محدود شوند.
// ═══════════════════════════════════════════════════════════════════════════

if (!function_exists('youtube_allowed_hosts')) {
    /**
     * هاست‌های مجاز یوتیوب (قرارداد ردیف ۲۰۰ گزارش R3 — بدون wildcard/زیر‌دامنهٔ دلخواه).
     *
     * @return list<string>
     */
    function youtube_allowed_hosts(): array
    {
        return ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be'];
    }
}

if (!function_exists('youtube_video_id')) {
    /**
     * استخراج سخت‌گیرانهٔ شناسهٔ ویدیوی یوتیوب (۱۱ کاراکتر [A-Za-z0-9_-]).
     *
     * فقط https + هاست مجاز + الگوهای کانونی پذیرفته می‌شود؛ هر چیز دیگری
     * (دامنهٔ جعلی با «youtube.com» در query، http، زیر‌دامنهٔ ناشناس) null برمی‌گرداند.
     *
     * @return string|null شناسهٔ ۱۱ کاراکتری یا null
     */
    function youtube_video_id(mixed $url): ?string
    {
        if (!is_string($url)) {
            return null;
        }
        $url = trim($url);
        if ($url === '' || mb_strlen($url) > 2048 || preg_match('/[\x00-\x1F\x7F]/', $url)) {
            return null;
        }

        $parsed = parse_url($url);
        if (!is_array($parsed)) {
            return null;
        }

        $scheme = strtolower(str_value($parsed['scheme'] ?? ''));
        $host = strtolower(str_value($parsed['host'] ?? ''));
        if ($scheme !== 'https' || !in_array($host, youtube_allowed_hosts(), true)) {
            return null;
        }

        $path = str_value($parsed['path'] ?? '');
        $query = str_value($parsed['query'] ?? '');

        // youtu.be/<id> — کوت‌لینکر رسمی
        if ($host === 'youtu.be') {
            $candidate = ltrim($path, '/');
            return preg_match('/^[A-Za-z0-9_-]{11}$/', $candidate) === 1 ? $candidate : null;
        }

        // youtube.com/watch?v=<id> — v باید در query string باشد (نه بخشی از مسیر/other پارامترها)
        if (preg_match('/(?:^|&)v=([A-Za-z0-9_-]{11})(?:&|$)/', $query, $m) === 1) {
            return $m[1];
        }

        // youtube.com/shorts|embed|live/<id>
        if (preg_match('~^/(?:shorts|embed|live)/([A-Za-z0-9_-]{11})(?:[/?#]|$)~', $path, $m) === 1) {
            return $m[1];
        }

        return null;
    }
}

if (!function_exists('youtube_watch_link_allowed')) {
    /**
     * آیا URL فقط به‌عنوان «لینک خارجی» قابل نمایش است؟ (https + هاست مجاز —
     * بدون الزام به شناسهٔ ویدیو؛ برای fallbackِ ردیف‌های قدیمی بدون ID قابل‌استخراج)
     */
    function youtube_watch_link_allowed(mixed $url): bool
    {
        if (!is_string($url)) {
            return false;
        }
        $url = trim($url);
        if ($url === '' || mb_strlen($url) > 2048 || preg_match('/[\x00-\x1F\x7F]/', $url)) {
            return false;
        }
        $parsed = parse_url($url);
        if (!is_array($parsed)) {
            return false;
        }
        $scheme = strtolower(str_value($parsed['scheme'] ?? ''));
        $host = strtolower(str_value($parsed['host'] ?? ''));
        return $scheme === 'https' && in_array($host, youtube_allowed_hosts(), true);
    }
}

if (!function_exists('hash_password')) {
    function hash_password(string $password): string
    {
        // CRITICAL: SHA-384 pre-hash to avoid 72-byte truncation in bcrypt and increase entropy
        $preHashed = base64_encode(hash('sha384', $password, true));

        if (defined('PASSWORD_ARGON2ID')) {
            return password_hash($preHashed, PASSWORD_ARGON2ID, ['memory_cost' => 65536, 'time_cost' => 4, 'threads' => 2]);
        }
        return password_hash($preHashed, PASSWORD_BCRYPT, ['cost' => 14]);
    }
}

if (!function_exists('verify_password')) {
    function verify_password(string $password, string $hash): bool
    {
        $preHashed = base64_encode(hash('sha384', $password, true));
        
        if (password_verify($preHashed, $hash)) {
            return true;
        }

        // Fallback for legacy (non-prehashed) passwords
        return password_verify($password, $hash);
    }
}


if (!function_exists('is_mobile')) {
    function is_mobile(): bool
    {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        return (bool) preg_match('/(android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini)/i', $userAgent);
    }
}
if (!function_exists('csp_nonce')) {
    /**
     * MEDIUM-03 Fix: Helper to retrieve the CSP nonce for the current request
     */
    function csp_nonce(): string
    {
        try {
            $app = \Core\Application::getInstance();
            if (isset($app->request)) {
                return (string)$app->request->getAttribute(\App\Constants\SessionKeys::CSP_NONCE, '');
            }
        } catch (\Throwable $e) {}
        return '';
    }
}

if (!function_exists('assert_fraud_allowed')) {
    /**
     * Fraud Policy Guard — بررسی ضدتقلب قبل از عملیات مالی
     *
     * FIX-S10-2 (بچ S10 — اصلاح docblock گمراه‌کننده): خط قبلی «fail-open»
     * کهنه بود و با رفتار واقعی (H-11) می‌گفت.
     *
     * fail-CLOSED: اگر FraudGuard در دسترس نباشد عملیات رد می‌شود
     * (ریشه‌ای‌شده در H-11 — هر فراخوانندهٔ این گارد عملیات مالی/پاداش است).
     *
     * @throws \App\Exceptions\BusinessException اگه fraud blocked بشه
     */
    function assert_fraud_allowed(int $userId, string $action, array $context = []): void
    {
        try {
            $fraudGuard = app(\App\Contracts\AntiFraud\FraudGuardInterface::class);
            $risk = $fraudGuard->checkAction($userId, $action, $context);

            if (empty($risk['allowed'])) {
                throw new \App\Exceptions\BusinessException(
                    'عملیات مالی به دلیل محدودیت‌های امنیتی مجاز نیست.'
                );
            }
        } catch (\App\Exceptions\BusinessException $e) {
            throw $e;
        } catch (\Throwable $e) {
            // Root fix (H-11): every caller of this guard is a financial/reward action.
            // If the fraud engine itself is unavailable, fail CLOSED rather than
            // silently allowing the operation.
            error_log('assert_fraud_allowed unavailable, failing closed: ' . $e->getMessage());
            throw new \App\Exceptions\BusinessException(
                'سرویس بررسی امنیتی در دسترس نیست؛ عملیات مالی موقتاً مجاز نیست.'
            );
        }
    }
}

if (!function_exists('redact_sensitive_text')) {
    /**
     * FIX-M2M20 (گزارش ماژول ۲، M20): حذف اثرِ دادهٔ حساس از پیام‌های لاگ —
     * ایمیل، توالی PAN-مانند و توکن‌های طولانی (hex/base64) ماسک می‌شوند تا
     * پیام خام exception/provider/SQL بدون PII به sinkها برسد.
     */
    function redact_sensitive_text(string $text): string
    {
        $text = preg_replace('/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/', '[email]', $text) ?? $text;
        $text = preg_replace('/(?:\d[ \-]?){13,19}/', '[pan]', $text) ?? $text;
        $text = preg_replace('/[A-Za-z0-9+\/=_\-]{20,}/', '[token]', $text) ?? $text;
        return $text;
    }
}

if (!function_exists('mask_ip')) {
    /**
     * FIX-M2M20: ماسک IP برای telemetry/retention — IPv4: سه اکتت اول + ‎.0‎؛
     * IPv6: سه هکتت اول (≈/48) + ماسک؛ ورودی نامعتبر → «unknown».
     */
    function mask_ip(string $ip): string
    {
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $parts = explode('.', $ip);
            return $parts[0] . '.' . $parts[1] . '.' . $parts[2] . '.0';
        }
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $parts = explode(':', $ip);
            return implode(':', array_slice($parts, 0, 3)) . '::m';
        }
        return 'unknown';
    }
}
