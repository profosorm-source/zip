<?php

/**
 * Feature Flag Helper Functions
 * 
 * این توابع برای استفاده راحت‌تر از Feature Flags در سراسر برنامه
 */

if (!function_exists('feature_enabled')) {
    /**
     * بررسی فعال بودن یک فیچر
     * 
     * @param string $name نام فیچر
     * @param int|null $userId آیدی کاربر (اگر null باشد، کاربر فعلی استفاده می‌شود)
     * @return bool
     */
    function feature_enabled(string $name, ?int $userId = null): bool
    {
        return app(\App\Services\FeatureFlagService::class)
            ->isEnabled($name, $userId ?? user_id());
    }
}


// W4-A (F-A24a-04 cleanup): ۹ تابع مردهٔ features_enabled/any_feature_enabled/when_feature/
// unless_feature/enabled_features/feature_when_render/feature_unless_render/feature_css_class/
// feature_attribute با ساین-آف کارفرما حذف شد — feature_enabled و feature_config زنده مانده‌اند.

if (!function_exists('feature_config')) {
    /**
     * دریافت مقدار از پیکربندی فیچر (نام مستعار)
     * 
     * @param string $name نام فیچر
     * @param string $key کلید مقدار
     * @param mixed $default مقدار پیش‌فرض
     * @return mixed
     */
    function feature_config(string $name, string $key, $default = null)
    {
        return app(\App\Services\FeatureFlagService::class)->getConfig($name, $key, $default);
    }
}
