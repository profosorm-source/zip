<?php

/**
 * Global Helper Hub - چرتکه
 * 
 * این فایل شامل توابع هسته (Core) است. 
 * سایر توابع تخصصی در فایل‌های هلوپر مجزا (view, url, auth, ...) تعریف شده‌اند
 * و توسط Composer بارگذاری می‌شوند.
 */

if (!function_exists('app')) {
    /**
     * دریافت Application Instance یا حل وابستگی از Container
     *
     * @template T of object
     * @param class-string<T>|null $abstract
     * @return ($abstract is null ? \Core\Application : T)
     */
    function app(?string $abstract = null)
    {
        $instance = \Core\Application::getInstance();
        if ($abstract === null) {
            return $instance;
        }
        return $instance->container->make($abstract);
    }
}

if (!function_exists('db')) {
    /**
     * دریافت Database Instance
     */
    function db(): \Core\Database
    {
        return app(\Core\Database::class);
    }
}

if (!function_exists('cache')) {
    /**
     * دسترسی به Cache از طریق Container (CacheInterface)
     *
     * تلاش می‌کند CacheInterface را از Container resolve کند.
     * در صورت عدم موفقیت (مثلاً پیش از بوت کامل)، مستقیماً Core\Cache را برمی‌گرداند
     * که در زمان اجرا با CacheInterface سازگار است.
     */
    function cache(): \App\Contracts\CacheInterface|\Core\Cache
    {
        try {
            return app(\App\Contracts\CacheInterface::class);
        } catch (\Throwable $e) {
            // Fallback: Core\Cache تمام متدهای CacheInterface را پشتیبانی می‌کند
            return \Core\Cache::getInstance();
        }
    }
}

if (!function_exists('session')) {
    /**
     * دسترسی سریع به Session singleton
     */
    function session(): \Core\Session
    {
        return \Core\Session::getInstance();
    }
}

if (!function_exists('env')) {
    function env(string $key, mixed $default = null): mixed
    {
        global $env;

        if (!isset($env)) {
            $env = [];
        }

        // FIX-M3-04: process environment WINS over the parsed .env file.
        // Container/orchestrator-injected vars (docker-compose environment, systemd,
        // k8s) must be the single source of truth; a stale .env accidentally present
        // next to the code (e.g. bind-mounted into the image) previously shadowed
        // them (DB_HOST=127.0.0.1 / QUEUE_DRIVER=database vs compose) and broke boot
        // or split the queue across drivers. File values still apply when the key is
        // not present in the runtime environment (local XAMPP/dev behavior unchanged).
        $runtimeValue = getenv($key);
        if ($runtimeValue !== false && $runtimeValue !== '') {
            $value = $runtimeValue;
        } elseif (isset($_ENV[$key]) && $_ENV[$key] !== '') {
            $value = $_ENV[$key];
        } elseif (isset($_SERVER[$key]) && is_string($_SERVER[$key]) && $_SERVER[$key] !== '') {
            $value = $_SERVER[$key];
        } elseif (isset($env[$key])) {
            $value = $env[$key];
        } else {
            return $default;
        }

            if (is_string($value)) {
                $value = trim($value);
                // Unquote values
                if ((str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                    (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
                    $value = substr($value, 1, -1);
                }
                $value = trim($value);

                $lower = strtolower($value);
                if ($lower === 'true') return true;
                if ($lower === 'false') return false;
                if ($lower === 'null') return null;
                if (is_numeric($value)) {
                    if (str_contains($value, '.')) {
                        return (float)$value;
                    }

                    // Only cast to int when the integer representation
                    // round-trips back to the original string. This protects
                    // values that merely *look* numeric (e.g. a 32-char numeric
                    // APP_KEY, IDs with leading zeros, or numbers that overflow
                    // PHP_INT_MAX) from being silently corrupted/clamped.
                    $asInt = (int)$value;
                    if ((string)$asInt === ltrim($value, '+')) {
                        return $asInt;
                    }

                    // Numeric but not safely an int — keep it as the raw string.
                    return $value;
                }
            }

            return $value;
    }
}

if (!function_exists('config')) {
    function config(?string $key = null, mixed $default = null): mixed
    {
        global $configData, $configLoaded, $configOverrides;

        if (!is_array($configData)) {
            $configData = [];
        }

        if (!is_array($configLoaded)) {
            $configLoaded = [];
        }

        if (!is_array($configOverrides)) {
            $configOverrides = [];
        }

        $loadConfig = function(string $name) use (&$configData, &$configLoaded) {
            if (isset($configLoaded[$name])) {
                return;
            }
            $configLoaded[$name] = true;

            $file = __DIR__ . "/../config/{$name}.php";
            if (file_exists($file)) {
                // عمداً require (نه require_once): تکرارِ بارگذاری همین‌جا با
                // $configLoaded مهار می‌شود. با require_once، پس از هر
                // config_reload() فایل بار دومْ true برمی‌گرداند نه آرایه، و
                // پیکربندیِ فایلی برای همیشه از دست می‌رفت — که در
                // QueueWorker (config_reload() بعد از هر job) یعنی از دست رفتن
                // دائمی تنظیمات در worker های بلندمدت.
                $content = require $file;
                if (is_array($content)) {
                    $configData[$name] = $content;
                }
            }
        };

        $traverse = function(array $source, array $keys, bool &$found) {
            $value = $source;
            foreach ($keys as $segment) {
                if (is_array($value) && array_key_exists($segment, $value)) {
                    $value = $value[$segment];
                    continue;
                }
                $found = false;
                return null;
            }
            $found = true;
            return $value;
        };

        if ($key === null) {
            $configDir = __DIR__ . '/../config/';
            if (is_dir($configDir)) {
                foreach ((glob($configDir . '*.php') ?: []) as $file) {
                    $loadConfig(basename($file, '.php'));
                }
            }

            $merged = [];
            foreach ($configData as $name => $content) {
                if ($name === 'config') {
                    $merged = array_merge($merged, $content);
                } else {
                    $merged[$name] = $content;
                }
            }

            return array_replace_recursive($merged, $configOverrides);
        }

        $keys = explode('.', $key);
        $file = $keys[0];

        $loadConfig($file);
        $loadConfig('config');

        if (!empty($configOverrides)) {
            $found = false;
            $override = $traverse($configOverrides, $keys, $found);
            if ($found) {
                return $override;
            }
        }

        if (isset($configData[$file])) {
            $found = false;
            $value = $traverse($configData[$file], array_slice($keys, 1), $found);
            if ($found) {
                return $value;
            }
        }

        if (isset($configData['config'])) {
            $found = false;
            $value = $traverse($configData['config'], $keys, $found);
            if ($found) {
                return $value;
            }
        }

        return $default;
    }
}

if (!function_exists('normalize_secret_version')) {
    /**
     * 🛡️ FIX-SECRETROT-2: نرمال‌ساز کانونیِ نسخهٔ secret توکن API.
     *
     * پیش از این، سه نقطه (bootstrap/app.php، core/EnvValidator.php و مصرف‌کننده‌های
     * config) هرکدام نرمال‌سازی خودشان را داشتند — با این تفاوت خطرناک که
     * bootstrap/EnvValidator مقادیر «1»/«V2» را می‌پذیرفتند ولی config.php مقدار
     * خام env را همان‌طور که هست پاس می‌داد؛ نتیجه با
     * SECURITY_API_TOKEN_CURRENT_VERSION=1 (بدون «v» — دقیقاً همان مقداری که
     * .env.example قدیمی داشت!):
     *   config('security.api.secrets.1') ⇒ null (کلید فقط v1/v2 دارد)
     *   ⇒ ApiToken::create با fallback constant هش می‌سازد ولی ردیف را با
     *     secret_version='1' برچسب می‌زند — برچسبی که هیچ سیکریت‌خانه‌ای ندارد؛
     *     چنین توکنی دیگر هرگز validate نمی‌شود (lookup نسخه‌کلیددار است).
     * اکنون تنها منبع حقیقت این تابع است: «1»/«v1»/«V1»/« v1 » ⇒ 'v1'، همین‌طور v2؛
     * هر چیز دیگر ⇒ پیش‌فرض fail-safe ('v2' — همان default تاریخی config).
     *
     * @param string|null $raw    مقدار خام env (INI_SCANNER_RAW — trim نشده)
     * @param string      $default 'v1' یا 'v2'
     * @return string 'v1'|'v2'
     */
    function normalize_secret_version(?string $raw, string $default = 'v2'): string
    {
        if ($raw === null || trim($raw) === '') {
            return $default;
        }
        $trimmed = strtolower(trim($raw));
        $bare = ltrim($trimmed, 'v');
        if ($bare !== '' && ctype_digit($bare)) {
            $normalized = 'v' . $bare;
            if ($normalized === 'v1' || $normalized === 'v2') {
                return $normalized;
            }
        }
        return $default;
    }
}

if (!function_exists('config_set')) {
    function config_set(string $key, mixed $value): void
    {
        global $configOverrides;

        if (!is_array($configOverrides)) {
            $configOverrides = [];
        }

        $segments = explode('.', $key);
        $target = &$configOverrides;
        foreach ($segments as $segment) {
            if (!isset($target[$segment]) || !is_array($target[$segment])) {
                $target[$segment] = [];
            }
            $target = &$target[$segment];
        }

        $target = $value;
    }
}

if (!function_exists('config_reload')) {
    function config_reload(?string $key = null): void
    {
        global $configData, $configLoaded, $configOverrides;

        if (!is_array($configData)) {
            $configData = [];
        }
        if (!is_array($configLoaded)) {
            $configLoaded = [];
        }
        if (!is_array($configOverrides)) {
            $configOverrides = [];
        }

        if ($key === null) {
            // Reload file-backed configuration while preserving explicit runtime
            // overrides. Clearing overrides here makes long-running workers lose
            // immutable bootstrap configuration after every processed job.
            $configData = [];
            $configLoaded = [];
            return;
        }

        $segments = explode('.', $key);
        // FIX-M4-16: چند namespace «مجازی» (app, database, session, security, ...)
        // داخل config/config.php تعریف شده‌اند نه فایل مستقل؛ قبلاً unset($configData[$first])
        // برایشان عملاً no-op بود (چنین کلیدی سطح اول وجود ندارد) و caller آینده
        // مقدار کهنه می‌دید. اکنون اگر segment اول فایل backing ندارد، به فایل
        // والدِ میزبان آن namespace (config.php) نگاشت می‌شود؛ فایل‌های واقعی
        // مثل health/payment مثل قبل خودشان reload می‌شوند.
        $first = $segments[0];
        if (!array_key_exists($first, $configData)) {
            $first = 'config';
        }
        unset($configData[$first], $configLoaded[$first]);
    }
}

if (!function_exists('settings')) {
    /**
     * @return array<string, mixed>
     */
    function settings(bool $forceReload = false): array
    {
        $service = app(\App\Services\Settings\AppSettings::class);
        if ($forceReload) {
            $service->clearCache();
        }
        $settings = $service->load();
        return is_array($settings) ? $settings : [];
    }
}

if (!function_exists('base_path')) {
    /**
     * مسیر ریشه پروژه
     */
    function base_path(string $path = ''): string
    {
        return app(\Core\PathResolver::class)->base($path);
    }
}

if (!function_exists('view_path')) {
    /**
     * مسیر فایل ویو
     */
    function view_path(string $viewName): string
    {
        $viewPath = defined('VIEW_PATH') ? VIEW_PATH : base_path('views');
        return rtrim($viewPath, '/\\') . '/' . str_replace('.', '/', trim($viewName, '/')) . '.php';
    }
}


if (!function_exists('storage_path')) {
    /**
     * Get the path to the storage folder.
     */
    function storage_path(string $path = ''): string
    {
        return app(\Core\PathResolver::class)->storage($path);
    }
}

if (!function_exists('public_path')) {
    /**
     * Get the path to the public folder.
     */
    function public_path(string $path = ''): string
    {
        return app(\Core\PathResolver::class)->public($path);
    }
}

if (!function_exists('setting')) {
    /**
     * دریافت یک تنظیم خاص
     */
    function setting(string $key, mixed $default = null): mixed
    {
        $settings = settings();
        return $settings[$key] ?? $default;
    }
}

if (!function_exists('logger')) {
    /**
     * Logger Helper
     */
    function logger(): \App\Contracts\LoggerInterface
    {
        // Fail-safe: اگر لاگر اصلی از کانتینر قابل resolve نبود (مثلاً پیش از بوت کامل یا در
        // شرایط خطا)، به‌جای پرتاب استثنا و کرش اپ، از FallbackLogger استفاده می‌شود.
        try {
            return app(\App\Contracts\LoggerInterface::class);
        } catch (\Throwable $e) {
            return new \App\Support\FallbackLogger();
        }
    }
}

if (!function_exists('dd')) {
    /**
     * Dump and Die
     */
    function dd(mixed ...$vars): never
    {
        if (!config('app.debug')) {
            try {
                logger()->error('dd() called in production environment', [
                    'trace' => debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5)
                ]);
            } catch (\Throwable $e) {
                // Fallback if logger is unavailable
            }
            die('An error occurred. Please contact administrator.');
        }

        echo '<pre style="background: #1e1e1e; color: #ddd; padding: 20px; direction: ltr; text-align: left;">';
        foreach ($vars as $var) {
            var_dump($var);
        }
        echo '</pre>';
        die(1);
    }
}

// W4-A (F-A24a-04 cleanup): format_amount مرده با ساین-آف کارفرما حذف شد —
// قالب‌بندی مبالغ زنده در ویوها/سرویس‌های مالی انجام می‌شود (نکتهٔ دقت float_value-on-money).

/* -------------------------------------------------------------
 | Lazy Loading Helpers Hub
 | فایل‌های راهنما به صورت هوشمند و تنها در صورت نیاز لود می‌شوند.
 * ------------------------------------------------------------- */

if (!function_exists('csrf_token')) {
    require_once __DIR__ . '/csrf_helper.php';
}
if (!function_exists('secure_key')) {
    require_once __DIR__ . '/security.php';
}
if (!function_exists('view')) {
    require_once __DIR__ . '/view_helper.php';
}

// ✅ e() باید همیشه تعریف باشد — مستقل از view() load شدن
// در view_helper.php هم تعریف شده، اما اگر view() از جای دیگری load شده باشد
// view_helper.php skip می‌شود و e() undefined می‌ماند → Fatal Error
if (!function_exists('e')) {
    /**
     * HTML escape — محافظت از XSS در views
     * استفاده: <?= e($userInput) ?>
     */
    function e(mixed $value, int $flags = ENT_QUOTES | ENT_SUBSTITUTE, string $encoding = 'UTF-8'): string
    {
        return htmlspecialchars(
            str_value($value),
            $flags,
            $encoding
        );
    }
}
if (!function_exists('dm_display_text')) {
    /**
     * 🛡️ FIX-S45-D1 (راند ۴۵ — P2): متن پیام DM آمادهٔ نمایش.
     *
     * قرارداد دو-مرزی escape پیام خصوصی:
     *  • مرز نوشتن (DirectMessageCommandService::sendMessage طبق FIX-R36-W3):
     *    متن پیش از ذخیره/رمز HTML-encode می‌شود — برای پیام رمزشده الزامی است
     *    (encode پیش از sodium، امنیت خواننده پس از دیکریپت).
     *  • مرز خواندن (ویو): قبلاً e() مستقیم روی رشتهٔ encode‌شده اعمال می‌شد ⇒
     *    دوبار-escape («سلام &» ذخیره «سلام &amp;» → نمایش «سلام &amp;amp;»).
     *    اکنون decode دقیقاً یک‌بار اینجا و escape نهایی با e() در ویو:
     *    کاربر متن اصلی را می‌بیند و XSS حفظ می‌شود (خروجی همیشه از e() می‌گذرد؛
     *    ردیف‌های legacy خام هم امن می‌مانند چون decode آنها no-op است).
     */
    function dm_display_text(mixed $value): string
    {
        return htmlspecialchars_decode(str_value($value), ENT_QUOTES | ENT_SUBSTITUTE);
    }
}
if (!function_exists('url')) {
    require_once __DIR__ . '/url_helper.php';
}
if (!function_exists('auth')) {
    require_once __DIR__ . '/auth_helper.php';
}
if (!function_exists('today')) {
    require_once __DIR__ . '/date_helper.php';
}
if (!function_exists('json_response')) {
    require_once __DIR__ . '/response_helper.php';
}
if (!function_exists('rate_limit')) {
    require_once __DIR__ . '/rate_limit_helper.php';
}
if (!function_exists('captcha')) {
    require_once __DIR__ . '/captcha_helper.php';
}
if (!function_exists('feature_enabled')) {
    require_once __DIR__ . '/feature_flag_helpers.php';
}
if (!function_exists('site_logo')) {
    require_once __DIR__ . '/site_helper.php';
}
if (!function_exists('unread_notifications_count') || !function_exists('notify')) {
    require_once __DIR__ . '/notifications.php';
}

// Backward-compatible aliases used by legacy views/controllers after the auth
// refactor. `auth()` remains the source of truth; `user()` and `h()` prevent
// old live routes from fatally failing while those call sites are migrated.
if (!function_exists('user')) {
    function user(): ?object
    {
        return auth();
    }
}

if (!function_exists('h')) {
    function h(mixed $value): string
    {
        return e($value);
    }
}

if (!function_exists('str_value')) {
    /**
     * تبدیل امن مقدار به رشته.
     * فقط مقادیر اسکالر تبدیل می‌شوند؛ array/object/null به $default برمی‌گردند.
     * (جایگزینِ cast کورِ `(string)$mixed` در PHPStan Level 9)
     */
    function str_value(mixed $value, string $default = ''): string
    {
        return is_scalar($value) ? (string)$value : $default;
    }
}

if (!function_exists('int_value')) {
    /**
     * تبدیل امن مقدار به عدد صحیح.
     * FIX-M1M26 (گزارش ماژول ۱، M26): scientific notation (1e5/1e999) و
     * مقادیر نامتنهای رد می‌شوند — قبلاً is_numeric آن‌ها را می‌پذیرفت و
     * (int)INF به 0 یا integer حدی تبدیل می‌شد.
     */
    function int_value(mixed $value, int $default = 0): int
    {
        if (is_int($value)) {
            return $value;
        }
        if (is_float($value)) {
            return is_finite($value) ? (int)$value : $default;
        }
        if (is_string($value) && preg_match('/^[+-]?[0-9]+(?:\.[0-9]+)?$/', trim($value)) === 1) {
            $f = (float)trim($value);
            if (!is_finite($f)) {
                return $default;
            }
            return (int)$value;
        }
        return $default;
    }
}

if (!function_exists('float_value')) {
    /**
     * تبدیل امن مقدار به عدد اعشاری.
     * FIX-M1M26: scientific notation رد می‌شود؛ نتیجهٔ نامتنها (INF/-INF) → default
     */
    function float_value(mixed $value, float $default = 0.0): float
    {
        if (is_int($value)) {
            return (float)$value;
        }
        if (is_float($value)) {
            return is_finite($value) ? $value : $default;
        }
        if (is_string($value) && preg_match('/^[+-]?[0-9]+(?:\.[0-9]+)?$/', trim($value)) === 1) {
            $f = (float)trim($value);
            return is_finite($f) ? $f : $default;
        }
        return $default;
    }
}


if (!function_exists('custom_task_status_labels_map')) {
    require_once __DIR__ . '/label_helpers.php';
}
if (!function_exists('banner_type_label')) {
    require_once __DIR__ . '/banner_helpers.php';
}
if (!function_exists('xss_clean')) {
    require_once __DIR__ . '/xss_protection.php';
}
// FIX-X94: پنهان‌سازی UI ادمین بر اساس مجوز (admin_can / admin_route_allowed / admin_nav_visible)
if (!function_exists('admin_can')) {
    require_once __DIR__ . '/admin_ui_helper.php';
}
if (!class_exists('\\Helpers\\JalaliDate', false)) {
    require_once __DIR__ . '/JalaliDate.php';
}

// ═══════════════════════════════════════════════════════════════════════════
// FIX-X117: مصرف‌کنندهٔ state بوست هدیه — منبع واحد کلیدها و احکام
// ───────────────────────────────────────────────────────────────────────────
// بوست‌ها از راند ۳۱ فقط «ثبت» می‌شدند (کلید redis با TTL) و هیچ سیستمی مصرفشان
// نمی‌کرد. از این پس هر ناحیه هنگام ثبت رکورد واقعی، بوست فعال کاربر را
// «مصرف» می‌کند (تیکت → اولویت high خودکار؛ صف‌های ادمین → صدر صف + نشان).
// کلیدهای زیر منبع واحد هستند؛ AdtubeController هم از همین helpers می‌خواند.
// ═══════════════════════════════════════════════════════════════════════════

if (!function_exists('boost_areas')) {
    /**
     * ناحیه‌های مجاز بوست (۸ صفحهٔ میزبان پاپ‌آپ).
     * منبع واحد: هم اعتبارسنجی ورودی AdtubeController و هم مصرف‌کننده‌ها از این می‌خوانند.
     *
     * FIX-POP (تصمیم ۳-A مالک): ناحیهٔ 'lottery' اضافه شد — پاداش پاپ‌آپ در این ناحیه
     * «افزایش شانس قرعه‌کشی» است (مصرف‌کننده: UpdateLotteryChanceScoresJob با
     * lottery_chance_boost)؛ TTL آن در BOOST_TTL کنترلر بلندتر است تا اجرای
     * روزانهٔ ۰۳:۲۰ شانس را پوشش دهد.
     *
     * @return list<string>
     */
    function boost_areas(): array
    {
        return ['social', 'kyc', 'ticket', 'withdraw', 'dispute', 'deposit', 'vitrine', 'lottery'];
    }
}

if (!function_exists('boost_state_key')) {
    /**
     * کلید state بوست یک کاربر در یک ناحیه (ساختار: boost_popup_state:{area}:{uid}).
     */
    function boost_state_key(string $area, int $userId): string
    {
        return "boost_popup_state:{$area}:{$userId}";
    }
}

if (!function_exists('boost_state')) {
    /**
     * state خام بوست: 'accepted' | 'dismissed' | '' (ناموجود/ناحیهٔ نامعتبر).
     * ناحیهٔ نامعتبر همیشه خالی برمی‌گردد (گارد مصرف‌کننده‌ها).
     */
    function boost_state(string $area, int $userId): string
    {
        if (!in_array($area, boost_areas(), true) || $userId <= 0) {
            return '';
        }
        try {
            $state = \Core\Cache::getInstance()->get(boost_state_key($area, $userId));
        } catch (\Throwable) {
            return ''; // خرابی کش هرگز نباید جریان اصلی (ثبت تیکت/برداشت/...) را بشکند
        }

        return is_string($state) ? $state : '';
    }
}

if (!function_exists('boost_active')) {
    /**
     * آیا بوستِ کاربر در این ناحیه «فعال» است؟ (accept شده و TTL آن نمرده باشد)
     * نیم‌مصرف: بوست یک «پنجرهٔ ۲۴/۴۸ ساعته» است؛ هر رکوردی که در این پنجره ثبت
     * شود از اولویت برخوردار می‌شود (مطابق وعدهٔ پاپ‌آپ: بررسی سریع‌تر).
     */
    function boost_active(string $area, int $userId): bool
    {
        return boost_state($area, $userId) === 'accepted';
    }
}

if (!function_exists('boost_queue_order')) {
    /**
     * FIX-X117: مرتب‌سازی صف بررسی ادمین — رکوردهای «بوست‌دارِ در انتظار» صدر صف.
     *
     * قرارداد همهٔ صف‌های ادمین (برداشت/KYC/واریز دستی/اختلاف/ویتترین/تسک اجتماعی):
     *  - فقط ردیف‌های actionable (در حال انتظار بررسی) که کاربرشان بوست فعال دارد
     *    به صدر می‌پرند؛ ترتیب نسبی بقیه (FIFO) با usort پایدار PHP 8 حفظ می‌شود.
     *  - خروجی دوم فهرست user_idهای بوست‌دار برای نمایش نشان «بوست فعال» در ویو است.
     *
     * @param list<object> $rows
     * @param list<string> $actionableStatuses
     * @return array{0: list<object>, 1: list<int>}
     */
    /**
     * 🛡️ FIX-PS-C2: قرارداد همهٔ فراخوان‌ها ردیف‌های FETCH_OBJ (stdClass) است؛
     * امضای بتن به‌جای ژنریک تا PHPStan همیشه بدون ابهام حل کند.
     *
     * @param list<\stdClass> $rows
     * @return array{0: list<\stdClass>, 1: list<int>}
     */
    function boost_queue_order(array $rows, string $area, string $userIdKey, string $statusKey, array $actionableStatuses): array
    {
        $boostedUserIds = [];
        $seen = [];
        $indexed = [];
        foreach ($rows as $row) {
            $uid = is_object($row) ? int_value($row->{$userIdKey} ?? 0) : 0;
            $status = is_object($row) ? str_value($row->{$statusKey} ?? '') : '';
            $isBoostedActionable = $uid > 0
                && in_array($status, $actionableStatuses, true)
                && boost_active($area, $uid);
            if ($isBoostedActionable && !isset($seen[$uid])) {
                $seen[$uid] = true;
                $boostedUserIds[] = $uid;
            }
            $indexed[] = ['row' => $row, 'flag' => $isBoostedActionable];
        }
        if ($boostedUserIds === []) {
            return [$rows, $boostedUserIds];
        }
        // usort از PHP 8 پایدار (stable) است → ترتیب FIFO درون هر گروه حفظ می‌شود
        usort($indexed, static function (array $a, array $b): int {
            return (int) $b['flag'] <=> (int) $a['flag']; // بوست‌دارها اول؛ بقیه پایدار
        });

        return [array_map(static fn (array $item) => $item['row'], $indexed), $boostedUserIds];
    }
}

if (!function_exists('boost_active_user_ids')) {
    /**
     * FIX-X124: شناسهٔ همهٔ کاربرانی که در یک ناحیه بوستِ «فعال» (accepted + TTL زنده) دارند.
     *
     * کاربرد: صف‌هایی که مصرف بوستشان بر اساس user_id ردیف‌هاست ولی رتبه‌بندی باید
     * «قبل از صفحه‌بندی» انجام شود (مثل لیست عمومی ویترین — نردبانِ بوست در SQL
     * نه در PHPِ داخل صفحه؛ تا آگهی بوست‌دار واقعاً صدر صفحهٔ ۱ باشد نه صدرِ صفحهٔ خودش).
     *
     * پیاده‌سازی: SCAN (نه KEYS — الگوی مشابه Cache::flush؛ بدون بلاک‌شدن redis).
     * توجه: کلیدها هم accepted (TTL ۲۴/۴۸h) و هم dismissed (TTL ۷روزه) را شامل‌اند →
     * مقدار هر کلید با boost_active نهایی می‌شود. خرابی کش → [] (هرگز جریان اصلی نمی‌شکند).
     *
     * @return list<int>
     */
    function boost_active_user_ids(string $area): array
    {
        if (!in_array($area, boost_areas(), true)) {
            return [];
        }
        try {
            $cache = \Core\Cache::getInstance();
            $redis = $cache->redis();
            if ($redis === null) {
                return []; // درایور فایل: اسکن ندارد → رفتار محافظه‌کارانه (بدون بوست)
            }

            $pattern  = $cache->redisKey(boost_state_key($area, 0));
            $pattern  = substr($pattern, 0, -1) . '*'; // "...:{area}:0" → "...:{area}:*"
            $candidates = [];
            $iterator = null;
            while (false !== ($batch = $redis->scan($iterator, $pattern, 100))) {
                foreach ((array) $batch as $fullKey) {
                    if (!is_string($fullKey)) { continue; }
                    $pos = strrpos($fullKey, ':');
                    if ($pos === false) { continue; }
                    $uid = (int) substr($fullKey, $pos + 1);
                    if ($uid > 0 && !in_array($uid, $candidates, true)) {
                        $candidates[] = $uid;
                    }
                }
                if ($iterator === 0 || $iterator === '0') { break; }
            }

            // فیلتر نهایی: فقط «accepted» (کلید dismissed بوست نیست)
            return array_values(array_filter(
                $candidates,
                static fn (int $uid): bool => boost_active($area, $uid)
            ));
        } catch (\Throwable) {
            return [];
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
// FIX-R16A (Task 16-A) — country_flag helpers
// ═══════════════════════════════════════════════════════════════════════

if (!function_exists('country_flag_emoji')) {
    /**
     * ایموجی پرچم از کد ISO ۳۱۶۶-۱ آلفا-۲ (بدون asset تصویری).
     * ورودی نامعتبر / نامشخص ('XX'، NULL، خالی) ⇒ placeholder 🌐.
     *
     * منبع کد: user_sessions.country (ثبت در ورود — FIX-R16A) یا
     * users.country_code/country_flag (ثبت در ثبت‌نام + backfill مایگریشن
     * 2026_09_20_0004). DB کد ISO را منبع حقیقت نگه می‌دارد؛ این helper
     * برای نمایش، ایموجی را از کد می‌سازد.
     */
    function country_flag_emoji(mixed $code): string
    {
        if (!is_string($code)) {
            return '🌐';
        }
        $code = strtoupper(trim($code));
        if (preg_match('/^[A-Z]{2}$/', $code) !== 1 || $code === 'XX') {
            return '🌐';
        }
        $c1 = ord($code[0]) + 127397;
        $c2 = ord($code[1]) + 127397;
        return html_entity_decode("&#{$c1};&#{$c2};", ENT_HTML5, 'UTF-8');
    }
}

if (!function_exists('session_country_code')) {
    /**
     * کد کشور یک ردیف user_sessions برای نمایش (نرمال ۲-حرفی یا null).
     * عمداً بدون fallback به کشورِ ثبت‌نامِ کاربر: پرچمِ هر نشست فقط دادهٔ
     * واقعی همان نشست را نشان می‌دهد؛ نامشخص = 🌐 (نه برچسب گمراه‌کننده).
     */
    function session_country_code(?object $session): ?string
    {
        $code = $session->country ?? null;
        if (is_string($code) && preg_match('/^[A-Za-z]{2}$/', trim($code)) === 1) {
            return strtoupper(trim($code));
        }
        return null;
    }
}

if (!function_exists('oauth_flat_config')) {
    /**
     * FIX-M4BR01 (سناریوی مرورگری M4-BR-01، یافتهٔ P0): کانفیگ OAuth هرگز به
     * OAuthService/Jobs تزریق نمی‌شد — Container برای آرگومان «array $oAuthConfig = []»
     * از پیش‌فرض خالی استفاده می‌کرد و هیچ bindingای وجود نداشت؛ نتیجه: حتی با
     * GOOGLE_CLIENT_ID/SECRET کامل در env، isGoogleConfigured() همیشه false بود و
     * کل قابلیت OAuth (config/oauth.php) کانفیگ مرده بود.
     * این تابع منبع کانونی نگاشت کانفیگ نستدِ config/oauth.php به کلیدهای تختِ
     * مصرف‌کنندگان است. مصرف‌کنندگان فقط وقتی آرایهٔ تزریق‌شدهٔ صریح خالی است به
     * این نگاشت fallback می‌کنند (تزریق صریح تست‌ها حفظ می‌شود).
     *
     * @return array<string, string>
     */
    function oauth_flat_config(): array
    {
        $oauth = (array)config('oauth', []);
        $google   = (array)($oauth['google'] ?? []);
        $facebook = (array)($oauth['facebook'] ?? []);

        return [
            'google_client_id'       => str_value($google['client_id'] ?? ''),
            'google_client_secret'   => str_value($google['client_secret'] ?? ''),
            'google_redirect_uri'    => str_value($google['redirect_uri'] ?? ''),
            'facebook_client_id'     => str_value($facebook['app_id'] ?? ''),
            'facebook_client_secret' => str_value($facebook['app_secret'] ?? ''),
            'facebook_redirect_uri'  => str_value($facebook['redirect_uri'] ?? ''),
        ];
    }
}
if (!function_exists('currency_active')) {
    /**
     * FIX-R7 (تصمیم محصول — currency mode سرتاسری): ارزِ فعالِ پلتفرم.
     *
     * منبع واحد برای ارزِ رکوردهای جدید و برچسب‌های سیستمی. با تغییر
     * currency_mode به 'usdt' کل پروژه باید بدون هیچ تغییر کدی به تتر برود؛
     * رکوردهای قدیمی با ستون currency خودشان تسویه می‌شوند (سوییچ حالت است،
     * نه نرخ تبدیل — مستند در migration 2026_08_09_0001).
     *
     * این helper لایهٔ نمایش/کنترلر است و مستقیم از settings می‌خواند تا در
     * viewها بدون کانتینر هم کار کند؛ منطق کانونی در
     * CurrencyService::getActiveCurrency() است (هم‌ارزش این تابع).
     */
    function currency_active(): string
    {
        // fail-open هم‌سمان settingFlag: خطای خواندن تنظیم (مثلاً ماک سخت‌گیرانه در
        // تست‌ها یا DB قطع) ⇒ دیفالت محصول یعنی تومان — هرگز جریان اصلی را نشکن.
        try {
            $mode = strtolower(trim(str_value(setting('currency_mode', 'irt'))));
            return $mode === 'usdt' ? 'usdt' : 'irt';
        } catch (\Throwable $e) {
            return 'irt';
        }
    }
}

if (!function_exists('currency_label')) {
    /**
     * FIX-R7: برچسب فارسی ارز برای متن‌های رابط — «تومان» یا «تتر».
     * ورودی null → ارز فعال؛ 'irt'/'usdt' → برچسب همان ارز؛
     * نامعتبر → برچسب ارز فعال (هم‌الگوی CurrencyService::getCurrencyLabel).
     */
    function currency_label(?string $currency = null): string
    {
        $active = currency_active();
        $cur = $currency !== null ? strtolower(trim($currency)) : $active;
        if ($cur === 'irt') return 'تومان';
        if ($cur === 'usdt') return 'تتر';
        return $active === 'usdt' ? 'تتر' : 'تومان';
    }
}

if (!function_exists('currency_code')) {
    /**
     * FIX-R7: کد نمایشی ارز برای بَج‌ها — «IRT» یا «USDT» (null → ارز فعال).
     */
    function currency_code(?string $currency = null): string
    {
        return currency_label($currency) === 'تتر' ? 'USDT' : 'IRT';
    }
}

if (!function_exists('investment_currency_of')) {
    /**
     * FIX-R7: ارزِ یک رکورد سرمایه‌گذاری/برداشت (ستون currency، پیش‌فرض 'usdt'
     * برای ردیف‌های legacy). نرمال‌ساز کانونی برای همهٔ خواندن‌های per-record
     * در سرویس‌ها و viewهای سرمایه‌گذاری.
     *
     * @param object|array<string, mixed>|null $record
     */
    function investment_currency_of(mixed $record): string
    {
        $raw = is_object($record)
            ? ($record->currency ?? null)
            : (is_array($record) ? ($record['currency'] ?? null) : null);
        $cur = strtolower(trim(str_value($raw)));
        return $cur === 'irt' ? 'irt' : 'usdt';
    }
}
