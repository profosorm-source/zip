<?php

/**
 * توابع کمکی URL و روتینگ
 */

if (!function_exists('url')) {
    function url(string $path = ''): string
    {
        return app(\Core\UrlGenerator::class)->to($path);
    }
}

if (!function_exists('asset')) {
    function asset(string $path): string
    {
        return app(\Core\UrlGenerator::class)->asset($path);
    }
}

if (!function_exists('asset_ver')) {
    /**
     * FIX-R15D: نسخهٔ cache-bust استاتیک‌ها (پارامتر ?v= در لینک‌های CSS/JS).
     * تاکنون لی‌اوت‌ها «?v=1.0.0» را هاردکد می‌کردند و بعد از هر تغییرِ
     * asset، کش مرورگر باطل نمی‌شد. مقدار از CHORTKE_ASSET_VER (bootstrap/app.php،
     * قابل‌بازنویسی با ASSET_VERSION در .env) خوانده می‌شود؛ fallback برای
     * entry-pointهای جانبی (CLI/tests) که bootstrap کامل را رد نمی‌کنند.
     */
    function asset_ver(): string
    {
        if (defined('CHORTKE_ASSET_VER')) {
            return CHORTKE_ASSET_VER;
        }
        return (string)config('app.version', '1.1.0');
    }
}

if (!function_exists('redirect')) {
    function redirect(string $path, int $statusCode = 302): never
    {
        if (!preg_match('#^https?://#i', $path) && function_exists('url')) {
            $path = url($path);
        }
        app(\Core\Response::class)->redirect($path, $statusCode);
        exit;
    }
}

if (!function_exists('back')) {
    function back(): never
    {
        app(\Core\Response::class)->back();
        exit;
    }
}

if (!function_exists('current_url')) {
    function current_url(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        return url($uri);
    }
}
