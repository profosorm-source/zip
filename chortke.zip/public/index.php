<?php
// PHP CLI dev server static asset handler
if (PHP_SAPI === 'cli-server') {
    $urlPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
    $trimmedPath = preg_replace('#^/chortke(?=/|$)#', '', $urlPath) ?? $urlPath;
    $filePath = __DIR__ . $trimmedPath;
    // Only yield to static file server if $filePath is an actual file (not a directory) and not a .php script
    if ($trimmedPath !== '/' && is_file($filePath) && !str_ends_with($filePath, '.php')) {
        return false;
    }
}

// Early tracing header
if (!headers_sent()) {
    // FIX-S8-2: هم‌راستا با FIX-S4-7 — مقدار correlation پیش از emit به هدر پاسخ
    // با الگوی canonical بچ S4 اعتبارسنجی می‌شود (قبلاً خام از $_SERVER عبور
    // می‌کرد؛ این تنها مصرف‌کنندهٔ خام باقی‌ماندهٔ هدر correlation در boot بود).
    // FIX (Round-18 P3): the incoming header key is HTTP_X_CORRELATION_ID —
    // $_SERVER['X_CORRELATION_ID'] is never populated, so the client-supplied
    // correlation id was always ignored.
    $corrCandidate = $_SERVER['HTTP_X_CORRELATION_ID'] ?? ($_SERVER['REQUEST_ID'] ?? '');
    $corr = (is_string($corrCandidate) && $corrCandidate !== ''
        && preg_match('/^[\w.\-:]{1,128}$/', $corrCandidate) === 1)
        ? $corrCandidate
        : bin2hex(random_bytes(8));
    header('X-Correlation-ID: ' . $corr);
}

/**
 * چرتکه (Chortke) — Clean Architecture Entry Point
 */

// ── ۱. پایه ─────────────────────────────────────────────────────
define('BASE_PATH', dirname(__DIR__));
define('VIEW_PATH', BASE_PATH . '/views');

ob_start();
ob_implicit_flush(false);

date_default_timezone_set('Asia/Tehran');

// LOW-03 Fix: Hardening PHP Environment - Remove identifying headers
@header_remove('X-Powered-By');
@ini_set('expose_php', 'off');

// HARDENING-01: Set maximum execution timeout for safety
if (PHP_SAPI !== 'cli' && function_exists('set_time_limit')) {
    @set_time_limit(30);
}

// ── ۲. بارگذاری محیط و هسته سیستم ──────────────────────────────
// Pre-bootstrap HTTPS enforcement for production: this must run before the
// container/bootstrap so a production-only bootstrap failure cannot bypass the
// required HTTP→HTTPS redirect.
if (PHP_SAPI !== 'cli') {
    // FIX-M4-04: تشخیص production در pre-bootstrap قبلاً فقط فایل .env را با
    // regex خام می‌خواند — نه process env تزریق‌شدهٔ اکسترویتور را می‌دید، نه
    // .env.local را، و مقدارهای quoted را هم نمی‌فهمید؛ در نتیجه production که
    // فقط از environment یا .env.local می‌آمد در این گات زودهنگام دیده نمی‌شد.
    // اکنون همان قرارداد precedence بوت اصلی (process env → .env → .env.local)
    // با parse هم‌خانوادهٔ parse_ini_file اجرا می‌شود — یک loader مفهومی.
    $envFile = BASE_PATH . '/.env';
    if (!is_file($envFile)) {
        $envFile = BASE_PATH . '/.env.local';
    }
    $envRaw = is_file($envFile) ? (string)@file_get_contents($envFile) : '';
    $envParsed = $envRaw !== '' ? @parse_ini_string($envRaw, false, INI_SCANNER_RAW) : [];
    if (!is_array($envParsed)) {
        $envParsed = [];
    }
    $m4PreEnvGet = static function (string $key) use ($envParsed): ?string {
        $raw = getenv($key);
        if ($raw === false || trim((string)$raw) === '') {
            $raw = $_ENV[$key] ?? ($envParsed[$key] ?? null);
        }
        $raw = $raw === null ? null : trim((string)$raw);
        return ($raw === '' || $raw === null) ? null : $raw;
    };
    $isProduction = $m4PreEnvGet('APP_ENV') === 'production';
    $remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '';
    $isDirectHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    // FIX-M2M16: گیت pre-bootstrap هم همان سیاست CIDR دقیق را اجرا می‌کند —
    // 172.* هاردکدِ وسیع (کل 172/8 با starts_with) با RFC1918 واقعی (172.16/12)
    // جایگزین شد. این گات آگاهانه پیش از bootstrap است (استقلال از config()) و
    // بعد از bootstrap مسیر Request::isSecure با is_trusted_proxy_peer() واحد می‌شود.
    $peerTrusted = in_array($remoteAddr, ['127.0.0.1', '::1'], true)
        || (filter_var($remoteAddr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
            && (
                str_starts_with($remoteAddr, '10.')
                || str_starts_with($remoteAddr, '192.168.')
                || preg_match('/^172\.(1[6-9]|2\d|3[01])\./', $remoteAddr) === 1
            ));
    $isHeaderHttps = (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
        && $peerTrusted;
    $isSecure = $isDirectHttps || $isHeaderHttps;

    if ($isProduction && !$isSecure) {
        // FIX-M4-04: مقصد ریدایرکت هم از همان loader واحد می‌آید (نه regex خام .env)
        $appUrl = (string)($m4PreEnvGet('APP_URL') ?? '');
        $appUrl = $appUrl !== '' ? rtrim($appUrl, '/') : '';
        if ($appUrl !== '' && !str_starts_with(strtolower($appUrl), 'https://')) {
            $appUrl = '';
        }
        if (empty($appUrl)) {
            // FIX-R2-07: مقصد ریدایرکت هرگز از SERVER_NAME/HTTP_HOST ساخته نمی‌شود —
            // Host هدرِ کنترل‌شدهٔ کلاینت است و regex فقط شکل hostname را می‌سنجد،
            // نه مجازبودنش را (open redirect / canonical غلط در misconfig).
            // بدون APP_URL پیکربندی‌شده، مقصد canonical ناشناخته است → شکست صریح
            // (fail-closed) به‌جای حدس از روی ورودی کاربر.
            http_response_code(500);
            echo 'Critical: APP_URL environment variable is required in production.';
            exit;
        }
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $query = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_QUERY);
        header('Location: ' . $appUrl . '/' . ltrim($path, '/') . ($query ? '?' . $query : ''), true, 301);
        exit;
    }
}
// تمام منطق‌های امنیتی شامل CORS، HTTPS و هدرها به صورت معماری سراسری (Middleware)
// به داخل هسته اپلیکیشن و Router منتقل شده‌اند.
require_once BASE_PATH . '/bootstrap/app.php';

// ── ۳. اجرای Application ────────────────────────────────────────
// Application::getInstance() مدیریت سشن، پایگاه داده و سرویس کانتینر را برعهده می‌گیرد.
$app = \Core\Application::getInstance();

// ── ۴. بارگذاری مسیرها (Routes) ────────────────────────────────
require_once BASE_PATH . '/routes/routes.php';

// ── ۵. اجرای نهایی و ارسال به کاربر ─────────────────────────────
try {
    $app->run();
} catch (\Throwable $e) {
    // ── ۶. سپر نهایی در برابر نشت خطا (Ultimate Safety Net) ────────
    // در این لایه بیرونی، ما فرض می‌کنیم کل سیستم (کانتینر، سرویس‌ها و کانفیگ) ممکن است خراب شده باشند.
    // بنابراین بدون هیچ وابستگی به توابع فریم‌ورک، با استفاده از قابلیت‌های نیتیو PHP خطا را مدیریت می‌کنیم.
    http_response_code(500);
    
    // پاکسازی کامل بافرهای خروجی باز برای جلوگیری از رندر صفحات شکسته یا اطلاعات ناقص
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // ثبت خطای بحرانی سیستمی در سیستم لاگ سرور (عاری از وابستگی به فریم‌ورک)
    error_log('Critical Bootstrapping Error: ' . $e->getMessage() . ' in ' . $e->getFile() . ' on line ' . $e->getLine());
    error_log($e->getTraceAsString());

    // خواندن مستقل فایل env. جهت جلوگیری از فراخوانی توابع کمکی فریم‌ورک در حالت خرابی
    $isDebug = false;
    if (defined('BASE_PATH')) {
        $envFile = BASE_PATH . '/.env';
        if (file_exists($envFile)) {
            $envContent = @file_get_contents($envFile);
            if ($envContent !== false && preg_match('/^\s*APP_DEBUG\s*=\s*(true|1)\s*$/mi', $envContent)) {
                $isDebug = true;
            }
        }
    }

    if (!headers_sent()) {
        header('Content-Type: text/html; charset=utf-8');
    }

    if ($isDebug) {
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><title>خطای بحرانی سیستم (حالت توسعه)</title>';
        echo '<style>body{font-family:Tahoma,sans-serif;padding:30px;background:#fcfcfc;} .box{background:#fff;border-right:5px solid #e74c3c;padding:25px;box-shadow:0 5px 20px rgba(0,0,0,0.05);border-radius:4px;overflow-x:auto;} pre{background:#f8f9fa;padding:15px;border:1px solid #eee;border-radius:4px;direction:ltr;text-align:left;}</style></head>';
        echo '<body><div class="box"><h2>خطای بحرانی راه‌اندازی سیستم</h2>';
        echo '<p><strong>خطا:</strong> ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p>';
        echo '<p><strong>فایل:</strong> ' . htmlspecialchars($e->getFile(), ENT_QUOTES, 'UTF-8') . ' (خط ' . $e->getLine() . ')</p>';
        echo '<h3>درخت فراخوانی (Stack Trace):</h3><pre>' . htmlspecialchars($e->getTraceAsString(), ENT_QUOTES, 'UTF-8') . '</pre></div></body></html>';
    } else {
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><title>خطای موقت سیستم</title>';
        echo '<style>body{font-family:Tahoma,sans-serif;padding:50px;background:#fcfcfc;text-align:center;} .box{display:inline-block;background:#fff;border-top:5px solid #e74c3c;padding:40px;box-shadow:0 5px 20px rgba(0,0,0,0.05);border-radius:4px;max-width:500px;}</style></head>';
        echo '<body><div class="box"><h2>بروز خطای موقت در سیستم</h2>';
        echo '<p>در حال حاضر سیستم با یک خطای غیرمنتظره مواجه شده است. تیم فنی ما از موضوع مطلع شده است. لطفاً چند لحظه دیگر دوباره تلاش کنید.</p></div></body></html>';
    }
    exit(1);
} finally {
    // ── ۷. اتمام بافر در شرایط عادی ─────────────────────────────
    if (ob_get_level() > 0) {
        ob_end_flush();
    }
}

