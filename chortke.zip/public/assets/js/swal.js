(function () {
  if (typeof Swal === "undefined") return;

  // ✅ RTL واقعی: با setAttribute(dir=rtl)
  const didOpenRtl = (popup) => {
    try {
      popup.setAttribute('dir', 'rtl');
      popup.style.textAlign = 'right';
    } catch (e) {}
  };

  window.swalWithBootstrapButtons = Swal.mixin({
    customClass: {
      confirmButton: "btn btn-success ms-2",
      cancelButton: "btn btn-danger"
    },
    buttonsStyling: false,
    didOpen: didOpenRtl
  });

  window.swalConfirm = function (options) {
    const defaults = {
      title: "آیا مطمئن هستید؟",
      text: "این عملیات قابل بازگشت نیست.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "تأیید",
      cancelButtonText: "انصراف",
      reverseButtons: true

    };

    return window.swalWithBootstrapButtons.fire(Object.assign({}, defaults, options || {}));
  };

  window.swalSuccess = function (options) {
    const defaults = {
      title: "انجام شد",
      text: "عملیات با موفقیت انجام شد.",
      icon: "success",
      confirmButtonText: "باشه"
    };
    return window.swalWithBootstrapButtons.fire(Object.assign({}, defaults, options || {}));
  };

  window.swalError = function (options) {
    const defaults = {
      title: "خطا",
      text: "مشکلی رخ داد.",
      icon: "error",
      confirmButtonText: "باشه"
    };
    return window.swalWithBootstrapButtons.fire(Object.assign({}, defaults, options || {}));
  };

  // FIX-T4 (باگ S): confirmAction به‌صورت global وجود نداشت در حالی که ۶+ فایل JS
  // (notificationssend, notifications, sentryfailedjobs, sentryfailedjobdetails,
  // sentryoutboxdlq, sentryeventfailures) آن را صدا می‌زدند → ReferenceError خاموش →
  // دکمه‌های «ارسال اعلان»، «retry job» و اکشن‌های اعلان ادمین کاملاً مرده بودند.
  // پشتیبانی از هر دو امضای موجود در کدبیس:
  //   ۱) confirmAction(title, text, callback)               — سبک lottery.js
  //   ۲) confirmAction({ type, title, text, confirmButtonText, onConfirm }) — سبک شیءگرا
  window.confirmAction = function (titleOrOptions, textOrUndefined, maybeCallback) {
    let opts;
    if (titleOrOptions && typeof titleOrOptions === 'object') {
      const o = titleOrOptions;
      opts = {
        title: o.title || "تأیید عملیات",
        text: o.text || "",
        icon: o.type || o.icon || "question",
        showCancelButton: true,
        confirmButtonText: o.confirmButtonText || "تأیید",
        cancelButtonText: o.cancelButtonText || "انصراف",
        reverseButtons: true
      };
      return window.swalWithBootstrapButtons.fire(opts).then(function (r) {
        if (r.isConfirmed && typeof o.onConfirm === 'function') o.onConfirm();
        return r;
      });
    }
    opts = {
      title: String(titleOrOptions || "تأیید عملیات"),
      text: String(textOrUndefined || ""),
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "بله",
      cancelButtonText: "انصراف",
      reverseButtons: true
    };
    return window.swalWithBootstrapButtons.fire(opts).then(function (r) {
      if (r.isConfirmed && typeof maybeCallback === 'function') maybeCallback();
      return r;
    });
  };
})();
