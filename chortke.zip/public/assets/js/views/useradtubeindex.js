document.querySelectorAll('.btn-start-adtube').forEach(btn => {
  btn.addEventListener('click', function() {
    const id = this.dataset.id;
    const btn = this;
    const busyHtml = '<span class="material-icons" style="font-size:14px;vertical-align:middle;">hourglass_top</span> درحال پردازش...';
    const idleHtml = '<span class="material-icons" style="font-size:16px;vertical-align:middle;">play_arrow</span> شروع تماشا';
    if (btn.dataset.busy === '1') return; // FIX-R36-W3 (F-A20-09): گارد دبل‌کلیک
    btn.dataset.busy = '1';
    btn.disabled = true; btn.innerHTML = busyHtml;
    fetch((window.BASE_URL || '') + '/adtube/start', {
      method:'POST',
      headers:{'Content-Type':'application/json','X-CSRF-Token':document.querySelector('meta[name=csrf-token]')?.content||''},
      body: JSON.stringify({ad_id: id})
    }).then(r=>r.json()).then(d=>{
      if(d.success && d.execution_id) {
        location.href = (window.BASE_URL || '') + `/adtube/${d.execution_id}/execute`;
      } else {
        alert(d.message || 'خطا در شروع'); btn.disabled = false;
        btn.innerHTML = idleHtml;
      }
    })
    // FIX-R36-W3 (F-A20-09): خطای شبکه دیگر دکمه را تا ابد «درحال پردازش» گیر نمی‌اندازد
    .catch(() => { alert('خطا در ارتباط با سرور'); btn.disabled = false; btn.innerHTML = idleHtml; })
    .finally(() => { btn.dataset.busy = ''; });
  });
});