/**
 * 🛡️ FIX-BUGREPORT-WIDGET: درایور CSP-safe ویجت شناور گزارش باگ.
 *
 * ویجت قدیمی JS نداشت (placeholder خالی) و هیچ‌کس آن را include نمی‌کرد.
 * این فایل مودال را باز می‌کند، اطلاعات صفحه را خودکار جمع می‌کند و
 * فرم را به POST /bug-reports/store (multipart، شامل اسکرین‌شات اختیاری)
 * ارسال می‌کند و پاسخ JSON کنترلر را نمایش می‌دهد.
 *
 * وابستگی‌ها: Bootstrap 5 bundle (مودال)، متا csrf-token، Notyf (اختیاری).
 */
(function () {
  'use strict';

  var fab = document.getElementById('bugReportFab');
  var modalEl = document.getElementById('bugReportModal');
  if (!fab || !modalEl) return;

  var form = document.getElementById('bugReportForm');
  var successBox = document.getElementById('bugReportSuccess');
  var errorBox = document.getElementById('bug_error');
  var submitBtn = document.getElementById('bugReportSubmitBtn');
  var descEl = document.getElementById('bug_description');
  var counterEl = document.getElementById('bug_char_count');
  var fileEl = document.getElementById('bug_screenshot');

  function csrf() {
    return document.querySelector('meta[name="csrf-token"]')?.content || window.csrfToken || '';
  }

  function notify(msg, ok) {
    if (window.Notyf) {
      var n = new Notyf({ duration: 4000, position: { x: 'left', y: 'top' }, dismissible: true });
      if (ok && typeof n.success === 'function') n.success(msg);
      else if (!ok && typeof n.error === 'function') n.error(msg);
      else if (typeof n.open === 'function') n.open({ type: ok ? 'success' : 'error', message: msg });
      return;
    }
    if (ok) { /* موفقیت داخل مودال نمایش داده می‌شود */ }
    else { alert(msg); }
  }

  function showError(msg) {
    errorBox.textContent = msg;
    errorBox.classList.remove('d-none');
  }

  function hideError() {
    errorBox.classList.add('d-none');
    errorBox.textContent = '';
  }

  /** اثر انگشت سبک مرورگر — سرور آن را با IP + UA ترکیب و هش می‌کند (BugReportController).
   * FIX-R36-W3 (F-A20-12): پیاده‌سازی مرجع مشترک (ux-extras.js::chortkeDeviceFingerprint) با همین
   * الگوریتم FNV-1a دوردُر؛ بدنهٔ محلی fallbackِ نبودِ فایل مشترک است. */
  function deviceFingerprint() {
    if (window.chortkeDeviceFingerprint) {
      try { return window.chortkeDeviceFingerprint(); } catch (e) { /* افت به بدنهٔ محلی */ }
    }
    try {
      var parts = [
        navigator.userAgent,
        navigator.language,
        (navigator.languages || []).join(','),
        String(navigator.platform || ''),
        String(screen.width) + 'x' + String(screen.height),
        String(screen.colorDepth || ''),
        Intl.DateTimeFormat().resolvedOptions().timeZone || '',
        String(navigator.hardwareConcurrency || ''),
        String(navigator.maxTouchPoints || '')
      ];
      var s = parts.join('|');
      var h1 = 0x811c9dc5, h2 = 0x1000193;
      for (var i = 0; i < s.length; i++) {
        h1 = (h1 ^ s.charCodeAt(i)) >>> 0;
        h1 = (h1 * 0x01000193) >>> 0;
        h2 = (h2 + s.charCodeAt(i) * (i + 7)) >>> 0;
      }
      return ('fp_' + h1.toString(16) + h2.toString(16));
    } catch (e) {
      return '';
    }
  }

  function collectMeta() {
    document.getElementById('bug_page_url').value = location.href.split('#')[0];
    document.getElementById('bug_page_title').value = (document.title || '').slice(0, 400);
    document.getElementById('bug_screen_resolution').value =
      String(screen.width) + 'x' + String(screen.height);
    document.getElementById('bug_device_fingerprint').value = deviceFingerprint();
  }

  function resetForm() {
    form.classList.remove('d-none');
    successBox.classList.add('d-none');
    form.reset();
    counterEl.textContent = '0';
    hideError();
    submitBtn.disabled = false;
    submitBtn.innerHTML = '<span class="material-icons me-1 align-middle" style="font-size:16px">send</span> ارسال گزارش';
  }

  fab.addEventListener('click', function () {
    collectMeta();
    resetForm();
    if (window.bootstrap) { new bootstrap.Modal(modalEl).show(); }
  });

  if (descEl && counterEl) {
    descEl.addEventListener('input', function () {
      counterEl.textContent = String(Math.min(descEl.value.length, 5000));
    });
  }

  submitBtn.addEventListener('click', function () {
    hideError();

    var category = document.getElementById('bug_category').value || 'other';
    var description = (descEl.value || '').trim();

    if (description.length < 10) {
      showError('توضیحات باید حداقل ۱۰ کاراکتر باشد.');
      return;
    }
    if (description.length > 5000) {
      showError('توضیحات نمی‌تواند بیش از ۵۰۰۰ کاراکتر باشد.');
      return;
    }

    var file = fileEl && fileEl.files && fileEl.files[0] ? fileEl.files[0] : null;
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        showError('حجم اسکرین‌شات بیش از ۵ مگابایت است.');
        return;
      }
      var okTypes = ['image/jpeg', 'image/jpg', 'image/png'];
      if (okTypes.indexOf(file.type) === -1) {
        showError('فرمت اسکرین‌شات فقط JPG یا PNG می‌تواند باشد.');
        return;
      }
    }

    var fd = new FormData();
    fd.append('category', category);
    fd.append('description', description);
    fd.append('page_url', document.getElementById('bug_page_url').value);
    fd.append('page_title', document.getElementById('bug_page_title').value);
    fd.append('screen_resolution', document.getElementById('bug_screen_resolution').value);
    fd.append('device_fingerprint', document.getElementById('bug_device_fingerprint').value);
    fd.append('_csrf_token', csrf());
    if (file) fd.append('screenshot', file);

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="material-icons me-1 align-middle" style="font-size:16px">hourglass_top</span> در حال ارسال...';

    fetch((window.BASE_URL || '') + '/bug-reports/store', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'X-CSRF-Token': csrf(),
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/json'
      },
      body: fd
    }).then(function (res) {
      return res.json().catch(function () { return { success: false, message: 'پاسخ سرور قابل خواندن نیست.' }; });
    }).then(function (data) {
      if (data && data.success) {
        form.classList.add('d-none');
        successBox.classList.remove('d-none');
        notify(data.message || 'گزارش شما ثبت شد.', true);
      } else {
        showError((data && data.message) || 'ارسال گزارش ناموفق بود. لطفاً دوباره تلاش کنید.');
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span class="material-icons me-1 align-middle" style="font-size:16px">send</span> ارسال گزارش';
      }
    }).catch(function () {
      showError('خطا در ارتباط با سرور. اتصال اینترنت خود را بررسی کنید.');
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<span class="material-icons me-1 align-middle" style="font-size:16px">send</span> ارسال گزارش';
    });
  });
})();
