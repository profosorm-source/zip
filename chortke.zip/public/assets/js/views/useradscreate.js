/**
 * Ads Wizard — Progressive AJAX Wizard
 * Features: Step-by-step disclosure, real-time validation, cost preview, zero reload.
 */

(function() {
  'use strict';

  const WIZARD = {
    step: 1,
    maxSteps: 4,
    selectedType: null,
    typeMeta: null,
    formData: new FormData(),
    validations: {},
    csrf: document.querySelector('meta[name="csrf-token"]')?.content || '',
    // 🛡️ FIX-COUPON-ADS-CAMPAIGN: وضعیت کد تخفیف (فقط کدِ تأییدشده ارسال می‌شود؛
    // مبلغ تخفیف همیشه سمت سرور دوباره محاسبه می‌شود)
    // R15 راند ۸۸: توکن اعتبارسنجی (validation_token از preview) هم نگه داشته
    // می‌شود و همراه ثبت نهایی به‌عنوان coupon_token ارسال می‌شود تا سمت سرور
    // در apply_coupon مصرف شود (single-use binding بین اعتبارسنجی و برداشت).
    coupon: { applied: false, code: '', preview: null, token: '' },
    lastBudgetPreview: null,
  };

  const els = {};

  document.addEventListener('DOMContentLoaded', init);

  function init() {
    cacheElements();
    bindEvents();
    window.WIZARD_RESET_TO_STEP1 = () => {
      // S20: ریست ویزارد = شروع intent جدید — نانس idempotency می‌چرخد
      rotateIntentKey();
      WIZARD.selectedType = null;
      WIZARD.typeMeta = null;
      els.typeCards?.forEach(c => c.classList.remove('selected'));
      const step2Title = document.getElementById('step2Title');
      if (step2Title) step2Title.textContent = 'جزئیات تبلیغ';
      resetCouponState();
      advanceTo(1);
    };
    window.addEventListener('popstate', () => {
      const p = new URLSearchParams(window.location.search);
      const st = parseInt(p.get('step') || '1', 10);
      const tp = p.get('type');
      if (tp && tp !== WIZARD.selectedType) {
        onSelectType(tp);
      } else if (st >= 1 && st <= 4 && st !== WIZARD.step) {
        advanceTo(st, false);
      }
    });
    const p = new URLSearchParams(window.location.search);
    const initialStep = parseInt(p.get('step') || '1', 10);
    const initialType = p.get('type');
    if (initialType && initialStep > 1) {
      onSelectType(initialType);
    } else {
      renderStep(1);
    }
  }

  function cacheElements() {
    els.container = document.getElementById('adsWizard');
    els.stepper = document.getElementById('wizardStepper');
    els.step1 = document.getElementById('step1');
    els.step2 = document.getElementById('step2');
    els.step3 = document.getElementById('step3');
    els.step4 = document.getElementById('step4');
    els.success = document.getElementById('wizardSuccess');
    els.typeCards = document.querySelectorAll('.type-card');
    els.dynamicForm = document.getElementById('dynamicForm');
    els.budgetPreview = document.getElementById('budgetPreview');
    els.btnNext = document.getElementById('btnNext');
    els.btnPrev = document.getElementById('btnPrev');
    els.btnSubmit = document.getElementById('btnSubmit');
    els.loadingOverlay = document.getElementById('stepLoading');
    els.finalSummary = document.getElementById('wizardFinalSummary');
    // 🛡️ FIX-COUPON-ADS-CAMPAIGN
    els.couponInput = document.getElementById('wizardCouponInput');
    els.btnApplyCoupon = document.getElementById('btnApplyCoupon');
    els.btnRemoveCoupon = document.getElementById('btnRemoveCoupon');
    els.couponFeedback = document.getElementById('wizardCouponFeedback');
  }

  function bindEvents() {
    els.typeCards.forEach(card => {
      card.addEventListener('click', () => onSelectType(card.dataset.type));
    });

    document.querySelectorAll('.step-node').forEach((node, idx) => {
      node.addEventListener('click', () => {
        const targetStep = idx + 1;
        if (targetStep < WIZARD.step || (targetStep === 2 && WIZARD.selectedType)) {
          advanceTo(targetStep);
        }
      });
    });

    els.btnNext?.addEventListener('click', onNext);
    els.btnPrev?.addEventListener('click', onPrev);
    els.btnSubmit?.addEventListener('click', onSubmit);

    // 🛡️ FIX-COUPON-ADS-CAMPAIGN: دکمه‌های اعمال/حذف کد تخفیف
    els.btnApplyCoupon?.addEventListener('click', onApplyCoupon);
    els.btnRemoveCoupon?.addEventListener('click', onRemoveCoupon);
    els.couponInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); onApplyCoupon(); }
    });

    // Delegate real-time validation on dynamic form
    els.dynamicForm?.addEventListener('input', debounce(onFieldInput, 350));
    els.dynamicForm?.addEventListener('change', onFieldChange);
  }

  function endpoint(key, fallback) {
    return els.container?.dataset?.[key] || fallback;
  }

  function withQuery(url, params) {
    const sep = url.includes('?') ? '&' : '?';
    return url + sep + params;
  }

  // ── Step 1: Type Selection ───────────────────────────────────────────

  async function onSelectType(type) {
    if (WIZARD.step !== 1) advanceTo(1);

    setLoading(true);

    try {
      const res = await fetch(withQuery(endpoint('typeInfoUrl', '/ads/api/type-info'), 'type=' + encodeURIComponent(type)), {
        headers: { 'Accept': 'application/json' }
      });
      const json = await res.json();

      if (!json.success) throw new Error(json.message || 'خطا در دریافت اطلاعات');

      WIZARD.selectedType = type;
      WIZARD.typeMeta = json.data;

      // 🛡️ FIX-COUPON-ADS-CAMPAIGN: نوع کمپین عوض شده؛ کد تخفیف باید دوباره اعمال شود
      if (WIZARD.coupon.applied) {
        resetCouponState();
        showToast('warning', 'نوع کمپین تغییر کرد؛ کد تخفیف را در مرحله بررسی هزینه دوباره اعمال کنید.');
      }

      // Visual feedback
      els.typeCards.forEach(c => c.classList.toggle('selected', c.dataset.type === type));

      // Build dynamic form before transition
      buildDynamicForm(json.data.fields);

      // Small delay for visual confirmation then advance
      await sleep(280);
      advanceTo(2);
    } catch (err) {
      showToast('error', err.message);
    } finally {
      setLoading(false);
    }
  }

  // ── Step 2: Dynamic Form ───────────────────────────────────────────

  function buildDynamicForm(fields) {
    if (!els.dynamicForm) return;
    els.dynamicForm.innerHTML = '';
    WIZARD.validations = {};

    const fragment = document.createDocumentFragment();

    fields.forEach((field, index) => {
      const group = document.createElement('div');
      group.className = 'field-group';
      group.dataset.field = field.name;

      const label = document.createElement('label');
      label.textContent = field.label + (field.required ? ' *' : '');
      group.appendChild(label);

      let input;
      if (field.type === 'textarea') {
        input = document.createElement('textarea');
        input.rows = 3;
      } else if (field.type === 'select') {
        input = document.createElement('select');
        // FIX-R36-W3 (F-A21-07): options سرور (/ads/api/type-info) با createElement+textContent ساخته
        // می‌شوند — نه interpolation خام در innerHTML (defence-in-depth کنار escHtml بقیهٔ فایل)
        const placeholder = document.createElement('option');
        placeholder.value = '';
        placeholder.disabled = true;
        placeholder.selected = true;
        placeholder.textContent = 'انتخاب کنید...';
        input.appendChild(placeholder);
        (field.options || []).forEach(o => {
          const opt = document.createElement('option');
          // FIX-CY3-A6 (یافتهٔ ۶ بچ CY3): option می‌تواند {value,label} باشد
          // (فیلد ارز کمپین: value=irt/usdt + label=تومان/تتر) یا رشتهٔ سادهٔ قبلی.
          if (o && typeof o === 'object' && !Array.isArray(o)) {
            opt.value = String(o.value ?? '');
            opt.textContent = String(o.label ?? o.value ?? '');
          } else {
            opt.value = o;
            opt.textContent = o;
          }
          input.appendChild(opt);
        });
      } else if (field.type === 'file') {
        input = document.createElement('input');
        input.type = 'file';
        if (field.accept) input.accept = field.accept;
      } else {
        input = document.createElement('input');
        input.type = field.type;
        if (field.min) input.min = field.min;
        if (field.max) input.max = field.max;
        if (field.step) input.step = field.step;
        if (field.placeholder) input.placeholder = field.placeholder;
      }

      input.name = field.name;
      input.className = 'form-control';
      input.required = !!field.required;
      input.dataset.validate = 'true';
      if (field.default) input.value = field.default;

      // RTL text inputs
      if (field.type === 'text' || field.type === 'textarea') {
        input.dir = 'rtl';
      }
      if (field.type === 'url' || field.type === 'number') {
        input.dir = 'ltr';
      }

      group.appendChild(input);

      // Feedback element
      const feedback = document.createElement('div');
      feedback.className = 'validation-feedback';
      group.appendChild(feedback);

      if (field.hint) {
        const hint = document.createElement('div');
        hint.className = 'field-hint';
        hint.textContent = field.hint;
        group.appendChild(hint);
      }

      fragment.appendChild(group);
    });

    // Hidden type field
    const hidden = document.createElement('input');
    hidden.type = 'hidden';
    hidden.name = 'ad_type';
    hidden.value = WIZARD.selectedType;
    fragment.appendChild(hidden);

    els.dynamicForm.appendChild(fragment);
    if (WIZARD.step === 2) {
      els.dynamicForm.classList.add('active');
    }
  }

  // ── Real-time Validation ───────────────────────────────────────────

  async function onFieldInput(e) {
    const field = e.target;
    if (!field.dataset.validate || !field.name) return;

    // Skip empty optional fields on input (validate on blur/change instead)
    if (!field.required && !field.value.trim()) {
      clearFieldStatus(field);
      return;
    }

    await validateField(field);
    updateStep2Validity();
  }

  async function onFieldChange(e) {
    const field = e.target;
    if (!field.dataset.validate || !field.name) return;
    await validateField(field);
    updateStep2Validity();

    // If price/quantity changed, refresh budget preview (if on step 3)
    if (WIZARD.step === 3 && isBudgetField(field.name)) {
      // 🛡️ FIX-COUPON-ADS-CAMPAIGN: مبنای تخفیف عوض شده است؛ کد باید دوباره اعمال شود
      if (WIZARD.coupon.applied) {
        invalidateAppliedCoupon('مبلغ کمپین تغییر کرد؛ لطفاً کد تخفیف را دوباره اعمال کنید.');
      }
      await refreshBudgetPreview();
    }
  }

  async function validateField(field) {
    const group = field.closest('.field-group');
    const feedback = group?.querySelector('.validation-feedback');
    if (!feedback) return;

    try {
      const formData = collectFormData();
      const res = await fetch(endpoint('validateFieldUrl', '/ads/api/validate-field'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': WIZARD.csrf,
        },
        body: JSON.stringify({
          ad_type: WIZARD.selectedType,
          field: field.name,
          value: field.value,
          ...formData,
        }),
      });
      const json = await res.json();

      WIZARD.validations[field.name] = json.success;

      field.classList.remove('is-valid', 'is-invalid');
      field.classList.add(json.success ? 'is-valid' : 'is-invalid');
      feedback.classList.toggle('show', true);
      feedback.classList.toggle('valid', json.success);
      feedback.classList.toggle('invalid', !json.success);
      // R31 XSS: پیام سرور قبل از ورود به innerHTML escape می‌شود (escHtml پایین فایل)
      feedback.innerHTML = json.success
        ? '<span class="material-icons wiz-feedback-icon">check_circle</span> ' + escHtml(json.message || 'معتبر')
        : '<span class="material-icons wiz-feedback-icon">error</span> ' + escHtml(json.errors?.[0] || 'نامعتبر');
    } catch (err) {
      // Silent fail on network error — don't block typing
    }
  }

  function clearFieldStatus(field) {
    field.classList.remove('is-valid', 'is-invalid');
    const group = field.closest('.field-group');
    const fb = group?.querySelector('.validation-feedback');
    if (fb) fb.classList.remove('show');
  }

  function updateStep2Validity() {
    const fields = els.dynamicForm?.querySelectorAll('[data-validate]');
    if (!fields) return;
    const allValid = Array.from(fields).every(f => {
      if (f.required && !f.value.trim()) return false;
      if (WIZARD.validations[f.name] === false) return false;
      return true;
    });
    if (els.btnNext) els.btnNext.disabled = !allValid;
  }

  // ── Navigation ─────────────────────────────────────────────────────

  async function onNext() {
    if (WIZARD.step === 2) {
      // Validate all required fields before proceeding
      const fields = els.dynamicForm?.querySelectorAll('[data-validate]');
      let allValid = true;
      for (const f of fields) {
        if (f.required && !f.value.trim()) allValid = false;
        if (WIZARD.validations[f.name] === false) allValid = false;
      }
      if (!allValid) {
        showToast('warning', 'لطفاً همه فیلدهای الزامی را صحیح وارد کنید.');
        return;
      }
      await refreshBudgetPreview();
    }
    if (WIZARD.step < WIZARD.maxSteps) advanceTo(WIZARD.step + 1);
  }

  function onPrev() {
    if (WIZARD.step > 1) advanceTo(WIZARD.step - 1);
  }

  function advanceTo(step, push = true) {
    WIZARD.step = step;
    renderStep(step);
    updateStepper(step);
    updateButtons(step);
    if (push) {
      try {
        const url = new URL(window.location.href);
        url.searchParams.set('section', 'create');
        url.searchParams.set('step', step);
        if (WIZARD.selectedType) url.searchParams.set('type', WIZARD.selectedType);
        else url.searchParams.delete('type');
        history.pushState(null, '', url.toString());
      } catch(e){}
    }
  }

  function renderStep(step) {
    [1,2,3,4].forEach(n => {
      const el = els['step'+n];
      if (el) el.classList.toggle('active', n === step);
    });

    // Ensure dynamic detail form becomes visible when the details step is active.
    if (els.dynamicForm) {
      els.dynamicForm.classList.toggle('active', step === 2);
    }

    // Budget preview only on step 3
    if (step === 3) {
      els.budgetPreview?.classList.add('active');
    } else {
      els.budgetPreview?.classList.remove('active');
    }

    // 🛡️ FIX-COUPON-ADS-CAMPAIGN: خلاصه‌ی نهایی با تخفیف در مرحله ۴
    if (step === 4) {
      renderFinalSummary();
    }
  }

  function updateStepper(step) {
    if (!els.stepper) return;
    els.stepper.className = 'wizard-stepper step-' + step;
    const nodes = els.stepper.querySelectorAll('.step-node');
    nodes.forEach((node, idx) => {
      const s = idx + 1;
      node.classList.remove('active', 'completed');
      if (s === step) node.classList.add('active');
      else if (s < step) node.classList.add('completed');
    });
  }

  function updateButtons(step) {
    if (els.btnPrev) {
      els.btnPrev.style.visibility = step === 1 ? 'hidden' : 'visible';
    }
    if (els.btnNext) {
      els.btnNext.classList.toggle('d-none', step === 4);
    }
    if (els.btnSubmit) {
      els.btnSubmit.classList.toggle('d-none', step !== 4);
    }
  }

  // ── Step 3: Budget Preview ───────────────────────────────────────────

  /**
   * 🛡️ FIX-COUPON-ADS-CAMPAIGN — اعمال کد تخفیف: پیش‌نمایش با coupon_code
   * گرفته می‌شود؛ اگر سرور تأیید کرد، وضعیت applied ثبت می‌شود.
   */
  async function onApplyCoupon() {
    const code = (els.couponInput?.value || '').trim().toUpperCase();
    if (!code) {
      setCouponFeedback('error', 'لطفاً کد تخفیف را وارد کنید.');
      return;
    }
    if (els.btnApplyCoupon) els.btnApplyCoupon.disabled = true;
    try {
      const data = collectFormData();
      data.coupon_code = code;
      const json = await fetchBudgetPreview(data);
      const c = json.preview?.coupon;
      if (json.success && c && c.valid) {
        WIZARD.coupon = { applied: true, code: c.coupon_code || code, preview: c, token: String(c.validation_token || '') };
        setCouponFeedback('success', 'کد تخفیف «' + (c.coupon_code || code) + '» اعمال شد.' +
          (c.effective_total_count ? ' تعداد مؤثر کمپین: ' + fmtNumber(c.effective_total_count) + ' مورد.' : ''));
        if (els.couponInput) { els.couponInput.value = c.coupon_code || code; els.couponInput.disabled = true; }
        els.btnApplyCoupon?.classList.add('d-none');
        els.btnRemoveCoupon?.classList.remove('d-none');
        renderBudgetPreview(json.preview);
        WIZARD.lastBudgetPreview = json.preview;
      } else {
        WIZARD.coupon = { applied: false, code: '', preview: null, token: '' };
        setCouponFeedback('error', (c && c.message) || json.message || 'کد تخفیف معتبر نیست.');
        if (json.success && json.preview) { renderBudgetPreview(json.preview); WIZARD.lastBudgetPreview = json.preview; }
      }
    } catch (err) {
      setCouponFeedback('error', 'خطای شبکه در بررسی کد تخفیف');
    } finally {
      if (els.btnApplyCoupon) els.btnApplyCoupon.disabled = false;
    }
  }

  /**
   * 🛡️ FIX-COUPON-ADS-CAMPAIGN — حذف کد اعمال‌شده و بازگشت به پیش‌نمایش عادی
   */
  async function onRemoveCoupon() {
    WIZARD.coupon = { applied: false, code: '', preview: null, token: '' };
    if (els.couponInput) { els.couponInput.value = ''; els.couponInput.disabled = false; }
    els.btnApplyCoupon?.classList.remove('d-none');
    els.btnRemoveCoupon?.classList.add('d-none');
    setCouponFeedback('', '');
    await refreshBudgetPreview();
  }

  /**
   * 🛡️ FIX-COUPON-ADS-CAMPAIGN — باطل‌کردن کد بعد از تغییر مبنا (قیمت/تعداد/بودجه)
   */
  function invalidateAppliedCoupon(message) {
    WIZARD.coupon = { applied: false, code: '', preview: null, token: '' };
    if (els.couponInput) { els.couponInput.value = ''; els.couponInput.disabled = false; }
    els.btnApplyCoupon?.classList.remove('d-none');
    els.btnRemoveCoupon?.classList.add('d-none');
    setCouponFeedback('warning', message || 'کد تخفیف باید دوباره اعمال شود.');
    showToast('warning', message || 'کد تخفیف باید دوباره اعمال شود.');
  }

  function setCouponFeedback(kind, message) {
    if (!els.couponFeedback) return;
    els.couponFeedback.className = 'wizard-coupon-feedback' + (kind ? ' show ' + kind : '');
    els.couponFeedback.textContent = message || '';
  }

  async function fetchBudgetPreview(data) {
    const res = await fetch(endpoint('previewCostUrl', '/ads/api/preview-cost'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': WIZARD.csrf,
      },
      body: JSON.stringify(data),
    });
    return res.json();
  }

  async function refreshBudgetPreview() {
    if (!els.budgetPreview) return;
    els.budgetPreview.classList.add('loading');

    const data = collectFormData();
    // 🛡️ FIX-COUPON-ADS-CAMPAIGN: اگر کدی اعمال شده، همراه پیش‌نمایش ارسال می‌شود
    if (WIZARD.coupon.applied && WIZARD.coupon.code) {
      data.coupon_code = WIZARD.coupon.code;
    }

    try {
      const json = await fetchBudgetPreview(data);

      if (json.success) {
        renderBudgetPreview(json.preview);
        WIZARD.lastBudgetPreview = json.preview;
        // اگر سرور کد را رد کرده باشد (مثلاً منقضی شده)، حالت applied را باطل کن
        if (WIZARD.coupon.applied && json.preview?.coupon && !json.preview.coupon.valid) {
          invalidateAppliedCoupon(json.preview.coupon.message || 'کد تخفیف دیگر معتبر نیست.');
        }
      } else {
        showToast('warning', json.message || 'خطا در محاسبه بودجه');
      }
    } catch (err) {
      showToast('error', 'خطای شبکه در محاسبه بودجه');
    } finally {
      els.budgetPreview.classList.remove('loading');
    }
  }

  function escHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, ch => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]
    ));
  }

  function renderBudgetPreview(p) {
    if (!els.budgetPreview || !p) return;
    const c = p.coupon && p.coupon.valid ? p.coupon : null;
    const baseBudget = c ? c.base_budget : p.base_budget;
    const feeAmount = c ? c.site_fee_amount : p.site_fee_amount;
    const totalWithFee = c ? c.total_with_fee : p.total_with_fee;
    // FIX-CY3-A6 (یافتهٔ ۶ بچ CY3): برچسب ارز از سرور (preview.currency_label) —
    // قبلاً «تومان» هاردکد بود و در حالت تتری پروژه گمراه‌کننده می‌شد.
    const cur = String(p.currency_label || (String(p.currency) === 'usdt' ? 'تتر' : 'تومان'));

    let couponRows = '';
    if (c) {
      couponRows += `
        <div class="budget-row budget-row-discount">
          <span>تخفیف کد ${escHtml(c.coupon_code || '')}</span>
          <span class="budget-amount">−${fmtNumber(c.discount_amount)} ${escHtml(cur)}</span>
        </div>`;
      if (c.fee_discount > 0) {
        couponRows += `
        <div class="budget-row budget-row-note">
          <span>سهم کسرشده از کارمزد سایت</span>
          <span class="budget-amount">${fmtNumber(c.fee_discount)} ${escHtml(cur)}</span>
        </div>`;
      }
      if (c.budget_discount > 0) {
        couponRows += `
        <div class="budget-row budget-row-note">
          <span>کاهش بودجه کمپین</span>
          <span class="budget-amount">−${fmtNumber(c.budget_discount)} ${escHtml(cur)}</span>
        </div>`;
      }
      couponRows += `
        <div class="budget-row budget-row-effective">
          <span>بودجه نهایی کمپین${c.effective_total_count ? ' (' + fmtNumber(c.effective_total_count) + ' مورد)' : ''}</span>
          <span class="budget-amount">${fmtNumber(c.effective_budget)} ${escHtml(cur)}</span>
        </div>`;
    }

    els.budgetPreview.innerHTML = `
      <div class="budget-preview-card" id="budgetPreviewCard">
        <div class="budget-row">
          <span>بودجه پایه</span>
          <span class="budget-amount">${fmtNumber(baseBudget)} ${escHtml(cur)}</span>
        </div>
        <div class="budget-row">
          <span>کارمزد سایت (${p.site_fee_percent}%)</span>
          <span class="budget-amount">${fmtNumber(feeAmount)} ${escHtml(cur)}</span>
        </div>
        ${couponRows}
        <div class="budget-row total">
          <span>جمع کل کسر از کیف پول</span>
          <span class="budget-amount">${fmtNumber(totalWithFee)} ${escHtml(cur)}</span>
        </div>
        ${p.estimated_reach ? `
        <div class="budget-row budget-row-estimate">
          <span>تخمین دسترسی</span>
          <span class="budget-amount">~${fmtNumber(p.estimated_reach)} نفر</span>
        </div>` : ''}
      </div>
    `;
  }

  /**
   * 🛡️ FIX-COUPON-ADS-CAMPAIGN — خلاصه‌ی نهایی مرحله ۴ (همراه تخفیف)
   */
  function renderFinalSummary() {
    if (!els.finalSummary) return;
    const p = WIZARD.lastBudgetPreview;
    if (!p) { els.finalSummary.innerHTML = ''; return; }
    const c = p.coupon && p.coupon.valid ? p.coupon : null;
    // FIX-CY3-A6: برچسب ارز از پیش‌نمایش سرور
    const cur = String(p.currency_label || (String(p.currency) === 'usdt' ? 'تتر' : 'تومان'));
    els.finalSummary.innerHTML = `
      <div class="budget-preview-card">
        <div class="budget-row">
          <span>بودجه کمپین</span>
          <span class="budget-amount">${fmtNumber(c ? c.effective_budget : p.base_budget)} ${escHtml(cur)}</span>
        </div>
        ${c ? `
        <div class="budget-row budget-row-discount">
          <span>تخفیف (${escHtml(c.coupon_code || '')})</span>
          <span class="budget-amount">−${fmtNumber(c.discount_amount)} ${escHtml(cur)}</span>
        </div>` : ''}
        <div class="budget-row total">
          <span>مبلغ کسر از کیف پول</span>
          <span class="budget-amount">${fmtNumber(c ? c.total_with_fee : p.total_with_fee)} ${escHtml(cur)}</span>
        </div>
      </div>
    `;
  }

  // ── S20 (گزارش بخش ۲۰ — یافتهٔ ۲): کلید idempotency پایدار برای POST /ads/store ──
  // سرور (AdsController::store → AdSystemManager::create → IdempotencyService) از
  // قبل X-Idempotency-Key (هدر) یا idempotency_key (بدنه) را می‌پذیرفت ولی این
  // فرم هیچ‌کدام را نمی‌فرستاند ⇒ در timeout (AbortController ۴۵s) که پاسخ به
  // مرورگر نرسیده ولی سرور commit کرده، دکمهٔ دوم «کمپین دوم + hold مالی دوم»
  // می‌ساخت. قرارداد کلید = «امضای پیلود فعلی + نانسِ یک‌بارِ intent»:
  //   - retry بدون تغییر ⇒ همان امضا + همان نانس ⇒ همان کلید ⇒ سرور همان
  //     ad_id/escrow را replay می‌کند، کمپین دومی ساخته نمی‌شود.
  //   - ویرایش هر فیلد/کوپن/فایل بعد از خطا ⇒ امضای متفاوت ⇒ کلید جدید =
  //     intent جدید.
  //   - 🛡️ FIX-S20-CLOSE-F3: سرور اکنون کلید را «الزامی» می‌کند و «اثر انگشت پیلود»
  //     را هم‌زمان با کلید ثبت می‌کند — همان کلید با محتوای متفاوت، به‌جای
  //     replay نتیجهٔ قدیمی، برخورد ۴۰۹ می‌گیرد. امضای کلاینت و اثر انگشت
  //     سرور حالا هم‌قراردادند: هر دو فقط محتوای کسب‌وکاری فرمان را می‌بینند.
  //   - پس از موفقیت یا ریست ویزارد، نانس می‌چرخد ⇒ کمپین مشابه بعدی intent
  //     جدید است و به‌راستی ساخته می‌شود (نه replay کمپین قبلی).
  let intentNonce = null;
  let boundIntentSignature = null;

  function generateIdempotencyKey() {
    if (window.chortkeIdempotencyKey) return window.chortkeIdempotencyKey('ADS_');
    return 'ADS_' + Date.now() + '_' + Math.random().toString(16).slice(2);
  }
  function stableStringify(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(stableStringify).join(',') + ']';
    return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stableStringify(value[k])).join(',') + '}';
  }
  function fileSignature() {
    const parts = [];
    els.dynamicForm?.querySelectorAll('input[type="file"]').forEach(input => {
      const f = input.files && input.files[0];
      parts.push((input.name || '') + ':' + (f ? (f.name + '|' + f.size + '|' + f.lastModified) : ''));
    });
    return parts.join(';');
  }
  function intentSignature(payload) {
    return stableStringify(payload) + '||' + fileSignature();
  }
  function getIntentKey(payload) {
    const sig = intentSignature(payload);
    if (intentNonce === null || boundIntentSignature !== sig) {
      intentNonce = generateIdempotencyKey();
      boundIntentSignature = sig;
    }
    return intentNonce;
  }
  function rotateIntentKey() {
    intentNonce = null;
    boundIntentSignature = null;
  }

  // ── Step 4: Confirm & Submit ───────────────────────────────────────

  async function onSubmit() {
    setLoading(true);
    els.btnSubmit.disabled = true;
    els.btnSubmit.innerHTML = '<span class="wizard-spinner"></span> در حال ثبت...';

    const data = collectFormData();
    // S20: کلید idempotency باید پیش از fetch و بر اساس همین پیلود ساخته شود؛
    // در retry بدون تغییر، همان کلید قبلی بازگردانده می‌شود (replay امن سمت سرور).
    const intentKey = getIntentKey(data);
    const formData = new FormData();
    for (const [k, v] of Object.entries(data)) {
      formData.append(k, v);
    }
    // S20: کلید هم در بدنه (idempotency_key) هم در هدر (X-Idempotency-Key) —
    // کنترلر هر دو مسیر را می‌پذیرد؛ هدر برای proxy-های ممکن، بدنه برای سازگاری.
    formData.append('idempotency_key', intentKey);

    // Handle file uploads
    const fileInputs = els.dynamicForm?.querySelectorAll('input[type="file"]');
    fileInputs?.forEach(input => {
      if (input.files[0]) formData.append(input.name, input.files[0]);
    });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 45000);
    try {
      const res = await fetch(endpoint('storeUrl', '/ads/store'), {
        method: 'POST',
        headers: {
          'X-CSRF-Token': WIZARD.csrf,
          'Accept': 'application/json',
          'X-Idempotency-Key': intentKey,
        },
        body: formData,
        signal: controller.signal,
      });
      const raw = await res.text();
      let json = {};
      try { json = raw ? JSON.parse(raw) : {}; } catch (_) {
        throw new Error('پاسخ سرور قابل خواندن نیست. لطفاً دوباره تلاش کنید.');
      }

      if (res.ok && json.success) {
        // S20: intent مصرف شد — چرخش نانس تا کمپین بعدیِ (احتمالاً مشابه) کلید تازه بگیرد
        rotateIntentKey();
        showSuccess(json.ad_id);
      } else {
        // خطای منطقی سرور (اعتبارسنجی/موجودی): کلید حفظ می‌شود تا retry همان
        // فرمان با همان کلید بیاید؛ ویرایش فرم به‌طور خودکار کلید جدید می‌سازد.
        showToast('error', json.message || 'خطا در ثبت تبلیغ');
        resetSubmitButton();
      }
    } catch (err) {
      // timeout/شبکه: پاسخ گم شده ولی سرور ممکن است commit کرده باشد — کلید
      // عمداً حفظ می‌شود تا retry بعدی با همان کلید بیاید و سرور به‌جای ساخت
      // کمپین دوم، همان نتیجهٔ اول را replay کند (S20).
      const msg = err && err.name === 'AbortError'
        ? 'زمان پاسخ سرور طولانی شد. لطفاً وضعیت آگهی‌های من را بررسی کنید یا دوباره تلاش کنید.'
        : (err.message || 'خطای شبکه در ارسال اطلاعات');
      showToast('error', msg);
      resetSubmitButton();
    } finally {
      clearTimeout(timeout);
      setLoading(false);
    }
  }

  function resetSubmitButton() {
    if (!els.btnSubmit) return;
    els.btnSubmit.disabled = false;
    els.btnSubmit.innerHTML = '<span class="material-icons icon-sm">check_circle</span> تأیید نهایی و ثبت';
  }

  function showSuccess(adId) {
    [els.step1, els.step2, els.step3, els.step4].forEach(el => {
      if (el) el.classList.remove('active');
    });
    if (els.success) els.success.classList.add('show');
    if (els.stepper) els.stepper.classList.add('d-none');
    document.getElementById('wizardActions')?.classList.add('d-none');
    if (els.btnSubmit) {
      els.btnSubmit.disabled = false;
      els.btnSubmit.innerHTML = '<span class="material-icons icon-sm">check_circle</span> ثبت شد';
    }

    // Auto-redirect to ad list after 2.5s
    setTimeout(() => {
      window.location.href = endpoint('indexUrl', '/ads');
    }, 2500);
  }

  // ── Utilities ──────────────────────────────────────────────────────

  function collectFormData() {
    const data = { ad_type: WIZARD.selectedType };
    const inputs = els.dynamicForm?.querySelectorAll('input, select, textarea');
    inputs?.forEach(input => {
      if (input.type === 'file') return;
      data[input.name] = input.value;
    });
    // 🛡️ FIX-COUPON-ADS-CAMPAIGN: فقط کدِ اعمال‌شده همراه ثبت نهایی می‌رود؛
    // مبلغ تخفیف هرگز از کلاینت پذیرفته نمی‌شود (سرور دوباره محاسبه می‌کند)
    if (WIZARD.coupon.applied && WIZARD.coupon.code) {
      data.coupon_code = WIZARD.coupon.code;
    }
    // R15 راند ۸۸: توکن اعتبارسنجی (از پیش‌نمایش) نیز همراه ثبت نهایی ارسال
    // می‌شود تا در مرحله‌ی apply_coupon سمت سرور مصرف شود؛ سرور در نبودِ توکن
    // از توکن تازه‌ی خودش استفاده می‌کند (fallback).
    if (WIZARD.coupon.applied && WIZARD.coupon.token) {
      data.coupon_token = WIZARD.coupon.token;
    }
    return data;
  }

  function resetCouponState() {
    WIZARD.coupon = { applied: false, code: '', preview: null, token: '' };
    if (els.couponInput) { els.couponInput.value = ''; els.couponInput.disabled = false; }
    els.btnApplyCoupon?.classList.remove('d-none');
    els.btnRemoveCoupon?.classList.add('d-none');
    setCouponFeedback('', '');
  }

  function isBudgetField(name) {
    return ['price_per_task', 'total_count', 'budget', 'min_payout', 'max_payout', 'quantity'].includes(name);
  }

  function fmtNumber(n) {
    return new Intl.NumberFormat('fa-IR').format(Math.round(n));
  }

  function showToast(type, message) {
    if (typeof Notyf !== 'undefined') {
      const notyf = new Notyf({ duration: 4000, position: { x: 'center', y: 'top' } });
      notyf[type === 'success' ? 'success' : 'error'](message);
    } else {
      alert(message);
    }
  }

  function setLoading(active) {
    if (els.loadingOverlay) {
      els.loadingOverlay.classList.toggle('show', active);
    }
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function debounce(fn, ms) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), ms);
    };
  }

})();

