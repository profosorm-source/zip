(function () {
    'use strict';

    // 🛡️ FIX-A24-06: اسکریپت ویرایش محتوا از ویو (inline) به این فایل منتقل شد —
    // هم‌الگوی usercontentcreate.js. نسخهٔ قبلی این فایل یتیم بود (صفر ارجاع،
    // شناسه‌های کهنهٔ updateBtn/descCount) و هم‌زمان کپی inline در edit.php
    // زندگی می‌کرد؛ اکنون یک منبع واحد با شناسه‌های واقعی فرم.
    // 🛡️ FIX-A24-05: پیام خطا بدون HTML خام ساخته می‌شود — هر جزء «جداگانه»
    // escape و سپس با <br> join می‌شود (قبلاً join('<br>') قبل از esc اجرا
    // می‌شد و «<br>» به‌صورت متن خام در Swal نمایش داده می‌شد).
    // 🛡️ FIX-A24-04: اعتبارسنجی سمت کلاینتِ سازگاری لینک با پلتفرم
    // (هم‌الگوی فرم ثبت — الگوی سمت سرور ContentService::validateVideoUrl).

    var form = document.getElementById('contentEditForm');
    if (!form) return;

    var updateUrl = form.getAttribute('data-update-url') || '';
    var indexUrl = form.getAttribute('data-index-url') || '';
    var csrf = form.getAttribute('data-csrf') || '';

    var saveBtn = document.getElementById('saveBtn');
    var platformSelect = document.getElementById('platform');
    var videoUrlField = document.getElementById('video_url');
    var titleField = document.getElementById('title');
    var descField = document.getElementById('description');
    var titleCount = document.getElementById('title-count');
    var descCount = document.getElementById('desc-count');
    var urlHint = document.getElementById('url-hint');

    var platformLabels = { aparat: 'آپارات', youtube: 'یوتیوب', upload_center: 'آپلود سنتر' };

    var urlPatterns = {
        'aparat': {
            pattern: /^https?:\/\/(www\.)?aparat\.com\/v\//i,
            hint: 'مثال: https://www.aparat.com/v/abcdef'
        },
        'youtube': {
            pattern: /^https?:\/\/(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)/i,
            hint: 'مثال: https://www.youtube.com/watch?v=abcdef یا https://youtu.be/abcdef'
        },
        'upload_center': {
            pattern: /^https?:\/\/.+/i,
            hint: 'لینک کامل ویدیو را از آپلود سنتر کپی کنید.'
        }
    };

    function esc(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    // 🛡️ FIX-A24-05: هر جزء پیام جداگانه escape می‌شود؛ <br> فقط بعد از escape
    // به‌عنوان جداکنندهٔ ایمن در html Swal قرار می‌گیرد.
    function notify(type, parts) {
        var lines = (Array.isArray(parts) ? parts : [parts]).filter(function (p) {
            return p !== '' && p != null;
        });
        var html = lines.map(esc).join('<br>');
        if (typeof window.Swal !== 'undefined') {
            Swal.fire(type === 'error'
                ? { icon: 'error', title: 'خطا', html: html }
                : { icon: 'success', title: 'ثبت شد', html: html });
        } else if (type === 'error') {
            alert(lines.join('\n'));
        }
    }

    function refreshUrlHint() {
        var platform = platformSelect ? platformSelect.value : '';
        if (urlHint && platform && urlPatterns[platform]) {
            urlHint.textContent = urlPatterns[platform].hint;
        }
    }

    if (titleField && titleCount) {
        titleField.addEventListener('input', function () { titleCount.textContent = this.value.length; });
    }
    if (descField && descCount) {
        descField.addEventListener('input', function () { descCount.textContent = this.value.length; });
    }
    if (platformSelect) {
        platformSelect.addEventListener('change', refreshUrlHint);
    }
    refreshUrlHint();

    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        var platform = platformSelect ? platformSelect.value : '';
        var videoUrl = videoUrlField ? videoUrlField.value.trim() : '';

        // 🛡️ FIX-A24-04: لینک باید با پلتفرم انتخابی سازگار باشد (هم‌الگوی ثبت)
        if (platform && urlPatterns[platform] && videoUrl !== '' && !urlPatterns[platform].pattern.test(videoUrl)) {
            notify('error', ['لینک وارد شده مربوط به ' + (platformLabels[platform] || platform) + ' نیست.']);
            return;
        }

        var original = saveBtn ? saveBtn.innerHTML : '';
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> در حال ثبت...';
        }

        var payload = {
            platform: platform,
            category: document.getElementById('category').value,
            video_url: videoUrl,
            title: titleField ? titleField.value.trim() : '',
            description: descField ? descField.value : '',
            _csrf_token: csrf
        };

        try {
            var response = await fetch(updateUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': csrf },
                body: JSON.stringify(payload)
            });
            var result = {};
            try { result = await response.json(); } catch (_) {}
            if (response.ok && result.success) {
                notify('success', result.message || 'ویرایش ثبت شد.');
                window.setTimeout(function () { window.location.href = indexUrl; }, 1200);
            } else {
                // 🛡️ FIX-A24-05: خطاهای اعتبارسنجی به‌صورت فهرستِ escape-شده —
                // هر پیام خودش یک جزء است و هیچ HTML خامی به esc نمی‌رسد
                var errorParts = [result.message || 'ویرایش انجام نشد.'];
                if (result.errors && typeof result.errors === 'object') {
                    Object.keys(result.errors).forEach(function (field) {
                        var messages = result.errors[field];
                        if (Array.isArray(messages)) {
                            messages.forEach(function (m) { errorParts.push(m); });
                        } else if (typeof messages === 'string') {
                            errorParts.push(messages);
                        }
                    });
                }
                notify('error', errorParts);
                if (saveBtn) {
                    saveBtn.disabled = false;
                    saveBtn.innerHTML = original;
                }
            }
        } catch (_) {
            notify('error', 'خطا در ارتباط با سرور.');
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = original;
            }
        }
    });
})();
