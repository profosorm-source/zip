// FIX-R36-W3 (F-A20-03): هندلر copy-code کد تأیید اینفلوئنسر اینجا منتقل شد — فایل
// views/userinfluencermyprofile.js هرگز توسط هیچ ویویی لود نمی‌شد و دکمهٔ data-action="copy-code"
// در user/influencer/my-profile.php:123 مرده بود («No handler registered»). این فایل همان تنها
// اسکریپتی است که my-profile.php لود می‌کند؛ ثبت باید «خارج از گارد #influencerHubِ» پایین انجام
// شود وگرنه در صفحهٔ my-profile (بدون آن ریشه) به no-op می‌رسد. حذف userinfluencermyprofile.js پیشنهاد شد.
window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
  'copy-code': function () {
    const btn = this;
    const code = btn.getAttribute('data-code') || '';
    if (!code) return;
    const original = btn.innerHTML;
    const done = () => {
      btn.innerHTML = '<span class="material-icons icon-sm">check</span>';
      setTimeout(() => { btn.innerHTML = original; }, 1800);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(code).then(done).catch(() => window.prompt('کد تایید را کپی کنید:', code));
    } else {
      window.prompt('کد تایید را کپی کنید:', code);
      done();
    }
  }
});

(function () {
  'use strict';
  const root = document.getElementById('influencerHub');
  if (!root) return;

  let rejectOrderId = null;
  let disputeOrderId = null;

  function csrf() { return document.querySelector('meta[name="csrf-token"]')?.content || window.csrfToken || ''; }
  // 16-W (گزینهٔ ۳): به‌جای تشخیص هاردکد /chortke از pathname — منبع واحد حقیقت
  // window.BASE_URL است که لی‌اوت (user.php) با url() مرکزی تزریق می‌کند.
  function basePath() { return window.BASE_URL || ''; }
  function jsonHeaders() { return { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest' }; }
  function notify(msg, ok) {
    if (window.Notyf) {
      const n = new Notyf({ duration: 3500, position: { x: 'left', y: 'top' }, dismissible: true });
      if (ok && typeof n.success === 'function') n.success(msg);
      else if (!ok && typeof n.error === 'function') n.error(msg);
      else if (typeof n.open === 'function') n.open({ type: ok ? 'success' : 'error', message: msg });
      else alert(msg);
    } else { alert(msg); }
  }
  function postJson(url, body) {
    return fetch(basePath() + url, {
      method: 'POST',
      headers: jsonHeaders(),
      body: JSON.stringify(body || {})
    }).then(r => r.json().catch(() => ({ success: false, message: 'پاسخ سرور قابل خواندن نیست.' })));
  }
  function reloadSoon(section) {
    setTimeout(() => { location.href = root.dataset.base + (section ? '?section=' + section : ''); }, 550);
  }
  function switchTab(name) {
    document.querySelectorAll('[data-inf-panel]').forEach(p => p.classList.toggle('active', p.dataset.infPanel === name));
    document.querySelectorAll('[data-inf-tab]').forEach(t => t.classList.toggle('active', t.dataset.infTab === name));
    if (history.replaceState) history.replaceState(null, '', root.dataset.base + (name === 'overview' ? '' : '?section=' + encodeURIComponent(name)));
  }
  function showModal(id) {
    const el = document.getElementById(id);
    if (!el) return;
    if (window.bootstrap) new bootstrap.Modal(el).show();
  }
  function hideModal(id) {
    const el = document.getElementById(id);
    if (!el || !window.bootstrap) return;
    const instance = bootstrap.Modal.getInstance(el);
    if (instance) instance.hide();
  }
  function respondOrder(id, action, reason) {
    if (!id) return;
    postJson('/influencer/orders/' + id + '/respond', { action: action, reason: reason || '' }).then(d => {
      if (d.success) { notify(d.message || 'عملیات انجام شد.', true); reloadSoon('incoming'); }
      else notify(d.message || 'عملیات انجام نشد.', false);
    }).catch(() => notify('خطا در ارتباط با سرور.', false));
  }

  document.addEventListener('click', function (e) {
    const tab = e.target.closest('[data-inf-tab]');
    if (tab) { switchTab(tab.dataset.infTab); return; }

    const select = e.target.closest('[data-select-influencer]');
    if (select) {
      document.getElementById('hubInfluencerId').value = select.dataset.id;
      document.getElementById('selectedInfluencerText').textContent = 'سفارش برای @' + (select.dataset.username || 'اینفلوئنسر');
      root.dataset.story = select.dataset.story || '0';
      root.dataset.post24 = select.dataset.post24 || '0';
      root.dataset.post48 = select.dataset.post48 || '0';
      root.dataset.post72 = select.dataset.post72 || '0';
      root.dataset.sponsored = select.dataset.sponsored || '0';
      root.dataset.pin = select.dataset.pin || '0';
      root.dataset.forward = select.dataset.forward || '0';
      root.dataset.platform = select.dataset.platform === 'telegram' ? 'telegram' : 'instagram';
      renderOrderTypes();
      // FIX-CY3-A7 (یافتهٔ ۷ بچ CY3): ارز پروفایل اینفلوئنسر — قیمت‌ها و کوپن
      // با ارز خودِ او (پیش‌فرض ریشه = ارز فعال پلتفرم).
      root.dataset.currency = (select.dataset.currency === 'usdt') ? 'usdt' : 'irt';
      updatePrice();
      document.querySelector('.inf-order-box')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    // FIX-X111: انشعاب‌های data-action به قرارداد X106 منتقل شدند (پایین فایل)
  });

  // FIX-X111: مهاجرت دلیگیشن قدیمی به قرارداد X106 (ChortkeActions)
  function respondOrderAction() { respondOrder(this.dataset.orderId, this.dataset.actionType || 'accept'); }
  function promptRejectAction() {
    rejectOrderId = this.dataset.orderId;
    const input = document.getElementById('rejectReason');
    if (input) input.value = '';
    showModal('rejectModal');
  }
  function openProofModalAction() {
    const form = document.getElementById('proofForm');
    const input = document.getElementById('proofOrderId');
    if (form) form.reset();
    if (input) input.value = this.dataset.orderId || '';
    showModal('proofModal');
  }
  function confirmOrderAction() {
    if (!confirm('آیا از انجام صحیح سفارش اطمینان دارید؟ مبلغ از صندوق امانی به اینفلوئنسر پرداخت می‌شود.')) return;
    postJson('/influencer/ads/orders/' + this.dataset.orderId + '/confirm', {}).then(d => {
      if (d.success) { notify(d.message || 'سفارش تأیید شد.', true); reloadSoon('placed'); }
      else notify(d.message || 'تأیید سفارش انجام نشد.', false);
    }).catch(() => notify('خطا در ارتباط با سرور.', false));
  }
  function openDisputeModalAction() {
    disputeOrderId = this.dataset.orderId;
    const reason = document.getElementById('disputeReason');
    if (reason) reason.value = '';
    showModal('disputeModal');
  }
  window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    'respond-order': respondOrderAction,
    'prompt-reject': promptRejectAction,
    'open-proof-modal': openProofModalAction,
    'confirm-order': confirmOrderAction,
    'open-dispute-modal': openDisputeModalAction
  });

  // 🛡️ FIX-F02: ورودی بیرونی (?influencer_id= و dataset) هرگز داخل querySelector
  // ساخته نمی‌شود — مقدار خام با گیومه/براکت SyntaxError می‌داد و بقیهٔ IIFE
  // (هندلرهای سفارش/کوپن/مدرک/اعتراض) هرگز initialize نمی‌شد. تطبیق با مقایسهٔ
  // data-id انجام می‌شود و کل initِ ورودی‌محور در try/catch است تا یک خطا نتواند
  // بقیهٔ هندلرها را بکشد.
  try {
    const init = root.dataset.initialSection || 'overview';
    switchTab(init);
    const requestedInfluencer = new URLSearchParams(location.search).get('influencer_id');
    if (requestedInfluencer) {
      let target = null;
      document.querySelectorAll('[data-select-influencer]').forEach(function (card) {
        if (!target && card.dataset.id === requestedInfluencer) target = card;
      });
      if (target) setTimeout(() => target.click(), 150);
    }
  } catch (initErr) {
    console.error('influencer hub init failed:', initErr);
  }

  // ═══ 🛡️ FIX-COUPON-STORY-ORDER: پیش‌نمایش کد تخفیف (سمت کلاینت) ═══
  // فقط پیش‌نمایش است؛ سرور در InfluencerCommandService::createOrder دوباره
  // اعتبارسنجی می‌کند و تخفیف را به سقف کارمزد خدمات محدود می‌کند.
  // اینجا همان سقف را برای نمایش صادقانه اعمال می‌کنیم (data-fee-percent).
  // R15 راند ۸۸: توکن اعتبارسنجی (validation_token از /coupons/validate) هم در
  // وضعیت نگه داشته می‌شود و همراه ثبت سفارش به‌عنوان coupon_token ارسال می‌شود
  // تا سمت سرور در redeem مصرف شود (single-use binding بین اعتبارسنجی و برداشت).
  var couponState = { applied: false, code: '', discount: 0, final: 0, token: '' };
  var couponInput = document.getElementById('hubCouponCode');
  var couponApplyBtn = document.getElementById('hubCouponApplyBtn');
  var couponResult = document.getElementById('hubCouponResult');

  function currentPriceValue() {
    const type = document.getElementById('hubOrderType')?.value || 'story';
    const dur = document.getElementById('hubDuration')?.value || '24';
    if (type === 'story') return parseFloat(root.dataset.story || '0') || 0;
    if (type === 'sponsored_post') return parseFloat(root.dataset.sponsored || '0') || 0;
    if (type === 'pin') return parseFloat(root.dataset.pin || '0') || 0;
    if (type === 'forward') return parseFloat(root.dataset.forward || '0') || 0;
    if (dur === '48') return parseFloat(root.dataset.post48 || '0') || 0;
    if (dur === '72') return parseFloat(root.dataset.post72 || '0') || 0;
    return parseFloat(root.dataset.post24 || '0') || 0;
  }

  function feeCapFor(price) {
    const feePercent = parseFloat(root.dataset.feePercent || '15') || 0;
    return Math.max(0, price * feePercent / 100);
  }

  function faNum(n) { return Number(n || 0).toLocaleString('fa-IR'); }

  // FIX-CY3-A7 (یافتهٔ ۷ بچ CY3): برچسب ارز از ارزِ اینفلوئنسرِ انتخاب‌شده —
  // قبلاً «تومان» هاردکد بود و currency:'irt' به اعتبارسنجی کوپن می‌رفت.
  function currentCurrency() { return root.dataset.currency === 'usdt' ? 'usdt' : 'irt'; }
  function currencyLabelJs(cur) { return cur === 'usdt' ? 'تتر' : 'تومان'; }

  function renderCouponPreview() {
    const price = currentPriceValue();
    const cur = currencyLabelJs(currentCurrency());
    const discountRow = document.getElementById('hubDiscountRow');
    const finalRow = document.getElementById('hubFinalRow');
    if (!couponState.applied || !(discountRow && finalRow)) return;
    // با تغییر نوع/مدت/اینفلوئنسر، سقف کارمزد عوض می‌شود → پیش‌نمایش را به‌روز کن
    let d = Math.min(couponState.discount, feeCapFor(price));
    if (d < 0) d = 0;
    couponState.discount = d;
    couponState.final = Math.max(0, price - d);
    document.getElementById('hubDiscountPreview').textContent = faNum(d) + ' ' + cur;
    document.getElementById('hubFinalPreview').textContent = faNum(couponState.final) + ' ' + cur;
    discountRow.classList.remove('d-none');
    finalRow.classList.remove('d-none');
  }

  function clearCouponUI(keepInputValue) {
    couponState = { applied: false, code: '', discount: 0, final: 0, token: '' };
    document.getElementById('hubDiscountRow')?.classList.add('d-none');
    document.getElementById('hubFinalRow')?.classList.add('d-none');
    if (couponResult) { couponResult.classList.add('d-none'); couponResult.textContent = ''; }
    if (!keepInputValue && couponInput) couponInput.value = '';
  }

  if (couponApplyBtn && couponInput) {
    couponApplyBtn.addEventListener('click', function () {
      const code = (couponInput.value || '').trim();
      const price = currentPriceValue();
      if (!code) { clearCouponUI(false); return; }
      if (!document.getElementById('hubInfluencerId').value) { notify('ابتدا یک اینفلوئنسر انتخاب کنید.', false); return; }
      if (!price) { notify('ابتدا نوع تبلیغ و مدت را انتخاب کنید.', false); return; }
      couponApplyBtn.disabled = true;
      postJson('/coupons/validate', { code: code, amount: String(price), currency: currentCurrency(), applicable_to: 'story_order' }).then(d => {
        couponApplyBtn.disabled = false;
        if (d.success && d.data) {
          const raw = parseFloat(d.data.discount_amount) || 0;
          const cap = feeCapFor(price);
          let eff = Math.min(raw, cap);
          if (eff < 0) eff = 0;
          couponState = { applied: true, code: code.toUpperCase(), discount: eff, final: Math.max(0, price - eff), token: String(d.data.validation_token || '') };
          const cur = currencyLabelJs(currentCurrency());
          if (couponResult) {
            const capped = raw > eff + 0.0001;
            couponResult.textContent = capped
              ? 'کد تخفیف معتبر است؛ تخفیف به سقف کارمزد خدمات محدود شد: ' + faNum(eff) + ' ' + cur
              : 'کد تخفیف اعمال شد. تخفیف: ' + faNum(eff) + ' ' + cur;
            couponResult.classList.remove('d-none');
          }
          renderCouponPreview();
          notify(d.message || 'کد تخفیف اعمال شد.', true);
        } else {
          clearCouponUI(false);
          if (couponResult) {
            couponResult.textContent = d.message || 'کد تخفیف معتبر نیست.';
            couponResult.classList.remove('d-none');
          }
          notify(d.message || 'کد تخفیف معتبر نیست.', false);
        }
      }).catch(() => {
        couponApplyBtn.disabled = false;
        clearCouponUI(true);
        notify('خطا در بررسی کد تخفیف.', false);
      });
    });
  }

  // T25-07: نوع‌های تبلیغ بر اساس پلتفرم پیج انتخاب‌شده
  function renderOrderTypes() {
    const sel = document.getElementById('hubOrderType');
    if (!sel) return;
    const tg = root.dataset.platform === 'telegram';
    const opts = tg
      ? [['sponsored_post', 'پست اسپانسری'], ['pin', 'پین پیام'], ['forward', 'فوروارد پیام']]
      : [['story', 'استوری'], ['post', 'پست']];
    sel.innerHTML = '';
    opts.forEach(function (o) { const el = document.createElement('option'); el.value = o[0]; el.textContent = o[1]; sel.appendChild(el); });
  }

  function updatePrice() {
    const type = document.getElementById('hubOrderType')?.value || 'story';
    const dur = document.getElementById('hubDuration')?.value || '24';
    let price = '0';
    if (type === 'story') price = root.dataset.story || '0';
    else if (type === 'sponsored_post') price = root.dataset.sponsored || '0';
    else if (type === 'pin') price = root.dataset.pin || '0';
    else if (type === 'forward') price = root.dataset.forward || '0';
    else price = dur === '48' ? (root.dataset.post48 || '0') : (dur === '72' ? (root.dataset.post72 || '0') : (root.dataset.post24 || '0'));
    document.getElementById('hubPricePreview').textContent = faNum(price) + ' ' + currencyLabelJs(currentCurrency());
    renderCouponPreview();
  }
  document.getElementById('hubOrderType')?.addEventListener('change', updatePrice);
  document.getElementById('hubDuration')?.addEventListener('change', updatePrice);

  document.getElementById('hubOrderForm')?.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!document.getElementById('hubInfluencerId').value) { notify('ابتدا یک اینفلوئنسر انتخاب کنید.', false); return; }
    // 🛡️ FIX-COUPON-STORY-ORDER: اگر کدی تایپ شده ولی «اعمال» زده نشده یا ناموفق
    // بوده، قبل از ارسال پاکش می‌کنیم تا سفارش به‌خاطر کد بررسی‌نشده رد نشود.
    if (couponInput && !couponState.applied && (couponInput.value || '').trim() !== '') {
      couponInput.value = '';
    }
    const btn = this.querySelector('button[type="submit"]');
    const old = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = 'در حال ثبت...';
    // R15 راند ۸۸: توکن اعتبارسنجی کوپن (در صورت اعمال موفق) به‌عنوان فیلد
    // coupon_token به payload سفارش افزوده می‌شود؛ سرور فقط در صورت هم‌خوانی
    // مبالغ، آن را در redeem مصرف می‌کند (در غیر این صورت توکن تازهٔ خودش).
    const orderFormData = new FormData(this);
    if (couponState.applied && couponState.token) {
      orderFormData.append('coupon_token', couponState.token);
    }
    fetch(root.dataset.storeUrl, { method: 'POST', headers: { 'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest' }, body: orderFormData })
      .then(r => r.json()).then(d => {
        if (d.success) { notify(d.message || 'سفارش ثبت شد.', true); setTimeout(() => location.href = d.redirect || (root.dataset.base + '?section=placed'), 700); }
        else { notify(d.message || 'ثبت سفارش انجام نشد.', false); btn.disabled = false; btn.innerHTML = old; }
      }).catch(() => { notify('خطا در ارتباط با سرور.', false); btn.disabled = false; btn.innerHTML = old; });
  });

  document.getElementById('rejectConfirmBtn')?.addEventListener('click', function () {
    const reason = document.getElementById('rejectReason')?.value || '';
    hideModal('rejectModal');
    respondOrder(rejectOrderId, 'reject', reason);
  });

  document.getElementById('proofForm')?.addEventListener('submit', function (e) {
    e.preventDefault();
    const id = document.getElementById('proofOrderId')?.value;
    if (!id) return;
    const btn = document.getElementById('proofSubmitBtn');
    const old = btn ? btn.innerHTML : '';
    if (btn) { btn.disabled = true; btn.innerHTML = 'در حال ارسال...'; }
    fetch(basePath() + '/influencer/orders/' + id + '/proof', {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest' },
      body: new FormData(this)
    }).then(r => r.json()).then(d => {
      if (d.success) { notify(d.message || 'مدرک ثبت شد.', true); reloadSoon('incoming'); }
      else { notify(d.message || 'ثبت مدرک انجام نشد.', false); if (btn) { btn.disabled = false; btn.innerHTML = old; } }
    }).catch(() => { notify('خطا در ارتباط با سرور.', false); if (btn) { btn.disabled = false; btn.innerHTML = old; } });
  });

  document.getElementById('disputeSubmitBtn')?.addEventListener('click', function () {
    const reason = (document.getElementById('disputeReason')?.value || '').trim();
    if (!reason) { notify('دلیل اعتراض الزامی است.', false); return; }
    const btn = this;
    const old = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = 'در حال ثبت...';
    postJson('/influencer/ads/orders/' + disputeOrderId + '/dispute', { reason: reason }).then(d => {
      if (d.success) { notify(d.message || 'اعتراض ثبت شد.', true); reloadSoon('disputes'); }
      else { notify(d.message || 'ثبت اعتراض انجام نشد.', false); btn.disabled = false; btn.innerHTML = old; }
    }).catch(() => { notify('خطا در ارتباط با سرور.', false); btn.disabled = false; btn.innerHTML = old; });
  });
})();

// T25-07: فرم ثبت پیج — فیلدهای تلگرام (بازدید + سه قیمت) یا اینستاگرام (چهار قیمت) بر اساس پلتفرم
(function () {
  const sel = document.querySelector('select[name="platform"]');
  if (!sel) return;
  const igNames = ['story_price_24h', 'post_price_24h', 'post_price_48h', 'post_price_72h'];
  function sync() {
    const tg = sel.value === 'telegram';
    document.querySelectorAll('[data-tg-only]').forEach(function (el) { el.style.display = tg ? '' : 'none'; });
    igNames.forEach(function (n) {
      const input = document.querySelector('input[name="' + n + '"]');
      if (input && input.closest('label')) input.closest('label').style.display = tg ? 'none' : '';
    });
  }
  sel.addEventListener('change', sync);
  sync();
})();
