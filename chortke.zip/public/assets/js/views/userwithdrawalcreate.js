(function () {
  'use strict';

  const root = document.getElementById('financeWithdrawRoot');
  if (!root) return;

  const config = {
    currency: (root.dataset.currency || 'IRT').toUpperCase(),
    min: parseFloat(root.dataset.min || '0'),
    max: parseFloat(root.dataset.max || '0'),
    fee: parseFloat(root.dataset.fee || '0'),
    // FIX-S34-B14-F16 (گزارش بخش ۱۴): کارمزد ثابت سرور — پیش‌نمایش خالص قبلاً فقط
    // درصد را حساب می‌کرد و با محاسبهٔ واقعی سرویس (درصد + ثابت با سقف مبلغ) نمی‌خواند.
    feeFixed: parseFloat(root.dataset.feeFixed || '0'),
    action: root.dataset.formAction || root.dataset.action || '',
    redirect: root.dataset.redirect || '/withdrawals',
    limitsUrl: root.dataset.limitsUrl || '',
    csrf: root.dataset.csrf || document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
  };

  const form = document.getElementById('withdrawalForm');
  const amountInput = document.getElementById('amount');
  const receiveAmount = document.getElementById('receive_amount');
  const confirmInput = document.getElementById('confirm_withdrawal');
  const submitBtn = document.getElementById('submit_btn');
  let notifier = null;

  function notify(type, message) {
    if (!notifier && typeof window.Notyf !== 'undefined') {
      notifier = new window.Notyf({ duration: 4500, position: { x: 'left', y: 'top' }, dismissible: true });
    }
    if (notifier && typeof notifier[type] === 'function') {
      notifier[type](message);
      return;
    }
    const toast = document.createElement('div');
    toast.textContent = message;
    Object.assign(toast.style, {
      position: 'fixed', left: '24px', top: '78px', zIndex: '10050', maxWidth: '360px',
      padding: '12px 16px', borderRadius: '12px', background: type === 'error' ? 'rgba(246,70,93,.96)' : 'rgba(30,217,168,.96)',
      color: '#fff', fontFamily: 'Vazirmatn, Tahoma, sans-serif', fontSize: '13px', fontWeight: '800', lineHeight: '1.8',
      boxShadow: '0 14px 34px rgba(0,0,0,.28)'
    });
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4500);
  }

  function formatAmount(value) {
    return config.currency === 'USDT'
      ? (value || 0).toLocaleString('en-US', { maximumFractionDigits: 4 })
      : Math.round(value || 0).toLocaleString('en-US');
  }

  function updateReceiveAmount() {
    // FIX-R36-W3 (F-A20-10): نرمال‌سازی ارقام فارسی/عربی + جداکنندهٔ هزارگان (توابع مرجع ux-extras)
    const raw = window.chortkeNormalizeDigits ? window.chortkeNormalizeDigits(amountInput?.value || '0') : String(amountInput?.value || '0');
    const amount = parseFloat(raw) || 0;
    // FIX-S34-B14-F16: همان فرمول سرور — کارمزد = درصد + ثابت، با سقفِ مبلغ خودش
    // (الگوی calculateFee در WithdrawalAdminService؛ FIX-R19-A3-10).
    let fee = amount * (config.fee / 100) + config.feeFixed;
    if (fee > amount) fee = amount;
    const net = Math.max(amount - fee, 0);
    if (receiveAmount) receiveAmount.textContent = formatAmount(net);
  }

  function setAmount(value) {
    if (!amountInput) return;
    amountInput.value = String(value || 0);
    amountInput.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // FIX-R36-W3 (F-A20-12): الگوریتم یکنواخت — پیاده‌سازی مرجع در ux-extras.js (window.chortkeIdempotencyKey /
  // window.chortkeDeviceFingerprint). بدنهٔ محلی فقط fallbackِ نبودِ فایل مشترک است تا فرم در حالت degraded نشکند.
  function generateIdempotencyKey() {
    if (window.chortkeIdempotencyKey) return window.chortkeIdempotencyKey('WTH_');
    return 'WTH_' + Date.now() + '_' + Math.random().toString(16).slice(2);
  }

  function generateDeviceFingerprint() {
    if (window.chortkeDeviceFingerprint) return window.chortkeDeviceFingerprint();
    const parts = [navigator.userAgent, navigator.language, screen.width + 'x' + screen.height + 'x' + screen.colorDepth, new Date().getTimezoneOffset()];
    let hash = 0;
    const str = parts.join('|');
    for (let i = 0; i < str.length; i++) hash = ((hash << 5) - hash) + str.charCodeAt(i) | 0;
    return Math.abs(hash).toString(16).padStart(16, '0').slice(0, 16);
  }

  // FIX-S34-B14-F11 (گزارش بخش ۱۴): کلید idempotency شناسهٔ «فرمان» است نه «کلیک» —
  // قبلاً هر submit کلید جدید می‌ساخت؛ اگر سرور فرمان را commit می‌کرد و پاسخ گم
  // می‌شد، retry کلاینت به‌عنوان فرمان جدید می‌رفت (پاسخ موفق اولیه replay نمی‌شد).
  // اکنون: کلید تا تغییرِ ورودی‌های تعیین‌کنندهٔ نیت (مبلغ/مقصد/ارز/توضیح) ثابت می‌ماند؛
  // تغییر نیت = فرمان جدید با کلید جدید (رفتار X156 حفظ می‌شود).
  let currentIntentKey = null;
  function getIntentKey() {
    if (currentIntentKey === null) currentIntentKey = generateIdempotencyKey();
    return currentIntentKey;
  }
  ['amount', 'card_id', 'network', 'wallet_address', 'user_description'].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener('input', function () { currentIntentKey = null; });
  });

  async function loadWithdrawalLimits() {
    if (!config.limitsUrl) return;
    try {
      const r = await fetch(config.limitsUrl + '?currency=' + encodeURIComponent(config.currency), { headers: { Accept: 'application/json' } });
      const data = await r.json();
      const limits = data.limits;
      if (!limits) return;
      const box = document.getElementById('withdrawalLimitsBox');
      const label = document.getElementById('limitsProfileLabel');
      const detail = document.getElementById('limitsDetail');
      if (!box || !label || !detail) return;
      label.textContent = 'سطح برداشت شما: ' + (limits.profile_label || 'استاندارد');
      // FIX-R36-W3 (F-A20-06): بج‌ها با createElement/textContent ساخته می‌شوند — مقادیر سرورِ
      // used_today/daily_count هرگز بدون escape به innerHTML نمی‌روند (الگوی showToast خودِ user/dashboard.js).
      // FIX-S34-B14-F17: واحدها با قرارداد جدید DTO — used_today «مبلغ» است و با واحد
      // نمایش داده می‌شود؛ daily_count شمارندهٔ تعداد درخواست‌هاست (قبلاً مبلغ به شکل
      // تعداد نشان داده می‌شد و min/max به fallback می‌رفتند).
      var wdUnit = (limits.currency === 'usdt' || limits.currency === 'USDT') ? 'USDT' : 'تومان';
      var usedMoney = Number(limits.used_today || 0).toLocaleString('en-US', { maximumFractionDigits: 4 });
      detail.innerHTML = '';
      var badgeToday = document.createElement('span');
      badgeToday.className = 'fin-badge fin-badge--info';
      badgeToday.textContent = 'مجموع برداشت امروز: ' + usedMoney + ' ' + wdUnit + ' (' + (limits.daily_count || 0) + ' درخواست)';
      var badgeMin = document.createElement('span');
      badgeMin.className = 'fin-badge fin-badge--warning';
      badgeMin.textContent = 'حداقل: ' + Number(limits.min_amount || config.min).toLocaleString('en-US');
      var badgeMax = document.createElement('span');
      badgeMax.className = 'fin-badge fin-badge--success';
      badgeMax.textContent = 'حداکثر باقی‌ماندهٔ امروز: ' + Number(limits.max_amount || config.max).toLocaleString('en-US', { maximumFractionDigits: 4 });
      detail.appendChild(badgeToday);
      detail.appendChild(document.createTextNode(' '));
      detail.appendChild(badgeMin);
      detail.appendChild(document.createTextNode(' '));
      detail.appendChild(badgeMax);
      box.style.display = 'flex';
    } catch (_) {}
  }

  document.getElementById('card_id')?.addEventListener('change', function () {
    const selectedOption = this.options[this.selectedIndex];
    const cardInfo = document.getElementById('card_info');
    const cardDetails = document.getElementById('card_details');
    if (this.value && cardInfo && cardDetails) {
      // R31 XSS: مقدار از textContent می‌آید، پس تخصیص textContent امن‌تر و هم‌رفتار است
      cardDetails.textContent = selectedOption.textContent.trim();
      cardInfo.style.display = 'flex';
    } else if (cardInfo) {
      cardInfo.style.display = 'none';
    }
  });

  amountInput?.addEventListener('input', updateReceiveAmount);
  confirmInput?.addEventListener('change', function () { if (submitBtn) submitBtn.disabled = !this.checked; });

  // FIX-X111: مهاجرت دلیگیشن قدیمی به قرارداد X106 (ChortkeActions)
  window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    'set-quick-amount': function () { setAmount(parseFloat(this.dataset.value || '0')); },
    'set-max-amount': function () { setAmount(config.max); }
  });

  form?.addEventListener('submit', async function (event) {
    event.preventDefault();
    // FIX-R36-W3 (F-A20-10): «۱۰,۰۰۰» فارسی دیگر NaN نمی‌شود و خطای گمراه‌کنندهٔ «کمتر از حداقل» نمی‌دهد
    const amountRaw = window.chortkeNormalizeDigits ? window.chortkeNormalizeDigits(amountInput?.value || '0') : String(amountInput?.value || '0');
    const amount = parseFloat(amountRaw) || 0;

    if (amount < config.min) return notify('error', 'مبلغ برداشت کمتر از حداقل مجاز است.');
    if (amount > config.max) return notify('error', 'موجودی کافی نیست.');
    if (!confirmInput?.checked) return notify('error', 'برای ادامه باید تأیید نهایی را فعال کنید.');

    const network = document.getElementById('network')?.value || '';
    const walletAddress = document.getElementById('wallet_address')?.value || '';
    if (config.currency === 'USDT') {
      if (!network) return notify('error', 'شبکه انتقال را انتخاب کنید.');
      if (!walletAddress) return notify('error', 'آدرس کیف پول را وارد کنید.');
      if (network === 'BNB20' && !walletAddress.startsWith('0x')) return notify('error', 'آدرس BNB20 باید با 0x شروع شود.');
      if (network === 'TRC20' && !walletAddress.startsWith('T')) return notify('error', 'آدرس TRC20 باید با T شروع شود.');
    }

    document.getElementById('idempotencyKey').value = getIntentKey();
    document.getElementById('deviceFingerprint').value = generateDeviceFingerprint();
    // FIX-OP3: فیلد مردهٔ request_timestamp حذف شد — هیچ مسیر backend آن را
    // نمی‌خواند و ارسال timestamp سمت‌کلاینت فقط سطح حملهٔ گمراه‌کننده می‌سازد.

    if (window.Swal) {
      const result = await window.Swal.fire({ title: 'ثبت درخواست برداشت؟', text: 'پس از ثبت، مبلغ تا زمان بررسی قفل می‌شود.', icon: 'warning', showCancelButton: true, confirmButtonText: 'تأیید و ثبت', cancelButtonText: 'انصراف', confirmButtonColor: '#FCD535' }); // FIX-R36-W3 (F-A20-13): طلایی کاننیکال
      if (!result.isConfirmed) return;
    }

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.classList.add('loading');
    }

    try {
      const formData = new FormData(form);
      const response = await fetch(config.action, { method: 'POST', credentials: 'same-origin', headers: { Accept: 'application/json', 'X-CSRF-Token': config.csrf }, body: formData });
      const data = await response.json().catch(() => ({}));
      if (response.ok && data.success) {
        notify('success', data.message || 'درخواست برداشت با موفقیت ثبت شد.');
        setTimeout(() => { window.location.href = config.redirect; }, 900);
      } else {
        notify('error', data.message || 'ثبت درخواست برداشت انجام نشد.');
      }
    } catch (_) {
      notify('error', 'خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = !confirmInput?.checked;
        submitBtn.classList.remove('loading');
      }
    }
  });

  updateReceiveAmount();
  loadWithdrawalLimits();
})();
