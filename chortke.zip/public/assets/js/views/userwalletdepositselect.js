// 🛡️ FIX-F04 (مالکیت یگانهٔ کلید idempotency): این فایل تنها تعریف‌کنندهٔ توابع
// مودال واریز است. پیش‌تر showOnlinePaymentModal اینجا با Math.random بازنویسی
// می‌شد در حالی که ویو (views/user/wallet/index.php) نسخهٔ امن crypto را تعریف
// می‌کرد — last-writer-wins باعث می‌شد کلید ضعیف ۹ کاراکتری جایگزین کلید
// ۳۲ کاراکتری hex (هم‌قالب با bin2hex(random_bytes(16)) سمت سرور) شود.
// اکنون فقط همین نسخهٔ crypto-based وجود دارد و قرارداد نام توابع برای همهٔ
// فراخوان‌ها (data-action و ChortkeActions در ویو) دست‌نخورده مانده است.
(function () {
  'use strict';

  window.showOnlinePaymentModal = function () {
    const m = document.getElementById('onlinePaymentModal');
    if (m) {
      m.style.setProperty('display', 'flex', 'important');
      m.classList.add('show');
      const ik = document.getElementById('payment_idempotency_key');
      if (ik) {
        /* FIX-R19-A9-4: کلید idempotency با crypto.getRandomValues ساخته می‌شود —
           16 بایت = ۳۲ کاراکتر hex، دقیقاً هم‌قالب/هم‌طول کلید سمت سرور؛
           الگوی قبلی Math.random().toString(36).substr(2,9) entropy ضعیف داشت. */
        const idemBytes = new Uint8Array(16);
        crypto.getRandomValues(idemBytes);
        ik.value = Array.from(idemBytes, b => b.toString(16).padStart(2, '0')).join('');
      }
    }
  };

  window.closeOnlinePaymentModal = function () {
    const m = document.getElementById('onlinePaymentModal');
    if (m) {
      m.style.setProperty('display', 'none', 'important');
      m.classList.remove('show');
    }
  };

  // FIX-X111: نسخهٔ بهبودیافتهٔ setAmount ویو (جستجوی input داخل مودال + dispatch
  // ایونت input) — پیش‌تر با تعریف سادهٔ همین فایل بازنویسی می‌شد؛ اکنون ادغام شده.
  window.setAmount = function (value) {
    const modal = document.getElementById('onlinePaymentModal');
    const input = modal ? modal.querySelector('input[name="amount"]') : document.getElementById('amount');
    if (input) { input.value = value; input.dispatchEvent(new Event('input', { bubbles: true })); }
  };

  document.addEventListener('click', function (event) {
    const modal = document.getElementById('onlinePaymentModal');
    if (modal && event.target === modal) {
      window.closeOnlinePaymentModal();
    }
  });
})();
