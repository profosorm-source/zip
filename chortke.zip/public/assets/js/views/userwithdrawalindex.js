/**
 * FIX-X6 (Task 11) — هندلر لغو درخواست برداشت از UI کاربر
 * مسیر بک‌اند از قبل موجود بود (POST /withdrawals/{id}/cancel) ولی هیچ
 * دکمه‌ای در هاب برداشت به آن وصل نبود؛ وجه قفل‌شدهٔ برداشت‌های pending
 * تا رسیدگی ادمین (تأیید/رد) غیرقابل آزادسازی بود.
 *
 * جریان: کلیک «لغو درخواست» → تأیید Swal → POST JSON → اعلان → reload.
 */
(function () {
  'use strict';

  function getCsrf() {
    var meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.getAttribute('content')) return meta.getAttribute('content');
    if (window.csrfToken) return window.csrfToken;
    var input = document.querySelector('input[name="_csrf_token"]');
    return input ? input.value : '';
  }

  function notify(type, message) {
    if (typeof window.Notyf !== 'undefined') {
      var notifier = new window.Notyf({ duration: 4500, position: { x: 'left', y: 'top' }, dismissible: true });
      if (typeof notifier[type] === 'function') { notifier[type](message); return; }
    }
    if (typeof window.notyf !== 'undefined' && window.notyf && typeof window.notyf[type] === 'function') {
      window.notyf[type](message);
      return;
    }
    if (typeof Swal !== 'undefined') {
      Swal.fire({ title: type === 'success' ? 'انجام شد' : 'خطا', text: message, icon: type === 'success' ? 'success' : 'error', confirmButtonText: 'متوجه شدم' });
      return;
    }
    // آخرین fallback: پیام inline بالای جدول
    var alertBox = document.createElement('div');
    alertBox.textContent = message;
    Object.assign(alertBox.style, {
      position: 'fixed', left: '24px', top: '78px', zIndex: '10050', maxWidth: '380px',
      padding: '12px 16px', borderRadius: '12px', background: type === 'error' ? 'rgba(246,70,93,.96)' : 'rgba(30,217,168,.96)',
      color: '#fff', fontFamily: 'Vazirmatn, Tahoma, sans-serif', fontSize: '13px', fontWeight: '800',
      boxShadow: '0 14px 34px rgba(0,0,0,.28)'
    });
    document.body.appendChild(alertBox);
    setTimeout(function () { alertBox.remove(); }, 4500);
  }

  function confirmCancel(amount, currency) {
    // FIX-S34-B14-F24 (گزارش بخش ۱۴): واحد و واحد پول از دادهٔ خودِ رکورد برداشت
    // می‌آید — قبلاً «تومان» hard-code شده بود و برای برداشت USDT پیام تأیید
    // واحد واقعی را بازتاب نمی‌داد (دقت هم روی سرور با data-amount اصلاح شد).
    var unit = (currency === 'USDT') ? 'USDT' : 'تومان';
    if (typeof Swal === 'undefined') {
      return Promise.resolve(window.confirm('لغو درخواست برداشت' + (amount ? ' ' + amount + ' ' + unit + 'ی' : '') + '؟ کل وجه قفل‌شده به موجودی شما بازمی‌گردد.'));
    }
    return Swal.fire({
      title: 'لغو درخواست برداشت؟',
      text: amount ? ('مبلغ ' + amount + ' ' + unit + ' قفل‌شده آزاد و به موجودی قابل برداشت شما بازمی‌گردد.') : 'کل وجه قفل‌شده به موجودی شما بازمی‌گردد.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'بله، لغو کن',
      cancelButtonText: 'انصراف',
      confirmButtonColor: '#F6465D'
    }).then(function (r) { return !!r.isConfirmed; });
  }

  function cancelWithdrawal(btn) {
    var id = btn.dataset.withdrawalId || btn.getAttribute('data-withdrawal-id');
    var amount = btn.dataset.amount || '';
    // FIX-S34-B14-F24: واحد پولی از خودِ دکمهٔ ردیف (data-currency) خوانده می‌شود.
    var currency = btn.dataset.currency || btn.getAttribute('data-currency') || '';
    if (!id) return;

    confirmCancel(amount, currency).then(function (ok) {
      if (!ok) return;

      btn.disabled = true;
      var originalHtml = btn.innerHTML;
      btn.innerHTML = '<i class="material-icons" style="font-size:15px;vertical-align:middle;">hourglass_empty</i> در حال لغو...';

      fetch((window.BASE_URL || '') + '/withdrawals/' + encodeURIComponent(id) + '/cancel', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'X-CSRF-Token': getCsrf()
        },
        body: JSON.stringify({})
      })
        .then(function (r) { return r.json().catch(function () { return { success: false, message: 'پاسخ نامعتبر از سرور' }; }); })
        .then(function (res) {
          if (res && res.success) {
            notify('success', (res.message || 'درخواست برداشت لغو و موجودی بازگردانده شد'));
            setTimeout(function () { window.location.reload(); }, 900);
          } else {
            notify('error', (res && res.message) || 'لغو درخواست برداشت انجام نشد');
            btn.disabled = false;
            btn.innerHTML = originalHtml;
          }
        })
        .catch(function () {
          notify('error', 'خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
          btn.disabled = false;
          btn.innerHTML = originalHtml;
        });
    });
  }

  // FIX-X111: مهاجرت دلیگیشن قدیمی به قرارداد X106 (ChortkeActions)
  window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    'cancel-withdrawal': function (ev) { if (ev && ev.preventDefault) ev.preventDefault(); cancelWithdrawal(this); }
  });
})();
