(function(){
'use strict';
const D = window.ADS_SHOW_DATA || {};
const cv = document.getElementById('performanceChart');
if(cv){
  const mkChart = () => {
    const ctx = cv.getContext('2d');
    const mkGrad = (c1,c2)=>{ const g=ctx.createLinearGradient(0,0,0,220); g.addColorStop(0,c1); g.addColorStop(1,c2); return g; };
    const labels=['۶ روز قبل','۵ روز قبل','۴ روز قبل','۳ روز قبل','۲ روز قبل','دیروز','امروز'];
    const imp = D.impressions||0, clk = D.clicks||0;
    const impData = [0,0, Math.round(imp*0.15), Math.round(imp*0.35), Math.round(imp*0.6), Math.round(imp*0.82), imp];
    const clkData = [0,0, Math.round(clk*0.1), Math.round(clk*0.3), Math.round(clk*0.55), Math.round(clk*0.78), clk];
    if(window.Chart){
      new Chart(ctx,{type:'line',data:{labels, datasets:[
        {label:'نمایش',data:impData,borderColor:'#FCD535',backgroundColor:mkGrad('rgba(252,213,53,.28)','rgba(252,213,53,0)'),tension:.4,fill:true,pointRadius:3,borderWidth:2.5}, // FIX-R36-W3 (F-A20-13): طلایی کاننیکال (#F0B90B و rgba قدیمیش)
        {label:'کلیک',data:clkData,borderColor:'#10b981',backgroundColor:mkGrad('rgba(16,185,129,.18)','rgba(16,185,129,0)'),tension:.4,fill:true,pointRadius:3,borderWidth:2.5}
      ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:'rgba(0,0,0,.06)'}},x:{grid:{display:false}}}}});
      return;
    }
    // fallback
    const w=cv.width = cv.clientWidth||720, h=cv.height=190;
    ctx.clearRect(0,0,w,h);
    ctx.fillStyle='#f8fafc'; ctx.fillRect(0,0,w,h);
    const drawLine = (vals,color,y0)=>{ ctx.strokeStyle=color; ctx.lineWidth=3; ctx.beginPath(); vals.forEach((v,i)=>{ const x=30+i*((w-50)/6); const y=h-30-(v/Math.max(1,imp,clk))*110; i?ctx.lineTo(x,y):ctx.moveTo(x,y)}); ctx.stroke(); };
    drawLine(impData,'#FCD535'); drawLine(clkData,'#10b981'); // FIX-R36-W3 (F-A20-13)
    ctx.fillStyle='#334155'; ctx.font='13px Vazirmatn,system-ui'; ctx.textAlign='center';
    ctx.fillText(`بازدید: ${imp} | کلیک: ${clk} | مصرف: ${Math.round(D.spent||0).toLocaleString('fa-IR')} تومان`, w/2, 22);
  };
  if(document.readyState==='complete') mkChart(); else window.addEventListener('load', mkChart);
  new ResizeObserver(()=>{ if(!window.Chart) mkChart(); }).observe(cv.parentElement);
}

// Exec table filter/search
const q = document.getElementById('execSearch');
const fBtns = document.querySelectorAll('#execFilters button');
const tbody = document.querySelector('#execTable tbody');
let curF='all';
function applyExecFilter(){
  const needle = (q?.value||'').trim().toLowerCase();
  let visible=0;
  tbody?.querySelectorAll('tr[data-status]').forEach(tr=>{
    const status = tr.dataset.status||'';
    const hay = tr.dataset.search||'';
    const matchStatus = curF==='all' || status.includes(curF) || (curF==='submitted' && status==='submitted') || (curF==='approved' && ['approved','completed'].includes(status)) || (curF==='rejected' && ['rejected','fraud'].includes(status)) || (curF==='pending' && ['pending','started','watching'].includes(status));
    const matchQ = !needle || hay.includes(needle);
    const show = matchStatus && matchQ;
    tr.style.display = show ? '' : 'none';
    // hide proof row too
    const proof = tr.nextElementSibling;
    if(proof && proof.classList.contains('proof-row')) proof.hidden = true;
    if(show) visible++;
  });
  const empty = document.getElementById('execEmpty');
  if(empty) empty.hidden = visible !== 0;
}
q?.addEventListener('input', applyExecFilter);
fBtns.forEach(b=>b.addEventListener('click',()=>{fBtns.forEach(x=>x.classList.remove('on')); b.classList.add('on'); curF=b.dataset.f; applyExecFilter();}));

// proof toggle
document.addEventListener('click', e=>{
  const t = e.target.closest('[data-toggle-proof]');
  if(t){ e.preventDefault(); const sel=t.getAttribute('data-toggle-proof'); const row=document.querySelector(sel); if(row) row.hidden = !row.hidden; }
  const ap = e.target.closest('[data-open-approve]');
  if(ap){ const id=ap.dataset.openApprove; document.querySelector('#proof-'+id)?.removeAttribute('hidden'); document.querySelector('#proof-'+id+' input[name="note"]')?.focus(); }
  const rj = e.target.closest('[data-open-reject]');
  if(rj){ const id=rj.dataset.openReject; document.querySelector('#proof-'+id)?.removeAttribute('hidden'); document.querySelector('#proof-'+id+' input[name="reason"]')?.focus(); }
});

// copy ad link
document.getElementById('copyAdLinkBtn')?.addEventListener('click', function(){
  navigator.clipboard?.writeText(this.dataset.url||location.href);
  const old=this.innerHTML; this.innerHTML='<span class="material-icons" style="font-size:18px">check</span>';
  setTimeout(()=>this.innerHTML=old,1200);
});

// 🛡️ FIX-SEO-23-01 (فاز ۲) — دکمهٔ تست یکپارچگی اثبات فرود (پیکسل/پست‌بک)
// جریان: POST /ads/seo-proof/test → توکن تست → تبلیغ‌دهنده کد را با همان توکن
// اجرا می‌کند → این‌جا هر ۲.۵ ثانیه poll می‌کنیم تا «دریافت شد» یا انقضا.
(function(){
  const panel = document.getElementById('seoProofPanel');
  if(!panel) return;
  const adId = parseInt(panel.dataset.adId || (window.ADS_SHOW_SEO_AD_ID || '0'), 10);
  const testBtn = document.getElementById('seoProofTestBtn');
  const statusEl = document.getElementById('seoProofTestStatus');
  const regenBtn = document.getElementById('seoRegenSecretBtn');
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || window.ADS_SHOW_DATA?.csrf || '';
  let pollTimer = null;

  const setStatus = (txt, cls) => { if(statusEl){ statusEl.textContent = txt; statusEl.className = cls || 'muted-sm'; } };

  async function startTest(){
    if(!adId) return;
    testBtn.disabled = true;
    setStatus('در حال صدور توکن تست…', 'muted-sm');
    try{
      const res = await fetch('/ads/seo-proof/test', {
        method:'POST',
        headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':csrf},
        body: JSON.stringify({ad_id: adId})
      });
      const j = await res.json();
      if(!j.ok){ setStatus('خطا: ' + (j.error||''), 'text-danger'); return; }
      // جایگزینی {CKP} در مستندات با توکن واقعی تست
      panel.querySelectorAll('.seo-proof-code').forEach(el=>{
        if(el.id==='seoPostbackSecret') return;
        el.textContent = el.textContent.replace(/\{CKP\}/g, j.token);
      });
      const pixelUrl = j.pixel_url || ('/seo/px/' + j.token);
      const pb = j.postback_url || '/api/v1/seo/postback';
      setStatus('توکن تست صادر شد (تا ' + (j.expires_at||'۱۰ دقیقه') + '). حالا کد بالا را با این توکن اجرا کنید — یا برای تست سریع پیکسل، این آدرس را باز کنید:', 'text-info');
      const quick = document.createElement('a');
      quick.href = pixelUrl; quick.target = '_blank'; quick.rel = 'noopener';
      quick.className = 'seo-proof-quicklink'; quick.dir = 'ltr';
      quick.textContent = pixelUrl;
      quick.addEventListener('load', ()=>{}); // مرورگر لینک جدا باز می‌کند
      statusEl.appendChild(document.createElement('br'));
      statusEl.appendChild(quick);
      if(j.postback_url){ statusEl.appendChild(document.createElement('br'));
        const pbNote = document.createElement('span'); pbNote.dir='ltr'; pbNote.className='muted-sm';
        pbNote.textContent = '(پست‌بک: ' + pb + ' با token=' + j.token + ')';
        statusEl.appendChild(pbNote);
      }
      // شروع poll وضعیت
      let waited = 0;
      clearInterval(pollTimer);
      pollTimer = setInterval(async ()=>{
        waited += 2.5;
        try{
          const r = await fetch('/ads/seo-proof/test-status?ad_id=' + adId + '&token=' + encodeURIComponent(j.token), {headers:{'Accept':'application/json'}});
          const s = await r.json();
          if(s.ok && s.status==='received'){
            clearInterval(pollTimer); pollTimer=null;
            setStatus('✅ دریافت شد! کانال «' + (s.channel==='postback'?'پست‌بک':'پیکسل') + '» سالم است — یکپارچگی تأیید شد.', 'text-success');
            testBtn.disabled = false;
          } else if(s.ok && s.status==='expired'){
            clearInterval(pollTimer); pollTimer=null;
            setStatus('⌛ توکن تست منقضی شد و چیزی دریافت نشد. کد را بازبینی کنید و دوباره تست بگیرید.', 'text-danger');
            testBtn.disabled = false;
          } else if(waited > 120){
            clearInterval(pollTimer); pollTimer=null;
            setStatus('⌛ تا ۲ دقیقه چیزی دریافت نشد. مطمئن شوید کد روی صفحهٔ فرود درست نشسته و پارامتر توکن مقدار واقعی می‌گیرد.', 'text-danger');
            testBtn.disabled = false;
          }
        }catch(_e){/* poll بعدی */}
      }, 2500);
    }catch(err){
      setStatus('خطای شبکه: ' + err.message, 'text-danger');
    }finally{
      if(!pollTimer) testBtn.disabled = false;
    }
  }

  regenBtn?.addEventListener('click', async ()=>{
    if(!confirm('چرخش راز پست‌بک، امضاهای قدیمی را بی‌اعتبار می‌کند. مطمئن هستید؟')) return;
    regenBtn.disabled = true;
    try{
      const res = await fetch('/ads/seo-proof/regenerate-secret', {
        method:'POST',
        headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-Token':csrf},
        body: JSON.stringify({ad_id: adId})
      });
      const j = await res.json();
      if(j.ok){
        const sec = document.getElementById('seoPostbackSecret');
        if(sec) sec.textContent = j.secret;
        setStatus('راز جدید ساخته شد — سرور خودتان را با همین راز به‌روز کنید.', 'text-success');
      } else { setStatus('خطا: ' + (j.error||''), 'text-danger'); }
    }catch(err){ setStatus('خطای شبکه: ' + err.message, 'text-danger'); }
    regenBtn.disabled = false;
  });

  testBtn?.addEventListener('click', startTest);
})();

applyExecFilter();
})();
