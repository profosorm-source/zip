/**
 * testcaptcha.js — هارنس تست صفحهٔ /test-captcha (W4-C)
 * ───────────────────────────────────────────────────────
 * قبلاً placeholder بود؛ اکنون دموی تعاملی کپچای رفتاری را به
 * public/assets/js/shared/behavioral-captcha.js (کالکتور مشترک) وصل می‌کند:
 *   - متریک‌های زندهٔ پنل behavioral (#bc-events/#bc-score/#bc-elapsed/#bc-iact)
 *   - نوار پیشرفت + وضعیت + لاگ پینگ‌های سرور
 *   - فعال‌شدن دکمهٔ ارسال وقتی state امضاشده + امتیاز + زمان به آستانه رسید
 * فرم همان endpoint استاندارد POST /test-captcha/verify را صدا می‌زند؛ پر کردن
 * hidden input ها (behavioral_state/behavioral_score/events) خودِ کالکتور
 * در رویداد submit انجام می‌دهد.
 */
(function () {
    'use strict';

    function $(id) { return document.getElementById(id); }

    function init() {
        var api = window.ChortkeBehavioralCaptcha;
        var form = $('bc-form');
        if (!form || !api) return;

        // کالکتور با defer قبل از این فایل لود شده و auto-attach شده است؛
        // attach مجدد idempotent است و instance همان فرم را برمی‌گرداند.
        var inst = api.attach('#bc-form');
        if (!inst || typeof inst.getState !== 'function') {
            // fallback: state از API سراسری
            inst = {
                getState: function () { return api.getState(); }
            };
        }

        var elEvents = $('bc-events');
        var elScore = $('bc-score');
        var elElapsed = $('bc-elapsed');
        var elIact = $('bc-iact');
        var elBar = $('bc-bar');
        var elStatus = $('bc-status');
        var elLog = $('bc-log');
        var elSubmit = $('bc-submit');

        var lastServerInteractions = 0;
        var lastState = null;

        function log(text) {
            if (!elLog) return;
            var line = document.createElement('div');
            line.className = 'll';
            line.textContent = '[' + new Date().toLocaleTimeString('fa-IR') + '] ' + text;
            elLog.appendChild(line);
            while (elLog.children.length > 8) {
                elLog.removeChild(elLog.firstChild);
            }
        }

        function render() {
            var s;
            try { s = inst.getState(); } catch (e) { return; }
            if (!s) return;
            lastState = s;

            if (elEvents) elEvents.textContent = String(s.events);
            if (elScore) elScore.textContent = String(s.score);
            if (elElapsed) elElapsed.textContent = s.elapsedSeconds + 's';
            if (elIact) elIact.textContent = String(s.serverInteractions);

            if (elBar) {
                elBar.style.width = Math.min(100, s.score) + '%';
                // reduced-motion: انیمیشن عرض حذف می‌شود
                if (s.reducedMotion) elBar.style.transition = 'none';
            }

            // لاگ پیشرفت شمارندهٔ امضاشدهٔ سرور
            if (s.serverInteractions > lastServerInteractions) {
                log('ping: interaction ' + s.serverInteractions + ' signed');
                lastServerInteractions = s.serverInteractions;
            }

            var ready = !!s.ready;
            if (elSubmit) elSubmit.disabled = !ready;

            if (elStatus) {
                elStatus.className = 'status-badge ' + (ready ? 's-ready' : 's-wait');
                elStatus.textContent = '';
                var dot = document.createElement('span');
                dot.className = 'status-dot';
                elStatus.appendChild(dot);
                elStatus.appendChild(document.createTextNode(
                    ready ? 'آمادهٔ ارسال — state امضاشده دریافت شد'
                        : (s.hasState ? 'در حال ثبت تعامل… (' + s.serverInteractions + '/5)'
                            : 'در انتظار تعامل…')
                ));
            }
        }

        log('collector v' + (api.version || '?') + ' attached');
        render();
        window.setInterval(render, 500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
