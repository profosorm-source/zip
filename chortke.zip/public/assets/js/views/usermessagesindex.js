document.getElementById('search-conversations').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    document.querySelectorAll('a[href^="/messages/"]').forEach(el => {
        const userName = el.querySelector('h3').textContent.toLowerCase();
        el.style.display = userName.includes(searchTerm) ? 'block' : 'none';
    });
});

function openNewMessageModal() {
    document.getElementById('new-message-modal').classList.remove('hidden');
}

function closeNewMessageModal() {
    document.getElementById('new-message-modal').classList.add('hidden');
}

document.getElementById('new-message-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    const form = this;

    // FIX-R36-W3 (F-A20-05): گارد ارسال دوباره — تا پایان درخواست، submit بعدی نادیده گرفته می‌شود
    if (form.dataset.sending === '1') return;
    const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
    const submitBtnHtml = submitBtn ? submitBtn.innerHTML : '';

    const recipientIdentifier = document.getElementById('new-recipient').value.trim();
    const message = document.getElementById('new-message-text').value.trim();
    const token = document.querySelector('[name="_csrf_token"]').value;

    if (!recipientIdentifier || !message) {
        return;
    }

    // FIX-R36-W3 (F-A20-05): نام‌کاربری دیگر بی‌صدا drop نمی‌شود — شناسهٔ عددی در recipient_id
    // و رشتهٔ خام در recipient ارسال می‌شود تا fallback سرور (MessageController: recipient_id<=0
    // → findByCredentials(recipient)) کار کند؛ قبلاً username → recipient_id:0 و همیشه شکستِ بی‌صدا.
    const numericId = Number(recipientIdentifier);
    const payload = {
        recipient_id: Number.isFinite(numericId) && numericId > 0 ? numericId : 0,
        recipient: recipientIdentifier,
        message,
        is_encrypted: false
    };

    form.dataset.sending = '1';
    if (submitBtn) { submitBtn.disabled = true; submitBtn.innerHTML = 'در حال ارسال...'; }

    try {
        const response = await fetch((window.BASE_URL || '') + '/messages/send', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': token
            },
            body: JSON.stringify(payload)
        });

        if (response.ok) {
            closeNewMessageModal();
            window.location.reload();
            return;
        }
        // FIX-R36-W3 (F-A20-05): شاخهٔ خطا — کاربر دیگر بی‌بازخورد نمی‌ماند
        const errData = await response.json().catch(() => ({}));
        notifySendError(errData.message || 'ارسال پیام انجام نشد.');
    } catch (err) {
        notifySendError('خطا در ارتباط با سرور. دوباره تلاش کنید.');
    } finally {
        form.dataset.sending = '';
        if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = submitBtnHtml; }
    }
});

// FIX-R36-W3 (F-A20-05): بازخورد خطا — notyf لی‌اوت کاربر، fallback alert
function notifySendError(message) {
    if (window.notyf && typeof window.notyf.error === 'function') window.notyf.error(message);
    else alert(message);
}

// Real-time unread count update
// FIX-X107: ① شکل پاسخ {success,message,data:{count}} است — data.count همیشه undefined بود
// (بج «undefined خوانده نشده») ② گارد نبودن بج ③ catch برای خطای شبکه/302
setInterval(() => {
    const badge = document.querySelector('.badge-info');
    if (!badge) return;
    fetch((window.BASE_URL || '') + '/messages/unread/count')
        .then(r => r.json())
        .then(data => {
            const count = data && data.data ? data.data.count : undefined;
            if (typeof count === 'number') {
                badge.textContent = count + ' خوانده نشده';
            }
        })
        .catch(() => { /* silent: polling غیربحرانی است */ });
}, 5000);