const referralScript = document.currentScript;
const referralCsrfToken = document.querySelector('meta[name="csrf-token"]')?.content || window.csrfToken || '';
const referredUsersUrl = referralScript?.dataset.usersUrl || '/referral/referred-users';
const referralCommissionsUrl = referralScript?.dataset.commissionsUrl || '/referral/commissions';
// R31 XSS: داده‌های متنی سرور قبل از ورود به innerHTML escape می‌شوند
function escHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
}
// ── Copy Link ──────────────────────────────────────────────
// FIX-X106: پارامتر btn اختیاری — فراخوانی از dispatch با خودِ دکمه (this) انجام می‌شود
function copyLink(btn) {
    const input = document.getElementById('referralLink');
    btn = btn || document.getElementById('btnCopy');

    const done = () => {
        if (btn) {
            btn.innerHTML = '<i class="material-icons">check</i> کپی شد!';
            btn.classList.add('ref-copy-btn--success');
            setTimeout(() => {
                btn.innerHTML = '<i class="material-icons">content_copy</i> کپی لینک';
                btn.classList.remove('ref-copy-btn--success');
            }, 2500);
        }
        notyf.success('لینک دعوت کپی شد!');
    };

    navigator.clipboard.writeText(input.value).then(done).catch(() => {
        // fallback برای مرورگرهای قدیمی
        input.select();
        document.execCommand('copy');
        done();
    });
}

// ── STY-14C: Copy Referral Code ────────────────────────────
// عین الگوی copyLink بالا: Clipboard API → fallback execCommand (با textarea
// موقت چون کد در <strong> است نه input) → بازخورد دکمه + توست notyf.
function copyReferralCode(btn) {
    const codeEl = document.getElementById('referralCode');
    btn = btn || document.querySelector('[data-action="copy-referral-code"]');
    if (!codeEl) return;
    const code = codeEl.textContent.trim();

    const done = () => {
        if (btn) {
            btn.innerHTML = '<i class="material-icons">check</i> کپی شد!';
            btn.classList.add('ref-copy-btn--success');
            setTimeout(() => {
                btn.innerHTML = '<i class="material-icons">content_copy</i> کپی کد';
                btn.classList.remove('ref-copy-btn--success');
            }, 2500);
        }
        notyf.success('کد دعوت کپی شد!');
    };

    const legacyFallback = () => {
        // fallback برای مرورگرهای قدیمی — الگوی execCommandِ copyLink
        const ta = document.createElement('textarea');
        ta.value = code;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (err) {}
        document.body.removeChild(ta);
        done();
    };

    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(code).then(done).catch(legacyFallback);
    } else {
        legacyFallback();
    }
}

// ── STY-14C: Generate-code form loading state ─────────────
// فرم POST کلاسیک (CSRF) — روی submit دکمه disable + اسپینر می‌گیرد؛
// خود صفحه بعد از redirect فلش موفقیت را نشان می‌دهد.
function bindGenerateForm() {
    const form = document.querySelector('.ref-generate-form');
    if (!form) return;
    form.addEventListener('submit', function () {
        const btn = form.querySelector('button[type="submit"]');
        if (!btn || btn.disabled) return;
        btn.disabled = true;
        btn.innerHTML = '<i class="material-icons icon-sm ref-icon-spin" aria-hidden="true">refresh</i> در حال ساخت کد...';
    });
}

// ── STY-14C: QR lazy-load (وندور موجود qrcodejs) ──────────
// اسکریپت وندور فقط وقتی تزریق می‌شود که جعبهٔ QR واقعاً دیده شود
// (IntersectionObserver)؛ فال‌بک: رندر فوری در DOMContentLoaded.
function renderReferralQr() {
    const box = document.getElementById('referralQrBox');
    if (!box || box.dataset.qrDone) return;
    const link = box.dataset.qrLink;
    if (!link || typeof QRCode === 'undefined') return;
    box.dataset.qrDone = '1';
    // qrcodejs: canvas + img می‌سازد؛ پس‌زمینهٔ سفید برای اسکن‌پذیری در هر دو تم
    new QRCode(box, {
        text: link,
        width: 128,
        height: 128,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
    });
    const img = box.querySelector('img');
    if (img) img.alt = 'کد QR لینک دعوت شما';
}

function bindQrLazyLoad() {
    const box = document.getElementById('referralQrBox');
    const qrSrc = referralScript && referralScript.dataset.qrSrc;
    if (!box || !qrSrc) return;
    if (typeof QRCode === 'undefined') {
        const s = document.createElement('script');
        s.src = qrSrc;
        // nonce همان اسکریپت ویو (CSP nonce-based) تا تزریق مجاز بماند
        try { if (referralScript.nonce) s.nonce = referralScript.nonce; } catch (err) {}
        s.async = true;
        s.onload = renderReferralQr;
        document.head.appendChild(s);
    }
    if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver((entries) => {
            entries.forEach((en) => {
                if (en.isIntersecting) {
                    // باکس از فاصلهٔ ۲۰۰px قبل دیده می‌شود
                    if (typeof QRCode !== 'undefined') { renderReferralQr(); io.disconnect(); }
                }
            });
        }, { rootMargin: '200px' });
        io.observe(box);
        // اگر بعد از load شدن اسکریپت هنوز باکس دیده نشده بود، onload خودش رندر نمی‌کند —
        // پس در onload هم چکِ نهایی:
        window.addEventListener('load', () => {
            const r = box.getBoundingClientRect();
            if (r.top < window.innerHeight + 200 && typeof QRCode !== 'undefined') {
                renderReferralQr();
                io.disconnect();
            }
        });
    }
    // فال‌بک بدون IO: بعد از لود شدن اسکریپت، onload رندر می‌کند (renderReferralQr گارد دیده‌شدن ندارد — عمدی؛ باکس در پنل پیش‌فرض فعال است)
}

// ── Load More Users ────────────────────────────────────────
let usersPage = 1;
function loadMoreUsers(btn) {
    usersPage++;
    btn.disabled = true;
    btn.innerHTML = '<i class="material-icons" style="animation:spin .8s linear infinite">refresh</i> در حال بارگذاری...';

    fetch(`${referredUsersUrl}?page=${usersPage}`, {
        headers: { 'X-CSRF-Token': referralCsrfToken, 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (!data.success || !data.users.length) {
            btn.closest('.ref-load-more').remove();
            return;
        }
        const tbody = btn.closest('.ref-section').querySelector('tbody');
        const offset = (usersPage - 1) * 15;
        data.users.forEach((u, i) => {
            const tr = document.createElement('tr');
            const initial = u.full_name ? u.full_name.charAt(0) : 'ک';
            tr.innerHTML = `
                <td class="ref-td-num">${offset + i + 1}</td>
                <td><div class="ref-user-cell"><div class="ref-user-avatar">${escHtml(initial)}</div><span>${escHtml(u.full_name || '—')}</span></div></td>
                <td class="ref-td-date">${escHtml(u.joined_at_jalali || '—')}</td>
                <td class="ref-td-earn ref-text-irt">${Number(u.earned_irt||0).toLocaleString()}</td>
                <td class="ref-td-earn ref-text-usdt">${Number(u.earned_usdt||0).toFixed(2)}</td>
                <td><span class="ref-count-chip">${Number(u.commission_count||0).toLocaleString()}</span></td>
            `;
            tbody.appendChild(tr);
        });
        if (usersPage >= data.pages) btn.closest('.ref-load-more').remove();
        else { btn.disabled = false; btn.innerHTML = '<i class="material-icons">expand_more</i> نمایش بیشتر'; }
    })
    .catch(() => { btn.disabled = false; btn.innerHTML = '<i class="material-icons">expand_more</i> نمایش بیشتر'; });
}

// ── Load More Commissions ──────────────────────────────────
let commPage = 1;
function loadMoreCommissions(btn) {
    commPage++;
    btn.disabled = true;
    btn.innerHTML = '<i class="material-icons" style="animation:spin .8s linear infinite">refresh</i> در حال بارگذاری...';

    fetch(`${referralCommissionsUrl}?page=${commPage}`, {
        headers: { 'X-CSRF-Token': referralCsrfToken, 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (!data.success || !data.commissions.length) {
            btn.closest('.ref-load-more').remove();
            return;
        }
        const tbody = btn.closest('.ref-section').querySelector('tbody');
        const offset = (commPage - 1) * 15;
        data.commissions.forEach((c, i) => {
            const isPaid = c.status === 'paid';
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="ref-td-num">${offset + i + 1}</td>
                <td class="ref-td-name">${escHtml(c.referred_name || '—')}</td>
                <td><span class="ref-source-chip">${escHtml(c.source_label || c.source_type)}</span></td>
                <td dir="ltr" class="ref-td-amount">${c.currency==='usdt' ? Number(c.source_amount).toFixed(2) : Number(c.source_amount).toLocaleString()}</td>
                <td class="ref-td-pct">${escHtml(c.commission_percent)}%</td>
                <td dir="ltr" class="ref-td-comm"><strong class="ref-text-earn">${c.currency==='usdt' ? Number(c.commission_amount).toFixed(2) : Number(c.commission_amount).toLocaleString()}</strong></td>
                <td><span class="ref-currency-chip ref-currency-chip--${escHtml(c.currency)}">${c.currency==='usdt'?'USDT':'تومان'}</span></td>
                <td><span class="ref-badge ${escHtml(c.status_class)}">${escHtml(c.status_label)}</span></td>
                <td class="ref-td-date">${escHtml(c.created_at_jalali || '—')}</td>
            `;
            tbody.appendChild(tr);
        });
        if (commPage >= data.pages) btn.closest('.ref-load-more').remove();
        else { btn.disabled = false; btn.innerHTML = '<i class="material-icons">expand_more</i> نمایش بیشتر'; }
    })
    .catch(() => { btn.disabled = false; btn.innerHTML = '<i class="material-icons">expand_more</i> نمایش بیشتر'; });
}

// spin animation
const style = document.createElement('style');
style.textContent = '@keyframes spin{to{transform:rotate(360deg)}}';
document.head.appendChild(style);

// ── FIX-X106: ثبت در منبع واحدِ dispatch (قرارداد X89) ──────────────────
// نام‌های ثبتشده دقیقاً همان data-actionهای views/user/referral/index.php است.
// STY-14C FIX: dispatch فعلی (FIX-X106c) originatingElement را در `this` می‌گذارد
// و آرگومان اول، خودِ Event است — ثبت‌های قبلی `function (el) { fn(el); }`
// Event را به‌جای دکمه پاس می‌دادند و بازخورد دکمه (کپی شد!/اسپینر) بی‌صدا
// می‌شکست. هم‌الگوی BUILTIN_HANDLERS: «const el = this».
window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    'copy-referral-link':    function () { copyLink(this); },
    'copy-referral-code':    function () { copyReferralCode(this); },
    'load-more-users':       function () { loadMoreUsers(this); },
    'load-more-commissions': function () { loadMoreCommissions(this); },
});

// ── STY-14C: بایندهای غیر-delegation (فرم ساخت کد + QR lazy) ──
function bindReferralExtras() {
    bindGenerateForm();
    bindQrLazyLoad();
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindReferralExtras);
} else {
    bindReferralExtras();
}