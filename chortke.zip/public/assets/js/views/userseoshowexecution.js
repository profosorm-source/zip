/**
 * 🛡️ FIX-SEO3-01 (تصمیم ۱ — فعال‌سازی report/rate سئو):
 * بازخورد مجری در صفحهٔ جزئیات اجرا — گزارش تخلف (یک‌بار) و امتیازدهی به
 * کمپین (قابل به‌روزرسانی). AJAX با CSRF از data-attribute؛ پس از ثبت، فرم
 * به پیام تأیید تبدیل می‌شود. هیچ سیگنال تعاملی/پولی از این صفحه نمی‌آید —
 * فقط interactions (گزارش/امتیاز) که در سرویس‌های مشترک dedupe/آلارم دارند.
 */
(function () {
  'use strict';

  const card = document.getElementById('seoFeedbackCard');
  if (!card) return;

  const csrf = card.dataset.csrf || window.csrfToken || document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
  const reportUrl = card.dataset.reportUrl || '';
  const rateUrl = card.dataset.rateUrl || '';

  function notify(type, message) {
    if (typeof window.Notyf !== 'undefined') {
      try { return new window.Notyf({ duration: 4500, position: { x: 'left', y: 'top' }, dismissible: true })[type](message); } catch (_) { /* fallthrough */ }
    }
    if (type === 'error') return alert(message);
    console.log(message);
  }

  async function post(url, payload) {
    const res = await fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(Object.assign({ _csrf_token: csrf }, payload))
    });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok && data.success, message: String(data.message || ''), data };
  }

  // ── گزارش تخلف ────────────────────────────────────────────────
  document.getElementById('seoReportBtn')?.addEventListener('click', async function () {
    const reason = (document.getElementById('seoReportReason')?.value || '').trim();
    const description = (document.getElementById('seoReportDescription')?.value || '').trim();
    if (reason === '') { notify('error', 'دلیل گزارش را انتخاب کنید.'); return; }

    const btn = this;
    btn.disabled = true;
    try {
      const r = await post(reportUrl, { reason, description });
      if (r.ok) {
        const form = document.getElementById('seoReportForm');
        if (form) {
          const done = document.createElement('div');
          done.className = 'alert alert-light mb-0 small';
          done.id = 'seoReportDone';
          done.textContent = 'گزارش شما ثبت شده و توسط تیم بررسی می‌شود. ممنون از همراهی شما.';
          form.replaceWith(done);
        }
        notify('success', r.message || 'گزارش ثبت شد.');
      } else {
        btn.disabled = false;
        notify('error', r.message || 'ثبت گزارش انجام نشد.');
      }
    } catch (_) {
      btn.disabled = false;
      notify('error', 'خطا در ارتباط با سرور.');
    }
  });

  // ── امتیازدهی ─────────────────────────────────────────────────
  let selectedStars = 0;
  const starBtns = Array.from(card.querySelectorAll('.seo-star-btn'));
  const rateBtn = document.getElementById('seoRateBtn');

  function paintStars(n) {
    starBtns.forEach(b => b.classList.toggle('active', Number(b.dataset.stars || 0) <= n));
  }

  starBtns.forEach(btn => btn.addEventListener('click', function () {
    selectedStars = Number(this.dataset.stars || 0);
    paintStars(selectedStars);
    if (rateBtn) rateBtn.disabled = false;
  }));

  rateBtn?.addEventListener('click', async function () {
    if (selectedStars < 1 || selectedStars > 5) { notify('error', 'ابتدا امتیاز (۱ تا ۵ ستاره) را انتخاب کنید.'); return; }
    const comment = (document.getElementById('seoRateComment')?.value || '').trim();

    const btn = this;
    btn.disabled = true;
    try {
      const r = await post(rateUrl, { stars: selectedStars, comment });
      if (r.ok) {
        const my = document.getElementById('seoMyRatingText');
        if (my) my.textContent = String(selectedStars);
        notify('success', r.message || 'امتیاز ثبت شد.');
        // میانگین محلی را تازه نمی‌کنیم — منبع حقیقت رندر بعدی سرور است.
      } else {
        notify('error', r.message || 'ثبت امتیاز انجام نشد.');
      }
    } catch (_) {
      notify('error', 'خطا در ارتباط با سرور.');
    } finally {
      btn.disabled = false;
    }
  });
})();
