(function () {
  'use strict';
  const root = document.getElementById('socialTaskExecuteRoot');
  const form = document.getElementById('socialTaskSubmitForm');
  if (!root || !form) return;

  const submitUrl = root.dataset.submitUrl || '';
  // FIX-S12-1: endpointهای هم‌مبدأ سشن‌محور — از پیشوند /api/ خارج شدند (CORE-037)
  const behaviorUrl = root.dataset.behaviorUrl || '/social-tasks/verify/behavior';
  const cameraUrl = root.dataset.cameraUrl || '/social-tasks/verify/camera-verify';
  // 🛡️ FIX-F21-01 (گزینهٔ C): گام اول جریان چالش-پاسخ — تحویل nonce یک‌بارمصرف
  const cameraChallengeUrl = root.dataset.cameraChallengeUrl || '/social-tasks/verify/camera-challenge';
  const csrf = root.dataset.csrf || document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
  const executionId = parseInt(root.dataset.executionId || '0', 10);
  const taskType = root.dataset.taskType || 'social';
  const clientMode = root.dataset.clientMode || (isNativeMobileApp() ? 'mobile_app' : 'web');
  const expectedTime = parseInt(root.dataset.expectedTime || '60', 10);
  function isNativeMobileApp() {
    return /ChortkeMobile|ChortkeApp/i.test(navigator.userAgent) || window.ChortkeMobileApp === true;
  }
  const isMobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) || isNativeMobileApp();
  let activeTime = 0;
  let focused = true;
  let notifier = null;
  let cameraFlowStarted = false;
  let cameraStaleRetries = 0; // سقف retry خودکار برای چالش منقضی/مصرف‌شده (جلوگیری از حلقهٔ بی‌پایان)
  let lastActionAt = Date.now();
  const actionDelays = [];
  const behavior = {
    tap_count: 0,
    swipe_count: 0,
    scroll_count: 0,
    touch_pauses: 0,
    touch_timing_variance: 999,
    scroll_speed_variance: 999,
    scroll_pauses: 0,
    session_duration: 0,
    active_time: 0,
    expected_time: expectedTime,
    reconnect_count: 0,
    app_blur_count: 0,
    max_blur_duration: 0,
    hesitation_count: 0,
    avg_action_delay_ms: 0,
    natural_delay_count: 0,
    is_mobile: isMobile ? 1 : 0,
    client_mode: clientMode,
    client_version: window.ChortkeAppVersion || ''
  };
  let blurStartedAt = 0;
  let touchStart = null;

  function notify(type, message) {
    if (type === 'warning') type = 'error'; // Notyf متد warning ندارد (بدون این خط alert() بلاک‌کننده می‌شد)
    if (!notifier && typeof window.Notyf !== 'undefined') notifier = new window.Notyf({ duration: 4500, position: { x: 'left', y: 'top' }, dismissible: true });
    if (notifier && typeof notifier[type] === 'function') return notifier[type](message);
    alert(message);
  }

  function idempotencyKey() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return 'SOC_' + window.crypto.randomUUID();
    return 'SOC_' + Date.now() + '_' + Math.random().toString(16).slice(2);
  }

  // FIX-W2G F-A21-01: کلید idempotency یک‌بار در بارگذاری صفحه ساخته و در فیلد مخفی
  // #idempotencyKey (هم‌نام انتظار سرور در ExecuteSocialTaskRequest) نگه داشته می‌شود؛
  // هر کلیک/تلاش مجدد (از جمله مسیر camera-retry) همان کلید را می‌فرستد تا
  // IdempotencyService سمت سرور بتواند «همان ارسال منطقی» را dedupe کند.
  const idemField = document.getElementById('idempotencyKey');
  if (idemField && !idemField.value) idemField.value = idempotencyKey();

  function currentIdempotencyKey() {
    if (idemField && idemField.value) return idemField.value;
    const key = idempotencyKey();
    if (idemField) idemField.value = key;
    return key;
  }

  function updateActionStats() {
    const now = Date.now();
    const delay = now - lastActionAt;
    lastActionAt = now;
    if (delay > 0 && delay < 30000) actionDelays.push(delay);
    if (actionDelays.length > 30) actionDelays.shift();
    if (delay > 450) behavior.natural_delay_count += 1;
    if (delay > 1200) behavior.hesitation_count += 1;
    if (actionDelays.length >= 2) {
      const avg = actionDelays.reduce((a, b) => a + b, 0) / actionDelays.length;
      const variance = actionDelays.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / actionDelays.length;
      behavior.avg_action_delay_ms = Math.round(avg);
      behavior.touch_timing_variance = Math.round(Math.sqrt(variance));
    }
  }

  function currentSignals() {
    behavior.session_duration = activeTime;
    behavior.active_time = activeTime;
    behavior.expected_time = expectedTime;
    return Object.assign({}, behavior);
  }

  async function postJson(url, payload) {
    const response = await fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(Object.assign({ _csrf_token: csrf }, payload))
    });
    const data = await response.json().catch(() => ({}));
    return { response, data, payload: data.data || data, message: (data && data.message) || '' };
  }

  async function sendBehaviorSignals() {
    if (!executionId || !behaviorUrl) return;
    try {
      const { response, payload } = await postJson(behaviorUrl, { execution_id: executionId, signals: currentSignals() });
      if (response.ok && payload && payload.camera_required) {
        await runCameraVerification(payload);
      }
    } catch (_) {
      // behavior tracking must be silent and must not block proof submission
    }
  }

  // 🛡️ FIX-F21-01 (گزینهٔ C) + FIX-F21-01-R2 (تصمیم‌های D1/D2 مالک): این
  // تابع «نمونهٔ کامل» جریان چالش-پاسخ است — همین قرارداد برای اپ موبایل:
  // (۰) اجازهٔ کاربر برای بررسی نمونهٔ تصادفی (spot_consent)؛ (۱) camera-challenge
  // → nonce + spot_check؛ (۲) ضبط حداقل ۳ فریم با ویژگی‌های t/lum/std و در صورت
  // درخواست سرور، یک تصویر کم‌حجم از فریم ایندکس‌شده؛ (۳) camera-verify با
  // nonce+frames(+spot_images). امتیاز را سرور محاسبه می‌کند؛ کلاینت هیچ
  // camera_score ادعایی نمی‌فرستد. تصویر نمونه هرگز ذخیره نمی‌شود.
  async function runCameraVerification(serverPayload) {
    if (cameraFlowStarted || !isMobile) return;
    cameraFlowStarted = true;

    const message = serverPayload?.message || 'برای اطمینان از واقعی بودن اجرای موبایل، تأیید دوربین لازم است. هیچ عکس یا اسکرین‌شاتی ذخیره نمی‌شود؛ فقط ویژگی‌های آماری فریم‌ها (زمان‌بندی/روشنایی) تحلیل می‌شود.';
    let confirmed = true;
    if (typeof Swal !== 'undefined') {
      confirmed = await Swal.fire({
        icon: 'warning',
        title: 'تأیید دوربین برای رفتار مشکوک',
        text: message,
        showCancelButton: true,
        confirmButtonText: 'اجازه می‌دهم',
        cancelButtonText: 'بعداً',
        confirmButtonColor: '#f0b90b'
      }).then(r => r.isConfirmed);
    } else {
      confirmed = window.confirm(message);
    }
    if (!confirmed) {
      cameraFlowStarted = false;
      return;
    }

    // ─── گام ۰ (تصمیم D1 مالک): اجازهٔ صریح برای بررسی نمونهٔ تصادفی ───
    // تصویر فقط در حافظهٔ سرور بررسی و بلافاصله حذف می‌شود؛ هرگز ذخیره نمی‌شود.
    // بدون رضایت، فلو ادامه می‌یابد اما تأیید خودکار (حکم pass) صادر نمی‌شود.
    const spotConsentMessage = 'برای آزادسازی خودکار پاداش، گاهی سرور یک تصویر بسیار کوچک (حداکثر ~۳۲۰ پیکسل) از لحظهٔ تأیید می‌خواهد. تصویر فقط بررسی می‌شود و بلافاصله حذف می‌شود — هرگز ذخیره نمی‌شود. اجازه می‌دهید؟';
    let spotConsent = false;
    if (typeof Swal !== 'undefined') {
      spotConsent = await Swal.fire({
        icon: 'question',
        title: 'اجازهٔ بررسی نمونهٔ تصادفی',
        text: spotConsentMessage,
        showCancelButton: true,
        confirmButtonText: 'اجازه می‌دهم (تأیید خودکار)',
        cancelButtonText: 'نه (بررسی دستی)',
        confirmButtonColor: '#f0b90b'
      }).then(r => r.isConfirmed);
    } else {
      spotConsent = window.confirm(spotConsentMessage);
    }

    if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
      notify('error', 'مرورگر شما دسترسی دوربین را پشتیبانی نمی‌کند.');
      cameraFlowStarted = false;
      return;
    }

    // ─── گام ۱: چالش (nonce یک‌بارمصرف + قرارداد فریم از سرور) ───
    let challenge = null;
    try {
      const { response, payload, message: challengeMessage } = await postJson(cameraChallengeUrl, { execution_id: executionId, client_mode: clientMode, spot_consent: spotConsent });
      if (!response.ok || !payload || !payload.nonce) {
        notify('error', challengeMessage || 'دریافت چالش دوربین انجام نشد.');
        cameraFlowStarted = false;
        return;
      }
      challenge = payload;
    } catch (_) {
      notify('error', 'خطا در دریافت چالش دوربین.');
      cameraFlowStarted = false;
      return;
    }

    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      const video = document.createElement('video');
      video.muted = true;
      video.playsInline = true;
      video.srcObject = stream;
      await video.play().catch(() => {});

      // ─── گام ۲: ضبط حداقل ۴ نمونه با زمان‌بندی واقعی — ویژگی‌های آماری هر
      // فریم (t/lum/std). اگر سرور spot_check.required داده باشد، فقط برای
      // ایندکس‌های درخواستی یک تصویر کم‌حجم (≤۳۲۰px JPEG) همان لحظه ساخته و
      // در حافظه نگه داشته می‌شود تا با همان ارسال برود (تصمیم D1 مالک).
      // گرم‌کردن: بعضی مرورگرهای موبایل در ۱-۲ فریم اول تصویر سیاه می‌دهند و
      // سرور آن را «لنز پوشانده» می‌خواند؛ تا آماده‌شدن اولین فریم صبر می‌کنیم.
      const warmStart = performance.now();
      while (video.readyState < 2 && performance.now() - warmStart < 2500) {
        await new Promise(resolve => setTimeout(resolve, 50));
      }
      await new Promise(resolve => setTimeout(resolve, 250)); // تثبیت نوردهی خودکار
      const frames = [];
      const spotImages = {};
      const spotIndices = (challenge.spot_check && challenge.spot_check.required && Array.isArray(challenge.spot_check.indices))
        ? challenge.spot_check.indices : [];
      const spotMaxBytes = (challenge.spot_check && challenge.spot_check.max_bytes) || 61440;
      const captureStart = performance.now();
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      function spotJpeg(frameIndex1Based) {
        // تصویر نمونه: همان لحظهٔ ضبط، حداکثر ~۳۲۰ پیکسل — فقط در حافظه
        return new Promise(resolve => {
          try {
            const vw = video.videoWidth || 96;
            const vh = video.videoHeight || 96;
            const scale = Math.min(1, 320 / Math.max(vw, vh));
            const spot = document.createElement('canvas');
            spot.width = Math.max(16, Math.round(vw * scale));
            spot.height = Math.max(16, Math.round(vh * scale));
            const sctx = spot.getContext('2d');
            if (!sctx) { resolve(null); return; }
            sctx.drawImage(video, 0, 0, spot.width, spot.height);
            spot.toBlob(blob => {
              if (!blob) { resolve(null); return; }
              const reader = new FileReader();
              reader.onload = () => {
                const b64 = String(reader.result || '').split(',')[1] || '';
                resolve(b64.length <= Math.ceil(spotMaxBytes * 4 / 3) + 16 ? b64 : null);
              };
              reader.onerror = () => resolve(null);
              reader.readAsDataURL(blob);
            }, 'image/jpeg', 0.55);
          } catch (_) { resolve(null); }
        });
      }
      async function sampleFrame(waitMs, frameIndex1Based) {
        await new Promise(resolve => setTimeout(resolve, waitMs));
        const width = video.videoWidth || 64;
        const height = video.videoHeight || 64;
        canvas.width = Math.min(width, 96);
        canvas.height = Math.min(height, 96);
        if (ctx && width > 0 && height > 0) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const image = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
          const n = image.length / 4;
          let sum = 0, sumSq = 0;
          for (let i = 0; i < image.length; i += 4) {
            const l = 0.299 * image[i] + 0.587 * image[i + 1] + 0.114 * image[i + 2];
            sum += l; sumSq += l * l;
          }
          const mean = sum / n;
          const variance = Math.max(0, sumSq / n - mean * mean);
          frames.push({
            t: Math.round(performance.now() - captureStart),
            lum: Math.round(mean * 100) / 100,
            std: Math.round(Math.sqrt(variance) * 100) / 100,
            w: canvas.width,
            h: canvas.height
          });
          if (spotConsent && spotIndices.includes(frameIndex1Based)) {
            const b64 = await spotJpeg(frameIndex1Based);
            if (b64) spotImages[String(frameIndex1Based)] = b64;
          }
        } else {
          frames.push({ t: Math.round(performance.now() - captureStart), lum: 0, std: 0 });
        }
      }
      // فواصل عمداً نامنظم‌اند (≈۳۳۰/۵۲۰/۴۱۰ms ⇒ CV≈۰٫۱۹): سرور فواصل تقریباً مساوی
      // (CV<۰٫۰۵) را الگوی اسکریپت می‌داند و ۲۰ امتیاز کم می‌کند؛ فواصل قبلی
      // (۴۲۰/۴۳۰/۴۷۰) درست زیر آستانه بود و کاربر صادق را به weak می‌برد.
      await sampleFrame(180, 1);
      await sampleFrame(330, 2);
      await sampleFrame(520, 3);
      await sampleFrame(410, 4);

      if (frames.length < (challenge.min_frames || 3)) {
        notify('error', 'نمونه‌های دوربین کافی نبود. دوباره تلاش کنید.');
        cameraFlowStarted = false;
        return;
      }

      // ─── گام ۳: ارسال nonce + ویژگی‌های فریم‌ها (+ نمونه‌های درخواستی) —
      // بدون هیچ امتیاز ادعایی. تصویر نمونه پس از ارسال از حافظه پاک می‌شود.
      const { response, payload, message: verifyMessage } = await postJson(cameraUrl, {
        execution_id: executionId,
        nonce: challenge.nonce,
        frames: frames,
        spot_images: Object.keys(spotImages).length ? spotImages : undefined,
        client_context: {
          client_mode: clientMode,
          client_version: window.ChortkeAppVersion || '',
          spot_consent: spotConsent,
          raw_image_stored: false
        }
      });
      for (const k of Object.keys(spotImages)) delete spotImages[k]; // پاکسازی فوری حافظه

      if (response.ok && payload && payload.success !== false) {
        const verdict = payload.verdict || payload.server_verdict || 'unknown';
        if (verdict === 'pass') {
          notify('success', (payload.message || 'تأیید دوربین با تحلیل سرور پذیرفته شد.') + ' هیچ تصویری ذخیره نشد.');
        } else if (payload.findings && payload.findings.indexOf('spot_no_consent') !== -1) {
          // 🛡️ FIX-F21-01-R2 (D1): پیام صادقانه — بدون رضایت نمونه، pass صادر نمی‌شود
          cameraFlowStarted = false;
          notify('warning', 'برای تأیید خودکار، اجازهٔ بررسی نمونهٔ تصادفی لازم است (تصویر بررسی و بلافاصله حذف می‌شود؛ ذخیره نمی‌شود). دوباره تلاش کنید.');
        } else {
          // 🛡️ R3-MINOR3 (بازبینی مستقل): پیام صادقانه — verdict weak/fail یعنی
          // سهم دوربین صفر است و اجرا (در صورت نیاز به proof) برای بررسی دستی
          // ارجاع می‌شود؛ قفل فلو آزاد می‌ماند تا مسیر بعدی چالش تازه بگیرد.
          cameraFlowStarted = false;
          notify('warning', (payload.message || 'تأیید دوربین ثبت شد اما تأیید خودکار انجام نشد') + ' (verdict=' + verdict + ') — در محیط نورانی و واقعی دوباره تلاش کنید.');
        }
      } else if (response.status === 422 && payload && payload.error_code === 'CAMERA_STALE_OR_REPLAYED') {
        // چالش منقضی/مصرف‌شده — یک retry کامل با چالش جدید
        cameraFlowStarted = false;
        if (cameraStaleRetries < 1) {
          cameraStaleRetries += 1;
          notify('error', 'چالش دوربین منقضی شده؛ دوباره تلاش می‌کنیم.');
          setTimeout(() => { runCameraVerification(serverPayload); }, 400);
        } else {
          notify('error', 'چالش دوربین دوباره منقضی شد. چند لحظه بعد تلاش کنید.');
        }
      } else {
        notify('error', verifyMessage || 'تأیید دوربین ثبت نشد.');
        cameraFlowStarted = false;
      }
    } catch (err) {
      notify('error', err && err.name === 'NotAllowedError' ? 'اجازه دوربین داده نشد.' : 'خطا در دسترسی به دوربین.');
      cameraFlowStarted = false;
    } finally {
      if (stream) stream.getTracks().forEach(track => track.stop());
    }
  }

  document.addEventListener('visibilitychange', () => {
    focused = !document.hidden;
    if (!focused) {
      behavior.app_blur_count += 1;
      blurStartedAt = Date.now();
    } else if (blurStartedAt) {
      const duration = Math.round((Date.now() - blurStartedAt) / 1000);
      behavior.max_blur_duration = Math.max(behavior.max_blur_duration, duration);
      blurStartedAt = 0;
    }
  });

  window.addEventListener('online', () => { behavior.reconnect_count += 1; });
  window.addEventListener('touchstart', event => {
    behavior.tap_count += 1;
    touchStart = event.touches && event.touches[0] ? { x: event.touches[0].clientX, y: event.touches[0].clientY } : null;
    updateActionStats();
  }, { passive: true });
  window.addEventListener('touchmove', event => {
    if (!touchStart || !event.touches || !event.touches[0]) return;
    const dx = Math.abs(event.touches[0].clientX - touchStart.x);
    const dy = Math.abs(event.touches[0].clientY - touchStart.y);
    if (dx > 35 || dy > 35) {
      behavior.swipe_count += 1;
      touchStart = null;
      updateActionStats();
    }
  }, { passive: true });
  window.addEventListener('scroll', () => {
    behavior.scroll_count += 1;
    updateActionStats();
  }, { passive: true });

  setInterval(() => {
    if (focused) activeTime++;
    const input = document.getElementById('activeTime');
    if (input) input.value = String(activeTime);
    const timer = document.getElementById('timerValue');
    if (timer) timer.textContent = String(Math.max(expectedTime - activeTime, 0));
  }, 1000);

  // برای موبایل، سیگنال رفتار چند ثانیه بعد از شروع و سپس دوره‌ای ارسال می‌شود.
  if (isMobile) {
    setTimeout(sendBehaviorSignals, 3500);
    setInterval(sendBehaviorSignals, 20000);
  }

  async function completeTask(retryAfterCamera) {
    const payload = {
      active_time: activeTime,
      expected_time: expectedTime,
      behavior_signals: currentSignals(),
      idempotency_key: currentIdempotencyKey(),
      client_mode: clientMode,
      _csrf_token: csrf
    };
    const response = await fetch(submitUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf, 'Accept': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await response.json().catch(() => ({}));
    if (response.ok && data.success) {
      notify('success', data.message || 'نتیجه تسک محاسبه شد.');
      setTimeout(() => { window.location.href = (window.BASE_URL || '') + '/tasks?type=social&submitted=1'; }, 900);
      return;
    }
    if (data && data.camera_required && !retryAfterCamera) {
      await runCameraVerification(data);
      await completeTask(true);
      return;
    }
    notify('error', data.message || 'محاسبه نتیجه تسک انجام نشد.');
  }

  form.addEventListener('submit', async function (event) {
    event.preventDefault();
    await sendBehaviorSignals();

    const btn = document.getElementById('submitBtn');
    if (btn) { btn.disabled = true; btn.dataset.originalText = btn.innerHTML; btn.innerHTML = '<i class="material-icons" style="animation:spin .8s linear infinite">refresh</i> در حال محاسبه...'; }
    // FIX-W2G F-A21-01: کلید اینجا دیگر رفرش نمی‌شود — فیلد مخفی در بارگذاری مقدار گرفته و payload از همان می‌خواند.
    document.getElementById('activeTime').value = String(activeTime);

    try {
      await completeTask(false);
    } catch (_) {
      notify('error', 'خطا در ارتباط با سرور.');
    } finally {
      if (btn) { btn.disabled = false; btn.innerHTML = btn.dataset.originalText || '<i class="material-icons">task_alt</i> پایان و محاسبه امتیاز'; }
    }
  });

  const style = document.createElement('style');
  style.textContent = '@keyframes spin{to{transform:rotate(360deg)}}';
  document.head.appendChild(style);
})();
