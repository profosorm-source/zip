const cryptoScript = document.querySelector('script[src*="usercryptodepositcreate.js"]');
const cryptoConfig = cryptoScript ? cryptoScript.dataset : {};
let networkConfig = {};
try { networkConfig = cryptoConfig.networks ? JSON.parse(cryptoConfig.networks) : {}; } catch (_) { networkConfig = {}; }
let selectedNetwork = null;

// FIX-S33-R09: کلیدهای UI (idها/config) با پاسخ سرور (همیشه بزرگ) هم‌خانواده شوند —
// سرور «TRC20» می‌دهد ولی id المان‌ها «trc20_wallet» است؛ تطبیق case-insensitive لازم است.
function netKeyOf(name) {
    const want = String(name ?? '').toLowerCase();
    const keys = Object.keys(networkConfig || {});
    for (let i = 0; i < keys.length; i++) {
        if (keys[i].toLowerCase() === want) return keys[i];
    }
    return String(name ?? '');
}

// FIX-S33-R09 (تکمیل): QR وندور صفحهٔ crypto هرگز لود نمی‌شد (typeof QRCode=undefined)
// ⇒ جعبهٔ QR همیشه خالی می‌ماند. lazy-load همان وندورِ موجود (qrcodejs) با nonce صفحه —
// الگوی STY-14C صفحهٔ رفرال.
let qrLibLoading = false;
function loadQrLib(cb) {
    if (typeof QRCode !== 'undefined') { cb(); return; }
    if (qrLibLoading) { const t = setInterval(function () { if (typeof QRCode !== 'undefined') { clearInterval(t); cb(); } }, 120); return; }
    const src = cryptoConfig.qrSrc || '';
    if (!src) return;
    qrLibLoading = true;
    const s = document.createElement('script');
    s.src = src;
    try { if (cryptoScript && cryptoScript.nonce) s.nonce = cryptoScript.nonce; } catch (_) {}
    s.async = true;
    s.onload = function () { qrLibLoading = false; cb(); };
    s.onerror = function () { qrLibLoading = false; };
    document.head.appendChild(s);
}

async function createIntent(network) {
    const requested = document.getElementById('requested_amount');
    const form = document.getElementById('cryptoDepositForm');
    const amount = requested ? requested.value.trim() : '';
    if (!amount || Number(amount) <= 0) {
        if (typeof notyf !== 'undefined') notyf.error('ابتدا مبلغ درخواستی را وارد کنید');
        return null;
    }
    const csrf = form ? form.querySelector('input[name="_csrf_token"]') : null;
    const body = new URLSearchParams({ network, requested_amount: amount });
    if (csrf && csrf.value) body.set('_csrf_token', csrf.value);
    try {
        const response = await fetch(cryptoConfig.intentUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' },
            body: body.toString(),
        });
        const result = await response.json();
        if (!result.success) {
            if (typeof notyf !== 'undefined') notyf.error(result.message || 'ایجاد درخواست واریز انجام نشد');
            return null;
        }
        return result;
    } catch (_) {
        if (typeof notyf !== 'undefined') notyf.error('ارتباط با سرور برای ایجاد درخواست برقرار نشد');
        return null;
    }
}

async function selectNetwork(network) {
    const intent = await createIntent(network.toUpperCase());
    if (!intent) return;
    // FIX-S33-R09 (گزارش بخش ۱۳): پاسخ intent «منبع حقیقت» است — سرور در وجودِ
    // intent بازِ قبلی، همان را (با network/to_wallet/amount خودش) برمی‌گرداند؛
    // UI قبلاً network انتخابیِ کاربر + آدرس config صفحه را نشان می‌داد ⇒ حالت
    // مخلوط «شبکهٔ جدید + intent قدیمی» (ثبت بعدی در سرویس رد می‌شد). اکنون
    // کارت/QR/آدرس/کپی/hidden بر اساس شبکهٔ خودِ intent رندر می‌شود و اگر با
    // انتخاب کاربر فرق داشت، صریح اعلام می‌شود.
    const intentData = (intent && intent.intent) ? intent.intent : (intent || {});
    const requestedNetwork = String(network).toUpperCase();
    const effectiveNetwork = String(intentData.network ?? requestedNetwork).toUpperCase();
    const elKey = netKeyOf(effectiveNetwork); // کلید المان‌ها/config (case واقعی صفحه)
    const intentWallet = String(intentData.to_wallet ?? '').trim();
    if (effectiveNetwork !== requestedNetwork && typeof notyf !== 'undefined') {
        notyf.warning('شما یک درخواست واریز باز در شبکهٔ ' + effectiveNetwork + ' دارید؛ اطلاعات همان درخواست نمایش داده شد.');
    }
    selectedNetwork = effectiveNetwork;
    const selectedInput = document.getElementById('selected_network');
    const intentInput = document.getElementById('intent_id');
    const exactAmount = document.getElementById('amount');
    if (selectedInput) selectedInput.value = effectiveNetwork;
    if (intentInput) intentInput.value = intentData.id ?? intentData.intent_id ?? '';
    if (exactAmount) exactAmount.value = intentData.expected_amount ?? '';

    const info = document.getElementById('intent_info');
    if (info) {
        info.textContent = `مبلغ دقیق قابل پرداخت: ${intentData.expected_amount} USDT — مهلت ثبت تراکنش: ${intentData.expires_at}`;
        info.classList.remove('d-none');
    }

    Object.keys(networkConfig).forEach(key => document.getElementById(key + '_wallet')?.style.setProperty('display', 'none'));
    const formEl = document.getElementById('deposit_form');
    // FIX-X38: wrapper فرم کلاس d-none دارد (display:none !important)؛
    // تغییر style.display بی‌اثر بود و فرم هش تراکنش هرگز نشان داده نمی‌شد.
    if (formEl) { formEl.classList.add('d-none'); formEl.style.display = ''; }

    const walletCard = document.getElementById(elKey + '_wallet');
    if (walletCard) {
        walletCard.style.display = 'block';
        // FIX-S33-R09: آدرس نمایش‌داده‌شده/QR/کپی = snapshotِ خود intent (fallback: config صفحه)
        const cfgAddress = networkConfig[elKey] ? (networkConfig[elKey].address || '') : '';
        const address = intentWallet !== '' ? intentWallet : cfgAddress;
        if (intentWallet !== '') {
            const addrText = walletCard.querySelector('.address-text');
            if (addrText) addrText.textContent = intentWallet;
            const copyBtn = walletCard.querySelector('[data-action="copy-to-clipboard"]');
            if (copyBtn) copyBtn.dataset.text = intentWallet;
        }
        const qrDiv = document.getElementById('qr_' + elKey);
        if (qrDiv) {
            qrDiv.innerHTML = '';
            if (typeof QRCode !== 'undefined' && address) new QRCode(qrDiv, { text: address, width: 200, height: 200, colorDark: '#000000', colorLight: '#ffffff' });
            else if (address) loadQrLib(function () { new QRCode(qrDiv, { text: address, width: 200, height: 200, colorDark: '#000000', colorLight: '#ffffff' }); });
        }
        if (formEl) { formEl.classList.remove('d-none'); formEl.style.display = ''; }
    }
    setTimeout(() => formEl?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 300);
}

function copyToClipboard(text) { navigator.clipboard.writeText(text).then(() => { if (typeof notyf !== 'undefined') notyf.success('آدرس کپی شد!'); }); }
function resetForm() { selectedNetwork = null; document.getElementById('intent_id').value = ''; Object.keys(networkConfig).forEach(key => document.getElementById(key + '_wallet')?.style.setProperty('display', 'none')); const f = document.getElementById('deposit_form'); if (f) { f.classList.add('d-none'); f.style.display = ''; } }

// FIX-X111: مهاجرت دلیگیشن قدیمی به قرارداد X106 (ChortkeActions)
window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    'select-network': function () { const n = this.dataset.network; if (!n) return; const radio = document.getElementById('network_' + n); if (radio) radio.checked = true; selectNetwork(n); },
    'copy-to-clipboard': function () { if (this.dataset.text) copyToClipboard(this.dataset.text); },
    'reset-crypto-form': function () { resetForm(); }
});

document.getElementById('cryptoDepositForm')?.addEventListener('submit', function(e) {
    if (!selectedNetwork || !document.getElementById('intent_id')?.value) { e.preventDefault(); if (typeof notyf !== 'undefined') notyf.error('ابتدا درخواست واریز و مبلغ دقیق را ایجاد کنید'); }
});
