(function () {
  'use strict';

  const root = document.getElementById('seoExecuteRoot');
  if (!root) return;

  const executionId = parseInt(root.dataset.executionId || '0', 10);
  const minDuration = parseInt(root.dataset.minDuration || '60', 10);
  const completeUrl = root.dataset.completeUrl || ('/seo/' + executionId + '/complete');
  const cancelUrl = root.dataset.cancelUrl || ('/seo/' + executionId + '/cancel');
  const returnUrl = root.dataset.returnUrl || '/seo';
  const csrf = root.dataset.csrf || window.csrfToken || document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
  const targetUrl = root.dataset.targetUrl || '';

  // 🛡️ FIX-SEO3-03 (تصمیم ۳ — نشان اثبات زنده): نشان سه‌حالتهٔ اثبات فقط در
  // رندر اولیه از سرور می‌آمد و بعد از بازگشت کاربر از سایت هدف کهنه می‌ماند
  // (پاداش سمت سرور درست محاسبه می‌شد؛ مشکل اعتماد/UX بود). حالا وضعیت در دو
  // لحظهٔ معنادار تازه می‌شود: ۱) بازگشت به تب/فوکوس پنجره (throttle ≥۵ ثانیه)
  // و ۲) یک‌بار پیش از ارسال تکمیل. هیچ timer مداومی در کار نیست و متن نشان
  // از خود سرور می‌آید (badgeFor — منبع واحد؛ JS چیزی ترجمه نمی‌کند).
  const proofStatusUrl = root.dataset.proofStatusUrl || '';
  const PROOF_RANK = { none: 0, click: 1, landing: 2 };
  let lastProofRefresh = 0;
  let lastProofState = String(root.dataset.proofState || 'none');

  async function refreshProofStatus(force = false) {
    if (!proofStatusUrl) return;
    const now = Date.now();
    if (!force && now - lastProofRefresh < 5000) return; // throttle 5s
    lastProofRefresh = now;
    try {
      const res = await fetch(proofStatusUrl, {
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
      });
      if (!res.ok) return;
      const data = await res.json().catch(() => null);
      if (!data || !data.success || !data.badge) return;
      const badge = document.getElementById('seoProofBadge');
      const text = document.getElementById('seoProofBadgeText');
      if (!badge || !text) return;
      const newState = String(data.proof_state || 'none');
      const improved = (PROOF_RANK[newState] || 0) > (PROOF_RANK[lastProofState] || 0);
      badge.className = 'seo-proof-badge ' + String(data.badge.cls || 'muted-sm');
      const icon = badge.querySelector('.material-icons');
      if (icon) icon.textContent = String(data.badge.icon || 'help');
      text.textContent = String(data.badge.text || '');
      if (newState !== 'none') {
        // راهنمای مخصوص حالت none دیگر معنا ندارد (کلیک/فرود رسیده)
        badge.querySelector('small')?.remove();
      }
      if (improved) {
        if (newState === 'landing') notify('success', 'فرود شما تأیید شد — پاداش در سقف کامل محاسبه می‌شود.');
        else if (newState === 'click') notify('success', 'کلیک شما از مسیر رسمی ثبت شد.');
      }
      lastProofState = newState;
    } catch (_) { /* cosmetic — تازه‌سازی نشان هرگز مسیر اصلی را نمی‌شکند */ }
  }

  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshProofStatus(); });
  window.addEventListener('focus', () => refreshProofStatus());

  // R31 XSS: پیام سرور قبل از ورود به Swal html escape می‌شود
  function escHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  let tracker = null;
  let fallbackDuration = 0;
  let openedTarget = false;
  let active = true;
  let focusBlurCount = 0;
  let notifier = null;

  function notify(type, message) {
    if (!notifier && typeof window.Notyf !== 'undefined') {
      notifier = new window.Notyf({ duration: 4500, position: { x: 'left', y: 'top' }, dismissible: true });
    }
    if (notifier && typeof notifier[type] === 'function') return notifier[type](message);
    if (type === 'error') return alert(message);
    console.log(message);
  }

  function updateUI(data) {
    const duration = Number(data.duration || 0);
    const scrollDepth = Number(data.scrollDepth ?? data.scroll_depth ?? 0);
    const interactions = Number(data.interactions || 0);
    document.getElementById('durationText').textContent = duration + 's';
    document.getElementById('scrollText').textContent = Math.round(scrollDepth) + '%';
    document.getElementById('interactionText').textContent = interactions;
    const mins = Math.floor(duration / 60);
    const secs = duration % 60;
    document.getElementById('timerDisplay').textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    const btn = document.getElementById('btnComplete');
    if (btn && duration >= minDuration) btn.disabled = false;
  }

  // 🛡️ FIX-SEO-23-01: fallback دیگر هیچ سیگنال تعاملی‌ای را «ساخت» نمی‌کند.
  // قبلاً صرفِ فشردن دکمهٔ باز کردن سایت، scroll_depth=60، interactions=3،
  // pause_count>=1 و interaction_types=[external_open,return_to_task] می‌ساخت
  // و همین مقادیرِ ساختگی مستقیم در امتیاز/پاداش اثر می‌گذاشت (~۷۹٪ بازهٔ
  // پاداش بدون هیچ تعامل واقعی). اکنون fallback فقط زمانِ سپری‌شده در همین
  // صفحه (که سرور به‌هرحال به زمان سرور clamp می‌کند) و شواهد واقعیِ قابل
  // مشاهده در همین صفحه را می‌فرستد؛ بقیهٔ سیگنال‌ها صفر صادقانه‌اند. سمت
  // سرور هم سقف پاداش غیرقابل‌اثبات (seo_unverified_payout_cap_percent)
  // اعمال می‌شود.
  function fallbackData() {
    return {
      duration: fallbackDuration,
      scroll_depth: 0,
      interactions: 0,
      scroll_speed: 0,
      mouse_pattern: 'normal',
      pause_count: 0,
      interaction_types: openedTarget ? ['external_open'] : [],
      target_opened: openedTarget ? 1 : 0,
      focus_blur_count: focusBlurCount,
      active_time: fallbackDuration,
      client_mode: 'web',
      behavior: {
        scroll_speed: 0,
        mouse_pattern: 'normal',
        pause_count: 0,
        interaction_types: openedTarget ? ['external_open'] : [],
        target_opened: openedTarget ? 1 : 0,
        focus_blur_count: focusBlurCount,
        active_time: fallbackDuration,
        client_mode: 'web'
      }
    };
  }

  function engagementData() {
    const fallback = fallbackData();
    if (tracker && typeof tracker.getData === 'function') {
      const tracked = tracker.getData();
      const duration = Math.max(Number(tracked.duration || 0), fallback.duration);

      // 🛡️ FIX-SEO-23-01: دادهٔ tracker معیار است و fallback دیگر سیگنال
      // ساختگی تولید نمی‌کند که با Math.max روی دادهٔ واقعی سوار شود؛
      // fallback فقط مقادیر صفر/شواهد دکمهٔ همین صفحه را تأمین می‌کند و
      // کلیدهای غایبِ tracker را پوشش می‌دهد (Object.assign: tracked مقدم است).
      return Object.assign({}, fallback, tracked, {
        duration,
        interaction_types: fallback.interaction_types,
        target_opened: openedTarget ? 1 : Number(tracked.target_opened || 0),
        focus_blur_count: focusBlurCount,
        active_time: duration,
        client_mode: 'web'
      });
    }
    return fallback;
  }

  // 🛡️ FIX-SEO-23-TIMER: زمان با ساعت دیواری از ورود به صفحه محاسبه می‌شود، نه
  // شمارندهٔ وابسته به visibility — کاربر طبق راهنما در تب هدف می‌ماند و تایمر
  // نباید متوقف یا (به‌خاطر throttle تب پس‌زمینه) کند شود. سرور به زمان واقعی clamp می‌کند.
  // شمارش blur هم فقط با visibilitychange است (قبلاً هر جابه‌جایی ۲ بار شمرده می‌شد).
  const pageStartTs = Date.now();
  document.addEventListener('visibilitychange', () => { if (document.hidden) focusBlurCount += 1; active = !document.hidden; });
  setInterval(() => {
    fallbackDuration = Math.floor((Date.now() - pageStartTs) / 1000);
    // FIX-R12-1: بعد از حذف iframe مردهٔ CSP-بلاک‌شده، SeoTracker تایمر داخلی‌اش را
    // شروع نمی‌کند (start() بدون فریم early-return می‌کند) — پس updateUI باید هر ثانیه
    // از مسیر fallback (fallbackDuration) اجرا شود تا زمان‌سنج و دکمهٔ تکمیل زنده بمانند.
    // (FIX-SEO-23-01: دیگر فقط زمان merge می‌شود؛ سیگنال‌های تعاملی ساختگی حذف شده‌اند.)
    updateUI(engagementData());
  }, 1000);

  document.getElementById('openTargetBtn')?.addEventListener('click', function () {
    // 🛡️ FIX-SEO-23-01: openedTarget فقط با پنجرهٔ «واقعاً بازشده» ست می‌شود.
    // قبلاً صرفِ کلیک، مقدار را true می‌کرد حتی اگر popup blocker آن را بلاک
    // کرده بود. توجه: noopener در features طبق spec باعث می‌شود window.open
    // همیشه null برگرداند؛ پس بدون آن باز می‌کنیم و مرجع opener را دستی
    // قطع می‌کنیم (همان محافظت tab-nabbing، با نتیجهٔ قابل بررسی).
    if (targetUrl) {
      const win = window.open(targetUrl, '_blank');
      openedTarget = !!win;
      if (win) {
        try { win.opener = null; } catch (_) { /* cross-origin guard */ }
      }
    } else {
      openedTarget = true;
    }
    if (openedTarget) {
      notify('success', 'سایت هدف باز شد. بعد از انجام تعامل، به این صفحه برگردید و تکمیل را بزنید.');
    } else {
      notify('error', 'باز کردن سایت هدف توسط مرورگر مسدود شد. لطفاً popup blocker را غیرفعال کنید و دوباره تلاش کنید.');
    }
  });

  document.addEventListener('DOMContentLoaded', function () {
    if (typeof window.SeoTracker === 'function') {
      try {
        tracker = new window.SeoTracker({
          frameId: 'taskFrame',
          minDuration: minDuration,
          onUpdate: updateUI,
          onReady: () => {
            const btn = document.getElementById('btnComplete');
            if (btn) btn.disabled = false;
          }
        });
        tracker.start();
      } catch (_) {
        tracker = null;
      }
    }
  });

  document.getElementById('btnComplete')?.addEventListener('click', async function () {
    const data = engagementData();
    if (Number(data.duration || 0) < minDuration) {
      notify('error', `حداقل ${minDuration} ثانیه زمان برای این تسک نیاز است.`);
      return;
    }
    if (!openedTarget && !window.confirm('هنوز دکمه باز کردن سایت هدف را نزده‌اید. مطمئنید تعامل را انجام داده‌اید؟')) return;

    // 🛡️ FIX-SEO3-03: آخرین فرصت تازه‌سازی نشان پیش از بستن صفحه — یک fetch،
    // بدون بلاک شدن مسیر تکمیل در خطا (خطای آن ساکت است؛ پاداش سمت سرور است).
    await refreshProofStatus(true);

    const btn = this;
    const original = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> ارسال...';

    try {
      const response = await fetch(completeUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': csrf },
        body: JSON.stringify(Object.assign({}, data, { _csrf_token: csrf }))
      });
      const result = await response.json().catch(() => ({}));
      if (response.ok && result.success) {
        // 🛡️ FIX-M23R-10 (T23-10): ارز پاداش از پاسخ سرور (payout_currency) —
        // قبلاً «تومان» هاردکد بود و پاداش تتری غلط نمایش داده می‌شد؛ تتر
        // با دو اعشار (هم‌قرارداد money_label سمت PHP).
        const payoutCur = result.payout_currency === 'usdt' ? 'تتر' : 'تومان';
        const payoutDecimals = result.payout_currency === 'usdt' ? 2 : 0;
        const payoutAmount = Number(result.payout).toLocaleString(undefined, { minimumFractionDigits: payoutDecimals, maximumFractionDigits: payoutDecimals });
        const html = result.payout ? `پاداش: ${payoutAmount} ${payoutCur}` : escHtml(result.message || 'تسک شما دریافت شد.');
        if (typeof Swal !== 'undefined') {
          await Swal.fire({ icon: 'success', title: 'تکمیل شد', html });
        } else {
          notify('success', result.message || 'تسک تکمیل شد.');
        }
        window.location.href = returnUrl;
      } else {
        notify('error', result.message || 'تکمیل تسک انجام نشد.');
        btn.disabled = false;
        btn.innerHTML = original;
      }
    } catch (_) {
      notify('error', 'خطا در ارتباط با سرور.');
      btn.disabled = false;
      btn.innerHTML = original;
    }
  });

  document.getElementById('btnCancel')?.addEventListener('click', async function () {
    const confirmed = typeof Swal !== 'undefined'
      ? await Swal.fire({ title: 'لغو تسک؟', text: 'اگر لغو کنید این اجرای SEO بسته می‌شود.', icon: 'warning', showCancelButton: true, confirmButtonText: 'بله، لغو شود', cancelButtonText: 'ادامه می‌دهم' }).then(r => r.isConfirmed)
      : window.confirm('لغو تسک؟');
    if (!confirmed) return;

    try {
      await fetch(cancelUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-CSRF-Token': csrf }, body: new FormData() });
    } catch (_) {}
    window.location.href = returnUrl;
  });
})();
