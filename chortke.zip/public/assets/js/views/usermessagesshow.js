const form = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const messagesContainer = document.getElementById('messages-container');
const recipientId = document.querySelector('input[name="recipient_id"]').value;
let typingTimeout;

// Character counter
messageInput.addEventListener('input', (e) => {
    document.getElementById('char-count').textContent = e.target.value.length + ' / 5000';
    
    // Send typing indicator
    clearTimeout(typingTimeout);
    fetch((window.BASE_URL || '') + '/messages/typing', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': document.querySelector('[name="_csrf_token"]').value
        },
        body: JSON.stringify({ recipient_id: recipientId, is_typing: true })
    });
    
    typingTimeout = setTimeout(() => {
        fetch((window.BASE_URL || '') + '/messages/typing', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': document.querySelector('[name="_csrf_token"]').value
            },
            body: JSON.stringify({ recipient_id: recipientId, is_typing: false })
        });
    }, 3000);
});

// Send message
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = messageInput.value.trim();

    if (!message) return;

    // FIX-R36-W3 (F-A21-13): گارد دابل‌سابمیت — Enter/کلیک سریع دیگر پیام DM تکراری نمی‌فرستد.
    // دکمه تا پایان درخواست بسته می‌شود؛ در موفقیت تا reload بسته می‌ماند، فقط در شکست آزاد می‌شود.
    if (form.dataset.sending === '1') return;
    const sendBtn = form.querySelector('button[type="submit"], input[type="submit"], button:not([type])');
    form.dataset.sending = '1';
    if (sendBtn) sendBtn.disabled = true;

    try {
        const response = await fetch((window.BASE_URL || '') + '/messages/send', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': document.querySelector('[name="_csrf_token"]').value
            },
            body: JSON.stringify({
                recipient_id: recipientId,
                message: message,
                is_encrypted: false
            })
        });

        if (response.ok) {
            messageInput.value = '';
            document.getElementById('char-count').textContent = '0 / 5000';
            // Reload messages
            loadMessages();
        } else {
            form.dataset.sending = ''; // FIX-R36-W3 (F-A21-13): شکست → قفل آزاد شود
            if (sendBtn) sendBtn.disabled = false;
        }
    } catch (error) {
        form.dataset.sending = ''; // FIX-R36-W3 (F-A21-13)
        if (sendBtn) sendBtn.disabled = false;
        console.error('Error sending message:', error);
    }
});

// Load messages periodically
function loadMessages() {
    // This would typically be a real-time update with WebSocket
    // For now, a simple implementation
    location.reload();
}

// Typing indicator listener
setInterval(() => {
    fetch((window.BASE_URL || '') + `/messages/typing/users?recipient_id=${recipientId}`)
        .then(r => r.json())
        .then(data => {
            const indicator = document.getElementById('typing-indicator');
            if (data.typing_users > 0) {
                indicator.textContent = 'در حال تایپ...';
            } else {
                indicator.textContent = '';
            }
        });
}, 1000);

// Auto-scroll to bottom
messagesContainer.scrollTop = messagesContainer.scrollHeight;

// ── R88 (راند ۸۸): دکمهٔ «گزارش این پیام» ──────────────────────────────
// فقط روی پیام‌های دریافتی رندر می‌شود (data-report-message). قرارداد همان
// الگوی fetch موجود این فایل است: POST /messages/{id}/report با JSON {reason}
// و هدر X-CSRF-Token از فیلد [name="_csrf_token"] (CSP-safe — بدون eval/inline).
document.querySelectorAll('[data-report-message]').forEach((reportBtn) => {
    reportBtn.addEventListener('click', async () => {
        const messageId = reportBtn.getAttribute('data-report-message');
        const reason = window.prompt('دلیل گزارش این پیام (حداقل ۳ کاراکتر):');
        if (reason === null) return; // کاربر انصراف داد
        const trimmed = reason.trim();
        if (trimmed.length < 3) {
            window.alert('دلیل باید حداقل ۳ کاراکتر باشد');
            return;
        }

        try {
            const response = await fetch((window.BASE_URL || '') + `/messages/${encodeURIComponent(messageId)}/report`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('[name="_csrf_token"]').value
                },
                body: JSON.stringify({ reason: trimmed })
            });
            const json = await response.json().catch(() => ({}));

            if (response.ok && json.success) {
                reportBtn.disabled = true;
                reportBtn.textContent = 'گزارش شد';
                window.alert(json.message || 'گزارش شما ثبت شد.');
            } else {
                window.alert(json.message || 'خطا در گزارش');
            }
        } catch (error) {
            console.error('Error reporting message:', error);
            window.alert('خطا در گزارش');
        }
    });
});