(function () {
  'use strict';

  const fileInput = document.getElementById('verificationImage');
  const previewBox = document.getElementById('kycPreviewBox');
  const previewImg = document.getElementById('previewImg');
  const submitBtn = document.getElementById('submitBtn');
  const confirmCheck = document.getElementById('confirmCheck');
  const ncInput = document.getElementById('national_code');
  const jySel = document.getElementById('birth_jy');
  const jmSel = document.getElementById('birth_jm');
  const jdSel = document.getElementById('birth_jd');
  const birthHidden = document.getElementById('birth_date');
  let notifier = null;

  // ── تاریخ تولد شمسی (FIX-KYC-JALALI) ─────────────────────────
  // سه select شمسی ساخته می‌شود و معادل میلادی در hidden birth_date
  // قرار می‌گیرد. تبدیل نهایی سمت سرور هم انجام می‌شود (دو لایه دفاعی).
  const JMONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
  // سال جاری شمسی را از سرور می‌گیریم (var present در صفحه؟) — fallback محاسبه دستی
  function currentJalaliYear() {
    const now = new Date();
    // شروع سال شمسی حدود 21 مارس (روز 80 میلادی)
    const gy = now.getFullYear();
    const isBeforeNewYear = (now.getMonth() + 1) < 3 || ((now.getMonth() + 1) === 3 && now.getDate() < 21);
    return gy - 621 - (isBeforeNewYear ? 1 : 0);
  }
  function isJalaliLeap(jy) {
    // الگوریتم رایج (Birashk-33): باقی‌مانندهای نامبرده سال کبیسه‌اند
    const r = jy % 33;
    return [1, 5, 9, 13, 17, 22, 26, 30].includes(r);
  }
  function jalaliMonthLength(jy, jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    return isJalaliLeap(jy) ? 30 : 29;
  }
  function fillDays() {
    if (!jdSel || !jySel?.value || !jmSel?.value) return;
    const prev = jdSel.value;
    const len = jalaliMonthLength(parseInt(jySel.value, 10), parseInt(jmSel.value, 10));
    jdSel.innerHTML = '<option value="">روز</option>';
    for (let d = 1; d <= len; d++) {
      const o = document.createElement('option');
      o.value = String(d); o.textContent = toFa(d);
      jdSel.appendChild(o);
    }
    if (prev && parseInt(prev, 10) <= len) jdSel.value = prev;
    syncBirth();
  }
  function toFa(n) { return String(n).replace(/[0-9]/g, c => '۰۱۲۳۴۵۶۷۸۹'[c]); }
  function fillJalaliSelects() {
    if (!jySel || !jmSel || !jdSel) return;
    const thisYear = currentJalaliYear();
    const minYear = thisYear - 100; // min قبلی: 100 سال
    const maxYear = thisYear - 18;  // min قبلی: 18 سال
    jySel.innerHTML = '<option value="">سال</option>';
    for (let y = maxYear; y >= minYear; y--) {
      const o = document.createElement('option');
      o.value = String(y); o.textContent = toFa(y);
      jySel.appendChild(o);
    }
    jmSel.innerHTML = '<option value="">ماه</option>';
    JMONTHS.forEach((name, i) => {
      const o = document.createElement('option');
      o.value = String(i + 1); o.textContent = name;
      jmSel.appendChild(o);
    });
    fillDays();
  }
  function syncBirth() {
    if (!birthHidden) return;
    const y = jySel?.value, m = jmSel?.value, d = jdSel?.value;
    birthHidden.value = (y && m && d) ? `${y}/${String(m).padStart(2, '0')}/${String(d).padStart(2, '0')}` : '';
    updateSubmitBtn();
  }
  jySel?.addEventListener('change', fillDays);
  jmSel?.addEventListener('change', fillDays);
  jdSel?.addEventListener('change', syncBirth);
  fillJalaliSelects();

  function notify(type, message) {
    if (!notifier && typeof window.Notyf !== 'undefined') {
      notifier = new window.Notyf({ duration: 4500, position: { x: 'left', y: 'top' }, dismissible: true });
    }
    if (notifier && typeof notifier[type] === 'function') return notifier[type](message);
    alert(message);
  }

  function updateSubmitBtn() {
    const hasFile = fileInput?.files?.length > 0;
    const hasConfirm = !!confirmCheck?.checked;
    const hasNc = (ncInput?.value || '').length === 10;
    const hasBirth = !!(birthHidden?.value || '');
    if (submitBtn) submitBtn.disabled = !(hasFile && hasConfirm && hasNc && hasBirth);
  }

  ncInput?.addEventListener('input', function () {
    // FIX-R36-W3 (F-A20-10): ارقام فارسی/عربی و جداکننده‌ها پیش از فیلتر [^0-9] نرمال می‌شوند —
    // «کد ملی» تایپ‌شده با کیبورد فارسی دیگر بی‌صدا حذف نمی‌شود (توابع مرجع: ux-extras.js)
    const normalized = window.chortkeNormalizeDigits ? window.chortkeNormalizeDigits(this.value) : this.value;
    this.value = normalized.replace(/[^0-9]/g, '').slice(0, 10);
    updateSubmitBtn();
  });

  fileInput?.addEventListener('change', function () {
    const file = this.files && this.files[0] ? this.files[0] : null;
    if (!file) return updateSubmitBtn();
    if (file.size > 5 * 1024 * 1024) { notify('error', 'حجم فایل نباید بیشتر از ۵ مگابایت باشد'); this.value = ''; return updateSubmitBtn(); }
    // 🛡️ FIX-S10-18: هم‌ترازی با سمتِ سرور — آداپتور/آپلود WebP و GIF را هم
    // می‌پذیرد؛ قبلاً کلاینت فقط JPG/PNG می‌داد (محدودیتِ بی‌دلیل برای کاربر).
    if (!['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif'].includes(file.type)) { notify('error', 'فقط فرمتهای JPG، PNG، WebP و GIF مجاز است'); this.value = ''; return updateSubmitBtn(); }
    const reader = new FileReader();
    reader.onload = e => {
      if (previewImg) previewImg.src = e.target.result;
      if (previewBox) previewBox.style.display = 'flex';
    };
    reader.readAsDataURL(file);
    updateSubmitBtn();
  });

  confirmCheck?.addEventListener('change', updateSubmitBtn);

  document.getElementById('kycForm')?.addEventListener('submit', function () {
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="material-icons" style="animation:spin .8s linear infinite">refresh</i> در حال ارسال...';
    }
  });

  const style = document.createElement('style');
  style.textContent = '@keyframes spin{to{transform:rotate(360deg)}}';
  document.head.appendChild(style);
  updateSubmitBtn();
})();
