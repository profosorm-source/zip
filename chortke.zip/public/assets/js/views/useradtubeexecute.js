(function () {
  'use strict';
  const script = document.currentScript;
  // 🛡️ FIX-YT-7: مدت سنجش فقط از سرور (data-duration = مدت واقعی ویدیو) — بدون fallback ۳۰
  const totalDuration = parseInt(script?.dataset.duration || '0', 10);
  if (!Number.isFinite(totalDuration) || totalDuration <= 0) {
    // بدون مدت معتبر: هیچ تایمری و هیچ ارسالی — fail-closed (سرور هم رد می‌کند)
    const btn = document.getElementById('btnSubmit');
    if (btn) { btn.disabled = true; btn.title = 'مدت ویدیو ثبت نشده است'; }
    return;
  }

  // ═══ 🛡️ FIX-S20-CLOSE-F1 (پایان‌کار بازبینی S20 — یافتهٔ ۱): سیگنال پخش واقعی ═══
  // تایمر قبلی «زمان باز بودن صفحه» را می‌شمرد — نه «زمان پخش». اکنون:
  //   ۱) وضعیت واقعی پلیر یوتیوب (IFrame API: play/pause/end) رصد می‌شود؛
  //   ۲) شمارندهٔ played فقط وقتی پیش می‌رود که پلیر واقعاً در حال پخش باشد؛
  //   ۳) هر ۵ ثانیه heartbeat با شمارندهٔ تجمعی به سرور می‌رود؛ سرور با ساعت
  //      خودش افزایش را به ۱× کلمپ می‌کند و «بدون این سیگنال» پاداش نمی‌دهد
  //      (تسویهٔ سرور fail-closed است — تایمر/ادعای فرم به‌تنهایی کافی نیست)؛
  //   ۴) ویدیوی کوتاه‌تر از مدت لازم، برای تکمیل زمان به‌طور خودکار دوباره
  //      پخش می‌شود (پخشِ واقعی، نه شمارش صوری).
  const watchedSeconds = document.getElementById('watchedSeconds');
  const watchTimeInput = document.getElementById('watchTime');
  const progressPercentInput = document.getElementById('progressPercent');
  const playerDurationInput = document.getElementById('playerDuration');
  const watchChallengeInput = document.getElementById('watchChallenge');
  const waitAlert = document.getElementById('waitAlert');
  const btnSubmit = document.getElementById('btnSubmit');

  const ytOrigin = 'https://www.youtube-nocookie.com';
  const YT_STATE_ENDED = 0, YT_STATE_PLAYING = 1, YT_STATE_PAUSED = 2, YT_STATE_BUFFERING = 3, YT_STATE_UNSTARTED = -1;

  let playerState = YT_STATE_UNSTARTED; // تا اولین پیام پلیر، «شروع‌نشده» فرض می‌شود
  let playerDurationReported = 0;
  let played = 0;          // ثانیه‌های «در حال پخش» — تنها ارز معتبر تماشا
  let heartbeatSeq = 0;
  let heartbeatFailures = 0;
  let replayCount = 0;
  const MAX_AUTO_REPLAYS = 10;

  function ytPost(payload) {
    const frame = document.getElementById('ytFrame');
    if (!frame || !frame.contentWindow) return;
    try { frame.contentWindow.postMessage(JSON.stringify(payload), ytOrigin); } catch (e) { /* deterrence best-effort */ }
  }
  function handshakePlayer() {
    if (playerDurationReported <= 0) {
      ytPost({ event: 'command', func: 'getDuration', args: [] });
    }
  }
  function isPlaying() {
    // فقط state=PLAYING شمرده می‌شود (buffering/ended/paused/unstarted = نه)
    return playerState === YT_STATE_PLAYING;
  }

  window.addEventListener('message', function (ev) {
    try {
      if (typeof ev.origin !== 'string' || !/(^|\.)youtube(-nocookie)?\.com$/.test(new URL(ev.origin).hostname)) return;
      const data = JSON.parse(typeof ev.data === 'string' ? ev.data : '{}');
      if (!data || typeof data.event !== 'string') return;

      if (data.event === 'onReady') {
        handshakePlayer();
        return;
      }
      // FIX-S20-CLOSE-F1: وضعیت واقعی پلیر — منبع حقیقتِ «در حال پخش بودن»
      if (data.event === 'onStateChange' && typeof data.info === 'number') {
        const prev = playerState;
        playerState = data.info;
        if (playerState === YT_STATE_ENDED && played < totalDuration && replayCount < MAX_AUTO_REPLAYS) {
          // ویدیوی کوتاه‌تر از مدت لازم: پخشِ واقعیِ مجدد (نه شمارش صوری)
          replayCount++;
          setTimeout(function () {
            ytPost({ event: 'command', func: 'seekTo', args: [0, true] });
            ytPost({ event: 'command', func: 'playVideo', args: [] });
          }, 400);
        }
        if (playerState === YT_STATE_PLAYING && (prev === YT_STATE_UNSTARTED || heartbeatSeq === 0)) {
          // اولین پخش واقعی: heartbeat بلافاصله مبنا را در سرور می‌گذارد
          sendHeartbeat();
        }
        return;
      }
      if (data.event === 'infoDelivery' && data.info && typeof data.info === 'object') {
        if (typeof data.info.duration === 'number' && data.info.duration > 0 && playerDurationReported <= 0) {
          playerDurationReported = Math.round(data.info.duration);
          if (playerDurationInput) playerDurationInput.value = String(playerDurationReported);
        }
      }
    } catch (e) { /* ignore malformed */ }
  });

  // handshake: پس از listening، پلیر onStateChange و infoDelivery می‌فرستد
  ytPost({ event: 'listening', id: 1, channel: 'widget' });
  handshakePlayer();
  const durationPoller = setInterval(handshakePlayer, 3000);

  // ─── رابط وضعیت ───
  function paintWaiting() {
    if (!waitAlert) return;
    if (playerState === YT_STATE_UNSTARTED) {
      waitAlert.className = 'alert alert-warning d-flex align-items-center gap-2';
      waitAlert.innerHTML = '<span class="material-icons">play_circle</span><div>برای شروع شمارش، ویدیو را پخش کنید. زمان فقط هنگام پخش واقعی پیش می‌رود.</div>';
    } else if (playerState === YT_STATE_PAUSED) {
      waitAlert.className = 'alert alert-secondary d-flex align-items-center gap-2';
      waitAlert.innerHTML = '<span class="material-icons">pause_circle</span><div>پخش متوقف است — شمارش متوقف شد. برای ادامه، ویدیو را پخش کنید.</div>';
    } else if (playerState === YT_STATE_ENDED) {
      waitAlert.className = 'alert alert-info d-flex align-items-center gap-2';
      waitAlert.innerHTML = '<span class="material-icons">replay</span><div>ویدیو به پایان رسید؛ برای تکمیل زمان تماشا دوباره پخش می‌شود…</div>';
    } else if (playerState === YT_STATE_PLAYING && heartbeatFailures < 3) {
      waitAlert.className = 'alert alert-warning d-flex align-items-center gap-2';
      waitAlert.innerHTML = '<span class="material-icons">timer</span><div>در حال پخش — زمان فقط همین‌طور پیش می‌رود. باقی‌مانده: <strong id="countdown">' + Math.max(0, totalDuration - played) + '</strong> ثانیه</div>';
    }
  }

  // ─── tick یک‌ثانیه‌ای: فقط هنگام پخش واقعی می‌شمارد ───
  const timer = setInterval(() => {
    if (isPlaying()) {
      played++;
    }
    const remaining = Math.max(0, totalDuration - played);
    const progress = Math.min(100, Math.round((played / totalDuration) * 100));

    // paintWaiting ممکن است innerHTML هشدار را بازنویسی کند → هر بار گرفتنِ تازهٔ countdown
    const countdownEl = document.getElementById('countdown');
    if (countdownEl) countdownEl.textContent = String(remaining);
    if (watchedSeconds) watchedSeconds.value = String(played);
    if (watchTimeInput) watchTimeInput.value = String(played);
    if (progressPercentInput) progressPercentInput.value = String(progress);

    if (played >= totalDuration) {
      clearInterval(timer);
      clearInterval(durationPoller);
      if (waitAlert) {
        waitAlert.className = 'alert alert-success d-flex align-items-center gap-2';
        waitAlert.innerHTML = '<span class="material-icons">check_circle</span><div>تماشا کامل شد! روی دکمه زیر کلیک کنید.</div>';
      }
      if (btnSubmit) btnSubmit.disabled = false;
      return; // پس از تکمیل، دیگر رنگ وضعیت بازنویسی نمی‌شود
    }
    paintWaiting();
  }, 1000);

  // ─── heartbeat: گزارش دوره‌ای شمارندهٔ تجمعی به سرور (منبع پاداش) ───
  function sendHeartbeat() {
    heartbeatSeq++;
    const headers = {
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest',
      'X-CSRF-Token': (document.querySelector('meta[name="csrf-token"]') || {}).content || ''
    };
    fetch(window.location.pathname.replace(/\/execute$/, '') + '/heartbeat', {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({
        watch_challenge: watchChallengeInput ? watchChallengeInput.value : '',
        played_seconds: played,
        playing: isPlaying(),
        seq: heartbeatSeq
      })
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d && d.success === true) {
          heartbeatFailures = 0;
        } else {
          heartbeatFailures++;
        }
      })
      .catch(function () { heartbeatFailures++; });
  }
  const heartbeatTimer = setInterval(() => {
    // تا وقتی اجرا نهایی نشده (دکمه فعال) سیگنال می‌رود؛ پس از فعال شدن دکمه هم
    // چند beat نهایی می‌رود تا انباشتهٔ سرور با تماشای واقعی هم‌گام بماند.
    if (played >= totalDuration && heartbeatFailures === 0 && heartbeatSeq > 0) {
      // پس از تکمیل: فقط اگر beat موفق آخر نرسیده باشد ادامه بده — ساده: بایست
      clearInterval(heartbeatTimer);
      return;
    }
    sendHeartbeat();
    if (heartbeatFailures >= 3 && waitAlert && played < totalDuration) {
      waitAlert.className = 'alert alert-danger d-flex align-items-center gap-2';
      waitAlert.innerHTML = '<span class="material-icons">wifi_off</span><div>سیگنال پخش به سرور نمی‌رسد؛ اتصال خود را بررسی کنید — بدون آن پاداش ثبت نمی‌شود.</div>';
    }
  }, 5000);
})();
