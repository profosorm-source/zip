(function () {
  'use strict';

  document.querySelectorAll('.sup-priority-opt input').forEach(function (radio) {
    radio.addEventListener('change', function () {
      document.querySelectorAll('.sup-priority-opt').forEach(el => el.classList.remove('active'));
      radio.closest('.sup-priority-opt')?.classList.add('active');
    });
  });

  document.getElementById('attachFiles')?.addEventListener('change', function () {
    const preview = document.getElementById('filePreview');
    if (!preview) return;
    preview.innerHTML = '';
    Array.from(this.files || []).forEach(function (file) {
      const chip = document.createElement('span');
      chip.className = 'sup-file-chip';
      // FIX-R36-W3 (F-A20-08): نام فایل کاربر با textContent — نه innerHTML (self-XSS بسته شد)
      const icon = document.createElement('i');
      icon.className = 'material-icons';
      icon.textContent = 'insert_drive_file';
      chip.appendChild(icon);
      chip.appendChild(document.createTextNode(file.name));
      preview.appendChild(chip);
    });
  });
})();
