// FIX-BANK-BIN-UX: تشخیص خودکار بانک از BIN (۶ رقم اول) — همگام با سرور
// BankCardService::detectBankName. سرور نام بانک را از BIN تعیین می‌کند؛
// اینجا همان نگاشت در UI اعمال می‌شود تا کاربر نتیجه را همان لحظه ببیند.
const BIN_BANKS = {
    '603799': 'ملی',
    '589210': 'سپه',
    '610433': 'ملت',
    '991975': 'ملت',
    '627961': 'صنعت و معدن',
    '603770': 'کشاورزی',
    '628023': 'مسکن',
    '627760': 'پست بانک',
    '502908': 'توسعه تعاون',
    '627412': 'اقتصاد نوین',
    '622106': 'پارسیان',
    '502229': 'پاسارگاد',
    '639607': 'صادرات',
    '627488': 'کارآفرین',
    '621986': 'سامان',
    '639346': 'سینا',
    '504706': 'شهر',
    '636214': 'آینده',
    '505785': 'تجارت',
    '589463': 'رفاه',
    '606256': 'ملل',
    '639599': 'قوامین',
    '505801': 'گردشگری',
    '606373': 'معارف',
    '502910': 'دی',
    '505416': 'خاورمیانه',
    '502938': 'مهر ایران',
};

document.getElementById('card_number').addEventListener('input', function(e) {
    // FIX-R36-W3 (F-A20-10): ارقام فارسی/عربی و جداکننده‌ها پیش از فیلتر نرمال می‌شوند (توابع مرجع: ux-extras.js)
    let value = window.chortkeNormalizeDigits ? window.chortkeNormalizeDigits(e.target.value) : e.target.value;
    value = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    let formattedValue = value.match(/.{1,4}/g)?.join('-') || value;
    e.target.value = formattedValue;

    // تشخیص بانک از BIN + به‌روزرسانی select و راهنما
    const bankSelect = document.getElementById('bank_name');
    const hint = document.getElementById('binDetectHint');
    const staticHint = document.getElementById('bankHint');
    if (!bankSelect || !hint) return;

    const digits = value; // همان اعداد خام کارت
    if (digits.length >= 6) {
        const bin = digits.slice(0, 6);
        const bank = BIN_BANKS[bin];
        if (bank) {
            // فقط اگر چنین گزینه‌ای وجود دارد مقداردهی کن
            const opt = Array.from(bankSelect.options).find(o => o.value === bank);
            if (opt) {
                bankSelect.value = bank;
                hint.textContent = '✓ بانک از BIN شناسایی شد: ' + opt.textContent;
                hint.style.color = '#0ecb81';
                hint.style.display = 'block';
                if (staticHint) staticHint.style.display = 'none';
            }
        } else {
            // FIX-T2: برای BIN ناشناخته انتخاب دستی کاربر اکنون سمت سرور به‌عنوان نام بانک ثبت می‌شود
            hint.textContent = '⚠ این BIN در سیستم شناخته نشده است — بانک را از فهرست انتخاب کنید؛ همان ثبت می‌شود (اگر نیست، «سایر»).';
            hint.style.color = '#f6465d';
            hint.style.display = 'block';
            if (staticHint) staticHint.style.display = 'none';
        }
    } else {
        hint.style.display = 'none';
        if (staticHint) staticHint.style.display = 'block';
    }
});

// فقط اعداد برای شبا
document.getElementById('sheba').addEventListener('input', function(e) {
    // FIX-R36-W3 (F-A20-10)
    const normalized = window.chortkeNormalizeDigits ? window.chortkeNormalizeDigits(e.target.value) : e.target.value;
    e.target.value = normalized.replace(/[^0-9]/gi, '');
});

// اعتبارسنجی فرم
document.getElementById('bankCardForm').addEventListener('submit', function(e) {
    const cardNumber = document.getElementById('card_number').value.replace(/-/g, '');
    
    if (cardNumber.length !== 16) {
        e.preventDefault();
        notyf.error('شماره کارت باید 16 رقم باشد');
        return false;
    }
    
    const sheba = document.getElementById('sheba').value;
    if (sheba && sheba.length !== 24) {
        e.preventDefault();
        notyf.error('شماره شبا باید 24 رقم باشد');
        return false;
    }
});