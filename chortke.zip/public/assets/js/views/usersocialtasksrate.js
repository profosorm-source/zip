/**
 * 🛡️ FIX-SOCRATE-VOTE-EXEC-01 (قرینهٔ userseoshowexecution.js — بخش امتیاز):
 * امتیازدهی به کمپین سوشیال از داخل خود صفحهٔ اجرا. کارت فقط برای اجرای
 * approved رندر می‌شود (تصمیم سرور)؛ بدون کارت این اسکریپت بی‌اثر است.
 *
 * ثبت از همان مسیر گاردشدهٔ سرویس (SocialTaskService::rateTask) انجام
 * می‌شود — بدون سیگنال پولی/تعاملی. میانگین محلی تازه نمی‌شود؛ منبع
 * حقیقت رندر بعدی سرور است (همان قرارداد سئو).
 */
(function () {
  'use strict';

  const card = document.getElementById('socRateCard');
  if (!card) return;

  const csrf = card.dataset.csrf || window.csrfToken || document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
  const rateUrl = card.dataset.rateUrl || '';

  function notify(type, message) {
    if (type === 'warning') type = 'error'; // Notyf متد warning ندارد
    const n = window.notyf
      || (typeof window.Notyf !== 'undefined' ? new window.Notyf({ duration: 4500, position: { x: 'left', y: 'top' }, dismissible: true }) : null);
    if (n) { try { return n[type](message); } catch (_) { /* fallthrough */ } }
    if (type === 'error') return alert(message);
    console.log(message);
  }

  // ── امتیازدهی ─────────────────────────────────────────────────
  let selectedStars = 0;
  const starBtns = Array.from(card.querySelectorAll('.soc-star-btn'));
  const rateBtn = document.getElementById('socRateBtn');

  function paintStars(n) {
    starBtns.forEach(b => b.classList.toggle('active', Number(b.dataset.stars || 0) <= n));
  }

  starBtns.forEach(btn => btn.addEventListener('click', function () {
    selectedStars = Number(this.dataset.stars || 0);
    paintStars(selectedStars);
    if (rateBtn) rateBtn.disabled = false;
  }));

  rateBtn?.addEventListener('click', async function () {
    if (selectedStars < 1 || selectedStars > 5) { notify('error', 'ابتدا امتیاز (۱ تا ۵ ستاره) را انتخاب کنید.'); return; }
    const comment = (document.getElementById('socRateComment')?.value || '').trim();

    const btn = this;
    btn.disabled = true;
    try {
      const res = await fetch(rateUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': csrf },
        body: JSON.stringify({ _csrf_token: csrf, stars: selectedStars, comment })
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success) {
        const my = document.getElementById('socMyRatingText');
        if (my) my.textContent = String(selectedStars);
        notify('success', data.message || 'امتیاز ثبت شد.');
        // میانگین محلی را تازه نمی‌کنیم — منبع حقیقت رندر بعدی سرور است.
      } else {
        notify('error', String(data.message || 'ثبت امتیاز انجام نشد.'));
      }
    } catch (_) {
      notify('error', 'خطا در ارتباط با سرور.');
    } finally {
      btn.disabled = false;
    }
  });
})();
