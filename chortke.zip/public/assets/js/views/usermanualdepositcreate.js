function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        notyf.success('کپی شد!');
    }).catch(err => {
        notyf.error('خطا در کپی کردن');
    });
}

// اعتبارسنجی فایل
document.getElementById('receipt_image')?.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        // بررسی حجم (2MB)
        if (file.size > 2 * 1024 * 1024) {
            notyf.error('حجم فایل نباید بیشتر از 2 مگابایت باشد');
            e.target.value = '';
            return;
        }
        
        // بررسی فرمت
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        if (!allowedTypes.includes(file.type)) {
            notyf.error('فقط فرمت JPG و PNG مجاز است');
            e.target.value = '';
            return;
        }
    }
});

// ✅ Initialize Security Fields
(function() {
    // Generate Idempotency Key (once per page load)
    if (!document.getElementById('idempotencyKey').value) {
        document.getElementById('idempotencyKey').value = generateIdempotencyKey();
    }
    
    // Generate Device Fingerprint
    document.getElementById('deviceFingerprint').value = generateDeviceFingerprint();
    
    // FIX-OP3: فیلد مردهٔ request_timestamp حذف شد — هیچ مسیر backend آن را
    // نمی‌خواند؛ listener قبلی فقط Date.now() را در فیلد بی‌مصرف می‌نوشت.

    console.log('🔐 Security initialized for manual deposit');
})();

/**
 * Generate unique Idempotency Key
 * FIX-R36-W3 (F-A20-12): الگوریتم یکنواخت — پیاده‌سازی مرجع در ux-extras.js
 * (crypto.randomUUID → crypto.getRandomValues → آخرین لایهٔ fallback). نسخهٔ
 * قبلی با Math.random به‌عنوان منبع اصلی، ضعیف‌ترین حلقهٔ زنجیرهٔ idempotency بود.
 */
function generateIdempotencyKey() {
    if (window.chortkeIdempotencyKey) return window.chortkeIdempotencyKey('MDP_');
    return 'MDP_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
}

/**
 * Generate Device Fingerprint
 * FIX-R36-W3 (F-A20-12): اثر انگشت یکنواخت FNV-1a دوردُر (مرجع: ux-extras.js)؛
 * بدنهٔ djb2 محلی فقط fallbackِ نبودِ فایل مشترک است.
 */
function generateDeviceFingerprint() {
    if (window.chortkeDeviceFingerprint) return window.chortkeDeviceFingerprint();
    const components = [
        navigator.userAgent,
        navigator.language || navigator.userLanguage,
        screen.width + 'x' + screen.height + 'x' + screen.colorDepth,
        new Date().getTimezoneOffset(),
        navigator.hardwareConcurrency || 'unknown',
        navigator.deviceMemory || 'unknown'
    ];

    const str = components.join('|');
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }

    return Math.abs(hash).toString(16).padStart(16, '0').substring(0, 16);
}
// FIX-X111: مهاجرت دلیگیشن قدیمی به قرارداد X106 (ChortkeActions)
window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    'copy-to-clipboard': function () {
        const text = this.dataset.text;
        if (text) {
            copyToClipboard(text);
        }
    }
});
