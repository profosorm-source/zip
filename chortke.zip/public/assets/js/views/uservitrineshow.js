const vitrineScript = document.currentScript;
const CSRF = document.querySelector('meta[name="csrf-token"]')?.content || window.csrfToken || '';
const ID = vitrineScript?.dataset.id || '';
const BASE_URL = (vitrineScript?.dataset.baseUrl || '/vitrine').replace(/\/$/, '');
const REQUEST_BASE_URL = (vitrineScript?.dataset.requestBaseUrl || '/vitrine/request').replace(/\/$/, '');
const headers = { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF };

// FIX-R36-W3 (F-A20-09): گارد in-flight مشترک اکشن‌های اسکرو — دبل‌کلیک در پنجرهٔ ۱.۵-۱.۸ ثانیه‌ای تا reload دیگر درخواست دوبل نمی‌زند
var actionBusy = false;
function beginAction() { if (actionBusy) return false; actionBusy = true; return true; }
function endAction() { actionBusy = false; }

function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `alert alert-${type} position-fixed shadow`;
  el.style.cssText = 'top:20px;left:50%;transform:translateX(-50%);z-index:9999;min-width:280px;text-align:center;';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ─── علاقه‌مندی ─────────────────────────────────────────────────────────────
function toggleWatch() {
  // FIX-X108: المنت از this می‌آید (قرارداد X106c) — مقاوم به هر رفتار args
  const btn = (this instanceof Element) ? this : document.getElementById('watchBtn');
  if (!btn) return;
  if (!beginAction()) return; // FIX-R36-W3 (F-A20-09)
  fetch(`${BASE_URL}/${encodeURIComponent(ID)}/watch`, { method: 'POST', headers })
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        toast(d.message, 'info');
        const icon = btn.querySelector('.material-icons');
        const cnt  = document.getElementById('watchCount');
        const isNow = d.watched;
        if (icon) icon.textContent = isNow ? 'bookmark' : 'bookmark_border';
        btn.className = `btn btn-outline-${isNow ? 'warning' : 'secondary'} btn-sm`;
        if (cnt) cnt.textContent = parseInt(cnt.textContent || 0) + (isNow ? 1 : -1);
      } else toast(d.message, 'danger');
      endAction(); // FIX-R36-W3 (F-A20-09): بدون reload — قفل همیشه آزاد شود
    })
    .catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); }); // FIX-R36-W3 (F-A20-09)
}

// ─── درخواست خرید ────────────────────────────────────────────────────────────
function openRequestModal() {
  new bootstrap.Modal(document.getElementById('requestModal')).show();
}

function submitRequest() {
  const msg   = document.getElementById('requestMessage').value.trim();
  const price = document.getElementById('offerPrice').value;
  if (!msg) { toast('پیام به فروشنده الزامی است.', 'warning'); return; }
  if (!beginAction()) return; // FIX-R36-W3 (F-A20-09)

  fetch(`${BASE_URL}/${encodeURIComponent(ID)}/request`, {
    method: 'POST', headers,
    body: JSON.stringify({ message: msg, offer_price: price || null })
  }).then(r => r.json()).then(d => {
    bootstrap.Modal.getInstance(document.getElementById('requestModal'))?.hide();
    toast(d.message, d.success ? 'success' : 'danger');
    endAction(); // بدون reload — قفل آزاد شود
  }).catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); }); // FIX-R36-W3 (F-A20-09)
}

// ─── پیشنهاد فروش (آگهی خریدار) ────────────────────────────────────────────
function openContactModal() {
  new bootstrap.Modal(document.getElementById('contactModal')).show();
}

function submitContact() {
  const msg   = document.getElementById('contactMessage').value.trim();
  const price = document.getElementById('contactOfferPrice').value;
  if (!msg || !price) { toast('قیمت و توضیحات الزامی هستند.', 'warning'); return; }
  if (!beginAction()) return; // FIX-R36-W3 (F-A20-09)

  fetch(`${BASE_URL}/${encodeURIComponent(ID)}/request`, {
    method: 'POST', headers,
    body: JSON.stringify({ message: msg, offer_price: price })
  }).then(r => r.json()).then(d => {
    bootstrap.Modal.getInstance(document.getElementById('contactModal'))?.hide();
    toast(d.message, d.success ? 'success' : 'danger');
    endAction(); // بدون reload — قفل آزاد شود
  }).catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); }); // FIX-R36-W3 (F-A20-09)
}

// ─── پذیرش / رد درخواست ────────────────────────────────────────────────────
function acceptRequest(reqId) {
  // FIX-X108: reqId از data-req-id روی خود المنت (this) — نه از args رویداد
  const id = (typeof reqId === 'string' && reqId) ? reqId : (this instanceof Element ? this.dataset.reqId : '');
  if (!id) return;
  if (!beginAction()) return; // FIX-R36-W3 (F-A20-09)
  if (!confirm('درخواست این خریدار پذیرفته شود؟')) { endAction(); return; }
  fetch(`${REQUEST_BASE_URL}/${encodeURIComponent(id)}/accept`, { method: 'POST', headers, body: '{}' })
    .then(r => r.json())
    .then(d => { toast(d.message, d.success ? 'success' : 'danger'); if (d.success) setTimeout(() => location.reload(), 1500); else endAction(); })
    .catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); }); // FIX-R36-W3 (F-A20-09)
}

function rejectRequest(reqId) {
  // FIX-X108: reqId از data-req-id روی خود المنت (this) — نه از args رویداد
  const id = (typeof reqId === 'string' && reqId) ? reqId : (this instanceof Element ? this.dataset.reqId : '');
  if (!id) return;
  if (!beginAction()) return; // FIX-R36-W3 (F-A20-09)
  if (!confirm('این درخواست رد شود؟')) { endAction(); return; }
  fetch(`${REQUEST_BASE_URL}/${encodeURIComponent(id)}/reject`, { method: 'POST', headers, body: '{}' })
    .then(r => r.json())
    .then(d => { toast(d.message, d.success ? 'success' : 'danger'); if (d.success) setTimeout(() => location.reload(), 1500); else endAction(); })
    .catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); }); // FIX-R36-W3 (F-A20-09)
}

// ─── خرید / قفل escrow ──────────────────────────────────────────────────────
function buyListing() {
  if (!beginAction()) return; // FIX-R36-W3 (F-A20-09)
  if (!confirm('آیا از پرداخت اطمینان دارید؟ مبلغ تا تایید شما در escrow نگه داشته می‌شود.')) { endAction(); return; }
  fetch(`${BASE_URL}/${encodeURIComponent(ID)}/buy`, { method: 'POST', headers, body: '{}' })
    .then(r => r.json())
    .then(d => { toast(d.message, d.success ? 'success' : 'danger'); if (d.success) setTimeout(() => location.reload(), 1800); else endAction(); })
    .catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); }); // FIX-R36-W3 (F-A20-09)
}

// ─── لغو آگهی توسط فروشنده ──────────────────────────────────────────────────
function cancelListing() {
  if (!beginAction()) return;
  if (!confirm('این آگهی لغو شود؟')) { endAction(); return; }
  fetch(`${BASE_URL}/${encodeURIComponent(ID)}/cancel`, { method: 'POST', headers, body: '{}' })
    .then(r => r.json())
    .then(d => { toast(d.message, d.success ? 'success' : 'danger'); if (d.success) setTimeout(() => location.reload(), 1500); else endAction(); })
    .catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); });
}

// ─── اثبات مالکیت حساب ──────────────────────────────────────────────────────
function ownershipCall(path, msg) {
  if (!beginAction()) return;
  if (!confirm(msg)) { endAction(); return; }
  fetch(`${BASE_URL}/${encodeURIComponent(ID)}/${path}`, { method: 'POST', headers, body: '{}' })
    .then(r => r.json())
    .then(d => { toast(d.message, d.success ? 'success' : 'danger'); if (d.success) setTimeout(() => location.reload(), 1500); else endAction(); })
    .catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); });
}
// ─── تایید دریافت ────────────────────────────────────────────────────────────
function confirmDelivery() {
  if (!beginAction()) return; // FIX-R36-W3 (F-A20-09)
  if (!confirm('آیا اطلاعات دسترسی را دریافت کرده و از صحت آن مطمئن هستید؟\nبا تایید شما، وجه به فروشنده پرداخت می‌شود.')) { endAction(); return; }
  fetch(`${BASE_URL}/${encodeURIComponent(ID)}/confirm`, { method: 'POST', headers, body: '{}' })
    .then(r => r.json())
    .then(d => { toast(d.message, d.success ? 'success' : 'danger'); if (d.success) setTimeout(() => location.reload(), 1800); else endAction(); })
    .catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); }); // FIX-R36-W3 (F-A20-09)
}

// ─── اختلاف ──────────────────────────────────────────────────────────────────
function openDispute() {
  new bootstrap.Modal(document.getElementById('disputeModal')).show();
}

function submitDispute() {
  const reason = document.getElementById('disputeReason').value.trim();
  if (reason.length < 10) { toast('لطفاً دلیل اختلاف را با جزئیات بیشتر بنویسید.', 'warning'); return; }
  if (!beginAction()) return; // FIX-R36-W3 (F-A20-09)
  fetch(`${BASE_URL}/${encodeURIComponent(ID)}/dispute`, {
    method: 'POST', headers,
    body: JSON.stringify({ reason })
  }).then(r => r.json()).then(d => {
    bootstrap.Modal.getInstance(document.getElementById('disputeModal'))?.hide();
    toast(d.message, d.success ? 'success' : 'danger');
    if (d.success) setTimeout(() => location.reload(), 1800); else endAction();
  }).catch(() => { toast('خطا در ارتباط با سرور', 'danger'); endAction(); }); // FIX-R36-W3 (F-A20-09)
}

// ═══ FIX-X108 (قرارداد X106/X89): ثبت همهٔ هندلرها در ChortkeActions ═══
// نام‌های kebab-case روی data-action فقط با رجیستری استاندارد resolve می‌شوند
// (fallback کلاسیک window[name] برای نام دارای خط تیره اصلاً قابل رزولو نیست).
window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
  'toggle-watch':     function () { toggleWatch.call(this); },
  'accept-request':   function () { acceptRequest.call(this); },
  'reject-request':   function () { rejectRequest.call(this); },
  'cancel-listing':   function () { cancelListing.call(this); },
  'buy-listing':      function () { buyListing.call(this); },
  'ownership-request': function () { ownershipCall('ownership-request', 'از فروشنده خواسته شود کد آگهی را در بیو/توضیحات حساب بگذارد؟'); },
  'ownership-ready':  function () { ownershipCall('ownership-ready', 'کد را در حساب قرار داده‌اید؟'); },
  'confirm-delivery': function () { confirmDelivery.call(this); },
  'submit-request':   function () { submitRequest.call(this); },
  'submit-contact':   function () { submitContact.call(this); },
  'submit-dispute':   function () { submitDispute.call(this); },
  'open-dispute':     function () { openDispute.call(this); }
});