// FIX-X111: مهاجرت دلیگیشن قدیمی به قرارداد X106 (ChortkeActions)
// 🛡️ FIX-F03: document.currentScript فقط در زمان اجرای همگام اسکریپت معتبر است؛
// داخل کال‌بک Promise همیشه null برمی‌گشت و به مسیر مطلق /lottery/* fallback
// می‌شد که استقرار زیرمسیر (/chortke) را می‌شکست. مرجع یک‌بار در ابتدای فایل
// (اجرای همگام IIFE) گرفته می‌شود و در کال‌بک‌ها از همان استفاده می‌شود.
(function () {
const script = document.currentScript;

function joinLotteryAction() {
    const roundId = this.dataset.roundId;
    if (!roundId) return;

    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: 'شرکت در قرعه‌کشی',
            text: 'آیا مطمئن هستید؟',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'بله، شرکت می‌کنم',
            cancelButtonText: 'انصراف'
        }).then(result => {
            if (result.isConfirmed) {
                fetch((script?.dataset.joinUrl || '/lottery/join'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': (document.querySelector('meta[name="csrf-token"]')?.content || window.csrfToken || '') },
                    body: JSON.stringify({ round_id: roundId })
                }).then(r => r.json()).then(res => {
                    if (res.success) {
                        Swal.fire('ثبت شد!', res.message + (res.code ? '\nکد شما: ' + res.code : ''), 'success')
                            .then(() => location.reload());
                    } else {
                        if (typeof notyf !== 'undefined') notyf.error(res.message);
                    }
                });
            }
        });
    } else {
        // Fallback without Swal
        if (confirm('آیا مطمئن هستید که می‌خواهید شرکت کنید؟')) {
            fetch((script?.dataset.joinUrl || '/lottery/join'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': (document.querySelector('meta[name="csrf-token"]')?.content || window.csrfToken || '') },
                body: JSON.stringify({ round_id: roundId })
            }).then(r => r.json()).then(res => {
                if (res.success) {
                    alert('ثبت شد! ' + (res.code ? 'کد شما: ' + res.code : ''));
                    location.reload();
                } else {
                    if (typeof notyf !== 'undefined') notyf.error(res.message);
                }
            });
        }
    }
}
function castVoteAction() {
    const roundId = this.dataset.roundId;
    const number = this.dataset.number;
    if (!roundId || !number) return;

    fetch((script?.dataset.voteUrl || '/lottery/vote'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': (document.querySelector('meta[name="csrf-token"]')?.content || window.csrfToken || '') },
        body: JSON.stringify({ round_id: roundId, voted_number: number })
    }).then(r => r.json()).then(res => {
        if (res.success) {
            if (typeof notyf !== 'undefined') notyf.success(res.message);
            setTimeout(() => location.reload(), 1000);
        } else {
            if (typeof notyf !== 'undefined') notyf.error(res.message);
        }
    });
}
window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    'join-lottery': joinLotteryAction,
    'cast-vote': castVoteAction
});
})();
