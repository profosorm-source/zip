// FIX-R13B: گارد عنصر ناموجود — در حالت resend_mode فرم کد رندر نمی‌شود و codeField نیست
// (خط اول بدون گارد کل اسکریپت را می‌شکست و شمارش معکوس هرگز وصل نمی‌شد)
(function() {
    const codeField = document.getElementById('codeField');
    if (codeField) {
        codeField.addEventListener('input', function() {
            // فقط حروف و اعداد — uppercase
            this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        });
    }
})();

// کانتدون ۶۰ ثانیه برای ارسال مجدد
(function() {
    const btn = document.getElementById('resendBtn');
    const form = document.getElementById('resendForm');
    if (!btn || !form) return;
    const originalLabel = btn.innerHTML;
    let seconds = 0;
    const stored = sessionStorage.getItem('resend_ts');
    if (stored) {
        const elapsed = Math.floor((Date.now() - parseInt(stored, 10)) / 1000);
        seconds = Math.max(0, 60 - elapsed);
    }
    if (seconds > 0) startCountdown(seconds);

    form.addEventListener('submit', function() {
        sessionStorage.setItem('resend_ts', Date.now().toString());
        startCountdown(60);
    });

    function startCountdown(sec) {
        btn.disabled = true;
        let s = sec;
        btn.textContent = 'ارسال مجدد (' + s + 'ث)';
        const t = setInterval(function() {
            s--;
            if (s <= 0) {
                clearInterval(t);
                btn.disabled = false;
                btn.innerHTML = originalLabel;
            } else {
                btn.textContent = 'ارسال مجدد (' + s + 'ث)';
            }
        }, 1000);
    }
})();
