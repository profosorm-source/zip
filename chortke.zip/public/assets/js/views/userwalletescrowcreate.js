document.getElementById('createEscrowForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = document.getElementById('submitEscrowBtn');
    if (!confirm('آیا از قفل کردن این مبلغ در صندوق امانات برای معامله با فروشنده مشخص‌شده اطمینان دارید؟')) return;

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> درحال قفل‌گذاری اتمیک...';

    const formData = new FormData(this);
    // 🛡️ FIX-S36-B15-S01 (هویت پایدار درخواست): نیتِ «ایجاد معامله امن» یک شناسهٔ
    // پایدار می‌گیرد که تا موفقیتِ نهایی حفظ می‌شود — retry پس از خطای شبکه/گم‌شدن
    // پاسخ همان request_id را می‌فرستد و سرور (کلید idempotency مبتنی بر آن) همان
    // عملیات را بازمی‌گرداند، نه امانت دوم. تغییر مبلغ/فروشنده = نیت جدید = کلید جدید.
    let requestId = sessionStorage.getItem('escrow_create_request_id');
    if (!requestId || !/^[A-Za-z0-9_-]{8,64}$/.test(requestId)) {
        requestId = (crypto.randomUUID ? crypto.randomUUID() : ('r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 12)))
            .replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64);
        if (requestId.length < 8) requestId = requestId.padEnd(8, '0');
        sessionStorage.setItem('escrow_create_request_id', requestId);
    }
    formData.append('request_id', requestId);
    fetch(this.action, {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            notyf.success(d.message || 'وجه با موفقیت در اسکرو قفل شد.');
            sessionStorage.removeItem('escrow_create_request_id');
        setTimeout(() => location.href = (window.BASE_URL || '') + '/wallet/escrows', 1500);
        } else {
            notyf.error(d.message || 'خطا در ایجاد معامله امن.');
            btn.disabled = false;
            btn.innerHTML = '<span class="material-icons align-middle me-2">lock</span> قفل‌گذاری آنی وجه در صندوق امانات';
        }
    })
    .catch(() => {
        // FIX-S36-B15-S01: نیت ذخیره‌شده عمداً پاک نمی‌شود — تلاش بعدی همان
        // request_id را می‌فرستد (امانت تکراری ممکن نیست).
        notyf.error('خطای ارتباط با سرور.');
        btn.disabled = false;
        btn.innerHTML = '<span class="material-icons align-middle me-2">lock</span> قفل‌گذاری آنی وجه در صندوق امانات';
    });
});
