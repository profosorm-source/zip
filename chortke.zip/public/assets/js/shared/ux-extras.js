/**
 * FEAT-QA5 (راند ۱۰) + FEAT-R11 (راند ۱۱) + FEAT-13D (راند ۱۳) — جزئیات UX مشترک همهٔ صفحات
 *
 * ۱) دکمهٔ بازگشت به بالا: بعد از ۶۰۰px اسکرول ظاهر می‌شود؛ کلیک = اسکرول نرم.
 * ۲) بنر قطع اتصال: با رویدادهای online/offline مرورگر، بدون polling.
 * ۳) کلید میان‌بر «/»: فوکوس روی جستجوی سریع هدر (tsInput) — الگوی رایج
 *    پنل‌های حرفه‌ای (GitHub/YouTube)؛ در inputهای متنی فعال نمی‌شود.
 * ۴) (R11) کلید «؟» (Shift+/) یا «Ctrl+/»: مودال راهنمای کلیدهای میان‌بر —
 *    کشف‌پذیری میان‌برها به‌جای فرض دانستنِ کاربر.
 * ۵) (R11) دکمهٔ کپی روی کدها/شماره‌ها (.js-copy): Clipboard API با fallback
 *    document.execCommand — بازخورد بصری «کپی شد» بدون toast اضافی.
 * ۶) (R12) هشدار انقضای نشست بی‌کار: در پنل‌های احراز-هویت‌شده (body[data-idle-seconds])
 *    ۲ دقیقه پیش از خروج خودکار سرور، کارت هشدار با شمارش معکوس فارسی +
 *    دکمهٔ «بمانم» (تمدید صریح = یک HEAD سمت سرور). بدون پینگ خودکار —
 *    تصمیم امنیتی پلتفرم مالی حفظ می‌شود.
 * ۷) (13D) ذخیرهٔ خودکار پیش‌نویس فرم: فرم‌های opt-in با form[data-draft] —
 *    ذخیرهٔ debounce-شده در localStorage (بدون هرگز: password/file/captcha/CSRF/token)
 *    + نوار بازیابی برنددار («بازیابی / نادیده») + پاک‌سازی روی submit.
 * ۸) (13D) جدول‌های مرتب‌شدنی: table[data-sortable] — کلیک/Enter روی th =
 *    مرتب‌سازی سمت کلاینت (عدد-آگاه با تبدیل ارقام فارسی و جداکننده‌ها؛
 *    تاریخِ عددی سگمنتی؛ fallback مقایسهٔ رشته‌ای فارسی) + aria-sort.
 * ۹) (13D) پیمایش پایین موبایل پنل کاربری: body[data-mobile-nav] حاوی JSON
 *    لینک‌های واقعی (تولیدشده با url() در لایوت) — زیر 768px رندر می‌شود،
 *    با تشخیص مسیر جاری، safe-area و نشانگر طلایی.
 * ۱۰) (R15D) کلمپ لبهٔ ویوپورت برای تولتیپ CSS-محض [data-tip]: حبابِ
 *    وسط‌چین نزدیک لبهٔ چپ/راست از صفحه بیرون می‌زد. روی mouseenter/focus
 *    عرض حباب اندازه‌گیری و سرریز محاسبه می‌شود → کلاس اصلاحی
 *    data-tip--start / data-tip--end (logical → RTL-safe) روی خود المان
 *    می‌نشیند و CSS در layout.css ترازِ لبه را انجام می‌دهد. با delegation
 *    روی document است ⇒ نودهای داینامیک هم پوشش داده می‌شوند؛ انیمیشنی
 *    در JS نیست ⇒ prefers-reduced-motion فقط از مسیر CSS رعایت می‌شود.
 * ۱۱) (FIX-R36-W3) توابع مرجع مشترک — window.chortkeNormalizeDigits (ارقام
 *    فارسی/عربی + جداکنندهٔ هزارگان ⇒ رشتهٔ عددی ASCII) برای همهٔ فرم‌های پولی،
 *    window.chortkeIdempotencyKey و window.chortkeDeviceFingerprint (الگوریتم
 *    یکنواخت به‌جای ۴ پیاده‌سازی موازی). مصرف‌کننده‌ها: فرم‌های برداشت/واریز/
 *    KYC/کارت بانکی، قرعه‌کشی ادمین، پیش‌بینی، ویجت گزارش باگ.
 *
 * همه با گارد prefers-reduced-motion و بدون هیچ وابستگی خارجی.
 */
(function () {
    'use strict';

    var REDUCED = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    document.addEventListener('DOMContentLoaded', function () {
        initBackToTop();
        initOfflineBanner();
        initSlashShortcut();
        initShortcutsModal();
        initCopyButtons();
        initIdleWarning();
        initDraftAutosave();
        initSortableTables();
        initMobileNav();
        initTooltipClamp();
    });

    // ─── ۱) بازگشت به بالا ───
    function initBackToTop() {
        if (document.getElementById('backToTop')) return;
        if (window.matchMedia && window.matchMedia('print').matches) return;

        var btn = document.createElement('button');
        btn.id = 'backToTop';
        btn.className = 'back-to-top';
        btn.type = 'button';
        btn.setAttribute('aria-label', 'بازگشت به بالای صفحه');
        btn.title = 'بازگشت به بالا';
        btn.innerHTML = '<span class="material-icons" aria-hidden="true">keyboard_arrow_up</span>';
        document.body.appendChild(btn);

        var ticking = false;
        function onScroll() {
            if (ticking) return;
            ticking = true;
            requestAnimationFrame(function () {
                btn.classList.toggle('is-visible', window.scrollY > 600);
                ticking = false;
            });
        }
        window.addEventListener('scroll', onScroll, { passive: true });
        onScroll();

        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: REDUCED ? 'auto' : 'smooth' });
        });
    }

    // ─── ۲) بنر قطع اتصال ───
    function initOfflineBanner() {
        if (document.getElementById('offlineBanner')) return;

        var banner = document.createElement('div');
        banner.id = 'offlineBanner';
        banner.className = 'offline-banner';
        banner.setAttribute('role', 'status');
        banner.setAttribute('aria-live', 'polite');
        banner.innerHTML = 'اتصال اینترنت قطع است — تغییرات تا بازگشت اتصال ذخیره نمی‌شوند' +
            ' <span class="material-icons" aria-hidden="true">wifi_off</span>';
        document.body.appendChild(banner);

        function update() {
            banner.classList.toggle('is-visible', !navigator.onLine);
        }
        window.addEventListener('offline', update);
        window.addEventListener('online', update);
        update();
    }

    // ─── ۳) کلید میان‌بر «/» برای جستجوی سریع پنل ───
    function initSlashShortcut() {
        document.addEventListener('keydown', function (e) {
            if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
            var tag = (e.target && e.target.tagName || '').toLowerCase();
            if (tag === 'input' || tag === 'textarea' || tag === 'select' || (e.target && e.target.isContentEditable)) return;

            var search = document.getElementById('tsInput');
            if (!search || search.disabled) return;

            // نوار جستجوی پنل به‌صورت پیش‌فرض بسته است — با «/» باز و فوکوس می‌شود
            var bar = document.getElementById('searchBar');
            if (bar && !bar.classList.contains('open')) {
                var toggle = document.getElementById('searchToggle');
                if (toggle) {
                    toggle.click();
                } else {
                    bar.classList.add('open');
                }
            }
            e.preventDefault();
            search.focus();
            search.select();
        });
    }

    // ─── ۴) (R11) مودال راهنمای کلیدهای میان‌بر («؟» یا Ctrl+/) ───
    var SHORTCUTS = [
        { keys: ['/'],           desc: 'فوکوس روی جستجوی سریع (در پنل)' },
        { keys: ['؟'],           desc: 'نمایش همین راهنما (یا Ctrl+/)' },
        { keys: ['Esc'],         desc: 'بستن مودال/منوی باز' },
        { keys: ['Tab'],         desc: 'جابه‌جایی بین فیلدها (پیمایش کیبورد)' }
    ];

    function initShortcutsModal() {
        var modal = null;

        function build() {
            modal = document.createElement('div');
            modal.id = 'shortcutsModal';
            modal.className = 'kbd-modal';
            modal.setAttribute('role', 'dialog');
            modal.setAttribute('aria-modal', 'true');
            modal.setAttribute('aria-label', 'راهنمای کلیدهای میان‌بر');

            var rows = SHORTCUTS.map(function (s) {
                var kbd = s.keys.map(function (k) {
                    return '<kbd class="kbd-key" dir="ltr">' + escapeHtml(k) + '</kbd>';
                }).join('<span class="kbd-or" dir="ltr"> / </span>');
                return '<div class="kbd-modal__row"><span class="kbd-modal__keys">' + kbd + '</span>' +
                       '<span class="kbd-modal__desc">' + escapeHtml(s.desc) + '</span></div>';
            }).join('');

            modal.innerHTML =
                '<div class="kbd-modal__backdrop" data-kbd-close></div>' +
                '<div class="kbd-modal__panel" role="document">' +
                    '<div class="kbd-modal__head">' +
                        '<span class="kbd-modal__title"><span class="material-icons" aria-hidden="true">keyboard</span> کلیدهای میان‌بر</span>' +
                        '<button type="button" class="kbd-modal__close" data-kbd-close aria-label="بستن راهنما">' +
                            '<span class="material-icons" aria-hidden="true">close</span>' +
                        '</button>' +
                    '</div>' +
                    '<div class="kbd-modal__body">' + rows + '</div>' +
                '</div>';
            document.body.appendChild(modal);

            modal.addEventListener('click', function (e) {
                if (e.target.closest('[data-kbd-close]')) close();
            });

            var panel = modal.querySelector('.kbd-modal__panel');
            if (panel) panel.setAttribute('tabindex', '-1');
        }

        function open() {
            if (!modal) build();
            modal.classList.add('is-open');
            var p = modal.querySelector('.kbd-modal__panel');
            if (p) p.focus({ preventScroll: true });
            document.addEventListener('keydown', onModalKeydown, true);
        }

        function close() {
            if (!modal) return;
            modal.classList.remove('is-open');
            document.removeEventListener('keydown', onModalKeydown, true);
        }

        function onModalKeydown(e) {
            if (e.key === 'Escape') { e.stopPropagation(); close(); }
        }

        function escapeHtml(s) {
            return String(s).replace(/[&<>"']/g, function (c) {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
            });
        }

        document.addEventListener('keydown', function (e) {
            // «؟» = Shift+/ روی لایه‌بندی انگلیسی؛ Ctrl+/ و Meta+/ هم پذیرفته می‌شود
            var isQuestion = (e.key === '?' && !e.ctrlKey && !e.metaKey);
            var isCtrlSlash = ((e.ctrlKey || e.metaKey) && e.key === '/');
            if (!isQuestion && !isCtrlSlash) return;

            var tag = (e.target && e.target.tagName || '').toLowerCase();
            // در فیلدهای متنی فقط Ctrl+/ (وگرنه علامت سؤال تایپ می‌شود)
            if ((tag === 'input' || tag === 'textarea' || (e.target && e.target.isContentEditable)) && !isCtrlSlash) return;
            // داخل خود مودال: بستن با Escape هندل می‌شود
            if (modal && modal.classList.contains('is-open') && isCtrlSlash) { e.preventDefault(); close(); return; }

            e.preventDefault();
            open();
        });
    }

    // ─── ۵) (R11) دکمهٔ کپی (.js-copy با data-copy یا data-copy-target) ───
    function initCopyButtons() {
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('.js-copy');
            if (!btn) return;

            var value = btn.getAttribute('data-copy') || '';
            if (!value) {
                var sel = btn.getAttribute('data-copy-target');
                var el = sel && document.querySelector(sel);
                value = el ? (el.value || el.textContent || '').trim() : '';
            }
            if (!value) return;

            function done(ok) {
                btn.classList.add(ok ? 'is-copied' : 'is-copy-failed');
                var icon = btn.querySelector('.material-icons');
                var prev = icon ? icon.textContent : null;
                if (icon) icon.textContent = ok ? 'check' : 'error_outline';
                btn.setAttribute('aria-label', ok ? 'کپی شد' : 'کپی ناموفق');
                setTimeout(function () {
                    btn.classList.remove('is-copied', 'is-copy-failed');
                    if (icon && prev) icon.textContent = prev;
                    btn.removeAttribute('aria-label');
                }, 1400);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(value).then(function () { done(true); }, function () { legacy(); });
            } else {
                legacy();
            }

            function legacy() {
                try {
                    var ta = document.createElement('textarea');
                    ta.value = value;
                    ta.setAttribute('readonly', '');
                    ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
                    document.body.appendChild(ta);
                    ta.select();
                    var ok = document.execCommand('copy');
                    document.body.removeChild(ta);
                    done(ok);
                } catch (err) {
                    done(false);
                }
            }
        });
    }

    // ─── ۶) (R12) هشدار خروج خودکار به‌علت بی‌فعالیتی ───
    // سرور نشست‌های بی‌کار را بعد از session_idle_timeout_seconds (پیش‌فرض ۱۵ دقیقه)
    // می‌بندد (تصمیم امنیتی پلتفرم مالی — راند ۱۱). این هشدار فقط «اطلاع‌رسانی» است:
    // هیچ پینگ خودکاری نمی‌زند؛ کاربر با دکمهٔ «بمانم» صریحاً تمدید می‌کند.
    function initIdleWarning() {
        var body = document.body;
        if (!body || !body.hasAttribute('data-idle-seconds')) return; // فقط پنل‌های احراز-هویت‌شده
        var timeout = parseInt(body.getAttribute('data-idle-seconds'), 10);
        if (!timeout || timeout < 300) timeout = 900;

        var WARN_BEFORE = 120; // ۲ دقیقه پیش از انقضا هشدار بده
        var startedAt = Date.now();
        var warned = false;
        var expired = false;

        // ساخت کارت هشدار (مخفی)
        var card = document.createElement('div');
        card.className = 'idle-warn';
        card.id = 'idleWarn';
        card.setAttribute('role', 'alertdialog');
        card.setAttribute('aria-live', 'assertive');
        card.setAttribute('aria-label', 'هشدار انقضای نشست');
        card.hidden = true;
        card.innerHTML =
            '<div class="idle-warn__icon" aria-hidden="true">' +
            '<span class="material-icons">hourglass_bottom</span></div>' +
            '<div class="idle-warn__body">' +
            '<strong>نشست شما به‌زودی منقضی می‌شود</strong>' +
            '<p>به‌دلیل بی‌کاری، <span class="idle-warn__count" id="idleCount">—</span> تا خروج خودکار باقی مانده است.</p>' +
            '</div>' +
            '<div class="idle-warn__actions">' +
            '<button type="button" class="idle-warn__stay" id="idleStay">بمانم</button>' +
            // FIX-R36-W3 (F-A20-11): fallback هاردکد «/chortke/login» در دیپلوی docroot=public همیشه 404 می‌داد.
            // زنجیره: override صریح لی‌اوت (window.chortkeLoginUrl — پیشنهاد اتصال با url('/login') در A4/A5)
            // → BASE_URL (guest) → تشخیص base-path از مسیر جاری → '/login'.
            '<a class="idle-warn__login" id="idleLogin" hidden href="' + idleLoginUrl() + '">ورود مجدد</a>' +
            '</div>';
        document.body.appendChild(card);

        function fmt(s) {
            var m = Math.floor(s / 60);
            var r = s % 60;
            return (m > 0 ? fa(m) + ' دقیقه و ' : '') + fa(r) + ' ثانیه';
        }
        function fa(n) {
            return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; });
        }

        function show() {
            card.hidden = false;
            requestAnimationFrame(function () { card.classList.add('is-visible'); });
        }
        function hide() {
            card.classList.remove('is-visible');
            setTimeout(function () { card.hidden = true; }, 250);
        }

        document.getElementById('idleStay').addEventListener('click', function () {
            // تمدید صریح با ارادهٔ کاربر = درخواست سبک به سرور؛ activity key سرور تازه می‌شود
            var btn = this;
            btn.disabled = true;
            btn.textContent = 'در حال تمدید…';
            fetch(window.location.pathname, {
                method: 'HEAD',
                cache: 'no-store',
                credentials: 'same-origin'
            }).then(function () {
                startedAt = Date.now();
                warned = false;
                expired = false;
                hide();
                btn.disabled = false;
                btn.textContent = 'بمانم';
            }).catch(function () {
                btn.textContent = 'خطا — دوباره بزنید';
                btn.disabled = false;
            });
        });

        setInterval(function () {
            if (expired) return;
            if (document.hidden) return; // تب پشت‌سر: سرور هم همان را می‌بیند؛ هشدار لازم نیست
            var elapsed = Math.floor((Date.now() - startedAt) / 1000);
            var remain = timeout - elapsed;
            var count = document.getElementById('idleCount');
            if (remain <= 0) {
                expired = true;
                card.querySelector('.idle-warn__body strong').textContent = 'نشست شما منقضی شد';
                card.querySelector('.idle-warn__body p').innerHTML = 'برای ادامه کار دوباره وارد شوید.';
                document.getElementById('idleStay').hidden = true;
                document.getElementById('idleLogin').hidden = false;
                show();
                return;
            }
            if (remain <= WARN_BEFORE) {
                if (count) count.textContent = fmt(remain);
                if (!warned) {
                    warned = true;
                    show();
                }
            }
        }, 1000);
    }

    // ─── ۷) (13D) ذخیرهٔ خودکار پیش‌نویس فرم — فرم‌های opt-in با form[data-draft] ───
    // هرگز رمز/فایل/captcha/CSRF/token ذخیره نمی‌شود؛ کلید = pathname+action+اندیس فرم.
    var DRAFT_PREFIX = 'chortke:draft:';
    var DRAFT_SECRET_NAME = /csrf|captcha|token|secret|password/i;

    function draftKey(form) {
        var idx = Array.prototype.indexOf.call(document.forms, form);
        var action = form.getAttribute('action') || '';
        return DRAFT_PREFIX + location.pathname + '|' + action + '|' + idx;
    }

    function lsGet(key) {
        try { return window.localStorage.getItem(key); } catch (err) { return null; }
    }
    function lsSet(key, value) {
        try { window.localStorage.setItem(key, value); return true; } catch (err) { return false; }
    }
    function lsRemove(key) {
        try { window.localStorage.removeItem(key); } catch (err) { /* ignore */ }
    }

    // اسنپ‌شات مقادیر فرم — آرایه‌ای هم‌اندیس با form.elements
    // null = این المان هرگز ذخیره نشود (پسورد/فایل/…)
    function snapshotForm(form) {
        var out = [];
        var els = form.elements;
        for (var i = 0; i < els.length; i++) {
            var el = els[i];
            var tag = (el.tagName || '').toLowerCase();
            var name = el.name || '';
            if (!name || el.disabled || DRAFT_SECRET_NAME.test(name)) { out.push(null); continue; }
            if (tag === 'button' || tag === 'fieldset' || tag === 'output') { out.push(null); continue; }
            if (tag === 'input') {
                var t = (el.type || 'text').toLowerCase();
                if (t === 'password' || t === 'file' || t === 'submit' || t === 'button' || t === 'reset' || t === 'image') { out.push(null); continue; }
                if (t === 'checkbox' || t === 'radio') { out.push({ c: el.checked }); continue; }
                out.push({ v: el.value }); continue;
            }
            if (tag === 'select' && el.multiple) {
                var vals = [];
                Array.prototype.forEach.call(el.options, function (opt) { if (opt.selected) vals.push(opt.value); });
                out.push({ m: vals }); continue;
            }
            out.push({ v: el.value });
        }
        return out;
    }

    function restoreSnapshot(form, snap) {
        var els = form.elements;
        for (var i = 0; i < els.length && i < snap.length; i++) {
            var el = els[i];
            var saved = snap[i];
            if (!saved || !el || el.disabled) continue;
            var tag = (el.tagName || '').toLowerCase();
            var name = el.name || '';
            if (!name || DRAFT_SECRET_NAME.test(name)) continue;
            try {
                if (tag === 'input') {
                    var t = (el.type || 'text').toLowerCase();
                    if (t === 'password' || t === 'file' || t === 'submit' || t === 'button' || t === 'reset' || t === 'image') continue;
                    if (t === 'checkbox' || t === 'radio') {
                        el.checked = !!saved.c;
                        if (t === 'radio' && el.checked) syncRadioLabels(form, name);
                        continue;
                    }
                }
                if (saved.m && tag === 'select' && el.multiple) {
                    Array.prototype.forEach.call(el.options, function (opt) {
                        opt.selected = saved.m.indexOf(opt.value) !== -1;
                    });
                } else if (typeof saved.v === 'string') {
                    el.value = saved.v;
                }
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            } catch (err) { /* المان بین ذخیره و بازیابی عوض شده — نادیده */ }
        }
    }

    // همگام‌سازی کلاس active لیبل رادیوها (الگوی اولویت تیکت) بعد از بازیابی
    function syncRadioLabels(form, name) {
        Array.prototype.forEach.call(form.querySelectorAll('input[name="' + cssEscape(name) + '"]'), function (r) {
            var label = r.closest('label');
            if (label) label.classList.toggle('active', r.checked);
        });
    }

    function cssEscape(s) {
        if (window.CSS && window.CSS.escape) return window.CSS.escape(s);
        return String(s).replace(/["\\\]]/g, '\\$&');
    }

    function draftHasContent(snap) {
        return snap.some(function (item) {
            if (!item) return false;
            if (typeof item.v === 'string') return item.v.trim() !== '';
            if (item.m) return item.m.length > 0;
            return !!item.c;
        });
    }

    function initDraftAutosave() {
        if (window.matchMedia && window.matchMedia('print').matches) return;
        Array.prototype.forEach.call(document.querySelectorAll('form[data-draft]'), function (form) {
            var key = draftKey(form);
            var timer = null;
            var MAX_BYTES = 65536;

            function save() {
                if (!draftHasContent(form.__lastSnap || [])) {
                    // فرم خالی شد → پیش‌نویس کهنه نباید بازیابی گمراه‌کننده بماند
                    lsRemove(key);
                    return;
                }
                var json = JSON.stringify(form.__lastSnap);
                if (json.length > MAX_BYTES) return; // فرم‌های عجیب سنگین را نگه نمی‌داریم
                lsSet(key, json);
            }

            form.addEventListener('input', function () {
                form.__lastSnap = snapshotForm(form);
                if (timer) clearTimeout(timer);
                timer = setTimeout(save, 800);
            });
            form.addEventListener('change', function () {
                form.__lastSnap = snapshotForm(form);
                if (timer) clearTimeout(timer);
                timer = setTimeout(save, 800);
            });

            form.addEventListener('submit', function () {
                if (timer) clearTimeout(timer);
                lsRemove(key);
            });

            // بازیابی فقط وقتی پیش‌نویسِ پرمحتوایی از جلسهٔ قبل مانده باشد
            var raw = lsGet(key);
            if (!raw) return;
            var snap = null;
            try { snap = JSON.parse(raw); } catch (err) { lsRemove(key); return; }
            if (!Array.isArray(snap) || !draftHasContent(snap)) { lsRemove(key); return; }

            showDraftBar(form, key, snap);
        });
    }

    function showDraftBar(form, key, snap) {
        if (document.querySelector('.draft-bar[data-draft-key]')) return; // هر بار یک نوار

        var bar = document.createElement('div');
        bar.className = 'draft-bar';
        bar.setAttribute('data-draft-key', key);
        bar.setAttribute('role', 'status');
        bar.setAttribute('aria-live', 'polite');
        bar.innerHTML =
            '<div class="draft-bar__icon" aria-hidden="true"><span class="material-icons">history_edu</span></div>' +
            '<div class="draft-bar__body">پیش‌نویس ذخیره‌شده بازیابی شود؟' +
            '<small>مقادیر قبلی این فرم در همین مرورگر نگه داشته شده است.</small></div>' +
            '<div class="draft-bar__actions">' +
            '<button type="button" class="draft-bar__restore">بازیابی</button>' +
            '<button type="button" class="draft-bar__dismiss">نادیده</button>' +
            '</div>';
        document.body.appendChild(bar);

        requestAnimationFrame(function () { bar.classList.add('is-visible'); });

        bar.querySelector('.draft-bar__restore').addEventListener('click', function () {
            restoreSnapshot(form, snap);
            hide();
            // پس از بازیابی، پیش‌نویس می‌ماند تا submit یا ویرایش بعدی آن را تازه کند
        });
        bar.querySelector('.draft-bar__dismiss').addEventListener('click', function () {
            lsRemove(key);
            hide();
        });

        function hide() {
            bar.classList.remove('is-visible');
            setTimeout(function () { if (bar.parentNode) bar.parentNode.removeChild(bar); }, 300);
        }
    }

    // ─── ۸) (13D) جدول‌های مرتب‌شدنی — table[data-sortable] ───
    // عدد-آگاه: تبدیل ارقام فارسی/عربی + حذف جداکننده‌ها؛ تاریخ عددی سگمنتی؛
    // بقیه مقایسهٔ رشته‌ای فارسی. بدون دست‌زدن به لینک‌ها/دکمه‌های ردیف‌ها.
    function faToEnDigits(s) {
        return String(s)
            .replace(/[\u06F0-\u06F9]/g, function (d) { return String(d.charCodeAt(0) - 0x06F0); })
            .replace(/[\u0660-\u0669]/g, function (d) { return String(d.charCodeAt(0) - 0x0660); });
    }

    // ─── ۱۱) (FIX-R36-W3) توابع مرجع مشترک — خروجی global برای فرم‌های پولی ───
    // F-A20-10/F-A21-10: نرمال‌سازی یکنواخت ارقام فارسی/عربی + جداکنندهٔ هزارگان
    // (کاما، ٬ عربی، جداکنندهٔ عربی، NBSP و فاصله) ⇒ رشتهٔ عددی ASCII برای parseFloat.
    function normalizeMoneyDigits(value) {
        return String(value == null ? '' : value)
            .replace(/[\u06F0-\u06F9]/g, function (d) { return String(d.charCodeAt(0) - 0x06F0); })
            .replace(/[\u0660-\u0669]/g, function (d) { return String(d.charCodeAt(0) - 0x0660); })
            .replace(/[',\u066C\u066B\u00A0\u2009\u202F\s]/g, '');
    }

    // F-A20-12: کلید idempotency یکنواخت — crypto.randomUUID → crypto.getRandomValues →
    // Date.now+Math.random (فقط آخرین لایهٔ fallback، هرگز منبع اصلی نیست).
    function canonicalIdempotencyKey(prefix) {
        var p = String(prefix || '');
        try {
            if (window.crypto && typeof window.crypto.randomUUID === 'function') return p + window.crypto.randomUUID();
            if (window.crypto && window.crypto.getRandomValues) {
                var buf = new Uint8Array(16);
                window.crypto.getRandomValues(buf);
                var hex = '';
                for (var i = 0; i < buf.length; i++) hex += ('0' + buf[i].toString(16)).slice(-2);
                return p + hex;
            }
        } catch (err) { /* افت به لایهٔ بعدی */ }
        return p + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
    }

    // F-A20-12: اثر انگشت دستگاه یکنواخت — FNV-1a ۳۲بیتی دوردُر روی مؤلفه‌های پایدار
    // (سازگار با الگوی bugreportwidget که قوی‌ترین نسخه بود). سرور آن را با IP+UA ترکیب می‌کند.
    function canonicalDeviceFingerprint() {
        try {
            var parts = [
                navigator.userAgent || '',
                navigator.language || '',
                (navigator.languages || []).join(','),
                String(screen.width) + 'x' + String(screen.height) + 'x' + String(screen.colorDepth || ''),
                String(new Date().getTimezoneOffset()),
                String(navigator.hardwareConcurrency || ''),
                String(navigator.maxTouchPoints || '')
            ];
            var s = parts.join('|');
            var h1 = 0x811c9dc5, h2 = 0x1000193;
            for (var i = 0; i < s.length; i++) {
                h1 = (h1 ^ s.charCodeAt(i)) >>> 0;
                h1 = (h1 * 0x01000193) >>> 0;
                h2 = (h2 + s.charCodeAt(i) * (i + 7)) >>> 0;
            }
            return ('fp_' + h1.toString(16) + h2.toString(16));
        } catch (err) {
            return '';
        }
    }

    // F-A20-11: مسیر ورود پس از انقضای نشست — override لی‌اوت → BASE_URL مرکزی
    // (16-W — گزینهٔ ۳): زنجیرهٔ fallback به منبع واحد حقیقت خلاصه شد؛ تشخیص
    // هاردکد /chortke از pathname حذف شد (window.BASE_URL در همهٔ لی‌اوت‌ها تعریف است).
    function idleLoginUrl() {
        if (window.chortkeLoginUrl) return window.chortkeLoginUrl;
        return (window.BASE_URL || '') + '/login';
    }

    // خروجی global (در همهٔ لی‌اوت‌های user/admin/guest این فایل لود می‌شود)
    window.chortkeNormalizeDigits = normalizeMoneyDigits;
    window.chortkeIdempotencyKey = canonicalIdempotencyKey;
    window.chortkeDeviceFingerprint = canonicalDeviceFingerprint;
    window.chortkeLoginUrlFromBase = idleLoginUrl;

    function cellKey(text) {
        var s = faToEnDigits(text).replace(/[\u2212]/g, '-').trim();
        // حذف جداکنندهٔ هزارگان و علامت‌های رایج پول/درصد
        var num = s.replace(/[,\u066C\u066B\u00A0\u2009\u202F'%٪+\s]|تومان|ریال|USDT|IRT/g, '');
        if (/^-?\d+(?:\.\d+)?$/.test(num)) return { kind: 'num', n: parseFloat(num) };
        // تاریخ/کد عددی سگمنتی مثل ۱۴۰۴/۰۶/۲۹
        if (/^[\d\/.\- ]+$/.test(s) && /\d/.test(s)) {
            return { kind: 'seg', parts: s.split(/[\/.\- ]+/).filter(Boolean).map(Number) };
        }
        return { kind: 'str', s: s };
    }

    function compareKeys(a, b) {
        if (a.kind === 'num' && b.kind === 'num') return a.n - b.n;
        if (a.kind === 'seg' && b.kind === 'seg') {
            var len = Math.max(a.parts.length, b.parts.length);
            for (var i = 0; i < len; i++) {
                var d = (a.parts[i] || 0) - (b.parts[i] || 0);
                if (d !== 0) return d;
            }
            return 0;
        }
        // عدد در برابر رشته: عدد اول؛ رشته‌ها با locale فارسی
        if (a.kind === 'num') return -1;
        if (b.kind === 'num') return 1;
        try { return a.s.localeCompare(b.s, 'fa'); } catch (err) { return a.s < b.s ? -1 : (a.s > b.s ? 1 : 0); }
    }

    function initSortableTables() {
        Array.prototype.forEach.call(document.querySelectorAll('table[data-sortable]'), function (table) {
            var head = table.querySelector('thead');
            var body = table.querySelector('tbody');
            if (!head || !body || body.getAttribute('data-sort-bound')) return;
            body.setAttribute('data-sort-bound', '1');

            var headRow = head.rows[0];
            if (!headRow) return;
            var ths = Array.prototype.slice.call(headRow.cells);
            var originalRows = Array.prototype.slice.call(body.rows);

            function sortRows(colIndex, dir) {
                // ردیف‌های empty-state (colspan) همیشه ته جدول می‌مانند
                var sortable = [];
                var pinned = [];
                originalRows.forEach(function (tr) {
                    if (tr.cells.length && tr.cells[0].colSpan > 1) pinned.push(tr);
                    else sortable.push(tr);
                });
                sortable.sort(function (ra, rb) {
                    var ka = cellKey(ra.cells[colIndex] ? ra.cells[colIndex].textContent : '');
                    var kb = cellKey(rb.cells[colIndex] ? rb.cells[colIndex].textContent : '');
                    return dir * compareKeys(ka, kb);
                });
                sortable.concat(pinned).forEach(function (tr) { body.appendChild(tr); });
            }

            ths.forEach(function (th, colIndex) {
                var label = (th.textContent || '').trim();
                if (!label || th.hasAttribute('data-no-sort')) return; // ستون عملیات/چک‌باکس
                th.classList.add('is-sortable');
                th.setAttribute('tabindex', '0');
                th.setAttribute('aria-sort', 'none');
                th.setAttribute('aria-label', 'مرتب‌سازی بر اساس ' + label);

                function toggle() {
                    var current = th.getAttribute('aria-sort');
                    var next = current === 'ascending' ? 'descending'
                             : current === 'descending' ? 'none'
                             : 'ascending';
                    ths.forEach(function (other) {
                        if (other.hasAttribute('aria-sort')) other.setAttribute('aria-sort', 'none');
                    });
                    th.setAttribute('aria-sort', next);
                    if (next === 'none') {
                        originalRows.forEach(function (tr) { body.appendChild(tr); });
                    } else {
                        sortRows(colIndex, next === 'ascending' ? 1 : -1);
                    }
                }

                th.addEventListener('click', function (e) {
                    // کلیک روی لینک/دکمهٔ داخل سرستول (اگر روزی اضافه شد) دست‌نخورده بماند
                    if (e.target.closest('a, button, input, select, label')) return;
                    toggle();
                });
                th.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
                });
            });
        });
    }

    // ─── ۹) (13D) پیمایش پایین موبایل پنل کاربری — body[data-mobile-nav='[...]'] ───
    // لینک‌ها در لایوت با url() ساخته می‌شوند (base-path امن) و به‌صورت JSON می‌آیند.
    function initMobileNav() {
        var body = document.body;
        if (!body || !body.hasAttribute('data-mobile-nav') || body.classList.contains('has-m-nav')) return;
        var raw = body.getAttribute('data-mobile-nav');
        var items = [];
        try { items = JSON.parse(raw || '[]'); } catch (err) { return; }
        if (!Array.isArray(items) || !items.length) return;

        var nav = document.createElement('nav');
        nav.className = 'm-nav';
        nav.setAttribute('aria-label', 'پیوندهای سریع پنل');

        var currentPath = location.pathname.replace(/\/+$/, '') || '/';
        items.forEach(function (item) {
            if (!item || !item.href || !item.label) return;
            var a = document.createElement('a');
            a.href = item.href;
            a.innerHTML = '<span class="material-icons" aria-hidden="true">' + escapeHtml(item.icon || 'circle') + '</span>' +
                          '<span>' + escapeHtml(item.label) + '</span>';

            try {
                var target = new URL(item.href, location.origin).pathname.replace(/\/+$/, '') || '/';
                if (currentPath === target || (target !== '/' && currentPath.indexOf(target + '/') === 0)) {
                    a.classList.add('is-active');
                    a.setAttribute('aria-current', 'page');
                }
            } catch (err) { /* مسیر جاری قابل‌تحلیل نبود — بدون حالت فعال */ }

            nav.appendChild(a);
        });
        if (!nav.children.length) return;

        body.classList.add('has-m-nav');
        body.appendChild(nav);
    }

    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    // ─── ۱۰) (R15D) کلمپ لبهٔ ویوپورت برای تولتیپ [data-tip] ───
    // تولتیپ CSS-محض (layout.css) بالای المان و وسط‌چین است؛ نزدیک لبهٔ
    // چپ/راست ویوپورت سرریز می‌کرد. اینجا عرض حباب تخمین زده می‌شود
    // (متن + فونت/padding واقعی از ::after) و در صورت سرریز، فقط کلاس
    // اصلاحی روی المان می‌نشیند — هندسهٔ حباب را CSS تعیین می‌کند.
    var tipProbe = null;
    var tipIsRtl = false;

    function tipMeasureBubble(el) {
        var text = el.getAttribute('data-tip') || '';
        if (!text) return 0;
        var cs = null;
        try { cs = window.getComputedStyle(el, '::after'); } catch (err) { cs = null; }
        if (!tipProbe) {
            tipProbe = document.createElement('span');
            tipProbe.setAttribute('aria-hidden', 'true');
            tipProbe.style.cssText = 'position:absolute;visibility:hidden;white-space:nowrap;top:-9999px;left:-9999px;border:1px solid transparent;box-sizing:content-box;';
            document.body.appendChild(tipProbe);
        }
        tipProbe.style.maxWidth = (cs && cs.maxWidth && cs.maxWidth !== 'none') ? cs.maxWidth : '240px';
        tipProbe.style.fontSize = (cs && cs.fontSize) || '12px';
        tipProbe.style.fontWeight = (cs && cs.fontWeight) || '600';
        tipProbe.style.fontFamily = (cs && cs.fontFamily) || 'inherit';
        tipProbe.style.lineHeight = (cs && cs.lineHeight) || '1.7';
        tipProbe.style.padding = (cs && cs.padding) || '6px 10px';
        tipProbe.textContent = text;
        return tipProbe.offsetWidth;
    }

    function tipClassify(el) {
        el.classList.remove('data-tip--start', 'data-tip--end');
        var rect = el.getBoundingClientRect();
        if (!rect || (rect.width === 0 && rect.height === 0)) return;
        var bubbleW = tipMeasureBubble(el);
        if (!bubbleW) return;

        var margin = 8; // حداقل فاصلهٔ حباب از لبهٔ ویوپورت
        var center = rect.left + rect.width / 2;
        var half = bubbleW / 2;
        var overflowRight = (center + half) - (window.innerWidth - margin);
        var overflowLeft = margin - (center - half);
        if (overflowRight <= 0 && overflowLeft <= 0) return;

        // کلاس‌ها logical هستند (inline-start/end) ⇒ در RTL جهتِ فیزیکی معکوس می‌شود
        tipIsRtl = document.documentElement.getAttribute('dir') === 'rtl';
        var cls;
        if (overflowRight > 0 && overflowRight >= overflowLeft) {
            cls = tipIsRtl ? 'data-tip--start' : 'data-tip--end';
        } else {
            cls = tipIsRtl ? 'data-tip--end' : 'data-tip--start';
        }
        el.classList.add(cls);
    }

    function tipClear(el) {
        el.classList.remove('data-tip--start', 'data-tip--end');
    }

    function initTooltipClamp() {
        // delegation روی document ⇒ نودهای داینامیک هم پوشش داده می‌شوند
        document.addEventListener('mouseover', function (e) {
            var el = e.target && e.target.closest ? e.target.closest('[data-tip]') : null;
            if (el) tipClassify(el);
        }, true);
        document.addEventListener('mouseout', function (e) {
            var el = e.target && e.target.closest ? e.target.closest('[data-tip]') : null;
            if (el) tipClear(el);
        }, true);
        document.addEventListener('focusin', function (e) {
            var el = e.target && e.target.closest ? e.target.closest('[data-tip]') : null;
            if (el) tipClassify(el);
        }, true);
        document.addEventListener('focusout', function (e) {
            var el = e.target && e.target.closest ? e.target.closest('[data-tip]') : null;
            if (el) tipClear(el);
        }, true);
    }
})();
