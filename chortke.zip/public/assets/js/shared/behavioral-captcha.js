/**
 * Chortke Behavioral CAPTCHA — کلاینت‌کالکتور رفتاری (W4-C)
 * ─────────────────────────────────────────────────────────
 * تکمیلِ کپچای رفتاری که سمت سرور (CaptchaService::generateBehavioral /
 * verifyBehavioral / pingBehavioral) از قبل وجود داشت ولی کلاینتِ آن
 * (captcha.js قدیمی) حذف شده بود و هیچ‌جا wire نبود.
 *
 * چه چیزی جمع می‌کند (فقط رفتار درون صفحه، بدون اثرانگشت PII، بدون سرویس ثالث):
 *   - حرکت اشاره‌گر (pointer/mouse move) با throttle و timestamp طبیعی
 *   - کلیک / keydown (بدون repeat) / touch / scroll
 *   - تایمینگ فوکوسِ فیلدهای فرم (focusin/focusout)
 *
 * قرارداد با سرور (CaptchaService::verifyBehavioral — نام‌ها دقیقاً همین‌ها):
 *   captcha_token     توکن HMAC که ویجت رندر کرده (دست نمی‌زنیم)
 *   behavioral_state  state امضاشده از POST /captcha/behavioral/ping
 *   behavioral_score  امتیاز مشورتی ۰..۱۰۰ (گیت سرور: ≥ ۶۰)
 *   events            JSON آرایهٔ {type,time,x,y} — time میلی‌ثانیهٔ نسبی،
 *                     سقف سرور ۵۰۰ رویداد / ۸KB (کلاینت سقفِ سخت‌تر می‌گذارد)
 *
 * امنیت/محیط:
 *   - CSP-safe: بدون eval/inline، فقط addEventListener و fetch با header های
 *     X-Requested-With (چک is_ajax سمت سرور).
 *   - prefers-reduced-motion: کالکتور کاملاً passive است و هیچ انیمیشنی
 *     ایجاد نمی‌کند؛ پرچم در state گذاشته شده تا UI میزبان هم رعایت کند.
 *   - degrade بی‌صدا: اگر JS لود نشود یا fetch شکست بخورد، ورودی‌ها خالی
 *     می‌مانند و سرور برای نوع behavioral fail-closed رد می‌کند (عمدی است).
 *   - کپچای رفتاری «دفاع در عمق» است؛ شواهد کلاینت مشورتی‌اند و نباید تنها
 *     گُرد مسیرهای پولی باشند (مستند در CaptchaService).
 */
(function () {
    'use strict';

    if (window.ChortkeBehavioralCaptcha) {
        return; // جلوگیری از دوبار attach شدن در صفحه
    }

    var MAX_EVENTS = 400;              // سقف داخلی (سقف سرور: ۵۰۰)
    var EVENTS_JSON_BUDGET = 7800;     // زیر سقف ۸KB سرور با حاشیه
    var POINTER_GAP_MS = 70;           // throttle حرکت اشاره‌گر
    var SCROLL_GAP_MS = 250;
    var TOUCHMOVE_GAP_MS = 120;
    var PING_GAP_MS = 1100;            // سرور حداقل ۱ ثانیه فاصله را شمارش می‌کند
    var MAX_PINGS = 30;                // سقف احتیاطی (route خودش ۳۰/min است)
    var SCORE_THRESHOLD = 60;          // هم‌تراز با گیت سرور

    function prefersReducedMotion() {
        try {
            return !!(window.matchMedia &&
                window.matchMedia('(prefers-reduced-motion: reduce)').matches);
        } catch (e) {
            return false;
        }
    }

    function BehavioralCollector(form, wrapper) {
        this.form = form;
        this.wrapper = wrapper || (form ? form.querySelector('[data-behavioral]') : null);
        this.pingUrl = (this.wrapper && this.wrapper.getAttribute('data-ping-url')) || '/captcha/behavioral/ping';
        this.tokenInput = form ? form.querySelector('input[name="captcha_token"]') : null;
        this.token = this.tokenInput ? this.tokenInput.value : '';
        this.token = this.token || '';

        this.events = [];
        this.interactions = 0;        // کلیک + کلید + touch (شمارش کلاینت)
        this.pingInteractions = 0;    // شمارندهٔ امضاشدهٔ سرور از آخرین ping
        this.behavioralState = '';    // آخرین state امضاشده از سرور
        this.startTime = Date.now();
        this.lastTimes = {};          // throttle per-type
        this.lastPingAt = 0;
        this.pingCount = 0;
        this.pingInFlight = false;
        this.reducedMotion = prefersReducedMotion();
        this.destroyed = false;

        this.handlers = [];
        this.bind();
        this.ping(); // state اولیه (interactions=1) — بدون آن هیچ state ای وجود ندارد
    }

    BehavioralCollector.prototype.on = function (target, type, fn, opts) {
        target.addEventListener(type, fn, opts || false);
        this.handlers.push({ target: target, type: type, fn: fn, opts: opts || false });
    };

    BehavioralCollector.prototype.unbind = function () {
        for (var i = 0; i < this.handlers.length; i++) {
            var h = this.handlers[i];
            try { h.target.removeEventListener(h.type, h.fn, h.opts); } catch (e) { /* بی‌صدا */ }
        }
        this.handlers = [];
    };

    /** ثبت رویداد خام با timestamp طبیعی (jitter انسانی برای stddev سرور حفظ می‌شود) */
    BehavioralCollector.prototype.record = function (type, x, y, opts) {
        if (this.destroyed) return;
        var now = Date.now();
        var minGap = 0;
        if (type === 'mouse_move') minGap = POINTER_GAP_MS;
        else if (type === 'scroll') minGap = SCROLL_GAP_MS;
        else if (type === 'touch_move') minGap = TOUCHMOVE_GAP_MS;

        if (minGap && this.lastTimes[type] && (now - this.lastTimes[type]) < minGap) {
            return; // throttle — بدون ساخت رویداد مصنوعیِ فاصله‌ی ثابت
        }
        this.lastTimes[type] = now;

        var ev = {
            type: type,
            time: now - this.startTime, // میلی‌ثانیهٔ نسبی (قرارداد سرور)
            x: typeof x === 'number' ? Math.round(x) : 0,
            y: typeof y === 'number' ? Math.round(y) : 0
        };

        if (this.events.length >= MAX_EVENTS) {
            if (type === 'mouse_move') return; // حرکت را فدای تعامل واقعی نکن
            // جای تعامل واقعی: قدیمی‌ترین حرکت اشاره‌گر حذف می‌شود
            for (var i = 0; i < this.events.length; i++) {
                if (this.events[i].type === 'mouse_move') { this.events.splice(i, 1); break; }
            }
            if (this.events.length >= MAX_EVENTS) return;
        }
        this.events.push(ev);

        var isInteraction = type === 'click' || type === 'keypress' ||
            type === 'touch_start' || type === 'touch_move';
        if (isInteraction) this.interactions++;

        if (opts && opts.ping) this.schedulePing();
    };

    BehavioralCollector.prototype.bind = function () {
        var self = this;
        var doc = document;
        var moveType = window.PointerEvent ? 'pointermove' : 'mousemove';

        this.on(doc, moveType, function (e) {
            self.record('mouse_move', e.clientX || 0, e.clientY || 0, { ping: true });
        });
        this.on(doc, 'click', function (e) {
            self.record('click', e.clientX || 0, e.clientY || 0, { ping: true });
        });
        this.on(doc, 'keydown', function (e) {
            if (e.repeat) return; // auto-repeat کلید = رویداد مصنوعی
            self.record('keypress', 0, 0, { ping: true });
        });
        this.on(window, 'scroll', function () {
            self.record('scroll', 0, window.scrollY || window.pageYOffset || 0, { ping: true });
        }, { passive: true });

        if (window.PointerEvent) {
            this.on(doc, 'pointerdown', function (e) {
                if (e.pointerType === 'touch') {
                    self.record('touch_start', e.clientX || 0, e.clientY || 0, { ping: true });
                }
            });
        }
        this.on(doc, 'touchstart', function (e) {
            var t = (e.touches && e.touches[0]) || null;
            self.record('touch_start', t ? t.clientX : 0, t ? t.clientY : 0, { ping: true });
        }, { passive: true });
        this.on(doc, 'touchmove', function (e) {
            var t = (e.touches && e.touches[0]) || null;
            self.record('touch_move', t ? t.clientX : 0, t ? t.clientY : 0, { ping: true });
        }, { passive: true });

        // تایمینگ فوکوسِ فیلدهای فرم (فقط در محدودهٔ همین فرم)
        if (this.form) {
            this.on(this.form, 'focusin', function () {
                self.record('focus', 0, 0, { ping: true });
            });
            this.on(this.form, 'focusout', function () {
                self.record('blur', 0, 0, { ping: true });
            });
            // پرکردن ورودی‌های مخفی دقیقاً قبل از ارسال (capture: زودتر از بقیه)
            this.on(this.form, 'submit', function () { self.fill(); }, true);
        }
    };

    /** پینگِ تعامل — شمارندهٔ امضاشدهٔ سرور را پیش می‌برد (throttle 1.1s) */
    BehavioralCollector.prototype.schedulePing = function () {
        var now = Date.now();
        if (this.pingInFlight) return;
        if (this.pingCount >= MAX_PINGS) return;
        if (this.lastPingAt && (now - this.lastPingAt) < PING_GAP_MS) return;
        this.ping();
    };

    /**
     * پینگِ تعامل — شمارندهٔ امضاشدهٔ سرور را پیش می‌برد (throttle 1.1s)
     *
     * نکتهٔ امنیتی: کانال عمدیِ این endpoint، GET است (routes/public.php) —
     * CSRFMiddleware سراسری فقط POST/PUT/PATCH/DELETE را می‌سنجد و فرمِ میزبان
     * همیشه csrf_token خودش را دارد؛ پینگِ stateless فقط شمارنده را زیاد می‌کند
     * (سقف ۳۰/min + حداقل ۱ ثانیه بین شمارش‌ها در pingBehavioral) و هیچ دسترسی‌ای
     * نمی‌دهد؛ با هدر X-Requested-With (چک is_ajax کنترلر) صدا زده می‌شود.
     */
    BehavioralCollector.prototype.ping = function () {
        if (this.destroyed || !this.pingUrl || this.pingInFlight) return;
        if (typeof window.fetch !== 'function') return; // degrade بی‌صدا
        if (!this.token) return;

        var self = this;
        this.pingInFlight = true;
        this.lastPingAt = Date.now();
        this.pingCount++;

        var url = this.pingUrl +
            (this.pingUrl.indexOf('?') === -1 ? '?' : '&') +
            'captcha_token=' + encodeURIComponent(this.token) +
            '&behavioral_state=' + encodeURIComponent(this.behavioralState || '');

        try {
            window.fetch(url, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                }
            }).then(function (r) {
                return r.ok ? r.json() : null;
            }).then(function (data) {
                if (data && data.success !== false && data.data &&
                    typeof data.data.behavioral_state === 'string' &&
                    data.data.behavioral_state.indexOf('.') !== -1) {
                    self.behavioralState = data.data.behavioral_state;
                    self.pingInteractions = parseInt(data.data.interactions, 10) || self.pingInteractions;
                }
            }).catch(function () {
                /* بی‌صدا — بدون state، سرور fail-closed رد می‌کند */
            }).then(function () {
                self.pingInFlight = false;
            });
        } catch (e) {
            this.pingInFlight = false;
        }
    };

    /** امتیاز مشورتی — بازتابِ همان شواهدی که سرور می‌سنجد */
    BehavioralCollector.prototype.computeScore = function () {
        if (this.destroyed) return 0;
        var types = {};
        for (var i = 0; i < this.events.length; i++) types[this.events[i].type] = 1;
        var typeCount = 0;
        for (var k in types) { if (Object.prototype.hasOwnProperty.call(types, k)) typeCount++; }

        var elapsedSec = Math.floor((Date.now() - this.startTime) / 1000);
        var score = (this.pingInteractions * 10) +          // شمارندهٔ امضاشدهٔ سرور
            Math.min(24, typeCount * 6) +               // تنوع رفتار
            Math.min(16, Math.floor(this.events.length / 3)) + // حجم رویداد
            Math.min(20, Math.floor(elapsedSec / 2));   // حضور
        return Math.max(0, Math.min(100, score));
    };

    /** فشرده‌سازی events داخل بودجهٔ ۸KB سرور — تعامل‌ها ترجیح دارند */
    BehavioralCollector.prototype.fitEvents = function () {
        var json = JSON.stringify(this.events);
        if (json.length <= EVENTS_JSON_BUDGET) return json;
        var kept = [];
        var moves = [];
        for (var i = 0; i < this.events.length; i++) {
            if (this.events[i].type === 'mouse_move') moves.push(this.events[i]);
            else kept.push(this.events[i]);
        }
        // نصفِ حرکت‌ها را بردار و دوباره بسنج (حلقهٔ محدود)
        while (moves.length > 8 && JSON.stringify(kept.concat(moves)).length > EVENTS_JSON_BUDGET) {
            moves.length = Math.floor(moves.length / 2);
        }
        kept = kept.concat(moves);
        kept.sort(function (a, b) { return a.time - b.time; });
        return JSON.stringify(kept);
    };

    /** پرکردن hidden input ها با نام‌هایی که سرور واقعاً می‌خواند */
    BehavioralCollector.prototype.fill = function () {
        if (!this.form) return;
        this.setHidden('behavioral_state', this.behavioralState || '');
        this.setHidden('behavioral_score', String(this.computeScore()));
        this.setHidden('events', this.fitEvents());
    };

    BehavioralCollector.prototype.setHidden = function (name, value) {
        var input = this.form.querySelector('input[type="hidden"][name="' + name + '"]');
        if (!input) {
            input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            this.form.appendChild(input);
        }
        input.value = value;
    };

    BehavioralCollector.prototype.getState = function () {
        var elapsedMs = Date.now() - this.startTime;
        return {
            interactions: this.interactions,          // شمارش کلاینت (کلیک/کلید/touch)
            serverInteractions: this.pingInteractions, // شمارندهٔ امضاشدهٔ سرور
            events: this.events.length,
            elapsedMs: elapsedMs,
            elapsedSeconds: Math.floor(elapsedMs / 1000),
            score: this.computeScore(),
            hasState: this.behavioralState !== '',
            ready: this.behavioralState !== '' &&
                this.pingInteractions >= 5 &&
                this.computeScore() >= SCORE_THRESHOLD &&
                Math.floor(elapsedMs / 1000) >= 4,
            reducedMotion: this.reducedMotion
        };
    };

    BehavioralCollector.prototype.destroy = function () {
        this.destroyed = true;
        this.unbind();
    };

    // ─── API عمومی ───
    var instances = [];

    function attach(formSelector) {
        var forms;
        try {
            forms = document.querySelectorAll(formSelector);
        } catch (e) {
            return null;
        }
        var last = null;
        for (var i = 0; i < forms.length; i++) {
            var form = forms[i];
            if (!form || form.__chortkeBehavioralAttached) continue;
            form.__chortkeBehavioralAttached = true;
            var wrapper = form.querySelector('[data-behavioral]') ||
                (form.matches && form.matches('[data-behavioral]') ? form : null);
            var inst = new BehavioralCollector(form, wrapper);
            instances.push(inst);
            last = inst;
        }
        return last;
    }

    function getState() {
        if (!instances.length) return null;
        return instances[instances.length - 1].getState();
    }

    function attachAll() {
        var wrappers = document.querySelectorAll('form [data-behavioral], form[data-behavioral]');
        for (var i = 0; i < wrappers.length; i++) {
            var w = wrappers[i];
            var form = w.closest ? w.closest('form') : (w.form || null);
            if (!form || form.__chortkeBehavioralAttached) continue;
            form.__chortkeBehavioralAttached = true;
            instances.push(new BehavioralCollector(form, form.querySelector('[data-behavioral]') || w));
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attachAll);
    } else {
        attachAll();
    }

    window.ChortkeBehavioralCaptcha = {
        attach: attach,
        getState: getState,
        /**
         * state کامل برای UI میزبان (میزبان تست) — بدون dump رویداد خام
         */
        version: 'W4-C-1'
    };
})();
