/**
 * ─── Event Delegation (CSP-safe inline handler replacement) ───────────
 * chortke / assets/js/shared/event-delegation.js
 *
 * Replaces inline `onclick="foo()"`, `onmouseover="..."`, `onchange="..."`
 * attributes with `data-action="foo"` etc., then routes DOM events to
 * global functions registered via `window.ChortkeActions`.
 *
 * SUPPORTED ATTRIBUTES:
 *   data-action="fnName"                  → click
 *   data-action-args='["arg1","arg2"]'    → args passed to fn
 *   data-mouseover="fnName"               → mouseover
 *   data-mouseout="fnName"                → mouseout
 *   data-change="fnName"                  → change (form fields)
 *   data-input="fnName"                   → input (live typing)
 *   data-submit="fnName"                  → submit (form)
 *   data-keydown="fnName"                 → keydown
 *   data-keyup="fnName"                   → keyup
 *   data-keypress="fnName"                → keypress
 *   data-focus="fnName"                   → focus
 *   data-blur="fnName"                    → blur
 *
 * SPECIAL HANDLERS:
 *   data-action="__alert" + data-action-args='["msg"]'
 *     → Calls window.alert() with msg. Falls back to Notyf if available.
 *
 *   data-action="__show-help-video" + data-action-args='["title"]'
 *     → Shows a Notyf info toast about an upcoming video.
 *
 *   data-action="__toggle-modal" + data-action-args='["#selector"]'   (FIX-X106)
 *     → Opens/closes a Bootstrap modal, or toggles hidden/flex fallback.
 *
 *   data-action="__copy" + data-action-args='["#inputSelector","toast?"]' (FIX-X106)
 *     → Copies the element's value/text to clipboard (Notyf feedback).
 *
 *   data-action="__reload"                                            (FIX-X106)
 *     → window.location.reload()
 *
 *   data-action="__back"                                              (FIX-S20-V24)
 *     → window.history.back() (replaces href="javascript:history.back()")
 *
 *   data-action="__submit-form"                                       (FIX-S20-V23)
 *     → Submits the enclosing form (replaces onchange="this.form.submit()").
 *
 *   data-action="__toggle-password" + data-action-args='["#inputSel"]' (FIX-X106)
 *     → Toggles password/text visibility on the target input.
 *
 * ARGUMENT FORMAT:
 *   The `data-action-args` attribute must be a JSON-encoded array.
 *   Each element is passed to the handler function in order.
 *   The placeholder "__this__" is automatically replaced with the
 *   originating DOM element (replaces the old `this` keyword in inline
 *   handlers).
 *
 * USAGE IN PHP VIEWS:
 *   Before:  <button onclick="accept_boost_popup()">...</button>
 *   After:   <button data-action="accept_boost_popup">...</button>
 *
 *   Before:  <button onclick="toggleAdStatus(123, this)">...</button>
 *   After:   <button data-action="toggleAdStatus"
 *                    data-action-args='["123","__this__"]'>...</button>
 *
 *   Before:  <button onclick="alert('msg')">...</button>
 *   After:   <button data-action="__alert"
 *                    data-action-args='["msg"]'>...</button>
 *
 * REGISTERING HANDLERS:
 *   Each view that needs an action must register it:
 *     window.ChortkeActions = window.ChortkeActions || {};
 *     window.ChortkeActions.myFunc = function (el, arg1, arg2) { ... };
 *   Or, simpler: just define the function globally and the dispatcher
 *   will look it up on window automatically.
 */
(function () {
    'use strict';

    // ─── Arg parser ─────────────────────────────────────────
    // Parses `data-action-args` JSON array and replaces "__this__" with
    // the originating element.
    function parseArgs(attrValue, originatingElement) {
        if (!attrValue) return [];
        try {
            const parsed = JSON.parse(attrValue);
            if (!Array.isArray(parsed)) return [];
            return parsed.map(function (a) {
                return a === '__this__' ? originatingElement : a;
            });
        } catch (e) {
            console.warn('[chortke:event-delegation] Invalid data-action-args JSON:', attrValue, e);
            return [];
        }
    }

    // 🛡️ X304: قرارداد «inlineactions» — data-args="a|b" + data-pass-el /
    // data-pass-value / data-pass-checked. پیش از این فایل فقط data-action-args
    // (JSON) را می‌فهمید و چون نگهبان ضد-دو-اجرایی FIX-X95 در inlineactions.js
    // هر هندلرِ قابل‌حل را به این فایل واگذار می‌کرد، ویوهایی که قرارداد قدیمی
    // داشتند (مثل آپلود تصویر تنظیمات) ساکت از کار می‌افتادند: تابع به‌جای id
    // خودِ Event را می‌گرفت و TypeError بلعیده می‌شد — «آپلود بدون هیچ بازخورد».
    function coerceLegacy(v) {
        if (v === 'true') return true;
        if (v === 'false') return false;
        if (v === 'null') return null;
        if (v !== '' && !isNaN(v) && /^-?\d+(\.\d+)?$/.test(v)) return Number(v);
        return v;
    }

    function legacyArgs(el) {
        if (!el || typeof el.getAttribute !== 'function') return [];
        let args = [];
        const raw = el.getAttribute('data-args');
        if (raw !== null && raw !== '') {
            args = raw.split('|').map(coerceLegacy);
        }
        if (el.hasAttribute('data-pass-el')) args.push(el);
        else if (el.hasAttribute('data-pass-value')) args.push(el.value);
        else if (el.hasAttribute('data-pass-checked')) args.push(el.checked);
        return args;
    }

    // ─── Resolve handler function ─────────────────────────
    // Look up the function by name in window.ChortkeActions first,
    // then fall back to window[name]. Returns null if not found.
    function resolveHandler(name) {
        if (!name) return null;
        if (typeof window.ChortkeActions !== 'undefined' &&
            Object.prototype.hasOwnProperty.call(window.ChortkeActions, name)) {
            return window.ChortkeActions[name];
        }
        if (typeof window[name] === 'function') {
            return window[name];
        }
        return null;
    }

    // ─── Built-in handlers ─────────────────────────────────
    const BUILTIN_HANDLERS = {
        '__alert': function (el, message) {
            // Prefer Notyf for nicer UX, fall back to alert()
            if (typeof window.Notyf !== 'undefined' && typeof window.notyf !== 'undefined') {
                window.notyf.info(message);
            } else if (typeof window.notyf !== 'undefined') {
                window.notyf.info(message);
            } else {
                window.alert(message);
            }
        },

        '__show-help-video': function (el, title) {
            if (typeof window.Notyf !== 'undefined') {
                // Try to use global notyf instance
                const n = window.notyf || (window.chortkeNotyf ? window.chortkeNotyf : null);
                if (n) {
                    n.info('ویدیوی آموزشی به‌زودی: ' + (title || ''));
                    return;
                }
            }
            window.alert('ویدیوی آموزشی به‌زودی: ' + (title || ''));
        },

        // تطابق دو فیلد (مثل رمز عبور و تکرار آن) — CSP-safe جایگزین
        // inline oninput="this.setCustomValidity(...)"
        //   <input data-input="__confirm-match"
        //          data-action-args='["#reg-password","پیام خطا"]'>
        '__confirm-match': function (el, targetSelector, message) {
            // HARDENING: اگر data-action-args ناموجود/نامعتبر باشد، parseArgs
            // آرایه خالی برمی‌گرداند و dispatcher به‌صورت خودکار Event را به‌عنوان
            // آخرین آرگومان اضافه می‌کند — بدون این گارد، Event به querySelector
            // می‌رسید و در هر input event خطا می‌داد.
            if (typeof targetSelector !== 'string' || targetSelector === '') return;
            const target = document.querySelector(targetSelector);
            if (!target) return;
            const msg = message || 'مقادیر واردشده یکسان نیستند';
            if (el.value !== target.value) {
                el.setCustomValidity(msg);
            } else {
                el.setCustomValidity('');
            }
        },

        // اجرای مجدد handler فیلد دیگر — برای وقتی که فیلد «اصلی» تغییر می‌کند
        // و باید وضعیت validity فیلد «تکرار» دوباره محاسبه شود.
        //   <input data-input="__revalidate" data-action-args='["#reg-password-confirm"]'>
        '__revalidate': function (el, targetSelector) {
            // HARDENING: بدون data-action-args معتبر، Event به‌جای selector
            // اینجا می‌افتد — گارد تایپ از TypeError در querySelector جلوگیری می‌کند.
            if (typeof targetSelector !== 'string' || targetSelector === '') return;
            const target = document.querySelector(targetSelector);
            if (!target) return;
            const action = target.getAttribute('data-input');
            if (action) {
                dispatch(action, target, target.getAttribute('data-action-args'));
            }
        },

        // FIX-X106: باز/بستن مودال.
        // ① اگر المان ساختار بوت‌استرپ (.modal) دارد و bootstrap.js هست → API رسمی
        // ② اگر .modal است ولی bootstrap.js نیست → شبیه‌سازی display/show
        // ③ بقیه (الگوی Tailwind: fixed inset-0 hidden) → toggle کلاس‌های hidden/flex
        // نکتهٔ X106b: Modal.show() بوت‌استرپ روی divهای غیر-مودالی «Illegal invocation»
        // می‌دهد — پس هرگز برای المان‌های non-.modal به API بوت‌استرپ نمی‌رویم.
        // args: [selector]
        //   data-action="__toggle-modal" data-action-args='["#new-message-modal"]'
        '__toggle-modal': function (selector) {
        const el = this; // FIX-X106c: originatingElement از this (پارامتر el غیرقابل‌اعتماد)
            // FIX-X106: args[0] یا data-target روی خود المنت (مقاوم به هر رفتار args)
        selector = (typeof selector === 'string' && selector) ? selector : el.getAttribute('data-target');
        if (!selector) return;
        const target = document.querySelector(selector);
        if (!target) return;
        if (target.classList.contains('modal')) {
            // ساختار بوت‌استرپ: اگر bootstrap.js هست API رسمی، وگرنه شبیه‌سازی
            if (typeof window.bootstrap !== 'undefined' && window.bootstrap.Modal) {
                const inst = window.bootstrap.Modal.getOrCreateInstance(target);
                if (target.classList.contains('show')) inst.hide(); else inst.show();
            } else {
                const bsHidden = getComputedStyle(target).display === 'none';
                target.classList.toggle('show', bsHidden);
                target.style.display = bsHidden ? 'block' : 'none';
                document.body.classList.toggle('modal-open', bsHidden);
            }
            return;
        }
        // الگوی Tailwind: hidden/flex
        const isHidden = target.classList.contains('hidden')
            || target.style.display === 'none'
            || getComputedStyle(target).display === 'none';
        target.classList.toggle('hidden', !isHidden);
        target.classList.toggle('flex', isHidden);
        target.style.display = isHidden ? '' : 'none';
    },
        '__copy': function (selectorOrText, toastMsg) {
        const el = this; // FIX-X106c
            if (typeof selectorOrText !== 'string' || selectorOrText === '') return;
            const srcEl = document.querySelector(selectorOrText);
            const text = srcEl ? (srcEl.value ?? srcEl.textContent ?? '') : selectorOrText;
            if (!text) return;
            const notify = function (ok) {
                const n = window.notyf || window.chortkeNotyf || null;
                if (n) { ok ? n.success(toastMsg || 'کپی شد!') : n.error('کپی ناموفق بود'); }
            };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(String(text)).then(function () { notify(true); }, function () { notify(false); });
            } else if (srcEl) {
                srcEl.select();
                try { document.execCommand('copy'); notify(true); } catch (e) { notify(false); }
            }
        },

        // FIX-X106: رفرش صفحه — برای دکمه‌های «تلاش مجدد» صفحات خطا
        '__reload': function () { window.location.reload(); },

        // FIX-S20-V24: بازگشت به صفحهٔ قبل — جایگزین href="javascript:history.back()"
        '__back': function () { window.history.back(); },

        // FIX-S20-V23: سابمیت خودکار فرم — جایگزین CSP-safe برای onchange="this.form.submit()"
        //   data-action="__submit-form"  (روی select/input فرم گذاشته می‌شود)
        '__submit-form': function () {
            const el = this;
            const form = (el && el.form) || (el && el.closest ? el.closest('form') : null);
            if (form && typeof form.requestSubmit === 'function') { form.requestSubmit(); return; }
            if (form) form.submit();
        },

        // FIX-X106: نمایش/مخفی فیلد رمز — args: [selectorOfInput]
        //   data-action="__toggle-password" data-action-args='["#password"]'
        '__toggle-password': function (selector) {
        const el = this; // FIX-X106c
            selector = (typeof selector === 'string' && selector) ? selector : el.getAttribute('data-target');
        if (!selector) return;
        const input = document.querySelector(selector);
        if (input) input.type = (input.type === 'password') ? 'text' : 'password';
    }
    };

    function dispatch(name, originatingElement, argsAttrValue, event) {
        // 🛡️ X304: اول قرارداد JSON؛ اگر غایب بود، قرارداد قدیمی data-args/
        // data-pass-* محترمانه خوانده می‌شود (سازگاری دو-سیستمی بدون شکستن هیچ ویو).
        const hasJsonArgs = typeof argsAttrValue === 'string' && argsAttrValue !== '';
        const args = hasJsonArgs
            ? parseArgs(argsAttrValue, originatingElement)
            : legacyArgs(originatingElement);

        // Built-in handlers (e.g. __alert)
        if (BUILTIN_HANDLERS[name]) {
            try {
                BUILTIN_HANDLERS[name].apply(originatingElement, args.concat([event]));
            } catch (e) {
                console.error('[chortke:event-delegation] Built-in handler error:', name, e);
            }
            return;
        }

        const fn = resolveHandler(name);
        if (!fn) {
            console.warn('[chortke:event-delegation] No handler registered for action:', name);
            return;
        }

        try {
            fn.apply(originatingElement, args.concat([event]));
        } catch (e) {
            console.error('[chortke:event-delegation] Handler error for', name, e);
        }
    }

    // ─── Event binding via delegation ───────────────────
    // Use a single delegated listener per event type on document.
    // Find the closest element with data-{event} attribute and dispatch.
    const EVENT_MAP = {
        'click':           'data-action',
        'mouseover':       'data-mouseover',
        'mouseout':        'data-mouseout',
        'change':          'data-change',
        'input':           'data-input',
        'submit':          'data-submit',
        'keydown':         'data-keydown',
        'keyup':           'data-keyup',
        'keypress':        'data-keypress',
        'focus':           'data-focus',
        'blur':            'data-blur',
    };

    function bind(eventName, attrName) {
        document.addEventListener(eventName, function (event) {
            const el = event.target.closest('[' + attrName + ']');
            if (!el) return;
            const name = el.getAttribute(attrName);
            if (!name) return;
            // فرم‌هایی که submit آن‌ها با JS هندل می‌شود، هرگز نباید
            // submit بومیِ مرورگر (full reload) هم انجام شود.
            if (eventName === 'submit') event.preventDefault();
            const argsAttr = el.getAttribute('data-action-args');
            dispatch(name, el, argsAttr, event);
        }, { passive: false });
    }

    // Bind all event types (skip mouseover/mouseout on touch devices to
    // avoid sticky hover state)
    const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
    Object.keys(EVENT_MAP).forEach(function (eventName) {
        if (isTouch && (eventName === 'mouseover' || eventName === 'mouseout')) return;
        bind(eventName, EVENT_MAP[eventName]);
    });

    // ─── Load handler (special: data-load fires on init) ──
    function fireLoadHandlers() {
        document.querySelectorAll('[data-load]').forEach(function (el) {
            const name = el.getAttribute('data-load');
            if (!name) return;
            const argsAttr = el.getAttribute('data-action-args');
            dispatch(name, el, argsAttr);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', fireLoadHandlers);
    } else {
        fireLoadHandlers();
    }

    // ─── Image error fallback handler ────────────────────
    // Replaces inline onerror="this.style.display='none'" attributes.
    // Supported data-fallback-action values:
    //   "hide-self"     → set this.style.display='none'
    //   "hide-parent"   → set this.parentElement.style.display='none'
    //   "swap-src-URL"  → replace this.src with URL
    //   "remove-self"   → this.remove()
    document.addEventListener('error', function (event) {
        const el = event.target;
        if (!el || !el.matches) return;
        if (!el.matches('img[data-fallback-action]')) return;

        const action = el.getAttribute('data-fallback-action');
        switch (action) {
            case 'hide-self':
                el.style.display = 'none';
                break;
            case 'hide-parent':
                if (el.parentElement) el.parentElement.style.display = 'none';
                break;
            case 'remove-self':
                el.remove();
                break;
            default:
                // If action looks like a URL, swap src
                if (action && (action.startsWith('/') || action.startsWith('http'))) {
                    el.src = action;
                } else {
                    // Default: hide self
                    el.style.display = 'none';
                }
        }
    }, true /* capture phase — error events don't bubble */);

    // Expose for testing
    window.ChortkeEventDelegation = {
        resolveHandler: resolveHandler,
        parseArgs: parseArgs,
        dispatch: dispatch,
    };
    // FIX-X106: مارکر نسخه + شمارش اجرا (کشف double-execution در هارنس)
    window.__x106ExecCount = (window.__x106ExecCount || 0) + 1;
    if (typeof console !== 'undefined' && console.info) {
        console.info('[chortke:event-delegation] ready #' + window.__x106ExecCount + ' (X106 builtins)');
    }
})();
