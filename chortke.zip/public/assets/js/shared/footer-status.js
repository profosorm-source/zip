/**
 * FEAT-QA5 (راند ۱۰) — Pill زندهٔ وضعیت سیستم در فوتر
 *
 * منبع داده: GET /status/api (همان کش ۳۰ثانیه‌ای صفحهٔ /status — بدون بار اضافه).
 * رفتار:
 *  - ok        → نقطهٔ سبز (نبض) + «همهٔ سرویس‌ها عملیاتی»
 *  - degraded  → نقطهٔ کهربایی + «برخی سرویس‌ها کند هستند»
 *  - down/error→ نقطهٔ قرمز + «اختلال در سرویس‌ها»
 *  - شکست fetch یا نبود pill → کاملاً بی‌صدا (فقط لینک ساده می‌ماند)
 *  - نتیجه در sessionStorage با TTL ۳۰ ثانیه‌ای کش می‌شود تا در ناوبری‌های
 *    پشت‌سرهم درخواست اضافه زده نشود (هم‌تراز با کش سمت سرور).
 *  - prefers-reduced-motion: نبض نقطه از قبل در CSS غیرفعال می‌شود.
 */
(function () {
    'use strict';

    var CACHE_KEY = 'chortke:footer-status';
    var CACHE_TTL = 30000; // هم‌تراز با کش سرورِ /status/api

    document.addEventListener('DOMContentLoaded', function () {
        var pill = document.querySelector('[data-status-pill]');
        if (!pill || !window.fetch) return;

        var cached = readCache();
        if (cached) {
            apply(pill, cached);
            return;
        }

        fetch((window.BASE_URL || '') + '/status/api', {
            headers: { 'Accept': 'application/json' },
            credentials: 'same-origin'
        })
            .then(function (res) { return res.ok ? res.json() : null; })
            .then(function (data) {
                if (!data || !data.overall) return;
                writeCache(data.overall);
                apply(pill, data.overall);
            })
            .catch(function () { /* بی‌صدا — pill به حالت خنثی می‌ماند */ });
    });

    function apply(pill, overall) {
        var state = overall === 'ok' ? 'operational' : (overall === 'degraded' ? 'degraded' : 'down');
        pill.setAttribute('data-state', state);
        var text = pill.querySelector('[data-status-text]');
        if (text) {
            text.textContent = state === 'operational'
                ? 'همهٔ سرویس‌ها عملیاتی'
                : (state === 'degraded' ? 'برخی سرویس‌ها کند هستند' : 'اختلال در سرویس‌ها');
        }
    }

    function readCache() {
        try {
            var raw = sessionStorage.getItem(CACHE_KEY);
            if (!raw) return null;
            var entry = JSON.parse(raw);
            if (!entry || !entry.state || (Date.now() - entry.at) > CACHE_TTL) return null;
            return entry.state;
        } catch (e) { return null; }
    }

    function writeCache(state) {
        try {
            sessionStorage.setItem(CACHE_KEY, JSON.stringify({ state: state, at: Date.now() }));
        } catch (e) { /* محدودیت حافظه — مهم نیست */ }
    }
})();
