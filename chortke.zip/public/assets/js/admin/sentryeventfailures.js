/* public/assets/js/admin/sentryeventfailures.js — 🛡️ FIX-EVENT-FAILURES-VISIBILITY (ممیزی outbox ۲۰۲۶-۰۸-۲۸)
   جدول event_failures توسط EventDispatcher روی هر خطای listener پر می‌شود ولی
   هیچ صفحه‌ای آن را نشان نمی‌داد. حالا صفحه فهرست با دکمه حذف رکورد وجود دارد.
   - دکمه‌های data-delete-failure در جدول ویو رندر می‌شوند؛
   - event delegation سراسری آن‌ها را وصل می‌کند؛
   - توکن CSRF از meta خوانده می‌شود؛
   - تأیید با SweetAlert2 (با fallback به confirm). */
(function () {
  'use strict';

  var csrf = (typeof window.csrfToken !== 'undefined' && window.csrfToken)
    || (document.querySelector('meta[name="csrf-token"]') || {}).content
    || '';

  function confirmAction() {
    var opts = {
      title: 'حذف این رکورد خطا؟',
      text: 'این رکورد از جدول event_failures برای همیشه حذف می‌شود (فقط رکورد لاگ — نه خود رویداد).',
      confirm: 'حذف'
    };
    if (typeof Swal !== 'undefined') {
      return Swal.fire({
        title: opts.title,
        text: opts.text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: opts.confirm,
        cancelButtonText: 'انصراف',
        confirmButtonColor: '#ef4444'
      }).then(function (r) { return r.isConfirmed; });
    }
    return Promise.resolve(confirm(opts.title));
  }

  function notifyError(msg) {
    if (typeof Swal !== 'undefined') {
      Swal.fire({ icon: 'error', title: 'خطا', text: msg || 'عملیات ناموفق بود.' });
    } else {
      alert(msg || 'عملیات ناموفق بود.');
    }
  }

  async function act(failureId) {
    var ok = await confirmAction();
    if (!ok) return;
    try {
      var res = await fetch((window.BASE_URL || '') + '/admin/sentry/event-failures/' + encodeURIComponent(failureId) + '/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-CSRF-Token': csrf
        },
        credentials: 'same-origin'
      });
      var data = {};
      try { data = await res.json(); } catch (_) {}
      if (res.ok && data.success) {
        if (typeof Swal !== 'undefined') {
          Swal.fire({ icon: 'success', title: 'حذف شد', timer: 1500, showConfirmButton: false })
            .then(function () { location.reload(); });
        } else {
          location.reload();
        }
      } else {
        notifyError(data.error || 'عملیات ناموفق بود.');
      }
    } catch (e) {
      notifyError('خطای شبکه: ' + (e && e.message ? e.message : e));
    }
  }

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest ? ev.target.closest('[data-delete-failure]') : null;
    if (!t) return;
    ev.preventDefault();
    var failureId = t.getAttribute('data-delete-failure');
    if (failureId) act(failureId);
  });
})();
