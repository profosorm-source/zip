/* admin/lottery.js — منطق ماژول لاتاری (create + show)
 * data-* روی #lotteryRoot:  data-base => /admin/lottery ، data-store => /admin/lottery/store
 * show: توابع generateNumbers/finalizeDaily/selectWinner/cancelRound (از data-click)
 */
(function () {
    'use strict';
    function root() { return document.getElementById('lotteryRoot') || document.body; }
    function d(k, fb) { var v = root().dataset[k]; return v !== undefined ? v : (fb || ''); }
    function csrf() { return window.csrfToken || ''; }

    function ajaxPost(url) {
        fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf() } })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                res.success ? notyf.success(res.message) : notyf.error(res.message);
                if (res.success) setTimeout(function () { location.reload(); }, 1200);
            });
    }
    function confirmAction(title, text, cb) {
        Swal.fire({ title: title, text: text, icon: 'question', showCancelButton: true, confirmButtonText: 'بله', cancelButtonText: 'انصراف' })
            .then(function (r) { if (r.isConfirmed) cb(); });
    }

    window.generateNumbers = function (id) { confirmAction('تولید اعداد امروز', 'آیا مطمئنید؟', function () { ajaxPost(d('base') + '/' + id + '/generate-numbers'); }); };
    window.finalizeDaily = function (dailyId) { confirmAction('نهایی‌سازی', 'عدد منتخب انتخاب و وزن‌ها اعمال می‌شود.', function () { ajaxPost(d('base') + '/daily/' + dailyId + '/finalize'); }); };
    window.selectWinner = function (id) { confirmAction('انتخاب برنده', '⚠️ این عملیات برگشت‌ناپذیر است!', function () { ajaxPost(d('base') + '/' + id + '/select-winner'); }); };
    window.cancelRound = function (id) { confirmAction('لغو دوره', 'آیا مطمئنید؟', function () { ajaxPost(d('base') + '/' + id + '/cancel'); }); };

    document.addEventListener('DOMContentLoaded', function () {
        var form = document.getElementById('roundForm');
        if (form) {
            /* FIX-X24: ویجت تاریخ datetime-local بدون مقدار پیش‌فرض رها شده بود و
             * مقادیر خالی در collect هم بی‌صدا حذف می‌شدند (if (v)) → 422 بدون message
             * → کاربر فقط «خطا» می‌دید (دکمهٔ submit عملاً بی‌اثر).
             * اکنون: prefill خودکار شروع/پایان + اعتبارسنجی سمت کلاینت + نمایش خطای
             * فیلدی 422 + هایلایت is-invalid. */
            var startInput = form.querySelector('[name="start_date"]');
            var endInput = form.querySelector('[name="end_date"]');
            var durInput = form.querySelector('[name="duration_days"]');
            var endManuallySet = false;

            function pad(n) { return (n < 10 ? '0' : '') + n; }
            function toLocalDT(d) {
                return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
            }
            function syncEnd() {
                if (!startInput || !durInput || !endInput || endManuallySet) return;
                if (!startInput.value) return;
                var s = new Date(startInput.value);
                if (isNaN(s.getTime())) return;
                var days = parseInt(durInput.value, 10);
                if (!days || days < 1) days = 7;
                s.setDate(s.getDate() + days);
                endInput.value = toLocalDT(s);
            }

            if (startInput && !startInput.value) {
                var s0 = new Date(); s0.setMinutes(s0.getMinutes() + 60);
                startInput.value = toLocalDT(s0);
            }
            if (startInput) startInput.addEventListener('change', syncEnd);
            if (durInput) durInput.addEventListener('change', syncEnd);
            if (endInput) endInput.addEventListener('input', function () { endManuallySet = true; });
            syncEnd();

            function clearInvalid() {
                form.querySelectorAll('.is-invalid').forEach(function (el) { el.classList.remove('is-invalid'); });
            }
            function showFieldErrors(errors) {
                var firstMsg = '';
                Object.keys(errors || {}).forEach(function (field) {
                    var el = form.querySelector('[name="' + field + '"]');
                    if (el) el.classList.add('is-invalid');
                    var msg = errors[field];
                    if (!firstMsg) firstMsg = Array.isArray(msg) ? msg[0] : String(msg);
                });
                if (firstMsg) notyf.error(firstMsg);
            }

            form.addEventListener('submit', function (e) {
                e.preventDefault();
                clearInvalid();

                var firstInvalid = null;
                form.querySelectorAll('[required]').forEach(function (el) {
                    var v = (el.value || '').trim();
                    el.classList.toggle('is-invalid', !v);
                    if (!v && !firstInvalid) firstInvalid = el;
                });
                if (firstInvalid) {
                    notyf.error('لطفاً فیلدهای الزامی را تکمیل کنید');
                    firstInvalid.focus();
                    return;
                }
                var feeInput = form.querySelector('[name="entry_fee"]');
                // FIX-R36-W3 (F-A21-10): «۵۰۰» فارسی دیگر NaN نمی‌شود و برای ورودی صحیحِ کاربر فارسی
                // خطای نادرست «بیشتر از صفر» نمی‌دهیم (توابع مرجع: shared/ux-extras.js)
                var feeRaw = window.chortkeNormalizeDigits ? window.chortkeNormalizeDigits(feeInput ? feeInput.value : '') : (feeInput ? feeInput.value : '');
                if (feeInput && (parseFloat(feeRaw) || 0) <= 0) {
                    feeInput.classList.add('is-invalid');
                    notyf.error('هزینه ورود باید بیشتر از صفر باشد');
                    feeInput.focus();
                    return;
                }
                if (startInput && endInput && startInput.value && endInput.value &&
                    new Date(endInput.value).getTime() <= new Date(startInput.value).getTime()) {
                    endInput.classList.add('is-invalid');
                    notyf.error('تاریخ پایان باید بعد از تاریخ شروع باشد');
                    endInput.focus();
                    return;
                }

                var btn = document.getElementById('submitBtn');
                if (btn) btn.disabled = true;
                var fd = new FormData(this); var data = {};
                fd.forEach(function (v, k) { if (v) data[k] = v; });
                fetch(d('store'), { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf() }, body: JSON.stringify(data) })
                    .then(function (r) { return r.json(); })
                    .then(function (res) {
                        if (res.success) { notyf.success(res.message); setTimeout(function () { window.location.href = d('base'); }, 1500); }
                        else { if (res.errors) { showFieldErrors(res.errors); } else { notyf.error(res.message || 'خطا در ایجاد دوره'); } if (btn) btn.disabled = false; }
                    }).catch(function () { notyf.error('خطا در ارتباط با سرور'); if (btn) btn.disabled = false; });
            });
        }
    });
})();
