/* admin/withdrawals.js — تأیید/رد برداشت (index لیست + review جزئیات)
 * data-* روی #withdrawalsRoot: data-base => /admin/withdrawals ، data-w-id (review)
 * index: .js-w-approve / .js-w-reject با data-id
 * review: توابع doApprove/doReject/confirmReject
 */
(function () {
    'use strict';
    function root() { return document.getElementById('withdrawalsRoot') || document.body; }
    function d(k, fb) { var v = root().dataset[k]; return v !== undefined ? v : (fb || ''); }
    function csrf() { return window.csrfToken || ''; }
    function post(url, body) {
        return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf() }, body: JSON.stringify(body || {}) }).then(function (r) { return r.json(); });
    }

    /* ── review: توابع تکی ── */
    window.doApprove = function () {
        var tracking = document.getElementById('trackingCode').value.trim();
        if (!tracking) { notyf.error('لطفاً شماره پیگیری را وارد کنید'); return; }
        Swal.fire({ title: 'تأیید برداشت', text: 'پرداخت با کد پیگیری «' + tracking + '» ثبت می‌شود.', icon: 'question', showCancelButton: true, confirmButtonText: '✅ تأیید', cancelButtonText: 'انصراف', confirmButtonColor: '#0ECB81' })
            .then(function (r) {
                if (!r.isConfirmed) return;
                // FIX: روت واقعی POST /admin/withdrawals/process است (قبلاً /{id}/approve → 404)
                post(d('base') + '/process', { withdrawal_id: d('wId'), payment_reference: tracking })
                    .then(function (res) { if (res.success) location.href = d('base'); else notyf.error(res.message || 'خطا'); })
                    .catch(function () { notyf.error('خطا در ارتباط با سرور'); }); // FIX-R36-W3 (F-A20-09)
            });
    };
    window.doReject = function () { var b = document.getElementById('rejectBox'); if (b) b.style.display = 'block'; };
    window.confirmReject = function () {
        var reason = document.getElementById('rejectReason').value.trim();
        Swal.fire({ title: 'رد درخواست', text: 'این عملیات غیرقابل بازگشت است.', icon: 'warning', showCancelButton: true, confirmButtonText: '⛔ رد شود', cancelButtonText: 'انصراف', confirmButtonColor: '#F6465D' })
            .then(function (r) {
                if (!r.isConfirmed) return;
                // FIX: بدنهٔ واقعی: withdrawal_id + rejection_reason
                post(d('base') + '/reject', { withdrawal_id: d('wId'), rejection_reason: reason })
                    .then(function (res) { if (res.success) location.href = d('base'); else notyf.error(res.message || 'خطا'); })
                    .catch(function () { notyf.error('خطا در ارتباط با سرور'); }); // FIX-R36-W3 (F-A20-09)
            });
    };

    /* ── index: دکمه‌های لیست ── */
    document.addEventListener('DOMContentLoaded', function () {
        var base = d('base');
        document.querySelectorAll('.js-w-approve[data-id]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var id = this.dataset.id;
                Swal.fire({ title: 'تأیید برداشت', html: '<input type="text" id="swal-track" class="swal2-input" placeholder="شماره پیگیری...">', icon: 'question', showCancelButton: true, confirmButtonText: '✅ تأیید', cancelButtonText: 'انصراف', confirmButtonColor: '#0ECB81', preConfirm: function () { var v = document.getElementById('swal-track').value.trim(); if (!v) Swal.showValidationMessage('شماره پیگیری الزامی است'); return v; } })
                    .then(function (r) { if (!r.isConfirmed) return; /* FIX: روت واقعی /process + withdrawal_id/payment_reference */ post(base + '/process', { withdrawal_id: id, payment_reference: r.value }).then(function (dd) { if (dd.success) { notyf.success(dd.message || 'برداشت تأیید شد'); setTimeout(function () { location.reload(); }, 900); } else notyf.error(dd.message || 'خطا'); }).catch(function () { notyf.error('خطا در ارتباط با سرور'); }); }); // FIX-R36-W3 (F-A20-09)
            });
        });
        document.querySelectorAll('.js-w-reject[data-id]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var id = this.dataset.id;
                Swal.fire({ title: 'رد درخواست برداشت', input: 'textarea', inputPlaceholder: 'دلیل رد...', icon: 'warning', showCancelButton: true, confirmButtonText: '⛔ رد', cancelButtonText: 'انصراف', confirmButtonColor: '#F6465D', preConfirm: function (v) { if (!v || v.trim().length < 10) { Swal.showValidationMessage('دلیل رد باید حداقل ۱۰ کاراکتر باشد'); return false; } return v.trim(); } })
                    .then(function (r) { if (!r.isConfirmed) return; /* FIX: روت واقعی /reject + withdrawal_id/rejection_reason */ post(base + '/reject', { withdrawal_id: id, rejection_reason: r.value }).then(function (dd) { if (dd.success) { notyf.success(dd.message || 'برداشت رد شد'); setTimeout(function () { location.reload(); }, 900); } else notyf.error(dd.message || 'خطا'); }).catch(function () { notyf.error('خطا در ارتباط با سرور'); }); }); // FIX-R36-W3 (F-A20-09)
            });
        });
    });
})();
