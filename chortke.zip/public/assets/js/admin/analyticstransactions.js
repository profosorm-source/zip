/* admin/analytics-transactions.js — نمودار حجم تراکنش‌ها */
(function () {
    'use strict';
    document.addEventListener('DOMContentLoaded', function () {
        var canvas = document.getElementById('transactionVolumeChart');
        if (!canvas || typeof Chart === 'undefined') return;
        var chartUrl = canvas.dataset.chartUrl;
        if (!chartUrl) return;

        // FIX-M12-12 (گزارش ماژول ۱۲): دو شکاف یک ریشه —
        //   (۱) fetch بدون X-Requested-With/Accept → گارد is_ajax endpoint به HTML
        //       ریدایرکت می‌کرد و response.json() شکست می‌خورد؛
        //   (۲) شکل داده: JS data.data.map می‌زد ولی API شکل {deposits:[],withdrawals:[]}
        //       می‌داد. اکنون هدرهای AJAX + بررسی response.ok/content-type +
        //       نرمال‌سازی دفاعی هر دو شکل + placeholder خطا/خالی.
        fetch(chartUrl, {
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
            credentials: 'same-origin'
        })
            .then(function (response) {
                if (!response.ok) throw new Error('HTTP ' + response.status);
                var ct = response.headers.get('content-type') || '';
                if (ct.indexOf('application/json') === -1) throw new Error('Unexpected content-type: ' + ct);
                return response.json();
            })
            .then(function (payload) {
                var rows = normalize(payload);
                if (!rows.length) { showEmpty(canvas); return; }
                var ctx = canvas.getContext('2d');
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: rows.map(function (item) { return item.date; }),
                        datasets: [{
                            label: 'واریز‌ها',
                            data: rows.map(function (item) { return item.deposits; }),
                            borderColor: 'rgb(40, 167, 69)',
                            backgroundColor: 'rgba(40, 167, 69, 0.1)',
                            tension: 0.4
                        }, {
                            label: 'برداشت‌ها',
                            data: rows.map(function (item) { return item.withdrawals; }),
                            borderColor: 'rgb(220, 53, 69)',
                            backgroundColor: 'rgba(220, 53, 69, 0.1)',
                            tension: 0.4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: { y: { beginAtZero: true } }
                    }
                });
            })
            .catch(function (error) {
                console.error('Error loading chart data:', error);
                showError(canvas);
            });

        // نرمال‌سازی دفاعی: [{date,deposits,withdrawals}] کانونی، یا شکل قدیمی
        // {deposits:[{date,total}], withdrawals:[{date,total}]} با merge بر اساس date
        function normalize(payload) {
            var data = payload && payload.data !== undefined ? payload.data : payload;
            if (Array.isArray(data)) {
                return data.filter(function (r) { return r && r.date !== undefined; })
                    .map(function (r) { return { date: r.date, deposits: Number(r.deposits) || 0, withdrawals: Number(r.withdrawals) || 0 }; });
            }
            if (data && (Array.isArray(data.deposits) || Array.isArray(data.withdrawals))) {
                var byDate = {};
                (data.deposits || []).forEach(function (r) {
                    if (!r || !r.date) return;
                    byDate[r.date] = byDate[r.date] || { date: r.date, deposits: 0, withdrawals: 0 };
                    byDate[r.date].deposits = Number(r.total) || 0;
                });
                (data.withdrawals || []).forEach(function (r) {
                    if (!r || !r.date) return;
                    byDate[r.date] = byDate[r.date] || { date: r.date, deposits: 0, withdrawals: 0 };
                    byDate[r.date].withdrawals = Number(r.total) || 0;
                });
                return Object.keys(byDate).sort().map(function (d) { return byDate[d]; });
            }
            return [];
        }

        function showEmpty(canvas) {
            var host = canvas.closest('.card-body') || canvas.parentElement;
            if (host) {
                var p = document.createElement('p');
                p.className = 'text-muted text-center my-3';
                p.textContent = 'داده‌ای برای نمایش در این دوره وجود ندارد.';
                host.appendChild(p);
            }
        }

        function showError(canvas) {
            var host = canvas.closest('.card-body') || canvas.parentElement;
            if (host) {
                var p = document.createElement('p');
                p.className = 'text-danger text-center my-3';
                p.textContent = 'بارگذاری داده‌های نمودار ناموفق بود؛ صفحه را دوباره بارگذاری کنید.';
                host.appendChild(p);
            }
        }
    });
})();
