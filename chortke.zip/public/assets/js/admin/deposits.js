/* admin/deposits.js — منطق مشترک ماژول‌های واریز (crypto-deposits + manual-deposits)
 * هر دو ماژول الگوی یکسان دارند؛ فقط base فرق می‌کند.
 * data-* روی #depositsRoot:
 *   data-base       => /admin/crypto-deposits  یا  /admin/manual-deposits
 *   data-verify-url => {base}/verify   (صفحهٔ index)
 *   data-reject-url => {base}/reject   (صفحهٔ index)
 *   data-deposit-id => شناسهٔ واریز (صفحهٔ review)
 */
(function () {
    'use strict';
    function root() { return document.getElementById('depositsRoot') || document.body; }
    function d(k, fb) { var v = root().dataset[k]; return v !== undefined ? v : (fb || ''); }
    function csrf() { return window.csrfToken || ''; }
    // FIX-R36-W3 (F-A20-09): گارد in-flight برای دبل‌کلیک روی تأیید/رد در صفحهٔ review
    var approveInFlight = false;

    window.copyToClipboard = function (text) {
        navigator.clipboard.writeText(text)
            .then(function () { notyf.success('کپی شد!'); })
            .catch(function () { notyf.error('خطا در کپی کردن'); });
    };

    /* ════ index: تأیید/رد با مودال ════ */
    window.verifyDeposit = function (depositId) {
        Swal.fire({
            title: 'تأیید واریز',
            html: '<p>آیا از تأیید این واریز اطمینان دارید؟</p><div style="margin-top:15px;padding:15px;background:#fff3e0;border-radius:8px;text-align:right;"><strong style="color:#f57c00;">توجه:</strong><p style="margin:5px 0 0 0;font-size:13px;color:#666;">لطفاً قبل از تأیید، تراکنش را بررسی کنید. پس از تأیید، مبلغ به کیف پول کاربر افزوده می‌شود.</p></div>',
            icon: 'question', showCancelButton: true, confirmButtonColor: '#4caf50', cancelButtonColor: '#999',
            confirmButtonText: 'بله، تأیید شود', cancelButtonText: 'انصراف'
        }).then(function (result) {
            if (!result.isConfirmed) return;
            var formData = new FormData();
            formData.append('deposit_id', depositId);
            // FIX(bug#13): سرور انتظار _csrf_token دارد؛ csrf_token همیشه CSRF fail می‌شد
            formData.append('_csrf_token', csrf());
            fetch(d('verifyUrl'), { method: 'POST', body: formData, headers: { 'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data.success) { notyf.success(data.message); setTimeout(function () { location.reload(); }, 1500); }
                    else notyf.error(data.message);
                })
                .catch(function () { notyf.error('خطا در ارتباط با سرور'); });
        });
    };
    window.showRejectModal = function (depositId) {
        var el = document.getElementById('reject_deposit_id'); if (el) el.value = depositId;
        var rr = document.getElementById('rejection_reason'); if (rr) rr.value = '';
        var m = document.getElementById('rejectModal'); if (m) m.classList.add('show');
    };
    window.closeRejectModal = function () {
        var m = document.getElementById('rejectModal'); if (m) m.classList.remove('show');
    };
    window.setReason = function (reason) {
        var rr = document.getElementById('rejection_reason'); if (rr) rr.value = reason;
    };

    /* ════ review: تأیید/رد تکی ════ */
    window.doApprove = function () {
        if (approveInFlight) return; // FIX-R36-W3 (F-A20-09)
        if (!confirm('ابتدا تراکنش در اکسپلورر بررسی می‌شود. ادامه می‌دهید؟')) return;
        approveInFlight = true;
        var base = d('base'), dId = d('depositId');
        var formData = new FormData();
        formData.append('deposit_id', dId);
        formData.append('_csrf_token', csrf());
        var preflightUrl = d('preflightUrl');
        var verifyUrl = d('verifyUrl') || (base + '/' + dId + '/approve');
        var preflight = preflightUrl
            ? fetch(preflightUrl, { method: 'POST', body: formData, headers: { 'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    if (!res.verified) throw new Error(res.reason || 'تراکنش از طریق اکسپلورر تأیید نشد');
                    return res;
                })
            : Promise.resolve({ verified: true });
        preflight.then(function () {
            return fetch(verifyUrl, { method: 'POST', body: formData, headers: { 'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest' } });
        }).then(function (r) { return r.json(); }).then(function (res) {
            if (res.success) location.href = base;
            else alert(res.message || 'خطا');
        })
            // FIX-R36-W3 (F-A20-09): خطای شبکه دیگر بی‌صدا نیست + قفل در-flight آزاد می‌شود
            .catch(function (err) { alert(err && err.message ? err.message : 'خطا در ارتباط با سرور'); })
            .finally(function () { approveInFlight = false; });
    };
    window.showReject = function () { var b = document.getElementById('rejectBox'); if (b) b.style.display = 'block'; };
    window.doReject = function () {
        if (approveInFlight) return; // FIX-R36-W3 (F-A20-09): همان قفل مشترک approve/reject
        var dId = d('depositId');
        var reason = document.getElementById('rejectReason').value;
        // FIX-S33-REJ (گزارش بخش ۱۳): endpoint قبلی (base+'/'+dId+'/reject') وجود
        // نداشت (404) و نام فیلد هم با سرور نمی‌خواند؛ قرارداد رسمی:
        // POST /admin/crypto-deposits/reject با deposit_id + rejection_reason
        var rejectUrl = d('rejectUrl') || (d('base') + '/reject');
        approveInFlight = true;
        var rejectForm = new FormData();
        rejectForm.append('deposit_id', dId);
        rejectForm.append('rejection_reason', reason);
        rejectForm.append('_csrf_token', csrf());
        fetch(rejectUrl, { method: 'POST', body: rejectForm, headers: { 'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); }).then(function (res) { if (res.success) location.href = d('base'); else alert(res.message || 'خطا'); })
            // FIX-R36-W3 (F-A20-09)
            .catch(function () { alert('خطا در ارتباط با سرور'); })
            .finally(function () { approveInFlight = false; });
    };

    document.addEventListener('DOMContentLoaded', function () {
        var rejectForm = document.getElementById('rejectForm');
        // فقط در صفحهٔ index که rejectForm + verifyUrl دارد
        if (rejectForm && d('rejectUrl')) {
            rejectForm.addEventListener('submit', function (e) {
                e.preventDefault();
                fetch(d('rejectUrl'), { method: 'POST', body: new FormData(this) })
                    .then(function (res) { return res.json(); })
                    .then(function (data) {
                        if (data.success) { window.closeRejectModal(); notyf.success(data.message); setTimeout(function () { location.reload(); }, 1000); }
                        else notyf.error(data.message);
                    })
                    .catch(function () { notyf.error('خطا در ارتباط با سرور'); });
            });
        }
    });
})();
