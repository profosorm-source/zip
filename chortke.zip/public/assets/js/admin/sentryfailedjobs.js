/* public/assets/js/admin/sentryfailedjobs.js — استخراج‌شده از views/admin/sentry/failed-jobs.php برای سازگاری با CSP و کش‌پذیری */
/* 🛡️ FIX-SENTRY-FAILED-JOB-BUTTONS (pre-existing):
   توابع retryJob/deleteJob قبلاً تعریف می‌شدند ولی هیچ دکمه‌ای در ویو نبود و
   هیچ event-listener ای وصل نبود (کاملاً مرده). حالا:
   - دکمه‌های data-retry-job / data-forget-job در جدول ویو رندر می‌شوند؛
   - event delegation سراسری آن‌ها را وصل می‌کند؛
   - توکن CSRF از meta خوانده می‌شود (window.csrfToken در layout ادمین تعریف نمی‌شود)؛
   - تأیید با SweetAlert2 (با fallback به confirm). */
(function () {
  'use strict';

  var csrf = (typeof window.csrfToken !== 'undefined' && window.csrfToken)
    || (document.querySelector('meta[name="csrf-token"]') || {}).content
    || '';

  function confirmAction(isRetry) {
    var opts = isRetry
      ? { title: 'ارسال مجدد این job؟', text: 'job دوباره به صف ارسال و رکوردش از لیست حذف می‌شود.', confirm: 'ارسال مجدد' }
      : { title: 'حذف این رکورد؟', text: 'این failed job برای همیشه حذف می‌شود و قابل بازیابی نیست.', confirm: 'حذف' };
    if (typeof Swal !== 'undefined') {
      return Swal.fire({
        title: opts.title,
        text: opts.text,
        icon: isRetry ? 'question' : 'warning',
        showCancelButton: true,
        confirmButtonText: opts.confirm,
        cancelButtonText: 'انصراف',
        confirmButtonColor: isRetry ? '#10b981' : '#ef4444'
      }).then(function (r) { return r.isConfirmed; });
    }
    return Promise.resolve(confirm(opts.title));
  }

  function notifyError(msg) {
    if (typeof Swal !== 'undefined') {
      Swal.fire({ icon: 'error', title: 'خطا', text: msg || 'عملیات ناموفق بود.' });
    } else {
      alert(msg || 'عملیات ناموفق بود.');
    }
  }

  async function act(jobId, action) {
    var ok = await confirmAction(action === 'retry');
    if (!ok) return;
    try {
      var res = await fetch((window.BASE_URL || '') + '/admin/sentry/failed-jobs/' + encodeURIComponent(jobId) + '/' + action, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-CSRF-Token': csrf
        },
        credentials: 'same-origin'
      });
      var data = {};
      try { data = await res.json(); } catch (_) {}
      if (res.ok && data.success) {
        if (typeof Swal !== 'undefined') {
          Swal.fire({
            icon: 'success',
            title: action === 'retry' ? 'Job دوباره ارسال شد.' : 'Job حذف شد.',
            timer: 1200,
            showConfirmButton: false
          }).then(function () { window.location.reload(); });
        } else {
          window.location.reload();
        }
      } else {
        notifyError(data.error || 'عملیات ناموفق بود.');
      }
    } catch (e) {
      notifyError('خطا در ارتباط با سرور: ' + (e && e.message ? e.message : ''));
    }
  }

  document.addEventListener('click', function (event) {
    var retryBtn = event.target.closest('[data-retry-job]');
    if (retryBtn) {
      event.preventDefault();
      act(retryBtn.getAttribute('data-retry-job'), 'retry');
      return;
    }
    var forgetBtn = event.target.closest('[data-forget-job]');
    if (forgetBtn) {
      event.preventDefault();
      act(forgetBtn.getAttribute('data-forget-job'), 'forget');
    }
  });
})();
