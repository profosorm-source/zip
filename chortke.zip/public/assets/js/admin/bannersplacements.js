/* admin/banners-placements.js — منطق صفحهٔ جایگاه بنرها
 * FIX-R36-W3 (F-A21-12): «ویرایش جایگاه» دیگر alert استاب نیست — به روت واقعی
 * POST /admin/banners/placements/{id}/update وصل شد (BannerController::updatePlacement؛
 * فیلدهای مجاز: title/description/max_banners/is_active/show_on_mobile/show_on_desktop/
 * rotation_speed/display_style/auto_rotate/max_width/max_height). ارسال با فرم مخفی native
 * (CSP-safe؛ سرور redirect+flash دارد پس fetch پاسخ را درست نشان نمی‌دهد).
 */
(function () {
    'use strict';

    function placementsBase() {
        // base را از فرم toggle موجود صفحه استخراج کن (سازگار با base-path هر دیپلوی)
        var toggleForm = document.querySelector('form[action*="/admin/banners/placements/toggle"]');
        if (toggleForm) {
            var action = toggleForm.getAttribute('action') || '';
            var idx = action.indexOf('/admin/banners/placements/toggle');
            if (idx !== -1) return action.slice(0, idx) + '/admin/banners/placements';
        }
        return '/admin/banners/placements';
    }

    function submitPlacementUpdate(id, fields) {
        var csrf = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = placementsBase() + '/' + encodeURIComponent(id) + '/update';
        form.style.display = 'none';

        var appendField = function (name, value) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = value;
            form.appendChild(input);
        };
        appendField('_csrf_token', csrf); // قرارداد کاننیکال core/CSRF.php
        Object.keys(fields).forEach(function (name) {
            if (fields[name] !== '' && fields[name] !== null && typeof fields[name] !== 'undefined') {
                appendField(name, fields[name]);
            }
        });

        document.body.appendChild(form);
        form.submit();
    }

    window.editPlacement = function (id) {
        var title = null, maxBanners = null, description = null;

        if (window.Swal) {
            window.Swal.fire({
                title: 'ویرایش جایگاه #' + id,
                html:
                    '<input id="plc-title" class="swal2-input" placeholder="عنوان (خالی = بدون تغییر)">' +
                    '<input id="plc-max" type="number" min="1" class="swal2-input" placeholder="حداکثر بنر (خالی = بدون تغییر)">' +
                    '<textarea id="plc-desc" class="swal2-textarea" placeholder="توضیح (خالی = بدون تغییر)"></textarea>',
                showCancelButton: true,
                confirmButtonText: 'ذخیره',
                cancelButtonText: 'انصراف',
                focusConfirm: false,
                preConfirm: function () {
                    return {
                        title: (document.getElementById('plc-title') || {}).value || '',
                        max_banners: (document.getElementById('plc-max') || {}).value || '',
                        description: (document.getElementById('plc-desc') || {}).value || ''
                    };
                }
            }).then(function (result) {
                if (!result.isConfirmed || !result.value) return;
                var v = result.value;
                // هیچ فیلدی پر نشده ⇒ ارسال بی‌مصرد (سرور با دیتای خالی آپدیت نمی‌کند)
                if (!v.title && !v.max_banners && !v.description) return;
                submitPlacementUpdate(id, v);
            });
            return;
        }

        // fallback بدون Swal — زنجیرهٔ prompt
        title = prompt('عنوان جایگاه (خالی = بدون تغییر):');
        if (title === null) return;
        maxBanners = prompt('حداکثر تعداد بنر (خالی = بدون تغییر):');
        if (maxBanners === null) return;
        description = prompt('توضیح جایگاه (خالی = بدون تغییر):');
        if (description === null) return;
        if (title === '' && maxBanners === '' && description === '') return; // هیچ تغییری نه
        submitPlacementUpdate(id, { title: title, max_banners: maxBanners, description: description });
    };
})();
