/* admin/logs-dashboard.js — استخراج‌شده از views/admin/logs/dashboard.php (CSP-safe)
 * 🛡️ FIX-ADMIN-PAGE-JS-WIRING: __D[0]/__D[1] قبلاً به‌صورت متنِ خام داخل template
 * literal بودند (period=__D[0]) و مقدار واقعی دوره ارسال نمی‌شد؛ درست شد.
 * گارد Chart/canvas اضافه شد تا در نبود کتابخانه یا المان، صفحه crash نکند. */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('logs-dashboard-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();
var errorsPeriod = parseInt(__D[0], 10) || 7;
var perfPeriod = parseInt(__D[1], 10) || 7;

// FIX-X205 (راند ۵۵): هدر قراردادی کدبیس — بدون آن گارد is_ajax سمت سرور این fetch را ردایرکت می‌کند
var AJAX_HEADERS = { 'X-Requested-With': 'XMLHttpRequest' };

if (typeof Chart === 'undefined') return;

// نمودار خطاها
fetch((window.BASE_URL || '') + '/admin/logs/api-stats?type=errors&period=' + errorsPeriod, { headers: AJAX_HEADERS })
    .then(r => r.json())
    .then(data => {
        const ctx = document.getElementById('errorsChart');
        if (!ctx || !data || !Array.isArray(data)) return;
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.map(d => d.date),
                datasets: [{
                    label: 'خطاها',
                    data: data.map(d => d.count),
                    borderColor: 'rgb(220, 53, 69)',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    });

// نمودار عملکرد
fetch((window.BASE_URL || '') + '/admin/logs/api-stats?type=performance&period=' + perfPeriod, { headers: AJAX_HEADERS })
    .then(r => r.json())
    .then(data => {
        const ctx = document.getElementById('performanceChart');
        if (!ctx || !data || !Array.isArray(data)) return;
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.map(d => d.date),
                datasets: [{
                    label: 'زمان اجرا (ms)',
                    data: data.map(d => d.avg_time),
                    borderColor: 'rgb(13, 110, 253)',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    });

// بروزرسانی خودکار هر 30 ثانیه
setInterval(() => {
    location.reload();
}, 30000);

})();
