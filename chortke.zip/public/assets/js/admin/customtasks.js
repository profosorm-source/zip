/* admin/custom-tasks.js — منطق ماژول وظایف سفارشی (index تأیید/رد + show تأیید/رد اجباری + disputes داوری + parked بازگردانی)
 * data-* روی #customTasksRoot:
 *   data-approve-url        => /admin/custom-tasks/approve
 *   data-resolve-url        => /admin/custom-tasks/disputes/resolve
 *   data-force-approve-url  => /admin/custom-tasks/submissions/force-approve   (FIX-M22-05)
 *   data-force-reject-url   => /admin/custom-tasks/submissions/force-reject    (FIX-M22-05)
 *   data-reset-parked-url   => /admin/custom-tasks/submissions/reset-attempts  (FIX-N22-02)
 * FIX-M22-06: دکمه‌های داوری با data-decision تصمیم اولیه را پیش‌انتخاب می‌کنند
 * و همهٔ fetchها .catch دارند (خطای شبکه/CSRF دیگر بی‌صدا نمی‌ماند).
 */
(function () {
    'use strict';
    function root() { return document.getElementById('customTasksRoot') || document.body; }
    function d(k, fb) { var v = root().dataset[k]; return v !== undefined ? v : (fb || ''); }
    function csrf() { return window.csrfToken || ''; }
    function notyfInst() { return new Notyf({ duration: 3000, position: { x: 'left', y: 'top' } }); }
    function netError() { notyfInst().error('خطای شبکه یا پاسخ نامعتبر از سرور؛ عملیات انجام نشد.'); }
    /* R30: دادهٔ کاربر هرگز خام به sink های html (مانند Swal html) تزریق نمی‌شود */
    function escHtml(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        /* ── index: تأیید/رد وظیفه ── */
        var approveUrl = d('approveUrl');
        document.querySelectorAll('.btn-approve-task').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var taskId = this.dataset.id;
                var decision = this.dataset.decision;
                if (decision === 'reject') {
                    Swal.fire({ title: 'رد وظیفه', input: 'text', inputLabel: 'دلیل رد:', showCancelButton: true, confirmButtonColor: '#f44336', confirmButtonText: 'رد و بازگشت بودجه', cancelButtonText: 'انصراف', inputValidator: function (v) { if (!v) return 'دلیل را بنویسید'; } })
                        .then(function (result) { if (result.isConfirmed) sendApprove(taskId, 'reject', result.value); });
                } else {
                    Swal.fire({ title: 'تأیید وظیفه', text: 'این وظیفه فعال خواهد شد.', icon: 'question', showCancelButton: true, confirmButtonText: 'تأیید', cancelButtonText: 'انصراف' })
                        .then(function (result) { if (result.isConfirmed) sendApprove(taskId, 'approve', null); });
                }
            });
        });
        function sendApprove(taskId, decision, reason) {
            fetch(approveUrl, {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json', 'X-CSRF-Token': csrf() },
                body: JSON.stringify({ _csrf_token: csrf(), task_id: taskId, decision: decision, reason: reason })
            }).then(function (r) { return r.json(); }).then(function (data) {
                var n = notyfInst();
                if (data.success || data.ok) { n.success(data.message); setTimeout(function () { location.reload(); }, 1500); } else n.error(data.message);
            }).catch(function () { netError(); }); /* FIX-M22-06: خطای شبکه/پاسخ غیر-JSON (مثل صفحهٔ CSRF) دیگر بی‌صدا نمی‌ماند */
        }

        /* ── disputes: داوری اختلاف ── */
        var resolveUrl = d('resolveUrl');
        document.querySelectorAll('.btn-resolve').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var disputeId = this.dataset.id;
                var reason = this.dataset.reason || '';
                var reasonHtml = escHtml(reason); /* R30: جلوگیری از XSS — dataset مقدار decode-شدهٔ خام را می‌دهد */
                var refType = this.dataset.refType || '';
                var isVitrine = (refType === 'vitrine_listing');
                /* FIX-M22-06: دکمهٔ زده‌شده تصمیم اولیه را تعیین می‌کند (قبلاً پیش‌فرض همیشه executor بود
                   و ادمینِ «حل میانه» می‌توانست ناخواسته پرداخت کامل ثبت کند) */
                var preset = this.dataset.decision || 'executor';
                function option(v, t) { return '<option value="' + v + '"' + (v === preset ? ' selected' : '') + '>' + t + '</option>'; }
                var decisionHtml, penaltyVisible;
                /* FIX-M22-MED (N4/D3-N2): مقادیر canonical فقط — ولیدیتور
                   ResolveExecutorDisputeRequest فقط executor|advertiser|split
                   می‌پذیرد؛ مقادیر قبلی buyer/seller همیشه 422 می‌شدند.
                   resolveForAdmin خودش برای ویترین advertiser→buyer (استرداد)
                   و executor→seller (آزادسازی) را نگاشت می‌کند. split طبق همان
                   الگوی شاخهٔ تسک سفارشی اضافه شد (سرویس ویترین در صورت
                   انتخاب، fail-closed با پیام فارسی). */
                if (isVitrine) {
                    decisionHtml = '<select id="swal-decision" class="form-select form-select-sm">' + option('advertiser', 'حق با خریدار (استرداد وجه)') + option('executor', 'حق با فروشنده (آزادسازی وجه)') + option('split', 'حل میانه (پرداخت درصدی)') + '</select>';
                    penaltyVisible = true;
                } else {
                    decisionHtml = '<select id="swal-decision" class="form-select form-select-sm">' + option('executor', 'حق با مجری/کارمند (تأیید و پرداخت کامل)') + option('advertiser', 'حق با تبلیغ‌دهنده (رد ارسال)') + option('split', 'حل میانه (پرداخت درصدی به مجری)') + '</select>';
                    penaltyVisible = true;
                }
                var penaltyDiv = penaltyVisible
                    ? '<div class="mb-2"><label class="form-label">درصد پرداخت به مجری در حالت حل میانه:</label><input type="number" id="swal-penalty" class="form-control form-control-sm" value="50" min="1" max="99"></div>'
                    : '<input type="hidden" id="swal-penalty" value="0">';
                Swal.fire({
                    title: 'داوری اختلاف',
                    html: '<div style="text-align:right;direction:rtl;font-size:13px;"><p><strong>دلیل اختلاف:</strong> ' + reasonHtml + '</p><hr><div class="mb-2"><label class="form-label">تصمیم:</label>' + decisionHtml + '</div>' + penaltyDiv + '<div class="mb-2"><label class="form-label">توضیحات ادمین:</label><textarea id="swal-note" class="form-control form-control-sm" rows="2"></textarea></div></div>',
                    showCancelButton: true, confirmButtonText: 'ثبت تصمیم', cancelButtonText: 'انصراف', width: 500,
                    preConfirm: function () { return { decision: document.getElementById('swal-decision').value, executor_percent: parseFloat(document.getElementById('swal-penalty').value) || 0, note: document.getElementById('swal-note').value }; }
                }).then(function (result) {
                    if (!result.isConfirmed) return;
                    fetch(resolveUrl, {
                        method: 'POST',
                        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json', 'X-CSRF-Token': csrf() },
                        body: JSON.stringify({ _csrf_token: csrf(), dispute_id: disputeId, decision: result.value.decision, admin_note: result.value.note, executor_percent: result.value.executor_percent })
                    }).then(function (r) { return r.json(); }).then(function (data) {
                        var n = notyfInst();
                        if (data.success || data.ok) { n.success(data.message); setTimeout(function () { location.reload(); }, 1500); } else n.error(data.message);
                    }).catch(function () { netError(); }); /* FIX-M22-06: شکست تصمیم مالی بی‌صدا نمی‌ماند */
                });
            });
        });

        /* ── show: تأیید/رد اجباری submission (FIX-M22-05 — این اندپوینت‌ها قبلاً هیچ UIای نداشتند) ── */
        var forceApproveUrl = d('forceApproveUrl');
        var forceRejectUrl = d('forceRejectUrl');
        function sendForce(url, body) {
            fetch(url, {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/json', 'X-CSRF-Token': csrf() },
                body: JSON.stringify(body)
            }).then(function (r) { return r.json(); }).then(function (data) {
                var n = notyfInst();
                if (data.success || data.ok) { n.success(data.message || 'انجام شد.'); setTimeout(function () { location.reload(); }, 1500); } else n.error(data.message || 'عملیات انجام نشد.');
            }).catch(function () { netError(); });
        }
        document.querySelectorAll('.btn-force-approve').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var submissionId = this.dataset.id;
                Swal.fire({
                    title: 'تأیید اجباری',
                    text: 'پاداش این ارسال از صندوق امانی به مجری آزاد می‌شود. مطمئن هستید؟',
                    icon: 'warning', showCancelButton: true,
                    confirmButtonText: 'تأیید و پرداخت', cancelButtonText: 'انصراف', confirmButtonColor: '#198754'
                }).then(function (result) {
                    if (result.isConfirmed) sendForce(forceApproveUrl, { _csrf_token: csrf(), submission_id: submissionId });
                });
            });
        });
        document.querySelectorAll('.btn-force-reject').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var submissionId = this.dataset.id;
                Swal.fire({
                    title: 'رد اجباری', input: 'text', inputLabel: 'دلیل رد:',
                    showCancelButton: true, confirmButtonColor: '#f44336',
                    confirmButtonText: 'رد', cancelButtonText: 'انصراف',
                    inputValidator: function (v) { if (!v) return 'دلیل را بنویسید'; }
                }).then(function (result) {
                    if (result.isConfirmed) sendForce(forceRejectUrl, { _csrf_token: csrf(), submission_id: submissionId, reason: result.value });
                });
            });
        });

        /* ── parked: بازگردانی ردیف پارک‌شدهٔ sweep به صف تأیید (FIX-N22-02) ── */
        var resetParkedUrl = d('resetParkedUrl');
        document.querySelectorAll('.btn-reset-parked').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var submissionId = this.dataset.id;
                Swal.fire({
                    title: 'بازگردانی به صف تأیید',
                    text: 'شمارندهٔ شکست این ارسال صفر می‌شود و دور بعدی sweep دوباره تلاش می‌کند. مطمئن هستید؟',
                    icon: 'question', showCancelButton: true,
                    confirmButtonText: 'بازگردانی', cancelButtonText: 'انصراف', confirmButtonColor: '#f0ad4e'
                }).then(function (result) {
                    if (result.isConfirmed) sendForce(resetParkedUrl, { _csrf_token: csrf(), submission_id: submissionId });
                });
            });
        });
    });
})();
