/* admin/sentry-dashboard.js — استخراج‌شده از views/admin/sentry/dashboard.php (CSP-safe)
 * 🛡️ FIX-ADMIN-PAGE-JS-WIRING: گارد Chart/canvas اضافه شد — این ویو در حال حاضر
 * المان چارت ندارد و Chart.js در لی‌اوت ادمین لود نمی‌شود؛ بدون گارد کل
 * اسکریپت با ReferenceError می‌مرد. */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('sentry-dashboard-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();

if (typeof Chart === 'undefined') return;
if (!document.getElementById('errorsChart') || !document.getElementById('performanceChart')) return;
if (!Array.isArray(__D[0]) || !Array.isArray(__D[1])) return;

        // Errors Chart
        new Chart(document.getElementById('errorsChart'), {
            type: 'line',
            data: {
                labels: __D[0],
                datasets: [{
                    label: 'خطاها',
                    data: __D[1],
                    borderColor: '#f56565',
                    backgroundColor: 'rgba(245, 101, 101, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                }
            }
        });

        // Performance Chart
        new Chart(document.getElementById('performanceChart'), {
            type: 'line',
            data: {
                labels: __D[2],
                datasets: [{
                    label: 'زمان پاسخ (ms)',
                    data: __D[3],
                    borderColor: '#48bb78',
                    backgroundColor: 'rgba(72, 187, 120, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                }
            }
        });
    
})();
