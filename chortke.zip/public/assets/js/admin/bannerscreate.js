/* admin/banners-create.js — منطق فرم ساخت/ویرایش بنر */
(function () {
    'use strict';
    window.toggleCategory = function (type) {
        var el = document.getElementById('categoryGroup');
        if (el) {
            el.style.display = (type === 'startup' || type === 'user') ? 'block' : 'none';
        }
    };

    // FIX-X111: قرارداد X106 — ثبت استاندارد هندلرها
    window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
        toggleCategory: window.toggleCategory
    });
})();
