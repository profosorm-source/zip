/* admin/vitrine-dispute.js — استخراج‌شده از views/admin/vitrine/dispute.php (CSP-safe) */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('vitrine-dispute-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();

const CSRF = document.querySelector('meta[name="csrf-token"]')?.content || '';
const ID   = __D[0];
// FIX-R36-W3 (F-A20-09): گارد in-flight — resolve اسکرو دو بار پست نشود
var resolveInFlight = false;
window.resolveDispute = function(winner) {
  if (resolveInFlight) return;
  const msg = winner === 'seller'
    ? `وجه ${__D[1]} USDT به فروشنده پرداخت شود؟`
    : `وجه ${__D[2]} USDT به خریدار استرداد شود؟`;

  if (!confirm(msg + '\n\nاین عمل غیرقابل بازگشت است.')) return;
  resolveInFlight = true;

  fetch((window.BASE_URL || '') + `/admin/vitrine/${ID}/resolve`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
    body: JSON.stringify({ winner })
  })
  .then(r => r.json())
  .then(d => {
    alert(d.success ? '✅ ' + (d.message || 'انجام شد') : '❌ ' + (d.message || 'خطا'));
    if (d.success) window.location.href = (window.BASE_URL || '') + '/admin/vitrine?status=disputed';
  })
  // FIX-R36-W3 (F-A20-09): خطای شبکه بی‌صدا نباشد + قفل آزاد شود
  .catch(() => { alert('❌ خطا در ارتباط با سرور'); })
  .finally(() => { resolveInFlight = false; });
}

})();
