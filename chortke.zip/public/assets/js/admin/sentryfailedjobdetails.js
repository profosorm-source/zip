/* admin/sentry-failed-job-details.js — عملیات retry/forget روی job */
/* 🛡️ FIX-SENTRY-FAILED-JOB-BUTTONS (pre-existing):
   - window.handleAction تعریف می‌شد ولی هیچ دکمه‌ای در ویو آن را صدا نمی‌زد
     و عنصر #statusMessage هم وجود نداشت (کاملاً مرده).
   - window.csrfToken در layout ادمین تعریف نمی‌شود → هدر CSRF با undefined
     می‌رفت و میدل‌ویر CSRF درخواست را رد می‌کرد. حالا از meta خوانده می‌شود.
   - تأیید حذف با SweetAlert2 (fallback: confirm). */
(function () {
    'use strict';

    var csrf = (typeof window.csrfToken !== 'undefined' && window.csrfToken)
        || (document.querySelector('meta[name="csrf-token"]') || {}).content
        || '';

    var statusMessage = document.getElementById('statusMessage');
    // base-url و آدرس لیست از data-* روی همان عنصر خوانده می‌شوند
    var actionBase = statusMessage ? statusMessage.dataset.actionBase : '';
    var listUrl = statusMessage ? statusMessage.dataset.listUrl : '';

    function confirmAction(action) {
        var opts = action === 'retry'
            ? { title: 'ارسال مجدد این job؟', text: 'job دوباره به صف ارسال و رکوردش از لیست حذف می‌شود.', confirm: 'ارسال مجدد', color: '#10b981' }
            : { title: 'حذف این رکورد؟', text: 'این failed job برای همیشه حذف می‌شود و قابل بازیابی نیست.', confirm: 'حذف', color: '#ef4444' };
        if (typeof Swal !== 'undefined') {
            return Swal.fire({
                title: opts.title,
                text: opts.text,
                icon: action === 'retry' ? 'question' : 'warning',
                showCancelButton: true,
                confirmButtonText: opts.confirm,
                cancelButtonText: 'انصراف',
                confirmButtonColor: opts.color
            }).then(function (r) { return r.isConfirmed; });
        }
        return Promise.resolve(confirm(opts.title));
    }

    window.handleAction = async function (action) {
        if (!statusMessage) return;
        var ok = await confirmAction(action);
        if (!ok) return;
        var url = actionBase + '/' + action;
        try {
            var res = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-Token': csrf
                },
                credentials: 'same-origin'
            });
            var data = {};
            try { data = await res.json(); } catch (_) {}
            statusMessage.style.display = 'block';
            if (res.ok && data.success) {
                statusMessage.innerText = action === 'retry' ? 'Job با موفقیت دوباره ارسال شد.' : 'Job با موفقیت حذف شد.';
                statusMessage.style.background = '#c6f6d5';
                statusMessage.style.color = '#22543d';
                if (action === 'forget') {
                    setTimeout(function () { window.location.href = listUrl; }, 900);
                } else {
                    setTimeout(function () { window.location.reload(); }, 900);
                }
            } else {
                statusMessage.innerText = data.error || 'عملیات ناموفق بود.';
                statusMessage.style.background = '#fed7d7';
                statusMessage.style.color = '#c53030';
            }
        } catch (error) {
            statusMessage.style.display = 'block';
            statusMessage.innerText = 'خطا در ارتباط با سرور.';
            statusMessage.style.background = '#fed7d7';
            statusMessage.style.color = '#c53030';
        }
    };
})();
