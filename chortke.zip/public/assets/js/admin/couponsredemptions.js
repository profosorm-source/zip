/* admin/coupons-redemptions.js — صفحه تاریخچه مصرف کوپن‌ها
 * 🛡️ FIX-COUPON-ADMIN-JS: بازنویسی با vanilla JS — نسخه‌ی قبلی به jQuery و
 * DataTables (که در لی‌اوت ادمین/CSP موجود نیستند) وابسته بود و عملاً no-op بود.
 * جدول سمت سرور رندر می‌شود؛ اینجا فقط فیلتر سریع متن اضافه شده است. */
(function () {
  'use strict';

  var table = document.getElementById('redemptionsTable');
  if (!table) return;

  var filterInput = document.getElementById('redemptionsFilter');
  if (!filterInput) return;

  filterInput.addEventListener('input', function () {
    var q = filterInput.value.trim().toLowerCase();
    var rows = table.querySelectorAll('tbody tr');
    rows.forEach(function (tr) {
      if (!q) { tr.style.display = ''; return; }
      var text = (tr.textContent || '').toLowerCase();
      tr.style.display = text.indexOf(q) !== -1 ? '' : 'none';
    });
  });
})();
