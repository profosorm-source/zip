/* admin/api-tokens-index.js — استخراج‌شده از views/admin/api-tokens/index.php (CSP-safe) */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('api-tokens-index-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();

const csrfToken = __D[0];
// FIX-R36-W3 (F-A20-09): feedback خطا + گارد in-flight (ابراز ابطال گروهی دو بار اجرا نشود)
var revokeInFlight = false;
window.revokeToken = function(id) {
    if (revokeInFlight) return;
    if (!confirm('این توکن را باطل کنید؟')) return;
    revokeInFlight = true;
    fetch(`${__D[1]}/${id}/revoke`, {
        method: 'POST', headers: {'X-CSRF-Token': csrfToken}
    }).then(r => {
        // FIX-M11-SF-002/006 (گزارش دوم): قرارداد هم‌زمان r.ok و d.success —
        // 404/409/500 دیگر مسیر موفق UI را نمی‌گیرند
        return r.json().then(d => ({ ok: r.ok, d }));
    }).then(({ ok, d }) => {
        if (ok && d.success) { notyf.success(d.message || 'توکن باطل شد'); setTimeout(() => location.reload(), 1000); }
        else notyf.error(d.message || 'ابطال انجام نشد');
    }).catch(() => {
        notyf.error('خطا در ارتباط با سرور'); // FIX-R36-W3 (F-A20-09)
    }).finally(() => { revokeInFlight = false; });
}
// W4-E: تمدید ۹۰ روزهٔ توکن — همان قرارداد و الگوی revoke بالا
// (گارد in-flight مستقل، confirm فارسی، X-CSRF-Token، catch + restore، reload بعد از موفقیت)
var renewInFlight = false;
window.renewToken = function(id) {
    if (renewInFlight) return;
    if (!confirm('این توکن تا ۹۰ روز دیگر تمدید شود؟')) return;
    renewInFlight = true;
    fetch(`${__D[1]}/${id}/renew`, {
        method: 'POST', headers: {'X-CSRF-Token': csrfToken}
    }).then(r => {
        // FIX-M11-SF-002/006 (گزارش دوم): gIARD r.ok + d.success
        return r.json().then(d => ({ ok: r.ok, d }));
    }).then(({ ok, d }) => {
        if (ok && d.success) { notyf.success(d.message || 'توکن تمدید شد'); setTimeout(() => location.reload(), 1000); }
        else notyf.error(d.message || 'تمدید انجام نشد');
    }).catch(() => {
        notyf.error('خطا در ارتباط با سرور');
    }).finally(() => { renewInFlight = false; });
}
window.revokeExpired = function() {
    if (revokeInFlight) return;
    if (!confirm('همه توکن‌های منقضی باطل شوند؟')) return;
    revokeInFlight = true;
    fetch(__D[2], {
        method: 'POST', headers: {'X-CSRF-Token': csrfToken}
    }).then(r => {
        // FIX-M11-SF-006 (گزارش دوم): قبلاً بدون بررسی d.success/response.ok همیشه
        // پیام موفق + reload بود — 403 CSRF/RBAC یا 500 با success:false هم به
        // مسیر موفق می‌رفت و اپراتور cleanup را موفق می‌دید (evidence خطا هم با
        // reload پاک می‌شد). اکنون فقط 2xx + success:true موفق و reload است.
        return r.json().then(d => ({ ok: r.ok, d }));
    }).then(({ ok, d }) => {
        if (ok && d.success) {
            notyf.success(`${d.count ?? 0} توکن باطل شد`);
            setTimeout(() => location.reload(), 1000);
        } else {
            notyf.error(d.message || 'ابطال گروهی انجام نشد');
        }
    }).catch(() => {
        notyf.error('خطا در ارتباط با سرور'); // FIX-R36-W3 (F-A20-09)
    }).finally(() => { revokeInFlight = false; });
}

})();
