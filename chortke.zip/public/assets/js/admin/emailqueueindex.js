/* admin/email-queue-index.js — استخراج‌شده از views/admin/email-queue/index.php (CSP-safe) */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('email-queue-index-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();

const csrfToken = __D[0];
// FIX-R36-W3 (F-A21-11): گارد in-flight مشترک + catch — خطای شبکه دیگر بدون بازخورد و
// به‌صورت unhandled rejection نمی‌ماند و دبل‌کلیک درخواست دوبل نمی‌زند
var queueActionInFlight = false;
function guardQueueAction() {
    if (queueActionInFlight) return false;
    queueActionInFlight = true;
    return true;
}
function releaseQueueAction() { queueActionInFlight = false; }

window.processQueue = function() {
    if (!guardQueueAction()) return;
    fetch(__D[1], {
        method: 'POST', headers: {'X-CSRF-Token': csrfToken}
    }).then(r => r.json()).then(d => {
        notyf.success(`ارسال شد: ${d.sent ?? 0} | ناموفق: ${d.failed ?? 0}`);
        setTimeout(() => location.reload(), 1500);
    }).catch(() => {
        notyf.error('خطا در ارتباط با سرور'); // FIX-R36-W3 (F-A21-11)
        releaseQueueAction();
    });
}
window.retryFailed = function() {
    if (!guardQueueAction()) return;
    fetch(__D[2], {
        method: 'POST', headers: {'X-CSRF-Token': csrfToken}
    }).then(r => r.json()).then(d => {
        notyf.success(`${d.count ?? 0} ایمیل برای تلاش مجدد آماده شد`);
        setTimeout(() => location.reload(), 1500);
    }).catch(() => {
        notyf.error('خطا در ارتباط با سرور'); // FIX-R36-W3 (F-A21-11)
        releaseQueueAction();
    });
}
window.retrySingle = function(id) {
    if (!guardQueueAction()) return;
    fetch(`${__D[3]}/${id}/retry`, {
        method: 'POST', headers: {'X-CSRF-Token': csrfToken}
    }).then(r => r.json()).then(d => {
        if (d.success) notyf.success('آماده تلاش مجدد');
        else notyf.error(d.message);
        setTimeout(() => location.reload(), 1000);
    }).catch(() => {
        notyf.error('خطا در ارتباط با سرور'); // FIX-R36-W3 (F-A21-11)
        releaseQueueAction();
    });
}

})();
