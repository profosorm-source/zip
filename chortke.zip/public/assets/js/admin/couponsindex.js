/* admin/coupons-index.js — مدیریت لیست کوپن‌ها (تغییر وضعیت + حذف)
 * 🛡️ FIX-COUPON-ADMIN-JS: بازنویسی کامل با fetch (بدون jQuery و بدون
 * DataTables — کتابخانه‌های خارجی در CSP ادمین مجاز نیستند؛ جدول HTML
 * سمت سرور رندر می‌شود و اینجا فقط اکشن‌های سطری وصل می‌شوند).
 * URLها از data-* روی جدول خوانده می‌شوند. */
(function () {
  'use strict';

  var table = document.getElementById('couponsTable');
  if (!table) return;

  var csrf = (window.csrfToken
    || (document.querySelector('meta[name="csrf-token"]') || {}).content
    || '');

  function notify(msg, ok) {
    if (window.notyf) { if (ok) notyf.success(msg); else notyf.error(msg); return; }
    alert(msg);
  }

  function postJson(url, body) {
    return fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrf,
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/json'
      },
      body: JSON.stringify(body || {})
    }).then(function (r) {
      return r.json().catch(function () { return { success: false, message: 'پاسخ سرور قابل خواندن نیست.' }; });
    });
  }

  // تغییر وضعیت فعال/غیرفعال
  table.addEventListener('change', function (e) {
    var checkbox = e.target.closest('.toggle-active');
    if (!checkbox) return;
    var id = checkbox.dataset.id;
    var wasChecked = checkbox.checked;
    checkbox.disabled = true;
    postJson(table.dataset.toggleUrl || '/admin/coupons/toggle-active', { id: id }).then(function (res) {
      checkbox.disabled = false;
      if (res.success) {
        notify(res.message || 'وضعیت تغییر کرد', true);
      } else {
        checkbox.checked = !wasChecked; // rollback
        notify(res.message || 'خطا در تغییر وضعیت', false);
      }
    }).catch(function () {
      checkbox.disabled = false;
      checkbox.checked = !wasChecked;
      notify('خطا در ارتباط با سرور', false);
    });
  });

  // حذف کوپن
  table.addEventListener('click', function (e) {
    var btn = e.target.closest('.delete-coupon');
    if (!btn) return;
    var id = btn.dataset.id;
    var row = btn.closest('tr');
    if (!window.confirm('آیا از حذف این کد تخفیف مطمئن هستید؟ این عمل قابل بازگشت نیست.')) return;
    btn.disabled = true;
    postJson(table.dataset.deleteUrl || '/admin/coupons/delete', { id: id }).then(function (res) {
      if (res.success) {
        notify(res.message || 'کد تخفیف حذف شد', true);
        if (row) row.remove();
        else window.location.reload();
      } else {
        btn.disabled = false;
        notify(res.message || 'خطا در حذف', false);
      }
    }).catch(function () {
      btn.disabled = false;
      notify('خطا در ارتباط با سرور', false);
    });
  });
})();
