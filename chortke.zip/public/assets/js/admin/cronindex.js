/* admin/cron-index.js — استخراج‌شده از views/admin/cron/index.php (CSP-safe) */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('cron-index-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();
window.copyCron = function() {
    const inp = document.getElementById('cronCmd');
    inp.select();
    navigator.clipboard.writeText(inp.value).then(() => notyf.success('کپی شد'));
}

// اجرای همه job ها (دکمه بالا) — R27-a: confirm Swal (الگوی deposits.js) قبل از اجرای دستی
window.runCron = function() {
    Swal.fire({
        title: 'اجرای دستی Cron Jobs؟',
        html: '<p>همهٔ jobهای زمان‌بندی‌شده به‌صورت دستی اجرا می‌شوند. ادامه می‌دهید؟</p>',
        icon: 'question', showCancelButton: true, confirmButtonColor: '#4caf50', cancelButtonColor: '#999',
        confirmButtonText: 'اجرا', cancelButtonText: 'انصراف'
    }).then(function (result) {
        if (!result.isConfirmed) return;
        const btn = document.getElementById('runBtn');
        btn.disabled = true;
        btn.innerHTML = '<span class="material-icons align-middle spin">sync</span> در حال اجرا...';

        fetch(__D[0], {
            method: 'POST',
            headers: {'X-CSRF-Token': __D[1]}
        })
        .then(r => r.json())
        .then(data => {
            // 🛡️ FIX-X164 (راند ۴۰): پاکت JSON واقعی {success, message, data:{results:{…}}}
            // است — کد قبلی data.results سطح‌بالا را می‌خواند که undefined بود و پنل
            // «خروجی اجرا» همیشه خالی می‌ماند.
            const results = (data.data && data.data.results) || data.results || {};
            showOutput(results);
            // FIX-M6-10: toast بر اساس وضعیت تجمیعی واقعی نتایج — نه صرفاً رسیدن
            // پاسخ. aggregate_status/error_count از کنترلر می‌آید؛ fallback محلی
            // هم شمارش status=error است (سازگار با پاکت قدیمی).
            let errCount = (data.data && data.data.error_count);
            if (typeof errCount !== 'number') {
                errCount = 0;
                for (const r of Object.values(results)) {
                    if (r && r.status === 'error') errCount++;
                }
            }
            if (errCount > 0 || data.success === false) {
                notyf.error(`اجرا با ${errCount} خطا انجام شد — جزئیات در خروجی`);
            } else {
                notyf.success('اجرا با موفقیت تمام شد');
            }
        })
        .catch(() => notyf.error('خطا در اجرا'))
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = '<span class="material-icons align-middle">play_arrow</span> اجرای همه';
        });
    });
}

// اجرای تکی یک job
window.runSingle = function(jobName, btn) {
    const orig = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="material-icons spin" style="font-size:16px;vertical-align:middle">sync</span>';

    fetch(__D[2], {
        method: 'POST',
        headers: {
            'X-CSRF-Token': __D[3],
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({job: jobName})
    })
    .then(r => r.json())
    .then(data => {
        // 🛡️ FIX-X164 (راند ۴۰): پاکت JSON واقعی {success, message, data:{results:{…}}}
        // است — کد قبلی data.result (کلید اشتباه و سطح اشتباه) می‌خواند و خروجی
        // تک‌جاب همیشه «undefined» نشان داده می‌شد.
        const results = (data.data && data.data.results) || data.results || {};
        const result = results[jobName] || {};
        const output = {};
        output[jobName] = result;
        showOutput(output);

        // FIX-M6-10: مبنا = وضعیت داخلیِ همان job (result.status) — نه صرفاً
        // data.success پاکت. قبلاً پاسخ HTTP موفق با results[job].status='error'
        // هم toast موفقیت + badge سبز «فعال» می‌گرفت؛ اکنون:
        //   error   → toast خطا + badge قرمز «خطا»
        //   skipped → toast هشدار + badge خاکستری «رد شد»
        //   ok/queued و بقیه → toast موفقیت + badge سبز «فعال»
        const status = (result && result.status) || '';
        const statusCell = document.querySelector(`.status-${jobName}`);
        if (status === 'error') {
            notyf.error(`${jobName}: خطا — ${result.message || 'نامشخص'}`);
            if (statusCell) {
                statusCell.innerHTML = '<span class="badge bg-danger">خطا</span>';
            }
        } else if (status === 'skipped') {
            notyf.warning(`${jobName}: رد شد — ${result.reason || ''}`);
            if (statusCell) {
                statusCell.innerHTML = '<span class="badge bg-secondary">رد شد</span>';
            }
        } else if (data.success) {
            notyf.success(`${jobName} اجرا شد`);
            if (statusCell) {
                statusCell.innerHTML = '<span class="badge bg-success">فعال</span>';
            }
        } else {
            notyf.error(`خطا: ${result.message || 'نامشخص'}`);
        }
    })
    .catch(() => notyf.error('خطا در اجرا'))
    .finally(() => {
        btn.disabled = false;
        btn.innerHTML = orig;
    });
}
window.showOutput = function(results) {
    document.getElementById('cronOutput').classList.remove('d-none');
    let out = '';
    for (const [name, result] of Object.entries(results)) {
        const icon = result.status === 'ok' ? '✓' : result.status === 'error' ? '✗' : '⟳';
        out += `[${icon}] ${name}: ${result.status}`;
        if (result.output) {
            const parts = Object.entries(result.output).map(([k,v]) => `${k}=${v}`);
            if (parts.length) out += ' — ' + parts.join(', ');
        }
        if (result.message) out += ' — ' + result.message;
        out += '\n';
    }
    document.getElementById('cronResult').textContent = out;
    document.getElementById('cronResult').scrollTop = 0;
}

})();
