/* public/assets/js/admin/seoadindex.js — CSP-safe SEO ad admin actions */
(function () {
  'use strict';

  const root = document.getElementById('adminSeoAdsRoot');
  const base = root?.dataset.base || '/admin/seo-ad';
  function csrf() { return document.querySelector('meta[name="csrf-token"]')?.content || window.csrfToken || ''; }
  function actionUrl(id, action) { return base.replace(/\/$/, '') + '/' + encodeURIComponent(id) + '/' + action; }
  let rejectId = null;

  async function post(url, body) {
    const options = { method: 'POST', headers: { 'X-CSRF-Token': csrf(), 'Accept': 'application/json' } };
    if (body instanceof FormData) options.body = body;
    try {
      const res = await fetch(url, options);
      const data = await res.json().catch(() => null);
      if (!data) return { success: false, message: 'پاسخ نامعتبر سرور (کد ' + res.status + ')' };
      if (!res.ok && data.success !== false) data.success = false;
      return data;
    } catch (e) {
      return { success: false, message: 'خطای شبکه؛ دوباره تلاش کنید' };
    }
  }

  // اجرای اکشن با قفل دکمه تا پایان درخواست (جلوگیری از کلیک/ارسال دوباره)
  async function runAction(btn, url, body) {
    if (btn) btn.disabled = true;
    const data = await post(url, body);
    if (data.success) { location.reload(); return; }
    if (btn) btn.disabled = false;
    alert(data.message || 'خطا');
  }

  document.querySelectorAll('.btn-approve').forEach(btn => {
    btn.addEventListener('click', function() {
      if(!confirm('تایید این آگهی؟')) return;
      runAction(this, actionUrl(this.dataset.id, 'approve'));
    });
  });

  document.querySelectorAll('.btn-reject').forEach(btn => {
    btn.addEventListener('click', function() {
      rejectId = this.dataset.id;
      const textarea = document.getElementById('rejectReason');
      if (textarea) textarea.value = '';
      if (window.bootstrap && document.getElementById('rejectModal')) {
        new bootstrap.Modal(document.getElementById('rejectModal')).show();
      } else {
        const reason = prompt('دلیل رد را بنویسید:');
        if (reason) submitReject(reason, null);
      }
    });
  });

  function submitReject(reason, btn) {
    const fd = new FormData();
    fd.append('reason', reason);
    return runAction(btn, actionUrl(rejectId, 'reject'), fd);
  }

  document.getElementById('btnConfirmReject')?.addEventListener('click', function() {
    const reason = document.getElementById('rejectReason').value.trim();
    if(!reason) { alert('دلیل رد الزامی است.'); return; }
    submitReject(reason, this);
  });

  document.querySelectorAll('.btn-pause-ad').forEach(btn => {
    btn.addEventListener('click', function() {
      if(!confirm('توقف این آگهی؟')) return;
      runAction(this, actionUrl(this.dataset.id, 'pause'));
    });
  });
})();
