/* admin/coupons-edit.js — ارسال AJAX فرم ویرایش کوپن
 * 🛡️ FIX-COUPON-ADMIN-JS: بازنویسی کامل با fetch (بدون jQuery).
 * آدرس آپدیت از data-action-url فرم خوانده می‌شود (کنترلر /admin/coupons/update
 * را انتظار دارد؛ id داخل body ارسال می‌شود). */
(function () {
  'use strict';

  var form = document.getElementById('editCouponForm');
  if (!form) return;

  var typeSelect = document.getElementById('discountType');
  var valueHint = document.getElementById('valueHint');
  var maxDiscountField = document.getElementById('maxDiscountField');

  function refreshTypeHints() {
    if (!typeSelect) return;
    var isPercent = typeSelect.value === 'percent';
    if (valueHint) valueHint.textContent = isPercent ? 'درصد تخفیف (0-100)' : 'مبلغ تخفیف به تومان';
    if (maxDiscountField) maxDiscountField.style.display = isPercent ? '' : 'none';
  }
  if (typeSelect) typeSelect.addEventListener('change', refreshTypeHints);
  refreshTypeHints();

  function notify(msg, ok) {
    if (window.notyf) { if (ok) notyf.success(msg); else notyf.error(msg); return; }
    alert(msg);
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var btn = form.querySelector('button[type="submit"]');
    var oldHtml = btn ? btn.innerHTML : '';
    if (btn) { btn.disabled = true; btn.innerHTML = 'در حال ذخیره...'; }

    var data = {};
    new FormData(form).forEach(function (v, k) { data[k] = v; });

    fetch(form.dataset.actionUrl || form.action, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': (window.csrfToken || (form.querySelector('[name="_csrf_token"]') || {}).value || ''),
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/json'
      },
      body: JSON.stringify(data)
    }).then(function (r) {
      return r.json().catch(function () { return { success: false, message: 'پاسخ سرور قابل خواندن نیست.' }; });
    }).then(function (res) {
      if (btn) { btn.disabled = false; btn.innerHTML = oldHtml; }
      if (res.success) {
        notify(res.message || 'کد تخفیف بروزرسانی شد', true);
        setTimeout(function () { window.location.href = res.redirect || '/admin/coupons'; }, 900);
      } else {
        if (res.errors) {
          var first = res.errors[Object.keys(res.errors)[0]];
          notify((Array.isArray(first) ? first[0] : first) || res.message || 'خطا در اعتبارسنجی', false);
        } else {
          notify(res.message || 'خطا در بروزرسانی', false);
        }
      }
    }).catch(function () {
      if (btn) { btn.disabled = false; btn.innerHTML = oldHtml; }
      notify('خطا در ارتباط با سرور', false);
    });
  });
})();
