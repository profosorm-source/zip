/* admin/referral-index.js — استخراج‌شده از views/admin/referral/index.php (CSP-safe) */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('referral-index-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();
// FIX-R36-W3 (F-A21-11): گارد in-flight مشترک لغو/پرداخت دسته‌ای — دبل‌کلیک درخواست دوبل نمی‌زند
var commissionActionInFlight = false;
window.cancelCommission = function(id) {
    if (commissionActionInFlight) return; // FIX-R36-W3 (F-A21-11)
    Swal.fire({
        title: 'لغو کمیسیون',
        input: 'text',
        inputLabel: 'دلیل لغو:',
        inputPlaceholder: 'مثال: تقلب زیرمجموعه',
        showCancelButton: true,
        confirmButtonColor: '#f44336',
        confirmButtonText: 'لغو کمیسیون',
        cancelButtonText: 'انصراف',
        inputValidator: function(value) {
            if (!value) return 'لطفاً دلیل لغو را وارد کنید';
        }
    }).then(function(result) {
        if (result.isConfirmed) {
            commissionActionInFlight = true;
            fetch(__D[0] + id + '/cancel', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': __D[1]
                },
                // FIX-R36-W3 (F-A20-14-pattern): کلید مردهٔ csrf_token به قرارداد کاننیکال _csrf_token (core/CSRF.php:125-128)
                body: JSON.stringify({_csrf_token: __D[2], reason: result.value})
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                var notyf = new Notyf({duration: 3000, position: {x:'left',y:'top'}});
                if (data.success) {
                    notyf.success(data.message);
                    location.reload();
                } else {
                    notyf.error(data.message);
                    commissionActionInFlight = false; // FIX-R36-W3 (F-A21-11)
                }
            })
            .catch(function() {
                new Notyf({duration: 3000, position: {x:'left',y:'top'}}).error('خطا در ارتباط با سرور'); // FIX-R36-W3 (F-A21-11)
                commissionActionInFlight = false;
            });
        }
    });
}
window.batchPay = function(currency) {
    if (commissionActionInFlight) return; // FIX-R36-W3 (F-A21-11)
    Swal.fire({
        title: 'پرداخت دسته‌ای',
        text: 'تمام کمیسیون‌های در انتظار پرداخت خواهند شد. آیا مطمئن هستید؟',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#4caf50',
        confirmButtonText: 'بله، پرداخت کن',
        cancelButtonText: 'انصراف'
    }).then(function(result) {
        if (result.isConfirmed) {
            commissionActionInFlight = true;
            fetch(__D[3], {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': __D[4]
                },
                // FIX-R36-W3 (F-A20-14-pattern): کلید مردهٔ csrf_token به قرارداد کاننیکال _csrf_token
                body: JSON.stringify({_csrf_token: __D[5], currency: currency})
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                var notyf = new Notyf({duration: 5000, position: {x:'left',y:'top'}});
                if (data.success) {
                    notyf.success(data.message);
                    setTimeout(function() { location.reload(); }, 2000);
                } else {
                    notyf.error(data.message);
                    commissionActionInFlight = false; // FIX-R36-W3 (F-A21-11): بدون reload — قفل آزاد شود
                }
            })
            .catch(function() {
                new Notyf({duration: 5000, position: {x:'left',y:'top'}}).error('خطا در ارتباط با سرور'); // FIX-R36-W3 (F-A21-11)
                commissionActionInFlight = false;
            });
        }
    });
}

})();
