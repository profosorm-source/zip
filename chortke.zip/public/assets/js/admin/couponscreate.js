/* admin/coupons-create.js — فرم ایجاد کوپن (نوع تخفیف + ارسال AJAX)
 * 🛡️ FIX-COUPON-ADMIN-JS: بازنویسی کامل با fetch (بدون jQuery — jQuery در
 * لی‌اوت ادمین لود نمی‌شود و نسخه‌ی قبلی $.ajax هرگز اجرا نمی‌شد).
 * الگو: settingsindex.js (اتصال از طریق data-action-url روی فرم). */
(function () {
  'use strict';

  var form = document.getElementById('createCouponForm');
  if (!form) return;

  var typeSelect = document.getElementById('discountType');
  var valueHint = document.getElementById('valueHint');
  var maxDiscountField = document.getElementById('maxDiscountField');

  function refreshTypeHints() {
    if (!typeSelect || !valueHint) return;
    if (typeSelect.value === 'percent') {
      valueHint.textContent = 'درصد تخفیف (0-100)';
      if (maxDiscountField) maxDiscountField.style.display = '';
    } else {
      valueHint.textContent = 'مبلغ تخفیف به تومان';
      if (maxDiscountField) maxDiscountField.style.display = 'none';
    }
  }
  if (typeSelect) typeSelect.addEventListener('change', refreshTypeHints);
  refreshTypeHints();

  function notify(msg, ok) {
    if (window.notyf) { if (ok) notyf.success(msg); else notyf.error(msg); return; }
    if (ok) alert(msg); else alert(msg);
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var btn = form.querySelector('button[type="submit"]');
    var oldHtml = btn ? btn.innerHTML : '';
    if (btn) { btn.disabled = true; btn.innerHTML = 'در حال ذخیره...'; }

    var data = {};
    new FormData(form).forEach(function (v, k) { data[k] = v; });

    fetch(form.dataset.actionUrl || form.action, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': (window.csrfToken || (form.querySelector('[name="_csrf_token"]') || {}).value || ''),
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/json'
      },
      body: JSON.stringify(data)
    }).then(function (r) {
      return r.json().catch(function () { return { success: false, message: 'پاسخ سرور قابل خواندن نیست.' }; });
    }).then(function (res) {
      if (btn) { btn.disabled = false; btn.innerHTML = oldHtml; }
      if (res.success) {
        notify(res.message || 'کد تخفیف ایجاد شد', true);
        setTimeout(function () { window.location.href = res.redirect || '/admin/coupons'; }, 900);
      } else {
        if (res.errors) {
          var first = res.errors[Object.keys(res.errors)[0]];
          notify((Array.isArray(first) ? first[0] : first) || res.message || 'خطا در اعتبارسنجی', false);
        } else {
          notify(res.message || 'خطا در ایجاد کد تخفیف', false);
        }
      }
    }).catch(function () {
      if (btn) { btn.disabled = false; btn.innerHTML = oldHtml; }
      notify('خطا در ارتباط با سرور', false);
    });
  });
})();
