/* public/assets/js/admin/sentryoutboxdlq.js — 🛡️ FIX-OUTBOX-DLQ-MANAGEMENT (ممیزی outbox ۲۰۲۶-۰۸-۲۸)
   صفحه Outbox DLQ قبلاً فقط-خواندنی بود: رویدادهای DLQ وضعیت پایانیِ بدون بازگشت
   بودند (publisher فقط pending/failed برمی‌دارد) و هیچ دکمه/مسیری برای بازیابی
   وجود نداشت. حالا:
   - دکمه‌های data-retry-outbox / data-delete-outbox در جدول ویو رندر می‌شوند؛
   - event delegation سراسری آن‌ها را وصل می‌کند؛
   - توکن CSRF از meta خوانده می‌شود؛
   - تأیید با SweetAlert2 (با fallback به confirm). */
(function () {
  'use strict';

  var csrf = (typeof window.csrfToken !== 'undefined' && window.csrfToken)
    || (document.querySelector('meta[name="csrf-token"]') || {}).content
    || '';

  function confirmAction(isRetry) {
    var opts = isRetry
      ? { title: 'بازگرداندن این رویداد به صف انتشار؟', text: 'وضعیت به pending و تلاش‌ها به صفر برمی‌گردد و publisher دوباره آن را منتشر می‌کند.', confirm: 'تلاش مجدد' }
      : { title: 'حذف این رکورد؟', text: 'این رویداد DLQ برای همیشه حذف می‌شود و قابل بازیابی نیست.', confirm: 'حذف' };
    if (typeof Swal !== 'undefined') {
      return Swal.fire({
        title: opts.title,
        text: opts.text,
        icon: isRetry ? 'question' : 'warning',
        showCancelButton: true,
        confirmButtonText: opts.confirm,
        cancelButtonText: 'انصراف',
        confirmButtonColor: isRetry ? '#10b981' : '#ef4444'
      }).then(function (r) { return r.isConfirmed; });
    }
    return Promise.resolve(confirm(opts.title));
  }

  function notifyError(msg) {
    if (typeof Swal !== 'undefined') {
      Swal.fire({ icon: 'error', title: 'خطا', text: msg || 'عملیات ناموفق بود.' });
    } else {
      alert(msg || 'عملیات ناموفق بود.');
    }
  }

  async function act(eventId, action) {
    var ok = await confirmAction(action === 'retry');
    if (!ok) return;
    try {
      var res = await fetch((window.BASE_URL || '') + '/admin/sentry/outbox-dlq/' + encodeURIComponent(eventId) + '/' + action, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-CSRF-Token': csrf
        },
        credentials: 'same-origin'
      });
      var data = {};
      try { data = await res.json(); } catch (_) {}
      if (res.ok && data.success) {
        if (typeof Swal !== 'undefined') {
          Swal.fire({
            icon: 'success',
            title: action === 'retry' ? 'به صف بازگشت' : 'حذف شد',
            text: action === 'retry' ? 'رویداد در سیکل بعدی publisher دوباره منتشر می‌شود.' : 'رکورد حذف شد.',
            timer: 1800,
            showConfirmButton: false
          }).then(function () { location.reload(); });
        } else {
          location.reload();
        }
      } else {
        notifyError(data.error || 'عملیات ناموفق بود.');
      }
    } catch (e) {
      notifyError('خطای شبکه: ' + (e && e.message ? e.message : e));
    }
  }

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest ? ev.target.closest('[data-retry-outbox],[data-delete-outbox]') : null;
    if (!t) return;
    ev.preventDefault();
    var eventId = t.getAttribute('data-retry-outbox') || t.getAttribute('data-delete-outbox');
    var action = t.hasAttribute('data-retry-outbox') ? 'retry' : 'delete';
    if (eventId) act(eventId, action);
  });
})();
