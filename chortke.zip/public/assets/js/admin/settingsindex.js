/* admin/settings-index.js — استخراج‌شده از views/admin/settings/index.php (CSP-safe) */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('settings-index-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();

/* 🛡️ X304: پاسخ‌های غیر JSON (مثلاً خطای PHP وقتی فایل از upload_max_filesize
   فایل‌پیکربندی سرور بزرگ‌تر است — پیش‌فرض ۲M در XAMPP) بدون این نرمال‌سازی
   ساکت بلعیده می‌شدند و کاربر هیچ بازخوردی نمی‌دید. */
async function readJson(response){
  var text = await response.text();
  try { return JSON.parse(text); } catch(e) {
    return { success:false, message: 'پاسخ نامعتبر از سرور (HTTP ' + response.status + ') — احتمالاً محدودیت آپلود PHP (upload_max_filesize) یا خطای داخلی. لطفاً لاگ سرور را بررسی کنید.' };
  }
}

window.updateSetting = async function(settingId) {
  const el = document.getElementById('setting_' + settingId);
  if (!el) return;
  try {
    const response = await fetch((window.BASE_URL || '') + `/admin/settings/${settingId}/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': __D[0] },
      credentials: 'same-origin',
      body: JSON.stringify({ id: settingId, key: el.dataset.key, value: el.value })
    });
    const result = await readJson(response);
    if (result.success) notyf.success(result.message || 'ذخیره شد');
    else notyf.error(result.message || 'خطا');
  } catch { notyf.error('خطا در ارتباط با سرور'); }
}

async function uploadImage(settingId, input) {
  const file = input.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) { notyf.error('لطفاً یک تصویر انتخاب کنید'); input.value=''; return; }
  if (file.size > 2 * 1024 * 1024) { notyf.error('حجم فایل نباید بیشتر از 2MB باشد'); input.value=''; return; }
  const formData = new FormData();
  formData.append('image', file);
  formData.append('setting_id', settingId);
  input.disabled = true;

  /* 🛡️ X304: بازخورد «در حال آپلود» — جعبهٔ پیش‌نمایش حالت اسپینر می‌گیرد
     تا کاربر بفهمد پردازش جریان دارد (قبلاً هیچ نشانه‌ای نبود). */
  const previewDiv = document.getElementById('preview_' + settingId);
  let prevHTML = null;
  if (previewDiv) {
    prevHTML = previewDiv.innerHTML;
    previewDiv.className = 'bx-img-upload__empty bx-img-upload__empty--loading';
    previewDiv.innerHTML = '<i class="material-icons">sync</i><span>در حال آپلود…</span>';
  }

  try {
    const response = await fetch(__D[1], { method:'POST', headers:{'X-CSRF-Token':__D[2]}, credentials:'same-origin', body:formData });
    const result = await readJson(response);
    input.disabled = false;
    if (result.success) {
      notyf.success(result.message || 'آپلود شد');
      /* 🛡️ X304: پاکت json سرور {success, message, data:{url}} است؛ result.url
         همیشه undefined بود (هرگز e2e آزمون نشده بود چون خودِ هندلر اصلاً اجرا
         نمی‌شد — باگ دیسپچر). fallback نگاه به result.url برای سازگاری. */
      const payload = result.data || {};
      const newUrl = payload.url || result.url || '';
      if (previewDiv && newUrl) {
        previewDiv.className = 'bx-img-upload__preview';
        previewDiv.innerHTML = `<img src="${newUrl}" alt="تصویر"><button type="button" class="bx-img-upload__remove" data-click="removeImage" data-args="${settingId}"><i class="material-icons">delete</i></button>`;
      }
      input.value = '';
    } else {
      notyf.error(result.message || 'خطا در آپلود');
      if (previewDiv) { previewDiv.className = 'bx-img-upload__empty'; previewDiv.innerHTML = '<i class="material-icons">cloud_upload</i><span>آپلود نشده</span>'; }
      input.value = '';
    }
  } catch {
    input.disabled = false;
    notyf.error('خطا در ارتباط با سرور');
    if (previewDiv) {
      if (prevHTML !== null) { previewDiv.innerHTML = prevHTML; previewDiv.className = 'bx-img-upload__preview'; }
      else { previewDiv.className = 'bx-img-upload__empty'; previewDiv.innerHTML = '<i class="material-icons">cloud_upload</i><span>آپلود نشده</span>'; }
    }
    input.value = '';
  }
}

window.removeImage = async function(settingId) {
  if (!confirm('آیا از حذف این تصویر اطمینان دارید؟')) return;
  const previewDiv = document.getElementById('preview_' + settingId);
  if (previewDiv) {
    previewDiv.className = 'bx-img-upload__empty bx-img-upload__empty--loading';
    previewDiv.innerHTML = '<i class="material-icons">sync</i><span>در حال حذف…</span>';
  }
  try {
    const response = await fetch(__D[3], { method:'POST', headers:{'Content-Type':'application/json','X-CSRF-Token':__D[4]}, credentials:'same-origin', body:JSON.stringify({setting_id:settingId}) });
    const result = await readJson(response);
    if (result.success) {
      notyf.success(result.message || 'حذف شد');
      if (previewDiv) {
        previewDiv.className = 'bx-img-upload__empty';
        previewDiv.innerHTML = '<i class="material-icons">cloud_upload</i><span>آپلود نشده</span>';
      }
    } else {
      notyf.error(result.message || 'خطا در حذف');
      location.reload(); /* 🛡️ X304: در شکست، پیش‌نمایش با مقدار واقعی DB همگام شود */
    }
  } catch {
    notyf.error('خطا در ارتباط با سرور');
    if (previewDiv) location.reload();
  }
}

// FIX-X111: قرارداد X106 — ثبت استاندارد هندلرها
window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    uploadImage: uploadImage
});

})();
