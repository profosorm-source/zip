/* public/assets/js/admin/logsnotificationsettings.js — منطق صفحهٔ «تنظیمات اعلان‌های لاگ» ادمین
 * FIX-X89: پیش از این صفحه از سه جهت شکسته بود:
 *   ① endpointهای toggle-rule (اصلاً unrouted) و test-channel بدون CSRF فراخوانی می‌شدند → 404/419
 *   ② توابع داخل IIFE خصوصی بودند و در window.ChortkeActions ثبت نمی‌شدند →
 *      event-delegation «No handler registered» و هیچ دکمه‌ای کار نمی‌کرد
 *   ③ ویو از data-click (پشتیبانی‌نشده) و data-args (قالب نادرست) استفاده می‌کرد — در ویو اصلاح شد
 */
(function () {
  'use strict';

  function postForm(url, params) {
    const body = new URLSearchParams(params);
    body.set('_csrf_token', window.csrfToken || '');
    return fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-CSRF-Token': window.csrfToken || '',
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: body.toString()
    }).then(function (r) { return r.json(); });
  }

  function updateChannelForm() {
    // event-delegation: this = المنت select (بدون args)
    const select = (this && this.value !== undefined) ? this : document.getElementById('channelType');
    const type = select.value;
    document.getElementById('telegramFields').style.display = type === 'telegram' ? 'block' : 'none';
    document.getElementById('emailFields').style.display = type === 'email' ? 'block' : 'none';
    document.getElementById('webhookFields').style.display = type === 'webhook' ? 'block' : 'none';
  }

  function testChannel(channelId) {
    // event-delegation: this = دکمه، آرگومان اول از data-action-args (JSON)
    if (!window.confirm('آیا می‌خواهید یک پیام تست ارسال شود؟')) return;
    postForm('/admin/logs/test-channel', { channel_id: channelId })
      .then(function (data) {
        notify(data.message || (data.success ? 'پیام تست ارسال شد' : 'خطا در ارسال'), data.success ? 'success' : 'error');
      })
      .catch(function (err) {
        notify('خطا در ارسال: ' + err.message, 'error');
      });
  }

  function toggleRule() {
    // event-delegation: this = خودِ چک‌باکس (data-rule-id روی المنت است)
    const el = this;
    const ruleId = el.getAttribute('data-rule-id');
    const isActive = !!el.checked;
    postForm('/admin/logs/toggle-rule', { rule_id: ruleId, is_active: isActive ? 1 : 0 })
      .then(function (data) {
        if (!data || !data.success) {
          el.checked = !isActive; // بازگرداندن سوییچ در صورت خطا
          notify((data && data.message) || 'خطا در تغییر وضعیت', 'error');
          return;
        }
        notify(data.message || 'قاعدهٔ هشدار به‌روزرسانی شد', 'success');
        // به‌روزرسانی badge وضعیت کنار نام قاعده
        const item = el.closest('.list-group-item');
        const badge = item && item.querySelector('.badge');
        if (badge) {
          badge.textContent = isActive ? 'فعال' : 'غیرفعال';
          badge.classList.toggle('bg-success', isActive);
          badge.classList.toggle('bg-secondary', !isActive);
        }
      })
      .catch(function () {
        el.checked = !isActive;
        notify('خطای شبکه در تغییر وضعیت', 'error');
      });
  }

  function notify(msg, type) {
    const n = window.notyf || window.chortkeNotyf;
    if (n) { (type === 'error') ? n.error(msg) : n.success(msg); }
    else { window.alert(msg); }
  }

  // ثبت فقط در ChortkeActions — تا event-delegation اجرا کند؛ ثبت هم‌زمان روی
  // window باعث دو-اجرایی می‌شد (inlineactions.js هم window[name] را صدا می‌زند).
  window.ChortkeActions = Object.assign(window.ChortkeActions || {}, {
    testChannel: testChannel,
    toggleRule: toggleRule,
    updateChannelForm: updateChannelForm
  });
})();
