/* admin/features-index.js — استخراج‌شده از views/admin/features/index.php (CSP-safe)
 * 🛡️ FIX-ADMIN-PAGE-JS-WIRING: چهار فراخوانی jQuery-مودال به bootstrap.Modal
 * بومی تبدیل شد (jQuery در لی‌اوت ادمین لود نمی‌شود). */
(function(){
'use strict';
var __D=(function(){var el=document.getElementById('features-index-data');try{return JSON.parse(el.textContent);}catch(e){return [];}})();

// 🛡️ FIX-ADMIN-PAGE-JS-WIRING: helperهای بومی مودال Bootstrap (جایگزین jQuery)
function showBsModal(id) {
    var el = document.getElementById(id);
    if (el && window.bootstrap) new bootstrap.Modal(el).show();
}
function hideBsModal(id) {
    var el = document.getElementById(id);
    if (el && window.bootstrap) { var inst = bootstrap.Modal.getInstance(el); if (inst) inst.hide(); }
}

// 🛡️ FIX-F01: helperهای امن ساخت DOM — متنِ داده‌محور (تگ‌ها، محیط‌ها، تاریخچه،
// diff و ...) هرگز به innerHTML تزریق نمی‌شود؛ innerHTML فقط برای رشته‌های
// کاملاً ثابت استفاده می‌شود. (تزریق HTML ذخیره‌شده در پنل فیچرها)
function el(tagName, className, text) {
    const node = document.createElement(tagName);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
}
function setChildren(container, node) {
    if (!container) return;
    while (container.firstChild) container.removeChild(container.firstChild);
    if (node) container.appendChild(node);
}

class TagInput {
    constructor(containerId, inputId) {
        this.container = document.getElementById(containerId);
        this.input = document.getElementById(inputId);
        this.tags = [];
        
        this.input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && this.input.value.trim()) {
                e.preventDefault();
                this.addTag(this.input.value.trim());
                this.input.value = '';
            }
        });
    }
    
    addTag(value) {
        if (!this.tags.includes(value)) {
            this.tags.push(value);
            this.render();
            updatePreview();
        }
    }
    
    removeTag(value) {
        this.tags = this.tags.filter(t => t !== value);
        this.render();
        updatePreview();
    }
    
    setTags(tags) {
        this.tags = tags || [];
        this.render();
    }
    
    getTags() {
        return this.tags;
    }
    
    render() {
        const existingTags = this.container.querySelectorAll('.tag');
        existingTags.forEach(tag => tag.remove());
        
        // 🛡️ FIX-F01: مقدار تگ با innerHTML رندر نمی‌شود — گره‌ها با DOM API ساخته
        // می‌شوند؛ data-args هم با setAttribute نوشته می‌شود (بدون پارس HTML).
        this.tags.forEach(tag => {
            const tagEl = document.createElement('div');
            tagEl.className = 'tag';
            tagEl.appendChild(document.createTextNode(tag));
            const removeEl = document.createElement('span');
            removeEl.className = 'remove';
            removeEl.setAttribute('data-click', 'removeTagFromInput');
            removeEl.setAttribute('data-args', this.container.id + '|' + tag);
            removeEl.textContent = '\u00d7';
            tagEl.appendChild(removeEl);
            this.container.insertBefore(tagEl, this.input);
        });
    }
}

// Initialize all tag inputs
const rolesTagInput = new TagInput('rolesTagInput', 'roleInput');
const usersTagInput = new TagInput('usersTagInput', 'userInput');
const countriesTagInput = new TagInput('countriesTagInput', 'countryInput');
const devicesTagInput = new TagInput('devicesTagInput', 'deviceInput');
const routesTagInput = new TagInput('routesTagInput', 'routeInput');
const environmentsTagInput = new TagInput('environmentsTagInput', 'environmentInput');

window.removeTagFromInput = function(containerId, value) {
    const inputs = {
        'rolesTagInput': rolesTagInput,
        'usersTagInput': usersTagInput,
        'countriesTagInput': countriesTagInput,
        'devicesTagInput': devicesTagInput,
        'routesTagInput': routesTagInput,
        'environmentsTagInput': environmentsTagInput
    };
    
    if (inputs[containerId]) {
        inputs[containerId].removeTag(value);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Link percentage slider and input
    const slider = document.getElementById('editPercentage');
    const numberInput = document.getElementById('editPercentageValue');
    
    slider?.addEventListener('input', () => {
        numberInput.value = slider.value;
        updatePreview();
    });
    
    numberInput?.addEventListener('input', () => {
        slider.value = numberInput.value;
        updatePreview();
    });
    
    // Initialize filters
    const searchInput = document.getElementById('searchFeature');
    const statusFilter = document.getElementById('filterStatus');
    // FIX-R15B (Low-28): ویو #filterTargeting و #filterEnvironment دارد ولی JS #filterType را
    // می‌خواند (همیشه null) → filterFeatures روی first call می‌شکست. کلیدها با ویو هم‌تراز شدند.
    const targetingFilter = document.getElementById('filterTargeting');
    const environmentFilter = document.getElementById('filterEnvironment');
    
    window.filterFeatures = function() {
        const searchTerm = (searchInput?.value || '').toLowerCase();
        const status = statusFilter?.value || '';
        const targeting = targetingFilter?.value || '';
        const environment = environmentFilter?.value || '';
        
        document.querySelectorAll('.feature-card').forEach(card => {
            const name = card.dataset.name.toLowerCase();
            const cardStatus = card.dataset.status;
            const cardTargeting = card.dataset.targeting || '';
            const cardEnvironment = card.dataset.environment || '';
            
            let show = true;
            
            if (searchTerm && !name.includes(searchTerm)) {
                show = false;
            }
            
            if (status && cardStatus !== status) {
                show = false;
            }
            
            if (targeting && !cardTargeting.includes(targeting)) {
                show = false;
            }
            
            if (environment && !cardEnvironment.includes(environment)) {
                show = false;
            }
            
            card.style.display = show ? 'block' : 'none';
        });
    }
    
    // FIX-R15B (Low-28): دکمهٔ data-click="clearFilters" در ویو تابع سراسری‌اش وجود نداشت.
    window.clearFilters = function() {
        if (searchInput) searchInput.value = '';
        if (statusFilter) statusFilter.value = '';
        if (targetingFilter) targetingFilter.value = '';
        if (environmentFilter) environmentFilter.value = '';
        window.filterFeatures();
    };
    
    searchInput?.addEventListener('input', filterFeatures);
    statusFilter?.addEventListener('change', filterFeatures);
    targetingFilter?.addEventListener('change', filterFeatures);
    environmentFilter?.addEventListener('change', filterFeatures);
});

window.updatePreview = function() {
    const percentage = document.getElementById('editPercentageValue')?.value || 100;
    const roles = rolesTagInput.getTags();
    const users = usersTagInput.getTags();
    const countries = countriesTagInput.getTags();
    const devices = devicesTagInput.getTags();
    const routes = routesTagInput.getTags();
    const minAge = document.getElementById('editMinAge')?.value;
    const maxAge = document.getElementById('editMaxAge')?.value;
    const enabledFrom = document.getElementById('editEnabledFrom')?.value;
    const enabledUntil = document.getElementById('editEnabledUntil')?.value;
    const environments = environmentsTagInput.getTags();
    
    // 🛡️ FIX-F01: پیش‌نمایش با DOM API ساخته می‌شود — درصد/سن/محیط‌ها ورودیِ
    // کاربرند و نباید به‌عنوان HTML تفسیر شوند.
    const preview = document.createElement('div');
    preview.className = 'd-flex flex-wrap gap-1';
    let hasItem = false;
    const addBadge = (cls, text) => {
        preview.appendChild(el('span', cls, text));
        hasItem = true;
    };
    
    if (percentage < 100) {
        addBadge('badge badge-info', 'A/B: ' + percentage + '%');
    }
    
    if (roles.length > 0) {
        addBadge('badge badge-primary', roles.length + ' نقش');
    }
    
    if (users.length > 0) {
        addBadge('badge badge-warning', users.length + ' کاربر');
    }
    
    if (countries.length > 0) {
        addBadge('badge badge-success', countries.length + ' کشور');
    }
    
    if (devices.length > 0) {
        addBadge('badge badge-secondary', devices.length + ' دستگاه');
    }
    
    if (routes.length > 0) {
        addBadge('badge badge-dark', routes.length + ' مسیر');
    }
    
    if (minAge || maxAge) {
        addBadge('badge badge-info', 'سن: ' + (minAge || 0) + '-' + (maxAge || '∞'));
    }
    
    if (enabledFrom || enabledUntil) {
        addBadge('badge badge-warning', 'زمان‌بندی');
    }
    
    if (environments.length > 0) {
        addBadge('badge badge-light text-dark', environments.join(', '));
    }
    
    if (!hasItem) {
        preview.appendChild(el('small', 'text-muted', 'هیچ محدودیتی اعمال نشده (عمومی)'));
    }
    
    setChildren(document.getElementById('settingsPreview'), preview);
}

window.showEditModal = function(feature) {
    document.getElementById('modalFeatureName').textContent = feature.name;
    document.getElementById('editFeatureName').value = feature.name;
    document.getElementById('editDescription').value = feature.description || '';
    
    const percentage = feature.enabled_percentage || 100;
    document.getElementById('editPercentage').value = percentage;
    document.getElementById('editPercentageValue').value = percentage;
    
    // Set advanced fields
    document.getElementById('editMinAge').value = feature.min_age || '';
    document.getElementById('editMaxAge').value = feature.max_age || '';
    document.getElementById('editEnabledFrom').value = feature.enabled_from ? 
        new Date(feature.enabled_from).toISOString().slice(0, 16) : '';
    document.getElementById('editEnabledUntil').value = feature.enabled_until ? 
        new Date(feature.enabled_until).toISOString().slice(0, 16) : '';
    document.getElementById('editPriority').value = feature.priority || 0;
    
    // Set tags
    const roles = feature.enabled_for_roles ? JSON.parse(feature.enabled_for_roles) : [];
    rolesTagInput.setTags(roles);
    
    const users = feature.enabled_for_users ? JSON.parse(feature.enabled_for_users) : [];
    usersTagInput.setTags(users.map(String));
    
    const countries = feature.enabled_for_countries ? JSON.parse(feature.enabled_for_countries) : [];
    countriesTagInput.setTags(countries);
    
    const devices = feature.enabled_for_devices ? JSON.parse(feature.enabled_for_devices) : [];
    devicesTagInput.setTags(devices);
    
    const routes = feature.enabled_for_routes ? JSON.parse(feature.enabled_for_routes) : [];
    routesTagInput.setTags(routes);
    
    const environments = feature.environments ? JSON.parse(feature.environments) : [];
    environmentsTagInput.setTags(environments);
    
    updatePreview();
    showBsModal('editFeatureModal');
}

window.saveFeature = function() {
    const name = document.getElementById('editFeatureName').value;
    const description = document.getElementById('editDescription').value;
    const percentage = parseInt(document.getElementById('editPercentageValue').value);
    const minAge = document.getElementById('editMinAge').value ? parseInt(document.getElementById('editMinAge').value) : null;
    const maxAge = document.getElementById('editMaxAge').value ? parseInt(document.getElementById('editMaxAge').value) : null;
    const enabledFrom = document.getElementById('editEnabledFrom').value;
    const enabledUntil = document.getElementById('editEnabledUntil').value;
    const priority = parseInt(document.getElementById('editPriority').value) || 0;
    
    const data = {
        name: name,
        description: description,
        enabled_percentage: percentage,
        enabled_for_roles: rolesTagInput.getTags(),
        enabled_for_users: usersTagInput.getTags().map(id => parseInt(id)),
        enabled_for_countries: countriesTagInput.getTags(),
        enabled_for_devices: devicesTagInput.getTags(),
        enabled_for_routes: routesTagInput.getTags(),
        min_age: minAge,
        max_age: maxAge,
        enabled_from: enabledFrom,
        enabled_until: enabledUntil,
        priority: priority,
        environments: environmentsTagInput.getTags()
    };
    
    fetch(__D[0], {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': __D[1]
        },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            notyf.success('تنظیمات پیشرفته با موفقیت ذخیره شد');
            hideBsModal('editFeatureModal');
            setTimeout(() => location.reload(), 1000);
        } else {
            notyf.error(data.message || 'خطا در ذخیره تنظیمات');
        }
    })
    .catch(err => {
        notyf.error('خطا در ارتباط با سرور');
        console.error(err);
    });
}

window.showMetrics = function(featureName) {
    document.getElementById('metricsFeatureName').textContent = featureName;
    
    fetch(`${__D[2]}/${encodeURIComponent(featureName)}`)
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            setChildren(document.getElementById('metricsContent'), generateMetricsHTML(data.metrics));
        } else {
            setChildren(document.getElementById('metricsContent'),
                el('div', 'alert alert-danger', 'خطا در دریافت آمار'));
        }
    })
    .catch(err => {
        setChildren(document.getElementById('metricsContent'),
            el('div', 'alert alert-danger', 'خطا در ارتباط با سرور'));
        console.error(err);
    });
    
    showBsModal('metricsModal');
}

window.showHistory = function(featureName) {
    document.getElementById('historyFeatureName').textContent = featureName;
    
    fetch(`${__D[3]}/${encodeURIComponent(featureName)}`)
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            setChildren(document.getElementById('historyContent'), generateHistoryHTML(data.history));
        } else {
            setChildren(document.getElementById('historyContent'),
                el('div', 'alert alert-danger', 'خطا در دریافت تاریخچه'));
        }
    })
    .catch(err => {
        setChildren(document.getElementById('historyContent'),
            el('div', 'alert alert-danger', 'خطا در ارتباط با سرور'));
        console.error(err);
    });
    
    showBsModal('historyModal');
}

// 🛡️ FIX-F01: ساختار DOM با createElement ساخته می‌شود — اعداد/رشته‌های
// سرور-محور با textContent وارد درخت می‌شوند و هرگز HTML تفسیر نمی‌شوند.
window.generateMetricsHTML = function(metrics) {
    metrics = metrics || {};
    const frag = document.createDocumentFragment();
    
    const metricRow = document.createElement('div');
    metricRow.className = 'row';
    [
        ['border-primary', 'text-primary', metrics.total_checks || 0, 'کل بررسی‌ها'],
        ['border-success', 'text-success', metrics.enabled_count || 0, 'فعال'],
        ['border-danger', 'text-danger', metrics.disabled_count || 0, 'غیرفعال'],
        ['border-info', 'text-info', (metrics.success_rate || 0) + '%', 'نرخ موفقیت'],
    ].forEach(([borderCls, valueCls, value, label]) => {
        const col = el('div', 'col-md-3');
        const card = el('div', 'card text-center ' + borderCls);
        const body = el('div', 'card-body');
        body.appendChild(el('h3', valueCls, value));
        body.appendChild(el('p', 'text-muted mb-0', label));
        card.appendChild(body);
        col.appendChild(card);
        metricRow.appendChild(col);
    });
    frag.appendChild(metricRow);
    
    if (metrics.avg_response_time > 0) {
        const timingRow = el('div', 'row mt-3');
        [
            ['border-warning', 'text-warning', metrics.avg_response_time, 'میانگین زمان پاسخ'],
            ['border-secondary', 'text-secondary', metrics.max_response_time, 'حداکثر زمان پاسخ'],
        ].forEach(([borderCls, valueCls, value, label]) => {
            const col = el('div', 'col-md-6');
            const card = el('div', 'card text-center ' + borderCls);
            const body = el('div', 'card-body');
            body.appendChild(el('h5', valueCls, Math.round(value) + 'ms'));
            body.appendChild(el('p', 'text-muted mb-0', label));
            card.appendChild(body);
            col.appendChild(card);
            timingRow.appendChild(col);
        });
        frag.appendChild(timingRow);
    }
    
    if (metrics.reasons && metrics.reasons.length > 0) {
        const reasons = el('div', 'mt-4');
        const heading = el('h6');
        heading.appendChild(el('i', 'material-icons', 'pie_chart'));
        heading.appendChild(document.createTextNode(' دلایل بررسی'));
        reasons.appendChild(heading);
        
        const table = el('table', 'table table-sm');
        const thead = document.createElement('thead');
        const headRow = document.createElement('tr');
        ['دلیل', 'تعداد', 'درصد'].forEach(label => headRow.appendChild(el('th', null, label)));
        thead.appendChild(headRow);
        table.appendChild(thead);
        
        const tbody = document.createElement('tbody');
        metrics.reasons.forEach(reason => {
            const tr = document.createElement('tr');
            tr.appendChild(el('td', null, (reason && reason.reason) || 'نامشخص'));
            tr.appendChild(el('td', null, (reason && reason.count) || 0));
            tr.appendChild(el('td', null, ((reason && reason.percentage) || 0) + '%'));
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);
        
        const responsive = el('div', 'table-responsive');
        responsive.appendChild(table);
        reasons.appendChild(responsive);
        frag.appendChild(reasons);
    }
    
    return frag;
}

// 🛡️ FIX-F01: details/changed_by/change_type دادهٔ تاریخچه‌اند (نه HTML) —
// همگی با DOM API رندر می‌شوند.
window.generateHistoryHTML = function(history) {
    const frag = document.createDocumentFragment();
    
    if (!history || history.length === 0) {
        const empty = el('div', 'alert alert-info');
        empty.appendChild(el('i', 'material-icons', 'info'));
        empty.appendChild(document.createTextNode(' هیچ تاریخچه‌ای یافت نشد'));
        frag.appendChild(empty);
        return frag;
    }
    
    const timeline = el('div', 'timeline');
    history.forEach(item => {
        item = item || {};
        const date = new Date(item.changed_at || item.created_at);
        const formattedDate = date.toLocaleDateString('fa-IR') + ' ' + date.toLocaleTimeString('fa-IR');
        const actionIcon = getActionIcon(item.change_type || item.action || 'updated');
        
        const timelineItem = el('div', 'timeline-item');
        timelineItem.appendChild(el('div', 'timeline-marker bg-primary'));
        
        const content = el('div', 'timeline-content');
        const headRow = el('div', 'd-flex justify-content-between align-items-start');
        const heading = el('h6', 'mb-1');
        const icon = el('i', 'material-icons', actionIcon);
        icon.style.fontSize = '16px';
        heading.appendChild(icon);
        heading.appendChild(document.createTextNode(' ' + (item.change_type || item.action || 'به‌روزرسانی')));
        headRow.appendChild(heading);
        headRow.appendChild(el('small', 'text-muted', formattedDate));
        content.appendChild(headRow);
        
        content.appendChild(el('p', 'mb-1', item.details || item.description || 'بدون جزئیات'));
        
        if (item.changed_by) {
            content.appendChild(el('small', 'text-info', 'توسط: ' + item.changed_by));
        }
        
        if (item.old_values || item.new_values) {
            const diffWrap = el('div', 'mt-2');
            diffWrap.appendChild(el('small', 'text-muted', 'تغییرات:'));
            const diffView = el('div', 'diff-view mt-1');
            diffView.appendChild(generateDiffHTML(item.old_values, item.new_values));
            diffWrap.appendChild(diffView);
            content.appendChild(diffWrap);
        }
        
        timelineItem.appendChild(content);
        timeline.appendChild(timelineItem);
    });
    frag.appendChild(timeline);
    return frag;
}

// 🛡️ FIX-F01: کلید/مقدارهای diff با textContent رندر می‌شوند — خروجی
// JSON.stringify به‌عنوان متن نمایش داده می‌شود، نه HTML.
window.generateDiffHTML = function(oldValues, newValues) {
    const frag = document.createDocumentFragment();
    if (!oldValues && !newValues) return frag;
    
    if (typeof oldValues === 'string') {
        try {
            oldValues = JSON.parse(oldValues);
        } catch (e) {
            oldValues = null;
        }
    }
    
    if (typeof newValues === 'string') {
        try {
            newValues = JSON.parse(newValues);
        } catch (e) {
            newValues = null;
        }
    }
    
    let hasDiff = false;
    if (oldValues && typeof oldValues === 'object') {
        Object.keys(oldValues).forEach(key => {
            const oldVal = oldValues[key];
            const newVal = newValues && newValues[key] !== undefined ? newValues[key] : null;
            
            if (oldVal !== newVal) {
                hasDiff = true;
                const line = el('div', 'diff-line');
                line.appendChild(el('code', null, key));
                line.appendChild(document.createTextNode(': '));
                line.appendChild(el('span', 'text-danger', JSON.stringify(oldVal)));
                line.appendChild(document.createTextNode(' \u2192 '));
                line.appendChild(el('span', 'text-success', JSON.stringify(newVal)));
                frag.appendChild(line);
            }
        });
    }
    
    if (!hasDiff) {
        frag.appendChild(el('small', 'text-muted', 'تغییرات جزئی'));
    }
    return frag;
}

window.getActionIcon = function(action) {
    const icons = {
        'created': 'add_circle',
        'updated': 'edit',
        'enabled': 'toggle_on',
        'disabled': 'toggle_off',
        'deleted': 'delete'
    };
    return icons[action.toLowerCase()] || 'info';
}

window.toggleFeature = function(name) {
    Swal.fire({
        title: 'تغییر وضعیت فیچر',
        text: `آیا مطمئن هستید که می‌خواهید وضعیت "${name}" را تغییر دهید؟`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'بله، تغییر بده',
        cancelButtonText: 'لغو',
        customClass: {
            confirmButton: 'btn btn-primary',
            cancelButton: 'btn btn-secondary'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(__D[4], {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': __D[5]
                },
                body: JSON.stringify({ name: name })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    notyf.success(data.message);
                    setTimeout(() => location.reload(), 1000);
                } else {
                    notyf.error(data.message);
                }
            })
            // FIX-R36-W3 (F-A20-09): خطای شبکه بی‌صدا نباشد
            .catch(() => notyf.error('خطا در ارتباط با سرور'));
        }
    });
}

window.editFeature = function(name) {
    // Find the feature data from the current features
    const features = __D[6];
    const feature = features.find(f => f.name === name);
    
    if (feature) {
        showEditModal(feature);
    } else {
        notyf.error('فیچر مورد نظر یافت نشد');
    }
}

})();
