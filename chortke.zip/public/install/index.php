<?php
/**
 * Chortke Super Strong Graphical Installer v4.7 (Security Hardened)
 * - Enforces CSRF & Production Web Lock
 * - FIX-M3-11: PHP-level network guard (HTTPS for non-loopback + IP allowlist,
 *   independent of Apache .htaccess/Nginx)
 * - Enforces strong password policy for Super Admin (12+ chars, mixed case, numbers, symbols)
 * - Creates actual Super Admin user in database with Argon2id password hash
 * - FIX-M3-05: admin password is NEVER persisted to .env (transient request-only)
 * - FIX-M3-06: role membership resolved by slug (not hardcoded IDs) + verified
 * - FIX-M3-07: installed.lock write is atomic & fail-closed
 * - FIX-M3-09: canonical QUEUE_DRIVER key is written (wizard choice no longer dead)
 * - FIX-M3-16: .env write is line-based + round-trip verified with the app parser
 * - Validates migration exit status; fails closed if migrations fail
 */

session_start();
define('INSTALLER_VERSION', '4.7.0-hardened');

// Generate CSRF token if not set
if (empty($_SESSION['_csrf_token'])) {
    $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
}

/**
 * Production safety guard
 */
function installer_env_value(string $key, ?string $default = null): ?string
{
    $runtime = getenv($key);
    if ($runtime !== false && $runtime !== '') {
        return (string)$runtime;
    }

    $envPath = __DIR__ . '/../../.env';
    if (!is_file($envPath) || !is_readable($envPath)) {
        return $default;
    }

    foreach ((array)file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim((string)$line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }
        [$envKey, $envValue] = array_map('trim', explode('=', $line, 2));
        if ($envKey === $key) {
            return trim($envValue, "\"'");
        }
    }

    return $default;
}

$installerAppEnv = strtolower((string)installer_env_value('APP_ENV', 'local'));
$allowWebInstaller = filter_var(installer_env_value('ALLOW_WEB_INSTALLER', 'false'), FILTER_VALIDATE_BOOLEAN);

// FIX-M3-13b (found live during M3-BR-02): the lock guard above used to block
// ?step=7 as well — after a SUCCESSFUL install the redirect to the success page
// hit this 403, so the final checklist (worker instructions, queue driver note)
// was never shown to the operator. Now the success page is shown exactly once,
// only to the session that just finished the install (GET only — POST is always
// rejected so the wizard can never re-run against an installed system).
$installerJustDone = false;
if (file_exists(__DIR__ . '/../../storage/installed.lock')) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' && !empty($_SESSION['done'])) {
        $installerJustDone = true;
    } else {
        http_response_code(403);
        die('<h1 style="color:#dc2626;text-align:center;margin-top:80px">نصب قبلاً انجام شده است</h1><p style="text-align:center">پوشه install را حذف یا تغییر نام دهید.</p>');
    }
}

// ───── نگهبان جلوگیری از نصب مجدد روی دادهٔ موجود (X315) ─────
// حادثهٔ ۱۷:۴۴: نصب‌کنندهٔ وب روی دیتابیس پر اجرا شد؛ مرحلهٔ ۶ مایگریشن‌ها را از نو اجرا
// و .env را بازنویسی می‌کند و داده‌ها نابود شدند. قفل installed.lock کافی نیست چون
// ممکن است وجود نداشته باشد. این گارد قبل از هر مرحله (و قبل از هر POST) چک می‌کند:
// اگر دیتابیس در دسترس باشد + جدول users موجود باشد + حداقل یک رکورد داشته باشد
// + APP_KEY در .env تنظیم شده باشد ⇒ نصب قبلاً انجام شده و اجرا متوقف می‌شود.
// دور زدن آگاهانه (مستند): فایل زیر را دستی بسازید و صفحه را دوباره باز کنید:
//   mkdir -p storage/framework && touch storage/framework/allow-reinstall.flag
if (!$installerJustDone && !file_exists(__DIR__ . '/../../storage/framework/allow-reinstall.flag')) {
    $guardAppKey = (string)installer_env_value('APP_KEY', '');
    if ($guardAppKey !== '') {
        $guardUsersCount = 0;
        $guardDbOk = false;
        try {
            $guardSocket = installer_env_value('DB_SOCKET', '');
            // هم‌راستا با config/config.php: نام رسمی DB_USER/DB_PASS است و نام دیتابیس
            // DB_NAME؛ DB_USERNAME/DB_PASSWORD/DB_DATABASE به‌عنوان جایگزین‌های سازگار پذیرفته می‌شوند
            $guardDbName = installer_env_value('DB_NAME', installer_env_value('DB_DATABASE', 'chortk'));
            $guardDsn = $guardSocket !== ''
                ? 'mysql:unix_socket=' . $guardSocket . ';dbname=' . $guardDbName . ';charset=utf8mb4'
                : 'mysql:host=' . installer_env_value('DB_HOST', '127.0.0.1') . ';port=' . installer_env_value('DB_PORT', '3306') . ';dbname=' . $guardDbName . ';charset=utf8mb4';
            $guardPdo = new PDO(
                $guardDsn,
                (string)installer_env_value('DB_USER', installer_env_value('DB_USERNAME', 'root')),
                (string)installer_env_value('DB_PASS', installer_env_value('DB_PASSWORD', '')),
                [PDO::ATTR_TIMEOUT => 3]
            );
            // اگر جدول users وجود نداشته باشد همین‌جا استثنا می‌دهد ⇒ نصب تازه محسوب می‌شود
            $guardUsersCount = (int)$guardPdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
            $guardDbOk = true;
        } catch (Throwable $guardError) {
            $guardDbOk = false; // دیتابیس در دسترس نیست ⇒ گارد دیتابیسی معنا ندارد، رفتار قبل حفظ شود
        }
        if ($guardDbOk && $guardUsersCount > 0) {
            http_response_code(403);
            die('<h1 style="color:#dc2626;text-align:center;margin-top:80px">نصب قبلاً انجام شده است</h1>'
                . '<p style="text-align:center">دیتابیس فعلی حاوی ' . (int)$guardUsersCount . ' کاربر است و APP_KEY در فایل .env تنظیم شده؛ برای جلوگیری از نابودی داده‌ها، نصب‌کننده متوقف شد.</p>'
                . '<p style="text-align:center">اگر کاملاً مطمئن هستید که می‌خواهید از نو نصب کنید، این دستور را دستی اجرا کنید و صفحه را دوباره باز کنید:<br>'
                . '<code style="direction:ltr;display:inline-block;background:#f1f5f9;padding:4px 8px;border-radius:6px">mkdir -p storage/framework &amp;&amp; touch storage/framework/allow-reinstall.flag</code></p>');
        }
    }
}

if ($installerAppEnv === 'production' && !$allowWebInstaller) {
    http_response_code(403);
    die('<h1 style="color:#dc2626;text-align:center;margin-top:80px">نصب‌کننده وب در محیط production غیرفعال است</h1><p style="text-align:center">برای استفاده موقت، ALLOW_WEB_INSTALLER=true را فقط در پنجره نگهداری فعال کنید یا از دستور CLI استفاده نمایید.</p>');
}

// ───── FIX-M3-11: network guard at PHP level (independent of Apache/Nginx) ─────
// IP restriction used to live only in public/install/.htaccess (Apache-only);
// Nginx ignores it, and plain-HTTP installs on reachable networks were unsafe.
// Policy (mirrors .htaccess default, stricter on scheme):
//   * loopback REMOTE_ADDR (127.0.0.1/::1) => allowed on HTTP/HTTPS (XAMPP UX kept)
//   * anything else => HTTPS required AND remote IP inside allowlist
//     - HTTPS = $_SERVER['HTTPS'], or X-Forwarded-Proto:https when REMOTE_ADDR is
//       a private/local peer (reverse proxy on the same private network).
//       Note: an already-allowed private client could spoof XFP — same trust
//       level the Apache .htaccess default already grants to the LAN.
//     - default allowlist = mirror of public/install/.htaccess (RFC1918 + loopback);
//       override via INSTALLER_ALLOWED_IPS="ip1,ip2,10.0.0.0/8,..."
function installer_ip_in_cidr(string $ip, string $cidr): bool
{
    if (!str_contains($cidr, '/')) {
        return strcasecmp($ip, $cidr) === 0;
    }
    [$subnet, $bits] = explode('/', $cidr, 2);
    $bits = (int)$bits;
    $ipBin = @inet_pton($ip);
    $subBin = @inet_pton($subnet);
    if ($ipBin === false || $subBin === false || strlen($ipBin) !== strlen($subBin)) {
        return false;
    }
    $maxBits = strlen($ipBin) * 8;
    if ($bits < 0 || $bits > $maxBits) {
        return false;
    }
    if ($bits === 0) {
        return true;
    }
    $fullBytes = intdiv($bits, 8);
    $remBits = $bits % 8;
    if ($fullBytes > 0 && substr($ipBin, 0, $fullBytes) !== substr($subBin, 0, $fullBytes)) {
        return false;
    }
    if ($remBits > 0) {
        $mask = (0xFF << (8 - $remBits)) & 0xFF;
        if ((ord($ipBin[$fullBytes]) & $mask) !== (ord($subBin[$fullBytes]) & $mask)) {
            return false;
        }
    }
    return true;
}

function installer_ip_allowed(string $ip, string $allowlist): bool
{
    if ($ip === '') {
        return false;
    }
    if ($allowlist !== '') {
        $entries = preg_split('/[\s,]+/', trim($allowlist)) ?: [];
        foreach ($entries as $entry) {
            $entry = trim($entry);
            if ($entry !== '' && installer_ip_in_cidr($ip, $entry)) {
                return true;
            }
        }
        return false;
    }
    // default allowlist = mirror of public/install/.htaccess
    foreach (['127.0.0.0/8', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16'] as $cidr) {
        if (installer_ip_in_cidr($ip, $cidr)) {
            return true;
        }
    }
    if ($ip === '::1') {
        return true;
    }
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        // IPv6 ULA (fc00::/7) and link-local (fe80::/10) count as "local network"
        return installer_ip_in_cidr($ip, 'fc00::/7') || installer_ip_in_cidr($ip, 'fe80::/10');
    }
    return false;
}

function installer_remote_over_https(array $server): bool
{
    $https = strtolower((string)($server['HTTPS'] ?? ''));
    if ($https !== '' && $https !== 'off') {
        return true;
    }
    $remote = (string)($server['REMOTE_ADDR'] ?? '');
    $isLocalPeer = installer_ip_allowed($remote, '');
    return strtolower((string)($server['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https' && $isLocalPeer;
}

$m3RemoteIp = (string)($_SERVER['REMOTE_ADDR'] ?? '');
$m3IsLoopback = in_array($m3RemoteIp, ['127.0.0.1', '::1'], true);
if (!$m3IsLoopback) {
    $m3Https = installer_remote_over_https($_SERVER);
    $m3Allowed = installer_ip_allowed($m3RemoteIp, (string)installer_env_value('INSTALLER_ALLOWED_IPS', ''));
    if (!$m3Https || !$m3Allowed) {
        http_response_code(403);
        error_log('[Chortke-Installer] blocked remote install attempt from ' . $m3RemoteIp . ' https=' . ($m3Https ? '1' : '0'));
        die('<h1 style="color:#dc2626;text-align:center;margin-top:80px">دسترسی به نصب کننده از این شبکه مجاز نیست</h1><p style="text-align:center">نصب کننده وب فقط از localhost (HTTP) یا از شبکهٔ مجاز روی HTTPS در دسترس است. برای استقرار production از نصب CLI/SSH استفاده کنید.</p>');
    }
}

$step = $installerJustDone ? 7 : max(1, min(7, (int)($_GET['step'] ?? 1)));
$errors = [];

/**
 * HTML escape برای نصب‌کننده.
 *
 * این اسکریپت مستقل است و تا مرحله ۵ (که bootstrap/app.php را require می‌کند)
 * هیچ‌یک از helperهای فریم‌ورک بارگذاری نشده‌اند. اما قالب مراحل ۲ تا ۶ برای
 * چاپ توکن CSRF از e() استفاده می‌کرد؛ نتیجه «Call to undefined function e()»
 * و کرش کامل ویزارد نصب در همان مراحل بود.
 *
 * تعریف مشروط است تا اگر helperهای فریم‌ورک قبلاً بارگذاری شده باشند،
 * با تعریف اصلی تداخل پیدا نکند و همان پیاده‌سازی محصول به کار برود.
 */
if (!function_exists('e')) {
    function e(mixed $value): string {
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

function check_req($name, $ok, $req = true) { return ['name'=>$name,'ok'=>$ok,'required'=>$req]; }
function gen_key($l=64){return bin2hex(random_bytes($l/2));}
function test_db($h,$p,$n,$u,$pw){try{$pdo=new PDO("mysql:host=$h;port=$p;dbname=$n;charset=utf8mb4",$u,$pw,[PDO::ATTR_TIMEOUT=>4]);return['ok'=>true,'pdo'=>$pdo];}catch(Throwable $e){return['ok'=>false,'msg'=>$e->getMessage()];}}
function test_redis($h,$p,$pw=''){if(!extension_loaded('redis'))return['ok'=>false];try{$r=new Redis();$r->connect($h,(int)$p,2);if($pw)$r->auth($pw);$r->ping();return['ok'=>true];}catch(Throwable $e){return['ok'=>false];}}
function write_env($d){$p=__DIR__.'/../../.env';$ex=file_exists(__DIR__.'/../../.env.example')?file_get_contents(__DIR__.'/../../.env.example'):'';foreach($d as $k=>$v){
// 🔧 FIX-M5BR01 (سناریوی مرورگری M5-BR-01 — نصب fresh از مرورگر):
// (1) مقادیری که «;» یا «#» یا فاصله/گیومه دارند باید quoted نوشته شوند —
//     در غیر این صورت parse_ini_file(INI_SCANNER_RAW) (پارسر رسمی اپ) دنبالهٔ
//     «; …» را کامنت می‌خواند و مقدار (مثلاً رمز قوی ادمین با «#») بی‌صدا
//     truncated می‌شد.
// (2) «"» داخل مقدار حذف می‌شود چون INI_SCANNER_RAW escapeهای درون-مقداری را
//     پردازش نمی‌کند و نقل‌قول تو در تو قرارداد INI را می‌شکند.
// (3) جایگزینی مقدار اکنون خط‌محور است (installer_env_upsert_line) — مشکل backref
//     در preg_replace با «$» و «\» کلاً حذف شده (FIX-M3-16).
$v=str_replace(["\n","\r"],'',(string)$v); $v=str_replace('"','',$v);
if ($v !== '' && preg_match('/[;\# \'$]/', $v)) { $v = '"'.$v.'"'; }
// FIX-M3-16: line-based upsert — old preg_replace("/^$k=.*/m", "$k=$vEsc", ...)
// corrupted values containing $ or \ (backref semantics) and interpolated $k raw
// into the pattern; exact-string line handling is safe for every byte.
$ex = installer_env_upsert_line($ex, $k, $v);}
// FIX-M3-05: admin credentials must never persist to .env (strip any legacy lines)
$ex = implode("\n", array_values(array_filter(explode("\n", $ex), static fn($l) => !preg_match('/^ADMIN_(PASSWORD|EMAIL)=/', $l))));
return file_put_contents($p, $ex . "\n") !== false;}

function installer_env_upsert_line(string $content, string $key, string $value): string
{
    $lines = explode("\n", $content);
    $needle = $key . '=';
    $found = false;
    foreach ($lines as $i => $line) {
        if (str_starts_with(ltrim($line), $needle)) {
            $lines[$i] = $key . '=' . $value;
            $found = true;
            break;
        }
    }
    if (!$found) {
        $lines[] = $key . '=' . $value;
    }
    return implode("\n", $lines);
}

/**
 * FIX-M3-16: round-trip verification — the generated .env must parse with the
 * SAME parser the application uses (parse_ini_file + INI_SCANNER_RAW) and yield
 * exactly the values the installer intended. Returns the list of problem keys.
 */
function installer_verify_env_roundtrip(string $path, array $expected): array
{
    $parsed = parse_ini_file($path, false, INI_SCANNER_RAW);
    if ($parsed === false) {
        return ['parse_ini_file failed'];
    }
    $bad = [];
    foreach ($expected as $k => $v) {
        $got = $parsed[$k] ?? null;
        if ($got === null || (string)$got !== (string)$v) {
            $bad[] = $k;
        }
    }
    return $bad;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    // CSRF Guard for installer
    $csrfSubmitted = $_POST['_csrf_token'] ?? '';
    if (!hash_equals($_SESSION['_csrf_token'] ?? '', (string)$csrfSubmitted)) {
        $errors[] = "خطای امنیتی CSRF: توکن نامعتبر است.";
    } else {
        if($step==2){
            $db=['DB_HOST'=>trim($_POST['db_host']??'127.0.0.1'),'DB_PORT'=>trim($_POST['db_port']??'3306'),'DB_NAME'=>trim($_POST['db_name']??'chortke'),'DB_USER'=>trim($_POST['db_user']??'chortke_user'),'DB_PASS'=>trim($_POST['db_pass']??'')];
            $testRes = test_db($db['DB_HOST'],$db['DB_PORT'],$db['DB_NAME'],$db['DB_USER'],$db['DB_PASS']);
            if(!$testRes['ok']){$errors[]="اتصال دیتابیس ناموفق: " . ($testRes['msg'] ?? '');}else{$_SESSION['db']=$db;header("Location:?step=3");exit;}
        }
        if($step==3){
            $rd=['REDIS_HOST'=>trim($_POST['redis_host']??'127.0.0.1'),'REDIS_PORT'=>trim($_POST['redis_port']??'6379'),'REDIS_PASSWORD'=>trim($_POST['redis_pass']??'')];
            $qd=$_POST['queue_driver']??'redis';
            // FIX-M3-09: whitelist — only redis|database may reach .env, and it is
            // written to the CANONICAL key QUEUE_DRIVER (see step 6).
            if(!in_array($qd, ['redis','database'], true)){$errors[]="انتخاب درایور صف نامعتبر است؛ فقط redis یا database مجاز است.";}
            elseif($qd==='redis' && !test_redis($rd['REDIS_HOST'],$rd['REDIS_PORT'],$rd['REDIS_PASSWORD'])['ok']){$errors[]="اتصال Redis ناموفق";}else{$_SESSION['redis']=$rd;$_SESSION['queue']=$qd;header("Location:?step=4");exit;}
        }
        if($step==4){
            // 🔧 FIX-M5BR01c (سناریوی مرورگری M5-BR-01): محیط نصب باید با «واقعیت
            // APP_URL» هم‌خوان باشد. اپ در production روی URLهای loopback
            // fail-closed می‌کند (UrlGenerator: «Production canonical URLs must
            // not use loopback hosts») — نصب‌کننده پیش‌تر همیشه APP_ENV=production
            // می‌نوشت، حتی برای نصب روی 127.0.0.1/localhost ⇒ اپ پس از نصب بوت
            // نمی‌شد. اکنون: URL loopback/localhost ⇒ محیط local (نصب sandbox)،
            // هر دامنهٔ عمومی ⇒ production. قرارداد واحد با گارد خودِ اپ.
            $appUrlValue = rtrim(trim($_POST['app_url']??'http://127.0.0.1:8080'),'/');
            // FIX-M3-16: APP_URL must be a real http(s) URL BEFORE it is persisted —
            // bootstrap (FILTER_VALIDATE_URL) and config/oauth.php (production loopback
            // ban) reject invalid values and leave the install unbootable.
            $m3UrlScheme = strtolower((string)parse_url($appUrlValue, PHP_URL_SCHEME));
            $envHost = strtolower((string)parse_url($appUrlValue, PHP_URL_HOST));
            $isLoopbackInstall = in_array($envHost, ['localhost','127.0.0.1','::1'], true);
            if (!filter_var($appUrlValue, FILTER_VALIDATE_URL) || !in_array($m3UrlScheme, ['http','https'], true) || $envHost === '' || preg_match('/\s/u', $appUrlValue) === 1) {
                $errors[] = "APP_URL نامعتبر است؛ نمونهٔ صحیح: https://example.com یا http://127.0.0.1:8080";
            } else {
            $_SESSION['app']=['APP_NAME'=>trim($_POST['app_name']??'چرتکه'),'APP_ENV'=>$isLoopbackInstall?'local':'production','APP_DEBUG'=>$isLoopbackInstall?'true':'false','APP_URL'=>$appUrlValue,'APP_KEY'=>gen_key(64),'SECURITY_API_TOKEN_SECRET'=>gen_key(64),'ZARINPAL_MERCHANT_ID'=>trim($_POST['zarinpal']??''),'KAVENEGAR_API_KEY'=>trim($_POST['kavenegar']??'')];
            header("Location:?step=5");exit;
            }
        }
        if($step==5){
            $em=trim($_POST['admin_email']??'admin@chortke.ir');
            $pw=trim($_POST['admin_pass']??'');
            
            // FIX-M3-16: validate admin email before it is persisted;
            // Strong Password Policy: 12+ chars, uppercase, lowercase, numbers, symbols
            if (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "ایمیل مدیر ارشد نامعتبر است.";
            } elseif(strlen($pw)<12){
                $errors[]="رمز عبور مدیر ارشد باید حداقل ۱۲ کاراکتر باشد.";
            } elseif(!preg_match('/[A-Z]/', $pw) || !preg_match('/[a-z]/', $pw) || !preg_match('/[0-9]/', $pw) || !preg_match('/[^a-zA-Z0-9]/', $pw)) {
                $errors[]="رمز عبور مدیر ارشد باید شامل حروف کوچک، حروف بزرگ، اعداد و کاراکترهای ویژه (مانند !@#$) باشد.";
            } else {
                $_SESSION['admin']=['email'=>$em,'pass'=>$pw];
                header("Location:?step=6");
                exit;
            }
        }
        if($step==6){
            $wm=$_POST['worker_method']??'supervisor';
            // FIX-M3-13 companion: keep worker_method inside the known set so the
            // step-7 instructions always match a real deployment path.
            if(!in_array($wm, ['supervisor','systemd','docker'], true)){$wm='supervisor';}
            $adminCreds = $_SESSION['admin'] ?? [];
            // FIX-R2-05: step از query انتخاب می‌شود و $_SESSION['admin'] اختیاری بود؛
            // پرش مستقیم به ?step=6 (یا انقضای سشن بین مراحل) ادمین را با hash رمز
            // «خالی» می‌ساخت. سیاست رمز فقط در step=5 اعمال می‌شد. اکنون بدون
            // اعتبارنامهٔ کاملِ مرحلهٔ ۵، حساب مدیر ساخته/به‌روز نمی‌شود و به همان
            // مرحله بازمی‌گردیم.
            if (empty($adminCreds['email']) || empty($adminCreds['pass'])) {
                $errors[] = "ابتدا حساب مدیر ارشد را در مرحله ۵ با رمز معتبر تعریف کنید.";
                unset($_SESSION['admin']);
                header("Location:?step=5");
                exit;
            }
            $env=array_merge($_SESSION['db']??[],$_SESSION['redis']??[],$_SESSION['app']??[]);
            // FIX-M3-09: QUEUE_DRIVER is the canonical key (config/queue.php reads
            // QUEUE_DRIVER first; the old QUEUE_CONNECTION write was dead weight and
            // let .env.example's QUEUE_DRIVER=database silently win over the wizard).
            $env['QUEUE_DRIVER']=in_array($_SESSION['queue']??'redis', ['redis','database'], true) ? ($_SESSION['queue']??'redis') : 'redis';

            // FIX-M3-05: admin credentials are TRANSIENT — provided to the seed
            // migration via process env for THIS request only (seed_initial_data reads
            // getenv/$_ENV first), never persisted to the stable .env file.
            if (!empty($adminCreds['email'])) {
                putenv('ADMIN_EMAIL=' . $adminCreds['email']);
                $_ENV['ADMIN_EMAIL'] = $adminCreds['email'];
                putenv('ADMIN_PASSWORD=' . $adminCreds['pass']);
                $_ENV['ADMIN_PASSWORD'] = $adminCreds['pass'];
            }

            // 🔧 FIX-M5BR01b (سناریوی مرورگری M5-BR-01 — نصب fresh از مرورگر):
            // EnvValidator اپ در production روی «DB_USER=root»، «DB_PASS خالی» و
            // «نبودن WEBHOOK_SECRET» fail-closed می‌شود. نصب‌کننده پیش‌تر هیچ‌کدام
            // از این سه را تدارک نمی‌داد ⇒ .env نوشته می‌شد ولی اپ بوت نمی‌شد و
            // step 6 بی‌صدا می‌مرد (کاربر فقط یک صفحهٔ سفید می‌دید).
            // اکنون: (۱) WEBHOOK_SECRET ۶۴ کاراکتری تولید می‌شود؛ (۲) اگر نصب با
            // root انجام می‌شود، یک کاربر اپ اختصاصیِ least-privilege (دسترسی فقط
            // روی DB همین نصب) ساخته و به‌جای root در .env نوشته می‌شود؛ (۳) اتصال
            // با همان کاربر جدید به‌صورت زنده تست می‌شود تا اختلاف auth-plugin
            // (mariadb/ed25519) پیش از مایگریشن آشکار شود.
            $env['WEBHOOK_SECRET'] = gen_key(64);
            if (strtolower((string)($env['DB_USER'] ?? '')) === 'root') {
                $appDbUser = 'chortke_app_' . substr(bin2hex(random_bytes(3)), 0, 5);
                $appDbPass = bin2hex(random_bytes(16));
                $provDbName = (string)($env['DB_NAME'] ?? 'chortke');
                try {
                    $provPdo = new PDO(
                        "mysql:host=" . ($env['DB_HOST'] ?? '127.0.0.1') . ";port=" . ($env['DB_PORT'] ?? '3306') . ";charset=utf8mb4",
                        (string)($env['DB_USER'] ?? 'root'),
                        (string)($env['DB_PASS'] ?? ''),
                        [PDO::ATTR_TIMEOUT => 4, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                    );
                    $sqlStr = static function (string $v): string {
                        return "'" . str_replace(["\\", "'"], ["\\\\", "''"], $v) . "'";
                    };
                    $bt = static function (string $v): string {
                        return '`' . str_replace('`', '``', $v) . '`';
                    };
                    foreach (['localhost', '127.0.0.1'] as $provHost) {
                        $provPdo->exec("CREATE USER IF NOT EXISTS " . $sqlStr($appDbUser) . "@" . $sqlStr($provHost) . " IDENTIFIED BY " . $sqlStr($appDbPass));
                        $provPdo->exec("GRANT ALL PRIVILEGES ON " . $bt($provDbName) . ".* TO " . $sqlStr($appDbUser) . "@" . $sqlStr($provHost));
                    }
                    $provPdo->exec("FLUSH PRIVILEGES");
                    // زنده‌آزمایی اتصال TCP با کاربر جدید؛ در صورت اختلاف auth plugin،
                    // صراحتاً mysql_native_password اعمال و دوباره تست می‌شود.
                    $probe = static function () use ($provDbName, $appDbUser, $appDbPass, $env): bool {
                        try {
                            $t = new PDO(
                                "mysql:host=" . ($env['DB_HOST'] ?? '127.0.0.1') . ";port=" . ($env['DB_PORT'] ?? '3306') . ";dbname=" . $provDbName . ";charset=utf8mb4",
                                $appDbUser,
                                $appDbPass,
                                [PDO::ATTR_TIMEOUT => 4, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                            );
                            $t->query('SELECT 1');
                            return true;
                        } catch (Throwable $e) {
                            return false;
                        }
                    };
                    if (!$probe()) {
                        foreach (['localhost', '127.0.0.1'] as $provHost) {
                            $provPdo->exec("ALTER USER " . $sqlStr($appDbUser) . "@" . $sqlStr($provHost) . " IDENTIFIED VIA mysql_native_password USING PASSWORD(" . $sqlStr($appDbPass) . ")");
                        }
                        $provPdo->exec("FLUSH PRIVILEGES");
                        if (!$probe()) {
                            throw new RuntimeException('اتصال با کاربر اختصاصی ساخته‌شده برقرار نشد.');
                        }
                    }
                    $env['DB_USER'] = $appDbUser;
                    $env['DB_PASS'] = $appDbPass;
                } catch (Throwable $provEx) {
                    $errors[] = "ساخت کاربر اختصاصی دیتابیس ممکن نشد: " . $provEx->getMessage()
                        . " — در production، DB_USER=root از نظر امنیتی مجاز نیست؛ یک کاربر اختصاصی بسازید و در مرحلهٔ ۲ وارد کنید.";
                }
            }

            if(!write_env($env)){
                $errors[]="نوشتن فایل .env ناموفق بود.";
            } else {
                // FIX-M3-16: fail-closed round-trip — the .env must parse with the
                // app's own parser and match the intended values, otherwise abort
                // BEFORE migrations run against a half-written environment.
                $rtBad = installer_verify_env_roundtrip(__DIR__.'/../../.env', $env);
                if ($rtBad) {
                    $errors[] = "نوشتن .env با پارسر رسمی اپ تأیید نشد (round-trip): " . implode(', ', $rtBad);
                }
                if (!$rtBad) {
                foreach($env as $k=>$v) {
                    putenv("$k=$v");
                    $_ENV[$k] = $v;
                }
                
                // Execute Migration Runner via MigrationService
                require_once __DIR__ . '/../../bootstrap/app.php';
                $container = \Core\Container::getInstance();
                $migrationService = new \App\Services\MigrationService(
                    $container->make(\Core\Redis::class),
                    $container->make(\Core\Database::class),
                    $container->make(\App\Contracts\LoggerInterface::class)
                );

                $migResult = $migrationService->runMigrations();

                if (empty($migResult['success'])) {
                    $errors[] = "اجرای مایگریشن‌ها با خطا مواجه شد: " . implode(', ', $migResult['errors'] ?? ['خطای ناشناخته']);
                } else {
                    // Create/Update Super Admin user directly with the entered credentials
                    try {
                        $pdo = $container->make(\Core\Database::class)->getPdo();
                        $adminEmail = $adminCreds['email'] ?? 'admin@chortke.ir';
                        $adminPass = $adminCreds['pass'] ?? '';
                        $hash = password_hash($adminPass, PASSWORD_ARGON2ID);

                        // FIX-M3-06: role membership must be resolved by SLUG from the
                        // roles table (the seed migration assigns dynamic IDs). The old
                        // hardcoded IDs (3, 2) assumed a specific row order and could
                        // miss the super_admin grant entirely on fresh installs.
                        $roleMap = [];
                        foreach ($pdo->query("SELECT id, slug FROM roles WHERE slug IN ('super_admin','admin')")->fetchAll(PDO::FETCH_OBJ) as $roleRow) {
                            $roleMap[$roleRow->slug] = (int)$roleRow->id;
                        }
                        if (empty($roleMap['super_admin'])) {
                            throw new RuntimeException('نقش super_admin در جدول roles یافت نشد — مایگریشن seed نقش‌ها را بررسی کنید.');
                        }
                        $superAdminRoleId = $roleMap['super_admin'];

                        $pdo->exec("
                            INSERT INTO users (email, username, full_name, password, role, role_id, is_admin, status, kyc_status, email_verified_at, created_at, updated_at)
                            VALUES (" . $pdo->quote($adminEmail) . ", 'admin', 'مدیر ارشد سیستم', " . $pdo->quote($hash) . ", 'super_admin', " . $superAdminRoleId . ", 1, 'active', 'verified', NOW(), NOW(), NOW())
                            ON DUPLICATE KEY UPDATE password = " . $pdo->quote($hash) . ", role = 'super_admin', role_id = " . $superAdminRoleId . ", status = 'active', email_verified_at = NOW(), updated_at = NOW()
                        ");

                        $userRow = $pdo->query("SELECT id FROM users WHERE email = " . $pdo->quote($adminEmail))->fetch(PDO::FETCH_OBJ);
                        if ($userRow && !empty($userRow->id)) {
                            $adminUserId = (int)$userRow->id;
                            $insRole = $pdo->prepare("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)");
                            $insRole->execute([$adminUserId, $superAdminRoleId]);
                            if (!empty($roleMap['admin'])) {
                                $insRole->execute([$adminUserId, $roleMap['admin']]);
                            }
                            // FIX-M3-06 (verify): final membership must contain super_admin
                            $chk = $pdo->prepare("SELECT COUNT(*) FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ? AND r.slug = 'super_admin'");
                            $chk->execute([$adminUserId]);
                            if ((int)$chk->fetchColumn() === 0) {
                                throw new RuntimeException('عضویت نقش super_admin پس از درج تأیید نشد.');
                            }
                        }

                        // FIX-M3-07: installed.lock write is fail-closed and atomic —
                        // the old @file_put_contents ignored permission/disk failures
                        // and still showed the success page (installer stayed reachable).
                        $lockPath = __DIR__.'/../../storage/installed.lock';
                        $tmpLock = __DIR__.'/../../storage/installed.lock.' . bin2hex(random_bytes(4)) . '.tmp';
                        $lockBytes = @file_put_contents($tmpLock, date('c'));
                        $lockOk = ($lockBytes !== false);
                        if ($lockOk) {
                            @chmod($tmpLock, 0600);
                            $lockOk = @rename($tmpLock, $lockPath);
                        }
                        if (!$lockOk) {
                            @unlink($tmpLock);
                            throw new RuntimeException('نوشتن installed.lock ناموفق بود — مجوز نوشتن storage را بررسی کنید. نصب ناتمام ماند و صفحهٔ موفقیت نمایش داده نمی‌شود.');
                        }

                        $_SESSION['done'] = true;
                        $_SESSION['wm'] = $wm;
                        $_SESSION['queue_used'] = $env['QUEUE_DRIVER'];

                        // FIX-M3-05: purge transient admin credentials from process env
                        // and session now that the hash lives (only) in the database.
                        putenv('ADMIN_PASSWORD');
                        putenv('ADMIN_EMAIL');
                        unset($_ENV['ADMIN_PASSWORD'], $_ENV['ADMIN_EMAIL'], $_SESSION['admin']);

                        header("Location:?step=7");
                        exit;
                    } catch (Throwable $e) {
                        $errors[] = "خطا در ایجاد حساب مدیر ارشد: " . $e->getMessage();
                    }
                }
                }
            }
        }
    }
}

$reqs=[check_req('PHP≥8.2',version_compare(PHP_VERSION,'8.2.0','>=')),check_req('pdo_mysql',extension_loaded('pdo_mysql')),// FIX-M3-10: redis is NOT mandatory anymore — only required when the wizard
// actually picks the redis queue (enforced live at step 3 via test_redis);
// the database-queue path (e.g. XAMPP without the redis extension) must install.
check_req('redis',extension_loaded('redis'),false),check_req('bcmath',extension_loaded('bcmath')),check_req('storage writable',is_writable(__DIR__.'/../../storage'))];
$reqOk=!in_array(false,array_column(array_filter($reqs,fn($r)=>$r['required']),'ok'));
?>
<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><title>نصب چرتکه v<?=INSTALLER_VERSION?></title>
<style>body{font-family:Tahoma;background:#f1f5f9;margin:0;padding:20px} .container{max-width:820px;margin:30px auto;background:#fff;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.1);overflow:hidden} .header{background:linear-gradient(135deg,#1e40af,#3b82f6);color:#fff;padding:28px} .steps{display:flex;background:#f8fafc;padding:10px 16px;gap:6px} .step{padding:5px 14px;border-radius:999px;font-size:12px;background:#e2e8f0} .step.active{background:#1e40af;color:#fff} .step.done{background:#10b981;color:#fff} .content{padding:32px} label{display:block;margin:8px 0 4px;font-weight:600} input,select{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px} .btn{background:#1e40af;color:#fff;border:none;padding:12px 26px;border-radius:8px;font-size:15px;cursor:pointer} table{width:100%;margin:16px 0} td{padding:8px;border-bottom:1px solid #eee} .ok{color:#16a34a;font-weight:700} .fail{color:#dc2626;font-weight:700} .alert{padding:12px;border-radius:8px;margin:12px 0} .alert.error{background:#fee2e2;color:#991b1b}</style>
</head><body><div class="container"><div class="header"><h1>نصب امن چرتکه v<?=INSTALLER_VERSION?></h1><p>نصب‌کننده ایمن گرافیکی • ایجاد حساب مدیر ارشد واقعی با هش Argon2id</p></div>
<div class="steps"><?php for($i=1;$i<=7;$i++)echo '<span class="step '.($i<$step?'done':($i==$step?'active':'')).'">'.$i.'</span>'; ?></div>
<div class="content">
<?php if($errors)echo '<div class="alert error">'.implode('<br>', array_map('e', $errors)).'</div>'; ?>

<?php if($step==1): ?>
<h2>بررسی پیش‌نیازها</h2>
<table><?php foreach($reqs as $r)echo '<tr><td>'.$r['name'].'</td><td>'.($r['ok']?'<span class="ok">✓</span>':'<span class="fail">✗</span>').'</td></tr>'; ?></table>

<?php if(PHP_OS_FAMILY==='Windows'): ?>
<div class="alert" style="background:#eff6ff;color:#1e40af">
    <strong>راهنمای اجرای محلی روی XAMPP (ویندوز)</strong>
    <ol style="margin:8px 0 0;padding-inline-start:20px;font-size:13px;line-height:2">
        <li><strong>روش ۱ — سرور داخلی PHP (پیشنهادی):</strong> در پوشهٔ پروژه یک CMD باز کنید و اجرا کنید:<br>
        <code style="direction:ltr;display:inline-block;background:#dbeafe;padding:4px 8px;border-radius:6px">C:\xampp\php\php.exe -S 127.0.0.1:8080 dev-router.php</code><br>
        سپس در مرورگر: <code style="direction:ltr">http://127.0.0.1:8080/install</code></li>
        <li><strong>روش ۲ — آپاچی XAMPP (جایگزین):</strong> پروژه را در <code style="direction:ltr">C:\xampp\htdocs\chortke</code> بگذارید، از XAMPP Control Panel هر دو <strong>Apache</strong> و <strong>MySQL</strong> را Start کنید و بروید به:<br>
        <code style="direction:ltr;display:inline-block;background:#dbeafe;padding:4px 8px;border-radius:6px">http://localhost/chortke/public/install/</code></li>
        <li>در XAMPP معمولاً افزونهٔ Redis وجود ندارد؛ در مرحلهٔ ۳ گزینهٔ <strong>database</strong> را برای صف انتخاب کنید.</li>
        <li>خطای «Forbidden» یعنی این صفحه از بیرونِ شبکهٔ محلی باز شده — فقط از <code style="direction:ltr">localhost/127.0.0.1</code> باز کنید.</li>
    </ol>
</div>
<?php endif; ?>

<?php if($reqOk): ?><a href="?step=2" class="btn">ادامه</a><?php else: ?><p style="color:#dc2626">پیش‌نیازهای الزامی را برطرف کنید.</p><?php endif; ?>

<?php elseif($step==2): ?>
<h2>دیتابیس</h2><form method="post">
<input type="hidden" name="_csrf_token" value="<?= e($_SESSION['_csrf_token']) ?>">
<input name="db_host" placeholder="هاست" value="127.0.0.1"><br><br>
<input name="db_port" placeholder="پورت" value="3306"><br><br>
<input name="db_name" placeholder="نام دیتابیس" value="chortke"><br><br>
<input name="db_user" placeholder="کاربر" value="root"><br><br>
<input name="db_pass" type="password" placeholder="رمز"><br><br>
<button class="btn">تست و ادامه</button></form>

<?php elseif($step==3): ?>
<h2>Redis و صف</h2><form method="post">
<input type="hidden" name="_csrf_token" value="<?= e($_SESSION['_csrf_token']) ?>">
<select name="queue_driver"><option value="redis">redis (پیشنهادی)</option><option value="database">database</option></select><br><br>
<input name="redis_host" value="127.0.0.1"><br><br>
<input name="redis_port" value="6379"><br><br>
<input name="redis_pass" type="password" placeholder="رمز ردیس (اختیاری)"><br><br>
<button class="btn">ادامه</button></form>

<?php elseif($step==4): ?>
<h2>تنظیمات + APIها</h2><form method="post">
<input type="hidden" name="_csrf_token" value="<?= e($_SESSION['_csrf_token']) ?>">
<input name="app_name" value="چرتکه"><br><br>
<input name="app_url" value="http://127.0.0.1:8080"><br><br>
<input name="zarinpal" placeholder="Zarinpal Merchant ID"><br><br>
<input name="kavenegar" placeholder="Kavenegar API Key"><br><br>
<button class="btn">ادامه</button></form>

<?php elseif($step==5): ?>
<h2>کاربر مدیر ارشد (Super Admin)</h2><form method="post">
<input type="hidden" name="_csrf_token" value="<?= e($_SESSION['_csrf_token']) ?>">
<input name="admin_email" value="admin@chortke.ir"><br><br>
<input name="admin_pass" type="password" placeholder="رمز ادمین (حداقل ۱۲ کاراکتر ترکیبی)"><br><br>
<p style="font-size:12px;color:#64748b">رمز عبور باید شامل حروف کوچک، بزرگ، اعداد و کاراکترهای ویژه (مانند !@#$) باشد.</p>
<button class="btn">ادامه</button></form>

<?php elseif($step==6): ?>
<h2>روش Workerها و اجرای مایگریشن</h2><form method="post">
<input type="hidden" name="_csrf_token" value="<?= e($_SESSION['_csrf_token']) ?>">
<select name="worker_method"><option value="supervisor">Supervisor</option><option value="systemd">systemd</option><option value="docker">Docker</option></select><br><br>
<button class="btn">نصب نهایی و ساخت حساب مدیر</button></form>

<?php elseif($step==7):
    // FIX-M3-13: the wizard's worker_method choice used to be stored and ignored;
    // the success page now renders REAL per-method deployment instructions.
    $wmLabels = ['supervisor' => 'Supervisor', 'systemd' => 'systemd', 'docker' => 'Docker Compose'];
    $wmGuides = [
        'supervisor' => "sudo cp deploy/supervisor/chortke-queue.conf deploy/supervisor/chortke-outbox.conf deploy/supervisor/chortke-dlq.conf /etc/supervisor/conf.d/\nsudo supervisorctl reread && sudo supervisorctl update && sudo supervisorctl status",
        'systemd'    => "sudo cp deploy/systemd/chortke-queue.service deploy/systemd/chortke-outbox.service deploy/systemd/chortke-dlq.service deploy/systemd/chortke-cron.service deploy/systemd/chortke-cron.timer /etc/systemd/system/\nsudo systemctl daemon-reload && sudo systemctl enable --now chortke-queue chortke-outbox chortke-dlq chortke-cron.timer",
        'docker'     => "APP_KEY/SECURITY_API_TOKEN_SECRET/WEBHOOK_SECRET/APP_URL را در .env کنار deploy/docker/docker-compose.yml تنظیم کنید، سپس:\ndocker compose -f deploy/docker/docker-compose.yml up -d",
    ];
    $wmKey = in_array($_SESSION['wm'] ?? 'supervisor', ['supervisor','systemd','docker'], true) ? ($_SESSION['wm'] ?? 'supervisor') : 'supervisor';
    $queueUsed = in_array($_SESSION['queue_used'] ?? 'redis', ['redis','database'], true) ? ($_SESSION['queue_used'] ?? 'redis') : 'redis';
?>
<div class="alert" style="background:#dcfce7;color:#166534">
    <h2>نصب امن با موفقیت تکمیل شد!</h2>
    <p>حساب مدیر ارشد واقعی با رمزعبور واردشده (هش Argon2id) در دیتابیس ایجاد گردید.</p>
    <p style="font-size:12px">رمز مدیر در فایل .env ذخیره <strong>نمی‌شود</strong> — فقط هش آن در دیتابیس است (FIX-M3-05).</p>
    <p>درایور صف انتخاب‌شده (<code style="direction:ltr">QUEUE_DRIVER=<?= e($queueUsed) ?></code>) در .env ثبت شد.</p>
    <p><strong>هشدار مهم:</strong> پوشه <code>public/install</code> را فوراً حذف یا تغییر نام دهید.</p>
</div>
<h3 style="margin:8px 0 4px">راه‌اندازی Workerها — روش انتخابی شما: <?= e($wmLabels[$wmKey]) ?></h3>
<pre style="direction:ltr;text-align:left;background:#0f172a;color:#e2e8f0;padding:12px;border-radius:8px;overflow:auto"><?= e($wmGuides[$wmKey]) ?></pre>
<pre>php cli.php distributed:health
php cli.php simulate:traceable-event --type=install.test --user=1</pre>
<a href="/login" class="btn">رفتن به صفحه ورود</a>
<?php endif; ?>
</div></div></body></html>
