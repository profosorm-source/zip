# نصب‌کننده گرافیکی فوق قوی چرتکه (نسخه ۴.۷ — Security Hardened)

## ویژگی‌های کلیدی
- رابط کاربری زیبا و کاملاً فارسی (۷ مرحله)
- بررسی واقعی پیش‌نیازها (Redis فقط وقتی صف redis انتخاب شود الزامی است — FIX-M3-10)
- تست زنده اتصال دیتابیس و Redis
- تولید خودکار APP_KEY و SECURITY_API_TOKEN_SECRET
- اعتبارسنجی APP_URL و ایمیل مدیر پیش از persist (FIX-M3-16)
- ورودی کلیدهای API خارجی (Zarinpal, Kavenegar, Tronscan و ...)
- انتخاب Driver صف (redis / database) — روی کلید کانونیکال QUEUE_DRIVER نوشته می‌شود (FIX-M3-09)
- انتخاب روش راه‌اندازی workerها (Supervisor / systemd / Docker) + نمایش دستورالعمل واقعی همان انتخاب در مرحلهٔ آخر (FIX-M3-13)
- اجرای خودکار مایگریشن + ساخت حساب مدیر ارشد با هش Argon2id و عضویت نقش بر اساس slug (FIX-M3-06)
- گارد شبکه‌ای سطح PHP: نصب غیر-loopback فقط با HTTPS + allowlist IP (`INSTALLER_ALLOWED_IPS`) — مستقل از Apache/Nginx (FIX-M3-11)
- قفل امنیتی قوی (installed.lock) با نوشتن اتمیک و fail-closed (FIX-M3-07)
- راستی‌آزمایی round-trip فایل .env با پارسر رسمی اپ پیش از مایگریشن (FIX-M3-16)
- هشدار واضح برای حذف/تغییر نام پوشه install بعد از موفقیت

## نحوه استفاده
1. پروژه را روی سرور آپلود کنید.
2. به این آدرس بروید (روی دامنه/شبکهٔ غیرمحلی فقط HTTPS — FIX-M3-11):
   ```
   https://your-domain.com/install/
   ```
   روی localhost/XAMPP، `http://127.0.0.1:8080/install` نیز کار می‌کند.
3. مراحل را پر کنید.
4. **حتماً** بعد از موفقیت، پوشه `install` را حذف کنید یا نام آن را عوض کنید (مثلاً `install-done`).

## امنیت
- اگر فایل `storage/installed.lock` وجود داشته باشد، installer غیرفعال می‌شود (نوشتن قفل اتمیک و fail-closed است — اگر قفل نوشته نشود، صفحهٔ موفقیت نمایش داده نمی‌شود).
- **رمز مدیر ارشد هرگز در `.env` نوشته نمی‌شود** — فقط هش Argon2id آن در دیتابیس ذخیره می‌شود (FIX-M3-05).
- نصب از شبکه‌های غیرمحلی روی HTTP مسدود است؛ allowlist پیش‌فرض = loopback و رنج‌های خصوصی (هم‌تراز .htaccess) و با `INSTALLER_ALLOWED_IPS` قابل تغییر است.

## بعد از نصب
- workerها را طبق دستورالعمل همان روش انتخابی در مرحلهٔ آخر راه‌اندازی کنید (Supervisor توصیه می‌شود).
- تست کنید:
  ```bash
  php cli.php distributed:health
  php cli.php simulate:traceable-event --type=install.test --user=1
  ```
