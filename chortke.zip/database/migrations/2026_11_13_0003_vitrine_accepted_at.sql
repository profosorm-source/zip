-- T26-06: زمان دقیق پذیرش درخواست (شروع مهلت پرداخت). قبلاً از updated_at درخواست استنباط می‌شد.
ALTER TABLE `vitrine_listings`
  ADD COLUMN IF NOT EXISTS `accepted_at` DATETIME NULL DEFAULT NULL;

-- آگهی‌های awaiting_payment موجود: زمان پذیرش از درخواست accepted
UPDATE `vitrine_listings` vl
  JOIN `vitrine_requests` r ON r.listing_id = vl.id AND r.status = 'accepted'
   SET vl.accepted_at = r.updated_at
 WHERE vl.status = 'awaiting_payment' AND vl.accepted_at IS NULL;
