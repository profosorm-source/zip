-- T27-11: ایندکس ترکیبی برای getDomainScore (SUM delta به‌ازای entity+domain) و کوئری سقف روزانهٔ XP؛
-- idx_se_entity فقط (entity_id, entity_type) را پوشش می‌داد و domain/created_at را فیلتر ردیفی می‌کرد.
ALTER TABLE `score_events` ADD INDEX `idx_se_entity_domain_time` (`entity_id`, `entity_type`, `domain`, `created_at`);
