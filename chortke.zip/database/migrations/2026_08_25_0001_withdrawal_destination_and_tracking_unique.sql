-- ============================================================
-- 2026_08_25_0001_withdrawal_destination_and_tracking_unique.sql
--
-- 🔴 FIX #2 (P1): مقصد برداشت رمزارز هیچ‌جا ذخیره نمی‌شد:
--   * فرم/ولیدیتور crypto_wallet + crypto_network می‌گرفت، سرویس دورش می‌ریخت؛
--   * جدول withdrawals هیچ ستون آدرسی نداشت؛
--   * view ادمین wallet_address خیالی می‌خواند و ادمین برای USDT مقصد نداشت.
-- 🔴 FIX #8e (P2): tracking_code UNIQUE نبود؛ دو تأیید می‌توانستند یک
--   شماره پیگیری داشته باشند.
-- ============================================================

ALTER TABLE `withdrawals`
  ADD COLUMN `wallet_address` VARCHAR(190) NULL DEFAULT NULL AFTER `currency`,
  ADD COLUMN `crypto_network` VARCHAR(20)  NULL DEFAULT NULL AFTER `wallet_address`;

-- پر کردن method برای ردیف‌های موجود (برای ردیف‌های جدید سرویس می‌نویسد)
UPDATE `withdrawals`
   SET `method` = CASE WHEN LOWER(`currency`) = 'usdt' THEN 'crypto' ELSE 'bank_card' END
 WHERE `method` IS NULL OR `method` = '';

-- رفع تداخل قبل از UNIQUE: رشتهٔ خالی → NULL، و از هر تکرار فقط قدیمی‌ترین
-- (کمترین id) نگه داشته می‌شود؛ بقیه NULL می‌شوند تا UNIQUE بدون خطا بنشیند.
UPDATE `withdrawals` SET `tracking_code` = NULL WHERE `tracking_code` = '';

UPDATE `withdrawals` w
  JOIN (
    SELECT `tracking_code`, MIN(`id`) AS keep_id
      FROM `withdrawals`
     WHERE `tracking_code` IS NOT NULL
     GROUP BY `tracking_code`
    HAVING COUNT(*) > 1
  ) dup ON w.`tracking_code` = dup.`tracking_code` AND w.`id` <> dup.keep_id
   SET w.`tracking_code` = NULL;

ALTER TABLE `withdrawals`
  ADD UNIQUE KEY `uq_withdrawals_tracking_code` (`tracking_code`);
