-- ═══════════════════════════════════════════════════════════════════════════
-- FIX-F21-01 (بازبینی بخش ۲۱ — گزینهٔ C ترکیبی، تصمیم مالک)
-- جریان چالش-پاسخ دوربین با nonce یک‌بارمصرف + تحلیل آماری سمت‌سرور فریم‌ها
--
-- ریشهٔ باگ: camera_score و frame_count فقط اعدادِ ادعاییِ کلاینت بودند (clamp
-- می‌شدند ولی هیچ مدرک مستقلی از capture وجود نداشت). رفعِ ریشه‌ای:
--   ۱) nonce یک‌بارمصرف که سرور در لحظهٔ ساخت camera request صادر می‌کند،
--      به user/execution مقید است و با همان UPDATE شرطیِ قبلی (pending +
--      expires_at) فقط یک‌بار قابل مصرف است → replay/dead-request fail-closed.
--   ۲) ویژگی‌های فریم‌ها (زمان‌بندی + روشنایی + نویز سنسور) به سرور می‌آیند و
--      امتیاز/حکم (server_score/server_verdict) سمت‌سرور محاسبه می‌شود —
--      بدون GPU و بدون آپلود تصویر خام (همچنان هیچ عکسی ذخیره نمی‌شود).
--   ۳) attestation (Play Integrity سرور-به-سرور) فقط «سیگنال تقویتی» است —
--      برای کاربران بازار/بدون GMS هرگز شرط عبور نیست (تصمیم مالک).
--
-- ناسازگاری عمدی (fail-closed): رکوردهای completed قدیمی که server_verdict
-- NULL دارند دیگر contribution دوربین نمی‌گیرند (effectiveCameraContribution
-- فقط server_verdict='pass' را می‌پذیرد). این یعنی «ادعای بدون مدرک = صفر» —
-- دقیقاً معیار بستن F21-01 در گزارش بازبینی. اجراهای در-فلایتِ بین deploy،
-- به بررسی دستی می‌روند نه آزادسازی خودکار؛ سمتِ امن است.
-- ═══════════════════════════════════════════════════════════════════════════

ALTER TABLE `social_camera_requests`
  ADD COLUMN IF NOT EXISTS `nonce` VARCHAR(64) NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `nonce_issued_at` TIMESTAMP NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `nonce_consumed_at` TIMESTAMP NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `server_score` DECIMAL(5,2) NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `server_verdict` VARCHAR(12) NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `server_analysis` LONGTEXT NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `attestation_status` VARCHAR(20) NULL DEFAULT NULL;

-- nonce یک‌بارمصرف: یکتایی در سطح DB هم تضمین می‌شود (برخورد تصادفی
-- ۶۴-hex ناممکن است؛ تکراری یعنی باگ تولید → fail-loud به‌جای انبارش).
CREATE UNIQUE INDEX IF NOT EXISTS `uq_scr_nonce` ON `social_camera_requests` (`nonce`);

-- گزارش عملیاتی: توزیع حکم سرور برای پایش نرخ تقلب پس از فعال‌سازی
CREATE INDEX IF NOT EXISTS `idx_scr_verdict` ON `social_camera_requests` (`server_verdict`, `status`, `expires_at`);
