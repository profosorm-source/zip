<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-Q4-MOD24-05 — ستون url_hash نرمال‌شده + UNIQUE برای content_submissions
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه (گزارش ماژول ۲۴، یافتهٔ ۰۵): isUrlExists با «تطابق دقیق رشتهٔ
// video_url» کار می‌کرد؛ یک ویدیو با https/http متفاوت، پارامتر اضافه
// (?t=30)، نسخهٔ youtu.be در برابر youtube.com/watch یا اسلش انتهایی،
// چند رکورد مستقل می‌ساخت ⇒ پرداخت درآمد جداگانه برای همان ویدیو.
//
// طراحی (الگوی اثبات‌شدهٔ R31-C2 / live_period_key):
//   url_hash = SHA-256( platform + ':' + canonicalVideoKey(video_url) )
//     — canonicalVideoKey (در App\Models\ContentSubmission) شناسهٔ ویدیو را
//       برای youtube/aparat استخراج و برای بقیه فرم نرمال عمومی می‌سازد.
//     — ردیف‌های «اشغال‌کنندهٔ زنده» (pending/under_review/approved/
//       published/suspended و is_deleted=0) hash پر دارند؛ ردیف‌های rejected
//       (قابل ارسال مجدد — MOD24-06) و حذف‌شده‌ها NULL دارند.
//     — UNIQUE روی url_hash (خودِ hash، platform را هم درون خود دارد)؛
//       MariaDB چند NULL می‌پذیرد ⇒ معادل partial-unique.
//
// گام‌ها (همه idempotent):
//   ۱) گارد: ستون url_hash هست؟ اگر نه → ALTER TABLE ADD COLUMN.
//   ۲) backfill با همان تابع PHP کد (منبع یگانه) — ردیف زنده hash، بقیه NULL.
//   ۳) جداسازی تکراری‌های زنده (keep-MIN(id) هم‌الگوی 2026_09_20_0003):
//      برای هر (platform, url_hash) زندهٔ تکراری، فقط کمترین id نگه داشته
//      می‌شود؛ بقیه is_deleted=1 می‌شوند (حذف نرم؛ تاریخچه حفظ می‌شود).
//   ۴) UNIQUE KEY uq_content_submissions_url_hash (url_hash).
//   ۵) seed دو تنظیم جدید Q4 + هم‌ترازی توضیح ۴ کلید موجود (MOD24-21) —
//      INSERT IGNORE / UPDATE مقادیر توضیح؛ مقدار تنظیم‌های موجود دست نمی‌خورد.
// ═══════════════════════════════════════════════════════════════════

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('q4m1_column_exists')) {
    function q4m1_column_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT column_name FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE()
               AND table_name = 'content_submissions'
               AND column_name = 'url_hash' LIMIT 1"
        );
        $stmt->execute();
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('q4m1_index_exists')) {
    function q4m1_index_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT index_name FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = 'content_submissions'
               AND index_name = 'uq_content_submissions_url_hash'
               AND non_unique = 0 LIMIT 1"
        );
        $stmt->execute();
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('q4m1_log')) {
    function q4m1_log(string $msg): void
    {
        echo '[q4-mod24-05-url_hash] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try { logger()->info('[q4-mod24-05-url_hash] ' . $msg); } catch (\Throwable $e) { /* best-effort */ }
        }
    }
}

// ── گام ۱: ستون ────────────────────────────────────────────────────
if (!q4m1_column_exists($db)) {
    $db->exec('ALTER TABLE content_submissions ADD COLUMN url_hash CHAR(64) NULL DEFAULT NULL AFTER video_url');
    q4m1_log('column url_hash added');
} else {
    q4m1_log('column url_hash already exists — skip');
}

// ── گام ۲: backfill با همان تابع کد (منبع یگانه) ───────────────────
$liveStatuses = ['pending', 'under_review', 'approved', 'published', 'suspended'];
$in = implode("','", $liveStatuses);
$stmt = $db->prepare(
    "SELECT id, platform, video_url FROM content_submissions
     WHERE url_hash IS NULL AND is_deleted = 0 AND status IN ('{$in}')"
);
$stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_OBJ);

$update = $db->prepare('UPDATE content_submissions SET url_hash = ? WHERE id = ?');
$filled = 0;
foreach ($rows as $row) {
    $hash = \App\Models\ContentSubmission::hashVideoUrl((string)($row->platform ?? ''), (string)($row->video_url ?? ''));
    $update->execute([$hash, (int)$row->id]);
    $filled++;
}
q4m1_log("backfill: {$filled} live rows hashed (rejected/deleted rows intentionally stay NULL)");

// ردیف‌های rejected که قبلاً (قبل از این بچ) hash گرفته باشند → آزادسازی
$freed = $db->exec(
    "UPDATE content_submissions SET url_hash = NULL
     WHERE url_hash IS NOT NULL AND is_deleted = 1"
);
q4m1_log('soft-deleted rows with hash freed: ' . (int)$freed);

// ── گام ۳: تکراری‌های زنده → keep MIN(id)، بقیه حذف نرم ─────────────
$dupGroups = $db->query(
    "SELECT platform, url_hash, COUNT(*) AS c, MIN(id) AS keep_id
     FROM content_submissions
     WHERE url_hash IS NOT NULL AND is_deleted = 0
     GROUP BY platform, url_hash
     HAVING COUNT(*) > 1"
)->fetchAll(\PDO::FETCH_OBJ);

$softDeleted = 0;
if ($dupGroups !== []) {
    $soft = $db->prepare(
        'UPDATE content_submissions SET is_deleted = 1, updated_at = NOW()
         WHERE platform = ? AND url_hash = ? AND id != ? AND is_deleted = 0'
    );
    foreach ($dupGroups as $g) {
        $soft->execute([$g->platform, $g->url_hash, (int)$g->keep_id]);
        $softDeleted += $soft->rowCount();
    }
}
q4m1_log('live duplicate rows soft-deleted (keep MIN(id)): ' . $softDeleted);

// ── گام ۴: UNIQUE ─────────────────────────────────────────────────
if (!q4m1_index_exists($db)) {
    $db->exec('ALTER TABLE content_submissions ADD UNIQUE KEY uq_content_submissions_url_hash (url_hash)');
    q4m1_log('UNIQUE uq_content_submissions_url_hash created');
} else {
    q4m1_log('UNIQUE already exists — skip');
}

// ── گام ۵: تنظیمات Q4 (seed + هم‌ترازی توضیح MOD24-21) ─────────────
$settingsSeed = [
    // key, value, group, type, desc
    ['content_max_submissions_per_day', '10', 'content', 'number', 'سقف ارسال محتوا در شبانه‌روز برای هر کاربر (۰ = بی‌سقف)'],
    ['seo_max_tasks_per_day', '10', 'seo', 'number', 'سقف انجام تسک‌های سئو در شبانه‌روز برای هر کاربر (۰ = بی‌سقف)؛ سقفِ هر کمپین جداگانه از ستون max_per_day همان کمپین است'],
];
$ins = $db->prepare(
    'INSERT IGNORE INTO system_settings (`key`, `value`, `group`, `type`, `description`)
     VALUES (?, ?, ?, ?, ?)'
);
foreach ($settingsSeed as $s) {
    $ins->execute($s);
}
q4m1_log('settings seeded (INSERT IGNORE): content_max_submissions_per_day, seo_max_tasks_per_day');

$descSync = [
    ['content_professional_max_percent', 'سقف کل سهم کاربر (پایه + پاداش) در سطح حرفه‌ای — نه سقفِ خود پاداش'],
    ['content_active_max_percent', 'سقف کل سهم کاربر (پایه + پاداش) در سطح فعال — نه سقفِ خود پاداش'],
];
$upd = $db->prepare('UPDATE system_settings SET description = ? WHERE `key` = ?');
foreach ($descSync as $s) {
    $upd->execute($s);
}
q4m1_log('descriptions synced for MOD24-21 (value untouched)');

q4m1_log('DONE');
