-- کد ماشینی دلیل رد اجرای سئو (جایگزین تطبیق متن فارسی در ویو)
-- مقادیر: not_seo | incomplete_data | too_fast | security_policy | low_score | payout_unavailable
-- ردیف‌های قدیمی NULL می‌مانند؛ ویو برای آن‌ها به تطبیق متن برمی‌گردد.
ALTER TABLE `seo_executions`
  ADD COLUMN IF NOT EXISTS `rejection_code` VARCHAR(32) NULL DEFAULT NULL
    COMMENT 'کد ماشینی دلیل رد (rejection_reason متن خام ممیزی است)' AFTER `rejection_reason`;
