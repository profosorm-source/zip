-- =====================================================
-- S3-H1 FIX (S33-B3 audit): impossible-travel needs real coordinates
--
-- The impossible-travel detector compared the CURRENT location against
-- `user_sessions` rows that never carry latitude/longitude, so the check
-- silently fell back to a fabricated Tehran anchor for every user and the
-- signal was fiction. These columns let SessionService persist the resolved
-- coordinates (NULL when unknown / null-island) so the detector compares
-- real locations, and legacy rows honestly skip the check.
-- =====================================================

ALTER TABLE `user_sessions` ADD COLUMN IF NOT EXISTS `latitude` DECIMAL(10,7) NULL DEFAULT NULL;
ALTER TABLE `user_sessions` ADD COLUMN IF NOT EXISTS `longitude` DECIMAL(10,7) NULL DEFAULT NULL;
