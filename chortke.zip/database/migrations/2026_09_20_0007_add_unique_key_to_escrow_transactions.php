<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-R20-B2 — UNIQUE(order_id, order_type) برای escrow_transactions
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه (Task 20-B، موردهای deferred بک‌لاگ راند ۱۹): جدول
// escrow_transactions فقط PRIMARY(id) + UNIQUE غیریکتای تولیدشدهٔ
// uq_escrow_active_order(active_order_key) داشت — آن کلیدِ تولیدی برای
// «حداکثر یک اسکرو فعال per order» است و به‌محض release/refund/cancel
// NULL می‌شود؛ یعنی بعد از بسته‌شدن اسکرو هیچ قید یکتایی روی خودِ جفت
// (order_id, order_type) باقی نمی‌ماند و سطرهای تکراریِ تاریخی آزادانه
// انباشت می‌شوند.
//
// کلید یکتا: escrow_transactions_order_unique (order_id, order_type) —
// ستون‌ها varchar(100) NOT NULL هستند و NULL-ساز نیستند.
//
// پیش‌شرط اجرا (تأییدشده موقع نوشتن): جدول live خالی است (۰ ردیف)،
// پس نیازی به جداسازی ردیف‌های تکراری نیست. Idempotent (الگوی
// information_schema 2026_09_20_0003): اگر UNIQUE دوسطونی روی
// (order_id, order_type) از قبل وجود داشته باشد، skip می‌شود.
//
// اجرا: چه توسط MigrationService (require درون‌پردازشی) و چه مستقیم با
// php CLI، گارد function_exists + return تمیز باعث می‌شود اجرای تکراری
// بی‌خطر باشد.
// ═══════════════════════════════════════════════════════════════════

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r20b2_escrow_order_unique_exists')) {
    /** آیا یک UNIQUE index دوسطونی روی (order_id, order_type) هست؟ */
    function r20b2_escrow_order_unique_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT index_name
             FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = 'escrow_transactions'
               AND non_unique = 0
               AND index_name <> 'PRIMARY'
               AND column_name IN ('order_id', 'order_type')
             GROUP BY index_name
             HAVING COUNT(DISTINCT column_name) = 2
             LIMIT 1"
        );
        $stmt->execute();
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('r20b2_escrow_log')) {
    function r20b2_escrow_log(string $msg): void
    {
        echo '[20b2-escrow-order-unique] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.20b2_escrow_order_unique', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

if (r20b2_escrow_order_unique_exists($db)) {
    r20b2_escrow_log('SKIP: UNIQUE index روی (order_id, order_type) از قبل وجود دارد (idempotent).');
    return; // پایان تمیزِ فایل مایگریشن (بدون interrupt کردن runner)
}

// جدول live خالی است (تأییدشده: COUNT(*) = 0) — بدون dedup
$db->exec('ALTER TABLE escrow_transactions ADD UNIQUE KEY escrow_transactions_order_unique (order_id, order_type)');
r20b2_escrow_log('OK: UNIQUE KEY escrow_transactions_order_unique (order_id, order_type) ساخته شد.');
