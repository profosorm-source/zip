<?php

declare(strict_types=1);

/**
 * Migration (راند ۷۷ — ستون شبح): ستون‌های کامل گردش‌کار withdrawal_reviews
 *
 * سرویس ReconciliationService یک گردش‌کار کامل بررسی برداشت‌های گیرکرده دارد
 * (open → in_progress → admin_resolved/dismissed/auto_resolved) که روی ستون‌هایی
 * مثل severity/reason_code/details/resolved_* می‌نویسد و هرگز وجود نداشتند (42S22).
 * این مایگریشن آن ستون‌ها را بر اساس قرارداد واقعی کد اضافه می‌کند.
 * ستون status واقعی (varchar 20) مقادیر گردش‌کار را می‌پذیرد؛ نام review_status در کد به status تغییر یافت.
 *
 * Idempotent: هر ستون با information_schema بررسی می‌شود.
 */

if (!function_exists('r77c_column_exists')) { // FIX-S19-4: گارد فراخوانی‌مجدد (الگوی رسمی مایگریشن‌های پروژه)
function r77c_column_exists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?"
    );
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}
}

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$pdo = $app->db()->getPdo();

$columns = [
    ['withdrawal_reviews', 'detected_status', "ALTER TABLE withdrawal_reviews ADD COLUMN detected_status VARCHAR(30) NULL DEFAULT NULL AFTER status"],
    ['withdrawal_reviews', 'transaction_status', "ALTER TABLE withdrawal_reviews ADD COLUMN transaction_status VARCHAR(30) NULL DEFAULT NULL AFTER detected_status"],
    ['withdrawal_reviews', 'stuck_minutes', "ALTER TABLE withdrawal_reviews ADD COLUMN stuck_minutes INT UNSIGNED NULL DEFAULT NULL AFTER stuck_hours"],
    ['withdrawal_reviews', 'severity', "ALTER TABLE withdrawal_reviews ADD COLUMN severity VARCHAR(20) NULL DEFAULT NULL AFTER stuck_minutes"],
    ['withdrawal_reviews', 'reason_code', "ALTER TABLE withdrawal_reviews ADD COLUMN reason_code VARCHAR(50) NULL DEFAULT NULL AFTER severity"],
    ['withdrawal_reviews', 'details', "ALTER TABLE withdrawal_reviews ADD COLUMN details TEXT NULL DEFAULT NULL AFTER reason_code"],
    ['withdrawal_reviews', 'assigned_admin_id', "ALTER TABLE withdrawal_reviews ADD COLUMN assigned_admin_id INT UNSIGNED NULL DEFAULT NULL AFTER admin_id"],
    ['withdrawal_reviews', 'resolved_at', "ALTER TABLE withdrawal_reviews ADD COLUMN resolved_at DATETIME NULL DEFAULT NULL AFTER assigned_admin_id"],
    ['withdrawal_reviews', 'resolved_by', "ALTER TABLE withdrawal_reviews ADD COLUMN resolved_by INT UNSIGNED NULL DEFAULT NULL AFTER resolved_at"],
    ['withdrawal_reviews', 'resolution_note', "ALTER TABLE withdrawal_reviews ADD COLUMN resolution_note VARCHAR(1000) NULL DEFAULT NULL AFTER resolved_by"],
    ['withdrawal_reviews', 'notified_admin_at', "ALTER TABLE withdrawal_reviews ADD COLUMN notified_admin_at DATETIME NULL DEFAULT NULL AFTER resolution_note"],
    ['withdrawal_reviews', 'updated_at', "ALTER TABLE withdrawal_reviews ADD COLUMN updated_at TIMESTAMP NULL DEFAULT NULL AFTER notified_admin_at"],
];

$applied = 0;
foreach ($columns as [$table, $column, $ddl]) {
    if (!r77c_column_exists($pdo, $table, $column)) {
        $pdo->exec($ddl);
        $applied++;
        echo "{$table}.{$column} added\n";
    } else {
        echo "{$table}.{$column} already exists\n";
    }
}

echo "applied={$applied}\n";
