-- =====================================================
-- P1-3 FIX (S33 Services audit): unify FeatureFlag rollout column
--
-- The schema carried TWO rollout columns after the 2026_06_12
-- reconciliation (`enabled_percentage` — the one the service
-- create/update paths write — and legacy `percentage_rollout` — the
-- one the old evaluator read). Because the write paths only ever
-- touched `enabled_percentage`, canary / partial-rollout changes had
-- no effect on evaluation. Code now reads and writes ONLY
-- `enabled_percentage` (FeatureFlagService, FeatureFlag model,
-- CacheWarmupJob).
--
-- This migration backfills any legacy intent and drops the phantom
-- column so the phantom names can never drift again.
-- =====================================================

-- 1. Preserve legacy rollout values where the canonical column was
--    never explicitly set (both default to 100, so this is a no-op in
--    most installations but keeps intent for partial rollouts).
UPDATE `feature_flags`
SET `enabled_percentage` = `percentage_rollout`
WHERE `enabled_percentage` IS NULL
  AND `percentage_rollout` IS NOT NULL;

-- 2. Drop the legacy column — the code no longer references it.
ALTER TABLE `feature_flags` DROP COLUMN IF EXISTS `percentage_rollout`;
