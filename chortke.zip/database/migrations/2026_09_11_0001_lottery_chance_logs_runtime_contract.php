<?php
// ═══════════════════════════════════════════════════════════════════
// X319 (تسک ۸۳) — قرارداد ران‌تایم lottery_chance_logs
// ═══════════════════════════════════════════════════════════════════
//
// پیش‌زمینه: UpdateLotteryChanceScoresJob (بازوزن‌کنندهٔ روزانهٔ شانس لاتاری)
// ستون‌های participation_id/round_id/date/score_before/score_change/
// score_after/details را در lottery_chance_logs INSERT می‌کند، ولی جدول
// (2026_06_10_0019_final_cleanup.sql:73-81) فقط
// id/user_id/change_amount/reason/created_at دارد → هر اجرای Job با SQL
// error کل تراکنش روزانه را rollback می‌کند و بازوزن‌کردن شانس عملاً
// مرده بود. LotteryChanceLog::getByParticipation هم همان ستون‌ها را
// SELECT می‌کند و LotteryParticipation::getChanceLogsByParticipation
// اشتباهاً به جدول موازیِ chance_logs (بدون participation_id) کوئری
// می‌زد (کوئری‌های ۴۲S22 همیشگی).
//
// این مایگریشنِ idempotent ستون‌های نوشته‌شدهٔ Job را با تیپ‌های سازگار
// اضافه می‌کند + ایندکس پوشش‌دهندهٔ (participation_id, date) برای خوانش
// تاریخچهٔ شانس. ستون قدیمی change_amount حفظ می‌شود (سازگاری ردیف‌های
// legacy). Generated: 2026-09-11

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r83_column_exists')) {
    function r83_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?"
        );
        $stmt->execute([$table, $column]);
        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r83_index_exists')) {
    function r83_index_exists(PDO $db, string $table, string $index): bool
    {
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM information_schema.statistics
             WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?"
        );
        $stmt->execute([$table, $index]);
        return (int) $stmt->fetchColumn() > 0;
    }
}

$applied = 0;
$skipped = 0;

// ستون‌هایی که Job می‌نویسد و جدول ندارد — با تیپ‌های منطبق بر دادهٔ واقعی
$newColumns = [
    'participation_id' => 'INT UNSIGNED NULL DEFAULT NULL AFTER user_id',
    'round_id'         => 'INT UNSIGNED NULL DEFAULT NULL AFTER participation_id',
    'date'             => 'DATE NULL DEFAULT NULL AFTER round_id',
    'score_before'     => 'DECIMAL(14,4) NULL DEFAULT NULL AFTER date',
    'score_change'     => 'DECIMAL(14,4) NULL DEFAULT NULL AFTER score_before',
    'score_after'      => 'DECIMAL(14,4) NULL DEFAULT NULL AFTER score_change',
    'details'          => "VARCHAR(255) NULL DEFAULT NULL AFTER reason",
];

foreach ($newColumns as $column => $definition) {
    if (r83_column_exists($db, 'lottery_chance_logs', $column)) {
        $skipped++;
        continue;
    }
    $db->exec('ALTER TABLE `lottery_chance_logs` ADD COLUMN `' . str_replace('`', '', $column) . '` ' . $definition);
    $applied++;
}

// ایندکس خوانش تاریخچهٔ شانس (WHERE participation_id = ? ORDER BY date DESC)
if (!r83_index_exists($db, 'lottery_chance_logs', 'idx_lcl_participation_date')) {
    $db->exec('ALTER TABLE `lottery_chance_logs` ADD INDEX `idx_lcl_participation_date` (`participation_id`, `date`)');
    $applied++;
} else {
    $skipped++;
}

echo 'migration 2026_09_11_0001_lottery_chance_logs_runtime_contract: OK'
    . " (server=mariadb, applied={$applied}, skipped={$skipped})\n";
