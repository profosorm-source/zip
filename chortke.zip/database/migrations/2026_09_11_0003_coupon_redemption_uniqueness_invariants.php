<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-X335 (راند ۸۴) — قیدهای یکتایی coupon_redemptions
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه: جدول coupon_redemptions فقط ایندکس عادی idx_cr_user داشت و
// «یکتایی» فقط با الگوی check-then-insert در سرویس تضمین می‌شد:
//
//   ۱) سهمیهٔ هر کاربر: hasUserUsedCouponForUpdate (FOR UPDATE) — یعنی
//      یک کاربر هر کوپن را فقط یک‌بار مصرف می‌کند؛ ولی در DB هیچ UNIQUE
//      (user_id, coupon_id) وجود نداشت و تنها سد، قفل گپ InnoDB +
//      runWithRetry بود (دو ریس مسابقه می‌توانستند به دی‌لاک برسند).
//   ۲) ضدتکرار entity: SELECT ... WHERE entity_type=? AND entity_id=?
//      (بدون قفل تا راند ۸۴، بدون ایندکس یونیک همیشه) — یعنی هر موجودیت
//      فقط یک‌بار باید تخفیف بگیرد؛ این هم در DB قید نداشت.
//
// این مایگریشن دو قید یونیک را اضافه می‌کند (دقیقاً همان ناورداهای
// سرویس — فایل کد راند ۸۴، FIX-X331/X335):
//
//   uq_cr_user_coupon (user_id, coupon_id)
//   uq_cr_entity      (entity_type, entity_id)
//
// نکتهٔ NULL: entity_id NULL است؛ در MySQL/MariaDB ایندکس یونیک ردیف‌های
// NULL چندگانه را مجاز می‌داند، پس ردیف‌های بدون entity دست‌نخورده می‌مانند
// (رفتار مطلوب — گارد entity فقط برای ردیف‌های دارای entity معنا دارد).
//
// قبل از افزودن هر ایندکس، تکراری‌های موجود بررسی می‌شوند؛ اگر دادهٔ
// تکراری وجود داشته باشد آن ایندکس ساخته نمی‌شود و پیام واضح چاپ می‌شود
// (fail-safe — مایگریشن هرگز دادهٔ کاربر را پاک نمی‌کند؛ خروجی دستی
// اصلاحِ داده به ادمین واگذار می‌شود).
//
// سازگار با MariaDB و Oracle MySQL 8 (بدون ستون generated / FK).
// کاملاً idempotent (الگوی information_schema، همان راندهای قبل).
// Generated: 2026-09-11

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r84_index_exists')) {
    /** آیا ایندکس با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r84_index_exists(PDO $db, string $table, string $index): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.statistics
             WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?'
        );
        $stmt->execute([$table, $index]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r84_has_duplicate_groups')) {
    /** آیا روی ستون‌های داده‌شده گروه تکراری وجود دارد؟ */
    function r84_has_duplicate_groups(PDO $db, string $table, array $cols): bool
    {
        $colList = implode(', ', $cols);
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM (
                SELECT {$colList} FROM {$table} GROUP BY {$colList} HAVING COUNT(*) > 1
             ) AS d"
        );
        $stmt->execute();

        return (int) $stmt->fetchColumn() > 0;
    }
}

$log = static function (string $msg): void {
    // خروجی قابل‌مشاهده در cli.php migration و لاگ
    echo '[x335-coupon-uniqueness] ' . $msg . PHP_EOL;
    if (function_exists('logger')) {
        try {
            logger()->info('migration.x335', ['msg' => $msg]);
        } catch (\Throwable $e) {
            // لاگ نباید مایگریشن را بشکند
        }
    }
};

$table = 'coupon_redemptions';

// ── قید ۱: یک کوپن برای هر کاربر فقط یک‌بار ─────────────────────
if (!r84_index_exists($db, $table, 'uq_cr_user_coupon')) {
    if (r84_has_duplicate_groups($db, $table, ['user_id', 'coupon_id'])) {
        $log('SKIP uq_cr_user_coupon: دادهٔ تکراری (user_id, coupon_id) موجود است — ابتدا داده را اصلاح کنید.');
    } else {
        $db->exec("ALTER TABLE {$table} ADD UNIQUE KEY uq_cr_user_coupon (user_id, coupon_id)");
        $log('OK: uq_cr_user_coupon ساخته شد.');
    }
} else {
    $log('SKIP uq_cr_user_coupon: از قبل موجود است (idempotent).');
}

// ── قید ۲: یک تخفیف برای هر موجودیت فقط یک‌بار (سراسری) ─────────
if (!r84_index_exists($db, $table, 'uq_cr_entity')) {
    if (r84_has_duplicate_groups($db, $table, ['entity_type', 'entity_id'])) {
        $log('SKIP uq_cr_entity: دادهٔ تکراری (entity_type, entity_id) موجود است — ابتدا داده را اصلاح کنید.');
    } else {
        $db->exec("ALTER TABLE {$table} ADD UNIQUE KEY uq_cr_entity (entity_type, entity_id)");
        $log('OK: uq_cr_entity ساخته شد.');
    }
} else {
    $log('SKIP uq_cr_entity: از قبل موجود است (idempotent).');
}
