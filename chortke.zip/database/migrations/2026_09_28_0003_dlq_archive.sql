-- =============================================================================
-- FIX-C97/C131 — DLQ Archive: آرشیو واقعی پیام‌های غیرقابل‌بازیابی
-- (یافته‌های ممیزی ۹۷ و ۱۳۱)
-- =============================================================================
-- پیشینه:
--   (۹۷) چرخهٔ DLQ «آرشیو» واقعی نداشت؛ core/Queue::archiveDlqJob() فقط رویداد
--        لاگ می‌کرد و payload برای همیشه حذف می‌شد (Data Loss).
--   (۱۳۱) job خراب (payload ناسازگار) بدون quarantine رد می‌شد و مسیر
--         بازبینی مدیریتی نداشت.
-- راه‌حل: جدول آرشیو واقعی برای بازبینی/کاوش بعدی؛ قرارداد archive در
-- core/Queue::archiveDlqJob() و DlqWorker به این جدول می‌نویسد.
-- =============================================================================

CREATE TABLE IF NOT EXISTS `dlq_archive` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `original_failed_job_id` BIGINT UNSIGNED NULL DEFAULT NULL
        COMMENT 'FIX-C97: شناسهٔ ردیف اصلی در failed_jobs (بعد از حذف، مرجع بازبینی)',
    `queue` VARCHAR(255) NULL DEFAULT NULL,
    `job_class` VARCHAR(255) NULL DEFAULT NULL
        COMMENT 'نام کلاس job استخراج‌شده از payload (NULL = payload خراب)',
    `payload` LONGTEXT NULL
        COMMENT 'FIX-C131: payload کامل خام — برای بازبینی دستی',
    `exception` LONGTEXT NULL,
    `archive_reason` VARCHAR(64) NOT NULL DEFAULT 'manual_purge'
        COMMENT 'چرای آرشیو: unrecoverable_poison_message | manual_purge | retention',
    `failed_at` TIMESTAMP NULL DEFAULT NULL,
    `archived_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `archived_by` VARCHAR(64) NULL DEFAULT NULL
        COMMENT 'شناسهٔ worker/command آرشیوکننده',
    KEY `idx_dlq_archive_queue` (`queue`),
    KEY `idx_dlq_archive_reason` (`archive_reason`),
    KEY `idx_dlq_archive_failed_at` (`failed_at`),
    KEY `idx_dlq_archive_original_id` (`original_failed_job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
