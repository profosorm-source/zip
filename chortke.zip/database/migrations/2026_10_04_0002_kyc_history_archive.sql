-- =====================================================================
-- FIX-M10-H7/M5 (گزارش جامع نهایی ماژول ۱۰): آرشیو تاریخچهٔ KYC
-- ---------------------------------------------------------------------
-- ریشهٔ مشکل: kyc_verifications به‌صورت single-record روی user_id کار می‌کند
-- (UNIQUE) و resubmit رکورد قبلی را DELETE می‌کند → سابقهٔ درخواست‌ها و
-- شواهد تصمیم‌ها (forensic/AML) از بین می‌رود.
-- راه‌حل ریشه‌ای: جدول آرشیو append-only؛ قبل از حذف رکورد قبلی در resubmit،
-- کپیِ امضاشدهٔ آن داخل همان تراکنش درج می‌شود (or همه یا هیچ).
-- دادهٔ حساس (کد ملی رمز، تصویر) آرشیو نمی‌شود — فقط hash و متادیتای تصمیم.
-- =====================================================================
CREATE TABLE IF NOT EXISTS kyc_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    original_kyc_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    last_status VARCHAR(20) NOT NULL,
    national_code_hash CHAR(64) NULL,
    rejection_reason VARCHAR(500) NULL,
    submitted_at DATETIME NULL,
    reviewed_at DATETIME NULL,
    verified_at DATETIME NULL,
    expires_at DATETIME NULL,
    created_at DATETIME NULL,
    archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    archived_reason VARCHAR(50) NOT NULL DEFAULT 'resubmit',
    INDEX idx_kych_user (user_id),
    INDEX idx_kych_orig (original_kyc_id),
    INDEX idx_kych_hash (national_code_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
