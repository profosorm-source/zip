-- X374 (راند ۹۳) — دامنهٔ KPI برای وب‌هوک S2S ویدیو-پاداشی.
-- s2s_hook_events لجر مشاهده‌پذیری (observability) است، نه لجر مالی:
-- هر خروجی نهاییِ AdtubeController::s2sWebhook (credited/replay/rejected)
-- یک ردیف best-effort ثبت می‌کند تا داشبورد ادمین نرخ پذیرش، الگوی ردشدگی
-- و مجموع پاداش هر شبکه را نشان دهد. txid خام هرگز ذخیره نمی‌شود — فقط sha256.
CREATE TABLE IF NOT EXISTS `s2s_hook_events` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `network` VARCHAR(40) NOT NULL,
  `outcome` VARCHAR(30) NOT NULL,           -- credited | replay | rejected
  `reject_reason` VARCHAR(40) NULL,          -- bad_timestamp | bad_signature | unknown_network | invalid_user | server_error
  `user_id` INT UNSIGNED NULL,
  `txid_hash` CHAR(64) NULL,                 -- sha256(network|txid) — هرگز txid خام
  `payout_amount` DECIMAL(24,8) NULL,
  `currency` VARCHAR(10) NULL,
  `http_status` SMALLINT UNSIGNED NOT NULL,
  `ip` VARCHAR(45) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_s2s_events_network_created` (`network`, `created_at`),
  KEY `idx_s2s_events_outcome` (`outcome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- X373 (راند ۹۳) — ایندکس پوششیِ leaderboard ماهانهٔ XP روی لجر score_events:
-- کوئری SUM(delta) GROUP BY entity_id با فیلتر entity_type+domain+created_at
-- (پیش‌تر فقط idx_se_entity(entity_id, entity_type) وجود داشت — برای خواندن
-- پنجرهٔ ماه کامل scan می‌شد؛ leaderboard و rankFor اکنون از این ایندکس می‌خوانند).
CREATE INDEX IF NOT EXISTS `idx_score_events_xp_month`
    ON `score_events` (`entity_type`, `domain`, `created_at`);
