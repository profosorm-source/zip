<?php

declare(strict_types=1);

/**
 * 🛡️ FIX-CH25 + FIX-CH26 (راند ۱۵ — گزارش بخش‌های ۸-۴۰)
 *
 * CH-25 — interactions: گارد علاقه‌مندی/امتیاز check-then-insert با SELECT ... FOR UPDATE
 * متکی به gap-lock موتور بود؛ وقتی ردیفی وجود ندارد قفل قابل‌اتکا نیست.
 * قید UNIQUE ترکیبی (user_id, interactable_type, interactable_id, interaction_type)
 * آن را در سطح دیتابیس اتمیک می‌کند. جدول فعلی فقط PK و ایندکس target داشت.
 *
 * CH-26 — fraud_reports: ضدتکرار «یک گزارش pending باز به‌ازای هر جفت
 * (گزارش‌دهنده، گزارش‌شونده)» فقط SELECT سپس INSERT بود. MySQL/MariaDB
 * ایندکس partial ندارد؛ ستون generated مجازی فقط ردیف‌های pending را در
 * قید یکتا شرکت می‌دهد — ردیف‌های reviewed/dismissed محدود نمی‌شوند و
 * «حداکثر یک pending به‌ازای هر جفت» durable می‌شود.
 *
 * هر دو عملیات idempotent‌اند (بررسی وجود ایندکس/ستون پیش از ساخت).
 */
final class Migration_2026_10_03_0004_interaction_and_fraud_unique_invariants
{
    public function up($db): void
    {
        $isMaria = self::isMariaDb($db);

        // ── CH-25: UNIQUE ترکیبی interactions ──
        if (!self::indexExists($db, 'interactions', 'uq_interactions_user_target_type')) {
            $db->exec(
                "ALTER TABLE `interactions`
                 ADD UNIQUE KEY `uq_interactions_user_target_type`
                 (`user_id`, `interactable_type`, `interactable_id`, `interaction_type`)"
            );
        }

        // ── CH-26: ستون generated + UNIQUE pending-pair fraud_reports ──
        if (!self::columnExists($db, 'fraud_reports', 'pending_pair_flag')) {
            $db->exec(
                "ALTER TABLE `fraud_reports`
                 ADD COLUMN `pending_pair_flag` TINYINT(1)
                 GENERATED ALWAYS AS (IF(`status` = 'pending', 1, NULL)) "
                . ($isMaria ? 'VIRTUAL' : 'VIRTUAL')
            );
        }
        if (!self::indexExists($db, 'fraud_reports', 'uq_fraud_reports_pending_pair')) {
            $db->exec(
                "ALTER TABLE `fraud_reports`
                 ADD UNIQUE KEY `uq_fraud_reports_pending_pair`
                 (`reporter_id`, `reported_user_id`, `pending_pair_flag`)"
            );
        }

        // ── CH-29: UNIQUE گزارش پیام (reporter, message) ──
        // ضدتکرار فقط check-then-insert بود؛ دو submit هم‌زمان صف moderation
        // را با رکورد تکراری باد می‌کرد. ردیف‌های دوبلهٔ تاریخی هم پیش از ساخت
        // قید حذف می‌شوند (قدیمی‌ترین نگه داشته می‌شود).
        $dupMessageReports = (int)self::scalar($db,
            "SELECT COUNT(*) FROM (
                SELECT reporter_id, message_id FROM message_reports
                GROUP BY reporter_id, message_id HAVING COUNT(*) > 1
             ) d"
        );
        if ($dupMessageReports > 0) {
            $db->exec(
                "DELETE mr1 FROM message_reports mr1
                 JOIN message_reports mr2
                   ON mr1.reporter_id = mr2.reporter_id
                  AND mr1.message_id = mr2.message_id
                  AND mr1.id > mr2.id"
            );
        }
        if (!self::indexExists($db, 'message_reports', 'uq_message_reports_reporter_message')) {
            $db->exec(
                "ALTER TABLE `message_reports`
                 ADD UNIQUE KEY `uq_message_reports_reporter_message` (`reporter_id`, `message_id`)"
            );
        }
    }

    private static function scalar($db, string $sql): int
    {
        $row = $db->fetch($sql);
        $vars = get_object_vars($row);
        return (int)reset($vars);
    }

    private static function isMariaDb($db): bool
    {
        try {
            return str_contains(strtolower((string)$db->fetchColumn('SELECT VERSION()')), 'mariadb');
        } catch (\Throwable) {
            return true; // استقرار مرجع پروژه MariaDB است
        }
    }

    private static function indexExists($db, string $table, string $index): bool
    {
        $row = $db->fetch(
            "SELECT COUNT(*) AS c FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?",
            [$table, $index]
        );
        return (int)($row->c ?? 0) > 0;
    }

    private static function columnExists($db, string $table, string $column): bool
    {
        $row = $db->fetch(
            "SELECT COUNT(*) AS c FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
            [$table, $column]
        );
        return (int)($row->c ?? 0) > 0;
    }
}

return new Migration_2026_10_03_0004_interaction_and_fraud_unique_invariants();
