-- ═══════════════════════════════════════════════════════════════════
-- FIX-DB-15 (راند ۱۲) — سیاست حذف روی FKهای مالی: CASCADE → RESTRICT
-- ═══════════════════════════════════════════════════════════════════
-- پیشینه: 2026_06_16_0003 با FOREIGN_KEY_CHECKS=0، FKهای users→
-- transactions/withdrawals/investments/escrow_transactions را با
-- ON DELETE CASCADE ساخت. حذف فیزیکی کاربر می‌توانست کل سوابق
-- مالی/escrow متصل را cascade-delete کند. جریان حذف اپ صرفاً
-- soft-delete است (AccountDeletionService: UPDATE users SET
-- status='deleted')، پس CASCADE فقط یک تلهٔ پنهان برای هر حذف فیزیکی
-- آینده (اپ یا عملیات DBA) است؛ برای ledger/payment/escrow سیاست
-- درست RESTRICT است: هر تلاشِ حذفِ کاربرِ صاحب سابقهٔ مالی باید با
-- خطای صریح (1451) رد شود، نه سکوتِ حذف تاریخ.
--
-- UPDATE_RULE و نام قیدها عیناً از وضعیت زندهٔ DB حفظ می‌شود تا فقط
-- DELETE_RULE عوض شود. بازسازی FK با checks روشن انجام می‌شود (FK
-- موجود، integrity را همین امروز تضمین می‌کند؛ orphan تازه‌ای ساخته
-- نمی‌شود). idempotent: DROP غایب → 1091، ADD تکراری → 1826 — هر دو
-- در طبقه‌بند idempotency runner این خطاها را رد می‌کند.
-- ═══════════════════════════════════════════════════════════════════

ALTER TABLE `transactions`
  DROP FOREIGN KEY `fk_transactions_user`;
ALTER TABLE `transactions`
  ADD CONSTRAINT `fk_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `withdrawals`
  DROP FOREIGN KEY `fk_withdrawal_user`;
ALTER TABLE `withdrawals`
  ADD CONSTRAINT `fk_withdrawal_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `investments`
  DROP FOREIGN KEY `fk_investment_user`;
ALTER TABLE `investments`
  ADD CONSTRAINT `fk_investment_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `escrow_transactions`
  DROP FOREIGN KEY `fk_escrow_buyer`;
ALTER TABLE `escrow_transactions`
  ADD CONSTRAINT `fk_escrow_buyer` FOREIGN KEY (`buyer_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `escrow_transactions`
  DROP FOREIGN KEY `fk_escrow_seller`;
ALTER TABLE `escrow_transactions`
  ADD CONSTRAINT `fk_escrow_seller` FOREIGN KEY (`seller_id`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
