-- 🛡️ FIX-SEO-23-01 (فاز ۱ — ریدایرکت شمارنده): ستون‌های اثبات کلیک سمت سرور.
-- تا پیش از این «باز کردن سایت هدف» صرفاً ادعای کلاینت بود (target_opened در
-- JSON کامل‌سازی) و کلاینت جعلی می‌توانست بدون باز کردن سایت هم تا سقفِ
-- پاداش غیرقابل‌اثبات (تنظیم seo_unverified_payout_cap_percent، پیش‌فرض ۶۰٪
-- بازه) برسد. از این پس دکمهٔ «باز کردن سایت هدف» از مسیر سرور
-- (‎/seo/{id}/go/{token}‎) عبور می‌کند و سرور لحظهٔ کلیک را مهر می‌زند:
--
--   click_token             — nonce یک‌بارمصرفِ صادرشده برای هر اجرا (48 هگز)
--   click_token_expires_at  — مهلت اعتبار nonce (پیش‌فرض ۱۵ دقیقه)
--   click_counted_at        — مهر زمانی سرور: کلیک از مسیر رسمی عبور کرده
--                             (NULL = اثبات‌نشده؛ ادعای کلاینت پذیرفته نمی‌شود)
--
-- مصرف nonce اتمیک است (UPDATE ... WHERE click_counted_at IS NULL AND
-- click_token_expires_at > NOW()) ⇒ بازپخش/مصرف مجدد/نقش‌زدن دو تب هم‌زمان
-- ممکن نیست. پس از مصرف، click_counted_at مرجع بی‌چون‌وچرای «کلیک اثبات‌شده»
-- است و مسیر پرداخت (ProcessSeoTaskAsyncJob) ادعای target_opened کلاینت را
-- با همین مهر بازنویسی می‌کند و سقف پاداش اثبات‌شده
-- (seo_click_proven_payout_cap_percent) را اعمال می‌کند.

ALTER TABLE `seo_executions`
  ADD COLUMN `click_token` VARCHAR(64) NULL DEFAULT NULL
    COMMENT 'nonce یک‌بارمصرف مسیر go — فاز ۱ اثبات کلیک سئو' AFTER `device_fingerprint`,
  ADD COLUMN `click_token_expires_at` TIMESTAMP NULL DEFAULT NULL
    COMMENT 'مهلت اعتبار nonce مسیر go' AFTER `click_token`,
  ADD COLUMN `click_counted_at` TIMESTAMP NULL DEFAULT NULL
    COMMENT 'مهر سرور: کلیک از ریدایرکت شمارنده عبور کرده (اثبات کلیک)' AFTER `click_token_expires_at`,
  ADD INDEX `idx_seo_exec_click_token` (`click_token`);
