<?php

declare(strict_types=1);

/**
 * Migration (راند ۷۷ — ستون شبح): ستون‌های موتور هشدار Sentry
 *
 * ۱) alert_rules.last_triggered_at — وضعیت load-bearing موتور قواعد؛ چهار فراخوان واقعی:
 *    AlertDispatcher:101، AlertRulesEngine:133/142، SystemTelemetryModel::updateRuleLastTriggered.
 * ۲) notification_history.alert_id — لینک ممیزی «کدام هشدار کدام نوتیفیکیشن» (AlertDispatcher:180/182).
 * ۳) system_alerts.sent_at — زمان ارسال واقعی هشدار (SentryModel::markAlertAsSent).
 *
 * Idempotent: هر ستون با information_schema بررسی می‌شود.
 */

if (!function_exists('r77b_column_exists')) { // FIX-S19-4: گارد فراخوانی‌مجدد (الگوی رسمی مایگریشن‌های پروژه)
function r77b_column_exists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?"
    );
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}
}

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$pdo = $app->db()->getPdo();

$columns = [
    ['alert_rules', 'last_triggered_at', "ALTER TABLE alert_rules ADD COLUMN last_triggered_at DATETIME NULL DEFAULT NULL"],
    ['notification_history', 'alert_id', "ALTER TABLE notification_history ADD COLUMN alert_id INT UNSIGNED NULL DEFAULT NULL"],
    ['system_alerts', 'sent_at', "ALTER TABLE system_alerts ADD COLUMN sent_at DATETIME NULL DEFAULT NULL"],
];

$applied = 0;
foreach ($columns as [$table, $column, $ddl]) {
    if (!r77b_column_exists($pdo, $table, $column)) {
        $pdo->exec($ddl);
        $applied++;
        echo "{$table}.{$column} added\n";
    } else {
        echo "{$table}.{$column} already exists\n";
    }
}

echo "applied={$applied}\n";
