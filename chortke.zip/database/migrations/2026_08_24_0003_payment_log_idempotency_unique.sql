-- A payment idempotency key is a one-shot request identity. NULL remains
-- allowed for legacy rows that predate idempotency; MariaDB permits multiple NULLs.
CREATE UNIQUE INDEX uq_payment_logs_idempotency ON payment_logs (idempotency_key);
