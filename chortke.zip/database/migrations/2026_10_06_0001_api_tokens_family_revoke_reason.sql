-- ============================================================================
-- FIX-M11-R19 (گزارش سوم ماژول ۱۱ — بندهای ۲، ۵، ۱۹):
-- جداسازی چرخهٔ عمر access/refresh + خانوادهٔ توکن + دلیل ابطال
--
-- ستون‌های جدید api_tokens:
--   revoke_reason      چرا این ردیف باطل شد؟ (rotated | user_revoked | admin_revoked |
--                      expired_cleanup | role_change | password_reset |
--                      password_changed | reuse_detected | scopes_removed)
--                      FIX-M11-R22-2: فقط «rotated» امضای چرخش طبیعی RTR است؛
--                      replayِ آن یعنی سرقت. بقیهٔ دلایل → INVALID_REFRESH_TOKEN ساده.
--   family_id          شناسهٔ نسل (خانوادهٔ RTR). جفتِ چرخش‌شده همان family را
--                      می‌گیرد؛ reuse فقط همان family را باطل می‌کند، نه همهٔ
--                      توکن‌های کاربر (FIX-M11-R22-2).
--   family_started_at  لنگرِ سقف مطلق خانواده (FIX-M11-R22-5: هرگز تمدید نمی‌شود؛
--                      پس از ۳۶۵ روز از این لنگر، refresh ممکن نیست).
--   refresh_expires_at اعتبارِ مستقل refresh token (FIX-M11-R22-5: access/refresh
--                      دیگر expires_at مشترک ندارند).
--   token_type         «login» = صادرشده از /auth/token با RTR (access کوتاه‌عمر)
--                      «personal» = توکن پنل کاربر (بدون refresh؛ FIX-M11-R22-23)
--
-- Backfill محافظه‌کارانه برای ردیف‌های موجود:
--   token_type='personal' (رفتار قدیمی ۹۰روزه حفظ می‌شود)،
--   refresh_expires_at=expires_at (رفتار قدیمی: refresh تا انقضای همان ردیف)،
--   family_started_at=created_at، family_id=UUID مستقل برای هر ردیف
--   (ردیف‌های قدیمی هرکدام خانوادهٔ تک‌عضوی‌اند؛ هیچ ردیفِ قدیمی نمی‌تواند
--   باطلِ خانوادگیِ دیگری را تحریک کند).
-- ============================================================================

ALTER TABLE api_tokens
    ADD COLUMN revoke_reason VARCHAR(32) NULL DEFAULT NULL AFTER revoked_at,
    ADD COLUMN family_id CHAR(36) NULL DEFAULT NULL AFTER revoke_reason,
    ADD COLUMN family_started_at DATETIME NULL DEFAULT NULL AFTER family_id,
    ADD COLUMN refresh_expires_at DATETIME NULL DEFAULT NULL AFTER family_started_at,
    ADD COLUMN token_type VARCHAR(16) NOT NULL DEFAULT 'personal' AFTER refresh_expires_at;

UPDATE api_tokens
   SET family_id = UUID(),
       family_started_at = COALESCE(created_at, NOW()),
       refresh_expires_at = expires_at
 WHERE family_id IS NULL;

CREATE INDEX idx_api_tokens_family ON api_tokens (family_id);
CREATE INDEX idx_api_tokens_user_revoked ON api_tokens (user_id, revoked);
