-- CHORTKE MIGRATION: حذف مکانیزم dispute ناقصِ task_disputes
-- وظیفه‌ی اجتماعی مکانیزمِ چرخشِ خودکار است (یا انجام می‌شود یا رد) و بخش داوری اعتراض ندارد؛
-- لذا جدول task_disputes (که تنها open+list بود و resolve نداشت) حذف می‌شود.
-- W4-B (F-A24c-06): creator existed only outside the migration chain (legacy dump artifact, cf. F-A2-09); DROP retained for legacy installs
DROP TABLE IF EXISTS `task_disputes`;
