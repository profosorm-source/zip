-- ============================================================================
-- FIX-SEOCLICK-P1 (فاز ۱ کانال سنجش سرورمحور سئو — ریشه‌ایِ SEO-23-01)
-- ----------------------------------------------------------------------------
-- مشکل گزارش ماژول ۲۳ (SEO-23-01، شدت: بالا): دکمهٔ «باز کردن سایت هدف»
-- لینک مستقیم به سایت تبلیغ‌دهنده بود؛ سرور هیچ اثری از عبور کاربر نداشت و
-- همهٔ سیگنال‌های تعامل، ادعای کلاینت بودند. بند فوری (بستهٔ قبل) سیگنال‌های
-- ساختگی JS را حذف و سقف پاداش غیرقابل‌اثبات (60٪ بازه) گذاشت؛ این
-- مایگریشن زیرساخت فاز ۱ را می‌سازد: کلیکِ عبور از روت سرور
-- (GET /seo/{id}/out) این‌جا ثبت می‌شود و ProcessSeoTaskAsyncJob برای
-- اجراهای دارای کلیکِ سرور-ثبت‌شده، سقف را برمی‌دارد (پاداش کامل) —
-- بدون کلیک، سقف ۶۰٪ باقی می‌ماند.
--
-- فاز ۲ (توکن یک‌بارمصرف در URL مقصد + پیکسل تبلیغ‌دهنده) به همکاری طرف
-- تبلیغ‌دهنده نیاز دارد و عمداً در این بسته نیست؛ ستون nonce در فاز ۲ با
-- مایگریشن جدا اضافه می‌شود تا این جدول بدون تغییر معنا بماند.
--
-- Idempotent (CREATE TABLE IF NOT EXISTS) — هم‌الگوی مایگریشن‌های همین پوشه.
-- ============================================================================

CREATE TABLE IF NOT EXISTS `seo_task_clicks` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `execution_id` BIGINT UNSIGNED NOT NULL COMMENT 'seo_executions.id — اجرای مالک کلیک',
  `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'انجام‌دهندهٔ تسک (مالک اجرا)',
  `ad_id` BIGINT UNSIGNED NOT NULL COMMENT 'کمپین سئو',
  `ip_address` VARCHAR(45) NULL DEFAULT NULL COMMENT 'IPv4/IPv6 — تحلیل سوءاستفاده',
  `user_agent` VARCHAR(255) NULL DEFAULT NULL,
  `clicked_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_seo_clicks_execution` (`execution_id`),
  KEY `idx_seo_clicks_user` (`user_id`, `ad_id`, `clicked_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='FIX-SEOCLICK-P1: سرور-شمارش‌شدهٔ کلیک‌های «باز کردن سایت هدف» تسک سئو';
