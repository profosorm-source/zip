-- X372 (راند ۹۳ — مجری 93-b): سیم‌کشی جدول یتیم fraud_reports (گزارش تخلف کاربر + صف بررسی ادمین)
-- جدول fraud_reports از 2026_06_10_0049_missing_business_tables.sql وجود داشت اما
-- هیچ مدل/کنترلری نداشت و ستون‌های بررسی ادمین (admin_note / reviewed_by / reviewed_at)
-- و ایندکس صف (status, created_at) در اسکیمای اولیه نبودند.
-- ۰ ردیف زنده → ALTER بدون ریسک؛ اجرای مجدد idempotent است (ردیابی در schema_migrations).

ALTER TABLE `fraud_reports`
    ADD COLUMN `admin_note` VARCHAR(1000) NULL AFTER `status`,
    ADD COLUMN `reviewed_by` INT(10) UNSIGNED NULL AFTER `admin_note`,
    ADD COLUMN `reviewed_at` TIMESTAMP NULL DEFAULT NULL AFTER `reviewed_by`;

-- ایندکس صف ادمین + پنجرهٔ آمار ۳۰روزه (KpiStatistics::getFraudStats و FraudReport::monthlyStats)
ALTER TABLE `fraud_reports`
    ADD KEY `idx_fraud_reports_status_created` (`status`, `created_at`);
