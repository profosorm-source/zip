-- ─────────────────────────────────────────────────────────────────────────────
-- FIX-S19-VFP: اتصال VideoFingerprintService به چرخهٔ ارسال مدرک تسک
--
-- پیشینه (تحقیق dead-file طبق دستور کارفرما):
--   سرویس VideoFingerprintService از تولد در کدبیس اصلی یتیم مطلق بود
--   (صفر caller در app/ و tests/)؛ زیرساختش آماده بود (جدول video_fingerprints
--   در 2026_06_10_0047_infrastructure_missing.sql ساخته می‌شود) ولی integration
--   هرگز کامل نشد. جایگزینِ ناقصِ موجود فقط match دقیقِ string در همانِ یک تسک
--   بود (SubmitProofJob::checkDuplicateProof) ⇒ استفادهٔ cross-task از یک ویدیو
--   (کش ریفرد) نامرئی بود و با variant های سادهٔ URL (پروتکل/www/حروف/پارامتر)
--   هم قابل دورزدن بود.
--
-- این patch: ستون proof_url_hash اثر انگشت نرمال‌شدهٔ proof_url (محصول
-- VideoFingerprintService) را روی رکورد submission لنگر می‌کند تا گیت
-- cross-task با یک SELECT ایندکس‌شده قابل اجرا باشد.
--
-- سازگاری با دادهٔ موجود: ردیف‌های قبلی proof_url_hash = NULL می‌گیرند و
-- گیت فقط ردیف‌های hash دار را مقایسه می‌کند (fail-open برای دادهٔ قدیمی).
-- ─────────────────────────────────────────────────────────────────────────────
ALTER TABLE `custom_task_submissions`
    ADD COLUMN `proof_url_hash` CHAR(64) NULL DEFAULT NULL,
    ADD KEY `idx_proof_url_hash` (`proof_url_hash`);
