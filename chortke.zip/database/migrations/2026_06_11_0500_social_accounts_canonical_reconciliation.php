<?php

declare(strict_types=1);

/**
 * ═══════════════════════════════════════════════════════════════════
 * FIX-DB-02 (راند ۱۲) — بازسازی canonical جدول social_accounts با
 * انتقال داده از شکل legacy
 * ═══════════════════════════════════════════════════════════════════
 *
 * پیشینه: 2026_04_28_0001 جدول social_accounts را با قرارداد OAuth می‌سازد
 * (provider enum, provider_id, provider_email, provider_name, data JSON,
 * user_id BIGINT UNSIGNED). سپس 2026_06_10_0020 همان جدول را DROP و با
 * قرارداد کاملاً متفاوت (platform, username, provider_id, avatar, status,
 * user_id INT UNSIGNED) بازمی‌سازد — هدف جدول از «هویت OAuth» به «حساب
 * اجتماعی/پروفایل» تغییر کرده و مسیر OAuth به ستون‌های کانونی همین جدول
 * نوشته می‌شود (LinkSocialAccountJob: platform/username/provider_id +
 * UNIQUE(platform, provider_id) از 2026_09_20_0006).
 *
 * خطر: روی DB داده‌دار، گارد destructive جدولِ populated را skip می‌کند
 * (DROP نویز drift می‌گیرد) و CREATE بعدی با 1050 idempotent رد می‌شود؛
 * نتیجه: جدول با شکل legacy می‌ماند درحالی‌که کدِ اپ ستون‌های canonical را
 * می‌خواهد → خطای unknown column و شکست OAuth/سوشال. مهاجرت‌های بعدی که
 * ستون‌های جدید را ALTER می‌کنند (مثل 2026_09_20_0006) هم روی شکل legacy
 * می‌شکنند و زنجیره نیمه‌کاره می‌ماند — پس این reconciliation باید «قبل از»
 * اولین مصرف‌کنندهٔ ستون‌های جدید اجرا شود؛ جایگاه نام فایل (2026_06_11)
 * بلافاصله پس از 2026_06_10_0020 و قبل از هر ALTER بعدی است.
 *
 * رفتار:
 *   ۱) اگر ستون platform موجود است → شکل canonical → no-op تمیز.
 *   ۲) اگر ستون provider نیست → جدول اصلاً وجود ندارد → no-op.
 *   ۳) شکل legacy:
 *      الف) بکاپ کامل قابل‌ممیزی: social_accounts_legacy_bak (CREATE LIKE +
 *           INSERT SELECT) — ریکاوری و audit.
 *      ب) ساخت جدول canonical در نام موقت، انتقال ردیف‌ها با نگاشت معنایی:
 *           platform     ← provider (enum google/facebook)
 *           username     ← provider_email، وگرنه provider_name، وگرنه
 *                          'user_' . provider_id (ستون NOT NULL است)
 *           provider_id  ← provider_id
 *           avatar       ← NULL (legacy معادل ندارد)
 *           status       ← 'active'
 *           created_at   ← COALESCE(created_at, linked_at)
 *         تداخل (platform, provider_id) با INSERT ... ON DUPLICATE KEY
 *         UPDATE id=id خنثی می‌شود (الگوی keep-first).
 *      ج) RENAME TABLE اتمیک: social_accounts → tmp_swap، canonical →
 *         social_accounts؛ سپس DROP جدول legacy (که هم‌نام swap شده) با
 *         نگه‌داشتن بکاپ مستقل در بند (الف).
 *
 * این migration منطق شرطی دارد و به همین دلیل PHP است؛ هیچ عملیات مخربی
 * بدون بکاپ قبلی انجام نمی‌شود.
 */
final class SocialAccountsCanonicalReconciliation
{
    public function up(\Core\Database $db): void
    {
        $tableName = 'social_accounts';

        $hasColumn = static function (string $column) use ($db, $tableName): bool {
            try {
                $cnt = $db->fetchColumn(
                    'SELECT COUNT(*) FROM information_schema.COLUMNS'
                    . ' WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?',
                    [$tableName, $column]
                );
            } catch (\Throwable) {
                // نبود دسترسی به کاتالوگ = تصمیم امن: دخالت نکن
                return false;
            }
            return (int) ($cnt ?? 0) > 0;
        };

        // ۱) شکل canonical یا جدول غایب → هیچ
        if ($hasColumn('platform') || !$hasColumn('provider')) {
            return;
        }

        // ۲) بکاپ کامل قابل‌ممیزی (شامل همهٔ ستون‌های legacy)
        $db->execute('DROP TABLE IF EXISTS `social_accounts_legacy_bak`');
        $db->execute('CREATE TABLE `social_accounts_legacy_bak` LIKE `social_accounts`');
        $db->execute('INSERT INTO `social_accounts_legacy_bak` SELECT * FROM `social_accounts`');

        // ۳) جدول canonical (شکل خروجی نهایی زنجیره: 2026_06_10_0020 + قید
        //    2026_09_20_0006 با همان نام uniq_sa_platform_provider + FK
        //    9999_0001؛ در DBهایی که آن‌ها بعداً اجرا شوند، 1061/1826
        //    idempotent رد می‌شود)
        $db->execute('DROP TABLE IF EXISTS `social_accounts_rebuild_tmp`');
        $db->execute(<<<'SQL'
CREATE TABLE `social_accounts_rebuild_tmp` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `platform` VARCHAR(50) NOT NULL,
    `username` VARCHAR(100) NOT NULL,
    `provider_id` VARCHAR(191) NULL,
    `avatar` VARCHAR(255) NULL,
    `status` VARCHAR(20) DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_sa_user` (`user_id`),
    UNIQUE KEY `uniq_sa_platform_provider` (`platform`, `provider_id`),
    CONSTRAINT `fk_social_accounts_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

        // ۴) انتقال با نگاشت معنایی (keep-first برای تداخل قید یکتایی)
        $db->execute(<<<'SQL'
INSERT INTO `social_accounts_rebuild_tmp`
    (`user_id`, `platform`, `username`, `provider_id`, `avatar`, `status`, `created_at`)
SELECT
    `user_id`,
    `provider`,
    COALESCE(NULLIF(`provider_email`, ''), NULLIF(`provider_name`, ''), CONCAT('user_', `provider_id`)),
    `provider_id`,
    NULL,
    'active',
    COALESCE(`created_at`, `linked_at`, CURRENT_TIMESTAMP)
FROM `social_accounts`
ON DUPLICATE KEY UPDATE `social_accounts_rebuild_tmp`.`id` = `social_accounts_rebuild_tmp`.`id`
SQL);

        // ۵) تعویض اتمیک؛ DROP ردیف‌های legacy پس از بکاپ مستقل بند (۲)
        $db->execute('RENAME TABLE `social_accounts` TO `social_accounts_old_shape_tmp`, `social_accounts_rebuild_tmp` TO `social_accounts`');
        $db->execute('DROP TABLE `social_accounts_old_shape_tmp`');
    }
}

return new SocialAccountsCanonicalReconciliation();
