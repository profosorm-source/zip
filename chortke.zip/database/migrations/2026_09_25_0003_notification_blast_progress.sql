-- =============================================================================
-- FIX-A6-F4 — جدول پیشرفت پایدار blast اعلان‌ها (Audit Task 6-a)
-- =============================================================================
--
-- پیشینه (Audit R6-F4): SendToAllNotificationJob / SendToSegmentNotificationJob
-- پیش از حلقهٔ دسته‌ها فقط یک claim ده‌دقیقه‌ای در کش می‌گرفتند؛ پیشرفتِ blast
-- پایدار نبود. شکست نیمهٔ راه → retry → claim موجود → «deduped»Instant →
-- کاربرانِ باقی‌مانده هرگز پردازش نمی‌شدند.
--
-- راه‌حل: هر blast با کلید پایدار خود (hash محتوای payload — همان ریشهٔ
-- claimKey) یک ردیف پیشرفت دارد:
--   * status='running' + last_user_id = cursor پایدار (بعد از هر batch آپدیت)
--   * retry → ردیف موجود (غیر completed) → حلقه از last_user_id ادامه می‌یابد
--   * اتمام موفق → status='completed' → اجرای دوبارهٔ همان payload = dedup
--     (رفتار FIX-R18-M10، اما اکنون پایدار و دقیق: فقط blastهای «تمام‌شده»
--     dedup می‌شوند، نه blastهای نیمه‌کاره)
--   * شکست → status='failed' + claim کش آزاد → retry فوری از cursor
--
-- blast_key کلید اصلی است (hash('sha256') = ۶۴ کاراکتر hex).
-- =============================================================================

CREATE TABLE IF NOT EXISTS `notification_blast_progress` (
    `blast_key`    VARCHAR(80)  NOT NULL,
    `last_user_id` INT(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'cursor پایدار: آخرین user_id پردازش‌شده',
    `batches_done` INT(10) UNSIGNED NOT NULL DEFAULT 0,
    `total_sent`   INT(10) UNSIGNED NOT NULL DEFAULT 0,
    `status`       ENUM('running','completed','failed') NOT NULL DEFAULT 'running',
    `created_at`   TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`blast_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
