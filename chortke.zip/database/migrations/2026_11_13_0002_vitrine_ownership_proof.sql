-- اثبات مالکیت حساب: خریدارِ پذیرفته‌شده از فروشنده می‌خواهد کد یکتای آگهی را در بیو/توضیحات
-- حساب قرار دهد؛ فروشنده پس از قرار دادن، تأیید می‌کند و خریدار خودش بررسی می‌کند.
ALTER TABLE `vitrine_listings`
  ADD COLUMN IF NOT EXISTS `ownership_code` VARCHAR(24) NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `ownership_proof_requested_at` DATETIME NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `ownership_proof_ready_at` DATETIME NULL DEFAULT NULL;

-- هر آگهی یک کد ثابت دارد؛ برای آگهی‌های موجود یک‌بار صادر می‌شود.
UPDATE `vitrine_listings`
   SET `ownership_code` = CONCAT('CHK-', UPPER(SUBSTRING(MD5(CONCAT(`id`, RAND(), UUID())), 1, 8)))
 WHERE `ownership_code` IS NULL;
