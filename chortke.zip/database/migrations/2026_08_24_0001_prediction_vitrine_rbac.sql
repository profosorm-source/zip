-- RBAC for admin prediction/vitrine routes.
-- support deliberately receives read-only access, never settlement/escrow mutations.
INSERT IGNORE INTO permissions (name, slug, group_name, description, created_at, updated_at) VALUES
 ('پیش‌بینی — مشاهده','prediction.view','prediction','View prediction administration',NOW(),NOW()),
 ('پیش‌بینی — مدیریت','prediction.manage','prediction','Create/update/close prediction games',NOW(),NOW()),
 ('پیش‌بینی — تسویه','prediction.settle','prediction','Settle prediction winners',NOW(),NOW()),
 ('پیش‌بینی — بازپرداخت','prediction.refund','prediction','Cancel and refund prediction games',NOW(),NOW()),
 ('ویترین — مشاهده','vitrine.view','vitrine','View vitrine administration',NOW(),NOW()),
 ('ویترین — مدیریت','vitrine.manage','vitrine','Approve/reject and change vitrine settings',NOW(),NOW()),
 ('ویترین — حل اختلاف','vitrine.dispute','vitrine','Resolve vitrine disputes',NOW(),NOW()),
 ('ویترین — مالی','vitrine.finance','vitrine','Release or refund vitrine escrow',NOW(),NOW());

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p
WHERE r.slug IN ('admin','super_admin') AND p.slug IN
('prediction.view','prediction.manage','prediction.settle','prediction.refund','vitrine.view','vitrine.manage','vitrine.dispute','vitrine.finance');

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p
WHERE r.slug='support' AND p.slug IN ('prediction.view','vitrine.view');
