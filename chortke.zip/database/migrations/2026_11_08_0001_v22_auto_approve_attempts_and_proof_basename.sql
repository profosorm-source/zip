-- 🛡️ FIX-V22 (بچ بازمانده‌های بازبینی ۲۲ — ۲۰۲۶-۱۱-۰۸): دو تغییر schema روی
-- custom_task_submissions — V22-03c (ضدگرسنگی sweep) + V22-04a (ایندکس‌پذیری مالکیت مدرک).
--
-- V22-03c: sweep ساعتی تأیید خودکار (CronSubmissionsJob::autoApproveOldSubmissions) با
-- «ORDER BY submitted_at ASC LIMIT 200» کار می‌کرد؛ ردیف‌هایی که همیشه شکست می‌خورند
-- (مثلاً escrow گمشدهٔ legacy، یا گارد دوبل‌پرداختِ T22-07) در ابتدای صف می‌ماندند و
-- در بک‌لاگ‌های بزرگ می‌توانستند ردیف‌های سالمِ جدیدتر را گرسنه کنند. ستون شمارندهٔ
-- auto_approve_attempts + ORDER BY attempts ASC ردیف‌های شکست‌خورده را به انتهای صف
-- می‌فرستد و سقف پارک (۱۰ = CustomTaskSubmissionModel::AUTO_APPROVE_PARK_THRESHOLD)
-- آن‌ها را از صف حذف می‌کند (لاگ error یک‌بار در CronSubmissionsJob).
--
-- V22-04a: FileAccess::checkTaskProofOwnership قبلاً با
-- SUBSTRING_INDEX(proof_file, '/', -1) در WHERE مالکیت مدرک را چک می‌کرد — عبارت
-- غیرقابل ایندکس ⇒ هر بازدید مدرک یک full-table-scan روی custom_task_submissions.
-- ستون generated هم‌ارزش + ایندکس آن، مقایسه را O(log n) می‌کند (کوئری FileAccess
-- به proof_file_basename = ? مهاجرت کرده است).
--
-- ستون generated عمداً VIRTUAL است (قرارداد پروژه — الگوی 2026_10_03_0003 و
-- rewriteForMysql ④): افزودن ستون STORED به جدول دارای FK با اکشن CASCADE/SET NULL
-- در InnoDB با errno 1215 شکست می‌خورد و MariaDB 11.8 همین‌جا هم سینتکس STORED را در
-- این ترکیب رد می‌کند؛ ایندکس ثانویه روی ستون VIRTUAL در MariaDB کاملاً معتبر است
-- (تأیید مستقیم روی MariaDB 11.8.6: KEY=MUL روی proof_file_basename) و پرهزینهٔ
-- ذخیره‌سازی هم ندارد.

-- ۱) شمارندهٔ شکست‌های متوالی auto-approve (پیش از auto_approved_at)
ALTER TABLE `custom_task_submissions`
  ADD COLUMN IF NOT EXISTS `auto_approve_attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0
    COMMENT 'FIX-V22-03c: شکست‌های متوالی auto-approve؛ ۱۰ = پارک (خارج از sweep)' AFTER `auto_approved_at`;

ALTER TABLE `custom_task_submissions`
  ADD INDEX IF NOT EXISTS `idx_cts_auto_approve_attempts` (`auto_approve_attempts`);

-- ۲) basename ایندکس‌پذیر مدرک (هم‌ارزش SUBSTRING_INDEX(proof_file,'/',-1) — DB نگه می‌دارد)
ALTER TABLE `custom_task_submissions`
  ADD COLUMN IF NOT EXISTS `proof_file_basename` VARCHAR(96)
    GENERATED ALWAYS AS (SUBSTRING_INDEX(`proof_file`, '/', -1)) VIRTUAL
    COMMENT 'FIX-V22-04a: basename مدرک برای چک مالکیت ایندکس‌پذیر FileAccess' AFTER `proof_file`;

ALTER TABLE `custom_task_submissions`
  ADD INDEX IF NOT EXISTS `idx_cts_proof_file_basename` (`proof_file_basename`);
