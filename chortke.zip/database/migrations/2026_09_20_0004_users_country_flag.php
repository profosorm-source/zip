<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-R16A (Task 16-A) — ستون users.country_flag + backfill پرچم
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه (یافتهٔ بازبینی: «country_flag ذخیره‌نشدن»): UserService::register
// از دورهای قبل $data['country_flag'] را از کد ISO می‌سازد، اما:
//   ۱) جدول users ستونی به نام country_flag ندارد؛
//   ۲) User::$fillable هم شامل آن نبود ⇒ مقدار هرگز persist نمی‌شد.
// این مایگریشن ستون را اضافه می‌کند (idempotent — الگوی information_schema)
// و برای کاربران موجودِ بدون flag، ایموجی پرچم را از country_code موجود
// backfill می‌کند (رفع مشکل «resolve+save for existing users where possible» —
// کد کشورِ آن‌ها از قبل ذخیره شده؛ برای کدهای نامعتبر/ناشناس مثل XX و برای
// کاربران با IP محلی که resolve نشده‌اند، NULL می‌ماند و UI placeholder 🌐
// نشان می‌دهد).
//
// نمایش: helper country_flag_emoji() (helpers/functions.php) ایموجی را از
// کد ISO می‌سازد؛ DB کد ISO را منبع حقیقت نگه می‌دارد و country_flag برای
// مصارف مستقیم (data-export/جداول ادمین) ذخیره می‌شود.

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r16a_country_flag_column_exists')) {
    function r16a_country_flag_column_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE()
               AND table_name = 'users'
               AND column_name = 'country_flag'"
        );
        $stmt->execute();
        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r16a_country_flag_emoji')) {
    /** ایموجی پرچم از کد ISO ۳۱۶۶-۱ آلفا-۲ ( Regional Indicator Symbols ) */
    function r16a_country_flag_emoji(string $code): ?string
    {
        $code = strtoupper(trim($code));
        if (preg_match('/^[A-Z]{2}$/', $code) !== 1) {
            return null;
        }
        $c1 = mb_ord($code[0]) + 127397;
        $c2 = mb_ord($code[1]) + 127397;
        return html_entity_decode("&#{$c1};&#{$c2};", ENT_HTML5, 'UTF-8');
    }
}

if (!function_exists('r16a_country_flag_log')) {
    function r16a_country_flag_log(string $msg): void
    {
        echo '[r16a-users-country-flag] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.r16a_users_country_flag', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

if (r16a_country_flag_column_exists($db)) {
    r16a_country_flag_log('SKIP: ستون users.country_flag از قبل وجود دارد (idempotent).');
    return;
}

$db->exec(
    "ALTER TABLE `users`
     ADD COLUMN `country_flag` VARCHAR(16) NULL DEFAULT NULL AFTER `country_name`"
);
r16a_country_flag_log('OK: ستون users.country_flag VARCHAR(16) NULL اضافه شد.');

// Backfill: از کد ISO موجودِ هر کاربر (منبع حقیقت)، پرچم بساز.
// کدهای نامعتبر (NULL/خالی/XX) دست‌نخورده NULL می‌مانند → placeholder 🌐.
$updated = 0;
$users = $db->query("SELECT id, country_code FROM users WHERE country_flag IS NULL")->fetchAll(PDO::FETCH_ASSOC);
$updateStmt = $db->prepare("UPDATE users SET country_flag = ? WHERE id = ?");
foreach ($users as $u) {
    $emoji = r16a_country_flag_emoji((string)($u['country_code'] ?? ''));
    if ($emoji === null) {
        continue;
    }
    $updateStmt->execute([$emoji, (int)$u['id']]);
    $updated++;
}
r16a_country_flag_log("OK: backfill پرچم برای {$updated} کاربر از country_code موجود انجام شد (کل کاربران: " . count($users) . ").");
