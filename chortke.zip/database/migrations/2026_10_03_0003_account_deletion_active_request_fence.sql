-- ═══════════════════════════════════════════════════════════════════
-- S7-FIX (DEL-003) — حصار یکتای «درخواستِ فعالِ حذف» برای هر کاربر
-- ═══════════════════════════════════════════════════════════════════
-- پیشینه (گزارش ممیزی بخش ۷): createDeletionRequest قفلِ SELECT ... FOR UPDATE
-- + insert دارد، اما «نبودِ ردیف قبلی» بدون قیدِ یکتا حصارِ قطعی نیست؛ در
-- READ COMMITTED (یا هر چیدمانی که gap-lock absent-row را به تبدیلِ claim
-- یکتا نکند) دو درخواستِ هم‌زمان می‌توانند دو ردیف 'requested' برای یک user بسازند.
--
-- راه‌حل معادل partial unique index در MySQL/MariaDB: ستونِ generated مجازی
-- active_request_key که فقط برای status='requested' برابر user_id است و برای
-- سایر وضعیت‌ها NULL (NULLها در unique index محدودیتی ندارند) + UNIQUE KEY.
-- نتیجه: حداکثر یک ردیفِ requested فعال برای هر user در سطح خودِ موتور ذخیره.
--
-- رقابتِ هم‌زمان: بازنده PDOException 1062 می‌گیرد که مدل آن را به قراردادِ
-- RuntimeException('Deletion request already exists') ترجمه می‌کند
-- (AccountDeletionLog::createDeletionRequestInTx).
--
-- Idempotent: اجرای مجدد با طبقه‌بندِ idempotencyِ runner (1060 duplicate column
-- / 1061 duplicate key) سازگار است.

ALTER TABLE `account_deletion_logs`
    ADD COLUMN `active_request_key` INT UNSIGNED
        GENERATED ALWAYS AS (CASE WHEN `status` = 'requested' THEN `user_id` ELSE NULL END) VIRTUAL;

ALTER TABLE `account_deletion_logs`
    ADD UNIQUE KEY `uq_adl_active_request` (`active_request_key`);
