-- T25-01: مهلت انتشار پس از پذیرش سفارش اینفلوئنسر + شمارش تخلف عدم‌انتشار (جریمه پلکانی)
-- accepted_at / publish_deadline_at: زمان پذیرش و مهلت انتشار؛ publish_missed_at: ثبت تخلف عدم انتشار.
ALTER TABLE `story_orders`
  ADD COLUMN IF NOT EXISTS `accepted_at` DATETIME NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `publish_deadline_at` DATETIME NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `publish_missed_at` DATETIME NULL DEFAULT NULL;

ALTER TABLE `story_orders`
  ADD INDEX IF NOT EXISTS `idx_story_orders_publish_deadline` (`status`, `publish_deadline_at`),
  ADD INDEX IF NOT EXISTS `idx_story_orders_publish_missed` (`influencer_user_id`, `publish_missed_at`);

-- سفارش‌های accepted قدیمی بدون مهلت: ۴۸ ساعت مهلت از لحظهٔ اجرای مایگریشن (ارفاق یک‌باره)
UPDATE `story_orders`
   SET `accepted_at` = COALESCE(`accepted_at`, `updated_at`, NOW()),
       `publish_deadline_at` = DATE_ADD(NOW(), INTERVAL 48 HOUR)
 WHERE `status` = 'accepted' AND `publish_deadline_at` IS NULL;
