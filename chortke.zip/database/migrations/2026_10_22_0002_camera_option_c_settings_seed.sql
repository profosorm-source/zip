-- ============================================================================
-- F21-01 — Camera Verifier Trust Chain (Option C) — 2026-10-22 / rebuild 2026-10-24
-- گام ۲ از ۲: seed تنظیمات پنل برای زنجیرهٔ اعتماد دوربین
-- ----------------------------------------------------------------------------
-- جدول مرجع: system_settings (مدل Setting و کاتالوگ X305/X306 و پنل ادمین
-- همگی همان جدول را می‌خوانند؛ AppSettings::load نیز بر همین است).
-- چهار کلید جدید در گروهِ task (همان تب کاتالوگ SettingsCatalog که
-- camera_verification_expiry و camera_signal_bonus در آن‌اند):
--   * camera_spot_check_ratio  — نسبت نمونه‌گیری D1 (پیش‌فرض 0.2 = ۲۰٪)
--   * camera_retention_days    — مهلت نگهداری رکوردها برای پاکسازی V7 (۳۰ روز)
--   * play_integrity_enabled   — کلید D3 (پیش‌فرض خاموش؛ بدون کلید تزئینی است)
--   * play_integrity_api_key   — کلید سرور Google Play Integrity (نوع secret)
-- قانون طلایی کاتالوگ: seed رفتار سیستم را تغییر نمی‌دهد؛ consumeکننده‌ها
-- همان پیش‌فرض را در کد نیز دارند.
-- idempotent: INSERT ... WHERE NOT EXISTS (بدون دست‌زدن به ردیف موجود).
-- ============================================================================

INSERT INTO `system_settings` (`key`, `value`, `group`, `type`, `description`, `is_public`)
SELECT 'camera_spot_check_ratio', '0.5', 'task', 'number', 'نسبت نمونه‌گیری spot-check دوربین (۰ تا ۱؛ دورهٔ اول ۰.۵ — برای برگشت به حالت عادی ۰.۲ یعنی ۲۰٪ چالش‌ها عکس تأییدی می‌خواهند)', 0
WHERE NOT EXISTS (SELECT 1 FROM `system_settings` WHERE `key` = 'camera_spot_check_ratio');

INSERT INTO `system_settings` (`key`, `value`, `group`, `type`, `description`, `is_public`)
SELECT 'camera_retention_days', '30', 'task', 'number', 'مهلت نگهداری رکوردهای راستی‌آزمایی دوربین (روز) — پاکسازی خودکار با system:cleanup', 0
WHERE NOT EXISTS (SELECT 1 FROM `system_settings` WHERE `key` = 'camera_retention_days');

INSERT INTO `system_settings` (`key`, `value`, `group`, `type`, `description`, `is_public`)
SELECT 'play_integrity_enabled', '0', 'task', 'boolean', 'فعال‌سازی بررسی Play Integrity گوگل در وریفای دوربین (تقویت‌گر؛ بدون کلید اثری ندارد)', 0
WHERE NOT EXISTS (SELECT 1 FROM `system_settings` WHERE `key` = 'play_integrity_enabled');

INSERT INTO `system_settings` (`key`, `value`, `group`, `type`, `description`, `is_public`)
SELECT 'play_integrity_api_key', '', 'task', 'secret', 'کلید سرور Google Play Integrity API — بدون آن بررسی attestation تزئینی است', 0
WHERE NOT EXISTS (SELECT 1 FROM `system_settings` WHERE `key` = 'play_integrity_api_key');

INSERT INTO `system_settings` (`key`, `value`, `group`, `type`, `description`, `is_public`)
SELECT 'camera_pass_audit_ratio', '0.05', 'task', 'number', 'نسبت بازبینی تصادفی ادمین برای اجراهای pass دوربین (۰.۰۵ = ۵٪؛ صفر = غیرفعال)', 0
WHERE NOT EXISTS (SELECT 1 FROM `system_settings` WHERE `key` = 'camera_pass_audit_ratio');

INSERT INTO `system_settings` (`key`, `value`, `group`, `type`, `description`, `is_public`)
SELECT 'camera_pass_daily_limit', '10', 'task', 'number', 'سقف pass دوربین برای هر کاربر در ۲۴ ساعت؛ بیش از آن به بررسی دستی می‌رود (صفر = غیرفعال)', 0
WHERE NOT EXISTS (SELECT 1 FROM `system_settings` WHERE `key` = 'camera_pass_daily_limit');
