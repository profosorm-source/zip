-- ═══════════════════════════════════════════════════════════════════
-- FIX-M10 (گزارش ماژول ۱۰) — مهاجرت‌های لازم برای یافته‌های ۳، ۴ و ۱
-- ═══════════════════════════════════════════════════════════════════
-- ① FIX-M10-04: مجوزِ مستقلِ «kyc.pii» — دسترسی به کد ملی/تاریخ تولدِ
--   رمزگشایی‌شده و فایلِ مدرک در صفحهٔ review. فقط reviewerهای ممتاز
--   (admin/super_admin) — نقشِ view-only (support) فاقد این مجوز است.
--   (admin.export.users جزو مجوزهای سطح super_admin در گیتِ تفویض است.)
-- ② FIX-M10-01: گسترشِ enum وضعیت با 'expired' — job انقضا می‌تواند
--   ردیف‌های verified منقضی‌شده را علامت بزند.
-- ③ FIX-M10-03: registry کد ملی با claim اتمیک در لحظهٔ تأیید — دو حساب
--   نمی‌توانند هم‌زمان یک کد ملی را verified کنند.
-- ═══════════════════════════════════════════════════════════════════

-- ① مجوز kyc.pii + تخصیص به admin و super_admin
INSERT INTO permissions (group_name, name, slug, description, created_at, updated_at)
SELECT 'kyc', 'مشاهدهٔ PII مقیِ احراز هویت', 'kyc.pii',
       'دسترسی به کد ملی و تاریخ تولد رمزگشایی‌شده و تصویر مدرک در صفحهٔ بررسی KYC', NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'kyc.pii');

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
JOIN permissions p ON p.slug = 'kyc.pii'
WHERE r.slug IN ('admin', 'super_admin') AND r.deleted_at IS NULL;

-- ② گسترش enum وضعیت KYC با 'expired'
ALTER TABLE kyc_verifications
    MODIFY COLUMN `status` ENUM('pending','under_review','verified','rejected','expired')
    NOT NULL DEFAULT 'pending';

-- ③ registry کد ملی — claim اتمیک در verify (FIX-M10-03)
CREATE TABLE IF NOT EXISTS kyc_national_code_registry (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    national_code_hash CHAR(64) NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    kyc_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_ncr_hash (national_code_hash),
    KEY idx_ncr_user (user_id),
    KEY idx_ncr_kyc (kyc_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
