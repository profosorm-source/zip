-- =====================================================
-- FIX (S-M review round 8-e) — ساخت جدول daily_statistics
--
-- هر دو cron شبانه/دوره‌ای روی این جدول INSERT..ON DUPLICATE می‌زنند
-- ولی جدول هرگز ساخته نشده بود → هر شب خطای 1146 (Table doesn't exist):
--   1) storage/cron/sentry-monitor.php (بخش ۴، نیمه‌شب):
--      (stat_date, total_errors, critical_errors, total_requests,
--       slow_requests, avg_response_time, unique_users)
--   2) storage/cron/cron_alert_checker.php → updateDailyStatistics():
--      (stat_date, total_errors, critical_errors, total_requests,
--       slow_requests, avg_response_time, security_incidents,
--       unique_users, peak_memory) + updated_at = NOW() در شاخهٔ UPDATE
--
-- ستون‌ها دقیقاً مطابق نویسنده‌ها + UNIQUE(stat_date) تا
-- ON DUPLICATE KEY UPDATE هر دو نویسنده fire شود.
-- =====================================================

CREATE TABLE IF NOT EXISTS `daily_statistics` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `stat_date` DATE NOT NULL,
    `total_errors` INT UNSIGNED NOT NULL DEFAULT 0,
    `critical_errors` INT UNSIGNED NOT NULL DEFAULT 0,
    `total_requests` INT UNSIGNED NOT NULL DEFAULT 0,
    `slow_requests` INT UNSIGNED NOT NULL DEFAULT 0,
    `avg_response_time` DECIMAL(14,4) NOT NULL DEFAULT 0,
    `security_incidents` INT UNSIGNED NOT NULL DEFAULT 0,
    `unique_users` INT UNSIGNED NOT NULL DEFAULT 0,
    `peak_memory` BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_daily_statistics_stat_date` (`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='آمار روزانهٔ پلتفرم — نوشته توسط cronهای sentry-monitor و cron_alert_checker';
