-- FIX-X7 (Task 11): جدول coupons ستون created_by نداشت، در حالی که
-- App\Models\Coupon::$fillable و AdminCouponController::store() آن را مقداردهی
-- می‌کردند → هر INSERT کوپن با "Unknown column 'created_by'" شکست می‌خورد و
-- امکان ساخت کوپن از پنل ادمین صفر بود.
ALTER TABLE coupons ADD COLUMN IF NOT EXISTS created_by INT UNSIGNED NULL AFTER usage_count;
