-- FIX-X87: ستون task_type برای task_reports — INSERT اینفلوئنسر
-- (InfluencerCommandService::reportOrder) ستون task_type را می‌نویسد ولی
-- ستون وجود نداشت → هر گزارش سفارش اینفلوئنسر SQL error و «خطا در ثبت گزارش».
-- مقدار پیش‌فرض 'custom_task' برای ردیف‌های قدیمی و سازگاری معنایی reviewReport.
ALTER TABLE task_reports
    ADD COLUMN task_type VARCHAR(30) NOT NULL DEFAULT 'custom_task' AFTER task_id,
    ADD INDEX idx_task_reports_type (task_type);
