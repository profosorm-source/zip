-- FIX-S36-B15-S09 (گزارش بخش ۱۵ — اسکرو و اختلاف‌ها): backfill قابل ممیزی
-- peer_deadline برای پرونده‌های open_peer قدیمی که بدون مهلت درج شده بودند.
-- پیش از این، buyerDispute اینفلوئنسر ردیف را با peer_deadline=NULL می‌ساخت و
-- پردازش خودکار فقط peer_deadline < NOW() را انتخاب می‌کرد ⇒ چنین پرونده‌هایی
-- هرگز وارد صف ارجاع خودکار نمی‌شدند. سیاست مهلت: +۴۸ ساعت از created_at
-- (هم‌سیاست openCustomTaskDispute در DisputeCommandService).
-- نکتهٔ idempotency: اجرای مجدد بی‌اثر است (فقط ردیف‌های NULL را لمس می‌کند).

UPDATE disputes
SET peer_deadline = DATE_ADD(COALESCE(created_at, NOW()), INTERVAL 48 HOUR)
WHERE status = 'open_peer'
  AND peer_deadline IS NULL;
