-- FIX-X14 (Task 13): فیلدهای type/duration_days/prize_description فرم ساخت
-- دورهٔ لاتاری ادمین (views/admin/lottery/create.php) توسط LotteryRoundRequest
-- اعتبارسنجی می‌شوند ولی ستون‌هایشان در جدول lottery_rounds وجود نداشت →
-- یا باید از فرم حذف می‌شدند یا ذخیره نمی‌شدند (فیلدهای UI بی‌مصرف —
-- آیتم باز X9-باقی‌مانده در worklog Task 12). این مایگریشن ستون‌ها را
-- اضافه می‌کند و کنترلر whitelist را نیز به‌روزرسانی شده است.
ALTER TABLE lottery_rounds
    ADD COLUMN IF NOT EXISTS `type` VARCHAR(20) NOT NULL DEFAULT 'weekly' AFTER `currency`,
    ADD COLUMN IF NOT EXISTS `duration_days` INT UNSIGNED NOT NULL DEFAULT 7 AFTER `type`,
    ADD COLUMN IF NOT EXISTS `prize_description` VARCHAR(500) NULL DEFAULT NULL AFTER `prize_amount`;
