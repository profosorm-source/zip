<?php
// FIX (راند ۷۵): ۹ ستون جاافتادهٔ user_social_accounts — جدول از مایگریشن
// 2026_06_10_0040 بدون این ستون‌ها ساخته شده بود، اما دو نویسندهٔ محصول
// (SocialAccount::createAccount و ProfileService::addSocialAccount) هر ۹ ستون را
// INSERT می‌کنند و SocialAccountService::verify/reject هم verified_by/verified_at/
// rejection_reason/rejection_history را UPDATE می‌کنند.
//
// نتیجهٔ وضعیت قبلی: «Unknown column» در ثبت حساب اجتماعی (هر دو مسیر کاربر و
// پروفایل)، شکست تایید/رد ادمین، و SELECT ... WHERE is_active = 1 در
// getVerifiedByUser که حسابِ تاییدشده را هم هرگز برنمی‌گرداند (باگ is_active).
//
// is_active با DEFAULT 1 ساخته می‌شود تا حساب‌های موجود (شامل pending/verified)
// فعال در نظر گرفته شوند؛ فیلد «غیرفعال‌سازی» آگاهانه برای آینده می‌ماند.
// این فایل کاملاً idempotent است. Generated: 2026-09-05

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r75_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r75_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

$table = 'user_social_accounts';

/** @var array<string, string> $columns نام ستون → DDL کامل (به‌ترتیب فیزیکی) */
$columns = [
    'following_count'    => "ADD COLUMN `following_count` INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `follower_count`",
    'post_count'         => "ADD COLUMN `post_count` INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `following_count`",
    'engagement_rate'    => "ADD COLUMN `engagement_rate` DECIMAL(6,2) NOT NULL DEFAULT 0 AFTER `post_count`",
    'account_age_months' => "ADD COLUMN `account_age_months` INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `engagement_rate`",
    'is_active'          => "ADD COLUMN `is_active` TINYINT(1) NOT NULL DEFAULT 1 AFTER `status`",
    'rejection_reason'   => "ADD COLUMN `rejection_reason` VARCHAR(500) NULL DEFAULT NULL AFTER `is_active`",
    'rejection_history'  => "ADD COLUMN `rejection_history` TEXT NULL DEFAULT NULL AFTER `rejection_reason`",
    'verified_by'        => "ADD COLUMN `verified_by` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `rejection_history`",
    'verified_at'        => "ADD COLUMN `verified_at` DATETIME NULL DEFAULT NULL AFTER `verified_by`",
];

$applied = 0;
foreach ($columns as $name => $ddl) {
    if (!r75_column_exists($db, $table, $name)) {
        $db->exec("ALTER TABLE `{$table}` {$ddl}");
        $applied++;
    }
}

echo "migration 2026_09_05_0001_user_social_accounts_review_columns: OK (applied={$applied})\n";
