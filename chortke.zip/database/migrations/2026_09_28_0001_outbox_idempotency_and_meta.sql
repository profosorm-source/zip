-- =============================================================================
-- FIX-C65/C66 — Outbox: شناسه/زمان/کنشگر/نسخهٔ رویداد + idempotency
-- (یافته‌های ممیزی ۶۵ و ۶۶)
-- =============================================================================
-- پیشینه:
--   (۶۵) DomainEvent شناسهٔ یکتا، زمان وقوع، کنشگر و نسخهٔ رویداد را اجباری
--        نمی‌کرد و جدول outbox_events هیچ ستونی برای آن‌ها نداشت.
--   (۶۶) record() یک INSERT ساده بود؛ هیچ قید یکتایی برای جلوگیری از ثبت
--        تکراری (retry سطح کسب‌وکار) وجود نداشت و «ثبت در همان تراکنش
--        business» فقط قرارداد شفاهی بود.
-- راه‌حل:
--   1) ستون‌های متادیتای nullable (سازگار با ردیف‌های موجود):
--      event_id / occurred_at / actor_id / event_version
--   2) ستون idempotency_key (nullable) + قید UNIQUE ترکیبی
--      (aggregate_type, aggregate_id, event_type, idempotency_key).
--      NULL در MySQL/MariaDB در قید UNIQUE چندبارپذیر است ⇒ ردیف‌های قدیمی
--      و رکوردهای بدون کلید idempotency، رفتار قبلی را حفظ می‌کنند.
--   3) OutboxService::record() از INSERT ... ON DUPLICATE KEY UPDATE id=id
--      استفاده می‌کند (فقط نقض قید یکتا بلعیده می‌شود، سایر خطاها fail-loud).
-- سازگاری: ستون‌ها nullable / دارای پیش‌فرض؛ اجرای مجدد با IF NOT EXISTS امن است
-- (MariaDB 10.5+، هم‌سبک مایگریشن‌های قبلی پروژه).
-- =============================================================================

ALTER TABLE `outbox_events`
    ADD COLUMN IF NOT EXISTS `event_id` VARCHAR(64) NULL DEFAULT NULL
        COMMENT 'FIX-C65: شناسهٔ یکتای رویداد (uuid/ulid) — از VersionedDomainEvent::eventId()'
        AFTER `event_type`,
    ADD COLUMN IF NOT EXISTS `occurred_at` DATETIME NULL DEFAULT NULL
        COMMENT 'FIX-C65: زمان وقوع واقعی رویداد (ممکن است با created_at ثبت فاصله داشته باشد)'
        AFTER `event_id`,
    ADD COLUMN IF NOT EXISTS `actor_id` BIGINT UNSIGNED NULL DEFAULT NULL
        COMMENT 'FIX-C65: کاربر/سامانهٔ محرک رویداد (0 = سامانه)'
        AFTER `occurred_at`,
    ADD COLUMN IF NOT EXISTS `event_version` INT UNSIGNED NOT NULL DEFAULT 1
        COMMENT 'FIX-C65: نسخهٔ شِمای رویداد (schema evolution)'
        AFTER `actor_id`,
    ADD COLUMN IF NOT EXISTS `idempotency_key` VARCHAR(191) NULL DEFAULT NULL
        COMMENT 'FIX-C66: کلید یکتای ثبت (NULL = رفتار legacy)' AFTER `event_version`;

-- قید یکتا فقط برای ردیف‌های دارای کلید صریح اعمال می‌شود (NULL چندبارپذیر).
ALTER TABLE `outbox_events`
    ADD UNIQUE KEY IF NOT EXISTS `uq_outbox_idempotency`
        (`aggregate_type`, `aggregate_id`, `event_type`, `idempotency_key`);

-- ایندکس کمکی برای publisher (شکار zombie/پروسهٔ زمانی) — nullable ستون‌ها در WHERE مشکل‌ساز نیستند.
ALTER TABLE `outbox_events`
    ADD KEY IF NOT EXISTS `idx_outbox_event_id` (`event_id`);
