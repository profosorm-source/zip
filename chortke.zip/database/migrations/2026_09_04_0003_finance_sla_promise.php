<?php
// FIX-X180 (راند ۴۷): ستون‌های «وعدهٔ تنظیمی SLA» برای جریان‌های مالی
//        (برداشت وجه + واریز دستی)
//
// تصمیم مصوب کاربر: گسترش SLA به Withdrawal/manual-deposit — گزینهٔ کامل:
//   ① وعدهٔ تنظیمی (از پنل ادمین)  ② شمارندهٔ صف ادمین  ③ کارت وضعیت کاربر.
// پیش از این هیچ وعدهٔ زمانیِ مُهرشده‌ای برای پردازش برداشت/تأیید واریز دستی
// وجود نداشت؛ کاربر فقط «در انتظار» می‌دید و نه deadline و نه قضاوت پس از آن.
// اکنون لحظهٔ ثبتِ هر درخواست، وعده مُهر می‌شود:
//   - sla_promised_minutes : دقیقهٔ وعده (از withdrawal_sla_minutes /
//                            manual_deposit_sla_minutes در لحظهٔ ثبت)
//   - sla_promised_at      : لحظهٔ ثبت وعده
// چرا ستون و نه محاسبهٔ زنده از created_at؟ چون اگر ادمین بعداً مقدار تنظیم را
// تغییر دهد، وعدهٔ درخواست‌های قبلی نباید بی‌صدا عوض شود (صداقت تنظیمی —
// همان استدلال FIX-X165 برای KYC).
// «زمان پاسخ واقعی» ستون لازم ندارد: برای برداشت از processed_at و برای واریز
// دستی از COALESCE(reviewed_at, approved_at) زنده محاسبه می‌شود.
// رکوردهای پیش از این مایگریشن SLA ندارند → هیچ نشان و ادعایی برایشان رندر
// نمی‌شود (صفر ادعا برای گذشته — الگوی صداقت X125).
// این فایل کاملاً idempotent است و دو تنظیم پنل ادمین را هم seed می‌کند
// (INSERT IGNORE؛ حذف رکورد توسط ادمین = بازگشت به پیش‌فرض کد).
//
// Generated: 2026-09-04

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r47_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r47_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

// ─── ① ستون‌های جدول withdrawals ───────────────────────────────────────────
if (!r47_column_exists($db, 'withdrawals', 'sla_promised_minutes')) {
    $db->exec("ALTER TABLE `withdrawals` ADD COLUMN `sla_promised_minutes` INT UNSIGNED NULL DEFAULT NULL
               COMMENT 'وعدهٔ دقیقه‌ای پردازش برداشت در لحظهٔ ثبت (withdrawal_sla_minutes)'
               AFTER `crypto_network`");
}

if (!r47_column_exists($db, 'withdrawals', 'sla_promised_at')) {
    $db->exec("ALTER TABLE `withdrawals` ADD COLUMN `sla_promised_at` TIMESTAMP NULL DEFAULT NULL
               COMMENT 'لحظهٔ مُهر شدن وعدهٔ برداشت'
               AFTER `sla_promised_minutes`");
}

// ─── ② ستون‌های جدول manual_deposits ───────────────────────────────────────
if (!r47_column_exists($db, 'manual_deposits', 'sla_promised_minutes')) {
    $db->exec("ALTER TABLE `manual_deposits` ADD COLUMN `sla_promised_minutes` INT UNSIGNED NULL DEFAULT NULL
               COMMENT 'وعدهٔ دقیقه‌ای تأیید واریز دستی در لحظهٔ ثبت (manual_deposit_sla_minutes)'
               AFTER `receipt_path`");
}

if (!r47_column_exists($db, 'manual_deposits', 'sla_promised_at')) {
    $db->exec("ALTER TABLE `manual_deposits` ADD COLUMN `sla_promised_at` TIMESTAMP NULL DEFAULT NULL
               COMMENT 'لحظهٔ مُهر شدن وعدهٔ واریز دستی'
               AFTER `sla_promised_minutes`");
}

// ─── ③ seed تنظیمات پنل ادمین (همان گروه video_ads که SLAهای قبلی در آن‌اند) ──
// پیش‌فرض محافظه‌کارانه: ۱۲۰ دقیقه (۲ ساعت). ادمین از پنل قابل تغییر است.
$slaSettings = [
    ['withdrawal_sla_minutes',      '120', 'number', 'دقایق وعدهٔ پردازش درخواست برداشت (SLA)'],
    ['manual_deposit_sla_minutes',  '120', 'number', 'دقایق وعدهٔ تأیید واریز دستی (SLA)'],
];

foreach ($slaSettings as [$key, $value, $type, $desc]) {
    try {
        $db->prepare("INSERT IGNORE INTO system_settings (`key`, `value`, `group`, `type`, `description`)
                      VALUES (?, ?, 'video_ads', ?, ?)")
           ->execute([$key, $value, $type, $desc]);
    } catch (\Throwable $ignore) {
        // seed تنظیمات best-effort است؛ نباید مایگریشن ستون را شکست بدهد.
    }
}

echo "migration 2026_09_04_0003_finance_sla_promise: OK\n";
