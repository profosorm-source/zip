-- 2026_08_30_0001: تکمیل اسکیمای social_task_executions
-- FIX-EXEC-SCHEMA (باگ X4): مدل SocialTaskExecutionModel در ALLOWED_UPDATE_FIELDS
-- به ~۲۵ ستون ارجاع می‌دهد (امتیازدهی رفتاری، فلگ، Override، وریفای دوربین) که
-- مایگریشن اولیه جدول آن‌ها را نمی‌ساخت؛ هر updateExecutionStatus با ستونِ
-- مرتبط «Invalid or restricted update column» می‌داد (مثلاً overridden_by) و
-- کل فیچر Override ادمین + فلگ + ثبت امتیازها مرده بود.
-- همه ستون‌ها با ADD COLUMN IF NOT EXISTS → اجرای idempotent.

ALTER TABLE social_task_executions
    ADD COLUMN IF NOT EXISTS task_score INT NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS active_time INT NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS decision VARCHAR(30) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS rejection_reason VARCHAR(500) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS reject_reason VARCHAR(500) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS flag_review TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS flag_note VARCHAR(500) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS anti_fraud_score INT NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS reward_paid TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS override_reason VARCHAR(500) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS overridden_by INT UNSIGNED NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS overridden_at DATETIME NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS reviewed_by INT UNSIGNED NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS completed_at DATETIME NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS client_mode VARCHAR(30) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS client_version VARCHAR(40) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS device_context VARCHAR(255) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS behavior_score INT NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS time_score INT NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS interaction_score INT NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS camera_score INT NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS final_score INT NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS score_breakdown TEXT NULL,
    ADD COLUMN IF NOT EXISTS verification_required TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS verification_method VARCHAR(40) NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS verification_requested_at DATETIME NULL DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS verification_completed_at DATETIME NULL DEFAULT NULL;

CREATE INDEX IF NOT EXISTS idx_ste_final_score ON social_task_executions (final_score);
CREATE INDEX IF NOT EXISTS idx_ste_overridden ON social_task_executions (overridden_by);
