<?php
// ═══════════════════════════════════════════════════════════════════
// 🛡️ FIX-AF-UPSERT-UNIQUE (بازبینی گیت‌هاب 2026-10-28 — مکمل FIX-AF-QRY-IDX):
// یکتایی جفتی (fingerprint, user_id) — ریشه‌ای کردن رفع ایندکس ضدتقلب.
//
// ریشه (اثبات‌شده با پروب روی شمای مایگریت‌شدهٔ همین زنجیره):
//   user_fingerprints از زمان ساخت (2026_06_10_0040) فقط PRIMARY(id) دارد.
//   IpAndDeviceModel::upsertFingerprint با «INSERT ... ON DUPLICATE KEY
//   UPDATE last_seen=NOW(), seen_count=seen_count+1» کار می‌کند — اما
//   ON DUPLICATE فقط روی کلید UNIQUE/PRIMARY گیر می‌کند. نتیجه:
//     ۱) هر فراخوانیِ upsert یک ردیف «جدید» درج می‌کند (پروب: ۳ فراخوانیِ
//        همان (user, fingerprint) ⇒ ۳ ردیف جدا با seen_count=1) — رشد
//        نامحدود جدول، تقریباً یک ردیف به‌ازای هر هیت انگشت.
//     ۲) seen_count/last_seen هرگز به‌روز نمی‌شوند — سیگنال «دستگاهِ
//        دیده‌شده N بار» ساختاراً مرده است.
//   مایگریشن FIX-AF-QRY-IDX ایندکس «غیر یکتا» (fingerprint, user_id) ساخت
//   که سرعت پرس‌وجوها را درست کرد ولی چون plain است، conflict نمی‌سازد و
//   باگِ درجِ مکرر باقی ماند.
//
// تعمیر (idempotent، بدون از دست رفتن هیچ دادهٔ معناداری):
//   گام ۱ — ادغام ردیف‌های تکراریِ (fingerprint, user_id) انباشته از دوران
//          باگ: برای هر جفت تکراری، ردیفِ نگه‌داشته = کمترین id؛
//          seen_count = جمع کل؛ last_seen = بیشینه؛ ردیف‌های مازاد حذف.
//          (حذف فقط ردیف‌های «عیناً تکراری» است — ادغام داده، نه پاک‌سازی.)
//   گام ۲ — حذف ایندکس plain قبلی (اگر غیر یکتا باشد؛ اگر از قبل UNIQUE
//          است، کل مایگریشن SKIP می‌شود).
//   گام ۳ — حذف ایندکس یونیک تک‌ستونهٔ قدیمی idx_fingerprint در صورت
//          وجود (drift محیط‌های قدیمی؛ یونیک تک‌ستونه یعنی «هر انگشت فقط
//          یک مالک» — تشخیص چند-حسابیِ همان دستگاه را خاموش می‌کند).
//   گام ۴ — ساخت UNIQUE INDEX idx_uf_fingerprint_user (fingerprint, user_id).
//
// پس از این مایگریشن: ON DUPLICATE واقعاً fire می‌شود؛ جفت تکراری
// dedupe + bump می‌شود؛ کاربر دومِ همان دستگاه ردیف خودش را می‌گیرد و
// COUNT(DISTINCT user_id) واقعاً چند-کاربره است (سیگنال ضدتقلب زنده).
//
// این فایل از داخل MigrationService::runMigrations() require می‌شود
// (هم‌الگوی 2026_10_25_0001_anti_fraud_query_indexes.php).

require_once __DIR__ . '/../../bootstrap/app.php';

if (!function_exists('afu28_index_row')) {
    /**
     * ردیفِ ایندکس از information_schema یا null.
     *@return array{non_unique:int, cols:string}|null
     */
    function afu28_index_row(PDO $db, string $table, string $indexName): ?array
    {
        $stmt = $db->prepare(
            "SELECT NON_UNIQUE, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS cols
             FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = ?
               AND index_name = ?
             GROUP BY NON_UNIQUE"
        );
        $stmt->execute([$table, $indexName]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row) || !isset($row['cols'])) {
            return null;
        }
        return ['non_unique' => (int)$row['NON_UNIQUE'], 'cols' => (string)$row['cols']];
    }
}

if (!function_exists('afu28_log')) {
    function afu28_log(string $msg): void
    {
        echo '[af-upsert-uniq 2026_10_28_0001] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.user_fingerprints_unique_upsert_fix', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

$pdo = \Core\Application::getInstance()->db()->getPdo();

// ── گام ۰: وضعیت فعلی ─────────────────────────────────────────────
$existing = afu28_index_row($pdo, 'user_fingerprints', 'idx_uf_fingerprint_user');
if ($existing !== null && $existing['non_unique'] === 0 && $existing['cols'] === 'fingerprint,user_id') {
    afu28_log('SKIP: idx_uf_fingerprint_user از قبل UNIQUE (fingerprint, user_id) است — idempotent.');
    return;
}

// ── گام ۱: ادغام ردیف‌های تکراری انباشته (فقط جفت‌های تکراری؛ حفظ داده) ──
try {
    $pdo->exec(
        "UPDATE user_fingerprints uf
         JOIN (
             SELECT fingerprint, user_id,
                    MIN(id)  AS keep_id,
                    SUM(seen_count) AS total_seen,
                    MAX(last_seen)  AS last_seen_max
             FROM user_fingerprints
             GROUP BY fingerprint, user_id
             HAVING COUNT(*) > 1
         ) d ON d.fingerprint = uf.fingerprint AND d.user_id = uf.user_id
         SET uf.seen_count = GREATEST(1, d.total_seen),
             uf.last_seen  = d.last_seen_max
         WHERE uf.id = d.keep_id"
    );
    $merged = $pdo->exec(
        "DELETE uf
         FROM user_fingerprints uf
         JOIN (
             SELECT fingerprint, user_id, MIN(id) AS keep_id
             FROM user_fingerprints
             GROUP BY fingerprint, user_id
             HAVING COUNT(*) > 1
         ) d ON d.fingerprint = uf.fingerprint AND d.user_id = uf.user_id
         WHERE uf.id <> d.keep_id"
    );
    afu28_log('OK: ادغام ردیف‌های تکراری (fingerprint, user_id) — ردیف‌های حذف‌شده: ' . (int)$merged);
} catch (\Throwable $e) {
    // بدون ادغام، ساخت UNIQUE روی داده‌های تکراری شکست می‌خورد — fail-loud
    afu28_log('FATAL: ادغام ردیف‌های تکراری ناموفق — ' . $e->getMessage());
    throw $e;
}

// ── گام ۲: حذف ایندکس plain قبلی (اگر غیر یکتا باشد) ───────────────
if ($existing !== null && $existing['non_unique'] === 1) {
    $pdo->exec('ALTER TABLE user_fingerprints DROP INDEX idx_uf_fingerprint_user');
    afu28_log('OK: ایندکس plain (غیر یکتا) idx_uf_fingerprint_user حذف شد.');
}

// ── گام ۳: حذف یونیک تک‌ستونهٔ قدیمی در صورت وجود (drift محیط‌های قدیمی) ──
$legacy = afu28_index_row($pdo, 'user_fingerprints', 'idx_fingerprint');
if ($legacy !== null) {
    $pdo->exec('ALTER TABLE user_fingerprints DROP INDEX idx_fingerprint');
    afu28_log('OK: ایندکس قدیمی تک‌ستونهٔ idx_fingerprint حذف شد (یکتایی به جفت منتقل شد).');
}

// ── گام ۴: ساخت UNIQUE جفتی ───────────────────────────────────────
$pdo->exec(
    'ALTER TABLE user_fingerprints
     ADD UNIQUE INDEX idx_uf_fingerprint_user (fingerprint, user_id)'
);
afu28_log('OK: UNIQUE INDEX idx_uf_fingerprint_user (fingerprint, user_id) ساخته شد — ON DUPLICATE KEY UPDATE اکنون واقعاً fire می‌شود و seen_count زنده است.');
