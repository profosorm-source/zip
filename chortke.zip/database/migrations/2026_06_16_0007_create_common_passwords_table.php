<?php
require_once __DIR__ . '/../../bootstrap/app.php';

// ═══════════════════════════════════════════════════════════════════════════
// 🛡️ FIX-S20-DEAD (تصمیم مصوب گزینهٔ ۶ — حذف جدول خفتهٔ common_passwords)
// ═══════════════════════════════════════════════════════════════════════════
//
// تاریخچه: این مایگریشن در نسخه‌های پیشین جدول common_passwords را می‌ساخت؛ اما
// جدول هیچ‌گاه population نشد (هیچ INSERT در کل مخزن وجود ندارد) و تنها خوانندهٔ
// بالقوهٔ آن (CommonPasswords::isCommonFromDatabase) هیچ فراخوانی‌کننده‌ای ندارد —
// مسیر runtime پسورد (PasswordPolicy → CommonPasswords::isCommon + Bloom Filter
// در app/Data/CommonPasswords.php) کاملاً خارج از این جدول کار می‌کند.
// طبق تصمیم مصوب کاربر (بچ S20، گزینهٔ ۶ — هم‌سو با تمیزکاری S19):
//   ۱) این فایل به cleanup تبدیل شد: DROP TABLE IF EXISTS (idempotent) —
//      نصب‌های موجودِ جدول‌دار را پاک می‌کند و در نصب تازه no-op است.
//   ۲) متد مردهٔ isCommonFromDatabase از CommonPasswords.php حذف شد.
//   ۳) SchemaIntegrityTest دیگر common_passwords را الزامی نمی‌داند.
// نام فایل و جایگاهش در زنجیرهٔ مایگریشن‌ها عمداً حفظ شده تا ترتیب/checksum
// زنجیره و شمارش preflight دست‌نخورده بماند.

$db = db();

// 🔒 AUDIT-FIX (R2): destructive PHP migrations must pass the same safety guard
// as destructive SQL statements (populated-table protection / explicit opt-in).
\App\Services\MigrationService::assertDestructiveOperation('drop_table', 'common_passwords');
$db->execute("DROP TABLE IF EXISTS common_passwords");

echo "migration 2026_06_16_0007: OK — dead table common_passwords removed (or was never created)\n";
