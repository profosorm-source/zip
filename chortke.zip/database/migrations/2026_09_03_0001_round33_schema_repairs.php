<?php
// FIX-X114b + X118: تعمیرات اسکیمای راند ۳۳ (فایل کانونیکال برای استقرار تازه)
//
// ۱) X114b — ایندکس‌های جاافتادهٔ vitrine_listings:
//    ممیزی راند ۳۲ (X114) نشان داد جدول فقط PRIMARY(id) داشت؛ ایندکس‌ها همان راند
//    به‌صورت زنده اعمال شدند. این فایل نسخهٔ کانونیکال برای استقرارهای تازه است.
//
// ۲) X118 — ستون جاافتادهٔ notifications.scheduled_at:
//    کشف تصادفی در پروب راند ۳۳: چند مسیر INSERT اعلان (SendToAdminsNotificationJob و
//    هم‌خانواده‌ها) ستون scheduled_at را می‌نویسند و مدل Notification + کوئری دیسپچر
//    (Notification::pendingScheduled و...) + فرم اعلان ادمین آن را می‌خوانند، اما ستون
//    هرگز در جدول notifications ساخته نشده بود → کل قابلیت «اعلان زمان‌بندی‌شده»
//    نیمه‌ساخته بود و هر اعلانی که scheduled_at می‌فرستاد با 42S22 شکست می‌خورد
//    (شامل هشدار ادمین در رویداد rate_limit.exceeded). فیکس ریشه‌ای = ساختن ستون +
//    ایندکسِ دیسپچر.
//
// این فایل کاملاً idempotent است: هر بخش پیش از اجرا، وضعیت موجود را با
// information_schema می‌سنجد؛ اجرای مکرر هیچ‌گاه خطا نمی‌دهد.
//
// Generated: 2026-09-03

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r33_index_exists')) {
    /** آیا ایندکس با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r33_index_exists(PDO $db, string $table, string $index): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.statistics
             WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?'
        );
        $stmt->execute([$table, $index]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r33_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r33_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

try {
    $applied = [];

    // ─── ۱) X114b: ایندکس‌های vitrine_listings ───
    if (!r33_index_exists($db, 'vitrine_listings', 'idx_vl_user')) {
        $db->exec('CREATE INDEX idx_vl_user ON vitrine_listings (user_id)');
        $applied[] = 'vitrine_listings.idx_vl_user(user_id)';
    }
    if (!r33_index_exists($db, 'vitrine_listings', 'idx_vl_status_created')) {
        $db->exec('CREATE INDEX idx_vl_status_created ON vitrine_listings (status, created_at)');
        $applied[] = 'vitrine_listings.idx_vl_status_created(status, created_at)';
    }

    // ─── ۲) X118: ستون scheduled_at جدول notifications + ایندکس دیسپچر ───
    if (!r33_column_exists($db, 'notifications', 'scheduled_at')) {
        // زمان‌بندی نمایش/ارسال اعلان — NULL یعنی فوری (بدون COMMENT در DDL: سازگاری گرامر MariaDB)
        $db->exec('ALTER TABLE notifications ADD COLUMN scheduled_at datetime NULL DEFAULT NULL AFTER created_at');
        $applied[] = 'notifications.scheduled_at (ADD COLUMN)';
    }
    if (!r33_index_exists($db, 'notifications', 'idx_notif_scheduled')) {
        $db->exec('CREATE INDEX idx_notif_scheduled ON notifications (scheduled_at)');
        $applied[] = 'notifications.idx_notif_scheduled(scheduled_at)';
    }

    echo $applied
        ? 'migration: round33 schema repairs applied: ' . implode(', ', $applied) . "\n"
        : "migration: round33 schema repairs already present (idempotent no-op)\n";
} catch (Throwable $e) {
    echo "migration error: " . $e->getMessage() . "\n";
    // 🛡️ FIX-S19-3: exit() درون مایگریشن = مرگ کل پروسه (include in-process).
    throw new RuntimeException('round33 schema repairs failed: ' . $e->getMessage(), 0, $e);
}
