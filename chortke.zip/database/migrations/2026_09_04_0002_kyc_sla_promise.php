<?php
// FIX-X165 (راند ۴۱): ستون‌های «وعدهٔ تنظیمی بررسی فوری KYC»
//
// تصمیم مصوب کاربر: گسترش SLA به KYC — وعده + شمارنده صف ادمین + کارت وضعیت کاربر.
// پیش از این قول «بررسی فوری» فقط در پاپ‌آپ بوست گفته می‌شد اما هیچ‌جا مُهر و
// سنجیده نمی‌شد. اکنون لحظهٔ ثبت KYC (فقط وقتی بوست فعال است) وعده مُهر می‌شود:
//   - sla_promised_minutes : تعداد دقیقهٔ وعده (از kyc_express_minutes در لحظهٔ ثبت)
//   - sla_promised_at      : لحظهٔ ثبت وعده
// چرا ستون و نه محاسبهٔ زنده از submitted_at؟ چون اگر ادمین بعداً kyc_express_minutes
// را تغییر دهد، وعدهٔ درخواست‌های قبلی نباید بی‌صدا عوض شود (صداقت تنظیمی).
// «زمان پاسخ واقعی» ستون لازم ندارد: از reviewed_at - sla_promised_at زنده محاسبه می‌شود.
// این فایل کاملاً idempotent است.
//
// Generated: 2026-09-04

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r41_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r41_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

$table = 'kyc_verifications';

if (!r41_column_exists($db, $table, 'sla_promised_minutes')) {
    $db->exec("ALTER TABLE `{$table}` ADD COLUMN `sla_promised_minutes` INT UNSIGNED NULL DEFAULT NULL
               COMMENT 'وعدهٔ دقیقه‌ای بررسی فوری در لحظهٔ ثبت (kyc_express_minutes)'
               AFTER `device_fingerprint`");
}

if (!r41_column_exists($db, $table, 'sla_promised_at')) {
    $db->exec("ALTER TABLE `{$table}` ADD COLUMN `sla_promised_at` TIMESTAMP NULL DEFAULT NULL
               COMMENT 'لحظهٔ مُهر شدن وعده'
               AFTER `sla_promised_minutes`");
}

echo "migration 2026_09_04_0002_kyc_sla_promise: OK\n";
