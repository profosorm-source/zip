<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-R31-C1 — UNIQUE(execution_id, rater_id, rater_type) برای social_ratings
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه: جدول social_ratings فقط PRIMARY(id) دارد و مدل
// SocialTaskAnalyticsModel::createRating() (app/Models/
// SocialTaskAnalyticsModel.php:19-52) با الگوی check-then-insert
// کار می‌کند: اول hasUserRated() چک می‌شود، بعد INSERT انجام می‌شود.
// بین چک و INSERT هیچ قید یکتایی وجود ندارد؛ دو درخواست هم‌زمان
// (دابل‌کلیک/ریتری شبکه) هر دو از hasUserRated() با false رد می‌شوند و
// دو امتیاز برای یک (execution_id, rater_id, rater_type) ثبت می‌شود ←
// خرابی میانگین امتیاز (AVG(stars)) و شمارش‌های اعتماد کاربر.
//
// ستون‌های کلید همگی NOT NULL هستند (execution_id INT UNSIGNED،
// rater_id INT UNSIGNED، rater_type ENUM('executor','advertiser'))، پس
// UNIQUE ساده کافی است و برخلاف content_revenues نیازی به ستون
// تولیدشده (generated column) نیست.
//
// ۱) گارد idempotency (الگوی information_schema، 2026_09_20_0007):
//    اگر UNIQUE سه‌ستونی روی (execution_id, rater_id, rater_type) از
//    قبل وجود داشته باشد، SKIP + return تمیز.
// ۲) جداسازی تکراری‌ها (الگوی keep-MIN(id)، 2026_09_20_0003): برای هر
//    سه‌تایی کمترین id نگه داشته می‌شود و بقیه حذف می‌شوند.
// ۳) ساخت UNIQUE KEY uq_social_ratings_exec_rater.
//
// رفتار بعد از مایگریشن: بازندهٔ ریس به‌جای ثبت امتیاز تکراری,
// duplicate-key exception می‌گیرد (fail-loud) — رفتار موردنظر است.
//
// اجرا: چه توسط MigrationService (require درون‌پردازشی) و چه مستقیم با
// php CLI، گارد function_exists + return تمیز اجرای تکراری را بی‌خطر
// می‌کند.
// ═══════════════════════════════════════════════════════════════════

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r31a_social_ratings_exec_rater_unique_exists')) {
    /** آیا یک UNIQUE index سه‌ستونی روی (execution_id, rater_id, rater_type) هست؟ */
    function r31a_social_ratings_exec_rater_unique_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT index_name
             FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = 'social_ratings'
               AND non_unique = 0
               AND index_name <> 'PRIMARY'
               AND column_name IN ('execution_id', 'rater_id', 'rater_type')
             GROUP BY index_name
             HAVING COUNT(DISTINCT column_name) = 3
             LIMIT 1"
        );
        $stmt->execute();
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('r31a_social_ratings_dup_rows_count')) {
    /**
     * تعداد ردیف‌های تکراری که باید حذف شوند: برای هر
     * (execution_id, rater_id, rater_type) با بیش از یک ردیف،
     * (اندازهٔ گروه - ۱) — جمع روی همهٔ گروه‌ها.
     */
    function r31a_social_ratings_dup_rows_count(PDO $db): int
    {
        $stmt = $db->prepare(
            "SELECT COALESCE(SUM(c - 1), 0) FROM (
                 SELECT COUNT(*) AS c
                 FROM social_ratings
                 GROUP BY execution_id, rater_id, rater_type
                 HAVING COUNT(*) > 1
             ) AS dup_groups"
        );
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }
}

if (!function_exists('r31a_social_ratings_log')) {
    function r31a_social_ratings_log(string $msg): void
    {
        echo '[r31-social-ratings-unique] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.r31a_social_ratings_exec_rater_unique', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

if (r31a_social_ratings_exec_rater_unique_exists($db)) {
    r31a_social_ratings_log('SKIP: UNIQUE index روی (execution_id, rater_id, rater_type) از قبل وجود دارد (idempotent).');
    return; // پایان تمیزِ فایل مایگریشن (بدون interrupt کردن runner)
}

// ۱) جداسازی تکراری‌ها: نگه‌داشتن کمترین id برای هر (execution_id, rater_id, rater_type)
$dupRows = r31a_social_ratings_dup_rows_count($db);
if ($dupRows > 0) {
    $deleted = $db->exec(
        'DELETE t1 FROM social_ratings t1
         JOIN social_ratings t2
           ON t2.execution_id = t1.execution_id
          AND t2.rater_id = t1.rater_id
          AND t2.rater_type = t1.rater_type
          AND t2.id < t1.id'
    );
    r31a_social_ratings_log("DEDUPE: {$deleted} ردیف تکراری حذف شد (برآورد پیش از حذف: {$dupRows}).");
} else {
    r31a_social_ratings_log('DEDUPE: ردیف تکراری وجود ندارد — جداسازی انجام نشد.');
}

// ۲) ساخت UNIQUE (کلیدِ بستنِ ریس TOCTOU در createRating())
$db->exec('ALTER TABLE social_ratings ADD UNIQUE KEY uq_social_ratings_exec_rater (execution_id, rater_id, rater_type)');
r31a_social_ratings_log('OK: UNIQUE KEY uq_social_ratings_exec_rater (execution_id, rater_id, rater_type) ساخته شد — بازندهٔ ریس اکنون duplicate-key exception می‌گیرد (fail-loud).');
