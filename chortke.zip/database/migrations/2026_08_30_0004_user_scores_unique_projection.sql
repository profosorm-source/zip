-- FIX-X20 (راند ۱۵، بحرانی-پروداکشن): پروجکشن امتیاز در user_scores قرارداد
-- «یک ردیف به‌ازای هر (user_id, domain)» دارد — ScoreProjectionListener با
-- INSERT ... ON DUPLICATE KEY UPDATE می‌نویسد — ولی جدول هیچ UNIQUE KEY روی
-- (user_id, domain) نداشت؛ در نتیجه ON DUPLICATE هرگز فعال نمی‌شد و هر ایونت
-- یک ردیف تازه می‌ساخت (در QA: ۵ ردیف برای کاربر ۵/دامنه fraud). خواندن با
-- SELECT ... LIMIT 1 هم امتیاز تجمعی واقعی را نمی‌داد (فقط اولین ردیف).
--
-- رفع دو بخشی و idempotent:
--   ۱) merge تکراری‌ها: جمع score در هر (user_id, domain)؛ دامنهٔ fraud طبق
--      قرارداد 0..100 با LEAST سقف می‌خورد (هم‌راستا با FIX-X17)؛ MAX(updated_at)
--      حفظ می‌شود تا واپاشی FIX-X17-deep مبنای درست داشته باشد.
--   ۲) افزودن UNIQUE KEY تا از این پس upsert واقعاً upsert باشد.
--
-- نکتهٔ idempotency: پس از اجرای اول هیچ تکراری باقی نمی‌ماند (گروه‌بندی یک ردیف
-- برمی‌گرداند) و ADD UNIQUE KEY IF NOT EXISTS نیز در اجرای مجدد no-op است.
--
-- W4-B (F-A24c-03): بلوک dedupe (DELETE + re-INSERT) حالا داخل «تراکنشِ صریح»
-- اجرا می‌شود. چون فایل شامل ALTER است، MigrationService کل فایل را در
-- autocommit اجرا می‌کند (isDdl ⇒ useTx=false) و تنها راه اتمیک‌شدن dedupe،
-- تراکنش صریح درون خود فایل است: کرش بین DELETE و INSERT دیگر user_scores را
-- خالی رها نمی‌کند (بسته‌شدن اتصال = rollback خودکار، ران مجدد idempotent).
-- ALTER عمداً «بیرون» تراکنشِ صریح می‌ماند (DDL در MySQL/MariaDB خودش implicit
-- commit می‌زند).
-- نکتهٔ حیاتیِ رانر (بدون آن فایل روی runner فعلی می‌شکند): MigrationService
-- پیش از statementِ بعدیِ هر statementی که با ALTER/CREATE/DROP/RENAME/TRUNCATE
-- «شروع شود» forceReconnect می‌زند و اتصالِ تازه یعنی مرگ TEMPORARY TABLE و
-- تراکنشِ باز. به همین دلیل chunkهای CREATE/DROP TEMPORARY با پیشوندِ کامنت
-- شروع می‌شوند (first-token آن‌ها DDL نباشد) تا هیچ reconnectی داخل تراکنش
-- رخ ندهد. این پیش‌فرض را هنگام ویرایش مجدد حذف نکنید.
START TRANSACTION;

-- گام ۱: merge تکراری‌ها در جدول کمکیِ session-scoped
CREATE TEMPORARY TABLE tmp_user_scores_dedupe AS
SELECT user_id,
       domain,
       SUM(score) AS score,
       MAX(updated_at) AS updated_at
FROM user_scores
GROUP BY user_id, domain;

DELETE us FROM user_scores us
JOIN tmp_user_scores_dedupe t
  ON us.user_id = t.user_id
 AND us.domain  = t.domain;

INSERT INTO user_scores (user_id, domain, score, updated_at)
SELECT user_id,
       domain,
       CASE WHEN domain = 'fraud' THEN LEAST(100, score) ELSE score END,
       updated_at
FROM tmp_user_scores_dedupe;

-- گام ۴: حذف جدول کمکیِ session-scoped (داخل همان تراکنش؛ TEMPORARY موضوع
-- implicit-commit نیست و تراکنش را نمی‌بندد)
DROP TEMPORARY TABLE tmp_user_scores_dedupe;

COMMIT;

ALTER TABLE user_scores
    ADD UNIQUE KEY IF NOT EXISTS uq_user_scores_entity_domain (user_id, domain);
