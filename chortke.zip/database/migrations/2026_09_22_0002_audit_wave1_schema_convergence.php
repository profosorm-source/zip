<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-R36-W1 — همگرایی اسکیمای موج رفع ۱ ممیزی R36 (یافته‌های P1)
// ═══════════════════════════════════════════════════════════════════
//
// این مایگریشن سهrift اسکیمایی را که ممیزی R36 (A2/A6b/A24c) قطعی کرد برای
// پایگاه‌های دادهٔ «موجود» اصلاح می‌کند (برای نصب تازه، DDLهای منبع خودشان
// اصلاح شده‌اند — 2026_06_10_0018). کاملاً idempotent است (الگوی
// information_schema، هم‌الگوی 2026_09_20_0004_users_country_flag.php):
//
//   1) F-A2-02 — data_exports چهار ستون چرخهٔ حیات را ندارد
//      (requested_at/completed_at/error_message/updated_at)؛ DataExport::
//      updateStatus (User.php:83/92/97) آن‌ها را می‌نویسد و خواننده‌ها ORDER BY
//      requested_at → 42S22 لامصرف → هر خروجی تا ابد processing می‌ماند.
//      ستون‌ها + backfill requested_at/updated_at از created_at اضافه می‌شود.
//
//   2) F-A2-01 (ریشهٔ F-A24c-01) — user_roles در پایگاه‌های موجود فاقد
//      granted_by/granted_at است (DDL موازی 06_16_0004 هرگز برندهٔ اجرا نشد)
//      → INSERT با این ستون‌ها (User::assignRole:722) روی 42S22 می‌ترکد.
//      ستون‌ها nullable و مطابق 06_16_0004 اضافه می‌شوند.
//
//   3) F-A6b-01 — ستون disputes.peer_votes برای گزینهٔ رضایت دوطرفهٔ
//      حل توافقی (ثبت رأی طرف اول تا تأیید طرف مقابل / ارجاع تعارض به
//      داوری ادمین).
//
// هیچ DROP/TRUNCATE/DELETE داده‌ای در کار نیست؛ فقط ADD COLUMN guarded +
// UPDATE backfill محدود به ستون‌های تازه.

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r36w1_column_exists')) {
    function r36w1_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE()
               AND table_name = ?
               AND column_name = ?"
        );
        $stmt->execute([$table, $column]);
        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r36w1_log')) {
    function r36w1_log(string $msg): void
    {
        echo '[r36w1-schema-convergence] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.r36w1_schema_convergence', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

// ─── 1) data_exports — ستون‌های چرخهٔ حیات (F-A2-02) ───────────────────
if (!r36w1_column_exists($db, 'data_exports', 'requested_at')) {
    $db->exec("ALTER TABLE `data_exports` ADD COLUMN `requested_at` TIMESTAMP NULL DEFAULT NULL AFTER `file_path`");
    $db->exec("UPDATE `data_exports` SET `requested_at` = `created_at` WHERE `requested_at` IS NULL");
    $db->exec("ALTER TABLE `data_exports` MODIFY `requested_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
    r36w1_log('OK: data_exports.requested_at افزوده و از created_at backfill شد.');
} else {
    r36w1_log('SKIP: data_exports.requested_at موجود است.');
}

if (!r36w1_column_exists($db, 'data_exports', 'completed_at')) {
    $db->exec("ALTER TABLE `data_exports` ADD COLUMN `completed_at` TIMESTAMP NULL DEFAULT NULL AFTER `requested_at`");
    r36w1_log('OK: data_exports.completed_at افزوده شد.');
} else {
    r36w1_log('SKIP: data_exports.completed_at موجود است.');
}

if (!r36w1_column_exists($db, 'data_exports', 'error_message')) {
    $db->exec("ALTER TABLE `data_exports` ADD COLUMN `error_message` TEXT NULL DEFAULT NULL AFTER `completed_at`");
    r36w1_log('OK: data_exports.error_message افزوده شد.');
} else {
    r36w1_log('SKIP: data_exports.error_message موجود است.');
}

if (!r36w1_column_exists($db, 'data_exports', 'updated_at')) {
    // ON UPDATE CURRENT_TIMESTAMP = همان قرارداد SQL دستیِ DataExport::updateStatus
    // («updated_at = NOW()»)؛ برای هر UPDATE وضعیت، خودکار به‌روز می‌شود.
    $db->exec("ALTER TABLE `data_exports` ADD COLUMN `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `error_message`");
    $db->exec("UPDATE `data_exports` SET `updated_at` = `created_at` WHERE `updated_at` IS NULL OR `updated_at` = CURRENT_TIMESTAMP");
    r36w1_log('OK: data_exports.updated_at افزوده و backfill شد.');
} else {
    r36w1_log('SKIP: data_exports.updated_at موجود است.');
}

// ─── 2) user_roles — ستون‌های grant برای پایگاه‌های موجود (F-A2-01) ────
if (!r36w1_column_exists($db, 'user_roles', 'granted_by')) {
    $db->exec("ALTER TABLE `user_roles` ADD COLUMN `granted_by` INT(10) UNSIGNED NULL DEFAULT NULL AFTER `role_id`");
    r36w1_log('OK: user_roles.granted_by افزوده شد (همگرا با 06_16_0004).');
} else {
    r36w1_log('SKIP: user_roles.granted_by موجود است.');
}

if (!r36w1_column_exists($db, 'user_roles', 'granted_at')) {
    $db->exec("ALTER TABLE `user_roles` ADD COLUMN `granted_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP AFTER `granted_by`");
    r36w1_log('OK: user_roles.granted_at افزوده شد (همگرا با 06_16_0004).');
} else {
    r36w1_log('SKIP: user_roles.granted_at موجود است.');
}

// ─── 3) disputes.peer_votes — رضایت دوطرفهٔ حل توافقی (F-A6b-01) ──────
if (!r36w1_column_exists($db, 'disputes', 'peer_votes')) {
    $db->exec("ALTER TABLE `disputes` ADD COLUMN `peer_votes` TEXT NULL DEFAULT NULL AFTER `resolution_note`");
    r36w1_log('OK: disputes.peer_votes افزوده شد (گزینهٔ رضایت دوطرفه).');
} else {
    r36w1_log('SKIP: disputes.peer_votes موجود است.');
}

// ─── 4) escrow_transactions — رفع تضاد دو unique (پین رفتاری چرخهٔ حیات) ──
// مایگریشن R20-B2 (2026_09_20_0007) یک UNIQUE سادهٔ (order_id, order_type)
// ساخته که «بازگشایی چرخهٔ حیات پس از وضعیت نهایی» (refund → escrow جدید
// برای همان سفارش) را در سطح DB قفل می‌کند — پین رفتاری پین‌شدهٔ پروژه
// (tests/Integration/Financial/EscrowActiveUniquenessDatabaseTest) صراحتاً
// «یک اسکرو فعال per order + امکان بازگشایی پس از terminal» را الزام کرده
// (همان قرارداد uq_escrow_active_order STORED GENERATED). هیچ تست دیگری
// وجودِ unique ساده را پین نکرده؛ حذف آن رفتار مالی صحیح را برمی‌گرداند
// (بدون هیچ دست‌کاری داده‌ای؛ قابل‌بازگشت).
$stmt = $db->query(
    "SELECT COUNT(*) FROM information_schema.STATISTICS
     WHERE table_schema = DATABASE()
       AND table_name = 'escrow_transactions'
       AND index_name = 'escrow_transactions_order_unique'"
);
if ((int) $stmt->fetchColumn() > 0) {
    $db->exec('ALTER TABLE `escrow_transactions` DROP INDEX `escrow_transactions_order_unique`');
    r36w1_log('OK: unique سادهٔ escrow_transactions_order_unique حذف شد (uq_escrow_active_order مرجع ماند).');
} else {
    r36w1_log('SKIP: escrow_transactions_order_unique موجود نیست.');
}

r36w1_log('DONE: همگرایی اسکیمای موج ۱ ممیزی R36 کامل شد (بدون هیچ حذف داده).');
