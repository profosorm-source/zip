-- ═══════════════════════════════════════════════════════════════════
-- FIX-CH04 (راند ۱۵ — گزارش بخش‌های ۸-۴۰) — اصلاح provenance backfill
-- ═══════════════════════════════════════════════════════════════════
-- پیشینه: نسخهٔ قبلی همین فایل (راند ۱۲، FIX-DB-03) همهٔ ردیف‌های
-- current_balance = 1025.5000 را به amount برمی‌گرداند. مساوی بودن مبلغ
-- به‌تنهایی provenance نیست: یک سرمایه‌گذاری واقعی که دقیقاً ۱۰۲۵٫۵
-- موجودی دارد (حاصل سود/زیان مشروع) هم انتخاب می‌شد و دارایی کاربر
 -- بازنویسی می‌شد.
--
-- اکنون backfill فقط ردیف‌هایی را اصلاح می‌کند که «امضای پیش‌فرضِ
-- بی‌منبع + سکوت فعالیت» دارند:
--   ۱) مقدار دقیقاً 1025.5000 (امضای DEFAULT legacy)،
--   ۲) هیچ تراکنش حسابداری سرمایه‌گذاری (سود/زیان/کارمزد/مالیات/برداشت)
--      با ref_type='investment' و ref_id همین ردیف وجود ندارد.
-- ردیفی که سابقهٔ settlement یا برداشت دارد، مقدار 1025.5 او حاصل
-- فعالیت مشروع است و دست‌نخورده می‌ماند.
--
-- اجرای مجدد idempotent است. روی نصب‌هایی که نسخهٔ قبلی را اجرا کرده‌اند
-- (از مسیر amendment با checksum جدید ثبت می‌شود) این UPDATE فقط برای
-- ردیف‌های باقی‌ماندهٔ منطبق عمل می‌کند.
-- ═══════════════════════════════════════════════════════════════════

ALTER TABLE `investments`
  MODIFY COLUMN `current_balance` DECIMAL(24,8) NULL DEFAULT 0;

UPDATE `investments` AS i
   SET i.`current_balance` = i.`amount`
 WHERE i.`current_balance` = 1025.5000
   AND NOT EXISTS (
       SELECT 1
         FROM `transactions` t
        WHERE t.`ref_type` = 'investment'
          AND t.`ref_id` = CAST(i.`id` AS CHAR)
          AND t.`type` IN (
              'investment_trading_profit',
              'investment_trading_loss',
              'investment_platform_fee',
              'investment_tax',
              'investment_withdrawal',
              'investment_profit_withdrawal'
          )
   );
