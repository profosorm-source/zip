-- FIX-S34-B14-F12 (گزارش بخش ۱۴ — برداشت وجه): توضیح اختیاری کاربر
-- (user_description — فیلد nullable در CreateWithdrawalRequest و بخشی از
-- payload مقایسه idempotency) تا پیش از این در هیچ ستونی از withdrawals ذخیره
-- نمی‌شد؛ کاربر توضیح می‌فرستاد ولی رکورد عملیاتی و صفحه بررسی ادمین آن را
-- دریافت نمی‌کرد و مسیر ممیزی مالی ناقص می‌ماند.

ALTER TABLE withdrawals
  ADD COLUMN user_description VARCHAR(500) NULL DEFAULT NULL
    COMMENT 'توضیح اختیاری کاربر هنگام ثبت درخواست برداشت (FIX-S34-B14-F12)'
    AFTER rejection_reason;
