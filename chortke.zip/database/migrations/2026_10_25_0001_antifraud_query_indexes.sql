-- ============================================================================
-- FIX-R18-GAP-IDX — ایندکس‌های پرس‌وجوی ضدتقلب (بستهٔ باقیماندهٔ R18)
-- ----------------------------------------------------------------------------
-- دو پرس‌وجوی ضدتقلبِ پرفرکانس روی جدول‌های بدون ایندکسمتناظر می‌زدند (full
-- table scan روی هر فراخوانی) و سیگنال «اثر انگشت مشترک بین کاربران» عملاً
-- ساختاریاً مرده بود:
--
--   ۱) SocialTaskExecutionModel::getRecentExecutionsByIp —
--      SELECT COUNT(DISTINCT executor_id) FROM social_task_executions
--      WHERE ip_address = ? AND executor_id != ? AND created_at >= ...
--      تنها ایندکس‌های موجود: idx_ste_final_score / idx_ste_overridden_by
--      → ایندکس ترکیبی (ip_address, created_at) هر دو شرط فیلتر را پوشش می‌دهد.
--
--   ۲) IpAndDeviceModel::getFingerprintUserCount + SocialTaskExecutionModel::
--      getSharedFingerprintUsers —
--      SELECT COUNT(DISTINCT user_id) FROM user_fingerprints
--      WHERE fingerprint = ? [AND user_id != ? / created_at > ...]
--      ⚠️ ریشه‌ای: UNIQUE قدیمی (fingerprint) یعنی هر اثر انگشت فقط یک سطر و یک
--      مالک دارد؛ upsert با ON DUPLICATE فقط seen_count مالکِ اول را بالا می‌برد
--      و ردیفِ کاربر دوم هرگز ثبت نمی‌شد → COUNT(DISTINCT user_id) همیشه ≤ ۱ و
--      getSharedFingerprintUsers همیشه ۰ → تشخیص «یک دستگاه، چند حساب» خاموش بود.
--      رفع: یکتایی به (fingerprint, user_id) منتقل شد؛ حالا کاربر دومِ همان دستگاه
--      ردیف خودش را می‌گیرد و شمارش واقعاً چند-کاربره است. نام ایندکس همان
--      idx_uf_fingerprint_user است که در مرور EXPLAIN بستهٔ R18 راستی‌آزمایی شد.
--
-- این مایگریشن idempotent است (IF [NOT] EXISTS) و داده‌ای حذف نمی‌کند؛
-- سازگار با MariaDB ≥ 10.4 (الگوی سایر مایگریشن‌های همین پوشه).
-- ============================================================================

-- ۱) social_task_executions: پوشش پرس‌وجوی «اجراهای اخیر از همین IP»
CREATE INDEX IF NOT EXISTS `idx_ste_ip_created`
  ON `social_task_executions` (`ip_address`, `created_at`);

-- ۲) user_fingerprints: جایگزینی یکتاییِ تک‌ستونه با یکتایی جفتی
--    (اول حذف ایندکس قدیمی، سپس ساخت ایندکس جدید — هردو گام idempotent)
DROP INDEX IF EXISTS `idx_fingerprint` ON `user_fingerprints`;

CREATE UNIQUE INDEX IF NOT EXISTS `idx_uf_fingerprint_user`
  ON `user_fingerprints` (`fingerprint`, `user_id`);
