-- ============================================================================
-- FIX-AT-PROOF (P1 گزارش S20 — اثبات پخش AdTube) — ستون‌های اثبات پخش واقعی
-- ----------------------------------------------------------------------------
-- مشکل گزارش: سرور فقط «دیوار-زمان» (started_at تا اکنون) و «ادعای سرعت»
-- (playback_speed تا 2.5x) را می‌سنجید ⇒ ۱۲ ثانیه حضور + ادعای 2.5x =
-- پاداش کامل ویدیوی ۳۰ثانیه‌ای بدون پخش حتی یک فریم.
--
-- قرارداد جدید (heartbeat): کلاینت هر ~۵ ثانیه وضعیت پلیر (PLAYING/ENDED/…)
-- و currentTime آن را می‌فرستد؛ سرور بستانکارِ پخش را «خودش» با دلتای ساعت
-- سرور محاسبه و در playing_seconds انبار می‌کند:
--   credit = min(پیشرویِ currentTime پلیر, دیوار-زمان سرور)  برای PLAYING
--          = دیوار-زمان سرور                              برای ENDED
--          = 0                                             برای سایر وضعیت‌ها
-- هیچ ضریب سرعتی پاداش را کوتاه نمی‌کند؛ پیشرویِ ادعاییِ غیرممکن
-- (> دیوار × maxSpeed + ۳s) بستانکار صفر می‌گیرد.
--
-- ستون‌ها:
--   playing_seconds   — جمع بستانکارِ تاییدشدهٔ پلیر (منبع نهایی progress)
--   last_heartbeat_at — مهر زمانی آخرین heartbeat پذیرفته‌شده (مبنای دلتای سرور)
--   last_player_time  — currentTime پلیر در آخرین heartbeat (مبنای پیشروی محتوا)
--
-- Idempotent (ADD COLUMN IF NOT EXISTS) — هم‌الگوی مایگریشن‌های همین پوشه؛
-- سازگار با MariaDB >= 10.4.
-- ============================================================================

ALTER TABLE `adtube_views`
  ADD COLUMN IF NOT EXISTS `playing_seconds` INT(10) UNSIGNED NOT NULL DEFAULT 0
    COMMENT 'verified playing seconds accumulated from server-measured heartbeats (FIX-AT-PROOF)'
    AFTER `watch_time`,
  ADD COLUMN IF NOT EXISTS `last_heartbeat_at` TIMESTAMP NULL DEFAULT NULL
    COMMENT 'server timestamp of the last accepted playback heartbeat (FIX-AT-PROOF)'
    AFTER `started_at`,
  ADD COLUMN IF NOT EXISTS `last_player_time` DECIMAL(12,3) UNSIGNED NOT NULL DEFAULT 0.000
    COMMENT 'player currentTime at the last accepted heartbeat (FIX-AT-PROOF)'
    AFTER `last_heartbeat_at`;
