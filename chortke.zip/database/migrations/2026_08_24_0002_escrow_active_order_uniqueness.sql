-- Prevent concurrent duplicate active escrow holds while allowing a new
-- lifecycle after a terminal escrow (released/refunded/cancelled).
ALTER TABLE escrow_transactions
  ADD COLUMN active_order_key VARCHAR(201)
    GENERATED ALWAYS AS (
      CASE WHEN status IN ('released','refunded','cancelled') THEN NULL
           ELSE CONCAT(order_type, ':', order_id)
      END
    ) STORED,
  ADD UNIQUE KEY uq_escrow_active_order (active_order_key);
