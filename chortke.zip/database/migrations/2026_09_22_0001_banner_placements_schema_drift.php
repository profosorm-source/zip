<?php
// ═══════════════════════════════════════════════════════════════════
// R35 — رفع دیفرم اسکیمای banner_placements با مدل BannerPlacement
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه: جدول (2026_06_10_0013_marketing_content.sql:18-25) فقط ۵ ستون
// دارد ولی مدل app/Models/BannerPlacement.php::$fillable ۱۴ ستون
// می‌شناسد ⇒ ۱۱ ستون غایب است:
//   title, page, position, show_on_mobile, show_on_desktop,
//   max_banners, rotation_speed, display_style, auto_rotate,
//   max_width, max_height
// پیامد: POST /admin/banners/placements/{id}/update با هر یک از این
// فیلدها → PDOException 42S22 (Unknown column) → 500
// (core/Database.php:741 rethrow). ویو views/admin/banners/placements.php
// روی page/max_banners هم undefined-property می‌دهد.
//
// انتخاب‌های نوع/پیش‌فرض (مطابق مصرف کد):
//   - max_banners INT UNSIGNED NOT NULL DEFAULT 5  == band-aid
//     BannerService:105 ($placementObj->max_banners ?? 5) و ==
//     پیش‌فرض getActiveBannersByPlacement (Ads.php:349) ⇒ رفتار خواندن
//     بعد از مایگریشن عیناً ثابت می‌ماند.
//   - display_style VARCHAR(20) NOT NULL DEFAULT 'grid' — عضو اول
//     whitelist مدل: ['grid','list','slider','carousel','single'].
//   - show_on_mobile/show_on_desktop TINYINT(1) NOT NULL DEFAULT 1 —
//     رفتار فعلی «نمایش در همه‌جا» حفظ می‌شود.
//   - auto_rotate TINYINT(1) NOT NULL DEFAULT 1، rotation_speed
//     INT UNSIGNED NOT NULL DEFAULT 5 — خواننده‌ای ندارد؛ مقدار ۵
//     (ثانیه) صرفاً future-proofing و مستند است.
//   - max_width/max_height SMALLINT UNSIGNED NULL — مدل clamp به
//     1..5000 می‌کند؛ NULL یعنی «بدون سقف».
//   - page VARCHAR(50) NOT NULL DEFAULT 'all' — فیلتر BannerPlacement::all()
//     «(page = :page OR page = 'all')» است؛ 'all' همان رفتار فعلی
//     (برگشتن همهٔ جایگاه‌ها) است.
//   - title VARCHAR(100) NULL + backfill یک‌بارهٔ title=name — جدول
//     ستون label را «name» می‌نامد ولی مدل/کنترلر «title» می‌نویسند؛
//     backfill از واگرایی جلوگیری می‌کند. name عمداً دست‌نخورده می‌ماند
//     (همهٔ ویوهای فعلی از name می‌خوانند).
//
// idempotent: گارد information_schema.COLUMNS برای هر ستون؛ اگر همه
// هست → SKIP تمیز. ردیابی: schema_migrations (checksum).
// بدون ایندکس جدید: UNIQUE slug از قبل هست و findBySlug را پوشش
// می‌دهد؛ جدول ۷ ردیفی است و فیلترهای page/is_active نیازی به ایندکس
// ندارند. تکراری‌های slug = صفر (بررسی R35).
// ═══════════════════════════════════════════════════════════════════

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r35_banner_placements_column_exists')) {
    function r35_banner_placements_column_exists(PDO $db, string $column): bool
    {
        $stmt = $db->prepare(
            "SELECT column_name
             FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE()
               AND table_name = 'banner_placements'
               AND column_name = ?
             LIMIT 1"
        );
        $stmt->execute([$column]);
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('r35_banner_placements_log')) {
    function r35_banner_placements_log(string $msg): void
    {
        echo '[r35-banner-placements-drift] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.r35_banner_placements_schema_drift', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

$columns = [
    'title'           => "ALTER TABLE banner_placements ADD COLUMN title VARCHAR(100) NULL DEFAULT NULL AFTER name",
    'page'            => "ALTER TABLE banner_placements ADD COLUMN page VARCHAR(50) NOT NULL DEFAULT 'all' AFTER slug",
    'position'        => "ALTER TABLE banner_placements ADD COLUMN position VARCHAR(50) NULL DEFAULT NULL AFTER page",
    'show_on_mobile'  => "ALTER TABLE banner_placements ADD COLUMN show_on_mobile TINYINT(1) NOT NULL DEFAULT 1 AFTER is_active",
    'show_on_desktop' => "ALTER TABLE banner_placements ADD COLUMN show_on_desktop TINYINT(1) NOT NULL DEFAULT 1 AFTER show_on_mobile",
    'max_banners'     => "ALTER TABLE banner_placements ADD COLUMN max_banners INT UNSIGNED NOT NULL DEFAULT 5 AFTER show_on_desktop",
    'rotation_speed'  => "ALTER TABLE banner_placements ADD COLUMN rotation_speed INT UNSIGNED NOT NULL DEFAULT 5 AFTER max_banners",
    'display_style'   => "ALTER TABLE banner_placements ADD COLUMN display_style VARCHAR(20) NOT NULL DEFAULT 'grid' AFTER rotation_speed",
    'auto_rotate'     => "ALTER TABLE banner_placements ADD COLUMN auto_rotate TINYINT(1) NOT NULL DEFAULT 1 AFTER display_style",
    'max_width'       => "ALTER TABLE banner_placements ADD COLUMN max_width SMALLINT UNSIGNED NULL DEFAULT NULL AFTER auto_rotate",
    'max_height'      => "ALTER TABLE banner_placements ADD COLUMN max_height SMALLINT UNSIGNED NULL DEFAULT NULL AFTER max_width",
];

$missing = [];
foreach (array_keys($columns) as $column) {
    if (!r35_banner_placements_column_exists($db, $column)) {
        $missing[] = $column;
    }
}

if ($missing === []) {
    r35_banner_placements_log('SKIP: هر ۱۱ ستون از قبل وجود دارند (idempotent).');
    return; // پایان تمیزِ فایل مایگریشن
}

foreach ($missing as $column) {
    $db->exec($columns[$column]);
    r35_banner_placements_log("OK: ستون {$column} اضافه شد.");
}

// Backfill یک‌بارهٔ title از name (فقط NULLها — idempotent، جلوگیری از
// واگرایی name/title که مدل و ویو به دو نام می‌خوانند).
if (in_array('title', $missing, true)) {
    $updated = $db->exec("UPDATE banner_placements SET title = name WHERE title IS NULL");
    r35_banner_placements_log("BACKFILL: title={$updated} ردیف از name کپی شد.");
}

r35_banner_placements_log('DONE: banner_placements اکنون با $fillable مدل هم‌تراز است (۱۶ ستون).');
