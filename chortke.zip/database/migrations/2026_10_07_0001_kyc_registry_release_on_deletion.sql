-- ═══════════════════════════════════════════════════════════════════
-- FIX-S31 (یادداشت worklog راند ۳۰) — آزادسازی رجیستری کد ملی هنگام حذف حساب
-- ═══════════════════════════════════════════════════════════════════
-- رفتار پیشین (عمدیِ ضدتقلبی): ردیفِ kyc_national_code_registry پس از حذف حساب
--   تا ابد claimed می‌ماند ⇒ کد ملیِ کاربرِ حذف‌شده برای همیشه — حتی برای خودِ
--   شخصِ واقعی پس از ثبت‌نام مجدد — قابلِ تأیید KYC نیست (گیتِ verify پیام
--   «این کد ملی پیش‌تر به حساب دیگری تعلق گرفته» می‌دهد).
-- رفتار جدید (آزادسازیِ نرم — soft release):
--   ① ردیف registry «حذف» نمی‌شود؛ با released_at/release_reason آزادِ منطقی
--      می‌شود (ساگای حذف حساب، داخل تراکنش — FIX-S31 در AccountDeletionService).
--      هشِ HMAC شبه‌ناشناس + ردیفِ آزادشده ردپای حسابرسی/ضدتقلب را حفظ می‌کند.
--   ② claimNationalCodeInTx ردیفِ آزادشده را برای کاربرِ جدید «بازپس می‌گیرد»
--      (re-claim) و claim_count را یک واحد افزایش می‌دهد — شمارشِ استفادهٔ یک
--      کد ملی در طول عمرِ سیستم برای تحلیلِ ضدتقلب (شناساییِ چرخش حساب).
--   ③ backfill یک‌باره: ردیف‌های کاربرانی که «پیش از این فیکس» حذف شده‌اند
--      (users.status='deleted' و registry.released_at IS NULL) با همین
--      migration آزاد می‌شوند تا هیچ قربانیِ قدیمیِ رفتارِ پیشین باقی نماند.
-- ═══════════════════════════════════════════════════════════════════

ALTER TABLE kyc_national_code_registry
    ADD COLUMN released_at DATETIME NULL DEFAULT NULL AFTER kyc_id,
    ADD COLUMN release_reason VARCHAR(64) NULL DEFAULT NULL AFTER released_at,
    ADD COLUMN claim_count INT UNSIGNED NOT NULL DEFAULT 1 AFTER release_reason,
    ADD KEY idx_ncr_released (released_at);

-- backfill یک‌بارهٔ ردیف‌های یتیمِ رفتارِ پیشین (کاربرِ حذف‌شده + هنوز claimed)
-- زمانِ آزادسازی = زمانِ حذفِ کاربر (deleted_at) برای دقتِ حسابرسی
UPDATE kyc_national_code_registry r
JOIN users u ON u.id = r.user_id
SET r.released_at = COALESCE(u.deleted_at, NOW()),
    r.release_reason = 'legacy_backfill'
WHERE u.status = 'deleted'
  AND r.released_at IS NULL;
