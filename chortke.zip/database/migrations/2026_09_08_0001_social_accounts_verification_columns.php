<?php
// FIX-X286 (راند ۶۵): ستون‌های حسابرسیِ تایید/رد برای user_social_accounts
//
// تصمیم محصولی مصوب مالک (گزینهٔ الف): جدول user_social_accounts ستون‌های
// rejection_reason / verified_by / verified_at را هرگز نداشت؛ در فیکس X285
// نویسنده‌ها حذف شده بودند (workaround «فقط فلپ وضعیت»)، در نتیجه:
//   - کاربر ردشده دلیل رد را فقط یک‌بار در نوتیفیکیشن می‌دید و هیچ ردپای
//     ماندگاری در DB نبود (ویوهای آمادهٔ نمایش بی‌داده می‌ماندند).
//   - هیچ سابقه‌ای از «کدام ادمین، کِی تأیید کرد» ثبت نمی‌شد (حسابرسی کور).
// این مایگریشن سه ستون nullable/additive اضافه می‌کند و هم‌زمان در
// SocialAccountService::verify/reject مقادیر واقعی نوشته می‌شوند.
// فایل کاملاً idempotent است (اجرای مجدد = بدون عملیات).
//
//.Generated: 2026-09-08

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('x286_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function x286_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

$table = 'user_social_accounts';

// دلیل رد — متن ادمین هنگام reject (کاربر در «حساب‌های من» می‌بیند)
if (!x286_column_exists($db, $table, 'rejection_reason')) {
    $db->exec("ALTER TABLE `{$table}` ADD COLUMN `rejection_reason` VARCHAR(500) NULL DEFAULT NULL
               AFTER `status`");
}

// حسابرسی تایید — کدام ادمین
if (!x286_column_exists($db, $table, 'verified_by')) {
    $db->exec("ALTER TABLE `{$table}` ADD COLUMN `verified_by` INT UNSIGNED NULL DEFAULT NULL
               AFTER `rejection_reason`");
}

// حسابرسی تایید — کِی
if (!x286_column_exists($db, $table, 'verified_at')) {
    $db->exec("ALTER TABLE `{$table}` ADD COLUMN `verified_at` DATETIME NULL DEFAULT NULL
               AFTER `verified_by`");
}

echo "migration 2026_09_08_0001_social_accounts_verification_columns: OK\n";
