<?php
// FIX-X148: ستون‌های جاافتادهٔ user_level_history (راند ۳۷)
//
// کشف با باتری e2e راند ۳۷: مدل UserLevelHistory::createHistory ستون‌های
// metadata (JSON مزایا/قیمت خرید) و ip_address را INSERT می‌کند و
// verifySignature هر دو را در امضای HMAC می‌خواند، اما جدول این دو ستون را
// هرگز نداشت → «Unknown column 'metadata'» → کل جریان‌های تاریخچهٔ سطح:
//   - خرید سطح (purchaseLevel) → خطای ۴۲۲ «خطای سیستمی در فرآیند خرید» (بحرانی)
//   - ارتقای خودکار/تنزل/انقضا → تاریخچه بی‌صدا ثبت نمی‌شد (حافظهٔ چرخهٔ لول‌آپ کور)
// فیکس ریشه‌ای = ساختن ستون‌ها. این فایل کاملاً idempotent است.
//
// Generated: 2026-09-04

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r37_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r37_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

$table = 'user_level_history';

if (!r37_column_exists($db, $table, 'metadata')) {
    $db->exec("ALTER TABLE `{$table}` ADD COLUMN `metadata` LONGTEXT NULL DEFAULT NULL
               AFTER `reason`");
}

if (!r37_column_exists($db, $table, 'ip_address')) {
    $db->exec("ALTER TABLE `{$table}` ADD COLUMN `ip_address` VARCHAR(45) NULL DEFAULT NULL
               AFTER `metadata`");
}

echo "migration 2026_09_04_0001_user_level_history_columns: OK\n";
