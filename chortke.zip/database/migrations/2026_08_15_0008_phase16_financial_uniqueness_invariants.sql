-- Database-owned concurrency invariants for Phase 16 financial lifecycles.
-- Service pre-checks and row locks improve messages, but uniqueness must survive
-- concurrent requests that both observe an initially empty result set.

-- COMPAT-MYSQL-ROUND65: STORED generated column on an FK-bearing table is rejected
-- by Oracle MySQL 8.4 (1215); VIRTUAL is portable (MariaDB 10.2+ + MySQL 8.0+) and
-- semantically equivalent for the unique-index invariant below.
ALTER TABLE `investments`
  ADD COLUMN IF NOT EXISTS `active_user_id` INT(10) UNSIGNED
    GENERATED ALWAYS AS (CASE WHEN `status` = 'active' AND `deleted_at` IS NULL THEN `user_id` ELSE NULL END) VIRTUAL;
CREATE UNIQUE INDEX IF NOT EXISTS `uq_investments_one_active_per_user`
  ON `investments` (`active_user_id`);

CREATE UNIQUE INDEX IF NOT EXISTS `uq_prediction_bets_user_game`
  ON `prediction_bets` (`user_id`, `game_id`);
