-- =============================================================================
-- FIX-M11-C1 (گزارش بازبینی عمیق ماژول ۱۱ — یافتهٔ بحرانی C1)
-- جداسازی «نسخهٔ secret هش refresh token» از «نسخهٔ secret هش access token»
-- =============================================================================
-- مشکل ریشه‌ای: ApiAuthMiddleware هنگام چرخش secret فقط `token` و `secret_version`
-- را به نسخهٔ جدید می‌برد؛ `refresh_token` با secret قدیمی هش شده می‌ماند.
-- findByRefreshToken() با شرط `refresh_token=? AND secret_version=?` جستجو می‌کند
-- ⇒ بعد از چرخش، refresh token یتیم می‌شود (هش با secret قدیم، ردیف با نسخهٔ جدید)
-- و کاربر تا انقضا نمی‌تواند توکن را نوسازی کند.
--
-- راه‌حل: ستون مستقل refresh_secret_version — نسخهٔ secretی که refresh با آن
-- هش شده است. چرخش access فقط access را می‌چرخاند؛ refresh روی نسخهٔ خودش
-- معتبر می‌ماند و در اولین RTR بعدی، جفت تازه با نسخهٔ جاری بازتولید می‌شود.
-- =============================================================================

ALTER TABLE `api_tokens`
  ADD COLUMN IF NOT EXISTS `refresh_secret_version` VARCHAR(20) NULL AFTER `secret_version`;

-- Backfill: در لحظهٔ صدور، access و refresh هر دو با «همان» secret هش شده‌اند؛
-- پس مقدار اولیهٔ معتبر برای ردیف‌های موجود، همان secret_version ردیف است.
UPDATE `api_tokens`
   SET `refresh_secret_version` = `secret_version`
 WHERE `refresh_token` IS NOT NULL
   AND (`refresh_secret_version` IS NULL OR `refresh_secret_version` = '');
