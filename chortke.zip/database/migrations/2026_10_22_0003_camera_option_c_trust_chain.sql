-- ============================================================================
-- F21-01 — Camera Verifier Trust Chain (Option C) — 2026-10-22 / rebuild 2026-10-24
-- گام ۱ از ۲: ستون‌های زنجیرهٔ اعتماد روی social_camera_requests
-- ----------------------------------------------------------------------------
-- معماری «گزینهٔ C» (هیبرید اعتماد):
--   * nonce یک‌بارمصرف: سرور nonce صادر می‌کند، DB فقط sha256(nonce) را نگه
--     می‌دارد (D2)؛ متنِ آشکار nonce هرگز ذخیره نمی‌شود.
--   * مصرف nonce با یک UPDATE اتمیِ چندشرطی انجام می‌شود (replay-proof).
--   * D1 spot-check: با نسبت camera_spot_check_ratio، سرور یک اسنپ‌شات JPEG
--     کوچک (≤320px، ≤60KB) می‌گیرد؛ فقط در حافظه تحلیل می‌شود و هرگز روی
--     دیسک/DB نوشته نمی‌شود.
--   * D3 attestation (Play Integrity): صرفاً «تقویت‌گر» است؛ بدون کلید،
--     تزئینی و fail-open در ثبت، بدون اثر بر امتیاز.
-- این مهاجرت idempotent است (IF NOT EXISTS) و داده‌ای حذف نمی‌کند.
-- ============================================================================

ALTER TABLE `social_camera_requests`
  ADD COLUMN IF NOT EXISTS `nonce_hash`         CHAR(64)    NULL DEFAULT NULL AFTER `user_id`,
  ADD COLUMN IF NOT EXISTS `nonce_issued_at`    TIMESTAMP   NULL DEFAULT NULL AFTER `nonce_hash`,
  ADD COLUMN IF NOT EXISTS `nonce_consumed_at`  TIMESTAMP   NULL DEFAULT NULL AFTER `nonce_issued_at`,
  ADD COLUMN IF NOT EXISTS `spot_required`      TINYINT(1)  NOT NULL DEFAULT 0 AFTER `nonce_consumed_at`,
  ADD COLUMN IF NOT EXISTS `spot_consent`       TINYINT(1)  NOT NULL DEFAULT 0 AFTER `spot_required`,
  ADD COLUMN IF NOT EXISTS `spot_check_status`  VARCHAR(20) NULL DEFAULT NULL AFTER `spot_consent`,
  ADD COLUMN IF NOT EXISTS `spot_check_at`      TIMESTAMP   NULL DEFAULT NULL AFTER `spot_check_status`,
  ADD COLUMN IF NOT EXISTS `attestation_status` VARCHAR(20) NULL DEFAULT NULL AFTER `spot_check_at`;

-- جست‌وجوی پزشکی-جرمی روی هش nonce (مصرفِ اتمی خودش با id+hash انجام می‌شود)
CREATE INDEX IF NOT EXISTS `idx_scr_nonce_hash` ON `social_camera_requests` (`nonce_hash`);
