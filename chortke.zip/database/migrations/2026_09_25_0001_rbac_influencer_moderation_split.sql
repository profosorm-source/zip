-- ============================================================================
-- AUDIT-FIX (RBAC audit R1 / Admin-controllers audit): split influencer
-- moderation from influencer visibility.
--
-- Finding: the support role was seeded with `influencer.manage`. Because
-- InfluencerController's route-guard default was `influencer.manage`, every
-- support account could approve/reject/suspend influencer profiles and
-- approve/reject verifications (operations that belong to full admins).
--
-- Root-cause remediation:
--   ① new dedicated permission `influencer.moderate` for moderation actions,
--      granted ONLY to admin + super_admin;
--   ② support is downgraded to read-only: gets `influencer.view`, loses
--      `influencer.manage` (defense in depth is added at the service layer in
--      VerificationService and the route map is split in
--      config/admin_permissions.php).
--
-- Idempotent: INSERTs are guarded, the DELETE is a no-op when the grant does
-- not exist. Safe to re-run. No schema change → runs inside a transaction.
-- ============================================================================

-- ① dedicated moderation permission
INSERT INTO permissions (`name`, `slug`, `group_name`, `description`, `created_at`, `updated_at`)
SELECT 'مدیریت اینفلوئنسرها — مودریشن', 'influencer.moderate', 'admin',
       'Approve/reject/suspend influencer profiles and influencer verifications',
       NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE slug = 'influencer.moderate');

-- ② moderation belongs to admin + super_admin only
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
JOIN permissions p ON p.slug = 'influencer.moderate'
WHERE r.slug IN ('admin', 'super_admin');

-- ③ support keeps read-only visibility of the influencer area
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
JOIN permissions p ON p.slug = 'influencer.view'
WHERE r.slug = 'support';

-- ④ remove the over-broad grant that made moderation reachable by support
DELETE rp
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
JOIN permissions p ON p.id = rp.permission_id
WHERE r.slug = 'support'
  AND p.slug IN ('influencer.manage', 'influencer.moderate');
