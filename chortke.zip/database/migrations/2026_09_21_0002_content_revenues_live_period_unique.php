<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-R31-C2 — UNIQUE «دورهٔ زنده» برای content_revenues با ستون تولیدشده
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه: ContentRevenue::existsForPeriod() (app/Models/
// ContentRevenue.php:251-257) فقط ردیف‌های is_deleted=0 را می‌شمارد و
// سپس create() رکورد درآمد را INSERT می‌کند ← ریس TOCTOU: دو درخواست
// هم‌زمان برای یک (submission_id, period) هر دو از existsForPeriod()
// با false رد می‌شوند و «دو رکورد درآمد» (مالی!) ساخته می‌شود. تنها
// ایندکسِ مرتبط، idx_content_revenues_submission_period
// (submission_id, period) است که UNIQUE نیست.
//
// چرا UNIQUE ساده روی (submission_id, period) غلط است؟ جدول soft-delete
// دارد: ردیف‌های is_deleted=1 باید اجازهٔ «استفادهٔ مجدد» از همان
// (submission_id, period) را بدهند؛ UNIQUE ساده، ردیفِ حذف‌شده را
// جلوی رکورد جدید می‌نشاند. MariaDB partial index ندارد ← ستون
// تولیدشدهٔ STORED به نام live_period_key:
//     ردیف زندهٔ کامل   = CONCAT(submission_id, ':', period)
//     حذف‌شده/ناقص      = NULL
// و چون ایندکس UNIQUE در MySQL/MariaDB چند NULL را می‌پذیرد، فقط
// ردیف‌های زنده با هم درگیر قید یکتایی می‌شوند (معادل partial unique).
//
// ۱) گارد ۱: اگر UNIQUE به نام uq_content_revenues_live_period از قبل
//    هست ← SKIP + return تمیز (idempotent).
// ۲) گارد ۲: اگر ستون live_period_key نیست، با ALTER اضافه می‌شود
//    (بررسی information_schema.COLUMNS).
// ۳) جداسازی تکراری‌های زنده (الگوی keep-MIN(id)، 2026_09_20_0003):
//    برای هر (submission_id, period) با is_deleted=0 کمترین id نگه
//    داشته می‌شود و بقیه حذف می‌شوند.
// ۴) ساخت UNIQUE KEY uq_content_revenues_live_period (live_period_key).
//
// عمداً idx_content_revenues_submission_period حذف نمی‌شود: ایندکسِ
// ستون تولیدشده نمی‌تواند query plan های SELECT ... WHERE
// submission_id = ? AND period = ? را پوشش دهد؛ ایندکس قدیمی برای
// برنامه‌های پرس‌وجوی ستون‌های خام می‌ماند.
//
// رفتار بعد از مایگریشن: بازندهٔ ریس به‌جای «دو رکورد درآمد / دو بار
// پرداخت»، duplicate-key exception می‌گیرد (fail-loud به‌جای double-pay)
// — این رفتار عمدی و موردنظر است.
// ═══════════════════════════════════════════════════════════════════

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r31b_content_revenues_unique_index_exists')) {
    /** آیا UNIQUE index به نام uq_content_revenues_live_period هست؟ */
    function r31b_content_revenues_unique_index_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT index_name
             FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = 'content_revenues'
               AND index_name = 'uq_content_revenues_live_period'
               AND non_unique = 0
             LIMIT 1"
        );
        $stmt->execute();
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('r31b_content_revenues_column_exists')) {
    /** آیا ستون live_period_key روی content_revenues تعریف شده است؟ */
    function r31b_content_revenues_column_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT column_name
             FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE()
               AND table_name = 'content_revenues'
               AND column_name = 'live_period_key'
             LIMIT 1"
        );
        $stmt->execute();
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('r31b_content_revenues_live_dup_rows_count')) {
    /**
     * تعداد ردیف‌های زندهٔ تکراری که باید حذف شوند: برای هر
     * (submission_id, period) با is_deleted=0 و غیر-NULL،
     * (اندازهٔ گروه - ۱) — جمع روی همهٔ گروه‌ها.
     */
    function r31b_content_revenues_live_dup_rows_count(PDO $db): int
    {
        $stmt = $db->prepare(
            "SELECT COALESCE(SUM(c - 1), 0) FROM (
                 SELECT COUNT(*) AS c
                 FROM content_revenues
                 WHERE is_deleted = 0 AND submission_id IS NOT NULL AND period IS NOT NULL
                 GROUP BY submission_id, period
                 HAVING COUNT(*) > 1
             ) AS dup_groups"
        );
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }
}

if (!function_exists('r31b_content_revenues_log')) {
    function r31b_content_revenues_log(string $msg): void
    {
        echo '[r31-content-revenues-unique] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.r31b_content_revenues_live_period_unique', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

if (r31b_content_revenues_unique_index_exists($db)) {
    r31b_content_revenues_log('SKIP: UNIQUE index uq_content_revenues_live_period از قبل وجود دارد (idempotent).');
    return; // پایان تمیزِ فایل مایگریشن (بدون interrupt کردن runner)
}

// گارد ۲: افزودن ستون تولیدشدهٔ STORED فقط اگر از قبل نیست (idempotent)
if (!r31b_content_revenues_column_exists($db)) {
    $db->exec(
        "ALTER TABLE content_revenues
         ADD COLUMN live_period_key VARCHAR(64) GENERATED ALWAYS AS
           (IF(is_deleted = 0 AND submission_id IS NOT NULL AND period IS NOT NULL,
               CONCAT(submission_id, ':', period),
               NULL)) STORED"
    );
    r31b_content_revenues_log('OK: ستون تولیدشدهٔ STORED live_period_key اضافه شد (NULL برای ردیف‌های soft-deleted/ناقص).');
} else {
    r31b_content_revenues_log('SKIP-COLUMN: ستون live_period_key از قبل وجود دارد.');
}

// ۱) جداسازی تکراری‌های زنده: نگه‌داشتن کمترین id برای هر (submission_id, period)
$dupRows = r31b_content_revenues_live_dup_rows_count($db);
if ($dupRows > 0) {
    $deleted = $db->exec(
        'DELETE t1 FROM content_revenues t1
         JOIN content_revenues t2
           ON t2.submission_id = t1.submission_id
          AND t2.period = t1.period
          AND t2.id < t1.id
         WHERE t1.is_deleted = 0
           AND t1.submission_id IS NOT NULL
           AND t1.period IS NOT NULL
           AND t2.is_deleted = 0'
    );
    r31b_content_revenues_log("DEDUPE: {$deleted} ردیف درآمد تکراری حذف شد (برآورد پیش از حذف: {$dupRows}).");
} else {
    r31b_content_revenues_log('DEDUPE: ردیف زندهٔ تکراری وجود ندارد — جداسازی انجام نشد.');
}

// ۲) ساخت UNIQUE روی ستون تولیدشده (جایگزین idx_content_revenues_submission_period نیست)
$db->exec('ALTER TABLE content_revenues ADD UNIQUE KEY uq_content_revenues_live_period (live_period_key)');
r31b_content_revenues_log('OK: UNIQUE KEY uq_content_revenues_live_period (live_period_key) ساخته شد — idx_content_revenues_submission_period عمداً حفظ شد (پوشش query plan ستون‌های خام).');
r31b_content_revenues_log('NOTE: live_period_key برای ردیف‌های soft-deleted/ناقص NULL است و ایندکس UNIQUE چند NULL را می‌پذیرد — حذف نرم، استفادهٔ مجدد از (submission_id, period) را مسدود نمی‌کند.');
