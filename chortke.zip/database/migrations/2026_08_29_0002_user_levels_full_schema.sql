-- FIX-T7 (باگ X): جدول user_levels در مایگریشن 2026_06_10_0006 مینیمال ساخته شد
-- (7 ستون) در حالی که مدل UserLevel، کنترلر ادمین و فرم create/edit روی اسکیمای
-- کامل کار می‌کنند → هر create/update سطح از پنل ادمین با
-- «Unknown column 'icon' in 'INSERT INTO'» به 500 می‌خورد (CRUD سطح کاملاً مرده).
-- این مایگریشن ستون‌های جاافتاده را idempotent اضافه می‌کند (MariaDB: IF NOT EXISTS).
ALTER TABLE `user_levels`
    ADD COLUMN IF NOT EXISTS `icon` VARCHAR(64) NOT NULL DEFAULT 'workspace_premium' AFTER `slug`,
    ADD COLUMN IF NOT EXISTS `color` VARCHAR(20) NOT NULL DEFAULT '#c0c0c0' AFTER `icon`,
    ADD COLUMN IF NOT EXISTS `min_active_days` INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `min_score`,
    ADD COLUMN IF NOT EXISTS `min_completed_tasks` INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `min_active_days`,
    ADD COLUMN IF NOT EXISTS `min_total_earning` DECIMAL(24,4) NOT NULL DEFAULT 0 AFTER `min_completed_tasks`,
    ADD COLUMN IF NOT EXISTS `min_total_earning_usdt` DECIMAL(24,4) NOT NULL DEFAULT 0 AFTER `min_total_earning`,
    ADD COLUMN IF NOT EXISTS `purchase_price_irt` DECIMAL(24,4) NOT NULL DEFAULT 0 AFTER `min_total_earning_usdt`,
    ADD COLUMN IF NOT EXISTS `purchase_price_usdt` DECIMAL(24,4) NOT NULL DEFAULT 0 AFTER `purchase_price_irt`,
    ADD COLUMN IF NOT EXISTS `purchase_duration_days` INT(10) UNSIGNED NOT NULL DEFAULT 30 AFTER `purchase_price_usdt`,
    ADD COLUMN IF NOT EXISTS `earning_bonus_percent` DECIMAL(8,2) NOT NULL DEFAULT 0 AFTER `purchase_duration_days`,
    ADD COLUMN IF NOT EXISTS `referral_bonus_percent` DECIMAL(8,2) NOT NULL DEFAULT 0 AFTER `earning_bonus_percent`,
    ADD COLUMN IF NOT EXISTS `daily_task_limit_bonus` INT(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `referral_bonus_percent`,
    ADD COLUMN IF NOT EXISTS `withdrawal_limit_bonus` DECIMAL(24,4) NOT NULL DEFAULT 0 AFTER `daily_task_limit_bonus`,
    ADD COLUMN IF NOT EXISTS `priority_support` TINYINT(1) NOT NULL DEFAULT 0 AFTER `withdrawal_limit_bonus`,
    ADD COLUMN IF NOT EXISTS `special_badge` TINYINT(1) NOT NULL DEFAULT 0 AFTER `priority_support`,
    ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP NULL DEFAULT NULL AFTER `created_at`;
