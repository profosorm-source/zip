<?php
// ═══════════════════════════════════════════════════════════════════
// X321 (تسک ۸۳) — گشادسازی interactions.context
// ═══════════════════════════════════════════════════════════════════
//
// پیش‌زمینه: InteractionModel::createReport (راند ۷۷) متادیتای گزارش را
// به‌صورت JSON داخل ستون context ادغام می‌کند:
//   {"context":"global","meta":{"reason":"...","description":"...","status":"pending"}}
// ReportInteractionRequest تا ۱۰۰ کاراکتر reason و ۱۰۰۰ کاراکتر
// description می‌پذیرد، ولی ستون context فقط VARCHAR(50) است → هر
// گزارشِ واقعی (POST /report) با SQL error (strict mode) یا truncate
// خاموش می‌شد؛ مسیر گزارش‌دهی کاربر عملاً مرده بود.
//
// راه‌حل: MODIFY به TEXT (بدون ایندکس روی context — امن). Idempotent:
// فقط وقتی DATA_TYPE هنوز متنی-کوتاه است اجرا می‌شود. روی MySQL 8 هم
// همین DDL معتبر است. Generated: 2026-09-11

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

$stmt = $db->prepare(
    "SELECT DATA_TYPE FROM information_schema.columns
     WHERE table_schema = DATABASE() AND table_name = 'interactions' AND column_name = 'context'"
);
$stmt->execute();
$dataType = (string) ($stmt->fetchColumn() ?: '');

if ($dataType === 'text') {
    echo 'migration 2026_09_11_0002_interactions_context_widen: OK (already TEXT, skipped=1, applied=0)' . "\n";
    // 🛡️ FIX-S19-3: exit(0) → return؛ این فایل include in-process است و return
    // کامل‌ترین skip تمیز است (مقدار غیر-شیء توسط MigrationService نادیده گرفته می‌شود).
    return 0;
}

if ($dataType === '') {
    fwrite(STDERR, "migration 2026_09_11_0002_interactions_context_widen: FAILED (interactions.context not found)\n");
    // 🛡️ FIX-S19-3: exit(1) → Exception (fail-loud بدون قطع پروسهٔ میزبان).
    throw new RuntimeException('interactions_context_widen failed: interactions.context column not found');
}

$db->exec('ALTER TABLE `interactions` MODIFY `context` TEXT NULL');

echo 'migration 2026_09_11_0002_interactions_context_widen: OK'
    . " (server=mariadb, from={$dataType}, applied=1, skipped=0)\n";
