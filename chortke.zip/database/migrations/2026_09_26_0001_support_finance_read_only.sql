-- Keep the support role read-only across financial admin modules.
-- This is idempotent and also repairs databases that received a broader
-- permission grant before the RBAC read-only contract was finalized.
DELETE rp
FROM role_permissions rp
JOIN roles r ON r.id = rp.role_id
JOIN permissions p ON p.id = rp.permission_id
WHERE r.slug = 'support'
  AND p.slug IN (
    'finance.card.approve',
    'finance.deposit.approve',
    'finance.crypto.approve',
    'finance.withdrawal.approve',
    'finance.transaction.approve'
  );
