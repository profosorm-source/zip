<?php
// ═══════════════════════════════════════════════════════════════════
// COMPAT-MYSQL8 (تسک 76-B) — جایگزینِ فایل SQL هم‌نام
// (2026_08_15_0007_phase16_financial_uniqueness_invariants.sql)
// ═══════════════════════════════════════════════════════════════════
//
// واگرایی MariaDB / Oracle MySQL 8 روی جدول `investments`:
//
//   • MariaDB اجازه می‌دهد FOREIGN KEY روی «ستون پایهٔ» یک ستون generated از
//     نوع STORED تعریف شود؛ MySQL 8 همین کار را با ERROR 1215 (errno 150)
//     رد می‌کند، چون UPDATEهای CASCADE باید ستون STORED را هم بازنویسی کنند.
//   • `active_user_id` STORED است و ستون پایه‌اش `user_id`؛ قید FK
//     `fk_investment_user` (از مایگریشن 2026_06_16_0003) روی همان `user_id`
//     تعریف می‌شود. پس در MySQL، وجودِ این ستون STORED با FK ناسازگار است.
//
// رفتار این مایگریشن (تشخیص سرور با SELECT VERSION()):
//
//   • MariaDB → دقیقاً همان شمای مرجع: ستون STORED + ایندکس یونیک
//     `uq_investments_one_active_per_user` + FK. تغییر صفر نسبت به قبل.
//   • MySQL → FK به‌طور عادی از 2026_06_16_0003 ساخته می‌شود (در آن نقطه هنوز
//     ستون generated وجود ندارد و FK سالم درمی‌آید) و این فایل عمداً
//     `active_user_id` و ایندکس یونیکش را نمی‌سازد — انحراف مستند از مرجع
//     MariaDB، عین همان کاری که ایمپورت موفق دامپ در MySQL 8.0.36 انجام داد.
//     قید یکتایی «یک سرمایه‌گذاری فعال برای هر کاربر» در نصب‌های MySQL فقط با
//     pre-check سرویس اعمال می‌شود (به‌جای قید سطح دیتابیس).
//   • اگر در نصب MySQL ستون generated از قبل موجود باشد (نصب‌های واسط)، دست
//     زده نمی‌شود — این فایل فقط «ساخت» را مدیریت می‌کند، نه حذف.
//
// `uq_prediction_bets_user_game` با هر دو موتور سازگار است و در هر دو ساخته
// می‌شود (مانند فایل اصلی).
//
// فایل کاملاً idempotent است (الگوی گاردهای r75_column_exists در
// 2026_09_05_0001). Generated: 2026-09-09

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r76b_is_mariadb')) {
    /**
     * تشخیص سرور: MySQL 8 اجازهٔ FK روی ستون پایهٔ generated STORED را نمی‌دهد (MariaDB می‌دهد).
     * رشتهٔ نسخهٔ MariaDB همیشه شامل "MariaDB" است (مثل "11.8.6-MariaDB").
     */
    function r76b_is_mariadb(PDO $pdo): bool
    {
        return (bool) stripos((string) $pdo->query('SELECT VERSION()')->fetchColumn(), 'mariadb');
    }
}

if (!function_exists('r76b_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r76b_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r76b_index_exists')) {
    /** آیا ایندکس با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r76b_index_exists(PDO $db, string $table, string $index): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.statistics
             WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?'
        );
        $stmt->execute([$table, $index]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r76b_fk_exists')) {
    /** آیا قید FK با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function r76b_fk_exists(PDO $db, string $table, string $constraint): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.referential_constraints
             WHERE constraint_schema = DATABASE() AND table_name = ? AND constraint_name = ?'
        );
        $stmt->execute([$table, $constraint]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

$isMariaDB = r76b_is_mariadb($db);
$applied   = 0;
$skipped   = 0;

// ── ① investments.active_user_id + ایندکس یونیکِ آن (فقط MariaDB) ──
if ($isMariaDB) {
    if (!r76b_column_exists($db, 'investments', 'active_user_id')) {
        // عین همین عبارت در فایل SQL حذف‌شده بود؛ STORED = سمانتیک مرجع MariaDB
        $db->exec("ALTER TABLE `investments`
            ADD COLUMN `active_user_id` INT(10) UNSIGNED
              GENERATED ALWAYS AS (CASE WHEN `status` = 'active' AND `deleted_at` IS NULL THEN `user_id` ELSE NULL END) STORED");
        $applied++;
    } else {
        $skipped++;
    }

    if (!r76b_index_exists($db, 'investments', 'uq_investments_one_active_per_user')) {
        $db->exec("CREATE UNIQUE INDEX `uq_investments_one_active_per_user` ON `investments` (`active_user_id`)");
        $applied++;
    } else {
        $skipped++;
    }
} else {
    // مسیر MySQL: ساختِ صریحِ FK (اگر از 0003 نیامده باشد) + پرش مستند از ستون
    // generated و ایندکسش — ERROR 1215 روی MySQL اجازهٔ ترکیبشان را نمی‌دهد.
    if (!r76b_fk_exists($db, 'investments', 'fk_investment_user')) {
        $db->exec("ALTER TABLE `investments`
            ADD CONSTRAINT `fk_investment_user`
            FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE");
        $applied++;
    } else {
        $skipped++;
    }

    // ستون generated عمداً ساخته نمی‌شود (skip مستند). اگر در نصب واسط MySQL از
    // مسیر قدیمی موجود باشد هم دست زده نمی‌شود — این فایل فقط «ساخت» را مدیریت می‌کند.
    $skipped++;
}

// ── ② قید یکتایی prediction_bets (هر دو موتور — بدون واگرایی) ──
if (!r76b_index_exists($db, 'prediction_bets', 'uq_prediction_bets_user_game')) {
    $db->exec("CREATE UNIQUE INDEX `uq_prediction_bets_user_game` ON `prediction_bets` (`user_id`, `game_id`)");
    $applied++;
} else {
    $skipped++;
}

echo 'migration 2026_08_15_0007_phase16_financial_uniqueness_invariants: OK'
    . ' (server=' . ($isMariaDB ? 'mariadb' : 'mysql')
    . ", applied={$applied}, skipped={$skipped})\n";
