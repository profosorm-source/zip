<?php
// FIX-X289/X292/X293/X294 (راند ۷۱): ستون‌های مصوب مأموریت ستون‌شبح — بخش مایگریشن
//
// اسکنر ستون‌شبح (qa/round65_ghost_scan.md) ۶۰ خوشهٔ «نوشتن به ستون ناموجود» را
// نشان داد. تحلیل هر خوشه سه دسته ساخت:
//   (۱) هم‌ترازی کد با اسکیمای واقعی (بدون مایگریشن) — در همین راند اعمال شد.
//   (۲) ستون‌شبح‌های write-only که حذف نوشتن‌شان درست است — حذف شدند.
//   (۳) ستون‌هایی که یک قابلیت واقعی و دارای مصرف‌کننده را حمل می‌کنند و غیبت‌شان
//       کل statement (و گاهی کل چرخهٔ محصولی) را با PDO 1054 می‌کُشت — همین مایگریشن.
//
// ستون‌های این فایل و دلیل هر یک:
//   withdrawal_reviews (چرخهٔ بازبینی برداشت گیرکرده — ReconciliationService):
//     - transaction_status   وضعیت تراکنش پیوندی هنگام کشف
//       (FIX-S20: ستون review_status که این‌جا اضافه می‌شد، در ممیزی S19 «مرده»
//        ثابت شد — گردش‌کار واقعی روی ستون status کار می‌کند و review_status
//        هرگز نوشته/خوانده نشد؛ از همین فایل حذف و برای نصب‌های موجود در
//        2026_09_17_0001_drop_dead_schema_items.php DROP می‌شود.)
//     - severity / reason_code / details  طبقه‌بندی و شواهد کشف (details = JSON)
//     - resolution_note / resolved_at / resolved_by      ردپای تصمیم ادمین
//     - notified_admin_at / updated_at                    حسابرسی اطلاع‌رسانی و ویرایش
//   users.warning_count — زنجیرهٔ هشدار مودراسیون (۳ نویسنده + ۲ خواننده؛ بدون این ستون
//     increment/decrement/getWarningCount و آستانهٔ ۳ هشدار → ban هرگز اجرا نمی‌شد)
//   alert_rules.last_triggered_at — ترمز ضدتکرار الرت (AlertRulesEngine::wasRecentlyTriggered
//     می‌خواند؛ updateRuleLastTriggered می‌نویسد؛ بدون آن هر ارزیابی exception + اسپم الرت)
//   email_queue.user_id — خوانندهٔ واقعی دارد (EmailService JOIN users روی همین ستون
//     برای نمایش «ایمیل‌های کاربر X» در پنل ادمین) + ایندکس
//
// فایل کاملاً idempotent است (اجرای مجدد = بدون عملیات) و فقط ADD COLUMN/INDEX
// ساده (بدون سینتکس MariaDB-only) تا روی Oracle MySQL هم سبز بماند.
//
//.Generated: 2026-09-09

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('x289_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function x289_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('x289_index_exists')) {
    /** آیا ایندکس با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function x289_index_exists(PDO $db, string $table, string $index): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.statistics
             WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?'
        );
        $stmt->execute([$table, $index]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

// ---------------------------------------------------------------------------
// ۱) withdrawal_reviews — چرخهٔ بازبینی برداشت گیرکرده (X289)
// ---------------------------------------------------------------------------
$t = 'withdrawal_reviews';

if (!x289_column_exists($db, $t, 'transaction_status')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `transaction_status` VARCHAR(30) NULL DEFAULT NULL
               AFTER `status`");
}
if (!x289_column_exists($db, $t, 'severity')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `severity` VARCHAR(20) NULL DEFAULT NULL
               AFTER `transaction_status`");
}
if (!x289_column_exists($db, $t, 'reason_code')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `reason_code` VARCHAR(50) NULL DEFAULT NULL
               AFTER `severity`");
}
if (!x289_column_exists($db, $t, 'details')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `details` TEXT NULL DEFAULT NULL
               AFTER `reason_code`");
}
if (!x289_column_exists($db, $t, 'resolution_note')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `resolution_note` TEXT NULL DEFAULT NULL
               AFTER `details`");
}
if (!x289_column_exists($db, $t, 'resolved_at')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `resolved_at` DATETIME NULL DEFAULT NULL
               AFTER `resolution_note`");
}
if (!x289_column_exists($db, $t, 'resolved_by')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `resolved_by` INT UNSIGNED NULL DEFAULT NULL
               AFTER `resolved_at`");
}
if (!x289_column_exists($db, $t, 'notified_admin_at')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `notified_admin_at` DATETIME NULL DEFAULT NULL
               AFTER `resolved_by`");
}
if (!x289_column_exists($db, $t, 'updated_at')) {
    $db->exec("ALTER TABLE `{$t}` ADD COLUMN `updated_at` TIMESTAMP NULL DEFAULT NULL
               AFTER `notified_admin_at`");
}

// ---------------------------------------------------------------------------
// ۲) users.warning_count — زنجیرهٔ هشدار مودراسیون (X292)
// ---------------------------------------------------------------------------
if (!x289_column_exists($db, 'users', 'warning_count')) {
    $db->exec("ALTER TABLE `users` ADD COLUMN `warning_count` INT UNSIGNED NOT NULL DEFAULT 0
               AFTER `fraud_score`");
}

// ---------------------------------------------------------------------------
// ۳) alert_rules.last_triggered_at — ترمز ضدتکرار الرت (X294)
// ---------------------------------------------------------------------------
if (!x289_column_exists($db, 'alert_rules', 'last_triggered_at')) {
    $db->exec("ALTER TABLE `alert_rules` ADD COLUMN `last_triggered_at` DATETIME NULL DEFAULT NULL
               AFTER `is_active`");
}

// ---------------------------------------------------------------------------
// ۴) email_queue.user_id — پیوند ایمیل با کاربر برای JOIN پنل ادمین (X293)
// ---------------------------------------------------------------------------
if (!x289_column_exists($db, 'email_queue', 'user_id')) {
    $db->exec("ALTER TABLE `email_queue` ADD COLUMN `user_id` INT UNSIGNED NULL DEFAULT NULL
               AFTER `to_email`");
}
if (!x289_index_exists($db, 'email_queue', 'idx_email_queue_user')) {
    $db->exec("ALTER TABLE `email_queue` ADD INDEX `idx_email_queue_user` (`user_id`)");
}

echo "migration 2026_09_09_0001_ghost_column_audit_columns: OK\n";
