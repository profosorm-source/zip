-- T27-03: کلید ایدمپوتنسی ماندگار در لجر (Redis تنها فیل‌اُپن بود). NULL چندگانه مجاز است.
ALTER TABLE `score_events` ADD COLUMN `idempotency_key` VARCHAR(191) NULL DEFAULT NULL AFTER `metadata`;
ALTER TABLE `score_events` ADD UNIQUE KEY `uq_score_events_idem` (`idempotency_key`);
