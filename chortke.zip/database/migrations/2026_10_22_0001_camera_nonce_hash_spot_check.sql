-- ═══════════════════════════════════════════════════════════════════════════
-- FIX-F21-01-R2 (تصمیم‌های مالک D1-D3 — ۳۰ مهر ۱۴۰۵ / ۲۲ اکتبر ۲۰۲۶)
--
-- D2 (تصمیم مالک): nonce فقط به‌صورت هش ذخیره می‌شود؛ retry = رکورد جدید.
--   پیش از این، nonce خام در ستون nonce نگهداری می‌شد (برای تحویل idempotent
--   چالش). سند تصمیم و بازبینی مستقل: «مقدار خام هرگز ذخیره نمی‌شود».
--   - ستون nonce_hash اضافه و از nonce خام بک‌فیل می‌شود (SHA-256).
--   - یکتایی به nonce_hash منتقل می‌شود (uq_scr_nonce حذف، uq_scr_nonce_hash).
--   - ستون nonce خام حذف می‌شود. تحویل nonce فقط یک‌بار در پاسخ همان چالش
--     انجام می‌شود؛ هر فراخوانی چالش جدید = رکورد جدید + nonce تازه (سقف نرخ
--     RateLimitPolicy باقی است) — رکوردهای pending قبلی همان user/execution
--     منقضی می‌شوند (expirePendingCameraRequestsForUser).
--
-- D1 (تصمیم مالک): spot-check با رضایت کاربر — تصویر فقط «بررسی» می‌شود،
--   هیچ‌گاه ذخیره نمی‌شود و نتیجهٔ عددی‌اش به‌عنوان یکی از پارامترهای امتیاز
--   سرور می‌نشیند.
--   - spot_consent: آیا کاربر به بررسی نمونهٔ تصادفی رضایت داده است.
--   - spot_indices: ایندکس‌های فریم (۱-مبنا) که این چالش برای آپلود کم‌حجم
--     درخواست می‌کند (مثلاً "2")؛ در camera-verify با spot_images تأیید می‌شود.
--   تصویر هرگز روی دیسک/DB نمی‌نشیند؛ فقط آمار عددی آن (server_lum/server_std)
--   در server_analysis برای ممیزی ثبت می‌شود.
--
-- D3 (تصمیم مالک): به‌جای فاز سایه، پوشش با بررسی و تست زنده انجام می‌شود؛
--   کلید enforcement_mode ساخته نمی‌شود و گیت حکم از ابتدا واقعی است.
-- ═══════════════════════════════════════════════════════════════════════════

ALTER TABLE `social_camera_requests`
  ADD COLUMN IF NOT EXISTS `nonce_hash` CHAR(64) NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `spot_indices` VARCHAR(16) NULL DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `spot_consent` TINYINT(1) NOT NULL DEFAULT 0;

-- بک‌فیل هش از ردیف‌های بین-deploy (هنوز pending) که nonce خام دارند
UPDATE `social_camera_requests`
   SET `nonce_hash` = SHA2(`nonce`, 256)
 WHERE `nonce_hash` IS NULL AND `nonce` IS NOT NULL AND `nonce` <> '';

-- یکتایی از ستون خام به هش منتقل می‌شود
DROP INDEX IF EXISTS `uq_scr_nonce` ON `social_camera_requests`;
CREATE UNIQUE INDEX IF NOT EXISTS `uq_scr_nonce_hash` ON `social_camera_requests` (`nonce_hash`);

-- مقدار خام دیگر هیچ‌جا ذخیره نمی‌شود (سند تصمیم، بخش ۷-۱)
ALTER TABLE `social_camera_requests` DROP COLUMN IF EXISTS `nonce`;
