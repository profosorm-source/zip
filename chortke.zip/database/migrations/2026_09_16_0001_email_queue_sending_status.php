<?php
// FIX-S17-8 — تکمیل وضعیت claim صف ایمیل (email_queue.sending)
//
// ممیزی S17 (بچ Jobs + Commands) کشف کرد:
//  ۱) EmailDeliveryStore::findAndLock برای جلوگیری از ارسال مضاعف، وضعیت ردیف را
//     روی 'sending' می‌گذارد (BUG-01 Fix)، اما ستون status از نوع
//     ENUM('pending','sent','failed') است و مقدار 'sending' را نمی‌پذیرد ⇒
//     در sql_mode سخت‌گیرانه UPDATE با خطای 1265 شکست می‌خورد، استثنا در
//     catch بلعیده می‌شود و findAndLock همیشه null برمی‌گرداند ⇒ SendEmailJob
//     پیش از ارسال، early-return می‌کند و هر ایمیلِ صف‌شدهٔ DB برای همیشه
//     'pending' می‌ماند (ارسال بی‌صدا حذف می‌شد).
//  ۲) همان مسیر، SELECT ... FOR UPDATE بدون تراکنش پیرامونی داشت (قفل در
//     autocommit فوری آزاد می‌شد) — در فیکس کد، claim اتمیک شد؛ این فایل فقط
//     پیش‌نیازِ اسکیمایی آن را کانونیکال می‌کند.
//
// این فایل کاملاً idempotent است: پیش از ALTER، مقدار ستون با information_schema
// سنجیده می‌شود؛ اجرای مکرر هیچ‌گاه خطا نمی‌دهد.
//
// Generated: 2026-09-16

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('s17_email_queue_status_type')) {
    /** نوع فعلی ستون status جدول email_queue (خالی = جدول/ستون موجود نیست) */
    function s17_email_queue_status_type(PDO $db): string
    {
        $stmt = $db->prepare(
            'SELECT COLUMN_TYPE FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute(['email_queue', 'status']);

        return (string) ($stmt->fetchColumn() ?: '');
    }
}

$columnType = s17_email_queue_status_type($db);

if ($columnType !== '' && strpos($columnType, "'sending'") === false) {
    // نگه‌داری nullability و مقدار پیش‌فرض موجود (NULL DEFAULT 'pending')
    $db->exec(
        "ALTER TABLE email_queue
         MODIFY COLUMN status ENUM('pending','sending','sent','failed') NULL DEFAULT 'pending'"
    );
}
