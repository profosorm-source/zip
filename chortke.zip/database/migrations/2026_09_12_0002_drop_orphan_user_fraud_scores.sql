-- X364 (راند ۹۲): جدول user_fraud_scores یتیم است — صفر ارجاع در app/ و tests/ و qa/
-- (grep-proof) و صفر ردیف. تنها نویسندهٔ زندهٔ users.fraud_score اکنون مسیر لجر است
-- (ScoreCommandService::applySystemDelta از UserService::incrementFraudScore) و
-- پروجکشن سوم از رویداد لجر (listener / scores:rebuild) مشتق می‌شود.
-- ⚠️ نگهبان MigrationService: جدول populated را skip می‌کند؛ این جدول ۰ ردیف دارد
-- و DROP انجام می‌شود.
DROP TABLE IF EXISTS `user_fraud_scores`;

-- X362 (راند ۹۲): گسترش وضعیت‌های user_score_adjustments با 'applied' —
-- اصلاح‌های operation='set' دیگر overlay فعال (active) نیستند؛ دلتایشان همان
-- لحظه به‌صورت reason='admin_set' در لجر score_events لنگر می‌شود (applySystemSet)
-- و ردیف adjustment صرفاً سابقهٔ audit است. اگر در enum نبود، STRICT_TRANS_TABLES
-- درج status='applied' را با خطای Data truncated رد می‌کرد.
-- خواننده‌های overlay (RiskDecisionService / ScoreService::getEffectiveScore /
-- getActiveAdjustments) همه با گارد status='active' می‌خوانند و ابطال
-- (revokeScoreAdjustment) هم فقط ردیف‌های active را لمس می‌کند — پس
-- ردیف‌های applied از هر دو مسیر به‌طور طبیعی مستثنا می‌مانند.
ALTER TABLE `user_score_adjustments`
    MODIFY COLUMN `status` enum('active','revoked','applied') NOT NULL DEFAULT 'active';
