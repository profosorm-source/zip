-- [FIX-R91-B] ستون‌های آف‌سایت برای backup_logs — حلقهٔ کامل DR (راند ۹۱)
-- هر بکاپ «completed» پس از این مهاجرت می‌تواند وضعیت آپلود به مقصد خارجی
-- (S3 سازگار / FTPS) را داشته باشد:
--   offsite_status:       pending | uploaded | failed | NULL (هرگز تلاش نشده — ردیف‌های failed بکاپ)
--   offsite_uploaded_at:  زمان موفقیت آخرین آپلود
--   offsite_remote_key:   کلید/مسیر شیء در مقصد (برای بازیابی از خارج)
--   offsite_error:        آخرین خطای آپلود (برای نمایش به ادمین)
ALTER TABLE `backup_logs`
    ADD COLUMN `offsite_status` VARCHAR(20) NULL DEFAULT NULL AFTER `checksum`,
    ADD COLUMN `offsite_uploaded_at` TIMESTAMP NULL DEFAULT NULL AFTER `offsite_status`,
    ADD COLUMN `offsite_remote_key` VARCHAR(500) NULL DEFAULT NULL AFTER `offsite_uploaded_at`,
    ADD COLUMN `offsite_error` VARCHAR(1000) NULL DEFAULT NULL AFTER `offsite_remote_key`;

-- خوانندهٔ اصلی: جاروب شبانهٔ syncPending (status='completed' AND offsite_status IN ('pending','failed'))
ALTER TABLE `backup_logs`
    ADD INDEX `idx_backup_logs_offsite` (`offsite_status`);
