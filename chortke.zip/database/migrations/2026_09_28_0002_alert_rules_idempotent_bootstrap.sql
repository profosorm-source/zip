-- =============================================================================
-- FIX-C116/C117/C118 — alert_rules: قید یکتا + توضیح ماندگار
-- (یافته‌های ممیزی ۱۱۶، ۱۱۷، ۱۱۸)
-- =============================================================================
-- پیشینه:
--   (۱۱۶) رقابت در ثبت/به‌روزرسانی قوانین: SELECT-then-INSERT بدون قید UNIQUE
--         روی rule_name ⇒ دو اجرای هم‌زمان bootstrap یک قانون را دوبار می‌ساخت.
--   (۱۱۷) bootstrap تراکنش نداشت ⇒ شکست وسط کار مجموعه‌ای ناقص از قوانین می‌گذاشت.
--   (۱۱۸) description قانون فقط در لاگ می‌رفت و در DB ذخیره نمی‌شد.
-- راه‌حل:
--   1) UNIQUE KEY روی rule_name ⇒ race در سطح DB بسته می‌شود (defensive).
--   2) AlertRulesBootstrapCommand از INSERT ... ON DUPLICATE KEY UPDATE و
--      تراکنش واحد استفاده می‌کند (فایل PHP مرتبط).
--   3) ستون description اضافه می‌شود و در bootstrap ذخیره می‌شود.
-- =============================================================================

ALTER TABLE `alert_rules`
    ADD COLUMN IF NOT EXISTS `description` VARCHAR(500) NULL DEFAULT NULL
        COMMENT 'FIX-C118: توضیح مدیریتی قانون برای نگهداری' AFTER `condition`;

-- قید یکتا: تکرار ممکن از رکوردهای موجود باید قبل از اعمال پاک شود.
-- (پاک‌سازی امن: فقط ردیف‌های تکراری با id بالاتر حذف می‌شوند؛ قانون با کوچک‌ترین id مرجع می‌ماند.)
DELETE r1 FROM `alert_rules` r1
INNER JOIN `alert_rules` r2
    ON r1.`rule_name` = r2.`rule_name` AND r1.`id` > r2.`id`;

ALTER TABLE `alert_rules`
    ADD UNIQUE KEY IF NOT EXISTS `uq_alert_rules_rule_name` (`rule_name`);
