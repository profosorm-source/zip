-- FIX-X21 (راند ۱۵): هم‌راستا با تغییر InvestmentCommandService::approveWithdrawal()
-- که اکنون وضعیت نهایی را به‌جای approved روی completed می‌گذارد، ردیف‌های
-- تاریخیِ approved که پرداختشان تکمیل شده (processed_at ثبت شده — پرداخت
-- درون همان Saga atomic انجام می‌شد) به completed مهاجرت می‌کنند تا گارد
-- hasPending()/گزارش‌ها دچار ابهام نشوند. Idempotent: اجرای مجدد no-op است.

UPDATE investment_withdrawals
SET status = 'completed'
WHERE status = 'approved'
  AND processed_at IS NOT NULL;
