<?php
// FIX-S20-1/FIX-S20-2 (بچ S20): حذف آیتم‌های مردهٔ اسکیما که ممیزی S19 نشانه‌گذاری کرد
//
//   ۱) جدول common_passwords — «جدول خفته» (یافتهٔ DB-4):
//      مایگریشن 2026_06_16_0007 آن را می‌ساخت، اما هیچ seedi آن را پر نمی‌کند و
//      تنها خوانندهٔ کد آن (CommonPasswords::isCommonFromDatabase) صفر caller زنده
//      داشت (مسیر زندهٔ PasswordPolicy از لیست درون-حافظه استفاده می‌کند).
//      فایل سازنده از نصب تازه حذف شد؛ اینجا برای نصب‌های موجود DROP می‌شود.
//
//   ۲) ستون withdrawal_reviews.review_status — «ستون مرده» (یافتهٔ DB-5):
//      2026_09_09_0001 آن را به‌عنوان ستون گردش‌کار بازبینی اضافه می‌کرد، اما
//      گردش‌کار واقعی روی ستون status کار می‌کند (INSERT='open'، resolve/dismiss
//      رویش UPDATE می‌زند) و review_status هرگز نوشته/خوانده نشد (فقط یک چاپ
//      نمایشی که FIX-S19-6 به status منتقل شد). ستون از مایگریشن سازنده حذف و
//      اینجا برای نصب‌های موجود DROP می‌شود.
//
// ایمنی:
//   • کاملاً idempotent (اجرای مجدد = بدون عملیات).
//   • DROP جدول فقط وقتی انجام می‌شود که جدول موجود و «خالی» باشد؛ جدول پُر =
//     skip با پیام (هم‌راستا با فلسفهٔ گارد «DROP جدول پُر» MigrationService).
//   • سینتکس MySQL/MariaDB-safe: چک information_schema، بدون «DROP COLUMN IF
//     EXISTS» که MariaDB-only است.
//
// Generated: 2026-09-17

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('s20_table_exists')) {
    /** آیا جدول با این نام در دیتابیس فعلی وجود دارد؟ */
    function s20_table_exists(PDO $db, string $table): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_name = ?'
        );
        $stmt->execute([$table]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('s20_column_exists')) {
    /** آیا ستون با این نام روی جدولِ داده‌شده وجود دارد؟ */
    function s20_column_exists(PDO $db, string $table, string $column): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?'
        );
        $stmt->execute([$table, $column]);

        return (int) $stmt->fetchColumn() > 0;
    }
}

// ---------------------------------------------------------------------------
// ۱) FIX-S20-1 — جدول خفتهٔ common_passwords
// ---------------------------------------------------------------------------
if (s20_table_exists($db, 'common_passwords')) {
    $rowCount = (int) $db->query('SELECT COUNT(*) FROM `common_passwords`')->fetchColumn();
    if ($rowCount > 0) {
        // گارد ایمنی: جدول پُر هرگز drop نمی‌شود (دادهٔ موجود از بین نرود).
        echo "SKIP: common_passwords has {$rowCount} rows — destructive drop skipped\n";
    } else {
        // 🔒 AUDIT-FIX (R2): destructive PHP migrations must pass the same safety
        // guard as destructive SQL statements (populated-table protection / opt-in).
        \App\Services\MigrationService::assertDestructiveOperation('drop_table', 'common_passwords');
        $db->exec('DROP TABLE `common_passwords`');
        echo "dropped dormant table common_passwords (0 rows)\n";
    }
}

// ---------------------------------------------------------------------------
// ۲) FIX-S20-2 — ستون مردهٔ withdrawal_reviews.review_status
// ---------------------------------------------------------------------------
if (s20_column_exists($db, 'withdrawal_reviews', 'review_status')) {
    // 🔒 AUDIT-FIX (R2): same destructive-guard parity as above.
    \App\Services\MigrationService::assertDestructiveOperation('drop_column', 'withdrawal_reviews');
    $db->exec('ALTER TABLE `withdrawal_reviews` DROP COLUMN `review_status`');
    echo "dropped dead column withdrawal_reviews.review_status\n";
}

// ---------------------------------------------------------------------------
// ۳) پاکسازی ردیفِ خاکستریِ مایگریشنِ سازندهٔ حذف‌شده (FIX-S20-1)
//
// W4-B (F-A24c-05) — تصحیح درِفتِ کامنت: کامنتِ قدیمی می‌گفت فایل
// 2026_06_16_0007_create_common_passwords_table.php «از درخت حذف شده است» —
// این دیگر درست نیست: آن فایل امروز در درخت «موجود» است و به مایگریشنِ
// cleanup-DROP تبدیل شده است؛ بنابراین شاخهٔ DELETEِ زیر در وضعیت فعلی
// no-opِ اثبات‌شده است (!is_file() هرگز true نمی‌شود).
//
// با این حال شاخه به‌عنوان طراحیِ دفاعیِ درست سر جایش می‌ماند: اگر اپراتوری
// روزی فایل مذکور را واقعاً از درخت حذف کند، ردیفِ اجرایش در schema_migrations
// می‌ماند و واریانتِ صحه‌گذاری‌شدهٔ preflight (تعداد فایل‌های مایگریشن = تعداد
// ردیف‌های schema_migrations) را می‌شکند. ردیف فقط وقتی پاک می‌شود که فایل
// واقعاً غایب باشد؛ تا وقتی فایل موجود است، ردیف و checksum آن به قوت خود
// می‌مانند (گارد دستکاری همچنان فعال) و فقط DROP جدول/ستون انجام شده است.
// ---------------------------------------------------------------------------
$s20RemovedCreator = __DIR__ . '/2026_06_16_0007_create_common_passwords_table.php';
if (!is_file($s20RemovedCreator)) {
    $db->exec("DELETE FROM schema_migrations WHERE migration = '2026_06_16_0007_create_common_passwords_table.php'");
    echo "removed stale schema_migrations row of deleted 2026_06_16_0007_create_common_passwords_table.php\n";
}

echo "migration 2026_09_17_0001_drop_dead_schema_items: OK\n";
