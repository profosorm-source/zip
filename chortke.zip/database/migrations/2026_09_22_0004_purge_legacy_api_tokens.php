<?php
// ═══════════════════════════════════════════════════════════════════
// W4-E (Task ID: W4-E) — حذف کامل توکن‌های API قدیمی (purge فاز تست)
// تصمیم تأییدشدهٔ مشتری (client decision #2)
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه: از W4 به بعد، قرارداد مالکیت توکن‌های API عوض شد:
//   - طول عمر پیش‌فرض توکن‌های جدید = ۹۰ روز ( renewable از پنل ادمین —
//     سرویس ApiTokenService::DEFAULT_TTL_DAYS و متد renewToken()).
//   - همهٔ توکن‌های ساخته‌شدهٔ قبلی، تحت قرارداد قدیمی صادر شده‌اند
//     (پیش‌فرض ۳۰ روزه در دو مسیر، مقادیر دلخواه ۱..۳۶۵ روز، و ردیف‌های
//     legacy با expires_at=NULL) و قابل تطبیق با قرارداد جدید نیستند.
//
// تصمیم مشتری (تأییدشده در W4): در فاز تست، «همهٔ» ردیف‌های قبلی جدول
// api_tokens حذف شوند تا هیچ توکنی با قرارداد قدیمی باقی نماند؛ کاربران
// توکن جدید با انقضای ۹۰ روزه می‌گیرند. این migration عمداً destructive
// روی دادهٔ api_tokens است (فقط جدول api_tokens — به هیچ جدول دیگری دست
// نمی‌زند) و هرگز نباید پس از خروج از فاز تست روی پروداکشن اجرا شود.
//
// fresh install = no-op طبیعی: اگر جدول api_tokens هنوز وجود نداشته باشد
// (نصب تازه، قبل از migration جدول‌ساز) SKIP می‌شود؛ اگر جدول خالی باشد
// صفر ردیف حذف می‌شود. اجرای دوباره هم no-op است (idempotent).
//
// اجرای این فایل روی دیتابیس زندهٔ chortk توسط عامل W4-E انجام نشده است.
//
// Generated: 2026-09-22

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('w4e_api_tokens_table_exists')) {
    /** وجود جدول api_tokens در دیتابیس جاری (null-safe برای نصب تازه) */
    function w4e_api_tokens_table_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT 1 FROM information_schema.TABLES
             WHERE table_schema = DATABASE()
               AND table_name = 'api_tokens'
             LIMIT 1"
        );
        $stmt->execute();
        return $stmt->fetchColumn() !== false;
    }
}

$log = static function (string $msg): void {
    echo '[w4e-purge-legacy-api-tokens] ' . $msg . PHP_EOL;
    if (function_exists('logger')) {
        try {
            logger()->info('migration.w4e_purge_legacy_api_tokens', ['msg' => $msg]);
        } catch (\Throwable $e) {
            // لاگ نباید مایگریشن را بشکند
        }
    }
};

if (!w4e_api_tokens_table_exists($db)) {
    $log('SKIP: جدول api_tokens در دیتابیس جاری وجود ندارد (نصب تازه) — no-op.');
} else {
    $count = (int) $db->query('SELECT COUNT(*) FROM api_tokens')->fetchColumn();

    if ($count === 0) {
        $log('SKIP: جدول api_tokens خالی است — no-op (idempotent).');
    } else {
        // 🔒 AUDIT-FIX (R2): این فایل مستند کرده که هرگز نباید پس از فاز تست اجرا شود،
        // اما گاردی برای آن وجود نداشت. حالا همان گارد destructive مایگریشن‌های SQL
        // (populated-table protection / ALLOW_DESTRUCTIVE_MIGRATIONS) اعمال می‌شود:
        // روی جدول پُر بدون opt-in صریح، اجرا fail-closed متوقف می‌شود.
        \App\Services\MigrationService::assertDestructiveOperation('delete_all', 'api_tokens');
        $deleted = $db->exec('DELETE FROM api_tokens');
        $log("OK: {$deleted} توکن legacy حذف شد (تصمیم تأییدشدهٔ مشتری W4 — purge فاز تست؛ " .
             'توکن‌های جدید با قرارداد ۹۰ روزهٔ renewable صادر می‌شوند).');
    }
}
