-- =====================================================
-- FIX (S-M review round 8-e) — ستون‌های بن‌کردن جدول users
--
-- UserService::banUser/unbanUser روی ستون‌های ban_reason/banned_at
-- می‌نوشت ولی این ستون‌ها در اسکیمای زنده وجود نداشتند → خطای 42S22
-- بلعیده می‌شد و دلیل/زمانِ بن هرگز ذخیره نمی‌شد (silent data loss).
--
-- هر دو ستون nullable هستند (کاربرِ عادی ban نیست) و مطابق قرارداد
-- کد موجود: ban_reason = رشتهٔ دلیل بن، banned_at = لحظهٔ بن
-- (DATETIME به‌جای TIMESTAMP تا محدودهٔ 2038 هم محدود نشود).
-- Idempotent: ADD COLUMN IF NOT EXISTS (الگوی 2026_09_19_0002).
-- =====================================================

ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `ban_reason` VARCHAR(255) NULL DEFAULT NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `banned_at` DATETIME NULL DEFAULT NULL;
