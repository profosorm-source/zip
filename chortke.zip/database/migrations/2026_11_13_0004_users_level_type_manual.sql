-- T27-06: سطحِ تعیین‌شده توسط ادمین ماندگار شود (checkUpgrade/checkDowngrades فقط level_type='auto' را بازنویسی می‌کنند)
ALTER TABLE `users` MODIFY COLUMN `level_type` ENUM('auto','purchased','manual') NULL DEFAULT 'auto';
