-- FIX-S33-R17 (گزارش بخش ۱۳ — واریز دستی): «تاریخ/ساعت واریز بانکی» که کاربر
-- در فرم واریز دستی وارد می‌کند (deposit_date + deposit_time — فیلدهای required
-- در views/user/manual-deposit/create.php) تا پیش از این در هیچ ستونی ذخیره
-- نمی‌شد؛ زمان ثبت/تأییدِ سیستم با عنوان «تاریخ واریز» نمایش داده می‌شد و تطبیق
-- رسید بانکی/ممیزی مخدوش می‌شد. ستون deposited_at لحظهٔ اعلامی بانکی را جدا از
-- created_at (لحظهٔ ثبت در سایت) نگه می‌دارد.

ALTER TABLE manual_deposits
  ADD COLUMN deposited_at DATETIME NULL DEFAULT NULL
    COMMENT 'لحظهٔ واریز بانکی اعلامی کاربر (از فرم deposit_date/deposit_time)' AFTER tracking_code,
  ADD INDEX idx_manual_deposits_deposited_at (deposited_at);

-- Backfill یک‌باره: ردیف‌های موجود لحظهٔ بانکی ندارند؛ NULL یعنی «ثبت‌شدهٔ پیش از FIX-S33-R17»
-- و ویو به created_at برمی‌گردد (رفتار قدیمی).
