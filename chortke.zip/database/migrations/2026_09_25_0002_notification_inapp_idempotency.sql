-- =============================================================================
-- FIX-A6-F3 — دایدیک idempotency پایدار برای اعلان‌های in-app (Audit Task 6-a)
-- =============================================================================
--
-- پیشینه (Audit R6-F3): SendNotificationJob (نویسندهٔ مرکزی in-app) روی هر retry
-- یک ردیف notifications جدید می‌ساخت؛ event_id داخل payload هیچ‌جا در ستونی
-- یکتا ذخیره نمی‌شد و شمای جدول هیچ قید یکتایی روی (event, recipient, channel)
-- نداشت. نتیجه: retry جاب/پابلیشر = اعلان مضاعف برای کاربر (silent duplicate).
--
-- راه‌حل:
--   ۱) ستون idempotency_key VARCHAR(128) NULL — کلید رویداد (event_id/notif_id/
--      message_id همان قرارداد NotificationDispatcher) با recipient+channel
--      ذخیره می‌شود. NULL برای مسیرهای بدون رویداد (رفتار قبلی) — MySQL/MariaDB
--      برای NULLها محدودیت یکتا اعمال نمی‌کند پس ردیف‌های موجود بی‌تغییر می‌مانند.
--   ۲) UNIQUE KEY uniq_notif_idem_user_channel (idempotency_key, user_id, channel)
--      — سمت کد، درج با UPSERT اتمیک (ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id))
--      انجام می‌شود (SendNotificationJob)؛ تکراری = همان ردیف قبلی، نه ردیف جدید.
--
-- Idempotent اجرا: ADD COLUMN IF NOT EXISTS + ADD UNIQUE KEY IF NOT EXISTS
-- (الگوی 2026_09_20_0006 / 2026_06_14_0016).
-- پاکسازی تکراری‌ها پیش از ساخت ایندکس: چند‌جدولیِ DELETE n1 FROM ... JOIN
-- (فرم out-of-scope گارد destructive رانر؛ الگوی مایگریشن‌های dedupe زنجیره)
-- با گارد information_schema — فقط وقتی ستون واقعاً موجود است اجرا می‌شود.
-- چون ستون در اولین اجرا تازه ساخته می‌شود و همهٔ ردیف‌های موجود NULL دارند،
-- این پاکسازی در حالت عادی no-op است و فقط حالت اجرای نیمه‌کارهٔ قبلی
-- (ستون ساخته‌شده اما ایندکس نه + درج‌های بینابینی) را ایمن می‌کند.
-- =============================================================================

ALTER TABLE `notifications`
  ADD COLUMN IF NOT EXISTS `idempotency_key` VARCHAR(128) NULL DEFAULT NULL
    COMMENT 'کلید idempotency رویداد (event_id/notif_id/message_id) — با recipient+channel یکتاست'
    AFTER `channel`;

-- پاکسازی تکراری‌ها (کمترین id نگه داشته می‌شود) — گارد information_schema
DELETE n1
FROM notifications n1
JOIN notifications n2
  ON  n1.idempotency_key = n2.idempotency_key
  AND n1.user_id         = n2.user_id
  AND n1.channel         = n2.channel
  AND n1.id > n2.id
WHERE n1.idempotency_key IS NOT NULL
  AND EXISTS (SELECT 1 FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME   = 'notifications'
                AND COLUMN_NAME  = 'idempotency_key');

ALTER TABLE `notifications`
  ADD UNIQUE KEY IF NOT EXISTS `uniq_notif_idem_user_channel` (`idempotency_key`, `user_id`, `channel`);
