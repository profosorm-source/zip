-- T26-04: بک‌فیل مهلت تایید خریدار برای آگهی‌های in_escrow قدیمی که escrow_deadline ندارند.
-- ارفاق یک‌باره: مهلت = لحظهٔ اجرای مایگریشن + vitrine_escrow_days (پیش‌فرض ۳ روز)
-- تا ProcessExpiredVitrineEscrowsJob بتواند آن‌ها را به‌صورت خودکار تسویه کند.
-- آگهی‌های disputed عمداً شامل نیستند (فقط ادمین حل می‌کند).
UPDATE `vitrine_listings`
   SET `escrow_deadline` = DATE_ADD(NOW(), INTERVAL COALESCE(NULLIF(
         (SELECT CAST(`value` AS UNSIGNED) FROM `system_settings` WHERE `key` = 'vitrine_escrow_days' LIMIT 1), 0), 3) DAY)
 WHERE `status` = 'in_escrow' AND `escrow_deadline` IS NULL AND `deleted_at` IS NULL;
