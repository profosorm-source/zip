<?php
// ═══════════════════════════════════════════════════════════════════════════
// 🛡️ FIX-S20-REVIEW (تصمیم مصوب گزینهٔ ۶ — تمیزکاری مرده‌ها، هم‌سو با S19)
// حذف ستون مردهٔ withdrawal_reviews.review_status
// ═══════════════════════════════════════════════════════════════════════════
//
// پیش‌زمینه: مایگریشن 2026_09_09_0001_ghost_column_audit_columns ستون
// review_status را به withdrawal_reviews افزود؛ ولی طبق سند
// 2026_09_06_0003_withdrawal_reviews_workflow_columns، نام در کد به `status`
// تغییر کرد و از آن پس هیچ نویسنده/خواننده‌ای برای review_status وجود ندارد
// (ReconciliationService فقط r.status را می‌خواند/می‌نویسد). تنها خوانندهٔ
// باقی‌مانده (StuckWithdrawalReviewCommand) اصلاح شد و دیگر به آن تکیه نمی‌کند.
// ستون همیشه روی DEFAULT 'open' می‌ماند و فقط سردرگمی عملیاتی می‌سازد.
//
// Idempotent: اگر ستون وجود نداشته باشد no-op است. Generated: 2026-09-17

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

$stmt = $db->prepare(
    "SELECT COUNT(*) FROM information_schema.columns
     WHERE table_schema = DATABASE() AND table_name = 'withdrawal_reviews' AND column_name = 'review_status'"
);
$stmt->execute();

if ((int) $stmt->fetchColumn() === 0) {
    echo "migration 2026_09_17_0001_drop_dead_review_status_column: OK (column absent, skipped=1, applied=0)\n";
    return 0;
}

// 🔒 AUDIT-FIX (R2): destructive PHP migrations must pass the same safety guard
// as destructive SQL statements (populated-table protection / explicit opt-in).
\App\Services\MigrationService::assertDestructiveOperation('drop_column', 'withdrawal_reviews');
$db->exec('ALTER TABLE `withdrawal_reviews` DROP COLUMN `review_status`');

echo "migration 2026_09_17_0001_drop_dead_review_status_column: OK (dropped, applied=1)\n";
