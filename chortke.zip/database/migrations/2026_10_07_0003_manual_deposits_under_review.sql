-- FIX-S33-R18 (گزارش بخش ۱۳): هم‌ارزی ماتریس وضعیت واریز دستی
-- صف/شمارش/boost پنل ادمین از قبل status IN ('pending','under_review') را می‌خوانند
-- (FIX-X117 و ManualDeposit::getPendingDeposits) ولی ستون status از نوع
-- ENUM('pending','approved','rejected') بود ⇒ ردیف under_review هرگز قابل ذخیره
-- نبود و بخش‌های «در-بررسی» (عملیات review، reject، SLA) عملاً مرده بودند.
-- اکنون ENUM گسترش می‌یابد تا کل ماتریس یکپارچه شود (index/review/approve/reject/count/SLA).

ALTER TABLE manual_deposits
  MODIFY COLUMN status ENUM('pending','under_review','approved','rejected') NOT NULL DEFAULT 'pending';
