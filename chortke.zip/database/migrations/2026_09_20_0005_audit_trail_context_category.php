<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-R16B (Task 16-B, ITEM 5) — audit_trail.context_category index
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه: جستجوی ادمینِ audit-trail دستهٔ رویداد را از JSON استخراج می‌کند
// (AdvancedAuditTrail::search → FIX-R15C: JSON_UNQUOTE(JSON_EXTRACT(context,
// '$.category')) = ?). این گزاره روی هر سطر full-scan می‌شود — ایندکس
// FULLTEXT(event) به آن کمکی نمی‌کند و در مقیاس (retention 90 روزه) گران است.
//
// آزمایش زنده روی MariaDB همین سندباکس (throwaway table r16b_probe_json،
// سپس DROP شد): MariaDB 11.8.6 ستون تولیدشدهٔ VIRTUAL بر پایهٔ
// JSON_UNQUOTE(JSON_EXTRACT(...)) را ایندکس‌پذیر می‌داند و بهینه‌ساز روی
// «ستون = ثابت» از ایندکس BTREE استفاده می‌کند:
//   EXPLAIN → type=ref, key=idx_context_category, ref=const
// پس مسیر (b) مأموریت: مایگریشن + سوییچ کوئری با fallback.
//
// ستون VIRTUAL است (هیچ بایت ذخیره نمی‌شود؛ فقط ایندکس هزینه دارد) و مقدارش
// همیشه با JSON منبع هم‌گام است — نیازی به backfill نیست. idempotent است
// (الگوی information_schema، هم‌شکل 2026_09_20_0004).

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r16b_audit_context_category_column_exists')) {
    function r16b_audit_context_category_column_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE()
               AND table_name = 'audit_trail'
               AND column_name = 'context_category'"
        );
        $stmt->execute();
        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r16b_audit_context_category_log')) {
    function r16b_audit_context_category_log(string $msg): void
    {
        echo '[r16b-audit-context-category] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.r16b_audit_context_category', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

if (r16b_audit_context_category_column_exists($db)) {
    r16b_audit_context_category_log('SKIP: ستون audit_trail.context_category از قبل وجود دارد (idempotent).');
    return;
}

// ستون مجازی + ایندکس در یک ALTER اتمیک. دستهٔ رویداد همیشه رشتهٔ کوتاهِ
// کنترل‌شده است (AuditTrail::record / AdvancedAuditTrail::record)؛ برای
// ردیف‌هایی که «$.category» ندارند مقدار NULL می‌شود و ایندکس شامل آن‌ها
// نمی‌شود (exactly the equality-filter semantics).
$db->exec(
    "ALTER TABLE `audit_trail`
     ADD COLUMN `context_category` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin
       GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(`context`, '$.category'))) VIRTUAL,
     ADD INDEX `idx_audit_trail_context_category` (`context_category`)"
);
r16b_audit_context_category_log('OK: ستون مجازی audit_trail.context_category + ایندکس idx_audit_trail_context_category اضافه شد.');
