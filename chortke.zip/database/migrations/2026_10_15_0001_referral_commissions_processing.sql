-- F-19-02 (گزارش بخش ۱۹) — transition اتمیک مشترک لغو/پرداختِ کمیسیون
-- race: batchPay ردیف pending را می‌خواند → ادمین همان ردیف را cancelled می‌کند
-- (UPDATE شرطی pending موفق) → batch واریز را انجام می‌دهد و با «UPDATE ... WHERE id=?»
-- بی‌شرط، ردیف را paid می‌کند ⇒ کمیسیونِ لغوشده پرداخت شد و status با wallet واگرا شد.
-- الگوی استاندارد رفع (پیشنهاد خود گزارش): گذارِ شرطیِ اتمیک
--   pending → processing → paid
-- هر دو مسیر (batchPay و cancelCommission) روی همان گذار CAS می‌کنند؛ لغوِ ردیفِ
-- درحالِ-پرداخت با affected=0 رد می‌شود (کنترلر پیام 422 موجود را برمی‌گرداند).
-- ردیف‌های گیرکرده در processing (کرش بین claim و mark-paid) با fence زمانی
-- (updated_at < NOW() - INTERVAL 30 MINUTE، بسیار بلندتر از قفل Redis 300s بچ)
-- توسط batch بعدی بازپذیرنده‌اند — کلید idempotency پایدار bp_{id} تضمین
-- می‌کند واریزِ دوباره در این حالت replay بی‌پرداخت است، نه پرداخت دوم.
-- ENUM فقط گسترش می‌یابد (backward-compatible؛ مقدار پیش‌فرض و مقادیر موجود
-- دست‌نخورده) — الگوی مایگریشن 2026_10_07_0003 (manual_deposits under_review).
-- نکتهٔ استقرار: دیتابیس‌های توسعه از varchar(50) استفاده می‌کنند (بدون
-- محدودیت ENUM)؛ این MODIFY برای نصب‌های پروداکشن که از ENUM مایگریشن
-- 2026_06_10_0006 آمده‌اند لازم است و روی varchar هم بی‌ضرر است.

ALTER TABLE referral_commissions
  MODIFY COLUMN status ENUM('pending', 'processing', 'paid', 'cancelled') DEFAULT 'pending';
