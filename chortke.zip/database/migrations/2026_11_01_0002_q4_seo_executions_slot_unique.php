<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-Q4-SEO23-09 — slot_date یکتا + ایندکس IP برای seo_executions
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه (گزارش ماژول ۲۳، یافتهٔ ۰۹):
//   • ایندکس (ad_id, user_id, execution_date) غیریکتاست ⇒ شاخهٔ تشخیص
//     خطای 1062 در StartSeoTaskJob هرگز فعال نمی‌شد (محافظ مرده) و جلوگیری
//     از تکرار فقط به قفل FOR UPDATE ردیف آگهی متکی بود (سریال‌سازی همهٔ
//     شروع‌های یک کمپین محبوب = نقطهٔ داغ throughput).
//   • کوئری محدودیت IP (ip_address, created_at) هیچ ایندکسی ندارد ⇒ روی
//     جدول بزرگ اسکن کامل.
//
// طراحی (partial-unique به سبک MariaDB با ستون nullable):
//   slot_date DATE NULL:
//     — started/completed → slot_date = execution_date (اشغال‌کنندهٔ سهمیه)
//     — cancelled/fraud/rejected → NULL (جایگاه روز آزاد؛ MOD24-06/SEO-23-04:
//       لغو، امکان شروع مجدد همان روز را برمی‌گرداند)
//   UNIQUE (ad_id, user_id, slot_date) — چند NULL مجاز؛ رقابتِ شروعِ هم‌زمان
//   حالا در سطح DB با duplicate-key بسته می‌شود و محافظ 1062 زنده می‌شود.
//   INDEX (ip_address, created_at) برای گیت ضدتقلب IP.
//
// گام‌ها (idempotent):
//   ۱) ستون slot_date (گارد information_schema)
//   ۲) backfill: rows با status IN (started, completed) → execution_date؛
//      بقیه → NULL (بازکردن جایگاهِ ردیف‌های باطلِ تاریخی)
//   ۳) تکراری‌های زنده: برای هر (ad_id, user_id, slot_date) با >۱ ردیف، فقط
//      «بهترین» نگه داشته می‌شود (completed مقدم بر started؛ سپس id بزرگ‌تر =
//      تازه‌تر) و slot_date بقیه NULL می‌شود (ردیف‌ها حفظ می‌شوند — تاریخچه؛
//      فقط قید یکتایی برای آن‌ها اعمال نمی‌شود).
//   ۴) UNIQUE uq_seo_executions_ad_user_slot (ad_id, user_id, slot_date)
//   ۵) INDEX idx_seo_exec_ip_created (ip_address, created_at)
// ═══════════════════════════════════════════════════════════════════

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('q4m2_column_exists')) {
    function q4m2_column_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT column_name FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE()
               AND table_name = 'seo_executions'
               AND column_name = 'slot_date' LIMIT 1"
        );
        $stmt->execute();
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('q4m2_index_exists')) {
    function q4m2_index_exists(PDO $db, string $name): bool
    {
        $stmt = $db->prepare(
            "SELECT index_name FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = 'seo_executions'
               AND index_name = ? LIMIT 1"
        );
        $stmt->execute([$name]);
        return $stmt->fetchColumn() !== false;
    }
}

if (!function_exists('q4m2_log')) {
    function q4m2_log(string $msg): void
    {
        echo '[q4-seo23-09-slot_date] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try { logger()->info('[q4-seo23-09-slot_date] ' . $msg); } catch (\Throwable $e) { /* best-effort */ }
        }
    }
}

// ── گام ۱: ستون ────────────────────────────────────────────────────
if (!q4m2_column_exists($db)) {
    $db->exec('ALTER TABLE seo_executions ADD COLUMN slot_date DATE NULL DEFAULT NULL AFTER execution_date');
    q4m2_log('column slot_date added');
} else {
    q4m2_log('column slot_date already exists — skip');
}

// ── گام ۲: backfill ────────────────────────────────────────────────
$backfilled = $db->exec(
    "UPDATE seo_executions
     SET slot_date = execution_date
     WHERE slot_date IS NULL AND status IN ('started', 'completed')"
);
q4m2_log('backfill slot_date (started/completed): ' . (int)$backfilled);

$freed = $db->exec(
    "UPDATE seo_executions
     SET slot_date = NULL
     WHERE slot_date IS NOT NULL AND status NOT IN ('started', 'completed')"
);
q4m2_log('freed slot_date for cancelled/fraud/rejected: ' . (int)$freed);

// ── گام ۳: تکراری‌های زنده — فقط بهترین نگه داشته می‌شود ────────────
$dupGroups = $db->query(
    "SELECT ad_id, user_id, slot_date, COUNT(*) AS c
     FROM seo_executions
     WHERE slot_date IS NOT NULL
     GROUP BY ad_id, user_id, slot_date
     HAVING COUNT(*) > 1"
)->fetchAll(\PDO::FETCH_OBJ);

$freedDup = 0;
if ($dupGroups !== []) {
    // بهترین = completed مقدم؛ سپس تازه‌تر (id بزرگ‌تر). بقیه slot_date=NULL.
    $nullify = $db->prepare(
        "UPDATE seo_executions
         SET slot_date = NULL
         WHERE ad_id = ? AND user_id = ? AND slot_date = ?
           AND id NOT IN (
               SELECT keep_id FROM (
                   SELECT id AS keep_id FROM seo_executions
                   WHERE ad_id = ? AND user_id = ? AND slot_date = ?
                   ORDER BY (status = 'completed') DESC, id DESC
                   LIMIT 1
               ) AS keeper
           )"
    );
    foreach ($dupGroups as $g) {
        $nullify->execute([
            $g->ad_id, $g->user_id, $g->slot_date,
            $g->ad_id, $g->user_id, $g->slot_date,
        ]);
        $freedDup += $nullify->rowCount();
    }
}
q4m2_log('duplicate live slots freed (rows kept, slot released): ' . $freedDup);

// ── گام ۴: UNIQUE ─────────────────────────────────────────────────
if (!q4m2_index_exists($db, 'uq_seo_executions_ad_user_slot')) {
    $db->exec('ALTER TABLE seo_executions ADD UNIQUE KEY uq_seo_executions_ad_user_slot (ad_id, user_id, slot_date)');
    q4m2_log('UNIQUE uq_seo_executions_ad_user_slot created');
} else {
    q4m2_log('UNIQUE already exists — skip');
}

// ── گام ۵: ایندکس IP ──────────────────────────────────────────────
if (!q4m2_index_exists($db, 'idx_seo_exec_ip_created')) {
    $db->exec('ALTER TABLE seo_executions ADD INDEX idx_seo_exec_ip_created (ip_address, created_at)');
    q4m2_log('INDEX idx_seo_exec_ip_created created');
} else {
    q4m2_log('INDEX already exists — skip');
}

q4m2_log('DONE');
