<?php
// ═══════════════════════════════════════════════════════════════════
// COMPAT-MYSQL8 (تسک 76-B) — حذف کامل کولیشن MariaDB-فقط utf8mb4_uca1400_ai_ci
// ═══════════════════════════════════════════════════════════════════
//
// پیش‌زمینه: جدول‌هایی که با «DEFAULT CHARSET=utf8mb4» بدون COLLATE صریح ساخته
// می‌شوند (مثل `banner` و `events` در 2026_06_16_0002_final_catch_all_tables.sql)
// روی MariaDB 11.8 کولیشن پیش‌فرضِ سرور یعنی utf8mb4_uca1400_ai_ci را به ارث
// می‌برند. این کولیشن در Oracle MySQL وجود ندارد؛ mysqldump از چنین جدول‌هایی
// هنگام ایمپورت در MySQL 8 با ERROR 1273 (Unknown collation) می‌میرد.
//
// چرا فایل اصلی دست‌نخورده ماند؟ runner مایگریشن گارد checksum دارد و فایلِ
// اجراشده قابل ویرایش نیست؛ این مایگریشنِ idempotent بعدی، در زمان اجرا هر
// جدول/ستونِ دارای uca1400 را به utf8mb4_unicode_ci (مشترک بین MariaDB 11.8
// و MySQL 8) نرمال می‌کند؛ پس نتیجهٔ نهایی نصب تازه هم‌ارز COLLATE صریح است.
//
// نکتهٔ ایمنی: «ALTER TABLE ... CONVERT TO CHARACTER SET» همهٔ ستون‌های رشته‌ای
// را هم کولیشن می‌کند و کولیشن‌های صریح utf8mb4_bin (مثل events.payload که
// ستون JSON است) را نابود می‌کند (با جدول تست ایزوله بازتولید شد). به‌جای آن،
// فقط ستون‌هایی که واقعاً uca1400 دارند با MODIFY هدفمند تغییر می‌کنند
// (نوع/nullability/default/کامنت حفظ می‌شود) و default سطح جدول جداگانه
// اصلاح می‌شود. تغییر کولیشن درونِ یک charset است و مقدارِ داده را عوض نمی‌کند.
//
// این فایل روی MySQL ذاتاً بی‌اثر است (آن کولیشن آنجا وجود ندارد). هم‌چنین
// MariaDB کولیشنِ ضمنیِ زمانِ ساخت را روی ستون «پین» می‌کند؛ یعنی پس از تغییر
// default جدول، ستون‌های قدیمی همچنان uca1400 می‌مانند — به همین دلیل اسکنِ
// ستون‌محورِ پایین ضروری است. Generated: 2026-09-09

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r76b_uca_tables')) {
    /**
     * جدول‌هایی که default سطح جدول یا حداقل یکی از ستون‌هایشان کولیشن
     * utf8mb4_uca1400_ai_ci دارد.
     *
     * @return array<string, list<array{column:string,type:string,nullable:bool,default:?string,comment:string,extra:string}>>
     */
    function r76b_uca_tables(PDO $db): array
    {
        $tables = [];

        // ① default سطح جدول
        // FIX (session2): گارد VIEW — information_schema.tables شامل VIEWها هم
        // هست؛ روی سروری که default collation آن uca1400 است (MariaDB 11.8+)،
        // ویوها هم به این اسکن می‌آیند و ALTER TABLE روی ویو با
        // «#1347 is not of type 'BASE TABLE'» کل مایگریشن را می‌شکند.
        $rows = $db->query(
            "SELECT table_name FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'
               AND table_collation = 'utf8mb4_uca1400_ai_ci'"
        )->fetchAll(PDO::FETCH_COLUMN);
        foreach ($rows as $t) {
            $tables[(string) $t] = [];
        }

        // ② ستون‌های رشته‌ای با کولیشن uca1400 (پس از تغییر default جدول هم پابرجا می‌مانند)
        $colStmt = $db->prepare(
            "SELECT c.table_name, c.column_name, c.column_type, c.is_nullable, c.column_default, c.column_comment, c.extra
             FROM information_schema.columns c
             JOIN information_schema.tables t
               ON t.table_schema = c.table_schema AND t.table_name = c.table_name AND t.table_type = 'BASE TABLE'
             WHERE c.table_schema = DATABASE() AND c.collation_name = 'utf8mb4_uca1400_ai_ci'
             ORDER BY c.table_name, c.ordinal_position"
        );
        $colStmt->execute();
        foreach ($colStmt->fetchAll(PDO::FETCH_ASSOC) as $c) {
            $t = (string) $c['table_name'];
            $tables[$t] = $tables[$t] ?? [];
            $tables[$t][] = [
                'column'   => (string) $c['column_name'],
                'type'     => (string) $c['column_type'],
                'nullable' => $c['is_nullable'] === 'YES',
                'default'  => $c['column_default'],
                'comment'  => (string) $c['column_comment'],
                'extra'    => (string) $c['extra'],
            ];
        }

        return $tables;
    }
}

$applied         = 0;
$generatedSkipped = 0;

foreach (r76b_uca_tables($db) as $table => $columns) {
    $clauses = [];
    foreach ($columns as $c) {
        // ستون‌های generated بدون بازسازی عبارت تولید، به‌طور ایمن MODIFY نمی‌شوند — رد شدن آگاهانه
        if (stripos($c['extra'], 'GENERATED') !== false) {
            $generatedSkipped++;
            continue;
        }
        $clauses[] = sprintf(
            'MODIFY `%s` %s CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci %s%s%s',
            $c['column'],
            $c['type'],
            $c['nullable'] ? 'NULL' : 'NOT NULL',
            $c['default'] !== null ? ' DEFAULT ' . $db->quote((string) $c['default']) : '',
            $c['comment'] !== '' ? ' COMMENT ' . $db->quote($c['comment']) : ''
        );
    }
    // default سطح جدول (بدون CONVERT TO — ستون‌های utf8mb4_bin حفظ می‌شوند)
    $clauses[] = 'DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

    $db->exec('ALTER TABLE `' . str_replace('`', '', $table) . '` ' . implode(', ', $clauses));
    $applied++;
}

echo 'migration 2026_09_09_0001_mysql8_collation_compat: OK'
    . " (tables_altered={$applied}, generated_skipped={$generatedSkipped})\n";
