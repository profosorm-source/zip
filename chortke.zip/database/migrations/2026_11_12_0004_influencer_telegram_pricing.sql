-- T25-07: قیمت‌گذاری تلگرام بر اساس «تعداد عضو» (follower_count) و «میانگین بازدید پست» (avg_views)
ALTER TABLE `influencer_profiles`
  ADD COLUMN IF NOT EXISTS `avg_views` INT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `sponsored_post_price` DECIMAL(24,4) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `pin_price` DECIMAL(24,4) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `forward_price` DECIMAL(24,4) NOT NULL DEFAULT 0;
