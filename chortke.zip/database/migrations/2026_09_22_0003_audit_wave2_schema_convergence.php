<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-R36-W2-C1 — همگرایی اسکیمای موج رفع ۲ ممیزی R36 (یافتهٔ F-A2-07)
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه (F-A2-07): جدول‌های user_fraud_scores و vitrine_disputes توسط
// مایگریشن‌های batch-1 ساخته شده‌اند (2026_06_10_0034_final_invariants.sql و
// 2026_06_10_0049_missing_business_tables.sql) و ردیفشان در schema_migrations
// ثبت است، ولی روی DB زنده غایب‌اند → زنجیرهٔ مایگریشن دیگر بازتابِ درستی از
// وضعیت واقعی اسکیما نیست و همگرایی ساخت‌مجدد (rebuild) به‌هم می‌ریزد.
//
// ⚠️ نکتهٔ شفاف‌سازی برای تصمیم‌گیر (باید در کارنوشت موج ۲ بماند):
// دو مایگریشن «حذف» هم ثبت‌شده‌اند و علت غیبت جدول‌ها همین‌ها هستند:
//   - 2026_08_03_0003_remove_vitrine_disputes.sql  (جدول موازی مرده؛ ویترین
//     به جدول یکپارچهٔ disputes با ref_type='vitrine_listing' رفته است)
//   - 2026_09_12_0002_drop_orphan_user_fraud_scores.sql (X364؛ جدول یتیم،
//     صفر ارجاع در app/tests/qa و صفر ردیف)
// یعنی زنجیره به‌خودی‌خود self-consistent است؛ اما رانِ تازه (fresh) زیر
// رانرِ سخت‌گیرشدهٔ فعلی (گارد destructive که DROP را skip+drift می‌کند) و
// رانِ تاریخی، دو سرِ متفاوتی تولید می‌کند. تصمیم ارکستراتور موج ۲ برای
// F-A2-07 «resurrect» است: این فایل صرفاً CREATE TABLE IF NOT EXISTS هر دو
// جدول را با «اسکیمای انتهایی دقیق» همان CREATEهای اصلی انجام می‌دهد تا
// هر دو مسیر (نصب تازه + DB موجود) به یک وضعیت همگرا برسند. هیچ
// DROP/TRUNCATE/DELETE داده‌ای در کار نیست (سازگار با گارد destructive
// رانر؛ صرفاً additive و idempotent).
//
// پیامد رفتاری: صفر — هر دو جدول صفر مصرف‌کنندهٔ زنده در app/core/routes
// دارند (اثبات grep ممیزی A2 + X364) و خالی ساخته می‌شوند. حذف دوباره‌شان
// (اگر کارفرما با تصمیم راندهای ۹۲ موافقت کند) فقط نیازمند حذف همین فایل +
// DROP دستی است.
//
// Idempotent: CREATE TABLE IF NOT EXISTS = no-op وقتی جدول موجود است.

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r36w2_table_exists')) {
    function r36w2_table_exists(PDO $db, string $table): bool
    {
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM information_schema.TABLES
             WHERE table_schema = DATABASE()
               AND table_name = ?"
        );
        $stmt->execute([$table]);
        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r36w2_log')) {
    function r36w2_log(string $msg): void
    {
        echo '[r36w2-schema-convergence] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.r36w2_schema_convergence', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

// ─── 1) user_fraud_scores — اسکیمای انتهایی دقیق 2026_06_10_0034 ──────
if (!r36w2_table_exists($db, 'user_fraud_scores')) {
    $db->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS `user_fraud_scores` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `category` VARCHAR(50) NOT NULL COMMENT 'velocity, proxy, behavior',
    `score_delta` DECIMAL(10,2),
    `reason` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_ufs_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
    r36w2_log('OK: user_fraud_scores با اسکیمای انتهایی 2026_06_10_0034 ساخته شد.');
} else {
    r36w2_log('SKIP: user_fraud_scores موجود است (no-op).');
}

// ─── 2) vitrine_disputes — اسکیمای انتهایی دقیق 2026_06_10_0049 ───────
// (FK خریدار در CREATE اصلی هم کامنت‌شده بود — عیناً حفظ شده است.)
if (!r36w2_table_exists($db, 'vitrine_disputes')) {
    $db->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS `vitrine_disputes` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `listing_id` INT(10) UNSIGNED NOT NULL,
    `buyer_id` INT(10) UNSIGNED NOT NULL,
    `seller_id` INT(10) UNSIGNED NOT NULL,
    `reason` TEXT NOT NULL,
    `status` ENUM('open', 'resolved', 'cancelled') DEFAULT 'open',
    `resolved_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_vit_disp_listing` FOREIGN KEY (`listing_id`) REFERENCES `vitrine_listings` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_vit_disp_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
    r36w2_log('OK: vitrine_disputes با اسکیمای انتهایی 2026_06_10_0049 ساخته شد (FK خریدار مطابق منبع غیرفعال).');
} else {
    r36w2_log('SKIP: vitrine_disputes موجود است (no-op).');
}

r36w2_log('DONE: همگرایی اسکیمای موج ۲ ممیزی R36 (F-A2-07) کامل شد — additive/idempotent، بدون حذف داده.');
