-- 📱 FIX-MOBILE-02 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲): چند-دستگاهی‌کردن user_devices.
--
-- مسئلهٔ پیشین: UNIQUE(user_id, platform) یعنی هر کاربر حداکثر «یک» دستگاه در هر
-- پلتفرم می‌توانست داشته باشد — قراردادی وب‌محور (یک مرورگر). کاربر موبایل با
-- گوشی + تبلت اندروید عملاً توکن دومی را روی اولی می‌نوشت و پوش فقط به یکی
-- می‌رسید. ضمناً dispatch (FcmChannel→sendToUser→getUserToken(user,'web')) فقط
-- توکنِ پلتفرم web را می‌خواند؛ یعنی ثبت android/ios اصلاً به مسیر ارسال
-- نمی‌رسید (باگ کشف‌شدهٔ همین بچ).
--
-- قرارداد جدید:
--   * یکتایی هویتِ «دستگاه» = خودِ توکن FCM (uq روی fcm_token(191)) — همان
--     توکن از دو حساب = یک دستگاه است که مالکش عوض شده (لاگین حساب دیگر)؛
--     upsert مالکیت را منتقل می‌کند.
--   * (user_id, platform) دیگر unique نیست — چند دستگاه هم‌پلتفرم آزاد است.
--   * device_name برای نمایش در لیست «دستگاه‌های من» (اختیاری، از کلاینت).
--
-- مراحل (ترتیب مهم است):
--   ۱) پاک‌سازی توکن‌های تکراریِ تاریخی (جدیدترین ردیف هر توکن می‌ماند) —
--      پیش از ساخت ایندکس unique الزامی است وگرنه migration می‌شکند.
--   ۲) حذف ایندکس‌های قدیمی (user_id,platform) و fcm_token غیر-unique.
--   ۳) افزودن ایندکس unique روی fcm_token(191).
--   ۴) ستون device_name.

DELETE ud1 FROM `user_devices` ud1
INNER JOIN `user_devices` ud2
  ON ud1.`fcm_token` = ud2.`fcm_token`
 AND (ud1.`updated_at` < ud2.`updated_at`
      OR (ud1.`updated_at` = ud2.`updated_at` AND ud1.`id` < ud2.`id`));

DROP INDEX IF EXISTS `uq_user_devices_user_platform` ON `user_devices`;
DROP INDEX IF EXISTS `idx_user_devices_fcm_token` ON `user_devices`;

CREATE UNIQUE INDEX IF NOT EXISTS `uq_user_devices_fcm_token`
  ON `user_devices` (`fcm_token`(191));

-- نکته: ایندکس user_id از قبل به‌صورت idx_ud_user_id (بچ foreign keys ۲۰۲۶-۰۸-۱۱)
-- وجود دارد؛ افزودن ایندکس تکراری صرفاً هزینهٔ نوشتن را بالا می‌برد.

ALTER TABLE `user_devices`
  ADD COLUMN `device_name` VARCHAR(120) NULL DEFAULT NULL
    COMMENT 'نام دلخواه دستگاه از کلاینت (مثل «گوشی علی») — صرفاً نمایشی' AFTER `platform`;
