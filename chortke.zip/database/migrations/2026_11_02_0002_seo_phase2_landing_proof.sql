-- 🛡️ FIX-SEO-23-01 (فاز ۲ — اثبات فرود با توکن یک‌بارمصرف + پیکسل/پست‌بک):
-- فاز ۱ ثابت کرد کاربر از ریدایرکت شمارندهٔ سرور عبور کرده (مهر click_counted_at)،
-- اما «رسیدن واقعی به سایت تبلیغ‌دهنده» همچنان اثبات‌نشده بود — کاربر می‌توانست
-- دکمه را بزند و تب را همان لحظه ببندد. فاز ۲ کانال بازگشتیِ اختیاری می‌سازد:
-- nonce مسیر go به‌عنوان توکن فرود به آدرس هدف الصاق می‌شود (پارامتر ckp) و
-- سایت تبلیغ‌دهنده با یکی از دو کانال بازگشت آن را تأیید می‌کند:
--
--   پیکسل  (<img src="/seo/px/{token}"> روی صفحهٔ فرود) — اثبات مرورگری، best-effort
--   پست‌بک (GET/POST /api/seo/postback با امضای HMAC از راز آگهی) — اثبات سروری، قوی
--
-- مشخصهٔ چهارگانهٔ مصوب:
--   ① وضعیت سه‌حالته (off/pixel/postback) + دکمهٔ تست یکپارچگی در جزئیات آگهی
--   ② پلهٔ پاداش سه‌پله‌ای: بدون‌اثبات ۶۰٪ ← کلیک‌اثبات‌شده ۸۵٪ ← فرود‌اثبات‌شده ۱۰۰٪
--   ③ پست‌بک جایگزینِ پیکسل برای سایت‌هایی که نمی‌توانند تصویر ردیاب بگذارند
--   ④ وعدهٔ صادقانه: هدف «گران‌کردن تقلب» است نه «صفرکردن» — بدون رد سختِ
--      جدید؛ فقط اقتصاد پاداش + شواهد ممیزی. تقلب‌کننده برای پلهٔ بالا باید
--      هزینهٔ واقعی بدهد (بارگذاری واقعی صفحه یا همکاری سرور تبلیغ‌دهنده).
--
-- تغییرات این مایگریشن (همه افزودنی — بدون حذف/تغییر داده):
--   ads.seo_landing_proof_mode   — حالت سه‌گانهٔ کانال اثبات فرود این آگهی (پیش‌فرض off)
--   ads.seo_postback_secret      — راز امضای پست‌بک این آگهی (hex-64؛ فقط حالت‌های فعال)
--   seo_executions.landing_verified_at    — مهر زمانی سرور: فرود از کانال رسمی تأیید شد
--   seo_executions.landing_proof_channel  — کانال تأیید (pixel|postback) برای ممیزی
--   seo_landing_proof_tests      — رفت‌وبرگشت دکمهٔ تست یکپارچگی تبلیغ‌دهنده (بدون
--                                  دست‌زدن به اجراهای واقعی کاربران)

ALTER TABLE `ads`
  ADD COLUMN `seo_landing_proof_mode` ENUM('off','pixel','postback') NOT NULL DEFAULT 'off'
    COMMENT 'فاز ۲ سئو: کانال اثبات فرود این آگهی — off=فقط مهر کلیک فاز ۱؛ pixel=تصویر ردیاب؛ postback=فراخوانی امضاشدهٔ سروری' AFTER `max_per_day`,
  ADD COLUMN `seo_postback_secret` CHAR(64) NULL DEFAULT NULL
    COMMENT 'فاز ۲ سئو: راز HMAC امضای پست‌بک این آگهی (hex-64؛ فقط وقتی mode فعال است)' AFTER `seo_landing_proof_mode`;

ALTER TABLE `seo_executions`
  ADD COLUMN `landing_verified_at` TIMESTAMP NULL DEFAULT NULL
    COMMENT 'فاز ۲ سئو: مهر سرور — فرود روی سایت هدف از کانال رسمی (پیکسل/پست‌بک) تأیید شد' AFTER `click_counted_at`,
  ADD COLUMN `landing_proof_channel` ENUM('pixel','postback') NULL DEFAULT NULL
    COMMENT 'فاز ۲ سئو: کانال تأیید فرود برای ممیزی' AFTER `landing_verified_at`;

CREATE TABLE IF NOT EXISTS `seo_landing_proof_tests` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ad_id`       INT UNSIGNED    NOT NULL COMMENT 'آگهیِ دارای mode فعال — تست مالکیت‌دار است',
  `token`       CHAR(48)        NOT NULL COMMENT 'nonce موقت تست (همان فرمت nonce مسیر go)',
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at`  DATETIME        NOT NULL COMMENT 'پنجرهٔ اعتبار تست (۱۰ دقیقه)',
  `received_at` DATETIME        NULL DEFAULT NULL COMMENT 'لحظهٔ رسیدن پیکسل/پست‌بک تست',
  `channel`     ENUM('pixel','postback') NULL DEFAULT NULL COMMENT 'کانالی که تست را تأیید کرد',
  `ip`          VARCHAR(45)     NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_seo_lpt_token` (`token`),
  KEY `idx_seo_lpt_ad` (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='فاز ۲ سئو: رفت‌وبرگشت دکمهٔ تست یکپارچگی پیکسل/پست‌بک تبلیغ‌دهنده';
