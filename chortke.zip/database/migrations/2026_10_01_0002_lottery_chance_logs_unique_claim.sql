-- =============================================================================
-- FIX-F-06 — قید یکتایی claim روزانهٔ شانس قرعه‌کشی (lottery_chance_logs)
-- =============================================================================
--
-- پیشینه: برای idempotency روزانه فقط ایندکس NON-UNIQUE idx_lcl_participation_date
-- وجود داشت و existsForParticipationDate یک SELECT ساده بود؛ دو اجرای هم‌پوشان
-- (کرون + اجرای دستی) هر دو «نبودن marker» را می‌دیدند، هر دو دلتای participation
-- را از خواندنِ کهنه اعمال و هر دو ردیف لاگ تکراری می‌نوشتند (اعوجاج وزن انتخاب
-- برنده + دوبار شمارش شانس).
--
-- راه‌حل: UNIQUE (participation_id, date) — Job اکنون «اول claim» می‌زند (INSERT
-- همان ردیف لاگ)؛ 1062 = قبلاً پردازش شده → skip. اتمیک در سطح DB، بدون پنجرهٔ race.
--
-- پاک‌سازی دادهٔ قبلی: ردیف‌های تکراریِ موجود ایجاد UNIQUE را می‌شکنند؛ نگه‌داشتن
-- قدیمی‌ترین (id کوچک‌تر) و حذف بقیه — معناشناسی «اولین پردازش» حفظ می‌شود.
-- =============================================================================

DELETE l1 FROM `lottery_chance_logs` l1
INNER JOIN `lottery_chance_logs` l2
    ON l1.participation_id = l2.participation_id
   AND l1.date = l2.date
   AND l1.id > l2.id;

ALTER TABLE `lottery_chance_logs`
    ADD UNIQUE KEY IF NOT EXISTS `uq_lcl_participation_date` (`participation_id`, `date`);
