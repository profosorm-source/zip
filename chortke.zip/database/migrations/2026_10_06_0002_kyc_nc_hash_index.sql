-- 🛡️ FIX-S10-04 (گزارش بخش ۱۰ — بقایای یکتایی کد ملی):
-- ایندکس روی national_code_hash برای lookup ثابت در مسیر submit (قبلاً
-- جست‌وجوی کاملِ جدول). تضمینِ یکتاییِ خود با kyc_national_code_registry
-- (UNIQUE uq_ncr_hash — مایگریشن 2026_10_04_0001) + claim اتمیک در verify()
-- انجام می‌شود؛ ایندکسِ زیر صرفاً کاراییِ مسیرِ submit است.

ALTER TABLE kyc_verifications
  ADD INDEX idx_kyc_nc_hash (national_code_hash);
