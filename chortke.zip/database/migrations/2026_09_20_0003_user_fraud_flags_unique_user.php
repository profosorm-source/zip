<?php
// ═══════════════════════════════════════════════════════════════════
// FIX (S-M review round 8-e) — UNIQUE(user_id) برای user_fraud_flags
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه: VelocityAndScoreModel (flagForReview / suspendAccount /
// requireKYC / flagForManualReview) با INSERT..ON DUPLICATE KEY UPDATE
// می‌نویسد ولی تنها کلیدِ جدول PRIMARY(id) + ایندکسِ غیریکتای
// idx_uff_user(user_id) بود → ON DUPLICATE هرگز fire نمی‌شد و برای هر
// کاربر بی‌نهایت ردیف انباشت می‌شد (رشد بی‌کران).
//
// ۱) اول جداسازیِ ردیف‌های تکراری: برای هر user_id کمترین id نگه داشته
//    می‌شود و بقیه حذف می‌شوند.
// ۲) بعد ایندکسِ غیریکتا حذف و UNIQUE(user_id) ساخته می‌شود.
//
// Idempotent (الگوی information_schema، همان راندهای قبل): اگر UNIQUE
// از قبل روی user_id وجود داشته باشد، skip می‌شود.

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r8e_fraud_flags_unique_exists')) {
    /** آیا یک UNIQUE index روی ستون user_id جدول user_fraud_flags هست؟ */
    function r8e_fraud_flags_unique_exists(PDO $db): bool
    {
        $stmt = $db->prepare(
            "SELECT COUNT(DISTINCT index_name) FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = 'user_fraud_flags'
               AND column_name = 'user_id'
               AND non_unique = 0"
        );
        $stmt->execute();
        return (int) $stmt->fetchColumn() > 0;
    }
}

if (!function_exists('r8e_fraud_flags_nonunique_index_name')) {
    /** نام ایندکس غیریکتای فعلی روی user_id (برای DROP)، یا null */
    function r8e_fraud_flags_nonunique_index_name(PDO $db): ?string
    {
        $stmt = $db->prepare(
            "SELECT index_name FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = 'user_fraud_flags'
               AND column_name = 'user_id'
               AND non_unique = 1
             LIMIT 1"
        );
        $stmt->execute();
        $name = $stmt->fetchColumn();
        return $name === false || $name === null ? null : (string) $name;
    }
}

if (!function_exists('r8e_fraud_flags_log')) {
    function r8e_fraud_flags_log(string $msg): void
    {
        echo '[8e-user-fraud-flags-unique] ' . $msg . PHP_EOL;
        if (function_exists('logger')) {
            try {
                logger()->info('migration.8e_fraud_flags_unique', ['msg' => $msg]);
            } catch (\Throwable $e) {
                // لاگ نباید مایگریشن را بشکند
            }
        }
    }
}

if (r8e_fraud_flags_unique_exists($db)) {
    r8e_fraud_flags_log('SKIP: UNIQUE index روی user_fraud_flags.user_id از قبل وجود دارد (idempotent).');
    return; // پایان تمیزِ فایل مایگریشن (بدون interrupt کردن runner)
}

// ۱) جداسازی تکراری‌ها: نگه‌داشتن کمترین id برای هر user_id
$dupCount = (int) $db->query('SELECT COUNT(*) FROM user_fraud_flags')->fetchColumn();
$deduped  = 0;
if ($dupCount > 0) {
    $deduped = $db->exec(
        'DELETE t1 FROM user_fraud_flags t1
         JOIN user_fraud_flags t2
           ON t2.user_id = t1.user_id AND t2.id < t1.id'
    );
    r8e_fraud_flags_log("DEDUPE: {$deduped} ردیف تکراری حذف شد (از {$dupCount} ردیف).");
} else {
    r8e_fraud_flags_log('DEDUPE: جدول خالی است — ردیف تکراری وجود ندارد.');
}

// ۲) تعویض ایندکس: حذف غیریکتای قدیمی (اگر هست) + ساخت UNIQUE
$oldIndex = r8e_fraud_flags_nonunique_index_name($db);
if ($oldIndex !== null) {
    $db->exec("ALTER TABLE user_fraud_flags DROP INDEX `" . str_replace('`', '', $oldIndex) . "`");
    r8e_fraud_flags_log("OK: ایندکس غیریکتای قدیمی '{$oldIndex}' حذف شد.");
}
$db->exec('ALTER TABLE user_fraud_flags ADD UNIQUE KEY uq_user_fraud_flags_user (user_id)');
r8e_fraud_flags_log('OK: UNIQUE KEY uq_user_fraud_flags_user (user_id) ساخته شد — ON DUPLICATE اکنون fire می‌شود.');
