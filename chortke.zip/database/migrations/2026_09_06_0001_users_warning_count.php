<?php

declare(strict_types=1);

/**
 * Migration (راند ۷۷ — ستون شبح): افزودن users.warning_count
 *
 * زنجیرهٔ هشدار تعدیل پیام (MessageModerationService + UserService::incrementWarningCount)
 * روی ستون users.warning_count نوشته می‌شد که هرگز وجود نداشت (خطای 42S22). این ستون
 * شمارش هشدارهای تعدیل را نگه می‌دارد و پایهٔ تشدید خودکار (بن بعد از هشدارهای مکرر) است.
 * Idempotent: با information_schema بررسی می‌شود.
 */

if (!function_exists('r77_column_exists')) { // FIX-S19-4: گارد فراخوانی‌مجدد (الگوی رسمی مایگریشن‌های پروژه)
function r77_column_exists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?"
    );
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}
}

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$pdo = $app->db()->getPdo();

$applied = 0;

if (!r77_column_exists($pdo, 'users', 'warning_count')) {
    $pdo->exec("ALTER TABLE users ADD COLUMN warning_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER is_blacklisted");
    $applied++;
    echo "users.warning_count added\n";
} else {
    echo "users.warning_count already exists\n";
}

echo "applied={$applied}\n";
