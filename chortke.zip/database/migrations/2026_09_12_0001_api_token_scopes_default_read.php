<?php
// ═══════════════════════════════════════════════════════════════════
// FIX-X350 (راند ۸۵) — پیش‌فرض امن ستون scopes جدول api_tokens
// ═══════════════════════════════════════════════════════════════════
//
// پیشینه: ستون scopes از نوع varchar(255) با DEFAULT '*' بود. همهٔ مسیرهای
// سرویس هنگام ساخت توکن مقدار صریح می‌نویسند، اما هر INSERT خام (ابزار/
// ادغام/اشتباه اپراتور) بدون تعیین scopes بی‌صدا یک توکن ادمینِ وایلدکارد
// (*) می‌ساخت. اصل کمترین دسترسی: پیش‌فرض امن = 'read' (fail-safe).
//
// idempotent (الگوی information_schema، همان راندهای قبل): فقط وقتی
// COLUMN_DEFAULT مؤثر دقیقاً '*' باشد ALTER اجرا می‌شود؛ اگر از قبل
// 'read' یا هر مقدارِ دیگری باشد skip می‌شود.
//
// ⚠ نکتهٔ سازگاری dialect (کشف در اجرای اول): MariaDB مقدار COLUMN_DEFAULT
// ستون‌های رشته‌ای را «با کوتیشن» برمی‌گرداند (مثل '*' یا 'read') ولی
// MySQL 8 همان مقدار را بدون کوتیشن می‌دهد؛ گارد باید هر دو حالت را
// نرمال‌سازی کند وگرنه روی MariaDB همیشه skip می‌شود.
//
// DDL ساده و سازگار با MariaDB 11.8 و Oracle MySQL 8.0.36:
//   ALTER TABLE api_tokens ALTER COLUMN scopes SET DEFAULT 'read'
//
// Generated: 2026-09-12

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db  = $app->db()->getPdo();

if (!function_exists('r85_scopes_column_default')) {
    /**
     * مقدار COLUMN_DEFAULT ستون scopes جدول api_tokens
     * (null = ستون/جدول غایب؛ خروجی نرمال‌شده و بدون کوتیشن dialect است)
     */
    function r85_scopes_column_default(PDO $db): ?string
    {
        $stmt = $db->prepare(
            "SELECT COLUMN_DEFAULT FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE()
               AND table_name = 'api_tokens'
               AND column_name = 'scopes'"
        );
        $stmt->execute();

        $val = $stmt->fetchColumn();
        if ($val === false || $val === null) {
            return null;
        }

        // نرمال‌سازی dialect: MariaDB رشته‌ها را با کوتیشن تک برمی‌گرداند
        // ('*' → *)؛ MySQL 8 بدون کوتیشن. کوتیشن‌های دوتاییِ escape شده هم باز می‌شوند.
        $val = (string) $val;
        if (strlen($val) >= 2 && $val[0] === "'" && substr($val, -1) === "'") {
            $val = substr($val, 1, -1);
            $val = str_replace("''", "'", $val);
        }

        return $val;
    }
}

$log = static function (string $msg): void {
    // خروجی قابل‌مشاهده در cli.php migration و لاگ
    echo '[x350-api-token-scopes-default] ' . $msg . PHP_EOL;
    if (function_exists('logger')) {
        try {
            logger()->info('migration.x350', ['msg' => $msg]);
        } catch (\Throwable $e) {
            // لاگ نباید مایگریشن را بشکند
        }
    }
};

$current = r85_scopes_column_default($db);

if ($current === null) {
    $log('SKIP: ستون api_tokens.scopes یافت نشد (جدول غایب؟) — دست‌نخورده.');
} elseif ($current !== '*') {
    $log("SKIP: پیش‌فرض فعلی scopes برابر '{$current}' است (idempotent — فقط از '*' مهاجرت می‌شود).");
} else {
    $db->exec("ALTER TABLE api_tokens ALTER COLUMN scopes SET DEFAULT 'read'");
    $log("OK: پیش‌فرض scopes از '*' (وایلدکارد ادمین) به 'read' (کم‌ترین دسترسی) تغییر یافت.");
}
