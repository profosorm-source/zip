-- ============================================================================
-- FIX-SCR-CREATED-IDX — ایندکس created_at برای social_camera_requests
-- (بازبینی نهایی 2026-10-28 — تکمیل FIX-CAM-CLEANUP-V7)
-- ----------------------------------------------------------------------------
-- زمان‌بندی پاک‌سازی ۰۴:۰۰ (SystemCleanupCommand،Kernel) روی ستونی فیلتر
-- می‌کند که هیچ ایندکسی ندارد:
--   DELETE FROM social_camera_requests WHERE created_at < DATE_SUB(...)
-- ایندکس‌های موجود: idx_scr_method_status (method,status,expires_at)،
-- idx_scr_verdict (server_verdict,status,expires_at)، uq_scr_nonce_hash —
-- هیچ‌کدام created_at را پوشش نمی‌دهند ⇒ هر شب full-table-scan روی جدولی
-- که ماه‌ها رشد نامحدود داشته (خودِ باگی که پاک‌سازی برای بستنش ساخته شد).
--
-- این ایندکس + DELETE دسته‌ای (FIX-SCR-BATCH در خود کامند) پاک‌سازی را
-- از «اسکن کامل با قفل طولانی» به «range-scan کوتاه در دسته‌های ۱۰۰۰تایی»
-- تغییر می‌دهد.
--
-- Idempotent (IF NOT EXISTS)؛ سازگار با MariaDB ≥ 10.4 — هم‌الگوی سایر
-- مایگریشن‌های همین پوشه.
-- ============================================================================

CREATE INDEX IF NOT EXISTS `idx_scr_created`
  ON `social_camera_requests` (`created_at`);
