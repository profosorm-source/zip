<?php

namespace Tests\Support;

/**
 * Fixture برای FIX-S3-1 (ممیزی امنیتی S3):
 *
 * این کلاس عمداً Event نیست ولی متد استاتیک fromPayload دارد — همان امضایی که
 * EventDispatcher::processQueuedEvent قبلاً بدون هیچ گایتی از روی payload صف
 * فراخوانی می‌کرد. اگر گیتِ «فقط زیرکلاس Core\Event» حذف شود، از طریق payload
 * صف می‌توان این متد را با دادهٔ دلخواه صدا زد (instantiation/فراخوانی استاتیک
 * کنترل‌شده توسط payload). تست‌ها با این پرچمDetect می‌کنند که فراخوانی رخ داده
 * یا نه.
 */
class QueuePayloadProbeClass
{
    /** @var bool */
    public static $fromPayloadCalled = false;

    /** @var list<mixed> */
    public static $fromPayloadArgs = [];

    public static function reset(): void
    {
        self::$fromPayloadCalled = false;
        self::$fromPayloadArgs = [];
    }

    /** @param mixed $data */
    public static function fromPayload($data): ?object
    {
        self::$fromPayloadCalled = true;
        self::$fromPayloadArgs[] = $data;
        return null;
    }
}
