<?php

declare(strict_types=1);

/**
 * 🛡️ FIX-R20-CY2-C — worker فرزندِ تست تعارض قفل ConcurrentRequestMiddleware.
 *
 * این پروسه در چهار حالت اجرا می‌شود:
 *   ajax-conflict              → درخواست همزمان دومِ Ajax (قفلِ مالکِ دیگر موجود)
 *                                روی مسیر غیرمالی → قرارداد: ۴۲۹/JSON بدون رسیدن
 *                                به $next — مکانیزم مجاز: HttpResponseException
 *                                (short-circuit پایپ‌لاین، FIX-R20-CY2-C) یا
 *                                Response برگشتی (Response-builder، FIX-R21-AJAX).
 *                                (در کد قدیمی: پرتابِ json() توسط catch(\Throwable)
 *                                بلعیده می‌شد → چون مسیر غیرمالی است fail-open →
 *                                $next بی‌قفل اجرا می‌شد!)
 *   plain-conflict             → همان تعارض بدون Ajax → Response 429 متنی برگردانده
 *                                می‌شود و $next اجرا نمی‌شود.
 *   redis-error-nonfinancial   → خطای واقعی Redis در SET روی مسیر غیرمالی →
 *                                fail-open طراحی‌شدهٔ L-07: $next اجرا می‌شود.
 *   redis-error-financial-ajax → خطای Redis روی مسیر مالی + Ajax → fail-closed:
 *                                503 JSON از serviceUnavailable (استثنا یا Response).
 *
 * Redis با کلاس ماکِ درون‌حافظه‌ای جایگزین شده (بدون اتصال واقعی) و همهٔ
 * فراخوانی‌ها + وضعیت نهایی store + نتیجهٔ handle (استثنا/پاسخ) به فایل JSON
 * نوشته می‌شوند تا تستِ والد از بیرونِ پروسه راستی‌آزمایی کند.
 * (الگوی tests/Support/concurrent_lock_exit_worker.php)
 *
 * Usage: php concurrent_lock_conflict_worker.php <result-file> <ajax-conflict|plain-conflict|redis-error-nonfinancial|redis-error-financial-ajax>
 */

if ($argc !== 3) {
    fwrite(STDERR, "Usage: concurrent_lock_conflict_worker.php <result-file> <ajax-conflict|plain-conflict|redis-error-nonfinancial|redis-error-financial-ajax>\n");
    exit(64);
}

[$script, $resultFile, $mode] = $argv;
$modes = ['ajax-conflict', 'plain-conflict', 'redis-error-nonfinancial', 'redis-error-financial-ajax'];
if (!in_array($mode, $modes, true)) {
    fwrite(STDERR, "mode must be one of: " . implode('|', $modes) . "\n");
    exit(64);
}

$GLOBALS['resultFile'] = $resultFile;
$GLOBALS['mode'] = $mode;
$GLOBALS['nextCalled'] = false;

// بوت پیش از تعریف کلاس‌ها — Core\Redis فقط پس از autoload در دسترس است
require dirname(__DIR__, 2) . '/bootstrap/testing.php';

/**
 * کلاینت ماک — همان زیرمجموعه‌ای از API که خودِ middleware صدا می‌زند.
 * امضاها دقیقاً با phpredis هم‌خوان‌اند (PHP 8 override سازگاری امضا می‌خواهد).
 *
 * رفتار بر اساس mode:
 *   conflict modes → set با NX روی کلید lock:user: قفلِ مالکِ دیگر را می‌بیند
 *                    (store از قبل با توکنِ خارجی seed شده) و false برمی‌گرداند.
 *   error modes    → set با RedisException می‌ترود (شبیه‌سازی قطعِ mid-flight).
 */
class FakeConflictRedisClient extends \Redis
{
    /** @var array<string, string> */
    public array $store = [];
    /** @var array<int, array<string, mixed>> */
    public array $calls = [];
    public bool $failSet = false;

    public function __construct(bool $seedForeignLock = false, string $seedKey = '')
    {
        // عمداً بدون parent::__construct — هیچ اتصال واقعی در کار نیست
        if ($seedForeignLock && $seedKey !== '') {
            // شبیه‌سازی درخواست اولِ هم‌زمان که قفل را گرفته و هنوز نگه داشته
            $this->store[$seedKey] = 'foreign-owner-' . bin2hex(random_bytes(8));
        }
    }

    /** @param mixed $options */
    public function set(string $key, mixed $value, mixed $options = null): \Redis|string|bool
    {
        if ($this->failSet) {
            $this->record('set-threw', $key);
            throw new \RedisException('simulated redis outage during SET NX');
        }
        $nx = is_array($options) && in_array('NX', $options, true);
        if ($nx && array_key_exists((string)$key, $this->store)) {
            $this->record('set-nx-blocked', $key);
            return false;
        }
        $this->store[(string)$key] = (string)$value;
        $this->record('set-nx-acquired', $key);
        return true;
    }

    public function eval(string $script, array $args = [], int $num_keys = 0): mixed
    {
        $key = (string)($args[0] ?? '');
        $owner = (string)($args[1] ?? '');
        $deleted = 0;
        if (($this->store[$key] ?? null) === $owner) {
            unset($this->store[$key]);
            $deleted = 1;
        }
        $this->record('eval-compare-and-del', $key, ['deleted' => $deleted, 'owner_matched' => $deleted === 1]);
        return $deleted;
    }

    public function get(string $key): mixed
    {
        $value = $this->store[$key] ?? false;
        $this->record('get', $key);
        return $value;
    }

    public function del(array|string $key, string ...$other_keys): \Redis|int|false
    {
        $keys = array_merge(is_array($key) ? $key : [$key], $other_keys);
        $deleted = 0;
        foreach ($keys as $k) {
            if (array_key_exists((string)$k, $this->store)) {
                unset($this->store[(string)$k]);
                $deleted++;
            }
        }
        $this->record('del', (string)($keys[0] ?? ''), ['deleted' => $deleted]);
        return $deleted;
    }

    /** @param array<string, mixed> $extra */
    public function record(string $op, string $key, array $extra = []): void
    {
        $this->calls[] = array_merge(['op' => $op, 'key' => $key, 'at' => microtime(true)], $extra);
        // وضعیت کامل در هر فراخوانی به فایل نتیجه می‌رسد — کانال ارتباط با والده
        @file_put_contents(
            $GLOBALS['resultFile'],
            json_encode([
                'mode'        => $GLOBALS['mode'],
                'calls'       => $this->calls,
                'store'       => $this->store,
                'next_called' => $GLOBALS['nextCalled'] ?? false,
                'outcome'     => $GLOBALS['outcome'] ?? null,
            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
        );
    }
}

/** wrapper ماک Core\Redis — بدون parent::__construct تا اتصال واقعی نشود. */
class FakeConflictCoreRedis extends \Core\Redis
{
    public FakeConflictRedisClient $fakeClient;

    public function __construct(FakeConflictRedisClient $client)
    {
        $this->fakeClient = $client;
    }

    public function isAvailable(): bool
    {
        return true;
    }

    public function getClient(): ?\Redis
    {
        return $this->fakeClient;
    }
}

// ---- تنظیم سناریو بر اساس mode ----

$isConflict = ($mode === 'ajax-conflict' || $mode === 'plain-conflict');
$isRedisError = ($mode === 'redis-error-nonfinancial' || $mode === 'redis-error-financial-ajax');
$isAjax = ($mode === 'ajax-conflict' || $mode === 'redis-error-financial-ajax');

// مسیر: مالی فقط برای حالت financial؛ بقیه پروب‌های غیرمالی
$uri = ($mode === 'redis-error-financial-ajax')
    ? '/wallet/transfer'
    : '/lock-conflict-probe/' . bin2hex(random_bytes(4));

// هویت قفل '42' و کلید مورد انتظار میان‌افزار — برای seed قفلِ خارجی
$lockKey = 'lock:user:42:' . md5($uri);

$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['REQUEST_URI'] = $uri;
$_SERVER['REQUEST_SCHEME'] = 'http';
$_SERVER['HTTP_HOST'] = '127.0.0.1';
if ($isAjax) {
    $_SERVER['HTTP_X_REQUESTED_WITH'] = 'XMLHttpRequest';
}

$client = new FakeConflictRedisClient($isConflict, $isConflict ? $lockKey : '');
$client->failSet = $isRedisError;
$redis = new FakeConflictCoreRedis($client);

session()->ensureStarted();
$_SESSION['user_id'] = 42; // هویت قفل: '42'

$request = new \Core\Request();
$middleware = new \App\Middleware\ConcurrentRequestMiddleware($redis, null);

$fnNext = static function ($req): \Core\Response {
    $GLOBALS['nextCalled'] = true;
    return new \Core\Response();
};

/** @var array<string, mixed> $outcome */
$outcome = [
    'exception_class' => null,
    'status'          => null,
    'content'         => '',
    'content_type'    => null,
    'returned_status' => null,
    'unexpected'      => null,
];
$GLOBALS['outcome'] = $outcome;

try {
    $returned = $middleware->handle($request, $fnNext);
    if ($returned instanceof \Core\Response) {
        $outcome['returned_status'] = $returned->getStatusCode();
        $outcome['content'] = $returned->getContent();
        $outcome['content_type'] = $returned->getHeader('Content-Type');
    }
} catch (\Core\Exceptions\HttpResponseException $e) {
    // رفتار صحیح short-circuit پایپ‌لاین (H10) — همان چیزی که Router می‌گیرد
    $resp = $e->getResponse();
    $outcome['exception_class'] = get_class($e);
    $outcome['status'] = $resp->getStatusCode();
    $outcome['content'] = $resp->getContent();
    $outcome['content_type'] = $resp->getHeader('Content-Type');
} catch (\Throwable $e) {
    $outcome['unexpected'] = get_class($e) . ': ' . $e->getMessage();
}

$GLOBALS['outcome'] = $outcome;
$client->record('worker-complete', 'final');
exit(0);
