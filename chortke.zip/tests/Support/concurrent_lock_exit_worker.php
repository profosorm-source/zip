<?php

declare(strict_types=1);

/**
 * 🛡️ FIX-R20-CY2-B — worker فرزندِ تست نشت قفل ConcurrentRequestMiddleware.
 *
 * این پروسه در سه حالت اجرا می‌شود:
 *   exit   → $next با exit() تمام می‌شود (شبیه‌سازی RateLimitPolicy::tooManyResponse
 *            که بعد از echo با exit خارج می‌شود) — باید قفل توسط تور ایمنیِ
 *            shutdown آزاد شود، چون PHP بلاک finally را هنگام exit اجرا نمی‌کند.
 *   normal → $next پاسخ عادی برمی‌گرداند — finally آزاد می‌کند و shutdown نباید
 *            آزادسازی مضاعف بزند.
 *   throw  → $next استثنا می‌دهد — finally آزاد می‌کند (رفتار FIX-R19-A7-2).
 *
 * Redis با کلاس ماکِ درون‌حافظه‌ای جایگزین شده (بدون اتصال واقعی) و همهٔ
 * فراخوانی‌ها (set/eval/get/del) + وضعیت نهایی store به فایل نتیجهٔ JSON
 * نوشته می‌شوند تا تستِ والد رفتار را از بیرونِ پروسه راستی‌آزمایی کند.
 * (الگوی tests/Support/payment_callback_worker.php)
 *
 * Usage: php concurrent_lock_exit_worker.php <result-file> <exit|normal|throw>
 */

if ($argc !== 3) {
    fwrite(STDERR, "Usage: concurrent_lock_exit_worker.php <result-file> <exit|normal|throw>\n");
    exit(64);
}

[$script, $resultFile, $mode] = $argv;
if (!in_array($mode, ['exit', 'normal', 'throw'], true)) {
    fwrite(STDERR, "mode must be exit|normal|throw\n");
    exit(64);
}

$GLOBALS['resultFile'] = $resultFile;
$GLOBALS['mode'] = $mode;
$GLOBALS['reachedAfterHandle'] = false;

// بوت پیش از تعریف کلاس‌ها — Core\Redis فقط پس از autoload در دسترس است
require dirname(__DIR__, 2) . '/bootstrap/testing.php';

/**
 * کلاینت ماک — همان زیرمجموعه‌ای از API که خودِ middleware صدا می‌زند.
 * امضاها دقیقاً با phpredis هم‌خوان‌اند (PHP 8 override سازگاری امضا می‌خواهد).
 */
class FakeLockRedisClient extends \Redis
{
    /** @var array<string, string> */
    public array $store = [];
    /** @var array<int, array<string, mixed>> */
    public array $calls = [];

    public function __construct()
    {
        // عمداً بدون parent::__construct — هیچ اتصال واقعی در کار نیست
    }

    /** @param mixed $options */
    public function set(string $key, mixed $value, mixed $options = null): \Redis|string|bool
    {
        $nx = is_array($options) && in_array('NX', $options, true);
        if ($nx && array_key_exists((string)$key, $this->store)) {
            $this->record('set-nx-blocked', $key);
            return false;
        }
        $this->store[(string)$key] = (string)$value;
        $this->record('set-nx-acquired', $key);
        return true;
    }

    public function eval(string $script, array $args = [], int $num_keys = 0): mixed
    {
        // همان معناشناسی Lua compare-and-del مالک‌آگاهِ releaseOwnedLock
        $key = (string)($args[0] ?? '');
        $owner = (string)($args[1] ?? '');
        $deleted = 0;
        if (($this->store[$key] ?? null) === $owner) {
            unset($this->store[$key]);
            $deleted = 1;
        }
        $this->record('eval-compare-and-del', $key, ['deleted' => $deleted, 'owner_matched' => $deleted === 1]);
        return $deleted;
    }

    public function get(string $key): mixed
    {
        $value = $this->store[$key] ?? false;
        $this->record('get', $key);
        return $value;
    }

    public function del(array|string $key, string ...$other_keys): \Redis|int|false
    {
        $keys = array_merge(is_array($key) ? $key : [$key], $other_keys);
        $deleted = 0;
        foreach ($keys as $k) {
            if (array_key_exists((string)$k, $this->store)) {
                unset($this->store[(string)$k]);
                $deleted++;
            }
        }
        $this->record('del', (string)($keys[0] ?? ''), ['deleted' => $deleted]);
        return $deleted;
    }

    /** @param array<string, mixed> $extra */
    public function record(string $op, string $key, array $extra = []): void
    {
        $this->calls[] = array_merge(['op' => $op, 'key' => $key, 'at' => microtime(true)], $extra);
        // نوشتن وضعیت کامل در هر فراخوانی — حتی فراخوانی‌های داخل shutdown callback
        // (پس از exit) به فایل می‌رسند؛ این همان کانال ارتباط با پروسهٔ والده.
        @file_put_contents(
            $GLOBALS['resultFile'],
            json_encode([
                'mode'   => $GLOBALS['mode'],
                'calls'  => $this->calls,
                'store'  => $this->store,
                'reached_after_handle' => $GLOBALS['reachedAfterHandle'] ?? false,
            ], JSON_UNESCAPED_SLASHES)
        );
    }
}

/** wrapper ماک Core\Redis — بدون parent::__construct تا اتصال واقعی نشود. */
class FakeLockCoreRedis extends \Core\Redis
{
    public FakeLockRedisClient $fakeClient;

    public function __construct()
    {
        $this->fakeClient = new FakeLockRedisClient();
    }

    public function isAvailable(): bool
    {
        return true;
    }

    public function getClient(): ?\Redis
    {
        return $this->fakeClient;
    }
}

// پروبِ مستقل از توکن: هویت مستقیم روی سشنِ در-شروع‌شده ست می‌شود
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['REQUEST_URI'] = '/lock-exit-probe/' . bin2hex(random_bytes(4));
$_SERVER['REQUEST_SCHEME'] = 'http';
$_SERVER['HTTP_HOST'] = '127.0.0.1';

$redis = new FakeLockCoreRedis();

session()->ensureStarted();
$_SESSION['user_id'] = 42; // هویت قفل: '42'

$request = new \Core\Request();
$middleware = new \App\Middleware\ConcurrentRequestMiddleware($redis, null);

$fnNext = static function ($req) use ($mode): mixed {
    if ($mode === 'exit') {
        exit(0); // شبیه‌سازی exit ترمینالِ Policy (مثل tooManyResponse)
    }
    if ($mode === 'throw') {
        throw new \RuntimeException('probe-boom');
    }
    return new \Core\Response();
};

if ($mode === 'throw') {
    try {
        $middleware->handle($request, $fnNext);
    } catch (\Throwable $e) {
        // استثنا در تست والد از روی فایل نتیجه بررسی می‌شود
    }
} else {
    $middleware->handle($request, $fnNext);
}

$GLOBALS['reachedAfterHandle'] = true;
// برای حالت normal: ثبت وضعیت نهایی پس از handle (finally اجرا شده)
$redis->fakeClient->record('worker-complete', 'final');
exit(0);
