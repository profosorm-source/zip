<?php

declare(strict_types=1);

/**
 * fake-provider-tls-proxy.php — پروکسی پایان‌دهندهٔ TLS برای سرور جعلی provider
 *
 * چرا این فایل لازم است:
 *   آداپتور DeepFace (KYC بیومتریک) طبق FIX-S10-14 فقط scheme «https» را
 *   می‌پذیرد و طبق مصوبهٔ Round-18 P2 اعتبارسنجی TLS روی آن هاردکد/روشن است
 *   (هرگز از config قابل خاموش‌کردن نیست). سرور توکارِ PHP خودش TLS ندارد،
 *   پس قراردادِ واقعیِ HTTPS را فقط می‌توان با یک پایان‌دهندهٔ TLS آزمود.
 *   این پروکسی بایت‌های خام را بین یک سوکت TLS و سرور HTTP جعلی لوله
 *   می‌کند — بدون هیچ تغییرِ امنیتی در آداپتور یا سرور جعلی.
 *
 * قرارداد محیط (همه اختیاری):
 *   FAKE_TLS_LISTEN_HOST   (پیش‌فرض 8.8.8.8 — همان IP عمومی alias شده روی lo)
 *   FAKE_TLS_LISTEN_PORT   (پیش‌فرض 8093)
 *   FAKE_TLS_UPSTREAM_HOST (پیش‌فرض 127.0.0.1)
 *   FAKE_TLS_UPSTREAM_PORT (پیش‌فرض 8092)
 *   FAKE_TLS_CERT          (PEM شامل گواهی + کلید سرور؛ پیش‌فرض
 *                           build/provider-fake-tls/server.pem)
 *
 * اجرا (به‌صورت معمول از طریق tests/Support/run-contract-suite.sh داخل
 * network namespace):
 *   php tests/Support/fake-provider-tls-proxy.php
 */

$listenHost   = getenv('FAKE_TLS_LISTEN_HOST') ?: '8.8.8.8';
$listenPort   = (int) (getenv('FAKE_TLS_LISTEN_PORT') ?: '8093');
$upstreamHost = getenv('FAKE_TLS_UPSTREAM_HOST') ?: '127.0.0.1';
$upstreamPort = (int) (getenv('FAKE_TLS_UPSTREAM_PORT') ?: '8092');
$certFile     = getenv('FAKE_TLS_CERT') ?: dirname(__DIR__, 2) . '/build/provider-fake-tls/server.pem';

if (!is_file($certFile)) {
    fwrite(STDERR, "TLS proxy: certificate not found: {$certFile}\n");
    exit(1);
}

$context = stream_context_create([
    'ssl' => [
        'local_cert'          => $certFile,
        // سمت سرور: کلاینت (curl) گواهی ما را با CA bundle خودش تأیید می‌کند؛
        // این گزینه‌ها فقط دربارهٔ احرازِ «کلاینت» هستند و در این قرارداد
        // mutual-TLS نداریم.
        'verify_peer'         => false,
        'verify_peer_name'    => false,
        'SNI_enabled'         => true,
        'use_openssl'         => true,
    ],
]);

$server = @stream_socket_server(
    "ssl://{$listenHost}:{$listenPort}",
    $errno,
    $errstr,
    STREAM_SERVER_BIND | STREAM_SERVER_LISTEN,
    $context
);
if ($server === false) {
    fwrite(STDERR, "TLS proxy: cannot listen on {$listenHost}:{$listenPort}: [{$errno}] {$errstr}\n");
    exit(1);
}
stream_context_set_option($server, ['ssl' => ['crypto_method' => STREAM_CRYPTO_METHOD_TLS_SERVER]]);
fwrite(STDERR, "TLS proxy: https://{$listenHost}:{$listenPort} -> http://{$upstreamHost}:{$upstreamPort}\n");

/**
 * لولهٔ دوسویهٔ بایت‌های خام تا بسته‌شدنِ هر یک از طرف‌ها.
 * curl پس از خواندن کاملِ پاسخ (Content-Length) اتصال را می‌بندد؛
 * همین EOF سمت کلاینت، علامت پایانِ درخواست/پاسخ است.
 */
function pipe_once($client, $upstream): void
{
    $pair = [$client, $upstream];
    stream_set_blocking($client, true);
    stream_set_blocking($upstream, true);
    while (true) {
        $read = $pair;
        $write = null;
        $except = null;
        $ready = @stream_select($read, $write, $except, 10, 0);
        if ($ready === false) {
            return;
        }
        if ($ready === 0) {
            continue; // idle — حلقهٔ بعدی select
        }
        foreach ($read as $socket) {
            $chunk = @fread($socket, 65536);
            if ($chunk === false || $chunk === '') {
                return; // EOF یا خطا در یکی از طرف‌ها
            }
            $destination = ($socket === $client) ? $upstream : $client;
            $written = 0;
            $length  = strlen($chunk);
            while ($written < $length) {
                $sent = @fwrite($destination, substr($chunk, $written));
                if ($sent === false || $sent === 0) {
                    return;
                }
                $written += $sent;
            }
        }
    }
}

while (true) {
    $client = @stream_socket_accept($server, 3600);
    if ($client === false) {
        continue; // timeout — حلقهٔ بعدی
    }
    $upstream = @stream_socket_client(
        "tcp://{$upstreamHost}:{$upstreamPort}",
        $uerrno,
        $uerrstr,
        5.0
    );
    if ($upstream === false) {
        fwrite(STDERR, "TLS proxy: upstream connect failed: [{$uerrno}] {$uerrstr}\n");
        @fclose($client);
        continue;
    }
    pipe_once($client, $upstream);
    // flushِ نهایی پاسخ پیش از بستن
    @stream_set_blocking($client, false);
    @stream_set_blocking($upstream, false);
    usleep(1000); // یک تیک به بافرهای TLS برای تخلیهٔ نهایی
    @fclose($upstream);
    @fclose($client);
}
