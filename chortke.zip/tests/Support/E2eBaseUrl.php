<?php

declare(strict_types=1);

namespace Tests\Support;

/**
 * تعیین آدرس سرور E2E بدون وابستگی به یک پورت ثابت.
 * ترتیب: CHORTKE_E2E_BASE_URL → اولین کاندیدای در حال گوش‌دادن (E2E_PORT از محیط/.env — پیش‌فرض 8090 —، سپس APP_URL پروژه).
 * اگر هیچ‌کدام بالا نبود، آدرس پیش‌فرض برگردانده می‌شود و تست‌ها طبق قرارداد قبلی skip/fail می‌شوند.
 */
final class E2eBaseUrl
{
    private const FALLBACK = 'http://127.0.0.1:8090';

    public static function resolve(): string
    {
        $configured = getenv('CHORTKE_E2E_BASE_URL');
        if (is_string($configured) && $configured !== '') {
            return rtrim($configured, '/');
        }

        $port = self::envValue('E2E_PORT');
        $candidates = [$port !== '' ? 'http://127.0.0.1:' . $port : self::FALLBACK];
        $appUrl = self::envValue('APP_URL');
        if ($appUrl !== '') {
            $candidates[] = rtrim($appUrl, '/') . '/' . trim(self::envValue('APP_BASE_PATH'), '/');
        }

        foreach ($candidates as $url) {
            $url = rtrim($url, '/');
            if (self::isListening($url)) {
                return $url;
            }
        }
        return self::FALLBACK;
    }

    private static function envValue(string $key): string
    {
        $v = getenv($key);
        if (is_string($v) && $v !== '') {
            return $v;
        }
        $file = dirname(__DIR__, 2) . '/.env';
        if (is_file($file)) {
            foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
                if (str_starts_with($line, $key . '=')) {
                    return trim(substr($line, strlen($key) + 1), " \t\"'");
                }
            }
        }
        return '';
    }

    private static function isListening(string $url): bool
    {
        $p = parse_url($url);
        if (!is_array($p) || empty($p['host'])) {
            return false;
        }
        $port = $p['port'] ?? (($p['scheme'] ?? 'http') === 'https' ? 443 : 80);
        $s = @fsockopen($p['host'], (int)$port, $errno, $errstr, 0.3);
        if ($s === false) {
            return false;
        }
        fclose($s);
        return true;
    }
}
