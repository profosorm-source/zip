<?php

declare(strict_types=1);

namespace Tests\Fixtures;

use Core\Model;

final class RuntimeRaceModel extends Model
{
    protected static string $table = 'phase20_model_race';

    /*
    | FIX-YAFTE4 (یافته ۴): قرارداد FIX-S9-03 در filterFillable — مدل بدون
    | $fillable به‌صورت deny-by-default می‌نویسد [] (و insert خالی استثنا
    | می‌پراند). این fixture صریحاً ستون‌های مسیرِ race را opt-in می‌کند
    | (تستِ firstOrCreate است، نه mass-assignment)؛ گاردِ ستون همچنان
    | مستقل روی همان مجموعه اجرا می‌شود.
    */
    protected array $fillable = ['id', 'email', 'slug', 'name'];
}
