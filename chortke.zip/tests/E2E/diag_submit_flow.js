// diag_submit_flow.js — trace what happens after the submit click
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');
const BASE = process.env.CHORTKE_BASE_URL || 'http://127.0.0.1:8090';
const MOBILE_UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36';

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ userAgent: MOBILE_UA, viewport: { width: 412, height: 915 }, isMobile: true, hasTouch: true });
  const page = await context.newPage();

  page.on('console', m => { if (['error', 'warning'].includes(m.type())) console.log(`  [console.${m.type()}] ${m.text().slice(0, 150)}`); });
  page.on('dialog', async d => { console.log(`  [native-dialog:${d.type()}] ${d.message().slice(0, 80)}`); await d.accept(); });
  page.on("request", r => { if (r.url().includes("/social-tasks/") && !r.url().includes("assets")) console.log(`  [req ${new Date().toISOString().slice(14, 23)}] ${r.method()} ${r.url().replace(BASE, "")}`); });
  page.on('response', r => { if (r.url().includes('/social-tasks/')) console.log(`  [res] ${r.status()} ${r.url().replace(BASE, '')}`); });

  await page.goto(BASE + '/login');
  await page.getByRole('textbox', { name: 'ایمیل یا موبایل' }).fill('user@chortke.ir');
  await page.getByRole('textbox', { name: 'رمز عبور' }).fill('Test@12345');
  await page.getByRole('button', { name: 'ورود', exact: true }).click();
  await page.waitForURL('**/dashboard', { timeout: 15000 });

  await page.goto(BASE + '/tasks');
  await page.waitForLoadState('networkidle');
  await page.getByRole('button', { name: 'شروع اجرای امتیازی' }).first().click();
  await page.waitForURL('**/social-tasks/**/execute', { timeout: 15000 });
  const execId = page.url().match(/social-tasks\/(\d+)\/execute/)[1];
  console.log(`execution_id=${execId} — waiting 44s`);
  await page.waitForTimeout(44000);

  console.log('── CLICK submit ──');
  await page.getByRole('button', { name: /پایان و محاسبه امتیاز/ }).click();

  for (let i = 1; i <= 8; i++) {
    await page.waitForTimeout(2000);
    const state = await page.evaluate(() => ({
      swal: !!document.querySelector('.swal2-confirm'),
      swalVisible: !!document.querySelector('.swal2-container'),
      btnDisabled: !!document.getElementById('submitBtn')?.disabled,
      url: location.href,
      toasts: Array.from(document.querySelectorAll('.notyf__message')).map(e => e.textContent.trim()).slice(-2),
    })).catch(e => ({ err: e.message.slice(0, 80) }));
    console.log(`  t+${i * 2}s ${JSON.stringify(state)}`);
  }
  await browser.close();
})();
