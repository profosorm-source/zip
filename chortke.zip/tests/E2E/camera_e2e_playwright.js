// camera_e2e_playwright.js — Grand E2E: full camera-verifier positive path in a REAL browser
// (Playwright + Chrome with fake camera device + granted camera permission).
//
// Flow: login (mobile UA) → tasks market → start fresh social ad → execute page →
//       wait ~44s (farm-exact-timing → behavior 30 → camera_required) →
//       consent dialog 1 (camera) → consent dialog 2 (spot check, D1) →
//       camera-challenge → getUserMedia (fake device) → 4 frames → spot image →
//       camera-verify → verdict toast → resubmit (pause-release fix!) → final decision.
//
// Evidence: screenshots + step log + network log of camera calls.
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const BASE = process.env.CHORTKE_BASE_URL || 'http://127.0.0.1:8090';
const SHOTS = '/home/z/my-project/download/e2e-screenshots';
const CHROME = '/home/z/.agent-browser/browsers/chrome-155.0.8059.39/chrome';
const MOBILE_UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36';

const results = [];
const ok = (name, detail = '') => { results.push(['PASS', name, detail]); console.log(`  ✓ ${name}${detail ? ' — ' + detail : ''}`); };
const bad = (name, detail = '') => { results.push(['FAIL', name, detail]); console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); };

(async () => {
  const browser = await chromium.launch({
    executablePath: CHROME,
    headless: true,
    args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--no-sandbox', '--disable-dev-shm-usage'],
  });
  const context = await browser.newContext({
    permissions: ['camera'],
    userAgent: MOBILE_UA,
    viewport: { width: 412, height: 915 },
    isMobile: true,
    hasTouch: true,
  });
  const page = await context.newPage();

  // Verify fake camera availability FIRST (precondition)
  await page.goto(BASE + '/');
  const camProbe = await page.evaluate(async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      const label = s.getVideoTracks()[0].label;
      s.getTracks().forEach(t => t.stop());
      return 'OK:' + label;
    } catch (e) { return 'FAIL:' + e.name; }
  });
  camProbe.startsWith('OK') ? ok('precondition: fake camera stream', camProbe) : bad('precondition: fake camera stream', camProbe);
  await page.screenshot({ path: `${SHOTS}/cam-00-home.png` });

  // ── Step 1: login ──
  console.log('── ورود ──');
  await page.goto(BASE + '/login');
  await page.getByRole('textbox', { name: 'ایمیل یا موبایل' }).fill('user@chortke.ir');
  await page.getByRole('textbox', { name: 'رمز عبور' }).fill('Test@12345');
  await page.getByRole('button', { name: 'ورود', exact: true }).click();
  await page.waitForURL('**/dashboard', { timeout: 15000 });
  ok('login user@chortke.ir → /dashboard');

  // ── Step 2: find the fresh ad in tasks market ──
  await page.goto(BASE + '/tasks');
  await page.waitForLoadState('networkidle');
  const startBtn = page.getByRole('button', { name: 'شروع اجرای امتیازی' }).first();
  await startBtn.waitFor({ timeout: 10000 });
  await page.screenshot({ path: `${SHOTS}/cam-01-tasks.png` });
  await startBtn.click();
  await page.waitForURL('**/social-tasks/**/execute', { timeout: 15000 });
  const execUrl = page.url();
  const execId = parseInt(execUrl.match(/social-tasks\/(\d+)\/execute/)[1], 10);
  ok(`start task → execution_id=${execId}`);

  // ── Step 3: wait for farm-exact-timing window (expected_time=45s for follow) ──
  console.log(`── انتظار ۴۳ ثانیه برای farm-exact-timing (expected=45s) ──`);
  await page.screenshot({ path: `${SHOTS}/cam-02-execute.png` });
  await page.waitForTimeout(43000);

  // track camera network calls
  const camCalls = [];
  page.on('response', async (r) => {
    if (r.url().includes('/social-tasks/verify/camera')) {
      camCalls.push([r.request().method(), r.url().replace(BASE, ''), r.status()]);
    }
  });

  // ── Step 4: submit with suspicious timing ──
  await page.getByRole('button', { name: /پایان و محاسبه امتیاز/ }).click();
  const consent1 = page.getByRole('button', { name: 'اجازه میدهم', exact: true });
  try {
    await consent1.waitFor({ timeout: 10000 });
    await page.screenshot({ path: `${SHOTS}/cam-03-consent1.png` });
    ok('submit → camera_required → consent dialog 1 shown');
    await consent1.click();
  } catch {
    bad('submit → camera_required → consent dialog 1 shown', 'dialog did not appear');
  }

  // ── Step 5: spot consent (D1) ──
  const consent2 = page.getByRole('button', { name: /تأیید خودکار/ });
  try {
    await consent2.waitFor({ timeout: 8000 });
    await page.screenshot({ path: `${SHOTS}/cam-04-consent2-spot.png` });
    ok('spot-check consent dialog (D1) shown');
    await consent2.click();
  } catch {
    bad('spot-check consent dialog (D1) shown', 'dialog did not appear');
  }

  // ── Step 6: camera flow runs (challenge → getUserMedia → frames → verify) ──
  console.log('── فلوی دوربین در جریان است (چالش + کپچر + تأیید) ──');
  await page.waitForTimeout(10000); // capture 4 frames (~1.5s) + verify + margin
  await page.screenshot({ path: `${SHOTS}/cam-05-verdict.png` });

  const toasts = await page.evaluate(() => Array.from(document.querySelectorAll('.notyf__message')).map(e => e.textContent.trim()));
  const verdictPass = toasts.some(t => t.includes('تأیید دوربین'));
  camCalls.length >= 2
    ? ok('camera HTTP calls: challenge + verify', JSON.stringify(camCalls))
    : bad('camera HTTP calls', JSON.stringify(camCalls));
  verdictPass ? ok('verdict toast displayed', toasts.join(' | ')) : (toasts.length ? bad('verdict toast', toasts.join(' | ')) : console.log('  (no toast captured)'));

  // ── Step 7: RESUBMIT (the pause-release fix — was 500 before) ──
  console.log('── ریسابمیت بعد از تأیید دوربین (تست فیکس pause-release) ──');
  let resubmitStatus = null, resubmitBody = null;
  const respPromise = page.waitForResponse(r => r.url().includes(`/social-tasks/${execId}/submit`), { timeout: 20000 }).catch(() => null);
  await page.getByRole('button', { name: /پایان و محاسبه امتیاز/ }).click().catch(() => {});
  const resp = await respPromise;
  if (resp) {
    resubmitStatus = resp.status();
    try { resubmitBody = await resp.json(); } catch { resubmitBody = null; }
  }
  await page.waitForTimeout(3000);
  await page.screenshot({ path: `${SHOTS}/cam-06-final.png`, fullPage: false });

  if (resubmitStatus === 200) {
    const cc = resubmitBody?.score_breakdown?.camera_contribution ?? resubmitBody?.data?.score_breakdown?.camera_contribution;
    const dec = resubmitBody?.score_breakdown?.decision ?? resubmitBody?.data?.score_breakdown?.decision;
    ok(`resubmit HTTP 200 (pause-release fix works)`, `camera_contribution=${cc} decision=${dec}`);
    if (typeof cc === 'number' && cc > 0) ok('server camera contribution > 0', String(cc));
    else bad('server camera contribution > 0', JSON.stringify(resubmitBody).slice(0, 300));
  } else {
    bad('resubmit HTTP 200 (pause-release fix)', `status=${resubmitStatus} body=${JSON.stringify(resubmitBody).slice(0, 200)}`);
  }

  // ── Summary ──
  console.log('\n══════════ E2E SUMMARY ══════════');
  const fails = results.filter(r => r[0] === 'FAIL').length;
  for (const [s, n, d] of results) console.log(`${s === 'PASS' ? '✓' : '✗'} ${n}${d ? ' — ' + d : ''}`);
  console.log(`══════════ PASS=${results.length - fails} FAIL=${fails} | execution_id=${execId} ══════════`);

  await browser.close();
  process.exit(fails > 0 ? 1 : 0);
})().catch(e => { console.error('SCRIPT ERROR:', e.message); process.exit(2); });
