// diag_camera.js — diagnose why getUserMedia fails in headless Chrome 155
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');
const CHROME = process.env.PW_CHROME || '';
const BASE = process.env.CHORTKE_BASE_URL || 'http://127.0.0.1:8090';

(async () => {
  const browser = await chromium.launch({
    ...(CHROME ? { executablePath: CHROME } : {}),
    headless: !!process.env.PW_HEADED,
    args: [
      '--use-fake-device-for-media-stream',
      '--use-fake-ui-for-media-stream',
      '--no-sandbox',
      '--disable-dev-shm-usage',
    ],
  });
  browser.on('disconnected', () => {});
  const context = await browser.newContext({ permissions: ['camera'] });
  const page = await context.newPage();
  await page.goto(BASE + '/');

  const diag = await page.evaluate(async () => {
    const out = {};
    out.hasMediaDevices = !!navigator.mediaDevices;
    try {
      const p = await navigator.permissions.query({ name: 'camera' });
      out.permissionState = p.state;
    } catch (e) { out.permissionState = 'query-error: ' + e.name; }
    const attempts = [
      ['plain', { video: true }],
      ['facing-user', { video: { facingMode: 'user' } }],
      ['facing-env', { video: { facingMode: 'environment' } }],
    ];
    out.attempts = [];
    for (const [name, constraints] of attempts) {
      try {
        const s = await navigator.mediaDevices.getUserMedia(constraints);
        out.attempts.push(name + ':OK(' + s.getVideoTracks()[0].label + ')');
        s.getTracks().forEach(t => t.stop());
      } catch (e) {
        out.attempts.push(name + ':' + e.name + '(' + (e.message || '').slice(0, 60) + ')');
      }
    }
    try {
      const devs = await navigator.mediaDevices.enumerateDevices();
      out.devices = devs.filter(d => d.kind === 'videoinput').map(d => d.label || '(unlabeled)').join(', ') || 'NONE';
    } catch (e) { out.devices = 'enum-error: ' + e.name; }
    return out;
  });
  console.log(JSON.stringify(diag, null, 2));
  await browser.close();
})();
