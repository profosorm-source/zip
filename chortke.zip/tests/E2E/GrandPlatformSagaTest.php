<?php

declare(strict_types=1);

namespace Tests\E2E;

use Core\Application;
use Core\Database;
use PHPUnit\Framework\TestCase;
use Throwable;

/**
 * A continuous, stateful black-box saga for the highest-value platform path.
 *
 * Unlike isolated endpoint tests, every stage consumes the state produced by
 * the previous stage and checks both HTTP behavior and database invariants.
 * Run explicitly against a live server:
 * CHORTKE_E2E_BASE_URL=http://127.0.0.1:8091 \
 *   ./vendor/bin/phpunit tests/E2E/GrandPlatformSagaTest.php --testdox
 */
final class GrandPlatformSagaTest extends TestCase
{
    private string $baseUrl;
    private string $cookieJar;
    /** @var list<array{name:string,status:string,duration_ms:float}> */
    private array $journal = [];

    protected function setUp(): void
    {
        parent::setUp();
        $this->baseUrl = \Tests\Support\E2eBaseUrl::resolve();
        $jar = tempnam(sys_get_temp_dir(), 'chortke-grand-saga-');
        if ($jar === false) {
            $this->fail('Unable to create the saga cookie jar.');
        }
        $this->cookieJar = $jar;
    }

    protected function tearDown(): void
    {
        if (isset($this->cookieJar) && is_file($this->cookieJar)) {
            unlink($this->cookieJar);
        }
        parent::tearDown();
    }

    public function test_grand_platform_saga_runs_as_one_continuous_real_flow(): void
    {
        $database = $this->database();
        $state = $this->captureState($database);

        try {
            $this->stage('runtime probes', function () use (&$state): void {
                foreach (['/health', '/health/distributed', '/metrics/distributed'] as $path) {
                    $response = $this->request('GET', $path);
                    $this->assertSame(200, $response['status'], $path . ' must be healthy.');
                    $payload = $this->json($response['body']);
                    if ($path === '/metrics/distributed') {
                        $this->assertSame('chortke-distributed-metrics', $payload['service'] ?? null);
                        $this->assertIsArray($payload['metrics'] ?? null);
                        $this->assertArrayHasKey('outbox_pending', $payload['metrics']);
                        $this->assertArrayHasKey('failed_jobs_total', $payload['metrics']);
                    } else {
                        $this->assertSame('ok', $payload['status'] ?? null, $path . ' returned a bad status.');
                    }
                    $this->assertNoRuntimeDiagnostics($response['body']);
                }
                $state['runtime_verified'] = true;
            });

            $this->stage('user authentication and session', function () use (&$state): void {
                $login = $this->login('/login', 'user@chortke.ir', '123456');
                $this->assertSame(302, $login['status']);
                $this->assertSame('/dashboard', $this->location($login));

                $dashboard = $this->request('GET', '/dashboard');
                $this->assertSame(200, $dashboard['status']);
                $this->assertStringContainsString('داشبورد', $dashboard['body']);
                $state['user_session_verified'] = true;
            });

            $this->stage('real transfer, ledger and idempotency', function () use (&$state, $database): void {
                $before = $this->wallets($database);
                $page = $this->request('GET', '/wallet/transfer');
                $this->assertSame(200, $page['status']);
                $csrf = $this->csrf($page['body']);
                $requestId = 'grand-saga-' . bin2hex(random_bytes(12));
                $amount = 12500.0;

                $transfer = $this->request('POST', '/wallet/transfer', [
                    '_csrf_token' => $csrf,
                    'recipient' => 'support@chortke.ir',
                    'amount' => '12500',
                ], [
                    'X-Request-ID: ' . $requestId,
                    'Idempotency-Key: ' . $requestId,
                    'X-Requested-With: XMLHttpRequest',
                    'Accept: application/json',
                ]);
                $this->assertSame(200, $transfer['status'], $transfer['body']);
                $this->assertTrue((bool)($this->json($transfer['body'])['success'] ?? false));

                $after = $this->wallets($database);
                $this->assertSame(-$amount, round((float)$after[1]->balance_irt - (float)$before[1]->balance_irt, 8));
                $this->assertSame($amount, round((float)$after[2]->balance_irt - (float)$before[2]->balance_irt, 8));

                $rows = $database->fetchAll(
                    "SELECT id,transaction_id,user_id,amount FROM transactions
                     WHERE id > ? AND type = 'transfer' AND user_id IN (1,2) ORDER BY id",
                    [$state['transaction_floor']]
                );
                $this->assertCount(2, $rows, 'A transfer must create exactly two transaction legs.');
                $this->assertSame(
                    0.0,
                    round(array_sum(array_map(static fn(object $row): float => (float)$row->amount, $rows)), 8),
                    'Transfer legs must net to zero.'
                );
                $transactionId = (string)$rows[0]->transaction_id;
                $ledger = $database->fetchAll(
                    'SELECT debit,credit FROM ledger_entries WHERE transaction_id=? ORDER BY id',
                    [$transactionId]
                );
                $this->assertCount(2, $ledger, 'A transfer must produce a balanced double-entry ledger.');
                $debit = array_sum(array_map(static fn(object $row): float => (float)$row->debit, $ledger));
                $credit = array_sum(array_map(static fn(object $row): float => (float)$row->credit, $ledger));
                $this->assertSame($amount, round($debit, 8));
                $this->assertSame($amount, round($credit, 8));

                $state['transfer_request_id'] = $requestId;
                $state['transfer_balance_after'] = $after;
                $state['transaction_ids'] = array_map(static fn(object $row): int => (int)$row->id, $rows);
                $state['ledger_transaction_ids'] = [$transactionId];
                $this->trackOutbox($database, $state);
            });

            $this->stage('idempotent replay has no financial side effect', function () use (&$state, $database): void {
                $page = $this->request('GET', '/wallet/transfer');
                $csrf = $this->csrf($page['body']);
                $replay = $this->request('POST', '/wallet/transfer', [
                    '_csrf_token' => $csrf,
                    'recipient' => 'support@chortke.ir',
                    'amount' => '12500',
                ], [
                    'Idempotency-Key: ' . $state['transfer_request_id'],
                    'X-Requested-With: XMLHttpRequest',
                    'Accept: application/json',
                ]);
                $this->assertContains($replay['status'], [200, 409, 422]);
                $this->assertCount(
                    2,
                    $database->fetchAll(
                        "SELECT id FROM transactions WHERE id > ? AND type='transfer' AND user_id IN (1,2)",
                        [$state['transaction_floor']]
                    ),
                    'An idempotent replay must not create another transfer.'
                );
                $this->assertWalletsEqual($state['transfer_balance_after'], $this->wallets($database));
            });

            $this->stage('reverse transfer restores the financial invariant', function () use (&$state, $database): void {
                file_put_contents($this->cookieJar, '');
                $login = $this->login('/admin/login', 'superadmin@chortke.ir', '123456');
                $this->assertSame('/admin/dashboard', $this->location($login));
                $page = $this->request('GET', '/admin/transactions');
                $csrf = $this->csrf($page['body']);
                foreach ($state['transaction_ids'] as $position => $transactionId) {
                    $reverse = $this->request('POST', '/admin/transactions/reverse', [
                        '_csrf_token' => $csrf,
                        'id' => $transactionId,
                        'reason' => 'Grand Platform Saga invariant rollback',
                    ], [
                        'X-Requested-With: XMLHttpRequest',
                        'Accept: application/json',
                    ]);
                    if ($position === 0) {
                        $this->assertSame(200, $reverse['status'], $reverse['body']);
                        $this->assertTrue((bool)($this->json($reverse['body'])['success'] ?? false));
                    } else {
                        // 16-W: برگشتِ انتقال pair-aware و اتمیک است (FIX-M12-01 —
                        // WalletMutationService::reverseTransferPair): فراخوانی اول،
                        // هر دو leg جفت را یک‌جا برمی‌گرداند و status هر دو را
                        // «reversed» می‌کند؛ فراخوانی دوم روی leg خواهر باید به‌درستی
                        // با 422 (گارد double-reversal کنترلر) رد شود — نه 200 تکراری.
                        $this->assertSame(422, $reverse['status'], $reverse['body']);
                        $this->assertFalse((bool)($this->json($reverse['body'])['success'] ?? true), $reverse['body']);
                    }
                }
                $this->assertWalletsEqual($state['wallets'], $this->wallets($database));

                $newRows = $database->fetchAll(
                    'SELECT id,transaction_id FROM transactions WHERE id > ? ORDER BY id',
                    [$state['transaction_floor']]
                );
                $state['transaction_ids'] = array_map(static fn(object $row): int => (int)$row->id, $newRows);
                $state['ledger_transaction_ids'] = array_values(array_unique(array_merge(
                    $state['ledger_transaction_ids'],
                    array_map(static fn(object $row): string => (string)$row->transaction_id, $newRows)
                )));
                $this->trackOutbox($database, $state);
            });

            $this->stage('admin observability and session revocation', function (): void {
                file_put_contents($this->cookieJar, '');
                $login = $this->login('/admin/login', 'superadmin@chortke.ir', '123456');
                $this->assertSame('/admin/dashboard', $this->location($login));

                foreach (['/admin/dashboard', '/admin/sentry', '/admin/sentry/outbox-dlq'] as $path) {
                    $response = $this->request('GET', $path);
                    $this->assertSame(200, $response['status'], $path . ' must be available to an admin.');
                    $this->assertNoRuntimeDiagnostics($response['body']);
                }

                $dashboard = $this->request('GET', '/admin/dashboard');
                $logout = $this->request('POST', '/admin/logout', [
                    '_csrf_token' => $this->csrf($dashboard['body']),
                ]);
                $this->assertSame(302, $logout['status'], 'Logout status: ' . $logout['status']);
                $this->assertSame('/admin/login', $this->location($logout), 'Logout location: ' . $this->location($logout));
                $protected = $this->request('GET', '/admin/dashboard');
                $this->assertSame(302, $protected['status'], 'Protected admin status: ' . $protected['status']);
            });
        } finally {
            $this->restoreState($database, $state);
        }
    }

    /** @param callable():void $callback */
    private function stage(string $name, callable $callback): void
    {
        $started = microtime(true);
        try {
            $callback();
            $this->journal[] = [
                'name' => $name,
                'status' => 'passed',
                'duration_ms' => round((microtime(true) - $started) * 1000, 2),
            ];
        } catch (Throwable $e) {
            $journal = json_encode($this->journal, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            throw new \RuntimeException(
                "Grand Saga failed at stage '{$name}'.\nCompleted stages: {$journal}\nCause: {$e->getMessage()}",
                0,
                $e
            );
        }
    }

    /** @return array<string,mixed> */
    private function captureState(Database $database): array
    {
        $walletRows = $database->fetchAll(
            'SELECT user_id,balance_irt,balance_usdt,locked_irt,locked_usdt,is_frozen,last_withdrawal_at FROM wallets WHERE user_id IN (1,2) ORDER BY user_id'
        );
        $this->assertCount(2, $walletRows, 'Grand Saga requires both seed wallets.');
        return [
            'wallets' => [1 => $walletRows[0], 2 => $walletRows[1]],
            'transaction_floor' => (int)$database->fetchColumn('SELECT COALESCE(MAX(id),0) FROM transactions'),
            'ledger_floor' => (int)$database->fetchColumn('SELECT COALESCE(MAX(id),0) FROM ledger_entries'),
            'idempotency_floor' => (int)$database->fetchColumn('SELECT COALESCE(MAX(id),0) FROM idempotency_keys'),
            'outbox_floor' => (int)$database->fetchColumn('SELECT COALESCE(MAX(id),0) FROM outbox_events'),
            'runtime_verified' => false,
            'user_session_verified' => false,
            'transaction_ids' => [],
            'ledger_transaction_ids' => [],
            'outbox_ids' => [],
        ];
    }

    /** @return array<int,object> */
    private function wallets(Database $database): array
    {
        $rows = $database->fetchAll(
            'SELECT user_id,balance_irt,balance_usdt,locked_irt,locked_usdt,is_frozen,last_withdrawal_at FROM wallets WHERE user_id IN (1,2) ORDER BY user_id'
        );
        $result = [];
        foreach ($rows as $row) {
            $result[(int)$row->user_id] = $row;
        }
        return $result;
    }

    /** @param array<int,object> $expected @param array<int,object> $actual */
    private function assertWalletsEqual(array $expected, array $actual): void
    {
        foreach ([1, 2] as $userId) {
            foreach (['balance_irt', 'balance_usdt', 'locked_irt', 'locked_usdt', 'is_frozen', 'last_withdrawal_at'] as $field) {
                $this->assertSame(
                    (string)$expected[$userId]->{$field},
                    (string)$actual[$userId]->{$field},
                    "Wallet {$userId} field {$field} changed unexpectedly."
                );
            }
        }
    }

    /** @param array<string,mixed> $state */
    private function restoreState(Database $database, array $state): void
    {
        $transactionRows = $database->fetchAll(
            'SELECT id,transaction_id FROM transactions WHERE id > ? AND user_id IN (1,2)',
            [$state['transaction_floor']]
        );
        $transactionIds = array_values(array_unique(array_map(static fn(object $row): int => (int)$row->id, $transactionRows)));
        $ledgerTransactionIds = array_values(array_unique(array_map(static fn(object $row): string => (string)$row->transaction_id, $transactionRows)));
        if ($ledgerTransactionIds !== []) {
            $marks = implode(',', array_fill(0, count($ledgerTransactionIds), '?'));
            $database->query("DELETE FROM ledger_entries WHERE transaction_id IN ({$marks})", $ledgerTransactionIds);
        }
        if ($transactionIds !== []) {
            $marks = implode(',', array_fill(0, count($transactionIds), '?'));
            $database->query("DELETE FROM transactions WHERE id IN ({$marks})", $transactionIds);
        }
        // The admin/session stage can emit events after the last explicit
        // trackOutbox call, so use the immutable floor for complete cleanup.
        $database->query('DELETE FROM outbox_events WHERE id > ?', [$state['outbox_floor']]);
        $database->query('DELETE FROM idempotency_keys WHERE id > ?', [$state['idempotency_floor']]);
        foreach ($state['wallets'] as $wallet) {
            $database->query(
                'UPDATE wallets SET balance_irt=?,balance_usdt=?,locked_irt=?,locked_usdt=?,is_frozen=?,last_withdrawal_at=? WHERE user_id=?',
                [$wallet->balance_irt, $wallet->balance_usdt, $wallet->locked_irt, $wallet->locked_usdt, $wallet->is_frozen, $wallet->last_withdrawal_at, $wallet->user_id]
            );
        }
        $this->flushRedis();
    }

    /** @param array<string,mixed> $state */
    private function trackOutbox(Database $database, array &$state): void
    {
        $rows = $database->fetchAll(
            'SELECT id FROM outbox_events WHERE id > ? ORDER BY id',
            [$state['outbox_floor']]
        );
        $state['outbox_ids'] = array_values(array_unique(array_merge(
            $state['outbox_ids'],
            array_map(static fn(object $row): int => (int)$row->id, $rows)
        )));
    }

    private function database(): Database
    {
        return Application::getInstance()->container->make(Database::class);
    }

    /** @return array{status:int,headers:array<string,list<string>>,body:string} */
    private function request(string $method, string $path, array $form = [], array $extraHeaders = []): array
    {
        $handle = curl_init($this->baseUrl . $path);
        if ($handle === false) {
            $this->fail('Unable to initialize cURL.');
        }
        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_COOKIEJAR => $this->cookieJar,
            CURLOPT_COOKIEFILE => $this->cookieJar,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_USERAGENT => 'Chortke-GrandSaga/1.0',
            CURLOPT_HTTPHEADER => array_merge(['Accept-Language: fa-IR', 'Accept-Encoding: identity'], $extraHeaders),
        ]);
        if ($method === 'POST') {
            curl_setopt($handle, CURLOPT_POSTFIELDS, http_build_query($form));
            curl_setopt($handle, CURLOPT_HTTPHEADER, array_merge(
                ['Accept-Language: fa-IR', 'Accept-Encoding: identity', 'Content-Type: application/x-www-form-urlencoded'],
                $extraHeaders
            ));
        }
        $raw = curl_exec($handle);
        if (!is_string($raw)) {
            $error = curl_error($handle);
            curl_close($handle);
            $this->fail('Grand Saga HTTP request failed: ' . $error);
        }
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        $headerSize = (int)curl_getinfo($handle, CURLINFO_HEADER_SIZE);
        curl_close($handle);
        $headerBlock = substr($raw, 0, $headerSize);
        $headers = [];
        foreach (preg_split('/\r\n|\n|\r/', trim($headerBlock)) ?: [] as $line) {
            if (!str_contains($line, ':')) {
                continue;
            }
            [$name, $value] = explode(':', $line, 2);
            $headers[strtolower(trim($name))][] = trim($value);
        }
        return ['status' => $status, 'headers' => $headers, 'body' => substr($raw, $headerSize)];
    }

    /** @return array<string,mixed> */
    private function json(string $body): array
    {
        $decoded = json_decode($body, true);
        $this->assertIsArray($decoded, 'Expected a JSON object from the live endpoint.');
        return $decoded;
    }

    private function csrf(string $html): string
    {
        $matched = preg_match('/name="_csrf_token"[^>]+value="([^"]+)"/', $html, $matches);
        if ($matched !== 1) {
            $matched = preg_match('/name="csrf-token"\s+content="([^"]+)"/', $html, $matches);
        }
        $this->assertSame(1, $matched, 'A live page did not expose a CSRF token.');
        $token = $matches[1] ?? '';
        $this->assertSame(64, strlen($token), 'Live CSRF token has an invalid length.');
        return $token;
    }

    /** @return array{status:int,headers:array<string,list<string>>,body:string} */
    private function login(string $path, string $email, string $password): array
    {
        $page = $this->request('GET', $path);
        $this->assertSame(200, $page['status']);
        return $this->request('POST', $path, [
            '_csrf_token' => $this->csrf($page['body']),
            'email' => $email,
            'password' => $password,
            'remember' => 'on',
        ]);
    }

    /** @param array{headers:array<string,list<string>>} $response */
    private function location(array $response): string
    {
        $location = $response['headers']['location'][0] ?? '';
        return (string)(parse_url($location, PHP_URL_PATH) ?: $location);
    }

    private function assertNoRuntimeDiagnostics(string $body): void
    {
        foreach (['Deprecated', 'Warning:', 'Fatal error', 'Stack trace', 'SQLSTATE['] as $diagnostic) {
            $this->assertStringNotContainsString($diagnostic, $body);
        }
    }

    private function flushRedis(): void
    {
        $config = config('redis', []);
        $redis = new \Redis();
        $redis->connect(str_value($config['host'] ?? '127.0.0.1'), int_value($config['port'] ?? 6379), 2.0);
        $password = str_value($config['password'] ?? '');
        if ($password !== '') {
            $redis->auth($password);
        }
        $redis->select(int_value($config['database'] ?? 0));
        $redis->flushDB();
        $redis->close();
    }
}
