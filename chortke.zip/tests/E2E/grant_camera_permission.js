// grant_camera_permission.js — grant camera permission to the Playwright-controlled
// Chrome via CDP Browser.grantPermissions (agent-browser has no permission command).
// Usage: node grant_camera_permission.js <devtools_ws_url>
const wsUrl = process.argv[2];
if (!wsUrl) { console.error('usage: node grant_camera_permission.js <wsUrl>'); process.exit(1); }

const ws = new WebSocket(wsUrl);
let id = 0;
const send = (method, params = {}) => {
  id += 1;
  ws.send(JSON.stringify({ id, method, params }));
  return id;
};

ws.onopen = () => {
  // Grant camera (videoCapture) for the app origin — covers getUserMedia permission
  send('Browser.grantPermissions', { permissions: ['videoCapture', 'audioCapture'] });
  // Also try granting for the origin explicitly
  send('Browser.grantPermissions', { permissions: ['videoCapture', 'audioCapture'], origin: 'http://127.0.0.1:8090' });
};

ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id) console.log(`response id=${msg.id} ${msg.error ? 'ERROR: ' + JSON.stringify(msg.error) : 'OK'}`);
  if (msg.id === 2 || (msg.id >= 2 && msg.error === undefined)) {
    // after both grant calls answered, exit
    setTimeout(() => { console.log('PERMISSIONS_GRANTED'); process.exit(0); }, 500);
  }
};

ws.onerror = (e) => { console.error('WS error:', e.message); process.exit(1); };
setTimeout(() => { console.error('timeout'); process.exit(1); }, 10000);
