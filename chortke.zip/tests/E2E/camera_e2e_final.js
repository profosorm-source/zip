// camera_e2e_final.js — Grand E2E: FULL camera-verifier positive path in a REAL browser.
//
// The container blocks Chrome's video-capture service (getUserMedia → NotAllowedError
// even with --use-fake-device-for-media-stream + granted permission + Xvfb headed).
// Standard E2E technique: simulate the CAMERA HARDWARE at the browser-API level —
// getUserMedia returns an animated canvas stream (moving scene + per-pixel sensor
// noise). Everything else is 100% real: the app's client JS (consent dialogs,
// challenge, frame sampling, spot JPEG), the HTTP layer, and the server trust chain
// (nonce, statistical analysis, spot match, verdict, contribution gate).
//
// Flow: login (mobile) → start fresh ad → wait ~44s (farm-exact-timing → behavior 30)
//   → submit → camera_required → Swal consent 1 → Swal spot-consent 2 (D1)
//   → challenge (nonce) → fake camera frames (t/lum/std + spot JPEG) → verify
//   → verdict=pass toast → RESUBMIT (pause-release fix) → camera_contribution=15.
const { chromium } = require('/home/z/.npm-global/lib/node_modules/playwright');

const BASE = process.env.CHORTKE_BASE_URL || 'http://127.0.0.1:8090';
const SHOTS = '/home/z/my-project/download/e2e-screenshots';
const MOBILE_UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36';

// ── Fake camera: animated canvas + sensor noise (browser-API level simulation) ──
const FAKE_CAMERA_INIT = `
(() => {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return;
  navigator.mediaDevices.getUserMedia = async (constraints) => {
    const canvas = document.createElement('canvas');
    canvas.width = 320; canvas.height = 240;
    const ctx = canvas.getContext('2d');
    let t = 0;
    const draw = () => {
      t += 1;
      // luminance oscillates slowly (HSL lightness 38%..62%) → frame-to-frame lum spread
      const L = 50 + 12 * Math.sin(t / 5);
      ctx.fillStyle = 'hsl(' + ((t * 3) % 360) + ', 45%, ' + L + '%)';
      ctx.fillRect(0, 0, 320, 240);
      // moving bright ball → intra-frame variance + motion
      ctx.beginPath();
      ctx.arc(40 + (t * 7) % 240, 120 + Math.sin(t / 8) * 60, 26, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.fill();
      // per-pixel sensor noise → std per frame (calibrates fake-vs-script)
      const img = ctx.getImageData(0, 0, 320, 240);
      const d = img.data;
      for (let i = 0; i < d.length; i += 4) {
        const n = (Math.random() - 0.5) * 22;
        d[i] += n; d[i+1] += n; d[i+2] += n;
      }
      ctx.putImageData(img, 0, 0);
    };
    draw();
    const stream = canvas.captureStream(10);
    const timer = setInterval(draw, 100);
    const track = stream.getVideoTracks()[0];
    const origStop = track.stop.bind(track);
    track.stop = () => { clearInterval(timer); origStop(); };
    track.label = 'fake-e2e-camera';
    return stream;
  };
})();
`;

const results = [];
const ok = (name, detail = '') => { results.push([true, name, detail]); console.log(`  ✓ ${name}${detail ? ' — ' + detail : ''}`); };
const bad = (name, detail = '') => { results.push([false, name, detail]); console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); };

(async () => {
  const browser = await chromium.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });
  const context = await browser.newContext({
    userAgent: MOBILE_UA,
    viewport: { width: 412, height: 915 },
    isMobile: true,
    hasTouch: true,
  });
  await context.addInitScript(FAKE_CAMERA_INIT);
  const page = await context.newPage();

  const camCalls = [];
  page.on('response', (r) => {
    if (r.url().includes('/social-tasks/verify/camera')) {
      camCalls.push([r.request().method(), r.url().replace(BASE, ''), r.status()]);
    }
  });

  // ── Step 0: fake camera precondition ──
  await page.goto(BASE + '/');
  const camProbe = await page.evaluate(async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      const label = s.getVideoTracks()[0].label;
      s.getTracks().forEach(t => t.stop());
      return 'OK:' + label;
    } catch (e) { return 'FAIL:' + e.name; }
  });
  camProbe.startsWith('OK') ? ok('fake camera stream available', camProbe) : bad('fake camera stream', camProbe);

  // ── Step 1: login ──
  await page.goto(BASE + '/login');
  await page.getByRole('textbox', { name: 'ایمیل یا موبایل' }).fill('user@chortke.ir');
  await page.getByRole('textbox', { name: 'رمز عبور' }).fill('Test@12345');
  await page.getByRole('button', { name: 'ورود', exact: true }).click();
  await page.waitForURL('**/dashboard', { timeout: 15000 });
  ok('login → /dashboard');

  // ── Step 2: start fresh ad ──
  await page.goto(BASE + '/tasks');
  await page.waitForLoadState('networkidle');
  const startBtn = page.getByRole('button', { name: 'شروع اجرای امتیازی' }).first();
  await startBtn.waitFor({ timeout: 10000 });
  await startBtn.click();
  await page.waitForURL('**/social-tasks/**/execute', { timeout: 15000 });
  const execId = parseInt(page.url().match(/social-tasks\/(\d+)\/execute/)[1], 10);
  ok(`start task → execution_id=${execId}`);
  await page.screenshot({ path: `${SHOTS}/camf-01-execute.png` });

  // ── Step 3: farm-exact-timing (expected_time=45s) ──
  console.log('  … انتظار ۴۴ ثانیه (farm-exact-timing → behavior 30 → camera_required)');
  await page.waitForTimeout(44000);

  // ── Step 4: submit → camera_required → Swal consent 1 ──
  await page.getByRole('button', { name: /پایان و محاسبه امتیاز/ }).click();
  const swal1 = page.locator('.swal2-confirm');
  try {
    await swal1.waitFor({ timeout: 10000 });
    await page.screenshot({ path: `${SHOTS}/camf-02-consent1.png` });
    ok('submit → camera_required → consent dialog 1 (تأیید دوربین)');
    await swal1.click();
  } catch { bad('consent dialog 1', 'did not appear'); }

  // ── Step 5: Swal spot-consent (D1) ──
  try {
    await page.locator('.swal2-confirm').waitFor({ timeout: 8000 });
    await page.screenshot({ path: `${SHOTS}/camf-03-consent2-spot.png` });
    ok('spot-check consent dialog (D1) shown');
    await page.locator('.swal2-confirm').click();
  } catch { bad('spot consent dialog', 'did not appear'); }

  // ── Step 6: camera flow (challenge → frames → verify → verdict → AUTO-resubmit) ──
  console.log('  … فلوی دوربین: چالش + کپچر ۴ فریم + نمونه spot + تأیید + ریسابمیت خودکار');
  // JS بعد از دوربین خودش completeTask(true) می‌زند — پاسخ ریسابمیت را همان‌جا بگیر
  const resubmitPromise = page.waitForResponse(
    r => r.url().includes(`/social-tasks/${execId}/submit`) && r.request().method() === 'POST',
    { timeout: 30000 }
  ).catch(() => null);
  await page.waitForTimeout(11000);
  await page.screenshot({ path: `${SHOTS}/camf-04-verdict.png` });
  const toasts = await page.evaluate(() => Array.from(document.querySelectorAll('.notyf__message')).map(e => e.textContent.trim()));

  const challengeCall = camCalls.find(c => c[1].includes('camera-challenge'));
  const verifyCall = camCalls.find(c => c[1].includes('camera-verify'));
  challengeCall ? ok('camera-challenge HTTP', JSON.stringify(challengeCall)) : bad('camera-challenge HTTP', 'not found');
  verifyCall ? ok('camera-verify HTTP', JSON.stringify(verifyCall)) : bad('camera-verify HTTP', 'not found');

  const passToast = toasts.find(t => t.includes('تأیید دوربین'));
  const weakToast = toasts.find(t => t.includes('verdict='));
  if (passToast) { ok('verdict toast: PASS', passToast); }
  else if (weakToast) { ok('verdict toast (non-pass)', weakToast); }
  else console.log('  (toast capture: ' + JSON.stringify(toasts) + ')');

  // ── Step 7: the AUTO-resubmit response (pause-release fix — was 500 before) ──
  console.log('  … دریافت پاسخ ریسابمیت خودکار (تست فیکس pause-release)');
  const resp = await resubmitPromise;
  let cc = null, dec = null, rs = null, resubmitBody = null;
  if (resp) {
    rs = resp.status();
    try {
      resubmitBody = await resp.json();
      cc = resubmitBody?.score_breakdown?.camera_contribution ?? resubmitBody?.data?.score_breakdown?.camera_contribution ?? null;
      dec = resubmitBody?.score_breakdown?.decision ?? resubmitBody?.data?.score_breakdown?.decision ?? null;
    } catch { /* ignore */ }
  }
  await page.waitForTimeout(2500);
  await page.screenshot({ path: `${SHOTS}/camf-05-final.png` });

  if (rs === 200) {
    ok('AUTO-RESUBMIT HTTP 200 — pause-release fix works', `camera_contribution=${cc} decision=${dec}`);
    if (typeof cc === 'number' && cc > 0) ok('server camera contribution > 0 (server-verdict gated)', String(cc));
    else bad('camera contribution', `cc=${cc} body=${JSON.stringify(resubmitBody).slice(0, 200)}`);
  } else {
    bad('AUTO-RESUBMIT HTTP 200', `status=${rs} body=${JSON.stringify(resubmitBody).slice(0, 200)}`);
  }

  // ── Summary ──
  console.log('\n══════════ E2E FINAL SUMMARY ══════════');
  const fails = results.filter(r => !r[0]).length;
  for (const [s, n, d] of results) console.log(`${s ? '✓' : '✗'} ${n}${d ? ' — ' + d : ''}`);
  console.log(`══════════ PASS=${results.length - fails} FAIL=${fails} | execution_id=${execId} ══════════`);
  console.log(`DB_CHECK_EXEC_ID=${execId}`);

  await browser.close();
  process.exit(fails > 0 ? 1 : 0);
})().catch(e => { console.error('SCRIPT ERROR:', e.message); process.exit(2); });
