<?php
/**
 * Cache Flush Helper — پاک‌سازی کامل cache برای تست‌ها
 * این فایل از CLI اجرا می‌شود تا risk scores و captcha state را ریست کند.
 *
 * FIX-HARNESS-QUEUE (E2E): صف‌های دیتابیس‌محور (analytics/default/maintenance)
 * در اجراهای پیاپی بدون worker انباشته می‌شوند؛ پس از عبور از سقف backpressure
 * (مثلاً analytics: 5000) هر درخواستِ job-محور 503 می‌دهد و کل ماژول‌های E2E
 * به‌صورت گذرا قرمز می‌شوند. تخلیهٔ صف‌ها در ایزولاسیون هر سناریو لازم است —
 * این جاب‌های معلق تست ارزش بازپخش ندارند (telemetry/log).
 */
require_once __DIR__ . '/../bootstrap/app.php';

$c = \Core\Container::getInstance()->make(\Core\Cache::class);
$c->flush();

try {
    $db = \Core\Container::getInstance()->make(\Core\Database::class);
    $db->execute("DELETE FROM queues WHERE queue IN ('analytics', 'default', 'maintenance', 'notifications', 'high_priority')");
} catch (\Throwable $e) {
    // fail-soft: پاک‌سازی صف هرگز خودش نباید هارنس را بشکند.
}

echo 'OK';
