#!/usr/bin/env python3
"""
تست ریاضیِ FIX-COUPON-ADS-CAMPAIGN — قانون تقسیم تخفیف کمپین تبلیغاتی
(«تخفیف اول از کارمزد بخوره؛ اگر بیشتر بود و نیاز شد از بودجه کمپین هم کم بشه»)

این تست، منطق AdSystemManager::splitCouponDiscount و چرخه‌ی عمر اسکرو را با
Decimal (معادل bcmath) بازتولید و صحت‌سنجی می‌کند:

  1) قانون تقسیم: D_fee = min(D, F) و D_budget = D − D_fee
  2) سلامت اسکرو (solvency): جمع کسرهای عمر کمپین هرگز از paid بیشتر نمی‌شود
     و در هر دو رژیمِ خالص (D≤F و D>F) «دقیقاً» برابر paid است.
  3) کفِ تعداد برای انواع تسکی + باقیمانده‌ی قابل استرداد ≥ 0
  4) جهتِ گرد‌کردن p_eff (به پایین در ۲ رقم) همیشه به‌سمت امن است.
  5) رفع باگ مبنای پیش‌نمایش سئو (بودجه به‌جای min_payout)

اجرا:  python3 tests/test_ads_coupon_split.py
"""
from decimal import Decimal, ROUND_DOWN, getcontext

getcontext().prec = 50

TWO = Decimal('2')
EIGHT_DP = Decimal('0.00000001')


def d(x):
    return Decimal(str(x))


def split_coupon_discount(budget, fee, fee_percent, discount):
    """آینه‌ی دقیقِ AdSystemManager::splitCouponDiscount (bcmath، scale=8)"""
    budget, fee, fee_percent, discount = d(budget), d(fee), d(fee_percent), d(discount)
    if discount < 0:
        discount = Decimal('0')
    total = budget + fee
    if total <= 0:
        return dict(fee_discount=Decimal('0'), budget_discount=Decimal('0'),
                    paid=Decimal('0'), budget_net=Decimal('0'), fee_percent_eff=Decimal('0'))
    if discount > total:
        discount = total

    fee_discount = fee if discount > fee else discount
    budget_discount = discount - fee_discount
    paid = total - discount
    budget_net = budget - budget_discount

    fee_percent_eff = Decimal('0')
    if fee > 0 and fee_percent > 0:
        fee_net = fee - fee_discount
        if fee_net > 0:
            # bcdiv(..., 2) در bcmath به‌سمت صفر گرد می‌کند ⇒ اینجا ROUND_DOWN
            fee_percent_eff = (fee_percent * fee_net / fee).quantize(Decimal('0.01'), rounding=ROUND_DOWN)
    return dict(fee_discount=fee_discount, budget_discount=budget_discount,
                paid=paid, budget_net=budget_net, fee_percent_eff=fee_percent_eff)


def simulate_campaign_life(budget_net, fee_percent_eff, price=None):
    """شبیه‌سازی کسرهای اسکرو در طول عمر کمپین.

    انواع بودجه‌ای: کل پاداش‌ها = budget_net (در گام‌های ۱ تومانی).
    انواع تسکی:    N_eff = floor(budget_net / price) پاداشِ price تومانی.
    هر گام: reward + reward×p_eff (۸ رقم اعشار، مثل Money/BCMath) کسر می‌شود.
    """
    decrements = Decimal('0')
    if price is None:
        step = Decimal('1')
        remaining = budget_net
        while remaining >= step:
            reward = step
            fee_part = (reward * fee_percent_eff / Decimal('100')).quantize(EIGHT_DP, rounding=ROUND_DOWN)
            decrements += reward + fee_part
            remaining -= reward
        return decrements
    n_eff = int((budget_net / price).to_integral_value(rounding=ROUND_DOWN))
    reward = price
    fee_part = (reward * fee_percent_eff / Decimal('100')).quantize(EIGHT_DP, rounding=ROUND_DOWN)
    decrements = n_eff * (reward + fee_part)
    return decrements


PASS = 0
FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {name}")
    else:
        FAIL += 1
        print(f"  FAIL  {name}  {detail}")


print("═" * 72)
print("۱) قانون تقسیم: تخفیف اول از کارمزد، مازاد از بودجه")
print("═" * 72)
# کمپین ۱میلیون تومانی با کارمزد ۱۰٪ و کوپن ۵۰هزار ثابت (D=50k ≤ F=100k)
s = split_coupon_discount('1000000', '100000', '10', '50000')
check("D≤F: کل تخفیف از کارمزد", s['fee_discount'] == d('50000'), str(s))
check("D≤F: بودجه کمپین دست‌نخورده", s['budget_net'] == d('1000000'), str(s))
check("D≤F: paid = B+F−D", s['paid'] == d('1050000'), str(s))
check("D≤F: کارمزد مؤثر نصف", s['fee_percent_eff'] == d('5.00'), str(s))

# کوپن ۱۵٪ روی کل (D = ۱۶۵هزار > F = ۱۰۰هزار)
s = split_coupon_discount('1000000', '100000', '10', '165000')
check("D>F: کارمزد کامل سوخته", s['fee_discount'] == d('100000'), str(s))
check("D>F: مازاد از بودجه کم شده", s['budget_discount'] == d('65000'), str(s))
check("D>F: بودجه مؤثر", s['budget_net'] == d('935000'), str(s))
check("D>F: کارمزد مؤثر صفر", s['fee_percent_eff'] == d('0.00'), str(s))
check("D>F: paid = B+F−D", s['paid'] == d('935000'), str(s))

print()
print("═" * 72)
print("۲) سلامت اسکرو — رژیم D ≤ F (پلتفرم جذب می‌کند)")
print("═" * 72)
cases = [
    ('1000000', '10', '50000'),   # fixed 50k
    ('1000000', '10', '100000'),  # دقیقاً = F
    ('250000', '15', '10000'),    # کارمزد ۱۵٪
    ('99999', '12.5', '5000'),    # درصد اعشاری
]
for budget, p, disc in cases:
    B = d(budget)
    F = (B * d(p) / Decimal('100')).quantize(Decimal('0.00000001'), rounding=ROUND_DOWN)
    s = split_coupon_discount(B, F, p, disc)
    decr = simulate_campaign_life(s['budget_net'], s['fee_percent_eff'])
    leftover = s['paid'] - decr
    # ستون site_commission_percent از نوع DECIMAL(5,2) است؛ p_eff به پایین گرد
    # می‌شود ⇒ باقیمانده ≥ ۰ (همیشه solvent) و بسیار کوچک (≤ ۰.۰۱٪ بودجه)
    # و در بستن کمپین به تبلیغ‌دهنده برمی‌گردد. برای اعداد «تمیز» دقیقاً صفر است.
    bound = (d(budget) * Decimal('0.0001')).quantize(Decimal('0.01')) + Decimal('0.01')
    check(f"B={budget}, p={p}%, D={disc}: اسکرو solvent و باقیمانده ریز",
          leftover >= 0 and leftover <= bound, f"paid={s['paid']} decr={decr} leftover={leftover}")

print()
print("═" * 72)
print("۳) سلامت اسکرو — رژیم D > F (بودجه کم می‌شود)")
print("═" * 72)
cases = [
    ('1000000', '10', '165000'),
    ('1000000', '10', '550000'),  # کوپن ۵۰٪ کل
    ('500000', '15', '100000'),
]
for budget, p, disc in cases:
    B = d(budget)
    F = (B * d(p) / Decimal('100')).quantize(Decimal('0.00000001'), rounding=ROUND_DOWN)
    s = split_coupon_discount(B, F, p, disc)
    decr = simulate_campaign_life(s['budget_net'], s['fee_percent_eff'])
    leftover = s['paid'] - decr
    # ستون site_commission_percent از نوع DECIMAL(5,2) است؛ p_eff به پایین گرد
    # می‌شود ⇒ باقیمانده ≥ ۰ (همیشه solvent) و بسیار کوچک (≤ ۰.۰۱٪ بودجه)
    # و در بستن کمپین به تبلیغ‌دهنده برمی‌گردد. برای اعداد «تمیز» دقیقاً صفر است.
    bound = (d(budget) * Decimal('0.0001')).quantize(Decimal('0.01')) + Decimal('0.01')
    check(f"B={budget}, p={p}%, D={disc}: اسکرو solvent و باقیمانده ریز",
          leftover >= 0 and leftover <= bound, f"paid={s['paid']} decr={decr} leftover={leftover}")

print()
print("═" * 72)
print("۴) انواع تسکی: کفِ تعداد + باقیمانده‌ی قابل استرداد")
print("═" * 72)
# B = 100×10 = 1000، F = 100، D = 220 ⇒ B_net = 880 ⇒ N_eff = 8 (800)، leftover escrow = paid − 8×10 = 90−80 = 10
s = split_coupon_discount('1000', '100', '10', '220')
check("تسکی: بودجه مؤثر", s['budget_net'] == d('880'), str(s))
n_eff = int((s['budget_net'] / d('100')).to_integral_value(rounding=ROUND_DOWN))
check("تسکی: تعداد مؤثر ۸", n_eff == 8, str(n_eff))
decr = simulate_campaign_life(s['budget_net'], s['fee_percent_eff'], price=d('100'))
leftover = s['paid'] - decr
check("تسکی: باقیمانده ≥ 0 (قابل استرداد در بستن کمپین)", leftover >= 0, str(leftover))
check("تسکی: باقیمانده < قیمت یک تسک", leftover < d('100'), str(leftover))

# بدون کوپن: تعداد دست‌نخورده
s = split_coupon_discount('1000', '100', '10', '0')
n_eff = int((s['budget_net'] / d('100')).to_integral_value(rounding=ROUND_DOWN))
check("بدون کوپن: تعداد ۱۰ و p_eff = p", n_eff == 10 and s['fee_percent_eff'] == d('10.00'), str(s))

print()
print("═" * 72)
print("۵) جهت گرد‌کردن p_eff همیشه به‌سمت امن (اسکرو هرگز منفی نمی‌شود)")
print("═" * 72)
# درصد اعشاری نامنظم: p=12.37، D کوچک ⇒ p_eff = 12.37×(F−D)/F با truncation
B = d('123456')
p = d('12.37')
F = (B * p / Decimal('100')).quantize(Decimal('0.00000001'), rounding=ROUND_DOWN)
for disc in ['1', '7.7', '100', '1000', '15000', str(F), '999999']:
    s = split_coupon_discount(B, F, p, disc)
    decr = simulate_campaign_life(s['budget_net'], s['fee_percent_eff'])
    leftover = s['paid'] - decr
    check(f"D={disc}: leftover ≥ 0 (solvent)", leftover >= 0,
          f"paid={s['paid']} decr={decr} p_eff={s['fee_percent_eff']}")

print()
print("═" * 72)
print("۶) رفع باگ مبنای پیش‌نمایش سئو (FIX-ADS-PREVIEW-BASIS)")
print("═" * 72)
# منطق جدید previewCost: کمپین بودجه‌ای → مبنای بودجه، نه min_payout
def preview_basis(is_budget_based, budget, price_per_task, quantity, min_payout):
    if is_budget_based and budget > 0:
        return budget
    if price_per_task > 0:
        return price_per_task * max(1, quantity)
    return budget

# سئو: budget=500000، min_payout=2000 → قبلاً ۲۰۰۰ نشان می‌داد
old_bug_value = d('2000') * 1
new_value = preview_basis(True, d('500000'), d('0'), 1, d('2000'))
check("سئو: پیش‌نمایش = بودجه کل (نه min_payout)", new_value == d('500000'), str(new_value))
check("سئو: مقدار قدیمی باگ‌دار متفاوت است", new_value != old_bug_value)

# تسکی: social — budget=0، price=2500، count=40 → 100000
new_value = preview_basis(False, d('0'), d('2500'), 40, d('0'))
check("تسکی: پیش‌نمایش = قیمت×تعداد", new_value == d('100000'), str(new_value))

print()
print("═" * 72)
print("۷) درآمد پلتفرم مطابق قانون")
print("═" * 72)
# D=50k ≤ F=100k ⇒ درآمد کارمزد پلتفرم باید F−D = 50k باشد (نه بیشتر، نه کمتر)
s = split_coupon_discount('1000000', '100000', '10', '50000')
platform_fee_income = (s['budget_net'] * s['fee_percent_eff'] / Decimal('100')).quantize(Decimal('0.01'), rounding=ROUND_DOWN)
check("D≤F: درآمد پلتفرم = F−D", platform_fee_income == d('50000.00'), str(platform_fee_income))
# D=165k > F=100k ⇒ کارمزد صفر و بودجه ۹۳۵هزار
s = split_coupon_discount('1000000', '100000', '10', '165000')
check("D>F: درآمد کارمزد پلتفرم صفر", s['fee_percent_eff'] == 0, str(s['fee_percent_eff']))

print()
print("═" * 72)
total = PASS + FAIL
print(f"نتیجه: {PASS}/{total} پاس — {'✅ همه تست‌ها موفق' if FAIL == 0 else '❌ خطا وجود دارد'}")
exit(0 if FAIL == 0 else 1)
