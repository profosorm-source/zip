<?php

declare(strict_types=1);

namespace Tests\Integration;

use App\Enums\SocialPlatform;
use PDO;
use PHPUnit\Framework\TestCase;

/**
 * FIX-F21-02-LT (بستهٔ ۷) — لایهٔ persistence قرارداد منبع واحد پلتفرم‌ها،
 * روی MariaDB واقعی (chortk).
 *
 * پیشنهاد بلندمدت گزارش بازبینی بخش ۲۱: «برای هر پلتفرم، آزمون contract از
 * انتخاب رابط تا ذخیرهٔ موفق بنویسید». این فایل پایانهٔ آن زنجیره است:
 * هر پلتفرمی که UI ارائه می‌کند (registerable) باید در ستون
 * user_social_accounts.platform واقعاً ذخیره شود — باگ F21-02 دقیقاً از
 * جنس شکستِ همین پیوند بود (UI می‌داد، validator رد می‌کرد؛ و سناریوی
 * معکوسش — validator بدهد، DB نپذیرد — اینجا برای همیشه پین می‌شود).
 *
 * @group pkg7
 */
final class Pkg7SocialPlatformPersistenceRuntimeTest extends TestCase
{
    /**
     * FIX-PKG7-ENV: پیش‌تر این تست اعتبارنامهٔ خصوصیِ خودش (user=chortke /
     * pass=chortke_dev) را می‌خواست — وابستگی محیطیِ مستند که در محیط‌های بدونِ
     * آن کاربر، ۳ skip می‌ساخت. اکنون همان قرارداد کانونیِ بقیهٔ سوئیت
     * (bootstrap/testing.php → CHORTKE_TEST_DB_*) با همان پیش‌فرض‌ها (root روی
     * 127.0.0.1:3306/chortk) خوانده می‌شود؛ TEST_DB_USER/TEST_DB_PASS قدیمی
     * همچنان به‌عنوان alias سطح‌بالا کار می‌کنند.
     */
    private const DEFAULT_HOST = '127.0.0.1';
    private const DEFAULT_PORT = '3306';
    private const DEFAULT_NAME = 'chortk';
    private const DEFAULT_USER = 'root';
    private const DEFAULT_PASS = '';

    private PDO $pdo;
    /** @var list<int> ردیف‌های ساخته‌شده برای پاکسازی teardown */
    private array $createdIds = [];

    protected function setUp(): void
    {
        try {
            // اولویت: CHORTKE_TEST_DB_* (قرارداد کانونی) → TEST_DB_* (legacy این
            // تست) → پیش‌فرض مستند. bootstrap/testing.php همین envها را به
            // DB اپلیکیشن تزریق می‌کند؛ اینجا PDO خام همان منبع حقیقت را می‌خواند.
            $host = getenv('CHORTKE_TEST_DB_HOST') ?: getenv('TEST_DB_HOST') ?: self::DEFAULT_HOST;
            $port = getenv('CHORTKE_TEST_DB_PORT') ?: getenv('TEST_DB_PORT') ?: self::DEFAULT_PORT;
            $name = getenv('CHORTKE_TEST_DB_NAME') ?: getenv('TEST_DB_NAME') ?: self::DEFAULT_NAME;
            $user = getenv('CHORTKE_TEST_DB_USER') ?: getenv('TEST_DB_USER') ?: self::DEFAULT_USER;
            $passEnv = getenv('CHORTKE_TEST_DB_PASS');
            $pass = $passEnv !== false ? (string)$passEnv : (getenv('TEST_DB_PASS') !== false ? (string)getenv('TEST_DB_PASS') : self::DEFAULT_PASS);
            $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s', $host, $port, $name);
            $this->pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        } catch (\PDOException $e) {
            $this->markTestSkipped('MariaDB تست در دسترس نیست: ' . $e->getMessage());
        }
    }

    protected function tearDown(): void
    {
        if (!empty($this->createdIds)) {
            $ph = implode(',', array_fill(0, count($this->createdIds), '?'));
            $stmt = $this->pdo->prepare("DELETE FROM user_social_accounts WHERE id IN ({$ph})");
            $stmt->execute($this->createdIds);
            $this->createdIds = [];
        }
    }

    /**
     * قرارداد زندهٔ ستون: مقدار ENUM واقعی DB باید دقیقاً همان cases() باشد —
     * اگر schema و enum از هم جدا شوند (مثلاً مقدار جدید فقط در یکی)، این
     * تست fail-loud می‌شود تا مایگریشن و enum با هم آپدیت شوند.
     */
    public function testLiveDbColumnEnumMatchesEnumCases(): void
    {
        $stmt = $this->pdo->query(
            "SELECT COLUMN_TYPE FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'user_social_accounts'
               AND COLUMN_NAME = 'platform'"
        );
        $columnType = $stmt->fetchColumn();
        $this->assertIsString($columnType, 'ستون platform در user_social_accounts باید وجود داشته باشد');

        $this->assertSame(1, preg_match('/^enum\((.*)\)$/i', $columnType, $m), "COLUMN_TYPE غیرمنتظره: {$columnType}");
        preg_match_all("/'([^']+)'/", $m[1], $vals);
        $dbValues = $vals[1];

        $enumValues = array_map(static fn(SocialPlatform $c): string => $c->value, SocialPlatform::cases());
        $this->assertSame(
            $enumValues,
            $dbValues,
            'ستون DB و SocialPlatform::cases() باید یک قرارداد باشند — تغییر هرکدام = تغییر دومی + مایگریشن'
        );
    }

    /**
     * قلب پیشنهاد گزارش: از انتخاب رابط تا ذخیرهٔ موفق — هر پلتفرمی که
     * forSelect() (درپ‌داون UI) ارائه می‌کند، INSERT واقعی در جدول می‌شود
     * و همان مقدار خوانده می‌شود (بدون truncation/تبدیل ساکت).
     */
    public function testEveryUiOfferedPlatformPersistsSuccessfully(): void
    {
        $userId = $this->anyRealUserId();

        foreach (SocialPlatform::forSelect() as $platform => $label) {
            $username = 'pkg7_' . $platform . '_' . bin2hex(random_bytes(4));
            $stmt = $this->pdo->prepare(
                'INSERT INTO user_social_accounts (user_id, platform, username, follower_count, status)
                 VALUES (?, ?, ?, 0, "pending")'
            );
            $stmt->execute([$userId, $platform, $username]);
            $id = (int)$this->pdo->lastInsertId();
            $this->createdIds[] = $id;

            $readBack = $this->pdo->prepare('SELECT platform, username FROM user_social_accounts WHERE id = ?');
            $readBack->execute([$id]);
            $row = $readBack->fetch(PDO::FETCH_ASSOC);

            $this->assertIsArray($row, "ردیف {$platform} باید قابل خواندن باشد");
            $this->assertSame($platform, $row['platform'], "پلتفرم باید عیناً ذخیره/خوانده شود: {$platform}");
            $this->assertSame($username, $row['username']);
        }
    }

    /**
     * سناریوی معکوس F21-02: مقداری در قرارداد ستون نیست (و در enum هم
     * نیست) — DB باید fail-loud رد کند، نه اینکه ساکت نرمالایز کند
     * (MariaDB در حالت strict دادهٔ خارج از ENUM را رد می‌کند).
     */
    public function testValueOutsideColumnContractIsRejectedByDb(): void
    {
        $userId = $this->anyRealUserId();

        $stmt = $this->pdo->prepare(
            'INSERT INTO user_social_accounts (user_id, platform, username, status)
             VALUES (?, ?, "pkg7_invalid", "pending")'
        );

        try {
            @$stmt->execute([$userId, 'snapchat']);
            // اگر رسیدیم یعنی MariaDB ساکت مقدار را پذیرفته (حالت غیر strict)
            $this->fail('مقدار خارج از ENUM ستون باید توسط DB رد شود (حالت strict)');
        } catch (\PDOException $e) {
            // Data truncated / Invalid value — ردِ fail-loud همان قرارداد است
            $this->assertStringContainsStringIgnoringCase(
                'truncat',
                $e->getMessage(),
                'ردِ انتظاریِ DB: ' . $e->getMessage()
            );
            // cleanup احتیاطی — در حالت غیر strict ممکن است ردیف درج شده باشد
            $del = $this->pdo->prepare('DELETE FROM user_social_accounts WHERE username = "pkg7_invalid"');
            $del->execute();
        }
    }

    /** شناسهٔ یک کاربر واقعی از DB تست (FK fk_social_user) */
    private function anyRealUserId(): int
    {
        $id = $this->pdo->query('SELECT id FROM users ORDER BY id LIMIT 1')->fetchColumn();
        $this->assertNotFalse($id, 'DB تست باید حداقل یک کاربر داشته باشد (seed)');
        return (int)$id;
    }
}
