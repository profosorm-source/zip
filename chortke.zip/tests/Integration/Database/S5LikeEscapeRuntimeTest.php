<?php

declare(strict_types=1);

namespace Tests\Integration\Database;

use App\Traits\Filterable;
use Core\Application;
use Core\Database;
use Core\Model;
use Core\QueryBuilder;
use PHPUnit\Framework\TestCase;

/**
 * بچ S5 — راستی‌آزمایی runtime فیکس‌های FIX-S5-1/2 روی MariaDB واقعی
 *
 * الگوی تبعیض‌کننده (قبل/بعد فیکس نتیجه عوض می‌شود):
 *   - جستجوی "\" (بک‌اسلش تنها): قبل از فیکس الگوی "%\%" یعنی «لیترال %» ⇒
 *     فقط ردیف percent می‌آمد؛ بعد از فیکس "%\\%" یعنی «بک‌اسلش» ⇒ فقط ردیف back.
 *   - جستجوی "\%": قبل از فیکس "%\\%" یعنی «بک‌اسلش + wildcard زنده» ⇒
 *     ردیف back می‌آمد (تزریق wildcard)؛ بعد از فیکس یعنی «لیترال \%» ⇒ صفر ردیف.
 *
 * جدول TEMPORARY است (همان اتصال، بدون آلودگی داده) و در tearDown حذف می‌شود.
 */
final class S5LikeEscapeRuntimeTest extends TestCase
{
    private Database $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Application::getInstance()->container->make(Database::class);

        $this->db->execute('DROP TEMPORARY TABLE IF EXISTS s5_like_probe');
        $this->db->execute('CREATE TEMPORARY TABLE s5_like_probe (v VARCHAR(200))');
        $this->db->execute('INSERT INTO s5_like_probe (v) VALUES (?)', ['percent%here']);
        $this->db->execute('INSERT INTO s5_like_probe (v) VALUES (?)', ['under_score']);
        $this->db->execute('INSERT INTO s5_like_probe (v) VALUES (?)', ['back' . chr(92) . 'slash']);
        $this->db->execute('INSERT INTO s5_like_probe (v) VALUES (?)', ['plain']);
    }

    protected function tearDown(): void
    {
        $this->db->execute('DROP TEMPORARY TABLE IF EXISTS s5_like_probe');
        parent::tearDown();
    }

    /** مدل probe با سرویس‌دهندهٔ applySearch والد (FIX-S5-1) */
    private function makeSearchProbe(): Model
    {
        return new class extends Model {
            protected static string $table = 's5_like_probe';
            protected static array $searchable = ['v'];
            public function __construct()
            {
                // applySearch فقط به QueryBuilder ورودی تکیه دارد
            }
            public function search(\Core\QueryBuilder $query, ?string $term): \Core\QueryBuilder
            {
                return $this->applySearch($query, $term);
            }
        };
    }

    /** مدل probe با Trait پروژه (FIX-S5-2) */
    private function makeFilterProbe(): Model
    {
        return new class extends Model {
            use Filterable;
            protected static string $table = 's5_like_probe';
            protected static array $filterable = ['probe' => ['v', 'LIKE']];
            public function __construct()
            {
            }
            public function filter(\Core\QueryBuilder $query, array $filters): \Core\QueryBuilder
            {
                return $this->applyFilters($query, $filters);
            }
        };
    }

    /** @return list<string> */
    private function valuesOf(QueryBuilder $query): array
    {
        return array_map(static fn($row): string => (string) $row->v, $query->get());
    }

    public function test_search_for_lone_backslash_matches_only_backslash_row(): void
    {
        $rows = $this->valuesOf(
            $this->makeSearchProbe()->search($this->db->table('s5_like_probe'), chr(92))
        );
        $this->assertSame(['back' . chr(92) . 'slash'], $rows);
    }

    public function test_search_for_backslash_prefixed_percent_cannot_inject_wildcard(): void
    {
        // قبل از فیکس این جستجو ردیفِ «back\slash» را برمی‌گرداند (wildcard زنده)
        $rows = $this->valuesOf(
            $this->makeSearchProbe()->search($this->db->table('s5_like_probe'), chr(92) . '%')
        );
        $this->assertSame([], $rows);
    }

    public function test_search_for_plain_wildcards_still_escaped(): void
    {
        $rows = $this->valuesOf(
            $this->makeSearchProbe()->search($this->db->table('s5_like_probe'), '%')
        );
        $this->assertSame(['percent%here'], $rows);

        $rows = $this->valuesOf(
            $this->makeSearchProbe()->search($this->db->table('s5_like_probe'), '_')
        );
        $this->assertSame(['under_score'], $rows);
    }

    public function test_search_for_literal_substring_still_matches(): void
    {
        $rows = $this->valuesOf(
            $this->makeSearchProbe()->search($this->db->table('s5_like_probe'), 'here')
        );
        $this->assertSame(['percent%here'], $rows);
    }

    public function test_filterable_like_branch_ignores_backslash_wildcard_injection(): void
    {
        $probe = $this->makeFilterProbe();

        // جستجوی لیترال بک‌اسلش → فقط ردیف مربوط
        $rows = $this->valuesOf($probe->filter(
            $this->db->table('s5_like_probe'),
            ['probe' => 'back' . chr(92) . 'slash']
        ));
        $this->assertSame(['back' . chr(92) . 'slash'], $rows);

        // "\%" → بدون wildcard تزریقی → صفر ردیف
        $rows = $this->valuesOf($probe->filter(
            $this->db->table('s5_like_probe'),
            ['probe' => chr(92) . '%']
        ));
        $this->assertSame([], $rows);
    }

    public function test_temporary_table_cleanup_removes_probe_rows(): void
    {
        $this->db->execute('DROP TEMPORARY TABLE IF EXISTS s5_like_probe');
        // لاگر پروژه خطای SQL را چاپ می‌کند (رفتار شناخته‌شده — الگوی S4)
        $this->expectOutputRegex('/database\.fetchAll\.failed/');
        // پس از حذف، کوئری روی جدول probe باید شکست بخورد (آلودگی داده صفر)
        $this->expectException(\PDOException::class);
        $this->db->fetchAll('SELECT * FROM s5_like_probe');
    }
}
