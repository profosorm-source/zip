<?php

declare(strict_types=1);

namespace Tests\Integration\Database;

use Core\Application;
use Core\Cache;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بچ S6 — راستی‌آزمایی runtime فیکس‌های FIX-S6-2/S6-3 روی زیرساخت واقعی:
 *
 *  - FIX-S6-3: classify خواندنِ قفل‌گذار — «SELECT … FOR UPDATE» و مشابه‌هایش
 *    باید در مسیر Database::prepare()/query() به‌عنوان non-read طبقه‌بندی شوند
 *    (روی primary بروند). راستی‌آزمایی: بازتاب isLockingRead + اجرای واقعی
 *    FOR UPDATE داخل تراکنش روی MariaDB (بدون رگرسیون).
 *  - FIX-S6-2: Cache::put با TTL غیرمثبت روی مسیر Redis = forget (نه RedisException)
 *    و هم‌رفتار با درایور فایل و قرارداد setSeconds.
 *
 * بدون رپلیکا، هر دو اتصال یکی است — discriminating assertion از طریق بازتابِ
 * متد classify انجام می‌شود (نه مقایسهٔ اتصال).
 */
final class S6LockingReadRoutingTest extends TestCase
{
    private Database $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Application::getInstance()->container->make(Database::class);
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S6-3 — isLockingRead + اجرای واقعی
    // ─────────────────────────────────────────────────────────────

    /** @return array<string, bool> */
    private function classifyViaPrepare(string $sql): bool
    {
        // طبقه‌بندی داخل prepare() از بازتاب $isRead محلی قابل خواندن نیست؛
        // به‌جای آن متد کمک‌گیر isLockingRead را (همان نقطهٔ تصمیم) بازتاب می‌گیریم.
        $m = new \ReflectionMethod(Database::class, 'isLockingRead');
        $m->setAccessible(true);
        return (bool) $m->invoke($this->db, $sql);
    }

    public function test_locking_reads_are_classified_non_read(): void
    {
        $this->assertTrue($this->classifyViaPrepare('SELECT * FROM wallet_transactions WHERE id = ? FOR UPDATE'));
        $this->assertTrue($this->classifyViaPrepare('select * from t1 FOR SHARE'));
        $this->assertTrue($this->classifyViaPrepare("SELECT balance FROM wallets WHERE user_id = 1 LOCK IN SHARE MODE"));
        $this->assertTrue($this->classifyViaPrepare('SELECT * FROM t WHERE x = 1   FOR    UPDATE'));
    }

    public function test_plain_reads_and_writes_are_not_misclassified(): void
    {
        $this->assertFalse($this->classifyViaPrepare('SELECT * FROM users WHERE id = ?'));
        $this->assertFalse($this->classifyViaPrepare('UPDATE users SET name = ? WHERE id = ?'));
        $this->assertFalse($this->classifyViaPrepare('SELECT * FROM t WHERE note = "please share this"'));
        // مرز کلمه: شناسهٔ for_update نباید قفل‌گذار تشخیص داده شود
        $this->assertFalse($this->classifyViaPrepare('SELECT * FROM t WHERE for_update = 1'));
    }

    public function test_for_update_executes_on_real_mariadb_inside_transaction(): void
    {
        $this->db->execute('DROP TEMPORARY TABLE IF EXISTS s6_lock_probe');
        $this->db->execute('CREATE TEMPORARY TABLE s6_lock_probe (id INT PRIMARY KEY, v VARCHAR(50))');
        $this->db->execute('INSERT INTO s6_lock_probe (id, v) VALUES (1, ?)', ['alpha']);

        $this->db->beginTransaction();
        try {
            $stmt = $this->db->query('SELECT id, v FROM s6_lock_probe WHERE id = 1 FOR UPDATE');
            $row = $stmt->fetch(\PDO::FETCH_OBJ);
            $this->assertSame('alpha', $row->v);
        } finally {
            $this->db->commit();
        }
        $this->db->execute('DROP TEMPORARY TABLE IF EXISTS s6_lock_probe');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S6-2 — Cache::put با TTL غیرمثبت روی Redis واقعی
    // ─────────────────────────────────────────────────────────────

    public function test_put_with_zero_and_negative_ttl_forgets_instead_of_crashing(): void
    {
        $cache = Cache::getInstance();

        $seedKey = 's6_ttl_probe_' . uniqid('', true);

        // seed: کلید موجود با TTL مثبت — سپس بازنویسی با TTL=0 باید حذفش کند
        $this->assertTrue($cache->put($seedKey, 'live', 5));
        $this->assertSame('live', $cache->get($seedKey));

        // بازنویسی با TTL=0: کلید موجود حذف می‌شود (forget → true)
        $this->assertTrue($cache->put($seedKey, 'should-vanish', 0));
        $this->assertNull($cache->get($seedKey), 'TTL=0 یعنی کلید نباید موجود باشد');

        // کلیدِ نو با TTL منفی: چیزی برای حذف نیست → false (قرارداد setSeconds)
        // و مهم‌تر: هیچ RedisException‌ای پرتاب نمی‌شود و مقدار ذخیره هم نمی‌شود
        $this->assertFalse($cache->put($seedKey . '_neg', 'x', -3));
        $this->assertNull($cache->get($seedKey . '_neg'), 'TTL منفی هم forget است');
    }

    public function test_put_with_positive_ttl_still_stores(): void
    {
        $cache = Cache::getInstance();
        $key = 's6_ttl_regression_' . uniqid('', true);
        try {
            $this->assertTrue($cache->put($key, ['v' => 42], 5));
            $this->assertSame(['v' => 42], $cache->get($key));
        } finally {
            $cache->forget($key);
        }
    }
}
