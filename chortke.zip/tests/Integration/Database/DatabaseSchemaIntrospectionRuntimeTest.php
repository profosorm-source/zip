<?php

declare(strict_types=1);

namespace Tests\Integration\Database;

use Core\Cache;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * W4-F (F-A2-08) — تست یکپارچگیِ Schema Introspection در core/Database.php
 * (پشتوانهٔ Runtime Column Guard) روی MariaDB واقعی (chortk).
 *
 * پین‌کردن قرارداد:
 *  ① getTableColumns(t) = ستون‌های زندهٔ INFORMATION_SCHEMA.COLUMNS (ترتیب ordinal).
 *  ② جدول غایب → [] (بدون استثنا — مصرف‌کننده fail-open است) و شناسهٔ نامعتبر → null.
 *  ③ کش دو-لایه: استاتیک per-process → کش مشترک (TTL 600s) → DB.
 *     - انقضای لایهٔ استاتیک، لایهٔ مشترک را بدون کوئری مصرف می‌کند (worker طولانی‌عمر).
 *     - انقضای کامل (استاتیک + مشترک) → کوئری تازه و refresh هر دو لایه.
 *     - هیچ negative-cache برای خطا وجود ندارد (null uncached).
 *  ④ getFreshTableColumns(t) هر دو لایه را دور می‌زند و هر دو را refresh می‌کند
 *     (محافظت از کشِ کهنه در مسیر نقضِ گارد — ستون تازه-افوده false-positive نمی‌دهد).
 *
 * ایدیم خانه: tests/Integration/Models/ModelBoundaryContractsRuntimeTest.php —
 * DB واقعی از container + پاک‌سازی صریح در tearDown (کلید کشِ مشترک forget می‌شود).
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class DatabaseSchemaIntrospectionRuntimeTest extends TestCase
{
    private const TABLE = 'payment_gateways';

    private Database $db;
    private string $sharedKey;
    /** @var \ReflectionClass<Database> */
    private \ReflectionClass $reflection;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = \Core\Application::getInstance()->container->make(Database::class);
        $this->reflection = new \ReflectionClass(Database::class);
        $prefix = $this->reflection->getConstant('SCHEMA_CACHE_SHARED_PREFIX');
        $this->assertIsString($prefix);
        $dbName = (string)(config('database')['name'] ?? 'chortk');
        $this->sharedKey = $prefix . $dbName . '.' . self::TABLE;

        Database::resetTableColumnsCache();
        $this->forgetShared();
    }

    protected function tearDown(): void
    {
        Database::resetTableColumnsCache();
        $this->forgetShared();
        parent::tearDown();
    }

    private function forgetShared(): void
    {
        try {
            Cache::getInstance()->forget($this->sharedKey);
        } catch (\Throwable $ignore) {
            // کش مشترک اختیاری است
        }
    }

    /** 'at' لایهٔ استاتیک را به‌صورت مصنوعی منقضی می‌کند */
    private function expireStaticLayer(): void
    {
        $prop = $this->reflection->getProperty('tableColumnsCache');
        if (PHP_VERSION_ID < 80100) { $prop->setAccessible(true); }
        $cache = $prop->getValue();
        $key = $this->staticKey();
        $this->assertArrayHasKey($key, $cache, 'لایهٔ استاتیک باید پس از اولین خواندن پر شده باشد');
        $cache[$key]['at'] = time() - 601; // پنجرهٔ 600s منقضی
        // tableColumnsCache استاتیک است — PHP 8.3+ برای ست‌کردن static فقط
        // setValue(null, …) را می‌پذیرد (arg غیر object/null یک deprecation
        // چاپ می‌کند که در PHPUnit خطا می‌شود).
        $prop->setValue(null, $cache);
    }

    private function staticKey(): string
    {
        $dbName = (string)(config('database')['name'] ?? 'chortk');
        return $dbName . '.' . self::TABLE;
    }

    private function seedStaleColumnEverywhere(string $ghostColumn): void
    {
        $key = $this->staticKey();
        $prop = $this->reflection->getProperty('tableColumnsCache');
        if (PHP_VERSION_ID < 80100) { $prop->setAccessible(true); }
        $prop->setValue(null, [$key => ['columns' => ['ghost_w4f'], 'at' => time()]]);

        try {
            Cache::getInstance()->put($this->sharedKey, ['ghost_w4f'], 10);
        } catch (\Throwable $e) {
            $this->markTestSkipped('کش مشترک در دسترس نیست: ' . $e->getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────
    // ① منبع حقیقت
    // ─────────────────────────────────────────────────────────────

    public function test_returns_live_columns_in_ordinal_order(): void
    {
        $columns = $this->db->getTableColumns(self::TABLE);

        $this->assertIsArray($columns);
        $this->assertNotEmpty($columns);
        foreach (['id', 'name', 'slug', 'config', 'is_active', 'callback_ips', 'updated_at'] as $expected) {
            $this->assertContains($expected, $columns, "ستون زندهٔ {$expected} باید در خروجی باشد");
        }
        $this->assertSame('id', $columns[0], 'ترتیب باید ordinal باشد (id اول)');
    }

    public function test_missing_table_yields_empty_list_without_throwing(): void
    {
        $this->assertSame([], $this->db->getTableColumns('w4f_missing_table_xyz'));
    }

    public function test_invalid_identifier_is_out_of_contract_and_returns_null(): void
    {
        $this->assertNull($this->db->getTableColumns('bad-name'));
        $this->assertNull($this->db->getTableColumns('x`injection'));
        $this->assertNull($this->db->getTableColumns(''));
    }

    // ─────────────────────────────────────────────────────────────
    // ③ کش دو-لایه + TTL
    // ─────────────────────────────────────────────────────────────

    public function test_shared_cache_is_populated_and_serves_after_static_expiry(): void
    {
        $first = $this->db->getTableColumns(self::TABLE);
        $this->assertContains('id', $first);

        // کش مشترک باید پر شده باشد (TTL دقیقه‌محور 10min)
        try {
            $shared = Cache::getInstance()->get($this->sharedKey);
        } catch (\Throwable $e) {
            $this->markTestSkipped('کش مشترک در دسترس نیست: ' . $e->getMessage());
        }
        $this->assertIsArray($shared);
        $this->assertContains('id', $shared);

        // انقضای مصنوعی لایهٔ استاتیک → خواندن بعدی باید از لایهٔ مشترک جواب
        // بگیرد و لایهٔ استاتیک را تازه کند (بدون DB query — خروجی عیناً همان است)
        $this->expireStaticLayer();
        $second = $this->db->getTableColumns(self::TABLE);
        $this->assertSame($first, $second);

        $prop = $this->reflection->getProperty('tableColumnsCache');
        if (PHP_VERSION_ID < 80100) { $prop->setAccessible(true); }
        $cache = $prop->getValue();
        $this->assertGreaterThan(
            time() - 5,
            (int)($cache[$this->staticKey()]['at'] ?? 0),
            'لایهٔ استاتیک باید بعد از hit لایهٔ مشترک تازه شود'
        );
    }

    public function test_full_ttl_expiry_refreshes_from_db_and_both_layers(): void
    {
        $first = $this->db->getTableColumns(self::TABLE);
        $this->assertContains('id', $first);

        // انقضای کامل: استاتیک منقضی + کش مشترک حذف → خواندن بعدی باید به DB برود
        $this->expireStaticLayer();
        $this->forgetShared();

        $second = $this->db->getTableColumns(self::TABLE);
        $this->assertSame($first, $second, 'پس از انقضای کامل، منبع حقیقت باید همان ستون‌های زنده بدهد');

        // هر دو لایه باید دوباره پر شده باشند
        try {
            $shared = Cache::getInstance()->get($this->sharedKey);
        } catch (\Throwable $e) {
            $shared = null;
        }
        $this->assertIsArray($shared, 'کش مشترک باید پس از refresh دوباره پر شود');
        $this->assertContains('id', $shared);
    }

    // ─────────────────────────────────────────────────────────────
    // ④ مسیر تازه (bypass + refresh)
    // ─────────────────────────────────────────────────────────────

    public function test_fresh_recheck_bypasses_stale_cache_and_heals_both_layers(): void
    {
        // شبیه‌سازی کشِ کهنه پس از مایگریشن زنده: هر دو لایه فقط 'ghost_w4f' را می‌شناسند
        $this->seedStaleColumnEverywhere('ghost_w4f');

        // خواندن کش‌دار عیناً لیست کهنه را برمی‌گرداند (اثبات اینکه لایه‌ها مصرف می‌شوند)
        $stale = $this->db->getTableColumns(self::TABLE);
        $this->assertSame(['ghost_w4f'], $stale);

        // خواندن تازه: دور زدن هر دو لایه → ستون‌های واقعی + refresh هر دو لایه
        $fresh = $this->db->getFreshTableColumns(self::TABLE);
        $this->assertIsArray($fresh);
        $this->assertContains('id', $fresh);
        $this->assertNotContains('ghost_w4f', $fresh);

        // خواندن کش‌دار بعدی باید لیست سالم تازه را بدهد (کش شفا یافت)
        $healed = $this->db->getTableColumns(self::TABLE);
        $this->assertSame($fresh, $healed);
    }

    public function test_fresh_recheck_on_missing_table_does_not_negative_cache_null(): void
    {
        // جدول غایب → [] (قابل‌کش) — اما null (شکست گذرایی) هرگز کش نمی‌شود؛
        // این را با شناسهٔ خارج از قرارداد (null) و جدول غایب ([]) تفکیک می‌کنیم.
        $this->assertNull($this->db->getFreshTableColumns('bad-name'));
        $this->assertSame([], $this->db->getFreshTableColumns('w4f_missing_table_xyz'));

        // [] کش شده باشد یا نه، رفتار بعدی یکسان است (بدون استثنا)
        $this->assertSame([], $this->db->getTableColumns('w4f_missing_table_xyz'));
    }
}
