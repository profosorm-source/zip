<?php

declare(strict_types=1);

namespace Tests\Integration\Database;

use App\Services\MigrationService;
use PDO;
use PHPUnit\Framework\TestCase;

/**
 * 🔒 AUDIT-FIX (migration audit R2-HIGH) — پینِ گارد destructive مایگریشن‌های PHP.
 *
 * باگ پین‌شده: فایل‌های PHP مایگریشن با require مستقیم اجرا می‌شدند و گاردِ
 * ALLOW_DESTRUCTIVE_MIGRATIONS / populated-table فقط روی گزاره‌های SQL اعمال
 * می‌شد؛ یعنی DELETE FROM api_tokens و DROP TABLE در PHP مایگریشن‌ها بدون هیچ
 * opt-in سیستمی اجرا می‌شدند.
 *
 * قرارداد جدید: MigrationService::assertDestructiveOperation() همان سیاست را
 * fail-closed برای کد PHP اعمال می‌کند.
 */
final class MigrationDestructiveGuardDatabaseTest extends TestCase
{
    private PDO $pdo;

    protected function setUp(): void
    {
        // FIX-PRE-1 (migration-tests DSN drift): fallback قبلی «chortke»/«chortke_dev»
        // اعتبارنامهٔ ماشینِ محلیِ نویسندهٔ قدیمی بود — هیچ سازوکاری در ریپو آن کاربر را
        // نمی‌سازد → «Access denied for user 'chortke'@'localhost'» در هر محیط استاندارد.
        // هم‌ترازی با قرارداد کانونیکال bootstrap/testing.php (root/خالی) — همان
        // اعتبارنامه‌ای که بقیهٔ تست‌های DBِ سوئیت از قبل استفاده می‌کنند.
        $this->pdo = new PDO(
            'mysql:host=' . (getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1') . ';dbname=' . ((getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk')),
            (getenv('CHORTKE_TEST_DB_USER') ?: 'root'),
            (getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : ''),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        // پاک‌سازی ردیف‌های اجرای قبلی (idempotent بودن تست)
        $this->pdo->exec('DROP TABLE IF EXISTS audit_guard_populated_test');
        $this->pdo->exec('DROP TABLE IF EXISTS audit_guard_empty_test');
        $this->pdo->exec('DROP TABLE IF EXISTS audit_guard_populated_test_tmp');
        // گارد در تست (env=testing، بدون --fresh) باید فعال باشد
        putenv('ALLOW_DESTRUCTIVE_MIGRATIONS');
        unset($_ENV['ALLOW_DESTRUCTIVE_MIGRATIONS'], $_SERVER['ALLOW_DESTRUCTIVE_MIGRATIONS']);
    }

    protected function tearDown(): void
    {
        $this->pdo->exec('DROP TABLE IF EXISTS audit_guard_populated_test');
        $this->pdo->exec('DROP TABLE IF EXISTS audit_guard_empty_test');
        putenv('ALLOW_DESTRUCTIVE_MIGRATIONS');
        parent::tearDown();
    }

    public function test_delete_all_on_populated_table_is_blocked_without_opt_in(): void
    {
        $this->pdo->exec('CREATE TABLE audit_guard_populated_test (id INT PRIMARY KEY AUTO_INCREMENT, v VARCHAR(10))');
        $this->pdo->exec("INSERT INTO audit_guard_populated_test (v) VALUES ('a'), ('b')");

        try {
            MigrationService::assertDestructiveOperation('delete_all', 'audit_guard_populated_test');
            $this->fail('گارد باید عملیات destructive روی جدول پُر را بدون opt-in مسدود کند');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('migration safety guard', $e->getMessage());
        }

        // داده دست‌نخورده مانده باشد
        $this->assertSame('2', (string)$this->pdo->query('SELECT COUNT(*) FROM audit_guard_populated_test')->fetchColumn());
    }

    public function test_delete_all_on_empty_table_is_allowed(): void
    {
        $this->pdo->exec('CREATE TABLE audit_guard_empty_test (id INT PRIMARY KEY)');
        MigrationService::assertDestructiveOperation('delete_all', 'audit_guard_empty_test');
        $this->addToAssertionCount(1); // بدون استثنا = گذر
    }

    public function test_missing_table_is_allowed_idempotent_noop(): void
    {
        MigrationService::assertDestructiveOperation('drop_table', 'audit_guard_never_existed_xyz');
        $this->addToAssertionCount(1);
    }

    public function test_temp_table_suffix_is_exempt(): void
    {
        $this->pdo->exec('CREATE TABLE audit_guard_populated_test_tmp (id INT PRIMARY KEY AUTO_INCREMENT, v VARCHAR(10))');
        $this->pdo->exec("INSERT INTO audit_guard_populated_test_tmp (v) VALUES ('a')");
        try {
            MigrationService::assertDestructiveOperation('drop_table', 'audit_guard_populated_test_tmp');
            $this->addToAssertionCount(1);
        } finally {
            $this->pdo->exec('DROP TABLE IF EXISTS audit_guard_populated_test_tmp');
        }
    }

    public function test_drop_database_is_always_blocked_when_guard_active(): void
    {
        try {
            MigrationService::assertDestructiveOperation('drop_database', 'anything');
            $this->fail('DROP DATABASE باید همیشه مسدود شود');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('drop_database', $e->getMessage());
        }
    }

    public function test_explicit_opt_in_allow_destructive_migrations_bypasses_guard(): void
    {
        $this->pdo->exec('CREATE TABLE audit_guard_populated_test (id INT PRIMARY KEY AUTO_INCREMENT, v VARCHAR(10))');
        $this->pdo->exec("INSERT INTO audit_guard_populated_test (v) VALUES ('a')");
        putenv('ALLOW_DESTRUCTIVE_MIGRATIONS=1');
        try {
            MigrationService::assertDestructiveOperation('delete_all', 'audit_guard_populated_test');
            $this->addToAssertionCount(1);
        } finally {
            putenv('ALLOW_DESTRUCTIVE_MIGRATIONS');
        }
    }

    public function test_populated_table_check_matches_sql_guard_semantics(): void
    {
        // پین رفتار یکسان با گارد SQL: جدول پُر مسدود، جدول خالی مجاز — در هر دو مسیر
        $this->pdo->exec('CREATE TABLE audit_guard_populated_test (id INT PRIMARY KEY)');
        $this->assertSame(0, (int)$this->pdo->query('SELECT COUNT(*) FROM audit_guard_populated_test')->fetchColumn());
        MigrationService::assertDestructiveOperation('truncate', 'audit_guard_populated_test'); // خالی → مجاز
        $this->pdo->exec("INSERT INTO audit_guard_populated_test (id) VALUES (1)");
        try {
            MigrationService::assertDestructiveOperation('truncate', 'audit_guard_populated_test'); // پُر → مسدود
            $this->fail('truncate روی جدول پُر باید مسدود شود');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('truncate', $e->getMessage());
        }
    }
}
