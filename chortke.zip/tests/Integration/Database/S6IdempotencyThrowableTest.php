<?php

declare(strict_types=1);

namespace Tests\Integration\Database;

use Core\Application;
use Core\Cache;
use Core\Database;
use Core\IdempotencyKey;
use PHPUnit\Framework\TestCase;

/**
 * بچ S6 — راستی‌آزمایی runtime فیکس FIX-S6-2 (یادداشت معلق S3) روی MariaDB واقعی
 *
 * الگوی تبعیض‌کنندهٔ قبل/بعد فیکس:
 *   - قبل: wrapInstance فقط \Exception را می‌گرفت؛ callback ای که \Throwable
 *     غیر-Exception (TypeError/DivisionByZeroError/…) پرتاب می‌کرد از fail() عبور
 *     می‌کرد ⇒ ردیف کلید در وضعیت pending می‌ماند؛ فراخوان دوم در پنجرهٔ ۳۰۰ثانیه‌ای
 *     پاسخ «در حال پردازش» (is_processing + 409) می‌گرفت — در حالی که عملیات شکست
 *     خورده بود.
 *   - بعد: fail() با retryable=false صدا خورده و وضعیت failed_final ثبت می‌شود؛
 *     فراخوان دوم معناشناسی P311 («previously failed») را می‌گیرد، نه success و نه
 *     processing.
 */
final class S6IdempotencyThrowableTest extends TestCase
{
    private const PROBE_USER_ID = 999001;

    private Database $db;
    private IdempotencyKey $idk;

    protected function setUp(): void
    {
        parent::setUp();
        $container = Application::getInstance()->container;
        $this->db = $container->make(Database::class);
        $this->idk = new IdempotencyKey($this->db, $container->make(Cache::class));
    }

    protected function tearDown(): void
    {
        $this->db->execute('DELETE FROM idempotency_keys WHERE user_id = ?', [self::PROBE_USER_ID]);
        parent::tearDown();
    }

    /**
     * LogService در CLI با echo می‌نویسد و سوییت با failOnRisky=true اجرا می‌شود؛
     * خروجی logger در مسیر شکست callback باید درون buffer بلعیده شود تا تست risky نشود.
     */
    private function wrapSilently(callable $fn): mixed
    {
        ob_start();
        try {
            return $fn();
        } finally {
            ob_end_clean();
        }
    }

    public function test_non_exception_throwable_marks_key_failed_instead_of_pending(): void
    {
        $key = 's6-throwable-1-' . uniqid();

        $thrown = null;
        try {
            $this->wrapSilently(function () use ($key, &$thrown): void {
                try {
                    $this->idk->wrapInstance($key, self::PROBE_USER_ID, 's6_probe', static function (): void {
                        throw new \DivisionByZeroError('boom');
                    });
                } catch (\Throwable $e) {
                    $thrown = $e;
                }
            });
        } finally {
            // noop — فقط برای خوانایی؛ خطا داخل closure جذب شده است
        }

        // خطای اصلی دست‌نخورده به فراخوان می‌رسد (معناشناسی حفظ شده)
        $this->assertInstanceOf(\DivisionByZeroError::class, $thrown);

        $stmt = $this->db->prepare('SELECT status FROM idempotency_keys WHERE `key` = :k AND user_id = :u');
        $stmt->execute(['k' => $key, 'u' => self::PROBE_USER_ID]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        $this->assertNotFalse($row, 'idempotency row must exist after callback failure');
        $this->assertSame(
            'failed_final',
            $row['status'],
            'FIX-S6-2: کلید باید failed_final شود؛ قبل از فیکس pending می‌ماند'
        );
    }

    public function test_second_call_gets_failed_semantics_not_processing(): void
    {
        $key = 's6-throwable-2-' . uniqid();

        try {
            $this->wrapSilently(function () use ($key): void {
                try {
                    $idk = \Core\Application::getInstance()->container->make(\Core\IdempotencyKey::class);
                    $idk->wrapInstance($key, self::PROBE_USER_ID, 's6_probe', static function (): void {
                        throw new \TypeError('bad type');
                    });
                } catch (\TypeError) {
                    // انتظاری
                }
            });
        } finally {
            // noop
        }

        // فراخوان دوم: نه success (نتیجهٔ قبلی شکست خورده) و نه «در حال پردازش»
        try {
            $this->wrapSilently(function () use ($key): void {
                $idk = \Core\Application::getInstance()->container->make(\Core\IdempotencyKey::class);
                $idk->wrapInstance($key, self::PROBE_USER_ID, 's6_probe', static fn (): string => 'ok');
                $this->fail('second call must see failed semantics (P311), not success or processing');
            });
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('previously failed', $e->getMessage());
        }
    }

    public function test_exception_path_still_records_failure_and_rethrows(): void
    {
        // گارد ضد over-blocking: مسیر قدیمی \Exception باید دقیقاً مثل قبل کار کند
        $key = 's6-throwable-3-' . uniqid();

        try {
            $this->wrapSilently(function () use ($key): void {
                $this->idk->wrapInstance($key, self::PROBE_USER_ID, 's6_probe', static function (): void {
                    throw new \RuntimeException('regular failure');
                });
            });
            $this->fail('exception must propagate');
        } catch (\RuntimeException $e) {
            $this->assertSame('regular failure', $e->getMessage());
        }

        $stmt = $this->db->prepare('SELECT status FROM idempotency_keys WHERE `key` = :k AND user_id = :u');
        $stmt->execute(['k' => $key, 'u' => self::PROBE_USER_ID]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        $this->assertNotFalse($row);
        $this->assertSame('failed_final', $row['status']);
    }
}
