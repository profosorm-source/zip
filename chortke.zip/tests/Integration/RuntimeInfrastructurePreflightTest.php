<?php

declare(strict_types=1);

namespace Tests\Integration;

use Core\Application;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * Hard preflight for the runtime integration suite.
 * Missing infrastructure is a build failure, never a skipped test.
 */
final class RuntimeInfrastructurePreflightTest extends TestCase
{
    public function test_application_uses_the_canonical_container(): void
    {
        $application = Application::getInstance();

        $this->assertSame(
            $application->container,
            \Core\Container::getInstance(),
            'Application and static accessor must reference one canonical Container.'
        );
    }

    public function test_mariadb_is_reachable_and_schema_is_complete(): void
    {
        $database = Application::getInstance()->container->make(Database::class);
        $pdo = $database->getPdo();

        $this->assertSame('1', $this->pdoScalar($pdo, 'SELECT 1'));
        // PS-fix (سازگاری پلتفرمی): GLOB_BRACE بر اساس مستندات PHP همیشه تعریف‌شده
        // نیست (وابسته به بیلد/پلتفرم) — الگوی brace جای خود را به دو glob مجزا می‌دهد.
        $migrationFiles = array_values(array_unique(array_merge(
            glob(dirname(__DIR__, 2) . '/database/migrations/*.php') ?: [],
            glob(dirname(__DIR__, 2) . '/database/migrations/*.sql') ?: []
        )));
        $this->assertIsArray($migrationFiles);
        $this->assertNotEmpty($migrationFiles, 'Production migration inventory is empty.');
        // FIX-ORPHAN-TOLERANT (بازبینی ۲۰۲۶-۱۰-۲۹، همراه حذف مایگریشن منصرف‌شده):
        // پینِ «تساوی دقیق تعداد فایل = تعداد رکورد» بعد از حذف مشروعِ یک مایگریشن
        // superseded‌شده (2026_10_25_0001_antifraud_query_indexes.sql — هم‌پیشوندِ
        // php ماندگار و به‌طور کامل منصرف‌شده توسط php + 2026_10_28_0001) روی
        // دیتابیس‌های قبلاً مایگریت‌شده می‌شکند: رکورد فایلِ حذف‌شده به‌عنوان
        // orphan در schema_migrations می‌ماند — و این طبق طراحی MigrationService
        // است (runner روی «فایل‌ها» iterate می‌کند؛ رکوردهای بدون فایل بی‌اثرند).
        // قرارداد درست: هر فایل زنجیرهٔ فعلی باید رکورد اجرا داشته باشد (صفر
        // pending)؛ رکوردهای orphan (فایل حذف‌شده) legacy قابل‌قبول‌اند.
        $executedStatement = $pdo->query('SELECT migration FROM schema_migrations');
        $this->assertNotFalse($executedStatement);
        $executedRows = $executedStatement->fetchAll(\PDO::FETCH_COLUMN);
        $executed = array_map('strval', is_array($executedRows) ? $executedRows : []);
        $pending = array_values(array_diff(array_map('basename', $migrationFiles), $executed));
        $this->assertSame(
            [],
            $pending,
            'The test database must be created by the complete migration chain (every current migration file must have an executed record).'
        );
        $this->assertGreaterThanOrEqual(
            count($migrationFiles),
            count($executed),
            'Executed migration records cannot be fewer than the current chain inventory.'
        );
        $this->assertSame(
            263, // FIX-C97 + FIX-MOBILE-06 (یافتهٔ ۹۷): جدول آرشیو واقعی DLQ (dlq_archive،
                 // migration 2026_09_28_0003) اضافه شد ⇒ شمارش از این پس ۲۶۰ بود.
                 // به‌روزرسانی پین (پس از آن): دو مایگریشن 2026_10_04_* دو جدول دیگر
                 // افزودند — kyc_national_code_registry (0001) و kyc_history (0002)
                 // ⇒ شمارش کانونی زنجیرهٔ کامل مایگریشن = ۲۶۲.
                 // 🛡️ فاز ۲ سئو (FIX-SEO-23-01، ۲۰۲۶-۱۱-۰۲): مایگریشن
                 // 2026_11_02_0002 جدول seo_landing_proof_tests (رفت‌وبرگشت دکمهٔ
                 // تست اثبات فرود تبلیغ‌دهنده) افزود ⇒ شمارش = ۲۶۳.
                 // 📱 FIX-MOBILE-06 (۲۰۲۶-۱۱-۰۳): پینِ از-قبل روی درختِ به‌روزشده
                 // قرمز بود — مایگریشن 2026_11_01_0003_seo_task_clicks (بچ
                 // SEOCLICK، rename‌شده در همین بچ برای یکتایی پیشوند) جدول
                 // seo_task_clicks را با CREATE TABLE IF NOT EXISTS می‌سازد ⇒
                 // شمارش زنجیرهٔ کامل = ۲۶۴.
                 // 🧹 FIX-SEO3-02 (تصمیم ۲، تأیید کاربر ۲۰۲۶-۱۱-۰۹): نسل اولِ
                 // اثبات کلیک (SeoClickService/SeoTaskClick) با جایگزین کامل
                 // (مسیر go/token + مهرهای ستونی روی seo_executions) منسوخ شد —
                 // مایگریشن 2026_11_09_0001 جدول seo_task_clicks را DROP می‌کند
                 // ⇒ شمارش زنجیرهٔ کامل = ۲۶۵ فایل ولی جدول‌های BASE = ۲۶۳
                 // (ساخت در 0003 + حذف در 0001_1109 = خالص بدون آن جدول).
            int_value($this->pdoScalar($pdo,
                "SELECT COUNT(*) FROM information_schema.tables"
                . " WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE'"
            )),
            'Fresh test schema table count is incomplete.'
        );

        foreach (['users', 'wallets', 'transactions', 'ledger_entries', 'outbox_events', 'failed_jobs', 'idempotency_keys'] as $table) {
            $statement = $pdo->prepare(
                'SELECT COUNT(*) FROM information_schema.tables'
                . ' WHERE table_schema = DATABASE() AND table_name = ?'
            );
            $statement->execute([$table]);
            $this->assertSame(1, (int) $statement->fetchColumn(), "Required runtime table '{$table}' is missing.");
        }

        $this->assertGreaterThanOrEqual(
            4,
            int_value($this->pdoScalar($pdo, 'SELECT COUNT(*) FROM users')),
            'Deterministic seed users are missing.'
        );
        $this->assertGreaterThanOrEqual(
            4,
            int_value($this->pdoScalar($pdo, 'SELECT COUNT(*) FROM wallets')),
            'Seed wallets are missing.'
        );
    }

    public function test_redis_is_reachable_authenticated_and_writable(): void
    {
        $redisConfig = config('redis', []);
        $this->assertIsArray($redisConfig);
        $host = is_string($redisConfig['host'] ?? null) ? $redisConfig['host'] : '127.0.0.1';
        $port = is_numeric($redisConfig['port'] ?? null) ? (int) $redisConfig['port'] : 6379;
        $password = is_string($redisConfig['password'] ?? null) ? $redisConfig['password'] : '';
        $database = is_numeric($redisConfig['database'] ?? null) ? (int) $redisConfig['database'] : 0;

        $redis = new \Redis();
        $this->assertTrue($redis->connect($host, $port, 2.0), 'Redis connection failed.');
        if ($password !== '') {
            $this->assertTrue($redis->auth($password), 'Redis authentication failed.');
        }
        $this->assertTrue($redis->select($database), 'Redis database selection failed.');
        $this->assertTrue((bool) $redis->ping(), 'Redis PING failed.');

        $key = 'phpunit:preflight:' . bin2hex(random_bytes(8));
        try {
            $this->assertTrue($redis->setEx($key, 10, 'ok'), 'Redis write failed.');
            $this->assertSame('ok', $redis->get($key), 'Redis read-after-write failed.');
        } finally {
            $redis->del($key);
            $redis->close();
        }
    }

    /**
     * FIX-PKG6-ENV (بستهٔ ۶ — درس محیطی): صف‌های اشتراکی دیتابیس تست باید
     * در شروع ران خالی باشند.
     *
     * ریشه: سرور dev با قرارداد testing (DB=chortk) هر HIT HTTP را به
     * LogPerformanceJob (صف analytics) و ProcessNotificationJob (صف default)
     * تبدیل می‌کند؛ پس از دفعات E2E/health-check این صف‌ها انباشته می‌شوند.
     * WorkerLifecycleTest ورکرهای زیرپروسه‌ایِ واقعی (queue:work --stop-when-empty
     * و dlq:work --limit=5) اجرا می‌کند که این ردیف‌های بیگانه را پردازش و
     * تعدادی را به failed_jobs می‌ریزند؛ آنگاه popDlq سراسریِ تست‌های
     * OutboxQueueDlqRuntimeTest (ORDER BY failed_at ASC) به‌جای ردیف تست،
     * ردیف بیگانه برمی‌دارد → شکست‌های flaky وابسته به ترتیب/زمان.
     * این preflight همان حالت را fail-loud با پیام اقدام‌پذیر می‌گیرد.
     */
    public function test_shared_queue_tables_start_clean(): void
    {
        $pdo = Application::getInstance()->container->make(Database::class)->getPdo();

        // پنجرهٔ کهنگی ۳۰ دقیقه: HomePageTest در جریان همین ران یک ردیف analytics
        // می‌سازد و خودش پاک می‌کند (FIX-PKG6-ENV)؛ این گیت باید فقط «آلودگیِ
        // پیش از ران» (ترافیک سرور testing یا ران‌های قبلی) را بگیرد، نه
        // ردیف‌های تازهٔ درون-ران را.
        $staleQueues = (int) $this->pdoScalar(
            $pdo,
            "SELECT COUNT(*) FROM queues WHERE queue IN ('analytics', 'default', 'notifications', 'maintenance', 'high_priority')"
            . " AND created_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE)"
        );
        $this->assertSame(
            0,
            $staleQueues,
            "Stale rows ({$staleQueues}) older than 30min in shared queues of the TEST database — a dev server with "
            . 'the testing contract (DB=chortk) is polluting it. Restart it as app-env (bash opt/bin/web-start) and '
            . "clean: DELETE FROM queues WHERE queue IN ('analytics','default'); "
            . "DELETE FROM outbox_events WHERE status IN ('pending','dlq'); — otherwise DLQ runtime tests may flake."
        );

        $eligibleFailed = (int) $this->pdoScalar(
            $pdo,
            "SELECT COUNT(*) FROM failed_jobs"
        );
        $this->assertSame(
            0,
            $eligibleFailed,
            "failed_jobs is not empty ({$eligibleFailed} rows) at suite start — DLQ tests pick the OLDEST row "
            . 'globally; leftover rows will hijack their assertions. Clean with: DELETE FROM failed_jobs;'
        );

        // همان پنجرهٔ کهنگی ۳۰ دقیقه — تست‌های مالی که WalletService را می‌چرخند
        // به‌طور طبیعی رویداد wallet.mutation.completed ثبت می‌کنند (گاهی due)
        // و ردیف‌های خودشان را backdate می‌کنند تا در رقابت ترتیبِ publisher
        // برنده شوند؛ اثر جانبی درون‌ران بی‌ضرر است. خطر واقعی آلودگیِ
        // «پیش از ران» (ترافیک سرور testing) است.
        $pendingOutbox = (int) $this->pdoScalar(
            $pdo,
            "SELECT COUNT(*) FROM outbox_events WHERE status = 'pending'"
            . " AND created_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE)"
        );
        $this->assertSame(
            0,
            $pendingOutbox,
            "Stale pending outbox rows ({$pendingOutbox}) older than 30min — a testing-contract dev server is "
            . 'polluting the test DB. Clean with: DELETE FROM outbox_events WHERE status IN (\'pending\',\'dlq\');'
        );
    }

    private function pdoScalar(\PDO $pdo, string $sql): string
    {
        $statement = $pdo->query($sql);
        if (!$statement instanceof \PDOStatement) $this->fail("PDO query failed: {$sql}");
        return str_value($statement->fetchColumn());
    }

}
