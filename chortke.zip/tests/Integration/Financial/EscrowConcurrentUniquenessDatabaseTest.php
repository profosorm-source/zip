<?php

declare(strict_types=1);
namespace Tests\Integration\Financial;
use PDO;
use PHPUnit\Framework\TestCase;
final class EscrowConcurrentUniquenessDatabaseTest extends TestCase
{
    private function connection(): PDO
    {
        // FIX-PRE-1b: اعتبارنامهٔ کانونیکال سوئیت (root/خالی) — هم‌تراز با bootstrap/testing.php
        return new PDO('mysql:host='.(getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1').';dbname='.((getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk')),(getenv('CHORTKE_TEST_DB_USER') ?: 'root'),(getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : ''),[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    }
    public function test_two_transactions_cannot_create_two_active_holds_for_same_order(): void
    {
        $a=$this->connection(); $b=$this->connection();
        $order='concurrency-'.bin2hex(random_bytes(6)); $type='test_concurrent';
        $sql='INSERT INTO escrow_transactions (order_id,order_type,buyer_id,seller_id,amount,currency,status) VALUES (?,?,?,?,?,?,?)';
        try {
            $a->beginTransaction();
            $a->prepare($sql)->execute([$order,$type,1,2,'10','irt','pending']);
            $b->exec('SET innodb_lock_wait_timeout=1');
            $b->beginTransaction();
            try {
                $b->prepare($sql)->execute([$order,$type,1,2,'10','irt','pending']);
                $this->fail('Concurrent active escrow insert unexpectedly succeeded.');
            } catch (\PDOException $e) {
                $this->assertStringContainsString('Lock wait timeout', $e->getMessage());
                $b->rollBack();
            }
            $a->rollBack();
            $b->beginTransaction();
            $b->prepare($sql)->execute([$order,$type,1,2,'10','irt','pending']);
            $b->commit();
            $this->assertSame(1,(int)$b->query('SELECT COUNT(*) FROM escrow_transactions WHERE order_id='.$b->quote($order).' AND order_type='.$b->quote($type).' AND status NOT IN (\'released\',\'refunded\',\'cancelled\')')->fetchColumn());
        } finally {
            if($a->inTransaction())$a->rollBack(); if($b->inTransaction())$b->rollBack();
            $b->prepare('DELETE FROM escrow_transactions WHERE order_id=? AND order_type=?')->execute([$order,$type]);
        }
    }
}
