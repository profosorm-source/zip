<?php

declare(strict_types=1);

namespace Tests\Integration\Financial;

use PDO;
use PHPUnit\Framework\TestCase;

/**
 * بستهٔ ۵ (فوری — مالی) — تست‌های runtime روی MariaDB واقعی:
 *  • F-19-02: ماشین‌گذارِ DB وضعیت کمیسیون (claim CAS / بازپذیری پشت fence /
 *    مایگریشن ENUM با مقدار processing).
 *  • F-19-01: سریال‌سازی probe سقف بونوس شروع (SELECT … FOR UPDATE) بین دو
 *    اتصال هم‌زمان — همان چیزی که پنجرهٔ probe-then-insert را می‌بندد.
 *
 * @group pkg5
 */
final class Pkg5MoneyGuardsRuntimeTest extends TestCase
{
    // FIX-PRE-1b: اعتبارنامهٔ کانونیکال سوئیت (root/خالی) — هم‌تراز با bootstrap/testing.php
    private const DSN = 'mysql:host=127.0.0.1;dbname=chortk';
    private const USER = 'root';
    private const PASS = '';

    private const CLAIM_SQL = "UPDATE referral_commissions
                     SET status = 'processing', updated_at = NOW()
                     WHERE id = ?
                       AND (
                            status = 'pending'
                            OR (status = 'processing' AND (updated_at IS NULL OR updated_at < NOW() - INTERVAL 30 MINUTE))
                       )";

    private const CANCEL_SQL = "UPDATE referral_commissions SET status = 'cancelled', updated_at = NOW() WHERE id = ? AND status = 'pending'";

    private const MARK_PAID_SQL = "UPDATE referral_commissions SET status = 'paid', paid_at = NOW(), updated_at = NOW() WHERE id = ? AND status = 'processing'";

    private const CANDIDATES_SQL = "SELECT * FROM referral_commissions
                 WHERE currency = ?
                   AND (context IS NULL OR context NOT LIKE '%oauth_first_task%')
                   AND (
                        status = 'pending'
                        OR (status = 'processing' AND (updated_at IS NULL OR updated_at < NOW() - INTERVAL 30 MINUTE))
                   )";

    private PDO $pdo;

    protected function setUp(): void
    {
        // FIX-PRE-1b: DSN/USER/PASS قابل‌تنظیم با CHORTKE_TEST_DB_* — همان قرارداد بقیهٔ سوئیت
        $this->pdo = new PDO(
            'mysql:host=' . (getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1') . ';dbname=' . ((getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk')),
            (getenv('CHORTKE_TEST_DB_USER') ?: 'root'),
            (getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : ''),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }

    /** @return int شناسهٔ ردیفِ ساخته‌شده */
    private function insertCommission(array $overrides = []): int
    {
        $row = array_merge([
            'referrer_id' => 900001 + random_int(0, 8999),
            'referred_id' => 900001 + random_int(0, 8999),
            'amount' => '10.00000000',
            'commission_amount' => '250.00000000',
            'currency' => 'irt',
            'status' => 'pending',
            'idempotency_key' => 'pkg5rt-' . bin2hex(random_bytes(8)),
        ], $overrides);
        $cols = implode(', ', array_keys($row));
        $ph = implode(', ', array_fill(0, count($row), '?'));
        $stmt = $this->pdo->prepare("INSERT INTO referral_commissions ({$cols}) VALUES ({$ph})");
        $stmt->execute(array_values($row));
        return (int)$this->pdo->lastInsertId();
    }

    private function status(int $id): string
    {
        $stmt = $this->pdo->prepare('SELECT status FROM referral_commissions WHERE id = ?');
        $stmt->execute([$id]);
        $v = $stmt->fetchColumn();
        return is_string($v) ? $v : '';
    }

    private function deleteCommission(int $id): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM referral_commissions WHERE id = ?');
        $stmt->execute([$id]);
    }

    /**
     * F-19-02: گذار pending→processing→paid به‌صورت CAS — لغو و claim دوم
     * باید رد شوند؛ این همان ماشینی است که batchPay (کد اصلاح‌شده) استفاده
     * می‌کند و race «لغوی موفق + پرداختِ همان ردیف» را در سطح DB می‌بندد.
     */
    public function test_commission_claim_transition_is_cas_and_blocks_cancel_and_double_claim(): void
    {
        $id = $this->insertCommission();
        try {
            // ۱) claim اول پیروز است
            $claim = $this->pdo->prepare(self::CLAIM_SQL);
            $this->assertSame(1, $claim->execute([$id]) ? $claim->rowCount() : 0);
            $this->assertSame('processing', $this->status($id));

            // ۲) لغوِ هم‌زمانِ ردیفِ درحالِ-پرداخت رد می‌شود (affected=0)
            $cancel = $this->pdo->prepare(self::CANCEL_SQL);
            $cancel->execute([$id]);
            $this->assertSame(0, $cancel->rowCount(), 'cancel must lose the race against a claimed (processing) row');
            $this->assertSame('processing', $this->status($id));

            // ۳) claim دوم (بچ موازی) هم رد می‌شود
            $claim->execute([$id]);
            $this->assertSame(0, $claim->rowCount(), 'a second concurrent batch must not re-claim the same row');

            // ۴) mark-paid شرطی از processing پیروز است
            $paid = $this->pdo->prepare(self::MARK_PAID_SQL);
            $paid->execute([$id]);
            $this->assertSame(1, $paid->rowCount());
            $this->assertSame('paid', $this->status($id));
        } finally {
            $this->deleteCommission($id);
        }
    }

    /**
     * F-19-02: ردیف‌های گیرکرده در processing فقط از پشت fence ۳۰ دقیقه
     * بازپذیرنده‌اند (کرش بین claim و mark-paid) — نه ردیفِ تازهٔ processingِ
     * بچِ زنده. پوشش updated_at IS NULL (ردیف‌های legacy) هم برقرار است.
     */
    public function test_stale_processing_rows_are_readoptable_only_behind_the_fence(): void
    {
        $staleId = $this->insertCommission(['status' => 'processing']);
        $freshId = $this->insertCommission(['status' => 'processing']);
        $legacyNullId = $this->insertCommission(['status' => 'processing']);
        $this->pdo->prepare('UPDATE referral_commissions SET updated_at = DATE_SUB(NOW(), INTERVAL 40 MINUTE) WHERE id = ?')->execute([$staleId]);
        $this->pdo->prepare('UPDATE referral_commissions SET updated_at = DATE_SUB(NOW(), INTERVAL 5 MINUTE) WHERE id = ?')->execute([$freshId]);
        $this->pdo->prepare('UPDATE referral_commissions SET updated_at = NULL WHERE id = ?')->execute([$legacyNullId]);
        try {
            $claim = $this->pdo->prepare(self::CLAIM_SQL);

            $claim->execute([$staleId]);
            $this->assertSame(1, $claim->rowCount(), '40-minute-old processing row must be re-adoptable');

            $claim->execute([$freshId]);
            $this->assertSame(0, $claim->rowCount(), '5-minute-old processing row belongs to a live batch and must not be touched');

            $claim->execute([$legacyNullId]);
            $this->assertSame(1, $claim->rowCount(), 'NULL updated_at (legacy row) must be re-adoptable like a stale row');
        } finally {
            foreach ([$staleId, $freshId, $legacyNullId] as $id) { $this->deleteCommission($id); }
        }
    }

    /**
     * F-19-02: SELECT کاندیداهای بچ — pending + processingِ پشت fence؛
     * processingِ تازه (بچ زنده) و hold ضدفارمینگ oauth_first_task کنار گذاشته می‌شوند.
     */
    public function test_batch_candidate_select_shapes_the_claimable_set(): void
    {
        $pendingId = $this->insertCommission(['status' => 'pending']);
        $staleId = $this->insertCommission(['status' => 'processing']);
        $freshId = $this->insertCommission(['status' => 'processing']);
        $holdId = $this->insertCommission(['status' => 'pending', 'context' => '{"holding":"oauth_first_task"}']);
        $this->pdo->prepare('UPDATE referral_commissions SET updated_at = DATE_SUB(NOW(), INTERVAL 45 MINUTE) WHERE id = ?')->execute([$staleId]);
        $this->pdo->prepare('UPDATE referral_commissions SET updated_at = NOW() WHERE id = ?')->execute([$freshId]);
        try {
            $stmt = $this->pdo->prepare(self::CANDIDATES_SQL);
            $stmt->execute(['irt']);
            $ids = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
            $this->assertContains($pendingId, $ids);
            $this->assertContains($staleId, $ids);
            $this->assertNotContains($freshId, $ids, 'a live batch row must not be a candidate');
            $this->assertNotContains($holdId, $ids, 'anti-fraud oauth_first_task hold must stay excluded');
        } finally {
            foreach ([$pendingId, $staleId, $freshId, $holdId] as $id) { $this->deleteCommission($id); }
        }
    }

    /**
     * F-19-02: مایگریشن ENUM باید مقدار processing را بیفزاید (backward-compatible)
     * و ستون بعد از آن مقدار processing را بپذیرد و مقدار خارج از دامنه را رد کند.
     * جدول با اسکیمای اصلی مایگریشن 2026_06_10_0006 به‌صورت TEMPORARY (سایه‌گذارِ
     * هم‌نام در همین سشن — بدون دست‌زدن به جدول واقعی) ساخته می‌شود و SQL
     * مایگریشن «عیناً» (بدون هیچ دستکاری) روی آن اعمال می‌شود؛ با بسته‌شدن
     * اتصال حذف می‌شود.
     */
    public function test_enum_migration_adds_processing_value_verbatim(): void
    {
        $this->pdo->exec('CREATE TEMPORARY TABLE referral_commissions (
            `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `referrer_id` INT(10) UNSIGNED NOT NULL,
            `referred_id` INT(10) UNSIGNED NOT NULL,
            `amount` DECIMAL(24,8) NOT NULL,
            `commission_amount` DECIMAL(24,8) NOT NULL,
            `currency` VARCHAR(10) DEFAULT \'irt\',
            `status` ENUM(\'pending\', \'paid\', \'cancelled\') DEFAULT \'pending\',
            `idempotency_key` VARCHAR(128) UNIQUE,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            KEY `idx_rc_ref` (`referrer_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

        // گارد سایه‌گذاری: جدول موقت ما (بر خلاف جدول واقعی) paid_at ندارد —
        // یعنی این سشن جدول موقت را می‌بیند و ALTER روی جدول واقعی نمی‌افتد
        $shadow = $this->pdo->query("SHOW COLUMNS FROM referral_commissions LIKE 'paid_at'")->fetchColumn();
        $this->assertFalse((bool)$shadow, 'temporary table must shadow the real referral_commissions in this session');

        // مقدار processing پیش از مایگریشن باید رد شود (اثباتِ اینکه مایگریشن لازم است)
        $before = $this->pdo->prepare("INSERT INTO referral_commissions (referrer_id, referred_id, amount, commission_amount, status) VALUES (1,2,1,1,'processing')");
        try {
            $before->execute();
            $this->fail('processing must be rejected before the migration applies');
        } catch (\PDOException $e) {
            $this->assertNotFalse(stripos($e->getMessage(), 'Data truncated'), 'expected data-truncated rejection, got: ' . $e->getMessage());
        }

        // مایگریشن بستهٔ ۵ — verbatim از فایل پروژه
        $migrationSql = file_get_contents(dirname(__DIR__, 3) . '/database/migrations/2026_10_15_0001_referral_commissions_processing.sql');
        self::assertIsString($migrationSql);
        $this->pdo->exec($migrationSql);

        $col = $this->pdo->query("SHOW COLUMNS FROM referral_commissions LIKE 'status'")->fetch(PDO::FETCH_ASSOC);
        $this->assertIsArray($col);
        $type = (string)($col['Type'] ?? '');
        $this->assertStringContainsString('processing', $type);
        $values = explode(',', trim(str_replace(['enum(', ')', "'", ' '], '', $type)));
        $this->assertSame(['pending', 'processing', 'paid', 'cancelled'], $values, 'exactly the four expected enum values, in order');

        // پس از مایگریشن: processing پذیرفته می‌شود؛ مقدار نامعتبر رد می‌شود؛
        // مقدارهای قبلی دست‌نخورده‌اند
        $this->pdo->exec("INSERT INTO referral_commissions (referrer_id, referred_id, amount, commission_amount, status) VALUES (1,2,1,1,'processing')");
        $this->pdo->exec("INSERT INTO referral_commissions (referrer_id, referred_id, amount, commission_amount, status) VALUES (1,2,1,1,'pending')");
        $invalid = $this->pdo->prepare("INSERT INTO referral_commissions (referrer_id, referred_id, amount, commission_amount, status) VALUES (1,2,1,1,'bogus')");
        try {
            $invalid->execute();
            $this->fail('out-of-domain status must still be rejected after the migration');
        } catch (\PDOException $e) {
            $this->assertNotFalse(stripos($e->getMessage(), 'Data truncated'), 'expected data-truncated rejection, got: ' . $e->getMessage());
        }
        // جدول موقت با بسته‌شدن اتصال حذف می‌شود — جدول واقعی دست‌نخورده می‌ماند
    }

    /**
     * F-19-01: probe قفل‌گذار سقف بونوس شروع باید اتصال دوم را تا commit اولی
     * متوقف کند — این همان سریال‌سازی‌ای است که پنجرهٔ probe-then-insert را
     * می‌بندد (دو واریز هم‌زمان دیگر هر دو مقدار کهنه نمی‌بینند).
     */
    public function test_start_bonus_cap_probe_locks_out_a_concurrent_probe_until_commit(): void
    {
        $conn1 = new PDO(self::DSN, self::USER, self::PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $conn2 = new PDO(self::DSN, self::USER, self::PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $conn2->exec('SET SESSION innodb_lock_wait_timeout = 1');

        // کاربر واقعی موجود (FK fk_transactions_user) — درج داخل تراکنشِ roll-back-شونده است
        $userId = (int)$this->pdo->query('SELECT id FROM users ORDER BY id LIMIT 1')->fetchColumn();
        $this->assertGreaterThan(0, $userId, 'a real user row is required for the transactions FK');

        $probeSql = "SELECT COUNT(*) AS cnt, COALESCE(SUM(amount), 0) AS total
                         FROM transactions
                         WHERE type = 'referral_start_bonus' AND created_at >= ?
                         FOR UPDATE";
        $dayStart = date('Y-m-d 00:00:00');
        $marker = 'pkg5-lock-probe-' . bin2hex(random_bytes(6));

        $conn1->beginTransaction();
        try {
            // تراکنش اول: درجِ بونوسِ هنوز-commit-نشده (شبیه واریزی که در پرواز است)
            $conn1->prepare("INSERT INTO transactions (transaction_id, user_id, type, currency, amount, status, idempotency_key)
                             VALUES (?, ?, 'referral_start_bonus', 'irt', 5000, 'completed', ?)")
                ->execute(['TXN-' . $marker, $userId, 'IDEM-' . $marker]);
            // probe خودِ تراکنش اول (قفل‌گذاری روی رنج)
            $conn1->prepare($probeSql)->execute([$dayStart]);

            // تراکنش دوم: همان probe قفل‌گذار — باید روی ردیف uncommitted اولی
            // block شود و پس از ۱ ثانیه با Lock wait timeout شکست بخورد
            $t0 = microtime(true);
            try {
                $conn2->beginTransaction();
                $conn2->prepare($probeSql)->execute([$dayStart]);
                // اگر بلاک نشد، سریال‌سازی معتبر نیست
                $this->fail('concurrent cap probe must block on the locking read');
            } catch (\PDOException $e) {
                $elapsed = microtime(true) - $t0;
                $this->assertStringContainsStringIgnoringCase('Lock wait timeout', $e->getMessage());
                $this->assertGreaterThanOrEqual(0.9, $elapsed, 'the second probe really waited on the lock');
                $this->assertLessThan(10.0, $elapsed, 'the wait must be a lock wait, not a general slowdown');
            } finally {
                try { $conn2->rollBack(); } catch (\Throwable $e) { /* already rolled back on error */ }
            }
        } finally {
            try { $conn1->rollBack(); } catch (\Throwable $e) { /* ignore */ }
            // درج داخل تراکنش rollback شده — هیچ ردیفی نباید باقی بماند؛
            // بررسی نهایی تمیزی:
            $left = $this->pdo->prepare("SELECT COUNT(*) FROM transactions WHERE idempotency_key = ?");
            $left->execute(['IDEM-' . $marker]);
            $this->assertSame(0, (int)$left->fetchColumn(), 'the probe transaction must be rolled back cleanly');
        }
    }
}
