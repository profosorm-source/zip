<?php

declare(strict_types=1);
namespace Tests\Integration\Financial;
use PDO;
use PHPUnit\Framework\TestCase;
final class PaymentLogIdempotencyDatabaseTest extends TestCase
{
    public function test_non_null_payment_idempotency_key_is_unique(): void
    {
        // FIX-PRE-1b: اعتبارنامهٔ کانونیکال سوئیت (root/خالی) — هم‌تراز با bootstrap/testing.php
        $pdo=new PDO('mysql:host='.(getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1').';dbname='.((getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk')),(getenv('CHORTKE_TEST_DB_USER') ?: 'root'),(getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : ''),[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
        $key='payment-test-'.bin2hex(random_bytes(6));
        $sql='INSERT INTO payment_logs (user_id,gateway,amount,status,authority,idempotency_key) VALUES (?,?,?,?,?,?)';
        try {
            $pdo->prepare($sql)->execute([1,'test','1.00','pending','auth-'.$key,$key]);
            try { $pdo->prepare($sql)->execute([1,'test','1.00','pending','auth2-'.$key,$key]); $this->fail('Duplicate payment idempotency key accepted.'); }
            catch (\PDOException $e) { $this->assertStringContainsString('Duplicate entry',$e->getMessage()); }
        } finally { $pdo->prepare('DELETE FROM payment_logs WHERE idempotency_key=?')->execute([$key]); }
    }
}
