<?php

declare(strict_types=1);

namespace Tests\Integration\Financial;

use App\Models\AdTubeExecutionModel;
use App\Models\SocialTaskAnalyticsModel;
use App\Services\AdSystemManager;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بستهٔ ۶ (بخش‌های ۲۰ و ۲۱) — تست‌های runtime روی MariaDB واقعی (chortk):
 *
 *  • FIX-F21-03: سه متد آمار تسک اجتماعی قبلاً مقادیر ثابت برمی‌گرداندند
 *    (soft_approved=0، avg_score=100.0، avg_time=60.0) — داشبورد مجری و تبلیغ‌دهنده
 *    بدون توجه به دادهٔ واقعی «میانگین امتیاز ۱۰۰» نشان می‌دادند. اکنون:
 *    SUM/AVG واقعی روی ستون‌های موجود (status/final_score/active_time).
 *  • FIX-S20-F3: تجمیع مالی به تفکیک ارز — getAdSummary قبلاً SUM تختِ
 *    ناهم‌واحد (IRT+USDT) با label ثابت «تومان» می‌داد؛ اکنون by_currency.
 *    درآمد امروز AdTube هم قبلاً placeholder ثابت ۰ بود؛ اکنون جمع واقعی
 *    GROUP BY ارز پاداش.
 *
 * @group pkg6
 */
final class Pkg6AnalyticsAndCurrencyRuntimeTest extends TestCase
{
    private Database $db;
    /** @var list<array{0: string, 1: int}> جدول/شناسه‌های ساخته‌شده برای teardown */
    private array $created = [];

    protected function setUp(): void
    {
        $this->db = Database::getInstance();
    }

    protected function tearDown(): void
    {
        foreach ($this->created as [$table, $id]) {
            try {
                $this->db->query("DELETE FROM {$table} WHERE id = ?", [$id]);
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        $this->created = [];
    }

    private function track(string $table, int $id): void
    {
        $this->created[] = [$table, $id];
    }

    /** شناسهٔ تصادفی برای عدم برخورد با داده‌های موجود */
    private function randomId(): int
    {
        return 2_000_000 + random_int(0, 900_000);
    }

    private function insertExecution(int $adId, int $executorId, string $status, ?float $finalScore, ?int $activeTime = null): int
    {
        $this->db->query(
            "INSERT INTO social_task_executions (ad_id, executor_id, status, final_score, active_time, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())",
            [$adId, $executorId, $status, $finalScore, $activeTime]
        );
        $id = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->track('social_task_executions', $id);
        return $id;
    }

    private function insertAd(int $userId, string $currency, string $total, string $remaining, string $spent): int
    {
        $this->db->query(
            "INSERT INTO ads (user_id, title, type, currency, total_budget, remaining_budget, spent_budget, status, created_at, updated_at)
             VALUES (?, ?, 'social_task', ?, ?, ?, ?, 'active', NOW(), NOW())",
            [$userId, 'pkg6-ad-' . bin2hex(random_bytes(4)), $currency, $total, $remaining, $spent]
        );
        $id = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->track('ads', $id);
        return $id;
    }

    private function insertAdtubeView(int $adId, int $executorId, string $status, string $rewardAmount, string $rewardCurrency, bool $completedToday = true): int
    {
        $this->db->query(
            "INSERT INTO adtube_views (ad_id, executor_id, status, reward_amount, reward_currency, completed_at, created_at)
             VALUES (?, ?, ?, ?, ?, " . ($completedToday ? 'NOW()' : 'NOW() - INTERVAL 2 DAY') . ", NOW())",
            [$adId, $executorId, $status, $rewardAmount, $rewardCurrency]
        );
        $id = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->track('adtube_views', $id);
        return $id;
    }

    // ───────────────────── F21-03: آمار واقعی تسک اجتماعی ─────────────────────

    public function testExecutorStatsComputesRealSoftApprovedAndAvgScore(): void
    {
        $model = new SocialTaskAnalyticsModel($this->db);
        $executor = $this->randomId();
        $ad = $this->insertAd($this->randomId(), 'irt', '100000', '50000', '50000');

        $this->insertExecution($ad, $executor, 'approved', 80.0);
        $this->insertExecution($ad, $executor, 'soft_approved', 60.0);
        $this->insertExecution($ad, $executor, 'rejected', null);

        $stats = $model->getExecutorStats($executor);
        $this->assertNotNull($stats);

        // قبلاً: soft_approved همیشه ۰ و avg_score همیشه ۱۰۰.۰
        $this->assertSame(3, (int)$stats->total);
        $this->assertSame(1, (int)$stats->approved);
        $this->assertSame(1, (int)$stats->soft_approved, 'FIX-F21-03: soft_approved واقعی، نه صفر ثابت');
        $this->assertSame(1, (int)$stats->rejected);
        // AVG فقط روی ردیف‌های دارای امتیاز: (80+60)/2 = 70 — نه ۱۰۰ ثابت
        $this->assertEqualsWithDelta(70.0, (float)$stats->avg_score, 0.001, 'FIX-F21-03: میانگین امتیاز واقعی، نه ۱۰۰ ثابت');
        $this->assertEqualsWithDelta(100.0 / 3.0, (float)$stats->success_rate, 0.01);
    }

    public function testExecutorStatsWithoutScoresReturnsNullAvgNotFakeHundred(): void
    {
        $model = new SocialTaskAnalyticsModel($this->db);
        $executor = $this->randomId();
        $ad = $this->insertAd($this->randomId(), 'irt', '100000', '50000', '50000');

        // هیچ ردیفی امتیاز ندارد — قبلاً ۱۰۰.۰ «واقعی‌نما» برمی‌گشت
        $this->insertExecution($ad, $executor, 'approved', null);
        $this->insertExecution($ad, $executor, 'rejected', null);

        $stats = $model->getExecutorStats($executor);
        $this->assertNotNull($stats);
        $this->assertNull($stats->avg_score, 'در نبود داده باید NULL باشد، نه عدد ظاهراً واقعی (توصیهٔ گزارش F21-03)');
    }

    public function testWeeklyExecutionStatsComputesRealValues(): void
    {
        $model = new SocialTaskAnalyticsModel($this->db);
        $executor = $this->randomId();
        $ad = $this->insertAd($this->randomId(), 'irt', '100000', '50000', '50000');

        $this->insertExecution($ad, $executor, 'approved', 90.0);
        $this->insertExecution($ad, $executor, 'soft_approved', 30.0);

        $stats = $model->getWeeklyExecutionStats($executor);
        $this->assertNotNull($stats);
        $this->assertSame(2, (int)$stats->total);
        $this->assertSame(1, (int)$stats->good_tasks);
        $this->assertSame(1, (int)$stats->soft_approved, 'FIX-F21-03: پنجرهٔ هفتگی هم soft_approved واقعی');
        $this->assertEqualsWithDelta(60.0, (float)$stats->avg_score, 0.001, 'FIX-F21-03: (90+30)/2، نه ۱۰۰ ثابت');
    }

    public function testAdvertiserAdStatsComputesRealAverages(): void
    {
        $model = new SocialTaskAnalyticsModel($this->db);
        $advertiser = $this->randomId();
        $ad = $this->insertAd($advertiser, 'irt', '100000', '50000', '50000');

        $this->insertExecution($ad, $this->randomId(), 'approved', 90.0, 100);
        $this->insertExecution($ad, $this->randomId(), 'soft_approved', 50.0, 20);
        // ردیف ردشده: نه امتیاز دارد نه زمان تماشای انباشته (NULL) — ستون
        // active_time طبق اسکیما nullable است و اجرای ردشدهٔ هرگز-تماشانشده
        // NULL می‌ماند؛ AVG مثل avg_score ردیف‌های NULL را نادیده می‌گیرد.
        $this->insertExecution($ad, $this->randomId(), 'rejected', null, null);

        $stats = $model->getAdvertiserAdStats($ad, $advertiser);
        $this->assertNotNull($stats);

        // قبلاً: 0/100.0/60.0 ثابت
        $this->assertSame(3, (int)$stats->total_executions);
        $this->assertSame(1, (int)$stats->approved);
        $this->assertSame(1, (int)$stats->soft_approved);
        $this->assertEqualsWithDelta(70.0, (float)$stats->avg_score, 0.001, 'FIX-F21-03: (90+50)/2');
        $this->assertEqualsWithDelta(60.0, (float)$stats->avg_time, 0.001, 'FIX-F21-03: AVG(active_time)=(100+20)/2 — نه ۶۰ ثابت');
    }

    // ───────────────────── S20-F3: تجمیع مالی به تفکیک ارز ─────────────────────

    public function testGetAdSummaryGroupsFinancialSumsByCurrency(): void
    {
        $manager = new AdSystemManager(
            $this->db,
            $this->createMock(\App\Contracts\LoggerInterface::class),
            [], // بدون آداپتور — getAdSummary آداپتور نمی‌خواهد
            $this->createMock(\App\Contracts\AdsRepositoryInterface::class),
            $this->createMock(\App\Services\EscrowService::class),
            $this->createMock(\App\Services\SagaOrchestrator::class),
            $this->createMock(\App\Contracts\WalletServiceInterface::class),
            $this->createMock(\App\Services\Ads\AdsBudgetSettlementService::class)
        );

        $user = $this->randomId();
        $this->insertAd($user, 'irt', '1000', '500', '500');
        $this->insertAd($user, 'irt', '2000', '1000', '1000');
        $this->insertAd($user, 'usdt', '10', '4', '6');

        $summary = $manager->getAdSummary($user);

        // شمارش‌ها سراسری‌اند (ارز-آگاه نیستند — قرارداد موجود)
        $this->assertSame(3, $summary['total']);

        // قهرمانِ S20-F3: جمع‌های مالی به تفکیک ارز
        $byCurrency = $summary['by_currency'];
        $this->assertIsArray($byCurrency);
        $this->assertArrayHasKey('irt', $byCurrency);
        $this->assertArrayHasKey('usdt', $byCurrency);

        $this->assertSame(2, $byCurrency['irt']['total']);
        $this->assertEqualsWithDelta(3000.0, (float)$byCurrency['irt']['total_budget'], 0.0001);
        $this->assertEqualsWithDelta(1500.0, (float)$byCurrency['irt']['remaining_budget'], 0.0001);
        $this->assertEqualsWithDelta(1500.0, (float)$byCurrency['irt']['spent_budget'], 0.0001);

        $this->assertSame(1, $byCurrency['usdt']['total']);
        $this->assertEqualsWithDelta(10.0, (float)$byCurrency['usdt']['total_budget'], 0.0001);
        $this->assertEqualsWithDelta(4.0, (float)$byCurrency['usdt']['remaining_budget'], 0.0001);
        $this->assertEqualsWithDelta(6.0, (float)$byCurrency['usdt']['spent_budget'], 0.0001);

        // جمع تختِ legacy (سازگاری مصرف‌کننده‌های قدیمی) = مجموع دو ارز؛
        // این عدد به‌تنهایی «پول» نیست (ناهم‌واحد) — فقط برای pin رفتار.
        $this->assertEqualsWithDelta(3010.0, (float)$summary['total_budget'], 0.0001);
    }

    public function testEarningsTodayByCurrencyGroupsByRewardCurrency(): void
    {
        $model = new AdTubeExecutionModel($this->db);
        $executor = $this->randomId();
        $ad = $this->insertAd($this->randomId(), 'irt', '100000', '50000', '50000');

        // امروز: ۲ تکمیل‌شده با دو ارز + ۱ در حال تماشا (نباید بشمارد)
        $this->insertAdtubeView($ad, $executor, 'completed', '10.5', 'irt', true);
        $this->insertAdtubeView($ad, $executor, 'completed', '3.25', 'usdt', true);
        $this->insertAdtubeView($ad, $executor, 'watching', '99', 'usdt', true);
        // دیروز: تکمیل‌شده اما خارج از پنجرهٔ امروز (نباید بشمارد)
        $this->insertAdtubeView($ad, $executor, 'completed', '50', 'irt', false);

        $earnings = $model->getEarningsTodayByCurrency($executor);

        $this->assertIsArray($earnings);
        $this->assertArrayHasKey('irt', $earnings);
        $this->assertArrayHasKey('usdt', $earnings);
        $this->assertEqualsWithDelta(10.5, (float)$earnings['irt'], 0.0001);
        $this->assertEqualsWithDelta(3.25, (float)$earnings['usdt'], 0.0001);
        // مقدارِ رد/تماشا/دیروز در هیچ ارزی نشت نکرده
        $this->assertArrayNotHasKey('USDT', $earnings, 'کلید ارز باید کانونی (lowercase) باشد');
    }

    public function testEarningsTodayByCurrencyEmptyWhenNoCompletedToday(): void
    {
        $model = new AdTubeExecutionModel($this->db);
        $executor = $this->randomId();

        // کاربر بدون هیچ ردیفی → آرایهٔ خالی (نه ۰ تومانی که واقعی به‌نظر برسد)
        $this->assertSame([], $model->getEarningsTodayByCurrency($executor));
    }

    // ─────────── QA10: قرارداد آمار/نمایش ادمین تسک‌های اجتماعی ───────────

    /**
     * 🛡️ FIX-QA10-ADMIN-STATS-CONTRACT (جاروی QA مستقل D1–D6، ۲۰۲۶-۱۰-۲۶):
     *  ۱) getAdByIdForAdmin باید آگهی نوع legacy 'social' را هم پیدا کند —
     *     هم‌فیلتر با لیستِ getAdsForAdmin (IN ('social','social_task')) و گیتِ
     *     شروع اجرا؛ قبلاً آگهیِ موجود در لیست، در صفحهٔ جزئیات 404 می‌شد
     *     (ریپرو زنده: آگهی‌های سیدر id=1/2).
     *  ۲) getAdStatsForAdmin باید هر دو املای نوع را بشمارد و کلیدهای قرارداد
     *     ویوی index (rejected/total_budget) را برگرداند.
     *  ۳) getFullStatsForAdmin باید دقیقاً کلیدهای قرارداد ویوی stats را بسازد
     *     (total_ads/…/low_trust_users/avg_trust) — قبلاً mergeِ کلیدهای خام
     *     بود و هر ۱۰ کارت صفحهٔ آمار همیشه صفر می‌زد.
     */
    public function testAdminSocialTaskStatsAndShowContractCoversLegacySocialType(): void
    {
        $service = \app(\App\Services\SocialTask\SocialTaskService::class);

        $base = (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM ads WHERE type IN ('social','social_task') AND deleted_at IS NULL"
        );

        $legacyId = $this->insertTypedAd('social');
        $modernId = $this->insertTypedAd('social_task');

        // ۱) قرارداد show: هر دو املا پیدا می‌شوند + فیلدهای قرارداد ویو حاضرند
        foreach (['legacy social' => $legacyId, 'modern social_task' => $modernId] as $label => $adId) {
            $ad = $service->getAdByIdForAdmin($adId);
            $this->assertNotNull($ad, "getAdByIdForAdmin must find the {$label} ad — the admin list links to this page");
            $this->assertObjectHasAttribute('user_name', $ad);
            $this->assertObjectHasAttribute('user_email', $ad);
            $this->assertObjectHasAttribute('price_per_task', $ad);
            $this->assertObjectHasAttribute('total_count', $ad);
            $this->assertObjectHasAttribute('remaining_count', $ad);
        }

        // ۲) قرارداد KPIهای index
        $stats = $service->getAdStatsForAdmin();
        $this->assertSame($base + 2, $stats['total'], 'both social type spellings must be counted');
        $this->assertArrayHasKey('rejected', $stats);
        $this->assertIsInt($stats['rejected']);
        $this->assertArrayHasKey('total_budget', $stats);
        $this->assertIsFloat($stats['total_budget']);

        // ۳) قرارداد صفحهٔ stats (هر ۱۰ کارت)
        $full = $service->getFullStatsForAdmin();
        foreach ([
            'total_ads', 'active_ads', 'pending_ads',
            'total_execs', 'approved_execs', 'rejected_execs', 'flagged_execs', 'avg_score',
            'low_trust_users', 'avg_trust',
        ] as $key) {
            $this->assertArrayHasKey($key, $full, "stats.php reads \$stats->{$key}");
        }
        $this->assertIsInt($full['total_ads']);
        $this->assertIsFloat($full['avg_trust']);
    }

    private function insertTypedAd(string $type): int
    {
        $this->db->query(
            "INSERT INTO ads (user_id, title, type, platform, task_type, currency, total_budget, remaining_budget, spent_budget, total_count, remaining_count, status, created_at, updated_at)
             VALUES (?, ?, ?, 'instagram', 'follow', 'irt', 1000, 1000, 0, 5, 5, 'active', NOW(), NOW())",
            [$this->randomId(), 'qa10-contract-' . $type . '-' . bin2hex(random_bytes(3)), $type]
        );
        $id = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->track('ads', $id);
        return $id;
    }
}
