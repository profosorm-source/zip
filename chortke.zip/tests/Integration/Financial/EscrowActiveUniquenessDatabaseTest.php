<?php

declare(strict_types=1);
namespace Tests\Integration\Financial;
use PDO;
use PHPUnit\Framework\TestCase;
final class EscrowActiveUniquenessDatabaseTest extends TestCase
{
    private PDO $pdo;
    // FIX-PRE-1b: اعتبارنامهٔ کانونیکال سوئیت (root/خالی) — هم‌تراز با bootstrap/testing.php
    protected function setUp(): void { $this->pdo = new PDO('mysql:host='.(getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1').';dbname='.((getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk')),(getenv('CHORTKE_TEST_DB_USER') ?: 'root'),(getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : ''),[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]); }
    public function test_duplicate_active_order_is_rejected_but_terminal_lifecycle_can_reopen(): void
    {
        $order='rbac-escrow-test-'.bin2hex(random_bytes(5)); $type='test_order';
        $sql='INSERT INTO escrow_transactions (order_id,order_type,buyer_id,seller_id,amount,currency,status) VALUES (?,?,?,?,?,?,?)';
        try {
            $this->pdo->prepare($sql)->execute([$order,$type,1,2,'10','irt','pending']);
            try {
                $this->pdo->prepare($sql)->execute([$order,$type,1,2,'10','irt','in_escrow']);
                $this->fail('A second active escrow for the same order was accepted.');
            } catch (\PDOException $e) {
                $this->assertStringContainsString('Duplicate entry', $e->getMessage());
            }
            $this->pdo->prepare('UPDATE escrow_transactions SET status="refunded" WHERE order_id=? AND order_type=?')->execute([$order,$type]);
            $reopened = $this->pdo->prepare($sql)->execute([$order,$type,1,2,'10','irt','pending']);
            $this->assertTrue($reopened, 'A new lifecycle must be allowed after terminal refund.');
            $this->pdo->prepare('DELETE FROM escrow_transactions WHERE order_id=? AND order_type=?')->execute([$order,$type]);
        } finally { $this->pdo->prepare('DELETE FROM escrow_transactions WHERE order_id=? AND order_type=?')->execute([$order,$type]); }
    }
}
