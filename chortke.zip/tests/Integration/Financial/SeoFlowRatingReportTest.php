<?php

declare(strict_types=1);

namespace Tests\Integration\Financial;

use App\Jobs\Seo\ProcessSeoTaskAsyncJob;
use App\Jobs\Seo\RateSeoTaskJob;
use App\Jobs\Seo\ReportSeoTaskJob;
use App\Models\SeoExecution;
use App\Services\AdSystemManager;
use App\Services\Settings\AppSettings;
use Core\Container;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * @backupGlobals disabled
 * جریان کامل: click → landing → complete (rejection_code) → rate → report → توقف خودکار.
 */
final class SeoFlowRatingReportTest extends TestCase
{
    private Database $db;
    private Container $container;
    private int $advertiserId = 0;
    private int $obLevel = 0;
    private string $tag = '';

    protected function setUp(): void
    {
        parent::setUp();
        ini_set('error_log', sys_get_temp_dir() . '/chortke-seo-flow.log');
        config_set('app.key', CHORTKE_TEST_APP_KEY);
        $this->obLevel = ob_get_level();
        ob_start();
        $this->tag = bin2hex(random_bytes(5));
        $this->container = Container::getInstance();
        $this->db = $this->container->make(Database::class);
        $s = $this->container->make(AppSettings::class);
        $s->set('seo_ad_site_fee_percent', '20');
        $s->set('seo_ad_requires_admin_review', 0);
        $this->db->beginTransaction();
        $this->advertiserId = $this->user('adv', '10000000');
    }

    protected function tearDown(): void
    {
        if ($this->db->inTransaction()) {
            $this->db->rollback();
        }
        while (ob_get_level() > $this->obLevel) {
            ob_end_clean();
        }
        parent::tearDown();
    }

    private function user(string $t, string $bal = '0'): int
    {
        $this->db->query('INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["f-$t-{$this->tag}", "f-$t-{$this->tag}@example.test", 'active', 'user']);
        $id = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->db->query('INSERT INTO wallets (user_id, balance_irt, locked_irt, is_frozen) VALUES (?, ?, 0, 0)
            ON DUPLICATE KEY UPDATE balance_irt = VALUES(balance_irt)', [$id, $bal . '.0000']);
        return $id;
    }

    private function campaign(): int
    {
        $r = $this->container->make(AdSystemManager::class)->create('seo', $this->advertiserId, [
            'title' => 'Flow', 'site_url' => 'https://example.com/', 'target_url' => 'https://example.com/l',
            'keyword' => 'chortke', 'description' => 'flow', 'budget' => '50000', 'min_payout' => '1000',
            'max_payout' => '5000', 'target_duration' => 60, 'min_score' => 40, 'max_per_day' => 50, 'currency' => 'irt',
        ], 'flow-' . $this->tag . bin2hex(random_bytes(3)), 'fp-' . bin2hex(random_bytes(6)));
        return (int)$r['ad_id'];
    }

    private function exec(int $adId, int $uid): int
    {
        $this->db->query("INSERT INTO seo_executions (ad_id, user_id, status, started_at, session_id, execution_date, ip_address, created_at)
            VALUES (?, ?, 'started', DATE_SUB(NOW(), INTERVAL 90 SECOND), ?, CURDATE(), '127.0.0.1', NOW())",
            [$adId, $uid, 'fl-' . bin2hex(random_bytes(6))]);
        return (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    private const GOOD = [
        'duration' => 60, 'active_time' => 55, 'target_duration' => 60, 'scroll_depth' => 85,
        'interactions' => 6, 'scroll_speed' => 3.5, 'mouse_pattern' => 'natural', 'pause_count' => 3,
        'interaction_types' => ['external_open', 'return_to_task', 'scroll'], 'target_opened' => true,
        'focus_blur_count' => 1, 'client_mode' => 'natural',
    ];

    public function testClickLandingCompleteRateReportAutoPause(): void
    {
        $adId = $this->campaign();
        $model = $this->container->make(SeoExecution::class);
        $u = $this->user('exe');
        $id = $this->exec($adId, $u);

        $token = $model->issueClickToken($id);
        $this->assertNotNull($token);
        $this->assertTrue($model->consumeClickToken($id, $u, $token, '127.0.0.1', 'UA'), 'click stamped');
        $this->assertFalse($model->consumeClickToken($id, $u, $token, '127.0.0.1', 'UA'), 'replay rejected');
        $this->assertTrue($model->verifyLandingProof($id, $token, 'pixel'), 'landing proven');

        $res = $this->container->make(ProcessSeoTaskAsyncJob::class)->handle($id, $u, $adId, self::GOOD);
        $this->assertTrue($res['success'] ?? false, json_encode($res, JSON_UNESCAPED_UNICODE));
        $this->assertSame('completed', $this->db->fetchColumn('SELECT status FROM seo_executions WHERE id=?', [$id]));

        // rejection_code روی اجرای ناقص
        $u2 = $this->user('bad');
        $id2 = $this->exec($adId, $u2);
        $this->container->make(ProcessSeoTaskAsyncJob::class)->handle($id2, $u2, $adId, ['duration' => 1]);
        $row = $this->db->fetch('SELECT status, rejection_code FROM seo_executions WHERE id=?', [$id2]);
        $this->assertSame('rejected', (string)$row->status);
        $this->assertNotEmpty($row->rejection_code, 'rejection_code stored');

        // امتیاز: اولی ok، دومی داخل یک دقیقه → پیام صریح
        $rate = $this->container->make(RateSeoTaskJob::class);
        $r1 = $rate->handle($u, $adId, 5, 'عالی');
        $this->assertTrue($r1['success'] ?? false, json_encode($r1, JSON_UNESCAPED_UNICODE));
        $r2 = $rate->handle($u, $adId, 4, 'x');
        $this->assertFalse($r2['success'] ?? true);
        $this->assertStringContainsString('یک دقیقه', (string)$r2['message']);

        // گزارش: تکراری رد، ۵ گزارش مستقل → توقف خودکار
        $rep = $this->container->make(ReportSeoTaskJob::class);
        $a = $rep->handle($u, $adId, 'mismatch', 'd');
        $this->assertTrue($a['success'] ?? false, json_encode($a, JSON_UNESCAPED_UNICODE));
        $dup = $rep->handle($u, $adId, 'mismatch', 'd');
        $this->assertFalse($dup['success'] ?? true);
        $this->assertStringContainsString('قبلاً', (string)$dup['message']);
        $this->assertSame('active', (string)$this->db->fetchColumn('SELECT status FROM ads WHERE id=?', [$adId]));
        for ($i = 0; $i < 4; $i++) {
            $x = $this->user('rep' . $i); $this->exec($adId, $x);
            $rep->handle($x, $adId, 'mismatch', 'd');
        }
        $this->assertSame('paused', (string)$this->db->fetchColumn('SELECT status FROM ads WHERE id=?', [$adId]), 'auto-paused at threshold');
    }
}
