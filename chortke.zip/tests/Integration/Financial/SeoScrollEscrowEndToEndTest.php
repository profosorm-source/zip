<?php

declare(strict_types=1);

namespace Tests\Integration\Financial;

use App\Jobs\Seo\ProcessSeoTaskAsyncJob;
use App\Services\AdSystemManager;
use App\Services\Settings\AppSettings;
use Core\Container;
use Core\Database;
use Core\ValueObjects\Money;
use PHPUnit\Framework\TestCase;

/**
 * @backupGlobals disabled
 *
 * توجه: این فایل عمداً بدون جداسازیِ فرایند (runTestsInSeparateProcesses)
 * نوشته شده — الگوی Pkg6AnalyticsAndCurrencyRuntimeTest (فرایند اصلی +
 * beginTransaction/rollback به‌عنوان پاک‌ساز). فرزندِ جداسازی در PHPUnit
 * 8.5 نتیجهٔ تست را serialize می‌کند (Serialization of PDO not allowed) و
 * snapshot globals پیش‌فرض هم به Container/Closure سراسری می‌رسد.
 *
 * 🧪 تست انتها‌به‌انتهای اسکرو سئو — گام ③ (پاسخ اجرایی به یافتهٔ SEO-23-03
 * گزارش ماژول ۲۳ + پین رفع باگ واقعی کوپن FIX-SEO23-COUPON-READER).
 *
 * روایت کامل، روی MariaDB واقعی (chortk) با سرویس‌های واقعیِ Container:
 * ساگای واقعی AdSystemManager::create('seo') → escrow → چرخهٔ کامل اجراها
 * با ProcessSeoTaskAsyncJob::handle واقعی → مصرف تا انتهای کمپین.
 *
 * اینواریانت مرکزی (ردِ ادعای «واگرایی اسکرو/بودجه» در SEO-23-03):
 *   escrow.amount == (1 + p) × ads.remaining_budget   — در هر لحظه
 * اسکرو از ابتدا «بودجه + کارمزد» پر می‌شود (AdSystemManager::create) و دو
 * شمارنده متناسب تخلیه می‌شوند؛ گیتِ بودجه (deductFromBudget) همان گیتِ
 * اسکرو است. ادعای گزارش («partialRelease در انتهای کمپین با Release amount
 * exceeds escrow amount می‌شکند») در این تست در هر مرحله رد می‌شود: هر
 * settle موفق تا آخرین اجرای قابل‌پرداخت + توقفِ پاکیزه روی گیت بودجه.
 *
 * پین باگ کوپن (FIX-SEO23-COUPON-READER): در دو رژیم تخفیف (D≤F و D>F)،
 * ads.site_commission_percent باید دقیقاً fee_percent_eff شود — مقداری که
 * پیش‌تر فقط از کانال closure می‌رسید و کلید پیلاد
 * (coupon_site_commission_percent) خواننده نداشت.
 *
 * 🤝 آشتی با FraudGuard (بچ SEO-SCROLL-RECONCILE): درِوی که این تست پیش‌تر یک
 * کاربرِ واحد را ده‌ها اجرای پشت‌سرهمِ همان آگهی می‌داد، تحت قرارداد جدید
 * ضدتقلب «کاربر متقلب» است (تکرار روزانهٔ همان آگهی +15، سقف ساعتی +20،
 * IP رزروشده در بافت CLI +20) و گارد به‌درستی پیش از رسیدنِ درِو به گیت
 * بودجه می‌بُردش (SEO-23-03 نقض می‌شد). شبیه‌سازی صادقانه با قرارداد جدید:
 * مخاطبِ کمپین = جمعیتِ کاربران، هرکدام فقط یک اجرا — اینواریانت‌های پولی
 * (lockstep/کارمزد/اسکرو) بی‌اندکی تضعیف نمی‌شوند؛ فقط «چه کسی اجرا می‌کند»
 * واقعی می‌شود.
 */
final class SeoScrollEscrowEndToEndTest extends TestCase
{
    /** دادهٔ تعامل ثابت → امتیاز ثابت → payout ثابت در همهٔ اجراها (موتور قطعی) */
    private const ENGAGEMENT = [
        'duration' => 60,
        'active_time' => 55,
        'target_duration' => 60,
        'scroll_depth' => 85,
        'interactions' => 6,
        'scroll_speed' => 3.5,
        'mouse_pattern' => 'natural',
        'pause_count' => 3,
        'interaction_types' => ['external_open', 'return_to_task', 'scroll'],
        'target_opened' => true,
        'focus_blur_count' => 1,
        'client_mode' => 'natural',
    ];

    private const FEE_PERCENT = '20';

    private Database $db;
    private Container $container;
    private int $advertiserId = 0;
    /** @var list<int> کاربران مجریِ این درِو — هر اجرا یک کاربر تازه (قرارداد ضدتقلب) */
    private array $executorPool = [];
    private int $obLevel = 0;
    private string $tag = '';

    protected function setUp(): void
    {
        parent::setUp();
        ini_set('error_log', sys_get_temp_dir() . '/chortke-seo-e2e.log');
        config_set('app.key', CHORTKE_TEST_APP_KEY);
        $this->obLevel = ob_get_level();
        ob_start();
        $this->tag = bin2hex(random_bytes(5));

        try {
            $this->container = Container::getInstance();
            $this->db = $this->container->make(Database::class);
            $this->db->getPdo();
            $settings = $this->container->make(AppSettings::class);
            $settings->set('seo_ad_site_fee_percent', self::FEE_PERCENT);
            $settings->set('seo_ad_requires_admin_review', 0);
            // سقفِ پرداختِ تعاملِ غیرقابل‌اثبات در این تست عامدانه ۱۰۰ است —
            // موضوع تست، ریاضی اسکرو/کارمزد است، نه سیاست اعتماد به کلاینت.
            $settings->set('seo_unverified_payout_cap_percent', 100);
        } catch (\Throwable $e) {
            $this->fail('SEO E2E database is unavailable: ' . $e->getMessage());
        }

        $this->db->beginTransaction();

        $this->advertiserId = $this->insertUser('adv');
        $this->insertWallet($this->advertiserId, '10000000');
        // فلگ کوپن داخل همان تراکنش (tearDown ⇒ rollback؛ کش ۵ثانیه‌ای بی‌اثر)
        $this->db->query(
            "INSERT INTO feature_flags (name, enabled, description) VALUES ('coupons', 1, 'seo-e2e')
             ON DUPLICATE KEY UPDATE enabled = 1",
        );
    }

    protected function tearDown(): void
    {
        if (isset($this->db) && $this->db->inTransaction()) {
            $this->db->rollback();
        }
        while (ob_get_level() > $this->obLevel) {
            ob_end_clean();
        }
        parent::tearDown();
    }

    // ─────────────────────────── Scenarios ───────────────────────────

    /**
     * سناریوی ۱ — بدون کوپن (بودجهٔ ۱۰ برابرِ max_payout — همان «حداقل اقدام»
     * پیشنهادی گزارش): B=50000، F=20٪×B=10000، اسکرو=paid=B+F=60000.
     */
    public function testNoCouponCampaignEndToEndLockstep(): void
    {
        $result = $this->createCampaign([]);
        $adId = (int)$result['ad_id'];
        $escrowId = $this->escrowIdFor($adId);

        $this->assertMoneyEq('60000', (string)$result['total_amount'], 'charge total (B+F)');
        $ad = $this->fetchAd($adId);
        $this->assertMoneyEq('50000', (string)$ad->remaining_budget, 'initial remaining (no coupon)');
        $this->assertMoneyEq(self::FEE_PERCENT, (string)$ad->site_commission_percent, 'commission (adapter, no coupon)');
        $escrow = $this->fetchEscrow($escrowId);
        $this->assertMoneyEq('60000', (string)$escrow->amount, 'escrow seeded with budget + commission');
        $this->assertSame('in_escrow', (string)$escrow->status);
        $this->assertSame('seo_ad_budget', (string)$escrow->order_type);
        $this->assertSame(0, (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM coupon_redemptions WHERE entity_type = 'ads_campaign' AND entity_id = ?",
            [$adId],
        ), 'no redemption row without coupon');

        $wallet = $this->fetchWallet($this->advertiserId);
        $this->assertMoneyEq('9940000', (string)$wallet->balance_irt, 'advertiser balance after charge');
        $this->assertMoneyEq('60000', (string)$wallet->locked_irt, 'advertiser locked after charge');

        $drive = $this->driveUntilBudgetGate($adId, $escrowId, self::FEE_PERCENT, '50000', '60000');

        // پایان کمپین: گیت بودجه همان گیت اسکرو بود — نه شکستِ partialRelease
        $leftover = bcsub('50000', $drive['payouts'], 8);
        $this->assertMoneyEq(
            '50000',
            bcadd($drive['payouts'], $leftover, 8),
            'Σ payouts + leftover == B_net',
        );
        $this->assertTrue(bccomp($leftover, '0', 8) >= 0, 'leftover >= 0');
        $this->assertLockstep($adId, $escrowId, self::FEE_PERCENT, 'terminal lockstep (no coupon)');
        $this->assertMoneyEq(
            bcmul($drive['payouts'], '0.2', 4),
            $drive['fees'],
            'Σ fees == 20% × Σ payouts',
        );
        $this->assertSame('exhausted', (string)$this->fetchAd($adId)->status, 'campaign exhausted cleanly');
        $this->assertMoneyEq($drive['payouts'], $this->executorPayoutsTotal(), 'executor cohort earned Σ payouts');
        $this->assertMoneyEq(
            (string)$this->fetchEscrow($escrowId)->amount,
            (string)$this->fetchWallet($this->advertiserId)->locked_irt,
            'advertiser locked == escrow remainder',
        );
    }

    /**
     * سناریوی ۲ — کوپن، رژیم D ≤ F (تخفیف فقط از حاشیهٔ کارمزد):
     * D=5000، F=10000 ⇒ p_eff=10٪، paid=55000، B_net=50000.
     * پینِ باگ واقعی کوپن: ads.site_commission_percent باید fee_percent_eff شود.
     */
    public function testCouponPartialFeeDiscountEndToEnd(): void
    {
        $code = $this->insertCoupon('5000');
        $result = $this->createCampaign(['coupon_code' => $code]);
        $adId = (int)$result['ad_id'];
        $escrowId = $this->escrowIdFor($adId);

        $this->assertMoneyEq('55000', (string)$result['total_amount'], 'paid (B+F−D)');
        $ad = $this->fetchAd($adId);
        $this->assertMoneyEq('50000', (string)$ad->remaining_budget, 'B_net on ads row');
        // ═══ پینِ باگ واقعی کوپن (FIX-SEO23-COUPON-READER) ═══
        $this->assertMoneyEq(
            '10.00',
            (string)$ad->site_commission_percent,
            'ads.site_commission_percent == fee_percent_eff (coupon override landed)',
        );
        $this->assertSame(1, (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM coupon_redemptions WHERE entity_type = 'ads_campaign' AND entity_id = ?",
            [$adId],
        ), 'redemption row recorded');
        $meta = json_decode((string)$ad->metadata, true);
        $this->assertIsArray($meta['coupon'] ?? null, 'ads.metadata.coupon present');
        $this->assertMoneyEq('55000', (string)($meta['coupon']['paid_amount'] ?? ''), 'metadata paid');
        $this->assertMoneyEq('5000', (string)($meta['coupon']['fee_discount'] ?? ''), 'metadata fee_discount');
        $escrow = $this->fetchEscrow($escrowId);
        $this->assertMoneyEq('55000', (string)$escrow->amount, 'escrow == paid (D≤F)');
        $wallet = $this->fetchWallet($this->advertiserId);
        $this->assertMoneyEq('9945000', (string)$wallet->balance_irt, 'advertiser balance after charge (coupon)');
        $this->assertMoneyEq('55000', (string)$wallet->locked_irt, 'advertiser locked after charge (coupon)');

        $drive = $this->driveUntilBudgetGate($adId, $escrowId, '10.00', '50000', '55000');

        $leftover = bcsub('50000', $drive['payouts'], 8);
        $this->assertMoneyEq(
            '50000',
            bcadd($drive['payouts'], $leftover, 8),
            'Σ payouts + leftover == B_net (coupon D≤F)',
        );
        $this->assertLockstep($adId, $escrowId, '10.00', 'terminal lockstep (coupon D≤F)');
        $this->assertMoneyEq($drive['payouts'], $this->executorPayoutsTotal(), 'executor cohort earned Σ payouts (coupon D≤F)');
        $this->assertMoneyEq(
            bcmul($drive['payouts'], '0.1', 4),
            $drive['fees'],
            'Σ fees == 10% (p_eff) × Σ payouts — نه 20٪ تنظیمات',
        );
        $this->assertSame('exhausted', (string)$this->fetchAd($adId)->status, 'campaign exhausted cleanly (D≤F)');
    }

    /**
     * سناریوی ۳ — کوپن، رژیم D > F (تخفیف کارمزد را کامل می‌خورد + بخشی از بودجه):
     * D=50000، F=10000 ⇒ p_eff=0٪، paid=B_net=10000.
     * کارمزد سایت صفر ⇒ burn نداریم؛ اسکرو فقط با payoutها تخلیه می‌شود.
     */
    public function testCouponOverFeeDiscountEndToEnd(): void
    {
        $code = $this->insertCoupon('50000');
        $result = $this->createCampaign(['coupon_code' => $code]);
        $adId = (int)$result['ad_id'];
        $escrowId = $this->escrowIdFor($adId);

        $this->assertMoneyEq('10000', (string)$result['total_amount'], 'paid (D>F regime)');
        $ad = $this->fetchAd($adId);
        $this->assertMoneyEq('10000', (string)$ad->remaining_budget, 'B_net == paid (D>F)');
        // ═══ پینِ باگ واقعی کوپن — رژیم صفر ═══
        $this->assertMoneyEq(
            '0',
            (string)$ad->site_commission_percent,
            'commission == 0 (fee fully eaten by discount)',
        );
        $meta = json_decode((string)$ad->metadata, true);
        $this->assertMoneyEq('40000', (string)($meta['coupon']['budget_discount'] ?? ''), 'budget_discount (D>F)');
        $this->assertMoneyEq('10000', (string)$this->fetchEscrow($escrowId)->amount, 'escrow == paid (D>F)');

        $drive = $this->driveUntilBudgetGate($adId, $escrowId, '0', '10000', '10000');

        $leftover = bcsub('10000', $drive['payouts'], 8);
        $this->assertMoneyEq(
            '10000',
            bcadd($drive['payouts'], $leftover, 8),
            'Σ payouts + leftover == B_net (D>F)',
        );
        $this->assertMoneyEq('0', $drive['fees'], 'zero fee burn (p_eff == 0)');
        // با p_eff=0 اینواریانت ساده می‌شود: escrow == remaining دقیقاً
        $this->assertMoneyEq(
            $leftover,
            (string)$this->fetchEscrow($escrowId)->amount,
            'escrow remainder == leftover budget (zero-commission lockstep)',
        );
        $this->assertMoneyEq($drive['payouts'], $this->executorPayoutsTotal(), 'executor cohort earned Σ payouts (D>F)');
        $this->assertSame('exhausted', (string)$this->fetchAd($adId)->status, 'campaign exhausted cleanly (D>F)');
        // کیفِ قفل‌شدهٔ تبلیغ‌دهنده آینهٔ اسکرو است — تا آخرین ریال
        $this->assertMoneyEq(
            (string)$this->fetchEscrow($escrowId)->amount,
            (string)$this->fetchWallet($this->advertiserId)->locked_irt,
            'advertiser locked == escrow remainder (D>F)',
        );
    }

    // ─────────────────────────── Driver ───────────────────────────

    /**
     * چرخهٔ اجراها با جابِ واقعی تا لحظهٔ توقفِ گیتِ بودجه.
     * هر settle موفق باید کامل بماند (کارمزد burn + release) — اگر زنجیرهٔ
     * تسویه وسط راه بشکند (ادعای گزارش)، fail صریح می‌گیریم.
     *
     * @return array{payouts: string, fees: string, count: int, last_payout: string, stop_message: string}
     */
    private function driveUntilBudgetGate(int $adId, int $escrowId, string $feePercent, string $bNet, string $paid): array
    {
        $job = $this->container->make(ProcessSeoTaskAsyncJob::class);
        $payouts = '0';
        $fees = '0';
        $count = 0;
        $lastPayout = '0';
        $guard = 0;

        while (true) {
            if (++$guard > 40) {
                $this->fail('driver did not terminate within 40 iterations');
            }
            $executorId = $this->newExecutor();
            $executionId = $this->insertExecution($adId, $executorId);
            $res = $job->handle($executionId, $executorId, $adId, self::ENGAGEMENT);

            if (($res['success'] ?? false) === true) {
                $payout = str_value($res['payout'] ?? '');
                $this->assertNotSame('', $payout, 'job returned empty payout');
                if ($count > 0) {
                    $this->assertMoneyEq(
                        $lastPayout,
                        $payout,
                        'payout determinism (same engagement ⇒ same payout)',
                    );
                }
                $fee = bccomp($feePercent, '0', 8) > 0
                    ? Money::fromString($payout, 'irt')->percentage($feePercent)->getAmount()
                    : '0';
                $payouts = bcadd($payouts, $payout, 8);
                $fees = bcadd($fees, $fee, 8);
                $lastPayout = $payout;
                $count++;
                // اینواریانت مرکزی — بعد از هر settle
                $this->assertLockstep($adId, $escrowId, $feePercent, "lockstep after settle #{$count}");
                // پوشش اسکرو برای «پرداخت بعدیِ مجاز» — همان‌جایی که گزارش شکست می‌دانست
                $factor = bcadd('1', bcdiv($feePercent, '100', 8), 8);
                $remaining = (string)$this->fetchAd($adId)->remaining_budget;
                if (bccomp($remaining, $lastPayout, 8) >= 0) {
                    $needed = bcmul($factor, $lastPayout, 8);
                    $escrowAmount = (string)$this->fetchEscrow($escrowId)->amount;
                    $this->assertTrue(
                        bccomp($escrowAmount, $needed, 8) >= 0,
                        "escrow must cover the next permitted payout: escrow={$escrowAmount} needed={$needed}",
                    );
                }
                continue;
            }

            // توقف باید «پیش از زنجیرهٔ پول» و پاکیزه باشد — نه شکستِ وسط settle
            $message = str_value($res['message'] ?? '');
            $cleanStop = str_contains($message, 'بودجه آگهی کافی نیست')
                || str_contains($message, 'آگهی فعال یافت نشد');
            $this->assertTrue(
                $cleanStop,
                "settlement broke mid-flow (refutation of SEO-23-03 violated): {$message}",
            );
            $this->assertGreaterThan(0, $count, 'at least one successful settle before stop');
            return [
                'payouts' => $payouts,
                'fees' => $fees,
                'count' => $count,
                'last_payout' => $lastPayout,
                'stop_message' => $message,
            ];
        }
    }

    /** escrow.amount ≈ (1 + p/100) × ads.remaining_budget — در هر لحظه */
    private function assertLockstep(int $adId, int $escrowId, string $feePercent, string $label): void
    {
        $factor = bcadd('1', bcdiv($feePercent, '100', 8), 8);
        $remaining = (string)$this->fetchAd($adId)->remaining_budget;
        $expected = bcmul($factor, $remaining, 8);
        $this->assertMoneyEq($expected, (string)$this->fetchEscrow($escrowId)->amount, "lockstep [{$label}]");
        // حسابدگی کل: paid − Σ(settle) == اسکرو باقی‌مانده
        $escrow = $this->fetchEscrow($escrowId);
        $this->assertTrue(bccomp((string)$escrow->amount, '0', 8) >= 0, "escrow never negative [{$label}]");
    }

    // ─────────────────────────── Fixtures ───────────────────────────

    /** @param array<string, mixed> $overrides */
    private function createCampaign(array $overrides): array
    {
        $manager = $this->container->make(AdSystemManager::class);
        $payload = array_merge([
            'title' => 'E2E SEO campaign',
            'site_url' => 'https://example.com/',
            'target_url' => 'https://example.com/landing',
            'keyword' => 'chortke',
            'description' => 'end-to-end escrow test',
            'budget' => '50000',
            'min_payout' => '1000',
            'max_payout' => '5000',
            'target_duration' => 60,
            'min_score' => 40,
            'max_per_day' => 50,
            'currency' => 'irt',
        ], $overrides);
        $result = $manager->create(
            'seo',
            $this->advertiserId,
            $payload,
            'e2e-seo-' . $this->tag . '-' . bin2hex(random_bytes(4)),
            'fp-' . bin2hex(random_bytes(8)),
        );
        $this->assertIsArray($result);
        $this->assertArrayHasKey('ad_id', $result);
        $this->assertGreaterThan(0, (int)$result['ad_id'], 'saga returned ad_id');
        $this->assertArrayHasKey('escrow_id', $result);
        $this->assertGreaterThan(0, (int)$result['escrow_id'], 'saga returned escrow_id');
        return $result;
    }

    private function insertUser(string $tag): int
    {
        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["e2e-{$tag}-{$this->tag}", "e2e-{$tag}-{$this->tag}@example.test", 'active', 'user'],
        );
        return (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    private function insertWallet(int $userId, string $balance): void
    {
        $this->db->query(
            'INSERT INTO wallets (user_id, balance_irt, locked_irt, is_frozen)
             VALUES (?, ?, 0, 0)
             ON DUPLICATE KEY UPDATE balance_irt = VALUES(balance_irt), locked_irt = 0, is_frozen = 0',
            [$userId, $balance . '.0000'],
        );
    }

    /**
     * مخاطبِ واقعیِ کمپین: هر اجرا یک کاربرِ تازه (بچ SEO-SCROLL-RECONCILE).
     * کاربر واحدِ ده‌ها-اجرا در همان روز/ساعت، تحت قرارداد جدید ضدتقلب
     * «متقلب» است و گارد درست می‌بُردش — پیش از گیت بودجه. کاربر تازه در هر
     * اجرا ⇒ تکرار روزانه/سقف ساعتی هرگز نقض نمی‌شود؛ موضوعِ تست (ریاضی
     * اسکرو/کارمزد) از این کانال بی‌تغییر می‌ماند.
     */
    private function newExecutor(): int
    {
        $id = $this->insertUser('exe' . \count($this->executorPool));
        $this->insertWallet($id, '0');
        $this->executorPool[] = $id;
        return $id;
    }

    /** Σ balance کاربران مجری — «دریافتیِ مخاطب کمپین» */
    private function executorPayoutsTotal(): string
    {
        if ($this->executorPool === []) {
            return '0';
        }
        $ids = implode(',', array_map('intval', $this->executorPool));
        return (string)$this->db->fetchColumn(
            "SELECT COALESCE(SUM(balance_irt), 0) FROM wallets WHERE user_id IN ({$ids})",
        );
    }

    /** کوپنِ مبلغ‌ثابت هم‌ارز irt برای ads_campaign */
    private function insertCoupon(string $value): string
    {
        $code = 'E2E' . strtoupper($this->tag);
        $this->db->query(
            "INSERT INTO coupons
             (code, type, value, currency, applicable_to, usage_limit, usage_count,
              min_purchase, min_amount, max_discount, is_active, expires_at)
             VALUES (?, 'fixed', ?, 'irt', 'ads_campaign', 10, 0, 0, 0, 0, 1, DATE_ADD(NOW(), INTERVAL 1 DAY))",
            [$code, $value],
        );
        return $code;
    }

    private function insertExecution(int $adId, int $userId): int
    {
        $this->db->query(
            "INSERT INTO seo_executions (ad_id, user_id, status, started_at, session_id, execution_date, ip_address, created_at)
             VALUES (?, ?, 'started', DATE_SUB(NOW(), INTERVAL 90 SECOND), ?, CURDATE(), '127.0.0.1', NOW())",
            [$adId, $userId, 'e2e-sess-' . bin2hex(random_bytes(6))],
        );
        return (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    // ─────────────────────────── Accessors ───────────────────────────

    private function escrowIdFor(int $adId): int
    {
        $id = $this->db->fetchColumn(
            'SELECT id FROM escrow_transactions WHERE order_type = ? AND order_id = ? LIMIT 1',
            ['seo_ad_budget', $adId],
        );
        $this->assertGreaterThan(0, (int)$id, 'escrow row bound to ad');
        return (int)$id;
    }

    private function fetchAd(int $adId): \stdClass
    {
        $ad = $this->db->fetch(
            'SELECT remaining_budget, total_budget, site_commission_percent, status, metadata FROM ads WHERE id = ?',
            [$adId],
        );
        $this->assertNotNull($ad, 'ads row exists');
        return $ad;
    }

    private function fetchEscrow(int $escrowId): \stdClass
    {
        $escrow = $this->db->fetch(
            'SELECT amount, status, order_type, partial_released FROM escrow_transactions WHERE id = ?',
            [$escrowId],
        );
        $this->assertNotNull($escrow, 'escrow row exists');
        return $escrow;
    }

    private function fetchWallet(int $userId): \stdClass
    {
        $wallet = $this->db->fetch('SELECT balance_irt, locked_irt FROM wallets WHERE user_id = ?', [$userId]);
        $this->assertNotNull($wallet, 'wallet row exists');
        return $wallet;
    }

    // ─────────────────────────── Assertions ───────────────────────────

    private function assertMoneyEq(string $expected, string $actual, string $label): void
    {
        $this->assertTrue(
            is_numeric($actual),
            "{$label}: actual is not numeric (" . var_export($actual, true) . ')',
        );
        $diff = bcsub((string)$expected, (string)$actual, 8);
        if (bccomp($diff, '0', 8) < 0) {
            $diff = bcmul($diff, '-1', 8);
        }
        $this->assertTrue(
            bccomp($diff, '0.01', 8) <= 0,
            "{$label}: expected {$expected}, actual {$actual} (diff {$diff})",
        );
    }
}
