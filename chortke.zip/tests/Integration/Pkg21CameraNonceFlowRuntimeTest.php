<?php

declare(strict_types=1);

namespace Tests\Integration;

use App\Models\SocialTaskExecutionModel;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * FIX-F21-01 (بازبینی بخش ۲۱ — گزینهٔ C ترکیبی) + FIX-F21-01-R2 (تصمیم D2
 * مالک): تست runtime جریان nonce یک‌بارمصرف دوربین روی DB واقعی.
 *
 * 🛡️ FIX-F21-01-P1 (فاز ۱ — خودساز-داده): تست دیگر به رکوردهای seed ثابت
 * (اجراهای ۲۴–۲۹) وابسته نیست — صبرِ ساکت و skipِ تصادفی روی محیط‌های
 * بدون seed، پوشش را نامطمئن می‌کرد. اکنون خودش کاربران متمایز + تسک
 * اجتماعی + شش اجرا را می‌سازد و در teardown «همهٔ» ردیف‌ها را پاک می‌کند؛
 * هیچ ردی در DB نمی‌ماند و اجرای سوئیت همیشه قطعی است.
 *
 * تغییر قرارداد D2: nonce فقط به‌صورت هش SHA-256 ذخیره می‌شود (ستون
 * nonce_hash) و مقدار خام هرگز در DB نیست؛ retry = رکورد جدید.
 *
 * پوشش سناریوها (معیار بستن F21-01 در گزارش بازبینی):
 *  - صدور چالش → هش nonce به user/execution مقید است و خامِ آن ذخیره نمی‌شود
 *  - مصرف موفق → replay همان nonce = رد (rowCount=0)
 *  - nonce با کاربر دیگر = رد
 *  - nonce منقضی = رد
 *  - retry = رکورد جدید: چالش تازه رکوردهای pending قبلی را منقضی می‌کند
 *  - گیت حکم: رکورد بدون server_verdict='pass' contribution صفر می‌گیرد
 *    (effectiveCameraContribution — fail-closed حتی برای رکورد قدیمی completed)
 */
final class Pkg21CameraNonceFlowRuntimeTest extends TestCase
{
    private Database $db;
    private SocialTaskExecutionModel $model;
    /** @var list<int> رکوردهای ساخته‌شده برای پاکسازی (ترتیب: camera_requests → executions → ads → users) */
    private array $createdRequestIds = [];
    private array $createdExecutionIds = [];
    private array $createdAdIds = [];
    private array $createdUserIds = [];

    /** اجراهای خودساختهٔ تست — نقش A..F (مالک هر کدام در setUp تعیین می‌شود) */
    private int $execA = 0;
    private int $execB = 0;
    private int $execC = 0;
    private int $execD = 0;
    private int $execE = 0;
    private int $execF = 0;

    private int $userA = 0;
    private int $userB = 0;

    protected function setUp(): void
    {
        $this->db = Database::getInstance();
        $this->model = new SocialTaskExecutionModel($this->db);

        // ── دادهٔ خودساخته: دو کاربر متمایز + یک تسک اجتماعی + شش اجرا ──
        $suffix = bin2hex(random_bytes(4));
        $this->userA = $this->createTestUser("pkg21-{$suffix}-a@camera-flow.test");
        $this->userB = $this->createTestUser("pkg21-{$suffix}-b@camera-flow.test");
        $this->assertNotSame($this->userA, $this->userB, 'دو کاربر متمایز برای تست nonce لازم است');

        $adId = $this->createTestAd($this->userA, "pkg21-camera-flow-test-{$suffix}");
        $this->execA = $this->createTestExecution($adId, $this->userA);
        $this->execB = $this->createTestExecution($adId, $this->userB);
        $this->execC = $this->createTestExecution($adId, $this->userA);
        $this->execD = $this->createTestExecution($adId, $this->userA);
        $this->execE = $this->createTestExecution($adId, $this->userA);
        $this->execF = $this->createTestExecution($adId, $this->userB);
    }

    protected function tearDown(): void
    {
        // پاکسازی کامل و معکوسِ وابستگی‌ها — هیچ ردی در DB نمی‌ماند.
        if (!empty($this->createdRequestIds)) {
            $ph = implode(',', array_fill(0, count($this->createdRequestIds), '?'));
            $this->db->query("DELETE FROM social_camera_requests WHERE id IN ({$ph})", $this->createdRequestIds);
            $this->createdRequestIds = [];
        }
        if (!empty($this->createdExecutionIds)) {
            $ph = implode(',', array_fill(0, count($this->createdExecutionIds), '?'));
            $this->db->query("DELETE FROM social_task_executions WHERE id IN ({$ph})", $this->createdExecutionIds);
            $this->createdExecutionIds = [];
        }
        foreach ($this->createdAdIds as $adId) {
            $this->db->query("DELETE FROM ads WHERE id = ?", [$adId]);
        }
        $this->createdAdIds = [];
        foreach ($this->createdUserIds as $userId) {
            $this->db->query("DELETE FROM wallets WHERE user_id = ?", [$userId]);
            $this->db->query("DELETE FROM users WHERE id = ?", [$userId]);
        }
        $this->createdUserIds = [];
    }

    private function createTestUser(string $email): int
    {
        $this->db->query(
            "INSERT INTO users (email, status, created_at, updated_at) VALUES (?, 'active', NOW(), NOW())",
            [$email]
        );
        $id = (int) $this->db->lastInsertId();
        $this->createdUserIds[] = $id;
        return $id;
    }

    private function createTestAd(int $creatorId, string $title): int
    {
        $this->db->query(
            "INSERT INTO ads (user_id, title, description, type, platform, task_type, target_url,
                price_per_task, total_budget, remaining_budget, spent_budget, total_count, remaining_count,
                pending_count, completed_count, clicks_count, status, created_at, updated_at)
             VALUES (?, ?, 'تست runtime جریان nonce دوربین', 'social', 'instagram', 'follow', 'https://example.test/pkg21',
                1000.0, 100000.0, 100000.0, 0, 100, 100, 0, 0, 0, 'active', NOW(), NOW())",
            [$creatorId, $title]
        );
        $id = (int) $this->db->lastInsertId();
        $this->createdAdIds[] = $id;
        return $id;
    }

    private function createTestExecution(int $adId, int $executorId): int
    {
        $this->db->query(
            "INSERT INTO social_task_executions (ad_id, executor_id, status, started_at, created_at, updated_at)
             VALUES (?, ?, 'in_progress', NOW(), NOW(), NOW())",
            [$adId, $executorId]
        );
        $id = (int) $this->db->lastInsertId();
        $this->createdExecutionIds[] = $id;
        return $id;
    }

    private function createRequest(int $executionId, int $userId, int $ttlSeconds = 120, ?string $rawNonce = null, bool $spotConsent = false, string $spotIndices = ''): int
    {
        $rawNonce = $rawNonce ?? bin2hex(random_bytes(32));
        // 🛡️ D2: مدل فقط هش را می‌گیرد — مقدار خام هرگز به DB نمی‌رود
        $id = $this->model->createCameraRequest([
            'execution_id'  => $executionId,
            'user_id'       => $userId,
            'method'        => 'mobile_camera',
            'expiry'        => $ttlSeconds,
            'client_context' => ['test' => true],
            'nonce_hash'    => hash('sha256', $rawNonce),
            'spot_consent'  => $spotConsent,
            'spot_indices'  => $spotIndices,
        ]);
        $this->createdRequestIds[] = $id;
        return $id;
    }

    private function consume(string $rawNonce, int $userId, int $executionId, int $score = 85, string $verdict = 'pass'): bool
    {
        return $this->model->consumeCameraNonce(
            hash('sha256', $rawNonce),
            $userId,
            $executionId,
            $score,
            '["frame_count_ok","timing_natural"]',
            4,
            '{"frames":[]}',
            null,
            $verdict,
            '{"analysis":{}}',
            null
        );
    }

    public function testNonceHashBindsToUserAndExecutionAndIsSingleUse(): void
    {
        $nonce = bin2hex(random_bytes(32));
        $id = $this->createRequest($this->execA, $this->userA, 120, $nonce);

        // 🛡️ D2: مقدار خام در رکورد وجود ندارد؛ فقط هشِ درست
        $row = $this->db->fetch("SELECT * FROM social_camera_requests WHERE id = ?", [$id]);
        $this->assertSame(hash('sha256', $nonce), (string) $row->nonce_hash, 'هش ذخیره‌شده باید sha256(nonce) باشد');
        $this->assertFalse(property_exists($row, 'nonce'), 'ستون nonce خام باید حذف شده باشد');

        // مصرف با execution نامرتبط → رد (توکن چالش به همان execution مقید است)
        $this->assertFalse(
            $this->consume($nonce, $this->userA, $this->execB),
            'nonce اجرای A با execution_id اجرای B باید رد شود'
        );

        // مصرف اولیه موفق (همان execution)
        $this->assertTrue($this->consume($nonce, $this->userA, $this->execA), 'مصرف اولیه باید موفق باشد');

        // replay: همان nonce، همان کاربر، همان اجرا → رد
        $this->assertFalse($this->consume($nonce, $this->userA, $this->execA), 'replay همان nonce باید رد شود');

        // مصرف با کاربر دیگر (حتی پیش از مصرف اولیه هم باید رد می‌شد — اینجا پس از مصرف)
        $this->assertFalse($this->consume($nonce, $this->userB, $this->execA), 'nonce کاربر دیگر باید رد شود');

        // رکورد دقیقاً یک‌بار completed شده است
        $row = $this->db->fetch(
            "SELECT status, nonce_consumed_at, server_verdict, server_score FROM social_camera_requests WHERE nonce_hash = ?",
            [hash('sha256', $nonce)]
        );
        $this->assertSame('completed', (string) $row->status);
        $this->assertNotNull($row->nonce_consumed_at);
        $this->assertSame('pass', (string) $row->server_verdict);
        $this->assertSame(85, (int) $row->server_score);
    }

    public function testExpiredNonceIsRejected(): void
    {
        $nonce = bin2hex(random_bytes(32));
        $this->createRequest($this->execC, $this->userA, 1, $nonce);
        // TTL=1 ثانیه — صبر کوتاه برای انقضا
        sleep(2);

        $this->assertFalse($this->consume($nonce, $this->userA, $this->execC), 'nonce منقضی باید رد شود');

        $row = $this->db->fetch("SELECT status FROM social_camera_requests WHERE nonce_hash = ?", [hash('sha256', $nonce)]);
        $this->assertSame('pending', (string) $row->status, 'رکورد منقضی completed نمی‌شود');
    }

    public function testWrongUserNonceIsRejectedEvenBeforeFirstUse(): void
    {
        $nonce = bin2hex(random_bytes(32));
        $this->createRequest($this->execD, $this->userA, 120, $nonce);

        $this->assertFalse($this->consume($nonce, $this->userB, $this->execD), 'nonce متعلق به userA برای userB رد می‌شود');

        // پس از ردِ کاربر اشتباه، مالک واقعی همچنان می‌تواند مصرف کند (single-use سالم)
        $this->assertTrue($this->consume($nonce, $this->userA, $this->execD));
    }

    public function testNewChallengeExpiresPreviousPendingRecords(): void
    {
        // 🛡️ D2: retry = رکورد جدید — رکوردهای pending قبلیِ همان user/execution
        // با expirePendingCameraRequestsForUser منقضی می‌شوند (فقط آخرین زنده است)
        $oldNonce = bin2hex(random_bytes(32));
        $oldId = $this->createRequest($this->execE, $this->userA, 120, $oldNonce);
        $newNonce = bin2hex(random_bytes(32));
        $newId = $this->createRequest($this->execE, $this->userA, 120, $newNonce);

        $expired = $this->model->expirePendingCameraRequestsForUser($this->execE, $this->userA, $newId);
        $this->assertGreaterThanOrEqual(1, $expired, 'رکورد قدیمی باید در شمار منقضی‌شده‌ها باشد');

        $this->assertFalse($this->consume($oldNonce, $this->userA, $this->execE), 'nonce رکورد منقضی‌شده باید رد شود');
        $this->assertTrue($this->consume($newNonce, $this->userA, $this->execE), 'nonce رکورد زنده باید مصرف شود');

        $old = $this->db->fetch("SELECT status FROM social_camera_requests WHERE id = ?", [$oldId]);
        $this->assertSame('expired', (string) $old->status);
    }

    /**
     * 🛡️ FIX-IDEM-COLLISION (بازبینی W1-REV #1 — HIGH) + W1-CHK #3: رکوردهای
     * «نشانگر» بدون nonce باید NULL بگیرند (نه '') — دو نشانگر متوالی در جدول
     * بدون Duplicate entry روی uq_scr_nonce_hash ساخته می‌شوند.
     */
    public function testMarkerRecordsWithoutNonceGetNullHashAndNeverCollide(): void
    {
        // نشانگرِ camera_requiredِ Job: بدون nonce_hash (مسیر مستقیم مدل)
        $id1 = $this->model->createCameraRequest([
            'execution_id' => $this->execA, 'user_id' => $this->userA,
            'method' => 'mobile_camera', 'expiry' => 120, 'client_context' => ['test' => true],
        ]);
        $this->createdRequestIds[] = $id1;
        $id2 = $this->model->createCameraRequest([
            'execution_id' => $this->execC, 'user_id' => $this->userB,
            'method' => 'mobile_camera', 'expiry' => 120, 'client_context' => ['test' => true],
        ]);
        $this->createdRequestIds[] = $id2;

        $r1 = $this->db->fetch("SELECT nonce_hash FROM social_camera_requests WHERE id = ?", [$id1]);
        $r2 = $this->db->fetch("SELECT nonce_hash FROM social_camera_requests WHERE id = ?", [$id2]);
        $this->assertNull($r1->nonce_hash, 'نشانگر اول باید nonce_hash=NULL بگیرد');
        $this->assertNull($r2->nonce_hash, 'نشانگر دوم باید nonce_hash=NULL بگیرد');
        $this->assertNotSame($id1, $id2, 'هر دو نشانگر باید بدون برخورد UNIQUE ساخته شده باشند');
    }

    public function testContributionGateRequiresServerVerdictPass(): void
    {
        // رکورد بدون حکم (completedِ قدیمی/سایر مسیر) → contribution صفر
        $legacyNonce = bin2hex(random_bytes(32));
        $legacyId = $this->createRequest($this->execE, $this->userA, 120, $legacyNonce);
        $this->db->query(
            "UPDATE social_camera_requests SET status='completed', camera_score=90, frame_count=4, server_verdict=NULL, completed_at=NOW() WHERE id=?",
            [$legacyId]
        );
        $this->assertSame(0.0, $this->fullService()->effectiveCameraContribution($this->execE, 90), 'رکوردِ بدون حکم = صفر');

        // حکم weak → صفر
        $weakNonce = bin2hex(random_bytes(32));
        $this->createRequest($this->execF, $this->userA, 120, $weakNonce);
        $this->consume($weakNonce, $this->userA, $this->execF, 60, 'weak');
        $this->assertSame(0.0, $this->fullService()->effectiveCameraContribution($this->execF, 60), 'حکم weak = صفر');

        // حکم pass + فریم → contribution مثبت (سقف‌خورده)
        $passNonce = bin2hex(random_bytes(32));
        $this->createRequest($this->execB, $this->userB, 120, $passNonce);
        $this->consume($passNonce, $this->userB, $this->execB, 85, 'pass');
        $contribution = $this->fullService()->effectiveCameraContribution($this->execB, 85);
        $this->assertGreaterThan(0.0, $contribution, 'حکم pass با فریم = contribution مثبت');
        $this->assertLessThanOrEqual(15.0, $contribution, 'سقف contribution (cap=15) رعایت می‌شود');

        // 🛡️ FIX-F21-01-P1 (فاز ۱ — گیت proof زنده): hasTrustedVerdict با حکم pass=true و
        // بدون حکم/حکم weak=false — همان قرارداد گیتِ خط ۲۱۲ Job.
        // (بازبینی ۲۰۲۶-۱۰-۲۶: نام متد با قرارداد فعلی سرویس هم‌گام شد — hasProof قدیمی)
        $this->assertTrue($this->fullService()->hasTrustedVerdict($this->execB), 'حکم pass + nonce مصرف‌شده + فریم = hasTrustedVerdict واقعی');
        $this->assertFalse($this->fullService()->hasTrustedVerdict($this->execE), 'رکورد بدون حکم = hasTrustedVerdict نادرست (سرویس واقعی)');
        $this->assertFalse($this->fullService()->hasTrustedVerdict($this->execF), 'حکم weak = hasTrustedVerdict نادرست (سرویس واقعی)');
    }

    /**
     * 🛡️ FIX-F21-01-P1 (بازبینی W1-REV #10): گیت با «سرویس واقعی» سنجیده می‌شود
     * (نه شبیه‌سازی محلی) — تا معناشناسی «آخرین رکورد برنده است» (ORDER BY id DESC)
     * و همان پنج شرط verifiedRecord روی DB واقعی پین بماند.
     */
    private function fullService(): \App\Services\SocialTask\CameraVerificationService
    {
        $settings = \Mockery::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('get')->andReturnUsing(
            static fn (string $key, mixed $default = null): mixed => $default
        );
        $scoring = new \App\Services\SocialTask\SocialTaskScoringService($settings);
        // قرارداد فعلی سازنده: (logger, model, behavior, scoring, settings, ?playIntegrity, ?analysis)
        // (بازبینی ۲۰۲۶-۱۰-۲۶: ترتیب قدیمیِ (…, analysis, scoring, settings) با امضای فعلی هم‌گام شد)
        return new \App\Services\SocialTask\CameraVerificationService(
            \Mockery::mock(\App\Contracts\LoggerInterface::class),
            $this->model,
            new \App\Services\SocialTask\BehaviorAnalysisService($scoring, $settings),
            $scoring,
            $settings,
            null,
            new \App\Services\SocialTask\CaptureAnalysisService()
        );
    }

    /**
     * 🎯 D5 (تصمیم مالک ۲۰۲۶-۱۰-۲۶ — «الان کلید گوگل ندارم»): حالت mock باید
     * بدون هیچ کلید گوگلی مسیر attestation را واقعاً قابل اجرا کند و همان
     * منطق مقیدسازی مسیر واقعی را طی کند (توکن به چالش گره خورده)، و در
     * production/خاموش هرگز فعال نشود. تنظیم روی DB واقعی + پاک‌شدن کش
     * تنظیمات (singleton AppSettings) و بازگردانی در finally.
     */
    public function testPlayIntegrityMockBindsTokenToChallengeWithoutGoogleKey(): void
    {
        // 🛡️ FIX-F2 (بازبینی D1–D6، ۲۰۲۶-۱۰-۲۶): شاخه‌های mismatch/alien سرویس واقعاً
        // logger->warning می‌زنند؛ FallbackLogger پیش‌فرض در CLI خروجی echo دارد و با
        // beStrictAboutOutputDuringTests تست risky → failOnRisky کل سوئیت را می‌اندازد.
        // هم‌الگوی ModelColumnGuardRuntimeTest:156 — خروجی کنسولی لاگر در تست بلعیده می‌شود.
        $this->setOutputCallback(static function (): void {});

        $pi = new \App\Services\SocialTask\PlayIntegrityService();
        $settingsSvc = \app(\App\Services\Settings\AppSettings::class);

        $savedRow = $this->db->fetch("SELECT `value` FROM system_settings WHERE `key` = 'play_integrity_mock'");
        $hadRow = $savedRow !== null;
        $savedValue = $hadRow ? (string) $savedRow->value : null;

        try {
            // ── mock خاموش (پیش‌فرض): بدون کلید گوگل = disabled ──
            $this->db->query(
                "INSERT INTO system_settings (`key`,`value`,`group`,type,is_public,created_at,updated_at)
                 VALUES ('play_integrity_mock','0','task','boolean',0,NOW(),NOW())
                 ON DUPLICATE KEY UPDATE `value`='0', updated_at=NOW()"
            );
            $settingsSvc->clearCache();
            $this->assertFalse($pi->isMockEnabled(), 'سوییچ خاموش: isMockEnabled=false');
            $off = $pi->verify('mock-integrity.' . hash('sha256', 'n'), 'n');
            $this->assertSame('disabled', $off['status'], 'بدون کلید و بدون mock = disabled (رفتار پیش‌فرض، بدون فراخوانی گوگل)');

            // ── mock روشن: توکن مقید درست = verified (از مسیر منطق واقعی) ──
            $this->db->query("UPDATE system_settings SET `value`='1', updated_at=NOW() WHERE `key`='play_integrity_mock'");
            $settingsSvc->clearCache();
            $this->assertTrue($pi->isMockEnabled(), 'APP_ENV=testing + سوییچ روشن = mock فعال');

            $nonce = bin2hex(random_bytes(16));
            $good = $pi->verify('mock-integrity.' . hash('sha256', $nonce), $nonce);
            $this->assertSame('verified', $good['status'], 'توکن mock مقید به nonce چالش = verified');
            $this->assertTrue((bool) $good['request_hash_match'], 'requestHash = sha256(nonce) تایید شد');
            $this->assertContains('MEETS_DEVICE_INTEGRITY', $good['device_verdicts']);

            // هش چالش دیگر → failed (هرگز verified نمی‌شود — replay بین چالش‌ها ممکن نیست)
            $mismatch = $pi->verify('mock-integrity.' . hash('sha256', 'another-challenge'), $nonce);
            $this->assertSame('failed', $mismatch['status'], 'توکن با requestHash ناهم‌خوان = failed');
            $this->assertFalse((bool) $mismatch['request_hash_match']);

            // توکن خارج از قرارداد mock → unavailable (معادل شکست decode گوگل)
            $alien = $pi->verify('real-looking-integrity-token', $nonce);
            $this->assertSame('unavailable', $alien['status']);

            // ── مسیر کامل دوربین: چالش → attestation_available → ثبت verified در DB ──
            $service = $this->cameraServiceWithRealSettings($pi);
            $c = $service->getChallenge($this->execD, $this->userA, ['client_mode' => 'mobile_app'], false);
            $this->assertIsArray($c);
            $this->createdRequestIds[] = (int) $c['camera_request_id'];
            $this->assertTrue((bool) ($c['attestation_available'] ?? false), 'در حالت mock کلاینت می‌داند attestation قابل ارسال است');

            $att = ['token' => 'mock-integrity.' . hash('sha256', (string) $c['nonce'])];
            $r = $service->processResult($this->execD, $this->userA, (string) $c['nonce'], [
                ['t' => 0, 'lum' => 118.4, 'std' => 6.2, 'w' => 96, 'h' => 96],
                ['t' => 180, 'lum' => 121.9, 'std' => 6.5, 'w' => 96, 'h' => 96],
                ['t' => 600, 'lum' => 127.3, 'std' => 5.9, 'w' => 96, 'h' => 96],
                ['t' => 1070, 'lum' => 124.1, 'std' => 6.8, 'w' => 96, 'h' => 96],
            ], [], $att);
            $this->assertTrue((bool) $r['success'], 'capture طبیعی + توکن mock = موفق');
            $row = $this->db->fetch("SELECT attestation_status FROM social_camera_requests WHERE id = ?", [(int) $c['camera_request_id']]);
            $this->assertSame('verified', (string) $row->attestation_status, 'attestation_status=verified در DB ثبت شد (بدون هیچ فراخوانی گوگل)');
        } finally {
            if ($hadRow) {
                $this->db->query("UPDATE system_settings SET `value`=?, updated_at=NOW() WHERE `key`='play_integrity_mock'", [$savedValue]);
            } else {
                $this->db->query("DELETE FROM system_settings WHERE `key`='play_integrity_mock'");
            }
            $settingsSvc->clearCache();
        }
    }

    /**
     * 🛡️ FIX-F2 (بازبینی D1–D6): پین مستقلِ فیکس نهفتهٔ FallbackLogger —
     * سازندهٔ بدون-لاگر (همان حالت پیش‌فرض production/بوت) نباید TypeError بدهد
     * و مسیر disabled (mock خاموش + بدون کلید گوگل) نه لاگ دارد نه خروجی؛
     * ریسک risky شدن سوئیت از این قرار نداشته باشد.
     */
    public function testPlayIntegrityServiceDefaultConstructorNeverTypeErrorsWithoutLogger(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی FallbackLogger در تست
        $savedRow = $this->db->fetch("SELECT `value` FROM system_settings WHERE `key` = 'play_integrity_mock'");
        $hadRow = $savedRow !== null;
        $savedValue = $hadRow ? (string) $savedRow->value : null;

        try {
            $this->db->query(
                "INSERT INTO system_settings (`key`,`value`,`group`,type,is_public,created_at,updated_at)
                 VALUES ('play_integrity_mock','0','task','boolean',0,NOW(),NOW())
                 ON DUPLICATE KEY UPDATE `value`='0', updated_at=NOW()"
            );
            \app(\App\Services\Settings\AppSettings::class)->clearCache();

            $pi = new \App\Services\SocialTask\PlayIntegrityService(); // بدون لاگر → FallbackLogger پیش‌فرض
            $this->assertFalse($pi->isMockEnabled(), 'سوییچ خاموش: isMockEnabled=false');
            $off = $pi->verify('mock-integrity.' . hash('sha256', 'pin'), 'pin');
            $this->assertSame('disabled', $off['status'], 'مسیر disabled بدون TypeError و بدون لاگ — سازندهٔ بدون-لاگر سالم است');
        } finally {
            if ($hadRow) {
                $this->db->query("UPDATE system_settings SET `value`=?, updated_at=NOW() WHERE `key`='play_integrity_mock'", [$savedValue]);
            } else {
                $this->db->query("DELETE FROM system_settings WHERE `key`='play_integrity_mock'");
            }
            \app(\App\Services\Settings\AppSettings::class)->clearCache();
        }
    }

    /** سرویس دوربین با تنظیمات «واقعی» (singleton AppSettings از DB) + PlayIntegrity تزریقی */
    private function cameraServiceWithRealSettings(?\App\Services\SocialTask\PlayIntegrityService $pi): \App\Services\SocialTask\CameraVerificationService
    {
        $settings = \app(\App\Services\Settings\AppSettings::class);
        $scoring = new \App\Services\SocialTask\SocialTaskScoringService($settings);
        return new \App\Services\SocialTask\CameraVerificationService(
            \Mockery::mock(\App\Contracts\LoggerInterface::class),
            $this->model,
            new \App\Services\SocialTask\BehaviorAnalysisService($scoring, $settings),
            $scoring,
            $settings,
            $pi,
            new \App\Services\SocialTask\CaptureAnalysisService()
        );
    }

    /**
     * 🎯 D1 (تصمیم مالک ۲۰۲۶-۱۰-۲۶ — نمایش حکم دوربین در پنل ادمین):
     * لایهٔ سرویسِ پنل باید (۱) آخرین رکورد دوربین را کامل برگرداند، (۲) لیست
     * اجراها حکم دوربین را در ستون camera_verdict بیاورد، و (۳) فیلترهای
     * flag/search که از ابتدا در فرم UI بودند اما در SQL نادیده گرفته می‌شدند
     * (FIX-ADMIN-EXEC-FILTERS) واقعاً اعمال شوند.
     */
    public function testAdminCameraLookupAndExecutionsListExposeCameraVerdict(): void
    {
        // داده: رکورد دوربین pass برای execB (مالک userB)؛ execD بدون هیچ رکورد دوربین
        $passNonce = bin2hex(random_bytes(32));
        $this->createRequest($this->execB, $this->userB, 120, $passNonce);
        $this->assertTrue($this->consume($passNonce, $this->userB, $this->execB, 85, 'pass'));

        $svc = $this->socialTaskServiceForAdmin();

        // (۱) getCameraRequestForAdmin — آخرین رکورد کامل برای کارت «حکم دوربین»
        $cam = $svc->getCameraRequestForAdmin($this->execB);
        $this->assertNotNull($cam, 'اجرای دارای رکورد دوربین → رکورد برمی‌گردد');
        $this->assertSame('pass', (string) $cam->server_verdict);
        $this->assertSame(4, (int) $cam->frame_count);
        $this->assertSame('completed', (string) $cam->status);
        $this->assertNull($svc->getCameraRequestForAdmin($this->execD), 'اجرای بدون دوربین → null (کارت نمایش داده نمی‌شود)');

        // (۲) لیست اجراها — ستون camera_verdict (آخرین رکورد completed)
        [$rows, $total] = $svc->getExecutionsForAdmin([], 30, 0);
        $this->assertGreaterThan(0, $total);
        $byId = [];
        foreach ($rows as $row) {
            $byId[(int) $row->id] = $row;
        }
        $this->assertArrayHasKey($this->execB, $byId, 'اجراهای خودساز باید در صفحهٔ اول لیست باشند');
        $this->assertSame('pass', (string) ($byId[$this->execB]->camera_verdict ?? ''), 'ستون دوربین لیست: pass');
        $this->assertArrayHasKey($this->execD, $byId);
        $this->assertNull($byId[$this->execD]->camera_verdict ?? null, 'اجرای بدون رکورد completed → camera_verdict=NULL');

        // (۳) فیلتر flag=1 (قبلاً بند مرده بود) — فقط فلگ‌شده‌ها + شمارش منطبق با SQL مستقیم
        $this->db->query("UPDATE social_task_executions SET flag_review=1 WHERE id = ?", [$this->execD]);
        [$flaggedRows, $flaggedTotal] = $svc->getExecutionsForAdmin(['flag' => '1'], 30, 0);
        $expectedFlagged = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM social_task_executions WHERE flag_review = 1");
        $this->assertSame($expectedFlagged, $flaggedTotal, 'شمارش فیلتر flag = شمارش SQL مستقیم');
        $sawFlaggedExecD = false;
        foreach ($flaggedRows as $f) {
            $this->assertSame(1, (int) $f->flag_review, 'فیلتر flag=1 نباید ردیف غیرفلگ برگرداند');
            if ((int) $f->id === $this->execD) {
                $sawFlaggedExecD = true;
            }
        }
        $this->assertTrue($sawFlaggedExecD, 'اجرای فلگ‌شدهٔ خودساز در نتیجهٔ فیلتر هست');

        // فیلتر search (قبلاً بند مرده بود) — با ایمیل یکتای اجراکننده
        $email = (string) $this->db->fetchColumn("SELECT email FROM users WHERE id = ?", [$this->userA]);
        $this->assertNotSame('', $email);
        [$foundRows, $foundTotal] = $svc->getExecutionsForAdmin(['search' => $email], 30, 0);
        $expectedFound = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM social_task_executions e LEFT JOIN users u ON u.id = e.executor_id WHERE u.email = ?",
            [$email]
        );
        $this->assertSame($expectedFound, $foundTotal, 'شمارش فیلتر search = شمارش SQL مستقیم');
        $this->assertGreaterThan(0, $foundTotal, 'ایمیل اجراکنندهٔ خودساز باید پیدا شود');
        foreach ($foundRows as $f) {
            $this->assertSame($this->userA, (int) $f->executor_id, 'search نباید ردیف اجراکنندهٔ دیگر برگرداند');
        }
    }

    /** SocialTaskService با وابستگی‌های mock (فقط db واقعی) — برای متدهای ادمین */
    private function socialTaskServiceForAdmin(): \App\Services\SocialTask\SocialTaskService
    {
        $model = \Mockery::mock(\App\Models\SocialTaskModel::class);
        $model->shouldReceive('getDb')->andReturn($this->db);
        return new \App\Services\SocialTask\SocialTaskService(
            \Mockery::mock(\App\Contracts\LoggerInterface::class),
            $model,
            \Mockery::mock(\App\Services\Gamification\TrustService::class),
            \Mockery::mock(\App\Services\SocialTask\SilentAntiFraudService::class),
            \Mockery::mock(\App\Services\User\UserService::class),
            \Mockery::mock(\App\Services\SocialAccountService::class),
            \Mockery::mock(\App\Services\Interaction\RatingService::class),
            \Mockery::mock(\App\Services\ScoreService::class),
            \Mockery::mock(\App\Services\Shared\IdempotencyService::class),
            \Mockery::mock(\Core\Container::class),
            \Mockery::mock(\App\Services\Ads\AdsBudgetSettlementService::class),
            \Mockery::mock(\App\Services\AdSystemManager::class)
        );
    }

}
