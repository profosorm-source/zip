<?php

declare(strict_types=1);

namespace Tests\Integration\Lottery;

use App\Jobs\Lottery\UpdateLotteryChanceScoresJob;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-S17-01 — سناریوی واقعیِ «دیروز + بک‌فیل» روی MariaDB زنده (chortk)
 *
 * سناریو (روایت کرونِ ۰۳:۲۰):
 *   روزهای D-3/D-2/D-1 برای راند R1 عدد روزانه دارند؛ عدد D-3 قبلاً claim شده
 *   (کرونِ روزِ D-2 آن را پردازش کرده). D-2 و D-1 هنوز claim ندارند (کرون از
 *   دست رفته). عددِ «امروز» و عددِ ۲۰ روز قبل هم موجودند (باید از پنجره خارج
 *   بمانند). راند R3 لغوشده است؛ عدد soft-deleted هم داریم.
 *   P1 از ابتدا عضو بوده؛ P2 شبِ D-2 (22:30) دیر پیوسته — با مرزِ «پایانِ
 *   روز» (23:59:59) برای D-2 و D-1 شمرده می‌شود (روزِ عضویتش و پس از آن)،
 *   ولی برای D-3 هرگز (روزِِ پیش از عضویت — جریمهٔ no_vote خیالی نمی‌گیرد).
 *
 * پین‌ها:
 *  ① SQL انتخابِ تاریخ‌ها عیناً از سورس Kernel استخراج می‌شود (تک-منبعِ حقیقت)
 *     و روی دیتای seed اجرا می‌شود: خروجی = [R1@D-2, R1@D-1, R2@D-1] به ترتیب ASC.
 *  ② اجرای واقعی Job روی کاندیدها → chance_logs با زنجیرهٔ score_before→after
 *     درست (D-2: 102→101.5 سپس D-1: 101.5→103.5 برای P1) + لجر score_events.
 *  ③ اجرای دومِ همان SQL → خالی (idempotency از طریق claim، نه rework).
 *  ④ as-of: getAllActiveByRound(101, D-3) فقط P1؛ (101, D-1) هر دو.
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class LotteryChanceScoresCronBackfillTest extends TestCase
{
    private Database $db;

    /** @var array<string,string> */
    private array $d = [];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = \Core\Application::getInstance()->container->make(Database::class);
        $this->d = [
            'D3'  => date('Y-m-d', strtotime('-3 day')),
            'D2'  => date('Y-m-d', strtotime('-2 day')),
            'D1'  => date('Y-m-d', strtotime('-1 day')), // دیروز
            'D0'  => date('Y-m-d'),                      // امروز
            'D20' => date('Y-m-d', strtotime('-20 day')),
        ];

        // beStrictAboutOutputDuringTests: sink استریمِ CLI (echo در LogService)
        // خروجی تست را آلوده می‌کند → LoggerInterface کانتینر با اسپایِ بی‌صدای
        // درون-تستی جایگزین می‌شود (هر تستِ این فایل پروسهٔ جدا دارد؛ بدون نشت).
        \Core\Application::getInstance()->container->instance(
            \App\Contracts\LoggerInterface::class,
            new class () implements \App\Contracts\LoggerInterface {
                /** @var list<string> */
                public array $lines = [];
                private function rec(string $level, string|\Stringable $m): void
                {
                    $this->lines[] = $level . ':' . (string)$m;
                }
                public function emergency($message, array $context = []): void { $this->rec('emergency', $message); }
                public function alert($message, array $context = []): void { $this->rec('alert', $message); }
                public function critical($message, array $context = []): void { $this->rec('critical', $message); }
                public function error($message, array $context = []): void { $this->rec('error', $message); }
                public function warning($message, array $context = []): void { $this->rec('warning', $message); }
                public function notice($message, array $context = []): void { $this->rec('notice', $message); }
                public function info($message, array $context = []): void { $this->rec('info', $message); }
                public function debug($message, array $context = []): void { $this->rec('debug', $message); }
                public function log($level, $message, array $context = []): void { $this->rec('log', $message); }
                public function activity(string $action, string $description, ?int $userId = null, array $metadata = []): void
                {
                    $this->rec('activity', $action);
                }
            }
        );

        $this->seed();
    }

    protected function tearDown(): void
    {
        $this->cleanup();
        parent::tearDown();
    }

    private function cleanup(): void
    {
        $pdo = $this->db->getPdo();
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        // حذف round-scoped (نه id-based): ردیف‌های seed/probe ممکن است id خودکار
        // کوچک داشته باشند؛ دامنهٔ تست = راندهای 101..103
        $pdo->exec("DELETE FROM lottery_chance_logs   WHERE round_id IN (101,102,103)");
        $pdo->exec("DELETE FROM lottery_votes          WHERE round_id IN (101,102,103)");
        $pdo->exec("DELETE FROM lottery_participations WHERE round_id IN (101,102,103)");
        $pdo->exec("DELETE FROM lottery_daily_numbers  WHERE round_id IN (101,102,103)");
        $pdo->exec("DELETE FROM lottery_rounds         WHERE id IN (101,102,103)");
        $pdo->exec("DELETE FROM score_events WHERE domain = 'lottery_chance'
                    AND entity_id IN (8801, 8802, 8803)
                    AND reason IN ('lottery_no_vote', 'lottery_daily_vote')");
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');

        // پاک‌سازی حالتِ Redis که بین اجراها می‌ماند (ادعای idempotencyِ لجر +
        // شمارنده‌های alternating برای کاربران ساختگیِ این تست) — بدون این،
        // اجرای مجددِ فایل تست، event لجر را «قبلاً-اعمال‌شده» می‌پندارد.
        try {
            $redis = \Core\Application::getInstance()->container->make(\Core\Cache::class)->redis();
            if ($redis !== null) {
                foreach (['101', '102'] as $round) {
                    foreach ($redis->keys("score_idemp:lottery:*:{$round}:*") ?: [] as $k) {
                        $redis->del([$k]);
                    }
                }
                foreach ([8801, 8802, 8803] as $uid) {
                    foreach ($redis->keys("score_alt*:user:{$uid}:lottery_chance") ?: [] as $k) {
                        $redis->del([$k]);
                    }
                    foreach ($redis->keys("chortke:rl:fw:rl_score_apply_user_{$uid}_lottery_chance") ?: [] as $k) {
                        $redis->del([$k]);
                    }
                }
            }
        } catch (\Throwable $e) {
            // Redis غایب: بقیهٔ تست‌ها به حالت خطا می‌روند (قرارداد سوئیت)
        }
    }

    private function seed(): void
    {
        $this->cleanup();
        $pdo = $this->db->getPdo();
        $now = date('Y-m-d H:i:s');
        ['D3' => $D3, 'D2' => $D2, 'D1' => $D1, 'D0' => $D0, 'D20' => $D20] = $this->d;

        // راندها: 101 فعال، 102 رأی‌گیری، 103 لغوشده
        $pdo->exec("INSERT INTO lottery_rounds (id, title, status, is_deleted, created_at) VALUES
            (101, 'S17-R1', 'active', 0, '$now'),
            (102, 'S17-R2', 'voting', 0, '$now'),
            (103, 'S17-R3', 'cancelled', 0, '$now')");

        // اعداد روزانه
        $pdo->exec("INSERT INTO lottery_daily_numbers (id, round_id, date, winning_number, number1, number2, number3, status, is_deleted, created_at) VALUES
            (301, 101, '$D3',  5,  5, 10, 15, 'pending', 0, '$now'),
            (302, 101, '$D2',  7,  7, 14, 21, 'pending', 0, '$now'),
            (303, 101, '$D1',  9,  9, 18, 27, 'pending', 0, '$now'),
            (304, 101, '$D0',  3,  3,  6,  9, 'pending', 0, '$now'),
            (305, 101, '$D20', 2,  2,  4,  8, 'pending', 0, '$now'),
            (306, 102, '$D1', 11, 11, 22, 33, 'pending', 0, '$now'),
            (307, 103, '$D1', 13, 13, 26, 39, 'pending', 0, '$now'),
            (308, 101, '$D2', 99, 99, 99, 99, 'pending', 1, '$now')");

        // مشارکت‌ها: 501=P1 (از D-3 صبح)، 502=P2 (شب D-2 دیرهنگام)، 511 عضو R2
        $pdo->exec("INSERT INTO lottery_participations (id, user_id, round_id, ticket_number, chance_score, status, is_deleted, created_at) VALUES
            (501, 8801, 101, '5,10,15', 100.0000, 'active', 0, '" . $D3 . " 08:00:00'),
            (502, 8802, 101, '7,14,21', 100.0000, 'active', 0, '" . $D2 . " 22:30:00'),
            (511, 8803, 102, '11,22,33', 100.0000, 'active', 0, '" . $D3 . " 09:00:00')");

        // claim موجود برای (R1, D-3) — پردازشِ روزِ قبل؛ P1 آن روز match گرفته (+2).
        // ردیف لجرِ همان روز هم seed می‌شود تا زنجیرهٔ لجر واقعی باشد: floor guardِ
        // ScoreService (کف دامنهٔ lottery_chance = 0) دلتای منفی را وقتی می‌پذیرد که
        // جمعِ لجر مثبت باشد — با لجرِ خالی، جریمه‌ها «clamp» می‌شوند (skip با true).
        $pdo->exec("INSERT INTO lottery_chance_logs (participation_id, user_id, round_id, date, score_before, score_change, score_after, reason, created_at) VALUES
            (501, 8801, 101, '$D3', 100.0000, 2.0000, 102.0000, 'match_success', '$now')");
        $pdo->exec("INSERT INTO score_events (entity_type, entity_id, domain, delta, reason, metadata, created_at) VALUES
            ('user', 8801, 'lottery_chance', 2.0000, 'lottery_daily_vote', '{}', '$now')");
        // مقدار فعلی P1 همان 102 (claim قبلاً اعمال شده)
        $pdo->exec("UPDATE lottery_participations SET chance_score = 102.0000 WHERE id = 501");

        // رأی‌ها: P1 روی D-2 رأی نداده (no_vote)؛ روی D-1 رأیِ منطبق (15 ∈ بلیت P1='5,10,15').
        // P2 روی D-1 رأی نادرست (9 ∉ بلیت P2='7,14,21'). عضو R2 روی D-1 رأی منطبق (11 ∈ '11,22,33').
        $pdo->exec("INSERT INTO lottery_votes (id, user_id, round_id, daily_number_id, participation_id, voted_number, status, is_deleted, created_at) VALUES
            (701, 8801, 101, 303, 501, 15, 'cast', 0, '" . $D1 . " 12:00:00'),
            (702, 8802, 101, 303, 502, 9,  'cast', 0, '" . $D1 . " 13:00:00'),
            (703, 8803, 102, 306, 511, 11, 'cast', 0, '" . $D1 . " 14:00:00')");
    }

    /**
     * SQL انتخابِ تاریخ‌ها را عیناً از سورس Kernel استخراج می‌کند —
     * تک-منبعِ حقیقت؛ تست با پروداکشن هم‌گام می‌ماند.
     */
    private function cronSql(): string
    {
        $src = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Console/Kernel.php');
        $ok = preg_match('/\$candidates = \$db->fetchAll\(\s*"(.*?)",\s*\[\$backfillDays\]/s', $src, $m);
        $this->assertSame(1, $ok, 'SQL کرون باید از سورس Kernel قابل استخراج باشد');
        return (string)$m[1];
    }

    /** @return list<string> */
    private function candidates(): array
    {
        $rows = $this->db->fetchAll($this->cronSql(), [14]);
        return array_values(array_map(
            fn($r) => (int)$r->round_id . '@' . date('Y-m-d', strtotime((string)$r->date)),
            $rows
        ));
    }

    // ═══════════ ① انتخاب پنجره ═══════════

    public function testCandidateSelectionIsYesterdayPlusUnclaimedBackfill(): void
    {
        $want = [
            '101@' . $this->d['D2'],
            '101@' . $this->d['D1'],
            '102@' . $this->d['D1'],
        ];
        $this->assertSame($want, $this->candidates(),
            'پنجره = دیروز + بک‌فیلِ claimنشده؛ خروجِ امروز/۲۰روزقبل/claimشده/راندِ لغوشده/soft-deleted؛ ترتیب ASC');
    }

    public function testAsOfParticipationFilter(): void
    {
        $pm = \Core\Application::getInstance()->container->make(\App\Models\LotteryParticipation::class);
        $this->assertCount(2, $pm->getAllActiveByRound(101), 'بدون as-of: هر دو عضو');
        $this->assertCount(1, $pm->getAllActiveByRound(101, $this->d['D3']),
            'as-of D-3: فقط P1 (P2 هنوز متولد نشده)');
        $this->assertCount(0, $pm->getAllActiveByRound(101, $this->d['D20']),
            'as-of بیست روز قبل: هیچ‌کدام');
        $ids = array_map(fn($p) => (int)$p->id, $pm->getAllActiveByRound(101, $this->d['D1']));
        $this->assertSame([501, 502], $ids, 'as-of D-1: P1 و P2 (شبِ D-2 دیرهنگام برای D-1 شمرده می‌شود)');
    }

    // ═══════════ ② اجرای واقعی Job روی کاندیدها ═══════════

    public function testEndToEndBackfillRunChainsScoresAndLedger(): void
    {
        $job = \Core\Application::getInstance()->container->make(UpdateLotteryChanceScoresJob::class);

        // اجرای کرون: برای هر کاندید، Job را مثل خود closure صدا بزن
        $results = [];
        foreach ($this->db->fetchAll($this->cronSql(), [14]) as $row) {
            $date = date('Y-m-d', strtotime((string)$row->date));
            $results[] = $job->handle((int)$row->round_id, $date);
        }

        $this->assertCount(3, $results, 'سه کاندید اجرا شود');
        foreach ($results as $r) {
            $this->assertTrue(!empty($r['success']), 'هر handle باید موفق باشد: ' . ($r['message'] ?? ''));
        }

        // P1 (بلیت 5,10,15 — chance=102 بعد از D-3):
        //   D-2: بدون رأی → no_vote −0.5 → 101.5
        //   D-1: رأی 15 منطبق → +2 → 103.5
        $p1 = $this->db->fetchAll("SELECT chance_score FROM lottery_participations WHERE id = 501")[0];
        $this->assertEqualsWithDelta(103.5, (float)$p1->chance_score, 0.0001,
            'زنجیرهٔ P1: 102 → (D-2 no_vote) 101.5 → (D-1 match +2) 103.5');

        // P2 (شبِ D-2 22:30 دیرهنگام؛ مرز as-of = پایانِ روز):
        //   D-2 (روزِ عضویتش): بدون رأی → no_vote −0.5 → 99.5
        //   D-1: رأی 9 نادرست (بلیت 7,14,21) → −1 → 98.5
        $p2 = $this->db->fetchAll("SELECT chance_score FROM lottery_participations WHERE id = 502")[0];
        $this->assertEqualsWithDelta(98.5, (float)$p2->chance_score, 0.0001,
            'P2 دیرهنگام از روزِِ عضویتش (D-2) به بعد امتیاز می‌گیرد؛ نه برای D-3ِ پیش از عضویت');

        // زنجیرهٔ chance_logs برای P1 — score_before هر روز = score_afterِ روزِ قبل
        $logs = $this->db->fetchAll(
            "SELECT date, score_before, score_change, score_after, reason
             FROM lottery_chance_logs WHERE participation_id = 501 ORDER BY date"
        );
        $this->assertCount(3, $logs, 'P1 سه ردیف لاگ: D-3 (seed) + D-2 + D-1');
        [$l3, $l2, $l1] = $logs;
        $this->assertSame('match_success', $l3->reason);
        $this->assertEqualsWithDelta(102.0, (float)$l3->score_after, 0.0001);

        $this->assertSame('no_vote', $l2->reason, 'D-2: P1 رأی نداده');
        $this->assertEqualsWithDelta(102.0, (float)$l2->score_before, 0.0001, 'score_beforeِ D-2 = score_afterِ D-3');
        $this->assertEqualsWithDelta(-0.5, (float)$l2->score_change, 0.0001);
        $this->assertEqualsWithDelta(101.5, (float)$l2->score_after, 0.0001);

        $this->assertSame('match_success', $l1->reason, 'D-1: رأی 15 منطبق');
        $this->assertEqualsWithDelta(101.5, (float)$l1->score_before, 0.0001, 'score_beforeِ D-1 = score_afterِ D-2');
        $this->assertEqualsWithDelta(103.5, (float)$l1->score_after, 0.0001);

        // P2 دو ردیف (D-2 روزِ عضویت + D-1) — نه D-3ِ خیالی (پیش از عضویت)
        $p2logs = $this->db->fetchAll(
            "SELECT date, reason, score_before, score_after FROM lottery_chance_logs WHERE participation_id = 502 ORDER BY date"
        );
        $this->assertCount(2, $p2logs, 'P2 از روزِ عضویتش به بعد؛ برای D-3 هیچ');
        $this->assertSame($this->d['D2'], (string)$p2logs[0]->date);
        $this->assertSame('no_vote', $p2logs[0]->reason);
        $this->assertEqualsWithDelta(99.5, (float)$p2logs[0]->score_after, 0.0001);
        $this->assertSame($this->d['D1'], (string)$p2logs[1]->date);
        $this->assertSame('match_fail', $p2logs[1]->reason);
        $this->assertEqualsWithDelta(99.5, (float)$p2logs[1]->score_before, 0.0001, 'score_beforeِ D-1 = score_afterِ D-2 (زنجیره)');
        $this->assertEqualsWithDelta(98.5, (float)$p2logs[1]->score_after, 0.0001);

        // لجر score_events (P1) — سه event به ترتیب id: D-3 (+2 seed)، D-2 (−0.5)، D-1 (+2).
        // (بدون seedِ D-3، floor guard دلتای منفی D-2 را با «جمعِ لجر صفر» clamp می‌کرد)
        $ledger = $this->db->fetchAll(
            "SELECT delta, reason FROM score_events
             WHERE entity_type = 'user' AND entity_id = 8801 AND domain = 'lottery_chance'
             ORDER BY id"
        );
        $this->assertCount(3, $ledger, 'P1: seedِ D-3 + دو event جدید (D-2, D-1)');
        $this->assertEqualsWithDelta(2.0, (float)$ledger[0]->delta, 0.0001, 'لجر D-3 (seed) = +2');
        $this->assertEqualsWithDelta(-0.5, (float)$ledger[1]->delta, 0.0001, 'لجر D-2 = no_vote');
        $this->assertEqualsWithDelta(2.0, (float)$ledger[2]->delta, 0.0001, 'لجر D-1 = match');

        // لجر P2 — صفر event: P2 هیچ سابقهٔ لجرِ مثبت ندارد؛ floor guardِ دامنهٔ
        // lottery_chance (کف 0 روی جمعِ لجر) هر دو دلتای منفی (D-2 no_vote −0.5 و
        // D-1 match_fail −1) را clamp می‌کند و applyDelta با true برمی‌گردد (skip).
        // participation.chance_score همان‌طور پایین می‌آید — این واگراییِ شناخته‌شدهٔ
        // projection/ledger است (مشاهدهٔ بازبینی، گزارش تحویل) و اینجا عیناً پین می‌شود.
        $ledgerP2 = $this->db->fetchAll(
            "SELECT delta FROM score_events
             WHERE entity_type = 'user' AND entity_id = 8802 AND domain = 'lottery_chance'
             ORDER BY id"
        );
        $this->assertCount(0, $ledgerP2,
            'floor guard: جریمه‌های کاربرِ بدون سابقهٔ لجرِ مثبت، در لجر ثبت نمی‌شوند (clamp با true)');
    }

    // ═══════════ ③ idempotency — اجرای دوم ═══════════

    public function testSecondCronRunIsNoOp(): void
    {
        $job = \Core\Application::getInstance()->container->make(UpdateLotteryChanceScoresJob::class);
        foreach ($this->db->fetchAll($this->cronSql(), [14]) as $row) {
            $job->handle((int)$row->round_id, date('Y-m-d', strtotime((string)$row->date)));
        }
        $before = $this->db->fetchAll("SELECT chance_score FROM lottery_participations WHERE id IN (501,502) ORDER BY id");
        $logCount = (int)$this->db->fetchColumn("SELECT COUNT(*) FROM lottery_chance_logs WHERE round_id IN (101,102)");

        $this->assertSame([], $this->candidates(), 'اجرای دوم: کاندید خالی (claim ها حذفشده‌اند)');
        // حتی اگر Job دوباره روی همان تاریخ صدا زده شود:
        $res = $job->handle(101, $this->d['D2']);
        $this->assertTrue(!empty($res['success']));
        $this->assertSame(0, (int)$res['updated_count'], 'چیزی به‌روز نمی‌شود');
        $this->assertGreaterThan(0, (int)$res['skipped_count'], 'همه skip (claim تکراری)');

        $after = $this->db->fetchAll("SELECT chance_score FROM lottery_participations WHERE id IN (501,502) ORDER BY id");
        $logCount2 = (int)$this->db->fetchColumn("SELECT COUNT(*) FROM lottery_chance_logs WHERE round_id IN (101,102)");
        $this->assertEqualsWithDelta(
            (float)$before[0]->chance_score, (float)$after[0]->chance_score, 0.0001, 'امتیاز P1 تغییر نکند');
        $this->assertEqualsWithDelta(
            (float)$before[1]->chance_score, (float)$after[1]->chance_score, 0.0001, 'امتیاز P2 تغییر نکند');
        $this->assertSame($logCount, $logCount2, 'هیچ ردیف لاگ تکراری');
    }
}
