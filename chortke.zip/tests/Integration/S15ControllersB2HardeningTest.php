<?php

declare(strict_types=1);

namespace Tests\Integration;

use App\Models\Dispute;
use App\Services\Dispute\DisputeCommandService;
use App\Services\TicketCommandService;
use Core\Database;
use PHPUnit\Framework\TestCase;
use Mockery as m;

/**
 * بچ S15 — قفل رفتاری فیکس‌های Controllers بخش ۲ (سطح سرویس، MariaDB واقعی):
 *
 *  - FIX-S15-1: DisputeCommandService::resolveByAgreement قبلاً فقط «طرف بودن»
 *    را چک می‌کرد — هر طرفی می‌توانست پروندهٔ escalated/under_review را به
 *    resolved_peer ببرد (خروج از صف‌های ادمین per CLOSED_STATUSES) یا پروندهٔ
 *    open را مستقیم ببندد؛ هر دو خلاف TRANSITIONS (فقط open_peer → resolved_peer).
 *  - FIX-S15-10: sanitize مرکزی پیوست تیکت — فراخوان‌های API بدنهٔ خام را عبور
 *    می‌دهند؛ بدون این صافی، مهاجم می‌توانست path پیوست قربانی را در تیکت خودش
 *    ثبت کند و زنجیرهٔ resolveAttachment (تازه‌ترین ردیفِ exact-match) فایل
 *    قربانی را سرو می‌کرد (IDOR با پرایمیتیو نوشتن، الگوی FIX-S14-1).
 */
final class S15ControllersB2HardeningTest extends TestCase
{
    /** @var list<int> */
    private array $insertedDisputeIds = [];
    /** @var list<int> */
    private array $insertedMessageIds = [];

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        foreach ($this->insertedDisputeIds as $id) {
            try {
                $db->table('disputes')->where('id', '=', $id)->delete();
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        foreach ($this->insertedMessageIds as $id) {
            try {
                $db->table('ticket_messages')->where('id', '=', $id)->delete();
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        $this->insertedDisputeIds = [];
        $this->insertedMessageIds = [];
        m::close();
        parent::tearDown();
    }

    // ─────────────────────────────────────────────────────────────
    // کمکی‌ها
    // ─────────────────────────────────────────────────────────────

    private function someUserId(): int
    {
        $db = Database::getInstance();
        $id = (int)($db->fetchColumn('SELECT id FROM users ORDER BY id ASC LIMIT 1') ?? 0);
        if ($id <= 0) {
            $this->markTestSkipped('هیچ کاربری برای fixture پیدا نشد');
        }
        return $id;
    }

    private function someOtherUserId(int $notThis): int
    {
        $db = Database::getInstance();
        $id = (int)($db->fetchColumn('SELECT id FROM users WHERE id <> ? ORDER BY id ASC LIMIT 1', [$notThis]) ?? 0);
        if ($id <= 0) {
            return $notThis; // تک‌کاربر — سناریوی «دیگری» را skip می‌کنیم (فراخواننده چک کند)
        }
        return $id;
    }

    private function insertDispute(int $userId, int $targetUserId, string $status): int
    {
        $db = Database::getInstance();
        $db->table('disputes')->insert([
            // FIX-R36-W1: ref_type='general' — fixture قبلی 'influencer_order' بود که
            // بعد از FIX 8-c (تسویهٔ اسکرو در مسیر توافقی با wrapper+escrow اجباری)
            // دیگر بدون ردیف سفارش/اسکرو قابل حل نیست. نیت این پین، سلامتِ مسیر
            // غیرمالیِ open_peer→resolved_peer است؛ رگرسیون درختِ بازسازی‌شدهٔ sandbox.
            'ref_type'    => 'general',
            'ref_id'      => 99988801,
            'user_id'     => $userId,
            'target_user_id' => $targetUserId,
            'status'      => $status,
            'reason'      => 'S15 fixture dispute',
            'role'        => 'customer',
            'created_at'  => date('Y-m-d H:i:s'),
            'updated_at'  => date('Y-m-d H:i:s'),
        ]);
        $id = (int)$db->getPdo()->lastInsertId();
        $this->insertedDisputeIds[] = $id;
        return $id;
    }

    private function makeDisputeCommandService(): DisputeCommandService
    {
        $db = Database::getInstance();
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);
        $wallet->shouldIgnoreMissing();
        $reconciliation = m::mock(\App\Services\ReconciliationService::class);
        $reconciliation->shouldIgnoreMissing();
        $transaction = m::mock(\App\Models\Transaction::class);
        $transaction->shouldIgnoreMissing();
        $idempotency = m::mock(\App\Services\Shared\IdempotencyService::class);
        $idempotency->shouldIgnoreMissing();

        return new DisputeCommandService(
            $db,
            $logger,
            new Dispute($db),
            $wallet,
            $reconciliation,
            $transaction,
            $idempotency,
            null, // outbox — nullable
            null, // templateService
            null, // financialEscrowService
            new \Core\TransactionWrapper($db) // FIX-R36-W1: wrapper واقعی — FIX 8-c تسویهٔ مالی را زیر تراکنش اتمیک الزامی کرده؛ nullِ قبلی رگرسیون بازسازی sandbox بود
        );
    }

    private function makeTicketCommandService(): TicketCommandService
    {
        $db = Database::getInstance();
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $validatorFactory = m::mock(\App\Contracts\ValidatorFactoryInterface::class);
        $validatorFactory->shouldIgnoreMissing();
        $events = m::mock(\Core\EventDispatcher::class);
        $events->shouldIgnoreMissing();
        $rateLimiter = m::mock(\Core\RateLimiter::class);
        $rateLimiter->shouldIgnoreMissing();
        $idempotency = m::mock(\App\Services\Shared\IdempotencyService::class);
        $idempotency->shouldIgnoreMissing();

        return new TicketCommandService(
            $validatorFactory,
            $events,
            $db,
            $logger,
            new \App\Models\Ticket($db),
            new \App\Models\TicketMessage($db),
            $rateLimiter,
            $idempotency,
            null // outbox
        );
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S15-1 — گارد ماشین وضعیت resolveByAgreement
    // ─────────────────────────────────────────────────────────────

    public function test_peer_resolution_rejected_for_escalated_case(): void
    {
        $userId = $this->someUserId();
        $disputeId = $this->insertDispute($userId, $userId, Dispute::STATUS_ESCALATED);

        $result = $this->makeDisputeCommandService()
            ->resolveByAgreement($disputeId, $userId, 'تلاش برای حل', 'favor_customer');

        $this->assertFalse($result['success'], 'حل توافقی روی پروندهٔ escalated باید رد شود');
        $row = Database::getInstance()->table('disputes')->where('id', '=', $disputeId)->first();
        $this->assertSame(
            Dispute::STATUS_ESCALATED,
            (string)$row->status,
            'وضعیت پروندهٔ escalated نباید توسط طرفین تغییر کند (خروج از صف ادمین مسدود)'
        );
    }

    public function test_peer_resolution_rejected_for_open_case(): void
    {
        $userId = $this->someUserId();
        $disputeId = $this->insertDispute($userId, $userId, Dispute::STATUS_OPEN);

        $result = $this->makeDisputeCommandService()
            ->resolveByAgreement($disputeId, $userId, 'تلاش برای حل', 'favor_influencer');

        $this->assertFalse($result['success'], 'حل توافقی روی پروندهٔ open (خارج از TRANSITIONS) باید رد شود');
    }

    public function test_peer_resolution_still_works_for_open_peer_case(): void
    {
        $userId = $this->someUserId();
        $disputeId = $this->insertDispute($userId, $userId, Dispute::STATUS_OPEN_PEER);

        $result = $this->makeDisputeCommandService()
            ->resolveByAgreement($disputeId, $userId, 'توافق دوطرفه', 'favor_influencer');

        $this->assertTrue($result['success'], 'مسیر مشروع open_peer → resolved_peer باید سالم بماند');
        $row = Database::getInstance()->table('disputes')->where('id', '=', $disputeId)->first();
        $this->assertSame(Dispute::STATUS_RESOLVED_PEER, (string)$row->status);
        $this->assertSame($userId, (int)$row->resolved_by);
    }

    public function test_peer_resolution_rejected_for_non_party(): void
    {
        $userId = $this->someUserId();
        $otherId = $this->someOtherUserId($userId);
        if ($otherId === $userId) {
            $this->markTestSkipped('فقط یک کاربر در DB است — سناریوی غیرطرف قابل ساخت نیست');
        }
        $disputeId = $this->insertDispute($userId, $userId, Dispute::STATUS_OPEN_PEER);

        $result = $this->makeDisputeCommandService()
            ->resolveByAgreement($disputeId, $otherId, 'دسترسی غیرطرف', 'favor_influencer');

        $this->assertFalse($result['success'], 'غیرطرف نباید بتواند حل توافقی ثبت کند');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S15-10 — sanitize مرکزی پیوست
    // ─────────────────────────────────────────────────────────────

    private function sanitize(array $attachments, int $userId): array
    {
        $svc = $this->makeTicketCommandService();
        $ref = new \ReflectionMethod($svc, 'sanitizeAttachments');
        $ref->setAccessible(true);
        /** @var list<array{name:string,path:string}> $out */
        $out = $ref->invoke($svc, $attachments, $userId);
        return $out;
    }

    private function insertMessageWithAttachment(int $userId, string $path): int
    {
        $db = Database::getInstance();
        $db->table('ticket_messages')->insert([
            'ticket_id'   => 99988802,
            'user_id'     => $userId,
            'message'     => 'S15 attachment claim fixture',
            'is_admin'    => 0,
            'attachments' => json_encode([['name' => 'shot.png', 'path' => $path]], JSON_UNESCAPED_UNICODE),
            'created_at'  => date('Y-m-d H:i:s', time() - 60),
            'updated_at'  => date('Y-m-d H:i:s', time() - 60),
        ]);
        $id = (int)$db->getPdo()->lastInsertId();
        $this->insertedMessageIds[] = $id;
        return $id;
    }

    public function test_attachment_with_foreign_pattern_or_traversal_is_dropped(): void
    {
        $userId = $this->someUserId();

        $out = $this->sanitize([
            ['name' => 'ok.png', 'path' => '../../etc/passwd'],                              // traversal
            ['name' => 'ok.png', 'path' => 'storage/uploads/ticket_attachments/aaa111bbb222ccc333ddd444.png'], // خارج از قالب نسبی
            ['name' => 'ok.png', 'path' => 'ticket_attachments/zzzz-not-hex.png'],           // نام غیرالگویی
            ['name' => 'ok.png', 'path' => 'ticket_attachments/aaa111bbb222ccc333ddd444.exe.exe'], // دوبل‌پسوند
        ], $userId);

        $this->assertSame([], $out, 'هیچ مسیری خارج از قالب قانونی نباید عبور کند');
    }

    public function test_attachment_claimed_by_other_user_is_dropped(): void
    {
        $victimId = $this->someUserId();
        $attackerId = $this->someOtherUserId($victimId);
        if ($attackerId === $victimId) {
            $this->markTestSkipped('فقط یک کاربر در DB است — سناریوی تصاحبه قابل ساخت نیست');
        }

        $victimPath = 'ticket_attachments/aaa111bbb222ccc333ddd444.png';
        $this->insertMessageWithAttachment($victimId, $victimPath);

        $out = $this->sanitize([
            ['name' => 'x.png', 'path' => $victimPath],
        ], $attackerId);

        $this->assertSame([], $out, 'ثبتِ مسیرِ ثبت‌شده توسط کاربر دیگر باید مردود باشد (IDOR write primitive)');
    }

    public function test_attachment_owner_reclaim_and_fresh_path_are_kept(): void
    {
        $ownerId = $this->someUserId();

        $path = 'ticket_attachments/bbb222ccc333ddd444eee555.png';
        $this->insertMessageWithAttachment($ownerId, $path);

        $out = $this->sanitize([
            ['name' => 'shot.png', 'path' => $path],                                     // صاحبِ قبلی = خود کاربر
            ['name' => 'fresh.png', 'path' => 'ticket_attachments/ccc333ddd444eee555fff666.jpg'], // مسیر تازهٔ الگوی UploadService
            ['name' => 'bad name Ünïcode.png', 'path' => 'ticket_attachments/ddd444eee555fff666aaa111.png'], // name پاک‌سازی می‌شود (قرارداد MEDIUM-02) نه حذف
        ], $ownerId);

        $this->assertCount(3, $out, 'هر سه پیوستِ با مسیر قانونی باید بمانند');
        $this->assertSame($path, $out[0]['path']);
        $this->assertSame('shot.png', $out[0]['name']);
        $this->assertSame('ticket_attachments/ccc333ddd444eee555fff666.jpg', $out[1]['path']);
        $this->assertSame('ticket_attachments/ddd444eee555fff666aaa111.png', $out[2]['path']);
        $this->assertSame('badnamencode.png', $out[2]['name'], 'نام باید به ASCII امن پاک‌سازی شود');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S15-4 — نگاشت سهمیهٔ coupon_validate
    // ─────────────────────────────────────────────────────────────

    public function test_coupon_validate_rate_limit_mapping_exists(): void
    {
        $config = include dirname(__DIR__, 2) . '/config/rate_limits.php';
        $this->assertIsArray($config);
        $this->assertSame(
            ['coupon', 'validate'],
            $config['action_map']['coupon_validate'] ?? null,
            'coupon_validate باید به گروه coupon/validate نگاشت شود'
        );
        $this->assertSame(10, (int)($config['coupon']['validate']['max_attempts'] ?? 0));
        $this->assertSame(1, (int)($config['coupon']['validate']['decay_minutes'] ?? 0));
    }
}
