<?php

declare(strict_types=1);

namespace Tests\Integration\Queue;

use App\Services\QueueWorker;
use Core\Application;
use Core\Cache;
use Core\Database;
use Core\Queue;
use PHPUnit\Framework\TestCase;
use Tests\Fixtures\RuntimeProbeJob;

/**
 * FIX-YAFTE22 (بستهٔ ۳) — قرارداد گیت حافظهٔ QueueWorker::work().
 *
 * گیت حافظه قرارداد دیمنِ تحتِ سوپروایزر است: خروج تمیز وقتی پروسهٔ ورکر
 * از سقف مطلق (پیش‌فرض 128MB، قابل تنظیم با QUEUE_MEMORY_LIMIT_MB /
 * queue.memory_limit_mb) عبور کند، تا سوپروایزر ری‌استارتش کند. اما همین
 * گیت وقتی work() داخل یک پروسهٔ میزبانِ سنگین (مثل PHPUnit پس از ~۲۵۰۰
 * تست، ~130MB حافظهٔ واقعی) فراخوانی شود، بدون هیچ علامتی ورکر را به
 * no-op تبدیل می‌کرد — ۹ شکستِ فقط-در-ران-کامل (پاس در ایزوله) که با
 * اندازه‌گیری مستقیم (memory_get_usage(true)=130.5MB > 128MB) ریشه‌یابی شد.
 *
 * این فایل دو قرارداد را pin می‌کند:
 *  ۱) آستانهٔ گیت در «استقرار پروسهٔ تست» باید همیشه بالای حافظهٔ واقعیِ
 *     پروسه و بالای ردپای واقع‌بینانهٔ سوئیت (~۲× رشد آتی) باشد — ست‌شده
 *     در bootstrap/testing.php با QUEUE_MEMORY_LIMIT_MB=512.
 *  ۲) خودِ گیت در آستانهٔ پایین رفتار امن دارد: جاب را نمی‌بلعد، حذف
 *     نمی‌کند و اجرا نمی‌کند — دست‌نخورده در صف می‌ماند و نتیجهٔ
 *     processed=0/failed=0/skipped=0 است (تفکیک‌پذیر از صفِ خالی با
 *     باقی‌ماندن ردیف در جدول queues).
 */
final class QueueWorkerMemoryGuardRuntimeTest extends TestCase
{
    private Database $db;
    private Cache $cache;
    private string $marker;
    private int $outputBufferLevel;

    protected function setUp(): void
    {
        parent::setUp();
        $this->outputBufferLevel = ob_get_level();
        ob_start();
        ini_set('error_log', sys_get_temp_dir() . '/chortke-queue-memguard-test.log');

        $container = Application::getInstance()->container;
        $this->db = $container->make(Database::class);
        $this->cache = $container->make(Cache::class);
        $this->marker = 'phpunit_memguard_' . bin2hex(random_bytes(8));

        $this->assertSame(
            'database',
            config('queue.driver', 'database'),
            'Runtime queue tests require the real database queue driver.'
        );
    }

    protected function tearDown(): void
    {
        if (isset($this->marker)) {
            $like = '%' . $this->marker . '%';
            $this->db->query('DELETE FROM failed_jobs WHERE payload LIKE ?', [$like]);
            $this->db->query('DELETE FROM queues WHERE payload LIKE ?', [$like]);
            $this->db->query('DELETE FROM system_settings WHERE `key` = ?', [$this->marker]);
        }
        if (isset($this->cache)) {
            $this->cache->forget('queue_size_cache:runtime_memguard');
        }
        while (isset($this->outputBufferLevel) && ob_get_level() > $this->outputBufferLevel) {
            ob_end_clean();
        }
        parent::tearDown();
    }

    /**
     * قرارداد استقرارِ پروسهٔ تست: آستانهٔ گیت حافظه باید (الف) حداقل ۲ برابرِ
     * ردپای واقع‌بینانهٔ سوئیت باشد و (ب) در لحظهٔ اجرا از حافظهٔ واقعیِ
     * پروسه بیشتر باشد. اگر روزی سوئیت چنان رشد کند که از 512MB عبور کند،
     * این تست با پیام روشن شکست می‌خورد — نه ۹ شکست خاموشِ processed=0.
     */
    public function test_process_guard_threshold_covers_full_suite_memory_footprint(): void
    {
        $thresholdBytes = int_value(config('queue.memory_limit_mb', 128)) * 1024 * 1024;

        $this->assertGreaterThan(
            256 * 1024 * 1024,
            $thresholdBytes,
            'QUEUE_MEMORY_LIMIT_MB در قرارداد محیط تست (bootstrap/testing.php) باید ≥ 256MB باشد '
            . 'تا رشد طبیعی سوئیت آن را عبور نکند (FIX-YAFTE22).'
        );

        $this->assertGreaterThan(
            memory_get_usage(true),
            $thresholdBytes,
            'آستانهٔ گیت حافظه باید از حافظهٔ واقعیِ لحظهٔ اجرای پروسهٔ تست بیشتر باشد؛ '
            . 'وگرنه QueueWorker::work() به‌صورت خاموش processed=0/failed=0 برمی‌گرداند (FIX-YAFTE22).'
        );
    }

    /**
     * رفتار خودِ گیت با آستانهٔ عمداً پایین: ورکر باید قبل از pop متوقف شود —
     * جاب نه اجرا می‌شود، نه fail می‌شود، نه حذف/بلعیده می‌شود؛ دست‌نخورده در
     * صف می‌ماند (تفکیک‌پذیر از صفِ خالی) و هیچ ردی از اجرا در system_settings نیست.
     */
    public function test_memory_guard_trips_before_pop_and_leaves_job_untouched_in_queue(): void
    {
        $originalThreshold = int_value(config('queue.memory_limit_mb', 128));
        $queueName = 'runtime_memguard';
        $container = Application::getInstance()->container;
        $queue = $container->make(Queue::class);

        try {
            // آستانه را عمداً زیر حافظهٔ واقعی هر پروسهٔ بوت‌شده می‌بریم (۱MB)
            config_set('queue.memory_limit_mb', 1);

            $this->assertTrue($queue->push(
                RuntimeProbeJob::class,
                ['marker' => $this->marker],
                $queueName
            ));

            $worker = $container->make(QueueWorker::class);
            $result = $worker->work($queueName, 5, [RuntimeProbeJob::class]);

            $this->assertSame(0, int_value($result['processed_jobs'] ?? -1));
            $this->assertSame(0, int_value($result['failed_jobs'] ?? -1));
            $this->assertSame(0, int_value($result['skipped_jobs'] ?? -1));

            // جاب باید دست‌نخورده در صف باقی مانده باشد (گیت قبل از pop می‌شکند)
            $this->assertSame(
                1,
                (int) $this->db->fetchColumn(
                    'SELECT COUNT(*) FROM queues WHERE payload LIKE ?',
                    ['%' . $this->marker . '%']
                ),
                'A memory-guard stop must leave the job queued — it must not consume or delete it.'
            );

            // و هیچ اجرایی رخ نداده است (probe در system_settings ردی نمی‌گذارد)
            $this->assertFalse(
                (bool) $this->db->fetch(
                    'SELECT `value` FROM system_settings WHERE `key` = ?',
                    [$this->marker]
                ),
                'A memory-guard stop must not execute the job.'
            );

            $this->assertSame(1, $queue->size($queueName));
        } finally {
            config_set('queue.memory_limit_mb', $originalThreshold);
        }
    }
}
