<?php

declare(strict_types=1);

namespace Tests\Integration\Queue;

use Core\Application;
use Core\Cache;
use Core\Database;
use Core\Queue;
use PHPUnit\Framework\TestCase;

final class RedisQueueRuntimeTest extends TestCase
{
    public function test_real_redis_queue_push_pop_delete_lifecycle_never_uses_database_queue(): void
    {
        $container = Application::getInstance()->container;
        $cache = $container->make(Cache::class);
        $db = $container->make(Database::class);
        $redis = $cache->redis();

        $this->assertInstanceOf(\Redis::class, $redis);
        $queueName = 'phase20.redis.' . bin2hex(random_bytes(6));
        $prefix = 'chortke:queue';
        $jobId = null;
        $queue = new Queue($db, $cache, 'redis');

        try {
            $this->assertSame(0, (int)$db->fetchColumn(
                'SELECT COUNT(*) FROM queues WHERE queue = ?',
                [$queueName]
            ));

            $this->assertTrue($queue->push(
                'App\\Jobs\\LogPerformanceJob',
                ['probe' => 'phase20'],
                $queueName
            ));
            $this->assertSame(1, $queue->size($queueName));

            $job = $queue->pop($queueName);
            $this->assertNotNull($job);
            $jobId = int_value($job['id'] ?? 0);
            $this->assertGreaterThan(0, $jobId);
            $this->assertSame('App\\Jobs\\LogPerformanceJob', $job['job']);
            $this->assertSame(['probe' => 'phase20'], $job['data']);
            $this->assertSame(1, $job['attempts']);

            $this->assertSame(0, (int)$db->fetchColumn(
                'SELECT COUNT(*) FROM queues WHERE queue = ?',
                [$queueName]
            ));
            $this->assertTrue($queue->delete($jobId));
            $this->assertSame(0, $queue->size($queueName));
        } finally {
            $members = $redis->zRange($prefix . ':' . $queueName . ':pending', 0, -1);
            if (is_array($members)) {
                foreach ($members as $member) {
                    $redis->del($prefix . ':job:' . $member);
                }
            }
            $members = $redis->zRange($prefix . ':' . $queueName . ':reserved', 0, -1);
            if (is_array($members)) {
                foreach ($members as $member) {
                    $redis->del($prefix . ':job:' . $member);
                }
            }
            if ($jobId !== null) {
                $redis->del($prefix . ':job:' . $jobId);
            }
            $redis->del($prefix . ':' . $queueName . ':pending');
            $redis->del($prefix . ':' . $queueName . ':reserved');
            $redis->del($prefix . ':job_id_counter');
            $cache->forget('queue_size_cache:' . $queueName);
        }
    }

    /**
     * FIX-9a-3: توکن مالکیت رزرو — روی Redis واقعی: هر pop توکن یکتا می‌سازد و
     * عملیات چرخهٔ عمر با توکن نامطابق رد می‌شود (compare-and-act) و با توکن
     * درست انجام می‌شود.
     */
    public function test_reservation_token_gates_lifecycle_operations_on_real_redis(): void
    {
        $container = Application::getInstance()->container;
        $cache = $container->make(Cache::class);
        $db = $container->make(Database::class);
        $redis = $cache->redis();

        $this->assertInstanceOf(\Redis::class, $redis);
        $queueName = 'phase20.rt.' . bin2hex(random_bytes(6));
        $prefix = 'chortke:queue';
        $queue = new Queue($db, $cache, 'redis');
        $popToken = null;

        try {
            $this->assertTrue($queue->push('App\\Jobs\\LogPerformanceJob', ['probe' => 'rt'], $queueName));

            $job = $queue->pop($queueName);
            $this->assertNotNull($job);
            $jobId = int_value($job['id']);
            $popToken = $job['reservation_token'] ?? null;
            $this->assertIsString($popToken);
            $this->assertNotSame('', $popToken);

            // توکن نامطابق: keepAlive و delete هر دو رد می‌شوند و رزرو دست‌نخورده می‌ماند
            $this->assertFalse($queue->keepAlive($jobId, $queueName, 300, str_repeat('f', 32)));
            $this->assertFalse($queue->delete($jobId, str_repeat('f', 32)));
            $this->assertSame(1, $queue->size($queueName));

            // توکن درست: تمدید visibility مجاز است
            $this->assertTrue($queue->keepAlive($jobId, $queueName, 300, $popToken));

            // release با توکن نامطابق رد می‌شود؛ با توکن درست جاب به pending برمی‌گردد
            $this->assertFalse($queue->release($jobId, 30, str_repeat('f', 32)));
            $this->assertTrue($queue->release($jobId, 30, $popToken));
            $this->assertSame(1, $queue->size($queueName));

            // پاپِ دوم: جابِ تازه push می‌شود (جابِ released دارای delay است) —
            // توکنِ جدید؛ توکنِ رانِ قبلی دیگر مالکیت ندارد
            $this->assertTrue($queue->push('App\\Jobs\\LogPerformanceJob', ['probe' => 'rt2'], $queueName));
            $job2 = $queue->pop($queueName);
            $this->assertNotNull($job2, 'Job must be re-poppable after token-gated release');
            $job2Id = int_value($job2['id']);
            $token2 = $job2['reservation_token'] ?? null;
            $this->assertIsString($token2);
            $this->assertNotSame($popToken, $token2);

            // ack با توکنِ منقضی رد می‌شود؛ ack با توکنِ درست حذف نهایی می‌کند
            // (جابِ اول هنوز در pending با delay است ⇒ size نهایی ۱)
            $this->assertFalse($queue->delete($job2Id, $popToken));
            $this->assertTrue($queue->delete($job2Id, $token2));
            $this->assertSame(1, $queue->size($queueName));
            $popToken = null; // cleanup اداره می‌شود
        } finally {
            $members = $redis->zRange($prefix . ':' . $queueName . ':pending', 0, -1);
            if (is_array($members)) {
                foreach ($members as $member) {
                    $redis->del($prefix . ':job:' . $member);
                    $redis->del($prefix . ':job:rt:' . $member);
                }
            }
            $members = $redis->zRange($prefix . ':' . $queueName . ':reserved', 0, -1);
            if (is_array($members)) {
                foreach ($members as $member) {
                    $redis->del($prefix . ':job:' . $member);
                    $redis->del($prefix . ':job:rt:' . $member);
                }
            }
            if ($popToken !== null && isset($jobId)) {
                $redis->del($prefix . ':job:' . $jobId);
                $redis->del($prefix . ':job:rt:' . $jobId);
            }
            $redis->del($prefix . ':' . $queueName . ':pending');
            $redis->del($prefix . ':' . $queueName . ':reserved');
            $cache->forget('queue_size_cache:' . $queueName);
        }
    }
}
