<?php

declare(strict_types=1);

namespace Tests\Integration\Core;

use Core\Database;
use PDO;
use PDOException;
use PHPUnit\Framework\TestCase;

/**
 * FIX-MODULE1-H1 + FIX-MODULE1-H2 regression tests (module1 deep review docx).
 *
 * H1 — write-after-lost-connection must be FAIL-CLOSED:
 *      the old code blindly re-executed ANY statement (including
 *      INSERT/UPDATE) after reconnecting on "server has gone away";
 *      an unknown-outcome write could then be applied twice (e.g.
 *      balance = balance + ?). New contract: only read-only statements
 *      are retried; writes rethrow so the caller/idempotency layer decides.
 *
 * H2 — nested rollback must NOT doom the parent transaction:
 *      the old rollback() at nested level set the global isRollbackOnly
 *      flag, so Model::createOrFetchAtomically()'s unique-race recovery
 *      (savepoint rollback + fetch winner) poisoned the outer commit and
 *      the whole business operation was rolled back for no reason.
 *      New contract: nested rollback rolls back ONLY its own savepoint;
 *      poisoning the root is an explicit markRollbackOnly() decision.
 *
 * @group integration
 * @requires extension pdo_mysql
 */
final class Module1H1H2TransactionSafetyTest extends TestCase
{
    private ?PDO $killer = null;

    protected function tearDown(): void
    {
        $this->killer = null;
        // FIX (بهداشت تست): cleanup() فقط «ابتدای» هر تست اجرا می‌شد — جدول‌های
        // tmp_* تستِ آخر کلاس در دیتابیس می‌ماندند و شمارش جدولِ
        // RuntimeInfrastructurePreflightTest را آلوده می‌کردند (263 vs 262).
        try {
            $this->cleanup();
        } catch (\Throwable) {
            // teardown هرگز نباید خود تست را شکست بدهد
        }
        Database::reset();
        parent::tearDown();
    }

    private function freshDb(): Database
    {
        Database::reset();

        // FIX-PRE-1b (core DSN drift): همان کلاسِ باگِ سه تستِ migration/rbac —
        // اعتبارنامهٔ هاردکدِ «chortke»/«chortke_dev» هیچ‌جا provision نمی‌شد.
        return Database::getInstance([
            'host'    => getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1',
            'port'    => (int)(getenv('CHORTKE_TEST_DB_PORT') ?: 3306),
            'name'    => getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk',
            'user'    => getenv('CHORTKE_TEST_DB_USER') ?: 'root',
            'pass'    => getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : '',
            'charset' => 'utf8mb4',
        ]);
    }

    private function cleanup(): void
    {
        $pdo = $this->connection();
        $pdo->exec('DROP TABLE IF EXISTS tmp_module1_h1');
        $pdo->exec('DROP TABLE IF EXISTS tmp_module1_h2');
    }

    private function connection(): PDO
    {
        // FIX-PRE-1b: اعتبارنامهٔ کانونیکال سوئیت (root/خالی) — هم‌تراز با bootstrap/testing.php
        return new PDO(
            'mysql:host=' . (getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1') . ';dbname=' . ((getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk')),
            (getenv('CHORTKE_TEST_DB_USER') ?: 'root'),
            (getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : ''),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }

    // ── H2 ────────────────────────────────────────────────────────────────

    public function test_h2_nested_rollback_does_not_doom_parent_commit(): void
    {
        $this->cleanup();
        $this->connection()->exec(
            'CREATE TABLE tmp_module1_h2 (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tag VARCHAR(32) NOT NULL UNIQUE,
                marker VARCHAR(16) NOT NULL
             ) ENGINE=InnoDB'
        );

        $db = $this->freshDb();

        // Parent transaction owns the real business write.
        $db->beginTransaction();
        $db->execute(
            "INSERT INTO tmp_module1_h2 (tag, marker) VALUES ('race-key', 'outer')"
        );

        // لاگ استاندارد خطای SQL در CLI به stdout اکو می‌شود (رفتار Twelve-Factor
        // LogService) — این تست «عمداً» خطای UNIQUE می‌سازد؛ خروجی لاگِ آن لحظه
        // بافر و دور ریخته می‌شود تا PHPUnit آن را «خروجی غیرمنتظره» نشمارد
        // (لاگ تولیدی رفتار صحیح production است؛ تغییر آن لازم نیست).
        ob_start();
        try {
            // Helper (same contract as Model::createOrFetchAtomically):
            // opens its own nested transaction, INSERT hits the UNIQUE
            // violation, rolls back ITS OWN savepoint and recovers by
            // fetching the winner.
            $db->beginTransaction();
            try {
                $db->execute(
                    "INSERT INTO tmp_module1_h2 (tag, marker) VALUES ('race-key', 'helper')"
                );
                $this->fail('Expected UNIQUE-violation PDOException inside helper');
            } catch (PDOException $e) {
                $db->rollback(); // nested level → ROLLBACK TO SAVEPOINT only
            }
        } finally {
            ob_end_clean();
        }
        $winner = $db->fetchColumn(
            "SELECT marker FROM tmp_module1_h2 WHERE tag = 'race-key'"
        );
        $this->assertSame('outer', $winner, 'helper must recover the parent winner');

        // OLD code: commit() here threw 'Cannot commit transaction: nested
        // rollback occurred' and silently destroyed the parent work.
        $db->commit();

        $pdo = $this->connection();
        $this->assertSame(
            1,
            (int) $pdo->query("SELECT COUNT(*) FROM tmp_module1_h2 WHERE tag = 'race-key'")->fetchColumn(),
            'exactly one row survives the parent commit'
        );
        $this->assertSame(
            'outer',
            $pdo->query("SELECT marker FROM tmp_module1_h2 WHERE tag = 'race-key'")->fetchColumn(),
            'parent write must be committed, not doomed by nested rollback'
        );
    }

    public function test_h2_explicit_mark_rollback_only_still_dooms_commit(): void
    {
        $this->cleanup();
        $this->connection()->exec(
            'CREATE TABLE tmp_module1_h2 (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tag VARCHAR(32) NOT NULL UNIQUE,
                marker VARCHAR(16) NOT NULL
             ) ENGINE=InnoDB'
        );

        $db = $this->freshDb();
        $db->beginTransaction();
        $db->execute("INSERT INTO tmp_module1_h2 (tag, marker) VALUES ('doom', 'x')");
        $db->markRollbackOnly();

        try {
            $db->commit();
            $this->fail('commit() after explicit markRollbackOnly() must throw');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsString('rollback', $e->getMessage());
        }

        $this->assertSame(
            0,
            (int) $this->connection()->query('SELECT COUNT(*) FROM tmp_module1_h2')->fetchColumn(),
            'explicitly doomed transaction must leave no rows'
        );
    }

    // ── H1 ────────────────────────────────────────────────────────────────

    private function killBackendConnection(Database $db): void
    {
        $connId = (int) $db->fetchColumn('SELECT CONNECTION_ID()');
        $this->killer = $this->connection();
        $this->killer->exec("KILL {$connId}");
    }

    public function test_h1_write_with_lost_connection_is_not_retried(): void
    {
        $this->cleanup();
        $this->connection()->exec(
            'CREATE TABLE tmp_module1_h1 (
                id INT PRIMARY KEY,
                v INT NOT NULL DEFAULT 0
             ) ENGINE=InnoDB'
        );
        $this->connection()->exec('INSERT INTO tmp_module1_h1 (id, v) VALUES (1, 0)');

        $db = $this->freshDb();
        // Warm the connection and take note of its backend thread.
        $this->assertSame(1, (int) $db->fetchColumn('SELECT COUNT(*) FROM tmp_module1_h1'));
        $this->killBackendConnection($db);

        // OLD code: lost-connection on a write outside a transaction was
        // silently re-executed after reconnect (unknown outcome → duplicate
        // application risk). NEW contract: writes fail closed — the
        // exception must propagate to the caller.
        // (خروجی لاگِ عمدیِ خطای SQL در CLI بافر می‌شود — هم‌دلیل تست H2)
        $thrown = null;
        ob_start();
        try {
            try {
                $db->execute('UPDATE tmp_module1_h1 SET v = v + 1 WHERE id = 1');
                $this->fail('write after lost connection must not be blindly retried');
            } catch (PDOException $e) {
                $thrown = $e;
            }
        } finally {
            ob_end_clean();
        }
        $this->assertNotNull($thrown, 'write must fail closed, not silently retry');
        $this->assertSame(
            0,
            (int) $this->connection()->query('SELECT v FROM tmp_module1_h1 WHERE id = 1')->fetchColumn(),
            'the killed statement must not have been applied by a blind retry'
        );

        // Connection is restored lazily for subsequent statements.
        $this->assertSame(1, (int) $db->fetchColumn('SELECT COUNT(*) FROM tmp_module1_h1'));
    }

    public function test_h1_read_with_lost_connection_is_still_retried(): void
    {
        $this->cleanup();
        $this->connection()->exec(
            'CREATE TABLE tmp_module1_h1 (
                id INT PRIMARY KEY,
                v INT NOT NULL DEFAULT 0
             ) ENGINE=InnoDB'
        );
        $this->connection()->exec('INSERT INTO tmp_module1_h1 (id, v) VALUES (1, 7)');

        $db = $this->freshDb();
        $this->assertSame(7, (int) $db->fetchColumn('SELECT v FROM tmp_module1_h1 WHERE id = 1'));
        $this->killBackendConnection($db);

        // Reads are idempotent and may still be auto-retried after a
        // transparent reconnect.
        $this->assertSame(
            7,
            (int) $db->fetchColumn('SELECT v FROM tmp_module1_h1 WHERE id = 1'),
            'read after lost connection should succeed via reconnect+retry'
        );
    }
}
