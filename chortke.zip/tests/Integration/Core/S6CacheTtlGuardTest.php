<?php

declare(strict_types=1);

namespace Tests\Integration\Core;

use Core\Cache;
use PHPUnit\Framework\TestCase;

/**
 * بچ S6 — راستی‌آزمایی runtime فیکس FIX-S6-3 (یادداشت معلق S3) روی Redis واقعی
 *
 * الگوی تبعیض‌کنندهٔ قبل/بعد فیکس:
 *   - قبل: Cache::put($key, $value, 0) در مسیر Redis به setEx با ttl=0 می‌رسید و
 *     RedisException می‌داد؛ مسیر فایل همان ورودی را «منقضی‌شده» ذخیره می‌کرد که
 *     عملاً هرگز خواندنی نیست. یعنی دو بک‌اند دو رفتار متفاوت.
 *   - بعد: هر دو بک‌اند معنای یکسان دارند — put با ttl<=0 یعنی forget (هم‌راستا با
 *     قرارداد درونی setSeconds/rememberSeconds). remember با ttl<=0 هم بدون کرش
 *     مقدار محاسبه‌شده را برمی‌گرداند (فقط ذخیره نمی‌کند).
 */
final class S6CacheTtlGuardTest extends TestCase
{
    private Cache $cache;

    /** @var list<string> */
    private array $keys = [];

    protected function setUp(): void
    {
        parent::setUp();
        $this->cache = Cache::getInstance();
    }

    protected function tearDown(): void
    {
        foreach ($this->keys as $key) {
            $this->cache->forget($key);
        }
        parent::tearDown();
    }

    private function track(string $key): string
    {
        $this->keys[] = $key;
        return $key;
    }

    public function test_put_with_zero_ttl_does_not_throw_and_value_is_absent(): void
    {
        $key = $this->track('s6_ttl_guard_zero_' . uniqid());

        // مقدار قبلی موجود است — put با ttl=0 باید آن را هم حذف کند (forget)
        $this->assertTrue($this->cache->put($key, 'before', 5));
        $this->assertSame('before', $this->cache->get($key));

        $this->assertTrue($this->cache->put($key, 'after', 0));
        $this->assertNull($this->cache->get($key), 'بعد از put با ttl=0 هیچ مقداری خواندنی نباید باشد');
        $this->assertFalse($this->cache->has($key));
    }

    public function test_put_with_negative_ttl_forgets_existing_value(): void
    {
        $key = $this->track('s6_ttl_guard_neg_' . uniqid());

        $this->assertTrue($this->cache->put($key, 'v', 5));
        $this->assertTrue($this->cache->put($key, 'v', -3));
        $this->assertNull($this->cache->get($key));
    }

    public function test_remember_with_zero_minutes_returns_computed_value_without_crash(): void
    {
        $key = $this->track('s6_ttl_guard_remember_' . uniqid());

        $calls = 0;
        $result = $this->cache->remember($key, 0, static function () use (&$calls): string {
            $calls++;
            return 'computed';
        });

        $this->assertSame('computed', $result);
        $this->assertSame(1, $calls, 'callback باید دقیقاً یک بار اجرا شود');
        $this->assertNull($this->cache->get($key), 'با ttl=0 نباید چیزی ذخیره شود');
    }

    public function test_positive_ttl_still_stores_value(): void
    {
        // گارد ضد over-blocking: مسیر عادی put باید مثل قبل کار کند
        $key = $this->track('s6_ttl_guard_positive_' . uniqid());

        $this->assertTrue($this->cache->put($key, 'normal', 5));
        $this->assertSame('normal', $this->cache->get($key));
        $this->assertTrue($this->cache->has($key));
    }
}
