<?php

declare(strict_types=1);

namespace Tests\Integration\Core;

use Core\Cache;
use Core\Database;
use Core\IdempotencyKey;
use PHPUnit\Framework\TestCase;

/**
 * 🔒 AUDIT-FIX (financial audit R10-P1) — پینِ رگرسیونِ «هرگز نتیجهٔ شکست در
 * completed ذخیره نشود».
 *
 * باگ پین‌شده: IdempotencyKey::wrapInstance() هر خروجی callback (شامل آرایه‌های
 * success=false / ok=false که سرویس‌های مالی برمی‌گردانند) را با complete() در
 * وضعیت completed ذخیره می‌کرد؛ retry مشروعِ کاربر همان پاسخ شکست را به‌عنوان
 * «نتیجهٔ نهایی cache‌شده» می‌گرفت و در escrow وجه locked می‌ماند.
 *
 * قرارداد جدید: خروجی شکست → fail(retryable=true) ⇒ ردیف failed_retryable می‌شود
 * و پس از پنجرهٔ RETRY_DELAY_SECONDS اجرای مجدد callback ممکن است. خروجی موفق
 * مثل قبل completed می‌شود. پاسخِ همان فراخوانی هم آرایهٔ شکست باقی می‌ماند.
 */
final class IdempotencyFailureResultDatabaseTest extends TestCase
{
    private IdempotencyKey $idempotency;

    private Database $db;

    /** @var list<string> */
    private array $usedKeys = [];

    protected function setUp(): void
    {
        $app = \Core\Application::getInstance();
        $this->db = $app->container->make(Database::class);
        $this->idempotency = new IdempotencyKey($this->db, Cache::getInstance());
        // لاگر مسیر idempotency در محیط تست روی stdout چاپ می‌کند — همان الگوی
        // IdempotencySignatureRuntimeTest (خروجی آزاد، بدون خطای strict-output).
        $this->expectOutputRegex('/.*/');
    }

    protected function tearDown(): void
    {
        foreach ($this->usedKeys as $key) {
            try {
                $this->db->execute("DELETE FROM idempotency_keys WHERE `key` = ?", [$key]);
            } catch (\Throwable $ignored) {
            }
        }
        parent::tearDown();
    }

    private function statusOf(string $key): ?string
    {
        $row = $this->db->fetch("SELECT status FROM idempotency_keys WHERE `key` = ?", [$key]);
        return $row === null ? null : (string)$row->status;
    }

    public function test_failure_array_result_is_stored_as_failed_retryable_not_completed(): void
    {
        $key = 'audit_idem_fail_' . bin2hex(random_bytes(6));
        $this->usedKeys[] = $key;

        $result = $this->idempotency->wrapInstance($key, 999901, 'audit.test', static function () {
            return ['ok' => false, 'error' => 'خطای گذرای شبیه‌سازی‌شده'];
        });

        // قرارداد پاسخ اول حفظ می‌شود: آرایهٔ شکست به فراخواننده می‌رسد
        $this->assertFalse($result['ok']);
        // اما هرگز در completed ذخیره نمی‌شود
        $this->assertSame('failed_retryable', $this->statusOf($key), 'نتیجهٔ شکست نباید completed شود (باید retryable باشد)');
    }

    public function test_success_false_array_result_is_also_stored_as_failed_retryable(): void
    {
        $key = 'audit_idem_fail2_' . bin2hex(random_bytes(6));
        $this->usedKeys[] = $key;

        $result = $this->idempotency->wrapInstance($key, 999901, 'audit.test', static function () {
            return ['success' => false, 'message' => 'شکست کاری'];
        });

        $this->assertFalse($result['success']);
        $this->assertSame('failed_retryable', $this->statusOf($key));
    }

    public function test_successful_result_is_stored_as_completed(): void
    {
        $key = 'audit_idem_ok_' . bin2hex(random_bytes(6));
        $this->usedKeys[] = $key;

        $calls = 0;
        $result = $this->idempotency->wrapInstance($key, 999901, 'audit.test', static function () use (&$calls) {
            $calls++;
            return ['ok' => true, 'amount' => '1000'];
        });

        $this->assertTrue($result['ok']);
        $this->assertSame(1, $calls);
        $this->assertSame('completed', $this->statusOf($key));

        // فراخوانی مجدد = duplicate موفق (بدون اجرای مجدد callback)
        $second = $this->idempotency->wrapInstance($key, 999901, 'audit.test', static function () use (&$calls) {
            $calls++;
            return ['ok' => true, 'amount' => 'SHOULD_NOT_RUN'];
        });
        $this->assertSame(1, $calls, 'callback برای duplicate موفق نباید دوباره اجرا شود');
        $this->assertSame('1000', $second['amount'] ?? null);
    }

    public function test_thrown_exception_is_still_failed_retryable_and_rethrown(): void
    {
        $key = 'audit_idem_throw_' . bin2hex(random_bytes(6));
        $this->usedKeys[] = $key;

        try {
            $this->idempotency->wrapInstance($key, 999901, 'audit.test', static function () {
                throw new \RuntimeException('boom');
            });
            $this->fail('exception باید rethrow شود');
        } catch (\RuntimeException $e) {
            $this->assertSame('boom', $e->getMessage());
        }

        $this->assertContains($this->statusOf($key), ['failed_retryable', 'failed_final'], 'شکست استثنایی هم نباید completed شود');
    }
}
