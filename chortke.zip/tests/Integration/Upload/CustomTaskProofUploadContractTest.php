<?php

declare(strict_types=1);

namespace Tests\Integration\Upload;

use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBCTR-01: پین‌های امنیتی آپلود مدرک — منطق از کنترلر وب به
 * CustomTaskProofFileService (تک‌منبع مشترک وب/موبایل) منتقل شد؛ همان
 * ادعاها حالا روی سرویس پین می‌شوند (port coverage، نه حذف پوشش).
 */
final class CustomTaskProofUploadContractTest extends TestCase
{
    public function test_video_proof_does_not_allow_generic_octet_stream(): void
    {
        $source = file_get_contents(base_path('app/Services/CustomTask/CustomTaskProofFileService.php'));
        $this->assertIsString($source);
        $this->assertStringNotContainsString("'application/octet-stream'", $source);
        $this->assertStringContainsString("'video/mp4'", $source);
        $this->assertStringContainsString("'video/webm'", $source);
        $this->assertStringContainsString("'video/quicktime'", $source);
    }

    public function test_proof_storage_is_private_and_filename_is_random_hex(): void
    {
        $proofService = file_get_contents(base_path('app/Services/CustomTask/CustomTaskProofFileService.php'));
        $uploadService = file_get_contents(base_path('app/Services/UploadService.php'));
        $this->assertIsString($proofService);
        $this->assertIsString($uploadService);
        $this->assertStringContainsString("uploadPrivateDocument", $uploadService);
        $this->assertStringContainsString("'task-proofs'", $proofService);
        $this->assertStringContainsString("bin2hex(random_bytes(12))", $uploadService);
        $this->assertStringContainsString('chmod($dest[\'fullPath\'], 0640)', $uploadService);
    }
}
