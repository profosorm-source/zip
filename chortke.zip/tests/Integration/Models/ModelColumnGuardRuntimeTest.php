<?php

declare(strict_types=1);

namespace Tests\Integration\Models;

use App\Models\PaymentGateway;
use App\Models\SecurityLog;
use Core\Application;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * W4-F (F-A2-08) — تست مسیرِ Runtime Column Guard روی مدل‌های واقعی
 * (MariaDB زنده) — «تست مسیر» خواسته‌شدهٔ کارفرما.
 *
 * مدل‌های انتخابی (هر دو بدون override و بدون $fillable → مسیرِ پایهٔ
 * core/Model::create/update + گارد، و گاردِ فقط-مجموعهٔ-نوشتنی):
 *  ● PaymentGateway  → جدول payment_gateways (create + update + firstOrCreate)
 *  ● SecurityLog     → جدول security_logs (create؛ جدول بدون updated_at است —
 *                      گارد فقط مسیر create را می‌بیند و update پایه روی این
 *                      جدول استفاده نمی‌شود)
 *
 * پین‌ها:
 *  ① رفتار سالم عیناً مثل قبل: create/update واقعاً می‌نویسند و می‌خوانند (zero behavior change).
 *  ② کلید ناشناخته → \InvalidArgumentException با پیام دقیق (جدول/ستون/مدل/عملیات)
 *     و FAIL FAST: هیچ INSERT/UPDATE جزئی به DB نمی‌رسد (شمارش ردیف = 0 / ردیف دست‌نخورده).
 *  ③ firstOrCreate/updateOrCreate (funnel به create/update) هم گارد-دار است.
 *  ④ کش اسکیما per-request + مشترک: هر جدول یک‌بار در پنجرهٔ TTL خوانده می‌شود
 *     (تست‌های شمارش در tests/Unit/Models/ModelColumnGuardTest.php با counting PDO).
 *
 * ایدیم خانه: tests/Integration/Models/ModelBoundaryContractsRuntimeTest.php —
 * DB واقعی از container + کلید یکتا + پاک‌سازی صریح در tearDown (بدون trash روی DB زنده).
 */
final class ModelColumnGuardRuntimeTest extends TestCase
{
    private Database $db;
    private string $slug;
    private string $message;
    private string $message2;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Application::getInstance()->container->make(Database::class);
        $suffix = random_int(1000000, 9999999);
        $this->slug = 'w4f-guard-' . $suffix;
        $this->message = 'W4F-GUARD-' . $suffix;
        $this->message2 = 'W4F-GUARD2-' . $suffix;

        /*
        | FIX-YAFTE4 (یافته ۴): قرارداد FIX-S9-03 — مدل‌های بدون $fillable
        | (PaymentGateway/SecurityLog) به‌صورت deny-by-default می‌نویسند [].
        | این تست گاردِ ستون را پین می‌کند؛ opt-in با API عمومی unguard/reguard
        | (هم‌قرارداد FIX-M1M25؛ reguard تضمینی در tearDown) — گاردِ ستون مستقل
        | از فیلتر fillable اجرا می‌شود، پس پین‌های این سوئیت دست‌نخورده می‌مانند.
        */
        \App\Models\PaymentGateway::unguard(true);
        \App\Models\SecurityLog::unguard(true);

        // شروع سردِ کشِ استاتیک گارد — مسیر کامل introspection در هر تست دیده شود
        Database::resetTableColumnsCache();
    }

    protected function tearDown(): void
    {
        // FIX-YAFTE4: بازگرداندن حالت guarded (بدون نشست state بین تست‌ها)
        \App\Models\PaymentGateway::reguard();
        \App\Models\SecurityLog::reguard();
        if (isset($this->db)) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            $this->db->execute('DELETE FROM payment_gateways WHERE slug = ?', [$this->slug]);
            $this->db->execute('DELETE FROM security_logs WHERE message = ?', [$this->message]);
            $this->db->execute('DELETE FROM security_logs WHERE message = ?', [$this->message2]);
        }
        Database::resetTableColumnsCache();
        parent::tearDown();
    }

    private function countPaymentGateways(string $slug): int
    {
        return (int)$this->db->fetchColumn(
            'SELECT COUNT(*) FROM payment_gateways WHERE slug = ?',
            [$slug]
        );
    }

    private function countSecurityLogs(string $message): int
    {
        return (int)$this->db->fetchColumn(
            'SELECT COUNT(*) FROM security_logs WHERE message = ?',
            [$message]
        );
    }

    // ─────────────────────────────────────────────────────────────
    // ① مسیرهای سالم — zero behavior change
    // ─────────────────────────────────────────────────────────────

    public function test_payment_gateway_create_and_update_roundtrip_through_guard(): void
    {
        $model = new PaymentGateway($this->db);
        $this->assertTrue($model->isStrictColumns(), 'پیش‌فرض گارد باید STRICT باشد');

        $id = $model->create([
            'name' => $this->slug,
            'slug' => $this->slug,
            'config' => '{"merchant":"w4f","timeout":15}',
            'is_active' => 1,
        ]);
        $this->assertIsInt($id);
        $this->assertGreaterThan(0, $id);

        $row = $model->find($id);
        $this->assertNotNull($row);
        $this->assertSame($this->slug, (string)$row->slug);
        $this->assertSame(1, (int)$row->is_active);

        $ok = $model->update($id, ['is_active' => 0, 'callback_ips' => '10.0.0.1']);
        $this->assertTrue($ok);

        $row2 = $model->find($id);
        $this->assertNotNull($row2);
        $this->assertSame(0, (int)$row2->is_active);
        $this->assertSame('10.0.0.1', (string)$row2->callback_ips);
    }

    public function test_first_or_create_funnel_is_guarded_and_idempotent(): void
    {
        $model = new PaymentGateway($this->db);

        $created = $model->firstOrCreate(
            ['slug' => $this->slug],
            ['name' => $this->slug, 'config' => '{"via":"firstOrCreate"}']
        );
        $this->assertNotNull($created);
        $this->assertSame($this->slug, (string)$created->slug);
        $this->assertSame(1, $this->countPaymentGateways($this->slug));

        $again = $model->firstOrCreate(
            ['slug' => $this->slug],
            ['name' => 'should-not-change']
        );
        $this->assertSame((int)$created->id, (int)$again->id);
        $this->assertSame(1, $this->countPaymentGateways($this->slug));
    }

    // ─────────────────────────────────────────────────────────────
    // ② مسیر نقض — fail-fast بدون نوشتنِ جزئی
    // ─────────────────────────────────────────────────────────────

    public function test_create_with_unknown_column_fails_fast_without_partial_write(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger در تست
        $model = new PaymentGateway($this->db);

        try {
            $model->create(['name' => $this->slug, 'ghost_col_w4f' => 1]);
            $this->fail('Expected InvalidArgumentException for unknown column');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('[ColumnGuard]', $e->getMessage());
            $this->assertStringContainsString('INSERT', $e->getMessage());
            $this->assertStringContainsString('payment_gateways', $e->getMessage());
            $this->assertStringContainsString('`ghost_col_w4f`', $e->getMessage());
            $this->assertStringContainsString(PaymentGateway::class, $e->getMessage());
        }

        // FAIL FAST: گارد قبل از QueryBuilder::insert پرتاب شده — هیچ ردیفی نوشته نشده
        $this->assertSame(0, $this->countPaymentGateways($this->slug));
    }

    public function test_update_with_unknown_column_fails_fast_and_row_untouched(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger در تست
        $model = new PaymentGateway($this->db);
        $id = $model->create(['name' => $this->slug, 'slug' => $this->slug, 'is_active' => 1]);
        $this->assertIsInt($id);

        try {
            $model->update($id, ['is_active' => 0, 'ghost_col_w4f' => 2]);
            $this->fail('Expected InvalidArgumentException for unknown column');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('UPDATE', $e->getMessage());
            $this->assertStringContainsString('`ghost_col_w4f`', $e->getMessage());
            $this->assertStringContainsString('payment_gateways', $e->getMessage());
        }

        // ردیف دست‌نخورده: نه is_active تغییر کرده و نه UPDATE جزئی رفته
        $row = $model->find($id);
        $this->assertNotNull($row);
        $this->assertSame(1, (int)$row->is_active);
        $this->assertEmpty($row->callback_ips ?? '');
    }

    // ─────────────────────────────────────────────────────────────
    // ③ مدل دوم (SecurityLog) — create سالم + نقض
    // ─────────────────────────────────────────────────────────────

    public function test_security_log_create_passes_guard_and_unknown_column_throws(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger در تست
        $log = new SecurityLog($this->db);

        $id = $log->create([
            'level' => 'info',
            'message' => $this->message,
            'ip_address' => '127.0.0.1',
        ]);
        $this->assertTrue($id !== false && $id !== null);
        $this->assertSame(1, $this->countSecurityLogs($this->message));

        try {
            $log->create(['level' => 'info', 'message' => $this->message2, 'bogus_w4f' => 1]);
            $this->fail('Expected InvalidArgumentException for unknown column');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('security_logs', $e->getMessage());
            $this->assertStringContainsString('`bogus_w4f`', $e->getMessage());
            $this->assertStringContainsString(SecurityLog::class, $e->getMessage());
        }

        $this->assertSame(0, $this->countSecurityLogs($this->message2), 'نوشتنِ جزئی نباید اتفاق افتاده باشد');
    }

    // ─────────────────────────────────────────────────────────────
    // ④ Escape hatch روی مدل واقعی
    // ─────────────────────────────────────────────────────────────

    public function test_escape_hatch_on_real_model_routes_unknown_column_to_db(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger (database.insert.failed) در تست
        // Opt-out مستند: کلید ناشناخته به DB می‌رود و در آن‌جا fail-loud می‌شود
        // (42S22) — گارد درِ قطع دسترسی نیست؛ فقط مسیرِ پیش‌فرضِ STRICT را عوض می‌کند.
        $model = new PaymentGateway($this->db);
        $model->setStrictColumns(false);
        $this->assertFalse($model->isStrictColumns());

        try {
            $model->create(['name' => $this->slug, 'ghost_col_w4f' => 1]);
            $this->fail('Expected PDOException (42S22) from the database as the loud backstop');
        } catch (\InvalidArgumentException $e) {
            $this->fail('با opt-out، گارد نباید InvalidArgumentException بدهد: ' . $e->getMessage());
        } catch (\PDOException $e) {
            $this->assertStringContainsStringIgnoringCase('unknown column', $e->getMessage());
        }
    }
}
