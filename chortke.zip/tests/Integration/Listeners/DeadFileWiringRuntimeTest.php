<?php

declare(strict_types=1);

namespace Tests\Integration\Listeners;

use Core\Application;
use Core\EventDispatcher;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-S20-DEADFILE — تست قفل‌کنندهٔ اتصال لیسنرهای یتیم (روش کارفرما: تحقیق → اتصال)
 *
 * سه اتصال را قفل می‌کند:
 *  ۱) CacheInvalidateListener روی 'cache.invalidate' — ده تولیدکنندهٔ زنده تا دیروز
 *     بی‌شنونده بودند؛ اکنون dispatch واقعاً کلید را از Redis حذف می‌کند.
 *  ۲) InvalidateSearchCacheListener روی ۵ نامِ تولیدشده — dispatch باعث
 *     invalidateModuleSearch + invalidateSearch (فلش تگ 'search') می‌شود.
 *  ۳) 'influencer.profile_updated' به $projectionSyncEvents اضافه شد (جاافتادگی wiring).
 *  ۴) FIX-R22-B2: AuditCircuitBreakerState روی 'circuit_breaker.opened'/'closed'
 *     ثبت شد (core/CircuitBreaker.php:205/:144) — تغییر وضعیت breaker دیگر
 *     بی‌ردیپ نیست (لاگ + audit_trail).
 *  منفی: نام‌های مردهٔ نقشهٔ قبلی (مثل 'ad.created') باید همچنان بی‌شنونده بمانند
 *  تا فال‌بک flush-all با رویدادهای ناشناخته تریگر نشود.
 */
final class DeadFileWiringRuntimeTest extends TestCase
{
    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_cache_invalidate_event_is_wired_and_forgets_real_key(): void
    {
        $this->expectOutputRegex('/.*/'); // لاگر INFO به stdout می‌نویسد (الگوی تست‌های runtime موجود)
        $container = Application::getInstance()->container;
        $dispatcher = $container->make(EventDispatcher::class);
        $cache = $container->make(\Core\Cache::class);

        $this->assertNotSame(
            [],
            $dispatcher->getListeners('cache.invalidate'),
            'CacheInvalidateListener must be registered on cache.invalidate'
        );

        $key = 's20:cache_invalidate:' . uniqid('', true);
        $this->assertTrue($cache->putSeconds($key, ['sentinel' => 1], 60));
        $this->assertSame(['sentinel' => 1], $cache->get($key));

        $dispatcher->dispatch('cache.invalidate', ['key' => $key]);

        $this->assertNull($cache->get($key), 'cache.invalidate dispatch must forget the key');
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_search_cache_bust_events_are_wired_and_flush_search_tag(): void
    {
        $this->expectOutputRegex('/.*/'); // لاگر INFO به stdout می‌نویسد
        $container = Application::getInstance()->container;
        $dispatcher = $container->make(EventDispatcher::class);
        $cache = $container->make(\Core\Cache::class);

        foreach (['prediction.created', 'prediction.updated', 'lottery.created', 'ticket.created', \App\Events\TaskCompletedEvent::class] as $event) {
            $this->assertNotSame(
                [],
                $dispatcher->getListeners($event),
                "InvalidateSearchCacheListener must be registered on {$event}"
            );
        }

        $predictionKey = 's20:search:prediction:' . uniqid('', true);
        $lotteryKey = 's20:search:lottery:' . uniqid('', true);
        $this->assertTrue($cache->tags(['search', 'search:prediction'])->put($predictionKey, 1, 1));
        $this->assertTrue($cache->tags(['search', 'search:lottery'])->put($lotteryKey, 2, 1));

        $dispatcher->dispatch('prediction.created', ['id' => 42]);

        $this->assertNull($cache->get($predictionKey), 'prediction.created must invalidate module search cache');
        $this->assertNull($cache->get($lotteryKey), 'listener also flushes the whole search tag by design');
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_dead_mapping_names_stay_unwired(): void
    {
        $this->expectOutputRegex('/.*/'); // FIX-R22-B7: لاگر dispatcher هشدار event.no_listeners را به stdout می‌نویسد (الگوی سایر تست‌های همین فایل)
        $container = Application::getInstance()->container;
        $dispatcher = $container->make(EventDispatcher::class);
        $cache = $container->make(\Core\Cache::class);

        // ۲۰ نامِ مردهٔ نقشهٔ قبلی (FIX-S20-ISCL) نباید شنوندهٔ search-bust بگیرند؛
        // در کل کدبیس فقط 'ad.created' و 'seo_ad.approved' واقعاً صفر شنونده دارند
        // (نام‌های دیگرِ نقشهٔ قدیمی یا حذف شدند یا مثل coupon/investment/escrow
        // قانوناً شنوندهٔ SearchProjectionListener در bootstrap دارند).
        // نکته: مقایسه با count() انجام می‌شود — serialize آرایهٔ حاوی Closure
        // در پروتکل پروسهٔ فرزند PHPUnit فاجعه‌بار است (child ended unexpectedly).
        foreach (['ad.created', 'seo_ad.approved'] as $dead) {
            $this->assertSame(
                0,
                count($dispatcher->getListeners($dead)),
                "Dead mapping name {$dead} must stay unwired"
            );
        }

        $plainKey = 's20:plain:' . uniqid('', true);
        $this->assertTrue($cache->putSeconds($plainKey, 7, 60));
        $dispatcher->dispatch('ad.created', ['id' => 1]);
        $this->assertSame(7, $cache->get($plainKey), 'unwired event must be a no-op');
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_influencer_profile_updated_projection_event_is_wired(): void
    {
        $this->expectOutputRegex('/.*/'); // لاگر INFO به stdout می‌نویسد
        $container = Application::getInstance()->container;
        $dispatcher = $container->make(EventDispatcher::class);

        $this->assertNotSame(
            [],
            $dispatcher->getListeners('influencer.profile_updated'),
            'influencer.profile_updated must be wired to SearchProjectionListener (FIX-S20-DEADFILE)'
        );
    }

    /**
     * 🛡️ FIX-R22-B2 — تغییر وضعیت circuit breaker باید شنونده داشته باشد.
     *
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_circuit_breaker_state_events_are_wired(): void
    {
        $this->expectOutputRegex('/.*/');
        $container = Application::getInstance()->container;
        $dispatcher = $container->make(EventDispatcher::class);

        foreach (['circuit_breaker.opened', 'circuit_breaker.closed'] as $event) {
            $this->assertNotSame(
                [],
                $dispatcher->getListeners($event),
                "AuditCircuitBreakerState must be registered on {$event} (FIX-R22-B2)"
            );
        }
    }
}
