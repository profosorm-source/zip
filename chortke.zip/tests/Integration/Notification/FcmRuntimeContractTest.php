<?php

declare(strict_types=1);

namespace Tests\Integration\Notification;

use App\Adapters\Notification\FcmNotificationAdapter;
use App\Services\Notification\Channels\FcmChannel;
use App\Services\Notification\FcmService;
use Core\Application;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-02 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲): قرارداد این تست
 * از «یک دستگاه به‌ازای (user, platform)» به قرارداد چند-دستگاهی منتقل شد:
 *   * یکتایی = خودِ توکن FCM (uq_user_devices_fcm_token) — نه (user_id, platform)
 *   * کاربر می‌تواند چند دستگاه هم‌پلتفرم داشته باشد (گوشی + تبلت)
 *   * ثبتِ توکنِ دستگاهِ دیگری = انتقال مالکیت (لاگین حساب دیگر روی همان گوشی)
 * پین‌های قدیمی (uq_user_devices_user_platform + جایگزینی توکن دوم در همان ردیف)
 * با مایگریشن 2026_11_02_0003 منسوخ شدند.
 */
final class FcmRuntimeContractTest extends TestCase
{
    private Database $db;
    /** @var list<\stdClass> */
    private array $originalDevices = [];

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Application::getInstance()->container->make(Database::class);
        $this->originalDevices = $this->db->fetchAll('SELECT * FROM user_devices WHERE user_id IN (1,2)');
        $this->db->query('DELETE FROM user_devices WHERE user_id IN (1,2)');
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM user_devices WHERE user_id IN (1,2)');
        foreach ($this->originalDevices as $row) {
            $this->db->query(
                'INSERT INTO user_devices (id,user_id,fcm_token,platform,last_activity,created_at,updated_at) VALUES (?,?,?,?,?,?,?)',
                [$row->id,$row->user_id,$row->fcm_token,$row->platform,$row->last_activity,$row->created_at,$row->updated_at]
            );
        }
        parent::tearDown();
    }

    public function test_container_resolves_without_cycle_and_token_upsert_is_validated_and_unique(): void
    {
        $container = Application::getInstance()->container;
        $adapter = $container->make(FcmNotificationAdapter::class);
        $service = $container->make(FcmService::class);
        $channel = $container->make(FcmChannel::class);
        $this->assertInstanceOf(FcmNotificationAdapter::class, $adapter);
        $this->assertInstanceOf(FcmService::class, $service);
        $this->assertInstanceOf(FcmChannel::class, $channel);

        // 📱 FIX-MOBILE-02: ایندکس یکتایی جدید روی خودِ توکن — قرارداد جدید
        $this->assertSame(1, (int)$this->db->fetchColumn(
            "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='user_devices' AND index_name='uq_user_devices_fcm_token'"
        ), 'یکتایی توکن FCM باید ایندکس‌دار باشد (uq_user_devices_fcm_token)');
        // ایندکس قدیمی (user_id, platform) باید حذف شده باشد — چند-دستگاهی
        $this->assertSame(0, (int)$this->db->fetchColumn(
            "SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='user_devices' AND index_name='uq_user_devices_user_platform'"
        ), 'یکتایی قدیمی (user_id, platform) باید حذف شده باشد');

        $tokenOne = 'fcm-runtime-token-' . str_repeat('a', 64);
        $tokenTwo = 'fcm-runtime-token-' . str_repeat('b', 64);
        $this->assertTrue($service->saveUserToken(1, $tokenOne, 'web'));
        $this->assertSame(1, (int)$this->db->fetchColumn("SELECT COUNT(*) FROM user_devices WHERE user_id=1 AND platform='web'"));
        $this->assertSame($tokenOne, $service->getUserToken(1, 'web'));

        // 📱 FIX-MOBILE-02: توکن «متفاوت» = دستگاه متفاوت — دیگر جایگزین نمی‌شود؛
        // کاربر با گوشی و تبلت (هر دو web/android) هر دو پوش می‌گیرد
        $this->assertTrue($service->saveUserToken(1, $tokenTwo, 'web'));
        $this->assertSame(2, (int)$this->db->fetchColumn("SELECT COUNT(*) FROM user_devices WHERE user_id=1 AND platform='web'"));
        $tokens = $service->getUserTokens(1);
        sort($tokens);
        $this->assertSame([$tokenOne, $tokenTwo], $tokens);

        // ثبت دوبارهٔ همان توکن = idempotent (یک ردیف، بدون رشد)
        $this->assertTrue($service->saveUserToken(1, $tokenOne, 'web'));
        $this->assertSame(2, (int)$this->db->fetchColumn('SELECT COUNT(*) FROM user_devices WHERE user_id=1'));

        // 📱 FIX-MOBILE-02: انتقال مالکیت — توکنِ کاربر ۱ توسط کاربر ۲ ثبت شود
        $tokenThree = 'fcm-runtime-token-' . str_repeat('c', 64);
        $this->assertTrue($service->saveUserToken(2, $tokenThree, 'android'));
        $this->assertTrue($service->saveUserToken(1, $tokenThree, 'android'));
        $this->assertSame(0, (int)$this->db->fetchColumn('SELECT COUNT(*) FROM user_devices WHERE user_id=2'),
            'توکن دستگاهِ لاگین‌شده به حساب دیگر باید از مالک قبلی منتقل شود');
        $this->assertSame(1, (int)$this->db->fetchColumn('SELECT COUNT(*) FROM user_devices WHERE user_id=1 AND platform=\'android\''));

        $this->expectOutputRegex('/(?s)fcm\.invalid_token_registration/');
        $this->assertFalse($service->saveUserToken(1, 'short', 'web'));
        $this->assertFalse($service->saveUserToken(1, $tokenOne, 'desktop'));
        $this->assertFalse($service->saveUserToken(0, $tokenOne, 'web'));
        $this->assertSame(3, (int)$this->db->fetchColumn('SELECT COUNT(*) FROM user_devices WHERE user_id=1'));

        $service->removeUserToken(1, 'web');
        $this->assertSame(0, (int)$this->db->fetchColumn("SELECT COUNT(*) FROM user_devices WHERE user_id=1 AND platform='web'"));
        $this->assertNull($service->getUserToken(1, 'web'));
        // دستگاه اندروید (منتقل‌شده) دست‌نخورده می‌ماند
        $this->assertSame(1, (int)$this->db->fetchColumn("SELECT COUNT(*) FROM user_devices WHERE user_id=1 AND platform='android'"));
    }
}
