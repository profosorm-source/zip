<?php

declare(strict_types=1);

namespace Tests\Integration\Auth;

use App\Models\UserVerification;
use App\Services\User\UserService;
use Core\Application;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بچ S10 — راستی‌آزمایی runtime فیکس FIX-S10-1 (بخش الف) روی MariaDB واقعی
 *
 * زنجیرهٔ معیوب قبلی:
 *   UserService::register توکن را «خام» در user_verifications.token ذخیره می‌کرد،
 *   در حالی که AuthController::verifyEmail با hash_hmac(token) جستجو می‌کند
 *   (UserVerification::findByToken) و upsertOtp هم هش ذخیره می‌کند.
 *
 * الگوی تبعیض‌کننده (قبل/بعد فیکس نتیجه عوض می‌شود):
 *   بعد از register():
 *     - user_verifications.token باید === hash_hmac(plain) باشد (نه خودِ plain)
 *     - findByToken(hash_hmac(plain)) باید ردیف را بیابد (قبل از فیکس: null)
 *     - findValidCode با strtoupper(substr(plain,0,6)) باید ردیف را بیابد
 *     - users.email_verification_token === همان hash (CRITICAL-02)
 */
final class S10RegistrationVerificationTest extends TestCase
{
    private Database $db;
    private int $createdUserId = 0;
    private string $createdEmail = '';

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Application::getInstance()->container->make(Database::class);
    }

    protected function tearDown(): void
    {
        // پاکسازی کامل رکوردهای آزمایشی (بدون رد پایا)
        if ($this->createdUserId > 0) {
            $this->db->execute('DELETE FROM user_verifications WHERE user_id = ?', [$this->createdUserId]);
            $this->db->execute('DELETE FROM users WHERE id = ?', [$this->createdUserId]);
        }
        parent::tearDown();
    }

    public function test_register_stores_hashed_token_and_working_code(): void
    {
        /** @var UserService $service */
        $service = Application::getInstance()->container->make(UserService::class);

        $this->createdEmail = 's10_probe_' . bin2hex(random_bytes(6)) . '@example.test';
        $plainPassword = 'S10-Probe-Pass!123';

        // خروجی لاگر CLI (user.registration.attempt/success) — failOnRisky=true
        // خروجی چاپی تست را Risky می‌کند؛ الگوی S6: بلع با output buffering
        ob_start();
        try {
            $result = $service->register([
                'full_name' => 'S10 Probe User',
                'email'     => $this->createdEmail,
                'password'  => $plainPassword,
            ]);
        } finally {
            if (ob_get_level() > 0) { ob_end_clean(); }
        }

        $this->assertIsArray($result, 'register باید موفق شود');
        $userId = (int)($result['id'] ?? 0);
        $this->assertGreaterThan(0, $userId);
        $this->createdUserId = $userId;

        $plainToken = (string)($result['plain_token'] ?? '');
        $this->assertNotSame('', $plainToken, 'register باید plain_token برگرداند');

        $expectedHash = hash_hmac('sha256', $plainToken, secure_key());

        // ۱) user_verifications.token اکنون «هش» است — نه خام (بخش الف فیکس)
        $row = $this->db->fetch(
            'SELECT token, code, user_id FROM user_verifications WHERE user_id = ? AND type = ? LIMIT 1',
            [$userId, 'email']
        );
        $this->assertNotFalse($row, 'ردیف user_verifications باید وجود داشته باشد');
        $this->assertSame($expectedHash, (string)$row->token, 'token ذخیره‌شده باید hash_hmac(plain) باشد');
        $this->assertNotSame($plainToken, (string)$row->token, 'توکن خام هرگز نباید در DB بنشیند');

        // ۲) مسیر تأییدِ لینک (AuthController::verifyEmail): hash_hmac(plain) باید ردیف را بیابد
        $foundByHash = app(UserVerification::class)->findByToken($expectedHash);
        $this->assertNotNull($foundByHash, 'findByToken(hash) باید ردیف ثبت‌نام را بیابد');
        $this->assertSame($userId, (int)$foundByHash->user_id);

        // ۳) مسیر کد ۶رقمی: FIX (Round-18 P3) — OTP اکنون مستقل از توکن و
        // ۶ رقمِ random_int است (حذف همبستگی OTP↔لینک). قرارداد: ذخیرهٔ عددی
        // ۶ کاراکتری + یافتن با مقایسهٔ خامِ findValidCode روی همان کد.
        $storedCode = (string)$row->code;
        $this->assertSame(6, strlen($storedCode), 'کد OTP باید دقیقاً ۶ کاراکتر باشد');
        $this->assertTrue(ctype_digit($storedCode), 'کد OTP باید عددی باشد (مستقل از توکن)');
        $foundByCode = app(UserVerification::class)->findValidCode($userId, $storedCode, 'email');
        $this->assertNotNull($foundByCode, 'findValidCode باید کد ذخیره‌شده را بیابد (مقایسهٔ خام)');

        // ۴) users.email_verification_token همچنان هش است (CRITICAL-02 — تغییر نکرده)
        $user = $this->db->fetch('SELECT email_verification_token FROM users WHERE id = ?', [$userId]);
        $this->assertNotFalse($user);
        $this->assertSame($expectedHash, (string)$user->email_verification_token);
    }
}
