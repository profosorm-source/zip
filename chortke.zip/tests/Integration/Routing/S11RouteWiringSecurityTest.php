<?php

declare(strict_types=1);

namespace Tests\Integration\Routing;

use App\Middleware\AdminMiddleware;
use App\Middleware\AdminPermissionGuard;
use App\Middleware\AdvancedFraudMiddleware;
use App\Middleware\AuthMiddleware;
use App\Middleware\ConcurrentRequestMiddleware;
use App\Middleware\CorsMiddleware;
use App\Middleware\CSRFMiddleware;
use App\Middleware\GlobalExceptionMiddleware;
use App\Middleware\HttpsMiddleware;
use App\Middleware\LoggingMiddleware;
use App\Middleware\MaintenanceMiddleware;
use App\Middleware\RateLimitMiddleware;
use App\Middleware\SafeModeMiddleware;
use App\Middleware\SecurityHeadersMiddleware;
use App\Middleware\SessionMiddleware;
use App\Middleware\TracingMiddleware;
use Core\Request;
use Core\Router;
use PHPUnit\Framework\TestCase;

/**
 * S11 — تست‌های قفل‌کنندهٔ ناوردایی‌های امنیتی سیم‌کشی Middleware/Router.
 *
 * لنز بچ S11 (ترتیب اجرای لایه‌ها / دورزدن احراز هویت / نشت هدر):
 *  ① هر روتِ /admin (به‌جز مسیرهای pre-auth مستند) باید زنجیرهٔ کامل
 *     Auth + Admin + CSRF + RateLimit + AdminPermissionGuard را داشته باشد —
 *     ترایوایر آینده: افزودن روت ادمین بدون $admin این تست را می‌شکند.
 *  ② هر روتِ مالیِ mutator باید AdvancedFraud + RateLimit + CSRF داشته باشد
 *     (الگوی $secureAuth در routes/wallet.php).
 *  ③ ترتیب canonical پشتهٔ سراسری: Session قبل از CSRF (توکن سشنی) و
 *     Logging درونی‌ترین لایه.
 *  ④ AdminPermissionGuard deny-by-default: اکشن نگاشت‌نشده → null (رد).
 *  ⑤ بازتاب هدرهای X-Request-ID/X-Correlation-ID بدون CR/LF (ضد header injection).
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class S11RouteWiringSecurityTest extends TestCase
{
    /**
     * مسیرهای pre-auth / مستنداً بدون گارد کامل (بازبینی دستی بچ S11).
     * قالب: 'method|uri'
     */
    private const ADMIN_ROUTE_EXEMPTIONS = [
        'GET|/admin',                 // FIX-X112: ریدایرکت ساده به پنل — هیچ اکشن حساسی
        'GET|/admin/login',           // pre-auth
        'POST|/admin/login',          // pre-auth (CSRF + RateLimit دارد؛ جداگانه pin شده)
        'GET|/admin/verify-2fa',      // pre-auth
        'POST|/admin/verify-2fa',     // pre-auth (CSRF دارد)
        'POST|/admin/logout',         // Auth+Admin+CSRF+RateLimit دارد؛ Guard لازم ندارد
    ];

    protected function setUp(): void
    {
        parent::setUp();

        if (!defined('BASE_PATH')) {
            define('BASE_PATH', dirname(__DIR__, 3));
        }
        if (!defined('VIEW_PATH')) {
            define('VIEW_PATH', BASE_PATH . '/views');
        }

        require_once BASE_PATH . '/routes/admin.php';
        require_once BASE_PATH . '/routes/wallet.php';
    }

    public function test_every_admin_route_carries_full_auth_stack(): void
    {
        $routes = app()->router->getRoutes();

        $checked = 0;
        $violations = [];

        foreach ($routes as $method => $methodRoutes) {
            foreach ($methodRoutes as $entry) {
                $uri = (string)$entry['uri'];
                if (!str_starts_with($uri, '/admin')) {
                    continue;
                }

                $key = $method . '|' . $uri;
                if (in_array($key, self::ADMIN_ROUTE_EXEMPTIONS, true)) {
                    continue;
                }

                $checked++;
                $names = [];
                foreach ($entry['route']->getMiddleware() as $mw) {
                    $names[] = is_string($mw) ? $mw : (is_object($mw) ? get_class($mw) : gettype($mw));
                }

                foreach ([AuthMiddleware::class, AdminMiddleware::class, AdminPermissionGuard::class, CSRFMiddleware::class] as $required) {
                    if (!in_array($required, $names, true)) {
                        $violations[] = $key . ' فاقد ' . $required;
                    }
                }

                $hasRateLimit = false;
                foreach ($names as $name) {
                    if (str_starts_with($name, RateLimitMiddleware::class)) {
                        $hasRateLimit = true;
                        break;
                    }
                }
                if (!$hasRateLimit) {
                    $violations[] = $key . ' فاقد ' . RateLimitMiddleware::class;
                }
            }
        }

        $this->assertGreaterThan(200, $checked, 'تعداد روت‌های ادمین بررسی‌شده غیرمنتظره کم است — احتمالاً routes/admin.php لود نشده.');
        $this->assertSame([], $violations, 'روت‌های ادمین بدون گارد کامل: ' . implode(' | ', $violations));
    }

    public function test_financial_mutating_routes_carry_failclosed_stack(): void
    {
        $routes = app()->router->getRoutes();
        $violations = [];
        $checked = 0;

        $financialPrefixes = ['/wallet', '/payment', '/withdrawal', '/withdrawals', '/transfer', '/escrow', '/deposit', '/manual-deposits', '/crypto-deposits'];

        foreach ($routes as $method => $methodRoutes) {
            if (!in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
                continue;
            }
            foreach ($methodRoutes as $entry) {
                $uri = (string)$entry['uri'];
                $isFinancial = false;
                foreach ($financialPrefixes as $prefix) {
                    if (str_starts_with($uri, $prefix)) {
                        $isFinancial = true;
                        break;
                    }
                }
                if (!$isFinancial) {
                    continue;
                }
                // callback درگاه‌ها مسیر مکانیزهٔ درگاه است (امضای دامنه‌محور در کنترلر)
                if (str_starts_with($uri, '/payment/callback/')) {
                    continue;
                }

                $checked++;
                $names = [];
                foreach ($entry['route']->getMiddleware() as $mw) {
                    $names[] = is_string($mw) ? $mw : (is_object($mw) ? get_class($mw) : gettype($mw));
                }

                if (!in_array(AuthMiddleware::class, $names, true)) {
                    $violations[] = $method . ' ' . $uri . ' فاقد Auth';
                }
                if (!in_array(AdvancedFraudMiddleware::class, $names, true)) {
                    $violations[] = $method . ' ' . $uri . ' فاقد AdvancedFraud';
                }
                if (!in_array(CSRFMiddleware::class, $names, true)) {
                    $violations[] = $method . ' ' . $uri . ' فاقد CSRF';
                }
                $hasRateLimit = false;
                foreach ($names as $name) {
                    if (str_starts_with($name, RateLimitMiddleware::class)) {
                        $hasRateLimit = true;
                        break;
                    }
                }
                if (!$hasRateLimit) {
                    $violations[] = $method . ' ' . $uri . ' فاقد RateLimit';
                }
            }
        }

        $this->assertGreaterThanOrEqual(5, $checked, 'روت‌های مالی mutator کمتر از انتظار یافت شد.');
        $this->assertSame([], $violations, 'روت‌های مالی بدون زنجیرهٔ fail-closed: ' . implode(' | ', $violations));
    }

    public function test_global_pipeline_priority_order_is_security_canonical(): void
    {
        $router = app()->router;

        $reflection = new \ReflectionProperty(Router::class, 'middlewarePriority');
        $reflection->setAccessible(true);
        /** @var list<class-string> $priority */
        $priority = $reflection->getValue($router);

        // ناوردایی ۱: Session باید قبل از CSRF باشد (توکن CSRF در نشست زندگی می‌کند)
        $this->assertGreaterThan(
            array_search(SessionMiddleware::class, $priority, true),
            array_search(CSRFMiddleware::class, $priority, true),
            'CSRFMiddleware نباید قبل از SessionMiddleware اجرا شود.'
        );

        // ناوردایی ۲: Tracing بیرونی‌ترین و Logging درونی‌ترین لایهٔ سراسری
        $this->assertSame(0, array_search(TracingMiddleware::class, $priority, true));
        $this->assertSame(count($priority) - 1, array_search(LoggingMiddleware::class, $priority, true));

        // ناوردایی ۳: مرتب‌سازیِ پشتهٔ سراسری پایدار است و ترتیب رجیستری را بازتولید می‌کند
        $method = new \ReflectionMethod(Router::class, 'sortMiddlewares');
        $method->setAccessible(true);
        $shuffled = [
            LoggingMiddleware::class,
            CSRFMiddleware::class,
            TracingMiddleware::class,
            SafeModeMiddleware::class,
            SessionMiddleware::class,
            HttpsMiddleware::class,
            GlobalExceptionMiddleware::class,
            MaintenanceMiddleware::class,
            CorsMiddleware::class,
            ConcurrentRequestMiddleware::class,
            SecurityHeadersMiddleware::class,
        ];
        $sorted = $method->invoke($router, $shuffled);
        $this->assertSame($priority, $sorted, 'sortMiddlewares باید ترتیب رجیستری اولویت را بازتولید کند.');
    }

    public function test_admin_permission_guard_is_deny_by_default(): void
    {
        // ① اکشن نگاشت‌نشده → null → گارد deny می‌کند
        $this->assertNull(AdminPermissionGuard::permissionForAction('Some\\Unknown\\Controller', 'index'));
        $this->assertNull(AdminPermissionGuard::permissionForAction('TotallyFakeController', 'store'));

        // ② نقشهٔ واقعی: هر ورودیِ موجود باید مجوزِ غیرتهی و عینِ نقشه برگرداند
        $map = (array)require BASE_PATH . '/config/admin_permissions.php';
        $this->assertNotEmpty($map, 'نقشهٔ مجوزهای ادمین نباید خالی باشد.');

        $resolvedAtLeastOne = false;
        foreach ($map as $shortClass => $entry) {
            if (!is_array($entry)) {
                continue;
            }
            if (isset($entry['default'])) {
                $this->assertSame($entry['default'], AdminPermissionGuard::permissionForAction('App\\Controllers\\Admin\\' . $shortClass, 'arbitraryMethod'));
                $resolvedAtLeastOne = true;
            }
            if (isset($entry['methods']) && is_array($entry['methods'])) {
                foreach ($entry['methods'] as $methodName => $permission) {
                    $this->assertSame($permission, AdminPermissionGuard::permissionForAction('App\\Controllers\\Admin\\' . $shortClass, $methodName));
                    $resolvedAtLeastOne = true;
                }
            }
        }
        $this->assertTrue($resolvedAtLeastOne, 'حداقل یک نگاشت کلاس→مجوز باید قابل‌حل باشد.');
    }

    public function test_reflected_request_ids_are_crlf_sanitized(): void
    {
        $originalServer = $_SERVER;
        $_SERVER = [
            'REQUEST_METHOD' => 'GET',
            'REQUEST_URI' => '/health',
            'SCRIPT_NAME' => '/index.php',
            'REMOTE_ADDR' => '127.0.0.1',
            'HTTP_X_REQUEST_ID' => "abc\r\nX-Injected: 1",
        ];

        try {
            $request = new Request();
            $middleware = new SecurityHeadersMiddleware();
            $response = $middleware->handle($request, static fn (): string => 'ok');

            $requestIdHeader = $response->getHeader('X-Request-ID');
            $correlationHeader = $response->getHeader('X-Correlation-ID');

            $this->assertNotNull($requestIdHeader);
            $this->assertNotNull($correlationHeader);
            $this->assertStringNotContainsString("\r", (string)$requestIdHeader);
            $this->assertStringNotContainsString("\n", (string)$requestIdHeader);
            $this->assertStringNotContainsString('X-Injected', (string)$requestIdHeader);
            $this->assertStringNotContainsString('X-Injected', (string)$correlationHeader);
            // شناسهٔ آلوده باید دور ریخته و شناسهٔ تصادفی تازه صادر شود
            // FIX-FLAKE (بچ فاز-۲ سئو، ۲۰۲۶-۱۱-۰۲): قبلاً «نباید abc داشته باشد»
            // پین می‌شد — اما شناسهٔ تازهٔ تصادفی hex به‌طور مشروع می‌تواند رشتهٔ
            // abc را در خود داشته باشد (~۳٪ ران‌ها) ⇒ تست flaky. قرارداد واقعی:
            // مقدار منعکس‌شده شناسهٔ تمیز hex/dash است، نه ورودی آلوده.
            $this->assertRegExp('/^[a-f0-9-]{8,64}$/i', (string)$correlationHeader);
            $this->assertNotSame("abc\r\nX-Injected: 1", (string)$correlationHeader);
        } finally {
            $_SERVER = $originalServer;
        }
    }
}
