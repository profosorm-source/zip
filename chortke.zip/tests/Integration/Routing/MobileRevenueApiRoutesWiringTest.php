<?php

declare(strict_types=1);

namespace Tests\Integration\Routing;

use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * پین سیم‌کشی: هر ۸ کانالِ فاقدِ API حالا مسیر /api/v1 دارد و گیت اسکوپ
 * صحیحی دارد — هم‌الگوی MobileApiRoutesWiringTest (بچ قبلی موبایل).
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class MobileRevenueApiRoutesWiringTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        if (!defined('BASE_PATH')) {
            define('BASE_PATH', dirname(__DIR__, 3));
        }
        if (!defined('VIEW_PATH')) {
            define('VIEW_PATH', BASE_PATH . '/views');
        }

        require_once BASE_PATH . '/routes/api.php';
    }

    /** @var array<int, array<string, string>> */
    private static array $routes = [];
    private static bool $loaded = false;

    private static function loadRoutes(): void
    {
        if (self::$loaded) {
            return;
        }
        foreach (app()->router->getRoutes() as $method => $entries) {
            foreach ($entries as $entry) {
                $action = '';
                $routeObj = $entry['route'] ?? null;
                if (is_object($routeObj) && method_exists($routeObj, 'getAction')) {
                    $raw = $routeObj->getAction();
                    if (is_string($raw)) {
                        $action = $raw;
                    } elseif (is_array($raw)) {
                        // [Controller::class, 'method']
                        $cls = $raw[0] ?? '';
                        $mth = $raw[1] ?? '';
                        $action = (is_string($cls) ? $cls : '') . '::' . (is_string($mth) ? $mth : '');
                    }
                }
                self::$routes[] = [
                    'method' => (string)$method,
                    'uri'    => (string)($entry['uri'] ?? ''),
                    'action' => $action,
                ];
            }
        }
        self::$loaded = true;
    }

    private static function has(string $method, string $uri, string $controller, string $action): bool
    {
        self::loadRoutes();
        $needle = $controller . '::' . $action;
        foreach (self::$routes as $r) {
            if (strcasecmp($r['method'], $method) === 0
                && '/' . trim($r['uri'], '/') === '/' . trim($uri, '/')
                && str_contains($r['action'], $needle)) {
                return true;
            }
        }
        return false;
    }

    public function test_adtube_routes_are_wired(): void
    {
        $this->assertTrue(self::has('GET', '/api/v1/adtube/ads', 'AdtubeApiController', 'ads'));
        $this->assertTrue(self::has('GET', '/api/v1/adtube/history', 'AdtubeApiController', 'history'));
        $this->assertTrue(self::has('POST', '/api/v1/adtube/ads/{id}/start', 'AdtubeApiController', 'start'));
        $this->assertTrue(self::has('POST', '/api/v1/adtube/executions/{id}/heartbeat', 'AdtubeApiController', 'heartbeat'));
        $this->assertTrue(self::has('POST', '/api/v1/adtube/executions/{id}/complete', 'AdtubeApiController', 'complete'));
    }

    public function test_prediction_routes_are_wired(): void
    {
        $this->assertTrue(self::has('GET', '/api/v1/prediction/games', 'PredictionApiController', 'games'));
        $this->assertTrue(self::has('GET', '/api/v1/prediction/games/{id}', 'PredictionApiController', 'show'));
        $this->assertTrue(self::has('GET', '/api/v1/prediction/my/bets', 'PredictionApiController', 'myBets'));
        $this->assertTrue(self::has('POST', '/api/v1/prediction/bets', 'PredictionApiController', 'placeBet'));
    }

    public function test_custom_task_routes_are_wired(): void
    {
        $this->assertTrue(self::has('GET', '/api/v1/custom-tasks/tasks', 'CustomTaskApiController', 'tasks'));
        $this->assertTrue(self::has('GET', '/api/v1/custom-tasks/my/submissions', 'CustomTaskApiController', 'mySubmissions'));
        $this->assertTrue(self::has('GET', '/api/v1/custom-tasks/submissions/{id}', 'CustomTaskApiController', 'showSubmission'));
        $this->assertTrue(self::has('POST', '/api/v1/custom-tasks/tasks/{id}/start', 'CustomTaskApiController', 'start'));
        $this->assertTrue(self::has('POST', '/api/v1/custom-tasks/submissions/{id}/proof', 'CustomTaskApiController', 'submitProof'));
    }

    public function test_content_routes_are_wired(): void
    {
        $this->assertTrue(self::has('GET', '/api/v1/content/submissions', 'ContentApiController', 'submissions'));
        $this->assertTrue(self::has('GET', '/api/v1/content/submissions/{id}', 'ContentApiController', 'showSubmission'));
        $this->assertTrue(self::has('GET', '/api/v1/content/revenues', 'ContentApiController', 'revenues'));
        $this->assertTrue(self::has('GET', '/api/v1/content/share-preview', 'ContentApiController', 'sharePreview'));
        $this->assertTrue(self::has('POST', '/api/v1/content/submissions', 'ContentApiController', 'store'));
    }

    public function test_coupon_and_transfer_routes_are_wired(): void
    {
        $this->assertTrue(self::has('POST', '/api/v1/coupons/validate', 'CouponApiController', 'validate'));
        $this->assertTrue(self::has('GET', '/api/v1/transfers', 'TransferApiController', 'index'));
        $this->assertTrue(self::has('POST', '/api/v1/transfers', 'TransferApiController', 'store'));
    }

    public function test_dashboard_level_escrow_dispute_routes_are_wired(): void
    {
        $this->assertTrue(self::has('GET', '/api/v1/dashboard/summary', 'DashboardApiController', 'summary'));
        $this->assertTrue(self::has('GET', '/api/v1/dashboard/recent-executions', 'DashboardApiController', 'recentExecutions'));
        $this->assertTrue(self::has('GET', '/api/v1/level/progress', 'DashboardApiController', 'level'));
        $this->assertTrue(self::has('GET', '/api/v1/escrows/by-order/{type}/{orderId}', 'EscrowDisputeApiController', 'escrowByOrder'));
        $this->assertTrue(self::has('GET', '/api/v1/disputes', 'EscrowDisputeApiController', 'disputes'));
        $this->assertTrue(self::has('GET', '/api/v1/disputes/{id}', 'EscrowDisputeApiController', 'showDispute'));
        $this->assertTrue(self::has('POST', '/api/v1/disputes/{id}/reply', 'EscrowDisputeApiController', 'replyDispute'));
    }

    /**
     * اسکوپ‌های جدید در کاتالوگ ApiToken (public /auth/scopes) موجودند و
     * transfer.write exact-only است.
     */
    public function test_new_scopes_are_in_catalog_and_transfer_write_is_exact_only(): void
    {
        $catalog = \App\Models\ApiToken::scopeCatalog();
        $names = array_column($catalog, 'scope');
        foreach ([
            'adtube.read', 'adtube.write',
            'prediction.read', 'prediction.write',
            'customtask.read', 'customtask.write',
            'content.read', 'content.write',
            'coupon.read',
            'transfer.read', 'transfer.write',
            'escrow.read',
            'dispute.read', 'dispute.write',
        ] as $scope) {
            $this->assertContains($scope, $names, "scope {$scope} باید در کاتالوگ باشد");
        }
        $byName = [];
        foreach ($catalog as $row) {
            $byName[$row['scope']] = $row;
        }
        $this->assertTrue($byName['transfer.write']['exact_only'], 'transfer.write باید exact_only باشد');
        $this->assertFalse($byName['adtube.write']['exact_only'], 'adtube.write استاندارد است (پوشش با write سراسری)');
        $this->assertFalse($byName['content.write']['exact_only']);
    }

    /**
     * سورس میدل‌ور: EXACT_ONLY_SCOPES باید شامل transfer.write باشد —
     * توکنِ «write» سراسری نباید انتقال پول را بپوشاند.
     */
    public function test_middleware_exact_only_list_contains_transfer_write(): void
    {
        $source = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Middleware/ApiAuthMiddleware.php');
        $this->assertStringContainsString("'transfer.write'", $source);
    }
}
