<?php

declare(strict_types=1);

namespace Tests\Integration\Routing;

use App\Middleware\ApiAuthMiddleware;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-01/03/04 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲):
 * پین سیم‌کشی مسیرهای جدید API اپ موبایل — ترایوایر آینده:
 *  • حذف/جابه‌جایی هر مسیر بدون هماهنگی اسکوپ، این تست را می‌شکند.
 *  • مسیرهای auth جدید باید «عمومی» بمانند (بدون ApiAuthMiddleware).
 *  • مسیرهای push/seo باید دقیقاً با اسکوپ‌های user.read/user.write و
 *    seo.read/seo.write گیت شوند.
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class MobileApiRoutesWiringTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        if (!defined('BASE_PATH')) {
            define('BASE_PATH', dirname(__DIR__, 3));
        }
        if (!defined('VIEW_PATH')) {
            define('VIEW_PATH', BASE_PATH . '/views');
        }

        require_once BASE_PATH . '/routes/api.php';
    }

    /** @return array<string, list<mixed>> */
    private function findRoute(string $method, string $uri): ?array
    {
        foreach (app()->router->getRoutes()[$method] ?? [] as $entry) {
            if ((string)$entry['uri'] === $uri) {
                return $entry['route']->getMiddleware();
            }
        }
        return null;
    }

    private function authScope(array $middleware): ?string
    {
        foreach ($middleware as $mw) {
            if (is_string($mw) && str_starts_with($mw, ApiAuthMiddleware::class . ':')) {
                return substr($mw, strlen(ApiAuthMiddleware::class) + 1);
            }
        }
        return null;
    }

    // ─────────────── FIX-MOBILE-01: چرخهٔ حساب عمومی ───────────────

    public function test_mobile_auth_lifecycle_routes_exist_and_are_public(): void
    {
        $public = [
            'POST|/api/v1/auth/register',
            'POST|/api/v1/auth/email/verify-code',
            'POST|/api/v1/auth/email/resend-verification',
            'POST|/api/v1/auth/password/forgot',
            'POST|/api/v1/auth/password/reset',
        ];
        foreach ($public as $spec) {
            [$method, $uri] = explode('|', $spec);
            $mw = $this->findRoute($method, $uri);
            $this->assertNotNull($mw, "مسیر {$uri} باید ثبت شده باشد");
            $this->assertNull($this->authScope($mw), "مسیر {$uri} باید عمومی باشد (بدون ApiAuthMiddleware)");
        }
    }

    // ─────────────── FIX-MOBILE-03: دستگاه‌های push ───────────────

    public function test_push_device_routes_are_scoped(): void
    {
        $read = $this->findRoute('GET', '/api/v1/push/devices');
        $this->assertNotNull($read);
        $this->assertSame('user.read', $this->authScope($read), 'لیست دستگاه‌ها = user.read (هم‌قواعد sessionsList)');

        $write = $this->findRoute('POST', '/api/v1/push/devices');
        $this->assertNotNull($write);
        $this->assertSame('user.write', $this->authScope($write), 'ثبت دستگاه = user.write');

        $revoke = $this->findRoute('POST', '/api/v1/push/devices/{id}/revoke');
        $this->assertNotNull($revoke);
        $this->assertSame('user.write', $this->authScope($revoke), 'حذف دستگاه = user.write (هم‌قواعد sessionsRevoke)');
    }

    // ─────────────── FIX-MOBILE-04: تسک‌های سئو ───────────────

    public function test_seo_api_routes_are_scoped(): void
    {
        $readRoutes = [
            'GET /api/v1/seo/ads' => ['GET', '/api/v1/seo/ads'],
            'GET /api/v1/seo/executions/{id}' => ['GET', '/api/v1/seo/executions/{id}'],
            'GET /api/v1/seo/history' => ['GET', '/api/v1/seo/history'],
        ];
        foreach ($readRoutes as $label => [$method, $uri]) {
            $mw = $this->findRoute($method, $uri);
            $this->assertNotNull($mw, "{$label} باید ثبت شده باشد");
            $this->assertSame('seo.read', $this->authScope($mw), "{$label} = seo.read");
        }

        $writeRoutes = [
            'POST /api/v1/seo/ads/{id}/start' => ['POST', '/api/v1/seo/ads/{id}/start'],
            'POST /api/v1/seo/executions/{id}/complete' => ['POST', '/api/v1/seo/executions/{id}/complete'],
            'POST /api/v1/seo/executions/{id}/cancel' => ['POST', '/api/v1/seo/executions/{id}/cancel'],
        ];
        foreach ($writeRoutes as $label => [$method, $uri]) {
            $mw = $this->findRoute($method, $uri);
            $this->assertNotNull($mw, "{$label} باید ثبت شده باشد");
            $this->assertSame('seo.write', $this->authScope($mw), "{$label} = seo.write");
        }
    }

    public function test_new_controllers_exist_and_extend_base_api(): void
    {
        foreach ([
            \App\Controllers\Api\MobileAuthController::class,
            \App\Controllers\Api\PushDeviceController::class,
            \App\Controllers\Api\SeoTaskApiController::class,
        ] as $class) {
            $this->assertTrue(class_exists($class));
            $this->assertTrue(
                (new \ReflectionClass($class))->isSubclassOf(\App\Controllers\Api\BaseApiController::class),
                "{$class} باید از BaseApiController extends کند"
            );
        }
    }
}
