<?php

declare(strict_types=1);

namespace Tests\Integration\Routing;

use PHPUnit\Framework\TestCase;

/**
 * بچ S12 — قفل رفتاری FIX-S12-1 (تصمیم کاربر، گزینهٔ الف):
 * جابه‌جایی endpointهای تأیید رفتاری/دوربینی از /api/social-tasks/* به
 * /social-tasks/verify/* با حفظ گارد سشن.
 *
 * پیشینه (اثبات S11): CORE-037 در AuthMiddleware:65 هر درخواست سشن‌دار زیر
 * /api/ را 401 می‌کند — در نتیجه این سه endpoint همیشه 401 بودند و قابلیت
 * «تأیید رفتاری» بی‌اثر بود. پس از جابه‌جایی (اثبات اجرایی
 * scripts/s12_verify_endpoints.sh):
 *
 *  ۱) GET /social-tasks/verify/trust-status با سشن معتبر = 200 + JSON success
 *     (قبل از فیکس: همیشه 401).
 *  ۲) GET /api/social-tasks/trust-status = 404/401 — زیر /api/ هیچ سرویسی
 *      از این خانواده باقی نمی‌ماند (هرگز دادهٔ سشن‌دار نمی‌دهد).
 *  ۳) بدون سشن = رد (302/401) — گارد احراز روی مسیر جدید فعال است.
 *  ۴) POST /social-tasks/verify/behavior با سشن+CSRF = غیر-401 —
 *     احراز عبور می‌کند (پاسخ واقعی تحلیل رفتار یا اعتبارسنجی دامنه).
 *
 * تست‌های HTTP به سرور 127.0.0.1:8090 (درخت e2e با dev-router) نیاز دارند —
 * همان قرارداد S8EntryPointGuardsTest. اعتبار ورود: user@chortke.ir/123456.
 */
final class S12SocialTaskVerifyEndpointsTest extends TestCase
{
    private string $base = 'http://127.0.0.1:8090';
    /** @var array<string,string> کوکی‌های سشن (از Set-Cookie پاسخ‌ها) */
    private array $cookies = [];

    protected function setUp(): void
    {
        parent::setUp();
        $this->base = \Tests\Support\E2eBaseUrl::resolve();
    }

    protected function tearDown(): void
    {
        $this->cookies = [];
        parent::tearDown();
    }

    /** GET/POST با کوکی‌جار؛ false = سرور در دسترس نیست */
    private function http(string $method, string $path, array $headers = [], ?string $body = null): array|false
    {
        $ctx = stream_context_create(['http' => [
            'method' => $method,
            'timeout' => 10,
            'ignore_errors' => true,
            'follow_location' => 0,
            'header' => implode("\r\n", $headers),
            'content' => $body,
            'user_agent' => 'S12IntegrationTest/1.0',
        ]]);
        $resp = @file_get_contents($this->base . $path, false, $ctx);
        if ($resp === false && empty($http_response_header)) {
            return false;
        }
        $status = 0;
        foreach ($http_response_header ?? [] as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) {
                $status = (int)$m[1];
            }
            if (preg_match('#^Set-Cookie:\s*([^=\s;]+)=([^;]*)#i', $h, $c)) {
                $this->cookies[trim($c[1])] = trim($c[2]);
            }
        }
        return ['status' => $status, 'body' => (string)$resp, 'headers' => $http_response_header ?? []];
    }

    private function cookieHeader(): string
    {
        $pairs = [];
        foreach ($this->cookies as $name => $value) {
            $pairs[] = $name . '=' . $value;
        }
        return implode('; ', $pairs);
    }

    /** ورود سشن‌دار با کوکی‌جار؛ false = سرور غایب */
    private function loginSession(): bool
    {
        $page = $this->http('GET', '/login');
        if ($page === false) {
            return false;
        }
        $csrf = '';
        if (preg_match('#name="csrf-token" content="([^"]+)"#', $page['body'], $m)
            || preg_match('#name="_csrf_token"[^>]*value="([^"]+)"#', $page['body'], $m)) {
            $csrf = $m[1];
        }
        $this->http('POST', '/login', [
            'Cookie: ' . $this->cookieHeader(),
            'X-CSRF-Token: ' . $csrf,
            'Content-Type: application/x-www-form-urlencoded',
        ], http_build_query([
            '_csrf_token' => $csrf,
            'email' => 'user@chortke.ir',
            'password' => '123456',
        ]));
        return true;
    }

    // ─────────────────────────────────────────────────────────────
    // ۱) trust-status با سشن = 200
    // ─────────────────────────────────────────────────────────────

    public function test_trust_status_with_session_is_200(): void
    {
        if (!$this->loginSession()) {
            $this->markTestSkipped('e2e server (' . $this->base . ') unavailable');
        }
        $r = $this->http('GET', '/social-tasks/verify/trust-status', ['Cookie: ' . $this->cookieHeader()]);
        $this->assertNotFalse($r);
        $this->assertSame(200, $r['status'], 'trust-status با سشن باید 200 باشد (قبل از FIX-S12-1: همیشه 401)');
        $json = json_decode($r['body'], true);
        $this->assertIsArray($json);
        $this->assertTrue((bool)($json['success'] ?? false));
        $this->assertArrayHasKey('trust_score', $json['data'] ?? []);
    }

    // ─────────────────────────────────────────────────────────────
    // ۲) مسیر قدیمی /api/ دیگر داده نمی‌دهد
    // ─────────────────────────────────────────────────────────────

    public function test_legacy_api_path_serves_no_session_data(): void
    {
        if (!$this->loginSession()) {
            $this->markTestSkipped('e2e server (' . $this->base . ') unavailable');
        }
        $r = $this->http('GET', '/api/social-tasks/trust-status', ['Cookie: ' . $this->cookieHeader()]);
        $this->assertNotFalse($r);
        // 404 = مسیر حذف شده (روتر) یا 401 = گارد CORE-037؛ هرگز 200/داده.
        $this->assertTrue(in_array($r['status'], [401, 404], true), 'مسیر قدیمی /api/ نباید داده بدهد، status=' . $r['status']);
    }

    // ─────────────────────────────────────────────────────────────
    // ۳) مسیر جدید بدون سشن رد می‌شود
    // ─────────────────────────────────────────────────────────────

    public function test_new_path_requires_session(): void
    {
        if ($this->http('GET', '/login') === false) {
            $this->markTestSkipped('e2e server (' . $this->base . ') unavailable');
        }
        $r = $this->http('GET', '/social-tasks/verify/trust-status');
        $this->assertNotFalse($r);
        $this->assertTrue(in_array($r['status'], [301, 302, 401], true), 'بدون سشن باید رد شود (302/401)، status=' . $r['status']);
    }

    // ─────────────────────────────────────────────────────────────
    // ۴) POST behavior با سشن+CSRF از گیت 401 عبور می‌کند
    // ─────────────────────────────────────────────────────────────

    public function test_behavior_post_with_session_and_csrf_passes_auth(): void
    {
        if (!$this->loginSession()) {
            $this->markTestSkipped('e2e server (' . $this->base . ') unavailable');
        }
        $page = $this->http('GET', '/social-tasks', ['Cookie: ' . $this->cookieHeader()]);
        $csrf = '';
        if ($page !== false && preg_match('#name="csrf-token" content="([^"]+)"#', $page['body'], $m)) {
            $csrf = $m[1];
        }
        $r = $this->http('POST', '/social-tasks/verify/behavior', [
            'Cookie: ' . $this->cookieHeader(),
            'X-CSRF-Token: ' . $csrf,
            'Content-Type: application/json',
        ], (string)json_encode(['execution_id' => 999999999, 'signals' => ['tap_count' => 3]]));
        $this->assertNotFalse($r);
        // 401 یعنی احراز عبور نکرده؛ پاسخ موجه: 200 (تحلیل) یا 4xx دامنه‌ای (validation/ownership).
        $this->assertNotSame(401, $r['status'], 'POST behavior با سشن+CSRF نباید 401 بگیرد');
        $this->assertLessThan(500, $r['status'], 'خطای 500 نشانهٔ خرابی سرور است');
    }
}
