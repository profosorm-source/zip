<?php

declare(strict_types=1);

namespace Tests\Integration\Routing;

use App\Middleware\ApiAuthMiddleware;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-REVGEN (بچ کانال‌های درآمدیِ فقط-وب — ۲۰۲۶-۱۱-۰۳):
 * 🛡️ FIX-REVGEN-ALIGN (۲۰۲۶-۱۱-۰۵): بازنویسی برای مسیرهای زندهٔ درخت.
 *
 * نسخهٔ revgen-q4 این فایل پین‌های قدیمی داشت (URLهای /content/{id}،
 * اسکوپ wallet.read برای کوپن، و کلاس ContentSubmissionApiController که
 * هرگز روی درخت اعمال نشد) و روی درخت REAPPLY ۳ شکست می‌داد. این نسخه
 * سیم‌کشی «واقعی» را پین می‌کند — همان قراردادی که بچ FIX-MOBILE-06 +
 * FIX-REVGEN-REAPLY روی درخت گذاشته‌اند (سند CHANGES-REVGEN-REAPPLY-fa):
 *   • محتوا: /content/submissions* (نه /content/{id}) — اسکوپ content.read/write
 *   • کوپن: coupon.read (نه wallet.read)
 *   • کنترلر محتوا: ContentApiController (نه ContentSubmissionApiController)
 *
 * ترایوایر آینده: حذف/جابه‌جایی هر مسیر یا تغییر اسکوپ، این تست را می‌شکند.
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class RevenueGapsApiRoutesWiringTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        if (!defined('BASE_PATH')) {
            define('BASE_PATH', dirname(__DIR__, 3));
        }
        if (!defined('VIEW_PATH')) {
            define('VIEW_PATH', BASE_PATH . '/views');
        }

        require_once BASE_PATH . '/routes/api.php';
    }

    /** @return array<string, mixed>|null */
    private function findRoute(string $method, string $uri): ?array
    {
        foreach (app()->router->getRoutes()[$method] ?? [] as $entry) {
            if ((string)$entry['uri'] === $uri) {
                return $entry['route']->getMiddleware();
            }
        }
        return null;
    }

    private function authScope(array $middleware): ?string
    {
        foreach ($middleware as $mw) {
            if (is_string($mw) && str_starts_with($mw, ApiAuthMiddleware::class . ':')) {
                return substr($mw, strlen(ApiAuthMiddleware::class) + 1);
            }
        }
        return null;
    }

    /** @param array<string, array{0: string, 1: string}> $routes */
    private function assertScoped(array $routes, string $expectedScope): void
    {
        foreach ($routes as $label => [$method, $uri]) {
            $mw = $this->findRoute($method, $uri);
            $this->assertNotNull($mw, "{$label} باید ثبت شده باشد");
            $this->assertSame($expectedScope, $this->authScope($mw), "{$label} = {$expectedScope}");
        }
    }

    // ─────────────── FIX-REVGEN-01: برنامهٔ محتوا (الگوی /content/submissions*) ───────────────

    public function test_content_api_routes_are_scoped(): void
    {
        $this->assertScoped([
            'GET /api/v1/content/submissions'        => ['GET', '/api/v1/content/submissions'],
            'GET /api/v1/content/submissions/{id}'   => ['GET', '/api/v1/content/submissions/{id}'],
            'GET /api/v1/content/revenues'           => ['GET', '/api/v1/content/revenues'],
            'GET /api/v1/content/revenues/summary'   => ['GET', '/api/v1/content/revenues/summary'],
            'GET /api/v1/content/share-preview'      => ['GET', '/api/v1/content/share-preview'],
            'GET /api/v1/content/agreement'          => ['GET', '/api/v1/content/agreement'],
        ], 'content.read');

        $this->assertScoped([
            'POST /api/v1/content/submissions'       => ['POST', '/api/v1/content/submissions'],
            'POST /api/v1/content/submissions/{id}'  => ['POST', '/api/v1/content/submissions/{id}'],
        ], 'content.write');
    }

    // ─────────────── FIX-REVGEN-02: رفرال ───────────────

    public function test_referral_api_routes_are_scoped(): void
    {
        $this->assertScoped([
            'GET /api/v1/referrals/milestones'        => ['GET', '/api/v1/referrals/milestones'],
        ], 'referral.read');

        $this->assertScoped([
            'POST /api/v1/referrals/rewards/claim'    => ['POST', '/api/v1/referrals/rewards/claim'],
        ], 'referral.write');
    }

    // ─────────────── FIX-REVGEN-04/05: کیف پول ───────────────

    public function test_wallet_gap_routes_are_scoped(): void
    {
        $this->assertScoped([
            'GET /api/v1/wallet/investments/profit-history' => ['GET', '/api/v1/wallet/investments/profit-history'],
        ], 'wallet.read');

        $vote = $this->findRoute('POST', '/api/v1/wallet/lottery/vote');
        $this->assertNotNull($vote, 'POST /api/v1/wallet/lottery/vote باید ثبت شده باشد');
        $this->assertSame('wallet.write', $this->authScope($vote), 'رأی لاتری = wallet.write (هم‌قواعد lotteryJoin)');
        // kill-switch لاتری هر دو کانال را می‌بندد (FIX-S17-02)
        $hasFeatureGate = false;
        foreach ($vote as $mw) {
            if (is_string($mw) && str_contains($mw, 'RequireFeature') && str_contains($mw, 'lottery')) {
                $hasFeatureGate = true;
            }
        }
        $this->assertTrue($hasFeatureGate, 'رأی لاتری باید gate لاتری داشته باشد (kill-switch)');
    }

    // ─────────────── FIX-REVGEN-03: کوپن (coupon.read مطابق FIX-MOBILE-06) ───────────────

    public function test_coupon_validate_route_is_scoped(): void
    {
        $this->assertScoped([
            'POST /api/v1/coupons/validate' => ['POST', '/api/v1/coupons/validate'],
        ], 'coupon.read');
    }

    /**
     * 🛡️ FIX-REVGEN-ALIGN: کنترلر زندهٔ درخت — ContentApiController (نه
     * ContentSubmissionApiController نسخهٔ revgen-q4 که اعمال نشد).
     */
    public function test_new_controllers_exist_and_extend_base_api(): void
    {
        foreach ([
            \App\Controllers\Api\ContentApiController::class,
            \App\Controllers\Api\ReferralApiController::class,
            \App\Controllers\Api\CouponApiController::class,
        ] as $class) {
            $this->assertTrue(class_exists($class));
            $this->assertTrue(
                (new \ReflectionClass($class))->isSubclassOf(\App\Controllers\Api\BaseApiController::class),
                "{$class} باید از BaseApiController extends کند"
            );
        }
    }
}
