<?php

namespace Tests\Integration\ContainerBacked\Core;

use PHPUnit\Framework\TestCase;
use Core\Queue;
use Core\Database;
use Core\EventDispatcher;
use Core\Event;
use Mockery as m;

use Mockery\Adapter\Phpunit\MockeryPHPUnitIntegration;
/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
class EventDispatcherTest extends TestCase
{
    // انتظاراتِ Mockery را به ادعای واقعی PHPUnit تبدیل می‌کند،
    // تا ادعای تهی برای دفعِ هشدارِ risky لازم نباشد.
    use MockeryPHPUnitIntegration;

    private \Core\Container $container;

    protected function setUp(): void
    {
        parent::setUp();
        ini_set('error_log', sys_get_temp_dir() . '/chortke-phpunit-error.log');
        $this->expectOutputRegex('/.*/');
        $this->container = \Core\Container::getInstance();

    }

    protected function tearDown(): void
    {
        // فقط mock هایی که خودمون register کردیم رو forget کن
        // Database رو forget نکن — بقیه تست‌ها بهش نیاز دارن

        m::close();
        parent::tearDown();
    }

    /** @test */
    public function it_continues_to_propagate_events_if_one_listener_throws_exception(): void
    {
        $queueMock = m::mock(Queue::class);
        $dbMock = m::mock(Database::class);
        $loggerMock = m::mock(\App\Contracts\LoggerInterface::class);

        $this->container->instance(Queue::class, $queueMock);
        $this->container->instance(Database::class, $dbMock);
        $this->container->instance(\App\Contracts\LoggerInterface::class, $loggerMock);

        $dispatcher = new EventDispatcher($queueMock);

        $firstExecuted = false;
        $secondExecuted = false;

        // Register first listener that throws an exception
        $dispatcher->listen('test.event', function ($event) use (&$firstExecuted) {
            $firstExecuted = true;
            throw new \RuntimeException("Something went wrong in listener 1");
        });

        // Register second listener that should execute successfully
        $dispatcher->listen('test.event', function ($event) use (&$secondExecuted) {
            $secondExecuted = true;
        });

        // The logger should receive the error call
        $loggerMock->shouldReceive('error')->with('event.listener_failed', m::on(function ($args) {
            return $args['event'] === 'test.event' &&
                   $args['listener'] === 'closure' &&
                   str_contains($args['error'], 'Something went wrong in listener 1');
        }))->once();

        // The logger should receive info calls (allow any number due to optional auditing dispatch loops)
        $loggerMock->shouldReceive('info')->with('event.dispatched', m::any());

        // The database should receive an insert into event_failures
        $dbMock->shouldReceive('execute')->with(
            m::on(function ($sql) {
                return str_contains($sql, 'INSERT INTO event_failures');
            }),
            m::on(function ($bindings) {
                return $bindings[0] === 'test.event' &&
                       $bindings[1] === 'closure' &&
                       str_contains($bindings[3], 'Something went wrong in listener 1');
            })
        )->once();

        $dispatcher->dispatch('test.event', ['some' => 'data']);

        $this->assertTrue($firstExecuted);
        $this->assertTrue($secondExecuted);
    }

    /** @test */
    public function it_continues_execution_even_if_logger_throws_exception(): void
    {
        $queueMock = m::mock(Queue::class);
        $dbMock = m::mock(Database::class);
        $loggerMock = m::mock(\App\Contracts\LoggerInterface::class);

        $this->container->instance(Queue::class, $queueMock);
        $this->container->instance(Database::class, $dbMock);
        $this->container->instance(\App\Contracts\LoggerInterface::class, $loggerMock);

        $dispatcher = new EventDispatcher($queueMock);

        $executed = false;

        $dispatcher->listen('test.event', function ($event) use (&$executed) {
            $executed = true;
        });

        // Logger throws an exception when info is called
        $loggerMock->shouldReceive('info')->andThrow(new \RuntimeException("Logger is broken"));

        $dispatcher->dispatch('test.event', ['some' => 'data']);

        $this->assertTrue($executed);
    }

    /** @test */
    public function it_gracefully_handles_missing_event_name_in_queued_event(): void
    {
        /*
        | FIX-YAFTE10 (یافته ۱۰): قرارداد FIX-S3-1 — payloadِ بدون event_name دیگر
        | «downgrade بی‌صدا» نیست؛ warning لاگ می‌شود و سپس InvalidArgumentException
        | پرتاب می‌شود تا QueueWorker بتواند retry/DLQ کند (fail-loud).
        */
        $queueMock = m::mock(Queue::class);
        $loggerMock = m::mock(\App\Contracts\LoggerInterface::class);

        $this->container->instance(Queue::class, $queueMock);
        $this->container->instance(\App\Contracts\LoggerInterface::class, $loggerMock);

        $dispatcher = new EventDispatcher($queueMock);

        $loggerMock->shouldReceive('warning')->with('event.queue.missing_payload', m::any())->once();

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('missing event_name');

        $dispatcher->processQueuedEvent(['id' => 123, 'data' => []]);
    }

    /** @test */
    public function it_safely_dlqs_reconstruction_failures_in_process_queued_event(): void
    {
        /*
        | FIX-YAFTE10: قرارداد FIX-S3-1 — کلاس ناموجود دیگر downgrade نمی‌شود؛
        | error لاگ می‌شود و استثنا پرتاب می‌شود (به عهدهٔ QueueWorker: retry/DLQ).
        */
        $queueMock = m::mock(Queue::class);
        $dbMock = m::mock(Database::class);
        $loggerMock = m::mock(\App\Contracts\LoggerInterface::class);

        $this->container->instance(Queue::class, $queueMock);
        $this->container->instance(Database::class, $dbMock);
        $this->container->instance(\App\Contracts\LoggerInterface::class, $loggerMock);

        $dispatcher = new EventDispatcher($queueMock);

        $job = [
            'id' => 999,
            'data' => [
                'event_name' => 'test.queued.event',
                'event_class' => 'NonExistentEventClassThatWillFail',
                'event_data' => ['key' => 'value']
            ]
        ];

        $loggerMock->shouldReceive('info')->withAnyArgs()->zeroOrMoreTimes();
        $loggerMock->shouldReceive('warning')->withAnyArgs()->zeroOrMoreTimes();
        $loggerMock->shouldReceive('error')->with('event.queue.reconstruction_failed', m::on(function ($args) {
            return $args['event_name'] === 'test.queued.event' && $args['job_id'] === 999;
        }))->once();

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Queued event class was not found: NonExistentEventClassThatWillFail');

        $dispatcher->processQueuedEvent($job);
    }

    /** @test */
    public function it_blocks_non_event_class_from_queue_payload_before_reconstruction(): void
    {
        // FIX-S3-1: event_class از payload صف فقط وقتی مجاز است که زیرکلاس Core\Event باشد.
        // QueuePayloadProbeClass (Tests\Support) عمداً Event نیست ولی fromPayload استاتیک دارد —
        // دقیقاً همان سطح حملهٔ قبلی (class_exists تنها گیت بود).
        \Tests\Support\QueuePayloadProbeClass::reset();

        $queueMock = m::mock(Queue::class);
        $loggerMock = m::mock(\App\Contracts\LoggerInterface::class);

        $this->container->instance(Queue::class, $queueMock);
        $this->container->instance(\App\Contracts\LoggerInterface::class, $loggerMock);

        $dispatcher = new EventDispatcher($queueMock);

        $job = [
            'id' => 4242,
            'data' => [
                'event_name'  => 'test.probe.event',
                'event_class' => \Tests\Support\QueuePayloadProbeClass::class,
                'event_data'  => ['marker' => 'attacker-controlled'],
            ],
        ];

        /*
        | FIX-YAFTE10: قرارداد FIX-S3-1 — کلاسِ خارج از Core\Event نه downgrade
        | می‌شود نه fromPayload صدا می‌خورد؛ error + استثنا (fail-loud).
        */
        $loggerMock->shouldReceive('info')->withAnyArgs()->zeroOrMoreTimes();
        $loggerMock->shouldReceive('warning')->withAnyArgs()->zeroOrMoreTimes();
        $loggerMock->shouldReceive('error')->with('event.queue.reconstruction_failed', m::any())->once();

        /*
        | FIX-YAFTE10: با try/catch (نه expectException) تا گاردِ fromPayload بعد از
        | استثنا هم قابل اطلاع باشد — طبق قرارداد FIX-S3-1 کلاس غیر-Event هرگز
        * fromPayload نمی‌گیرد.
        */
        $thrown = null;
        try {
            $dispatcher->processQueuedEvent($job);
        } catch (\InvalidArgumentException $e) {
            $thrown = $e;
        }

        $this->assertNotNull($thrown, 'کلاس غیر-Event باید fail-loud باشد');
        $this->assertStringContainsString('is not a Core\Event', $thrown->getMessage());
        $this->assertFalse(
            \Tests\Support\QueuePayloadProbeClass::$fromPayloadCalled,
            'fromPayload of a non-Event class must never be invoked from queue payload'
        );
    }

    /** @test */
    public function it_still_reconstructs_legit_event_subclass_from_queue_payload(): void
    {
        // FIX-S3-1 نباید مسیر مشروع را ببندد: GenericEvent زیرکلاس Event است
        // و باید مثل قبل بازسازی و dispatch شود (بدون downgrade).
        $queueMock = m::mock(Queue::class);
        $loggerMock = m::mock(\App\Contracts\LoggerInterface::class);

        $this->container->instance(Queue::class, $queueMock);
        $this->container->instance(\App\Contracts\LoggerInterface::class, $loggerMock);

        $dispatcher = new EventDispatcher($queueMock);

        $job = [
            'id' => 5151,
            'data' => [
                'event_name'  => 'test.legit.event',
                'event_class' => \Core\GenericEvent::class,
                'event_data'  => ['foo' => 'bar'],
            ],
        ];

        // شنونده ثبت می‌شود تا dispatch مسیر کامل را طی کند و رویدادِ بازسازی‌شده
        // قابل مشاهده باشد (dispatch بدون listener زودهنگام return می‌کند).
        $captured = null;
        $dispatcher->listen('test.legit.event', function ($event) use (&$captured) {
            $captured = $event;
        });

        $loggerMock->shouldNotReceive('warning')->with('event.queue.reconstruction_downgraded', m::any());

        $loggerMock->shouldReceive('info')->with('event.dispatched', m::on(function ($args) {
            return $args['event_name'] === 'test.legit.event';
        }))->once();
        $loggerMock->shouldReceive('info')->withAnyArgs()->zeroOrMoreTimes();

        $dispatcher->processQueuedEvent($job);

        $this->assertInstanceOf(\Core\GenericEvent::class, $captured);
        $this->assertSame('bar', $captured->getData('foo'));
    }

    /** @test */
    public function it_masks_sensitive_keys_in_missing_payload_warning(): void
    {
        // FIX-S3-2: payloadِ لاگ‌شده در مسیر missing_payload باید مثل بقیهٔ مسیرها ماسک شود.
        $queueMock = m::mock(Queue::class);
        $loggerMock = m::mock(\App\Contracts\LoggerInterface::class);

        $this->container->instance(Queue::class, $queueMock);
        $this->container->instance(\App\Contracts\LoggerInterface::class, $loggerMock);

        $dispatcher = new EventDispatcher($queueMock);

        $job = [
            'id' => 6161,
            'data' => [
                'password' => 'super-secret-value',
                'note'     => 'plain-value',
            ],
        ];

        $loggerMock->shouldReceive('warning')->with('event.queue.missing_payload', m::on(function ($args) {
            return $args['job_id'] === 6161
                && $args['payload']['password'] === '******** (masked)'
                && $args['payload']['note'] === 'plain-value';
        }))->once();

        /*
        | FIX-YAFTE10: پس از warningِ ماسک‌شده، مسیر fail-loud (FIX-S3-1) استثنا
        | می‌پراند تا QueueWorker retry/DLQ کند.
        */
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('missing event_name');

        $dispatcher->processQueuedEvent($job);
    }

    /** @test */
    public function it_handles_missing_event_class_gracefully(): void
    {
        /*
        | FIX-YAFTE10: event_class غایب (null) → GenericEvent طبق قرارداد قدیمی
        | (ردیف‌های قدیمی صف ممکن است کلاس نداشته باشند) — بدون warningِ downgrade.
        | برای عبور از Strict Delivery باید listener ثبت شود (بدون listener،
        | dispatchOrFail همان‌جا fail-loud می‌شود).
        */
        $queueMock = m::mock(Queue::class);
        $loggerMock = m::mock(\App\Contracts\LoggerInterface::class);

        $this->container->instance(Queue::class, $queueMock);
        $this->container->instance(\App\Contracts\LoggerInterface::class, $loggerMock);

        $dispatcher = new EventDispatcher($queueMock);

        $job = [
            'id' => 777,
            'data' => [
                'event_name' => 'test.no_class.event',
                'event_data' => ['foo' => 'bar']
            ]
        ];

        $captured = null;
        $dispatcher->listen('test.no_class.event', function ($event) use (&$captured) {
            $captured = $event;
        });

        $loggerMock->shouldNotReceive('warning')->with('event.queue.reconstruction_downgraded', m::any());
        $loggerMock->shouldReceive('info')->withAnyArgs()->zeroOrMoreTimes();
        $loggerMock->shouldReceive('warning')->withAnyArgs()->zeroOrMoreTimes();

        $dispatcher->processQueuedEvent($job);

        $this->assertInstanceOf(\Core\GenericEvent::class, $captured);
        $this->assertSame('bar', $captured->getData('foo'));
    }
}
