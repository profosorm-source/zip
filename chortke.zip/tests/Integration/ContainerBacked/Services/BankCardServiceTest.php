<?php

namespace Tests\Integration\ContainerBacked\Services;

use PHPUnit\Framework\TestCase;
use App\Services\BankCardService;
use Mockery as m;

/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
class BankCardServiceTest extends TestCase
{
    /** @var \Core\Database&\Mockery\MockInterface */
    private \Core\Database $db;
    /** @var \App\Contracts\LoggerInterface&\Mockery\MockInterface */
    private \App\Contracts\LoggerInterface $logger;
    /** @var \App\Models\BankCard&\Mockery\MockInterface */
    private \App\Models\BankCard $model;
    /** @var \App\Models\User&\Mockery\MockInterface */
    private \App\Models\User $userModel;
    /** @var \Core\Encryption&\Mockery\MockInterface */
    private \Core\Encryption $encryption;
    /** @var \App\Contracts\ValidatorFactoryInterface&\Mockery\MockInterface */
    private \App\Contracts\ValidatorFactoryInterface $validatorFactory;
    /** @var \App\Services\Shared\IdempotencyService&\Mockery\MockInterface */
    private \App\Services\Shared\IdempotencyService $idempotencyService;
    private BankCardService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock(\Core\Database::class);
        $this->logger = m::mock(\App\Contracts\LoggerInterface::class);
        $this->model = m::mock(\App\Models\BankCard::class);
        $this->userModel = m::mock(\App\Models\User::class);
        $this->encryption = m::mock(\Core\Encryption::class);
        $this->validatorFactory = m::mock(\App\Contracts\ValidatorFactoryInterface::class);
        $this->idempotencyService = m::mock(\App\Services\Shared\IdempotencyService::class);

        $this->logger->shouldIgnoreMissing();
        $this->db->shouldReceive('inTransaction')->byDefault()->andReturn(false);
        $this->db->shouldReceive('beginTransaction')->byDefault();
        $this->db->shouldReceive('commit')->byDefault();
        $this->db->shouldReceive('rollBack')->byDefault();

        // Register Database mock inside Container
        \Core\Container::getInstance()->instance(\Core\Database::class, $this->db);

        $this->service = new BankCardService(
            $this->db,
            $this->logger,
            $this->model,
            $this->userModel,
            $this->encryption,
            $this->validatorFactory,
            $this->idempotencyService
        );
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function service_can_be_instantiated(): void
    {
        $this->assertInstanceOf(BankCardService::class, $this->service);
    }

    /** @test */
    public function create_bank_card_fails_if_limit_exceeded(): void
    {
        $userId = 1;
        $data = [
            'card_number' => '6037991234567890', // valid Luhn is not strictly checked if mock handles validation, but we can use real Luhn to be safe
            'card_holder' => 'علیرضا رضاپور',
            'iban' => ''
        ];

        // Validation success mock
        $validator = m::mock(\Core\Validator::class);
        $validator->shouldReceive('custom')->twice();
        $validator->shouldReceive('result')->once()->andReturn([
            'valid' => true,
            'errors' => []
        ]);
        $this->validatorFactory->shouldReceive('make')->once()->andReturn($validator);

        // User lookup mock
        $userMock = (object)[
            'id' => $userId,
            'full_name' => 'علیرضا رضاپور'
        ];
        $this->userModel->shouldReceive('find')->with($userId)->once()->andReturn($userMock);

        // Mock Idempotency
        $this->idempotencyService->shouldReceive('executeWithTransaction')
            ->once()
            ->andReturnUsing(function($scope, $actorId, $payload, $callback, $key = null) {
                return $callback();
            });

        // FIX-R36-W3 (F-A12-20): قفل ردیف کاربر پیش از شمارش کارت‌ها —
        // ثبت کارت per-user سریالایز می‌شود (ضد check-then-insert race)
        $this->db->shouldReceive('query')
            ->once()
            ->with("SELECT id FROM users WHERE id = ? FOR UPDATE", [$userId])
            ->andReturn(m::mock(\PDOStatement::class));

        // Set active cards to 4 (exceeded)
        $this->model->shouldReceive('countUserCards')->with($userId)->once()->andReturn(4);

        $result = $this->service->create($userId, $data);

        $this->assertFalse($result['success']);
        $this->assertEquals('حداکثر ۴ کارت بانکی مجاز است', $result['message']);
    }

    /** @test */
    public function create_bank_card_success(): void
    {
        $userId = 1;
        $data = [
            'card_number' => '6037991823157540', // valid Luhn
            'card_holder' => 'علیرضا رضاپور',
            'iban' => ''
        ];

        $validator = m::mock(\Core\Validator::class);
        $validator->shouldReceive('custom')->twice();
        $validator->shouldReceive('result')->once()->andReturn([
            'valid' => true,
            'errors' => []
        ]);
        $this->validatorFactory->shouldReceive('make')->once()->andReturn($validator);

        $userMock = (object)[
            'id' => $userId,
            'full_name' => 'علیرضا رضاپور'
        ];
        $this->userModel->shouldReceive('find')->with($userId)->once()->andReturn($userMock);

        $this->idempotencyService->shouldReceive('executeWithTransaction')
            ->once()
            ->andReturnUsing(function($scope, $actorId, $payload, $callback, $key = null) {
                return $callback();
            });

        // FIX-R36-W3 (F-A12-20): قفل ردیف کاربر پیش از شمارش کارت‌ها
        $this->db->shouldReceive('query')
            ->once()
            ->with("SELECT id FROM users WHERE id = ? FOR UPDATE", [$userId])
            ->andReturn(m::mock(\PDOStatement::class));

        // No cards yet
        $this->model->shouldReceive('countUserCards')->with($userId)->once()->andReturn(0);

        // Encryption mock
        $this->encryption->shouldReceive('encrypt')->andReturn('encrypted_value');

        // Check duplicated card
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once();
        $stmt->shouldReceive('fetch')->once()->andReturn(false); // not duplicate

        $this->db->shouldReceive('prepare')->once()->andReturn($stmt);

        // Create card mock
        $this->model->shouldReceive('createBankCard')->once()->andReturn((object)['id' => 456]);

        $result = $this->service->create($userId, $data);

        $this->assertTrue($result['success']);
        $this->assertEquals('کارت ثبت شد و در انتظار تأیید است', $result['message']);
        $this->assertEquals(456, $result['card_id']);
    }

    /** @test */
    public function admin_verify_approves_card_for_verified_user(): void
    {
        $adminId = 99;
        $cardId = 123;

        // DB Lock mock
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('fetch')->once()->andReturn((object)[
            'id' => $cardId,
            'user_id' => 1,
            'status' => 'pending',
            'owner_name' => 'encrypted_name'
        ]);
        $this->db->shouldReceive('query')->once()->andReturn($stmt);

        // User is verified (KYC status verified)
        $userMock = (object)[
            'id' => 1,
            'kyc_status' => 'verified',
            'full_name' => 'علیرضا رضاپور'
        ];
        $this->userModel->shouldReceive('find')->with(1)->once()->andReturn($userMock);

        /*
        | FIX-YAFTE12 (یافته ۱۲): adminVerify مسیر سخت‌گیرانهٔ FIX-M10-13
        | (KycEligibilityService از container) و decryptForContext (FIX-M2M12)
        | دارد؛ تست قبلی decrypt بدون context و بدون گیت KYC بود.
        */
        $kycEligibility = m::mock(\App\Services\KYC\KycEligibilityService::class);
        $kycEligibility->shouldReceive('isEligible')->once()->with(1)->andReturn(true);
        \Core\Container::getInstance()->instance(\App\Services\KYC\KycEligibilityService::class, $kycEligibility);

        // Decryption of name mock — decrypt مقید به context (FIX-M2M12)
        $this->encryption->shouldReceive('decryptForContext')
            ->with('encrypted_name', 'bank.owner_name')
            ->once()
            ->andReturn('علیرضا رضاپور');

        // Update status in DB
        $this->model->shouldReceive('updateStatus')
            ->with($cardId, 'verified', null, $adminId)
            ->once()
            ->andReturn(true);

        $result = $this->service->adminVerify($adminId, $cardId, true);

        $this->assertTrue($result['success']);
        $this->assertEquals('کارت تأیید شد', $result['message']);
    }

    /** @test */
    public function admin_verify_rejects_card_properly(): void
    {
        $adminId = 99;
        $cardId = 123;

        // DB Lock mock
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('fetch')->once()->andReturn((object)[
            'id' => $cardId,
            'user_id' => 1,
            'status' => 'pending'
        ]);
        $this->db->shouldReceive('query')->once()->andReturn($stmt);

        // Update status in DB to rejected
        $this->model->shouldReceive('updateStatus')
            ->with($cardId, 'rejected', 'Incorrect holder name', $adminId)
            ->once()
            ->andReturn(true);

        $result = $this->service->adminVerify($adminId, $cardId, false, 'Incorrect holder name');

        $this->assertTrue($result['success']);
        $this->assertEquals('کارت رد شد', $result['message']);
    }

    /** @test */
    public function masked_card_list_never_exposes_full_pan(): void
    {
        // P1-2 (S33 audit): API card list must return the masked PAN only.
        $raw = [
            (object)[
                'id' => 7,
                'card_number' => 'enc-6037991823157540',
                'owner_name' => 'enc-owner',
                'bank_name' => 'Melli',
                'status' => 'verified',
                'is_default' => 1,
            ],
        ];
        $this->model->shouldReceive('getUserCards')
            ->with(9, null)
            ->once()
            ->andReturn($raw);
        /*
        | FIX-YAFTE12 (یافته ۱۲): FIX-M2M12 — decrypt مقید به context ستون
        | (tryDecryptForContext با 'bank.card_number'/'bank.owner_name).
        */
        $this->encryption->shouldReceive('tryDecryptForContext')
            ->with('enc-6037991823157540', 'bank.card_number')
            ->andReturn('6037991823157540');
        $this->encryption->shouldReceive('tryDecryptForContext')
            ->with('enc-owner', 'bank.owner_name')
            ->andReturn('Runtime User');

        $cards = $this->service->listForUserMasked(9);

        $this->assertCount(1, $cards);
        $this->assertSame('************7540', (string)$cards[0]->card_number);
        $this->assertStringNotContainsString('6037991823157540', (string)$cards[0]->card_number);
        $this->assertSame('Runtime User', (string)$cards[0]->owner_name);
    }

    /** @test */
    public function mask_pan_handles_separators_and_garbage(): void
    {
        $this->assertSame('************7540', $this->service->maskPan('6037-9918-2315-7540'));
        $this->assertSame('****', $this->service->maskPan('123'));
        $this->assertSame('****', $this->service->maskPan(''));
        $this->assertSame('****', $this->service->maskPan('no-digits-here'));
    }
}
