<?php

declare(strict_types=1);

namespace Tests\Integration\ContainerBacked\Services;

use PHPUnit\Framework\TestCase;
use App\Services\Payment\PaymentDepositService;
use App\Services\Payment\PaymentService;
use App\Services\CryptoDeposit\CryptoDepositService;

/**
 * 🛡️ FIX-R16B — superseded regression pin (S4-C1 / S4-H2 / S33-B4 audit).
 *
 * The original four tests of this class exercised fulfillCryptoDeposit() as a
 * "fail-closed completion step". That middle-ground contract was later
 * deliberately retired: the ONLY crypto-deposit crediting site is
 * CryptoDepositService::approve() (cron auto-verify and admin approve both
 * reach it) which credits the wallet with the fixed idempotency key
 * IdempotencyKeys::cryptoDepositApprove() AND flips the legacy `status`
 * column to 'completed' inside the SAME transaction (single status moment).
 * Any separate "fulfillment" method — even a credit-free one — is a second
 * crediting path waiting to happen (S25MoneyFixesTest pins its removal).
 *
 * This class now pins the removal contract itself:
 *  - fulfillCryptoDeposit() must NOT exist on PaymentDepositService
 *  - fulfillCryptoDeposit() must NOT exist on the PaymentService facade
 *  - approveManualDeposit() must remain the manual-deposit crediting path
 *  - CryptoDepositService::approve() must remain the crypto crediting path
 */
class PaymentCryptoFulfillmentTest extends TestCase
{
    public function test_fulfill_crypto_deposit_is_removed_from_deposit_service(): void
    {
        $this->assertFalse(
            method_exists(PaymentDepositService::class, 'fulfillCryptoDeposit'),
            'fulfillCryptoDeposit must stay removed from PaymentDepositService'
        );
    }

    public function test_fulfill_crypto_deposit_is_removed_from_payment_facade(): void
    {
        $this->assertFalse(
            method_exists(PaymentService::class, 'fulfillCryptoDeposit'),
            'fulfillCryptoDeposit must stay removed from the PaymentService facade'
        );
    }

    public function test_manual_deposit_crediting_path_remains_single(): void
    {
        $this->assertTrue(
            method_exists(PaymentDepositService::class, 'approveManualDeposit'),
            'approveManualDeposit must remain the manual-deposit crediting path'
        );
        $this->assertTrue(
            method_exists(PaymentService::class, 'approveManualDeposit'),
            'the PaymentService facade must keep exposing approveManualDeposit'
        );
    }

    public function test_crypto_crediting_path_is_exclusively_approve(): void
    {
        $this->assertTrue(
            method_exists(CryptoDepositService::class, 'approve'),
            'CryptoDepositService::approve() must remain the single crypto crediting site'
        );
        $rc = new \ReflectionMethod(CryptoDepositService::class, 'approve');
        $body = (string)file_get_contents(__DIR__ . '/../../../../app/Services/CryptoDeposit/CryptoDepositService.php');
        // Single-status-moment pin (S4-H2): approve() itself closes the legacy
        // status column in the same transaction — no external fulfiller needed.
        $this->assertStringContainsString(
            "SET status = 'completed'",
            $body,
            'approve() must flip the legacy status column inside its own transaction'
        );
        // approve(adminId, depositId) signature kept — callers (admin UI + cron) unchanged.
        $this->assertGreaterThanOrEqual(2, $rc->getNumberOfParameters());
    }
}
