<?php

declare(strict_types=1);

namespace Tests\Integration\ContainerBacked\Services;

use PHPUnit\Framework\TestCase;
use App\Services\Auth\SessionService;
use App\Services\User\AccountDeletionService;
use Core\Application;
use Core\Database;
use Mockery as m;

/**
 * S5 identity hardening regressions (S33-B5 audit).
 *
 * H1: invalidateAllUserSessions must DESTROY the session payloads
 *     (CHORTKE_SESSION:*), not just flip the DB row — otherwise sessions
 *     survive a password reset (hijack after credential rotation).
 * H3: the deletion-saga purge referenced non-existent columns
 *     (password_resets.user_id / search_projections.user_id /
 *     kyc_documents.user_id) and always threw — NO account could ever be
 *     deleted. The fixed statements must run cleanly against the real schema.
 */
final class S5IdentityHardeningTest extends TestCase
{
    private ?Database $db = null;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Application::getInstance()->container->make(Database::class);
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /**
     * H3: schema-contract test — runs the exact purge statements from
     * AccountDeletionService against the REAL schema. Reverting any of them
     * to a phantom column makes this test fail with an SQL error.
     */
    public function test_deletion_purge_statements_match_real_schema(): void
    {
        $db = $this->db;
        $this->assertNotNull($db);

        $uid = 0;
        $email = 's5-purge-regression@chortke-test.ir';

        // FK safety: kyc_verifications.user_id references users(id) — pick a real
        // seed user that currently has NO kyc rows, so the purge DELETEs only
        // touch our own fixture.
        $uid = (int)$db->fetchColumn(
            'SELECT u.id FROM users u LEFT JOIN kyc_verifications k ON k.user_id = u.id
             WHERE k.id IS NULL AND u.id <= 10 ORDER BY u.id LIMIT 1'
        );
        $this->assertGreaterThan(0, $uid, 'no seed user without kyc rows available');

        // Pre-clean any leftovers from earlier runs, then re-seed.
        $db->execute("DELETE FROM kyc_documents WHERE kyc_id IN (SELECT id FROM kyc_verifications WHERE user_id = ?)", [$uid]);
        $db->execute("DELETE FROM kyc_verifications WHERE user_id = ?", [$uid]);
        $db->execute("DELETE FROM search_projections WHERE entity_type = 'user' AND entity_id = ?", [$uid]);
        $db->execute("DELETE FROM password_resets WHERE email = ?", [$email]);

        // Fixture rows (cleaned in finally).
        $db->execute(
            "INSERT IGNORE INTO password_resets (email, token, created_at) VALUES (?, ?, NOW())",
            [$email, 's5regressiontoken']
        );
        $db->execute(
            "INSERT INTO search_projections (entity_type, entity_id, title, content, is_active, created_at, updated_at)
             VALUES ('user', ?, 'S5 regression', 'content', 1, NOW(), NOW())",
            [$uid]
        );
        $db->execute(
            "INSERT INTO kyc_verifications (user_id, status, created_at)
             VALUES (?, 'pending', NOW())",
            [$uid]
        );
        $kycId = (int)$db->fetchColumn('SELECT id FROM kyc_verifications WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$uid]);
        $db->execute(
            "INSERT INTO kyc_documents (kyc_id, doc_type, file_path, created_at)
             VALUES (?, 'national_card', '/tmp/s5-regression.png', NOW())",
            [$kycId]
        );

        try {
            // The exact fixed statements from the purge step.
            $userEmail = (string)($db->fetchColumn("SELECT email FROM users WHERE id = ?", [$uid]) ?? '');
            $this->assertNotSame('', $userEmail, 'the fixture user must exist with an email');
            $db->execute("DELETE FROM password_resets WHERE email = ?", [$email]);
            $db->execute("DELETE FROM search_projections WHERE entity_type = 'user' AND entity_id = ?", [$uid]);
            $db->execute("DELETE FROM kyc_documents WHERE kyc_id IN (SELECT id FROM kyc_verifications WHERE user_id = ?)", [$uid]);
            $db->execute("DELETE FROM kyc_verifications WHERE user_id = ?", [$uid]);

            $this->assertSame(0, (int)$db->fetchColumn('SELECT COUNT(*) FROM password_resets WHERE email = ?', [$email]));
            $this->assertSame(0, (int)$db->fetchColumn("SELECT COUNT(*) FROM search_projections WHERE entity_type = 'user' AND entity_id = ?", [$uid]));
            $this->assertSame(0, (int)$db->fetchColumn('SELECT COUNT(*) FROM kyc_documents WHERE kyc_id = ?', [$kycId]));
        } finally {
            $db->execute("DELETE FROM password_resets WHERE email = ?", [$email]);
            $db->execute("DELETE FROM kyc_documents WHERE kyc_id IN (SELECT id FROM kyc_verifications WHERE user_id = ?)", [$uid]);
            $db->execute("DELETE FROM kyc_verifications WHERE user_id = ?", [$uid]);
            $db->execute("DELETE FROM search_projections WHERE entity_type = 'user' AND entity_id = ?", [$uid]);
        }
    }

    /**
     * H1: payload keys must be destroyed for every revoked session.
     */
    public function test_invalidate_all_destroys_session_payload_keys(): void
    {
        $redis = m::mock(\Core\Redis::class);
        $model = m::mock(\App\Models\SecurityModel::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        $sessions = [
            (object)['session_id' => 'sess-hijack-1'],
            (object)['session_id' => 'sess-hijack-2'],
            (object)['session_id' => 'sess-keep-me'],
        ];

        $model->shouldReceive('getActiveSessions')->once()->with(77)->andReturn($sessions);
        $model->shouldReceive('deactivateUserSessions')->once()->with(77, 'sess-keep-me')->andReturn(true);

        $redis->shouldReceive('isAvailable')->once()->andReturn(true);
        foreach (['sess-hijack-1', 'sess-hijack-2'] as $sid) {
            $redis->shouldReceive('delete')->once()->with('session:activity:' . $sid);
            $redis->shouldReceive('delete')->once()->with('CHORTKE_SESSION:' . $sid);
        }
        $redis->shouldReceive('delete')->never()->with('CHORTKE_SESSION:sess-keep-me');

        $service = new SessionService(
            $redis,
            $this->db,
            $logger,
            $model,
            m::mock(\App\Services\AntiFraud\RiskPolicyService::class)->shouldIgnoreMissing(),
            m::mock(\App\Services\DistributedLockService::class)->shouldIgnoreMissing()
        );
        $this->assertTrue($service->invalidateAllUserSessions(77, 'sess-keep-me'));
    }
}
