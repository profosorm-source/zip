<?php

declare(strict_types=1);

namespace Tests\Integration\ContainerBacked\Services;

use PHPUnit\Framework\TestCase;
use App\Services\User\AccountDeletionService;
use App\Events\AccountDeletedEvent;
use Core\Container;
use Core\Database;
use Core\EventDispatcher;

/**
 * بچ S28 — FIX-HAD-WIRE: سیم‌کشی زنجیرهٔ رویداد حذف حساب.
 *
 * پیش از این فیکس، HandleAccountDeleted و AccountDeletedEvent «جفت مرده» بودند:
 *   ۱) listener هیچ‌جا register نشده بود (AppServiceProvider).
 *   ۲) هیچ producer ای رویداد را dispatch نمی‌کرد (ساگا در AccountDeletionService).
 * در نتیجه سه عملِ listener (هشدار موجودی معوق به ادمین، بستن escrowهای باز
 * ads/investments/submissions، آدیت نهایی account.deleted) هرگز اجرا نمی‌شد و
 * تنها جایی که آن‌ها را انجام می‌داد همین listener بود (یافتهٔ ممیزی S18).
 *
 * این تست رفتاریِ هر دو نیمه را روی MariaDB واقعی قفل می‌کند:
 *   - dispatch دقیقاً «یک‌بار» پس از commit موفق ساگا، با بارِ درست (userId/email/reason)
 *   - اثرات DB ای listener: لغو ads/investments باز + ردیف audit_logs با action='account.deleted'
 *   - مسیرِ رد (گارد FIX-S16-2، درخواست cancelled) هرگز dispatch نمی‌کند
 *
 * رویداد با «نمونهٔ typed» dispatch می‌شود (نه آرایه) تا EventDispatcher آن را در
 * GenericEvent نپیچد و امضای typedِ HandleAccountDeleted::handle سالم بماند.
 */
final class AccountDeletionEventWiringTest extends TestCase
{
    /** @var list<string> */
    private array $cleanupTables = [];
    /** @var list<int> */
    private array $cleanupIds = [];

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        foreach ($this->cleanupIds as $i => $id) {
            $table = $this->cleanupTables[$i] ?? null;
            if ($table === null) {
                continue;
            }
            try {
                $db->table($table)->where('id', '=', $id)->delete();
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        $this->cleanupIds = [];
        $this->cleanupTables = [];
        parent::tearDown();
    }

    private function trackCleanup(string $table, int $id): void
    {
        $this->cleanupTables[] = $table;
        $this->cleanupIds[] = $id;
    }

    private function db(): Database
    {
        return Database::getInstance();
    }

    /** کاربر اختصاصی تست — نه firstActiveUserId (ساگا او را به status='deleted' می‌برد) */
    private function seedUser(string $email): int
    {
        $db = $this->db();
        $db->table('users')->insert([
            'email'     => $email,
            'username'  => 's28_' . bin2hex(random_bytes(5)),
            'full_name' => 'S28 Wiring Fixture',
            'password'  => 'not-a-real-hash',
            'status'    => 'active',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        $id = (int)$db->fetchColumn('SELECT id FROM users WHERE email = ?', [$email]);
        $this->assertGreaterThan(0, $id, 'فیکسچر کاربر باید ساخته شود');
        $this->trackCleanup('users', $id);
        return $id;
    }

    private function seedDeletionRequest(int $userId, string $status): int
    {
        $db = $this->db();
        $db->table('account_deletion_logs')->insert([
            'user_id'      => $userId,
            'reason'       => 'S28 wiring fixture',
            'status'       => $status,
            'requested_at' => date('Y-m-d H:i:s'),
            'expires_at'   => date('Y-m-d H:i:s', time() + 86400),
        ]);
        $logId = (int)$db->fetchColumn(
            'SELECT id FROM account_deletion_logs WHERE user_id = ? ORDER BY id DESC LIMIT 1',
            [$userId]
        );
        $this->trackCleanup('account_deletion_logs', $logId);
        return $logId;
    }

    public function test_delete_user_dispatches_event_once_and_listener_closes_open_items(): void
    {
        // خروجی لاگر کانتکست تست به stdout می‌رود — الگوی همان expectOutputRegex در S16
        $this->expectOutputRegex('/account_deletion\./');
        $db = $this->db();
        $uid = $this->seedUser('s28-wire-' . bin2hex(random_bytes(4)) . '@example.test');
        $email = (string)$db->fetchColumn('SELECT email FROM users WHERE id = ?', [$uid]);
        $this->seedDeletionRequest($uid, 'requested');

        // فیکسچرهای «escrow باز» — تنها جایی که این‌ها را می‌بندد HandleAccountDeleted است
        $db->table('ads')->insert([
            'user_id'      => $uid,
            'title'        => 'S28 wiring fixture ad',
            'type'         => 'banner',
            'status'       => 'active',
            'spent_budget' => 0,
            'budget'       => 0,
            'created_at'   => date('Y-m-d H:i:s'),
        ]);
        $adId = (int)$db->fetchColumn('SELECT id FROM ads WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$uid]);
        $this->trackCleanup('ads', $adId);

        $db->table('investments')->insert([
            'user_id'    => $uid,
            'amount'     => 1000,
            'status'     => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        $invId = (int)$db->fetchColumn('SELECT id FROM investments WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$uid]);
        $this->trackCleanup('investments', $invId);

        // فیکسچر تسک سفارشی — مسیر FIX-S28-SAGA-COL (ستون مالکیت = creator_id)
        $db->table('custom_tasks')->insert([
            'creator_id'       => $uid,
            'title'            => 'S28 wiring fixture task',
            'price_per_task'   => 100,
            'total_budget'     => 1000,
            'remaining_budget' => 1000,
            'total_count'      => 10,
            'remaining_count'  => 10,
            'status'           => 'active',
            'created_at'       => date('Y-m-d H:i:s'),
        ]);
        $taskId = (int)$db->fetchColumn('SELECT id FROM custom_tasks WHERE creator_id = ? ORDER BY id DESC LIMIT 1', [$uid]);
        $this->trackCleanup('custom_tasks', $taskId);

        // جاسوس رویداد روی همان dispatcher singleton ای که سرویس استفاده می‌کند
        $dispatcher = Container::getInstance()->make(EventDispatcher::class);
        /** @var list<AccountDeletedEvent> $captured */
        $captured = [];
        $dispatcher->listen(AccountDeletedEvent::class, static function (AccountDeletedEvent $event) use (&$captured): void {
            $captured[] = $event;
        });

        $service = Container::getInstance()->make(AccountDeletionService::class);
        $deleted = $service->deleteUserAccount($uid, 'S28 wiring test', 0);
        $this->assertTrue($deleted, 'ساگای حذف حساب باید موفق شود (درخواست requested با موجودی صفر)');

        // ۱) S7-FIX (EVT-001, هم‌ترازسازی تست): رویداد پس‌حذف دیگر in-process
        // dispatch نمی‌شود — داخل همان تراکنشِ ساگا در outbox پایدار شده است
        // (retry/DLQ پایدار؛ بدون double-dispatch). جاسوس in-process باید خالی بماند.
        $this->assertCount(0, $captured, 'مسیر outbox نباید dispatch درون-پروسه‌ای داشته باشد (fallback legacy فقط با outbox=null)');

        $outboxRow = $db->selectOne(
            "SELECT id, event_type, status, payload FROM outbox_events
             WHERE aggregate_type = 'account_deletion' AND aggregate_id = ? AND event_type = 'account.deleted.reconciliation'
             ORDER BY id DESC LIMIT 1",
            [(string)$uid]
        );
        $this->assertNotNull($outboxRow, 'رویداد پس‌حذف باید در outbox ثبت شود');
        $this->assertSame('pending', (string)$outboxRow->status);
        $payload = (array)(json_decode((string)$outboxRow->payload, true) ?? []);
        $this->assertSame(\App\Jobs\AccountDeleted\AccountDeletedReconciliationJob::class, (string)($payload['job'] ?? ''));
        $this->assertSame($uid, (int)($payload['data']['user_id'] ?? 0));
        $this->assertSame($email, (string)($payload['data']['email'] ?? ''), 'رویداد باید «ایمیل اصلی» را حمل کند (قبل از ناشناس‌سازی)');
        $this->assertSame('S28 wiring test', (string)($payload['data']['reason'] ?? ''));

        // تحویل: ناشرِ outbox همان‌طور که cron/daemon می‌کند job را به صف می‌دهد؛
        // اینجا معادلِ worker (پاپ از صف + اجرا) به‌صورت مستقیم و هم‌قرارداد
        // با سربرگِ job اجرا می‌شود (payload['data'] + _outbox_event_id).
        $job = Container::getInstance()->make(\App\Jobs\AccountDeleted\AccountDeletedReconciliationJob::class);
        $job->handle((array)($payload['data'] ?? []) + ['_outbox_event_id' => (int)$outboxRow->id]);

        // ۲) ساگا: حساب ناشناس‌سازی شده
        $row = $db->selectOne('SELECT status, email FROM users WHERE id = ?', [$uid]);
        $this->assertSame('deleted', (string)($row->status ?? ''), 'وضعیت کاربر باید deleted شود');
        $this->assertStringStartsWith('deleted_', (string)($row->email ?? ''), 'ایمیل باید ناشناس‌سازی شود');

        // ۳) اثرات listener: بستن escrowهای باز
        $this->assertSame('cancelled', (string)$db->fetchColumn('SELECT status FROM ads WHERE id = ?', [$adId]),
            'HandleAccountDeleted باید تبلیغ فعال را لغو کند (قبل از سیم‌کشی: هیچ‌کس این کار را نمی‌کرد)');
        $this->assertSame('cancelled', (string)$db->fetchColumn('SELECT status FROM investments WHERE id = ?', [$invId]),
            'HandleAccountDeleted باید سرمایه‌گذاری pending را لغو کند');
        // 🧹 FIX-COSMET-25 (A1-N11) — هم‌ترازسازی تست: جدول legacy custom_tasks هیچ
        // نویسنده‌ای ندارد (تسک‌های سفارشی واقعی در ads زندگی می‌کنند و همان بالا با
        // assertion «ads» پوشش داده شدند)؛ cancelUserCustomTasks که این ردیف را
        // no-op آپدیت می‌کرد حذف شد. قرارداد جدید: ساگا دیگر جدول legacy را لمس
        // نمی‌کند — ردیف باید دست‌نخورده بماند (پین حذف متد: CosmetPinningTest::test_d_26).
        $this->assertSame('active', (string)$db->fetchColumn('SELECT status FROM custom_tasks WHERE id = ?', [$taskId]),
            'FIX-COSMET-25/A1-N11: جدول legacy بدون-نویسندهٔ custom_tasks دیگر در ساگای حذف حساب نقش ندارد');

        // ۴) اثرات listener: آدیت نهایی account.deleted
        $auditAction = $db->fetchColumn(
            "SELECT action FROM audit_logs WHERE user_id = ? AND action = 'account.deleted' ORDER BY id DESC LIMIT 1",
            [$uid]
        );
        $this->assertSame('account.deleted', (string)($auditAction ?? ''), 'آدیت نهایی حذف باید ثبت شود');

        // بهداشت تست: ردیف outbox مصرف‌شده حذف شود تا اجراهای بعدی سوئیت
        // آن را pending نیابند (listener idempotent است ولی تست باید اثری نگذارد).
        try {
            $db->query('DELETE FROM outbox_events WHERE id = ?', [(int)$outboxRow->id]);
        } catch (\Throwable) {
            // teardown best-effort
        }
    }

    public function test_blocked_deletion_request_never_dispatches_event(): void
    {
        // هشدار account_deletion.blocked_non_requested به stdout می‌رود — مصرف می‌شود (الگوی S16)
        $this->expectOutputRegex('/account_deletion\.blocked_non_requested/');
        $db = $this->db();
        $uid = $this->seedUser('s28-nodisp-' . bin2hex(random_bytes(4)) . '@example.test');
        $this->seedDeletionRequest($uid, 'cancelled');

        $dispatcher = Container::getInstance()->make(EventDispatcher::class);
        /** @var list<AccountDeletedEvent> $captured */
        $captured = [];
        $dispatcher->listen(AccountDeletedEvent::class, static function (AccountDeletedEvent $event) use (&$captured): void {
            $captured[] = $event;
        });

        $service = Container::getInstance()->make(AccountDeletionService::class);
        $deleted = $service->deleteUserAccount($uid, 'S28 negative test', 0);

        $this->assertFalse($deleted, 'گارد FIX-S16-2 باید درخواست cancelled را رد کند');
        $this->assertCount(0, $captured, 'در مسیرِ رد هیچ رویدادی dispatch نباید شود');
        $status = (string)$db->fetchColumn('SELECT status FROM users WHERE id = ?', [$uid]);
        $this->assertSame('active', $status, 'حساب باید دست‌نخورده بماند');
    }
}
