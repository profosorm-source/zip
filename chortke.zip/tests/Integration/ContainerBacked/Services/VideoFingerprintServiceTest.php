<?php

declare(strict_types=1);

namespace Tests\Integration\ContainerBacked\Services;

use PHPUnit\Framework\TestCase;
use App\Services\AntiFraud\VideoFingerprintService;
use Core\Container;
use Core\Database;

/**
 * بچ S31 — VideoFingerprintService (بستهٔ «الف» — اتصال log-only با تأیید کاربر):
 *
 * پیش از این بچ، سرویس صفر ارجاع کدی داشت (dead-file) و سه نقص پین‌شده بود:
 *   ۱) FIX-S31-VF1: هیوریستیک شکستهٔ calculateConfidence (str_contains(videoId,'md5')
 *      هرگز fallback را تشخیص نمی‌داد) → مبتنی بر پرچم extracted شد.
 *   ۲) FIX-S31-VF2: cleanOldFingerprints بدون LIMIT → حذف دسته‌ای (batch).
 *   ۳) FIX-S31-VF3: بدون هوک کرون → 'video_fingerprint_cleanup' روزانه در Console/Kernel.
 *
 * اتصال: ContentService::validateVideoUrl → inspect() در حالت log-only
 * (فقط لاگ؛ هرگز block نمی‌کند). این تست روی MariaDB واقعی رفتار را قفل می‌کند.
 *
 * 🛡️ FIX-A24-02 (قرارداد جدید — نوشتن فقط پس از پذیرش):
 *   - checkDuplicate/inspect دیگر corpus نمی‌نویسند؛ ثبت فقط با
 *     recordFingerprint از سوی فراخوان پس از موفقیت ثبت/تأیید است.
 *   - validateVideoUrl (مسیر اعتبارسنجی محتوا) هم دیگر در corpus نمی‌نویسد.
 * 🛡️ FIX-A24-03: recordFingerprint برای ردیف موجود، شناسهٔ همان ردیف را
 *   برمی‌گرداند (نه null) — idempotent با یک ردیف.
 *
 * نکتهٔ پاک‌سازی: جدول video_fingerprints اختصاصی همین قابلیت است و در seed خالی است؛
 * setUp/tearDown کل جدول را خالی می‌کند. URLها تصادفی‌اند تا بین ران‌ها cache/ردیف
 * کهنه نتیجه را آلوده نکند.
 */
final class VideoFingerprintServiceTest extends TestCase
{
    protected function setUp(): void
    {
        Database::getInstance()->execute('DELETE FROM video_fingerprints');
    }

    protected function tearDown(): void
    {
        Database::getInstance()->execute('DELETE FROM video_fingerprints');
        parent::tearDown();
    }

    private function service(): VideoFingerprintService
    {
        return Container::getInstance()->make(VideoFingerprintService::class);
    }

    private function aparatUrl(string $id): string
    {
        return 'https://www.aparat.com/v/' . $id;
    }

    public function test_generate_fingerprint_extracts_platform_ids_and_confidence(): void
    {
        $svc = $this->service();

        $fpAparat = $svc->generateFingerprint($this->aparatUrl('abc123'), 'aparat');
        $this->assertSame('abc123', $fpAparat['video_id'], 'شناسهٔ aparat باید از الگوی /v/ استخراج شود');
        $this->assertSame(0.8, $fpAparat['confidence'], 'extracted + بدون metadata = 0.5+0.3');

        $fpYoutube = $svc->generateFingerprint('https://youtu.be/xyz98745123', 'youtube');
        $this->assertSame('xyz98745123', $fpYoutube['video_id'], 'شناسهٔ youtu.be باید استخراج شود');

        // metadata کامل → confidence سقف
        $fpFull = $svc->generateFingerprint($this->aparatUrl('abc123'), 'aparat', ['title' => 't', 'duration' => 120]);
        $this->assertSame(1.0, $fpFull['confidence'], 'extracted + metadata کامل = 0.5+0.3+0.2');

        // 🛡️ FIX-S31-VF1: پلتفرم ناشناخته → نرمال عمومی؛ confidence باید 0.5 بماند
        // 🛡️ FIX-A24-01: شناسهٔ عمومی دیگر md5 کل URL خام نیست — کلید کانونی
        // host+path (پایدار در برابر variant) است؛ پوشش کامل در
        // VideoFingerprintNormalizationTest (یونیت)
        $fpFallback = $svc->generateFingerprint('https://example.com/some/video', 'other');
        $this->assertSame('example.com/some/video', $fpFallback['video_id'], 'شناسهٔ عمومی = کلید کانونی نرمال');
        $this->assertSame(0.5, $fpFallback['confidence'], 'نرمال عمومی = پایهٔ 0.5 بدون +0.3');
    }

    public function test_fingerprint_is_deterministic_and_url_normalization_insensitive(): void
    {
        $svc = $this->service();
        $a = $svc->generateFingerprint('https://www.aparat.com/v/normtest1/', 'aparat');
        $b = $svc->generateFingerprint('http://aparat.com/v/normtest1', 'aparat');
        $this->assertSame($a['url_hash'], $b['url_hash'], 'نرمال‌سازی پروتکل/www/trailing-slash');
        $this->assertSame($a['combined_hash'], $b['combined_hash']);
    }

    /**
     * 🛡️ FIX-A24-02 — checkDuplicate فقط «می‌خواند»؛ ثبت فقط با recordFingerprint.
     * قبلاً checkDuplicate در مسیر غیرتکراری خودش ذخیره می‌کرد و هر بازرسی
     * (حتی ارسالی که بعداً رد می‌شود) لینک را ۹۰ روز اشغال می‌کرد.
     */
    public function test_check_duplicate_is_read_only_and_record_fingerprint_feeds_corpus(): void
    {
        $svc = $this->service();
        $url = $this->aparatUrl('dup' . bin2hex(random_bytes(4)));
        $fp = $svc->generateFingerprint($url, 'aparat');

        $first = $svc->checkDuplicate($fp);
        $this->assertFalse((bool)$first['is_duplicate'], 'اولین رکورد نباید تکراری باشد');

        // قرارداد جدید: بازرسی «نمی‌نویسد» — corpus خالی می‌ماند
        $this->assertSame(0, (int)Database::getInstance()->fetchColumn(
            'SELECT COUNT(*) FROM video_fingerprints WHERE combined_hash = ?',
            [$fp['combined_hash']]
        ), '🛡️ FIX-A24-02: checkDuplicate نباید دیگر در corpus بنویسد');

        // ثبت صریح (فراخوان پس از موفقیت ثبت/پذیرش) → ردیف تازه
        $recordedId = $svc->recordFingerprint($url, 'aparat');
        $this->assertGreaterThan(0, (int)$recordedId, 'recordFingerprint باید شناسهٔ ردیف تازه را بدهد');
        $this->assertSame(1, (int)Database::getInstance()->fetchColumn(
            'SELECT COUNT(*) FROM video_fingerprints WHERE combined_hash = ?',
            [$fp['combined_hash']]
        ), 'recordFingerprint باید corpus را تغذیه کند');

        $second = $svc->checkDuplicate($fp);
        $this->assertTrue((bool)$second['is_duplicate'], 'بررسی دوبارهٔ همان اثر باید تکراری باشد');
        $this->assertSame('database', (string)($second['source'] ?? ''));
    }

    /**
     * 🛡️ FIX-A24-03 — recordFingerprint برای ردیف موجود idempotent است:
     * شناسهٔ همان ردیف برگردانده می‌شود (نه null) و ردیف دوم ساخته نمی‌شود.
     */
    public function test_record_fingerprint_is_idempotent_and_returns_existing_id(): void
    {
        $svc = $this->service();
        $url = $this->aparatUrl('idem' . bin2hex(random_bytes(4)));

        $firstId = $svc->recordFingerprint($url, 'aparat');
        $this->assertGreaterThan(0, (int)$firstId);

        $secondId = $svc->recordFingerprint($url, 'aparat');
        $this->assertSame((int)$firstId, (int)$secondId, 'ثبت دوباره باید شناسهٔ ردیف موجود را بدهد');

        $this->assertSame(1, (int)Database::getInstance()->fetchColumn(
            'SELECT COUNT(*) FROM video_fingerprints WHERE video_id = ?',
            [substr($url, (int)strrpos($url, '/') + 1)]
        ), 'ردیف دومی نباید ساخته شود');
    }

    /**
     * 🛡️ FIX-A24-02 — inspect فقط-خواندنی است: بازرسی مکرر، لینک را «اشغال»
     * نمی‌کند (قبلاً inspect دوم همان URL را تکراری گزارش می‌داد)؛ تشخیص
     * تکراری فقط پس از ثبت واقعی (recordFingerprint) رخ می‌دهد و در حالت
     * log-only هرگز مسیر را block نمی‌کند.
     */
    public function test_inspect_is_read_only_and_never_blocks(): void
    {
        $svc = $this->service();
        $url = $this->aparatUrl('ro' . bin2hex(random_bytes(4)));

        $r1 = $svc->inspect($url, 'aparat');
        $this->assertTrue($r1['inspected']);
        $this->assertFalse($r1['is_duplicate']);
        $this->assertSame('log-only', $r1['mode']);

        // بازرسی دوباره «بدون ثبت» — نباید تکراری شود (رفع اشغال با بازرسی زودهنگام)
        $r2 = $svc->inspect($url, 'aparat');
        $this->assertTrue($r2['inspected']);
        $this->assertFalse($r2['is_duplicate'], '🛡️ FIX-A24-02: inspect نباید در corpus بنویسد — بازرسی مکرر یعنی اشغال');
        $this->assertSame('log-only', $r2['mode']);

        // ثبت واقعی (پس از موفقیت فراخوان) → حالا تکراری گزارش می‌شود (فقط لاگ)
        $svc->recordFingerprint($url, 'aparat');

        // هشدار video_fingerprint.duplicate_detected به stdout می‌رود — مصرف می‌شود (الگوی S28)
        $this->expectOutputRegex('/video_fingerprint/');
        $r3 = $svc->inspect($url, 'aparat');
        $this->assertTrue($r3['inspected']);
        $this->assertTrue($r3['is_duplicate'], 'پس از ثبت واقعی، بازرسی تکراری را می‌بیند');
        $this->assertSame('log-only', $r3['mode'], 'حالت log-only نباید تغییر کند');
    }

    public function test_clean_old_fingerprints_respects_limit_and_age(): void
    {
        // لاگ video_fingerprint به stdout می‌رود — مصرف می‌شود (الگوی S28)
        $this->expectOutputRegex('/video_fingerprint/');
        $db = Database::getInstance();
        $svc = $this->service();

        // ۳ رکورد قدیمی (۱۲۰ روز) + ۱ تازه
        for ($i = 1; $i <= 3; $i++) {
            $db->execute(
                "INSERT INTO video_fingerprints
                    (platform, video_id, url_hash, metadata_hash, combined_hash, method, confidence, created_at)
                 VALUES ('aparat', ?, ?, NULL, ?, 'url_hash', 0.8, DATE_SUB(NOW(), INTERVAL 120 DAY))",
                ["vfold{$i}", 'oldhash' . $i, 'oldcombined' . $i]
            );
        }
        $db->execute(
            "INSERT INTO video_fingerprints
                (platform, video_id, url_hash, metadata_hash, combined_hash, method, confidence, created_at)
             VALUES ('aparat', 'vffresh', 'freshhash', NULL, 'freshcombined', 'url_hash', 0.8, NOW())"
        );

        // 🛡️ FIX-S31-VF2: LIMIT باید حذف را به ۲ محدود کند
        $this->assertSame(2, $svc->cleanOldFingerprints(90, 2), 'LIMIT باید حذف را به ۲ محدود کند');

        $remainingOld = (int)$db->fetchColumn(
            'SELECT COUNT(*) FROM video_fingerprints WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)'
        );
        $this->assertSame(1, $remainingOld, 'دقیقاً یک رکورد قدیمی باید باقی بماند');

        $remainingFresh = (int)$db->fetchColumn(
            'SELECT COUNT(*) FROM video_fingerprints WHERE created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)'
        );
        $this->assertSame(1, $remainingFresh, 'رکورد تازه نباید حذف شود');

        // دستهٔ بعدی: باقی‌ماندهٔ قدیمی هم حذف می‌شود؛ رکورد تازه می‌ماند
        $this->assertSame(1, $svc->cleanOldFingerprints(90, 1000));
        $this->assertSame(1, (int)$db->fetchColumn('SELECT COUNT(*) FROM video_fingerprints'));
    }

    /**
     * 🛡️ FIX-A24-02 — مسیر اعتبارسنجی محتوا (validateVideoUrl) دیگر در
     * corpus نمی‌نویسد؛ ثبت اثر انگشت فقط پس از موفقیت ثبت/ویرایش
     * (recordVideoFingerprint → recordFingerprint) انجام می‌شود.
     */
    public function test_content_service_validate_video_url_wires_fingerprint_log_only(): void
    {
        $db = Database::getInstance();
        $content = Container::getInstance()->make(\App\Services\ContentService::class);
        $ref = new \ReflectionMethod($content, 'validateVideoUrl');
        if (PHP_VERSION_ID < 80100) { $ref->setAccessible(true); }

        $url = $this->aparatUrl('wire' . bin2hex(random_bytes(4)));
        $valid = $ref->invoke($content, $url, 'aparat');
        $this->assertTrue($valid, 'URL معتبر aparat باید validate شود (log-only: بدون block)');

        $videoId = substr($url, (int)strrpos($url, '/') + 1);
        $count = (int)$db->fetchColumn('SELECT COUNT(*) FROM video_fingerprints WHERE video_id = ?', [$videoId]);
        $this->assertSame(0, $count, '🛡️ FIX-A24-02: اعتبارسنجی نباید در corpus بنویسد — ثبت فقط پس از موفقیت ثبت محتواست');

        // invoke دوباره → باز هم true (تکراری block نمی‌کند — قرارداد log-only)
        $validAgain = $ref->invoke($content, $url, 'aparat');
        $this->assertTrue($validAgain, 'تکراری‌بودن در حالت log-only نباید اعتبارسنجی را رد کند');
    }
}
