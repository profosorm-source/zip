<?php

declare(strict_types=1);

namespace Tests\Integration\ContainerBacked\Services;

use Mockery as m;
use PHPUnit\Framework\TestCase;
use App\Services\Auth\AuthService;

/**
 * بچ S15 — قفل رفتاری FIX-S15-3b:
 *
 * شکل قبلی AuthService::performLogin برای هر حسابِ email_verified_at خالی،
 * «بدون سنجیدن رمز» email_unverified برمی‌گرداند ⇒ شمارش حساب (این ایمیل
 * موجود و تأییدنشده است) بدون دانستن رمز. اکنون رمز علیه هشِ واقعی سنجیده
 * می‌شود: رمز غلط ⇒ پیام عمومیِ ورود و بدون فلگ؛ رمز درست ⇒ همان مسیر
 * email_unverified (ادامهٔ جریان تأیید — سازگاری کامل UX).
 *
 * الگوی ساخت از tests/Integration/ContainerBacked/Services/AuthServiceTest.php.
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class S15AuthUnverifiedGateTest extends TestCase
{
    private \Core\Database $db;
    private \App\Contracts\LoggerInterface $logger;
    private \App\Services\User\UserService $userService;
    private \App\Models\User $userModel;
    private \Core\RateLimiter $rateLimiter;
    private \App\Services\Auth\AuthSessionManager $sessionManager;
    private \App\Services\Auth\PasswordRecoveryService $passwordService;
    private AuthService $service;

    private const REAL_HASH = '$2y$10$abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUV';

    protected function setUp(): void
    {
        parent::setUp();

        $this->db = m::mock('Core\\Database');
        $this->logger = m::mock('App\\Contracts\\LoggerInterface');
        $this->userService = m::mock('App\\Services\\User\\UserService');
        $this->userModel = m::mock('App\\Models\\User');
        $this->rateLimiter = m::mock('Core\\RateLimiter');
        $this->sessionManager = m::mock('App\\Services\\Auth\\AuthSessionManager');
        $this->passwordService = m::mock('App\\Services\\Auth\\PasswordRecoveryService');

        $this->logger->shouldIgnoreMissing();
        $this->db->shouldIgnoreMissing();

        \Core\Container::getInstance()->instance(\Core\Database::class, $this->db);

        $verify2FAJob = m::mock('App\\Jobs\\Auth\\Verify2FAJob');
        $processRegistrationJob = m::mock('App\\Jobs\\Auth\\ProcessRegistrationJob');
        $resetPasswordJob = m::mock('App\\Jobs\\Auth\\ResetPasswordJob');

        $this->service = new AuthService(
            $this->db,
            $this->logger,
            $this->userService,
            $this->userModel,
            $this->rateLimiter,
            $this->sessionManager,
            $this->passwordService,
            $verify2FAJob,
            $processRegistrationJob,
            $resetPasswordJob,
            m::mock('App\\Contracts\\OutboxServiceInterface')
        );
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    private function unverifiedUser(): \stdClass
    {
        return (object)[
            'id'                 => 42,
            'email'              => 'victim@example.com',
            'username'           => 'victim',
            'password'           => self::REAL_HASH,
            'status'             => 'active',
            'role'               => 'user',
            'email_verified_at'  => null,
            'two_factor_secret'  => null,
        ];
    }

    /** @test */
    public function unverified_email_with_wrong_password_returns_generic_message_without_flag(): void
    {
        $this->rateLimiter->shouldReceive('attempt')->andReturnTrue()->byDefault();
        $this->userModel->shouldReceive('findByCredentialsForUpdate')
            ->andReturn($this->unverifiedUser());

        // 🛡️ باید علیه هشِ «واقعی» سنجیده شود نه هشِ ساختگی؛ رمز غلط ⇒ پیام عمومی
        $this->passwordService->shouldReceive('verifyPassword')
            ->once()
            ->with('wrong-password', self::REAL_HASH)
            ->andReturnFalse();

        $result = $this->service->login('victim@example.com', 'wrong-password');

        $this->assertFalse($result['success']);
        $this->assertArrayNotHasKey(
            'email_unverified',
            $result,
            'رمز غلط روی حساب تأییدنشده نباید فلگ email_unverified برگرداند (شمارش حساب)'
        );
        $this->assertSame('نام کاربری یا رمز عبور اشتباه است.', $result['message']);
    }

    /** @test */
    public function unverified_email_with_correct_password_still_returns_email_unverified(): void
    {
        $this->rateLimiter->shouldReceive('attempt')->andReturnTrue()->byDefault();
        $this->userModel->shouldReceive('findByCredentialsForUpdate')
            ->andReturn($this->unverifiedUser());

        $this->passwordService->shouldReceive('verifyPassword')
            ->once()
            ->with('correct-password', self::REAL_HASH)
            ->andReturnTrue();

        $result = $this->service->login('victim@example.com', 'correct-password');

        $this->assertFalse($result['success']);
        $this->assertTrue(
            (bool)($result['email_unverified'] ?? false),
            'رمز درست روی حساب تأییدنشده باید مسیر جریان تأیید را حفظ کند'
        );
        $this->assertSame('victim@example.com', $result['email'] ?? null);
    }
}
