<?php

declare(strict_types=1);

namespace Tests\Integration\Distributed;

use Core\Scheduler;
use PHPUnit\Framework\TestCase;

/**
 * بچ S8 — قفل رفتاری گاردهای نقاط ورود:
 *
 *  - FIX-S8-1: dev-router.php مسیرهای dot-segment را رد می‌کند (اثبات اجرایی:
 *    «GET /../.env» قبل از فیکس = 200 + محتوای کامل .env؛ اکنون 404).
 *    هدفِ traversal در تست «/../phpunit.xml» است که در ریشهٔ هر دو درخت وجود
 *    دارد — تا 404 ثابت‌کنندهٔ گارد باشد نه نبودِ فایل.
 *  - FIX-S8-2: هدر early X-Correlation-ID همیشه با الگوی canonical
 *    (^[\w.\-:]{1,128}$) emit می‌شود (مقدار تصادفی hex در نبود ورودی معتبر).
 *  - FIX-S8-3: فلگ مردهٔ forceRegisterJobs هرگز نباید به Scheduler بازگردد —
 *    FIX-P3-15 متد را حذف کرد ولی call-site آن در cron.php مانده بود و
 *    «php cron.php --job=X» را فتال می‌کرد؛ این تست قرارداد حذف را قفل می‌کند.
 *
 * تست‌های HTTP به سرور 127.0.0.1:8090 (درخت e2e با dev-router) نیاز دارند —
 * همان قرارداد HealthEndpointsTest.
 */
final class S8EntryPointGuardsTest extends TestCase
{
    private string $base = 'http://127.0.0.1:8090';

    protected function setUp(): void
    {
        parent::setUp();
        $this->base = \Tests\Support\E2eBaseUrl::resolve();
    }

    /** GET با ارسال path-as-is (خام — بدون نرمال‌سازی کلاینت) */
    private function getRaw(string $path): array|false
    {
        $ctx = stream_context_create([
            'http' => [
                'timeout' => 5,
                'ignore_errors' => true,
                'follow_location' => 0,
            ],
        ]);
        $body = @file_get_contents($this->base . $path, false, $ctx);
        if ($body === false) {
            return false;
        }
        $status = 0;
        foreach ($http_response_header ?? [] as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) {
                $status = (int)$m[1];
            }
        }
        return ['status' => $status, 'body' => $body, 'headers' => $http_response_header ?? []];
    }

    public function test_dev_router_blocks_dot_segment_traversal(): void
    {
        $resp = $this->getRaw('/../phpunit.xml');
        if ($resp === false) {
            $this->fail('Web server not running on 8090 — start with php -S 127.0.0.1:8090 dev-router.php');
        }
        $this->assertSame(404, $resp['status'], 'dot-segment باید 404 بگیرد (FIX-S8-1)');
        $this->assertStringNotContainsString('<phpunit', $resp['body'], 'محتوای فایل traversed نباید لو برود');
        $this->assertStringNotContainsString('APP_KEY', $resp['body']);
    }

    public function test_dev_router_blocks_dot_env_traversal(): void
    {
        $resp = $this->getRaw('/../.env');
        if ($resp === false) {
            $this->fail('Web server not running on 8090 — start with php -S 127.0.0.1:8090 dev-router.php');
        }
        $this->assertSame(404, $resp['status'], 'سربار .env باید 404 باشد (FIX-S8-1 — سناریوی اثبات‌شدهٔ S8)');
        $this->assertStringNotContainsString('DB_PASSWORD', $resp['body']);
    }

    public function test_dev_router_still_serves_real_static_assets(): void
    {
        $resp = $this->getRaw('/assets/vendor/notyf/notyf.min.css');
        if ($resp === false) {
            $this->fail('Web server not running on 8090');
        }
        $this->assertSame(200, $resp['status'], 'فایل استاتیک واقعی باید سرو شود (ضد over-blocking)');
        $this->assertStringContainsString('text/css', implode("\n", $resp['headers']));
    }

    public function test_x_correlation_header_is_canonical(): void
    {
        $ctx = stream_context_create(['http' => ['timeout' => 5, 'ignore_errors' => true]]);
        @file_get_contents($this->base . '/health/live', false, $ctx);
        $headerValues = [];
        foreach ($http_response_header ?? [] as $h) {
            if (stripos($h, 'X-Correlation-ID:') === 0) {
                $headerValues[] = trim(substr($h, strlen('X-Correlation-ID:')));
            }
        }
        if ($headerValues === []) {
            $this->fail('Web server not running on 8090 or header missing');
        }
        $value = $headerValues[0];
        $this->assertSame(1, preg_match('/^[\w.\-:]{1,128}$/', $value), 'هدر correlation باید canonical باشد (FIX-S8-2)');
    }

    public function test_scheduler_dead_flag_is_not_resurrected(): void
    {
        // FIX-S8-3: قفل قرارداد FIX-P3-15 — متد حذف‌شده نباید برگردد، وگرنه
        // call-siteهای فراموش‌شده (مثل cron.php) فتال می‌شوند
        $this->assertFalse(
            method_exists(Scheduler::class, 'forceRegisterJobs'),
            'forceRegisterJobs حذف‌شده نباید به Scheduler بازگردد'
        );
    }
}
