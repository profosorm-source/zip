<?php

namespace Tests\Integration\Distributed;

use PHPUnit\Framework\TestCase;

/**
 * Tests the consolidated health/distributed and metrics endpoints.
 * Assumes the PHP built-in server or real web server is running on 127.0.0.1:8090
 * (or the test skips gracefully).
 */
class HealthEndpointsTest extends TestCase
{
    private string $base = 'http://127.0.0.1:8090';

    /* FIX-PRE-3 (health): docblock این تست از ابتدا می‌گفت «or the test skips
     * gracefully» ولی بدنه بدون سرور fail() می‌زد → در هر رانِ سوئیت بدون
     * سرورِ dev، ۲ شکستِ ثابتِ «health» تولید می‌شد. قرارداد جدید هم‌الگوی
     * S12SocialTaskVerifyEndpointsTest: سرورِ پیش‌فرضِ در دسترس نیست ⇒ skip؛
     * فقط وقتی CHORTKE_E2E_BASE_URL صراحتاً کانفیگ شده باشد (خط لولهٔ E2E که
     * سرور را قول داده) fail صادقانه می‌ماند.
     */
    private bool $baseUrlConfigured = false;

    protected function setUp(): void
    {
        parent::setUp();
        // از همان قرارداد محیطیِ سوییت E2E پروژه استفاده می‌کنیم تا آدرس ثابت
        // در کد تست باقی نماند و در محیط‌های مختلف قابل تنظیم باشد.
        $this->base = \Tests\Support\E2eBaseUrl::resolve();
        $this->baseUrlConfigured = (string)getenv('CHORTKE_E2E_BASE_URL') !== '';
    }

    private function unavailableSkipOrFail(string $context): void
    {
        if ($this->baseUrlConfigured) {
            $this->fail('Configured CHORTKE_E2E_BASE_URL (' . $this->base . ') not reachable for ' . $context . '.');
        }
        $this->markTestSkipped('e2e server (' . $this->base . ') unavailable — ' . $context);
    }

    public function test_health_distributed_endpoint_exists_or_skips(): void
    {
        $ctx = stream_context_create(['http' => ['timeout' => 2]]);
        $response = @file_get_contents($this->base . '/health/distributed', false, $ctx);

        if ($response === false) {
            $this->unavailableSkipOrFail('health/distributed');
        }
        
        $data = json_decode($response, true);
        $this->assertIsArray($data);
        $this->assertArrayHasKey('checks', $data);
        $this->assertArrayHasKey('outbox', $data['checks']);
        $this->assertArrayHasKey('dlq', $data['checks']);
    }

    public function test_metrics_distributed_returns_prometheus_or_json(): void
    {
        $ctx = stream_context_create(['http' => ['timeout' => 2, 'header' => "Accept: text/plain\r\n"]]);
        $response = @file_get_contents($this->base . '/metrics/distributed', false, $ctx);

        if ($response === false) {
            $this->unavailableSkipOrFail('metrics/distributed');
        }
        
        // Either Prometheus text or JSON
        $this->assertTrue(
            str_contains($response, 'chortke_') || 
            str_contains($response, 'outbox_') ||
            json_decode($response) !== null
        );
    }
}
