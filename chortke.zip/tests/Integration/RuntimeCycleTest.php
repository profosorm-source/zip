<?php

declare(strict_types=1);

namespace Tests\Integration;

use App\Contracts\LoggerInterface;
use App\Jobs\Notification\SendNotificationJob;
use App\Services\Notification\NotificationPreferenceService;
use App\Services\Notification\NotificationTracker;
use App\Services\StateMachineService;
use Core\Cache;
use Core\Database;
use Core\Queue;
use Core\RateLimiter;
use Mockery;
use PHPUnit\Framework\TestCase;

final class RuntimeCycleTest extends TestCase
{
    private Database $db;
    private \PDO $pdo;

    protected function setUp(): void
    {
        parent::setUp();
        ob_start();
        $this->db = Database::getInstance();
        $this->pdo = $this->db->getPdo();
    }

    protected function tearDown(): void
    {
        if (ob_get_level() > 0) {
            ob_end_clean();
        }
        Mockery::close();
        parent::tearDown();
    }

    public function testDatabaseQueueRoundTripPreservesPayloadAndOwnership(): void
    {
        $queue = new Queue($this->db, Cache::getInstance(), 'database');
        $queueName = 'integration_runtime';
        $marker = bin2hex(random_bytes(8));

        // FIX (ایزوله‌سازی تست): ردیف‌های کهنهٔ همین صف از اجراهای قبلی سوئیت
        // (crash/بازمانده) باعث می‌شد pop قدیمی‌ترین job را برگرداند نه job همین
        // تست — marker تطبیق نمی‌کرد. پاک‌سازی پیش از push، round-trip را قطعی
        // و تست را از حالت دیتابیس مستقل می‌کند.
        $this->pdo->prepare('DELETE FROM queues WHERE queue = ?')->execute([$queueName]);

        self::assertTrue($queue->push('integration.test_job', ['marker' => $marker], $queueName));
        $job = $queue->pop($queueName);

        self::assertIsArray($job);
        self::assertSame('integration.test_job', $job['job']);
        self::assertSame($marker, $job['data']['marker']);
        self::assertIsString($job['reservation_token']);
        self::assertTrue($queue->delete((int)$job['id'], $job['reservation_token']));
    }

    public function testNotificationJobPersistsSanitizedNotificationToDatabase(): void
    {
        $email = 'integration-' . bin2hex(random_bytes(6)) . '@example.test';
        $this->pdo->prepare(
            'INSERT INTO users (email, status, role) VALUES (?, ?, ?)'
        )->execute([$email, 'active', 'user']);
        $userId = (int)$this->pdo->lastInsertId();

        $preferences = Mockery::mock(NotificationPreferenceService::class);
        $preferences->shouldReceive('isNotificationEnabled')->once()->with($userId, 'system')->andReturn(true);
        // FIX (هم‌ترازسازی تست): job پس از گیت isNotificationEnabled، کانال in_app را
        // هم با isInAppEnabled چک می‌کند (همان قرارداد delegation — مستند در job).
        $preferences->shouldReceive('isInAppEnabled')->once()->with($userId, 'system')->andReturn(true);
        $rateLimiter = Mockery::mock(RateLimiter::class);
        $rateLimiter->shouldReceive('attempt')->once()->andReturn(true);
        $tracker = Mockery::mock(NotificationTracker::class);
        $tracker->shouldReceive('invalidateUnreadCache')->once()->with($userId);
        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldReceive('warning')->zeroOrMoreTimes();
        $logger->shouldReceive('error')->zeroOrMoreTimes();

        try {
            $job = new SendNotificationJob($preferences, $logger, $rateLimiter, $this->db, $tracker);
            $notificationId = $job->handle(
                $userId,
                'system',
                'Integration notification',
                'Persisted by the runtime cycle',
                ['idempotency_key' => 'integration-' . $userId],
                'javascript:alert(1)',
                'Open',
                'normal'
            );

            self::assertIsInt($notificationId);
            $row = $this->pdo->prepare('SELECT action_url, channel, user_id FROM notifications WHERE id = ?');
            $row->execute([$notificationId]);
            $notification = $row->fetch(\PDO::FETCH_ASSOC);
            self::assertIsArray($notification);
            self::assertNull($notification['action_url']);
            self::assertSame('in_app', $notification['channel']);
            self::assertSame($userId, (int)$notification['user_id']);
        } finally {
            $this->pdo->prepare('DELETE FROM notifications WHERE user_id = ?')->execute([$userId]);
            $this->pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$userId]);
        }
    }

    public function testLotteryAndPredictionTransitionsCommitAndRejectInvalidMoves(): void
    {
        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldReceive('warning')->zeroOrMoreTimes();
        $logger->shouldReceive('error')->zeroOrMoreTimes();
        $stateMachine = new StateMachineService($this->db, $logger);

        $this->pdo->exec("INSERT INTO lottery_rounds (title, status, type, duration_days) VALUES ('integration lottery', 'upcoming', 'weekly', 7)");
        $lotteryId = (int)$this->pdo->lastInsertId();
        $this->pdo->exec("INSERT INTO prediction_games (title, status, result) VALUES ('integration prediction', 'open', NULL)");
        $predictionId = (int)$this->pdo->lastInsertId();

        try {
            $lotteryResult = $stateMachine->executeTransition(
                'lottery',
                'lottery_rounds',
                $lotteryId,
                'active',
                static fn(string $from): array => ['from' => $from]
            );
            self::assertTrue($lotteryResult['success']);

            $invalidLottery = $stateMachine->executeTransition(
                'lottery',
                'lottery_rounds',
                $lotteryId,
                'upcoming',
                static fn(string $from): array => ['from' => $from]
            );
            self::assertFalse($invalidLottery['success']);

            $predictionClosed = $stateMachine->executeTransition(
                'prediction_game',
                'prediction_games',
                $predictionId,
                'closed',
                static fn(string $from): array => ['from' => $from]
            );
            self::assertTrue($predictionClosed['success']);

            $lotteryStatus = $this->pdo->query('SELECT status FROM lottery_rounds WHERE id = ' . $lotteryId)->fetchColumn();
            $predictionStatus = $this->pdo->query('SELECT status FROM prediction_games WHERE id = ' . $predictionId)->fetchColumn();
            self::assertSame('active', $lotteryStatus);
            self::assertSame('closed', $predictionStatus);
        } finally {
            $this->pdo->prepare('DELETE FROM lottery_rounds WHERE id = ?')->execute([$lotteryId]);
            $this->pdo->prepare('DELETE FROM prediction_games WHERE id = ?')->execute([$predictionId]);
        }
    }
}
