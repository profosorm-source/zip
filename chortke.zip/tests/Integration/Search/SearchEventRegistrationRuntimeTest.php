<?php

declare(strict_types=1);

namespace Tests\Integration\Search;

use Core\Application;
use Core\EventDispatcher;
use PHPUnit\Framework\TestCase;

final class SearchEventRegistrationRuntimeTest extends TestCase
{
    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_critical_projection_events_have_runtime_listeners_and_orphan_name_does_not(): void
    {
        $dispatcher=Application::getInstance()->container->make(EventDispatcher::class);
        // 🛡️ FIX-S23-C8 (قرارداد جدید): فقط رویدادهای با «تولیدکنندهٔ زنده» شنونده دارند.
        // از ۲۸ نام قبلی، ۲۳ مورد صفر تولیدکننده داشتند (اسکن scripts/s23_c8_matrix.sh)
        // و از آرایهٔ $projectionSyncEvents حذف شدند — اکنون orphan حساب می‌شوند.
        foreach ([
            // string-name رویدادهای زندهٔ projection
            'ticket.created','prediction.created','lottery.created','influencer.profile_updated',
            'content.approved','wallet.mutation.completed',
            // رویدادهای کلاس‌محور (FQCN) با سیم‌کشی جدید bootstrap
            \App\Events\WithdrawalCreatedEvent::class,
            \App\Events\KYCApprovedEvent::class,
            \App\Events\InvestmentCreatedEvent::class,
            // لیسنرهای غیر-projection ثبت‌شده در AppServiceProvider
            \App\Events\SettingsUpdated::class,
            \App\Events\WithdrawalApprovedEvent::class,
            'investment.profit_applied',
        ] as $event) {
            $this->assertNotSame([], $dispatcher->getListeners($event), "Runtime listener missing for {$event}");
        }
        // نام‌های مردهٔ حذف‌شده (و خواهرهای orphan) دیگر هیچ شنونده‌ای نباید داشته باشند
        foreach ([
            'wallet.deposit.completed','wallet.withdraw.completed',
            'withdrawal.created','kyc.approved','investment.created', // string-nameهای جایگزین‌شده با FQCN
            'direct_message.sent','content.created','content.deleted',
            'crypto_deposit.completed','bank_card.created','escrow.created',
            'social_task.created','social_task.deleted','kyc.created',
            'prediction.deleted','lottery.deleted','coupon.deleted',
            'investment.deleted','bank_card.deleted',
            'direct_message.created',
        ] as $orphan) {
            $this->assertSame([], $dispatcher->getListeners($orphan), "Orphan event must have NO listeners: {$orphan}");
        }
    }

    /**
     * @runInSeparateProcess
     * @preserveGlobalState disabled
     */
    public function test_settings_updated_listener_executes_and_invalidates_distributed_cache(): void
    {
        $this->expectOutputRegex('/.*/');
        $container = Application::getInstance()->container;
        $dispatcher = $container->make(EventDispatcher::class);
        $cache = $container->make(\Core\Cache::class);
        $key = 'system:settings:v2';

        try {
            $this->assertSame('redis', $cache->driver(), 'Integration runtime must exercise the real Redis cache path.');
            $this->assertTrue($cache->putSeconds($key, ['sentinel' => true], 60));
            $this->assertSame(['sentinel' => true], $cache->get($key));

            $applicationUrlBeforeDispatch = config('app.url');
            $dispatcher->dispatchOrFail(
                \App\Events\SettingsUpdated::class,
                new \App\Events\SettingsUpdated(['site.name'])
            );

            $this->assertNull($cache->get($key));
            $this->assertSame(
                $applicationUrlBeforeDispatch,
                config('app.url'),
                'Database settings invalidation must not erase immutable application configuration.'
            );
        } finally {
            $cache->forget($key);
        }
    }
}
