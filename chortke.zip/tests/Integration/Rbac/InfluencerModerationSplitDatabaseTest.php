<?php

declare(strict_types=1);

namespace Tests\Integration\Rbac;

use App\Middleware\AdminPermissionGuard;
use PDO;
use PHPUnit\Framework\TestCase;

/**
 * 🔒 AUDIT-FIX (RBAC audit R1) — پین دیتابیسیِ تفکیک مودریشن اینفلوئنسر.
 *
 * باگ پین‌شده: نقش support با مجوز influencer.manage وارد ناحیهٔ ادمین می‌شد و
 * چون پیش‌فرضِ InfluencerController همان مجوز بود، support می‌توانست تأیید/رد/
 * تعلیق پروفایل اینفلوئنسر و تأیید/رد verification را فراخوانی کند.
 *
 * قرارداد جدید (migration 2026_09_25_0001 + config/admin_permissions.php):
 *   - influencer.moderate فقط برای admin و super_admin
 *   - support فقط influencer.view دارد (بدون manage و بدون moderate)
 *   - نگاشت route guard: اکشن‌های مودریشن → influencer.moderate، بقیه → influencer.view
 */
final class InfluencerModerationSplitDatabaseTest extends TestCase
{
    private PDO $pdo;

    protected function setUp(): void
    {
        // FIX-PRE-1 (rbac DSN drift): fallback قبلی «chortke»/«chortke_dev»
        // اعتبارنامهٔ ماشینِ محلیِ نویسندهٔ قدیمی بود — هیچ سازوکاری در ریپو آن کاربر را نمی‌سازد
        // → «Access denied for user 'chortke'@'localhost'» در هر محیط استاندارد.
        // هم‌ترازی با قرارداد کانونیکال bootstrap/testing.php (root/خالی) — همان
        // اعتبارنامه‌ای که بقیهٔ تست‌های DBِ سوئیت از قبل استفاده می‌کنند.
        $this->pdo = new PDO(
            'mysql:host=' . (getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1') . ';dbname=' . ((getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk')),
            (getenv('CHORTKE_TEST_DB_USER') ?: 'root'),
            (getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : ''),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }

    private function roleHasPermission(string $roleSlug, string $permissionSlug): bool
    {
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(*) FROM role_permissions rp
             JOIN roles r ON r.id = rp.role_id
             JOIN permissions p ON p.id = rp.permission_id
             WHERE r.slug = ? AND p.slug = ?"
        );
        $stmt->execute([$roleSlug, $permissionSlug]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function test_support_is_view_only_for_influencer_area(): void
    {
        $this->assertTrue($this->roleHasPermission('support', 'influencer.view'), 'support باید مشاهده داشته باشد');
        $this->assertFalse($this->roleHasPermission('support', 'influencer.moderate'), 'support نباید مودریشن داشته باشد');
        $this->assertFalse($this->roleHasPermission('support', 'influencer.manage'), 'مجوز فراگیر influencer.manage باید از support سلب شده باشد');
    }

    public function test_admin_and_super_admin_have_moderation(): void
    {
        $this->assertTrue($this->roleHasPermission('admin', 'influencer.moderate'));
        $this->assertTrue($this->roleHasPermission('super_admin', 'influencer.moderate'));
    }

    public function test_moderation_permission_exists_and_is_dedicated(): void
    {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM permissions WHERE slug = 'influencer.moderate'");
        $stmt->execute();
        $this->assertSame(1, (int)$stmt->fetchColumn(), 'مجوز influencer.moderate باید دقیقاً یک بار ثبت شده باشد');
    }

    private function mapPermission(string $method): ?string
    {
        return AdminPermissionGuard::permissionForAction(
            \App\Controllers\Admin\InfluencerController::class,
            $method
        );
    }

    public function test_route_guard_maps_moderation_actions_to_dedicated_permission(): void
    {
        $this->assertSame('influencer.moderate', $this->mapPermission('approveProfile'));
        $this->assertSame('influencer.moderate', $this->mapPermission('approveVerification'));
        $this->assertSame('influencer.moderate', $this->mapPermission('rejectVerification'));
        $this->assertSame('influencer.moderate', $this->mapPermission('resolveDispute'));
    }

    public function test_route_guard_maps_view_actions_to_view_permission(): void
    {
        $this->assertSame('influencer.view', $this->mapPermission('orders'));
        $this->assertSame('influencer.view', $this->mapPermission('profiles'));
        $this->assertSame('influencer.view', $this->mapPermission('verificationRequests'));
        $this->assertSame('influencer.view', $this->mapPermission('disputes'));
        // پیش‌فرض کنترلر هم دیگر influencer.manage نیست
        $this->assertSame('influencer.view', $this->mapPermission('nonExistentViewAction'));
    }
}
