<?php

declare(strict_types=1);

namespace Tests\Integration\Rbac;

use App\Services\Shared\PolicyService;
use Core\Application;
use Core\Database;
use PHPUnit\Framework\TestCase;

/** Real MariaDB authorization checks; no mocked permission lookup. */
final class PolicyServiceResourceDatabaseTest extends TestCase
{
    private Database $db;
    private PolicyService $policy;

    protected function setUp(): void
    {
        $container = Application::getInstance()->container;
        $this->db = $container->make(Database::class);
        $this->policy = $container->make(PolicyService::class);
    }

    private function user(string $email): object
    {
        $row = $this->db->fetch('SELECT id, email, role FROM users WHERE email = ? LIMIT 1', [$email]);
        $this->assertNotNull($row, "Seed user missing: {$email}");
        return $row;
    }

    public function test_real_support_cannot_use_ownership_to_approve_finance(): void
    {
        $user = $this->user('support@chortke.ir');
        $resource = (object)['user_id' => (int)$user->id];
        $this->assertFalse($this->policy->can('finance.withdrawal.approve', $user, $resource));
    }

    public function test_real_admin_with_database_permission_can_approve_finance_on_owned_resource(): void
    {
        $user = $this->user('admin@chortke.ir');
        $resource = (object)['user_id' => (int)$user->id];
        $this->assertTrue($this->policy->can('finance.withdrawal.approve', $user, $resource));
    }

    public function test_real_support_cannot_settle_owned_prediction_but_admin_can(): void
    {
        $support = $this->user('support@chortke.ir');
        $admin = $this->user('admin@chortke.ir');
        $this->assertFalse($this->policy->can('prediction.settle', $support, (object)['user_id' => (int)$support->id]));
        $this->assertTrue($this->policy->can('prediction.settle', $admin, (object)['user_id' => (int)$admin->id]));
    }

    public function test_real_super_admin_bypasses_permission_but_not_user_identity(): void
    {
        $user = $this->user('superadmin@chortke.ir');
        $this->assertSame('super_admin', (string)$user->role);
        $this->assertTrue($this->policy->can('vitrine.finance.refund', $user, (object)['user_id' => (int)$user->id]));
    }

    public function test_real_owner_bypass_remains_for_non_sensitive_action(): void
    {
        $user = $this->user('user@chortke.ir');
        $this->assertTrue($this->policy->can('profile.edit', $user, (object)['user_id' => (int)$user->id]));
    }
}
