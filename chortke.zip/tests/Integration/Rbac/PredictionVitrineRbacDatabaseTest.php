<?php

declare(strict_types=1);

namespace Tests\Integration\Rbac;

use PDO;
use PHPUnit\Framework\TestCase;

/** Verifies the RBAC migration against the real MariaDB schema. */
final class PredictionVitrineRbacDatabaseTest extends TestCase
{
    private PDO $pdo;

    protected function setUp(): void
    {
        // FIX-PRE-1 (rbac DSN drift): fallback قبلی «chortke»/«chortke_dev»
        // اعتبارنامهٔ ماشینِ محلیِ نویسندهٔ قدیمی بود — هیچ سازوکاری در ریپو آن کاربر را نمی‌سازد
        // (docker-compose فقط MARIADB_USER از .env می‌گیرد) → در هر محیط استانداردی
        // «Access denied for user 'chortke'@'localhost'». هم‌ترازی با قرارداد کانونیکال
        // bootstrap/testing.php: DB_USER=root / DB_PASS='' — همان اعتبارنامه‌ای که
        // بقیهٔ تست‌های DBِ سوئیت (مسیر Core\Database) از قبل استفاده می‌کنند.
        $this->pdo = new PDO(
            'mysql:host=' . (getenv('CHORTKE_TEST_DB_HOST') ?: '127.0.0.1') . ';dbname=' . ((getenv('CHORTKE_TEST_DB_NAME') ?: 'chortk')),
            (getenv('CHORTKE_TEST_DB_USER') ?: 'root'),
            (getenv('CHORTKE_TEST_DB_PASS') !== false ? (string)getenv('CHORTKE_TEST_DB_PASS') : ''),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }

    public function test_all_new_permissions_exist_in_database(): void
    {
        $slugs = [
            'prediction.view', 'prediction.manage', 'prediction.settle', 'prediction.refund',
            'vitrine.view', 'vitrine.manage', 'vitrine.dispute', 'vitrine.finance',
        ];
        $stmt = $this->pdo->prepare('SELECT slug FROM permissions WHERE slug = ?');
        foreach ($slugs as $slug) {
            $stmt->execute([$slug]);
            $this->assertSame($slug, $stmt->fetchColumn(), "Missing permission: {$slug}");
        }
    }

    public function test_support_has_read_only_access(): void
    {
        $sql = 'SELECT p.slug FROM role_permissions rp JOIN roles r ON r.id=rp.role_id JOIN permissions p ON p.id=rp.permission_id WHERE r.slug="support" AND p.slug LIKE "prediction.%" OR r.slug="support" AND p.slug LIKE "vitrine.%"';
        $actual = $this->pdo->query($sql)->fetchAll(PDO::FETCH_COLUMN);
        sort($actual);
        $this->assertSame(['prediction.view', 'vitrine.view'], $actual);
    }

    public function test_admin_has_sensitive_permissions_but_support_does_not(): void
    {
        $sensitive = ['prediction.settle', 'prediction.refund', 'vitrine.finance'];
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM role_permissions rp JOIN roles r ON r.id=rp.role_id JOIN permissions p ON p.id=rp.permission_id WHERE r.slug=? AND p.slug=?');
        foreach ($sensitive as $slug) {
            $stmt->execute(['admin', $slug]);
            $this->assertSame(1, (int)$stmt->fetchColumn(), "admin missing {$slug}");
            $stmt->execute(['support', $slug]);
            $this->assertSame(0, (int)$stmt->fetchColumn(), "support must not have {$slug}");
        }
    }
}
