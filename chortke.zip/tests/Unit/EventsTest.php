<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Events\FeatureFlagChanged;
use App\Events\DisputeOpenedEvent;
use App\Events\KYCApprovedEvent;

class EventsTest extends TestCase
{
    /** @test */
    public function verify_all_events_can_be_instantiated(): void
    {
        // 🧹 FIX-R18C (هم‌ترازی با FIX-S18-13): AccountDeletedEvent حذف شد — گارد
        // dead_listener_and_event_classes_are_gone (S18p5) بودنِ این کلاس را ممنوع می‌کند.

        // 2. FeatureFlagChanged
        $event2 = new FeatureFlagChanged('feature_x', 'toggled');
        $this->assertEquals('feature_x', $event2->featureName);

        // 3. DisputeOpenedEvent
        $event3 = new DisputeOpenedEvent(45, 12, 13);
        $this->assertEquals(45, $event3->disputeId);

        // 🧹 S31-C-W1-5: PaymentCompletedEvent و FraudScoreUpdatedEvent حذف شدند
        // (کلاس‌مردهٔ «class dead/string live» — مسیر زندهٔ outbox با GenericEvent است).

        // 4. KYCApprovedEvent
        $event6 = new KYCApprovedEvent(12, 101);
        $this->assertEquals(12, $event6->userId);
    }
}
