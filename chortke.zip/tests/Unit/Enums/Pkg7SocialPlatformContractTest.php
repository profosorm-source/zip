<?php

declare(strict_types=1);

namespace Tests\Unit\Enums;

use App\Enums\SocialPlatform;
use App\Models\SocialAccount;
use App\Validators\Requests\StoreSocialAccountRequest;
use PHPUnit\Framework\TestCase;

/**
 * FIX-F21-02-LT (بازبینی بخش ۲۱ — پیشنهاد بلندمدت، بستهٔ ۷): تست‌های
 * contract منبع واحد پلتفرم‌ها.
 *
 * یافتهٔ گزارش F21-02: قرارداد «کدام پلتفرم» در شش نقطهٔ مستقل تعریف
 * شده بود و بینشان دریفت می‌کرد — رابط تیک‌تاک را ارائه می‌کرد ولی
 * allow-list والیدیتور آن را نداشت. پیشنهاد بلندمدت: «enum پلتفرم‌ها را
 * از منبع مشترک برای رابط، validator و persistence تولید کنید؛ برای هر
 * پلتفرم، آزمون contract از انتخاب رابط تا ذخیرهٔ موفق و پیام خطای مورد
 * انتظار بنویسید.»
 *
 * این فایل لایه‌های UI/validator/سرویس/مدل/helper را از یک منبع می‌سنجه؛
 * لایهٔ persistence واقعی (ستون ENUM جدول user_social_accounts + INSERT
 * موفق هر پلتفرم) در
 * tests/Integration/Pkg7SocialPlatformPersistenceRuntimeTest.php سنجه می‌شود.
 */
final class Pkg7SocialPlatformContractTest extends TestCase
{
    /** ریشهٔ پروژه برای پین‌های سورس */
    private static string $root;

    public static function setUpBeforeClass(): void
    {
        self::$root = dirname(__DIR__, 3) . '/';
    }

    private static function src(string $relPath): string
    {
        return (string)file_get_contents(self::$root . $relPath);
    }

    // ------------------------------------------------------------------
    // ۱) نامتغیری تک‌منبع — همان چیزی که بازگشت F21-02 را غیرممکن می‌کند
    // ------------------------------------------------------------------

    /**
     * کلیدهای درپ‌داون UI دقیقاً همان مقادیر قاعدهٔ in: والیدیتور و همان
     * registerableValues — UI هرگز پلتفرمی نمی‌دهد که validator نپذیرد و
     * validator هرگز پلتفرمی را نمی‌پذیرد که UI ندارد.
     */
    public function testUiDropdownValidatorAndRegistryAreTheSameSet(): void
    {
        $uiKeys = array_keys(SocialPlatform::forSelect());
        $this->assertSame(SocialPlatform::registerableValues(), $uiKeys);
        $this->assertSame(
            SocialPlatform::registerableValues(),
            explode(',', SocialPlatform::validationRule()),
            'validationRule() باید دقیقاً مقادیر registerable باشد — این رشتهٔ عینِ قاعدهٔ in: است'
        );
    }

    /** ترتیب درپ‌داون = قرارداد UI سابق (تغییر بی‌صدا = تغییر تجربهٔ کاربر) */
    public function testForSelectOrderMatchesHistoricalUiOrder(): void
    {
        $this->assertSame(
            ['instagram', 'youtube', 'telegram', 'tiktok', 'twitter'],
            array_keys(SocialPlatform::forSelect())
        );
    }

    /**
     * cases() = قرارداد persistence — دقیقاً همان ENUM ستون
     * user_social_accounts.platform (مایگریشن 2026_06_10_0040).
     * (نسخهٔ زندهٔ DB در تست runtime اینترکشن سنجه می‌شود.)
     */
    public function testEnumCasesMatchDbColumnEnumContract(): void
    {
        $dbEnumValues = [
            'instagram', 'telegram', 'youtube', 'twitter', 'tiktok',
            'aparat', 'linkedin', 'other',
        ];
        $caseValues = array_map(static fn(SocialPlatform $c): string => $c->value, SocialPlatform::cases());
        $this->assertSame($dbEnumValues, $caseValues);
    }

    // ------------------------------------------------------------------
    // ۲) contract از انتخاب رابط تا validator — پذیرش هر پلتفرم UI + پیام
    //    خطای مورد انتظار برای غیرمجازها
    // ------------------------------------------------------------------

    /** @return array<string, array{0: string, 1: string}> */
    public function providerUiOfferedPlatformsWithLabels(): array
    {
        $out = [];
        foreach (SocialPlatform::forSelect() as $value => $label) {
            $out[$value] = [$value, $label];
        }
        return $out;
    }

    /** @dataProvider providerUiOfferedPlatformsWithLabels */
    public function testEveryUiPlatformPassesValidationAndCarriesLabel(string $platform, string $label): void
    {
        // (الف) رابط ارائه می‌دهد → validator می‌پذیرد
        $request = new StoreSocialAccountRequest([
            'provider'         => $platform,
            'provider_user_id' => 'valid_handle',
        ]);
        $this->assertTrue($request->validate(), "پلتفرم ارائه‌شده در UI باید پاس شود: {$platform}");
        $this->assertSame($platform, $request->validated()['provider']);

        // (ب) هر پلتفرم UI برچسب نمایشی غیرخالی دارد
        $this->assertNotSame('', $label);
        $this->assertSame($label, SocialPlatform::from($platform)->label());
    }

    /**
     * پیام خطای مورد انتظار برای پلتفرم غیرمجاز — قرارداد پیام قاعدهٔ in:
     * (core/Validator): «مقدار نامعتبر است» روی فیلد provider.
     */
    public function testNonRegisterablePlatformIsRejectedWithExpectedMessage(): void
    {
        // aparat/linkedin/other در DB مجازند (قرارداد ستون) ولی در فرم ثبت
        // حساب ارائه نمی‌شوند — validator باید رد کند (رفتار سابق حفظ شده)
        foreach (['aparat', 'linkedin', 'other', 'snapchat', 'facebook', 'TikTok '] as $platform) {
            $request = new StoreSocialAccountRequest([
                'provider'         => $platform,
                'provider_user_id' => 'valid_handle',
            ]);
            $this->assertFalse($request->validate(), "پلتفرم غیرقابل‌ثبت باید رد شود: {$platform}");
            $errors = $request->errors();
            $this->assertArrayHasKey('provider', $errors);
            $this->assertSame(
                'مقدار نامعتبر است',
                $errors['provider'][0],
                "پیام خطای مورد انتظار قاعدهٔ in: برای {$platform}"
            );
        }
    }

    // ------------------------------------------------------------------
    // ۳) سهمیه‌های کیفیت حساب — پین عینی اعداد قرارداد سابق سرویس
    // ------------------------------------------------------------------

    /** @return array<string, array{0: SocialPlatform, 1: int, 2: int}> */
    public function providerQuotaContract(): array
    {
        return [
            'instagram' => [SocialPlatform::Instagram, 10, 50],
            'youtube'   => [SocialPlatform::Youtube,   5, 20],
            'telegram'  => [SocialPlatform::Telegram,  0,  0],
            'tiktok'    => [SocialPlatform::Tiktok,    5, 30],
            'twitter'   => [SocialPlatform::Twitter,  10, 20],
        ];
    }

    /** @dataProvider providerQuotaContract */
    public function testEligibilityQuotasPreservedExactly(SocialPlatform $platform, int $minPosts, int $minFollowers): void
    {
        $this->assertSame($minPosts, $platform->minPosts());
        $this->assertSame($minFollowers, $platform->minFollowers());
    }

    /** پلتفرم‌های غیرقابل‌ثبت = مقدار پیش‌فرض سابق سرویس (۱۰ پست / ۵۰ فالوور) */
    public function testNonRegisterablePlatformsKeepServiceFallbackQuotas(): void
    {
        foreach ([SocialPlatform::Aparat, SocialPlatform::Linkedin, SocialPlatform::Other] as $platform) {
            $this->assertSame(10, $platform->minPosts());
            $this->assertSame(50, $platform->minFollowers());
            $this->assertFalse($platform->isRegisterable());
        }
    }

    // ------------------------------------------------------------------
    // ۴) لایه‌های نمایش — مدل و helper از همان منبع می‌خوانند
    // ------------------------------------------------------------------

    public function testModelPlatformLabelDelegatesToEnum(): void
    {
        // newInstanceWithoutConstructor: platformLabel به DB دست نمی‌زند —
        // درس بستهٔ ۶ (PHPUnit 8 + PHP 8.4 mock محدودیت دارد)
        /** @var SocialAccount $model */
        $model = (new \ReflectionClass(SocialAccount::class))->newInstanceWithoutConstructor();

        foreach (SocialPlatform::forSelect() as $value => $label) {
            $this->assertSame($label, $model->platformLabel($value));
        }
        // سازگاری ستون DB: label برای مقادیر غیررجیسترپذیرِ مجازِ DB هم هست
        $this->assertSame('آپارات', $model->platformLabel('aparat'));
        // رفتار سابق: پلتفرم ناشناخته عین همان رشتهٔ خام برمی‌گردد
        $this->assertSame('snapchat', $model->platformLabel('snapchat'));
    }

    public function testViewHelperSocialPlatformLabelContract(): void
    {
        // هر ۸ مقدار قرارداد DB → label فارسی enum
        foreach (SocialPlatform::cases() as $case) {
            $this->assertSame($case->label(), social_platform_label($case->value));
        }
        // نرمال‌سازی case (قرارداد FIX-R36-W3)
        $this->assertSame('اینستاگرام', social_platform_label('INSTAGRAM'));
        // ناشناخته → پاس‌ترو escape‌شده (نه label جعلی)
        $this->assertSame('&lt;b&gt;x&lt;/b&gt;', social_platform_label('<b>x</b>'));
        // خالی → برچسب عمومی
        $this->assertSame('شبکه اجتماعی', social_platform_label(null));
        $this->assertSame('شبکه اجتماعی', social_platform_label(''));
    }

    // ------------------------------------------------------------------
    // ۵) پین‌های wiring (ضددریفت) — درس FIX-S20-DEADFILE: enum فقط تا وقتی
    //    زنده است که واقعاً مصرف شود؛ جدایی هر لایه fail-loud می‌شود
    // ------------------------------------------------------------------

    public function testValidatorConsumesEnumAndHasNoHardcodedAllowList(): void
    {
        $src = self::src('app/Validators/Requests/StoreSocialAccountRequest.php');
        $this->assertStringContainsString('SocialPlatform::validationRule()', $src);
        $this->assertStringNotContainsString('in:instagram', $src, 'allow-list هاردکد نباید برگردد');
    }

    public function testUserControllerConsumesEnumAndHasNoHardcodedDropdown(): void
    {
        $src = self::src('app/Controllers/User/SocialAccountController.php');
        $this->assertSame(
            2,
            substr_count($src, 'SocialPlatform::forSelect()'),
            'index() و showCreate() هر دو باید از منبع واحد بخوانند'
        );
        $this->assertStringNotContainsString("'اینستاگرام'", $src, 'آرایهٔ label هاردکد نباید برگردد');
        $this->assertStringNotContainsString("'tiktok'", $src);
    }

    public function testServiceConsumesEnumForQuotas(): void
    {
        $src = self::src('app/Services/SocialAccountService.php');
        $this->assertStringContainsString('SocialPlatform::tryFrom', $src);
        // نقشه‌های سهمیهٔ هاردکد نباید برگردند
        $this->assertStringNotContainsString("'instagram' => 10", $src);
        $this->assertStringNotContainsString("'instagram' => 50", $src);
    }

    public function testModelConsumesEnumForLabels(): void
    {
        $src = self::src('app/Models/SocialAccount.php');
        $this->assertStringContainsString('SocialPlatform::tryFrom', $src);
        $this->assertStringNotContainsString("'اینستاگرام'", $src);
    }

    public function testLabelHelperConsumesEnum(): void
    {
        $src = self::src('helpers/label_helpers.php');
        $this->assertStringContainsString('SocialPlatform::tryFrom', $src);
        $this->assertStringNotContainsString("'توییتر / X'", $src, 'label دریفت‌کرده یکدست شد');
    }

    public function testAdminFilterViewConsumesEnum(): void
    {
        $src = self::src('views/admin/social-accounts/index.php');
        $this->assertStringContainsString('SocialPlatform::forSelect()', $src);
        $this->assertStringNotContainsString('value="instagram"', $src, 'آپشن هاردکد نباید برگردد');
    }
}
