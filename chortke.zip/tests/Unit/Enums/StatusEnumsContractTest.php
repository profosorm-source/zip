<?php

declare(strict_types=1);

namespace Tests\Unit\Enums;

use App\Enums\AdsStatus;
use App\Enums\CustomTaskStatus;
use App\Enums\StoryOrderStatus;
use PHPUnit\Framework\TestCase;

/**
 * 🔒 FIX-STATUS-ENUM — قرارداد نمایشی سه enum جدید مهاجرت سه‌گانه
 * (Ads / StoryOrder / custom_task — مصوب مالک).
 *
 * هر assertion عیناً همان نقشهٔ دستیِ پیشین را پین می‌کند تا تضمین شود
 * delegate کردن به enum هیچ تغییر نمایشی‌ای ایجاد نکرده است
 * (قانون ۶: هیچ ادعایی بدون شاهد).
 */
final class StatusEnumsContractTest extends TestCase
{
    /** @test */
    public function ads_status_labels_map_is_identical_to_legacy_model_map(): void
    {
        $this->assertSame([
            'draft'          => 'پیشنویس',
            'pending_review' => 'در انتظار بررسی',
            'active'         => 'فعال',
            'paused'         => 'متوقف',
            'completed'      => 'تکمیل‌شده',
            'rejected'       => 'رد شده',
            'expired'        => 'منقضی',
        ], AdsStatus::labelsMap());
    }

    /** @test */
    public function ads_status_classes_map_is_identical_to_legacy_model_map(): void
    {
        $this->assertSame([
            'draft'          => 'badge-secondary',
            'pending_review' => 'badge-warning',
            'active'         => 'badge-success',
            'paused'         => 'badge-info',
            'completed'      => 'badge-primary',
            'rejected'       => 'badge-danger',
            'expired'        => 'badge-danger',
        ], AdsStatus::badgesMap());
    }

    /** @test */
    public function story_order_status_labels_map_is_identical_to_legacy_model_map(): void
    {
        $this->assertSame([
            'pending_payment'        => 'در انتظار پرداخت',
            'pending_acceptance'     => 'در انتظار پاسخ اینفلوئنسر',
            'paid'                   => 'پرداخت شده',
            'accepted'               => 'پذیرفته شده',
            'rejected_by_influencer' => 'رد توسط اینفلوئنسر',
            'published'              => 'منتشر شده',
            'proof_submitted'        => 'مدرک ارسال شده',
            'awaiting_buyer_check'   => 'در انتظار تأیید خریدار',
            'peer_resolution'        => 'حل اختلاف دوطرفه',
            'escalated_to_admin'     => 'ارجاع به مدیر',
            'verified'               => 'تأیید مدرک',
            'rejected'               => 'رد شده',
            'disputed'               => 'اختلاف',
            'completed'              => 'تکمیل‌شده',
            'cancelled'              => 'لغو شده',
            'refunded'               => 'بازگشت وجه',
            'expired'                => 'منقضی',
        ], StoryOrderStatus::labelsMap());
    }

    /** @test */
    public function story_order_status_classes_map_is_identical_to_legacy_model_map(): void
    {
        $this->assertSame([
            'pending_payment'        => 'badge-secondary',
            'pending_acceptance'     => 'badge-warning',
            'paid'                   => 'badge-info',
            'accepted'               => 'badge-primary',
            'rejected_by_influencer' => 'badge-danger',
            'published'              => 'badge-info',
            'proof_submitted'        => 'badge-warning',
            'awaiting_buyer_check'   => 'badge-warning',
            'peer_resolution'        => 'badge-orange',
            'escalated_to_admin'     => 'badge-danger',
            'verified'               => 'badge-success',
            'rejected'               => 'badge-danger',
            'disputed'               => 'badge-danger',
            'completed'              => 'badge-success',
            'cancelled'              => 'badge-secondary',
            'refunded'               => 'badge-warning',
            'expired'                => 'badge-secondary',
        ], StoryOrderStatus::badgesMap());
    }

    /** @test */
    public function custom_task_labels_map_with_alias_is_identical_to_legacy_helper_map(): void
    {
        $this->assertSame([
            'draft'          => 'پیشنویس',
            'pending_review' => 'در انتظار بررسی',
            'review_pending' => 'در انتظار بررسی',
            'active'         => 'فعال',
            'paused'         => 'متوقف',
            'completed'      => 'تکمیل‌شده',
            'rejected'       => 'رد شده',
            'expired'        => 'منقضی',
        ], CustomTaskStatus::labelsMapWithAlias());
    }

    /** @test */
    public function custom_task_classes_map_with_alias_is_identical_to_legacy_helper_map(): void
    {
        $this->assertSame([
            'draft'          => 'badge-secondary',
            'pending_review' => 'badge-warning',
            'review_pending' => 'badge-warning',
            'active'         => 'badge-success',
            'paused'         => 'badge-info',
            'completed'      => 'badge-primary',
            'rejected'       => 'badge-danger',
            'expired'        => 'badge-danger',
        ], CustomTaskStatus::badgesMapWithAlias());
    }

    /** @test */
    public function custom_task_legacy_alias_resolves_to_pending_review_case(): void
    {
        $this->assertSame(CustomTaskStatus::PendingReview, CustomTaskStatus::tryFromString('review_pending'));
        $this->assertSame(CustomTaskStatus::PendingReview, CustomTaskStatus::tryFromString('pending_review'));
        $this->assertSame(CustomTaskStatus::PendingReview, CustomTaskStatus::tryFromString('PENDING_REVIEW'));
    }

    /** @test */
    public function try_from_string_is_fail_closed_for_null_empty_and_unknown(): void
    {
        $this->assertNull(AdsStatus::tryFromString(null));
        $this->assertNull(AdsStatus::tryFromString(''));
        $this->assertNull(AdsStatus::tryFromString('no_such_status'));
        $this->assertNull(StoryOrderStatus::tryFromString(null));
        $this->assertNull(StoryOrderStatus::tryFromString(''));
        $this->assertNull(StoryOrderStatus::tryFromString('no_such_status'));
        $this->assertNull(CustomTaskStatus::tryFromString(null));
        $this->assertNull(CustomTaskStatus::tryFromString(''));
        $this->assertNull(CustomTaskStatus::tryFromString('no_such_status'));
    }

    /** @test */
    public function happy_path_strings_resolve_to_expected_cases(): void
    {
        $this->assertSame(AdsStatus::Active, AdsStatus::tryFromString('active'));
        $this->assertSame(StoryOrderStatus::PeerResolution, StoryOrderStatus::tryFromString('peer_resolution'));
        $this->assertSame(StoryOrderStatus::RejectedByInfluencer, StoryOrderStatus::tryFromString('rejected_by_influencer'));
        $this->assertSame(CustomTaskStatus::Expired, CustomTaskStatus::tryFromString('expired'));
    }
}
