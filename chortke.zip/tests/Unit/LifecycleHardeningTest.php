<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Contracts\LoggerInterface;
use App\Jobs\PredictionGameSettlementJob;
use App\Services\PredictionService;
use App\Services\QueueWorker;
use App\Services\StateMachineService;
use Core\EventDispatcher;
use Core\Queue;
use Mockery;
use PHPUnit\Framework\TestCase;

final class QueueContractFixture
{
    public function handle(int $userId, string $amount): array
    {
        return ['user_id' => $userId, 'amount' => $amount];
    }
}

final class ArrayPayloadFixture
{
    /** @param array<string, mixed> $payload */
    public function handle(array $payload): array
    {
        return $payload;
    }
}

final class LifecycleHardeningTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        ob_start();
    }

    protected function tearDown(): void
    {
        if (ob_get_level() > 0) {
            ob_end_clean();
        }
        Mockery::close();
        parent::tearDown();
    }

    public function testStrictDispatchFailsWhenNoListenerExists(): void
    {
        $dispatcher = new EventDispatcher(Mockery::mock(Queue::class));

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('No listener registered');
        $dispatcher->dispatchOrFail('test.no_listener');
    }

    public function testStrictDispatchPropagatesListenerFailure(): void
    {
        $dispatcher = new EventDispatcher(Mockery::mock(Queue::class));
        $dispatcher->listen('test.failure', static function (): void {
            throw new \RuntimeException('listener failed');
        });

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('listener failed');
        $dispatcher->dispatchOrFail('test.failure');
    }

    public function testQueuedEventMissingPayloadFailsInsteadOfBeingConsumed(): void
    {
        $dispatcher = new EventDispatcher(Mockery::mock(Queue::class));

        $this->expectException(\InvalidArgumentException::class);
        $dispatcher->processQueuedEvent(['data' => []]);
    }

    public function testQueuedEventCannotDowngradeMalformedTypedEvent(): void
    {
        $dispatcher = new EventDispatcher(Mockery::mock(Queue::class));

        $this->expectException(\Throwable::class);
        $dispatcher->processQueuedEvent([
            'data' => [
                'event_name' => 'test.typed',
                'event_class' => \stdClass::class,
                'event_data' => ['id' => 1],
            ],
        ]);
    }

    public function testQueuedGenericEventReachesItsRegisteredListener(): void
    {
        $dispatcher = new EventDispatcher(Mockery::mock(Queue::class));
        $received = null;
        $dispatcher->listen('test.queued', static function (mixed $event) use (&$received): void {
            $received = $event;
        });

        $dispatcher->processQueuedEvent([
            'data' => [
                'event_name' => 'test.queued',
                'event_data' => ['id' => 9],
            ],
        ]);

        self::assertInstanceOf(\Core\GenericEvent::class, $received);
        self::assertSame(['id' => 9], $received->getData());
    }

    public function testCanonicalStateTransitionsAreEnforced(): void
    {
        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldReceive('warning')->zeroOrMoreTimes();
        $stateMachine = new StateMachineService(Mockery::mock(\Core\Database::class), $logger);

        self::assertTrue($stateMachine->canTransition('lottery', 'upcoming', 'active'));
        self::assertTrue($stateMachine->canTransition('lottery', 'active', 'voting'));
        self::assertTrue($stateMachine->canTransition('lottery', 'calculating', 'completed'));
        self::assertFalse($stateMachine->canTransition('lottery', 'completed', 'active'));
        self::assertTrue($stateMachine->canTransition('prediction_game', 'closed', 'finished'));
        self::assertFalse($stateMachine->canTransition('prediction_game', 'finished', 'open'));
    }

    public function testQueueWorkerMapsAssociativeAndArrayPayloads(): void
    {
        $logger = Mockery::mock(LoggerInterface::class);
        $queue = Mockery::mock(Queue::class);
        $worker = new QueueWorker($logger, $queue);
        $invoke = new \ReflectionMethod($worker, 'invokeHandler');
        $invoke->setAccessible(true);

        $result = $invoke->invoke(
            $worker,
            new QueueContractFixture(),
            ['userId' => '42', 'amount' => 3.5],
            QueueContractFixture::class
        );
        self::assertSame(['user_id' => 42, 'amount' => '3.5'], $result);

        $payload = ['event_name' => 'test.event', 'event_data' => ['id' => 7]];
        self::assertSame(
            $payload,
            $invoke->invoke($worker, new ArrayPayloadFixture(), $payload, ArrayPayloadFixture::class)
        );
    }

    public function testPredictionSettlementBatchRequeuesWhenOneGameFails(): void
    {
        $db = Mockery::mock(\Core\Database::class);
        $db->shouldReceive('fetchAll')->once()->andReturn([
            (object)['id' => 17, 'result' => 'home'],
        ]);

        // FIX-CH03 (هم‌ترازسازی تست): شناسهٔ سیستمی از تنظیم معتبر resolve می‌شود
        // (نه sentinel صفر) — resolveAdminId ردیف کاربر سیستمی را از DB چک می‌کند.
        $db->shouldReceive('fetch')
            ->once()
            ->with("SELECT id, status FROM users WHERE id = ? LIMIT 1", Mockery::any())
            ->andReturn((object)['id' => 1, 'status' => 'active']);

        $predictionService = Mockery::mock(PredictionService::class);
        $predictionService->shouldReceive('settleGameOrFail')
            ->once()
            ->with(17, 'home', 1)
            ->andThrow(new \RuntimeException('temporary settlement failure'));

        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldReceive('error')->twice();

        $job = new PredictionGameSettlementJob($predictionService, $db, $logger);

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('temporary settlement failure');
        $job->handle();
    }
}
