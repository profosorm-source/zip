<?php

declare(strict_types=1);

namespace Tests\Unit\Events;

use App\Events\TaskCompletedEvent;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M22-03 — رویداد باید submission_id را حمل کند تا لیسنر کلیدهای
 * idempotency XP/trust را per-submission بسازد (در تسک‌های چندمجریه فقط
 * اولین مجری پاداش نمی‌گیرد). سازگاری رویدادهای legacy (بدون submission)
 * حفظ می‌شود.
 */
final class M22TaskCompletedEventSubmissionIdTest extends TestCase
{
    /** @test */
    public function event_carries_submission_id_as_property_and_payload(): void
    {
        $event = new TaskCompletedEvent(7, 3, 5.0, 'CUSTOM_TASK', 912);

        $this->assertSame(912, $event->submissionId);
        $data = $event->getData();
        $this->assertSame(912, $data['submission_id']);
        $this->assertSame(7, $data['user_id']);
        $this->assertSame(3, $data['task_id']);
    }

    /** @test */
    public function legacy_events_without_submission_id_still_construct(): void
    {
        // فراخوانی positional قدیمی (۴ آرگومان) باید دست‌نخورده بماند
        $event = new TaskCompletedEvent(7, 3, 5.0, 'CUSTOM_TASK');

        $this->assertNull($event->submissionId);
        $data = $event->getData();
        $this->assertNull($data['submission_id']);
    }

    /** @test */
    public function listener_uses_per_submission_keys_with_legacy_fallback(): void
    {
        // پین رفتاری لیسنر: منطق کلید per-submission + fallback per-task
        $src = file_get_contents(dirname(__DIR__, 3) . '/app/Listeners/TaskCompletedListener.php');

        $this->assertStringContainsString('$xpIdemKey = $submissionId > 0 ? "custom_task_xp_{$submissionId}" : "task_{$taskId}";', $src);
        $this->assertStringContainsString('$trustIdemKey = $submissionId > 0 ? "custom_task_trust_{$submissionId}" : "task_completed_{$taskId}";', $src);
        $this->assertStringContainsString('FIX-M22-03', $src);

        // کلیدهای محاسبه‌شده واقعاً به award/applyDelta پاس داده می‌شوند
        $this->assertStringContainsString('$xpService->award($userIdInt, ModuleContext::CUSTOM_TASKS, (float)$xpReward, $xpIdemKey);', $src);
        $this->assertStringContainsString('\'task_completed\', [], $trustIdemKey);', $src);
        $this->assertStringContainsString("'event_id' => \$eventId", $src);
    }
}
