<?php

declare(strict_types=1);

namespace Tests\Unit\Auth;

use App\Events\UserRegisteredEvent;
use App\Jobs\Auth\ProcessRegistrationJob;
use App\Listeners\LogUserRegisteredActivity;
use App\Services\User\UserService;
use Core\EventDispatcher;
use Mockery as m;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * بچ S10 — سنجاق رفتار فیکس FIX-S10-1 (بخش‌های ب و ج)
 *
 * بخش ب: ProcessRegistrationJob باید plain_tokenِ بازگشتی از register() را به
 * سازندهٔ UserRegisteredEvent بدهد (قبلاً دور ریخته می‌شد و شنونده به‌عنوان
 * fallback «هشِ» DB را ایمیل می‌کرد ⇒ لینک/کد تأیید ثبت‌نام مرده).
 *
 * بخش ج: LogUserRegisteredActivity با plainToken=null هرگز نباید ایمیل بفرستد
 * (fallback قبلی هش DB را می‌فرستاد) — fail-visible با هشدار، نه ایمیل دروغین.
 */
final class S10EventTokenPropagationTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->expectOutputRegex('/.*/');
    }

    protected function tearDown(): void
    {
        // پاکسازی شنوندهٔ probe از سینگلتون واقعی تا به تست‌های دیگر نشت نکند
        try {
            EventDispatcher::getInstance()->forget(UserRegisteredEvent::class);
        } catch (\Throwable) {
        }
        m::close();
        parent::tearDown();
    }

    public function test_job_passes_plain_token_from_register_result_into_event(): void
    {
        $captured = [];
        $dispatcher = EventDispatcher::getInstance();
        $dispatcher->listen(
            UserRegisteredEvent::class,
            static function (UserRegisteredEvent $event) use (&$captured): void {
                $captured[] = $event;
            }
        );

        $userService = m::mock(UserService::class);
        $userService->shouldReceive('register')->once()->andReturn([
            'id'          => 777,
            'plain_token' => 'plain-token-abc123',
        ]);

        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);
        $wallet->shouldReceive('getOrCreateWallet')->once()->with(777)->andReturnNull();

        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldReceive('warning')->byDefault()->andReturnNull();
        $logger->shouldReceive('error')->byDefault()->andReturnNull();
        $logger->shouldReceive('info')->byDefault()->andReturnNull();

        $userModel = m::mock(\App\Models\User::class);
        $created = new \stdClass();
        $created->referred_by = null; // بدون معرف → مسیر بونوس رفرال اجرا نمی‌شود
        // find دو بار صدا زده می‌شود: یک‌بار در بلوک رفرال و یک‌بار در return نهایی
        $userModel->shouldReceive('find')->twice()->with(777)->andReturn($created);

        $referral = m::mock(\App\Services\Shared\ReferralService::class);
        $referral->shouldReceive('awardSignupBonus')->never();

        $job = new ProcessRegistrationJob($userService, $wallet, $logger, $userModel, $referral);

        $result = $job->handle([
            'email'    => 's10@example.test',
            'password' => 'Secret!123',
        ]);

        $this->assertTrue((bool)($result['success'] ?? false));
        $this->assertCount(1, $captured, 'رویداد باید دقیقاً یک‌بار دیسپچ شود');

        $event = $captured[0];
        $this->assertSame('plain-token-abc123', $event->plainToken, 'plain_token باید به رویداد برسد');
        $this->assertSame('plain-token-abc123', $event->getData()['plain_token'] ?? null);
        $this->assertSame(777, $event->userId);
    }

    public function test_listener_sends_verification_email_with_plain_token(): void
    {
        /** @var MockInterface&\App\Services\EmailService $email */
        $email = m::mock(\App\Services\EmailService::class);
        $email->shouldReceive('sendVerificationEmail')
            ->once()
            ->with(42, 'plain-xyz')
            ->andReturnTrue();

        $userService = m::mock(UserService::class);
        $found = new \stdClass();
        $found->email_verification_token = 'db-hash-value';
        $userService->shouldReceive('find')->once()->with(42)->andReturn($found);

        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldReceive('activity')->once()->andReturnNull();

        $listener = new LogUserRegisteredActivity($logger, $userService, $email);
        $event = new UserRegisteredEvent(42, 'u@example.test', '127.0.0.1', 'plain-xyz');

        $listener->handle($event);
        $this->assertTrue(true, 'رسیدن بدون استثنا = قرارداد برقرار');
    }

    public function test_listener_never_sends_email_when_plain_token_missing(): void
    {
        /** @var MockInterface&\App\Services\EmailService $email */
        $email = m::mock(\App\Services\EmailService::class);
        // بخش ج: fallback هش حذف شد — بدون plainToken هیچ ایمیلی ارسال نمی‌شود
        $email->shouldReceive('sendVerificationEmail')->never();

        $userService = m::mock(UserService::class);
        $found = new \stdClass();
        $found->email_verification_token = 'db-hash-value';
        $userService->shouldReceive('find')->once()->with(9)->andReturn($found);

        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldReceive('activity')->once()->andReturnNull();
        // fail-visible: هشدار ثبت می‌شود
        $logger->shouldReceive('warning')
            ->once()
            ->with('listener.user_registered.no_plain_token', m::on(static fn (array $ctx): bool => (int)($ctx['user_id'] ?? 0) === 9))
            ->andReturnNull();

        $listener = new LogUserRegisteredActivity($logger, $userService, $email);
        $event = new UserRegisteredEvent(9, 'u@example.test', '127.0.0.1', null);

        $listener->handle($event);
        $this->assertTrue(true, 'رسیدن بدون استثنا = رفتار fail-visible');
    }
}
