<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use PHPUnit\Framework\TestCase;
use Mockery as m;
use App\Jobs\WithdrawalTimeoutJob;
use App\Services\Wallet\WalletMutationService;
use Core\Database;
use App\Contracts\LoggerInterface;

/**
 * تست رگرسیون S4-M5 (بخش کرون): کرون timeout باید نتیجهٔ UPDATE ردیف
 * withdrawals را چک کند؛ صفر ردیف = شکست کل تراکنش (rollback بازگشت وجه)
 * تا «refund بدون ردیف» — یعنی بازگشت پول قفل‌شده برای درخواستی که هم‌زمان
 * از وضعیت pending/processing خارج شده — ناممکن شود.
 */
final class WithdrawalTimeoutJobCasTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @return array<string, mixed> */
    private function stuckRow(): array
    {
        return [
            (object)[
                'id'             => 11,
                'user_id'        => 5,
                'amount'         => '7000',
                'currency'       => 'irt',
                'status'         => 'pending',
                'transaction_id' => 'WTX-1',
                'created_at'     => '2026-09-19 00:00:00',
                'stuck_hours'    => 3,
            ],
        ];
    }

    private function stmt(): \PDOStatement
    {
        $s = m::mock(\PDOStatement::class);
        $s->shouldReceive('fetchAll')->with(\PDO::FETCH_OBJ)->andReturn($this->stuckRow());
        $s->shouldReceive('rowCount')->andReturn(0)->byDefault();
        return $s;
    }

    /** @test */
    public function zero_row_update_rolls_back_and_counts_no_cancellation(): void
    {
        $db = m::mock(Database::class);
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $mutation = m::mock(WalletMutationService::class);
        $mutation->shouldReceive('cancelWithdrawal')->once()->with('WTX-1', 5)->andReturnTrue();

        $selectStmt = $this->stmt();
        $insertStmt = m::mock(\PDOStatement::class);
        $updateStmt = m::mock(\PDOStatement::class);
        $updateStmt->shouldReceive('rowCount')->andReturn(0); // ردیف هم‌زمان تغییر کرده

        $db->shouldReceive('query')->with(m::on(fn (string $sql): bool => str_contains($sql, 'FROM withdrawals')), m::type('array'))->andReturn($selectStmt);
        $db->shouldReceive('fetchAll')->andReturn([]); // withdrawal_reviews خالی
        $db->shouldReceive('query')->with(m::on(fn (string $sql): bool => str_contains($sql, 'INSERT INTO withdrawal_reviews')), m::type('array'))->andReturn($insertStmt);
        $db->shouldReceive('fetchColumn')->with(m::on(fn (string $sql): bool => str_contains($sql, 'FROM wallets')), m::type('array'))->andReturn('0');
        // transactional: کلوژر را اجرا کن؛ استثنای داخلش باید بیرون پرتاب شود (rollback)
        $db->shouldReceive('transactional')->once()->andReturnUsing(function (callable $cb) use ($db) {
            return $cb($db);
        });
        $db->shouldReceive('query')->with(m::on(fn (string $sql): bool => str_contains($sql, 'UPDATE withdrawals')), m::type('array'))->andReturn($updateStmt);

        $job = new WithdrawalTimeoutJob($db, $logger, $mutation, null);
        $result = $job->handle();

        $this->assertSame(0, $result['cancelled']);
        $this->assertSame(1, $result['scanned']);
    }

    /** @test */
    public function successful_update_counts_cancellation(): void
    {
        $db = m::mock(Database::class);
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $mutation = m::mock(WalletMutationService::class);
        $mutation->shouldReceive('cancelWithdrawal')->once()->with('WTX-1', 5)->andReturnTrue();

        $selectStmt = $this->stmt();
        $insertStmt = m::mock(\PDOStatement::class);
        $updateStmt = m::mock(\PDOStatement::class);
        $updateStmt->shouldReceive('rowCount')->andReturn(1);

        $db->shouldReceive('query')->with(m::on(fn (string $sql): bool => str_contains($sql, 'FROM withdrawals')), m::type('array'))->andReturn($selectStmt);
        $db->shouldReceive('fetchAll')->andReturn([]);
        $db->shouldReceive('query')->with(m::on(fn (string $sql): bool => str_contains($sql, 'INSERT INTO withdrawal_reviews')), m::type('array'))->andReturn($insertStmt);
        $db->shouldReceive('fetchColumn')->with(m::on(fn (string $sql): bool => str_contains($sql, 'FROM wallets')), m::type('array'))->andReturn('0');
        $db->shouldReceive('transactional')->once()->andReturnUsing(function (callable $cb) use ($db) {
            return $cb($db);
        });
        $db->shouldReceive('query')->with(m::on(fn (string $sql): bool => str_contains($sql, 'UPDATE withdrawals')), m::type('array'))->andReturn($updateStmt);
        // FIX-S34-B14-F22 (هم‌ترازسازی تست): پس از لغو خودکار موفق، پروندهٔ
        // رسیدگیِ بازِ همان برداشت dismissed می‌شود تا صف ادمین از پروندهٔ
        // خودکار-حل‌شده پر نماند.
        $dismissStmt = m::mock(\PDOStatement::class);
        $dismissStmt->shouldReceive('rowCount')->andReturn(1);
        $db->shouldReceive('query')->with(m::on(fn (string $sql): bool => str_contains($sql, 'UPDATE withdrawal_reviews') && str_contains($sql, "'dismissed'")), m::type('array'))->andReturn($dismissStmt);

        $logger->shouldReceive('info')->with('withdrawal.timeout.cancelled', m::type('array'))->once();

        $job = new WithdrawalTimeoutJob($db, $logger, $mutation, null);
        $result = $job->handle();

        $this->assertSame(1, $result['cancelled']);
    }
}
