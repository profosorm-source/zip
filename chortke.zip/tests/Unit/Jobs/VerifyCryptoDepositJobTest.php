<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use PHPUnit\Framework\TestCase;
use App\Jobs\VerifyCryptoDepositJob;
use App\Services\CryptoDeposit\CryptoDepositService;

/**
 * S4-C1 regression (S33-B4 audit): the cron verify job must route through the
 * on-chain verification flow (tryAutoVerify), never through the legacy blind
 * fulfillCryptoDeposit crediting path.
 */
final class VerifyCryptoDepositJobTest extends TestCase
{
    protected function tearDown(): void
    {
        \Mockery::close();
        parent::tearDown();
    }

    public function test_handle_delegates_to_try_auto_verify(): void
    {
        /** @var \Mockery\MockInterface&CryptoDepositService $service */
        $service = \Mockery::mock(CryptoDepositService::class);
        $service->shouldReceive('tryAutoVerify')
            ->once()
            ->with(77)
            ->andReturn(['success' => true, 'message' => 'بررسی خودکار با موفقیت انجام و تأیید شد', 'auto' => true]);

        $job = new VerifyCryptoDepositJob($service);
        $result = $job->handle(77);

        $this->assertTrue(($result['auto'] ?? false) === true);
        $this->assertTrue((bool)($result['success'] ?? false));
    }

    public function test_handle_wraps_service_exceptions_as_failed_result(): void
    {
        /** @var \Mockery\MockInterface&CryptoDepositService $service */
        $service = \Mockery::mock(CryptoDepositService::class);
        $service->shouldReceive('tryAutoVerify')
            ->once()
            ->with(88)
            ->andThrow(new \RuntimeException('verifier offline'));

        $job = new VerifyCryptoDepositJob($service);
        $result = $job->handle(88);

        $this->assertFalse((bool)($result['success'] ?? true));
        $this->assertSame('verifier offline', $result['message'] ?? null);
    }
}
