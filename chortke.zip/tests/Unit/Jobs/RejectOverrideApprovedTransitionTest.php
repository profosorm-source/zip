<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use PHPUnit\Framework\TestCase;
use Mockery as m;
use App\Jobs\SocialTask\RejectSocialTaskExecutionJob;
use App\Models\SocialTaskExecutionModel;
use App\Models\SocialTaskModel;
use Core\Database;

/**
 * FIX-R36-W4 (F-A17-ORCH-01) — گارد گذرِ عرضیِ approve→reject در
 * RejectSocialTaskExecutionJob::handleAdminOverride.
 *
 * قرارداد:
 *  - اجرای previously-approved/soft_approved (reward_paid=1) هنگام ردِ اجباریِ
 *    ادمین باید بوک‌کیپینگِ خانوادهٔ completed_count بگیرد
 *    (completed_count-1 + remaining_count+1) و هرگز pending_count-1 نزند
 *    (شمارندهٔ کمپینِ یک اجرای دیگرِ درانتظار را می‌سوزاند) — آینهٔ
 *    FIX-R36-W3 (F-A17-03) در ApproveSocialTaskExecutionJob.
 *  - ردِ عادیِ submitted همچنان مسیر کلاسیک pending_count-1 را می‌رود.
 */
class RejectOverrideApprovedTransitionTest extends TestCase
{
    use \Mockery\Adapter\Phpunit\MockeryPHPUnitIntegration;

    /** Database::query() has a PDOStatement return type — mocks must satisfy it */
    private static function stmt(): \PDOStatement
    {
        return m::mock(\PDOStatement::class);
    }

    private const ADS_COMPLETED_SQL = 'completed_count = GREATEST(COALESCE(completed_count,0)-1,0)';
    private const ADS_PENDING_SQL   = 'pending_count = GREATEST(COALESCE(pending_count,0)-1,0)';
    private const TRUST_SQL         = 'INSERT INTO social_user_trust';

    private function makeJob(object $exec): RejectSocialTaskExecutionJob
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('beginTransaction')->andReturnTrue();
        $db->shouldReceive('commit')->andReturnTrue();
        $db->shouldReceive('inTransaction')->andReturn(true);
        $db->shouldReceive('rollback')->andReturnTrue();

        $execModel = m::mock(SocialTaskExecutionModel::class);
        $execModel->shouldReceive('getExecutionById')->with(9, true)->andReturn($exec);
        $execModel->shouldReceive('updateExecutionStatus')
            ->once()
            ->withArgs(function (int $id, string $status, array $data): bool {
                return $id === 9
                    && $status === 'rejected'
                    && ($data['decision'] ?? '') === 'rejected'
                    && ($data['overridden_by'] ?? 0) === 1;
            })
            ->andReturnTrue();

        $taskModel = m::mock(SocialTaskModel::class);

        return new RejectSocialTaskExecutionJob($db, $execModel, $taskModel, null, null);
    }

    public function testApprovedToRejectedUsesCompletedCountBookkeepingNotPending(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('beginTransaction')->andReturnTrue();
        $db->shouldReceive('commit')->andReturnTrue();
        $db->shouldReceive('inTransaction')->andReturn(true);
        $db->shouldReceive('rollback')->andReturnTrue();

        // شاخهٔ گذر عرضی: دقیقاً دو query — completed_count واریانت + trust
        $db->shouldReceive('query')
            ->once()
            ->withArgs(function (string $sql, array $params): bool {
                return str_contains($sql, self::ADS_COMPLETED_SQL)
                    && str_contains($sql, 'remaining_count = COALESCE(remaining_count,0)+1')
                    && !str_contains($sql, self::ADS_PENDING_SQL)
                    && $params === [1];
            })
            ->andReturn(self::stmt());
        $db->shouldReceive('query')
            ->once()
            ->withArgs(function (string $sql, array $params): bool {
                return str_contains($sql, self::TRUST_SQL) && $params === [2];
            })
            ->andReturn(self::stmt());

        $execModel = m::mock(SocialTaskExecutionModel::class);
        $execModel->shouldReceive('getExecutionById')->with(9, true)->andReturn((object) [
            'id' => 9, 'ad_id' => 1, 'executor_id' => 2,
            'status' => 'approved', 'decision' => 'approved', 'reward_paid' => 1,
        ]);
        $execModel->shouldReceive('updateExecutionStatus')->once()->andReturnTrue();
        $taskModel = m::mock(SocialTaskModel::class);

        $job = new RejectSocialTaskExecutionJob($db, $execModel, $taskModel, null, null);
        $result = $job->handleAdminOverride(9, 1, 'override after approval');

        $this->assertTrue($result['success'], 'approved→rejected override must succeed');
        $this->assertSame('rejected', $result['new_decision']);
    }

    public function testSoftApprovedWithoutRewardPaidFlagStillRoutedByStatus(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('beginTransaction')->andReturnTrue();
        $db->shouldReceive('commit')->andReturnTrue();
        $db->shouldReceive('inTransaction')->andReturn(true);
        $db->shouldReceive('rollback')->andReturnTrue();

        $db->shouldReceive('query')
            ->once()
            ->withArgs(function (string $sql, array $params): bool {
                return str_contains($sql, self::ADS_COMPLETED_SQL) && $params === [1];
            })
            ->andReturn(self::stmt());
        $db->shouldReceive('query')
            ->once()
            ->withArgs(function (string $sql, array $params): bool {
                return str_contains($sql, self::TRUST_SQL) && $params === [2];
            })
            ->andReturn(self::stmt());

        $execModel = m::mock(SocialTaskExecutionModel::class);
        // بدون reward_paid (رکورد قدیمی) — فیل بر status
        $execModel->shouldReceive('getExecutionById')->with(9, true)->andReturn((object) [
            'id' => 9, 'ad_id' => 1, 'executor_id' => 2,
            'status' => 'soft_approved', 'decision' => 'soft_approved',
        ]);
        $execModel->shouldReceive('updateExecutionStatus')->once()->andReturnTrue();
        $taskModel = m::mock(SocialTaskModel::class);

        $job = new RejectSocialTaskExecutionJob($db, $execModel, $taskModel, null, null);
        $result = $job->handleAdminOverride(9, 1, 'override');

        $this->assertTrue($result['success']);
    }

    public function testSubmittedToRejectedKeepsClassicPendingBookkeeping(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('beginTransaction')->andReturnTrue();
        $db->shouldReceive('commit')->andReturnTrue();
        $db->shouldReceive('inTransaction')->andReturn(true);
        $db->shouldReceive('rollback')->andReturnTrue();

        $db->shouldReceive('query')
            ->once()
            ->withArgs(function (string $sql, array $params): bool {
                return str_contains($sql, self::ADS_PENDING_SQL)
                    && str_contains($sql, 'remaining_count = COALESCE(remaining_count,0)+1')
                    && !str_contains($sql, self::ADS_COMPLETED_SQL)
                    && $params === [1];
            })
            ->andReturn(self::stmt());
        $db->shouldReceive('query')
            ->once()
            ->withArgs(function (string $sql, array $params): bool {
                return str_contains($sql, self::TRUST_SQL) && $params === [2];
            })
            ->andReturn(self::stmt());

        $execModel = m::mock(SocialTaskExecutionModel::class);
        $execModel->shouldReceive('getExecutionById')->with(9, true)->andReturn((object) [
            'id' => 9, 'ad_id' => 1, 'executor_id' => 2,
            'status' => 'submitted', 'decision' => null, 'reward_paid' => 0,
        ]);
        $execModel->shouldReceive('updateExecutionStatus')->once()->andReturnTrue();
        $taskModel = m::mock(SocialTaskModel::class);

        $job = new RejectSocialTaskExecutionJob($db, $execModel, $taskModel, null, null);
        $result = $job->handleAdminOverride(9, 1, 'normal reject');

        $this->assertTrue($result['success']);
        $this->assertSame('rejected', $result['new_decision']);
    }

    public function testRejectedReplayStillSkipsBookkeeping(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('beginTransaction')->andReturnTrue();
        $db->shouldReceive('commit')->andReturnTrue();
        $db->shouldReceive('inTransaction')->andReturn(true);
        $db->shouldReceive('rollback')->andReturnTrue();
        $db->shouldNotReceive('query'); // بوک‌کیپینگ صفر

        $execModel = m::mock(SocialTaskExecutionModel::class);
        $execModel->shouldReceive('getExecutionById')->with(9, true)->andReturn((object) [
            'id' => 9, 'ad_id' => 1, 'executor_id' => 2,
            'status' => 'rejected', 'decision' => 'rejected', 'reward_paid' => 0,
        ]);
        $execModel->shouldReceive('updateExecutionStatus')->once()->andReturnTrue();
        $taskModel = m::mock(SocialTaskModel::class);

        $job = new RejectSocialTaskExecutionJob($db, $execModel, $taskModel, null, null);
        $result = $job->handleAdminOverride(9, 1, 'replay');

        $this->assertTrue($result['success']);
        $this->assertStringContainsString('قبلاً اعمال شده', (string)$result['message']);
    }
}
