<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Jobs\CustomTask\SubmitProofJob;
use Core\Container;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * FIX-S19-VFP — اتصال VideoFingerprintService به چرخهٔ ارسال مدرک تسک:
 *
 *  پیشینه: سرویس VideoFingerprintService از تولد در کدبیس اصلی یتیم مطلق بود
 *  (صفر caller) و جایگزینِ ناقصش فقط match دقیقِ string در همانِ یک تسک بود ⇒
 *  استفادهٔ cross-task از یک ویدیو (کش ریفرد) نامرئی بود و با variant های سادهٔ
 *  URL (پروتکل/www/حروف بزرگ/پارامتر query) قابل دورزدن بود.
 *
 *  ۱) ارسال همان ویدیو با variant URL برای تسک دیگر باید کشف و رد شود.
 *  ۲) ریسابمیتِ همان لینک روی همان تسک پس از reject باید آزاد بماند (عدالت).
 *  ۳) proof_url_hash باید روی رکورد ذخیره و corpus سراسری تغذیه شود.
 *  ۴) مدرک بدون لینک (نوع text) نباید hash بگیرد.
 *
 * تست‌های DB روی MariaDB واقعی اجرا می‌شوند (قرارداد S12…S16).
 */
final class CustomTaskProofFingerprintTest extends TestCase
{
    /** @var list<int> */
    private array $cleanupSubmissionIds = [];
    /** @var list<int> */
    private array $cleanupTaskIds = [];
    /** @var list<string> */
    private array $cleanupFingerprintHashes = [];

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        foreach ($this->cleanupSubmissionIds as $id) {
            try {
                $db->execute("DELETE FROM custom_task_submissions WHERE id = ?", [$id]);
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        foreach ($this->cleanupTaskIds as $id) {
            try {
                $db->execute("DELETE FROM ads WHERE id = ?", [$id]);
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        foreach ($this->cleanupFingerprintHashes as $hash) {
            try {
                $db->execute("DELETE FROM video_fingerprints WHERE combined_hash = ?", [$hash]);
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        $this->cleanupSubmissionIds = [];
        $this->cleanupTaskIds = [];
        $this->cleanupFingerprintHashes = [];
        parent::tearDown();
    }

    public function test_cross_task_reuse_of_same_video_is_rejected_despite_url_variants(): void
    {
        $this->setOutputCallback(static function (string $output): string { return ''; });
        $db = $this->db();
        $worker = random_int(950000, 979999);

        $idA = $this->seedSubmission($this->seedTask('video'), $worker);
        $idB = $this->seedSubmission($this->seedTask('video'), $worker);
        /** @var SubmitProofJob $job */
        $job = $this->container()->make(SubmitProofJob::class);

        // ارسال اول — لینک اصلی باید پذیرفته شود و hash + corpus لنگر شود
        $originalUrl = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
        $resultA = $job->handle([
            'submission_id' => $idA,
            'worker_id' => $worker,
            'proof_data' => [
                'proof_url' => $originalUrl,
                'idempotency_key' => 's33vfp_a_' . bin2hex(random_bytes(8)),
            ],
        ]);
        $this->assertTrue(is_bool($resultA['success'] ?? null) ? $resultA['success'] : false, 'ارسال اول باید موفق باشد: ' . (string)($resultA['message'] ?? ''));

        $rowA = $db->fetch("SELECT proof_url_hash, status FROM custom_task_submissions WHERE id = ?", [$idA]);
        $this->assertNotNull($rowA);
        $this->assertSame('submitted', (string)$rowA->status);
        $this->assertNotNull($rowA->proof_url_hash, 'proof_url_hash باید ذخیره شود');
        $hashA = (string)$rowA->proof_url_hash;
        $this->cleanupFingerprintHashes[] = $hashA;

        $corpus = $db->fetch("SELECT id FROM video_fingerprints WHERE combined_hash = ?", [$hashA]);
        $this->assertNotNull($corpus, 'corpus سراسری video_fingerprints باید تغذیه شود');

        // ارسال دوم — همان ویدیو با variant (پروتکل/www/حروف بزرگ/پارامتر query)
        // برای تسکِ دیگر باید توسط گیت cross-task رد شود
        $variantUrl = 'http://WWW.YOUTUBE.com/watch?v=dQw4w9WgXcQ&t=42s';
        $resultB = $job->handle([
            'submission_id' => $idB,
            'worker_id' => $worker,
            'proof_data' => [
                'proof_url' => $variantUrl,
                'idempotency_key' => 's33vfp_b_' . bin2hex(random_bytes(8)),
            ],
        ]);
        $this->assertFalse($resultB['success'] ?? true, 'استفادهٔ cross-task باید رد شود');
        $this->assertStringContainsString('تسک دیگری', (string)($resultB['message'] ?? ''));

        $rowB = $db->fetch("SELECT status, proof_url_hash FROM custom_task_submissions WHERE id = ?", [$idB]);
        $this->assertNotNull($rowB);
        $this->assertSame('in_progress', (string)$rowB->status, 'ردیفِ ردشده نباید submitted شود');
        $this->assertNull($rowB->proof_url_hash, 'ردیفِ ردشده نباید hash بگیرد');
    }

    public function test_resubmission_after_rejection_on_same_task_is_allowed(): void
    {
        $this->setOutputCallback(static function (string $output): string { return ''; });
        $db = $this->db();
        $worker = random_int(950000, 979999);
        $taskId = $this->seedTask('video');
        $idFirst = $this->seedSubmission($taskId, $worker);
        /** @var SubmitProofJob $job */
        $job = $this->container()->make(SubmitProofJob::class);

        $url = 'https://youtu.be/Channel0938X';
        $resultFirst = $job->handle([
            'submission_id' => $idFirst,
            'worker_id' => $worker,
            'proof_data' => [
                'proof_url' => $url,
                'idempotency_key' => 's33vfp_r1_' . bin2hex(random_bytes(8)),
            ],
        ]);
        $this->assertTrue(is_bool($resultFirst['success'] ?? null) ? $resultFirst['success'] : false, 'ارسال اول باید موفق باشد');

        // مدرک رد می‌شود (جریان واقعی: کارفرما reject می‌کند)
        $db->execute("UPDATE custom_task_submissions SET status = 'rejected' WHERE id = ?", [$idFirst]);

        // تلاش دوم روی همان تسک با همان لینک — باید آزاد بماند
        $idSecond = $this->seedSubmission($taskId, $worker);
        $resultSecond = $job->handle([
            'submission_id' => $idSecond,
            'worker_id' => $worker,
            'proof_data' => [
                'proof_url' => $url,
                'idempotency_key' => 's33vfp_r2_' . bin2hex(random_bytes(8)),
            ],
        ]);
        $this->assertTrue(is_bool($resultSecond['success'] ?? null) ? $resultSecond['success'] : false, 'ریسابمیت پس از reject روی همان تسک باید مجاز باشد: ' . (string)($resultSecond['message'] ?? ''));

        $hashRow = $db->fetch("SELECT proof_url_hash FROM custom_task_submissions WHERE id = ?", [$idSecond]);
        $this->assertNotNull($hashRow);
        if (is_string($hashRow->proof_url_hash ?? null)) {
            $this->cleanupFingerprintHashes[] = (string)$hashRow->proof_url_hash;
        }
    }

    public function test_text_proof_stores_no_url_hash(): void
    {
        $this->setOutputCallback(static function (string $output): string { return ''; });
        $db = $this->db();
        $worker = random_int(950000, 979999);

        $id = $this->seedSubmission($this->seedTask('text'), $worker);
        /** @var SubmitProofJob $job */
        $job = $this->container()->make(SubmitProofJob::class);

        $result = $job->handle([
            'submission_id' => $id,
            'worker_id' => $worker,
            'proof_data' => [
                'proof_text' => 'این مدرک متنی آزمون است و از ده کاراکتر بیشتر است.',
                'idempotency_key' => 's33vfp_t_' . bin2hex(random_bytes(8)),
            ],
        ]);
        $this->assertTrue(is_bool($result['success'] ?? null) ? $result['success'] : false, 'مدرک متنی باید موفق شود: ' . (string)($result['message'] ?? ''));

        $row = $db->fetch("SELECT proof_url_hash FROM custom_task_submissions WHERE id = ?", [$id]);
        $this->assertNotNull($row);
        $this->assertNull($row->proof_url_hash, 'مدرک بدون لینک نباید hash بگیرد');
    }

    /**
     * 🛡️ FIX-A24-02 — ردِ گیت (ویدیوی تسک دیگر) نباید هیچ ردیف corpus
     * جدیدی بسازد: قبل از این بچ، checkDuplicateِ خودِ گیت در دیدِ نخست
     * می‌نوشت و شکست‌های بعدی اثر انگشت را می‌سوزاند؛ اکنون نوشتن فقط
     * پس از پذیرش CAS است (ترتیب منبع در A24Section24PinningTest پین شده).
     */
    public function test_gate_rejection_adds_no_corpus_rows(): void
    {
        $this->setOutputCallback(static function (string $output): string { return ''; });
        $db = $this->db();
        $worker = random_int(950000, 979999);

        // الف) پذیرش اول — corpus تغذیه می‌شود
        $idA = $this->seedSubmission($this->seedTask('video'), $worker);
        /** @var SubmitProofJob $job */
        $job = $this->container()->make(SubmitProofJob::class);

        $originalUrl = 'https://youtu.be/NoBurn' . bin2hex(random_bytes(3));
        $resultA = $job->handle([
            'submission_id' => $idA,
            'worker_id' => $worker,
            'proof_data' => [
                'proof_url' => $originalUrl,
                'idempotency_key' => 'a24gb_a_' . bin2hex(random_bytes(8)),
            ],
        ]);
        $this->assertTrue(is_bool($resultA['success'] ?? null) ? $resultA['success'] : false, 'ارسال اول باید موفق باشد: ' . (string)($resultA['message'] ?? ''));

        $rowA = $db->fetch("SELECT proof_url_hash FROM custom_task_submissions WHERE id = ?", [$idA]);
        $this->assertNotNull($rowA);
        $this->cleanupFingerprintHashes[] = (string)$rowA->proof_url_hash;

        $videoId = substr($originalUrl, (int)strrpos($originalUrl, '/') + 1);
        $countAfterAccept = (int)$db->fetchColumn(
            'SELECT COUNT(*) FROM video_fingerprints WHERE video_id = ?',
            [$videoId]
        );
        $this->assertSame(1, $countAfterAccept, 'پذیرش اول باید دقیقاً یک ردیف corpus بسازد');

        // ب) همان ویدیو برای تسک دیگر → ردِ گیت؛ تعداد ردیف‌های corpus
        // این ویدیو نباید تغییر کند (نوشتن ممنوع در مسیر بازرسی/رد)
        $idB = $this->seedSubmission($this->seedTask('video'), $worker);
        $variantUrl = 'https://www.youtube.com/watch?v=' . $videoId . '&t=10s';
        $resultB = $job->handle([
            'submission_id' => $idB,
            'worker_id' => $worker,
            'proof_data' => [
                'proof_url' => $variantUrl,
                'idempotency_key' => 'a24gb_b_' . bin2hex(random_bytes(8)),
            ],
        ]);
        $this->assertFalse($resultB['success'] ?? true, 'استفادهٔ cross-task باید رد شود');

        $countAfterReject = (int)$db->fetchColumn(
            'SELECT COUNT(*) FROM video_fingerprints WHERE video_id = ?',
            [$videoId]
        );
        $this->assertSame(1, $countAfterReject, 'ردِ گیت نباید ردیف corpus جدیدی بسازد (مصون از اشغال)');
    }

    // ─────────────────────────────────────────────────────────────
    // هارنس
    // ─────────────────────────────────────────────────────────────

    private function db(): Database
    {
        return Database::getInstance();
    }

    private function container(): Container
    {
        return Container::getInstance();
    }

    private function seedTask(string $proofType): int
    {
        $db = $this->db();
        $id = (int)$db->table('ads')->insert([
            'type' => 'custom_task',
            'user_id' => 1,
            'title' => 'تسک آزمون FIX-S19-VFP',
            'description' => 'تسک موقتی برای تست اتصال اثر انگشت ویدیو',
            'proof_type' => $proofType,
            'status' => 'active',
            'total_count' => 10,
            'remaining_count' => 10,
            'pending_count' => 0,
            'completed_count' => 0,
            'price_per_task' => 1000,
            'currency' => 'irt',
        ]);
        $this->cleanupTaskIds[] = $id;
        return $id;
    }

    private function seedSubmission(int $taskId, int $worker): int
    {
        $db = $this->db();
        $id = (int)$db->table('custom_task_submissions')->insert([
            'task_id' => $taskId,
            'worker_id' => $worker,
            'status' => 'in_progress',
            'idempotency_key' => 's33vfp_seed_' . bin2hex(random_bytes(8)),
            'deadline_at' => date('Y-m-d H:i:s', time() + 3600),
        ]);
        $this->cleanupSubmissionIds[] = $id;
        return $id;
    }
}
