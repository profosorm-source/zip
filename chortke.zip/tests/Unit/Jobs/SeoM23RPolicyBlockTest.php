<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Jobs\Seo\ProcessSeoTaskAsyncJob;
use App\Services\AntiFraud\FraudDetectionService;
use App\Services\AntiFraud\FraudGuardService;
use App\Services\AntiFraud\FraudStrategyResolver;
use App\Services\AntiFraud\RiskDecisionService;
use App\Services\AntiFraud\SeoFraudDetector;
use App\Services\Seo\AdsSeoService;
use App\Services\SeoPayoutService;
use App\Services\Settings\AppSettings;
use Core\TransactionWrapper;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M23R — پین تفکیک «تقلب» از «رد سیاستی» در تکمیل تسک سئو (T23-05):
 *  • ردِ صرفاً سیاستی گارد (allowed=false بدون is_fraud) دیگر کاربر را
 *    blacklist نمی‌کند و اجرا را fraud نمی‌زند — فقط rejected.
 *  • تشخیص قطعی تقلب (is_fraud=true) دقیقاً مثل قبل: fraud + blacklist.
 *  • T23-07: تکمیل روی آگهی غیرسئو رد می‌شود.
 */
final class SeoM23RPolicyBlockTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    private function guard(bool $isFraud, string $decision): FraudGuardService
    {
        $strategy = $this->createMock(\App\Contracts\AntiFraud\FraudCheckStrategyInterface::class);
        $strategy->method('check')->willReturn([
            'seo_fraud' => [
                'is_fraud'  => $isFraud,
                'flags'     => $isFraud ? ['seo_click_farm'] : [],
                'risk_score' => 10,
            ],
        ]);
        $resolver = $this->createMock(FraudStrategyResolver::class);
        $resolver->method('resolve')->willReturn($strategy);
        $riskDecision = $this->createMock(RiskDecisionService::class);
        $riskDecision->method('decide')->willReturn(['decision' => $decision, 'reason' => 'm23r-test']);
        $fraudDetection = $this->createMock(FraudDetectionService::class);
        $fraudDetection->method('calculateFraudScore')->willReturn(0);
        return new FraudGuardService(
            $this->createMock(\App\Contracts\LoggerInterface::class),
            $riskDecision,
            $fraudDetection,
            $resolver
        );
    }

    /** @param array<string, mixed> $adOverrides */
    private function runJob(bool $isFraud, string $decision, array $adOverrides = []): array
    {
        $execution = $this->createMock(\App\Models\SeoExecution::class);
        $execution->id = 11;
        $execution->user_id = 9;
        $execution->ad_id = 5;
        $execution->status = 'started';
        $execution->session_id = 'sess-m23r';
        $execution->device_fingerprint = '';
        $execution->click_counted_at = '2026-11-11 10:00:00'; // کلیک مهرشده — پلهٔ کامل
        $execution->landing_verified_at = null;
        $execution->method('findByIdForUpdate')->with(11)->willReturn($execution);
        $execution->method('secondsSinceStart')->with(11)->willReturn(300);

        $ad = (object)[
            'id' => 5,
            'user_id' => 77,
            'status' => 'active',
            'type' => 'seo',
            'target_duration' => 60,
            'min_score' => 40,
            'min_payout' => '100',
            'max_payout' => '200',
            'remaining_budget' => '10000',
            'currency' => 'irt',
            'site_commission_percent' => '0',
            'keyword' => 'm23r',
        ];
        foreach ($adOverrides as $k => $v) {
            $ad->$k = $v;
        }

        $ads = m::mock(AdsSeoService::class);
        $ads->shouldReceive('getAdForUpdate')->with(5)->andReturn($ad);
        $ads->shouldReceive('markExecutionAsFraud')->andReturn(true);
        $ads->shouldReceive('rejectExecution')->andReturn(true);
        $ads->shouldReceive('completeExecution')->andReturn(true);
        $ads->shouldReceive('getUser')->andReturn(null);

        $detector = m::mock(SeoFraudDetector::class);
        $detector->shouldReceive('addToBlacklist')->byDefault();

        $settings = $this->createMock(AppSettings::class);
        $settings->method('get')->willReturnCallback(static fn(string $k, mixed $d = null) => $d);

        $tx = $this->createMock(TransactionWrapper::class);
        $tx->method('runWithRetry')->willReturnCallback(static fn(\Closure $cb) => $cb());

        $job = new ProcessSeoTaskAsyncJob(
            $ads,
            $this->guard($isFraud, $decision),
            $detector,
            $this->createMock(\App\Contracts\LoggerInterface::class),
            $this->createMock(SeoPayoutService::class),
            $settings,
            $tx,
            $execution
        );

        $engagement = [
            'duration' => 60,
            'scroll_depth' => 80,
            'interactions' => 3,
            'interaction_types' => ['click'],
            'client_mode' => 'web',
            'behavior' => [],
        ];

        return [$job->handle(11, 9, 5, $engagement), $ads, $detector];
    }

    /** T23-05: رد سیاستی بدون تقلب ⇒ rejected، بدون blacklist و بدون برچسب fraud */
    public function test_policy_block_rejects_without_blacklist_or_fraud_label(): void
    {
        [$result, $ads, $detector] = $this->runJob(isFraud: false, decision: 'block');

        $this->assertFalse($result['success']);
        $this->assertFalse($result['fraud_detected'], 'رد سیاستی نباید fraud_detected=true بدهد');
        $ads->shouldNotHaveReceived('markExecutionAsFraud');
        $detector->shouldNotHaveReceived('addToBlacklist');
        $ads->shouldHaveReceived('rejectExecution')->once();
    }

    /** T23-05: تقلب قطعی ⇒ همان رفتار قبلی: برچسب fraud + blacklist */
    public function test_actual_fraud_still_marks_fraud_and_blacklists(): void
    {
        [$result, $ads, $detector] = $this->runJob(isFraud: true, decision: 'block');

        $this->assertFalse($result['success']);
        $this->assertTrue($result['fraud_detected']);
        $ads->shouldHaveReceived('markExecutionAsFraud')->once();
        $detector->shouldHaveReceived('addToBlacklist')->once();
        $ads->shouldNotHaveReceived('rejectExecution');
    }

    /** T23-07: تکمیل اجرا روی آگهی غیرسئو رد می‌شود (گیت نوع در مسیر تکمیل) */
    public function test_non_seo_ad_completion_is_rejected(): void
    {
        [$result, $ads] = $this->runJob(isFraud: false, decision: 'allow', adOverrides: ['type' => 'social_task']);

        $this->assertFalse($result['success']);
        $this->assertSame('این آگهی یک تسک سئو نیست.', $result['message']);
        $ads->shouldHaveReceived('rejectExecution')->once();
        $ads->shouldNotHaveReceived('completeExecution');
    }
}
