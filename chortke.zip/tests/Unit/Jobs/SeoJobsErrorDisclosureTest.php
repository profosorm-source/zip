<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Jobs\Seo\CompleteSeoTaskJob;
use App\Jobs\Seo\ProcessSeoTaskAsyncJob;
use App\Jobs\Seo\RateSeoTaskJob;
use App\Jobs\Seo\ReportSeoTaskJob;
use App\Services\AntiFraud\FraudDetectionService;
use App\Services\AntiFraud\FraudGuardService;
use App\Services\AntiFraud\FraudStrategyResolver;
use App\Services\AntiFraud\RiskDecisionService;
use App\Services\AntiFraud\SeoFraudDetector;
use App\Services\Seo\AdsSeoService;
use App\Services\SeoPayoutService;
use App\Services\Settings\AppSettings;
use Core\TransactionWrapper;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SEO-23-02 — قرارداد عدم‌افشای جزئیات استثنا در پاسخ کاربر.
 *
 * گزارش ماژول ۲۳ (SEO-23-02، شدت: بالا): چهار نقطه پیام خطا را به‌صورت
 * «خطا ...: » + getMessage() می‌ساختند و متن خامِ استثناهای لایه‌های پایین
 * (SQL/PDO، اسکرو «Escrow not found...»، کیف پول) مستقیم در JSON عمومی
 * ظاهر می‌شد — نقض سیاست امنیتی خودِ ماژول (SeoAdAdapter همان کار را ممنوع
 * کرده). این تست‌ها تضمین می‌کنند پیام خروجی هیچ‌گاه حاوی متن استثنا،
 * SQLSTATE، شناسه‌های داخلی یا نام کلاس نیست و جزئیات فقط به لاگ می‌رود.
 *
 * نکتهٔ فنی: AdsSeoService با PHPUnit-mock در PHP 8.2 مشکل union-type دارد
 * ⇒ Mockery؛ FraudGuardService کلاس final است ⇒ نمونهٔ واقعی با وابستگی‌های
 * mock (الگوی FraudGuardServiceTest). در این تست‌ها گارد هرگز فراخوانی
 * نمی‌شود (runWithRetry/سرویس زیرین قبلش استثنا می‌دهد) ولی constructor
 * به نمونهٔ معتبر نیاز دارد.
 */
final class SeoJobsErrorDisclosureTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    /** پیام‌های داخلی «سم‌دار» که هرگز نباید به کاربر برسند */
    private const POISON = 'SQLSTATE[42S02]: Table \'chortke.secret_table\' doesn\'t exist — SECRET-INTERNAL-DETAILS user_id=99 escrow_ref=EUR-7731';

    /** گارد واقعی (final) با وابستگی‌های سالم — در این تست‌ها فراخوانی نمی‌شود */
    private function fraudGuard(): FraudGuardService
    {
        $strategy = $this->createMock(\App\Contracts\AntiFraud\FraudCheckStrategyInterface::class);
        $strategy->method('check')->willReturn([]);
        $resolver = $this->createMock(FraudStrategyResolver::class);
        $resolver->method('resolve')->willReturn($strategy);
        $riskDecision = $this->createMock(RiskDecisionService::class);
        $riskDecision->method('decide')->willReturn(['decision' => 'allow', 'reason' => 'Low risk score']);
        $fraudDetection = $this->createMock(FraudDetectionService::class);
        $fraudDetection->method('calculateFraudScore')->willReturn(0);
        return new FraudGuardService(
            $this->createMock(\App\Contracts\LoggerInterface::class),
            $riskDecision,
            $fraudDetection,
            $resolver
        );
    }

    public function test_process_job_returns_generic_message_not_exception_text(): void
    {
        $transaction = $this->createMock(TransactionWrapper::class);
        // runWithRetry در اولین خط handle صدا می‌شود؛ استثنای داخلی را شبیه‌سازی می‌کنیم
        $transaction->method('runWithRetry')->willThrowException(new \RuntimeException(self::POISON));

        $logger = $this->createMock(\App\Contracts\LoggerInterface::class);
        $captured = null;
        $logger->method('error')->willReturnCallback(static function (string $k, array $ctx = []) use (&$captured) {
            $captured = $ctx;
            return null;
        });

        $job = new ProcessSeoTaskAsyncJob(
            m::mock(AdsSeoService::class),
            $this->fraudGuard(),
            $this->createMock(SeoFraudDetector::class),
            $logger,
            $this->createMock(SeoPayoutService::class),
            $this->createMock(AppSettings::class),
            $transaction,
            $this->createMock(\App\Models\SeoExecution::class)
        );

        $result = $job->handle(11, 2, 3, []);

        $this->assertFalse($result['success']);
        $this->assertSame('خطا در پردازش تسک سئو. لطفاً دوباره تلاش کنید؛ در صورت تکرار با پشتیبانی تماس بگیرید.', $result['message']);
        $this->assertStringNotContainsString('SQLSTATE', $result['message']);
        $this->assertStringNotContainsString('SECRET', $result['message']);
        $this->assertStringNotContainsString('RuntimeException', $result['message']);

        // جزئیات به‌جای کاربر، در لاگ با execution_id همبستگی ثبت شده است
        $this->assertIsArray($captured);
        $this->assertSame(11, $captured['execution_id'] ?? null);
        $this->assertSame(2, $captured['user_id'] ?? null);
        $this->assertStringContainsString('SECRET-INTERNAL-DETAILS', (string)($captured['error'] ?? ''));
    }

    public function test_complete_job_returns_generic_message_not_exception_text(): void
    {
        // مدل SeoExecution دارای return type ?self است — mock خودِ کلاس با propertyهای ست‌شده
        $execution = $this->createMock(\App\Models\SeoExecution::class);
        $execution->id = 11;
        $execution->user_id = 2;
        $execution->ad_id = 3;
        $execution->status = 'started';
        $execution->method('findByUser')->willReturn($execution);

        $process = $this->createMock(ProcessSeoTaskAsyncJob::class);
        $process->method('handle')->willThrowException(new \RuntimeException('Escrow not found or not releasable — SECRET-INTERNAL'));

        $logger = $this->createMock(\App\Contracts\LoggerInterface::class);
        $logged = null;
        $logger->method('error')->willReturnCallback(static function (string $k, array $ctx = []) use (&$logged) {
            $logged = $ctx;
            return null;
        });

        $job = new CompleteSeoTaskJob($execution, $process, $logger);
        $result = $job->handle(11, 2, ['duration' => 60, 'scroll_depth' => 50, 'interactions' => 2]);

        $this->assertFalse($result['success']);
        $this->assertSame('خطا در تکمیل تسک سئو. لطفاً دوباره تلاش کنید؛ در صورت تکرار با پشتیبانی تماس بگیرید.', $result['message']);
        $this->assertStringNotContainsString('Escrow', $result['message']);
        $this->assertStringNotContainsString('SECRET', $result['message']);
        $this->assertSame(11, $logged['execution_id'] ?? null);
    }

    public function test_report_job_returns_generic_message_not_exception_text(): void
    {
        $ads = m::mock(AdsSeoService::class);
        // 🛡️ FIX-SEO3-01: جاب حالا گیت type=seo + گیت «مجری با اجرای started/completed» دارد
        $ads->shouldReceive('getAd')->once()->andReturn((object)['id' => 3, 'status' => 'active', 'type' => 'seo', 'user_id' => 9]);

        $executions = m::mock(\App\Models\SeoExecution::class);
        $executions->shouldReceive('userHasExecutionForAd')->once()->with(2, 3, ['started', 'completed'])->andReturn(true);

        $reportService = $this->createMock(\App\Services\Interaction\ReportService::class);
        $reportService->method('submit')->willThrowException(new \PDOException(self::POISON));

        $logger = $this->createMock(\App\Contracts\LoggerInterface::class);

        $job = new ReportSeoTaskJob($ads, $reportService, $executions, $logger);
        $result = $job->handle(2, 3, 'other', 'توضیح');

        $this->assertFalse($result['success']);
        $this->assertSame('خطای سیستمی در ثبت گزارش. لطفاً دوباره تلاش کنید.', $result['message']);
        $this->assertStringNotContainsString('SQLSTATE', $result['message']);
        $this->assertStringNotContainsString('SECRET', $result['message']);
    }

    public function test_rate_job_returns_generic_message_not_exception_text(): void
    {
        $ads = m::mock(AdsSeoService::class);
        // 🛡️ FIX-SEO3-01: گیت‌های جدید — type=seo، مالک کمپین ≠ رأی‌دهنده، مجریِ completed
        $ads->shouldReceive('getAd')->once()->andReturn((object)['id' => 3, 'status' => 'active', 'type' => 'seo', 'user_id' => 9]);

        $executions = m::mock(\App\Models\SeoExecution::class);
        $executions->shouldReceive('userHasExecutionForAd')->once()->with(2, 3, ['completed'])->andReturn(true);

        $ratingService = $this->createMock(\App\Services\Interaction\RatingService::class);
        $ratingService->method('rate')->willThrowException(new \RuntimeException('DB user row missing user_id=99'));

        $logger = $this->createMock(\App\Contracts\LoggerInterface::class);

        $job = new RateSeoTaskJob($ads, $ratingService, $executions, $logger);
        $result = $job->handle(2, 3, 5, 'کامنت');

        $this->assertFalse($result['success']);
        $this->assertSame('خطای سیستمی در ثبت امتیاز. لطفاً دوباره تلاش کنید.', $result['message']);
        $this->assertStringNotContainsString('user_id=99', $result['message']);
        $this->assertStringNotContainsString('DB', $result['message']);
    }
}
