<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Contracts\LoggerInterface;
use App\Models\SocialTaskExecutionModel;
use App\Services\Settings\AppSettings;
use App\Services\SocialTask\BehaviorAnalysisService;
use App\Services\SocialTask\CameraVerificationService;
use App\Services\SocialTask\SocialTaskScoringService;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * F21-01 (بازبینی بخش ۲۱) — وریفایر واقعی دوربین: nonce یک‌بارمصرف + تحلیل آماری
 * سمت‌سرور (گزینهٔ C، تصمیم‌های D1-D3 مالک).
 *
 * پوشش (سه لایه؛ آزمون منفی برای score جعلی، frame ساختگی، replay، انقضا و
 * user/execution نامرتبط):
 *
 *  الف) گیت خروجی: effectiveCameraContribution / hasTrustedVerdict — فقط رکورد
 *      completed + nonce مصرف‌شده + server_verdict='pass' + frame_count>0؛ رکورد
 *      legacy/weak/fail و ادعای کلاینت = صفر؛ سقف ۱۵ از config.
 *  ب) پین سورس job: $hasVerifiableProof فقط از hasTrustedVerdict می‌آید؛
 *      هرگز از contribution/ادعای کلاینت؛ برچسب auto_approved_with_mobile_camera
 *      حذف‌شده می‌ماند (قانون ۶).
 *  ج) runtime روی MariaDB واقعی: getChallenge → processResult؛ replay، منقضی،
 *      کاربر نامرتبط، ویژگی‌های جعلیِ ثابت، نبود رضایت spot و retry.
 *
 * @group s21
 */
final class SocialTaskSection21CameraProofTest extends TestCase
{
    protected function tearDown(): void
    {
        // پاکسازی runtime (اگر تست‌های DB اجرا شده باشند) + بستن Mockery.
        foreach (array_reverse($this->created) as [$table, $id]) {
            try {
                $this->db()->query("DELETE FROM {$table} WHERE id = ?", [$id]);
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        $this->created = [];
        m::close();
        parent::tearDown();
    }

    // ───────────────────────── الف) گیت خروجی ─────────────────────────

    private function serviceWithModel(SocialTaskExecutionModel $model): CameraVerificationService
    {
        return new CameraVerificationService(
            m::mock(LoggerInterface::class)->shouldIgnoreMissing(),
            $model,
            m::mock(BehaviorAnalysisService::class),
            m::mock(SocialTaskScoringService::class),
            m::mock(AppSettings::class)
        );
    }

    private function completedRequest(
        int $frameCount,
        int $score,
        string $verdict = 'pass',
        ?string $consumedAt = '2026-10-24 10:00:00',
        ?string $spotStatus = null
    ): object {
        return (object)[
            'id' => 1, 'status' => 'completed', 'camera_score' => $score, 'server_score' => $score,
            'frame_count' => $frameCount, 'server_verdict' => $verdict,
            'nonce_consumed_at' => $consumedAt, 'spot_check_status' => $spotStatus,
        ];
    }

    /** @test */
    public function inline_claim_without_completed_server_record_counts_zero(): void
    {
        // «score جعلی» بدون فلوِ دوربین: هیچ رکورد server-created وجود ندارد.
        $model = m::mock(SocialTaskExecutionModel::class);
        $model->shouldReceive('getCameraRequest')->once()->with(10, ['completed'])->andReturn(null);

        $contribution = $this->serviceWithModel($model)->effectiveCameraContribution(10, 100);
        $this->assertSame(0.0, $contribution, 'ادعای inline کلاینت بدون رکورد سروری = صفر');
    }

    /** @test */
    public function legacy_completed_record_without_consumed_nonce_counts_zero(): void
    {
        // مسیر قدیمی (بدون nonce): حتی با verdict/score/frames بالا، اثبات نیست.
        $model = m::mock(SocialTaskExecutionModel::class);
        $model->shouldReceive('getCameraRequest')->once()->andReturn($this->completedRequest(4, 100, 'pass', null));

        $this->assertSame(0.0, $this->serviceWithModel($model)->effectiveCameraContribution(11, 100));
    }

    /** @test */
    public function weak_or_fail_verdict_counts_zero(): void
    {
        foreach (['weak', 'fail', ''] as $verdict) {
            $model = m::mock(SocialTaskExecutionModel::class);
            $model->shouldReceive('getCameraRequest')->once()->andReturn($this->completedRequest(4, 90, $verdict));
            $this->assertSame(
                0.0,
                $this->serviceWithModel($model)->effectiveCameraContribution(12, 90),
                "حکم '{$verdict}' اثبات نیست"
            );
        }
    }

    /** @test */
    public function completed_record_without_frames_counts_zero(): void
    {
        // «frame count ساختگی = صفر»: امتیازِ بدون هیچ فریمِ ثبت‌شده = صفر.
        $model = m::mock(SocialTaskExecutionModel::class);
        $model->shouldReceive('getCameraRequest')->once()->andReturn($this->completedRequest(0, 100));

        $this->assertSame(0.0, $this->serviceWithModel($model)->effectiveCameraContribution(13, 100));
    }

    /** @test */
    public function failed_spot_check_counts_zero(): void
    {
        $model = m::mock(SocialTaskExecutionModel::class);
        $model->shouldReceive('getCameraRequest')->once()->andReturn($this->completedRequest(4, 95, 'pass', '2026-10-24 10:00:00', 'fail'));

        $this->assertSame(0.0, $this->serviceWithModel($model)->effectiveCameraContribution(14, 95));
    }

    /** @test */
    public function trusted_pass_is_capped_at_fifteen_and_ignores_client_claim(): void
    {
        $model = m::mock(SocialTaskExecutionModel::class);
        $model->shouldReceive('getCameraRequest')->twice()->andReturn($this->completedRequest(4, 95));
        $service = $this->serviceWithModel($model);

        $this->assertTrue($service->hasTrustedVerdict(15));
        // ادعای کلاینت (حتی ۲۵۰ یا null) اثری ندارد؛ مبنا امتیاز ثبت‌شدهٔ سرور است.
        $this->assertSame(15.0, $service->effectiveCameraContribution(15, 250), 'min(95×0.30, 15) = 15');
    }

    /** @test */
    public function trusted_partial_server_score_scales_linearly(): void
    {
        $model = m::mock(SocialTaskExecutionModel::class);
        $model->shouldReceive('getCameraRequest')->once()->andReturn($this->completedRequest(4, 40));

        // ادعای کلاینت ۱۰۰ است ولی مبنا امتیاز سرور (۴۰) است: 40×0.30 = 12
        $this->assertSame(12.0, $this->serviceWithModel($model)->effectiveCameraContribution(16, 100));
    }

    // ───────────────────────── ب) پین سورس job ─────────────────────────

    /** @return array<string, mixed> */
    private function jobSource(): array
    {
        $path = dirname(__DIR__, 3) . '/app/Jobs/SocialTask/SubmitSocialTaskExecutionJob.php';
        $source = file_get_contents($path);
        $this->assertIsString($source);
        return ['source' => $source, 'path' => $path];
    }

    /** @test */
    public function proof_comes_only_from_trusted_server_verdict(): void
    {
        $src = $this->jobSource()['source'];

        // F21-01: «اثبات» فقط حکم trusted سروری است (گیتِ شاخهٔ approve بدون تغییر).
        $this->assertStringContainsString(
            '$hasVerifiableProof = $this->cameraVerification->hasTrustedVerdict($executionId);',
            $src
        );
        $this->assertStringContainsString('FIX-F21-01', $src);

        // تکلیف ثابت false و الگوی قدیمیِ contribution-کلاینتی نباید برگردند.
        $this->assertStringNotContainsString('$hasVerifiableProof = false;', $src);
        $this->assertStringNotContainsString(
            '$hasVerifiableProof = $cameraContribution > 0.0;',
            $src,
            'contribution دیگر proof نمی‌خرد؛ فقط hasTrustedVerdict'
        );
    }

    /** @test */
    public function high_score_without_proof_routes_to_manual_review_never_auto_release(): void
    {
        $src = $this->jobSource()['source'];

        // شاخهٔ auto-approve فقط بدون challenge و با proof باز می‌شود؛ با
        // FIX-S21-01 همیشه به بررسی دستی با pay_reward=false می‌رود.
        $this->assertStringContainsString('if ($fraudChallenge || !$hasVerifiableProof || $auditReason !== null) {', $src);
        $this->assertStringContainsString('passAuditReason(', $src);
        $this->assertStringContainsString("'manual_review_no_verifiable_proof'", $src);
        $this->assertStringContainsString("'pay_reward' => false,", $src);
    }

    /** @test */
    public function decision_labels_stay_honest_with_the_gate(): void
    {
        $src = $this->jobSource()['source'];

        // برچسب auto_approved دیگر از هیچ مسیر کلاینتی تولید نمی‌شود.
        $this->assertStringNotContainsString(
            'auto_approved_with_mobile_camera',
            $src,
            'برچسبِ auto_approved_with_mobile_camera هرگز تولید نمی‌شود (قانون ۶)'
        );
        // شاخه‌های رد/بررسی دستی سر جایشان‌اند.
        $this->assertStringContainsString("'auto_rejected_with_mobile_camera'", $src);
        $this->assertStringContainsString("'manual_review_with_mobile_camera'", $src);
    }

    /** @test */
    public function auto_approve_threshold_is_pinned_to_d4_value(): void
    {
        $src = $this->jobSource()['source'];

        // 🎯 D4 (تصمیم مالک ۲۰۲۶-۱۰-۲۶): آستانهٔ auto-approve ۷۰→۶۰ کاهش یافت تا
        // صف بررسی دستی کوچک شود؛ گیتِ اثبات سروری دست‌نخورده مانده (fail-closed).
        // این پین جلوی بازگشتِ خامِ مقدار را می‌گیرد (قانون ۷).
        $this->assertStringContainsString('AUTO_APPROVE_SCORE = 60.0', $src);
        $this->assertStringNotContainsString(
            'AUTO_APPROVE_SCORE = 70.0',
            $src,
            'آستانهٔ قدیمی ۷۰ نباید برگردد'
        );
    }

    // ─────────────── ج) runtime: fail-closed فلو دوربین (MariaDB واقعی) ───────────────

    private ?Database $db = null;
    /** @var list<array{0: string, 1: int}> */
    private array $created = [];

    private function db(): Database
    {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    private function track(string $table, int $id): void
    {
        $this->created[] = [$table, $id];
    }

    private function randomId(): int
    {
        return 2_100_000 + random_int(0, 800_000);
    }

    private function insertAdRow(int $advertiserId): int
    {
        $this->db()->query(
            "INSERT INTO ads (user_id, title, type, currency, total_budget, remaining_budget, spent_budget, status, created_at, updated_at)
             VALUES (?, ?, 'social_task', 'irt', '100000', '100000', '0', 'active', NOW(), NOW())",
            [$advertiserId, 's21-proof-' . bin2hex(random_bytes(4))]
        );
        $id = (int)$this->db()->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->track('ads', $id);
        return $id;
    }

    private function insertExecutionRow(int $adId, int $executorId): int
    {
        $this->db()->query(
            "INSERT INTO social_task_executions (ad_id, executor_id, status, created_at)
             VALUES (?, ?, 'in_progress', NOW())",
            [$adId, $executorId]
        );
        $id = (int)$this->db()->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->track('social_task_executions', $id);
        return $id;
    }

    /** تبلیغ + اجرا (صاحب = $userId)؛ خروجی execution id */
    private function seedExecution(int $userId): int
    {
        return $this->insertExecutionRow($this->insertAdRow($this->randomId()), $userId);
    }

    /** رکوردهای camera ساخته‌شده برای این execution را برای پاکسازی ثبت می‌کند */
    private function trackRequestsOf(int $executionId): void
    {
        $rows = $this->db()->query('SELECT id FROM social_camera_requests WHERE execution_id = ?', [$executionId])->fetchAll(\PDO::FETCH_OBJ);
        foreach ($rows as $r) {
            $id = (int)$r->id;
            if (!in_array(['social_camera_requests', $id], $this->created, true)) {
                $this->track('social_camera_requests', $id);
            }
        }
    }

    private function liveService(float $spotRatio = 0.0, ?int $spotMaxBytes = null): CameraVerificationService
    {
        $model = new SocialTaskExecutionModel($this->db());
        $scoring = m::mock(SocialTaskScoringService::class);
        $scoring->shouldReceive('calculateCameraContribution')->andReturnUsing(
            static fn (int $score, array $signals = []): int => $score
        );
        $settings = m::mock(AppSettings::class);
        // 🎯 D2-wiring (۲۰۲۶-۱۰-۲۶): کلید camera_spot_image_max_bytes هم قابل
        // override است تا سیم‌کشی تنظیم → قرارداد چالش → گارد oversize تست شود؛
        // بدون override همان $default (۶۱۴۴۰ = ثابت قرارداد) برمی‌گردد.
        $settings->shouldReceive('get')->andReturnUsing(
            static function (string $key, mixed $default = null) use ($spotRatio, $spotMaxBytes): mixed {
                if ($key === 'camera_spot_check_ratio') {
                    return $spotRatio;
                }
                if ($key === 'camera_spot_image_max_bytes' && $spotMaxBytes !== null) {
                    return $spotMaxBytes;
                }
                return $default;
            }
        );
        return new CameraVerificationService(
            m::mock(LoggerInterface::class)->shouldIgnoreMissing(),
            $model,
            m::mock(BehaviorAnalysisService::class),
            $scoring,
            $settings
        );
    }

    /** فریم‌های طبیعی: فواصل نامنظم، تنوع روشنایی، نویز سنسور ⇒ pass (امتیاز ۹۵) */
    /** @return list<array<string, int|float>> */
    private function naturalFrames(): array
    {
        return [
            ['t' => 0,    'lum' => 118.4, 'std' => 6.2, 'w' => 96, 'h' => 96],
            ['t' => 180,  'lum' => 121.9, 'std' => 6.5, 'w' => 96, 'h' => 96],
            ['t' => 600,  'lum' => 127.3, 'std' => 5.9, 'w' => 96, 'h' => 96],
            ['t' => 1070, 'lum' => 124.1, 'std' => 6.8, 'w' => 96, 'h' => 96],
        ];
    }

    /** فریم‌های اسکریپتیِ ثابت: بدون تنوع/نویز و فواصل مساوی ⇒ هرگز pass */
    /** @return list<array<string, int|float>> */
    private function fakeStaticFrames(): array
    {
        return [
            ['t' => 0,   'lum' => 100.0, 'std' => 0.0],
            ['t' => 500, 'lum' => 100.0, 'std' => 0.0],
            ['t' => 1000, 'lum' => 100.0, 'std' => 0.0],
            ['t' => 1500, 'lum' => 100.0, 'std' => 0.0],
        ];
    }

    /** @return array<string, mixed> */
    private function challenge(CameraVerificationService $service, int $exec, int $user, bool $consent = true): array
    {
        $c = $service->getChallenge($exec, $user, ['client_mode' => 'mobile_app'], $consent);
        $this->assertIsArray($c, 'چالش برای مالک اجرا باید صادر شود');
        $this->trackRequestsOf($exec);
        return $c;
    }

    /** @test */
    public function spot_max_bytes_setting_is_wired_into_challenge_contract_and_oversize_guard(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);

        // 🎯 D2-wiring (تصمیم مالک ۲۰۲۶-۱۰-۲۶): مقدار پنل (camera_spot_image_max_bytes)
        // باید واقعاً مصرف شود — قبلاً کلید در کاتالوک/DB بود اما کد ثابت هاردکد
        // 61440 را می‌خواند (تنظیم مرده). این آزمون هر سه خصلت را پین می‌کند:
        //  ۱) قرارداد چالش به کلاینت (spot_check.max_bytes) از تنظیمات می‌آید؛
        //  ۲) اعتبارسنجی سروری آپلود (oversize → حکم weak) از همان مقدار؛
        //  ۳) کلمپ ایمن ۲KB..۱MB و fallback ثابت قرارداد.
        $service = $this->liveService(1.0, 4096);
        $c = $this->challenge($service, $exec, $user, true);

        $this->assertTrue((bool)($c['spot_check']['required'] ?? false), 'نرخ ۱.۰ + رضایت = نمونه‌گیری قطعی');
        $this->assertSame(4096, (int)$c['spot_check']['max_bytes'], 'قرارداد چالش max_bytes از تنظیمات می‌آید (نه ثابت هاردکد)');

        $idx = (int)($c['spot_check']['indices'][0] ?? 1);
        $oversize = base64_encode("\xFF\xD8\xFF" . str_repeat('A', 4096)); // ۴۰۹۹ بایت > سقف ۴۰۹۶
        $r = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames(), [$idx => $oversize]);
        $this->assertTrue($r['success'], 'فریم‌های طبیعی + spot oversize = رد نشدنی نیست، فقط تنزل حکم');
        $this->assertSame('weak', $r['verdict'], 'تصویر بزرگ‌تر از سقفِ تنظیمی → حکم weak (هرگز pass)');
        $this->assertContains('spot_oversize_' . $idx, array_map('strval', (array)($r['findings'] ?? [])), 'کد یافتهٔ oversize با ایندکس فریم ثبت شد');
        $this->assertFalse($service->hasTrustedVerdict($exec), 'حکم weak = بدون اثبات (fail-closed)');

        // کلمپ ایمن: مقدار بی‌منطق کوچک (۱۰۰) → حداقل ۲KB
        $clamped = $this->liveService(1.0, 100);
        $cc = $this->challenge($clamped, $exec, $user, true);
        $this->assertSame(2048, (int)$cc['spot_check']['max_bytes'], 'کلمپ پایین: ۱۰۰ → ۲۰۴۸');

        // fallback: بدون مقدار در تنظیمات → ثابت قرارداد ۶۰KB
        $fallback = $this->liveService(1.0);
        $cf = $this->challenge($fallback, $exec, $user, true);
        $this->assertSame(61440, (int)$cf['spot_check']['max_bytes'], 'fallback = ثابت قرارداد (۶۰KB)');
    }

    /** @test */
    public function challenge_stores_only_hash_and_is_refused_for_non_owner(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();

        $this->assertNull($service->getChallenge($exec, $this->randomId(), [], true), 'اجرای دیگران: چالش صادر نمی‌شود');

        $c = $this->challenge($service, $exec, $user);
        $this->assertSame(64, strlen((string)$c['nonce']));
        $row = $this->db()->fetch('SELECT * FROM social_camera_requests WHERE id = ?', [(int)$c['camera_request_id']]);
        $this->assertSame(hash('sha256', (string)$c['nonce']), (string)$row->nonce_hash, 'فقط هش ذخیره می‌شود');
        $this->assertFalse(property_exists($row, 'nonce'), 'ستون nonce خام نباید وجود داشته باشد');
    }

    /** @test */
    public function natural_capture_with_consent_passes_and_opens_the_gate(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();
        $c = $this->challenge($service, $exec, $user);

        $r = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames());
        $this->assertTrue($r['success'], 'capture طبیعی پذیرفته می‌شود');
        $this->assertSame('pass', $r['verdict']);
        $this->assertTrue($service->hasTrustedVerdict($exec), 'حکم trusted = اثبات');
        $this->assertSame(15.0, $service->effectiveCameraContribution($exec, null), 'سقف config');
    }

    /** @test */
    public function replay_is_rejected_after_nonce_is_consumed(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();
        $c = $this->challenge($service, $exec, $user);

        $first = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames());
        $this->assertTrue($first['success']);

        $replay = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames(), [], [], [], ['camera_score' => 100]);
        $this->assertFalse($replay['success'], 'replay همان nonce رد می‌شود');
        $this->assertSame('CAMERA_STALE_OR_REPLAYED', $replay['error_code']);

        $row = $this->db()->fetch('SELECT server_score, server_verdict FROM social_camera_requests WHERE id = ?', [(int)$c['camera_request_id']]);
        $this->assertSame('pass', (string)$row->server_verdict, 'نتیجهٔ اول بازنویسی نشد');
    }

    /** @test */
    public function expired_challenge_is_rejected(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();
        $c = $this->challenge($service, $exec, $user);

        $this->db()->query(
            'UPDATE social_camera_requests SET expires_at = DATE_SUB(NOW(), INTERVAL 1 SECOND) WHERE id = ?',
            [(int)$c['camera_request_id']]
        );

        $r = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames());
        $this->assertFalse($r['success'], 'چالش منقضی: fail-closed');
        $this->assertFalse($service->hasTrustedVerdict($exec));
    }

    /** @test */
    public function unrelated_user_or_execution_cannot_consume_the_nonce(): void
    {
        $owner = $this->randomId();
        $attacker = $this->randomId();
        $exec = $this->seedExecution($owner);
        $otherExec = $this->seedExecution($owner);
        $service = $this->liveService();
        $c = $this->challenge($service, $exec, $owner);

        $asAttacker = $service->processResult($exec, $attacker, (string)$c['nonce'], $this->naturalFrames());
        $this->assertFalse($asAttacker['success'], 'user نامرتبط رد می‌شود');
        $wrongExec = $service->processResult($otherExec, $owner, (string)$c['nonce'], $this->naturalFrames());
        $this->assertFalse($wrongExec['success'], 'execution نامرتبط رد می‌شود');
        $this->assertFalse($service->hasTrustedVerdict($exec));

        // مالک واقعی هنوز می‌تواند مصرف کند (رد کاربر اشتباه nonce را نسوزاند)
        $ok = $service->processResult($exec, $owner, (string)$c['nonce'], $this->naturalFrames());
        $this->assertTrue($ok['success']);
    }

    /** @test */
    public function forged_static_features_and_claimed_score_never_pass(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();
        $c = $this->challenge($service, $exec, $user);

        // سناریوی زندهٔ گزارش: امتیاز جعلی ۱۰۰ + فریم‌های ساختگی
        $r = $service->processResult(
            $exec, $user, (string)$c['nonce'], $this->fakeStaticFrames(), [], [], [],
            ['camera_score' => 100, 'frame_count' => 10]
        );
        $this->assertTrue($r['success'], 'حکم منفی ثبت می‌شود');
        $this->assertNotSame('pass', $r['verdict'], 'ویژگی‌های ثابت/جعلی هرگز pass نمی‌گیرند');
        $this->assertFalse($service->hasTrustedVerdict($exec));
        $this->assertSame(0.0, $service->effectiveCameraContribution($exec, 100));
    }

    /** @test */
    public function malformed_or_too_few_frames_do_not_burn_the_nonce(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();
        $c = $this->challenge($service, $exec, $user);

        $bad = $service->processResult($exec, $user, (string)$c['nonce'], [['t' => 0, 'lum' => 999]]);
        $this->assertFalse($bad['success']);
        $this->assertSame('malformed_frames', $bad['error_code']);

        $ok = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames());
        $this->assertTrue($ok['success'], 'خطای قالب، nonce را مصرف نکرده است');
    }

    /** @test */
    public function no_spot_consent_caps_verdict_at_weak(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();
        $c = $this->challenge($service, $exec, $user, false);
        $this->assertFalse($c['spot_check']['required']);

        $r = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames());
        $this->assertTrue($r['success']);
        $this->assertSame('weak', $r['verdict'], 'بدون رضایت: هرگز pass');
        $this->assertFalse($service->hasTrustedVerdict($exec));
    }

    /** @test */
    public function required_spot_image_missing_caps_verdict_at_weak(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService(1.0); // همهٔ چالش‌ها نمونه‌گیری می‌شوند
        $c = $this->challenge($service, $exec, $user, true);
        $this->assertTrue($c['spot_check']['required']);

        $r = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames());
        $this->assertTrue($r['success']);
        $this->assertSame('weak', $r['verdict'], 'نبود تصویر spot = سقف weak');
        $this->assertFalse($service->hasTrustedVerdict($exec));
    }

    /** @test */
    public function new_challenge_invalidates_the_previous_one(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();
        $first = $this->challenge($service, $exec, $user);
        $second = $this->challenge($service, $exec, $user);
        $this->assertNotSame($first['nonce'], $second['nonce']);

        $old = $service->processResult($exec, $user, (string)$first['nonce'], $this->naturalFrames());
        $this->assertFalse($old['success'], 'nonce چالش قدیمی پس از چالش جدید بی‌اعتبار است');
        $new = $service->processResult($exec, $user, (string)$second['nonce'], $this->naturalFrames());
        $this->assertTrue($new['success']);
    }

    /** @test */
    public function requests_created_without_nonce_do_not_collide(): void
    {
        // رگرسیون: nonce_hash خالی باید NULL باشد، نه '' (ایندکس یکتا)
        $a = $this->randomId();
        $b = $this->randomId();
        $execA = $this->seedExecution($a);
        $execB = $this->seedExecution($b);
        $service = $this->liveService();

        $service->createRequest($execA, $a);
        $service->createRequest($execB, $b);
        $this->trackRequestsOf($execA);
        $this->trackRequestsOf($execB);
        $this->addToAssertionCount(1);
    }

    // ───────── بازبینی وریفایر دوربین ۲۰۲۶-۱۰-۲۶: semantics ادغام بیکن‌ها ─────────
    // FIX-CAMERA-E2E-BEACON — کلاینت مرجع (usersocialtasksexecute.js) در هر بیکن
    // «اسنپشات تجمعی» می‌فرستد؛ ادغامِ جمعیِ قبلی مقدارها را ×تعداد-بیکن باد می‌کرد
    // و farm_exact_timing (ماشهٔ camera_required) را برای کلاینت واقعی از کار
    // می‌انداخت. این دو آزمون semantics اسنپشات (سازگار با array_merge مسیر submit)
    // را در هر دو لایه (واحد + مسیر کامل روی DB واقعی) پین می‌کنند.

    /** @test */
    public function beacon_snapshot_merge_replaces_instead_of_accumulating(): void
    {
        $service = $this->socialTaskServiceForBehavior();

        $merge = static function (array $prev, array $new) use ($service): array {
            $ref = new \ReflectionMethod($service, 'mergeBehaviorSignals');
            $ref->setAccessible(true);
            return $ref->invoke($service, $prev, $new);
        };

        // بیکن ۱ (ثانیهٔ ۴): snapshot واقعی کلاینت
        $state = $merge([], [
            'session_duration' => 4, 'active_time' => 4, 'tap_count' => 0,
            'scroll_count' => 1, 'hesitation_count' => 1, 'touch_timing_variance' => 999,
        ]);
        // بیکن ۲ (ثانیهٔ ۲۰) و بیکن ۳ (ثانیهٔ ۴۴): اسنپشات‌های بعدی همان جلسه
        $state = $merge($state, [
            'session_duration' => 20, 'active_time' => 20, 'tap_count' => 0,
            'scroll_count' => 1, 'hesitation_count' => 1, 'touch_timing_variance' => 999,
        ]);
        $state = $merge($state, [
            'session_duration' => 44, 'active_time' => 44, 'tap_count' => 2,
            'scroll_count' => 1, 'hesitation_count' => 1, 'touch_timing_variance' => 999,
        ]);

        // snapshot نهایی باید بدون تورمِ ×۳ باشد (جمعیِ قبلی: ۶۸/۸۲ و scroll=۳)
        $this->assertSame(44, (int)$state['session_duration'], 'session_duration = آخرین اسنپشات (نه ۴+۲۰+۴۴)');
        $this->assertSame(44, (int)$state['active_time'], 'active_time = آخرین اسنپشات (نه جمع بیکن‌ها)');
        $this->assertSame(2, (int)$state['tap_count'], 'tap_count = آخرین اسنپشات');
        $this->assertSame(1, (int)$state['scroll_count'], 'scroll_count = آخرین اسنپشات (نه ۱+۱+۱ = false-positive farm_linear_scroll)');
        $this->assertSame(1, (int)$state['hesitation_count'], 'hesitation_count = آخرین اسنپشات (نه ۳ = false-positive human_hesitation که دوربین را خاموش می‌کند)');

        // سقف ضد-پمپاژ روی مقدار ورودی همچنان برقرار است
        $capped = $merge([], ['session_duration' => 100000, 'tap_count' => 100000]);
        $this->assertSame(600, (int)$capped['session_duration'], 'سقف BEHAVIOR_SIGNAL_CALL_CAPS روی session_duration');
        $this->assertSame(500, (int)$capped['tap_count'], 'سقف BEHAVIOR_SIGNAL_CALL_CAPS روی tap_count');
    }

    /** @test */
    public function record_behavior_beacons_keep_snapshot_semantics_on_real_db(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->socialTaskServiceForBehavior();

        $beacon = static fn (int $sec) => [
            'session_duration' => $sec, 'active_time' => $sec, 'tap_count' => 0,
            'swipe_count' => 0, 'scroll_count' => 1, 'touch_pauses' => 0,
            'touch_timing_variance' => 999, 'scroll_speed_variance' => 999, 'scroll_pauses' => 0,
            'reconnect_count' => 0, 'app_blur_count' => 0, 'max_blur_duration' => 0,
            'hesitation_count' => 1, 'avg_action_delay_ms' => 0, 'natural_delay_count' => 1,
            'is_mobile' => 1, 'client_mode' => 'web', 'client_version' => '',
        ];

        // سه بیکن واقعیِ کلاینت مرجع: ثانیهٔ ۴، ۲۰ و ۴۴
        $this->assertTrue($service->recordBehaviorSignals($exec, $user, $beacon(4)));
        $this->assertTrue($service->recordBehaviorSignals($exec, $user, $beacon(20)));
        $this->assertTrue($service->recordBehaviorSignals($exec, $user, $beacon(44)));

        $row = $this->db()->fetch('SELECT behavior_data FROM social_task_executions WHERE id = ?', [$exec]);
        $data = (array)(json_decode((string)$row->behavior_data, true) ?? []);

        $this->assertSame(44, (int)$data['session_duration'], 'پس از ۳ بیکن، session_duration = آخرین اسنپشات (۴۴) — نه ۶۸');
        $this->assertSame(1, (int)$data['scroll_count'], 'scroll_count تورم نمی‌گیرد');
        $this->assertSame(3, (int)($data['_call_count'] ?? 0), '_call_count همچنان تعداد بیکن‌ها را می‌شمارد');
    }

    // ───────── چرخهٔ اصلاحی 2026-10-28 (رفع یافته‌های 17-RV) — سناریو ۱۰ + دو پین ─────────

    /**
     * سناریوی دهم (FIX-TERMINAL-GUARD): صدور چالش برای اجرای پایانی ممنوع.
     * وضعیت‌های ترمینال = همان چهار حالت خالی STATE_TRANSITIONS.
     * @test
     */
    public function terminal_execution_cannot_get_a_challenge(): void
    {
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService();

        foreach (['approved', 'cancelled'] as $terminal) {
            $this->db()->query(
                'UPDATE social_task_executions SET status = ? WHERE id = ?',
                [$terminal, $exec]
            );
            $this->assertNull(
                $service->getChallenge($exec, $user, ['client_mode' => 'mobile_app'], true),
                "اجرای {$terminal} نباید چالش جدید بگیرد"
            );
            $this->assertSame(
                0,
                (int)$this->db()->fetchColumn('SELECT COUNT(*) FROM social_camera_requests WHERE execution_id = ?', [$exec]),
                "برای اجرای {$terminal} نباید رکورد چالشی ساخته شود"
            );
        }
    }

    /**
     * FIX-CAM-VERIFIED-GATE: camera_verified=1 فقط برای حکم pass سرور.
     * weak → پرچم ۰ + camera_verdict='weak'؛ pass → پرچم ۱ + camera_verdict='pass'.
     * (قبلاً هر حکمی پرچم را ۱ می‌کرد و evaluator تا +۸ بونوس از weak می‌گرفت.)
     * @test
     */
    public function weak_verdict_does_not_set_camera_verified_but_pass_does(): void
    {
        // weak: چالشِ spot-دار (ratio=1، رضایت بله) ولی بدون spot_images → capWeak
        $user = $this->randomId();
        $exec = $this->seedExecution($user);
        $service = $this->liveService(1.0);
        $c = $this->challenge($service, $exec, $user); // consent=true + ratio=1 → spot required
        $this->assertTrue((bool)($c['spot_check']['required'] ?? false), 'precondition: spot required');

        $r = $service->processResult($exec, $user, (string)$c['nonce'], $this->naturalFrames());
        $this->assertTrue($r['success']);
        $this->assertSame('weak', $r['verdict'], 'precondition: بدون spot_images حکم weak است');

        $row = $this->db()->fetch('SELECT behavior_data FROM social_task_executions WHERE id = ?', [$exec]);
        $behavior = (array)json_decode((string)$row->behavior_data, true);
        $this->assertSame(0, (int)($behavior['camera_verified'] ?? -1), 'weak → camera_verified=0');
        $this->assertSame('weak', (string)($behavior['camera_verdict'] ?? ''), 'weak → camera_verdict ثبت شد');
        $this->assertGreaterThan(0, (int)($behavior['camera_score'] ?? 0), 'امتیاز سرور ثبت می‌شود');

        // pass: همان اجرا با چالش تازه و capture طبیعی (ratio=0 → بدون spot)
        $service2 = $this->liveService(0.0);
        $c2 = $service2->getChallenge($exec, $user, ['client_mode' => 'mobile_app'], true);
        $this->trackRequestsOf($exec);
        $this->assertIsArray($c2);
        $r2 = $service2->processResult($exec, $user, (string)$c2['nonce'], $this->naturalFrames());
        $this->assertSame('pass', $r2['verdict'], 'precondition: capture طبیعی pass');

        $row2 = $this->db()->fetch('SELECT behavior_data FROM social_task_executions WHERE id = ?', [$exec]);
        $behavior2 = (array)json_decode((string)$row2->behavior_data, true);
        $this->assertSame(1, (int)($behavior2['camera_verified'] ?? -1), 'pass → camera_verified=1');
        $this->assertSame('pass', (string)($behavior2['camera_verdict'] ?? ''), 'pass → camera_verdict=pass');
    }

    /**
     * FIX-BOMB-PRECHECK: ابعاد از هدر خوانده می‌شود و تصویر خارج از bounds
     * قرارداد (SPOT_MIN_DIM=16..SPOT_MAX_DIM=2048) بدون decode رد می‌شود.
     * @test
     */
    public function oversize_dimension_jpeg_is_rejected_before_decode(): void
    {
        $analysis = new \App\Services\SocialTask\CaptureAnalysisService();
        $this->assertTrue(function_exists('getimagesizefromstring'), 'precondition: header reader exists');
        $this->assertTrue(function_exists('imagecreatefromstring'), 'precondition: GD exists');

        $makeJpeg = static function (int $w, int $h): string {
            // palette (1 byte/px) نه truecolor — همان هدرِ واقعی JPEG با ~۵ برابر
            // حافظهٔ کمتر؛ سوییت runtime با memory_limit=128M باید کامل شود.
            $img = @imagecreate(max(1, $w), max(1, $h));
            \assert($img !== false);
            \assert(@imagecolorallocate($img, 96, 96, 96) >= 0);
            ob_start();
            \assert(@imagejpeg($img, null, 20));
            $bin = (string)ob_get_clean();
            imagedestroy($img);
            return $bin;
        };

        // بمبِ ابعاد: هدر 3000×3000 (خارج از سقف 2048) — باید بدون decode رد شود
        $bomb = $makeJpeg(3000, 3000);
        $r = $analysis->analyzeSpotImage($bomb, null);
        $this->assertSame('unreadable', $r['result'], 'تصویر 3000×3000 بدون decode رد می‌شود');
        $this->assertSame(3000, $r['width'], 'عرض از هدر ثبت شد');
        $this->assertSame(3000, $r['height'], 'ارتفاع از هدر ثبت شد');

        // خردتر از حداقل: 8×8 < SPOT_MIN_DIM=16
        $tiny = $makeJpeg(8, 8);
        $r2 = $analysis->analyzeSpotImage($tiny, null);
        $this->assertSame('unreadable', $r2['result'], 'تصویر 8×8 بدون decode رد می‌شود');
        $this->assertSame(8, $r2['width']);

        // در-bounds: 96×96 از گیت ابعاد عبور می‌کند (نتیجه از تحلیل آماری می‌آید، نه از گیت)
        $okImg = $makeJpeg(96, 96);
        $r3 = $analysis->analyzeSpotImage($okImg, null);
        $this->assertNotSame('unreadable', $r3['result'], 'تصویر 96×96 در-bounds از گیت ابعاد رد نمی‌شود');
    }

    /** ساخت SocialTaskService فقط برای مسیر recordBehaviorSignals (بقیهٔ DI ماک) */
    private function socialTaskServiceForBehavior(): \App\Services\SocialTask\SocialTaskService
    {
        $db = $this->db();
        $model = new \App\Models\SocialTaskModel(
            $db,
            new SocialTaskExecutionModel($db),
            m::mock(\App\Models\SocialTaskAnalyticsModel::class)->shouldIgnoreMissing()
        );
        return new \App\Services\SocialTask\SocialTaskService(
            m::mock(LoggerInterface::class)->shouldIgnoreMissing(),
            $model,
            m::mock(\App\Services\Gamification\TrustService::class),
            m::mock(\App\Services\SocialTask\SilentAntiFraudService::class),
            m::mock(\App\Services\User\UserService::class),
            m::mock(\App\Services\SocialAccountService::class),
            m::mock(\App\Services\Interaction\RatingService::class),
            m::mock(\App\Services\ScoreService::class),
            m::mock(\App\Services\Shared\IdempotencyService::class),
            m::mock(\Core\Container::class),
            m::mock(\App\Services\Ads\AdsBudgetSettlementService::class),
            m::mock(\App\Services\AdSystemManager::class)
        );
    }
}
