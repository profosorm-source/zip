<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Jobs\Auth\OAuthHelperTrait;
use App\Services\Shared\IdempotencyKeys;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * S17 — قفل‌کنندهٔ امنیتی لایهٔ Jobs/Listeners/Events (۱۷۶ فایل، خط‌به‌خط).
 *
 * پین‌کردن فیکس‌های بچ S17:
 *  ① FIX-S17-1 — CreateTradeJob دیگر کلید HMAC هاردکد
 *                 («کلید ترید هاردکد» — CWE-798) ندارد و
 *                 «امضای اثبات» بی‌وریفایر تولید نمی‌کند؛ reason فقط
 *                 notes + created_by_admin_id است.
 *  ② FIX-S17-2 — OAuthHelperTrait::linkOrCreateUser اتصال خودکارِ ایمیلی به
 *                 کاربرِ موجود فقط با attestation مالکیت ایمیل از ارائه‌دهنده
 *                 (email_verified=true) انجام می‌شود؛ بدون فلگ = fail-closed
 *                 مگر oauth.auto_link_unverified_email صریحاً true باشد.
 *  ③ دوکتورین «یک عملیات = یک کلید idempotency» در مسیرهای پولی listener/job
 *     پین می‌شود (socialTaskReward/storyRefund/customTaskReward).
 *
 * سبک خانه: Database/Session با Mockery مک می‌شود (بدون DB و بدون session واقعی).
 */
final class S17JobsListenersSecurityPinningTest extends TestCase
{
    /** ریشهٔ پروژه — بدون وابستگی به BASE_PATH (در testing bootstrap تعریف نشده) */
    private const ROOT = __DIR__ . '/../../..';
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    // ─────────────────────────────────────────────────────────────────────
    // FIX-S17-1 — حذف کلید هاردکد HMAC در CreateTradeJob
    // ─────────────────────────────────────────────────────────────────────

    public function testCreateTradeJobHasNoHardcodedHmacSecret(): void
    {
        $file = self::ROOT . '/app/Jobs/Investment/CreateTradeJob.php';
        $src = (string)file_get_contents($file);

        // کلید هاردکد هرگز نباید به سورس برگردد
        $this->assertStringNotContainsString(
            'chortke_secure_trade_hash_key_2026',
            $src,
            'کلید HMAC هاردکد (CWE-798) باید حذف شده باشد'
        );

        // هیچ «امضای اثبات» بی‌وریفایری نباید تولید شود (hash_hmac در این فایل معنایی نداشت)
        $this->assertStringNotContainsString(
            'hash_hmac',
            $src,
            'امضای بی‌وریفایر = security theater؛ باید حذف شده باشد'
        );

        // و کل کدبیس Jobs هیچ وریفایری برای proof.signature نداشت — تثبیت می‌شود که خالی است
        $this->assertSame(
            [],
            $this->grepJobFilesForSecret(),
            'هیچ فایلی در app/Jobs نباید کلید هاردکد trade_hash را داشته باشد'
        );
    }

    /** @return list<string> */
    private function grepJobFilesForSecret(): array
    {
        $hits = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator(self::ROOT . '/app/Jobs')
        );
        /** @var \SplFileInfo $fileInfo */
        foreach ($iterator as $fileInfo) {
            if ($fileInfo->getExtension() !== 'php') {
                continue;
            }
            $content = (string)file_get_contents($fileInfo->getPathname());
            if (str_contains($content, 'chortke_secure_trade_hash_key_2026')) {
                $hits[] = $fileInfo->getPathname();
            }
        }
        return $hits;
    }

    public function testCreateTradeJobReasonPayloadPinsAdminAndNotes(): void
    {
        /** @var \App\Models\TradingRecord&\Mockery\MockInterface $trading */
        $trading = m::mock(\App\Models\TradingRecord::class);
        /** @var \App\Contracts\LoggerInterface&\Mockery\MockInterface $logger */
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        /** @var \App\Services\AuditTrail&\Mockery\MockInterface $audit */
        $audit = m::mock(\App\Services\AuditTrail::class);

        /** @var array<string, mixed> $capturedCreate */
        $capturedCreate = [];
        $createRef = &$capturedCreate;

        $trading->shouldReceive('create')
            ->once()
            ->with(m::on(function (array $payload) use (&$createRef): bool {
                $createRef = $payload;
                return true;
            }))
            ->andReturn(501);

        $audit->shouldReceive('record')->once()->andReturnUsing(static function () {
            return true;
        });
        $logger->shouldReceive('info')->once();

        $job = new \App\Jobs\Investment\CreateTradeJob($trading, $logger, $audit);

        $result = $job->handle(7, [
            'direction' => 'buy',
            'open_price' => '42000.5',
            'pair' => 'BTC/USDT',
            'lot_size' => '0.25',
            'notes' => 'پوزیشن آموزشی',
        ]);

        $this->assertTrue($result['success'] ?? false, 'ثبت ترید باید موفق باشد');
        $this->assertSame(501, $result['trade_id'] ?? null);

        $reason = json_decode((string)($createRef['reason'] ?? 'null'), true);
        $this->assertIsArray($reason, 'reason باید JSON معتبر باشد');
        $this->assertSame(7, $reason['created_by_admin_id'] ?? null, 'ادمین ثبت‌کننده باید در reason پین شود');
        $this->assertSame('پوزیشن آموزشی', $reason['notes'] ?? null);
        $this->assertArrayNotHasKey('proof', $reason, 'بلوک proof.signature باید حذف شده باشد');
    }

    // ─────────────────────────────────────────────────────────────────────
    // FIX-S17-2 — گیت attestation ایمیل در اتصال خودکار OAuth
    // ─────────────────────────────────────────────────────────────────────

    /**
     * هارنسِ ترِیت: همهٔ وابستگی‌های خصوصی linkOrCreateUser مک می‌شوند.
     * Session singleton واقعی با مک جایگزین می‌شود (بدون session_start).
     */
    private function makeTraitHarness(
        object $db,
        object $userModel,
        object $logger,
        object $authService
    ): object {
        $harness = new class($db, $userModel, $logger, $authService) {
            use OAuthHelperTrait;

            public function __construct(object $db, object $userModel, object $logger, object $authService)
            {
                // پراپرتی‌های ترِیت پس از flatten، پراپرتی کلاس‌اند؛
                // تزریق از درون کلاس بدون Reflection انجام می‌شود.
                $this->db = $db;
                $this->userModel = $userModel;
                $this->logger = $logger;
                $this->authService = $authService;
            }

            public function run(string $provider, array $userData): array
            {
                return $this->linkOrCreateUser($provider, $userData);
            }
        };

        return $harness;
    }

    /** Session::getInstance را با مک جایگزین می‌کند و OAUTH_LINKING_USER_ID را null برمی‌گرداند */
    private function mockSession(): void
    {
        $session = m::mock(\Core\Session::class);
        $session->shouldReceive('get')->andReturn(null)->byDefault();
        $session->shouldReceive('remove')->byDefault();
        // FIX-C96: قرارداد خواندنِ یک‌بارمصرف اکنون Session::once() است —
        // مک باید همین متد را هم بشناسد (null = هیچ نیتِ linking‌ای در نشست نیست).
        $session->shouldReceive('once')->andReturn(null)->byDefault();

        $ref = new \ReflectionProperty(\Core\Session::class, 'instance');
        $ref->setAccessible(true);
        $ref->setValue(null, $session);
    }

    private function restoreSession(): void
    {
        $ref = new \ReflectionProperty(\Core\Session::class, 'instance');
        $ref->setAccessible(true);
        $ref->setValue(null, null);
    }

    /** @return array{db: \Mockery\MockInterface, userModel: \Mockery\MockInterface, logger: \Mockery\MockInterface, authService: \Mockery\MockInterface, builder: \Mockery\MockInterface} */
    private function makeOAuthMocks(object $existingUser): array
    {
        $builder = m::mock(\Core\QueryBuilder::class);
        $builder->shouldReceive('where')->andReturnSelf()->byDefault();
        $builder->shouldReceive('first')->andReturn(null)->byDefault(); // social account هنوز لینک نشده

        /** @var \Mockery\MockInterface $db */
        $db = m::mock('Core\Database');
        $db->shouldReceive('table')->with('social_accounts')->andReturn($builder)->byDefault();

        /** @var \Mockery\MockInterface $userModel */
        $userModel = m::mock('App\Models\User');
        $userModel->shouldReceive('findByEmail')->andReturn($existingUser)->once();

        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        $authService = m::mock('App\Services\Auth\AuthService');

        return ['db' => $db, 'userModel' => $userModel, 'logger' => $logger, 'authService' => $authService, 'builder' => $builder];
    }

    public function testOauthEmailAutolinkBlockedWithoutProviderAttestation(): void
    {
        $this->mockSession();

        try {
            $existingUser = (object)['id' => 42, 'email' => 'victim@example.com'];
            $mocks = $this->makeOAuthMocks($existingUser);

            $harness = $this->makeTraitHarness($mocks['db'], $mocks['userModel'], $mocks['logger'], $mocks['authService']);

            // Facebook هیچ email_verified فلگی نمی‌دهد → باید fail-closed باشد
            $result = $harness->run('facebook', [
                'id' => 'fb_attacker_1',
                'email' => 'victim@example.com',
                'name' => 'Attacker',
            ]);

            $this->assertFalse($result['success'] ?? true, 'اتصال خودکار بدون attestation باید رد شود');
            // به‌روزرسانی پین پیام (FIX-S17-5 — بازنویسی پیام در بچ بعدی):
            // پیام قطعیِ S17-5 بدون واژهٔ «تأییدنشده» است ولی همان مسیر fail-closed
            // و همان توصیه (ورود با رمز / تأیید نزد ارائه‌دهنده) را می‌دهد.
            $this->assertStringContainsString('ورود خودکار با این ایمیل ممکن نیست', (string)($result['message'] ?? ''));

            $mocks['authService']->shouldNotHaveReceived('loginDirectly');
            $mocks['builder']->shouldNotHaveReceived('insert');
        } finally {
            $this->restoreSession();
        }
    }

    public function testOauthEmailAutolinkAllowedWithProviderAttestation(): void
    {
        $this->mockSession();

        try {
            $existingUser = (object)['id' => 42, 'email' => 'user@example.com'];
            $mocks = $this->makeOAuthMocks($existingUser);

            // Google با ID Token مالکیت ایمیل را attest می‌کند
            $mocks['builder']->shouldReceive('insert')->once()->andReturn(true);
            $mocks['authService']->shouldReceive('loginDirectly')
                ->once()
                ->with(m::on(static fn($u) => is_object($u) && (int)$u->id === 42))
                ->andReturn(['success' => true, 'user' => $existingUser]);

            $harness = $this->makeTraitHarness($mocks['db'], $mocks['userModel'], $mocks['logger'], $mocks['authService']);

            $result = $harness->run('google', [
                'id' => 'google_sub_1',
                'email' => 'user@example.com',
                'name' => 'User',
                'email_verified' => true,
            ]);

            $this->assertTrue($result['success'] ?? false, 'اتصال با attestation معتبر باید موفق باشد');
        } finally {
            $this->restoreSession();
        }
    }

    /**
     * به‌روزرسانی پین (FIX-S17-5 — سخت‌سازی بعدی): حتی hatch پیکربندی‌شده هم
     * مسیرِ اتصال خودکار بدون attestation را باز نمی‌کند — قرارداد نهایی
     * fail-closed مطلق است (مسیر مشروع: ورود با رمز یا لینک از تنظیماتِ
     * کاربرِ لاگین‌شده). این تست حالا «حذفِ کاملِ hatch» را پین می‌کند.
     */
    public function testOauthEmailAutolinkEscapeHatchRequiresExplicitConfig(): void
    {
        $this->mockSession();
        config_set('oauth.auto_link_unverified_email', true);

        try {
            $existingUser = (object)['id' => 42, 'email' => 'user@example.com'];
            $mocks = $this->makeOAuthMocks($existingUser);

            $mocks['authService']->shouldNotHaveReceived('loginDirectly');
            $mocks['builder']->shouldNotHaveReceived('insert');

            $harness = $this->makeTraitHarness($mocks['db'], $mocks['userModel'], $mocks['logger'], $mocks['authService']);

            $result = $harness->run('facebook', [
                'id' => 'fb_1',
                'email' => 'user@example.com',
                'name' => 'User',
            ]);

            // حتی با hatch=true مسیر باید بسته بماند (S17-5: fail-closed مطلق)
            $this->assertFalse($result['success'] ?? true, 'S17-5: hatch نباید دیگر مسیر را باز کند');
            $mocks['authService']->shouldNotHaveReceived('loginDirectly');
        } finally {
            config_set('oauth.auto_link_unverified_email', false);
            $this->restoreSession();
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // دوکتورین «یک عملیات = یک کلید» — پین ساختاری مسیرهای پولی
    // ─────────────────────────────────────────────────────────────────────

    public function testMoneyPathsUseCanonicalIdempotencyKeys(): void
    {
        // الفبای رسمی کلیدها
        $this->assertSame('social_task_reward_11', IdempotencyKeys::socialTaskReward(11));
        $this->assertSame('story_refund_22', IdempotencyKeys::storyRefund(22));
        $this->assertSame('custom_task_reward_33', IdempotencyKeys::customTaskReward(33));

        // مصرف‌کنندگان باید از همان الفبا استفاده کنند (پین منبع؛ دوباره‌گشایی P0-19/P0-20 را می‌شکند)
        $listener = (string)file_get_contents(self::ROOT . '/app/Listeners/SocialTaskEventListeners.php');
        $this->assertStringContainsString('IdempotencyKeys::socialTaskReward', $listener);

        $influencer = (string)file_get_contents(self::ROOT . '/app/Listeners/InfluencerEventListeners.php');
        $this->assertStringContainsString('IdempotencyKeys::storyRefund', $influencer);

        // 🧹 FIX-T22-19 (بچ FIX-M22-MED): جابِ پاداش تسک سفارشی حذف شد؛ مصرف‌کنندهٔ
        // زندهٔ همین کلید اکنون موتور Moderation است (settleCustomTaskReward → partialRelease).
        $moderation = (string)file_get_contents(self::ROOT . '/app/Services/CustomTask/CustomTaskModerationService.php');
        $this->assertStringContainsString('IdempotencyKeys::customTaskReward', $moderation);

        // ورکرِ تأیید تسک اجتماعی: کارمزد قبل از release burn می‌شود (FIX-SOCIAL-FEE-BURN)
        $approveJob = (string)file_get_contents(self::ROOT . '/app/Jobs/SocialTask/ApproveSocialTaskExecutionJob.php');
        $this->assertStringContainsString('IdempotencyKeys::socialTaskFee', $approveJob);
        $this->assertStringContainsString('consumeHeldBudget', $approveJob);
    }
}
