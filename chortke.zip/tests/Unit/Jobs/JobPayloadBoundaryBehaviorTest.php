<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Jobs\Notification\SendFromTemplateNotificationJob;
use App\Jobs\Notification\SendNotificationJob;
use App\Jobs\ProcessNotificationJob;
use App\Jobs\UpdateFraudScoreJob;
use App\Services\Notification\NotificationDispatcher;
use App\Services\Notification\NotificationTemplateService;
use App\Services\ScoreService;
use PHPUnit\Framework\TestCase;

final class JobPayloadBoundaryBehaviorTest extends TestCase
{
    // 🛡️ FIX-S20-DEADFILE + 🧹 FIX-T22-19: تست test_create_custom_task_rejects_non_array_data_before_side_effects
    // حذف شد — جابِ یتیمِ ایجاد تسک سفارشی (بدون تولیدکننده و خارج از allowlist صف) با
    // saga سنکرون زندهٔ AdsController::store → AdSystemManager::create → CustomTaskAdapter
    // جایگزین شده بود و کلاسش هم در بچ FIX-M22-MED (T22-19) حذف شد.

    public function test_process_notification_rejects_unknown_channel(): void
    {
        $job = new ProcessNotificationJob(
            $this->createMock(NotificationDispatcher::class),
            $this->createMock(\App\Contracts\LoggerInterface::class)
        );

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('channel must be fcm or sms');
        $job->handle(['channel' => ['fcm'], 'user_ids' => [1]]);
    }

    public function test_process_notification_rejects_empty_recipient_contract(): void
    {
        $job = new ProcessNotificationJob(
            $this->createMock(NotificationDispatcher::class),
            $this->createMock(\App\Contracts\LoggerInterface::class)
        );

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('user_ids must be a non-empty array');
        $job->handle(['channel' => 'fcm', 'user_ids' => []]);
    }

    public function test_update_fraud_score_rejects_structurally_invalid_domain(): void
    {
        $job = new UpdateFraudScoreJob($this->createMock(ScoreService::class));

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('domain and source must be non-empty strings');
        $job->handle(['user_id' => 7, 'delta' => 1, 'domain' => ['fraud']]);
    }

    public function test_template_job_fails_fast_when_renderer_breaks_title_contract(): void
    {
        $templates = $this->createMock(NotificationTemplateService::class);
        $templates->expects($this->once())->method('renderTemplate')->willReturn([
            'title' => ['invalid'],
            'message' => 'valid message',
        ]);
        $sender = $this->createMock(SendNotificationJob::class);
        $sender->expects($this->never())->method('handle');
        $job = new SendFromTemplateNotificationJob($templates, $sender);

        $this->expectException(\UnexpectedValueException::class);
        $this->expectExceptionMessage('must render string title and message');
        $job->handle(7, 'security_alert');
    }
}
