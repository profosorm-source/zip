<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Jobs\VitrineListingExpiryJob;
use App\Jobs\CustomTask\SubmitProofJob;
use App\Models\CustomTaskSubmissionModel;
use App\Services\EmailDeliveryStore;
use App\Jobs\Notification\SendToSegmentNotificationJob;
use App\Jobs\Notification\SendToAllNotificationJob;
use App\Validators\Requests\CloseTradeRequest;
use Core\Container;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بچ S17 — قفل رفتاری فیکس‌های Jobs + Commands:
 *
 *  - FIX-S17-1: آزادسازی Hold ویترین با claim اتمیک CAS + کلید idempotency صریح
 *    per-listing — دو لیستین منقضیِ هم‌مبلغِ یک کاربر هر دو باید واریز شوند
 *    (کلید ضمنی ولت فاقد شناسهٔ لیستین بود ⇒ واریز دوم replay می‌شد).
 *  - FIX-S17-2: proof_file فقط مسیر تولیدشدهٔ UploadService (task-proofs/24hex.ext)
 *    پذیرفته می‌شود؛ رشتهٔ خام = IDOR write primitive (الگوی FIX-S15-10).
 *  - FIX-S17-3: وضعیت بستن ترید وایت‌لیست closed/stopped.
 *  - FIX-S17-4: انقضای ارسال‌ها فقط از in_progress (CAS) — تصویب هم‌زمان بازنویسی نمی‌شود.
 *  - FIX-S17-5: لینک خودکار OAuth فقط با تأییدیهٔ email_verified ارائه‌دهنده (ضد ATO).
 *  - FIX-S17-6/7: سگمنت ناشناخته fail-closed + bind هم‌تراز SQL + sanitizeUrl در جاب‌های bulk.
 *  - FIX-S17-8: claim اتمیک صف ایمیل (وضعیت 'sending' در اسکیما مجاز شده است).
 *
 * تست‌های DB روی MariaDB واقعی اجرا می‌شوند (قرارداد S12…S16).
 */
final class S17JobsCommandsHardeningTest extends TestCase
{
    /** @var list<string> */
    private array $cleanupTables = [];
    /** @var list<int> */
    private array $cleanupIds = [];
    /** @var list<string> */
    private array $cleanupIdempotencyKeys = [];

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        foreach ($this->cleanupIdempotencyKeys as $key) {
            try {
                $db->execute("DELETE FROM idempotency_keys WHERE `key` = ?", [$key]);
            } catch (\Throwable) {
            }
        }
        foreach ($this->cleanupIds as $i => $id) {
            $table = $this->cleanupTables[$i] ?? null;
            if ($table === null) {
                continue;
            }
            try {
                $db->table($table)->where('id', '=', $id)->delete();
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        $this->cleanupIds = [];
        $this->cleanupTables = [];
        $this->cleanupIdempotencyKeys = [];
        parent::tearDown();
    }

    private function trackCleanup(string $table, int $id): void
    {
        $this->cleanupTables[] = $table;
        $this->cleanupIds[] = $id;
    }

    private function db(): Database
    {
        return Database::getInstance();
    }

    private function container(): Container
    {
        return Container::getInstance();
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S17-1 — آزادسازی Hold ویترین: هر لیستین دقیقاً یک بار
    // ─────────────────────────────────────────────────────────────

    public function test_expired_vitrine_holds_release_each_listing_once(): void
    {
        $this->setOutputCallback(static function (string $output): string { return ''; });
        $db = $this->db();
        $userId = 1;

        $wallet = $db->fetch("SELECT * FROM wallets WHERE user_id = ?", [$userId]);
        $this->assertNotNull($wallet, 'کیف پول seed برای کاربر ۱ باید موجود باشد');
        $this->assertSame(0, (int)($wallet->is_frozen ?? 0), 'کیف پول seed نباید مسدود باشد');
        $balanceBefore = (string)($wallet->balance_irt ?? '0');

        $idBefore = (int)($db->fetchColumn("SELECT COALESCE(MAX(id),0) FROM transactions") ?? 0);

        $l1 = (int)$db->table('vitrine_listings')->insert([
            'user_id' => $userId, 'title' => 'S17 hold A', 'status' => 'expired',
            'hold_amount' => 1.50000000, 'hold_released' => 0, 'currency' => 'irt',
        ]);
        $l2 = (int)$db->table('vitrine_listings')->insert([
            'user_id' => $userId, 'title' => 'S17 hold B', 'status' => 'expired',
            'hold_amount' => 1.50000000, 'hold_released' => 0, 'currency' => 'irt',
        ]);
        $this->assertGreaterThan(0, (int)$l1);
        $this->assertGreaterThan(0, (int)$l2);
        $this->trackCleanup('vitrine_listings', (int)$l1);
        $this->trackCleanup('vitrine_listings', (int)$l2);

        /** @var VitrineListingExpiryJob $job */
        $job = $this->container()->make(VitrineListingExpiryJob::class);
        $job->handle();

        // هر دو لیستین claimed شده‌اند
        $releasedCount = (int)$db->fetchColumn(
            "SELECT COUNT(*) FROM vitrine_listings WHERE id IN (?, ?) AND hold_released = 1",
            [(int)$l1, (int)$l2]
        );
        $this->assertSame(2, $releasedCount, 'هر دو لیستین منقضی باید آزاد می‌شدند');

        // نکتهٔ کلیدی فیکس: دو تراکنش جدا (قبلاً واریز دوم به‌عنوان replay حذف می‌شد)
        $txCount = (int)$db->fetchColumn(
            "SELECT COUNT(*) FROM transactions WHERE id > ? AND user_id = ? AND type = 'vitrine_hold_release'",
            [$idBefore, $userId]
        );
        $this->assertSame(2, $txCount, 'دو لیستینِ هم‌مبلغ باید دو واریز مستقل بسازند');

        foreach ([(int)$l1, (int)$l2] as $lid) {
            // کلید صریح per-listing: vitrine_hold_release_{listing_id}
            $tx = $db->fetch(
                "SELECT idempotency_key FROM transactions WHERE id > ? AND user_id = ? AND type = 'vitrine_hold_release' AND idempotency_key = ?",
                [$idBefore, $userId, 'vitrine_hold_release_' . $lid]
            );
            $this->assertNotNull($tx, 'هر واریز باید idempotency_key per-listing داشته باشد');
            if ($tx !== null) {
                $this->cleanupIdempotencyKeys[] = (string)$tx->idempotency_key;
            }
        }
        $txRows = $db->fetchAll(
            "SELECT id, idempotency_key, description, amount FROM transactions WHERE id > ? AND user_id = ? AND type = 'vitrine_hold_release'",
            [$idBefore, $userId]
        );
        foreach ($txRows as $row) {
            $this->trackCleanup('transactions', (int)$row->id);
            $this->cleanupIdempotencyKeys[] = (string)$row->idempotency_key;
        }

        // ماندهٔ کیف پول باید دقیقاً ۳ واحد افزایش یافته باشد (۲ × ۱.۵)
        $balanceAfter = (string)($db->fetchColumn(
            "SELECT balance_irt FROM wallets WHERE user_id = ?", [$userId]
        ) ?? '0');
        $this->assertSame('3.00000000', bcsub($balanceAfter, $balanceBefore, 8), 'افزایش مانده باید ۲×۱.۵ باشد');

        // بازگردانی ماندهٔ کیف پول به مقدار اولیه
        $db->execute("UPDATE wallets SET balance_irt = ? WHERE user_id = ?", [$balanceBefore, $userId]);
    }

    public function test_vitrine_release_uses_cas_claim_and_explicit_idempotency_key(): void
    {
        $source = file_get_contents(dirname(__DIR__, 3) . '/app/Jobs/VitrineListingExpiryJob.php');
        $this->assertNotFalse($source);

        // claim اتمیک با گارد از-وضعیت (نه UPDATE بی‌قید)
        $this->assertStringContainsString("AND hold_released = 0 AND status = 'expired'", $source);
        // کلید idempotency صریح per-listing + ref_id
        $this->assertStringContainsString("'idempotency_key' => 'vitrine_hold_release_'", $source);
        $this->assertStringContainsString("'ref_id' => 'vitrine_listing_'", $source);
        // SELECT FOR UPDATE بیرون از تراکنش (بی‌اثر) نباید باقی مانده باشد
        $this->assertStringNotContainsString('LIMIT 200 FOR UPDATE', $source);
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S17-2 — گیت مسیر proof_file تسک سفارشی
    // ─────────────────────────────────────────────────────────────

    public function test_custom_task_proof_file_rejects_raw_path_and_accepts_upload_path(): void
    {
        $this->setOutputCallback(static function (string $output): string { return ''; });
        $db = $this->db();
        $workerId = 1;

        $mk = function (string $tag) use ($db, $workerId): int {
            $id = (int)$db->table('custom_task_submissions')->insert([
                'task_id' => 990001, 'worker_id' => $workerId, 'status' => 'in_progress',
                'idempotency_key' => 's17proof_' . $tag . '_' . bin2hex(random_bytes(4)),
                'deadline_at' => date('Y-m-d H:i:s', time() + 3600),
            ]);
            $this->trackCleanup('custom_task_submissions', $id);
            return $id;
        };

        // مسیر خام (IDOR write primitive) — باید drop شود
        $badId = $mk('bad');
        /** @var SubmitProofJob $job */
        $job = $this->container()->make(SubmitProofJob::class);
        $job->handle([
            'submission_id' => $badId, 'worker_id' => $workerId,
            'proof_data' => [
                'proof_type' => 'file',
                'proof_file' => 'kyc/victim-file.jpg',
                'proof_file_hash' => str_repeat('a', 64),
                'idempotency_key' => 's17_idem_bad_' . bin2hex(random_bytes(8)),
                'proof_text' => 'مدرک آزمون مسیر خام',
            ],
        ]);
        $badRow = $db->fetch("SELECT proof_file, proof_file_hash FROM custom_task_submissions WHERE id = ?", [$badId]);
        $this->assertNotNull($badRow);
        $this->assertNull($badRow->proof_file, 'مسیر خام باید drop شود');
        $this->assertNull($badRow->proof_file_hash, 'همراه مسیرِ ردشده، hash هم باید drop شود');

        // مسیر مشروع تولیدشدهٔ UploadService — باید حفظ شود
        $goodId = $mk('good');
        $goodPath = 'task-proofs/' . bin2hex(random_bytes(12)) . '.jpg';
        $job->handle([
            'submission_id' => $goodId, 'worker_id' => $workerId,
            'proof_data' => [
                'proof_type' => 'file',
                'proof_file' => $goodPath,
                'proof_file_hash' => str_repeat('b', 64),
                'idempotency_key' => 's17_idem_good_' . bin2hex(random_bytes(8)),
                'proof_text' => 'مدرک آزمون مسیر مشروع',
            ],
        ]);
        $goodRow = $db->fetch("SELECT proof_file, proof_file_hash FROM custom_task_submissions WHERE id = ?", [$goodId]);
        $this->assertNotNull($goodRow);
        $this->assertSame($goodPath, $goodRow->proof_file, 'مسیر مشروع آپلود باید ذخیره شود');
        $this->assertSame(str_repeat('b', 64), $goodRow->proof_file_hash);
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S17-3 — وایت‌لیست وضعیت بستن ترید
    // ─────────────────────────────────────────────────────────────

    public function test_close_trade_request_whitelists_status(): void
    {
        $base = ['close_price' => '1.5', 'profit_loss_amount' => '0.5'];

        $open = new CloseTradeRequest($base + ['status' => 'open']);
        $this->assertFalse($open->validate(), 'وضعیت open نباید قابل نوشتن باشد');

        $forged = new CloseTradeRequest($base + ['status' => 'cancelled']);
        $this->assertFalse($forged->validate(), 'وضعیت دلخواه نباید قابل نوشتن باشد');

        $closed = new CloseTradeRequest($base + ['status' => 'closed']);
        $this->assertTrue($closed->validate());

        $stopped = new CloseTradeRequest($base + ['status' => 'stopped']);
        $this->assertTrue($stopped->validate());

        $nullStatus = new CloseTradeRequest($base);
        $this->assertTrue($nullStatus->validate(), 'نبودِ وضعیت (پیش‌فرض closed در جاب) مجاز است');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S17-4 — CAS انقضای ارسال‌های تسک سفارشی
    // ─────────────────────────────────────────────────────────────

    public function test_submission_expire_cas_only_transitions_from_in_progress(): void
    {
        $db = $this->db();
        $model = new CustomTaskSubmissionModel(Database::getInstance());

        $id = (int)$db->table('custom_task_submissions')->insert([
            'task_id' => 990002, 'worker_id' => 1, 'status' => 'in_progress',
            'idempotency_key' => 's17_cas_' . bin2hex(random_bytes(4)),
            'deadline_at' => date('Y-m-d H:i:s', time() - 60),
        ]);
        $this->trackCleanup('custom_task_submissions', $id);

        $this->assertTrue($model->submission_expireIfInProgress($id), 'in_progress → expired باید claim شود');
        $this->assertSame('expired', (string)$db->fetchColumn("SELECT status FROM custom_task_submissions WHERE id = ?", [$id]));

        // پس از تصویب (شبیه‌سازی تصویب هم‌زمان)، کرون انقضا نباید بازنویسی کند
        $db->execute("UPDATE custom_task_submissions SET status = 'approved' WHERE id = ?", [$id]);
        $this->assertFalse($model->submission_expireIfInProgress($id), 'approved نباید به expired بازنویسی شود');
        $this->assertSame('approved', (string)$db->fetchColumn("SELECT status FROM custom_task_submissions WHERE id = ?", [$id]));

        // claim دوم روی expired هم ناموفق است
        $db->execute("UPDATE custom_task_submissions SET status = 'expired' WHERE id = ?", [$id]);
        $this->assertFalse($model->submission_expireIfInProgress($id));
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S17-5 — گیت email_verified در لینک خودکار OAuth
    // ─────────────────────────────────────────────────────────────

    public function test_oauth_email_link_requires_provider_verification(): void
    {
        $source = file_get_contents(dirname(__DIR__, 3) . '/app/Jobs/Auth/OAuthHelperTrait.php');
        $this->assertNotFalse($source);

        // گیت باید پیش از درج social_accounts در شاخهٔ هم‌ایمیلیِ حساب محلی باشد
        $gatePos = strpos($source, "if (empty(\$userData['email_verified']))");
        $linkPos = strpos($source, 'Link + login');
        $this->assertNotFalse($gatePos, 'گیت email_verified باید در تریت وجود داشته باشد');
        $this->assertNotFalse($linkPos, 'شاخهٔ link+login باید موجود باشد');
        $this->assertLessThan($linkPos, $gatePos, 'گیت باید پیش از درج لینک و loginDirectly باشد');

        // ثبت‌نام جدید هم فقط با فلگ تأییدشده ایمیل را وریفای می‌کند (رفتار موجود)
        $this->assertStringContainsString("(\$userData['email_verified'] ?? false)", $source);
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S17-6 — سگمنت‌های اعلان: وایت‌لیست + bind هم‌تراز
    // ─────────────────────────────────────────────────────────────

    /** @return array{0:SendToSegmentNotificationJob,1:\ReflectionMethod} */
    private function segmentQueryProbe(): array
    {
        $job = $this->container()->make(SendToSegmentNotificationJob::class);
        $m = new \ReflectionMethod($job, 'buildSegmentQuery');
        $m->setAccessible(true);
        return [$job, $m];
    }

    public function test_segment_query_known_segments_return_sql_and_bindings(): void
    {
        [, $m] = $this->segmentQueryProbe();
        /** @var array{0:string,1:list<mixed>} $admins */
        $admins = $m->invoke($this->container()->make(SendToSegmentNotificationJob::class), 'admins', []);
        $this->assertSame('SELECT id FROM users WHERE deleted_at IS NULL AND role IN (\'admin\', \'super_admin\')', $admins[0]);
        $this->assertSame([], $admins[1]);
    }

    public function test_segment_query_unknown_segment_is_fail_closed(): void
    {
        [$job, $m] = $this->segmentQueryProbe();
        $this->assertNull($m->invoke($job, 'admins ', []), 'سگمنت ناشناخته نباید به «همهٔ کاربران» سقوط کند');
        $this->assertNull($m->invoke($job, 'custom_seg', []), 'سگمنت سفارشی بدون فیلتر معتبر = blast همه — مسدود');
        $this->assertNull($m->invoke($job, 'vipusers', []));
    }

    public function test_segment_custom_filters_bind_in_sql_order(): void
    {
        [$job, $m] = $this->segmentQueryProbe();

        // FIX-R36-W2-F1 (F-A18-01): وایت‌لیست هم‌تراز اسکیمای واقعی — role از enum
        // نقش‌ها، status/kyc_status از enum/مقادیر واقعی، level → ستون level_slug.
        // کلید شبح min_level/level_id حذف شده است.
        // ترتیب کلیدهای ورودی با ترتیب SQL فرق دارد — bind باید با SQL هم‌تراز بماند
        /** @var array{0:string,1:list<mixed>} $r */
        $r = $m->invoke($job, 'segment_x', ['level' => 'gold', 'role' => 'admin', 'status' => 'active', 'kyc_status' => 'verified', 'registered_after' => '2026-01-02 03:04:05']);
        $this->assertStringContainsString(' AND role = ?', $r[0]);
        $this->assertStringContainsString(' AND status = ?', $r[0]);
        $this->assertStringContainsString(' AND kyc_status = ?', $r[0]);
        $this->assertStringContainsString(' AND level_slug = ?', $r[0]);
        $this->assertStringContainsString(' AND created_at >= ?', $r[0]);
        $this->assertSame(
            ['admin', 'active', 'verified', 'gold', '2026-01-02 03:04:05'],
            $r[1],
            'ترتیب bind باید با ترتیب placeholderها یکی باشد'
        );

        // کلیدهای غیر وایت‌لیست (از جمله شبح min_level) نادیده گرفته می‌شوند
        /** @var array{0:string,1:list<mixed>} $r2 */
        $r2 = $m->invoke($job, 'segment_x', ['role' => 'support', 'min_level' => 7, 'evil' => '1=1']);
        $this->assertSame(['support'], $r2[1]);
        $this->assertStringNotContainsString('evil', $r2[0]);
        $this->assertStringNotContainsString('level_id', $r2[0]);
    }

    /**
     * FIX-R36-W2-F1 (F-A18-01): سگمنت‌های دراپ‌داون ادمین باید واقعاً پشتیبانی شوند
     * و روی ستون‌های واقعی users بچرخند (نه شبح‌های last_login_at/level_id/role='vip').
     */
    public function test_segment_contract_matches_admin_dropdown_and_real_schema(): void
    {
        [, $m] = $this->segmentQueryProbe();

        // کلیدهای دراپ‌داون GetAvailableSegments — هر کلید باید query بدهد (نه null)
        foreach (['all', 'kyc_verified', 'kyc_pending', 'kyc_none', 'level_silver', 'level_gold', 'level_vip', 'new_users', 'inactive', 'custom'] as $key) {
            $filters = $key === 'custom' ? ['status' => 'active'] : [];
            /** @var array{0:string,1:list<mixed>} $q */
            $q = $m->invoke($this->container()->make(SendToSegmentNotificationJob::class), $key, $filters);
            $this->assertNotNull($q, "سگمنت دراپ‌داون [$key] نباید fail-closed بماند");
            $this->assertStringNotContainsString('last_login_at', $q[0], "[$key] ستون شبح last_login_at ممنوع");
            $this->assertStringNotContainsString('level_id', $q[0], "[$key] ستون شبح level_id ممنوع");
            $this->assertStringNotContainsString("role = 'vip'", $q[0], "[$key] نقش 'vip' وجود خارجی ندارد");
        }

        // ستون‌های واقعی schema: last_login / level_slug / kyc_status
        /** @var array{0:string,1:list<mixed>} $active */
        $active = $m->invoke($this->container()->make(SendToSegmentNotificationJob::class), 'active', []);
        $this->assertStringContainsString('last_login >=', $active[0]);
        /** @var array{0:string,1:list<mixed>} $vip */
        $vip = $m->invoke($this->container()->make(SendToSegmentNotificationJob::class), 'vip', []);
        $this->assertStringContainsString("level_slug = 'vip'", $vip[0]);
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S17-7 — sanitizeUrl در جاب‌های bulk اعلان
    // ─────────────────────────────────────────────────────────────

    public function test_bulk_notification_jobs_sanitize_action_url(): void
    {
        $segment = $this->container()->make(SendToSegmentNotificationJob::class);
        $all = $this->container()->make(SendToAllNotificationJob::class);

        foreach (['SendToSegmentNotificationJob' => [$segment, 'sanitizeUrl'], 'SendToAllNotificationJob' => [$all, 'sanitizeUrl']] as $label => [$obj, $methodName]) {
            $m = new \ReflectionMethod($obj, $methodName);
            $m->setAccessible(true);

            $this->assertNull($m->invoke($obj, 'javascript:alert(1)'), "[$label] scheme جاواسکریپت باید رد شود");
            $this->assertNull($m->invoke($obj, '/wallet'), "[$label] URL نسبی باید رد شود");
            $this->assertNull($m->invoke($obj, null), "[$label] null ورودی null خروجی");
            $this->assertNull($m->invoke($obj, ''), "[$label] رشتهٔ خالی null خروجی");
            $this->assertSame('https://example.com/p', $m->invoke($obj, 'https://example.com/p'), "[$label] URL مشروع https حفظ می‌شود");
        }
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S17-8 — claim اتمیک صف ایمیل
    // ─────────────────────────────────────────────────────────────

    public function test_email_queue_claim_is_atomic_and_exclusive(): void
    {
        $this->setOutputCallback(static function (string $output): string { return ''; });
        $db = $this->db();

        $id = (int)$db->table('email_queue')->insert([
            'to_email' => 's17-claim@test.local', 'subject' => 'S17 claim', 'body' => 'x',
            'status' => 'pending',
        ]);
        $this->trackCleanup('email_queue', $id);

        /** @var EmailDeliveryStore $store */
        $store = $this->container()->make(EmailDeliveryStore::class);

        // نخستین claim برنده است و وضعیت sending می‌گیرد
        $row = $store->findAndLock((string)$id);
        $this->assertNotNull($row, 'نخستین claim باید موفق باشد');
        $this->assertSame('sending', (string)$db->fetchColumn("SELECT status FROM email_queue WHERE id = ?", [$id]));

        // claim دوم (ورکر موازی) باید null بگیرد — بدون ارسال مضاعف
        $this->assertNull($store->findAndLock((string)$id), 'claim دوم باید مسدود شود');

        // markAsSent و مسیر نرمال
        $this->assertTrue($store->markAsSent((string)$id));
        $this->assertSame('sent', (string)$db->fetchColumn("SELECT status FROM email_queue WHERE id = ?", [$id]));
    }

    public function test_email_queue_schema_allows_sending_status(): void
    {
        $db = $this->db();
        $colType = (string)($db->fetchColumn(
            "SELECT COLUMN_TYPE FROM information_schema.columns
             WHERE table_schema = DATABASE() AND table_name = 'email_queue' AND column_name = 'status'"
        ) ?? '');
        $this->assertStringContainsString("'sending'", $colType, 'اسکیمای email_queue باید مقدار sending را بپذیرد (FIX-S17-8)');
    }
}
