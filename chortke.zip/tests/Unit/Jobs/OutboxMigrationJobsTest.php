<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use PHPUnit\Framework\TestCase;
use Mockery as m;

/**
 * تست‌های قواعد معماری Outbox برای Jobs
 *
 * دو قاعدهٔ مکمل (R89-e — بازسازی تست کهنهٔ Migration):
 *
 * ۱. هر جابی که رخداد outbox منتشر می‌کند (->record() روی سرویس outbox)
 *    باید App\Contracts\OutboxServiceInterface را در سازنده بپذیرد —
 *    «هر جابِ رخداد outbox منتشرکننده باید OutboxServiceInterface را بگیرد».
 *
 * ۲. جاب‌هایی که پس از FIX-DEAD-EVENT (حذف رخدادهای مردهٔ kyc.status_changed،
 *    registration.completed و seo.task.completed) دیگر رخدادی منتشر نمی‌کنند،
 *    نباید وابستگی outbox را نگه دارند — سازندهٔشان نباید OutboxServiceInterface
 *    بپذیرد و سورسشان نباید فراخوانی outbox->record() داشته باشد.
 *    گارد آینده‌نگر: اگر کسی استفادهٔ outbox را به این جاب‌ها برگرداند، باید
 *    وابستگی را دوباره تزریق کند و کلاس را به outboxEmittingJobsProvider منتقل
 *    کند — این تست سپر جلوگیری از فراموشی آن است.
 *
 * یادداشت ۹۰-c (فاز N-4): جابِ یتیمِ ایجاد تسک سفارشی از گروه ۱ به گروه ۲ منتقل شد —
 * وابستگی nullable outbox آن با صفر emission (بهداشت راندهای ۸۸/۸۹) حذف شد؛
 * رکورد وظیفه در DB منبع حقیقت بود (کامنت FIX-DEAD-EVENT در خود فایل جاب).
 * 🧹 FIX-T22-19 (بچ FIX-M22-MED): خودِ جاب نیز — یتیمِ بدون تولیدکننده و خارج از
 * allowlist صف — به‌طور کامل حذف شد؛ گارد رو-به-جلو برای بازگشتِ احتمالیِ outbox
 * به جاب‌های گروه ۲ باقی است.
 */
/**
 * @group architecture
 */
class OutboxMigrationJobsTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /**
     * قاعدهٔ ۱: جاب منتشرکنندهٔ outbox باید OutboxServiceInterface را بپذیرد.
     *
     * @dataProvider outboxEmittingJobsProvider
     * @test
     * @param class-string $class
     */
    public function outbox_emitting_job_must_accept_outbox_injection(string $class): void
    {
        $ref = new \ReflectionClass($class);
        $constructor = $ref->getConstructor();

        $this->assertNotNull($constructor, "$class has no constructor");

        $params = $constructor->getParameters();
        $paramTypes = [];
        foreach ($params as $p) {
            $type = $p->getType();
            if ($type instanceof \ReflectionNamedType) {
                $paramTypes[] = $type->getName();
            }
        }

        $this->assertTrue(
            in_array('App\\Contracts\\OutboxServiceInterface', $paramTypes),
            "$class should accept OutboxServiceInterface in constructor"
        );
    }

    /**
     * قاعدهٔ ۲: جابِ بدون رخدادِ زنده نباید outbox را تزریق کند و نباید
     * ->record() روی سرویس outbox صدا بزند.
     *
     * @dataProvider outboxFreeJobsProvider
     * @test
     * @param class-string $class
     */
    public function dead_event_jobs_must_not_require_outbox(string $class): void
    {
        $ref = new \ReflectionClass($class);
        $constructor = $ref->getConstructor();

        $this->assertNotNull($constructor, "$class has no constructor");

        $paramTypes = [];
        foreach ($constructor->getParameters() as $p) {
            $type = $p->getType();
            if ($type instanceof \ReflectionNamedType) {
                $paramTypes[] = $type->getName();
            }
        }

        $this->assertNotContains(
            'App\\Contracts\\OutboxServiceInterface',
            $paramTypes,
            "$class lost its outbox usage in FIX-DEAD-EVENT; if outbox is reintroduced, "
            . 'inject OutboxServiceInterface again and move the class to outboxEmittingJobsProvider'
        );

        // گارد آینده‌نگر: اگر کسی دوباره ->record( روی سرویس outbox بنویسد،
        // باید وابستگی بازتزریق و کلاس به پرووایدر اول منتقل شود (قاعدهٔ ۱).
        $file = $ref->getFileName();
        $this->assertIsString($file);
        $this->assertFileExists($file);
        $source = file_get_contents($file);
        $this->assertIsString($source);
        $this->assertNotRegExp(
            '/\$\w*outbox\w*\s*->\s*record\s*\(/i',
            $source,
            "$class emits an outbox event again; inject OutboxServiceInterface and "
            . 'move it to outboxEmittingJobsProvider'
        );
    }

    /**
     * جاب‌هایی که رخداد outbox منتشر می‌کنند (۱۲ جاب — پس از ۹۰-c).
     *
     * FIX-R18D: KycTimeoutJob از گروه ۲ به اینجا برگشت — در S18.6 (FIX-S18-6I)
     * اعلان ردِ timeout از مسیر مرده به «درِ واحد اعلان» (notification.requested)
     * منتقل شد و outbox nullable دوباره تزریق شد (کامنت FIX-S18-6I در خود فایل).
     *
     * @return list<array{0:class-string}>
     */
    public function outboxEmittingJobsProvider(): array
    {
        return [
            ['App\\Jobs\\KycTimeoutJob'],
            ['App\\Jobs\\Auth\\Verify2FAJob'],
            ['App\\Jobs\\CustomTask\\CronSubmissionsJob'],
            ['App\\Jobs\\CustomTask\\RateSubmissionJob'],
            ['App\\Jobs\\CustomTask\\SubmitProofJob'],
            // P3 DEAD-CODE FIX: ReconcilePaymentsJob با زنجیرهٔ بی‌فراخوانش حذف شد.
            ['App\\Jobs\\Investment\\ApplyProfitLossToBatchJob'],
            ['App\\Jobs\\Investment\\RejectWithdrawalJob'],
            ['App\\Jobs\\SocialTask\\ApproveSocialTaskExecutionJob'],
            ['App\\Jobs\\SocialTask\\DecideSilentAntiFraudJob'],
            ['App\\Jobs\\SocialTask\\RejectSocialTaskExecutionJob'],
            ['App\\Jobs\\Seo\\ProcessSeoTaskAsyncJob'],
        ];
    }

    /**
     * جاب‌هایی که تنها مصرف‌کنندهٔ رخدادشان حذف شده (FIX-DEAD-EVENT) یا از ابتدا
     * رخدادی منتشر نمی‌کرده‌اند (۹۰-c: جابِ ایجاد تسک سفارشی — که خودش هم در T22-19 حذف شد) —
     * بدون وابستگی outbox و بدون انتشار رخداد (مستند در کامنت هر فایل).
     *
     * @return list<array{0:class-string}>
     */
    public function outboxFreeJobsProvider(): array
    {
        return [
            ['App\\Jobs\\Auth\\ProcessRegistrationJob'],
            ['App\\Jobs\\Seo\\CompleteSeoTaskJob'],
        ];
    }
}
