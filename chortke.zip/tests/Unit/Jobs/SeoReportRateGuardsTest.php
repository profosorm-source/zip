<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Jobs\Seo\RateSeoTaskJob;
use App\Jobs\Seo\ReportSeoTaskJob;
use App\Models\SeoExecution;
use App\Services\Seo\AdsSeoService;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SEO3-01 (تصمیم ۱ — فعال‌سازی report/rate سئو): پین رفتاری گاردهای
 * سمت جاب — قرینهٔ S27SubserviceGuardsTest برای سوشیال. گاردها:
 *   Report: type=seo + مجری با اجرای started/completed
 *   Rate:   type=seo + نه مالک کمپین + مجری با اجرای completed + clamp ۱..۵
 */
final class SeoReportRateGuardsTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    /** @param array<string, mixed> $overrides */
    private function ad(array $overrides = []): \stdClass
    {
        return (object)array_merge([
            'id' => 3, 'status' => 'active', 'type' => 'seo', 'user_id' => 9,
        ], $overrides);
    }

    /** سازندهٔ جاب گزارش با گاردهای پاس‌شده به‌صورت پیش‌فرض */
    private function reportJob(\stdClass $ad, bool $hasExecution, \App\Services\Interaction\ReportService $reportService): ReportSeoTaskJob
    {
        $ads = m::mock(AdsSeoService::class);
        $ads->shouldReceive('getAd')->andReturn($ad);
        $executions = m::mock(SeoExecution::class);
        $executions->shouldReceive('userHasExecutionForAd')->andReturn($hasExecution);
        return new ReportSeoTaskJob($ads, $reportService, $executions);
    }

    private function rateJob(\stdClass $ad, bool $hasCompleted, \App\Services\Interaction\RatingService $ratingService): RateSeoTaskJob
    {
        $ads = m::mock(AdsSeoService::class);
        $ads->shouldReceive('getAd')->andReturn($ad);
        $executions = m::mock(SeoExecution::class);
        $executions->shouldReceive('userHasExecutionForAd')->andReturn($hasCompleted);
        return new RateSeoTaskJob($ads, $ratingService, $executions);
    }

    // ─────────────── گزارش: گاردها ───────────────

    public function test_report_rejects_non_seo_ad_type(): void
    {
        $reportService = $this->createMock(\App\Services\Interaction\ReportService::class);
        $reportService->expects($this->never())->method('submit');

        $job = $this->reportJob($this->ad(['type' => 'social']), true, $reportService);
        $result = $job->handle(2, 3, 'other', 'توضیح');

        $this->assertFalse($result['success']);
        // بدون افشای وجود آگهی از ماژول دیگر — همان پیام عمومی «یافت نشد»
        $this->assertSame('تسک یافت نشد', $result['message']);
    }

    public function test_report_requires_executor_with_started_or_completed_execution(): void
    {
        $reportService = $this->createMock(\App\Services\Interaction\ReportService::class);
        $reportService->expects($this->never())->method('submit');

        $job = $this->reportJob($this->ad(), false, $reportService);
        $result = $job->handle(2, 3, 'other', 'توضیح');

        $this->assertFalse($result['success']);
        $this->assertSame('فقط مجری این تسک می‌تواند گزارش ثبت کند', $result['message']);
    }

    public function test_report_accepts_executor_and_delegates_to_interaction_service(): void
    {
        $reportService = $this->createMock(\App\Services\Interaction\ReportService::class);
        $reportService->expects($this->once())->method('submit')
            ->with(2, 'seo_task', 3, \App\Enums\ModuleContext::GLOBAL, 'other', 'توضیح')
            ->willReturn(true);

        $job = $this->reportJob($this->ad(), true, $reportService);
        $result = $job->handle(2, 3, 'other', 'توضیح');

        $this->assertTrue($result['success']);
    }

    public function test_report_rejects_empty_reason(): void
    {
        $reportService = $this->createMock(\App\Services\Interaction\ReportService::class);
        $reportService->expects($this->never())->method('submit');

        $job = $this->reportJob($this->ad(), true, $reportService);
        $result = $job->handle(2, 3, '   ', '');

        $this->assertFalse($result['success']);
        $this->assertSame('دلیل گزارش الزامی است', $result['message']);
    }

    // ─────────────── امتیاز: گاردها ───────────────

    public function test_rate_rejects_non_seo_ad_type(): void
    {
        $ratingService = $this->createMock(\App\Services\Interaction\RatingService::class);
        $ratingService->expects($this->never())->method('rate');

        $job = $this->rateJob($this->ad(['type' => 'custom_task']), true, $ratingService);
        $result = $job->handle(2, 3, 5);

        $this->assertFalse($result['success']);
        $this->assertSame('تسک یافت نشد', $result['message']);
    }

    public function test_rate_rejects_campaign_owner(): void
    {
        $ratingService = $this->createMock(\App\Services\Interaction\RatingService::class);
        $ratingService->expects($this->never())->method('rate');

        // مالک کمپین = کاربر ۹ (همان user_id آگهی)
        $job = $this->rateJob($this->ad(['user_id' => 9]), true, $ratingService);
        $result = $job->handle(9, 3, 5);

        $this->assertFalse($result['success']);
        $this->assertSame('امتیاز دادن به تسک خودتان مجاز نیست', $result['message']);
    }

    public function test_rate_requires_completed_execution(): void
    {
        $ratingService = $this->createMock(\App\Services\Interaction\RatingService::class);
        $ratingService->expects($this->never())->method('rate');

        $job = $this->rateJob($this->ad(), false, $ratingService);
        $result = $job->handle(2, 3, 5);

        $this->assertFalse($result['success']);
        $this->assertSame('فقط مجریِ اجرای تکمیل‌شده می‌تواند به این تسک امتیاز بدهد', $result['message']);
    }

    public function test_rate_accepts_completed_executor_and_clamps_stars(): void
    {
        $ratingService = $this->createMock(\App\Services\Interaction\RatingService::class);
        // ستارهٔ خارج از بازه (۹) به ۵ clamp می‌شود — قرارداد مشترک با سوشیال
        $ratingService->expects($this->once())->method('rate')
            ->with(2, 'seo_task', 3, \App\Enums\ModuleContext::GLOBAL, 5, 'نظر')
            ->willReturn(true);

        $job = $this->rateJob($this->ad(), true, $ratingService);
        $result = $job->handle(2, 3, 9, 'نظر');

        $this->assertTrue($result['success']);
    }

    public function test_rate_clamps_zero_stars_to_one(): void
    {
        $ratingService = $this->createMock(\App\Services\Interaction\RatingService::class);
        $ratingService->expects($this->once())->method('rate')
            ->with(2, 'seo_task', 3, \App\Enums\ModuleContext::GLOBAL, 1, '')
            ->willReturn(true);

        $job = $this->rateJob($this->ad(), true, $ratingService);
        $result = $job->handle(2, 3, 0);

        $this->assertTrue($result['success']);
    }
}
