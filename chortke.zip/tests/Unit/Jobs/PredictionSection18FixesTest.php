<?php

declare(strict_types=1);

namespace Tests\Unit\Jobs;

use App\Contracts\LoggerInterface;
use App\Jobs\PredictionGameSettlementJob;
use App\Models\PredictionBet;
use App\Services\PredictionService;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * بخش ۱۸ — Prediction (بازبینی مالک، راند FIX-SEC18)
 *
 * پوشش:
 *  - F-01: کلاس PredictionGameSettlementJob بدون fatal بارگذاری می‌شود
 *    (بلوک use تکراری درون کلاس با FIX-YAFTE3 حذف شده) + سازندهٔ تزریق
 *    وابستگی فعال است + handle() با صف خالی مسیر موفق/صفر را برمی‌گرداند.
 *  - F-02: هم‌ارزی فرمول پیش‌نمایش کلاینت (userpredictionshow.js) با
 *    ریاضیات سرور (SettleGameJob: profitPool = losers − siteFee + bonusPool)
 *    شامل استخر جایزهٔ انتقالی + پین سورسِ data-bonus-pool در view.
 *  - F-03: PredictionBet::getByUserAndGame کوئری را دقیقاً به
 *    (user_id + game_id) محدود می‌کند + پین سورسِ کنترلر (بدون الگوی قدیمی).
 *  - F-04: پیام جداگانهٔ بازی پایان‌یافته در view قدیمی + پین سورس.
 */
final class PredictionSection18FixesTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    // ───────────────────────────── F-01 ─────────────────────────────

    /** @test */
    public function settlement_job_class_loads_without_fatal_and_constructor_di_works(): void
    {
        // اگر بلوک use درون کلاس برگردد، این خط در link-time fatal می‌دهد.
        $this->assertTrue(class_exists(PredictionGameSettlementJob::class, true));

        $job = new PredictionGameSettlementJob(
            m::mock(PredictionService::class),
            m::mock(Database::class),
            m::mock(LoggerInterface::class)
        );
        $this->assertInstanceOf(PredictionGameSettlementJob::class, $job);
        $this->assertSame(900, $job->timeoutSeconds);
    }

    /** @test */
    public function settlement_job_handle_with_empty_queue_returns_success_payload(): void
    {
        $db = m::mock(Database::class);
        $logger = m::mock(LoggerInterface::class);
        $db->shouldReceive('fetchAll')->once()->andReturn([]);
        $logger->shouldReceive('info')
            ->once()
            ->with('prediction.settlement_job_completed', m::on(static function (array $p): bool {
                return $p['success'] === true
                    && $p['settled'] === 0
                    && $p['failed'] === 0
                    && array_key_exists('skipped', $p);
            }));

        $job = new PredictionGameSettlementJob(m::mock(PredictionService::class), $db, $logger);
        $result = $job->handle();

        $this->assertSame(['success' => true, 'settled' => 0, 'failed' => 0, 'skipped' => 0], $result);
    }

    /** @test */
    public function settlement_job_is_registered_in_console_kernel(): void
    {
        $kernel = file_get_contents(dirname(__DIR__, 3) . '/app/Console/Kernel.php');
        $this->assertIsString($kernel);
        $this->assertStringContainsString(PredictionGameSettlementJob::class, $kernel);
    }

    // ───────────────────────────── F-02 ─────────────────────────────

    /**
     * هم‌ارزی پیش‌نمایش کلاینت با ریاضیات سرور.
     * سرور (SettleGameJob): siteFee=losers×comm؛ profitPool=losers−siteFee+bonus؛
     * payout=amount+(amount/winnerPool)×profitPool.
     * کلاینت (userpredictionshow.js): همان با float؛ winnerPool شامل شرطِ
     * فرضیِ کاربر است (پیش‌نمایش «اگر الان ثبت کنم»).
     */
    private function serverPayout(string $amount, string $selectedPool, string $loserPool, string $bonusPool, string $commissionPercent): string
    {
        $commissionRatio = bcdiv($commissionPercent, '100', 8);
        $siteFee = bccomp($loserPool, '0', 8) > 0
            ? bcmul($loserPool, $commissionRatio, 8)
            : '0.00000000';
        $profitFromLosers = bcsub($loserPool, $siteFee, 8);
        $profitPool = bcadd($profitFromLosers, $bonusPool, 8);
        $winnerPool = bcadd($selectedPool, $amount, 8);
        if (bccomp($winnerPool, '0', 8) <= 0) {
            return $amount;
        }
        $ratio = bcdiv($amount, $winnerPool, 12);
        $profitShare = bccomp($profitPool, '0', 8) > 0
            ? bcmul($profitPool, $ratio, 8)
            : '0.00000000';
        return bcadd($amount, $profitShare, 8);
    }

    private function clientPayout(float $amount, float $selectedPool, float $totalPool, float $bonusPool, float $commission): float
    {
        $winnerPoolIfWins = $selectedPool + $amount;
        if ($winnerPoolIfWins <= 0) {
            return $amount;
        }
        $loserPoolIfWins = max(0.0, $totalPool - $selectedPool);
        $siteFee = $loserPoolIfWins * $commission;
        $distributableProfit = max(0.0, $loserPoolIfWins - $siteFee) + $bonusPool;
        return $amount + (($amount / $winnerPoolIfWins) * $distributableProfit);
    }

    /** @test */
    public function client_preview_formula_is_equivalent_to_server_settlement_math_with_bonus_pool(): void
    {
        $cases = [
            // [amount, selectedPool, loserPool(=totalPool−selectedPool), bonus, commissionPercent]
            ['50.00000000', '300.00000000', '1000.00000000', '250.00000000', '5'],   // سناریوی اصلی با bonus
            ['10.00000000', '75.50000000', '240.25000000', '0.00000000', '7.5'],     // بدون bonus
            ['100.00000000', '500.00000000', '0.00000000', '120.00000000', '5'],     // loserPool=0 ولی bonus>0
            ['25.00000000', '10.00000000', '90.00000000', '45.12345678', '0'],       // کمیسیون صفر
        ];
        foreach ($cases as [$amount, $selectedPool, $loserPool, $bonus, $commissionPercent]) {
            $expected = $this->serverPayout($amount, $selectedPool, $loserPool, $bonus, $commissionPercent);
            $client = $this->clientPayout((float)$amount, (float)$selectedPool, (float)bcadd($selectedPool, $loserPool, 8), (float)$bonus, (float)bcdiv($commissionPercent, '100', 8));
            $this->assertEqualsWithDelta(
                (float)$expected,
                $client,
                0.000001,
                "ناهم‌ارزی پیش‌نمایش با تسویه سرور: amount={$amount} bonus={$bonus}"
            );
        }
    }

    /** @test */
    public function show_view_exposes_bonus_pool_data_and_js_consumes_it_like_hub(): void
    {
        $root = dirname(__DIR__, 3);
        $view = (string)file_get_contents($root . '/views/user/prediction/show.php');
        $js = (string)file_get_contents($root . '/public/assets/js/views/userpredictionshow.js');
        $hub = (string)file_get_contents($root . '/public/assets/js/views/userpredictionhub.js');

        $this->assertStringContainsString('data-bonus-pool=', $view);
        $this->assertStringContainsString('dataset.bonusPool', $js);
        $this->assertStringContainsString('+ bonusPool', $js);
        // قرارداد واحد با هاب: profit نهایی = max(0, losers − siteFee) + bonus
        $this->assertStringContainsString('max(0, loserPoolIfWins - siteFee) + bonusPool', $js);
        $this->assertStringContainsString('max(0, loserPool - siteFee) + bonusPool', $hub);
    }

    // ───────────────────────────── F-03 ─────────────────────────────

    /** @test */
    public function get_by_user_and_game_scopes_query_to_both_user_and_game(): void
    {
        $row = (object) ['id' => 11, 'user_id' => 7, 'game_id' => 3, 'prediction' => 'home', 'amount_usdt' => '25.00'];
        $captured = new \stdClass();
        $db = m::mock(Database::class);
        $db->shouldReceive('fetch')
            ->once()
            ->with(m::on(static function (string $sql) use ($captured): bool {
                $captured->sql = $sql;
                return str_contains($sql, 'pb.user_id = ?') && str_contains($sql, 'pb.game_id = ?');
            }), [7, 3])
            ->andReturn($row);

        $model = new PredictionBet($db);
        $bet = $model->getByUserAndGame(7, 3);

        $this->assertNotNull($bet);
        $this->assertSame(3, (int)$bet->game_id);
        $this->assertStringContainsString('user_id = ?', $captured->sql);
        $this->assertStringContainsString('game_id = ?', $captured->sql);
    }

    /** @test */
    public function get_by_user_and_game_returns_null_when_user_has_no_bet_in_this_game(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('fetch')->once()->andReturn(null);
        $model = new PredictionBet($db);
        $this->assertNull($model->getByUserAndGame(7, 999));
    }

    /** @test */
    public function user_show_controller_reads_bet_via_user_and_game_not_last_record(): void
    {
        $controller = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Controllers/User/PredictionController.php');
        $this->assertStringContainsString('getByUserAndGame($userId, $id)', $controller);
        // الگوی معیوبِ قدیمی (فقط آخرین رکورد + foreach) نباید برگردد.
        $this->assertStringNotContainsString('getByUser($userId, 1, 0)', $controller);
    }

    // ───────────────────────────── F-04 ─────────────────────────────

    /** @test */
    public function show_view_has_distinct_finished_message_before_generic_expired(): void
    {
        $view = (string)file_get_contents(dirname(__DIR__, 3) . '/views/user/prediction/show.php');
        $finishedPos = mb_strpos($view, "status === 'finished'") ?: mb_strpos($view, "status==='finished'");
        $cancelledPos = mb_strpos($view, "status === 'cancelled'") ?: mb_strpos($view, "status==='cancelled'");
        $this->assertNotFalse($finishedPos, 'شاخهٔ finished جداگانه وجود ندارد');
        $this->assertNotFalse($cancelledPos);
        $this->assertLessThan($cancelledPos, $finishedPos, 'شاخهٔ finished باید قبل از cancelled بیاید تا قابل‌دسترس باشد');
        $this->assertStringContainsString('به پایان رسیده', $view);
        // پیام عمومی «مهلت تمام شده» فقط برای closed/منقضی می‌ماند.
        $this->assertStringContainsString('مهلت ثبت پیش‌بینی برای این بازی تمام شده است', $view);
    }
}
