<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Constants\CryptoConstants;
use App\Constants\SessionKeys;
use App\Constants\TimeConstants;
use App\Constants\PercentageConstants;
use App\Constants\SystemConstants;

class ConstantsTest extends TestCase
{
    /** @test */
    public function crypto_constants_are_defined_correctly(): void
    {
        $this->assertEquals(19, CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_TRC20);
        $this->assertEquals(15, CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_BNB20);
        $this->assertEquals(30, CryptoConstants::DEFAULT_INTENT_EXPIRE_MINUTES);
    }

    /** @test */
    public function session_keys_are_defined_correctly(): void
    {
        $this->assertEquals('user_id', SessionKeys::USER_ID);
        $this->assertEquals('user_role', SessionKeys::USER_ROLE);
        $this->assertEquals('oauth_state', SessionKeys::OAUTH_STATE);
    }

    /** @test */
    public function magic_numbers_constants_are_defined_correctly(): void
    {
        // 🛡️ FIX-S20-DEADFILE: ۸ کلاسِ مردهٔ MagicNumbers (TrustScore/RateLimit/TaskScoring/
        // Pagination/Redis/Payment/Validation/Feature Constants) حذف شدند — تنها مصرفشان
        // همین تست tautological بود و مقادیرشان نسبت به مسیر زندهٔ production دریفت خورده
        // بود (LOGIN_DECAY ۶۰دقیقه↔واقعی ۱۵دقیقه؛ TrustMinimum ۰↔−۵۰). سه کلاسِ زنده مانده‌اند.
        $this->assertEquals(60, TimeConstants::SECONDS_PER_MINUTE);
        $this->assertEquals(3600, TimeConstants::SECONDS_PER_HOUR);
        $this->assertEquals(86400, TimeConstants::SECONDS_PER_DAY);

        $this->assertEquals(20, PercentageConstants::AD_TUBE_FEE_PERCENT);
        $this->assertEquals(15, PercentageConstants::SOCIAL_TASK_FEE_PERCENT);

        $this->assertEquals(1073741824, SystemConstants::GB_1);
        $this->assertEquals(1048576, SystemConstants::MB_1);
    }
}
