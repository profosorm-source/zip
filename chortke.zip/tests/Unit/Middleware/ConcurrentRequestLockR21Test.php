<?php

declare(strict_types=1);

namespace Tests\Unit\Middleware;

use App\Middleware\ConcurrentRequestMiddleware;
use Core\Request;
use Core\Redis;
use PHPUnit\Framework\TestCase;

/**
 * چرخهٔ اصلاحی 2026-10-28 (بستن یافته‌های جانبی QA چرخهٔ R18) —
 * FIX-R21-LOCK + FIX-R21-AJAX روی ConcurrentRequestMiddleware.
 *
 * باگ ۲ (FIX-R21-LOCK): exit پالیسی (RateLimitPolicy::tooManyResponse) داخل
 * $next فینالیِ middleware را نمی‌سوزاند (PHP در exit بلوک‌های finally زنجیرهٔ
 * فراخوان را اجرا نمی‌کند) ⇒ قفل Redis تا پایان TTL (15s/60s) نشتی می‌کرد و
 * درخواست بعدیِ همان کاربر 429 «درخواست هم‌زمان» می‌گرفت.
 * فیکس: register_shutdown_function با release صاحب‌آگاه (compare-and-del).
 *
 * باگ ۳ (FIX-R21-AJAX): شاخهٔ Ajaxِ ردِ قفل از Response::json() استفاده می‌کرد
 * که send() → HttpResponseException پرتاب می‌کند؛ آن پرتاب توسط catch(\Throwable)
 * همین try (که برای خطاهای Redis بود) بلعیده می‌شد ⇒ مسیر غیرمالی بی‌قفل به
 * کنترلر می‌رسید (fail-open = خنثی‌شدن حفاظت دابل‌سابمیت برای کلاینت‌های Ajax).
 * فیکس: Response-builder بدون پرتاب + مذاکرهٔ محتوای هم‌قاعدهٔ پالیسی.
 *
 * @group r21
 */
final class ConcurrentRequestLockR21Test extends TestCase
{
    private const TEST_USER_ID = 424242;

    private Redis $redis;

    /** @var array<string, mixed> */
    private array $serverBackup = [];

    private mixed $sessionUserIdBackup = null;

    protected function setUp(): void
    {
        $this->redis = new Redis();
        if (!$this->redis->isAvailable()) {
            self::markTestSkipped('Redis در دسترس نیست — تست قفل هم‌زمانی به Redis زنده نیاز دارد');
        }
        $this->serverBackup = $_SERVER;
        $this->sessionUserIdBackup = session()->get('user_id');
    }

    protected function tearDown(): void
    {
        $_SERVER = $this->serverBackup;
        if ($this->sessionUserIdBackup === null) {
            session()->remove('user_id');
        } else {
            session()->set('user_id', $this->sessionUserIdBackup);
        }
        $client = $this->redis->getClient();
        if ($client !== null) {
            @$client->del('lock:user:' . self::TEST_USER_ID . ':' . md5('/r21-lock-pin'));
            @$client->del('lock:user:' . self::TEST_USER_ID . ':' . md5('/r21-exit-pin'));
            @$client->del('lock:user:' . self::TEST_USER_ID . ':' . md5('/r21-accept-pin'));
        }
    }

    private function makeRequest(string $uri): Request
    {
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_SERVER['REQUEST_URI'] = $uri;
        session()->set('user_id', self::TEST_USER_ID);
        return new Request();
    }

    /**
     * @test
     */
    public function ajax_lock_conflict_is_rejected_not_fail_open(): void
    {
        $uri = '/r21-lock-pin';
        $lockKey = 'lock:user:' . self::TEST_USER_ID . ':' . md5($uri);
        $client = $this->redis->getClient();
        self::assertNotNull($client);
        $client->del($lockKey);
        // قفلِ صاحبِ دیگر = درخواست هم‌زمانِ واقعیِ در جریان
        self::assertTrue($client->set($lockKey, 'other-owner-token', ['NX', 'EX' => 30]));

        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'XMLHttpRequest';
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
        $request = $this->makeRequest($uri);

        $middleware = new ConcurrentRequestMiddleware($this->redis);
        $response = $middleware->handle($request, static function (): never {
            throw new \RuntimeException('fail-open: درخواستِ دارای قفلِ زنده به کنترلر رسید (BUG-3)');
        });

        self::assertSame(429, $response->getStatusCode(), 'کلاینت Ajaxِ هم‌زمان باید 429 بگیرد نه عبور بی‌قفل');
        $body = json_decode($response->getContent(), true);
        self::assertIsArray($body, 'بدنهٔ پاسخ Ajax باید JSON معتبر باشد');
        self::assertFalse((bool)$body['success']);
        self::assertSame(
            'درخواست قبلی شما در حال پردازش است. لطفاً چند لحظه صبر کنید.',
            $body['message']
        );
        // LOCK_TTL = 15s برای مسیر غیرمالی (ثابت خصوصی کلاس — مقدار پین‌شده)
        self::assertSame(15, $body['retry_after']);
        // قفل صاحب دیگر باید دست‌نخورده بماند (release صاحب‌آگاه هرگز قفل بیگانه را نمی‌بُزد)
        self::assertSame('other-owner-token', $client->get($lockKey));
    }

    /**
     * @test
     */
    public function accept_json_client_without_ajax_header_also_gets_json(): void
    {
        // هم‌قاعدهٔ RateLimitPolicy::tooManyResponse: Accept-JSON بدون X-Requested-With
        $uri = '/r21-accept-pin';
        $lockKey = 'lock:user:' . self::TEST_USER_ID . ':' . md5($uri);
        $client = $this->redis->getClient();
        self::assertNotNull($client);
        $client->del($lockKey);
        self::assertTrue($client->set($lockKey, 'other-owner-token', ['NX', 'EX' => 30]));

        unset($_SERVER['HTTP_X_REQUESTED_WITH']);
        $_SERVER['HTTP_ACCEPT'] = 'application/json';
        $request = $this->makeRequest($uri);

        $middleware = new ConcurrentRequestMiddleware($this->redis);
        $response = $middleware->handle($request, static function (): never {
            throw new \RuntimeException('نباید به کنترلر برسد — قفل زنده بود');
        });

        self::assertSame(429, $response->getStatusCode());
        $body = json_decode($response->getContent(), true);
        self::assertIsArray($body, 'کلاینت Accept-JSON باید بدنهٔ JSON بگیرد (مذاکرهٔ هم‌قاعده)');
        self::assertStringContainsString('در حال پردازش', (string)($body['message'] ?? ''));
    }

    /**
     * @test
     */
    public function non_ajax_lock_conflict_gets_text_429(): void
    {
        $uri = '/r21-lock-pin';
        $lockKey = 'lock:user:' . self::TEST_USER_ID . ':' . md5($uri);
        $client = $this->redis->getClient();
        self::assertNotNull($client);
        $client->del($lockKey);
        self::assertTrue($client->set($lockKey, 'other-owner-token', ['NX', 'EX' => 30]));

        unset($_SERVER['HTTP_X_REQUESTED_WITH']);
        $_SERVER['HTTP_ACCEPT'] = 'text/html';
        $request = $this->makeRequest($uri);

        $middleware = new ConcurrentRequestMiddleware($this->redis);
        $response = $middleware->handle($request, static function (): never {
            throw new \RuntimeException('نباید به کنترلر برسد — قفل زنده بود');
        });

        self::assertSame(429, $response->getStatusCode());
        self::assertSame('درخواست همزمان مجاز نیست. لطفا صبر کنید.', $response->getContent());
        self::assertSame('15', $response->getHeader('Retry-After'));
    }

    /**
     * @test
     */
    public function lock_is_released_when_pipeline_exits(): void
    {
        // پین رفتاری FIX-R21-LOCK — با زیرپروسه: $next داخل middleware با exit
        // ختم می‌شود (شبیه‌سازی RateLimitPolicy::tooManyResponse). فینالیِ
        // middleware در exit اجرا نمی‌شود؛ تنها shutdown handler می‌تواند قفل را
        // آزاد کند. پس از مرگ زیرپروسه، قفل باید غایب باشد.
        $uri = '/r21-exit-pin';
        $lockKey = 'lock:user:' . self::TEST_USER_ID . ':' . md5($uri);
        $client = $this->redis->getClient();
        self::assertNotNull($client);
        $client->del($lockKey);

        $root = dirname(__DIR__, 3);
        $script = sys_get_temp_dir() . '/r21-lock-exit-' . uniqid('', true) . '.php';
        $marker = sys_get_temp_dir() . '/r21-lock-marker-' . uniqid('', true) . '.txt';

        $userId = (string)self::TEST_USER_ID;
        file_put_contents($script, <<<PHP
<?php
declare(strict_types=1);
[, \$root, \$marker, \$userId] = \$argv;
define('PHPUNIT_RUNNING', true);
require \$root . '/bootstrap/testing.php';

\$uri = '/r21-exit-pin';
\$lockKey = 'lock:user:' . \$userId . ':' . md5(\$uri);
\$redis = new \Core\Redis();
\$client = \$redis->getClient();

\$_SERVER['REQUEST_METHOD'] = 'POST';
\$_SERVER['REQUEST_URI'] = \$uri;
session()->set('user_id', (int)\$userId);
\$request = new \Core\Request();

\$middleware = new \App\Middleware\ConcurrentRequestMiddleware(\$redis);
\$middleware->handle(\$request, static function () use (\$client, \$lockKey, \$marker): void {
    // قفل باید در لحظهٔ اجرای pipeline زنده باشد
    file_put_contents(\$marker, \$client->get(\$lockKey) !== false ? 'held' : 'not-held');
    exit; // شبیه‌سازی exit پالیسی — finallyِ middleware نباید اجرا شود
});
echo 'UNEXPECTED-RETURN';
PHP);

        try {
            $output = [];
            $exitCode = 0;
            exec(
                PHP_BINARY . ' ' . escapeshellarg($script) . ' '
                . escapeshellarg($root) . ' ' . escapeshellarg($marker) . ' ' . escapeshellarg($userId)
                . ' 2>&1',
                $output,
                $exitCode
            );

            self::assertSame(
                'held',
                (string)file_get_contents($marker),
                'قفل باید در حین اجرای $next زنده باشد (کنترل مثبت)'
            );
            self::assertFalse(
                $client->get($lockKey),
                'قفل باید پس از exit توسط shutdown handler آزاد شود (FIX-R21-LOCK) — در حالت باگ تا TTL 15s می‌ماند'
            );
        } finally {
            @unlink($script);
            @unlink($marker);
        }
    }

    /**
     * @test
     */
    public function middleware_registers_shutdown_release_on_acquisition(): void
    {
        // پین ساختاری با پیام خطای روشن (پین رفتاری بالای همین فایل قوی‌تر است؛
        // این پین علت شکست را در حذفِ ناخواستهٔ handler خواناتر می‌کند)
        $src = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Middleware/ConcurrentRequestMiddleware.php');
        self::assertStringContainsString(
            'register_shutdown_function',
            $src,
            'میان‌افزار باید پس از اکتساب قفل shutdown handler ثبت کند تا exit پالیسی قفل را نشت ندهد'
        );
        self::assertStringContainsString(
            'concurrentConflictResponse',
            $src,
            'شاخهٔ ردِ قفل باید از Response-builder بدون پرتاب استفاده کند (FIX-R21-AJAX)'
        );
        // شاخهٔ قدیمیِ باگ: json() داخل try قفل — نباید بازگردده شود
        $lockBranch = substr($src, (int)strpos($src, 'if (!$acquiredLock)'), 700);
        self::assertStringNotContainsString(
            '->json(',
            $lockBranch,
            'شاخهٔ ردِ قفل نباید از Response::json() (پرتاب‌کننده) استفاده کند — بازگشت آن fail-open است'
        );
    }
}
