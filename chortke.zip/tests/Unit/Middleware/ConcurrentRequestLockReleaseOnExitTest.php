<?php

declare(strict_types=1);

namespace Tests\Unit\Middleware;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-R20-CY2-B (باگ جانبی QA چرخهٔ R18 — رگرسیون نشت قفل):
 *
 * ریشهٔ باگ: exit() در PHP بلاک finally را اجرا نمی‌کند. RateLimitPolicy::
 * tooManyResponse (و هر لایهٔ زیرینِ دیگر با الگوی echo+exit) بعد از گرفتن
 * قفل توسط ConcurrentRequestMiddleware، بدون آزادسازی پروسه را ترک می‌کرد؛
 * قفل lock:user:{id}:{uri} تا انقضای TTL (۱۵s/۶۰s) می‌ماند و کاربر در همهٔ
 * تلاش‌های بعدی همان URI خطای ۴۲۹ «درخواست قبلی شما در حال پردازش است»
 * می‌گرفت — باگ #32 گزارش‌شده در QA چرخهٔ R18.
 *
 * رفع: تور ایمنی register_shutdown_function در خودِ middleware — کال‌بک‌های
 * shutdown حتی هنگام exit اجرا می‌شوند و قفل مالک‌آگاه را آزاد می‌کنند.
 *
 * روش تست: هر سناریو در پروسهٔ فرزندِ مجزا اجرا می‌شود (exit در پروسهٔ
 * PHPUnit قابل شبیه‌سازی نیست) با Redis ماکِ درون‌حافظه‌ای که فراخوانی‌هایش
 * را به فایل JSON می‌نویسد — الگوی payment_callback_worker.php.
 */
final class ConcurrentRequestLockReleaseOnExitTest extends TestCase
{
    private string $phpBinary;

    protected function setUp(): void
    {
        parent::setUp();
        // همان مفسرِ در حال اجرا (الگوی WorkerLifecycleTest) — با fallback به php
        $this->phpBinary = PHP_BINARY ?: 'php';
    }

    /** @return array{mode:string, calls:array<int,array<string,mixed>>, store:array<string,string>, reached_after_handle:bool} */
    private function runWorker(string $mode): array
    {
        $resultFile = sys_get_temp_dir() . '/chortke-lock-exit-' . $mode . '-' . bin2hex(random_bytes(4)) . '.json';
        @unlink($resultFile);

        $worker = dirname(__DIR__, 2) . '/Support/concurrent_lock_exit_worker.php';
        $cmd = escapeshellarg($this->phpBinary)
            . ' ' . escapeshellarg($worker)
            . ' ' . escapeshellarg($resultFile)
            . ' ' . escapeshellarg($mode)
            . ' 2>&1';

        $output = [];
        $exitCode = 0;
        exec($cmd, $output, $exitCode);

        $raw = is_file($resultFile) ? (string)file_get_contents($resultFile) : '';
        @unlink($resultFile);

        $this->assertNotSame('', $raw, "worker mode={$mode} باید فایل نتیجه بنویسد (exit={$exitCode}, output=" . implode("\n", $output) . ')');

        $decoded = json_decode($raw, true);
        $this->assertIsArray($decoded, "خروجی worker باید JSON معتبر باشد: {$raw}");
        return $decoded;
    }

    /** @param array<int,array<string,mixed>> $calls */
    private function countOp(array $calls, string $op): int
    {
        $n = 0;
        foreach ($calls as $c) {
            if (($c['op'] ?? '') === $op) {
                $n++;
            }
        }
        return $n;
    }

    public function test_exit_bypassing_finally_still_releases_lock_via_shutdown(): void
    {
        $r = $this->runWorker('exit');

        // قفل گرفته شده؟
        $this->assertSame(1, $this->countOp($r['calls'], 'set-nx-acquired'), 'قفل NX باید گرفته شده باشد');

        // هست باگ: exit → finally اجرا نمی‌شود → تنها راه آزادسازی، shutdown callback است
        $this->assertSame(1, $this->countOp($r['calls'], 'eval-compare-and-del'), 'پس از exit، تور ایمنی shutdown باید قفل را با compare-and-del آزاد کند');

        // store خالی = قفل واقعاً آزاد شد
        $this->assertSame([], $r['store'], 'قفل نباید بعد از خروج پروسه باقی بماند (نشت قفل)');

        // و مسیر عادی هرگز طی نشد (اثبات اینکه سناریو واقعاً exit بوده)
        $this->assertFalse($r['reached_after_handle'], 'در حالت exit نباید کد بعد از handle اجرا شود');
    }

    public function test_normal_path_releases_exactly_once_no_double_release(): void
    {
        $r = $this->runWorker('normal');

        $this->assertSame(1, $this->countOp($r['calls'], 'set-nx-acquired'));
        // finally آزاد می‌کند + shutdown با پرچم lockReleased باید skip کند → فقط یک آزادسازی
        $this->assertSame(1, $this->countOp($r['calls'], 'eval-compare-and-del'), 'در مسیر عادی دقیقاً یک آزادسازی (finally) — shutdown نباید مضاعف بزند');
        $this->assertSame([], $r['store']);
        $this->assertTrue($r['reached_after_handle'], 'حالت normal باید تا انتهای handle اجرا شود');
    }

    public function test_exception_path_releases_via_finally(): void
    {
        $r = $this->runWorker('throw');

        $this->assertSame(1, $this->countOp($r['calls'], 'set-nx-acquired'));
        // رفتار FIX-R19-A7-2 حفظ شده: استثنا → finally آزاد می‌کند
        $this->assertSame(1, $this->countOp($r['calls'], 'eval-compare-and-del'), 'استثنا باید از مسیر finally آزاد کند (رفتار قبلی حفظ شده)');
        $this->assertSame([], $r['store']);
    }

    public function test_release_is_owner_aware_even_in_shutdown(): void
    {
        // آزادسازی shutdown همان مسیر releaseOwnedLock را می‌رود: فقط با تطابق
        // مالک حذف می‌کند. در هر سه حالت، eval ثبت‌شده باید مالک را تطبیق داده
        // باشد (owner_matched=true در متادیتای فراخوانی).
        foreach (['exit', 'normal', 'throw'] as $mode) {
            $r = $this->runWorker($mode);
            $evals = array_values(array_filter($r['calls'], static fn ($c) => ($c['op'] ?? '') === 'eval-compare-and-del'));
            $this->assertNotEmpty($evals, "mode={$mode}: حداقل یک eval");
            foreach ($evals as $e) {
                $this->assertSame(1, $e['deleted'] ?? 0, "mode={$mode}: آزادسازی فقط قفلِ خودمان را پاک کند");
                $this->assertTrue($e['owner_matched'] ?? false, "mode={$mode}: حذف باید با تطابق مالک انجام شود");
            }
        }
    }
}
