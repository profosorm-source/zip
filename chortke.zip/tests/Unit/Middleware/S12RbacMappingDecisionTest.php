<?php

declare(strict_types=1);

namespace Tests\Unit\Middleware;

use App\Middleware\AdminPermissionGuard;
use PHPUnit\Framework\TestCase;

/**
 * بچ S12 — قفل رفتاری «تصمیم RBAC کاربر» (FIX-S12-2 — راه ترکیبی):
 *
 *  ۱) FraudReportsAdminController (صف بررسی گزارش‌های تخلف) از «خارج از نقشه»
 *     به نقشهٔ مجوز آمد: default = fraud.view، review/dismiss = fraud.manage.
 *     هر دو slug از قبل در جدول permissions موجودند (migration
 *     2026_08_08_0001_rbac_full_permissions.sql) — صفر تغییر دادهٔ RBAC.
 *     تا پیش از این، unmapped بودن یعنی 403 برای هر غیرسوپرادمین.
 *
 *  ۲) چهار کنترلر سیستمی عمداً unmapped می‌مانند (super_admin-only):
 *     CronController، CacheAdminController، ApiTokenAdminController،
 *     EmailQueueController — تصمیم ثبت‌شده در config/admin_permissions.php.
 *     permissionForAction برای آن‌ها null برمی‌گرداند و گارد deny می‌کند.
 *
 *  ۳) قرارداد تک‌منبع-حقیقت (X98): permissionForAction باید با همان کلیدِ
 *     short-class-name که config می‌شناسد کار کند — با FQN و با short name.
 */
final class S12RbacMappingDecisionTest extends TestCase
{
    // ─────────────────────────────────────────────────────────────
    // ۱) FraudReportsAdminController — نقشه‌گذاری جدید
    // ─────────────────────────────────────────────────────────────

    public function test_fraud_reports_index_requires_fraud_view(): void
    {
        $this->assertSame(
            'fraud.view',
            AdminPermissionGuard::permissionForAction(
                \App\Controllers\Admin\FraudReportsAdminController::class,
                'index'
            )
        );
    }

    public function test_fraud_reports_review_and_dismiss_require_fraud_manage(): void
    {
        $this->assertSame(
            'fraud.manage',
            AdminPermissionGuard::permissionForAction(
                \App\Controllers\Admin\FraudReportsAdminController::class,
                'review'
            )
        );
        $this->assertSame(
            'fraud.manage',
            AdminPermissionGuard::permissionForAction(
                \App\Controllers\Admin\FraudReportsAdminController::class,
                'dismiss'
            )
        );
    }

    public function test_fraud_reports_mapping_uses_short_class_key_and_fqn_input(): void
    {
        // قرارداد X98: کلید نقشه = short name؛ ورودی FQN هم باید همان جواب را بدهد.
        $this->assertSame(
            'fraud.view',
            AdminPermissionGuard::permissionForAction('FraudReportsAdminController', 'index')
        );
    }

    // ─────────────────────────────────────────────────────────────
    // ۲) کنترلرهای سیستمی — عمداً unmapped (deny برای غیرسوپر)
    // ─────────────────────────────────────────────────────────────

    public function test_system_controllers_remain_unmapped_deny_by_default(): void
    {
        $systemActions = [
            [\App\Controllers\Admin\CronController::class, 'index'],
            [\App\Controllers\Admin\CronController::class, 'run'],
            [\App\Controllers\Admin\CacheAdminController::class, 'index'],
            [\App\Controllers\Admin\ApiTokenAdminController::class, 'index'],
            [\App\Controllers\Admin\ApiTokenAdminController::class, 'revoke'],
            [\App\Controllers\Admin\EmailQueueController::class, 'index'],
            [\App\Controllers\Admin\EmailQueueController::class, 'process'],
        ];
        foreach ($systemActions as [$class, $method]) {
            $this->assertNull(
                AdminPermissionGuard::permissionForAction($class, $method),
                "$class::$method باید unmapped بماند (تصمیم S12: super_admin-only)"
            );
        }
    }

    // ─────────────────────────────────────────────────────────────
    // ۳) هم‌سایگان fraud دست‌نخورده (رگرسیون نقشه)
    // ─────────────────────────────────────────────────────────────

    public function test_sibling_fraud_controllers_keep_their_mappings(): void
    {
        $this->assertSame(
            'fraud.view',
            AdminPermissionGuard::permissionForAction(\App\Controllers\Admin\FraudDashboardController::class, 'index')
        );
        $this->assertSame(
            'fraud.manage',
            AdminPermissionGuard::permissionForAction(\App\Controllers\Admin\FraudManagementController::class, 'blockIP')
        );
        $this->assertSame(
            'fraud.manage',
            AdminPermissionGuard::permissionForAction(\App\Controllers\Admin\FraudController::class, 'recalculateScore')
        );
    }
}
