<?php

namespace Tests\Unit\Middleware;

use PHPUnit\Framework\TestCase;
use App\Middleware\AdvancedFraudMiddleware;
use Core\Request;
use Core\Response;
use Mockery as m;

class AdvancedFraudMiddlewareTest extends TestCase
{
    /** @var \App\Services\AntiFraud\BrowserFingerprintService&\Mockery\MockInterface */
    private \App\Services\AntiFraud\BrowserFingerprintService $fingerprintService;
    /** @var \App\Services\AntiFraud\GeoIPService&\Mockery\MockInterface */
    private \App\Services\AntiFraud\GeoIPService $ipQualityService;
    /** @var \App\Services\Auth\SessionService&\Mockery\MockInterface */
    private \App\Services\Auth\SessionService $sessionService;
    /** @var \App\Services\AntiFraud\AccountTakeoverService&\Mockery\MockInterface */
    private \App\Services\AntiFraud\AccountTakeoverService $accountTakeoverService;
    /** @var \App\Services\ScoreService&\Mockery\MockInterface */
    private \App\Services\ScoreService $scoreService;
    /** @var \App\Services\AntiFraud\RiskDecisionService&\Mockery\MockInterface */
    private \App\Services\AntiFraud\RiskDecisionService $decisionService;
    /** @var \App\Contracts\LoggerInterface&\Mockery\MockInterface */
    private \App\Contracts\LoggerInterface $logger;
    /** @var \Core\Session&\Mockery\MockInterface */
    private \Core\Session $session;
    private AdvancedFraudMiddleware $middleware;
    /** @var \App\Contracts\NotificationServiceInterface&\Mockery\MockInterface */
    private \App\Contracts\NotificationServiceInterface $notifications;

    private function mockRequest(): \Core\Request
    {
        $request = m::mock(Request::class);
        $request->shouldIgnoreMissing();
        $request->shouldReceive('uri')->andReturn('/test');
        $request->shouldReceive('header')->with('accept-language')->andReturnUsing(fn() => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? null);
        $request->shouldReceive('header')->with('accept-encoding')->andReturnUsing(fn() => $_SERVER['HTTP_ACCEPT_ENCODING'] ?? null);
        return $request;
    }

    protected function setUp(): void
    {
        parent::setUp();
        $this->fingerprintService = m::mock('App\Services\AntiFraud\BrowserFingerprintService');
        $this->ipQualityService = m::mock('App\Services\AntiFraud\GeoIPService');
        $this->sessionService = m::mock('App\Services\Auth\SessionService');
        $this->accountTakeoverService = m::mock('App\Services\AntiFraud\AccountTakeoverService');
        $this->scoreService = m::mock('App\Services\ScoreService');
        $this->decisionService = m::mock('App\Services\AntiFraud\RiskDecisionService');
        $this->logger = m::mock('App\Contracts\LoggerInterface');
        $this->session = m::mock('Core\Session');
        $this->notifications = m::mock('App\Contracts\NotificationServiceInterface');

        $this->logger->shouldIgnoreMissing();
        $this->notifications->shouldIgnoreMissing();

        $this->middleware = new AdvancedFraudMiddleware(
            $this->fingerprintService,
            $this->ipQualityService,
            $this->sessionService,
            $this->accountTakeoverService,
            $this->scoreService,
            $this->decisionService,
            $this->logger,
            $this->session,
            $this->notifications
        );
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function guests_bypass_the_middleware(): void
    {
        $this->session->shouldReceive('has')->with('user_id')->once()->andReturn(false);

        $request = $this->mockRequest();
        $response = new Response();
        $next = function ($req) use ($response) {
            return $response;
        };

        $result = $this->middleware->handle($request, $next);
        $this->assertSame($response, $result);
    }

    /** @test */
    public function authenticated_user_with_clean_record_is_allowed(): void
    {
        $userId = 42;
        $sessionId = 'sess_xyz';
        $ip = '1.1.1.1';
        $userAgent = 'Mozilla/5.0';
        $acceptLanguage = 'fa-IR';
        $acceptEncoding = 'gzip, deflate';
        $geoData = ['country_code' => 'IR', 'city' => 'Tehran'];

        // Mock Server Globals
        $_SERVER['HTTP_ACCEPT_LANGUAGE'] = $acceptLanguage;
        $_SERVER['HTTP_ACCEPT_ENCODING'] = $acceptEncoding;
        $_SERVER['HTTP_USER_AGENT'] = $userAgent;
        $_SERVER['REMOTE_ADDR'] = $ip;

        // Mock Session calls
        $this->session->shouldReceive('has')->with('user_id')->andReturn(true);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId);
        $this->session->shouldReceive('getId')->andReturn($sessionId);
        $this->session->shouldReceive('get')->with('fraud_check_done')->andReturn(false);
        $this->session->shouldReceive('set')->with('fraud_check_done', true)->once();
        $this->session->shouldReceive('remove')->with('under_manual_review')->once();

        // Service expectations
        $this->ipQualityService->shouldReceive('getGeolocation')->with($ip)->once()->andReturn($geoData);
        $this->sessionService->shouldReceive('updateActivity')->with($sessionId)->once();
        $this->sessionService->shouldReceive('recordSession')
            ->with($userId, $sessionId, $userAgent, $ip, $acceptLanguage, $acceptEncoding, $geoData)
            ->once();

        $this->ipQualityService->shouldReceive('isIPBlacklisted')->with($ip)->once()->andReturn(false);

        // IP Check
        $ipCheck = ['is_suspicious' => false, 'score' => 0];
        $this->ipQualityService->shouldReceive('check')->with($ip)->once()->andReturn($ipCheck);

        // Session Check
        $sessionCheck = ['is_anomaly' => false, 'score' => 0];
        $this->sessionService->shouldReceive('analyzeAnomaly')->with($userId, $sessionId)->once()->andReturn($sessionCheck);

        // Fingerprint Service
        $this->fingerprintService->shouldReceive('generate')->once()->andReturn('fingerprint_123');

        // Takeover Check
        $takeoverCheck = ['is_takeover' => false, 'risk_score' => 0];
        $this->accountTakeoverService->shouldReceive('detect')
            ->with($userId, $ip, $userAgent, 'fingerprint_123')
            ->once()
            ->andReturn($takeoverCheck);

        // Risk Decision Service
        $this->decisionService->shouldReceive('decide')
            ->with($userId, ['action' => 'general'])
            ->once()
            ->andReturn(['result' => 'allow']);

        $request = $this->mockRequest();
        $response = new Response();
        $next = function ($req) use ($response) {
            return $response;
        };

        $result = $this->middleware->handle($request, $next);
        $this->assertInstanceOf(Response::class, $result);
    }

    /** @test */
    public function blacklisted_ip_triggers_immediate_session_destroy_and_redirect(): void
    {
        $userId = 42;
        $sessionId = 'sess_xyz';
        $ip = '1.1.1.1';

        $_SERVER['REMOTE_ADDR'] = $ip;

        $this->session->shouldReceive('has')->with('user_id')->andReturn(true);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId);
        $this->session->shouldReceive('getId')->andReturn($sessionId);
        $this->session->shouldReceive('get')->with('fraud_check_done')->andReturn(true);

        $this->ipQualityService->shouldReceive('getGeolocation')->with($ip)->once()->andReturn([]);
        $this->sessionService->shouldReceive('updateActivity')->with($sessionId)->once();

        // Mock Blacklist IP
        $this->ipQualityService->shouldReceive('isIPBlacklisted')->with($ip)->once()->andReturn(true);
        $this->session->shouldReceive('destroy')->once();

        $request = $this->mockRequest();
        $next = function ($req) {
            return new Response();
        };

        try {
            $result = $this->middleware->handle($request, $next);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            $result = $e->getResponse();
        }

        $this->assertInstanceOf(Response::class, $result);
        $this->assertContains($result->getStatusCode(), [200, 301, 302], "Expected a redirect");
    }

    /** @test */
    public function tor_node_ip_causes_blacklist_and_tor_blocked_redirect(): void
    {
        $userId = 42;
        $sessionId = 'sess_xyz';
        $ip = '1.1.1.1';

        $_SERVER['REMOTE_ADDR'] = $ip;

        $this->session->shouldReceive('has')->with('user_id')->andReturn(true);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId);
        $this->session->shouldReceive('getId')->andReturn($sessionId);
        $this->session->shouldReceive('get')->with('fraud_check_done')->andReturn(true);

        $this->ipQualityService->shouldReceive('getGeolocation')->with($ip)->once()->andReturn([]);
        $this->sessionService->shouldReceive('updateActivity')->with($sessionId)->once();

        $this->ipQualityService->shouldReceive('isIPBlacklisted')->with($ip)->once()->andReturn(false);

        // TOR IP Check Result
        $ipCheck = [
            'is_suspicious' => true,
            'score' => 90,
            'reasons' => ['استفاده از شبکه Tor'],
            'details' => ['is_tor' => true]
        ];
        $this->ipQualityService->shouldReceive('check')->with($ip)->once()->andReturn($ipCheck);
        $this->ipQualityService->shouldReceive('logIPCheck')->with($userId, $ip, $ipCheck)->once();
        
        // Delta points application
        // NOTE: the middleware now passes a 7th argument (idempotency signal key)
        // so the same static IP-quality signal is applied only once per
        // (user, ip, reasons) — the expectation must match the new contract.
        $this->scoreService->shouldReceive('applyDelta')
            ->with('user', $userId, \App\Enums\ScoreDomain::Fraud->value, 22.5, 'ip_quality', m::type('array'), m::type('string'))
            ->once();

        // Blacklist and destroy
        $this->ipQualityService->shouldReceive('blacklistIP')->with($ip, 'Tor Network', 86400 * 7)->once();
        $this->session->shouldReceive('destroy')->once();

        $request = $this->mockRequest();
        $next = function ($req) {
            return new Response();
        };

        try {
            $result = $this->middleware->handle($request, $next);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            $result = $e->getResponse();
        }

        $this->assertInstanceOf(Response::class, $result);
        $this->assertContains($result->getStatusCode(), [200, 301, 302], "Expected a redirect");
    }

    /** @test */
    public function high_risk_decision_blocks_user(): void
    {
        $userId = 42;
        $sessionId = 'sess_xyz';
        $ip = '1.1.1.1';

        $_SERVER['REMOTE_ADDR'] = $ip;

        $this->notifications->shouldReceive('send')->once()->andReturn(1234);

        $this->session->shouldReceive('has')->with('user_id')->andReturn(true);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId);
        $this->session->shouldReceive('getId')->andReturn($sessionId);
        $this->session->shouldReceive('get')->with('fraud_check_done')->andReturn(true);

        $this->ipQualityService->shouldReceive('getGeolocation')->with($ip)->once()->andReturn([]);
        $this->sessionService->shouldReceive('updateActivity')->with($sessionId)->once();
        $this->ipQualityService->shouldReceive('isIPBlacklisted')->with($ip)->once()->andReturn(false);

        $this->ipQualityService->shouldReceive('check')->andReturn(['is_suspicious' => false]);
        $this->sessionService->shouldReceive('analyzeAnomaly')->andReturn(['is_anomaly' => false]);
        $this->fingerprintService->shouldReceive('generate')->andReturn('fp');
        $this->accountTakeoverService->shouldReceive('detect')->andReturn(['is_takeover' => false]);

        // Mock Decision: block
        $this->decisionService->shouldReceive('decide')->andReturn(['result' => 'block']);
        $this->session->shouldReceive('destroy')->once();

        $request = $this->mockRequest();
        $next = function ($req) {
            return new Response();
        };

        try {
            $result = $this->middleware->handle($request, $next);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            $result = $e->getResponse();
        }

        $this->assertInstanceOf(Response::class, $result);
        $this->assertContains($result->getStatusCode(), [200, 301, 302], "Expected a redirect");
    }

    /** @test */
    public function manual_review_decision_sets_manual_review_session_flag(): void
    {
        $userId = 42;
        $sessionId = 'sess_xyz';
        $ip = '1.1.1.1';

        $_SERVER['REMOTE_ADDR'] = $ip;

        $this->session->shouldReceive('has')->with('user_id')->andReturn(true);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId);
        $this->session->shouldReceive('getId')->andReturn($sessionId);
        $this->session->shouldReceive('get')->with('fraud_check_done')->andReturn(true);

        $this->ipQualityService->shouldReceive('getGeolocation')->with($ip)->once()->andReturn([]);
        $this->sessionService->shouldReceive('updateActivity')->with($sessionId)->once();
        $this->ipQualityService->shouldReceive('isIPBlacklisted')->with($ip)->once()->andReturn(false);

        $this->ipQualityService->shouldReceive('check')->andReturn(['is_suspicious' => false]);
        $this->sessionService->shouldReceive('analyzeAnomaly')->andReturn(['is_anomaly' => false]);
        $this->fingerprintService->shouldReceive('generate')->andReturn('fp');
        $this->accountTakeoverService->shouldReceive('detect')->andReturn(['is_takeover' => false]);

        // Mock Decision: review
        $this->decisionService->shouldReceive('decide')->andReturn(['result' => 'review']);
        $this->session->shouldReceive('set')->with('under_manual_review', true)->once();

        $request = $this->mockRequest();
        $response = new Response();
        $next = function ($req) use ($response) {
            return $response;
        };

        $result = $this->middleware->handle($request, $next);
        $this->assertSame($response, $result);
    }

    /**
     * پیکربندی همه‌ی سرویس‌های ضدتقلب روی حالت «کاملاً سالم و پاک».
     *
     * هدف: در تست‌های رگرسیونِ زیر، هیچ‌کدام از بررسی‌ها نباید علت خطا باشند تا
     * بتوان مطمئن شد رفتار مشاهده‌شده صرفاً ناشی از استثنای خودِ کنترلر است.
     */
    private function arrangeCleanFraudEngine(int $userId = 42, string $sessionId = 'sess_clean', string $ip = '1.1.1.1'): void
    {
        $_SERVER['REMOTE_ADDR'] = $ip;

        $this->session->shouldReceive('has')->with('user_id')->andReturn(true);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId);
        $this->session->shouldReceive('getId')->andReturn($sessionId);
        $this->session->shouldReceive('get')->with('fraud_check_done')->andReturn(true);
        $this->session->shouldReceive('remove')->with('under_manual_review');

        $this->ipQualityService->shouldReceive('getGeolocation')->with($ip)->andReturn([]);
        $this->ipQualityService->shouldReceive('isIPBlacklisted')->with($ip)->andReturn(false);
        $this->ipQualityService->shouldReceive('check')->with($ip)->andReturn(['is_suspicious' => false]);

        $this->sessionService->shouldReceive('updateActivity')->with($sessionId)->andReturn(true);
        $this->sessionService->shouldReceive('analyzeAnomaly')->andReturn(['is_anomaly' => false]);

        $this->fingerprintService->shouldReceive('generate')->andReturn('fp');
        $this->accountTakeoverService->shouldReceive('detect')->andReturn(['is_takeover' => false]);
        $this->decisionService->shouldReceive('decide')->andReturn(['result' => 'allow']);
    }

    /**
     * ساخت درخواست POST برای یک مسیر حساس مالی.
     */
    private function mockSensitivePostRequest(string $uri = '/investment/withdraw'): \Core\Request
    {
        $request = m::mock(Request::class);
        $request->shouldIgnoreMissing();
        $request->shouldReceive('uri')->andReturn($uri);
        $request->shouldReceive('isPost')->andReturn(true);
        $request->shouldReceive('header')->andReturn(null);
        return $request;
    }

    /**
     * رگرسیون BUGFIX-FRAUD-SWALLOW-2026-08.
     *
     * استثنای مشروعِ دامنه که کنترلر روی یک مسیر حساس مالی پرتاب می‌کند نباید
     * توسط موتور ضدتقلب بلعیده شود. پیش از رفع، $next داخل try/catch بود و این
     * استثنا به‌عنوان «خرابی موتور» تفسیر می‌شد و پاسخ ۵۰۳ fail-closed می‌داد.
     *
     * @test
     */
    public function business_exception_from_controller_is_not_swallowed_on_sensitive_route(): void
    {
        $this->arrangeCleanFraudEngine();

        // موتور ضدتقلب سالم است، پس نباید هیچ خرابی‌ای لاگ شود.
        $this->logger->shouldNotReceive('error');
        $this->logger->shouldNotReceive('warning');

        $request = $this->mockSensitivePostRequest('/investment/withdraw');
        $next = function ($req): void {
            throw new \App\Exceptions\BusinessException('سودی برای برداشت وجود ندارد', 422);
        };

        try {
            $this->middleware->handle($request, $next);
            $this->fail('BusinessException کنترلر باید propagate شود، نه اینکه بلعیده شود.');
        } catch (\App\Exceptions\BusinessException $e) {
            $this->assertSame('سودی برای برداشت وجود ندارد', $e->getMessage());
            $this->assertSame(422, $e->getCode());
        }
    }

    /**
     * تضمین می‌کند رفع باگ، پاسخ ۵۰۳ را به شکل دیگری بازتولید نکند.
     *
     * در تلاش اول برای رفع، فقط $next بیرون برده شد ولی امضای
     * performFraudChecks روی «mixed» ماند؛ در نتیجه PHP خودش یک TypeError
     * («Return value must be of type mixed, none returned») پرتاب می‌کرد که
     * دوباره در همان catch می‌افتاد و همان ۵۰۳ برمی‌گشت.
     *
     * @test
     */
    public function controller_exception_never_becomes_a_503_service_unavailable(): void
    {
        $this->arrangeCleanFraudEngine();
        $this->logger->shouldNotReceive('error');
        $this->logger->shouldNotReceive('warning');

        $request = $this->mockSensitivePostRequest('/wallet/withdraw');
        $next = function ($req): void {
            throw new \App\Exceptions\BusinessException('موجودی کافی نیست', 422);
        };

        $caught = null;
        try {
            $this->middleware->handle($request, $next);
        } catch (\Throwable $e) {
            $caught = $e;
        }

        $this->assertNotInstanceOf(
            \Core\Exceptions\HttpResponseException::class,
            $caught,
            'استثنای کنترلر نباید به پاسخ HTTP مصنوعیِ موتور ضدتقلب تبدیل شود.'
        );
        $this->assertInstanceOf(\App\Exceptions\BusinessException::class, $caught);
    }

    /**
     * انواع دیگر استثناهای دامنه هم باید دست‌نخورده عبور کنند.
     *
     * @test
     */
    public function arbitrary_controller_exceptions_propagate_unchanged(): void
    {
        $this->arrangeCleanFraudEngine();
        $this->logger->shouldNotReceive('error');

        $request = $this->mockSensitivePostRequest('/wallet/transfer');
        $marker = new \RuntimeException('خطای دامنه‌ی دلخواه');
        $next = function ($req) use ($marker): void {
            throw $marker;
        };

        try {
            $this->middleware->handle($request, $next);
            $this->fail('استثنای کنترلر باید propagate شود.');
        } catch (\RuntimeException $e) {
            $this->assertSame($marker, $e, 'باید دقیقاً همان شیء استثنا باشد.');
        }
    }

    /**
     * رفتار fail-closed برای خرابی «واقعیِ» موتور ضدتقلب باید حفظ شود.
     *
     * این تست مکمل تست‌های بالاست: مرز میان «خطای کنترلر» و «خرابی موتور» باید
     * دقیق بماند — رفع باگ نباید حفاظت M-24 را از بین ببرد.
     *
     * @test
     */
    public function genuine_fraud_engine_failure_still_fails_closed_on_sensitive_route(): void
    {
        $userId = 42;
        $sessionId = 'sess_boom';
        $ip = '1.1.1.1';
        $_SERVER['REMOTE_ADDR'] = $ip;

        $this->session->shouldReceive('has')->with('user_id')->andReturn(true);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId);
        $this->session->shouldReceive('getId')->andReturn($sessionId);
        $this->session->shouldReceive('get')->with('fraud_check_done')->andReturn(true);

        // خرابی واقعی زیرساخت در حین بررسی.
        $this->ipQualityService->shouldReceive('getGeolocation')
            ->andThrow(new \RuntimeException('geoip backend down'));

        $this->logger->shouldReceive('error')->with('fraud.middleware.check_failed', m::type('array'))->once();
        $this->logger->shouldReceive('warning')->with('fraud.middleware.fail_closed', m::type('array'))->once();

        $request = $this->mockSensitivePostRequest('/investment/withdraw');
        $reachedController = false;
        $next = function ($req) use (&$reachedController) {
            $reachedController = true;
            return new Response();
        };

        try {
            $this->middleware->handle($request, $next);
            $this->fail('مسیر حساس باید fail-closed شود.');
        } catch (\Core\Exceptions\HttpResponseException $e) {
            $this->assertSame(503, $e->getResponse()->getStatusCode());
        }

        $this->assertFalse($reachedController, 'هنگام خرابی موتور، کنترلر نباید اجرا شود.');
    }

    /**
     * روی مسیر غیرحساس، خرابی موتور باید fail-open باشد و کنترلر اجرا شود.
     *
     * @test
     */
    public function fraud_engine_failure_on_non_sensitive_route_still_fails_open(): void
    {
        $userId = 42;
        $sessionId = 'sess_open';
        $ip = '1.1.1.1';
        $_SERVER['REMOTE_ADDR'] = $ip;

        $this->session->shouldReceive('has')->with('user_id')->andReturn(true);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId);
        $this->session->shouldReceive('getId')->andReturn($sessionId);
        $this->session->shouldReceive('get')->with('fraud_check_done')->andReturn(true);

        $this->ipQualityService->shouldReceive('getGeolocation')
            ->andThrow(new \RuntimeException('geoip backend down'));

        $this->logger->shouldReceive('error')->with('fraud.middleware.check_failed', m::type('array'))->once();
        $this->logger->shouldNotReceive('warning');

        $request = m::mock(Request::class);
        $request->shouldIgnoreMissing();
        $request->shouldReceive('uri')->andReturn('/dashboard');
        $request->shouldReceive('isPost')->andReturn(false);
        $request->shouldReceive('header')->andReturn(null);

        $response = new Response();
        $reachedController = false;
        $next = function ($req) use ($response, &$reachedController) {
            $reachedController = true;
            return $response;
        };

        $result = $this->middleware->handle($request, $next);

        $this->assertTrue($reachedController, 'مسیر غیرحساس باید fail-open بماند.');
        $this->assertSame($response, $result);
    }

    /**
     * کنترلر باید دقیقاً یک‌بار اجرا شود.
     *
     * پیش از رفع، $next هم در انتهای performFraudChecks و هم در مسیر fail-open
     * وجود داشت. این تست تضمین می‌کند ساختار جدید فراخوانی دوباره ایجاد نکند —
     * که روی مسیرهای مالی به معنای تراکنش تکراری است.
     *
     * @test
     */
    public function controller_is_invoked_exactly_once_on_the_happy_path(): void
    {
        $this->arrangeCleanFraudEngine();

        $request = $this->mockSensitivePostRequest('/investment/withdraw');
        $calls = 0;
        $response = new Response();
        $next = function ($req) use (&$calls, $response) {
            $calls++;
            return $response;
        };

        $result = $this->middleware->handle($request, $next);

        $this->assertSame(1, $calls, 'کنترلر نباید بیش از یک‌بار اجرا شود.');
        $this->assertSame($response, $result);
    }
}
