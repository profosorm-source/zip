<?php

declare(strict_types=1);

namespace Tests\Unit\Middleware;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ باگ C چرخهٔ ۲ — رگرسیون fail-open شدن گارد هم‌زمانی برای Ajax
 * (نسخهٔ سازگار با هر دو پیاده‌سازی — بازبینی نهایی 2026-10-28):
 *
 * ریشهٔ باگ: شاخهٔ پاسخِ تعارضِ قفل (!acquiredLock) داخل همان try قرار داشت
 * که catch(\Throwable) آن برای خطاهای Redis طراحی شده بود. Response::json()
 * در این فریم‌ورک برای short-circuit پایپ‌لاین HttpResponseException پرتاب
 * می‌کند (رفتار H10 در Core\Response::send). نتیجه: در درخواست هم‌زمان دومِ
 * Ajax، پرتاب json() توسط catch بلعیده می‌شد و چون مسیر غیرمالی است (تصمیم
 * fail-open برای خطای واقعی Redis)، اجرا بدون قفل به $next می‌رسید — گارد
 * هم‌زمانی دقیقاً برای سناریوی هدفش (درخواست هم‌زمان دوم) بی‌اثر بود.
 *
 * دو پیاده‌سازیِ رفع‌شده هر دو این تست را پاس می‌کنند (قرارداد، نه مکانیزم):
 *   • FIX-R20-CY2-C: دامنهٔ try محدود به فراخوانی Redis؛ پاسخ بیرون از catch؛
 *   • FIX-R21-AJAX (درخت اصلی): سازندهٔ Response بدون پرتاب (Response-builder)
 *     هم‌سبک RateLimitMiddleware.
 * قراردادِ پین‌شده: تعارض قفل Ajax = ۴۲۹ + JSON + پیام «درخواست قبلی» و
 * $next هرگز اجرا نمی‌شود — فارغ از اینکه ۴۲۹ با استثنا (short-circuit
 * پایپ‌لاین) یا با Response برگشتی برسد.
 *
 * روش تست: هر سناریو در پروسهٔ فرزند مجزا با Redis ماک درون‌حافظه‌ای (الگوی
 * ConcurrentRequestLockReleaseOnExitTest) — نتیجه از طریق فایل JSON تبادل
 * می‌شود؛ تستِ ۱ دقیقاً روی کدِ آلوده fail می‌شود (next_called=true) و روی
 * کدِ رفع‌شده سبز است.
 */
final class ConcurrentRequestLockConflictAjaxTest extends TestCase
{
    private string $phpBinary;

    protected function setUp(): void
    {
        parent::setUp();
        $this->phpBinary = PHP_BINARY ?: 'php';
    }

    /** @return array{mode:string, calls:array<int,array<string,mixed>>, store:array<string,string>, next_called:bool, outcome:array<string,mixed>} */
    private function runWorker(string $mode): array
    {
        $resultFile = sys_get_temp_dir() . '/chortke-lock-conflict-' . $mode . '-' . bin2hex(random_bytes(4)) . '.json';
        @unlink($resultFile);

        $worker = dirname(__DIR__, 2) . '/Support/concurrent_lock_conflict_worker.php';
        $cmd = escapeshellarg($this->phpBinary)
            . ' ' . escapeshellarg($worker)
            . ' ' . escapeshellarg($resultFile)
            . ' ' . escapeshellarg($mode)
            . ' 2>&1';

        $output = [];
        $exitCode = 0;
        exec($cmd, $output, $exitCode);

        $raw = is_file($resultFile) ? (string)file_get_contents($resultFile) : '';
        @unlink($resultFile);

        $this->assertNotSame('', $raw, "worker mode={$mode} باید فایل نتیجه بنویسد (exit={$exitCode}, output=" . implode("\n", $output) . ')');

        $decoded = json_decode($raw, true);
        $this->assertIsArray($decoded, "خروجی worker باید JSON معتبر باشد: {$raw}");
        $this->assertIsArray($decoded['outcome'] ?? null, "خروجی worker باید outcome داشته باشد: {$raw}");
        return $decoded;
    }

    /** @param array<int,array<string,mixed>> $calls */
    private function countOp(array $calls, string $op): int
    {
        $n = 0;
        foreach ($calls as $c) {
            if (($c['op'] ?? '') === $op) {
                $n++;
            }
        }
        return $n;
    }

    /**
     * کد وضعیت نهایی فارغ از مکانیزم: پرتاب HttpResponseException (short-circuit)
     * یا Response برگشتی از handle() — هر دو «رسیدن ۴۲۹ به کلاینت» هستند.
     *
     * @param array<string, mixed> $o
     */
    private function effectiveStatus(array $o): ?int
    {
        if (!empty($o['exception_class'])) {
            return isset($o['status']) ? (int)$o['status'] : null;
        }
        return isset($o['returned_status']) ? (int)$o['returned_status'] : null;
    }

    public function test_ajax_lock_conflict_short_circuits_with_429_json_not_fail_open(): void
    {
        $r = $this->runWorker('ajax-conflict');
        $o = $r['outcome'];

        // مکانیزم مجاز: یا HttpResponseException (FIX-R20-CY2-C) یا Response
        // برگشتی (FIX-R21-AJAX) — هر دو صحیح؛ استثنای دیگری ممنوع
        $this->assertTrue(
            $o['exception_class'] === null
            || $o['exception_class'] === \Core\Exceptions\HttpResponseException::class,
            'مکانیزم مجاز فقط short-circuit پایپ‌لاین یا Response برگشتی است، نه استثنای دیگر: ' . (string)$o['exception_class']
        );

        // هستهٔ قرارداد (و هستهٔ باگ CY2-C): ۴۲۹ با بدنهٔ JSON
        $this->assertSame(429, $this->effectiveStatus($o), 'کد وضعیت تعارض قفل باید 429 باشد');
        $this->assertIsString($o['content_type']);
        $this->assertStringContainsString('application/json', (string)$o['content_type'], 'پاسخ Ajax باید JSON باشد');

        $body = json_decode((string)$o['content'], true);
        $this->assertIsArray($body, 'بدنهٔ پاسخ باید JSON معتبر باشد: ' . (string)$o['content']);
        $this->assertFalse($body['success'] ?? null, 'success باید false باشد');
        $this->assertStringContainsString('درخواست قبلی', (string)($body['message'] ?? ''), 'پیام باید «درخواست قبلی در حال پردازش» باشد');

        // درخواست هم‌زمان دوم هرگز نباید به کنترلر برسد — این همان چیزی است که
        // در کد آلوده (fail-open) رخ می‌داد و این‌جا ممنوع است.
        $this->assertFalse($r['next_called'], 'در تعارض قفل، $next (کنترلر) هرگز نباید اجرا شود — نقض آن یعنی fail-open');

        // تعارض دیده شده (NX blocked) و قفلِ مالکِ دیگر دست‌نخورده مانده
        $this->assertSame(1, $this->countOp($r['calls'], 'set-nx-blocked'), 'یک تلاش NX باید block شده باشد');
        $this->assertSame(0, $this->countOp($r['calls'], 'eval-compare-and-del'), 'قفلِ دیگری نباید آزاد شود');
        $this->assertSame(0, $this->countOp($r['calls'], 'del'), 'قفلِ دیگری نباید del شود');
        $this->assertNotEmpty($r['store'], 'قفل مالکِ دیگر (خارجی) باید سر جایش مانده باشد');
    }

    public function test_plain_lock_conflict_returns_429_text_response(): void
    {
        $r = $this->runWorker('plain-conflict');
        $o = $r['outcome'];

        // بدون Ajax: مسیر بازگشت Response عادی (بدون استثنا) — رفتار قبلی پین می‌شود
        $this->assertNull($o['exception_class'], 'بدون Ajax نباید استثنایی در کار باشد');
        $this->assertSame(429, $this->effectiveStatus($o), 'کد وضعیت تعارض قفل باید 429 باشد');
        $this->assertSame('درخواست همزمان مجاز نیست. لطفا صبر کنید.', (string)$o['content'], 'پیام متنی تعارض قفل');
        $this->assertFalse($r['next_called'], 'در تعارض قفل، $next نباید اجرا شود');
        $this->assertSame(1, $this->countOp($r['calls'], 'set-nx-blocked'));
    }

    public function test_redis_set_error_non_financial_keeps_documented_fail_open(): void
    {
        $r = $this->runWorker('redis-error-nonfinancial');
        $o = $r['outcome'];

        // معناشناسی L-07 باید دست‌نخورده بماند: خطای واقعی Redis روی مسیر
        // غیرمالی → fail-open (دسترس‌پذیری) — هیچ رفعی نباید این تصمیم
        // طراحی‌شده را تغییر دهد.
        $this->assertNull($o['unexpected'], 'نباید استثنای غیرمنتظره‌ای رخ دهد: ' . (string)$o['unexpected']);
        $this->assertNull($o['exception_class'], 'fail-open یعنی بدون short-circuit به $next می‌رسیم');
        $this->assertTrue($r['next_called'], 'خطای Redis روی مسیر غیرمالی باید fail-open بماند (تصمیم L-07)');
        $this->assertSame(1, $this->countOp($r['calls'], 'set-threw'), 'یک خطای شبیه‌سازی‌شدهٔ SET');
        $this->assertSame(0, $this->countOp($r['calls'], 'eval-compare-and-del'), 'قفلی نگرفته‌ایم که آزاد کنیم');
    }

    public function test_redis_set_error_financial_ajax_fails_closed_with_503(): void
    {
        $r = $this->runWorker('redis-error-financial-ajax');
        $o = $r['outcome'];

        // خطای Redis روی مسیر مالی → fail-closed (L-07): serviceUnavailable با
        // ۵۰۳ — باز هم مکانیزم (استثنا یا Response برگشتی) جزو پیاده‌سازی است؛
        // قرارداد: ۵۰۳ JSON و $next هرگز اجرا نمی‌شود.
        $this->assertNull($o['unexpected'], 'نباید استثنای غیرمنتظره‌ای رخ دهد: ' . (string)$o['unexpected']);
        $this->assertTrue(
            $o['exception_class'] === null
            || $o['exception_class'] === \Core\Exceptions\HttpResponseException::class,
            'مکانیزم مجاز فقط short-circuit یا Response برگشتی است: ' . (string)$o['exception_class']
        );
        $this->assertSame(503, $this->effectiveStatus($o), 'خطای Redis روی مسیر مالی = 503 fail-closed');
        $this->assertIsString($o['content_type']);
        $this->assertStringContainsString('application/json', (string)$o['content_type'], 'پاسخ Ajax مالی باید JSON باشد');
        $this->assertFalse($r['next_called'], 'مسیر مالی در نبود Redis هرگز نباید به کنترلر برسد (دابل‌پردازت)');

        $body = json_decode((string)$o['content'], true);
        $this->assertIsArray($body, 'بدنهٔ 503 باید JSON معتبر باشد: ' . (string)$o['content']);
        $this->assertFalse($body['success'] ?? null, 'success باید false باشد');
        $this->assertStringContainsString('سرویس موقتاً در دسترس نیست', (string)($body['message'] ?? ''), 'پیام 503 هم‌قاعدهٔ serviceUnavailable');
    }
}
