<?php

declare(strict_types=1);

namespace Tests\Unit\Deploy;

use PHPUnit\Framework\TestCase;

/**
 * S22 — قفل‌کنندهٔ امنیتی لایهٔ Deploy/Docker (۲۸ فایل — Dockerfileها، دو
 * docker-compose، nginx، php ini، supervisorها، systemdها، اسکریپت‌های
 * worker، logrotate، .dockerignoreها — خط‌به‌خط).
 *
 * پین‌کردن ناورداهای بچ S22:
 *  ① FIX-S22-1: docker-entrypoint.sh هرگز در APP_ENV=production حساب‌های
 *     رمز-شناخته (123456) نمی‌سازد (پاریتی با FIX-S20-3) + انتظار DB
 *     fail-closed است + خطای migrate ماسک نمی‌شود.
 *  ② FIX-S22-2: وب‌سرور (php -S) در هر سه supervisord با user=www-data اجرا
 *     می‌شود — هرگز root.
 *  ③ FIX-S22-3: cron جاب‌ها به‌عنوان www-data اجرا می‌شوند (crontab
 *     /etc/crontabs/www-data + chown) — نه root.
 *  ④ FIX-S22-4: تمام متغیرهای حساس در هر دو compose با :? fail-closed هستند
 *     — فرم خام ${VAR} برای DB_PASS/DB_ROOT_PASSWORD/REDIS_PASSWORD صفر است.
 *  ⑤ FIX-S22-5: تفکیک شبکه frontend / backend(internal:true) در هر دو compose؛
 *     db/redis فقط backend، وب فقط frontend.
 *  ⑥ FIX-S22-7: هر دو .dockerignore مسیرهای حساس storage را از build context
 *     حذف می‌کنند + .env همیشه مستثنی است.
 *  ⑦ FIX-S22-6: php ini هاردن‌شده (display_errors/expose_php خاموش) + کشف
 *     fast_shutdown مرده ممنوع + کپی ini در ایمیج deploy.
 *  ⑧ FIX-S22-11: nginx — رندر poll از طریق front-controller (index.php) +
 *     دایرکتیو limit_req تکراری حذف + server_tokens off + بلاک dotfiles.
 *  ⑨ FIX-S22-8: واحدهای systemd با سندباکس هاردن شده‌اند.
 *  ⑩ FIX-S22-10: workerهای outbox/dlq در compose اداری env کامل DB دارند.
 *  ⑪ .env.docker.example موجود است و هیچ سکرت واقعی‌ای در آن نیست.
 */
final class S22DeployDockerSecurityPinningTest extends TestCase
{
    private const ROOT = __DIR__ . '/../../..';

    private function read(string $relative): string
    {
        $path = self::ROOT . '/' . $relative;
        $this->assertFileExists($path, "فایل deploy مورد انتظار یافت نشد: {$relative}");
        return (string)file_get_contents($path);
    }

    /** استخراج بلاک یک سرویس از compose (کلید در تورفتگی ۲-فاصله تا کلید بعدی) */
    private function yamlServiceBlock(string $yaml, string $service): string
    {
        $lines = preg_split('/\n/', $yaml) ?: [];
        $block = [];
        $in = false;
        foreach ($lines as $line) {
            $isServiceKey = (bool)preg_match('/^  [A-Za-z0-9_-]+:/', $line);
            if ($isServiceKey) {
                if ($block !== []) {
                    break; // سرویس بعدی — پایان بلاک فعلی
                }
                $in = ($line === "  {$service}:");
                if ($in) {
                    $block[] = $line;
                }
                continue;
            }
            if ($in) {
                $block[] = $line;
            }
        }
        $this->assertNotSame([], $block, "بلاک سرویس '{$service}' در compose یافت نشد");
        return implode("\n", $block);
    }

    /** استخراج بلاک یک program از supervisord */
    private function supervisorProgramBlock(string $conf, string $program): string
    {
        $count = preg_match_all(
            '/^\[program:' . preg_quote($program, '/') . '\]\n(?:(?!\[).*\n?)*/m',
            $conf . "\n[EOF]",
            $m
        );
        $this->assertSame(1, $count, "بلاک [program:{$program}] باید دقیقاً یک‌بار باشد");
        return $m[0][0];
    }

    /** سازگار با PHPUnit 8.5 — الگو باید مطابقت داشته باشد */
    private function assertMatches(string $pattern, string $subject, string $message = ''): void
    {
        $this->assertSame(1, preg_match($pattern, $subject), $message . "\n[الگو یافت نشد] {$pattern}");
    }

    /** سازگار با PHPUnit 8.5 — الگو نباید مطابقت داشته باشد */
    private function assertNotMatches(string $pattern, string $subject, string $message = ''): void
    {
        $this->assertSame(0, preg_match($pattern, $subject), $message . "\n[الگوی ممنوع یافت شد] {$pattern}");
    }

    /** ① FIX-S22-1 — گارد production بلاک seed + انتظار fail-closed DB */
    public function testEntrypointRefusesKnownPasswordSeedInProduction(): void
    {
        $src = $this->read('deploy/docker/docker-entrypoint.sh');

        // گارد fail-closed: APP_ENV نامشخص = production = ممنوع
        $this->assertStringContainsString(
            '[ "${APP_ENV:-production}" = "production" ]',
            $src,
            'گارد APP_ENV با پیش‌فرض fail-closed باید موجود باشد'
        );

        // بلاک seed (رمز 123456) باید داخل شاخهٔ else (غیر-production) باشد
        $guardPos = strpos($src, '[ "${APP_ENV:-production}" = "production" ]');
        $elsePos = strpos($src, 'else', $guardPos);
        $fiPos = strpos($src, "\nfi", $elsePos);
        $seedPos = strpos($src, 'password_hash("123456"');
        $this->assertNotFalse($guardPos, 'گارد production یافت نشد');
        $this->assertNotFalse($elsePos, 'شاخهٔ else گارد یافت نشد');
        $this->assertNotFalse($fiPos, 'پایان if گارد یافت نشد');
        $this->assertNotFalse($seedPos, 'بلاک seed باید حفظ شود (فقط در غیر-production)');
        $this->assertTrue(
            $seedPos > $elsePos && $seedPos < $fiPos,
            'بلاک seed رمز-شناخته باید دقیقاً داخل شاخهٔ غیر-production گارد باشد'
        );

        // انتظار DB fail-closed: بعد از حلقهٔ retry، خروج با exit 1
        $this->assertStringContainsString('DB_READY=0', $src);
        $this->assertStringContainsString('exit 1', $src, 'DB غیرقابل‌دسترس باید fail-closed باشد');
        $this->assertStringContainsString('database not reachable after 40 attempts', $src);

        // خطای migrate ماسک نمی‌شود (2>/dev/null حذف شد)
        $this->assertNotMatches(
            '/migrate --force 2>\/dev\/null/',
            $src,
            'stderr مایگریشن نباید دور ریخته شود'
        );
        // R34: پین کهنه «migrate --force || echo» (فرمان غلط + بلع خطا) با فیکس
        // مصوب R30 جایگزین شد: نام واقعی فرمان `migration` است (bootstrap/app.php)
        // و شکست مایگریشن باید entrypoint را fail-closed کند، نه WARN بی‌صدا.
        $this->assertStringContainsString('cli.php migration --force', $src, 'فرمان مایگریشن باید نام واقعی migration باشد');
        $this->assertStringContainsString('ERROR: migration command failed', $src, 'شکست مایگریشن باید fail-closed و پیام‌دار باشد');
        $this->assertNotMatches(
            '/migrate --force \|\| echo/',
            $src,
            'فرمان غلط migrate + بلع خطای || echo نباید برگردد'
        );

        // سینتکس bash معتبر است
        $tmp = tempnam(sys_get_temp_dir(), 's22ep');
        file_put_contents($tmp, $src);
        exec('bash -n ' . escapeshellarg($tmp) . ' 2>&1', $out, $code);
        unlink($tmp);
        $this->assertSame(0, $code, 'سینتکس docker-entrypoint.sh شکست خورد: ' . implode("\n", $out));
    }

    /** ② FIX-S22-2 — وب‌سرور در هر سه supervisord با www-data (نه root) */
    public function testBuiltInWebServerNeverRunsAsRoot(): void
    {
        foreach ([
            'docker/supervisord.conf',
            'deploy/supervisor/supervisord.conf',
            'deploy/docker/supervisord.conf',
        ] as $file) {
            $conf = $this->read($file);
            $web = $this->supervisorProgramBlock($conf, 'chortke-web');
            $this->assertStringContainsString(
                'user=www-data',
                $web,
                "{$file}: وب‌سرور باید user=www-data داشته باشد"
            );
            $this->assertStringContainsString(
                'PHP_CLI_SERVER_WORKERS',
                $web,
                "{$file}: وب‌سرور داخلی باید چند-worker باشد"
            );
        }
    }

    /** ③ FIX-S22-3 — cron جاب‌ها www-data هستند؛ crontab root دیگر تولید نمی‌شود */
    public function testCronJobsRunAsWwwData(): void
    {
        foreach ([
            'docker/supervisord.conf',
            'deploy/supervisor/supervisord.conf',
        ] as $file) {
            $conf = $this->read($file);
            $cron = $this->supervisorProgramBlock($conf, 'chortke-cron');
            $this->assertStringContainsString(
                '/etc/crontabs/www-data',
                $cron,
                "{$file}: crontab باید برای www-data نوشته شود"
            );
            $this->assertNotMatches(
                '/\/etc\/crontabs\/root/',
                $cron,
                "{$file}: crontab root نباید وجود داشته باشد (جاب‌ها root می‌شدند)"
            );
            $this->assertStringContainsString(
                'chown www-data:www-data /etc/crontabs/www-data',
                $cron,
                "{$file}: مالکیت فایل crontab باید www-data باشد (dcron جاب را با UID مالک اجرا می‌کند)"
            );
        }

        // هر دو compose: اسکجولر crontab www-data + chown + chmod 600
        foreach (['docker-compose.yml', 'deploy/docker/docker-compose.yml'] as $file) {
            $yaml = $this->read($file);
            $scheduler = $this->yamlServiceBlock($yaml, 'scheduler');
            $this->assertStringContainsString('/etc/crontabs/www-data', $scheduler, "{$file}: scheduler");
            $this->assertNotMatches('/\/etc\/crontabs\/root/', $scheduler, "{$file}: scheduler نباید crontab root بنویسد");
            $this->assertStringContainsString('chown www-data:www-data /etc/crontabs/www-data', $scheduler, "{$file}: scheduler chown");
            $this->assertStringContainsString('chmod 600 /etc/crontabs/www-data', $scheduler, "{$file}: scheduler chmod");
        }

        // compose ریشه: کانتینر اسکجولر باید root باشد (dcron ریشه می‌خواهد)
        // ولی جاب‌ها از طریق crontab www-data غیرممتاز اجرا می‌شوند.
        $rootYaml = $this->read('docker-compose.yml');
        $scheduler = $this->yamlServiceBlock($rootYaml, 'scheduler');
        $this->assertStringContainsString('user: "0:0"', $scheduler, 'اسکجولر compose ریشه باید user 0:0 داشته باشد (USER www-data تصویر + crond ریشه-نیاز)');
    }

    /** ④ FIX-S22-4 — صفر متغیر حساس خام؛ همه با :? fail-closed */
    public function testComposeSecretsAreFailClosed(): void
    {
        foreach (['docker-compose.yml', 'deploy/docker/docker-compose.yml'] as $file) {
            $yaml = $this->read($file);

            // فرم خام ${VAR} برای متغیرهای حساس ممنوع (بدون :? یا :-)
            $bare = 0;
            foreach (['DB_PASS', 'DB_ROOT_PASSWORD', 'REDIS_PASSWORD', 'DB_NAME', 'DB_USER'] as $var) {
                $count = preg_match_all('/\$\{' . $var . '\}/', $yaml);
                $bare += (int) $count;
            }
            $this->assertSame(
                0,
                $bare,
                "{$file}: {$bare} ارجاع خام به متغیر حساس (بدون :? fail-closed) باقی است"
            );

            // هر متغیر حساس حداقل یک‌بار با :? پین شده است
            foreach (['DB_PASS', 'DB_ROOT_PASSWORD', 'REDIS_PASSWORD'] as $var) {
                $this->assertMatches(
                    '/\$\{' . $var . '\:\?/',
                    $yaml,
                    "{$file}: {$var} باید فرم fail-closed :? داشته باشد"
                );
            }
        }
    }

    /** ⑤ FIX-S22-5 — تفکیک شبکه: db/redis فقط backend داخلی؛ وب فقط frontend */
    public function testComposeNetworkSegmentation(): void
    {
        foreach (['docker-compose.yml', 'deploy/docker/docker-compose.yml'] as $file) {
            $yaml = $this->read($file);

            // تعریف شبکه‌ها
            $this->assertMatches(
                '/^networks:\n  frontend:\n    driver: bridge\n  backend:\n    driver: bridge\n    [^\n]*\n    internal: true/m',
                $yaml,
                "{$file}: backend باید internal: true باشد"
            );

            // db/redis: فقط backend
            foreach (['db', 'redis'] as $svc) {
                $block = $this->yamlServiceBlock($yaml, $svc);
                $this->assertStringContainsString('- backend', $block, "{$file}/{$svc}");
                $this->assertNotMatches('/- frontend\b/', $block, "{$file}/{$svc} نباید روی frontend باشد");
            }
        }

        // compose ریشه: وب فقط frontend
        $web = $this->yamlServiceBlock($this->read('docker-compose.yml'), 'web');
        $this->assertStringContainsString('- frontend', $web);
        $this->assertNotMatches('/- backend\b/', $web, 'وب ریشه نباید روی backend باشد');

        // app/workerها/اسکجولر: هر دو شبکه
        foreach (['docker-compose.yml', 'deploy/docker/docker-compose.yml'] as $file) {
            $yaml = $this->read($file);
            foreach (['app', 'worker-queue', 'worker-outbox', 'worker-dlq', 'scheduler'] as $svc) {
                $block = $this->yamlServiceBlock($yaml, $svc);
                $this->assertStringContainsString('- frontend', $block, "{$file}/{$svc}");
                $this->assertStringContainsString('- backend', $block, "{$file}/{$svc}");
            }
        }
    }

    /** ⑥ FIX-S22-10 — env کامل DB برای workerهای outbox/dlq (ضد crash-loop) */
    public function testDeployComposeWorkersHaveFullDatabaseEnvironment(): void
    {
        $yaml = $this->read('deploy/docker/docker-compose.yml');
        foreach (['worker-outbox', 'worker-dlq'] as $svc) {
            $block = $this->yamlServiceBlock($yaml, $svc);
            foreach (['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASS', 'REDIS_HOST', 'REDIS_PASSWORD'] as $var) {
                $this->assertMatches(
                    '/^      ' . $var . ':/m',
                    $block,
                    "deploy compose/{$svc}: متغیر {$var} گم شده (crash-loop)"
                );
            }
        }
    }

    /** ⑦ FIX-S22-7 — build context بدون storage حساس + .env همیشه مستثنی */
    public function testDockerignoreBlocksSensitiveStorage(): void
    {
        // FIX-R36-W4: deploy/docker/.dockerignore deleted (dead — compose build
        // context is repo root ../.. so only the root .dockerignore applies;
        // zero effective consumers). Root file remains the single pinned guard.
        foreach (['.dockerignore'] as $file) {
            $src = $this->read($file);
            foreach (['storage/sessions/*', 'storage/exports/*', 'storage/backups/*', 'storage/email_fallback/*', 'storage/locks/*'] as $pattern) {
                $this->assertStringContainsString($pattern, $src, "{$file}: الگوی {$pattern} گم شده");
            }
            $this->assertMatches('/^\.env$/m', $src, "{$file}: .env باید در build context نباشد");
        }

        // Dockerfileها: کاربر غیر-ریشه (ریشه) + ini هاردن‌شده در هر دو ایمیج
        $rootDockerfile = $this->read('Dockerfile');
        $this->assertStringContainsString('USER www-data', $rootDockerfile);
        $this->assertStringContainsString('chmod -R 700 /var/www/html/storage', $rootDockerfile);
        $this->assertStringContainsString('COPY docker/php/custom.ini', $rootDockerfile);

        $deployDockerfile = $this->read('deploy/docker/Dockerfile');
        $this->assertStringContainsString('COPY docker/php/custom.ini', $deployDockerfile, 'ایمیج deploy هم باید ini هاردن‌شده داشته باشد');
    }

    /** ⑧ FIX-S22-6 — php ini هاردن‌شده؛ fast_shutdown مرده بازنگردد */
    public function testPhpIniHardening(): void
    {
        $ini = $this->read('docker/php/custom.ini');
        $this->assertMatches('/^display_errors\s*=\s*Off/m', $ini);
        $this->assertMatches('/^display_startup_errors\s*=\s*Off/m', $ini);
        $this->assertMatches('/^log_errors\s*=\s*On/m', $ini);
        $this->assertMatches('/^expose_php\s*=\s*Off/m', $ini);
        $this->assertNotMatches('/^opcache\.fast_shutdown/m', $ini, 'opcache.fast_shutdown در PHP 8 حذف شده است');
        $this->assertMatches('/^opcache\.validate_timestamps\s*=\s*0/m', $ini);
    }

    /** ⑨ FIX-S22-11 — nginx: front-controller برای poll + بهداشت کانفیگ */
    public function testNginxPollRoutesThroughFrontController(): void
    {
        $conf = $this->read('docker/nginx/default.conf');

        // بلاک poll
        $this->assertSame(1, preg_match('/location = \/api\/real-time\/poll \{\n(?:.*\n)*?    \}/', $conf, $m), 'بلاک poll یافت نشد');
        $poll = $m[0];

        $this->assertStringContainsString(
            'fastcgi_param SCRIPT_FILENAME $realpath_root/index.php;',
            $poll,
            'poll باید از طریق front-controller (index.php) رندر شود'
        );
        $this->assertNotMatches('/SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name/', $poll, 'SCRIPT_FILENAME خام برای URI غیر-فایل جواب نمی‌دهد');

        // دایرکتیو limit_req تکراری نباید برگردد
        $limitReqCount = preg_match_all('/^        limit_req zone=longpoll burst=2 nodelay;$/m', $poll);
        $this->assertSame(1, $limitReqCount, 'limit_req باید دقیقاً یک‌بار در بلاک poll باشد');

        // سراسر فایل
        $this->assertStringContainsString('server_tokens off;', $conf);
        $this->assertStringContainsString('location ~ /\.(?!well-known).* {', $conf, 'بلاک ضد-dotfile (.env) باید پابرجا باشد');
        $this->assertStringContainsString('deny all;', $conf);
        $this->assertStringContainsString('add_header X-Frame-Options "SAMEORIGIN" always;', $conf);
        $this->assertStringContainsString('add_header X-Content-Type-Options "nosniff" always;', $conf);
        $this->assertStringContainsString('root /var/www/html/public;', $conf);
    }

    /** ⑩ FIX-S22-8 — سندباکس systemd */
    public function testSystemdUnitsAreSandboxed(): void
    {
        foreach ([
            'deploy/systemd/chortke-queue.service',
            'deploy/systemd/chortke-outbox.service',
        ] as $file) {
            $unit = $this->read($file);
            $this->assertStringContainsString('User=www-data', $unit, $file);
            $this->assertStringContainsString('NoNewPrivileges=true', $unit, $file);
            $this->assertStringContainsString('PrivateTmp=true', $unit, $file);
            $this->assertStringContainsString('ProtectSystem=full', $unit, $file);
            $this->assertStringContainsString('ProtectHome=true', $unit, $file);
        }
    }

    /** ⑪ مستندات هم‌راستا با رفتار واقعی + نمونهٔ env بدون سکرت */
    public function testDeployDocumentationMatchesGuardedBehavior(): void
    {
        $readme = $this->read('deploy/docker/README.md');

        // دیگر ادعای ساخت خودکار حساب 123456 در production ندارد
        $this->assertStringContainsString('refused when `APP_ENV=production`', $readme);
        $this->assertNotMatches(
            '/entrypoint automatically runs migrations and creates basic users/i',
            $readme,
            'README قدیمی باید به‌روز شود'
        );
        // ارجاع به install.sh غایب حذف شده
        $this->assertNotMatches('/deploy\/install\.sh/', $readme);

        // .env.docker.example موجود و عاری از سکرت
        $example = $this->read('deploy/docker/.env.docker.example');
        $this->assertMatches('/^APP_ENV=production$/m', $example);
        foreach (['DB_PASS=', 'DB_ROOT_PASSWORD=', 'REDIS_PASSWORD='] as $emptyVar) {
            $this->assertMatches('/^' . preg_quote($emptyVar, '/') . '\s*$/m', $example, "{$emptyVar} باید خالی باشد (بدون سکرت واقعی)");
        }
        $this->assertNotMatches('/(DB_PASS|REDIS_PASSWORD|DB_ROOT_PASSWORD)=(?!\s*$)\S+/', $example, 'نمونهٔ env نباید سکرت واقعی داشته باشد');
    }

    /** ⑫ پین عمومی بهداشت deploy — اسکریپت‌های worker و logrotate */
    public function testWorkerScriptsAndLogrotateHygiene(): void
    {
        // start-workers فقط bind الکترونی dev/test — بدون rm -rf / curl|bash و...
        $start = $this->read('deploy/scripts/start-workers.sh');
        $this->assertNotMatches('/curl[^|]*\|\s*(ba)?sh/', $start);
        $this->assertNotMatches('/rm\s+-rf\s+\//', $start);

        $health = $this->read('deploy/scripts/health-check-cron.sh');
        $this->assertStringContainsString('distributed:health', $health);
        $this->assertNotMatches('/curl[^|]*\|\s*(ba)?sh/', $health);

        // logrotate: فایل‌های لاگ جدید 0640 www-data (غیرقابل‌خواندن توسط other)
        $logrotate = $this->read('deploy/logrotate/chortke.conf');
        $this->assertStringContainsString('create 0640 www-data www-data', $logrotate);

        // supervisor/README مسیر نصب درست را می‌گوید
        $supReadme = $this->read('deploy/supervisor/README.md');
        $this->assertStringContainsString('chown -R www-data:www-data /var/log/chortke', $supReadme);
    }
}
