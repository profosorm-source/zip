<?php

declare(strict_types=1);

namespace Tests\Unit\Listeners;

use App\Contracts\LoggerInterface;
use App\Contracts\NotificationServiceInterface;
use App\Events\LevelDowngradedEvent;
use App\Listeners\HandleLevelDowngraded;
use Core\Database;
use PHPUnit\Framework\TestCase;

/** T27-13: اعلان انقضا/تنزل + برداشتن نشان فقط در انقضا */
class HandleLevelDowngradedTest extends TestCase
{
    /** PHPUnit 8 نمی‌تواند PDOStatement را (union type در PHP 8) mock کند */
    private function stmt(callable $onExecute): \PDOStatement
    {
        return new class($onExecute) extends \PDOStatement {
            private $cb;
            public function __construct(callable $cb) { $this->cb = $cb; }
            public function execute(?array $params = null): bool { ($this->cb)($params); return true; }
        };
    }

    /** @return array{0:HandleLevelDowngraded,1:\ArrayObject,2:\ArrayObject} */
    private function make(bool $notifyThrows = false): array
    {
        $sent = new \ArrayObject();
        $sql = new \ArrayObject();
        $notif = $this->createMock(NotificationServiceInterface::class);
        if ($notifyThrows) {
            $notif->method('send')->willThrowException(new \RuntimeException('x'));
        } else {
            $notif->method('send')->willReturnCallback(function (...$a) use ($sent) { $sent[] = $a; return true; });
        }
        $db = $this->createMock(Database::class);
        $db->method('prepare')->willReturnCallback(function (string $q) use ($sql) {
            return $this->stmt(function ($p) use ($sql, $q) { $sql[] = [$q, $p]; });
        });
        return [new HandleLevelDowngraded($notif, $this->createMock(LoggerInterface::class), $db), $sent, $sql];
    }

    private function badgeDeletes(\ArrayObject $sql): array
    {
        return array_values(array_filter($sql->getArrayCopy(), fn($s) => str_contains($s[0], 'DELETE FROM user_badges')));
    }

    public function test_expiry_notifies_audits_and_removes_badge(): void
    {
        [$l, $sent, $sql] = $this->make();
        $l->handle(new LevelDowngradedEvent(7, 'gold', 'bronze', 'expired'));
        $this->assertCount(1, $sent);
        $this->assertSame('level_expired', $sent[0][1]);
        $deletes = $this->badgeDeletes($sql);
        $this->assertCount(1, $deletes);
        $this->assertSame([7, 'badge_gold'], $deletes[0][1]);
        $this->assertNotEmpty(array_filter($sql->getArrayCopy(), fn($s) => str_contains($s[0], 'audit_logs')));
    }

    public function test_organic_downgrade_notifies_but_keeps_badge(): void
    {
        [$l, $sent, $sql] = $this->make();
        $l->handle(new LevelDowngradedEvent(7, 'gold', 'silver', 'downgraded'));
        $this->assertSame('level_downgraded', $sent[0][1]);
        $this->assertSame([], $this->badgeDeletes($sql));
    }

    public function test_level_without_badge_does_not_delete_anything(): void
    {
        [$l, , $sql] = $this->make();
        $l->handle(new LevelDowngradedEvent(7, 'bronze', 'bronze', 'expired'));
        $this->assertSame([], $this->badgeDeletes($sql));
    }

    public function test_notification_failure_does_not_block_badge_removal(): void
    {
        [$l, , $sql] = $this->make(true);
        $l->handle(new LevelDowngradedEvent(7, 'vip', 'silver', 'expired'));
        $this->assertCount(1, $this->badgeDeletes($sql));
    }
}
