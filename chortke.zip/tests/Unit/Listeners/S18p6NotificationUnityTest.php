<?php

declare(strict_types=1);

namespace Tests\Unit\Listeners;

use App\Contracts\LoggerInterface;
use App\Listeners\NotificationRequestListener;
use App\Services\AuditTrail;
use App\Services\Notification\NotificationService;
use App\Services\OutboxService;
use Core\Container;
use Core\Database;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * بچ S18.6 — وحدت اعلان‌ها (درِ واحد notification.requested):
 *
 *  - FIX-S18-6A: NotificationRequestListener سه شکل رسمی payload را پشتیبانی می‌کند:
 *      ۱) ساده:    {user_id, type, title, message, data, action_url, ...} → send()
 *      ۲) قالبی:   {user_id, template, template_vars, priority, action_url, ...} → sendFromTemplate()
 *      ۳) ادمین:   {target: 'admins', type, title, message, data, priority} → sendToAdmins()
 *  - FIX-S18-6B..6Q: ۱۸ نقطهٔ تولید اعلان (۱۳ فراخوانی مستقیم sync + ۵ رویداد RPC-shape)
 *      به رویداد استاندارد notification.requested مهاجرت کردند.
 *  - FIX-S18-6R: شاخهٔ RPC شکل قدیمی (payload['notification']['method']) از
 *      OutboxPublisher حذف شد — publishNotification دیگر وجود ندارد.
 *  - FIX-S18-6S: ده متد تخصصی NotificationService + ده جاب تخصصی حذف شدند.
 *
 * گاردهای این تست:
 *   ۱) روتینگ سه شکلِ درِ واحد (اسپای روی NotificationService)
 *   ۲) ثبت واقعی producer→outbox روی MariaDB واقعی (تولیدکنندهٔ نمونه: قرارداد record)
 *   ۳) گارد بازگشت: متدهای تخصصی حذف‌شده نباید در NotificationService باشند
 *   ۴) گارد بازگشت: OutboxPublisher دیگر متد publishNotification ندارد
 *   ۵) گارد یکپارچگی: هیچ متد رشته‌ای RPC-shape ('send_notification'،
 *      'notification.payment_failed_max_retries'، ...) نباید بازتولید شود
 *
 * تست‌های DB روی MariaDB واقعی اجرا می‌شوند (قرارداد S12…S18).
 */
final class S18p6NotificationUnityTest extends TestCase
{
    /** @var list<int> */
    private array $outboxIds = [];

    protected function setUp(): void
    {
        parent::setUp();
        $this->setOutputCallback(static function (string $output): string {
            return '';
        });
    }

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        foreach ($this->outboxIds as $id) {
            try { $db->table('outbox_events')->where('id', '=', $id)->delete(); } catch (\Throwable) {}
        }
        $this->outboxIds = [];
        // پاکسازی binding اسپای از سینگلتون کانتینر (ضد نشت بین تست‌ها).
        try { Container::getInstance()->forget(NotificationService::class); } catch (\Throwable) {}
        Mockery::close();
        parent::tearDown();
    }

    // ─────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────

    private function db(): Database
    {
        return Database::getInstance();
    }

    /**
     * درِ واحد با Container واقعی که NotificationService اسپای‌شده دارد.
     *
     * @param array<string, mixed> $expectations
     */
    private function makeListener(callable $configureSpy): NotificationRequestListener
    {
        /** @var MockInterface&NotificationService $spy */
        $spy = Mockery::mock(NotificationService::class);
        $configureSpy($spy);

        // Container سازندهٔ private دارد — singleton رسمی (قرارداد Core).
        $container = Container::getInstance();
        $container->instance(NotificationService::class, $spy);

        /** @var MockInterface&LoggerInterface $logger */
        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        return new NotificationRequestListener($container, $logger);
    }

    // ─────────────────────────────────────────────────────────────
    // ۱) روتینگ سه شکل درِ واحد
    // ─────────────────────────────────────────────────────────────

    /** @test */
    public function door_routes_simple_shape_to_send(): void
    {
        $listener = $this->makeListener(static function (MockInterface $spy): void {
            $spy->shouldReceive('send')
                ->once()
                ->with(
                    42,
                    'withdrawal.cancelled',
                    'درخواست برداشت لغو شد',
                    Mockery::on(static fn (string $m): bool => str_contains($m, '#9')),
                    // نکته: listener correlation_id را به data تزریق می‌کند — تطابق جزئی.
                    Mockery::on(static fn (array $d): bool => ($d['withdrawal_id'] ?? null) === 9
                        && isset($d['correlation_id'])),
                    '/wallet/history',
                    null,
                    'normal'
                )
                ->andReturn(11);
        });

        // FIX-A6-F2 (Audit Task 6-a): مسیر موفق دست‌نخورده — listener بدون شکست
        // برمی‌گردد و درِ واحد همان شکل args را به send() می‌دهد.
        $listener->handle([
            'user_id'    => 42,
            'type'       => 'withdrawal.cancelled',
            'title'      => 'درخواست برداشت لغو شد',
            'message'    => 'درخواست برداشت #9 لغو شد.',
            'data'       => ['withdrawal_id' => 9],
            'action_url' => '/wallet/history',
        ]);

        // Mockery::close در tearDown انتظار once را بررسی می‌کند.
        $this->assertTrue(true);
    }

    /** @test */
    public function door_propagates_send_failure_to_caller(): void
    {
        // FIX-A6-F2 (Audit Task 6-a): پین رفتار جدید — شکست واقعی ارسال دیگر
        // بلعیده نمی‌شود؛ از listener به بالا پرتاب می‌شود تا OutboxPublisher
        // (dispatchOrFail) رکورد outbox را retry/DLQ کند. (رفتار قبلی: swallow
        // کامل و markAsPublished بلافاصله → گم‌شدن دائمی اعلان.)
        $listener = $this->makeListener(static function (MockInterface $spy): void {
            $spy->shouldReceive('send')
                ->once()
                ->andThrow(new \RuntimeException('notifications table unavailable'));
        });

        try {
            $listener->handle([
                'user_id' => 42,
                'type'    => 'withdrawal.cancelled',
                'title'   => 'درخواست برداشت لغو شد',
                'message' => 'درخواست برداشت #9 لغو شد.',
            ]);
            $this->fail('شکست ارسال باید از listener به بیرون پرتاب شود (جلوسو ممنوع).');
        } catch (\RuntimeException $e) {
            $this->assertSame('notifications table unavailable', $e->getMessage());
        }
    }

    /** @test */
    public function door_reports_deliberate_drop_with_distinct_metric_when_send_returns_null(): void
    {
        // FIX-A6-F2 (Audit Task 6-a): پین رفتار جدید — null از send() یعنی
        // رهاشدنِ عمدی (opt-out ترجیحات یا rate-limit)، نه شکست؛ با متریک مجزای
        // dropped_deliberate ثبت می‌شود، بدون exception و بدون candidate retry.
        /** @var MockInterface&NotificationService $spy */
        $spy = Mockery::mock(NotificationService::class);
        $spy->shouldReceive('send')->once()->andReturn(null);

        $container = Container::getInstance();
        $container->instance(NotificationService::class, $spy);

        /** @var MockInterface&LoggerInterface $logger */
        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $logger->shouldReceive('info')
            ->once()
            ->with(
                'notification.request.dropped_deliberate',
                Mockery::on(static function (array $ctx): bool {
                    return ($ctx['user_id'] ?? null) === 42
                        && ($ctx['type'] ?? null) === 'withdrawal.cancelled'
                        && ($ctx['reason'] ?? null) === 'opt_out_or_rate_limited';
                })
            );

        $listener = new NotificationRequestListener($container, $logger);
        $listener->handle([
            'user_id' => 42,
            'type'    => 'withdrawal.cancelled',
            'title'   => 'درخواست برداشت لغو شد',
            'message' => 'درخواست برداشت #9 لغو شد.',
        ]);

        $this->assertTrue(true);
    }

    /** @test */
    public function door_never_logs_raw_event_payload(): void
    {
        // FIX-A6-F6 (Audit Task 6-a): پین لاگِ allowlist — در مسیر missing_user
        // (و شکست) دیگر کل event خام لاگ نمی‌شود؛ فقط فیلدهای مجاز + نام کلیدهای data.
        /** @var MockInterface&NotificationService $spy */
        $spy = Mockery::mock(NotificationService::class);
        $spy->shouldNotReceive('send');

        $container = Container::getInstance();
        $container->instance(NotificationService::class, $spy);

        $captured = null;
        /** @var MockInterface&LoggerInterface $logger */
        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $logger->shouldReceive('warning')
            ->once()
            ->with(
                'notification.request.missing_user',
                Mockery::on(static function (array $ctx) use (&$captured): bool {
                    $captured = $ctx;
                    return true;
                })
            );

        $listener = new NotificationRequestListener($container, $logger);
        $listener->handle([
            'type'    => 'x',
            'title'   => 't',
            'message' => 'm',
            'data'    => ['password' => 'super-secret', 'withdrawal_id' => 9],
        ]);

        $this->assertIsArray($captured);
        $this->assertArrayHasKey('event', $captured);
        $this->assertArrayNotHasKey('password', $captured['event'], 'payload خام نباید لاگ شود');
        $this->assertSame(['password', 'withdrawal_id'], $captured['event']['data_keys'] ?? null, 'فقط نام کلیدهای data');
        $this->assertStringNotContainsString('super-secret', json_encode($captured, JSON_UNESCAPED_UNICODE) ?: '');
    }

    /** @test */
    public function door_routes_template_shape_to_sendFromTemplate(): void
    {
        $listener = $this->makeListener(static function (MockInterface $spy): void {
            $spy->shouldReceive('sendFromTemplate')
                ->once()
                ->with(
                    77,
                    'withdrawal',
                    Mockery::on(static fn (array $vars): bool => ($vars['amount'] ?? null) === '25,000'
                        && ($vars['currency'] ?? null) === 'IRT'),
                    'high',
                    '/wallet/history',
                    'مشاهده تاریخچه',
                    null,
                    null
                )
                ->andReturn(12);
        });

        $listener->handle([
            'user_id'       => 77,
            'template'      => 'withdrawal',
            'template_vars' => ['amount' => '25,000', 'currency' => 'IRT'],
            'priority'      => 'high',
            'action_url'    => '/wallet/history',
            'action_text'   => 'مشاهده تاریخچه',
        ]);

        $this->assertTrue(true);
    }

    /** @test */
    public function door_routes_admins_shape_to_sendToAdmins(): void
    {
        $listener = $this->makeListener(static function (MockInterface $spy): void {
            $spy->shouldReceive('sendToAdmins')
                ->once()
                ->with(
                    'withdrawal_review',
                    'برداشت گیرکرده',
                    Mockery::on(static fn (string $m): bool => $m !== ''),
                    Mockery::on(static fn (array $d): bool => ($d['withdrawal_id'] ?? null) === 55),
                    'urgent'
                )
                ->andReturn(2);
        });

        $listener->handle([
            'target'   => 'admins',
            'type'     => 'withdrawal_review',
            'title'    => 'برداشت گیرکرده',
            'message'  => 'برداشت #55 بیش از حد مجاز در وضعیت processing است.',
            'data'     => ['withdrawal_id' => 55],
            'priority' => 'urgent',
        ]);

        $this->assertTrue(true);
    }

    /** @test */
    public function door_skips_event_without_user_and_without_admin_target(): void
    {
        $listener = $this->makeListener(static function (MockInterface $spy): void {
            $spy->shouldNotReceive('send');
            $spy->shouldNotReceive('sendFromTemplate');
            $spy->shouldNotReceive('sendToAdmins');
        });

        $listener->handle(['type' => 'x', 'title' => 't', 'message' => 'm']);

        $this->assertTrue(true);
    }

    // ─────────────────────────────────────────────────────────────
    // ۲) ثبت واقعی producer → outbox (MariaDB واقعی)
    // ─────────────────────────────────────────────────────────────

    /** @test */
    public function notification_request_outbox_row_is_persisted_and_publishable_shape(): void
    {
        $db = $this->db();

        /** @var MockInterface&\App\Services\OutboxPublisher $publisher */
        $publisher = Mockery::mock(\App\Services\OutboxPublisher::class);
        $publisher->shouldIgnoreMissing();

        /** @var MockInterface&AuditTrail $auditTrail */
        $auditTrail = Mockery::mock(AuditTrail::class);
        $auditTrail->shouldIgnoreMissing();

        /** @var MockInterface&LoggerInterface $logger */
        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        // OutboxService واقعی: همان سرویسی که تولیدکنندگان واقعی مصرف می‌کنند
        // (فقط وابستگی‌های جانبی حسابرسی/انتشار mock می‌شوند؛ write مسیر واقعی DB است).
        $outbox = new OutboxService($db, $logger, $auditTrail, $publisher);

        $payload = [
            'user_id'    => 7,
            'type'       => 'withdrawal.cancelled',
            'title'      => 'درخواست برداشت لغو شد',
            'message'    => 'درخواست برداشت #9 لغو شد و مبلغ 25,000 irt به موجودی شما بازگشت.',
            'data'       => ['withdrawal_id' => 9],
            'action_url' => '/wallet/history',
        ];

        $ok = $outbox->record('withdrawal', '9', 'notification.requested', $payload);
        $this->assertTrue($ok);

        /** @var \stdClass|null $row */
        $row = $db->selectOne(
            "SELECT * FROM outbox_events WHERE aggregate_type = 'withdrawal' AND aggregate_id = '9'
             AND event_type = 'notification.requested' ORDER BY id DESC LIMIT 1"
        );
        $this->assertNotNull($row);
        $id = (int)$row->id;
        $this->outboxIds[] = $id;
        $this->assertSame('pending', (string)$row->status);

        $decoded = json_decode((string)$row->payload, true);
        $this->assertSame(7, $decoded['user_id'] ?? null);
        $this->assertSame('withdrawal.cancelled', $decoded['type'] ?? null);
        $this->assertSame('/wallet/history', $decoded['action_url'] ?? null);
    }

    // ─────────────────────────────────────────────────────────────
    // ۳) گاردهای بازگشت کد مرده (سطح متد/کلاس)
    // ─────────────────────────────────────────────────────────────

    /** @test */
    public function notification_service_specialized_shortcuts_are_gone(): void
    {
        $removed = [
            'depositSuccess',
            'withdrawalApproved',
            'withdrawalRejected',
            'kycVerified',
            'kycRejected',
            'securityAlert',
            'lotteryWinner',
            'referralEarning',
            'investmentCompleted',
            'newTaskAvailable',
            'sendToChannel',
        ];
        foreach ($removed as $method) {
            $this->assertFalse(
                method_exists(NotificationService::class, $method),
                "متد تخصصی حذف‌شده نباید وجود داشته باشد: NotificationService::{$method}"
            );
        }
    }

    /** @test */
    public function interface_no_longer_declares_depositSuccess(): void
    {
        $this->assertFalse(
            method_exists(\App\Contracts\NotificationServiceInterface::class, 'depositSuccess'),
            'متد depositSuccess باید از NotificationServiceInterface حذف شده باشد'
        );
    }

    /**
     * به‌روزرسانی پین (FIX-S21-1 / کانسالت C4 — تصمیم جدیدتر از FIX-S18-6R):
     * publishNotification با شکل RPC حذف نشد؛ به‌جای آن با whitelist بستهٔ
     * ALLOWED_NOTIFICATION_METHODS=['send','sendToAdmins'] سخت‌سازی شد
     * (تخطی = RuntimeException fail-loud → retry کران‌دار → DLQ). راستی‌آزمایی
     * C4 هر ۶ نویسندهٔ زندهٔ شاخهٔ notification را با همین whitelist پوشش داد.
     *
     * FIX-A6-F2 (Audit Task 6-a): داکبلاک دوتایی قبلی باعث می‌شد این تست هرگز
     * اجرا نشود (فقط آخرین docblock به PHPUnit می‌رسد و @test آن گم می‌شد) و
     * اعلان ثابتِ ALLOWED_NOTIFICATION_METHODS هم در OutboxPublisher به شکل
     * const نام‌دار درآمد تا این پین مستقیماً روی declaration قفل باشد.
     *
     * @test
     */
    public function outbox_publisher_rpc_shape_is_whitelist_guarded(): void
    {
        $this->assertTrue(
            method_exists(\App\Services\OutboxPublisher::class, 'publishNotification'),
            'publishNotification (نسخهٔ سخت‌سازی‌شدهٔ C4) باید موجود باشد'
        );
        $src = (string)file_get_contents((string)(new \ReflectionClass(\App\Services\OutboxPublisher::class))->getFileName());
        $this->assertStringContainsString(
            "ALLOWED_NOTIFICATION_METHODS = ['send', 'sendToAdmins']",
            $src,
            'whitelist بستهٔ C4 باید پابرجا باشد'
        );
        $this->assertStringContainsString(
            'not whitelisted',
            $src,
            'تخطی whitelist باید fail-loud باشد (RuntimeException)'
        );
    }

    /** @test */
    public function producer_sites_no_longer_call_notification_service_directly(): void
    {
        // فایل‌هایی که در S18.6 به درِ واحد مهاجرت کردند — دیگر نباید فراخوانی
        // مستقیم متدهای ارسال NotificationService را داشته باشند (فقط برای جلوگیری
        // از بازگشت ناخواسته؛ تست‌های رفتاری جداگانه قرارداد هر مهاجرت را قفل کرده‌اند).
        $files = [
            (new \ReflectionClass(\App\Services\Withdrawal\WithdrawalAdminService::class))->getFileName(),
            (new \ReflectionClass(\App\Services\Withdrawal\WithdrawalUserService::class))->getFileName(),
            (new \ReflectionClass(\App\Services\CryptoDeposit\CryptoDepositService::class))->getFileName(),
            (new \ReflectionClass(\App\Services\Lottery\LotteryCommandService::class))->getFileName(),
            (new \ReflectionClass(\App\Services\KYC\KYCCommandService::class))->getFileName(),
            (new \ReflectionClass(\App\Services\Auth\TwoFactorService::class))->getFileName(),
            (new \ReflectionClass(\App\Listeners\WithdrawalListener::class))->getFileName(),
            (new \ReflectionClass(\App\Listeners\TaskCompletedListener::class))->getFileName(),
            // 🧹 FIX-M22-CLOSE (F2): ReconcilePaymentsJob حذف شد (زنجیرهٔ صفر-دیسپچر
            // همراه ProcessPaymentCallbackJob) — انعکاس فایلِ حذف‌شده از فهرست برداشته شد.
            (new \ReflectionClass(\App\Services\ReconciliationService::class))->getFileName(),
            (new \ReflectionClass(\App\Services\Interaction\ReportService::class))->getFileName(),
            (new \ReflectionClass(\App\Jobs\Vitrine\ReportVitrineListingJob::class))->getFileName(),
        ];
        foreach ($files as $file) {
            $src = (string)file_get_contents((string)$file);
            // PHPUnit 8.5: assertDoesNotMatchRegularExpression ندارد — معادل با preg_match.
            $hit = (bool)preg_match(
                '/->\s*(send|kycVerified|kycRejected|securityAlert|withdrawalApproved|withdrawalRejected|depositSuccess|lotteryWinner)\s*\(/i',
                $src
            );
            $this->assertFalse(
                $hit,
                'این فایل باید فقط از درِ واحد notification.requested اعلان بفرستد: ' . (string)$file
            );
        }
    }
}
