<?php

declare(strict_types=1);

namespace Tests\Unit\Listeners;

use App\Events\FeatureFlagChanged;
use App\Events\Registry\EventRegistry;
use App\Contracts\LoggerInterface;
use Core\Cache;
use Core\EventDispatcher;
use Core\GenericEvent;
use Core\Queue;
use Mockery as m;
use Mockery\Adapter\Phpunit\MockeryPHPUnitIntegration;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-R22-B6 — قفل سیم‌کشی رویدادهای بی‌شنوندهٔ راند ۲۱-C (D1/D2/D4/D5/D3)
 *
 * سه لایهٔ ادعا:
 *  ۱) منبعِ ثبت: AppServiceProvider دقیقاً همین ثبت‌ها را دارد (لایهٔ قفل منبع —
 *     وکتور بازگشت باگ D1 حذفِ بی‌سروصدای خطوط listen بود).
 *  ۲) رزولوشن: EventDispatcher با همان امضاهای ثبت، شنونده برای هر نام resolve می‌کند.
 *  ۳) رفتار: payload قرارداد تولیدکننده‌ها (['key'=>...] برای cache.invalidate و
 *     ['service','error'] برای circuit_breaker.*) تا انتهای لیسنر سالم می‌رسد.
 *  ۴) منفی: نام legacy 'content.revenue_paid' (FIX-R22-B3) باید بی‌شنونده بماند.
 *
 * بدون دیتابیس/ردیس — فقط Mockery (همان الگوی Unit/Listeners/ListenersBehaviorTest).
 *
 * @group architecture
 */
final class EventWiringR22Test extends TestCase
{
    use MockeryPHPUnitIntegration;

    protected function setUp(): void
    {
        parent::setUp();
        // الگوی EventDispatcherRegistrationBehaviorTest: dispatch لاگ INFO به stdout می‌نویسد
        $this->expectOutputRegex('/.*/');
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    // ─── ۱) لایهٔ قفل منبع: ثبت‌ها واقعاً در AppServiceProvider هستند ─────────

    public function test_provider_source_registers_r22_listeners(): void
    {
        $path = dirname(__DIR__, 3) . '/app/Providers/AppServiceProvider.php';
        $src = file_get_contents($path);
        $this->assertIsString($src, 'AppServiceProvider.php must be readable');

        $expected = [
            // FIX-R22-B1
            "\$container->singleton(\App\Listeners\CacheInvalidateListener::class);",
            "\$contentEvents->listen('cache.invalidate', [\App\Listeners\CacheInvalidateListener::class, 'handle']);",
            // FIX-R22-B2
            "\$container->singleton(\App\Listeners\AuditCircuitBreakerState::class);",
            "\$contentEvents->listen('circuit_breaker.opened', [\App\Listeners\AuditCircuitBreakerState::class, 'handleOpened']);",
            "\$contentEvents->listen('circuit_breaker.closed', [\App\Listeners\AuditCircuitBreakerState::class, 'handleClosed']);",
            // FIX-R22-B4
            "\$container->singleton(\App\Listeners\LogFeatureFlagChange::class);",
            "\$contentEvents->listen(\App\Events\FeatureFlagChanged::class, [\App\Listeners\LogFeatureFlagChange::class, 'handle']);",
            // FIX-R22-B5
            "\$container->singleton(\App\Listeners\AuditRegistryEvent::class);",
            "\$contentEvents->listen(\App\Events\Registry\EventRegistry::CRYPTO_DEPOSIT_CONFIRMED, [\App\Listeners\AuditRegistryEvent::class, 'handle']);",
            "\$contentEvents->listen(\App\Events\Registry\EventRegistry::REFERRAL_COMMISSION_EARNED, [\App\Listeners\AuditRegistryEvent::class, 'handle']);",
            "\$contentEvents->listen(\App\Events\Registry\EventRegistry::INFLUENCER_ORDER_PARTIAL_REFUNDED, [\App\Listeners\AuditRegistryEvent::class, 'handle']);",
        ];

        foreach ($expected as $needle) {
            $this->assertStringContainsString($needle, $src, "AppServiceProvider must wire: {$needle}");
        }

        // FIX-R22-B3: ثبت legacy حذف شده باشد.
        $this->assertStringNotContainsString("listen('content.revenue_paid'", $src, 'legacy content.revenue_paid registration must stay removed');
    }

    // ─── ۲) رزولوشن: دیسپچر با امضای ثبت، شنونده resolve می‌کند ───────────────

    public function test_dispatcher_resolves_r22_wired_listeners(): void
    {
        $dispatcher = new EventDispatcher(m::mock(Queue::class));

        // دقیقاً همان امضاهای AppServiceProvider
        $dispatcher->listen('cache.invalidate', [\App\Listeners\CacheInvalidateListener::class, 'handle']);
        $dispatcher->listen('circuit_breaker.opened', [\App\Listeners\AuditCircuitBreakerState::class, 'handleOpened']);
        $dispatcher->listen('circuit_breaker.closed', [\App\Listeners\AuditCircuitBreakerState::class, 'handleClosed']);
        $dispatcher->listen(FeatureFlagChanged::class, [\App\Listeners\LogFeatureFlagChange::class, 'handle']);
        $dispatcher->listen(EventRegistry::CRYPTO_DEPOSIT_CONFIRMED, [\App\Listeners\AuditRegistryEvent::class, 'handle']);
        $dispatcher->listen(EventRegistry::REFERRAL_COMMISSION_EARNED, [\App\Listeners\AuditRegistryEvent::class, 'handle']);
        $dispatcher->listen(EventRegistry::INFLUENCER_ORDER_PARTIAL_REFUNDED, [\App\Listeners\AuditRegistryEvent::class, 'handle']);

        foreach ([
            'cache.invalidate',
            'circuit_breaker.opened',
            'circuit_breaker.closed',
            FeatureFlagChanged::class,
            EventRegistry::CRYPTO_DEPOSIT_CONFIRMED,
            EventRegistry::REFERRAL_COMMISSION_EARNED,
            EventRegistry::INFLUENCER_ORDER_PARTIAL_REFUNDED,
        ] as $name) {
            $this->assertSame(1, count($dispatcher->getListeners($name)), "listener must resolve for {$name}");
        }

        // منفی: نام legacy حذف‌شده بی‌شنونده می‌ماند
        $this->assertSame(0, count($dispatcher->getListeners('content.revenue_paid')));
    }

    // ─── ۳) رفتار: payload قرارداد تولیدکننده‌ها سالم به لیسنر می‌رسد ─────────

    /** تولیدکننده‌ها dispatch('cache.invalidate', ['key' => ...]) می‌کنند (D1). */
    public function test_cache_invalidate_listener_forgets_payload_key(): void
    {
        $cache = m::mock(Cache::class);
        $cache->shouldReceive('forget')->once()->with('r22:test:key')->andReturnTrue();
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldReceive('info')->once()->with('cache.invalidate.event', ['key' => 'r22:test:key']);

        (new \App\Listeners\CacheInvalidateListener($cache, $logger))
            ->handle(new GenericEvent(['key' => 'r22:test:key']));
    }

    /** CircuitBreaker dispatch می‌کند: ['service'=>..., 'error'=>...] (D2). */
    public function test_circuit_breaker_opened_listener_logs_and_audits(): void
    {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldReceive('warning')->once()->with('circuit_breaker.opened', [
            'channel' => 'circuit_breaker',
            'service' => 'payment_gateway',
            'error'   => 'boom',
        ]);
        $auditTrail = m::mock(\App\Services\AuditTrail::class);
        $auditTrail->shouldReceive('record')->once()->with('circuit_breaker.opened', null, m::any());

        (new \App\Listeners\AuditCircuitBreakerState($logger, $auditTrail))
            ->handleOpened(new GenericEvent(['service' => 'payment_gateway', 'error' => 'boom']));
    }

    /** رویداد تایپ‌دار FeatureFlagChanged بدون downgrade به GenericEvent می‌رسد (D5). */
    public function test_feature_flag_changed_reaches_log_listener_typed(): void
    {
        $received = null;
        $dispatcher = new EventDispatcher(m::mock(Queue::class));
        $dispatcher->listen(FeatureFlagChanged::class, static function (FeatureFlagChanged $event) use (&$received): void {
            $received = $event;
        });

        $event = new FeatureFlagChanged('feature_x', 'toggled', ['enabled' => false], ['enabled' => true], 7);
        $dispatcher->dispatch($event::class, $event);

        $this->assertInstanceOf(FeatureFlagChanged::class, $received);
        $this->assertSame('feature_x', $received->featureName);
        $this->assertSame('toggled', $received->action);
    }
}
