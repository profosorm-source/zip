<?php

declare(strict_types=1);

namespace Tests\Unit\Listeners;

use App\Contracts\AntiFraud\FraudGuardInterface;
use App\Contracts\LoggerInterface;
use App\Contracts\NotificationServiceInterface;
use App\Contracts\WalletServiceInterface;
use App\Events\AuditRecordedEvent;
use App\Events\ScoreDeltaAppendedEvent;
use App\Enums\ModuleContext;
use App\Listeners\ContentEventListeners;
use App\Listeners\HandlePaymentCompleted;
use App\Listeners\HandleRateLimitExceeded;
use App\Listeners\LogUserRegisteredActivity;
use App\Listeners\PersistAuditRecordListener;
use App\Listeners\ProcessFraudAlert;
use App\Listeners\WalletDepositRequestListener;
use App\Jobs\Notification\SendNotificationJob;
use App\Models\AuditTrail as AuditTrailModel;
use App\Services\Cache\CacheInvalidationService;
use App\Services\EmailService;
use App\Services\DistributedLockService;
use App\Services\Gamification\TrustService;
use App\Services\Gamification\XpService;
use App\Services\Notification\NotificationService;
use App\Services\OutboxService;
use App\Services\ScoreService;
use App\Services\Settings\AppSettings;
use App\Services\Shared\IdempotencyService;
use App\Services\Shared\ReferralService;
use App\Services\User\UserService;
use App\Services\Wallet\WalletMutationService;
use App\Services\Wallet\WalletQueryService;
use App\Services\Wallet\WalletService;
use Core\Cache;
use Core\Container;
use Core\Database;
use Core\EventDispatcher;
use Core\GenericEvent;
use App\Domain\Gamification\Strategies\TrustEvaluationStrategy;
use PHPUnit\Framework\TestCase;

/**
 * بچ S18 — قفل رفتاری فیکس‌های Events + Listeners:
 *
 *  - FIX-S18-1: گیت ضدتقلب wallet.transfer مستقیم در WalletService (لیسنرِ
 *    FraudGuardListener هرگز register نشده بود و dispatch استثنا را هم بلعیده
 *    می‌دهد ⇒ P2P transfer از velocity/sybil/ML عبور می‌کرد).
 *  - FIX-S18-2: شاخهٔ dead-letter واریز، ردیف outbox جانشین نمی‌سازد (قطع
 *    زنجیرهٔ خودتکثیر ∞)؛ مسیر retry کران‌دار 1..3 حفظ شده.
 *  - FIX-S18-3: پروجکشن امتیاز با score_event_id در IdempotencyService —
 *    تحویل تکراری دلتا را دوباره اعمال نمی‌کند (at-least-once ⇒ once).
 *  - FIX-S18-4: فلگ IP فقط در مرز دقیق آستانه (۱ ردیف per IP per window).
 *  - FIX-S18-5: زنجیرهٔ ایمیل تأیید — ستون token هش HMAC است و لیسنر فقط
 *    plainToken رویداد را ایمیل می‌کند (fallback هش حذف شد).
 *  - FIX-S18-6: کلید idempotency trust با dedup_id per-execution.
 *  - FIX-S18-7: ماسک بازگشتی حسابرسی + سقف عمق/طول.
 *  - FIX-S18-8: گارد action_url نویسندهٔ مرکزی in-app (javascript: → null،
 *    مسیر نسبی same-site و http(s) مطلق مجاز).
 *  - FIX-S18-9: هشدار تقلب حداکثر یک ردیف per کاربر per ساعت.
 *  - FIX-S18-10: reason اعلان‌های ردِ سفارش/محتوا strip_tags + سقف ۵۰۰.
 *  - FIX-S18-11: رویداد پرداختِ بی‌هویت (transaction_id خالی) skip + هشدار.
 *
 * تست‌های DB روی MariaDB واقعی اجرا می‌شوند (قرارداد S12…S17).
 */
final class S18EventsListenersHardeningTest extends TestCase
{
    /** @var list<string> */
    private array $cleanupTables = [];
    /** @var list<int> */
    private array $cleanupIds = [];
    /** @var list<string> */
    private array $cleanupSql = [];

    protected function setUp(): void
    {
        parent::setUp();
        // الگوی S17: لاگرهای داخلی مستقیماً روی stdout می‌نویسند — خروجیِ
        // موردانتظار تست‌ها ساکت می‌شود تا PHPUnit آن را خطا نشمارد.
        $this->setOutputCallback(static function (string $output): string {
            return '';
        });
    }

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        foreach ($this->cleanupSql as $sql) {
            try {
                $db->execute($sql, []);
            } catch (\Throwable) {
            }
        }
        foreach ($this->cleanupIds as $i => $id) {
            $table = $this->cleanupTables[$i] ?? null;
            if ($table === null) {
                continue;
            }
            try {
                $db->table($table)->where('id', '=', $id)->delete();
            } catch (\Throwable) {
            }
        }
        $this->cleanupIds = [];
        $this->cleanupTables = [];
        $this->cleanupSql = [];
        \Mockery::close();
        parent::tearDown();
    }

    private function trackCleanup(string $table, int $id): void
    {
        $this->cleanupTables[] = $table;
        $this->cleanupIds[] = $id;
    }

    private function db(): Database
    {
        return Database::getInstance();
    }

    private function container(): Container
    {
        return Container::getInstance();
    }

    private function mockSettings(): AppSettings
    {
        $s = \Mockery::mock(AppSettings::class);
        $s->shouldReceive('get')->andReturn(null);
        return $s;
    }

    /** لاگر lenient — متدهای error/info/warning/activity بدون انتظار صریح مجازند */
    private function lenientLogger(): LoggerInterface
    {
        return \Mockery::mock(LoggerInterface::class)->shouldIgnoreMissing();
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-1 — گیت ضدتقلب wallet.transfer
    // ─────────────────────────────────────────────────────────────

    public function test_transfer_blocked_by_fraud_gate_before_locks(): void
    {
        $db = \Mockery::mock(Database::class);
        // گیرنده و فرستنده موجود (دو COUNT) — گیت باید بعدشان و قبل از قفل بگذرد
        $db->shouldReceive('fetchColumn')->twice()->andReturn(1);

        $lock = \Mockery::mock(DistributedLockService::class);
        $lock->shouldReceive('synchronized')->never(); // گیت باید «پیش از» قفل باشد

        $fraud = \Mockery::mock(FraudGuardInterface::class);
        $fraud->shouldReceive('checkAction')
            ->once()
            ->with(5, 'wallet.transfer', \Mockery::on(static function (array $ctx): bool {
                return (int)($ctx['to_user_id'] ?? 0) === 6
                    && isset($ctx['amount'], $ctx['currency']);
            }))
            ->andReturn(['allowed' => false, 'reason' => 'velocity']);

        $svc = new WalletService(
            \Mockery::mock(EventDispatcher::class),
            $db,
            $this->lenientLogger(),
            \Mockery::mock(IdempotencyService::class),
            $lock,
            \Mockery::mock(WalletQueryService::class),
            \Mockery::mock(WalletMutationService::class),
            $this->mockSettings(),
            $fraud
        );

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('انتقال وجه به دلیل محدودیت‌های امنیتی مجاز نیست');
        $svc->transfer(5, 6, '1000', 'irt', 's18', null);
    }

    public function test_transfer_gate_invoked_with_wallet_transfer_action_and_propagates(): void
    {
        $db = \Mockery::mock(Database::class);
        $db->shouldReceive('fetchColumn')->twice()->andReturn(1);

        $fraud = \Mockery::mock(FraudGuardInterface::class);
        $fraud->shouldReceive('checkAction')
            ->once()
            ->with(5, 'wallet.transfer', \Mockery::type('array'))
            ->andThrow(new \RuntimeException('stop-after-gate'));

        $svc = new WalletService(
            \Mockery::mock(EventDispatcher::class),
            $db,
            $this->lenientLogger(),
            \Mockery::mock(IdempotencyService::class),
            \Mockery::mock(DistributedLockService::class),
            \Mockery::mock(WalletQueryService::class),
            \Mockery::mock(WalletMutationService::class),
            $this->mockSettings(),
            $fraud
        );

        try {
            $svc->transfer(5, 6, '1000', 'irt', 's18', null);
            $this->fail('پرتاب استثنای گیت بعد از checkAction باید از transfer بیرون بزند');
        } catch (\RuntimeException $e) {
            $this->assertSame('stop-after-gate', $e->getMessage(), 'گیت باید دقیقاً با action=wallet.transfer صدا شود و استثنایش propagate شود');
        }
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-2 — قطع زنجیرهٔ خودتکثیر outbox در dead-letter
    // ─────────────────────────────────────────────────────────────

    private function makeDepositListener(OutboxService $outbox, WalletServiceInterface $wallet, IdempotencyService $idem): WalletDepositRequestListener
    {
        return new WalletDepositRequestListener(
            $wallet,
            $this->lenientLogger(),
            $outbox,
            $idem,
            Database::getInstance()
        );
    }

    public function test_deposit_dead_letter_records_no_successor_outbox_row(): void
    {
        $wallet = \Mockery::mock(WalletServiceInterface::class);
        $wallet->shouldReceive('deposit')->andReturn(['success' => false]);

        $idem = \Mockery::mock(IdempotencyService::class);
        $idem->shouldReceive('executeWithTransaction')->andReturn(['success' => false]);

        $outbox = \Mockery::mock(OutboxService::class);
        $outbox->shouldReceive('record')->never(); // 🛡️ dead-letter = بدون ردیف جانشین

        $listener = $this->makeDepositListener($outbox, $wallet, $idem);
        $listener->handle(new GenericEvent([
            'user_id' => 1,
            'amount' => '1000',
            'currency' => 'irt',
            'metadata' => ['retry_count' => 3, 'idempotency_key' => 's18_dl_key'],
        ]));

        // اگر تا اینجا بدون record رسیده باشد، زنجیرهٔ بی‌پایان بسته است
        $this->assertTrue(true);
    }

    public function test_deposit_exception_dead_letter_records_no_successor_row(): void
    {
        $wallet = \Mockery::mock(WalletServiceInterface::class);
        $wallet->shouldReceive('deposit')->andThrow(new \RuntimeException('frozen wallet'));

        $idem = \Mockery::mock(IdempotencyService::class);
        $idem->shouldReceive('executeWithTransaction')->andThrow(new \RuntimeException('frozen wallet'));

        $outbox = \Mockery::mock(OutboxService::class);
        $outbox->shouldReceive('record')->never();

        $listener = $this->makeDepositListener($outbox, $wallet, $idem);
        $listener->handle(new GenericEvent([
            'user_id' => 1,
            'amount' => '1000',
            'currency' => 'irt',
            'metadata' => ['retry_count' => 3],
        ]));

        $this->assertTrue(true);
    }

    public function test_deposit_bounded_retry_still_records_successor_once(): void
    {
        $wallet = \Mockery::mock(WalletServiceInterface::class);
        $wallet->shouldReceive('deposit')->andReturn(['success' => false]);

        $idem = \Mockery::mock(IdempotencyService::class);
        $idem->shouldReceive('executeWithTransaction')->andReturn(['success' => false]);

        $captured = null;
        $outbox = \Mockery::mock(OutboxService::class);
        $outbox->shouldReceive('record')
            ->once()
            ->with('wallet', '1', 'wallet.deposit.requested', \Mockery::on(static function (array $p) use (&$captured): bool {
                $captured = $p;
                return (int)($p['metadata']['retry_count'] ?? 0) === 1; // retry کران‌دار ۱→۲→۳
            }));

        $listener = $this->makeDepositListener($outbox, $wallet, $idem);
        $listener->handle(new GenericEvent([
            'user_id' => 1,
            'amount' => '1000',
            'currency' => 'irt',
            'metadata' => ['idempotency_key' => 's18_retry_key'],
        ]));

        $this->assertNotNull($captured, 'مسیر retry کران‌دار باید یک ردیف جانشین با retry_count=1 بسازد');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-3 — پروجکشن امتیاز: تحویل تکراری = اعمالِ یک‌بار
    // ─────────────────────────────────────────────────────────────

    public function test_score_projection_duplicate_delivery_applies_delta_once(): void
    {
        $db = $this->db();
        $uid = 1;
        $domain = 's18probe';

        $eventId = (int)$db->table('score_events')->insert([
            'entity_type' => 'user', 'entity_id' => $uid, 'domain' => $domain,
            'delta' => 10, 'reason' => 's18-dedup-probe', 'metadata' => '{}',
        ]);
        $this->assertGreaterThan(0, $eventId);
        $this->trackCleanup('score_events', $eventId);
        $this->cleanupSql[] = "DELETE FROM user_scores WHERE user_id = {$uid} AND domain = '{$domain}'";
        $this->cleanupSql[] = "DELETE FROM idempotency_keys WHERE `action` = 'score_projection' AND user_id = {$uid}";

        /** @var \App\Listeners\ScoreProjectionListener $listener */
        $listener = $this->container()->make(\App\Listeners\ScoreProjectionListener::class);
        $event = new ScoreDeltaAppendedEvent('user', $uid, $domain, 10, 's18-probe', $eventId);

        $listener->handle($event);
        $listener->handle($event); // تحویل تکراری (at-least-once)
        $listener->handle($event);

        $score = (float)$db->fetchColumn(
            "SELECT score FROM user_scores WHERE user_id = ? AND domain = ?",
            [$uid, $domain]
        );
        $this->assertSame(10.0, $score, 'دلتا باید دقیقاً یک‌بار اعمال شده باشد نه سه‌بار');

        $keyCount = (int)$db->fetchColumn(
            "SELECT COUNT(*) FROM idempotency_keys WHERE `action` = 'score_projection' AND user_id = ?",
            [$uid]
        );
        $this->assertGreaterThanOrEqual(1, $keyCount, 'کلید idempotency پروجکشن باید ثبت شده باشد');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-4 — فلگ IP فقط در مرز دقیق آستانه
    // ─────────────────────────────────────────────────────────────

    public function test_rate_limit_ip_flag_inserted_only_at_exact_threshold(): void
    {
        $marker = 's18-flag-' . bin2hex(random_bytes(4));

        $buildListener = function (int $countAtViolation) use ($marker): HandleRateLimitExceeded {
            $cache = \Mockery::mock(Cache::class);
            $cache->shouldReceive('get')->andReturn(true); // cooldown فعال → فقط مسیر فلگ
            $cache->shouldReceive('increment')->andReturn($countAtViolation);
            return new HandleRateLimitExceeded(
                \Mockery::mock(NotificationServiceInterface::class)->shouldIgnoreMissing(),
                $this->lenientLogger(),
                $cache,
                Database::getInstance()
            );
        };

        $before = (int)$this->db()->fetchColumn(
            "SELECT COUNT(*) FROM suspect_flags WHERE reason LIKE ?",
            ["%{$marker}%"]
        );

        // زیر آستانه، در آستانه، بالای آستانه — فقط «۵» باید ردیف بسازد
        $buildListener(4)->handle(new GenericEvent(['key' => $marker, 'ip' => '203.0.113.9']));
        $buildListener(5)->handle(new GenericEvent(['key' => $marker, 'ip' => '203.0.113.9']));
        $buildListener(6)->handle(new GenericEvent(['key' => $marker, 'ip' => '203.0.113.9']));

        $after = (int)$this->db()->fetchColumn(
            "SELECT COUNT(*) FROM suspect_flags WHERE reason LIKE ?",
            ["%{$marker}%"]
        );
        $this->assertSame($before + 1, $after, 'دقیقاً یک فلگ در مرز آستانه — نه در ۴ و نه در ۶');

        $this->cleanupSql[] = "DELETE FROM suspect_flags WHERE reason LIKE '%{$marker}%'";
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-5 — زنجیرهٔ ایمیل تأیید ثبت‌نام
    // ─────────────────────────────────────────────────────────────

    public function test_registration_email_never_uses_stored_hash_fallback(): void
    {
        $email = \Mockery::mock(EmailService::class);
        $email->shouldReceive('sendVerificationEmail')->never(); // بدون plainToken → skip

        $user = \Mockery::mock(UserService::class);
        $user->shouldReceive('find')->andReturn((object)['id' => 1, 'email' => 'x@y.z']);

        $listener = new LogUserRegisteredActivity(
            $this->lenientLogger(),
            $user,
            $email
        );
        $listener->handle(new \App\Events\UserRegisteredEvent(1, 'x@y.z', '127.0.0.1', null));
        $this->assertTrue(true);
    }

    public function test_registration_email_uses_plain_token_from_event(): void
    {
        $email = \Mockery::mock(EmailService::class);
        $email->shouldReceive('sendVerificationEmail')
            ->once()
            ->with(1, 'plain-s18-token');

        $user = \Mockery::mock(UserService::class);
        $user->shouldReceive('find')->andReturn((object)['id' => 1]);

        $listener = new LogUserRegisteredActivity(
            $this->lenientLogger(),
            $user,
            $email
        );
        $listener->handle(new \App\Events\UserRegisteredEvent(1, 'x@y.z', '127.0.0.1', 'plain-s18-token'));
        $this->assertTrue(true);
    }

    public function test_registration_stores_hmac_hashed_token_in_user_verifications(): void
    {
        /** @var UserService $service */
        $service = $this->container()->make(UserService::class);
        $email = 's18-' . bin2hex(random_bytes(5)) . '@test.local';

        $result = $service->register([
            'full_name' => 'S18 Token Probe',
            'email' => $email,
            'password' => 'Secret123!',
        ]);
        $this->assertIsArray($result);
        $userId = (int)($result['id'] ?? 0);
        $plain = (string)($result['plain_token'] ?? '');
        $this->assertGreaterThan(0, $userId);
        $this->assertNotSame('', $plain);
        $this->cleanupSql[] = "DELETE FROM user_verifications WHERE user_id = {$userId}";
        $this->cleanupSql[] = "DELETE FROM wallets WHERE user_id = {$userId}";
        $this->cleanupSql[] = "DELETE FROM users WHERE id = {$userId}";

        $row = $this->db()->fetch(
            "SELECT token, code FROM user_verifications WHERE user_id = ? AND type = 'email'",
            [$userId]
        );
        $this->assertNotNull($row, 'ردیف user_verifications باید ساخته شده باشد');
        $expectedHash = hash_hmac('sha256', $plain, secure_key());
        $this->assertSame($expectedHash, (string)$row->token, 'ستون token باید هش HMAC توکن خام باشد (قرارداد findByToken)');
        $this->assertNotSame($plain, (string)$row->token, 'توکن خام هرگز نباید در DB بماند');
        // FIX (Round-18 P3): code اکنون OTP مستقل ۶ رقمی random_int است، نه
        // مشتقِ توکن — قرارداد جدید: دقیقاً ۶ کاراکتر عددی (مقایسهٔ خام
        // findValidCode دست‌نخورده). توکن دیگر هرگز نباید در code نشت کند.
        $code = (string)$row->code;
        $this->assertSame(6, strlen($code), 'کد OTP باید دقیقاً ۶ کاراکتر باشد');
        $this->assertTrue(ctype_digit($code), 'کد OTP باید عددی باشد');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-6 — کلید trust با تفکیک‌کنندهٔ اجرا
    // ─────────────────────────────────────────────────────────────

    public function test_trust_evaluate_uses_dedup_id_in_idempotency_key(): void
    {
        $strategy = \Mockery::mock(TrustEvaluationStrategy::class);
        $strategy->shouldReceive('calculate')->andReturn(-10.0);

        $captured = null;
        $score = \Mockery::mock(ScoreService::class);
        $score->shouldReceive('applyDelta')
            ->once()
            ->with('user', 7, \Mockery::type('string'), -10.0, 'task_rejected', [], \Mockery::on(static function (string $k) use (&$captured): bool {
                $captured = $k;
                return str_ends_with($k, ':task_rejected:42');
            }))
            ->andReturn(true);
        $score->shouldReceive('getScore')->andReturn(0.0);

        $svc = new TrustService(Database::getInstance(), $this->lenientLogger(), $score, $strategy, null);
        $ok = $svc->evaluate((object)['id' => 7], ModuleContext::SOCIAL_TASKS, 'task_rejected', ['dedup_id' => '42']);
        $this->assertTrue($ok);
        $this->assertNotNull($captured);
        $this->assertStringEndsWith(':task_rejected:42', (string)$captured);
    }

    public function test_trust_evaluate_without_dedup_id_keeps_legacy_key(): void
    {
        $strategy = \Mockery::mock(TrustEvaluationStrategy::class);
        $strategy->shouldReceive('calculate')->andReturn(-10.0);

        $captured = null;
        $score = \Mockery::mock(ScoreService::class);
        $score->shouldReceive('applyDelta')
            ->once()
            ->with('user', 7, \Mockery::type('string'), -10.0, 'task_rejected', [], \Mockery::on(static function (string $k) use (&$captured): bool {
                $captured = $k;
                return str_ends_with($k, ':task_rejected') && !str_ends_with($k, ':task_rejected:');
            }))
            ->andReturn(true);
        $score->shouldReceive('getScore')->andReturn(0.0);

        $svc = new TrustService(Database::getInstance(), $this->lenientLogger(), $score, $strategy, null);
        $this->assertTrue($svc->evaluate((object)['id' => 7], ModuleContext::SOCIAL_TASKS, 'task_rejected'));
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-7 — ماسک بازگشتی حسابرسی
    // ─────────────────────────────────────────────────────────────

    public function test_persist_audit_masks_nested_sensitive_context(): void
    {
        $captured = null;
        $model = \Mockery::mock(AuditTrailModel::class);
        $model->shouldReceive('createEntry')
            ->once()
            ->with(\Mockery::on(static function (array $row) use (&$captured): bool {
                $captured = json_decode((string)$row['context'], true);
                return is_array($captured);
            }))
            ->andReturn(1);

        $listener = new PersistAuditRecordListener($model, $this->lenientLogger());
        $listener->handle(new AuditRecordedEvent('s18.audit', 9, [
            'password' => 'topsecret',
            'old_values' => ['password' => 'nested-secret', 'note' => 'keep-me'],
            'outbox' => ['metadata' => ['card' => '6111-1111-1111-1111']],
        ], 2));

        $this->assertNotNull($captured);
        $this->assertSame('********', $captured['password'] ?? null, 'ماسک سطح اول حفظ شده');
        $this->assertSame('********', $captured['old_values']['password'] ?? null, 'توچهٔ تودرتو باید ماسک شود');
        $this->assertSame('keep-me', $captured['old_values']['note'] ?? null, 'فیلد غیرحساس دست‌نخورده');
        $this->assertSame('********', $captured['outbox']['metadata']['card'] ?? null, 'سه‌سطح تودرتو هم باید ماسک شود');
    }

    public function test_persist_audit_limits_depth(): void
    {
        $captured = null;
        $model = \Mockery::mock(AuditTrailModel::class);
        $model->shouldReceive('createEntry')
            ->once()
            ->with(\Mockery::on(static function (array $row) use (&$captured): bool {
                $captured = json_decode((string)$row['context'], true);
                return is_array($captured);
            }))
            ->andReturn(1);

        $deep = ['a' => ['b' => ['c' => ['d' => ['e' => ['f' => ['g' => 'too-deep']]]]]]];
        $listener = new PersistAuditRecordListener($model, $this->lenientLogger());
        $listener->handle(new AuditRecordedEvent('s18.depth', 9, $deep, null));

        $found = false;
        $flat = $captured ?? [];
        array_walk_recursive($flat, static function ($v) use (&$found): void {
            if ($v === '[MAX_DEPTH_REACHED]') {
                $found = true;
            }
        });
        $this->assertTrue($found, 'عمق بیش از ۵ باید بریده شود');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-8 — گارد action_url نویسندهٔ مرکزی in-app
    // ─────────────────────────────────────────────────────────────

    public function test_send_notification_job_blocks_javascript_and_keeps_safe_urls(): void
    {
        /** @var SendNotificationJob $job */
        $job = $this->container()->make(SendNotificationJob::class);
        $uid = 1;
        $type = 's18_url_probe_' . bin2hex(random_bytes(3));

        $this->cleanupSql[] = "DELETE FROM notifications WHERE user_id = {$uid} AND type = '{$type}'";

        $bad = $job->handle($uid, $type, 't', 'm', null, 'javascript:alert(1)');
        $badRow = $bad !== null ? $this->db()->fetch("SELECT action_url FROM notifications WHERE id = ?", [(int)$bad]) : null;
        $this->assertTrue($bad === null || ($badRow !== null && $badRow->action_url === null), 'javascript: باید null شود');

        $rel = $job->handle($uid, $type, 't', 'm', null, '/tickets/show/5');
        $this->assertNotNull($rel, 'اعلان با URL سالم باید ذخیره شود');
        $relRow = $this->db()->fetch("SELECT action_url FROM notifications WHERE id = ?", [(int)$rel]);
        $this->assertSame('/tickets/show/5', (string)$relRow->action_url, 'مسیر نسبی same-site مجاز است');

        $abs = $job->handle($uid, $type, 't', 'm', null, 'https://example.com/go');
        $this->assertNotNull($abs);
        $absRow = $this->db()->fetch("SELECT action_url FROM notifications WHERE id = ?", [(int)$abs]);
        $this->assertSame('https://example.com/go', (string)$absRow->action_url);

        $proto = $job->handle($uid, $type, 't', 'm', null, '//evil.example');
        if ($proto !== null) {
            $protoRow = $this->db()->fetch("SELECT action_url FROM notifications WHERE id = ?", [(int)$proto]);
            $this->assertNotSame('//evil.example', (string)$protoRow->action_url, 'پروتکل-نسبی باید رد شود');
        }
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-9 — dedup هشدار تقلب
    // ─────────────────────────────────────────────────────────────

    public function test_fraud_alert_notification_deduped_within_hour(): void
    {
        $listener = $this->container()->make(ProcessFraudAlert::class);
        $uid = 1;

        // پاک‌سازی هشدارهای قبلیِ پنجره برای قطعیت شمارش (DB تست per-run بازسازی می‌شود)
        $this->db()->execute("DELETE FROM notifications WHERE user_id = ? AND type = 'high_fraud_alert'", [$uid]);
        $this->cleanupSql[] = "DELETE FROM notifications WHERE user_id = {$uid} AND type = 'high_fraud_alert'";

        $event = new GenericEvent(['user_id' => $uid, 'fraud_score' => 88]);
        $listener->handle($event);
        $listener->handle($event);
        $listener->handle($event);

        $count = (int)$this->db()->fetchColumn(
            "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND type = 'high_fraud_alert'",
            [$uid]
        );
        $this->assertSame(1, $count, 'سه تحویل باید فقط یک هشدار بسازد (dedup ساعتی)');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-10 — مهار reason اعلان‌های رد
    // ─────────────────────────────────────────────────────────────

    public function test_content_rejection_reason_stripped_and_capped(): void
    {
        $captured = null;
        $notif = \Mockery::mock(NotificationService::class);
        $notif->shouldReceive('send')
            ->once()
            ->andReturnUsing(static function (...$args) use (&$captured) {
                $captured = $args;
                return 1;
            });

        $listener = new ContentEventListeners(
            $this->lenientLogger(),
            \Mockery::mock(XpService::class)->shouldIgnoreMissing(),
            \Mockery::mock(ReferralService::class)->shouldIgnoreMissing(),
            $notif,
            \Mockery::mock(CacheInvalidationService::class)->shouldIgnoreMissing(),
            null
        );

        $longReason = str_repeat('<b>بد</b> ', 150); // ۷۵۰ کاراکتر با تگ
        $listener->handleContentRejected(new GenericEvent([
            'submission_id' => 3,
            'user_id' => 9,
            'reason' => $longReason,
        ]));

        $this->assertNotNull($captured, 'send باید صدا زده شده باشد');
        $message = (string)($captured[3] ?? '');
        $this->assertStringNotContainsString('<b>', $message, 'تگ‌ها باید حذف شده باشند');
        $this->assertLessThanOrEqual(520, mb_strlen($message), 'پیام باید سقف طول داشته باشد (~۵۰۰ + پیشوند)');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S18-11 — رویداد پرداختِ بی‌هویت
    // ─────────────────────────────────────────────────────────────

    public function test_payment_without_transaction_identity_skips_xp_and_commission(): void
    {
        $xp = \Mockery::mock(XpService::class);
        $xp->shouldReceive('award')->never();
        $referral = \Mockery::mock(ReferralService::class);
        $referral->shouldReceive('processCommission')->never();
        $notif = \Mockery::mock(NotificationServiceInterface::class);
        $notif->shouldReceive('send')->never();

        $listener = new HandlePaymentCompleted(
            $xp,
            $referral,
            $notif,
            $this->lenientLogger(),
            Database::getInstance()
        );

        $listener->handle(new GenericEvent([
            'user_id' => 7,
            'amount' => 1000000,
            'currency' => 'IRT',
            'transaction_id' => '',
        ]));
        $this->assertTrue(true, 'رویداد بی‌هویت باید skip شود — بدون XP/کمیسیون/اعلان');
    }

    public function test_payment_with_identity_awards_xp_with_key(): void
    {
        $xp = \Mockery::mock(XpService::class);
        $xp->shouldReceive('award')
            ->once()
            ->with(7, \Mockery::type(ModuleContext::class), \Mockery::on(static fn($v) => (float)$v > 0), 'gateway_deposit_tx-s18-1');
        $referral = \Mockery::mock(ReferralService::class);
        $referral->shouldReceive('processCommission')->andReturnNull();
        $notif = \Mockery::mock(NotificationServiceInterface::class);
        $notif->shouldReceive('send')->andReturnNull();

        $listener = new HandlePaymentCompleted(
            $xp,
            $referral,
            $notif,
            $this->lenientLogger(),
            Database::getInstance()
        );

        $listener->handle(new GenericEvent([
            'user_id' => 7,
            'amount' => 10000000,
            'currency' => 'IRT',
            'transaction_id' => 'tx-s18-1',
        ]));
        $this->assertTrue(true);
    }
}
