<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🧾 FIX-N22-01/FIX-N22-02 — پین‌های ساختاری سیم‌کشی دو اصلاح بازبینی ۲۲:
 *
 *  N22-01 (فیلتر کیفی مسیر تقلب):
 *   ۱) ExecutorTaskController::reviewReport فقط مسیر گزارش تقلب را با
 *      fraudReported=true صدا می‌زند؛ ردِ مستقیم ادمین (AdTaskController)
 *      پارامتر ندارد = بدون فیلتر (قرارداد گزینهٔ A بچ V22B دست‌نخورده).
 *   ۲) آستانهٔ ۷۰ و متد فیلتر روی سرویس؛ ردِ هدفمند با «فیلتر کیفی» در دلیل.
 *   ۳) پاسخ و لاگ داوری تعداد نگه‌داشته‌شده‌ها را شفاف می‌کنند.
 *
 *  N22-02 (دید/راه بازگشت ردیف‌های پارک‌شدهٔ sweep):
 *   ۴) روت GET /admin/custom-tasks/parked «قبل از» وایلدکارت {id} ثبت شده
 *      (قرارداد static-before-wildcard همان stats — F-A3-02).
 *   ۵) روت POST .../submissions/reset-attempts کنار force-approve/reject.
 *   ۶) ویو parked.php: دکمهٔ بازگردانی + تأیید/رد اجباری + ریشهٔ URLها.
 *   ۷) JS: data-reset-parked-url + btn-reset-parked با confirm.
 *   ۸) سایدبار ادمین آیتم صفحه را دارد؛ جدول submissions تسک هم نشان پارک دارد.
 *
 * @group architecture
 */
final class N22FixPinningTest extends TestCase
{
    private static function repoPath(string $rel): string
    {
        return dirname(__DIR__, 3) . '/' . $rel;
    }

    /** @return array{string, string} */
    private static function read(string $rel): array
    {
        $src = file_get_contents(self::repoPath($rel));
        self::assertIsString($src, $rel . ' باید موجود باشد');
        return [$src, $rel];
    }

    private static function assertContainsWithRel(string $needle, string $haystack, string $rel, string $why): void
    {
        self::assertStringContainsString($needle, $haystack, $why . ' — ' . $rel);
    }

    /** @test */
    public function n22_01_fraud_report_path_passes_fraud_reported_true(): void
    {
        [$src, $rel] = self::read('app/Controllers/Admin/ExecutorTaskController.php');

        self::assertContainsWithRel('FIX-N22-01', $src, $rel, 'مارکر اصلاح');
        self::assertContainsWithRel(
            "rejectTask((int)\$report->task_id, (int)\$this->userId(), 'گزارش شده به دلیل تقلب', true)",
            $src, $rel,
            'مسیر گزارش تقلب باید fraudReported=true بدهد تا فیلتر کیفی فعال شود'
        );
        // شفافیت فیلتر در پاسخ و لاگ داوری
        self::assertContainsWithRel("'fraud_filtered_submissions' => \$taskFraudFiltered", $src, $rel, 'پاسخ JSON و لاگ باید تعداد فیلترشده‌ها را داشته باشند');
    }

    /** @test */
    public function n22_01_direct_admin_reject_stays_unfiltered(): void
    {
        [$src, $rel] = self::read('app/Controllers/Admin/AdTaskController.php');

        $this->assertStringContainsString('rejectTask($taskId, (int)$this->userId(), $reasonStr)', $src,
            'رد مستقیم ادمین باید بدون پارامتر چهارم بماند — گزینهٔ A بچ V22B برای مسیر عمومی');
        $this->assertStringNotContainsString('rejectTask($taskId, (int)$this->userId(), $reasonStr, true', $src,
            'فیلتر کیفی فقط به مسیر گزارش تقلب تعلق دارد، نه رد مستقیم ادمین');
    }

    /** @test */
    public function n22_01_service_threshold_and_targeted_rejection_reason(): void
    {
        [$src, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        self::assertContainsWithRel('FRAUD_SETTLEMENT_SCORE_THRESHOLD = 70', $src, $rel, 'آستانهٔ مشکوک = ۷۰ (تعریف VelocityAndScoreModel)');
        self::assertContainsWithRel('isSuspiciousForFraudSettlement', $src, $rel, 'متد فیلتر کیفی');
        self::assertContainsWithRel('bool $fraudReported = false', $src, $rel, 'پارامتر پیش‌فرض false = مسیر عمومی بدون فیلتر');
        // رد هدفمند با دلیل روشن (نه رد گروهی بی‌صدا)
        self::assertContainsWithRel('در فیلتر کیفیِ تسویهٔ جبرانی نگه داشته شد', $src, $rel, 'دلیل ردِ ارسال فیلترشده باید برای مجری روشن باشد');
        // fail-closed بدون User model
        self::assertContainsWithRel('User model برای فیلتر کیفی مسیر تقلب الزامی است', $src, $rel, 'نبود وابستگی = شکست کل رد، نه دور زدن فیلتر');
    }

    /** @test */
    public function n22_02_parked_route_registered_before_wildcard_id(): void
    {
        [$src, $rel] = self::read('routes/admin.php');

        self::assertContainsWithRel("'/admin/custom-tasks/parked', [AdminExecutorTaskController::class, 'parkedSubmissions']", $src, $rel, 'روت صفحهٔ پارک‌شده‌ها');
        self::assertContainsWithRel("'/admin/custom-tasks/submissions/reset-attempts', [AdminExecutorTaskController::class, 'resetParkedSubmission']", $src, $rel, 'روت بازگردانی');

        $parkedPos = strpos($src, "'/admin/custom-tasks/parked'");
        $wildcardPos = strpos($src, "'/admin/custom-tasks/{id}'");
        $this->assertIsInt($parkedPos);
        $this->assertIsInt($wildcardPos);
        $this->assertLessThan($wildcardPos, $parkedPos,
            'static-before-wildcard: /parked باید قبل از /{id} ثبت شود (قرارداد F-A3-02 برای stats)');
    }

    /** @test */
    public function n22_02_parked_view_has_root_urls_and_actions(): void
    {
        [$src, $rel] = self::read('views/admin/custom-tasks/parked.php');

        self::assertContainsWithRel('data-reset-parked-url', $src, $rel, 'ریشهٔ URL بازگردانی برای JS');
        self::assertContainsWithRel('data-force-approve-url', $src, $rel, 'تأیید اجباری از همان صفحه');
        self::assertContainsWithRel('btn-reset-parked', $src, $rel, 'دکمهٔ بازگردانی به صف');
        self::assertContainsWithRel('parkThreshold', $src, $rel, 'آستانه از کنترلر (منبع واحد مدل) پاس می‌شود نه هاردکد');

        [$ctrl, $relC] = self::read('app/Controllers/Admin/ExecutorTaskController.php');
        self::assertContainsWithRel("'parkThreshold' => CustomTaskSubmissionModel::AUTO_APPROVE_PARK_THRESHOLD", $ctrl, $relC, 'کنترلر آستانه را از ثابت مدل می‌خواند');
    }

    /** @test */
    public function n22_02_js_wires_reset_parked_with_confirm(): void
    {
        [$src, $rel] = self::read('public/assets/js/admin/customtasks.js');

        self::assertContainsWithRel("d('resetParkedUrl')", $src, $rel, 'خواندن URL از data-attr');
        self::assertContainsWithRel('btn-reset-parked', $src, $rel, 'هندلر دکمهٔ بازگردانی');
        self::assertContainsWithRel('data-reset-parked-url', $src, $rel, 'مستندسازی قرارداد data-attr');
    }

    /** @test */
    public function n22_02_sidebar_and_task_detail_show_parked_visibility(): void
    {
        [$sidebar, $relS] = self::read('views/partials/admin/sidebar.php');
        self::assertContainsWithRel("'/admin/custom-tasks/parked'", $sidebar, $relS, 'آیتم منوی سایدبار ادمین');

        [$show, $relV] = self::read('views/admin/custom-tasks/show.php');
        self::assertContainsWithRel('AUTO_APPROVE_PARK_THRESHOLD', $show, $relV, 'نشان پارک در جدول ارسال‌های تسک');
        self::assertContainsWithRel('پارک‌شدهٔ sweep', $show, $relV, 'برچسب فارسی نشان پارک');
    }
}
