<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🧾 FIX-V22 (بچ بازمانده‌های بازبینی ۲۲) — پین‌های ساختاری سه اصلاح:
 *
 *  V22-01 — ترتیب «ابتدا رد تسک، بعد بستن گزارش تقلب»:
 *   ۱) در reviewReport فراخوانی rejectTask باید «قبل» از UPDATE وضعیت
 *      task_reports بیاید (اندیس کاراکتری در سورس)؛ شکست رد ⇒ ۴۰۹ و گزارش
 *      در وضعیت غیرپایانی می‌ماند (پاسخ success=false برمی‌گردد).
 *   ۲) تسکِ از-قبل-rejected بدون فراخوانی مجدد rejectTask، رد شمرده می‌شود
 *      (idempotency) و وضعیت پایانیِ غیرقابل‌رد فقط یادداشت می‌سازد.
 *   ۳) رقابت CAS (rowCount=0) با ۴۰۹ «گزارش پیش‌تر تعیین تکلیف شده» پاسخ
 *      می‌دهد نه ۵۰۰ مبهم قبلی.
 *   ۴) ویو reports.php هشدار task_reject_note را پیش از reload نمایش می‌دهد.
 *
 *  V22-03 — auto-approve و ضدگرسنگی sweep:
 *   ۵) گارد «return 0 اگر تنظیم سراسری ≤۰» از کرون حذف شده (فالبک به SQL
 *      منتقل شد — وعدهٔ T22-16 برای تسک‌های دارای ساعت اختصاصی حفظ شود).
 *   ۶) کوئری مدل هر سه گارد جدید دارد: COALESCE(...) > 0 + attempts < سقف +
 *      NOT EXISTS خواهرِ approved/disputed (V22-04c) + ORDER BY attempts.
 *   ۷) متد افزایش اتمیک شمارنده با «auto_approve_attempts + 1» در خود SQL.
 *   ۸) مایگریشن ستون‌ها/ایندکس‌ها را می‌سازد و بند ۵ CHANGES-M22-MED-fa.md
 *      با اصلاحیهٔ FIX-V22-03 علامت خورده (سند تاریخی نادرست نماند).
 *
 *  V22-04 — نکات کوچک:
 *   ۹) FileAccess::checkTaskProofOwnership روی ستون ایندکس‌پذیر
 *      proof_file_basename مقایسه می‌کند (نه SUBSTRING_INDEX در WHERE).
 *  ۱۰) حدِ اعتبار device_restriction (قابل‌جعل با UA) در سرویس مجری
 *      با مارکر FIX-V22-04b مستند شده.
 *
 * @group architecture
 */
final class V22ResidualsPinningTest extends TestCase
{
    private static function repoPath(string $rel): string
    {
        return dirname(__DIR__, 3) . '/' . $rel;
    }

    /** @return array{string, string} */
    private static function read(string $rel): array
    {
        $src = file_get_contents(self::repoPath($rel));
        self::assertIsString($src, $rel . ' باید موجود باشد');
        return [$src, $rel];
    }

    private static function assertContainsWithRel(string $needle, string $haystack, string $rel, string $why): void
    {
        self::assertStringContainsString($needle, $haystack, $why . ' — ' . $rel);
    }

    /** @test */
    public function v22_01_reject_task_precedes_report_resolution(): void
    {
        [$src, $rel] = self::read('app/Controllers/Admin/ExecutorTaskController.php');

        // مارکر اصلاح
        self::assertContainsWithRel('FIX-V22-01', $src, $rel, 'مارکر FIX-V22-01');
        // ترتیب: rejectTask باید قبل از UPDATE گزارش بیاید
        $rejectPos = strpos($src, 'rejectTask((int)$report->task_id');
        $casPos = strpos($src, "db()->table('task_reports')");
        self::assertIsInt($rejectPos, 'فراخوانی rejectTask باید در reviewReport موجود باشد');
        self::assertIsInt($casPos, 'گذار CAS وضعیت گزارش باید موجود باشد');
        self::assertLessThan(
            $casPos,
            $rejectPos,
            'FIX-V22-01: رد تسک باید «قبل» از بستن گزارش انجام شود تا شکست رد، گزارش حل‌شدهٔ دروغین نسازد'
        );
        // شکست رد تسک ⇒ ۴۰۹ + ماندن گزارش (پاسخ بلافاصله برمی‌گردد)
        self::assertContainsWithRel("'task_rejected' => false", $src, $rel, 'پاسخ شکست رد تسک باید task_rejected=false داشته باشد');
        self::assertContainsWithRel('رد تسک ناموفق بود؛ گزارش باز ماند', $src, $rel, 'پیام شکست رد تسک');
        // idempotency: تسکِ از-قبل-rejected بدون فراخوانی مجدد
        self::assertContainsWithRel("if (\$taskStatus === 'rejected')", $src, $rel, 'گارد idempotency برای تسک از-قبل-ردشده');
        // وضعیت پایانی غیرقابل‌رد ⇒ یادداشت (نه شکست)
        self::assertContainsWithRel('task_reject_note', $src, $rel, 'یادداشت وضعیت پایانی غیرقابل‌رد');
        // رقابت CAS ⇒ ۴۰۹ نه ۵۰۰
        self::assertContainsWithRel('گزارش پیش‌تر تعیین تکلیف شده است', $src, $rel, 'پیام ۴۰۹ رقابت CAS');
    }

    /** @test */
    public function v22_01_view_surfaces_task_reject_note(): void
    {
        [$src, $rel] = self::read('views/admin/custom-tasks/reports.php');
        self::assertContainsWithRel('FIX-V22-01', $src, $rel, 'مارکر FIX-V22-01 در ویو');
        self::assertContainsWithRel('task_reject_note', $src, $rel, 'هشدار یادداشت ردنشدن تسک باید خوانده شود');
        self::assertContainsWithRel('task_rejected === false', $src, $rel, 'شرط هشدار باید task_rejected=false را چک کند');
    }

    /** @test */
    public function v22_03_global_gate_moved_to_sql(): void
    {
        [$job, $rel] = self::read('app/Jobs/CustomTask/CronSubmissionsJob.php');
        self::assertContainsWithRel('FIX-V22-03b', $job, $rel, 'مارکر FIX-V22-03b در کرون');
        self::assertStringNotContainsString(
            "if (\$hours <= 0) {\n            return 0;\n        }",
            $job,
            'FIX-V22-03b: گارد کشتن کل sweep با تنظیم سراسری ≤۰ باید حذف شود (فالبک در SQL اعمال می‌شود)'
        );
        self::assertContainsWithRel('submission_incrementAutoApproveAttempts', $job, $rel, 'افزایش شمارندهٔ شکست در شاخهٔ شکست');
        self::assertContainsWithRel('custom_task.auto_approve_parked', $job, $rel, 'لاگ error پارک');
    }

    /** @test */
    public function v22_03_sweep_query_guards(): void
    {
        [$src, $rel] = self::read('app/Models/CustomTaskSubmissionModel.php');
        self::assertContainsWithRel('FIX-V22-03', $src, $rel, 'مارکر FIX-V22-03 در مدل');
        // (b) ساعت اختصاصی مستقل از سراسری + غیرممکن‌شدن INTERVAL صفر
        self::assertContainsWithRel('AND COALESCE(ct.auto_approve_hours, ?) > 0', $src, $rel, 'گارد > 0 روی COALESCE');
        // (c) ضدگرسنگی
        self::assertContainsWithRel('AND s.auto_approve_attempts < ?', $src, $rel, 'فیلتر ردیف‌های پارک‌شده');
        self::assertContainsWithRel('ORDER BY s.auto_approve_attempts ASC, s.submitted_at ASC', $src, $rel, 'ترتیب صف بر اساس attempts سپس قدیمی‌ترین');
        // (d/V22-04c) حذف نویز گارد دوبل‌پرداخت
        self::assertContainsWithRel("s2.status IN ('approved', 'disputed')", $src, $rel, 'استثنای خواهرِ approved/disputed از کاندیدای auto-approve');
        // سقف پارک به‌صورت ثابت مدل (منبع واحد حقیقت)
        self::assertContainsWithRel('AUTO_APPROVE_PARK_THRESHOLD = 10', $src, $rel, 'ثابت آستانهٔ پارک روی مدل');
    }

    /** @test */
    public function v22_03_increment_is_atomic_in_sql(): void
    {
        [$src, $rel] = self::read('app/Models/CustomTaskSubmissionModel.php');
        self::assertContainsWithRel(
            'SET auto_approve_attempts = auto_approve_attempts + 1',
            $src,
            $rel,
            'افزایش باید اتمیک در خود SQL باشد (نه خواندن-سپس-نوشتن)'
        );
    }

    /** @test */
    public function v22_03_migration_and_doc_correction_exist(): void
    {
        $mig = 'database/migrations/2026_11_08_0001_v22_auto_approve_attempts_and_proof_basename.sql';
        [$src, $rel] = self::read($mig);
        self::assertContainsWithRel('`auto_approve_attempts`', $src, $rel, 'ستون شمارندهٔ شکست‌ها');
        self::assertContainsWithRel('`proof_file_basename`', $src, $rel, 'ستون generated.basename مدرک');
        self::assertContainsWithRel("GENERATED ALWAYS AS (SUBSTRING_INDEX(`proof_file`, '/', -1)) VIRTUAL", $src, $rel, 'ستون generated هم‌ارزش basename');
        self::assertContainsWithRel('idx_cts_proof_file_basename', $src, $rel, 'ایندکس.basename');
        self::assertContainsWithRel('idx_cts_auto_approve_attempts', $src, $rel, 'ایندکس.attempts');

        [$doc, $docRel] = self::read('CHANGES-M22-MED-fa.md');
        self::assertContainsWithRel('اصلاح FIX-V22-03', $doc, $docRel, 'بند ۵ مستند باید اصلاحیهٔ صریح داشته باشد');
    }

    /** @test */
    public function v22_04_proof_ownership_uses_indexed_generated_column(): void
    {
        [$src, $rel] = self::read('app/Models/FileAccess.php');
        self::assertContainsWithRel('FIX-V22-04a', $src, $rel, 'مارکر FIX-V22-04a');
        self::assertContainsWithRel('WHERE s.proof_file_basename = ?', $src, $rel, 'مقایسه روی ستون ایندکس‌پذیر');
        $method = substr($src, (int)strpos($src, 'function checkTaskProofOwnership'), 2200);
        self::assertStringNotContainsString(
            "SUBSTRING_INDEX(s.proof_file, '/', -1)",
            $method,
            'FIX-V22-04a: عبارت غیرقابل ایندکس نباید در WHERE چک مالکیت مدرک باشد'
        );
    }

    /** @test */
    public function v22_04_device_restriction_limits_documented(): void
    {
        [$src, $rel] = self::read('app/Services/CustomTask/CustomTaskExecutorService.php');
        self::assertContainsWithRel('FIX-V22-04b', $src, $rel, 'مارکر مستندسازی حدِ اعتبار device_restriction');
        self::assertContainsWithRel('قابل جعل', $src, $rel, 'صراحت دربارهٔ جعل‌پذیری UA');
    }
}
