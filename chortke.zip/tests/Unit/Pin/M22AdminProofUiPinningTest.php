<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M22-05 + FIX-M22-06 — پین رابط کاربری پنل ادمین:
 *  ۱) جدول submissions ویوی show باید همهٔ کانال‌های مدرک را رندر کند و
 *     دکمه‌های تأیید/رد اجباری داشته باشد (اندپوینت‌ها از قبل ثبت بودند ولی UI نداشتند).
 *  ۲) صفحهٔ اختلاف باید مدرک مجری را نشان دهد و سه دکمهٔ داوری تصمیم اولیهٔ
 *     خودشان را با data-decision مشخص کنند (نه دیالوگ واحد با پیش‌فرض executor).
 *  ۳) JS ادمین باید .catch داشته باشد و هندلرهای force جدید را بشناسد.
 *
 * @group architecture
 */
final class M22AdminProofUiPinningTest extends TestCase
{
    private static function repoPath(string $rel): string
    {
        return dirname(__DIR__, 3) . '/' . $rel;
    }

    /** @test */
    public function admin_show_view_renders_all_proof_channels(): void
    {
        $src = file_get_contents(self::repoPath('views/admin/custom-tasks/show.php'));
        self::assertIsString($src);

        $this->assertStringContainsString('proof_url', $src);
        $this->assertStringContainsString('proof_file', $src);
        $this->assertStringContainsString('proof_code', $src);
        $this->assertStringContainsString('proof_data', $src);
        // فایل‌های خصوصی از مسیر کنترل‌شدهٔ سرو می‌شوند (دسترسی ادمین مجاز است)
        $this->assertStringContainsString("/file/view/task-proofs/", $src);
        $this->assertStringContainsString('basename(', $src, 'نام فایل باید با basename محدود شود');
    }

    /** @test */
    public function admin_show_view_exposes_force_endpoints_ui(): void
    {
        $src = file_get_contents(self::repoPath('views/admin/custom-tasks/show.php'));
        self::assertIsString($src);

        $this->assertStringContainsString('btn-force-approve', $src);
        $this->assertStringContainsString('btn-force-reject', $src);
        $this->assertStringContainsString('data-force-approve-url', $src);
        $this->assertStringContainsString('data-force-reject-url', $src);
        // ویو باید اسکریپت ماژول را لود کند
        $this->assertStringContainsString('assets/js/admin/customtasks.js', $src);
    }

    /** @test */
    public function dispute_detail_shows_worker_proof_and_preset_decisions(): void
    {
        $src = file_get_contents(self::repoPath('views/admin/custom-tasks/dispute-detail.php'));
        self::assertIsString($src);

        // مدرک مجری باید دیده شود (قبلاً فیلدها از findDetailWithSubmission می‌آمدند ولی رندر نمی‌شدند)
        $this->assertStringContainsString('مدرک ارسالی مجری', $src);
        $this->assertStringContainsString('proof_file', $src);
        $this->assertStringContainsString("/file/view/task-proofs/", $src);

        // سه دکمهٔ داوری تصمیم اولیهٔ خودشان را تعیین می‌کنند
        $this->assertStringContainsString('data-decision="executor"', $src);
        $this->assertStringContainsString('data-decision="split"', $src);
        $this->assertStringContainsString('data-decision="advertiser"', $src);
        // دکمهٔ قدیمیِ بدون-تأییدیه حذف شده است
        $this->assertStringNotContainsString('btn-resolve-advertiser', $src);
    }

    /** @test */
    public function admin_js_handles_decisions_and_network_failures(): void
    {
        $src = file_get_contents(self::repoPath('public/assets/js/admin/customtasks.js'));
        self::assertIsString($src);

        // پیش‌انتخاب تصمیم از data-decision (FIX-M22-06)
        $this->assertStringContainsString('dataset.decision', $src);
        // همهٔ fetchها .catch دارند — سه‌گانهٔ approve/resolve/force
        $this->assertGreaterThanOrEqual(3, substr_count($src, '.catch('));
        // هندلرهای force جدید (FIX-M22-05)
        $this->assertStringContainsString('btn-force-approve', $src);
        $this->assertStringContainsString('btn-force-reject', $src);
    }

    /** @test */
    public function force_endpoints_remain_registered_in_admin_routes(): void
    {
        $src = file_get_contents(self::repoPath('routes/admin.php'));
        self::assertIsString($src);

        $this->assertStringContainsString('submissions/force-approve', $src);
        $this->assertStringContainsString('submissions/force-reject', $src);
    }
}
