<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-T23-01..04 — پین‌های ساختاری بخش ۲۳ (سئو) روی درخت زنده.
 *
 * سبک خانه: بازرسی سورس (رفتارِ runtime در تست‌های Mockery/زنده پین شده).
 */
final class T23Section23PinningTest extends TestCase
{
    private const BASE = __DIR__ . '/../../../';

    private function read(string $path): string
    {
        $src = (string)file_get_contents(self::BASE . $path);
        self::assertNotSame('', $src, "فایل یافت نشد: {$path}");
        return $src;
    }

    // ─────────────── T23-01: الصاق ckp در کلیک اول ───────────────

    public function test_go_uses_click_stamped_flag_after_consume(): void
    {
        $src = $this->read('app/Controllers/User/SeoController.php');

        // پرچم محلی پس از مصرف موفق nonce ست می‌شود (نه خواندن دوبارهٔ شیء stale)
        self::assertStringContainsString('FIX-T23-01', $src);
        self::assertStringContainsString('$clickStamped = $execution->click_counted_at !== null;', $src);
        self::assertStringContainsString('$clickStamped = true;', $src);
        // شرط الصاق ckp دیگر به شیءِ کش‌شده قبل از مصرف نگاه نمی‌کند — در این
        // نقطه کلیک همیشه مهرشده است (مسیر خطا با redirectِ never خارج شده) و
        // شرط فقط به حالت آگهی + حضور توکن وابسته است
        self::assertStringContainsString('if ($this->landingProof->isEnabledForAd($ad) && $token !== \'\') {', $src);
        // شرط قدیمیِ باگ‌دار (نگاه به click_counted_at شیء stale) نباید برگردد
        self::assertStringNotContainsString('if ($execution->click_counted_at !== null && $this->landingProof->isEnabledForAd($ad)', $src);
    }

    // ─────────────── T23-02: گیت حالت + Referer پیکسل ───────────────

    public function test_pixel_service_gates_ad_mode_and_referer(): void
    {
        $src = $this->read('app/Services/SeoLandingProofService.php');

        self::assertStringContainsString('FIX-T23-02', $src);
        // گیت حالت آگهی (قرینهٔ پست‌بک)
        self::assertStringContainsString("modeForAd(\$ad) !== 'pixel'", $src);
        self::assertStringContainsString('pixel_mode_mismatch', $src);
        // الزام Referer هم‌مقصد با صفحهٔ فرود
        self::assertStringContainsString('pixelRefererMatchesAd', $src);
        self::assertStringContainsString('pixel_non_browser', $src);
        self::assertStringContainsString('not_browser_request', $src);
        // نرمال‌سازی هاست (lowercase + حذف www)
        self::assertStringContainsString("preg_replace('/^www\\./'", $src);
        // امضای handlePixel پارامتر referer دارد (🛡️ FIX-T23H: + پارامتر UA
        // سخت‌سازی پیکسل — پین با امضای چهار-آرگومانی به‌روز شد)
        self::assertStringContainsString('public function handlePixel(string $token, string $ip, ?string $referer = null, ?string $userAgent = null): array', $src);
    }

    public function test_pixel_controller_passes_referer(): void
    {
        $src = $this->read('app/Controllers/User/SeoController.php');
        self::assertStringContainsString('HTTP_REFERER', $src);
        // 🛡️ FIX-T23H: کنترلر حالا UA را هم برای گیت‌های سخت‌سازی پاس می‌دهد
        self::assertStringContainsString('handlePixel($token, $ip, $referer, $userAgent)', $src);
        self::assertStringContainsString('HTTP_USER_AGENT', $src);
    }

    // ─────────────── T23-03: کوئری کاربر-محور فهرست سئو ───────────────

    public function test_both_user_facing_list_callers_use_user_oriented_query(): void
    {
        $web = $this->read('app/Controllers/User/SeoController.php');
        $api = $this->read('app/Controllers/Api/SeoTaskApiController.php');

        foreach ([$web, $api] as $src) {
            self::assertStringContainsString('searchActiveSeoTasksForUser', $src);
            self::assertStringNotContainsString('searchAdminTasks', $src);
        }
    }

    public function test_ads_model_has_user_oriented_query_and_real_sort(): void
    {
        $src = $this->read('app/Models/Ads.php');
        self::assertStringContainsString('public function searchActiveSeoTasksForUser(', $src);
        // مرتب‌سازی getActiveForSearch بر اساس بازهٔ واقعی پاداش است (نه ستون همیشه‌صفر)
        $active = substr($src, (int)strpos($src, 'function getActiveForSearch'), 1600);
        self::assertStringContainsString("orderBy('max_payout', 'DESC')", $active);
        self::assertStringNotContainsString("orderBy('price_per_click', 'DESC')", $active);
    }

    // ─────────────── T23-04: قرارداد پاداش API موبایل ───────────────

    public function test_api_ads_rows_expose_real_reward_range(): void
    {
        $src = $this->read('app/Controllers/Api/SeoTaskApiController.php');
        self::assertStringContainsString("'min_payout'", $src);
        self::assertStringContainsString("'max_payout'", $src);
        self::assertStringContainsString("'target_duration'", $src);
        // کلیدهای قدیمی alias هستند — نه مقادیر خامِ ستون‌های بی‌معنا
        self::assertStringContainsString('deprecated', $src);
    }

    public function test_mobile_api_guide_documents_reward_fields(): void
    {
        $src = $this->read('docs/MOBILE-API-GUIDE-fa.md');
        self::assertStringContainsString('min_payout', $src);
        self::assertStringContainsString('max_payout', $src);
        self::assertStringContainsString('target_duration', $src);
    }

    public function test_advertiser_pixel_docs_mention_referer_requirement(): void
    {
        $src = $this->read('views/user/ads/show.php');
        self::assertStringContainsString('FIX-T23-02', $src);
        self::assertStringContainsString('Referer', $src);
    }
}
