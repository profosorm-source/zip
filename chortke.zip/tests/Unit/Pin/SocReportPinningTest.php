<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCREPORT-01 (۲۰۲۶-۱۱-۰۹ — تصمیم «گزینه B» کارفرما) — پین‌های ساختاریِ
 * قوی‌کردن قرارداد گزارش سوشیال.
 *
 * تا بچ SOCGUARD، گزارش سوشیال قرارداد ضعیفِ وب را حفظ کرده بود (فقط «آگهی
 * موجود» + دلیل — هر کاربر لاگین به هر کمپینی) و همین موضوع به‌عنوان «تصمیم
 * محصولی بچ بعدی» در مانیفست SOCGUARD مستند شده بود. این بچ آن را قوی کرد:
 * قرینهٔ گارد گزارش سئو (ReportSeoTaskJob: «فقط مجری این تسک») + هم‌الگوی
 * گاردهای rateTask.
 *
 * سبک خانه (الگوی SocGuardPinningTest/Seo3PinningTest): بازرسی سورس —
 * رفتارِ runtime در InteractionApiControllerSocialGuardTest (Mockery، از بچ
 * SOCGUARD — همان مسیر ۴۲۲ را برای پیام‌های جدید هم می‌پوشاند) و E2E زندهٔ
 * socguard-live-e2e.php پین شده است.
 *
 * 🛡️ FIX-SOCREPORT2-01 (داوری کارفرما ۲۰۲۶-۱۱-۰۹): فیلتر وضعیتِ اسپکِ گزینه B
 * به کوئری گارد اجرا اضافه شد — «غیر-pending/غیر-cancelled» (عین متن توافق).
 * تست test_report_execution_status_filter_pinned همین فیلتر را پین می‌کند.
 */
final class SocReportPinningTest extends TestCase
{
    private const BASE = __DIR__ . '/../../../';

    private function read(string $path): string
    {
        $src = (string)file_get_contents(self::BASE . $path);
        self::assertNotSame('', $src, "فایل یافت نشد: {$path}");
        return $src;
    }

    // ─────────────── گاردهای جدید reportTask — کسی ضعیفشان نکند ───────────────

    public function test_report_owner_guard_pinned(): void
    {
        $src = $this->read('app/Services/SocialTask/SocialTaskService.php');

        // گارد تضاد منافع: مالک کمپین به تسک خودش گزارش نمی‌دهد (قرینهٔ rate)
        self::assertStringContainsString('if ((int)($ad->user_id ?? 0) === $reporterId)', $src);
        self::assertStringContainsString('گزارش دادن تسک خودتان مجاز نیست', $src);
        self::assertStringContainsString('FIX-SOCREPORT-01', $src);
    }

    public function test_report_executor_guard_pinned(): void
    {
        $src = $this->read('app/Services/SocialTask/SocialTaskService.php');

        // گارد اجرا: الزامِ داشتنِ اجرای همین تسک — وضعیت‌های مجاز (هر چیزی
        // جز pending/cancelled — پین دقیق در تستِ فیلتر FIX-SOCREPORT2-01 پایین).
        // پیام عیناً همان پیام ReportSeoTaskJob (تقارن سئو/سوشیال).
        self::assertStringContainsString('فقط مجری این تسک می‌تواند گزارش ثبت کند', $src);
        self::assertStringContainsString('FIX-SOCREPORT-01', $src);
    }

    public function test_report_execution_status_filter_pinned(): void
    {
        $src = $this->read('app/Services/SocialTask/SocialTaskService.php');

        // 🛡️ FIX-SOCREPORT2-01 (داوری کارفرما ۲۰۲۶-۱۱-۰۹): کوئری گارد گزارش —
        // اجرای مجاز باید «غیر-pending/غیر-cancelled» باشد، عین متن توافق گزینه B.
        // pending در جریان زنده گذراست (INSERT→in_progress در همان تراکنش) و
        // cancelled تنها از بلاک FraudGuard می‌آید — فیلتر عملاً حسابِ ضدتقلبِ
        // لو-rفته را از کانال گزارش می‌بندد. rejected همچنان پاس (تنها کانال
        // قربانیِ بدون dispute).
        self::assertStringContainsString(
            "SELECT id FROM social_task_executions\n             WHERE ad_id = ? AND executor_id = ?\n               AND status NOT IN ('pending','cancelled')\n             LIMIT 1",
            $src
        );
        self::assertStringContainsString('FIX-SOCREPORT2-01', $src);

        // رگرسیون: فیلتر جدید فقط report را گرفت — کوئری rate همچنان
        // approved-only است (امتیاز حقِ مجریِ تأییدشده است؛ گزارش حقِ هر مجریِ واقعی)
        self::assertStringContainsString("WHERE ad_id = ? AND executor_id = ? AND status = 'approved'", $src);

        // و نسخهٔ بی‌فیلترِ قبلی (انحراف ۲ از توافق) دیگر در کد نیست
        self::assertStringNotContainsString(
            "SELECT id FROM social_task_executions\n             WHERE ad_id = ? AND executor_id = ?\n             LIMIT 1",
            $src
        );
    }

    public function test_report_guards_precede_reason_check_and_rate_guards_untouched(): void
    {
        $src = $this->read('app/Services/SocialTask/SocialTaskService.php');

        $reportPos = strpos($src, 'public function reportTask(');
        $ownerPos = strpos($src, 'گزارش دادن تسک خودتان مجاز نیست');
        $reasonPos = strpos($src, 'دلیل گزارش الزامی است');
        self::assertNotFalse($reportPos);
        self::assertNotFalse($ownerPos);
        self::assertNotFalse($reasonPos);
        // گاردها پیش از ولیدیشن دلیل (هم‌ترتیب rateTask: ad → مالک → مجری → …)
        self::assertGreaterThan($reportPos, $ownerPos);
        self::assertGreaterThan($ownerPos, $reasonPos);

        // رگرسیون: گاردهای rateTask دست‌نخورده
        self::assertStringContainsString('امتیاز دادن به تسک خودتان مجاز نیست', $src);
        self::assertStringContainsString("WHERE ad_id = ? AND executor_id = ? AND status = 'approved'", $src);
        self::assertStringContainsString('فقط مجریِ اجرای تأییدشده می‌تواند به این تسک امتیاز بدهد', $src);
        self::assertStringContainsString('$stars = max(1, min(5, $stars));', $src);
    }

    // ─────────────── قرارداد مستند در گاید اپ — هم‌گام با کد ───────────────

    public function test_mobile_guide_documents_strong_report_contract(): void
    {
        $guide = $this->read('docs/MOBILE-API-GUIDE-fa.md');

        self::assertStringContainsString('FIX-SOCREPORT-01', $guide);
        // 🛡️ FIX-SOCREPORT2-01: گاید هم فیلتر وضعیت را مستند کند — هم‌گام با کد
        self::assertStringContainsString('FIX-SOCREPORT2-01', $guide);
        self::assertStringContainsString('غیر-pending/غیر-cancelled', $guide);
        // گاید: گزارش فقط برای مجریِ همین کمپین (نه «فقط آگهی موجود» قبلی)
        self::assertStringContainsString('گزارش فقط برای مجریِ همین کمپین', $guide);
        // و قرارداد ضعیف قدیمی دیگر مستند نیست
        self::assertStringNotContainsString('گزارش فقط برای آگهیِ واقعاً موجود', $guide);
    }

    // ─────────────── E2E زنده: قرارداد قوی پین شده ───────────────

    public function test_live_e2e_pins_strong_report_contract(): void
    {
        $e2e = $this->read('tools/socguard-live-e2e.php');

        // غریبهٔ بی‌اجرا → ۴۲۲ (قبلاً ۲۰۰ — قرارداد ضعیف)
        self::assertStringContainsString('قرارداد قوی', $e2e);
        self::assertStringContainsString('بدون اجرا) → 422 SOCIAL_REPORT_GUARDED', $e2e);
        // مالک → ۴۲۲ تضاد منافع
        self::assertStringContainsString('report مالک کمپین (تسک خودش) → 422', $e2e);
        // مجریِ ردشده → ۲۰۰ (تنها کانال قربانیِ بدون dispute)
        self::assertStringContainsString('report مجریِ ردشده → 200', $e2e);
        // 🛡️ FIX-SOCREPORT2-01: فیلتر وضعیت اسپک — pending و cancelled → ۴۲۲
        self::assertStringContainsString('اجراهای pending/cancelled → 422', $e2e);
        self::assertStringContainsString("VALUES (?, ?, 'pending'", $e2e);
        self::assertStringContainsString("VALUES (?, ?, 'cancelled'", $e2e);
        // و قرارداد ضعیف قدیمی از E2E حذف شده
        self::assertStringNotContainsString('قرارداد ضعیف گزارش — همان وب', $e2e);
    }

    // ─────────────── دامنهٔ تغییر: مسیر مستقیم سایر type ها دست‌نخورده ───────────────

    public function test_direct_path_for_other_types_untouched(): void
    {
        $src = $this->read('app/Controllers/Api/InteractionApiController.php');

        // شاخهٔ social_task گزارش همچنان از همان SocialTaskService می‌گذرد
        // (گاردها داخل سرویس اضافه شدند؛ کنترلر دست نخورده — ۴۲۲ SOCIAL_REPORT_GUARDED
        // پاسِ پیام‌های جدید را هم می‌پوشاند)
        self::assertStringContainsString('SocialTaskService::class)->reportTask(', $src);
        self::assertStringContainsString("'SOCIAL_REPORT_GUARDED'", $src);
        self::assertSame(1, substr_count($src, '$this->reportService->submit('));
    }
}
