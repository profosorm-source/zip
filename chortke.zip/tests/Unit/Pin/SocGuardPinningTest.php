<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCGUARD-01 (۲۰۲۶-۱۱-۰۹) — پین‌های ساختاریِ بستن حفرهٔ pre-existing:
 * «عدم گارد social_task در API عمومی تعاملات» (قدم بعدی پیشنهادی کاربر،
 * نقل از سطر آخر مانیفست SEO3).
 *
 * سبک خانه (الگوی Seo3PinningTest): بازرسی سورس — رفتارِ runtime در
 * InteractionApiControllerSocialGuardTest (Mockery) و E2E زنده پین شده.
 */
final class SocGuardPinningTest extends TestCase
{
    private const BASE = __DIR__ . '/../../../';

    private function read(string $path): string
    {
        $src = (string)file_get_contents(self::BASE . $path);
        self::assertNotSame('', $src, "فایل یافت نشد: {$path}");
        return $src;
    }

    // ─────────────── شاخهٔ گاردشده در کنترلر API ───────────────

    public function test_api_controller_routes_social_rate_and_report_through_guarded_service(): void
    {
        $src = $this->read('app/Controllers/Api/InteractionApiController.php');

        // هر دو متد rate() و report() شاخهٔ social_task دارند (دو بار ظاهر می‌شود)
        self::assertSame(2, substr_count($src, "if (str_value(\$data['type']) === 'social_task') {"),
            'شاخهٔ social_task باید در rate() و report() هر دو باشد');
        // از مسیر گاردشدهٔ SocialTaskService (مالک رد + مجری تأییدشده + ۱..۵)
        self::assertStringContainsString('SocialTaskService::class)->rateTask(', $src);
        self::assertStringContainsString('SocialTaskService::class)->reportTask(', $src);
        // شکست گارد: ۴۲۲ + کد اختصاصی — هم‌قرارداد SEO_RATE/REPORT_GUARDED
        self::assertStringContainsString("'SOCIAL_RATE_GUARDED'", $src);
        self::assertStringContainsString("'SOCIAL_REPORT_GUARDED'", $src);
        // پاسخ موفق: میانگین از همان سرویس مشترک تعاملات
        self::assertStringContainsString("getAverageRating('social_task'", $src);
        self::assertStringContainsString('FIX-SOCGUARD-01', $src);
    }

    public function test_direct_legacy_path_untouched_for_other_types(): void
    {
        $src = $this->read('app/Controllers/Api/InteractionApiController.php');

        // سایر type ها (vitrine_listing و…) همان مسیر مستقیم قبلی را دارند —
        // فقط social_task و seo_task گارد می‌شوند (دامنهٔ مصوب؛ بدون whitelist)
        // T27: مسیر عمومی rate حذف شد؛ vitrine_listing فقط از مسیر گاردشدهٔ ویترین امتیاز می‌گیرد
        self::assertSame(0, substr_count($src, '$this->ratingService->rate('));
        self::assertStringContainsString('$this->vitrineService->rateListing(', $src);
        self::assertSame(1, substr_count($src, '$this->reportService->submit('));
        // شاخهٔ seo_task از FIX-SEO3-01 دست‌نخورده مانده (رگرسیون)
        self::assertStringContainsString("'SEO_RATE_GUARDED'", $src);
        self::assertStringContainsString("'SEO_REPORT_GUARDED'", $src);
    }

    public function test_rate_validator_carries_comment_for_api_web_parity(): void
    {
        $src = $this->read('app/Validators/Requests/RateInteractionRequest.php');

        // توازن API/وب: کامنت امتیاز قبلاً توسط safeValidated حذف می‌شد؛
        // حالا برای هر دو شاخهٔ seo_task و social_task به سرویس می‌رسد (FIX-R15C)
        self::assertStringContainsString("'comment' => 'nullable|string|max:1000'", $src);
        self::assertStringContainsString('FIX-SOCGUARD-01', $src);
    }

    // ─────────────── گاردهای سرویس سوشیال: کسی ضعیفشان نکند ───────────────

    public function test_social_service_guards_pinned(): void
    {
        $src = $this->read('app/Services/SocialTask/SocialTaskService.php');

        // گارد تضاد منافع: مالک کمپین به خودش امتیاز نمی‌دهد
        self::assertStringContainsString('if ((int)($ad->user_id ?? 0) === $raterId)', $src);
        self::assertStringContainsString('امتیاز دادن به تسک خودتان مجاز نیست', $src);
        // گارد مجری: فقط اجرای تأییدشدهٔ همین تسک
        self::assertStringContainsString("WHERE ad_id = ? AND executor_id = ? AND status = 'approved'", $src);
        self::assertStringContainsString('فقط مجریِ اجرای تأییدشده می‌تواند به این تسک امتیاز بدهد', $src);
        // کلمپ ستاره‌ها ۱..۵ (دفاع در عمق؛ ولیدیتور API هم ۱..۵ دارد)
        self::assertStringContainsString('$stars = max(1, min(5, $stars));', $src);
        // گزارش: آگهی باید موجود باشد + دلیل/توضیح الزامی
        self::assertStringContainsString('دلیل گزارش الزامی است', $src);
    }

    // ─────────────── رأی وب: فعال اما از همان مسیر گاردشده ───────────────

    public function test_web_social_rate_goes_through_guarded_service(): void
    {
        $src = $this->read('app/Controllers/User/SocialTaskController.php');

        // 🛡️ FIX-SOCRATE-VOTE-EXEC-01 (تصمیم کارفرما ۲۰۲۶-۱۱-۱۰): رأی‌دهی وب
        // از داخل صفحهٔ اجرا فعال شد — قرینهٔ SeoController::rate. گارد قابل
        // دورزدن نیست: همان SocialTaskService::rateTask (مالک رد + مجریِ
        // تأییدشده) + گارد وضعیت approved در خود کنترلر.
        self::assertStringContainsString('$this->socialTaskService->rateTask(', $src);
        self::assertStringContainsString("!== 'approved'", $src);
        self::assertStringContainsString('امتیازدهی فقط پس از تأیید این تسک امکان‌پذیر است', $src);
        self::assertStringContainsString('FIX-SOCRATE-VOTE-EXEC-01', $src);
        // پیام خاموشیِ قدیمی حذف شد (روت وب دیگر ۴۲۲ کلی نمی‌دهد)
        self::assertStringNotContainsString('فعلاً از این مسیر فعال نیست', $src);
        // و همچنان اندپوینت امتیاز/گزارش سوشیال در API اپ موبایل وجود ندارد
        $api = $this->read('app/Controllers/Api/SocialTaskApiController.php');
        self::assertStringNotContainsString('rateTask', $api);
        self::assertStringNotContainsString('reportTask', $api);
    }
}
