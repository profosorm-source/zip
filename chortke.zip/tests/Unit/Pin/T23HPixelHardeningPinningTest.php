<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-T23H (بچ T23H — سخت‌سازی پیکسل اثبات فرود؛ گزینهٔ ۲ کارفرما):
 * پین ساختاری چهار گیت جدید روی مسیر پیکسل. یافتهٔ T23-01 گزارش بازبینی
 * ۲۲/۲۳: «پیکسل bearer است؛ جعلِ آگاهانهٔ Referer ممکن» — این بچ جعل را
 * گران می‌کند (نه صفر): هر چهار گیت زیر باید همزمان در سورس بمانند.
 */
final class T23HPixelHardeningPinningTest extends TestCase
{
    /** @return non-empty-string */
    private function read(string $rel): string
    {
        $path = __DIR__ . '/../../../' . $rel;
        self::assertFileExists($path, "فایل {$rel} باید وجود داشته باشد");
        $src = (string)file_get_contents($path);
        self::assertNotSame('', $src);
        return $src;
    }

    public function test_service_has_all_four_hardening_gates(): void
    {
        $src = $this->read('app/Services/SeoLandingProofService.php');

        // گیت مرورگری
        self::assertStringContainsString('FIX-T23H-02', $src);
        self::assertStringContainsString('looksLikeNonBrowserClient', $src);
        self::assertStringContainsString("'non_browser_client'", $src);
        self::assertStringContainsString('NON_BROWSER_UA_PATTERN', $src);

        // گیت تطبیق کلاینت (سه حالت ستون click_user_agent)
        self::assertStringContainsString('userAgentMatches', $src);
        self::assertStringContainsString('pixel_client_mismatch', $src);
        self::assertStringContainsString('pixel_click_without_client', $src);
        self::assertStringContainsString('pixel_client_unknown_legacy', $src);
        self::assertStringContainsString("'client_mismatch'", $src);

        // گیت زمانی
        self::assertStringContainsString('FIX-T23H-03', $src);
        self::assertStringContainsString('PIXEL_MIN_INTERVAL_SECONDS', $src);
        self::assertStringContainsString('pixel_too_fast', $src);
        self::assertStringContainsString("'too_fast'", $src);

        // سیگنال IP (فقط لاگ)
        self::assertStringContainsString('FIX-T23H-04', $src);
        self::assertStringContainsString('pixel_ip_mismatch', $src);
    }

    public function test_min_interval_constant_is_one_second(): void
    {
        $src = $this->read('app/Services/SeoLandingProofService.php');
        self::assertStringContainsString('public const PIXEL_MIN_INTERVAL_SECONDS = 1;', $src);
    }

    public function test_model_stamps_click_evidence_in_atomic_update(): void
    {
        $src = $this->read('app/Models/SeoExecution.php');

        // 🛡️ FIX-T23H-01: شواهد لحظهٔ کلیک در همان تک UPDATE مهر می‌شوند
        self::assertStringContainsString('FIX-T23H-01', $src);
        self::assertStringContainsString('click_ip = ?', $src);
        self::assertStringContainsString('click_user_agent = ?', $src);
        // findByClickToken شواهد را برمی‌گرداند (مسیر عمومی پیکسل)
        self::assertStringContainsString('ip_address, click_ip, click_user_agent', $src);
    }

    public function test_go_controller_passes_click_ip_and_user_agent(): void
    {
        $src = $this->read('app/Controllers/User/SeoController.php');
        // مهر کلیک با شواهد (گیت‌های پیکسل به آن‌ها تکیه می‌کنند)
        self::assertStringContainsString('consumeClickToken($executionId, $userId, $token, get_client_ip(), $clickUserAgent)', $src);
        self::assertStringContainsString('HTTP_USER_AGENT', $src);
    }

    public function test_migration_adds_click_evidence_columns_idempotently(): void
    {
        $src = $this->read('database/migrations/2026_11_12_0001_seo_pixel_hardening.sql');
        self::assertStringContainsString('FIX-T23H-01', $src);
        self::assertStringContainsString('ADD COLUMN IF NOT EXISTS `click_ip`', $src);
        self::assertStringContainsString('ADD COLUMN IF NOT EXISTS `click_user_agent`', $src);
        // هر دو ستون افزودنی و nullable — بدون تغییر دادهٔ موجود
        self::assertStringContainsString('NULL DEFAULT NULL', $src);
    }
}
