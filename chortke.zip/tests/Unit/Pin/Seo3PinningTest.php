<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SEO3-01..03 — پین‌های ساختاری سه تصمیم کاربر (۲۰۲۶-۱۱-۰۹) روی درخت زنده.
 *
 * سبک خانه: بازرسی سورس (رفتارِ runtime در تست‌های Mockery/زنده پین شده):
 *   ۱) فعال‌سازی report/rate سئو + نمایش (وب/API/تبلیغ‌دهنده)
 *   ۲) حذف نسل اول فاز ۱ (SeoClickService/SeoTaskClick/جدول)
 *   ۳) اندپوینت proof-status + poll سبک نشان اثبات
 */
final class Seo3PinningTest extends TestCase
{
    private const BASE = __DIR__ . '/../../../';

    private function read(string $path): string
    {
        $src = (string)file_get_contents(self::BASE . $path);
        self::assertNotSame('', $src, "فایل یافت نشد: {$path}");
        return $src;
    }

    // ─────────────── تصمیم ۱: report/rate فعال ───────────────

    public function test_routes_register_report_rate_and_proof_status(): void
    {
        $src = $this->read('routes/user.php');

        // روت‌های گزارش/امتیاز با گروه کامل $authCSRF (لاگین + CSRF + ریت‌لیمیت)
        self::assertStringContainsString("\$r->post('/seo/{id}/report', [SeoController::class, 'report'],    \$authCSRF);", $src);
        self::assertStringContainsString("\$r->post('/seo/{id}/rate',   [SeoController::class, 'rate'],      \$authCSRF);", $src);
        // اندپوینت وضعیت اثبات — GET سبک با $auth (بدون CSRF — فقط خواندن)
        self::assertStringContainsString("\$r->get('/seo/execution/{id}/proof-status', [SeoController::class, 'proofStatus'], \$auth);", $src);
        self::assertStringContainsString('FIX-SEO3-01', $src);
    }

    public function test_web_controller_guards_execution_status(): void
    {
        $src = $this->read('app/Controllers/User/SeoController.php');

        // گزارش فقط برای در حال انجام/تکمیل‌شده (۴۲۲ در غیر این صورت)
        self::assertStringContainsString("in_array((string)\$execution->status, ['started', 'completed'], true)", $src);
        // امتیاز فقط پس از تکمیل
        self::assertStringContainsString("(string)\$execution->status !== 'completed'", $src);
        // ad_id از خود اجرا مشتق می‌شود — نه از ورودی کاربر
        self::assertStringContainsString('$this->seoService->rateTask($userId, (int)$execution->ad_id, $stars, $comment)', $src);
    }

    public function test_show_execution_view_has_feedback_card_and_scripts(): void
    {
        $src = $this->read('views/user/seo/show-execution.php');

        self::assertStringContainsString('id="seoFeedbackCard"', $src);
        self::assertStringContainsString('id="seoReportForm"', $src);
        self::assertStringContainsString('id="seoRateForm"', $src);
        self::assertStringContainsString('seo-star-btn', $src);
        self::assertStringContainsString('userseoshowexecution.js', $src);
        // قواعد نمایش سمت سرور: گزارش فقط بدون گزارش قبلی؛ امتیاز فقط completed
        self::assertStringContainsString("in_array(\$status, ['started', 'completed'], true) && !\$hasReported", $src);
        self::assertStringContainsString("\$canRate = \$status === 'completed'", $src);
    }

    public function test_index_and_advertiser_views_show_community_rating(): void
    {
        $index = $this->read('views/user/seo/index.php');
        self::assertStringContainsString('seo-community-rating', $index);
        self::assertStringContainsString('رأی مجریان', $index);
        self::assertStringContainsString('$ratings[(int)$ad->id]', $index);

        $ads = $this->read('views/user/ads/show.php');
        self::assertStringContainsString('id="seoCommunityRating"', $ads);
        self::assertStringContainsString('seo-rating-row', $ads);
    }

    public function test_api_interactions_routes_seo_task_through_guarded_service(): void
    {
        $src = $this->read('app/Controllers/Api/InteractionApiController.php');

        // type=seo_task از مسیر گاردشدهٔ سئو می‌گذرد (هر دو اندپوینت)
        self::assertStringContainsString("str_value(\$data['type']) === 'seo_task'", $src);
        self::assertStringContainsString('SEO_RATE_GUARDED', $src);
        self::assertStringContainsString('SEO_REPORT_GUARDED', $src);
        self::assertStringContainsString('SeoService::class)->rateTask(', $src);
        self::assertStringContainsString('SeoService::class)->reportTask(', $src);
    }

    // ─────────────── تصمیم ۲: حذف نسل اول ───────────────

    public function test_dead_gen1_click_code_is_removed(): void
    {
        self::assertFileNotExists(self::BASE . 'app/Services/Seo/SeoClickService.php', 'SeoClickService باید حذف شود (تصمیم ۲)');
        self::assertFileNotExists(self::BASE . 'app/Models/SeoTaskClick.php', 'مدل SeoTaskClick باید حذف شود (تصمیم ۲)');
        self::assertFileNotExists(self::BASE . 'tests/Unit/Services/SeoClickServiceTest.php', 'تست سرویس مرده هم حذف می‌شود');

        // هیچ ارجاع زنده‌ای نباید مانده باشد (غیر از مانیفست‌های تاریخی و پین‌ها)
        foreach (['app', 'routes', 'views', 'config', 'core', 'public'] as $dir) {
            $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator(self::BASE . $dir, \FilesystemIterator::SKIP_DOTS));
            foreach ($it as $file) {
                if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
                    $content = (string)file_get_contents($file->getPathname());
                    self::assertStringNotContainsString('SeoClickService', $content, 'ارجاع زنده به SeoClickService: ' . $file->getPathname());
                    self::assertStringNotContainsString('SeoTaskClick', $content, 'ارجاع زنده به SeoTaskClick: ' . $file->getPathname());
                }
            }
        }
    }

    public function test_drop_migration_exists_with_tombstone(): void
    {
        $src = $this->read('database/migrations/2026_11_09_0001_drop_seo_task_clicks.sql');
        self::assertStringContainsString('DROP TABLE IF EXISTS `seo_task_clicks`', $src);
        self::assertStringContainsString('FIX-SEO3-02', $src);
        // مایگریشن ساختِ اصلی حفظ می‌شود (زنجیرهٔ تاریخی نصب تازه)
        self::assertFileExists(self::BASE . 'database/migrations/2026_11_01_0003_seo_task_clicks.sql');
    }

    public function test_preflight_pin_counts_263_base_tables(): void
    {
        $src = $this->read('tests/Integration/RuntimeInfrastructurePreflightTest.php');
        self::assertStringContainsString('263, // FIX-C97', $src);
        self::assertStringContainsString('FIX-SEO3-02', $src);
        // پین قدیمی ۲۶۴ نباید برگردد (جدول seo_task_clicks حذف شده)
        self::assertStringNotContainsString('            264, //', $src);
    }

    // ─────────────── تصمیم ۳: poll نشان اثبات ───────────────

    public function test_proof_status_endpoint_derives_state_from_stamps(): void
    {
        $src = $this->read('app/Controllers/User/SeoController.php');

        self::assertStringContainsString('public function proofStatus(): void', $src);
        // همان استنتاج سه‌حالتهٔ رندر اولیه
        self::assertStringContainsString("(\$execution->landing_verified_at !== null) ? 'landing' : 'click'", $src);
        // badge سرور-ساخته — منبع واحد با ویو
        self::assertStringContainsString('SeoLandingProofService::badgeFor($state, $mode)', $src);
    }

    public function test_badge_map_is_single_source_in_service(): void
    {
        $src = $this->read('app/Services/SeoLandingProofService.php');
        self::assertStringContainsString('public static function badgeFor(string $state, string $mode): array', $src);
        self::assertStringContainsString('بدون اثبات — سقف پاداش ۶۰٪', $src);
        self::assertStringContainsString('فرود اثبات‌شده — سقف کامل پاداش', $src);

        // ویوی execute از سرویس می‌خواند — نقشهٔ inline حذف شده
        $view = $this->read('views/user/seo/execute.php');
        self::assertStringContainsString('SeoLandingProofService::badgeFor($proofState, $proofMode)', $view);
        self::assertStringNotContainsString("'st-danger'", $view);
        // data attribute برای JS
        self::assertStringContainsString('data-proof-status-url', $view);
        self::assertStringContainsString('data-proof-state', $view);
    }

    public function test_execute_js_polls_on_visibility_and_before_complete(): void
    {
        $src = $this->read('public/assets/js/views/userseoexecute.js');

        // poll سبک: فقط بازگشت به تب/فوکوس + قبل از تکمیل — نه timer
        self::assertStringContainsString("document.addEventListener('visibilitychange'", $src);
        self::assertStringContainsString("window.addEventListener('focus'", $src);
        self::assertStringContainsString('await refreshProofStatus(true);', $src);
        // throttle ۵ ثانیه‌ای
        self::assertStringContainsString('5000', $src);
        // متن نشان از سرور می‌آید — JS ترجمه نمی‌کند
        self::assertStringContainsString('data.badge', $src);
    }

    public function test_api_execution_includes_proof_state_and_ads_rating(): void
    {
        $src = $this->read('app/Controllers/Api/SeoTaskApiController.php');
        self::assertStringContainsString("'proof_state'             => \$proofState", $src);
        self::assertStringContainsString("'avg_rating'", $src);
        self::assertStringContainsString("'rating_count'", $src);
    }
}
