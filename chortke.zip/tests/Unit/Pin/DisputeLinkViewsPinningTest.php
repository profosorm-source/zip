<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-DISPUTELINK — پین لینک پیوست اختلاف در ویوها:
 *  ۱) هر دو ویوی گفت‌وگوی اختلاف (کاربر + ادمین) پیوست را از مسیر کنترل‌شدهٔ
 *     FileController می‌سازند: /file/view/dispute-evidence/<basename> —
 *     گارد مالکیت FIX-FILEACCESS-04 فقط برای طرفین پرونده/ادمین مجاز می‌کند.
 *  ۲) رفتار قدیمی (sanitize_url مستقیم روی attachment — که برای مسیر نسبی
 *     '#' برمی‌گرداند و لینک مرده می‌ساخت) در هیچ‌کدام برنگشته.
 *  ۳) basename + rawurlencode (الگوی امن kyc/review و custom-tasks/show):
 *     هر مقدار ذخیره‌شده فقط به یک نام فایل داخل پوشهٔ dispute-evidence
 *     تبدیل می‌شود؛ پوشه هاردکد است و از دادهٔ کاربر نمی‌آید.
 *  ۴) شاخهٔ مقدار مطلق قدیمی/فرضی از sanitize_url با allowlist scheme
 *     (http/https) می‌گذرد — جاوااسکریپت:/دیتا: بسته می‌ماند (FIX-R19-A9-1).
 *  ۵) قرارداد نوشتن: هر دو نویسندهٔ زندهٔ attachment مسیر نسبی با پیشوند
 *     پوشه ذخیره می‌کنند (UploadService → dispute-evidence/<hash>.<ext>).
 *
 * @group architecture
 */
final class DisputeLinkViewsPinningTest extends TestCase
{
    private static function repoPath(string $rel): string
    {
        return dirname(__DIR__, 3) . '/' . $rel;
    }

    private static function src(string $rel): string
    {
        $src = file_get_contents(self::repoPath($rel));
        self::assertIsString($src);
        return $src;
    }

    /** @test */
    public function user_dispute_panel_links_attachment_through_file_view_route(): void
    {
        $src = self::src('views/user/influencer/dispute-panel.php');

        // مسیر کنترل‌شدهٔ FileController با پوشهٔ هاردکد dispute-evidence
        $this->assertStringContainsString("url('/file/view/dispute-evidence/' . rawurlencode(basename((string)\$m->attachment)))", $src);
        // لینک پیوست از متغیر محاسبه‌شدهٔ $attHref می‌آید (نه echo خام ستون)
        $this->assertStringContainsString('href="<?= $attHref ?>"', $src);
        // شاخهٔ مقدار مطلق قدیمی: allowlist scheme همان FIX-R19-A9-1
        $this->assertStringContainsString("preg_match('#^https?://#i', (string)\$m->attachment)", $src);

        // رفتار قدیمی حذف شده: sanitize_url مستقیم روی attachment
        $this->assertStringNotContainsString('sanitize_url($m->attachment)', $src);
        // فایل پیوست هنوز rel noopener + target blank دارد (قرارداد قبلی)
        $this->assertStringContainsString('rel="noopener noreferrer" target="_blank"', $src);
    }

    /** @test */
    public function admin_dispute_detail_links_attachment_through_file_view_route(): void
    {
        $src = self::src('views/admin/influencer/dispute-detail.php');

        // همان قرارداد در ویوی ادمین (تک‌خطی فشرده)
        $this->assertStringContainsString("url('/file/view/dispute-evidence/' . rawurlencode(basename((string)\$m->attachment)))", $src);
        $this->assertStringContainsString("preg_match('#^https?://#i', (string)\$m->attachment)", $src);

        // رفتار قدیمی حذف شده
        $this->assertStringNotContainsString('sanitize_url($m->attachment)', $src);
        // proof_link بیرونی (فیلد جدا) عمداً دست‌نخورده — sanitize_url باقی است
        $this->assertStringContainsString('sanitize_url($order->proof_link)', $src);
    }

    /** @test */
    public function both_views_keep_attachment_folder_hardcoded_and_confined(): void
    {
        foreach ([
            'views/user/influencer/dispute-panel.php',
            'views/admin/influencer/dispute-detail.php',
        ] as $rel) {
            $src = self::src($rel);

            // پوشهٔ هدف فقط از کد می‌آید؛ مسیرِ کاملِ attachment (که ممکن است
            // حاوی اجزای مسیر باشد) هرگز مستقیم داخل URL کپی نمی‌شود
            $this->assertStringContainsString('/file/view/dispute-evidence/', $src);
            // الگوی قدیمی دقیق (sanitize_url بدون cast و بدون شاخهٔ مطلق)
            $this->assertStringNotContainsString('sanitize_url($m->attachment)', $src);
            // مقدار خام داخل url() — نه به‌تنهایی، نه به‌عنوان پیشوند پوشه
            $this->assertStringNotContainsString('url($m->attachment', $src);
            $this->assertStringNotContainsString("url('/file/view/' . \$m->attachment", $src);
        }
    }

    /** @test */
    public function live_writers_still_store_relative_prefixed_paths(): void
    {
        // قرارداد نوشتن که لینک‌ساز به آن تکیه دارد (bootstrap برای تغییر نیست؛
        // فقط پین): هر دو نویسندهٔ زندهٔ attachment خروجی نسبی UploadService را
        // ذخیره می‌کنند — بدون URL مطلق.
        $web = self::src('app/Controllers/User/InfluencerController.php');
        $this->assertStringContainsString("upload(\$_FILES['attachment'], 'dispute-evidence')", $web);
        $this->assertStringContainsString("if (\$up['success']) \$attachment = \$up['path'];", $web);

        $api = self::src('app/Controllers/Api/InfluencerController.php');
        $this->assertStringContainsString("upload(\$_FILES['attachment'], 'dispute-evidence')", $api);
        $this->assertStringContainsString("if (\$up['success']) \$attachment = \$up['path'];", $api);
    }

    /** @test */
    public function file_controller_serve_pattern_accepts_generated_filenames(): void
    {
        // نام فایلی که ویو تولید می‌کند باید از sanitizeFilename فایل‌کنترلر
        // رد شود (الگوی هش ۸..۶۴ هگز) — قرارداد سر تا سر مسیر.
        $src = self::src('app/Controllers/FileController.php');
        $this->assertStringContainsString("FILENAME_PATTERN", $src);

        $pattern = '/^(captcha_[a-f0-9]{16}|[a-f0-9]{8,64})\.(jpg|png|webp|gif|pdf|mp4|webm|mov)$/i';
        foreach ([
            'dispute-evidence/5555666677778888.jpg', // قالب واقعی نوشتهٔ UploadService
            '5555666677778888.jpg',                  // مقدار بدون پیشوند (دفاع عمقی)
        ] as $stored) {
            $generated = basename($stored);
            $this->assertRegExp($pattern, $generated);
        }
        // مقدار مسیر-پیمایی هرگز به نام فایل معتبر تبدیل نمی‌شود
        $this->assertNotRegExp($pattern, basename('../../etc/passwd'));
        $this->assertNotRegExp($pattern, basename('dispute-evidence/'));
    }

    /** @test */
    public function route_dispute_evidence_folder_is_registered(): void
    {
        // روت عمومی FileController::serve باید همچنان ثبت باشد (مسیر هدف لینک)
        $src = self::src('routes/public.php');
        $this->assertStringContainsString('file/view', $src);
        $this->assertStringContainsString('FileController', $src);
    }
}
