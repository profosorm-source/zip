<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-FILEACCESS (D4-N1) — پین‌های اسکمای مالکیت فایل در FileAccess:
 * هر چهار متد دارای ستون شبح بودند و روی DB واقعی «Unknown column» می‌گرفتند.
 * پین‌ها هم‌الگوی M22MedMainPinningTest: رشته/الگو در سورس واقعی درخت.
 * سنجشِ اجراییِ همان کوئری‌ها روی DB واقعی: tools/fileaccess-ownership-live-test.php
 */
final class FileAccessOwnershipSchemaPinningTest extends TestCase
{
    private static function src(string $rel): string
    {
        $p = dirname(__DIR__, 3) . '/' . $rel;
        self::assertFileExists($p, "فایل مورد انتظار وجود ندارد: {$rel}");
        return (string)file_get_contents($p);
    }

    /** @return string تکهٔ سورس متد از ابتدای امضایش تا انتهای تقریبی (بدون خطوط کامنت — الگوی M22MedMain: کامنتِ مستندِ «چه بود» نادیده گرفته می‌شود، خود SQL سنجیده می‌شود) */
    private static function method(string $src, string $name, int $len = 1600): string
    {
        $pos = (int)strpos($src, "function {$name}");
        self::assertNotFalse($pos, "متد {$name} پیدا نشد");
        $chunk = substr($src, $pos, $len);
        $codeLines = [];
        foreach (explode("\n", $chunk) as $line) {
            $t = trim($line);
            if ($t === '' || str_starts_with($t, '//') || str_starts_with($t, '*') || str_starts_with($t, '/*')) {
                continue;
            }
            $codeLines[] = $line;
        }
        return implode("\n", $codeLines);
    }

    // ── FIX-FILEACCESS-01: receipt از ستون زندهٔ receipt_path ──
    /** @test */
    public function receipt_ownership_uses_live_receipt_path_column(): void
    {
        $src = self::src('app/Models/FileAccess.php');
        $m = self::method($src, 'checkReceiptOwnership');
        $this->assertStringContainsString('FROM manual_deposits', $m);
        $this->assertStringContainsString("SUBSTRING_INDEX(receipt_path, '/', -1) = ?", $m);
        // ستون شبح حذف شد (کامنت‌های مستند هم اشارهٔ «چه بود» ندارند تا SQL سنجیده شود)
        $this->assertStringNotContainsString('receipt_image', $m);
    }

    // ── FIX-FILEACCESS-02: task-samples از منابع زندهٔ ماژول ۲۲ (ads + worker_id) ──
    /** @test */
    public function task_sample_ownership_reads_live_custom_task_sources(): void
    {
        $src = self::src('app/Models/FileAccess.php');
        $m = self::method($src, 'checkTaskSampleOwnership', 2400);
        $this->assertStringContainsString('FROM ads', $m);
        $this->assertStringContainsString("type = 'custom_task'", $m);
        $this->assertStringContainsString('FROM custom_task_submissions s', $m);
        $this->assertStringContainsString('JOIN ads a ON a.id = s.task_id', $m);
        $this->assertStringContainsString('s.worker_id = ?', $m);
        $this->assertStringContainsString("SUBSTRING_INDEX(a.sample_image, '/', -1) = ?", $m);
        // جدول legacy و ستون legacy هر دو از SQL رفتند (کامنت مستند مهم نیست)
        $this->assertStringNotContainsString('FROM custom_tasks', $m);
        $this->assertStringNotContainsString('cts.user_id', $m);
    }

    // ── FIX-FILEACCESS-03: ad-tasks روی advertisement_id (نه ads_id) ──
    /** @test */
    public function ad_task_sample_ownership_uses_advertisement_id(): void
    {
        $src = self::src('app/Models/FileAccess.php');
        $m = self::method($src, 'checkAdTaskSampleOwnership', 2200);
        $this->assertStringContainsString('FROM task_executions te', $m);
        $this->assertStringContainsString('JOIN ads a ON a.id = te.advertisement_id', $m);
        $this->assertStringContainsString('te.executor_id = ?', $m);
        $this->assertStringContainsString("SUBSTRING_INDEX(a.sample_image, '/', -1) = ?", $m);
        // ستون شبح رفت
        $this->assertStringNotContainsString('te.ads_id', $m);
    }

    // ── FIX-FILEACCESS-04: dispute-evidence از dispute_messages.attachment ──
    /** @test */
    public function dispute_evidence_ownership_reads_dispute_messages(): void
    {
        $src = self::src('app/Models/FileAccess.php');
        $m = self::method($src, 'checkDisputeEvidenceOwnership', 2400);
        $this->assertStringContainsString('FROM dispute_messages dm', $m);
        $this->assertStringContainsString('JOIN disputes d ON d.id = dm.dispute_id', $m);
        $this->assertStringContainsString('dm.attachment IS NOT NULL', $m);
        $this->assertStringContainsString("SUBSTRING_INDEX(dm.attachment, '/', -1) = ?", $m);
        // فرستنده یا هر یک از طرفین پرونده
        $this->assertStringContainsString('sender_id === $userId', $m);
        $this->assertStringContainsString('opener_id === $userId', $m);
        $this->assertStringContainsString('target_id === $userId', $m);
        // دو ستون شبح رفتند
        $this->assertStringNotContainsString('te.ads_id', $m);
        $this->assertStringNotContainsString('te.dispute_evidence', $m);
    }

    // ── رگرسیون: متدهای سالم قبلی دست‌نخورده ماندند ──
    /** @test */
    public function intact_methods_keep_their_contracts(): void
    {
        $src = self::src('app/Models/FileAccess.php');
        // N10 (FIX-M22-MED) — نباید با این بچ بشکند
        $this->assertStringContainsString('FROM custom_task_submissions s', $src);
        // 🛡️ FIX-V22-04a: مقایسهٔ basename به ستون generated ایندکس‌پذیر منتقل شد
        // (هم‌ارزش SUBSTRING_INDEX(s.proof_file,'/',-1) — تعریف ستون در migration
        // 2026_11_08_0001)؛ معنای مالکیت دوجانبه (مجری/کارفرما) دست‌نخورده است.
        $this->assertStringContainsString('WHERE s.proof_file_basename = ?', $src);
        // بقیهٔ متدها روی جداول معتبر خودشان ماندند
        $this->assertStringContainsString('FROM kyc_verifications', $src);
        $this->assertStringContainsString('FROM story_orders', $src);
        $this->assertStringContainsString('FROM influencer_profiles', $src);
        $this->assertStringContainsString('FROM message_attachments ma', $src);
        $this->assertStringContainsString('FROM ticket_messages tm', $src);
    }

    // ── پیمایش کل فایل: هیچ ستون شبحی در هیچ SQL زنده‌ای نماند ──
    /** @test */
    public function no_ghost_columns_anywhere_in_file_queries(): void
    {
        $src = self::src('app/Models/FileAccess.php');
        // خطوط کامنت (// یا *) را حذف می‌کنیم؛ فقط کد سنجیده می‌شود
        $codeLines = [];
        foreach (explode("\n", $src) as $line) {
            $t = trim($line);
            if ($t === '' || str_starts_with($t, '//') || str_starts_with($t, '*') || str_starts_with($t, '/*')) {
                continue;
            }
            $codeLines[] = $line;
        }
        $code = implode("\n", $codeLines);
        $this->assertStringNotContainsString('receipt_image', $code);
        $this->assertStringNotContainsString('te.ads_id', $code);
        $this->assertStringNotContainsString('te.dispute_evidence', $code);
        $this->assertStringNotContainsString('FROM custom_tasks', $code);
    }
}
