<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M22-MED — پین‌های محتوایی اصلاحات main (هم‌الگوی M22AdminProofUiPinningTest):
 * هر ادعا یک رشته/الگو در سورس واقعی درخت است.
 */
final class M22MedMainPinningTest extends TestCase
{
    private static function src(string $rel): string
    {
        $p = dirname(__DIR__, 3) . '/' . $rel;
        self::assertFileExists($p, "فایل مورد انتظار وجود ندارد: {$rel}");
        return (string)file_get_contents($p);
    }

    // ── T22-16: بازنویسی کوئری تأیید خودکار ──
    /** @test */
    public function auto_approval_query_uses_per_task_hours_and_limit(): void
    {
        $src = self::src('app/Models/CustomTaskSubmissionModel.php');
        $this->assertStringContainsString('INTERVAL COALESCE(ct.auto_approve_hours, ?) HOUR', $src);
        // 🛡️ FIX-V22-03c: ترتیب صف ابتدا بر اساس شمارندهٔ شکست‌ها (ضدگرسنگی)، سپس قدیمی‌ترین
        $this->assertStringContainsString('ORDER BY s.auto_approve_attempts ASC, s.submitted_at ASC', $src);
        $this->assertStringContainsString('LIMIT {$limit}', $src);
        // FOR UPDATE از کوئریِ autocommit حذف شد (قفل بی‌اثر) — دیگر در این متد نیست
        $method = substr($src, (int)strpos($src, 'getOldSubmissionsForAutoApproval'), 1600);
        $this->assertStringNotContainsString('FOR UPDATE', $method);
    }

    // ── T22-10: زنجیرهٔ امتیازدهی ──
    /** @test */
    public function rating_chain_is_coherent(): void
    {
        $request = self::src('app/Validators/Requests/RateSubmissionRequest.php');
        $this->assertStringContainsString("'review_text'", $request);
        $this->assertStringNotContainsString("'feedback'", $request);

        $job = self::src('app/Jobs/CustomTask/RateSubmissionJob.php');
        $this->assertStringContainsString("reviewText !== '' ? \$reviewText : null", $job);

        $service = self::src('app/Services/Interaction/RatingService.php');
        $this->assertStringContainsString('UPDATE interactions SET value = ?, context = ?', $service);
        $this->assertStringNotContainsString('function getRatingsByRef', $service);

        // داشبوردها از interactions می‌خوانند (نه task_ratings با ستون‌های ناموجود)
        $analytics = self::src('app/Models/CustomTaskAnalyticsModel.php');
        $this->assertStringNotContainsString('FROM task_ratings', $analytics);
        $this->assertStringContainsString("i.interactable_type = 'custom_task'", $analytics);
        $this->assertStringContainsString("i.interaction_type = 'rating'", $analytics);
    }

    // ── N2: درآمد واقعی کاربر به‌جای بودجهٔ کل بازار ──
    /** @test */
    public function executor_stats_carry_per_currency_earnings(): void
    {
        $src = self::src('app/Services/UnifiedTaskService.php');
        $this->assertStringContainsString('as total_earned_irt', $src);
        $this->assertStringContainsString('as total_earned_usdt', $src);
        // کلید و کوئری قدیمی حذف شده (کامنت مستند اشکالی ندارد؛ خود SELECT/کلید نه)
        $this->assertStringNotContainsString('as available_earnings', $src);
        $this->assertStringNotContainsString("'available_earnings' =>", $src);
    }

    // ── N7: آنالیتیکس از منابع واقعی با قرارداد تخت ──
    /** @test */
    public function custom_task_period_metrics_contract(): void
    {
        $model = self::src('app/Models/CustomTaskAnalyticsModel.php');
        $this->assertStringContainsString('analytics_getCustomTaskPeriodMetrics', $model);
        foreach (['period', 'total_tasks', 'active_tasks', 'total_budget_irt', 'total_budget_usdt',
                  'reward_paid_irt', 'reward_paid_usdt', 'submissions', 'approved', 'pending',
                  'rejected', 'completions', 'unique_workers'] as $key) {
            $this->assertStringContainsString("'{$key}'", $model);
        }
        $service = self::src('app/Services/Analytics/AnalyticsService.php');
        $this->assertStringContainsString('getCustomTaskMetrics(?string $period', $service);
        $this->assertStringNotContainsString("safeCount('custom_tasks'", $service);
        $repo = self::src('app/Services/Analytics/AnalyticsQueryService.php');
        $this->assertStringContainsString('getCustomTaskPeriodMetrics', $repo);
    }

    // ── N10: FileAccess ownership از custom_task_submissions ──
    /** @test */
    public function file_access_task_proof_ownership_query(): void
    {
        $src = self::src('app/Models/FileAccess.php');
        $this->assertStringContainsString('FROM custom_task_submissions s', $src);
        // 🛡️ E2-review + FIX-V22-04a: مقایسه روی basename — ستون proof_file با
        // پیشوند پوشه ذخیره می‌شود ولی پارامتر FileController basename است؛ از این
        // بچ مقایسه روی ستون generated ایندکس‌پذیر proof_file_basename انجام می‌شود
        // (هم‌ارزش SUBSTRING_INDEX(proof_file,'/',-1) در تعریف ستون — migration
        // 2026_11_08_0001) تا هر بازدید مدرک full-table-scan نزند.
        $this->assertStringContainsString('WHERE s.proof_file_basename = ?', $src);
        // متد checkTaskProofOwnership نباید دیگر به task_executions.ads_id (ستون ناموجود) بزند —
        // سایر متدهای این فایل خارج از دامنهٔ بخش ۲۲ هستند (قید فقط روی خود متد).
        // کامنتِ مستندِ «چه بود» را نادیده می‌گیریم؛ خود SQL سنجیده می‌شود.
        $m = substr($src, (int)strpos($src, 'function checkTaskProofOwnership'), 900);
        $qStart = (int)strpos($m, '"SELECT');
        $q = substr($m, $qStart, (int)strpos($m, 'LIMIT 1"') + 9 - $qStart);
        $this->assertStringNotContainsString('te.ads_id', $q);
        $this->assertStringNotContainsString('task_executions', $q);
    }

    // ── D2-N14: findTaskReport با JOIN دوگانه ──
    /** @test */
    public function find_task_report_uses_dual_join(): void
    {
        $src = self::src('app/Models/InteractionModel.php');
        $this->assertEquals(0, substr_count($src, 'LEFT JOIN custom_tasks'), 'دیگر نباید به جدول legacy وصل شود');
        $this->assertSame(2, substr_count($src, "ads_t.id = r.task_id"), 'findTaskReport + adminListTaskReports هر دو باید JOIN اصلاح‌شده داشته باشند');
    }

    // ── D1-N4: XP=0 قابل تنظیم ──
    /** @test */
    public function xp_zero_is_settable(): void
    {
        $src = self::src('app/Listeners/TaskCompletedListener.php');
        $this->assertStringContainsString('rawXp', $src);
        $this->assertStringNotContainsString("setting('xp_custom_task', 10) ?: 10", $src);
    }

    // ── D2-N12: لاگ فعالیت فقط پس از موفقیت ──
    /** @test */
    public function activity_logs_gated_on_success(): void
    {
        $ad = self::src('app/Controllers/Admin/AdTaskController.php');
        $this->assertStringContainsString("if (!empty(\$result['success'])) {", $ad);
        $exec = self::src('app/Controllers/Admin/ExecutorTaskController.php');
        $this->assertStringContainsString("if (!empty(\$result['ok'])) {", $exec);
    }

    // ── N8: گاردهای مسیرها ──
    /** @test */
    public function route_guards_are_in_place(): void
    {
        $user = self::src('routes/user.php');
        $this->assertStringContainsString("'/custom-tasks/rate', [CustomTaskController::class, 'rateSubmission'], \$tasksSecure", $user);
        $this->assertStringNotContainsString("'/user/custom-tasks/rate'", $user);
        $this->assertStringNotContainsString("'/custom-tasks/review'", $user);
        $this->assertStringNotContainsString("'/custom-tasks/my-submissions-list'", $user);
        $this->assertStringNotContainsString("'/custom-tasks/detail/{id}'", $user);
        $this->assertStringNotContainsString("'/custom-tasks/{id}/approve'", $user);
        $this->assertStringNotContainsString("'/custom-tasks/{id}/reject'", $user);

        $api = self::src('routes/api.php');
        // 🛡️ FIX-BEHAV1-08: RequireFeature حالا با ,json است (پاس JSON به موبایل Bearer)
        $this->assertStringContainsString("ApiAuthMiddleware::class . ':customtask.read', RequireFeature::class . ':tasks,json']", $api);
        $this->assertStringContainsString("ApiAuthMiddleware::class . ':customtask.write', RequireFeature::class . ':tasks,json']", $api);
    }

    // ── T22-08/T22-11/T22-21: حذف‌ها ──
    /** @test */
    public function dead_code_removals_are_complete(): void
    {
        $admin = self::src('app/Services/CustomTask/AdminCustomTaskService.php');
        foreach (['function pauseTask', 'function deleteTask', 'function getAdminAnalytics'] as $needle) {
            $this->assertStringNotContainsString($needle, $admin);
        }
        $analytics = self::src('app/Models/CustomTaskAnalyticsModel.php');
        foreach (['function analytics_recordView', 'function analytics_recordStart', 'function analytics_incrementDailyMetric',
                  'function recordTaskView', 'function getTaskAnalytics', 'function getAdminTaskStats'] as $needle) {
            $this->assertStringNotContainsString($needle, $analytics);
        }
        $ads = self::src('app/Models/Ads.php');
        $this->assertStringNotContainsString('function expireOldAdvertisements', $ads);
        $this->assertStringContainsString('a.task_type', $ads, 'N6: فیلتر نوع تسک تا مدل');
        $moderation = self::src('app/Services/CustomTask/CustomTaskModerationService.php');
        $this->assertStringNotContainsString('function moderate(', $moderation);
        $this->assertStringNotContainsString('function moderateContent', $moderation);
        $executor = self::src('app/Services/CustomTask/CustomTaskExecutorService.php');
        $this->assertStringNotContainsString('function recordTaskView', $executor);
        $this->assertStringContainsString('daily_limit_per_user', $executor, 'T22-12 اعمال قیود');
        $this->assertStringContainsString('is_mobile()', $executor, 'T22-12 تشخیص دستگاه');
        $model = self::src('app/Models/CustomTaskSubmissionModel.php');
        foreach (['function submission_getByWorker(', 'function submission_findWithTask', 'function submission_getUnreviewedSubmissions',
                  'function submission_markExpired', 'function submission_markApproved', 'function submission_markRewardPaid',
                  'function submission_isDuplicateImage', 'function submission_checkIdempotency', 'function getAdminSubmissionStats'] as $needle) {
            $this->assertStringNotContainsString($needle, $model);
        }
        $this->assertStringContainsString('function submission_countByWorkerWithTask', $model, 'F3: شمارش صفحه‌بندی');
        $this->assertStringContainsString('function submission_todayCountForTask', $model, 'T22-12: شمارش per-task');
        $adCtrl = self::src('app/Controllers/Admin/AdTaskController.php');
        $this->assertStringNotContainsString('function analytics', $adCtrl);
    }

    // ── T22-17c: یکسان‌سازی catchها ──
    /** @test */
    public function throwable_catch_alignment(): void
    {
        foreach ([
            'app/Services/CustomTask/AdminCustomTaskService.php',
            'app/Services/CustomTask/CustomTaskModerationService.php',
            'app/Services/CustomTask/CustomTaskExecutorService.php',
            'app/Jobs/CustomTask/CronSubmissionsJob.php',
        ] as $rel) {
            $src = self::src($rel);
            $this->assertStringNotContainsString('catch (\Exception', $src, "{$rel} هنوز \\Exception دارد");
        }
    }

    // ── T22-09: هم‌راستایی شمارنده‌ها ──
    /** @test */
    public function force_approve_counter_sync_pinned(): void
    {
        $src = self::src('app/Services/CustomTask/AdminCustomTaskService.php');
        $this->assertStringContainsString('decrementAdSlots', $src);
        $this->assertStringContainsString("in_array((string)\$taskFresh->status, ['rejected', 'completed'], true)", $src);
        $moderation = self::src('app/Services/CustomTask/CustomTaskModerationService.php');
        $this->assertStringContainsString("in_array((string)\$task->status, ['rejected', 'completed'], true)", $moderation);
    }
}
