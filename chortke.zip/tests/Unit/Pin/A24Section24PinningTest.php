<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ بچ A24 — پین یافته‌های §۲۴ (ضمیمهٔ Module24) روی درخت جاری.
 *
 * A24-01: نرمال‌سازی اثر انگشت ویدیو از منبع یگانه (canonicalVideoKey)
 * A24-02: نوشتن corpus فقط پس از موفقیت ثبت/پذیرش (نه در بازرسی)
 * A24-03: شناسهٔ ردیف موجود در saveFingerprint + \Throwable
 * A24-04+T24-01: بازسازی url_hash در ویرایش + یکتایی نرمال‌شده + هشدار کامل
 * A24-05: پیام خطای edit بدون HTML خام (esc تک‌تک، بعد join)
 * A24-06: JS خارجی + requireAuth در update()
 * T24-09: scheme قبلاً در هستهٔ اعتبارسنج محدود شده (FIX-R19-A8-1) — پین مستند
 */
final class A24Section24PinningTest extends TestCase
{
    private const ROOT = __DIR__ . '/../../..';

    /** @return array{0: string, 1: string} */
    private function read(string $relative): array
    {
        $path = self::ROOT . '/' . $relative;
        $this->assertFileExists($path, "فایل مورد انتظار یافت نشد: {$relative}");
        return [$path, (string)file_get_contents($path)];
    }

    // ── A24-01 ────────────────────────────────────────────────

    public function test_a24_01_service_uses_canonical_key_single_source_of_truth(): void
    {
        [, $src] = $this->read('app/Services/AntiFraud/VideoFingerprintService.php');

        // منبع یگانهٔ نرمال‌سازی
        $this->assertStringContainsString('ContentSubmission::canonicalVideoKey(', $src);
        $this->assertStringContainsString('ContentSubmission::hashVideoUrl(', $src);

        // نرمال‌ساز جداگانهٔ ضعیف حذف شد
        $this->assertStringNotContainsString('private function normalizeUrl(', $src);

        // ادعای نادرست سرآیند (Frame/Audio) حذف شد — نام‌گذاری صادقانه URL-hash
        // (اشارهٔ توضیحی داک‌بلاک به «هرگز پیاده نشد» مجاز است؛ فهرست قابلیت نیست)
        $this->assertStringNotContainsString(' * - Frame Hashing', $src);
        $this->assertStringNotContainsString(' * - Audio Fingerprinting', $src);
        $this->assertStringContainsString('Video Fingerprinting Service (URL-hash)', $src);
    }

    // ── A24-02 ────────────────────────────────────────────────

    public function test_a24_02_check_duplicate_and_inspect_are_read_only(): void
    {
        [, $src] = $this->read('app/Services/AntiFraud/VideoFingerprintService.php');

        // checkDuplicate دیگر saveFingerprint نمی‌زند
        $checkStart = (int)strpos($src, 'public function checkDuplicate');
        $checkEnd = (int)strpos($src, 'public function recordFingerprint');
        $this->assertGreaterThan(0, $checkStart);
        $this->assertGreaterThan($checkStart, $checkEnd);
        $checkBody = substr($src, $checkStart, $checkEnd - $checkStart);
        $this->assertStringNotContainsString('saveFingerprint(', $checkBody, 'checkDuplicate باید فقط بخواند');

        // ثبت صریح عمومی برای فراخوان‌ها پس از موفقیت
        $this->assertStringContainsString('public function recordFingerprint(', $src);
    }

    public function test_a24_02_content_service_records_fingerprint_after_success_only(): void
    {
        [, $src] = $this->read('app/Services/ContentService.php');

        // فراخوان ثبت پس از موفقیت + گارد سرویس
        $this->assertStringContainsString('$this->videoFingerprintService->recordFingerprint(', $src);

        // submitContent: ثبت پس از خروج موفق تراکنش (بعد از $submissionId = $result)
        $submitPos = (int)strpos($src, 'public function submitContent');
        $updatePos = (int)strpos($src, 'public function updateSubmission');
        $recordPos = (int)strpos($src, '$this->recordVideoFingerprint($videoUrl, $platform);');
        $this->assertGreaterThan(0, $recordPos);
        $this->assertGreaterThan($submitPos, $recordPos, 'ثبت اثر انگشت باید داخل چرخهٔ submitContent باشد');
        $this->assertGreaterThan($recordPos, $updatePos, 'فراخوان ثبت باید قبل از تعریف updateSubmission باشد (بدنهٔ submitContent)');

        // updateSubmission: فقط وقتی (platform, url) عوض شد (مستثنا کردن مالک)
        $this->assertStringContainsString('if ($isNewVideoForOwner) {', $src);
        $this->assertStringContainsString('$isNewVideoForOwner = (', $src);

        // بازرسیِ اعتبارسنجی فقط برای لینک جدید
        $this->assertStringContainsString('private function validateVideoUrl(string $url, string $platform, bool $inspectForAntiFraud = true): bool', $src);
    }

    public function test_a24_02_submit_proof_job_feeds_corpus_only_after_cas_acceptance(): void
    {
        [, $src] = $this->read('app/Jobs/CustomTask/SubmitProofJob.php');

        // گیت فقط می‌خواند — اثر انگشت کاندید را برمی‌گرداند تا فراخوان پس از
        // پذیرش تغذیه کند
        $gateStart = (int)strpos($src, 'private function resolveVideoFingerprintGate');
        $this->assertGreaterThan(0, $gateStart);
        $gateEnd = (int)strpos($src, 'private function resolveVideoPlatform');
        $gateBody = substr($src, $gateStart, $gateEnd - $gateStart);
        $this->assertStringNotContainsString('saveFingerprint(', $gateBody, 'گیت نباید corpus بنویسد');
        $this->assertStringContainsString("'fingerprint' => \$fingerprint", $gateBody);

        // تغذیه فقط پس از پذیرش CAS: فراخوانی saveFingerprint باید بعد از
        // بلوک ردِ CAS (rowCount === 0) و بعد از $filePersisted = true باشد
        $casRejectPos = (int)strpos($src, 'این اجرا قبلاً ارسال شده است.');
        $persistedPos = (int)strpos($src, '$filePersisted = true;');
        $feedPos = (int)strpos($src, '$this->videoFingerprint?->saveFingerprint($pendingFingerprint);');
        $this->assertGreaterThan(0, $casRejectPos);
        $this->assertGreaterThan($casRejectPos, $persistedPos);
        $this->assertGreaterThan($persistedPos, $feedPos, 'تغذیهٔ corpus باید پس از پذیرش CAS باشد');
    }

    // ── A24-03 ────────────────────────────────────────────────

    public function test_a24_03_save_fingerprint_returns_existing_id_and_throwable_catch(): void
    {
        [, $src] = $this->read('app/Services/AntiFraud/VideoFingerprintService.php');

        // شناسهٔ ردیف موجود پس از ON DUPLICATE KEY UPDATE
        $this->assertStringContainsString('SELECT id FROM video_fingerprints WHERE combined_hash = ? LIMIT 1', $src);

        // هیچ catch \Exception باقی نمانده — همه \Throwable
        $this->assertSame(0, preg_match_all('/catch\s*\(\\\\Exception/', $src), 'catch باید \Throwable باشد');
        $this->assertGreaterThanOrEqual(5, preg_match_all('/catch\s*\(\\\\Throwable/', $src));
    }

    // ── A24-04 + T24-01 ───────────────────────────────────────

    public function test_a24_04_update_rebuilds_url_hash_and_normalized_uniqueness(): void
    {
        [, $src] = $this->read('app/Services/ContentService.php');

        // یکتایی ویرایش با platform (نرمال‌شده مثل ثبت — نه خام)
        $this->assertStringContainsString('isUrlExists($videoUrl, (int)$submissionId, $platform)', $src);

        // بازسازی هش در CAS آپدیت
        $this->assertStringContainsString(
            "'url_hash'    => ContentSubmission::hashVideoUrl(\$platform, \$videoUrl) ?: null,",
            $src
        );
    }

    public function test_a24_04_edit_view_warning_covers_unpaid_confirmed_revenue(): void
    {
        [, $src] = $this->read('views/user/content/edit.php');

        // هشدار کامل: درآمد تأییدشدهٔ پرداخت‌نشده هم تا تأیید مجدد قابل پرداخت نیست
        $this->assertStringContainsString('پرداخت‌نشده', $src);
        $this->assertStringContainsString('تا تأیید مجدد', $src);
        $this->assertStringContainsString('پرداخت‌شده شما محفوظ می‌مانند', $src);
    }

    public function test_a24_t24_09_scheme_restriction_already_in_core_validator(): void
    {
        // مستندسازی راستی‌آمایی: ادعای T24-09 در درخت فعلی معتبر نیست —
        // rule «url» هسته از FIX-R19-A8-1 scheme را به http/https محدود می‌کند
        [, $src] = $this->read('core/Validator.php');
        $this->assertStringContainsString(
            "strtolower((string)\\parse_url(str_value(\$value), PHP_URL_SCHEME)), ['http', 'https'], true",
            $src
        );

        // و sanitize سرویس محتوا هم scheme را قبل از validateVideoUrl می‌بندد
        [, $content] = $this->read('app/Services/ContentService.php');
        $this->assertStringContainsString("throw new \\InvalidArgumentException('Invalid URL scheme');", $content);
    }

    // ── A24-05 ────────────────────────────────────────────────

    public function test_a24_05_edit_js_builds_messages_without_raw_html(): void
    {
        [, $src] = $this->read('public/assets/js/views/usercontentedit.js');

        // هر جزء جداگانه escape و «بعد» join می‌شود — نه join قبل از esc
        $this->assertStringContainsString('lines.map(esc).join(', $src);
        // الگوی قدیمی (خطاهای خام با <br> چسبانده می‌شد قبل از esc) حذف شده
        $this->assertStringNotContainsString("Object.values(result.errors).join", $src);
        $this->assertStringNotContainsString("+ errs", $src, 'الحاق HTML خام ممنوع');

        // خطاهای اعتبارسنجی به‌صورت فهرست جداگانه جمع می‌شوند (نه رشتهٔ HTML-دار)
        $this->assertStringContainsString('errorParts.push(', $src);
    }

    // ── A24-06 ────────────────────────────────────────────────

    public function test_a24_06_edit_view_has_no_inline_script_and_loads_external_js(): void
    {
        [$path, $src] = $this->read('views/user/content/edit.php');

        // JS از ویو حذف شد — هیچ بلاک <script> inline نمی‌ماند (به‌جز صدای $scripts)
        $this->assertSame(0, (int)preg_match_all('/<script(?![^>]*src=)[^>]*>/i', $src), 'edit.php نباید script inline داشته باشد');

        // بارگذاری فایل خارجی با nonce (الگوی index.php/usercontentcreate.js)
        $this->assertStringContainsString("assets/js/views/usercontentedit.js", $src);
        $this->assertStringContainsString('e(csp_nonce())', $src);

        // فایل خارجی واقعاً وجود دارد و با فرم فعلی هم‌خوان است
        [, $js] = $this->read('public/assets/js/views/usercontentedit.js');
        $this->assertStringContainsString("getElementById('contentEditForm')", $js);
        $this->assertStringContainsString("getElementById('saveBtn')", $js);
        $this->assertStringContainsString("getElementById('title-count')", $js);
        $this->assertStringContainsString("getElementById('desc-count')", $js);
        $this->assertStringContainsString("getElementById('url-hint')", $js);

        // ویو عنصر راهنمای لینک را دارد (id که JS انتظار دارد)
        $this->assertStringContainsString('id="url-hint"', $src);
    }

    public function test_a24_06_update_action_calls_require_auth(): void
    {
        [, $src] = $this->read('app/Controllers/User/ContentController.php');

        // update() باید مثل edit()/store() requireAuth داشته باشد
        $updateStart = (int)strpos($src, 'public function update(): void');
        $this->assertGreaterThan(0, $updateStart);
        $updateEnd = (int)strpos($src, 'public function ', $updateStart + 30);
        $updateBody = substr($src, $updateStart, ($updateEnd ?: strlen($src)) - $updateStart);
        $this->assertStringContainsString('$this->requireAuth();', $updateBody, 'update() باید requireAuth داشته باشد');
    }
}
