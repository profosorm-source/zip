<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCRATE-VOTE-EXEC-01 (۲۰۲۶-۱۱-۱۰ — درخواست/تصمیم کارفرما) — پین‌های
 * ساختاری «رأی‌دهی از داخل خود صفحهٔ اجرای سوشیال» روی درخت زنده.
 *
 * قرینهٔ FIX-SEO3-01 سئو (فرم report/rate در show-execution): فرم امتیاز
 * داخل صفحهٔ اجرا (user/social-tasks/execute.php) فقط برای اجرای approved
 * رندر می‌شود و ثبت آن از همان مسیر گاردشدهٔ SocialTaskService::rateTask
 * می‌گذرد (مالک رد + مجریِ تأییدشده) — گارد API از وب دورزدنی نیست.
 *
 * سبک خانه: بازرسی سورس — رفتارِ runtime در SocialTaskControllerRateExecutionTest
 * (Mockery) و E2E زندهٔ socguard-live-e2e بخش ⑥ پین شده.
 */
final class SocRateExecPinningTest extends TestCase
{
    private const BASE = __DIR__ . '/../../../';

    private function read(string $path): string
    {
        $src = (string)file_get_contents(self::BASE . $path);
        self::assertNotSame('', $src, "فایل یافت نشد: {$path}");
        return $src;
    }

    // ─────────────── کنترلر: قرارداد rateExecution ───────────────

    public function test_controller_rate_execution_flow_pinned(): void
    {
        $src = $this->read('app/Controllers/User/SocialTaskController.php');

        // {id} = شناسهٔ اجرا (هم‌قرارداد /execute و /submit)؛ بار از body
        self::assertStringContainsString("\$stars = int_value(\$body['stars'] ?? 0);", $src);
        // ولیدیشن ۱..۵ قبل از هر کوئری (قرینهٔ SeoController::rate)
        self::assertStringContainsString("if (\$stars < 1 || \$stars > 5)", $src);
        self::assertStringContainsString('امتیاز نامعتبر است', $src);
        // اجرا executor-scoped خوانده می‌شود (getExecutionWithAd: id + executor_id)
        self::assertStringContainsString('getExecutionWithAd($executionId, $userId)', $src);
        self::assertStringContainsString('اجرای تسک یافت نشد', $src);
        // گارد وضعیت: فقط approved (معادل completed سئو)
        self::assertStringContainsString("if ((string)\$execution->status !== 'approved')", $src);
        // تفویض به مسیر گاردشدهٔ سرویس — با ad_id اجرا (نه شناسهٔ اجرا)
        self::assertStringContainsString('rateTask($userId, (int)$execution->ad_id, $stars, $comment)', $src);
        // پاسخ: ۲۰۰/۴۲۲ بسته به نتیجهٔ سرویس
        self::assertStringContainsString("!empty(\$result['success']) ? 200 : 422", $src);
        self::assertStringContainsString('FIX-SOCRATE-VOTE-EXEC-01', $src);
    }

    public function test_controller_show_execute_passes_feedback(): void
    {
        $src = $this->read('app/Controllers/User/SocialTaskController.php');

        // خلاصهٔ رأی مجریان + رأی خودِ کاربر (یک batch — قرارداد FIX-SEO3-01)
        self::assertStringContainsString("getRatingsSummary('social_task', [\$adId])", $src);
        self::assertStringContainsString("getUserRating((int)\$this->userId(), 'social_task', \$adId)", $src);
        self::assertStringContainsString("'feedback' => [", $src);
        self::assertStringContainsString("'my_rating' =>", $src);
        // GET مسیر رأی → هدایت به صفحهٔ اجرا (فرم داخل صفحه است)
        self::assertStringContainsString("redirect(url('/social-tasks/' . (int)\$this->request->param('id') . '/execute'))", $src);
    }

    // ─────────────── ویو: کارت امتیاز فقط برای اجرای approved ───────────────

    public function test_execute_view_renders_rate_card_for_approved_only(): void
    {
        $src = $this->read('views/user/social-tasks/execute.php');

        // فالبک امن (include مستقیم بدون کنترلر هم کرش نکند)
        self::assertStringContainsString('$feedback = $feedback ?? null;', $src);
        // فرم فقط برای اجرای تأییدشده
        self::assertStringContainsString("\$canRate = \$status === 'approved';", $src);
        self::assertStringContainsString('<?php if ($canRate): ?>', $src);
        // کارت + قرارداد JS (data-rate-url/data-csrf)
        self::assertStringContainsString('id="socRateCard"', $src);
        self::assertStringContainsString("data-rate-url=\"<?= e(url('/social-tasks/' . \$executionId . '/rate')) ?>\"", $src);
        // دکمه‌های ستاره ۱..۵ + کامنت اختیاری (قرینهٔ سئو)
        self::assertStringContainsString('soc-star-btn', $src);
        self::assertStringContainsString('id="socRateComment"', $src);
        self::assertStringContainsString('id="socRateBtn" disabled', $src);
        // میانگین رأی مجریان + رأی خود کاربر (نمایش پس از ثبت)
        self::assertStringContainsString('میانگین رأی مجریان', $src);
        self::assertStringContainsString('امتیاز فعلی شما', $src);
        self::assertStringContainsString('id="socMyRatingText"', $src);
        self::assertStringContainsString('FIX-SOCRATE-VOTE-EXEC-01', $src);
        // رگرسیون: فرم ارسال اجرا دست‌نخورده
        self::assertStringContainsString('id="socialTaskSubmitForm"', $src);
    }

    public function test_rate_js_wired_to_card_contract(): void
    {
        $src = $this->read('public/assets/js/views/usersocialtasksrate.js');

        // بدون کارت بی‌اثر (صفحهٔ در جریان)
        self::assertStringContainsString("document.getElementById('socRateCard')", $src);
        self::assertStringContainsString('if (!card) return;', $src);
        // payload سئو-قرارداد: stars + comment + CSRF
        self::assertStringContainsString('_csrf_token: csrf, stars: selectedStars, comment', $src);
        self::assertStringContainsString('X-CSRF-Token', $src);
        // میانگین محلی تازه نمی‌شود — منبع حقیقت رندر بعدی سرور است
        self::assertStringContainsString('socMyRatingText', $src);
        self::assertStringContainsString('FIX-SOCRATE-VOTE-EXEC-01', $src);
    }

    public function test_history_view_links_back_to_execution_page(): void
    {
        $src = $this->read('views/user/social-tasks/history.php');

        // مسیر بازگشت به اجرا (قرینهٔ دکمهٔ «مشاهده» تاریخچهٔ سئو) — بدون آن،
        // فرم رأیِ داخل صفحهٔ اجرا برای اجراهای قدیمی غیرقابل‌دسترس بود.
        self::assertStringContainsString("url('/social-tasks/' . (int)(\$row->id ?? 0) . '/execute')", $src);
        self::assertStringContainsString('FIX-SOCRATE-VOTE-EXEC-01', $src);
    }

    // ─────────────── رگرسیون‌های قرینه‌ها ───────────────

    public function test_seo_rate_and_social_service_guards_untouched(): void
    {
        // سئو: مرجع قرینه‌سازی دست‌نخورده
        $seo = $this->read('app/Controllers/User/SeoController.php');
        self::assertStringContainsString("if ((string)\$execution->status !== 'completed')", $seo);
        self::assertStringContainsString('$this->seoService->rateTask($userId, (int)$execution->ad_id, $stars, $comment)', $seo);

        // سوشیال: گاردهای سرویس (منبع حقیقت رأی) سر جایش — این بچ سرویس را لمس نکرد
        $svc = $this->read('app/Services/SocialTask/SocialTaskService.php');
        self::assertStringContainsString('if ((int)($ad->user_id ?? 0) === $raterId)', $svc);
        self::assertStringContainsString("WHERE ad_id = ? AND executor_id = ? AND status = 'approved'", $svc);

        // روت‌ها: GET/POST همان مسیرهای قبلی — روت جدیدی اضافه نشد
        $routes = $this->read('routes/user.php');
        self::assertStringContainsString("[SocialTaskController::class, 'rateExecutionForm']", $routes);
        self::assertStringContainsString("[SocialTaskController::class, 'rateExecution']", $routes);
    }

    public function test_live_e2e_pins_vote_from_execution_contract(): void
    {
        $e2e = $this->read('tools/socguard-live-e2e.php');

        // بخش ⑥: فرم + گاردها + به‌روزرسانی همان ردیف
        self::assertStringContainsString('FIX-SOCRATE-VOTE-EXEC-01', $e2e);
        self::assertStringContainsString('⑥ وب: صفحهٔ اجرای تأییدشده فرم امتیاز دارد (قرینهٔ سئو)', $e2e);
        self::assertStringContainsString('⑥ وب: صفحهٔ اجرای در جریان فرم امتیاز ندارد', $e2e);
        self::assertStringContainsString('⑥ وب: ثبت رأی ۴ ستاره از صفحهٔ اجرا → ۲۰۰ + ردیف interactions + کامنت', $e2e);
        self::assertStringContainsString('⑥ وب: رأی دوباره = به‌روزرسانی همان ردیف (نه رأی دوم)', $e2e);
        self::assertStringContainsString('⑥ وب: رأی به اجرای در جریان → ۴۲۲ «پس از تأیید»', $e2e);
        self::assertStringContainsString('⑥ وب: رأی به اجرای دیگری (غیر مالک اجرا) → ۴۰۴ «یافت نشد»', $e2e);
        // چک منسوخِ «وب غیرفعال» حذف شد
        self::assertStringNotContainsString('وبِ سوشیال همچنان غیرفعال', $e2e);
    }
}
