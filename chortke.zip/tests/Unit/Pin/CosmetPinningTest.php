<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🧹 FIX-COSMET — پین‌های بچ ۳ (برچسب/آرایشی/پاک‌سازی + X1..X6): ۳۵ یافتهٔ
 * باقی‌ماندهٔ M22-RA روی درخت eb8e0de (پایهٔ a7f1bb7+BEHAV1+MOBCTR) به‌علاوهٔ
 * ترمیم رجیستری FIXES-MANIFEST. هر یافته به‌صورت قراردادِ کد پین می‌شود
 * (رشته/الگو در سورس واقعی). سنجشِ اجرایی روی DB/HTTP واقعی:
 * tools/cosmet-live-test.php.
 *
 * گروه‌ها: L (برچسب/ویو) · P (صفحه‌بندی/UX وب) · B (باک‌اند کوچک) ·
 * C (کرون/امنیت) · D (پاک‌سازی مرده) · X (legacy/analytics/docs/tests) ·
 * R (ترمیم رجیستری).
 */
final class CosmetPinningTest extends TestCase
{
    /** @var array<string, string> کش سورس فایل‌ها */
    private static array $srcCache = [];

    private static function src(string $rel): string
    {
        if (!isset(self::$srcCache[$rel])) {
            $p = dirname(__DIR__, 3) . '/' . $rel;
            self::assertFileExists($p, "فایل مورد انتظار وجود ندارد: {$rel}");
            self::$srcCache[$rel] = (string)file_get_contents($p);
        }
        return self::$srcCache[$rel];
    }

    private static function fileExistsAt(string $rel): bool
    {
        return is_file(dirname(__DIR__, 3) . '/' . $rel);
    }

    // ═══════════════ گروه L — برچسب/ویو ═══════════════

    public function test_l_01_dispute_decision_labels_include_split_no_dead_keys(): void
    {
        $src = self::src('views/admin/custom-tasks/disputes.php');
        $this->assertStringContainsString("'split'=>'تسویه توافقی (تقسیم پاداش)'", $src, 'A2-N6: برچسب split لازم است');
        $this->assertStringNotContainsString("'executor'=>'حق با مجری'", $src, 'A2-N6: کلید مردهٔ executor حذف شود');
    }

    public function test_l_02_resolved_split_status_label_everywhere(): void
    {
        $this->assertStringContainsString("'resolved_split' => 'تسویه اختلاف (تقسیم)'", self::src('app/Models/Ads.php'), 'A2-N7: Ads::submissionStatusLabels');
        $mySub = self::src('views/user/custom-tasks/executor/my-submissions.php');
        $this->assertStringContainsString("'resolved_split'=>'تسویه اختلاف (تقسیم)'", $mySub, 'A2-N7: نقشهٔ $sl ویوی مجری');
        $this->assertStringContainsString("'resolved_split'=>'info'", $mySub, 'A2-N7: نقشهٔ $sc ویوی مجری');
    }

    public function test_l_03_custom_task_types_single_source_from_adapter(): void
    {
        $adapter = self::src('app/Adapters/CustomTaskAdapter.php');
        $this->assertStringContainsString('public static function allowedTaskTypes(): array', $adapter, 'A2-N8: accessor عمومی آداپتر');
        $helper = self::src('helpers/label_helpers.php');
        $this->assertStringContainsString('CustomTaskAdapter::allowedTaskTypes()', $helper, 'A2-N8: هلپر از آداپتر می‌سازد');
        // فقط بدنهٔ custom_task_types (نه سایر هلپرها مثل برچسب‌های سئو)
        $pos = (int)strpos($helper, 'function custom_task_types');
        $body = substr($helper, $pos, 1800);
        foreach (['signup', 'survey', 'content', 'seo', 'social'] as $dead) {
            $this->assertStringNotContainsString("'{$dead}'", $body, "A2-N8: کلید مردهٔ {$dead} در custom_task_types نباشد");
        }
        $view = self::src('views/admin/custom-tasks/index.php');
        $this->assertStringContainsString('$adapterTaskTypes = custom_task_types();', $view, 'A2-N8: ویوی ادمین تک‌منبع شد');
        $this->assertStringNotContainsString("'register' => 'ثبت‌نام',\n", $view, 'A2-N8: فهرست هاردکد موازی حذف شود');
    }

    public function test_l_04_admin_index_empty_state_points_to_real_creation_path(): void
    {
        $src = self::src('views/admin/custom-tasks/index.php');
        $this->assertStringNotContainsString('دکمهٔ «جدید» در بالای همین صفحه', $src, 'A2-N9: ارجاع به دکمهٔ ناموجود حذف شود');
        $this->assertStringContainsString('ویزارد «ساخت تبلیغ»', $src, 'A2-N9: مسیر واقعی ساخت اشاره شود');
    }

    public function test_l_05_jalali_dates_in_dispute_views(): void
    {
        $this->assertStringContainsString("e(to_jalali((string)(\$msg->created_at ?? ''), 'Y/m/d H:i'))", self::src('views/admin/custom-tasks/dispute-detail.php'), 'A2-N10: ادمین تسک سفارشی');
        $this->assertStringContainsString("e(to_jalali((string)(\$m->created_at ?? ''), 'Y/m/d H:i'))", self::src('views/user/influencer/dispute-panel.php'), 'A2-N10: پنل کاربر اینفلوئنسر');
        $this->assertStringContainsString("\$h(to_jalali((string)(\$m->created_at ?? ''), 'Y/m/d H:i'))", self::src('views/admin/influencer/dispute-detail.php'), 'A2-N10: داوری ادمین اینفلوئنسر');
        $this->assertStringNotContainsString('substr((string)$m->created_at', self::src('views/admin/influencer/dispute-detail.php'), 'A2-N10: substr خام حذف شود');
    }

    public function test_l_06_dispute_amounts_have_currency_label(): void
    {
        $this->assertStringContainsString('money_label($order->price ?? 0, (string)($order->currency ?? \'irt\'))', self::src('views/user/influencer/dispute-panel.php'), 'A2-N11: مبلغ پنل کاربر');
        $admin = self::src('views/admin/influencer/dispute-detail.php');
        $this->assertStringContainsString('$money($order->price ?? 0, (string)($order->currency ?? \'irt\'))', $admin, 'A2-N11: مبلغ سفارش ادمین');
        $this->assertStringContainsString('$money($order->influencer_earning ?? 0, (string)($order->currency ?? \'irt\'))', $admin, 'A2-N11: سهم اینفلوئنسر ادمین');
    }

    public function test_l_07_feed_pagination_href_escaped(): void
    {
        $this->assertStringContainsString('e(http_build_query($qParams))', self::src('views/user/tasks/feed.php'), 'A2-N13: escape خروجی کوئری در href');
    }

    public function test_l_08_proof_deadline_unit_honest(): void
    {
        $src = self::src('views/user/custom-tasks/proof.php');
        $this->assertStringContainsString("'تاریخ مقطع'", $src, 'A2-N14: واحد صادقانه');
        $this->assertStringNotContainsString('>زمان باقی‌مانده<', $src, 'A2-N14: برچسب گمراه‌کننده حذف شود');
    }

    public function test_l_09_persian_status_labels_user_views(): void
    {
        $show = self::src('views/user/custom-tasks/show.php');
        $this->assertStringContainsString('AdsStatus::labelsMap()', $show, 'A2-N15: show.php برچسب از enum');
        $this->assertStringNotContainsString('e($task->status ?? \'active\')', $show, 'A2-N15: کلید خام حذف شود');
        $proof = self::src('views/user/custom-tasks/proof.php');
        $this->assertStringContainsString("'in_progress'=>'در حال انجام'", $proof, 'A2-N15: proof.php نقشهٔ فارسی');
    }

    public function test_l_10_idempotency_key_removed_from_proof_form(): void
    {
        $src = self::src('views/user/custom-tasks/proof.php');
        // فقط کد (کامنت‌های توضیحی فیکس می‌توانند کلمه را ذکر کنند)
        $code = preg_replace('/\/\*.*?\*\//s', '', $src) ?? $src;
        $this->assertStringNotContainsString('name="idempotency_key"', $code, 'A2-N5: فیلد مرده از فرم حذف شود');
        $this->assertStringNotContainsString('bin2hex', $code, 'A2-N5: تولید کلید بی‌فایده حذف شود');
        $this->assertStringNotContainsString('$idempotencyKey', $code, 'A2-N5: متغیر مرده حذف شود');
    }

    public function test_l_11_notification_urls_use_real_routes(): void
    {
        $job = self::src('app/Jobs/CustomTask/SubmitProofJob.php');
        $this->assertStringContainsString("'/custom-tasks/submissions/' . \$submissionId . '/proof'", $job, 'A1-N5: روت واقعی proofForm');
        $this->assertStringNotContainsString("'/user/custom-tasks/submissions/'", $job, 'A1-N5: روت غلط حذف شود');
        $mod = self::src('app/Services/CustomTask/CustomTaskModerationService.php');
        $this->assertStringContainsString("'url' => \"/custom-tasks/my-submissions\"", $mod, 'A1-N5: روت واقعی لیست اجراها');
        // فقط مقداردهی واقعی (کامنت توضیحی فیکس مسیر قدیمی را نقل می‌کند)
        $this->assertStringNotContainsString("'url' => \"/user/custom-tasks/my-submissions/{\$submission->id}\"", $mod, 'A1-N5: مقداردهی روت غلط حذف شود');
    }

    public function test_l_12_web_reply_role_computed_not_auto(): void
    {
        $src = self::src('app/Controllers/User/CustomTaskController.php');
        $this->assertStringNotContainsString("sendMessage(\$disputeId, \$userId, 'auto'", $src, 'A3-N6: role خام auto حذف شود');
        $this->assertStringContainsString("submission_findById((int)\$disputeRow->ref_id)", $src, 'A3-N6: محاسبه از worker_id واقعی');
        $this->assertStringContainsString("\$role = 'worker';", $src, 'A3-N6: واژگان worker');
    }

    // ═══════════════ گروه P — صفحه‌بندی/UX وب ═══════════════

    public function test_p_13_report_responds_web_and_json(): void
    {
        $src = self::src('app/Controllers/User/CustomTaskController.php');
        $pos = (int)strpos($src, 'function report');
        $chunk = substr($src, $pos, 2400);
        $this->assertStringContainsString('$wantsJson = $this->wantsJson();', $chunk, 'A2-N1: تشخیص نوع درخواست');
        $this->assertStringContainsString("setFlash(!empty(\$result['success']) ? 'success' : 'error'", $chunk, 'A2-N1: flash برای فرم وب');
        $this->assertStringContainsString("redirect(url('/custom-tasks/' . \$taskId))", $chunk, 'A2-N1: ریدایرکت برای فرم وب');
    }

    public function test_p_14_admin_submissions_pagination(): void
    {
        $svc = self::src('app/Services/CustomTask/AdminCustomTaskService.php');
        $this->assertStringContainsString('submission_countByTask($taskId)', $svc, 'A2-N3: شمارش واقعی');
        $this->assertStringContainsString("'totalPages' => max(1, (int)ceil(\$totalSubmissions / \$perPage))", $svc, 'A2-N3: totalPages');
        $model = self::src('app/Models/CustomTaskSubmissionModel.php');
        $this->assertStringContainsString('function submission_countByTask', $model, 'A2-N3: متد شمارش مدل');
        $ctrl = self::src('app/Controllers/Admin/AdTaskController.php');
        $this->assertStringContainsString("getTaskDetailsForAdmin(\$taskId, \$page, 30)", $ctrl, 'A2-N3: صفحه از کنترلر');
        $view = self::src('views/admin/custom-tasks/show.php');
        $this->assertStringContainsString("totalSubmissions ?? count(\$submissions", $view, 'A2-N3: سرستون کل واقعی');
        $this->assertStringContainsString("include view_path('partials.pagination')", $view, 'A2-N3: pager در ویو');
    }

    public function test_p_15_user_disputes_pagination(): void
    {
        $src = self::src('app/Controllers/User/CustomTaskController.php');
        $this->assertStringContainsString('countCustomTaskDisputesByUser($userId)', $src, 'A2-N12: شمارش');
        $this->assertStringContainsString('getCustomTaskDisputesByUser($userId, $perPage, $offset)', $src, 'A2-N12: لیست صفحه‌بندی‌شده');
        $this->assertStringNotContainsString('getCustomTaskDisputesByUser($userId);', $src, 'A2-N12: فراخوان سقف‌دار پیش‌فرض حذف شود');
        $q = self::src('app/Services/Dispute/DisputeQueryService.php');
        $this->assertStringContainsString('function countCustomTaskDisputesByUser', $q, 'A2-N12: متد شمارش در کوئری‌سرویس');
        $this->assertStringContainsString('function countCustomTaskDisputesByUser', self::src('app/Services/Shared/DisputeService.php'), 'A2-N12: delegate سرویس');
        $this->assertStringContainsString("include view_path('partials.pagination')", self::src('views/user/custom-tasks/executor/disputes.php'), 'A2-N12: pager در ویو');
    }

    // ═══════════════ گروه B — باک‌اند کوچک ═══════════════

    public function test_b_16_auto_approve_promise_per_task_and_disabled_semantics(): void
    {
        $job = self::src('app/Jobs/CustomTask/SubmitProofJob.php');
        $this->assertStringContainsString('is_numeric($task->auto_approve_hours ?? null)', $job, 'A1-N6: مقدار per-task');
        $this->assertStringContainsString('$autoApproveInfo = null;', $job, 'A1-N6/A1-N7: وعده حذف‌پذیر (غیرفعال)');
        $this->assertStringContainsString('if ($taskAutoApproveHours > 0)', $job, 'A1-N6: فقط مقدار مثبت وعده می‌دهد');
        $adapter = self::src('app/Adapters/CustomTaskAdapter.php');
        $this->assertStringContainsString('$autoApproveHours > 0 ? $autoApproveHours : null', $adapter, 'A1-N7: آداپتر NULL برای ≤۰');
        // 🛡️ FIX-V22-03b: گارد «۰ = غیرفعال، نه تأیید آنی» از کرون به SQL منتقل شد
        // (کرون دیگر با return 0 کل sweep را نمی‌کشد — وعدهٔ per-task T22-16 حفظ
        // شود؛ ردیف‌های بی‌ساعت با تنظیم سراسری ≤۰ در خودِ کوئری حذف می‌شوند).
        $model = self::src('app/Models/CustomTaskSubmissionModel.php');
        $this->assertStringContainsString('AND COALESCE(ct.auto_approve_hours, ?) > 0', $model, 'A1-N7: گارد غیرفعال‌بودن فالبک سراسری در SQL');
    }

    public function test_b_17_reward_paid_includes_resolved_split_paid_amount(): void
    {
        $src = self::src('app/Models/CustomTaskAnalyticsModel.php');
        $this->assertStringContainsString("WHERE s.status IN ('approved', 'resolved_split')", $src, 'A1-N13: پوشش resolved_split');
        $this->assertStringContainsString('COALESCE(s.paid_amount, 0)', $src, 'A1-N13: مبلغ واقعی تسویه توافقی');
        $this->assertStringNotContainsString("WHERE s.status = 'approved' {\$approvedWhere}", $src, 'A1-N13: شاخهٔ فقط-approved حذف شود');
    }

    public function test_b_18_file_proof_contract_explicit(): void
    {
        $src = self::src('app/Services/CustomTask/CustomTaskProofSchema.php');
        $this->assertStringContainsString('تصویر JPG/PNG/WEBP یا PDF تا ۵ مگابایت', $src, 'A1-N14: قالب‌های پذیرفته‌شده صریح');
    }

    public function test_b_19_formatOrder_proof_screenshot_is_guarded_url(): void
    {
        $src = self::src('app/Controllers/Api/InfluencerController.php');
        $pos = (int)strpos($src, 'function formatOrder');
        $chunk = substr($src, $pos, 2600);
        $this->assertStringContainsString("url('/file/view/inf-proof/' . rawurlencode(basename(", $chunk, 'A3-N5: URL گارددار به‌جای مسیر خام');
        $this->assertStringNotContainsString("'proof_screenshot'        => \$o->proof_screenshot ?? null,", $chunk, 'A3-N5: نشت مسیر خام حذف شود');
    }

    public function test_b_20_analytics_period_whitelisted_and_throwable(): void
    {
        $src = self::src('app/Controllers/Admin/AdminAnalyticsController.php');
        $this->assertStringNotContainsString('catch (\Exception $e)', $src, 'A3-N11: همه catchها Throwable');
        // همهٔ متدهای خوانندهٔ period باید whitelist داشته باشند؛ شمارش فراخوانی
        // request->str('period') برابر شمارش whitelistهاست (exportReport از post می‌خواند).
        $reads = substr_count($src, "\$period = \$this->request->str('period', 'month');");
        $whitelists = substr_count($src, "in_array(\$period, ['day', 'week', 'month', 'year'], true) ? \$period : 'month'");
        $this->assertSame($reads, $whitelists, 'A3-N11: هر متد reader period باید whitelist داشته باشد');
    }

    // ═══════════════ گروه C — کرون/امنیت ═══════════════

    public function test_c_21_vitrine_escrow_job_scheduled_in_kernel(): void
    {
        $kernel = self::src('app/Console/Kernel.php');
        $this->assertStringContainsString('ProcessExpiredVitrineEscrowsJob::class', $kernel, 'A3-N4: جاب در زمان‌بند');
        $this->assertStringContainsString("'vitrine_escrow_expiry:' . date('Ymd-H')", $kernel, 'A3-N4: کلید dedup ساعتی');
        $this->assertStringContainsString("}, 'vitrine_escrow_expiry');", $kernel, 'A3-N4: نام زمان‌بند');
    }

    public function test_c_22_sentry_monitor_cli_guard(): void
    {
        $src = self::src('storage/cron/sentry-monitor.php');
        $this->assertStringContainsString("php_sapi_name() !== 'cli'", $src, 'A3-N8: گارد CLI');
        $pos = (int)strpos($src, "php_sapi_name() !== 'cli'");
        $bootstrap = (int)strpos($src, "require_once __DIR__ . '/../../bootstrap/app.php'");
        $this->assertGreaterThan(0, $bootstrap);
        $this->assertLessThan($bootstrap, $pos, 'A3-N8: گارد قبل از bootstrap');
    }

    public function test_c_23_backup_credentials_not_in_argv(): void
    {
        $src = self::src('storage/cron/backup_database.php');
        $this->assertStringNotContainsString('"--password={$dbPass}"', $src, 'A3-N9: رمز در argv ممنوع');
        $this->assertStringContainsString('--defaults-extra-file={$defaultsFile}', $src, 'A3-N9: فایل defaults با مجوز 0600');
        $this->assertStringContainsString('chmod($defaultsFile, 0600);', $src, 'A3-N9: مجوز فایل');
        $this->assertStringContainsString('@unlink($defaultsFile);', $src, 'A3-N9: پاک‌سازی در هر حال');
    }

    public function test_c_24_email_queue_batch_from_feature_config(): void
    {
        $src = self::src('storage/cron/email_queue.php');
        $this->assertStringContainsString("feature_config('cron_email_batch_size', 'rollout_percentage', 20)", $src, 'A3-N10: batch از همان منبع Kernel');
        $this->assertStringNotContainsString('processQueue(10)', $src, 'A3-N10: batch سخت‌کد حذف شود');
        $this->assertStringContainsString("php_sapi_name() !== 'cli'", $src, 'A3-N10: پین M22-CLOSE (گارد CLI) حفظ شد');
    }

    // ═══════════════ گروه D — پاک‌سازی مرده ═══════════════

    public function test_d_25_dead_methods_removed_live_methods_pinned(): void
    {
        $src = self::src('app/Models/InteractionModel.php');
        foreach (['isFavorite', 'getUserFavorites', 'countUserFavorites', 'updateTaskReport', 'getTaskReportCount'] as $dead) {
            $this->assertStringNotContainsString("function {$dead}(", $src, "A1-N9: متد مردهٔ {$dead} حذف شود");
        }
        // A1-N10: متدهای زنده پین می‌شوند تا حذف تصادفی رخ ندهد
        $this->assertStringContainsString('function createTaskReport(', $src, 'A1-N10: createTaskReport زنده است');
        $this->assertStringContainsString('function hasPendingTaskReport(', $src, 'A1-N10: hasPendingTaskReport زنده است');
        $this->assertStringNotContainsString('هر شش متد', $src, 'A1-N10: docblock نادرست «شش متد صفر-فراخوان» حذف شود');
        $executor = self::src('app/Services/CustomTask/CustomTaskExecutorService.php');
        $this->assertStringContainsString('hasPendingTaskReport(', $executor, 'A1-N10: مصرف‌کنندهٔ زندهٔ گزارش تخلف');
    }

    public function test_d_26_legacy_cancel_and_proof_types_removed(): void
    {
        $ads = self::src('app/Models/Ads.php');
        $this->assertStringNotContainsString('function cancelUserCustomTasks(', $ads, 'A1-N11: متد no-op روی legacy حذف شود');
        $this->assertStringNotContainsString('function proofTypes(', $ads, 'A1-N12: متد صفر-فراخوان حذف شود');
        $svc = self::src('app/Services/CustomTask/AdminCustomTaskService.php');
        $this->assertStringNotContainsString('cancelUserCustomTasks(', $svc, 'A1-N11: فراخوان مرده حذف شود');
    }

    // ═══════════════ گروه X — legacy/analytics/docs/tests ═══════════════

    public function test_x_27_kpi_stats_from_real_tables(): void
    {
        $src = self::src('app/Models/KpiStatistics.php');
        $this->assertStringNotContainsString('FROM custom_tasks"', $src, 'X1: جدول legacy حذف شود');
        $this->assertStringContainsString('FROM custom_task_submissions', $src, 'X1: منبع واقعی');
        $this->assertStringContainsString("SUM(CASE WHEN status IN ('approved','resolved_split') THEN 1 ELSE 0 END)", $src, 'X1: نرخ تکمیل از نهایی‌ها');
        $this->assertStringContainsString('COALESCE(approved_at, reviewed_at)', $src, 'X1: مبنای زمان واقعی');
    }

    public function test_x_28_aggregate_tasks_completed_real_source(): void
    {
        $src = self::src('app/Jobs/AggregateAnalyticsJob.php');
        $this->assertStringNotContainsString('FROM custom_tasks WHERE', $src, 'X2: شمارش legacy حذف شود');
        $this->assertStringContainsString("FROM custom_task_submissions WHERE status IN ('approved','resolved_split')", $src, 'X2: منبع واقعی');
    }

    public function test_x_29_export_tasks_from_ads(): void
    {
        $src = self::src('app/Models/ExportData.php');
        $pos = (int)strpos($src, 'function exportTasks');
        $chunk = substr($src, $pos, 2200);
        $this->assertStringContainsString("WHERE type = 'custom_task' AND deleted_at IS NULL", $chunk, 'X3: منبع واقعی ads');
        $this->assertStringContainsString('user_id AS creator_id', $chunk, 'X3: حفظ قرارداد کلید خروجی');
        $this->assertStringNotContainsString('FROM custom_tasks', $chunk, 'X3: جدول legacy حذف شود');
    }

    public function test_x_30_ratings_counts_use_real_enum(): void
    {
        $src = self::src('app/Services/Analytics/AnalyticsService.php');
        $this->assertStringNotContainsString("'pending','review_pending','pending_review'", $src, 'X4: وضعیت‌های شبح حذف شوند');
        $this->assertStringNotContainsString("'approved','active'", $src, 'X4: active شبح حذف شود');
        $this->assertStringContainsString("safeCount('ratings', \"status = 'pending'\")", $src, 'X4: enum واقعی pending');
        $this->assertStringContainsString("safeCount('ratings', \"status = 'approved'\")", $src, 'X4: enum واقعی approved');
    }

    public function test_x_31_parallel_paths_doc_dated_correction(): void
    {
        $src = self::src('docs/VERIFICATION-PARALLEL-PATHS-FA.md');
        $this->assertStringContainsString('FIX-COSMET-30', $src, 'X5: یادداشت اصلاحی');
        $this->assertStringContainsString('PayRewardJob` در بچ M22-CLOSE', $src, 'X5: ابهام زدایی حذف PayRewardJob');
    }

    public function test_x_32_model_race_test_moved_to_tools(): void
    {
        $this->assertFalse(self::fileExistsAt('tests/model_race_test.php'), 'X6: اسکریپت مستقل از tests/ ریشه برود');
        $this->assertTrue(self::fileExistsAt('tools/model_race_test.php'), 'X6: مکان استاندارد اسکریپت‌های QA');
        $src = self::src('tools/model_race_test.php');
        $this->assertStringContainsString("PHP_SAPI !== 'cli'", $src, 'X6: گارد CLI');
        $this->assertStringContainsString('FIX-COSMET-31', $src, 'X6: مستندسازی جابه‌جایی');
    }

    // ═══════════════ R — ترمیم رجیستری ═══════════════

    public function test_r_33_manifest_has_all_three_batch_entries(): void
    {
        $src = self::src('FIXES-MANIFEST.txt');
        $this->assertStringContainsString('chortke-fixes-behav1-2026-11-07', $src, 'R: مدخل BEHAV1');
        $this->assertStringContainsString('chortke-fixes-mobctr-2026-11-07', $src, 'R: مدخل MOBCTR');
        $this->assertStringContainsString('FIX-COSMET-32', $src, 'R: یادداشت ترمیم رجیستری');
    }
}
