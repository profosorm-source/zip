<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M22-MED — پین ویوها/JS/CSS بچ FIX-M22-MED:
 *  ۱) رندر مبلغ به‌تفکیک ارز (money_label) در همهٔ فایل‌های اصلاح‌شدهٔ پولی؛
 *     هیچ «تومان» هاردکدی کنار number_format روی مقادیر ارزدار نیست.
 *  ۲) $scripts (customtasks.js) در admin/custom-tasks/index.php.
 *  ۳) انشعاب لینک جزئیات اختلاف بر اساس ref_type + چهار گزینهٔ فیلتر اینفلوئنسر.
 *  ۴) to_jalali در چهار ویوی کاربر (my-submissions، executor/disputes،
 *     executor/dispute-detail، proof).
 *  ۵) e() روی task_id + عنوان درست «اجراهای تسک سفارشی من».
 *  ۶) خواندن deadline_hours به‌جای ستون ناموجود deadline.
 *  ۷) .icon-xl در userearn.css حفظ شده؛ فایل‌های مرده حذف شده‌اند.
 *  ۸) دیالوگ داوری ویترین فقط مقادیر canonical می‌فرستد (executor/advertiser/split).
 *
 * @group architecture
 */
final class M22MedViewsPinningTest extends TestCase
{
    private static function repoPath(string $rel): string
    {
        return dirname(__DIR__, 3) . '/' . $rel;
    }

    private static function src(string $rel): string
    {
        $src = file_get_contents(self::repoPath($rel));
        self::assertIsString($src);
        return $src;
    }

    /** @test */
    public function money_label_helper_exists_with_currency_decimals(): void
    {
        $src = self::src('helpers/functions.php');
        $this->assertStringContainsString('function money_label(', $src);
        $this->assertStringContainsString("currency_label(\$currency)", $src);
        // اعشار تتر دوم و اعشار تومان صفر — قلب قرارداد قالب‌بندی
        $this->assertStringContainsString("\$label === 'تتر' ? 2 : 0", $src);
    }

    /** @test */
    public function feed_view_renders_per_currency_and_raw_data_reward(): void
    {
        $src = self::src('views/user/tasks/feed.php');

        // درآمد شخصی دو‌ارزی (قرارداد getExecutorStats) بدون فالبک available_earnings
        $this->assertStringContainsString('total_earned_irt', $src);
        $this->assertStringContainsString('total_earned_usdt', $src);
        $this->assertStringNotContainsString('$userStats->available_earnings', $src);
        $this->assertStringContainsString("money_label(\$totalEarnedIrt, 'irt')", $src);
        $this->assertStringContainsString("money_label(\$totalEarnedUsdt, 'usdt')", $src);

        // data-reward خام + data-currency؛ «تومان» هاردکد داخل اتریبیوت حذف شد
        $this->assertStringContainsString('data-currency=', $src);
        $this->assertStringNotContainsString('data-reward="<?= e(number_format($reward)) ?> تومان"', $src);
        // پاداش کارت از ارز ردیف؛ <small>تومان</small> هاردکد حذف شد
        $this->assertStringContainsString('money_label($reward, $cur, false)', $src);
        $this->assertStringNotContainsString('<small>تومان</small>', $src);

        // پنجرهٔ محدود صفحه‌بندی (اول/آخر/±۲) به‌جای حلقهٔ بی‌سقف ۱..N
        $this->assertStringContainsString('range(max(1, $currentPage - 2)', $src);
        $this->assertStringNotContainsString('for ($i=1; $i <= $totalPages; $i++)', $src);
    }

    /** @test */
    public function user_custom_task_show_uses_helper_and_deadline_hours(): void
    {
        $src = self::src('views/user/custom-tasks/show.php');
        $this->assertStringContainsString('money_label($reward', $src);
        $this->assertStringContainsString('currency_label((string)($task->currency', $src);
        $this->assertStringNotContainsString('fa_number(number_format($reward))', $src);
        // ستون deadline در اسکیما وجود ندارد → deadline_hours
        $this->assertStringContainsString('deadline_hours', $src);
        $this->assertStringNotContainsString('substr($task->deadline, 0, 10)', $src);
        $this->assertStringNotContainsString('!empty($task->deadline)', $src);
    }

    /** @test */
    public function proof_view_uses_helper_jalali_and_aligned_video_help(): void
    {
        $src = self::src('views/user/custom-tasks/proof.php');
        $this->assertStringContainsString('money_label($reward', $src);
        // کد خام ارز (irt/usdt) دیگر چاپ نمی‌شود
        $this->assertStringNotContainsString("e(\$submission->reward_currency ?? \$submission->currency ?? 'irt')", $src);
        $this->assertStringContainsString("to_jalali((string)\$submission->deadline_at, 'Y/m/d H:i')", $src);
        // متن راهنما با فرم/سرور هم‌راستا شد (قبلاً می‌گفت آپلود ویدیو فعال نیست)
        $this->assertStringContainsString('لینک ویدیو یا آپلود فایل ویدیو', $src);
        $this->assertStringNotContainsString('آپلود ویدیو در این فاز فعال نیست', $src);
    }

    /** @test */
    public function my_submissions_pins(): void
    {
        $src = self::src('views/user/custom-tasks/executor/my-submissions.php');
        // پاداش با اعشار/برچسب از ارز ردیف
        $this->assertStringContainsString('money_label($sub->reward_amount', $src);
        $this->assertStringNotContainsString('fa_number(number_format($sub->reward_amount', $src);
        // تاریخ جلالی
        $this->assertStringContainsString("to_jalali(\$sub->created_at ?? '', 'Y/m/d H:i')", $src);
        // e() روی task_id
        $this->assertStringContainsString("e((string)(\$sub->task_id ?? ''))", $src);
        // عنوان درست
        $this->assertStringContainsString('اجراهای تسک سفارشی من', $src);
        $this->assertStringNotContainsString('اجراهای Adtask من', $src);
        // صفحه‌بندی با partial مشترک (لینک‌های واقعی ?page=N)
        $this->assertStringContainsString("include view_path('partials.pagination')", $src);
        $this->assertStringNotContainsString('count($submissions) >= 20', $src);
    }

    /** @test */
    public function user_disputes_use_jalali_and_helper(): void
    {
        $disputes = self::src('views/user/custom-tasks/executor/disputes.php');
        $this->assertStringContainsString("to_jalali(\$item->created_at ?? '', 'Y/m/d H:i')", $disputes);

        $detail = self::src('views/user/custom-tasks/executor/dispute-detail.php');
        $this->assertStringContainsString('money_label($dispute->reward_amount', $detail);
        $this->assertStringNotContainsString("e(\$dispute->reward_currency ?? 'irt')", $detail);
        $this->assertStringContainsString("to_jalali(\$msg->created_at ?? '', 'Y/m/d H:i')", $detail);
    }

    /** @test */
    public function admin_show_pins_helper_and_deadline_hours(): void
    {
        $src = self::src('views/admin/custom-tasks/show.php');
        // «قیمت هر تسک» + کارمزد + بودجه‌ها با واحد/اعشار از ارز رکورد
        $this->assertStringContainsString('money_label($task->total_budget', $src);
        $this->assertStringContainsString('money_label($task->price_per_task', $src);
        $this->assertStringContainsString('money_label($feeAmount', $src);
        $this->assertStringNotContainsString('fa_number(number_format($task->price_per_task', $src);
        // «تومان»/«USDT» هاردکد قدیمی حذف شد
        $this->assertStringNotContainsString("e(\$task->currency === 'usdt' ? 'USDT' : 'تومان')", $src);
        // deadline_hours به‌جای ستون ناموجود deadline
        $this->assertStringContainsString('deadline_hours', $src);
        $this->assertStringNotContainsString('to_jalali($task->deadline', $src);
    }

    /** @test */
    public function admin_dispute_detail_uses_helper(): void
    {
        $src = self::src('views/admin/custom-tasks/dispute-detail.php');
        $this->assertStringContainsString('money_label($dispute->reward_amount', $src);
        $this->assertStringNotContainsString("e(\$dispute->reward_currency ?? 'irt')", $src);
    }

    /** @test */
    public function admin_index_loads_customtasks_js_and_real_type_filter(): void
    {
        $src = self::src('views/admin/custom-tasks/index.php');
        // دکمه‌های تأیید/رد بدون این اسکریپت مرده بودند
        $this->assertStringContainsString('assets/js/admin/customtasks.js', $src);
        $this->assertStringContainsString("e(csp_nonce())", $src);
        // 🧹 FIX-COSMET-03 (A2-N8) — همگام‌سازی پین با تک‌منبع‌سازی: گزینه‌های نوع
        // دیگر هاردکد در ویو نیستند؛ از custom_task_types() (delegate به
        // CustomTaskAdapter::allowedTaskTypes()) می‌آیند — همان ۴ نوع جدید که پین
        // قبلی تثبیت کرده بود حالا از تک‌منبع تأمین می‌شوند (پین تکمیلی در
        // CosmetPinningTest::test_l_03).
        $this->assertStringContainsString('$adapterTaskTypes = custom_task_types();', $src);
        $this->assertStringContainsString('foreach ($adapterTaskTypes as $k => $v)', $src);
        $this->assertStringNotContainsString('foreach ($typeLabels as $k => $v)', $src);
    }

    /** @test */
    public function admin_disputes_branch_detail_links_and_four_filter_options(): void
    {
        $src = self::src('views/admin/custom-tasks/disputes.php');
        // انشعاب لینک بر اساس ref_type (ردیف‌های غیر custom_task_submission در
        // /admin/custom-tasks/disputes/{id} وجود ندارند — INNER JOIN)
        $this->assertStringContainsString('$detailUrlFor', $src);
        $this->assertStringContainsString("'/admin/influencer/disputes/'", $src);
        $this->assertStringContainsString("e(\$detailUrlFor(\$d))", $src);
        $this->assertStringNotContainsString("url('/admin/custom-tasks/disputes/' . (int)\$d->id) ?>\">جزئیات", $src);
        // چهار گزینهٔ مجزای اینفلوئنسر به‌جای value="order" واحد
        $this->assertStringContainsString('value="order"', $src);
        $this->assertStringContainsString('value="story_order"', $src);
        $this->assertStringContainsString('value="influencer_order"', $src);
        $this->assertStringContainsString('value="influencer"', $src);
        $this->assertStringNotContainsString("in_array(\$filters['ref_type'] ?? '', ['order','story_order','influencer_order','influencer'], true) ? 'selected'", $src);
    }

    /** @test */
    public function analytics_page_follows_new_metrics_contract(): void
    {
        $src = self::src('views/admin/analytics/custom-tasks.php');
        $this->assertStringContainsString('آنالیتیکس تسک‌های سفارشی', $src);
        $this->assertStringNotContainsString("\$title = 'مدیریت'", $src);
        // کلیدهای تخت قرارداد جدید
        $this->assertStringContainsString("total_budget_irt", $src);
        $this->assertStringContainsString("total_budget_usdt", $src);
        $this->assertStringContainsString("reward_paid_irt", $src);
        $this->assertStringContainsString("reward_paid_usdt", $src);
        $this->assertStringContainsString("unique_workers", $src);
        // دکمه‌های دوره با مقدارهای today/all (قبلاً day و بدون all)
        $this->assertStringContainsString("'today' => 'امروز'", $src);
        $this->assertStringContainsString("'all' => 'همه'", $src);
        $this->assertStringContainsString('?period=\' . urlencode($pKey)', $src);
        // شکل قدیمی metrics['tasks']['total'] دیگر خوانده نمی‌شود
        $this->assertStringNotContainsString("\$metrics['tasks']['total']", $src);
    }

    /** @test */
    public function vitrine_resolve_dialog_sends_canonical_values_only(): void
    {
        $src = self::src('public/assets/js/admin/customtasks.js');
        // مقادیر buyer/seller توسط ولیدیتور (in:executor,advertiser,split) رد می‌شدند
        $this->assertStringNotContainsString("option('buyer'", $src);
        $this->assertStringNotContainsString("option('seller'", $src);
        $this->assertStringContainsString("option('advertiser', 'حق با خریدار (استرداد وجه)'", $src);
        $this->assertStringContainsString("option('executor', 'حق با فروشنده (آزادسازی وجه)'", $src);
        $this->assertStringContainsString("option('split', 'حل میانه (پرداخت درصدی)'", $src);
    }

    /** @test */
    public function feed_js_appends_currency_label_from_data_currency(): void
    {
        $src = self::src('public/assets/js/views/usertasksfeed.js');
        $this->assertStringContainsString('card.dataset.currency', $src);
        $this->assertStringContainsString("rewardCur === 'usdt' ? 'تتر' : 'تومان'", $src);
    }

    /** @test */
    public function icon_xl_preserved_and_dead_files_deleted(): void
    {
        // .icon-xl تنها قانون قاب‌اثبات‌شدهٔ useradtasks.css بود — به userearn.css منتقل شد
        $earnCss = self::src('public/assets/css/views/userearn.css');
        $this->assertStringContainsString('.icon-xl { font-size: 64px; }', $earnCss);

        // فایل‌های مرده حذف شده‌اند (PHPUnit 8.5 — assertFileDoesNotExist ندارد)
        $this->assertFalse(file_exists(self::repoPath('views/admin/custom-tasks/analytics.php')), 'ویوی یتیم analytics.php باید حذف شود');
        $this->assertFalse(file_exists(self::repoPath('public/assets/css/views/usertasksfeed.css')), 'CSS مرده باید حذف شود');
        $this->assertFalse(file_exists(self::repoPath('public/assets/css/views/useradtasks.css')), 'CSS مرده باید حذف شود');

        // هیچ ویویی دیگر به فایل‌های حذف‌شده لینک نمی‌دهد؛ adtube به userearn.css سوئیچ کرد
        $adtube = self::src('views/user/adtube/index.php');
        $this->assertStringNotContainsString("asset('assets/css/views/usertasksfeed.css')", $adtube);
        $this->assertStringNotContainsString("asset('assets/css/views/useradtasks.css')", $adtube);
        $this->assertStringContainsString("asset('assets/css/views/userearn.css')", $adtube);
    }
}
