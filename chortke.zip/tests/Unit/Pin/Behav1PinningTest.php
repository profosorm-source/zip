<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-BEHAV1 — پین‌های بچ ۱ (رفتاری): ۹ یافتهٔ M22-RA.
 * هر یافته اینجا به‌صورت قراردادِ کد پین می‌شود (رشته/الگو در سورس واقعی).
 * سنجشِ اجرایی روی DB واقعی: tools/behav1-live-test.php
 */
final class Behav1PinningTest extends TestCase
{
    private static function src(string $rel): string
    {
        $p = dirname(__DIR__, 3) . '/' . $rel;
        self::assertFileExists($p, "فایل مورد انتظار وجود ندارد: {$rel}");
        return (string)file_get_contents($p);
    }

    /** مثل M22MedMain: تکهٔ سورس متد بدون خطوط کامنت — کامنتِ «چه بود» نادیده، خودِ کد سنجیده می‌شود */
    private static function method(string $src, string $name, int $len = 1800): string
    {
        $pos = (int)strpos($src, "function {$name}");
        self::assertNotFalse($pos, "متد {$name} پیدا نشد");
        $chunk = substr($src, $pos, $len);
        $codeLines = [];
        foreach (explode("\n", $chunk) as $line) {
            $t = trim($line);
            if ($t === '' || str_starts_with($t, '//') || str_starts_with($t, '*') || str_starts_with($t, '/*')) {
                continue;
            }
            $codeLines[] = $line;
        }
        return implode("\n", $codeLines);
    }

    /** سورسِ کل فایل بدون خطوط کامنت — برای شمارش الگوها؛ کامنت‌های «چه بود»
     *  الگوهای قدیمی را عیناً تکرار می‌کنند و نباید در شمارش بیایند */
    private static function fileCode(string $src): string
    {
        $codeLines = [];
        foreach (explode("\n", $src) as $line) {
            $t = trim($line);
            if ($t === '' || str_starts_with($t, '//') || str_starts_with($t, '*') || str_starts_with($t, '/*')) {
                continue;
            }
            $codeLines[] = $line;
        }
        return implode("\n", $codeLines);
    }

    // ── A1-N1: داشبورد مجری بدون ستون شبح ──
    /** @test */
    public function a1n1_worker_dashboard_uses_real_timestamps_not_ghost_column(): void
    {
        $src = self::src('app/Models/CustomTaskAnalyticsModel.php');
        $m = self::method($src, 'analytics_getWorkerDashboard', 3400);
        $this->assertStringNotContainsString('completion_time_minutes', $m, 'ستون شبح باید حذف شده باشد');
        $this->assertStringContainsString('TIMESTAMPDIFF(MINUTE, created_at, COALESCE(approved_at, reviewed_at))', $m);
        // کلیدهای هم‌بسته که با مرگ کوئری از دست می‌رفتند:
        $this->assertStringContainsString('as total_earned_irt', $m);
        $this->assertStringContainsString('as approved', $m);
    }

    // ── A1-N2: گذار pending_review در نقشهٔ custom_task ──
    /** @test */
    public function a1n2_custom_task_transitions_cover_pending_review(): void
    {
        $src = self::src('app/Services/StateMachineService.php');
        $pos = (int)strpos($src, 'CUSTOM_TASK_TRANSITIONS = [');
        $this->assertNotFalse($pos, 'CUSTOM_TASK_TRANSITIONS پیدا نشد');
        $chunk = substr($src, $pos, 900);
        $this->assertStringContainsString("'pending_review' => ['active', 'rejected']", $chunk);
    }

    // ── A1-N3: مسیرهای force اختلاف را می‌بندند ──
    /** @test */
    public function a1n3_force_paths_close_open_disputes_with_cas(): void
    {
        $src = self::src('app/Services/CustomTask/AdminCustomTaskService.php');
        $approve = self::method($src, 'forceApproveSubmissionByAdmin', 9000);
        $this->assertStringContainsString("UPDATE disputes SET status = ?", $approve);
        $this->assertStringContainsString("ref_type = 'custom_task_submission' AND ref_id = ?", $approve);
        $this->assertStringContainsString("status IN ('open','open_peer','under_review','escalated')", $approve);
        $this->assertStringContainsString("'resolved_for_executor', 'worker_wins'", $approve);
        $this->assertStringContainsString('resolved_by = ?', $approve);
        $this->assertStringContainsString("'disputes_closed' => \$disputesClosed", $approve);

        $reject = self::method($src, 'forceRejectSubmissionByAdmin', 9000);
        $this->assertStringContainsString("UPDATE disputes SET status = ?", $reject);
        $this->assertStringContainsString("status IN ('open','open_peer','under_review','escalated')", $reject);
        $this->assertStringContainsString("'resolved_for_advertiser', 'advertiser_wins'", $reject);
        $this->assertStringContainsString('resolved_by = ?', $reject);
    }

    // ── A1-N4: سقف دستورالعمل مدرک + blob کوتاه ──
    /** @test */
    public function a1n4_proof_description_capped_at_source_and_blob(): void
    {
        $adapter = self::src('app/Adapters/CustomTaskAdapter.php');
        $this->assertStringContainsString('PROOF_DESCRIPTION_MAX = 2000', $adapter);
        $this->assertSame(2, substr_count($adapter, 'self::PROOF_DESCRIPTION_MAX'), 'سقف باید هم روی proof_description هم روی schema.description باشد');

        $ctrl = self::src('app/Controllers/User/CustomTaskController.php');
        $this->assertStringContainsString("mb_substr(str_value(\$embeddedSchema['description']), 0, 1000)", $ctrl);
    }

    // ── A2-N2: جستجوی ادمین با قید نوع ──
    /** @test */
    public function a2n2_admin_custom_task_search_scopes_type(): void
    {
        $ctrl = self::src('app/Controllers/Admin/AdTaskController.php');
        $m = self::method($ctrl, 'index', 2600);
        $this->assertStringContainsString("'type' => 'custom_task',", $m, 'فیلترهای جستجو باید type هاردکد داشته باشند');
        $this->assertStringContainsString('searchAdminTasks($search, $filters', $m);

        $ads = self::src('app/Models/Ads.php');
        $sm = self::method($ads, 'searchAdminTasks', 2200);
        $this->assertStringContainsString("(\$type === 'custom' || \$type === 'custom_task')", $sm, 'نگاشت custom/custom_task به a.type=custom_task باید بماند');
    }

    // ── A2-N4: قیمت با شرط ارز ──
    /** @test */
    public function a2n4_price_filters_and_sort_are_currency_scoped(): void
    {
        $svc = self::src('app/Services/UnifiedTaskService.php');
        $code = self::fileCode($svc);
        $this->assertStringContainsString('private function applyPriceFilters', $code);
        $this->assertStringContainsString('(a.currency = ? AND a.price_per_task >= ?)', $code);
        $this->assertStringContainsString('(a.currency = ? AND a.price_per_task <= ?)', $code);
        $this->assertSame(1, substr_count($code, 'a.price_per_task >= ?'), 'قید بدون ارز نباید بازمانده باشد');
        $this->assertSame(1, substr_count($code, 'a.price_per_task <= ?'), 'قید بدون ارز نباید بازمانده باشد');
        $this->assertSame(2, substr_count($code, 'CASE WHEN a.currency = ? THEN 0 ELSE 1 END'), 'هر دو مرتب‌سازی قیمت باید گروهِ هم‌ارز اول باشند');
        // تک-منبع: هر دو متد لیست و شمارش از همان کمکی
        $this->assertSame(2, substr_count($code, 'applyPriceFilters($where'), 'لیست و شمارش هر دو باید از applyPriceFilters بگذرند');

        $feedCtrl = self::src('app/Controllers/User/TaskFeedController.php');
        $this->assertStringContainsString("'currency'  => \$this->request->query('currency')", $feedCtrl);
    }

    // ── A3-N1: گارد inf-proof روی basename ──
    /** @test */
    public function a3n1_story_proof_guard_compares_basename(): void
    {
        $src = self::src('app/Models/FileAccess.php');
        $m = self::method($src, 'checkStoryProofOwnership');
        $this->assertStringContainsString("SUBSTRING_INDEX(proof_screenshot, '/', -1) = ?", $m);
        $this->assertStringNotContainsString('WHERE proof_screenshot = ?', $m);
    }

    // ── A3-N2: همهٔ RequireFeatureهای API با ,json ──
    /** @test */
    public function a3n2_all_api_require_feature_usages_carry_json_mode(): void
    {
        $routes = self::src('routes/api.php');
        preg_match_all("#RequireFeature::class \\. ':([a-z_]+)'#", $routes, $without);
        $this->assertSame([], $without[1], 'کاربرد بدون ,json نباید باشد: ' . implode(',', $without[1]));
        preg_match_all("#RequireFeature::class \\. ':([a-z_]+),json'#", $routes, $with);
        $this->assertCount(9, $with[1], 'باید ۹ کاربرد ,json باشد (۳ لاتری قبلی + ۶ جدید)');
        $this->assertContains('crypto_wallet', $with[1]);
        $this->assertContains('crypto_deposit', $with[1]);
        $this->assertContains('tasks', $with[1]);
    }

    // ── D2-N13r: پاک‌سازی فایل orphan در شکست‌های جاب ──
    /** @test */
    public function d2n13r_job_cleans_orphan_file_on_all_failure_paths(): void
    {
        $src = self::src('app/Jobs/CustomTask/SubmitProofJob.php');
        $code = self::fileCode($src);
        $this->assertStringContainsString('private function cleanupOrphanProofFile', $code);
        $this->assertStringContainsString('#^task-proofs/[0-9a-f]{24}', $code, 'الگوی امن UploadService الزامی است (S17-2)');
        $this->assertGreaterThanOrEqual(10, substr_count($code, '$this->cleanupOrphanProofFile('), 'همهٔ مسیرهای شکست باید پاک‌سازی کنند');
        // چرخهٔ کامل پرچم: false در ابتدا → true فقط پس از CAS موفق → خوانده‌شدن در catch
        $this->assertSame(1, substr_count($code, '$filePersisted = false'), 'پرچم باید یک‌بار در ابتدا false شود');
        $this->assertSame(1, substr_count($code, '$filePersisted = true'), 'و یک‌بار فقط پس از CAS موفق true');
        $this->assertSame(1, substr_count($code, 'empty($filePersisted)'), 'و یک‌بار در catch خوانده شود');
    }
}
