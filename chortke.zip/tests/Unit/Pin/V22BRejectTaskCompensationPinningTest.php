<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🧾 FIX-V22-02 (بچ V22B — گزینهٔ A، تصمیم محصولی کارفرما ۲۰۲۶-۱۱-۰۸) — پین‌های
 * ساختاری تسویهٔ جبرانی ارسال‌های submitted هنگام رد تسک توسط ادمین:
 *
 *   ۱) مارکر FIX-V22-02 در AdminCustomTaskService (مرکز اصلاح) و مدل.
 *   ۲) ترتیب داخل تراکنش rejectTask: گارد escrow disputed «قبل» از اولین
 *      عمل مالی تسویه (پیام روشن داور، نه خطای گنگ release).
 *   ۳) ترتیب: settleCustomTaskReward (تسویهٔ جبرانی) «قبل» از refundHeldBudget
 *      (استرداد به کارفرما) — پاداش مجریان از بودجهٔ قفل‌شده، سپس باقی.
 *   ۴) تسویه از هم‌موتورِ approveSubmission اما مستقیم در همین تراکنش؛ خودِ
 *      approveSubmission داخل rejectTask فراخوانی نمی‌شود (تراکنش تودرتو ممنوع).
 *   ۵) گارد دوبل‌پرداخت per-worker (seenWorkers؛ فقط قدیمی‌ترین submitted هر
 *      مجری تسویه؛ بقیه رد گروهی) — هم‌قرارداد T22-07.
 *   ۶) reviewed_by = ادمینِ ردکننده (نه کارفرما) + reward_paid=1 + txId.
 *   ۷) incrementCustomTaskCompletion با shouldDecrementPending=true.
 *   ۸) متد مدل submission_getSubmittedForTaskForUpdate: FOR UPDATE + ORDER BY
 *      id ASC + فقط status='submitted'.
 *   ۹) رد گروهیِ باقی‌مانده‌ها «بعد» از حلقهٔ تسویه می‌آید (تسویه‌شده‌ها
 *      approved شده‌اند و UPDATE گروهی فقط پرداخت‌نشده‌ها را می‌گیرد).
 *  ۱۰) پس از commit: TaskCompletedEvent per-submission از طریق outbox
 *      (XP/trust per-submission + اعلان مجری — الگوی approveSubmission).
 *  ۱۱) پاسخ موفقیت فیلدهای settled_* و پیام داینامیک دارد (شفافیت جبران).
 *
 * @group architecture
 */
final class V22BRejectTaskCompensationPinningTest extends TestCase
{
    private static function repoPath(string $rel): string
    {
        return dirname(__DIR__, 3) . '/' . $rel;
    }

    /** @return array{string, string} */
    private static function read(string $rel): array
    {
        $src = file_get_contents(self::repoPath($rel));
        self::assertIsString($src, $rel . ' باید موجود باشد');
        return [$src, $rel];
    }

    private static function assertContainsWithRel(string $needle, string $haystack, string $rel, string $why): void
    {
        self::assertStringContainsString($needle, $haystack, $why . ' — ' . $rel);
    }

    /** @test */
    public function v22b_01_markers_present_in_service_and_model(): void
    {
        [$svc, $svcRel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');
        [$mdl, $mdlRel] = self::read('app/Models/CustomTaskSubmissionModel.php');

        self::assertContainsWithRel('FIX-V22-02', $svc, $svcRel, 'مارکر FIX-V22-02 در سرویس');
        self::assertContainsWithRel('گزینهٔ A', $svc, $svcRel, 'تصمیم محصولی (گزینهٔ A) مستند شده باشد');
        self::assertContainsWithRel('FIX-V22-02', $mdl, $mdlRel, 'مارکر FIX-V22-02 در مدل');
    }

    /** @test */
    public function v22b_02_disputed_guard_precedes_first_settlement(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        $disputedPos = strpos($svc, "=== 'disputed'");
        $settlePos = strpos($svc, 'settleCustomTaskReward(');
        self::assertIsInt($disputedPos, 'گارد escrow disputed باید موجود باشد');
        self::assertIsInt($settlePos, 'فراخوانی settleCustomTaskReward باید موجود باشد');
        self::assertLessThan(
            $settlePos,
            $disputedPos,
            'FIX-V22-02: گارد disputed باید «قبل» از اولین تسویه بیاید تا داور پیام روشن بگیرد، نه خطای گنگ release'
        );
    }

    /** @test */
    public function v22b_03_settlement_precedes_refund(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        $settlePos = strpos($svc, 'settleCustomTaskReward(');
        $refundPos = strpos($svc, 'refundHeldBudget(');
        self::assertIsInt($refundPos, 'فراخوانی refundHeldBudget باید موجود باشد');
        self::assertLessThan(
            $refundPos,
            $settlePos,
            'FIX-V22-02: پاداش مجریان باید «قبل» از استرداد به کارفرما از بودجه تسویه شود (گزینهٔ A)'
        );
    }

    /** @test */
    public function v22b_04_same_engine_not_nested_approve(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        // هم‌موتور: settle مستقیم از moderationService
        self::assertContainsWithRel(
            '$this->moderationService->settleCustomTaskReward(',
            $svc,
            $rel,
            'تسویه باید با همان موتور settleCustomTaskReward انجام شود'
        );
        // خودِ approveSubmission نباید داخل سرویس ادمین فراخوانی شود (تراکنش تودرتو)
        self::assertStringNotContainsString(
            'approveSubmission(',
            $svc,
            'FIX-V22-02: فراخوانی approveSubmission داخل rejectTask ممنوع است — خودش تراکنش جدید باز می‌کند'
        );
    }

    /** @test */
    public function v22b_05_per_worker_double_payment_guard(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        self::assertContainsWithRel('$seenWorkers = [];', $svc, $rel, 'گارد seenWorkers باید موجود باشد');
        self::assertContainsWithRel('isset($seenWorkers[$workerId])', $svc, $rel, 'چک عضویت per-worker');
        self::assertContainsWithRel('continue; // فقط یک پاداش per (task, worker)', $svc, $rel, 'skip بقیهٔ submittedهای همان مجری');
    }

    /** @test */
    public function v22b_06_admin_is_the_reviewer_of_compensation(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        self::assertContainsWithRel("'reviewed_by' => \$adminId", $svc, $rel, 'داورِ تسویهٔ جبرانی ادمین است نه کارفرما');
        self::assertContainsWithRel("'reward_paid' => 1", $svc, $rel, 'پرچم پرداخت پاداش');
        self::assertContainsWithRel("'reward_transaction_id' => \$txId", $svc, $rel, 'شناسهٔ تراکنش آزادسازی ذخیره می‌شود');
    }

    /** @test */
    public function v22b_07_counters_decrement_pending(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        self::assertContainsWithRel(
            'incrementCustomTaskCompletion($taskId, (string)$rewardAmount, true)',
            $svc,
            $rel,
            'شمارندهٔ completion با shouldDecrementPending=true (هم‌الگوی submitted در approveSubmission)'
        );
    }

    /** @test */
    public function v22b_08_model_fetch_locked_ordered(): void
    {
        [$mdl, $rel] = self::read('app/Models/CustomTaskSubmissionModel.php');

        $mPos = strpos($mdl, 'function submission_getSubmittedForTaskForUpdate');
        self::assertIsInt($mPos, 'متد واکشی باید موجود باشد');
        $body = substr($mdl, $mPos, 700);
        self::assertStringContainsString("status = 'submitted'", $body, 'فقط submittedها — ' . $rel);
        self::assertStringContainsString('ORDER BY id ASC', $body, 'قدیمی‌ترین هر مجری اول — ' . $rel);
        self::assertStringContainsString('FOR UPDATE', $body, 'قفل ردیف داخل تراکنش rejectTask — ' . $rel);
    }

    /** @test */
    public function v22b_09_group_reject_after_settlement_loop(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        $settlePos = strpos($svc, 'settleCustomTaskReward(');
        $groupPos = strpos($svc, 'submission_rejectSubmittedForTask(');
        self::assertIsInt($groupPos, 'رد گروهی باقی‌مانده‌ها باید موجود باشد');
        self::assertLessThan(
            $groupPos,
            $settlePos,
            'رد گروهی باید «بعد» از حلقهٔ تسویه بیاید تا فقط پرداخت‌نشده‌ها را رد کند'
        );
    }

    /** @test */
    public function v22b_10_completed_events_after_commit(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        $commitPos = strpos($svc, '$this->db->commit();');
        $eventPos = strpos($svc, 'custom_task.v22b_settle_event_failed');
        self::assertIsInt($commitPos, 'commit اصلی باید موجود باشد');
        self::assertIsInt($eventPos, 'حلقهٔ رویداد پس از commit باید موجود باشد');
        self::assertGreaterThan(
            $commitPos,
            $eventPos,
            'FIX-V22-02: رویداد TaskCompletedEvent پس از commit ثبت می‌شود (شکستش نتیجه را برنمی‌گرداند)'
        );
        self::assertContainsWithRel('TaskCompletedEvent::class', $svc, $rel, 'رویداد از طریق outbox');
        self::assertContainsWithRel('$settledId', $svc, $rel, 'submission_id در رویداد (XP/trust per-submission FIX-M22-03)');
    }

    /** @test */
    public function v22b_11_response_reports_compensation(): void
    {
        [$svc, $rel] = self::read('app/Services/CustomTask/AdminCustomTaskService.php');

        self::assertContainsWithRel("'settled_submissions' => \$settledCount", $svc, $rel, 'تعداد تسویه‌شده‌ها در پاسخ');
        self::assertContainsWithRel("'settled_submission_ids' => \$settledSubmissionIds", $svc, $rel, 'شناسه‌های تسویه‌شده‌ها در پاسخ');
        self::assertContainsWithRel("'settled_amount' => \$settledTotal", $svc, $rel, 'جمع پاداش در پاسخ');
        self::assertContainsWithRel('از بودجهٔ تسک تسویه شد', $svc, $rel, 'پیام موفقیت داینامیک (شفافیت برای داور)');
    }
}
