<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCRATE-DISPLAY-01 (۲۰۲۶-۱۱-۰۹ — داوری/درخواست کارفرما) — پین‌های
 * ساختاری «نمایش عمومی رأی کاربران به کمپین سوشیال» روی درخت زنده.
 *
 * قرینهٔ FIX-SEO3-01 سئو: زیرساخت ثبت رأی (rateTask → interactions با
 * interactable_type='social_task') موجود بود ولی هیچ‌جا عمومی نمایش داده
 * نمی‌شد. این بچ سه سطح نمایش را وصل می‌کند:
 *   ۱) فید وب بازار تسک‌ها (/tasks — تنها فهرست وب سوشیال)
 *   ۲) فهرست API (GET /api/v1/social/tasks → avg_rating/rating_count)
 *   ۳) پنل تبلیغ‌دهنده (/ads/{id} → کارت بازخورد مجریان)
 *
 * سبک خانه: بازرسی سورس (رفتارِ runtime در SocialTaskApiControllerTasksRatingTest
 * و E2E زندهٔ socguard-live-e2e بخش ۵ پین شده).
 */
final class SocRateDisplayPinningTest extends TestCase
{
    private const BASE = __DIR__ . '/../../../';

    private function read(string $path): string
    {
        $src = (string)file_get_contents(self::BASE . $path);
        self::assertNotSame('', $src, "فایل یافت نشد: {$path}");
        return $src;
    }

    // ─────────────── سطح ۱: فید وب بازار تسک‌ها ───────────────

    public function test_task_feed_controller_batches_social_ratings(): void
    {
        $src = $this->read('app/Controllers/User/TaskFeedController.php');

        // فقط کارت‌های سوشیال (هر دو مقدار نوع) — سئو از صفحهٔ خودش
        self::assertStringContainsString("in_array((string)(\$task->type ?? ''), ['social', 'social_task'], true)", $src);
        // یک کوئری batch برای کل صفحه — همان قرارداد FIX-SEO3-01
        self::assertStringContainsString("getRatingsSummary('social_task', \$socialAdIds)", $src);
        // پاس به ویو
        self::assertStringContainsString("'socialRatings' => \$socialRatings", $src);
        self::assertStringContainsString('FIX-SOCRATE-DISPLAY-01', $src);
        // صفحهٔ خالی ⇒ هیچ کوئری امتیازی
        self::assertStringContainsString('$socialAdIds === []', $src);
    }

    public function test_feed_view_renders_social_community_rating_badge(): void
    {
        $src = $this->read('views/user/tasks/feed.php');

        // فالبک امن (ویو مستقیم include شده هم کرش نکند)
        self::assertStringContainsString('$socialRatings = $socialRatings ?? [];', $src);
        // فقط کارت‌های سوشیالِ دارای رأی — count>0
        self::assertStringContainsString("\$socRating = \$type === 'social' ? (\$socialRatings[(int)(\$task->id ?? 0)] ?? null) : null;", $src);
        self::assertStringContainsString("is_array(\$socRating) && (int)(\$socRating['count'] ?? 0) > 0", $src);
        self::assertStringContainsString('رأی کاربران:', $src);
        self::assertStringContainsString('از ۵', $src);
        self::assertStringContainsString('FIX-SOCRATE-DISPLAY-01', $src);
    }

    // ─────────────── سطح ۲: فهرست API ───────────────

    public function test_social_api_controller_injects_rating_fields(): void
    {
        $src = $this->read('app/Controllers/Api/SocialTaskApiController.php');

        // سرویس امتیاز اختیاری (تست mock تزریق می‌کند؛ production از کانتینر)
        self::assertStringContainsString('?\\App\\Services\\Interaction\\RatingService $ratingService = null', $src);
        // batch برای کل صفحه با همان interactable_type ثبت رأی
        self::assertStringContainsString("getRatingsSummary('social_task', \$adIds)", $src);
        // تزریق صادقانه در هر ردیف — بدون رأی = صفر، نه حذف کلید
        self::assertStringContainsString("\$t->avg_rating   = isset(\$s['avg']) ? (float)\$s['avg'] : 0.0;", $src);
        self::assertStringContainsString("\$t->rating_count = isset(\$s['count']) ? (int)\$s['count'] : 0;", $src);
        self::assertStringContainsString('FIX-SOCRATE-DISPLAY-01', $src);
    }

    // ─────────────── سطح ۳: پنل تبلیغ‌دهنده ───────────────

    public function test_ads_controller_builds_social_feedback(): void
    {
        $src = $this->read('app/Controllers/User/AdsController.php');

        // هر دو مقدار نوع سوشیال (social قدیمی و social_task)
        self::assertStringContainsString("in_array((string)(\$ad->type ?? ''), ['social', 'social_task'], true)", $src);
        self::assertStringContainsString("getRatingsSummary('social_task', [\$adId])", $src);
        self::assertStringContainsString("getRecentRatings('social_task', \$adId, 3)", $src);
        // هر دو کارت سئو و سوشیال به ویو پاس می‌شوند
        self::assertStringContainsString("'seoFeedback', 'socialFeedback'", $src);
        self::assertStringContainsString('FIX-SOCRATE-DISPLAY-01', $src);
    }

    public function test_ads_show_view_has_social_community_rating_card(): void
    {
        $src = $this->read('views/user/ads/show.php');

        self::assertStringContainsString('$isSocialOwner = in_array', $src);
        self::assertStringContainsString('id="socialCommunityRating"', $src);
        // ستاره‌ها از میانگین سرور رندر می‌شوند (نه عدد ثابت)
        self::assertStringContainsString("\$s <= round((float)(\$socialFeedback['avg'] ?? 0))", $src);
        // کامنت آخرین رأی‌ها از context JSON (getRecentRatings)
        self::assertStringContainsString("\$rr['comment']", $src);
        self::assertStringContainsString('FIX-SOCRATE-DISPLAY-01', $src);
        // رگرسیون: کارت سئو دست‌نخورده مانده
        self::assertStringContainsString('id="seoCommunityRating"', $src);
    }

    // ─────────────── رگرسیون‌های قرینه‌ها ───────────────

    public function test_seo_display_and_socreport2_report_filter_untouched(): void
    {
        // سئو: کارت فهرست اختصاصی خودش همچنان ستاره دارد (این بچ سئو را لمس نکرد)
        $seoIndex = $this->read('views/user/seo/index.php');
        self::assertStringContainsString('seo-community-rating', $seoIndex);

        // SOCREPORT2: فیلتر وضعیت reportTask دست‌نخورده
        $svc = $this->read('app/Services/SocialTask/SocialTaskService.php');
        self::assertStringContainsString("AND status NOT IN ('pending','cancelled')", $svc);

        // گارد ثبت رأی (منبع دادهٔ این نمایش) سر جایش است — فقط مجریِ approved
        self::assertStringContainsString("WHERE ad_id = ? AND executor_id = ? AND status = 'approved'", $svc);
    }

    public function test_live_e2e_pins_display_contract(): void
    {
        $e2e = $this->read('tools/socguard-live-e2e.php');

        // بخش ۵: سه سطح نمایش + صفر صادقانه
        self::assertStringContainsString('FIX-SOCRATE-DISPLAY-01', $e2e);
        self::assertStringContainsString('⑤ API: کمپین دارای رأی → avg_rating=5 + rating_count=1', $e2e);
        self::assertStringContainsString('⑤ API: کمپین بدون رأی → صفر صادقانه (نه حذف کلید)', $e2e);
        self::assertStringContainsString('⑤ وب: کارت سوشیالِ دارای رأی در فید بازار با نشان «رأی کاربران»', $e2e);
        self::assertStringContainsString('⑤ پنل تبلیغ‌دهنده: کارت بازخورد مجریان + کامنت آخرین رأی', $e2e);
        // seed با نوع social_task (چون getAvailableTasks فقط همین نوع را فهرست می‌کند)
        self::assertStringContainsString("'social_task', 'instagram', 'active', 1, 'irt'", $e2e);
    }

    public function test_mobile_api_guide_documents_rating_fields(): void
    {
        $src = $this->read('docs/MOBILE-API-GUIDE-fa.md');
        self::assertStringContainsString('FIX-SOCRATE-DISPLAY-01', $src);
        self::assertStringContainsString('`GET /api/v1/social/tasks`', $src);
        self::assertStringContainsString('`avg_rating`', $src);
        self::assertStringContainsString('`rating_count`', $src);
    }
}
