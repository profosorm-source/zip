<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCRATE-MOBILE-01 (۲۰۲۶-۱۱-۱۰) — پین‌های ساختاری «ستاره‌های رأی
 * کاربران در سطح API اپ موبایل» روی درخت زنده.
 *
 * زنجیرهٔ SOCRATE تا این‌جا: رأی‌دهی گاردشده (SOCGUARD) → نمایش فهرست وب/
 * API/پنل (SOCRATE-DISPLAY) → رأی از صفحهٔ اجرای وب (SOCRATE-VOTE-EXEC).
 * این بچ آخرین سطح را می‌بندد: جزئیات کمپین (showAd) و پنل مالک (myAds)
 * از کانال API + قرارداد کامل سوشیال در مستند موبایل:
 *   ۱) showAd غیرمالک: sanitize + avg_rating/rating_count/my_rating
 *   ۲) showAd مالک: پاسخ کامل + avg_rating/rating_count (بدون my_rating)
 *   ۳) myAds: هر ردیف + avg_rating/rating_count (batch)
 *   ۴) مستند MOBILE-API-GUIDE: بخش اختصاصی سوشیال + فیلدهای ستاره
 *
 * سبک خانه: بازرسی سورس (رفتارِ runtime در SocialTaskApiControllerMobileRatingTest
 * و E2E زندهٔ socguard-live-e2e بخش ⑦ پین شده).
 */
final class SocRateMobilePinningTest extends TestCase
{
    private const BASE = __DIR__ . '/../../../';

    private function read(string $path): string
    {
        $src = (string)file_get_contents(self::BASE . $path);
        self::assertNotSame('', $src, "فایل یافت نشد: {$path}");
        return $src;
    }

    // ─────────────── سطح ۱: showAd — جزئیات تک‌کمپین ───────────────

    public function test_show_ad_sanitized_payload_includes_ratings_and_my_rating(): void
    {
        $src = $this->read('app/Controllers/Api/SocialTaskApiController.php');

        // گارد type: فقط کمپین سوشیال (id آگهی غیرسوشیال رأی سوشیالِ هم‌شماره نگیرد)
        self::assertStringContainsString("\$isSocialType = in_array((string)(\$adObj->type ?? ''), ['social', 'social_task'], true)", $src);
        // summary تک‌آگهی از همان سرویس DISPLAY (یک منبع داده)
        self::assertStringContainsString("getRatingsSummary('social_task', [\$adKey])[\$adKey] ?? null", $src);
        // sanitize غیرمالک: سه فیلد ستاره
        self::assertStringContainsString("\$adData['avg_rating']", $src);
        self::assertStringContainsString("\$adData['rating_count']", $src);
        self::assertStringContainsString("getUserRating((int)\$user->id, 'social_task', \$adKey)", $src);
        self::assertStringContainsString('FIX-SOCRATE-MOBILE-01', $src);
        // گارد IDOR دست‌نخورده: sanitize همچنان کوتاه است (budget مالکانه ندارد)
        self::assertStringContainsString("'reward_amount' => \$adObj->price_per_task ?? \$adObj->reward_amount ?? 0,", $src);
    }

    public function test_show_ad_owner_gets_ratings_on_full_object(): void
    {
        $src = $this->read('app/Controllers/Api/SocialTaskApiController.php');

        // مالک: فیلدها روی آبجکت کامل — و my_rating ندارد (گارد تضاد منافع)
        self::assertStringContainsString("\$ad->avg_rating   = isset(\$ratingSummary['avg'])", $src);
        self::assertStringContainsString("\$ad->rating_count = isset(\$ratingSummary['count'])", $src);
        // getUserRating فقط در شاخهٔ sanitize (غیرمالک) — نه مالک
        $ownerBranch = (string)substr($src, (int)strpos($src, 'FIX-SOCRATE-MOBILE-01: مالک هم قرینهٔ پنل وب'));
        $this->assertNotFalse($ownerBranch);
        self::assertStringNotContainsString('getUserRating', $ownerBranch);
    }

    // ─────────────── سطح ۲: myAds — پنل مالک ───────────────

    public function test_my_ads_batches_social_ratings(): void
    {
        $src = $this->read('app/Controllers/Api/SocialTaskApiController.php');

        // یک کوئری batch برای کل صفحه (قرینهٔ tasks)
        self::assertStringContainsString("getRatingsSummary('social_task', \$adIds)", $src);
        // صفحهٔ خالی ⇒ هیچ کوئری امتیازی
        self::assertStringContainsString('$adIds === []', $src);
        // دو متد (tasks + myAds) × مارکر — به‌علاوهٔ دو شاخهٔ showAd
        $this->assertSame(4, substr_count($src, 'FIX-SOCRATE-MOBILE-01'));
    }

    // ─────────────── سطح ۳: مستند قرارداد موبایل ───────────────

    public function test_mobile_api_guide_has_dedicated_social_section_with_rating_fields(): void
    {
        $src = $this->read('docs/MOBILE-API-GUIDE-fa.md');

        // بخش اختصاصی سوشیال (قرینهٔ بخش ۵ سئو / بخش ۶ سفارشی) + فیلدهای ستاره
        self::assertStringContainsString('## ۷. تسک‌های سوشیال', $src);
        self::assertStringContainsString('`GET /social/tasks?page=&per_page=`', $src);
        self::assertStringContainsString('`GET /social/ads/{id}`', $src);
        self::assertStringContainsString('`GET /social/ads`', $src);
        self::assertStringContainsString('`my_rating`', $src);
        self::assertStringContainsString('FIX-SOCRATE-MOBILE-01', $src);
        // شیفت شماره‌های پس از بخش جدید حفظ شده
        self::assertStringContainsString('## ۸. بقیهٔ قابلیت‌های آمادهٔ API', $src);
        self::assertStringContainsString('## ۱۱. نقشهٔ مسیرها', $src);
    }

    // ─────────────── سطح ۴: E2E زنده ───────────────

    public function test_live_e2e_pins_mobile_display_contract(): void
    {
        $e2e = $this->read('tools/socguard-live-e2e.php');

        // بخش ⑦: ستاره‌ها در showAd/myAds از کانال API
        self::assertStringContainsString('FIX-SOCRATE-MOBILE-01', $e2e);
        self::assertStringContainsString('⑦ API: showAd غیرمالک', $e2e);
        self::assertStringContainsString('⑦ API: showAd مالک', $e2e);
        self::assertStringContainsString('⑦ API: myAds', $e2e);
    }

    // ─────────────── رگرسیون: سطح‌های قبلی دست‌نخورده ───────────────

    public function test_previous_socrate_surfaces_untouched(): void
    {
        $api = $this->read('app/Controllers/Api/SocialTaskApiController.php');

        // tasks (DISPLAY) همچنان فیلدها را می‌سازد
        self::assertStringContainsString('FIX-SOCRATE-DISPLAY-01', $api);
        self::assertStringContainsString('getAvailableTasksForExecutor', $api);
        // گارد SocGuard: همچنان هیچ اندپوینت rateTask در کانال API نیست
        self::assertStringNotContainsString('rateTask', $api);

        // سئو از این بچ جداست — قرارداد فهرست دست‌نخورده
        $seo = $this->read('app/Controllers/Api/SeoTaskApiController.php');
        self::assertStringContainsString('FIX-SEO3-01', $seo);
    }
}
