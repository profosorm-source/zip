<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBCTR — پین‌های بچ ۲ (قرارداد API موبایل): ۴ یافتهٔ
 * A3-N3 + A1-N15 + A1-N8 + A3-N7. هر یافته به‌صورت قراردادِ کد پین
 * می‌شود (رشته/الگو در سورس واقعی). سنجشِ اجرایی روی DB/HTTP واقعی:
 * tools/mobctr-live-test.php.
 */
final class MobileContractPinningTest extends TestCase
{
    private static function src(string $rel): string
    {
        $p = dirname(__DIR__, 3) . '/' . $rel;
        self::assertFileExists($p, "فایل مورد انتظار وجود ندارد: {$rel}");
        return (string)file_get_contents($p);
    }

    /** تکهٔ سورس متد بدون خطوط کامنت — الگوی Behav1PinningTest */
    private static function method(string $src, string $name, int $len = 1800): string
    {
        $pos = (int)strpos($src, "function {$name}");
        self::assertNotFalse($pos, "متد {$name} پیدا نشد");
        $chunk = substr($src, $pos, $len);
        $codeLines = [];
        foreach (explode("\n", $chunk) as $line) {
            $t = trim($line);
            if ($t === '' || str_starts_with($t, '//') || str_starts_with($t, '*') || str_starts_with($t, '/*')) {
                continue;
            }
            $codeLines[] = $line;
        }
        return implode("\n", $codeLines);
    }

    // ── MOBCTR-01: تک‌منبع فایل مدرک ──────────────────────────────

    /** @test */
    public function mobctr01_proof_file_logic_is_single_sourced(): void
    {
        // سرویس جدید وجود دارد و هر دو کانال از آن می‌خوانند
        $svc = self::src('app/Services/CustomTask/CustomTaskProofFileService.php');
        $this->assertStringContainsString('final class CustomTaskProofFileService', $svc);
        $this->assertStringContainsString("uploadPrivateDocument(\$file, 'task-proofs', ['application/pdf']", $svc);
        $this->assertStringContainsString('uploadPrivateDocument($file, \'task-proofs\', self::VIDEO_ALLOWED_MIMES, self::VIDEO_MAX_BYTES', $svc);
        $this->assertStringContainsString('upload($file, \'task-proofs\', self::IMAGE_ALLOWED, self::IMAGE_MAX_BYTES', $svc);

        // کنترلر وب: دیگر متد خصوصی storeProofFile ندارد و از سرویس می‌خواند
        $web = self::fileCode(self::src('app/Controllers/User/CustomTaskController.php'));
        $this->assertStringNotContainsString('private function storeProofFile', $web, 'منطق فایل باید از کنترلر وب رفته باشد');
        $this->assertStringContainsString('$this->proofFileService->store($_FILES[\'proof_file\'], $proofType)', $web);
        $this->assertStringContainsString('$this->proofFileService->delete($uploadedPath)', $web);

        // کنترلر API: همان سرویس (نه کپی)
        $api = self::fileCode(self::src('app/Controllers/Api/CustomTaskApiController.php'));
        $this->assertStringContainsString('$this->proofFileService->store($proofFile, $proofType)', $api);
        $this->assertStringContainsString('private CustomTaskProofFileService $proofFileService', $api);
    }

    // ── A3-N3: proof_type در همهٔ پاسخ‌ها + همهٔ کانال‌ها ─────────

    /** @test */
    public function a3n3_proof_type_in_every_response_and_all_channels(): void
    {
        $api = self::src('app/Controllers/Api/CustomTaskApiController.php');

        // tasks: proof_type + proof_description در ردیف‌ها
        $tasks = self::method($api, 'tasks', 3000);
        $this->assertStringContainsString("'proof_type'        => CustomTaskProofSchema::normalizeType", $tasks);
        $this->assertStringContainsString("'proof_description' => mb_substr", $tasks);

        // mySubmissions: proof_type از ستون join شده
        $my = self::method($api, 'mySubmissions', 2600);
        $this->assertStringContainsString("task_proof_type", $my);

        // detail: proof_type + proof_description + proof_code
        $show = self::method($api, 'showSubmission', 2400);
        $this->assertStringContainsString("'proof_code' => str_value(\$submission->proof_code", $show);
        $this->assertStringContainsString("'proof_type'        => CustomTaskProofSchema::normalizeType", $show);

        // start: enrich با proof_type تسک
        $start = self::method($api, 'start', 2600);
        $this->assertStringContainsString("\$data['proof_type'] = CustomTaskProofSchema::normalizeType", $start);
        $this->assertStringContainsString("\$data['proof_description'] = mb_substr", $start);

        // submit: نوع سرور-محاسبه از ردیف (هرگز از body)
        $submit = self::method($api, 'submitProof', 9000);
        $this->assertStringContainsString('submission_findForProof($submissionId, $userId)', $submit);
        $this->assertStringContainsString("CustomTaskProofSchema::normalizeType(str_value(\$submission->proof_type ?? 'text'))", $submit);
        // کانال کد و متن و فایل همگی نگاشت می‌شوند
        $this->assertStringContainsString("body['proof_text'] ?? \$body['note']", $submit);
        $this->assertStringContainsString("body['proof_code'] ?? \$body['code']", $submit);
        $this->assertStringContainsString("->file('proof_file')", $submit);
        // رشته‌های فایل JSON هرگز خوانده نمی‌شوند (S17-2)
        $this->assertStringNotContainsString("body['proof_file']", $submit);
    }

    /** @test */
    public function a3n3_models_expose_proof_type_for_api_lists(): void
    {
        $sm = self::src('app/Models/CustomTaskSubmissionModel.php');
        // mySubmissions: ستون join شده
        $this->assertStringContainsString('a.proof_type AS task_proof_type', $sm);
        // detail (submission_find): proof_description هم برای API
        $this->assertStringContainsString('ct.proof_description', $sm);
    }

    // ── A1-N15: URL برای تسک متنی اجباری نیست ────────────────────

    /** @test */
    public function a1n15_url_is_not_unconditionally_required(): void
    {
        $api = self::src('app/Controllers/Api/CustomTaskApiController.php');
        $submit = self::method($api, 'submitProof', 9000);
        // شرط الزام URL فقط برای نوع url است (نه همه‌جا)
        $this->assertStringContainsString("} elseif (\$proofType === 'url') {", $submit);
        $this->assertStringContainsString("if (\$proofLink !== '') {", $submit, 'URL ارسال‌شده اعتبارسنجی می‌شود (validate-if-present)');
        // قدیم: الزام بی‌قیدوشرط — نباید برگردد
        $this->assertStringNotContainsString("if (\$proofLink === '' || !filter_var", $submit);
    }

    // ── A1-N8: data پاسخ submit = کلیدهای واقعی جاب ──────────────

    /** @test */
    public function a1n8_submit_response_carries_real_job_keys(): void
    {
        $api = self::src('app/Controllers/Api/CustomTaskApiController.php');
        $submit = self::method($api, 'submitProof', 9500);
        $this->assertStringContainsString("'auto_approve_info' => str_value(\$result['auto_approve_info'] ?? '')", $submit);
        $this->assertStringContainsString("'status'            => 'submitted'", $submit);
        // قدیم: $result['data'] که جاب هرگز برنمی‌گرداند — نباید برگردد
        $this->assertStringNotContainsString("is_array(\$result['data'] ?? null)", $submit);
    }

    // ── A3-N7: meta صفحه‌بندی در هر دو لیست ───────────────────────

    /** @test */
    public function a3n7_both_lists_carry_pagination_meta(): void
    {
        $api = self::src('app/Controllers/Api/CustomTaskApiController.php');
        $tasks = self::method($api, 'tasks', 3200);
        $this->assertStringContainsString("'meta'    => \$this->paginationMeta(", $tasks);
        $this->assertStringContainsString('countStartableCustomTasks($userId)', $tasks, 'شمارندهٔ هم‌شرط لیست (نه همهٔ فعال‌ها)');

        $my = self::method($api, 'mySubmissions', 2800);
        $this->assertStringContainsString("'meta'    => \$this->paginationMeta(", $my);
        $this->assertStringContainsString('submission_countByWorkerWithTask($userId)', $my);

        // هلپر مشترک در Base — paginated موجود هم از همان می‌خواند
        $base = self::src('app/Controllers/Api/BaseApiController.php');
        $this->assertStringContainsString('protected function paginationMeta(', $base);
        $this->assertStringContainsString("'meta'    => \$this->paginationMeta(\$total, \$page, \$perPage),", $base);

        // شمارندهٔ هم‌شرط در مدل: همان حذفِ تسک‌های شروع‌شدهٔ لیست
        $ads = self::src('app/Models/Ads.php');
        $count = self::method($ads, 'countStartableCustomTasks', 1600);
        $this->assertStringContainsString('startedCustomTaskIds($workerId)', $count);
        $this->assertStringContainsString("whereNotIn('id', \$startedIds)", $count);
    }

    // ── سند قرارداد ──────────────────────────────────────────────

    /** @test */
    public function mobile_api_guide_documents_custom_tasks_contract(): void
    {
        $doc = self::src('docs/MOBILE-API-GUIDE-fa.md');
        $this->assertStringContainsString('## ۶. تسک‌های سفارشی', $doc);
        $this->assertStringContainsString('`GET /custom-tasks/tasks', $doc);
        $this->assertStringContainsString('`POST /custom-tasks/submissions/{id}/proof`', $doc);
        $this->assertStringContainsString('auto_approve_info', $doc);
        $this->assertStringContainsString('multipart `proof_file`', $doc);
        $this->assertStringContainsString('POST /api/v1/custom-tasks/submissions/{id}/proof (customtask.write)', $doc);
    }

    /** سورسِ کل فایل بدون خطوط کامنت — هم‌الگوی Behav1PinningTest */
    private static function fileCode(string $src): string
    {
        $codeLines = [];
        foreach (explode("\n", $src) as $line) {
            $t = trim($line);
            if ($t === '' || str_starts_with($t, '//') || str_starts_with($t, '*') || str_starts_with($t, '/*')) {
                continue;
            }
            $codeLines[] = $line;
        }
        return implode("\n", $codeLines);
    }
}
