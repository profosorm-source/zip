<?php

declare(strict_types=1);

namespace Tests\Unit\Pin;

use PHPUnit\Framework\TestCase;

/**
 * 🧾 FIX-M22-CLOSE — پین‌های ساختاری بچ بستن بخش ۲۲:
 *  ۱) فایل‌های زنجیرهٔ مردهٔ F2 (ReconcilePaymentsJob + ProcessPaymentCallbackJob)
 *     حذف شده‌اند و نام کلاس‌ها در کد زنده (app/، config/، routes/) غایب‌اند.
 *  ۲) زامبی‌های storage/cron حذف شده‌اند (cron_alert_checker با دو کلاس ناموجود
 *     + دوقلوی email_queue_cron) و email_queue.php (نسخهٔ گارد‌دار) زنده است.
 *  ۳) روت intake گزارش تخلف (/custom-tasks/{id}/report) ثبت و کنترلر/ویو سیم‌کشی
 *     شده‌اند (D2-N8).
 *  ۴) قاعدهٔ مشروط proof_text (min:10 فقط برای نوع text) در هر دو فراخوان
 *     (کنترلر وب + SubmitProofJob) با proof_type سرور-محاسبه تأمین می‌شود (D2-edge).
 *  ۵) E2E کهنه به روت حذف‌شدهٔ /custom-tasks/review دیگر ارجاع نمی‌دهد.
 *
 * @group architecture
 */
final class M22ClosePinningTest extends TestCase
{
    private static function repoPath(string $rel): string
    {
        return dirname(__DIR__, 3) . '/' . $rel;
    }

    private static function src(string $rel): string
    {
        $src = file_get_contents(self::repoPath($rel));
        self::assertIsString($src);
        return $src;
    }

    /** @test */
    public function f2_dead_chain_files_are_deleted(): void
    {
        // PHPUnit 8.5 — assertFileDoesNotExist ندارد
        $this->assertFalse(file_exists(self::repoPath('app/Jobs/Payment/ReconcilePaymentsJob.php')), 'جاب صفر-دیسپچر ReconcilePaymentsJob باید حذف شود');
        $this->assertFalse(file_exists(self::repoPath('app/Jobs/Payment/ProcessPaymentCallbackJob.php')), 'تنها فراخوان همگامِ آن (خودش صفر-دیسپچر) باید حذف شود');
        $this->assertFalse(class_exists(\App\Jobs\Payment\ReconcilePaymentsJob::class, false), 'کلاس ReconcilePaymentsJob نباید قابل autoload باشد');
        $this->assertFalse(class_exists(\App\Jobs\Payment\ProcessPaymentCallbackJob::class, false), 'کلاس ProcessPaymentCallbackJob نباید قابل autoload باشد');
    }

    /** @test */
    public function f2_class_names_absent_from_live_code(): void
    {
        // اسکن متنی کد زنده (بدون vendor/docs/مانیفست‌ها) — نام کلاس‌ها فقط در
        // کامنت‌های توضیحیِ تاریخچه مجازند، نه در کد اجرایی. برای سادگی و صراحت،
        // وجودشان در فایل‌های اجرایی پین‌شدهٔ زیر چک می‌شود (قابل اطمینان‌ترین
        // نقاطی که قبلاً ارجاع داشتند).
        foreach (['config/queue.php', 'routes/api.php', 'routes/user.php'] as $rel) {
            $src = self::src($rel);
            // ارجاع کلاسِ زنده (new/make/static) ممنوع — کامنت تاریخچه آزاد است؛
            // الگوی FQCN با بک‌اسلش فقط در رشتهٔ کلاس‌ رخ می‌دهد:
            $this->assertStringNotContainsString('new \App\Jobs\Payment\ReconcilePaymentsJob', $src);
            $this->assertStringNotContainsString('App\Jobs\Payment\ProcessPaymentCallbackJob::class', $src);
        }
        // تست انعکاس S18p6 نباید فایل حذف‌شده را باز کند (Fatal)
        $s18 = self::src('tests/Unit/Listeners/S18p6NotificationUnityTest.php');
        $this->assertStringNotContainsString('ReflectionClass(\App\Jobs\Payment\ReconcilePaymentsJob::class', $s18);
    }

    /** @test */
    public function cron_zombies_deleted_and_guarded_email_queue_kept(): void
    {
        $this->assertFalse(file_exists(self::repoPath('storage/cron/cron_alert_checker.php')), 'کرون زامبی (LogNotificationService/ErrorLogService ناموجود) باید حذف شود — الگوی T22-15');
        $this->assertFalse(file_exists(self::repoPath('storage/cron/email_queue_cron.php')), 'دوقلوی *_cron الگوی تکراری T22-15 — نسخهٔ گارددار email_queue.php زنده می‌ماند');
        $this->assertTrue(file_exists(self::repoPath('storage/cron/email_queue.php')), 'email_queue.php (CLI-guard) باید بماند');
        $eq = self::src('storage/cron/email_queue.php');
        $this->assertStringContainsString("php_sapi_name() !== 'cli'", $eq, 'گارد CLI باید بماند');
        // بقیهٔ اسکریپت‌های بازمانده نباید به کلاس ناموجود ارجاع دهند
        foreach (glob(self::repoPath('storage/cron/*.php')) ?: [] as $cronFile) {
            $src = (string)file_get_contents($cronFile);
            foreach (['LogNotificationService', 'ErrorLogService', 'TaskRecheckService', 'TaskExecution'] as $dead) {
                $this->assertStringNotContainsString($dead, $src, basename($cronFile) . ' نباید به کلاس ناموجود ' . $dead . ' ارجاع دهد');
            }
        }
    }

    /** @test */
    public function report_intake_route_controller_validator_wired(): void
    {
        $routes = self::src('routes/user.php');
        $this->assertStringContainsString("'/custom-tasks/{id}/report'", $routes);
        $this->assertStringContainsString("[CustomTaskController::class, 'report']", $routes);

        $controller = self::src('app/Controllers/User/CustomTaskController.php');
        $this->assertStringContainsString('public function report(): void', $controller);
        $this->assertStringContainsString('CreateCustomTaskReportRequest', $controller);

        $this->assertTrue(file_exists(self::repoPath('app/Validators/Requests/CreateCustomTaskReportRequest.php')));
        $validator = self::src('app/Validators/Requests/CreateCustomTaskReportRequest.php');
        $this->assertStringContainsString('in:spam,fraud,inappropriate,misleading,other', $validator, 'allowlist دلیل باید با برچسب‌های پنل ادمین یکی باشد');

        // ویو: فرم گزارش فقط برای غیر-owner (canReport)
        $view = self::src('views/user/custom-tasks/show.php');
        $this->assertStringContainsString("url('/custom-tasks/' . \$taskId . '/report')", $view);
        $this->assertStringContainsString('canReport', $view);

        // سرویس: گاردهای قرینهٔ reportOrder اینفلوئنسر
        $service = self::src('app/Services/CustomTask/CustomTaskExecutorService.php');
        $this->assertStringContainsString('public function reportTask(', $service);
        $this->assertStringContainsString('hasPendingTaskReport', $service);
        $this->assertStringContainsString("INTERVAL 24 HOUR", $service);
        $this->assertStringContainsString("'task_type'   => 'custom_task'", $service);
    }

    /** @test */
    public function conditional_proof_text_min_rule_wired_in_both_callers(): void
    {
        $validator = self::src('app/Validators/Requests/SubmitCustomTaskProofRequest.php');
        $this->assertStringContainsString("(\$this->data['proof_type'] ?? 'text')", $validator, 'نوع مدرک باید از payload سرور-محاسبه خوانده شود');
        $this->assertStringContainsString("'nullable|string|min:10|max:2000'", $validator, 'قاعدهٔ کامل برای نوع text باید بماند');
        $this->assertStringContainsString("'nullable|string|max:2000'", $validator, 'قاعدهٔ بدون min برای انواع غیرمتنی');

        $controller = self::src('app/Controllers/User/CustomTaskController.php');
        $this->assertStringContainsString("\$payload['proof_type'] = \$proofType;", $controller, 'کنترلر وب باید نوع سرور-محاسبه را در payload بنویسد');

        $job = self::src('app/Jobs/CustomTask/SubmitProofJob.php');
        $this->assertStringContainsString("\$proofData['proof_type'] = \$proofType;", $job, 'جاب (مسیر API) هم باید همین را بنویسد');
    }

    /** @test */
    public function stale_e2e_review_route_reference_removed(): void
    {
        $spec = self::src('tests/E2E/chortke_full_30_modules.spec.js');
        $this->assertStringNotContainsString("'/custom-tasks/review'", $spec, 'روت حذف‌شدهٔ review نباید در E2E بماند (FIX-M22-21 حذفش کرد)');
    }
}
