<?php

declare(strict_types=1);

namespace Tests\Unit\Data;

use App\Data\CommonPasswords;
use PHPUnit\Framework\TestCase;

/**
 * FIX-S20-C7 — تست قفل‌کنندهٔ ابزار Bloom Filter در CommonPasswords.
 *
 * تصمیم کاربر (C-S20-7): متدهای Bloom نگه داشته می‌شوند (ابزار آینده)، اما با
 * بهداشت استاندارد: باگ خواندن بایت (cast به‌جای ord) رفع شده و قرارداد
 * «پیش‌فیلتر + تأیید دقیق» است — یعنی معناشناسی isCommonBloomFilter() باید
 * دقیقاً برابر isCommon() باشد (بدون false-negative و بدون false-positive).
 */
final class CommonPasswordsBloomTest extends TestCase
{
    /** نمونه‌ای پوشاننده: اعضای لیست، الگوهای عددی/کیبوردی، پسوردهای قوی */
    private const SAMPLES = [
        '123456', 'password', 'Password1', 'letmein', 'qwerty123', 'admin123',
        'abc123', '111111', '1234567890', 'qwerty', 'asdfgh', '1qaz2wsx',
        '1234567', '987654', 'Tr0ub4dour&3x92!', 'x7#Kp2$vLq9!', 'درست-است-1',
        'correct horse battery staple',
    ];

    public function test_bloom_semantics_are_equivalent_to_is_common(): void
    {
        foreach (self::SAMPLES as $password) {
            $this->assertSame(
                CommonPasswords::isCommon($password),
                CommonPasswords::isCommonBloomFilter($password),
                "Bloom/Exact mismatch for: {$password}"
            );
        }
    }

    public function test_bloom_path_identifies_listed_passwords(): void
    {
        // setupBloomFilterInCache اگر cache موجود نباشد no-op امن است؛ در هر دو
        // حالت قرارداد معناشناسی برابر باید برقرار بماند.
        CommonPasswords::setupBloomFilterInCache();

        $this->assertTrue(CommonPasswords::isCommonBloomFilter('123456'));
        $this->assertFalse(CommonPasswords::isCommonBloomFilter('Tr0ub4dour&3x92!'));
    }

    public function test_setup_returns_status_array_and_is_web_safe(): void
    {
        $status = CommonPasswords::setupBloomFilterInCache();
        $this->assertIsArray($status);
        $this->assertArrayHasKey('status', $status);
        $this->assertContains($status['status'], ['cached', 'no_cache'], 'وضعیت باید cached یا no_cache باشد');
        if (($status['status'] ?? '') === 'cached') {
            $this->assertArrayHasKey('usage', $status);
        }
    }

    public function test_benchmark_methods_returns_both_strategies(): void
    {
        $results = CommonPasswords::benchmarkMethods('123456');
        $this->assertSame(['Array (Cached)', 'Bloom Filter'], array_keys($results));
        foreach ($results as $timing) {
            $this->assertIsString($timing);
            $this->assertStringEndsWith('ms', $timing);
        }
    }

    public function test_count_and_suggest_contracts_hold(): void
    {
        $this->assertGreaterThan(0, CommonPasswords::count());
        $suggested = CommonPasswords::suggest();
        $this->assertSame(1, preg_match('/^[A-Za-z]\w{2,}[\d]{2}[A-Za-z]\w{2,}[!@#$%&*]$/', $suggested), 'قالب پیشنهاد پسورد تغییر کرده است');
    }
}
