<?php

declare(strict_types=1);

namespace Tests\Unit\Security;

use PHPUnit\Framework\TestCase;

final class CsrfJavaScriptContractTest extends TestCase
{
    /** @test */
    public function admin_scripts_use_the_canonical_csrf_body_field(): void
    {
        $base = dirname(__DIR__, 3) . '/public/assets/js/admin';
        $scripts = [
            'usersindex.js',
            'userscreate.js',
            'usersedit.js',
            'rolesindex.js',
            'levelsindex.js',
            'kyc.js',
            'customtasks.js',
        ];

        foreach ($scripts as $script) {
            $source = file_get_contents($base . '/' . $script);
            self::assertIsString($source, $script . ' could not be read');
            self::assertSame(
                0,
                preg_match('/(?:["\']csrf_token["\']|\bcsrf_token\s*:|\b_token\s*:|data\._token\b)/', $source),
                $script . ' still sends a legacy CSRF field'
            );
        }
    }
}
