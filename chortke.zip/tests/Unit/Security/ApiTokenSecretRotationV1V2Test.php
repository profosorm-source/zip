<?php

declare(strict_types=1);

namespace Tests\Unit\Security;

use PHPUnit\Framework\TestCase;
use App\Middleware\ApiAuthMiddleware;
use Mockery as m;

/**
 * 🛡️ FIX-SECRETROT — بستهٔ چرخش رمز توکن API (تصمیم بازِ V1/V2)
 *
 * پوشش هدف:
 *  1) قرارداد نرمال‌ساز کانونی normalize_secret_version(): «1»/«v1»/«V1»/« v1 »
 *     همه ⇒ 'v1' (و همین‌طور v2)؛ مقادیر نامعتبر/خالی ⇒ پیش‌فرض fail-safe 'v2'.
 *     (ریشه: .env.example قدیمی CURRENT_VERSION=1 بدون «v» داشت و config خام
 *     پاسش می‌داد ⇒ کلید secrets.1 ناموجود ⇒ ApiToken::create توکن با برچسب
 *     نسخهٔ یتیم می‌ساخت که هرگز validate نمی‌شد.)
 *  2) پین آرتیفکتِ .env تحویلی: V1/V2 متمایز hex-64، CURRENT_VERSION=v1 و
 *     پیوستگی (V2 == legacy) — یعنی چرخشِ «فلیپ» واقعاً اعمال شده.
 *  3) اثبات zero-invalidation: توکنِ برچسب-v2 (هش‌شده با رمز قدیمی) پس از
 *     چرخش از مسیر V2 پیدا می‌شود و در همان اولین استفاده به v1/رمز جدید
 *     بازهاش و برچسب‌گذاری می‌شود (ApiAuthMiddleware::validateTokenWithRotation).
 */
final class ApiTokenSecretRotationV1V2Test extends TestCase
{
    /** رمز «جدید» (نسخهٔ جاری بعد از چرخش) — فقط برای این تست */
    private const NEW_SECRET = '1111111111111111111111111111111111111111111111111111111111111111';
    /** رمز «قدیمی» (نسخهٔ v2 — توکن‌های موجود) */
    private const OLD_SECRET = '2222222222222222222222222222222222222222222222222222222222222222';

    /** @var array<string, mixed>snapshot کانفیگ برای بازگرداندن در tearDown */
    private array $configSnapshot = [];

    protected function setUp(): void
    {
        parent::setUp();
        foreach (['security.api.secrets', 'security.api.current_secret_version'] as $key) {
            $this->configSnapshot[$key] = config($key);
        }
    }

    protected function tearDown(): void
    {
        foreach ($this->configSnapshot as $key => $value) {
            config_set($key, $value);
        }
        m::close();
        parent::tearDown();
    }

    /** @test @dataProvider provideRawVersions */
    public function normalize_secret_version_maps_all_forms_canonically(?string $raw, string $expected): void
    {
        self::assertSame($expected, normalize_secret_version($raw), 'raw=' . var_export($raw, true));
    }

    /** @return list<list<mixed>> */
    public function provideRawVersions(): array
    {
        return [
            ['v1', 'v1'],
            ['V1', 'v1'],
            ['1',  'v1'],
            [' v1 ', 'v1'],
            ['v2', 'v2'],
            ['V2', 'v2'],
            ['2',  'v2'],
            [' v2 ', 'v2'],
            // fail-safe: خارج از دو خانهٔ سیکریت ⇒ پیش‌فرض تاریخی config
            ['',   'v2'],
            [null, 'v2'],
            ['v3', 'v2'],
            ['0',  'v2'],
            ['12', 'v2'],
            ['vx', 'v2'],
            ['garbage', 'v2'],
            // پیش‌فرض قابل‌تحمیل
            [null, 'v2'],
        ];
    }

    /** @test */
    public function normalize_secret_version_honors_explicit_default(): void
    {
        self::assertSame('v1', normalize_secret_version(null, 'v1'));
        self::assertSame('v1', normalize_secret_version('', 'v1'));
        self::assertSame('v1', normalize_secret_version('junk', 'v1'));
        // مقدار معتبر بر پیش‌فرض اولویت دارد
        self::assertSame('v2', normalize_secret_version('2', 'v1'));
    }

    /** @test */
    public function config_current_secret_version_is_never_a_bare_digit(): void
    {
        // قرارداد مصرف‌کننده‌ها (ApiToken/ApiAuthMiddleware): مقدار config باید
        // همیشه یکی از کلیدهای واقعی secrets (v1/v2) باشد — هرگز '1'/'2' لخت.
        $current = config('security.api.current_secret_version');
        self::assertIsString($current);
        self::assertContains($current, ['v1', 'v2'], 'current_secret_version باید کانونی‌سازی‌شده باشد، نه مقدار خام env');

        // و کلیدِ نسخهٔ جاری واقعاً در secrets خانه دارد
        $secrets = config('security.api.secrets');
        self::assertIsArray($secrets);
        self::assertArrayHasKey($current, $secrets);
    }

    /**
     * @test
     * پین آرتیفکت: چرخشِ «فلیپ» در .env تحویلی واقعاً اعمال شده باشد.
     * اگر .env در محیط اجرا وجود نداشته باشد (مثلاً فقط .env.local)، صادقانه skip.
     */
    public function shipped_env_artifact_has_the_flip_rotation_applied(): void
    {
        $envPath = dirname(__DIR__, 3) . '/.env';
        if (!is_file($envPath)) {
            self::markTestSkipped('.env در این محیط وجود ندارد — پین آرتیفکت فقط با فایل تحویلی معنا دارد');
        }
        $parsed = parse_ini_file($envPath, false, INI_SCANNER_RAW);
        self::assertIsArray($parsed, '.env باید قابل‌parse باشد (همان مسیر bootstrap)');

        $v1 = (string)($parsed['SECURITY_API_TOKEN_SECRET_V1'] ?? '');
        $v2 = (string)($parsed['SECURITY_API_TOKEN_SECRET_V2'] ?? '');
        $legacy = (string)($parsed['SECURITY_API_TOKEN_SECRET'] ?? '');
        $currentRaw = $parsed['SECURITY_API_TOKEN_CURRENT_VERSION'] ?? null;

        // ۱) هر دو نسخه: hex-64 کامل
        self::assertRegExp('/^[a-f0-9]{64}$/', $v1, 'V1 باید hex-64 باشد');
        self::assertRegExp('/^[a-f0-9]{64}$/', $v2, 'V2 باید hex-64 باشد');

        // ۲) متمایز — جوهرِ رفع هشدار V1===V2
        self::assertNotSame($v1, $v2, 'V1 و V2 نباید برابر باشند (والدِ همان هشدار بوت)');

        // ۳) نسخهٔ جاری = v1 کانونی‌سازی‌شده
        self::assertSame('v1', normalize_secret_version(is_string($currentRaw) ? $currentRaw : null));

        // ۴) پیوستگی zero-invalidation: V2 همان رمز legacy است (توکن‌های موجود
        //    برچسب-v2 با همین مقدار هش شده‌اند) و V1 واقعاً رمز تازه است.
        self::assertSame($legacy, $v2, 'V2 باید رمز قدیمی باشد تا توکن‌های موجود اعتبار بگیرند');
        self::assertNotSame($legacy, $v1, 'V1 باید رمز جدید باشد، نه تکرارِ legacy');
    }

    /**
     * @test
     * اثبات zero-invalidation + مهاجرت خودکار:
     *   توکنی که با رمز قدیمی (V2) هش و با برچسب v2 ثبت شده، پس از چرخش
     *   (current=v1 با رمز جدید) همچنان از مسیر V2 پیدا می‌شود؛ سپس در همان
     *   اولین استفاده به هشِ v1/رمز جدید مهاجرت می‌کند (UPDATE برچسب+هش).
     */
    public function old_version_token_survives_flip_rotation_and_migrates_on_first_use(): void
    {
        $rawToken = 'plain-api-token-' . bin2hex(random_bytes(16));
        $newSecret = self::NEW_SECRET;
        $oldSecret = self::OLD_SECRET;

        config_set('security.api.secrets', ['v1' => $newSecret, 'v2' => $oldSecret]);
        config_set('security.api.current_secret_version', 'v1');

        $db = m::mock('Core\Database');
        $rateLimiter = m::mock('Core\RateLimiter');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $tokenRow = (object)[
            'id' => 7, 'username' => 'u7', 'full_name' => 'U Seven', 'email' => 'u7@example.test',
            'mobile' => null, 'referral_code' => 'RC7', 'role' => 'user', 'status' => 'active',
            'email_verified_at' => '2026-01-01 00:00:00', 'kyc_status' => 'none', 'level_slug' => 'basic',
            'avatar' => null, 'created_at' => '2026-01-01 00:00:00', 'two_factor_enabled' => 0,
            'token_id' => 42, 'scopes' => 'read', 'token_expires_at' => null,
            'token_type' => 'personal', 'refresh_expires_at' => null,
        ];

        $selects = [];
        $db->shouldReceive('fetch')->andReturnUsing(
            function ($query, $params = []) use (&$selects, $tokenRow, $newSecret, $oldSecret, $rawToken) {
                $query = (string)$query;
                if (strpos($query, 'SHOW COLUMNS') !== false) {
                    return false; // secret_version_expires_at پشتیبانی نمی‌شود
                }
                if (strpos($query, 'FROM api_tokens') === false) {
                    return null;
                }
                $version = (string)($params[1] ?? '');
                $selects[$version] = [ (string)($params[0] ?? ''), $query ];
                if ($version === 'v1') {
                    // توکن هنوز در نسخهٔ جدید ثبت نشده — جستجوی اول باید miss شود
                    return null;
                }
                // مسیر نجات: hash با رمز قدیمی + برچسب v2 ⇒ پیدا می‌شود
                return hash_equals(hash_hmac('sha256', $rawToken, $oldSecret), (string)$params[0])
                    ? $tokenRow
                    : null;
            }
        );
        $db->shouldReceive('fetchColumn')->andReturn(false);

        $capturedUpdate = null;
        $db->shouldReceive('query')->once()->andReturnUsing(
            function ($sql, $params = []) use (&$capturedUpdate) {
                $capturedUpdate = [(string)$sql, $params];
                return true;
            }
        );

        $middleware = new ApiAuthMiddleware($db, $rateLimiter, $logger, null);

        $ref = new \ReflectionMethod(ApiAuthMiddleware::class, 'validateTokenWithRotation');
        $ref->setAccessible(true);
        $user = $ref->invoke($middleware, $rawToken, 0);

        // ۱) توکنِ قدیمی باطل نشده — از مسیر V2 احراز شد
        self::assertNotNull($user, 'توکن v2 پس از چرخش باید از مسیر V2 احراز شود (zero-invalidation)');
        self::assertSame(42, (int)$user->token_id);

        // ۲) جستجوی نسخهٔ جاری (v1) واقعاً انجام شد و با هشِ رمزِ جدید miss خورد
        self::assertArrayHasKey('v1', $selects, 'lookup باید اول با نسخهٔ جاری v1 امتحان شود');
        self::assertSame(hash_hmac('sha256', $rawToken, $newSecret), $selects['v1'][0]);
        self::assertStringContainsString("at.secret_version = ?", $selects['v1'][1]);

        // ۳) جستجوی v2 با هشِ رمز قدیمی match شد (همان ردیف بالا برگشت)
        self::assertArrayHasKey('v2', $selects);
        self::assertSame(hash_hmac('sha256', $rawToken, $oldSecret), $selects['v2'][0]);

        // ۴) مهاجرت خودکار: UPDATE با هشِ رمز جدید + برچسب v1 + همان token_id
        self::assertIsArray($capturedUpdate, 'UPDATE مهاجرت باید اجرا شود');
        [$updateSql, $updateParams] = $capturedUpdate;
        self::assertStringContainsString('UPDATE api_tokens SET token = ?, secret_version = ?', $updateSql);
        self::assertSame(hash_hmac('sha256', $rawToken, $newSecret), $updateParams[0], 'هش جدید باید با رمز V1 ساخته شود');
        self::assertSame('v1', $updateParams[1], 'برچسب نسخه باید به v1 برگردد');
        self::assertSame(42, (int)$updateParams[2]);
    }

    /**
     * @test
     * قرارداد منفی: توکنِ ساخته‌شده با رمز قدیمی وقتی رمزِ آن نسخه حذف/عوض شود،
     * دیگر پیدا نمی‌شود — یعنی در چرخشِ درست، حذفِ خانهٔ رمز قدیمی «عمداً» باطل‌کننده
     * است و پین قبلی (باقی‌ماندن V2=رمز قدیمی) ضروری است، نه سلیقه.
     */
    public function dropping_old_version_secret_is_intentionally_invalidating(): void
    {
        $rawToken = 'plain-api-token-' . bin2hex(random_bytes(16));
        $newSecret = self::NEW_SECRET;

        // فقط نسخهٔ جاری تعریف شده — خانهٔ v2 نیست
        config_set('security.api.secrets', ['v1' => $newSecret, 'v2' => '']);
        config_set('security.api.current_secret_version', 'v1');

        $db = m::mock('Core\Database');
        $rateLimiter = m::mock('Core\RateLimiter');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $db->shouldReceive('fetch')->andReturnUsing(function ($query, $params = []) {
            if (strpos((string)$query, 'SHOW COLUMNS') !== false) {
                return false;
            }
            return null; // هیچ توکنی پیدا نمی‌شود
        });
        $db->shouldReceive('fetchColumn')->andReturn(false);
        $db->shouldReceive('query')->never(); // نه مهاجرت، نه هیچ UPDATEای

        $middleware = new ApiAuthMiddleware($db, $rateLimiter, $logger, null);
        $ref = new \ReflectionMethod(ApiAuthMiddleware::class, 'validateTokenWithRotation');
        $ref->setAccessible(true);

        self::assertNull($ref->invoke($middleware, $rawToken, 0));
    }
}
