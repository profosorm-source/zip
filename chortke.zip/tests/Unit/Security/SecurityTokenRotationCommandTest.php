<?php

declare(strict_types=1);

namespace Tests\Unit\Security;

use App\Commands\SecurityTokenRotationCommand;
use App\Models\ApiToken;
use App\Models\AuditTrail;
use App\Contracts\LoggerInterface;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SECRETROT-4 — بستهٔ تکمیل چرخش رمز (توکن‌های هرگز-استفاده‌نشدهٔ نسخهٔ قدیمی).
 *
 * پوشش هدف:
 *  1) مدل ApiToken:
 *     - getSecretVersionRotationStats(): نگاشت درستِ تجمیع DB به شکل تایپ‌شده؛
 *     - revokeByStaleSecretVersion(): SQL دامنه‌دار به تفکیک فیلتر استفاده
 *       (never_used/used/all)، پارامترها، شرط NULL، و دفاع برچسب/فیلتر نامعتبر؛
 *     - listStaleSecretVersionRows(): JOIN کاربر + LIMIT.
 *  2) فرمان security:token-rotation:
 *     - گزارش: خروج ۲ با ردیف کهنهٔ فعال / خروج ۰ تمیز؛ تفکیک نسخهٔ یتیم
 *       (رمز ندارد در config)؛ هشدار V1===V2 (چرخش غیرواقعی)؛
 *     - ابطال: گارد production (بدون --confirm رد می‌شود، بدون هیچ UPDATEای)؛
 *       dry-run بدون اثر جانبی؛ ابطال واقعی با دامنهٔ درست (نسخهٔ جاری
 *       هرگز هدف نیست)، دلیل rotation_cleanup، ورودی audit_trail، و حکم
 *       پس از پاکسازی از آمارِ تازه.
 */
final class SecurityTokenRotationCommandTest extends TestCase
{
    private const NEW_SECRET = '1111111111111111111111111111111111111111111111111111111111111111';
    private const OLD_SECRET = '2222222222222222222222222222222222222222222222222222222222222222';

    /** @var array<string, mixed> snapshot کانفیگ برای بازگرداندن در tearDown */
    private array $configSnapshot = [];

    /** @var Database&\Mockery\MockInterface */
    private Database $db;

    /** @var ApiToken&\Mockery\MockInterface */
    private ApiToken $apiToken;

    /** @var AuditTrail&\Mockery\MockInterface */
    private AuditTrail $auditTrail;

    /** @var LoggerInterface&\Mockery\MockInterface */
    private LoggerInterface $logger;

    protected function setUp(): void
    {
        parent::setUp();
        foreach (['security.api.secrets', 'security.api.current_secret_version', 'app.env'] as $key) {
            $this->configSnapshot[$key] = config($key);
        }
        $this->db = m::mock(Database::class);
        $this->apiToken = m::mock(ApiToken::class);
        $this->auditTrail = m::mock(AuditTrail::class);
        $this->logger = m::mock(LoggerInterface::class);
        $this->logger->shouldIgnoreMissing();
    }

    protected function tearDown(): void
    {
        foreach ($this->configSnapshot as $key => $value) {
            config_set($key, $value);
        }
        m::close();
        parent::tearDown();
    }

    /** چرخشِ سالم: جاری v1 با رمز جدید، قدیمی v2 با رمز قدیمی */
    private function setRotatedConfig(): void
    {
        config_set('security.api.secrets', ['v1' => self::NEW_SECRET, 'v2' => self::OLD_SECRET]);
        config_set('security.api.current_secret_version', 'v1');
        config_set('app.env', 'development');
    }

    /**
     * @param array<string, array{total:int, live:int, live_never_used:int, live_used_before:int, live_expired:int, live_with_refresh:int}> $access
     * @param array<string, int> $refresh
     * @return array{access: array<string, array{total:int, live:int, live_never_used:int, live_used_before:int, live_expired:int, live_with_refresh:int}>, refresh: array<string, int>}
     */
    private function stats(array $access, array $refresh): array
    {
        return ['access' => $access, 'refresh' => $refresh];
    }

    /** اجرای فرمان با بافر خروجی — @return array{exit: int, output: string} */
    private function runCommand(string ...$args): array
    {
        $command = new SecurityTokenRotationCommand($this->db, $this->apiToken, $this->auditTrail, $this->logger);
        ob_start();
        $exit = $command->run(array_merge(['cli.php', 'security:token-rotation'], array_values($args)));
        /** @var string $output */
        $output = ob_get_clean();
        return ['exit' => $exit, 'output' => $output];
    }

    // ═══════════════ مدل: getSecretVersionRotationStats ═══════════════

    /** @test */
    public function model_stats_maps_db_aggregates_into_typed_shape(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('fetchAll')->twice()->andReturnUsing(
            static function (string $sql) {
                if (str_contains($sql, 'refresh_secret_version')) {
                    return [
                        (object)['version_label' => 'v1', 'live_refresh_rows' => '4'],
                        (object)['version_label' => 'v2', 'live_refresh_rows' => '3'],
                    ];
                }
                self::assertStringContainsString('GROUP BY COALESCE(secret_version', $sql);
                self::assertStringContainsString('SUM(revoked = 0 AND last_used_at IS NULL)', $sql);
                return [
                    (object)[
                        'version_label' => 'v1', 'total_rows' => '12', 'live_rows' => '12',
                        'live_never_used' => '5', 'live_used_before' => '7', 'live_expired' => '0', 'live_with_refresh' => '4',
                    ],
                    (object)[
                        'version_label' => 'v2', 'total_rows' => '20', 'live_rows' => '8',
                        'live_never_used' => '6', 'live_used_before' => '2', 'live_expired' => '3', 'live_with_refresh' => '3',
                    ],
                ];
            }
        );

        $model = new ApiToken($db);
        $stats = $model->getSecretVersionRotationStats();

        self::assertSame(
            ['total' => 12, 'live' => 12, 'live_never_used' => 5, 'live_used_before' => 7, 'live_expired' => 0, 'live_with_refresh' => 4],
            $stats['access']['v1']
        );
        self::assertSame(
            ['total' => 20, 'live' => 8, 'live_never_used' => 6, 'live_used_before' => 2, 'live_expired' => 3, 'live_with_refresh' => 3],
            $stats['access']['v2']
        );
        self::assertSame(4, $stats['refresh']['v1']);
        self::assertSame(3, $stats['refresh']['v2']);
    }

    // ═══════════════ مدل: revokeByStaleSecretVersion ═══════════════

    /** @test @dataProvider provideUsageFilters */
    public function model_revoke_builds_scoped_sql_per_usage_filter(string $filter, string $expectedPredicate): void
    {
        $capturedSql = '';
        $capturedParams = [];
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->andReturnUsing(
            static function (array $params) use (&$capturedParams) {
                $capturedParams = $params;
                return true;
            }
        );
        $stmt->shouldReceive('rowCount')->once()->andReturn(6);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->andReturnUsing(
            static function (string $sql) use (&$capturedSql, $stmt) {
                $capturedSql = $sql;
                return $stmt;
            }
        );

        $model = new ApiToken($db);
        $revoked = $model->revokeByStaleSecretVersion(['v2'], 'rotation_cleanup', $filter);

        self::assertSame(6, $revoked);
        self::assertStringContainsString('UPDATE api_tokens', $capturedSql);
        self::assertStringContainsString("SET revoked = 1, revoked_at = NOW(), revoke_reason = ?", $capturedSql);
        self::assertStringContainsString('WHERE revoked = 0', $capturedSql);
        self::assertStringContainsString('secret_version IN (?)', $capturedSql);
        self::assertStringNotContainsString('secret_version IS NULL', $capturedSql);
        if ($expectedPredicate === '') {
            self::assertStringNotContainsString('last_used_at IS', $capturedSql);
        } else {
            self::assertStringContainsString($expectedPredicate, $capturedSql);
        }
        self::assertSame(['rotation_cleanup', 'v2'], $capturedParams);
    }

    /** @return list<list<string>> */
    public function provideUsageFilters(): array
    {
        return [
            ['never_used', 'AND last_used_at IS NULL'],
            ['used', 'AND last_used_at IS NOT NULL'],
            ['all', ''],
        ];
    }

    /** @test */
    public function model_revoke_rejects_invalid_labels_filters_and_empty_lists(): void
    {
        $model = new ApiToken($this->db);

        try {
            $model->revokeByStaleSecretVersion(["v2' OR 1=1 --"], 'rotation_cleanup', 'all');
            self::fail('برچسب تزریقی باید رد شود');
        } catch (\InvalidArgumentException $e) {
            self::assertStringContainsString('Invalid secret version label', $e->getMessage());
        }

        try {
            $model->revokeByStaleSecretVersion([], 'rotation_cleanup', 'all');
            self::fail('فهرست خالی باید رد شود');
        } catch (\InvalidArgumentException $e) {
            self::assertStringContainsString('At least one secret version label', $e->getMessage());
        }

        try {
            $model->revokeByStaleSecretVersion(['v2'], 'rotation_cleanup', 'sometimes');
            self::fail('فیلتر نامعتبر باید رد شود');
        } catch (\InvalidArgumentException $e) {
            self::assertStringContainsString('Invalid usage filter', $e->getMessage());
        }
    }

    /** @test */
    public function model_revoke_covers_null_version_rows_when_empty_label_present(): void
    {
        $capturedSql = '';
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with(['rotation_cleanup', 'v2', ''])->andReturn(true);
        $stmt->shouldReceive('rowCount')->once()->andReturn(2);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->andReturnUsing(
            static function (string $sql) use (&$capturedSql, $stmt) {
                $capturedSql = $sql;
                return $stmt;
            }
        );

        $model = new ApiToken($db);
        self::assertSame(2, $model->revokeByStaleSecretVersion(['v2', ''], 'rotation_cleanup', 'all'));
        self::assertStringContainsString('secret_version IN (?,?)', $capturedSql);
        self::assertStringContainsString('OR secret_version IS NULL', $capturedSql);
    }

    // ═══════════════ مدل: listStaleSecretVersionRows ═══════════════

    /** @test */
    public function model_list_joins_users_applies_usage_and_limit(): void
    {
        $capturedSql = '';
        $capturedParams = [];
        $db = m::mock(Database::class);
        $db->shouldReceive('fetchAll')->once()->andReturnUsing(
            static function (string $sql, array $params = []) use (&$capturedSql, &$capturedParams) {
                $capturedSql = $sql;
                $capturedParams = $params;
                return [(object)['id' => 9, 'username' => 'zahra', 'secret_version' => 'v2', 'last_used_at' => null]];
            }
        );

        $model = new ApiToken($db);
        $rows = $model->listStaleSecretVersionRows(['v2'], 'never_used', 25);

        self::assertCount(1, $rows);
        self::assertStringContainsString('LEFT JOIN users u ON u.id = at.user_id', $capturedSql);
        self::assertStringContainsString('at.revoked = 0', $capturedSql);
        self::assertStringContainsString('AND last_used_at IS NULL', $capturedSql);
        self::assertStringContainsString('LIMIT 25', $capturedSql);
        self::assertSame(['v2'], $capturedParams);
    }

    // ═══════════════ فرمان: گزارش ═══════════════

    /** @test */
    public function report_mode_exits_2_when_stale_live_rows_exist_and_shows_verdicts(): void
    {
        $this->setRotatedConfig();
        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            [
                'v1' => ['total' => 12, 'live' => 12, 'live_never_used' => 5, 'live_used_before' => 7, 'live_expired' => 0, 'live_with_refresh' => 4],
                'v2' => ['total' => 20, 'live' => 8, 'live_never_used' => 6, 'live_used_before' => 2, 'live_expired' => 3, 'live_with_refresh' => 3],
            ],
            ['v1' => 4, 'v2' => 3]
        ));

        $result = $this->runCommand();

        self::assertSame(2, $result['exit'], 'ردیف کهنهٔ فعال ⇒ خروج ۲ (سیگنال عملیاتی)');
        self::assertStringContainsString('نسخهٔ جاری: v1', $result['output']);
        self::assertStringContainsString('v2 [قدیمی]: فعال=8', $result['output']);
        self::assertStringContainsString('هرگز-استفاده‌نشده=6', $result['output']);
        self::assertStringContainsString('حکم بازنشستگی', $result['output']);
        self::assertStringContainsString('دسترسی: 8 | refresh: 3', $result['output']);
        self::assertStringContainsString('v1 [جاری]: هرگز حذف نشود', $result['output']);
        self::assertStringContainsString('8 ردیف فعال روی نسخهٔ کهنه', $result['output']);
        self::assertStringContainsString('--revoke=never-used --dry-run', $result['output']);
    }

    /** @test */
    public function report_mode_exits_0_when_rotation_is_complete(): void
    {
        $this->setRotatedConfig();
        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            ['v1' => ['total' => 5, 'live' => 5, 'live_never_used' => 1, 'live_used_before' => 4, 'live_expired' => 0, 'live_with_refresh' => 2]],
            ['v1' => 2]
        ));

        $result = $this->runCommand();

        self::assertSame(0, $result['exit']);
        self::assertStringContainsString('چرخش کامل است', $result['output']);
        self::assertStringContainsString('v2: ✅ هیچ ردیف فعالی به این رمز وابسته نیست — می‌توانید مقدارش را از .env حذف/خالی کنید', $result['output']);
    }

    /** @test */
    public function report_mode_flags_orphan_versions_and_includes_them_in_revoke_scope(): void
    {
        $this->setRotatedConfig();
        // '1' = برچسب یتیمِ باگ pre-SECRETROT (کلید رمزش در config نیست — هیچ‌وقت validate نمی‌شود)
        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            [
                'v1' => ['total' => 3, 'live' => 3, 'live_never_used' => 0, 'live_used_before' => 3, 'live_expired' => 0, 'live_with_refresh' => 0],
                'v2' => ['total' => 4, 'live' => 2, 'live_never_used' => 2, 'live_used_before' => 0, 'live_expired' => 0, 'live_with_refresh' => 0],
                '1' => ['total' => 2, 'live' => 2, 'live_never_used' => 2, 'live_used_before' => 0, 'live_expired' => 0, 'live_with_refresh' => 0],
            ],
            []
        ));

        $report = $this->runCommand('--list');
        self::assertSame(2, $report['exit']);
        self::assertStringContainsString('1 [یتیم — رمزی در config ندارد]', $report['output']);
        self::assertStringContainsString('هرگز اعتبارسنجی نمی‌شوند', $report['output']);

        // ابطال باید هر دو نسخهٔ غیرجاری را هدف بگیرد — یتیم هم مردهٔ قطعی است
        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            [
                'v1' => ['total' => 3, 'live' => 3, 'live_never_used' => 0, 'live_used_before' => 3, 'live_expired' => 0, 'live_with_refresh' => 0],
                'v2' => ['total' => 4, 'live' => 2, 'live_never_used' => 2, 'live_used_before' => 0, 'live_expired' => 0, 'live_with_refresh' => 0],
                '1' => ['total' => 2, 'live' => 2, 'live_never_used' => 2, 'live_used_before' => 0, 'live_expired' => 0, 'live_with_refresh' => 0],
            ],
            []
        ));
        $this->apiToken->shouldReceive('listStaleSecretVersionRows')->once()->with(['1', 'v2'], 'never_used', 50)->andReturn([]);
        $this->apiToken->shouldReceive('revokeByStaleSecretVersion')->once()->with(['1', 'v2'], 'rotation_cleanup', 'never_used')->andReturn(4);
        $this->auditTrail->shouldReceive('createEntry')->once()->andReturnUsing(
            static function (array $data) {
                self::assertSame('security.token_rotation_cleanup', $data['event']);
                self::assertSame('never-used', $data['context']['scope']);
                self::assertSame(['1', 'v2'], $data['context']['versions_targeted']);
                self::assertSame(4, $data['context']['revoked_count']);
                return 1;
            }
        );
        $this->db->shouldReceive('beginTransaction')->once();
        $this->db->shouldReceive('commit')->once();
        // آمار تازه پس از پاکسازی: همه چیز صفر
        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            ['v1' => ['total' => 3, 'live' => 3, 'live_never_used' => 0, 'live_used_before' => 3, 'live_expired' => 0, 'live_with_refresh' => 0]],
            []
        ));

        $revoke = $this->runCommand('--revoke=never-used');
        self::assertSame(0, $revoke['exit']);
        self::assertStringContainsString('4 ردیف ابطال شد', $revoke['output']);
        self::assertStringContainsString('رمز قدیمی را می‌توانید از .env حذف/خالی کنید', $revoke['output']);
    }

    /** @test */
    public function report_mode_warns_when_rotation_is_not_real_yet(): void
    {
        // V1 === V2 (هر دو fallback به legacy) — چرخش هنوز واقعی نیست
        config_set('security.api.secrets', ['v1' => self::OLD_SECRET, 'v2' => self::OLD_SECRET]);
        config_set('security.api.current_secret_version', 'v1');
        config_set('app.env', 'development');

        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            ['v1' => ['total' => 2, 'live' => 2, 'live_never_used' => 0, 'live_used_before' => 2, 'live_expired' => 0, 'live_with_refresh' => 0]],
            []
        ));

        $result = $this->runCommand();

        self::assertSame(0, $result['exit']);
        self::assertStringContainsString('چرخش هنوز واقعی نیست', $result['output']);
    }

    // ═══════════════ فرمان: ابطال ═══════════════

    /** @test */
    public function revoke_refuses_in_production_without_confirm_and_touches_nothing(): void
    {
        $this->setRotatedConfig();
        config_set('app.env', 'production');

        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            ['v2' => ['total' => 8, 'live' => 8, 'live_never_used' => 6, 'live_used_before' => 2, 'live_expired' => 0, 'live_with_refresh' => 0]],
            []
        ));
        $this->apiToken->shouldNotReceive('revokeByStaleSecretVersion');
        $this->apiToken->shouldNotReceive('listStaleSecretVersionRows');
        $this->auditTrail->shouldNotReceive('createEntry');
        $this->db->shouldNotReceive('beginTransaction');

        $result = $this->runCommand('--revoke=never-used');

        self::assertSame(1, $result['exit'], 'production بدون --confirm ⇒ ردِ fail-closed');
        self::assertStringContainsString('--confirm الزامی است', $result['output']);
    }

    /** @test */
    public function revoke_dry_run_lists_candidates_without_side_effects(): void
    {
        $this->setRotatedConfig();
        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            ['v2' => ['total' => 8, 'live' => 8, 'live_never_used' => 6, 'live_used_before' => 2, 'live_expired' => 0, 'live_with_refresh' => 0]],
            []
        ));
        $this->apiToken->shouldReceive('listStaleSecretVersionRows')->once()->with(['v2'], 'never_used', 50)->andReturn([
            (object)[
                'id' => 42, 'user_id' => 7, 'username' => 'ali', 'name' => 'ci-script', 'token_type' => 'personal',
                'secret_version' => 'v2', 'refresh_secret_version' => 'v2', 'last_used_at' => null,
                'use_count' => 0, 'expires_at' => null, 'created_at' => '2026-09-01 10:00:00', 'has_refresh' => 0,
            ],
        ]);
        $this->apiToken->shouldNotReceive('revokeByStaleSecretVersion');
        $this->auditTrail->shouldNotReceive('createEntry');
        $this->db->shouldNotReceive('beginTransaction');

        $result = $this->runCommand('--revoke=never-used', '--dry-run');

        self::assertSame(0, $result['exit']);
        self::assertStringContainsString('dry-run، بدون تغییر', $result['output']);
        self::assertStringContainsString('id=42', $result['output']);
        self::assertStringContainsString('ci-script', $result['output']);
        self::assertStringContainsString('هیچ تغییری اعمال نشد', $result['output']);
    }

    /** @test */
    public function revoke_executes_scoped_update_writes_audit_and_reports_fresh_verdict(): void
    {
        $this->setRotatedConfig();
        $before = $this->stats(
            [
                'v1' => ['total' => 12, 'live' => 12, 'live_never_used' => 5, 'live_used_before' => 7, 'live_expired' => 0, 'live_with_refresh' => 4],
                'v2' => ['total' => 20, 'live' => 8, 'live_never_used' => 6, 'live_used_before' => 2, 'live_expired' => 3, 'live_with_refresh' => 3],
            ],
            ['v1' => 4, 'v2' => 3]
        );
        // پس از ابطالِ never-used: فقط ۲ ردیف خفتهٔ v2 می‌ماند + refreshِ همان‌ها
        $after = $this->stats(
            [
                'v1' => ['total' => 12, 'live' => 12, 'live_never_used' => 5, 'live_used_before' => 7, 'live_expired' => 0, 'live_with_refresh' => 4],
                'v2' => ['total' => 20, 'live' => 2, 'live_never_used' => 0, 'live_used_before' => 2, 'live_expired' => 0, 'live_with_refresh' => 2],
            ],
            ['v1' => 4, 'v2' => 2]
        );

        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->twice()->andReturn($before, $after);
        $this->apiToken->shouldReceive('listStaleSecretVersionRows')->once()->with(['v2'], 'never_used', 50)->andReturn([]);
        // قرارداد حیاتی: نسخهٔ جاری (v1) هرگز در فهرست هدف نیست
        $this->apiToken->shouldReceive('revokeByStaleSecretVersion')->once()->with(['v2'], 'rotation_cleanup', 'never_used')->andReturn(6);
        $this->auditTrail->shouldReceive('createEntry')->once()->andReturnUsing(
            static function (array $data) {
                self::assertSame('security.token_rotation_cleanup', $data['event']);
                self::assertSame(AuditTrail::SYSTEM_ACTOR_ID, $data['actor_id']);
                self::assertSame(['v2'], $data['context']['versions_targeted']);
                self::assertSame(6, $data['context']['revoked_count']);
                self::assertSame('cli:security:token-rotation', $data['context']['source']);
                return 1;
            }
        );
        $this->db->shouldReceive('beginTransaction')->once();
        $this->db->shouldReceive('commit')->once();

        $result = $this->runCommand('--revoke=never-used');

        self::assertSame(0, $result['exit']);
        self::assertStringContainsString('6 ردیف ابطال شد', $result['output']);
        self::assertStringContainsString('rotation_cleanup', $result['output']);
        self::assertStringContainsString('2 ردیف فعالِ کهنه هنوز باقی است', $result['output']);
        self::assertStringContainsString('--revoke=all-stale --dry-run', $result['output']);
    }

    /** @test */
    public function revoke_is_idempotent_when_no_stale_live_rows_remain(): void
    {
        $this->setRotatedConfig();
        $this->apiToken->shouldReceive('getSecretVersionRotationStats')->once()->andReturn($this->stats(
            ['v1' => ['total' => 5, 'live' => 5, 'live_never_used' => 0, 'live_used_before' => 5, 'live_expired' => 0, 'live_with_refresh' => 0]],
            []
        ));
        $this->apiToken->shouldNotReceive('revokeByStaleSecretVersion');
        $this->auditTrail->shouldNotReceive('createEntry');

        $result = $this->runCommand('--revoke=all-stale');

        self::assertSame(0, $result['exit']);
        self::assertStringContainsString('کاری برای انجام نیست (idempotent)', $result['output']);
    }

    /** @test */
    public function bad_flags_exit_1_with_usage(): void
    {
        $this->setRotatedConfig();

        $badScope = $this->runCommand('--revoke=everything');
        self::assertSame(1, $badScope['exit']);
        self::assertStringContainsString('مقدار --revoke نامعتبر است', $badScope['output']);

        $badFlag = $this->runCommand('--wat');
        self::assertSame(1, $badFlag['exit']);
        self::assertStringContainsString('پارامتر ناشناخته: --wat', $badFlag['output']);
    }
}
