<?php

declare(strict_types=1);

namespace Tests\Unit\Security;

use App\Models\ApiToken;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SEARCHV2 — پینِ جست‌وجوی ادمین بر اساس توکن خام (باقی‌ماندهٔ اعلام‌شدهٔ
 * بندهای ۲/۵ مانیفست‌های SECRETROT و V2CLEAN).
 *
 * قرارداد پین‌شده:
 *  ۱) جست‌وجوی ۶۴-hex توکن خام باید با «همهٔ» نسخه‌های رمزِ پیکربندی‌شده هش و
 *     تطبیق داده شود، نه فقط نسخهٔ جاری — توکنِ هنوز-مهاجرت‌نکرده (برچسب v2
 *     بعد از چرخش به v1) هم باید از پنل ادمین پیدا شود.
 *  ۲) توکنِ نسخهٔ جاری همچنان پیدا می‌شود (بدون رگرسیون).
 *  ۳) مسیر LIKE (نام/ایمیل) دست‌نخورده است.
 * تست با DB واقعی و ردیفِ واقعیِ هش‌شده با رمز قدیمی، مسیر واقعیِ
 * findAllPaginated/countAll را اجرا می‌کند (نه mock از QueryBuilder).
 */
final class ApiTokenRawSearchAllVersionsTest extends TestCase
{
    /** رمز «جدید» — نسخهٔ جاری پس از چرخش (v1) */
    private const NEW_SECRET = '5f1c8a3e7b9d2f4a6c8e0b2d4f6a8c0e2b4d6f8a0c2e4b6d8f0a2c4e6b8d0f2a4';
    /** رمز «قدیمی» — نسخه‌ای که توکن‌های موجود با آن هش شده‌اند (v2) */
    private const OLD_SECRET = 'e7b3a9c1d5f2b8a4c6e0d2f4a6b8c0e2d4f6a8b0c2e4d6f8a0b2c4e6d8f0a2b4';

    private ?Database $db = null;
    private int $tokenId = 0;
    private int $userId = 0;
    /** @var array<string, mixed> */
    private array $configSnapshot = [];

    protected function setUp(): void
    {
        parent::setUp();
        foreach (['security.api.secrets', 'security.api.current_secret_version'] as $key) {
            $this->configSnapshot[$key] = config($key);
        }
        try {
            $db = Database::getInstance();
            $userId = (int) $db->query('SELECT id FROM users ORDER BY id LIMIT 1')->fetchColumn();
            if ($userId <= 0) {
                self::markTestSkipped('DB تست در دسترس است اما کاربری ندارد (seed لازم)');
            }
            $this->db = $db;
            $this->userId = $userId;
        } catch (\Throwable $e) {
            self::markTestSkipped('DB تست در دسترس نیست: ' . $e->getMessage());
        }
        // وضعیتِ پس از چرخش: جاری = v1 (رمز جدید)؛ v2 = رمز قدیمی
        config_set('security.api.secrets', ['v1' => self::NEW_SECRET, 'v2' => self::OLD_SECRET]);
        config_set('security.api.current_secret_version', 'v1');
    }

    protected function tearDown(): void
    {
        if ($this->tokenId > 0 && $this->db !== null) {
            try {
                $this->db->query('DELETE FROM api_tokens WHERE id = ?', [$this->tokenId]);
            } catch (\Throwable) {
                // best-effort cleanup
            }
            $this->tokenId = 0;
        }
        foreach ($this->configSnapshot as $key => $value) {
            config_set($key, $value);
        }
        parent::tearDown();
    }

    /** ردیف توکن واقعی با هشِ رمزِ داده‌شده درج می‌کند و id آن را نگه می‌دارد */
    private function insertTokenRow(string $hashedToken, string $secretVersion, string $name): void
    {
        $this->db->query(
            'INSERT INTO api_tokens (user_id, token, name, secret_version, revoked, created_at)
             VALUES (?, ?, ?, ?, 0, NOW())',
            [$this->userId, $hashedToken, $name, $secretVersion]
        );
        $this->tokenId = (int) $this->db->query('SELECT LAST_INSERT_ID()')->fetchColumn();
        self::assertGreaterThan(0, $this->tokenId, 'ردیف توکن باید درج شود');
    }

    /** @test */
    public function raw_token_still_on_old_version_is_findable_after_rotation(): void
    {
        // توکن خامِ ۶۴-hex — هشش با رمز «قدیمی» (v2) ذخیره شده؛ هنوز استفاده
        // نشده ⇒ مهاجرت خودکار هم رخ نداده ⇒ برچسب v2 باقی مانده.
        $raw = bin2hex(random_bytes(32));
        $this->insertTokenRow(
            hash_hmac('sha256', $raw, self::OLD_SECRET),
            'v2',
            'pkg-searchv2-old-version-token'
        );

        $model = new ApiToken($this->db);
        $rows = $model->findAllPaginated(20, 0, $raw, null);
        $found = array_values(array_filter($rows, fn($r): bool => (int) $r->id === $this->tokenId));

        self::assertCount(
            1,
            $found,
            'FIX-SEARCHV2: توکن هنوز-مهاجرت‌نکرده (v2) باید با جست‌وجوی توکن خام پیدا شود'
        );
        self::assertSame('pkg-searchv2-old-version-token', $found[0]->name ?? null);

        self::assertGreaterThanOrEqual(
            1,
            $model->countAll($raw, null),
            'countAll هم باید همان توکن را بشمارد (همان searchPredicate)'
        );
    }

    /** @test */
    public function raw_token_on_current_version_is_still_findable(): void
    {
        $raw = bin2hex(random_bytes(32));
        $this->insertTokenRow(
            hash_hmac('sha256', $raw, self::NEW_SECRET),
            'v1',
            'pkg-searchv2-current-version-token'
        );

        $model = new ApiToken($this->db);
        $rows = $model->findAllPaginated(20, 0, $raw, null);
        $found = array_values(array_filter($rows, fn($r): bool => (int) $r->id === $this->tokenId));

        self::assertCount(1, $found, 'توکن نسخهٔ جاری همچنان باید با جست‌وجوی خام پیدا شود');
    }

    /** @test */
    public function name_like_search_path_is_untouched(): void
    {
        $raw = bin2hex(random_bytes(32));
        $this->insertTokenRow(
            hash_hmac('sha256', $raw, self::NEW_SECRET),
            'v1',
            'pkg-searchv2-like-fixture-name'
        );

        $model = new ApiToken($this->db);
        $rows = $model->findAllPaginated(20, 0, 'pkg-searchv2-like-fixture', null);
        $found = array_values(array_filter($rows, fn($r): bool => (int) $r->id === $this->tokenId));

        self::assertCount(1, $found, 'جست‌وجوی متنی (LIKE روی نام) نباید از FIX-SEARCHV2 آسیب ببیند');
    }
}
