<?php

declare(strict_types=1);

namespace Tests\Unit\Database;

use PHPUnit\Framework\TestCase;

/**
 * W4-E — تست ساختاری مایگریشن purge توکن‌های legacy
 *
 * helper آزمایشگاهی (tests/Support/migrate_disposable_database.php) اجرای
 * تک‌مایگریشن را پشتیبانی نمی‌کند (فقط runMigrations کامل) و اجرای روی DB
 * زنده ممنوع است؛ بنابراین طبق دستور تسک، ساختار فایل مایگریشن pin می‌شود:
 * فایل درست، DELETE کامل api_tokens، no-op طبیعی برای نصب تازه، و بدون
 * دست‌زدن به جدول دیگری.
 */
class MigrationPurgeLegacyApiTokensTest extends TestCase
{
    private string $migrationPath = __DIR__ . '/../../../database/migrations/2026_09_22_0004_purge_legacy_api_tokens.php';

    /** @test */
    public function migration_file_exists_with_expected_name(): void
    {
        $this->assertFileExists($this->migrationPath);
        $this->assertStringEndsWith(
            'database/migrations/2026_09_22_0004_purge_legacy_api_tokens.php',
            $this->migrationPath
        );
    }

    /** @test */
    public function migration_purges_all_api_tokens_rows(): void
    {
        $content = (string) file_get_contents($this->migrationPath);
        $this->assertStringContainsString('DELETE FROM api_tokens', $content);
    }

    /** @test */
    public function migration_is_natural_noop_for_fresh_install(): void
    {
        $content = (string) file_get_contents($this->migrationPath);
        // گارد نصب تازه: بررسی information_schema قبل از هر DELETE
        $this->assertStringContainsString('information_schema.TABLES', $content);
        $this->assertStringContainsString("table_name = 'api_tokens'", $content);
        // گارد idempotency: جدول خالی → بدون DELETE
        $this->assertStringContainsString('SELECT COUNT(*) FROM api_tokens', $content);
    }

    /** @test */
    public function migration_documentation_references_client_decision(): void
    {
        $content = (string) file_get_contents($this->migrationPath);
        $this->assertStringContainsString('W4', $content, 'کامنت باید تصمیم W4 و مالکیت تصمیم را مستند کند');
    }

    /** @test */
    public function migration_touches_no_other_table(): void
    {
        $content = (string) file_get_contents($this->migrationPath);
        preg_match_all(
            '/(?:DELETE FROM|UPDATE|INSERT INTO|DROP TABLE|TRUNCATE|ALTER TABLE)\s+`?([a-zA-Z0-9_]+)`?/i',
            $content,
            $matches
        );
        $tables = array_values(array_unique(array_map('strtolower', $matches[1] ?? [])));
        $this->assertNotEmpty($tables, 'حداقل یک دستور DML/DDL باید وجود داشته باشد');
        $this->assertSame(['api_tokens'], $tables, 'فقط جدول api_tokens مجاز است: ' . implode(',', $tables));
    }
}
