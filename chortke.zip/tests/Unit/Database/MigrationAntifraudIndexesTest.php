<?php

declare(strict_types=1);

namespace Tests\Unit\Database;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-R18-GAP-IDX (بستهٔ باقیماندهٔ R18 — قرارداد مایگریشن ایندکس‌های ضدتقلب).
 *
 * پین سطح-سورس (هم‌الگوی MigrationPurgeLegacyApiTokensTest): فایل SQL باید
 * idempotent باشد، هیچ داده‌ای حذف نکند، و دقیقاً ایندکس‌هایی را بسازد که
 * دو پرس‌وجوی ضدتقلبِ پرفرکانس به آن‌ها نیاز دارند:
 *   • idx_ste_ip_created (social_task_executions: ip_address, created_at)
 *     ← SocialTaskExecutionModel::getRecentExecutionsByIp
 *   • idx_uf_fingerprint_user (user_fingerprints: fingerprint, user_id — UNIQUE)
 *     ← getFingerprintUserCount / getSharedFingerprintUsers + رفع ریشه‌ایِ
 *       یکتایی تک‌ستونه که سیگنال «اثر انگشت مشترک» را ساختاریاً مرده کرده بود.
 */
final class MigrationAntifraudIndexesTest extends TestCase
{
    private string $migrationPath;

    protected function setUp(): void
    {
        parent::setUp();
        $this->migrationPath = dirname(__DIR__, 3) . '/database/migrations/2026_10_25_0001_antifraud_query_indexes.sql';
        $this->assertFileExists($this->migrationPath, 'فایل مایگریشن ایندکس‌های ضدتقلب باید وجود داشته باشد');
    }

    public function test_migration_is_idempotent_and_destructive_free(): void
    {
        $content = (string)file_get_contents($this->migrationPath);

        $this->assertStringContainsString('CREATE INDEX IF NOT EXISTS', $content, 'CREATE INDEX باید IF NOT EXISTS باشد (اجرای مجدد امن)');
        $this->assertStringContainsString('DROP INDEX IF EXISTS', $content, 'DROP INDEX باید IF EXISTS باشد (اجرای مجدد امن)');
        $this->assertStringNotContainsString('DELETE FROM', $content, 'مایگریشن ایندکسی نباید داده حذف کند');
        $this->assertStringNotContainsString('TRUNCATE', $content, 'مایگریشن ایندکسی نباید جدول را خالی کند');
        $this->assertStringNotContainsString('DROP TABLE', $content, 'مایگریشن ایندکسی نباید جدول بیندازد');
    }

    public function test_ste_ip_created_index_matches_the_fraud_query_shape(): void
    {
        $content = (string)file_get_contents($this->migrationPath);
        $this->assertStringContainsString('`idx_ste_ip_created`', $content);
        $this->assertStringContainsString('ON `social_task_executions` (`ip_address`, `created_at`)', $content, 'ترتیب ستون‌ها باید با WHERE ip_address=? AND created_at>=... هم‌خوان باشد');
    }

    public function test_fingerprint_uniqueness_moves_to_the_pair(): void
    {
        $content = (string)file_get_contents($this->migrationPath);

        // حذف یکتایی تک‌ستونه (ریشهٔ مرده‌بودن سیگنال اثر انگشت مشترک)
        $this->assertStringContainsString('DROP INDEX IF EXISTS `idx_fingerprint`', $content);
        // یکتایی جفتی با همان نامی که در EXPLAIN بستهٔ R18 راستی‌آزمایی شد
        $this->assertStringContainsString('CREATE UNIQUE INDEX IF NOT EXISTS `idx_uf_fingerprint_user`', $content);
        $this->assertStringContainsString('ON `user_fingerprints` (`fingerprint`, `user_id`)', $content);
    }

    public function test_model_queries_are_served_by_these_indexes(): void
    {
        // قرارداد پین متقاطع: کوئری‌های مصرف‌کننده باید با ایندکس‌های بالا هم‌خوان باشند
        $execModel = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Models/SocialTaskExecutionModel.php');
        $this->assertStringContainsString('FROM social_task_executions', $execModel);
        $this->assertStringContainsString('WHERE ip_address = ?', $execModel, 'کوئری getRecentExecutionsByIp باید بر ip_address فیلتر کند');
        $this->assertStringContainsString('FROM user_fingerprints', $execModel, 'کوئری getSharedFingerprintUsers باید روی user_fingerprints باشد');
        $this->assertStringContainsString('WHERE fingerprint = ?', $execModel);
    }

    public function test_upsert_still_bumps_owner_row_under_pair_uniqueness(): void
    {
        // upsert باید تحت یکتایی (fingerprint, user_id) همچنان bump کند نه insert تکراری
        $ipModel = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Models/IpAndDeviceModel.php');
        $this->assertStringContainsString('ON DUPLICATE KEY UPDATE last_seen = NOW(), seen_count = seen_count + 1', $ipModel, 'semantics دیده‌شدنِ مالکِ ردیف حفظ شود');
    }
}
