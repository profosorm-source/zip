<?php

declare(strict_types=1);

namespace Tests\Unit\Database;

use PHPUnit\Framework\TestCase;
use App\Services\MigrationService;

/**
 * 🛡️ FIX-MIG-SEQ (رفع خطای از-قبل؛ حوزهٔ migration):
 * پین «یکتایی شمارهٔ توالی مایگریشن‌ها» + اعتبار نگاشت rename.
 *
 * پیشینه: ۸ فایل زیر ۷ پیشوندِ توالیِ تکراری قرار داشتند؛ هر اجرای
 * php cli.php migration با هشدار database.migration.duplicate_sequence_prefixes
 * شروع می‌شد و بازبینی/rollback دستی را مبهم می‌کرد. اکنون:
 *   ۱) همهٔ پیشوندها یکتا هستند؛
 *   ۲) نگاشت MIGRATION_FILE_RENAMES دقیقاً همان ۸ انتقال را پوشش می‌دهد؛
 *   ۳) هیچ نام قدیمی روی دیسک باقی نمانده؛
 *   ۴) مقصدهای rename همه موجودند (وگرنه transition دیگری رخ می‌داد).
 */
final class MigrationSequencePrefixUniquenessTest extends TestCase
{
    private const MIGRATIONS_DIR = __DIR__ . '/../../../database/migrations';

    /** @return list<string> */
    private function migrationFiles(): array
    {
        $all = array_merge(glob(self::MIGRATIONS_DIR . '/*.sql') ?: [], glob(self::MIGRATIONS_DIR . '/*.php') ?: []);
        sort($all);
        return array_map('basename', $all);
    }

    public function testAllSequencePrefixesAreUnique(): void
    {
        $seen = [];
        $duplicates = [];
        foreach ($this->migrationFiles() as $file) {
            if (preg_match('/^(\d{4}_\d{2}_\d{2}_\d{4})_/', $file, $m) !== 1) {
                // 9999_0001 sentinel is allowed to keep its historical shape.
                continue;
            }
            $prefix = $m[1];
            if (isset($seen[$prefix])) {
                $duplicates[] = $prefix . ' (' . $seen[$prefix] . ' / ' . $file . ')';
            }
            $seen[$prefix] = $file;
        }
        $this->assertSame([], $duplicates, 'duplicate migration sequence prefixes found: ' . implode('; ', $duplicates));
    }

    public function testRenameMapCoversExactlyTheNineRenamesAndTargetsExist(): void
    {
        $renames = (new \ReflectionClass(MigrationService::class))->getConstant('MIGRATION_FILE_RENAMES');
        $this->assertIsArray($renames);
        // 📱 FIX-MOBILE-06 (۲۰۲۶-۱۱-۰۳): نهمین rename — رفع تکرارِ پیشوندِ
        // 2026_11_01_0001 (تست قرمزِ از-قبل MigrationSequencePrefixUniqueness).
        $this->assertCount(9, $renames, 'FIX-MIG-SEQ registry must cover exactly the 9 reviewed renames');

        $onDisk = $this->migrationFiles();
        foreach ($renames as $old => $new) {
            $this->assertNotContains($old, $onDisk, "old name must be gone from disk: {$old}");
            $this->assertContains($new, $onDisk, "renamed target missing on disk: {$new}");
            // a rename must actually change the sequence prefix (not a cosmetic no-op)
            $this->assertNotSame(substr($old, 0, 15), substr($new, 0, 15), "rename must de-duplicate the prefix: {$old}");
        }
    }

    public function testRenameMapTargetsKeepContentsUntamperedAgainstDbChecksums(): void
    {
        // The rename is a pure filename move: file content (and therefore its
        // sha256 checksum) must be untouched. We cannot read the DB here, but we
        // pin the invariant that the service never treats a rename as re-execution
        // by asserting the rename map keys are disjoint from the on-disk files —
        // i.e. the runner can only ever reach them through MIGRATION_FILE_RENAMES.
        $renames = (new \ReflectionClass(MigrationService::class))->getConstant('MIGRATION_FILE_RENAMES');
        $onDisk = $this->migrationFiles();
        foreach (array_keys($renames) as $old) {
            $this->assertNotContains($old, $onDisk);
        }
        $this->assertSame([], array_values(array_intersect(array_keys($renames), $onDisk)));
        // sanity: AMENDED_MIGRATIONS keys for renamed files use the NEW names
        $amended = (new \ReflectionClass(MigrationService::class))->getConstant('AMENDED_MIGRATIONS');
        foreach (['2026_09_17_0002_drop_dead_schema_items.php', '2026_09_22_0004_purge_legacy_api_tokens.php'] as $key) {
            $this->assertArrayHasKey($key, $amended, 'amendment registry must be keyed by the current (renamed) filename');
        }
    }
}
