<?php

declare(strict_types=1);

namespace Tests\Unit\Database;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-AF-UPSERT-UNIQUE (بازبینی گیت‌هاب 2026-10-28 — رگرسیون یکتایی جفتی).
 *
 * باگ (اثبات‌شده با پروب روی شمای مایگریت‌شده): user_fingerprints فقط
 * PRIMARY(id) داشت و IpAndDeviceModel::upsertFingerprint با ON DUPLICATE KEY
 * UPDATE کار می‌کند — بدون کلید یکتا، ON DUPLICATE هرگز fire نمی‌شود ⇒ هر
 * فراخوانی upsert یک ردیف جدید درج می‌کرد (پروب: ۳ فراخوانی همان جفت ⇒ ۳
 * ردیف جدا با seen_count=1) و seen_count/last_seen برای همیشه مرده بودند؛
 * مایگریشن FIX-AF-QRY-IDX ایندکس «plain» ساخت که سرعت پرس‌وجو را درست کرد
 * اما چون یکتا نیست، درج مکرر باقی ماند.
 *
 * رفع: مایگریشن 2026_10_28_0001_user_fingerprints_unique_upsert_fix.php —
 * ادغام ردیف‌های تکراری انباشته + UNIQUE (fingerprint, user_id).
 *
 * این تست هر دو سطح را قفل می‌کند: قرارداد فایل مایگریشن (سورس) و
 * رفتار زندهٔ upsert روی دیتابیس مایگریت‌شده.
 *
 * @group antifraud
 */
final class UserFingerprintsUniqueUpsertMigrationTest extends TestCase
{
    private const FP = 'fp_test_unique_upsert_probe';

    private string $migrationPath;

    protected function setUp(): void
    {
        parent::setUp();
        $this->migrationPath = dirname(__DIR__, 3)
            . '/database/migrations/2026_10_28_0001_user_fingerprints_unique_upsert_fix.php';
        $this->assertFileExists($this->migrationPath, 'مایگریشن یکتایی جفتی باید وجود داشته باشد');
    }

    protected function tearDown(): void
    {
        try {
            $db = \Core\Database::getInstance();
            $db->query('DELETE FROM user_fingerprints WHERE fingerprint = ?', [self::FP]);
        } catch (\Throwable $e) {
            // بدون DB — تست‌های رفتاری خودشان skip می‌شوند
        }
        parent::tearDown();
    }

    /**
     * @test
     */
    public function migration_adds_unique_pair_index_not_plain(): void
    {
        $content = (string)file_get_contents($this->migrationPath);

        self::assertStringContainsString(
            'ADD UNIQUE INDEX idx_uf_fingerprint_user (fingerprint, user_id)',
            $content,
            'ایندکس جفتی باید UNIQUE باشد — ایندکس plain، ON DUPLICATE KEY UPDATE را زنده نمی‌کند'
        );
    }

    /**
     * @test
     */
    public function migration_merges_existing_duplicates_before_unique(): void
    {
        $content = (string)file_get_contents($this->migrationPath);

        // بدون ادغام اولیه، ساخت UNIQUE روی داده‌های تکراریِ انباشته از دوران
        // باگ با «Duplicate entry» شکست می‌خورد — مایگریشن باید قبل از ADD
        // UNIQUE، ردیف‌های تکراریِ همان جفت را ادغام کند (حفظ جمع seen_count).
        self::assertStringContainsString('HAVING COUNT(*) > 1', $content, 'گام ادغام جفت‌های تکراری');
        self::assertStringContainsString('SUM(seen_count)', $content, 'جمع seen_count هنگام ادغام حفظ می‌شود');
        self::assertStringContainsString('MAX(last_seen)', $content, 'آخرین دیدار هنگام ادغام حفظ می‌شود');
    }

    /**
     * @test
     */
    public function migration_is_idempotent(): void
    {
        $content = (string)file_get_contents($this->migrationPath);

        // اجرای دوم نباید duplicate-key error بگیرد — گارد SKIP وقتی از قبل UNIQUE است
        self::assertStringContainsString("non_unique'] === 0", $content, 'گارد SKIP برای حالت از-before-UNIQUE');
        self::assertStringNotContainsString('DROP TABLE', $content, 'مایگریشن نباید جدول بیندازد');
        self::assertStringNotContainsString('TRUNCATE', $content, 'مایگریشن نباید جدول را خالی کند');
    }

    /**
     * @test
     */
    public function upsert_model_uses_on_duplicate_semantics(): void
    {
        $model = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Models/IpAndDeviceModel.php');
        self::assertStringContainsString(
            'ON DUPLICATE KEY UPDATE last_seen = NOW(), seen_count = seen_count + 1',
            $model,
            'قرارداد upsertFingerprint — نیازمند کلید یکتای جفتی برای fire شدن'
        );
    }

    /**
     * @test
     */
    public function live_index_is_unique_on_the_pair(): void
    {
        $db = \Core\Database::getInstance();
        $row = $db->fetch(
            'SELECT NON_UNIQUE, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS cols
             FROM information_schema.STATISTICS
             WHERE table_schema = DATABASE()
               AND table_name = \'user_fingerprints\'
               AND index_name = \'idx_uf_fingerprint_user\'
             GROUP BY NON_UNIQUE'
        );
        self::assertNotNull($row, 'ایندکس idx_uf_fingerprint_user باید اعمال شده باشد');
        self::assertSame(0, (int)$row->NON_UNIQUE, 'ایندکس باید UNIQUE باشد (NON_UNIQUE=0) — plain سیگنال مردهٔ upsert را زنده نمی‌کند');
        self::assertSame('fingerprint,user_id', (string)$row->cols, 'ترتیب ستون‌ها: fingerprint, user_id');
    }

    /**
     * @test
     * @depends live_index_is_unique_on_the_pair
     */
    public function repeated_upserts_of_same_pair_bump_seen_count_not_new_rows(): void
    {
        $model = \Core\Container::getInstance()->make(\App\Models\IpAndDeviceModel::class);

        // سه فراخوانی همان (user, fingerprint) — قبل از رفع: ۳ ردیف جدا با seen_count=1
        foreach ([1, 2, 3] as $_) {
            self::assertTrue($model->upsertFingerprint(990001, self::FP, ['probe' => 'unique-upsert']));
        }

        $db = \Core\Database::getInstance();
        $row = $db->fetch(
            'SELECT COUNT(*) AS rows_cnt, MAX(seen_count) AS max_seen
             FROM user_fingerprints WHERE fingerprint = ? AND user_id = ?',
            [self::FP, 990001]
        );
        self::assertSame(1, (int)$row->rows_cnt, 'سه upsert همان جفت باید دقیقاً یک ردیف بسازد');
        self::assertSame(3, (int)$row->max_seen, 'seen_count باید به ۳ رسیده باشد (اولین درج=1 + دو bump)');
    }

    /**
     * @test
     * @depends live_index_is_unique_on_the_pair
     */
    public function second_user_same_fingerprint_gets_own_row_and_signal_stays_alive(): void
    {
        $model = \Core\Container::getInstance()->make(\App\Models\IpAndDeviceModel::class);
        $db = \Core\Database::getInstance();

        $model->upsertFingerprint(990001, self::FP, []);
        $model->upsertFingerprint(990002, self::FP, []);

        $row = $db->fetch(
            'SELECT COUNT(DISTINCT user_id) AS users FROM user_fingerprints WHERE fingerprint = ?',
            [self::FP]
        );
        self::assertSame(2, (int)$row->users, 'دو کاربرِ همان دستگاه باید هرکدام ردیف خودشان را داشته باشند — سیگنال «یک دستگاه، چند حساب» زنده');

        // قرارداد مصرف‌کنندهٔ ضدتقلب: شمارش کاربران دیگرِ همین اثر انگشت
        $execModel = \Core\Container::getInstance()->make(\App\Models\SocialTaskExecutionModel::class);
        self::assertSame(1, $execModel->getSharedFingerprintUsers(self::FP, 990001), 'از دید کاربر 990001: یک کاربر دیگر با همین انگشت');
    }

    /**
     * @test
     * @depends live_index_is_unique_on_the_pair
     */
    public function raw_duplicate_pair_insert_is_rejected_by_database(): void
    {
        $db = \Core\Database::getInstance();
        $db->query(
            'INSERT INTO user_fingerprints (user_id, fingerprint, metadata, created_at) VALUES (?, ?, \'{}\', NOW())',
            [990003, self::FP]
        );

        // لاگِ fail-soft لایهٔ Database برای خطای 1062 با expectOutputRegex مصرف
        // می‌شود (الگوی S28/SystemCameraCleanupScheduleTest) و هم‌زمان «رخدادِ
        // خودِ خطای یکتایی» به‌عنوان ادعای تست پین می‌شود.
        $this->expectOutputRegex('/1062 Duplicate entry/');

        try {
            $db->query(
                'INSERT INTO user_fingerprints (user_id, fingerprint, metadata, created_at) VALUES (?, ?, \'{}\', NOW())',
                [990003, self::FP]
            );
            self::fail('درج خامِ جفت تکراری باید توسط UNIQUE INDEX رد شود (1062)');
        } catch (\PDOException $e) {
            self::assertStringContainsString('1062', (string)$e->getMessage(), 'خطای انتظار: Duplicate entry for key idx_uf_fingerprint_user');
        }
    }
}
