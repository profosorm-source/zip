<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\EventDispatcher;
use Core\Event;
use PHPUnit\Framework\TestCase;

/**
 * فیکسچرهای سبک برای آزمودن رزولوشن canonical بدون وابستگی به سرویس‌های واقعی.
 */
final class S21WiringProbeEvent extends Event
{
}

final class S21WiringProbeListener
{
    public static int $hits = 0;

    public function handle(Event $event): void
    {
        self::$hits++;
    }
}

/**
 * S21 — تست قفل‌کنندهٔ سیم‌کشی رویدادها (FIX-EV-1 + FIX-EV-5)
 *
 * این تست رفتارهای ریشه‌ایِ ممیزی سیم‌کشی را قفل می‌کند:
 *  ۱) dispatch با صفر شنونده هرگز بی‌صدا نیست (event.no_listeners) — دغدغهٔ اصلی
 *     «رویدادهای بدسیم‌شده بدون صدا بلعیده می‌شوند».
 *  ۲) dispatch یک رویداد class-string، شنوندهٔ ثبت‌شده زیر نام canonical نقطه‌ای را هم
 *     اجرا می‌کند (حلقهٔ گم‌شدهٔ CQRS Write→Read) و dedupe جلوی اجرای دوبارهٔ
 *     شنوندهٔ دوباره‌ثبت‌شده را می‌گیرد.
 *  ۳) KYCApprovedEvent (acronym) به درستی 'kyc.approved' می‌دهد نه 'kycapproved'.
 *  ۴) getRegisteredEventNames() نمای درستی از ثبت‌ها می‌دهد (ابزار ممیزی).
 *
 * نکتهٔ ایزولاسیون: این تست عمداً LoggerInterface کانتینر را override نمی‌کند
 * (باقی‌ماندنش کل پروسهٔ PHPUnit را آلوده می‌کند — تست‌های S6/S16 به رفتار
 * پیش‌فرضِ FallbackLogger وابسته‌اند). مشاهدهٔ لاگ از طریق خروجی استاندارد
 * FallbackLogger و expectOutputRegex انجام می‌شود.
 *
 * @group events
 * @group wiring
 */
final class EventWiringIntegrityTest extends TestCase
{
    private function makeDispatcher(): EventDispatcher
    {
        // وابستگی‌های سازنده در این سناریو استفاده نمی‌شوند (بدون async/audit)؛
        // Queue فقط برای dispatchAsync لازم است.
        $cache = new \Core\Cache();
        return new EventDispatcher(
            new \Core\Queue(\Core\Database::getInstance(), $cache, 'database'),
            null
        );
    }

    public function test_zero_listener_dispatch_logs_no_listeners_warning(): void
    {
        // در محیط unit-test، logger() به FallbackLogger (چاپ خروجی) fallback می‌کند؛
        // حضور event.no_listeners در خروجی = اثباتِ «صدادار بودن» dispatch بی‌شنونده.
        $this->expectOutputRegex('/event\.no_listeners/');

        $dispatcher = $this->makeDispatcher();
        $dispatcher->dispatch('s21.no_listener_probe');
    }

    public function test_class_string_event_fires_canonical_dot_name_listener_once(): void
    {
        $this->expectOutputRegex('/.*/'); // لاگ event.dispatchedِ FallbackLogger مجاز است
        $dispatcher = $this->makeDispatcher();
        S21WiringProbeListener::$hits = 0;

        $closureHits = 0;

        // canonical واقعی این کلاس: S21|Wiring|Probe → 's21.wiring.probe'
        $canonical = 's21.wiring.probe';

        // شنوندهٔ [class,method] زیر FQCN + زیر نام canonical (الگوی دوباره‌ثبتی)
        $dispatcher->listen(S21WiringProbeEvent::class, [S21WiringProbeListener::class, 'handle']);
        $dispatcher->listen($canonical, [S21WiringProbeListener::class, 'handle']);
        // شنوندهٔ مستقل زیر نام canonical (مثل پروجکشن‌های bootstrap)
        $dispatcher->listen($canonical, function () use (&$closureHits): void {
            $closureHits++;
        });

        $dispatcher->dispatch(S21WiringProbeEvent::class, new S21WiringProbeEvent(['id' => 1]));

        $this->assertSame(1, $closureHits, 'dispatch با FQCN باید شنوندهٔ نام نقطه‌ای canonical را هم اجرا کند (FIX-EV-5).');
        $this->assertSame(1, S21WiringProbeListener::$hits, 'شنوندهٔ دوباره‌ثبت‌شده (FQCN + dot-name) باید فقط یک‌بار اجرا شود (dedupe).');
    }

    public function test_acronym_event_class_normalizes_to_kyc_approved(): void
    {
        $this->expectOutputRegex('/.*/'); // لاگ event.dispatchedِ FallbackLogger مجاز است
        $dispatcher = $this->makeDispatcher();
        $hit = 0;
        $dispatcher->listen('kyc.approved', function () use (&$hit): void { $hit++; });

        $dispatcher->dispatch(\App\Events\KYCApprovedEvent::class, new \App\Events\KYCApprovedEvent(1, 2));

        $this->assertSame(1, $hit, 'KYCApprovedEvent باید به kyc.approved (نه kycapproved) resolve شود.');
    }

    public function test_get_registered_event_names_exposes_wiring(): void
    {
        $dispatcher = $this->makeDispatcher();
        $dispatcher->listen('s21.exposure.probe', fn() => null);

        $names = $dispatcher->getRegisteredEventNames();
        $this->assertContains('s21.exposure.probe', $names);
    }
}
