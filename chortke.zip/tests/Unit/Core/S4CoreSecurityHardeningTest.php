<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use App\Services\LogService;
use App\Contracts\LoggerInterface;
use App\Contracts\ErrorContract;
use Core\ExceptionHandler;
use Core\Logger;
use Core\QueryBuilder;
use Core\Validator;
use PHPUnit\Framework\TestCase;

/**
 * بچ S4 ممیزی امنیتی هسته — تست‌های حلقه‌بستهٔ فیکس‌های FIX-S4-1..7
 *
 * لنز: نشت دادهٔ حساس / تزریق لاگ (Logger, ExceptionHandler, LogService,
 * helpers/security.php, Queue meta, bootstrap REQUEST_ID) و دورزدن/کرش
 * اعتبارسنجی عددی (Validator ↔ bcmath).
 *
 * الگوی canonical مشترک: ^[\w.\-:]{1,128}$ (هم‌راستا با ExceptionHandler::fallbackTraceId)
 */
final class S4CoreSecurityHardeningTest extends TestCase
{
    /** الگوی canonical شناسه‌های همبستگی (بچ S4) */
    private const CORRELATION_PATTERN = '/^[\w.\-:]{1,128}$/';

    protected function tearDown(): void
    {
        // پاکسازی superglobalها بین تست‌ها تا نشت حالت رخ ندهد
        foreach (['HTTP_X_TRACE_ID', 'HTTP_X_SPAN_ID', 'HTTP_X_PARENT_SPAN_ID', 'HTTP_X_REQUEST_ID', 'REQUEST_ID'] as $key) {
            unset($_SERVER[$key]);
        }
        parent::tearDown();
    }

    // ─────────────────────────────────────────────────────────────────────
    // FIX-S4-1 — helpers/security.php: get_trace_context
    // ─────────────────────────────────────────────────────────────────────

    public function test_trace_context_rejects_malformed_user_trace_headers(): void
    {
        $_SERVER['HTTP_X_TRACE_ID'] = "evil id\r\nX-Injected: yes";
        $_SERVER['HTTP_X_SPAN_ID'] = 'bad span!!';
        $_SERVER['HTTP_X_PARENT_SPAN_ID'] = 'parent with space';

        $context = get_trace_context();

        $this->assertSame(1, preg_match(self::CORRELATION_PATTERN, $context['trace_id']));
        $this->assertStringNotContainsString('evil id', (string) $context['trace_id']);
        $this->assertStringNotContainsString('X-Injected', (string) $context['trace_id']);

        // span نامعتبر → تولید امن hex
        $this->assertSame(1, preg_match('/^[a-f0-9]{16}$/', (string) $context['span_id']));
        // parent_span_id فیلد اختیاری است → نامعتبر حذف (null) می‌شود
        $this->assertNull($context['parent_span_id']);
    }

    public function test_trace_context_keeps_well_formed_user_trace_headers(): void
    {
        $_SERVER['HTTP_X_TRACE_ID'] = '4bf92f3577b34da6a3ce929d0e0e4736';
        $_SERVER['HTTP_X_SPAN_ID'] = '00f067aa0ba902b7';
        $_SERVER['HTTP_X_PARENT_SPAN_ID'] = '5D.2b_1:abc';

        $context = get_trace_context();

        $this->assertSame('4bf92f3577b34da6a3ce929d0e0e4736', $context['trace_id']);
        $this->assertSame('00f067aa0ba902b7', $context['span_id']);
        $this->assertSame('5D.2b_1:abc', $context['parent_span_id']);
    }

    public function test_trace_context_falls_back_to_request_id_when_trace_header_is_invalid(): void
    {
        $_SERVER['REQUEST_ID'] = 'REQ_20260914120000_ab12cd34';
        $_SERVER['HTTP_X_TRACE_ID'] = '###invalid###';

        $context = get_trace_context();

        $this->assertSame('REQ_20260914120000_ab12cd34', $context['trace_id']);
    }

    // ─────────────────────────────────────────────────────────────────────
    // FIX-S4-2 — core/Logger.php: enrich (آخرین خط دفاعی facade)
    // ─────────────────────────────────────────────────────────────────────

    private function invokeEnrich(Logger $logger, array $context): array
    {
        $method = new \ReflectionMethod(Logger::class, 'enrich');
        $method->setAccessible(true);

        return $method->invoke($logger, $context);
    }

    public function test_logger_enrich_neutralizes_malformed_correlation_ids(): void
    {
        $logger = new Logger(new LogService());

        $enriched = $this->invokeEnrich($logger, [
            'trace_id' => "id\r\nwith-CRLF",
            'span_id' => str_repeat('A', 500), // فراتر از سقف ۱۲۸
            'parent_span_id' => ['not-a-string'],
            'request_id' => 'valid.Request_01:ok',
        ]);

        $this->assertNull($enriched['trace_id']);
        $this->assertNull($enriched['span_id']);
        $this->assertNull($enriched['parent_span_id']);
        $this->assertSame('valid.Request_01:ok', $enriched['request_id']);
    }

    public function test_logger_enrich_uses_sanitized_trace_context_for_user_headers(): void
    {
        // REQUEST_ID در bootstrap به مقدار معتبر ست می‌شود؛ برای سنجش مسیر
        // fallback هدر مخرب، آن را خالی می‌کنیم تا مبنای مقایسه قطعی شود.
        unset($_SERVER['REQUEST_ID']);
        $_SERVER['HTTP_X_TRACE_ID'] = "trace\r\nforged-line";
        $_SERVER['HTTP_X_REQUEST_ID'] = 'req-id;DROP--';

        $enriched = $this->invokeEnrich(new Logger(new LogService()), []);

        // هدرهای مخرب هرگز به context لاگ نمی‌رسند؛ request_id یا از مسیر تمیز
        // تأمین می‌شود (تولیدشدهٔ get_request_id) یا امن حذف می‌شود (null) —
        // بسته به کش استاتیک get_request_id در طول سوئیت کامل.
        $this->assertNotSame('req-id;DROP--', $enriched['request_id']);
        $this->assertTrue(
            $enriched['request_id'] === null
            || preg_match(self::CORRELATION_PATTERN, (string) $enriched['request_id']) === 1
        );
        $this->assertSame(1, preg_match(self::CORRELATION_PATTERN, (string) $enriched['trace_id']));
    }

    // ─────────────────────────────────────────────────────────────────────
    // FIX-S4-3 — core/ExceptionHandler.php: fallbackTraceId + مصرف‌کننده‌ها
    // ─────────────────────────────────────────────────────────────────────

    private function invokeFallbackTraceId(): string
    {
        $method = new \ReflectionMethod(ExceptionHandler::class, 'fallbackTraceId');
        $method->setAccessible(true);

        return $method->invoke(null);
    }

    public function test_fallback_trace_id_rejects_malformed_header_and_generates_safe_id(): void
    {
        unset($_SERVER['REQUEST_ID']);
        $_SERVER['HTTP_X_REQUEST_ID'] = "evil\r\nInjected: 1";

        $traceId = $this->invokeFallbackTraceId();

        $this->assertSame(1, preg_match(self::CORRELATION_PATTERN, $traceId));
        $this->assertStringStartsWith('req-', $traceId);
    }

    public function test_fallback_trace_id_accepts_valid_header_and_internal_request_ids(): void
    {
        $_SERVER['HTTP_X_REQUEST_ID'] = 'abc-123.DEF_456';
        $this->assertSame('abc-123.DEF_456', $this->invokeFallbackTraceId());

        // هم‌راستاسازی FIX-S4-3: شناسه‌های داخلی REQ_… (با زیرخط) دیگر رد نمی‌شوند
        $_SERVER['HTTP_X_REQUEST_ID'] = null;
        unset($_SERVER['HTTP_X_REQUEST_ID']);
        $_SERVER['REQUEST_ID'] = 'REQ_20260914120000_ab12cd34';
        $this->assertSame('REQ_20260914120000_ab12cd34', $this->invokeFallbackTraceId());
    }

    public function test_emergency_sentry_jsonl_never_persists_malformed_trace_id(): void
    {
        $_SERVER['HTTP_X_REQUEST_ID'] = "evil\r\nX-Forged: yes";

        $method = new \ReflectionMethod(ExceptionHandler::class, 'logToEmergencySentry');
        $method->setAccessible(true);
        $method->invoke(null, 'S4 verification message', null, 'ERROR', 'S4_TEST');

        $logPath = (function_exists('config') ? config('paths.storage', null) : null);
        $logPath = (is_string($logPath) && $logPath !== '' ? $logPath : dirname(__DIR__, 3) . '/storage') . '/logs/sentry_emergency.jsonl';

        // در چک‌اوت تازه ممکن است پوشهٔ لاگ هنوز ساخته نشده باشد
        if (!is_dir(dirname($logPath))) {
            @mkdir(dirname($logPath), 0775, true);
        }

        $this->assertFileExists($logPath);
        $lines = file($logPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $this->assertNotEmpty($lines);
        $last = json_decode((string) end($lines), true);
        $this->assertIsArray($last);
        $this->assertSame(1, preg_match(self::CORRELATION_PATTERN, (string) $last['trace_id']));
        $this->assertStringNotContainsString('X-Forged', (string) $last['trace_id']);
    }

    public function test_json_payload_meta_trace_id_always_matches_canonical_pattern(): void
    {
        $_SERVER['HTTP_X_REQUEST_ID'] = "evil\r\nX-Forged: yes";

        $payload = ExceptionHandler::getJsonPayloadForException(new \RuntimeException('boom'));

        $this->assertSame(1, preg_match(self::CORRELATION_PATTERN, (string) $payload['meta']['trace_id']));
    }

    public function test_error_contract_uses_middleware_request_id_not_raw_header(): void
    {
        $_SERVER['REQUEST_ID'] = 'server-request-123';
        $_SERVER['HTTP_X_REQUEST_ID'] = 'client-controlled-id';

        $method = new \ReflectionMethod(ErrorContract::class, 'resolveTraceId');
        $method->setAccessible(true);

        $this->assertSame('server-request-123', $method->invoke(null));
    }

    public function test_error_contract_generates_safe_random_trace_id_without_request_id(): void
    {
        unset($_SERVER['REQUEST_ID']);

        $method = new \ReflectionMethod(ErrorContract::class, 'resolveTraceId');
        $method->setAccessible(true);
        $traceId = $method->invoke(null);

        $this->assertSame(1, preg_match('/^req-[a-f0-9]{32}$/', $traceId));
    }

    public function test_project_logger_contract_is_psr3_compatible(): void
    {
        $this->assertTrue(is_subclass_of(\App\Contracts\LoggerInterface::class, \Psr\Log\LoggerInterface::class, true));
        $this->assertInstanceOf(\App\Contracts\LoggerInterface::class, new \App\Support\FallbackLogger());
    }

    // ─────────────────────────────────────────────────────────────────────
    // FIX-S4-4 — app/Services/LogService.php: تک‌خطی‌بودن پیام + UTF-8
    // ─────────────────────────────────────────────────────────────────────

    public function test_log_message_is_forced_to_a_single_line(): void
    {
        $service = new LogService();

        $this->expectOutputRegex('/^\[ERROR\] \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} line1 line2 line3 /');
        $service->error("line1\r\nline2\nline3");
    }

    public function test_log_context_survives_invalid_utf8_values(): void
    {
        $service = new LogService();

        $this->expectOutputRegex('/"user":"\\\\ufffd1"/');
        $service->error('utf8 probe', ['user' => "\xB1" . '1']);
    }

    public function test_querybuilder_failure_logging_redacts_bindings_payloads_and_exception_messages(): void
    {
        if (!in_array('sqlite', \PDO::getAvailableDrivers(), true)) {
            $this->markTestSkipped('SQLite PDO driver is required for the isolated QueryBuilder logging test.');
        }

        $logger = $this->createMock(LoggerInterface::class);
        $contexts = [];
        $logger->expects($this->exactly(2))
            ->method('error')
            ->with(
                $this->callback(static fn ($event): bool => in_array($event, [
                    'database.builder.query.failed',
                    'database.update.failed',
                ], true)),
                $this->callback(function ($context) use (&$contexts): bool {
                    if (!is_array($context) || array_key_exists('error', $context)) {
                        return false;
                    }
                    $contexts[] = $context;
                    return true;
                })
            );

        $container = app()->container;
        $originalLogger = $container->make(LoggerInterface::class);
        $container->instance(LoggerInterface::class, $logger);

        try {
            $pdo = new \PDO('sqlite::memory:');

            try {
                (new QueryBuilder($pdo))
                    ->table('missing_table')
                    ->where('token', '=', 'secret-token')
                    ->get();
                $this->fail('The missing-table SELECT should fail.');
            } catch (\PDOException) {
                // Expected: only the logging payload is under test here.
            }

            try {
                (new QueryBuilder($pdo))
                    ->table('missing_table')
                    ->where('token', '=', 'secret-token')
                    ->update(['password' => 'secret-password']);
                $this->fail('The missing-table UPDATE should fail.');
            } catch (\PDOException) {
                // Expected: only the logging payload is under test here.
            }
        } finally {
            $container->instance(LoggerInterface::class, $originalLogger);
        }

        $this->assertCount(2, $contexts);
        $encodedContexts = json_encode($contexts, JSON_THROW_ON_ERROR);
        $this->assertStringNotContainsString('secret-token', $encodedContexts);
        $this->assertStringNotContainsString('secret-password', $encodedContexts);
        $this->assertStringNotContainsString('no such table', $encodedContexts);
        $this->assertSame(['[redacted]'], $contexts[0]['bindings']);
        $this->assertSame(['password' => '[redacted]'], $contexts[1]['data']);
    }

    // ─────────────────────────────────────────────────────────────────────
    // FIX-S4-5 — core/Validator.php: numeric سازگار با bcmath + accessors
    // ─────────────────────────────────────────────────────────────────────

    public function test_numeric_rule_rejects_exponent_notation_without_crashing(): void
    {
        // پیش از فیکس: is_numeric می‌پذیرفت و bccomp در شاخهٔ min با ValueError کرش می‌کرد (۵۰۰)
        $validator = Validator::create(['amount' => '1e999'], ['amount' => 'numeric|min:1']);

        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('amount', $validator->errors());
        $this->assertContains('این فیلد باید عددی باشد', $validator->errors()['amount']);
    }

    public function test_numeric_rule_rejects_non_bcmath_strings_and_accepts_plain_decimals(): void
    {
        $this->assertTrue(Validator::create(['a' => '1e5'], ['a' => 'numeric'])->fails());
        $this->assertTrue(Validator::create(['a' => ' 12'], ['a' => 'numeric'])->fails());
        $this->assertTrue(Validator::create(['a' => '0x1A'], ['a' => 'numeric'])->fails());
        $this->assertTrue(Validator::create(['a' => '1,5'], ['a' => 'numeric'])->fails());

        $this->assertFalse(Validator::create(['a' => '1.5'], ['a' => 'numeric|min:1'])->fails());
        $this->assertFalse(Validator::create(['a' => '-3'], ['a' => 'numeric|min:-10'])->fails());
        $this->assertFalse(Validator::create(['a' => '12'], ['a' => 'numeric|max:100'])->fails());
        $this->assertFalse(Validator::create(['a' => '.75'], ['a' => 'numeric'])->fails());
        $this->assertFalse(Validator::create(['a' => 150], ['a' => 'numeric|min:1'])->fails());
        $this->assertFalse(Validator::create(['a' => 1.5], ['a' => 'numeric'])->fails());
    }

    public function test_min_and_max_numeric_branches_never_reach_bccomp_with_malformed_values(): void
    {
        // حتی بدون rule عددیِ ردکننده، شاخهٔ min/max نباید ValueError پرتاب کند
        $min = Validator::create(['amount' => '1e999'], ['amount' => 'numeric|min:1']);
        $this->assertTrue($min->fails());

        $max = Validator::create(['amount' => '1e999'], ['amount' => 'numeric|max:100']);
        $this->assertTrue($max->fails());
    }

    public function test_accessors_return_default_for_non_finite_numerics(): void
    {
        $validator = Validator::create([
            'bad_exp' => '1e999',
            'good_decimal' => '12.5',
            'good_int' => '42',
            'negative' => '-7.25',
        ], []);

        $this->assertSame(0, $validator->int('bad_exp', 0));
        $this->assertSame(5.0, $validator->float('bad_exp', 5.0));
        $this->assertSame(12.5, $validator->float('good_decimal', 0.0));
        $this->assertSame(42, $validator->int('good_int', 0));
        $this->assertSame(-7.25, $validator->float('negative', 0.0));
        $this->assertSame(9, $validator->int('missing', 9));
    }

    public function test_accessors_accept_plain_decimal_strings_only(): void
    {
        $validator = Validator::create([
            'sci' => '1e5',
            'spacey' => ' 12',
            'hexish' => '0x1A',
        ], []);

        $this->assertSame(0.0, $validator->float('sci', 0.0));
        $this->assertSame(0, $validator->int('spacey', 0));
        $this->assertSame(0.0, $validator->float('hexish', 0.0));
    }
}
