<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Exceptions\HttpResponseException;
use Core\Response;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

class ResponseTest extends TestCase
{
    public function testSetHeaderRejectsInvalidHeaderName(): void
    {
        $response = new Response();

        $this->expectException(InvalidArgumentException::class);
        $response->setHeader("Bad\r\nName", 'value');
    }

    public function testJsonResponseThrowsHttpResponseExceptionWithCorrectPayload(): void
    {
        $response = new Response();

        try {
            $response->json(['success' => true, 'message' => 'ok'], 201);
            $this->fail('Expected HttpResponseException was not thrown');
        } catch (HttpResponseException $e) {
            $sentResponse = $e->getResponse();
            $this->assertSame(201, $sentResponse->getStatusCode());
            $expected = json_encode(['success' => true, 'message' => 'ok'], JSON_UNESCAPED_UNICODE);
            $this->assertIsString($expected);
            $this->assertJsonStringEqualsJsonString(
                $expected,
                $sentResponse->getContent()
            );
        }
    }

    public function testNoContentThrowsHttpResponseExceptionWithStatus204(): void
    {
        $response = new Response();

        try {
            $response->noContent();
            $this->fail('Expected HttpResponseException was not thrown');
        } catch (HttpResponseException $e) {
            $sentResponse = $e->getResponse();
            $this->assertSame(204, $sentResponse->getStatusCode());
            $this->assertSame('', $sentResponse->getContent());
        }
    }

    public function testRedirectRejectsOpenRedirectOutsideSameDomain(): void
    {
        $response = new Response();
        $_SERVER['HTTP_HOST'] = 'localhost';
        $_SERVER['REQUEST_URI'] = '/';

        $this->expectException(InvalidArgumentException::class);
        $response->redirect('http://evil.com', 302);
    }

    public function testRedirectExternalAllowsAbsoluteUrl(): void
    {
        $response = new Response();
        $_SERVER['HTTP_HOST'] = 'localhost';
        $_SERVER['REQUEST_URI'] = '/';

        try {
            $response->redirectExternal('https://accounts.google.com/o/oauth2/v2/auth?test=1');
            $this->fail('Expected HttpResponseException was not thrown');
        } catch (HttpResponseException $e) {
            $sentResponse = $e->getResponse();
            $this->assertSame(302, $sentResponse->getStatusCode());
        }
    }

    public function testDownloadRejectsPathTraversalOutsideAllowedPaths(): void
    {
        $response = new Response();
        $tmpFile = tempnam(sys_get_temp_dir(), 'chortke_test_');
        file_put_contents($tmpFile, 'test');

        $this->expectException(InvalidArgumentException::class);
        $response->download($tmpFile, 'download.txt');
    }

    public function testStatusCodeValidationRejectsBadStatusCode(): void
    {
        $response = new Response();

        $this->expectException(InvalidArgumentException::class);
        $response->setStatusCode(700);
    }

    public function testRedirectLocationHonorsConfiguredBasePath(): void
    {
        // 16-W (گزینهٔ ۳): redirect('/dashboard') در هر دو حالت نصب Location درست می‌سازد —
        // base_path خالی → بدون پیشوند؛ '/chortke' → پیشونددار. نکته: UrlGenerator در
        // bootstrap به‌عنوان singletonِ immutable (طبق قرارداد AppServiceProvider) resolve
        // می‌شود، پس حالت دوم با instance-swap کانتینر شبیه‌سازی می‌شود (الگوی رایج
        // S14ControllerGatePinningTest) — config_set روی singleton زنده اثری ندارد.
        $container = app(\Core\Container::class);
        $originalGenerator = $container->make(\Core\UrlGenerator::class);
        $_SERVER['HTTP_HOST'] = '127.0.0.1:8090';
        $_SERVER['REQUEST_URI'] = '/dashboard';

        try {
            // حالت ۱: نصب ریشهٔ دامنه (APP_BASE_PATH خالی) → Location بدون پیشوند
            $container->instance(
                \Core\UrlGenerator::class,
                new \Core\UrlGenerator('http://127.0.0.1:8090', null, '', 'testing')
            );
            $response = new Response();
            try {
                $response->redirect('/dashboard', 302);
                $this->fail('Expected HttpResponseException was not thrown');
            } catch (HttpResponseException $e) {
                $sent = $e->getResponse();
                $this->assertSame(302, $sent->getStatusCode());
                $this->assertSame('http://127.0.0.1:8090/dashboard', $sent->getHeader('Location'));
            }

            // حالت ۲: نصب زیرپوشه (APP_BASE_PATH=/chortke) → Location پیشونددار
            $container->instance(
                \Core\UrlGenerator::class,
                new \Core\UrlGenerator('http://127.0.0.1:8090', null, '/chortke', 'testing')
            );
            $response = new Response();
            try {
                $response->redirect('/dashboard', 302);
                $this->fail('Expected HttpResponseException was not thrown');
            } catch (HttpResponseException $e) {
                $sent = $e->getResponse();
                $this->assertSame(302, $sent->getStatusCode());
                $this->assertSame('http://127.0.0.1:8090/chortke/dashboard', $sent->getHeader('Location'));
            }
        } finally {
            $container->instance(\Core\UrlGenerator::class, $originalGenerator);
        }
    }
}
