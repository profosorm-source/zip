<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Cache;
use Core\CircuitBreaker;
use Core\EventDispatcher;
use Core\Exceptions\CircuitBreakerOpenException;
use Core\Logger;
use Core\RetryPolicy;
use Mockery as m;
use PHPUnit\Framework\TestCase;
use RuntimeException;

/**
 * بچ S7 — لنز DoS/وضعیت روی هستهٔ تاب‌آوری (CircuitBreaker/RetryPolicy)
 *
 * FIX-S7-1: خطای state-store در recordFailure نباید استثنای «اصلیِ» عملیات را
 *           جایگزین کند و fallback را دور بزند (قرارداد call() حفظ شود).
 * FIX-S7-2: گارد fail-fast در RetryPolicy نباید خودش در قطعی state-store
 *           استثنا بدهد؛ فقط پاسخ قطعی «open» باید fail-fast شود.
 */
final class S7CoreSecurityHardeningTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /* ═══════════════ FIX-S7-1 — CircuitBreaker::recordFailure ═══════════════ */

    public function test_s7_1_state_store_failure_preserves_fallback_with_original_exception(): void
    {
        $cache = m::mock(Cache::class);
        $logger = m::mock(Logger::class);
        $events = m::mock(EventDispatcher::class);

        // وضعیت مدار «closed» خوانده می‌شود؛ سپس ثبت شکست با خطای state-store می‌میرد
        $cache->shouldReceive('get')->with('circuit_breaker:payment:status', 'closed')->andReturn('closed');
        $cache->shouldReceive('increment')->andThrow(new RuntimeException('redis down mid-flight'));
        // FIX-S7-1: خرابی state فقط لاگ می‌شود (قرارداد تازه)
        $logger->shouldReceive('error')->with('circuit_breaker.state_update_failed', m::on(
            static fn(array $context): bool => $context['service'] === 'payment'
                && $context['error'] === 'redis down mid-flight'
        ))->once();

        $breaker = new CircuitBreaker($cache, $logger, $events, [
            'payment' => ['threshold' => 5, 'timeout' => 60],
        ]);

        $original = new RuntimeException('payment gateway timeout');
        $captured = null;

        $result = $breaker->call('payment', function () use ($original): never {
            throw $original;
        }, function (\Throwable $e) use (&$captured) {
            $captured = $e;
            return 'fallback-response';
        });

        $this->assertSame('fallback-response', $result);
        $this->assertSame($original, $captured, 'fallback باید عین استثنای اصلی عملیات را بگیرد، نه خطای state-store');
    }

    public function test_s7_1_state_store_failure_rethrows_original_exception_without_fallback(): void
    {
        $cache = m::mock(Cache::class);
        $logger = m::mock(Logger::class);
        $events = m::mock(EventDispatcher::class);

        $cache->shouldReceive('get')->andReturn('closed');
        $cache->shouldReceive('increment')->andThrow(new RuntimeException('redis down mid-flight'));
        $logger->shouldReceive('error')->with('circuit_breaker.state_update_failed', m::type('array'))->once();

        $breaker = new CircuitBreaker($cache, $logger, $events, [
            'payment' => ['threshold' => 5, 'timeout' => 60],
        ]);

        try {
            $breaker->call('payment', function (): never {
                throw new RuntimeException('payment gateway timeout');
            });
            $this->fail('استثنای اصلی عملیات باید مجدداً پرتاب می‌شد');
        } catch (RuntimeException $e) {
            $this->assertSame('payment gateway timeout', $e->getMessage(), 'خطای state-store نباید جایگزین استثنای اصلی شود');
        }
    }

    public function test_s7_1_normal_trip_to_open_still_works_after_fix(): void
    {
        $cache = m::mock(Cache::class);
        $logger = m::mock(Logger::class);
        $events = m::mock(EventDispatcher::class);

        // فراخوانی اول: عملیات شکست می‌خورد، شمارنده ۱ و آستانه ۱ ⇒ trip به OPEN
        $cache->shouldReceive('get')->with('circuit_breaker:svc:status', 'closed')->andReturn('closed')->once();
        $cache->shouldReceive('increment')->with('circuit_breaker:svc:failures', 1, 30)->andReturn(1)->once();
        $cache->shouldReceive('putSeconds')->with('circuit_breaker:svc:status', 'open', 60)->once();
        $cache->shouldReceive('putSeconds')->with(m::pattern('/opened_at$/'), m::type('int'), 60)->once();
        $logger->shouldReceive('error')->with('circuit_breaker.failure', m::type('array'))->once();
        $logger->shouldReceive('critical')->with('circuit_breaker.tripped_open', m::type('array'))->once();
        $logger->shouldReceive('warning')->with('circuit_breaker.open', m::type('array'))->once();
        $events->shouldReceive('dispatch')->with('circuit_breaker.opened', m::type('array'))->once();

        $breaker = new CircuitBreaker($cache, $logger, $events, [
            'svc' => ['threshold' => 1, 'timeout' => 30],
        ]);

        try {
            $breaker->call('svc', function (): never {
                throw new RuntimeException('boom');
            });
            $this->fail('عملیات شکسته باید پرتاب می‌شد');
        } catch (RuntimeException $e) {
            $this->assertSame('boom', $e->getMessage());
        }

        // فراخوانی دوم: وضعیت «open» و timeout منقضی نشده ⇒ ردّ سریع با CircuitBreakerOpenException
        $cache->shouldReceive('get')->with('circuit_breaker:svc:status', 'closed')->andReturn('open')->once();
        $cache->shouldReceive('get')->with('circuit_breaker:svc:opened_at', 0)->andReturn(time())->once();

        $fallbackArg = null;
        $result = $breaker->call('svc', function (): string {
            $this->fail('عملیات نباید در وضعیت OPEN اجرا شود');
            return 'unreachable';
        }, function (\Throwable $e) use (&$fallbackArg): string {
            $fallbackArg = $e;
            return 'degraded';
        });

        $this->assertSame('degraded', $result);
        $this->assertInstanceOf(CircuitBreakerOpenException::class, $fallbackArg);
    }

    /* ═══════════════ FIX-S7-2 — RetryPolicy fail-fast tolerance ═══════════════ */

    public function test_s7_2_open_circuit_state_store_failure_lets_operation_run(): void
    {
        $breaker = m::mock(CircuitBreaker::class);
        // قطعی state-store در لحظهٔ خواندن وضعیت مدار
        $breaker->shouldReceive('isOpen')->andThrow(new RuntimeException('redis down mid-flight'));

        $policy = new RetryPolicy($breaker);

        $executed = false;
        $result = $policy->executeWithContext('payment:charge', function () use (&$executed): string {
            $executed = true;
            return 'operation-ok';
        });

        $this->assertTrue($executed, 'در خرابی state، بهینه‌سازی fail-fast نباید عملیات را مسدود کند');
        $this->assertSame('operation-ok', $result);
    }

    public function test_s7_2_definitive_open_status_still_fails_fast_without_running_operation(): void
    {
        $breaker = m::mock(CircuitBreaker::class);
        $breaker->shouldReceive('isOpen')->andReturn(true)->once();

        $policy = new RetryPolicy($breaker);

        $executed = false;
        try {
            $policy->executeWithContext('payment:charge', function () use (&$executed): string {
                $executed = true;
                return 'operation-ok';
            });
            $this->fail('وضعیت قطعی OPEN باید fail-fast می‌شد');
        } catch (RuntimeException $e) {
            $this->assertSame(503, $e->getCode());
            $this->assertStringContainsString('Circuit Breaker is OPEN', $e->getMessage());
        }

        $this->assertFalse($executed, 'عملیات نباید در fail-fast اجرا شود');
    }

    public function test_s7_2_closed_circuit_keeps_normal_execution_path(): void
    {
        $breaker = m::mock(CircuitBreaker::class);
        $breaker->shouldReceive('isOpen')->andReturn(false)->once();

        $policy = new RetryPolicy($breaker);

        $this->assertSame('normal-path', $policy->executeWithContext('email:send', function (): string {
            return 'normal-path';
        }));
    }
}
