<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use PHPUnit\Framework\TestCase;

/**
 * چرخهٔ اصلاحی 2026-10-28 (بستن دو یافتهٔ جانبی QA چرخهٔ R18) — FIX-R21-MSG.
 *
 * باگ: RateLimitPolicy::tooManyResponse() همیشه پیام عمومی هاردکد می‌فرستاد؛
 * فیلد message کانفیگ پالیسی‌ها (rate_limits.{group}.{endpoint}.message — بیش از
 * ۲۵ پیام اختصاصی) توسط resolveActionConfig خوانده می‌شد اما هرگز رندر نمی‌شد.
 *
 * خودِ tooManyResponse در پایان exit دارد و در-پروسه در PHPUnit قابل فراخوانی
 * نیست؛ رزولور پیام به‌صورت متد خالص (resolveTooManyMessage) استخراج شد تا
 * مستقیم پین شود + پین ساختاری سیم‌کشی tooManyResponse → رزولور.
 * (هم‌مسیر R18CameraFixesPinningTest — پین پالیسی در Tests\Unit\Core)
 *
 * @group r21
 */
final class RateLimitPolicyMessageTest extends TestCase
{
    private \App\Policies\RateLimitPolicy $policy;

    protected function setUp(): void
    {
        $this->policy = \Core\Container::getInstance()->make(\App\Policies\RateLimitPolicy::class);
    }

    /**
     * @test
     */
    public function camera_verify_renders_its_configured_message(): void
    {
        // قرارداد FIX-CAM-VERIFY-CAP (چرخهٔ R18): پیام اختصاصی تأیید دوربین
        $expected = (string)config('rate_limits.camera_challenge.verify.message');
        self::assertNotSame('', $expected, 'پیام کانفیگ camera_challenge.verify باید تعریف شده باشد');

        self::assertSame(
            $expected,
            $this->policy->resolveTooManyMessage('camera_verify', 3600),
            'پیام ۴۲۹ camera_verify باید پیام اختصاصی کانفیگ باشد، نه پیام عمومی'
        );
    }

    /**
     * @test
     */
    public function kyc_submit_renders_its_configured_message(): void
    {
        $expected = (string)config('rate_limits.kyc.submit.message');
        self::assertNotSame('', $expected, 'پیام کانفیگ kyc.submit باید تعریف شده باشد');

        self::assertSame(
            $expected,
            $this->policy->resolveTooManyMessage('kyc_submit', 86400),
            'پیام ۴۲۹ kyc_submit باید پیام اختصاصی کانفیگ باشد'
        );
    }

    /**
     * @test
     */
    public function action_without_config_message_falls_back_to_generic_with_minutes(): void
    {
        // اکشن ناشناخته → مسیر legacy بدون message → پیام عمومی + دقیقهٔ گردشده
        $msg90s = $this->policy->resolveTooManyMessage('r21_missing_action', 90);
        self::assertStringContainsString('بیش از حد مجاز', $msg90s, 'fallback عمومی');
        self::assertStringContainsString('2 دقیقه', $msg90s, 'ceil(90s/60)=2 دقیقه');

        $msg1h = $this->policy->resolveTooManyMessage('r21_missing_action', 3600);
        self::assertStringContainsString('60 دقیقه', $msg1h, 'ceil(3600s/60)=60 دقیقه');
    }

    /**
     * @test
     */
    public function every_action_map_entry_with_config_message_is_renderable(): void
    {
        // جاروی پوشش: هر اکشن action_map که کانفیگش message دارد، باید همان را برگرداند
        $map = (array)config('rate_limits.action_map');
        self::assertNotEmpty($map);

        $checked = 0;
        foreach ($map as $action => $target) {
            if (!is_string($action) || !is_array($target)) {
                continue;
            }
            $cfg = config('rate_limits.' . ($target[0] ?? '') . '.' . ($target[1] ?? ''));
            if (!is_array($cfg) || !is_string($cfg['message'] ?? null) || trim((string)$cfg['message']) === '') {
                continue;
            }
            $resolved = $this->policy->resolveTooManyMessage((string)$action, 60);
            self::assertSame(
                (string)$cfg['message'],
                $resolved,
                "اکشن {$action} باید پیام اختصاصی کانفیگش را رندر کند"
            );
            $checked++;
        }
        self::assertGreaterThan(10, $checked, 'بیش از ۱۰ اکشن دارای پیام اختصاصی باید پوشش داده شوند');
    }

    /**
     * @test
     */
    public function too_many_response_wires_resolver_and_unicode_json(): void
    {
        // پین ساختاری سیم‌کشی (خود tooManyResponse به‌خاطر exit در-پروسه تست نمی‌شود):
        $src = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Policies/RateLimitPolicy.php');
        self::assertStringContainsString(
            '$message = $this->resolveTooManyMessage($action, $retryAfter);',
            $src,
            'tooManyResponse باید پیام را از resolveTooManyMessage بگیرد (FIX-R21-MSG)'
        );
        self::assertStringContainsString(
            'JSON_UNESCAPED_UNICODE',
            $src,
            'خروجی JSON باید JSON_UNESCAPED_UNICODE داشته باشد (هم‌سبک RateLimitMiddleware/Response::json)'
        );
        // پیام در شاخهٔ HTML هم باید رندر شود (قبلاً فقط <h1> خالی بود)
        self::assertStringContainsString(
            "htmlspecialchars(\$message, ENT_QUOTES, 'UTF-8')",
            $src,
            'شاخهٔ HTML باید پیام (escape‌شده) را هم نشان دهد'
        );
    }
}
