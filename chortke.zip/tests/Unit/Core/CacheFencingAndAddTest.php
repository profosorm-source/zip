<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Cache;
use PHPUnit\Framework\TestCase;

/**
 * FIX-36/W2-D2 — پین‌های موج رفع ۲:
 *
 * F-A11-01: پریمیتیوهای fencing روی قفل هسته (توکن مونوتونیک + withLock
 * fence-aware + validateFence CAS-max per-resource) — backward-compatible.
 *
 * F-A9a-01: قرارداد add() (SET NX + TTL ثانیه‌ای) روی پریمیتیو Core\Cache
 * (سمت قرارداد CacheInterface در CacheManagerContractAndDegradationTest پین شده).
 *
 * همهٔ تست‌ها روی درایور فایل (بدون Redis) اجرا می‌شوند — deterministic.
 */
class CacheFencingAndAddTest extends TestCase
{
    private string $cacheDir;
    private Cache $cache;

    protected function setUp(): void
    {
        $this->cacheDir = sys_get_temp_dir() . '/chortke_cache_fence_test/';
        $this->cleanupCacheDir();
        $this->cache = new Cache(null, $this->cacheDir);
    }

    protected function tearDown(): void
    {
        $this->cache->flushAllLocks();
        $this->cleanupCacheDir();
    }

    // ───────────────────────── F-A11-01: fencing ─────────────────────────

    public function testNextFenceTokenIsPositiveAndMonotonic(): void
    {
        $t1 = $this->cache->nextFenceToken();
        $t2 = $this->cache->nextFenceToken();
        $t3 = $this->cache->nextFenceToken();

        $this->assertGreaterThan(0, $t1);
        $this->assertGreaterThan($t1, $t2);
        $this->assertGreaterThan($t2, $t3);
    }

    public function testValidateFenceRejectsStaleHolderAndAcceptsNewest(): void
    {
        // CAS-max per-resource: هر توکن جدیدتر می‌پذیرد، توکن کهنه رد می‌شود.
        $this->assertTrue($this->cache->validateFence('wallet:1', 5));
        $this->assertSame(5, $this->cache->currentFence('wallet:1'));

        $this->assertFalse($this->cache->validateFence('wallet:1', 4), 'stale holder must be rejected');
        $this->assertFalse($this->cache->validateFence('wallet:1', 1));

        $this->assertTrue($this->cache->validateFence('wallet:1', 5), 'equal re-validation is allowed (same holder)');
        $this->assertTrue($this->cache->validateFence('wallet:1', 6), 'newest holder passes');
        $this->assertSame(6, $this->cache->currentFence('wallet:1'));
    }

    public function testValidateFenceRejectsNonPositiveToken(): void
    {
        $this->assertFalse($this->cache->validateFence('wallet:2', 0));
        $this->assertFalse($this->cache->validateFence('wallet:2', -3));
        $this->assertSame(0, $this->cache->currentFence('wallet:2'));
    }

    public function testFencesAreIsolatedPerResource(): void
    {
        $this->assertTrue($this->cache->validateFence('resA', 10));
        $this->assertSame(0, $this->cache->currentFence('resB'), 'resource B has its own high-water mark');
        $this->assertTrue($this->cache->validateFence('resB', 1), 'low token on a fresh resource is valid');
        $this->assertFalse($this->cache->validateFence('resA', 2), 'but still stale on resource A');
    }

    public function testWithLockPassesMonotonicFenceTokenToFencingAwareCallback(): void
    {
        $seen = null;
        $result = $this->cache->withLock('order:7', function (int $fence) use (&$seen) {
            $seen = $fence;
            // مصرف‌کنندهٔ fence-aware: قبل از نوشتار، fence خودش را اعتبارسنجی می‌کند.
            return $this->cache->validateFence('order:7', $fence) ? 'committed' : 'stale-rejected';
        }, 5);

        $this->assertSame('committed', $result);
        $this->assertIsInt($seen);
        $this->assertGreaterThan(0, $seen);

        // نگهدارندهٔ کهنه (توکن کوچک‌تر) پس از انقضای قفل رد می‌شود — سناریوی F-A11-01.
        $stale = $seen;
        $this->cache->withLock('order:7', function (int $fence) {
            // نگهدارندهٔ دوم (fencing-aware) توکن بزرگ‌تر می‌گیرد و قبل از نوشتار
            // high-water mark را جلو می‌برد.
            return $this->cache->validateFence('order:7', $fence);
        }, 5);
        $this->assertFalse(
            $this->cache->validateFence('order:7', $stale),
            'expired-lock stale holder with old fence token must be rejected'
        );
    }

    public function testWithLockBackwardCompatibleForParameterlessCallback(): void
    {
        $calls = 0;
        $result = $this->cache->withLock('plain:1', function () use (&$calls) {
            $calls++;
            return 'plain';
        }, 5);

        $this->assertSame('plain', $result);
        $this->assertSame(1, $calls);
        // بدون پارامتر، INCR اضافه‌ای صادر نمی‌شود (هزینهٔ صفر برای مصرف‌کننده‌های فعلی).
    }

    // ───────────────────────── F-A9a-01: add() primitive ─────────────────────────

    public function testAddClaimsAtomicallyAndIsIdempotentGuard(): void
    {
        $this->assertTrue($this->cache->add('dedupe:banner:1', 1, 35), 'first claim wins');
        $this->assertFalse($this->cache->add('dedupe:banner:1', 1, 35), 'second claim on live key loses');
        $this->assertSame(1, $this->cache->get('dedupe:banner:1'), 'claimed value is readable');

        $this->assertTrue($this->cache->forget('dedupe:banner:1'));
        $this->assertTrue($this->cache->add('dedupe:banner:1', 2, 35), 'after release the claim is acquirable again');
        $this->assertSame(2, $this->cache->get('dedupe:banner:1'));
    }

    public function testAddRejectsNonPositiveTtl(): void
    {
        // پین S27: TTL غیرمثبت = InvalidArgumentException (نه forget خاموش).
        $this->expectException(\InvalidArgumentException::class);
        $this->cache->add('bad_ttl', 1, 0);
    }

    public function testAddSupportsArraysLikeRegularCacheWrite(): void
    {
        $this->assertTrue($this->cache->add('payload:1', ['k' => 'v'], 10));
        $this->assertSame(['k' => 'v'], $this->cache->get('payload:1'));
    }

    private function cleanupCacheDir(): void
    {
        if (!is_dir($this->cacheDir)) {
            return;
        }
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($this->cacheDir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $file) {
            $file->isDir() ? @rmdir($file->getPathname()) : @unlink($file->getPathname());
        }
        @rmdir($this->cacheDir);
    }
}
