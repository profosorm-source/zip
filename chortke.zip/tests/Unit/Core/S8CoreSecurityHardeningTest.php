<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Encryption;
use Core\PathResolver;
use Core\Redis;
use Core\RedisSessionHandler;
use Core\Session;
use PHPUnit\Framework\TestCase;
use RuntimeException;

/**
 * بچ S8 — لنز نشست/رمزنگاری روی Session/RedisSessionHandler/Encryption/Redis
 *
 * FIX-S8-1: Redis::scanKeys پارامتر محافظ $maxIterations را هرگز اعمال نمی‌کرد
 *           (dead code) — فراخواننده‌های مسیر داغ (DirectMessageQueryService)
 *           در عمل حلقهٔ بدون‌سقف می‌گرفتند: با OPT_SCAN=SCAN_RETRY هر poll
 *           یک اسکن کامل keyspace روی نمونهٔ پرحجم — تقویت‌کنندهٔ CPU/latency
 *           (لنز DoS).
 * FIX-S8-2: Encryption::redact با keepLength منفی قرارداد «حداکثر N کاراکتر
 *           پایانی» را می‌شکست و دمِ مقدار حساس را لو می‌داد.
 *
 * پوشش لنز نشست: اعتبارسنجی شناسهٔ session (مسیر فایل/کلید Redis)، قراردادهای
 * مرزی کانفیگ (name/lifetime/samesite/boolean) در مرز Session.
 */
final class S8CoreSecurityHardeningTest extends TestCase
{
    private ?string $tempBase = null;

    private function rrmdir(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        foreach (scandir($dir) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $path = $dir . '/' . $entry;
            is_dir($path) && !is_link($path) ? $this->rrmdir($path) : @unlink($path);
        }
        @rmdir($dir);
    }

    protected function tearDown(): void
    {
        if ($this->tempBase !== null && is_dir($this->tempBase)) {
            $this->rrmdir($this->tempBase);
            $this->tempBase = null;
        }
        parent::tearDown();
    }

    /* ═══════════════ FIX-S8-1 — Redis::scanKeys cap ═══════════════ */

    /**
     * کلاینت \Redis به‌صورت mock (بدون اتصال) داخل wrapper تزریق می‌شود تا
     * قرارداد حلقهٔ SCAN مستقل از signature نسخهٔ نصب‌شدهٔ phpredis آزموده شود.
     *
     * @param list<list<string>|false> $pages خروجی هر فراخوان scan (به ترتیب)
     * @return array{0: Redis, 1: object, 2: \Closure():int} (wrapper, fake client, شمارنده)
     */
    private function makeWrapperWithMock(array $pages): array
    {
        $state = (object)[
            'pages' => $pages,
            'idx' => 0,
            'scanCalls' => 0,
        ];
        $fake = \Mockery::mock(\Redis::class);
        $fake->shouldReceive('scan')->andReturnUsing(function (&$iterator, $pattern = null, $count = 0) use ($state): array|false {
            $state->scanCalls++;
            if ($state->idx < count($state->pages)) {
                return $state->pages[$state->idx++];
            }
            return false;
        });

        $rc = new \ReflectionClass(Redis::class);
        /** @var Redis $wrapper */
        $wrapper = $rc->newInstanceWithoutConstructor();
        $clientProp = $rc->getProperty('client');
        $clientProp->setAccessible(true);
        $clientProp->setValue($wrapper, $fake);
        $connectedProp = $rc->getProperty('connected');
        $connectedProp->setAccessible(true);
        $connectedProp->setValue($wrapper, true);

        return [$wrapper, $fake, static function () use ($state): int { return $state->scanCalls; }];
    }

    /** @return list<string> */
    private function keyBatch(string $prefix, int $n): array
    {
        $batch = [];
        for ($i = 0; $i < $n; $i++) {
            $batch[] = $prefix . ':' . $i;
        }
        return $batch;
    }

    public function test_s8_1_scan_keys_honors_max_iterations_cap(): void
    {
        // ۵ دستهٔ ۱۰تایی موجود است؛ کپ ۳ ⇒ فقط ۳ دسته جمع می‌شود و scan
        // دقیقاً ۳ بار صدا زده می‌شود (رفتار قبل از فیکس: ۵۰ کلید/۵ فراخوان).
        [$wrapper, $mock, $callCount] = $this->makeWrapperWithMock([
            $this->keyBatch('s8scan', 10),
            $this->keyBatch('s8scan', 10),
            $this->keyBatch('s8scan', 10),
            $this->keyBatch('s8scan', 10),
            $this->keyBatch('s8scan', 10),
            false,
        ]);

        $keys = $wrapper->scanKeys('s8scan:*', 10, 3);

        $this->assertCount(30, $keys, 'cap ۳ دسته‌ای باید دقیقاً اعمال شود');
        $this->assertSame(3, $callCount(), 'scan نباید بیش از سقف فراخوان شود');
        $this->assertNotContains('s8scan:39', $keys, 'کلیدهای دستهٔ چهارم/پنجم نباید جمع شده باشند');
    }

    public function test_s8_1_scan_keys_default_zero_keeps_unbounded_behavior(): void
    {
        // مسیرهای cleanup/WebSocket بدون سقف صدا می‌زنند — رفتار قبلی باید دست‌نخورده بماند.
        [$wrapper, $mock, $callCount] = $this->makeWrapperWithMock([
            $this->keyBatch('s8scan', 10),
            $this->keyBatch('s8scan', 10),
            $this->keyBatch('s8scan', 10),
            $this->keyBatch('s8scan', 10),
            $this->keyBatch('s8scan', 10),
            false,
        ]);

        $keys = $wrapper->scanKeys('s8scan:*', 10);

        $this->assertCount(50, $keys);
        // ۵ فراخوان دسته + ۱ فراخوان پایانی که false برمی‌گرداند (پایان SCAN).
        $this->assertSame(6, $callCount());
    }

    public function test_s8_1_scan_keys_single_batch_cap_returns_first_batch_only(): void
    {
        [$wrapper, $mock, $callCount] = $this->makeWrapperWithMock([
            $this->keyBatch('s8scan', 7),
            $this->keyBatch('s8scan', 7),
            false,
        ]);

        $keys = $wrapper->scanKeys('s8scan:*', 7, 1);

        $this->assertCount(7, $keys);
        $this->assertSame(1, $callCount());
    }

    /* ═══════════════ FIX-S8-2 — Encryption::redact clamp ═══════════════ */

    public function test_s8_2_redact_negative_keep_length_leaks_nothing(): void
    {
        $enc = new Encryption();

        // قبل از فیکس: ۱۲ ستاره + «ret123» (۶ کاراکتر لو رفته بود).
        $this->assertSame('**********', $enc->redact('1234567890', -3));
        $this->assertSame('******', $enc->redact('secret', -1));
        $this->assertStringNotContainsString('7', $enc->redact('1234567890', -3));
    }

    public function test_s8_2_redact_zero_and_positive_keep_contract_unchanged(): void
    {
        $enc = new Encryption();

        $this->assertSame('****', $enc->redact('1234', 0)); // کلاً ماسک
        $this->assertSame('******7890', $enc->redact('1234567890', 4)); // قرارداد عادی
        $this->assertSame('****', $enc->redact('1234', 4)); // len == keep
        $this->assertSame('***', $enc->redact('123', 4));   // len < keep
    }

    /* ═══════════════ لنز نشست — مرز کانفیگ Session ═══════════════ */

    /**
     * فراخوانی متد خصوصی Session از طریق Reflection (بدون any state change).
     * @param list<mixed> $args
     */
    private function callSessionMethod(string $method, array $args): mixed
    {
        $ref = new \ReflectionMethod(Session::class, $method);
        $ref->setAccessible(true);
        return $ref->invoke(Session::getInstance(), ...$args);
    }

    public function test_s8_session_name_boundary_rejects_injection_shapes(): void
    {
        $this->assertSame('CHORTKE_SESSION', $this->callSessionMethod('resolveSessionName', [null]));
        $this->assertSame('CHORTKE_ADM_SESS', $this->callSessionMethod('resolveSessionName', ['CHORTKE_ADM_SESS']));

        $this->expectException(\InvalidArgumentException::class);
        $this->callSessionMethod('resolveSessionName', ["evil\r\nSet-Cookie: x"]);
    }

    public function test_s8_session_lifetime_boundary_rejects_negative_and_fractional(): void
    {
        $this->assertSame(7200, $this->callSessionMethod('resolveLifetime', [null]));
        $this->assertSame(3600, $this->callSessionMethod('resolveLifetime', ['3600']));
        $this->assertSame(60, $this->callSessionMethod('resolveLifetime', [60]));

        try {
            $this->callSessionMethod('resolveLifetime', [-1]);
            $this->fail('lifetime منفی باید reject شود');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('negative', $e->getMessage());
        }

        $this->expectException(\InvalidArgumentException::class);
        $this->callSessionMethod('resolveLifetime', [1.5]);
    }

    public function test_s8_session_samesite_boundary_whitelist(): void
    {
        $this->assertSame('Lax', $this->callSessionMethod('resolveSameSite', [null]));
        $this->assertSame('Strict', $this->callSessionMethod('resolveSameSite', ['strict']));
        $this->assertSame('None', $this->callSessionMethod('resolveSameSite', ['NONE']));

        $this->expectException(\InvalidArgumentException::class);
        $this->callSessionMethod('resolveSameSite', ['bogus']);
    }

    public function test_s8_session_boolean_boundary_rejects_loose_truthy(): void
    {
        $this->assertTrue($this->callSessionMethod('resolveBooleanConfig', [true, 'session.secure']));
        $this->assertFalse($this->callSessionMethod('resolveBooleanConfig', ['false', 'session.secure']));
        $this->assertTrue($this->callSessionMethod('resolveBooleanConfig', ['TRUE', 'session.secure']));

        $this->expectException(\InvalidArgumentException::class);
        $this->callSessionMethod('resolveBooleanConfig', [1, 'session.secure']); // int نه bool است نه string
    }

    /* ═══════════════ لنز نشست — اعتبارسنجی شناسه / مسیر فایل ═══════════════ */

    private function makeFileHandler(): RedisSessionHandler
    {
        $this->tempBase = sys_get_temp_dir() . '/s8_sess_' . uniqid('', true);
        mkdir($this->tempBase . '/storage/sessions', 0700, true);
        $paths = new PathResolver($this->tempBase);
        return new RedisSessionHandler(null, 'file', $paths);
    }

    public function test_s8_session_handler_rejects_traversal_and_malformed_ids(): void
    {
        $handler = $this->makeFileHandler();

        $ref = new \ReflectionMethod(RedisSessionHandler::class, 'isValidSessionId');
        $ref->setAccessible(true);

        $this->assertTrue($ref->invoke($handler, bin2hex(random_bytes(16))));
        $this->assertTrue($ref->invoke($handler, strtoupper(bin2hex(random_bytes(16))))); // hex با حروف بزرگ
        $this->assertTrue($ref->invoke($handler, 'ABC-123')); // خط تیره مجاز
        $this->assertFalse($ref->invoke($handler, ''));
        $this->assertFalse($ref->invoke($handler, '../etc/passwd'));
        $this->assertFalse($ref->invoke($handler, 'a/b'));
        $this->assertFalse($ref->invoke($handler, "a\0b"));
        $this->assertFalse($ref->invoke($handler, str_repeat('a', 129)));
        $this->assertTrue($ref->invoke($handler, str_repeat('a', 128)));
    }

    public function test_s8_session_handler_file_path_never_escapes_storage(): void
    {
        $handler = $this->makeFileHandler();

        try {
            $ref = new \ReflectionMethod(RedisSessionHandler::class, 'getFilePath');
            $ref->setAccessible(true);
            $ref->invoke($handler, '../../bootstrap/app.php');
            $this->fail('path traversal باید در getFilePath fail-loud باشد');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('Invalid session id', $e->getMessage());
        }
    }

    public function test_s8_session_handler_public_api_fails_closed_on_invalid_id(): void
    {
        $handler = $this->makeFileHandler();

        $this->assertSame('', $handler->read(''));                       // خواندن id نامعتبر = «سشن جدید»
        $this->assertFalse($handler->write('a/b', 'payload'));           // نوشتن id نامعتبر = رد
        $this->assertFalse($handler->destroy('../victim'));              // تخریب id نامعتبر = رد (بدون unlink)
    }

    public function test_s8_session_handler_file_round_trip_stays_inside_storage(): void
    {
        $handler = $this->makeFileHandler();
        $this->assertTrue($handler->open('', 'CHORTKE_SESSION'));
        $this->assertSame('file', $handler->driver());

        $sid = bin2hex(random_bytes(16));
        $payload = 'user_id|i:7;_csrf_token|s:64:"' . str_repeat('a', 64) . '";';

        $this->assertTrue($handler->write($sid, $payload));
        $this->assertSame($payload, $handler->read($sid));
        $this->assertTrue(is_file($this->tempBase . '/storage/sessions/sess_' . $sid));

        $this->assertTrue($handler->destroy($sid));
        $this->assertSame('', $handler->read($sid));
    }

    /* ═══════════════ لنز نشست — API عمومی Session در برابر id مخرب ═══════════════ */

    public function test_s8_session_public_destroy_and_exists_fail_closed_on_malformed_ids(): void
    {
        $session = Session::getInstance();

        $this->assertFalse($session->destroyById('../../etc/passwd'));
        $this->assertFalse($session->destroyById(str_repeat('A', 129)));
        $this->assertFalse($session->destroyById("ab\0cd"));
        $this->assertFalse($session->existsById('a/b'));
        $this->assertFalse($session->existsById(''));
    }

    public function test_s8_session_cli_pseudo_id_is_csprng_hex(): void
    {
        $session = Session::getInstance();

        $ref = new \ReflectionMethod(Session::class, 'currentSessionId');
        $ref->setAccessible(true);

        // در CLI (بدون سشن فعال PHP) شناسهٔ شبیه‌سازی‌شده باید الگوی مجاز را رعایت کند.
        $id = $ref->invoke($session);
        $this->assertRegExp('/^[A-Za-z0-9,-]{1,128}$/', $id === '' ? 'x' : $id);
    }
}
