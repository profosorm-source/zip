<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use PHPUnit\Framework\TestCase;

/**
 * چرخهٔ اصلاحی 2026-10-28 (رفع یافته‌های 17-RV) — پین‌های ساختاری شش فیکس اصلی.
 * هر پین یک رگرسیون را قفل می‌کند: اگر کسی زمان‌بندی/سقف/گارد را بردارد،
 * این تست fail-loud می‌شود.
 *
 * @group r18
 */
final class R18CameraFixesPinningTest extends TestCase
{
    /** @return array<string, mixed> */
    private static function read(string $rel): string
    {
        $p = dirname(__DIR__, 3) . '/' . $rel;
        self::assertFileExists($p, 'فایل باید وجود داشته باشد: ' . $rel);
        return (string)file_get_contents($p);
    }

    /**
     * @test
     */
    public function kernel_schedules_system_camera_cleanup_daily(): void
    {
        $scheduler = \Core\Container::getInstance()->make(\Core\Scheduler::class);
        \App\Console\Kernel::schedule($scheduler);

        $jobs = $scheduler->registeredJobs();
        $found = null;
        foreach ($jobs as $job) {
            if (($job['name'] ?? '') === 'system_camera_cleanup') {
                $found = $job;
                break;
            }
        }
        self::assertNotNull($found, 'system_camera_cleanup باید در Kernel رجیستر شود');
        self::assertSame(86400, (int)$found['interval'], 'زمان‌بندی روزانه (interval=86400)');
    }

    /**
     * @test
     */
    public function rate_limits_pin_camera_verify_30_per_hour(): void
    {
        $map = config('rate_limits.action_map');
        self::assertIsArray($map);
        self::assertArrayHasKey('camera_verify', $map, 'action_map باید camera_verify داشته باشد');

        $cfg = config('rate_limits.camera_challenge.verify');
        self::assertIsArray($cfg, 'پالیسی camera_challenge.verify باید موجود باشد');
        self::assertSame(30, (int)($cfg['max_attempts'] ?? 0), 'سقف تأیید: ۳۰/ساعت');
        self::assertSame(60, (int)($cfg['decay_minutes'] ?? 0), 'پنجره: ۶۰ دقیقه');
    }

    /**
     * @test
     */
    public function controller_enforces_camera_verify_rate_limit(): void
    {
        $src = self::read('app/Controllers/Api/SocialTaskApiController.php');
        self::assertStringContainsString(
            "RateLimitPolicy::enforce('camera_verify'",
            $src,
            'cameraVerify باید سقف camera_verify را اعمال کند'
        );
    }

    /**
     * @test
     */
    public function service_refuses_terminal_executions_in_get_challenge(): void
    {
        $src = self::read('app/Services/SocialTask/CameraVerificationService.php');
        self::assertStringContainsString('challenge_refused_terminal', $src, 'گارد ترمینال با لاگ مشخص');
        self::assertStringContainsString("['approved', 'rejected', 'cancelled', 'expired']", $src);
    }

    /**
     * @test
     */
    public function model_gates_camera_verified_on_pass_verdict(): void
    {
        $src = self::read('app/Models/SocialTaskExecutionModel.php');
        self::assertStringContainsString('($verdict === \'pass\' ? 1 : 0)', $src, 'camera_verified فقط برای pass');
        self::assertStringContainsString("'\$.camera_verdict', ?", $src, 'حکم برای ممیزی ثبت می‌شود');
    }

    /**
     * @test
     */
    public function capture_analysis_prechecks_header_before_gd_decode(): void
    {
        $src = self::read('app/Services/SocialTask/CaptureAnalysisService.php');
        $precheck = strpos($src, 'getimagesizefromstring');
        $decode = strpos($src, '@imagecreatefromstring');
        self::assertNotFalse($precheck, 'پیش‌چک هدر باید موجود باشد');
        self::assertNotFalse($decode, 'decode GD باید موجود باشد');
        self::assertLessThan($decode, $precheck, 'هدرخوان باید «پیش از» decode در فایل بیاید');
    }

    /**
     * @test
     */
    public function job_decision_label_uses_rounded_final_score(): void
    {
        $src = self::read('app/Jobs/SocialTask/SubmitSocialTaskExecutionJob.php');
        self::assertStringContainsString('$decision = $finalScore >= self::AUTO_APPROVE_SCORE', $src);
        self::assertStringContainsString("\$finalScore < self::REJECT_SCORE ? 'auto_rejected'", $src);
        self::assertStringContainsString("'final_score' => \$finalScore", $src);
        self::assertStringNotContainsString('$decision = $final >=', $src, 'برچسب دیگر از خام نیست');
    }

    /**
     * @test
     */
    public function migration_file_for_anti_fraud_indexes_exists(): void
    {
        // FIX-GHVERIFY-R18PIN: پین قبلی نام/پسوندِ نسلِ قبل را می‌زد (anti_fraud_query_indexes.php)؛
        // فایلِ اعمال‌شدهٔ جاریِ درخت (بستهٔ CY2) با نام antifraud و پسوند .sql است.
        self::assertFileExists(
            dirname(__DIR__, 3) . '/database/migrations/2026_10_25_0001_antifraud_query_indexes.sql',
            'مایگریشن ایندکس‌های ضدتقلب باید وجود داشته باشد'
        );
    }

    /**
     * @test
     * @depends migration_file_for_anti_fraud_indexes_exists
     */
    public function live_database_has_both_anti_fraud_indexes(): void
    {
        $db = \Core\Database::getInstance();
        foreach ([
            ['user_fingerprints', 'idx_uf_fingerprint_user'],
            ['social_task_executions', 'idx_ste_ip_created'],
        ] as [$table, $index]) {
            $stmt = $db->query(
                'SELECT COUNT(DISTINCT index_name) FROM information_schema.STATISTICS
                 WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?',
                [$table, $index]
            );
            $count = (int)$stmt->fetchColumn();
            self::assertSame(1, $count, "ایندکس {$index} روی {$table} باید اعمال شده باشد");
        }
    }
}
