<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Cache;
use Core\Database;
use Core\QueryBuilder;
use Core\Queue;
use Mockery as m;
use PHPUnit\Framework\TestCase;
use RuntimeException;

final class QueueBehaviorTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    public function test_database_driver_maps_jobs_to_prioritized_queue(): void
    {
        $db = m::mock(Database::class);
        $table = m::mock(QueryBuilder::class);
        $db->shouldReceive('table')->with('queues')->once()->andReturn($table);
        $table->shouldReceive('insert')->with(m::on(
            static fn(array $row): bool => $row['queue'] === 'notifications'
        ))->once()->andReturn(true);

        $queue = $this->databaseQueue($db);

        $this->assertSame(5, $queue->getMaxAttempts());
        $this->assertTrue($queue->push('App\\Jobs\\SendEmailJob', ['email' => 'test@example.com']));
    }

    public function test_database_driver_generates_status_report_from_database_only(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('selectOne')->andReturn((object)['c' => 5]);

        $report = $this->databaseQueue($db)->getQueueStatusReport();

        $high = $report['high_priority'] ?? null;
        $meta = $report['meta'] ?? null;
        $this->assertIsArray($high);
        $this->assertIsArray($meta);
        $this->assertSame(5, $high['total_jobs']);
        $this->assertSame(5, $meta['total_failed_dlq']);
    }

    public function test_redis_driver_pushes_without_touching_database_queue(): void
    {
        $redis = m::mock(\Redis::class);
        $redis->shouldReceive('incr')->once()->with('chortke:queue:job_id_counter')->andReturn(42);

        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        // FIX-9a-6: درج push اتمیک شد (setEx+zAdd در یک اسکریپت Lua — الگوی
        // release/popSingleQueue) تا کرش بین دو دستور، متادیتا یا عضو pending را
        // یتیم نگذارد. چون Mockery نمی‌تواند متد رزروشدهٔ eval را intercept کند،
        // طبق الگوی همین فایل runRedisEval در anonymous subclass بازنویسی و
        // قرارداد جدید (کلیدها، TTL مقیاس‌پذیر و متادیتای کامل) پین می‌شود.
        $queue = new class($db, $this->redisCache($redis), 'redis') extends Queue {
            public ?array $captured = null;
            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                $this->captured = ['script' => $script, 'args' => $args, 'numKeys' => $numKeys];
                return 1;
            }
        };

        $this->assertTrue($queue->push('App\\Jobs\\SendEmailJob', ['email' => 'test@example.com']));

        $this->assertNotNull($queue->captured);
        $this->assertSame(2, $queue->captured['numKeys']);
        $this->assertSame('chortke:queue:job:42', $queue->captured['args'][0]);
        $this->assertSame('chortke:queue:notifications:pending', $queue->captured['args'][1]);
        $this->assertStringContainsString("setEx", $queue->captured['script']);
        $this->assertStringContainsString("zAdd", $queue->captured['script']);
        $this->assertSame(86400 * 7, $queue->captured['args'][2]); // delay=0 ⇒ TTL پایهٔ ۷ روز
        $metadata = json_decode($queue->captured['args'][3], true);
        $this->assertSame(42, $metadata['id'] ?? null);
        $this->assertSame('notifications', $metadata['queue'] ?? null);
        $this->assertSame('42', $queue->captured['args'][5]);
    }

    public function test_redis_driver_push_scales_metadata_ttl_with_delay(): void
    {
        // FIX-9a-6: TTL متادیتا باید با delay مقیاس شود (۷ روز + delay) — قبلاً
        // ۷ روز ثابت بود و جاب delay-دارِ بلند، قبل از pop یتیم می‌شد.
        $redis = m::mock(\Redis::class);
        $redis->shouldReceive('incr')->once()->andReturn(7);

        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        $queue = new class($db, $this->redisCache($redis), 'redis') extends Queue {
            public ?array $captured = null;
            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                $this->captured = ['args' => $args];
                return 1;
            }
        };

        $this->assertTrue($queue->push('App\\Jobs\\LogPerformanceJob', [], null, 86400 * 30)); // delay ۳۰ روز

        $this->assertSame(86400 * 7 + 86400 * 30, $queue->captured['args'][2]);
    }

    public function test_redis_driver_deletes_job_without_cross_driver_fallback(): void
    {
        $redis = m::mock(\Redis::class);
        $redis->shouldReceive('get')->once()->andReturn(json_encode(['queue' => 'default']));
        $redis->shouldReceive('zRem')->twice()->andReturn(1);
        // FIX-9a-3: کلید توکن رزرو (job:rt:{id}) هم در مسیر legacy پاک می‌شود
        $redis->shouldReceive('del')->twice()->andReturn(1);
        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        $this->assertTrue($this->redisQueue($db, $redis)->delete(42));
    }

    public function test_redis_driver_delete_with_wrong_reservation_token_is_refused(): void
    {
        // FIX-9a-3: ack/delete مشروط به توکن — نمونهٔ stall‌شده نمی‌تواند جابِ
        // مالک جدید را حذف کند (compare-and-act اتمیک در Lua؛ 0 ⇒ false).
        $redis = m::mock(\Redis::class);
        $redis->shouldReceive('get')->once()->andReturn(json_encode(['queue' => 'default']));
        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        $queue = new class($db, $this->redisCache($redis), 'redis') extends Queue {
            public ?array $captured = null;
            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                $this->captured = ['script' => $script, 'args' => $args, 'numKeys' => $numKeys];
                return 0; // توکن نامطابق — رزرو دست‌نخورده می‌ماند
            }
        };

        $this->assertFalse($queue->delete(42, 'deadbeef'));
        $this->assertSame(4, $queue->captured['numKeys']);
        $this->assertSame('chortke:queue:job:rt:42', $queue->captured['args'][3]);
        $this->assertSame('deadbeef', $queue->captured['args'][5]);
        $this->assertStringContainsString("~= token", $queue->captured['script']);
    }

    public function test_redis_driver_releases_job_without_cross_driver_fallback(): void
    {
        $redis = m::mock(\Redis::class);
        $redis->shouldReceive('get')->once()->andReturn(json_encode([
            'queue' => 'default',
            'attempts' => 2,
        ]));
        $cache = m::mock(Cache::class);
        $cache->shouldReceive('redis')->once()->andReturn($redis);
        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        // FIX-P3-5: zRem/zAdd/setEx جای خود را به اسکریپت Lua اتمیک (eval) دادند؛
        // چون Mockery نمی‌تواند متد رزروشدهٔ eval را intercept کند، طبق الگوی همین
        // فایل، runRedisEval در anonymous subclass بازنویسی و فراخوانی ثبت می‌شود.
        $queue = new class($db, $cache, 'redis') extends Queue {
            public ?array $captured = null;
            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                $this->captured = ['script' => $script, 'args' => $args, 'numKeys' => $numKeys];
                return 1;
            }
        };

        $this->assertTrue($queue->release(42, 60));
        $this->assertNotNull($queue->captured);
        $this->assertSame(4, $queue->captured['numKeys']);
        $this->assertSame('chortke:queue:default:pending', $queue->captured['args'][0]);
        $this->assertSame('chortke:queue:default:reserved', $queue->captured['args'][1]);
        $this->assertSame('chortke:queue:job:42', $queue->captured['args'][2]);
        $this->assertSame('chortke:queue:job:rt:42', $queue->captured['args'][3]);
        $this->assertSame('42', $queue->captured['args'][4]);
        $this->assertStringContainsString('zScore', $queue->captured['script']);
        $this->assertStringContainsString('zRem', $queue->captured['script']);
        $this->assertStringContainsString('zAdd', $queue->captured['script']);
        $metadata = json_decode($queue->captured['args'][7], true);
        $this->assertSame(2, $metadata['attempts'] ?? null);
        $this->assertNull($metadata['reserved_at']);
        // FIX-9a-3: بدون توکن (مسیر legacy) گیت توکن غیرفعال است (رشتهٔ خالی)
        $this->assertSame('', $queue->captured['args'][8]);
    }

    public function test_redis_driver_release_with_wrong_reservation_token_is_refused(): void
    {
        // FIX-9a-3: رزرو فقط با توکنِ مالک فعلی آزاد می‌شود؛ رزرو ورکرِ دیگر
        // (پس از انقضای visibility و پاپِ دوباره) هرگز overwrite نمی‌شود.
        $redis = m::mock(\Redis::class);
        $redis->shouldReceive('get')->once()->andReturn(json_encode([
            'queue' => 'default',
            'attempts' => 1,
        ]));
        $cache = m::mock(Cache::class);
        $cache->shouldReceive('redis')->once()->andReturn($redis);
        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        $queue = new class($db, $cache, 'redis') extends Queue {
            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                return 0; // توکن نامطابق
            }
        };

        $this->assertFalse($queue->release(42, 60, 'stale-token'));
    }

    public function test_redis_driver_keepalive_with_wrong_reservation_token_is_refused(): void
    {
        // FIX-9a-3: تمدید visibility فقط برای مالکِ فعلی رزرو (compare-token اتمیک)
        $redis = m::mock(\Redis::class);
        $cache = m::mock(Cache::class);
        $cache->shouldReceive('redis')->once()->andReturn($redis);
        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        $queue = new class($db, $cache, 'redis') extends Queue {
            public ?array $captured = null;
            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                $this->captured = ['script' => $script, 'args' => $args, 'numKeys' => $numKeys];
                return 0;
            }
        };

        $this->assertFalse($queue->keepAlive(42, 'default', 300, 'stale-token'));
        $this->assertSame(2, $queue->captured['numKeys']);
        $this->assertSame('chortke:queue:default:reserved', $queue->captured['args'][0]);
        $this->assertSame('chortke:queue:job:rt:42', $queue->captured['args'][1]);
        $this->assertSame('stale-token', $queue->captured['args'][3]);
        $this->assertStringContainsString("~= token", $queue->captured['script']);
        $this->assertStringContainsString('zAdd', $queue->captured['script']);
    }

    public function test_redis_driver_release_refuses_when_job_not_in_reserved(): void
    {
        // FIX-P3-5: اگر جاب در reserved نباشد (مثلاً ورکر دیگری مالکیت را گرفته)،
        // release نباید رزرو مالک جدید را overwrite کند — اسکریپت 0 برمی‌گرداند ⇒ false
        $redis = m::mock(\Redis::class);
        $redis->shouldReceive('get')->once()->andReturn(json_encode([
            'queue' => 'default',
            'attempts' => 1,
        ]));
        $cache = m::mock(Cache::class);
        $cache->shouldReceive('redis')->once()->andReturn($redis);
        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        $queue = new class($db, $cache, 'redis') extends Queue {
            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                return 0;
            }
        };

        $this->assertFalse($queue->release(42, 60));
    }

    public function test_ambiguous_redis_pop_failure_never_reserves_database_job(): void
    {
        $this->expectOutputRegex('/.*/');
        $redis = m::mock(\Redis::class);
        $cache = m::mock(Cache::class);
        $cache->shouldReceive('redis')->once()->andReturn($redis);
        $db = m::mock(Database::class);
        $db->shouldNotReceive('beginTransaction');
        $db->shouldNotReceive('selectOne');

        $queue = new class($db, $cache, 'redis') extends Queue {
            private int $evalCalls = 0;

            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                $this->evalCalls++;
                if ($this->evalCalls === 1) {
                    return 0;
                }

                throw new RuntimeException('connection lost after reservation');
            }
        };

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('ambiguous reservation outcome');

        $queue->pop('default');
    }

    public function test_ambiguous_redis_push_failure_never_inserts_database_duplicate(): void
    {
        $this->expectOutputRegex('/.*/');
        $redis = m::mock(\Redis::class);
        $redis->shouldReceive('incr')->once()->andReturn(42);

        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        // FIX-9a-6: درج اتمیک via eval — شکستِ اتصال حین اسکریپت همان قرارداد
        // ambiguous-outcome قبلی را دارد (هرگز fallback به درایور دیتابیس نیست).
        $queue = new class($db, $this->redisCache($redis), 'redis') extends Queue {
            protected function runRedisEval(string $script, array $args, int $numKeys): mixed
            {
                throw new RuntimeException('connection lost after write');
            }
        };

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('ambiguous outcome');

        $queue->push('App\\Jobs\\LogPerformanceJob', ['key' => 'value']);
    }

    public function test_redis_driver_fails_during_composition_without_active_connection(): void
    {
        $cache = m::mock(Cache::class);
        $cache->shouldReceive('redis')->once()->andReturn(null);

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('requires an active Redis connection');

        new Queue(m::mock(Database::class), $cache, 'redis');
    }

    /**
     * @dataProvider invalidQueueNameProvider
     */
    public function test_invalid_queue_name_is_rejected_before_storage_access(string $queueName): void
    {
        $db = m::mock(Database::class);
        $db->shouldNotReceive('table');

        $this->expectException(\InvalidArgumentException::class);

        $this->databaseQueue($db)->push('App\\Jobs\\LogPerformanceJob', [], $queueName);
    }

    /** @return array<string, array{0: string}> */
    public function invalidQueueNameProvider(): array
    {
        return [
            'whitespace' => ['critical queue'],
            'path separator' => ['critical/queue'],
            'control character' => ["critical\nqueue"],
            'too long' => [str_repeat('a', 129)],
        ];
    }

    private function databaseQueue(Database $db): Queue
    {
        $cache = m::mock(Cache::class);
        $cache->shouldNotReceive('redis');
        $cache->shouldReceive('rememberSeconds')->andReturn(0)->byDefault();

        return new Queue($db, $cache, 'database');
    }

    private function redisCache(\Redis $redis): Cache
    {
        $cache = m::mock(Cache::class);
        $cache->shouldReceive('redis')->andReturn($redis);
        $cache->shouldReceive('rememberSeconds')->andReturn(0)->byDefault();
        return $cache;
    }

    private function redisQueue(Database $db, \Redis $redis): Queue
    {
        $cache = $this->redisCache($redis);
        return new Queue($db, $cache, 'redis');
    }
}
