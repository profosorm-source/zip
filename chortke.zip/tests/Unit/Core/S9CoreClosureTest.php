<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Attributes\Inject;
use Core\Event;
use Core\GenericEvent;
use Core\Lib\QRCode;
use PHPUnit\Framework\TestCase;
use ReflectionClass;

/**
 * بچ S9 — بستن باقی‌ماندهٔ core/: Lib/QRCode + Attributes/Inject + خانوادهٔ Event
 *
 * لنز: ورودی-خروجی کتابخانه‌ای (QRCode) و ردیف‌کشی صفت‌ها (Inject).
 * حکم ممیزی: صفر باگ قابل‌بهره‌برداری — این سوییت رفتارهای قراردادی سطوح
 * ممیزی‌شده را «سنجاق» می‌کند تا رگرسیون‌های آینده آشکار شوند:
 *  - QRCode::svg: خروجی SVG فقط-ماتریسی (payload هیچ‌گاه به‌صورت متن در
 *    markup جاسازی نمی‌شود) + clamp نزولی scale/quietzone + هم‌سازی payload.
 *  - Inject: قرارداد صفت (target فقط PROPERTY، serviceName اختیاری).
 *  - Event/GenericEvent: قراردادهای پایهٔ رویداد (wrap غیرآرایه، پیش‌فرض null،
 *    تقدم کلیدهای aggregate، محافظت str_value در برابر مقادیر غیراسکالر).
 */
final class S9CoreClosureTest extends TestCase
{

    /* ─────────────────────────── QRCode ─────────────────────────── */

    public function testSvgOutputIsMatrixOnlyAndNeverEmbedsRawPayload(): void
    {
        $marker = 'SECRET-MARKER-9f8e7d6c-otpauth';
        $svg = QRCode::svg('https://example.com/totp?payload=' . $marker . '&more=1');

        $this->assertIsString($svg);
        $this->assertNotSame('', $svg);
        $this->assertStringContainsString('<svg', $svg);
        $this->assertStringContainsString('</svg>', $svg);
        $this->assertStringContainsString('http://www.w3.org/2000/svg', $svg);
        // قرارداد امنیتی: payload فقط به ماژول‌های QR کدگذاری می‌شود،
        // هیچ‌گاه به‌صورت متن/ویژگی در markup ظاهر نمی‌شود.
        $this->assertStringNotContainsString($marker, $svg);
    }

    public function testSvgScaleClampHandlesDegenerateValues(): void
    {
        $payload = 'chortke-scale-clamp-probe';

        // scale صفر/منفی/غیرعددی — هر سه باید بدون استثنا به clamp برسند
        // (۰/منفی → ۱؛ غیرعددی → ۴) و خروجی ساختار SVG سالم بدهند.
        foreach ([0, -5, 'abc', null] as $degenerateScale) {
            $svg = QRCode::svg($payload, ['scale' => $degenerateScale]);
            $this->assertStringContainsString('<svg', $svg, 'scale=' . var_export($degenerateScale, true));
            $this->assertStringContainsString('</svg>', $svg, 'scale=' . var_export($degenerateScale, true));
        }

        // quietzone صفر هم مجاز است (حد پایین ۰)
        $svg = QRCode::svg($payload, ['quietzone' => 0, 'scale' => 1]);
        $this->assertStringContainsString('<svg', $svg);
    }

    public function testSvgAcceptsNonStringPayloadsViaCoercion(): void
    {
        // اسکالر عددی → cast رشته‌ای؛ آرایه → json_encode (UNICODE خام)
        $intSvg = QRCode::svg(1234567890);
        $this->assertStringContainsString('<svg', $intSvg);

        $arraySvg = QRCode::svg(['u' => 'علی', 'id' => 42]);
        $this->assertStringContainsString('<svg', $arraySvg);

        // هر دو خروجی باید متفاوت باشند (payload واقعاً در ماتریس اثر دارد)
        $this->assertNotSame($intSvg, $arraySvg);
    }

    public function testSvgScaleIsViewBoxNoopWhileQuietzoneGrowsMatrix(): void
    {
        $payload = 'chortke-size-delta-probe';

        // واقعیت کتابخانه (chillerlan): خروجی SVG اندازه‌اش را از viewBox
        // ماتریس می‌گیرد؛ scale در رشتهٔ SVG هیچ اثری ندارد (no-op) —
        // یعنی سناریوی فرضی «scale کاربر-کنترل → SVG غول» از اساس منتفی است.
        $scale1 = QRCode::svg($payload, ['scale' => 1]);
        $scale8 = QRCode::svg($payload, ['scale' => 8]);
        $this->assertSame($scale1, $scale8);

        // اهرم واقعی اندازهٔ خروجی: quietzone (ماتریس را بزرگ می‌کند)
        $tight = QRCode::svg($payload, ['quietzone' => 0]);
        $wide = QRCode::svg($payload, ['quietzone' => 8]);
        $this->assertNotSame($tight, $wide);
        $this->assertGreaterThan(strlen($tight), strlen($wide));
    }

    /* ─────────────────────────── Inject ─────────────────────────── */

    public function testInjectAttributeContract(): void
    {
        // بدون آرگومان → serviceName تهی (Container از type-hint پراپرتی استفاده می‌کند)
        $bare = new Inject();
        $this->assertNull($bare->serviceName);

        // با آرگومان → همان نام سرویس (developer-trusted؛ هرگز ورودی کاربر)
        $named = new Inject(App\Service\Name::class);
        $this->assertSame(App\Service\Name::class, $named->serviceName);

        // قرارداد صفت: فقط روی PROPERTY هدف‌گذاری شده
        $rc = new ReflectionClass(Inject::class);
        $attrs = $rc->getAttributes(\Attribute::class);
        $this->assertNotEmpty($attrs);
        /** @var \Attribute $meta */
        $meta = $attrs[0]->newInstance();
        $this->assertSame(\Attribute::TARGET_PROPERTY, $meta->flags);
    }

    /* ─────────────────── Event / GenericEvent ─────────────────── */

    public function testEventWrapsNonArrayDataUnderValue(): void
    {
        // رشتهٔ ساده (غیرآرایه) → زیر کلید 'value' wrap می‌شود
        $event = new class('plain-string') extends Event {};

        $this->assertSame(['value' => 'plain-string'], $event->getData());

        // کلید ناموجود → null (قرارداد getData)
        $this->assertNull($event->getData('nonexistent'));

        // آرایه عیناً حفظ می‌شود (بدون wrap)
        $arrayEvent = new class(['a' => 1]) extends Event {};
        $this->assertSame(['a' => 1], $arrayEvent->getData());
    }

    public function testEventSetDataAndPropagationFlag(): void
    {
        $event = new class() extends Event {};

        $this->assertFalse($event->isPropagationStopped());
        $event->stopPropagation();
        $this->assertTrue($event->isPropagationStopped());

        $event->setData('k', 'v');
        $this->assertSame('v', $event->getData('k'));
    }

    public function testGenericEventAggregateTypePrecedence(): void
    {
        // تقدم: aggregate_type > event_name > 'general'
        $withAgg = new GenericEvent(['aggregate_type' => 'wallet', 'event_name' => 'deposit']);
        $this->assertSame('wallet', $withAgg->aggregateType());

        $withEvt = new GenericEvent(['event_name' => 'deposit']);
        $this->assertSame('deposit', $withEvt->aggregateType());

        $bare = new GenericEvent([]);
        $this->assertSame('general', $bare->aggregateType());

        // مقدار غیراسکالر به‌جای رشته → fallback (هرگز TypeError)
        $junk = new GenericEvent(['aggregate_type' => ['array']]);
        $this->assertSame('general', $junk->aggregateType());
    }

    public function testGenericEventAggregateIdPrecedenceAndScalarGuard(): void
    {
        // تقدم: user_id > userId > id > aggregate_id
        $this->assertSame('7', (new GenericEvent(['user_id' => 7, 'id' => 9]))->aggregateId());
        $this->assertSame('9', (new GenericEvent(['userId' => 9, 'id' => 3]))->aggregateId());
        $this->assertSame('3', (new GenericEvent(['id' => 3, 'aggregate_id' => 5]))->aggregateId());
        $this->assertSame('5', (new GenericEvent(['aggregate_id' => 5]))->aggregateId());

        // هیچ کلیدی → '0'
        $this->assertSame('0', (new GenericEvent([]))->aggregateId());

        // مقدار غیراسکالر (آرایه/آبجکت) → str_value default یعنی '0' — بدون کرش
        $this->assertSame('0', (new GenericEvent(['user_id' => ['array']]))->aggregateId());
    }

    public function testGenericEventToPayloadRoundTrip(): void
    {
        $data = ['user_id' => 12, 'event_name' => 'withdraw', 'amount' => '617.2500'];
        $event = new GenericEvent($data);

        $this->assertSame($data, $event->toPayload());
        $this->assertSame($data, $event->getData());
    }
}
