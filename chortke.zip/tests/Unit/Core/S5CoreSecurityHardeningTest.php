<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Model;
use PHPUnit\Framework\TestCase;

/**
 * بچ S5 ممیزی امنیتی هسته — تست‌های حلقه‌بستهٔ فیکس‌های FIX-S5-1/2/3
 *
 * لنز: دورزدن escape کاراکتر LIKE (بک‌اسلش → wildcard زنده) و
 * امن‌سازی هدر Content-Disposition (CR/LF/NUL).
 *
 * FIX-S5-1: core/Model.php::escapeLikeValue — مجموعهٔ escape باید شامل
 * backslash باشد؛ با '%_' ورودیِ "\%" پس از escape به «بک‌اسلش لیتارال +
 * wildcard زنده» تبدیل می‌شد (خانوادهٔ همان باگ M31 در AuditTrail/Dispute).
 *
 * FIX-S5-3: App\Services\TicketService::sanitizeDownloadName — CR/LF/NUL
 * پیش از addslashes حذف می‌شوند تا Content-Disposition تک‌خطی بماند.
 */
final class S5CoreSecurityHardeningTest extends TestCase
{
    /** مدل probe — سازندهٔ والد عمداً bypass می‌شود (بدون نیاز به Database) */
    private ?Model $probe = null;

    protected function setUp(): void
    {
        parent::setUp();
        $this->probe = new class extends Model {
            protected static string $table = 's5_like_probe';
            protected static array $searchable = ['v'];
            public function __construct()
            {
                // عمدی: escapeLikeValue به $this->db دست نمی‌زند
            }
            public function exposedEscapeLikeValue(string $value, int $maxLength = 100): string
            {
                return $this->escapeLikeValue($value, $maxLength);
            }
        };
    }

    public function test_plain_percent_and_underscore_are_escaped(): void
    {
        $this->assertSame(chr(92) . '%', $this->probe->exposedEscapeLikeValue('%'));
        $this->assertSame(chr(92) . '_', $this->probe->exposedEscapeLikeValue('_'));
        $this->assertSame('hello', $this->probe->exposedEscapeLikeValue('hello'));
    }

    public function test_backslash_alone_is_escaped_so_it_cannot_swallow_the_next_char(): void
    {
        // قبل از فیکس: '\\' تغییر نمی‌کرد و در LIKE به‌عنوان escape-char زنده عمل می‌کرد
        // (ورودی "\" → الگوی "%\%" → یعنی «لیترال %» نه «بک‌اسلش»)
        $this->assertSame(chr(92) . chr(92), $this->probe->exposedEscapeLikeValue(chr(92)));
    }

    public function test_prefixed_wildcard_bypass_is_closed(): void
    {
        // هستهٔ FIX-S5-1: ورودی "\%" قبلاً به "\\%" تبدیل می‌شد که MySQL
        // آن را «بک‌اسلش لیتارال + wildcard زنده» می‌خواند ⇒ تزریق wildcard.
        // اکنون: "\" → "\\" و "%" → "\%" ⇒ هر توالی unambiguous است.
        $this->assertSame(
            chr(92) . chr(92) . chr(92) . '%',
            $this->probe->exposedEscapeLikeValue(chr(92) . '%')
        );
        $this->assertSame(
            chr(92) . chr(92) . chr(92) . '_',
            $this->probe->exposedEscapeLikeValue(chr(92) . '_')
        );
    }

    public function test_mixed_term_with_all_special_chars_is_fully_escaped(): void
    {
        $input = 'a' . chr(92) . '%b_c';
        $expected = 'a' . chr(92) . chr(92) . chr(92) . '%' . 'b' . chr(92) . '_' . 'c';
        $this->assertSame($expected, $this->probe->exposedEscapeLikeValue($input));
    }

    public function test_max_length_guard_is_preserved(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Search term exceeds');
        $this->probe->exposedEscapeLikeValue(str_repeat('x', 101));
    }

    // ─────────────────────────────────────────────────────────────────────
    // FIX-S5-3 — TicketService::sanitizeDownloadName
    // ─────────────────────────────────────────────────────────────────────

    public function test_download_name_strips_crlf_and_nul(): void
    {
        // \r و \n هرکدام جداگانه به فاصله تبدیل می‌شوند (دو فاصله پشت‌سرهم)
        $this->assertSame('report  final.pdf', \App\Services\TicketService::sanitizeDownloadName("report\r\nfinal.pdf"));
        $this->assertSame('na me.pdf', \App\Services\TicketService::sanitizeDownloadName("na\0me.pdf"));
        $this->assertSame('report.pdf', \App\Services\TicketService::sanitizeDownloadName('report.pdf'));
    }

    public function test_download_name_quotes_and_backslashes_still_escaped_by_addslashes(): void
    {
        $this->assertSame(
            'file' . chr(92) . '"name.pdf',
            \App\Services\TicketService::sanitizeDownloadName('file"name.pdf')
        );
        $this->assertSame(
            'back' . chr(92) . chr(92) . 'slash.pdf',
            \App\Services\TicketService::sanitizeDownloadName('back' . chr(92) . 'slash.pdf')
        );
    }

    public function test_download_name_output_is_single_line(): void
    {
        // خاصیت امنیتیِ فیکس: هدر چندخطی نمی‌تواند ساخته شود — CR/LF حذف می‌شوند؛
        // متن باقیمانده بخشی از همان نام فایل تک‌خطی است (ادغام با PHP رد می‌شود).
        $out = \App\Services\TicketService::sanitizeDownloadName("evil\r\nX-Injected: 1.pdf");
        $this->assertStringNotContainsString("\r", $out);
        $this->assertStringNotContainsString("\n", $out);
        $this->assertStringNotContainsString("\0", $out);
        $this->assertSame('evil  X-Injected: 1.pdf', $out);
    }
}
