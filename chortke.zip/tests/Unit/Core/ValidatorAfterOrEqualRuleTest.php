<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Validator;
use PHPUnit\Framework\TestCase;

/**
 * FIX-S17-F04 (بازبینی بخش ۱۷ — بستهٔ ۶): تست‌های pin قاعدهٔ after_or_equal.
 *
 * قاعدهٔ مقایسه‌ای بین‌فیلدی برای تاریخ (الگوی «same»): مقدار فیلد باید
 * برابر یا بعد از تاریخِ فیلد مرجع باشد. قرارداد مالکیت خطا:
 *  - مقدار خالی ⇒ skip (required مالک خطاست)
 *  - مرجع غایب/خالی ⇒ skip (required خودِ مرجع مالک خطاست)
 *  - هر طرف غیرقابل‌تجزیه ⇒ skip (date همان فیلد مالک خطاست)
 *  - هر دو قابل‌تجزیه و مقدار < مرجع ⇒ خطای after_or_equal
 * قاعده بدون پارامتر مرجع = خطای برنامه‌نویس (fail-loud، هم‌الگوی R34).
 */
class ValidatorAfterOrEqualRuleTest extends TestCase
{
    /**
     * @param array<string,mixed> $data
     * @param array<string,mixed> $rules
     * @param array<string,mixed> $messages
     */
    private function make(array $data, array $rules, array $messages = []): Validator
    {
        return new Validator($data, $rules, null, $messages);
    }

    public function testPassesWhenValueAfterReference(): void
    {
        $v = $this->make(
            ['start' => '2026-10-15T10:00', 'end' => '2026-10-22T10:00'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertFalse($v->fails());
    }

    public function testPassesOnBoundaryWhenValueEqualsReference(): void
    {
        // قرارداد گزارش بازبینی: end_date ≥ start_date — مرز مساوی مجاز است
        $v = $this->make(
            ['start' => '2026-10-15T10:00', 'end' => '2026-10-15T10:00'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertFalse($v->fails());
    }

    public function testFailsWhenValueBeforeReference(): void
    {
        $v = $this->make(
            ['start' => '2026-10-15T10:00', 'end' => '2026-10-14T10:00'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertTrue($v->fails());
        $this->assertArrayHasKey('end', $v->errors());
        $this->assertStringContainsString('برابر یا بعد از', implode(' ', $v->errors()['end']));
    }

    public function testFailsBySingleMinuteAcrossMidnight(): void
    {
        // مرز دقیقه‌ای: یک دقیقه قبل از شروع هم باید رد شود
        $v = $this->make(
            ['start' => '2026-10-15T00:01', 'end' => '2026-10-15T00:00'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertTrue($v->fails());
        $this->assertArrayHasKey('end', $v->errors());
    }

    public function testMixedFormatsComparedConsistently(): void
    {
        // فرمت ناهم‌جنس (date-only مرجع در برابر datetime-local مقدار):
        // هر دو در یک منطقهٔ زمانی (سرور) تفسیر و درست مقایسه می‌شوند.
        $ok = $this->make(
            ['start' => '2026-10-15', 'end' => '2026-10-15T23:59'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertFalse($ok->fails());

        $bad = $this->make(
            ['start' => '2026-10-15', 'end' => '2026-10-14T23:59'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertTrue($bad->fails());
    }

    public function testSkipsWhenValueEmptyBecauseRequiredOwnsTheError(): void
    {
        // مقدار خالی ⇒ قاعدهٔ مقایسه ساکت است؛ فقط requiredِ همان فیلد خطا می‌دهد
        $v = $this->make(
            ['start' => '2026-10-15T10:00', 'end' => ''],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertTrue($v->fails());
        $errors = $v->errors()['end'];
        $this->assertCount(1, $errors); // فقط required — بدون after_or_equal اضافه
        $this->assertStringContainsString('الزامی', $errors[0]);
    }

    public function testSkipsWhenReferenceMissingBecauseItsOwnRulesOwnTheError(): void
    {
        // مرجع غایب ⇒ مقایسه ممکن نیست؛ requiredِ خودِ مرجع مالک خطاست و
        // روی فیلد مقصد خطای گمراه‌کننده‌ای نمی‌بینیم
        $v = $this->make(
            ['end' => '2026-10-14'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertTrue($v->fails());
        $this->assertArrayHasKey('start', $v->errors());
        $this->assertArrayNotHasKey('end', $v->errors());
    }

    public function testSkipsWhenEitherDateUnparseableBecauseDateRuleOwnsTheError(): void
    {
        // مقدار غیرقابل‌تجزیه ⇒ فقط قاعدهٔ date همان فیلد خطا می‌دهد
        $v = $this->make(
            ['start' => '2026-10-15T10:00', 'end' => 'not-a-date'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertTrue($v->fails());
        $errors = $v->errors()['end'];
        $this->assertCount(1, $errors);
        $this->assertStringContainsString('تاریخ نامعتبر', $errors[0]);

        // مرجع غیرقابل‌تجزیه ⇒ مقدارِ سالمِ بعدی نباید قربانی مقایسهٔ ناممکن شود
        $v2 = $this->make(
            ['start' => 'garbage', 'end' => '2026-10-14'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start']
        );
        $this->assertTrue($v2->fails());
        $this->assertArrayNotHasKey('end', $v2->errors());
    }

    public function testCustomMessageOverridesDefault(): void
    {
        $v = $this->make(
            ['start' => '2026-10-15', 'end' => '2026-10-14'],
            ['start' => 'required|date', 'end' => 'required|date|after_or_equal:start'],
            ['end.after_or_equal' => 'تاریخ پایان باید برابر یا بعد از تاریخ شروع باشد']
        );
        $this->assertTrue($v->fails());
        $this->assertSame(
            ['تاریخ پایان باید برابر یا بعد از تاریخ شروع باشد'],
            $v->errors()['end']
        );
    }

    public function testBareRuleWithoutReferenceParamIsProgrammerError(): void
    {
        // R34-FAIL-LOUD: قاعدهٔ بدون پارامتر = خطای پیکربندی برنامه‌نویس، نه دادهٔ کاربر
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('after_or_equal" requires a reference field');
        $this->make(
            ['a' => '2026-10-15'],
            ['a' => 'after_or_equal']
        );
    }

    public function testNullableValueSkipsComparison(): void
    {
        // nullable + مقدار null ⇒ کل زنجیرهٔ قواعد بعدی skip (قرارداد موتور)
        $v = $this->make(
            ['start' => '2026-10-15'],
            ['start' => 'required|date', 'end' => 'nullable|date|after_or_equal:start']
        );
        $this->assertFalse($v->fails());
    }
}
