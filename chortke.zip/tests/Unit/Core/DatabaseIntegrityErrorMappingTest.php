<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * FIX-36/W2-D2 — پین F-A9a-02:
 * SQLSTATE 23000 در MySQL ابهام‌دار است؛ منبع حقیقت driver code
 * (errorInfo[1]) است:
 *   1062 → «رکورد تکراری» · 1451/1452 → کلید خارجی · 1048 → NOT-NULL.
 *
 * پیش از فیکس، «کلِ 23000» به ValidationExceptionِ «قبلاً ثبت شده» ترجمه می‌شد:
 *   ① UX غلط — DELETE با محدودیت FK به کاربر «تکراری بودن» می‌گفت؛
 *   ② طبقه‌بندهای PDOException (TransactionWrapper::isTransientDatabaseError،
 *      Model::isUniqueViolation) ورودی‌شان ValidationException می‌شد.
 *
 * مترجم برای تست‌پذیری به Database::translateIntegrityConstraintViolation
 * استخراج شده (رفتار عیناً حفظ شده؛ گیت PHP_SAPI !== 'cli' — ترجمهٔ HTTP-تنها —
 * در call-site باقی مانده؛ پین e2e مسیر CLI: خامِ PDOException دست‌نخورده رِی می‌شود).
 */
class DatabaseIntegrityErrorMappingTest extends TestCase
{
    protected function setUp(): void
    {
        Database::reset();
        parent::setUp();
    }

    protected function tearDown(): void
    {
        Database::reset();
        parent::tearDown();
    }

    /** PDOException واقعی با errorInfo[1] (driver code) و SQLSTATE ساختگی‌شده */
    private function fakePdoException(string $message, string $sqlState, ?int $driverCode): \PDOException
    {
        return new class($message, $sqlState, $driverCode) extends \PDOException {
            public function __construct(string $message, string $sqlState, ?int $driverCode)
            {
                parent::__construct($message);
                $this->code = $sqlState;
                $this->errorInfo = $driverCode === null ? [$sqlState] : [$sqlState, $driverCode, $message];
            }
        };
    }

    /** @return array{0:\Core\Exceptions\ValidationException|null, 1:\PDOException|null} */
    private function translate(\PDOException $e): array
    {
        $db = (new \ReflectionClass(Database::class))->newInstanceWithoutConstructor();
        $method = new \ReflectionMethod(Database::class, 'translateIntegrityConstraintViolation');
        $method->setAccessible(true);
        $result = $method->invoke($db, $e);
        if ($result === null) {
            return [null, $e];
        }
        return [$result, null];
    }

    // ───────────── 1062: unique — فقط این کد «تکراری» است ─────────────

    public function testDuplicateEntry1062TranslatesToDuplicateValidationException(): void
    {
        [$validation, $raw] = $this->translate($this->fakePdoException(
            "SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'ali@test' for key 'users.email_unique'",
            '23000',
            1062
        ));
        $this->assertNull($raw);
        $this->assertInstanceOf(\Core\Exceptions\ValidationException::class, $validation);
        $this->assertArrayHasKey('email', $validation->getErrors());
        $this->assertStringContainsString('قبلاً در سیستم ثبت شده است', $this->firstErrorMessage($validation));
    }

    public function testDuplicateEntryMySql8FormatStripsTablePrefix(): void
    {
        // BUGFIX-PHASE2-P22 فرمت MySQL 8.0.13+: for key 'users.email_unique'
        [$validation,] = $this->translate($this->fakePdoException(
            "SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'x' for key 'users.email_unique'",
            '23000',
            1062
        ));
        $this->assertNotNull($validation);
        $this->assertArrayHasKey('email', $validation->getErrors(), 'پسوند _unique باید از کلید خطا حذف شود (قرارداد P22)');
    }

    // ───────────── 1451/1452: FK — دیگر «تکراری» برچسب نمی‌خورند ─────────────

    public function testForeignKeyViolation1451TranslatesToDependencyMessage(): void
    {
        [$validation, $raw] = $this->translate($this->fakePdoException(
            "SQLSTATE[23000]: Integrity constraint violation: 1451 Cannot delete or update a parent row: a foreign key constraint fails (`chortk`.`wallets`, CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`))",
            '23000',
            1451
        ));
        $this->assertNull($raw, 'FK violation must surface as ValidationException (HTTP UX contract)');
        $this->assertInstanceOf(\Core\Exceptions\ValidationException::class, $validation);
        $this->assertStringContainsString('وابسته است و حذف یا تغییر آن امکان‌پذیر نیست', $this->firstErrorMessage($validation));
        $this->assertStringNotContainsString('تکراری', $validation->getMessage() . $this->firstErrorMessage($validation), 'FK نباید «رکورد تکراری» برچسب بخورد');
    }

    public function testForeignKeyViolation1452TranslatesToMissingReferenceMessage(): void
    {
        [$validation, $raw] = $this->translate($this->fakePdoException(
            "SQLSTATE[23000]: Integrity constraint violation: 1452 Cannot add or update a child row: a foreign key constraint fails (`chortk`.`orders`, CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`))",
            '23000',
            1452
        ));
        $this->assertNull($raw);
        $this->assertStringContainsString('رکورد مرجعِ انتخاب‌شده وجود ندارد یا معتبر نیست', $this->firstErrorMessage($validation));
    }

    // ───────────── 1048: NOT-NULL — دیگر «تکراری» برچسب نمی‌خورد ─────────────

    public function testNotNullViolation1048UsesFriendlyFieldNameWhenKnown(): void
    {
        [$validation, $raw] = $this->translate($this->fakePdoException(
            "SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'email' cannot be null",
            '23000',
            1048
        ));
        $this->assertNull($raw);
        $this->assertArrayHasKey('email', (array)($validation?->getErrors()));
        $this->assertStringContainsString('ایمیل نمی‌تواند خالی باشد', $this->firstErrorMessage($validation));
    }

    public function testNotNullViolation1048UnknownColumnStillPrecise(): void
    {
        [$validation,] = $this->translate($this->fakePdoException(
            "SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'referral_code' cannot be null",
            '23000',
            1048
        ));
        $this->assertStringContainsString('referral_code', $this->firstErrorMessage($validation));
        $this->assertStringContainsString('نمی‌تواند خالی باشد', $this->firstErrorMessage($validation));
    }

    // ───────────── سایر 23000ها و SQLSTATEهای دیگر: رِیِ خام ─────────────

    public function testCheckConstraint3819PassesThroughRaw(): void
    {
        [$validation, $raw] = $this->translate($this->fakePdoException(
            "SQLSTATE[23000]: Integrity constraint violation: 3819 Check constraint 'chk_amount_positive' is violated.",
            '23000',
            3819
        ));
        $this->assertNull($validation, 'کدهای ناشناختهٔ 23000 باید خام رِی شوند (طبقه‌بندهای PDOException دست‌نخورده)');
        $this->assertInstanceOf(\PDOException::class, $raw);
    }

    public function test23000WithoutDriverCodeAndWithoutDuplicateMessagePassesThroughRaw(): void
    {
        // هستهٔ فیکس: 23000 بدون driver code و بدون پیام Duplicate دیگر «تکراری» نمی‌شود.
        [$validation, $raw] = $this->translate($this->fakePdoException(
            'SQLSTATE[23000]: Integrity constraint violation: 1451 Cannot delete or update a parent row',
            '23000',
            null
        ));
        $this->assertNull($validation);
        $this->assertInstanceOf(\PDOException::class, $raw);
    }

    public function testLegacyDuplicateMessageWithoutDriverCodeStillTranslates(): void
    {
        // درایورهای قدیمی بدون errorInfo[1] — پیام Duplicate تنها مسیر نگاشت به ۱۰۶۲.
        [$validation, $raw] = $this->translate($this->fakePdoException(
            "Duplicate entry 'ali@test' for key 'users.email_unique'",
            '23000',
            null
        ));
        $this->assertNull($raw);
        $this->assertArrayHasKey('email', (array)($validation?->getErrors()));
    }

    private function firstErrorMessage(\Core\Exceptions\ValidationException $e): string
    {
        $errors = $e->getErrors();
        $flat = [];
        array_walk_recursive($errors, function ($v) use (&$flat) {
            if (is_string($v)) { $flat[] = $v; }
        });
        return $flat[0] ?? '';
    }

    public function testNon23000SqlStateIsNeverTranslated(): void
    {
        [$validation, $raw] = $this->translate($this->fakePdoException(
            'SQLSTATE[40001]: Serialization failure: 1213 Deadlock found',
            '40001',
            1213
        ));
        $this->assertNull($validation);
        $this->assertInstanceOf(\PDOException::class, $raw);
    }

    // ───────────── e2e (مسیر CLI): PDOException خام رِی می‌شود ─────────────

    public function testCliPathPassesRawPdoExceptionThrough(): void
    {
        $e = $this->fakePdoException(
            "SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'x' for key 'users.email_unique'",
            '23000',
            1062
        );

        $db = (new \ReflectionClass(Database::class))->newInstanceWithoutConstructor();

        $holder = new \stdClass();
        $holder->e = $e;
        // PDO زیرکلاس با سازندهٔ خالی — PHPUnit 8.5 نمی‌تواند PDO را mock کند
        // (ReflectionUnionType روی PHP 8.2)؛ prepare همیشه استثنای هدف را می‌دهد.
        $pdo = new class($holder) extends \PDO {
            private \stdClass $holder;
            public function __construct(\stdClass $holder) { $this->holder = $holder; }
            public function prepare(string $query, array $options = []): \PDOStatement|false
            {
                throw $this->holder->e;
            }
        };

        $pdoProp = new \ReflectionProperty(Database::class, 'pdo');
        $pdoProp->setAccessible(true);
        $pdoProp->setValue($db, $pdo);
        $pingProp = new \ReflectionProperty(Database::class, 'lastPingTime');
        $pingProp->setAccessible(true);
        $pingProp->setValue($db, time());

        try {
            ob_start(); // fallbackLog در مسیر شکست، لاگر را چاپ می‌کند — خروجی تست را آلوده نکند
            $db->execute('INSERT INTO users (email) VALUES (?)', ['x']);
            $this->fail('expected the raw PDOException');
        } catch (\PDOException $caught) {
            $this->assertSame($e, $caught, 'در CLI (و HTTP بدون ترجمه) قرارداد PDOException حفظ می‌شود');
        } finally {
            if (ob_get_level() > 0) { ob_end_clean(); }
        }
    }
}
