<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Cache;
use Core\Database;
use Core\IdempotencyKey;
use Core\Sql\SafeExpression;
use Core\Sql\SqlExpressionException;
use PHPUnit\Framework\TestCase;

/**
 * بچ S6 — قفل رفتاری فیکس‌های لنز امنیتی/دقت هسته:
 *
 *  - FIX-S6-1: wrapInstance برای Throwable-غیر-Exception (TypeError/ValueError/Error)
 *    نیز fail() را ثبت و همان خطا را rethrow می‌کند (کلید دیگر تا ۳۰۰ ثانیه pending نمی‌ماند).
 *  - FIX-S6-4: نویسه‌های کنترلی C0 داخل لیترال رشته‌ای SafeExpression fail-loud رد می‌شوند؛
 *    لیترال‌های قانونی ('' escape، LIKE، CASE، CAST) بدون تغییر سبز می‌مانند.
 *
 * راستی‌آزمایی Database::isLockingRead (FIX-S6-3) و Cache::put TTL<=0 روی Redis واقعی
 * در tests/Integration/Database/S6LockingReadRoutingTest.php انجام می‌شود.
 */
final class S6CoreSecurityHardeningTest extends TestCase
{
    // ─────────────────────────────────────────────────────────────
    // FIX-S6-4 — SafeExpression: نویسه‌های کنترلی در لیترال
    // ─────────────────────────────────────────────────────────────

    public function test_nul_in_string_literal_is_rejected(): void
    {
        $this->expectException(SqlExpressionException::class);
        $this->expectExceptionMessage('control characters');
        SafeExpression::parse("status = 'a" . chr(0) . "b'");
    }

    public function test_newline_in_string_literal_is_rejected(): void
    {
        $this->expectException(SqlExpressionException::class);
        $this->expectExceptionMessage('control characters');
        SafeExpression::parse("status = 'line1\nline2'");
    }

    public function test_control_char_inside_literal_via_concat_is_rejected(): void
    {
        $this->expectException(SqlExpressionException::class);
        SafeExpression::parse("note = 'ok" . chr(1) . "trailing'");
    }

    public function test_doubled_quote_literal_still_parses_and_emits(): void
    {
        $expr = SafeExpression::parse("note = 'it''s ok'");
        $this->assertSame("`note` = 'it''s ok'", $expr->emit());
    }

    public function test_like_case_and_alias_still_work(): void
    {
        $sql = SafeExpression::parse("CASE WHEN status = 'deleted' THEN 1 ELSE 0 END AS alive");
        $this->assertSame(
            "CASE WHEN `status` = 'deleted' THEN 1 ELSE 0 END AS `alive`",
            $sql->emit()
        );
        $like = SafeExpression::parse("title LIKE '%paid%'");
        $this->assertSame("`title` LIKE '%paid%'", $like->emit());
    }

    public function test_cast_decimal_params_still_work(): void
    {
        $sql = SafeExpression::parse('CAST(amount AS DECIMAL(12, 2))');
        $this->assertSame('CAST(`amount` AS DECIMAL(12,2))', $sql->emit());
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S6-1 — wrapInstance: مسیر Throwable-غیر-Exception
    // ─────────────────────────────────────────────────────────────

    /** هارنس سبک: check/complete/fail بازنویسی می‌شوند تا DB لازم نباشد (الگوی هارنس فاز ۳) */
    private function makeHarness(array &$trace): IdempotencyKey
    {
        return new class($trace) extends IdempotencyKey {
            /** @param array<string, mixed> $trace */
            public function __construct(private array &$trace)
            {
                parent::__construct(
                    \Core\Database::getInstance(),
                    new Cache(null, sys_get_temp_dir() . '/s6_idem_cache_test/')
                );
            }

            public function check(string $key, int $userId, string $action, ?array $requestData = null, int $retryCount = 0): array
            {
                $this->trace['check_calls'][] = $key;
                return ['is_duplicate' => false];
            }

            public function complete(string $key, $result, int $userId): bool
            {
                $this->trace['completed'][] = $key;
                return true;
            }

            public function fail(string $key, $error, int $userId, bool $retryable = false): bool
            {
                $this->trace['failures'][] = [
                    'key' => $key,
                    'error' => is_array($error) ? $error : (string)$error,
                    'retryable' => $retryable,
                ];
                return true;
            }
        };
    }

    public function test_wrap_instance_marks_failure_and_rethrows_plain_error(): void
    {
        $trace = ['check_calls' => [], 'completed' => [], 'failures' => []];
        $idem = $this->makeHarness($trace);

        // لاگر fallback در تست به stdout echo می‌کند — خروجی انتظارشده اعلام می‌شود
        // (الگوی FIX-S4-4: پیام لاگ تک‌خطی است)
        $this->expectOutputRegex('/^\[INFO\] \d{4}-\d{2}-\d{2} [^\r\n]+$/m');

        $thrown = null;
        try {
            $idem->wrapInstance('s6_error_probe', 1, 's6.test', function (): void {
                throw new \TypeError('boom-non-exception-throwable');
            });
        } catch (\Throwable $e) {
            $thrown = $e;
        }

        $this->assertInstanceOf(\TypeError::class, $thrown, 'همان TypeError باید rethrow شود');
        $this->assertSame('boom-non-exception-throwable', $thrown->getMessage());
        $this->assertCount(1, $trace['failures'], 'FIX-S6-1: fail() باید برای Error هم ثبت شود');
        $this->assertSame('s6_error_probe', $trace['failures'][0]['key']);
        $this->assertStringContainsString('boom-non-exception-throwable', (string)($trace['failures'][0]['error']['error'] ?? ''));
        $this->assertSame(\TypeError::class, $trace['failures'][0]['error']['exception'] ?? null);
        $this->assertSame([], $trace['completed'], 'مسیر شکست نباید complete شود');
        $this->assertFalse($trace['failures'][0]['retryable'], 'Error شناخته‌نشده = non-retryable (سیاست مالی محافظه‌کار)');
    }

    public function test_wrap_instance_still_rethrows_exception_with_fail_recorded(): void
    {
        $trace = ['check_calls' => [], 'completed' => [], 'failures' => []];
        $idem = $this->makeHarness($trace);

        $this->expectOutputRegex('/^\[INFO\] \d{4}-\d{2}-\d{2} [^\r\n]+$/m');

        $thrown = null;
        try {
            $idem->wrapInstance('s6_exc_probe', 2, 's6.test', function (): void {
                throw new \RuntimeException('classic-failure');
            });
        } catch (\Throwable $e) {
            $thrown = $e;
        }

        $this->assertInstanceOf(\RuntimeException::class, $thrown);
        $this->assertCount(1, $trace['failures']);
        $this->assertSame([], $trace['completed']);
    }

    public function test_wrap_instance_success_path_unchanged(): void
    {
        $trace = ['check_calls' => [], 'completed' => [], 'failures' => []];
        $idem = $this->makeHarness($trace);

        $this->expectOutputRegex('/^\[INFO\] \d{4}-\d{2}-\d{2} [^\r\n]+$/m');

        $result = $idem->wrapInstance('s6_ok_probe', 3, 's6.test', fn (): array => ['ok' => true]);

        $this->assertSame(['ok' => true], $result);
        $this->assertSame(['s6_ok_probe'], $trace['completed']);
        $this->assertSame([], $trace['failures']);
    }

    public function test_unknown_throwable_is_classified_non_retryable(): void
    {
        $trace = ['check_calls' => [], 'completed' => [], 'failures' => []];
        $idem = $this->makeHarness($trace);

        $m = new \ReflectionMethod(IdempotencyKey::class, 'isRetryableException');
        $m->setAccessible(true);

        $this->assertFalse($m->invoke($idem, new \TypeError('x')));
        $this->assertFalse($m->invoke($idem, new \Error('x')));
        $this->assertFalse($m->invoke($idem, new \RuntimeException('x')));
    }
}
