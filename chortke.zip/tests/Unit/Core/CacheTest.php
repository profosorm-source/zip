<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\Cache;
use PHPUnit\Framework\TestCase;

class CacheTest extends TestCase
{
    private string $cacheDir;
    private Cache $cache;

    protected function setUp(): void
    {
        $this->cacheDir = sys_get_temp_dir() . '/chortke_cache_test/';
        $this->cleanupCacheDir();
        $this->cache = new Cache(null, $this->cacheDir);
    }

    protected function tearDown(): void
    {
        $this->cache->flushAllLocks();
        $this->cleanupCacheDir();
    }

    public function testFileDriverPutGetHasForgetAndFlush(): void
    {
        $cache = $this->cache;

        $this->assertTrue($cache->put('foo', 'bar', 10));
        $this->assertTrue($cache->has('foo'));
        $this->assertSame('bar', $cache->get('foo'));
        $this->assertTrue($cache->forget('foo'));
        $this->assertFalse($cache->has('foo'));

        $this->assertTrue($cache->put('foo', 'baz', 10));
        $this->assertTrue($cache->flush());
        $this->assertFalse($cache->has('foo'));
    }

    public function testRememberCachesCallbackResult(): void
    {
        $cache = $this->cache;
        $count = 0;

        $result = $cache->remember('remember_key', 10, function () use (&$count) {
            $count++;
            return ['name' => 'ali'];
        });

        $this->assertSame(['name' => 'ali'], $result);
        $this->assertSame(1, $count);
        $this->assertSame(['name' => 'ali'], $cache->remember('remember_key', 10, function () use (&$count) {
            $count++;
            return ['name' => 'error'];
        }));
        $this->assertSame(1, $count);
    }

    public function testPullReturnsValueAndForgetsKey(): void
    {
        $cache = $this->cache;
        $cache->put('temp', 'value', 10);

        $this->assertSame('value', $cache->pull('temp'));
        $this->assertFalse($cache->has('temp'));
    }

    public function testIncrementDecrementAndTtl(): void
    {
        $cache = $this->cache;

        $this->assertSame(1, $cache->increment('counter', 1, 2));
        $this->assertSame(0, $cache->decrement('counter', 1, 2));
        $this->assertGreaterThanOrEqual(0, $cache->ttl('counter'));
    }

    public function testIncrementFloatWorksAndPreservesValue(): void
    {
        $cache = $this->cache;

        $this->assertSame(1.5, $cache->incrementFloat('float_counter', 1.5, 2));
        $this->assertSame(3.0, $cache->incrementFloat('float_counter', 1.5, 2));
    }

    public function testCleanupRemovesExpiredFiles(): void
    {
        $cache = $this->cache;
        $this->expectOutputRegex('/cache\.file\.cleanup\.completed/');

        // FIX-S6-3: put با ttl<=0 اکنون forget می‌کند و هرگز «فایل منقضی» نمی‌سازد
        // (قرارداد واحد هر دو بک‌اند؛ قرارداد قبلی put(-1) برای ساخت فایل منقضی بود).
        // cleanup() برای جاروب بقایای واقعی روی دیسک است (بقایای پردازش قبلی/کرش) —
        // فایل منقضی مستقیماً در قالب رسمی filePut ساخته می‌شود تا همان سناریو
        // شبیه‌سازی شود.
        $expiredFile = $this->cacheDir . md5('old') . '.cache';
        $payload = json_encode(['expire_at' => time() - 100, 'value' => 'expired'], JSON_UNESCAPED_UNICODE);
        $this->assertNotFalse($payload);
        $this->assertTrue((bool) file_put_contents($expiredFile, $payload, LOCK_EX));

        $cleaned = $cache->cleanup();

        $this->assertGreaterThanOrEqual(1, $cleaned);
        $this->assertFalse($cache->has('old'));
        $this->assertFalse(file_exists($expiredFile));
    }

    public function testTaggedCacheFlushRemovesTaggedKeys(): void
    {
        $cache = $this->cache;
        $tagged = $cache->tags(['users']);

        $this->assertTrue($tagged->put('profile', ['name' => 'ali'], 10));
        $this->assertTrue($tagged->has('profile'));
        $this->assertSame(['name' => 'ali'], $tagged->get('profile'));

        $tagged->flush();
        $this->assertFalse($tagged->has('profile'));
    }

    public function testWithLockExecutesCallbackAndReleasesLock(): void
    {
        $cache = $this->cache;

        $result = $cache->withLock('lock-key', function () {
            return 'locked';
        }, 1);

        $this->assertSame('locked', $result);
        $this->assertTrue($cache->lock('lock-key', 1, 1));
        $this->assertTrue($cache->unlock('lock-key'));
    }

    private function cleanupCacheDir(): void
    {
        if (!is_dir($this->cacheDir)) {
            return;
        }

        $files = glob($this->cacheDir . '*') ?: [];
        foreach ($files as $file) {
            @unlink($file);
        }
    }
}
