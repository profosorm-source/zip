<?php

declare(strict_types=1);

namespace Tests\Unit\Core;

use Core\QueryBuilder;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🔒 AUDIT-FIX (static security audit R4-MEDIUM) — پینِ رگرسیون گارد عملگرهای NULL.
 *
 * باگِ پین‌شده: فراخوانی سه‌پارامتری where('col', 'IS NULL', null) توسط shorthand
 * دوارگامی به where('col', '=', 'IS NULL') تخریب می‌شد (مقایسهٔ ستون با رشتهٔ
 * 'IS NULL' به‌جای شرط NULL) و فیلتر is_verified فهرست کاربران نتیجهٔ نادرست
 * می‌داد. اکنون: عملگرهای NULL پیش از shorthand پردازش می‌شوند و User.php از
 * API صریح whereNull/whereNotNull استفاده می‌کند.
 */
final class QueryBuilderNullOperatorGuardTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** SQL یک SELECT ساده را با بایندها برمی‌گرداند (reflection روی buildSelectQuery). */
    private function compile(QueryBuilder $qb, array &$bindings = []): string
    {
        $method = new \ReflectionMethod(QueryBuilder::class, 'buildSelectQuery');
        $method->setAccessible(true);
        return (string) $method->invokeArgs($qb, [&$bindings]);
    }

    public function test_three_arg_is_null_is_not_degraded_to_string_compare(): void
    {
        $qb = (new QueryBuilder(m::mock(\PDO::class)))->select('*')->table('users');
        $qb->where('email_verified_at', 'IS NULL', null);
        $sql = $this->compile($qb);

        $this->assertStringContainsString('`email_verified_at` IS NULL', $sql);
        $this->assertStringNotContainsString("'IS NULL'", $sql);
    }

    public function test_three_arg_is_not_null_is_not_degraded_to_string_compare(): void
    {
        $qb = (new QueryBuilder(m::mock(\PDO::class)))->select('*')->table('users');
        $qb->where('email_verified_at', 'IS NOT NULL', null);
        $sql = $this->compile($qb);

        $this->assertStringContainsString('`email_verified_at` IS NOT NULL', $sql);
        $this->assertStringNotContainsString("'IS NOT NULL'", $sql);
    }

    public function test_lowercase_null_operator_is_normalized(): void
    {
        $qb = (new QueryBuilder(m::mock(\PDO::class)))->select('*')->table('users');
        $qb->where('deleted_at', 'is null', null);
        $this->assertStringContainsString('`deleted_at` IS NULL', $this->compile($qb));
    }

    public function test_or_where_null_operator_is_not_degraded(): void
    {
        $qb = (new QueryBuilder(m::mock(\PDO::class)))->select('*')->table('users');
        $qb->orWhere('mobile', 'IS NULL', null);
        $this->assertStringContainsString('`mobile` IS NULL', $this->compile($qb));
    }

    public function test_two_arg_shorthand_still_works_for_values(): void
    {
        $qb = (new QueryBuilder(m::mock(\PDO::class)))->select('*')->table('users');
        $qb->where('email', 'a@b.c');
        $bindings = [];
        $sql = $this->compile($qb, $bindings);

        $this->assertStringContainsString('`email` = ?', $sql);
        $this->assertSame('a@b.c', $bindings[0] ?? null);
    }

    public function test_null_value_with_equals_still_compiles_to_is_null(): void
    {
        // رفتار قدیمی و درست: where('col', null) دوپارامتری ⇒ IS NULL
        $qb = (new QueryBuilder(m::mock(\PDO::class)))->select('*')->table('users');
        $qb->where('remember_token', null);
        $this->assertStringContainsString('`remember_token` IS NULL', $this->compile($qb));
    }
}
