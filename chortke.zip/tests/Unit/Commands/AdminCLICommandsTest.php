<?php

namespace Tests\Unit\Commands;

use PHPUnit\Framework\TestCase;
use App\Commands\OutboxPublishCommand;
use App\Commands\BackfillSearchProjectionCommand;
use App\Commands\DLQRetryCommand;
use App\Commands\StuckWithdrawalReviewCommand;
use App\Commands\DatabaseAnalyzerCommand;
use Mockery as m;

class AdminCLICommandsTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function outbox_publish_command_works_correctly(): void
    {
        $publisher = m::mock('App\Services\OutboxPublisher');
        $logger = m::mock('App\Contracts\LoggerInterface');

        // FIX-CMD063: فرمان حالا failClosed را بر اساس محیط (تست = non-production ⇒ false)
        // به publishPending پاس می‌دهد؛ مک با هر دو آرگومان تطبیق داده می‌شود.
        $publisher->shouldReceive('publishPending')
            ->with(50, false)
            ->once()
            ->andReturn(['published' => 12, 'failed' => 0]);

        $logger->shouldIgnoreMissing();

        $cmd = new OutboxPublishCommand($publisher, $logger);

        ob_start();
        $cmd->run(['--limit=50']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('published=12 failed=0', $output);
    }

    /** @test */
    public function backfill_search_projection_command_handles_parameters(): void
    {
        $job = m::mock('App\Jobs\BackfillSearchProjectionJob');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $job->shouldReceive('handle')
            ->with(['source' => 'transactions', 'batch_size' => 100])
            ->once();

        $logger->shouldIgnoreMissing();

        $cmd = new BackfillSearchProjectionCommand($job, $logger);

        ob_start();
        $cmd->run(['--source=transactions', '--batch=100']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('starting (source=transactions, batch=100)', $output);
    }

    /** @test */
    public function dlq_retry_command_is_instantiable_and_runs_purge(): void
    {
        $db = m::mock('Core\Database');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        // FIX-C132/C97 (مسیر no-model): purge اکنون «آرشیو در dlq_archive + حذف
        // گارددار (بدون processing/quarantined)» در یک تراکنش است.
        $db->shouldIgnoreMissing();
        $db->shouldReceive('execute')->andReturn(5); // 5 deleted
        $db->shouldReceive('beginTransaction')->byDefault();
        $db->shouldReceive('commit')->byDefault();
        $db->shouldReceive('inTransaction')->andReturn(true)->byDefault();

        $cmd = new DLQRetryCommand($db, $logger, null);

        ob_start();
        $cmd->execute(['purge', '15']); // purge older than 15 days
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Purged 5 failed jobs permanently', $output);
    }

    /** @test */
    public function stuck_withdrawal_review_command_scans_correctly(): void
    {
        $reconciliation = m::mock('App\Services\ReconciliationService');
        $withdrawalAdmin = m::mock('App\Services\Withdrawal\WithdrawalAdminService');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $reconciliation->shouldReceive('flagStuckWithdrawals')
            ->with(120, 200)
            ->once()
            ->andReturn([
                'scanned' => 50,
                'flagged' => 5,
                'notified' => 2,
                'skipped' => 0
            ]);

        $logger->shouldIgnoreMissing();

        $cmd = new StuckWithdrawalReviewCommand($reconciliation, $withdrawalAdmin, $logger);

        ob_start();
        $cmd->run(['cli.php', 'withdrawals:review:scan', '--minutes=120', '--limit=200']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('scanned=50 flagged=5 notified=2 skipped=0', $output);
    }

    /** @test */
    public function database_analyzer_command_displays_slow_queries(): void
    {
        $analyzer = m::mock('App\Services\DatabaseAnalyzerService');

        $analyzer->shouldReceive('getSlowQueries')
            ->once()
            ->andReturn([[
                'sql_text' => 'SELECT * FROM users',
                'query_count' => 4,
                'avg_time_ms' => 1250.5,
            ]]);

        $cmd = new DatabaseAnalyzerCommand($analyzer);

        ob_start();
        $cmd->run(['cli.php', 'db:analyze', 'slow-queries']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Recent Slow Queries', $output);
        $this->assertStringContainsString('SELECT * FROM users', $output);
    }

    /** @test */
    public function database_analyzer_command_displays_deadlocks(): void
    {
        $analyzer = m::mock('App\Services\DatabaseAnalyzerService');

        $analyzer->shouldReceive('getDeadlockInfo')
            ->once()
            ->andReturn([[
                'detected_at' => '2026-07-26 22:00:00',
                'summary' => 'Transaction rollback caused by lock conflict',
            ]]);

        $cmd = new DatabaseAnalyzerCommand($analyzer);

        ob_start();
        $cmd->run(['cli.php', 'db:analyze', 'deadlocks']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Recent InnoDB Deadlocks', $output);
        $this->assertStringContainsString('Transaction rollback caused by lock conflict', $output);
    }

    /**
     * @test
     * FIX-TBLVIEW: db:analyze — جدول‌های BASE TABLE با rows/size چاپ می‌شوند و
     * VIEWها به‌جای «? rows ?» گمراه‌کننده، برچسب صریح [VIEW] می‌گیرند
     * (TABLE_ROWS برای VIEW در INFORMATION_SCHEMA همیشه NULL است).
     */
    public function database_analyzer_command_labels_views_instead_of_question_rows(): void
    {
        $analyzer = m::mock('App\Services\DatabaseAnalyzerService');

        // showOverview فقط این سه متد را صدا می‌زند (Connection Pool → Health
        // Check → Table Statistics)؛ slow-queries/deadlocks اکشن‌های جدا هستند.
        $analyzer->shouldReceive('getConnectionStats')->once()->andReturn(['connections' => 2]);
        $analyzer->shouldReceive('healthCheck')->once()->andReturn([]);
        $analyzer->shouldReceive('getTableStats')
            ->once()
            ->andReturn([
                ['table' => 'users', 'type' => 'BASE TABLE', 'rows' => 42, 'size_mb' => '1.25'],
                ['table' => 'v_user_wallets', 'type' => 'VIEW', 'rows' => null, 'size_mb' => null],
            ]);

        $cmd = new DatabaseAnalyzerCommand($analyzer);

        ob_start();
        $cmd->run(['cli.php', 'db:analyze']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('users', $output);
        $this->assertStringContainsString('42 rows', $output);
        $this->assertStringContainsString('v_user_wallets', $output);
        $this->assertStringContainsString('[VIEW]', $output);
        // «? rows ?» دیگر نباید برای VIEW چاپ شود
        $this->assertStringNotContainsString('? rows', $output);
    }
}
