<?php

declare(strict_types=1);

namespace Tests\Unit\Commands;

use PHPUnit\Framework\TestCase;
use App\Commands\DLQRetryCommand;
use App\Models\FailedJob;
use App\Contracts\LoggerInterface;
use Core\Database;
use Core\Queue;
use Mockery as m;

/**
 * تست حرفه‌ای DLQRetryCommand (دستور بازیابی/پاکسازی صف مرده).
 *
 * FIX-CMD013/CMD014: قرارداد جدید claim-first:
 *   - claim اتمیک (FailedJob::claimForRetry) قبل از هر اثر جانبی — حصار
 *     در برابر retry موازی و ورکر DLQ؛
 *   - push خارج از تراکنش DB (اثر جانبی redis داخل تراکنش نیست)؛
 *   - حذف فقط با گارد مالکیت claim (status='processing')؛
 *   - در شکست push، claim آزاد می‌شود (releaseRetryClaim) و ردیف retryable می‌ماند.
 *
 * نکتهٔ قرارداد: requeue باید از Queue::push عبور کند (سازگار با درایور redis)،
 * نه INSERT مستقیم به جدول ناموجود «jobs».
 */
class DLQRetryCommandTest extends TestCase
{
    /** @var Database&\Mockery\MockInterface */
    private Database $db;
    /** @var LoggerInterface&\Mockery\MockInterface */
    private LoggerInterface $logger;
    /** @var FailedJob&\Mockery\MockInterface */
    private FailedJob $failedJob;
    /** @var Queue&\Mockery\MockInterface */
    private Queue $queue;
    private DLQRetryCommand $command;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock(Database::class);
        $this->logger = m::mock(LoggerInterface::class);
        $this->failedJob = m::mock(FailedJob::class);
        $this->queue = m::mock(Queue::class);

        $this->command = new DLQRetryCommand(
            $this->db,
            $this->logger,
            $this->failedJob,
            $this->queue
        );
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function it_can_be_instantiated_with_all_dependencies(): void
    {
        $this->assertInstanceOf(DLQRetryCommand::class, $this->command);
    }

    /**
     * @test
     * FIX-CMD013/CMD014: requeue موفق با الگوی claim-first — claim اتمیک →
     * push (بیرون از تراکنش) → حذف گارددارِ مالکیت claim. هیچ beginTransaction
     * در مسیر retry انبوه نباید رخ دهد.
     */
    public function it_requeues_failed_jobs_with_claim_first_pattern(): void
    {
        // FIX-R36-W3 (F-A19e-12): exclude-fatal از این راند پیش‌فرضِ روشن است؛ فیکسچر
        // به استثنای غیرقطعی تغییر کرد تا «مسیر بازپخشِ جاب سالم» را — که intent این
        // تست است — همچنان تحت پیش‌فرض جدید پین کند (BusinessException دیگر بازصف
        // پیش‌فرض ندارد؛ پوشش آن در it_skips_fatal_jobs_when_exclude_fatal_is_enabled).
        $job = (object) [
            'id' => 42,
            'queue' => 'default',
            'payload' => '{"job":"App\\\\Jobs\\\\SendEmailJob","data":{"task":"email.send"}}',
            'exception' => 'RuntimeException: connection reset by peer',
        ];

        $this->failedJob->shouldReceive('fetchByQueue')
            ->once()
            ->with('default', 50)
            ->andReturn([$job]);

        // FIX-CMD013: claim اتمیک قبل از هر اثر جانبی
        $this->failedJob->shouldReceive('claimForRetry')
            ->once()
            ->with(42)
            ->andReturn(true);
        $this->failedJob->shouldNotReceive('releaseRetryClaim');

        // FIX-CMD014: push خارج از تراکنش — هیچ beginTransaction/commit نباید باشد
        $this->db->shouldNotReceive('beginTransaction');
        $this->db->shouldNotReceive('commit');
        $this->db->shouldNotReceive('rollback');

        $this->queue->shouldReceive('push')
            ->once()
            ->with(
                'App\\Jobs\\SendEmailJob',
                ['task' => 'email.send'],
                'default'
            )
            ->andReturn(true);
        $this->db->shouldReceive('execute')
            ->once()
            ->with(
                m::on(fn ($sql) => str_contains($sql, 'DELETE FROM failed_jobs') && str_contains($sql, "status = 'processing'")),
                [42]
            )
            // حذف فقط با گارد مالکیت claim — یک ردیف حذف‌شده = موفقیت
            ->andReturn(1);

        $this->logger->shouldReceive('info')
            ->once()
            ->with('dlq.job_retried', m::on(fn ($ctx) => $ctx['failed_job_id'] === 42));

        ob_start();
        $exit = $this->command->execute(['retry', 'default']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Successfully requeued 1 jobs', $output);
        // FIX-CMD017: موفقیت ⇒ کد خروج ۰ (قرارداد FIX-C141)
        $this->assertSame(0, $exit);
    }

    /**
     * @test
     * FIX-CMD014: هنگام استثنا در push، claim باید آزاد شود (releaseRetryClaim)،
     * خطا لاگ شود و job رها شود — بدون rollback (تراکنشی در کار نیست).
     */
    public function it_releases_claim_and_logs_error_when_requeue_fails(): void
    {
        $job = (object) [
            'id' => 7,
            'queue' => 'default',
            'payload' => '{"job":"App\\\\Jobs\\\\LogPerformanceJob","data":{}}',
            'exception' => '',
        ];

        $this->failedJob->shouldReceive('fetchByQueue')
            ->once()
            ->with('default', 50)
            ->andReturn([$job]);

        $this->failedJob->shouldReceive('claimForRetry')
            ->once()
            ->with(7)
            ->andReturn(true);
        $this->failedJob->shouldReceive('releaseRetryClaim')
            ->once()
            ->with(7)
            ->andReturn(true);

        $this->db->shouldNotReceive('beginTransaction');
        $this->db->shouldNotReceive('rollback');

        $this->queue->shouldReceive('push')
            ->once()
            ->with('App\\Jobs\\LogPerformanceJob', [], 'default')
            ->andThrow(new \RuntimeException('Deadlock detected'));

        $this->logger->shouldReceive('error')
            ->once()
            ->with('dlq.retry_failed', m::on(fn ($ctx) =>
                $ctx['failed_job_id'] === 7 && $ctx['error'] === 'Deadlock detected'));

        ob_start();
        $exit = $this->command->execute(['retry', 'default']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Failed to retry job 7', $output);
        $this->assertStringContainsString('Successfully requeued 0 jobs', $output);
        // FIX-CMD017: شکست بازصف دیگر exit 0 نیست — کد خروج ۱ پین می‌شود
        $this->assertSame(1, $exit);
    }

    /**
     * @test
     * FIX-CMD013: وقتی claim اتمیک از دست برود (ورکر یا retry موازی زودتر رسید)،
     * دیگر نباید push انجام شود — جاب دوبله ساختنی نیست.
     */
    public function it_does_not_push_when_claim_is_lost(): void
    {
        $job = (object) [
            'id' => 9,
            'queue' => 'default',
            'payload' => '{"job":"App\\\\Jobs\\\\LogPerformanceJob","data":{}}',
            'exception' => '',
        ];

        $this->failedJob->shouldReceive('fetchByQueue')
            ->once()
            ->with('default', 50)
            ->andReturn([$job]);

        $this->failedJob->shouldReceive('claimForRetry')
            ->once()
            ->with(9)
            ->andReturn(false);
        $this->failedJob->shouldNotReceive('releaseRetryClaim');

        $this->queue->shouldNotReceive('push');
        $this->db->shouldNotReceive('beginTransaction');
        $this->db->shouldNotReceive('execute');

        $this->logger->shouldNotReceive('info');

        ob_start();
        $exit = $this->command->execute(['retry', 'default']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Successfully requeued 0 jobs', $output);
        // FIX-CMD017: ازدست‌رفتن claim شکستِ بازصف نیست ⇒ کد خروج ۰
        $this->assertSame(0, $exit);
    }

    /**
     * @test
     * در حالت --exclude-fatal، jobهای دارای خطای مهلک (Validation/Business/TypeError...)
     * باید شمارش و رد شوند بدون اینکه تراکنش اجرا شود.
     */
    public function it_skips_fatal_jobs_when_exclude_fatal_is_enabled(): void
    {
        $fatal = (object) [
            'id' => 1,
            'queue' => 'default',
            'payload' => '{"job":"App\\\\Jobs\\\\SendEmailJob","data":{}}',
            'exception' => 'App\Exceptions\ValidationException: bad input',
        ];
        $ok = (object) [
            'id' => 2,
            'queue' => 'default',
            'payload' => '{"job":"App\\\\Jobs\\\\LogPerformanceJob","data":{"ok":1}}',
            'exception' => 'PDOException: connection lost, retry later',
        ];

        $this->failedJob->shouldReceive('fetchByQueue')
            ->once()
            ->with('default', 50)
            ->andReturn([$fatal, $ok]);

        // job مهلک قبل از claim رد می‌شود؛ فقط job سالم claim و requeue می‌شود.
        $this->failedJob->shouldNotReceive('claimForRetry')->with(1);
        $this->failedJob->shouldReceive('claimForRetry')
            ->once()
            ->with(2)
            ->andReturn(true);
        $this->failedJob->shouldNotReceive('releaseRetryClaim');

        // FIX-CMD014: مسیر جدید بدون تراکنش است
        $this->db->shouldNotReceive('beginTransaction');
        $this->db->shouldNotReceive('commit');
        $this->queue->shouldReceive('push')
            ->once()
            ->with('App\\Jobs\\LogPerformanceJob', ['ok' => 1], 'default')
            ->andReturn(true);
        $this->db->shouldReceive('execute')
            ->once()
            ->with(m::on(fn ($sql) => str_contains($sql, 'DELETE FROM failed_jobs') && str_contains($sql, "status = 'processing'")), [2])
            ->andReturn(1);

        $this->logger->shouldReceive('info')
            ->once()
            ->with('dlq.job_retried', m::on(fn ($ctx) => $ctx['failed_job_id'] === 2));

        ob_start();
        $exit = $this->command->execute(['retry', 'default', '--exclude-fatal']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Skipped 1 fatal errors', $output);
        $this->assertStringContainsString('Successfully requeued 1 jobs', $output);
        $this->assertSame(0, $exit); // FIX-CMD017
    }

    /**
     * @test
     * حالت purge باید jobs قدیمی را به‌صورت دائمی حذف کند و لاگ ثبت کند.
     */
    public function it_purges_failed_jobs_older_than_given_days(): void
    {
        $this->failedJob->shouldReceive('purge')
            ->once()
            ->with(30)
            ->andReturn(12);

        $this->logger->shouldReceive('info')
            ->once()
            ->with('dlq.purged', m::on(fn ($ctx) =>
                $ctx['count'] === 12 && $ctx['older_than_days'] === 30));

        ob_start();
        $exit = $this->command->execute(['purge', '30']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Purged 12 failed jobs permanently', $output);
        $this->assertSame(0, $exit); // FIX-CMD017
    }

    /**
     * @test
     * بدون ورودی، دستور به‌صورت پیش‌فرض روی صف 'default' اجرا می‌شود.
     */
    public function it_defaults_to_retry_action_and_default_queue(): void
    {
        $this->failedJob->shouldReceive('fetchByQueue')
            ->once()
            ->with('default', 50)
            ->andReturn([]);

        ob_start();
        $exit = $this->command->execute(['retry', 'default']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('No failed jobs found', $output);
        $this->assertSame(0, $exit); // FIX-CMD017
    }
}
