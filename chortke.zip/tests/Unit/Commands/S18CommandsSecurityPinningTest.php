<?php

declare(strict_types=1);

namespace Tests\Unit\Commands;

use PHPUnit\Framework\TestCase;

/**
 * S18 — قفل‌کنندهٔ امنیتی لایهٔ Console/Commands (۲۴ کماند + Kernel — ۵٬۴۳۴ خط، خط‌به‌خط).
 *
 * پین‌کردن ناورداهای بچ S18 (صفر فیکس کد — لایه سالم ارزیابی شد):
 *  ① تنها exec() در Kernel با escapeshellarg کامل است (X129) — هیچ exec دیگری
 *     در app/Commands مجاز نیست.
 *  ② حذف فایل KYC در Kernel با realpath-containment و basename است — بدون
 *     traversal.
 *  ③ واپاشی fraud (scores:decay) از مسیر لجر است — هرگز مستقیم UPDATE
 *     user_scores نمی‌نویسد (X359)؛ بازسازی (scores:rebuild) مرجع upsert است.
 *  ④ حذف مخرب feature:delete در محیط غیرتعاملی بدون --force ممنوع است
 *     (گارد stream_isatty).
 *  ⑤ اسکن عرضی کل app/Commands + app/Console برای توکن‌های خطرناک — صفر.
 *  ⑥ درون‌یابی LIMIT فقط در سایت‌های allowlist-شدهٔ int-ثابت.
 */
final class S18CommandsSecurityPinningTest extends TestCase
{
    /** ریشهٔ پروژه — بدون وابستگی به BASE_PATH (در testing bootstrap تعریف نشده) */
    private const ROOT = __DIR__ . '/../../..';

    private function read(string $relative): string
    {
        return (string)file_get_contents(self::ROOT . '/' . $relative);
    }

    public function testKernelExecIsSingleAndFullyEscaped(): void
    {
        $kernel = $this->read('app/Console/Kernel.php');

        // FIX-P3-CMD-152: تنها استثنای مجاز، فراخوان متد phpredis «->exec()» است
        // (فلاش تراکنش MULTI برای جایگزینی اتمیک اعضای set تگ‌ها) — اجرای shell نیست.
        // شمارش فقط سایت‌های بدون «->» را می‌بیند تا intent پین (ممنوعیت exec خام/
        // shell) حفظ شود و سایت Redis مستند در پین بعدی قفل باشد.
        $codeOnly = (string)preg_replace('/->\s*exec\s*\(/', '', $kernel);
        $execCount = preg_match_all('/(?<![\w$-])exec\s*\(/', $codeOnly);
        $this->assertSame(1, $execCount, 'تنها فراخوان exec در Kernel باید سایت outbox_publisher باشد');

        $this->assertStringContainsString('escapeshellarg(PHP_BINARY)', $kernel, 'باینری PHP باید escape شود');
        $this->assertStringContainsString("escapeshellarg(BASE_PATH . '/cli.php')", $kernel, 'مسیر cli.php باید escape شود');
        $this->assertStringNotContainsString("exec('php", $kernel, 'فراخوان php از PATH ممنوع (X129)');
    }

    /** FIX-P3-CMD-152: سایت تراکنش Redis در Kernel — اتمیک و بدون اسکریپت Lua/eval */
    public function testKernelRedisTagReplacementIsTransactionalWithoutLua(): void
    {
        $kernel = $this->read('app/Console/Kernel.php');
        $this->assertStringContainsString('\\Redis::MULTI', $kernel, 'جایگزینی اعضای set تگ باید در تراکنش MULTI باشد');
        $this->assertStringNotContainsString('eval(', $kernel, 'اسکریپت Lua در لایهٔ Console ممنوع است');
        $this->assertStringContainsString('$pipe->exec()', $kernel, 'فلاش تراکنش فقط با فراخوان متد phpredis مجاز است');
    }

    public function testCommandsLayerHasNoShellExecutionPrimitives(): void
    {
        $forbidden = ['shell_exec', 'passthru', 'proc_open', 'popen', 'system(', 'eval('];
        $violations = [];

        $dirs = [self::ROOT . '/app/Commands', self::ROOT . '/app/Console'];
        foreach ($dirs as $dir) {
            $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir));
            /** @var \SplFileInfo $fileInfo */
            foreach ($iterator as $fileInfo) {
                if ($fileInfo->getExtension() !== 'php') {
                    continue;
                }
                $content = (string)file_get_contents($fileInfo->getPathname());
                foreach ($forbidden as $token) {
                    if (str_contains($content, $token)) {
                        $violations[] = $fileInfo->getPathname() . ' → ' . $token;
                    }
                }
            }
        }

        $this->assertSame([], $violations, 'لایهٔ Commands/Console نباید primitive اجرای shell داشته باشد');
    }

    public function testKycFileCleanupUsesRealpathContainment(): void
    {
        $kernel = $this->read('app/Console/Kernel.php');

        // گارد مسیر: basename + realpath + containment قبل از unlink
        $this->assertStringContainsString('basename((string) $row[$field])', $kernel, 'نام فایل باید با basename استخراج شود');
        $this->assertStringContainsString('str_starts_with($path, $baseDir . DIRECTORY_SEPARATOR)', $kernel, 'کانتینمنت realpath الزامی است');
        $this->assertStringContainsString("storage_path('uploads/kyc')", $kernel, 'حذف فقط در ریشهٔ مجاز uploads/kyc');
    }

    public function testScoresDecayGoesThroughLedgerNotDirectProjection(): void
    {
        $decay = $this->read('app/Commands/ScoresDecayCommand.php');

        // رشته در کامنت X359 مجاز است؛ «دستور SQL واقعی» ممنوع است
        $codeOnly = (string)preg_replace('/^\s*(\/\/|\*).*$/m', '', $decay);
        $this->assertStringNotContainsString(
            'UPDATE user_scores',
            $codeOnly,
            'واپاشی باید از لجر (applySystemDelta) برود؛ نوشتن مستقیم پروجکشن = drift (X359)'
        );
        $this->assertStringContainsString('applySystemDelta', $decay, 'مسیر رسمی واپاشی = ScoreCommandService::applySystemDelta');
        $this->assertStringContainsString('fraud_decay:', $decay, 'idempotency ساعتی واپاشی باید پابرجا باشد');

        $rebuild = $this->read('app/Commands/ScoresRebuildCommand.php');
        $this->assertStringContainsString('ScoreDomainPolicy::clamp', $rebuild, 'replay باید با clamp مشترک با listener باشد');
        $this->assertStringContainsString('admin_set', $rebuild, 'لنگر مطلق admin_set (X362) باید در replay حفظ شود');
    }

    public function testFeatureDeleteRequiresInteractiveConfirmOrForce(): void
    {
        $cmd = $this->read('app/Commands/FeatureFlagCommand.php');

        $this->assertStringContainsString('stream_isatty(STDIN)', $cmd, 'حذف غیرتعاملی بدون --force باید بلاک شود');
        $this->assertStringContainsString("strtolower((string)\$confirm) !== 'yes'", $cmd, 'تأیید صریح yes الزامی است');
    }

    public function testLimitInterpolationOnlyInPinnedSafeSites(): void
    {
        $hits = [];
        $dirs = [self::ROOT . '/app/Commands', self::ROOT . '/app/Console'];
        foreach ($dirs as $dir) {
            $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir));
            /** @var \SplFileInfo $fileInfo */
            foreach ($iterator as $fileInfo) {
                if ($fileInfo->getExtension() !== 'php') {
                    continue;
                }
                $content = (string)file_get_contents($fileInfo->getPathname());
                if (preg_match_all('/LIMIT \{\$([A-Za-z_]+)\}/', $content, $m, PREG_SET_ORDER)) {
                    foreach ($m as $match) {
                        $hits[] = [$fileInfo->getFilename(), $match[1]];
                    }
                }
            }
        }

        // تنها سایت مجاز: Kernel.php — $batchSize ثابت int داخلی (۱۰۰۰)
        $this->assertNotEmpty($hits, 'حداقل سایت پین‌شدهٔ Kernel باید موجود باشد');
        foreach ($hits as [$file, $var]) {
            $this->assertSame('Kernel.php', $file, "درون‌یابی LIMIT در فایل غیرپین‌شده: {$file}");
            $this->assertSame('batchSize', $var, "متغیر درون‌یابی LIMIT باید batchSize باشد: {$var}");
        }
        $kernel = $this->read('app/Console/Kernel.php');
        $this->assertStringContainsString('$batchSize = 1000;', $kernel, 'batchSize باید ثابت int داخلی باشد');
    }

    public function testFinancialCommandPathsEnforceAdminAttribution(): void
    {
        $cmd = $this->read('app/Commands/StuckWithdrawalReviewCommand.php');

        // L-15: عملیات مالی/اداری هرگز با ادمینِ پیش‌فرض ۰ انجام نمی‌شود
        $this->assertStringContainsString('--admin-id=<id> is required', $cmd, 'اتریبیوشن ادمین الزامی است (L-15)');
        $this->assertStringContainsString('requireAdminId', $cmd, 'گارد requireAdminId باید در resolve/dismiss/auto-fix باشد');
    }
}
