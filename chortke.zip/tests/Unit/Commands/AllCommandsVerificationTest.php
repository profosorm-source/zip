<?php

namespace Tests\Unit\Commands;

use PHPUnit\Framework\TestCase;
use App\Commands\FeatureFlagCommand;
use App\Commands\IdempotencyCommand;
use App\Commands\DLQRetryCommand;
use App\Commands\AnalyticsCacheWarmupCommand;
use App\Commands\AlertRulesBootstrapCommand;
use App\Commands\BackfillSearchProjectionCommand;
use App\Commands\DlqWorkCommand;
use App\Commands\EscrowCleanupCommand;
use App\Commands\MigrationManager;
use App\Commands\ProcessScheduledTasksCommand;
use App\Commands\QueueFailedCommand;
use App\Commands\QueueWorkCommand;
use App\Commands\RateLimitAuditCommand;
use App\Commands\RouteAuditCommand;
use App\Commands\StuckWithdrawalReviewCommand;
use App\Commands\SystemCleanupCommand;
use App\Commands\UpdateTorExitNodesCommand;
use App\Commands\DistributedHealthCommand;
use Mockery as m;

class AllCommandsVerificationTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function feature_flag_command_is_instantiable(): void
    {
        $logger = m::mock('App\Contracts\LoggerInterface');
        $service = m::mock('App\Services\FeatureFlagService');

        $logger->shouldIgnoreMissing();

        $cmd = new FeatureFlagCommand($logger, $service);
        $this->assertInstanceOf(FeatureFlagCommand::class, $cmd);
    }

    /** @test */
    public function idempotency_command_is_instantiable(): void
    {
        $idempotency = m::mock('App\Services\Shared\IdempotencyService');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new IdempotencyCommand($idempotency, $logger);
        $this->assertInstanceOf(IdempotencyCommand::class, $cmd);
    }

    /** @test */
    public function dlq_retry_command_is_instantiable(): void
    {
        $db = m::mock('Core\Database');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new DLQRetryCommand($db, $logger);
        $this->assertInstanceOf(DLQRetryCommand::class, $cmd);
    }

    /** @test */
    public function analytics_cache_warmup_command_is_instantiable(): void
    {
        $logger = m::mock('App\Contracts\LoggerInterface');
        $service = m::mock('App\Services\Analytics\AnalyticsService');

        $logger->shouldIgnoreMissing();

        $cmd = new AnalyticsCacheWarmupCommand($service, $logger);
        $this->assertInstanceOf(AnalyticsCacheWarmupCommand::class, $cmd);
    }

    /** @test */
    public function analytics_cache_warmup_hides_exception_details_on_failure(): void
    {
        /*
        | FIX-YAFTE2 (یافته ۲): هم‌تراز با قرارداد کانونیکال FIX-CMD017/FIX-P3-CMD-088:
        | run(): int (۱ روی شکست)، لاگ با error+exception+file+line، و پیام خام
        | SQL/DSN فقط در لاگ — خروجی operator همان پیام عمومی md5-id است (یافته ۱۲۵).
        | قبلاً: context با exception_type/exception_line و بدون error + exit(1)
        | داخل run که فرمان را غیرقابل‌تست می‌کرد.
        */
        $logger = m::mock('App\Contracts\LoggerInterface');
        $service = m::mock('App\Services\Analytics\AnalyticsService');
        $failure = new \RuntimeException('SELECT secret FROM private_table');

        $logger->shouldIgnoreMissing();
        $service->shouldReceive('getUserMetrics')->once()->andThrow($failure);
        $logger->shouldReceive('error')
            ->once()
            ->with('command.analytics_warmup.failed', m::on(function (array $context) use ($failure): bool {
                return ($context['error'] ?? null) === $failure->getMessage()
                    && ($context['exception'] ?? null) === get_class($failure)
                    && is_string($context['file'] ?? null)
                    && is_int($context['line'] ?? null);
            }));

        ob_start();
        $exitCode = (new AnalyticsCacheWarmupCommand($service, $logger))->run([]);
        $output = str_value(ob_get_clean());

        $this->assertSame(1, $exitCode);
        $this->assertStringContainsString('details in logs', $output);
        $this->assertStringNotContainsString('SELECT secret FROM private_table', $output);
    }

    /** @test */
    public function alert_rules_bootstrap_command_is_instantiable(): void
    {
        $db = m::mock('Core\Database');
        $logger = m::mock('Core\Logger');

        $logger->shouldIgnoreMissing();

        $cmd = new AlertRulesBootstrapCommand($db, $logger);
        $this->assertInstanceOf(AlertRulesBootstrapCommand::class, $cmd);
    }

    /** @test */
    public function backfill_search_projection_command_is_instantiable(): void
    {
        $job = m::mock('App\Jobs\BackfillSearchProjectionJob');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new BackfillSearchProjectionCommand($job, $logger);
        $this->assertInstanceOf(BackfillSearchProjectionCommand::class, $cmd);
    }

    /** @test */
    public function dlq_work_command_is_instantiable(): void
    {
        $worker = m::mock('App\Services\DlqWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new DlqWorkCommand($worker, $logger);
        $this->assertInstanceOf(DlqWorkCommand::class, $cmd);
    }

    /** @test */
    public function dlq_work_command_returns_failure_for_one_shot_worker_errors(): void
    {
        /*
        | FIX-YAFTE2 (یافته ۲): این تست با قرارداد کانونیکال FIX-C141 هم‌تراز شد —
        | return: array با کلید exit_code (هم‌الگوی QueueWorkCommandTest/P3CommandsPinTest)،
        | و context لاگ مطابق FIX-P3-CMD-088: error + exception + file + line.
        | قبلاً: assertSame(1, int) روی قرارداد قدیمی int-return و context بدون error.
        */
        $worker = m::mock('App\Services\DlqWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $failure = new \RuntimeException('secret queue connection details');

        $worker->shouldReceive('work')->once()->with(10)->andThrow($failure);
        $logger->shouldReceive('info')->once()->with('dlq.command.work.starting', ['limit' => 10]);
        $logger->shouldReceive('error')
            ->once()
            ->with('dlq.command.work.failed', m::on(function (array $context) use ($failure): bool {
                return ($context['error'] ?? null) === $failure->getMessage()
                    && ($context['exception'] ?? null) === get_class($failure)
                    && is_string($context['file'] ?? null)
                    && is_int($context['line'] ?? null);
            }));

        $result = (new DlqWorkCommand($worker, $logger))->run([]);

        $this->assertSame(1, $result['exit_code'] ?? null);
        $this->assertSame($failure->getMessage(), $result['error'] ?? null);
        $this->assertSame(0, $result['processed'] ?? null);
    }

    /** @test */
    public function dlq_work_daemon_stops_after_repeated_worker_errors(): void
    {
        /*
        | FIX-YAFTE2 (یافته ۲): seam صحیح این تست interruptibleSleep است (متد واقعی
        | موجود در DlqWorkCommand/QueueWorkCommand — FIX-C141)؛ قبلاً متد غیرواقعی
        | waitForDaemonRetry override می‌شد → sleep واقعی تا ۶۰ثانیه‌ای اجرا می‌شد
        | و کل سوئیت بلاک می‌شد.
        | قرارداد کانونیکال FIX-C142: backoff = min(60, max(sleep,5) * 2**min(n,4))
        | → با sleep=1: [10, 20, 40, 60, 60] برای پنج شکست متوالی.
        | دیمن طبق معماری خواهری (QueueWorkCommand) با شکست‌ها بی‌نهایت backoff
        | می‌کند و فقط با سیگنال quit (shouldQuit) خارج می‌شود.
        */
        $worker = m::mock('App\Services\DlqWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');

        // پنج iteration خطا؛ سیگنال quit بعد از پنجمین شکست می‌رسد (فراخوانی ۶).
        $worker->shouldReceive('shouldQuit')->andReturn(false, false, false, false, false, true);
        $worker->shouldReceive('work')->times(5)->with(10)->andThrow(new \RuntimeException('database unavailable'));
        $logger->shouldIgnoreMissing();

        $command = new class($worker, $logger) extends DlqWorkCommand {
            /** @var list<int> */
            public array $waits = [];

            protected function interruptibleSleep(int $seconds): void
            {
                $this->waits[] = $seconds;
            }
        };

        ob_start();
        $result = $command->run(['--sleep=1']);
        ob_get_clean();

        $this->assertSame(0, $result['processed'] ?? null);
        $this->assertSame([10, 20, 40, 60, 60], $command->waits);
    }

    /** @test */
    public function escrow_cleanup_command_is_instantiable(): void
    {
        $db = m::mock('Core\Database');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $escrow = m::mock('App\Domain\Financial\Services\FinancialEscrowService');

        $logger->shouldIgnoreMissing();

        $cmd = new EscrowCleanupCommand($escrow, $db, $logger);
        $this->assertInstanceOf(EscrowCleanupCommand::class, $cmd);
    }

    /** @test */
    public function migration_manager_command_is_instantiable(): void
    {
        $db = m::mock('Core\Database');
        $cmd = new MigrationManager($db);
        $this->assertInstanceOf(MigrationManager::class, $cmd);
    }

    /** @test */
    public function process_scheduled_tasks_command_is_instantiable(): void
    {
        $deletion = m::mock('App\Services\User\AccountDeletionService');
        $export = m::mock('App\Services\DataExportService');
        $escrow = m::mock('App\Domain\Financial\Services\FinancialEscrowService');
        $db = m::mock('Core\Database');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new ProcessScheduledTasksCommand($deletion, $export, $escrow, $db, $logger);
        $this->assertInstanceOf(ProcessScheduledTasksCommand::class, $cmd);
    }

    /** @test */
    public function queue_failed_command_is_instantiable(): void
    {
        $db = m::mock('Core\Database');
        $queue = m::mock('Core\Queue');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new QueueFailedCommand($db, $queue, $logger);
        $this->assertInstanceOf(QueueFailedCommand::class, $cmd);
    }

    /** @test */
    public function queue_work_command_is_instantiable(): void
    {
        $worker = m::mock('App\Services\QueueWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new QueueWorkCommand($worker, $logger);
        $this->assertInstanceOf(QueueWorkCommand::class, $cmd);
    }

    /** @test */
    public function rate_limit_audit_command_is_instantiable(): void
    {
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new RateLimitAuditCommand($logger);
        $this->assertInstanceOf(RateLimitAuditCommand::class, $cmd);
    }

    /** @test */
    public function route_audit_command_is_instantiable(): void
    {
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new RouteAuditCommand();
        $this->assertInstanceOf(RouteAuditCommand::class, $cmd);
    }

    /** @test */
    public function stuck_withdrawal_review_command_is_instantiable(): void
    {
        $recon = m::mock('App\Services\ReconciliationService');
        $admin = m::mock('App\Services\Withdrawal\WithdrawalAdminService');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new StuckWithdrawalReviewCommand($recon, $admin, $logger);
        $this->assertInstanceOf(StuckWithdrawalReviewCommand::class, $cmd);
    }

    /** @test */
    public function system_cleanup_command_is_instantiable(): void
    {
        $cmd = new SystemCleanupCommand();
        $this->assertInstanceOf(SystemCleanupCommand::class, $cmd);
    }

    /** @test */
    public function update_tor_exit_nodes_command_is_instantiable(): void
    {
        $service = m::mock('App\Services\AntiFraud\TorListUpdater');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldIgnoreMissing();

        $cmd = new UpdateTorExitNodesCommand($service);
        $this->assertInstanceOf(UpdateTorExitNodesCommand::class, $cmd);
    }

    /** @test */
    public function distributed_health_command_is_instantiable_with_its_container_dependency(): void
    {
        $container = m::mock('Core\Container');

        $cmd = new DistributedHealthCommand($container);

        $this->assertInstanceOf(DistributedHealthCommand::class, $cmd);
    }
}
