<?php

declare(strict_types=1);

namespace Tests\Unit\Commands;

use PHPUnit\Framework\TestCase;
use App\Commands\AnalyticsCacheWarmupCommand;
use App\Commands\DLQRetryCommand;
use App\Commands\DatabaseAnalyzerCommand;
use App\Commands\DlqWorkCommand;
use App\Commands\EscrowCleanupCommand;
use App\Commands\IdempotencyCommand;
use App\Commands\MigrationManager;
use App\Commands\OutboxPublishCommand;
use App\Commands\QueueFailedCommand;
use App\Commands\QueueWorkCommand;
use App\Commands\RateLimitAuditCommand;
use App\Commands\RouteAuditCommand;
use App\Commands\ScoresDecayCommand;
use App\Commands\ScoresRebuildCommand;
use App\Commands\SettingsMigrateSecretsCommand;
use App\Commands\SimulateTraceableEventCommand;
use App\Commands\StuckWithdrawalReviewCommand;
use Mockery as m;

/**
 * P3 pin tests — fixes of the app/Commands cluster (p3-cmd-commands round).
 *
 * پین‌های رفتاری اصلاحات FIX-P3-CMD-0xx (راند p3-cmd-commands):
 *  - CMD-008: شمارندهٔ registrations در لاگ completion
 *  - CMD-019: catch \Throwable در حلقهٔ per-job بازصف DLQ
 *  - CMD-025: ماسک literalهای SQL در خروجی slow-queries/deadlocks (بدون --raw)
 *  - CMD-028: ✅/❌ شکل‌آگاه در health — DB سالم دیگر exit 1 نمی‌دهد
 *  - CMD-037/039: قفل اجرای سطح command (skip صادقانه + fail-open بدون کش)
 *  - CMD-052/053: reject گزینهٔ ناشناخته + sanitize کلید status
 *  - CMD-059/060/061: ایندکس پیشرو، skip جدول غایب، report با ردیف آرایه‌ای
 *  - CMD-068: skipped نرمال (bool true هم نمایش داده می‌شود)
 *  - CMD-080/081/082: status در list، exit code، حلقهٔ drain
 *  - CMD-085/086/087/088: بودجهٔ max-jobs، peak memory، allowlist صف، جزئیات exception در لاگ
 *  - CMD-089/090/091: خروج ۱ روی یافته‌ها، مقادیر غیرواقعی policy، mapping خراب
 *  - CMD-095: use function/const و group use در پارسر alias
 *  - CMD-105/112: شمارندهٔ شکست ابطال کش، --user سخت‌گیر
 *  - CMD-117: قفل اجرای مهاجرت secrets (skip صادقانه)
 *  - CMD-124/125: dedup شبیه‌ساز، خطای insert/json
 *  - CMD-131/133: شناسهٔ review تمام‌ارقام، اپراتورِ موجود
 */
class P3CommandsPinTest extends TestCase
{
    private mixed $origRateLimits = null;

    protected function setUp(): void
    {
        parent::setUp();
        /** @var mixed $cfg */
        $cfg = config('rate_limits');
        $this->origRateLimits = $cfg;
    }

    protected function tearDown(): void
    {
        config_set('rate_limits', $this->origRateLimits);
        m::close();
        parent::tearDown();
    }

    // ─────────────────────────── CMD-008 ───────────────────────────

    /** @test */
    public function analytics_warmup_completed_log_includes_registrations_count(): void
    {
        $analytics = m::mock('App\Services\Analytics\AnalyticsService');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $analytics->shouldReceive('getUserMetrics')->once()->andReturn([['u' => 1]]);
        $analytics->shouldReceive('getTransactionMetrics')->once()->andReturn([]);
        $analytics->shouldReceive('getTaskMetrics')->once()->andReturn([]);
        $analytics->shouldReceive('getDailyRegistrations')->once()->with(30)->andReturn([['d' => 1], ['d' => 2], ['d' => 3]]);

        // FIX-P3-CMD-008: شمارندهٔ registrations باید در context لاگ پایان باشد
        $logger->shouldReceive('info')->once()->with(
            'command.analytics_warmup.completed',
            m::on(static fn (array $ctx): bool => ($ctx['registrations_count'] ?? null) === 3
                && ($ctx['user_metrics_count'] ?? null) === 1
                && ($ctx['tx_metrics_count'] ?? null) === 0)
        );

        $cmd = new AnalyticsCacheWarmupCommand($analytics, $logger);

        ob_start();
        $cmd->run([]);
        ob_get_clean();
        // انتظار Mockery (registrations_count=3 در context) در m::close() سنجیده می‌شود
        $this->assertTrue(true, 'completed log must carry registrations_count');
    }

    // ─────────────────────────── CMD-019 ───────────────────────────

    /** @test */
    public function dlq_retry_survives_errors_and_releases_claim_per_job(): void
    {
        $db = m::mock('Core\Database');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $failedJob = m::mock('App\Models\FailedJob');
        $queue = m::mock('Core\Queue');
        $logger->shouldIgnoreMissing();

        $job = (object) [
            'id' => 15,
            'queue' => 'default',
            'payload' => '{"job":"App\\\\Jobs\\\\LogPerformanceJob","data":{}}',
            'exception' => '',
        ];

        $failedJob->shouldReceive('fetchByQueue')->once()->with('default', 50)->andReturn([$job]);
        $failedJob->shouldReceive('claimForRetry')->once()->with(15)->andReturn(true);
        // FIX-P3-CMD-019: با \Error هم claim آزاد می‌شود (catch \Throwable)
        $failedJob->shouldReceive('releaseRetryClaim')->once()->with(15)->andReturn(true);

        $queue->shouldReceive('push')->once()->andThrow(new \Error('TypeError-ish: internal engine failure'));

        $db->shouldNotReceive('beginTransaction');

        $cmd = new DLQRetryCommand($db, $logger, $failedJob, $queue);

        ob_start();
        $exit = $cmd->execute(['retry', 'default']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('Failed to retry job 15', $output);
        $this->assertSame(1, $exit);
    }

    // ─────────────────────────── CMD-025 ───────────────────────────

    /** @test */
    public function database_analyzer_masks_sql_literals_in_slow_queries_by_default(): void
    {
        $analyzer = m::mock('App\Services\DatabaseAnalyzerService');
        $analyzer->shouldReceive('getSlowQueries')->once()->andReturn([[
            'sql_text' => "SELECT * FROM users WHERE email = 'alice@example.com' AND id = 42",
            'query_count' => 4,
            'avg_time_ms' => 1250.5,
        ]]);

        $cmd = new DatabaseAnalyzerCommand($analyzer);

        ob_start();
        $cmd->run(['cli.php', 'db:analyze', 'slow-queries']);
        $output = str_value(ob_get_clean());

        $this->assertStringNotContainsString('alice@example.com', $output, 'literal باید ماسک شود');
        $this->assertStringContainsString("'?'", $output);
        $this->assertStringContainsString('masked', $output);
    }

    /** @test */
    public function database_analyzer_slow_queries_raw_flag_shows_unmasked_text(): void
    {
        $analyzer = m::mock('App\Services\DatabaseAnalyzerService');
        $analyzer->shouldReceive('getSlowQueries')->once()->andReturn([[
            'sql_text' => "SELECT * FROM users WHERE email = 'alice@example.com'",
        ]]);

        $cmd = new DatabaseAnalyzerCommand($analyzer);

        ob_start();
        $cmd->run(['cli.php', 'db:analyze', 'slow-queries', '--raw']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('alice@example.com', $output, '--raw باید عمدی literal را نشان دهد');
    }

    /** @test */
    public function database_analyzer_masks_literals_in_deadlock_summary(): void
    {
        $analyzer = m::mock('App\Services\DatabaseAnalyzerService');
        $analyzer->shouldReceive('getDeadlockInfo')->once()->andReturn([[
            'detected_at' => '2026-07-26 22:00:00',
            'summary' => 'UPDATE wallets SET balance_irt = 500 WHERE id = 9',
        ]]);

        $cmd = new DatabaseAnalyzerCommand($analyzer);

        ob_start();
        $cmd->run(['cli.php', 'db:analyze', 'deadlocks']);
        $output = str_value(ob_get_clean());

        $this->assertStringNotContainsString('balance_irt = 500', $output);
        $this->assertStringContainsString('balance_irt = ?', $output);
    }

    // ─────────────────────────── CMD-028 ───────────────────────────

    /** @test */
    public function database_analyzer_health_is_green_for_a_fully_healthy_db(): void
    {
        $analyzer = m::mock('App\Services\DatabaseAnalyzerService');
        // DB سالم: healthy=true و آرایه‌های issues/recommendations خالی —
        // کد قدیمی empty() را "شکست" می‌گرفت و exit 1 می‌داد (CMD-028)
        $analyzer->shouldReceive('healthCheck')->once()->andReturn([
            'healthy' => true,
            'issues' => [],
            'recommendations' => [],
            'checked_at' => '2026-01-01 00:00:00',
        ]);

        $cmd = new DatabaseAnalyzerCommand($analyzer);

        ob_start();
        $exit = $cmd->run(['cli.php', 'db:analyze', 'health']);
        $output = str_value(ob_get_clean());

        $this->assertSame(0, $exit, 'DB سالم نباید hadFailure بسازد');
        $this->assertStringContainsString('✅ healthy', $output);
        $this->assertStringContainsString('✅ issues', $output);
        $this->assertStringNotContainsString('NEEDS ATTENTION', $output);
    }

    /** @test */
    public function database_analyzer_health_fails_on_nonempty_issues_only(): void
    {
        $analyzer = m::mock('App\Services\DatabaseAnalyzerService');
        $analyzer->shouldReceive('healthCheck')->once()->andReturn([
            'healthy' => false,
            'issues' => ['Table t has no primary key'],
            'recommendations' => ['Add primary key'],
            'checked_at' => '2026-01-01 00:00:00',
        ]);

        $cmd = new DatabaseAnalyzerCommand($analyzer);

        ob_start();
        $exit = $cmd->run(['cli.php', 'db:analyze', 'health']);
        $output = str_value(ob_get_clean());

        $this->assertSame(1, $exit);
        $this->assertStringContainsString('❌ issues', $output);
        $this->assertStringContainsString('NEEDS ATTENTION', $output);
    }

    // ─────────────────────────── CMD-037 ───────────────────────────

    /** @test */
    public function dlq_work_skips_honestly_when_run_lock_is_busy(): void
    {
        $worker = m::mock('App\Services\DlqWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();
        $cache = m::mock('Core\Cache');
        $redis = m::mock(\Redis::class);

        $cache->shouldReceive('redis')->andReturn($redis);
        $cache->shouldReceive('redisKey')->with('dlq:work:run_lock')->andReturn('chortke:dlq:work:run_lock');
        $redis->shouldReceive('set')->once()->andReturn(false); // قفل مشغول

        $worker->shouldNotReceive('work');

        $cmd = new DlqWorkCommand($worker, $logger, null, $cache);

        ob_start();
        $result = $cmd->run([]);
        $output = str_value(ob_get_clean());

        $this->assertSame('lock_busy', $result['skipped'] ?? null);
        $this->assertSame(0, $result['processed'] ?? null);
        $this->assertStringContainsString('skipped: another dlq:work instance holds the run lock', $output);
    }

    /** @test */
    public function dlq_work_fails_open_without_cache_and_processes(): void
    {
        $worker = m::mock('App\Services\DlqWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        // بدون کش — fail-open مستند؛ لایهٔ claim صحت را تضمین می‌کند
        $worker->shouldReceive('work')->once()->with(10)->andReturn([
            'processed' => 2, 'compensated' => 1, 'archived' => 0,
        ]);

        $cmd = new DlqWorkCommand($worker, $logger, null, null);

        ob_start();
        $result = $cmd->run([]);
        ob_get_clean();

        $this->assertSame(2, $result['processed'] ?? null);
    }

    // ─────────────────────────── CMD-039 ───────────────────────────

    /** @test */
    public function escrow_cleanup_skips_when_run_lock_is_busy(): void
    {
        $escrow = m::mock('App\Domain\Financial\Services\FinancialEscrowService');
        $db = m::mock('Core\Database');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();
        $cache = m::mock('Core\Cache');
        $redis = m::mock(\Redis::class);

        $cache->shouldReceive('redis')->andReturn($redis);
        $cache->shouldReceive('redisKey')->with('escrow:cleanup:run_lock')->andReturn('chortke:escrow:cleanup:run_lock');
        $redis->shouldReceive('set')->once()->andReturn(false);

        $escrow->shouldNotReceive('releaseExpiredHolds');

        $cmd = new EscrowCleanupCommand($escrow, $db, $logger, $cache);

        ob_start();
        $exit = $cmd->run(['--force']);
        $output = str_value(ob_get_clean());

        $this->assertSame(0, $exit, 'رقابت عادی است نه شکست');
        $this->assertStringContainsString('skipped: another escrow:cleanup instance holds the run lock', $output);
    }

    /** @test */
    public function escrow_cleanup_fails_open_without_cache_and_releases(): void
    {
        $escrow = m::mock('App\Domain\Financial\Services\FinancialEscrowService');
        $db = m::mock('Core\Database');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();
        $cache = m::mock('Core\Cache');
        $cache->shouldReceive('redis')->andReturn(null); // بدون redis

        $escrow->shouldReceive('releaseExpiredHolds')->once()->andReturn(3);

        $cmd = new EscrowCleanupCommand($escrow, $db, $logger, $cache);

        ob_start();
        $exit = $cmd->run(['--force']);
        ob_get_clean();

        $this->assertSame(0, $exit);
    }

    // ─────────────────────────── CMD-052 ───────────────────────────

    /** @test */
    public function idempotency_command_rejects_unknown_options(): void
    {
        $idempotency = m::mock('App\Services\Shared\IdempotencyService');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $idempotency->shouldNotReceive('cleanup');

        $cmd = new IdempotencyCommand($idempotency, $logger);

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Unknown option');
        $cmd->run(['cli.php', 'idempotency:cleanup', '--dry-run', '--dryrun']);
    }

    // ─────────────────────────── CMD-053 ───────────────────────────

    /** @test */
    public function idempotency_stats_sanitizes_control_chars_in_status_keys(): void
    {
        $idempotency = m::mock('App\Services\Shared\IdempotencyService');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $idempotency->shouldReceive('getStats')->once()->andReturn([
            'total' => 2,
            'by_status' => [
                "ok\r\n\033[31mEVIL" => ['count' => 1, 'last_hour' => 0, 'last_24h' => 1],
            ],
        ]);

        $cmd = new IdempotencyCommand($idempotency, $logger);

        ob_start();
        $cmd->run(['cli.php', 'idempotency:stats']);
        $output = str_value(ob_get_clean());

        $this->assertStringNotContainsString("\033[31m", $output, 'ANSI escape از کلید status حذف شود');
        $this->assertStringNotContainsString("\r", $output);
        $this->assertStringContainsString('EVIL', $output);
    }

    // ───────────────────── CMD-059 / CMD-060 ─────────────────────

    private function makeMigrationDbMock(array $tables, array $columnsByTable, array $leadingIndexCols): \Mockery\MockInterface
    {
        $db = m::mock('Core\Database');
        $db->shouldReceive('fetch')->andReturnUsing(static function (string $sql, array $params = []) use ($tables, $columnsByTable, $leadingIndexCols) {
            if (str_contains($sql, 'information_schema.TABLES')) {
                $table = (string)($params[0] ?? '');
                return in_array($table, $tables, true) ? (object) ['ok' => 1] : null;
            }
            if (str_contains($sql, 'information_schema.COLUMNS')) {
                $table = (string)($params[0] ?? '');
                $column = (string)($params[1] ?? '');
                return in_array($column, $columnsByTable[$table] ?? [], true) ? (object) ['ok' => 1] : null;
            }
            if (str_contains($sql, 'information_schema.STATISTICS')) {
                $table = (string)($params[0] ?? '');
                $column = (string)($params[1] ?? '');
                return in_array($column, $leadingIndexCols[$table] ?? [], true) ? (object) ['INDEX_NAME' => 'idx_x'] : null;
            }
            return null;
        });
        return $db;
    }

    /** @test */
    public function migration_verify_schema_requires_leading_column_index(): void
    {
        // همهٔ جدول/ستون‌ها موجود؛ ایندکس پیشرو فقط برای همهٔ ستون‌ها به‌جز transactions.user_id
        $tables = ['users', 'wallets', 'transactions', 'api_tokens', 'investments', 'withdrawals', 'realtime_messages', 'queues', 'rate_limit_requests'];
        $columnsByTable = [
            'users' => ['id', 'email', 'password', 'status', 'created_at'],
            'wallets' => ['id', 'user_id', 'balance_irt', 'balance_usdt', 'created_at'],
            'transactions' => ['id', 'user_id', 'type', 'amount', 'status', 'created_at'],
            'api_tokens' => ['id', 'user_id', 'token', 'refresh_token', 'expires_at', 'is_active'],
            'investments' => ['id', 'user_id', 'amount', 'status', 'created_at'],
            'withdrawals' => ['id', 'user_id', 'amount', 'status', 'created_at'],
        ];
        $leading = [
            'transactions' => ['status', 'created_at'], // user_id عمداً غایب (فقط ایندکس غیر-پیشرو دارد)
            'withdrawals' => ['user_id', 'status', 'created_at'],
            'api_tokens' => ['user_id', 'token'],
            'realtime_messages' => ['room', 'user_id', 'expires_at'],
            'queues' => ['queue', 'available_at', 'reserved_at'],
            'rate_limit_requests' => ['identifier_key', 'action', 'created_at'],
        ];

        $cmd = new MigrationManager($this->makeMigrationDbMock($tables, $columnsByTable, $leading));

        $issues = $cmd->verifySchema();

        $this->assertContains('⚠️ Index missing for column: transactions.user_id', $issues, 'ستونِ بدون ایندکسِ پیشرو باید یافته شود (CMD-059)');
        $this->assertNotContains('⚠️ Index missing for column: transactions.status', $issues);
        $this->assertNotContains('⚠️ Index missing for column: withdrawals.user_id', $issues);
    }

    /** @test */
    public function migration_verify_schema_skips_index_check_for_missing_table(): void
    {
        $tables = ['users', 'wallets', 'api_tokens', 'investments', 'withdrawals', 'realtime_messages', 'queues', 'rate_limit_requests'];
        // transactions غایب — ستون‌هایش هم بی‌اهمیت‌اند
        $columnsByTable = [
            'users' => ['id', 'email', 'password', 'status', 'created_at'],
            'wallets' => ['id', 'user_id', 'balance_irt', 'balance_usdt', 'created_at'],
            'api_tokens' => ['id', 'user_id', 'token', 'refresh_token', 'expires_at', 'is_active'],
            'investments' => ['id', 'user_id', 'amount', 'status', 'created_at'],
            'withdrawals' => ['id', 'user_id', 'amount', 'status', 'created_at'],
        ];
        $leading = [
            'withdrawals' => ['user_id', 'status', 'created_at'],
            'api_tokens' => ['user_id', 'token'],
            'realtime_messages' => ['room', 'user_id', 'expires_at'],
            'queues' => ['queue', 'available_at', 'reserved_at'],
            'rate_limit_requests' => ['identifier_key', 'action', 'created_at'],
        ];

        $cmd = new MigrationManager($this->makeMigrationDbMock($tables, $columnsByTable, $leading));

        $issues = $cmd->verifySchema();

        $tableIssues = array_values(array_filter($issues, static fn (string $i): bool => str_contains($i, 'transactions')));
        $this->assertCount(1, $tableIssues, 'برای جدول غایب فقط یک پیام روشن؛ نه چند «Index missing»');
        $this->assertStringContainsString('Table not found: transactions', $tableIssues[0]);
        $this->assertStringContainsString('column and index checks skipped', $tableIssues[0]);
        $this->assertNotContains('⚠️ Index missing for column: transactions.user_id', $issues);
    }

    // ─────────────────────────── CMD-061 ───────────────────────────

    /** @test */
    public function migration_report_renders_array_rows_without_error(): void
    {
        $db = m::mock('Core\Database');
        // ردیف‌های آرایه‌ای (تغییر fetch mode) — report() قبلاً property access می‌کرد
        $db->shouldReceive('fetchAll')->once()->andReturn([
            ['migration' => 'm_one', 'batch' => 2, 'executed_at' => '2026-01-01 00:00:00'],
        ]);
        // verifySchema: هیچ جدولی وجود ندارد → فقط issueهای جدول غایب
        $db->shouldReceive('fetch')->andReturn(null);

        $cmd = new MigrationManager($db);

        $report = $cmd->report();

        $this->assertStringContainsString('[2] m_one (2026-01-01 00:00:00)', $report);
        $this->assertStringContainsString('Schema Verification:', $report);
    }

    // ─────────────────────────── CMD-068 ───────────────────────────

    /** @test */
    public function outbox_publish_displays_bool_skipped_lock_busy(): void
    {
        $publisher = m::mock('App\Services\OutboxPublisher');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $publisher->shouldReceive('publishPending')->once()->with(50, false)
            ->andReturn(['published' => 0, 'failed' => 0, 'skipped' => true]);

        $cmd = new OutboxPublishCommand($publisher, $logger);

        ob_start();
        $cmd->run(['--limit=50']);
        $output = str_value(ob_get_clean());

        $this->assertStringContainsString('skipped: publisher lock busy', $output, 'bool skipped باید نمایش داده شود نه حذف (CMD-068)');
    }

    // ───────────────────── CMD-080 / 081 / 082 ─────────────────────

    /** @test */
    public function queue_failed_list_shows_status_per_row(): void
    {
        $db = m::mock('Core\Database');
        $queue = m::mock('Core\Queue');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $db->shouldReceive('fetchAll')->once()
            ->with(m::on(static fn (string $sql): bool => str_contains($sql, 'status')))
            ->andReturn([
                (object) ['id' => 1, 'queue' => 'default', 'status' => 'processing', 'failed_at' => '2026-01-01 00:00:00'],
                (object) ['id' => 2, 'queue' => 'emails', 'status' => null, 'failed_at' => '2026-01-02 00:00:00'],
            ]);

        $cmd = new QueueFailedCommand($db, $queue, $logger);

        ob_start();
        $exit = $cmd->run(['list']);
        $output = str_value(ob_get_clean());

        $this->assertSame(0, $exit);
        $this->assertStringContainsString('ID: 1 | Queue: default | Status: processing', $output);
        $this->assertStringContainsString('ID: 2 | Queue: emails | Status: failed', $output, 'status خالی صادقانه failed نمایش داده شود');
    }

    /** @test */
    public function queue_failed_run_returns_nonzero_exit_on_runtime_failure(): void
    {
        $db = m::mock('Core\Database');
        $queue = m::mock('Core\Queue');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        // جاب یافت نمی‌شود → processRetry=false → exit 1 (قبلاً همیشه 0 بود — CMD-081)
        $stmt = m::mock('PDOStatement');
        $stmt->shouldReceive('fetch')->andReturn(null);
        $db->shouldReceive('query')->once()->andReturn($stmt);

        $cmd = new QueueFailedCommand($db, $queue, $logger);

        ob_start();
        $exit = $cmd->run(['retry', '7']);
        ob_get_clean();

        $this->assertSame(1, $exit);
    }

    /** @test */
    public function queue_failed_replay_drain_loops_until_batch_is_not_full(): void
    {
        $db = m::mock('Core\Database');
        $queue = m::mock('Core\Queue');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $db->shouldReceive('fetchColumn')->once()->andReturn(1500);
        // FIX-P3-CMD-082: --drain تا وقتی بچ پر برمی‌گردد ادامه می‌دهد
        $queue->shouldReceive('retryFailedJobsBatch')->twice()->with(null, 1000)
            ->andReturn(
                ['requeued' => 1000, 'errors' => 0, 'skipped' => 0],
                ['requeued' => 500, 'errors' => 0, 'skipped' => 0],
            );

        $cmd = new QueueFailedCommand($db, $queue, $logger);

        ob_start();
        $exit = $cmd->run(['replay', '--force', '--drain']);
        $output = str_value(ob_get_clean());

        $this->assertSame(0, $exit);
        $this->assertStringContainsString('rounds=2', $output);
        $this->assertStringContainsString('1500 موفق', $output);
    }

    // ───────────────── CMD-085 / 086 / 087 / 088 ─────────────────

    /** @test */
    public function queue_work_rejects_unknown_queue_name(): void
    {
        $worker = m::mock('App\Services\QueueWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $worker->shouldNotReceive('work');

        $cmd = new QueueWorkCommand($worker, $logger);

        ob_start();
        $result = $cmd->run(['cli.php', 'queue:work', '--queue=boom']);
        ob_get_clean();

        $this->assertSame(1, $result['exit_code'] ?? null);
        $this->assertSame('unknown queue', $result['error'] ?? null);
    }

    /** @test */
    public function queue_work_daemon_clamps_iteration_limit_to_max_jobs_budget(): void
    {
        $worker = m::mock('App\Services\QueueWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $worker->shouldReceive('shouldQuit')->andReturn(false);
        // FIX-P3-CMD-085: با --max-jobs=2 و --limit=5 فقط بچ ۲تایی فچ می‌شود
        $worker->shouldReceive('work')->once()->with(null, 2)->andReturn([
            'processed_jobs' => 2, 'failed_jobs' => 0,
        ]);

        $cmd = new QueueWorkCommand($worker, $logger);

        ob_start();
        $result = $cmd->run(['cli.php', 'queue:work', '--daemon', '--max-jobs=2', '--limit=5']);
        $output = str_value(ob_get_clean());

        $this->assertSame(2, $result['processed_jobs'] ?? null);
        $this->assertStringContainsString('processed=2', $output);
    }

    /** @test */
    public function queue_work_memory_peak_above_threshold_recycles_daemon(): void
    {
        $worker = m::mock('App\Services\QueueWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $worker->shouldReceive('shouldQuit')->andReturn(false);
        $worker->shouldReceive('work')->once()->with(null, 5)->andReturn([
            'processed_jobs' => 1, 'failed_jobs' => 0,
        ]);

        // FIX-P3-CMD-086: peak memory هم بررسی می‌شود — آستانهٔ ۱MB همیشه فعال است
        $logger->shouldReceive('info')->once()->with(
            'queue.command.work.memory_limit_reached',
            m::on(static fn (array $ctx): bool => isset($ctx['peak_mb']) && isset($ctx['used_mb']) && $ctx['threshold_mb'] === 1)
        );

        $cmd = new QueueWorkCommand($worker, $logger);

        ob_start();
        $result = $cmd->run(['cli.php', 'queue:work', '--daemon', '--memory=1', '--limit=5']);
        ob_get_clean();

        $this->assertSame(1, $result['processed_jobs'] ?? null);
    }

    /** @test */
    public function queue_work_structured_error_log_includes_exception_details(): void
    {
        $worker = m::mock('App\Services\QueueWorker');
        $logger = m::mock('App\Contracts\LoggerInterface');

        $logger->shouldReceive('info')->andReturn(null);
        $worker->shouldReceive('work')->once()->andThrow(new \RuntimeException('Connection failed'));

        // FIX-P3-CMD-088: کلاس/فایل/خط استثنا در لاگ ساختاریافته
        $logger->shouldReceive('error')->once()->with(
            'queue.command.work.failed',
            m::on(static function (array $ctx): bool {
                return ($ctx['error'] ?? null) === 'Connection failed'
                    && ($ctx['exception'] ?? null) === \RuntimeException::class
                    && is_string($ctx['file'] ?? null)
                    && is_int($ctx['line'] ?? null);
            })
        );

        $cmd = new QueueWorkCommand($worker, $logger);

        ob_start();
        $result = $cmd->run(['cli.php', 'queue:work']);
        ob_get_clean();

        $this->assertSame(1, $result['exit_code'] ?? null);
    }

    // ───────────────── CMD-089 / 090 / 091 ─────────────────

    /** @test */
    public function rate_limit_audit_exits_nonzero_on_orphan_route_mapping(): void
    {
        config_set('rate_limits', [
            'default' => ['max_attempts' => 60, 'decay_minutes' => 1],
            'groups' => [],
            'route_map' => [
                'api/v1/ghost' => ['nosuchgroup', 'general'],
            ],
            'action_map' => [],
        ]);

        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $cmd = new RateLimitAuditCommand($logger);

        ob_start();
        $exit = $cmd->run([]);
        $output = str_value(ob_get_clean());

        $this->assertSame(1, $exit, 'اورفان باید audit را شکست بدهد (CMD-089)');
        $this->assertStringContainsString('orphan route mappings', $output);
    }

    /** @test */
    public function rate_limit_audit_flags_implausible_policy_values(): void
    {
        config_set('rate_limits', [
            'default' => ['max_attempts' => 60, 'decay_minutes' => 1],
            // ساختار واقعی config/rate_limits.php: گروه‌ها در سطح بالای‌اند (بدون کلید 'groups')
            'auth' => [
                'login' => ['max_attempts' => 5, 'decay_minutes' => 0, 'fail_closed' => false],
            ],
            'route_map' => ['api/v1/login' => ['auth', 'login']],
            'action_map' => [],
        ]);

        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $cmd = new RateLimitAuditCommand($logger);

        ob_start();
        $exit = $cmd->run([]);
        $output = str_value(ob_get_clean());

        $this->assertSame(1, $exit, 'decay=0 غیرواقعی است و باید یافته شمرده شود (CMD-090)');
        $this->assertStringContainsString('implausible policy value for auth.login', $output);
    }

    /** @test */
    public function rate_limit_audit_reports_malformed_route_mapping_target(): void
    {
        config_set('rate_limits', [
            'default' => ['max_attempts' => 60, 'decay_minutes' => 1],
            'groups' => [],
            'route_map' => [
                'api/v1/broken' => 'auth', // شکل خراب — رشته به‌جای [group, endpoint]
            ],
            'action_map' => [
                'send' => ['auth'], // ناقص — endpoint ندارد
            ],
        ]);

        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $cmd = new RateLimitAuditCommand($logger);

        ob_start();
        $exit = $cmd->run([]);
        $output = str_value(ob_get_clean());

        $this->assertSame(1, $exit, 'mapping خراب باید یافته باشد (CMD-091)');
        $this->assertSame(2, substr_count($output, 'malformed mapping'));
    }

    /** @test */
    public function rate_limit_audit_passes_green_policy_with_zero_exit(): void
    {
        config_set('rate_limits', [
            'default' => ['max_attempts' => 60, 'decay_minutes' => 1],
            'groups' => [
                'auth' => ['login' => ['max_attempts' => 5, 'decay_minutes' => 15]],
            ],
            'route_map' => ['api/v1/login' => ['auth', 'login']],
            'action_map' => ['send' => ['auth', 'login']],
        ]);

        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $cmd = new RateLimitAuditCommand($logger);

        ob_start();
        $exit = $cmd->run([]);
        ob_get_clean();

        $this->assertSame(0, $exit);
    }

    // ─────────────────────────── CMD-095 ───────────────────────────

    /** @test */
    public function route_audit_alias_parser_skips_function_const_and_expands_group_use(): void
    {
        $cmd = new RouteAuditCommand();
        $ref = new \ReflectionMethod($cmd, 'parseUseAliases');
        $ref->setAccessible(true);

        $source = <<<'PHP'
<?php
use function strlen;
use const PHP_EOL;
use App\Controllers\Api\{SocialTaskApiController, AdminController as AC};
use App\Controllers\UserController;
PHP;

        /** @var array<string, string> $aliases */
        $aliases = $ref->invoke($cmd, $source);

        $this->assertArrayNotHasKey('strlen', $aliases, 'use function نباید alias کلاس بسازد (CMD-095)');
        $this->assertArrayNotHasKey('PHP_EOL', $aliases, 'use const نباید alias کلاس بسازد (CMD-095)');
        $this->assertSame('App\Controllers\Api\SocialTaskApiController', $aliases['SocialTaskApiController'] ?? null, 'عضو group use باید باز شود');
        $this->assertSame('App\Controllers\Api\AdminController', $aliases['AC'] ?? null, 'عضو group use با as باید فروکاست شود');
        $this->assertSame('App\Controllers\UserController', $aliases['UserController'] ?? null);
    }

    // ───────────────────── CMD-105 / CMD-112 ─────────────────────

    /** @test */
    public function scores_decay_counts_cache_invalidation_failures_in_summary(): void
    {
        $db = m::mock('Core\Database');
        $cache = m::mock('Core\Cache');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $scoreService = m::mock('App\Services\Score\ScoreCommandService');

        $cache->shouldReceive('redis')->andReturn(null); // گارد ساعتی fail-open
        $logger->shouldIgnoreMissing();

        $row = (object) ['user_id' => 7, 'score' => 100.0];
        // کوئری اول (main loop) یک ردیف، کوئری دوم (floor loop) خالی
        $db->shouldReceive('select')->twice()->andReturn([$row], []);

        $scoreService->shouldReceive('applySystemDelta')->once()->andReturn(true);
        // FIX-P3-CMD-105: شکست ابطال کش → warning + شمارنده در خلاصه
        $scoreService->shouldReceive('clearScoresCache')->once()->andThrow(new \RuntimeException('redis down'));

        $logger->shouldReceive('warning')->once()->with(
            'scores.decay.cache_invalidate_failed',
            m::on(static fn (array $ctx): bool => ($ctx['error'] ?? null) === 'redis down')
        );
        $logger->shouldReceive('info')->once()->with(
            'scores.decay.completed',
            m::on(static fn (array $ctx): bool => ($ctx['cache_invalidate_failures'] ?? null) === 1)
        );

        $cmd = new ScoresDecayCommand($db, $cache, $logger, $scoreService);

        ob_start();
        $exit = $cmd->run(['--force']);
        ob_get_clean();

        $this->assertSame(0, $exit);
    }

    /** @test */
    public function scores_rebuild_rejects_non_numeric_user_argument(): void
    {
        $db = m::mock('Core\Database');
        $cache = m::mock('Core\Cache');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();
        $cache->shouldReceive('redis')->andReturn(null);

        $db->shouldNotReceive('fetchAll'); // پیش از هر کوئری باید usage error بدهد

        $cmd = new ScoresRebuildCommand($db, $cache, $logger, null);

        ob_start();
        $exit = $cmd->run(['--dry-run', '--user=abc']);
        ob_get_clean();

        $this->assertSame(1, $exit, '‎--user=abc نباید بی‌صدا به کاربر ۱ نگاشت شود (CMD-112)');
    }

    // ─────────────────────────── CMD-117 ───────────────────────────

    /** @test */
    public function settings_migrate_skips_when_run_lock_is_busy(): void
    {
        $db = m::mock('Core\Database');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();
        $cache = m::mock('Core\Cache');
        $redis = m::mock(\Redis::class);

        $cache->shouldReceive('redis')->andReturn($redis);
        $cache->shouldReceive('redisKey')->with('settings:migrate_secrets:run_lock')->andReturn('chortke:settings:migrate_secrets:run_lock');
        $redis->shouldReceive('set')->once()->andReturn(false);

        $db->shouldNotReceive('fetchAll'); // پیش از واکشی ردیف‌ها باید skip شود

        $cmd = new SettingsMigrateSecretsCommand($db, $logger, null, $cache);

        ob_start();
        $exit = $cmd->run([]);
        $output = str_value(ob_get_clean());

        $this->assertSame(0, $exit);
        $this->assertStringContainsString('another run is active; skipped', $output);
    }

    // ───────────────────── CMD-124 / CMD-125 ─────────────────────

    private function makeSimulateCommand(m\MockInterface $db): SimulateTraceableEventCommand
    {
        $container = m::mock('Core\Container');
        $container->shouldReceive('make')->once()->with('Core\Database')->andReturn($db);
        return new SimulateTraceableEventCommand($container);
    }

    /** @test */
    public function simulate_reuses_existing_pending_simulated_event(): void
    {
        $db = m::mock('Core\Database');
        // ۱) users lookup موجود؛ ۲) ردیف pending شبیه‌سازی‌شدهٔ قبلی
        $db->shouldReceive('fetch')->twice()->andReturn(
            (object) ['id' => 5],
            (object) ['id' => 901, 'payload' => '{"simulated_by":"simulate:traceable-event"}'],
        );
        $db->shouldNotReceive('query'); // نباید INSERT تکراری بزند

        $cmd = $this->makeSimulateCommand($db);

        ob_start();
        $exit = $cmd->run(['--type=test.event', '--user=5', '--confirm']);
        $output = str_value(ob_get_clean());

        $this->assertSame(0, $exit);
        $this->assertStringContainsString('no duplicate inserted', $output);
    }

    /** @test */
    public function simulate_reports_insert_failure_with_generic_message(): void
    {
        $db = m::mock('Core\Database');
        $db->shouldReceive('fetch')->twice()->andReturn(
            (object) ['id' => 5],
            null, // ردیف pending موجود نیست
        );
        $db->shouldReceive('query')->once()->andThrow(new \RuntimeException('INSERT failed: duplicate key'));
        $db->shouldNotReceive('lastInsertId');

        $cmd = $this->makeSimulateCommand($db);

        ob_start();
        $exit = $cmd->run(['--type=test.event', '--user=5', '--confirm']);
        ob_get_clean();

        $this->assertSame(1, $exit, 'insert ناموفق نباید موفق گزارش شود (CMD-125)');
    }

    // ───────────────────── CMD-131 / CMD-133 ─────────────────────

    /** @test */
    public function stuck_withdrawal_rejects_non_digit_review_id(): void
    {
        $recon = m::mock('App\Services\ReconciliationService');
        $admin = m::mock('App\Services\Withdrawal\WithdrawalAdminService');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $recon->shouldNotReceive('adminResolveReview'); // هرگز با id خراب صدا زده نشود

        $cmd = new StuckWithdrawalReviewCommand($recon, $admin, $logger);

        // قرارداد CLI: run() InvalidArgumentException را به «Usage error» + exit 1 ترجمه می‌کند
        ob_start();
        $exit = $cmd->run(['cli.php', 'withdrawals:review:resolve', '12abc', '--note=x', '--admin-id=2']);
        ob_get_clean();
        $this->assertSame(1, $exit, 'id خراب باید exit 1 بدهد');

        // خودِ گارد سخت‌گیر — به‌صورت بازتابی pin می‌شود
        $guard = new \ReflectionMethod($cmd, 'parseReviewId');
        $guard->setAccessible(true);
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('positive integer review id');
        $guard->invoke($cmd, '12abc');
    }

    /** @test */
    public function stuck_withdrawal_admin_id_must_reference_existing_user(): void
    {
        $recon = m::mock('App\Services\ReconciliationService');
        $admin = m::mock('App\Services\Withdrawal\WithdrawalAdminService');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();
        $db = m::mock('Core\Database');

        $db->shouldReceive('fetch')->twice()
            ->with(m::on(static fn (string $sql): bool => str_contains($sql, 'FROM users')), [999])
            ->andReturn(null); // کاربر ۹۹۹ وجود ندارد — یک‌بار مسیر CLI، یک‌بار فراخوانی بازتابی گارد

        $recon->shouldNotReceive('adminResolveReview');

        $cmd = new StuckWithdrawalReviewCommand($recon, $admin, $logger, $db);

        // مسیر CLI: گارد کاربرِ ناموجود → Usage error + exit 1 (بدون فراخوانی سرویس)
        ob_start();
        $exit = $cmd->run(['cli.php', 'withdrawals:review:resolve', '5', '--note=x', '--admin-id=999']);
        ob_get_clean();
        $this->assertSame(1, $exit, 'admin-id بدون کاربر واقعی باید exit 1 بدهد');

        // خودِ گارد attribution — به‌صورت بازتابی pin می‌شود
        $guard = new \ReflectionMethod($cmd, 'requireAdminId');
        $guard->setAccessible(true);
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('does not reference an existing user');
        $guard->invoke($cmd, ['admin-id' => '999']);
    }
}
