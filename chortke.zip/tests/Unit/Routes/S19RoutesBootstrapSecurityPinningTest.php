<?php

declare(strict_types=1);

namespace Tests\Unit\Routes;

use PHPUnit\Framework\TestCase;

/**
 * S19 — قفل‌کنندهٔ امنیتی لایهٔ Routes/Bootstrap (routes/ ۱۰ فایل + bootstrap/ + نقاط ورود
 * public/index.php و cli.php — ۲٬۲۲۰ خط، خط‌به‌خط).
 *
 * پین‌کردن ناورداهای بچ S19:
 *  ① زنجیرهٔ گارد ادمین = Auth + Admin + CSRF + RateLimit:30,1 + AdminPermissionGuard
 *     (deny-by-default) — تعریف پین می‌شود و همهٔ روت‌های /admin/* از آن استفاده می‌کنند
 *     (به‌جز ورود عمومی login/verify-2fa و ریدایرکت /admin).
 *  ② هر روت تغییردهندهٔ وضعیت وب (post/put/patch/delete) خارج از پیشوندهای معافِ
 *     مستند (/api/ = توکن‌محور، /payment/callback/ = امضای درگاه، /webhooks/ = HMAC)
 *     باید CSRFMiddleware را (مستقیم یا از طریق متغیر گروه) داشته باشد.
 *  ③ پاریتی گیت فیچر کریپتو: shortcut /crypto-deposit/create باید همان
 *     RequireFeature:crypto_deposit مسیر canonical /wallet/deposit/crypto را داشته
 *     باشد (FIX-S19-1).
 *  ④ endpointهای عمومی metrics/health توزیع‌شده باید درون‌کنترلری fail-closed گیت
 *     IP/token داشته باشند (M-34 / Issue #7/#8).
 *  ⑤ نقاط ورود: گارد root در cli.php + پاکسازی نام command + قفل flock؛
 *     enforcement HTTPS با گارد proxy-spoofing در index.php؛ خطای دیباگ همیشه
 *     htmlspecialchars. bootstrap: canonical REQUEST_ID + APP_KEY/SECRET baselines.
 *  ⑥ صفر توکن اجرای خطرناک در کل محدودهٔ S19 (اسکن بازگشتی).
 */
final class S19RoutesBootstrapSecurityPinningTest extends TestCase
{
    /** ریشهٔ پروژه — بدون وابستگی به BASE_PATH (در testing bootstrap تعریف نشده) */
    private const ROOT = __DIR__ . '/../../..';

    /** @var array<int,string> */
    private array $routeFiles = [
        'routes/routes.php',
        'routes/health.php',
        'routes/system.php',
        'routes/public.php',
        'routes/auth.php',
        'routes/user.php',
        'routes/wallet.php',
        'routes/admin.php',
        'routes/api.php',
        'routes/missing.php',
    ];

    private function read(string $relative): string
    {
        return (string)file_get_contents(self::ROOT . '/' . $relative);
    }

    /**
     * متغیرهای گروه middleware هر فایل روت را resolve می‌کند
     * (شکل‌ها: $x = [...];  $x = $y;  $x = array_merge($y, [...]);)
     *
     * @return array<string,string> نام متغیر => عبارت بسط‌یافته
     */
    private function resolveMiddlewareVariables(string $content): array
    {
        $vars = [];
        if (preg_match_all('/^\s*\$(\w+)\s*=\s*(.+?);\s*(?:\/\/.*)?$/m', $content, $m, PREG_SET_ORDER)) {
            foreach ($m as $match) {
                $rhs = $match[2];
                // روت‌ها و کلاس‌ها را حذف کن تا فقط عبارت middleware بماند
                if (str_contains($rhs, '::class') === false && str_contains($rhs, 'array_merge') === false && !preg_match('/^\$\w+$/', $rhs)) {
                    continue; // احتمالاً $router/$r/$app و امثال آن
                }
                $vars[$match[1]] = $rhs;
            }
        }
        // بسط بازگشتی متغیرها — طولانی‌ترین نام اول تا برخورد پیشوندی
        // (مثل $auth داخل $authCSRF) رخ ندهد (۳ پاس کافی است)
        $names = array_keys($vars);
        usort($names, static fn (string $a, string $b): int => strlen($b) <=> strlen($a));
        for ($i = 0; $i < 3; $i++) {
            foreach ($vars as $name => $expr) {
                $expanded = $expr;
                foreach ($names as $innerName) {
                    if ($innerName !== $name && str_contains($expanded, '$' . $innerName)) {
                        $expanded = str_replace('$' . $innerName, '(' . $vars[$innerName] . ')', $expanded);
                    }
                }
                $vars[$name] = $expanded;
            }
        }
        return $vars;
    }

    /** ① تعریف زنجیرهٔ گارد ادمین + حضور AdminPermissionGuard (deny-by-default) */
    public function testAdminGuardChainDefinitionIsPinned(): void
    {
        $admin = $this->read('routes/admin.php');
        $missing = $this->read('routes/missing.php');
        $system = $this->read('routes/system.php');

        $chainNeedle = 'AuthMiddleware::class, AdminMiddleware::class, CSRFMiddleware::class, RateLimitMiddleware::class';
        $this->assertStringContainsString($chainNeedle, $admin, 'زنجیرهٔ $admin در admin.php باید کامل باشد');
        $this->assertStringContainsString($chainNeedle, $missing, 'زنجیرهٔ $admin در missing.php باید کامل باشد');
        $this->assertStringContainsString('AdminMiddleware::class, CSRFMiddleware::class', $system, 'زنجیرهٔ ادمین system.php باید CSRF داشته باشد');

        $this->assertStringContainsString('AdminPermissionGuard::class', $admin, 'RBAC deny-by-default باید در زنجیرهٔ ادمین باشد');
        $this->assertStringContainsString('AdminPermissionGuard::class', $missing, 'RBAC deny-by-default باید در missing.php هم باشد');
        $this->assertStringContainsString('deny-by-default', $admin, 'قرارداد deny-by-default باید مستندِ همان زنجیره باشد');
    }

    /** ① هر روت پنل ادمین باید از گارد ادمین عبور کند (به‌جز ورود عمومی) */
    public function testEveryAdminPanelRouteCarriesAdminGuard(): void
    {
        // ورود عمومی ادمین (پیش از احراز) — logout خودش گارد کامل دارد و مستثنا نمی‌شود
        $publicEntryUris = ['/admin/login', '/admin/verify-2fa'];
        $violations = [];

        foreach (['routes/admin.php', 'routes/missing.php', 'routes/system.php'] as $file) {
            $lines = explode("\n", $this->read($file));
            foreach ($lines as $line) {
                if (!preg_match("/->(?:get|post|put|patch|delete)\(\s*'(\/admin\/[^']*)'/", $line, $m)) {
                    continue;
                }
                $uri = $m[1];
                if (in_array($uri, $publicEntryUris, true)) {
                    continue;
                }
                if (!str_contains($line, 'AdminMiddleware') && !str_contains($line, '$admin')) {
                    $violations[] = $file . ': ' . trim($line);
                }
            }
        }

        $this->assertSame([], $violations, 'روت ادمین بدون گارد ادمین: ' . "\n" . implode("\n", $violations));
    }

    /** ② CSRF روی همهٔ روت‌های تغییردهندهٔ وضعیت وب خارج از پیشوندهای معاف مستند */
    public function testStateChangingWebRoutesRequireCsrf(): void
    {
        $exemptPrefixes = ['/api/', '/payment/callback/', '/webhooks/'];
        // پیشوند گروهی فایل‌ها — routes/api.php همه‌اش داخل group prefix '/api/v1' ثبت می‌شود
        // (group در L42 باز و در انتهای فایل بسته می‌شود؛ راستی‌آزمایی در تست زیر)
        $fileGroupPrefix = ['routes/api.php' => '/api/v1'];
        $violations = [];

        foreach ($this->routeFiles as $file) {
            $content = $this->read($file);
            $vars = $this->resolveMiddlewareVariables($content);
            $lines = explode("\n", $content);

            foreach ($lines as $line) {
                if (!preg_match("/->(post|put|patch|delete)\(\s*'([^']+)',\s*\[[^\]]+\](?:,\s*(.+?))?\)\s*;/", $line, $m)) {
                    continue;
                }
                [, $method, $uri] = $m;
                $middlewareExpr = $m[3] ?? null;

                // اعمال پیشوند گروه در صورت وجود
                $effectiveUri = ($fileGroupPrefix[$file] ?? '') . $uri;

                // استثنای مستند FIX-S19-2: پینگ تله‌متری pre-auth کپچا — به‌جای CSRF
                // (که توکن سشن روی همهٔ سطوح کپچا وجود ندارد) با RateLimitMiddleware گیت می‌شود
                // و در تست مجزا پین است.
                if ($effectiveUri === '/captcha/behavioral/ping') {
                    continue;
                }

                foreach ($exemptPrefixes as $prefix) {
                    if (str_starts_with($effectiveUri, $prefix)) {
                        continue 2;
                    }
                }

                // بسط متغیرهای گروه — طولانی‌ترین نام اول تا پیشوندِ نام‌ها
                // (مثل $auth داخل $authCSRF) توکن را نابود نکند
                $expanded = $middlewareExpr ?? '';
                $names = array_keys($vars);
                usort($names, static fn (string $a, string $b): int => strlen($b) <=> strlen($a));
                for ($pass = 0; $pass < 3; $pass++) {
                    $before = $expanded;
                    foreach ($names as $name) {
                        $expanded = str_replace('$' . $name, '(' . $vars[$name] . ')', $expanded);
                    }
                    if ($expanded === $before) {
                        break;
                    }
                }
                if (!str_contains($expanded, 'CSRFMiddleware::class')) {
                    $violations[] = sprintf('%s [%s %s] => middleware: %s', $file, strtoupper($method), $effectiveUri, $middlewareExpr ?? '(none)');
                }
            }
        }

        $this->assertSame([], $violations, 'روت تغییردهندهٔ وضعیت بدون CSRF: ' . "\n" . implode("\n", $violations));
    }

    /** ②-ب: خودِ group گیت /api/v1 پین می‌شود (ApiRequest + RateLimit سراسری گروه) */
    public function testApiV1GroupGateIsPinned(): void
    {
        $api = $this->read('routes/api.php');
        $this->assertSame(
            1,
            preg_match("/->group\(\['prefix'\s*=>\s*'\/api\/v1',\s*'middleware'\s*=>\s*\[ApiRequestMiddleware::class,\s*.*RateLimitMiddleware::class\]\]/", $api),
            'گروه /api/v1 باید ApiRequestMiddleware + RateLimitMiddleware سراسری داشته باشد'
        );
        // گیت scopeها: هر subgroup محافظت‌شده باید ApiAuthMiddleware با اسکوپ صریح داشته باشد
        $this->assertSame(1, substr_count($api, 'ApiAuthMiddleware::class') >= 15 ? 1 : 0, 'تعداد گیت‌های scope-gated انتظار‌رفته');
    }

    /** ②-ک پایین: استثنای مستند FIX-S19-2 — پینگ کپچا باید نرخ‌سنج صریح داشته باشد */
    public function testCaptchaBehavioralPingHasExplicitRateLimitInsteadOfCsrf(): void
    {
        $public = $this->read('routes/public.php');
        $this->assertSame(
            1,
            preg_match("/->post\('\/captcha\/behavioral\/ping'[^;]*RateLimitMiddleware/", $public),
            'FIX-S19-2: POST پینگ رفتاری کپچا باید RateLimitMiddleware صریح داشته باشد'
        );
        $this->assertSame(
            1,
            preg_match("/->get\('\/captcha\/behavioral\/ping'[^;]*RateLimitMiddleware/", $public),
            'FIX-S19-2: GET پینگ رفتاری کپچا هم باید نرخ‌سنج داشته باشد'
        );
    }

    /** ③ FIX-S19-1: پاریتی گیت فیچر کریپتو بین shortcut و مسیر canonical */
    public function testCryptoDepositFeatureGateParityBetweenShortcutAndCanonicalRoute(): void
    {
        $needle = "RequireFeature::class . ':crypto_deposit'";

        $missing = $this->read('routes/missing.php');
        $wallet = $this->read('routes/wallet.php');

        $this->assertStringContainsString($needle, $wallet, 'مسیر canonical کریپتو باید گیت فیچر داشته باشد');
        $this->assertSame(
            1,
            preg_match("/->get\('\/crypto-deposit\/create'[^;]*" . preg_quote($needle, '/') . '/', $missing),
            'FIX-S19-1: shortcut /crypto-deposit/create باید همان RequireFeature:crypto_deposit را داشته باشد'
        );

        // و POSTهای عملیاتی کریپتو هم گیت + secure chain داشته باشند
        $this->assertSame(1, preg_match("/->post\('\/wallet\/deposit\/crypto\/intent'[^;]*cryptoSecureAuth/", $wallet));
        $this->assertSame(1, preg_match("/->post\('\/wallet\/deposit\/crypto'[^;]*cryptoSecureAuth/", $wallet));
    }

    /** ④ گیت fail-closed درون‌کنترلری endpointهای عمومی metrics/health */
    public function testPublicMetricsEndpointsAreSelfGatedFailClosed(): void
    {
        $metrics = $this->read('app/Controllers/MetricsController.php');
        $this->assertStringContainsString("config('health.allowed_ips'", $metrics, 'گیت IP برای /metrics');
        $this->assertStringContainsString('hash_equals', $metrics, 'مقایسهٔ timing-safe توکن');
        $this->assertStringContainsString('403', $metrics, 'رد صریح');

        $health = $this->read('app/Controllers/Api/HealthCheckController.php');
        $this->assertStringContainsString('validateAccess', $health, 'distributed/metrics باید validateAccess را صدا بزنند');
        $this->assertStringContainsString('Fail-closed', $health, 'لیست خالی نباید دسترسی عمومی بدهد (Issue #7)');
        $this->assertStringContainsString('X-Health-Token', $health, 'توکن فقط از هدر (Issue #8)');

        // هر دو روت /health/distributed و /metrics/distributed از همین کنترلر سرو می‌شوند
        $healthRoutes = $this->read('routes/health.php');
        $this->assertStringContainsString("'distributed'", $healthRoutes);
        $this->assertStringContainsString("'metrics'", $healthRoutes);
    }

    /** ⑤ نقاط ورود + baselineهای bootstrap */
    public function testEntryPointsAndBootstrapSecurityBaselines(): void
    {
        $cli = $this->read('cli.php');
        $this->assertStringContainsString('posix_getuid', $cli, 'گارد اجرای root');
        $this->assertStringContainsString('--allow-root', $cli, 'hatch صریح root');
        $this->assertStringContainsString('preg_replace(' . "'/[^a-zA-Z0-9_-]/', '', " . '$argv[1])', $cli, 'نام command باید قبل از ساخت مسیر lock پاکسازی شود');
        $this->assertStringContainsString('flock', $cli, 'قفل اجرای هم‌زمان');
        $this->assertStringContainsString("php_sapi_name() !== 'cli'", $cli, 'CLI-only guard');

        $index = $this->read('public/index.php');
        $this->assertStringContainsString('HTTP_X_FORWARDED_PROTO', $index, 'enforcement HTTPS');
        $this->assertStringContainsString("'127.0.0.1', '::1'", $index, 'پذیرش XFP فقط از proxy خصوصی (ضد spoof)');
        $this->assertStringContainsString('htmlspecialchars', $index, 'صفحهٔ خطای دیباگ باید escape شود');

        $bootstrap = $this->read('bootstrap/app.php');
        $this->assertStringContainsString('/^[\\w.\\-:]{1,128}$/', $bootstrap, 'الگوی canonical REQUEST_ID (FIX-S4-7)');
        $this->assertStringContainsString("'default_key'", $bootstrap, 'رد APP_KEY پیش‌فرض');
        $this->assertStringContainsString('SECURITY_API_TOKEN_SECRET', $bootstrap, 'baseline رمز توکن امنیتی');
        $this->assertStringContainsString('strlen(SECURITY_API_TOKEN_SECRET) < 32', $bootstrap, 'حداقل طول رمز');
        $this->assertStringContainsString("ini_set('display_errors', '0')", $bootstrap, 'خاموشی نمایش خطا در production');
    }

    /** ⑥ اسکن عرضی: صفر توکن اجرای خطرناک در کل محدودهٔ S19 */
    public function testRoutesBootstrapAndEntryPointsHaveNoDangerousPrimitives(): void
    {
        $forbidden = ['eval(', 'assert(', 'system(', 'shell_exec', 'passthru', 'proc_open', 'popen(', 'unserialize(', 'base64_decode('];
        $violations = [];

        $targets = array_merge($this->routeFiles, [
            'bootstrap/app.php',
            'bootstrap/testing.php',
            'bootstrap/phpunit-prepend.php',
            'public/index.php',
            'cli.php',
        ]);

        foreach ($targets as $file) {
            $content = $this->read($file);
            foreach ($forbidden as $token) {
                if (str_contains($content, $token)) {
                    // کامنت‌های تک‌خطی که صرفاً نام توکن را توضیح می‌دهند نادیده گرفته می‌شوند
                    foreach (explode("\n", $content) as $line) {
                        $codeOnly = trim((string)preg_replace('/\/\/.*$/', '', $line));
                        if ($codeOnly === '' || str_starts_with($codeOnly, '*') || str_starts_with($codeOnly, '/*')) {
                            continue;
                        }
                        if (str_contains($codeOnly, $token)) {
                            $violations[] = $file . ' => ' . $token . ' => ' . trim($line);
                        }
                    }
                }
            }
        }

        $this->assertSame([], $violations, 'توکن خطرناک در لایهٔ روت/bootstrap: ' . "\n" . implode("\n", $violations));
    }
}
