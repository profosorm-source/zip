<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Policies\RateLimitPolicy;
use Core\Redis;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-R20-CY2-A (باگ جانبی QA چرخهٔ R18 — رگرسیون):
 *
 * تا قبل از رفع، RateLimitPolicy::tooManyResponse همیشه پیام عمومیِ ثابت
 * «تعداد درخواست‌های شما بیش از حد مجاز است...» می‌فرستاد؛ پیام‌های اختصاصیِ
 * تعریف‌شده در config/rate_limits.php (۲۴+ مورد) و پیام‌های اپراتور در
 * metadata فلگ‌ها هرگز رندر نمی‌شدند.
 *
 * منطق حل پیام به متد خالص resolveTooManyMessage استخراج شد تا بدون اجرای
 * exit (رفتار terminal خود tooManyResponse) قابل‌پین باشد. این تست قراردادِ
 * حل پیام را روی کانفیگ واقعی پروژه قفل می‌کند.
 */
final class RateLimitPolicyMessageTest extends TestCase
{
    private RateLimitPolicy $policy;

    /** @var \Mockery\MockInterface&\Core\Logger */
    private \Core\Logger $logger;

    /** @var \Mockery\MockInterface&Redis */
    private Redis $redis;

    /** @var array<string, mixed> */
    private array $savedOverrides;

    protected function setUp(): void
    {
        parent::setUp();
        $this->savedOverrides = $GLOBALS['configOverrides'] ?? [];
        // مسیر حل پیام فقط کانفیگ می‌خواند؛ Logger/Redis ماک هستند تا نه لاگ
        // واقعی نوشته شود و نه تلاش اتصال رخ دهد (الگوی AlertDispatcherChannelIsolationTest).
        $this->logger = m::mock(\Core\Logger::class);
        $this->logger->shouldIgnoreMissing();
        $this->redis = m::mock(Redis::class);
        $this->policy = new RateLimitPolicy($this->logger, $this->redis, null);
    }

    protected function tearDown(): void
    {
        // بازگرداندن override های قبلی — آلودگی ترتیبی بین تست‌ها ممنوع
        $GLOBALS['configOverrides'] = $this->savedOverrides;
        m::close();
        parent::tearDown();
    }

    public function test_action_with_configured_message_renders_it_verbatim(): void
    {
        // kyc_submit → action_map → ['kyc','submit'] → پیام اختصاصی در کانفیگ
        $msg = $this->policy->resolveTooManyMessage('kyc_submit', 600, 10);
        $this->assertSame(
            'تعداد ارسال مدارک احراز هویت بیش از حد. لطفاً 24 ساعت صبر کنید.',
            $msg,
            'پیام اختصاصیِ kyc.submit باید عیناً از کانفیگ رندر شود، نه پیام عمومی'
        );
    }

    public function test_action_map_login_message_renders_not_generic(): void
    {
        $msg = $this->policy->resolveTooManyMessage('login', 300, 5);
        $this->assertSame('تعداد تلاش‌های ورود بیش از حد مجاز. لطفاً کمی صبر کنید.', $msg);
        $this->assertStringNotContainsString('بیش از حد مجاز است. لطفاً', $msg, 'پیام عمومی نباید برای action دارای پیام اختصاصی بیاید');
    }

    public function test_minutes_placeholder_is_substituted_in_custom_message(): void
    {
        // override بلوک کامل endpoint (نه فقط message) — قرارداد کانفیگ:
        // block معتبر باید max_attempts هم داشته باشد
        config_set('rate_limits.auth.login', [
            'max_attempts' => 5,
            'decay_minutes' => 5,
            'message' => 'به دلیل تلاش‌های ناموفق، حساب موقتاً محدود شد؛ لطفاً :minutes دقیقه دیگر تلاش کنید.',
        ]);
        $msg = $this->policy->resolveTooManyMessage('login', 480, 8);
        $this->assertSame(
            'به دلیل تلاش‌های ناموفق، حساب موقتاً محدود شد؛ لطفاً 8 دقیقه دیگر تلاش کنید.',
            $msg,
            'جای‌گذار :minutes باید با دقیقهٔ واقعی retry جایگزین شود'
        );
    }

    public function test_braced_minutes_placeholder_is_substituted_too(): void
    {
        config_set('rate_limits.auth.login', [
            'max_attempts' => 5,
            'decay_minutes' => 5,
            'message' => 'محدودیت فعال است؛ {minutes} دقیقه صبر کنید.',
        ]);
        $msg = $this->policy->resolveTooManyMessage('login', 120, 2);
        $this->assertSame('محدودیت فعال است؛ 2 دقیقه صبر کنید.', $msg);
    }

    public function test_action_without_configured_message_falls_back_to_generic(): void
    {
        // action جعلی که نه در action_map است نه در ACTIONS قدیمی → پیام عمومی
        $msg = $this->policy->resolveTooManyMessage('definitely_unknown_action_xyz', 300, 5);
        $this->assertSame(
            'تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً 5 دقیقه دیگر تلاش کنید.',
            $msg,
            'بدون پیام اختصاصی، پیام عمومی با دقیقهٔ واقعی باید بیاید (رفتار قبل حفظ شده)'
        );
    }

    public function test_generic_message_uses_ceil_minutes(): void
    {
        // retryAfter=61s → retryMins=2 (سقف)
        $msg = $this->policy->resolveTooManyMessage('definitely_unknown_action_xyz', 61, 2);
        $this->assertStringContainsString('2 دقیقه', $msg);
    }

    public function test_legacy_path_grouped_config_message_is_rendered(): void
    {
        // مسیر legacy: actionی که در action_map نیست → ACTIONS قدیمی/گروه
        // 'rate_limiting' → config('rate_limits.rate_limiting.standard').
        // با override بلوک کامل، عبورِ پیام از مسیر legacy (FeatureConfig گروهی) پین می‌شود.
        config_set('rate_limits.rate_limiting.standard', [
            'max_attempts' => 3,
            'decay_minutes' => 10,
            'message' => 'برای امنیت حساب، این عملیات موقتاً محدود شده است.',
        ]);
        $msg = $this->policy->resolveTooManyMessage('definitely_unknown_action_xyz', 600, 10);
        $this->assertSame(
            'برای امنیت حساب، این عملیات موقتاً محدود شده است.',
            $msg,
            'پیام endpoint از مسیر legacy (FeatureConfig گروهی) هم باید رندر شود'
        );
    }

    public function test_blank_config_message_falls_back_to_generic(): void
    {
        // پیام خالی/فاصله‌ای = نبود پیام → عمومی (دفاع در برابر کانفیگ خراب)
        config_set('rate_limits.auth.login', [
            'max_attempts' => 5,
            'decay_minutes' => 5,
            'message' => '   ',
        ]);
        $msg = $this->policy->resolveTooManyMessage('login', 300, 5);
        $this->assertSame('تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً 5 دقیقه دیگر تلاش کنید.', $msg);
    }

    public function test_configured_messages_actually_exist_for_real_caller_actions(): void
    {
        // قرارداد عملی: هر actionی که کنترلرها واقعاً enforce می‌کنند و در کانفیگ
        // پیام اختصاصی دارد باید از همان مسیر رفع پیدا کند. (lottery_participate
        // و manual_deposit عمداً در این فهرست نیستند — endpointشان در کانفیگ
        // پیام ندارد و رفتار درستشان همین پیام عمومی است.)
        $realCallerActions = [
            'camera_challenge'       => 'camera_challenge.challenge',   // SocialTaskApiController
            'coupon_validate'        => 'coupon.validate',              // CouponController
            'social_account_add'     => 'social_account.add',           // SocialAccountController
            'kyc_submit'             => 'kyc.submit',                   // KYCController / Api UserController
            'admin_bugreport_reply'  => 'admin.bugreport_reply',        // Admin BugReportController
            'admin_ticket_reply'     => 'admin.ticket_reply',           // Admin TicketController
        ];
        foreach ($realCallerActions as $action => $cfgPath) {
            $msg = $this->policy->resolveTooManyMessage($action, 300, 5);
            $generic = 'تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً 5 دقیقه دیگر تلاش کنید.';
            $this->assertNotSame(
                $generic,
                $msg,
                "action «{$action}» باید پیام اختصاصیِ کانفیگ ({$cfgPath}) بگیرد؛ اگر پیام عمومی آمد، یا action_map یا خود پیام گم شده"
            );
        }
    }
}
