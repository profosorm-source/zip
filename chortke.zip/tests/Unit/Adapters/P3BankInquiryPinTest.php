<?php

declare(strict_types=1);

namespace Tests\Unit\Adapters;

use App\Adapters\BankInquiryAdapter;
use App\Adapters\BankInquiryManager;
use App\Adapters\JibitInquiryAdapter;
use App\Adapters\VandarInquiryAdapter;
use App\Contracts\CircuitBreakerInterface;
use App\Contracts\CacheInterface;
use App\Contracts\LoggerInterface;
use Core\Exceptions\PermanentFailure;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * FIX-P3 pin suite — بانک/PSP inquiry cluster (scripts/p3fix_bank.json).
 *
 * پین‌های رگرسیون برای فیکس‌های ADP-031..035، ADP-081..088، ADP-152..155/158:
 *   - ماسک IBAN و حذف بدنهٔ خام/URL از لاگ‌ها (ADP-031/081/152)
 *   - schema/binding guard روی نتیجه و کش (ADP-032/083/153)
 *   - اعتبارسنجی IBAN در مرز منیجر (ADP-033)
 *   - deadline کلی زنجیره (ADP-034)
 *   - dedupe/پیکربندی‌سنجی پروایدرها (ADP-035)
 *   - type-safe parse و کپ طول (ADP-084/155)
 *   - کلمپ timeout (ADP-085)
 *   - ردّ secret فقط-فاصله‌ای (ADP-087)
 *   - کش توکن (ADP-088)
 *   - پین هاست production و فرمت business (ADP-154)
 *   - track_id پایدار بین retryها (ADP-158 — سطح ساختاری؛ پین قراردادی در
 *     ExternalProviderHttpContractTest با regex /^[a-f0-9]{24}$/ روی payload).
 */
final class P3BankInquiryPinTest extends TestCase
{
    private const IBAN = 'IR820540102680020817909002';
    private const MASKED_IBAN = '****9002';

    protected function tearDown(): void
    {
        $this->resetConfig();
        m::close();
        parent::tearDown();
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private function resetConfig(): void
    {
        // baseline بازگشت به وضعیت bootstrap/testing.php
        config_set('app.env', 'testing');
        foreach (['api_key', 'api_secret', 'base_url', 'timeout'] as $key) {
            config_set('services.jibit.' . $key, null);
        }
        foreach (['api_token', 'business', 'base_url', 'timeout'] as $key) {
            config_set('services.vandar.' . $key, null);
        }
        config_set('services.bank_inquiry.deadline_seconds', null);
    }

    /** @return LoggerInterface&\Mockery\MockInterface */
    private function loggerMock(): LoggerInterface
    {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        return $logger;
    }

    /** @return BankInquiryAdapter&\Mockery\MockInterface */
    private function adapterMock(bool $configured = true): BankInquiryAdapter
    {
        $adapter = m::mock(BankInquiryAdapter::class);
        $adapter->shouldReceive('isConfigured')->andReturn($configured)->byDefault();
        return $adapter;
    }

    /** @return CacheInterface&\Mockery\MockInterface */
    private function cacheMock(): CacheInterface
    {
        return m::mock(CacheInterface::class);
    }

    /** @return CircuitBreakerInterface&\Mockery\MockInterface */
    private function breakerMock(): CircuitBreakerInterface
    {
        return m::mock(CircuitBreakerInterface::class);
    }

    /** @return array<string,mixed> */
    private function validResult(string $owner = 'Owner', string $bank = 'Bank'): array
    {
        return [
            'success' => true,
            'owner_name' => $owner,
            'bank' => $bank,
            'iban' => self::IBAN,
            'message' => 'استعلام با موفقیت انجام شد.',
        ];
    }

    private function configureJibit(?string $baseUrl = null): void
    {
        config_set('services.jibit.api_key', 'p3-pin-key');
        config_set('services.jibit.api_secret', 'p3-pin-secret');
        if ($baseUrl !== null) {
            config_set('services.jibit.base_url', $baseUrl);
        }
    }

    private function configureVandar(?string $baseUrl = 'https://api.vandar.io', ?string $business = 'runtime-business'): void
    {
        config_set('services.vandar.api_token', 'p3-pin-token');
        config_set('services.vandar.business', $business);
        config_set('services.vandar.base_url', $baseUrl);
    }

    private function jibitTimeout(JibitInquiryAdapter $adapter): int
    {
        $prop = new \ReflectionProperty(JibitInquiryAdapter::class, 'timeout');
        return (int) $prop->getValue($adapter);
    }

    // ------------------------------------------------------------------
    // BankInquiryManager
    // ------------------------------------------------------------------

    /** FIX-P3-ADP-031: IBAN در هیچ سطح لاگِ منیجر خام نیست. */
    public function test_manager_masks_iban_in_all_log_contexts(): void
    {
        $logger = m::mock(LoggerInterface::class);
        $masked = self::MASKED_IBAN;
        $logger->shouldReceive('warning')->once()->with(
            'bank_inquiry_manager.adapter_failed',
            m::on(static fn (array $ctx): bool => ($ctx['iban'] ?? null) === $masked)
        );
        $logger->shouldReceive('error')->once()->with(
            'bank_inquiry_manager.adapter_exception',
            m::on(static fn (array $ctx): bool => ($ctx['iban'] ?? null) === $masked)
        );
        $logger->shouldReceive('critical')->once()->with(
            'bank_inquiry_manager.all_providers_failed',
            m::on(static fn (array $ctx): bool => ($ctx['iban'] ?? null) === $masked && is_int($ctx['elapsed_ms'] ?? null))
        );

        $first = new P3BankCountingAdapter(true, null, static function (): array {
            throw new \RuntimeException('boom');
        });
        $second = new P3BankAltCountingAdapter(true, ['success' => false, 'message' => 'رد شد']);

        $manager = new BankInquiryManager($logger, [$first, $second]);
        $result = $manager->inquireIban(self::IBAN);

        $this->assertFalse((bool) $result['success']);
        $this->assertSame(1, $second->inquireCalls);
    }

    /** FIX-P3-ADP-032: success بدون owner/bank معتبر در مرز منیجر رد می‌شود. */
    public function test_manager_rejects_schema_invalid_success_result(): void
    {
        $logger = $this->loggerMock();

        // راند ۱: owner_name خالی → رد؛ پروایدر بعدی نتیجهٔ معتبر می‌دهد.
        $first = new P3BankCountingAdapter(true, [
            'success' => true, 'owner_name' => '', 'bank' => 'Bank', 'iban' => self::IBAN,
        ]);
        $second = new P3BankAltCountingAdapter(true, $this->validResult('Second'));
        $result = (new BankInquiryManager($logger, [$first, $second]))->inquireIban(self::IBAN);
        $this->assertTrue((bool) $result['success']);
        $this->assertSame('Second', $result['owner_name']);

        // راند ۲: فقط success (بدون owner/bank) → رد؛ نتیجهٔ مسموم به caller نمی‌رسد.
        $poison = new P3BankCountingAdapter(true, ['success' => true]);
        $fallback = new P3BankAltCountingAdapter(true, ['success' => false, 'message' => 'nope']);
        $result = (new BankInquiryManager($logger, [$poison, $fallback]))->inquireIban(self::IBAN);
        $this->assertFalse((bool) $result['success']);
        $this->assertArrayNotHasKey('owner_name', $result);
    }

    /** FIX-P3-ADP-032: نتیجه‌ای که برای شِبای دیگری است (binding ناجور) رد می‌شود. */
    public function test_manager_rejects_success_result_with_mismatched_iban_binding(): void
    {
        $logger = $this->loggerMock();
        $first = new P3BankCountingAdapter(true, [
            'success' => true, 'owner_name' => 'Owner', 'bank' => 'Bank',
            'iban' => 'IR012345678901234567890123', // شِبای متفاوت = مسموم
        ]);
        $second = new P3BankAltCountingAdapter(true, $this->validResult('Honest'));

        $result = (new BankInquiryManager($logger, [$first, $second]))->inquireIban(self::IBAN);

        $this->assertTrue((bool) $result['success']);
        $this->assertSame('Honest', $result['owner_name']);
    }

    /** FIX-P3-ADP-033: شِبای خراب هرگز به هیچ پروایدر نمی‌رسد. */
    public function test_manager_validates_iban_before_reaching_any_provider(): void
    {
        $logger = $this->loggerMock();
        // هر دو پروایدر پیکربندی‌شده‌اند — تنها سدِ جلوی fan-out، اعتبارسنجی شِبا است.
        $first = new P3BankCountingAdapter(true);
        $second = new P3BankAltCountingAdapter(true);

        $result = (new BankInquiryManager($logger, [$first, $second]))->inquireIban('IR123456789012345678901234');

        $this->assertFalse((bool) $result['success']);
        $this->assertSame(0, $first->inquireCalls);
        $this->assertSame(0, $second->inquireCalls);
        $this->assertStringContainsString('نامعتبر', strval($result['message'] ?? ''));
    }

    /** FIX-P3-ADP-034: fan-out بعد از عبور از بودجهٔ زمانی متوقف و شکست واقعی اعلام می‌شود. */
    public function test_manager_stops_fanout_when_deadline_exceeded(): void
    {
        config_set('services.bank_inquiry.deadline_seconds', 1);
        $logger = $this->loggerMock();

        $slow = new P3BankCountingAdapter(true, null, static function (): array {
            usleep(1_200_000); // 1.2s > deadline 1s
            return ['success' => false, 'message' => 'slow provider'];
        });
        $never = new P3BankAltCountingAdapter(true);

        $result = (new BankInquiryManager($logger, [$slow, $never]))->inquireIban(self::IBAN);

        $this->assertFalse((bool) $result['success']);
        $this->assertStringContainsString('زمان مجاز', strval($result['message'] ?? ''));
        $this->assertSame(0, $never->inquireCalls);
    }

    /** FIX-P3-ADP-035: کلاس تکراری در سازنده و addAdapter حذف می‌شود. */
    public function test_manager_dedupes_adapters_by_class(): void
    {
        $logger = $this->loggerMock();
        $a = new P3BankCountingAdapter(true, $this->validResult());
        $b = new P3BankCountingAdapter(true, $this->validResult());

        $manager = new BankInquiryManager($logger, [$a, $b]);
        $manager->addAdapter($b); // تکراری — نادیده گرفته می‌شود

        $result = $manager->inquireIban(self::IBAN);
        $this->assertTrue((bool) $result['success']);
        $this->assertSame(1, $a->inquireCalls);
        $this->assertSame(0, $b->inquireCalls);
    }

    /** FIX-P3-ADP-035: پروایدر پیکربندی‌نشده از زنجیره کنار می‌رود؛ زنجیرهٔ خالی = گارد سرویس غایب. */
    public function test_manager_skips_unconfigured_adapters_and_reports_missing_service(): void
    {
        $logger = $this->loggerMock();
        $unconfigured = new P3BankCountingAdapter(false, $this->validResult());
        $configured = new P3BankAltCountingAdapter(true, $this->validResult('Configured'));

        $manager = new BankInquiryManager($logger, [$unconfigured, $configured]);
        $this->assertTrue($manager->isConfigured()); // OR semantics حفظ شده

        $result = $manager->inquireIban(self::IBAN);
        $this->assertTrue((bool) $result['success']);
        $this->assertSame('Configured', $result['owner_name']);
        $this->assertSame(0, $unconfigured->inquireCalls);

        // هیچ پروایدر پیکربندی‌نشده → نتیجهٔ ساختاریافته، نه موفقیت کاذب.
        $emptyManager = new BankInquiryManager($logger, [new P3BankCountingAdapter(false), new P3BankAltCountingAdapter(false)]);
        $result = $emptyManager->inquireIban(self::IBAN);
        $this->assertFalse((bool) $result['success']);
        $this->assertStringContainsString('پیکربندی نشده است', strval($result['message'] ?? ''));
    }

    // ------------------------------------------------------------------
    // JibitInquiryAdapter
    // ------------------------------------------------------------------

    /** FIX-P3-ADP-087: secret فقط-فاصله‌ای = پیکربندی‌نشده (بدون هیچ فراخوانی شبکه). */
    public function test_jibit_rejects_whitespace_only_credentials(): void
    {
        config_set('services.jibit.api_key', "   ");
        config_set('services.jibit.api_secret', "\t\n");
        $breaker = $this->breakerMock();
        $breaker->shouldNotReceive('call');

        $adapter = new JibitInquiryAdapter($this->loggerMock(), $this->cacheMock(), $breaker);

        $this->assertFalse($adapter->isConfigured());
        $result = $adapter->inquireIban(self::IBAN);
        $this->assertFalse((bool) $result['success']);
        $this->assertStringContainsString('پیکربندی Jibit انجام نشده است', strval($result['message'] ?? ''));
    }

    /** FIX-P3-ADP-085: صفر/منفی/بزرگِ timeout → کلمپ 2..30. */
    public function test_jibit_clamps_timeout_config_to_sane_range(): void
    {
        config_set('services.jibit.timeout', -5);
        $this->assertSame(2, $this->jibitTimeout(new JibitInquiryAdapter($this->loggerMock(), $this->cacheMock(), $this->breakerMock())));

        config_set('services.jibit.timeout', 0);
        $this->assertSame(2, $this->jibitTimeout(new JibitInquiryAdapter($this->loggerMock(), $this->cacheMock(), $this->breakerMock())));

        config_set('services.jibit.timeout', 99);
        $this->assertSame(30, $this->jibitTimeout(new JibitInquiryAdapter($this->loggerMock(), $this->cacheMock(), $this->breakerMock())));

        config_set('services.jibit.timeout', null);
        $this->assertSame(10, $this->jibitTimeout(new JibitInquiryAdapter($this->loggerMock(), $this->cacheMock(), $this->breakerMock())));
    }

    /** FIX-P3-ADP-083: رکورد کشِ سالم (با binding درست) بدون شبکه برمی‌گردد. */
    public function test_jibit_returns_valid_cached_result_without_network(): void
    {
        $this->configureJibit();
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->once()->andReturn($this->validResult('Cached Owner'));
        $breaker = $this->breakerMock();
        $breaker->shouldNotReceive('call');

        $result = (new JibitInquiryAdapter($this->loggerMock(), $cache, $breaker))->inquireIban(self::IBAN);

        $this->assertTrue((bool) $result['success']);
        $this->assertSame('Cached Owner', $result['owner_name']);
    }

    /** FIX-P3-ADP-083: نتیجهٔ مسموم کش (بدون binding / ناموفق) مثل cache-miss رفتار می‌کند. */
    public function test_jibit_ignores_poisoned_cache_and_refreshes(): void
    {
        $this->configureJibit();
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->once()->andReturn(json_encode([
            'success' => true, 'owner_name' => 'Evil', 'bank' => 'Evil', // بدون iban
        ], JSON_THROW_ON_ERROR));
        $breaker = $this->breakerMock();
        $breaker->shouldReceive('call')->andThrow(new \RuntimeException('transport down'));

        $result = (new JibitInquiryAdapter($this->loggerMock(), $cache, $breaker))->inquireIban(self::IBAN);

        $this->assertFalse((bool) $result['success']);
        $this->assertArrayNotHasKey('owner_name', $result);
        $this->assertStringNotContainsString('Evil', json_encode($result, JSON_UNESCAPED_UNICODE) ?: '');
    }

    /** FIX-P3-ADP-081: در لاگ شکست، IBAN ماسک و URL/شِبا در متن خطا نمی‌آید. */
    public function test_jibit_masks_iban_and_never_logs_url_on_failure(): void
    {
        $this->configureJibit('http://127.0.0.1:8092/success/jibit/v1/');
        $masked = self::MASKED_IBAN;
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldReceive('error')->once()->with(
            'jibit.inquiry.failed',
            m::on(static function (array $ctx) use ($masked): bool {
                if (($ctx['iban'] ?? null) !== $masked) {
                    return false;
                }
                $error = strval($ctx['error'] ?? '');
                // URL بلوکه‌شده و شِبا نباید در لاگ باشند.
                return !str_contains($error, 'http://127.0.0.1')
                    && !str_contains($error, self::IBAN)
                    && !str_contains($error, 'value=');
            })
        );
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->andReturn(null);
        $breaker = $this->breakerMock();
        $breaker->shouldReceive('call')->andReturnUsing(static fn (string $name, callable $operation) => $operation());

        $result = (new JibitInquiryAdapter($logger, $cache, $breaker))->inquireIban(self::IBAN);

        $this->assertFalse((bool) $result['success']);
    }

    /** FIX-P3-ADP-084: parse type-safe — فیلد بدنوع/ناقص = PermanentFailure؛ فیلد بزرگ کپ می‌شود. */
    public function test_jibit_parse_rejects_non_string_or_incomplete_fields(): void
    {
        $this->configureJibit();
        $adapter = new JibitInquiryAdapter($this->loggerMock(), $this->cacheMock(), $this->breakerMock());
        $method = new \ReflectionMethod(JibitInquiryAdapter::class, 'parseIbanResponse');

        // name غیر-رشته‌ای (آرایه) → رد
        try {
            $method->invoke($adapter, ['name' => ['evil'], 'bank' => 'Bank'], self::IBAN);
            $this->fail('PermanentFailure expected for non-string name');
        } catch (PermanentFailure) {
            $this->addToAssertionCount(1);
        }

        // name ok اما bank غایب → رد
        try {
            $method->invoke($adapter, ['name' => 'Test', 'familyName' => 'Owner'], self::IBAN);
            $this->fail('PermanentFailure expected for missing bank');
        } catch (PermanentFailure) {
            $this->addToAssertionCount(1);
        }

        // پاسخ سالم → نتیجهٔ استاندارد با binding شِبا
        $ok = $method->invoke($adapter, ['name' => 'Test', 'familyName' => 'Owner', 'bank' => 'Runtime Bank'], self::IBAN);
        $this->assertTrue((bool) $ok['success']);
        $this->assertSame('Test Owner', $ok['owner_name']);
        $this->assertSame(self::IBAN, $ok['iban']);

        // کپ طول (ADP-084/155 هم‌الگو): نام/بانک غول‌پیکر
        $capped = $method->invoke($adapter, [
            'name' => str_repeat('ن', 300),
            'familyName' => str_repeat('ف', 300),
            'bank' => str_repeat('ب', 500),
        ], self::IBAN);
        $this->assertLessThanOrEqual(200, mb_strlen(strval($capped['owner_name'])));
        $this->assertLessThanOrEqual(200, mb_strlen(strval($capped['bank'])));
    }

    /** FIX-P3-ADP-088: توکن کش‌شده قبل از درخواست شبکه مصرف می‌شود. */
    public function test_jibit_token_is_read_from_cache_before_network(): void
    {
        $this->configureJibit();
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->once()->with('jibit:access_token')->andReturn('cached-token-xyz');
        $adapter = new JibitInquiryAdapter($this->loggerMock(), $cache, $this->breakerMock());

        $method = new \ReflectionMethod(JibitInquiryAdapter::class, 'getAccessToken');
        $this->assertSame('cached-token-xyz', $method->invoke($adapter));
    }

    // ------------------------------------------------------------------
    // VandarInquiryAdapter
    // ------------------------------------------------------------------

    /** FIX-P3-ADP-152: IBAN ماسک و «body=RAW» در لاگ شکست حذف می‌شود. */
    public function test_vandar_masks_iban_and_redacts_raw_body_in_failure_log(): void
    {
        $this->configureVandar();
        $masked = self::MASKED_IBAN;
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldReceive('error')->once()->with(
            'vandar.inquiry.failed',
            m::on(static function (array $ctx) use ($masked): bool {
                if (($ctx['iban'] ?? null) !== $masked) {
                    return false;
                }
                return !str_contains(strval($ctx['error'] ?? ''), 'RAW-PROVIDER-BODY');
            })
        );
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->once()->andReturn(null);
        $breaker = $this->breakerMock();
        $breaker->shouldReceive('call')->andThrow(new \RuntimeException('vandar exploded body=RAW-PROVIDER-BODY-XXXX'));

        $result = (new VandarInquiryAdapter($logger, $cache, $breaker))->inquireIban(self::IBAN);

        $this->assertFalse((bool) $result['success']);
        $this->assertStringNotContainsString('RAW-PROVIDER-BODY', json_encode($result, JSON_UNESCAPED_UNICODE) ?: '');
    }

    /** FIX-P3-ADP-153: رکورد کش سالم بدون شبکه برگردانده می‌شود. */
    public function test_vandar_returns_valid_cached_result_without_network(): void
    {
        $this->configureVandar();
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->once()->andReturn($this->validResult('Cached Owner'));
        $breaker = $this->breakerMock();
        $breaker->shouldNotReceive('call');

        $result = (new VandarInquiryAdapter($this->loggerMock(), $cache, $breaker))->inquireIban(self::IBAN);

        $this->assertTrue((bool) $result['success']);
        $this->assertSame('Cached Owner', $result['owner_name']);
    }

    /** FIX-P3-ADP-153: کشِ مسموم (binding غلط یا بدون success) رد و مسیر شبکه می‌رود. */
    public function test_vandar_ignores_poisoned_cache_and_refreshes(): void
    {
        $this->configureVandar();
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->once()->andReturn([
            'success' => true, 'owner_name' => 'Evil', 'bank' => 'Evil',
            'iban' => 'IR012345678901234567890123', // binding غلط
        ]);
        $breaker = $this->breakerMock();
        $breaker->shouldReceive('call')->andThrow(new \RuntimeException('transport down'));

        $result = (new VandarInquiryAdapter($this->loggerMock(), $cache, $breaker))->inquireIban(self::IBAN);

        $this->assertFalse((bool) $result['success']);
        $this->assertArrayNotHasKey('owner_name', $result);
    }

    /** FIX-P3-ADP-154: در production هاستِ خارج از allowlist وندار قبل از DNS/شبکه بلاک می‌شود. */
    public function test_vandar_blocks_non_allowlisted_host_in_production(): void
    {
        config_set('app.env', 'production');
        $this->configureVandar('https://api.vandar.io.evil.test');
        $breaker = $this->breakerMock();
        $breaker->shouldNotReceive('call');
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->andReturn(null);

        $result = (new VandarInquiryAdapter($this->loggerMock(), $cache, $breaker))->inquireIban(self::IBAN);

        $this->assertFalse((bool) $result['success']);
        $this->assertStringContainsString('مجاز نیست', strval($result['message'] ?? ''));
    }

    /** FIX-P3-ADP-154: خارج از production، گارد SSRF loopback مثل قبل بلاک می‌کند (هارنس قرارداد). */
    public function test_vandar_still_blocks_loopback_via_ssrf_guard_in_testing(): void
    {
        $this->configureVandar('http://127.0.0.1:8092/success/vandar');
        $breaker = $this->breakerMock();
        $breaker->shouldNotReceive('call');
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->andReturn(null);

        $result = (new VandarInquiryAdapter($this->loggerMock(), $cache, $breaker))->inquireIban(self::IBAN);

        $this->assertFalse((bool) $result['success']);
        $this->assertStringContainsString('مجاز نیست', strval($result['message'] ?? ''));
    }

    /** FIX-P3-ADP-154: business identifier خارج از allowlist فرمت = پروایدر پیکربندی‌نشده. */
    public function test_vandar_rejects_malformed_business_identifier(): void
    {
        $this->configureVandar('https://api.vandar.io', 'bad business!');
        $breaker = $this->breakerMock();
        $breaker->shouldNotReceive('call');
        $cache = $this->cacheMock();

        $adapter = new VandarInquiryAdapter($this->loggerMock(), $cache, $breaker);
        $this->assertFalse($adapter->isConfigured());
        $result = $adapter->inquireIban(self::IBAN);
        $this->assertFalse((bool) $result['success']);
        $this->assertStringContainsString('پیکربندی Vandar انجام نشده است', strval($result['message'] ?? ''));

        // slug سالم → configured
        $this->configureVandar('https://api.vandar.io', 'runtime-business');
        $okAdapter = new VandarInquiryAdapter($this->loggerMock(), $this->cacheMock(), $this->breakerMock());
        $this->assertTrue($okAdapter->isConfigured());
    }

    /** FIX-P3-ADP-155: owner/bank کپ طول می‌گیرند و پاسخ ناقص null می‌شود. */
    public function test_vandar_caps_owner_and_bank_lengths(): void
    {
        $this->configureVandar();
        $adapter = new VandarInquiryAdapter($this->loggerMock(), $this->cacheMock(), $this->breakerMock());
        $method = new \ReflectionMethod(VandarInquiryAdapter::class, 'normalizeProviderResult');

        $owners = [];
        for ($i = 0; $i < 12; $i++) {
            $owners[] = ['firstName' => str_repeat('ن', 120), 'lastName' => str_repeat('ف', 120)];
        }
        $normalized = $method->invoke($adapter, [
            'account_owners' => $owners,
            'bank_name' => str_repeat('بانک', 100),
        ], self::IBAN);

        $this->assertIsArray($normalized);
        $this->assertTrue((bool) $normalized['success']);
        $this->assertLessThanOrEqual(200, mb_strlen(strval($normalized['owner_name'])));
        $this->assertLessThanOrEqual(200, mb_strlen(strval($normalized['bank'])));
        $this->assertSame(self::IBAN, $normalized['iban']);

        // پاسخ ناقص (owners خالی) → null
        $this->assertNull($method->invoke($adapter, ['account_owners' => [], 'bank_name' => 'Bank'], self::IBAN));
    }
}

/**
 * آداپتر شمارندهٔ فراخوانی برای پین‌های منیجر (dedupe / skip / missing-service).
 * dedupe منیجر بر اساس get_class است؛ برای سناریوهای چند-پروایدرِه دو کلاس مجزا
 * لازم است (P3BankAltCountingAdapter هم‌ساختار این کلاس با نام کلاس متفاوت است).
 */
final class P3BankCountingAdapter implements BankInquiryAdapter
{
    public int $inquireCalls = 0;

    public function __construct(
        private readonly bool $configured = true,
        private readonly ?array $result = null,
        private readonly ?\Closure $handler = null,
    ) {
    }

    public function isConfigured(): bool
    {
        return $this->configured;
    }

    public function inquireIban(string $iban): array
    {
        $this->inquireCalls++;
        if ($this->handler !== null) {
            return ($this->handler)($iban);
        }
        return $this->result ?? ['success' => false, 'message' => 'no result configured'];
    }
}

/** کلاس دوم برای سناریوهای چند-پروایدره (dedupe منیجر بر اساس کلاس است). */
final class P3BankAltCountingAdapter implements BankInquiryAdapter
{
    public int $inquireCalls = 0;

    public function __construct(
        private readonly bool $configured = true,
        private readonly ?array $result = null,
        private readonly ?\Closure $handler = null,
    ) {
    }

    public function isConfigured(): bool
    {
        return $this->configured;
    }

    public function inquireIban(string $iban): array
    {
        $this->inquireCalls++;
        if ($this->handler !== null) {
            return ($this->handler)($iban);
        }
        return $this->result ?? ['success' => false, 'message' => 'no result configured'];
    }
}
