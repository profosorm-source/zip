<?php

namespace Tests\Unit\Adapters;

use PHPUnit\Framework\TestCase;
use App\Adapters\CryptoApiAdapter;
use App\Adapters\DeepFaceKycAdapter;
use App\Contracts\LoggerInterface;
use App\Services\Settings\AppSettings;
use Core\CircuitBreaker;
use Mockery as m;

/**
 * P3 crypto + KYC adapter pin tests (round p3-crypto).
 *
 * Pins the fail-closed remediations of the following findings:
 *  - ADP-072/073: unconfigured service / missing file must NEVER read as is_valid=true
 *  - ADP-074: biometric upload path containment + extension/MIME allowlist
 *  - ADP-075/077: malformed / schema-violating AI responses fail closed, bounds enforced
 *  - ADP-076: AI total timeout clamped to 5..120
 *  - ADP-078: upload/response size caps
 *  - ADP-079: idempotency headers on the paid AI endpoint
 *  - ADP-047: TON user-friendly address requires standard tag byte + CRC16-XMODEM
 *  - ADP-048: TON jetton body parser rejects non-hex / odd-length input
 *  - ADP-049/061: (response caps covered by adapter code; service-miss fail-closed here)
 *  - ADP-052: per-network destination address format validation
 *  - ADP-053: base58 canonicalization no longer lowercases case-sensitive addresses
 *  - ADP-057: JSON-RPC response schema (jsonrpc/id/error) validated
 *  - ADP-062: expected amount scale capped at 8 decimals
 */
class P3CryptoKycPinTest extends TestCase
{
    private ?string $tempBaseDir = null;

    protected function tearDown(): void
    {
        m::close();
        $this->cleanupTempBaseDir();
        parent::tearDown();
    }

    // ───────────────────────────── DeepFace KYC ─────────────────────────────

    private function deepFaceAdapter(): DeepFaceKycAdapter
    {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $breaker = m::mock(CircuitBreaker::class);
        $breaker->shouldReceive('call')->andReturnUsing(static fn (string $name, callable $operation) => $operation());
        return new DeepFaceKycAdapter($logger, $breaker);
    }

    private function tempBaseDir(): string
    {
        if ($this->tempBaseDir === null) {
            $this->tempBaseDir = sys_get_temp_dir() . '/p3-kyc-base-' . uniqid('', true);
            mkdir($this->tempBaseDir, 0770, true);
            config_set('services.deepface.allowed_base_dir', $this->tempBaseDir);
        }
        return $this->tempBaseDir;
    }

    private function cleanupTempBaseDir(): void
    {
        if ($this->tempBaseDir !== null && is_dir($this->tempBaseDir)) {
            foreach (glob($this->tempBaseDir . '/*') ?: [] as $f) {
                @unlink($f);
            }
            @rmdir($this->tempBaseDir);
        }
        $this->tempBaseDir = null;
    }

    private function writeTempFile(string $name, string $contents): string
    {
        $path = $this->tempBaseDir() . '/' . $name;
        file_put_contents($path, $contents);
        return $path;
    }

    private const PNG_MAGIC = "\x89PNG\r\n\x1A\n";

    /** @test ADP-072 */
    public function unconfigured_deepface_service_fails_closed_and_never_reads_as_valid(): void
    {
        config_set('services.deepface.api_url', null);
        $result = $this->deepFaceAdapter()->analyzeImage('/any/path.jpg');

        $this->assertFalse((bool)($result['success'] ?? true));
        $this->assertFalse((bool)($result['is_valid'] ?? true), 'Missing service must never read as a KYC pass.');
        $this->assertTrue((bool)($result['needs_manual_review'] ?? false));
    }

    /** @test ADP-073 */
    public function missing_file_fails_closed_and_never_reads_as_valid(): void
    {
        config_set('services.deepface.api_url', 'https://ai.example.com/analyze');
        config_set('services.deepface.allowed_base_dir', sys_get_temp_dir());

        $result = $this->deepFaceAdapter()->analyzeImage(sys_get_temp_dir() . '/definitely-missing-p3-' . uniqid() . '.png');

        $this->assertFalse((bool)($result['success'] ?? true));
        $this->assertFalse((bool)($result['is_valid'] ?? true), 'Missing file must never read as a KYC pass.');
        $this->assertTrue((bool)($result['needs_manual_review'] ?? false));
    }

    /** @test ADP-074 */
    public function path_containment_rejects_traversal_and_outside_base_dir(): void
    {
        config_set('services.deepface.api_url', 'https://ai.example.com/analyze');
        $base = $this->tempBaseDir();

        // a real, valid PNG placed OUTSIDE the allowed base dir
        $outside = sys_get_temp_dir() . '/p3-outside-' . uniqid('', true) . '.png';
        file_put_contents($outside, self::PNG_MAGIC);
        try {
            // 1) direct absolute path outside the base dir
            $result = $this->deepFaceAdapter()->analyzeImage($outside);
            $this->assertFalse((bool)($result['success'] ?? true));
            $this->assertFalse((bool)($result['is_valid'] ?? true), 'File outside base dir must be rejected.');

            // 2) ../ traversal resolving to the same outside file
            $traversal = $base . '/../' . basename($outside);
            $result2 = $this->deepFaceAdapter()->analyzeImage($traversal);
            $this->assertFalse((bool)($result2['success'] ?? true));
            $this->assertFalse((bool)($result2['is_valid'] ?? true), 'Traversal outside base dir must be rejected.');
        } finally {
            @unlink($outside);
        }
    }

    /** @test ADP-074 */
    public function upload_extension_and_mime_allowlist_reject_disguised_files(): void
    {
        config_set('services.deepface.api_url', 'https://ai.example.com/analyze');
        $base = $this->tempBaseDir();

        // 1) text file with a non-allowlisted extension
        $txt = $this->writeTempFile('secret.txt', 'top secret document body');
        $result = $this->deepFaceAdapter()->analyzeImage($txt);
        $this->assertFalse((bool)($result['is_valid'] ?? true), 'Non-image extension must be rejected.');

        // 2) .png name but text content — MIME sniffing must not trust the name
        $disguised = $this->writeTempFile('disguised.png', 'this is definitely not a png image');
        $result2 = $this->deepFaceAdapter()->analyzeImage($disguised);
        $this->assertFalse((bool)($result2['is_valid'] ?? true), 'Disguised extension must be rejected by MIME sniffing.');
    }

    /** @test ADP-078 */
    public function upload_file_size_cap_rejects_oversized_images(): void
    {
        config_set('services.deepface.api_url', 'https://ai.example.com/analyze');
        $base = $this->tempBaseDir();

        $huge = $base . '/huge.png';
        $fh = fopen($huge, 'wb');
        $this->assertIsResource($fh);
        ftruncate($fh, 10 * 1024 * 1024 + 1); // sparse 10MB+1 file
        fclose($fh);

        $result = $this->deepFaceAdapter()->analyzeImage($huge);
        $this->assertFalse((bool)($result['is_valid'] ?? true), 'Oversized upload must be rejected before any HTTP call.');
    }

    /** @test ADP-076 */
    public function deepface_timeout_is_clamped_to_safe_range(): void
    {
        $method = new \ReflectionMethod(DeepFaceKycAdapter::class, 'clampTimeout');
        $method->setAccessible(true);

        $this->assertSame(120, $method->invoke(null, 9999), 'Huge timeout must clamp to max.');
        $this->assertSame(120, $method->invoke(null, '5000'));
        $this->assertSame(5, $method->invoke(null, 0), 'Zero timeout must clamp to min.');
        $this->assertSame(5, $method->invoke(null, -50), 'Negative timeout must clamp to min.');
        $this->assertSame(30, $method->invoke(null, null), 'Non-numeric must fall back to default.');
        $this->assertSame(30, $method->invoke(null, 'not-a-number'));
        $this->assertSame(7, $method->invoke(null, 7.9), 'Fractional timeout floors to int within range.');
    }

    /** @test ADP-075/077/078 */
    public function malformed_or_oversized_ai_response_fails_closed(): void
    {
        $method = new \ReflectionMethod(DeepFaceKycAdapter::class, 'interpretAiResponse');
        $method->setAccessible(true);
        $adapter = $this->deepFaceAdapter();

        // malformed JSON → fail-closed (was is_valid=true before FIX-P3-ADP-075)
        $malformed = $method->invoke($adapter, '{not valid json', 'x.png');
        $this->assertFalse((bool)($malformed['success'] ?? true));
        $this->assertFalse((bool)($malformed['is_valid'] ?? true), 'Malformed AI response must fail closed.');
        $this->assertTrue((bool)($malformed['needs_manual_review'] ?? false));

        // oversized raw body (beyond 2MiB cap) → fail-closed
        $oversized = $method->invoke($adapter, str_repeat('a', 2 * 1024 * 1024 + 1), 'x.png');
        $this->assertFalse((bool)($oversized['is_valid'] ?? true), 'Oversized response must fail closed.');

        // empty body → fail-closed
        $empty = $method->invoke($adapter, '', 'x.png');
        $this->assertFalse((bool)($empty['is_valid'] ?? true));
    }

    /** @test ADP-077 */
    public function ai_response_schema_violation_fails_closed(): void
    {
        $method = new \ReflectionMethod(DeepFaceKycAdapter::class, 'interpretAiResponse');
        $method->setAccessible(true);
        $adapter = $this->deepFaceAdapter();

        // 'verified' must be a strict bool — strings/numbers are schema violations
        $stringVerified = $method->invoke($adapter, '{"verified": "true"}', 'x.png');
        $this->assertFalse((bool)($stringVerified['success'] ?? true));
        $this->assertFalse((bool)($stringVerified['is_valid'] ?? true), 'Non-bool verified must be a schema violation.');

        $numericVerified = $method->invoke($adapter, '{"verified": 1}', 'x.png');
        $this->assertFalse((bool)($numericVerified['is_valid'] ?? true));

        $missingVerified = $method->invoke($adapter, '{"confidence": 0.9}', 'x.png');
        $this->assertFalse((bool)($missingVerified['is_valid'] ?? true), 'Missing verified must be a schema violation.');
    }

    /** @test ADP-077 */
    public function ai_confidence_is_clamped_and_notes_are_sanitized_and_capped(): void
    {
        $method = new \ReflectionMethod(DeepFaceKycAdapter::class, 'interpretAiResponse');
        $method->setAccessible(true);
        $adapter = $this->deepFaceAdapter();

        $high = $method->invoke($adapter, '{"verified": true, "confidence": 1.7}', 'x.png');
        $this->assertTrue((bool)($high['success'] ?? false));
        $this->assertSame(1.0, $high['confidence'] ?? null, 'Confidence must clamp to [0,1].');

        $low = $method->invoke($adapter, '{"verified": false, "confidence": -0.5}', 'x.png');
        $this->assertSame(0.0, $low['confidence'] ?? null);

        $stringConfidence = $method->invoke($adapter, '{"verified": true, "confidence": "0.75"}', 'x.png');
        $this->assertSame(0.75, $stringConfidence['confidence'] ?? null);

        $missingConfidence = $method->invoke($adapter, '{"verified": true}', 'x.png');
        $this->assertSame(0.0, $missingConfidence['confidence'] ?? null);

        $longNotes = str_repeat('x', 2000);
        $withNotes = $method->invoke($adapter, '{"verified": true, "confidence": 0.5, "notes": "' . $longNotes . '"}', 'x.png');
        $this->assertLessThanOrEqual(501, mb_strlen((string)($withNotes['ai_notes'] ?? '')), 'Notes must be capped at 500 chars.');

        $withControlChars = $method->invoke($adapter, '{"verified": true, "confidence": 0.5, "notes": "ok\u0000bad"}', 'x.png');
        $this->assertSame('okbad', $withControlChars['ai_notes'] ?? null, 'Control characters must be stripped.');
    }

    /** @test ADP-079 */
    public function paid_ai_endpoint_sends_idempotency_headers(): void
    {
        $method = new \ReflectionMethod(DeepFaceKycAdapter::class, 'buildRequestHeaders');
        $method->setAccessible(true);
        $adapter = $this->deepFaceAdapter();

        $withToken = $method->invoke($adapter, 'secret-ai-token', 'kyc-abc123');
        $this->assertContains('Authorization: Bearer secret-ai-token', $withToken);
        $this->assertContains('X-Idempotency-Key: kyc-abc123', $withToken);
        $this->assertContains('X-Request-Id: kyc-abc123', $withToken);

        $withoutToken = $method->invoke($adapter, null, 'kyc-xyz');
        $this->assertNotContains('Authorization: Bearer ', $withoutToken);
        $this->assertContains('X-Idempotency-Key: kyc-xyz', $withoutToken);
    }

    // ─────────────────────────── CryptoApiAdapter ───────────────────────────

    /** FIX-P3-ADP-050: timeout صفر/منفی/غیرواقعی به CURLOPT_TIMEOUT منفی نمی‌رسد (clamp ۱..۱۲۰ در هر دو سایت) */
    public function test_crypto_timeout_is_clamped_to_sane_range(): void
    {
        $src = (string)file_get_contents(__DIR__ . '/../../../app/Adapters/CryptoApiAdapter.php');
        // هر دو سایت ساخت curl باید از متغیر clamp-شده (۱..۱۲۰) تغذیه شوند
        $this->assertStringContainsString('max(1, min(120, (int)$rawTimeout))', $src, 'clamp در executeWithRetry');
        $this->assertStringContainsString('max(1, min(120, (int)$rawT))', $src, 'clamp در executeJsonRpc');
        // CURLOPT_TIMEOUT فقط از متغیرهای clamp-شده تغذیه می‌شود (دو شکل فراخوانی)
        preg_match_all('/CURLOPT_TIMEOUT, \$timeout\)|CURLOPT_TIMEOUT=>\$timeout/', $src, $m);
        $this->assertCount(2, $m[0], 'هر دو سایت CURLOPT_TIMEOUT (setopt + setopt_array)');
    }

    private function makeCryptoAdapter(): CryptoApiAdapter
    {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $settings = m::mock(AppSettings::class);
        $settings->shouldReceive('get')->byDefault()->andReturnUsing(static fn ($key, $default = null) => $default);
        $breaker = m::mock(CircuitBreaker::class);
        $breaker->shouldReceive('call')->andReturnUsing(static fn (string $name, callable $operation) => $operation());
        return new CryptoApiAdapter($logger, $settings, $breaker);
    }

    private function blockCryptoProvidersAtLoopback(): void
    {
        // Loopback URLs are SSRF-blocked before curl runs → deterministic
        // "provider unreachable" without any real network traffic.
        config_set('services.crypto.tronscan_transaction_url', 'http://127.0.0.1:9/crypto/tron_tx/%s');
        config_set('services.crypto.trongrid_events_url', 'http://127.0.0.1:9/crypto/tron_events/%s');
        config_set('services.crypto.tronscan_status_url', 'http://127.0.0.1:9/crypto/tron_status');
        config_set('services.crypto.trongrid_block_url', 'http://127.0.0.1:9/crypto/tron_block');
        config_set('services.crypto.toncenter_run_url', 'http://127.0.0.1:9/crypto/ton_run');
        config_set('services.crypto.toncenter_fallback_run_url', 'http://127.0.0.1:9/crypto/ton_run_fb');
    }

    private const TRON_ADDR = 'TXkAFrBmcu4rQdP6EUepJWMEDwVwxcniZj';
    private const TON_ADDR = 'EQD2NmD_lH5f5u1Kj3KfGyTvhZSX0Eg6qp2a5IQUKXxOG21n'; // real USDT-TON master — valid CRC
    private const SOL_ADDR = '4Nd1mBQtrMJVYVfKf2PJy9NZUZdTAsp7D4xWLs4gDB4T';

    /** @test ADP-052 */
    public function destination_address_format_is_validated_per_network(): void
    {
        $adapter = $this->makeCryptoAdapter();

        foreach ([
            ['TRC20', str_repeat('a', 64), 'TToRuntimeWallet'],          // not a 34-char T-address
            ['BNB20', '0x' . str_repeat('c', 64), '0x123'],              // not 0x+40hex
            ['BNB20', '0x' . str_repeat('c', 64), str_repeat('c', 41)],  // missing 0x prefix
            ['TON', str_repeat('b', 64), 'EQToRuntimeWallet'],           // garbage TON form
            ['TON', str_repeat('b', 64), '1:zz'],                        // malformed wc:hex
            ['SOL', str_repeat('3', 88), 'SolToRuntimeWallet'],          // not base58 43-44
            ['SOL', str_repeat('3', 88), '0x' . str_repeat('a', 40)],    // EVM address on SOL
        ] as [$network, $hash, $toWallet]) {
            $result = $adapter->verify($network, $hash, '', $toWallet, '12.5');
            $this->assertSame('error', $result['status'] ?? null, "[$network] $toWallet");
            $this->assertSame('فرمت آدرس مقصد با شبکهٔ انتخاب‌شده هم‌خوانی ندارد', $result['reason'] ?? null, "[$network] $toWallet");
        }
    }

    /** @test ADP-062 */
    public function expected_amount_with_more_than_8_decimals_is_rejected(): void
    {
        $adapter = $this->makeCryptoAdapter();
        $this->blockCryptoProvidersAtLoopback();

        $over = $adapter->verify('TRC20', str_repeat('a', 64), '', self::TRON_ADDR, '0.123456789'); // 9 decimals
        $this->assertSame('error', $over['status'] ?? null);
        $this->assertSame('مقصد یا مبلغ مورد انتظار نامعتبر است', $over['reason'] ?? null);

        // boundary: exactly 8 decimals passes amount validation (fails later at unreachable provider = connection error)
        $ok = $adapter->verify('TRC20', str_repeat('a', 64), '', self::TRON_ADDR, '0.12345678');
        $this->assertSame('error', $ok['status'] ?? null);
        $this->assertStringContainsString('اتصال', (string)($ok['reason'] ?? ''), 'Valid format+amount must proceed to provider call.');
    }

    /** @test ADP-047 */
    public function ton_user_friendly_address_requires_standard_tag_and_valid_crc(): void
    {
        $adapter = $this->makeCryptoAdapter();
        $method = new \ReflectionMethod(CryptoApiAdapter::class, 'tonAddressToWcHash');
        $method->setAccessible(true);

        // real USDT-TON master address → parses with valid CRC
        $parsed = $method->invoke($adapter, self::TON_ADDR);
        $this->assertIsArray($parsed);
        $this->assertSame(0, $parsed['wc'] ?? null);
        $this->assertRegExp('/^[0-9a-f]{64}$/', (string)($parsed['hash'] ?? ''));

        // corrupted CRC byte → rejected
        $raw = base64_decode(strtr(substr(self::TON_ADDR, 0, 48), '-_', '+/'), true);
        $this->assertIsString($raw) && $this->assertSame(36, strlen($raw));
        $corruptedRaw = $raw;
        $corruptedRaw[35] = chr(ord($corruptedRaw[35]) ^ 0x01);
        $corrupted = strtr(base64_encode($corruptedRaw), '+/', '-_');
        $this->assertNull($method->invoke($adapter, $corrupted), 'Bad CRC must be rejected.');

        // valid CRC but non-standard tag byte → rejected
        $crcMethod = new \ReflectionMethod(CryptoApiAdapter::class, 'crc16Xmodem');
        $crcMethod->setAccessible(true);
        $badTagPayload = "\x00" . substr($raw, 1, 33); // 34 bytes, tag=0x00 (not 0x11/0x51/0x91)
        $badTagAddress = strtr(base64_encode($badTagPayload . $crcMethod->invoke(null, $badTagPayload)), '+/', '-_');
        $this->assertNull($method->invoke($adapter, $badTagAddress), 'Non-standard tag byte must be rejected.');

        // wc:hex form still parses
        $wcHex = $method->invoke($adapter, '-1:' . str_repeat('ab', 32));
        $this->assertIsArray($wcHex);
        $this->assertSame(-1, $wcHex['wc'] ?? null);
    }

    /** @test ADP-048 */
    public function ton_jetton_body_parser_rejects_non_hex_and_accepts_canonical_body(): void
    {
        $adapter = $this->makeCryptoAdapter();
        $method = new \ReflectionMethod(CryptoApiAdapter::class, 'tonParseJettonTransferNotification');
        $method->setAccessible(true);

        $this->assertNull($method->invoke($adapter, '7362d09c' . str_repeat('zz', 16)), 'Non-hex body must be rejected.');
        $this->assertNull($method->invoke($adapter, '7362d09c' . str_repeat('ab', 15) . 'a'), 'Odd-length hex must be rejected.');
        $this->assertNull($method->invoke($adapter, str_repeat('a', 23)), 'Too-short body must be rejected.');
        $this->assertNull($method->invoke($adapter, str_repeat('a', 20000)), 'Over-cap body must be rejected.');
        $this->assertNull($method->invoke($adapter, 'deadbeef' . str_repeat('ab', 16)), 'Wrong op must be rejected.');

        // canonical positive path: op + query_id + 1-byte amount + MsgAddressInt sender
        $bits = '';
        foreach ([0x73, 0x62, 0xd0, 0x9c] as $byte) {
            $bits .= str_pad(decbin($byte), 8, '0', STR_PAD_LEFT);
        }
        $bits .= str_repeat('0', 64);          // query_id
        $bits .= '0001';                        // VarUInteger16 length nibble = 1 byte
        $bits .= '11111111';                    // amount = 255
        $bits .= '10';                          // MsgAddressInt tag
        $bits .= '0';                           // anycast = 0
        $bits .= str_pad(decbin(0), 8, '0', STR_PAD_LEFT); // wc = 0
        $bits .= str_repeat('1', 256);          // sender hash
        $bits = str_pad($bits, (int)(ceil(strlen($bits) / 8) * 8), '0');
        $hex = '';
        foreach (str_split($bits, 4) as $nibble) {
            $hex .= dechex((int)bindec($nibble));
        }

        $parsed = $method->invoke($adapter, $hex);
        $this->assertIsArray($parsed);
        $this->assertSame('255', $parsed['amount'] ?? null);
        $this->assertSame(0, $parsed['sender_wc'] ?? null);
        $this->assertSame(str_repeat('f', 64), $parsed['sender_hash'] ?? null);
    }

    /** @test ADP-049/061 */
    public function jetton_wallet_resolution_fails_closed_when_service_unreachable(): void
    {
        $adapter = $this->makeCryptoAdapter();
        $this->blockCryptoProvidersAtLoopback();

        $method = new \ReflectionMethod(CryptoApiAdapter::class, 'tonResolveJettonWalletAddress');
        $method->setAccessible(true);

        $this->assertNull(
            $method->invoke($adapter, self::TON_ADDR, 0, str_repeat('ab', 32)),
            'Service miss must resolve to null (fail-closed), never a guessed address.'
        );
    }

    /** @test ADP-057 */
    public function json_rpc_response_schema_is_validated(): void
    {
        $method = new \ReflectionMethod(CryptoApiAdapter::class, 'isValidJsonRpcResponse');
        $method->setAccessible(true);

        $this->assertTrue($method->invoke(null, ['jsonrpc' => '2.0', 'id' => 1, 'result' => ['ok' => 1]], 1));
        $this->assertTrue($method->invoke(null, ['jsonrpc' => '2.0', 'id' => '1', 'result' => null], 1), 'String-typed matching id must be accepted.');

        $this->assertFalse($method->invoke(null, ['id' => 1, 'result' => []], 1), 'Missing jsonrpc must be rejected.');
        $this->assertFalse($method->invoke(null, ['jsonrpc' => '1.0', 'id' => 1, 'result' => []], 1), 'Wrong protocol version must be rejected.');
        $this->assertFalse($method->invoke(null, ['jsonrpc' => '2.0', 'id' => 2, 'result' => []], 1), 'Mismatched id must be rejected.');
        $this->assertFalse($method->invoke(null, ['jsonrpc' => '2.0', 'id' => null, 'result' => []], 1));
        $this->assertFalse($method->invoke(null, ['jsonrpc' => '2.0', 'id' => 1, 'error' => ['code' => -32600, 'message' => 'bad']], 1), 'Error member must be rejected.');
        $this->assertFalse($method->invoke(null, 'not-an-array', 1));
    }

    /** @test ADP-053 */
    public function base58_addresses_are_canonicalized_without_case_folding(): void
    {
        $adapter = $this->makeCryptoAdapter();
        $method = new \ReflectionMethod(CryptoApiAdapter::class, 'normalizeAddress');
        $method->setAccessible(true);

        $canonical = $method->invoke($adapter, self::TRON_ADDR, 'tron');
        $this->assertRegExp('/^[0-9a-f]{42}$/', $canonical, 'TRON base58 must canonicalize to 21-byte payload hex.');

        // case-mangled base58 is a DIFFERENT address — must not compare equal (was lowercased before)
        $mangled = 'TXKAFRBMCU4RQDP6EUEPJWMEDWVWXCNIZJ';
        $this->assertNotSame($canonical, $method->invoke($adapter, $mangled, 'tron'), 'Case-folded base58 equality is the bug being pinned.');

        // the USDT contract alias keeps its single canonical form
        $this->assertSame(
            'tr7nhqjekqxgwtci8q8zy4pl8otszgjlj6t',
            $method->invoke($adapter, 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', 'tron')
        );

        // hex forms stay case-insensitive (safe for hex only)
        $this->assertSame('0xabc', $method->invoke($adapter, '0xABC', 'bsc'));
        $this->assertSame('0xabc', $method->invoke($adapter, '0xABC', 'evm'));
        $this->assertSame(
            '41a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a901',
            $method->invoke($adapter, '41A1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6E7F8A901', 'tron')
        );

        // unparseable input falls back to exact comparison (fail-closed), not case folding
        $this->assertSame('TTooShort', $method->invoke($adapter, 'TTooShort', 'tron'));
    }
}
