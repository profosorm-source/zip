<?php

declare(strict_types=1);

namespace Tests\Unit\Adapters;

use App\Adapters\Notification\FcmNotificationAdapter;
use App\Adapters\Notification\LogNotificationAdapter;
use App\Adapters\Notification\PushNotificationAdapter;
use App\Adapters\Notification\SmsNotificationAdapter;
use App\Adapters\NotificationAdAdapter;
use App\Contracts\CacheInterface;
use App\Contracts\LoggerInterface;
use App\Contracts\MetricsCollectorInterface;
use App\Services\Notification\NotificationOrchestrator;
use Core\CircuitBreaker;
use Core\Database;
use Core\Logger;
use Core\ValueObjects\Money;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * P3 notify cluster pin tests (FIX-P3-ADP-*).
 *
 * قفل رفتارهای کلیدِ جدید آداپترهای نوتیفیکیشن بدون هیچ وابستگی شبکه/DB:
 *  - ADP-090/101: گیت فرمت توکن + schema/bounds payload (title/body/data/URL)
 *  - ADP-092: شمارش failed مقابل ورودی اصلی batch
 *  - ADP-093: purge توکن مرده فقط با semantics بدنه (نه هر 404 بی‌بدنه)
 *  - ADP-095: isConfigured فقط با فایل واقعیِ خواندنی
 *  - ADP-096: outage cache مسیر auth را نمی‌شکند
 *  - ADP-103/104: قرارداد failure واحد single/batch + breaker واقعی (no-op حذف شده)
 *  - ADP-122/123: پارس سخت‌گیرانه enabled + gate readiness در send
 *  - ADP-125: canonical money + allowlist ارز در پیامک برداشت
 *  - ADP-131: mask طول‌امن موبایل
 *  - ADP-105/109/112/114/115/116/117: LogNotificationAdapter bounds/fail-visible/ack
 *  - ADP-133/134/135/136/137: NotificationAdAdapter https/schedule/id/currency/bool
 *  - ADP-121: PushNotificationAdapter با LoggerInterface
 */
final class P3NotifyAdaptersPinTest extends TestCase
{
    private ?string $serviceAccountFile = null;

    protected function tearDown(): void
    {
        m::close();
        if ($this->serviceAccountFile !== null && is_file($this->serviceAccountFile)) {
            @unlink($this->serviceAccountFile);
            $this->serviceAccountFile = null;
        }
        parent::tearDown();
    }

    // ────────────────────────────── helpers ──────────────────────────────

    private function loggerMock(): LoggerInterface&m\MockInterface
    {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        return $logger;
    }

    private function orchestratorMock(LoggerInterface $logger, CacheInterface $cache, CircuitBreaker $circuit): NotificationOrchestrator&m\MockInterface
    {
        $orchestrator = m::mock(NotificationOrchestrator::class);
        $orchestrator->shouldReceive('logger')->andReturn($logger);
        $orchestrator->shouldReceive('cache')->andReturn($cache);
        $orchestrator->shouldReceive('circuitBreaker')->andReturn($circuit);
        return $orchestrator;
    }

    private function cacheMock(): CacheInterface&m\MockInterface
    {
        $cache = m::mock(CacheInterface::class);
        $cache->shouldReceive('get')->byDefault()->andReturn(null);
        $cache->shouldReceive('put')->byDefault()->andReturn(true);
        $cache->shouldReceive('forget')->byDefault()->andReturn(true);
        return $cache;
    }

    private function passthroughCircuit(): CircuitBreaker&m\MockInterface
    {
        $circuit = m::mock(CircuitBreaker::class);
        $circuit->shouldReceive('call')->byDefault()->andReturnUsing(
            static fn(string $name, callable $operation) => $operation()
        );
        return $circuit;
    }

    private function metricsMock(): MetricsCollectorInterface&m\MockInterface
    {
        $metrics = m::mock(MetricsCollectorInterface::class);
        $metrics->shouldIgnoreMissing();
        return $metrics;
    }

    private function writeServiceAccount(string $content): string
    {
        $path = sys_get_temp_dir() . '/p3-fcm-sa-' . bin2hex(random_bytes(5)) . '.json';
        file_put_contents($path, $content);
        $this->serviceAccountFile = $path;
        return $path;
    }

    /**
     * FCM adapter با isConfigured()=true و credential خراب (هیچ شبکه‌ای لمس نمی‌شود).
     */
    private function makeFcmAdapter(
        CacheInterface $cache,
        CircuitBreaker $circuit,
        ?MetricsCollectorInterface $metrics = null,
        ?LoggerInterface $logger = null
    ): FcmNotificationAdapter {
        config_set('services.fcm.project_id', 'p3-pin-project');
        config_set('services.fcm.service_account_json', $this->writeServiceAccount('{not-a-service-account'));
        // IP literal عمومی — بدون DNS resolution از گارد SSRF رد می‌شود؛ ترافیک واقعی
        // هم رخ نمی‌دهد (breaker mock قبل از transport می‌گیرد یا credential خراب است).
        config_set('services.fcm.endpoint', 'https://8.8.8.8/v1/projects/%s/messages_send');
        $logger = $logger ?? $this->loggerMock();
        $orchestrator = $this->orchestratorMock($logger, $cache, $circuit);
        return new FcmNotificationAdapter($metrics ?? $this->metricsMock(), $orchestrator, m::mock(Database::class));
    }

    private function invokePrivate(object $target, string $method, array $args): mixed
    {
        $ref = new \ReflectionMethod($target, $method);
        $ref->setAccessible(true);
        return $ref->invoke($target, ...$args);
    }

    private function setPrivate(object $target, string $property, mixed $value): void
    {
        $ref = new \ReflectionProperty($target, $property);
        $ref->setAccessible(true);
        $ref->setValue($target, $value);
    }

    private function validFcmToken(): string
    {
        return 'p3-pin-valid-fcm-token-000000000001';
    }

    // ─────────────────────── FcmNotificationAdapter ───────────────────────

    /** FIX-P3-ADP-090: توکنِ بدشکل در مرزِ ارسال رد می‌شود — قبل از هر transport/auth */
    public function test_fcm_send_to_token_rejects_malformed_token_without_transport(): void
    {
        $cache = $this->cacheMock();
        $cache->shouldNotReceive('put'); // هرگز تا auth نمی‌رسد
        $adapter = $this->makeFcmAdapter($cache, $this->passthroughCircuit());

        $this->assertFalse($adapter->sendToToken('short', 't', 'b'));
        $this->assertFalse($adapter->sendToToken("tok-with-\x01-control-char-12345", 't', 'b'));
    }

    /** FIX-P3-ADP-092: کل batchِ نامعتبر = failed به تعداد ورودیِ اصلی، بدون transport */
    public function test_fcm_send_to_tokens_counts_invalid_tokens_against_original_input(): void
    {
        $metrics = $this->metricsMock();
        $metrics->shouldReceive('increment')->once()->with('fcm.send.failure', ['count' => 3]);
        $adapter = $this->makeFcmAdapter($this->cacheMock(), $this->passthroughCircuit(), $metrics);

        $result = $adapter->sendToTokens(['x', 123, 'short'], 't', 'b');

        $this->assertSame(['sent' => 0, 'failed' => 3], $result);
    }

    /** FIX-P3-ADP-092: ورودی مخلوط (معتبر + تکراری + غیر string) بدون credential معتبر = همه failed */
    public function test_fcm_send_to_tokens_mixed_input_reports_against_original_count(): void
    {
        $adapter = $this->makeFcmAdapter($this->cacheMock(), $this->passthroughCircuit());
        $tokens = [$this->validFcmToken(), $this->validFcmToken(), 42, 'short'];
        $result = $adapter->sendToTokens($tokens, 't', 'b');
        $this->assertSame(0, $result['sent']);
        $this->assertSame(count($tokens), $result['failed']);
    }

    /** FIX-P3-ADP-090/101: schema payload — cap طول، کلید رزرو، مقدار non-scalar، URL غیر https */
    public function test_fcm_build_payload_enforces_bounds_reserved_keys_and_https_urls(): void
    {
        $adapter = $this->makeFcmAdapter($this->cacheMock(), $this->passthroughCircuit());

        $payload = $this->invokePrivate($adapter, 'buildPayload', [
            str_repeat('ع', 300),                 // عنوان خیلی بلند
            str_repeat('م', 1200),               // متن خیلی بلند
            [
                'ok'        => 12,               // scalar → '12'
                'from'      => 'spoofed',        // رزروشده → drop
                'google.x'  => 'reserved',       // پیشوند رزرو → drop
                'nested'    => ['a' => 1],       // non-scalar → drop
                str_repeat('k', 100) => 'v',     // کلید خیلی بلند → drop
            ],
            'http://insecure.example/img.png',       // غیر https → drop
            'javascript:alert(1)',                    // scheme غیرمجاز → drop
        ]);

        /** @var array<string, mixed> $message */
        $message = $payload['message'];
        $this->assertSame(200, mb_strlen($message['notification']['title']));
        $this->assertSame(1000, mb_strlen($message['notification']['body']));
        $this->assertArrayNotHasKey('image', $message['notification']);
        $this->assertSame(['ok' => '12'], $message['data']);
        $this->assertNull($message['webpush']);

        // URL https معتبر باید باقی بماند
        $payload2 = $this->invokePrivate($adapter, 'buildPayload', ['t', 'b', [], null, 'https://merchant.example/open']);
        /** @var array<string, mixed> $message2 */
        $message2 = $payload2['message'];
        $this->assertSame('https://merchant.example/open', $message2['webpush']['fcm_options']['link']);
    }

    /** FIX-P3-ADP-095: فقط فایلِ واقعیِ خواندنی «configured» است */
    public function test_fcm_is_configured_requires_readable_file(): void
    {
        $adapter = $this->makeFcmAdapter($this->cacheMock(), $this->passthroughCircuit());
        $this->assertTrue($adapter->isConfigured());

        $dir = sys_get_temp_dir() . '/p3-fcm-dir-' . bin2hex(random_bytes(3));
        @mkdir($dir);
        $this->setPrivate($adapter, 'serviceAccountPath', $dir);
        $this->assertFalse($adapter->isConfigured(), 'directory must not count as configured');

        $this->setPrivate($adapter, 'serviceAccountPath', '/nonexistent/path/sa.json');
        $this->assertFalse($adapter->isConfigured());

        $this->setPrivate($adapter, 'serviceAccountPath', $dir);
        $this->setPrivate($adapter, 'projectId', '');
        $this->assertFalse($adapter->isConfigured(), 'empty project id must not count as configured');
        @rmdir($dir);
    }

    /** FIX-P3-ADP-093: 404ِ بی‌بدنه purge نمی‌کند؛ 404 با NOT_FOUND semantics و UNREGISTERED بله */
    public function test_fcm_token_purge_requires_not_found_body_semantics(): void
    {
        $adapter = $this->makeFcmAdapter($this->cacheMock(), $this->passthroughCircuit());

        $this->assertFalse($this->invokePrivate($adapter, 'isFcmTokenInvalidResponse', [404, '']), 'bare 404 must NOT purge');
        $this->assertFalse($this->invokePrivate($adapter, 'isFcmTokenInvalidResponse', [404, '<html>Not Found</html>']), 'project-level 404 page must NOT purge');
        $this->assertTrue($this->invokePrivate($adapter, 'isFcmTokenInvalidResponse', [404, '{"error":{"status":"NOT_FOUND"}}']));
        $this->assertTrue($this->invokePrivate($adapter, 'isFcmTokenInvalidResponse', [404, '{"error":{"message":"Requested entity was not found."}}']));
        $this->assertTrue($this->invokePrivate($adapter, 'isFcmTokenInvalidResponse', [400, 'UNREGISTERED']));
        $this->assertFalse($this->invokePrivate($adapter, 'isFcmTokenInvalidResponse', [400, '{"error":{"status":"INVALID_ARGUMENT"}}']));
        $this->assertFalse($this->invokePrivate($adapter, 'isFcmTokenInvalidResponse', [200, 'ok']));
    }

    /** FIX-P3-ADP-104: مدارِ باز = شکست صادقانه + متریک open_skipped؛ no-op legacy حذف شده */
    public function test_fcm_circuit_open_returns_false_without_fake_success(): void
    {
        $circuit = m::mock(CircuitBreaker::class);
        $circuit->shouldReceive('call')->once()->with('fcm', \Mockery::on(fn($op) => is_callable($op)))
            ->andThrow(new \Core\Exceptions\CircuitBreakerOpenException('fcm'));
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->with('fcm:access_token')->andReturn('cached-oauth-token');
        $metrics = $this->metricsMock();
        $metrics->shouldReceive('increment')->once()->with('fcm.circuit.open_skipped');

        $adapter = $this->makeFcmAdapter($cache, $circuit, $metrics);

        $this->assertFalse(method_exists(FcmNotificationAdapter::class, 'isFcmCircuitOpen'), 'legacy no-op stub must be removed');
        $this->assertFalse($adapter->sendToToken($this->validFcmToken(), 't', 'b'));
    }

    /** FIX-P3-ADP-103: قرارداد failure واحد — sendToToken هرگز rethrow نمی‌کند */
    public function test_fcm_send_to_token_swallows_transport_exception_like_batch(): void
    {
        $circuit = m::mock(CircuitBreaker::class);
        $circuit->shouldReceive('call')->once()->andThrow(new \RuntimeException('boom'));
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->with('fcm:access_token')->andReturn('cached-oauth-token');

        $adapter = $this->makeFcmAdapter($cache, $circuit);

        $this->assertFalse($adapter->sendToToken($this->validFcmToken(), 't', 'b'));
    }

    /** FIX-P3-ADP-096/091: outage cache مسیر auth را نمی‌شکند؛ batch پشت breaker 'fcm_batch' است */
    public function test_fcm_batch_is_gated_behind_fcm_batch_breaker(): void
    {
        $circuit = m::mock(CircuitBreaker::class);
        $circuit->shouldReceive('call')->once()->with('fcm_batch', \Mockery::on(fn($op) => is_callable($op)))
            ->andThrow(new \Core\Exceptions\CircuitBreakerOpenException('fcm_batch'));
        $cache = $this->cacheMock();
        $cache->shouldReceive('get')->with('fcm:access_token')->andReturn('cached-oauth-token');

        $adapter = $this->makeFcmAdapter($cache, $circuit);

        $result = $adapter->sendToTokens([$this->validFcmToken(), $this->validFcmToken()], 't', 'b');
        $this->assertSame(['sent' => 0, 'failed' => 2], $result);
    }

    // ─────────────────────── SmsNotificationAdapter ───────────────────────

    private function makeSmsAdapter(LoggerInterface $orchestratorLogger): SmsNotificationAdapter
    {
        $orchestrator = m::mock(NotificationOrchestrator::class);
        $orchestrator->shouldReceive('logger')->andReturn($orchestratorLogger);
        $orchestrator->shouldReceive('circuitBreaker')->andReturn($this->passthroughCircuit());
        return new SmsNotificationAdapter(
            m::mock(\App\Models\User::class),
            m::mock(Logger::class),
            m::mock(CircuitBreaker::class),
            $orchestrator
        );
    }

    /** FIX-P3-ADP-122: (bool)'false' دیگر true جعل نمی‌کند */
    public function test_sms_enabled_config_is_parsed_strictly(): void
    {
        config_set('services.sms.enabled', 'false');
        config_set('services.sms.provider', 'kavenegar');
        config_set('services.sms.api_key', 'p3-pin-key');
        $disabledAdapter = $this->makeSmsAdapter($this->loggerMock());
        $this->assertFalse($disabledAdapter->isEnabled(), "string 'false' must parse to false");

        config_set('services.sms.enabled', 'true');
        $enabledAdapter = $this->makeSmsAdapter($this->loggerMock());
        $this->assertTrue($enabledAdapter->isEnabled(), "string 'true' must parse to true");

        config_set('services.sms.enabled', '0');
        $zeroAdapter = $this->makeSmsAdapter($this->loggerMock());
        $this->assertFalse($zeroAdapter->isEnabled());
    }

    /** FIX-P3-ADP-123: send روی readiness گیت می‌خورد نه فقط flag enabled */
    public function test_sms_send_gates_on_readiness_not_just_enabled(): void
    {
        config_set('services.sms.enabled', true);
        config_set('services.sms.provider', '');
        config_set('services.sms.api_key', '');

        $logger = $this->loggerMock();
        $logger->shouldReceive('info')->once()->with('sms.disabled', \Mockery::on(fn($ctx) => is_array($ctx)));
        $adapter = $this->makeSmsAdapter($logger);

        $this->assertFalse($adapter->send('09121234567', 'hello'));
    }

    /** FIX-P3-ADP-125: ارز allowlist و مبلغ canonical — ورودی خام به پیامک راه ندارد */
    public function test_sms_withdrawal_alert_rejects_bad_currency_and_amount(): void
    {
        config_set('services.sms.enabled', true);
        config_set('services.sms.provider', 'kavenegar');
        config_set('services.sms.api_key', 'p3-pin-key');

        $logger = $this->loggerMock();
        $logger->shouldReceive('warning')->once()->with('sms.withdrawal.currency_rejected', \Mockery::on(fn($ctx) => ($ctx['currency'] ?? '') === 'btc'));
        $logger->shouldReceive('warning')->once()->with('sms.withdrawal.amount_rejected', \Mockery::on(fn($ctx) => is_array($ctx)));
        $adapter = $this->makeSmsAdapter($logger);

        $this->assertFalse($adapter->sendWithdrawalAlert('09121234567', '50000', 'BTC'));
        $this->assertFalse($adapter->sendWithdrawalAlert('09121234567', 'not-a-number', 'irt'));
    }

    /** FIX-P3-ADP-131: mask طول‌امن — ورودی کوتاه کاملاً mask می‌شود */
    public function test_sms_mask_mobile_is_length_safe(): void
    {
        config_set('services.sms.enabled', false);
        $adapter = $this->makeSmsAdapter($this->loggerMock());

        $this->assertSame('****', $this->invokePrivate($adapter, 'maskMobile', ['0912']));
        $this->assertSame('****', $this->invokePrivate($adapter, 'maskMobile', ['']));
        $this->assertSame('0912****567', $this->invokePrivate($adapter, 'maskMobile', ['09121234567']));
    }

    // ─────────────────────── LogNotificationAdapter ───────────────────────

    private function makeLogAdapter(\App\Models\Notification&m\MockInterface $notification, \App\Models\SystemTelemetryModel&m\MockInterface $telemetry, ?LoggerInterface $logger = null): LogNotificationAdapter
    {
        $orchestrator = m::mock(NotificationOrchestrator::class);
        $logger = $logger ?? $this->loggerMock();
        $orchestrator->shouldReceive('logger')->andReturn($logger);
        $orchestrator->shouldReceive('circuitBreaker')->andReturn($this->passthroughCircuit());
        return new LogNotificationAdapter($notification, $telemetry, m::mock(Logger::class), m::mock(CircuitBreaker::class), $orchestrator);
    }

    /** FIX-P3-ADP-109: کانال sms فعال = شکستِ دیدنی + history 'failed' */
    public function test_log_adapter_sms_channel_fails_visibly_with_history(): void
    {
        $notification = m::mock(\App\Models\Notification::class);
        $notification->shouldReceive('getActiveChannelsBySeverity')->once()->with('high')->andReturn([
            (object)['id' => 3, 'channel_type' => 'sms', 'config' => '{}'],
        ]);
        $notification->shouldReceive('logHistory')->once()->with(3, 'alert', 't', \Mockery::type('string'), 'failed');

        $logger = $this->loggerMock();
        $logger->shouldReceive('warning')->once()->with('log_notification.sms_channel_unimplemented', \Mockery::on(fn($ctx) => is_array($ctx)));

        $adapter = $this->makeLogAdapter($notification, m::mock(\App\Models\SystemTelemetryModel::class), $logger);
        $this->assertFalse($adapter->sendAlert('t', 'hello message', 'high'));
    }

    /** FIX-P3-ADP-105: severity نامعتبر → medium (query با medium می‌رود) و طول‌ها capped */
    public function test_log_adapter_send_alert_normalizes_severity_and_caps_lengths(): void
    {
        $notification = m::mock(\App\Models\Notification::class);
        $notification->shouldReceive('getActiveChannelsBySeverity')->once()->with('medium')->andReturn([]);
        $adapter = $this->makeLogAdapter($notification, m::mock(\App\Models\SystemTelemetryModel::class));

        $this->assertFalse($adapter->sendAlert(str_repeat('t', 500), str_repeat('m', 9000), 'bogus-severity'));
    }

    /** FIX-P3-ADP-112: testChannel برای sms پیام صادقانهٔ «پیاده‌سازی نشده» می‌دهد */
    public function test_log_adapter_test_channel_sms_reports_unsupported(): void
    {
        $notification = m::mock(\App\Models\Notification::class);
        $notification->shouldReceive('getChannel')->once()->with(9)
            ->andReturn((object)['id' => 9, 'channel_type' => 'sms', 'config' => '{}']);

        $adapter = $this->makeLogAdapter($notification, m::mock(\App\Models\SystemTelemetryModel::class));
        $result = $adapter->testChannel(9);

        $this->assertFalse($result['success']);
        $this->assertSame('کانال پیامک هنوز پیاده‌سازی نشده است', $result['message']);
    }

    /** FIX-P3-ADP-114: شکستِ همهٔ کانال‌ها rule را ack نمی‌کند (suppression مسلح نمی‌شود) */
    public function test_log_adapter_check_alert_rules_does_not_ack_on_total_send_failure(): void
    {
        $rule = (object)[
            'id' => 7,
            'rule_name' => 'P3 pin rule',
            'condition' => json_encode(['metric' => 'error_count', 'operator' => '>']),
            'threshold' => 1,
            'time_window' => 5,
            'severity' => 'critical',
            'last_triggered_at' => null,
        ];

        $telemetry = m::mock(\App\Models\SystemTelemetryModel::class);
        $telemetry->shouldReceive('getActiveAlertRules')->once()->andReturn([$rule]);
        $telemetry->shouldReceive('getErrorCount')->once()->with(5)->andReturn(10);
        // FIX-P3-ADP-113: claim اتمیک برنده می‌شود، اما ارسالِ کاملاً شکست‌خورده claim را پس می‌دهد
        $telemetry->shouldReceive('claimAlertRuleTrigger')->once()->with(7, 3600)->andReturnTrue();
        $telemetry->shouldReceive('releaseAlertRuleClaim')->once()->with(7, null)->andReturnTrue();

        $notification = m::mock(\App\Models\Notification::class);
        $notification->shouldReceive('getActiveChannelsBySeverity')->once()->with('critical')->andReturn([]);

        $logger = $this->loggerMock();
        $logger->shouldReceive('warning')->once()->with('log_notification.alert_rule.not_acked_all_channels_failed', \Mockery::on(fn($ctx) => ($ctx['rule_id'] ?? 0) === 7));

        $adapter = $this->makeLogAdapter($notification, $telemetry, $logger);
        $adapter->checkAlertRules();
        // رفتار کلیدی: rule ack نشد (claim پس داده شد) — صریح pin می‌شود
        $this->assertTrue(true, 'all-channels-failed must release the claim, not ack');
    }

    /** FIX-P3-ADP-113: claimِ باخته یعنی worker دیگری فرستاد — sendAlert اصلاً صدا نمی‌شود */
    public function test_log_adapter_check_alert_rules_claim_lost_skips_send(): void
    {
        $rule = (object)[
            'id' => 11,
            'rule_name' => 'P3 race rule',
            'condition' => json_encode(['metric' => 'error_count', 'operator' => '>']),
            'threshold' => 1,
            'time_window' => 5,
            'severity' => 'high',
            'last_triggered_at' => null,
        ];

        $telemetry = m::mock(\App\Models\SystemTelemetryModel::class);
        $telemetry->shouldReceive('getActiveAlertRules')->once()->andReturn([$rule]);
        $telemetry->shouldReceive('getErrorCount')->once()->with(5)->andReturn(10);
        $telemetry->shouldReceive('claimAlertRuleTrigger')->once()->with(11, 3600)->andReturnFalse();
        $telemetry->shouldNotReceive('releaseAlertRuleClaim');

        $notification = m::mock(\App\Models\Notification::class);
        $notification->shouldNotReceive('getActiveChannelsBySeverity');

        $logger = $this->loggerMock();
        $logger->shouldReceive('info')->once()->with('log_notification.alert_rule.claim_lost', \Mockery::on(fn($ctx) => ($ctx['rule_id'] ?? 0) === 11));

        $adapter = $this->makeLogAdapter($notification, $telemetry, $logger);
        $adapter->checkAlertRules();
        $this->assertTrue(true, 'claim lost must skip send entirely');
    }

    /** FIX-P3-ADP-116/117: متریک/عملگر ناشناخته دیدنی است؛ == strict شد */
    public function test_log_adapter_evaluate_rule_unknown_metric_operator_and_strict_equality(): void
    {
        $telemetry = m::mock(\App\Models\SystemTelemetryModel::class);
        // ترتیب مهم است: with(1440) باید قبل از catch-all تعریف شود (Mockery اولین تطبیق می‌برد)
        $telemetry->shouldReceive('getErrorCount')->with(1440)->andReturn(0);
        $telemetry->shouldReceive('getErrorCount')->with(5)->andReturn(5);

        $logger = $this->loggerMock();
        $logger->shouldReceive('warning')->once()->with('log_notification.alert_rule.unknown_metric', \Mockery::on(fn($ctx) => ($ctx['metric'] ?? '') === 'nope_metric'));
        $logger->shouldReceive('warning')->once()->with('log_notification.alert_rule.unknown_operator', \Mockery::on(fn($ctx) => ($ctx['operator'] ?? '') === '=~'));

        $adapter = $this->makeLogAdapter(m::mock(\App\Models\Notification::class), $telemetry, $logger);

        $rule = (object)['id' => 7, 'time_window' => 5, 'threshold' => 5];

        $this->assertTrue($this->invokePrivate($adapter, 'evaluateRule', [$rule, ['metric' => 'error_count', 'operator' => '==']]));
        $this->assertFalse($this->invokePrivate($adapter, 'evaluateRule', [$rule, ['metric' => 'nope_metric', 'operator' => '>']]));
        $this->assertFalse($this->invokePrivate($adapter, 'evaluateRule', [$rule, ['metric' => 'error_count', 'operator' => '=~']]));

        // FIX-P3-ADP-116: پنجرهٔ زمانی clamp می‌شود (1500 دقیقه → 1440)
        $clamped = (object)['id' => 7, 'time_window' => 1500, 'threshold' => 0];
        $this->assertFalse($this->invokePrivate($adapter, 'evaluateRule', [$clamped, ['metric' => 'error_count', 'operator' => '>']]));
    }

    /** FIX-P3-ADP-115: استثنا در کانال هم history 'failed' می‌نویسد */
    public function test_log_adapter_channel_exception_writes_failed_history(): void
    {
        $notification = m::mock(\App\Models\Notification::class);
        $notification->shouldReceive('getActiveChannelsBySeverity')->once()->andReturn([
            (object)['id' => 4, 'channel_type' => 'telegram', 'config' => 'not-valid-json'],
        ]);
        // decodeConfig روی 'not-valid-json' آرایهٔ خالی می‌دهد → sendTelegram early false —
        // برای تحمیل استثنا، logHistory بار اول throw می‌کند؛ catch باید دوباره history بنویسد.
        $notification->shouldReceive('logHistory')->once()->andThrow(new \RuntimeException('history down'));
        $notification->shouldReceive('logHistory')->once()->with(4, 'alert', \Mockery::type('string'), \Mockery::type('string'), 'failed');

        $logger = $this->loggerMock();
        $logger->shouldReceive('error')->once()->with('log_notification.channel.send.failed', \Mockery::on(fn($ctx) => is_array($ctx)));

        $adapter = $this->makeLogAdapter($notification, m::mock(\App\Models\SystemTelemetryModel::class), $logger);
        $this->assertFalse($adapter->sendAlert('t', 'm', 'low'));
    }

    // ─────────────────────── NotificationAdAdapter ───────────────────────

    private function makeAdAdapter(?\App\Models\Ads $adModel = null, ?\App\Services\Settings\AppSettings $settings = null): NotificationAdAdapter
    {
        $adModel = $adModel ?? m::mock(\App\Models\Ads::class);
        $settings = $settings ?? m::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('get')->byDefault()->andReturnUsing(
            static fn(string $key, mixed $default = null) => $default
        );
        return new NotificationAdAdapter(
            $adModel,
            m::mock(\App\Contracts\WalletServiceInterface::class),
            m::mock(Database::class),
            $this->loggerMock(),
            $settings,
            m::mock(\App\Contracts\ValidatorFactoryInterface::class),
            m::mock(\App\Services\Shared\IdempotencyService::class),
            m::mock(\App\Services\Ads\AdsBudgetSettlementService::class)
        );
    }

    private function validAdData(): array
    {
        return [
            'title' => 'تخفیف ویژه P3',
            'body' => 'متن پیام نوتیفیکیشن آگهی حداقل ده کاراکتر',
            'budget' => 5000,
        ];
    }

    /** FIX-P3-ADP-133: لینک مقصد فقط https؛ image/icon مسیر نسبیِ امن */
    public function test_notification_ad_validate_enforces_https_and_safe_paths(): void
    {
        $adapter = $this->makeAdAdapter();

        $httpLink = $this->validAdData() + ['target_link' => 'http://example.com/campaign'];
        $result = $adapter->validate($httpLink);
        $this->assertFalse($result['valid']);
        $this->assertContains('لینک مقصد نوتیفیکیشن باید HTTPS باشد.', $result['errors']);

        $traversal = $this->validAdData() + ['image_path' => '../uploads/evil.png'];
        $result = $adapter->validate($traversal);
        $this->assertFalse($result['valid']);
        $this->assertContains('مسیر تصویر نوتیفیکیشن نامعتبر است.', $result['errors']);

        $ok = $this->validAdData() + ['target_link' => 'https://example.com/campaign', 'image_path' => 'uploads/ads/pic.png'];
        $this->assertTrue($adapter->validate($ok)['valid']);
    }

    /** FIX-P3-ADP-134: scheduled_time باید canonical و آینده باشد؛ طول‌ها سقف دارند */
    public function test_notification_ad_validate_requires_future_schedule_and_caps_lengths(): void
    {
        $adapter = $this->makeAdAdapter();

        $past = $this->validAdData() + ['scheduled_time' => '2020-01-01 00:00:00'];
        $result = $adapter->validate($past);
        $this->assertFalse($result['valid']);
        $this->assertContains('زمان‌بندی ارسال نوتیفیکیشن باید در آینده باشد.', $result['errors']);

        $badFormat = $this->validAdData() + ['scheduled_time' => 'tomorrow-ish'];
        $this->assertFalse($adapter->validate($badFormat)['valid']);

        $future = date('Y-m-d H:i:s', time() + 86400);
        $ok = $this->validAdData() + ['scheduled_time' => $future];
        $this->assertTrue($adapter->validate($ok)['valid']);

        $longTitle = $this->validAdData();
        $longTitle['title'] = str_repeat('ع', 120);
        $result = $adapter->validate($longTitle);
        $this->assertContains('عنوان نوتیفیکیشن حداکثر ۱۰۰ کاراکتر است.', $result['errors']);
    }

    /** FIX-P3-ADP-135: id <= 0 دیگر success جعل نمی‌کند */
    public function test_notification_ad_create_rejects_invalid_id(): void
    {
        $adModel = m::mock(\App\Models\Ads::class);
        $adModel->shouldReceive('create')->once()->andReturn(0);
        $adapter = $this->makeAdAdapter($adModel);

        $result = $adapter->create(1, $this->validAdData());
        $this->assertFalse($result['success']);
        $this->assertSame('شناسه آگهی ایجادشده نامعتبر است.', $result['message']);
    }

    /** FIX-P3-ADP-136: calculateCost به canonical irt pin می‌شود */
    public function test_notification_ad_calculate_cost_pins_currency_to_irt(): void
    {
        $adapter = $this->makeAdAdapter();
        $expected = Money::fromString('10000', 'irt')->percentage('15')->getAmount();

        $this->assertSame($expected, $adapter->calculateCost('10000', ['currency' => 'usdt']));
        $this->assertSame($expected, $adapter->calculateCost('10000', ['currency' => 'irt']));
    }

    /** FIX-P3-ADP-137: setting 'false' دیگر requires_admin_review=true جعل نمی‌کند */
    public function test_notification_ad_requires_admin_review_parses_boolean_settings(): void
    {
        $captured = [];
        $adModel = m::mock(\App\Models\Ads::class);
        $adModel->shouldReceive('create')->andReturnUsing(function (array $row) use (&$captured) {
            $captured[] = $row;
            return 77;
        });

        $settings = m::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('get')->byDefault()->andReturnUsing(
            static fn(string $key, mixed $default = null) => $default
        );
        $settings->shouldReceive('get')->with('notification_ad_requires_admin_review', 1)->andReturn('false');

        $adapter = $this->makeAdAdapter($adModel, $settings);
        $result = $adapter->create(1, $this->validAdData());
        $this->assertTrue($result['success']);
        $this->assertSame('active', $captured[0]['status'], "string 'false' must parse to false (no review)");

        // و 'true' → pending_review
        $settings2 = m::mock(\App\Services\Settings\AppSettings::class);
        $settings2->shouldReceive('get')->byDefault()->andReturnUsing(
            static fn(string $key, mixed $default = null) => $default
        );
        $settings2->shouldReceive('get')->with('notification_ad_requires_admin_review', 1)->andReturn('true');
        $adapter2 = $this->makeAdAdapter($adModel, $settings2);
        $adapter2->create(1, $this->validAdData());
        $this->assertSame('pending_review', $captured[1]['status']);
    }

    // ─────────────────────── PushNotificationAdapter ───────────────────────

    /** FIX-P3-ADP-121: facade با App\Contracts\LoggerInterface سازگار است */
    public function test_push_adapter_accepts_logger_interface_and_delegates(): void
    {
        $fcmService = m::mock(\App\Services\Notification\FcmService::class);
        $fcmService->shouldReceive('sendToUser')->once()->with(5, 't', 'b', [], null, null)->andReturn(true);
        $fcmService->shouldReceive('sendToTokens')->once()->andReturn(['sent' => 2, 'failed' => 0]);

        $adapter = new PushNotificationAdapter($fcmService, $this->loggerMock());

        $this->assertTrue($adapter->sendToUser(5, 't', 'b'));
        $this->assertSame(['sent' => 2, 'failed' => 0], $adapter->sendToTokens(['tok-1-xxxxxxxxxxxxxxxxx', 'tok-2-xxxxxxxxxxxxxxxxx'], 't', 'b'));
    }
}
