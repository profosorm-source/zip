<?php

namespace Tests\Unit\Adapters;

use PHPUnit\Framework\TestCase;
use App\Adapters\VandarInquiryAdapter;
use Mockery as m;

class VandarInquiryAdapterTest extends TestCase
{
    /** @var \App\Contracts\LoggerInterface&\Mockery\MockInterface */
    private \App\Contracts\LoggerInterface $logger;
    private VandarInquiryAdapter $adapter;

    protected function setUp(): void
    {
        parent::setUp();
        $this->logger = m::mock('App\Contracts\LoggerInterface');
        $this->logger->shouldIgnoreMissing();

        $cache = m::mock('App\Contracts\CacheInterface');
        $circuit = m::mock('App\Contracts\CircuitBreakerInterface');
        $this->adapter = new VandarInquiryAdapter($this->logger, $cache, $circuit);
    }

    protected function tearDown(): void
    {
        // FIX (بهداشت تست): PHPUnit ترتیب اجرای متدها را declaration-order تضمین
        // نمی‌کند — config_setهای این کلاس (services.vandar.*) در store سراسری
        // می‌مانند و تستِ is_configuredِ متعاقب با adapterِ ساخته‌شده روی configِ
        // آلوده (api_token=test-token) شکست می‌خورد. بازگردانی به null (هم‌الگوی
        // tearDownِ P3BankInquiryPinTest) تا نشت حالت بین تست‌ها رخ ندهد.
        if (function_exists('config_set')) {
            foreach (['api_token', 'business', 'base_url', 'timeout'] as $key) {
                config_set('services.vandar.' . $key, null);
            }
        }
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function adapter_can_be_instantiated(): void
    {
        $this->assertInstanceOf(VandarInquiryAdapter::class, $this->adapter);
    }

    /** @test */
    public function is_configured_returns_false_without_credentials(): void
    {
        $this->assertFalse($this->adapter->isConfigured());
    }

    /** @test */
    public function inquire_iban_rejects_invalid_input_without_transport(): void
    {
        $result = $this->adapter->inquireIban('IR123456789012345678901234');
        $this->assertFalse($result['success']);
        $this->assertIsString($result['message']);
        $this->assertStringContainsString('نامعتبر', $result['message']);
    }

    /** @test */
    public function provider_exception_logging_does_not_include_raw_exception_message(): void
    {
        config_set('services.vandar.api_token', 'test-token');
        config_set('services.vandar.business', 'test-business');
        config_set('services.vandar.base_url', 'https://example.com');

        $logger = m::mock('App\\Contracts\\LoggerInterface');
        $context = null;
        $logger->shouldReceive('error')
            ->once()
            ->with('vandar.inquiry.failed', m::on(function (array $value) use (&$context): bool {
                $context = $value;
                return !array_key_exists('error', $value)
                    && ($value['error_type'] ?? null) === \RuntimeException::class;
            }));

        $cache = m::mock('App\\Contracts\\CacheInterface');
        $cache->shouldReceive('get')->once()->andReturn(null);
        $circuit = m::mock('App\\Contracts\\CircuitBreakerInterface');
        $circuit->shouldReceive('call')
            ->once()
            ->andThrow(new \RuntimeException('provider-secret-response'));

        $adapter = new class($logger, $cache, $circuit) extends VandarInquiryAdapter {
            protected function isExternalUrlSafe(string $url, array $allowedHosts = []): bool
            {
                return true;
            }
        };

        $result = $adapter->inquireIban('IR820540102680020817909002');

        $this->assertFalse($result['success']);
        $this->assertIsArray($context);
        $this->assertStringNotContainsString('provider-secret-response', json_encode($context, JSON_THROW_ON_ERROR));
    }
}
