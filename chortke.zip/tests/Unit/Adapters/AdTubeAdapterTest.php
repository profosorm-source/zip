<?php

namespace Tests\Unit\Adapters;

use PHPUnit\Framework\TestCase;
use App\Adapters\AdTubeAdapter;
use Mockery as m;

class AdTubeAdapterTest extends TestCase
{
    /** @var \App\Models\Ads&\Mockery\MockInterface */
    private \App\Models\Ads $adModel;
    /** @var \App\Contracts\LoggerInterface&\Mockery\MockInterface */
    private \App\Contracts\LoggerInterface $logger;
    /** @var \App\Services\Settings\AppSettings&\Mockery\MockInterface */
    private \App\Services\Settings\AppSettings $appSettings;
    /** @var \App\Contracts\ValidatorFactoryInterface&\Mockery\MockInterface */
    private \App\Contracts\ValidatorFactoryInterface $validatorFactory;
    private AdTubeAdapter $adapter;

    protected function setUp(): void
    {
        parent::setUp();
        $this->adModel = m::mock('App\Models\Ads');
        $this->logger = m::mock('App\Contracts\LoggerInterface');
        $this->appSettings = m::mock('App\Services\Settings\AppSettings');
        $this->validatorFactory = m::mock('App\Contracts\ValidatorFactoryInterface');

        $this->logger->shouldIgnoreMissing();
        $this->appSettings->shouldReceive('get')->byDefault()->andReturn(10);

        $this->adapter = new AdTubeAdapter(
            $this->adModel,
            $this->logger,
            $this->appSettings,
            $this->validatorFactory
        );
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function adapter_can_be_instantiated(): void
    {
        $this->assertInstanceOf(AdTubeAdapter::class, $this->adapter);
    }

    /** @test */
    public function get_type_returns_adtube(): void
    {
        $this->assertEquals('adtube', $this->adapter->getType());
    }

    /**
     * نمونهٔ معتبرِ مشترک — 🛡️ FIX-YT-7 (تصمیم ۲-گزینه A): مدت واقعی ویدیو الزامی
     * است (VIDEO_DURATION_MIN..MAX = 10..7200) و هیچ پیش‌فرضی وجود ندارد. نمونه‌های
     * قدیمی بدون این فیلد معتبر نبودند و سه شکست pre-existing می‌دادند (تست زیر +
     * شکل یکنواخت P3 + create-mockery P3) — این چرخه آنها را می‌بندد.
     */
    private function validAdTubeInput(array $overrides = []): array
    {
        return array_merge([
            'title' => 'ویدیو تست یوتیوب',
            'link' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'price_per_task' => 120,
            'total_count' => 100,
            'video_duration_seconds' => 300,
        ], $overrides);
    }

    /** @test */
    public function validate_accepts_valid_youtube_links(): void
    {
        $data = $this->validAdTubeInput();

        $this->appSettings->shouldReceive('get')
            ->with('adtube_min_price_per_view', 100)
            ->once()
            ->andReturn(100);

        $result = $this->adapter->validate($data);

        $this->assertTrue($result['valid']);
        $this->assertEmpty($result['errors']);
    }

    /** @test */
    public function validate_detects_invalid_youtube_links(): void
    {
        // FIX-YT-7: نمونهٔ واجد شرایط (با مدت معتبر) — تا این تست «فقط» خطای لینک را
        // ایزوله کند، نه اینکه به‌خاطر دو خطای هم‌زمان (لینک + مدت غایب) پاس شود.
        $data = $this->validAdTubeInput(['link' => 'https://vimeo.com/12345']);

        $result = $this->adapter->validate($data);

        $this->assertFalse($result['valid']);
        $this->assertContains('لینک وارد شده باید یک لینک معتبر یوتیوب باشد', $result['errors']);
        $this->assertCount(1, $result['errors'], 'تنها خطا باید خطای لینک باشد (مدت از قبل معتبر است)');
    }

    // ────────────────────────────────────────────────────────────────────────
    // 🛡️ FIX-YT-7 (تصمیم ۲-گزینه A) — پین‌های قرارداد مدت واقعی ویدیو
    // ریشهٔ بسته‌شدن این چرخه: کد آداپتر مدت را الزامی کرده بود (بدون پیش‌فرض،
    // 10..7200، ذخیره در metadata) اما هیچ artifact تستی video_duration_seconds
    // نداشت — سه شکست pre-existing (شکل یکنواخت P3 + create-mockery + همین فایل).
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function fix_yt7_validate_requires_video_duration_seconds_without_default(): void
    {
        // حذف فیلد از نمونهٔ معتبر → رد با پیام دقیق (پین «هیچ پیش‌فرضی وجود ندارد»)
        $data = $this->validAdTubeInput();
        unset($data['video_duration_seconds']);

        $result = $this->adapter->validate($data);

        $this->assertFalse($result['valid']);
        $this->assertContains(
            'مدت واقعی ویدیو (ثانیه) الزامی است و باید بین 10 تا 7200 باشد',
            $result['errors']
        );
    }

    /** @test */
    public function fix_yt7_validate_rejects_duration_outside_allowed_bounds(): void
    {
        // مرزهای بیرونی: ۹ (کمتر از حداقل) و 7201 (بیش از حداکثر) → رد
        foreach ([9, 7201] as $badDuration) {
            $result = $this->adapter->validate($this->validAdTubeInput([
                'video_duration_seconds' => $badDuration,
            ]));
            $this->assertFalse($result['valid'], "مدت {$badDuration} ثانیه باید رد شود.");
            $this->assertContains(
                'مدت واقعی ویدیو (ثانیه) الزامی است و باید بین 10 تا 7200 باشد',
                $result['errors']
            );
        }
    }

    /** @test */
    public function fix_yt7_validate_accepts_duration_at_exact_bounds(): void
    {
        // مرزهای درونی: دقیقاً 10 و دقیقاً 7200 → معتبر (پین بازهٔ بستهٔ 10..7200)
        foreach ([10, 7200] as $okDuration) {
            $result = $this->adapter->validate($this->validAdTubeInput([
                'video_duration_seconds' => $okDuration,
            ]));
            $this->assertTrue($result['valid'], "مدت {$okDuration} ثانیه باید معتبر باشد.");
            $this->assertSame($okDuration, (int)$result['data']['video_duration_seconds']);
        }
    }

    /** @test */
    public function fix_yt7_normalize_maps_video_duration_alias_for_backcompat(): void
    {
        // قرارداد normalize(): نام مستعار video_duration هم پذیرفته می‌شود
        $data = $this->validAdTubeInput();
        unset($data['video_duration_seconds']);
        $data['video_duration'] = 240;

        $result = $this->adapter->validate($data);

        $this->assertTrue($result['valid']);
        $this->assertSame(240, (int)$result['data']['video_duration_seconds']);
    }

    /** @test */
    public function fix_yt7_normalize_rejects_malformed_duration_instead_of_clamping(): void
    {
        // ورودی بدشکل (رشتهٔ غیرعددی) → 0 در normalize → رد در validateNormalized
        // (تصمیم ۲-گزینه A: «نه clamp به مقداری دیگر» — پین صریح همین تصمیم)
        foreach (['abc', '', -5] as $garbage) {
            $result = $this->adapter->validate($this->validAdTubeInput([
                'video_duration_seconds' => $garbage,
            ]));
            $this->assertFalse($result['valid'], "ورودی بدشکل «" . var_export($garbage, true) . "» باید رد شود.");
        }
    }

    /** @test */
    public function fix_yt7_create_persists_video_duration_in_ad_metadata(): void
    {
        // قرارداد ذخیره‌سازی: مدت در metadata آگهی JSON می‌نشیند و مسیر اجرا
        // (AdTubeExecutionModel::startView با JSON_EXTRACT) و تسویه
        // (AdsBudgetSettlementService::adtubePerVideoPolicy) از همان metadata می‌خوانند.
        $captured = null;
        $this->adModel->shouldReceive('create')
            ->once()
            ->andReturnUsing(static function (array $payload) use (&$captured) {
                $captured = $payload;
                return (object)['id' => 321];
            });

        $result = $this->adapter->create(7, $this->validAdTubeInput());

        $this->assertTrue($result['success']);
        $this->assertSame(321, (int)$result['data']['ad_id']);
        $this->assertNotNull($captured, 'Ads::create باید دقیقاً یک‌بار فراخوانی شود.');
        $metadata = json_decode((string)($captured['metadata'] ?? ''), true);
        $this->assertIsArray($metadata, 'metadata باید JSON معتبر باشد.');
        $this->assertSame(300, (int)($metadata['video_duration_seconds'] ?? 0), 'مدت واقعی ویدیو باید در metadata ذخیره شود.');
        $this->assertSame('youtube', $metadata['network'] ?? null);
    }
}
