<?php

namespace Tests\Unit\Adapters;

use PHPUnit\Framework\TestCase;
use Mockery as m;

use App\Adapters\AdapterBase;
use App\Adapters\AdSocialAdapter;
use App\Adapters\AdTubeAdapter;
use App\Adapters\BannerAdapter;
use App\Adapters\CustomTaskAdapter;
use App\Adapters\SeoAdAdapter;
use App\Adapters\AdVideoRewardManager;
use App\Adapters\TapsellVideoRewardAdapter;
use App\Adapters\AdVideoRewardPayoutPolicy;

/**
 * پین‌تست‌های موج P3 آداپترهای تبلیغات (FIX-P3-ADP-*).
 * هر تست یک یافتهٔ ممیزی p3fix_ads.json را پین می‌کند:
 *  - ADP-017/019: bounds نرخ/سهم + سیاست قطع payout ویدیویی
 *  - ADP-018/020: HMAC پایدار + trim secret + rate-limit هشدار
 *  - ADP-021: provider پیکربندی‌نشده is_active=false
 *  - ADP-024/067: شکل یکنواخت validate + عدم نشت exception
 *  - ADP-027/028: fraud guard fail-closed / نقشهٔ دامنه‌ای Throwable
 *  - ADP-001/011/002/003, 012/016, 036..042, 064..069, 141..150: validation مرزها
 */
final class P3AdAdaptersPinTest extends TestCase
{
    private \App\Contracts\LoggerInterface $logger;
    /** @var \App\Services\Settings\AppSettings&\Mockery\MockInterface */
    private \App\Services\Settings\AppSettings $settings;
    /** @var \App\Models\Ads&\Mockery\MockInterface */
    private \App\Models\Ads $adModel;

    protected function setUp(): void
    {
        parent::setUp();
        $this->logger = m::mock(\App\Contracts\LoggerInterface::class);
        $this->logger->shouldIgnoreMissing();
        $this->settings = m::mock(\App\Services\Settings\AppSettings::class);
        $this->settings->shouldReceive('get')->byDefault()->andReturn(10);
        $this->settings->shouldReceive('getFloat')->byDefault()->andReturnUsing(
            static fn (string $key, float $default = 0.0): float => $default
        );
        $this->adModel = m::mock(\App\Models\Ads::class);
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-017 / ADP-019 — payout ویدیویی: bounds و سیاست قطع
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function share_percent_above_100_is_clamped_in_payout(): void
    {
        $adapter = $this->makeTapsell(200.0, 150.0);
        // ۲۰۰ × ۱۰۰٪ (نه ۱۵۰٪) = ۲۰۰ تومان — share هرگز بالای ۱۰۰ نمی‌رود.
        $this->assertSame('200', $adapter->calculateUserPayout()->getAmount());
    }

    /** @test */
    public function negative_share_is_clamped_to_zero_payout(): void
    {
        $adapter = $this->makeTapsell(200.0, -30.0);
        $payout = $adapter->calculateUserPayout()->getAmount();
        $this->assertSame('0', $payout);
        $this->assertFalse(str_starts_with($payout, '-'), 'پاداش منفی هرگز نباید تولید شود.');
    }

    /** @test */
    public function non_positive_base_rate_fails_fast_before_bcmul(): void
    {
        $adapter = $this->makeTapsell(0.0, 70.0);
        $this->expectException(\RuntimeException::class);
        $adapter->calculateUserPayout();
    }

    /** @test */
    public function irt_payout_truncates_instead_of_rounding_up(): void
    {
        // ۱۵۰ × ۳۳٫۳۳۳٪ = ۴۹٫۹۹۹۵ → سیاست رسمی: قطع به ۴۹ (نه گرد به ۵۰).
        $adapter = $this->makeTapsell(150.0, 33.333);
        $this->assertSame('49', $adapter->calculateUserPayout()->getAmount());
    }

    /** @test */
    public function usdt_payout_keeps_four_decimal_truncation(): void
    {
        // AdMob: نرخ 0.02 USDT × ۵۰٪ = 0.01 — قطع به ۴ رقم اعشار.
        // FIX-M12-04 (هم‌ترازسازی پین): بازنمایی کانونی Money صفرهای انتهایی را
        // می‌تراشد — '0.0100' → '0.01'؛ مقدار و قطعِ ۴رقمی (FIX-P3-ADP-019)
        // تغییر نکرده، فقط نمایش رشته‌ای است.
        $settings = m::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('getFloat')->andReturnUsing(
            static function (string $key, float $default = 0.0): float {
                return match ($key) {
                    'admob_base_rate_usdt' => 0.02,
                    'admob_user_share' => 50.0,
                    default => $default,
                };
            }
        );
        $settings->shouldReceive('get')->andReturn('');
        require_once dirname(__DIR__, 3) . '/app/Adapters/AdVideoRewardManager.php';
        $adapter = new \App\Adapters\AdMobVideoRewardAdapter($settings, $this->logger);
        $this->assertSame('0.01', $adapter->calculateUserPayout()->getAmount());

        // پین معنای «قطع» (نه گردکردن): 0.0123 × ۵۰٪ = 0.00615 → رقم پنجم
        // حذف می‌شود (truncate = 0.0061؛ گردکردن به بالا 0.0062 می‌داد).
        $settings2 = m::mock(\App\Services\Settings\AppSettings::class);
        $settings2->shouldReceive('getFloat')->andReturnUsing(
            static function (string $key, float $default = 0.0): float {
                return match ($key) {
                    'admob_base_rate_usdt' => 0.0123,
                    'admob_user_share' => 50.0,
                    default => $default,
                };
            }
        );
        $settings2->shouldReceive('get')->andReturn('');
        $adapter2 = new \App\Adapters\AdMobVideoRewardAdapter($settings2, $this->logger);
        $this->assertSame('0.0061', $adapter2->calculateUserPayout()->getAmount(), 'پاداش باید قطع شود نه گرد به بالا');
    }

    /**
     * FIX-P3-ADP-017 — هاب: تنظیمات بی‌معنا → شبکه حذف می‌شود (نه پاداش ساختگی).
     * FIX-P3-ADP-021 — شبکهٔ بدون secret وب‌هوک is_active=false است.
     * @test
     */
    public function hub_excludes_nonsense_settings_and_marks_unconfigured_inactive(): void
    {
        global $configOverrides;
        $previous = is_array($configOverrides ?? null) ? $configOverrides : [];
        try {
            $this->settings->shouldReceive('get')->byDefault()->andReturn('');
            $manager = new AdVideoRewardManager($this->logger, $this->settings);

            // نرخ/سهم پیش‌فرض سالم؛ secret‌ها همه خالی → هیچ شبکه‌ای فعال نیست.
            $ads = $manager->getAvailableRewardAds();
            $this->assertNotEmpty($ads, 'با تنظیمات سالم، هر ۶ شبکه باید لیست شوند.');
            foreach ($ads as $network => $entry) {
                $this->assertFalse($entry['is_active'], "شبکه {$network} بدون secret نباید فعال باشد.");
                $this->assertGreaterThanOrEqual(0.0, $entry['user_share_percent']);
                $this->assertLessThanOrEqual(100.0, $entry['user_share_percent']);
            }

            // پیکربندی تپسل → فقط تپسل فعال.
            $configOverrides = ['services' => ['tapsell' => ['webhook_secret' => 'k1']]];
            $ads2 = $manager->getAvailableRewardAds();
            $this->assertTrue($ads2['tapsell']['is_active']);
            $this->assertFalse($ads2['admob']['is_active']);
        } finally {
            $configOverrides = $previous;
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-020 — HMAC: trim secret + پایداری + rate-limit هشدار
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function hmac_verification_is_stable_with_padded_secret_and_rate_limits_warning(): void
    {
        global $configOverrides;
        $previous = is_array($configOverrides ?? null) ? $configOverrides : [];
        try {
            // secret با فاصلهٔ دورریخته در config — قبل از hash باید trim شود.
            $configOverrides = ['services' => ['tapsell' => ['webhook_secret' => '  test-secret  ']]];

            $logger = m::mock(\App\Contracts\LoggerInterface::class);
            // دو mismatch پشت‌هم → هشدار فقط یک‌بار (rate-limit ۶۰ ثانیه).
            $logger->shouldReceive('warning')->with('tapsell.webhook.hmac_mismatch')->once();
            $logger->shouldIgnoreMissing();

            $settings = m::mock(\App\Services\Settings\AppSettings::class);
            $settings->shouldReceive('get')->andReturn('');
            $adapter = new TapsellVideoRewardAdapter($settings, $logger);

            $raw = '{"user_id":7,"txid":"abc"}';
            $signature = hash_hmac('sha256', $raw, 'test-secret');

            $this->assertTrue($adapter->verifyS2SHmac($raw, $signature), 'امضای محاسبه‌شده با secret پس‌از-trim باید معتبر باشد.');
            $this->assertTrue($adapter->verifyS2SHmac($raw, ' ' . $signature . ' '), 'امضای دریافتی هم trim می‌شود.');
            $this->assertFalse($adapter->verifyS2SHmac($raw, hash_hmac('sha256', $raw, 'other-secret')));
            $this->assertFalse($adapter->verifyS2SHmac($raw, hash_hmac('sha256', $raw . 'x', 'test-secret')));
        } finally {
            $configOverrides = $previous;
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-027 / ADP-028 — fraud guard: fail-closed و نقشهٔ دامنه‌ای
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function missing_fraud_guard_fails_closed_on_money_paths(): void
    {
        $fixture = new class($this->logger, $this->settings, null, null) extends AdapterBase {
            public function getType(): string { return 'p3fixture'; }
            public function validate(array $data, bool $isUpdate = false): array { return ['valid' => true, 'errors' => [], 'data' => $data]; }
            public function check(int $userId): void { $this->assertFraudAllowed($userId, 'p3.test'); }
        };

        $this->expectException(\App\Exceptions\BusinessException::class);
        $fixture->check(7);
    }

    /** @test */
    public function raw_throwable_from_guard_is_mapped_to_business_exception(): void
    {
        $guard = m::mock(\App\Contracts\AntiFraud\FraudGuardInterface::class);
        $guard->shouldReceive('checkAction')->once()->andThrow(new \RuntimeException('guard outage'));

        $fixture = new class($this->logger, $this->settings, null, $guard) extends AdapterBase {
            public function getType(): string { return 'p3fixture'; }
            public function validate(array $data, bool $isUpdate = false): array { return ['valid' => true, 'errors' => [], 'data' => $data]; }
            public function check(int $userId): void { $this->assertFraudAllowed($userId, 'p3.test'); }
        };

        try {
            $fixture->check(7);
            $this->fail('انتظار BusinessException می‌رفت.');
        } catch (\App\Exceptions\BusinessException $e) {
            // FIX-P3-ADP-028: استثنای خام (RuntimeException) مستقیم بیرون نمی‌زند؛
            // به BusinessException دامنه‌ای نقشه می‌خورد و به‌عنوان previous حفظ می‌شود.
            $this->assertNotNull($e->getPrevious());
            $this->assertInstanceOf(\RuntimeException::class, $e->getPrevious());
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-024 / ADP-067 — شکل یکنواخت validate و عدم نشت exception
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function validate_result_shape_is_uniform_across_all_ad_adapters(): void
    {
        foreach ($this->sampleValidInputs() as $type => [$adapter, $data]) {
            $result = $adapter->validate($data);
            $this->assertArrayHasKey('valid', $result, "validate({$type}) باید کلید valid داشته باشد.");
            $this->assertArrayHasKey('errors', $result, "validate({$type}) باید کلید errors داشته باشد.");
            $this->assertArrayHasKey('data', $result, "validate({$type}) باید کلید data داشته باشد (normalize تک‌گذر).");
            $this->assertIsBool($result['valid']);
            $this->assertIsArray($result['errors']);
            $this->assertIsArray($result['data']);
            $this->assertTrue($result['valid'], "ورودی نمونهٔ {$type} باید معتبر باشد: " . json_encode($result['errors'], JSON_UNESCAPED_UNICODE));
        }
    }

    /** @test */
    public function validate_returns_valid_false_instead_of_throwing_on_malformed_money(): void
    {
        // FIX-P3-ADP-067: قیمت با نماد علمی قبلاً InvalidArgumentExceptionِ Money را
        // از validate() بیرون می‌داد؛ اکنون ردّ دامنه‌ای valid=false است.
        $adapter = $this->makeCustomTask();
        $result = $adapter->validate([
            'title' => 'عنوان تستی تسک',
            'description' => 'توضیحات کافی برای شرح تسک سفارشی تست',
            'price_per_task' => '1.0E+25',
            'total_count' => 5,
        ]);
        $this->assertFalse($result['valid']);
        // پیام‌های دامنه‌ایِ دقیق آداپتر (بهتر از پیام عمومی) — نکتهٔ کلیدی: استثنا نشت نمی‌کند
        $this->assertContains('پاداش هر تسک نامعتبر است.', $result['errors']);
        $this->assertContains('پاداش هر تسک کمتر از حداقل مجاز است.', $result['errors']);
    }

    /** @test */
    public function validate_data_helper_treats_missing_valid_key_as_invalid(): void
    {
        // FIX-P3-ADP-024: نتیجهٔ بدشکل (بدون کلید valid) fail-closed است.
        $fixture = new class($this->logger, $this->settings) extends AdapterBase {
            /** @var array<string, mixed> */
            public array $shape = [];
            public function getType(): string { return 'p3fixture'; }
            public function validate(array $data, bool $isUpdate = false): array { return $this->shape; }
            public function callValidateData(array $data): void { $this->validateData($data); }
        };

        try {
            $fixture->shape = ['errors' => []]; // کلید valid غایب
            $fixture->callValidateData([]);
            $this->fail('نتیجهٔ validate بدون کلید valid باید fail-closed باشد.');
        } catch (\Core\Exceptions\ValidationException $e) {
            $this->addToAssertionCount(1);
        }

        $fixture->shape = ['valid' => true, 'errors' => []];
        $fixture->callValidateData([]); // نباید استثنا بدهد
        $this->addToAssertionCount(1);
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-002 / 011 / 064 — گیت خام تعداد (۰/منفی/اعشاری → رد، نه coerce)
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function raw_count_zero_negative_or_fractional_is_rejected_not_coerced_to_one(): void
    {
        $social = $this->makeSocial();
        foreach ([0, '0', -3, '1.5', 'abc', []] as $bad) {
            $result = $social->validate($this->socialInput($bad));
            $this->assertFalse($result['valid'], 'social total_count=' . var_export($bad, true) . ' باید رد شود.');
            $this->assertNotEmpty($result['errors']);
        }
        // and: عدد صحیح رشته‌ای و عددی هردو قبول‌اند.
        $this->assertTrue($social->validate($this->socialInput('100'))['valid']);
        $this->assertTrue($social->validate($this->socialInput(100))['valid']);

        $adtube = $this->makeAdTube();
        $this->assertFalse($adtube->validate($this->adtubeInput('1.5'))['valid']);
        $this->assertFalse($adtube->validate($this->adtubeInput(0))['valid']);

        $custom = $this->makeCustomTask();
        $this->assertFalse($custom->validate($this->customInput(-3))['valid']);
        $this->assertTrue($custom->validate($this->customInput('25'))['valid']);
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-001 / 037 / 065 / 141 — policy لینک‌ها (http/https + هاست)
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function social_link_requires_safe_url_or_handle_form(): void
    {
        $social = $this->makeSocial();
        $this->assertFalse($social->validate($this->socialInput(10, ['link' => 'javascript:alert(1)']))['valid']);
        $this->assertFalse($social->validate($this->socialInput(10, ['link' => 'ftp://files.example.com/x']))['valid']);
        $this->assertFalse($social->validate($this->socialInput(10, ['link' => 'https://user:pass@evil.example.com/x']))['valid']);
        $this->assertTrue($social->validate($this->socialInput(10, ['link' => '@my_handle']))['valid']);
        $this->assertTrue($social->validate($this->socialInput(10, ['link' => 'https://instagram.com/my_page']))['valid']);
    }

    /** @test */
    public function banner_destination_link_rejects_non_http_schemes(): void
    {
        $banner = $this->makeBanner();
        $data = $this->bannerInput(['link' => 'javascript:alert(1)']);
        $result = $banner->validate($data);
        $this->assertFalse($result['valid']);
        $this->assertContains('لینک مقصد معتبر نیست.', $result['errors']);
        $this->assertTrue($banner->validate($this->bannerInput())['valid']);
    }

    /** @test */
    public function custom_task_type_and_link_are_allowlisted(): void
    {
        $custom = $this->makeCustomTask();
        $badType = $custom->validate($this->customInput(10, ['task_type' => 'freeform!!']));
        $this->assertFalse($badType['valid']);
        $this->assertContains('نوع تسک معتبر نیست.', $badType['errors']);

        $badLink = $custom->validate($this->customInput(10, ['link' => 'data:text/html;base64,xxx']));
        $this->assertFalse($badLink['valid']);
        $this->assertContains('لینک هدف معتبر نیست.', $badLink['errors']);

        $ok = $custom->validate($this->customInput(10, ['link' => 'https://example.com/task', 'task_type' => 'register']));
        $this->assertTrue($ok['valid']);
    }

    /** @test */
    public function seo_target_url_is_validated_like_site_url(): void
    {
        $seo = $this->makeSeo();
        $result = $seo->validate($this->seoInput(['target_url' => 'javascript:alert(1)']));
        $this->assertFalse($result['valid']);
        $this->assertContains('آدرس مقصد معتبر نیست.', $result['errors']);
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-036 / 038 — بنر: مسیر تصویر و allowlist دستگاه هدف
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function banner_image_path_rejects_traversal_absolute_and_non_image(): void
    {
        $banner = $this->makeBanner();
        foreach (['../config/secrets.png', '/etc/passwd.png', 'shell.php', 'banners/nope.txt'] as $badPath) {
            $result = $banner->validate($this->bannerInput(['image_path' => $badPath]));
            $this->assertFalse($result['valid'], "مسیر {$badPath} باید رد شود.");
            $this->assertContains('مسیر تصویر بنر معتبر نیست.', $result['errors']);
        }
        $this->assertTrue($banner->validate($this->bannerInput(['image_path' => 'banners/sale.png']))['valid']);
    }

    /** @test */
    public function banner_target_devices_are_allowlisted_and_capped(): void
    {
        $banner = $this->makeBanner();
        // مقدار خارج از allowlist → خطای دامنه‌ای (نه drop خاموش، نه ذخیرهٔ دلخواه).
        $result = $banner->validate($this->bannerInput(['target_devices' => ['web', 'smart-fridge']]));
        $this->assertFalse($result['valid']);
        $this->assertSame(['ورودی ارسالی معتبر نیست.'], $result['errors']);

        // بیش از سقف ۴ مقدار.
        $this->assertFalse($banner->validate($this->bannerInput(['target_devices' => ['web', 'mobile', 'web', 'mobile', 'web']]))['valid']);

        // مقادیر مجاز (case-insensitive) قبول‌اند و canonical می‌شوند.
        $ok = $banner->validate($this->bannerInput(['target_devices' => ['WEB', 'Mobile']]));
        $this->assertTrue($ok['valid']);
        $this->assertSame(['web', 'mobile'], $ok['data']['target_devices']);
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-003 / 041 / 043 — کارمزد clamp [0,100] و بودجه خوش‌فرم
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function banner_fee_percent_is_clamped_to_0_100(): void
    {
        $banner = $this->makeBanner();
        // Mockery اولین با with() برابر را همیشه برمی‌گرداند؛ مقدار متغیر با andReturnUsing
        $fee = 250;
        $this->settings->shouldReceive('get')->with('banner_fee_percent', 12)->andReturnUsing(function () use (&$fee) { return $fee; });
        $result = $banner->validate($this->bannerInput());
        $this->assertTrue($result['valid']);
        $this->assertSame('100', $result['data']['site_commission_percent']);

        $fee = -5;
        $result2 = $banner->validate($this->bannerInput());
        $this->assertSame('0', $result2['data']['site_commission_percent']);
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-016 — calculateCost آداپتر: preflight مبلغ/کارمزد
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function adtube_calculate_cost_rejects_malformed_amounts_as_domain_error(): void
    {
        $adtube = $this->makeAdTube();
        foreach (['1.0E+25', 'abc', '', '-500', '0'] as $bad) {
            try {
                $adtube->calculateCost((string)$bad);
                $this->fail("مبلغ {$bad} باید InvalidArgumentException دامنه‌ای بدهد.");
            } catch (\InvalidArgumentException $e) {
                $this->assertStringNotContainsString('Invalid monetary amount', $e->getMessage(), 'پیام خام Money نباید نشت کند.');
            }
        }
        // مسیر سالم: کارمزد ۱۰٪ (پیش‌فرض mock) روی ۱۰۰۰.
        $this->assertSame('100', $adtube->calculateCost('1000'));
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-012 / 066 — پرچم requires_admin_review: 'false' دیگر truthy نیست
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function review_flag_string_false_is_not_truthy_and_unknown_values_fail_safe(): void
    {
        $adtube = $this->makeAdTube();
        $flag = 'false'; // مقدار متغیر: اول 'false' (بدون بازبینی)، بعد 10 (ناشناخته → fail-safe)
        $this->settings->shouldReceive('get')->with('adtube_requires_admin_review', 0)->andReturnUsing(function () use (&$flag) { return $flag; });
        $this->assertFalse($adtube->validate($this->adtubeInput())['data']['requires_admin_review']);

        $flag = 10;
        $this->assertTrue($adtube->validate($this->adtubeInput())['data']['requires_admin_review'], 'مقدار ناشناخته fail-safe روی نیاز به بازبینی ادمین است.');

        $custom = $this->makeCustomTask();
        $this->settings->shouldReceive('get')->with('custom_task_requires_admin_review', 0)->andReturn('false');
        $this->assertFalse($custom->validate($this->customInput())['data']['requires_admin_review']);
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-040 / 068 / 145 / 006 — id<=0 هرگز «موفقیت» نیست
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function create_with_unavailable_id_returns_failure_not_fake_success(): void
    {
        foreach (['social' => $this->makeSocial(), 'adtube' => $this->makeAdTube(), 'banner' => $this->makeBanner(), 'custom' => $this->makeCustomTask(), 'seo' => $this->makeSeo()] as $type => $adapter) {
            $model = m::mock(\App\Models\Ads::class);
            $model->shouldReceive('create')->once()->andReturn(true); // شکل true مدل: insert بدون ID
            $this->swapModel($adapter, $model);
            $result = $adapter->create(7, $this->sampleFor($type));
            $this->assertFalse($result['success'], "آداپتر {$type} نباید با شناسهٔ ناموجود موفقیت جعل کند.");
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-149 — isExpired سئو: 'completed' هم منقضی
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function seo_is_expired_treats_completed_status_as_expired(): void
    {
        $seo = $this->makeSeo();
        $model = m::mock(\App\Models\Ads::class);
        $model->shouldReceive('find')->once()->andReturn((object)['status' => 'completed', 'remaining_budget' => '50000', 'currency' => 'irt']);
        $this->swapModel($seo, $model);
        $this->assertTrue($seo->isExpired(11));
    }

    // ────────────────────────────────────────────────────────────────────────
    // FIX-P3-ADP-150 — سقف max_payout نسبت به بودجه + طول keyword
    // ────────────────────────────────────────────────────────────────────────

    /** @test */
    public function seo_max_payout_cannot_exceed_total_budget(): void
    {
        $seo = $this->makeSeo();
        $result = $seo->validate($this->seoInput(['max_payout' => '999999999']));
        $this->assertFalse($result['valid']);
        $this->assertContains('حداکثر پرداخت نمی‌تواند از بودجه کل بیشتر باشد.', $result['errors']);

        $longKeyword = $this->seoInput(['keyword' => str_repeat('ک', 101)]);
        $this->assertFalse($seo->validate($longKeyword)['valid']);
    }

    // ────────────────────────────────────────────────────────────────────────
    // Fixtures & helpers
    // ────────────────────────────────────────────────────────────────────────

    private function makeTapsell(float $base, float $share): TapsellVideoRewardAdapter
    {
        $settings = m::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('getFloat')->andReturnUsing(
            static function (string $key, float $default = 0.0) use ($base, $share): float {
                return match ($key) {
                    'tapsell_base_rate_irt' => $base,
                    'tapsell_user_share' => $share,
                    default => $default,
                };
            }
        );
        $settings->shouldReceive('get')->andReturn('');
        // کلاس‌های خویشاوند در همان فایل AdVideoRewardManager.php هستند؛ PSR-4 به‌تنهایی
        // آن‌ها را autoload نمی‌کند — هم‌الگوی FinancialIntegrityTest: require_once اول.
        require_once dirname(__DIR__, 3) . '/app/Adapters/AdVideoRewardManager.php';
        return new TapsellVideoRewardAdapter($settings, $this->logger);
    }

    private function makeSocial(): AdSocialAdapter
    {
        return new AdSocialAdapter($this->adModel, $this->logger, $this->settings, m::mock(\App\Contracts\ValidatorFactoryInterface::class));
    }

    private function makeAdTube(): AdTubeAdapter
    {
        return new AdTubeAdapter($this->adModel, $this->logger, $this->settings, m::mock(\App\Contracts\ValidatorFactoryInterface::class));
    }

    private function makeBanner(): BannerAdapter
    {
        // پرچم بازبینی ادمین باید bool معتبر باشد (هم‌الگوی BannerAdapterTest).
        $this->settings->shouldReceive('get')->with('banner_requires_admin_review', true)->andReturn(true);
        return new BannerAdapter(
            $this->adModel,
            m::mock(\App\Contracts\WalletServiceInterface::class),
            m::mock(\Core\Database::class),
            $this->logger,
            $this->settings,
            m::mock(\App\Contracts\ValidatorFactoryInterface::class),
            m::mock(\App\Services\Shared\IdempotencyService::class),
            m::mock(\App\Services\Ads\AdsBudgetSettlementService::class)
        );
    }

    private function makeCustomTask(): CustomTaskAdapter
    {
        return new CustomTaskAdapter(
            $this->adModel,
            m::mock(\App\Contracts\WalletServiceInterface::class),
            m::mock(\Core\Database::class),
            $this->logger,
            $this->settings,
            m::mock(\App\Contracts\ValidatorFactoryInterface::class)
        );
    }

    private function makeSeo(): SeoAdAdapter
    {
        return new SeoAdAdapter(
            $this->adModel,
            m::mock(\App\Contracts\WalletServiceInterface::class),
            m::mock(\Core\Database::class),
            $this->logger,
            $this->settings,
            m::mock(\App\Contracts\ValidatorFactoryInterface::class),
            m::mock(\App\Services\Shared\IdempotencyService::class)
        );
    }

    /**
     * جایگزینی مدل در آداپترِ ساخته‌شده برای تست مسیر create/isExpired
     * (پیاده‌سازی‌ها private typed property هستند؛ via reflection).
     */
    private function swapModel(object $adapter, object $model): void
    {
        $ref = new \ReflectionClass($adapter);
        foreach (['adModel', 'taskModel'] as $propName) {
            if ($ref->hasProperty($propName)) {
                $prop = $ref->getProperty($propName);
                $prop->setValue($adapter, $model);
                return;
            }
        }
        $this->fail('هیچ پراپرتی مدلی برای swap پیدا نشد.');
    }

    private function socialInput(mixed $count = 100, array $overrides = []): array
    {
        return array_merge([
            'platform' => 'instagram',
            'task_type' => 'follow',
            'title' => 'فالو کنید صفحه را',
            'link' => '@my_handle',
            'price_per_task' => 6000,
            'total_count' => $count,
        ], $overrides);
    }

    private function adtubeInput(mixed $count = 100, array $overrides = []): array
    {
        return array_merge([
            'title' => 'ویدیو تست یوتیوب',
            'link' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'price_per_task' => 120,
            'total_count' => $count,
            // 🛡️ FIX-YT-7 (تصمیم ۲-گزینه A): مدت واقعی ویدیو الزامی است — بدون این
            // فیلد ورودی نمونهٔ adtube در شکل یکنواخت validate رد می‌شد و create()
            // هرگز به Ads::create نمی‌رسید (شکست mockery «called 0 times»).
            'video_duration_seconds' => 300,
        ], $overrides);
    }

    private function customInput(mixed $count = 10, array $overrides = []): array
    {
        return array_merge([
            'title' => 'عنوان تستی تسک',
            'description' => 'توضیحات کافی برای شرح تسک سفارشی تست',
            'price_per_task' => 6000,
            'total_count' => $count,
        ], $overrides);
    }

    private function bannerInput(array $overrides = []): array
    {
        return array_merge([
            'title' => 'بنر تبلیغاتی تخفیف',
            'placement' => 'top_header',
            'image_path' => 'banners/sale.png',
            'link' => 'https://example.com/sale',
            'total_budget' => 500,
        ], $overrides);
    }

    private function seoInput(array $overrides = []): array
    {
        return array_merge([
            'title' => 'بهبود سئو رتبه یک گوگل',
            'site_url' => 'https://mywebsite.com',
            'keyword' => 'آموزش برنامه نویسی',
            'price_per_click' => 150,
            'budget' => 50000,
        ], $overrides);
    }

    /** @return array<string, array{0: AdapterBase, 1: array<string, mixed>}> */
    private function sampleValidInputs(): array
    {
        return [
            'social_task' => [$this->makeSocial(), $this->socialInput()],
            'adtube' => [$this->makeAdTube(), $this->adtubeInput()],
            'banner' => [$this->makeBanner(), $this->bannerInput()],
            'custom_task' => [$this->makeCustomTask(), $this->customInput()],
            'seo' => [$this->makeSeo(), $this->seoInput()],
        ];
    }

    private function sampleFor(string $type): array
    {
        return match ($type) {
            'social' => $this->socialInput(),
            'adtube' => $this->adtubeInput(),
            'banner' => $this->bannerInput(),
            'custom' => $this->customInput(),
            'seo' => $this->seoInput(),
            default => $this->fail('نوع ناشناخته'),
        };
    }
}
