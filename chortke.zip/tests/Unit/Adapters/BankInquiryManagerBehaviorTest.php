<?php

declare(strict_types=1);

namespace Tests\Unit\Adapters;

use App\Adapters\BankInquiryAdapter;
use App\Adapters\BankInquiryManager;
use App\Contracts\LoggerInterface;
use Mockery as m;
use PHPUnit\Framework\TestCase;

final class BankInquiryManagerBehaviorTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    public function test_chain_falls_back_and_stops_after_first_success(): void
    {
        // FIX-P3-ADP-035: named mocks — منیجر اکنون addapters را بر اساس کلاس dedupe
        // می‌کند و m::mock ساده برای هر سه، یک کلاس تولید می‌کند که به‌عنوان تکراری حذف
        // می‌شد. نام‌گذاری مجزا = سه پروایدر مستقل.
        $first=m::namedMock('P3BehaviorChainFirstAdapter', BankInquiryAdapter::class);
        $second=m::namedMock('P3BehaviorChainSecondAdapter', BankInquiryAdapter::class);
        $third=m::namedMock('P3BehaviorChainThirdAdapter', BankInquiryAdapter::class);
        // FIX-P3-ADP-035: منیجر اکنون پیش از fan-out از isConfigured() هر پروایدر
        // می‌پرسد و پروایدر پیکربندی‌نشده را از زنجیره کنار می‌گذارد — پین رفتار جدید.
        $first->shouldReceive('isConfigured')->andReturn(true);
        $second->shouldReceive('isConfigured')->andReturn(true);
        $third->shouldReceive('isConfigured')->andReturn(true);
        $first->shouldReceive('inquireIban')->once()->andReturn(['success'=>false,'message'=>'temporary']);
        $second->shouldReceive('inquireIban')->once()->andReturn(['success'=>true,'owner_name'=>'Owner','bank'=>'Bank']);
        $third->shouldNotReceive('inquireIban');
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $result=(new BankInquiryManager($logger,[$first,$second,$third]))->inquireIban('IR820540102680020817909002');
        $this->assertTrue((bool)$result['success']);
        $this->assertSame('Owner',$result['owner_name']);
    }

    public function test_chain_contains_exception_and_returns_failure_after_all_providers(): void
    {
        // FIX-P3-ADP-035: named mocks — استدلال در تست بالا (dedupe بر اساس کلاس).
        $first=m::namedMock('P3BehaviorFailFirstAdapter', BankInquiryAdapter::class);
        $second=m::namedMock('P3BehaviorFailSecondAdapter', BankInquiryAdapter::class);
        // FIX-P3-ADP-035: همان قرارداد isConfigured برای زنجیرهٔ failover.
        $first->shouldReceive('isConfigured')->andReturn(true);
        $second->shouldReceive('isConfigured')->andReturn(true);
        $first->shouldReceive('inquireIban')->once()->andThrow(new \RuntimeException('network down'));
        $second->shouldReceive('inquireIban')->once()->andReturn(['success'=>false,'message'=>'provider rejected']);
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $result=(new BankInquiryManager($logger,[$first,$second]))->inquireIban('IR820540102680020817909002');
        $this->assertFalse((bool)$result['success']);
        // FIX-R36-W3 (F-A19d-06): پین بازنویسی شد — قرارداد پیام ژنریک R18 اکنون در
        // «مرز منیجر» هم اعمال است: متن خام lastError (جزئیات پروایدر/شبکه) به
        // caller/UI نشت نمی‌کند؛ جزئیات فقط در لاگ ساختاریافته می‌ماند.
        $this->assertStringContainsString('تمامی سرویس‌های استعلام بانکی با خطا مواجه شدند', str_value($result['message'] ?? ''));
        $this->assertStringNotContainsString('provider rejected', str_value($result['message'] ?? ''));
        $this->assertStringNotContainsString('network down', str_value($result['message'] ?? ''));
    }
}
