<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Enums\InteractionType;

class EnumsTest extends TestCase
{
    /** @test */
    public function verify_all_enums_are_defined_correctly(): void
    {
        // 1. InteractionType (Backed Enum)
        $this->assertEquals('rating', InteractionType::RATING->value);
        $this->assertEquals('report', InteractionType::REPORT->value);

        // 🛡️ FIX-S20-DEADFILE: UserStatus و TransactionStatus حذف شدند — هرگز در
        // production پذیرفته نشده بودند (registry واقعی = STATUS_* مدل‌ها + وایت‌لیست
        // 'in:' والیدیتورها) و نسبت به فضای وضعیت واقعی دریفت خورده بودند
        // (locked/locked_2fa/pending در UserStatus وجود نداشت).
        // موج حذف Round 22-A: پین غیبت — فایل‌ها باید حذف‌شده باقی بمانند.
        $this->assertFalse(
            is_file(dirname(__DIR__, 2) . '/app/Enums/UserStatus.php'),
            'UserStatus enum must stay deleted (FIX-S20-DEADFILE / R22-A deletion wave)'
        );
        $this->assertFalse(
            is_file(dirname(__DIR__, 2) . '/app/Enums/TransactionStatus.php'),
            'TransactionStatus enum must stay deleted (FIX-S20-DEADFILE / R22-A deletion wave)'
        );
    }
}
