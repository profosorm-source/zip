<?php

declare(strict_types=1);

namespace Tests\Unit\Helpers;

use PHPUnit\Framework\TestCase;

/**
 * FIX-36/W2-D2 — پین F-A9b-01:
 * هدرهای فورواردشدهٔ Client-IP (CF-Connecting-IP / True-Client-IP / X-Real-IP /
 * X-Forwarded-For) فقط وقتی خوانده می‌شوند که هر دو شرط برقرار باشد:
 *   ① TRUST_PROXY_HEADERS=true صراحتاً در env (پیش‌فرض OFF — ریسک جعل IP)،
 *   ② peer مستقیم (REMOTE_ADDR) در trusted_proxies.
 * پیش‌فرض OFF یعنی بدون opt-in، منبع حقیقت REMOTE_ADDR است و کلاینتِ پشتِ
 * peer معتمدِ غیر-CF (nginx ساده/LB) نمی‌تواند هدر جعل کند.
 */
class ClientIpTrustTest extends TestCase
{
    protected function setUp(): void
    {
        if (!function_exists('get_client_ip')) {
            require_once dirname(__DIR__, 3) . '/helpers/security.php';
        }
        $this->unsetTrustFlag();
    }

    protected function tearDown(): void
    {
        $this->unsetTrustFlag();
        unset(
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_CF_CONNECTING_IP'],
            $_SERVER['HTTP_TRUE_CLIENT_IP'],
            $_SERVER['HTTP_X_REAL_IP'],
            $_SERVER['HTTP_X_FORWARDED_FOR']
        );
        parent::tearDown();
    }

    private function unsetTrustFlag(): void
    {
        global $env;
        unset($env['TRUST_PROXY_HEADERS']);
        putenv('TRUST_PROXY_HEADERS');
        unset($_ENV['TRUST_PROXY_HEADERS']);
        if (isset($_SERVER['TRUST_PROXY_HEADERS'])) {
            unset($_SERVER['TRUST_PROXY_HEADERS']);
        }
    }

    private function enableTrustFlag(): void
    {
        global $env;
        $env['TRUST_PROXY_HEADERS'] = 'true';
    }

    /** کلاینتِ جاعل: پشتِ peer معتمد (127.0.0.1) با هر ۴ هدر جعلی */
    private function spoofRequest(string $remoteAddr = '127.0.0.1'): void
    {
        $_SERVER['REMOTE_ADDR'] = $remoteAddr;
        $_SERVER['HTTP_CF_CONNECTING_IP'] = '203.0.113.9';
        $_SERVER['HTTP_TRUE_CLIENT_IP'] = '203.0.113.10';
        $_SERVER['HTTP_X_REAL_IP'] = '203.0.113.11';
        $_SERVER['HTTP_X_FORWARDED_FOR'] = '198.51.100.7, 203.0.113.12';
    }

    public function testDefaultIsOffForwardedHeadersAreIgnoredEvenFromTrustedPeer(): void
    {
        $this->spoofRequest('127.0.0.1'); // peer معتمد هم هست
        $this->assertSame('127.0.0.1', get_client_ip(), 'بدون TRUST_PROXY_HEADERS، منبع حقیقت REMOTE_ADDR است — جعل هدر بی‌اثر');
    }

    public function testEnabledAndTrustedPeerHonorsForwardedHeaderChain(): void
    {
        $this->enableTrustFlag();
        $this->spoofRequest('127.0.0.1');
        // CF-Connecting-IP اولِ زنجیره است — رفتار دیپلوی CF حفظ می‌شود.
        $this->assertSame('203.0.113.9', get_client_ip());
    }

    public function testEnabledButUntrustedPeerFallsBackToRemoteAddr(): void
    {
        $this->enableTrustFlag();
        $this->spoofRequest('192.0.2.55'); // peer غیرمعتمد
        $this->assertSame('192.0.2.55', get_client_ip(), 'هدرهای فورواردشده از peer غیرمعتمد خوانده نمی‌شوند');
    }

    public function testEnabledChainSkipsTrustedHopsAndReturnsFirstUntrustedIp(): void
    {
        $this->enableTrustFlag();
        $_SERVER['REMOTE_ADDR'] = '127.0.0.1';
        $_SERVER['HTTP_X_FORWARDED_FOR'] = '203.0.113.9, 127.0.0.1'; // راست‌به‌چپ: 127.0.0.1 trusted hop → IP واقعی
        unset($_SERVER['HTTP_CF_CONNECTING_IP'], $_SERVER['HTTP_TRUE_CLIENT_IP'], $_SERVER['HTTP_X_REAL_IP']);
        $this->assertSame('203.0.113.9', get_client_ip());
    }

    public function testInvalidRemoteAddrFallsBackToZero(): void
    {
        unset($_SERVER['REMOTE_ADDR']);
        $this->assertSame('0.0.0.0', get_client_ip(), 'بدون REMOTE_ADDR معتبر (CLI) → 0.0.0.0 (مستند)');
    }
}
