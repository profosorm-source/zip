<?php

declare(strict_types=1);

namespace Tests\Unit\Helpers;

use PHPUnit\Framework\TestCase;

/**
 * FIX-36/W2-D2 — پین F-A24a-01:
 * escaper کانونی e() باید نسخهٔ «قوی» باشد: ENT_QUOTES|ENT_SUBSTITUTE به‌عنوان
 * پیش‌فرض + پارامتر اختیاری flags/encoding.
 *
 * ریشهٔ باگ: functions.php در composer files لود می‌شود و بلوک لِیزی آن در
 * همان لحظه view_helper.php را require می‌کند؛ پس تعریف e() در functions.php
 * (گات function_exists) هرگز برنده نمی‌شود — تعریفِ برنده همیشه view_helper است.
 * فیکس: ارتقای «تعریف برنده» به کانونیک (و هم‌امضا کردن هر دو برای پوشش
 * سناریوهای لود وارونه). ورودی UTF-8 نامعتبر باید U+FFFD بدهد نه '' خاموش.
 */
class CanonicalEscapeTest extends TestCase
{
    public function testRuntimeWinnerOfEIsViewHelperDefinition(): void
    {
        $ref = new \ReflectionFunction('e');
        $this->assertSame(
            'view_helper.php',
            basename($ref->getFileName()),
            'e() runtime winner must be helpers/view_helper.php (lazy-require order proves functions.php definition is dead)'
        );
    }

    public function testCanonicalSignatureHasOptionalFlagsAndEncoding(): void
    {
        $ref = new \ReflectionFunction('e');
        $params = $ref->getParameters();

        $this->assertCount(3, $params, 'e($value, $flags, $encoding) — signature-compatible with functions.php contract');

        $this->assertTrue($params[1]->isDefaultValueAvailable());
        $flags = $params[1]->getDefaultValue();
        $this->assertSame(\ENT_QUOTES | \ENT_SUBSTITUTE, $flags, 'پیش‌فرض کانونیک: ENT_QUOTES|ENT_SUBSTITUTE');

        $this->assertTrue($params[2]->isDefaultValueAvailable());
        $this->assertSame('UTF-8', $params[2]->getDefaultValue());
    }

    public function testInvalidUtf8IsSubstitutedNotSilentlyEmptied(): void
    {
        // پیش از فیکس: e("bad\xFF<x>") = '' (data-loss خاموش بدون ENT_SUBSTITUTE)
        $out = e("bad\xFF<x>");
        $this->assertNotSame('', $out, 'ورودی UTF-8 نامعتبر نباید بی‌صدا به رشتهٔ خالی تبدیل شود');
        $this->assertStringContainsString("\xEF\xBF\xBD", $out, 'بایت نامعتبر باید به U+FFFD (EF BF BD) سابستیتوت شود');
        $this->assertSame("bad\xEF\xBF\xBD&lt;x&gt;", $out);
    }

    public function testDefaultFlagsEscapeBothQuoteTypes(): void
    {
        $this->assertSame('&quot;x&quot;', e('"x"'), 'ENT_QUOTES default — دابل‌کوتیشن escape می‌شود');
        $this->assertSame('&#039;x&#039;', e("'x'"), 'ENT_QUOTES default — تک‌کوتیشن escape می‌شود');
        $this->assertSame('&lt;b&gt;ok&lt;/b&gt;', e('<b>ok</b>'));
    }

    public function testExplicitFlagsParameterIsHonored(): void
    {
        $this->assertSame('&lt;b&gt;"x"&lt;/b&gt;', e('<b>"x"</b>', \ENT_NOQUOTES), 'پارامتر flags اختیاری کار می‌کند');
    }

    public function testScalarCoercionViaStrValue(): void
    {
        $this->assertSame('123', e(123));
        $this->assertSame('', e(null));
        $this->assertSame('1', e(true));
    }
}
