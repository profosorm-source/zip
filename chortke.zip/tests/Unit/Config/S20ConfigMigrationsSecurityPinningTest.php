<?php

declare(strict_types=1);

namespace Tests\Unit\Config;

use PHPUnit\Framework\TestCase;

/**
 * S20 — قفل‌کنندهٔ امنیتی لایهٔ Config/Migrations (۱۹ فایل config + ۲۲ مایگریشن —
 * ۴٬۰۷۹ خط، خط‌به‌خط).
 *
 * پین‌کردن ناورداهای بچ S20:
 *  ① FIX-S20-1: rate_limits.php فاقد کلیدهای تکراری است (بلوک‌های سایه‌شدهٔ
 *     score/social_account/message/search حذف شدند) — ویرایش هر کلید همیشه مؤثر است.
 *  ② FIX-S20-2: defaultهای ساختگیِ مرده حذف شدند — encryption.message_keys و
 *     feature_flags.api_key بدون env صریح = خالی (ضد تلهٔ مصرف‌کنندهٔ آینده).
 *  ③ FIX-S20-3: seed_initial_data در production بدون ADMIN_EMAIL/ADMIN_PASSWORD
 *     هرگز حساب‌های 123456 نمی‌سازد (فقط محیط غیر-production).
 *  ④ نقشهٔ RBAC ادمین: هر controller@action استفاده‌شده در روت‌های ادمین یا نگاشت
 *     دارد یا در فهرست بستهٔ «عمداً نگاشت‌نشده/خارج از گارد» پین‌شده است —
 *     اضافه‌شدن روت ادمینِ جدیدِ نگاشت‌نشده تست را می‌شکند (تصمیم آگاهانه اجباری).
 *  ⑤ مایگریشن‌ها: صفر توکن اجرای خطرناک + گارد regex نام‌جدول در seeder +
 *     پین پیش‌فرض امن scopes='read' (X350) + secret وب‌هوک fail-closed.
 */
final class S20ConfigMigrationsSecurityPinningTest extends TestCase
{
    private const ROOT = __DIR__ . '/../../..';

    private function read(string $relative): string
    {
        return (string)file_get_contents(self::ROOT . '/' . $relative);
    }

    /** ① FIX-S20-1 — هر کلید top-level حساس دقیقاً یک‌بار تعریف شده است */
    public function testRateLimitsHasNoShadowedDuplicateKeys(): void
    {
        $src = $this->read('config/rate_limits.php');

        // شمارش در سطح تورفتگی ۴-فاصله (کلید top-level آرایهٔ return)
        foreach (['score', 'social_account', 'message', 'search', 'two_factor', 'payment', 'admin'] as $key) {
            $count = preg_match_all('/^    \'' . $key . '\' =>/m', $src);
            $this->assertSame(
                1,
                $count,
                "کلید top-level '{$key}' باید دقیقاً یک‌بار تعریف شود (یافته‌شده: {$count})"
            );
        }

        // بخش two_factor واقعی با recovery_code سخت‌گیرانه موجود است
        $this->assertStringContainsString("'recovery_code' =>", $src, 'سقف اختصاصی کد بازیابی (MEDIUM-M-14) باید پابرجا باشد');
        $this->assertStringContainsString("'fail_closed' => true", $src, 'سقف‌های payment باید fail-closed باشند');
    }

    /** ② FIX-S20-2 — defaultهای ساختگیِ کلیدهای مرده خنثی شده‌اند */
    public function testDeadKeyDefaultsAreDefused(): void
    {
        $config = $this->read('config/config.php');
        $flags = $this->read('config/feature_flags.php');

        $this->assertStringContainsString("env('MESSAGE_ENCRYPTION_KEY_V1', '')", $config, 'کلید پیام بدون env = خالی (fail-closed برای مصرف‌کنندهٔ آینده)');
        $this->assertStringNotContainsString('strong_message_enc_key', $config, 'کلید ساختگی هاردکد باید حذف شده باشد');

        $this->assertStringContainsString("env('FEATURE_FLAG_API_KEY', '')", $flags, 'api_key فلگ‌ها بدون env = خالی');
        $this->assertStringNotContainsString('FF_SECURE_KEY_REQUIRED', $flags, 'ساختگیِ ظاهراً-قوی باید حذف شده باشد');
    }

    /** ③ FIX-S20-3 — seed کاربران در production بدون اعتبار اپراتور ممنوع */
    public function testSeedUsersAreProductionGated(): void
    {
        $seed = $this->read('database/migrations/2026_06_16_0005_seed_initial_data.php');

        $this->assertStringContainsString("if (\$appEnv === 'production') {", $seed, 'گارد production در شاخهٔ seed پیش‌فرض');
        $this->assertStringContainsString('PRODUCTION بدون ADMIN_EMAIL/ADMIN_PASSWORD', $seed, 'هشدار fail-visible اپراتور');

        // ساخت رمز 123456 باید «بعد از» گاردهای غیر-production باشد
        $guardPos = strpos($seed, "if (\$appEnv !== 'production')");
        $guard2Pos = strpos($seed, "if (\$appEnv === 'production')");
        $this->assertNotFalse($guardPos, 'گارد شاخهٔ اعتبار سفارشی');
        $this->assertNotFalse($guard2Pos, 'گارد شاخهٔ seed پیش‌فرض');
        $lastHashPos = strrpos($seed, "password_hash('123456'");
        $this->assertNotFalse($lastHashPos);
        $this->assertGreaterThan($guard2Pos, $lastHashPos, 'ساخت رمز پیش‌فرض باید داخل گارد غیر-production باشد');

        // گارد تزریق نام‌جدول در shouldSeed
        $this->assertStringContainsString("preg_match('/^[a-zA-Z0-9_]+\$/', \$table)", $seed, 'نام جدول seeder باید whitelist-regex داشته باشد');
    }

    /** ④ نقشهٔ RBAC — کامل در برابر روت‌های فعلی یا پینِ بستهٔ استثناها */
    public function testAdminRbacMapCoversRoutesOrMatchesDocumentedExceptions(): void
    {
        $root = self::ROOT;
        $src = '';
        foreach (['routes/admin.php', 'routes/missing.php', 'routes/system.php'] as $f) {
            $src .= (string)file_get_contents($root . '/' . $f) . "\n";
        }

        // aliasهای فضای Admin
        $aliasMap = [];
        if (preg_match_all('/^use\s+App\\\\Controllers\\\\Admin\\\\(\w+)(?:\s+as\s+(\w+))?\s*;/m', $src, $m, PREG_SET_ORDER)) {
            foreach ($m as $x) {
                $aliasMap[$x[2] ?? $x[1]] = $x[1];
            }
        }
        if (preg_match_all('/App\\\\Controllers\\\\Admin\\\\(\w+)::class/', $src, $m2)) {
            foreach ($m2[1] as $real) {
                $aliasMap[$real] = $real;
            }
        }

        // مصرف‌ها
        $used = [];
        if (preg_match_all("/\[([\w\\\\]+)::class,\s*'(\w+)'\]/", $src, $m3, PREG_SET_ORDER)) {
            foreach ($m3 as $x) {
                $token = ltrim($x[1], '\\');
                if (!isset($aliasMap[$token])) {
                    continue; // فقط کنترلرهای ادمین
                }
                $used[$aliasMap[$token] . '@' . $x[2]] = true;
            }
        }

        /** @var array<string, mixed> $perm */
        $perm = require $root . '/config/admin_permissions.php';

        // استثناهای پین‌شده: خارج از گارد RBAC (ورود عمومی/گیت محیطی/گیت IP-token)
        $guardExempt = ['AuthController', 'DebugController', 'MetricsController'];
        // رکورد S19: ۱۶ اکشن عمداً نگاشت‌نشده (فقط super_admin — fail-closed)؛
        // افزودن نگاشت جدید = تصمیم محصولی و باید این پین را به‌روز کند.
        // به‌روزرسانی پین (S27 — FIX بچ سرویس‌های زیرسیستم): سه اکشن
        // FraudReportsAdminController (index/review/dismiss) از «عمداً نگاشت‌نشده»
        // خارج و به گارد sentry.view/sentry.manage نگاشت شدند (ردیف‌های ۸۴۸ worklog).
        $knownUnmapped = [
            // FIX-R36-W4: ApiTokenAdminController@renew به فهرست عمداً نگاشت‌نشده
            // پیوست (فقط super_admin — fail-closed)؛ تمدید ۹۰ روزهٔ توکن API از
            // مسیر تصمیم محصولی W4-E است و نگاشت نقشِ جدیدی معرفی نمی‌کند.
            'ApiTokenAdminController@index', 'ApiTokenAdminController@renew', 'ApiTokenAdminController@revoke', 'ApiTokenAdminController@revokeExpired',
            'CacheAdminController@clear', 'CacheAdminController@forget', 'CacheAdminController@index', 'CacheAdminController@resetCircuitBreaker',
            'CronController@index', 'CronController@run',
            'EmailQueueController@index', 'EmailQueueController@process', 'EmailQueueController@retry', 'EmailQueueController@retryFailed',
        ];

        $unmapped = [];
        foreach (array_keys($used) as $key) {
            [$ctrl, $method] = explode('@', $key);
            if (in_array($ctrl, $guardExempt, true)) {
                continue;
            }
            if (isset($perm[$ctrl])) {
                $this->assertArrayHasKey('default', $perm[$ctrl], "کنترلر نگاشت‌شده باید default داشته باشد: {$ctrl}");
                continue;
            }
            $unmapped[] = $key;
        }

        sort($unmapped);
        $this->assertSame(
            $knownUnmapped,
            $unmapped,
            'فهرست اکشن‌های عمداً نگاشت‌نشده (fail-closed) تغییر کرده — پین S20 را آگاهانه به‌روز کنید'
        );
    }

    /** ⑤ مایگریشن‌ها: صفر توکن خطرناک + پین پیش‌فرض امن scopes */
    public function testMigrationsAreCleanAndLeastPrivilegePinned(): void
    {
        $forbidden = ['eval(', 'system(', 'shell_exec', 'passthru', 'proc_open', 'popen(', 'unserialize('];
        $violations = [];

        $dir = self::ROOT . '/database/migrations';
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir)) as $fileInfo) {
            if ($fileInfo->getExtension() !== 'php') {
                continue;
            }
            $content = (string)file_get_contents($fileInfo->getPathname());
            foreach ($forbidden as $token) {
                if (strpos($content, $token) !== false) {
                    $violations[] = $fileInfo->getFilename() . ' => ' . $token;
                }
            }
            // دسترسی مستقیم سوپرگلوبال ورودی در مایگریشن بی‌معناست
            foreach (['$_GET[', '$_POST[', '$_REQUEST['] as $sg) {
                if (strpos($content, $sg) !== false) {
                    $violations[] = $fileInfo->getFilename() . ' => ' . $sg;
                }
            }
        }
        $this->assertSame([], $violations, 'توکن خطرناک در مایگریشن‌ها: ' . "\n" . implode("\n", $violations));

        // X350: پیش‌فرض امن scopes (حداقل دسترسی) پین می‌شود
        $scopes = $this->read('database/migrations/2026_09_12_0001_api_token_scopes_default_read.php');
        $this->assertStringContainsString("SET DEFAULT 'read'", $scopes, 'مهاجرت از وایلدکارد * به read باید پابرجا باشد');
        $this->assertStringContainsString("current !== '*'", $scopes, 'مهاگریتن فقط از * اجرا می‌شود (idempotent)');

        // secret وب‌هوک: بدون env = null (سیستم webhook را رد می‌کند)
        $webhook = $this->read('config/webhook.php');
        $this->assertStringContainsString("env('WEBHOOK_SECRET', null)", $webhook, 'secret وب‌هوک نباید default داشته باشد');
    }

    /**
     * ⑥ W4-B (F-A24c-04) — صفرِ فراخوانی زندهٔ exit() در مایگریشن‌های PHP.
     *
     * مایگریشن‌ها in-process از داخل MigrationService::runMigrations() include
     * می‌شوند؛ exit()/die() درون آن‌ها یعنی مرگ کل پروسه (CLI دیمون/HTTP FPM)
     * و شکستن قرارداد fail-loud (الگوی صحیح: throw new RuntimeException(...)).
     *
     * تشخیص با tokenizer انجام می‌شود نه strpos خام: کامنت‌های تاریخیِ
     * FIX-S19-3 («exit() درون مایگریشن = مرگ کل پروسه») عمداً حاوی رشتهٔ
     * «exit()» هستند و نباید false-positive بسازند؛ T_EXIT فقط توکنِ زنده است.
     * هر T_EXIT (چه «exit(...)» و چه «exit;» و چه die) تخلف شمرده می‌شود.
     */
    public function testNoLiveExitCallsInMigrations(): void
    {
        $violations = [];
        $scanned = 0;

        $dir = self::ROOT . '/database/migrations';
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir));
        foreach ($files as $fileInfo) {
            /** @var \SplFileInfo $fileInfo */
            if ($fileInfo->getExtension() !== 'php') {
                continue;
            }
            $scanned++;
            $path = $fileInfo->getPathname();
            $tokens = token_get_all((string)file_get_contents($path));

            foreach ($tokens as $index => $token) {
                if (!is_array($token) || $token[0] !== T_EXIT) {
                    continue;
                }
                $line = $token[2];
                // شیوهٔ فراخوانی صرفاً برای پیامِ خطا: آیا «(» بلافاصله می‌آید؟
                $kind = 'bare exit/die';
                for ($j = $index + 1, $n = count($tokens); $j < $n; $j++) {
                    $next = $tokens[$j];
                    $nextText = is_array($next) ? $next[1] : $next;
                    if (is_array($next) && in_array($next[0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) {
                        continue;
                    }
                    if ($nextText === '(') {
                        $kind = 'exit(...)';
                    }
                    break;
                }
                $violations[] = $fileInfo->getFilename() . ':' . $line . ' => ' . $kind;
            }
        }

        $this->assertGreaterThan(0, $scanned, 'پوشش اسکن باید حداقل یک فایل PHP مایگریشن باشد');
        $this->assertSame(
            [],
            $violations,
            'فراخوانی زندهٔ exit()/die در مایگریشن‌ها ممنوع است (in-process include) — به‌جای آن RuntimeException پرتاب کنید:' . "\n" . implode("\n", $violations)
        );
    }
}
