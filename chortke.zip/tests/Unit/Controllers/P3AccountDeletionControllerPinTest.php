<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers;

use App\Controllers\Admin\AccountDeletionManagementController;
use Core\Response;
use Core\Session;
use Core\Exceptions\HttpResponseException;
use Mockery;
use PHPUnit\Framework\TestCase;

/**
 * P3 pin suite — AccountDeletionManagementController (task p3-cmd).
 *
 * Pins the behaviors fixed/kept by FIX-P3-CMD-172 / FIX-P3-CMD-174 and the
 * earlier CMD-round contracts this controller relies on (FIX-CMD168..171,
 * FIX-18Q, FIX-S16-2):
 *
 *  ① Pagination caps  — pending/history clamp the request limit (500/250) with
 *     page floor 1 and offset = (page-1)*clamped-limit; stats/getStats fetch
 *     with the fixed 500 cap (never unbounded).
 *  ② Throwable guards — TypeError/Error/AssertionError in any action become a
 *     *generic* user-visible message; the raw exception text only reaches the
 *     structured logger (FIX-P3-CMD-174), while HttpResponseException from
 *     successful view()/redirect() is still re-thrown, never swallowed (FIX-18Q):
 *     success flashes are not overwritten by the widened catch.
 *  ③ PII envelope     — getUserDetails masks full_name for non-super_admin
 *     callers (FIX-P3-CMD-172), keeps the reason super_admin-only policy
 *     (CMD-173, deliberate REJECT), caps username/full_name length
 *     (multibyte-safe), and keeps one {success, error|data} envelope on both
 *     JSON endpoints (missing id / not-found / 500 all share the shape).
 *  ④ Honest stats     — expiring_soon counts only rows expiring in (0, 24h]
 *     (expired / unparsable / non-string / missing excluded — FIX-CMD170),
 *     rows may be objects OR arrays (type guard), total_data_size stays the
 *     documented ~1MB/user estimate (FIX-CMD171).
 *
 * NOTE: this controller has no export action, no json_decode of stored
 * payloads and no money/KPI figures — the export-guard / JSON-decode-guard /
 * decimal-string-money categories of the p3 brief have no counterpart in this
 * file and are therefore not pinned (see worklog p3-cmd).
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class P3AccountDeletionControllerPinTest extends TestCase
{
    /** @var array<string, list<array{0:string,1:mixed}>> captured log calls by level */
    private array $logs = [];

    /** @var array<string, mixed> captured flash messages by key */
    private array $flash = [];

    protected function tearDown(): void
    {
        Mockery::close();
        // session state cleanup (SessionTest house pattern) — tests run in
        // isolated processes, this only protects the isolated child itself.
        if (session_status() === PHP_SESSION_ACTIVE) {
            @session_unset();
            @session_destroy();
        }
        $_SESSION = [];
        $ref = new \ReflectionClass(Session::class);
        $instance = $ref->getProperty('instance');
        if (PHP_VERSION_ID < 80100) {
            $instance->setAccessible(true);
        }
        $instance->setValue(null, null);
        parent::tearDown();
    }

    // ------------------------------------------------------------------
    // ① Pagination caps (pending/history) + Throwable → generic flash
    // ------------------------------------------------------------------

    public function testPendingCapsLimitTo500OffsetsPageOneAndNeverLeaksExceptionToUser(): void
    {
        $captured = [];
        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('getPendingDeletions')
            ->once()
            ->andReturnUsing(static function (int $limit, int $offset) use (&$captured): array {
                $captured = [$limit, $offset];
                throw new \TypeError('DB creds mysql://root:secret@10.0.0.9 leaked');
            });

        $controller = $this->makeController(
            requestInts: ['limit' => 100000, 'page' => 1],
            deletionLogModel: $model
        );

        try {
            $controller->pending();
            self::fail('HttpResponseException (redirect) was expected');
        } catch (HttpResponseException $e) {
            self::assertStringEndsWith('/admin/dashboard', (string)$e->getResponse()->getHeader('Location'));
        }

        // FIX-CMD169 contract: limit clamped to [1, 500], page floor 1 → offset 0
        self::assertSame([500, 0], $captured, 'pending must clamp limit to 500 and page to floor 1');
        // generic user-visible message — raw exception text must not leak
        self::assertSame('خطا: دریافت درخواست‌های معلق ناموفق بود', $this->flash['error'] ?? null);
        self::assertStringNotContainsString('secret', (string)($this->flash['error'] ?? ''));
        // house contract: full detail goes to the structured log, not the UI
        $this->assertLogged('error', 'admin.account_deletion.pending.failed', 'secret');
    }

    public function testHistoryCapsLimitTo250AndOffsetsSecondPage(): void
    {
        $captured = [];
        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('getDeletedAccounts')
            ->once()
            ->andReturnUsing(static function (int $limit, int $offset) use (&$captured): array {
                $captured = [$limit, $offset];
                throw new \Error('history query internals secret');
            });

        $controller = $this->makeController(
            requestInts: ['limit' => 99999, 'page' => 2],
            deletionLogModel: $model
        );

        try {
            $controller->history();
            self::fail('HttpResponseException (redirect) was expected');
        } catch (HttpResponseException $e) {
            self::assertStringEndsWith('/admin/dashboard', (string)$e->getResponse()->getHeader('Location'));
        }

        self::assertSame([250, 250], $captured, 'history limit must clamp to 250; page 2 offset = clamped limit');
        self::assertSame('خطا: دریافت تاریخچه ناموفق بود', $this->flash['error'] ?? null);
        $this->assertLogged('error', 'admin.account_deletion.history.failed', 'secret');
    }

    public function testStatsFetchKeepsFixed500CapAndThrowableBecomesGenericFlash(): void
    {
        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        // S7-FIX (UI-DEL-002, هم‌ترازسازی تست): مسیر stats() دیگر ردیف‌های
        // سقف‌دار ۵۰۰تایی نمی‌کشد — شمارش‌های دقیق COUNT(*) از مدل می‌آید؛
        // شکست مدل باید همان قرارداد fail-safe قبلی را بدهد (فلش عمومی +
        // redirect + لاگ با جزئیات).
        $model->shouldReceive('countPendingDeletions')
            ->once()
            ->andThrow(new \TypeError('raw pdo dsn must not reach the admin UI'));

        $controller = $this->makeController(requestInts: [], deletionLogModel: $model);

        try {
            $controller->stats();
            self::fail('HttpResponseException (redirect) was expected');
        } catch (HttpResponseException $e) {
            self::assertStringEndsWith('/admin/dashboard', (string)$e->getResponse()->getHeader('Location'));
        }

        self::assertSame('خطا: دریافت آمار ناموفق بود', $this->flash['error'] ?? null);
        self::assertStringNotContainsString('pdo', (string)($this->flash['error'] ?? ''));
        $this->assertLogged('error', 'admin.account_deletion.stats.failed', 'raw pdo dsn');
    }

    // ------------------------------------------------------------------
    // ④ Honest stats + consistent JSON envelope (getStats)
    // ------------------------------------------------------------------

    public function testGetStatsEnvelopeCountsAndExpiringSoonWindowIsHonest(): void
    {
        // S7-FIX (UI-DEL-002, هم‌ترازسازی تست): شمارش‌های دقیق از مدل می‌آیند —
        // کنترلر پا‌س‌through صادقانه است؛ «صداقت پنجرهٔ expiring_soon» (فقط
        // (۰..۲۴h] آینده، status=requested، expires_at ناتهی) اکنون در SQLِ
        // AccountDeletionLog::countExpiringSoon زندگی می‌کند و در تست مدل
        // (AccountDeletionLogCountsTest) مستقیماً پین می‌شود.
        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('countPendingDeletions')->once()->andReturn(5);
        $model->shouldReceive('countDeletedAccounts')->once()->andReturn(2);
        $model->shouldReceive('countExpiringSoon')->once()->andReturn(1);

        $controller = $this->makeController(requestInts: [], deletionLogModel: $model);
        $payload = $this->captureJson(static fn () => $controller->getStats());

        // consistent envelope: success flag + data under a named key
        self::assertTrue($payload['success']);
        self::assertArrayHasKey('stats', $payload);
        self::assertSame(5, $payload['stats']['pending_count']);
        self::assertSame(2, $payload['stats']['deleted_count']);
        // FIX-CMD170: پنجرهٔ (۰..۲۴h] — مقدار مدل بدون تحریف عبور می‌کند
        self::assertSame(1, $payload['stats']['expiring_soon']);
        // FIX-CMD171: تخمین مستند ~۱MB/کاربر → (5+2)MB
        self::assertSame('7 MB', $payload['stats']['total_data_size']);
    }

    public function testGetStatsThrowableReturnsGenericJsonError(): void
    {
        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('countPendingDeletions')
            ->once()
            ->andThrow(new \Error('uncaught error detail must stay out of JSON'));

        $controller = $this->makeController(requestInts: [], deletionLogModel: $model);
        $payload = $this->captureJson(static fn () => $controller->getStats());

        self::assertFalse($payload['success']);
        self::assertSame('خطا: دریافت آمار ناموفق', $payload['error']);
        $this->assertLogged('error', 'admin.account_deletion.get_stats.failed', 'uncaught error detail');
    }

    // ------------------------------------------------------------------
    // ③ getUserDetails — envelope, PII masking, length caps, CMD-173 policy
    // ------------------------------------------------------------------

    public function testGetUserDetailsMissingUserIdUsesSameEnvelope(): void
    {
        $controller = $this->makeController(requestInts: ['user_id' => 0]);
        $payload = $this->captureJson(static fn () => $controller->getUserDetails());

        // envelope consistency with the other error paths (success + error keys)
        self::assertFalse($payload['success']);
        self::assertSame('شناسه کاربر الزامی است', $payload['error']);
    }

    public function testGetUserDetailsMasksFullNameAndReasonForNonSuperAdmin(): void
    {
        $controller = $this->makeController(
            requestInts: ['user_id' => 7],
            targetUser: (object)[
                'id' => 7,
                'email' => 'ali@example.com',
                'mobile' => '09121234567',
                'national_id' => '1234567890',
                'full_name' => 'Ali Test',
                'username' => 'ali',
                'created_at' => '2026-01-01 00:00:00',
                'last_activity_at' => '2026-01-02 00:00:00',
            ],
            deletion: (object)[
                'requested_at' => '2026-01-01 00:00:00',
                'expires_at' => '2026-01-08 00:00:00',
                'status' => 'requested',
                'reason' => 'کاربر درخواست حذف داده است',
            ]
        );

        $payload = $this->captureJson(static fn () => $controller->getUserDetails());

        self::assertTrue($payload['success']);
        // FIX-P3-CMD-172: full_name is no longer raw for non-super_admin callers
        self::assertSame('A***', $payload['user']['full_name']);
        // username is a public handle — stays raw (pinned deliberately)
        self::assertSame('ali', $payload['user']['username']);
        // CMD-173 (deliberate REJECT policy): reason stays super_admin-only
        self::assertSame('HIDDEN', $payload['deletion']['reason']);
        self::assertSame('a***@example.com', $payload['user']['email']);
        self::assertSame('0912***67', $payload['user']['mobile']);
        // PII access audit stays in place
        $this->assertLogged('warning', 'admin.pii.accessed', 'get_user_details_for_deletion');
    }

    public function testGetUserDetailsRevealsFullNameAndReasonForSuperAdmin(): void
    {
        $this->withSessionUser(9);

        $superAdmin = (object)['id' => 9, 'role' => 'super_admin'];
        $service = Mockery::mock(\App\Services\User\UserService::class);
        $service->shouldReceive('find')->once()->with(7)->andReturn((object)[
            'id' => 7,
            'email' => 'ali@example.com',
            'full_name' => 'Ali Test',
            'username' => 'ali',
        ]);
        // auth() resolves the current admin through the container, not the property —
        // swap the container binding (tests run in isolated processes, no restore needed)
        app(\Core\Container::class)->instance(\App\Services\User\UserService::class, $service);
        $service->shouldReceive('findById')->with(9)->andReturn($superAdmin);

        $controller = $this->makeController(
            requestInts: ['user_id' => 7],
            userService: $service,
            deletion: (object)[
                'requested_at' => '2026-01-01 00:00:00',
                'expires_at' => '2026-01-08 00:00:00',
                'status' => 'requested',
                'reason' => 'دلیل محرمانه',
            ]
        );
        $payload = $this->captureJson(static fn () => $controller->getUserDetails());

        self::assertTrue($payload['success']);
        // FIX-P3-CMD-172: super_admin keeps the raw (length-capped) full name
        self::assertSame('Ali Test', $payload['user']['full_name']);
        // CMD-173 (deliberate policy): super_admin sees the raw reason
        self::assertSame('دلیل محرمانه', $payload['deletion']['reason']);
    }

    public function testGetUserDetailsCapsUsernameAndFullNameLengthsMultibyteSafe(): void
    {
        $this->withSessionUser(9);

        $service = Mockery::mock(\App\Services\User\UserService::class);
        $service->shouldReceive('find')->once()->with(7)->andReturn((object)[
            'id' => 7,
            'email' => '',
            'full_name' => str_repeat('ن', 300), // multibyte — must not be cut mid-character
            'username' => str_repeat('u', 300),
        ]);
        $service->shouldReceive('findById')->with(9)->andReturn((object)['id' => 9, 'role' => 'super_admin']);

        app(\Core\Container::class)->instance(\App\Services\User\UserService::class, $service);

        $controller = $this->makeController(requestInts: ['user_id' => 7], userService: $service);
        $payload = $this->captureJson(static fn () => $controller->getUserDetails());

        self::assertSame(100, mb_strlen((string)$payload['user']['full_name'], 'UTF-8'), 'full_name capped at 100 chars');
        self::assertSame(100, mb_strlen((string)$payload['user']['username'], 'UTF-8'), 'username capped at 100 chars');
        // empty email falls back to the (capped) username as identifier — original contract
        self::assertSame(str_repeat('u', 100), $payload['user']['username']);
    }

    public function testGetUserDetailsThrowableReturnsGenericJsonError(): void
    {
        $service = Mockery::mock(\App\Services\User\UserService::class);
        $service->shouldReceive('find')
            ->once()
            ->with(7)
            ->andThrow(new \TypeError('pdo://root:topsecret@10.9.9.9 must not leak'));

        $controller = $this->makeController(requestInts: ['user_id' => 7], userService: $service);
        $payload = $this->captureJson(static fn () => $controller->getUserDetails());

        self::assertFalse($payload['success']);
        self::assertSame('خطا: دریافت اطلاعات ناموفق', $payload['error']);
        $this->assertLogged('error', 'admin.account_deletion.get_details.failed', 'topsecret');
    }

    // ------------------------------------------------------------------
    // ② forceDelete / cancelDeletion — Throwable guards, honest flashes
    // ------------------------------------------------------------------

    public function testForceDeleteSuccessKeepsSuccessFlashAndRedirects(): void
    {
        $this->withSessionUser(9);

        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('getUserDeletionRequest')->once()->with(7)
            ->andReturn((object)['status' => 'requested']);

        $service = Mockery::mock(\App\Services\User\AccountDeletionService::class);
        $service->shouldReceive('deleteUserAccount')->once()->with(7, 'admin_force_delete', 9)->andReturnTrue();

        $audit = Mockery::mock(\App\Services\AuditTrail::class);
        // logAdminAction(): bool — the mock must honor the real return type
        $audit->shouldReceive('logAdminAction')->once()->andReturnTrue();

        $controller = $this->makeController(
            requestInts: ['user_id' => 7],
            deletionLogModel: $model,
            deletionService: $service,
            auditTrail: $audit
        );

        try {
            $controller->forceDelete();
            self::fail('HttpResponseException (redirect) was expected');
        } catch (HttpResponseException $e) {
            self::assertStringEndsWith('/admin/account-deletion/history', (string)$e->getResponse()->getHeader('Location'));
        }

        // FIX-18Q under FIX-P3-CMD-174: the success flash is NOT overwritten by
        // the (now wider) \Throwable catch — the success-path redirect still wins
        self::assertSame('حساب کاربری با موفقیت حذف شد', $this->flash['success'] ?? null);
        self::assertArrayNotHasKey('error', $this->flash);
    }

    public function testForceDeleteRefusesNonRequestedStatusWithoutCallingService(): void
    {
        $this->withSessionUser(9);

        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('getUserDeletionRequest')->once()->with(7)
            ->andReturn((object)['status' => 'cancelled']);

        $service = Mockery::mock(\App\Services\User\AccountDeletionService::class);
        $service->shouldReceive('deleteUserAccount')->never(); // FIX-S16-2: cancelled ≠ deletable

        $controller = $this->makeController(
            requestInts: ['user_id' => 7],
            deletionLogModel: $model,
            deletionService: $service
        );

        try {
            $controller->forceDelete();
            self::fail('HttpResponseException (redirect) was expected');
        } catch (HttpResponseException $e) {
            self::assertStringEndsWith('/admin/account-deletion/pending', (string)$e->getResponse()->getHeader('Location'));
        }

        self::assertSame('این درخواست در وضعیت فعال (requested) نیست و قابل حذف فوری نیست', $this->flash['error'] ?? null);
    }

    public function testForceDeleteThrowableBecomesGenericFlash(): void
    {
        $this->withSessionUser(9);

        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('getUserDeletionRequest')->once()->with(7)
            ->andReturn((object)['status' => 'requested']);

        $service = Mockery::mock(\App\Services\User\AccountDeletionService::class);
        $service->shouldReceive('deleteUserAccount')
            ->once()
            ->andThrow(new \TypeError('saga internals with db password abc123 leaked'));

        $controller = $this->makeController(
            requestInts: ['user_id' => 7],
            deletionLogModel: $model,
            deletionService: $service
        );

        try {
            $controller->forceDelete();
            self::fail('HttpResponseException (redirect) was expected');
        } catch (HttpResponseException $e) {
            self::assertStringEndsWith('/admin/account-deletion/pending', (string)$e->getResponse()->getHeader('Location'));
        }

        self::assertSame('خطا: حذف ناموفق بود', $this->flash['error'] ?? null);
        self::assertStringNotContainsString('abc123', (string)($this->flash['error'] ?? ''));
        $this->assertLogged('error', 'admin.account_deletion.force_delete.failed', 'abc123');
    }

    public function testCancelDeletionSuccessAuditsAndRedirects(): void
    {
        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('getUserDeletionRequest')->once()->with(7)
            ->andReturn((object)['status' => 'requested']);

        $service = Mockery::mock(\App\Services\User\AccountDeletionService::class);
        $service->shouldReceive('cancelDeletion')->once()->with(7)->andReturnTrue();

        $audit = Mockery::mock(\App\Services\AuditTrail::class);
        $audit->shouldReceive('logAdminAction')->once()->andReturnTrue();

        $controller = $this->makeController(
            requestInts: ['user_id' => 7],
            deletionLogModel: $model,
            deletionService: $service,
            auditTrail: $audit
        );

        try {
            $controller->cancelDeletion();
            self::fail('HttpResponseException (redirect) was expected');
        } catch (HttpResponseException $e) {
            self::assertStringEndsWith('/admin/account-deletion/pending', (string)$e->getResponse()->getHeader('Location'));
        }

        self::assertSame('درخواست حذف با موفقیت لغو شد', $this->flash['success'] ?? null);
        self::assertArrayNotHasKey('error', $this->flash);
    }

    public function testCancelDeletionThrowableBecomesGenericFlash(): void
    {
        $model = Mockery::mock(\App\Models\AccountDeletionLog::class);
        $model->shouldReceive('getUserDeletionRequest')->once()->with(7)->andReturnNull();

        $service = Mockery::mock(\App\Services\User\AccountDeletionService::class);
        $service->shouldReceive('cancelDeletion')
            ->once()
            ->with(7)
            ->andThrow(new \AssertionError('assertion internals secret-token-xyz'));

        $controller = $this->makeController(
            requestInts: ['user_id' => 7],
            deletionLogModel: $model,
            deletionService: $service
        );

        try {
            $controller->cancelDeletion();
            self::fail('HttpResponseException (redirect) was expected');
        } catch (HttpResponseException $e) {
            self::assertStringEndsWith('/admin/account-deletion/pending', (string)$e->getResponse()->getHeader('Location'));
        }

        self::assertSame('خطا: لغو ناموفق بود', $this->flash['error'] ?? null);
        $this->assertLogged('error', 'admin.account_deletion.cancel.failed', 'secret-token-xyz');
    }

    // ------------------------------------------------------------------
    // helpers (house pattern: construct-less instantiation + property injection)
    // ------------------------------------------------------------------

    private function withSessionUser(int $userId): void
    {
        $session = Session::getInstance();
        $session->ensureStarted();
        $session->set('user_id', $userId);
    }

    private function makeController(
        array $requestInts = [],
        ?Mockery\MockInterface $userService = null,
        ?Mockery\MockInterface $deletionLogModel = null,
        ?Mockery\MockInterface $deletionService = null,
        ?object $targetUser = null,
        ?object $deletion = null,
        ?Mockery\MockInterface $auditTrail = null
    ): AccountDeletionManagementController {
        $controller = (new \ReflectionClass(AccountDeletionManagementController::class))
            ->newInstanceWithoutConstructor();

        $request = Mockery::mock(\Core\Request::class);
        foreach ($requestInts as $key => $value) {
            $request->shouldReceive('int')->with($key)->andReturn($value);
        }
        // auditLog() reads ip/userAgent — needed on every success/audit path
        $request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $request->shouldReceive('userAgent')->andReturn('PHPUnit-Agent')->byDefault();

        $response = new Response();

        // capture flashes (instead of strict counts) so each test can assert
        // exactly which flash won
        $session = Mockery::mock(Session::class);
        $session->shouldReceive('setFlash')->andReturnUsing(function (string $key, mixed $value): void {
            $this->flash[$key] = $value;
        })->byDefault();

        $logger = Mockery::mock(\Core\Logger::class);
        foreach (['error', 'warning', 'info'] as $level) {
            $logger->shouldReceive($level)->andReturnUsing(function (string $event, ?array $ctx = null) use ($level): void {
                $this->logs[$level][] = [$event, $ctx ?? []];
            })->byDefault();
        }

        $userService = $userService ?? Mockery::mock(\App\Services\User\UserService::class);
        if ($targetUser !== null) {
            $userService->shouldReceive('find')->andReturn($targetUser);
        }

        $deletionLogModel = $deletionLogModel ?? Mockery::mock(\App\Models\AccountDeletionLog::class);
        if ($deletion !== null) {
            $deletionLogModel->shouldReceive('getUserDeletionRequest')->andReturn($deletion)->byDefault();
        } else {
            // explicit fallback — every model method must have a declared expectation
            $deletionLogModel->shouldReceive('getUserDeletionRequest')->andReturnNull()->byDefault();
        }

        $deletionService = $deletionService ?? Mockery::mock(\App\Services\User\AccountDeletionService::class);

        $auditTrail = $auditTrail ?? Mockery::mock(\App\Services\AuditTrail::class);
        $auditTrail->shouldReceive('logAdminAction')->andReturnTrue()->byDefault();

        $this->setControllerProperty($controller, 'request', $request);
        $this->setControllerProperty($controller, 'response', $response);
        $this->setControllerProperty($controller, 'session', $session);
        $this->setControllerProperty($controller, 'logger', $logger);
        $this->setControllerProperty($controller, 'userService', $userService);
        $this->setControllerProperty($controller, 'deletionLogModel', $deletionLogModel);
        $this->setControllerProperty($controller, 'deletionService', $deletionService);
        $this->setControllerProperty($controller, 'auditTrail', $auditTrail);

        return $controller;
    }

    private function assertLogged(string $level, string $event, string $mustContain): void
    {
        foreach ($this->logs[$level] ?? [] as [$loggedEvent, $ctx]) {
            if ($loggedEvent === $event
                && str_contains(json_encode($ctx, JSON_UNESCAPED_UNICODE) ?: '', $mustContain)) {
                self::addToAssertionCount(1);
                return;
            }
        }
        self::fail("Expected a '$level' log with event '$event' whose context contains '$mustContain'");
    }

    /** AJAX gate + JSON envelope capture: getUserDetails/getStats throw on send(). */
    private function captureJson(callable $invoke): array
    {
        $_SERVER['HTTP_X_REQUESTED_WITH'] = 'xmlhttprequest';
        try {
            $invoke();
            self::fail('HttpResponseException was expected from response->json()');
        } catch (HttpResponseException $e) {
            $payload = json_decode($e->getResponse()->getContent(), true);
        } finally {
            unset($_SERVER['HTTP_X_REQUESTED_WITH']);
        }

        self::assertIsArray($payload, 'JSON payload must decode to an array');
        return $payload;
    }

    private function setControllerProperty(object $controller, string $name, mixed $value): void
    {
        $ref = new \ReflectionClass($controller);
        while ($ref instanceof \ReflectionClass && !$ref->hasProperty($name)) {
            $ref = $ref->getParentClass();
        }
        $this->assertInstanceOf(\ReflectionClass::class, $ref);
        $property = $ref->getProperty($name);
        if (PHP_VERSION_ID < 80100) {
            $property->setAccessible(true);
        }
        $property->setValue($controller, $value);
    }
}
