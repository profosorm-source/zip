<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\CouponApiController;
use App\Services\Shared\CouponService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-REVGEN-03 (بچ کانال‌های درآمدیِ فقط-وب — ۲۰۲۶-۱۱-۰۳):
 * 🛡️ FIX-REVGEN-ALIGN (۲۰۲۶-۱۱-۰۵): امضای سازنده به نسخهٔ زندهٔ درخت
 * (FIX-MOBILE-06: CouponService، ?Session، ?Request، ?Response، ?Logger)
 * هم‌تراز شد؛ پوشش قرارداد همان است — پاس‌ترو کامل خروجی سرویس +
 * نگاشت خطای زیرساخت به ۴۲۲ COUPON_VALIDATE_FAILED بدون نشت.
 *
 * لنزها:
 *  ① ورودی: code/amount الزامی + amount عددی + ارز فقط irt|usdt
 *  ② کد معتبر: همان خروجی وب (discount/final/validation_token) بدون مصرف
 *  ③ کد نامعتبر: 422 COUPON_INVALID با پیام علت وب
 *  ④ خطای زیرساخت: 422 بدون نشت جزئیات
 */
final class CouponApiControllerTest extends TestCase
{
    private CouponService&MockInterface $couponService;
    private Request&MockInterface $request;
    private LoggerInterface&MockInterface $logger;
    private Response $response;
    private int $uid;

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): CouponApiController
    {
        // 🛡️ FIX-REVGEN-ALIGN: امضای زندهٔ درخت (FIX-MOBILE-06) — ۵ آرگومان.
        return new CouponApiController(
            $this->couponService,
            Mockery::mock(Session::class),
            $this->request,
            $this->response,
            $this->logger,
        );
    }

    private function boot(): void
    {
        $this->uid = random_int(900000, 999999);
        $this->couponService = Mockery::mock(CouponService::class);
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->uid])->byDefault();
        $this->request->shouldReceive('body')->andReturn([])->byDefault();

        $this->response = new Response();
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    public function test_validate_returns_web_identical_calculation(): void
    {
        $this->boot();
        $this->setBody(['code' => 'WELCOME10', 'amount' => '100000', 'currency' => 'irt']);

        $this->couponService->shouldReceive('validateAndCalculate')->once()->with(
            'WELCOME10',
            '100000',
            'irt',
            $this->uid,
            'all'
        )->andReturn([
            'valid' => true,
            'coupon_code' => 'WELCOME10',
            'original_amount' => '100000',
            'discount_amount' => '10000',
            'final_amount' => '90000',
            'currency' => 'irt',
            'validation_token' => 'tok-abc',
        ]);

        $out = $this->capture(fn() => $this->controller()->validate());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['data']['valid']);
        $this->assertSame('10000', (string)$out['data']['discount_amount']);
        $this->assertSame('90000', (string)$out['data']['final_amount']);
        $this->assertSame('tok-abc', $out['data']['validation_token']);
    }

    public function test_validate_invalid_code_maps_web_reason_to_422(): void
    {
        $this->boot();
        $this->setBody(['code' => 'EXPIRED', 'amount' => '50000', 'currency' => 'irt']);

        $this->couponService->shouldReceive('validateAndCalculate')->once()->andReturn([
            'valid' => false,
            'error' => 'کد تخفیف منقضی شده یا غیرفعال است.',
        ]);

        $out = $this->capture(fn() => $this->controller()->validate());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('COUPON_INVALID', $out['error_code']);
        $this->assertStringContainsString('منقضی', (string)$out['message']);
    }

    /** @return array<string, list<array<string, mixed>>> */
    public function invalidBodyProvider(): array
    {
        return [
            'missing code' => [['amount' => '100', 'currency' => 'irt']],
            'missing amount' => [['code' => 'X', 'currency' => 'irt']],
            'non-numeric amount' => [['code' => 'X', 'amount' => 'abc', 'currency' => 'irt']],
            'bad currency' => [['code' => 'X', 'amount' => '100', 'currency' => 'eur']],
        ];
    }

    /**
     * @dataProvider invalidBodyProvider
     * @param array<string, mixed> $body
     */
    public function test_validate_rejects_malformed_bodies(array $body): void
    {
        $this->boot();
        $this->setBody($body);

        $out = $this->capture(fn() => $this->controller()->validate());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('VALIDATION_ERROR', $out['error_code']);
    }

    public function test_validate_maps_infrastructure_failure_to_422(): void
    {
        $this->boot();
        $this->setBody(['code' => 'OK', 'amount' => '100', 'currency' => 'usdt']);

        $this->couponService->shouldReceive('validateAndCalculate')->once()->andThrow(
            new \RuntimeException('cache exploded')
        );
        $this->logger->shouldReceive('error')->once();

        $out = $this->capture(fn() => $this->controller()->validate());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('COUPON_VALIDATE_FAILED', $out['error_code']);
        $raw = (string)json_encode($out, JSON_UNESCAPED_UNICODE);
        $this->assertStringNotContainsString('cache exploded', $raw);
    }
}
