<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\ContentApiController;
use App\Models\ContentRevenue;
use App\Models\ContentSubmission;
use App\Services\ContentService;
use App\Services\KYC\KycEligibilityService;
use App\Services\User\UserService;
use Core\Container;
use Core\Database;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-06: پوشش قرارداد ContentApiController — درآمد محتوا از کانال API.
 *
 * لنزها:
 *  ① گیت KYC: بدون verified → ۴۰۳ KYC_REQUIRED (همان گیت وب)
 *  ② سهمیه‌ها از سرویس واقعی عبور می‌کند (بدون دور زدن سقف روزانه/صف)
 *  ③ درآمدها: ردیف‌های کاربر با مالکیت
 *  ④ share-preview بدون نیاز به KYC (محاسبه است نه ثبت)
 *  ⑤ ثبت محتوا: اعتبارسنجی ۴۲۲ (بدون تعهدنامه)
 */
final class ContentApiControllerTest extends TestCase
{
    private Database $db;
    private ContentSubmission $submissionModel;
    private ContentRevenue $revenueModel;
    private ContentService $contentService;
    private KycEligibilityService&MockInterface $kycEligibility;
    private UserService $userService;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private LoggerInterface&MockInterface $logger;
    private Response $response;
    private int $userId;
    private string $tag;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->submissionModel = Container::getInstance()->make(ContentSubmission::class);
        $this->revenueModel = Container::getInstance()->make(ContentRevenue::class);
        $this->contentService = Container::getInstance()->make(ContentService::class);
        $this->userService = Container::getInstance()->make(UserService::class);
        $this->tag = 'q6ct' . bin2hex(random_bytes(4));

        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["{$this->tag}-u", "{$this->tag}-u@example.test", 'active', 'user'],
        );
        $this->userId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM content_revenues WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM content_submissions WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM users WHERE id = ?', [$this->userId]);
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): ContentApiController
    {
        return new ContentApiController(
            $this->submissionModel,
            $this->revenueModel,
            $this->contentService,
            $this->kycEligibility,
            $this->userService,
            $this->session,
            $this->request,
            $this->response,
            $this->logger,
        );
    }

    private function boot(string $kycStatus = 'verified'): void
    {
        $this->kycEligibility = Mockery::mock(KycEligibilityService::class);
        $this->kycEligibility->shouldReceive('isEligible')->andReturn(true)->byDefault();
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();
        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('10.0.0.11')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->userId])->byDefault();
        $this->request->shouldReceive('param')->andReturn('')->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 10)->andReturn(10)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();
        $this->request->shouldReceive('body')->andReturn([])->byDefault();
        $this->request->shouldReceive('header')->andReturn('')->byDefault();
        $this->session = Mockery::mock(Session::class);
        $this->response = new Response();

        $this->db->query('UPDATE users SET kyc_status = ? WHERE id = ?', [$kycStatus, $this->userId]);
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    /** @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    // ── ① گیت KYC ───────────────────────────────────────────

    public function test_submissions_require_verified_kyc(): void
    {
        $this->boot('pending');
        $out = $this->capture(fn () => $this->controller()->submissions());
        $this->assertSame(403, $out['__status']);
        $this->assertSame('KYC_REQUIRED', $out['error_code'] ?? '');
    }

    public function test_store_requires_verified_kyc(): void
    {
        $this->boot('pending');
        $out = $this->capture(fn () => $this->controller()->store());
        $this->assertSame(403, $out['__status']);
        $this->assertSame('KYC_REQUIRED', $out['error_code'] ?? '');
    }

    public function test_expired_kyc_is_rejected_too(): void
    {
        $this->boot('verified');
        $this->kycEligibility = Mockery::mock(KycEligibilityService::class);
        $this->kycEligibility->shouldReceive('isEligible')->andReturn(false)->byDefault();

        $out = $this->capture(fn () => $this->controller()->submissions());
        $this->assertSame(403, $out['__status']);
        $this->assertSame('KYC_EXPIRED', $out['error_code'] ?? '');
    }

    // ── ② فهرست‌ها ──────────────────────────────────────────

    public function test_submissions_list_returns_user_rows_and_stats(): void
    {
        $this->boot();
        $this->db->query(
            "INSERT INTO content_submissions (user_id, platform, video_url, url, title, status, is_deleted, created_at, updated_at)
             VALUES (?, 'youtube', 'https://youtu.be/q6ctA', 'https://youtu.be/q6ctA', ?, 'pending', 0, NOW(), NOW())",
            [$this->userId, "{$this->tag} تست"],
        );

        $out = $this->capture(fn () => $this->controller()->submissions());
        $this->assertSame(200, $out['__status']);
        $rows = $out['data']['submissions'] ?? [];
        $this->assertNotEmpty($rows);
        $this->assertSame('pending', $rows[0]['status'] ?? '');
        $this->assertSame(1, (int)($out['data']['stats']['total'] ?? 0));
    }

    public function test_show_submission_rejects_non_owner(): void
    {
        $this->boot();
        // ردیف متعلق به کاربر دیگر
        $this->db->query(
            "INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)",
            ["{$this->tag}-other", "{$this->tag}-o@example.test", 'active', 'user'],
        );
        $otherId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->db->query(
            "INSERT INTO content_submissions (user_id, platform, video_url, url, title, status, is_deleted, created_at, updated_at)
             VALUES (?, 'youtube', 'https://youtu.be/q6ctB', 'https://youtu.be/q6ctB', 'دیگری', 'pending', 0, NOW(), NOW())",
            [$otherId],
        );
        $sid = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');

        $out = $this->capture(fn () => $this->controller()->showSubmission($sid));
        $this->assertSame(404, $out['__status']);

        $this->db->query('DELETE FROM content_submissions WHERE user_id = ?', [$otherId]);
        $this->db->query('DELETE FROM users WHERE id = ?', [$otherId]);
    }

    public function test_revenues_list_returns_user_rows(): void
    {
        $this->boot();
        $this->db->query(
            "INSERT INTO content_submissions (user_id, platform, video_url, url, title, status, is_deleted, created_at, updated_at)
             VALUES (?, 'youtube', 'https://youtu.be/q6ctC', 'https://youtu.be/q6ctC', 'برای درآمد', 'published', 0, NOW(), NOW())",
            [$this->userId],
        );
        $submissionId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->db->query(
            "INSERT INTO content_revenues (submission_id, user_id, period, total_revenue, site_share_percent, site_share_amount, user_share_percent, user_share_amount, tax_percent, tax_amount, net_user_amount, currency, status, created_at, updated_at)
             VALUES (?, ?, '1405-08', 1000.0000, 40.00, 400.0000, 60.00, 600.0000, 9.00, 54.0000, 546.0000, 'irt', 'paid', NOW(), NOW())",
            [$submissionId, $this->userId],
        );

        $out = $this->capture(fn () => $this->controller()->revenues());
        $this->assertSame(200, $out['__status']);
        $rows = $out['data']['revenues'] ?? [];
        $this->assertNotEmpty($rows);
        $this->assertSame('paid', $rows[0]['status'] ?? '');
        $this->assertSame('1405-08', $rows[0]['period'] ?? '');
    }

    // ── ④ share-preview (بدون KYC) ──────────────────────────

    public function test_share_preview_works_without_kyc_and_returns_tier_shape(): void
    {
        $this->boot('pending');
        $out = $this->capture(fn () => $this->controller()->sharePreview());
        $this->assertSame(200, $out['__status'], 'پیش‌نمایش محاسبه است — گیت KYC ندارد');
        $preview = $out['data']['preview'] ?? [];
        $this->assertSame('normal', $preview['tier'] ?? '');
        $this->assertSame(60.0, (float)($preview["user_percent"] ?? -1));
        $this->assertSame(40.0, (float)($preview["site_percent"] ?? -1));
    }

    // ── ⑤ ثبت ───────────────────────────────────────────────

    public function test_store_validation_errors_without_agreement(): void
    {
        $this->boot();
        $this->setBody([
            'platform' => 'youtube',
            'title' => 'عنوان',
            'video_url' => 'https://youtu.be/q6ctD',
            'agreement_accepted' => 0,
        ]);
        $out = $this->capture(fn () => $this->controller()->store());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('agreement_accepted', $out['data']['errors'] ?? []);
    }

    public function test_store_success_creates_pending_submission_via_real_service(): void
    {
        $this->boot();
        $this->setBody([
            'platform' => 'youtube',
            'title' => 'محتوای API تست',
            'video_url' => 'https://youtu.be/q6ctE' . bin2hex(random_bytes(3)),
            'agreement_accepted' => 1,
        ]);

        ob_start();
        try {
            $out = $this->capture(fn () => $this->controller()->store());
        } finally { ob_end_clean(); }

        $this->assertSame(200, $out['__status'], json_encode($out, JSON_UNESCAPED_UNICODE));
        $submissionId = (int)($out['data']['submission_id'] ?? 0);
        $this->assertGreaterThan(0, $submissionId);

        $row = $this->db->query('SELECT status, url_hash FROM content_submissions WHERE id = ?', [$submissionId])->fetch(\PDO::FETCH_OBJ);
        $this->assertSame('pending', (string)$row->status);
        $this->assertNotSame('', (string)$row->url_hash, 'ثبت از مسیر سرویس واقعی — url_hash نوشته می‌شود (FIX-Q4-MOD24-05)');
    }

    // ── ⑥ FIX-REVGEN-ALIGN: پوشش پورت‌شده از ContentSubmissionApiControllerTest
    // (کنترلر نسخهٔ revgen-q4 هرگز اعمال نشد؛ این پوشش حالا کنترلر زندهٔ
    // درخت — ContentApiController با اندپوینت‌های FIX-REVGEN-REAPLY — را پین
    // می‌کند: agreement / revenues summary / update / نگاشت خطای کسب‌وکار).

    public function test_agreement_returns_web_identical_text_and_settings(): void
    {
        $this->boot();

        $service = Mockery::mock(ContentService::class);
        $service->shouldReceive('getAgreementText')->once()->andReturn('متن تعهدنامه');
        $service->shouldReceive('getSettings')->once()->andReturn([
            'allowed_platforms'  => ['youtube', 'aparat'],
            'site_share_percent' => 40.0,
            'tax_percent'        => 9.0,
            'min_months'         => 2,
        ]);
        $service->shouldReceive('getUserSharePreview')->once()->with($this->userId)->andReturn([
            'tier' => 'normal', 'user_percent' => 60.0, 'site_percent' => 40.0, 'tax_percent' => 9.0,
        ]);
        $this->contentService = $service;

        $out = $this->capture(fn () => $this->controller()->agreement());
        $this->assertSame(200, $out['__status']);
        $this->assertSame('متن تعهدنامه', $out['data']['agreement_text'] ?? null);
        $this->assertSame(['youtube', 'aparat'], $out['data']['allowed_platforms'] ?? null);
        $this->assertSame(40.0, (float)($out['data']['site_share_percent'] ?? -1));
        $this->assertSame(2, (int)($out['data']['min_months'] ?? -1));
        $this->assertSame('normal', $out['data']['share_preview']['tier'] ?? null);
    }

    public function test_revenues_summary_splits_total_paid_pending(): void
    {
        $this->boot();

        $revenueModel = Mockery::mock(ContentRevenue::class);
        $revenueModel->shouldReceive('getTotalUserRevenue')->once()->with($this->userId)->andReturn(1000.0);
        $revenueModel->shouldReceive('getTotalUserRevenue')->once()->with($this->userId, 'paid')->andReturn(546.0);
        $revenueModel->shouldReceive('getTotalUserRevenue')->once()->with($this->userId, 'pending')->andReturn(454.0);
        $this->revenueModel = $revenueModel;

        $out = $this->capture(fn () => $this->controller()->revenuesSummary());
        $this->assertSame(200, $out['__status']);
        $this->assertSame(1000.0, (float)($out['data']['summary']['total_net'] ?? -1));
        $this->assertSame(546.0, (float)($out['data']['summary']['paid_net'] ?? -1));
        $this->assertSame(454.0, (float)($out['data']['summary']['pending_net'] ?? -1));
        // کلید گمراه‌کنندهٔ total_user_paid (Q4-09) در قرارداد API هم نیست
        $this->assertArrayNotHasKey('total_user_paid', $out['data'] ?? []);
    }

    public function test_update_passes_service_and_returns_updated_data(): void
    {
        $this->boot();
        $this->setBody([
            'platform'    => 'youtube',
            'video_url'   => 'https://youtu.be/q6ctF' . bin2hex(random_bytes(3)),
            'title'       => 'ویرایش از اپ',
            'description' => 'توضیح جدید',
        ]);

        $service = Mockery::mock(ContentService::class);
        $service->shouldReceive('updateSubmission')->once()->andReturn([
            'success' => true, 'message' => 'به‌روزرسانی شد', 'data' => ['submission_id' => 11],
        ]);
        $this->contentService = $service;

        $out = $this->capture(fn () => $this->controller()->update(11));
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['success']);
        $this->assertSame(11, (int)($out['data']['submission_id'] ?? 0));
    }

    public function test_update_maps_business_exception_to_422(): void
    {
        $this->boot();
        $this->setBody([
            'platform'  => 'youtube',
            'video_url' => 'https://youtu.be/q6ctG' . bin2hex(random_bytes(3)),
            'title'     => 'ویرایش ردشده',
        ]);

        $service = Mockery::mock(ContentService::class);
        $service->shouldReceive('updateSubmission')->once()->andThrow(
            new \Core\Exceptions\BusinessException('این محتوا در وضعیت فعلی قابل ویرایش نیست')
        );
        $this->contentService = $service;

        $out = $this->capture(fn () => $this->controller()->update(11));
        $this->assertSame(422, $out['__status']);
        $this->assertSame('CONTENT_UPDATE_FAILED', $out['error_code'] ?? null);
        $this->assertStringContainsString('قابل ویرایش نیست', (string)($out['message'] ?? ''));
    }

    public function test_store_maps_business_exception_to_422(): void
    {
        $this->boot();
        $this->setBody([
            'platform'           => 'youtube',
            'title'              => 'روی سقف روزانه',
            'video_url'          => 'https://youtu.be/q6ctH' . bin2hex(random_bytes(3)),
            'agreement_accepted' => 1,
        ]);

        // همان گاردهای سرویس: سقف روزانه (Q4-23)، سهمیهٔ صف (Q4-04)،
        // یگانگی هش (Q4-05) — سرویس بعد از لاگ دوباره پرتاب می‌کند.
        $service = Mockery::mock(ContentService::class);
        $service->shouldReceive('submitContent')->once()->andThrow(
            new \Core\Exceptions\BusinessException('سقف ارسال محتوا در روز پر شده است. لطفاً فردا دوباره تلاش کنید.')
        );
        $this->contentService = $service;

        $out = $this->capture(fn () => $this->controller()->store());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('CONTENT_SUBMIT_FAILED', $out['error_code'] ?? null);
        $this->assertStringContainsString('سقف ارسال محتوا', (string)($out['message'] ?? ''));
    }

    public function test_submissions_status_filter_is_whitelisted(): void
    {
        $this->boot();
        // مقدار خارج از لیست مجاز (pending/under_review/approved/published/
        // rejected/suspended) به‌جای خطا، فیلترِ خالی تفسیر می‌شود.
        $this->request->shouldReceive('param')->with('status', '')->andReturn('hacked')->byDefault();

        $out = $this->capture(fn () => $this->controller()->submissions());
        $this->assertSame(200, $out['__status'], 'مقدار نامعتبر ≠ خطا — رها می‌شود و بدون فیلتر برمی‌گردد');
        $this->assertArrayHasKey('submissions', $out['data'] ?? []);
    }
}
