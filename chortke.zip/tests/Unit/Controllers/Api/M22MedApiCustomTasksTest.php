<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\CustomTaskApiController;
use App\Models\Ads;
use App\Models\CustomTaskSubmissionModel;
use App\Services\CustomTask\CustomTaskExecutorService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M22-MED (N1) — سه شکست کانال API موبایل:
 *  ۱) submitProof: فیلدهای proof_link/note روی قرارداد مشترک جاب نگاشت می‌شوند
 *     (proof_url/proof_text) — قبلاً کلیدهایی که جاب هرگز نمی‌خواند ⇒ همیشه 422.
 *  ۲) start: کلیدهای واقعی نتیجه (submission_id/deadline) به‌عنوان data —
 *     قبلاً $result['data'] (که هرگز وجود ندارد) پوش می‌شد ⇒ data:[].
 *  ۳) جزئیات اجرا: پاداش از ستون واقعی reward_amount — نه worker_rewardِ ناموجود.
 *
 * 📱 FIX-MOBCTR-05: هم‌گام با قرارداد جدید — کنترلر حالا قبل از submit ردیف
 * submission را با submission_findForProof می‌خواند (نوع مدرک سرور-محاسبه)؛
 * mock ها همین مسیر را تغذیه می‌کنند. قراردادهای جدید در MobileContractCustomTasksTest.
 */
final class M22MedApiCustomTasksTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    private Ads $adModel;
    private CustomTaskSubmissionModel $submissionModel;
    private CustomTaskExecutorService&\Mockery\MockInterface $executorService;
    private Request&\Mockery\MockInterface $request;
    private Session&\Mockery\MockInterface $session;
    private LoggerInterface&\Mockery\MockInterface $logger;
    private Response $response;
    private int $workerId = 77;

    private function boot(): void
    {
        $this->adModel = m::mock(Ads::class);
        $this->submissionModel = m::mock(CustomTaskSubmissionModel::class);
        $this->executorService = m::mock(CustomTaskExecutorService::class);
        $this->logger = m::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->zeroOrMoreTimes();
        $this->logger->shouldReceive('error')->zeroOrMoreTimes();
        $this->request = m::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('10.0.0.10')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->workerId])->byDefault();
        $this->request->shouldReceive('body')->andReturn([])->byDefault();
        $this->request->shouldReceive('header')->andReturn('')->byDefault();
        // 📱 FIX-MOBCTR-05: کانال multipart — پیش‌فرض بدون فایل
        $this->request->shouldReceive('file')->andReturn(null)->byDefault();
        $this->session = m::mock(Session::class);
        $this->response = new Response();
    }

    private function controller(): CustomTaskApiController
    {
        // الگوی M22StartGuards: بدون-سازنده + تزریق Reflection (سازندهٔ BaseController
        // وابستگی‌ها را از کانتینر می‌گیرد و در محیط بدون-DB می‌شکند)
        $controller = (new \ReflectionClass(CustomTaskApiController::class))->newInstanceWithoutConstructor();
        $inject = static function (object $target, string $class, string $prop, mixed $value): void {
            $r = new \ReflectionProperty($class, $prop);
            $r->setAccessible(true);
            $r->setValue($target, $value);
        };
        $inject($controller, CustomTaskApiController::class, 'adModel', $this->adModel);
        $inject($controller, CustomTaskApiController::class, 'submissionModel', $this->submissionModel);
        $inject($controller, CustomTaskApiController::class, 'executorService', $this->executorService);
        // 📱 FIX-MOBCTR-01: کانال فایل مشترک وب/موبایل — سرویس final است؛ نمونهٔ
        // واقعی روی UploadService ماک‌شده (در تست‌های بدون فایل هرگز فراخوانی نمی‌شود)
        $inject($controller, CustomTaskApiController::class, 'proofFileService', new \App\Services\CustomTask\CustomTaskProofFileService(m::mock(\App\Services\UploadService::class)));
        $inject($controller, \App\Controllers\BaseController::class, 'session', $this->session);
        $inject($controller, \App\Controllers\BaseController::class, 'request', $this->request);
        $inject($controller, \App\Controllers\BaseController::class, 'response', $this->response);
        $inject($controller, \App\Controllers\BaseController::class, 'logger', $this->logger);
        $inject($controller, \App\Controllers\BaseController::class, 'policyService', m::mock(\App\Services\Shared\PolicyService::class));
        $inject($controller, \App\Controllers\BaseController::class, 'csrf', m::mock(\Core\CSRF::class));
        $inject($controller, \App\Controllers\BaseController::class, 'validatorFactory', m::mock(\App\Contracts\ValidatorFactoryInterface::class));
        return $controller;
    }

    /** ردیف اجرای در-جریان برای فراخوان‌های proof (هم‌شکل findForProof) */
    private function inProgressSubmission(string $proofType = 'url'): \stdClass
    {
        return (object)[
            'id' => 55,
            'task_id' => 11,
            'worker_id' => $this->workerId,
            'status' => 'in_progress',
            'deadline_at' => null,
            'proof_type' => $proofType,
            'proof_description' => 'دستورالعمل مدرک',
            'proof_schema' => null,
        ];
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    /** @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    // ── ۱) شروع: کلیدهای واقعی نتیجه در data ──────────────────────

    /** @test */
    public function start_response_data_carries_submission_id_and_deadline(): void
    {
        $this->boot();
        // خروجی واقعی startTask (برخلاف mock های قدیمی، هیچ کلید data ندارد)
        $this->executorService->shouldReceive('startTask')
            ->once()->with(11, $this->workerId)
            ->andReturn(['success' => true, 'submission_id' => 555, 'deadline' => '2026-12-01 10:00:00', 'message' => 'شروع شد']);
        // 📱 FIX-MOBCTR-05: تسک برای enrich پاسخ با proof_type خوانده می‌شود
        $this->adModel->shouldReceive('find')->once()->with(11)
            ->andReturn((object)['id' => 11, 'proof_type' => 'screenshot', 'proof_description' => 'اسکرین‌شات بگیرید']);

        $out = $this->capture(fn () => $this->controller()->start(11));
        $this->assertSame(200, $out['__status']);
        $this->assertSame(555, (int)($out['data']['submission_id'] ?? 0), 'submission_id باید به کلاینت برسد');
        $this->assertSame('2026-12-01 10:00:00', (string)($out['data']['deadline'] ?? ''), 'deadline باید به کلاینت برسد');
        $this->assertSame('screenshot', (string)($out['data']['proof_type'] ?? ''), 'نوع مدرک باید در پاسخ start باشد');
        $this->assertSame('شروع شد', (string)($out['message'] ?? ''));
    }

    /** @test */
    public function start_failure_still_maps_to_422(): void
    {
        $this->boot();
        $this->executorService->shouldReceive('startTask')
            ->once()->with(11, $this->workerId)
            ->andReturn(['success' => false, 'message' => 'ظرفیت تکمیل است']);
        $this->adModel->shouldReceive('find')->never();

        $out = $this->capture(fn () => $this->controller()->start(11));
        $this->assertSame(422, $out['__status']);
        $this->assertSame('ظرفیت تکمیل است', (string)($out['message'] ?? ''));
    }

    // ── ۲) مدرک: نگاشت فیلدهای موبایل روی قرارداد جاب ──────────────

    /** @test */
    public function submit_proof_maps_proof_link_to_proof_url_and_note_to_proof_text(): void
    {
        $this->boot();
        // 📱 FIX-MOBCTR-05: ردیف اجرا + نوع سرور-محاسبه قبل از نگاشت
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->with(55, $this->workerId)
            ->andReturn($this->inProgressSubmission('url'));
        $this->executorService->shouldReceive('submitProof')
            ->once()
            ->with(55, $this->workerId, m::on(static function (array $payload): bool {
                return ($payload['proof_url'] ?? '') === 'https://cdn.example.com/p/1.png'
                    && ($payload['proof_text'] ?? '') === 'گزارش نهایی مدرک'
                    && !array_key_exists('proof_link', $payload)
                    && !array_key_exists('note', $payload)
                    && !array_key_exists('idempotency_key', $payload);
            }))
            ->andReturn(['success' => true, 'message' => 'مدرک ثبت شد', 'auto_approve_info' => 'تا ۴۸ ساعت']);

        $this->setBody(['proof_link' => 'https://cdn.example.com/p/1.png', 'note' => 'گزارش نهایی مدرک']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(200, $out['__status']);
        // 📱 FIX-MOBCTR-05 (A1-N8): کلیدهای واقعی جاب در data — نه [] همیشگی
        $this->assertSame('تا ۴۸ ساعت', (string)($out['data']['auto_approve_info'] ?? ''), 'auto_approve_info نباید دور ریخته شود');
        $this->assertSame(55, (int)($out['data']['submission_id'] ?? 0));
        $this->assertSame('submitted', (string)($out['data']['status'] ?? ''));
    }

    /** @test */
    public function submit_proof_still_rejects_localhost_hosts(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->with(55, $this->workerId)
            ->andReturn($this->inProgressSubmission('url'));
        $this->executorService->shouldReceive('submitProof')->never();

        $this->setBody(['proof_link' => 'http://127.0.0.1/proof.png']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('proof_link', $out['data']['errors'] ?? []);
    }

    /** @test */
    public function submit_proof_payload_is_capped_to_contract_max_lengths(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->with(55, $this->workerId)
            ->andReturn($this->inProgressSubmission('url'));
        $longNote = str_repeat('م', 3000);
        $this->executorService->shouldReceive('submitProof')
            ->once()
            ->with(55, $this->workerId, m::on(static function (array $payload): bool {
                return mb_strlen((string)($payload['proof_text'] ?? '')) === 2000
                    && mb_strlen((string)($payload['proof_url'] ?? '')) <= 1000;
            }))
            ->andReturn(['success' => true, 'message' => 'مدرک ثبت شد']);

        $this->setBody(['proof_link' => 'https://cdn.example.com/p/2.png', 'note' => $longNote]);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(200, $out['__status']);
    }

    // ── ۳) جزئیات اجرا: پاداش از reward_amount ─────────────────────

    /** @test */
    public function submission_detail_reads_reward_from_real_reward_amount_column(): void
    {
        $this->boot();
        // ستون worker_reward هرگز وجود ندارد — reward_amount واقعی است
        $this->submissionModel->shouldReceive('submission_findById')
            ->once()->with(55)
            ->andReturn((object)[
                'id' => 55,
                'task_id' => 11,
                'worker_id' => $this->workerId,
                'status' => 'approved',
                'proof_url' => 'https://cdn.example.com/p/1.png',
                'proof_code' => 'TRK-991',
                'proof_type' => 'code',
                'proof_description' => 'کد پیگیری را بفرستید',
                'admin_note' => '',
                'reward_amount' => '3000.0000',
                'reward_currency' => 'irt',
                'updated_at' => '2026-11-01 10:00:00',
            ]);

        $out = $this->capture(fn () => $this->controller()->showSubmission(55));
        $this->assertSame(200, $out['__status']);
        $this->assertSame('3000.0000', (string)($out['data']['submission']['reward'] ?? ''), 'پاداش باید از reward_amount بخواند، نه worker_reward ناموجود');
        // 📱 FIX-MOBCTR-05 (A3-N3): نوع مدرک + کد ارسالی در جزئیات
        $this->assertSame('code', (string)($out['data']['submission']['proof_type'] ?? ''));
        $this->assertSame('TRK-991', (string)($out['data']['submission']['proof_code'] ?? ''));
    }

    /** @test */
    public function submission_detail_rejects_non_owner(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findById')
            ->once()->with(55)
            ->andReturn((object)['id' => 55, 'worker_id' => 999, 'status' => 'approved', 'reward_amount' => '0']);

        $out = $this->capture(fn () => $this->controller()->showSubmission(55));
        $this->assertSame(404, $out['__status']);
    }
}
