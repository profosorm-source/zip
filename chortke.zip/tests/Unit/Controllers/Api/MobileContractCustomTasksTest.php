<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\CustomTaskApiController;
use App\Models\Ads;
use App\Models\CustomTaskSubmissionModel;
use App\Services\CustomTask\CustomTaskExecutorService;
use App\Services\CustomTask\CustomTaskProofFileService;
use App\Services\UploadService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBCTR (بچ قرارداد API موبایل — ۲۰۲۶-۱۱-۰۷) — پوشش قرارداد جدید
 * CustomTaskApiController؛ یافته‌های A3-N3 + A1-N15 + A1-N8 + A3-N7:
 *
 *  A3-N3  proof_type در tasks/start/detail/mySubmissions + همهٔ کانال‌های مدرک
 *         (text/code/url/screenshot/file/video) — نوع همیشه سرور-محاسبه.
 *  A1-N15 تسک text بدون URL اجباری (note≥10 کافی)؛ note کوتاه = پیام اسکیما.
 *  A1-N8  data پاسخ submit = کلیدهای واقعی جاب (auto_approve_info و…).
 *  A3-N7  هر دو لیست meta صفحه‌بندی دارند (هم‌شکل paginated خواهرها).
 *
 * کانال فایل: CustomTaskProofFileService واقعی روی UploadService ماک‌شده
 * (همان الگوی M22MedProofChainTest) — سرویس final است و mock مستقیم نمی‌شود.
 */
final class MobileContractCustomTasksTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    private Ads $adModel;
    private CustomTaskSubmissionModel $submissionModel;
    private CustomTaskExecutorService&\Mockery\MockInterface $executorService;
    private UploadService&\Mockery\MockInterface $upload;
    private Request&\Mockery\MockInterface $request;
    private LoggerInterface&\Mockery\MockInterface $logger;
    private Response $response;
    private int $workerId = 77;

    private function boot(): void
    {
        $this->adModel = m::mock(Ads::class);
        $this->submissionModel = m::mock(CustomTaskSubmissionModel::class);
        $this->executorService = m::mock(CustomTaskExecutorService::class);
        $this->upload = m::mock(UploadService::class);
        $this->logger = m::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->zeroOrMoreTimes();
        $this->logger->shouldReceive('error')->zeroOrMoreTimes();
        $this->request = m::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('10.0.0.10')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->workerId])->byDefault();
        $this->request->shouldReceive('body')->andReturn([])->byDefault();
        $this->request->shouldReceive('header')->andReturn('')->byDefault();
        $this->request->shouldReceive('file')->andReturn(null)->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();
        $this->response = new Response();
    }

    private function controller(): CustomTaskApiController
    {
        $controller = (new \ReflectionClass(CustomTaskApiController::class))->newInstanceWithoutConstructor();
        $inject = static function (object $target, string $class, string $prop, mixed $value): void {
            $r = new \ReflectionProperty($class, $prop);
            $r->setAccessible(true);
            $r->setValue($target, $value);
        };
        $inject($controller, CustomTaskApiController::class, 'adModel', $this->adModel);
        $inject($controller, CustomTaskApiController::class, 'submissionModel', $this->submissionModel);
        $inject($controller, CustomTaskApiController::class, 'executorService', $this->executorService);
        $inject($controller, CustomTaskApiController::class, 'proofFileService', new CustomTaskProofFileService($this->upload));
        $inject($controller, \App\Controllers\BaseController::class, 'session', m::mock(Session::class));
        $inject($controller, \App\Controllers\BaseController::class, 'request', $this->request);
        $inject($controller, \App\Controllers\BaseController::class, 'response', $this->response);
        $inject($controller, \App\Controllers\BaseController::class, 'logger', $this->logger);
        $inject($controller, \App\Controllers\BaseController::class, 'policyService', m::mock(\App\Services\Shared\PolicyService::class));
        $inject($controller, \App\Controllers\BaseController::class, 'csrf', m::mock(\Core\CSRF::class));
        $inject($controller, \App\Controllers\BaseController::class, 'validatorFactory', m::mock(\App\Contracts\ValidatorFactoryInterface::class));
        return $controller;
    }

    /** @param array<string, mixed> $overrides */
    private function submission(string $proofType, array $overrides = []): \stdClass
    {
        return (object)array_merge([
            'id' => 55,
            'task_id' => 11,
            'worker_id' => $this->workerId,
            'status' => 'in_progress',
            'deadline_at' => null,
            'proof_type' => $proofType,
            'proof_description' => 'دستورالعمل مدرک',
            'proof_schema' => null,
        ], $overrides);
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    /** @param array<string, mixed> $file */
    private function setFile(array $file): void
    {
        $this->request->shouldReceive('file')->with('proof_file')->andReturn($file)->byDefault();
    }

    /** @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    // ── A1-N15: تسک text بدون URL اجباری ─────────────────────────

    /** @test */
    public function text_task_accepts_note_only_without_any_url(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('text'));
        $this->executorService->shouldReceive('submitProof')
            ->once()->with(55, $this->workerId, m::on(static function (array $p): bool {
                // کانال متنی کافی است — URL لازم نیست (قبلاً 422 اجباری)
                return ($p['proof_text'] ?? '') === 'توضیح کامل انجام تسک سفارشی'
                    && ($p['proof_url'] ?? null) === null;
            }))
            ->andReturn(['success' => true, 'message' => 'ok', 'auto_approve_info' => 'info']);

        $this->setBody(['note' => 'توضیح کامل انجام تسک سفارشی']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(200, $out['__status']);
    }

    /** @test */
    public function text_task_short_note_gets_schema_message(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('text'));
        $this->executorService->shouldReceive('submitProof')->never();

        $this->setBody(['note' => 'کوتاه']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(422, $out['__status']);
        $this->assertStringContainsString('حداقل ۱۰ کاراکتر', (string)($out['message'] ?? ''));
    }

    // ── A3-N3: کانال کد ──────────────────────────────────────────

    /** @test */
    public function code_task_maps_code_channel_with_min_two_chars(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('code'));
        $this->executorService->shouldReceive('submitProof')
            ->once()->with(55, $this->workerId, m::on(static function (array $p): bool {
                return ($p['proof_code'] ?? '') === 'TRK-8877'
                    && ($p['proof_url'] ?? null) === null
                    && ($p['proof_text'] ?? null) === null;
            }))
            ->andReturn(['success' => true, 'message' => 'ok']);

        $this->setBody(['code' => 'TRK-8877']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(200, $out['__status']);
    }

    /** @test */
    public function code_task_missing_code_is_rejected_by_schema(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('code'));
        $this->executorService->shouldReceive('submitProof')->never();

        $this->setBody(['note' => 'توضیح بلند بدون کد']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(422, $out['__status']);
        $this->assertStringContainsString('کد یا شناسه', (string)($out['message'] ?? ''));
    }

    // ── A3-N3: کانال‌های فایل (multipart) ─────────────────────────

    /** @test */
    public function screenshot_task_without_file_is_rejected_with_proof_file_key(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('screenshot'));
        $this->executorService->shouldReceive('submitProof')->never();

        $this->setBody(['note' => 'بدون فایل']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(422, $out['__status']);
        $fieldErrors = (array)($out['data']['errors']['proof_file'] ?? []);
        $this->assertNotEmpty($fieldErrors, 'خطای فیلدی proof_file لازم است');
        $this->assertStringContainsString('اسکرین‌شات', (string)($fieldErrors[0] ?? ''));
    }

    /** @test */
    public function screenshot_task_uploads_via_shared_service_and_carries_server_path_and_hash(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('screenshot'));
        $tmp = (string)tempnam(sys_get_temp_dir(), 'mobctr');
        file_put_contents($tmp, 'fake-png-bytes');
        $relPath = 'task-proofs/' . bin2hex(random_bytes(12)) . '.png';

        // 📱 FIX-MOBCTR-01: سرویس مشترک — همان قرارداد upload() کنترلر وب
        $this->upload->shouldReceive('upload')
            ->once()->with(m::on(static fn($f): bool => ($f['name'] ?? '') === 'shot.png'), 'task-proofs', ['jpg', 'jpeg', 'png', 'webp'], 5 * 1024 * 1024)
            ->andReturn(['success' => true, 'path' => $relPath, 'url' => null, 'size' => 14, 'mime' => 'image/png']);
        $this->upload->shouldReceive('getPath')->once()->with($relPath)->andReturn($tmp);

        $this->executorService->shouldReceive('submitProof')
            ->once()->with(55, $this->workerId, m::on(static function (array $p) use ($relPath, $tmp): bool {
                return ($p['proof_file'] ?? '') === $relPath
                    && ($p['proof_file_hash'] ?? '') === hash_file('sha256', $tmp)
                    && ($p['proof_url'] ?? null) === null;
            }))
            ->andReturn(['success' => true, 'message' => 'ok', 'auto_approve_info' => 'info']);

        $this->setFile(['name' => 'shot.png', 'tmp_name' => $tmp, 'error' => UPLOAD_ERR_OK, 'size' => 14]);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(200, $out['__status']);
        unlink($tmp);
    }

    /** @test */
    public function file_task_pdf_goes_through_private_document_channel(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('file'));
        $tmp = (string)tempnam(sys_get_temp_dir(), 'mobctr');
        file_put_contents($tmp, '%PDF-1.7 mobctr');
        $relPath = 'task-proofs/' . bin2hex(random_bytes(12)) . '.pdf';

        $this->upload->shouldReceive('uploadPrivateDocument')
            ->once()->with(m::on(static fn($f): bool => ($f['name'] ?? '') === 'report.pdf'), 'task-proofs', ['application/pdf'], 5 * 1024 * 1024)
            ->andReturn(['success' => true, 'path' => $relPath, 'size' => 18]);
        $this->upload->shouldReceive('getPath')->once()->with($relPath)->andReturn($tmp);

        $this->executorService->shouldReceive('submitProof')
            ->once()->andReturn(['success' => true, 'message' => 'ok']);

        $this->setFile(['name' => 'report.pdf', 'tmp_name' => $tmp, 'error' => UPLOAD_ERR_OK, 'size' => 18]);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(200, $out['__status']);
        unlink($tmp);
    }

    /** @test */
    public function schema_failure_after_upload_deletes_the_orphan_file(): void
    {
        $this->boot();
        // تسک text با فایل پیوست + note کوتاه ⇒ آپلود موفق ولی اسکما (text≥10)
        // شکست می‌خورد ⇒ فایل آپلودشده باید همان‌جا پاک شود (هم‌الگوی D2-N13 وب).
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('text'));
        $tmp = (string)tempnam(sys_get_temp_dir(), 'mobctr');
        file_put_contents($tmp, 'fake-bytes');
        $relPath = 'task-proofs/' . bin2hex(random_bytes(12)) . '.png';

        $this->upload->shouldReceive('upload')->once()->andReturn(['success' => true, 'path' => $relPath]);
        $this->upload->shouldReceive('getPath')->once()->andReturn($tmp);
        $this->upload->shouldReceive('delete')->once()->with($relPath)->andReturn(true);
        $this->executorService->shouldReceive('submitProof')->never();

        $this->setFile(['name' => 'shot.png', 'tmp_name' => $tmp, 'error' => UPLOAD_ERR_OK, 'size' => 10]);
        $this->setBody(['note' => 'کوتاه']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(422, $out['__status']);
        $this->assertStringContainsString('حداقل ۱۰ کاراکتر', (string)($out['message'] ?? ''));
        unlink($tmp);
    }

    /** @test */
    public function client_json_proof_file_strings_are_ignored(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('text'));
        $this->executorService->shouldReceive('submitProof')
            ->once()->with(55, $this->workerId, m::on(static function (array $p): bool {
                return !array_key_exists('proof_file', $p)
                    && !array_key_exists('proof_file_hash', $p)
                    && ($p['proof_text'] ?? '') === 'متن مدرک معتبر و کامل';
            }))
            ->andReturn(['success' => true, 'message' => 'ok']);

        $this->setBody([
            'note' => 'متن مدرک معتبر و کامل',
            'proof_file' => 'task-proofs/someone-else.png',
            'proof_file_hash' => str_repeat('a', 64),
        ]);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(200, $out['__status']);
    }

    // ── گاردهای وضعیت/مالکیت ─────────────────────────────────────

    /** @test */
    public function not_in_progress_submission_is_rejected_before_any_upload(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('text', ['status' => 'submitted']));
        $this->executorService->shouldReceive('submitProof')->never();

        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(422, $out['__status']);
        $this->assertSame('INVALID_STATE', (string)($out['error_code'] ?? ''));
    }

    /** @test */
    public function deadline_passed_submission_is_rejected(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('text', ['deadline_at' => '2020-01-01 00:00:00']));
        $this->executorService->shouldReceive('submitProof')->never();

        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(422, $out['__status']);
        $this->assertSame('DEADLINE_PASSED', (string)($out['error_code'] ?? ''));
    }

    /** @test */
    public function foreign_submission_is_404(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->with(55, $this->workerId)->andReturn(null);
        $this->executorService->shouldReceive('submitProof')->never();

        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(404, $out['__status']);
        $this->assertSame('SUBMISSION_NOT_FOUND', (string)($out['error_code'] ?? ''));
    }

    // ── A3-N7: meta صفحه‌بندی در هر دو لیست ───────────────────────

    /** @test */
    public function tasks_list_carries_proof_type_and_pagination_meta(): void
    {
        $this->boot();
        $this->adModel->shouldReceive('getAvailableCustomTasks')
            ->once()->with($this->workerId, [], 20, 0, 'custom_task')
            ->andReturn([
                (object)['id' => 12, 'title' => 'تسک', 'description' => 'د', 'price_per_task' => '3000',
                         'currency' => 'irt', 'remaining_slots' => 7, 'proof_type' => 'image',
                         'proof_description' => 'دستورالعمل'],
            ]);
        // شمارندهٔ هم‌شرط لیست (نه شمارندهٔ همهٔ فعال‌ها)
        $this->adModel->shouldReceive('countStartableCustomTasks')
            ->once()->with($this->workerId)->andReturn(23);

        $out = $this->capture(fn () => $this->controller()->tasks());
        $this->assertSame(200, $out['__status']);
        $row = $out['data']['tasks'][0] ?? [];
        // نرمال‌سازی: image ⇒ screenshot (تک‌منبع CustomTaskProofSchema)
        $this->assertSame('screenshot', (string)($row['proof_type'] ?? ''));
        $this->assertSame('دستورالعمل', (string)($row['proof_description'] ?? ''));
        $meta = $out['meta'] ?? [];
        $this->assertSame(23, (int)($meta['total'] ?? -1));
        $this->assertSame(2, (int)($meta['last_page'] ?? -1), 'last_page = ceil(23/20)');
        $this->assertSame(20, (int)($meta['per_page'] ?? -1));
        $this->assertSame(1, (int)($meta['current_page'] ?? -1));
        $this->assertSame(1, (int)($meta['from'] ?? -1));
        $this->assertSame(20, (int)($meta['to'] ?? -1), 'to = min(page*per_page, total) = min(20,23)');
    }

    /** @test */
    public function my_submissions_carries_proof_type_and_pagination_meta(): void
    {
        $this->boot();
        $this->submissionModel->shouldReceive('submission_getByWorkerWithTask')
            ->once()->with($this->workerId, 20, 0)
            ->andReturn([
                (object)['id' => 55, 'task_id' => 11, 'task_title' => 'تسک', 'status' => 'in_progress',
                         'reward_amount' => '3000', 'reward_currency' => 'irt', 'task_proof_type' => 'code',
                         'updated_at' => '2026-11-07 10:00:00'],
            ]);
        $this->submissionModel->shouldReceive('submission_countByWorkerWithTask')
            ->once()->with($this->workerId)->andReturn(41);

        $out = $this->capture(fn () => $this->controller()->mySubmissions());
        $this->assertSame(200, $out['__status']);
        $row = $out['data']['submissions'][0] ?? [];
        $this->assertSame('code', (string)($row['proof_type'] ?? ''));
        $meta = $out['meta'] ?? [];
        $this->assertSame(41, (int)($meta['total'] ?? -1));
        $this->assertSame(3, (int)($meta['last_page'] ?? -1), 'last_page = ceil(41/20)');
    }

    // ── blob ثبت رویداد (هم‌قرارداد وب) ───────────────────────────

    /** @test */
    public function payload_carries_event_blob_with_capped_schema_description(): void
    {
        $this->boot();
        $longDesc = str_repeat('x', 1500);
        $this->submissionModel->shouldReceive('submission_findForProof')
            ->once()->andReturn($this->submission('text', [
                'proof_schema' => json_encode(['description' => $longDesc, 'fields' => ['note']], JSON_UNESCAPED_UNICODE),
            ]));
        $this->executorService->shouldReceive('submitProof')
            ->once()->with(55, $this->workerId, m::on(static function (array $p): bool {
                $blob = json_decode((string)($p['proof_data'] ?? ''), true);
                if (!is_array($blob)) return false;
                $schema = is_array($blob['proof_schema'] ?? null) ? $blob['proof_schema'] : [];
                $fields = is_array($blob['submitted_fields'] ?? null) ? $blob['submitted_fields'] : [];
                return mb_strlen((string)($schema['description'] ?? '')) === 1000
                    && ($blob['proof_type'] ?? '') === 'text'
                    && ($fields['proof_text'] ?? false) === true
                    && ($fields['proof_url'] ?? true) === false
                    && ($fields['proof_code'] ?? true) === false
                    && ($fields['proof_file'] ?? true) === false
                    && ($p['task_execution_id'] ?? 0) === 55
                    && ($p['proof_type'] ?? '') === 'text';
            }))
            ->andReturn(['success' => true, 'message' => 'ok']);

        $this->setBody(['note' => 'توضیح کامل انجام تسک سفارشی']);
        $out = $this->capture(fn () => $this->controller()->submitProof(55));
        $this->assertSame(200, $out['__status']);
    }
}
