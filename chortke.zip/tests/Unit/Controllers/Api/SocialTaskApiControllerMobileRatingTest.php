<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\SocialTaskApiController;
use App\Services\Gamification\TrustService;
use App\Services\Interaction\RatingService;
use App\Services\SocialTask\SocialTaskService;
use App\Services\User\UserService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCRATE-MOBILE-01 (۲۰۲۶-۱۱-۱۰) — پوشش قرارداد ستاره‌های رأی کاربران
 * در پاسخ‌های API که اپ موبایل برای جزئیات/پنل کمپین سوشیال مصرف می‌کند
 * (قرینهٔ SocialTaskApiControllerTasksRatingTest برای tasks()).
 *
 * لنزها:
 *  ① showAd غیرمالک: sanitize شامل avg_rating/rating_count/my_rating و
 *     همچنان بدون فیلدهای مالکانه (گارد IDOR Issue #5 دست‌نخورده)
 *  ② کمپین بدون رأی = صفر صادقانه + my_rating=null (نه حذف کلید)
 *  ③ showAd مالک: آبجکت کامل + avg_rating/rating_count (بدون my_rating —
 *     مالک رأی نمی‌دهد)
 *  ④ آگهی غیرسوشیال (seo): هیچ فیلد/کوئری rating (گارد type)
 *  ⑤ myAds: هر ردیف avg_rating/rating_count از یک batch؛ صفحهٔ خالی =
 *     هیچ کوئری امتیازی
 *  ⑥ تبلیغ غایب → 404؛ بدون احراز هویت → 401 (رگرسیون)
 */
final class SocialTaskApiControllerMobileRatingTest extends TestCase
{
    private SocialTaskService&MockInterface $service;
    private TrustService&MockInterface $trust;
    private UserService&MockInterface $userService;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private LoggerInterface&MockInterface $logger;
    private Response $response;
    private Mockery\MockInterface $ratingService;

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): SocialTaskApiController
    {
        return new SocialTaskApiController(
            $this->service,
            $this->trust,
            $this->userService,
            null,
            null,
            $this->logger,
            // 🛡️ FIX-SOCRATE-DISPLAY-01: سرویس امتیاز — mock تزریقی
            $this->ratingService,
        );
    }

    /** @param int|null $userId کاربر لاگین (null = بدون احراز هویت) */
    private function boot(?int $userId = 7): void
    {
        $this->service = Mockery::mock(SocialTaskService::class);
        $this->trust = Mockery::mock(TrustService::class);
        $this->userService = Mockery::mock(UserService::class);
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn($userId === null ? null : (object)['id' => $userId])->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();

        app(\Core\Container::class)->instance(Request::class, $this->request);

        $this->session = Mockery::mock(Session::class);
        $this->response = new Response();

        $this->ratingService = Mockery::mock(RatingService::class);
        $this->ratingService->shouldReceive('getRatingsSummary')->byDefault()->andReturn([]);
        $this->ratingService->shouldReceive('getUserRating')->byDefault()->andReturn(null);
    }

    /** اجرای callback و گرفتن پاسخ JSON به‌همراه status (الگوی SocialTaskApiControllerTasksRatingTest). @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    /** کمپین سوشیالِ متعلق به تبلیغ‌دهندهٔ دیگری + فیلد مالکانهٔ حساس برای اثبات گارد @return \stdClass */
    private function foreignSocialAd(): object
    {
        return (object)[
            'id' => 34, 'user_id' => 77, 'type' => 'social_task', 'title' => 'کمپین سوشیال',
            'description' => 'توضیح', 'target_url' => 'https://social.example/p', 'link' => 'https://social.example/p',
            'platform' => 'instagram', 'action_type' => 'view', 'price_per_task' => 5000,
            'status' => 'active', 'budget' => 100000, 'total_budget' => 100000,
        ];
    }

    // ─────────────────────────────────────────────────────────────
    // ① showAd غیرمالک — sanitize + ستاره‌ها
    // ─────────────────────────────────────────────────────────────

    public function test_show_ad_non_owner_includes_ratings_and_my_rating(): void
    {
        $this->boot(userId: 7);
        $this->service->shouldReceive('getAdById')->once()->with(34)->andReturn($this->foreignSocialAd());
        $this->ratingService->shouldReceive('getRatingsSummary')->once()->with('social_task', [34])->andReturn([
            34 => ['avg' => 4.5, 'count' => 9],
        ]);
        $this->ratingService->shouldReceive('getUserRating')->once()->with(7, 'social_task', 34)->andReturn(4);

        $out = $this->capture(fn () => $this->controller()->showAd('34'));
        $this->assertSame(200, $out['__status']);
        $data = $out['data'];
        $this->assertSame(4.5, (float)$data['avg_rating']);
        $this->assertSame(9, (int)$data['rating_count']);
        $this->assertSame(4, $data['my_rating']);
        // گارد IDOR دست‌نخورده: فیلدهای مالکانه در sanitize نیستند
        $this->assertArrayNotHasKey('budget', $data);
        $this->assertArrayNotHasKey('total_budget', $data);
        // فیلدهای عمومی sanitize همچنان حاضرند
        $this->assertSame('کمپین سوشیال', $data['title']);
        $this->assertSame(5000, (int)$data['reward_amount']);
    }

    public function test_show_ad_non_owner_without_votes_is_honest_zero_and_null_my_rating(): void
    {
        $this->boot(userId: 7);
        $this->service->shouldReceive('getAdById')->once()->with(34)->andReturn($this->foreignSocialAd());
        $this->ratingService->shouldReceive('getRatingsSummary')->once()->with('social_task', [34])->andReturn([]);
        $this->ratingService->shouldReceive('getUserRating')->once()->with(7, 'social_task', 34)->andReturn(null);

        $out = $this->capture(fn () => $this->controller()->showAd('34'));
        $this->assertSame(200, $out['__status']);
        // صفر صادقانه + null صریح — نه حذف کلید
        $this->assertSame(0.0, (float)$out['data']['avg_rating']);
        $this->assertSame(0, (int)$out['data']['rating_count']);
        $this->assertArrayHasKey('my_rating', $out['data']);
        $this->assertNull($out['data']['my_rating']);
    }

    // ─────────────────────────────────────────────────────────────
    // ③ showAd مالک — پاسخ کامل + ستاره‌ها
    // ─────────────────────────────────────────────────────────────

    public function test_show_ad_owner_gets_full_object_with_ratings(): void
    {
        $this->boot(userId: 77);
        $ad = $this->foreignSocialAd(); // مالک = کاربر لاگین
        $this->service->shouldReceive('getAdById')->once()->with(34)->andReturn($ad);
        $this->ratingService->shouldReceive('getRatingsSummary')->once()->with('social_task', [34])->andReturn([
            34 => ['avg' => 5.0, 'count' => 1],
        ]);
        // مالک my_rating نمی‌گیرد (گارد تضاد منافع سرویس)
        $this->ratingService->shouldReceive('getUserRating')->never();

        $out = $this->capture(fn () => $this->controller()->showAd('34'));
        $this->assertSame(200, $out['__status']);
        $data = $out['data'];
        $this->assertSame(5.0, (float)$data['avg_rating']);
        $this->assertSame(1, (int)$data['rating_count']);
        $this->assertArrayNotHasKey('my_rating', $data);
        // پاسخ کامل مالکانه — فیلد حساس مالک حاضر است
        $this->assertSame(100000, (int)$data['budget']);
    }

    // ─────────────────────────────────────────────────────────────
    // ④ آگهی غیرسوشیال — گارد type
    // ─────────────────────────────────────────────────────────────

    public function test_show_ad_non_social_type_gets_no_rating_fields_nor_query(): void
    {
        $this->boot(userId: 7);
        $ad = (object)[
            'id' => 40, 'user_id' => 77, 'type' => 'seo', 'title' => 'آگهی سئو',
            'description' => 'd', 'target_url' => 'https://t.example', 'platform' => 'general',
            'action_type' => 'view', 'price_per_task' => 0, 'status' => 'active',
        ];
        $this->service->shouldReceive('getAdById')->once()->with(40)->andReturn($ad);
        // هیچ کوئری امتیازی برای آگهی غیرسوشیال (id تصادفی رأی سوشیال نگیرد)
        $this->ratingService->shouldReceive('getRatingsSummary')->never();
        $this->ratingService->shouldReceive('getUserRating')->never();

        $out = $this->capture(fn () => $this->controller()->showAd('40'));
        $this->assertSame(200, $out['__status']);
        $this->assertArrayNotHasKey('avg_rating', $out['data']);
        $this->assertArrayNotHasKey('rating_count', $out['data']);
        $this->assertArrayNotHasKey('my_rating', $out['data']);
    }

    // ─────────────────────────────────────────────────────────────
    // ⑤ myAds — batch + فیلدها
    // ─────────────────────────────────────────────────────────────

    public function test_my_ads_includes_community_rating_from_batch_summary(): void
    {
        $this->boot(userId: 77);
        $this->service->shouldReceive('getUserAds')->once()->with(77, 20, 0)->andReturn([
            [
                (object)['id' => 34, 'title' => 'کمپین الف', 'type' => 'social_task', 'status' => 'active'],
                (object)['id' => 35, 'title' => 'کمپین ب', 'type' => 'social_task', 'status' => 'active'],
            ],
            2,
        ]);
        // یک کوئری batch برای کل صفحه — نه per-row
        $this->ratingService->shouldReceive('getRatingsSummary')->once()->with('social_task', [34, 35])->andReturn([
            34 => ['count' => 3, 'avg' => 2.5],
        ]);

        $out = $this->capture(fn () => $this->controller()->myAds());
        $this->assertSame(200, $out['__status']);
        $rows = $out['data'];
        $this->assertCount(2, $rows);
        $this->assertSame(2.5, (float)$rows[0]['avg_rating']);
        $this->assertSame(3, (int)$rows[0]['rating_count']);
        // کمپین بدون رأی — صفر صادقانه
        $this->assertSame(0.0, (float)$rows[1]['avg_rating']);
        $this->assertSame(0, (int)$rows[1]['rating_count']);
        $this->assertSame(2, (int)$out['meta']['total']);
    }

    public function test_my_ads_empty_page_skips_rating_query(): void
    {
        $this->boot(userId: 77);
        $this->service->shouldReceive('getUserAds')->once()->andReturn([[], 0]);
        $this->ratingService->shouldReceive('getRatingsSummary')->never();

        $out = $this->capture(fn () => $this->controller()->myAds());
        $this->assertSame(200, $out['__status']);
        $this->assertSame([], $out['data']);
        $this->assertSame(0, (int)$out['meta']['total']);
    }

    // ─────────────────────────────────────────────────────────────
    // ⑥ رگرسیون‌های قرارداد
    // ─────────────────────────────────────────────────────────────

    public function test_show_ad_missing_ad_returns_404(): void
    {
        $this->boot();
        $this->service->shouldReceive('getAdById')->once()->with(999)->andReturn(null);
        $this->ratingService->shouldReceive('getRatingsSummary')->never();

        $out = $this->capture(fn () => $this->controller()->showAd('999'));
        $this->assertSame(404, $out['__status']);
    }

    public function test_show_ad_requires_authentication(): void
    {
        $this->boot(userId: null);
        $this->service->shouldReceive('getAdById')->never();

        $out = $this->capture(fn () => $this->controller()->showAd('34'));
        $this->assertSame(401, $out['__status']);
        $this->assertFalse((bool)($out['success'] ?? true));
    }
}
