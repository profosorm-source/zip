<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\InteractionApiController;
use App\Enums\ModuleContext;
use App\Models\VitrineRequest;
use App\Services\Interaction\FavoriteService;
use App\Services\Interaction\RatingService;
use App\Services\Interaction\ReportService;
use App\Services\Seo\SeoService;
use App\Services\SocialTask\SocialTaskService;
use App\Services\VitrineService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCGUARD-01 (۲۰۲۶-۱۱-۰۹) — رفتارِ بستن حفرهٔ pre-existing:
 * «عدم گارد social_task در API عمومی تعاملات».
 *
 * پیش از فیکس: POST /api/v1/interactions/rate|report با type=social_task
 * بی‌گارد مستقیم به Rating/ReportService می‌رفت — و همین API عمومی تنها مسیر
 * زندهٔ امتیازدهی/گزارش سوشیال بود (روت وب ۴۲۲ و اندپوینت اپ ندارد).
 * اکنون (قرینهٔ FIX-SEO3-01):
 *   ① social_task → SocialTaskService گاردشده (مالک کمپین رد؛ فقط مجریِ
 *      اجرای تأییدشدهٔ همین تسک؛ ستاره‌ها ۱..۵)
 *   ② شکست گارد → ۴۲۲ + SOCIAL_RATE_GUARDED / SOCIAL_REPORT_GUARDED
 *      با پاسِ پیام فارسی سرویس
 *   ③ کامنت از API به سرویس می‌رسد (توازن API/وب — FIX-R15C)
 *   ④ سایر type ها همان مسیر مستقیم قبلی؛ شاخهٔ seo_task دست‌نخورده
 */
final class InteractionApiControllerSocialGuardTest extends TestCase
{
    private Request&MockInterface $request;
    private LoggerInterface&MockInterface $logger;
    private RatingService&MockInterface $ratingService;
    private ReportService&MockInterface $reportService;

    protected function tearDown(): void
    {
        Mockery::close();
        // mockهای Container نباید به تست‌های بعدی نشت کنند (Pkg6 در suite کامل mock می‌گرفت)
        app(\Core\Container::class)->forget(SocialTaskService::class);
        app(\Core\Container::class)->forget(Request::class);
        parent::tearDown();
    }

    private function boot(int $userId = 7): void
    {
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $user = (object)['id' => $userId];
        $this->request->shouldReceive('getUser')->andReturn($user)->byDefault();
        $this->request->shouldReceive('int')->byDefault()->andReturnUsing(static fn(string $k = 'id') => 0);

        // BaseController سازنده: request/response/... را از Container می‌گیرد
        // (null ?? app(Request::class)) — mock را در Container می‌بندیم (الگوی P3)
        app(\Core\Container::class)->instance(Request::class, $this->request);

        $this->ratingService = Mockery::mock(RatingService::class);
        $this->reportService = Mockery::mock(ReportService::class);
    }

    private function controller(): InteractionApiController
    {
        return new InteractionApiController(
            Mockery::mock(FavoriteService::class),
            $this->ratingService,
            $this->reportService,
            Mockery::mock(VitrineService::class),
            Mockery::mock(VitrineRequest::class),
            $this->logger,
        );
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    /** اجرای callback و گرفتن پاسخ JSON به‌همراه status (الگوی SeoTaskApiControllerTest). @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    /** سرویس سوشیال را در Container (app()) با mock عوض می‌کند — الگوی P3AccountDeletionControllerPinTest. */
    private function overrideSocial(MockInterface $social): void
    {
        app(\Core\Container::class)->instance(SocialTaskService::class, $social);
    }

    // ─────────────── ① مسیر گاردشده + کامنت ───────────────

    public function test_rate_social_task_passes_through_guarded_service_with_comment(): void
    {
        $this->boot();
        $social = Mockery::mock(SocialTaskService::class);
        $social->shouldReceive('rateTask')->once()->with(7, 11, 5, 'کیفیت خوبی داشت')
            ->andReturn(['success' => true, 'message' => 'امتیاز با موفقیت ثبت شد']);
        $this->overrideSocial($social);
        $this->ratingService->shouldReceive('getAverageRating')->once()->with('social_task', 11)->andReturn(4.5);

        $this->setBody([
            'type' => 'social_task', 'id' => 11, 'rating' => 5,
            'comment' => 'کیفیت خوبی داشت', 'context' => 'social_tasks',
        ]);

        $out = $this->capture(fn() => $this->controller()->rate());
        self::assertSame(200, $out['__status']);
        self::assertTrue($out['success']);
        // شکل پاسخ success(): پیام در data.message است (مثل شاخهٔ seo_task)
        self::assertSame('امتیاز با موفقیت ثبت شد.', $out['data']['message']);
        // json_encode بدون PRESERVE_ZERO_FRACTION کسر صفر را می‌اندازد → cast float
        self::assertSame(4.5, (float)$out['data']['average_rating']);
    }

    public function test_rate_without_comment_sends_empty_string(): void
    {
        $this->boot();
        $social = Mockery::mock(SocialTaskService::class);
        $social->shouldReceive('rateTask')->once()->with(7, 11, 4, '')
            ->andReturn(['success' => true, 'message' => 'امتیاز با موفقیت ثبت شد']);
        $this->overrideSocial($social);
        $this->ratingService->shouldReceive('getAverageRating')->once()->with('social_task', 11)->andReturn(0.0);

        $this->setBody(['type' => 'social_task', 'id' => 11, 'rating' => 4, 'context' => 'social_tasks']);

        $out = $this->capture(fn() => $this->controller()->rate());
        self::assertSame(200, $out['__status']);
    }

    // ─────────────── ② شکست گارد → ۴۲۲ + کد اختصاصی ───────────────

    public function test_rate_guard_rejection_maps_to_422_social_rate_guarded(): void
    {
        $this->boot();
        $social = Mockery::mock(SocialTaskService::class);
        $social->shouldReceive('rateTask')->once()->andReturn([
            'success' => false,
            'message' => 'فقط مجریِ اجرای تأییدشده می‌تواند به این تسک امتیاز بدهد',
        ]);
        $this->overrideSocial($social);

        $this->setBody(['type' => 'social_task', 'id' => 11, 'rating' => 5, 'context' => 'social_tasks']);

        $out = $this->capture(fn() => $this->controller()->rate());
        self::assertSame(422, $out['__status']);
        self::assertFalse($out['success']);
        self::assertSame('SOCIAL_RATE_GUARDED', $out['error']['code']);
        // پیام فارسی سرویس (عاملِ رد) عیناً پاس می‌شود — مثل شاخهٔ seo_task
        self::assertSame('فقط مجریِ اجرای تأییدشده می‌تواند به این تسک امتیاز بدهد', $out['message']);
    }

    public function test_report_guard_rejection_maps_to_422_social_report_guarded(): void
    {
        $this->boot();
        $social = Mockery::mock(SocialTaskService::class);
        // گارد گزارش سوشیال: آگهی باید واقعاً موجود باشد
        $social->shouldReceive('reportTask')->once()->andReturn(['success' => false, 'message' => 'تسک یافت نشد']);
        $this->overrideSocial($social);

        $this->setBody([
            'type' => 'social_task', 'id' => 999999, 'reason' => 'spam',
            'description' => 'توضیح', 'context' => 'social_tasks',
        ]);

        $out = $this->capture(fn() => $this->controller()->report());
        self::assertSame(422, $out['__status']);
        self::assertSame('SOCIAL_REPORT_GUARDED', $out['error']['code']);
        self::assertSame('تسک یافت نشد', $out['message']);
    }

    public function test_report_social_task_passes_through_guarded_service(): void
    {
        $this->boot();
        $social = Mockery::mock(SocialTaskService::class);
        $social->shouldReceive('reportTask')->once()->with(7, 11, 'spam', 'توضیح کامل')
            ->andReturn(['success' => true, 'message' => 'گزارش شما ثبت شد و بررسی خواهد شد']);
        $this->overrideSocial($social);

        $this->setBody([
            'type' => 'social_task', 'id' => 11, 'reason' => 'spam',
            'description' => 'توضیح کامل', 'context' => 'social_tasks',
        ]);

        $out = $this->capture(fn() => $this->controller()->report());
        self::assertSame(200, $out['__status']);
        self::assertTrue($out['success']);
        self::assertSame('گزارش شما با موفقیت ثبت شد و بررسی خواهد شد.', $out['data']['message']);
    }

    // ─────────────── ④ سایر type ها: مسیر مستقیم دست‌نخورده ───────────────

    private function bindListing(?object $listing): void
    {
        $m = Mockery::mock(\App\Models\VitrineListing::class);
        $m->shouldReceive('find')->andReturn($listing);
        app(\Core\Container::class)->instance(\App\Models\VitrineListing::class, $m);
    }

    public function test_rate_other_types_rejected_422(): void
    {
        $this->boot();
        $this->overrideSocial(Mockery::mock(SocialTaskService::class));
        $this->ratingService->shouldNotReceive('rate');
        $this->setBody(['type' => 'custom_task', 'id' => 9, 'rating' => 4, 'context' => 'global']);

        $out = $this->capture(fn() => $this->controller()->rate());
        self::assertSame(422, $out['__status']);
    }

    public function test_rate_vitrine_missing_listing_404(): void
    {
        $this->boot();
        $this->overrideSocial(Mockery::mock(SocialTaskService::class));
        $this->bindListing(null);
        $this->setBody(['type' => 'vitrine_listing', 'id' => 9, 'rating' => 4, 'context' => 'global']);

        $out = $this->capture(fn() => $this->controller()->rate());
        self::assertSame(404, $out['__status']);
    }

    public function test_report_vitrine_own_listing_403(): void
    {
        $this->boot();
        $this->overrideSocial(Mockery::mock(SocialTaskService::class));
        $this->bindListing((object)['status' => 'active', 'seller_id' => 7, 'user_id' => 7]);
        $this->reportService->shouldNotReceive('submit');
        $this->setBody(['type' => 'vitrine_listing', 'id' => 9, 'reason' => 'spam', 'description' => 'x', 'context' => 'global']);

        $out = $this->capture(fn() => $this->controller()->report());
        self::assertSame(403, $out['__status']);
    }

    public function test_report_vitrine_other_listing_goes_direct(): void
    {
        $this->boot();
        $this->overrideSocial(Mockery::mock(SocialTaskService::class));
        $this->bindListing((object)['status' => 'active', 'seller_id' => 1, 'user_id' => 1]);
        $this->reportService->shouldReceive('submit')->once()
            ->with(7, 'vitrine_listing', 9, ModuleContext::GLOBAL, 'spam', 'توضیح')->andReturn(true);
        $this->setBody(['type' => 'vitrine_listing', 'id' => 9, 'reason' => 'spam', 'description' => 'توضیح', 'context' => 'global']);

        $out = $this->capture(fn() => $this->controller()->report());
        self::assertSame(200, $out['__status']);
    }
    // ─────────────── رگرسیون: شاخهٔ seo_task + کامنتِ تازه ───────────────

    public function test_rate_seo_branch_regression_with_comment_passthrough(): void
    {
        $this->boot();
        $seo = Mockery::mock(SeoService::class);
        // FIX-SOCGUARD-01 (ولیدیتور): کامنت حالا برای seo_task هم از API می‌رسد
        $seo->shouldReceive('rateTask')->once()->with(7, 11, 5, 'نظر سئو از اپ')
            ->andReturn(['success' => true, 'message' => 'امتیاز با موفقیت ثبت شد']);
        app(\Core\Container::class)->instance(SeoService::class, $seo);
        $this->ratingService->shouldReceive('getAverageRating')->once()->with('seo_task', 11)->andReturn(4.0);

        $this->setBody([
            'type' => 'seo_task', 'id' => 11, 'rating' => 5,
            'comment' => 'نظر سئو از اپ', 'context' => 'custom_tasks',
        ]);

        $out = $this->capture(fn() => $this->controller()->rate());
        self::assertSame(200, $out['__status']);
        self::assertSame(4.0, (float)$out['data']['average_rating']);
    }
}
