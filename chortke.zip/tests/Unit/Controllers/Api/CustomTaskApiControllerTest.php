<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\CustomTaskApiController;
use App\Models\Ads;
use App\Models\CustomTaskSubmissionModel;
use App\Services\CustomTask\CustomTaskExecutorService;
use Core\Container;
use Core\Database;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-06: پوشش قرارداد CustomTaskApiController — تسک سفارشی از کانال API.
 *
 * لنزها:
 *  ① فهرست تسک‌ها: فقط فیلدهای عمومی + remaining_slots
 *  ② اجراهای من: درج مستقیم + خروجی با task_title
 *  ③ جزئیات اجرا: مالکیت ۴۰۴ برای غیرمالک
 *  ④ شروع: عبور از سرویس (قرارداد نگاشت)
 *  ⑤ مدرک: URL نامعتبر ۴۲۲، میزبان لوکال ۴۲۲، موفق از مسیر سرویس
 */
final class CustomTaskApiControllerTest extends TestCase
{
    private Database $db;
    private Ads $adModel;
    private CustomTaskSubmissionModel $submissionModel;
    private CustomTaskExecutorService&MockInterface $executorService;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private LoggerInterface&MockInterface $logger;
    private Response $response;
    private int $workerId;
    private int $ownerId;
    private string $tag;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->adModel = Container::getInstance()->make(Ads::class);
        $this->submissionModel = Container::getInstance()->make(CustomTaskSubmissionModel::class);
        $this->tag = 'q6c' . bin2hex(random_bytes(4));

        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["{$this->tag}-worker", "{$this->tag}-w@example.test", 'active', 'user'],
        );
        $this->workerId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["{$this->tag}-owner", "{$this->tag}-o@example.test", 'active', 'user'],
        );
        $this->ownerId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM custom_task_submissions WHERE worker_id = ?', [$this->workerId]);
        $this->db->query('DELETE FROM ads WHERE user_id = ?', [$this->ownerId]);
        $this->db->query('DELETE FROM users WHERE id IN (?, ?)', [$this->workerId, $this->ownerId]);
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): CustomTaskApiController
    {
        // 📱 FIX-MOBCTR-01: پارامتر جدید سرویس فایل مدرک (پیش از session)
        return new CustomTaskApiController(
            $this->adModel,
            $this->submissionModel,
            $this->executorService,
            new \App\Services\CustomTask\CustomTaskProofFileService(Container::getInstance()->make(\App\Services\UploadService::class)),
            $this->session,
            $this->request,
            $this->response,
            $this->logger,
        );
    }

    private function boot(): void
    {
        $this->executorService = Mockery::mock(CustomTaskExecutorService::class);
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();
        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('10.0.0.10')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->workerId])->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();
        $this->request->shouldReceive('body')->andReturn([])->byDefault();
        $this->request->shouldReceive('header')->andReturn('')->byDefault();
        // 📱 FIX-MOBCTR-05: کانال multipart — پیش‌فرض بدون فایل
        $this->request->shouldReceive('file')->andReturn(null)->byDefault();
        $this->session = Mockery::mock(Session::class);
        $this->response = new Response();
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    /** @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    /** @param array<string, mixed> $overrides @return int ad id */
    private function seedTask(array $overrides = []): int
    {
        $fields = array_merge([
            'user_id' => $this->ownerId,
            'title' => 'تسک تست API',
            'description' => 'توضیح تسک',
            'type' => 'custom_task',
            'task_type' => 'survey',
            'status' => 'active',
            'currency' => 'irt',
            'price_per_task' => 3000.0,
            'total_budget' => 30000.0,
            'remaining_budget' => 30000.0,
            'total_count' => 10,
            'completed_count' => 0,
            'pending_count' => 0,
            'proof_type' => 'screenshot',
            'proof_description' => 'از پنل اسکرین‌شات بگیرید',
        ], $overrides);
        $cols = implode(',', array_keys($fields));
        $marks = implode(',', array_fill(0, count($fields), '?'));
        $this->db->query("INSERT INTO ads ({$cols}, created_at, updated_at) VALUES ({$marks}, NOW(), NOW())", array_values($fields));
        return (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    public function test_tasks_list_returns_public_fields_with_remaining_slots(): void
    {
        $this->boot();
        $taskId = $this->seedTask();

        $out = $this->capture(fn () => $this->controller()->tasks());
        $this->assertSame(200, $out['__status']);

        $row = null;
        foreach ($out['data']['tasks'] ?? [] as $t) {
            if ((int)$t['id'] === $taskId) { $row = $t; break; }
        }
        $this->assertNotNull($row, 'تسک seed در فهرست');
        $this->assertSame('تسک تست API', $row['title'] ?? '');
        $this->assertSame(10, $row['remaining_slots'] ?? -1);
        $this->assertArrayNotHasKey('metadata', $row);
        // 📱 FIX-MOBCTR-05 (A3-N3/A3-N7): نوع مدرک در ردیف + meta صفحه‌بندی
        $this->assertSame('screenshot', (string)($row['proof_type'] ?? ''), 'proof_type باید نرمال‌شده در لیست باشد');
        $this->assertSame('از پنل اسکرین‌شات بگیرید', (string)($row['proof_description'] ?? ''));
        $meta = $out['meta'] ?? [];
        $this->assertSame(1, (int)($meta['total'] ?? 0), 'meta.total هم‌شرط لیست');
        $this->assertSame(1, (int)($meta['current_page'] ?? 0));
        $this->assertSame(1, (int)($meta['last_page'] ?? 0));
        $this->assertGreaterThanOrEqual(1, (int)($meta['per_page'] ?? 0));
    }

    public function test_my_submissions_lists_rows_with_task_title(): void
    {
        $this->boot();
        $taskId = $this->seedTask();
        $this->db->query(
            "INSERT INTO custom_task_submissions (task_id, worker_id, status, reward_amount, reward_currency, created_at, updated_at)
             VALUES (?, ?, 'in_progress', 3000.0000, 'irt', NOW(), NOW())",
            [$taskId, $this->workerId],
        );

        $out = $this->capture(fn () => $this->controller()->mySubmissions());
        $this->assertSame(200, $out['__status']);
        $rows = $out['data']['submissions'] ?? [];
        $this->assertNotEmpty($rows);
        $this->assertSame('تسک تست API', $rows[0]['task_title'] ?? '');
        $this->assertSame('in_progress', $rows[0]['status'] ?? '');
        // 📱 FIX-MOBCTR-05: نوع مدرک تسک در ردیف + meta
        $this->assertSame('screenshot', (string)($rows[0]['proof_type'] ?? ''));
        $this->assertSame(1, (int)($out['meta']['total'] ?? 0), 'meta.total از شمارندهٔ worker');
    }

    public function test_show_submission_rejects_non_owner(): void
    {
        $this->boot();
        $taskId = $this->seedTask();
        $this->db->query(
            "INSERT INTO custom_task_submissions (task_id, worker_id, status, created_at, updated_at) VALUES (?, ?, 'in_progress', NOW(), NOW())",
            [$taskId, $this->ownerId], // متعلق به owner نه worker
        );
        $submissionId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');

        $out = $this->capture(fn () => $this->controller()->showSubmission($submissionId));
        $this->assertSame(404, $out['__status']);
    }

    public function test_start_delegates_to_executor_service(): void
    {
        $this->boot();
        $taskId = $this->seedTask();
        // 🛡️ FIX-M22-MED (N1/D2-N2): شکل واقعی startTask یعنی {success, submission_id,
        // deadline} — قبلاً mock کلید data می‌ساخت که سرویس هرگز برنمی‌گرداند و
        // کلاینت data:[] می‌گرفت.
        $this->executorService->shouldReceive('startTask')
            ->once()
            ->with($taskId, $this->workerId)
            ->andReturn(['success' => true, 'submission_id' => 77, 'deadline' => '2026-12-01 12:00:00', 'message' => 'شروع شد']);

        $out = $this->capture(fn () => $this->controller()->start($taskId));
        $this->assertSame(200, $out['__status']);
        $this->assertSame(77, (int)($out['data']['submission_id'] ?? 0));
        $this->assertSame('2026-12-01 12:00:00', (string)($out['data']['deadline'] ?? ''));
    }

    public function test_start_maps_service_error(): void
    {
        $this->boot();
        $taskId = $this->seedTask();
        $this->executorService->shouldReceive('startTask')
            ->once()
            ->andReturn(['success' => false, 'message' => 'ظرفیت تکمیل است']);

        $out = $this->capture(fn () => $this->controller()->start($taskId));
        $this->assertSame(422, $out['__status']);
        $this->assertSame('ظرفیت تکمیل است', $out['message'] ?? '');
    }

    public function test_submit_proof_rejects_invalid_url(): void
    {
        $this->boot();
        // 📱 FIX-MOBCTR-05: کنترلر حالا ردیف اجرا را با findForProof می‌خواند —
        // submission واقعی لازم است (قبلاً 422 اعتبارسنجی قبل از هر خواندنی بود)؛
        // نوع url تا مسیرِ اعتبارسنجی لینک (نه گارد فایل) آزموده شود
        $taskId = $this->seedTask(['proof_type' => 'url']);
        $this->db->query(
            "INSERT INTO custom_task_submissions (task_id, worker_id, status, created_at, updated_at) VALUES (?, ?, 'in_progress', NOW(), NOW())",
            [$taskId, $this->workerId],
        );
        $submissionId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->setBody(['proof_link' => 'not-a-url']);
        $out = $this->capture(fn () => $this->controller()->submitProof($submissionId));
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('proof_link', $out['data']['errors'] ?? []);
    }

    public function test_submit_proof_rejects_localhost_host(): void
    {
        $this->boot();
        $taskId = $this->seedTask(['proof_type' => 'url']);
        $this->db->query(
            "INSERT INTO custom_task_submissions (task_id, worker_id, status, created_at, updated_at) VALUES (?, ?, 'in_progress', NOW(), NOW())",
            [$taskId, $this->workerId],
        );
        $submissionId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->setBody(['proof_link' => 'http://127.0.0.1/proof.png']);
        $out = $this->capture(fn () => $this->controller()->submitProof($submissionId));
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('proof_link', $out['data']['errors'] ?? []);
    }

    public function test_submit_proof_passes_validated_payload_to_service(): void
    {
        $this->boot();
        // 🛡️ FIX-M22-MED (N1/D2-N1): نگاشت فیلدهای API به قرارداد جاب —
        // proof_link→proof_url و note→proof_text (قبلاً کلیدها همان‌طور خام پاس می‌شد
        // و جاب هرگز نمی‌خواندش → ۴۲۲ دائمی).
        // 📱 FIX-MOBCTR-05: submission واقعی با نوع text (هر دو کانال مجاز؛ نگاشت
        // همان‌قدر معتبر) + data پاسخ = کلیدهای واقعی جاب (A1-N8).
        $taskId = $this->seedTask(['proof_type' => 'text']);
        $this->db->query(
            "INSERT INTO custom_task_submissions (task_id, worker_id, status, created_at, updated_at) VALUES (?, ?, 'in_progress', NOW(), NOW())",
            [$taskId, $this->workerId],
        );
        $submissionId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');

        $this->executorService->shouldReceive('submitProof')
            ->once()
            ->with($submissionId, $this->workerId, Mockery::on(static function (array $data): bool {
                return ($data['proof_url'] ?? '') === 'https://cdn.example.com/p/1.png'
                    && ($data['proof_text'] ?? '') === 'گزارش نهایی'
                    && ($data['proof_type'] ?? '') === 'text';
            }))
            ->andReturn(['success' => true, 'message' => 'مدرک ثبت شد', 'auto_approve_info' => 'تا ۴۸ ساعت']);

        $this->setBody(['proof_link' => 'https://cdn.example.com/p/1.png', 'note' => 'گزارش نهایی']);
        $out = $this->capture(fn () => $this->controller()->submitProof($submissionId));
        $this->assertSame(200, $out['__status']);
        $this->assertSame('تا ۴۸ ساعت', (string)($out['data']['auto_approve_info'] ?? ''), 'A1-N8: خروجی جاب نباید دور ریخته شود');
        $this->assertSame($submissionId, (int)($out['data']['submission_id'] ?? 0));
    }
}
