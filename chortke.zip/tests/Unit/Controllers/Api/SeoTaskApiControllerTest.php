<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\SeoTaskApiController;
use App\Models\Ads;
use App\Models\SeoExecution;
use App\Services\Seo\SeoService;
use App\Services\Shared\PolicyService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\UrlGenerator;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-04 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲):
 * پوشش صددرصدی قرارداد SeoTaskApiController — تسک سئو از کانال API.
 *
 * لنزها:
 *  ① فهرست آگهی‌ها: فقط فیلدهای عمومی (نشت‌ناپذیری site_url/target_url)
 *  ② شروع: go_url مطلق + حالت اثبات؛ شکست → 422 SEO_START_FAILED
 *  ③ وضعیت اجرا: نشان سه‌حالته (کلیک/فرود/کانال) + go_url=null بعد از کلیک
 *  ④ تکمیل: اعتبارسنجی عددی + گیرِ client_mode (فقط mobile_app|mobile_web)
 *  ⑤ لغو/تاریخچه: عبور سرویس + صفحه‌بندی قرارداد paginated()
 */
final class SeoTaskApiControllerTest extends TestCase
{
    private Ads&MockInterface $adModel;
    private SeoExecution&MockInterface $executionModel;
    private SeoService&MockInterface $seoService;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private LoggerInterface&MockInterface $logger;
    private Response $response;

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): SeoTaskApiController
    {
        // UrlGenerator واقعی با محیط testing (کانonical؛ مطابق S14ControllerGatePinningTest)
        $url = new UrlGenerator('http://127.0.0.1:8090', null, '', 'testing');
        return new SeoTaskApiController(
            $this->adModel,
            $this->executionModel,
            $this->seoService,
            $url,
            $this->logger,
            $this->session,
            $this->request,
            $this->response,
            Mockery::mock(PolicyService::class),
            // 🛡️ FIX-SEO3-01: سرویس امتیاز (avg_rating فهرست) — mock تزریقی
            $this->ratingService,
        );
    }

    private function boot(int $userId = 7): void
    {
        $this->adModel = Mockery::mock(Ads::class);
        $this->executionModel = Mockery::mock(SeoExecution::class);
        $this->seoService = Mockery::mock(SeoService::class);
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $user = (object)['id' => $userId];
        $this->request->shouldReceive('getUser')->andReturn($user)->byDefault();
        $this->request->shouldReceive('int')->with('id')->andReturnUsing(static fn() => 0)->byDefault();

        $this->session = Mockery::mock(Session::class);
        $this->response = new Response();

        // 🛡️ FIX-SEO3-01: سرویس امتیاز — پیش‌فرض بدون رأی (خلاصهٔ خالی)
        $this->ratingService = Mockery::mock(\App\Services\Interaction\RatingService::class);
        $this->ratingService->shouldReceive('getRatingsSummary')->byDefault()->andReturn([]);
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    private ?Mockery\MockInterface $ratingService = null;

    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    private function executionRow(array $overrides = []): SeoExecution
    {
        // مدل واقعی props تایپ‌دار دارد — mock جزئی با مقداردهی مستقیم
        // (همان قرارداد hydrate واقعی findByUser)
        $row = array_merge([
            'id' => 5, 'ad_id' => 3, 'user_id' => 7, 'status' => 'started',
            'time_score' => 0.0, 'scroll_score' => 0.0, 'interaction_score' => 0.0,
            'quality_score' => 0.0, 'final_score' => 0.0, 'payout_amount' => 0.0,
            'ip_address' => '127.0.0.1', 'started_at' => '2026-11-02 10:00:00',
            'created_at' => '2026-11-02 10:00:00',
            'click_counted_at' => null, 'landing_verified_at' => null, 'landing_proof_channel' => null,
            'completed_at' => null,
        ], $overrides);
        $mock = Mockery::mock(SeoExecution::class)->makePartial();
        foreach ($row as $k => $v) {
            $mock->{$k} = $v;
        }
        return $mock;
    }

    // ─────────────────────────────────────────────────────────────
    // ① فهرست آگهی‌ها
    // ─────────────────────────────────────────────────────────────

    public function test_ads_lists_public_fields_only_without_target_url_leak(): void
    {
        $this->boot();
        $this->request->shouldReceive('query')->with('search', '')->andReturn('')->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();

        // 🛡️ FIX-T23-03: فهرست کاربر-محور (نه کوئری ادمین searchAdminTasks)
        $this->adModel->shouldReceive('searchActiveSeoTasksForUser')->with(7, '', 20, 0)->andReturn([
            'items' => [
                (object)[
                    'id' => 3, 'title' => 'آگهی تست', 'keyword' => 'کفش ورزشی', 'description' => 'توضیح',
                    'min_payout' => 2500.0, 'max_payout' => 5000.0, 'target_duration' => 45,
                    'currency' => 'irt',
                    'site_url' => 'https://secret-advertiser.example/landing', 'seo_landing_proof_mode' => 'pixel',
                ],
            ],
            'total' => 1,
        ]);
        $this->executionModel->shouldReceive('getUserStats')->andReturn((object)['total_executions' => 3]);

        $out = $this->capture(fn () => $this->controller()->ads());
        $this->assertSame(200, $out['__status']);
        $raw = (string)json_encode($out, JSON_UNESCAPED_UNICODE);
        // آدرس هدف آگهی هرگز در فهرست نشت نمی‌کند — فقط از مسیر go عبور داده می‌شود
        $this->assertStringNotContainsString('secret-advertiser', $raw);
        $row = $out['data'][0];
        foreach (['id', 'title', 'keyword', 'description', 'min_payout', 'max_payout', 'target_duration', 'currency', 'proof_mode'] as $key) {
            $this->assertArrayHasKey($key, $row);
        }
        // 🛡️ FIX-SEO3-01: فیلدهای بازخورد کمپین — بدون رأی = صفر صادقانه
        $this->assertArrayHasKey('avg_rating', $row);
        $this->assertArrayHasKey('rating_count', $row);
        $this->assertSame(0.0, (float)$row['avg_rating']);
        $this->assertSame(0, (int)$row['rating_count']);
        $this->assertSame('pixel', $row['proof_mode']);
        // 🛡️ FIX-T23-04: بازهٔ پاداش واقعی سئو + کلیدهای سازگاری (deprecated).
        // (کست float: رفت‌وبرگشت JSON اعداد صحیح‌مقدار را int می‌کند)
        $this->assertSame(2500.0, (float)$row['min_payout']);
        $this->assertSame(5000.0, (float)$row['max_payout']);
        $this->assertSame(45, (int)$row['target_duration']);
        $this->assertSame(2500.0, (float)$row['price_per_click']);   // alias → min_payout
        $this->assertSame(45, (int)$row['estimated_time']);         // alias → target_duration
        $this->assertSame(1, $out['meta']['total']);
    }

    /** 🛡️ FIX-SEO3-01: میانگین رأی مجریان در ردیف‌های فهرست (batch) */
    public function test_ads_includes_community_rating_from_batch_summary(): void
    {
        $this->boot();
        $this->request->shouldReceive('query')->with('search', '')->andReturn('')->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();

        $this->adModel->shouldReceive('searchActiveSeoTasksForUser')->andReturn([
            'items' => [
                (object)['id' => 3, 'title' => 'a', 'keyword' => 'k', 'min_payout' => 1.0, 'max_payout' => 2.0, 'target_duration' => 30, 'currency' => 'irt', 'seo_landing_proof_mode' => 'off'],
                (object)['id' => 4, 'title' => 'b', 'keyword' => 'k', 'min_payout' => 1.0, 'max_payout' => 2.0, 'target_duration' => 30, 'currency' => 'irt', 'seo_landing_proof_mode' => 'off'],
            ],
            'total' => 2,
        ]);
        $this->executionModel->shouldReceive('getUserStats')->andReturn((object)[]);
        $this->ratingService->shouldReceive('getRatingsSummary')->once()->with('seo_task', [3, 4])->andReturn([
            3 => ['count' => 17, 'avg' => 4.2],
        ]);

        $out = $this->capture(fn () => $this->controller()->ads());
        $rows = $out['data'];
        $this->assertSame(4.2, (float)$rows[0]['avg_rating']);
        $this->assertSame(17, (int)$rows[0]['rating_count']);
        // آگهی بدون رأی — صفر صادقانه، نه null/حذف کلید
        $this->assertSame(0.0, (float)$rows[1]['avg_rating']);
        $this->assertSame(0, (int)$rows[1]['rating_count']);
    }

    public function test_ads_requires_authentication(): void
    {
        $this->boot(userId: 0);
        $out = $this->capture(fn () => $this->controller()->ads());
        $this->assertSame(401, $out['__status']);
        $this->assertSame('UNAUTHENTICATED', $out['error']['code']);
    }

    // ─────────────────────────────────────────────────────────────
    // ② شروع تسک
    // ─────────────────────────────────────────────────────────────

    public function test_start_returns_execution_id_absolute_go_url_and_proof_mode(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(3)->byDefault();
        $this->seoService->shouldReceive('startTask')->once()->with(3, 7)->andReturn([
            'success' => true, 'message' => 'تسک SEO شروع شد.', 'execution_id' => 5,
        ]);
        $this->executionModel->shouldReceive('issueClickToken')->once()->with(5)->andReturn(str_repeat('a', 48));
        $this->adModel->shouldReceive('find')->with(3)->andReturn((object)['seo_landing_proof_mode' => 'postback']);

        $out = $this->capture(fn () => $this->controller()->start());
        $this->assertSame(201, $out['__status']);
        $this->assertSame(5, $out['data']['execution_id']);
        $this->assertSame('http://127.0.0.1:8090/seo/5/go/' . str_repeat('a', 48), $out['data']['go_url']);
        $this->assertSame('postback', $out['data']['proof_mode']);
        $this->assertSame('open_go_url_then_complete', $out['data']['next_step']);
    }

    public function test_start_failure_maps_to_422_with_service_message(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(3)->byDefault();
        $this->seoService->shouldReceive('startTask')->andReturn(['success' => false, 'message' => 'شما امروز این تسک را قبلاً انجام داده‌اید']);

        $out = $this->capture(fn () => $this->controller()->start());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('SEO_START_FAILED', $out['error']['code']);
        $this->assertStringContainsString('قبلاً', (string)$out['message']);
    }

    public function test_start_rejects_invalid_ad_id(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(0)->byDefault();
        $out = $this->capture(fn () => $this->controller()->start());
        $this->assertSame(422, $out['__status']);
        $this->seoService->shouldNotHaveReceived('startTask');
    }

    // ─────────────────────────────────────────────────────────────
    // ③ وضعیت اجرا
    // ─────────────────────────────────────────────────────────────

    public function test_execution_state_exposes_proof_badge_and_fresh_go_url(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();
        $this->executionModel->shouldReceive('findByUser')->with(5, 7)->andReturn($this->executionRow());
        $this->executionModel->shouldReceive('issueClickToken')->with(5)->andReturn(str_repeat('b', 48));
        $this->adModel->shouldReceive('find')->with(3)->andReturn((object)['seo_landing_proof_mode' => 'pixel']);

        $out = $this->capture(fn () => $this->controller()->execution());
        $this->assertSame(200, $out['__status']);
        $d = $out['data'];
        $this->assertSame('started', $d['status']);
        // 🛡️ FIX-SEO3-03: کلید راحتی سه‌حالته — بدون مهر = none
        $this->assertSame('none', $d['proof_state']);
        $this->assertFalse($d['click_counted']);
        $this->assertFalse($d['landing_verified']);
        $this->assertNull($d['click_counted_at']);
        $this->assertSame('pixel', $d['proof_mode']);
        $this->assertNotNull($d['go_url']);
    }

    public function test_execution_state_after_click_counted_has_no_go_url(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();
        $this->executionModel->shouldReceive('findByUser')->with(5, 7)->andReturn(
            $this->executionRow(['click_counted_at' => '2026-11-02 10:01:00'])
        );
        // توکن دیگر صادر نمی‌شود — بازکردن مجدد لازم نیست
        $this->executionModel->shouldNotReceive('issueClickToken');
        $this->adModel->shouldReceive('find')->with(3)->andReturn((object)['seo_landing_proof_mode' => 'off']);

        $out = $this->capture(fn () => $this->controller()->execution());
        $d = $out['data'];
        $this->assertTrue($d['click_counted']);
        // 🛡️ FIX-SEO3-03: کلیک مهرشده بدون فرود = click (پلهٔ ۸۵٪)
        $this->assertSame('click', $d['proof_state']);
        $this->assertNull($d['go_url']);
    }

    /** 🛡️ FIX-SEO3-03: فرود تأییدشده = landing (پلهٔ کامل) */
    public function test_execution_state_landing_verified_is_landing(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();
        $this->executionModel->shouldReceive('findByUser')->with(5, 7)->andReturn(
            $this->executionRow(['click_counted_at' => '2026-11-02 10:01:00', 'landing_verified_at' => '2026-11-02 10:02:00'])
        );
        $this->adModel->shouldReceive('find')->with(3)->andReturn((object)['seo_landing_proof_mode' => 'pixel']);

        $out = $this->capture(fn () => $this->controller()->execution());
        $d = $out['data'];
        $this->assertSame('landing', $d['proof_state']);
        $this->assertTrue($d['landing_verified']);
    }

    public function test_execution_state_404_for_foreign_execution(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();
        $this->executionModel->shouldReceive('findByUser')->with(5, 7)->andReturn(null);

        $out = $this->capture(fn () => $this->controller()->execution());
        $this->assertSame(404, $out['__status']);
        $this->assertSame('EXECUTION_NOT_FOUND', $out['error']['code']);
    }

    // ─────────────────────────────────────────────────────────────
    // ④ تکمیل
    // ─────────────────────────────────────────────────────────────

    public function test_complete_rejects_non_numeric_engagement_fields(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();
        $this->setBody(['duration' => 'abc', 'scroll_depth' => 50, 'interactions' => 3]);

        $out = $this->capture(fn () => $this->controller()->complete());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('duration', $out['data']['errors']);
    }

    public function test_complete_rejects_web_client_mode_from_api_channel(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();
        $this->setBody([
            'duration' => 60, 'scroll_depth' => 80.5, 'interactions' => 4,
            'interaction_types' => ['tap'], 'client_mode' => 'web',
        ]);

        $out = $this->capture(fn () => $this->controller()->complete());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('client_mode', $out['data']['errors']);
        $this->seoService->shouldNotHaveReceived('completeTask');
    }

    public function test_complete_accepts_mobile_app_mode_and_passes_service_contract(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();
        $this->setBody([
            'duration' => 60, 'scroll_depth' => 80.5, 'interactions' => 4,
            'active_time' => 55, 'target_opened' => true, 'focus_blur_count' => 1,
            'interaction_types' => ['tap', 'scroll'], 'client_mode' => 'mobile_app',
        ]);

        $this->seoService->shouldReceive('completeTask')->once()->with(5, 7, Mockery::on(static function (array $eng): bool {
            return $eng['duration'] === 60
                && $eng['scroll_depth'] === 80.5
                && $eng['interactions'] === 4
                && $eng['client_mode'] === 'mobile_app'
                && $eng['target_opened'] === 1
                && $eng['interaction_types'] === ['tap', 'scroll']
                && isset($eng['behavior']['client_mode'])
                && $eng['behavior']['client_mode'] === 'mobile_app';
        }))->andReturn(['success' => true, 'message' => 'در صف پردازش', 'payout' => 2125]);

        $out = $this->capture(fn () => $this->controller()->complete());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['success']);
    }

    public function test_complete_failure_maps_to_422(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();
        $this->setBody(['duration' => 60, 'scroll_depth' => 80, 'interactions' => 4, 'client_mode' => 'mobile_app', 'interaction_types' => []]);
        $this->seoService->shouldReceive('completeTask')->andReturn(['success' => false, 'message' => 'این تسک قابل انجام نیست']);

        $out = $this->capture(fn () => $this->controller()->complete());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('SEO_COMPLETE_FAILED', $out['error']['code']);
    }

    // ─────────────────────────────────────────────────────────────
    // ⑤ لغو / تاریخچه
    // ─────────────────────────────────────────────────────────────

    public function test_cancel_passes_service_and_maps_failure(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('id')->andReturn(5)->byDefault();

        $this->seoService->shouldReceive('cancelTask')->once()->with(5, 7)->andReturn(['success' => true, 'message' => 'لغو شد']);
        $out = $this->capture(fn () => $this->controller()->cancel());
        $this->assertSame(200, $out['__status']);

        $this->seoService->shouldReceive('cancelTask')->andReturn(['success' => false, 'message' => 'اجرا یافت نشد']);
        $out = $this->capture(fn () => $this->controller()->cancel());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('SEO_CANCEL_FAILED', $out['error']['code']);
    }

    public function test_history_is_paginated_with_shaped_rows(): void
    {
        $this->boot();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(2)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();

        $this->executionModel->shouldReceive('getByUser')->once()->with(7, 20, 20)->andReturn([
            (object)[
                'id' => 9, 'ad_id' => 3, 'ad_title' => 'آگهی تست', 'keyword' => 'کفش', 'status' => 'completed',
                'payout_amount' => 2125.0, 'final_score' => 88.5, 'landing_verified_at' => '2026-11-02 10:05:00',
                'created_at' => '2026-11-02 10:00:00', 'completed_at' => '2026-11-02 10:05:00',
            ],
        ]);
        $this->executionModel->shouldReceive('countByUser')->once()->with(7)->andReturn(21);

        $out = $this->capture(fn () => $this->controller()->history());
        $this->assertSame(200, $out['__status']);
        $this->assertSame(21, $out['meta']['total']);
        $this->assertSame(2, $out['meta']['current_page']);
        $this->assertSame(2, $out['meta']['last_page']);
        $row = $out['data'][0];
        $this->assertSame('completed', $row['status']);
        $this->assertTrue($row['landing_verified']);
        $this->assertEqualsWithDelta(2125.0, $row['payout_amount'], 0.001);
    }

    // ─────────────────────────────────────────────────────────────
    // قرارداد ساختاری
    // ─────────────────────────────────────────────────────────────

    public function test_controller_extends_base_api_controller(): void
    {
        $this->boot();
        $this->assertInstanceOf(\App\Controllers\Api\BaseApiController::class, $this->controller());
    }

    public function test_all_six_endpoints_exist(): void
    {
        foreach (['ads', 'start', 'execution', 'complete', 'cancel', 'history'] as $m) {
            $this->assertTrue(method_exists(SeoTaskApiController::class, $m), "SeoTaskApiController::{$m} باید وجود داشته باشد");
        }
    }
}
