<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\MobileAuthController;
use App\Models\UserVerification;
use App\Contracts\AntiFraud\FraudGuardInterface;
use App\Services\Auth\AuthService;
use App\Services\Auth\LoginRiskService;
use App\Services\CaptchaService;
use App\Services\EmailService;
use App\Services\Shared\PolicyService;
use App\Services\User\UserService;
use Core\Exceptions\HttpResponseException;
use Core\RateLimiter;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-01 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲):
 * پوشش صددرصدی قرارداد MobileAuthController — چرخهٔ حساب بدون session.
 *
 * لنزها:
 *  ① ثبت‌نام: گیت قوانین (terms)، کپچای ریسک‌محور (فقط recaptcha)،
 *     گارد ضدتقلب، پاسخ عمومی ضد-افشای وجود حساب
 *  ② تأیید ایمیل با کد: قالب کد، سقف تلاش، کد غلط = پاسخ عمومی + زمان‌پرکن،
 *     idempotency روی حساب تأییدشده
 *  ③ ارسال مجدد/فراموشی رمز: پاسخ همیشگی عمومی (ضد-افشا) + سقف‌ها
 *  ④ بازنشانی رمز: قوانین رمز، اطلاع‌رسانی ابطال نشست‌ها/توکن‌ها
 */
final class MobileAuthControllerTest extends TestCase
{
    private AuthService&MockInterface $authService;
    private UserService&MockInterface $userService;
    private UserVerification&MockInterface $userVerification;
    private EmailService&MockInterface $emailService;
    private LoginRiskService&MockInterface $loginRiskService;
    private CaptchaService&MockInterface $captchaService;
    private FraudGuardInterface&MockInterface $fraudGuard;
    private RateLimiter&MockInterface $rateLimiter;
    private LoggerInterface&MockInterface $logger;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private Response $response;

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): MobileAuthController
    {
        return new MobileAuthController(
            $this->authService,
            $this->userService,
            $this->userVerification,
            $this->emailService,
            $this->loginRiskService,
            $this->captchaService,
            $this->fraudGuard,
            $this->rateLimiter,
            $this->logger,
            null, // ReferralAntiFarmingGate — اختیاری (fail-open)
            $this->session,
            $this->request,
            $this->response,
            Mockery::mock(PolicyService::class),
        );
    }

    private function boot(): void
    {
        $this->authService = Mockery::mock(AuthService::class);
        $this->userService = Mockery::mock(UserService::class);
        $this->userVerification = Mockery::mock(UserVerification::class);
        $this->emailService = Mockery::mock(EmailService::class);
        $this->loginRiskService = Mockery::mock(LoginRiskService::class);
        $this->captchaService = Mockery::mock(CaptchaService::class);
        $this->fraudGuard = Mockery::mock(FraudGuardInterface::class);
        $this->rateLimiter = Mockery::mock(RateLimiter::class);
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();
        $this->logger->shouldReceive('critical')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('10.0.0.9')->byDefault();
        $this->request->shouldReceive('userAgent')->andReturn('PHPUnit')->byDefault();

        $this->session = Mockery::mock(Session::class);
        $this->response = new Response();

        // پیش‌فرض‌های مسیر شاد: همهٔ سقف‌ها باز
        $this->rateLimiter->shouldReceive('attempt')->andReturn(true)->byDefault();
        $this->captchaService->shouldReceive('isEnabled')->andReturn(false)->byDefault();
        $this->fraudGuard->shouldReceive('checkAction')->andReturn(['allowed' => true, 'reason' => ''])->byDefault();
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    /** اجرای متد و گرفتن پاسخ JSON پرتاب‌شده */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    // ─────────────────────────────────────────────────────────────
    // ① ثبت‌نام
    // ─────────────────────────────────────────────────────────────

    public function test_register_requires_terms_acceptance(): void
    {
        $this->boot();
        $this->setBody(['full_name' => 'Ali T', 'email' => 'ali@example.com', 'password' => 'Str0ngPassw0rd!x', 'password_confirmation' => 'Str0ngPassw0rd!x']);

        $out = $this->capture(fn () => $this->controller()->register());
        $this->assertSame(422, $out['__status']);
        $this->assertFalse($out['success']);
        $this->assertArrayHasKey('terms', $out['data']['errors']);
        // هیچ سرویس پایین‌دستی نباید صدا شود
        $this->authService->shouldNotHaveReceived('register');
    }

    public function test_register_rejects_invalid_recaptcha_when_risk_engine_demands(): void
    {
        $this->boot();
        $this->captchaService->shouldReceive('isEnabled')->andReturn(true);
        $this->loginRiskService->shouldReceive('getCaptchaType')->with('register', null, null)->andReturn('recaptcha_v2');
        $this->loginRiskService->shouldReceive('recordFailure')->with('register', null, null)->byDefault();
        $this->captchaService->shouldReceive('verify')->with('', '', '')->andReturn(false);

        $this->setBody(['full_name' => 'Ali T', 'email' => 'ali@example.com', 'password' => 'Str0ngPassw0rd!x', 'password_confirmation' => 'Str0ngPassw0rd!x', 'terms' => true]);

        $out = $this->capture(fn () => $this->controller()->register());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('CAPTCHA_REQUIRED', $out['error']['code']);
    }

    public function test_register_passes_recaptcha_and_creates_account(): void
    {
        $this->boot();
        $this->captchaService->shouldReceive('isEnabled')->andReturn(true);
        $this->loginRiskService->shouldReceive('getCaptchaType')->with('register', null, null)->andReturn('recaptcha_v2');
        $this->captchaService->shouldReceive('verify')->with('', '', 'valid-token')->andReturn(true);

        $body = ['full_name' => 'Ali T', 'email' => 'ali@example.com', 'password' => 'Str0ngPassw0rd!x', 'password_confirmation' => 'Str0ngPassw0rd!x', 'terms' => '1', 'g-recaptcha-response' => 'valid-token'];
        $this->setBody($body);

        $this->authService->shouldReceive('validateRegister')->andReturn([]);
        $this->authService->shouldReceive('register')->andReturnUsing(static function (array $data) {
            // allowlist: فقط فیلدهای مجاز باید عبور کنند (بدون terms/recaptcha)
            unset($data['terms']);
            return ['success' => true, 'user' => (object)['id' => 42], 'data' => $data];
        });

        $out = $this->capture(fn () => $this->controller()->register());
        $this->assertSame(201, $out['__status']);
        $this->assertTrue($out['success']);
        $this->assertSame(42, $out['data']['user_id']);
        $this->assertSame('verify_email', $out['data']['next_step']);
        $this->assertSame('/api/v1/auth/email/verify-code', $out['data']['next_endpoint']);
    }

    public function test_register_validation_errors_map_to_validation_contract(): void
    {
        $this->boot();
        $this->setBody(['full_name' => 'A', 'email' => 'not-an-email', 'password' => 'x', 'password_confirmation' => 'y', 'terms' => true]);
        $this->authService->shouldReceive('validateRegister')->andReturn(['نام کوتاه است', 'ایمیل نامعتبر است']);

        $out = $this->capture(fn () => $this->controller()->register());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('VALIDATION_ERROR', $out['error']['code']);
        $this->assertNotEmpty($out['data']['errors']['form']);
    }

    public function test_register_fraud_guard_block_returns_403_without_details(): void
    {
        $this->boot();
        $this->setBody(['full_name' => 'Ali T', 'email' => 'ali@example.com', 'password' => 'Str0ngPassw0rd!x', 'password_confirmation' => 'Str0ngPassw0rd!x', 'terms' => true]);
        $this->authService->shouldReceive('validateRegister')->andReturn([]);
        $this->fraudGuard->shouldReceive('checkAction')->andReturn(['allowed' => false, 'reason' => 'disposable-email']);

        $out = $this->capture(fn () => $this->controller()->register());
        $this->assertSame(403, $out['__status']);
        $this->assertSame('REGISTRATION_BLOCKED', $out['error']['code']);
        // دلیل داخلی هرگز به پاسخ نشت نمی‌کند
        $this->assertStringNotContainsString('disposable-email', (string)$out['message']);
    }

    public function test_register_duplicate_email_gets_generic_error_no_enumeration(): void
    {
        $this->boot();
        $this->setBody(['full_name' => 'Ali T', 'email' => 'taken@example.com', 'password' => 'Str0ngPassw0rd!x', 'password_confirmation' => 'Str0ngPassw0rd!x', 'terms' => true]);
        $this->authService->shouldReceive('validateRegister')->andReturn([]);
        $this->authService->shouldReceive('register')->andReturn(['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.']);

        $out = $this->capture(fn () => $this->controller()->register());
        $this->assertSame(400, $out['__status']);
        $this->assertSame('REGISTER_FAILED', $out['error']['code']);
        $this->assertStringNotContainsString('قبلاً ثبت شده', (string)$out['message']);
    }

    public function test_register_is_rate_limited_per_ip(): void
    {
        $this->boot();
        $this->rateLimiter->shouldReceive('attempt')->andReturn(false)->byDefault();
        $this->setBody(['terms' => true]);

        $out = $this->capture(fn () => $this->controller()->register());
        $this->assertSame(429, $out['__status']);
        $this->assertSame('RATE_LIMITED', $out['error']['code']);
    }

    // ─────────────────────────────────────────────────────────────
    // ② تأیید ایمیل با کد
    // ─────────────────────────────────────────────────────────────

    public function test_verify_code_rejects_malformed_input(): void
    {
        $this->boot();
        // ایمیل نامعتبر → خطای email
        $this->setBody(['email' => 'not-an-email', 'code' => 'A1B2C3']);
        $out = $this->capture(fn () => $this->controller()->verifyEmailCode());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('email', $out['data']['errors']);

        // کد نامعتبر (۵ کاراکتر / کاراکتر غیرمجاز) → خطای code
        $this->setBody(['email' => 'ali@example.com', 'code' => '12 45']);
        $out = $this->capture(fn () => $this->controller()->verifyEmailCode());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('code', $out['data']['errors']);
    }

    public function test_verify_code_invalid_or_expired_returns_generic_invalid(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ali@example.com', 'code' => 'A1B2C3']);
        $this->userService->shouldReceive('findByEmail')->andReturn((object)['id' => 42, 'email_verified_at' => null]);
        $this->userVerification->shouldReceive('findValidCode')->andReturn(null);

        $out = $this->capture(fn () => $this->controller()->verifyEmailCode());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('INVALID_CODE', $out['error']['code']);
        $this->userService->shouldNotHaveReceived('verifyEmail');
    }

    public function test_verify_code_unknown_user_gets_same_generic_invalid_response(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ghost@example.com', 'code' => 'A1B2C3']);
        $this->userService->shouldReceive('findByEmail')->andReturn(null);

        $out = $this->capture(fn () => $this->controller()->verifyEmailCode());
        // همان قرارداد «کد نامعتبر» — کاربر غایب از موجودیت حساب افشا نمی‌شود
        $this->assertSame(422, $out['__status']);
        $this->assertSame('INVALID_CODE', $out['error']['code']);
    }

    public function test_verify_code_success_marks_verified_and_points_to_login(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ali@example.com', 'code' => 'A1B2C3']);
        $this->userService->shouldReceive('findByEmail')->andReturn((object)['id' => 42, 'email_verified_at' => null]);
        $this->userVerification->shouldReceive('findValidCode')->with(42, 'A1B2C3', 'email')->andReturn((object)['id' => 7]);
        $this->userService->shouldReceive('verifyEmail')->once()->with(42);
        $this->userVerification->shouldReceive('markVerified')->once()->with(7);

        $out = $this->capture(fn () => $this->controller()->verifyEmailCode());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['data']['email_verified']);
        $this->assertSame('login', $out['data']['next_step']);
    }

    public function test_verify_code_already_verified_is_idempotent_success(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ali@example.com', 'code' => 'A1B2C3']);
        $this->userService->shouldReceive('findByEmail')->andReturn((object)['id' => 42, 'email_verified_at' => '2026-01-01 00:00:00']);

        $out = $this->capture(fn () => $this->controller()->verifyEmailCode());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['data']['email_verified']);
        $this->userService->shouldNotHaveReceived('verifyEmail');
        $this->userVerification->shouldNotHaveReceived('findValidCode');
    }

    public function test_verify_code_is_rate_limited(): void
    {
        $this->boot();
        $this->rateLimiter->shouldReceive('attempt')->andReturn(false)->byDefault();
        $this->setBody(['email' => 'ali@example.com', 'code' => 'A1B2C3']);

        $out = $this->capture(fn () => $this->controller()->verifyEmailCode());
        $this->assertSame(429, $out['__status']);
    }

    // ─────────────────────────────────────────────────────────────
    // ③ ارسال مجدد تأییدیه / فراموشی رمز
    // ─────────────────────────────────────────────────────────────

    public function test_resend_returns_generic_success_even_for_unknown_email(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ghost@example.com']);
        $this->userService->shouldReceive('findByEmail')->andReturn(null);

        $out = $this->capture(fn () => $this->controller()->resendVerification());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['data']['sent']);
        $this->emailService->shouldNotHaveReceived('sendVerificationEmail');
    }

    public function test_resend_rotates_token_and_sends_email_for_unverified_user(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ali@example.com']);
        $user = (object)['id' => 42, 'email_verified_at' => null];
        $this->userService->shouldReceive('findByEmail')->andReturn($user);
        $this->userService->shouldReceive('update')->once()->with(42, Mockery::on(static fn(array $d) => isset($d['email_verification_token']) && strlen((string)$d['email_verification_token']) === 64));
        $this->userVerification->shouldReceive('upsertOtp')->once()->with(42, Mockery::pattern('/^[a-f0-9]{64}$/'), Mockery::pattern('/^[A-Z0-9]{6}$/'), Mockery::type('string'), 'email');
        $this->emailService->shouldReceive('sendVerificationEmail')->once()->with(42, Mockery::pattern('/^[a-f0-9]{64}$/'));

        $out = $this->capture(fn () => $this->controller()->resendVerification());
        $this->assertSame(200, $out['__status']);
    }

    public function test_resend_does_nothing_for_verified_user(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ali@example.com']);
        $this->userService->shouldReceive('findByEmail')->andReturn((object)['id' => 42, 'email_verified_at' => '2026-01-01 00:00:00']);

        $out = $this->capture(fn () => $this->controller()->resendVerification());
        $this->assertSame(200, $out['__status']);
        $this->emailService->shouldNotHaveReceived('sendVerificationEmail');
    }

    public function test_resend_is_rate_limited(): void
    {
        $this->boot();
        $this->rateLimiter->shouldReceive('attempt')->andReturn(false)->byDefault();
        $this->setBody(['email' => 'ali@example.com']);

        $out = $this->capture(fn () => $this->controller()->resendVerification());
        $this->assertSame(429, $out['__status']);
    }

    public function test_forgot_password_always_returns_generic_success(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ali@example.com']);
        $this->authService->shouldReceive('requestPasswordReset')->once()->with('ali@example.com');

        $out = $this->capture(fn () => $this->controller()->forgotPassword());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['data']['sent']);
    }

    public function test_forgot_password_invalid_email_still_generic_success(): void
    {
        $this->boot();
        $this->setBody(['email' => 'not-an-email']);

        $out = $this->capture(fn () => $this->controller()->forgotPassword());
        $this->assertSame(200, $out['__status']);
        $this->authService->shouldNotHaveReceived('requestPasswordReset');
    }

    public function test_forgot_password_infra_failure_stays_generic(): void
    {
        $this->boot();
        $this->setBody(['email' => 'ali@example.com']);
        $this->authService->shouldReceive('requestPasswordReset')->andThrow(new \RuntimeException('SMTP down'));

        $out = $this->capture(fn () => $this->controller()->forgotPassword());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['data']['sent']);
    }

    public function test_forgot_password_is_rate_limited(): void
    {
        $this->boot();
        $this->rateLimiter->shouldReceive('attempt')->andReturn(false)->byDefault();
        $this->setBody(['email' => 'ali@example.com']);

        $out = $this->capture(fn () => $this->controller()->forgotPassword());
        $this->assertSame(429, $out['__status']);
    }

    // ─────────────────────────────────────────────────────────────
    // ④ بازنشانی رمز
    // ─────────────────────────────────────────────────────────────

    public function test_reset_password_validates_token_password_and_confirmation(): void
    {
        $this->boot();

        // بدون توکن
        $this->setBody(['password' => 'Str0ngPassw0rd!x', 'password_confirm' => 'Str0ngPassw0rd!x']);
        $out = $this->capture(fn () => $this->controller()->resetPassword());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('token', $out['data']['errors']);

        // رمز کوتاه
        $this->setBody(['token' => str_repeat('a', 64), 'password' => 'short', 'password_confirm' => 'short']);
        $out = $this->capture(fn () => $this->controller()->resetPassword());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('password', $out['data']['errors']);

        // عدم تطابق تکرار
        $this->setBody(['token' => str_repeat('a', 64), 'password' => 'Str0ngPassw0rd!x', 'password_confirm' => 'Different123!']);
        $out = $this->capture(fn () => $this->controller()->resetPassword());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('password_confirm', $out['data']['errors']);
    }

    public function test_reset_password_invalid_token_returns_422(): void
    {
        $this->boot();
        $this->setBody(['token' => str_repeat('a', 64), 'password' => 'Str0ngPassw0rd!x', 'password_confirm' => 'Str0ngPassw0rd!x']);
        $this->authService->shouldReceive('resetPassword')->andReturn(['success' => false, 'message' => 'توکن بازنشانی رمز عبور نامعتبر یا منقضی شده است.']);

        $out = $this->capture(fn () => $this->controller()->resetPassword());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('INVALID_RESET_TOKEN', $out['error']['code']);
    }

    public function test_reset_password_success_advertises_revocations_and_relogin(): void
    {
        $this->boot();
        $this->setBody(['token' => str_repeat('a', 64), 'password' => 'Str0ngPassw0rd!x', 'password_confirm' => 'Str0ngPassw0rd!x']);
        $this->authService->shouldReceive('resetPassword')->once()->with(str_repeat('a', 64), 'Str0ngPassw0rd!x', null)->andReturn(['success' => true]);

        $out = $this->capture(fn () => $this->controller()->resetPassword());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['data']['reset']);
        $this->assertTrue($out['data']['revoked']['web_sessions']);
        $this->assertTrue($out['data']['revoked']['api_tokens']);
        $this->assertSame('login', $out['data']['next_step']);
    }

    public function test_reset_password_is_rate_limited_per_ip(): void
    {
        $this->boot();
        $this->rateLimiter->shouldReceive('attempt')->andReturn(false)->byDefault();
        $this->setBody(['token' => str_repeat('a', 64), 'password' => 'Str0ngPassw0rd!x', 'password_confirm' => 'Str0ngPassw0rd!x']);

        $out = $this->capture(fn () => $this->controller()->resetPassword());
        $this->assertSame(429, $out['__status']);
    }

    // ─────────────────────────────────────────────────────────────
    // قرارداد ساختاری
    // ─────────────────────────────────────────────────────────────

    public function test_controller_extends_base_api_controller(): void
    {
        $this->boot();
        $this->assertInstanceOf(\App\Controllers\Api\BaseApiController::class, $this->controller());
    }

    public function test_all_five_endpoints_exist(): void
    {
        foreach (['register', 'verifyEmailCode', 'resendVerification', 'forgotPassword', 'resetPassword'] as $m) {
            $this->assertTrue(method_exists(MobileAuthController::class, $m), "MobileAuthController::{$m} باید وجود داشته باشد");
        }
    }
}
