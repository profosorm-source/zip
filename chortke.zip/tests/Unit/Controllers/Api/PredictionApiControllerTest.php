<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\PredictionApiController;
use App\Models\PredictionBet;
use App\Models\PredictionGame;
use App\Services\PredictionService;
use Core\Container;
use Core\Database;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-06: پوشش قرارداد PredictionApiController — شرط‌بندی از کانال API.
 *
 * لنزها:
 *  ① فهرست بازی‌ها: بازی بازِ seed شده + استخرهای USDT
 *  ② جزئیات بازی با my_bet=null (بدون شرط قبلی)
 *  ③ اعتبارسنجی ثبت شرط: prediction نامعتبر ۴۲۲، مبلغ نامعتبر ۴۲۲،
 *     Idempotency-Key غایب ۴۲۲ (بدون side-effect)
 *  ④ ثبت شرط موفق با موجودی واقعی کیف پول + idempotent replay (بدون دوبل‌کمشدن)
 *  ⑤ شرط با موجودی ناکافی → خطای سرویس ۴۲۲
 */
final class PredictionApiControllerTest extends TestCase
{
    private Database $db;
    private PredictionGame $gameModel;
    private PredictionBet $betModel;
    private PredictionService $predictionService;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private LoggerInterface&MockInterface $logger;
    private Response $response;
    private int $userId;
    private string $tag;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->gameModel = Container::getInstance()->make(PredictionGame::class);
        $this->betModel = Container::getInstance()->make(PredictionBet::class);
        $this->predictionService = Container::getInstance()->make(PredictionService::class);
        $this->tag = 'q6p' . bin2hex(random_bytes(4));

        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["{$this->tag}-u", "{$this->tag}-u@example.test", 'active', 'user'],
        );
        $this->userId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        // کیف پول با موجودی USDT برای شرط موفق (شما schema: ستون‌های balance_usdt/locked_usdt)
        $this->db->query(
            'INSERT INTO wallets (user_id, balance_usdt, locked_usdt, balance_irt, locked_irt) VALUES (?, ?, 0, 0, 0)
             ON DUPLICATE KEY UPDATE balance_usdt = VALUES(balance_usdt)',
            [$this->userId, '50.00000000'],
        );
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM prediction_bets WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM prediction_games WHERE title LIKE ?', ["{$this->tag}%"]);
        $this->db->query('DELETE FROM wallets WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM transactions WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM users WHERE id = ?', [$this->userId]);
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): PredictionApiController
    {
        return new PredictionApiController(
            $this->gameModel,
            $this->betModel,
            $this->predictionService,
            $this->session,
            $this->request,
            $this->response,
            $this->logger,
        );
    }

    private function boot(): void
    {
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();
        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('10.0.0.9')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->userId])->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();
        $this->request->shouldReceive('body')->andReturn([])->byDefault();
        $this->request->shouldReceive('header')->andReturn('')->byDefault();
        $this->session = Mockery::mock(Session::class);
        $this->response = new Response();
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    /** @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    /** @return int game id */
    private function seedGame(string $title = '', string $status = 'open'): int
    {
        $title = $title !== '' ? $title : "{$this->tag} — تست";
        $this->db->query(
            "INSERT INTO prediction_games
             (title, sport_type, team_home, team_away, status, min_bet_usdt, max_bet_usdt,
              bet_deadline, match_date, created_by, created_at, updated_at)
             VALUES (?, 'football', 'آ', 'ب', ?, 1, 100,
                     DATE_ADD(NOW(), INTERVAL 1 DAY), DATE_ADD(NOW(), INTERVAL 2 DAY), 1, NOW(), NOW())",
            [$title, $status],
        );
        return (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    // ── ① فهرست ─────────────────────────────────────────────

    public function test_games_list_includes_seeded_open_game_with_pools(): void
    {
        $this->boot();
        $gameId = $this->seedGame();

        $out = $this->capture(fn () => $this->controller()->games());
        $this->assertSame(200, $out['__status']);

        $found = null;
        foreach ($out['data']['open_games'] ?? [] as $g) {
            if ((int)$g['id'] === $gameId) { $found = $g; break; }
        }
        $this->assertNotNull($found, 'بازی باز در فهرست');
        $this->assertSame(0.0, (float)($found['total_pool_usdt'] ?? 'x'));
        $this->assertSame('آ', $found['team_home']);
    }

    // ── ② جزئیات ─────────────────────────────────────────────

    public function test_show_returns_game_with_my_bet_null(): void
    {
        $this->boot();
        $gameId = $this->seedGame();

        $out = $this->capture(fn () => $this->controller()->show($gameId));
        $this->assertSame(200, $out['__status']);
        $this->assertNull($out['data']['my_bet']);
        $this->assertSame(1.0, (float)$out['data']['game']['min_bet_usdt']);
    }

    public function test_show_unknown_game_is_404(): void
    {
        $this->boot();
        $out = $this->capture(fn () => $this->controller()->show(999999999));
        $this->assertSame(404, $out['__status']);
    }

    // ── ③ اعتبارسنجی ثبت شرط ────────────────────────────────

    public function test_place_bet_validation_errors(): void
    {
        $this->boot();
        $gameId = $this->seedGame();

        // prediction نامعتبر
        $this->setBody(['game_id' => $gameId, 'prediction' => 'up', 'amount' => '10']);
        $out = $this->capture(fn () => $this->controller()->placeBet());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('prediction', $out['data']['errors'] ?? []);

        // مبلغ نامعتبر
        $this->setBody(['game_id' => $gameId, 'prediction' => 'home', 'amount' => '-5']);
        $out = $this->capture(fn () => $this->controller()->placeBet());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('amount', $out['data']['errors'] ?? []);

        // Idempotency-Key غایب — بدون side-effect
        $this->setBody(['game_id' => $gameId, 'prediction' => 'home', 'amount' => '10']);
        $out = $this->capture(fn () => $this->controller()->placeBet());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('idempotency_key', $out['data']['errors'] ?? []);
        $this->assertSame(0, (int)$this->db->fetchColumn('SELECT COUNT(*) FROM prediction_bets WHERE user_id = ?', [$this->userId]) ?: 0, 'هیچ شرطی ثبت نشده باشد');
    }

    // ── ④ ثبت موفق + idempotent replay ──────────────────────

    public function test_place_bet_success_and_idempotent_replay(): void
    {
        $this->boot();
        $gameId = $this->seedGame();

        $this->setBody(['game_id' => $gameId, 'prediction' => 'home', 'amount' => '10']);
        $this->request->shouldReceive('header')->with('Idempotency-Key', Mockery::any())->andReturn('q6p-idem-key-12345')->byDefault();

        // سرویس واقعی لاگ می‌نویسد — بافر خروجی تست را تمیز نگه می‌داریم
        ob_start();
        try {
            $out = $this->capture(fn () => $this->controller()->placeBet());
        } finally { ob_end_clean(); }
        $this->assertSame(200, $out['__status'], json_encode($out, JSON_UNESCAPED_UNICODE));
        $this->assertTrue((bool)$out['success']);

        $this->assertSame(1, (int)$this->db->fetchColumn('SELECT COUNT(*) FROM prediction_bets WHERE user_id = ?', [$this->userId]), 'یک شرط ثبت شد');

        // موجودی کم شد (۱۰ usdt از ۵۰)
        $balance = (string)$this->db->fetchColumn('SELECT balance_usdt FROM wallets WHERE user_id = ?', [$this->userId]);
        $this->assertSame('40.00000000', $balance, 'مبلغ شرط از کیف پول کم شد (۱۰ از ۵۰)');

        // replay با همان کلید: قرارداد سرویس فعلی = ردِ صریحِ کلید تکراری (نه نتیجهٔ اصلی)
        // (idempotency_status=completed) — پین اصلی API: بدون شرط دوم و بدون کسر مجدد.
        ob_start();
        try {
            $out2 = $this->capture(fn () => $this->controller()->placeBet());
        } finally { ob_end_clean(); }
        $this->assertSame(422, $out2['__status'], 'کلیدِ تکراری → خطای کاربر (نه retry موفق)');
        $this->assertStringContainsString('قبلاً ثبت شده', (string)($out2['message'] ?? ''));
        $this->assertSame(1, (int)$this->db->fetchColumn('SELECT COUNT(*) FROM prediction_bets WHERE user_id = ?', [$this->userId]), 'replay شرط دومی نساخت');
        $balance2 = (string)$this->db->fetchColumn('SELECT balance_usdt FROM wallets WHERE user_id = ?', [$this->userId]);
        $this->assertSame('40.00000000', $balance2, 'replay دوباره کم نکرد');
    }

    // ── ⑤ موجودی ناکافی (نقش API: نگاشت خطای سرویس) ────────

    public function test_place_bet_maps_service_error_to_422(): void
    {
        $this->boot();
        $gameId = $this->seedGame();

        // سرویس موک: قرارداد نگاشتِ خطای سرویس → ۴۲۲ (بدون اجرای لاگ‌دارِ سرویس واقعی)
        $mockService = Mockery::mock(PredictionService::class);
        $mockService->shouldReceive('placeBet')
            ->once()
            ->with($this->userId, $gameId, 'away', '999', Mockery::any())
            ->andReturn(['success' => false, 'message' => 'موجودی کافی نیست.']);

        $this->setBody(['game_id' => $gameId, 'prediction' => 'away', 'amount' => '999']);
        $this->request->shouldReceive('header')->with('Idempotency-Key', Mockery::any())->andReturn('q6p-idem-key-67890')->byDefault();

        $controller = new PredictionApiController(
            $this->gameModel,
            $this->betModel,
            $mockService,
            $this->session,
            $this->request,
            $this->response,
            $this->logger,
        );
        $out = $this->capture(fn () => $controller->placeBet());
        $this->assertSame(422, $out['__status']);
        $this->assertFalse((bool)$out['success']);
        $this->assertSame('موجودی کافی نیست.', $out['message'] ?? '');
        $this->assertSame(0, (int)$this->db->fetchColumn('SELECT COUNT(*) FROM prediction_bets WHERE user_id = ?', [$this->userId]) ?: 0, 'شرط ثبت نشد');
    }

    // ── my/bets ─────────────────────────────────────────────

    public function test_my_bets_lists_seeded_bet_with_direction_fields(): void
    {
        $this->boot();
        // درج مستقیم ردیف شرط (بدون لاگ‌های سرویس — خروجی تست تمیز می‌ماند)
        $gameId = $this->seedGame();
        $this->db->query(
            "INSERT INTO prediction_bets (user_id, game_id, prediction, amount, currency, amount_usdt, status, created_at)
             VALUES (?, ?, 'draw', 7, 'usdt', 7, 'active', NOW())",
            [$this->userId, $gameId],
        );

        $out = $this->capture(fn () => $this->controller()->myBets());
        $this->assertSame(200, $out['__status']);
        $rows = $out['data']['items'] ?? $out['data'] ?? [];
        $this->assertNotEmpty($rows);
        $first = $rows[0] ?? [];
        $this->assertSame('draw', $first['prediction'] ?? '');
        $this->assertSame(7.0, (float)($first['amount_usdt'] ?? '0'), 'مبلغ شرط در لیست من');
        $this->assertSame($this->tag . ' — تست', $first['game_title'] ?? '');
    }
}
