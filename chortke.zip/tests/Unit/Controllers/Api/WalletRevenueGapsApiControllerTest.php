<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Controllers\Api\WalletController;
use App\Services\BankCardService;
use App\Services\CryptoDeposit\CryptoDepositService;
use App\Services\InvestmentService;
use App\Services\Lottery\LotteryService;
use App\Services\ManualDepositService;
use App\Services\Settings\AppSettings;
use App\Services\Shared\ReferralService;
use App\Services\Withdrawal\WithdrawalUserService;
use App\Contracts\WalletServiceInterface;
use Core\Container;
use Core\Database;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Mockery;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-REVGEN-REAPLY (بازکاربرد REVGEN روی درخت FIX-MOBILE-06 — ۲۰۲۶-۱۱-۰۳):
 * پوشش دو متد جدید WalletController — تاریخچهٔ سود سرمایه‌گذاری و رأی لاتری.
 *
 * لنزها:
 *  ① profit-history: ردیف‌های سود کاربر با صفحه‌بندی (DB واقعی؛ الگوی
 *     ContractTestهای محتوا) — فقط ردیف‌های خود کاربر
 *  ② vote: گیت اعتبارسنجی VoteLotteryRequest (عدد ۱..۴۹ الزامی؛ بدون
 *     پیش‌فرض پنهان) + رزولوشن عدد روزانهٔ round → 422 تمیز وقتی عددی نیست
 */
final class WalletRevenueGapsApiControllerTest extends TestCase
{
    private Database $db;
    private WalletController $controller;
    private Request $request;
    private int $userId;
    private string $tag;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->tag = 'rg' . bin2hex(random_bytes(4));

        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["rg-{$this->tag}", "rg-{$this->tag}@example.test", 'active', 'user'],
        );
        $this->userId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');

        // همان سازندهٔ مسیرهای موجود — سرویس‌های پولی mock
        // (متدهای زیرین این تست‌ها هرگز به آن‌ها نمی‌رسند).
        $this->controller = new WalletController(
            Mockery::mock(WalletServiceInterface::class),
            Mockery::mock(BankCardService::class),
            Mockery::mock(WithdrawalUserService::class),
            Mockery::mock(ManualDepositService::class),
            Mockery::mock(CryptoDepositService::class),
            Mockery::mock(AppSettings::class),
            Mockery::mock(InvestmentService::class),
            Mockery::mock(ReferralService::class),
            Mockery::mock(LotteryService::class),
        );

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->userId])->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();

        // تزریق request/response واقعی به کنترلر (propertyهای protected والد)
        $ref = new \ReflectionClass(\App\Controllers\Api\BaseApiController::class);
        while ($ref && !$ref->hasProperty('request')) {
            $ref = $ref->getParentClass();
        }
        if ($ref && $ref->hasProperty('request')) {
            $p = $ref->getProperty('request');
            $p->setAccessible(true);
            $p->setValue($this->controller, $this->request);
        }
        $ref2 = new \ReflectionClass(\App\Controllers\BaseController::class);
        if ($ref2->hasProperty('response')) {
            $p2 = $ref2->getProperty('response');
            $p2->setAccessible(true);
            $p2->setValue($this->controller, new Response());
        }
    }

    protected function tearDown(): void
    {
        // پاکسازی جراحی — فقط ردیف‌های همین اجرا (سلسله: profit → investment → user)
        $this->db->query(
            'DELETE FROM investment_profits WHERE investment_id IN (SELECT id FROM investments WHERE user_id = ?)',
            [$this->userId],
        );
        $this->db->query('DELETE FROM investments WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM users WHERE id = ?', [$this->userId]);
        Mockery::close();
        parent::tearDown();
    }

    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    /**
     * ردیف سود برای این کاربر — با سرمایه‌گذاریِ واقعیِ مالکِ کاربر (مدل JOIN دارد).
     * قید uq_investments_one_active_per_user: فقط اولین ردیف active؛ بعدی closed.
     */
    private function seedProfit(string $profitType, string $amount, string $invStatus = 'active'): void
    {
        $this->db->query(
            "INSERT INTO investments (user_id, amount, currency, profit, status, created_at)
             VALUES (?, 1000, 'usdt', 2.5, ?, NOW())",
            [$this->userId, $invStatus],
        );
        $invId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        $this->db->query(
            'INSERT INTO investment_profits
             (investment_id, amount, gross_amount, site_fee_amount, tax_amount, net_amount, currency, profit_type, status, created_at)
             VALUES (?, ?, ?, 0, 0, ?, ?, ?, ?, NOW())',
            [$invId, $amount, $amount, $amount, 'usdt', $profitType, 'paid'],
        );
    }

    // ─────────────────────────────────────────────────────────────
    // ① تاریخچهٔ سود/زیان
    // ─────────────────────────────────────────────────────────────

    public function test_profit_history_returns_only_my_rows_paginated(): void
    {
        $this->seedProfit('trading', '150.00000000', 'active');
        $this->seedProfit('trading', '20.00000000', 'closed');

        $out = $this->capture(fn() => $this->controller->investmentProfitHistory());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['success']);
        $this->assertSame(2, $out['meta']['total']);
        $this->assertCount(2, $out['data']);

        $amounts = array_map(static fn($r) => (float)$r['amount'], $out['data']);
        sort($amounts);
        $this->assertSame([20.0, 150.0], $amounts);
        $this->assertSame('usdt', $out['data'][0]['currency']);
        $this->assertSame('trading', $out['data'][0]['profit_type']);
    }

    public function test_profit_history_empty_for_user_without_investments(): void
    {
        $out = $this->capture(fn() => $this->controller->investmentProfitHistory());
        $this->assertSame(200, $out['__status']);
        $this->assertSame(0, $out['meta']['total']);
        $this->assertSame([], $out['data']);
    }

    // ─────────────────────────────────────────────────────────────
    // ② رأی لاتری — گاردهای ورودی (بدون نیاز به seed راند)
    // ─────────────────────────────────────────────────────────────

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    public function test_vote_requires_voted_number(): void
    {
        $this->setBody(['round_id' => 5]);
        $out = $this->capture(fn() => $this->controller->lotteryVote());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('اطلاعات ورودی نامعتبر است.', $out['message']);
    }

    public function test_vote_rejects_out_of_range_number(): void
    {
        $this->setBody(['round_id' => 5, 'voted_number' => 99]);
        $out = $this->capture(fn() => $this->controller->lotteryVote());
        $this->assertSame(422, $out['__status']);
    }

    public function test_vote_rejects_float_number_without_silent_cast(): void
    {
        // «1.9» نباید ساکت به 1 تبدیل شود (قرارداد FIX-S17-F05)
        $this->setBody(['round_id' => 5, 'voted_number' => '1.9']);
        $out = $this->capture(fn() => $this->controller->lotteryVote());
        $this->assertSame(422, $out['__status']);
    }

    public function test_vote_with_unknown_round_gives_clean_daily_number_error(): void
    {
        // راندِ وجودنداشته ⇒ عدد روزانه‌ای نیست ⇒ 422 تمیز (نه خطای خام DB)
        $this->setBody(['round_id' => 987654321, 'voted_number' => 7]);
        $out = $this->capture(fn() => $this->controller->lotteryVote());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('LOTTERY_NO_DAILY_NUMBER', $out['error_code']);
    }
}
