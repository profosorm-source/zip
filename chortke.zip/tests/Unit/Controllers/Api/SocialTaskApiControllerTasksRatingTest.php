<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\SocialTaskApiController;
use App\Services\Gamification\TrustService;
use App\Services\Interaction\RatingService;
use App\Services\Shared\PolicyService;
use App\Services\SocialTask\SocialTaskService;
use App\Services\User\UserService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCRATE-DISPLAY-01 (۲۰۲۶-۱۱-۰۹) — پوشش قرارداد نمایش رأی کاربران
 * در فهرست تسک‌های سوشیال از کانال API (قرینهٔ SeoTaskApiControllerTest).
 *
 * لنزها:
 *  ① tasks(): هر ردیف avg_rating/rating_count دارد (یک batch از getRatingsSummary)
 *  ② کمپین بدون رأی = صفر صادقانه (نه null/حذف کلید)
 *  ③ صفحهٔ خالی = هیچ کوئری امتیازی (سرویس صدا زده نمی‌شود)
 *  ④ بدون احراز هویت → 401 (رگرسیون قرارداد قبلی)
 */
final class SocialTaskApiControllerTasksRatingTest extends TestCase
{
    private SocialTaskService&MockInterface $service;
    private TrustService&MockInterface $trust;
    private UserService&MockInterface $userService;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private LoggerInterface&MockInterface $logger;
    private Response $response;
    private Mockery\MockInterface $ratingService;

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): SocialTaskApiController
    {
        return new SocialTaskApiController(
            $this->service,
            $this->trust,
            $this->userService,
            null,
            null,
            $this->logger,
            // 🛡️ FIX-SOCRATE-DISPLAY-01: سرویس امتیاز (avg_rating فهرست) — mock تزریقی
            $this->ratingService,
        );
    }

    /** @param int|null $userId کاربر لاگین (null = بدون احراز هویت) */
    private function boot(?int $userId = 7): void
    {
        $this->service = Mockery::mock(SocialTaskService::class);
        $this->trust = Mockery::mock(TrustService::class);
        $this->userService = Mockery::mock(UserService::class);
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn($userId === null ? null : (object)['id' => $userId])->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();

        // BaseController سازنده: request/response/... را از Container می‌گیرد
        // (null ?? app(Request::class)) — mock را در Container می‌بندیم (الگوی P3)
        app(\Core\Container::class)->instance(Request::class, $this->request);

        $this->session = Mockery::mock(Session::class);
        $this->response = new Response();

        // 🛡️ FIX-SOCRATE-DISPLAY-01: سرویس امتیاز — پیش‌فرض بدون رأی (خلاصهٔ خالی)
        $this->ratingService = Mockery::mock(RatingService::class);
        $this->ratingService->shouldReceive('getRatingsSummary')->byDefault()->andReturn([]);
    }

    /** اجرای callback و گرفتن پاسخ JSON به‌همراه status (الگوی SeoTaskApiControllerTest). @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    // ─────────────────────────────────────────────────────────────
    // ① فهرست تسک‌ها + رأی کاربران
    // ─────────────────────────────────────────────────────────────

    public function test_tasks_includes_community_rating_from_batch_summary(): void
    {
        $this->boot();
        $this->service->shouldReceive('getAvailableTasksForExecutor')->once()->with(20, 0, 7)->andReturn([
            [
                (object)['id' => 11, 'title' => 'کمپین الف', 'type' => 'social_task', 'platform' => 'instagram', 'reward' => 5000],
                (object)['id' => 12, 'title' => 'کمپین ب', 'type' => 'social_task', 'platform' => 'telegram', 'reward' => 3000],
            ],
            2,
        ]);
        // یک کوئری batch برای کل صفحه — نه per-row
        $this->ratingService->shouldReceive('getRatingsSummary')->once()->with('social_task', [11, 12])->andReturn([
            11 => ['count' => 9, 'avg' => 4.5],
        ]);

        $out = $this->capture(fn () => $this->controller()->tasks());
        $this->assertSame(200, $out['__status']);
        $rows = $out['data'];
        $this->assertCount(2, $rows);
        $this->assertSame(4.5, (float)$rows[0]['avg_rating']);
        $this->assertSame(9, (int)$rows[0]['rating_count']);
        // آگهی بدون رأی — صفر صادقانه، نه null/حذف کلید
        $this->assertSame(0.0, (float)$rows[1]['avg_rating']);
        $this->assertSame(0, (int)$rows[1]['rating_count']);
        $this->assertSame(2, (int)$out['meta']['total']);
    }

    public function test_tasks_empty_page_skips_rating_query(): void
    {
        $this->boot();
        $this->service->shouldReceive('getAvailableTasksForExecutor')->once()->andReturn([[], 0]);
        // صفحهٔ خالی ⇒ هیچ کوئری امتیازی (سرویس امتیاز صدا زده نمی‌شود)
        $this->ratingService->shouldReceive('getRatingsSummary')->never();

        $out = $this->capture(fn () => $this->controller()->tasks());
        $this->assertSame(200, $out['__status']);
        $this->assertSame([], $out['data']);
        $this->assertSame(0, (int)$out['meta']['total']);
    }

    public function test_tasks_requires_authentication(): void
    {
        $this->boot(userId: null);
        $this->service->shouldReceive('getAvailableTasksForExecutor')->never();

        $out = $this->capture(fn () => $this->controller()->tasks());
        $this->assertSame(401, $out['__status']);
        $this->assertFalse((bool)($out['success'] ?? true));
    }
}
