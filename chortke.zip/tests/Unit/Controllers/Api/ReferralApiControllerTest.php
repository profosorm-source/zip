<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\ReferralApiController;
use App\Services\Shared\ReferralService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use App\Services\Shared\PolicyService;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-REVGEN-REAPLY (بازکاربرد REVGEN روی درخت FIX-MOBILE-06 — ۲۰۲۶-۱۱-۰۳):
 * پوشش قرارداد ReferralApiController — میلستون‌ها و ادعای پاداش رفرال.
 *
 * لنزها:
 *  ① نمای میلستون‌ها: شمار مرجع‌های تأییدشده + دست‌یافته/در دسترس
 *  ② ادعای پاداش: همان checkAndAwardMilestones وب (idempotent) — خروجی خام
 *  ③ خطای زیرساخت → 422 REFERRAL_CLAIM_FAILED (جزئیات فقط در لاگ)
 */
final class ReferralApiControllerTest extends TestCase
{
    private ReferralService&MockInterface $referralService;
    private Request&MockInterface $request;
    private LoggerInterface&MockInterface $logger;
    private Response $response;

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): ReferralApiController
    {
        return new ReferralApiController(
            $this->referralService,
            $this->logger,
            Mockery::mock(Session::class),
            $this->request,
            $this->response,
            Mockery::mock(PolicyService::class),
        );
    }

    private function boot(int $userId = 7): void
    {
        $this->referralService = Mockery::mock(ReferralService::class);
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $userId])->byDefault();

        $this->response = new Response();
    }

    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    public function test_milestones_returns_overview_with_verified_count(): void
    {
        $this->boot(7);

        $this->referralService->shouldReceive('getMilestoneOverview')->once()->with(7)->andReturn([
            'referral_count' => 12,
            'achieved' => [(object)['id' => 1, 'title' => 'SILVER', 'threshold_value' => 5]],
            'available' => [(object)['id' => 2, 'title' => 'GOLD', 'threshold_value' => 10]],
        ]);

        $out = $this->capture(fn() => $this->controller()->milestones());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['success']);
        $this->assertSame(12, $out['data']['referral_count']);
        $this->assertCount(1, $out['data']['achieved']);
        $this->assertCount(1, $out['data']['available']);
    }

    public function test_claim_passes_check_and_award_milestones_verbatim(): void
    {
        $this->boot(7);

        // idempotent: میلستونِ اعطاشده دوباره پاداش نمی‌دهد — نتیجهٔ خام سرویس
        $this->referralService->shouldReceive('checkAndAwardMilestones')->once()->with(7)->andReturn([
            'awarded' => [],
            'awarded_count' => 0,
            'referral_count' => 12,
            'achieved' => [1, 2],
        ]);

        $out = $this->capture(fn() => $this->controller()->claimRewards());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue($out['success']);
        $this->assertSame(0, $out['data']['awarded_count']);
        $this->assertSame(12, $out['data']['referral_count']);
    }

    public function test_claim_maps_infrastructure_failure_to_422(): void
    {
        $this->boot(7);

        $this->referralService->shouldReceive('checkAndAwardMilestones')->once()->andThrow(
            new \RuntimeException('db down')
        );
        $this->logger->shouldReceive('error')->once();

        $out = $this->capture(fn() => $this->controller()->claimRewards());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('REFERRAL_CLAIM_FAILED', $out['error_code']);
        // جزئیات استثنا به کلاینت نشت نکرده
        $raw = (string)json_encode($out, JSON_UNESCAPED_UNICODE);
        $this->assertStringNotContainsString('db down', $raw);
    }
}
