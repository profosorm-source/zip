<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Controllers\Api\AdtubeApiController;
use App\Models\AdTubeExecutionModel;
use App\Models\Ads;
use App\Services\Ads\AdsBudgetSettlementService;
use Core\Container;
use Core\Database;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;
use Tests\Support\ResetsConfiguredRedis;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳):
 * پوشش قرارداد AdtubeApiController — تماشای ویدیو از کانال API.
 *
 * لنزها:
 *  ① فهرست: فقط فیلدهای عمومی + آمار روزانه (بدون نشت metadata خام)
 *  ② شروع: گاردهای زنجیرهٔ وب — کمپین خود ۴۰۳، بدون‌مدت ۴۰۹
 *  ③ شروع موفق: execution در DB وضعیت watching + چالش قابل بازخوانی (کلید مشترک وب)
 *  ④ heartbeat: انباشت سیگنال پخش + چالشِ نامعتبر ۴۰۹
 *  ⑤ complete: fail-closed بدون سیگنال پخش (NO_HEARTBEAT_SIGNAL) — پاداش بدون سیگنال نمی‌آید
 */
final class AdtubeApiControllerTest extends TestCase
{
    use ResetsConfiguredRedis;

    private Database $db;
    private Ads $adModel;
    private AdTubeExecutionModel $executionModel;
    private AdsBudgetSettlementService $settlement;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private LoggerInterface&MockInterface $logger;
    private Response $response;
    private int $workerId;
    private int $ownerId;
    private string $tag;

    protected function setUp(): void
    {
        parent::setUp();
        $this->resetConfiguredRedis(); // هرمتیک: throttle/چالش/heartbeat بین ران‌ها
        $this->db = Container::getInstance()->make(Database::class);
        $this->executionModel = Container::getInstance()->make(AdTubeExecutionModel::class);
        $this->settlement = Container::getInstance()->make(AdsBudgetSettlementService::class);
        $this->tag = 'q6a' . bin2hex(random_bytes(4));

        foreach ([['q6a-owner', 'owner'], ['q6a-worker', 'worker']] as [$name, $kind]) {
            $this->db->query(
                'INSERT INTO users (username, email, status, role, kyc_status) VALUES (?, ?, ?, ?, ?)',
                ["{$this->tag}-{$kind}", "{$this->tag}-{$kind}@example.test", 'active', 'user', 'verified'],
            );
            ${$kind . 'Id'} = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        }
        $this->ownerId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()') - 1;
        $this->workerId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM adtube_views WHERE ad_id IN (SELECT id FROM ads WHERE user_id = ?)', [$this->ownerId]);
        $this->db->query('DELETE FROM ads WHERE user_id = ?', [$this->ownerId]);
        $this->db->query('DELETE FROM users WHERE id IN (?, ?)', [$this->ownerId, $this->workerId]);
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): AdtubeApiController
    {
        return new AdtubeApiController(
            $this->adModel,
            $this->executionModel,
            $this->settlement,
            $this->session,
            $this->request,
            $this->response,
            $this->logger,
        );
    }

    /** boot با کاربرِ احراز‌شدهٔ API */
    private function boot(): void
    {
        $this->adModel = Container::getInstance()->make(Ads::class);
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('10.20.30.40')->byDefault();
        $this->request->shouldReceive('userAgent')->andReturn('phpunit-agent')->byDefault();
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->workerId])->byDefault();
        $this->request->shouldReceive('int')->with('page', 1)->andReturn(1)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 20)->andReturn(20)->byDefault();
        $this->request->shouldReceive('int')->with('per_page', 5)->andReturn(5)->byDefault();
        $this->request->shouldReceive('body')->andReturn([])->byDefault();
        $this->request->shouldReceive('header')->andReturn('')->byDefault();

        $this->session = Mockery::mock(Session::class);
        $this->response = new Response();
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->andReturn($body)->byDefault();
    }

    /** @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    /** @param array<string, mixed> $overrides @return int ad id */
    private function seedAd(array $overrides = []): int
    {
        $fields = array_merge([
            'user_id' => $this->ownerId,
            'title' => 'کمپین تست AdTube',
            'type' => 'adtube',
            'platform' => 'youtube',
            'status' => 'active',
            'currency' => 'irt',
            'price_per_task' => 5000.0,
            'total_budget' => 50000.0,
            'remaining_budget' => 50000.0,
            'total_count' => 10,
            'completed_count' => 0,
            'pending_count' => 0,
            'link' => 'https://youtu.be/Q6AdTube',
            'metadata' => json_encode(['video_duration_seconds' => 30]),
        ], $overrides);
        $cols = implode(',', array_keys($fields));
        $marks = implode(',', array_fill(0, count($fields), '?'));
        $this->db->query("INSERT INTO ads ({$cols}, created_at, updated_at) VALUES ({$marks}, NOW(), NOW())", array_values($fields));
        return (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    // ── ① فهرست ─────────────────────────────────────────────

    public function test_ads_list_returns_public_fields_and_daily_stats(): void
    {
        $this->boot();
        $adId = $this->seedAd();

        $out = $this->capture(fn () => $this->controller()->ads());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue((bool)$out['success']);

        $ads = $out['data']['ads'] ?? [];
        $this->assertNotEmpty($ads, 'کمپین seed شده باید در فهرست بیاید (fail-closed بدون مدت از فهرست حذف می‌شود — مدت داریم)');
        $row = null;
        foreach ($ads as $a) {
            if ((int)$a['id'] === $adId) { $row = $a; break; }
        }
        $this->assertNotNull($row, 'ردیف کمپین در فهرست');
        $this->assertSame(30, $row['video_duration_seconds']);
        $this->assertSame('https://youtu.be/Q6AdTube', $row['link']);
        $this->assertArrayNotHasKey('metadata', $row, 'metadata خام کمپین نباید نشت کند');
        $this->assertArrayHasKey('daily_cap', $out['data']['stats']);
    }

    // ── ② گاردهای شروع ──────────────────────────────────────

    public function test_start_own_campaign_is_forbidden(): void
    {
        $this->boot();
        $adId = $this->seedAd();
        // کاربر جاری = مالک کمپین
        $this->request->shouldReceive('getUser')->andReturn((object)['id' => $this->ownerId])->byDefault();

        $out = $this->capture(fn () => $this->controller()->start($adId));
        $this->assertSame(403, $out['__status']);
        $this->assertSame('OWN_CAMPAIGN', $out['error_code'] ?? '');
    }

    public function test_start_ad_without_duration_fails_closed(): void
    {
        $this->boot();
        $adId = $this->seedAd(['metadata' => json_encode(['note' => 'بدون مدت'])]);

        $out = $this->capture(fn () => $this->controller()->start($adId));
        $this->assertSame(409, $out['__status']);
        $this->assertSame('NO_DURATION', $out['error_code'] ?? '');
    }

    public function test_start_unknown_ad_is_404(): void
    {
        $this->boot();
        $out = $this->capture(fn () => $this->controller()->start(999999999));
        $this->assertSame(404, $out['__status']);
    }

    // ── ③ شروع موفق ─────────────────────────────────────────

    public function test_start_success_reserves_slot_mints_challenge_and_starts_watching(): void
    {
        $this->boot();
        $adId = $this->seedAd();

        $out = $this->capture(fn () => $this->controller()->start($adId));
        $this->assertSame(200, $out['__status']);
        $this->assertTrue((bool)$out['success']);

        $execId = (int)($out['data']['execution_id'] ?? 0);
        $challenge = (string)($out['data']['watch_challenge'] ?? '');
        $this->assertGreaterThan(0, $execId);
        $this->assertNotSame('', $challenge);

        $row = $this->db->query('SELECT status, video_duration FROM adtube_views WHERE id = ?', [$execId])->fetch(\PDO::FETCH_OBJ);
        $this->assertNotNull($row);
        $this->assertSame('watching', (string)$row->status, 'بعد از start وضعیت watching است');
        $this->assertSame(30, (int)$row->video_duration);

        // چالش با همان کلیدِ وب قابل بازخوانی است (کلید مشترک کانال‌ها)
        $stored = \Core\Cache::getInstance()->get("adtube_watch_challenge:{$execId}:{$this->workerId}");
        $this->assertSame($challenge, (string)$stored, 'چالش در کش با کلید وب ذخیره شده است');
    }

    // ── ④ heartbeat ─────────────────────────────────────────

    public function test_heartbeat_accumulates_played_seconds(): void
    {
        $this->boot();
        $adId = $this->seedAd();
        $start = $this->capture(fn () => $this->controller()->start($adId));
        $execId = (int)($start['data']['execution_id'] ?? 0);
        $challenge = (string)($start['data']['watch_challenge'] ?? '');

        // هم‌قرارداد accumulateHeartbeatState: نخستین heartbeat فقط «مبنا را
        // همگام می‌کند» (accum=0)؛ انباشت از دلتای بعدی با کلمپ ۱× + ۱ث شروع می‌شود.
        $this->setBody(['watch_challenge' => $challenge, 'played_seconds' => 5, 'playing' => true, 'seq' => 1]);
        $out = $this->capture(fn () => $this->controller()->heartbeat($execId));
        $this->assertSame(200, $out['__status']);
        $this->assertSame(0, (int)($out['data']['played_seconds'] ?? -1), 'نخستین heartbeat: فقط همگام‌سازی مبنا (accum=0)');

        sleep(2);
        $this->setBody(['watch_challenge' => $challenge, 'played_seconds' => 9, 'playing' => true, 'seq' => 2]);
        $out2 = $this->capture(fn () => $this->controller()->heartbeat($execId));
        $this->assertSame(200, $out2['__status']);
        $second = (int)($out2['data']['played_seconds'] ?? -1);
        // دلتای کلاینت ۴ ثانیه؛ کلمپ دیواری = sleep(~2s)+1 ⇒ بازهٔ ۲..۴
        $this->assertGreaterThanOrEqual(2, $second, 'انباشت شروع شده (کلمپ ۱× فعال است)');
        $this->assertLessThanOrEqual(4, $second, 'ادعای پخشِ سریع‌تر از دیوار کلمپ می‌شود');
    }

    public function test_heartbeat_with_bad_challenge_is_rejected(): void
    {
        $this->boot();
        $adId = $this->seedAd();
        $start = $this->capture(fn () => $this->controller()->start($adId));
        $execId = (int)($start['data']['execution_id'] ?? 0);

        $this->setBody(['watch_challenge' => 'deadbeef', 'played_seconds' => 10, 'playing' => true]);
        $out = $this->capture(fn () => $this->controller()->heartbeat($execId));
        $this->assertSame(409, $out['__status']);
        $this->assertSame('CHALLENGE_INVALID', $out['error_code'] ?? '');
    }

    // ── ⑤ complete fail-closed ─────────────────────────────

    public function test_complete_without_heartbeat_signal_fails_closed(): void
    {
        $this->boot();
        $adId = $this->seedAd();
        $start = $this->capture(fn () => $this->controller()->start($adId));
        $execId = (int)($start['data']['execution_id'] ?? 0);
        $challenge = (string)($start['data']['watch_challenge'] ?? '');

        // هیچ heartbeat ای نفرستاده‌ایم — تسویه نباید انجام شود
        $this->setBody(['watch_challenge' => $challenge, 'watch_time' => 30, 'playback_speed' => 1.0]);
        $out = $this->capture(fn () => $this->controller()->complete($execId));
        $this->assertSame(409, $out['__status']);
        $this->assertSame('NO_HEARTBEAT_SIGNAL', $out['error_code'] ?? '');

        // وضعیت هنوز watching است (خطای گذرا — retry مجاز؛ بدون markRejected)
        $row = $this->db->query('SELECT status FROM adtube_views WHERE id = ?', [$execId])->fetch(\PDO::FETCH_OBJ);
        $this->assertSame('watching', (string)$row->status, 'خطای چالش/سیگنال گذرا است — اجرا نباید رد شود');
    }

    public function test_complete_bad_challenge_is_rejected(): void
    {
        $this->boot();
        $adId = $this->seedAd();
        $start = $this->capture(fn () => $this->controller()->start($adId));
        $execId = (int)($start['data']['execution_id'] ?? 0);

        $this->setBody(['watch_challenge' => 'forged', 'watch_time' => 30]);
        $out = $this->capture(fn () => $this->controller()->complete($execId));
        $this->assertSame(409, $out['__status']);
        $this->assertSame('CHALLENGE_INVALID', $out['error_code'] ?? '');
    }
}
