<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\User;

use App\Controllers\User\AdsController;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-S20-CLOSE-F3 (پایان‌کار بازبینی S20 — یافتهٔ ۲) — سخت‌سازی idempotency
 * ساخت کمپین (POST /ads/store). دو شکاف باقی‌مانده از FIX قبلی (S20):
 *
 *  شکاف الف — کلید سمت سرور الزامی نبود: POST مستقیم به API بدون کلید، بی‌هیچ
 *  گاردی از کنترلر رد می‌شد → دو درخواست موازی = دو کمپین + دو hold مالی.
 *
 *  شکاف ب — پیلاد خالی در ثبت idempotency: کلید صریح با [] ثبت می‌شد؛ یعنی همان
 *  کلید با پیلود متفاوت، بی‌صدا نتیجهٔ قدیمی را replay می‌کرد (نه برخورد ۴۰۹).
 *  اکنون «اثر انگشت پیلاد» (محتوای کسب‌وکاری نرمال‌شده + اثر فایل) همراه کلید
 *  ثبت می‌شود و مغایرت = ۴۰۹ صادقانه.
 */
final class AdsCreateIdempotencyHardeningTest extends TestCase
{
    /** @return array<string, mixed> نمونهٔ پیلاد نرمال‌شدهٔ کمپین adtube */
    private static function samplePayload(): array
    {
        return [
            'ad_type' => 'adtube',
            'title' => 'کمپین تستی',
            'description' => 'توضیح کمپین',
            'link' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'total_count' => 10,
            'price_per_task' => '1200',
            'total_budget' => '12000',
            'currency' => 'irt',
        ];
    }

    protected function tearDown(): void
    {
        unset($_FILES['image']);
        parent::tearDown();
    }

    // ─── اثر انگشت پیلاد (pure) ────────────────────────────────────────────

    public function test_fingerprint_is_deterministic_for_same_command(): void
    {
        $a = AdsController::buildAdPayloadFingerprint(self::samplePayload());
        $b = AdsController::buildAdPayloadFingerprint(self::samplePayload());
        $this->assertSame($a, $b, 'retry همان فرمان ⇒ همان اثر انگشت ⇒ replay امن');
        $this->assertRegExp('/^[a-f0-9]{64}$/', $a);
    }

    public function test_fingerprint_is_key_order_independent(): void
    {
        $data = self::samplePayload();
        $reordered = array_reverse($data, true); // همان مقادیر، ترتیب معکوس
        $this->assertSame(
            AdsController::buildAdPayloadFingerprint($data),
            AdsController::buildAdPayloadFingerprint($reordered),
            'ksort — ترتیب فرم/فیلدها نباید فرمان را «متفاوت» کند'
        );
    }

    public function test_fingerprint_changes_with_business_content(): void
    {
        $base = AdsController::buildAdPayloadFingerprint(self::samplePayload());
        // تغییر بودجه = فرمان متفاوت
        $changed = self::samplePayload();
        $changed['total_budget'] = '24000';
        $this->assertNotSame($base, AdsController::buildAdPayloadFingerprint($changed), 'بودجهٔ متفاوت = فرمان متفاوت = ۴۰۹ با همان کلید');
        // تغییر عنوان
        $changedTitle = self::samplePayload();
        $changedTitle['title'] = 'کمپین دیگر';
        $this->assertNotSame($base, AdsController::buildAdPayloadFingerprint($changedTitle));
        // تغییر کوپن (توکن) = فرمان متفاوت
        $changedCoupon = self::samplePayload();
        $changedCoupon['coupon_token'] = 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6';
        $this->assertNotSame($base, AdsController::buildAdPayloadFingerprint($changedCoupon));
    }

    public function test_fingerprint_ignores_volatile_server_fields(): void
    {
        $base = AdsController::buildAdPayloadFingerprint(self::samplePayload());
        // فیلدهای فرّار سرور — نباید اثر انگشت را عوض کنند (retry بعد از آپلود مجدد):
        $volatile = self::samplePayload();
        $volatile['image_path'] = 'banners/abc123.png';   // مسیر تازه پس از هر آپلود
        $volatile['user_id'] = 42;                          // actor، نه محتوا
        $volatile['idempotency_key'] = 'ADS_11112222';     // خودِ کلید
        $this->assertSame($base, AdsController::buildAdPayloadFingerprint($volatile), 'فیلدهای فرّار مستثنی‌اند — retry صادقانه همان اثر را می‌دهد');
    }

    public function test_fingerprint_includes_uploaded_file_identity(): void
    {
        $base = AdsController::buildAdPayloadFingerprint(self::samplePayload());
        try {
            $_FILES['image'] = ['name' => 'banner-a.png', 'size' => 10240, 'tmp_name' => '/tmp/x', 'error' => 0, 'type' => 'image/png'];
            $withFile = AdsController::buildAdPayloadFingerprint(self::samplePayload());
            $this->assertNotSame($base, $withFile, 'وجود فایل باید در اثر انگشت دیده شود');
            // همان فایل (نام/حجم یکسان) در retry ⇒ همان اثر
            $sameFile = AdsController::buildAdPayloadFingerprint(self::samplePayload());
            $this->assertSame($withFile, $sameFile);
            // فایل دیگر = فرمان دیگر
            $_FILES['image'] = ['name' => 'banner-b.png', 'size' => 20480, 'tmp_name' => '/tmp/y', 'error' => 0, 'type' => 'image/png'];
            $this->assertNotSame($withFile, AdsController::buildAdPayloadFingerprint(self::samplePayload()), 'فایل متفاوت = فرمان متفاوت = ۴۰۹');
        } finally {
            unset($_FILES['image']);
        }
    }

    // ─── پین سورس — سیم‌کابی کنترلر و سرویس ─────────────────────────────────

    public function test_store_requires_idempotency_key(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Controllers/User/AdsController.php');
        // شکاف الف: کلید مفقود باید «قبل از» فراخوانی create رد شود
        $posGuard = strpos($src, 'کلید تکرارنشدن (Idempotency-Key) الزامی است');
        $posCreate = strpos($src, '$this->adManager->create(');
        $this->assertIsInt($posGuard, 'گارد الزام کلید در store موجود باشد');
        $this->assertIsInt($posCreate);
        $this->assertLessThan($posCreate, $posGuard, 'گارد باید پیش از create اجرا شود');
        // قالب کلید هم اعتبارسنجی می‌شود (۸..۱۲۸ کاراکتر alphanumeric)
        $this->assertStringContainsString("preg_match('/^[A-Za-z0-9_\\-]+\$/', \$idempotencyKey)", $src);
    }

    public function test_store_registers_payload_fingerprint_not_empty_payload(): void
    {
        $manager = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Services/AdSystemManager.php');
        // شکاف ب: پیلاد idempotency دیگر خالی نیست — اثر انگشت داخلش می‌نشیند
        $this->assertStringContainsString("['payload_fingerprint' => \$payloadFingerprint]", $manager, 'اثر انگشت باید به‌عنوان پیلاد ثبت idempotency برود (data_hash در CORE-049)');
        $this->assertStringContainsString('public function create(string $type, int $userId, array $data, ?string $idempotencyKey = null, ?string $payloadFingerprint = null)', $manager);
        // کنترلر هم اثر انگشت را می‌سازد و پاس می‌دهد
        $controller = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Controllers/User/AdsController.php');
        $this->assertStringContainsString('self::buildAdPayloadFingerprint($data)', $controller);
        $this->assertStringContainsString('$this->adManager->create((string)$type, $userId, $data, $idempotencyKey, $payloadFingerprint)', $controller);
    }

    public function test_collision_gets_honest_409_message(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Controllers/User/AdsController.php');
        // برخورد ۴۰۹ (کلید تکراری با محتوای متفاوت) پیام صادقانه دارد — نه پیام عمومی
        $this->assertStringContainsString("\$e->getCode() === 409", $src);
        $this->assertStringContainsString('همین کلید تکرارنشدن قبلاً با محتوای دیگری ثبت شده است', $src);
    }
}
