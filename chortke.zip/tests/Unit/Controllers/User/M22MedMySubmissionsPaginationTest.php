<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\User;

use App\Controllers\User\CustomTaskController;
use App\Models\Ads;
use App\Models\CustomTaskAnalyticsModel;
use App\Models\CustomTaskSubmissionModel;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\Shared\DisputeService;
use App\Services\UploadService;
use Core\Logger;
use Core\Request;
use Core\Session;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M22-MED (T22-20) — صفحه‌بندی mySubmissions:
 *  ۱) پارامتر page خوانده و clamp می‌شود (>=1، سقف ۵۰۰).
 *  ۲) offset=(page-1)*20 و فراخوانی مدل با (userId, limit, offset).
 *  ۳) count واقعی + totalPages=ceil(count/20) به ویو پاس می‌شود.
 *  ۴) شکست مدل (مثلاً تا زمان اضافه‌شدن متد شمارش توسط هماهنگ‌کننده)
 *     degrade صلح‌آمیز دارد: صفحه با لیست خالی رندر می‌شود.
 */
final class M22MedMySubmissionsPaginationTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    /**
     * کنترلر با وابستگی‌های mock + شیمِ view برای گرفتن دادهٔ ویو.
     * (شیم = subclass بی‌نام که view() را capture می‌کند؛ وابستگی‌ها mock‌اند، بدون DB)
     *
     * @return array{0: CustomTaskController, 1: CustomTaskSubmissionModel&\Mockery\MockInterface, 2: Request&\Mockery\MockInterface}
     */
    private function build(int $pageParam): array
    {
        $executor = m::mock(\App\Services\CustomTask\CustomTaskExecutorService::class);
        $moderation = m::mock(CustomTaskModerationService::class);
        $upload = m::mock(UploadService::class);
        $ads = m::mock(Ads::class);
        $dispute = m::mock(DisputeService::class);
        $submissionModel = m::mock(CustomTaskSubmissionModel::class);
        $analytics = m::mock(CustomTaskAnalyticsModel::class);
        $logger = m::mock(Logger::class);
        $logger->shouldReceive('warning')->zeroOrMoreTimes();

        // شیم view با سازندهٔ خالی (سازندهٔ والد نیازمند ۸ آرگومان و کانتینر/DB است؛
        // الگوی M22StartGuards: بدون-سازنده + تزریق Reflection)
        $controller = new class extends CustomTaskController {
            public function __construct() {}
            /** @var list<array{0: string, 1: array<string, mixed>}> */
            public array $capturedViews = [];
            protected function view(string $template, array $data = []): string
            {
                $this->capturedViews[] = [$template, $data];
                return '';
            }
        };

        $session = m::mock(Session::class);
        $session->shouldReceive('get')->with('user_id')->andReturn(77)->byDefault();
        $session->shouldReceive('setFlash')->zeroOrMoreTimes();
        $request = m::mock(Request::class);
        $request->shouldReceive('int')->with('page', 1)->andReturn($pageParam)->byDefault();
        $request->shouldReceive('param')->andReturn(null)->byDefault();

        $inject = static function (object $target, string $class, string $prop, mixed $value): void {
            $r = new \ReflectionProperty($class, $prop);
            $r->setAccessible(true);
            $r->setValue($target, $value);
        };
        $inject($controller, CustomTaskController::class, 'executorService', $executor);
        $inject($controller, CustomTaskController::class, 'moderationService', $moderation);
        // 📱 FIX-MOBCTR-01: uploadService به proofFileService تبدیل شد (کانال فایل مشترک)
        $inject($controller, CustomTaskController::class, 'proofFileService', new \App\Services\CustomTask\CustomTaskProofFileService($upload));
        $inject($controller, CustomTaskController::class, 'adsModel', $ads);
        $inject($controller, CustomTaskController::class, 'disputeService', $dispute);
        $inject($controller, CustomTaskController::class, 'submissionModel', $submissionModel);
        $inject($controller, CustomTaskController::class, 'analyticsModel', $analytics);
        $inject($controller, \App\Controllers\BaseController::class, 'session', $session);
        $inject($controller, \App\Controllers\BaseController::class, 'request', $request);
        $inject($controller, \App\Controllers\BaseController::class, 'response', new \Core\Response());
        $inject($controller, \App\Controllers\BaseController::class, 'logger', $logger);
        $inject($controller, \App\Controllers\BaseController::class, 'policyService', m::mock(\App\Services\Shared\PolicyService::class));
        $inject($controller, \App\Controllers\BaseController::class, 'csrf', m::mock(\Core\CSRF::class));
        $inject($controller, \App\Controllers\BaseController::class, 'validatorFactory', m::mock(\App\Contracts\ValidatorFactoryInterface::class));

        return [$controller, $submissionModel, $request];
    }

    /** @param array<string, mixed> $overrides */
    private function row(array $overrides = []): \stdClass
    {
        return (object)array_merge(['id' => 1, 'task_id' => 11, 'task_title' => 'تسک', 'status' => 'approved'], $overrides);
    }

    /** @return array{0: string, 1: array<string, mixed>} */
    private function singleView(CustomTaskController $controller): array
    {
        $this->assertNotEmpty($controller->capturedViews, 'mySubmissions باید یک بار view صدا بزند');
        /** @var array{0: string, 1: array<string, mixed>} */
        return $controller->capturedViews[0];
    }

    /** @test */
    public function page_one_with_count_45_yields_three_total_pages(): void
    {
        [$controller, $submissionModel] = $this->build(1);
        $submissionModel->shouldReceive('submission_countByWorkerWithTask')->once()->with(77)->andReturn(45);
        $submissionModel->shouldReceive('submission_getByWorkerWithTask')->once()
            ->with(77, 20, 0)
            ->andReturn([$this->row()]);

        $controller->mySubmissions();

        [$template, $data] = $this->singleView($controller);
        $this->assertSame('user/custom-tasks/executor/my-submissions', $template);
        $this->assertSame(1, $data['page']);
        $this->assertSame(3, $data['totalPages'], 'ceil(45/20)=3');
        $this->assertCount(1, $data['submissions']);
    }

    /** @test */
    public function page_three_applies_offset_math(): void
    {
        [$controller, $submissionModel] = $this->build(3);
        $submissionModel->shouldReceive('submission_countByWorkerWithTask')->once()->with(77)->andReturn(95);
        $submissionModel->shouldReceive('submission_getByWorkerWithTask')->once()
            ->with(77, 20, 40) // (3-1)*20
            ->andReturn([$this->row()]);

        $controller->mySubmissions();

        [, $data] = $this->singleView($controller);
        $this->assertSame(3, $data['page']);
        $this->assertSame(5, $data['totalPages'], 'ceil(95/20)=5');
    }

    /** @test */
    public function page_is_clamped_to_at_least_one(): void
    {
        foreach ([0, -7] as $bad) {
            [$controller, $submissionModel] = $this->build($bad);
            $submissionModel->shouldReceive('submission_countByWorkerWithTask')->once()->andReturn(10);
            $submissionModel->shouldReceive('submission_getByWorkerWithTask')->once()
                ->with(77, 20, 0)
                ->andReturn([]);

            $controller->mySubmissions();

            [, $data] = $this->singleView($controller);
            $this->assertSame(1, $data['page'], "page={$bad} باید به 1 clamp شود");
            $this->assertSame(1, $data['totalPages']);
        }
    }

    /** @test */
    public function page_is_capped_at_500(): void
    {
        [$controller, $submissionModel] = $this->build(999999);
        $submissionModel->shouldReceive('submission_countByWorkerWithTask')->once()->andReturn(3);
        $submissionModel->shouldReceive('submission_getByWorkerWithTask')->once()
            ->with(77, 20, (500 - 1) * 20) // cap ⇒ offset=9980
            ->andReturn([]);

        $controller->mySubmissions();

        [, $data] = $this->singleView($controller);
        $this->assertSame(500, $data['page']);
    }

    /** @test */
    public function zero_count_yields_one_total_page(): void
    {
        [$controller, $submissionModel] = $this->build(1);
        $submissionModel->shouldReceive('submission_countByWorkerWithTask')->once()->andReturn(0);
        $submissionModel->shouldReceive('submission_getByWorkerWithTask')->once()
            ->with(77, 20, 0)
            ->andReturn([]);

        $controller->mySubmissions();

        [, $data] = $this->singleView($controller);
        $this->assertSame(1, $data['totalPages'], 'max(1, ceil(0/20))');
        $this->assertSame([], $data['submissions']);
    }

    /** @test */
    public function model_failure_degrades_gracefully_with_empty_list(): void
    {
        // تا زمانی که هماهنگ‌کننده متد شمارش را اضافه کند (قرارداد گزارش)،
        // خطای undefined-method (Error) باید توسط try/catch خنثی شود.
        [$controller, $submissionModel] = $this->build(2);
        $submissionModel->shouldReceive('submission_countByWorkerWithTask')->once()
            ->andThrow(new \Error('Call to undefined method'));
        $submissionModel->shouldReceive('submission_getByWorkerWithTask')->never();

        $controller->mySubmissions();

        [, $data] = $this->singleView($controller);
        $this->assertSame(2, $data['page']);
        $this->assertSame(1, $data['totalPages']);
        $this->assertSame([], $data['submissions']);
    }

    /** @test */
    public function pagination_contract_is_pinned_in_controller_source(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Controllers/User/CustomTaskController.php');
        $this->assertStringContainsString('submission_countByWorkerWithTask', $src);
        $this->assertStringContainsString("\$this->request->int('page', 1)", $src);
        $this->assertStringContainsString('totalPages', $src);
        $this->assertStringNotContainsString('function review(', $src, 'استاب review باید حذف شده باشد (T22-21)');
    }
}
