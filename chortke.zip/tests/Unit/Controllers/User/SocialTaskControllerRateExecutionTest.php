<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\User;

use App\Contracts\LoggerInterface;
use App\Controllers\User\SocialTaskController;
use App\Services\SocialTask\SocialTaskService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SOCRATE-VOTE-EXEC-01 (۲۰۲۶-۱۱-۱۰) — رفتار «رأی‌دهی از داخل خود
 * صفحهٔ اجرای سوشیال» (قرینهٔ SeoController::rate در FIX-SEO3-01).
 *
 * لنزها:
 *  ① اجرای approved + ستارهٔ معتبر → ۲۰۰ و تفویض به مسیر گاردشدهٔ
 *     SocialTaskService::rateTask(userId, ad_id, stars, comment)
 *  ② اجرای در جریان/ردشده → ۴۲۲ «پس از تأیید»؛ سرویس هرگز صدا زده نمی‌شود
 *  ③ ستارهٔ نامعتبر (۰/۹) → ۴۲۲ «نامعتبر» قبل از هر کوئری اجرا
 *  ④ اجرای دیگری (executor-scoped null) → ۴۰۴ «یافت نشد»
 *  ۵ شکست گارد سرویس (مثلاً مالک) → ۴۲۲ با پاسِ پیام سرویس
 */
final class SocialTaskControllerRateExecutionTest extends TestCase
{
    private SocialTaskService&MockInterface $service;
    private Request&MockInterface $request;
    private Session&MockInterface $session;
    private LoggerInterface&MockInterface $logger;

    protected function tearDown(): void
    {
        Mockery::close();
        // mockهای Session/Request نباید در Container به تست‌های بعدی نشت کنند
        app(\Core\Container::class)->forget(Request::class);
        app(\Core\Container::class)->singleton(Session::class, fn () => Session::getInstance());
        parent::tearDown();
    }

    private function boot(int $userId = 7): void
    {
        $this->logger = Mockery::mock(LoggerInterface::class);
        $this->logger->shouldReceive('warning')->byDefault();
        $this->logger->shouldReceive('error')->byDefault();

        $this->request = Mockery::mock(Request::class);
        $this->request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $this->request->shouldReceive('param')->with('id')->andReturn('55')->byDefault();

        // BaseController سازنده: request/session/... را از Container می‌گیرد
        // (null ?? app(...)) — mock را در Container می‌بندیم (الگوی P3)
        app(\Core\Container::class)->instance(Request::class, $this->request);

        $this->session = Mockery::mock(Session::class);
        $this->session->shouldReceive('get')->with('user_id')->andReturn($userId)->byDefault();
        app(\Core\Container::class)->instance(Session::class, $this->session);

        $this->service = Mockery::mock(SocialTaskService::class);
    }

    private function controller(): SocialTaskController
    {
        return new SocialTaskController($this->service, $this->logger);
    }

    /** @param array<string, mixed> $body */
    private function setBody(array $body): void
    {
        $this->request->shouldReceive('body')->withNoArgs()->andReturn($body)->byDefault();
    }

    /** اجرای callback و گرفتن پاسخ JSON به‌همراه status (الگوی InteractionApiControllerSocialGuardTest). @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> $decoded */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    /** @return \stdClass اجرای متعلق به کاربر ۷ روی آگهی ۱۱ */
    private function execution(string $status): \stdClass
    {
        return (object)[
            'id' => 55,
            'ad_id' => 11,
            'executor_id' => 7,
            'status' => $status,
            'ad_title' => 'کمپین آزمایشی',
        ];
    }

    // ─────────────── ① مسیر موفق: اجرای approved ───────────────

    public function test_approved_execution_delegates_to_guarded_service(): void
    {
        $this->boot();
        $this->setBody(['stars' => 4, 'comment' => 'تعامل خوبی داشت']);
        $this->service->shouldReceive('getExecutionWithAd')->once()->with(55, 7)->andReturn($this->execution('approved'));
        $this->service->shouldReceive('rateTask')->once()->with(7, 11, 4, 'تعامل خوبی داشت')
            ->andReturn(['success' => true, 'message' => 'امتیاز با موفقیت ثبت شد']);

        $out = $this->capture(fn () => $this->controller()->rateExecution());
        $this->assertSame(200, $out['__status']);
        $this->assertTrue((bool)$out['success']);
    }

    // ─────────────── ② گارد وضعیت: فقط approved ───────────────

    /** @dataProvider nonApprovedStatuses */
    public function test_non_approved_execution_is_rejected_before_service(string $status): void
    {
        $this->boot();
        $this->setBody(['stars' => 5]);
        $this->service->shouldReceive('getExecutionWithAd')->once()->with(55, 7)->andReturn($this->execution($status));
        $this->service->shouldReceive('rateTask')->never();

        $out = $this->capture(fn () => $this->controller()->rateExecution());
        $this->assertSame(422, $out['__status']);
        $this->assertStringContainsString('پس از تأیید', (string)$out['message']);
    }

    /** @return list<array{string}> */
    public static function nonApprovedStatuses(): array
    {
        return [['in_progress'], ['submitted'], ['rejected'], ['pending'], ['cancelled']];
    }

    // ─────────────── ③ ستارهٔ نامعتبر: قبل از هر کوئری ───────────────

    /** @dataProvider invalidStars */
    public function test_invalid_stars_rejected_without_execution_lookup(int $stars): void
    {
        $this->boot();
        $this->setBody(['stars' => $stars]);
        $this->service->shouldReceive('getExecutionWithAd')->never();
        $this->service->shouldReceive('rateTask')->never();

        $out = $this->capture(fn () => $this->controller()->rateExecution());
        $this->assertSame(422, $out['__status']);
        $this->assertSame('امتیاز نامعتبر است', (string)$out['message']);
    }

    /** @return list<array{int}> */
    public static function invalidStars(): array
    {
        return [[0], [-1], [6], [9], [100]];
    }

    // ─────────────── ۴ اجرای غیرخود / ناموجود ───────────────

    public function test_foreign_or_missing_execution_is_404(): void
    {
        $this->boot();
        $this->setBody(['stars' => 5]);
        // getExecutionWithAd اجرا را executor-scoped می‌خواند (id + executor_id)
        $this->service->shouldReceive('getExecutionWithAd')->once()->with(55, 7)->andReturn(null);
        $this->service->shouldReceive('rateTask')->never();

        $out = $this->capture(fn () => $this->controller()->rateExecution());
        $this->assertSame(404, $out['__status']);
        $this->assertSame('اجرای تسک یافت نشد', (string)$out['message']);
    }

    // ─────────────── ۵ شکست گارد سرویس → ۴۲۲ با پیام سرویس ───────────────

    public function test_service_guard_failure_passes_through_as_422(): void
    {
        $this->boot();
        $this->setBody(['stars' => 5]);
        $this->service->shouldReceive('getExecutionWithAd')->once()->andReturn($this->execution('approved'));
        $this->service->shouldReceive('rateTask')->once()->andReturn(['success' => false, 'message' => 'امتیاز دادن به تسک خودتان مجاز نیست']);

        $out = $this->capture(fn () => $this->controller()->rateExecution());
        $this->assertSame(422, $out['__status']);
        $this->assertStringContainsString('خودتان', (string)$out['message']);
    }
}
