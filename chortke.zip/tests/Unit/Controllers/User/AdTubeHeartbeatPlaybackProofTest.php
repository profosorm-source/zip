<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\User;

use App\Services\Ads\AdsBudgetSettlementService;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-S20-CLOSE-F1 (پایان‌کار بازبینی S20 — یافتهٔ ۱، P1) — پین‌های «سیگنال پخش واقعی»:
 *
 * قلب یافتهٔ ۱: پاداش قبلاً از «زمان باز بودن صفحه × ادعای سرعتِ کلاینت» می‌آمد؛
 * مهاجمِ POST مستقیم با playback_speed=2.5 در required÷2.۵ ثانیهٔ حضور — بدون حتی
 * یک فریم پخش — پاداش کامل می‌گرفت. قرارداد جدید:
 *   ۱) ماشین حالت heartbeat (AdsBudgetSettlementService::accumulateHeartbeatState) — انباشتهٔ
 *      «ثانیه‌های پخش» فقط با افزایش شمارندهٔ کلاینت، فقط playing=true، و هرگز
 *      بیشتر از Δ زمان دیواری سرور + ۱ث (قفل ۱×).
 *   ۲) computeAdTubeMetrics با سیگنال غیر-null: سیگنال «تنها منبع» ثانیه‌های
 *      محتوایی است — ادعای watch_time دیگر progress نمی‌سازد؛ سیگنالِ بیش از
 *      سقف فیزیکی = fraud.
 *   ۳) سیم‌کشی (پین سورس — سناریوی کامل settle به DB واقعی نیاز دارد، الگوی
 *      AdTubeDurationMismatchGateTest): گارد fail-closed بدون سیگنال در settle،
 *      عبور سیگنال از submit، روت heartbeat، حذف فیلد playback_speed از فرم.
 */
final class AdTubeHeartbeatPlaybackProofTest extends TestCase
{
    // ─── ۱) ماشین حالت heartbeat (pure) ────────────────────────────────────

    public function test_first_heartbeat_only_baselines_no_seconds_granted(): void
    {
        // مهاجم بلافاصله played_seconds=30 می‌فرستد — heartbeat اول فقط مبنا ست
        // می‌کند؛ هیچ ثانیه‌ای اعتبار نمی‌گیرد (پرشِ انباشته غیرممکن است).
        $s = AdsBudgetSettlementService::accumulateHeartbeatState(null, 30, true, 1, 1000);
        $this->assertSame(0, $s['accum']);
        $this->assertSame(1000, $s['first_ts']);
        $this->assertSame(30, $s['last_client']);
        $this->assertSame(0, AdsBudgetSettlementService::effectiveHeartbeatSeconds($s, 1000));
    }

    public function test_playing_heartbeat_accumulates_up_to_wall_delta_plus_one(): void
    {
        // پخش صادقانه: beat هر ۵ ثانیه، Δ کلاینت ۵، Δ دیواری ۵ → انباشته ۵×n
        $s = AdsBudgetSettlementService::accumulateHeartbeatState(null, 0, true, 1, 1000);
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 5, true, 2, 1005);
        $this->assertSame(5, $s['accum']);
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 10, true, 3, 1010);
        $this->assertSame(10, $s['accum']);
        $this->assertSame(10, AdsBudgetSettlementService::effectiveHeartbeatSeconds($s, 1010));
    }

    public function test_client_claim_above_wall_delta_is_clamped_to_one_x(): void
    {
        // مهاجم در ۵ ثانیهٔ دیواری ادعای +۱۰۰ ثانیه پخش می‌کند → فقط ۵+۱=۶
        // (قفل ۱× + تلورانس ۱ث) اعتبار می‌گیرد.
        $s = AdsBudgetSettlementService::accumulateHeartbeatState(null, 0, true, 1, 2000);
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 100, true, 2, 2005);
        $this->assertSame(6, $s['accum'], 'افزایش انباشته ≤ Δ دیواری + ۱ (قفل ۱×)');
    }

    public function test_paused_heartbeat_accumulates_nothing(): void
    {
        // توقف پخش: شمارندهٔ کلاینت ثابت می‌ماند → هیچ انباشته‌ای؛ حتی اگر
        // مهاجم حین playing=false شمارنده را هم بالا ببرد (playing=false → نه).
        $s = AdsBudgetSettlementService::accumulateHeartbeatState(null, 0, true, 1, 3000);
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 0, false, 2, 3005);
        $this->assertSame(0, $s['accum']);
        // ادعای شمارندهٔ بالاتر حین paused هم انباشته نمی‌شود:
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 20, false, 3, 3010);
        $this->assertSame(0, $s['accum'], 'playing=false → هیچ انباشته');
    }

    public function test_client_counter_reset_cannot_reclaim_same_seconds(): void
    {
        // مهاجم شمارنده را ریست و همان ثانیه‌ها را دوباره ادعا می‌کند —
        // پایهٔ last_client فقط بالا می‌رود؛ ادعای دوباره Δ مثبت نمی‌سازد.
        $s = AdsBudgetSettlementService::accumulateHeartbeatState(null, 0, true, 1, 4000);
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 5, true, 2, 4005);
        $this->assertSame(5, $s['accum']);
        // ریست به صفر:
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 0, true, 3, 4010);
        $this->assertSame(5, $s['accum'], 'ریست شمارنده انباشته را کم نمی‌کند');
        // ادعای دوبارهٔ همان ۵ ثانیه در beat بعدی:
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 5, true, 4, 4015);
        $this->assertSame(5, $s['accum'], 'ادعای دوبارهٔ همان ثانیه‌ها Δ جدید نمی‌سازد (پایه فقط بالا می‌رود)');
        // فقط ثانیه‌های تازه (فراتر از پایهٔ قبلی) شمرده می‌شوند:
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 9, true, 5, 4020);
        $this->assertSame(9, $s['accum']);
    }

    public function test_dense_heartbeat_under_one_second_does_not_accumulate(): void
    {
        // کش‌کوبی: beatهای متراکم‌تر از ۱ ثانیه فقط مبنا را همگام می‌کنند
        $s = AdsBudgetSettlementService::accumulateHeartbeatState(null, 0, true, 1, 5000);
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 1, true, 2, 5000);
        $this->assertSame(0, $s['accum'], 'Δ دیواری صفر → بدون انباشت');
    }

    public function test_effective_seconds_clamped_by_wall_time_since_first_beat(): void
    {
        // تورمِ ناشی از heartbeat های هم‌زمان (شرایط مسابقه‌ای): مقدار ذخیره‌شده
        // ممکن است بالاتر رفته باشد؛ خوانده‌شده هرگز از زمان دیواریِ خودِ جریان
        // (از اولین beat) بیشتر نیست — سقف مطلق ۱×.
        $inflated = [
            'accum' => 120, 'last_ts' => 1060, 'last_client' => 120,
            'seq' => 24, 'first_ts' => 1000, 'beats' => 25,
        ];
        $this->assertSame(60, AdsBudgetSettlementService::effectiveHeartbeatSeconds($inflated, 1060), 'انباشتهٔ متورم به ۶۰ ثانیهٔ دیواری کلمپ می‌شود');
        $this->assertSame(0, AdsBudgetSettlementService::effectiveHeartbeatSeconds($inflated, 1000), 'قبل از first_ts → صفر');
    }

    public function test_seq_is_monotonic_and_beats_counted(): void
    {
        $s = AdsBudgetSettlementService::accumulateHeartbeatState(null, 0, true, 7, 100);
        $s = AdsBudgetSettlementService::accumulateHeartbeatState($s, 1, true, 3, 105); // seq قدیمی
        $this->assertSame(7, $s['seq'], 'seq فقط بالا می‌رود');
        $this->assertSame(2, $s['beats']);
    }

    // ─── ۲) موتور سنجش با سیگنال پخش (computeAdTubeMetrics) ────────────────

    public function test_zero_signal_yields_zero_progress_even_with_full_claim(): void
    {
        // سناریوی یافتهٔ ۱ (POST مستقیم): ۳۰ ثانیه صفحه باز، ادعای watch_time=30،
        // سرعت 1.0 — ولی سیگنال پخش صفر (هیچ heartbeat ای نرسیده) → progress=0
        // → تسویه با آستانهٔ ۸۰٪ رد می‌کند. ادعا دیگر پیشرفت نمی‌خرد.
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1030, 30, 1.0, 30, 1.0, 0);
        $this->assertSame(30, $m['elapsed_seconds']);
        $this->assertFalse($m['fraud'], 'ادعای در سقف فیزیکی = fraud نیست؛ فقط بی‌اثر است');
        $this->assertSame(0, $m['progress_percent'], 'بدون سیگنال پخش، پیشرفتی وجود ندارد');
        $this->assertSame(0, $m['watch_seconds']);
    }

    public function test_real_playback_signal_reaches_reward_threshold(): void
    {
        // تماشای صادقانه: ۲۴ ثانیهٔ پخش واقعی (heartbeat) در ۳۰ ثانیهٔ دیواری،
        // ویدیوی ۳۰ثانیه‌ای → progress = 80 → عبور آستانه؛ watch = سیگنال (۲۴).
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1030, 24, 1.0, 30, 1.0, 24);
        $this->assertSame(80, $m['progress_percent']);
        $this->assertSame(24, $m['watch_seconds']);
        $this->assertFalse($m['fraud']);
    }

    public function test_signal_beats_client_claim_and_clamps_to_ceiling(): void
    {
        // ادعای watch_time=30 ولی سیگنال پخش ۲۰ → watch/progress از سیگنال:
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1030, 30, 1.0, 30, 1.0, 20);
        $this->assertSame(20, $m['watch_seconds'], 'منبع واحد ثانیه‌های محتوایی = سیگنال سرور');
        $this->assertSame(66, $m['progress_percent'], 'floor(20/30×100)=66 — ادعای ۳۰ نادیده');
    }

    public function test_forged_signal_above_physical_ceiling_is_fraud(): void
    {
        // جعل جریان heartbeat: سیگنال ۴۰ در ۳۰ ثانیهٔ دیواری (سقف ۳۰+۳) → fraud
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1030, 30, 1.0, 30, 1.0, 40);
        $this->assertTrue($m['fraud'], 'سیگنال بیش از سقف فیزیکی = جعل');
    }

    public function test_speed_claim_does_not_shorten_reward_with_signal(): void
    {
        // یافتهٔ ۱ (قلب باگ): ادعای 2.5x + سیگنال ۲۴ در ۱۲ ثانیهٔ دیواری →
        // سقف فیزیکی 12×1.0=12 → سیگنال کلمپ به 12 → progress 40 (نه 100).
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1012, 30, 2.5, 30, 1.0, 24);
        $this->assertSame(1.0, $m['speed'], 'سرعت ادعایی به ۱× کلمپ');
        $this->assertSame(12, $m['max_content_seconds']);
        $this->assertSame(40, $m['progress_percent'], '12/30=40٪ — سرعتِ ادعایی پاداش را کوتاه نمی‌کند');
    }

    // ─── ۳) سیم‌کشی — پین سورس (الگوی AdTubeDurationMismatchGateTest) ──────

    public function test_settle_path_is_fail_closed_without_signal(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Services/Ads/AdsBudgetSettlementService.php');
        // گارد fail-closed: بدون سیگنال پخش، تسویه رد و ردیف rejected می‌شود
        $this->assertStringContainsString('if ($heartbeatPlayedSeconds <= 0) {', $src, 'گارد نبودِ سیگنال پخش در settleAdTubeView');
        $this->assertStringContainsString('سیگنال پخش واقعی (heartbeat) برای این اجرا ثبت نشده است.', $src, 'دلیل رد باید صادقانه در reject_reason ثبت شود');
        // سیگنال باید به computeAdTubeMetrics هم برسد (قفل ۱× دفاع در عمق)
        $this->assertStringContainsString("\$heartbeatPlayedSeconds\n            );", $src);
    }

    public function test_submit_wiring_passes_signal_and_uses_hard_ceiling(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Controllers/User/AdtubeController.php');
        // submit: خواندن انباشتهٔ سرور + گارد زودهنگام دوستانه (بدون markRejected)
        $this->assertStringContainsString('$this->readHeartbeatPlayedSeconds($execId, $userId)', $src);
        // سرعت: فقط سقف سخت ۲.۵ (مقدار غیرممکن) رد می‌شود — نه سقف سیاستِ ۱×
        $this->assertStringContainsString('if ($speed > self::ADTUBE_HARD_SPEED_CEILING) {', $src);
        // سیگنال به settle پاس می‌شود
        $this->assertStringContainsString('$finance->settleAdTubeView($execId, $userId, $watchTime, $progress, $speed, $playerDuration, $heartbeatPlayedSeconds)', $src);
    }

    public function test_heartbeat_route_is_registered(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/routes/missing.php');
        $this->assertStringContainsString("'/adtube/{id}/heartbeat'", $src, 'روت POST /adtube/{id}/heartbeat ثبت شده باشد');
        $this->assertStringContainsString("[AdtubeController::class, 'heartbeat']", $src);
    }

    public function test_player_js_tracks_real_playback_and_heartbeats(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/public/assets/js/views/useradtubeexecute.js');
        // ردیابی وضعیت واقعی پلیر
        $this->assertStringContainsString("onStateChange", $src, 'JS باید وضعیت واقعی پلیر (IFrame API) را رصد کند');
        $this->assertStringContainsString('isPlaying()', $src);
        // شمارش فقط حین پخش
        $this->assertStringContainsString('if (isPlaying()) {', $src, 'شمارنده فقط وقتی پیش برود که پلیر در حال پخش باشد');
        // heartbeat با چالش و شمارندهٔ تجمعی
        $this->assertStringContainsString("watch_challenge: watchChallengeInput ? watchChallengeInput.value : ''", $src);
        $this->assertStringContainsString('played_seconds: played', $src);
        $this->assertStringContainsString("playing: isPlaying()", $src);
        // پخش خودکار مجدد برای ویدیوی کوتاه
        $this->assertStringContainsString("seekTo", $src);
    }

    public function test_execute_form_no_longer_sends_speed_claim(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/views/user/adtube/execute.php');
        // فیلد مخفی playback_speed حذف شده (ادعای سرعت جزو فرم صادقانه نیست)
        $this->assertStringNotContainsString('name="playback_speed"', $src, 'فیلد playback_speed باید از فرم حذف شود');
        // cache-bust واقعی JS (filemtime) — پلیر جدید باید جای نسخهٔ کش‌شده بنشیند
        $this->assertStringContainsString('filemtime($playerJsPath)', $src);
    }
}
