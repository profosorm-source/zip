<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\User;

use App\Controllers\User\SeoController;
use App\Models\Ads;
use App\Models\SeoExecution;
use App\Services\Seo\SeoService;
use Core\Exceptions\HttpResponseException;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-05 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲):
 * ریدایرکت شمارندهٔ کلیک ‎/seo/{id}/go/{token}‎ باید برای «مهمان» هم کار کند —
 * اپ موبایل این لینک را در مرورگر سیستمی باز می‌کند و آنجا session وب نیست.
 *
 * قرارداد جدید (capability URL):
 *  ① مهمان + توکن معتبرِ همان اجرا → کلیک با مالکِ واقعی (از ردیف توکن) مهر می‌شود
 *  ② مهمان + توکن نامعتبر/غیرهمتا → همان پاسخ عمومی وب («تسک یافت نشد»)؛ بدون مصرف
 *  ③ مهمان + اجرای غیر-started با توکن معتبر → رد (همان گارد وب)
 *  ④ کاربر لاگین‌شده → مسیر وب قبلی بیت‌به‌بیت (مالکیت session همچنان الزامی)
 *  ⑤ مسیر route عمومی است (بدون AuthMiddleware) — پین سیم‌کشی routes/user.php
 */
final class SeoGoGuestAccessTest extends TestCase
{
    private Ads&MockInterface $adModel;
    private SeoExecution&MockInterface $executionModel;
    private SeoService&MockInterface $seoService;
    private Request&MockInterface $request;
    private Response $response;
    private Session&MockInterface $session;

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    private function controller(): SeoController
    {
        // ساخت بدون constructor (الگوی P3AccountDeletionControllerPinTest) —
        // وایر کردن وابستگی‌های go() با reflection
        $ref = new \ReflectionClass(SeoController::class);
        $controller = $ref->newInstanceWithoutConstructor();
        foreach (['adModel' => $this->adModel, 'executionModel' => $this->executionModel, 'seoService' => $this->seoService] as $prop => $dep) {
            $p = $ref->getProperty($prop);
            $p->setAccessible(true);
            $p->setValue($controller, $dep);
        }
        // session والد (BaseController::$session) برای شاخه‌های خطا
        $base = new \ReflectionClass(\App\Controllers\BaseController::class);
        $sp = $base->getProperty('session');
        $sp->setAccessible(true);
        $sp->setValue($controller, $this->session);
        $rp = $base->getProperty('response');
        $rp->setAccessible(true);
        $rp->setValue($controller, $this->response);
        $rq = $base->getProperty('request');
        $rq->setAccessible(true);
        $rq->setValue($controller, $this->request);

        // landingProof سبک با حالت off — هرگز DB واقعی نمی‌خواهد
        $lp = $ref->getProperty('landingProof');
        $lp->setAccessible(true);
        $lp->setValue($controller, new \App\Services\SeoLandingProofService(
            $this->executionModel,
            Mockery::mock(\App\Models\SeoLandingProofTest::class),
            $this->adModel,
            Mockery::mock(\Core\Database::class),
            Mockery::mock(\App\Contracts\LoggerInterface::class),
        ));

        return $controller;
    }

    private function boot(): void
    {
        $this->adModel = Mockery::mock(Ads::class);
        $this->executionModel = Mockery::mock(SeoExecution::class);
        $this->seoService = Mockery::mock(SeoService::class);
        $this->request = Mockery::mock(Request::class);
        $this->response = new Response();
        $this->session = Mockery::mock(Session::class);
        $this->session->shouldReceive('setFlash')->byDefault();
    }

    /** @param array<string, mixed> $overrides */
    private function execution(int $id, int $userId, array $overrides = []): SeoExecution
    {
        $row = array_merge([
            'id' => $id, 'ad_id' => 3, 'user_id' => $userId, 'status' => 'started',
            'time_score' => 0.0, 'scroll_score' => 0.0, 'interaction_score' => 0.0,
            'quality_score' => 0.0, 'final_score' => 0.0, 'payout_amount' => 0.0,
            'ip_address' => '127.0.0.1', 'started_at' => '2026-11-02 10:00:00',
            'created_at' => '2026-11-02 10:00:00',
            'click_counted_at' => null, 'landing_verified_at' => null,
            'landing_proof_channel' => null, 'completed_at' => null,
        ], $overrides);
        $mock = Mockery::mock(SeoExecution::class)->makePartial();
        foreach ($row as $k => $v) {
            $mock->{$k} = $v;
        }
        return $mock;
    }

    private function ad(): \stdClass
    {
        return (object)[
            'id' => 3, 'status' => 'active', 'site_url' => 'https://advertiser.example/landing',
            'seo_landing_proof_mode' => 'off',
        ];
    }

    /** @param array<string, mixed> $byTokenRow */
    private function setParams(int $id, string $token, ?array $byTokenRow): void
    {
        $this->request->shouldReceive('param')->with('id')->andReturn((string)$id)->byDefault();
        $this->request->shouldReceive('param')->with('token')->andReturn($token)->byDefault();
        if ($byTokenRow !== null) {
            $this->executionModel->shouldReceive('findByClickToken')->with($token)->andReturn($byTokenRow)->byDefault();
        } else {
            $this->executionModel->shouldReceive('findByClickToken')->with($token)->andReturn(null)->byDefault();
        }
    }

    private function capture(callable $fn): HttpResponseException
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (redirect) پرتاب شود');
        } catch (HttpResponseException $e) {
            return $e;
        }
    }

    public function test_guest_with_valid_token_counts_click_as_real_owner(): void
    {
        $this->boot();
        // مهمان (بدون user_id در session singleton)
        $this->setParams(5, str_repeat('a', 48), [
            'id' => 5, 'ad_id' => 3, 'user_id' => 7, 'status' => 'started',
            'click_counted_at' => null, 'click_token_expires_at' => null, 'landing_verified_at' => null,
        ]);
        $this->executionModel->shouldReceive('find')->with(5)->andReturn($this->execution(5, 7));
        // مهر کلیک باید با مالکِ واقعیِ اجرا (۷) انجام شود — نه مهمان.
        // 🛡️ FIX-T23H-01: دو آرگومان جدید شواهد لحظهٔ کلیک (IP + UA) هم
        // پاس می‌شوند — m::any() چون مقدارشان به $_SERVER محیط تست وابسته است.
        $this->executionModel->shouldReceive('consumeClickToken')->once()->with(5, 7, str_repeat('a', 48), \Mockery::any(), \Mockery::any())->andReturn(true);
        $this->adModel->shouldReceive('find')->with(3)->andReturn($this->ad());

        $e = $this->capture(fn () => $this->controller()->go());
        $this->assertSame('https://advertiser.example/landing', $e->getResponse()->getHeader('Location'));
    }

    public function test_guest_with_wrong_token_gets_generic_not_found(): void
    {
        $this->boot();
        $this->setParams(5, str_repeat('d', 48), null); // توکن ناشناخته
        $this->executionModel->shouldNotReceive('consumeClickToken');
        $this->executionModel->shouldNotReceive('find');

        $e = $this->capture(fn () => $this->controller()->go());
        // ریدایرکت خطا به صفحهٔ عمومی /seo — نه آدرس تبلیغ‌دهنده
        $this->assertNotSame('https://advertiser.example/landing', $e->getResponse()->getHeader('Location'));
    }

    public function test_guest_token_belonging_to_another_execution_is_rejected(): void
    {
        $this->boot();
        // توکن معتبر اما برای اجرای دیگر (id=6) — mismatch با id مسیر (5)
        $this->setParams(5, str_repeat('e', 48), [
            'id' => 6, 'ad_id' => 3, 'user_id' => 7, 'status' => 'started',
            'click_counted_at' => null, 'click_token_expires_at' => null, 'landing_verified_at' => null,
        ]);
        $this->executionModel->shouldNotReceive('consumeClickToken');

        $e = $this->capture(fn () => $this->controller()->go());
        $this->assertNotSame('https://advertiser.example/landing', $e->getResponse()->getHeader('Location'));
    }

    public function test_guest_with_valid_token_but_non_started_execution_is_rejected(): void
    {
        $this->boot();
        $this->setParams(5, str_repeat('f', 48), [
            'id' => 5, 'ad_id' => 3, 'user_id' => 7, 'status' => 'completed',
            'click_counted_at' => '2026-11-02 10:01:00', 'click_token_expires_at' => null, 'landing_verified_at' => null,
        ]);
        $this->executionModel->shouldReceive('find')->with(5)->andReturn($this->execution(5, 7, ['status' => 'completed', 'click_counted_at' => '2026-11-02 10:01:00']));
        $this->executionModel->shouldNotReceive('consumeClickToken');
        $this->adModel->shouldNotReceive('find');

        $e = $this->capture(fn () => $this->controller()->go());
        $this->assertNotSame('https://advertiser.example/landing', $e->getResponse()->getHeader('Location'));
    }

    public function test_guest_already_counted_click_is_idempotent_redirect(): void
    {
        $this->boot();
        $this->setParams(5, str_repeat('g', 48), [
            'id' => 5, 'ad_id' => 3, 'user_id' => 7, 'status' => 'started',
            'click_counted_at' => '2026-11-02 10:01:00', 'click_token_expires_at' => null, 'landing_verified_at' => null,
        ]);
        $this->executionModel->shouldReceive('find')->with(5)->andReturn(
            $this->execution(5, 7, ['click_counted_at' => '2026-11-02 10:01:00'])
        );
        // کلیک قبلاً مهر شده — نباید دوباره مصرف شود
        $this->executionModel->shouldNotReceive('consumeClickToken');
        $this->adModel->shouldReceive('find')->with(3)->andReturn($this->ad());

        $e = $this->capture(fn () => $this->controller()->go());
        $this->assertSame('https://advertiser.example/landing', $e->getResponse()->getHeader('Location'));
    }

    public function test_logged_in_user_path_is_unchanged_and_ownership_enforced(): void
    {
        $this->boot();
        // کاربر session‌دار ۷ — مسیر وب؛ findByClickToken اصلاً نباید لازم شود
        $session = Session::getInstance();
        $session->ensureStarted();
        $session->set('user_id', 7);
        try {
            $this->setParams(5, str_repeat('h', 48), null); // توکن جعلی برای مسیر session
            $this->executionModel->shouldReceive('find')->with(5)->andReturn($this->execution(5, 99)); // مالک دیگر
            $this->executionModel->shouldNotReceive('consumeClickToken');

            $e = $this->capture(fn () => $this->controller()->go());
            $this->assertNotSame('https://advertiser.example/landing', $e->getResponse()->getHeader('Location'), 'اجرای کاربر دیگر باید رد شود (مسیر وب دست‌نخورده)');
        } finally {
            $session->remove('user_id');
        }
    }

    // ─────────────── پین سیم‌کشی route ───────────────

    public function test_go_route_is_public_not_session_gated(): void
    {
        $user = (string)file_get_contents(dirname(__DIR__, 4) . '/routes/user.php');
        // مسیر go باید بدون $auth ثبت شده باشد (عمومی مثل pixel)
        $this->assertRegExp(
            "#\\\$r->get\('/seo/\{id\}/go/\{token\}',\s*\[SeoController::class,\s*'go'\],\s*\[\]\)#",
            $user,
            'route go باید بدون AuthMiddleware باشد (capability URL مهمان)'
        );
        // توضیح FIX-MOBILE-05 باید کنار مسیر مستند باشد
        $this->assertStringContainsString('FIX-MOBILE-05', $user);
    }

    public function test_seo_controller_guest_branch_is_pinned(): void
    {
        $src = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Controllers/User/SeoController.php');
        // شاخهٔ مهمان: user_id() <= 0 → findByClickToken + مالک از ردیف توکن
        $this->assertStringContainsString('if ($userId <= 0) {', $src);
        $this->assertStringContainsString('findByClickToken', $src);
        $this->assertStringContainsString('FIX-MOBILE-05', $src);
    }
}
