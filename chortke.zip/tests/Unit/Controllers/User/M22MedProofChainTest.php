<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers\User;

use App\Controllers\User\CustomTaskController;
use App\Jobs\CustomTask\SubmitProofJob;
use App\Models\Ads;
use App\Models\CustomTaskAnalyticsModel;
use App\Models\CustomTaskSubmissionModel;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\CustomTask\CustomTaskProofFileService;
use App\Services\CustomTask\CustomTaskProofSchema;
use App\Services\Shared\DisputeService;
use App\Services\UploadService;
use App\Validators\Requests\SubmitCustomTaskProofRequest;
use Core\Exceptions\HttpResponseException;
use Core\Logger;
use Core\Request;
use Core\Response;
use Core\Session;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M22-MED (T22-14 + T22-18 + D2-N13) — زنجیرهٔ مدرک تسک سفارشی:
 *  ۱) PDF/ویدیو هم مثل تصویر هش sha256 سمتِ سرور دارند (قبلاً null).
 *  ۲) proof_file/proof_file_hash/idempotency_key هرگز از ورودی کلاینت به جاب
 *     نمی‌روند — کانال فایل فقط از نتیجهٔ آپلود سرور ساخته می‌شود.
 *  ۳) خطای اعتبارسنجیِ «بعد از آپلود» فایلِ آپلودشده را پاک می‌کند (orphan).
 *  ۴) قرارداد مشترک CustomTaskProofSchema در هر دو فراخوان (کنترلر + جاب).
 */
final class M22MedProofChainTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        unset($_FILES['proof_file']);
        parent::tearDown();
    }

    /** فایل موقت واقعی روی دیسک — همان الگوی شاخهٔ تصویر برای is_file/hash_file */
    private function tempProofFile(string $contents): string
    {
        $path = (string)tempnam(sys_get_temp_dir(), 'm22med');
        file_put_contents($path, $contents);
        return $path;
    }

    private function hexName(string $ext): string
    {
        return 'task-proofs/' . bin2hex(random_bytes(12)) . '.' . $ext;
    }

    /**
     * کنترلر با تمام وابستگی‌های mock — نمونهٔ بدون-سازنده + تزریق
     * Reflection (الگوی M22StartGuards؛ سازندهٔ BaseUserController از کانتینر
     * AuthService/UserService/CaptchaService می‌سازد و در محیط بدون-DB می‌شکند).
     *
     * @return array{0: CustomTaskController, 1: UploadService&\Mockery\MockInterface, 2: \App\Services\CustomTask\CustomTaskExecutorService&\Mockery\MockInterface, 3: CustomTaskSubmissionModel&\Mockery\MockInterface, 4: Request&\Mockery\MockInterface, 5: Session&\Mockery\MockInterface}
     */
    private function buildController(): array
    {
        $executor = m::mock(\App\Services\CustomTask\CustomTaskExecutorService::class);
        $moderation = m::mock(CustomTaskModerationService::class);
        $upload = m::mock(UploadService::class);
        $ads = m::mock(Ads::class);
        $dispute = m::mock(DisputeService::class);
        $submissionModel = m::mock(CustomTaskSubmissionModel::class);
        $analytics = m::mock(CustomTaskAnalyticsModel::class);
        $logger = m::mock(Logger::class);
        $logger->shouldReceive('warning')->zeroOrMoreTimes();
        $logger->shouldReceive('error')->zeroOrMoreTimes();

        $controller = (new \ReflectionClass(CustomTaskController::class))->newInstanceWithoutConstructor();

        $session = m::mock(Session::class);
        $session->shouldReceive('get')->andReturnUsing(static function (string $key): mixed {
            return $key === 'user_id' ? 77 : null;
        })->byDefault();
        $session->shouldReceive('setFlash')->zeroOrMoreTimes();
        $request = m::mock(Request::class);
        // توجه: انتظارِ «پهن» باید یک‌تکه باشد؛ with('id') جدا با انتظار پهنِ بعدی
        // override می‌شود (آزمون شد: param(id) به پهنی می‌افتاد). اینجا وابسته به کلید.
        $request->shouldReceive('param')->andReturnUsing(static function (?string $key = null, ?string $default = null): ?string {
            return $key === 'id' ? '55' : $default;
        })->byDefault();
        $request->shouldReceive('all')->andReturn([])->byDefault();
        $request->shouldReceive('int')->andReturn(1)->byDefault();

        $inject = static function (object $target, string $class, string $prop, mixed $value): void {
            $r = new \ReflectionProperty($class, $prop);
            $r->setAccessible(true);
            $r->setValue($target, $value);
        };
        // پراپرتی‌های خصوصی خودِ کنترلر
        $inject($controller, CustomTaskController::class, 'executorService', $executor);
        $inject($controller, CustomTaskController::class, 'moderationService', $moderation);
        // 📱 FIX-MOBCTR-01: کانال فایل حالا در سرویس مشترک است — سرویس واقعی روی
        // UploadService ماک‌شده (انتظار‌های همان متدها بی‌تغییر)
        $inject($controller, CustomTaskController::class, 'proofFileService', new CustomTaskProofFileService($upload));
        $inject($controller, CustomTaskController::class, 'adsModel', $ads);
        $inject($controller, CustomTaskController::class, 'disputeService', $dispute);
        $inject($controller, CustomTaskController::class, 'submissionModel', $submissionModel);
        $inject($controller, CustomTaskController::class, 'analyticsModel', $analytics);
        // پراپرتی‌های BaseController (session/request/response/...)
        $inject($controller, \App\Controllers\BaseController::class, 'session', $session);
        $inject($controller, \App\Controllers\BaseController::class, 'request', $request);
        $inject($controller, \App\Controllers\BaseController::class, 'response', new Response());
        $inject($controller, \App\Controllers\BaseController::class, 'logger', $logger);
        $inject($controller, \App\Controllers\BaseController::class, 'policyService', m::mock(\App\Services\Shared\PolicyService::class));
        $inject($controller, \App\Controllers\BaseController::class, 'csrf', m::mock(\Core\CSRF::class));
        $inject($controller, \App\Controllers\BaseController::class, 'validatorFactory', m::mock(\App\Contracts\ValidatorFactoryInterface::class));

        return [$controller, $upload, $executor, $submissionModel, $request, $session];
    }

    /** @param array<string, mixed> $submissionOverrides */
    private function inProgressSubmission(array $submissionOverrides = []): \stdClass
    {
        $s = (object)array_merge([
            'id' => 55,
            'task_id' => 11,
            'worker_id' => 77,
            'status' => 'in_progress',
            'proof_type' => 'text',
            'proof_schema' => null,
        ], $submissionOverrides);
        return $s;
    }

    /** @return array<string, mixed> */
    private function capture(callable $fn): array
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (json) پرتاب شود');
        } catch (HttpResponseException $e) {
            $r = $e->getResponse();
            /** @var array<string, mixed> */
            $decoded = json_decode((string)$r->getContent(), true) ?: [];
            $decoded['__status'] = $r->getStatusCode();
            return $decoded;
        }
    }

    private function storeProofFileViaReflection(CustomTaskController $controller, array $file, string $proofType): array
    {
        // 📱 FIX-MOBCTR-01: storeProofFile از کنترلر به CustomTaskProofFileService
        // منتقل شد — همان رفتار، همان انتظار‌ها.
        $method = new \ReflectionMethod(CustomTaskProofFileService::class, 'store');
        $method->setAccessible(true);
        /** @var array<string, mixed> */
        return $method->invoke($this->proofFileService($controller), $file, $proofType);
    }

    private function proofFileService(CustomTaskController $controller): CustomTaskProofFileService
    {
        $r = new \ReflectionProperty(CustomTaskController::class, 'proofFileService');
        $r->setAccessible(true);
        /** @var CustomTaskProofFileService */
        return $r->getValue($controller);
    }

    // ── ۱) T22-14: هش سرور برای PDF/ویدیو (قرینهٔ شاخهٔ تصویر) ───────

    /** @test */
    public function pdf_proof_carries_server_computed_sha256_hash(): void
    {
        [$controller, $upload] = $this->buildController();
        $tmp = $this->tempProofFile('%PDF-1.7 m22med');
        $relPath = $this->hexName('pdf');

        $upload->shouldReceive('uploadPrivateDocument')->once()
            ->with(m::on(static fn(array $f): bool => ($f['name'] ?? '') === 'report.pdf'), 'task-proofs', ['application/pdf'], 5 * 1024 * 1024)
            ->andReturn(['success' => true, 'filename' => 'x.pdf', 'path' => $relPath, 'url' => null, 'size' => 18, 'mime' => 'application/pdf', 'message' => '']);
        $upload->shouldReceive('getPath')->once()->with($relPath)->andReturn($tmp);

        $out = $this->storeProofFileViaReflection($controller, ['name' => 'report.pdf'], 'file');

        $this->assertSame($relPath, $out['path']);
        $this->assertSame(hash_file('sha256', $tmp), $out['hash'], 'هش PDF باید sha256 محاسبه‌شدهٔ سرور باشد');
        $this->assertNotSame('', (string)$out['hash']);
        unlink($tmp);
    }

    /** @test */
    public function video_proof_carries_server_computed_sha256_hash(): void
    {
        [$controller, $upload] = $this->buildController();
        $tmp = $this->tempProofFile('m22med-video-bytes');
        $relPath = $this->hexName('mp4');

        $upload->shouldReceive('uploadPrivateDocument')->once()
            ->with(m::on(static fn(array $f): bool => ($f['name'] ?? '') === 'clip.mp4'), 'task-proofs', ['video/mp4', 'video/webm', 'video/quicktime'], 30 * 1024 * 1024)
            ->andReturn(['success' => true, 'filename' => 'x.mp4', 'path' => $relPath, 'url' => null, 'size' => 20, 'mime' => 'video/mp4', 'message' => '']);
        $upload->shouldReceive('getPath')->once()->with($relPath)->andReturn($tmp);

        $out = $this->storeProofFileViaReflection($controller, ['name' => 'clip.mp4'], 'video');

        $this->assertSame($relPath, $out['path']);
        $this->assertSame(hash_file('sha256', $tmp), $out['hash'], 'هش ویدیو باید sha256 محاسبه‌شدهٔ سرور باشد');
        unlink($tmp);
    }

    /** @test */
    public function image_proof_branch_still_carries_server_hash(): void
    {
        [$controller, $upload] = $this->buildController();
        $tmp = $this->tempProofFile('m22med-png-bytes');
        $relPath = $this->hexName('png');

        $upload->shouldReceive('upload')->once()
            ->with(m::on(static fn(array $f): bool => ($f['name'] ?? '') === 'shot.png'), 'task-proofs', ['jpg', 'jpeg', 'png', 'webp'], 5 * 1024 * 1024)
            ->andReturn(['success' => true, 'filename' => 'x.png', 'path' => $relPath, 'url' => 'uploads/x', 'size' => 20, 'mime' => 'image/png', 'message' => '']);
        $upload->shouldReceive('getPath')->once()->with($relPath)->andReturn($tmp);

        $out = $this->storeProofFileViaReflection($controller, ['name' => 'shot.png'], 'screenshot');

        $this->assertSame(hash_file('sha256', $tmp), $out['hash']);
        unlink($tmp);
    }

    /** @test */
    public function missing_file_on_disk_yields_null_hash_not_crash(): void
    {
        [$controller, $upload] = $this->buildController();
        $relPath = $this->hexName('pdf');
        $upload->shouldReceive('uploadPrivateDocument')->once()
            ->andReturn(['success' => true, 'filename' => 'x.pdf', 'path' => $relPath, 'url' => null, 'size' => 1, 'mime' => 'application/pdf', 'message' => '']);
        $upload->shouldReceive('getPath')->once()->with($relPath)->andReturn(null);

        $out = $this->storeProofFileViaReflection($controller, ['name' => 'r.pdf'], 'file');
        $this->assertNull($out['hash'], 'getPath=null ⇒ hash=null (همان قرارداد شاخهٔ تصویر)');
    }

    // ── ۲) T22-18: مقادیر کلاینت نادیده گرفته می‌شوند ──────────────

    /** @test */
    public function client_supplied_proof_file_and_hash_are_never_forwarded_to_job(): void
    {
        [$controller, , $executor, $submissionModel, $request] = $this->buildController();
        $submissionModel->shouldReceive('submission_findForProof')->once()->with(55, 77)
            ->andReturn($this->inProgressSubmission(['proof_type' => 'text']));

        $forgedHash = str_repeat('a', 64); // 64-hex معتبر — جعل‌پذیرِ قبلی
        $request->shouldReceive('all')->once()->andReturn([
            'proof_text' => 'متن مدرک کاملاً معتبر برای پین',
            'proof_file' => 'task-proofs/evil-path-owned-by-others.png',
            'proof_file_hash' => $forgedHash,
            'idempotency_key' => 'FORGED_KEY_123456',
        ]);
        unset($_FILES['proof_file']); // بدون آپلود واقعی

        $executor->shouldReceive('submitProof')->once()
            ->with(55, 77, m::on(static function (array $data): bool {
                return ($data['proof_text'] ?? '') === 'متن مدرک کاملاً معتبر برای پین'
                    && ($data['task_execution_id'] ?? 0) === 55
                    && !array_key_exists('proof_file', $data)
                    && !array_key_exists('proof_file_hash', $data)
                    && !array_key_exists('idempotency_key', $data);
            }))
            ->andReturn(['success' => true, 'message' => 'ok']);

        $out = $this->capture(fn () => $controller->submitProof());
        $this->assertSame(200, $out['__status']);
    }

    /** @test */
    public function successful_upload_overrides_payload_with_server_values_only(): void
    {
        [$controller, $upload, $executor, $submissionModel, $request] = $this->buildController();
        $submissionModel->shouldReceive('submission_findForProof')->once()->with(55, 77)
            ->andReturn($this->inProgressSubmission(['proof_type' => 'file']));

        // کلاینت مقادیر جعلی می‌فرستد؛ آپلود واقعی سرور آن‌ها را بازنویسی می‌کند
        $request->shouldReceive('all')->once()->andReturn([
            'proof_file' => '/etc/passwd',
            'proof_file_hash' => str_repeat('b', 64),
            'idempotency_key' => 'forged',
        ]);
        $tmp = $this->tempProofFile('m22med-file-upload');
        $relPath = $this->hexName('png');
        $_FILES['proof_file'] = ['name' => 'proof.png', 'tmp_name' => $tmp, 'error' => UPLOAD_ERR_OK, 'size' => 21];

        $upload->shouldReceive('upload')->once()->andReturn(['success' => true, 'filename' => 'x.png', 'path' => $relPath, 'url' => null, 'size' => 21, 'mime' => 'image/png', 'message' => '']);
        $upload->shouldReceive('getPath')->once()->with($relPath)->andReturn($tmp);

        $executor->shouldReceive('submitProof')->once()
            ->with(55, 77, m::on(static function (array $data) use ($relPath, $tmp): bool {
                return ($data['proof_file'] ?? '') === $relPath
                    && ($data['proof_file_hash'] ?? '') === hash_file('sha256', $tmp)
                    && ($data['proof_file'] ?? '') !== '/etc/passwd'
                    && !array_key_exists('idempotency_key', $data);
            }))
            ->andReturn(['success' => true, 'message' => 'ok']);

        $out = $this->capture(fn () => $controller->submitProof());
        $this->assertSame(200, $out['__status']);
        unlink($tmp);
    }

    // ── ۳) D2-N13: پاک‌سازی فایل orphan در خطای پس از آپلود ─────────

    /** @test */
    public function schema_error_after_upload_deletes_the_uploaded_file(): void
    {
        [$controller, $upload, $executor, $submissionModel, $request] = $this->buildController();
        $submissionModel->shouldReceive('submission_findForProof')->once()->with(55, 77)
            ->andReturn($this->inProgressSubmission(['proof_type' => 'text']));

        // متن کوتاه ⇒ شاخهٔ متنی اسکیما پس از آپلود شکست می‌خورد
        $request->shouldReceive('all')->once()->andReturn(['proof_text' => 'کوتاه']);
        $tmp = $this->tempProofFile('m22med-orphan-1');
        $relPath = $this->hexName('png');
        $_FILES['proof_file'] = ['name' => 'proof.png', 'tmp_name' => $tmp, 'error' => UPLOAD_ERR_OK, 'size' => 20];

        $upload->shouldReceive('upload')->once()->andReturn(['success' => true, 'filename' => 'x.png', 'path' => $relPath, 'url' => null, 'size' => 20, 'mime' => 'image/png', 'message' => '']);
        $upload->shouldReceive('getPath')->once()->with($relPath)->andReturn($tmp);
        $upload->shouldReceive('delete')->once()->with($relPath)->andReturn(true);
        $executor->shouldReceive('submitProof')->never();

        $out = $this->capture(fn () => $controller->submitProof());
        $this->assertSame(422, $out['__status']);
        $this->assertStringContainsString('حداقل ۱۰ کاراکتر', (string)($out['message'] ?? ''));
    }

    /** @test */
    public function form_validation_error_after_upload_deletes_the_uploaded_file(): void
    {
        [$controller, $upload, $executor, $submissionModel, $request] = $this->buildController();
        $submissionModel->shouldReceive('submission_findForProof')->once()->with(55, 77)
            ->andReturn($this->inProgressSubmission(['proof_type' => 'text']));

        // اسکیما عبور می‌کند (>=10) اما فرم‌ریکوئست روی max:2000 می‌شکند
        $request->shouldReceive('all')->once()->andReturn(['proof_text' => str_repeat('م', 2500)]);
        $tmp = $this->tempProofFile('m22med-orphan-2');
        $relPath = $this->hexName('png');
        $_FILES['proof_file'] = ['name' => 'proof.png', 'tmp_name' => $tmp, 'error' => UPLOAD_ERR_OK, 'size' => 20];

        $upload->shouldReceive('upload')->once()->andReturn(['success' => true, 'filename' => 'x.png', 'path' => $relPath, 'url' => null, 'size' => 20, 'mime' => 'image/png', 'message' => '']);
        $upload->shouldReceive('getPath')->once()->with($relPath)->andReturn($tmp);
        $upload->shouldReceive('delete')->once()->with($relPath)->andReturn(true);
        $executor->shouldReceive('submitProof')->never();

        $out = $this->capture(fn () => $controller->submitProof());
        $this->assertSame(422, $out['__status']);
        $this->assertArrayHasKey('proof_text', $out['errors'] ?? []);
    }

    // ── ۴) کلاس مشترک CustomTaskProofSchema — رفتار پورت‌شده ────────

    /** @test */
    public function shared_schema_class_exists_and_normalizes_like_the_old_code(): void
    {
        $this->assertTrue(class_exists(CustomTaskProofSchema::class));

        // پورتِ رفتاریِ یکسان با کد تکراری قبلی (CustomTaskController:395-403 قدیم)
        $this->assertSame('url', CustomTaskProofSchema::normalizeType('link'));
        $this->assertSame('screenshot', CustomTaskProofSchema::normalizeType('image'));
        $this->assertSame('video', CustomTaskProofSchema::normalizeType('  VIDEO '));
        $this->assertSame('text', CustomTaskProofSchema::normalizeType('bogus'));
        $this->assertSame('code', CustomTaskProofSchema::normalizeType('code'));
    }

    /** @test */
    public function shared_validate_schema_ports_old_behavior_identically(): void
    {
        $this->assertNull(CustomTaskProofSchema::validateSchema('url', ['proof_url' => 'https://example.com/p.png']));
        $this->assertNull(CustomTaskProofSchema::validateSchema('text', ['proof_text' => 'متن بلند معتبر']));
        $this->assertNull(CustomTaskProofSchema::validateSchema('video', ['proof_url' => 'https://example.com/v.mp4']));
        $this->assertNull(CustomTaskProofSchema::validateSchema('screenshot', ['proof_file' => 'task-proofs/abc.png']));

        $this->assertSame('برای این تسک، توضیح متنی حداقل ۱۰ کاراکتر الزامی است.', CustomTaskProofSchema::validateSchema('text', ['proof_text' => 'کوتاه']));
        $this->assertSame('برای این تسک، اسکرین‌شات الزامی است.', CustomTaskProofSchema::validateSchema('screenshot', []));
        $this->assertSame('مدرک انجام تسک الزامی است.', CustomTaskProofSchema::validateSchema('other', []));
    }

    /** @test */
    public function both_call_sites_use_the_shared_class_and_duplicates_are_gone(): void
    {
        $ctrl = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Controllers/User/CustomTaskController.php');
        $job = (string)file_get_contents(dirname(__DIR__, 4) . '/app/Jobs/CustomTask/SubmitProofJob.php');

        $this->assertStringContainsString('CustomTaskProofSchema::normalizeType', $ctrl);
        $this->assertStringContainsString('CustomTaskProofSchema::validateSchema', $ctrl);
        $this->assertStringNotContainsString('private function normalizeProofType', $ctrl);
        $this->assertStringNotContainsString('private function validateProofSchema', $ctrl);

        $this->assertStringContainsString('CustomTaskProofSchema::normalizeType', $job);
        $this->assertStringContainsString('CustomTaskProofSchema::validateSchema', $job);
        $this->assertStringNotContainsString('private function normalizeProofType', $job);
        $this->assertStringNotContainsString('function validateProofSchema', $job);
    }

    // ── ۵) T22-18: جاب دیگر هشِ بدونِ کانال فایل را قبول نمی‌کند ────

    /** @test */
    public function validator_no_longer_requires_idempotency_key_or_client_proof_file(): void
    {
        $rules = (new SubmitCustomTaskProofRequest([]))->rules();
        $this->assertArrayNotHasKey('idempotency_key', $rules);
        $this->assertArrayNotHasKey('proof_file', $rules);

        $request = new SubmitCustomTaskProofRequest([
            'task_execution_id' => 55,
            'proof_text' => 'متن معتبر مدرک بدون کلید idempotency',
        ]);
        $this->assertTrue($request->validate(), 'بدون idempotency_key باید اعتبارسنجی پاس شود');
    }

    /** @test */
    public function job_drops_forged_file_hash_without_file_channel_before_cas_write(): void
    {
        $forgedHash = str_repeat('c', 64);

        $db = m::mock(\Core\Database::class);
        $casStmt = m::mock(\PDOStatement::class);
        $casArgs = null;
        $casStmt->shouldReceive('execute')->once()
            ->andReturnUsing(static function (array $args) use (&$casArgs): bool {
                $casArgs = $args;
                return true;
            });
        $casStmt->shouldReceive('rowCount')->once()->andReturn(1);
        $db->shouldReceive('prepare')->once()->andReturn($casStmt);
        $db->shouldReceive('fetch')->zeroOrMoreTimes()->andReturn(null);

        $submissionModel = m::mock(CustomTaskSubmissionModel::class);
        $submissionModel->shouldReceive('getDb')->zeroOrMoreTimes()->andReturn($db);
        $submissionModel->shouldReceive('submission_findById')->once()->with(55)
            ->andReturn($this->inProgressSubmission(['proof_type' => 'text', 'deadline_at' => null]));

        $rateLimiter = m::mock(\Core\RateLimiter::class);
        $rateLimiter->shouldReceive('attempt')->once()->andReturn(true);

        $taskModel = m::mock(Ads::class);
        $taskModel->shouldReceive('find')->zeroOrMoreTimes()->andReturn((object)['id' => 11, 'user_id' => 9, 'title' => 't']);

        $settings = m::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('get')->zeroOrMoreTimes()->andReturn(48);

        $logger = m::mock(Logger::class);
        $logger->shouldReceive('info')->zeroOrMoreTimes();
        $logger->shouldReceive('warning')->zeroOrMoreTimes();
        $logger->shouldReceive('error')->zeroOrMoreTimes();

        $job = new SubmitProofJob($rateLimiter, $submissionModel, $taskModel, $settings, $logger, null, null);

        // کلاینت هشِ جعلیِ 64hex را بدون فایل تزریق می‌کند — باید قبل از CAS ریخته شود
        $result = $job->handle([
            'submission_id' => 55,
            'worker_id' => 77,
            'proof_data' => [
                'proof_text' => 'متن معتبر و بلند مدرک برای تست جاب',
                'proof_file_hash' => $forgedHash,
            ],
        ]);

        $this->assertTrue($result['success'] ?? false, 'پیام: ' . ($result['message'] ?? ''));
        $this->assertNotNull($casArgs, 'CAS UPDATE باید اجرا شود');
        // آرگومان‌ها: [url, text, code, file, hash, url_hash, data, submitted_at, id]
        $this->assertNull($casArgs[4], 'هش جعل‌شدهٔ بدون کانال فایل نباید نوشته شود');
        $this->assertNull($casArgs[3], 'مسیر فایل هم نباید نوشته شود');
        $this->assertSame('متن معتبر و بلند مدرک برای تست جاب', $casArgs[1]);
    }
}
