<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers;

use App\Contracts\LoggerInterface;
use App\Controllers\BaseController;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Exceptions\HttpResponseException;
use Mockery;
use PHPUnit\Framework\TestCase;

/**
 * S14 — قفل‌کنندهٔ گیت‌های امنیتی لایهٔ Controller (بخش Admin).
 *
 *  ① BaseController::back() — ریدایرکت «بازگشت» فقط با referer هم‌اورجین
 *     (مقایسهٔ origin دقیق با hash_equals؛ مقایسهٔ پیشوندی
 *     «https://app.test.attacker» را فریب نمی‌دهد) و در غیر این صورت fallback امن.
 *  ② BaseController::requireAdmin() — کاربر بدون نقش ادمین (از DB، نه سشن)
 *     رد می‌شود و به dashboard برگردانده می‌شود.
 *  ③ DebugController::router() — خروجی دیباگ شامل ورودی خام کاربر همیشه
 *     htmlspecialchars می‌شود (ضد XSS در مسیر ادمین).
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class S14ControllerGatePinningTest extends TestCase
{
    /** اورجین global کانفیگ تست (bootstrap/testing.php) — Response::redirect به همین اعتبارسنجی می‌کند */
    private const APP_ORIGIN = 'http://127.0.0.1:8090';

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    private function makeController(array $serverOverrides = [], ?bool $isAdminById = null): BaseController
    {
        $session = Mockery::mock(Session::class);
        $session->shouldReceive('setFlash')->byDefault();
        $session->shouldReceive('get')->with('user_id')->andReturn(7)->byDefault();

        $request = Mockery::mock(Request::class);
        $request->shouldReceive('header')->with('referer', '')->andReturn($serverOverrides['referer'] ?? '')->byDefault();
        $request->shouldReceive('ip')->andReturn('127.0.0.1')->byDefault();
        $request->shouldReceive('str')->andReturnUsing(static fn(string $key, mixed $default = '') => $default)->byDefault();

        $response = new Response();
        $logger = Mockery::mock(LoggerInterface::class);
        $logger->shouldReceive('warning')->byDefault();

        $userModel = Mockery::mock(\App\Models\User::class);
        $userModel->shouldReceive('findById')->andReturnUsing(static function (int $id) use ($isAdminById) {
            if ($isAdminById === null) {
                return null;
            }
            return (object)['id' => $id, 'role' => $isAdminById ? 'admin' : 'user'];
        })->byDefault();

        $roleModel = Mockery::mock(\App\Models\Role::class);
        $auditTrail = Mockery::mock(\App\Services\AuditTrail::class);
        $auditTrail->shouldReceive('record')->byDefault()->andReturn(true);
        $policyService = new \App\Services\Shared\PolicyService($logger, $userModel, $roleModel, $auditTrail);

        $csrf = Mockery::mock(\Core\CSRF::class);
        $validatorFactory = Mockery::mock(\App\Contracts\ValidatorFactoryInterface::class);
        $urlGenerator = new \Core\UrlGenerator(self::APP_ORIGIN, null, '', 'testing'); // production: loopback ممنوع

        return new class($session, $request, $response, $policyService, $logger, $csrf, $validatorFactory, $urlGenerator) extends BaseController {
            /** در معرض گذاشتن helperهای protected برای تست */
            public function doBack(): void
            {
                $this->back();
            }

            public function doRequireAdmin(): void
            {
                $this->requireAdmin();
            }
        };
    }

    private function captureRedirect(callable $fn): HttpResponseException
    {
        try {
            $fn();
            $this->fail('انتظار می‌رفت HttpResponseException (redirect/json) پرتاب شود');
        } catch (HttpResponseException $e) {
            return $e;
        }
    }

    public function test_back_redirects_to_same_origin_referer(): void
    {
        $controller = $this->makeController(['referer' => self::APP_ORIGIN . '/admin/users']);
        $e = $this->captureRedirect(fn () => $controller->doBack());
        $this->assertSame(self::APP_ORIGIN . '/admin/users', $e->getResponse()->getHeader('Location'));
    }

    public function test_back_rejects_cross_origin_referer_with_fallback(): void
    {
        // prefix-spoof: «app.test.attacker» با شروع‌بودنِ مشابه فریب نمی‌دهد
        $spoofed = $this->makeController(['referer' => self::APP_ORIGIN . '.attacker/admin/users']);
        $e = $this->captureRedirect(fn () => $spoofed->doBack());
        $this->assertSame(self::APP_ORIGIN . '/', $e->getResponse()->getHeader('Location'));

        // اورجین متفاوتِ کامل
        $other = $this->makeController(['referer' => 'https://evil.example/admin']);
        $e2 = $this->captureRedirect(fn () => $other->doBack());
        $this->assertSame(self::APP_ORIGIN . '/', $e2->getResponse()->getHeader('Location'));
    }

    public function test_back_falls_back_safely_without_referer(): void
    {
        $controller = $this->makeController(); // referer خالی
        $e = $this->captureRedirect(fn () => $controller->doBack());
        $this->assertSame(self::APP_ORIGIN . '/', $e->getResponse()->getHeader('Location'));
    }

    public function test_require_admin_rejects_non_admin_and_accepts_admin(): void
    {
        // کاربر بدون نقش ادمین (findById → user) → رد و ریدایرکت به dashboard
        $nonAdmin = $this->makeController([], isAdminById: false);
        $e = $this->captureRedirect(fn () => $nonAdmin->doRequireAdmin());
        $this->assertSame(self::APP_ORIGIN . '/dashboard', $e->getResponse()->getHeader('Location'));

        // نقش ادمین → بدون redirect عبور می‌کند
        $admin = $this->makeController([], isAdminById: true);
        $admin->doRequireAdmin(); // هیچ استثنایی نباید پرتاب شود
        $this->addToAssertionCount(1);
    }

    public function test_debug_router_output_is_html_escaped(): void
    {
        $request = Mockery::mock(Request::class);
        $request->shouldReceive('ip')->andReturn('127.0.0.1');
        // ورودی مخرب: تلاش برای XSS و path-traversal هم‌زمان
        $request->shouldReceive('str')->with('path', '')->andReturn('/file/view/../../<script>alert(1)</script>');

        // DebugController فقط logger می‌گیرد؛ Request از container می‌آید — bind می‌کنیم
        $container = app(\Core\Container::class);
        $originalRequest = $container->has(Request::class) ? $container->make(Request::class) : null;
        $container->instance(Request::class, $request);

        try {
            $controller = new \App\Controllers\DebugController(Mockery::mock(LoggerInterface::class));
            $controller->router();
            $this->fail('انتظار می‌رفت HttpResponseException پرتاب شود');
        } catch (HttpResponseException $e) {
            $content = $e->getResponse()->getContent();
            $this->assertStringNotContainsString('<script>', $content, 'ورودی خام نباید در خروجی دیباگ بماند');
            $this->assertStringContainsString('&lt;script&gt;', $content);
        } finally {
            if ($originalRequest !== null) {
                $container->instance(Request::class, $originalRequest);
            }
        }
    }
}
