<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers;

use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بچ S14 — قفل رفتاری فیکس‌های لایهٔ کنترلر/نگاشت RBAC/پیوست تیکت:
 *
 *  - FIX-S14-5: متدهای جهش‌یافتهٔ SentryAdminController (retryOutboxEvent/
 *    deleteOutboxEvent/deleteEventFailure) و ExecutorTaskController::reviewReport
 *    تا قبل از این بچ بدون نگاشت بودند و به defaultِ فقط-نمایش سقوط می‌کردند.
 *  - FIX-S14-1: TicketMessage::findByAttachmentFilename با LIKE '%F%' + LIMIT 1
 *    تازه‌ترین پیامِ حاویِ زیررشته را برمی‌گرداند؛ در ترکیب با ساخت مسیر سرو از
 *    ورودی درخواست، زنجیرهٔ IDOR مهندسی‌شده ممکن بود. اکنون فقط تطابق «دقیقِ»
 *    basename(path) در JSON پیوست معتبر است.
 *
 * تست‌های DB روی MariaDB واقعی اجرا می‌شوند (قرارداد S12/S13).
 */
final class S14ControllersHardeningTest extends TestCase
{
    /** @var list<int> */
    private array $insertedMessageIds = [];

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        foreach ($this->insertedMessageIds as $id) {
            try {
                $db->table('ticket_messages')->where('id', '=', $id)->delete();
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        $this->insertedMessageIds = [];
        parent::tearDown();
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S14-5 — نگاشت RBAC
    // ─────────────────────────────────────────────────────────────

    private function rbacMap(): array
    {
        $map = include dirname(__DIR__, 3) . '/config/admin_permissions.php';
        $this->assertIsArray($map);
        return $map;
    }

    public function test_mutating_sentry_dlq_methods_require_sentry_manage(): void
    {
        $sentry = $this->rbacMap()['SentryAdminController'] ?? null;
        $this->assertIsArray($sentry, 'نگاشت SentryAdminController غایب است');
        $this->assertSame('sentry.view', $sentry['default'] ?? null);

        foreach (['retryOutboxEvent', 'deleteOutboxEvent', 'deleteEventFailure'] as $method) {
            $this->assertSame(
                'sentry.manage',
                $sentry['methods'][$method] ?? null,
                "متد جهش‌یافتهٔ {$method} باید sentry.manage بخواهد نه سقوط به default"
            );
        }
    }

    public function test_review_report_requires_custom_tasks_manage(): void
    {
        $executor = $this->rbacMap()['ExecutorTaskController'] ?? null;
        $this->assertIsArray($executor, 'نگاشت ExecutorTaskController غایب است');
        $this->assertSame(
            'custom_tasks.manage',
            $executor['methods']['reviewReport'] ?? null,
            'reviewReport (تغییر وضعیت گزارش + رد تسک در رأی fraud) باید custom_tasks.manage بخواهد'
        );
        // خواهرانِ جهش‌یافته همچنان manage:
        foreach (['forceApproveSubmission', 'forceRejectSubmission', 'resolveDispute', 'replyDispute'] as $m) {
            $this->assertSame('custom_tasks.manage', $executor['methods'][$m] ?? null);
        }
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S14-1 — تطابق دقیق پیوست تیکت
    // ─────────────────────────────────────────────────────────────

    private function insertTicketMessage(int $userId, string $attachmentsJson, string $createdAt): int
    {
        $db = Database::getInstance();
        $db->table('ticket_messages')->insert([
            'ticket_id' => 99999901,
            'user_id' => $userId,
            'message' => 'S14 attachment fixture',
            'is_admin' => 0,
            'attachments' => $attachmentsJson,
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ]);
        $id = (int)$db->getPdo()->lastInsertId();
        $this->insertedMessageIds[] = $id;
        return $id;
    }

    public function test_attachment_lookup_matches_exact_path_basename_not_substring(): void
    {
        $db = Database::getInstance();
        $userId = (int)($db->fetchColumn('SELECT id FROM users ORDER BY id ASC LIMIT 1') ?? 0);
        if ($userId <= 0) {
            $this->markTestSkipped('هیچ کاربری برای fixture پیدا نشد');
        }

        $victimFile = 'aaa111bbb222ccc333ddd444.png'; // basename مسیر ذخیره‌شدهٔ قربانی
        $attackerFile = 'eee555fff666ggg777hhh888.png';

        // پیام قربانی — قدیمی‌تر؛ path دقیقاً حاوی F:
        $victimId = $this->insertTicketMessage(
            $userId,
            json_encode([['name' => 'screenshot.png', 'path' => 'ticket_attachments/' . $victimFile]], JSON_UNESCAPED_UNICODE),
            date('Y-m-d H:i:s', time() - 600)
        );
        // پیام مهاجم — تازه‌تر؛ فقط «name» حاوی F به‌عنوان زیررشته است:
        $this->insertTicketMessage(
            $userId,
            json_encode([['name' => 'x' . $victimFile, 'path' => 'ticket_attachments/' . $attackerFile]], JSON_UNESCAPED_UNICODE),
            date('Y-m-d H:i:s')
        );

        $model = new \App\Models\TicketMessage(Database::getInstance());

        $row = $model->findByAttachmentFilename($victimFile);
        $this->assertNotNull($row, 'پیوست با تطابق دقیق باید پیدا شود');
        $this->assertSame(
            $victimId,
            (int)$row->id,
            'باید پیامِ صاحبِ path دقیق برگردد نه پیامِ تازه‌ترِ حاویِ زیررشته (الگوی IDOR مهندسی‌شده)'
        );
    }

    public function test_attachment_lookup_fails_closed_for_substring_only_or_traversal(): void
    {
        $db = Database::getInstance();
        $userId = (int)($db->fetchColumn('SELECT id FROM users ORDER BY id ASC LIMIT 1') ?? 0);
        if ($userId <= 0) {
            $this->markTestSkipped('هیچ کاربری برای fixture پیدا نشد');
        }

        $target = 'zzz999yyy888xxx777www666.png';
        // پیامی که فقط «name» آن حاوی زیررشتهٔ هدف است — path متفاوت:
        $this->insertTicketMessage(
            $userId,
            json_encode([['name' => 'a' . $target, 'path' => 'ticket_attachments/qqq111ppp222lll333kkk444.png']], JSON_UNESCAPED_UNICODE),
            date('Y-m-d H:i:s')
        );

        $model = new \App\Models\TicketMessage(Database::getInstance());

        $this->assertNull(
            $model->findByAttachmentFilename($target),
            'درخواستِ نامی که فقط به‌صورت زیررشته در JSON هست باید ۴۰۴ (null) بدهد — نه ردیفِ صاحبِ زیررشته'
        );
        $this->assertNull($model->findByAttachmentFilename('..'), 'traversal باید null بدهد');
        $this->assertNull($model->findByAttachmentFilename(''), 'نام خالی باید null بدهد');
    }
}
