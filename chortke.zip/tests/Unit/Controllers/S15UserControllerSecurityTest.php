<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers;

use App\Services\LogService;
use Core\Logger;
use PHPUnit\Framework\TestCase;

/**
 * S15 — قفل‌کنندهٔ امنیتی لایهٔ Controller (بخش ۲ — کاربر/محور-کاربر).
 *
 *  ① FIX-S15-1 (CWE-532): Logger facade هیچ مقداری از کلیدهای حساس
 *     (password/token/otp/card_number/...) را — در هر عمق از context —
 *     به استریم لاگ نمی‌فرستد. انگیزهٔ واقعی: AuthController::register
 *     قبلاً «کل آرایهٔ $data» با رمز عبور plaintext را در خطای اعتبارسنجی
 *     ثبت می‌کرد؛ این تست آخرین خط دفاعی سطح facade را قفل می‌کند تا هر
 *     فراخوانی فعلی/آینده هم پوشش داشته باشد.
 *  ② FIX-S15-2: فاویکون SVG جایگزین — حرف اولِ تنظیمِ site_name پیش از
 *     ورود به markup escape می‌شود (same-origin SVG = سند فعال).
 *  ③ FIX-S15-3: مسیر دانلود پیوست تیکت دیگر تنها مسیرِ بدون
 *     AuthMiddleware در routes/user.php نیست — قرارداد سربرگ فایل
 *     («همه نیاز به AuthMiddleware دارند») enforce شده است؛ گیت
 *     مالکیت درون کنترلر هم طبق معمول باقی است.
 *
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
final class S15UserControllerSecurityTest extends TestCase
{
    public function tearDown(): void
    {
        parent::tearDown();
    }

    /** یک Logger واقعی با sink واقعی — همان زنجیرهٔ پروداکشن (enrich → LogService::log) */
    private function makeLogger(): Logger
    {
        $logService = new LogService();
        $logService->setCorrelationId('s15-redaction-test'); // میان‌بر: از app()->request عبور نمی‌کند
        return new Logger($logService);
    }

    /** سوزن تطبیق برای استریم لاگ — json_encode همان رشته با همان فلگ‌های LogService */
    private function jsonNeedle(string $value): string
    {
        return (string)json_encode($value, JSON_INVALID_UTF8_SUBSTITUTE);
    }

    /** اجرای یک لاگ و گرفتن دقیق همان چیزی که به استریم می‌رفت */
    private function captureLogStream(callable $fn): string
    {
        ob_start();
        try {
            $fn();
        } finally {
            $stream = (string)ob_get_clean();
        }
        return $stream;
    }

    public function test_logger_masks_credential_values_in_log_stream(): void
    {
        $logger = $this->makeLogger();
        $secret = 'SuperSecret-Password-#159!';

        $stream = $this->captureLogStream(function () use ($logger, $secret): void {
            // بازسازی دقیق الگوی قدیمی AuthController::register (FIX-S15-1)
            $logger->error('auth.registration.validation_failed', [
                'errors'               => ['email' => 'قالب ایمیل نامعتبر است'],
                'data'                 => [
                    'full_name'            => 'کاربر آزمون',
                    'email'                => 'user@example.com',
                    'password'             => $secret,
                    'password_confirmation' => $secret,
                ],
            ]);
        });

        $this->assertStringNotContainsString($secret, $stream, 'رمز عبور نباید به استریم لاگ برسد');
        $this->assertStringContainsString('[redacted]', $stream);
        // فیلدهای غیرحساس برای همبستگی عملیاتی باید سالم بمانند (سوزن json-escape)
        $this->assertStringContainsString('user@example.com', $stream);
        $this->assertStringContainsString($this->jsonNeedle('کاربر آزمون'), $stream);
        $this->assertStringContainsString($this->jsonNeedle('قالب ایمیل نامعتبر است'), $stream);
    }

    public function test_logger_masks_nested_and_various_sensitive_keys(): void
    {
        $logger = $this->makeLogger();

        $stream = $this->captureLogStream(function () use ($logger): void {
            $logger->warning('s15.nested_probe', [
                'request' => [
                    'body' => [
                        'refresh_token' => 'rt-PLAIN-ABC',
                        'otp'           => '123456',
                        'card_number'   => '6219861012345678',
                    ],
                    'headers' => ['Authorization' => 'Bearer xyz-token'],
                ],
                'oauth_state' => 'این-کلید-حساس-نیست', // تطابق دقیق، نه زیررشته
                'token_name'  => 'موبایل من',           // مقادیر بی‌ضرر هم‌خانواده دست‌نخورده
            ]);
        });

        $this->assertStringNotContainsString('rt-PLAIN-ABC', $stream);
        $this->assertStringNotContainsString('123456', $stream);
        $this->assertStringNotContainsString('6219861012345678', $stream);
        $this->assertStringNotContainsString('Bearer xyz-token', $stream);
        $this->assertStringContainsString('[redacted]', $stream);
        $this->assertStringContainsString($this->jsonNeedle('این-کلید-حساس-نیست'), $stream, 'کلید oauth_state نباید ماسک شود');
        $this->assertStringContainsString($this->jsonNeedle('موبایل من'), $stream, 'کلید token_name نباید ماسک شود');
    }

    public function test_logger_preserves_structure_and_masks_non_scalar_sensitive_value(): void
    {
        $logger = $this->makeLogger();

        $stream = $this->captureLogStream(function () use ($logger): void {
            $logger->info('s15.structure_probe', [
                'password' => ['plain' => 'nope'], // مقدار غیراسکالر → برچسب نوع
                'ok_key'   => 'salam',
            ]);
        });

        $this->assertStringContainsString('[redacted:array]', $stream, 'مقدار غیراسکالر حساس با برچسب نوع ماسک می‌شود');
        $this->assertStringNotContainsString('nope', $stream);
        $this->assertStringContainsString('"password"', $stream, 'نام کلید حفظ می‌شود تا مصرف‌کنندهٔ تشخیصی نشکند');
        $this->assertStringContainsString('"ok_key"', $stream);
    }

    public function test_favicon_fallback_svg_escapes_markup_in_site_name(): void
    {
        // حرف اول site_name مخرب: تلاش برای شکستن SVG به سند فعال same-origin
        $svg = \App\Controllers\FaviconController::renderFallbackSvg(
            '<img src=x onerror=alert(1)> payload',
            '#1565c0'
        );

        $this->assertStringNotContainsString('<img', $svg, 'markup خام نباید داخل SVG بنشیند');
        $this->assertStringNotContainsString('onerror', $svg);
        // فقط «حرف اول» رندر می‌شود؛ '<' → &lt; و بقیهٔ payload هرگز وارد نمی‌شود
        $this->assertStringContainsString('&lt;</text>', $svg);
        $this->assertStringNotContainsString('payload', $svg);
        $this->assertStringContainsString('fill="#1565c0"', $svg, 'رنگ معتبر دست‌نخورده می‌ماند');
        $this->assertStringContainsString('<svg xmlns="http://www.w3.org/2000/svg"', $svg);
    }

    public function test_favicon_fallback_svg_keeps_unicode_first_letter(): void
    {
        // رفتار عادی: حرف اول فارسی — escape نباید آن را خراب کند
        $svg = \App\Controllers\FaviconController::renderFallbackSvg('چرتکه', '#1565c0');
        $this->assertStringContainsString('>چ</text>', $svg);
    }

    public function test_ticket_attachment_route_is_registered_with_auth_middleware(): void
    {
        // FIX-S15-3: ثبت واقعی routes/user.php روی روتر و بازرسی میدل‌ور مسیر
        $router = app(\Core\Router::class);
        require base_path('routes/user.php');

        $authClass = \App\Middleware\AuthMiddleware::class;
        $attachmentRoute = null;
        $profileRoute = null;

        foreach ($router->getRoutes()['GET'] as $entry) {
            $uri = (string)$entry['uri'];
            if ($uri === '/tickets/attachments/{filename}') {
                $attachmentRoute = $entry['route'];
            }
            if ($uri === '/profile') {
                $profileRoute = $entry['route'];
            }
        }

        $this->assertNotNull($profileRoute, 'مسیر کنترلی /profile باید ثبت شده باشد (اعتبارسنجی روش بازرسی)');
        $this->assertContains($authClass, $profileRoute->getMiddleware(), 'بازرسی باید بتواند میدل‌ور $auth را ببیند');

        $this->assertNotNull($attachmentRoute, 'مسیر پیوست تیکت باید ثبت شده باشد');
        $this->assertContains(
            $authClass,
            $attachmentRoute->getMiddleware(),
            'FIX-S15-3: مسیر پیوست تیکت باید AuthMiddleware داشته باشد (قرارداد سربرگ routes/user.php)'
        );
    }
}
