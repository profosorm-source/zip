<?php

declare(strict_types=1);

namespace Tests\Unit\Controllers;

use App\Services\CryptoDeposit\CryptoDepositService;
use App\Services\ScoreService;
use App\Services\User\AccountDeletionService;
use Core\Container;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بچ S16 — قفل رفتاری فیکس‌های آخرین بچ Controllers (بخش ۲ ب — Admin باقی‌مانده):
 *
 *  - FIX-S16-1: زنجیرهٔ $admin در routes/system.php هم‌تراز admin.php شد؛ ۴ کنترلر سیستمی
 *    طبق تصمیم ثبت‌شدهٔ S12 از deny-by-default گارد (نگاشت‌نشده ⇒ 403 غیرسوپر) استفاده می‌کنند.
 *  - FIX-S16-2: ساگای حذف حساب فقط برای درخواستِ status='requested' اجرا می‌شود (fail-closed).
 *  - FIX-S16-3: PredictionGame دارای $fillable است و کنترلر هرگز status را از body نمی‌پذیرد.
 *  - FIX-S16-6: تأیید واریز کریپتوی حسابِ خودِ ادمین ممنوع (هم‌تراز C03-باگ۷).
 *  - FIX-S16-7/8/9: یابندهٔ اصلاح امتیاز + حسابرسی جهش‌های مالی.
 *
 * تست‌های DB روی MariaDB واقعی اجرا می‌شوند (قرارداد S12/S13/S14/S15).
 */
final class S16ControllersHardeningTest extends TestCase
{
    /** @var list<string> */
    private array $cleanupTables = [];
    /** @var list<int> */
    private array $cleanupIds = [];

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        foreach ($this->cleanupIds as $i => $id) {
            $table = $this->cleanupTables[$i] ?? null;
            if ($table === null) {
                continue;
            }
            try {
                $db->table($table)->where('id', '=', $id)->delete();
            } catch (\Throwable) {
                // teardown best-effort
            }
        }
        $this->cleanupIds = [];
        $this->cleanupTables = [];
        parent::tearDown();
    }

    private function trackCleanup(string $table, int $id): void
    {
        $this->cleanupTables[] = $table;
        $this->cleanupIds[] = $id;
    }

    private function db(): Database
    {
        return Database::getInstance();
    }

    private function firstActiveUserId(): int
    {
        return (int)($this->db()->fetchColumn(
            "SELECT id FROM users WHERE deleted_at IS NULL ORDER BY id ASC LIMIT 1"
        ) ?? 0);
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S16-1 — گارد RBAC روی مسیرهای سیستمی
    // ─────────────────────────────────────────────────────────────

    public function test_system_route_group_wires_admin_permission_guard(): void
    {
        $source = file_get_contents(dirname(__DIR__, 3) . '/routes/system.php');
        $this->assertNotFalse($source);

        // هم گروه $admin و هم $adminRead باید گارد را داشته باشند (۲ رخداد)
        $this->assertSame(2, substr_count($source, 'AdminPermissionGuard::class'),
            'routes/system.php باید AdminPermissionGuard را در $admin و $adminRead سیم‌کشی کند (FIX-S16-1)');
        $this->assertStringContainsString("RateLimitMiddleware::class . ':30,1'", $source,
            'زنجیرهٔ $admin سیستم باید هم‌تراز admin.php شامل RateLimit 30,1 باشد (FIX-S16-1)');
    }

    public function test_system_controllers_stay_deny_by_default_for_non_super(): void
    {
        // تصمیم ثبت‌شدهٔ S12: ۴ کنترلر سیستمی عمداً خارج از نقشه‌اند ⇒ گارد null می‌گیرد ⇒ deny.
        // اگر روزی نگاشت شدند، این تست باید آگاهانه به‌روز شود (سطح حمله دوباره ارزیابی شود).
        foreach ([
            [\App\Controllers\Admin\CronController::class, 'run'],
            [\App\Controllers\Admin\ApiTokenAdminController::class, 'revoke'],
            [\App\Controllers\Admin\ApiTokenAdminController::class, 'revokeExpired'],
            [\App\Controllers\Admin\CacheAdminController::class, 'clear'],
            [\App\Controllers\Admin\CacheAdminController::class, 'forget'],
            [\App\Controllers\Admin\CacheAdminController::class, 'resetCircuitBreaker'],
            [\App\Controllers\Admin\EmailQueueController::class, 'retryFailed'],
            [\App\Controllers\Admin\EmailQueueController::class, 'process'],
        ] as [$class, $method]) {
            $this->assertNull(
                \App\Middleware\AdminPermissionGuard::permissionForAction($class, $method),
                "{$class}::{$method} باید نگاشت‌نشده بماند (deny-by-default برای غیرسوپر — تصمیم S12)"
            );
        }
    }

    public function test_rbac_map_sanity_for_mapped_admin_controllers(): void
    {
        $this->assertSame(
            'features.manage',
            \App\Middleware\AdminPermissionGuard::permissionForAction(
                \App\Controllers\Admin\FeatureFlagController::class, 'toggle'
            ),
            'نگاشت FeatureFlagController::toggle باید دست‌نخورده بماند (رجرفس نقشه)'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S16-2 — گارد وضعیت ساگای حذف حساب
    // ─────────────────────────────────────────────────────────────

    public function test_account_deletion_purge_blocked_for_cancelled_request(): void
    {
        // FIX-S16-2 در مسیر رد، لاگ هشدار می‌دهد — همین‌جا آن را هم اثبات می‌کنیم
        $this->expectOutputRegex('/account_deletion\.blocked_non_requested/');

        $userId = $this->firstActiveUserId();
        if ($userId <= 0) {
            $this->markTestSkipped('کاربر seed موجود نیست');
        }

        $db = $this->db();
        // فیکسچر: درخواست حذفِ «لغوشده» — تازه‌ترین رکوردِ کاربر (جدول created_at/updated_at ندارد)
        $db->table('account_deletion_logs')->insert([
            'user_id' => $userId,
            'reason' => 'S16 fixture — cancelled',
            'status' => 'cancelled',
            'requested_at' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', time() + 86400),
        ]);
        $logId = (int)$db->fetchColumn(
            'SELECT id FROM account_deletion_logs WHERE user_id = ? AND status = ? ORDER BY id DESC LIMIT 1',
            [$userId, 'cancelled']
        );
        $this->trackCleanup('account_deletion_logs', $logId);

        /** @var AccountDeletionService $service */
        $service = Container::getInstance()->make(AccountDeletionService::class);
        $deleted = $service->deleteUserAccount($userId, 'S16 guard test', 0);

        $this->assertFalse($deleted,
            'ساگای purge نباید برای درخواستِ غیر-requested اجرا شود (FIX-S16-2)');

        $status = (string)($db->fetchColumn('SELECT status FROM users WHERE id = ?', [$userId]) ?? '');
        $this->assertNotSame('deleted', $status, 'حساب کاربر نباید حذف شده باشد');
        $this->assertSame('cancelled', (string)($db->fetchColumn(
            'SELECT status FROM account_deletion_logs WHERE id = ?', [$logId]
        ) ?? ''), 'رکورد لغوشده باید دست‌نخورده بماند');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S16-3 — $fillable مدل پیش‌بینی + مسیر کنترلر
    // ─────────────────────────────────────────────────────────────

    public function test_prediction_game_model_drops_privileged_columns_on_update(): void
    {
        $db = $this->db();
        $db->table('prediction_games')->insert([
            'title' => 'S16 fillable fixture',
            'team_home' => 'A',
            'team_away' => 'B',
            'sport_type' => 'football',
            'match_date' => date('Y-m-d H:i:s', time() + 172800),
            'bet_deadline' => date('Y-m-d H:i:s', time() + 86400),
            'status' => 'open',
            'description' => 'fixture',
            'created_by' => 1,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        $gameId = (int)$db->fetchColumn(
            "SELECT id FROM prediction_games WHERE title = ? ORDER BY id DESC LIMIT 1",
            ['S16 fillable fixture']
        );
        if ($gameId <= 0) {
            $this->markTestSkipped('ثبت فیکسچر prediction_games ناموفق بود');
        }
        $this->trackCleanup('prediction_games', $gameId);

        $model = new \App\Models\PredictionGame($db);
        // حملهٔ شبیه‌سازی‌شدهٔ body خامِ کنترلر (قبل از FIX-S16-3 عبور می‌کرد)
        $ok = $model->update($gameId, [
            'title' => 'S16 fillable fixture — updated',
            'status' => 'finished',
            'bonus_pool_usdt' => '999',
            'created_by' => 424242,
            'settled_by' => 424242,
        ]);
        $this->assertTrue($ok);

        $this->assertSame('S16 fillable fixture — updated', (string)($db->fetchColumn(
            'SELECT title FROM prediction_games WHERE id = ?', [$gameId]
        ) ?? ''), 'فیلد درون fillable باید به‌روز شود');
        $this->assertSame('open', (string)($db->fetchColumn(
            'SELECT status FROM prediction_games WHERE id = ?', [$gameId]
        ) ?? ''), 'status ستون ممتاز است و نباید از مسیر عمومی مدل بازنویسی شود (FIX-S16-3)');
        $this->assertSame('0.00000000', (string)($db->fetchColumn(
            'SELECT bonus_pool_usdt FROM prediction_games WHERE id = ?', [$gameId]
        ) ?? ''), 'bonus_pool_usdt نباید از مسیر عمومی مدل بازنویسی شود (FIX-S16-3)');
        $this->assertSame(1, (int)($db->fetchColumn(
            'SELECT created_by FROM prediction_games WHERE id = ?', [$gameId]
        ) ?? 0), 'created_by نباید بازنویسی شود');
    }

    public function test_prediction_controller_never_accepts_status_from_body(): void
    {
        $source = file_get_contents(dirname(__DIR__, 3) . '/app/Controllers/Admin/PredictionController.php');
        $this->assertNotFalse($source);
        $this->assertStringNotContainsString("allowedFields = ['description', 'status']", $source,
            'شاخهٔ betCount>0 نباید status را عبور دهد (FIX-S16-3)');
        $this->assertStringContainsString("'description',\n            ];", $source,
            'شاخهٔ betCount==0 باید whitelist کانونی داشته باشد');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S16-6 — ممنوعیت خودتأییدی واریز کریپتو
    // ─────────────────────────────────────────────────────────────

    public function test_crypto_deposit_self_approval_is_blocked(): void
    {
        // FIX-S16-6 در مسیر رد، لاگ هشدار می‌دهد — همین‌جا آن را هم اثبات می‌کنیم
        $this->expectOutputRegex('/crypto_deposit\.self_approval_blocked/');

        $userId = $this->firstActiveUserId();
        if ($userId <= 0) {
            $this->markTestSkipped('کاربر seed موجود نیست');
        }

        $db = $this->db();
        $txHash = 'S16TEST-' . bin2hex(random_bytes(8));
        $db->table('crypto_deposits')->insert([
            'user_id' => $userId,
            'amount' => '5.00000000',
            'currency' => 'usdt',
            'tx_hash' => $txHash,
            'network' => 'tron',
            'status' => 'pending',
            'verification_status' => 'pending',
            'deposit_date' => date('Y-m-d'),
            'deposit_time' => date('H:i:s'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        $depositId = (int)$db->fetchColumn('SELECT id FROM crypto_deposits WHERE tx_hash = ?', [$txHash]);
        if ($depositId <= 0) {
            $this->markTestSkipped('ثبت فیکسچر crypto_deposits ناموفق بود');
        }
        $this->trackCleanup('crypto_deposits', $depositId);

        /** @var CryptoDepositService $service */
        $service = Container::getInstance()->make(CryptoDepositService::class);
        $result = $service->approve($userId, $depositId);

        $this->assertFalse((bool)($result['success'] ?? true),
            'ادمین نباید واریز حساب خودش را تأیید کند (FIX-S16-6)');
        $this->assertStringContainsString('شخصی', (string)($result['message'] ?? ''),
            'پیام رد باید ممنوعیت خودتأییدی را اعلام کند');

        $row = $db->fetch('SELECT verification_status, reviewed_by FROM crypto_deposits WHERE id = ?', [$depositId]);
        $this->assertNotNull($row);
        $row = (array)$row;
        $this->assertSame('pending', (string)$row['verification_status'],
            'وضعیت واریز باید دست‌نخورده بماند');
        $this->assertSame(0, (int)$row['reviewed_by'], 'reviewed_by نباید ثبت شده باشد');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S16-7 — یابندهٔ رکورد اصلاح امتیاز
    // ─────────────────────────────────────────────────────────────

    public function test_score_adjustment_finder_returns_owner_and_rejects_zero(): void
    {
        $service = Container::getInstance()->make(ScoreService::class);
        $this->assertNull($service->findAdjustmentById(0),
            'شناسهٔ صفر باید null برگرداند (fail-closed)');

        $userId = $this->firstActiveUserId();
        if ($userId <= 0) {
            $this->markTestSkipped('کاربر seed موجود نیست');
        }
        $db = $this->db();
        $db->table('user_score_adjustments')->insert([
            'user_id' => $userId,
            'score_adjustment' => 1.50,
            'operation' => 'add',
            'reason' => 'S16 finder fixture',
            'domain' => 'fraud',
            'status' => 'active',
            'created_by' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        $adjId = (int)$db->fetchColumn(
            "SELECT id FROM user_score_adjustments WHERE user_id = ? AND reason = ? ORDER BY id DESC LIMIT 1",
            [$userId, 'S16 finder fixture']
        );
        $this->trackCleanup('user_score_adjustments', $adjId);

        $adjustment = $service->findAdjustmentById($adjId);
        $this->assertNotNull($adjustment);
        $this->assertSame($userId, (int)$adjustment->user_id,
            'یابنده باید کاربرِ صاحب رکورد را برگرداند تا ریدایرکت درست شود (FIX-S16-7)');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S16-4/5/9 — تله‌های رگرسیون حسابرسی/گارد در لایهٔ کنترلر
    // ─────────────────────────────────────────────────────────────

    public function test_investment_controller_carries_state_and_audit_guards(): void
    {
        $source = file_get_contents(dirname(__DIR__, 3) . '/app/Controllers/Admin/InvestmentController.php');
        $this->assertNotFalse($source);
        $this->assertStringContainsString('Investment::STATUS_CLOSED', $source,
            'suspend باید رکورد closed را رد کند (FIX-S16-4)');
        $this->assertStringContainsString('investment.suspended', $source, 'FIX-S16-4: auditLog suspend');
        foreach (['investment.trade_closed', 'investment.weekly_profit_applied',
                  'investment.withdrawal_approved', 'investment.withdrawal_rejected'] as $event) {
            $this->assertStringContainsString($event, $source,
                "جهش مالی سرمایه‌گذاری باید {$event} را حسابرسی کند (FIX-S16-9)");
        }
    }

    public function test_user_controller_update_audits_sensitive_changes(): void
    {
        $source = file_get_contents(dirname(__DIR__, 3) . '/app/Controllers/Admin/UserController.php');
        $this->assertNotFalse($source);
        $this->assertStringContainsString("auditLog('user.updated'", $source,
            'تغییر role/status/password باید auditLog بگذارد (FIX-S16-5)');
    }

    public function test_create_trade_job_audit_label_is_accurate(): void
    {
        $source = file_get_contents(dirname(__DIR__, 3) . '/app/Jobs/Investment/CreateTradeJob.php');
        $this->assertNotFalse($source);
        $this->assertStringContainsString('admin.investment.trade_created', $source,
            'برچسب حسابرسی باید رویداد واقعی را نام ببرد (FIX-S16-9)');
        $this->assertStringNotContainsString('admin.settings.changed', $source,
            'برچسب گمراه‌کنندهٔ قبلی باید حذف شده باشد (FIX-S16-9)');
    }
}
