<?php

declare(strict_types=1);

namespace Tests\Unit\Console;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-S17-01 + FIX-S17-02 (بازبینی بخش ۱۷ — یافته‌های خارج از گزارش)
 *
 * پین منبع (source-pinning) برای دو اصلاح:
 *
 * ① FIX-S17-01 — پنجرهٔ زمانی کرون امتیاز شانس (Kernel::lottery_chance_scores):
 *    - رفتار قبلی: d.date = CURDATE() + handle(date('Y-m-d')) در ۰۳:۲۰ امروز.
 *      عدد روزانهٔ امروز در ۰۳:۲۰ هنوز تولید نشده (generateDailyNumbers =
 *      date('Y-m-d') در طول روز) ⇒ JOIN خالی ⇒ no-op ساختاری؛ روزها گم می‌شد
 *      (باعث می‌شد F-03/F-06 گزارش بخش ۱۷ عملاً بی‌موضوع بمانند) و در حالت
 *      استثناییِ تولید نیمه‌شب، «امروزِ ۰۳:۲۰» با رأی‌های ناقص پردازش می‌شد
 *      ⇒ جریمهٔ no_vote خیالی.
 *    - رفتار جدید: پنجرهٔ اصلی = دیروز + بک‌فیلِ claimنشده‌ها در
 *      lottery_score_backfill_days روز اخیر؛ امروز هرگز؛ ترتیب ASC؛
 *      as-of participation (عضو دیرهنگام جریمهٔ خیالی نمی‌گیرد).
 *
 * ② FIX-S17-02 — gate لاتری در مسیر API (همان‌الگوی FIX-M12-24 برای کریپتو):
 *    /wallet/lottery/rounds و /wallet/lottery/join باید RequireFeature:lottery
 *    داشته باشند؛ با feature خاموش، کانال API هم بسته می‌شود (503 JSON).
 *
 * ایدیم خانه: SystemCameraCleanupScheduleTest (پین سیم‌کشی Kernel).
 */
final class LotteryChanceScoresCronWindowTest extends TestCase
{
    private string $kernel;
    private string $job;
    private string $jobRaw;
    private string $model;
    private string $catalog;
    private string $apiRoutes;

    protected function setUp(): void
    {
        parent::setUp();
        $base = dirname(__DIR__, 3);
        // برای پین‌های «نبودِ» کد، کامنت‌ها حذف می‌شوند — سابقهٔ باگ در docblock
        // مجاز است؛ آنچه مهم است عینِ SQL/کدِ اجرایی است.
        $strip = static function (string $src): string {
            $src = preg_replace('#/\*.*?\*/#s', '', $src) ?? $src;   // /* */
            $src = preg_replace('#^\s*//.*$#m', '', $src) ?? $src;   // //
            $src = preg_replace('#^\s*\*.*$#m', '', $src) ?? $src;   // docblock tails
            return $src;
        };
        $this->kernel    = $strip((string)file_get_contents($base . '/app/Console/Kernel.php'));
        $this->job       = $strip((string)file_get_contents($base . '/app/Jobs/Lottery/UpdateLotteryChanceScoresJob.php'));
        $this->model     = $strip((string)file_get_contents($base . '/app/Models/LotteryParticipation.php'));
        $this->catalog   = (string)file_get_contents($base . '/app/Services/Settings/SettingsCatalog.php');
        $this->apiRoutes = (string)file_get_contents($base . '/routes/api.php');
        // نسخهٔ خام برای پین مارکر (مارکرها در کامنت‌اند)
        $this->jobRaw    = (string)file_get_contents($base . '/app/Jobs/Lottery/UpdateLotteryChanceScoresJob.php');
    }

    // ═══════════════ ① پنجرهٔ زمانی کرون ═══════════════

    public function testKernelCronNoLongerProcessesToday(): void
    {
        // باگ قبلی: JOIN روی d.date = CURDATE() — عددِ امروزِ هنوز-تولیدنشده
        $this->assertStringNotContainsString(
            'd.date = CURDATE()',
            $this->kernel,
            'کرون نباید دیگر عددِ «امروز» را هدف بگیرد (در ۰۳:۲۰ هنوز تولید نشده و رأی‌های امروز باز است)'
        );
        $this->assertStringNotContainsString(
            "handle((int) \$row->round_id, date('Y-m-d'))",
            $this->kernel,
            'پارامتر تاریخ Job نباید «امروزِ لحظهٔ اجرا» باشد؛ باید از ردیف‌های انتخابی (دیروز/بک‌فیل) بیاید'
        );
    }

    public function testKernelCronWindowIsYesterdayPlusBackfill(): void
    {
        // سقف پنجره = دیروز
        $this->assertStringContainsString('DATE_SUB(CURDATE(), INTERVAL 1 DAY)', $this->kernel,
            'سقف پنجرهٔ پردازش باید «دیروز» باشد');
        // عمق بک‌فیل = پارامتری bind شده
        $this->assertStringContainsString('DATE_SUB(CURDATE(), INTERVAL ? DAY)', $this->kernel,
            'کف پنجره باید با placeholder بایند شود (INTERVAL ? DAY)');
        $this->assertStringContainsString('lottery_score_backfill_days', $this->kernel,
            'عمق بک‌فیل از تنظیم lottery_score_backfill_days خوانده شود');
        $this->assertStringContainsString("max(1, int_value(\\setting('lottery_score_backfill_days', 14)))", $this->kernel,
            'کف ۱ روز برای مقدار خراب/صفر تنظیم');
    }

    public function testKernelCronBackfillSkipsClaimedDates(): void
    {
        $this->assertStringContainsString('NOT EXISTS', $this->kernel,
            'بک‌فیل باید تاریخ‌های claimشده را با NOT EXISTS حذف کند');
        $this->assertStringContainsString('JOIN lottery_chance_logs c ON c.participation_id = p.id AND c.date = d.date', $this->kernel,
            'پروب claim از مسیر participation (ایندکس uq_lcl_participation_date) — نه round_id بی‌ایندکس');
        // منبع حقیقت idempotency همان claim اتمیک خود Job است؛ فیلتر فقط بهینه‌سازی است
        $this->assertStringContainsString('ORDER BY d.round_id ASC, d.date ASC', $this->kernel,
            'ترتیب پردازش باید صعودی باشد تا زنجیرهٔ score_before → score_after درست سرهم شود');
    }

    public function testKernelCronReturnShape(): void
    {
        foreach (['window_days', 'candidates', 'processed', 'failed', 'detail'] as $key) {
            $this->assertStringContainsString("'{$key}'", $this->kernel,
                "کلید {$key} در خروجی کرون برای مشاهده‌پذیری پنل");
        }
    }

    public function testJobAppliesAsOfDateToParticipants(): void
    {
        $this->assertStringContainsString(
            'getAllActiveByRound($roundId, $date)',
            $this->job,
            'Job باید همان تاریخِ در حال پردازش را به getAllActiveByRound بدهد (as-of participation)'
        );
        $this->assertStringContainsString('FIX-S17-01', $this->jobRaw, 'مارکر تغییر (در کامنت — نسخهٔ خام)');
    }

    public function testModelAsOfFilterBoundIsEndOfDay(): void
    {
        $this->assertStringContainsString(
            'public function getAllActiveByRound(int $roundId, ?string $asOfDate = null): array',
            $this->model,
            'امضای متد باید as-of اختیاری بگیرد (سازگار با تمام callerهای موجود)'
        );
        $this->assertStringContainsString("created_at <= ?", $this->model,
            'فیلتر as-of روی created_at');
        $this->assertStringContainsString("23:59:59", $this->model,
            'مرز as-of = پایان همان روز (Y-m-d 23:59:59)');
    }

    public function testBackfillSettingRegisteredForOperators(): void
    {
        $this->assertStringContainsString("'lottery_score_backfill_days'", $this->catalog,
            'کلید بک‌فیل باید برای اپراتور در پنل تنظیمات ثبت شده باشد (ایدم camera_retention_days)');
    }

    // ═══════════════ ② gate لاتری در مسیر API ═══════════════

    public function testApiLotteryRoutesCarryFeatureGate(): void
    {
        $this->assertStringContainsString(
            "[ApiWalletController::class, 'lotteryList'], [\\App\\Middleware\\RequireFeature::class . ':lottery,json']",
            $this->apiRoutes,
            'GET /wallet/lottery/rounds باید RequireFeature:lottery داشته باشد (kill-switch کانال API)'
        );
        $this->assertStringContainsString(
            "[ApiWalletController::class, 'lotteryJoin'], [\\App\\Middleware\\RequireFeature::class . ':lottery,json']",
            $this->apiRoutes,
            'POST /wallet/lottery/join باید RequireFeature:lottery داشته باشد (با feature خاموش برداشت بلیط از API ممکن نباشد)'
        );
        $this->assertStringContainsString('FIX-S17-02', $this->apiRoutes, 'مارکر تغییر');
    }

    public function testApiCryptoGatesUntouchedRegression(): void
    {
        // رگرسیون: گیت‌های FIX-M12-24 سرِجایشان — 🛡️ FIX-BEHAV1-08: حالت ,json
        // به همان گیت‌ها افزوده شد (پاس JSON به موبایل Bearer)؛ خودِ گیت سرِجایشان است
        $this->assertStringContainsString(
            "[ApiWalletController::class, 'cryptoDepositWallets'], [\\App\\Middleware\\RequireFeature::class . ':crypto_wallet,json']",
            $this->apiRoutes
        );
        $this->assertStringContainsString(
            "[ApiWalletController::class, 'cryptoDepositCreateIntent'], [\\App\\Middleware\\RequireFeature::class . ':crypto_deposit,json']",
            $this->apiRoutes
        );
        // و مسیر وب هم همچنان گیت دارد (user.php)
        $userRoutes = (string)file_get_contents(dirname(__DIR__, 3) . '/routes/user.php');
        $this->assertStringContainsString("RequireFeature::class . ':lottery'", $userRoutes,
            'مسیرهای وب لاتری همچنان گیت دارند');
    }
}
