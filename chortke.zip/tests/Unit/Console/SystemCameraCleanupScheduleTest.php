<?php

declare(strict_types=1);

namespace Tests\Unit\Console;

use App\Commands\SystemCleanupCommand;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ رگرسیون پاک‌سازی دوربین — بازنویسهٔ بازبینی نهایی 2026-10-28:
 *
 * این فایل پیش از این، پیاده‌سازیِ بستهٔ R18-GAP (cleanOldCameraRequests روی
 * مدل + تنظیم camera_requests_retention_days) را پین می‌کرد — اما کد اصلی
 * پروژه (چرخهٔ موازی مالک) معماری متفاوت FIX-CAM-CLEANUP-V7 را دارد:
 * SystemCleanupCommand::cleanup() + سیم‌کشی Kernel. تستِ قدیمی روی کد اصلی
 * ۳ خطا (متد ناموجود) + ۲ شکست می‌داد. این نسخه همان قراردادها را روی
 * «پیاده‌سازی واقعیِ درخت» پین می‌کند:
 *   ۱) cleanup(): حذف دسته‌ای قدیمی‌ها (LIMIT 1000) + انقضای pendingها +
 *      شمارندهٔ صادقانهٔ هر مرحله؛
 *   ۲) کف retention = ۱ روز (ورودی ۰/منفی هرگز پنجرهٔ باز نگرفته نمی‌سازد)؛
 *   ۳) سقف retention = ۳۶۵۰ روز؛
 *   ۴) شکست مرحله‌ای = status=failed با همان شمارنده‌ها (هرگز جعل موفقیت نمی‌شود)؛
 *   ۵) سیم‌کشی Kernel: هوک system_camera_cleanup روزانهٔ ۰۴:۰۰ ← SystemCleanupCommand
 *      (بعد از پاک‌سازی ۰۳:۴۰) + ثبت کلید camera_retention_days در پنل تنظیمات.
 *
 * روش: AppSettings و Core\Database به‌عنوان ماک در Container نشسته‌اند
 * (همان الگویی که cleanup() از آن‌ها resolve می‌کند) — بدون DB واقعی؛
 * setUp وابستگی‌های اصلی را نگه می‌دارند و tearDown آن‌ها را برمی‌گرداند
 * تا ماک هرگز به فایل‌های بعدی ران کامل نشت نکند.
 */
final class SystemCameraCleanupScheduleTest extends TestCase
{
    /** وابستگی‌های اصلی Container قبل از جایگزینی با ماک — برای بازیابی در tearDown
     * (بدون این، ماک به‌عنوان singleton در Container نشت می‌کند و همهٔ فایل‌های
     * بعدی ران کامل که Core\Database واقعی انتظار دارند با BadMethodCallException
     * می‌میرند — درس بازبینی نهایی 2026-10-28) */
    private object $origDb;
    private object $origSettings;

    protected function setUp(): void
    {
        parent::setUp();
        $container = \Core\Container::getInstance();
        $this->origDb = $container->make(\Core\Database::class);
        $this->origSettings = $container->make(\App\Services\Settings\AppSettings::class);
    }

    protected function tearDown(): void
    {
        // بازیابی وابستگی‌های واقعی پیش از بستن Mockery — نشت ماک به ران کامل ممنوع
        $container = \Core\Container::getInstance();
        $container->instance(\Core\Database::class, $this->origDb);
        $container->instance(\App\Services\Settings\AppSettings::class, $this->origSettings);
        m::close();
        parent::tearDown();
    }

    /** stmt با rowCount دلخواه — خروجی $db->query در cleanup() (قرارداد PDOStatement) */
    private function stmtWithRowCount(int $n): \PDOStatement
    {
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('rowCount')->andReturn($n);
        return $stmt;
    }

    /**
     * اتصال ماک‌های AppSettings/Core\Database به Container.
     *
     * @param array<int, int> $deleteBatches  rowCount هر دستهٔ DELETE به‌ترتیب
     * @param int             $expectedIntervalDays  روزِ مورد انتظار در SQL حذف
     */
    private function bindContainer(array $deleteBatches, int $expiredRows, mixed $retentionSetting, int $expectedIntervalDays): void
    {
        $settings = m::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('get')->with('camera_retention_days', 30)->andReturn($retentionSetting);

        $needle = 'INTERVAL ' . $expectedIntervalDays . ' DAY';
        $deleteArgs = static function (string $sql, array $params) use ($needle): bool {
            return str_contains($sql, 'DELETE FROM social_camera_requests')
                && str_contains($sql, $needle)
                && str_contains($sql, 'LIMIT 1000');
        };

        $db = m::mock(\Core\Database::class);
        $batches = $deleteBatches;
        $db->shouldReceive('query')
            ->times(count($deleteBatches))
            ->withArgs($deleteArgs)
            ->andReturnUsing(function () use (&$batches) {
                return $this->stmtWithRowCount(array_shift($batches));
            });
        $db->shouldReceive('query')
            ->once()
            ->withArgs(static function (string $sql, array $params): bool {
                return str_contains($sql, 'UPDATE social_camera_requests')
                    && str_contains($sql, "'expired'")
                    && str_contains($sql, 'expires_at < NOW()');
            })
            ->andReturnUsing(fn (): \PDOStatement => $this->stmtWithRowCount($expiredRows));

        $container = \Core\Container::getInstance();
        $container->instance(\App\Services\Settings\AppSettings::class, $settings);
        $container->instance(\Core\Database::class, $db);
    }

    public function test_cleanup_deletes_old_batches_and_expires_pending_with_honest_counters(): void
    {
        // دو دستهٔ DELETE (۱۰۰۰ + ۴۰۰ = ۱۴۰۰) + ۵ pending منقضی — خروجی صادقانه
        $this->bindContainer([1000, 400], 5, 30, 30);

        $result = (new SystemCleanupCommand())->cleanup();

        $this->assertSame('ok', $result['status'], 'پاک‌سازی موفق: status=ok');
        $this->assertSame(30, $result['retention_days'], 'retention خوانده‌شده از تنظیمات');
        $this->assertSame(1400, $result['deleted'], 'جمع واقعی هر دو دسته (نه فقط دستهٔ آخر)');
        $this->assertSame(5, $result['expired'], 'شمارندهٔ انقضای pending');
    }

    public function test_cleanup_clamps_retention_days_to_minimum_one(): void
    {
        // ورودی ۰ → کف ۱ روز — پنجرهٔ «همه‌چیز» یا منفی هرگز ساخته نمی‌شود
        $this->bindContainer([0], 0, 0, 1);

        $result = (new SystemCleanupCommand())->cleanup();

        $this->assertSame(1, $result['retention_days'], 'کف retention = ۱ روز');
        $this->assertSame(0, $result['deleted']);
    }

    public function test_cleanup_clamps_retention_days_to_maximum_3650(): void
    {
        $this->bindContainer([0], 0, 99999, 3650);

        $result = (new SystemCleanupCommand())->cleanup();

        $this->assertSame(3650, $result['retention_days'], 'سقف retention = ۳۶۵۰ روز');
    }

    public function test_cleanup_reports_failure_without_faking_success(): void
    {
        // شکست DELETE = status=failed با همان شمارنده‌ها — سوئیپ انقضا همچنان
        // جدا اجرا می‌شود (خطای مرحله‌ای کل کامند را نمی‌کشد، ولی جعل ok هم نمی‌شود)
        $settings = m::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('get')->with('camera_retention_days', 30)->andReturn(30);

        $db = m::mock(\Core\Database::class);
        $db->shouldReceive('query')
            ->once()
            ->withArgs(static function (string $sql, array $params): bool {
                return str_contains($sql, 'DELETE FROM social_camera_requests');
            })
            ->andThrow(new \RuntimeException('db down'));
        $db->shouldReceive('query')
            ->once()
            ->withArgs(static function (string $sql, array $params): bool {
                return str_contains($sql, 'UPDATE social_camera_requests');
            })
            ->andReturnUsing(fn (): \PDOStatement => $this->stmtWithRowCount(3));

        $container = \Core\Container::getInstance();
        $container->instance(\App\Services\Settings\AppSettings::class, $settings);
        $container->instance(\Core\Database::class, $db);

        $result = (new SystemCleanupCommand())->cleanup();

        $this->assertSame('failed', $result['status'], 'شکست حذف = failed — نه ok جعلی');
        $this->assertStringContainsString('delete:', (string)$result['error'], 'خطای مرحلهٔ delete گزارش شود');
        $this->assertSame(0, $result['deleted']);
        $this->assertSame(3, $result['expired'], 'سوئیپ انقضا مستقل اجرا شد');
    }

    public function test_kernel_wires_daily_4am_hook_named_system_camera_cleanup(): void
    {
        $kernel = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Console/Kernel.php');

        $this->assertStringContainsString("daily('04:00'", $kernel, 'هوک پاک‌سازی دوربین باید روزانه ساعت ۰۴:۰۰ زمان‌بندی شود');
        $this->assertStringContainsString("'system_camera_cleanup'", $kernel, 'نام هوک: system_camera_cleanup (قابل راستی‌آزمایی در رجیستری کرون)');
        $this->assertStringContainsString('SystemCleanupCommand', $kernel, 'کرون باید SystemCleanupCommand::cleanup را صدا بزند (معماری FIX-CAM-CLEANUP-V7)');
        // 04:00 باید بعد از 03:40 (پاک‌سازی fingerprint) بیاید تا دو DELETE سنگین هم‌زمان نشوند
        $posVideo = strpos($kernel, "daily('03:40'");
        $posCamera = strpos($kernel, "daily('04:00'");
        $this->assertIsInt($posVideo);
        $this->assertIsInt($posCamera);
        $this->assertGreaterThan($posVideo, $posCamera, 'پاک‌سازی دوربین باید بعد از پاک‌سازی fingerprint زمان‌بندی شود');
    }

    public function test_retention_setting_is_registered_in_settings_catalog(): void
    {
        // SystemCleanupCommand کلید camera_retention_days را می‌خواند (پیش‌فرض ۳۰) —
        // بدون ثبت در کاتالوگ، اپراتور هیچ راهی برای تغییرش از پنل ندارد
        $catalog = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Services/Settings/SettingsCatalog.php');
        $this->assertStringContainsString("'camera_retention_days'", $catalog, 'کلید retention باید برای اپراتور در پنل تنظیمات ثبت شده باشد');
    }
}
