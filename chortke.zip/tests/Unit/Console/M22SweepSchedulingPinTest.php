<?php

declare(strict_types=1);

namespace Tests\Unit\Console;

use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M22-01: پین ساختاری — sweep ارسال‌های تسک سفارشی باید در زمان‌بند
 * Kernel ثبت شده باشد (قبلاً فقط allowlist صف بود و هیچ فراخوانی زمان‌بندی‌شده‌ای
 * نداشت ⇒ وعدهٔ «تأیید خودکار تا N ساعت» هرگز محقق نمی‌شد).
 *
 * @group architecture
 */
final class M22SweepSchedulingPinTest extends TestCase
{
    private static function kernelSource(): string
    {
        $src = file_get_contents(dirname(__DIR__, 3) . '/app/Console/Kernel.php');
        self::assertIsString($src);
        self::assertNotSame('', $src);
        return $src;
    }

    /** @test */
    public function kernel_registers_custom_task_submissions_sweep_with_scheduler(): void
    {
        $src = self::kernelSource();

        $this->assertStringContainsString('custom_task_submissions_sweep', $src, 'نام job زمان‌بندی باید ثبت شود');
        $this->assertStringContainsString(\App\Jobs\CustomTask\CronSubmissionsJob::class, $src, 'سوییپ باید CronSubmissionsJob را صدا بزند');
        $this->assertStringContainsString('FIX-M22-01', $src, 'مارکر اصلاح باید در Kernel بماند');
    }

    /** @test */
    public function sweep_is_registered_hourly_like_the_sibling_social_pattern(): void
    {
        $src = self::kernelSource();

        // الگوی ثبت ساعتانه (هم‌الگوی influencer_buyer_check_timeout / social_task_expire_pending)
        $this->assertSame(
            1,
            preg_match('/\$scheduler->hourly\(\s*function\s*\(\)\s*use\s*\(\$container\).*?custom_task_submissions_sweep/s', $src),
            'سوییپ باید با $scheduler->hourly ثبت شده باشد'
        );
        $this->assertStringContainsString("->handle()", $src, 'handle() جاب (هر دو sweep) باید صدا زده شود');
    }

    /** @test */
    public function sweep_job_still_invokes_both_sweeps_idempotently(): void
    {
        // قرارداد جاب: handle() = autoApprove + expire (بدون تغییر رفتار جاب)
        $ref = new \ReflectionClass(\App\Jobs\CustomTask\CronSubmissionsJob::class);
        $this->assertTrue($ref->hasMethod('handle'));
        $this->assertTrue($ref->hasMethod('autoApproveOldSubmissions'));
        $this->assertTrue($ref->hasMethod('expireOldSubmissions'));
    }
}
