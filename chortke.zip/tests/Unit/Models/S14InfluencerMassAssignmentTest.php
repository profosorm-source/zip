<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Controllers\Api\InfluencerController;
use App\Models\InfluencerModel;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بچ S14 — قفل رفتاری فیکس mass-assignment اینفلوئنسر (FIX-S14-2):
 *
 *  - شکل قبلی: InfluencerModel بدون $fillable بود (Base\Model با fillable خالی
 *    همهٔ کلیدها را به QueryBuilder می‌داد) و Api\InfluencerController::saveProfile
 *    در مسیر UPDATE بدنهٔ خام JSON را با ردیف فعلی merge و تمامش را به update()
 *    می‌داد ⇒ کاربر احرازشده می‌توانست status='verified' + is_active=1 خودش
 *    بنویسد (self-verification / دور زدن تایید ادمین) یا آمار (total_orders/
 *    completed_orders/average_rating) را جعل کند.
 *
 *  - فیکس دولایه: fillable مدل + whitelist صریح کنترلر (whitelistProfileUpdate).
 *
 *  - اثر جانبی بهبود: مسیر web (User\InfluencerController::storeProfile) که
 *    کلیدهای قیمتِ بی‌ستون (sponsored_post_price/pin_price/forward_price) را
 *    همیشه merge می‌کرد، قبلاً UPDATE/INSERT را با SQLSTATE 42S22 (1054)
 *    می‌شکست؛ اکنون آن کلیدها در لایهٔ fillable سالم فیلتر می‌شوند.
 *
 * تست‌های DB روی MariaDB واقعی اجرا می‌شوند (همان قرارداد S12ModelsHardeningTest).
 */
final class S14InfluencerMassAssignmentTest extends TestCase
{
    private ?int $createdProfileId = null;

    protected function tearDown(): void
    {
        if ($this->createdProfileId !== null) {
            try {
                (new InfluencerModel(Database::getInstance()))->forceDelete($this->createdProfileId);
            } catch (\Throwable) {
                // teardown best-effort
            }
            $this->createdProfileId = null;
        }
        parent::tearDown();
    }

    // ─────────────────────────────────────────────────────────────
    // لایهٔ ۱ — whitelist کنترلر API
    // ─────────────────────────────────────────────────────────────

    public function test_controller_whitelist_drops_privilege_keys_and_body_overrides_row(): void
    {
        $row = [
            'id' => 7,
            'user_id' => 42,
            'status' => 'pending',
            'is_active' => 0,
            'verified_by' => null,
            'total_orders' => 3,
            'completed_orders' => 2,
            'average_rating' => '4.50',
            'currency' => 'irt',
            'priority' => 5,
            'username' => 'old_name',
            'bio' => 'old bio',
            'page_url' => 'https://old.example/t',
        ];
        $body = [
            // حمله — کلیدهای مدیریتی نباید عبور کنند:
            'status' => 'verified',
            'is_active' => 1,
            'verified_by' => 1,
            'verified_at' => date('Y-m-d H:i:s'),
            'total_orders' => 99999,
            'completed_orders' => 99999,
            'average_rating' => 5.0,
            'currency' => 'usd',
            'priority' => 100,
            'user_id' => 1,
            'id' => 1,
            // به‌روزرسانی مشروع — باید body روی row override کند:
            'username' => 'new_name',
            'bio' => 'new bio',
            'page_url' => 'https://new.example/t',
            'follower_count' => 12000,
        ];

        $merged = InfluencerController::whitelistProfileUpdate($row, $body);

        // حمله‌ها حذف شدند:
        foreach (['status', 'is_active', 'verified_by', 'verified_at', 'total_orders',
                  'completed_orders', 'average_rating', 'currency', 'priority', 'user_id', 'id'] as $k) {
            $this->assertArrayNotHasKey($k, $merged, "کلید مدیریتی {$k} نباید از بدنه عبور کند");
        }
        // override صحیح body روی row:
        $this->assertSame('new_name', $merged['username']);
        $this->assertSame('new bio', $merged['bio']);
        $this->assertSame('https://new.example/t', $merged['page_url']);
        $this->assertSame(12000, $merged['follower_count']);
    }

    // ─────────────────────────────────────────────────────────────
    // لایهٔ ۲ — fillable مدل (روی MariaDB واقعی)
    // ─────────────────────────────────────────────────────────────

    private function createFixtureProfile(): ?array
    {
        $db = Database::getInstance();
        $userId = (int)($db->fetchColumn(
            "SELECT u.id FROM users u
             LEFT JOIN influencer_profiles ip ON ip.user_id = u.id
             WHERE ip.id IS NULL AND u.deleted_at IS NULL
             ORDER BY u.id ASC LIMIT 1"
        ) ?? 0);
        if ($userId <= 0) {
            return null;
        }

        $model = new InfluencerModel(Database::getInstance());
        $profile = $model->createProfile([
            'user_id' => $userId,
            'platform' => 'instagram',
            'username' => 's14_massassign_fixture',
            'page_url' => 'https://example.com/s14',
            'follower_count' => 5000,
            'status' => 'pending',
            'verification_code' => 'CK-S14TEST',
        ]);
        if (!$profile) {
            return null;
        }
        $this->createdProfileId = (int)$profile->id;
        return ['model' => $model, 'profile' => $profile];
    }

    public function test_model_fillable_drops_hostile_columns_on_update(): void
    {
        $fixture = $this->createFixtureProfile();
        if ($fixture === null) {
            $this->markTestSkipped('هیچ کاربر بدون پروفایل برای fixture پیدا نشد');
        }
        $model = $fixture['model'];
        $profileId = (int)$fixture['profile']->id;

        $ok = $model->update($profileId, [
            'bio' => 'S14 updated bio', // کلید مجاز — باید نوشته شود
            // حمله — ستون‌های مدیریتی/محاسباتی خارج از fillable:
            'total_orders' => 99999,
            'completed_orders' => 99999,
            'average_rating' => 3.3, // قابل‌تشخیص از پیش‌فرض ستون (5.00)
            'followers_count' => 9999999,
            'price_story' => 12345.0,
            'currency' => 'usd',
            'deleted_at' => date('Y-m-d H:i:s'),
        ]);
        $this->assertTrue($ok);

        $row = $model->find($profileId);
        $this->assertNotNull($row);
        $this->assertSame('S14 updated bio', (string)$row->bio);
        $this->assertSame(0, (int)$row->total_orders);
        $this->assertSame(0, (int)$row->completed_orders);
        // پیش‌فرض ستون 5.00 است؛ 3.3ِ حمله‌وار فیلتر شده و مقدار دست‌نخورده:
        $this->assertSame('5.00', (string)$row->average_rating);
        $this->assertSame(5000, (int)$row->follower_count);
        $this->assertSame('irt', (string)$row->currency);
        $this->assertNull($row->deleted_at);
        $this->assertSame('pending', (string)$row->status);
    }

    public function test_model_fillable_heals_ghost_price_columns_from_web_path(): void
    {
        // مسیر web کلیدهای بی‌ستون را همیشه merge می‌کرد ⇒ 1054؛ اکنون فیلتر سالم:
        $fixture = $this->createFixtureProfile();
        if ($fixture === null) {
            $this->markTestSkipped('هیچ کاربر بدون پروفایل برای fixture پیدا نشد');
        }
        $model = $fixture['model'];
        $profileId = (int)$fixture['profile']->id;

        $ok = $model->update($profileId, [
            'bio' => 'web path heal',
            'story_price_24h' => 150000.0,
            'post_price_24h' => 250000.0,
            // کلیدهای بی‌ستونِ legacy مسیر web — قبلاً SQLSTATE 42S22:
            'sponsored_post_price' => 100000.0,
            'pin_price' => 90000.0,
            'forward_price' => 80000.0,
        ]);
        $this->assertTrue($ok, 'کلیدهای بی‌ستون باید بدون خطای ۱۰۵۴ فیلتر شوند');

        $row = $model->find($profileId);
        $this->assertNotNull($row);
        $this->assertSame('web path heal', (string)$row->bio);
        $this->assertSame('150000.0000', (string)$row->story_price_24h);
        $this->assertSame('250000.0000', (string)$row->post_price_24h);
    }

    public function test_admin_verification_keys_still_writable(): void
    {
        // رگرسیون نویسنده‌های مشروع ادمین (Admin\InfluencerController approve/reject/suspend):
        $fixture = $this->createFixtureProfile();
        if ($fixture === null) {
            $this->markTestSkipped('هیچ کاربر بدون پروفایل برای fixture پیدا نشد');
        }
        $model = $fixture['model'];
        $profileId = (int)$fixture['profile']->id;

        $ok = $model->update($profileId, [
            'status' => 'verified',
            'verified_by' => 1,
            'verified_at' => date('Y-m-d H:i:s'),
            'is_active' => 1,
        ]);
        $this->assertTrue($ok);
        $row = $model->find($profileId);
        $this->assertNotNull($row);
        $this->assertSame('verified', (string)$row->status);
        $this->assertSame(1, (int)$row->is_active);

        $ok = $model->update($profileId, [
            'status' => 'suspended',
            'is_active' => 0,
            'suspended_at' => date('Y-m-d H:i:s'),
            'suspended_reason' => 'S14 test',
        ]);
        $this->assertTrue($ok);
        $row2 = $model->find($profileId);
        $this->assertNotNull($row2);
        $this->assertSame('suspended', (string)$row2->status);
        $this->assertSame('S14 test', (string)$row2->suspended_reason);
    }
}
