<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\ContentSubmission;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-Q4-MOD24-05 — قرارداد نرمال‌سازی URL ویدیو (خالص، بدون DB).
 *
 * گزارش بخش ۲۴ (MOD24-05): تشخیص لینک تکراری فقط «تطابق دقیق رشته» بود؛
 * یک ویدیو با https/http متفاوت، پارامتر اضافه (?t=)، نسخهٔ youtu.be در
 * برابر youtube.com/watch یا اسلش انتهایی، چند رکورد مستقل (و درآمد جداگانه)
 * می‌ساخت. این تست‌ها کلید نرمال مشترکِ همهٔ شکل‌های یک ویدیو را pin می‌کنند.
 */
final class ContentUrlCanonicalizationTest extends TestCase
{
    /** همهٔ شکل‌های رسمی یوتیوب باید یک کلید بسازند */
    public function test_youtube_variants_share_one_canonical_key(): void
    {
        $expected = 'yt:dQw4w9WgXcQ';
        $variants = [
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            'http://youtube.com/watch?v=dQw4w9WgXcQ',
            'https://m.youtube.com/watch?v=dQw4w9WgXcQ&t=30s',
            'https://youtu.be/dQw4w9WgXcQ',
            'https://www.youtube.com/shorts/dQw4w9WgXcQ',
            'https://www.youtube.com/embed/dQw4w9WgXcQ',
            'https://www.youtube.com/live/dQw4w9WgXcQ',
            'https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=PLabc123&index=2',
            'https://YouTube.com/watch?v=dQw4w9WgXcQ#t=5',
        ];
        foreach ($variants as $url) {
            $this->assertSame($expected, ContentSubmission::canonicalVideoKey($url), "URL: {$url}");
        }
    }

    /** شکل‌های آپارات همه به /v/<id> ختم می‌شوند */
    public function test_aparat_variants_share_one_canonical_key(): void
    {
        $expected = 'ap:AbCd123';
        $variants = [
            'https://www.aparat.com/v/AbCd123',
            'https://aparat.com/v/AbCd123?playlist=1',
            'http://www.aparat.com/v/AbCd123#preview',
        ];
        foreach ($variants as $url) {
            $this->assertSame($expected, ContentSubmission::canonicalVideoKey($url), "URL: {$url}");
        }
    }

    /** پلتفرم عمومی: host کوچک + بدون www + بدون query/fragment/اسلش انتهایی */
    public function test_generic_url_normalization(): void
    {
        $this->assertSame(
            'example.com/files/video1',
            ContentSubmission::canonicalVideoKey('https://www.Example.com/files/video1/?download=1#top')
        );
        // ریشهٔ دامنه بدون مسیر
        $this->assertSame(
            'example.com',
            ContentSubmission::canonicalVideoKey('https://example.com/')
        );
    }

    /** هش شامل platform است ⇒ همان ویدیو در دو پلتفرم دو هش متفاوت دارد */
    public function test_hash_is_platform_scoped(): void
    {
        $yt = 'https://youtu.be/dQw4w9WgXcQ';
        $this->assertSame(
            ContentSubmission::hashVideoUrl('youtube', $yt),
            ContentSubmission::hashVideoUrl('youtube', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ')
        );
        $this->assertNotSame(
            ContentSubmission::hashVideoUrl('youtube', $yt),
            ContentSubmission::hashVideoUrl('aparat', $yt),
            'هش باید platform را درون خود داشته باشد'
        );
    }

    /** هش ۶۴ کاراکتر هگز (SHA-256) است */
    public function test_hash_shape(): void
    {
        $hash = ContentSubmission::hashVideoUrl('youtube', 'https://youtu.be/x1');
        $this->assertSame(64, strlen($hash));
        $this->assertRegExp('/^[0-9a-f]{64}$/', $hash);
    }

    /** ورودی خالی ⇒ کلید خالی (نه crash) */
    public function test_empty_input_yields_empty_key(): void
    {
        $this->assertSame('', ContentSubmission::canonicalVideoKey(''));
        $this->assertSame('', ContentSubmission::canonicalVideoKey('   '));
    }
}
