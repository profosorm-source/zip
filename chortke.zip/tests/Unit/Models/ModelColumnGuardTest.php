<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use Core\Database;
use Core\Model;
use Core\QueryBuilder;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * W4-F (F-A2-08) — Runtime Column Guard (گارد سیستمی ستون‌ها در ORM).
 *
 * پین‌کردن قرارداد گارد روی core/Model.php:
 *  ① create()/update() با ستون‌های زنده → عیناً مثل قبل اجرا می‌شوند (zero behavior change).
 *  ② کلید ناشناخته → \InvalidArgumentException با پیام دقیق
 *     (عملیات + جدول + کلاس مدل + ستون متخلف) — FAIL FAST قبل از DB؛
 *     ستون هرگز silent-drop نمی‌شود (گناه اصلیِ یافتهٔ F-A2-08).
 *  ③ ترتیب: filterFillable (mass-assignment، قرارداد مستند FIX-18O/S14) اول
 *     اجرا می‌شود، گاردِ اسکیما روی «مجموعهٔ واقعاً نوشتنی» اعمال می‌شود.
 *  ④ Escape hatch: setStrictColumns(false) — پیش‌فرض STRICT.
 *  ⑤ کش اسکیما: یک کوئری INFORMATION_SCHEMA به‌ازای هر (db,table) در هر
 *     پنجرهٔ TTL — ردیف دوم به بعد فقط array-lookup (بدون N+1)؛ با
 *     «counting PDO stub» (ایدیم tests/Unit/Core/DatabaseTest.php) شمرده می‌شود.
 *  ⑥ محافظت از کشِ کهنه: نقضِ گارد یک introspection تازه اجرا می‌کند؛
 *     ستونِ تازه-افوده با مایگریشن زنده false-positive نمی‌دهد.
 *  ⑦ اسکیمای غیرقابل‌مشاهده (null) → fail-open؛ خودِ write غلط در سرور
 *     fail-loud می‌شود (42S22) — گارد درِ قطع دسترسی نیست.
 *
 * سبک خانه: Database با Mockery مک می‌شود (بدون DB واقعی) — آینهٔ
 * tests/Unit/Models/S16ModelsSecurityPinningTest.php؛ و برای سناریوی
 * کش/شمارش، Database واقعی با PDO stub تزریقی (آینهٔ DatabaseTest).
 */
final class ModelColumnGuardTest extends TestCase
{
    public const TABLE = 'guard_test_table';

    /** @var \Core\Database&\Mockery\MockInterface */
    private \Core\Database $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock('Core\Database');
        Database::resetTableColumnsCache();
    }

    protected function tearDown(): void
    {
        Database::resetTableColumnsCache();
        m::close();
        parent::tearDown();
    }

    /** مدل fixture بدون fillable (همهٔ کلیدها به گارد می‌رسند) */
    private function makeModel(): Model
    {
        /*
        | FIX-YAFTE4 (یافته ۴): قرارداد FIX-S9-03 در filterFillable — مدل بدون
        | $fillable به‌صورت deny-by-default می‌نویسد [] (opt-in صریح لازم دارد).
        | این تست گارد را پین می‌کند، نه mass-assignment را؛ fixture از مسیرِ
        | مستندِ escape-hatch (گاردِ ستون مستقل از فیلتر fillable است) عبور
        | می‌دهد تا کلیدها «همه» به guardColumns برسند — همان چیزی که هدر تست
        | قرارداد کرده است.
        */
        return new class($this->db) extends Model {
            protected static string $table = ModelColumnGuardTest::TABLE;
            protected static bool $unguarded = true;
        };
    }

    /** stub جدول‌بیلدر که insert/update را کپچر می‌کند */
    private function stubQueryBuilder(): \Core\QueryBuilder&\Mockery\MockInterface
    {
        $qb = m::mock(QueryBuilder::class);
        $this->db->shouldReceive('table')
            ->with(self::TABLE)
            ->andReturn($qb)
            ->byDefault();

        return $qb;
    }

    private function stubSchema(array $columns): void
    {
        $this->db->shouldReceive('getTableColumns')
            ->with(self::TABLE)
            ->andReturn($columns)
            ->byDefault();
    }

    // ─────────────────────────────────────────────────────────────
    // ① مسیرهای سالم — zero behavior change
    // ─────────────────────────────────────────────────────────────

    public function test_default_state_is_strict(): void
    {
        $this->assertTrue($this->makeModel()->isStrictColumns());
    }

    public function test_create_with_live_columns_passes_and_insert_receives_data_exactly(): void
    {
        $this->stubSchema(['id', 'name', 'created_at']);
        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('insert')->once()->with(['name' => 'ali'])->andReturn(7);

        $this->db->shouldReceive('getFreshTableColumns')->never();

        $model = $this->makeModel();
        $this->assertSame(7, $model->create(['name' => 'ali']));
    }

    public function test_update_with_live_columns_passes_and_stamps_updated_at(): void
    {
        $this->stubSchema(['id', 'name', 'updated_at']);
        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('where')->once()->with('id', '=', 5)->andReturnSelf();
        $captured = [];
        $qb->shouldReceive('update')->once()
            ->with(m::on(function (array $data) use (&$captured): bool {
                $captured = $data;
                return true;
            }))
            ->andReturn(1);

        $model = $this->makeModel();
        $this->assertTrue($model->update(5, ['name' => 'new']));
        $this->assertSame('new', $captured['name'] ?? null);
        $this->assertArrayHasKey('updated_at', $captured, 'updated_at مهرِ قراردادی update باید حفظ شود');
    }

    // ─────────────────────────────────────────────────────────────
    // ② مسیر نقض — fail-fast با پیام دقیق
    // ─────────────────────────────────────────────────────────────

    public function test_create_with_unknown_column_throws_precise_invalid_argument(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger در تست
        $this->stubSchema(['id', 'name']);
        $this->db->shouldReceive('getFreshTableColumns')
            ->with(self::TABLE)
            ->andReturn(['id', 'name']) // recheck تازه هم ستون را تأیید نمی‌کند
            ->once();
        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('insert')->never(); // fail-fast: قبل از DB

        $model = $this->makeModel();

        try {
            $model->create(['name' => 'ok', 'ghost_col' => 1, 'second_ghost' => 2]);
            $this->fail('Expected InvalidArgumentException for unknown column');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('[ColumnGuard]', $e->getMessage());
            $this->assertStringContainsString('INSERT', $e->getMessage());
            $this->assertStringContainsString(self::TABLE, $e->getMessage(), 'پیام باید جدول را بگوید');
            $this->assertStringContainsString('`ghost_col`', $e->getMessage(), 'پیام باید ستون متخلف را بگوید');
            $this->assertStringContainsString('`second_ghost`', $e->getMessage());
            $this->assertStringContainsString(get_class($model), $e->getMessage(), 'پیام باید کلاس مدل را بگوید');
        }
    }

    public function test_update_with_unknown_column_throws_precise_invalid_argument(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger در تست
        // updated_at توسط Model::update مهر می‌شود → باید جزو ستون‌های شناخته‌شده باشد
        $this->stubSchema(['id', 'name', 'updated_at']);
        $this->db->shouldReceive('getFreshTableColumns')
            ->with(self::TABLE)
            ->andReturn(['id', 'name', 'updated_at'])
            ->once();
        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('update')->never(); // fail-fast: قبل از DB

        $model = $this->makeModel();

        try {
            $model->update(3, ['ghost_col' => 1]);
            $this->fail('Expected InvalidArgumentException for unknown column');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('[ColumnGuard]', $e->getMessage());
            $this->assertStringContainsString('UPDATE', $e->getMessage());
            $this->assertStringContainsString('`ghost_col`', $e->getMessage());
            $this->assertStringContainsString(self::TABLE, $e->getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────
    // ③ ترتیب filterFillable → guard
    // ─────────────────────────────────────────────────────────────

    public function test_fillable_filter_runs_before_guard_so_write_set_is_validated(): void
    {
        // ترتیب پین می‌شود: filterFillable (قرارداد mass-assignment FIX-18O) اول
        // اجرا می‌شود؛ اگر گارد قبل از fillable بود، کلیدِ بی‌fillableِ 'name'
        // استثنا می‌داد. این‌جا 'name' توسط fillable حذف می‌شود و مجموعهٔ
        // واقعاً نوشتنی ('title' — ستون زنده) بدون استثنا عبور می‌کند.
        $this->db->shouldReceive('getTableColumns')
            ->with(self::TABLE)
            ->andReturn(['id', 'title'])
            ->once();

        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('insert')->once()->with(['title' => 'ok'])->andReturn(true);

        $model = new class($this->db) extends Model {
            protected static string $table = ModelColumnGuardTest::TABLE;

            /** @var list<string> */
            protected array $fillable = ['title'];
        };

        $this->assertTrue($model->create(['name' => 'evil_outside_fillable', 'title' => 'ok']));
    }

    // ─────────────────────────────────────────────────────────────
    // ④ Escape hatch
    // ─────────────────────────────────────────────────────────────

    public function test_escape_hatch_relaxes_guard_for_legit_dynamic_cases(): void
    {
        $this->stubSchema(['id', 'name']);
        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('insert')->once()->with(['ghost_col' => 1])->andReturn(true);

        $model = $this->makeModel();
        $model->setStrictColumns(false);
        $this->assertFalse($model->isStrictColumns());
        $this->assertTrue($model->create(['ghost_col' => 1]));
    }

    // ─────────────────────────────────────────────────────────────
    // ⑦ fail-open وقتی اسکیما غیرقابل‌مشاهده است
    // ─────────────────────────────────────────────────────────────

    public function test_unobservable_schema_fails_open_and_db_stays_the_loud_backstop(): void
    {
        $this->db->shouldReceive('getTableColumns')->with(self::TABLE)->andReturn(null)->byDefault();
        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('insert')->once()->with(['ghost_col' => 1])->andReturn(true);

        $model = $this->makeModel();
        $this->assertTrue($model->create(['ghost_col' => 1]));
    }

    /**
     * پینِ رگرسیون AuditTrailServiceTest: دابل‌های سخت‌گیر Mockery روی متدِ
     * بدون expectation به‌جای null پرتاب می‌کنند — گارد باید این را هم
     * «اسکیمای غیرقابل‌مشاهده» ببیند (fail-open)، نه شکستِ write.
     */
    public function test_introspection_throw_is_swallowed_and_write_proceeds(): void
    {
        $this->db->shouldReceive('getTableColumns')
            ->with(self::TABLE)
            ->andThrow(new \BadMethodCallException('Received ..., but no expectations were specified'));
        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('insert')->once()->with(['ghost_col' => 1])->andReturn(true);

        $model = $this->makeModel();
        $this->assertTrue($model->create(['ghost_col' => 1]));
    }

    // ─────────────────────────────────────────────────────────────
    // ⑥ محافظت از کشِ کهنه (recheck تازه قبل از پرتاب)
    // ─────────────────────────────────────────────────────────────

    public function test_stale_schema_cache_is_self_healed_by_fresh_recheck(): void
    {
        // کش کهنه: 'fresh_col' را نمی‌داند (مثلاً worker طولانی‌عمر پس از مایگریشن)
        $this->db->shouldReceive('getTableColumns')
            ->with(self::TABLE)
            ->andReturn(['id', 'name'])
            ->once();
        // recheck تازه: ستون واقعاً زنده است → کش refresh و write عبور می‌کند
        $this->db->shouldReceive('getFreshTableColumns')
            ->with(self::TABLE)
            ->andReturn(['id', 'name', 'fresh_col'])
            ->once();

        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('insert')->once()->with(['fresh_col' => 9])->andReturn(11);

        $model = $this->makeModel();
        $this->assertSame(11, $model->create(['fresh_col' => 9]));
    }

    public function test_column_unknown_even_after_fresh_recheck_still_throws(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger در تست
        $this->db->shouldReceive('getTableColumns')
            ->with(self::TABLE)
            ->andReturn(['id', 'name'])
            ->once();
        $this->db->shouldReceive('getFreshTableColumns')
            ->with(self::TABLE)
            ->andReturn(['id', 'name'])
            ->once();

        $qb = $this->stubQueryBuilder();
        $qb->shouldReceive('insert')->never();

        $model = $this->makeModel();
        try {
            $model->create(['truly_bogus' => 1]);
            $this->fail('Expected InvalidArgumentException even after fresh recheck');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('`truly_bogus`', $e->getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────
    // ⑤ کش: یک کوئری INFORMATION_SCHEMA در هر پنجرهٔ TTL (+ expiry refresh)
    //    با Database واقعی + counting PDO stub (بدون DB واقعی)
    // ─────────────────────────────────────────────────────────────

    public function test_introspection_query_runs_once_per_window_and_refreshes_after_ttl_expiry(): void
    {
        $counter = new class {
            public int $schemaQueries = 0;
        };

        $stmt = new class extends \PDOStatement {
            /** @var list<\stdClass> */
            public array $rows = [];

            public function __construct() {}

            /** @param array<int|string, mixed> $params */
            public function execute(?array $params = null): bool
            {
                return true;
            }

            public function bindValue(int|string $param, mixed $value, int $type = \PDO::PARAM_STR): bool
            {
                return true;
            }

            public function fetchAll(int $mode = \PDO::FETCH_OBJ, mixed ...$fetchModeArgs): array
            {
                return $this->rows;
            }
        };
        $stmt->rows = [
            (object)['column_name' => 'id'],
            (object)['column_name' => 'name'],
        ];

        $pdo = new class($counter, $stmt) extends \PDO {
            /** @var object{schemaQueries:int} */
            private object $counter;
            private \PDOStatement $stmt;

            public function __construct(object $counter, \PDOStatement $stmt)
            {
                $this->counter = $counter;
                $this->stmt = $stmt;
            }

            public function prepare(string $query, array $options = []): \PDOStatement|false
            {
                if (str_contains($query, 'INFORMATION_SCHEMA')) {
                    $this->counter->schemaQueries++;
                }
                return $this->stmt;
            }

            public function inTransaction(): bool
            {
                return false;
            }

            public function lastInsertId(?string $name = null): string|false
            {
                return '42';
            }
        };

        // ایدیم DatabaseTest: نمونهٔ Database بدون constructor + تزریق PDO stub
        $reflection = new \ReflectionClass(Database::class);
        $database = $reflection->newInstanceWithoutConstructor();
        $pdoProp = $reflection->getProperty('pdo');
        if (PHP_VERSION_ID < 80100) { $pdoProp->setAccessible(true); }
        $pdoProp->setValue($database, $pdo);
        $pingProp = $reflection->getProperty('lastPingTime');
        if (PHP_VERSION_ID < 80100) { $pingProp->setAccessible(true); }
        $pingProp->setValue($database, time());

        $model = new class($database) extends Model {
            protected static string $table = ModelColumnGuardTest::TABLE;
            // FIX-YAFTE4: opt-in مستند — مسیر گارد/کش پین می‌شود، نه mass-assignment
            protected static bool $unguarded = true;
        };
        // کش مشترک PERSISTENT است (بین ران‌های phpunit) — کلید مصنوعی این جدول
        // (dbName='unknown' چون config مقداردهی‌نشده) باید سرد شروع کند
        $prefix = (new \ReflectionClass(Database::class))->getConstant('SCHEMA_CACHE_SHARED_PREFIX');
        $this->assertIsString($prefix);
        try {
            \Core\Cache::getInstance()->forget($prefix . 'unknown.' . self::TABLE);
        } catch (\Throwable $e) {
            $this->markTestSkipped('کش مشترک در دسترس نیست: ' . $e->getMessage());
        }

        // create #1 → یک کوئری INFORMATION_SCHEMA (سرد)
        $this->assertSame(42, $model->create(['name' => 'a']));
        $this->assertSame(1, $counter->schemaQueries, 'اولین write باید اسکیما را یک‌بار بخواند');

        // create #2 → کش per-process؛ هیچ کوئری اضافی (بدون N+1 per-row)
        $this->assertSame(42, $model->create(['name' => 'b']));
        $this->assertSame(1, $counter->schemaQueries, 'ردیف دوم باید فقط array-lookup باشد');

        // expiry مصنوعی لایهٔ استاتیک → create #3 → لایهٔ دوم (کش مشترک) جواب
        // می‌دهد؛ هنوز هیچ کوئری اضافی (رفتار دو-لایهٔ کش)
        $cacheProp = $reflection->getProperty('tableColumnsCache');
        if (PHP_VERSION_ID < 80100) { $cacheProp->setAccessible(true); }
        $cache = $cacheProp->getValue();
        $key = (string)array_key_first($cache);
        $this->assertNotSame('', $key);
        $cache[$key]['at'] = time() - 601; // پنجرهٔ 600s استاتیک منقضی
        $cacheProp->setValue($cache, $cache);

        $this->assertSame(42, $model->create(['name' => 'c']));
        $this->assertSame(1, $counter->schemaQueries, 'پس از انقضای لایهٔ استاتیک، کش مشترک باید بدون کوئری جواب بدهد');

        \Core\Cache::getInstance()->forget($prefix . $key);
        $this->assertFalse(\Core\Cache::getInstance()->has($prefix . $key), 'بعد از forget، کش مشترک باید خالی باشد');
        $cache[$key]['at'] = time() - 601;
        $cacheProp->setValue($cache, $cache);

        $this->assertSame(42, $model->create(['name' => 'd']));
        $this->assertSame(2, $counter->schemaQueries, 'پس از انقضای کامل TTL باید اسکیما تازه شود');

        // hygiene: کلید مصنوعی ('unknown.' — config مقداردهی‌نشده) از کش مشترک پاک شود
        try {
            \Core\Cache::getInstance()->forget($prefix . $key);
        } catch (\Throwable $ignore) {}
    }
}
