<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\CustomTaskSubmissionModel;
use App\Models\User;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🧾 FIX-N22-01/FIX-N22-02 — رفتار واقعی (بدون بازرسی سورس) متدهای جدید:
 *
 *  N22-01: CustomTaskSubmissionModel::submission_countDeviceCollusions —
 *    تطبیق هم‌زمان IP «و» اثر انگشت با مجری دیگر روی همان تسک؛ سیگنال بی‌معنا
 *    (unknown/خالی) بدون کوئری رد می‌شود.
 *  N22-02: submission_getParkedForAutoApprove / submission_countParkedForAutoApprove /
 *    submission_resetAutoApproveAttempts — دید و راه بازگشت ردیف‌های پارک‌شدهٔ sweep
 *    (همان آستانهٔ AUTO_APPROVE_PARK_THRESHOLD منبع واحد مدل).
 */
final class N22ParkedAndCollusionModelTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    public function test_device_collusion_requires_both_ip_and_fingerprint_match(): void
    {
        $capturedSql = '';
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with([11, 21, '10.0.0.1', 'abc123'])->andReturn(true);
        $stmt->shouldReceive('fetchColumn')->once()->andReturn('2');

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->with(m::on(static function (string $sql) use (&$capturedSql): bool {
            $capturedSql = $sql;
            return true;
        }))->andReturn($stmt);

        $model = new CustomTaskSubmissionModel($db);
        $this->assertSame(2, $model->submission_countDeviceCollusions(11, 21, '10.0.0.1', 'abc123'));

        // مجری دیگر، همان تسک؛ ارسال‌های منقضی/ردشده نمی‌شمارند؛ هر دو سیگنال لازم‌اند
        $this->assertStringContainsString('worker_id <> ?', $capturedSql);
        $this->assertStringContainsString("status NOT IN ('expired', 'rejected')", $capturedSql);
        $this->assertStringContainsString('worker_ip = ?', $capturedSql);
        $this->assertStringContainsString("worker_fingerprint NOT IN ('', 'unknown')", $capturedSql);
        $this->assertStringContainsString('worker_fingerprint = ?', $capturedSql);
    }

    /** @dataProvider meaninglessSignalProvider */
    public function test_device_collusion_short_circuits_on_meaningless_signal(string $ip, string $fp): void
    {
        $db = m::mock(Database::class);
        $db->shouldNotReceive('prepare');

        $model = new CustomTaskSubmissionModel($db);
        $this->assertSame(0, $model->submission_countDeviceCollusions(11, 21, $ip, $fp),
            'بدون سیگنال معتبر، اتهام هم‌دستسی نمی‌سازیم (بدون کوئری)');
    }

    /** @return list<list<string>> */
    public function meaninglessSignalProvider(): array
    {
        return [
            // رشته‌های بی‌معنای صریح
            ['10.0.0.1', 'unknown'],
            ['10.0.0.1', ''],
            ['', 'abc123'],
            // IPهای جای‌نگهدار (CLI/بدون REMOTE_ADDR/پروکسی محلی)
            ['0.0.0.0', 'abc123'],
            ['127.0.0.1', 'abc123'],
            // اثر انگشت جای‌نگهدار (هش UA-fallback محیط CLI)
            ['10.0.0.1', 'ad921d60486366258809553a3db49a4a'], // md5('unknown')
            ['10.0.0.1', '88183b946cc5f0e8c96b2e66e1c74a7e'], // md5('Unknown')
        ];
    }

    public function test_parked_list_uses_park_threshold_and_orders_worst_oldest_first(): void
    {
        $capturedSql = '';
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with([10])->andReturn(true);
        $stmt->shouldReceive('fetchAll')->once()->andReturn([]);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->with(m::on(static function (string $sql) use (&$capturedSql): bool {
            $capturedSql = $sql;
            return true;
        }))->andReturn($stmt);

        $model = new CustomTaskSubmissionModel($db);
        $this->assertSame([], $model->submission_getParkedForAutoApprove());

        $this->assertStringContainsString("s.status = 'submitted'", $capturedSql);
        $this->assertStringContainsString('s.auto_approve_attempts >= ?', $capturedSql);
        // بدترین‌ها (بیشترین شکست) اول، سپس قدیمی‌ترین — تعیین تکلیف دیرترین‌ها
        $this->assertStringContainsString('ORDER BY s.auto_approve_attempts DESC, s.submitted_at ASC', $capturedSql);
        // اطلاعات داوری: عنوان تسک + مجری
        $this->assertStringContainsString('ct.title AS task_title', $capturedSql);
        $this->assertStringContainsString('w.full_name AS worker_name', $capturedSql);
    }

    public function test_parked_count_binds_same_threshold(): void
    {
        $capturedSql = '';
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with([10])->andReturn(true);
        $stmt->shouldReceive('fetchColumn')->once()->andReturn('7');

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->with(m::on(static function (string $sql) use (&$capturedSql): bool {
            $capturedSql = $sql;
            return true;
        }))->andReturn($stmt);

        $model = new CustomTaskSubmissionModel($db);
        $this->assertSame(7, $model->submission_countParkedForAutoApprove());
        $this->assertStringContainsString("status = 'submitted'", $capturedSql);
        $this->assertStringContainsString('auto_approve_attempts >= ?', $capturedSql);
    }

    public function test_reset_attempts_is_cas_only_for_actually_parked_rows(): void
    {
        $capturedSql = '';
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with([901, 10])->andReturn(true);
        $stmt->shouldReceive('rowCount')->once()->andReturn(1);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->with(m::on(static function (string $sql) use (&$capturedSql): bool {
            $capturedSql = $sql;
            return true;
        }))->andReturn($stmt);

        $model = new CustomTaskSubmissionModel($db);
        $this->assertTrue($model->submission_resetAutoApproveAttempts(901));

        // فقط ردیفِ واقعاً پارک‌شده (submitted و attempts >= آستانه) صفر می‌شود
        $this->assertStringContainsString('auto_approve_attempts = 0', $capturedSql);
        $this->assertStringContainsString("status = 'submitted'", $capturedSql);
        $this->assertStringContainsString('auto_approve_attempts >= ?', $capturedSql);
    }

    public function test_reset_attempts_returns_false_when_row_was_not_parked(): void
    {
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->andReturn(true);
        $stmt->shouldReceive('rowCount')->once()->andReturn(0);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->andReturn($stmt);

        $model = new CustomTaskSubmissionModel($db);
        $this->assertFalse($model->submission_resetAutoApproveAttempts(902));
    }

    public function test_user_get_fraud_score_reads_int_and_defaults_to_zero(): void
    {
        // مقدار موجود → int
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with([21])->andReturn(true);
        $stmt->shouldReceive('fetchColumn')->once()->andReturn('85');

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->with(m::on(
            static fn(string $sql): bool => str_contains($sql, 'SELECT fraud_score FROM users')
        ))->andReturn($stmt);

        $model = new User($db);
        $this->assertSame(85, $model->getFraudScore(21));
    }

    public function test_user_get_fraud_score_missing_row_is_zero(): void
    {
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->andReturn(true);
        $stmt->shouldReceive('fetchColumn')->once()->andReturn(false);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->andReturn($stmt);

        $model = new User($db);
        $this->assertSame(0, $model->getFraudScore(999));
    }
}
