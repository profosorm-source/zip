<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\SeoExecution;
use App\Models\SeoLandingProofTest;
use Mockery as m;
use PDOStatement;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SEO-23-01 (فاز ۲ — اثبات فرود): قرارداد لایهٔ مدل.
 *
 * پوشش:
 *   SeoExecution::findByClickToken — نگاه با کلید توکن (ستون‌های تصمیم‌گیری)
 *   SeoExecution::verifyLandingProof — UPDATE اتمیک با گاردهای کامل:
 *     کلیکِ مهرشده + فرودِ تأییدنشده + پنجرهٔ زنده + تطابق توکن؛
 *     پس از موفقیت توکن پاک می‌شود (یک‌بارمصرف)؛ کانال فقط pixel|postback
 *   SeoLandingProofTest — چرخهٔ دکمهٔ تست: صدور/یافتن/مهر دریافت idempotent/وضعیت
 *
 * سبک خانه: Database با Mockery مک می‌شود — آینهٔ SeoClickProofTokenTest.
 */
final class SeoLandingProofModelTest extends TestCase
{
    /** @var \Core\Database&\Mockery\MockInterface */
    private \Core\Database $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock('Core\Database');
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    // ─────────────── findByClickToken ───────────────

    public function test_find_by_click_token_returns_decision_columns(): void
    {
        $stmt = m::mock(PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with(['abc123']);
        $stmt->shouldReceive('fetch')->once()->andReturn([
            'id' => 11, 'ad_id' => 1, 'user_id' => 2, 'status' => 'started',
            'click_counted_at' => '2026-11-02 10:00:00',
            'click_token_expires_at' => '2026-11-02 10:15:00',
            'landing_verified_at' => null,
        ]);
        $this->db->shouldReceive('prepare')->once()->with(m::on(
            static fn (string $sql): bool => str_contains($sql, 'FROM seo_executions WHERE click_token = ?')
        ))->andReturn($stmt);

        $row = (new SeoExecution($this->db))->findByClickToken('abc123');

        $this->assertIsArray($row);
        $this->assertSame(11, $row['id']);
        $this->assertSame('2026-11-02 10:00:00', $row['click_counted_at']);
    }

    public function test_find_by_click_token_rejects_empty_or_oversized_tokens(): void
    {
        $model = new SeoExecution($this->db);
        $this->db->shouldReceive('prepare')->never();
        $this->assertNull($model->findByClickToken(''));
        $this->assertNull($model->findByClickToken(str_repeat('a', 65)));
    }

    public function test_find_by_click_token_returns_null_when_missing(): void
    {
        $stmt = m::mock(PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with(['nope']);
        $stmt->shouldReceive('fetch')->once()->andReturn(false);
        $this->db->shouldReceive('prepare')->once()->andReturn($stmt);

        $this->assertNull((new SeoExecution($this->db))->findByClickToken('nope'));
    }

    // ─────────────── verifyLandingProof ───────────────

    public function test_verify_landing_proof_atomic_update_guards(): void
    {
        $stmt = m::mock(PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with(m::on(static function (array $args): bool {
            // [channel, id, token]
            return $args[0] === 'pixel' && $args[1] === 11 && $args[2] === 'tok48';
        }))->andReturn(true);
        $stmt->shouldReceive('rowCount')->once()->andReturn(1);
        $this->db->shouldReceive('prepare')->once()->with(m::on(static function (string $sql): bool {
            // گاردهای کامل: توکن + کلیک مهرشده + فرود تأییدنشده + پنجرهٔ زنده؛
            // و پاک‌سازی توکن (یک‌بارمصرف) + ثبت کانال
            return str_contains($sql, 'landing_verified_at = NOW()')
                && str_contains($sql, 'landing_proof_channel = ?')
                && str_contains($sql, 'click_token = NULL')
                && str_contains($sql, 'click_counted_at IS NOT NULL')
                && str_contains($sql, 'landing_verified_at IS NULL')
                && str_contains($sql, 'click_token_expires_at > NOW()')
                && str_contains($sql, 'click_token = ?');
        }))->andReturn($stmt);

        $this->assertTrue((new SeoExecution($this->db))->verifyLandingProof(11, 'tok48', 'pixel'));
    }

    public function test_verify_landing_proof_fails_on_race_or_replay(): void
    {
        $stmt = m::mock(PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->andReturn(true);
        $stmt->shouldReceive('rowCount')->once()->andReturn(0);
        $this->db->shouldReceive('prepare')->once()->andReturn($stmt);

        $this->assertFalse((new SeoExecution($this->db))->verifyLandingProof(11, 'tok48', 'pixel'));
    }

    public function test_verify_landing_proof_rejects_unknown_channel(): void
    {
        $this->db->shouldReceive('prepare')->never();
        $this->assertFalse((new SeoExecution($this->db))->verifyLandingProof(11, 'tok48', 'email'));
    }

    // ─────────────── SeoLandingProofTest (دکمهٔ تست) ───────────────

    public function test_issue_creates_test_row_with_48hex_token_and_ttl(): void
    {
        $insert = m::mock(PDOStatement::class);
        $insert->shouldReceive('execute')->once()->with(m::on(static function (array $args): bool {
            return $args[0] === 5 // ad_id
                && is_string($args[1]) && preg_match('/^[0-9a-f]{48}$/', $args[1]) === 1
                && $args[2] === SeoLandingProofTest::TEST_TOKEN_TTL_SECONDS;
        }))->andReturn(true);
        $this->db->shouldReceive('prepare')->once()->with(m::on(
            static fn (string $sql): bool => str_contains($sql, 'INSERT INTO seo_landing_proof_tests')
        ))->andReturn($insert);

        $select = m::mock(PDOStatement::class);
        $select->shouldReceive('execute')->once();
        $select->shouldReceive('fetch')->once()->andReturn([
            'id' => 1, 'ad_id' => 5, 'token' => 'x', 'expires_at' => '2026-11-02 10:10:00',
            'received_at' => null, 'channel' => null, 'ip' => null,
        ]);
        $this->db->shouldReceive('prepare')->once()->with(m::on(
            static fn (string $sql): bool => str_contains($sql, 'FROM seo_landing_proof_tests WHERE token = ?')
        ))->andReturn($select);

        $issued = (new SeoLandingProofTest($this->db))->issue(5);

        $this->assertRegExp('/^[0-9a-f]{48}$/', $issued['token']);
        $this->assertSame('2026-11-02 10:10:00', $issued['expires_at']);
    }

    public function test_mark_received_is_idempotent_for_duplicate_hits(): void
    {
        // اولین مهر: UPDATE برنده
        $update = m::mock(PDOStatement::class);
        $update->shouldReceive('execute')->once()->andReturn(true);
        $update->shouldReceive('rowCount')->once()->andReturn(1);
        $this->db->shouldReceive('prepare')->once()->with(m::on(
            static fn (string $sql): bool => str_contains($sql, 'UPDATE seo_landing_proof_tests')
                && str_contains($sql, 'received_at IS NULL') && str_contains($sql, 'expires_at > NOW()')
        ))->andReturn($update);

        $this->assertTrue((new SeoLandingProofTest($this->db))->markReceived('tok', 'pixel', '1.2.3.4'));
    }

    public function test_mark_received_second_call_still_true_when_already_received(): void
    {
        // UPDATE برنده نمی‌شود (received قبلاً ست شده)
        $update = m::mock(PDOStatement::class);
        $update->shouldReceive('execute')->once()->andReturn(true);
        $update->shouldReceive('rowCount')->once()->andReturn(0);
        $this->db->shouldReceive('prepare')->once()->andReturn($update);

        $select = m::mock(PDOStatement::class);
        $select->shouldReceive('execute')->once();
        $select->shouldReceive('fetch')->once()->andReturn([
            'id' => 1, 'ad_id' => 5, 'token' => 'tok', 'expires_at' => '2026-11-02 10:10:00',
            'received_at' => '2026-11-02 10:05:00', 'channel' => 'pixel', 'ip' => '1.2.3.4',
        ]);
        $this->db->shouldReceive('prepare')->once()->andReturn($select);

        $this->assertTrue((new SeoLandingProofTest($this->db))->markReceived('tok', 'pixel', '1.2.3.4'));
    }

    public function test_status_for_reports_pending_expired_and_received(): void
    {
        $model = new SeoLandingProofTest($this->db);

        // ردیف ناشناخته
        $miss = m::mock(PDOStatement::class);
        $miss->shouldReceive('execute')->once();
        $miss->shouldReceive('fetch')->once()->andReturn(false);
        $this->db->shouldReceive('prepare')->once()->andReturn($miss);
        $s = $model->statusFor('ghost');
        $this->assertFalse($s['found']);
        $this->assertFalse($s['received']);

        // ردیف دریافت‌شده
        $hit = m::mock(PDOStatement::class);
        $hit->shouldReceive('execute')->once();
        $hit->shouldReceive('fetch')->once()->andReturn([
            'id' => 2, 'ad_id' => 5, 'token' => 't2', 'expires_at' => date('Y-m-d H:i:s', time() + 600),
            'received_at' => '2026-11-02 10:05:00', 'channel' => 'postback', 'ip' => '9.9.9.9',
        ]);
        $this->db->shouldReceive('prepare')->once()->andReturn($hit);
        $s = $model->statusFor('t2');
        $this->assertTrue($s['found']);
        $this->assertTrue($s['received']);
        $this->assertSame('postback', $s['channel']);

        // ردیف منقضی‌نشده
        $pending = m::mock(PDOStatement::class);
        $pending->shouldReceive('execute')->once();
        $pending->shouldReceive('fetch')->once()->andReturn([
            'id' => 3, 'ad_id' => 5, 'token' => 't3', 'expires_at' => date('Y-m-d H:i:s', time() + 300),
            'received_at' => null, 'channel' => null, 'ip' => null,
        ]);
        $this->db->shouldReceive('prepare')->once()->andReturn($pending);
        $s = $model->statusFor('t3');
        $this->assertTrue($s['found']);
        $this->assertFalse($s['received']);
        $this->assertFalse($s['expired']);
    }
}
