<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\Ads;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-T23-03 — رفتار واقعی (بدون بازرسی سورس) کوئری کاربر-محور فهرست سئو:
 *
 * بازگردانی قرارداد Q4/SEO-23-06 که در آشتی‌بندی نوامبر گم شده بود:
 *   • حذف آگهی خود کاربر
 *   • type=seo + status=active + is_active=1 + deleted_at IS NULL
 *   • remaining_budget ≥ حداقلِ یک پاداش (کمپین مرده دیده نمی‌شود)
 *   • مهلت معتبر (deadline NULL یا آینده)
 *   • مرتب‌سازی max_payout DESC (نه price_per_click همیشه‌صفر)
 * هم‌الگوی V22SweepAndProofOwnershipSqlTest — سبک خانه: Mockery + DB ساختگی.
 */
final class AdsSearchActiveSeoTasksForUserSqlTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    public function test_query_filters_own_ad_dead_campaign_and_expired_deadline(): void
    {
        $captured = ['items' => '', 'count' => ''];

        $db = m::mock(Database::class);
        $db->shouldReceive('fetchAll')->once()->with(m::on(static function (string $sql) use (&$captured): bool {
            $captured['items'] = $sql;
            return true;
        }), m::any())->andReturn([]);
        $db->shouldReceive('fetchColumn')->once()->with(m::on(static function (string $sql) use (&$captured): bool {
            $captured['count'] = $sql;
            return true;
        }), m::any())->andReturn(0);

        $model = new Ads($db);
        $result = $model->searchActiveSeoTasksForUser(42, '', 20, 0);

        self::assertSame(['items' => [], 'total' => 0], $result);
        $sql = $captured['items'];

        // آگهی خود کاربر حذف می‌شود
        self::assertStringContainsString('COALESCE(a.user_id, 0) <> ?', $sql);
        // کمپین مرده: بودجه باید دست‌کم یک حداقل‌پاداش بپردازد
        self::assertStringContainsString('COALESCE(a.remaining_budget, a.total_budget, 0) >= COALESCE(a.min_payout, a.price_per_click, 0)', $sql);
        // مهلت معتبر
        self::assertStringContainsString('(a.deadline IS NULL OR a.deadline > ?)', $sql);
        // وضعیت/نوع/حذف‌نرم
        self::assertStringContainsString("a.type = 'seo'", $sql);
        self::assertStringContainsString("a.status = 'active'", $sql);
        self::assertStringContainsString('a.is_active = 1', $sql);
        self::assertStringContainsString('a.deleted_at IS NULL', $sql);
        // مرتب‌سازی بر اساس بازهٔ پاداش واقعی (نه price_per_click همیشه‌صفر)
        self::assertStringContainsString('ORDER BY a.max_payout DESC, a.created_at DESC', $sql);
        // کوئری شمارش همان WHERE را می‌دهد (صفحه‌بندی صادقانه)
        self::assertStringContainsString('COALESCE(a.user_id, 0) <> ?', $captured['count']);
    }

    public function test_query_binds_search_like_and_clamps_limit(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('fetchAll')->once()->with(
            m::on(static fn(string $sql): bool => str_contains($sql, 'LIMIT 100 OFFSET 40')),
            m::on(static function (array $p): bool {
                // [userId, now, like, like, like] — جستجو در سه ستون
                return count($p) === 5 && $p[0] === 42 && $p[1] !== ''
                    && $p[2] === $p[3] && $p[3] === $p[4] && str_contains((string)$p[2], 'کفش');
            })
        )->andReturn([]);
        $db->shouldReceive('fetchColumn')->once()->with(m::any(), m::any())->andReturn(0);

        $model = new Ads($db);
        // limit=500 → clamp به 100 (سقف امن like searchAdminTasks)
        $result = $model->searchActiveSeoTasksForUser(42, 'کفش', 500, 40);

        self::assertSame(['items' => [], 'total' => 0], $result);
    }

    public function test_negative_offset_is_clamped_to_zero(): void
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('fetchAll')->once()->with(
            m::on(static fn(string $sql): bool => str_contains($sql, 'LIMIT 20 OFFSET 0')),
            m::any()
        )->andReturn([]);
        $db->shouldReceive('fetchColumn')->once()->andReturn(0);

        $model = new Ads($db);
        $model->searchActiveSeoTasksForUser(1, '', 20, -99);
        $this->addToAssertionCount(1); // بدون خطا = clamp درست
    }
}
