<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use PHPUnit\Framework\TestCase;
use Mockery as m;
use Mockery\MockInterface;
use Core\Database;
use App\Models\LotteryChanceLog;

/**
 * FIX-R36-W3 (F-A6b-07) + (F-A6b-05):
 *  - LotteryChanceLog::create must persist the real `details` column (audit evidence of the
 *    vote match produced by UpdateLotteryChanceScoresJob) instead of silently dropping it;
 *  - existsForParticipationDate is the processed marker for the (round,date) idempotency of
 *    the chance-score job.
 */
class LotteryChanceLogW3DTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    private function makeModelWithCapturedInsert(MockInterface $db, array &$captured, string $lastInsertId = '5'): LotteryChanceLog
    {
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')
            ->once()
            ->andReturnUsing(function (array $params) use (&$captured) {
                // keep the captured SQL alongside the bound params (numeric keys + 'sql')
                $captured = $params + $captured;
                return true;
            });

        $db->shouldReceive('prepare')
            ->once()
            ->andReturnUsing(function (string $sql) use ($stmt, &$captured) {
                $captured['sql'] = $sql;
                return $stmt;
            });
        $db->shouldReceive('lastInsertId')->andReturn($lastInsertId);

        return new LotteryChanceLog($db);
    }

    /** @test */
    public function create_persists_details_column(): void
    {
        $db = m::mock(Database::class);
        $captured = [];
        $model = $this->makeModelWithCapturedInsert($db, $captured);

        $id = $model->create([
            'participation_id' => 11,
            'user_id' => 22,
            'round_id' => 33,
            'date' => '2026-09-22',
            'score_before' => 1.0,
            'score_change' => 2.0,
            'score_after' => 3.0,
            'reason' => 'match_success',
            'details' => 'selected:7, matched:yes',
        ]);

        $this->assertSame(5, $id);
        $this->assertStringContainsString('`details`', (string)$captured['sql']);
        $detailsIndex = array_search('`details`', explode(',', substr((string)$captured['sql'], (int)strpos((string)$captured['sql'], '('))), true);
        $this->assertNotFalse($detailsIndex, 'details must be part of the column list');
        $this->assertContains('selected:7, matched:yes', $captured, 'the details value must be bound');
    }

    /** @test */
    public function create_without_details_still_persists_legacy_shape(): void
    {
        $db = m::mock(Database::class);
        $captured = [];
        $model = $this->makeModelWithCapturedInsert($db, $captured);

        $id = $model->create([
            'participation_id' => 11,
            'user_id' => 22,
            'reason' => 'no_vote',
        ]);

        $this->assertSame(5, $id);
        $this->assertStringNotContainsString('`details`', (string)$captured['sql']);
        $this->assertStringContainsString('`created_at`', (string)$captured['sql']);
    }

    /** @test */
    public function exists_for_participation_date_detects_processed_marker(): void
    {
        $db = m::mock(Database::class);

        $stmtHit = m::mock(\PDOStatement::class);
        $stmtHit->shouldReceive('execute')->once();
        $stmtHit->shouldReceive('fetchColumn')->once()->andReturn('1');

        $stmtMiss = m::mock(\PDOStatement::class);
        $stmtMiss->shouldReceive('execute')->once();
        $stmtMiss->shouldReceive('fetchColumn')->once()->andReturn(false);

        $sqlSeen = [];
        $db->shouldReceive('prepare')
            ->twice()
            ->andReturnUsing(function (string $sql) use (&$sqlSeen, $stmtHit, $stmtMiss) {
                $sqlSeen[] = $sql;
                return count($sqlSeen) === 1 ? $stmtHit : $stmtMiss;
            });

        $model = new LotteryChanceLog($db);

        $this->assertTrue($model->existsForParticipationDate(11, '2026-09-22'));
        $this->assertFalse($model->existsForParticipationDate(11, '2026-09-23'));

        $this->assertStringContainsString('participation_id = ?', (string)$sqlSeen[0]);
        $this->assertStringContainsString('date = ?', (string)$sqlSeen[0]);
    }
}
