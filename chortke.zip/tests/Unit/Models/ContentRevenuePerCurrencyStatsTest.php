<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\ContentRevenue;
use Core\Container;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-Q4-MOD24-09 — قرارداد آمار مالی per-currency درآمد محتوا.
 *
 * گزارش بخش ۲۴: getFinancialStats همهٔ ردیف‌ها را بدون GROUP BY currency جمع
 * می‌زد (اختلاط تومان/تتر در کارت‌های پنل) و total_user_paid مبنای اشتباه
 * (جمع net در همهٔ وضعیت‌ها حتی cancelled) داشت.
 *
 * قرارداد جدید (هم‌الگوی CY3):
 *  • کلیدهای سطح‌بالا = جمع صادقانهٔ IRT (بدون ردیف IRT ⇒ صفرِ واقعی).
 *  • per_currency = نقشهٔ کامل irt/usdt.
 *  • paid_amount فقط ردیف‌های status=paid؛ pending/cancelled اثر ندارند.
 *  • total_user_paid دیگر وجود ندارد (کلید گمراه‌کننده حذف شد).
 */
final class ContentRevenuePerCurrencyStatsTest extends TestCase
{
    private Database $db;
    private ContentRevenue $model;
    private string $tag;
    private int $userId;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->model = Container::getInstance()->make(ContentRevenue::class);
        $this->tag = 'q4r' . bin2hex(random_bytes(4));

        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["q4rev-{$this->tag}", "q4rev-{$this->tag}@example.test", 'active', 'user'],
        );
        $this->userId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM content_revenues WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM users WHERE id = ?', [$this->userId]);
        parent::tearDown();
    }

    /** @param array<string, mixed> $overrides */
    private function seedRevenue(string $currency, string $status, string $total, string $net, array $overrides = []): void
    {
        $fields = array_merge([
            'user_id' => $this->userId,
            'submission_id' => 999000,
            'period' => '1405-08',
            'total_revenue' => $total,
            'site_share_percent' => '40.00',
            'site_share_amount' => '1.00',
            'user_share_percent' => '60.00',
            'user_share_amount' => '2.00',
            'tax_percent' => '9.00',
            'tax_amount' => '0.10',
            'net_user_amount' => $net,
            'status' => $status,
            'currency' => $currency,
            'is_deleted' => 0,
        ], $overrides);
        $cols = implode(',', array_keys($fields));
        $marks = implode(',', array_fill(0, count($fields), '?'));
        $this->db->query(
            "INSERT INTO content_revenues ({$cols}, created_at, updated_at) VALUES ({$marks}, NOW(), NOW())",
            array_values($fields),
        );
    }

    public function test_stats_group_by_currency_and_paid_only(): void
    {
        // IRT: یک paid + یک pending
        $this->seedRevenue('irt', 'paid', '1000', '500', ['site_share_amount' => '400.00', 'submission_id' => 999001]);
        $this->seedRevenue('irt', 'pending', '200', '100', ['site_share_amount' => '80.00', 'submission_id' => 999002]);
        // USDT: یک paid کسری + یک cancelled (نباید در paid شمرده شود)
        $this->seedRevenue('usdt', 'paid', '0.5', '0.27', ['site_share_amount' => '0.20000000', 'period' => '1405-09', 'submission_id' => 999003]);
        $this->seedRevenue('usdt', 'cancelled', '0.3', '0.16', ['site_share_amount' => '0.12000000', 'period' => '1405-10', 'submission_id' => 999004]);

        $stats = $this->model->getFinancialStats();

        // سطح‌بالا = جمع صادقانهٔ IRT — نه اختلاط با تتر
        $this->assertSame(2, $stats->total_records);
        $this->assertEqualsWithDelta(1200.0, (float)$stats->total_revenue, 0.0001);
        $this->assertEqualsWithDelta(500.0, (float)$stats->paid_amount, 0.0001, 'paid فقط ردیف‌های paid');
        $this->assertEqualsWithDelta(100.0, (float)$stats->pending_amount, 0.0001);

        // per_currency — هر دو ارز کامل
        $this->assertObjectHasAttribute('per_currency', $stats);
        $per = $stats->per_currency;
        $this->assertArrayHasKey('irt', $per);
        $this->assertArrayHasKey('usdt', $per);
        $this->assertSame(2, $per['irt']->total_records);
        $this->assertEqualsWithDelta(500.0, (float)$per['irt']->paid_amount, 0.0001);
        $this->assertSame(2, $per['usdt']->total_records);
        $this->assertEqualsWithDelta(0.27, (float)$per['usdt']->paid_amount, 0.0001, 'cancelled نباید در paidِ تتر بیاید');

        // کلید گمراه‌کنندهٔ قبلی حذف شده است
        $this->assertObjectNotHasAttribute('total_user_paid', $stats, 'total_user_paid (مبنای اشتباه: همهٔ وضعیت‌ها) حذف شد — MOD24-09');
    }

    public function test_stats_without_irt_rows_top_level_is_honest_zero(): void
    {
        // فقط تتر — سطح‌بالا باید صفرِ صادقانه باشد نه عدد مخلوط
        $this->seedRevenue('usdt', 'paid', '5.5', '3.3', ['site_share_amount' => '2.20000000', 'submission_id' => 999005]);

        $stats = $this->model->getFinancialStats();
        $this->assertSame(0, $stats->total_records, 'سطح‌بالا فقط IRT است؛ ردیف IRT نیست ⇒ صفر');
        $this->assertEqualsWithDelta(0.0, (float)$stats->total_revenue, 0.0001);
        $this->assertEqualsWithDelta(3.3, (float)$stats->per_currency['usdt']->paid_amount, 0.0001);
    }

    public function test_deleted_rows_are_excluded(): void
    {
        $this->seedRevenue('irt', 'paid', '1000', '500', ['site_share_amount' => '400.00', 'submission_id' => 999001]);
        $this->seedRevenue('irt', 'paid', '999', '499', ['site_share_amount' => '399.00', 'is_deleted' => 1, 'period' => '1405-09', 'submission_id' => 999006]);

        $stats = $this->model->getFinancialStats();
        $this->assertSame(1, $stats->total_records, 'ردیف حذف‌شده (is_deleted=1) نباید شمرده شود');
        $this->assertEqualsWithDelta(1000.0, (float)$stats->total_revenue, 0.0001);
    }
}
