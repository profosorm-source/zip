<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\ActivityLog;
use App\Models\Ads;
use App\Models\DirectMessage;
use App\Models\EmailQueue;
use App\Models\Notification;
use App\Models\Score;
use App\Services\EmailDeliveryStore;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * W2-C1 — قفل‌کنندهٔ همگرایی اسکیمای Models (موج رفع ۲ ممیزی R36).
 *
 * پین‌کردن ۶ یافتهٔ دامنهٔ Models/Schema:
 *  ① F-A19a-01 — Ads::$fillable هفت ستون زندهٔ مسیرهای کانونیِ ایجاد آگهی را
 *     دارد (restrictions/proof_schema/sample_image/auto_approve_hours/
 *     country_restriction/os_restriction/reject_rules) → filterFillable
 *     دیگر هیچ کلید مسیرِ create را ساکت نمی‌ریزد.
 *  ② F-A2-05 — Ads::$fillable کلید شبح «reward» را ندارد (reward مالِ
 *     social_ads است نه ads) + هیچ کلیدی از fillable در جدول زنده نیست.
 *  ③ F-A2-06 — کلیدهای شبح ActivityLog.user_agent / Score.meta / Score.source /
 *     DirectMessage.attachments از fillableها حذف و با معادل‌های واقعی
 *     (reason/metadata) جایگزین شدند.
 *  ④ F-A2-04 — پنج متد مردهٔ EmailQueue (markAsSent/markAsFailed/cleanOldSent/
 *     archiveOldSent/retryAllFailed با ستون‌های شبح sent_at/error_message/
 *     is_archived/archived_at) حذف شدند؛ پایپ‌لاین زندهٔ EmailDeliveryStore
 *     دست‌نخورده مانده است.
 *  ⑤ F-A2-03 — Notification::logHistory فقط ستون‌های واقعیِ notification_history
 *     را درج می‌کند (channel_id/status/sent_at/error_message) — پیلودِ ثبت
 *     زیرمجموعهٔ ستون‌های زنده است؛ امضای ۵-پارامتری (قرارداد
 *     LogNotificationAdapter::sendAlert) دست‌نخورده.
 *  ⑥ گشت سراسری جهتِ fillable→جدول برای هر ۶ مدل — هیچ کلید شبحی باقی نیست.
 *
 * سبک خانه: Database با Mockery مک می‌شود؛ اسکیمای زنده فقط
 * SELECT/SHOW (information_schema) خوانده می‌شود — صفر نوشتار روی DB.
 */
final class W2C1ModelsSchemaConvergenceTest extends TestCase
{
    /** @var \PDO */
    private \PDO $pdo;

    protected function setUp(): void
    {
        parent::setUp();
        $this->pdo = Database::getInstance()->getPdo();
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** نقشهٔ ستون‌های زندهٔ یک جدول (فقط-خواندنی، information_schema) */
    /** @return array<string, bool> */
    private function liveColumns(string $table): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT column_name FROM information_schema.COLUMNS
             WHERE table_schema = DATABASE() AND table_name = ?'
        );
        $stmt->execute([$table]);
        $cols = [];
        foreach ((array) $stmt->fetchAll(\PDO::FETCH_COLUMN) as $c) {
            $cols[(string) $c] = true;
        }
        self::assertNotEmpty($cols, "live table {$table} must exist");
        return $cols;
    }

    /** خواندن protected $fillable بدون لمس DB */
    /** @return list<string> */
    private function fillableOf(string $model): array
    {
        $rp = new \ReflectionProperty($model, 'fillable');
        $rp->setAccessible(true);
        /** @var list<string> $f */
        $f = $rp->getValue(new $model(m::mock('Core\Database')));
        return $f;
    }

    // ─────────────────────────────────────────────────────────────
    // ① ② F-A19a-01 + F-A2-05 — Ads
    // ─────────────────────────────────────────────────────────────

    public function test_ads_fillable_has_no_ghost_keys_against_live_table(): void
    {
        $live   = $this->liveColumns('ads');
        $ghost  = array_diff($this->fillableOf(Ads::class), array_keys($live));

        self::assertSame(
            [],
            array_values($ghost),
            'Ads::$fillable must only contain live ads columns (F-A2-05: reward removed)'
        );
    }

    public function test_ads_fillable_covers_seven_canonical_creation_columns(): void
    {
        $fillable = array_flip($this->fillableOf(Ads::class));

        foreach ([
            'restrictions', 'proof_schema', 'sample_image', 'auto_approve_hours',
            'country_restriction', 'os_restriction', 'reject_rules',
        ] as $col) {
            self::assertArrayHasKey(
                $col,
                $fillable,
                "Ads::\$fillable must include live column {$col} (F-A19a-01 — canonical ad-creation path)"
            );
        }
    }

    public function test_ads_fillable_no_longer_contains_reward_ghost(): void
    {
        self::assertNotContains('reward', $this->fillableOf(Ads::class), 'reward belongs to social_ads, not ads');
        $live = $this->liveColumns('ads');
        self::assertArrayNotHasKey('reward', $live, 'live ads must not gain reward (direction pinned)');
    }

    // ─────────────────────────────────────────────────────────────
    // ③ F-A2-06 — ActivityLog / Score / DirectMessage
    // ─────────────────────────────────────────────────────────────

    public function test_activity_log_fillable_drops_user_agent_ghost(): void
    {
        $fillable = $this->fillableOf(ActivityLog::class);

        self::assertNotContains('user_agent', $fillable);
        self::assertSame([], array_values(array_diff($fillable, array_keys($this->liveColumns('activity_logs')))));
    }

    public function test_score_fillable_uses_reason_metadata_instead_of_meta_source(): void
    {
        $fillable = $this->fillableOf(Score::class);

        self::assertNotContains('meta', $fillable);
        self::assertNotContains('source', $fillable);
        self::assertContains('reason', $fillable);
        self::assertContains('metadata', $fillable);
        self::assertSame([], array_values(array_diff($fillable, array_keys($this->liveColumns('score_events')))));
    }

    public function test_direct_message_fillable_drops_attachments_ghost(): void
    {
        $fillable = $this->fillableOf(DirectMessage::class);

        self::assertNotContains('attachments', $fillable);
        self::assertSame([], array_values(array_diff($fillable, array_keys($this->liveColumns('direct_messages')))));
    }

    // ─────────────────────────────────────────────────────────────
    // ④ F-A2-04 — EmailQueue dead methods + live pipeline intact
    // ─────────────────────────────────────────────────────────────

    public function test_email_queue_ghost_column_methods_are_deleted(): void
    {
        foreach (['markAsSent', 'markAsFailed', 'cleanOldSent', 'archiveOldSent', 'retryAllFailed'] as $method) {
            self::assertFalse(
                method_exists(EmailQueue::class, $method),
                "EmailQueue::{$method} referenced ghost columns and must stay deleted (F-A2-04)"
            );
        }
    }

    public function test_email_queue_live_pipeline_store_still_owns_the_lifecycle(): void
    {
        foreach (['markAsSent', 'markAsFailed', 'retryAllFailed', 'retryEmail'] as $method) {
            self::assertTrue(
                method_exists(EmailDeliveryStore::class, $method),
                "EmailDeliveryStore::{$method} is the live pipeline and must remain intact"
            );
        }
        // متدهای باقی‌ماندهٔ مدل (مصرف‌کنندگان زندهٔ StatusController/EmailService)
        foreach (['countPendingOrSending', 'markAsSending', 'retryById', 'getStats'] as $method) {
            self::assertTrue(method_exists(EmailQueue::class, $method));
        }
    }

    public function test_email_queue_table_never_had_the_ghost_columns(): void
    {
        $live = $this->liveColumns('email_queue');

        foreach (['sent_at', 'error_message', 'is_archived', 'archived_at'] as $ghost) {
            self::assertArrayNotHasKey($ghost, $live, "email_queue.{$ghost} never existed — provenance of F-A2-04");
        }
        foreach (['status', 'attempts', 'last_error', 'updated_at'] as $real) {
            self::assertArrayHasKey($real, $live);
        }
    }

    // ─────────────────────────────────────────────────────────────
    // ⑤ F-A2-03 — Notification::logHistory writes only live columns
    // ─────────────────────────────────────────────────────────────

    /** @return list<array{payload: array<string, mixed>}> */
    private function captureLogHistoryPayload(string $status): array
    {
        $captured = [];
        $qb = m::mock('Core\QueryBuilder');
        $qb->shouldReceive('insert')
            ->once()
            ->withArgs(function (array $payload) use (&$captured): bool {
                $captured[] = ['payload' => $payload];
                return true;
            })
            ->andReturnTrue();

        $db = m::mock('Core\Database');
        $db->shouldReceive('table')->once()->with('notification_history')->andReturn($qb);

        (new Notification($db))->logHistory(7, 'alert', 'T', 'M', $status);

        return $captured;
    }

    public function test_log_history_payload_is_subset_of_live_notification_history_columns(): void
    {
        $live = $this->liveColumns('notification_history');

        foreach (['sent', 'failed'] as $status) {
            foreach ($this->captureLogHistoryPayload($status) as $run) {
                self::assertSame(
                    [],
                    array_values(array_diff(array_keys($run['payload']), array_keys($live))),
                    "logHistory payload for status={$status} must target only live columns (F-A2-03)"
                );
            }
        }
    }

    public function test_log_history_maps_failed_delivery_body_to_error_message(): void
    {
        [$sent]   = $this->captureLogHistoryPayload('sent');
        [$failed] = $this->captureLogHistoryPayload('failed');

        self::assertSame(7, $sent['payload']['channel_id']);
        self::assertSame('sent', $sent['payload']['status']);
        self::assertNotSame(null, $sent['payload']['sent_at']);
        self::assertArrayNotHasKey('error_message', $sent['payload']);

        self::assertSame('failed', $failed['payload']['status']);
        self::assertNull($failed['payload']['sent_at']);
        self::assertSame('M', $failed['payload']['error_message'], 'failed body preserved as delivery-audit error_message');
        self::assertArrayNotHasKey('notification_type', $failed['payload']);
        self::assertArrayNotHasKey('title', $failed['payload']);
        self::assertArrayNotHasKey('message', $failed['payload']);
    }

    public function test_log_history_keeps_five_param_adapter_contract(): void
    {
        $rm = new \ReflectionMethod(Notification::class, 'logHistory');

        self::assertSame(5, $rm->getNumberOfParameters(), 'LogNotificationAdapter::sendAlert calls logHistory with 5 args');
        self::assertSame(
            ['channelId', 'type', 'title', 'message', 'status'],
            array_map(static fn (\ReflectionParameter $p): string => $p->getName(), $rm->getParameters())
        );
    }

    // ─────────────────────────────────────────────────────────────
    // ⑥ گشت سراسری — هیچ کلید شبحی در fillable هر ۶ مدل نیست
    // ─────────────────────────────────────────────────────────────

    public function test_all_six_w2c1_models_fillable_is_subset_of_live_schema(): void
    {
        $map = [
            Ads::class          => 'ads',
            ActivityLog::class  => 'activity_logs',
            Score::class        => 'score_events',
            DirectMessage::class => 'direct_messages',
            Notification::class => 'notifications',
        ];

        foreach ($map as $model => $table) {
            $ghost = array_diff($this->fillableOf($model), array_keys($this->liveColumns($table)));
            self::assertSame([], array_values($ghost), "{$model}::\$fillable must match live {$table}");
        }
        // EmailQueue خودش fillable تعریف نمی‌کند (SQL خام با سفیدلیست صریح؛
        // $fillable ارثیِ core/Model خالی است) — متدهایش در ④ پین شدند.
        $rp = new \ReflectionProperty(EmailQueue::class, 'fillable');
        $rp->setAccessible(true);
        self::assertNotSame(EmailQueue::class, $rp->getDeclaringClass()->getName());
        self::assertSame([], $rp->getValue(new EmailQueue(m::mock('Core\Database'))));
    }
}
