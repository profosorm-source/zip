<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\CustomTaskSubmissionModel;
use App\Models\FileAccess;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-V22 — رفتار واقعی (بدون بازرسی سورس) دو مسیر SQL بازنویسی‌شده:
 *
 *  ۱) CustomTaskSubmissionModel::getOldSubmissionsForAutoApproval (V22-03b/c/d):
 *     کوئری باید سه پارامتر بگیرد (سراسری ×۲ + سقف پارک) و گاردهای جدید را
 *     داشته باشد؛ ترتیب صف بر اساس attempts است.
 *  ۲) CustomTaskSubmissionModel::submission_incrementAutoApproveAttempts (V22-03c):
 *     افزایش اتمیک در SQL + بازگشت مقدار تازه.
 *  ۳) FileAccess::checkTaskProofOwnership (V22-04a): مقایسه روی ستون generated
 *     proof_file_basename (ایندکس‌پذیر) — نه SUBSTRING_INDEX در WHERE.
 */
final class V22SweepAndProofOwnershipSqlTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    public function test_auto_approval_query_binds_global_hours_twice_and_park_threshold(): void
    {
        $capturedSql = '';
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with(m::on(static function (array $p): bool {
            return count($p) === 3 && $p[0] === 48 && $p[1] === 48 && $p[2] === 10;
        }))->andReturn(true);
        $stmt->shouldReceive('fetchAll')->once()->andReturn([]);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->with(m::on(static function (string $sql) use (&$capturedSql): bool {
            $capturedSql = $sql;
            return true;
        }))->andReturn($stmt);

        $model = new CustomTaskSubmissionModel($db);
        $result = $model->getOldSubmissionsForAutoApproval(48);

        self::assertSame([], $result);
        // V22-03b: ساعت اختصاصی مستقل از سراسری + غیرممکن‌شدن INTERVAL صفر
        self::assertStringContainsString('AND COALESCE(ct.auto_approve_hours, ?) > 0', $capturedSql);
        self::assertStringContainsString('INTERVAL COALESCE(ct.auto_approve_hours, ?) HOUR', $capturedSql);
        // V22-03c: ضدگرسنگی
        self::assertStringContainsString('AND s.auto_approve_attempts < ?', $capturedSql);
        self::assertStringContainsString('ORDER BY s.auto_approve_attempts ASC, s.submitted_at ASC', $capturedSql);
        // V22-04c: خواهرِ approved/disputed همان مجری از کاندیدها حذف می‌شود
        self::assertStringContainsString("AND s2.status IN ('approved', 'disputed')", $capturedSql);
        // گارد اختلاف باز قبلی حفظ شده باشد (بدون بازگشت)
        self::assertStringContainsString("d.ref_type = 'custom_task_submission'", $capturedSql);
    }

    public function test_auto_approval_query_with_disabled_global_still_uses_per_task_hours(): void
    {
        // سراسری ۰ ⇒ پارامترهای فالبک ۰/۰: ردیف‌های بی‌ساعت با COALESCE(...,0)>0
        // حذف می‌شوند و INTERVAL تسک‌های دارای ساعت اختصاصی معنا دارد.
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with([0, 0, 10])->andReturn(true);
        $stmt->shouldReceive('fetchAll')->once()->andReturn([]);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->andReturn($stmt);

        $model = new CustomTaskSubmissionModel($db);
        self::assertSame([], $model->getOldSubmissionsForAutoApproval(0));
    }

    public function test_increment_attempts_is_atomic_update_then_reads_back(): void
    {
        $update = m::mock(\PDOStatement::class);
        $update->shouldReceive('execute')->once()->with([901])->andReturn(true);
        $select = m::mock(\PDOStatement::class);
        $select->shouldReceive('fetch')->once()->with(\PDO::FETCH_OBJ)->andReturn((object)['attempts' => 7]);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->with(m::on(
            static fn(string $sql): bool => str_contains($sql, 'auto_approve_attempts = auto_approve_attempts + 1')
        ))->andReturn($update);
        $db->shouldReceive('query')->once()->with(m::on(
            static fn(string $sql): bool => str_contains($sql, 'SELECT auto_approve_attempts')
        ), [901])->andReturn($select);

        $model = new CustomTaskSubmissionModel($db);
        self::assertSame(7, $model->submission_incrementAutoApproveAttempts(901));
    }

    public function test_increment_attempts_returns_zero_when_row_missing(): void
    {
        $update = m::mock(\PDOStatement::class);
        $update->shouldReceive('execute')->once()->andReturn(true);
        $select = m::mock(\PDOStatement::class);
        $select->shouldReceive('fetch')->once()->with(\PDO::FETCH_OBJ)->andReturn(false);

        $db = m::mock(Database::class);
        $db->shouldReceive('prepare')->once()->andReturn($update);
        $db->shouldReceive('query')->once()->andReturn($select);

        $model = new CustomTaskSubmissionModel($db);
        self::assertSame(0, $model->submission_incrementAutoApproveAttempts(999));
    }

    public function test_task_proof_ownership_compares_indexed_basename(): void
    {
        $capturedSql = '';
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('fetch')->once()->with(\PDO::FETCH_OBJ)->andReturn(
            (object)['worker_id' => 42, 'user_id' => 7]
        );

        $db = m::mock(Database::class);
        $db->shouldReceive('query')->once()->with(m::on(static function (string $sql) use (&$capturedSql): bool {
            $capturedSql = $sql;
            return true;
        }), ['abc123.jpg'])->andReturn($stmt);

        $access = new FileAccess($db);
        // مجریِ مدرک مالک است
        self::assertTrue($access->checkTaskProofOwnership('abc123.jpg', 42));

        // V22-04a: مقایسه روی ستون ایندکس‌پذیر generated — نه SUBSTRING_INDEX در WHERE
        self::assertStringContainsString('WHERE s.proof_file_basename = ?', $capturedSql);
        self::assertStringNotContainsString("SUBSTRING_INDEX(s.proof_file, '/', -1)", $capturedSql);
        // قرارداد مالکیت دوجانبه (مجری یا کارفرما) حفظ شده باشد
        self::assertStringContainsString('SELECT s.worker_id, a.user_id', $capturedSql);
    }

    public function test_task_proof_ownership_denies_stranger(): void
    {
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('fetch')->once()->with(\PDO::FETCH_OBJ)->andReturn(
            (object)['worker_id' => 42, 'user_id' => 7]
        );

        $db = m::mock(Database::class);
        $db->shouldReceive('query')->once()->andReturn($stmt);

        $access = new FileAccess($db);
        self::assertFalse($access->checkTaskProofOwnership('abc123.jpg', 999));
    }
}
