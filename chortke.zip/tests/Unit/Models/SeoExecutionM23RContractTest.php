<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Services\Seo\AdsSeoService;
use Core\Container;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-M23R — قراردادهای دیتابی اصلاح‌شده (بازبینی بخش ۲۳):
 *  • T23-02: countByAdToday «کل» اجراهای امروزِ آگهی (همهٔ کاربران،
 *    started/completed) را می‌شمارد — سقف واقعی max_per_day.
 *  • T23-06: rejectExecution فقط از started، slot_date را آزاد می‌کند و
 *    rowCount واقعی برمی‌گرداند (completed دیگر بازنویسی نمی‌شود؛ لغوی
 *    غیر-started «موفق» گزارش نمی‌شود؛ complete با CAS/rowCount صادق است).
 */
final class SeoExecutionM23RContractTest extends TestCase
{
    private Database $db;
    private \App\Models\SeoExecution $model;
    private AdsSeoService $service;
    private string $tag;
    /** @var list<int> */
    private array $userIds = [];
    private int $adId;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->model = Container::getInstance()->make(\App\Models\SeoExecution::class);
        $this->service = Container::getInstance()->make(AdsSeoService::class);
        $this->tag = 'm23r' . bin2hex(random_bytes(4));

        // دو کاربر مجری + یک تبلیغ‌دهنده
        foreach (['w1', 'w2'] as $k) {
            $this->db->query(
                'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
                ["m23r-{$k}-{$this->tag}", "m23r-{$k}-{$this->tag}@example.test", 'active', 'user'],
            );
            $this->userIds[] = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
        }
        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["m23r-adv-{$this->tag}", "m23r-adv-{$this->tag}@example.test", 'active', 'user'],
        );
        $advId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');

        $this->db->query(
            "INSERT INTO ads (user_id, title, type, status, is_active, budget, total_budget, remaining_budget, min_payout, max_payout, currency, max_per_day, created_at, updated_at)
             VALUES (?, ?, 'seo', 'active', 1, 100000, 100000, 100000, 1000, 5000, 'irt', 10, NOW(), NOW())",
            [$advId, "m23r-ad-{$this->tag}"],
        );
        $this->adId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM seo_executions WHERE ad_id = ?', [$this->adId]);
        foreach ($this->userIds as $uid) {
            $this->db->query('DELETE FROM seo_executions WHERE user_id = ?', [$uid]);
            $this->db->query('DELETE FROM users WHERE id = ?', [$uid]);
        }
        $row = $this->db->query('SELECT user_id FROM ads WHERE id = ?', [$this->adId])->fetch(\PDO::FETCH_OBJ);
        if ($row) {
            $this->db->query('DELETE FROM users WHERE id = ?', [(int)$row->user_id]);
        }
        $this->db->query('DELETE FROM ads WHERE id = ?', [$this->adId]);
        parent::tearDown();
    }

    /** @param array<string, mixed> $overrides */
    private function insertExecution(int $userId, string $status = 'started', array $overrides = []): int
    {
        $this->db->query(
            "INSERT INTO seo_executions
             (ad_id, user_id, status, ip_address, device_fingerprint, session_id, target_keyword, started_at, execution_date, slot_date, created_at)
             VALUES (?, ?, ?, '10.0.0.9', 'fp', ?, 'm23r', NOW(), CURDATE(), ?, NOW())",
            [
                $overrides['ad_id'] ?? $this->adId,
                $userId,
                $status,
                'sess-' . bin2hex(random_bytes(4)),
                in_array($status, ['started', 'completed'], true) ? date('Y-m-d') : null,
            ],
        );
        return (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    /** T23-02: شمارش کمپین‌محور — همهٔ کاربران، فقط وضعیت‌های اشغال‌کننده */
    public function test_count_by_ad_today_is_campaign_wide(): void
    {
        $w1 = $this->userIds[0];
        $w2 = $this->userIds[1];

        $this->insertExecution($w1, 'started');      // کاربر ۱ — امروز
        $this->insertExecution($w2, 'completed');    // کاربر ۲ — امروز
        $this->insertExecution($w1, 'cancelled');    // باطل — شمرده نمی‌شود
        $this->insertExecution($w2, 'fraud');        // باطل — شمرده نمی‌شود

        $this->assertSame(2, $this->model->countByAdToday($this->adId));
        // شمارش per-user جدا هست و فقط کاربر خودش را می‌شمارد (قرارداد Q4 پابرجا)
        $this->assertSame(1, $this->model->countByAdAndUserToday($this->adId, $w1));
        $this->assertSame(1, $this->model->countByAdAndUserToday($this->adId, $w2));
    }

    /** T23-06: reject سرویس گاردِ started دارد — completed/paid بازنویسی نمی‌شود */
    public function test_service_reject_cannot_overwrite_completed(): void
    {
        $w1 = $this->userIds[0];
        $completedId = $this->insertExecution($w1, 'completed');

        $this->assertFalse(
            $this->service->rejectExecution($completedId, 'تست M23R: رد اجرای تکمیل‌شده'),
            'reject روی ردیف completed باید false بدهد (گارد وضعیت)',
        );
        $row = $this->db->query('SELECT status FROM seo_executions WHERE id = ?', [$completedId])->fetch(\PDO::FETCH_OBJ);
        $this->assertSame('completed', $row->status, 'وضعیت completed نباید بازنویسی شود');
    }

    /** T23-06: reject سرویس slot_date را آزاد می‌کند — شروع مجدد همان روز ممکن است */
    public function test_service_reject_releases_daily_slot(): void
    {
        $w1 = $this->userIds[0];
        $execId = $this->insertExecution($w1, 'started');

        $this->assertTrue($this->service->rejectExecution($execId, 'امتیاز کمتر از حد مجاز (40)'));
        $row = $this->db->query('SELECT status, slot_date FROM seo_executions WHERE id = ?', [$execId])->fetch(\PDO::FETCH_OBJ);
        $this->assertSame('rejected', $row->status);
        $this->assertNull($row->slot_date, 'رد باید جایگاه روز (slot_date) را آزاد کند — هم‌سیاست cancel/fraud');

        // شروع مجدد همان روز نباید به UNIQUE(slot_date) بخورد
        $retry = $this->model->createExecution([
            'ad_id' => $this->adId,
            'user_id' => $w1,
            'ip_address' => '10.0.0.9',
            'target_keyword' => 'm23r',
        ]);
        $this->assertNotNull($retry, 'پس از رد، شروع مجدد همان آگهی در همان روز باید ممکن باشد');
    }

    /** T23-06: لغوی ردیف غیر-started دیگر «موفق» گزارش نمی‌شود */
    public function test_service_cancel_returns_false_for_non_started(): void
    {
        $w1 = $this->userIds[0];
        $completedId = $this->insertExecution($w1, 'completed');

        $this->assertFalse($this->service->cancelExecution($completedId, 'تست: لغوی ردیف تکمیل‌شده'));
    }

    /** T23-06: complete با CAS/rowCount صادق است — تکمیل دوباره false می‌دهد */
    public function test_model_complete_is_rowcount_aware(): void
    {
        $w1 = $this->userIds[0];
        $execId = $this->insertExecution($w1, 'started');

        $scores = [
            'time_score' => 20, 'scroll_score' => 18, 'interaction_score' => 15,
            'quality_score' => 16, 'final_score' => 69, 'fraud_score' => 0,
            'fraud_flags' => [],
            'engagement_data' => ['duration' => 60, 'scroll_depth' => 80, 'interactions' => 3, 'client_mode' => 'web'],
        ];

        $this->assertTrue($this->model->complete($execId, $scores, '1000'));
        // تکمیل دوباره: ردیف دیگر started نیست ⇒ false (نه trueٔ همیشگی قبل)
        $this->assertFalse($this->model->complete($execId, $scores, '1000'));
    }
}
