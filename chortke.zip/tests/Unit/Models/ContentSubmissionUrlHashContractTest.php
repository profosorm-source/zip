<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\ContentSubmission;
use Core\Container;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-Q4-MOD24-05/06/16 — قرارداد DB هش URL و طول کاراکتری.
 *
 * ۱) create() باید url_hash نرمال‌شده بنویسد (ستون جدید؛ UNIQUE).
 * ۲) isUrlExists با «لینک متفاوتِ همان ویدیو» هم true بدهد (نرمال‌سازی).
 * ۳) ردیف rejected (url_hash=NULL) لینک را برای ارسال مجدد آزاد کند (MOD24-06).
 * ۴) UNIQUE(url_hash) رقابت دو INSERT هم‌زمان را در سطح DB ببندد (1062).
 * ۵) عنوان ۱۵۰ کاراکتری فارسی از MAX_TITLE_LENGTH=255 رد شود (mb_strlen — MOD24-16).
 */
final class ContentSubmissionUrlHashContractTest extends TestCase
{
    private Database $db;
    private ContentSubmission $model;
    private string $tag;
    private int $userId;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->model = Container::getInstance()->make(ContentSubmission::class);
        $this->tag = 'q4h' . bin2hex(random_bytes(4));

        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["q4-{$this->tag}", "q4-{$this->tag}@example.test", 'active', 'user'],
        );
        $this->userId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    protected function tearDown(): void
    {
        // پاکسازی جراحی — فقط ردیف‌های همین اجرا
        $this->db->query(
            'DELETE FROM content_submissions WHERE user_id = ?',
            [$this->userId],
        );
        $this->db->query(
            'DELETE FROM users WHERE id = ?',
            [$this->userId],
        );
        parent::tearDown();
    }

    /** @param array<string, mixed> $overrides */
    private function createSubmission(string $videoUrl, array $overrides = []): int
    {
        $id = $this->model->create(array_merge([
            'user_id' => $this->userId,
            'platform' => 'youtube',
            'video_url' => $videoUrl,
            'title' => 'تست Q4',
            'agreement_accepted' => 1,
        ], $overrides));
        $this->assertIsInt($id);
        $this->assertGreaterThan(0, $id);
        return $id;
    }

    public function test_create_writes_normalized_url_hash(): void
    {
        $id = $this->createSubmission('https://www.youtube.com/watch?v=Q4videoA&t=15');
        $row = $this->db->query(
            'SELECT url_hash, platform, video_url FROM content_submissions WHERE id = ?',
            [$id],
        )->fetch(\PDO::FETCH_OBJ);

        $this->assertNotNull($row->url_hash, 'create باید url_hash بنویسد');
        $this->assertSame(
            ContentSubmission::hashVideoUrl('youtube', 'https://youtu.be/Q4videoA'),
            (string)$row->url_hash,
            'هش ذخیره‌شده باید نرمال باشد (لینک متفاوتِ همان ویدیو ≡ همان هش)',
        );
    }

    public function test_is_url_exists_matches_link_variants_of_same_video(): void
    {
        $this->createSubmission('https://youtu.be/Q4videoB');
        // شکل دیگرِ همان ویدیو — قبلاً تطابق دقیق بود و رد می‌شد
        $this->assertTrue(
            $this->model->isUrlExists('https://www.youtube.com/watch?v=Q4videoB&list=x', null, 'youtube'),
            'لینک متفاوتِ همان ویدیو باید تکراری تشخیص داده شود',
        );
        // ویدیوی دیگر
        $this->assertFalse($this->model->isUrlExists('https://youtu.be/Q4videoOTHER', null, 'youtube'));
    }

    public function test_rejected_row_frees_url_for_resubmission(): void
    {
        $id = $this->createSubmission('https://youtu.be/Q4videoC');
        $this->assertTrue(
            $this->model->isUrlExists('https://youtu.be/Q4videoC', null, 'youtube'),
        );

        // رد (شبیه rejectSubmission: url_hash → NULL)
        $this->db->query(
            "UPDATE content_submissions SET status = 'rejected', url_hash = NULL WHERE id = ?",
            [$id],
        );

        $this->assertFalse(
            $this->model->isUrlExists('https://youtu.be/Q4videoC', null, 'youtube'),
            'رد با دلیل قابل‌رفع باید لینک را برای ارسال مجدد آزاد کند (MOD24-06)',
        );
    }

    public function test_unique_index_blocks_duplicate_concurrent_insert(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger خطای DB در تست
        $this->createSubmission('https://youtu.be/Q4videoD');

        try {
            // ارسال هم‌زمانِ همان ویدیو توسط کاربر دیگر — UNIQUE باید بگیرد
            $this->db->query(
                'INSERT INTO content_submissions
                 (user_id, platform, video_url, url, url_hash, title, status, is_deleted, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW(), NOW())',
                [
                    $this->userId + 1000000,
                    'youtube',
                    'https://www.youtube.com/watch?v=Q4videoD',
                    'https://www.youtube.com/watch?v=Q4videoD',
                    ContentSubmission::hashVideoUrl('youtube', 'https://youtu.be/Q4videoD'),
                    'تقلب هم‌زمان',
                    'pending',
                ],
            );
            $this->fail('UNIQUE(url_hash) باید ردیف تکراری را بگیرد');
        } catch (\PDOException $e) {
            $this->assertSame('23000', (string)$e->getCode(), 'خطا باید نقض قید یکتایی باشد');
            $this->assertContains((string)($e->errorInfo[1] ?? ''), ['1062', '1586']);
        }
    }

    public function test_persian_title_150_chars_passes_char_limit(): void
    {
        // ۱۵۰ کاراکتر فارسی = ۴۵۰ بایت — strlen قبلاً رد می‌کرد؛ mb_strlen می‌پذیرد
        $longTitle = str_repeat('ت', 150);
        $id = $this->createSubmission('https://youtu.be/Q4videoE', ['title' => $longTitle]);
        $this->assertGreaterThan(0, $id, 'عنوان ۱۵۰ کاراکتری فارسی باید پذیرفته شود (MOD24-16)');

        // مرز واقعی: ۲۵۶ کاراکتر همچنان رد می‌شود
        $this->expectException(\InvalidArgumentException::class);
        $this->createSubmission('https://youtu.be/Q4videoF', ['title' => str_repeat('ت', 256)]);
    }
}
