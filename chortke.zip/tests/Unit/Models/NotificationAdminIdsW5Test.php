<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use PHPUnit\Framework\TestCase;
use Mockery as m;
use Mockery\MockInterface;
use Core\Database;
use App\Models\Notification;

/**
 * FIX-R36-W5: پینِ قراردادِ Notification::getAdminUsersIds()
 * (رفع W3 برای F-A19b-06): هر دو نقشِ مدیریتی (admin + super_admin) هدف‌اند —
 * enum زندهٔ users.role = user/support/admin/super_admin. رگرسیون به
 * role='admin' تنها، super_admin را بی‌صدا از فن‌اوتِ
 * SendToAdminsNotificationJob و هشدارهای نزاع (DisputeListener) حذف می‌کرد.
 */
class NotificationAdminIdsW5Test extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function admin_ids_target_both_management_roles(): void
    {
        $db = m::mock(Database::class);

        $builder = m::mock(\Core\QueryBuilder::class);
        $builder->shouldReceive('select')->once()->with('id')->andReturnSelf();
        $builder->shouldReceive('whereNull')->once()->with('deleted_at')->andReturnSelf();
        $builder->shouldReceive('whereIn')->once()->with('role', m::on(
            static fn (array $roles): bool => $roles === ['admin', 'super_admin']
        ))->andReturnSelf();
        $builder->shouldReceive('get')->once()->andReturn([
            ['id' => 7], ['id' => 9], ['id' => 11],
        ]);

        $db->shouldReceive('table')->once()->with('users')->andReturn($builder);

        $model = new Notification($db);

        $ids = $model->getAdminUsersIds();

        $this->assertSame([7, 9, 11], $ids);
    }

    /** @test */
    public function admin_ids_never_accept_single_role_filter(): void
    {
        // گارد رگرسیون: اگر کد به role='admin' تنها برگردد، whereIn با لیست
        // تک‌عضوی فراخوانی می‌شود و Mockery انتظارِ لیست دوعضوی را نقض می‌کند.
        $db = m::mock(Database::class);

        $builder = m::mock(\Core\QueryBuilder::class);
        $builder->shouldReceive('select')->andReturnSelf();
        $builder->shouldReceive('whereNull')->andReturnSelf();
        $builder->shouldReceive('whereIn')->once()->with('role', ['admin', 'super_admin'])->andReturnSelf();
        $builder->shouldReceive('get')->andReturn([]);

        $db->shouldReceive('table')->andReturn($builder);

        $model = new Notification($db);

        $this->assertSame([], $model->getAdminUsersIds());
    }
}
