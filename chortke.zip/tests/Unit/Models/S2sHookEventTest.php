<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use PHPUnit\Framework\TestCase;
use App\Models\S2sHookEvent;
use Core\Container;
use Core\Database;

/**
 * 🛡️ X374 (راند ۹۳) — تست لجر KPI وب‌هوک S2S
 *
 * record() + درستیِ تجمیع networkStats/overallStats + ترتیب recent().
 * شبکه‌های فیکسچر با نام per-run یکتا ساخته می‌شوند تا از دادهٔ واقعی/پراب‌ها
 * (تپسل/آدموب و...) تفکیک بمانند و بین چرخه‌ها آلودگی رخ ندهد (درس راند ۹۲).
 */
class S2sHookEventTest extends TestCase
{
    private Database $db;
    private S2sHookEvent $model;
    private string $netA;
    private string $netB;

    /** baseline آمار کل قبل از سید — برای گاردِ تفریقِ دادهٔ موازی (وب‌هوک زنده/پراب) */
    private array $baseline;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->model = Container::getInstance()->make(S2sHookEvent::class);
        $this->netA = 'qa93a_' . bin2hex(random_bytes(3));
        $this->netB = 'qa93b_' . bin2hex(random_bytes(3));
        $this->baseline = $this->model->overallStats(30);
    }

    protected function tearDown(): void
    {
        // پاکسازی جراحی — فقط شبکه‌های یکتای همین اجرا
        $this->db->execute(
            "DELETE FROM s2s_hook_events WHERE network LIKE 'qa93a\\_%' OR network LIKE 'qa93b\\_%'"
        );
        parent::tearDown();
    }

    /** سید فیکسچر رویدادها برای دو شبکهٔ یکتای همین اجرا */
    private function seedFixture(): void
    {
        // credited — پاداش پرداخت‌شده (IRT)
        $this->model->record([
            'network' => $this->netA, 'outcome' => 'credited', 'reject_reason' => null,
            'user_id' => 7, 'txid_hash' => str_repeat('a', 64),
            'payout_amount' => '105.00000000', 'currency' => 'IRT', 'http_status' => 200, 'ip' => '10.0.0.1',
        ]);
        // replay — پخش مجددِ همان txid (بدون پاداشِ تازه)
        $this->model->record([
            'network' => $this->netA, 'outcome' => 'replay', 'reject_reason' => null,
            'user_id' => 7, 'txid_hash' => str_repeat('a', 64),
            'payout_amount' => null, 'currency' => null, 'http_status' => 200, 'ip' => '10.0.0.1',
        ]);
        // rejected ×۲ با دو دلیل مختلف
        $this->model->record([
            'network' => $this->netA, 'outcome' => 'rejected', 'reject_reason' => 'bad_signature',
            'user_id' => null, 'txid_hash' => null, 'payout_amount' => null, 'currency' => null,
            'http_status' => 401, 'ip' => '10.0.0.2',
        ]);
        $this->model->record([
            'network' => $this->netA, 'outcome' => 'rejected', 'reject_reason' => 'bad_timestamp',
            'user_id' => null, 'txid_hash' => null, 'payout_amount' => null, 'currency' => null,
            'http_status' => 400, 'ip' => '10.0.0.2',
        ]);
        // شبکهٔ دوم — یک credited با USDT
        $this->model->record([
            'network' => $this->netB, 'outcome' => 'credited', 'reject_reason' => null,
            'user_id' => 9, 'txid_hash' => str_repeat('b', 64),
            'payout_amount' => '0.01400000', 'currency' => 'usdt', 'http_status' => 200, 'ip' => '10.0.0.3',
        ]);
    }

    /** @test */
    public function record_persists_all_columns_and_normalizes_currency(): void
    {
        $this->seedFixture();

        $row = $this->db->fetch(
            "SELECT * FROM s2s_hook_events WHERE network = ? AND outcome = 'credited' ORDER BY id ASC LIMIT 1",
            [$this->netA]
        );

        $this->assertNotNull($row);
        $this->assertSame($this->netA, (string)$row->network);
        $this->assertSame('credited', (string)$row->outcome);
        $this->assertSame(7, (int)$row->user_id);
        $this->assertSame(str_repeat('a', 64), (string)$row->txid_hash);
        $this->assertSame('105.00000000', (string)$row->payout_amount);
        $this->assertSame('irt', (string)$row->currency, 'ارز باید به حروف کوچک نرمال شود');
        $this->assertSame(200, (int)$row->http_status);
        $this->assertSame('10.0.0.1', (string)$row->ip);
    }

    /** @test */
    public function record_coerces_unknown_outcome_to_rejected(): void
    {
        $this->model->record([
            'network' => $this->netA, 'outcome' => 'mystery', 'reject_reason' => 'server_error',
            'user_id' => null, 'http_status' => 500, 'ip' => null,
        ]);

        $outcome = (string)$this->db->fetchColumn(
            'SELECT outcome FROM s2s_hook_events WHERE network = ?',
            [$this->netA]
        );

        $this->assertSame('rejected', $outcome, 'خروجیِ ناشناخته باید fail-safe به rejected برود');
    }

    /** @test */
    public function network_stats_aggregates_counts_rejects_and_payouts(): void
    {
        $this->seedFixture();

        $byNetwork = [];
        foreach ($this->model->networkStats(30) as $stat) {
            $byNetwork[(string)$stat['network']] = $stat;
        }

        $this->assertArrayHasKey($this->netA, $byNetwork);
        $a = $byNetwork[$this->netA];
        $this->assertSame(4, $a['attempts']);
        $this->assertSame(1, $a['credited']);
        $this->assertSame(1, $a['replays']);
        $this->assertSame(2, $a['rejected']);
        $this->assertSame(['bad_signature' => 1, 'bad_timestamp' => 1], $a['rejects']);
        $this->assertSame(['irt' => '105.00000000'], $a['payouts']);

        $b = $byNetwork[$this->netB];
        $this->assertSame(1, $b['attempts']);
        $this->assertSame(1, $b['credited']);
        $this->assertSame([], $b['rejects']);
        $this->assertSame(['usdt' => '0.01400000'], $b['payouts']);
    }

    /** @test */
    public function overall_stats_computes_acceptance_rate_and_top_reject_reason(): void
    {
        $this->seedFixture();

        $overall = $this->model->overallStats(30);

        // آمار کل، شامل هر دادهٔ دیگر (وب‌هوک زنده) هم می‌شود — با baseline مقایسهٔ دلتایی می‌کنیم
        $this->assertSame($this->baseline['attempts'] + 5, $overall['attempts']);
        $this->assertSame($this->baseline['credited'] + 2, $overall['credited']);
        $this->assertSame($this->baseline['replays'] + 1, $overall['replays']);
        $this->assertSame($this->baseline['rejected'] + 2, $overall['rejected']);

        // نرخ پذیرش = ۱۰۰ × credited/attempts روی مجموعِ کامل (فرمول مدل)
        $expectedRate = $overall['attempts'] > 0
            ? round($overall['credited'] * 100.0 / $overall['attempts'], 1)
            : 0.0;
        $this->assertSame($expectedRate, $overall['acceptance_rate']);
        // 2 / 5 = ۴۰٪ وقتی جدول قبل از سید خالی باشد (وضعیت طبیعی جدول تازه‌ساخت)
        if ((int)$this->baseline['attempts'] === 0) {
            $this->assertSame(40.0, $overall['acceptance_rate']);
        }

        // شایع‌ترین دلیل ردشدگی روی فیکسچرِ این اجرا: bad_signature و bad_timestamp تک‌تکرارند؛
        // با ترتیب قطعی (cnt DESC, reason ASC) → bad_signature (وقتی دادهٔ دیگری در پنجره نباشد)
        if ((int)$this->baseline['rejected'] === 0) {
            $this->assertSame('bad_signature', $overall['top_reject_reason']);
        } else {
            $this->assertTrue(
                $overall['top_reject_reason'] === null || is_string($overall['top_reject_reason']),
                'top_reject_reason باید string|null باشد'
            );
        }

        // مجموع پاداش = baseline + سهم فیکسچر (per-currency)
        foreach (['irt' => '105.00000000', 'usdt' => '0.01400000'] as $currency => $fixturePayout) {
            $expected = bcadd((string)($this->baseline['payouts'][$currency] ?? '0'), $fixturePayout, 8);
            $this->assertSame($expected, (string)($overall['payouts'][$currency] ?? '0'), "مجموع پاداش {$currency} باید baseline + فیکسچر باشد");
        }
    }

    /** @test */
    public function recent_returns_rows_newest_first_and_is_bounded(): void
    {
        $this->seedFixture();

        $recent = $this->model->recent(3);

        $this->assertCount(3, $recent);
        $ids = array_map(fn($r) => (int)$r->id, $recent);
        $sorted = $ids;
        rsort($sorted);
        $this->assertSame($sorted, $ids, 'جدول رویدادهای اخیر باید نزولی (تازه‌ترین اول) باشد');

        // شبکهٔ فیکسچر در تازه‌ترین‌ها حاضر است (seed در همین لحظه رخ داده)
        $networks = array_map(fn($r) => (string)$r->network, $recent);
        $this->assertTrue(
            in_array($this->netA, $networks, true) || in_array($this->netB, $networks, true),
            'رویدادهای به‌تازگی ثبت‌شدهٔ فیکسچر باید در صدر recent باشند'
        );
    }
}
