<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\SentryModel;
use App\Models\SystemTelemetryModel;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بچ S13 — قفل رفتاری فیکس‌های ستون‌شبح در SystemTelemetryModel (موتور دوم هشدار):
 *
 *  - FIX-S13-1: getFailedLoginCount روی security_logs.event_type می‌رفت — ستونی که
 *    هرگز وجود نداشت (اثبات قبل از فیکس: SQLSTATE 42S22 روی MariaDB واقعی).
 *    نگاشت canonical FIX-X354: پیام «ورود ناموفق%» (همان پیشوند AuthService).
 *  - FIX-S13-2: getCriticalErrorCount روی error_logs.level می‌رفت — ستون شبح.
 *    نگاشت canonical SentryModel::getMetricValue: sentry_events.level ∈ {'critical','fatal'}.
 *
 *  هر دو متد در زنجیرهٔ زندهٔ LogNotificationAdapter::evaluateRule (قوانین هشدار
 *  notification_channels/alert_rules) مصرف می‌شوند و پیش از فیکس، قانونِ
 *  failed_login/critical_errors روی هر ارزیابی استثنای 42S22 می‌داد که catch بیرونی
 *  بی‌صدا می‌بلعید (قانون همیشه کور — همان کلاس باگ X354/S12-5).
 *
 *  تست‌ها روی MariaDB واقعی اجرا می‌شوند (قرارداد S6LockingReadRoutingTest/S12).
 *  ردیف‌های نشانگر با شناسهٔ یکتا درج و در پایان پاک می‌شوند.
 */
final class S13TelemetryGhostColumnsTest extends TestCase
{
    private const MARKER_MSG = 'ورود ناموفق — S13 proof marker';
    private const MARKER_EVENT = 'S13GhostColumnsProof_' . 'a91c3f7e';

    private int $securityLogId = 0;
    private int $sentryEventId = 0;
    private int $sentryIssueId = 0;

    protected function tearDown(): void
    {
        $db = Database::getInstance();
        if ($this->securityLogId > 0) {
            $db->execute('DELETE FROM security_logs WHERE id = ?', [$this->securityLogId]);
        }
        if ($this->sentryEventId > 0) {
            $db->execute('DELETE FROM sentry_events WHERE id = ?', [$this->sentryEventId]);
        }
        if ($this->sentryIssueId > 0) {
            $db->execute('DELETE FROM sentry_issues WHERE id = ?', [$this->sentryIssueId]);
        }
        parent::tearDown();
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S13-1 — failed_login روی ستون واقعی security_logs.message
    // ─────────────────────────────────────────────────────────────

    public function test_failed_login_count_executes_and_counts_marker_row(): void
    {
        $db = Database::getInstance();
        $db->execute(
            "INSERT INTO security_logs (level, message, user_id, ip_address, created_at)
             VALUES ('WARNING', ?, NULL, '203.0.113.77', NOW())",
            [self::MARKER_MSG]
        );
        $this->securityLogId = (int)$db->fetchColumn(
            'SELECT id FROM security_logs WHERE message = ? ORDER BY id DESC LIMIT 1',
            [self::MARKER_MSG]
        );
        $this->assertGreaterThan(0, $this->securityLogId, 'marker row must be inserted');

        $model = new SystemTelemetryModel(Database::getInstance());
        $count = $model->getFailedLoginCount(60);

        $this->assertIsInt($count);
        $this->assertGreaterThanOrEqual(1, $count, 'failed_login metric must see the marker row (42S22 regression lock)');
    }

    private function makeSentryModel(): SentryModel
    {
        $container = \Core\Container::getInstance();
        return new SentryModel(
            $container->make(\Core\Database::class),
            $container->make(\App\Contracts\LoggerInterface::class),
            $container->make(\App\Services\Settings\AppSettings::class),
            $container->make(\Core\Queue::class)
        );
    }

    public function test_failed_login_parity_with_sentry_engine(): void
    {
        // پارتیِ دو موتور هشدار برای یک نام متریک: SentryModel (X354-fixed) و
        // SystemTelemetryModel (FIX-S13-1) باید روی همان DB وضعیت یکسان بدهند.
        $sentry = $this->makeSentryModel();
        $telemetry = new SystemTelemetryModel(Database::getInstance());

        $a = $sentry->getMetricValue('failed_login', 60);
        $b = $telemetry->getFailedLoginCount(60);

        $this->assertSame((int)round((float)$a), (int)$b, 'both alert engines must agree on failed_login semantics');
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S13-2 — critical_errors روی ستون واقعی sentry_events.level
    // ─────────────────────────────────────────────────────────────

    public function test_critical_error_count_executes_and_counts_marker_row(): void
    {
        $db = Database::getInstance();

        $db->execute(
            "INSERT INTO sentry_issues (fingerprint, level, title, culprit, first_seen, last_seen, count, environment, release_version, status, metadata)
             VALUES (?, 'critical', 'S13 proof issue', 'S13Test', NOW(), NOW(), 1, 'testing', 's13', 'unresolved', '{}')",
            [self::MARKER_EVENT]
        );
        $this->sentryIssueId = (int)$db->fetchColumn(
            'SELECT id FROM sentry_issues WHERE fingerprint = ? ORDER BY id DESC LIMIT 1',
            [self::MARKER_EVENT]
        );
        $this->assertGreaterThan(0, $this->sentryIssueId);

        $db->execute(
            "INSERT INTO sentry_events (issue_id, event_id, level, message, environment, release_version, user_id, ip_address, user_agent, created_at)
             VALUES (?, ?, 'critical', 'S13 proof critical event', 'testing', 's13', NULL, '203.0.113.78', 'S13Test', NOW())",
            [$this->sentryIssueId, self::MARKER_EVENT]
        );
        $this->sentryEventId = (int)$db->fetchColumn(
            'SELECT id FROM sentry_events WHERE event_id = ? ORDER BY id DESC LIMIT 1',
            [self::MARKER_EVENT]
        );
        $this->assertGreaterThan(0, $this->sentryEventId, 'marker event must be inserted');

        $model = new SystemTelemetryModel(Database::getInstance());
        $count = $model->getCriticalErrorCount(60);

        $this->assertIsInt($count);
        $this->assertGreaterThanOrEqual(1, $count, 'critical_errors metric must see the marker row (42S22 regression lock)');
    }

    public function test_critical_error_parity_with_sentry_engine(): void
    {
        $sentry = $this->makeSentryModel();
        $telemetry = new SystemTelemetryModel(Database::getInstance());

        $a = $sentry->getMetricValue('critical_errors', 60);
        $b = $telemetry->getCriticalErrorCount(60);

        $this->assertSame((int)round((float)$a), (int)$b, 'both alert engines must agree on critical_errors semantics');
    }
}
