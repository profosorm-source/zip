<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\FraudReport;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * تست مدل FraudReport — X372 (راند ۹۳): سیم‌کشی جدول یتیم fraud_reports
 *
 * پوشش:
 *   - create: ثبت با evidence JSON و بازگشت شناسه / شکست INSERT → RuntimeException
 *   - ضد تکرار: hasPendingReport برای جفت (reporter, reported)
 *   - سقف نرخ: pendingCountForReporter (پنجرهٔ ۲۴ ساعت)
 *   - گذارهای ادمین: review / dismiss → نوشتن status + reviewed_by/at + admin_note (با برش ۱۰۰۰)
 *   - monthlyStats: شکل خروجی و کلیدها
 *   - paginate: JOIN users + فیلتر وضعیت + شمارش کل
 *
 * سبک خانه: Database با Mockery مک می‌شود (بدون دست‌زدن به DB واقعی) —
 * آینهٔ tests/Unit/Services/MessageModerationServiceTest.
 */
class FraudReportTest extends TestCase
{
    /** @var \Core\Database&\Mockery\MockInterface */
    private \Core\Database $db;
    /** @var \Core\QueryBuilder&\Mockery\MockInterface */
    private \Core\QueryBuilder $qb;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock('Core\Database');
        $this->qb = m::mock('Core\QueryBuilder');
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    private function makeModel(): FraudReport
    {
        return new FraudReport($this->db);
    }

    /** @test */
    public function constants_expose_status_machine_and_reason_vocabulary(): void
    {
        $this->assertSame('pending', FraudReport::STATUS_PENDING);
        $this->assertSame('reviewed', FraudReport::STATUS_REVIEWED);
        $this->assertSame('dismissed', FraudReport::STATUS_DISMISSED);
        $this->assertSame(3, FraudReport::MAX_PENDING_PER_24H);

        // واژه‌نامهٔ کنترل‌شدهٔ دلیل — کلیدهای مجاز با برچسب فارسی
        $this->assertSame(
            ['spam_link', 'fake_promises', 'impersonation', 'farming', 'other'],
            array_keys(FraudReport::REASONS)
        );
        foreach (FraudReport::REASONS as $label) {
            $this->assertNotSame('', trim($label));
        }
    }

    /** @test */
    public function create_report_persists_pending_row_with_json_evidence(): void
    {
        $this->db->shouldReceive('table')->with('fraud_reports')->once()->andReturn($this->qb);
        $this->qb->shouldReceive('insert')->once()->withArgs(function (array $data): bool {
            return $data['reporter_id'] === 6
                && $data['reported_user_id'] === 7
                && $data['reason'] === 'spam_link'
                && $data['status'] === 'pending'
                && is_string($data['evidence'])
                && str_contains($data['evidence'], '"source":"referral_hub"');
        })->andReturn(101);

        $id = $this->makeModel()->createReport(6, 7, 'spam_link', ['text' => 'لینک هرز', 'source' => 'referral_hub']);

        $this->assertSame(101, $id);
    }

    /** @test */
    public function create_report_throws_when_insert_does_not_return_id(): void
    {
        $this->db->shouldReceive('table')->with('fraud_reports')->once()->andReturn($this->qb);
        $this->qb->shouldReceive('insert')->once()->andReturn(true); // جدول بدون auto-inc یا شکست

        $this->expectException(\RuntimeException::class);
        $this->makeModel()->createReport(6, 7, 'other', ['text' => null, 'source' => 'referral_hub']);
    }

    /** @test */
    public function has_pending_report_checks_exact_pair_and_status(): void
    {
        $this->db->shouldReceive('table')->with('fraud_reports')->andReturn($this->qb);
        $this->qb->shouldReceive('where')->with('reporter_id', 6)->andReturnSelf();
        $this->qb->shouldReceive('where')->with('reported_user_id', 7)->andReturnSelf();
        $this->qb->shouldReceive('where')->with('status', 'pending')->andReturnSelf();
        $this->qb->shouldReceive('exists')->once()->andReturn(true);

        $this->assertTrue($this->makeModel()->hasPendingReport(6, 7));
    }

    /** @test */
    public function pending_count_for_reporter_counts_last_24h_pending_only(): void
    {
        $this->db->shouldReceive('table')->with('fraud_reports')->andReturn($this->qb);
        $this->qb->shouldReceive('where')->with('reporter_id', 6)->andReturnSelf();
        $this->qb->shouldReceive('where')->with('status', 'pending')->andReturnSelf();
        $this->qb->shouldReceive('whereRaw')->once()
            ->withArgs(fn(string $sql): bool => str_contains($sql, 'INTERVAL 24 HOUR'))
            ->andReturnSelf();
        $this->qb->shouldReceive('count')->once()->andReturn(3);

        $this->assertSame(3, $this->makeModel()->pendingCountForReporter(6));
    }

    /** @test */
    public function review_writes_status_admin_signature_and_note(): void
    {
        $this->db->shouldReceive('table')->with('fraud_reports')->andReturn($this->qb);
        $this->qb->shouldReceive('where')->with('id', 11)->andReturnSelf();
        // [X376] گارد وضعیت در خود SQL — گذار فقط از pending
        $this->qb->shouldReceive('where')->with('status', 'pending')->andReturnSelf();
        $this->qb->shouldReceive('update')->once()->withArgs(function (array $data): bool {
            return $data['status'] === 'reviewed'
                && $data['reviewed_by'] === 5
                && $data['admin_note'] === 'تأیید شد'
                && is_string($data['reviewed_at']);
        })->andReturn(1);

        $this->assertTrue($this->makeModel()->review(11, 5, 'تأیید شد'));
    }

    /** @test */
    public function dismiss_truncates_note_to_1000_chars_and_reports_zero_affected(): void
    {
        $longNote = str_repeat('ت', 1500);

        $this->db->shouldReceive('table')->with('fraud_reports')->andReturn($this->qb);
        $this->qb->shouldReceive('where')->with('id', 12)->andReturnSelf();
        // [X376] گارد وضعیت در خود SQL — گذار فقط از pending
        $this->qb->shouldReceive('where')->with('status', 'pending')->andReturnSelf();
        $this->qb->shouldReceive('update')->once()->withArgs(function (array $data) use ($longNote): bool {
            return $data['status'] === 'dismissed'
                && $data['reviewed_by'] === 5
                && $data['admin_note'] === mb_substr($longNote, 0, 1000)
                && mb_strlen((string)$data['admin_note']) === 1000;
        })->andReturn(0); // گزارش یافت نشد → false

        $this->assertFalse($this->makeModel()->dismiss(12, 5, $longNote));
    }

    /** @test */
    public function monthly_stats_returns_pending_and_30d_transitions(): void
    {
        $this->db->shouldReceive('table')->with('fraud_reports')->andReturn($this->qb);

        // pending (کل صف باز)
        $this->qb->shouldReceive('where')->with('status', 'pending')->andReturnSelf();
        $this->qb->shouldReceive('count')->once()->andReturn(4);
        // reviewed ۳۰ روز
        $this->qb->shouldReceive('where')->with('status', 'reviewed')->andReturnSelf();
        $this->qb->shouldReceive('whereRaw')->twice()
            ->withArgs(fn(string $sql): bool => str_contains($sql, 'INTERVAL 30 DAY'))
            ->andReturnSelf();
        $this->qb->shouldReceive('count')->once()->andReturn(9);
        // dismissed ۳۰ روز
        $this->qb->shouldReceive('where')->with('status', 'dismissed')->andReturnSelf();
        $this->qb->shouldReceive('count')->once()->andReturn(2);

        $stats = $this->makeModel()->monthlyStats();

        $this->assertSame(
            ['pending' => 4, 'reviewed_30d' => 9, 'dismissed_30d' => 2],
            $stats
        );
    }

    /** @test */
    public function paginate_reports_joins_users_and_applies_status_filter(): void
    {
        $row = (object)[
            'id' => 3, 'reporter_id' => 6, 'reported_user_id' => 7, 'reason' => 'spam_link',
            'status' => 'pending', 'reporter_name' => 'Saga Tester', 'reported_username' => 'qa20b01_2314',
        ];

        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('bindValue')->times(3);
        $stmt->shouldReceive('execute')->once();
        $stmt->shouldReceive('fetchAll')->once()->with(\PDO::FETCH_OBJ)->andReturn([$row]);

        $this->db->shouldReceive('prepare')->once()
            ->withArgs(function (string $sql): bool {
                return str_contains($sql, 'LEFT JOIN users rp ON rp.id = fr.reporter_id')
                    && str_contains($sql, 'LEFT JOIN users ru ON ru.id = fr.reported_user_id')
                    && str_contains($sql, 'WHERE fr.status = ?')
                    && str_contains($sql, 'LIMIT ? OFFSET ?');
            })
            ->andReturn($stmt);

        $this->db->shouldReceive('fetchColumn')->once()
            ->withArgs(function (string $sql, array $params): bool {
                return str_contains($sql, 'COUNT(*)')
                    && $params === ['pending'];
            })
            ->andReturn(1);

        $result = $this->makeModel()->paginateReports(1, 20, 'pending');

        $this->assertSame(1, $result['total']);
        $this->assertSame(1, $result['page']);
        $this->assertSame(20, $result['per_page']);
        $this->assertSame(1, $result['last_page']);
        $this->assertSame('Saga Tester', $result['items'][0]->reporter_name);
    }

    /** @test */
    public function paginate_reports_with_all_status_has_no_where(): void
    {
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('bindValue')->times(2);
        $stmt->shouldReceive('execute')->once();
        $stmt->shouldReceive('fetchAll')->once()->with(\PDO::FETCH_OBJ)->andReturn([]);

        $this->db->shouldReceive('prepare')->once()
            ->withArgs(fn(string $sql): bool => !str_contains($sql, 'WHERE') && str_contains($sql, 'LIMIT ? OFFSET ?'))
            ->andReturn($stmt);
        $this->db->shouldReceive('fetchColumn')->once()->andReturn(0);

        $result = $this->makeModel()->paginateReports(2, 20, 'all');

        $this->assertSame(0, $result['total']);
        $this->assertSame([], $result['items']);
        $this->assertSame(1, $result['last_page']); // max(1, ceil(0/20))
    }
}
