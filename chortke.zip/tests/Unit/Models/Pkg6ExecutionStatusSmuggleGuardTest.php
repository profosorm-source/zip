<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\SocialTaskExecutionModel;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * FIX-F21-05 (بازبینی بخش ۲۱ — بستهٔ ۶): status از mass-update allow-list
 * مدل اجرای تسک اجتماعی حذف شد.
 *
 * یافتهٔ گزارش (latent): 'status' در ALLOWED_UPDATE_FIELDS حضور داشت؛ چون
 * updateExecutionStatus ستون status را اول با مقدارِ transition-validated
 * می‌نویسد، کلید status در $data همان ستون را در ادامهٔ SET بازنویسی می‌کرد —
 * یعنی هر caller ای که data['status'] بفرستد می‌توانست نتیجهٔ ماشین حالت را
 * بی‌سروصدا دور بزند. در callsiteهای فعلی چنین caller ای نبود (بررسی کامل
 * jobs/controllers در بستهٔ ۶)؛ رفع = fail-loud: کلید status حالا مثل بقیهٔ
 * ستون‌های ممنوعه «Invalid or restricted update column» می‌گیرد.
 */
final class Pkg6ExecutionStatusSmuggleGuardTest extends TestCase
{
    public function testStatusIsNoLongerInTheMassUpdateAllowList(): void
    {
        $reflection = new \ReflectionClass(SocialTaskExecutionModel::class);
        $this->assertTrue($reflection->hasConstant('ALLOWED_UPDATE_FIELDS'));
        /** @var list<string> $fields */
        $fields = $reflection->getConstant('ALLOWED_UPDATE_FIELDS');

        // قهرمانِ یافته: status دیگر قابل قاچاق از data نیست
        $this->assertNotContains('status', $fields, 'FIX-F21-05: status نباید در ALLOWED_UPDATE_FIELDS باشد');
    }

    public function testOperationalColumnsRemainUpdatable(): void
    {
        $reflection = new \ReflectionClass(SocialTaskExecutionModel::class);
        /** @var list<string> $fields */
        $fields = $reflection->getConstant('ALLOWED_UPDATE_FIELDS');

        // حذف status نباید ستون‌های عملیاتیِ شغل‌های تأیید/رد را خراب کند —
        // این کلیدها در Approve/Reject/Submit jobs واقعاً استفاده می‌شوند.
        foreach (['flag_review', 'flag_note', 'decision', 'rejection_reason', 'reviewed_by', 'reviewed_at', 'override_reason', 'overridden_by', 'overridden_at', 'final_score', 'reward_paid', 'reward_amount', 'submitted_at'] as $column) {
            $this->assertContains($column, $fields, "ستون عملیاتی {$column} باید در allow-list بماند");
        }
    }

    /**
     * رفتاری: data['status'] باید قبل از هر write ای fail-loud شکست بخورد —
     * مسیر بازنویسیِ بی‌صدای ستون وضعیت عملاً مرده است.
     */
    public function testSmuggledStatusKeyThrowsBeforeAnyWrite(): void
    {
        $db = $this->createMock(Database::class);
        // SELECT وضعیت فعلی (بدنهٔ اول متد) — یک ردیف submitted برمی‌گرداند
        $db->method('fetch')->willReturn((object)['status' => 'submitted']);
        // write هرگز نباید رخ دهد
        $db->expects($this->never())->method('query');

        $model = new SocialTaskExecutionModel($db);

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('status');

        // حتی اگر مقدار قاچاق با target transition یکی باشد هم رد می‌شود —
        // ستون وضعیت فقط از آرگومان اختصاصی می‌آید، نه از data.
        $model->updateExecutionStatus(42, 'approved', ['status' => 'approved', 'flag_review' => 1]);
    }

    /**
     * رفتاری مثبت: گذار مجاز با dataهای سالم همچنان کار می‌کند و ستون status
     * در SQL با «مقدار آرگومانِ» اعتبارسنجی‌شده نوشته می‌شود.
     */
    public function testLegitimateTransitionStillWritesValidatedStatus(): void
    {
        $db = $this->createMock(Database::class);
        $db->method('fetch')->willReturn((object)['status' => 'submitted']);

        $capturedSql = '';
        $capturedParams = [];
        // PHPUnit 8 با متدهای union-typed کلاس PDOStatement در PHP 8.4 نمی‌تواند
        // mock بسازد (ReflectionUnionType::getName)؛ مدل فقط خروجی را bool
        // می‌کند و هرگز خودِ statement را لمس نمی‌کند — نمونهٔ خامِ بدون‌سازنده
        // کافی است.
        $stmt = (new \ReflectionClass(\PDOStatement::class))->newInstanceWithoutConstructor();
        $db->expects($this->once())
            ->method('query')
            ->willReturnCallback(function (string $sql, array $params = []) use (&$capturedSql, &$capturedParams, $stmt) {
                $capturedSql = $sql;
                $capturedParams = $params;
                return $stmt;
            });

        $model = new SocialTaskExecutionModel($db);
        $ok = $model->updateExecutionStatus(42, 'approved', ['flag_review' => 1, 'reviewed_by' => 7]);

        $this->assertTrue($ok);
        $this->assertStringStartsWith('UPDATE social_task_executions SET status = ?', $capturedSql);
        // اولین پارامتر = وضعیتِ transition-validated؛ سپس ستون‌های data؛ در پایان id
        $this->assertSame('approved', $capturedParams[0]);
        $this->assertSame(1, $capturedParams[1]); // flag_review
        $this->assertSame(7, $capturedParams[2]); // reviewed_by
        $this->assertSame(42, $capturedParams[3]); // id
    }

    /**
     * رفتاری: گذار غیرمجاز همچنان توسط ماشین حالت رد می‌شود (رگرسیونِ
     * نگه‌دارندهٔ رفتار موجود — این تست قبل و بعد از FIX-F21-05 یکسان پاس است).
     */
    public function testInvalidTransitionIsStillRejectedByStateMachine(): void
    {
        $db = $this->createMock(Database::class);
        $db->method('fetch')->willReturn((object)['status' => 'approved']); // terminal
        $db->expects($this->never())->method('query');

        $model = new SocialTaskExecutionModel($db);

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid state transition');

        $model->updateExecutionStatus(42, 'rejected');
    }
}
