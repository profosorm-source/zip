<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\ApiToken;
use Mockery as m;
use PDOStatement;
use PHPUnit\Framework\TestCase;

/**
 * FIX-QA2-MULTIVER (بچ فاز-۲ سئو، ۲۰۲۶-۱۱-۰۲): پینِ رفع مورد معوق searchPredicate.
 *
 * قرارداد: جست‌وجوی ادمین با توکن خام (۶۴-hex) باید توکن‌های هش‌شده با «هر
 * نسخهٔ راز» را پیدا کند (هم‌قرارداد مسیر اعتبارسنجی) — نه فقط نسخهٔ جاری.
 * توکن‌های هنوز-مهاجرت‌نکرده (v1) تا قبل از این رفع، در جست‌وجو گم می‌شدند.
 */
final class ApiTokenSearchMultiVersionTest extends TestCase
{
    /** @var \Core\Database&\Mockery\MockInterface */
    private \Core\Database $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock('Core\Database');
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /**
     * بازنمایی searchPredicate از طریق رفتار findAllPaginated — متد private است؛
     * رفتارش از SQL/پارامترهایی که به whereRaw می‌روند پین می‌شود.
     *
     * @return array{0: string, 1: list<mixed>}
     */
    private function capturePredicate(string $search): array
    {
        $builder = m::mock('Core\QueryBuilder');
        $builder->shouldReceive('leftJoin')->once()->andReturnSelf();
        $captured = [];
        $builder->shouldReceive('whereRaw')->once()->with(
            m::on(function (string $sql) use (&$captured): bool {
                $captured[0] = $sql;
                return true;
            }),
            m::on(function (array $params) use (&$captured): bool {
                $captured[1] = $params;
                return true;
            })
        );
        $builder->shouldReceive('select')->once()->andReturnSelf();
        $builder->shouldReceive('orderBy')->once()->andReturnSelf();
        $builder->shouldReceive('limit')->once()->andReturnSelf();
        $builder->shouldReceive('offset')->once()->andReturnSelf();
        $builder->shouldReceive('get')->once()->andReturn([]);

        $this->db->shouldReceive('table')->once()->andReturn($builder);

        $model = new ApiToken($this->db);
        $model->findAllPaginated(20, 0, $search, null);

        $this->assertIsArray($captured);
        return [$captured[0], $captured[1]];
    }

    public function test_raw_token_search_matches_all_secret_versions(): void
    {
        $rawToken = str_repeat('a', 64);

        // config سراسری — نسخه‌های متمایز مثل بوت تست
        global $configOverrides;
        $old = $configOverrides;
        $configOverrides = [
            'security' => [
                'api' => [
                    'secrets' => [
                        'v1' => str_repeat('1', 64),
                        'v2' => str_repeat('2', 64),
                    ],
                    'current_secret_version' => 'v2',
                ],
            ],
        ];

        try {
            [$sql, $params] = $this->capturePredicate($rawToken);
        } finally {
            $configOverrides = $old;
        }

        // هر دو نسخه در SQL ظاهر می‌شوند — جفت (token = ? AND secret_version = ?)
        $this->assertSame(2, substr_count($sql, 'AND at.secret_version = ?'));
        $this->assertStringContainsString('at.token = ?', $sql);

        // پارامترها: ۲ LIKE + (هش v1, 'v1') + (هش v2, 'v2')
        $this->assertCount(6, $params);
        $this->assertSame(hash_hmac('sha256', $rawToken, str_repeat('1', 64)), $params[2]);
        $this->assertSame('v1', $params[3]);
        $this->assertSame(hash_hmac('sha256', $rawToken, str_repeat('2', 64)), $params[4]);
        $this->assertSame('v2', $params[5]);
    }

    public function test_non_hex_search_never_adds_token_hash_params(): void
    {
        [$sql, $params] = $this->capturePredicate('just-a-name');

        $this->assertStringNotContainsString('at.token', $sql);
        $this->assertCount(2, $params); // فقط دو LIKE
    }

    public function test_short_hex_is_treated_as_plain_search(): void
    {
        // ۶۳ کاراکتر hex = نه توکن کامل، نه نام معمولی — مثل جستجوی اسم رفتار می‌کند
        [$sql, $params] = $this->capturePredicate(str_repeat('f', 63));

        $this->assertStringNotContainsString('at.token', $sql);
        $this->assertCount(2, $params);
    }
}
