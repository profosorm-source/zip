<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\AccountDeletionLog;
use Core\Database;
use Mockery;
use PHPUnit\Framework\TestCase;

/**
 * پین‌های مدل شمارش‌های حذف حساب (S7-FIX UI-DEL-002 + FIX-CMD169/170).
 *
 * پس از S7-FIX، «صداقت» شمارش‌ها (پنجرهٔ expiring_soon، تفکیک status) از
 * closure کنترلر به SQL مدل منتقل شد — این تست SQL همان قرارداد را مستقیماً
 * قفل می‌کند تا drift بین کنترلر و مدل ناممکن شود:
 *  - countPendingDeletions: فقط status='requested'
 *  - countDeletedAccounts: فقط status='deleted'
 *  - countExpiringSoon: status='requested' + expires_at ناتهی + پنجرهٔ
 *    بستهٔ [NOW() .. NOW()+24h] (FIX-CMD170 — منفی/دور/تهی شمرده نمی‌شوند)
 *  - getPendingDeletions: سقف clamp شدهٔ ۱..۵۰۰ (FIX-CMD169)
 */
final class AccountDeletionLogCountsTest extends TestCase
{
    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /** @return array{0: AccountDeletionLog, 1: Mockery\MockInterface} */
    private function makeModel(): array
    {
        $db = Mockery::mock(Database::class);
        $model = new AccountDeletionLog($db);

        return [$model, $db];
    }

    public function test_count_pending_deletions_counts_only_requested_rows(): void
    {
        [$model, $db] = $this->makeModel();
        $db->shouldReceive('fetchColumn')
            ->once()
            ->with(Mockery::on(static fn (string $sql): bool =>
                str_contains($sql, 'COUNT(*)')
                && str_contains($sql, "`account_deletion_logs`")
                && str_contains($sql, "status = 'requested'")))
            ->andReturn('7');

        $this->assertSame(7, $model->countPendingDeletions());
    }

    public function test_count_deleted_accounts_counts_only_deleted_rows(): void
    {
        [$model, $db] = $this->makeModel();
        $db->shouldReceive('fetchColumn')
            ->once()
            ->with(Mockery::on(static fn (string $sql): bool =>
                str_contains($sql, "status = 'deleted'")))
            ->andReturn('3');

        $this->assertSame(3, $model->countDeletedAccounts());
    }

    public function test_count_expiring_soon_uses_closed_24h_window_on_requested_rows(): void
    {
        [$model, $db] = $this->makeModel();
        $db->shouldReceive('fetchColumn')
            ->once()
            ->with(Mockery::on(static fn (string $sql): bool =>
                str_contains($sql, "status = 'requested'")
                // پنجرهٔ بستهٔ [NOW() .. NOW()+24h] — FIX-CMD170:
                // ردیف‌های منقضی‌شده (expires_at < NOW())، دور (> ۲۴h) و NULL
                // هرگز شمرده نمی‌شوند.
                && str_contains($sql, 'expires_at IS NOT NULL')
                && str_contains($sql, 'expires_at >= NOW()')
                && str_contains($sql, 'DATE_ADD(NOW(), INTERVAL 24 HOUR)')))
            ->andReturn('2');

        $this->assertSame(2, $model->countExpiringSoon());
    }

    public function test_get_pending_deletions_clamps_limit_to_500(): void
    {
        [$model, $db] = $this->makeModel();
        $rows = [(object)['id' => 1, 'status' => 'requested']];
        $db->shouldReceive('fetchAll')
            ->once()
            ->with(Mockery::on(static fn (string $sql): bool =>
                str_contains($sql, 'LIMIT 500 OFFSET 0')))
            ->andReturn($rows);

        $result = $model->getPendingDeletions(10000);

        $this->assertSame($rows, $result);
    }
}
