<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Middleware\ApiAuthMiddleware;
use App\Models\ApiToken;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-MOBILE-04 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲):
 * اسکوپ‌های سئو (seo.read/seo.write) — کاتالوگ عمومی + سلسله‌مراتب پوشش.
 *
 * قرارداد:
 *  ① در ALLOWED_SCOPES و کاتالوگ ماشینی /auth/scopes با متادیتای استاندارد
 *  ② exact-only نیستند (برخلاف wallet.withdraw/account.security)
 *  ③ سلسله‌مراتب: read سراسری → seo.read؛ write سراسری → seo.read/seo.write
 *  ④ seo.write → seo.read (سلسله‌مراتب entity)
 */
final class ApiTokenSeoScopesTest extends TestCase
{
    public function test_scopes_in_allowlist_and_catalog(): void
    {
        $this->assertContains('seo.read', ApiToken::ALLOWED_SCOPES, 'seo.read باید در allowlist باشد');
        $this->assertContains('seo.write', ApiToken::ALLOWED_SCOPES, 'seo.write باید در allowlist باشد');

        $catalog = ApiToken::scopeCatalog();
        $byScope = [];
        foreach ($catalog as $row) {
            $byScope[$row['scope']] = $row;
        }

        $this->assertArrayHasKey('seo.read', $byScope, 'کاتالوگ عمومی /auth/scopes باید seo.read را فهرست کند');
        $this->assertArrayHasKey('seo.write', $byScope, 'کاتالوگ عمومی /auth/scopes باید seo.write را فهرست کند');
        $this->assertFalse($byScope['seo.read']['exact_only']);
        $this->assertFalse($byScope['seo.write']['exact_only']);
        $this->assertSame('standard', $byScope['seo.read']['risk']);
        $this->assertSame('standard', $byScope['seo.write']['risk']);
        $this->assertNotEmpty($byScope['seo.read']['description']);
        $this->assertNotEmpty($byScope['seo.write']['description']);
    }

    /** سلسله‌مراتب پوشش از طریق منطق کانونی ApiAuthMiddleware::hasScope */
    public function test_scope_hierarchy_coverage(): void
    {
        $m = new \ReflectionMethod(ApiAuthMiddleware::class, 'hasScope');
        $m->setAccessible(true);
        // hasScope غیرstatic است — invoke روی null با $this بسته‌بندی نمی‌شود چون
        // متد به propertyهای $this اشاره نمی‌کند؛ اما برای اطمینان proxy سبک:
        $middleware = (new \ReflectionClass(ApiAuthMiddleware::class))->newInstanceWithoutConstructor();
        $has = static fn(array $scopes, string $need): bool => $m->invoke($middleware, $scopes, $need);

        // read سراسری → seo.read (نه seo.write)
        $this->assertTrue($has(['read'], 'seo.read'));
        $this->assertFalse($has(['read'], 'seo.write'));

        // write سراسری → هر دو
        $this->assertTrue($has(['write'], 'seo.read'));
        $this->assertTrue($has(['write'], 'seo.write'));

        // تطبیق دقیق
        $this->assertTrue($has(['seo.read'], 'seo.read'));
        $this->assertTrue($has(['seo.write'], 'seo.write'));

        // سلسله‌مراتب entity: seo.write → seo.read
        $this->assertTrue($has(['seo.write'], 'seo.read'));

        // wildcard ادمین
        $this->assertTrue($has(['*'], 'seo.write'));

        // بدون اسکوپ مرتبط
        $this->assertFalse($has(['user.read'], 'seo.read'));
        $this->assertFalse($has(['social.write'], 'seo.read'));
    }

    public function test_exact_only_scopes_unchanged_by_new_scopes(): void
    {
        // اسکوپ‌های پرریسک همچنان exact-only اند (رگرسیون FIX-M11-R22-13)
        $catalog = [];
        foreach (ApiToken::scopeCatalog() as $row) {
            $catalog[$row['scope']] = $row;
        }
        $this->assertTrue($catalog['wallet.withdraw']['exact_only']);
        $this->assertTrue($catalog['account.security']['exact_only']);
    }
}
