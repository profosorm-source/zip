<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Services\Seo\AdsSeoService;
use Core\Container;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-Q4-SEO23-04/09 — قرارداد سهمیه‌های سئو و جایگاه یکتای روز.
 *
 * گزارش بخش ۲۳:
 *  • SEO-23-04: max_per_day کمپین با «کل اجراهای کاربر روی همهٔ کمپین‌ها»
 *    مقایسه می‌شد؛ اکنون دو سهمیهٔ جدا: per-ad (ستون کمپین) و سراسریِ کاربر
 *    (تنظیم seo_max_tasks_per_day). اجرای cancelled سهمیه و تکرار را نمی‌سوزاند.
 *  • SEO-23-09: ایندکس (ad_id, user_id, execution_date) غیریکتا بود و محافظ
 *    1062 مرده بود؛ اکنون slot_date یکتا (NULL برای باطل‌ها) رقابت را در
 *    سطح DB می‌بندد و ایندکس (ip_address, created_at) گیت ضدتقلب را پوشش
 *    می‌دهد.
 */
final class SeoExecutionQuotaSlotContractTest extends TestCase
{
    private Database $db;
    private \App\Models\SeoExecution $model;
    private AdsSeoService $service;
    private string $tag;
    private int $userId;
    private int $adA;
    private int $adB;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->model = Container::getInstance()->make(\App\Models\SeoExecution::class);
        $this->service = Container::getInstance()->make(AdsSeoService::class);
        $this->tag = 'q4s' . bin2hex(random_bytes(4));

        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["q4seo-{$this->tag}", "q4seo-{$this->tag}@example.test", 'active', 'user'],
        );
        $this->userId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');

        foreach (['A', 'B'] as $k) {
            $this->db->query(
                "INSERT INTO ads (user_id, title, type, status, is_active, budget, total_budget, remaining_budget, min_payout, max_payout, currency, max_per_day, created_at, updated_at)
                 VALUES (?, ?, 'seo', 'active', 1, 100000, 100000, 100000, 1000, 5000, 'irt', 2, NOW(), NOW())",
                [$this->userId, "q4-ad-{$k}-{$this->tag}"],
            );
            $id = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
            if ($k === 'A') { $this->adA = $id; } else { $this->adB = $id; }
        }
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM seo_executions WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM ads WHERE id IN (?, ?)', [$this->adA, $this->adB]);
        $this->db->query('DELETE FROM users WHERE id = ?', [$this->userId]);
        parent::tearDown();
    }

    private function createExecution(int $adId, string $status = 'started'): int
    {
        $execution = $this->model->createExecution([
            'ad_id' => $adId,
            'user_id' => $this->userId,
            'ip_address' => '10.0.0.1',
            'target_keyword' => 'q4',
        ]);
        $this->assertNotNull($execution);
        if ($status !== 'started') {
            // گذار از مسیر واقعی (سرویس/مدل) تا slot_date هم طبق کد آزاد شود
            if ($status === 'cancelled') {
                $this->service->cancelExecution((int)$execution->id, 'تست Q4');
            } elseif ($status === 'fraud') {
                $this->model->markAsFraud((int)$execution->id, ['reason' => 'تست Q4']);
            } else {
                $this->db->query(
                    'UPDATE seo_executions SET status = ?, slot_date = NULL WHERE id = ?',
                    [$status, $execution->id],
                );
            }
        }
        return (int)$execution->id;
    }

    /** سهمیهٔ per-ad: فقط اجراهای همین آگهی؛ آگهی دیگر اثر ندارد (SEO-23-04) */
    public function test_per_ad_quota_is_ad_scoped(): void
    {
        $this->createExecution($this->adA, 'completed');
        $this->createExecution($this->adB, 'completed'); // آگهی دیگر — نباید در سهمیهٔ A شمرده شود

        $this->assertSame(1, $this->model->countByAdAndUserToday($this->adA, $this->userId));
        $this->assertSame(1, $this->model->countByAdAndUserToday($this->adB, $this->userId));
        // سهمیهٔ سراسری = جمع همهٔ کمپین‌ها
        $this->assertSame(2, $this->model->countByUserToday($this->userId));
    }

    /** اجرای cancelled/fraud/rejected سهمیهٔ روز را نمی‌سوزاند (SEO-23-04) */
    public function test_cancelled_execution_does_not_burn_quota(): void
    {
        $this->createExecution($this->adA, 'cancelled');
        $this->createExecution($this->adA, 'fraud');

        $this->assertSame(0, $this->model->countByAdAndUserToday($this->adA, $this->userId));
        $this->assertSame(0, $this->model->countByUserToday($this->userId));
    }

    /** لغو، امکان شروع مجدد همان آگهی در همان روز را برمی‌گرداند (SEO-23-04) */
    public function test_cancel_allows_same_day_restart(): void
    {
        $execId = $this->createExecution($this->adA); // started
        $this->assertTrue($this->model->existsByAdAndUserToday($this->adA, $this->userId));

        // لغو از مسیر سرویس (همان مسیر کنترلر) — slot_date آزاد می‌شود
        $this->assertTrue($this->service->cancelExecution($execId, 'تست: شروع مجدد همان روز'));

        $this->assertFalse(
            $this->model->existsByAdAndUserToday($this->adA, $this->userId),
            'پس از لغو، همان آگهی باید در همان روز قابل شروع مجدد باشد',
        );

        // شروع مجدد واقعی — UNIQUE(slot) نباید بگیرد چون لغو جایگاه را آزاد کرده
        $second = $this->createExecution($this->adA);
        $this->assertGreaterThan(0, $second);
    }

    /** createExecution جایگاه روز (slot_date) را پر می‌کند (SEO-23-09) */
    public function test_create_execution_fills_slot_date(): void
    {
        $execId = $this->createExecution($this->adA);
        $slot = $this->db->query(
            'SELECT slot_date, execution_date FROM seo_executions WHERE id = ?',
            [$execId],
        )->fetch(\PDO::FETCH_OBJ);
        $this->assertNotNull($slot->slot_date);
        $this->assertSame($slot->execution_date, $slot->slot_date);
    }

    /** رقابت دو شروعِ هم‌زمان: UNIQUE (ad_id, user_id, slot_date) می‌گیرد (SEO-23-09) */
    public function test_unique_slot_blocks_concurrent_same_day_start(): void
    {
        $this->setOutputCallback(static function (): void {}); // سینک کنسولی logger خطای DB
        $this->createExecution($this->adA); // جایگاه امروز گرفته شد

        try {
            $this->model->createExecution([
                'ad_id' => $this->adA,
                'user_id' => $this->userId,
                'ip_address' => '10.0.0.1',
            ]);
            $this->fail('شروع دوم همان روز باید توسط UNIQUE(slot_date) رد شود');
        } catch (\PDOException $e) {
            $this->assertSame('23000', (string)$e->getCode());
            $this->assertContains((string)($e->errorInfo[1] ?? ''), ['1062', '1586']);
        }
    }

    /** hydrate باید slot_date را برگرداند و ردیف ناسالم (NULL ها) نه TypeError بدهد (SEO-23-13) */
    public function test_hydrate_tolerates_null_schema_columns(): void
    {
        $this->db->query(
            'INSERT INTO seo_executions (ad_id, user_id, status, ip_address, started_at, execution_date, slot_date, created_at)
             VALUES (?, ?, ?, NULL, NULL, CURDATE(), NULL, NOW())',
            [$this->adA, $this->userId, 'started'],
        );
        $legacyId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');

        $row = $this->model->find($legacyId);
        // بدون TypeError — پراپرتی‌های nullable شدند (FIX-Q4-SEO23-13)
        $this->assertNotNull($row);
        $this->assertNull($row->ip_address);
        $this->assertNull($row->started_at);
        $this->assertSame('started', (string)$row->status);
    }
}
