<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\InfluencerVerification;
use App\Models\Investment;
use App\Models\InvestmentProfit;
use App\Models\KYCVerification;
use App\Models\LotteryChanceLog;
use App\Models\LotteryParticipation;
use App\Models\LotteryRound;
use App\Models\LotteryVote;
use App\Models\NotificationPreference;
use App\Models\SocialTaskExecutionModel;
use App\Models\TradingRecord;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * S16 — قفل‌کنندهٔ امنیتی لایهٔ Models (بچ S16 — ۹۹ فایل، خط‌به‌خط).
 *
 * پین‌کردن ۱۳ فیکس بچ S16:
 *  ① FIX-S16-1  — Investment::findForUpdate قفل بدبینانهٔ واقعی + fail-closed
 *                 (بدون تراکنش فعال → RuntimeException).
 *  ② FIX-S16-3  — جریمهٔ نرخ اختلاف در calculateReputationGrade واقعاً کسر می‌شود
 *                 (نرخ اختلاف بالا هرگز نمره را بالا نمی‌برد).
 *  ③ FIX-S16-4  — getCameraRequest وضعیت‌ها را bind می‌کند نه درون‌یابی خام.
 *  ④ FIX-S16-5  — KYCVerification::update کلید ناشناخته را رد می‌کند (throw).
 *  ⑤ FIX-S16-6  — TradingRecord create/update سفیدلیست ستون.
 *  ⑥ FIX-S16-7  — InfluencerVerification::updateStatus سفیدلیست کلید.
 *  ⑦ FIX-S16-8  — LotteryParticipation create/update سفیدلیست.
 *  ⑧ FIX-S16-9  — LotteryVote::create سفیدلیست.
 *  ⑨ FIX-S16-10 — LotteryRound create/update سفیدلیست.
 *  ⑩ FIX-S16-11 — LotteryChanceLog::create سفیدلیست.
 *  ⑪ FIX-S16-12 — NotificationPreference::updateForUser گارد مدل‌سطح.
 *  ⑫ FIX-S16-13 — InvestmentProfit::create سفیدلیست.
 *
 * سبک خانه: Database با Mockery مک می‌شود (بدون DB واقعی) —
 * آینهٔ tests/Unit/Models/FraudReportTest.php.
 */
final class S16ModelsSecurityPinningTest extends TestCase
{
    /** @var \Core\Database&\Mockery\MockInterface */
    private \Core\Database $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock('Core\Database');
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** کپچرِ SQL ارسالی به prepare + کنترلِ execute — $captured با reference پر می‌شود */
    private function capturePrepare(array &$captured, bool $executeResult = true): void
    {
        $captured = ['sql' => '', 'values' => []];
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()
            ->with(m::on(function (array $values) use (&$captured): bool {
                $captured['values'] = $values;
                return true;
            }))
            ->andReturn($executeResult);
        $this->db->shouldReceive('prepare')->once()
            ->with(m::on(function (string $sql) use (&$captured): bool {
                $captured['sql'] = $sql;
                return true;
            }))
            ->andReturn($stmt);
        $this->db->shouldReceive('lastInsertId')->andReturn('7')->byDefault();
    }

    // ─────────────────────────────────────────────────────────────────
    // ① FIX-S16-1 — Investment::findForUpdate واقعاً قفل می‌گذارد
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function investment_find_for_update_fails_closed_without_active_transaction(): void
    {
        $model = new Investment($this->db);
        $this->db->shouldReceive('inTransaction')->once()->andReturn(false);

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('requires an active transaction');
        $model->findForUpdate(5);
    }

    /** @test */
    public function investment_find_for_update_issues_real_pessimistic_lock(): void
    {
        $model = new Investment($this->db);
        $this->db->shouldReceive('inTransaction')->once()->andReturn(true);
        $this->db->shouldReceive('fetch')->once()
            ->with(m::on(static fn (string $sql): bool =>
                str_contains($sql, 'FOR UPDATE') && str_contains($sql, 'investments')
            ), [5])
            ->andReturn((object)['id' => 5, 'profit_earned' => '10']);

        $row = $model->findForUpdate(5);
        $this->assertNotNull($row);
        $this->assertSame(5, (int)$row->id);
    }

    // ─────────────────────────────────────────────────────────────────
    // ② FIX-S16-3 — جریمهٔ نرخ اختلاف وارونه نباشد
    // ─────────────────────────────────────────────────────────────────

    /**
     * نرخ اختلاف بالا باید نمره را پایین بیاورد نه بالا.
     * (private بودن متد با Reflection صدا زده می‌شود — قرارداد خروجی آرایهٔ گِرِید)
     */
    /** @test */
    public function reputation_grade_penalizes_high_dispute_rate(): void
    {
        $model = new \App\Models\InfluencerModel($this->db);
        $method = new \ReflectionMethod($model::class, 'calculateReputationGrade');
        $method->setAccessible(true);

        $clean = $method->invoke($model, 100, 95, 0);   // بدون اختلاف
        $bad   = $method->invoke($model, 100, 95, 40);  // اختلاف ۴۰٪
        $mid   = $method->invoke($model, 100, 95, 20);  // اختلاف ۲۰٪

        $this->assertSame('A', $clean['letter']);
        $this->assertNotSame('A', $bad['letter'], 'نرخ اختلاف ۴۰٪ هرگز نباید برنگردد');
        // نمرهٔ با اختلاف باید اکیداً بدتر از بدون اختلاف باشد
        $order = ['A' => 4, 'B' => 3, 'C' => 2, 'D' => 1, 'F' => 0];
        $this->assertGreaterThan($order[$bad['letter']], $order[$clean['letter']]);
        $this->assertGreaterThan($order[$mid['letter']], $order[$clean['letter']]);
    }

    // ─────────────────────────────────────────────────────────────────
    // ③ FIX-S16-4 — getCameraRequest بدون درون‌یابی خام
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function camera_request_with_empty_status_list_queries_nothing(): void
    {
        $model = new SocialTaskExecutionModel($this->db);
        $this->db->shouldNotReceive('fetch');
        $this->assertNull($model->getCameraRequest(3, ['', '   ']));
    }

    /** @test */
    public function camera_request_binds_statuses_via_placeholders(): void
    {
        $model = new SocialTaskExecutionModel($this->db);
        $captured = ['sql' => '', 'values' => []];
        $this->db->shouldReceive('fetch')->once()
            ->with(m::on(function (string $sql) use (&$captured): bool {
                $captured['sql'] = $sql;
                // هیچ وضعیتی به‌صورت خام داخل IN نباشد
                return !str_contains($sql, "'completed'")
                    && !str_contains($sql, "'pending'")
                    && substr_count($sql, '?') === 3;
            }), m::on(function (array $values) use (&$captured): bool {
                $captured['values'] = $values;
                return true;
            }))
            ->andReturn((object)['id' => 1, 'status' => 'pending']);

        $row = $model->getCameraRequest(9, ['completed', 'pending']);
        $this->assertNotNull($row);
        $this->assertSame(9, (int)$captured['values'][0], 'execution_id باید پارامتر اول باشد');
        $this->assertContains('completed', $captured['values']);
        $this->assertContains('pending', $captured['values']);
    }

    // ─────────────────────────────────────────────────────────────────
    // ④ FIX-S16-5 — KYCVerification::update سفیدلیست
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function kyc_update_rejects_unknown_column(): void
    {
        $model = new KYCVerification($this->db);
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid KYC update column');
        $model->update(1, ['verified_at = NOW(); DROP TABLE users' => 'x']);
    }

    /** @test */
    public function kyc_update_accepts_whitelisted_column(): void
    {
        $model = new KYCVerification($this->db);
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('rowCount')->andReturn(1);
        $this->db->shouldReceive('query')->once()
            ->with(m::on(static fn (string $sql): bool =>
                str_contains($sql, '`status` = ?') && !str_contains($sql, 'password')
            ), m::type('array'))
            ->andReturn($stmt);

        $this->assertTrue($model->update(1, ['status' => 'verified']));
    }

    // ─────────────────────────────────────────────────────────────────
    // ⑤ FIX-S16-6 — TradingRecord سفیدلیست
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function trading_record_update_rejects_unknown_column(): void
    {
        $model = new TradingRecord($this->db);
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid trading record column');
        $model->update(1, ['admin_id' => 2, 'x_evil' => 1]);
    }

    /** @test */
    public function trading_record_create_silently_drops_non_whitelisted_keys(): void
    {
        $model = new TradingRecord($this->db);
        $captured = [];
        $this->capturePrepare($captured, false);
        $id = $model->create([
            'admin_id' => 2, 'direction' => 'buy', 'pair' => 'XAUUSD',
            'amount' => '1', 'open_price' => '2000', 'currency' => 'usdt',
            'status' => 'open', 'user_id' => 3,
            '__is_admin_from_client__' => true, // کلید شبح باید فیلتر شود
        ]);
        $this->assertNull($id, 'execute=false → null');
        $this->assertStringContainsString('`admin_id`', $captured['sql']);
        $this->assertStringNotContainsString('__is_admin_from_client__', $captured['sql']);
        $this->assertStringNotContainsString('__is_admin_from_client__', implode(',', array_map('strval', $captured['values'])));
    }

    // ─────────────────────────────────────────────────────────────────
    // ⑥ FIX-S16-7 — InfluencerVerification::updateStatus سفیدلیست
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function influencer_verification_update_status_rejects_unknown_column(): void
    {
        $model = new InfluencerVerification($this->db);
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid verification update column');
        $model->updateStatus(1, 'approved', ['status' => 'hacked']);
    }

    /** @test */
    public function influencer_verification_update_status_accepts_whitelisted_keys(): void
    {
        $model = new InfluencerVerification($this->db);
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with(m::type('array'))->andReturn(true);
        $this->db->shouldReceive('prepare')->once()
            ->with(m::on(static fn (string $sql): bool =>
                str_contains($sql, '`approved_at` = ?') && str_contains($sql, '`admin_id` = ?')
            ))
            ->andReturn($stmt);

        $this->assertTrue($model->updateStatus(1, 'approved', [
            'approved_at' => date('Y-m-d H:i:s'),
            'admin_id' => 4,
        ]));
    }

    // ─────────────────────────────────────────────────────────────────
    // ⑦ FIX-S16-8 — LotteryParticipation سفیدلیست
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function lottery_participation_update_rejects_unknown_column(): void
    {
        $model = new LotteryParticipation($this->db);
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid lottery participation column');
        $model->update(1, ['chance_score' => 5, 'is_admin' => 1]);
    }

    /** @test */
    public function lottery_participation_create_filters_rogue_keys(): void
    {
        $model = new LotteryParticipation($this->db);
        $captured = [];
        $this->capturePrepare($captured, false);
        $id = $model->create([
            'user_id' => 3, 'round_id' => 1, 'ticket_number' => '1,2,3',
            'chance_score' => 100.0, 'status' => 'active',
            'winner_user_id' => 3, // کلید شبح — ستون ناموجود
        ]);
        $this->assertNull($id);
        $this->assertStringNotContainsString('winner_user_id', $captured['sql']);
        $this->assertStringContainsString('`ticket_number`', $captured['sql']);
    }

    // ─────────────────────────────────────────────────────────────────
    // ⑧ FIX-S16-9 — LotteryVote::create سفیدلیست
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function lottery_vote_create_filters_rogue_keys(): void
    {
        $model = new LotteryVote($this->db);
        $captured = [];
        $this->capturePrepare($captured, false);
        $id = $model->create([
            'user_id' => 3, 'daily_number_id' => 2, 'voted_number' => '17',
            'role' => 'admin', // کلید شبح
        ]);
        $this->assertNull($id);
        $this->assertStringContainsString('`daily_number_id`', $captured['sql']);
        $this->assertStringNotContainsString('`role`', $captured['sql']);
        $this->assertStringContainsString('`is_deleted`', $captured['sql'], 'پیش‌فرض is_deleted=0 حفظ شود');
    }

    // ─────────────────────────────────────────────────────────────────
    // ⑨ FIX-S16-10 — LotteryRound سفیدلیست
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function lottery_round_update_rejects_unknown_column(): void
    {
        $model = new LotteryRound($this->db);
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid lottery round column');
        $model->update(1, ['status' => 'active', 'winner_user_id = 1; --' => 'x']);
    }

    /** @test */
    public function lottery_round_update_accepts_whitelisted_status_transition(): void
    {
        $model = new LotteryRound($this->db);
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('rowCount')->andReturn(1);
        $this->db->shouldReceive('query')->once()
            ->with(m::on(static fn (string $sql): bool =>
                str_contains($sql, '`status` = ?') && str_contains($sql, '`winner_user_id` = ?')
            ), m::type('array'))
            ->andReturn($stmt);

        $this->assertTrue($model->update(1, ['status' => 'active', 'winner_user_id' => null, 'draw_at' => null]));
    }

    // ─────────────────────────────────────────────────────────────────
    // ⑩ FIX-S16-11 — LotteryChanceLog::create سفیدلیست
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function lottery_chance_log_create_filters_rogue_keys(): void
    {
        $model = new LotteryChanceLog($this->db);
        $captured = [];
        $this->capturePrepare($captured, false);
        $id = $model->create([
            'participation_id' => 1, 'user_id' => 3, 'round_id' => 2,
            'date' => '2026-09-15', 'score_before' => 100, 'score_change' => -2,
            'score_after' => 98, 'reason' => 'vote',
            'ip_address' => '1.2.3.4', // کلید شبح
        ]);
        $this->assertNull($id);
        $this->assertStringContainsString('`participation_id`', $captured['sql']);
        $this->assertStringNotContainsString('`ip_address`', $captured['sql']);
    }

    // ─────────────────────────────────────────────────────────────────
    // ⑪ FIX-S16-12 — NotificationPreference گارد مدل‌سطح
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function notification_preference_update_rejects_unknown_field(): void
    {
        $model = new NotificationPreference($this->db);
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid notification preference field');
        $model->updateForUser(3, ['email_enabled' => 1, 'in_app_deposit' => 1, 'super_field' => 1]);
    }

    /** @test */
    public function notification_preference_update_accepts_whitelisted_field(): void
    {
        $model = new NotificationPreference($this->db);
        $stmt = m::mock(\PDOStatement::class);
        $this->db->shouldReceive('query')->once()
            ->with(m::on(static fn (string $sql): bool =>
                str_contains($sql, '`email_enabled` = ?') && str_contains($sql, 'notification_preferences_v2')
            ), m::type('array'))
            ->andReturn($stmt);

        $this->assertTrue($model->updateForUser(3, ['email_enabled' => 1]));
    }

    // ─────────────────────────────────────────────────────────────────
    // ⑫ FIX-S16-13 — InvestmentProfit::create سفیدلیست
    // ─────────────────────────────────────────────────────────────────

    /** @test */
    public function investment_profit_create_filters_rogue_keys(): void
    {
        $model = new InvestmentProfit($this->db);
        $captured = [];
        $this->capturePrepare($captured, true);
        $id = $model->create([
            'investment_id' => 1, 'user_id' => 3, 'amount' => '5',
            'gross_amount' => '5', 'net_amount' => '4.5', 'currency' => 'usdt',
            'profit_type' => 'profit', 'status' => 'paid',
            'balance_before' => '0', 'balance_after' => '4.5',
            'is_admin' => 1, // کلید شبح
        ]);
        $this->assertSame(7, $id);
        $this->assertStringContainsString('`investment_id`', $captured['sql']);
        $this->assertStringNotContainsString('`is_admin`', $captured['sql']);
    }
}
