<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\SeoExecution;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SEO-23-01 (فاز ۱ — ریدایرکت شمارنده): قرارداد nonce یک‌بارمصرفِ کلیک سئو.
 *
 * پوشش:
 *   - issueClickToken: صدور اتمیک توکن تازه ۴۸هگز وقتی UPDATE برنده می‌شود
 *   - issueClickToken: رندر دوم → توکنِ زندهٔ قبلی برگردانده می‌شود (بدون بازنویسی)
 *   - issueClickToken: اجرای قبلاً اثبات‌شده → null (توکن جدید لازم نیست)
 *   - consumeClickToken: تک UPDATE با همهٔ گاردها (مالکیت/وضعیت/توکن/مصرف‌نشده/انقضا)
 *   - consumeClickToken: شکست (بازپخش، رقابت، مالک دیگر، منقضی) ⇒ false
 *
 * سبک خانه: Database با Mockery مک می‌شود — آینهٔ tests/Unit/Models/FraudReportTest.
 */
final class SeoClickProofTokenTest extends TestCase
{
    /** @var \Core\Database&\Mockery\MockInterface */
    private \Core\Database $db;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock('Core\Database');
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    private function makeModel(): SeoExecution
    {
        return new SeoExecution($this->db);
    }

    /** @param array<string, mixed> $overrides */
    private function dbRow(array $overrides = []): array
    {
        return array_merge([
            'id' => 11,
            'ad_id' => 1,
            'user_id' => 2,
            'status' => 'started',
            'ip_address' => '127.0.0.1',
            'started_at' => '2026-11-02 10:00:00',
            'created_at' => '2026-11-02 10:00:00',
            'click_token' => null,
            'click_token_expires_at' => null,
            'click_counted_at' => null,
        ], $overrides);
    }

    public function test_issue_click_token_returns_fresh_48hex_token_when_update_wins(): void
    {
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with(m::on(function (array $args): bool {
            // [token, ttl, id]
            return is_string($args[0] ?? null) && preg_match('/^[0-9a-f]{48}$/', $args[0]) === 1
                && $args[1] === SeoExecution::CLICK_TOKEN_TTL_SECONDS && $args[2] === 11;
        }))->andReturn(true);
        $stmt->shouldReceive('rowCount')->once()->andReturn(1);

        $this->db->shouldReceive('prepare')->once()->with(m::on(
            static fn (string $sql): bool => str_contains($sql, 'click_counted_at IS NULL')
                && str_contains($sql, 'click_token IS NULL OR click_token_expires_at <= NOW()')
        ))->andReturn($stmt);

        $token = $this->makeModel()->issueClickToken(11);

        $this->assertIsString($token);
        $this->assertRegExp('/^[0-9a-f]{48}$/', $token);
    }

    public function test_issue_click_token_returns_existing_live_token_on_second_render(): void
    {
        // UPDATE می‌بازد (توکن زنده از قبل هست) ⇒ باید توکن موجود از DB خوانده شود
        $update = m::mock(\PDOStatement::class);
        $update->shouldReceive('execute')->once()->andReturn(true);
        $update->shouldReceive('rowCount')->once()->andReturn(0);

        $select = m::mock(\PDOStatement::class);
        $select->shouldReceive('execute')->once()->with([11])->andReturn(true);
        $select->shouldReceive('fetch')->once()->andReturn($this->dbRow([
            'click_token' => 'aabbccdd11223344aabbccdd11223344aabbccdd11223344',
            'click_token_expires_at' => '2099-01-01 00:00:00',
            'click_counted_at' => null,
        ]));

        $this->db->shouldReceive('prepare')->twice()->andReturnUsing(
            static fn (string $sql) => str_contains($sql, 'UPDATE seo_executions') ? $update : $select
        );

        $token = $this->makeModel()->issueClickToken(11);

        // توکن زندهٔ قبلی برگشت — بدون بازنویسی (رفرش صفحه UX را نمی‌شکند)
        $this->assertSame('aabbccdd11223344aabbccdd11223344aabbccdd11223344', $token);
    }

    public function test_issue_click_token_returns_null_when_click_already_proven(): void
    {
        $update = m::mock(\PDOStatement::class);
        $update->shouldReceive('execute')->once()->andReturn(true);
        $update->shouldReceive('rowCount')->once()->andReturn(0);

        $select = m::mock(\PDOStatement::class);
        $select->shouldReceive('execute')->once()->with([11])->andReturn(true);
        $select->shouldReceive('fetch')->once()->andReturn($this->dbRow([
            'click_counted_at' => '2026-11-02 10:05:00',
        ]));

        $this->db->shouldReceive('prepare')->twice()->andReturnUsing(
            static fn (string $sql) => str_contains($sql, 'UPDATE seo_executions') ? $update : $select
        );

        $this->assertNull($this->makeModel()->issueClickToken(11));
    }

    public function test_consume_click_token_is_single_atomic_guarded_update(): void
    {
        $capturedSql = '';
        $capturedArgs = [];
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->with(m::on(function (array $args) use (&$capturedArgs): bool {
            $capturedArgs = $args;
            return true;
        }))->andReturn(true);
        $stmt->shouldReceive('rowCount')->once()->andReturn(1);

        $this->db->shouldReceive('prepare')->once()->with(m::on(
            static function (string $sql) use (&$capturedSql): bool {
                $capturedSql = $sql;
                return true;
            }
        ))->andReturn($stmt);

        $this->assertTrue($this->makeModel()->consumeClickToken(11, 2, 'tok', '9.9.9.9', 'UA-Click/1.0'));

        // گاردهای کامل در همان تک UPDATE — بدون TOCTOU
        // 🛡️ FIX-T23H-01: دو شاهد جدید (click_ip/click_user_agent) هم در همان
        // UPDATE اتمیک نوشته می‌شوند و آرگومان‌ها به همان ترتیب پاس می‌شوند.
        $this->assertSame(['9.9.9.9', 'UA-Click/1.0', 11, 2, 'tok'], $capturedArgs);
        foreach ([
            "user_id = ?",              // مالکیت: توکن کاربر دیگر بی‌اثر
            "click_token = ?",          // تطابق توکن
            "status = 'started'",       // اجرای بسته قابل شمارش نیست
            'click_counted_at IS NULL', // یک‌بارمصرف: بازپخش رد
            'click_token_expires_at > NOW()', // انقضا
            'click_counted_at = NOW()', // مهر سرور
            'click_ip = ?',             // 🛡️ FIX-T23H-01: شاهد IP لحظهٔ کلیک
            'click_user_agent = ?',     // 🛡️ FIX-T23H-01: شاهد UA لحظهٔ کلیک
        ] as $guard) {
            $this->assertStringContainsString($guard, $capturedSql, "گارد «{$guard}» باید در UPDATE مصرف توکن باشد");
        }
    }

    public function test_consume_click_token_returns_false_on_replay_race_or_foreign_owner(): void
    {
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->andReturn(true);
        $stmt->shouldReceive('rowCount')->once()->andReturn(0);

        $this->db->shouldReceive('prepare')->once()->andReturn($stmt);

        // بازپخش لینک / رقابت دو تب / مالک دیگر / توکن منقضی — همه یک نتیجه: false
        $this->assertFalse($this->makeModel()->consumeClickToken(11, 2, 'tok'));
    }

    public function test_ttl_constant_is_fifteen_minutes(): void
    {
        // پنجرهٔ کوتاه کافی: کلیک باید نزدیک رندر صفحهٔ اجرا اتفاق بیفتد
        $this->assertSame(900, SeoExecution::CLICK_TOKEN_TTL_SECONDS);
    }
}
