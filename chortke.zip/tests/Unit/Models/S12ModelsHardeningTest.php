<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Models\InfluencerVerification;
use App\Models\Investment;
use Core\Database;
use PHPUnit\Framework\TestCase;

/**
 * بچ S12 — قفل رفتاری فیکس‌های لنز mass-assignment/SQL/concurrency در app/Models بخش ۱:
 *
 *  - FIX-S12-3: InfluencerVerification::updateStatus کلیدهای $fields را بدون
 *    whitelist به‌عنوان «نام ستون» درون‌یابی می‌کرد. اکنون fail-loud است؛ کلیدهای
 *    ناشناخته InvalidArgumentException می‌دهند و کلیدهای مجاز (مصرفِ فعلی
 *    VerificationService) سبز می‌مانند.
 *  - FIX-S12-4: Investment::findForUpdate فقط find() ساده بود (بدون FOR UPDATE) —
 *    قرارداد قفل را می‌داد ولی قفل نمی‌گرفت. اکنون: بیرون تراکنش → RuntimeException؛
 *    داخل تراکنش روی MariaDB واقعی → SELECT … FOR UPDATE موفق.
 *
 * تست‌های S12-4 روی MariaDB/Redis واقعی اجرا می‌شوند (همان قرارداد S6LockingReadRoutingTest).
 */
final class S12ModelsHardeningTest extends TestCase
{
    // ─────────────────────────────────────────────────────────────
    // FIX-S12-3 — InfluencerVerification::updateStatus whitelist
    // ─────────────────────────────────────────────────────────────

    public function test_update_status_rejects_unknown_column_keys(): void
    {
        $model = new InfluencerVerification(Database::getInstance());

        try {
            $model->updateStatus(1, 'approved', [
                'approved_at' => date('Y-m-d H:i:s'),
                'evil_col' => 'x', // کلید خارج از whitelist — باید fail-loud شود
            ]);
            $this->fail('Expected InvalidArgumentException for unknown column key');
        } catch (\InvalidArgumentException $e) {
            $this->assertStringContainsString('evil_col', $e->getMessage());
        }
    }

    public function test_update_status_accepts_whitelisted_keys_and_locks_id(): void
    {
        // اجرا روی ردیف ناموجود: قرارداد فعلی متد، بولیِ execute() است نه rowCount —
        // «true بدون استثنا» یعنی whitelist برای همهٔ کلیدهای مجاز عبور کرد و SQL معتبر بود.
        // (کلید نامجاز در تست قبل InvalidArgumentException می‌دهد — fail-loud اثبات شد.)
        $model = new InfluencerVerification(Database::getInstance());
        $ok = $model->updateStatus(999999999, 'approved', [
            'post_url' => 'https://example.com/p',
            'proof_url' => 'https://example.com/s',
            'proof_data' => json_encode(['k' => 'v']),
            'submitted_at' => date('Y-m-d H:i:s'),
            'approved_at' => date('Y-m-d H:i:s'),
            'admin_id' => 1,
            'rejection_reason' => null,
        ]);
        $this->assertTrue($ok);
    }

    // ─────────────────────────────────────────────────────────────
    // FIX-S12-4 — Investment::findForUpdate قرارداد واقعی قفل
    // ─────────────────────────────────────────────────────────────

    public function test_find_for_update_outside_transaction_fails_loud(): void
    {
        $model = new Investment(Database::getInstance());
        $db = Database::getInstance();

        if ($db->inTransaction()) {
            $db->rollBack();
        }

        try {
            $model->findForUpdate(1);
            $this->fail('Expected RuntimeException outside an active transaction');
        } catch (\RuntimeException $e) {
            $this->assertStringContainsStringIgnoringCase('transaction', $e->getMessage());
        }
    }

    public function test_find_for_update_inside_transaction_locks_row(): void
    {
        $db = Database::getInstance();
        $model = new Investment($db);

        $db->beginTransaction();
        try {
            $row = $model->findForUpdate(999999999);
            $this->assertNull($row, 'ردیف ناموجود باید null بدهد اما قفل‌گیری SQL اجرا شده باشد');
        } finally {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
        }
    }
}
