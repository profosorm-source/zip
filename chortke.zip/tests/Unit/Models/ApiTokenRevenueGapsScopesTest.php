<?php

declare(strict_types=1);

namespace Tests\Unit\Models;

use App\Middleware\ApiAuthMiddleware;
use App\Models\ApiToken;
use PHPUnit\Framework\TestCase;

/**
 * 📱 FIX-REVGEN-REAPLY (بازکاربرد REVGEN روی درخت FIX-MOBILE-06 — ۲۰۲۶-۱۱-۰۳):
 * اسکوپ‌های رفرال (referral.*) — کاتالوگ + سلسله‌مراتب.
 *
 * قرارداد (هم‌الگوی ApiTokenSeoScopesTest):
 *  ① در ALLOWED_SCOPES و کاتالوگ /auth/scopes با متادیتای استاندارد
 *  ② exact-only نیستند
 *  ③ read سراسری → دامنهٔ read؛ write سراسری → دامنهٔ read و write
 *  ④ entity: referral.write → referral.read
 *
 * پین رگرسیون بین-بچی: اسکوپ‌های exact-only بچ FIX-MOBILE-06 (transfer.write)
 * و بچ‌های قبل (wallet.withdraw/account.security) دست‌نخورده می‌مانند.
 */
final class ApiTokenRevenueGapsScopesTest extends TestCase
{
    public function test_scopes_in_allowlist_and_catalog(): void
    {
        foreach (['referral.read', 'referral.write'] as $scope) {
            $this->assertContains($scope, ApiToken::ALLOWED_SCOPES, "{$scope} باید در allowlist باشد");
        }

        $byScope = [];
        foreach (ApiToken::scopeCatalog() as $row) {
            $byScope[$row['scope']] = $row;
        }

        foreach (['referral.read', 'referral.write'] as $scope) {
            $this->assertArrayHasKey($scope, $byScope, "کاتالوگ عمومی /auth/scopes باید {$scope} را فهرست کند");
            $this->assertFalse($byScope[$scope]['exact_only']);
            $this->assertSame('standard', $byScope[$scope]['risk']);
            $this->assertNotEmpty($byScope[$scope]['description']);
        }
    }

    public function test_scope_hierarchy_coverage(): void
    {
        $m = new \ReflectionMethod(ApiAuthMiddleware::class, 'hasScope');
        $m->setAccessible(true);
        $middleware = (new \ReflectionClass(ApiAuthMiddleware::class))->newInstanceWithoutConstructor();
        $has = static fn(array $scopes, string $need): bool => $m->invoke($middleware, $scopes, $need);

        // read سراسری → *.read (نه *.write)
        $this->assertTrue($has(['read'], 'referral.read'));
        $this->assertFalse($has(['read'], 'referral.write'));

        // write سراسری → هر دو
        $this->assertTrue($has(['write'], 'referral.read'));
        $this->assertTrue($has(['write'], 'referral.write'));

        // entity: write → read همان موجودیت
        $this->assertTrue($has(['referral.write'], 'referral.read'));

        // موجودیت‌ها همدیگر را نمی‌پوشانند (رفرال ≠ محتوا ≠ سئو ≠ کیف پول)
        $this->assertFalse($has(['referral.write'], 'content.write'));
        $this->assertFalse($has(['content.write'], 'referral.write'));
        $this->assertFalse($has(['seo.write'], 'referral.read'));
        $this->assertFalse($has(['wallet.write'], 'referral.write'));

        // wildcard ادمین
        $this->assertTrue($has(['*'], 'referral.write'));
    }

    public function test_exact_only_scopes_unchanged(): void
    {
        $catalog = [];
        foreach (ApiToken::scopeCatalog() as $row) {
            $catalog[$row['scope']] = $row;
        }
        // رگرسیون FIX-M11-R22-13 — اسکوپ‌های پرریسک exact-only ماندند
        $this->assertTrue($catalog['wallet.withdraw']['exact_only']);
        $this->assertTrue($catalog['account.security']['exact_only']);
        // رگرسیون FIX-MOBILE-06 — انتقال بین‌کاربری exact-only ماند
        $this->assertTrue($catalog['transfer.write']['exact_only']);
        // و اسکوپ‌های سئو (FIX-MOBILE-04) هم دست‌نخورده ماندند
        $this->assertFalse($catalog['seo.read']['exact_only']);
        $this->assertFalse($catalog['seo.write']['exact_only']);
        // اسکوپ‌های content بچ FIX-MOBILE-06 هم استاندارد ماندند
        $this->assertFalse($catalog['content.read']['exact_only']);
        $this->assertFalse($catalog['content.write']['exact_only']);
    }
}
