<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use PHPUnit\Framework\TestCase;
use App\Services\ApiTokenService;
use App\Middleware\ApiAuthMiddleware;
use Mockery as m;

/**
 * W4-E — قرارداد انقضای توکن API
 *
 * پوشش هدف:
 *  1) هر مسیر صدور، همیشه expires_at ست می‌کند و پیش‌فرض canonical = ۹۰ روز است.
 *  2) renewToken: تمدید به now+90d، کلمپ ≤365، رد ناموجود/باطل.
 *  3) توکن منقضی در نقطهٔ احراز هویت (ApiAuthMiddleware) رد می‌شود — pin شدن
 *     شرط SQL (at.expires_at IS NULL OR at.expires_at > NOW()).
 */
class ApiTokenExpiryW4Test extends TestCase
{
    /** @var \App\Contracts\LoggerInterface&\Mockery\MockInterface */
    private \App\Contracts\LoggerInterface $logger;
    /** @var \App\Models\ApiToken&\Mockery\MockInterface */
    private \App\Models\ApiToken $apiTokenModel;
    /** @var \App\Models\User&\Mockery\MockInterface */
    private \App\Models\User $userModel;
    /** @var \Core\RateLimiter&\Mockery\MockInterface */
    private \Core\RateLimiter $rateLimiter;
    /** @var \App\Services\Auth\TwoFactorService&\Mockery\MockInterface */
    private \App\Services\Auth\TwoFactorService $twoFactorService;
    private ApiTokenService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->logger = m::mock('App\Contracts\LoggerInterface');
        $this->apiTokenModel = m::mock('App\Models\ApiToken');
        $this->userModel = m::mock('App\Models\User');
        $this->rateLimiter = m::mock('Core\RateLimiter');
        $this->twoFactorService = m::mock('App\Services\Auth\TwoFactorService');

        $this->logger->shouldIgnoreMissing();

        $this->service = new ApiTokenService(
            $this->logger,
            $this->apiTokenModel,
            $this->userModel,
            $this->rateLimiter,
            $this->twoFactorService
        );
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /**
     * createToken را mock می‌کند و مقدار expires_at پاس‌داده‌شده (آرگومان پنجم) را برمی‌گرداند.
     * @param list<object> $user
     */
    private function mockUserContext(int $userId, int $activeCount = 0): void
    {
        $user = (object)['id' => $userId, 'role' => 'user', 'status' => 'active', 'email_verified_at' => '2026-01-01 00:00:00'];
        $this->userModel->shouldReceive('findById')->andReturn($user);
        $this->mockAtomicCapPath($userId, $activeCount);
    }

    /*
    | FIX-YAFTE5 (یافته ۵): مسیر اتمیک FIX-M11-TOK-01 — createTokenForUser از
    | insertWithinActiveCap می‌گذرد: getDb + countActiveByUserIdForUpdate داخل
    | تراکنش (بدون countActiveByUserId قدیمی). تست قبلی گرافِ فراخوانی قدیمی را
    | مک می‌کرد؛ اکنون قرارداد واقعی پیاده‌سازی (FIX-M11-R22-22/23) پین می‌شود.
    */
    private function mockAtomicCapPath(int $userId, int $activeCount = 0): void
    {
        $db = m::mock('Core\Database');
        $db->shouldReceive('beginTransaction')->andReturn(true)->byDefault();
        $db->shouldReceive('commit')->andReturn(true)->byDefault();
        $db->shouldReceive('rollback')->andReturn(true)->byDefault();
        $db->shouldIgnoreMissing();
        $this->apiTokenModel->shouldReceive('getDb')->andReturn($db)->byDefault();
        $this->apiTokenModel->shouldReceive('countActiveByUserIdForUpdate')
            ->with($userId)->andReturn($activeCount)->byDefault();
        $this->apiTokenModel->shouldReceive('countActiveByUserId')
            ->with($userId)->andReturn($activeCount)->byDefault();
    }

    private function assertExpiryNearDays(?string $expiresAt, int $days, int $startTs, int $endTs, string $message = ''): void
    {
        $this->assertIsString($expiresAt, $message . ' (expires_at باید رشتهٔ دیتابیس باشد)');
        $ts = strtotime((string)$expiresAt);
        $this->assertNotFalse($ts, 'expires_at باید تاریخ معتبر باشد');
        $this->assertGreaterThanOrEqual($startTs + ($days - 1) * 86400, $ts, $message);
        $this->assertLessThanOrEqual($endTs + $days * 86400, $ts, $message);
    }

    /** @test */
    public function create_token_for_user_defaults_to_90_day_expiry(): void
    {
        $userId = 12;
        $this->mockUserContext($userId);

        $captured = null;
        $this->apiTokenModel->shouldReceive('createToken')
            ->once()
            ->andReturnUsing(function (...$args) use (&$captured) {
                $captured = $args[4]; // expires_at
                return 1;
            });

        $start = time();
        // هیچ expiresIn صریحی پاس نمی‌شود — پیش‌فرض canonical باید ۹۰ روز باشد.
        $result = $this->service->createTokenForUser($userId, 'W4 default TTL');
        $end = time();

        $this->assertTrue($result['success']);
        $this->assertExpiryNearDays($captured, 90, $start, $end, 'پیش‌فرض TTL باید ۹۰ روز باشد');
        $this->assertExpiryNearDays($result['payload']['expires_at'] ?? null, 90, $start, $end, 'payload باید همان expires_at را برگرداند');
    }

    /** @test */
    public function create_token_for_user_clamps_oversized_ttl_to_365_days(): void
    {
        $userId = 12;
        $this->mockUserContext($userId);

        $captured = null;
        $this->apiTokenModel->shouldReceive('createToken')
            ->once()
            ->andReturnUsing(function (...$args) use (&$captured) {
                $captured = $args[4];
                return 1;
            });

        $start = time();
        $result = $this->service->createTokenForUser($userId, 'W4 clamp', 5000);
        $end = time();

        $this->assertTrue($result['success']);
        $this->assertExpiryNearDays($captured, 365, $start, $end, 'کلمپ سقف ۳۶۵ روزه (F-A7-06) باید حفظ شود');
    }

    /** @test */
    public function issue_token_uses_90_day_default_expiry(): void
    {
        /*
        | FIX-YAFTE5 (یافته ۵): عمر جداشتهٔ FIX-M11-R22-5 — جفتِ login:
        | access کوتاه‌عمر (ACCESS_TTL_DAYS=۱ روز) + refresh لغزان (REFRESH_TTL_DAYS=۹۰
        | روز). پین قدیمی (access=۹۰ روز) پیش از این اصلاح بود.
        */
        $email = 'w4@example.com';
        $password = 'correct-password';

        $this->rateLimiter->shouldReceive('attempt')->andReturn(true);
        $this->rateLimiter->shouldReceive('clear')->andReturnNull();
        // FIX-YAFTE5: قفلِ نرمِ شناسه (FIX-M11-R22-21) — getAttempts پیش از بررسی اعتبارنامه
        $this->rateLimiter->shouldReceive('getAttempts')->andReturn(0);
        $this->rateLimiter->shouldReceive('incrementAttempts')->andReturnNull();

        $user = (object)[
            'id' => 21,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_BCRYPT),
            'role' => 'user',
            'status' => 'active',
            'two_factor_enabled' => 0,
            'two_factor_secret' => null,
            'email_verified_at' => '2026-01-01 00:00:00',
        ];
        $this->userModel->shouldReceive('findByEmail')->with($email)->once()->andReturn($user);
        $this->userModel->shouldReceive('findById')->andReturn($user);
        // FIX-YAFTE5: مسیر اتمیک صدور پس از اعتبارسنجی — همان قرارداد createTokenForUser
        $this->mockAtomicCapPath(21, 0);

        $captured = [];
        $this->apiTokenModel->shouldReceive('createToken')
            ->once()
            ->andReturnUsing(function (...$args) use (&$captured) {
                $captured = $args;
                return 1;
            });

        $start = time();
        $result = $this->service->issueToken($email, $password, 'W4 issued', 'read');
        $end = time();

        $this->assertTrue($result['success']);
        // args[4]=expires_at (access؛ ۱ روز) — args[6]=refresh_expires_at (۹۰ روز)
        $this->assertExpiryNearDays($captured[4] ?? null, ApiTokenService::ACCESS_TTL_DAYS, $start, $end, 'access باید کوتاه‌عمر باشد (FIX-M11-R22-5)');
        $this->assertExpiryNearDays($captured[6] ?? null, ApiTokenService::REFRESH_TTL_DAYS, $start, $end, 'refresh باید ۹۰ روزه باشد');
    }

    /** @test */
    public function renew_token_extends_expiry_by_90_days(): void
    {
        $tokenRow = (object)['id' => 5, 'user_id' => 7, 'revoked' => 0];
        $this->apiTokenModel->shouldReceive('findById')->with(5)->once()->andReturn($tokenRow);

        $captured = null;
        $this->apiTokenModel->shouldReceive('renewById')
            ->once()
            ->andReturnUsing(function (...$args) use (&$captured) {
                $captured = $args[1]; // newExpiresAt
                return true;
            });

        $start = time();
        $result = $this->service->renewToken(5);
        $end = time();

        $this->assertTrue($result['success']);
        $this->assertExpiryNearDays($captured, 90, $start, $end, 'تمدید باید expires_at را به now+90d برساند');
        $this->assertSame(90, $result['payload']['days'] ?? null);
        $this->assertSame($captured, $result['payload']['expires_at'] ?? null);
    }

    /** @test */
    public function renew_token_clamps_days_to_max_365(): void
    {
        $tokenRow = (object)['id' => 5, 'user_id' => 7, 'revoked' => 0];
        $this->apiTokenModel->shouldReceive('findById')->with(5)->once()->andReturn($tokenRow);

        $captured = null;
        $this->apiTokenModel->shouldReceive('renewById')
            ->once()
            ->andReturnUsing(function (...$args) use (&$captured) {
                $captured = $args[1];
                return true;
            });

        $start = time();
        $result = $this->service->renewToken(5, 1000);
        $end = time();

        $this->assertTrue($result['success']);
        $this->assertExpiryNearDays($captured, 365, $start, $end, 'تمدید هم باید به سقف ۳۶۵ روز کلمپ شود');
        $this->assertSame(365, $result['payload']['days'] ?? null);
    }

    /** @test */
    public function renew_token_rejects_unknown_id(): void
    {
        $this->apiTokenModel->shouldReceive('findById')->with(999)->once()->andReturn(null);
        $this->apiTokenModel->shouldReceive('renewById')->never();

        $result = $this->service->renewToken(999);

        $this->assertFalse($result['success']);
        $this->assertSame('TOKEN_NOT_FOUND', $result['code'] ?? null);
        $this->assertSame(404, $result['status'] ?? null);
    }

    /** @test */
    public function renew_token_rejects_revoked_token(): void
    {
        $tokenRow = (object)['id' => 5, 'user_id' => 7, 'revoked' => 1];
        $this->apiTokenModel->shouldReceive('findById')->with(5)->once()->andReturn($tokenRow);
        $this->apiTokenModel->shouldReceive('renewById')->never();

        $result = $this->service->renewToken(5);

        $this->assertFalse($result['success']);
        $this->assertSame('TOKEN_REVOKED', $result['code'] ?? null);
        $this->assertSame(409, $result['status'] ?? null);
    }

    /** @test */
    public function expired_token_is_rejected_at_authentication_point(): void
    {
        $db = m::mock('Core\Database');
        $rateLimiter = m::mock('Core\RateLimiter');
        $logger = m::mock('App\Contracts\LoggerInterface');
        $logger->shouldIgnoreMissing();

        $activeRow = (object)['id' => 21, 'token_id' => 5, 'scopes' => 'read', 'status' => 'active'];
        $capturedQuery = null;

        $db->shouldReceive('fetch')->andReturnUsing(function ($query, $params = []) use (&$capturedQuery, $activeRow) {
            if (strpos((string)$query, 'SHOW COLUMNS') !== false) {
                return false; // secret_version_expires_at پشتیبانی نمی‌شود
            }
            $capturedQuery = (string)$query;
            return $activeRow; // ردیف فعال — منقضی‌ها خودِ SQL فیلتر می‌کند
        });

        $middleware = new ApiAuthMiddleware($db, $rateLimiter, $logger, null);

        $ref = new \ReflectionMethod(ApiAuthMiddleware::class, 'validateTokenByHashAndVersion');
        $ref->setAccessible(true);

        $hash64 = str_repeat('a', 64);
        $result = $ref->invoke($middleware, $hash64, 'v2', 0);

        // pin: گیت‌های SQL سفت‌شده باشند (FIX-M11-R22-9)
        $this->assertNotNull($capturedQuery, 'کوئری احراز هویت باید اجرا شده باشد');
        $this->assertStringContainsString('at.revoked = 0', (string)$capturedQuery);
        $this->assertStringContainsString('u.email_verified_at IS NOT NULL', (string)$capturedQuery);
        $this->assertSame($activeRow, $result, 'ردیف فعال باید احراز شود');

        /*
        | FIX-YAFTE5 (یافته ۵): گیتِ انقضا طبق FIX-M11-R22-20 بعد از واکشی در PHP
        | اعمال می‌شود (نه داخل WHERE) — تا «توکنِ شناخته‌شده اما مرده» از «توکن
        | ناشناخته» تفکیک شود و کش منفی فقط برای اولی نوشته شود (گارد DoS replay).
        | سناریوی دوم همان قرارداد قدیم را پین می‌کند: ردیفِ منقضی → null → 401.
        */
        $db2 = m::mock('Core\Database');
        $db2->shouldReceive('fetch')->andReturnUsing(function ($query, $params = []) {
            if (strpos((string)$query, 'SHOW COLUMNS') !== false) {
                return false;
            }
            // ردیف شناخته‌شده اما منقضی — token_expires_at در گذشته
            return (object)[
                'id' => 21,
                'token_id' => 5,
                'scopes' => 'read',
                'status' => 'active',
                'token_expires_at' => date('Y-m-d H:i:s', time() - 3600),
            ];
        });
        $middleware2 = new ApiAuthMiddleware($db2, $rateLimiter, $logger, null);
        $result2 = $ref->invoke($middleware2, $hash64, 'v2', 0);
        $this->assertNull($result2, 'توکن منقضی باید در نقطهٔ احراز هویت رد شود (null → 401)');
    }
}
