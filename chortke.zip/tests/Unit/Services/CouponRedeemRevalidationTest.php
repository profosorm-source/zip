<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use PHPUnit\Framework\TestCase;
use App\Services\Shared\CouponService;
use Core\Exceptions\InvalidStateException;
use Mockery as m;

/**
 * 🛡️ FIX-10a-F4 (R10 audit P2) — رگرسیونِ اعتبارسنجیِ لحظهٔ مصرف کوپن.
 *
 * سناریوی رقابتی preview→redeem: یک preview معتبر (validateAndCalculate) تا
 * پایان TTL توکن (۱۵ دقیقه) قابلِ استفاده است؛ اگر در این فاصله کوپن غیرفعال/
 * منقضی شود یا سقفِ تخفیفش کاهش یابد، مصرف باید fail-closed رد شود و هیچ رکورد
 * redemption ثبت نگردد (کل سفارش/کمپینِ فراخوان rollback می‌شود).
 * مسیرِ مجاز (تخفیفِ اعمالی ≤ سقفِ فعلی، مثلاً سقف‌خورده به کارمزد در سفارش
 * اینفلوئنسر) باید بدون تغییر کار کند.
 */
class CouponRedeemRevalidationTest extends TestCase
{
    /** @var \App\Models\Coupon&\Mockery\MockInterface */
    private \App\Models\Coupon $couponModel;
    /** @var \App\Models\CouponRedemption&\Mockery\MockInterface */
    private \App\Models\CouponRedemption $redemptionModel;
    /** @var \Core\Database&\Mockery\MockInterface */
    private \Core\Database $database;
    /** @var \App\Contracts\LoggerInterface&\Mockery\MockInterface */
    private \App\Contracts\LoggerInterface $logger;
    /** @var \Core\TransactionWrapper&\Mockery\MockInterface */
    private \Core\TransactionWrapper $transactionWrapper;
    private CouponService $service;

    protected function setUp(): void
    {
        parent::setUp();
        // \get_client_ip() در CouponService::redeem ارزیابی می‌شود — helpers/security.php
        // توسط lazy-loader وابستهٔ helpers/functions.php در bootstrap لود می‌شود.

        $this->couponModel = m::mock('App\Models\Coupon');
        $this->redemptionModel = m::mock('App\Models\CouponRedemption');
        $this->database = m::mock('Core\Database');
        $this->logger = m::mock('App\Contracts\LoggerInterface');
        $this->logger->shouldIgnoreMissing();
        $this->transactionWrapper = m::mock('Core\TransactionWrapper');
        $this->transactionWrapper->shouldReceive('runWithRetry')
            ->andReturnUsing(fn (callable $closure) => $closure());

        $this->service = new CouponService(
            $this->transactionWrapper,
            $this->database,
            $this->logger,
            $this->couponModel,
            $this->redemptionModel
        );
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @param array<string, mixed> $over */
    private function coupon(array $over = []): \stdClass
    {
        return (object) array_merge([
            'id' => 1,
            'code' => 'SAVE10',
            'type' => 'percent',
            'value' => 10,
            'usage_limit' => 100,
            'usage_count' => 5,
            'applicable_to' => 'all',
            'min_purchase' => null,
            'max_discount' => null,
            'active' => 1,
            'start_date' => null,
            'end_date' => null,
        ], $over);
    }

    /**
     * مصرف با ردیفِ قفل‌شدهٔ مفروض — گاردِ رد باید پیش از هر بررسی/نوشتنِ بعدی رخ دهد.
     * @param array<string, mixed> $lockedRow
     */
    private function redeemLockedRow(array $lockedRow, ?string $applicableTo = null): bool
    {
        $this->couponModel->shouldReceive('findWithLock')->once()->with(1)->andReturn((object)$lockedRow);
        // در مسیرهای رد، هیچ بررسی/نوشتنِ بعد از گاردهای consumption-time نباید رخ دهد
        $this->redemptionModel->shouldNotReceive('hasUserUsedCouponForUpdate');
        $this->redemptionModel->shouldNotReceive('create');
        $this->couponModel->shouldNotReceive('incrementUsage');

        return $this->service->redeem(
            1, 5, '1000.0000', '100.0000', '900.0000', 'irt', 'story_order', 77, null, $applicableTo
        );
    }

    /** @test */
    public function redeem_rejects_coupon_deactivated_between_preview_and_redeem(): void
    {
        $this->expectException(InvalidStateException::class);
        $this->expectExceptionMessage('منقضی شده یا غیرفعال');

        // preview معتبر بوده (کوپن فعال)، اما در لحظهٔ مصرفِ تحتِ قفل ردیفِ غیرفعال دیده می‌شود
        $this->redeemLockedRow((array)$this->coupon(['active' => 0]));
    }

    /** @test */
    public function redeem_rejects_expired_coupon_between_preview_and_redeem(): void
    {
        $this->expectException(InvalidStateException::class);
        $this->expectExceptionMessage('منقضی شده یا غیرفعال');

        $this->redeemLockedRow((array)$this->coupon(['end_date' => date('Y-m-d H:i:s', time() - 60)]));
    }

    /** @test */
    public function redeem_rejects_coupon_not_yet_started_between_preview_and_redeem(): void
    {
        $this->expectException(InvalidStateException::class);
        $this->expectExceptionMessage('منقضی شده یا غیرفعال');

        $this->redeemLockedRow((array)$this->coupon(['start_date' => date('Y-m-d H:i:s', time() + 3600)]));
    }

    /** @test */
    public function redeem_enforces_applicability_at_consumption_time(): void
    {
        $this->expectException(InvalidStateException::class);
        $this->expectExceptionMessage('نوع عملیات');

        $this->redeemLockedRow((array)$this->coupon(['applicable_to' => 'deposit']), 'story_order');
    }

    /** @test */
    public function redeem_rejects_below_min_purchase_at_consumption_time(): void
    {
        $this->expectException(InvalidStateException::class);
        $this->expectExceptionMessage('حداقل');

        // مبلغ خرید (۱۰۰۰) زیرِ حداقلِ مجازِ فعلیِ کوپن (۲۰۰۰)
        $this->redeemLockedRow((array)$this->coupon(['min_purchase' => 2000]));
    }

    /** @test */
    public function redeem_rejects_applied_discount_above_current_authorization(): void
    {
        $this->expectException(InvalidStateException::class);
        $this->expectExceptionMessage('هم‌خوان نیست');

        // کوپن بین preview و redeem از ۱۰٪ به ۵٪ کاهش یافته: تخفیفِ اعمالیِ ۱۰۰ از
        // سقفِ فعلیِ ۵۰ می‌گذرد → مصرف fail-closed رد می‌شود.
        $this->redeemLockedRow((array)$this->coupon(['value' => 5]));
    }

    /** @test */
    public function redeem_accepts_discount_within_current_authorization(): void
    {
        // مسیرِ مجاز: تخفیفِ اعمالیِ ۴۰ (سقف‌خورده به کارمزد — قرارداد سفارش اینفلوئنسر)
        // ≤ سقفِ فعلیِ ۱۰۰ (۱۰٪ از ۱۰۰۰) → ثبت رکورد ادامه می‌یابد.
        $this->couponModel->shouldReceive('findWithLock')->once()->with(1)->andReturn($this->coupon());

        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('fetch')->andReturn(false);
        $this->database->shouldReceive('query')->once()->andReturn($stmt);

        $this->redemptionModel->shouldReceive('hasUserUsedCouponForUpdate')->once()->with(5, 1)->andReturn(false);
        $this->redemptionModel->shouldReceive('create')->once()->with(m::type('array'))->andReturn(55);
        $this->couponModel->shouldReceive('incrementUsage')->once()->with(1)->andReturn(true);

        $this->assertTrue($this->service->redeem(
            1, 5, '1000.0000', '40.0000', '960.0000', 'irt', 'story_order', 77, null, 'story_order'
        ));
    }
}
