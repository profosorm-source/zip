<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Models\ContentAgreement;
use App\Models\ContentRevenue;
use App\Models\ContentSubmission;
use App\Services\ContentService;
use App\Services\Settings\AppSettings;
use Core\Container;
use Core\Database;
use Core\Exceptions\BusinessException;
use Core\TransactionWrapper;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-Q4-MOD24-15/06 — قرارداد گذارهای وضعیت محتوا.
 *
 *  • MOD24-15: انتشار قبلاً check-then-act بدون CAS بود؛ دو ادمین هم‌زمان هر دو
 *    موفق می‌شدند، published_url/published_by دومی اولی را بازنویسی می‌کرد و
 *    رویداد content.published دوبار منتشر می‌شد. اکنون UPDATE … WHERE status='approved'.
 *  • MOD24-06: suspended بن‌بست بود (رفع تعلیق فقط با SQL دستی). اکنون
 *    unsuspend با CAS به published (اگر published_url دارد) یا approved برمی‌گردد.
 */
final class ContentStatusTransitionsCasTest extends TestCase
{
    private Database $db;
    private int $userId;
    private string $tag;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = Container::getInstance()->make(Database::class);
        $this->tag = 'q4t' . bin2hex(random_bytes(4));

        $this->db->query(
            'INSERT INTO users (username, email, status, role) VALUES (?, ?, ?, ?)',
            ["q4t-{$this->tag}", "q4t-{$this->tag}@example.test", 'active', 'user'],
        );
        $this->userId = (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    protected function tearDown(): void
    {
        $this->db->query('DELETE FROM content_revenues WHERE submission_id IN (SELECT id FROM content_submissions WHERE user_id = ?)', [$this->userId]);
        $this->db->query('DELETE FROM content_submissions WHERE user_id = ?', [$this->userId]);
        $this->db->query('DELETE FROM users WHERE id = ?', [$this->userId]);
        m::close();
        parent::tearDown();
    }

    /** @param array<string, mixed> $overrides */
    private function insertSubmission(string $status, array $overrides = []): int
    {
        $fields = array_merge([
            'user_id' => $this->userId,
            'platform' => 'youtube',
            'video_url' => 'https://youtu.be/q4' . bin2hex(random_bytes(3)),
            'url' => 'https://youtu.be/q4',
            'url_hash' => null,
            'title' => 'تست گذار Q4',
            'status' => $status,
            'is_deleted' => 0,
        ], $overrides);
        $cols = implode(',', array_keys($fields));
        $marks = implode(',', array_fill(0, count($fields), '?'));
        $this->db->query(
            "INSERT INTO content_submissions ({$cols}, created_at, updated_at) VALUES ({$marks}, NOW(), NOW())",
            array_values($fields),
        );
        return (int)$this->db->fetchColumn('SELECT LAST_INSERT_ID()');
    }

    private function buildService(): ContentService
    {
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        $settingsMock = m::mock(AppSettings::class);
        $settingsMock->shouldIgnoreMissing(0);

        return new ContentService(
            $logger,
            $this->db,
            Container::getInstance()->make(ContentSubmission::class),
            Container::getInstance()->make(ContentRevenue::class),
            m::mock(ContentAgreement::class),
            Container::getInstance()->make(TransactionWrapper::class),
            $settingsMock,
            null, // outbox — اختیاری
        );
    }

    /** انتشار موفق از approved (MOD24-15 — مسیر سالم) */
    public function test_publish_from_approved_succeeds(): void
    {
        $id = $this->insertSubmission('approved', ['approved_at' => date('Y-m-d H:i:s', strtotime('-3 months'))]);
        $result = $this->buildService()->publishSubmission($id, 77, 'https://example.com/published', 'کانال تست');

        $this->assertTrue($result['success'] ?? false);
        $row = $this->db->query(
            'SELECT status, published_url, published_by FROM content_submissions WHERE id = ?',
            [$id],
        )->fetch(\PDO::FETCH_OBJ);
        $this->assertSame('published', $row->status);
        $this->assertSame('https://example.com/published', $row->published_url);
        $this->assertEquals(77, (int)$row->published_by);
    }

    /** انتشار دوم (رقابت دو ادمین) fail-loud — نه بازنویسی/رویداد دوبار (MOD24-15) */
    public function test_second_concurrent_publish_fails_loud(): void
    {
        $id = $this->insertSubmission('approved', ['approved_at' => date('Y-m-d H:i:s', strtotime('-3 months'))]);
        $service = $this->buildService();

        $first = $service->publishSubmission($id, 77, 'https://example.com/first');
        $this->assertTrue($first['success'] ?? false);

        // تلاش دوم — چه در گیتِ خواندن وضعیت (مسیر ترتیبی) چه در CAS (رقابت واقعی
        // پنجرهٔ بین read و update) باید fail-loud رد شود؛ قراردادِ اصلی: هرگز
        // موفق نمی‌شود و published_url/published_by اولی را بازنویسی نمی‌کند.
        try {
            $service->publishSubmission($id, 88, 'https://example.com/second');
            $this->fail('انتشار دوم نباید موفق شود');
        } catch (BusinessException $e) {
            $this->assertThat(
                $e->getMessage(),
                $this->logicalOr(
                    $this->stringContains('توسط فرایند دیگری'),
                    $this->stringContains('فقط محتوای تأیید شده'),
                ),
            );
        }

        // بازنویسی رخ نداد — ادمین اول مالک انتشار است
        $row = $this->db->query(
            'SELECT published_url, published_by FROM content_submissions WHERE id = ?',
            [$id],
        )->fetch(\PDO::FETCH_OBJ);
        $this->assertSame('https://example.com/first', $row->published_url);
        $this->assertEquals(77, (int)$row->published_by);
    }

    /** انتشار از وضعیت غیرمجاز رد می‌شود (گیت باقی مانده) */
    public function test_publish_from_pending_rejected(): void
    {
        $id = $this->insertSubmission('pending');
        $this->expectException(BusinessException::class);
        $this->expectExceptionMessage('فقط محتوای تأیید شده');
        $this->buildService()->publishSubmission($id, 77, 'https://example.com/x');
    }

    /** رفع تعلیق محتوای «قبلاً منتشرشده» به published برمی‌گردد (MOD24-06) */
    public function test_unsuspend_restores_to_published_when_url_exists(): void
    {
        $id = $this->insertSubmission('suspended', [
            'approved_at' => date('Y-m-d H:i:s', strtotime('-4 months')),
            'published_at' => date('Y-m-d H:i:s', strtotime('-3 months')),
            'published_url' => 'https://example.com/live',
        ]);

        $result = $this->buildService()->unsuspendSubmission($id, 99, 'تعلیق اشتباه بود');
        $this->assertTrue($result['success'] ?? false);
        $this->assertSame('published', $result['data']['restored_status'] ?? '');

        $row = $this->db->query(
            'SELECT status, suspended_at, suspended_by FROM content_submissions WHERE id = ?',
            [$id],
        )->fetch(\PDO::FETCH_OBJ);
        $this->assertSame('published', $row->status);
        $this->assertNull($row->suspended_at);
        $this->assertNull($row->suspended_by);
    }

    /** رفع تعلیق محتوای «تأییدشده و هنوز منتشرنشده» به approved برمی‌گردد */
    public function test_unsuspend_restores_to_approved_without_published_url(): void
    {
        $id = $this->insertSubmission('suspended', [
            'approved_at' => date('Y-m-d H:i:s', strtotime('-4 months')),
        ]);

        $result = $this->buildService()->unsuspendSubmission($id, 99);
        $this->assertTrue($result['success'] ?? false);
        $this->assertSame('approved', $result['data']['restored_status'] ?? '');
    }

    /** رفع تعلیق فقط از suspended —CAS رقابت را fail-loud می‌کند */
    public function test_unsuspend_from_non_suspended_fails(): void
    {
        $id = $this->insertSubmission('published', [
            'approved_at' => date('Y-m-d H:i:s', strtotime('-4 months')),
            'published_url' => 'https://example.com/live',
        ]);
        $this->expectException(BusinessException::class);
        $this->expectExceptionMessage('فقط محتوای تعلیق‌شده');
        $this->buildService()->unsuspendSubmission($id, 99);
    }
}
