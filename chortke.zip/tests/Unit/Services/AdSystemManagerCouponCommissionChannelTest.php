<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Services\AdSystemManager;
use Core\Exceptions\ApplicationException;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-SEO23-COUPON-READER (گام ③) — پین قراردادیِ خوانندهٔ جدید
 * coupon_site_commission_percent (resolveCouponCommissionChannel).
 *
 * پیش‌تر این کلید در پیلاد ساگا نوشته می‌شد اما هیچ خواننده‌ای نداشت
 * (باگ واقعی کوپن از بازبینی گزارش ماژول ۲۳/۲۴ — ریشهٔ سوءبرداشتِ
 * «واگرایی اسکرو/بودجه» در SEO-23-03). اکنون قرینهٔ coupon_charge_total
 * است: خواننده با گارد تطابق با quote.
 */
final class AdSystemManagerCouponCommissionChannelTest extends TestCase
{
    /** کلید غایب → مقدار quote (سازگاری پسرو؛ کانال پیلاد خاموش) */
    public function testAbsentKeyFallsBackToQuote(): void
    {
        $this->assertSame(
            '10.00',
            AdSystemManager::resolveCouponCommissionChannel(
                ['unrelated' => '1'],
                ['fee_percent_eff' => '10.00']
            )
        );
    }

    /** کلید خالی/whitespace → همان رفتار غیبت */
    public function testBlankKeyFallsBackToQuote(): void
    {
        $this->assertSame(
            '0',
            AdSystemManager::resolveCouponCommissionChannel(
                ['coupon_site_commission_percent' => '   '],
                ['fee_percent_eff' => '0']
            )
        );
        $this->assertSame(
            '12.50',
            AdSystemManager::resolveCouponCommissionChannel(
                ['coupon_site_commission_percent' => ''],
                ['fee_percent_eff' => '12.50']
            )
        );
    }

    /** کلید موجود و هم‌ارز quote (مقیاس ۲؛ «10» === «10.00») → مقدار پیلاد */
    public function testMatchingKeyPassesThrough(): void
    {
        $this->assertSame(
            '10.00',
            AdSystemManager::resolveCouponCommissionChannel(
                ['coupon_site_commission_percent' => '10.00'],
                ['fee_percent_eff' => '10.00']
            )
        );
        // همان عدد با نمایش متفاوت — هم‌ارز در مقیاس ۲
        $this->assertSame(
            '10',
            AdSystemManager::resolveCouponCommissionChannel(
                ['coupon_site_commission_percent' => '10'],
                ['fee_percent_eff' => '10.00']
            )
        );
        // quote صفر (رژیم D > F — کارمزد کامل‌خورده) + پیلاد صفر
        $this->assertSame(
            '0',
            AdSystemManager::resolveCouponCommissionChannel(
                ['coupon_site_commission_percent' => '0'],
                ['fee_percent_eff' => '0']
            )
        );
    }

    /** واگرایی کانال پیلاد با quote → fail-loud (قرین amount-match در coupon_charge_total) */
    public function testDivergentKeyFailsLoud(): void
    {
        $this->expectException(ApplicationException::class);
        $this->expectExceptionMessage('مغایرت دارد');
        AdSystemManager::resolveCouponCommissionChannel(
            ['coupon_site_commission_percent' => '15'],
            ['fee_percent_eff' => '10.00']
        );
    }

    /** مقدار غیرعددی → fail-loud */
    public function testNonNumericKeyFailsLoud(): void
    {
        $this->expectException(ApplicationException::class);
        $this->expectExceptionMessage('معتبر نیست');
        AdSystemManager::resolveCouponCommissionChannel(
            ['coupon_site_commission_percent' => 'ten'],
            ['fee_percent_eff' => '10.00']
        );
    }

    /** مقدار منفی → fail-loud (درصد کارمزد مؤثر هرگز منفی نیست) */
    public function testNegativeKeyFailsLoud(): void
    {
        $this->expectException(ApplicationException::class);
        $this->expectExceptionMessage('معتبر نیست');
        AdSystemManager::resolveCouponCommissionChannel(
            ['coupon_site_commission_percent' => '-5'],
            ['fee_percent_eff' => '10.00']
        );
    }

    /** کلید quote غایب در coupon (ناسازگاری فراخواننده) → صفرِ صادقانه، نه خطا */
    public function testMissingQuoteKeyYieldsZeroChannel(): void
    {
        $this->assertSame(
            '0',
            AdSystemManager::resolveCouponCommissionChannel(
                ['coupon_site_commission_percent' => '0'],
                []
            )
        );
        // پیلاد هم غایب → quote غایب → '0'
        $this->assertSame('0', AdSystemManager::resolveCouponCommissionChannel([], []));
    }
}
