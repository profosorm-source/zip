<?php

declare(strict_types=1);

namespace Tests\Unit\Services\AntiFraud;

use App\Contracts\LoggerInterface;
use App\Models\ContentSubmission;
use App\Services\AntiFraud\VideoFingerprintService;
use Core\Cache;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-A24-01 — نرمال‌سازی اثر انگشت ویدیو از منبع یگانهٔ حقیقت.
 *
 * پیش از این بچ، سرویس نرمال‌ساز خودش را داشت که با canonicalVideoKey مدل
 * ناهم‌خوان بود: کل URL lowercase می‌شد (برخورد کاذب شناسه‌های case-sensitive
 * یوتیوب/آپارات)، query/fragment حفظ می‌شد (دور زدن با ?si=/&t=) و regexهای
 * استخراج شناسه لنگردار بودند (youtu.be/abc/ و aparat …#fragment شناسهٔ متفاوت
 * می‌گرفتند). اکنون resolveVideoId/createUrlHash از ContentSubmission::
 * canonicalVideoKey/hashVideoUrl تغذیه می‌شوند — این تست قفل می‌کند:
 *
 *  ۱) variant های همان ویدیو (پروتکل/www/m./کوتاه‌کننده/پارامتر/fragment)
 *     به video_id و combined_hash یکسان می‌رسند.
 *  ۲) شناسهٔ ویدیو case-sensitive می‌ماند (بدون برخورد کاذب AbC ≠ abc).
 *  ۳) url_hash سرویس = url_hash مدل برای همان (platform, url) — یک منبع حقیقت.
 *  ۴) پلتفرم عمومی (upload_center): host+path پایدار، به‌جای md5 کل URL خام.
 */
final class VideoFingerprintNormalizationTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    private function service(): VideoFingerprintService
    {
        return new VideoFingerprintService(
            m::mock(Cache::class),
            m::mock(Database::class),
            m::mock(LoggerInterface::class)
        );
    }

    public function test_youtube_variants_collapse_to_one_identity(): void
    {
        $svc = $this->service();

        $variants = [
            'https://www.youtube.com/watch?v=AbCdEf12345',
            'http://youtube.com/watch?v=AbCdEf12345',
            'https://m.youtube.com/watch?v=AbCdEf12345&list=xyz&t=30',
            'https://youtu.be/AbCdEf12345',
            'https://youtu.be/AbCdEf12345?t=42s#comments',
            'https://www.youtube.com/shorts/AbCdEf12345',
        ];

        $base = $svc->generateFingerprint($variants[0], 'youtube');
        $this->assertSame('AbCdEf12345', $base['video_id'], 'شناسهٔ یوتیوب باید استخراج شود');
        $this->assertSame(0.8, $base['confidence'], 'extracted + بدون metadata = 0.5+0.3');

        foreach (\array_slice($variants, 1) as $url) {
            $fp = $svc->generateFingerprint($url, 'youtube');
            $this->assertSame($base['video_id'], $fp['video_id'], "video_id یکسان برای: {$url}");
            $this->assertSame($base['url_hash'], $fp['url_hash'], "url_hash یکسان برای: {$url}");
            $this->assertSame($base['combined_hash'], $fp['combined_hash'], "combined_hash یکسان برای: {$url}");
        }
    }

    public function test_youtube_ids_are_case_sensitive_no_false_collision(): void
    {
        $svc = $this->service();

        $upper = $svc->generateFingerprint('https://youtu.be/AbCdEf12345', 'youtube');
        $lower = $svc->generateFingerprint('https://youtu.be/abcdef12345', 'youtube');

        // نرمال‌ساز قدیمی کل URL را lowercase می‌کرد → این دو تصادمی برخورد
        // می‌کردند؛ شناسهٔ واقعی یوتیوب case-sensitive است و باید جدا بمانند
        $this->assertNotSame($upper['video_id'], $lower['video_id']);
        $this->assertNotSame($upper['combined_hash'], $lower['combined_hash']);
    }

    public function test_aparat_variants_collapse_to_one_identity(): void
    {
        $svc = $this->service();

        $variants = [
            'https://www.aparat.com/v/xyz987',
            'http://aparat.com/v/xyz987',
            'https://www.aparat.com/v/xyz987?playlist=1',
            'https://aparat.com/v/xyz987#t=5',
        ];

        $base = $svc->generateFingerprint($variants[0], 'aparat');
        $this->assertSame('xyz987', $base['video_id']);
        $this->assertSame(0.8, $base['confidence']);

        foreach (\array_slice($variants, 1) as $url) {
            $fp = $svc->generateFingerprint($url, 'aparat');
            $this->assertSame($base['video_id'], $fp['video_id'], "video_id یکسان برای: {$url}");
            $this->assertSame($base['combined_hash'], $fp['combined_hash'], "combined_hash یکسان برای: {$url}");
        }
    }

    public function test_generic_platform_uses_stable_host_path_not_raw_md5(): void
    {
        $svc = $this->service();

        // 🛡️ FIX-A24-01: قبلاً شناسهٔ پلتفرم عمومی md5 کل URL خام بود — هر
        // تغییر کوچک (پارامتر/fragment) تطابق را می‌کشت. اکنون host نرمال +
        // مسیر بدون query/fragment (همان canonicalVideoKey) است.
        $base = $svc->generateFingerprint('https://Example.com/Files/Video.MP4', 'upload_center');
        $variant = $svc->generateFingerprint('http://www.example.com/Files/Video.MP4?token=abc#top', 'upload_center');

        $this->assertSame('example.com/Files/Video.MP4', $base['video_id'], 'شناسهٔ عمومی = کلید کانونی نرمال');
        $this->assertSame($base['video_id'], $variant['video_id']);
        $this->assertSame($base['combined_hash'], $variant['combined_hash']);
        $this->assertSame(0.5, $base['confidence'], 'پلتفرم عمومی بدون استخراج شناسه = پایهٔ 0.5');
        $this->assertStringNotContainsString(' ', $base['video_id']);
    }

    public function test_service_url_hash_equals_model_url_hash_single_source_of_truth(): void
    {
        $svc = $this->service();
        $url = 'https://www.aparat.com/v/uniq456';
        $platform = 'aparat';

        $fp = $svc->generateFingerprint($url, $platform);

        // url_hash سرویس باید دقیقاً همان هش نرمال‌شدهٔ مدل باشد — دیگر
        // دو نرمال‌ساز با قواعد متفاوت وجود ندارد
        $this->assertSame(
            ContentSubmission::hashVideoUrl($platform, $url),
            $fp['url_hash']
        );
    }

    public function test_unparseable_url_falls_back_gracefully(): void
    {
        $svc = $this->service();

        $fp = $svc->generateFingerprint('not a url', 'upload_center');
        $this->assertSame(32, \strlen((string)$fp['video_id']), 'fallback غیرقابل‌تجزیه = md5 هگز');
        $this->assertTrue(\ctype_xdigit((string)$fp['video_id']));
        $this->assertSame(0.5, $fp['confidence']);
    }
}
