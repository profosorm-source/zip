<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Services\SocialTask\CaptureAnalysisService;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ رگرسیون پیش‌بررسی بمب فشرده‌سازی (FIX-BOMB-PRECHECK چرخهٔ 17-RV +
 * FIX-R18-GAP-BOMB بستهٔ باقیماندهٔ R18 — پیوست تست در بازبینی گیت‌هاب 2026-10-28):
 *
 * مسیر spot در camera-verify تصویر base64 کاربر را در CaptureAnalysisService::
 * analyzeSpotImage دیکد درون‌حافظه‌ای می‌کند. تا قبل از رفع، imagecreatefromstring
 * بدون هیچ پیش‌بررسیِ ابعاد صدا زده می‌شد: یک JPEG کوچکِ (≤۶۰KB — زیر سقف بایت)
 * با ابعاد اعلامی غول‌آسا (مثلاً ۳۰۰۰۰×۳۰۰۰۰) به تلاش تخصیص چند-گیگابایتی و
 * OOM/کرش پروسهٔ FPM منتهی می‌شد — کلاسیک‌ترین شکل decompression bomb.
 *
 * رفع: getimagesizefromstring (خواندن هدر، بدون decode) پیش از دیکد؛ ابعاد
 * خارج از قرارداد SPOT_MIN_DIM..SPOT_MAX_DIM → رد بدون هیچ تخصیصی، همان
 * الگوی UploadService::checkImageDimensions برای ورودی رشته‌ای.
 */
final class CaptureAnalysisBombPrecheckTest extends TestCase
{
    private CaptureAnalysisService $service;

    protected function setUp(): void
    {
        parent::setUp();
        if (!function_exists('imagecreatefromstring') || !function_exists('imagejpeg')) {
            $this->markTestSkipped('GD با پشتیبانی JPEG لازم است (محیط تولید/تست استاندارد چرتکه)');
        }
        $this->service = new CaptureAnalysisService();
    }

    /**
     * JPEG با هدر سالم اما ابعاد اعلامیِ ۳۰۰۰۰×۳۰۰۰۰ (SOF0 دست‌ساز).
     * سقف بایت قرارداد spot (۶۰KB) رعایت شده — یعنی سقف بایت به‌تنهایی این
     * payload را نمی‌بیند؛ تنها ایندکی پیش از decode است که می‌بنددش.
     */
    private function craftedHugeDimsJpeg(int $w, int $h): string
    {
        $bytes = "\xFF\xD8";                                   // SOI
        $bytes .= "\xFF\xE0\x00\x10" . 'JFIF' . "\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00"; // APP0/JFIF
        $bytes .= "\xFF\xC0" . pack('n', 8 + 3 * 3)            // SOF0 + length
            . "\x08"                                           // precision 8-bit
            . pack('n', $h) . pack('n', $w) . "\x03"           // H, W, 3 components
            . "\x01\x22\x00" . "\x02\x11\x01" . "\x03\x11\x01";
        $bytes .= "\xFF\xDA\x00\x08\x01\x01\x00\x00\x3F\x00";  // SOS (بدون اسکن واقعی)
        $bytes .= str_repeat("\x7F", 128);                     // entropy فیک — عبور از گارد ≥64B
        $bytes .= "\xFF\xD9";                                  // EOI
        return $bytes;
    }

    /** JPEG واقعیِ ساخته‌شده با GD با ابعاد درون قرارداد. */
    private function realJpeg(int $w, int $h, int $gray): string
    {
        // FIX-R18-GAP-BOMB (تکمیلی): تصویر palette-based (۱ بایت/پیکسل) به‌جای
        // truecolor (۴ بایت/پیکسل) — خروجی JPEG واقعی همان است (ابعاد و محتوا
        // از هدر خوانده شد: 3000×3000 معتبر)، اما پیک حافظهٔ تولید از ~۳۶MB به
        // ~۱۰MB می‌رسد. بدون این، تست در رانِ سوئیت کامل (حافظهٔ انباشتهٔ PHPUnit
        // نزدیک سقف 128M پیش‌فرض CLI) با OOM کل ران را می‌کشت — با اینکه در
        // اجرای تنها سبز بود.
        $img = imagecreate($w, $h);
        $color = imagecolorallocate($img, $gray, $gray, $gray);
        imagefilledrectangle($img, 0, 0, $w - 1, $h - 1, $color);
        ob_start();
        imagejpeg($img, null, 90);
        $bin = (string)ob_get_clean();
        imagedestroy($img);
        return $bin;
    }

    public function test_huge_declared_dims_are_rejected_before_decode(): void
    {
        $bomb = $this->craftedHugeDimsJpeg(30000, 30000);
        $this->assertLessThanOrEqual(61440, strlen($bomb), 'پروب باید زیر سقف بایت spot بماند (اثبات اینکه سقف بایت سد نمی‌شود)');

        $r = $this->service->analyzeSpotImage($bomb, ['lum' => 128.0, 'std' => 10.0]);

        $this->assertSame('unreadable', $r['result'], 'ابعاد اعلامی خارج از قرارداد باید بدون decode رد شود');
        $this->assertSame(30000, $r['width'], 'ابعاد اعلامی از هدر (پیش از decode) در خروجی ثبت می‌شود');
        $this->assertSame(30000, $r['height']);
        // اگر پیش‌بررسی حذف شود، این تست با OOM/کرش پروسه جان می‌دهد (4.5GB تخصیص)
    }

    public function test_slightly_oversize_dims_are_rejected_too(): void
    {
        // 2049 > SPOT_MAX_DIM=2048 — مرز دقیقاً یک پیکسل بالاتر
        $r = $this->service->analyzeSpotImage(
            $this->craftedHugeDimsJpeg(2049, 2049),
            ['lum' => 128.0, 'std' => 10.0]
        );
        $this->assertSame('unreadable', $r['result']);
        $this->assertSame(2049, $r['width']);
    }

    public function test_dims_below_contract_minimum_are_rejected(): void
    {
        // 8 < SPOT_MIN_DIM=16 — تصویر خردشده نامعتبر است
        $r = $this->service->analyzeSpotImage(
            $this->craftedHugeDimsJpeg(8, 8),
            ['lum' => 128.0, 'std' => 10.0]
        );
        $this->assertSame('unreadable', $r['result']);
        $this->assertSame(8, $r['width']);
    }

    public function test_real_oversize_jpeg_is_rejected_without_decoding(): void
    {
        // JPEG واقعیِ ۳۰۰۰×۳۰۰۰ (خارج از سقف ۲۰۴۸) — قدیم: decode کامل ۳۶MB سپس رد؛
        // حالا: رد از روی هدر. قرارداد خروجی همان unreadable است.
        $r = $this->service->analyzeSpotImage(
            $this->realJpeg(3000, 3000, 128),
            ['lum' => 128.0, 'std' => 10.0]
        );
        $this->assertSame('unreadable', $r['result']);
        $this->assertSame(3000, $r['width']);
    }

    public function test_valid_in_contract_jpeg_still_decodes_and_matches(): void
    {
        // رگرسیون معکوس: پیش‌بررسی نباید تصویر سالمِ درون قرارداد را رد کند —
        // خاکستریِ ۱۲۸، ادعای هم‌خوان → match
        $bin = $this->realJpeg(64, 64, 128);
        $r = $this->service->analyzeSpotImage($bin, ['lum' => 128.0, 'std' => 5.0]);
        $this->assertSame('match', $r['result'], 'تصویر معتبر ۶۴×۶۴ با ادعای هم‌خوان باید match بماند');
        $this->assertNotNull($r['server_lum']);
        $this->assertNotNull($r['server_std']);
    }

    public function test_valid_image_with_wrong_claim_still_mismatches(): void
    {
        // آمار سرور همچنان مرجع است: ادعای lum دور از واقعیت → mismatch
        $bin = $this->realJpeg(64, 64, 128);
        $r = $this->service->analyzeSpotImage($bin, ['lum' => 250.0, 'std' => 5.0]);
        $this->assertSame('mismatch', $r['result']);
    }

    public function test_non_image_garbage_is_rejected_without_decode_attempt(): void
    {
        // ۲۰۰ بایت زبالهٔ غیرتصویری — getimagesizefromstring fail → unreadable
        $r = $this->service->analyzeSpotImage(str_repeat("\xDE\xAD\xBE\xEF", 50), ['lum' => 128.0, 'std' => 10.0]);
        $this->assertSame('unreadable', $r['result']);
        $this->assertNull($r['width']);
    }
}
