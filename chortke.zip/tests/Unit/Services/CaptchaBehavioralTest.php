<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use PHPUnit\Framework\TestCase;
use App\Services\CaptchaService;
use Mockery as m;

/**
 * W4-C — تست‌های کپچای رفتاری (behavioral captcha) سرتاسری.
 *
 * شاخهٔ behavioral تا موج W4 عملاً «مرده» بود: کلاینت (captcha.js قدیمی)
 * حذف شده بود و verifyBehavioral فقط از پارامتر چهارم verify() تغذیه می‌شد.
 * این تست‌ها قراردادِ تکمیل‌شده را پین می‌کنند:
 *
 *   ۱. انتخاب (selection): با captcha_type=behavioral در تنظیمات، generate()
 *      توکن behavioral می‌دهد (شاخهٔ پیش‌تر مرده در مسیر زنده).
 *   ۲. اسکورینگ: state JSON امضاشده باید behavioral_min_interactions و
 *      behavioral_min_seconds را رعایت کند؛ پیلود نامعقول (نرخ فرا-انسانی،
 *      JSON خراب، > ۸KB، timestamp آینده) رد می‌شود.
 *   ۳. HMAC توکن + گارد single-use (replay) سرِ جایشان می‌مانند.
 *   ۴. fallback: state از بدنهٔ درخواست هم خوانده می‌شود (سایت‌های
 *      verify($token,$response) مثل ContactService بدون پارامتر چهارم).
 *
 * ادیوم تست: همان الگوی CaptchaServiceTest (Mockery + ساخت مستقیم سرویس)؛
 * فقط دو singleton محیطی با reflection سواپ/ری‌استور می‌شوند:
 *   - Core\Application (برای app()->request که verifyBehavioral می‌خواند)
 *   - Core\Cache (گارد replay — به‌جای کش فایلِ ماندگار)
 */
class CaptchaBehavioralTest extends TestCase
{
    /** @var \App\Contracts\LoggerInterface&\Mockery\MockInterface */
    private \App\Contracts\LoggerInterface $logger;
    /** @var \App\Models\CaptchaLog&\Mockery\MockInterface */
    private \App\Models\CaptchaLog $captchaLogModel;
    /** @var \App\Services\Settings\AppSettings&\Mockery\MockInterface */
    private \App\Services\Settings\AppSettings $appSettings;
    /** @var \Core\Session&\Mockery\MockInterface */
    private \Core\Session $session;
    /** @var \Core\Request&\Mockery\MockInterface */
    private \Core\Request $request;
    /** @var \Core\Cache&\Mockery\MockInterface */
    private \Core\Cache $cache;
    private CaptchaService $service;

    /** @var array<string, mixed> رِفلکشن‌های سواپ singleton برای ری‌استور در tearDown */
    private array $swap = [];

    protected function setUp(): void
    {
        parent::setUp();

        $this->logger          = m::mock('App\Contracts\LoggerInterface');
        $this->captchaLogModel = m::mock('App\Models\CaptchaLog');
        $this->appSettings     = m::mock('App\Services\Settings\AppSettings');
        $this->session         = m::mock('Core\Session');
        $this->request         = m::mock('Core\Request');
        $this->cache           = m::mock('Core\Cache');

        $this->logger->shouldIgnoreMissing();
        $this->appSettings->shouldReceive('get')->byDefault()->andReturnUsing(
            function (string $key, mixed $default = null) {
                // آستانه‌های پیش‌فرضِ کاتالوگ تنظیمات (behavioral_min_*: 5 / 4)
                return match ($key) {
                    'behavioral_min_interactions' => 5,
                    'behavioral_min_seconds'      => 4,
                    'captcha_expire_minutes'      => 5,
                    default                       => $default,
                };
            }
        );

        $this->service = new CaptchaService(
            $this->logger,
            $this->captchaLogModel,
            $this->appSettings,
            $this->session,
            new \Core\PathResolver(dirname(__DIR__, 3))
        );

        $this->swapApplication();
        $this->swapCache();
    }

    protected function tearDown(): void
    {
        $this->restoreSwaps();
        m::close();
        parent::tearDown();
    }

    // ────────────────────────────────────────────────────────
    //  محیط: سواپ singleton ها با reflection
    // ────────────────────────────────────────────────────────

    private function swapApplication(): void
    {
        $prop = new \ReflectionProperty(\Core\Application::class, 'instance');
        $prop->setAccessible(true);
        $previous = $prop->getValue();

        $app = (new \ReflectionClass(\Core\Application::class))->newInstanceWithoutConstructor();
        $app->request = $this->request; // public property

        $prop->setValue(null, $app);
        $this->swap['app'] = [$prop, $previous];
    }

    private function swapCache(): void
    {
        $prop = new \ReflectionProperty(\Core\Cache::class, 'instance');
        $prop->setAccessible(true);
        $previous = $prop->getValue();

        $prop->setValue(null, $this->cache);
        $this->swap['cache'] = [$prop, $previous];
    }

    private function restoreSwaps(): void
    {
        foreach ($this->swap as [$prop, $previous]) {
            /** @var \ReflectionProperty $prop */
            $prop->setValue(null, $previous);
        }
        $this->swap = [];
    }

    // ────────────────────────────────────────────────────────
    //  سازنده‌های payload (مشابه signBehavioral سرویس)
    // ────────────────────────────────────────────────────────

    private function makeToken(int $createdAt): string
    {
        $payload = base64_encode((string)json_encode([
            'created_at' => $createdAt,
            'nonce'      => 'unit-test-nonce',
        ]));

        return $payload . '.' . hash_hmac('sha256', $payload, secure_key());
    }

    private function makeState(int $interactions, int $lastInteractionAt): string
    {
        $payload = base64_encode((string)json_encode([
            'interactions'       => $interactions,
            'last_interaction_at' => $lastInteractionAt,
        ]));

        return $payload . '.' . hash_hmac('sha256', $payload, secure_key());
    }

    /**
     * رویدادهای طبیعی (time ها میلی‌ثانیهٔ نسبی با jitter انسانی؛ مختصات متغیر)
     *
     * @return string JSON
     */
    private function naturalEvents(int $count = 12): string
    {
        $gaps = [120, 340, 90, 680, 210, 155, 520, 130, 305, 240, 410, 175, 260, 390, 145];
        $events = [];
        $t = 0;
        for ($i = 0; $i < $count; $i++) {
            $type = ($i % 4 === 3) ? 'click' : 'mouse_move';
            $events[] = [
                'type' => $type,
                'time' => $t,
                'x'    => 120 + ($i * 37) % 600,
                'y'    => 80 + ($i * 53) % 400,
            ];
            $t += $gaps[$i % count($gaps)];
        }

        return (string)json_encode($events);
    }

    /** @param array<string, mixed> $overrides */
    private function primeRequest(array $overrides = []): void
    {
        $o = array_merge([
            'behavioral_score' => 85,
            'events'           => $this->naturalEvents(),
            'behavioral_state' => $this->makeState(6, time() - 2),
        ], $overrides);

        // قرارداد verifyBehavioral: body() اول، input() fallback
        $this->request->shouldReceive('body')->with('behavioral_score', 0)->andReturn($o['behavioral_score'])->byDefault();
        $this->request->shouldReceive('input')->with('behavioral_score', 0)->andReturn($o['behavioral_score'])->byDefault();
        $this->request->shouldReceive('body')->with('events')->andReturn($o['events'])->byDefault();
        $this->request->shouldReceive('input')->with('events', '')->andReturn($o['events'])->byDefault();
        $this->request->shouldReceive('body')->with('behavioral_state', '')->andReturn($o['behavioral_state'])->byDefault();
        $this->request->shouldReceive('input')->with('behavioral_state', '')->andReturn($o['behavioral_state'])->byDefault();
    }

    private function expectSuccessLog(): void
    {
        $this->captchaLogModel->shouldReceive('recordAttempt')->once()->andReturnNull();
    }

    // ────────────────────────────────────────────────────────
    //  ۱. انتخاب نوع (selection) — پینِ شاخهٔ پیش‌تر مرده
    // ────────────────────────────────────────────────────────

    /** @test */
    public function generate_selects_behavioral_when_settings_say_so(): void
    {
        $this->appSettings->shouldReceive('get')
            ->with('captcha_type', 'math')
            ->once()
            ->andReturn('behavioral');

        $captcha = $this->service->generate(null); // مسیر زندهٔ تنظیمات

        $this->assertSame('behavioral', $captcha['type']);
        $this->assertArrayHasKey('token', $captcha);
        $this->assertArrayHasKey('instruction', $captcha);
        $this->assertNotSame('', strval($captcha['instruction']));
        // توکن behavioral = payload.sig (HMAC)
        $this->assertSame(1, substr_count((string)$captcha['token'], '.'));
    }

    /** @test */
    public function generate_explicit_behavioral_type_returns_hmac_token(): void
    {
        $captcha = $this->service->generate('behavioral');

        $this->assertSame('behavioral', $captcha['type']);
        [$payload, $sig] = explode('.', (string)$captcha['token']);
        $this->assertSame(hash_hmac('sha256', $payload, secure_key()), $sig);

        $data = json_decode((string)base64_decode($payload), true);
        $this->assertIsArray($data);
        $this->assertGreaterThan(time() - 5, intval($data['created_at'] ?? 0));
    }

    // ────────────────────────────────────────────────────────
    //  ۲. مسیر موفق — state طبیعی
    // ────────────────────────────────────────────────────────

    /** @test */
    public function valid_natural_behavioral_state_passes(): void
    {
        $this->primeRequest();
        $this->expectSuccessLog();
        // FIX-MODULE2-H2 (هم‌ترازسازی تست): گارد single-use اتمیک با Cache::add
        // (SETNX) است — نه check-then-act قدیمی get()+put() که race داشت.
        $this->cache->shouldReceive('add')->once()->andReturnTrue();

        $token = $this->makeToken(time() - 10); // ۱۰ ثانیه پیش — ≥ behavioral_min_seconds

        $this->assertTrue($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    /** @test */
    public function state_param_falls_back_to_request_body(): void
    {
        // W4-C FIX: سایت‌هایی که verify($token,$response) بدون پارامتر state صدا می‌زنند
        // (ContactService) باید از بدنهٔ درخواست تغذیه شوند.
        $this->primeRequest();
        $this->expectSuccessLog();
        // FIX-MODULE2-H2 (هم‌ترازسازی تست): گارد اتمیک add (SETNX)
        $this->cache->shouldReceive('add')->once()->andReturnTrue();

        $token = $this->makeToken(time() - 10);

        $this->assertTrue($this->service->verify($token, '', null, ''));
    }

    // ────────────────────────────────────────────────────────
    //  ۳. اسکورینگ — آستانه‌های تنظیمات
    // ────────────────────────────────────────────────────────

    /** @test */
    public function too_few_interactions_fails(): void
    {
        $this->primeRequest([
            'behavioral_state' => $this->makeState(3, time() - 2), // < 5
        ]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(3, time() - 2)));
    }

    /** @test */
    public function min_interactions_is_read_from_settings(): void
    {
        $this->appSettings->shouldReceive('get')
            ->with('behavioral_min_interactions', 5)
            ->andReturn(8); // آستانهٔ سفارشی ادمین

        $this->primeRequest([
            'behavioral_state' => $this->makeState(7, time() - 2), // بین 5 و 8
        ]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(7, time() - 2)));
    }

    /** @test */
    public function too_fast_token_age_fails(): void
    {
        // توکن همین الان صادر شده؛ حتی با state عالی، زمان < behavioral_min_seconds
        $this->primeRequest();
        $token = $this->makeToken(time()); // سن صفر

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    /** @test */
    public function stale_last_interaction_fails(): void
    {
        // آخرین تعامل ۲ دقیقه پیش — پنجرهٔ ۶۰ ثانیه‌ای رد می‌شود
        $this->primeRequest([
            'behavioral_state' => $this->makeState(6, time() - 120),
        ]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 120)));
    }

    /** @test */
    public function future_last_interaction_fails(): void
    {
        // timestamp آینده (دستکاری ساعت کلاینت یا پیلود جعلی)
        $this->primeRequest([
            'behavioral_state' => $this->makeState(6, time() + 300),
        ]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() + 300)));
    }

    /** @test */
    public function low_client_score_fails(): void
    {
        // گیت score<60: کلاینتِ بدون JS = fail-closed (مشورتی اما فعال)
        $this->primeRequest(['behavioral_score' => 30]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    // ────────────────────────────────────────────────────────
    //  ۴. پیلود نامعقول
    // ────────────────────────────────────────────────────────

    /** @test */
    public function malformed_state_json_fails(): void
    {
        $this->primeRequest(['behavioral_state' => 'not.base64!']);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, 'not.base64!'));
    }

    /** @test */
    public function oversized_state_fails(): void
    {
        $big = str_repeat('A', 9000); // > 8KB
        $this->primeRequest(['behavioral_state' => $big]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $big));
    }

    /** @test */
    public function oversized_events_payload_fails(): void
    {
        $big = str_repeat('[{"type":"mouse_move","time":1,"x":1,"y":1},', 2000); // > 8KB
        $this->primeRequest(['events' => $big]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    /** @test */
    public function malformed_events_json_fails(): void
    {
        $this->primeRequest(['events' => '[{broken json']);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    /** @test */
    public function insufficient_events_fail(): void
    {
        $this->primeRequest([
            'events' => (string)json_encode([
                ['type' => 'mouse_move', 'time' => 10,  'x' => 10, 'y' => 10],
                ['type' => 'mouse_move', 'time' => 300, 'x' => 50, 'y' => 60],
            ]),
        ]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    /** @test */
    public function superhuman_event_rate_fails(): void
    {
        // نرخ فرا-انسانی: میانگین فاصلهٔ رویدادها ۵ms (< ۱۰ms گیت سرور)
        $events = [];
        for ($i = 0; $i < 20; $i++) {
            $events[] = ['type' => 'mouse_move', 'time' => $i * 5, 'x' => 10 + $i, 'y' => 20 + $i];
        }
        $this->primeRequest(['events' => (string)json_encode($events)]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    /** @test */
    public function zero_variance_timing_fails(): void
    {
        // فواصل کاملاً یکنواخت (stddev ~ 0) — الگوی ماشینی
        $events = [];
        for ($i = 0; $i < 20; $i++) {
            $events[] = ['type' => 'mouse_move', 'time' => $i * 100, 'x' => 10 + $i, 'y' => 20 + $i];
        }
        $this->primeRequest(['events' => (string)json_encode($events)]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    // ────────────────────────────────────────────────────────
    //  ۵. HMAC و replay
    // ────────────────────────────────────────────────────────

    /** @test */
    public function tampered_token_signature_fails(): void
    {
        $this->primeRequest();
        $token = $this->makeToken(time() - 10);
        $tampered = $token . 'a'; // امضا خراب شد

        $this->assertFalse($this->service->verify($tampered, '', null, $this->makeState(6, time() - 2)));
    }

    /** @test */
    public function tampered_state_signature_fails(): void
    {
        $this->primeRequest([
            'behavioral_state' => $this->makeState(6, time() - 2) . 'f',
        ]);
        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2) . 'f'));
    }

    /** @test */
    public function replayed_token_is_rejected_by_cache_guard(): void
    {
        $this->primeRequest();
        // FIX-MODULE2-H2 (هم‌ترازسازی تست): گارد single-use اتمیک — Cache::add
        // false یعنی کلید «مصرف‌شده» از قبل موجود است (SETNX نبرد) → replay رد.
        // قرارداد قدیمی get()→1 به‌عنوان نشانهٔ مصرف، race-prone بود.
        $this->cache->shouldReceive('add')
            ->once()
            ->with(\Mockery::pattern('/^captcha_behavioral_used:/'), 1, 360)
            ->andReturn(false);

        $token = $this->makeToken(time() - 10);

        $this->assertFalse($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }

    /** @test */
    public function successful_verify_marks_token_used_for_replay(): void
    {
        $this->primeRequest();
        $this->expectSuccessLog();

        // FIX-MODULE2-H2 (هم‌ترازسازی تست): مصرف توکن با add اتمیک ثبت می‌شود —
        // TTL ثانیه‌ای ۳۶۰ (پنجرهٔ انقضای ۵ دقیقه + حاشیه؛ هم‌ارز put قبلی ۶ دقیقه).
        $usedKeyPattern = \Mockery::pattern('/^captcha_behavioral_used:[0-9a-f]{64}$/');
        $this->cache->shouldReceive('add')->once()->with($usedKeyPattern, 1, 360)->andReturnTrue();

        $token = $this->makeToken(time() - 10);

        $this->assertTrue($this->service->verify($token, '', null, $this->makeState(6, time() - 2)));
    }
}
