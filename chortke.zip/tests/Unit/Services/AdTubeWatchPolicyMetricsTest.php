<?php

namespace Tests\Unit\Services;

use PHPUnit\Framework\TestCase;
use App\Services\Ads\AdsBudgetSettlementService;

/**
 * 🛡️ FIX-R3-F2/F5 (R3 Ads/AdTube) — پین‌های رفتاری موتور سنجش سمت‌سرور تماشا
 * و allowlist یوتیوب. این تست‌ها «رفتار جدید» را قفل می‌کنند:
 *
 *  - progress از زمانِ سرور محاسبه می‌شود؛ ادعای progress=80 با watch_time=0
 *    بعد از چند ثانیه دیگر قابل تسویه نیست (سناریوی گزارش R3-F2).
 *  - ادعای watch_time بیش از سقف فیزیکی (elapsed × سرعت سقف‌دار + تلورانس) = fraud.
 *  - 🛡️ FIX-S20-CLOSE-F1: سقف سرعت سیاست = ۱.۰x (پاداش به ۱× قفل شد) — ادعای سرعت
 *    کلاینت در پاداش بی‌اثر است (کلمپ ۱×) و سرعت 0/منفی → 1x.
 *  - allowlist یوتیوب: دامنه‌های جعلی با «youtube.com» در query رد، هاست‌های
 *    مجاز با ID معتبر ۱۱ کاراکتری قبول (FIX-R3-F5).
 */
class AdTubeWatchPolicyMetricsTest extends TestCase
{
    // ─── FIX-R3-F2: computeAdTubeMetrics ────────────────────────────────────

    public function test_forged_progress_with_zero_watch_time_does_not_pass_after_short_elapsed(): void
    {
        // سناریوی گزارش: progress=80 با watch_time=0 بعد از ۲ ثانیه → پاداش.
        // اکنون progress صرفاً از زمان سرور محاسبه می‌شود: ۲s/30s → 6% (< 80).
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1002, 0, 1.0, 30);
        $this->assertSame(2, $m['elapsed_seconds']);
        $this->assertFalse($m['fraud']);
        $this->assertLessThan(80, $m['progress_percent']);
    }

    public function test_full_watch_at_one_x_passes_threshold(): void
    {
        // تماشای واقعی ۳۰ ثانیه‌ای در 1x → سقف فیزیکی ۳۰ → progress=100
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1030, 30, 1.0, 30);
        $this->assertSame(30, $m['elapsed_seconds']);
        $this->assertFalse($m['fraud']);
        $this->assertSame(100, $m['progress_percent']);
        $this->assertSame(30, $m['watch_seconds']);
    }

    public function test_watch_time_claim_above_physical_ceiling_is_fraud(): void
    {
        // ادعای ۳۰ ثانیه تماشا در ۵ ثانیه با 1x → سقف فیزیکی ۵ → fraud
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1005, 30, 1.0, 30);
        $this->assertTrue($m['fraud']);
    }

    public function test_watch_time_within_tolerance_is_not_fraud(): void
    {
        // تلورانس ۳ ثانیه‌ای شبکه/لاتنسی: ادعای 7s در سقف فیزیکی 5s → fraud نیست
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1005, 7, 1.0, 30);
        $this->assertFalse($m['fraud']);
        // ولی watch_time ثبت‌شدنی به سقف فیزیکی کلمپ می‌شود
        $this->assertSame(5, $m['watch_seconds']);
    }

    public function test_speed_is_clamped_to_policy_cap(): void
    {
        // 🛡️ FIX-S20-CLOSE-F1: سقف سیاست = ۱.۰x (قفل پاداش) — ادعای 4x به 1.0 کلمپ می‌شود:
        // در ۱۰ ثانیه حداکثر ۱۰ ثانیه محتوای قابل‌اثبات (نه ۲۵ با ضرب سرعت)
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1010, 10, 4.0, 30);
        $this->assertSame(1.0, $m['speed']);
        $this->assertSame(10, $m['max_content_seconds']);
        // ادعای 10 در سقف فیزیکی ۱× دقیقاً قابل‌دستیابی است → fraud نیست
        $this->assertFalse($m['fraud']);
    }

    public function test_claim_exceeding_capped_speed_ceiling_is_fraud(): void
    {
        // 🛡️ FIX-S20-CLOSE-F1: ادعای 40 ثانیه محتوا در ۱۰ ثانیه با کلمپ ۱× (سقف 10+3) ممکن نیست
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1010, 40, 4.0, 30);
        $this->assertTrue($m['fraud']);
        // و ادعای 2.5x دیگر پاداش را کوتاه نمی‌کند: speed به 1.0 کلمپ؛ سقف همان 10
        $m2 = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1010, 10, 2.5, 30);
        $this->assertSame(1.0, $m2['speed'], 'ادعای سرعت 2.5x در پاداش بی‌اثر است — کلمپ ۱×');
        $this->assertSame(10, $m2['max_content_seconds']);
    }

    public function test_non_positive_speed_falls_back_to_one_x(): void
    {
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1010, 0, 0.0, 30);
        $this->assertSame(1.0, $m['speed']);
        $this->assertSame(10, $m['max_content_seconds']);
    }

    public function test_progress_never_exceeds_video_duration_cap(): void
    {
        // کاربر ساعت‌ها صفحه را باز نگه داشته → progress سقفش 100 است نه بیشتر
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1000 + 7200, 0, 1.0, 30);
        $this->assertSame(100, $m['progress_percent']);
        $this->assertSame(30, $m['watch_seconds']);
    }

    public function test_elapsed_is_clamped_for_clock_skew(): void
    {
        // now قبل از started_at (اسکیو ساعت) → elapsed منفی نمی‌شود
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(2000, 1000, 0, 1.0, 30);
        $this->assertSame(0, $m['elapsed_seconds']);
        $this->assertSame(0, $m['progress_percent']);
    }

    public function test_minimum_wall_clock_is_proportional_to_duration(): void
    {
        // 🛡️ FIX-S20-CLOSE-F1: کفِ دیواری از سیاست per-video می‌آید: ceil(30×0.8)=24.
        // اینجا فقط قرارداد اعداد موتور: در ۱۱ ثانیه با ادعای 2.5x → کلمپ 1x →
        // سقف محتوا 11 → progress 36 (ادعای سرعت دیگر پیشرفت نمی‌خرد).
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1011, 0, 2.5, 30);
        $this->assertSame(11, $m['max_content_seconds']);
        $this->assertSame(11, $m['elapsed_seconds']);
        $this->assertSame(36, $m['progress_percent']);
    }

    // ─── FIX-R3-F5: youtube_video_id / youtube_watch_link_allowed ───────────

    public function test_youtube_id_extraction_accepts_canonical_hosts(): void
    {
        $this->assertSame('dQw4w9WgXcQ', youtube_video_id('https://www.youtube.com/watch?v=dQw4w9WgXcQ'));
        $this->assertSame('dQw4w9WgXcQ', youtube_video_id('https://youtube.com/watch?v=dQw4w9WgXcQ&list=PL123'));
        $this->assertSame('dQw4w9WgXcQ', youtube_video_id('https://youtu.be/dQw4w9WgXcQ'));
        $this->assertSame('dQw4w9WgXcQ', youtube_video_id('https://m.youtube.com/watch?v=dQw4w9WgXcQ'));
        $this->assertSame('dQw4w9WgXcQ', youtube_video_id('https://www.youtube.com/shorts/dQw4w9WgXcQ'));
        $this->assertSame('dQw4w9WgXcQ', youtube_video_id('https://www.youtube.com/embed/dQw4w9WgXcQ'));
    }

    public function test_youtube_id_extraction_rejects_attacker_domains_and_http(): void
    {
        // «youtube.com» در query هاستِ مهاجم — باگ گزارش‌شده
        $this->assertNull(youtube_video_id('https://evil.tld/?x=youtube.com'));
        $this->assertNull(youtube_video_id('https://notyoutube.com/watch?v=dQw4w9WgXcQ'));
        $this->assertNull(youtube_video_id('https://youtube.com.evil.tld/watch?v=dQw4w9WgXcQ'));
        $this->assertNull(youtube_video_id('http://www.youtube.com/watch?v=dQw4w9WgXcQ')); // فقط https
        $this->assertNull(youtube_video_id('https://www.youtube.com/watch?v=short'));       // ID کوتاه
        $this->assertNull(youtube_video_id('https://www.youtube.com/watch?v=toolongid12345')); // ID بلند
        $this->assertNull(youtube_video_id('javascript:alert(1)'));
        $this->assertNull(youtube_video_id(null));
        $this->assertNull(youtube_video_id(''));
    }

    public function test_fallback_link_allowed_only_for_allowlisted_https_hosts(): void
    {
        $this->assertTrue(youtube_watch_link_allowed('https://www.youtube.com/watch?v=dQw4w9WgXcQ'));
        $this->assertTrue(youtube_watch_link_allowed('https://youtu.be/dQw4w9WgXcQ'));
        $this->assertFalse(youtube_watch_link_allowed('https://evil.tld/?x=youtube.com'));
        $this->assertFalse(youtube_watch_link_allowed('http://www.youtube.com/watch?v=dQw4w9WgXcQ'));
        $this->assertFalse(youtube_watch_link_allowed('javascript:alert(1)'));
    }
}
