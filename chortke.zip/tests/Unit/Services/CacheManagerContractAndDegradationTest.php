<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Contracts\CacheInterface;
use App\Services\Cache\CacheManager;
use PHPUnit\Framework\TestCase;

/**
 * FIX-36/W2-D2 — پین‌های موج رفع ۲:
 *
 * F-A9a-01: پریمیتیو add() (SET NX — دلالت SETNX) بخشی از قرارداد اصلی
 * cache() است (CacheInterface) و CacheManager آن را fail-closed delegate می‌کند.
 * این قرارداد ستون فقرات dedupeهای R33/R18N است (NotificationController:111
 * گارد long-poll؛ InvestmentProfitDistributionJob:208 claim fallback).
 *
 * F-A9a-03: مدیریت شکست per-op روی Redis — قطعی mid-process دیگر RedisException
 * خام (→ ۵۰۰) به مصرف‌کننده نمی‌دهد؛ لایهٔ CacheManager degrade می‌شود:
 * مقادیر degraded هم‌قرارداد FIX-8a هستند (increment → false تا گاردهای
 * fail-closed مالی زنده بمانند، add → false ضد دوباره‌اجرا، get → default،
 * remember → اجرای callback تازه) + مدار قطع‌شکن کوتاه‌مدت (۱۰s) تا هر عملیات
 * هزینهٔ timeout نپردازد.
 */
class CacheManagerContractAndDegradationTest extends TestCase
{
    // ───────────────────────── Fixtures ─────────────────────────

    /** مخزنی که درست بعد از «قطعی Redis mid-process» همه‌جا RedisException می‌دهد */
    private array $throwingCalls = [];

    private ?CacheInterface $throwingCache = null;
    private ?CacheInterface $recordingCache = null;
    private array $recorded = [];

    private function throwingCache(): CacheInterface
    {
        if ($this->throwingCache !== null) {
            return $this->throwingCache;
        }
        $self = $this;
        return $this->throwingCache = new class($self) implements CacheInterface {
            private \Closure $recorder;
            public function __construct($recorder) { $this->recorder = \Closure::fromCallable([$recorder, 'recordThrowingCall']); }
            private function op(string $name): void
            {
                ($this->recorder)($name);
                throw new \RedisException('Redis went away mid-process');
            }
            public function get(string $key, mixed $default = null): mixed { $this->op('get'); return $default; }
            public function set(string $key, mixed $value, ?int $ttlSeconds = null): bool { $this->op('set'); return true; }
            public function delete(string $key): bool { $this->op('delete'); return true; }
            public function put(string $key, mixed $value, int $minutes = 60): bool { $this->op('put'); return true; }
            public function forget(string $key): bool { $this->op('forget'); return true; }
            public function add(string $key, mixed $value, int $seconds = 60): bool { $this->op('add'); return true; }
            public function increment(string $key, int $step = 1): int { $this->op('increment'); return $step; }
            public function decrement(string $key, int $step = 1): int { $this->op('decrement'); return $step; }
            public function getOrSet(string $key, callable $callback, ?int $ttlSeconds = null): mixed { $this->op('getOrSet'); return null; }
            public function remember(string $key, ?int $ttlSeconds, \Closure $callback): mixed { $this->op('remember'); return null; }
            public function rememberForever(string $key, \Closure $callback): mixed { $this->op('rememberForever'); return null; }
            public function has(string $key): bool { $this->op('has'); return true; }
            public function ttl(string $key): int { $this->op('ttl'); return 60; }
            public function flush(): bool { $this->op('flush'); return true; }
            public function driver(): string { return 'throwing-redis'; }
            public function tags(array $tags): CacheInterface { return $this; }
            public function redis(): ?\Redis { return null; }
            public function lock(string $key, int $ttl = 30, int $wait = 1): bool { $this->op('lock'); return true; }
            public function unlock(string $key): bool { $this->op('unlock'); return true; }
            public function redisKey(string $key): string { return $key; }
        };
    }

    private function recordingCache(): CacheInterface
    {
        if ($this->recordingCache !== null) {
            return $this->recordingCache;
        }
        $self = $this;
        return $this->recordingCache = new class($self) implements CacheInterface {
            private \Closure $recorder;
            public function __construct($recorder) { $this->recorder = \Closure::fromCallable([$recorder, 'recordCall']); }
            private function op(string $name, array $args = []): mixed { ($this->recorder)($name, $args); return true; }
            public function get(string $key, mixed $default = null): mixed { return $this->op('get', [$key]); }
            public function set(string $key, mixed $value, ?int $ttlSeconds = null): bool { return $this->op('set', [$key, $ttlSeconds]); }
            public function delete(string $key): bool { return $this->op('delete'); }
            public function put(string $key, mixed $value, int $minutes = 60): bool { return $this->op('put'); }
            public function forget(string $key): bool { return $this->op('forget'); }
            public function add(string $key, mixed $value, int $seconds = 60): bool { return $this->op('add', [$key, $seconds]); }
            public function increment(string $key, int $step = 1): int { return $this->op('increment'); }
            public function decrement(string $key, int $step = 1): int { return $this->op('decrement'); }
            public function getOrSet(string $key, callable $callback, ?int $ttlSeconds = null): mixed { return $this->op('getOrSet'); }
            public function remember(string $key, ?int $ttlSeconds, \Closure $callback): mixed { return $this->op('remember'); }
            public function rememberForever(string $key, \Closure $callback): mixed { return $this->op('rememberForever'); }
            public function has(string $key): bool { return $this->op('has'); }
            public function ttl(string $key): int { return $this->op('ttl'); }
            public function flush(): bool { return $this->op('flush'); }
            public function driver(): string { return 'recording'; }
            public function tags(array $tags): CacheInterface { return $this; }
            public function redis(): ?\Redis { return null; }
            public function lock(string $key, int $ttl = 30, int $wait = 1): bool { return $this->op('lock'); }
            public function unlock(string $key): bool { return $this->op('unlock'); }
            public function redisKey(string $key): string { return $key; }
        };
    }

    public function recordThrowingCall(string $op): void
    {
        $this->throwingCalls[$op] = ($this->throwingCalls[$op] ?? 0) + 1;
    }

    public function recordCall(string $op, array $args = []): void
    {
        $this->recorded[$op][] = $args;
    }

    // ─────────────── F-A9a-01: قرارداد add() روی قرارداد اصلی cache() ───────────────

    public function testCacheInterfaceContractIncludesAtomicAdd(): void
    {
        $ref = new \ReflectionMethod(CacheInterface::class, 'add');
        $params = $ref->getParameters();
        $this->assertSame('add', $ref->getName());
        $this->assertSame('string', (string)$params[0]->getType());
        $this->assertSame('int', (string)$params[2]->getType(), 'TTL بر حسب ثانیه (FIX-8a)');
        $this->assertTrue($ref->hasReturnType());
        $this->assertSame('bool', (string)$ref->getReturnType());
    }

    public function testCacheManagerDelegatesAddWithSecondBasedTtl(): void
    {
        $manager = new CacheManager($this->recordingCache());
        $this->assertTrue($manager->add('poll_42', 1, 35));
        $this->assertSame([['poll_42', 35]], $this->recorded['add'] ?? []);

        // فیکسچر واقعی پروژه (CorruptSearchCache) هم باید با قرارداد جدید سازگار بماند
        $this->assertTrue((new \Tests\Fixtures\CorruptSearchCache())->add('k', 'v', 1));
    }

    public function testCacheManagerIsInstantiableAgainstFullInterface(): void
    {
        // اگر متدی از CacheInterface در CacheManager جا مانده باشد، همین‌جا fatal می‌گیریم.
        $manager = new CacheManager($this->recordingCache());
        $this->assertInstanceOf(CacheInterface::class, $manager);
        $this->assertSame('recording', $manager->driver());
    }

    // ─────────────── F-A9a-03: degrade per-op روی قطعی Redis ───────────────

    public function testRedisDeathDegradesInsteadOfRawException(): void
    {
        $manager = new CacheManager($this->throwingCache());

        // هیچ‌کدام از این‌ها RedisException نباید بلند کنند — قرارداد degraded:
        $this->assertSame('dflt', $manager->get('k', 'dflt'), 'get → default');
        $this->assertFalse($manager->set('k', 'v', 10), 'set → false');
        $this->assertFalse($manager->delete('k'), 'delete → false');
        $this->assertFalse($manager->forget('k'));
        $this->assertFalse($manager->has('k'), 'has → false');
        $this->assertSame(-2, $manager->ttl('k'), 'ttl → «کلید ناموجود»');
        $this->assertFalse($manager->increment('referral_daily_1'), 'increment → false (گارد مالی fail-closed زنده می‌ماند)');
        $this->assertFalse($manager->decrement('k'));
        $this->assertFalse($manager->add('claim_1', 1, 21600), 'add → false = claim باخته (fail-closed ضد دوباره‌اجرا)');
        $this->assertFalse($manager->lock('lk'), 'lock → false = «قفل گرفته نشد» (مسیر skip مستند)');
        $this->assertFalse($manager->unlock('lk'));
        // flush() عمداً پین نشده — مسیر آن در non-production لاگ هشدار چاپ می‌کند
        // و در production گارد ALLOW_FULL_CACHE_FLUSH دارد (رفتار مستقل از این یافته).
    }

    public function testRememberDegradesToFreshCompute(): void
    {
        $manager = new CacheManager($this->throwingCache());
        $count = 0;
        $result = $manager->remember('sidebar', 60, function () use (&$count) {
            $count++;
            return ['a' => 1];
        });
        $this->assertSame(['a' => 1], $result, 'degrade = محاسبهٔ تازه بدون کش، نه خطا');
        $this->assertSame(1, $count);

        $this->assertSame('orset', $manager->getOrSet('x', fn () => 'orset', 30));
        $this->assertSame('forever', $manager->rememberForever('y', fn () => 'forever'));
    }

    public function testCircuitShortCircuitsSubsequentOpsInSameProcess(): void
    {
        $manager = new CacheManager($this->throwingCache());
        $manager->get('first', 'd'); // شکست اول → مدار ۱۰ ثانیه باز می‌شود
        $this->assertSame(1, $this->throwingCalls['get'] ?? 0);

        // در پنجرهٔ باز مدار، عملیات بعدی به مخزن زیرین نمی‌رود (بدون هزینهٔ timeout)
        $this->assertSame('d2', $manager->get('second', 'd2'));
        $this->assertSame('d3', $manager->get('third', 'd3'));
        $this->assertSame(1, $this->throwingCalls['get'] ?? 0, 'circuit must short-circuit — no extra backend attempts');
    }

    public function testSuccessClosesTheCircuit(): void
    {
        $flip = new class implements CacheInterface {
            public bool $fail = true;
            public function get(string $key, mixed $default = null): mixed
            {
                if ($this->fail) { throw new \RedisException('down'); }
                return 'ok';
            }
            public function set(string $key, mixed $value, ?int $ttlSeconds = null): bool { return true; }
            public function delete(string $key): bool { return true; }
            public function put(string $key, mixed $value, int $minutes = 60): bool { return true; }
            public function forget(string $key): bool { return true; }
            public function add(string $key, mixed $value, int $seconds = 60): bool { return true; }
            public function increment(string $key, int $step = 1): int { return $step; }
            public function decrement(string $key, int $step = 1): int { return -$step; }
            public function getOrSet(string $key, callable $callback, ?int $ttlSeconds = null): mixed { return null; }
            public function remember(string $key, ?int $ttlSeconds, \Closure $callback): mixed { return null; }
            public function rememberForever(string $key, \Closure $callback): mixed { return null; }
            public function has(string $key): bool { return true; }
            public function ttl(string $key): int { return 60; }
            public function flush(): bool { return true; }
            public function driver(): string { return 'flip'; }
            public function tags(array $tags): CacheInterface { return $this; }
            public function redis(): ?\Redis { return null; }
            public function lock(string $key, int $ttl = 30, int $wait = 1): bool { return true; }
            public function unlock(string $key): bool { return true; }
            public function redisKey(string $key): string { return $key; }
        };

        $manager = new CacheManager($flip);
        $this->assertSame('fallback', $manager->get('k', 'fallback')); // شکست → مدار باز

        // شبیه‌سازی انقضای پنجرهٔ مدار (نیمه‌باز) → تلاش واقعی بعدی رخ می‌دهد
        $prop = new \ReflectionProperty(CacheManager::class, 'circuitOpenUntil');
        $prop->setAccessible(true);
        $prop->setValue($manager, time() - 1);

        $flip->fail = false;
        $this->assertSame('ok', $manager->get('k', 'fallback2'), 'پس از انقضای پنجره، تلاش واقعی موفق باید پاس شود');
        $this->assertNull($prop->getValue($manager), 'موفقیت مدار را می‌بندد');

        $flip->fail = true;
        $prop->setValue($manager, null);
        $this->assertSame('fallback3', $manager->get('k', 'fallback3')); // شکست دوباره → degrade عادی
    }
}
