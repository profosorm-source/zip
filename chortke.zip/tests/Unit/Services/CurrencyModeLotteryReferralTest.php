<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Models\AuditTrail;
use App\Models\LotteryDailyNumber;
use App\Models\LotteryParticipation;
use App\Models\LotteryRound;
use App\Models\ReferralCommission;
use App\Models\User;
use App\Services\Lottery\LotteryCommandService;
use App\Services\Shared\ReferralService;
use Core\Database;
use Core\EventDispatcher;
use Core\TransactionWrapper;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * FIX-R7 (تصمیم محصول — currency mode سرتاسری، دیفالت تومان):
 * پین رفتار دو-ارزی شدن قرعه‌کشی و معرفی.
 *
 * قراردادها:
 *  - ارز پیش‌فرض دورهٔ قرعه‌کشی جدید = ارز فعال (currency_mode).
 *  - خرید بلیط/تسویه/جایزه با ارز خودِ دوره (legacy → irt).
 *  - پاداش‌های معرفی با ارز فعال؛ در حالت تتر کلید‌های *_usdt خوانده می‌شوند.
 */
final class CurrencyModeLotteryReferralTest extends TestCase
{
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    // ─── helpers ─────────────────────────────────────────────────────────

    /** @return array{0: LotteryCommandService, 1: m\MockInterface, 2: m\MockInterface, 3: m\MockInterface} */
    private function lotteryService(
        m\MockInterface $appSettings,
        m\MockInterface $walletService,
        ?m\MockInterface $roundModel = null,
        ?m\MockInterface $db = null
    ): array {
        $db = $db ?? m::mock(Database::class);
        $roundModel = $roundModel ?? m::mock(LotteryRound::class);
        $participationModel = m::mock(LotteryParticipation::class);
        $dailyModel = m::mock(LotteryDailyNumber::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $eventDispatcher = m::mock(EventDispatcher::class);
        $idempotency = m::mock(\App\Services\Shared\IdempotencyService::class);
        $saga = m::mock(\App\Services\SagaOrchestrator::class);
        $auditTrail = m::mock(AuditTrail::class);

        $svc = new LotteryCommandService(
            $db, $roundModel, $participationModel, $dailyModel, $logger,
            $eventDispatcher, $walletService, $idempotency, $saga, $auditTrail,
            null, null, null
        );
        return [$svc, $db, $roundModel, $participationModel];
    }

    /** @return array{0: ReferralService, 1: m\MockInterface, 2: m\MockInterface, 3: m\MockInterface, 4: m\MockInterface, 5: m\MockInterface, 6: m\MockInterface} */
    private function referralService(m\MockInterface $appSettings): array
    {
        $db = m::mock(Database::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldReceive('info')->zeroOrMoreTimes();
        $logger->shouldReceive('warning')->zeroOrMoreTimes();
        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);
        $commissionModel = m::mock(ReferralCommission::class);
        $userModel = m::mock(User::class);
        $transactionWrapper = m::mock(TransactionWrapper::class);

        $svc = new ReferralService(
            $db, $logger, $wallet, $commissionModel, $userModel,
            $appSettings, $transactionWrapper, null, null
        );
        return [$svc, $db, $wallet, $commissionModel, $userModel, $transactionWrapper, $logger];
    }

    // ─── ① قرعه‌کشی: ارز پیش‌فرض دورهٔ جدید ─────────────────────────────

    public function test_lottery_create_round_defaults_to_active_currency(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);

        $captured = [];
        $roundModel = m::mock(LotteryRound::class);
        $roundModel->shouldReceive('create')->once()->andReturnUsing(function (array $data) use (&$captured) {
            $captured = $data;
            return 55;
        });

        [$svc] = $this->lotteryService($appSettings, $wallet, $roundModel);
        $result = $svc->createRound(1, ['ticket_price' => 5000, 'prize_amount' => 10000]);

        $this->assertTrue((bool)$result['success']);
        // منبع ارز پیش‌فرض دوره = currency_active() (تنظیم زندهٔ currency_mode)
        $this->assertSame(currency_active(), $captured['currency'], 'دورهٔ جدید باید با ارز فعال پروژه ساخته شود');
    }

    /** تست DB-محور: سوییچ واقعی currency_mode به usdt باید دورهٔ جدید را تتری کند */
    public function test_lottery_create_round_follows_live_currency_mode_switch(): void
    {
        $pdo = db();
        $pdo->query("INSERT INTO system_settings (`key`, `value`, `type`) VALUES ('currency_mode', 'usdt', 'string') ON DUPLICATE KEY UPDATE `value` = 'usdt'");
        settings(true); // پاک‌سازی کش بعد از تغییر زنده

        try {
            $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
            $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);
            $captured = [];
            $roundModel = m::mock(LotteryRound::class);
            $roundModel->shouldReceive('create')->once()->andReturnUsing(function (array $data) use (&$captured) {
                $captured = $data;
                return 57;
            });

            [$svc] = $this->lotteryService($appSettings, $wallet, $roundModel);
            $svc->createRound(1, ['ticket_price' => 5000, 'prize_amount' => 10000]);

            $this->assertSame('usdt', currency_active(), 'بعد از سوییچ زنده، ارز فعال usdt است');
            $this->assertSame('usdt', $captured['currency'], 'دورهٔ جدید باید تتری ساخته شود — بدون هیچ تغییر کدی');
        } finally {
            $pdo->query("DELETE FROM system_settings WHERE `key` = 'currency_mode'");
            settings(true);
        }
        $this->assertSame('irt', currency_active(), 'بازگشت به دیفالت تومان');
    }

    public function test_lottery_create_round_irt_default_when_mode_missing(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);

        $captured = [];
        $roundModel = m::mock(LotteryRound::class);
        $roundModel->shouldReceive('create')->once()->andReturnUsing(function (array $data) use (&$captured) {
            $captured = $data;
            return 56;
        });

        [$svc] = $this->lotteryService($appSettings, $wallet, $roundModel);
        $svc->createRound(1, ['ticket_price' => 5000, 'prize_amount' => 10000]);

        // در محیط تست currency_mode ثبت نشده ⇒ ارز فعال = irt (دیفالت تومان)
        $this->assertSame('irt', $captured['currency'], 'دیفالت تومان — تصمیم محصول FIX-R7');
    }

    // ─── ② قرعه‌کشی: خرید بلیط با ارز خودِ دوره ─────────────────────────

    public function test_lottery_participate_withdraws_in_round_currency(): void
    {
        // الگوی S28: لاگ‌های واقعی anti-fraud (خروجی fail-soft) مصرف می‌شوند تا
        // beStrictAboutOutputDuringTests تست را risky نکند.
        $this->expectOutputRegex('/./s');

        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);

        $round = (object)[
            'id' => 55, 'status' => 'active',
            'start_date' => '', 'end_date' => '',
            'ticket_price' => '5', 'max_capacity' => 100,
            'currency' => 'usdt',
        ];

        $db = m::mock(Database::class);
        $db->shouldReceive('fetch')->andReturnUsing(function (string $sql) use ($round) {
            if (str_contains($sql, 'lottery_rounds')) {
                return $round;
            }
            if (str_contains($sql, 'COUNT(*)')) {
                return (object)['cnt' => 0];
            }
            // already participated
            return null;
        });

        $roundModel = m::mock(LotteryRound::class);
        $idempotency = m::mock(\App\Services\IdempotencyService::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $logger->shouldReceive('info')->once();
        $participationModel = m::mock(LotteryParticipation::class);
        $participationModel->shouldReceive('create')->once()->andReturn(11);

        $idempotency = m::mock(\App\Services\Shared\IdempotencyService::class);
        $idempotency->shouldReceive('executeWithTransaction')
            ->once()
            ->andReturnUsing(function (string $key, int $uid, array $ctx, callable $cb) {
                return $cb();
            });

        $svc = new LotteryCommandService(
            $db, $roundModel, $participationModel, m::mock(LotteryDailyNumber::class), $logger,
            m::mock(EventDispatcher::class), $wallet, $idempotency,
            m::mock(\App\Services\SagaOrchestrator::class), m::mock(AuditTrail::class),
            null, null, null
        );

        // شمارندهٔ velocity ضدتقلب در Redis واقعی پایدار است؛ uid یکتا برای هر اجرا تا تست به اجراهای قبلی وابسته نباشد
        $uid = random_int(900000, 999999);
        // بلیط باید از کیف تتر برداشت شود — نه کیف تومان
        $wallet->shouldReceive('withdraw')->once()->with($uid, '5', 'usdt', m::any())
            ->andReturn(['success' => true, 'transaction_id' => 'LT-TX-1']);

        $result = $svc->participate($uid, 55, 'part-key-1');

        $this->assertTrue((bool)$result['success'], 'شرکت در دورهٔ تتری باید موفق باشد: ' . (string)($result['message'] ?? ''));
    }

    // ─── ③ معرفی: پاداش ثبت‌نام با ارز فعال و کلید per-currency ────────

    public function test_referral_award_signup_bonus_usdt_mode_uses_usdt_key(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        [$svc, $db, $wallet, $commissionModel, $userModel, $transactionWrapper] = $this->referralService($appSettings);

        $referred = (object)['id' => 20, 'referred_by' => 10, 'email_verified_at' => '2026-10-01'];
        $userModel->shouldReceive('findById')->with(20)->andReturn($referred);

        $appSettings->shouldReceive('get')->with('referral_commission_enabled', '1')->andReturn('1');
        // حالت تتر → کلید USDT خوانده می‌شود (دیفالت '1000' — قرارداد موجود)
        $appSettings->shouldReceive('get')->with('referral_signup_bonus_usdt', '1000')->andReturn('5');

        $commissionModel->shouldReceive('findByIdempotencyKey')->once()->andReturn(null);

        $transactionWrapper->shouldReceive('runWithRetry')->once()->andReturnUsing(function (callable $cb) {
            return $cb();
        });
        // معرف فعال
        $db->shouldReceive('fetch')->andReturn((object)['id' => 10, 'status' => 'active', 'deleted_at' => null]);

        $captured = [];
        $commissionModel->shouldReceive('createCommission')->once()->andReturnUsing(function (array $data) use (&$captured) {
            $captured = $data;
            return (object)['id' => 77];
        });
        // واریز به معرف با همان ارز (depositInTransaction — قرارداد این مسیر)
        $wallet->shouldReceive('depositInTransaction')->once()->with(10, '5', 'usdt', m::any())
            ->andReturn(['success' => true, 'transaction_id' => 'RB-1']);
        // میلستون‌ها غیرفعال — kill-switch
        $appSettings->shouldReceive('get')->with('referral_milestones_enabled', '0')->andReturn('0');

        $result = $svc->awardSignupBonus(20, 'usdt');

        $this->assertTrue((bool)$result['success']);
        $this->assertSame('usdt', $captured['currency'], 'رکورد پورسانت باید usdt باشد');
        $this->assertSame('5', (string)$captured['amount']);
    }

    public function test_referral_record_pending_reward_uses_active_currency_and_usdt_key(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        [$svc, $db, , $commissionModel, $userModel, $transactionWrapper] = $this->referralService($appSettings);

        $referred = (object)['id' => 21, 'referred_by' => 11];
        $userModel->shouldReceive('findById')->with(21)->andReturn($referred);

        $appSettings->shouldReceive('get')->with('currency_mode', 'irt')->andReturn('usdt');
        $appSettings->shouldReceive('get')->with('referral_commission_enabled', '1')->andReturn('1');
        // کلید per-currency مقدم است
        $appSettings->shouldReceive('get')->with('referral_signup_bonus_usdt', '0')->andReturn('4');

        $commissionModel->shouldReceive('findByIdempotencyKey')->once()->andReturn(null);
        $transactionWrapper->shouldReceive('runWithRetry')->once()->andReturnUsing(function (callable $cb) {
            return $cb();
        });

        $captured = [];
        $commissionModel->shouldReceive('createCommission')->once()->andReturnUsing(function (array $data) use (&$captured) {
            $captured = $data;
            return (object)['id' => 78];
        });

        $result = $svc->recordPendingReferralRewardForVerifiedUser(21);

        $this->assertTrue((bool)$result['success']);
        $this->assertSame('usdt', $captured['currency'], 'پورسانت معلق باید با ارز فعال (usdt) ثبت شود');
        $this->assertSame('4', (string)$captured['amount']);
    }

    public function test_referral_record_pending_reward_irt_mode_uses_irt_key(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        [$svc, , , $commissionModel, $userModel, $transactionWrapper] = $this->referralService($appSettings);

        $referred = (object)['id' => 22, 'referred_by' => 12];
        $userModel->shouldReceive('findById')->with(22)->andReturn($referred);

        $appSettings->shouldReceive('get')->with('currency_mode', 'irt')->andReturn('irt');
        $appSettings->shouldReceive('get')->with('referral_commission_enabled', '1')->andReturn('1');
        $appSettings->shouldReceive('get')->with('referral_signup_bonus', '1000')->andReturn('1000');

        $commissionModel->shouldReceive('findByIdempotencyKey')->once()->andReturn(null);
        $transactionWrapper->shouldReceive('runWithRetry')->once()->andReturnUsing(function (callable $cb) {
            return $cb();
        });

        $captured = [];
        $commissionModel->shouldReceive('createCommission')->once()->andReturnUsing(function (array $data) use (&$captured) {
            $captured = $data;
            return (object)['id' => 79];
        });

        $result = $svc->recordPendingReferralRewardForVerifiedUser(22);

        $this->assertTrue((bool)$result['success']);
        $this->assertSame('irt', $captured['currency']);
        $this->assertSame('1000', (string)$captured['amount']);
    }

    // ─── ④ بونوس شروع: fail-safe در حالت تتر ────────────────────────────

    public function test_referral_start_bonus_usdt_mode_without_key_is_off(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        [$svc] = $this->referralService($appSettings);

        $appSettings->shouldReceive('get')->with('currency_mode', 'irt')->andReturn('usdt');
        $appSettings->shouldReceive('get')->with('referral_commission_enabled', '1')->andReturn('1');
        // کلید تومانی همیشه اول خوانده می‌شود؛ در حالت تتر توسط کلید USDT override می‌شود
        $appSettings->shouldReceive('get')->with('referral_start_bonus', '0')->andReturn('5000');
        // کلید تتر غایب → بونوس خاموش (fail-safe) حتی اگر کلید تومانی روشن باشد
        $appSettings->shouldReceive('get')->with('referral_start_bonus_usdt', null)->andReturn(null);

        $result = $svc->awardStartBonus(30);

        $this->assertFalse((bool)$result['success']);
        $this->assertFalse((bool)($result['awarded'] ?? true));
        $this->assertStringContainsString('پیکربندی نشده', (string)$result['message']);
    }

    public function test_referral_start_bonus_usdt_mode_with_key_deposits_usdt(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        [$svc, $db, $wallet, , , $transactionWrapper] = $this->referralService($appSettings);

        $appSettings->shouldReceive('get')->with('currency_mode', 'irt')->andReturn('usdt');
        $appSettings->shouldReceive('get')->with('referral_commission_enabled', '1')->andReturn('1');
        $appSettings->shouldReceive('get')->with('referral_start_bonus', '0')->andReturn('0');
        $appSettings->shouldReceive('get')->with('referral_start_bonus_usdt', null)->andReturn('3');
        $appSettings->shouldReceive('get')->with('referral_start_bonus_daily_cap', '100000')->andReturn('0');

        $transactionWrapper->shouldReceive('runWithRetry')->once()->andReturnUsing(function (callable $cb) {
            return $cb();
        });
        // probe سقف روزانه — بی‌سقف (cap=0) ⇒ probe اجرا نمی‌شود؛ مستقیم واریز
        $wallet->shouldReceive('depositInTransaction')->once()->with(30, '3', 'usdt', m::any())
            ->andReturn(['success' => true, 'transaction_id' => 'SB-1']);

        $result = $svc->awardStartBonus(30);

        $this->assertTrue((bool)$result['success']);
        $this->assertTrue((bool)($result['awarded'] ?? false));
    }

    // ─── ⑤ helperهای نمایش دو-ارزی ─────────────────────────────────────

    public function test_currency_label_and_code_contract(): void
    {
        $this->assertSame('تومان', currency_label('irt'));
        $this->assertSame('تتر', currency_label('usdt'));
        $this->assertSame('IRT', currency_code('irt'));
        $this->assertSame('USDT', currency_code('usdt'));
        // نرمال‌سازی ورودی
        $this->assertSame('تومان', currency_label(' IRT '));
        $this->assertSame('تتر', currency_label('Usdt'));
        // نامعتبر → برچسب ارز فعال (در محیط تست currency_mode غایب ⇒ irt/تومان)
        $this->assertSame(currency_active() === 'usdt' ? 'تتر' : 'تومان', currency_label('eur'));
        $this->assertSame(currency_active() === 'usdt' ? 'USDT' : 'IRT', currency_code('garbage'));
    }

    public function test_currency_active_is_normalized_irt_or_usdt(): void
    {
        $active = currency_active();
        $this->assertContains($active, ['irt', 'usdt'], 'ارز فعال فقط irt|usdt است');
        // در DB تست currency_mode ثبت نشده ⇒ دیفالت تومان
        $this->assertSame('irt', $active, 'پیش‌فرض پروژه تومان است (dیفالت تومان — تصمیم محصول)');
    }

    public function test_investment_currency_of_helper_contract(): void
    {
        $this->assertSame('irt', investment_currency_of((object)['currency' => 'irt']));
        $this->assertSame('usdt', investment_currency_of((object)['currency' => 'usdt']));
        $this->assertSame('irt', investment_currency_of((object)['currency' => 'IRT']));
        // legacy: ستون غایب → usdt (رفتار ردیف‌های قدیمی)
        $this->assertSame('usdt', investment_currency_of((object)['amount' => '10']));
        $this->assertSame('usdt', investment_currency_of(null));
        $this->assertSame('irt', investment_currency_of(['currency' => 'irt']));
        $this->assertSame('usdt', investment_currency_of(['currency' => 'USD']));
        $this->assertSame('usdt', investment_currency_of(['amount' => '5']));
    }
}
