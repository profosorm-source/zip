<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Events\AlertRequestedEvent;
use App\Services\Sentry\Alerting\AlertDispatcher;
use Mockery as m;
use PHPUnit\Framework\TestCase;
use Tests\Support\ResetsConfiguredRedis;

final class AlertDispatcherChannelIsolationTest extends TestCase
{
    use ResetsConfiguredRedis;

    protected function setUp(): void
    {
        parent::setUp();
        // 🛡️ FIX-Q4-CONTENT-HERMETIC: isThrottled() یک claimِ TTLدار در Redis
        // می‌گذارد (sentry:alert_throttle:...). fingerprint این رویداد قطعی است،
        // پس اجرای دومِ تستِ همان رویداد در پنجرهٔ ۶۰۰ ثانیه، throttled
        // برگرداند و storeAlert/getActiveChannels هرگز فراخوانی نمی‌شدند
        // (شکستِ «از قبل» گزارش‌شده). تست باید مستقل از اجراهای قبلی باشد.
        $this->resetConfiguredRedis();
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /** @test */
    public function malformed_channel_is_failed_and_following_channels_are_still_processed(): void
    {
        $model = m::mock(\App\Models\SentryModel::class);
        $model->shouldReceive('getLastAlert')->once()->andReturn(null);
        $model->shouldReceive('storeAlert')->once()->andReturn(901);
        $model->shouldReceive('getActiveChannels')->once()->andReturn([
            // Missing bot_token makes sendTelegram throw InvalidArgumentException.
            (object)['id' => 1, 'channel_type' => 'telegram', 'config' => '{"chat_id":"42"}'],
            // This second channel proves the loop continued after that exception.
            (object)['id' => 2, 'channel_type' => 'pager_duty', 'config' => '{}'],
        ]);
        $model->shouldReceive('recordNotificationHistory')->once()->with(1, 901, 'failed');
        $model->shouldReceive('recordNotificationHistory')->once()->with(2, 901, 'failed');
        $model->shouldNotReceive('markAlertAsSent');

        $settings = m::mock(\App\Services\Settings\AppSettings::class);
        $settings->shouldReceive('get')->andReturn(true);
        $logger = m::mock(\Core\Logger::class);
        $logger->shouldIgnoreMissing();

        $dispatcher = new AlertDispatcher(
            $model,
            $logger,
            m::mock(\Core\EventDispatcher::class),
            $settings
        );

        $result = $dispatcher->handleAlertRequest(new AlertRequestedEvent([
            'type' => 'channel_isolation_test',
            'severity' => 'critical',
            'title' => 'malformed channel',
            'message' => 'the next channel must still run',
            'environment' => 'testing',
        ]));

        $this->assertFalse($result);
    }

    /** @test */
    public function safe_webhook_resolution_rejects_private_targets_and_supports_pinning(): void
    {
        $dispatcher = new AlertDispatcher(
            m::mock(\App\Models\SentryModel::class),
            m::mock(\Core\Logger::class),
            m::mock(\Core\EventDispatcher::class),
            m::mock(\App\Services\Settings\AppSettings::class)
        );
        $method = new \ReflectionMethod(AlertDispatcher::class, 'isSafeUrl');
        $method->setAccessible(true);

        $this->assertNull($method->invoke($dispatcher, 'http://127.0.0.1/hook'));
        $resolved = $method->invoke($dispatcher, 'http://1.1.1.1/hook');
        $this->assertIsArray($resolved);
        $this->assertSame('1.1.1.1', $resolved['ip']);

        $source = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Services/Sentry/Alerting/AlertDispatcher.php');
        $this->assertStringContainsString('CURLOPT_RESOLVE', $source);
        $this->assertStringContainsString('CURLINFO_PRIMARY_IP', $source);
    }
}
