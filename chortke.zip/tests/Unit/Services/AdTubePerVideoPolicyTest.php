<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Contracts\LoggerInterface;
use App\Domain\Financial\Services\FinancialEscrowService;
use App\Services\Ads\AdsBudgetSettlementService;
use App\Services\Settings\AppSettings;
use App\Contracts\WalletServiceInterface;
use Core\Database;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-YT-7 (تصمیم ۲-گزینه A) — نمونه‌های تستی بستهٔ YT7 (فایل ۱ از ۲):
 * پین سیاستِ «سنجش بر مدتِ واقعیِ هر ویدیو، بدون هیچ پیش‌فرض».
 *
 * قرارداد adtubePerVideoPolicy:
 *   ۱) مدت ثبت‌شدهٔ رکورد اجرا (video_duration) ملاک است؛ در نبودش metadata
 *      کمپین (video_duration_seconds).
 *   ۲) کف سراسری adtube_watch_duration_seconds فقط floor است (max آن دو) —
 *      حداقل تماشا هرگز کمتر از خودِ ویدیو نمی‌شود (FIX-YT-3).
 *   ۳) هیچ مدتی ثبت نشده → 0 = fail-closed: نه fallback ۳۰، نه تسویه.
 *   ۴) declared_duration = مدت خام اعلانی (مبنای mismatch پلیر — FIX-R1-1)،
 *      نه مقدار floored.
 */
final class AdTubePerVideoPolicyTest extends TestCase
{
    private AdsBudgetSettlementService $service;

    /** @var \Mockery\MockInterface&AppSettings */
    private AppSettings $settings;

    protected function setUp(): void
    {
        parent::setUp();
        $this->settings = m::mock(AppSettings::class);
        $this->settings->shouldReceive('get')->with('adtube_watch_duration_seconds', 30)->andReturn(30)->byDefault();

        $db = m::mock(Database::class);
        $db->shouldIgnoreMissing();
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $escrow = m::mock(FinancialEscrowService::class);
        $escrow->shouldIgnoreMissing();
        $wallet = m::mock(WalletServiceInterface::class);
        $wallet->shouldIgnoreMissing();

        $this->service = new AdsBudgetSettlementService($db, $logger, $this->settings, $escrow, $wallet);
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    public function test_no_recorded_duration_anywhere_is_fail_closed_zero(): void
    {
        // نه video_duration و نه metadata → 0 (نه fallback ۳۰ ثانیه)
        $p = $this->service->adtubePerVideoPolicy(null, '');
        $this->assertSame(0, $p['required_duration'], 'بدون مدت ثبت‌شده، required_duration باید صفر باشد (fail-closed)');
        $this->assertSame(0, $p['min_watch_seconds']);
        $this->assertSame(0, $p['declared_duration']);
    }

    public function test_zero_or_negative_duration_is_also_fail_closed(): void
    {
        $p = $this->service->adtubePerVideoPolicy(0, '');
        $this->assertSame(0, $p['required_duration']);
        $this->assertSame(0, $this->service->adtubePerVideoPolicy(-5, '')['required_duration']);
    }

    public function test_video_duration_shorter_than_global_floor_uses_floor(): void
    {
        // ویدیوی ۱۰ثانیه‌ای، کف سراسری ۳۰ → سقفِ لازم = ۳۰ (floor برنده)
        $p = $this->service->adtubePerVideoPolicy(10, '');
        $this->assertSame(30, $p['required_duration']);
        // 🛡️ FIX-S20-CLOSE-F1 (پاداش به ۱× قفل شد): min_watch = کفِ فیزیکیِ رسیدن به
        // آستانهٔ ۸۰٪ در ۱× = ceil(30 × 0.8) = 24 — فرمول قبلی ceil(30/2.5)=12
        // مبتنی بر «ضربِ ادعای سرعت در زمان دیواری» بود که با POST مستقیم قابل
        // سوءاستفاده بود (۱۲ ثانیهٔ حضور بدون هیچ پخش = پاداش کامل).
        $this->assertSame(24, $p['min_watch_seconds'], 'min_watch = ceil(required×80٪) در ۱×: ceil(30×0.8)=24');
        // FIX-R1-1: declared خام می‌ماند (۱۰)، نه floored (۳۰)
        $this->assertSame(10, $p['declared_duration'], 'declared_duration باید مدت خام ویدیو باشد — مبنای mismatch پلیر');
    }

    public function test_video_longer_than_floor_wins_over_floor(): void
    {
        // ویدیوی ۴۵ثانیه‌ای > کف ۳۰ → ۴۵ (FIX-YT-3: حداقل تماشا هرگز کمتر از خود ویدیو نیست)
        $p = $this->service->adtubePerVideoPolicy(45, '');
        $this->assertSame(45, $p['required_duration']);
        $this->assertSame(45, $p['declared_duration']);
        // 🛡️ FIX-S20-CLOSE-F1: حداقل زمان دیواری = کفِ آستانهٔ ۸۰٪ در ۱× = ceil(45×0.8) = 36
        $this->assertSame(36, $p['min_watch_seconds']);
    }

    public function test_metadata_is_the_fallback_when_record_duration_missing(): void
    {
        // رکورد مدت ندارد؛ metadata کمپین video_duration_seconds=60 دارد → ملاک
        $meta = json_encode(['video_duration_seconds' => 60, 'title' => 'x']);
        $p = $this->service->adtubePerVideoPolicy(null, $meta);
        $this->assertSame(60, $p['required_duration']);
        $this->assertSame(60, $p['declared_duration']);
    }

    public function test_record_duration_takes_priority_over_metadata(): void
    {
        // رکورد ۲۰ دارد، metadata 99 می‌گوید → رکورد ملاک (منبع درج reserveSlot)
        $meta = json_encode(['video_duration_seconds' => 99]);
        $p = $this->service->adtubePerVideoPolicy(20, $meta);
        $this->assertSame(30, $p['required_duration'], 'رکورد=۲۰ بر metadata=۹۹ مقدم است؛ سپس floor ۳۰ اعمال می‌شود');
        $this->assertSame(20, $p['declared_duration']);
    }

    public function test_garbage_metadata_does_not_crash_and_stays_fail_closed(): void
    {
        $p = $this->service->adtubePerVideoPolicy(null, 'not-json{{');
        $this->assertSame(0, $p['required_duration']);
        // metadata معتبر ولی بدون کلید مدت
        $p2 = $this->service->adtubePerVideoPolicy(null, json_encode(['title' => 'x']));
        $this->assertSame(0, $p2['required_duration']);
    }

    public function test_min_watch_seconds_is_at_least_two_and_proportional(): void
    {
        // کف امن min_watch=2 حتی برای ویدیوهای بسیار کوتاه زیر کف سراسری
        $p = $this->service->adtubePerVideoPolicy(3, '');
        $this->assertSame(30, $p['required_duration']); // floor 30 برنده
        // 🛡️ FIX-S20-CLOSE-F1: required=30 → ceil(30×0.8)=24 در ۱×
        $this->assertSame(24, $p['min_watch_seconds']);
    }

    public function test_max_speed_is_the_policy_cap(): void
    {
        $p = $this->service->adtubePerVideoPolicy(30, '');
        // 🛡️ FIX-S20-CLOSE-F1 (پایان‌کار بازبینی S20 — یافتهٔ ۱): پاداش به ۱× قفل شد —
        // سقف ۲.۵x قبلی یعنی «ضربِ ادعای سرعتِ کلاینت در زمان دیواری» که با POST
        // مستقیم قابل دور زدن بود؛ اکنون ادعای سرعت در پاداش بی‌اثر است (کلمپ ۱×)
        // و فقط مقادیر غیرممکن (>۲.۵) در کنترلر به‌عنوان دستکاری رد می‌شوند.
        $this->assertSame(1.0, $p['max_speed'], 'سقف سرعت سیاست AdTube = 1.0x (قفل پاداش)');
    }

    public function test_duration_mismatch_percent_default_and_clamps(): void
    {
        // پیش‌فرض ۱۰٪
        $this->settings->shouldReceive('get')->with('adtube_duration_mismatch_percent', 10)->andReturn(10)->once();
        $this->assertSame(10.0, $this->service->adtubeDurationMismatchPercent());

        // کلمپ پایین: 0.2 → 1.0
        $this->settings->shouldReceive('get')->with('adtube_duration_mismatch_percent', 10)->andReturn(0.2)->once();
        $this->assertSame(1.0, $this->service->adtubeDurationMismatchPercent());

        // کلمپ بالا: 500 → 100
        $this->settings->shouldReceive('get')->with('adtube_duration_mismatch_percent', 10)->andReturn(500)->once();
        $this->assertSame(100.0, $this->service->adtubeDurationMismatchPercent());

        // مقدار غیرعددی → همان پیش‌فرض ۱۰
        $this->settings->shouldReceive('get')->with('adtube_duration_mismatch_percent', 10)->andReturn('garbage')->once();
        $this->assertSame(10.0, $this->service->adtubeDurationMismatchPercent());
    }
}
