<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Contracts\LoggerInterface;
use App\Contracts\OutboxServiceInterface;
use App\Models\ContentAgreement;
use App\Models\ContentRevenue;
use App\Models\ContentSubmission;
use App\Services\ContentService;
use App\Services\Settings\AppSettings;
use Core\Database;
use Core\TransactionWrapper;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-MOD24-06 — ویرایش کامل محتوا + رفع تعلیق ادمین + آزادسازی URL ردشده.
 *
 * پوشش:
 *   - updateSubmission: مالکیت (کاربر دیگر ⇒ خطا)، وضعیت تعلیق (قفل ادمین)،
 *     ترنزیشن‌ها (rejected/pending/under_review/approved/published → pending)،
 *     CAS (رقابت ادمین/کاربر)، URL تکراریِ محتوای فعال دیگران ⇒ رد،
 *     URL خودِ رکورد ⇒ مجاز، اعتبارسنجی پلتفرم/عنوان
 *   - unsuspendSubmission: فقط suspended → approved (زیر قفل + بررسی نتیجهٔ update)،
 *     وضعیت غیر suspended ⇒ خطا، اطلاع‌رسانی کاربر
 *   - isUrlExists (سطح مدل): SQL باید محتوای rejected را مستثنا کند
 *
 * سبک خانه: آینهٔ ContentRevenueLifecycleTest (Mockery + TransactionWrapper مستقیم).
 */
final class ContentSubmissionEditTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    /** @param array<string, mixed> $overrides */
    private function submissionRow(array $overrides = []): \stdClass
    {
        return (object) array_merge([
            'id' => 10,
            'user_id' => 5,
            'status' => ContentSubmission::STATUS_PENDING,
            'platform' => 'aparat',
            'video_url' => 'https://www.aparat.com/v/abc123',
            'title' => 'عنوان تستی معتبر',
            'description' => 'توضیح',
            'category' => 'tech',
        ], $overrides);
    }

    /**
     * @param callable|null $runBehavior رفتار TransactionWrapper::run
     * @param callable|null $casBehavior رفتار QueryBuilder CAS (updateSubmission)
     * @param \App\Services\AntiFraud\VideoFingerprintService|null $videoFingerprint 🛡️ FIX-A24-02
     */
    private function buildService(
        ContentSubmission $submission,
        Database $db,
        ?callable $runBehavior = null,
        ?OutboxServiceInterface $outbox = null,
        ?\App\Services\AntiFraud\VideoFingerprintService $videoFingerprint = null
    ): ContentService {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        $wrapper = m::mock(TransactionWrapper::class);
        $run = $runBehavior ?? static fn (callable $c) => $c();
        $wrapper->shouldReceive('run')->andReturnUsing($run)->byDefault();

        return new ContentService(
            $logger,
            $db,
            $submission,
            m::mock(ContentRevenue::class),
            m::mock(ContentAgreement::class),
            $wrapper,
            m::mock(AppSettings::class),
            $outbox,
            null,
            null,
            $videoFingerprint
        );
    }

    private function dbMock(): m\MockInterface
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('inTransaction')->andReturn(false)->byDefault();
        $db->shouldReceive('beginTransaction')->byDefault();
        $db->shouldReceive('commit')->byDefault();
        $db->shouldReceive('rollback')->byDefault();
        $db->shouldReceive('query')->andReturn(m::mock(\PDOStatement::class))->byDefault();
        return $db;
    }

    /** ورودی معتبر ویرایش (آپارات) */
    private function validInput(): array
    {
        return [
            'platform' => 'aparat',
            'video_url' => 'https://www.aparat.com/v/abc123',
            'title' => 'عنوان تستی معتبر',
            'description' => 'توضیح اصلاح‌شده',
            'category' => 'tech',
        ];
    }

    // ─────────────────────────────────────────────────────────────
    // مالکیت و وضعیت
    // ─────────────────────────────────────────────────────────────

    public function test_update_rejects_foreign_owner(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow(['user_id' => 99]));

        $service = $this->buildService($submission, $this->dbMock());

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('دسترسی');
        $service->updateSubmission(5, 10, $this->validInput());
    }

    public function test_update_rejects_suspended_submission(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow([
            'status' => ContentSubmission::STATUS_SUSPENDED,
        ]));

        $service = $this->buildService($submission, $this->dbMock());

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('قابل ویرایش نیست');
        $service->updateSubmission(5, 10, $this->validInput());
    }

    /**
     * @dataProvider editableStatusesProvider
     */
    public function test_update_moves_every_editable_status_back_to_pending(string $from): void
    {
        $captured = [];
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow(['status' => $from]));
        // excludeId=خودِ رکورد ⇒ URL خودی آزاد است
        // 🛡️ FIX-A24-04/T24-01: یکتایی ویرایش هم مثل ثبت، بر url_hash نرمال‌شده
        // با platform چک می‌شود (سه‌آرگومانی — قبلاً خام/دو‌آرگومانی بود)
        $submission->shouldReceive('isUrlExists')->once()
            ->with('https://www.aparat.com/v/abc123', 10, 'aparat')->andReturn(false);

        $db = $this->dbMock();
        $qb = m::mock(\Core\QueryBuilder::class);
        $qb->shouldReceive('where')->once()->with('id', '=', 10)->andReturnSelf();
        $qb->shouldReceive('whereIn')->once()->with('status', m::on(
            static fn (array $s): bool => in_array($from, $s, true)
                && !in_array(ContentSubmission::STATUS_SUSPENDED, $s, true)
        ))->andReturnSelf();
        $qb->shouldReceive('update')->once()->with(m::on(
            static function (array $data) use (&$captured): bool {
                $captured = $data;
                return true;
            }
        ))->andReturn(1);
        $db->shouldReceive('table')->once()->with('content_submissions')->andReturn($qb);

        $service = $this->buildService($submission, $db);

        $result = $service->updateSubmission(5, 10, $this->validInput());

        $this->assertTrue($result['success']);
        // همهٔ فیلدهای فرم کامل نوشته می‌شوند + بازگشت به صف بررسی
        $this->assertSame(ContentSubmission::STATUS_PENDING, $captured['status']);
        foreach (['platform', 'video_url', 'url', 'url_hash', 'title', 'description', 'category'] as $field) {
            $this->assertArrayHasKey($field, $captured, "فیلد {$field} باید در ویرایش نوشته شود");
        }
        // 🛡️ FIX-A24-04/T24-01: هش نرمال‌شده با (platform, url) جدید بازسازی می‌شود
        $this->assertSame(
            ContentSubmission::hashVideoUrl('aparat', 'https://www.aparat.com/v/abc123'),
            $captured['url_hash'],
            'url_hash باید پس از ویرایش بازسازی شود (نه هش کهنه)'
        );
        // پیام بازارسال فقط برای محتوای ردشده
        $this->assertSame(
            $from === ContentSubmission::STATUS_REJECTED,
            str_contains($result['message'], 'ارسال مجدد') || str_contains($result['message'], 'اصلاحات')
        );
    }

    /** @return list<list<string>> */
    public function editableStatusesProvider(): array
    {
        return [
            [ContentSubmission::STATUS_PENDING],
            [ContentSubmission::STATUS_UNDER_REVIEW],
            [ContentSubmission::STATUS_REJECTED],
            [ContentSubmission::STATUS_APPROVED],
            [ContentSubmission::STATUS_PUBLISHED],
        ];
    }

    public function test_update_loses_cas_race_with_admin_action(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow());
        $submission->shouldReceive('isUrlExists')->once()->andReturn(false);

        $db = $this->dbMock();
        $qb = m::mock(\Core\QueryBuilder::class);
        $qb->shouldReceive('where')->andReturnSelf();
        $qb->shouldReceive('whereIn')->andReturnSelf();
        $qb->shouldReceive('update')->once()->andReturn(0); // ادمین هم‌زمان تعلیق کرد
        $db->shouldReceive('table')->once()->andReturn($qb);

        $service = $this->buildService($submission, $db);

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('توسط فرایند دیگری');
        $service->updateSubmission(5, 10, $this->validInput());
    }

    public function test_update_rejects_url_claimed_by_active_submission_of_others(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow());
        // محتوای فعالِ کاربر دیگر همین URL را دارد
        $submission->shouldReceive('isUrlExists')->once()->andReturn(true);

        $service = $this->buildService($submission, $this->dbMock());

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('قبلاً');
        $service->updateSubmission(5, 10, $this->validInput());
    }

    public function test_update_rejects_invalid_platform(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow());

        $service = $this->buildService($submission, $this->dbMock());

        try {
            $service->updateSubmission(5, 10, array_merge($this->validInput(), ['platform' => 'tiktok']));
            $this->fail('platform نامعتبر باید رد شود');
        } catch (\Core\Exceptions\BusinessException $e) {
            $this->assertStringContainsString('پلتفرم', $e->getMessage());
        }
    }

    public function test_update_rejects_short_title(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow());
        $submission->shouldReceive('isUrlExists')->once()->andReturn(false);

        $service = $this->buildService($submission, $this->dbMock());

        try {
            $service->updateSubmission(5, 10, array_merge($this->validInput(), ['title' => 'کوتا']));
            $this->fail('عنوان کوتاه باید رد شود');
        } catch (\Core\Exceptions\BusinessException $e) {
            $this->assertStringContainsString('عنوان', $e->getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────
    // رفع تعلیق (ادمین)
    // ─────────────────────────────────────────────────────────────

    public function test_unsuspends_suspended_submission_to_approved_under_lock(): void
    {
        $captured = [];
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow([
            'status' => ContentSubmission::STATUS_SUSPENDED,
            'user_id' => 5,
        ]));
        // 🛡️ FIX-MOD24-20: نتیجهٔ update بررسی می‌شود
        $submission->shouldReceive('update')->once()->with(10, m::on(
            static function (array $data) use (&$captured): bool {
                $captured = $data;
                return true;
            }
        ))->andReturn(true);

        $db = $this->dbMock();
        $lockStmt = m::mock(\PDOStatement::class);
        $lockStmt->shouldReceive('fetch')->once()->with(\PDO::FETCH_OBJ)
            ->andReturn((object)['id' => 10, 'status' => ContentSubmission::STATUS_SUSPENDED]);
        $db->shouldReceive('query')->once()->with(
            m::on(static fn (string $sql): bool => str_contains($sql, 'FOR UPDATE')),
            [10]
        )->andReturn($lockStmt);

        $outbox = m::mock(OutboxServiceInterface::class);
        $outbox->shouldReceive('record')->once()->with(
            'notification', 5, 'notification.requested',
            m::on(static fn (array $d): bool => $d['type'] === 'content_unsuspended' && $d['user_id'] === 5)
        )->andReturn(true);

        $service = $this->buildService($submission, $db, null, $outbox);
        $result = $service->unsuspendSubmission(10, 77);

        $this->assertTrue($result['success']);
        $this->assertSame(ContentSubmission::STATUS_APPROVED, $captured['status']);
        // پاکسازی دلیل تعلیق + مالکیت مهر تعلیق
        $this->assertNull($captured['rejection_reason']);
        $this->assertNull($captured['suspended_by']);
        $this->assertNull($captured['suspended_at']);
    }

    public function test_unsuspend_rejects_non_suspended_status(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow([
            'status' => ContentSubmission::STATUS_APPROVED,
        ]));

        $service = $this->buildService($submission, $this->dbMock());

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('فقط محتوای تعلیق‌شده');
        $service->unsuspendSubmission(10, 77);
    }

    public function test_unsuspend_rolls_back_when_status_changed_under_lock(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow([
            'status' => ContentSubmission::STATUS_SUSPENDED,
        ]));

        $db = $this->dbMock();
        $lockStmt = m::mock(\PDOStatement::class);
        // زیر قفل: وضعیت دیگر suspended نیست (رقابت) ⇒ باید استثنا بدهد؛
        // rollback واقعی مسئول TransactionWrapper است (در تست، wrapper مستقیم اجرا می‌کند)
        $lockStmt->shouldReceive('fetch')->once()->andReturn((object)['id' => 10, 'status' => 'approved']);
        $db->shouldReceive('query')->once()->andReturn($lockStmt);

        $service = $this->buildService($submission, $db);

        try {
            $service->unsuspendSubmission(10, 77);
            $this->fail('وضعیت زیر قفل باید خطا بدهد');
        } catch (\Core\Exceptions\BusinessException $e) {
            $this->assertStringContainsString('فقط محتوای تعلیق‌شده', $e->getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────
    // مدل: آزادسازی URL محتوای ردشده (FIX-MOD24-06)
    // ─────────────────────────────────────────────────────────────

    public function test_is_url_exists_sql_excludes_rejected_submissions(): void
    {
        $capturedSql = '';
        $capturedParams = [];
        $db = m::mock(Database::class);
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('fetch')->once()->andReturn((object)['total' => '0']);
        $db->shouldReceive('query')->once()->with(
            m::on(static function (string $sql) use (&$capturedSql): bool {
                $capturedSql = $sql;
                return true;
            }),
            m::on(static function (array $p) use (&$capturedParams): bool {
                $capturedParams = $p;
                return true;
            })
        )->andReturn($stmt);

        $model = new ContentSubmission($db);
        $this->assertFalse($model->isUrlExists('https://www.aparat.com/v/x', 10));

        // محتوای ردشده در شمارش یکتایی URL نیست (بازارسال همان ویدیو ممکن است)
        $this->assertStringContainsString('status != ?', $capturedSql);
        $this->assertSame(ContentSubmission::STATUS_REJECTED, $capturedParams[1]);
        $this->assertSame(10, $capturedParams[2]);
        // ستون platform در whitelist ویرایش موجود است (فرم کامل)
        $ref = new \ReflectionMethod(ContentSubmission::class, 'update');
        $ref->setAccessible(true);
        $this->assertTrue(true); // placeholder برای خوانایی؛ whitelist در تست پایین پین شده
    }

    public function test_update_whitelist_includes_platform(): void
    {
        // فرم ویرایش کامل باید بتواند پلتفرم را هم بازنویسی کند (سرویس با
        // همان مقدار/مقدار سازگار) و url_hash نیز پس از ویرایش بازسازی می‌شود
        // (🛡️ FIX-A24-04/T24-01 — whitelist مدل باید هش را بپذیرد)
        $source = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Models/ContentSubmission.php');
        $this->assertStringContainsString("'title', 'description', 'category', 'video_url', 'url', 'platform',", $source);
        $this->assertStringContainsString("'url_hash',", $source, 'url_hash باید در whitelist مدل باشد (بازسازی پس از ویرایش)');
    }

    /**
     * 🛡️ FIX-A24-02 — ثبت اثر انگشت فقط پس از موفقیت ویرایش و فقط وقتی
     * (platform, url) واقعاً عوض شده؛ ویرایش بدون تغییر لینک نباید ویدیوی
     * خود مالک را دوباره بازرسی/ثبت کند (هشدار کاذب + بازنویسی بی‌مورد corpus).
     */
    public function test_update_records_fingerprint_only_when_video_changed(): void
    {
        // حالت ۱: لینک جدید → بازرسی (inspect) + ثبت (recordFingerprint) هر دو
        $fingerprint = m::mock(\App\Services\AntiFraud\VideoFingerprintService::class);
        $fingerprint->shouldReceive('inspect')->once()
            ->with('https://www.aparat.com/v/new456', 'aparat')
            ->andReturn(['inspected' => true, 'is_duplicate' => false, 'confidence' => 0.0, 'mode' => 'log-only']);
        $fingerprint->shouldReceive('recordFingerprint')->once()
            ->with('https://www.aparat.com/v/new456', 'aparat')
            ->andReturn(1);

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn(
            $this->submissionRow(['video_url' => 'https://www.aparat.com/v/old123'])
        );
        $submission->shouldReceive('isUrlExists')->once()->andReturn(false);

        $db = $this->dbMock();
        $qb = m::mock(\Core\QueryBuilder::class);
        $qb->shouldReceive('where')->andReturnSelf();
        $qb->shouldReceive('whereIn')->andReturnSelf();
        $qb->shouldReceive('update')->once()->andReturn(1);
        $db->shouldReceive('table')->once()->andReturn($qb);

        $service = $this->buildService($submission, $db, null, null, $fingerprint);
        $result = $service->updateSubmission(5, 10, array_merge($this->validInput(), [
            'video_url' => 'https://www.aparat.com/v/new456',
        ]));
        $this->assertTrue($result['success']);

        // حالت ۲: بدون تغییر (platform, url) → نه بازرسی، نه ثبت
        $fingerprintUnchanged = m::mock(\App\Services\AntiFraud\VideoFingerprintService::class);
        $fingerprintUnchanged->shouldReceive('inspect')->never();
        $fingerprintUnchanged->shouldReceive('recordFingerprint')->never();

        $submission2 = m::mock(ContentSubmission::class);
        $submission2->shouldReceive('find')->once()->andReturn($this->submissionRow());
        $submission2->shouldReceive('isUrlExists')->once()->andReturn(false);

        $db2 = $this->dbMock();
        $qb2 = m::mock(\Core\QueryBuilder::class);
        $qb2->shouldReceive('where')->andReturnSelf();
        $qb2->shouldReceive('whereIn')->andReturnSelf();
        $qb2->shouldReceive('update')->once()->andReturn(1);
        $db2->shouldReceive('table')->once()->andReturn($qb2);

        $service2 = $this->buildService($submission2, $db2, null, null, $fingerprintUnchanged);
        $result2 = $service2->updateSubmission(5, 10, $this->validInput());
        $this->assertTrue($result2['success']);
    }

    /**
     * 🛡️ FIX-A24-04 — تغییر پلتفرم با لینکِ ناسازگار باید رد شود (اعتبارسنجی
     * الگوی لینک/پلتفرم در سرویس) — پلتفرم جزو url_hash است و این گارد
     * جابه‌جایی بی‌هماهنگ فضای یکتایی را می‌بندد.
     */
    public function test_update_rejects_platform_switch_with_mismatched_url(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow(['platform' => 'aparat']));

        $service = $this->buildService($submission, $this->dbMock());

        try {
            // پلتفرم یوتیوب ولی لینک آپارات → ناسازگار
            $service->updateSubmission(5, 10, array_merge($this->validInput(), ['platform' => 'youtube']));
            $this->fail('لینک ناسازگار با پلتفرم جدید باید رد شود');
        } catch (\Core\Exceptions\BusinessException $e) {
            $this->assertStringContainsString('لینک ویدیو نامعتبر', $e->getMessage());
        }
    }
}
