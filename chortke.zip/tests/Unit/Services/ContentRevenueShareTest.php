<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Contracts\LoggerInterface;
use App\Contracts\OutboxServiceInterface;
use App\Models\ContentAgreement;
use App\Models\ContentRevenue;
use App\Models\ContentSubmission;
use App\Services\ContentService;
use App\Services\Settings\AppSettings;
use Core\Database;
use Core\TransactionWrapper;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-MOD24-01 — تست‌های invariant تقسیم درآمد محتوا.
 *
 * گزارش بخش ۲۴ (MOD24-01): سهم سایت مستقل از تنظیمات (۴۰٪) و سهم کاربر
 * «۱۰۰ منهای سهم سایت + پاداش سطح» بود و پاداش از سهم سایت کسر نمی‌شد ⇒
 * عادی ۱۰۰٪، فعال ۱۰۵٪، حرفه‌ای ۱۱۰٪ (با سقف ۸۰٪ تا ۱۲۰٪) توزیع می‌شد.
 *
 * این تست‌ها قرارداد جدید را pin می‌کنند:
 *   ۱) سهم سایت = باقی‌ماندهٔ سهم کاربر ⇒ جمع دقیقاً ۱۰۰٪ در هر سه سطح.
 *   ۲) جمع مبالغ هرگز از درآمد کل بیشتر نمی‌شود (تلورانس گرد کردن ۲ رقمی).
 *   ۳) تنظیمات ناسازگار (سهم کاربر > ۱۰۰٪) fail-loud است، نه توزیع بیش از ۱۰۰٪.
 */
final class ContentRevenueShareTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    /**
     * سرویس با تنظیمات و سطح فعالیت قابل تزریق.
     *
     * @param array<string, float> $settings مقادیر AppSettings
     * @param int $activeMonths ماه‌های فعالیت کاربر (خروجی getActiveMonths)
     * @param int $publishedCount تعداد محتوای published کاربر
     * @param ContentRevenue $revenueModel مدل درآمد (برای assert روی create)
     */
    private function buildService(
        array $settings,
        int $activeMonths,
        int $publishedCount,
        ?ContentRevenue $revenueModel = null,
        ?\stdClass &$capturedCreate = null
    ): ContentService {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        $settingsMock = m::mock(AppSettings::class);
        foreach ($settings as $key => $value) {
            $settingsMock->shouldReceive('get')->with($key, m::any())->andReturn($value)->byDefault();
        }
        $settingsMock->shouldIgnoreMissing(0);

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->with(10)->andReturn((object)[
            'id' => 10,
            'user_id' => 5,
            'status' => ContentSubmission::STATUS_PUBLISHED,
        ])->byDefault();
        $submission->shouldReceive('getActiveMonths')->with(5)->andReturn($activeMonths)->byDefault();
        $submission->shouldReceive('countByUser')->with(5, ContentSubmission::STATUS_PUBLISHED)->andReturn($publishedCount)->byDefault();

        $revenue = $revenueModel ?? m::mock(ContentRevenue::class);
        $revenue->shouldReceive('existsForPeriod')->andReturn(false)->byDefault();
        if ($capturedCreate !== null) {
            $revenue->shouldReceive('create')->once()->andReturnUsing(
                static function (array $data) use (&$capturedCreate) {
                    $capturedCreate = (object)$data;
                    return 77;
                }
            );
        } else {
            $revenue->shouldReceive('create')->andReturn(77)->byDefault();
        }

        $db = m::mock(Database::class);
        $db->shouldReceive('beginTransaction')->byDefault();
        $db->shouldReceive('commit')->byDefault();
        $db->shouldReceive('rollback')->byDefault();
        $db->shouldReceive('inTransaction')->andReturn(false)->byDefault();
        $db->shouldReceive('query')->andReturn(m::mock(\PDOStatement::class))->byDefault();

        return new ContentService(
            $logger,
            $db,
            $submission,
            $revenue,
            m::mock(ContentAgreement::class),
            m::mock(TransactionWrapper::class),
            $settingsMock,
            null // outbox
        );
    }

    /** تنظیمات پیش‌فرض گزارش: سایت ۴۰٪، پاداش فعال +۵/سقف ۷۵، حرفه‌ای +۱۰/سقف ۸۰ */
    private function defaultSettings(): array
    {
        return [
            'content_site_share_percent' => 40.0,
            'content_tax_percent' => 9.0,
            'content_active_bonus_percent' => 5.0,
            'content_active_max_percent' => 75.0,
            'content_professional_bonus_percent' => 10.0,
            'content_professional_max_percent' => 80.0,
            'currency_mode' => 'irt',
        ];
    }

    /** @return array{0: float, 1: float} [userPercent, sitePercent] از رکورد ثبت‌شده */
    private function recordAndCapture(array $settings, int $activeMonths, int $publishedCount): \stdClass
    {
        $captured = new \stdClass();
        $service = $this->buildService($settings, $activeMonths, $publishedCount, null, $captured);
        $result = $service->recordRevenue(10, 1, ['total_revenue' => 1000.0, 'period' => '1405-07', 'views' => 100]);
        $this->assertTrue($result['success'] ?? false, 'recordRevenue باید موفق باشد');
        $this->assertNotNull($captured, 'رکورد درآمد باید create شود');
        return $captured;
    }

    public function test_normal_tier_shares_sum_to_exactly_100(): void
    {
        // عادی: فعال (برای واجد بودنِ ثبت درآمد MIN_MONTHS_FOR_REVENUE=2 لازم است)
        // اما زیر آستانهٔ tier فعال (۶ ماه) و حرفه‌ای (۱۲ ماه).
        $row = $this->recordAndCapture($this->defaultSettings(), 2, 0);

        // عادی: کاربر ۶۰٪ / سایت ۴۰٪ (رفتار قبلی همین سطح درست بود — pin می‌شود)
        $this->assertSame(60.0, $row->user_share_percent);
        $this->assertSame(40.0, $row->site_share_percent);
        $this->assertSame(100.0, $row->user_share_percent + $row->site_share_percent);
    }

    public function test_active_tier_shares_sum_to_exactly_100_not_105(): void
    {
        // ACTIVE_TIER_MONTHS = 6, ACTIVE_TIER_SUBMISSIONS = 5
        $row = $this->recordAndCapture($this->defaultSettings(), 6, 5);

        // فعال: کاربر ۶۵٪ / سایت ۳۵٪ — قبلاً ۶۵٪ + ۴۰٪ = ۱۰۵٪ می‌شد
        $this->assertSame(65.0, $row->user_share_percent);
        $this->assertSame(35.0, $row->site_share_percent);
        $this->assertSame(100.0, $row->user_share_percent + $row->site_share_percent);
    }

    public function test_professional_tier_shares_sum_to_exactly_100_not_110(): void
    {
        // PROFESSIONAL_TIER_MONTHS = 12, PROFESSIONAL_TIER_SUBMISSIONS = 10
        $row = $this->recordAndCapture($this->defaultSettings(), 12, 10);

        // حرفه‌ای: کاربر ۷۰٪ / سایت ۳۰٪ — قبلاً ۷۰٪ + ۴۰٪ = ۱۱۰٪ می‌شد
        // (گزارش MOD24-01: برای هر رکورد حرفه‌ای ۱۰٪ بیش از درآمد کل پرداخت می‌شد)
        $this->assertSame(70.0, $row->user_share_percent);
        $this->assertSame(30.0, $row->site_share_percent);
        $this->assertSame(100.0, $row->user_share_percent + $row->site_share_percent);
    }

    public function test_share_amounts_never_exceed_total_revenue(): void
    {
        // عدد ناجور برای گرد کردن: 999.99 با سهم ۳۵/۶۵
        $row = $this->recordAndCapture($this->defaultSettings(), 6, 5);
        // این assert روی رکورد ۱۰۰۰ است؛ برای عدد ناجور مسیر جدا:
        $captured = new \stdClass();
        $service = $this->buildService($this->defaultSettings(), 6, 5, null, $captured);
        $service->recordRevenue(10, 1, ['total_revenue' => 999.99, 'period' => '1405-07']);

        $sum = (float)$captured->site_share_amount + (float)$captured->user_share_amount;
        $this->assertLessThanOrEqual(999.99 + 0.02, $sum, 'جمع سهم‌ها نباید از درآمد کل (با تلورانس گرد کردن) بیشتر شود');
        $this->assertSame(100.0, (float)$captured->user_share_percent + (float)$captured->site_share_percent);
    }

    public function test_misconfigured_settings_user_share_over_100_fail_loud(): void
    {
        // سهم سایت منفی (خطای ادمین) + سقف سطح ۱۳۰ ⇒ پایه ۱۰۵ + پاداش ⇒ > ۱۰۰٪
        $settings = $this->defaultSettings();
        $settings['content_site_share_percent'] = -5.0;
        $settings['content_professional_max_percent'] = 130.0;

        $service = $this->buildService($settings, 12, 10);

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('سهم کاربر بیش از ۱۰۰٪');
        $service->recordRevenue(10, 1, ['total_revenue' => 1000.0, 'period' => '1405-07']);
    }

    public function test_tier_floor_never_reduces_user_below_base(): void
    {
        // FIX-R36-W3 حفظ شده: سقف سطحِ پایین‌تر از پایه، سهم کاربر را از پایه کم نمی‌کند
        // پایه ۶۰؛ سقف حرفه‌ای ۵۰ ⇒ min(70,50)=50 ⇒ max(60,50)=60 ⇒ سایت ۴۰
        $settings = $this->defaultSettings();
        $settings['content_professional_max_percent'] = 50.0;

        $row = $this->recordAndCapture($settings, 12, 10);

        $this->assertSame(60.0, $row->user_share_percent);
        $this->assertSame(40.0, $row->site_share_percent);
        $this->assertSame(100.0, $row->user_share_percent + $row->site_share_percent);
    }
}
