<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Contracts\LoggerInterface;
use App\Contracts\OutboxServiceInterface;
use App\Contracts\WalletServiceInterface;
use App\Models\ContentAgreement;
use App\Models\ContentRevenue;
use App\Models\ContentSubmission;
use App\Services\ContentService;
use App\Services\Settings\AppSettings;
use Core\Database;
use Core\TransactionWrapper;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-MOD24-02/03/20 — تست‌های چرخهٔ حیات درآمد محتوا.
 *
 * MOD24-02: تأیید و پرداخت درآمد باید به وضعیت محتوای مبدأ گره بخورد —
 * درآمد محتوای تعلیق‌شده (مثلاً به‌دلیل کپی) قابل تأیید/پرداخت نیست؛ و
 * تعلیق، رکوردهای درآمد باز (pending/approved) را به cancelled می‌برد.
 * MOD24-03: تأیید درآمد با CAS اتمیک (status='pending' در WHERE + rowCount).
 * MOD24-20: خروجی update در payRevenue بررسی می‌شود (deposit ↔ وضعیت هم‌تراز).
 */
final class ContentRevenueLifecycleTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    /** @param array<string, mixed> $overrides */
    private function revenueRow(array $overrides = []): \stdClass
    {
        return (object) array_merge([
            'id' => 55,
            'submission_id' => 10,
            'content_id' => 10,
            'user_id' => 5,
            'status' => ContentRevenue::STATUS_APPROVED,
            'net_user_amount' => '900.00000000',
            'amount' => '900.00000000',
            'currency' => 'irt',
            'period' => '1405-07',
        ], $overrides);
    }

    /** @param array<string, mixed> $overrides */
    private function submissionRow(array $overrides = []): \stdClass
    {
        return (object) array_merge([
            'id' => 10,
            'user_id' => 5,
            'status' => ContentSubmission::STATUS_PUBLISHED,
        ], $overrides);
    }

    /**
     * @param callable|null $runBehavior رفتار TransactionWrapper::run (پیش‌فرض: اجرای مستقیم closure)
     */
    private function buildService(
        ContentRevenue $revenue,
        ContentSubmission $submission,
        Database $db,
        ?WalletServiceInterface $wallet = null,
        ?callable $runBehavior = null,
        ?OutboxServiceInterface $outbox = null
    ): ContentService {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        $wrapper = m::mock(TransactionWrapper::class);
        $run = $runBehavior ?? static fn (callable $c) => $c();
        $wrapper->shouldReceive('run')->andReturnUsing($run)->byDefault();

        return new ContentService(
            $logger,
            $db,
            $submission,
            $revenue,
            m::mock(ContentAgreement::class),
            $wrapper,
            m::mock(AppSettings::class),
            $outbox,
            null,
            $wallet
        );
    }

    private function dbMock(): m\MockInterface
    {
        $db = m::mock(Database::class);
        $db->shouldReceive('inTransaction')->andReturn(false)->byDefault();
        $db->shouldReceive('beginTransaction')->byDefault();
        $db->shouldReceive('commit')->byDefault();
        $db->shouldReceive('rollback')->byDefault();
        $db->shouldReceive('query')->andReturn(m::mock(\PDOStatement::class))->byDefault();
        return $db;
    }

    // ─────────────────────────────────────────────────────────────
    // payRevenue + گیت وضعیت محتوا (MOD24-02)
    // ─────────────────────────────────────────────────────────────

    public function test_payRevenue_blocks_when_submission_is_suspended(): void
    {
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('findForUpdate')->once()->with(55)->andReturn($this->revenueRow(['status' => ContentRevenue::STATUS_APPROVED]));

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow(['status' => ContentSubmission::STATUS_SUSPENDED]));

        $wallet = m::mock(WalletServiceInterface::class);
        $wallet->shouldReceive('deposit')->never(); // هیچ پولی نباید واریز شود

        $db = $this->dbMock();
        $db->shouldReceive('rollback')->once();

        $service = $this->buildService($revenue, $submission, $db, $wallet);

        try {
            $service->payRevenue(55, 1);
            $this->fail('پرداخت درآمد محتوای تعلیق‌شده باید BusinessException بدهد');
        } catch (\Core\Exceptions\BusinessException $e) {
            $this->assertStringContainsString('وضعیت محتوا', $e->getMessage());
        }
    }

    public function test_payRevenue_blocks_when_submission_is_rejected(): void
    {
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('findForUpdate')->once()->andReturn($this->revenueRow(['status' => ContentRevenue::STATUS_APPROVED]));

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow(['status' => ContentSubmission::STATUS_REJECTED]));

        $wallet = m::mock(WalletServiceInterface::class);
        $wallet->shouldReceive('deposit')->never();

        $db = $this->dbMock();
        $db->shouldReceive('rollback')->once();

        $service = $this->buildService($revenue, $submission, $db, $wallet);

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $service->payRevenue(55, 1);
    }

    public function test_payRevenue_blocks_when_submission_missing(): void
    {
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('findForUpdate')->once()->andReturn($this->revenueRow());

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn(null);

        $wallet = m::mock(WalletServiceInterface::class);
        $wallet->shouldReceive('deposit')->never();

        $db = $this->dbMock();
        $db->shouldReceive('rollback')->once();

        $service = $this->buildService($revenue, $submission, $db, $wallet);

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $service->payRevenue(55, 1);
    }

    public function test_payRevenue_succeeds_for_published_submission_and_records_paid(): void
    {
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('findForUpdate')->once()->andReturn($this->revenueRow(['status' => ContentRevenue::STATUS_APPROVED]));

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow(['status' => ContentSubmission::STATUS_PUBLISHED]));

        $wallet = m::mock(WalletServiceInterface::class);
        $wallet->shouldReceive('deposit')->once()->with(5, '900.00000000', 'irt', m::any())->andReturn(['success' => true, 'transaction_id' => 'tx-1']);

        // MOD24-20: update باید با STATUS_PAID صدا شود و نتیجه‌اش true باشد
        $revenue->shouldReceive('update')->once()->with(55, m::on(static function (array $data): bool {
            return ($data['status'] ?? '') === ContentRevenue::STATUS_PAID
                && ($data['transaction_id'] ?? null) === 'tx-1'
                && ($data['paid_by_admin'] ?? null) === 1;
        }))->andReturn(true);

        $db = $this->dbMock();
        $db->shouldReceive('beginTransaction')->once();
        $db->shouldReceive('commit')->once();

        $service = $this->buildService($revenue, $submission, $db, $wallet);
        $result = $service->payRevenue(55, 1);

        $this->assertTrue($result['success']);
    }

    public function test_payRevenue_rolls_back_when_status_update_fails(): void
    {
        // MOD24-20: deposit موفق اما UPDATE صفر ردیف ⇒ rollback کامل (نه پولِ واریزشده با رکوردِ approved)
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('findForUpdate')->once()->andReturn($this->revenueRow(['status' => ContentRevenue::STATUS_APPROVED]));

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow());

        $wallet = m::mock(WalletServiceInterface::class);
        $wallet->shouldReceive('deposit')->once()->andReturn(['success' => true, 'transaction_id' => 'tx-2']);

        $revenue->shouldReceive('update')->once()->andReturn(false);

        $db = $this->dbMock();
        $db->shouldReceive('rollback')->once();

        $service = $this->buildService($revenue, $submission, $db, $wallet);

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('پرداخت‌شده');
        $service->payRevenue(55, 1);
    }

    // ─────────────────────────────────────────────────────────────
    // approveRevenue (MOD24-02 + MOD24-03)
    // ─────────────────────────────────────────────────────────────

    public function test_approveRevenue_blocks_when_submission_suspended(): void
    {
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('find')->once()->with(55)->andReturn($this->revenueRow(['status' => ContentRevenue::STATUS_PENDING]));

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow(['status' => ContentSubmission::STATUS_SUSPENDED]));

        $service = $this->buildService($revenue, $submission, $this->dbMock());

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('وضعیت محتوا');
        $service->approveRevenue(55, 1);
    }

    public function test_approveRevenue_claims_pending_atomically_via_cas(): void
    {
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('find')->once()->andReturn($this->revenueRow(['status' => ContentRevenue::STATUS_PENDING]));

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow(['status' => ContentSubmission::STATUS_PUBLISHED]));

        // MOD24-03: UPDATE ... WHERE id=55 AND status='pending' با بررسی rowCount
        $db = $this->dbMock();
        $builder = m::mock(\Core\QueryBuilder::class);
        $db->shouldReceive('table')->once()->with('content_revenues')->andReturn($builder);
        $builder->shouldReceive('where')->once()->with('id', 55)->andReturnSelf();
        $builder->shouldReceive('where')->once()->with('status', ContentRevenue::STATUS_PENDING)->andReturnSelf();
        $builder->shouldReceive('update')->once()->with(m::on(static function (array $data): bool {
            return ($data['status'] ?? '') === ContentRevenue::STATUS_APPROVED && isset($data['reviewed_by'], $data['reviewed_at']);
        }))->andReturn(1);

        $service = $this->buildService($revenue, $submission, $db);
        $result = $service->approveRevenue(55, 1);

        $this->assertTrue($result['success']);
        $this->assertSame('درآمد تأیید شد.', $result['message']);
    }

    public function test_approveRevenue_fails_loud_when_cas_loses_race(): void
    {
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('find')->once()->andReturn($this->revenueRow(['status' => ContentRevenue::STATUS_PENDING]));

        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow());

        $db = $this->dbMock();
        $builder = m::mock(\Core\QueryBuilder::class);
        $db->shouldReceive('table')->once()->with('content_revenues')->andReturn($builder);
        $builder->shouldReceive('where')->twice()->andReturnSelf();
        $builder->shouldReceive('update')->once()->andReturn(0); // رقابت: رکورد دیگر pending نیست

        $service = $this->buildService($revenue, $submission, $db);

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('تغییر کرد');
        $service->approveRevenue(55, 1);
    }

    public function test_approveRevenue_rejects_non_pending_record(): void
    {
        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('find')->once()->andReturn($this->revenueRow(['status' => ContentRevenue::STATUS_PAID]));

        $service = $this->buildService($revenue, m::mock(ContentSubmission::class), $this->dbMock());

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('در انتظار');
        $service->approveRevenue(55, 1);
    }

    // ─────────────────────────────────────────────────────────────
    // suspendSubmission + لغو درآمدهای باز (MOD24-02/13)
    // ─────────────────────────────────────────────────────────────

    public function test_suspendSubmission_cancels_open_revenues_inside_transaction(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->with(10)->andReturn($this->submissionRow(['status' => ContentSubmission::STATUS_PUBLISHED]));

        $revenue = m::mock(ContentRevenue::class);

        $db = $this->dbMock();
        $lockStmt = m::mock(\PDOStatement::class);
        $lockStmt->shouldReceive('fetch')->once()->andReturn((object)['id' => 10, 'status' => ContentSubmission::STATUS_PUBLISHED]);
        $db->shouldReceive('query')->once()->with(
            'SELECT id, status FROM content_submissions WHERE id = ? FOR UPDATE',
            [10]
        )->andReturn($lockStmt);

        $submission->shouldReceive('update')->once()->with(10, m::on(static function (array $data): bool {
            return ($data['status'] ?? '') === ContentSubmission::STATUS_SUSPENDED
                && isset($data['suspended_by'], $data['suspended_at']);
        }))->andReturn(true);

        // MOD24-02/13: درآمدهای باز لغو می‌شوند — این تنها مسیر نوشتن cancelled است
        $revenue->shouldReceive('cancelOpenBySubmission')->once()->with(
            10,
            1,
            m::on(static fn (string $r): bool => str_contains($r, 'تعلیق محتوا'))
        )->andReturn(2);

        $service = $this->buildService($revenue, $submission, $db, null, null, null);
        $result = $service->suspendSubmission(10, 1, 'محتوای کپی از کانال دیگر');

        $this->assertTrue($result['success']);
    }

    public function test_suspendSubmission_fails_when_status_update_fails(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow(['status' => ContentSubmission::STATUS_PUBLISHED]));
        $submission->shouldReceive('update')->once()->andReturn(false); // شکست UPDATE

        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('cancelOpenBySubmission')->never();

        $db = $this->dbMock();
        $lockStmt = m::mock(\PDOStatement::class);
        $lockStmt->shouldReceive('fetch')->once()->andReturn((object)['id' => 10, 'status' => ContentSubmission::STATUS_PUBLISHED]);
        $db->shouldReceive('query')->once()->andReturn($lockStmt);

        $service = $this->buildService($revenue, $submission, $db);

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $this->expectExceptionMessage('ناموفق');
        $service->suspendSubmission(10, 1, 'دلیل تست با طول کافی');
    }

    public function test_suspendSubmission_rechecks_status_under_lock(): void
    {
        // قفل گرفته شده اما وضعیت هم‌زمان تغییر کرده (مثلاً reject شده) ⇒ تعلیق رد می‌شود
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->once()->andReturn($this->submissionRow(['status' => ContentSubmission::STATUS_PUBLISHED]));

        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('cancelOpenBySubmission')->never();

        $db = $this->dbMock();
        $lockStmt = m::mock(\PDOStatement::class);
        $lockStmt->shouldReceive('fetch')->once()->andReturn((object)['id' => 10, 'status' => ContentSubmission::STATUS_REJECTED]);
        $db->shouldReceive('query')->once()->andReturn($lockStmt);

        $submission->shouldReceive('update')->never();

        $service = $this->buildService($revenue, $submission, $db);

        $this->expectException(\Core\Exceptions\BusinessException::class);
        $service->suspendSubmission(10, 1, 'دلیل تست با طول کافی');
    }
}
