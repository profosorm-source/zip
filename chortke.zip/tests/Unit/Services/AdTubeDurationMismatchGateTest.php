<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Services\Ads\AdsBudgetSettlementService;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-YT-7 + FIX-R1-1 — نمونه‌های تستی بستهٔ YT7 (فایل ۲ از ۲):
 * دروازهٔ mismatch مدت پلیر واقعی (IFrame API) در برابر مدت اعلانی ویدیو.
 *
 * سناریوی کامل تسویه (settleAdTubeView) DB واقعی می‌خواهد؛ این فایل دو لایهٔ
 * قابل‌پینِ مستقل را قفل می‌کند:
 *   ۱) ریاضیات دروازه: diffPct بر «declared_duration خام» حساب می‌شود (نه
 *      مقدار floored) — وگرنه تماشای صادقانهٔ ویدیوهای کوتاه‌تر از کف سراسری
 *      به‌اشتباه mismatch می‌خورد (FIX-R1-1).
 *   ₂) سیم‌کشی: مسیر settle واقعاً این دروازه را با playerDurationSeconds>0
 *      اجرا و رد می‌کند (پین سورس).
 */
final class AdTubeDurationMismatchGateTest extends TestCase
{
    /**
     * همان فرمول settleAdTubeView (FIX-YT-7 بخش ۲ + FIX-R1-1) — اینجا صریح
     * بازتولید می‌شود تا هم‌خوانی policy و دروازه برای همیشه پین بماند.
     */
    private static function gateVerdict(int $playerDurationSeconds, int $declaredDuration, float $mismatchPct): bool
    {
        if ($playerDurationSeconds <= 0) {
            return true; // پلیر مدت نداد → دروازه بی‌اثر
        }
        $declared = max(1, $declaredDuration);
        $diffPct = abs($playerDurationSeconds - $declared) / $declared * 100.0;
        return $diffPct <= $mismatchPct; // true = عبور
    }

    public function test_short_video_watch_is_not_falsely_mismatched(): void
    {
        // ویدیوی واقعی ۱۰ثانیه‌ای (زیر کف سراسری ۳۰): پلیر ۱۰ می‌گوید.
        // اگر مقایسه با مقدار floored (۳۰) بود: diff=66% → رد ناعادلانه.
        // با declared خام (۱۰): diff=0% → عبور.
        $this->assertTrue(self::gateVerdict(10, 10, 10.0), 'پلیرِ هم‌قیمتِ مدت اعلانی خام باید عبور کند');
    }

    public function test_swapped_video_is_rejected(): void
    {
        // جای ویدیوی ۶۰ثانیه‌ای، ویدیوی ۱۵ثانیه‌ای پخش شده (کمپین جاسوازی/سوئیچ):
        // diff = |15-60|/60 = 75% > 10% → رد
        $this->assertFalse(self::gateVerdict(15, 60, 10.0), 'پلیرِ به‌مراتب کوتاه‌تر از اعلانی = سوئیچ ویدیو → رد');
    }

    public function test_inflated_player_duration_is_rejected(): void
    {
        // پلیر 90 در برابر اعلانی 60: diff=50% > 10% → رد (جهت مخالف هم بسته است)
        $this->assertFalse(self::gateVerdict(90, 60, 10.0));
    }

    public function test_small_network_drift_within_threshold_passes(): void
    {
        // اعلانی 60، پلیر 63 → diff=5% ≤ 10% → عبور (لاتنسی/ preroll عادی)
        $this->assertTrue(self::gateVerdict(63, 60, 10.0));
        // مرز دقیق: پلیر 66 → diff=10% → عبور (شرط > برای رد است)
        $this->assertTrue(self::gateVerdict(66, 60, 10.0));
        // یک ثانیه بیش مرز: 67 → diff≈11.7% → رد
        $this->assertFalse(self::gateVerdict(67, 60, 10.0));
    }

    public function test_missing_player_duration_leaves_gate_inert(): void
    {
        // کلاینت قدیمی بدون IFrame API (playerDuration=0) → دروازه صرفاً بی‌اثر؛
        // سنجش اصلی (computeAdTubeMetrics) همچنان مستقل کار می‌کند
        $this->assertTrue(self::gateVerdict(0, 60, 10.0));
    }

    public function test_metrics_with_per_video_required_duration_short_video(): void
    {
        // ترکیب FIX-YT-7 با موتور سنجش: ویدیوی ۱۰ثانیه‌ای زیر کف سراسری →
        // required = 30 (floor)؛ تماشای ۱�ثانیه‌ای صادقانه هنوز 100% نیست
        // و ادعای 30s در 12s با 1x = fraud (سقف فیزیکی 12).
        $m = AdsBudgetSettlementService::computeAdTubeMetrics(1000, 1012, 30, 1.0, 30);
        $this->assertSame(12, $m['elapsed_seconds']);
        $this->assertTrue($m['fraud'], 'ادعای 30s تماشا در 12s فیزیکی = fraud');
        $this->assertSame(40, $m['progress_percent'], 'پیشرفت از زمان سرور: 12s×1x / 30 = 40% (هنوز 100% نیست)');
    }

    public function test_settle_path_wires_the_gate_against_declared_duration(): void
    {
        // پین سورس — مسیر واقعی تسویه باید:
        $src = (string)file_get_contents(dirname(__DIR__, 3) . '/app/Services/Ads/AdsBudgetSettlementService.php');

        // ۱) دروازه فقط وقتی فعال شود که پلیر مدت داده (playerDurationSeconds > 0)
        $this->assertStringContainsString('if ($playerDurationSeconds > 0) {', $src, 'دروازه mismatch فقط با مدت پلیر واقعی فعال شود');
        // ۲) مبنای مقایسه declared_duration خام باشد نه مقدار floored
        $this->assertStringContainsString("\$declared = max(1, (int)(\$adPolicy['declared_duration'] ?? 0));", $src, 'مقایسه بر declared_duration خام (FIX-R1-1)');
        // ۳) درصد آستانه از تنظیمات با کلمپ
        $this->assertStringContainsString('adtubeDurationMismatchPercent()', $src);
        // ۴) ردِ mismatch باید ردیف را rejected کند (نه فقط پیام)
        $this->assertStringContainsString("'mismatch مدت ویدیو: پلیر '", $src, 'دلیل رد باید در reject_reason ثبت شود');
    }
}
