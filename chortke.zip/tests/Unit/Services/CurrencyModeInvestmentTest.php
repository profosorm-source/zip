<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Jobs\Investment\ApplyProfitLossToBatchJob;
use App\Jobs\Investment\ApplyWeeklyProfitLossJob;
use App\Jobs\Investment\CloseTradeJob;
use App\Jobs\Investment\CreateTradeJob;
use App\Jobs\Investment\RejectWithdrawalJob;
use App\Jobs\Investment\RequestWithdrawalJob;
use App\Models\Investment;
use App\Models\InvestmentWithdrawal;
use App\Services\Investment\InvestmentCommandService;
use App\Services\Investment\InvestmentQueryService;
use Core\Database;
use Core\ValueObjects\Money;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * FIX-R7 (تصمیم محصول — currency mode سرتاسری، دیفالت تومان):
 * پین رفتار دو-ارزی شدن بخش سرمایه‌گذاری.
 *
 * قراردادها:
 *  - ارز سرمایه‌گذاری جدید از currency_mode می‌آید (irt پیش‌فرض).
 *  - سقف‌ها per-currency هستند (investment_min_amount_irt/usdt + legacy fallback برای usdt).
 *  - تسویه‌های رکورد (سود/ضرر، برداشت سود، زیان دستی، دفتر حسابداری) با ارز خودِ رکورد.
 *  - توانگری per-currency محاسبه می‌شود؛ بدترین سبد تعیین‌کنندهٔ وضعیت کلی.
 */
final class CurrencyModeInvestmentTest extends TestCase
{
    /** @var array<string, mixed> */
    private array $capturedSql = [];

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    // ─── helpers ─────────────────────────────────────────────────────────

    /** @return array{0: InvestmentCommandService, 1: m\MockInterface, 2: m\MockInterface, 3: m\MockInterface, 4: m\MockInterface} */
    private function commandService(
        m\MockInterface $appSettings,
        m\MockInterface $walletService,
        ?m\MockInterface $investmentModel = null
    ): array {
        $db = m::mock(Database::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $invModel = $investmentModel ?? m::mock(Investment::class);
        $wdModel = m::mock(InvestmentWithdrawal::class);
        $saga = m::mock(\App\Services\SagaOrchestrator::class);

        $svc = new InvestmentCommandService(
            $db,
            $logger,
            $appSettings,
            $invModel,
            $wdModel,
            $walletService,
            $saga,
            null,
            m::mock(CreateTradeJob::class),
            m::mock(CloseTradeJob::class),
            m::mock(ApplyWeeklyProfitLossJob::class),
            m::mock(ApplyProfitLossToBatchJob::class),
            m::mock(RequestWithdrawalJob::class),
            m::mock(RejectWithdrawalJob::class)
        );
        return [$svc, $db, $invModel, $wdModel, $logger];
    }

    /** تنظیم‌های Mock برای getSettings در حالت irt با کلید‌های per-currency غایب → پیش‌فرض‌ها */
    private function expectIrtSettings(m\MockInterface $appSettings): void
    {
        $appSettings->shouldReceive('get')->with('currency_mode', 'irt')->andReturn('irt');
        $appSettings->shouldReceive('get')->with('investment_min_amount_irt', null)->andReturn(null);
        $appSettings->shouldReceive('get')->with('investment_max_amount_irt', null)->andReturn(null);
        $appSettings->shouldReceive('get')->with('investment_site_fee_percent', '10')->andReturn('10');
        $appSettings->shouldReceive('get')->with('investment_tax_percent', '9')->andReturn('9');
    }

    // ─── ① ارز سرمایه‌گذاری جدید از currency_mode ────────────────────────

    public function test_create_investment_irt_mode_min_error_uses_toman_label_and_irt_bounds(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $this->expectIrtSettings($appSettings);
        [$svc] = $this->commandService($appSettings, m::mock(\App\Contracts\WalletServiceInterface::class));

        // 100,000 تومان < حداقل پیش‌فرض irt (500,000)
        $result = $svc->createInvestment(7, ['amount' => '100000', 'risk_accepted' => 1]);

        $this->assertFalse((bool)$result['success']);
        $this->assertSame('BELOW_MIN_AMOUNT', $result['error_code']);
        $this->assertSame('500000', (string)$result['min_amount']);
        // FIX-R7: پیام با برچسب تومان — نه USDT
        $this->assertSame('حداقل مبلغ سرمایه‌گذاری 500000 تومان است.', $result['message']);
    }

    public function test_create_investment_irt_mode_insufficient_balance_error_code_and_label(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $this->expectIrtSettings($appSettings);
        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);
        $wallet->shouldReceive('isWalletFrozen')->with(7)->andReturn(false);
        // کیفِ irt خوانده می‌شود — نه usdt
        $wallet->shouldReceive('getBalance')->once()->with(7, 'irt')->andReturn('100');
        [$svc] = $this->commandService($appSettings, $wallet);

        $result = $svc->createInvestment(7, ['amount' => '600000', 'risk_accepted' => 1]);

        $this->assertFalse((bool)$result['success']);
        $this->assertSame('INSUFFICIENT_IRT_BALANCE', $result['error_code']);
        $this->assertStringContainsString('تومان', (string)$result['message']);
        $this->assertStringNotContainsString('USDT', (string)$result['message']);
    }

    public function test_create_investment_usdt_mode_keeps_usdt_contract_with_legacy_fallback(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $appSettings->shouldReceive('get')->with('currency_mode', 'irt')->andReturn('usdt');
        $appSettings->shouldReceive('get')->with('investment_min_amount_usdt', null)->andReturn(null);
        $appSettings->shouldReceive('get')->with('investment_max_amount_usdt', null)->andReturn(null);
        // کلید legacy (USDT-مقیاس) به‌عنوان fallback — نصب‌های موجود حفظ می‌شوند
        $appSettings->shouldReceive('get')->with('investment_min_amount', '10')->andReturn('20');
        $appSettings->shouldReceive('get')->with('investment_max_amount', '10000')->andReturn('10000');
        $appSettings->shouldReceive('get')->with('investment_site_fee_percent', '10')->andReturn('10');
        $appSettings->shouldReceive('get')->with('investment_tax_percent', '9')->andReturn('9');

        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);
        [$svc] = $this->commandService($appSettings, $wallet);

        $result = $svc->createInvestment(7, ['amount' => '15', 'risk_accepted' => 1]);

        $this->assertFalse((bool)$result['success']);
        $this->assertSame('BELOW_MIN_AMOUNT', $result['error_code']);
        $this->assertSame('20', (string)$result['min_amount']);
        $this->assertSame('حداقل مبلغ سرمایه‌گذاری 20 تتر است.', $result['message']);
    }

    // ─── ② getSettings per-currency ──────────────────────────────────────

    public function test_command_get_settings_irt_defaults(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $this->expectIrtSettings($appSettings);
        [$svc] = $this->commandService($appSettings, m::mock(\App\Contracts\WalletServiceInterface::class));

        $settings = $svc->getSettings();

        $this->assertSame('500000', $settings['min_amount']);
        $this->assertSame('500000000', $settings['max_amount']);
        $this->assertSame('irt', $settings['currency']);
    }

    public function test_command_get_settings_usdt_prefers_new_key_over_legacy(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $appSettings->shouldReceive('get')->with('currency_mode', 'irt')->andReturn('usdt');
        $appSettings->shouldReceive('get')->with('investment_min_amount_usdt', null)->andReturn('15');
        $appSettings->shouldReceive('get')->with('investment_max_amount_usdt', null)->andReturn('20000');
        $appSettings->shouldReceive('get')->with('investment_site_fee_percent', '10')->andReturn('10');
        $appSettings->shouldReceive('get')->with('investment_tax_percent', '9')->andReturn('9');
        // legacy نباید خوانده شود — بدون expectation؛ فراخوانی ⇒ شکست تست

        [$svc] = $this->commandService($appSettings, m::mock(\App\Contracts\WalletServiceInterface::class));

        $settings = $svc->getSettings();
        $this->assertSame('15', $settings['min_amount']);
        $this->assertSame('20000', $settings['max_amount']);
        $this->assertSame('usdt', $settings['currency']);
    }

    public function test_query_get_settings_usdt_legacy_fallback_floats(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $appSettings->shouldReceive('get')->with('currency_mode', 'irt')->andReturn('usdt');
        $appSettings->shouldReceive('get')->with('investment_min_amount_usdt', null)->andReturn(null);
        $appSettings->shouldReceive('get')->with('investment_max_amount_usdt', null)->andReturn(null);
        $appSettings->shouldReceive('get')->with('investment_min_amount', '10.0')->andReturn('25');
        $appSettings->shouldReceive('get')->with('investment_max_amount', '10000.0')->andReturn('50000');
        $appSettings->shouldReceive('get')->with('investment_site_fee_percent', 10)->andReturn('10');
        $appSettings->shouldReceive('get')->with('investment_tax_percent', 9)->andReturn('9');

        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $invModel = m::mock(Investment::class);
        $query = new InvestmentQueryService($logger, $appSettings, $invModel, null);

        $settings = $query->getSettings();
        $this->assertSame(25.0, $settings['min_amount']);
        $this->assertSame(50000.0, $settings['max_amount']);
        $this->assertSame('usdt', $settings['currency']);
    }

    // ─── ③ مدل: ستون currency در whitelist + پیش‌فرض ارز فعال ────────────

    public function test_investment_model_create_default_currency_is_active_currency(): void
    {
        $db = m::mock(Database::class);
        $captured = [];
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->andReturnUsing(function (array $values) use (&$captured): bool {
            $captured = $values;
            return true;
        });
        $db->shouldReceive('prepare')->once()->andReturnUsing(function (string $sql) use ($stmt, &$capturedSql) {
            $this->capturedSql[] = $sql;
            return $stmt;
        });
        $db->shouldReceive('lastInsertId')->andReturn('9');

        $model = new Investment($db);
        $id = $model->create(['user_id' => 7, 'amount' => '100']);

        $this->assertSame(9, $id);
        $this->assertStringContainsString('`currency`', $this->capturedSql[0]);
        // در محیط تست currency_mode غایب است → ارز فعال پیش‌فرض = irt
        $this->assertContains(currency_active(), $captured, 'create() باید ارز فعال را در INSERT بیاورد');
    }

    public function test_investment_model_create_invalid_currency_normalizes_to_usdt(): void
    {
        $db = m::mock(Database::class);
        $captured = [];
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('execute')->once()->andReturnUsing(function (array $values) use (&$captured): bool {
            $captured = $values;
            return true;
        });
        $db->shouldReceive('prepare')->once()->andReturn($stmt);
        $db->shouldReceive('lastInsertId')->andReturn('10');

        $model = new Investment($db);
        $model->create(['user_id' => 7, 'amount' => '100', 'currency' => 'EUR']);

        $this->assertContains('usdt', $captured, 'ارز نامعتبر → usdt (رفتار legacy)');
    }

    // ─── ④ برداشت سود با ارز خودِ رکورد ────────────────────────────────

    public function test_withdraw_profit_deposits_investment_own_currency(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);
        $invModel = m::mock(Investment::class);

        [$svc, $db] = $this->commandService($appSettings, $wallet, $invModel);

        $inv = (object)[
            'id' => 5,
            'user_id' => 7,
            'status' => 'active',
            'profit_earned' => '50',
            'last_profit_date' => '2026-10-01 10:00:00',
            'currency' => 'irt',
        ];
        $invModel->shouldReceive('findForUpdate')->with(5)->andReturn($inv);
        $db->shouldReceive('transactional')->once()->andReturnUsing(fn (callable $cb) => $cb());

        // واریز سود باید با ارز رکورد (irt) باشد — نه usdt
        $wallet->shouldReceive('deposit')->once()->with(7, '50', 'irt', m::on(fn ($meta) => true))
            ->andReturn(['success' => true, 'transaction_id' => 'TX-IRT-1']);
        $db->shouldReceive('query')->once()->andReturn(m::mock(\PDOStatement::class));

        $result = $svc->withdrawProfit(5, 7);

        $this->assertTrue((bool)$result['success']);
        $this->assertSame('50', (string)$result['amount']);
    }

    // ─── ⑤ زیان دستی: ردیف دفتر با ارز رکورد ────────────────────────────

    public function test_apply_loss_records_profit_row_in_investment_currency(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $wallet = m::mock(\App\Contracts\WalletServiceInterface::class);
        $invModel = m::mock(Investment::class);
        [$svc, $db, , , $logger] = $this->commandService($appSettings, $wallet, $invModel);

        $inv = (object)[
            'id' => 5, 'user_id' => 7, 'status' => 'active',
            'current_balance' => '1000', 'currency' => 'irt',
        ];
        $invModel->shouldReceive('findForUpdate')->with(5)->andReturn($inv);
        $db->shouldReceive('transactional')->once()->andReturnUsing(fn (callable $cb) => $cb());

        $updateStmt = m::mock(\PDOStatement::class);
        $updateStmt->shouldReceive('execute')->once()->andReturn(true);
        $updateStmt->shouldReceive('rowCount')->andReturn(1);
        $db->shouldReceive('prepare')->once()->andReturn($updateStmt);

        $insertParams = null;
        $db->shouldReceive('query')->once()->andReturnUsing(function (string $sql, array $params = []) use (&$insertParams) {
            $this->capturedSql[] = $sql;
            $insertParams = $params;
            return m::mock(\PDOStatement::class);
        });
        $logger->shouldReceive('info')->once();

        $this->assertTrue($svc->applyLoss(5, '100', '1'));
        // پارامتر سوم INSERT = ارز رکورد (irt) — قبلاً ثابت 'usdt' بود
        $this->assertSame('irt', $insertParams[2] ?? null, 'ردیف دفتر زیان باید با ارز سرمایه‌گذاری ثبت شود');
    }

    // ─── ⑥ توانگری per-currency ────────────────────────────────────────

    public function test_solvency_report_is_per_currency_and_worst_bucket_wins(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $invModel = m::mock(Investment::class);
        $auditTrail = m::mock(\App\Services\AuditTrail::class);

        $invModel->shouldReceive('getSolvencyBuckets')->once()->andReturn([
            'usdt' => ['active_balance' => '100', 'initial_invested' => '100'],
            'irt'  => ['active_balance' => '1000000', 'initial_invested' => '800000'],
        ]);
        $invModel->shouldReceive('getTotalTradingProfitLoss')->once()->andReturn('0');

        // سبد irt نسبت 0.8 دارد → زیر 90٪ → هشدار critical + audit
        $logger->shouldReceive('critical')->once()->with(m::on(fn ($msg) => str_contains((string)$msg, 'Solvency alert')));
        $auditTrail->shouldReceive('record')->once()->with('system.solvency_alert', 0, m::on(function ($ctx) {
            return ($ctx['currency'] ?? '') === 'irt';
        }));

        $query = new InvestmentQueryService($logger, $appSettings, $invModel, $auditTrail);
        $report = $query->getSolvencyReport();

        // بدترین سبد (irt) اعداد کلی را تعیین می‌کند
        $this->assertSame('irt', $report['currency']);
        $this->assertSame('insolvent', $report['status']);
        $this->assertEqualsWithDelta(0.8, (float)$report['ratio'], 0.0001);
        $this->assertSame(0, bccomp((string)$report['shortfall'], '200000', 2), 'کسری سبد irt = 200,000 تومان');
        // جزئیات هر دو سبد
        $this->assertArrayHasKey('usdt', $report['per_currency']);
        $this->assertArrayHasKey('irt', $report['per_currency']);
        $this->assertSame('solvent', $report['per_currency']['usdt']['status']);
        $this->assertSame('insolvent', $report['per_currency']['irt']['status']);
    }

    public function test_solvency_report_single_currency_keeps_legacy_shape(): void
    {
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $invModel = m::mock(Investment::class);

        $invModel->shouldReceive('getSolvencyBuckets')->once()->andReturn([
            'usdt' => ['active_balance' => '500', 'initial_invested' => '500'],
        ]);
        $invModel->shouldReceive('getTotalTradingProfitLoss')->once()->andReturn('50');

        $query = new InvestmentQueryService($logger, $appSettings, $invModel, null);
        $report = $query->getSolvencyReport();

        // دارایی = 500 + 50 = 550 / 500 = 1.1
        $this->assertSame('usdt', $report['currency']);
        $this->assertSame('solvent', $report['status']);
        $this->assertEqualsWithDelta(1.1, (float)$report['ratio'], 0.0001);
    }

    // ─── ⑦ جمع‌های per-currency مدل ─────────────────────────────────────

    public function test_model_totals_filter_by_currency(): void
    {
        $db = m::mock(Database::class);
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('fetchColumn')->twice()->andReturn('42');
        $db->shouldReceive('query')->twice()->andReturnUsing(function (string $sql, array $params = []) use ($stmt) {
            $this->assertStringContainsString('AND currency = ?', $sql);
            $this->assertSame(['usdt'], $params);
            return $stmt;
        });

        $model = new Investment($db);
        $this->assertSame('42', $model->getTotalActiveBalance('usdt'));
        $this->assertSame('42', $model->getTotalInitialInvested('usdt'));
    }

    public function test_model_solvency_buckets_groups_by_currency(): void
    {
        $db = m::mock(Database::class);
        $stmt = m::mock(\PDOStatement::class);
        $stmt->shouldReceive('fetchAll')->once()->andReturn([
            ['currency' => 'usdt', 'active_balance' => '100', 'initial_invested' => '90'],
            ['currency' => 'irt', 'active_balance' => '9000', 'initial_invested' => '8000'],
        ]);
        $db->shouldReceive('query')->once()->andReturnUsing(function (string $sql) use ($stmt) {
            $this->assertStringContainsString('GROUP BY currency', $sql);
            return $stmt;
        });

        $model = new Investment($db);
        $buckets = $model->getSolvencyBuckets();

        $this->assertSame('100', $buckets['usdt']['active_balance']);
        $this->assertSame('8000', $buckets['irt']['initial_invested']);
    }

    // ─── ⑧ جاب تسویه: ارز per-record در دفتر و رویداد ───────────────────

    public function test_batch_job_settles_each_investment_in_its_own_currency(): void
    {
        $db = m::mock(Database::class);
        $invModel = m::mock(Investment::class);
        $appSettings = m::mock(\App\Services\Settings\AppSettings::class);
        $profitModel = m::mock(\App\Models\InvestmentProfit::class);
        $stateMachine = m::mock(\App\Services\StateMachineService::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $transactionModel = m::mock(\App\Models\Transaction::class);
        $ledger = m::mock(\App\Domain\Financial\Services\LedgerService::class);

        $invUsdt = (object)['id' => 1, 'user_id' => 11, 'status' => 'active', 'current_balance' => '100', 'amount' => '100', 'currency' => 'usdt'];
        $invIrt  = (object)['id' => 2, 'user_id' => 12, 'status' => 'active', 'current_balance' => '1000000', 'amount' => '1000000', 'currency' => 'irt'];

        $db->shouldReceive('beginTransaction')->once();
        $db->shouldReceive('commit')->once();

        // trade lookup
        $db->shouldReceive('fetch')->once()->andReturn((object)['id' => 77, 'status' => 'closed']);
        // idempotency probes (initial + after-lock)
        $emptyStmt = m::mock(\PDOStatement::class);
        $emptyStmt->shouldReceive('execute')->twice();
        $emptyStmt->shouldReceive('fetchAll')->twice()->andReturn([]);
        $db->shouldReceive('prepare')->twice()->andReturn($emptyStmt);

        $invModel->shouldReceive('findInIdsForUpdate')->once()->andReturn([$invUsdt, $invIrt]);

        $appSettings->shouldReceive('get')->with('investment_site_fee_percent', '10')->andReturn('10');
        $appSettings->shouldReceive('get')->with('investment_tax_percent', '9')->andReturn('9');

        // سود ۱۰٪ — هر دو سرمایه‌گذاری سود می‌گیرند؛ سه انتقال حسابداری در هر کدام
        $createdCurrencies = [];
        $transactionModel->shouldReceive('createTransaction')->times(6)->andReturnUsing(
            function (array $data) use (&$createdCurrencies) {
                $createdCurrencies[] = $data['currency'];
                return (object)['transaction_id' => 'TX-' . count($createdCurrencies)];
            }
        );
        $ledger->shouldReceive('recordDoubleEntry')->times(6)->andReturnUsing(
            function (string $txId, string $d, string $c, string $amount, string $currency) use (&$createdCurrencies): bool {
                // ارز دفتر کل هم باید هم‌ارز رکورد باشد
                $this->assertContains($currency, ['usdt', 'irt']);
                return true;
            }
        );

        $profitCurrencies = [];
        $profitModel->shouldReceive('create')->twice()->andReturnUsing(
            function (array $data) use (&$profitCurrencies) {
                $profitCurrencies[$data['investment_id']] = $data['currency'];
                return count($profitCurrencies);
            }
        );

        $invModel->shouldReceive('update')->twice()->andReturn(true);
        // سود مثبت ⇒ مانده صفر نمی‌شود ⇒ canTransition هرگز صدا نمی‌شود

        // CurrencyService واقعی با AppSettings ماک‌شده — formatAmount هم‌ارز رکورد
        $currencySvc = new \App\Services\CurrencyService($appSettings, m::mock(\Core\Request::class));

        $job = new ApplyProfitLossToBatchJob(
            $db, $invModel, $appSettings, $profitModel, $stateMachine,
            $logger, $transactionModel, $ledger, null, $currencySvc, null
        );

        $result = $job->handle([1, 2], 77, '10', '2026-W44', 99);

        $this->assertTrue((bool)$result['success']);
        $this->assertSame(2, $result['processed']);
        $this->assertSame('usdt', $profitCurrencies[1]);
        $this->assertSame('irt', $profitCurrencies[2]);
        // ۳ انتقال حسابداری usdt (inv#1) + ۳ انتقال irt (inv#2)
        $this->assertSame(['usdt', 'usdt', 'usdt', 'irt', 'irt', 'irt'], $createdCurrencies);
    }

    // ─── ⑨ listener اعلان سود: فرمت با ارز رویداد ───────────────────────

    public function test_profit_applied_listener_formats_with_event_currency(): void
    {
        $container = m::mock(\Core\Container::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $listener = new \App\Listeners\InvestmentEventListeners($container, $logger);

        $currencySvc = m::mock(\App\Services\CurrencyService::class);
        $currencySvc->shouldReceive('formatAmount')->twice()->andReturnUsing(
            function ($amount, ?string $currency = null): string {
                // ارز payload باید پاس داده شود — نه usdt ثابت
                $this->assertSame('irt', $currency);
                return $amount . ' تومان';
            }
        );
        $container->shouldReceive('make')->with('App\Services\CurrencyService')->andReturn($currencySvc);

        $notifier = m::mock(\App\Contracts\NotificationServiceInterface::class);
        $notifier->shouldReceive('send')->once()->with(
            7, 'investment_update', m::any(), m::on(fn ($msg) => str_contains((string)$msg, 'تومان'))
        );
        $container->shouldReceive('make')->with('App\Contracts\NotificationServiceInterface')->andReturn($notifier);
        $container->shouldReceive('make')->with('App\Services\Cache\CacheInvalidationService')->andReturn(
            m::mock(\App\Services\Cache\CacheInvalidationService::class, ['invalidateWallet' => null])
        );

        $listener->handleInvestmentProfitApplied([
            'user_id' => 7,
            'investment_id' => 5,
            'net_amount' => '120.5',
            'balance_after' => '1120.5',
            'profit_type' => 'profit',
            'currency' => 'irt',
            'period' => '2026-W44',
        ]);

        $this->assertTrue(true, 'listener بدون exception و با ارز رویداد فرمت کرد');
    }

    public function test_profit_applied_listener_defaults_to_usdt_for_legacy_payload(): void
    {
        $container = m::mock(\Core\Container::class);
        $logger = m::mock(\App\Contracts\LoggerInterface::class);
        $listener = new \App\Listeners\InvestmentEventListeners($container, $logger);

        $currencySvc = m::mock(\App\Services\CurrencyService::class);
        $currencySvc->shouldReceive('formatAmount')->twice()->andReturnUsing(
            function ($amount, ?string $currency = null): string {
                $this->assertSame('usdt', $currency, 'payload بی‌ارز (legacy) → usdt');
                return $amount . ' USDT';
            }
        );
        $container->shouldReceive('make')->with('App\Services\CurrencyService')->andReturn($currencySvc);
        $notifier = m::mock(\App\Contracts\NotificationServiceInterface::class);
        $notifier->shouldReceive('send')->once();
        $container->shouldReceive('make')->with('App\Contracts\NotificationServiceInterface')->andReturn($notifier);
        $container->shouldReceive('make')->with('App\Services\Cache\CacheInvalidationService')->andReturn(
            m::mock(\App\Services\Cache\CacheInvalidationService::class, ['invalidateWallet' => null])
        );

        $listener->handleInvestmentProfitApplied([
            'user_id' => 7, 'investment_id' => 5,
            'net_amount' => '10', 'balance_after' => '110',
            'profit_type' => 'profit', 'period' => '2026-W44',
        ]);

        $this->assertTrue(true);
    }
}
