<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Contracts\LoggerInterface;
use App\Models\ContentAgreement;
use App\Models\ContentRevenue;
use App\Models\ContentSubmission;
use App\Services\ContentService;
use App\Services\Settings\AppSettings;
use Core\Database;
use Core\Exceptions\BusinessException;
use Core\TransactionWrapper;
use Mockery as m;
use PHPUnit\Framework\TestCase;

/**
 * 🛡️ FIX-Q4 — پیش‌نمایش سهم، دقت bcmath و سقف‌های ارسال محتوا.
 *
 *  • MOD24-12: پیش‌نمایش JS فرم ادمین همیشه «۱۰۰−سهم سایت» بود؛ اکنون
 *    getUserSharePreview همان مسیر محاسبهٔ سرور (پاداش سطح) را برمی‌گرداند.
 *  • MOD24-22: مبالغ با bcmath در scale=8 محاسبه می‌شوند (ستون‌ها
 *    DECIMAL(24,8))؛ گرد کردن float دو رقمی برای USDT خطای واقعی بود.
 *  • MOD24-23: سقف روزانهٔ ارسال محتوا از تنظیمات (پیش‌فرض ۱۰؛ ۰ = بی‌سقف).
 *  • MOD24-04: سهمیهٔ «در صف بررسی» شامل under_review هم هست.
 */
final class ContentSharePreviewAndQuotasTest extends TestCase
{
    protected function tearDown(): void { m::close(); parent::tearDown(); }

    /** @param array<string, float|int|string> $settings */
    private function buildService(
        array $settings,
        int $activeMonths = 0,
        int $publishedCount = 0,
        ?ContentSubmission $submissionMock = null,
        ?\stdClass &$capturedCreate = null,
        bool $passthroughTransaction = false
    ): ContentService {
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();

        $settingsMock = m::mock(AppSettings::class);
        foreach ($settings as $key => $value) {
            $settingsMock->shouldReceive('get')->with($key, m::any())->andReturn($value)->byDefault();
        }
        $settingsMock->shouldIgnoreMissing(0);

        $submission = $submissionMock ?? m::mock(ContentSubmission::class);
        $submission->shouldReceive('getActiveMonths')->andReturn($activeMonths)->byDefault();
        $submission->shouldReceive('getActiveMonthsForSubmission')->andReturn($activeMonths)->byDefault();
        $submission->shouldReceive('countByUser')->andReturn($publishedCount)->byDefault();
        $submission->shouldReceive('countByUserInStatuses')->andReturn(0)->byDefault();
        $submission->shouldReceive('countCreatedTodayByUser')->andReturn(0)->byDefault();

        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldIgnoreMissing();

        $db = m::mock(Database::class);
        $db->shouldIgnoreMissing();

        $transactionWrapper = m::mock(TransactionWrapper::class);
        if ($passthroughTransaction) {
            // اجرای مستقیم closure (بدون DB واقعی) برای مسیرهای موفق
            $transactionWrapper->shouldReceive('run')->andReturnUsing(static function (callable $cb) {
                return $cb();
            });
        }

        $agreement = m::mock(ContentAgreement::class);
        $agreement->shouldIgnoreMissing();
        $agreement->shouldReceive('create')->andReturn(555)->byDefault();

        return new ContentService(
            $logger,
            $db,
            $submission,
            $revenue,
            $agreement,
            $transactionWrapper,
            $settingsMock,
            null,
        );
    }

    private function defaultSettings(): array
    {
        return [
            'content_site_share_percent' => 40.0,
            'content_tax_percent' => 9.0,
            'content_active_bonus_percent' => 5.0,
            'content_active_max_percent' => 75.0,
            'content_professional_bonus_percent' => 10.0,
            'content_professional_max_percent' => 80.0,
            'currency_mode' => 'irt',
        ];
    }

    // ── MOD24-12: پیش‌نمایش = همان مسیر سرور ─────────────────────────

    public function test_preview_normal_tier_matches_server_formula(): void
    {
        $preview = $this->buildService($this->defaultSettings(), 2, 0)->getUserSharePreview(5);
        $this->assertSame('normal', $preview['tier']);
        $this->assertSame(60.0, $preview['user_percent']);
        $this->assertSame(40.0, $preview['site_percent']);
        $this->assertSame(9.0, $preview['tax_percent']);
    }

    public function test_preview_professional_tier_includes_level_bonus(): void
    {
        // حرفه‌ای: پایه ۶۰ + پاداش ۱۰ (سقف ۸۰) ⇒ ۷۰ — پیش‌نمایش JS قبلی ۶۰ نشان می‌داد
        $preview = $this->buildService($this->defaultSettings(), 12, 10)->getUserSharePreview(5);
        $this->assertSame('professional', $preview['tier']);
        $this->assertSame(70.0, $preview['user_percent']);
        $this->assertSame(30.0, $preview['site_percent']);
    }

    public function test_preview_active_tier(): void
    {
        $preview = $this->buildService($this->defaultSettings(), 6, 5)->getUserSharePreview(5);
        $this->assertSame('active', $preview['tier']);
        $this->assertSame(65.0, $preview['user_percent']);
    }

    // ── MOD24-22: دقت bcmath در scale 8 (مسیر پولی USDT) ─────────────

    public function test_usdt_amounts_keep_8_decimal_precision(): void
    {
        $captured = new \stdClass();
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('find')->with(10)->andReturn((object)[
            'id' => 10,
            'user_id' => 5,
            'status' => ContentSubmission::STATUS_PUBLISHED,
        ]);
        $submission->shouldReceive('getActiveMonthsForSubmission')->with(10)->andReturn(2);
        $submission->shouldReceive('getActiveMonths')->with(5)->andReturn(2);
        $submission->shouldReceive('countByUser')->andReturn(0);

        $revenue = m::mock(ContentRevenue::class);
        $revenue->shouldReceive('existsForPeriod')->andReturn(false);
        $revenue->shouldReceive('create')->once()->andReturnUsing(
            static function (array $data) use (&$captured) {
                $captured = (object)$data;
                return 77;
            }
        );

        $settings = $this->defaultSettings();
        $settings['currency_mode'] = 'usdt';
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldIgnoreMissing();
        $settingsMock = m::mock(AppSettings::class);
        foreach ($settings as $key => $value) {
            $settingsMock->shouldReceive('get')->with($key, m::any())->andReturn($value)->byDefault();
        }
        $settingsMock->shouldIgnoreMissing(0);

        $db = m::mock(Database::class);
        $db->shouldReceive('beginTransaction')->byDefault();
        $db->shouldReceive('commit')->byDefault();
        $db->shouldReceive('rollback')->byDefault();
        $db->shouldReceive('query')->andReturn(m::mock(\PDOStatement::class))->byDefault();

        $service = new ContentService(
            $logger, $db, $submission, $revenue,
            m::mock(ContentAgreement::class),
            m::mock(TransactionWrapper::class),
            $settingsMock, null,
        );

        // ۰٫۱۲۳۴۵۶۷۸ تتر: سایت ۴۰٪ = ۰٫۰۴۹۳۸۲۷۱ / کاربر ۶۰٪ = ۰٫۰۷۴۰۷۴۰۶ —
        // گرد کردن float دو رقمی قبلاً این ارقام را از بین می‌برد.
        $result = $service->recordRevenue(10, 1, ['total_revenue' => 0.12345678, 'period' => '1405-07']);
        $this->assertTrue($result['success'] ?? false);

        $this->assertSame('0.04938271', (string)$captured->site_share_amount, 'سهم سایت با دقت ۸ رقم (40٪)');
        $this->assertSame('0.07407406', (string)$captured->user_share_amount, 'سهم کاربر با دقت ۸ رقم (60٪)');
        $this->assertSame('0.12345677', bcadd((string)$captured->site_share_amount, (string)$captured->user_share_amount, 8), 'جمع سهم‌ها ≤ درآمد کل (bcmath؛ اختلاف ۱e-8 = کف گرد کردن ضرب)');
        $this->assertSame(-1, bccomp(bcadd((string)$captured->site_share_amount, (string)$captured->user_share_amount, 8), '0.12345678', 8), 'جمع سهم‌ها هرگز بیشتر از درآمد کل نیست');
    }

    // ── MOD24-23: سقف روزانهٔ ارسال ─────────────────────────────────

    public function test_daily_submission_cap_blocks_eleventh_submission(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('countCreatedTodayByUser')->with(5)->andReturn(10);
        $submission->shouldReceive('countByUserInStatuses')->andReturn(0);

        $service = $this->buildService(
            ['content_max_submissions_per_day' => 10] + $this->defaultSettings(),
            0, 0, $submission,
        );

        $this->expectException(BusinessException::class);
        $this->expectExceptionMessage('سقف ارسال محتوا در روز');
        $service->submitContent(5, [
            'platform' => 'youtube',
            'video_url' => 'https://youtu.be/capTest1',
            'title' => 'تست سقف',
            'agreement_accepted' => 1,
        ]);
    }

    public function test_daily_cap_zero_means_unlimited(): void
    {
        $unusedCaptured = null;
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('countCreatedTodayByUser')->with(5)->andReturn(50);
        $submission->shouldReceive('countByUserInStatuses')->andReturn(0);
        // ادامهٔ مسیر: نرمال‌سازی و isUrlExists → false، سپس create موفق
        $submission->shouldReceive('isUrlExists')->andReturn(false);
        $submission->shouldReceive('create')->andReturn(123);

        $service = $this->buildService(
            ['content_max_submissions_per_day' => 0, 'content_max_pending_submissions' => 1] + $this->defaultSettings(),
            0, 0, $submission,
            $unusedCaptured,
            true // passthroughTransaction
        );

        $result = $service->submitContent(5, [
            'platform' => 'youtube',
            'video_url' => 'https://youtu.be/capTest2',
            'title' => 'تست بی‌سقف',
            'agreement_accepted' => 1,
        ]);
        $this->assertTrue($result['success'] ?? false, '۰ = بی‌سقف (رفتار قدیم)');
    }

    // ── MOD24-04: سهمیهٔ در صف شامل under_review ───────────────────

    public function test_pending_quota_counts_under_review_too(): void
    {
        $submission = m::mock(ContentSubmission::class);
        $submission->shouldReceive('countCreatedTodayByUser')->andReturn(0);
        // سهمیهٔ ۱ پر شده با یک under_review — قبلاً فقط pending شمرده می‌شد
        $submission->shouldReceive('countByUserInStatuses')
            ->with(5, [ContentSubmission::STATUS_PENDING, ContentSubmission::STATUS_UNDER_REVIEW])
            ->andReturn(1);

        $service = $this->buildService(
            ['content_max_pending_submissions' => 1] + $this->defaultSettings(),
            0, 0, $submission,
        );

        $this->expectException(BusinessException::class);
        $this->expectExceptionMessage('حداکثر تعداد مجاز محتوای در انتظار');
        $service->submitContent(5, [
            'platform' => 'youtube',
            'video_url' => 'https://youtu.be/quotaTest',
            'title' => 'تست سهمیه',
            'agreement_accepted' => 1,
        ]);
    }
}
