<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use PHPUnit\Framework\TestCase;
use Mockery as m;
use Core\Database;
use App\Contracts\LoggerInterface;
use App\Domain\Financial\Services\FinancialEscrowService;
use App\Models\AccountDeletionLog;
use App\Models\User;
use App\Services\CustomTask\AdminCustomTaskService;
use App\Services\DistributedLockService;
use App\Services\SagaOrchestrator;
use App\Services\User\AccountDeletionService;

/**
 * 🛡️ FIX-S24-DELETION-FUNDS — تست‌های تسویهٔ اسکروهای باز هنگام حذف حساب.
 *
 * پوشش:
 *  ۱) اسکروی بودجه‌ای سمت خریدار → refundHeldBudget به نفع خود کاربر
 *  ۲) اسکروی P2P سمت خریدار → refundEscrowToBuyer (مسیر کامل کانونیک)
 *  ۳) اسکروی P2P سمت فروشنده → refundEscrowToBuyer به نفع خریدارِ طرف مقابل
 *  ۴) شکستِ refund → InvalidStateException (fail-closed؛ rollback ساگا)
 *  ۵) اسکروی disputed → هیچ refundی اجرا نمی‌شود؛ هشدار ثبت می‌شود
 *  ۶) خنثی‌سازی اجراهای در انتظارِ کمپین‌های خود کاربر
 */
class AccountDeletionSettlementTest extends TestCase
{
    /** @var Database&\Mockery\MockInterface */
    private Database $db;
    /** @var LoggerInterface&\Mockery\MockInterface */
    private LoggerInterface $logger;
    /** @var FinancialEscrowService&\Mockery\MockInterface */
    private FinancialEscrowService $escrow;
    private AccountDeletionService $service;

    private const UID = 99;

    protected function setUp(): void
    {
        parent::setUp();
        $this->db = m::mock(Database::class);
        $this->db->shouldIgnoreMissing();
        $this->logger = m::mock(LoggerInterface::class);
        $this->logger->shouldIgnoreMissing();
        $this->escrow = m::mock(FinancialEscrowService::class);

        $this->service = new AccountDeletionService(
            $this->db,
            $this->logger,
            m::mock(User::class),
            m::mock(AccountDeletionLog::class),
            m::mock(AdminCustomTaskService::class),
            m::mock(DistributedLockService::class),
            m::mock(SagaOrchestrator::class),
            $this->escrow
        );
    }

    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }

    /**
     * اجرای متد خصوصی settleOpenEscrowsToWallet با Reflection
     * @param list<\stdClass> $openEscrows
     */
    private function settle(array $openEscrows, int $disputedCount = 0): void
    {
        $this->db->shouldReceive('fetchColumn')
            ->andReturnUsing(function (string $sql, array $params = []) use ($disputedCount) {
                if (str_contains($sql, 'disputed') && str_contains($sql, 'escrow_transactions')) {
                    return $disputedCount;
                }
                return 0;
            })->byDefault();

        $this->db->shouldReceive('fetchAll')
            ->andReturnUsing(function (string $sql, array $params = []) use ($openEscrows) {
                if (str_contains($sql, 'FROM escrow_transactions')) {
                    return $openEscrows;
                }
                return [];
            })->byDefault();

        $this->db->shouldReceive('execute')->andReturn(0)->byDefault();

        $method = new \ReflectionMethod(AccountDeletionService::class, 'settleOpenEscrowsToWallet');
        $method->invoke($this->service, self::UID);
    }

    /** ردیف اسکروی نمونه */
    private function escrowRow(array $over = []): \stdClass
    {
        return (object) array_merge([
            'id' => 11,
            'order_id' => '55',
            'order_type' => 'social_task_budget',
            'buyer_id' => self::UID,
            'seller_id' => 0,
            'amount' => '50000.00000000',
            'currency' => 'irt',
            'status' => 'in_escrow',
        ], $over);
    }

    public function test_buyer_side_budget_escrow_refunds_via_refundHeldBudget(): void
    {
        $this->escrow->shouldReceive('refundHeldBudget')
            ->once()
            ->withArgs(function (int $escrowId, int $buyerId, string $reason, string $by, string $key) {
                return $escrowId === 11
                    && $buyerId === self::UID
                    && $by === 'account_deletion'
                    && $key === 'acct_del_escrow_11'
                    && $reason !== '';
            })
            ->andReturn(['ok' => true, 'amount' => '50000', 'currency' => 'irt']);

        $this->settle([$this->escrowRow()]);

        $this->assertTrue(true, 'تسویهٔ بودجه‌ای بدون استثنا به پایان رسید');
    }

    public function test_buyer_side_p2p_escrow_uses_canonical_refundEscrowToBuyer(): void
    {
        $this->escrow->shouldReceive('refundEscrowToBuyer')
            ->once()
            ->withArgs(function (int $escrowId, int $buyerId, string $reason, string $by, string $key) {
                return $escrowId === 12
                    && $buyerId === self::UID
                    && $by === 'account_deletion'
                    && $key === 'acct_del_escrow_12';
            })
            ->andReturn(['ok' => true, 'amount' => '120000', 'currency' => 'irt']);

        $this->settle([$this->escrowRow(['id' => 12, 'order_type' => 'custom_deal', 'seller_id' => 7])]);

        $this->assertTrue(true, 'اسکروی P2P از مسیر کانونیک refundEscrowToBuyer تسویه شد');
    }

    public function test_seller_side_escrow_refunds_counterparty_buyer(): void
    {
        // کاربرِ حذف‌شده «فروشنده» است؛ ذی‌نفعِ استرداد باید خریدارِ طرف مقابل باشد.
        $this->escrow->shouldReceive('refundEscrowToBuyer')
            ->once()
            ->withArgs(function (int $escrowId, int $buyerId, string $reason, string $by, string $key) {
                return $escrowId === 13
                    && $buyerId === 77 // خریدارِ طرف مقابل — نه کاربرِ حذف‌شده
                    && $by === 'account_deletion'
                    && str_contains($reason, 'فروشنده');
            })
            ->andReturn(['ok' => true, 'amount' => '90000', 'currency' => 'irt']);

        $this->settle([$this->escrowRow([
            'id' => 13,
            'order_type' => 'vitrine_listing',
            'buyer_id' => 77,
            'seller_id' => self::UID,
        ])]);

        $this->assertTrue(true, 'وجهِ معاملهٔ فروشندهٔ حذف‌شده به خریدار مسترد شد');
    }

    public function test_refund_failure_throws_and_is_fail_closed(): void
    {
        $this->escrow->shouldReceive('refundHeldBudget')
            ->once()
            ->andReturn(['ok' => false, 'error' => 'موجودی قفل‌شده کافی نیست']);

        $this->expectException(\Core\Exceptions\InvalidStateException::class);

        $this->settle([$this->escrowRow(['id' => 14])]);
    }

    public function test_disputed_escrows_are_left_for_admin_and_logged(): void
    {
        // اسکروی disputed در سویپِ بازها نیست (فقط pending/in_escrow/partial) —
        // پس باید فقط هشدار ثبت شود و هیچ refundی صدا زده نشود.
        $this->escrow->shouldNotReceive('refundHeldBudget');
        $this->escrow->shouldNotReceive('refundEscrowToBuyer');

        $this->logger->shouldReceive('warning')
            ->once()
            ->withArgs(function (string $event, array $ctx) {
                return $event === 'account_deletion.disputed_escrows_left_for_admin'
                    && (int)($ctx['disputed_count'] ?? 0) === 2;
            });

        $this->settle([], disputedCount: 2);

        $this->assertTrue(true, 'اسکروهای disputed بدون اقدام مالی برای ادمین علامت‌گذاری شدند');
    }

    public function test_incoming_pending_work_on_own_campaigns_is_cancelled(): void
    {
        $this->escrow->shouldReceive('refundHeldBudget')
            ->once()->andReturn(['ok' => true, 'amount' => '100', 'currency' => 'irt']);

        $this->db->shouldReceive('execute')
            ->once()
            ->withArgs(function (string $sql, array $params) {
                return str_contains($sql, 'social_task_executions')
                    && str_contains($sql, 'JOIN ads')
                    && (int)$params[0] === self::UID;
            })
            ->andReturn(3);
        $this->db->shouldReceive('execute')
            ->once()
            ->withArgs(function (string $sql, array $params) {
                return str_contains($sql, 'custom_task_submissions')
                    && str_contains($sql, 'JOIN ads')
                    && (int)$params[0] === self::UID;
            })
            ->andReturn(2);

        $this->logger->shouldReceive('info')
            ->once()
            ->withArgs(function (string $event, array $ctx) {
                return $event === 'account_deletion.escrows_settled'
                    && (int)($ctx['incoming_work_cancelled'] ?? 0) === 5;
            });

        $this->settle([$this->escrowRow(['id' => 21])]);

        $this->assertTrue(true, 'اجراهای در انتظارِ کمپین‌های کاربر خنثی شدند');
    }
}
