<?php

declare(strict_types=1);

namespace Tests\Unit\Services;

use App\Contracts\CacheInterface;
use App\Contracts\LoggerInterface;
use App\Services\CacheAdminService;
use Core\PathResolver;
use Mockery as m;
use Mockery\Adapter\Phpunit\MockeryPHPUnitIntegration;
use PHPUnit\Framework\TestCase;

final class CacheAdminServiceTest extends TestCase
{
    use MockeryPHPUnitIntegration;

    public function test_reset_circuit_breaker_deletes_all_real_core_keys(): void
    {
        $cache = m::mock(CacheInterface::class);
        $logger = m::mock(LoggerInterface::class);

        $cache->shouldReceive('delete')
            ->with('circuit_breaker:payments:status')
            ->once()
            ->ordered()
            ->andReturn(true);
        $cache->shouldReceive('delete')
            ->with('circuit_breaker:payments:failures')
            ->once()
            ->ordered()
            ->andReturn(true);
        $cache->shouldReceive('delete')
            ->with('circuit_breaker:payments:opened_at')
            ->once()
            ->ordered()
            ->andReturn(true);
        $logger->shouldReceive('info')
            ->with('cache.circuit_breaker.reset', ['name' => 'payments'])
            ->once();

        $service = new CacheAdminService(
            $logger,
            $cache,
            new PathResolver(dirname(__DIR__, 3))
        );

        $this->assertTrue($service->resetCircuitBreaker('payments'));
    }

    public function test_unknown_tag_cannot_be_flushed(): void
    {
        $cache = m::mock(CacheInterface::class);
        $cache->shouldNotReceive('tags');
        $logger = m::mock(LoggerInterface::class);
        $logger->shouldReceive('warning')->once();

        $service = new CacheAdminService(
            $logger,
            $cache,
            new PathResolver(dirname(__DIR__, 3))
        );

        $result = $service->clear('tags', 'arbitrary-user-input');
        $this->assertFalse((bool)($result['success'] ?? true));
    }
}
