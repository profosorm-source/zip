<?php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap/app.php';

// FIX-STATE-ISOLATION: اثر انگشت دستگاهِ CLI ثابت است و تراکنش‌های تست‌های مختلف
// خوشهٔ «شبکهٔ سابیلی» می‌سازند. UA اختصاصیِ همین اسکریپت + یکتاسازی
// اثر انگشتِ ردیف‌های قبلی در setup، خوشه را از هر دو سر می‌بندد.
$_SERVER['HTTP_USER_AGENT'] = 'legacy-test/phase3-revenue';
$_SERVER['HTTP_ACCEPT_LANGUAGE'] = 'fa';

use Core\Container;
use App\Services\AdSystemManager;
use App\Services\Wallet\WalletService;
use App\Services\EscrowService;
use App\Models\User;
use Core\Database;

/**
 * Phase 3 Revenue Integration Test
 * 
 * Objectives:
 * 1. Verify correct Ad Adapter resolution (Banner vs SEO).
 * 2. Verify Financial integrity (Funds hold -> Ad creation -> Ledger).
 * 3. Verify Anti-Fraud (IP Blacklist).
 */

class RevenueTest {
    private Database $db;
    private AdSystemManager $adManager;
    private WalletService $walletService;
    private EscrowService $escrow;
    private int $testUserId;

    public function __construct() {
        $this->db = Container::getInstance()->make(Database::class);
        $this->adManager = Container::getInstance()->make(AdSystemManager::class);
        $this->walletService = Container::getInstance()->make(WalletService::class);
        $this->escrow = Container::getInstance()->make(EscrowService::class);
        
        $this->setupTestData();
    }

    private function setupTestData() {
        // Create a test user if not exists
        $this->testUserId = 99999;
        $this->db->prepare("INSERT IGNORE INTO users (id, email, full_name, password, created_at) VALUES (?, 'test@revenue.com', 'test_revenue', 'hashed_pass', NOW())")->execute([$this->testUserId]);

        // FIX-STATE-ISOLATION (خطای از-قبل): اجراهای پیاپی، velocity ماليِ
        // (Core\Cache) و توکن‌باکتِ financial_commitment کاربرِ تست را اشباع
        // می‌کردند و create با «محدودیت‌های امنیتی» رد می‌شد. الگوی ایزولاسیونِ
        // خود پروژه (tests/flush_cache.php) اینجا اعمال می‌شود + ریست حالتِ تقلب.
        \Core\Container::getInstance()->make(\Core\Cache::class)->flush();
        $this->db->prepare("UPDATE users SET fraud_score = 0, is_blacklisted = 0, status = 'active' WHERE id = ?")->execute([$this->testUserId]);
        $this->db->prepare("DELETE FROM fraud_logs WHERE user_id = ?")->execute([$this->testUserId]);

        // FIX-STATE-ISOLATION (ادامه): در CLI هیچ UA/IPی وجود ندارد →
        // generate_device_fingerprint() برای «همهٔ» تست‌های CLI یک مقدار ثابت
        // می‌سازد؛ تراکنش‌های کاربران تستِ مختلف (۹۹۹۹۹/۸۸۸۸۸/۷۷۷۷۷) با همان
        // اثر انگشت، خوشهٔ «شبکهٔ سابیلی» (≥۳ حساب) می‌سازند و گارد مالی
        // create را با «محدودیت‌های امنیتی» رد می‌کند. اثر انگشتِ ذخیره‌شدهٔ
        // کاربرِ همین تست یکتا می‌شود (خودترمیم‌شونده در اجراهای بعدی).
        $this->db->prepare(
            "UPDATE transactions SET device_fingerprint = CONCAT('test-isolated-', user_id, '-', device_fingerprint)
             WHERE user_id = ? AND device_fingerprint IS NOT NULL AND device_fingerprint <> ''
               AND device_fingerprint NOT LIKE 'test-isolated-%'"
        )->execute([$this->testUserId]);
        
        // Clear wallet if exists and recreate with clean 1000000 IRT
        $this->db->prepare("DELETE FROM wallets WHERE user_id = ?")->execute([$this->testUserId]);
        $this->db->prepare("INSERT INTO wallets (user_id, balance_irt, created_at) VALUES (?, 1000000, NOW())")->execute([$this->testUserId]);
        
        // Clear previous test ads, escrows, and sagas
        $this->db->prepare("DELETE FROM ads WHERE user_id = ?")->execute([$this->testUserId]);
        $this->db->prepare("DELETE FROM escrow_transactions WHERE buyer_id = ? OR seller_id = ?")->execute([$this->testUserId, $this->testUserId]);
        $this->db->prepare("DELETE FROM saga_executions WHERE payload LIKE ?")->execute(["%\"user_id\":$this->testUserId%"]);
        $this->db->prepare("DELETE FROM idempotency_keys WHERE user_id = ?")->execute([$this->testUserId]);
    }

    public function run() {
        $this->testBannerCreation();
        $this->testSeoCreation();
        $this->testIpBlacklist();
        
        echo "\n✅ All Revenue Tests Passed!\n";
    }

    private function testBannerCreation() {
        echo "Testing Banner Creation... ";
        
        $data = [
            'title' => 'Test Banner',
            'placement' => 'homepage_slider',
            'link' => 'https://example.com',
            'image_path' => 'uploads/banners/test-banner.png', // FIX-REVENUE-PHASE3: مسیر تصویر امن — اعتبارسنجی جاری بنر بدون آن رد می‌شود
            'budget' => '10000',
            'currency' => 'irt',
            'total_budget' => '10000',
        ];

        $result = $this->adManager->create('banner', $this->testUserId, $data);
        
        if (!isset($result['ad_id'])) {
            throw new Exception("Banner creation failed: " . json_encode($result));
        }

        // Verify DB records
        $stmt = $this->db->prepare("SELECT * FROM ads WHERE id = ?");
        $stmt->execute([$result['ad_id']]);
        $ad = $stmt->fetch();
        if (!$ad) throw new Exception("Ad record not found in DB");

        // Verify Ledger / Wallet (Approx check)
        $stmt = $this->db->prepare("SELECT balance_irt FROM wallets WHERE user_id = ?");
        $stmt->execute([$this->testUserId]);
        $wallet = $stmt->fetch();
        if (!$wallet || $wallet->balance_irt >= 1000000) {
            throw new Exception("Funds were not deducted from wallet");
        }

        echo "OK\n";
    }

    private function testSeoCreation() {
        echo "Testing SEO Creation... ";
        
        $data = [
            'title' => 'Test SEO',
            'site_url' => 'https://example.com',
            'keyword' => 'test keyword',
            'price_per_click' => '100',
            'budget' => '20000',
            'currency' => 'irt',
            'total_budget' => '20000',
        ];

        $result = $this->adManager->create('seo', $this->testUserId, $data);
        
        if (!isset($result['ad_id'])) {
            throw new Exception("SEO creation failed: " . json_encode($result));
        }

        $stmt = $this->db->prepare("SELECT * FROM ads WHERE id = ?");
        $stmt->execute([$result['ad_id']]);
        $ad = $stmt->fetch();
        if (!$ad) throw new Exception("Ad record not found in DB");

        echo "OK\n";
    }

    private function testIpBlacklist() {
        echo "Testing IP Blacklist... ";
        
        $badIp = '1.2.3.4';
        $this->db->prepare("INSERT INTO ip_blacklist (ip_address, reason, auto_blocked, expires_at) VALUES (?, 'test fraud', 1, DATE_ADD(NOW(), INTERVAL 1 DAY))")->execute([$badIp]);
        
        // In a real scenario, we'd check a service that uses this table.
        // Since we don't have a direct 'checkIp' method in AdSystemManager, 
        // we verify the table works.
        $stmt = $this->db->prepare("SELECT id FROM ip_blacklist WHERE ip_address = ? AND (expires_at IS NULL OR expires_at > NOW()) LIMIT 1");
        $stmt->execute([$badIp]);
        $check = $stmt->fetch();
        
        if (!$check) throw new Exception("Blacklisted IP not found");
        
        // Clean up
        $this->db->prepare("DELETE FROM ip_blacklist WHERE ip_address = ?")->execute([$badIp]);
        
        echo "OK\n";
    }
}

try {
    $test = new RevenueTest();
    $test->run();
} catch (\Throwable $e) {
    echo "\n❌ Test Failed: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
