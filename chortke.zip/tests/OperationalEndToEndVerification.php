<?php

declare(strict_types=1);

namespace Tests;

use App\Models\User;
use App\Models\Wallet;
use App\Models\VitrineListing;
use App\Models\Ticket;
use App\Services\Wallet\WalletMutationService;
use App\Services\Wallet\WalletService;
use App\Services\VitrineService;
use App\Services\User\UserService;
use App\Services\TicketService;
use Core\Database;
use Core\Container;

/**
 * OperationalEndToEndVerification — اجرای آزمون‌های ۱۰۰٪ عملیاتی و لایو روی MariaDB و Redis
 *
 * این اسکریپت تمام مراحل کاری پلتفرم را به صورت واقعی روی دیتابیس اجرا و مقادیر جدول‌ها را
 * قبل و بعد از هر اکشن بازرسی می‌کند.
 */
require_once __DIR__ . '/../bootstrap/app.php';

echo "\n======================================================================\n";
echo "  شروع اجرای آزمون‌های ۱۰۰٪ عملیاتی، اکشن‌محور و زنده (Live MariaDB Operations)\n";
echo "======================================================================\n\n";

$db = Database::getInstance();
$container = Container::getInstance();

$userSvc = $container->make(UserService::class);
$walletSvc = $container->make(WalletService::class);
$vitrineSvc = $container->make(VitrineService::class);

$pass = 0;
$fail = 0;

function opAssert(string $title, bool $condition, string $detail = '') {
    global $pass, $fail;
    if ($condition) {
        echo "  ✓ PASS: {$title}" . ($detail ? " ({$detail})" : "") . "\n";
        $pass++;
    } else {
        echo "  ✗ FAIL: {$title}" . ($detail ? " ({$detail})" : "") . "\n";
        $fail++;
    }
}

// ─── اکشن ۱: ثبت‌نام و ساخت کیف‌پول واقعی در دیتابیس ───────────────
echo "▶ [اکشن ۱]: افتتاح حساب کاربری و ایجاد کیف‌پول در MariaDB...\n";
$email1 = 'op_user1_' . time() . '@chortke.test';
$passHash = hash_password('123456');

$u1Id = (int)$db->insert(
    "INSERT INTO users (username, email, password, full_name, role, status, kyc_status, email_verified_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'user', 'active', 'verified', NOW(), NOW(), NOW())",
    ['user1_' . time(), $email1, $passHash, 'کاربر عملیاتی اول']
);

$db->insert("INSERT INTO wallets (user_id, balance_irt, balance_usdt, locked_irt, locked_usdt) VALUES (?, 0, 0, 0, 0)", [$u1Id]);

$w1 = $db->fetch("SELECT balance_irt, balance_usdt FROM wallets WHERE user_id = ?", [$u1Id]);
opAssert("حساب کاربری op_user1 در دیتابیس ایجاد شد", $u1Id > 0, "User ID: {$u1Id}");
opAssert("کیف پول اول با موجودی اولیه صفر ایجاد شد", (float)$w1->balance_irt === 0.0);


// ─── اکشن ۲: واریز دستی ۵ میلیون تومانی و شارژ دیتابیس ──────────────
echo "\n▶ [اکشن ۲]: ثبت واریز دستی ۵ میلیون تومانی و شارژ کیف پول...\n";
$trkCode = 'TRK_OP_' . time();
$depId = (int)$db->insert(
    "INSERT INTO manual_deposits (user_id, amount, currency, tracking_code, status, created_at)
     VALUES (?, 5000000, 'irt', ?, 'pending', NOW())",
    [$u1Id, $trkCode]
);

// تایید ادمین و شارژ کیف پول
$db->execute("UPDATE manual_deposits SET status = 'approved', approved_at = NOW() WHERE id = ?", [$depId]);
$walletSvc->deposit($u1Id, '5000000', 'irt', ['type' => 'manual_deposit', 'deposit_id' => $depId]);

$w1AfterDep = $db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u1Id]);
opAssert("موجودی کاربر اول پس از واریز دستی به ۵,۰۰۰,۰۰۰ تومان رسید", (float)$w1AfterDep->balance_irt === 5000000.0, "Balance: " . number_format((float)$w1AfterDep->balance_irt) . " IRT");


// ─── اکشن ۳: انتقال اعتبار P2P بین دو کاربر واقعی ─────────────────
echo "\n▶ [اکشن ۳]: انتقال اعتبار ۱ میلیون تومانی P2P به کاربر دوم...\n";
$email2 = 'op_user2_' . time() . '@chortke.test';
$u2Id = (int)$db->insert(
    "INSERT INTO users (username, email, password, full_name, role, status, kyc_status, email_verified_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'user', 'active', 'verified', NOW(), NOW(), NOW())",
    ['user2_' . time(), $email2, $passHash, 'کاربر عملیاتی دوم']
);
$db->insert("INSERT INTO wallets (user_id, balance_irt, balance_usdt, locked_irt, locked_usdt) VALUES (?, 0, 0, 0, 0)", [$u2Id]);

// انتقال ۱,۰۰۰,۰۰۰ تومان
$transferRes = $walletSvc->transfer($u1Id, $u2Id, '1000000', 'irt', 'انتقال P2P عملیاتی');

$w1AfterTrans = $db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u1Id]);
$w2AfterTrans = $db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u2Id]);

opAssert("موجودی فرستنده به ۴,۰۰۰,۰۰۰ تومان کسر شد", (float)$w1AfterTrans->balance_irt === 4000000.0);
opAssert("موجودی گیرنده به ۱,۰۰۰,۰۰۰ تومان افزایش یافت", (float)$w2AfterTrans->balance_irt === 1000000.0);


// ─── اکشن ۴: معامله اسکرو در ویترین تجاری (قفل وجه و تسویه) ──────────
echo "\n▶ [اکشن ۴]: ثبت آگهی فروش ۱۰۰ تتری در ویترین، قفل امانی و تسویه...\n";
// شارژ ۱۰۰ تتر کاربر ۱
$walletSvc->deposit($u1Id, '100', 'usdt', ['type' => 'test_charge']);

// ساخت آگهی ویترین توسط کاربر ۲ (فروشنده)
$listingId = (int)$db->insert(
    "INSERT INTO vitrine_listings (seller_id, title, category, platform, price_usdt, status, created_at, updated_at)
     VALUES (?, 'کانال تلگرام معامله عملیاتی', 'social', 'telegram', 100.0000, 'active', NOW(), NOW())",
    [$u2Id]
);

// قفل اسکرو توسط کاربر ۱ (خریدار)
$lockRes = $vitrineSvc->lockEscrow($u1Id, $listingId);
$lockOk = is_object($lockRes) ? (bool)($lockRes->success ?? false) : (bool)($lockRes['success'] ?? false);

$w1Locked = $db->fetch("SELECT balance_usdt, locked_usdt FROM wallets WHERE user_id = ?", [$u1Id]);

opAssert("قفل وجه اسکرو ۱۰۰ تتری خریدار موفقیت‌آمیز بود", $lockOk);
opAssert("مبلغ ۱۰۰ تتر در حساب خریدار قفل گردید (Locked USDT = 100)", (float)$w1Locked->locked_usdt === 100.0);

// تایید تحویل توسط خریدار و آزادسازی وجه به فروشنده
$confirmRes = $vitrineSvc->confirmDelivery($u1Id, $listingId);
$confirmOk = is_object($confirmRes) ? (bool)($confirmRes->success ?? false) : (bool)($confirmRes['success'] ?? false);
$w2Seller = $db->fetch("SELECT balance_usdt FROM wallets WHERE user_id = ?", [$u2Id]);

opAssert("تایید تحویل انجام شد و معامله ویترین تسویه گردید", $confirmOk);
opAssert("مبلغ ۱۰۰ تتر به حساب فروشنده واریز شد (موجودی فروشنده: {$w2Seller->balance_usdt} USDT)", (float)$w2Seller->balance_usdt > 0);


// ─── اکشن ۵: ثبت تیکت پشتیبانی و پاسخ ادمین ───────────────────────
echo "\n▶ [اکشن ۵]: ثبت تیکت پشتیبانی و پاسخ‌دهی ادمین در دیتابیس...\n";
$ticketSvc = $container->make(TicketService::class);
$ticketRes = $ticketSvc->create($u1Id, [
    'subject' => 'پیگیری واریز دستی ۵ میلیون تومانی',
    'category' => 'billing',
    'category_id' => 1,
    'priority' => 'high',
    'message' => 'سلام، واریز دستی ۵ میلیون تومانی انجام گردید. لطفاً بررسی و تایید بفرمایید.'
]);

opAssert("تیکت پشتیبانی با موفقیت در دیتابیس ثبت شد", $ticketRes['success']);

$ticketId = (int)($ticketRes['data']['ticket_id'] ?? $ticketRes['ticket_id'] ?? 0);
if ($ticketId > 0) {
    // پاسخ ادمین
    $db->insert(
        "INSERT INTO ticket_messages (ticket_id, user_id, message, is_admin, created_at)
         VALUES (?, 3, 'پاسخ ادمین: درخواست شما تایید و واریز انجام شد.', 1, NOW())",
        [$ticketId]
    );
    $db->execute("UPDATE tickets SET status = 'answered', updated_at = NOW() WHERE id = ?", [$ticketId]);

    $tRow = $db->fetch("SELECT status FROM tickets WHERE id = ?", [$ticketId]);
    opAssert("پاسخ ادمین ثبت شد و وضعیت تیکت به answered تغییر یافت", $tRow->status === 'answered');
}


// ─── اکشن ۶: پایش ریسک ضدتقلب و ارزیابی امتیاز ────────────────────
echo "\n▶ [اکشن ۶]: ارزیابی ریسک ضدتقلب و ثبت جریمه در MariaDB...\n";
$userSvc->incrementFraudScore($u2Id, 15);
$u2Updated = $db->fetch("SELECT fraud_score FROM users WHERE id = ?", [$u2Id]);

opAssert("امتیاز ریسک کاربر در دیتابیس با موفقیت ارتقا یافت (Fraud Score = {$u2Updated->fraud_score})", (int)$u2Updated->fraud_score === 15);

echo "\n======================================================================\n";
echo "  خلاصه عملکرد آزمون‌های ۱۰۰٪ عملیاتی و زنده دیتابیس\n";
echo "======================================================================\n";
echo "  Passed: {$pass}    Failed: {$fail}\n";
echo "======================================================================\n\n";

exit($fail === 0 ? 0 : 1);
