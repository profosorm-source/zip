<?php

declare(strict_types=1);

require_once __DIR__ . '/../bootstrap/app.php';

// FIX-STATE-ISOLATION: اثر انگشت دستگاهِ CLI ثابت است و تراکنش‌های تست‌های مختلف
// خوشهٔ «شبکهٔ سابیلی» می‌سازند. UA اختصاصیِ همین اسکریپت + یکتاسازی
// اثر انگشتِ ردیف‌های قبلی در setup، خوشه را از هر دو سر می‌بندد.
$_SERVER['HTTP_USER_AGENT'] = 'legacy-test/phase4-payouts';
$_SERVER['HTTP_ACCEPT_LANGUAGE'] = 'en'; // FIX-STATE-ISOLATION: زبانِ متفاوت = اثر انگشت متفاوت (hash شامل substr(acceptLang,0,5))

use Core\Container;
use Core\Database;
use App\Models\SocialTaskModel;
use App\Models\SocialTaskExecutionModel;
use App\Jobs\SocialTask\ApproveSocialTaskExecutionJob;
use App\Listeners\SocialTaskEventListeners;
use Core\Event;

class PayoutIntegrationTest {
    private Database $db;
    private SocialTaskModel $taskModel;
    private SocialTaskExecutionModel $execModel;
    private int $advertiserId = 88888;
    private int $executorId = 77777;
    private int $adId = 0;

    public function __construct() {
        $this->db = Container::getInstance()->make(Database::class);
        // SocialTaskModel requires ExecutionModel and AnalyticsModel
        $this->execModel = Container::getInstance()->make(SocialTaskExecutionModel::class);
        $analyticsModel = Container::getInstance()->make(\App\Models\SocialTaskAnalyticsModel::class);
        $this->taskModel = new SocialTaskModel($this->db, $this->execModel, $analyticsModel);
        
        $this->setupTestData();
    }

    private function setupTestData() {
        // 1. Create Users
        $this->db->prepare("INSERT IGNORE INTO users (id, email, full_name, password, created_at) VALUES (?, 'adv@test.com', 'Advertiser', 'pass', NOW())")->execute([$this->advertiserId]);
        $this->db->prepare("INSERT IGNORE INTO users (id, email, full_name, password, created_at) VALUES (?, 'exe@test.com', 'Executor', 'pass', NOW())")->execute([$this->executorId]);

        // 2. Wallets — delete+insert (الگوی phase3) تا holdهای اجرای قبلی انباشته نشود
        $this->db->prepare("DELETE FROM wallets WHERE user_id IN (?, ?)")->execute([$this->advertiserId, $this->executorId]);
        $this->db->prepare("INSERT INTO wallets (user_id, balance_irt, created_at) VALUES (?, 1000000, NOW())")->execute([$this->advertiserId]);
        $this->db->prepare("INSERT INTO wallets (user_id, balance_irt, created_at) VALUES (?, 0, NOW())")->execute([$this->executorId]);

        // FIX-STATE-ISOLATION (خطای از-قبل): flush الگوی tests/flush_cache.php +
        // ریست حالت تقلب — اجراهای پیاپی velocity/token-bucketِ financial_commitment
        // را اشباع می‌کرد و AdSystemManager::create با «محدودیت‌های امنیتی» رد می‌شد.
        \Core\Container::getInstance()->make(\Core\Cache::class)->flush();
        $this->db->prepare("UPDATE users SET fraud_score = 0, is_blacklisted = 0, status = 'active' WHERE id IN (?, ?)")->execute([$this->advertiserId, $this->executorId]);
        $this->db->prepare("DELETE FROM fraud_logs WHERE user_id IN (?, ?)")->execute([$this->advertiserId, $this->executorId]);

        // FIX-STATE-ISOLATION (ادامه): در CLI اثر انگشتِ دستگاه ثابت است؛
        // تراکنش‌های کاربران تستِ مختلف خوشهٔ «شبکهٔ سابیلی» (≥۳ حساب) می‌سازند و
        // گارد مالی create را رد می‌کند. اثر انگشتِ ذخیره‌شدهٔ کاربرانِ همین تست
        // یکتا می‌شود (خودترمیم‌شونده در اجراهای بعدی).
        $this->db->prepare(
            "UPDATE transactions SET device_fingerprint = CONCAT('test-isolated-', user_id, '-', device_fingerprint)
             WHERE user_id IN (?, ?) AND device_fingerprint IS NOT NULL AND device_fingerprint <> ''
               AND device_fingerprint NOT LIKE 'test-isolated-%'"
        )->execute([$this->advertiserId, $this->executorId]);

        // 3. FIX-PAYOUT-PHASE4 (خطای از-قبل): تبلیغ تسک اجتماعی از مسیر مالیِ
        // واقعی ساخته می‌شود (AdSystemManager: قول saga + hold بودجه + ردیف
        // escrow با order_type=social_task_budget). درج خامِ مستقیم در ads
        // escrow نمی‌ساخت و ApproveSocialTaskExecutionJob به‌درستی fail-closed
        // می‌شد («escrow بودجه‌ی تسک اجتماعی یافت نشد»). پلتفرم youtube نیز
        // طبق قرارداد Adaptersocial فقط از مسیر AdTube می‌آید → instagram.
        $this->db->prepare("DELETE FROM ads WHERE user_id = ?")->execute([$this->advertiserId]);
        $this->db->prepare("DELETE FROM escrow_transactions WHERE buyer_id = ? OR seller_id = ?")->execute([$this->advertiserId, $this->advertiserId]);
        $adManager = Container::getInstance()->make(\App\Services\AdSystemManager::class);
        $adResult = $adManager->create('social_task', $this->advertiserId, [
            'title'         => 'Test Task',
            'platform'      => 'instagram',
            'task_type'     => 'subscribe',
            'link'          => '@testchannel',
            'price_per_task' => '5000',
            'total_count'   => 10,
            'currency'      => 'irt',
        ]);
        if (!isset($adResult['ad_id'])) {
            throw new Exception('Social ad creation failed: ' . json_encode($adResult, JSON_UNESCAPED_UNICODE));
        }
        $this->adId = (int)$adResult['ad_id'];

        // 4. Clear old executions
        $this->db->prepare("DELETE FROM social_task_executions WHERE executor_id = ?")->execute([$this->executorId]);
    }

    public function run() {
        echo "--- Phase 4: Social Task Payout Integration Test ---\n";

        // Step 1: Create Execution
        echo "Creating execution... ";
        $execId = $this->execModel->createExecution([
            'ad_id' => $this->adId,
            'executor_id' => $this->executorId,
            'ip_address' => '127.0.0.1',
            'user_agent' => 'TestAgent',
            'expected_time' => 60
        ]);
        echo "Created ID: $execId\n";

        // Step 2: Move to 'submitted' status (pending -> started -> submitted)
        echo "Updating execution status... ";
        $this->execModel->updateExecutionStatus($execId, 'started');
        $this->execModel->updateExecutionStatus($execId, 'submitted');
        echo "OK\n";

        // Step 3: Approve Execution using Job
        echo "Approving execution... ";
        $job = Container::getInstance()->make(ApproveSocialTaskExecutionJob::class);
        $result = $job->handle($this->advertiserId, $execId);
        if (!$result['success']) {
            throw new Exception("Approval failed: " . $result['message']);
        }
        echo "OK\n";

        // Step 4: Simulate Outbox/Event Dispatch for Payout
        echo "Triggering payout listener... ";
        $listener = Container::getInstance()->make(SocialTaskEventListeners::class);
        
        // The event data as it would be produced by ApproveSocialTaskExecutionJob
        $eventData = [
            'user_id' => $this->executorId,
            'reward_amount' => 5000,
            'currency' => 'irt',
            'execution_id' => $execId,
            'ad_id' => $this->adId,
            'decision' => 'approved'
        ];
        
        // Create a concrete Event class since Core\Event is abstract
        $event = new class($eventData) extends \Core\Event {
            public function __construct($data) { parent::__construct($data); }
        };

        
        $listener->handleRewardApproved($event);
        echo "OK\n";

        // Step 5: Verify Wallet Balance
        echo "Verifying wallet balance... ";
        $wallet = $this->db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$this->executorId]);
        if (!$wallet || (float)$wallet->balance_irt < 5000) {
            throw new Exception("Payment not received. Balance: " . ($wallet->balance_irt ?? 'null'));
        }
        echo "Balance: {$wallet->balance_irt} (OK)\n";

        // Step 6: Verify Ledger Entries
        echo "Verifying ledger... ";
        $ledgerCount = $this->db->fetchColumn("SELECT COUNT(*) FROM ledger_entries WHERE account = ? AND currency = 'irt'", ["wallet:{$this->executorId}"]);
        if ((int)$ledgerCount === 0) {
            throw new Exception("No ledger entry found for the payout");
        }
        echo "Found $ledgerCount entries (OK)\n";

        echo "\n✅ Payout Integration Test Passed!\n";
    }
}

try {
    $test = new PayoutIntegrationTest();
    $test->run();
} catch (\Throwable $e) {
    echo "\n❌ Test Failed: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
