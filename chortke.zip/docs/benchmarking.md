# Benchmarking

Chortke keeps two performance views separate:

1. Browser/tunnel measurements represent user-perceived latency, including the browser, proxy, and tunnel.
2. Direct HTTP measurements represent backend/API latency for the application, database, and Redis path.

## Direct local or staging-like run

Use the dependency-free benchmark with its safe local defaults:

```bash
php scripts/benchmark_http.php \
  --label=backend-local \
  --base-url=http://127.0.0.1:8091 \
  --requests=20 \
  --concurrency=4
```

For an approved staging or production-like target, explicitly opt in to a low-load remote run:

```bash
php scripts/benchmark_http.php \
  --label=backend-staging \
  --base-url=https://staging.example.com \
  --requests=20 \
  --concurrency=4 \
  --allow-remote \
  --json
```

Do not run an uncontrolled load test against production. Use a small request count, a scheduled window, and monitoring for errors, latency, database connections, Redis, CPU, and memory.

The JSON output is intended to be stored beside the browser report. Compare p50/p95/max only between runs made with the same route set, request count, concurrency, and environment.
