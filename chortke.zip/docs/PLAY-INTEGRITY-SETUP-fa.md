# راهنمای Play Integrity — راه‌اندازی بعدی و حالت آزمایشی (mock)

> **نوع سند:** عملیاتی/راهنما · **ایجاد:** ۲۰۲۶-۱۰-۲۶ (تصمیم مالک D5)
> **قلمرو:** attestation تسک‌های اجتماعی (F21-01 گزینهٔ C) — `PlayIntegrityService`
> **موضع طراحی:** attestation فقط «سیگنال تقویتی» است؛ نبود/شکست آن هرگز مسیر دوربین
> را بلاک نمی‌کند (کافه‌بازار/بدون-GMS safe) و فقط در ستون `attestation_status`
> جدول `social_camera_requests` ثبت می‌شود.

---

## ۱) وضعیت فعلی (بدون کلید گوگل — رفتار پیش‌فرض)

سیستم همین امروز **بدون هیچ کلید گوگلی کامل کار می‌کند**:

| پارامتر | مقدار فعلی | اثر |
|---|---|---|
| `play_integrity_enabled` | `0` (بولی، گروه task) | سرویس attestation غیرفعال |
| `play_integrity_api_key` | خالی (secret، گروه task) | هیچ فراخوانی شبکه‌ای به گوگل انجام نمی‌شود |
| چالش دوربین (`camera-challenge`) | `attestation_available: false` | کلاینت توکن نمی‌فرستد |
| `camera-verify` با توکن | `attestation_status: disabled` | فقط ثبت وضعیت؛ **هیچ اثری بر حکم/امتیاز/تصمیم ندارد** (fail-open طبق طراحی مالک) |

پس فعال‌کردن بعدی **هیچ عجله‌ای ندارد** — هیچ قابلیتی از چرخهٔ وریفایر دوربین به آن
گرفته نشده است.

## ۲) راه‌اندازی واقعی (وقتی کلید گوگل در دسترس شد)

**گام ۱ — ساخت کلید در Google Cloud Console:**
1. پروژه‌ای که اپ اندروید در آن تعریف شده را باز کنید (یا پروژهٔ جدید بسازید).
2. «APIs & Services → Library» → جستجوی **Play Integrity API** → Enable.
3. «APIs & Services → Credentials» → Create Credentials → **API Key**. کلید را کپی کنید
   (همان کلیدی که `PlayIntegrityService::DECODE_URL` با پارامتر `?key=` مصرف می‌کند؛
   آدرس: `https://playintegrity.googleapis.com/v1/integrity:decodeIntegrityToken?key=…`).
4. در همان صفحهٔ Credentials، محدودیت (restriction) کلید را به «Play Integrity API»
   ببندید و در صورت امکان به IP سرورهای خود محدود کنید.

**گام ۲ — تنظیم Play Console (سمت اپ):**
1. Play Console → اپ → «Release → Setup → App integrity».
2. برای درخواست‌های کلاسیک Play Integrity، **SHA-256 امضای اپ** (keystore استقرار)
   باید همان چیزی باشد که توکن‌ها با آن صادر می‌شوند؛ نیازی به آپلود چیزی در سرور
   چرتکه نیست.
3. کلاینت اندروید باید طبق `CAMERA-VERIFY-CONTRACT.md §۶`:
   - nonce چالش دوربین را از پاسخ `camera-challenge` بگیرد؛
   - `requestHash` توکن را دقیقاً برابر `sha256(nonce)` (hex کوچک) بگذارد؛
   - توکن را در فیلد `attestation.token` هنگام `camera-verify` بفرستد.

**گام ۳ — فعال‌سازی در چرتکه (صفر خط کد):**
1. پنل ادمین → تنظیمات → تب «تسک‌ها و محتوا» (گروه task):
   - `play_integrity_api_key` → کلید ساخته‌شده در گام ۱؛
   - `play_integrity_enabled` → روشن.
2. fallback محیطی: کلید را می‌توان به‌جای پنل در `.env` هم گذاشت —
   `PLAY_INTEGRITY_API_KEY=…` (خوانده‌شده از `config/services.php`؛ پنل اولویت دارد).
   افزودن این خط به `.env.example` برای یادآوری کافی است.
3. تست سلامت: یک چالش دوربین بگیرید — پاسخ باید `attestation_available: true` باشد؛
   سپس `camera-verify` با توکن واقعی → `attestation_status: verified` (با
   `request_hash_match: true`).

**نکتهٔ عملیاتی:** تغییر پنل کش Redis تنظیمات (`chortke:system:settings:v2`) را خودکار
پاک/بازپر می‌کند؛ اگر مقدار مستقیم در DB عوض شود، فلش دستی کش لازم است.

**پایش بعد از فعال‌سازی:**
- ستون `attestation_status` در `social_camera_requests` (verified/failed/unavailable/disabled)؛
- لاگ‌های `play_integrity.*` در لاگ سرویس (`play_integrity.decode_unavailable`،
  `play_integrity.request_hash_mismatch`، `play_integrity.decode_http_error`).
- `unavailable` یعنی مشکل شبکه/سهمیه/کلید — با «توکن جعلی» اشتباه گرفته نشود.

## ۳) حالت آزمایشی (mock) — تست فلو بدون کلید گوگل

**هدف:** وقتی کلید واقعی نیست، مسیر کامل attestation (چالش → ساخت توکن → verify →
ثبت وضعیت) بتواند در محیط توسعه/تست واقعاً اجرا شود.

**دو گارد مستقل (عمق دفاع) — هر دو باید برقرار باشند:**
1. محیط: `APP_ENV` برابر `local` یا `testing` باشد (در `production` هرگز، حتی اگر
   سوییچ روشن شود).
2. سوییچ پنل: `play_integrity_mock` (گروه task، پیش‌فرض خاموش) روشن باشد.

**قرارداد توکن mock:**
```
mock-integrity.<sha256(nonce) به‌صورت hex کوچک>
```
کلاینت/تست باید خودش `sha256(nonce)` چالش را محاسبه و در توکن بگذارد — یعنی همان
منطق مقیدسازی `requestHash` مسیر واقعی طی می‌شود (توکن mock هم به چالش گره خورده و
بین چالش‌ها قابل بازیافت نیست). فقط «transport گوگل» با پاسخ ساختگی جایگزین شده است؛
همهٔ منطق راستی‌آزمایی (`hash_equals`، verdicts، licensing) همان کد تولیدی است.

**رفتار:**
| ورودی | خروجی |
|---|---|
| توکن درستِ مقید به nonce | `status=verified`، `request_hash_match=true`، verdicts: `MEETS_BASIC_INTEGRITY`, `MEETS_DEVICE_INTEGRITY` |
| توکن با هشِ چالش دیگر | `status=failed`، `error=request_hash_mismatch` (همان مسیر واقعی) |
| توکن خارج از قرارداد mock | `status=unavailable`، `error=mock_decode_failed` |
| mock خاموش + کلید نیست | `status=disabled` (رفتار پیش‌فرض فعلی) |

**روشن/خاموش‌کردن:** پنل → تنظیمات → تب تسک‌ها → `play_integrity_mock`. مقدار در
کاتالوگ (`SettingsCatalog` گروه task) هم هست تا نصب‌های تازه به‌صورت پیش‌فرضِ خاموش
seed شوند.

> ℹ️ نکتهٔ seeding (بازبینی D1–D6): `play_integrity_enabled` برخلاف
> `play_integrity_mock`، در `SettingsCatalog` تعریف نشده و صرفاً از ماگریشن
> `2026_10_22_0002_camera_option_c_settings_seed.sql` (شرط WHERE NOT EXISTS) seed
> می‌شود — پنل مقدار را از DB می‌خواند، پس در نصب تازه فقط از همین مسیر می‌آید.

## ۴) نقشهٔ کد (برای بازبین بعدی)

| نقطه | فایل | نقش |
|---|---|---|
| سرویس | `app/Services/SocialTask/PlayIntegrityService.php` | `isEnabled()` (کلید+سوییچ)، `isMockEnabled()` (دو گارد)، `verify()` (منطق مشترک)، `decodeToken()` (transport گوگل)، `decodeMockToken()` (transport ساختگی) |
| اتصال به چرخهٔ دوربین | `app/Services/SocialTask/CameraVerificationService.php` | `attestation_available` در `getChallenge` (isEnabled ∨ isMockEnabled)؛ `verify()` در `processResult` → فقط ثبت `attestation_status` |
| تنظیمات | `SettingsCatalog` (گروه task) + جدول `system_settings` | `play_integrity_mock` (بولی، پیش‌فرض ۰)؛ `play_integrity_api_key` (secret)؛ `play_integrity_enabled` (بولی) |
| قرارداد کلاینت | `CAMERA-VERIFY-CONTRACT.md §۶` | requestHash = sha256(nonce) |

## ۵) پذیرش‌های امنیتی (ثابت و تغییرناپذیر)

1. attestation **هرگز** شرط عبور نیست — نبود/شکست/جعل آن حکم دوربین را fail نمی‌کند
   و نمره‌ای نمی‌گیرد/از دست نمی‌دهد.
2. mock در production غیرقابل فعال‌سازی است (گارد محیط پیش از گارد سوییچ).
3. توکن (واقعی یا mock) بدون `requestHash` هم‌خوان **هرگز** `verified` نمی‌شود.
4. `play_integrity_api_key` از نوع secret است و در پاسخ‌های API بازگردانده نمی‌شود.
