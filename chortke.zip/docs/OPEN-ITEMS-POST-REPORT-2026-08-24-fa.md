# موارد باز گزارش امنیت/مالی — ۱۴۰۵/۰۶/۰۲

این سند backlog مواردی است که پس از batchهای فعلی باید بررسی و اصلاح شوند.

## CSRF Contract Normalization — P1

وضعیت: باز، اصلاح سراسری هنوز انجام نشده است.

قرارداد canonical پیشنهادی:

- فرم POST: `_csrf_token`
- هدر HTTP: `X-CSRF-Token`
- meta tag: `csrf-token`
- تولید توکن PHP: `csrf_token()`

واریانت‌های legacy که باید inventory و سپس migrate شوند:

- `csrf_token`
- `X-CSRF-TOKEN`

دامنهٔ کار:

1. inventory تمام routeها، controllerها، viewها و JavaScriptها
2. اصلاح مصرف‌کننده‌ها بدون شکستن فرم‌های موجود
3. بررسی CORS allowlist
4. تست request بدون token، token نامعتبر و token معتبر
5. تست regression فرم‌های اصلی
6. در پایان تصمیم دربارهٔ حذف پشتیبانی legacy از CSRFMiddleware

شواهد فعلی:

- `app/Middleware/CSRFMiddleware.php` قرارداد `_csrf_token` و `X-CSRF-Token` را می‌خواند.
- `Admin/VitrineController` در batch قبلی اصلاح شد.
- `User/ContentController` و view محتوای کاربر هنوز variationهای legacy دارند.
- برخی JavaScriptها هنوز `X-CSRF-TOKEN` می‌فرستند.

## موارد باز دیگر

- انتقال کامل PDF/video proof به `UploadService`؛ در batch فعلی فقط `application/octet-stream` حذف شد.
- تست E2E دسترسی admin به فایل private متعلق به کاربر دیگر.
- تست concurrent کامل برای lifecycle escrow.
- audit نهایی rounding در مرزهای budget/ledger.
- انتقال تشخیص actionهای حساس PolicyService از regex به registry مرکزی.

## موردی که نباید دوباره اجرا شود

ادعای نبود idempotency برای P2P در گزارش قبلی با کد فعلی منطبق نیست؛ این بخش قبلاً اصلاح شده است.
