# مستند معماری و استانداردهای کدنویسی پروژه Chortke

این سند راهنمای رسمی برای توسعه‌دهندگان پلتفرم چرتکه است تا یکپارچگی معماری، امنیت بالا و عملکرد بهینه پروژه حفظ شود.

---

## ۱. ساختار لایه‌های معماری (Layered Architecture)

پروژه چرتکه بر اساس معماری لایه‌بندی شده توسعه یافته است. ارتباط بین لایه‌ها به صورت یک‌طرفه از بالا به پایین است:

```mermaid
graph TD
    Router --> Controllers
    Controllers --> Services
    Services --> Models
    Models --> Database
```

### ۱.۱. لایه کنترلرها (Controllers)
* تمام کنترلرها باید از کلاس `\App\Controllers\BaseController` یا `\App\Controllers\User\BaseUserController` ارث‌بری کنند.
* وظیفه کنترلر **فقط** دریافت ورودی، احراز هویت اولیه، فراخوانی سرویس مناسب و بازگرداندن پاسخ است.
* **هیچ منطق تجاری (Business Logic)، ارتباط مستقیم با دیتابیس یا محاسبات مالی نباید در کنترلر انجام شود.**

### ۱.۲. لایه سرویس‌ها (Services)
* قلب منطق تجاری سیستم است.
* ~~تمام سرویس‌ها **باید** از `\App\Services\BaseService` ارث‌بری کنند.~~
  **[به‌روزرسانی ۱۴۰۵/۰۶]** `BaseService` به‌دلیل بی‌مورد بودن **عمداً حذف شد** و این الزام دیگر برقرار نیست. قانون فعلی: سرویس‌ها کلاس مستقل‌اند؛ وابستگی‌ها (از جمله Logger) از طریق سازنده تزریق می‌شوند و هیچ کلاس پایه‌ی مشترکی الزامی نیست.
* تزریق وابستگی‌ها (Dependency Injection) باید از طریق سازنده (Constructor) انجام شود.
* لاگ‌گذاری به طور متمرکز از طریق `$this->logger` (تزریق‌شده با `LoggerInterface`) انجام می‌گردد.

### ۱.۳. لایه مدل‌ها (Models)
* مدل‌ها فقط مسئول تعامل با جداول پایگاه داده هستند.
* نباید هیچ‌گونه وابستگی به لایه‌های بالاتر (مانند سرویس‌ها) در مدل‌ها وجود داشته باشد.
* استفاده از `\Core\Container::getInstance()` در مدل‌ها **ممنوع** است.

---

## ۲. استانداردهای کدنویسی (Coding Standards)

* **نسخه PHP:** تمامی کدها باید با PHP 8.2+ و استاندارد `strict_types=1` سازگار باشند.
* **نام‌گذاری کلاس‌ها:** مطابق استاندارد PSR-4 به صورت PascalCase (مثال: `InvestmentService`).
* **نام‌گذاری متدها و متغیرها:** به صورت camelCase (مثال: `applyWeeklyProfitLoss`).
* **طول متدها:** حداکثر طول هر متد تجاری باید **زیر ۳۰ خط** باشد. در صورت طولانی شدن، باید به متدهای کوچک‌تر شکسته شود.

---

## ۳. امنیت و پیشگیری از آسیب‌پذیری‌ها

* **SQL Injection:** تمام کوئری‌ها باید از متدهای متصل پارامتری (Prepared Statements) استفاده کنند. هیچ پارامتر مستقیمی نباید درون رشته‌ی SQL الحاق (String Concat) شود.
* **XSS:** تمام خروجی‌ها در صفحات ویو باید با هلوپرهای ایمن انکود شوند.
* **تزریق وابستگی ایمن:** از فراخوانی سراسری کانتینر در بدنه متدها خودداری کرده و ترجیحاً از تزریق سازنده یا هلوپر استاندارد `app()` استفاده کنید.

---

## ۴. سیستم صف (Queue System)

* عملیات سنگین تجاری (مانند محاسبات سود هفتگی، ارسال ایمیل‌های انبوه و خروجی‌های گزارش‌گیری) نباید به صورت همزمان (Synchronous) پردازش شوند.
* این تسک‌ها باید با کلاس `\Core\Queue` درون صف ثبت شده و پردازش آن‌ها به پردازشگر پس‌زمینه در `cron.php` سپرده شود.

---

## ۵. تزریق وابستگی: قواعد و الگوهای رسمی (به‌روزرسانی ۱۴۰۵/۰۶)

> مرجع ممیزی: `CONTAINER_BYPASS_AUDIT_FA.md` (۲۰۲۶-۰۸-۲۴) — این بخش نتیجه‌ی آن ممیزی و تصمیم‌های اتخاذشده را رسمیت می‌دهد.

### ۵.۱. اولویت اول: تزریق سازنده (Constructor Injection)
* هر وابستگی **الزامی** باید پارامتر سازنده باشد. کانتینر (و `core/Router.php` در ساخت کنترلرها) autowire کامل انجام می‌دهد؛ بنابراین هیچ بهانه‌ای برای `app()` / `container->make(...)` در بدنه‌ی متد کنترلرها وجود ندارد.
* **ممنوع:** `app(X::class)` یا `$this->container->make(X::class)` در بدنه‌ی متدهای کنترلر/سرویس/میدل‌ور، تا وقتی تزریق سازنده ممکن است. فقط موارد ذیل در بخش ۵.۴ مستثنا هستند.

### ۵.۲. الگوی A — تزریق اختیاری با fail-closed (برای چرخه‌های واقعی)
وقتی چرخه‌ی وابستگی واقعی (A↔B) وجود دارد، به‌جای Service Locator از این الگو استفاده کنید:

```php
public function __construct(
    // ... وابستگی‌های الزامی
    ?FinancialEscrowService $escrowService = null,
) {
    $this->escrowService = $escrowService;
}

// در بدنه‌ی متد:
$escrow = $this->escrowService ?? throw new \RuntimeException('FinancialEscrowService در دسترس نیست');
```

* دو نوع کانسکوئنس مجاز است:
  * **fail-closed (`?? throw`)** — وقتی نبودِ وابستگی یعنی خطای فنی (پیش‌فرض برای مسیرهای مالی/حیاتی).
  * **best-effort با null-check** — وقتی وابستگی اختیاری محض است (مثلاً پاک‌سازی اعلان‌ها در `PasswordRecoveryService`)؛ ولی **هرگز** `?? app(...)` به‌عنوان fallback ننویسید.
* ضبط این الگو در گزارش: دسته B3 (سرویس‌های مالی/auth)، فازهای ۱ و ۲.

### ۵.۳. Property Injection رسمی — `#[Inject]`
فریم‌ورک تزریق پراپرتی رسمی دارد: `core/Attributes/Inject.php` + `core/Container::injectProperties()` (هر شیء ساخته‌شده از کانتینر، پراپرتی‌های `#[Inject]` را خودکار دریافت می‌کند). موارد استفاده:

```php
#[\Core\Attributes\Inject]
protected \App\Services\AuditTrail $auditTrail;
```

* الگوی رسمی برای فرزندان `BaseApiController` / `BaseUserController` / `BaseAdminController` است (به‌جای `container->make` دستی).
* **کاربرد عملی:** برای وابستگی‌های لِیزی (مثل `AuditTrail` که در هر درخواست لازم نیست) یا وقتی سازنده‌ی کلاس پایه مدیریت شده است.
* اگر کلاسی هم `#[Inject] Container` دارد و هم `$this->container = \Core\Container::getInstance();` در سازنده، خط سازنده **زائد** است و حذف می‌شود — مگر اینکه ساخت دستی (`new`) در tests/tools وجود داشته باشد؛ در آن صورت آن خط fallback عمدی است و با کامنت «DI-CLEANUP» علامت می‌خورد.

### ۵.۴. مستثناهای مجاز (Service Locator مشروع)
| الگو | دلیل | مثال |
|---|---|---|
| `app(X::class)` در `Optional-ctor + fallback` کلاس‌های پایه | الگوی عمدی سازگاری | `BaseController::__construct` (همه پارامترها optional هستند) |
| ساخت Job/Service از نام کلاس داینامیک | Factory/Registry ناگزیر | `QueueWorker`، `NotificationJobFactory`، `FraudStrategyResolver` |
| `Console/Kernel.php`، `Commands/*`، `Providers/*` | bootstrap و زمان‌بندی | cron شبانه |
| `app()` در داده‌ی درخواست جاری برای سرویس‌های singleton | در لحظه خواندن (frozen نباشد) | x-request-id در `LogService`، `AuditTrail` |
| فاسِد استاتیک رسمی: `app(self::class)` | سازگاری با کد legacy | `RateLimitPolicy::enforce()`، `PermissionMiddleware::check()` |
| `\Core\EventDispatcher::getInstance()` | سینگلتون فریم‌ورک که در binder ثبت شده | در ۸+ فایل (B5 گزارش — اولویت پایین) |

### ۵.۵. مدل‌ها: بدون Container، بدون request-context
* استفاده از `Container::getInstance()` / `app()` در مدل‌ها **ممنوع** است (بند ۱.۳).
* اگر مدلی به داده‌ی درخواست نیاز دارد (مثل `x-request-id` در `SentryModel`)، آن را به‌صورت **آرگومان اختیاری** دریافت کنید (`?string $requestId = null`) و fallbackِ خواندن از کانتینر را فقط در یک متد خصوصیِ کامنت‌دار نگه دارید:

```php
private function currentRequestId(): string
{
    if ($this->requestId !== null) {
        return $this->requestId;
    }
    return \function_exists('app') && app()->request
        ? str_value(app()->request->header('x-request-id') ?? '')
        : '';
}
```

* Data-utility های استاتیک (مثل `CommonPasswords`) وابستگی‌ها را **پارامتر متد** بگیرند، نه از کانتینر.

---

## ۶. سیاست Listener ها (Lazy Loading رویدادی)

۱۰ Listener رویداد (`Withdrawal`، `Influencer`، `KYC`، `Investment`، `TaskCompleted`، `Dispute`، `ScoreUpdate`، `Escrow`، `NotificationRequest`، `Vitrine`) طبق **الگوی رسمی singleton** کار می‌کنند:

* سازنده‌ی Listeners فقط `(Container, Logger)` می‌گیرد؛
* وابستگی‌های سنگین (سرویس/مدل/Outbox) **در بدنه‌ی متد و به‌صورت lazy** از `$this->container->make(...)` گرفته می‌شوند؛
* **چرا:** رویدادها می‌توانند زنجیره‌ای با چرخه بسازند (مثلاً `ScoreUpdateListener → UserLevelService → dispatch LevelUpgradedEvent → ...`). ساخت همه‌ی وابستگی‌ها در سازنده، چرخه‌ی ساخت کانتینر را عمیق/شکسته می‌کند؛ lazy در لحظه‌ی رویداد این را حل می‌کند و در عین حال در مسیرهای بدون رویداد هزینه‌ای ندارد.

**الزام:** هر Listener باید یک کامنت مرجع (مطابق `InvestmentEventListeners`) داشته باشد که این سیاست را توضیح دهد تا ممیزی‌های بعدی آن را نقض نپندارند.

```php
// ⚠️ الگوی رسمی: وابستگی‌ها عمداً lazy هستند (singleton + Container)
// تا از چرخه‌ی رویدادی (Event → Service → dispatch → Listener) جلوگیری شود.
```

---

## ۷. علامت‌گذاری پاک‌سازی: `🧹 DI-CLEANUP (YYYY-MM-DD)`

هر تغییری که `app()` / `make()` را حذف یا جابه‌جا می‌کند باید با کامنت `🧹 DI-CLEANUP (تاریخ)` + دلیل یک‌خطی علامت بخورد (الگوی اجراشده در ممیزی ۲۰۲۶-۰۸-۲۴). این باعث می‌شود ممیزی‌های بعدی بتوانند «عمدی» را از «باقی‌مانده» تفکیک کنند:
* کامنت روی خط حذف‌شده → ردیابی در git blame.
* کامنت روی خط نگه‌داشته‌شده (fallback عمدی) → جلوگیری از حذف اشتباه در آینده.
