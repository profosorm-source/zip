# راستی‌آزمایی گزارش «مسیرهای موازی مالی» مقابل کد واقعی

تاریخ: ۲۰۲۶-۰۸-۲۳ | روش: بازخوانی مستقیم سورس + بررسی ایندکس‌های DB واقعی (MariaDB با ۱۴۸ مایگریشن اعمال‌شده)

## پاسخ کوتاه

**بله — وجود مسیرهای موازی واقعی است.** از ۱۰ ادعای اصلی گزارش: **۷ مورد دقیقاً تأیید شد**، ۲ مورد در نتیجه درست ولی در مکانیزم نادقیق بود (P0-7 و P0-23)، و ۱ مورد در عمل توسط ایندکس DB بسته است (لاتاری). یک مورد جدید هم پیدا شد که گزارش «هنوز نخوانده» گذاشته بود و اکنون تأیید می‌شود (کمیسیون معرفی).

---

## جدول رأی نهایی

| ادعا | رأی | شواهد کد |
|---|---|---|
| **P0-20** outbox بدون consumer | ✅ **تأیید کامل — و بدتر از گزارش** | `OutboxPublisher::publishEvent` → `events->dispatchOrFail($event->event_type)`؛ در `AppServiceProvider` فقط ۱۶ رویداد listen شده و `wallet.deposit.requested` بین‌شان نیست. dispatch بدون listener = هیچ؛ ردیف outbox هم `status='published'` می‌خورد → پول بی‌صدا گم می‌شود. **یافته جدید:** `referral.commission.process` هم listener ندارد (`ReferralCommissionListener` فقط singleton bind شده، هرگز listen نشده) → کمیسیون‌های معرفیِ outbox-first هم می‌میرند. `crypto.deposit.confirmed` هم فقط در Registry تعریف شده. |
| **P0-7** واریز کریپتو دوبل | ✅ **تأیید — با تدقیق مکانیزم** | ادعای «بدون idempotency_key» دقیق نیست: `WalletService::deposit` کلید خودکار می‌سازد = `sha256(user|action|amount|currency|gateway_tx|ref|to_user|ip)`. اما کلید **شامل IP است**: approve ادمین (IP ادمین) و `tryAutoVerify` کرون (IP سیستم) → دو کلید متفاوت → حصار بی‌اثر. + TOCTOU واقعی: `approve()` وضعیت را **قبل از** `beginTransaction` بدون `FOR UPDATE` می‌خواند و `canTransition` روی وضعیت stale اجرا می‌شود → همزمانی ادمین+کرون = دو واریز USDT. (دابل‌کلیک همان ادمین از همان IP مسدود است.) |
| **P0-23** انتقال P2P دوبل | ⚠️ **نیمه‌درست — مکانیزم گزارش غلط، دو باگ واقعی دیگر** | ادعای «کلید idempotency نیست» رد شد: transfer از `executeAtomicOperation` می‌گذرد؛ کلید خودکار + UNIQUE روی `idempotency_keys.key` + قفل مرتب دو کیف. دابل‌کلیک/retry از همان IP مسدود است. باگ‌های واقعی: **(الف)** retry از IP متفاوت (موبایل/تعویض شبکه) = کلید جدید = دو انتقال کامل — سناریوی گزارش فقط با این شرط معتبر است. **(ب) باگ معکوس خطرناک‌تر:** انتقال مشروعِ دومِ همان مبلغ به همان گیرنده از همان IP تا **۹۰ روز** (CLEANUP_DAYS) به‌عنوان replay بلعیده می‌شود — کاربر پیام موفقیت می‌گیرد ولی پول جابه‌جا نمی‌شود. |
| **P0-19** پاداش تسک دوبار | ✅ **تأیید کامل** | دو موتور با **دو کلید متفاوت**: مسیر عادی `approveSubmission` → کلید `custom_task_reward_{id}` (escrow `partialRelease` یا deposit)؛ مسیر ادمین `forceApproveSubmissionByAdmin` (مجاز روی `submitted/disputed/rejected`) → `PayRewardJob` → کلید `ctask_reward_{id}`. کلیدها همدیگر را نمی‌بینند → حصار متقاطع صفر. بدتر: شاخه‌ی outbox در PayRewardJob بعد از record، `reward_paid=1` می‌زند در حالی که واریز واقعی هرگز انجام نمی‌شود (P0-20). |
| **P0-21** برداشت گیر کرده | ✅ **تأیید کامل** | `autoResolveStuck` فقط `UPDATE withdrawals SET status='rejected'` — **هیچ `cancelWithdrawal`ای در کار نیست** (مقایسه کنید با `adminReject` چند خط پایین‌تر که saga کامل `refund_hold` دارد). وجه در `locked_*` برای همیشه می‌ماند. تنها caller: `StuckWithdrawalReviewCommand` (CLI) — در Kernel نیست. زمین‌مین. |
| **P0-22** refund اینفلوئنسر دوبل | ✅ **تأیید** | `refundOrder` با کلید `story_refund_{orderId}` مستقیم `wallet.deposit` می‌زند **بدون** آزادسازی اسکرو. هیچ Controller/route ای صدایش نمی‌زند — فقط Facade `InfluencerService::refundOrder`. اگر روزی کنار `refundCustomer` (مسیر اسکرو) صدا شود = دو برگشت. زمین‌مین. |
| P1: نام رویداد اینفلوئنسر | ✅ **تأیید** | `completeOrder` رویداد `influencer.order_completed` (نقطه) می‌نویسد؛ listener روی `influencer_order.completed` (زیرخط) ثبت شده → شنونده برای مسیر complete هرگز آتش نمی‌گیرد. |
| P1: لاتاری API با `uniqid` | ✅ تأیید ولی **در عمل بسته** | `Api\WalletController::lotteryJoin` کلید نمی‌دهد و سرویس `uniqid` می‌سازد؛ اما ایندکس یکتای `uniq_lottery_participation_user_round_active (user_id, round_id, is_deleted)` **روی DB واقعی موجود است** → insert دوم شکست می‌خورد و TX عقب‌گرد می‌شود. |
| P1: `check_stuck_transactions.php` | ✅ **تأیید** | هر تراکنش `type='withdraw'` قدیمی‌تر از ۱ ساعت را unlock می‌کند — شامل holdهای لاتاری/اسکرو/برداشت. در Kernel نیست؛ فقط اگر cron قدیمی سرور هنوز اجرایش کند خطرناک است. |
| P1: `WithdrawalTimeoutJob` بدون قفل | ✅ **تأیید** | SELECT بدون `FOR UPDATE`؛ ترتیب: اول `cancelWithdrawal` بعد UPDATE گارد‌دار → پنجره‌ی ناسازگاری وضعیت با approve همزمان وجود دارد (ضرب پول نه، ناسازگاری وضعیت بله). |
| P1: `holdSocialTaskFunds` مرده | ✅ **تأیید** | هیچ caller خارج از خود `FinancialEscrowService` ندارد. |
| سایر «عمداً موازی نیست» (GET callback، Facade، …) | ✅ نمونه‌گیری تأیید شد | `callbackGet` اعتبار نمی‌زند؛ `executeApproveWallet` (saga کریپتو) هیچ caller ای ندارد؛ `InfluencerOrderTimeoutJob` در Kernel نیست و Kernel مستقیم `processExpired*` را صدا می‌زند. |

---

## پس «دو مسیر موازی» واقعاً طراحی شده؟

بله، در این نقاط دو (یا چند) مسیر مستقل برای همان پولِ واحد وجود دارد:

1. **پاداش تسک سفارشی:** موتور moderation (escrow/deposit با کلید A) در برابر موتور ادمین (`PayRewardJob` با کلید B) — واقعی و زنده.
2. **تأیید واریز کریپتو:** کلیک ادمین در برابر کرون auto-verify — هر دو به همان `approve()` می‌رسند ولی حصار مشترک ندارند (کلید IP-محور + وضعیت stale).
3. **معماری outbox در برابر مسیر مستقیم:** چند تولیدکننده رویداد واریز می‌نویسند در حالی که مصرف‌کننده هرگز وصل نشده — یعنی «مسیر دوم» ساخته شده ولی نیمه‌کاره رها شده است. این معماری دوگانه (اگر outbox بود → رویداد، وگرنه → deposit همزمان) در `PayRewardJob`، `refundOrder` و listener ها تکرار شده.
4. **بازگشت وجه اینفلوئنسر:** `refundCustomer` (مسیر اسکرو، زنده) در برابر `refundOrder` (مینت مستقیم، زمین‌مین).
5. **cron قدیمی `storage/cron/*` در برابر Kernel** — چهار فایل پول‌زا که اگر crontab قدیمی سرور هنوز فعال باشد، موازی با Job های Kernel اجرا می‌شوند.
6. **رأی جزئی dispute:** `resolveDisputePartial` (خودش پول می‌زند) + `resolveDisputedEscrow` (دوباره settle) — دو لایه روی هم.

## اصلاحات لازم روی خود گزارش

- **P0-7:** حصار «وجود دارد ولی IP-محور است» — نه اینکه اصلاً کلیدی نباشد. راه‌حل درست: کلید صریح `crypto_deposit_approve_{depositId}` + خواندن وضعیت با `FOR UPDATE` داخل TX.
- **P0-23:** دابل‌کلیک/retry معمولی مسدود است؛ خطر واقعی retry با تغییر IP و باگ معکوسِ بلعیدن انتقال مشروع دوم تا ۹۰ روز است. راه‌حل درست: حذف IP از کلید + کلید صریح سمت کلاینت (فرم توکن یک‌بارمصرف).
- **لاتاری:** با ایندکس موجود روی DB عملاً بسته است — از P1 خارج می‌شود (فقط برای محیط‌هایی که مایگریشن کامل نخورده‌اند ریسک است).
- **گسترش P0-20:** دامنه‌ی رویدادهای مرده بزرگ‌تر از گزارش است: `wallet.deposit.requested` + `referral.commission.process` + `crypto.deposit.confirmed` + `influencer.order_completed` (به‌خاطر typo نام).

## ترتیب پیشنهادی اصلاح (هم‌نظر با گزارش، با یک جابه‌جایی)

1. **P0-20** — تعیین تکلیف outbox (وصل‌کردن consumer با بازبینی کلیدها، یا حذف مسیر outbox و استفاده از مسیر مستقیم همه‌جا)
2. **P0-7** — کلید قطعی `crypto_deposit_approve_{id}` + `FOR UPDATE`
3. **P0-19** — یکی‌کردن کلید دو مسیر پاداش + گارد `reward_paid`
4. **P0-23** — حذف IP از ماده‌ی کلید + کلید صریح کلاینت (توجه: باگ معکوس ۹۰روزه هم همین‌جا حل می‌شود)
5. زمین‌مین‌ها: P0-21 (اضافه‌کردن `cancelWithdrawal` به autoResolveStuck)، P0-22، typo نام رویداد اینفلوئنسر، حذف/غیرفعال‌سازی cron های قدیمی
