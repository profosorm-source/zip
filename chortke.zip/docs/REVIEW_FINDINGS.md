# 📋 گزارش کامل بازبینی کد — پلتفرم چرتکه
**تاریخ:** ۱۴۰۴/۰۶/۲۹ (2026-09-19) | **محدوده:** سرویس‌ها (app/Services — 219 فایل) + ویوها (views — 301 فایل)
**روش:** بازبینی خط‌به‌خط توسط ۱۰ ایجنت مستقل + راستی‌آزمایی هر یافته با کد فراخوان، اینترفیس‌ها، اسکیمای مایگریشن‌ها و دیتابیس زنده
**جمع کل: ~۲۲۳ یافته** — Critical: 3 (+1 fix انجام‌شده در bring-up) | High: 38 | Medium: 91 | Low: 90

> ## ✅ وضعیت اصلاحات (به‌روزرسانی 2026-09-19 — دور ۱ فیکس)
> **فیکس‌شده و تست‌شده:** C-1، C-2، C-3 (همه Criticalها) + H-6، H-7، H-8، H-14، H-25، H-26/27، H-28، H-33
> ## ✅ وضعیت اصلاحات (به‌روزرسانی 2026-09-20 — دور ۱۳ فیکس: Lowهای کاربرمواجه + E2E رفرال + استایل/امکانات)
> - ۱۰ یافتهٔ Low کاربرمواجه بسته شد: آیکون‌های FA → material-icons (coupons/history + settings×7) | data-action صفحات خطا (500/429/419/feature-disabled) بدون inline-JS سالم | حذف require_once دوبارهٔ لایوت (tickets/show، transactions، users، kyc×2) | class تکراری roles/create|edit | لینک مطلق → url() (messages/index + sentry-widget) | فوتر عمومی از social-tasks×2 حذف | page-highlight باگ‌ریپورت با اثبات ?page=2 | off-by-one صفحه‌بندی rating-reviews | resend_mode در verify-email | قالب ایمیل lottery-winner بالاخره وصل شد (EmailService::sendLotteryWinnerEmail از LotteryCommandService::notifyWinner با DI nullable)
> - L-UI12: username در RegisterRequest یونیک شد (unique:users,username + پیام فارسی) — E2E: نام تکراری رد، یکتا قبول
> - E2E کامل جریان رفرال PASS: ?ref=CODE → ثبت‌نام → attribution (referral_clicks converted) → کمیسیون ۱۰۰۰ IRT + مایلستون ۱۰۰۰۰ IRT (تراکنش/لجر/idempotency کامل) → هاب معرف به‌روز — صفر ردپا (users=5)
> - استایل: تولتیپ CSS-محض data-tip (۱۴ دکمهٔ ادمین)، میکرو-اینتراکشن دکمه‌ها، بج معنایی، پولیش فرم‌ها (+~۴۱۰ خط layout.css)
> - امکانات: پیش‌نویس خودکار فرم‌ها (data-draft — بدون رمز/توکن)، جدول‌های مرتب‌شدنی (data-sortable + aria-sort)، پیمایش پایین موبایل پنل کاربر (m-nav با safe-area) — همه اثبات مرورگری
> - ⚠️ یافته‌های جدید دور ۱۳ (رفرال — برای دور بعد): ۱) پاداش معرف پیش از تأیید ایمیل پرداخت می‌شود (ProcessRegistrationJob — گیت R90 تنها سد است؛ پیشنهاد: گیت روی email_verified_at) ۲) ردیف milestone referred_user_id=خود معرف (ReferralService:1054) ۳) هاب رفرال برای کاربران قدیمی دکمهٔ تولید کد ندارد (views/user/referral/index.php:86-97) ۴) sendWelcomeEmail بدون فراخوان (کد مرده) ۵) اعلان/ایمیل به معرف هنگام تبدیل وجود ندارد ۶) پاداش شروع برای کاربر معرفی‌شده وجود ندارد

> ## ✅ وضعیت اصلاحات (به‌روزرسانی 2026-09-20 — دور ۱۲ فیکس: COEP/iframe + Lowهای کاربرمواجه + هشدار انقضا نشست)
> - **FIX-R12-1 (Low مرگ‌آور UI):** iframe سایت هدف در views/user/seo/execute.php **همیشه خالی** بود (CSP frame-src فقط هاست‌های مجاز + COEP:credentialless حذف کوکی + XFO سایت‌ها). جایگزین با کارت راهنمای مراحلی برنددار + فیکس انجماد تایمر JS (updateUI بدون فریم) — اثبات E2E مرورگری: شروع از بازار → اجرا → تایمر → تکمیل → امتیاز ۴۰- → fail-safe اسکرو («escrow یافت نشد») → rollback اتمیک (status=started باقی ماند)
> - **FIX-R12-2 (Low):** دکمه‌های toggle رمز در views/auth/reset-password.php تگ ناقص (">") داشتند؛ ارتقا به سنجهٔ ۴سگمنتی + بازخورد تطابق (هم‌الگوی register دور ۱۱) + حذف authresetpassword.js یتیم — اثبات مرورگری با توکن واقعی
> - **FIX-R12-3 (Low):** pageTitle→title در bank-cards / crypto-deposit / manual-deposit (تایتل صفحه برقرار شد)
> - **FIX-R12-4 (Low):** ایمیل هاردکد support@chortke.com در errors/503 → setting('contact_email','support@chortke.ir') + mailto؛ fallback خالی contact.php هم بسته شد
> - **FIX-R12-5 (Low):** دکمه‌های «خروجی Excel» ادمین (users/transactions) به هاب خالی می‌رفتند → روت‌های واقعی دانلود /admin/export/users و /transactions (اثبات: ERR_ABORTED=attachment streaming)
> - **FEAT-R12-1:** هشدار انقضای نشست بی‌کار (ux-extras.js + body[data-idle-seconds] در لایوت user/admin): ۲ دقیقه پیش از خروج خودکار، کارت شمارش معکوس فارسی + دکمهٔ «بمانم» (HEAD صریح) — بدون پینگ خودکار (تصمیم امنیتی حفظ شد)؛ اثبات E2E با setting موقت ۳۰۰ثانیه: شمارش «۱ دقیقه و ۴۸ ثانیه»، بمانم→HEAD 200→مخفی، حالت منقضی→لینک ورود؛ تنظیم به ۹۰۰ برگشت
> - **STY-R12-2:** حلقهٔ فوکوس طلایی سراسری (focus-visible) + رنگ انتخاب متن برند + استایل کارت هشدار (layout.css)
> - **اسکن COEP سراسری (توصیهٔ دور ۱۱):** فقط seo/execute (فیکس شد) و adtube (youtube-nocookie در frame-src مجاز، سالم) و mailbox (الگوی srcdoc دور ۱۱) — پاک
> - **E2E بازیابی رمز (توصیهٔ دور ۱۱):** فراموشی→ایمیل برنددار در mail.log→لینک→فرم→ورود مجدد — PASS؛ هش کاربر #۱ بازگردانی شد، توکن‌ها پاک (صفر ردپا)

> - C-1: EmailDeliveryStore — نگاشت dbmap + بستن ردیف DB در مسیر job (تست: tools/verify_fix_c1.php = PASS)
> - C-2: PaymentCommandService::checkPaymentIntegrity — پنجره ۲۵ساعته برای pending_verification (تست: tools/verify_fix_c2.php = ۳/۳ PASS)
> - C-3: disputes/index.php — to_jalali جایگزین کلاس خیالی
> - H-6/H-7: KYCCommandService → outbox | H-8: TwoFactorService → outbox | H-14: TrustService ستون‌های واقعی
> - H-25: Chart.js محلی | H-26/27/33: لینک‌های 404 اصلاح | H-28: روت‌های بن/تعلیق ادمین اصلاح + حذف دکمه delete بی‌روت

> ## ✅ وضعیت اصلاحات (به‌روزرسانی 2026-09-20 — دور ۳ فیکس: Mediumها)
> **همهٔ ۹۱ Medium بررسی شد؛ ~۷۰ مورد فیکس و تست شد با ۶ اسکریپت verify مستقل (جمعاً ۴۴۴+ PASS):**
>
> **8-a — باستان سیستمی RateLimiter/Cache + اسکیپ‌سگمنت (تست: tools/verify_fix8a.php = ۶۷/۶۷ PASS):**
> - قرارداد واحد «دقیقه» مستند شد در core/RateLimiter.php + TTL exact-seconds در core/Cache.php (setSeconds/putSeconds/rememberSeconds — بدون گردکردن زیر-دقیقه)
> - TicketCommandService ۳۶۰۰→۶۰ ×۲، ContactService ۸۶۴۰۰→۱۴۴۰ + ۳۶۰۰→۶۰ ×۳، TwoFactorService ۳۰۰→۵، AuthController forgot-pwd ۳۶۰۰→۶۰، ExportService ۳۶۰۰→۶۰
> - UserSettingsService/UserDashboardService/NotificationPreferenceService → putSeconds دقیق
> - CacheManager::increment دیگر false→0 نمی‌کند (int|false) → گاردهای fail-closed سقف کمیسیون و قفل ۱۰تایی دوباره زنده
> - 🛡️ کشف + فیکس SIGSEGV: زنجیرهٔ alert ریت‌لیمیت → NotificationTracker::invalidateUnreadCacheBulk با clone $redisClient + multi(PIPELINE) در phpredis 6.1.0 کرش می‌کرد (اثباتشده در HEAD) → multi-key DEL روی کلاینت مشترک
>
> **8-b — امنیت (تست: tools/verify_fix8b.php = ۱۴۰/۱۴۰ PASS):**
> - VerificationService: SSRF بسته شد (reject loopback/RFC1918/CGNAT/link-local/metadata/IPv4-mapped-IPv6 + resolve همهٔ A/AAAA fail-closed + فالو دستی ریدایرکت با re-validate، حداکثر ۳ هاپ)
> - CaptchaService: normalizeBehavioralEvents — ورودی garbage دیگر TypeError/۵۰۰ نمی‌دهد (graceful false)
> - BannerService: whitelist placeholder حذف؛ فقط مسیرهای نسبی داخلی + host خود اپ + ENV اختیاری؛ fail-closed
> - EmailService: log-injection بسته (strip CRLF/control chars + JSON تک‌خطی) + processQueue درایور log را دیگر رد نمی‌کند + 🛡️ کشف double-claim در EmailDeliveryStore::getPending که ایمیل‌های صف DB را بی‌صدا می‌گم کرد
> - AdminCustomTaskService::forceApprove: گارد وضعیت داخل تراکنش با SELECT…FOR UPDATE (TOCTOU بسته)
> - rateInfluencer: مالک‌بودن خریدار + وضعیت completed + بازهٔ ۱..۵ سخت‌گیرانه + یک رأی به‌ازای هر سفارش
> - views/admin/notifications/index.php: URL نسبی usable + اکشن‌ها روی window + delete بدون بک‌اند → toast محترمانه به‌جای POST مرده
>
> **8-c1 — مالی (تست: tools/verify_fix8c1.php = ۱۱۵/۱۱۵ PASS ×۳):**
> - ScheduledPaymentService: ترتیب قفل Redis-first هم‌الگوی WalletMutationService (پروب اثبات کرد stall ۱۰ثانیه‌ای رفع شده)
> - IdempotencyKey: rollback فقط توسط مالکِ تراکنش؛ helper دیگر تراکنش بیرونی را نمی‌بندد؛ کلید تکراری = همان نتیجه
> - InfluencerCommandService::respondToOrder + cron انقضا: claim اتمیک + refund در runWithRetry واحد؛ 🛡️ کشف حفرهٔ cron (فقط id برگردانده می‌شد → customer_id=0 → refund کرون همیشه شکست و سفارش گیر می‌کرد) → بارگذاری کامل ردیف در حلقه
> - AdNotificationDispatcher: بچ گیرندگان به chargedUnits بریده می‌شود (اثبات انتگرال: بودجهٔ ۲ واحد → دقیقاً ۲ ارسال)
> - DisputeCommandService::resolveByAgreement: اسکرو در «یک تراکنش» با درگاه وضعیت واقعی زیر قفل (release/refund/resolveDisputedEscrow)؛ شکست = rollback کامل؛ اعلان بعد از commit
>
> **8-c2 — منطق (تست: tools/verify_fix8c2.php = ۵۱/۵۱ PASS ×۳):**
> - FraudDetectionService: کلیدهای fraud_calculation_logs canonical (اثبات: ردیف nonzero با وزن‌های واقعی)
> - AnalyticsQueryService: users در summary (getUsersStats ناموجود حذف شد)
> - DirectMessageCommandService: unread پس از commit + recountUnreadFromSource (اثبات: drift ۹۹ → SET دقیق)
> - DirectMessageService: outbox واقعاً تزریق می‌شود (اثبات identity ===)
> - WebSocketService: claim صف delayed اتمیک با Lua — تست همزمانی واقعی ۵ پروسه × ۱۵۰ دور → دقیقاً ۴۰ تحویل، صفر دوبله
> - DashboardService: persist قبل از unlink (شکست → فایل حفظ می‌شود)
> - AlertDispatcher: push_alerts روی هر ۴ کانال (telegram/email/slack/webhook)
>
> **8-d — ویوها (۳۳ فایل: ۳۱ ادیت + ۲ partial جدید، php -l ۳۳/۳۳ clean):**
> - الگوی flash-consumed در ۱۰ ویو → استفاده از متغیرهای ازپیش‌استخراج‌شدهٔ view() ($flashError/$flashSuccess/$errors/$old) — بازپرکردن فرم roles/levels دوباره کار می‌کند
> - manual-deposits/review: دو هندلر JS به قرارداد واقعی کنترلر (POST /verify و /reject) وصل شد — تأیید/رد واریز دستی دیگر ۴۰۴ نیست
> - hidden-0 برای vitrine_enabled و بنر is_active → غیرفعال‌سازی اکنون ذخیره می‌شود
> - to_jalali روی اعداد → fa_number (crypto-deposits/manual-deposits/logs)
> - register.php: رندر مجاز HTML خطای سرور + verify-2fa: خروج POST با CSRF + social-accounts: دابل‌اسکیپ + vitrine/show: (بررسی شد درست بود) + tasks/feed: بج جعلی حذف + wallet: mock فقط غیر-production + prediction: وعدهٔ جعلی حذف + api-tokens: لینک به /help
> - partialهای جدید: views/admin/ads/partials/notification_detail.php + views/partials/pagination.php (ژنریک RTL با GET-preserve)
> - analytics/transactions: Chart.js محلی + نوارهای خالی seo-ad/notifications-stats/social-tasks×2 با width+ARIA
>
> **8-e — SQL/Schema (تست: tools/verify_fix8e.php = ۷۱/۷۱ PASS ×۳ + ۳ مایگریشن):**
> - مایگریشن‌های اعمال‌شده: 2026_09_20_0001_users_ban_columns.sql | 0002_daily_statistics_create.sql (هر دو کرون شبانه دیگر fail نمی‌کنند) | 0003_user_fraud_flags_unique_user.php (dedupe + UNIQUE)
> - ReferralManagementService SQL بک‌اسلش‌دار اصلاح؛ AdminCustomTaskService::getAdminStats fetchAll؛ RatingService → social_ratings (نویسندهٔ واقعی)؛ ScoreCommandService کف per-domain از ScoreDomainPolicy
> - CronService: purge با created_at + status='completed'؛ DashboardStatsService status='active'؛ ExportService نگاشت ENUM رشته‌ای کامل
> - MaintenanceService: پاک‌سازی ۲۱ نوع projection (قبلاً ۳) + 🛡️ اثبات delete دقیق orphanها با direct_message encoding
> - ویوها: custom-tasks (user_name/total_count/محاسبه site_fee)، banners/stats (نام/اسلاگ واقعی)، bug-reports (schema واقعی + ENUM labels)
> - 🛡️ نکته: بدنهٔ اصلی cron_alert_checker هنوز به ستون‌های شبح error_logs.is_resolved/... می‌خواند (خارج از اسکوپ ۱۵ یافته — برای دور بعد)
>
> **امکان جدید + استایل (main agent):**
> - API عمومی JSON وضعیت: GET /status/api (کنترلر StatusController::api — کش ۳۰ثانیه‌ای مشترک، Cache-Control + stale-while-revalidate، بدون اطلاعات حساس)
> - به‌روزرسانی زندهٔ صفحهٔ /status: polling ۶۰ثانیه‌ای با re-render امن (esc + Persian digits) + بج «زنده» با نقطهٔ pulse — fetch درون‌صفحه تست شد (overall/کارت‌ها آپدیت می‌شوند)
> - کارت‌های جدید Outbox و Saga/DLQ در /status (قبلاً این پروب‌ها در overall لحاظ می‌شدند ولی نامرئی بودند → overall=degraded با ۶ کارت ok — ناسازگاری حل شد)
> - 🛡️ بهره‌برداری عملیاتی: ۲۳۶ رویداد outbox pending انباشته (بدون کرون host در سندباکس) → outbox:publish اجرا شد (۲۵۷ منتشر شد) + ورکر دائمی /home/z/tools/outbox-worker.sh (هر ۶۰ثانیه، الگوی orphaned-daemon) — readiness حالا ok است
> - استایل سایت‌واید (shared/layout.css): اسکرول‌بار سفارشی webkit+Firefox (با تم تیره)، :focus-visible حلقهٔ طلایی (a11y کیبورد)، انیمیشن ورود flash/toast، hover elevation کارت‌ها، ::selection، hover ردیف جداول — با prefers-reduced-motion guard
>
> **راستی‌آزمایی مرورگری نهایی:** / , /login, /register, /status, /status/api, /health همه 200؛ ورود ادمین → داشبورد ادمین؛ admin/bug-reports و admin/custom-tasks با empty-state سالم (بدون SQL error)؛ fetch زندهٔ /status/api درون صفحه = ok/8 کارت

> ## ✅ وضعیت اصلاحات (به‌روزرسانی 2026-09-20 — دور ۴: معماری کرون/صف + باگ‌های کنترلری + PWA + استایل)
> **کشف اصلی QA:** کارگر صف و دیسپچر کرون در سندباکس هرگز اجرا نمی‌شدند — backlog صف ۶۴۹ جاب (LogPerformanceJob×۶۴۰ + ProcessNotificationJob). معماری صحیح پروداکشن: cron.php (dispatch) + queue:work (worker).
> - ورکرهای دائمی: /home/z/tools/scheduler-worker.sh (حلقه‌های cron.php هر ۶۰ثانیه + queue:work --limit=25 هر ۵ثانیه) + /home/z/tools/spawn-workers.sh (الگوی orphaned-daemon) + ثبت در start-services.sh — صف کاملاً تخلیه شد، همه‌ٔ کارهای Kernel (ایمیل/نوتیف/ساگا/کریپتو) اکنون زنده‌اند
> - FIX-QA4-1: Admin\ManualDepositController::review — TypeError «must be of type int, null given» روی card_id=NULL → HTTP 500 (تست مرورگری با ردیف موقت؛ صفر ردپا) + ستون شبح deposit_date (Warning رندر شده) → approved_at + مرجع غلط reference_number → tracking_code
> - FIX-QA4-2: بازپرکردن فرم ثبت‌نام — AuthController::register در هر ۴ شاخهٔ خطا فلش old (فیلدهای بی‌خطر) + CaptchaMiddleware::reject برای register (کپچا پیش از کنترلر است) — E2E مرورگری: پیام خطا + بازگشت نام/ایمیل/موبایل
> - FIX-QA4-3: cron_alert_checker از روز اول هرگز اجرا نشد — کلاس ErrorLogService ناموجود + namespace غلط LogNotificationService + ستون‌های شبح (is_resolved/occurrence_count/last_occurred_at/file_path/line_number → resolved_at/occurrences/updated_at/file/line) + $this->logger خارج از کلاس — اکنون سرتاسری سالم
> - استایل: صفحهٔ 404 دیباگ برندشد (تیره+طلایی+Vazirmatn با حفظ اطلاعات دیاگ) | اسکلتون شیمر + کامپوننت empty-box + ترنزیشن ورود صفحه در shared/layout.css (با گارد reduced-motion) | empty-box اعمال به bug-reports و custom-tasks
> - امکان جدید PWA: ۷ آیکون برند واقعی با GD (موتیف چرتکهٔ طلایی — جایگزین placeholder 1×1!) + manifest.json (فارسی/RTL/maskable) + wire در هر ۳ لایوت + theme-color یکسان طلایی #F0B90B

> ## ✅ وضعیت اصلاحات (به‌روزرسانی 2026-09-20 — دور ۲ فیکس)
> **همهٔ Highهای مالی/هویتی/تسکی/ارتباطی/زیرساختی فیکس و تست شدند:**
> - H-1: ReconciliationService علامت تراز لجر (credit−debit) + اصلاح SQL شکستهٔ reconcilePayment (LIMIT + placeholder تکراری) — تست: tools/verify_fix6a.php = ۲۵/۲۵ PASS
> - H-2: IDPayGateway نرمال‌سازی اعشار تومان (create+verify با scale 4) — همان فایل تست
> - H-3: WalletMutationService::reverseTransaction null-check + rollback — همان فایل تست
> - H-4: createOrphanTransaction با گارد isInternal برای استرداد رأی اختلاف (دیگر orphan_no_user کاذب نمی‌سازد) — همان فایل تست
> - H-9: UserService::changePassword → متد اتمیک User::changePassword (remember_token واقعاً null می‌شود) — تست: tools/verify_fix6b.php = ۳۶/۳۶ PASS
> - H-10: KYCCommandService ریت‌لیمیت 3600→60 دقیقه (پنجرهٔ واقعی ۱ ساعت) — همان فایل تست
> - H-11: sanitizeStoredFilename + FileController ویدئو mp4/webm/mov (serve به‌صورت attachment) — همان فایل تست
> - H-12: SocialTaskService::toggleAdStatus — مالک دیگر pending_review را activate نمی‌کند — تست: tools/verify_fix6c.php = ۲۸/۲۸ PASS
> - H-13: AdSystemManager::toggleAdStatus — whitelist وضعیت‌های زنده (bypass همهٔ انواع تبلیغ بسته شد) — همان فایل تست
> - H-15: forceRejectSubmissionByAdmin — پس‌گرفتن پاداش escrow + کاهش completed_count در یک تراکنش — همان فایل تست
> - H-16: updateBugReportStatus/Priority جدید → جدول bug_reports (تیکت هم‌id دیگر خراب نمی‌شود) — تست: tools/verify_fix6d.php = ۴۲/۴۲ PASS
> - H-17: Notification::create ستون scheduled_at را INSERT می‌کند + گیت ۵ کوئری خواندن — همان فایل تست
> - H-18: XSS تصویر گزارش باگ — validateScreenshotPath در API + سرویس + ویو ادمین با e() — همان فایل تست
> - H-22: FeatureFlagService ستون‌های canonical enabled_for_* + allowlist ادمین — تست: tools/verify_fix6e.php = ۲۵/۲۵ PASS
> - H-23: UserSearchProvider در AppServiceProvider ثبت شد + hasProvider ضدتکرار — همان فایل تست
> - H-24: Queue::popSingleQueue نام صف واقعی را برمی‌گرداند → heartbeat درست — همان فایل تست
>
> **فیکس محیطی بحرانی (استایل کل سایت):** dev-router.php — درخواست‌های /chortke/assets/* به‌خاطر APP_BASE_PATH به front controller می‌رسیدند و ۲۰۰ خالی با text/html برمی‌گشتند → هیچ CSS/JS/فونتی در مرورگر لود نمی‌شد. حالا مسیر بدون base-path هم امتحان می‌شود (هم‌تراز nginx). صحت‌سنجی مرورگری: صفحهٔ اصلی + /status + ادمین کاملاً استایل‌دار.
>
> **امکان جدید:** صفحهٔ عمومی «وضعیت سیستم» (/status) — کنترلر StatusController با کش ۳۰ثانیه‌ای + ویو تیرهٔ RTL + کارت‌های ۶ سرویس + لینک فوتر با نقطهٔ زنده.
>
> **استایل:** ۸ نوار پیشرفت در ۷ ویوی analytics ادمین width + ARIA گرفتند (قبلاً خالی رندر می‌شدند).
>
> **دور بعد (پیشنهادی):** شروع Mediumها (۹۱ مورد) — اولویت: H-5 double-verify ادمین (needs verification)، ریت‌لیمیت‌های ۳۶۰۰/۸۶۴۰۰ باقیمانده در Contact/Ticket/Export/2FA (همان الگوی H-10)، video inline player policy، ستون‌های targeting قدیمی targeted_* (حذف با مایگریشن).

> ⚠️ FIX#0 (bring-up — قبلاً اعمال شد): `app/Models/SentryModel.php` — پیاده‌سازی متد گمشده `deleteAuditRecordsByIds` از اینترفیس `SentryAuditRepositoryInterface` (Fatal error جلوی بوت کل سایت بود)

---

## 🔴 CRITICAL (۳ مورد — قطع سرویس یا ضرر مالی مستقیم)

### C-1. ایمیل‌های صف‌شده همیشه دوبار ارسال می‌شوند
- **فایل:** `app/Services/EmailDeliveryStore.php:97-138`
- **مشکل:** `save()` یک uniqid (`email_66f...`) می‌سازد و برمی‌گرداند، اما `saveToDatabase()` ردیف DB با `lastInsertId` عددی می‌سازد و id دور ریخته می‌شود. `updateStatus()` فقط برای id عددی UPDATE می‌زند → وقتی job از مسیر Redis-meta ارسال می‌کند، ردیف DB در `pending` می‌ماند → کرون `email_queue` دقیقه بعد همان را دوباره claim و **دوباره می‌فرستد**. قفل‌های دو مسیر هیچ هم‌پوشانی ندارند.
- **اصلاح:** `saveToDatabase()` باید id عددی DB را برگرداند و به payload job تزریق شود؛ `markAsSent/markAsFailed` همیشه ردیف DB را هم ببندند.

### C-2. بن‌بست ابدی پرداخت‌های pending_verification — پول کاربر در درگاه گیر می‌کند
- **فایل:** `app/Services/Payment/PaymentAdminService.php:60-103` + `app/Services/Payment/PaymentCommandService.php:605-609`
- **مشکل:** وریفایِ ناموفقِ درگاه → وضعیت `pending_verification` با وعدهٔ «۲۴ ساعت». اما `manuallyVerifyPayment` دوباره از `callback()` می‌گذرد و `checkPaymentIntegrity` گات سخت ۷۲۰۰ ثانیه‌ای (۲ ساعت) دارد. کرون (Console/Kernel.php:115) تا ۲۴ ساعت retry می‌کند ولی همهٔ تلاش‌ها بعد از ۲ ساعت با پیام «زمان مجاز به پایان رسیده» رد می‌شود. هیچ مسیر بازیابی‌ای وجود ندارد.
- **اصلاح:** برای وضعیت `pending_verification` گات انقضا بر اساس `paid_at` (مثلاً ۲۵ ساعت) یا مستثنا کردن این وضعیت.

### C-3. فراخوانی کلاس ناموجود در صفحه اختلاف‌ها → Fatal Error
- **فایل:** `views/user/disputes/index.php:165`
- **مشکل:** `\Core\Helpers\PersianDate::toPersian()` هیچ‌جا تعریف نشده (کلاس موجود: `\Helpers\JalaliDate` و هلپر `to_jalali()`). با اولین پروندهٔ اختلاف، صفحه ۵۰۰ می‌شود.
- **اصلاح:** جایگزینی با `to_jalali($d->updated_at)`.

---

## 🟠 HIGH (۳۸ مورد)

### مالی و پرداخت (۵)
1. **[app/Services/ReconciliationService.php:615-636]** علامت محاسبه تراز لجر در `verifyConsistency` معکوس است (`debit−credit` به‌جای `credit−debit`) → کنترل مالی برای هر کیف غیرصفر همیشه fail؛ کرون برای هر پرداختِ موفق هشدار کاذب صادر می‌کند.
2. **[app/Services/Payment/IDPayGateway.php:79-98,252-272]** قطع اعشار تومان (`bcdiv(...,'10',0)`) → کاربر مبلغ کسری می‌پردازد، وریفای با mismatch رد و پول در درگاه می‌ماند. باید `normalizePositiveTomanAmount` مثل بقیه درگاه‌ها اعمال شود.
3. **[app/Services/Wallet/WalletMutationService.php:1223-1251]** `reverseTransaction` نتیجه `createTransaction` را null-check نمی‌کند → برگشت پول بدون ردیف تراکنش (نقض الگوی S4-M1).
4. **[app/Services/ReconciliationService.php:290-316]** تطبیق داخلی استرداد رأی اختلاف همیشه در `orphan_no_user` شکست می‌خورد (`user_id` عمداً null می‌شود ولی گارد null را reject می‌کند).
5. **[app/Services/Payment/PaymentAdminService.php:74-94]** (نیازمند تأیید) double-verify در تأیید دستی — NextPay/DgPay ممکن است وریفای تکراری را reject کنند و پرداخت درست به failed فلیپ کند.

### هویت/احراز هویت (۶)
6. **[app/Services/KYC/KYCCommandService.php:360]** فراخوانی `NotificationService::kycVerified()` که حذف شده → بعد از commit، Error → به ادمین «خطای سیستمی» و اعلان کاربر هرگز ارسال نمی‌شود.
7. **[app/Services/KYC/KYCCommandService.php:436]** همان مشکل با `kycRejected()` در `reject()`.
8. **[app/Services/Auth/TwoFactorService.php:346]** فراخوانی `securityAlert()` ناموجود، خارج از try/catch → ۵۰۰ برای کاربر بعد از قفل حساب.
9. **[app/Services/User/UserService.php:196-212]** `changePassword` ستون‌های `remember_token/remember_expires_at` را پاس می‌دهد ولی در `User::$fillable` نیستند → کوکی remember مسروقه بعد از تغییر رمز همچنان معتبر می‌ماند (H-03 شکسته).
10. **[app/Services/KYC/KYCCommandService.php:92]** `attempt(..., 2, 3600)` — واحد RateLimiter دقیقه است → پنجره واقعی ۶۰ ساعت نه ۱ ساعت؛ کاربر عملاً ۲ بار در ۲.۵ روز فرصت ثبت KYC دارد.
11. **[app/Services/UploadService.php:566]** `sanitizeStoredFilename` ویدئو را قبول نمی‌کند ولی `uploadPrivateDocument` ویدئوی task-proof ذخیره می‌کند → ویدئوی اثبات تسک هرگز قابل مشاهده/حذف نیست (orphan دائمی).

### تسک‌ها/تعامل (۴)
12. **[app/Services/SocialTask/SocialTaskService.php:795-819]** دور زدن تأیید ادمین — مالک کمپین با `resumeUserAd` کمپین `pending_review` را خودش activate می‌کند و `reviewed_by` آیدی خودش ثبت می‌شود.
13. **[app/Services/AdSystemManager.php:723-734]** همان bypass برای همه انواع تبلیغ از `AdsController::toggleStatus` (مسیر زنده).
14. **[app/Services/Gamification/TrustService.php:131-136]** کوئری ستون‌شبح (`user_id`, `score` در `social_task_executions`) → SQLSTATE 42S22 → بازیابی هفتگی اعتماد هرگز اجرا نمی‌شود.
15. **[app/Services/CustomTask/AdminCustomTaskService.php:447-491]** `forceRejectSubmissionByAdmin` وضعیت `approved` را می‌پذیرد بدون بازگشت پاداش/کاهش completed_count → ناهم‌خوانی دفتر/پول.

### ارتباطات/پشتیبانی (۳)
16. **[app/Services/TicketService.php:221-235]** تغییر وضعیت/اولویت «گزارش باگ» روی جدول `tickets` می‌نویسد نه `bug_reports` → وضعیت هرگز عوض نمی‌شود و تیکت هم‌idِ کاربر دیگر خراب می‌شود.
17. **[app/Models/Notification.php:63-85]** ستون `scheduled_at` هرگز INSERT نمی‌شود → DND و ارسال زمان‌بندی‌شده کاملاً شکسته؛ گیت unread-counter هم رد می‌شود → بج نخوانده کهنه.
18. **[app/Services/TicketService.php:397-427 + app/Controllers/Api/UserController.php:431-437]** Stored XSS در پنل ادمین: مسیر API فیلد `screenshot_path` را بدون اعتبارسنجی می‌پذیرد و ویو `views/admin/bug-reports/show.php:69-70` آن را بدون `e()` در href/src چاپ می‌کند.

### Sentry/AntiFraud (۳)
19. **[app/Services/Sentry/Alerting/EscalationManager.php:37-83]** حلقه بی‌پایان re-escalation — هر ۵ دقیقه برای ایسوی acknowledge‌نشده الرت جدید + ردیف جدید؛ رشد بی‌کران.
20. **[app/Services/Sentry/Audit/AdvancedAuditTrail.php:89-91]** فیلتر category به ستون ناموجود `audit_trail.category` → خطای SQL و ۵۰۰ در پنل ادمین با `?category=...`.
21. **[app/Services/AntiFraud/GeolocationIntelligenceService.php:239-257]** SELECT بدون `latitude/longitude` → سیگنال geo-velocity عملاً مرده (همه سرعت‌ها صفر) + سیل warning.

### زیرساخت (۳)
22. **[app/Services/FeatureFlagService.php:221-262]** ناهم‌خوانی ستون‌های targeting (`targeted_*` خوانده می‌شود، `enabled_for_*` نوشته می‌شود) → فلگ «فقط ادمین» برای همه فعال است.
23. **[app/Providers/AppServiceProvider.php:232-243]** فقط `AdminSearchProvider` ثبت شده → جستجوی سمت کاربر همیشه خالی (`UserSearchProvider` هرگز wire نمی‌شود).
24. **[app/Services/QueueWorker.php:177]** heartbeat با نام صف اشتباه (`'default'` همیشه، چون `pop()` کلید queue برنمی‌گرداند) → jobهای طولانی پس از visibility_timeout دوباره pop و مثلاً ایمیل دوبله.

### ویوها (۱۱)
25. **[views/user/ads/show.php:355]** Chart.js از CDN مسدود-CSP → نمودار عملکرد هرگز رندر نمی‌شود (asset محلی موجود است).
26. **[views/user/dashboard.php:630]** لینک مرده به `/advertiser` (404) — باید `/ads` باشد.
27. **[views/user/dashboard.php:708]** لینک مرده به `/tasks/history` (404).
28. **[views/admin/users/index.php:163-187]** دکمه‌های بن/تعلیق/حذف به روت‌های ناموجود POST می‌زنند (`/admin/users/ban/{id}` به‌جای `/admin/users/{id}/ban`) → هر سه 404.
29. **[views/admin/withdrawals/index.php:141]** لینک «بررسی» به `/admin/withdrawals/{id}` که وجود ندارد → 404.
30. **[views/admin/withdrawals/review.php:91-101]** دکمه‌های تأیید/رد به توابع JS ناموجود (`doApprove/doReject`) → صفحه بررسی هیچ اکشنی ندارد.
31. **[views/admin/vitrine/index.php:182-206]** چهار اکشن ادمین (تایید/رد/آزادسازی/استرداد) به توابع IIFE-scoped اشاره می‌کنند که به `window` وصل نیستند → همه مرده.
32. **[views/admin/vitrine/dispute.php]** المان bootstrap `#vitrine-dispute-data` هرگز رندر نمی‌شود → POST به `/admin/vitrine/undefined/resolve` → 404.
33. **[views/welcome.php:265-377]** چهار لینک صفحه اصلی به روت‌های ناموجود (`/story-orders`, `/seo-tasks`) → 404.
34. **[views/admin/audit-trail/show.php:4]** کنترلر متغیر را `event` می‌فرستد، ویو `$record` می‌خواند → همیشه «رکورد یافت نشد».
35. **[views/admin/login.php:55-60]** پیام خطای ورود ادمین هرگز نمایش داده نمی‌شود ( `$flashError` مصرف‌شده قبل از include؛ ویو کلید `errors` را می‌خواند که ست نمی‌شود) → شکست لاگین ادمین بی‌صدا.

---

## 🟡 MEDIUM (۹۱ مورد — خلاصه دسته‌بندی‌شده)

### واحد پنجره RateLimiter/Cache (باستان سیستمی — ۸ مورد)
واحد decay در `core/RateLimiter` دقیقه است ولی چند سرویس ثانیه فرض کرده‌اند:
- `TicketCommandService.php:107,224` (۳۶۰۰→۶۰ ساعت بلاک)، `ContactService.php:66-163` (۸۶۴۰۰→۶۰ روز!)، `TwoFactorService.php:51` (300→۵ ساعت)، `UserSettingsService.php:94,149` (کش ۶۰ ساعت)، `UserDashboardService.php:321,378` (آمار مالی تا ۶۰ دقیقه کهنه)، `NotificationPreferenceService.php:40,68` (TTL ۳۰۰ دقیقه)، `CacheManager::set` گرد کردن TTL زیردقیقه‌ای به ۶۰ ثانیه، `AppServiceProvider` رجیستر.

### SQL/Schema mismatch (۱۵ مورد)
- `ReferralManagementService.php:250-263` بک‌اسلش ادامه‌خط در SQL → خطای 1064 به‌محض اتصال UI.
- `UserService.php:239-255` ستون‌های `ban_reason/banned_at` ناموجود → ذخیره بی‌صدا از بین می‌رود.
- `AdminCustomTaskService.php:494-513` `fetch` روی GROUP BY → فقط یک وضعیت در آمار.
- `RatingService.php:34-93` صف نظرات ادمین جدول `ratings` را می‌خواند که هیچ نویسنده‌ای ندارد.
- `ScoreCommandService.php:186-217` کف ۰ برای همه دامنه‌ها → هشدار trust.critical_drop غیرقابل‌وقوع.
- `daily_statistics` جدولش هرگز ساخته نشده (cron sentry-monitor + cron_alert_checker شبانه fail).
- `CronService.php:120-129` DELETE روی `expires_at` ناموجود در `password_resets` → توکن‌ها هرگز پاک نمی‌شوند.
- `CronService.php:181-188` `status='success'` به‌جای `'completed'` → حجم تراکنش ~۰.
- `DashboardStatsService.php:412` `status = 1` روی ENUM رشته‌ای → همیشه ۰.
- `ExportService.php:201-212` نگاشت عددی وضعیت روی ENUM رشته‌ای → همه «غیرفعال».
- `VelocityAndScoreModel.php:620-679` `user_fraud_flags` بدون UNIQUE(user_id) → ON DUPLICATE هرگز fire نمی‌شود، رشد بی‌کران.
- `MaintenanceService.php:331-350` پاک‌سازی projectionها فقط ۳ نوع از ۱۹ نوع واقعی.
- `views/admin/custom-tasks/index.php:70-72` ستون‌های `total_quantity/site_fee_amount/creator_name` ناموجود در جدول ads.
- `views/admin/banners/stats.php` ستون‌های `title/page/max_banners/dimensions` ناموجود در banner_placements.
- `views/admin/bug-reports/*` چند ستون/متغیر ناموجود (`title/user_name/full_name/priority_label/...`).

### امنیت (۷ مورد)
- `VerificationService.php:343-368,622-654` SSRF نیمه‌کور (localhost در allowlist + دنبال‌کردن ریدایرکت بدون اعتبارسنجی).
- `CaptchaService.php:339-341` ورودی کلاینت‌کنترل `events` بدون گارد → TypeError → ۵۰۰.
- `BannerService.php:222-233` whitelist ریدایرکت شامل دامنه‌های placeholder.
- `EmailService.php:135-138,517-540` log-injection در MAIL_DRIVER=log (قبل از اعتبارسنجی، بدون حذف CRLF).
- `AdminCustomTaskService.php:361-444` TOCTOU در forceApprove (گارد قبل از beginTransaction/lock).
- `Influencer/InfluencerCommandService.php:1255-1289` `rateInfluencer` بدون گارد مالکیت/وضعیت.
- `views/admin/notifications/index.php` sanitize_url خروجی `#` برای URLهای نسبی + توابع IIFE + روت delete ناموجود.

### منطق/مالی (۱۶ مورد)
- `ScheduledPaymentService.php:141-171` وارونگی ترتیب قفل (DB→Redis برخلاف همه مسیرها) → stall تا ۱۰ ثانیه.
- `IdempotencyKey.php:249,461-464` rollback در سطح تراکنش بیرونی از داخل helper.
- `InfluencerCommandService.php:570-609` اول status بعد refund بدون try/catch → سفارش گیر می‌کند؛ همان در cron خط ۱۰۵۴-۱۰۶۶.
- `AdNotificationDispatcher.php:148-196` نادیده گرفتن `units` بودجه‌خورده → ارسال ۱۰۰ نوتیف با شارژ ۶۰ واحد.
- `DisputeCommandService.php:236-289` `resolveByAgreement` بدون تسویه escrow → پول معلق تا مداخله ادمین.
- `SocialTaskService.php:680-689` `processAutoApprovals` تأیید بدون پرداخت (dead code ولی تله).
- `FraudDetectionService.php:183,209-217` mismatch کلیدها → fraud_calculation_logs همیشه صفر.
- `AnalyticsQueryService.php:224-240` سکشن users هرگز در summary نیست (`getUsersStats` vs `getUserStats`).
- `DashboardService.php:416-419` حذف فایل لاگ اضطراری قبل از persist موفق → از دست رفتن رخدادها.
- `AlertDispatcher.php:97-113` toggle push_alerts فقط در Telegram اعمال می‌شود.
- `QueueWorker` heartbeat — بالا ذکر شد.
- `DirectMessageCommandService.php:219-330` drift همیشگی شمارنده unread + del داخل تراکنش قبل از commit.
- `DirectMessageService.php:34-36` آرگومان هفتم `$outbox` به سازنده ۶ پارامتری → بی‌صدا حذف.
- `WebSocketService.php:310-343` claim غیراتمیک صف delayed → پیام مضاعف.
- `EmailService.php:297-331` `processQueue` درایور log را رد می‌کند → fail بی‌صدا در dev.
- `CacheManager::increment` false→0 → گارد fail-closed سقف کمیسیون و قفل اکانت پس از ۱۰ خطا مرده.

### ویوها (۳۰ مورد) — شامل:
- الگوی flash-consumed در ۹ ویو (reset-password, oauth-confirm, verify-2fa ادمین, referral/settings, risk-policies, roles×3, levels×3) → پیام‌ها هرگز دیده نمی‌شوند.
- `$old = getFlash('old')` بعد از مصرف → بازپرکردن فرم کاملاً از کار افتاده (roles/create|edit, levels/create|edit).
- روترهای 404: `/admin/users/show/{id}` (fraud/logs, fraud/reports)، `/admin/coupons/details|edit?id=`، `/admin/kyc/{id}`، `/admin/logs/alerts|performance`، `/admin/users/view/{id}`، `/admin/users/{id}` (investment/withdrawals).
- manual-deposits/review: POST به `/admin/manual-deposits/{id}/approve` ناموجود → تأیید/رد واریز دستی 404.
- تنظیمات: `vitrine_enabled` بدون hidden-0 → غیرفعال‌سازی ویترین غیرممکن؛ `is_active` بنر با default=1 → غیرفعال‌سازی ذخیره نمی‌شود.
- templates ایمیل: `account-locked` غایب → ایمیل هشدار قفل حساب با بدنه placeholder.
- paginate: `$total = count($deposits)` صفحه‌بندی manual-deposits را کلاً از کار می‌اندازد؛ influencer×4 بدون UI صفحه‌بندی.
- `to_jalali($عدد)` روی اعداد (crypto-deposits, manual-deposits, logs) → ۱۹۷۰/۰۱/۰۱ یا خالی.
- `views/user/register.php` پیام خطا HTML→dable-escape + از بین رفتن old input.
- `views/user/security/verify-2fa.php` لینک GET به `/logout` (روت فقط POST).
- `views/user/social-accounts/index.php` دابل‌اسکیپ مارک‌آپ آیکون.
- `views/user/vitrine/show.php` دکمه‌های آزادسازی وجه خارج از گارد in_escrow.
- `views/user/tasks/feed.php` نشان «اعتماد» جعلی از ایندکس آرایه.
- `views/user/wallet/index.php` گزینه mock درگاه برای همه کاربران.
- `views/user/prediction/index.php` وعدهٔ جعلی «پیش‌بینی بدون کارمزد» بدون wiring سرور.
- logs/index همیشه خالی (کنترلر لاگ نمی‌فرستد)؛ kpi progress-bar بدون width؛ analytics/transactions بدون Chart.js؛ ads/show partial ناموجود notification_detail؛ features/modal ناموجود + filterType mismatch؛ email-queue pagination partial ناموجود.
- `views/user/api-tokens/index.php` لینک `/api/v1/docs` 404.

---

## 🟢 LOW (۹۰ مورد — خلاصه) — ~۱۱ مورد کاربرمواجه در دورهای ۱۱-۱۳ بسته شد (جزئیات در بلوک دور ۱۳ بالای فایل)
- Dead-code/اوراکل‌های گمراه‌کننده: `getPendingCryptoDeposits($hours)` بدون استفاده، `deleteOldSessions` روی جدول ناموجود sessions، `getLowTrustUsersForAdmin` مقادیر ساختگی، `getTrustStatsForAdmin` توزیع ساختگی، `reportTask` stub، `rateTask` گم‌کردن کامنت، `estimateReach` تقسیم بر صفر بالقوه، `executePaymentSaga` شاخه مرده، `tryAutoVerify` نوشتن شمارنده در transaction_id، `getAllowedChannels` کانال email بدون هندلر، `image_url` کلید بی‌مقصد، SchemaInspector نقشه FULLTEXT غلط برای ۲۳ جدول، `crc32` به‌جای entity_id در projection، `escrow` نگاشت دو-جدولی، wildcard LIKE بدون escape (quickSearchTickets, escape دوبله در Search)، cleanupOldFiles فقط ۳ روز، cancelWithdrawal/finalizeLockedSpend… 
- رابط کاربری: `$pageTitle` به‌جای `$title` (bank-cards, crypto-deposit, features)، آیکون FontAwesome بدون لود فونت (coupons/history, settings×3)، progress-bar خالی (analytics×7, notifications/stats, seo-ad, social-tasks×2)، `data-action="__reload/__back"` روی صفحات خطا بدون JS، require_once دوباره لایوت (tickets/show, transactions, users, kyc×2)، دکمه Excel به صفحه هاب به‌جای دانلود، تگ دکمه toggle-password ناقص (reset-password)، attribute class تکراری (roles/create|edit)، لینک مطلق به‌جای url() (messages/index, sentry-widget)، ایمیل هاردکد support@chortke.com (errors/503)، فوتر عمومی داخل لایوت ادمین (social-tasks×2)، page-highlight با نام متغیر غلط (bug-reports)، off-by-one صفحه‌بندی (social-tasks/rating-reviews)، قالب lottery-winner بدون مصرف + ایمیل‌ها بدون <style>، `verify-email.php` نادیده گرفتن resend_mode، `country_flag` ذخیره‌نشدن، `unique` نبودن username در RegisterRequest، fallback تاتولوژی get_client_ip، SessionService آستانه anomaly ناسازگار، LEFT JOIN→INNER (referral)، adjustQualityScore int-truncate، ProfileService کش هرگز init نمی‌شود، kyc فایل‌های یتیم پس از resubmit، AccountDeletion ناسازگاری وضعیت، SocialAccountService reject بدون گارد وضعیت، MetricsCollector timing غیراتمیک، AnalyticsService فرمول uptime غلط، disk_total_space false → تقسیم بر صفر، circuit breaker counter بدون TTL، SentryErrorMonitor UNIQUE(fingerprint) بدون environment، getErrorTimeSeries نادیده گرفتن interval، unique_categories/actor_email همیشه خالی، AlertsEngine فرمت condition مبهم، dispatch true حتی در fail کامل، BehavioralBiometrics گارد نداشتن کلیدها، SeoFraudDetector throw به‌جای degrade، FraudGuardService action خارج قرارداد، BulkOperations rollback محافظت‌نشده + clearCache('*') بدون گارد production، CouponService getRedemptions نادیده گرفتن limit/offset + مصرف توکن قبل از کار DB، PerformanceOptimizationService rollback در catch، کرون‌های هیچ‌جا wire نشده (sentry-monitor rules engine)، SentryModel — handled، الگوهای BS4 روی BS5 در fraud×3، `filterType` mismatch در featuresindex.js، `direction` فیلتر مرده (investment/trades)، ALL withdrawals در investment/show، `full_name` vs `user_name` (investment/withdrawals)، search گم‌شده در paginate (investment/index)، kyc search دابل‌اسکیپ + گم‌شدن در paginate، JSON bootstrap بدون nonce + depth اشتباه (tickets/show)، `deposit_date` ناموجود (manual-deposits/review)، JSON خام پس از POST (messages/report-detail)، `function_exists ? f : f` متناقض (influencer×4)، Logout GET pattern، mock option — و موارد جزئی دیگر.

---

## ✅ نواحی سالم (بررسی شد — بدون باگ)
- WalletService/WalletMutationService (قفل FOR UPDATE + CAS + idempotency + لجر دوقلمونی)، Withdrawal services، BankCardService (Luhn/IBAN/رمزنگاری PAN)، EscrowService، CryptoDepositService، InvestmentCommandService، ManualDepositService
- UploadService لایه‌های دفاعی کامل؛ TwoFactorService TOTP ضد-replay؛ QueryBuilder::count؛ CSRF روی POSTهای auth
- PHPMailer v7.1.1 استفاده صحیح؛ LogService PSR-3؛ LIMIT/OFFSET bind امن؛ گیت‌های IDOR تیکت/DM/WebSocket
- BackupService/OffsiteBackupService/MigrationService/OutboxPublisher/DistributedLockService/QueueWorker-retry/ReferralService/IdempotencyKeys
- لایوت‌ها و partialهای اصلی؛ ماژول prediction/sentry/social-accounts/settings/seo-ad؛ صفحات خطا بدون نشت stack trace؛ test-captcha فقط در غیر-production رجیستر می‌شود

## 🎯 پیشنهاد اولویت اصلاح
1. **Critical ×3** (ایمیل دوبله، بن‌بست pending_verification، Fatal اختلاف‌ها)
2. **Highهای مالی** (لجر معکوس، IDPay اعشار، reverseTransaction، bypass تأیید ادمین ×2)
3. **Highهای هویت** (kycVerified/kycRejected/securityAlert ناموجود، remember-token، ریت‌لیمیت KYC)
4. **باستان واحد RateLimiter/Cache** (۸ مورد — یک fix محدود چند نقطه را حل می‌کند)
5. **ویوهای ادمین مرده** (الگوی JS-window + flash-globals + روت‌های 404 — مستقیماً عملیات مالی ادمین را از کار انداخته)
6. Medium/Low به ترتیب دسته‌ها

---

## ✅ دور ۱۰ (2026-09-20 — QA مرورگری + رفع باگ‌های زنده + پولیش/امکانات)

**روش:** QA مرورگری کامل با agent-browser (مهمان + کاربر + ادمین) → کشف باگ‌های زنده → فیکس با اثبات مرورگری/CLI → پولیش استایل + امکانات جدید الزامی راند.

### فیکس‌شده در این راند:
1. **FIX-QA5-1 — آمار «همیشه صفر» صفحهٔ اصلی (Medium/Viw+Service):**
   - `HomeController::index` با آرگومان روی `getDashboardSummary()` صدا می‌زد که امضایش بدون آرگومان است و کلیدهای خروجی‌اش (`key_kpis`/`kyc_completion_rate`) هیچ‌مانندی از کلیدهای انتظاری (`users.total`/`tasks.total_completed`) نبود.
   - بدتر: ویو `views/welcome.php` عدد را هاردکد «0» رندر می‌کرد و `data-target` را هیچ JSی مصرف نمی‌کرد → حتی با دادهٔ واقعی هم بازدیدکننده صفر می‌دید.
   - فیکس: تزریق `AnalyticsService` به‌جای `AnalyticsQueryService` (متدهای متریک واقعی: `getUserMetrics/getTaskMetrics/getTransactionMetrics/getLotteryStats`) + افزودن کلید `completed_total` به `KpiStatistics::getTaskStats` و `completed_rounds` (دوره‌های completed با `winner_user_id`) به `getLotteryStats` + رندر SSR عدد واقعی با `fa_number` در ویو.
   - اثبات: CLI-probe `tools/qa5_stats_probe.php` (users total=5 active=5) + مرورگر: `data-target="5"` و شمارندهٔ انیمیت‌شونده «۵».
2. **FIX-QA5-2 — صفحهٔ قرعه‌کشی ۵۰۰ (Regression از FIX-S18-6F):**
   - `LotteryService` پارامتر آخرش «?OutboxServiceInterface» بود ولی `LotteryCommandService` آرگومان یازدهم را «?NotificationServiceInterface» می‌خواهد → TypeError در زمان اجرا → «خطای سیستمی».
   - فیکس: تایپ‌هینت به قرارداد درست برگشت (`NotificationServiceInterface` — singleton در AppServiceProvider:115)؛ اثبات: مرورگر title «قرعه‌کشی» به‌جای خطا.
3. **FIX-QA5-3 — کرون alert_rule_engine هر دقیقه fail می‌شد (رشد بی‌وقفهٔ DLQ):**
   - Kernel تابع کرون `AlertDispatcher::processRules()` را صدا می‌زد که وجود ندارد → جاب هر ~۱ دقیقه در failed_jobs می‌افتاد (۲۹ ردیف در ~۲۵ دقیقه) → کارت Saga/DLQ در /status = degraded.
   - فیکس: فراخوانی `AlertRulesEngine::evaluateAllRules()` (موتور واقعی قوانین) + پاک‌سازی ۲۹ ردیف کهنه با `queue:failed forget` (مسیر ادمینِ خود اپ) → /status/api = overall ok، ۸/۸.
4. **FIX-QA5-4 — OOM مرگ‌آور سرور PHP (۱×رخداد زنده):**
   - رخداد: `Allowed memory size of 134217728 bytes exhausted` + پکت ۶.۶MB خراب MySQL → مرگ کامل php -S 3001 → همهٔ صفحات ۵۰۰.
   - فیکس زیرساختی: `memory_limit=256M` برای سرور dev + سوپروایزر `/home/z/tools/php-supervisor-3001.sh` (بررسی سلامت هر ۵ثانیه، ری‌استارت خودکار ≤۹ثانیه — تست kill/restore: PASS) + رفع باگ `start-services.sh` که «exit 0» وسط فایل باعث می‌شد بخش ۶ به بعد (workers) هرگز از آن اجرا نشود.

### رفع‌شده از لیست یافته‌ها در این راند:
- قالب ایمیل `account-locked` (views/emails/account-locked.php) ساخته شد — با اسکیپ XSS و همین قرارداد vars (name/ip/time/security_url)؛ تست CLI: رندر OK + XSS-escape OK.

### استایل (الزامی راند):
- شمارندهٔ آمار hero: خروجی با ارقام فارسی + جداکنندهٔ هزارگانِ فارسی (٬) هماهنگ با سایت؛ گارد prefers-reduced-motion.
- ورود پلکهای (stagger) کارت‌های صفحهٔ اصلی + گارد reduced-motion + پاک‌سازی transitionDelay پس از ورود.
- جدول‌ها: `font-variant-numeric: tabular-nums` برای هر دو سیستم (.table و bx-table) + سرستول جمع‌وجورتر + utility چسبان `.table-scroll` / `.bx-table-scroll`.
- حالت چاپ سایت‌واید (بدون سایدبار/تاپ‌بار/فوتر/دکمه‌ها) برای خروجی گزارش تمیز.

### امکانات جدید (الزامی راند):
- **Pill زندهٔ وضعیت سیستم در فوتر** (`shared/footer-status.js`): fetch به /status/api (کش ۳۰ثانیه‌ای سرور + sessionStorage ۳۰ثانیه‌ای کلاینت)؛ حالت‌های operational/degraded/down با رنگ سبز/کهربایی/قرمز + aria-live؛ شکست fetch بی‌صدا.
- **دکمهٔ بازگشت به بالا** سایت‌واید (`shared/ux-extras.js`): ظهور بعد از ۶۰۰px، اسکرول نرم، گارد reduced-motion، ناحیهٔ لمسی ۴۴px.
- **بنر قطع اتصال اینترنت**: رویدادهای online/offline مرورگر، بدون polling.
- **کلید میان‌بر «/»** در پنل: باز کردن + فوکوس جستجوی سریع هدر (الگوی GitHub/YouTube).
- wire در هر ۳ لایوت (guest/user/admin) با nonce.

### ریسک/باقیمانده برای راند بعد:
- منشأ کوئری ۶.۶MB/OOM مشخص نشد (لاگ فقط fatal را نشان می‌دهد) — توصیه: فعال‌کردن slow-log MariaDB یا Sentry breadcrumb برای گرفتن کوئری سنگین؛ supervisor الان از مرگ سایت جلوگیری می‌کند ولی علت حل نشده.
- H-5 همچنان نیازمند درگاه واقعی؛ ~۹۰ Low باز است.
- session ادمین/کاربر در محیط dev زود از بین می‌رفت (چند بار re-login در QA) — بررسی session lifetime پیشنهاد می‌شود.
- ۵ «کاربر فعال» در آمار = ۵ کاربر seed؛ با رشد داده، صحت شمارنده‌ها را دوباره چک شود (completed_total فقط ads را می‌شمارد، نه custom_task_submissions).

## ✅ دور ۱۱ (2026-09-20 — E2E ثبت‌نام/تأیید/ورود + لینک‌های مردهٔ باقیمانده + Dev Mailbox + پولیش)

**فیکس‌شده از لیست یافته‌ها:**
- لینک‌های مردهٔ ادمین (بخش ویوهای دور ۳ — ۸ مورد در ۶ فایل): `users/show|view/{id}` → `users/{id}/edit` (fraud/logs، fraud/reports، logs/error-details) | `coupons/details?id` و `coupons/edit?id` → `admin/coupons/{id}` و `{id}/edit` (coupons/index، coupons/details) | `logs/alerts` و `logs/performance` → `sentry/alerts` و `sentry/performance` (logs/dashboard ×۳)
- LOW «تگ دکمهٔ toggle-password ناقص (reset-password)» — هم‌خانواده: دکمهٔ نمایش رمز کامل با آیکون متغیر در register پیاده شد (reset-password در دور بعد چک شود)

**کشف/رفع فراتر از لیست:**
- MAIL_DRIVER=smtp در سندباکس → ایمیل‌های حیاتی (sendDirect) بی‌صدا شکست می‌خوردند → سوییچ به log (درایور آمادهٔ دور 8-b) + اثبات E2E
- COEP: credentialless سراسری → کوکی‌ها از ناوبری iframe حذف → هر iframe احراز-هویت‌شده‌ای می‌شکند (بدنهٔ ایمیلmailbox با الگوی srcdoc دور زده شد — سایر iframeها باید اسکن شوند)
- A11Y: transform-only hiding بنر آفلاین و back-to-top در a11y tree می‌ماند → visibility:hidden
- آفست ایندکس mail.log در خواندن (off-by-one با خط خالی انتهایی)

**امکانات جدید:** Dev Mailbox ادمین (/admin/logs/mailbox — لیست+پیش‌نمایش sandboxed)، مودال میان‌برهای «؟»، دکمهٔ کپی سایت‌واید (.js-copy — اولین استفاده: کد کوپن)، سنجهٔ قدرت رمز + toggle + بازخورد تطابق در register

**راستی‌آزمایی:** E2E مرورگری کامل (ثبت‌نام→ایمیل→لینک تأیید→ورود) PASS؛ ۱۶ صفحهٔ کلیدی 200؛ php -l ×۹ و node --check clean؛ دادهٔ تست حذف شد (صفر ردپا)
