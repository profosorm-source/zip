# صف فیکس معلق — بازتولید از سشن S31-S33 (گم‌شده)

> تاریخ بازتولید: ۲۰۲۶-۰۹-۱۹. منبع: کانتکست عامل اصلی پس از ریست سندباکس به v23.
> ⚠️ همهٔ موارد پیش از فیکس باید **مجدد روی کد حاضر (v23) راستی‌آزمایی شوند** — شماره خط‌ها ممکن است کمی جابه‌جا باشند.
> وضعیت: P0/P1 موج ۱ (۱۲ کامیت تا ab3cce0) و P2 موج ۲ (635e581) فیکس شدند — رکورد کامل در INDEX.md. تصمیم اصلی کاربر: P0 و هر سه P1 «انجامش بده»؛ P2/P3 «اگر بدرد نمی‌خورند و مرده حساب می‌شوند حذفشون کن». سپس کاربر اجرای فیکس را به بعد از ادامهٔ بررسی‌ها موکول کرد.
> پشتوانه: کاربر بعداً تأیید کرد این موارد پابرجا بمانند و بررسی‌ها ادامه یابد.

## P0 🔴 — بازپرداخت ویترین به مسیر state-only (پول stranded)

- `app/Services/EscrowService::refundFunds` (حدود L462-520): فقط flip وضعیت می‌زند؛ کامنت «WalletMutationService records the ledger leg» نادرست است — هیچ لجر مالی ثبت نمی‌شود.
- مصرف‌کنندهٔ خطرناک: `app/Jobs/Vitrine/AdminRefundVitrineListingJob:104-120` (فراخوان در L108) آن را «بازپرداخت موفق» فرض می‌کند و `status='refunded'` مسیر درست را برای همیشه می‌بندد.
- مسیر درست: `app/Domain/Financial/Services/FinancialEscrowService::refundEscrowToBuyer` (حدود L150-172؛ گارد status در L159؛ سه مرحله refundFunds + releaseLockedFunds + finalizeLockedRefund).
- مدل `app/Models/Escrow.php:199-218` هم state-only است (فقط برای خواندن وضعیت).
- **فیکس توافق‌شده**: اتصال جاب به `FinancialEscrowService::refundEscrowToBuyer` + تست رگرسیون + تصمیم حذف/delegation برای `refundFunds` و متدهای state-only مدل.
- راستی‌آزمایی بازتولید (این سشن): فراخوان در `AdminRefundVitrineListingJob:108` در کد حاضر تأیید شد.

## P1 🟠 — سه مورد

1. **قفل توزیع‌شدهٔ fail-open**: `app/Services/DistributedLockService` — در شکست Redis قفل را «تهیه‌شده» فرض می‌کند. ۹ فراخواننده شناسایی‌شده: SessionService:104، TwoFactorService:207، ScoreCommandService:233، VelocityCheckService:114، AccountDeletionService:83 + ۴ مورد دیگر. تنها WalletService:407-418 الگوی درست (fail-closed با فلگ) را دارد.
   **فیکس توافق‌شده**: فعال‌سازی سراسری `lock.fail_closed` + تست + بازبینی ۹ فراخواننده.
2. **PAN کامل در پاسخ API**: `app/Services/BankCardService` (L116، L548-568) + `app/Http/Controllers/Api/WalletController:100-106` — شماره کارت رمزنگاری‌شدهٔ کامل بدون ماسک برمی‌گردد.
   **فیکس توافق‌شده**: ماسک ۴ رقم آخر در `bankCardsList`.
3. **FeatureFlag بی‌اثر**: ارزیاب `app/Services/FeatureFlagService` (حدود L296/L304 `percentage_rollout`) و مدل (L124 `rollout_percentage`، L112 `enabled_percentage`) سه نام ستون فانتومی را می‌خوانند/می‌نویسند در حالی که ستون واقعی migration فقط **`n`** است (migration `2026_06_12_0001`) — canary و targeting عملاً هیچ اثری ندارند.
   **فیکس توافق‌شده**: یکسان‌سازی (ترجیحاً rename `n` → `enabled_percentage` در migration کانونی + اصلاح کد/ادمین) یا حذف مستدل canary — تصمیم در ledger ثبت شود.

## P2 ✅ — هشت Medium زیربچ ۲ — فیکس شد در موج ۲ (کامیت 635e581، ۲۰۲۶-۰۹-۱۹)

1. `ScheduledPaymentService:95-214` — توهم تراکنش (closure داخل tx فعال بدون savepoint: `core/TransactionWrapper.php:38-40`) + ماژول یتیم بدون تولیدکنندهٔ رویداد.
2. `MaintenanceService:283-307` — حذف audit بدون آرشیو در شکست fopen.
3. `SeoPayoutService:77` — گیت بودجه با float به‌جای bccomp؛ متد مردهٔ `refundToBudget` با داک دروغگو → حذف.
4. `TicketQueryService:41-44` — quickSearchTickets اسکوپ را نادیده می‌گیرد.
5. `DirectMessageCommandService:152-158` — مسیر پیوست بدون containment.
6. `OutboxPublisher:93+320-351` — zombie recovery با پنجرهٔ ۷ دقیقه → ریسک دابل‌پابلیش؛ بدون قفل publisher.
7. `ScoreService:222-263` — سه نوشتار بدون تراکنش.
8. `DatabaseAnalyzerService:96-118` — OPTIMIZE/ANALYZE روی همه‌جدول‌ها بدون allowlist.

## P3 🟡 — بدهی متد مرده (→ حذف مستدل به الگوی C-W1)

- ۱۶۵ متد DEAD در Services (سه‌لایه: ثبت‌نشده + بدون تولیدکنندهٔ رویداد + بدون فراخوان API جایگزین).
- دو کلاس تمام‌مرده: `ReferralManagementService` (۱۸ متد؛ مدرک: کامنت `ReferralService.php:1099`) و `DatabaseService` (۷ متد).
- قانون: موارد دارای مسیر API زنده یا تست نگهداری می‌شوند؛ بقیه حذف با مستندسازی در ledger.

## سایر یافتهٔ زیربچ ۲ (از پاس A سشن گم‌شده — برای تقاطع/پاس B آینده)

- Backup: ۳ مورد Low
- Content: float-math درآمد (حدود L920-951)
- WebSocket: رقابت zRangeByScore→zRem + `/stats` بدون gate
- Email: processQueue دورزدن MAIL_DRIVER
- Upload: getCloudViewUrl بدون گارد
- Captcha: client-trusted

## زیربچ ۱ (سشن گم‌شده) — کشف‌های کلیدی که به صف بالا منتقل شدند

- خوانش کامل EscrowService (۶۳۸ خط) و کشف P0 بالا + الفبای مسیر مالی واقعی FinancialEscrowService
- افزوده‌های تقاطع: Backup 3×Low، Content/WebSocket/Email/Upload/Captcha (فهرست بالا)
- پاس B زیربچ ۲ به‌عنوان گلوگاه باقی‌مانده (پس از فیکس‌ها یا موازی با آن)

## زیربچ ۵ (S33-B5، ۲۰۲۶-۰۹-۱۹) — یافته‌های کلیدی هویت/کاربر (جزئیات + بستهٔ فیکس ۱۰گانه در `s33_subbatch5_auth_user_identity.md`)

- **S5-H3 🔴** حذف حساب ۱۰۰٪ شکست: `AccountDeletionService:201` DELETE به ستون ناموجود `password_resets.user_id` (اسکیما فقط email/token/created_at) → ساگا همیشه rollback
- **S5-H1 🔴** ابطال سشن بی‌اثر: `SessionService:303-322` بدون destroy payload و بدون پاک‌کردن CHORTKE_SESSION؛ هیچ middleware `is_active` نمی‌خواند؛ changePassword اصلاً ابطال نمی‌کند → سشن ربوده‌شده از ریست/تغییر رمز جان می‌برد
- **S5-H2 🔴** خود-تأییدی اینفلوئنسر: `VerificationService:290-320` — همهٔ ورودی‌های امتیاز (+40/+25/+35) از کلاینت؛ auto_verified بدون هیچ بررسی واقعی اسکرین‌شات
- **S5-M1** `adminChangeLevel` همیشه false (userService هرگز تزریق نمی‌شود؛ LevelController:166 زنده) — قابلیت ادمین شکسته
- **S5-M2** processQueue ایمیل بدون claim اتمیک (FOR UPDATE بیرون tx + کامنت دروغ) → ارسال مضاعف؛ **S5-M3** ناشناس‌سازی ناقص حذف حساب (PII/فایل KYC/کش FCM/`password='DELETED_ACCOUNT'`)؛ **S5-M4** عبور OAuth از `locked_2fa` (loginDirectly:276)؛ **S5-M5** قفل ردیف در طول bcrypt/ایمیل → DoS (AuthService:133-231)؛ **S5-M6** پیام جعلی ثبت معرف (whitelist:375 بدون referred_by)؛ **S5-M7** کش `user_prefs:{id}` بدون invalidation
- + ۱۷ Low و ۱۰ کاندید مرده (از جمله `sendLotteryWinnerEmail` تله‌دار و `cleanupExpiredVerifications` با داک cron دروغگو) → ledger
- یادآوری: بسته‌های فیکس زیربچ ۳ (۴H) و ۴ (1C/4H) در لجرهای خودشان هستند.


## زیربچ ۶ (S33-B6، ۲۰۲۶-۰۹-۱۹) — Sentry+Search+زیرساخت (Mediumها راستی‌آزمایی و فیکس شدند)

جزئیات کامل + بستهٔ پیشنهادی ۱۶گانه در `s33_subbatch6_sentry_search_infra.md`:
- **S6-H1 🔴** موتور قواعد الرت روی ستون‌های شبح (`rule_type/time_window/threshold/severity` ناموجود) — کرون هر دقیقه خطا؛ هرگز کار نکرده
- **S6-H2 🔴** `UserSearchProvider` هرگز در DI ثبت نشده → جستجوی کاربر در production همیشه خالی
- **S6-H3 🔴** `evaluateAllRules`/`processEscalations`/`autoResolveAlerts` صفر فراخوان — ارزیابی/تشدید/حل‌خودکار الرت مرده
- **S6-M×۱۲**: موارد راستی‌آزمایی‌شده در موج‌های بعدی اصلاح یا false positive اعلام شدند؛ جزئیات و تست‌ها در `s33_subbatch6_sentry_search_infra.md` ثبت است. انتقال `transactions_archive` تا وجود reader برنامه‌ای disabled است.
- **S6-L×۱۶**: L1 false positive و همهٔ L8/L9/L11/L12/L2/L4/L7/L13/L15 اصلاح شدند؛ مورد Low تأییدشدهٔ باز باقی نمانده است. جزئیات و راستی‌آزمایی در `s33_subbatch6_sentry_search_infra.md` ثبت شده‌اند.
