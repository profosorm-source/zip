# زیربچ ۳ — AntiFraud + Score + Gamification (S33-B3)

> تاریخ: ۲۰۲۶-۰۹-۱۹ | پروتکل: پاس A + پاس B (کور، موازی) + تقاطع + راستی‌آزمایی خط‌به‌خط توسط عامل اصلی
> پوشش: **۳۳/۳۳ فایل — ۹,۶۴۳/۹,۶۴۳ خط** (AntiFraud ۲۷ / Score ۴ / Gamification ۲)
> گزارش‌های خام: `agent-ctx/_audit/s33b3_pass_a.md` و `s33b3_pass_b.md` (خارج ریپو)
> ⚠️ این بچ فقط بررسی بود؛ **هیچ تغییری در کد اعمال نشد.** فیکس‌ها به صف معلق می‌روند (تصمیم کاربر: اول بررسی‌ها).

## یافته‌های تأییدشدهٔ تقاطع (A∩B + راستی‌آزمایی عامل اصلی)

### 🔴 High

**S3-H1 (PA-1≡PB-20) — زنجیرهٔ «سفر غیرممکن» از کار افتاده/جعلی است.**
- `app/Models/IpAndDeviceModel.php:155-161` — `getLastLoginLocation` فقط `ip_address, country, city, created_at` را انتخاب می‌کند؛ ستون latitude/longitude وجود ندارد (راستی‌آزمایی شد) + `OFFSET 1` آخرین سشن را هم رد می‌کند.
- `GeolocationIntelligenceService.php:77-88` — مختصات قبلی همیشه 0,0 → گارد null-island همیشه `is_impossible=false`؛ در `analyzeGeoVelocity` همهٔ فواصل/سرعت‌ها صفر و سیگنال high_speed هرگز آتش نمی‌زند.
- `AccountTakeoverService.php:311-324` — کامنت اعترافی «در رکوردهای جدید latitude/longitude ذخیره نمی‌شود» + لنگر پیش‌فرض تهران (35.6892,51.3890) → لاگین سریع از شهر غیرتهرانی = جریمهٔ +۹۰ کاذب و challenge بی‌مورد؛ مهاجم نزدیک تهران هرگز فلگ نمی‌شود.
- اثر: یکی از ستون‌های اصلی ATO عملاً چرت تولید می‌کند یا خاموش است.

**S3-H2 (PA-2≡PB-2) — گیت velocity برای ۱۲ اکشن مالی و task.custom عملاً no-op است.**
- `VelocityCheckService.php:29-60` — `DEFAULT_RULES` فقط deposit/withdrawal/transfer/social_task/login/password_change دارد؛ `financial_commitment` و `task_execution` غایب‌اند. `AMOUNT_LIMITS` هم فقط deposit/withdrawal.
- `VelocityCheckService.php:164-168` — قوانین خالی → `return ['allowed'=>true]` (راستی‌آزمایی شد)؛ `TransactionFraudStrategy.php:113-128` برای investment.pay / lottery.participate / prediction.bet / vitrine.escrow / banner.purchase / ad.budget_withdraw / seo.ad_budget / scheduled_payment / user.level_purchase / influencer_order_create فقط `financial_commitment` می‌فرستد؛ `CheckTaskFraudJob.php:45` برای تسک‌ها `task_execution`.
- تنها منبع قوانین (`setCustomRules`) هیچ caller ندارد؛ کامنت `TransactionFraudStrategy.php:123-124` («same velocity checks as transfers») دروغ است.

**S3-H3 (PA-3≡PB-4) — کلید ایدمپوتنسی score قبل از گاردها مصرف و در شکست آزاد نمی‌شود → جریمه/XP برای همیشه گم می‌شود.**
- `ScoreCommandService.php:74-90` — SETNX+EXPIRE پیش از همهٔ گاردها؛ early-returnها (rate-limit:98، fraud-block:124، velocity:147، alternating:179، floor:214) و catch تراکنش (:292-300) کلید را release نمی‌کنند (finally فقط قفل را آزاد می‌کند: 301-310).
- نتیجه: هر retry مشروع با همان کلید تا ۷ روز «موفق-فِیک» skip می‌شود — جریمهٔ task_rejected / decay / XP ثبت نمی‌شود ولی caller موفقیت می‌بیند.
- ناسازگاری درون-فایلی: `applySystemSet` (:463-556) الگوی کامل `$claimed`+`releaseClaim` را دارد؛ `applyDelta` و `applySystemDelta` (:359-374) ندارند (هر دو راستی‌آزمایی شد).
- ریشهٔ مشترک با PA-11: SETNX+EXPIRE دودستوری غیراتمیک (کرش بین دو دستور = کلید بی‌TTL ابدی).

**S3-H4 (PB-1) — سیگنال‌های پرریسک Sybil/ML هرگز بر تصمیم اثر ندارند؛ فقط لاگ می‌شوند.**
- `FraudGuardService.php:71-96` — Sybil: `$score = max($score, 85)`؛ ML: `max($score, mlScore*100)` — اما هیچ‌کدام کلید `allowed` به `$results` اضافه نمی‌کنند.
- `RiskDecisionService.php:34-73` — `decide()` فقط `effectiveFraudScore()` از لجر (:41,96-121) را می‌خواند؛ `context['fraud_score']` که در :114-119 پاس داده می‌شود **نادیده گرفته می‌شود**.
- `FraudGuardService::compileFinalDecision` (:147-207) فقط `allowed` پارشیال‌ها و `ip_quality.risk_score>=90` را مصرف می‌کند → Sybil/ML صرفاً در `details` می‌مانند. همهٔ ~۱۱ فراخوانندهٔ checkAction فقط `['allowed']` می‌خوانند.

### 🟠 Medium

**S3-M1 (PB-9) — خروجی geolocation / ATO / device کلید `allowed` ندارند → در compileFinalDecision بی‌اثرند.** (`GeolocationIntelligenceService.php:556-601`، `AccountTakeoverService.php:201-206`، `DeviceIntelligenceService.php:425-432`؛ مصرف‌کننده: `FraudGuardService.php:129-207`)

**S3-M2 (PA-7≡PB-5) — همهٔ دامنه‌های `.ir` «غیرقابل‌مسیریابی» فرض شده و بدون MX-lookup `valid=true` برمی‌گردند — در production هم.** (`EmailPhoneIntelligenceService.php:118-132`؛ راستی‌آزمایی شد: گارد `str_ends_with('.ir')` پیش از lookup) → ایمیل جعلی `*.ir` از جریمهٔ +۷۰ عبور می‌کند. `getmxrr` هم timeout ندارد.

**S3-M3 (PA-6≡PB-7) — بازسازی لیست Tor غیراتمیک: `truncateTorNodes()` سپس insert حلقه‌ای بدون تراکنش.** (`TorListUpdater.php:65-72`؛ مسیر زندهٔ کرون 04:20 در `Console/Kernel.php:1104`) → کرش وسط کار = لیست خالی/جزئی و پنجرهٔ کور ۲۴ ساعته برای سیگنال +۸۰ تور (مصرف: IPQualityService:41، GeoIPService:486).

**S3-M4 (PA-13≡PB-10) — ScoreQueryService fail-open: شکست DB → `0.0` بی‌صدا.** (`ScoreQueryService.php:70-72` + لاگ خراب `@error_log('[ScoreQueryService\]')` در :51) → مصرف‌کنندهٔ حساس `RiskDecisionService::effectiveFraudScore:98` در outage امتیاز fraud=0 می‌بیند → مسیر allow. همچنین آب‌رسانی کش از پروجکشنِ عقب‌مانده + hIncrByFloat پس‌ازِ commit (`ScoreCommandService.php:318-334`) پایهٔ کهنه را تا TTL 1h مُهر می‌کند (تسکین موجود: hDel در ScoreProjectionListener:212-218).

**S3-M5 (PA-8) — در خطای gather، fallback امتیاز ثابتِ پایین (~۲۴ < flag=50) ساخته می‌شود → در اختلال DB همهٔ گیت‌های fraud بی‌صدا باز می‌شوند.** (`FraudDetectionService.php:158-176`؛ راستی‌آزمایی شد) — باید fail-closed یا حداقل فلگِ degraded باشد.

**S3-M6 (PA-9≡PB-3) — «راستی‌آزمایی امضای رمزنگاری‌شده» موبایل فقط `strlen>=32` روی هدر سمت‌کلاینت است و متد هم مرده است.** (`DeviceIntelligenceService.php:534-570`؛ docblock :527 ادعای verify رمزنگاری دارد؛ بدون caller) → ادعای امنیتی کاذب؛ یا پیاده شود یا حذف.

**S3-M7 (PA-10) — FIX-S18-6 به تنها producer وصل نشده: `SocialTaskEventListeners.php:193` → `evaluate(..., 'task_rejected')` بدون dedup_id** → کلید `trust:{uid}:{domain}:task_rejected` فقط اولین جریمهٔ ۷روزه را اعمال می‌کند؛ جریمه‌های بعدی تا انقضای SETNX بی‌اثرند (راستی‌آزمایی شد).

**S3-M8 (PB-8) — پیش‌فرض lookup جغرافیا `http://ip-api.com` بدون TLS** (`GeolocationIntelligenceService.php:37,459-479`) → MITM می‌تواند country/lat/lon جعل کند و impossible-travel/timezone را همیشه «نرمال» نشان دهد. (SSRF رد شد؛ مشکل صرفاً transport است.)

**S3-M9 (PB-6) — `ipInRange` فقط IPv4: IPv6 هرگز با رنج‌های VPN/Datacenter match نمی‌شود.** (`IPQualityService.php:96-109` — گارد `ip2long===false` دارد اما برای IPv6 همیشه false؛ `GeoIPService.php:238-246` حتی گارد رنج-بدون-`/` ندارد → CIDR خراب ادمینی = همه‌ی IPv4ها suspicious +۳۰). الگوی درست: `SeoFraudDetector::ipInCidr:349-388` (inet_pton).

**S3-M10 (PA-4) — متادیتای لجر `original_delta` مقدار clamp‌شده را ثبت می‌کند نه اصلی.** (`ScoreCommandService.php:198-218` — بازنویسی `$delta` در :204 پیش از `requested_delta`(:212) و `original_delta`(:217)) → audit trail نادرست در ردیف‌های floor-clamped.

**S3-M11 (PA-5≡PB-16) — `VelocityCheckService::record()` مردهٔ تله‌دار:** اگر احیا شود شمارش را ۲× می‌کند (check خودش اسلات رزرو می‌کند :215-217)، ثانیه را به‌جای دقیقه به Cache::set می‌دهد (بازگشت باگ X317)، TTL را refresh می‌کند (بازگشت M-23)، RMW غیراتمیک. (`VelocityCheckService.php:349-368`؛ بدون caller)

### 🟡 Low (فشرده)

| ID | محل | خلاصه |
|---|---|---|
| S3-L1 | PA-11 / ScoreCommandService:80-84,467-471 | SETNX+EXPIRE دودستوری غیراتمیک → کلید بی‌TTL ابدی در کرش (SET NX EX تک‌دستوری) |
| S3-L2 | PB-11 / VelocityCheckService:126-158,215-217 | رزرو اسلات بدون مسیر بازگشت → تلاش‌های ناموفق بودجهٔ ۳/h واریز را می‌سوزانند |
| S3-L3 | PB-12 / MLFraudDetectionService:97-100 + GeolocationIntelligence:543-546 | نشت PII (email/phone/ip/location) به لاگ info/critical |
| S3-L4 | PB-13 / TrustService:141-150,174 | «capped at 100» فقط در پروجکشن؛ لجر عبور می‌کند + بازوی مردهٔ min() |
| S3-L5 | PB-14=PA-consult / FraudDetectionService:138 | `$this->outbox` تکراری داخل حلقهٔ نرمال‌سازی وزن |
| S3-L6 | PB-15 / ScoreCommandService:112-135 + FraudDetectionService:186-205 | هر applyDelta = یک calculateFraudScore کامل + INSERT لاگ + outbox (write amplification) |
| S3-L7 | PB-17 / GeoIPService:332-438 | ادعای دروغین «Integrity کامل/Zip Bomb Protection»: فقط ۲ بایت gzip، سقف روی حجم فشرده نه استخراج‌شده؛ متد بی‌caller |
| S3-L8 | PB-18 / FraudDashboardService:127-128 | متریک جعلی `false_positive_rate_percent => 0` هاردکد در داشبورد ادمین |
| S3-L9 | PB-19 / RiskDecisionService:149-156 | `SELECT status FROM kyc_verifications ... LIMIT 1` بدون ORDER BY → وتوی KYC nondeterministic |
| S3-L10 | PA-12 / GeoIPService:238-246 | گارد `ip2long===false` ندارد (جزء S3-M9) |
| S3-L11 | PA-14 / ScoreCommandService:318-334 | شکست hIncrByFloat پس از commit → drift کش تا TTL 1h (تسکین async موجود) |
| S3-L12 | PA-15 / VideoFingerprintService:359-371 | heuristic `str_contains($videoId,'md5')` همیشه غلط + docblock وعدهٔ Frame-Hashing/Audio-FP |
| S3-L13 | PA-16 | ناهم‌خوانی پیکربندی: MAX_TRAVEL_SPEED هاردکد در velocity-loop (Geolocation:259) در برابر policy:103؛ +۲۵ هاردکد GeoIPService:499-501 |
| S3-L14 | PB-20 / AccountTakeoverService:297-354 | پیاده‌سازی دومِ impossible-travel با آستانهٔ متفاوت (1000 vs 900) — جزء S3-H1 |
| S3-L15 | PB-21 / VideoFingerprintService:83-122 | TOCTOU در checkDuplicate (کلاس مرده) |
| S3-L16 | PB-22 / XpService:66 | `award()` کلید ایدمپوتنسی nullable می‌پذیرد (فراخوانان فعلی کلید می‌دهند) |

## ردهای مشترک/تأییدشده (گزیده)

XFF blind-trust (helpers/security.php:226-277 فقط trusted-proxy)؛ fail-open گارد آنتی‌فراد (FraudGuardService:213-242 fail-closed + config fail_open_actions=[])؛ SQLi در fallbackها (int-clamp/placeholder)؛ LIKE MonthlyLeaderboard (escape درست)؛ SSRF geo (FILTER_VALIDATE_IP دولایه + urlencode + timeout)؛ IPQualityService بدون HTTP خارجی؛ قفل velocity فقط با توکن خود instance؛ دوبار-XP (هر سه پرودیوسر کلید دارند — ContentEventListeners:265، TaskCompletedListener:83، HandlePaymentCompleted:130)؛ رقابت کش/پروجکشن مهارشده (hDel بعد از upsert)؛ MonthlyLeaderboard مرده نیست (views/user/level/index.php:147-151)؛ executeAutomatedActions بدون forcedScore از FraudController:95؛ recoverWeekly هم‌خوان با social_task_executions (Kernel:880)؛ isFinancialAction ↔ FraudStrategyResolver هم‌پوشان؛ normalizeThresholds ترتیب آستانه‌ها را تضمین می‌کند.

## کاندیدهای کد مرده (سه‌لایه؛ توافق دو پاس مگر خلافش ذکر شود)

| آیتم | A | B | حکم پیشنهادی |
|---|---|---|---|
| `VideoFingerprintService` (کل کلاس، ۴۹۲ خط) | ✅ DEAD | ✅ DEAD | حذف — فقط self-ref + migration + سند |
| `DeviceIntelligenceService::verifyMobileAppAttestation` | ✅ | ✅ | حذف یا پیاده‌سازی واقعی (S3-M6) |
| `DeviceIntelligenceService::saveDeviceAnalysis` / `getDeviceHistory` | ✅ | ✅/— | حذف |
| `VelocityCheckService::setCustomRules` / `record` / `reset` / `getStatus` | ✅ | ✅ | حذف (record تله‌دار — S3-M11) |
| `RateLimitingService::checkSlidingWindow` / `checkComposite` / `recordRateLimitExceeded` (بدنه خالی) | ✅ | ✅/— | حذف |
| `GeoIPService::updateMaxMindDatabase` / `isIranianIP` | ✅ | ✅/— | حذف (به‌روزرسانی MaxMind هرگز خودکار نیست) |
| `EmailPhoneIntelligenceService::updateDisposableList` / `cleanupCache` | ✅ | ✅/— | حذف (لیست DB فقط ۱۲ دامنهٔ hardcode) |
| `GeolocationIntelligenceService::cleanupCache` | ✅ | — | حذف |
| `GraphAnalysisService::analyzeUserNetwork` (کلاس زنده به‌خاطر detectSybilNetwork) | ✅ | ✅ | حذف متد |
| `SeoFraudDetector::smoothScore` / `isBlacklisted` | ✅ | ✅ | حذف (addToBlacklist زنده: ProcessSeoTaskAsyncJob:146) |
| `BrowserFingerprintService::isFingerprintBlacklisted` | — | ✅ | حذف (لیست device_blacklist در گارد مصرف نمی‌شود) |
| `IPQualityService::checkIp` (alias) | — | ✅ | حذف |
| `FraudDetectionService::requiresReview` | — | ✅ | فقط tests → تصمیم حذف با تست |
| قواعد `social_task` در DEFAULT_RULES | — | ✅ | DEAD-CONFIG (هیچ check با social_task) |
| `MLFraudDetectionService::provideFeedback` | ✅ | — | حلقهٔ feedback هرگز تغذیه نمی‌شود — حذف یا اتصال |

## کانسالت‌های مهم (فقط-ثبت)

- پرودیوسرهای applyDelta بدون کلید ایدمپوتنسی: SettleGameJob:162-189، UpdateLotteryChanceScoresJob:131,207 (+ TaskCompletedListener:87 در گزارش A — مغایرت با ردِ B:83 کلید دارد؛ در فاز فیکس راستی‌آزمایی شود)
- detectorهای client-fed (browser-fingerprint، device-FP، biometrics) ذاتاً جعل‌پذیرند — سیگنال‌اند نه کنترل
- anchor تهران برای IPهای private در ATO
- ip-api روی HTTP (S3-M8) و دانلود disposable-list بدون timeout/سقف
- false-positive اسکرول عمودی در detectLinearScroll
- OFFSET 1 در getLastLoginLocation حتی اگر ستون‌ها اضافه شوند، آخرین لاگین را نادیده می‌گیرد

## بستهٔ پیشنهادی فیکس (صف — پس از تصمیم کاربر)

1. **S3-H3** ایدمپوتنسی score: انتقال claim به پس از گاردها + releaseClaim در همهٔ مسیرهای شکست + `SET NX EX` تک‌دستوری (S3-L1) — یکدست‌سازی با applySystemSet
2. **S3-H2** افزودن قواعد `financial_commitment`/`task_execution` به DEFAULT_RULES (یا تنظیم از policy) + اصلاح کامنت دروغگو
3. **S3-H1** ستون‌های lat/lon در user_sessions (migration) + حذف OFFSET 1 + حذف لنگر تهران + یکسان‌سازی آستانه
4. **S3-H4 + S3-M1** اتصال Sybil/ML/geo/ATO/device به تصمیم (کلید allowed یا بلوک score در decide) — با گارد false-positive
5. **S3-M2** حذف میان‌بُر `.ir` (فقط دامنهٔ خود پروژه) + MX با timeout
6. **S3-M3** تراکنش‌دار کردن بازسازی Tor
7. **S3-M4/S3-M5** fail-closed یا فلگ degraded در ScoreQueryService و FraudDetectionService
8. **S3-M7** ارسال dedup_id در task_rejected (تکمیل FIX-S18-6)
9. **S3-M8** HTTPS/کلیددار کردن geo-provider + **S3-M9** inet_pton IPv6-safe
10. **S3-M10** ثبت original_delta پیش از clamp
11. حذف جدول dead-code بالا (به الگوی C-W1) + پاک‌سازی S3-M11/S3-L12/S3-L15 همراهش


---

## وضعیت فیکس (موج ۲ — ۲۰۲۶-۰۹-۱۹، کامیت 6788083)

هر ۱۱ Medium این لجر (S3-M1 تا S3-M11) فیکس شدند؛ گیت: سوییت کامل سبز + PHPStan صفر. نکات:
- **S3-M1**: باقی‌مانده (geo/device بدون کلید allowed) در همان بلوک فیکس S3-H4 تکمیل شد — فقط بر حکم نامطلوب خود سرویس (is_high_risk>=70 / is_suspicious).
- **S3-M7**: کشف تکمیلی — handleTaskRejected اصلاً به هیچ رویدادی وصل نبود و dispatch هم قبلاً حذف شده بود؛ زنجیره از دو سر احیا شد (ثبت listener + تولید رویداد در RejectSocialTaskExecutionJob + dedup_id per-execution از execution_id) — تکمیل FIX-S18-6.
- **S3-M2**: میان‌بُر .ir فقط برای دامنهٔ خود پروژه (chortke.ir) و TLDهای محلی؛ MX با memoization درون‌پروسه‌ای (PHP هسته timeout مستقیم DNS ندارد — ثبت شد).
- **S3-M3**: TRUNCATE (DDL؛ implicit commit) با DELETE+INSERT در یک تراکنش (rebuildTorNodes) جایگزین شد؛ متدهای قدیمی مدل حذف شدند.
- **S3-M8**: در production فقط endpoint از نوع https:// مجاز است؛ http:// به «نامعلوم» fail-closed می‌شود (پس از S3-H1 = بدون لنگر جعلی) + لاگ critical. free-tier ip-api ذاتاً HTTP است — اپراتور باید endpoint کلیددار (pro.ip-api) در settings بگذارد.
- **S3-M6/M11**: متدهای مردهٔ تله‌دار (verifyMobileAppAttestation؛ record/setCustomRules/reset/getStatus در Velocity) حذف شدند + ثابت APPLE_ATTESTATION_MIN_LEN و ACCOUNT_AGE_FALLBACK_DAYS.
