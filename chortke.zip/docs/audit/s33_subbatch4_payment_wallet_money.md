# زیربچ ۴ — زنجیرهٔ حرکت پول: Payment + Wallet + Withdrawal + CryptoDeposit + Dispute + Investment + Lottery (S33-B4)

> تاریخ: ۲۰۲۶-۰۹-۱۹ | پروتکل: پاس A + پاس B (کور، موازی) + تقاطع + راستی‌آزمایی خط‌به‌خط توسط عامل اصلی
> پوشش: **۲۷/۲۷ فایل — ~۹,۲۰۶ خط** (تخصیص این سشن؛ فهرست دقیق زیربچ ~۱۲,۳۵۶ خطی سشن گم‌شده قابل بازیابی نبود — کل دایرکتوری‌های حرکت پول همین ۲۷ فایل است)
> گزارش‌های خام: `agent-ctx/_audit/s33b4_pass_a.md` و `s33b4_pass_b.md` (کامیت‌شده)
> ⚠️ بررسی فقط؛ **هیچ تغییری در کد اعمال نشد.** فیکس‌ها به صف معلق اضافه می‌شوند.
> **این حساس‌ترین بچ تاکنون است: یک Critical + چهار High پولی.**

## یافته‌های تأییدشدهٔ تقاطع (A∩B + راستی‌آزمایی عامل اصلی)

### 🔴 Critical

**S4-C1 (PA-2≡PB-1) — کرون، واریز USDT را بدون هیچ راستی‌آزمایی آن‌چین اعتبار می‌زند.**
- `app/Console/Kernel.php:72-100` — کرون هر دقیقه ردیف‌های `crypto_deposits` با `verification_status='pending'` را برمی‌دارد و به `VerifyCryptoDepositJob` می‌دهد.
- `app/Jobs/VerifyCryptoDepositJob.php:19` — مستقیم → `fulfillCryptoDeposit`.
- `app/Services/Payment/PaymentDepositService.php:161-204` — گام `verify_and_update` فقط `$deposit->status !== 'pending'` را چک می‌کند، `status='completed'` می‌زند و `walletService->deposit(usdt, amount)` اجرا می‌کند — **هیچ verifier آن‌چینی در مسیر نیست** (راستی‌آزمایی شد).
- تنها پیاده‌سازی وریفای واقعی (`CryptoDepositService::tryAutoVerify` → CryptoVerificationAdapter) **بدون caller است** (هر دو عامل مستقلاً تأیید کردند) — یعنی موتور وریفای هرگز اجرا نمی‌شود.
- اثر: کاربر با tx_hash دلخواه و مبلغ دلخواه (min=1 USDT، بدون سقف) ظرف ~۱ دقیقه اعتبار مجانی می‌گیرد. **فوری‌ترین فیکس کل پروژه.**

### 🔴 High

**S4-H2 (PA-3≡PB-2) — دو موتور موازی اعتبار برای یک واریز کریپتو = دابل‌کِردیت تضمینی.**
- مسیر ادمین `CryptoDepositService::approve` (:194-289): ستون `verification_status` → 'verified'، کلید صریح `cryptoDepositApprove(id)` (:251).
- مسیر کرون `fulfillCryptoDeposit`: ستون `status` → 'completed'، کلید خودکارِ مبتنی بر ref_id+IP (هیچ کلید صریحی ندارد).
- هر دو ستون default 'pending' (migration `2026_06_10_0008_extended_financial.sql:77-78`)؛ هیچ‌کدام ستون دیگری را نمی‌بندد؛ کلیدها هم متفاوت‌اند → گذر یک ردیف از هر دو مسیر = **دو بار واریز**. کامنت :246-250 خودش مشکل دو-کلیدی را می‌شناسد ولی فقط approve را بسته است.

**S4-H3 (PA-1≡PB-3) — درگاه Mock در پروداکشن زنده و از ورودی کاربر قابل انتخاب است.**
- `CreateDepositRequest.php:14` — `in:zarinpal,idpay,nextpay,dgpay,mock`؛ `AppServiceProvider.php:148-155` — resolver پروداکشن بدون گارد env شامل `mock`؛ حتی آپشن UI (`views/user/wallet/index.php:531`).
- `MockPaymentGateway` — `verifyPayment` همیشه success؛ `verifyCallback` بدون WEBHooK_SECRET فقط در production می‌ترکد، وگرنه true (:21-47).
- سدهای جانبی فعلی: nonce محرمانه + IP-whitelist کالبک (`PaymentCommandService:471-513`)؛ با `APP_ENV≠production` یا ردیف `payment_gateways` با نام mock = اعتبار مجانی نامحدود.

**S4-H4 (PA-4≡PB-4) — برداشت سود سرمایه‌گذاری با کلید ثابت؛ سود دوم بی‌صدا می‌سوزد.**
- `InvestmentCommandService.php:445-471` — `profit_earned` **قبل از** واریز صفر می‌شود (:453-456) و واریز با کلید ثابت `'investment_profit_withdrawal_'.$investmentId` (:463) انجام می‌شود.
- کلید UNIQUE است → برداشت سودِ دومِ مشروع (پس از کول‌داون ۷روزه) به واریز اول replay می‌شود (`WalletMutationService::processDeposit:156-172` — راستی‌آزمایی شد: برمی‌گرداند `success=true` با transaction_id قدیم و پیام «قبلاً پردازش شده») → پیام موفقیت، سود صفرشده، **هیچ پولی واریز نمی‌شود**.

**S4-H5 (PA-5≡PB-5) — بن‌بست ساختاری کالبک درگاه‌ها در production (fail-totally).**
- `BasePaymentGateway.php:175-227` — `signatureExpected` با وجود secret همیشه true است؛ هیچ‌یک از ۴ درگاه ایرانی callback را امضا نمی‌کنند (`usesSignedCallbacks()`=false و **هیچ override در کل repo نیست**) → `verifyCallbackSignature` در نبود فیلد امضا false (:135-139) → همهٔ کالبک‌ها رد می‌شوند.
- بدون secret در production → RuntimeException (:199-215). یعنی خط لولهٔ وب‌هوک آنلاین در پروداکشن کور است؛ اعتبار فقط از مسیر بازگشت کاربر + `verifyPayment` (nonce) می‌آید. کامنت H-07 ادعای واگذاری می‌کند ولی گیت `verifyCallback` قبل از آن است (Lie نسبی).

### 🟠 Medium

| ID | محل | خلاصه |
|---|---|---|
| S4-M1 | PA-8≡PB-8b / `WalletMutationService.php:1100-1121` | `releaseLockedFunds`: اگر `createTransaction` null شود، unlock و commit انجام می‌شود **بدون ردیف transactions و بدون لجر** و پاسخ `success=true` با `transaction_id=null` (الگوی درست throw در spendLockedFunds:961-963) |
| S4-M2 | PB-8a / `WalletMutationService.php:641-674` | `processTransfer`: شکست/نال شدن ردیف گیرنده → وجه جابه‌جا می‌شود ولی `recordDoubleEntry` skip می‌شود (`if ($fromTransaction && $toTransaction)`) و commit می‌ماند |
| S4-M3 | PB-6 / `PaymentCommandService.php:129-163` | HTTP درگاه (~۶۰ ثانیه با ۳ retry) داخل تراکنش باز DB و زیر قفل FOR UPDATE → گرسنگی قفل/کانکشن |
| S4-M4 | PA-7 / `WithdrawalAdminService.php:290-315` | `adminReject` برخلاف `adminApprove` بدون `lockForUpdate` و با چک وضعیت بیرون تراکنش → TOCTOU در تقاطع approve/reject |
| S4-M5 | PA-6 / `WalletMutationService.php:754-848` + `WithdrawalTimeoutJob.php:148-164` | `completeWithdrawal/cancelWithdrawal` وضعیت را بیرون تراکنش می‌خوانند و `recordStatusChange` بدون CAS است → دو فراخوانی هم‌زمان = دوبار برداشت از locked برای یک hold؛ کرون timeout نتیجهٔ UPDATE را چک نمی‌کند (refund بدون ردیف) |
| S4-M6 | PB-7 / `ZarinPalGateway:70-72,167-169` + `IDPayGateway:104` + `PaymentGateway::updateConfig:71` | سوییچ sandbox از DB بدون هیچ گارد APP_ENV → اپراتور/نفوذ DB می‌تواند پروداکشن را به sandbox ببرد (رفتار معکوس وریفای) |

### 🟡 Low (فشرده، ادغام A/B)

| ID | محل | خلاصه |
|---|---|---|
| S4-L1 | PA-9 / IDPayGateway:184-185,253-256 | بلاک if خالیِ «اعتبارسنجی» + fallback مبلغ به ورودی + regex authority احتمالاً ناسازگار با IDPay واقعی (fail-closed) |
| S4-L2 | PA-10 / WalletMutationService:180-184 | دورزدن frozen-check با `metadata['type']` از refundTypes (امروز فقط caller داخلی — hardening) |
| S4-L3 | PA-11 / WalletQueryService:64-70 | کسر دوبارهٔ locked از balance که از قبل کسر شده → available کمتر از واقع (مصرف ApiWalletController) |
| S4-L4 | PA-12 / WalletMutationService:1182-1195 | snapshot بدون قفل balance_before/after در reverseTransaction |
| S4-L5 | PA-13 | float در پول: WithdrawalQueryService:100-101، LotteryQueryService:98 |
| S4-L6 | PA-14 | authority token در breadcrumb/لاگ؛ تناقض ریال/تومان در کامنت‌ها (divide by 10 در برابر bcmul ×10)؛ نام گمراه‌کنندهٔ depositInTransaction/withdrawInTransaction |
| S4-L7 | PB-9 / DisputeCommandService:706-710 | استاب rate-limit dispute — `checkLimits` همیشه true |
| S4-L8 | PB-10 / LotteryCommandService | ادعاهای شفافیت لاتاری ناسازگار با کد (chance_score هاردکد ۱۰۰، seed_hash=hash نتیجه) |
| S4-L9 | PB-11 / canWithdraw:103 در برابر :119 | case-sensitivity ارز |
| S4-L10 | PB-12 / LotteryCommandService:420-427 | پرداخت جایزهٔ لاتاری بدون کنترل کفایت lottery_pool |
| S4-L11 | PB-13 | نام گمراه‌کنندهٔ depositInTransaction/withdrawInTransaction (تراکنش مستقل می‌سازند) |
| S4-L12 | PB-14 / applyLoss:421-442 | بدون اعتبارسنجی علامت مبلغ |

## ردهای مشترک/تأییدشده (گزیده — ۱۳ A + ۱۷ B)

مبلغ منفی (گیت bccomp در executeAtomicOperation:157) • دستکاری amount کالبک (سه لایه: PaymentCommandService:595-606,631-645 + هر ۳ گیت‌وی) • replay وریفای همان authority (کلید per-authority + UNIQUE + FOR UPDATE) • دابل‌کلیک ادمین برداشت (lockForUpdate+pending) • دابل refund اختلاف (M-16 + کلید per-dispute) • بلیط لاتاری دوبل (قفل راند + ظرفیت) • سرمایه‌گذاری دوبل (بازچک FOR UPDATE داخل tx — M-21) • جعل role پیام اختلاف (سمت‌سرور) • کالبک GET (فقط بلاک) • بایپس IP-whitelist (بدون ورودی کاربر) • self-approval ادمین کریپتو/دستی (گارد C03 در هر دو) • fail-open گیت ضدتقلب (assert_fraud_allowed fail-CLOSED) • دابل‌پرداخت برداشت سرمایه (کلید per-row:339-345) • double-reversal (claimForReversal CAS) • tx_hash تکراری (UNIQUE) • TOCTOU reject کریپتو (بازچک زیر قفل) • نشت PAN/credentials در لاگ (رد شد).

## کاندیدهای کد مرده (سه‌لایه)

| مورد | A | B | حکم |
|---|---|---|---|
| `CryptoDepositService::tryAutoVerify` (:360) | ✅ | ✅ | **خطرناک‌ترین کد مرده** — تنها وریفای آن‌چین؛ باید زنده شود، نه حذف |
| `reconcilePendingPayments` + `ReconcilePaymentsJob` | — | ✅ | بدون cron/route — حذف یا اتصال به زمان‌بند |
| `refundPayment` ×۵ گیت‌وی (Interface:50) | ✅ | — | بدون caller — حذف یا اتصال به مسیر refund |
| `PaymentGatewayFactory::getAvailableGateways()` (:97) | ✅ | — | حذف |
| `PaymentGatewayInterface::getName()` ×۵ | ✅ | — | بدون caller — حذف از اینترفیس |
| `InvestmentCommandService::calculateNetProfitV1/V2` | — | ✅ | protected بی‌subclass — حذف |
| `CryptoDepositService::quickSearchCryptoDeposits` (:498) | ✅ | ✅ | حذف |
| `cleanupExpiredIntents` (زنجیره) | — | ✅ | بدون cron — حذف یا زمان‌بندی (اشباع مبالغ یکتای intent) |
| `MockPaymentGateway` | NOT-dead | NOT-dead | «زنده ولی نباید زنده باشد» — S4-H3 |

## بستهٔ پیشنهادی فیکس (صف — پس از تصمیم کاربر)

1. **S4-C1** فوری: وریفای آن‌چین پیش‌شرط fulfill شود (`tryAutoVerify` زنده شود یا کرون تا اتصال adapter غیرفعال گردد) + تست
2. **S4-H2** یکسان‌سازی: fulfill همان ستون/کلید approve را مصرف کند (ستون واحد + کلید صریح `cryptoDepositApprove(id)`)
3. **S4-H3** حذف `mock` از allowlist ورودی و resolver پروداکشن (گارد APP_ENV در factory) + حذف آپشن UI
4. **S4-H4** کلید per-withdrawal (مثلاً hash(investmentId+period یا timestamp کول‌داون)) + صفرکردن سود **بعد از** واریز موفق در همان tx
5. **S4-H5** تصمیم معماری کالبک: یا override `usesSignedCallbacks` برای درگاه‌های واقعاً امضاکننده و خطای صریح برای بقیه، یا دورزدن گیت امضا برای درگاه‌های غیرامضا با اتکای کامل به nonce+verifyPayment (مستند)
6. **S4-M1/M2** failure-hardening: در نبود ردیف تراکنش، throw (الگوی spendLockedFunds) نه ادامه با success
7. **S4-M3** خروج HTTP درگاه از تراکنش/قفل (create → commit → HTTP → verify در tx جدید)
8. **S4-M4** lockForUpdate در adminReject + **S4-M5** CAS کردن complete/cancel + چک نتیجهٔ UPDATE در کرون timeout
9. **S4-M6** گارد APP_ENV روی sandbox
10. پاک‌سازی dead-code (به‌جز tryAutoVerify که باید زنده شود)


---

## وضعیت فیکس (موج ۱+۲ — ۲۰۲۶-۰۹-۱۹)

- موج ۱ (S4-C1/H2→b7c3c49، H3/H4/H5→83d41ae، M1/M2/M4/M6→f1c5952).
- **موج ۲ — S4-M3 (کامیت f0db0b4)**: فراخوانی HTTP درگاه (تا ~۶۰ ثانیه با ۳ retry) از داخل تراکنش/قفل FOR UPDATE خارج شد — بازسازی سه‌فازی: tx کوتاه اعتبارسنجی کارت+nonce → commit → HTTP بدون tx/قفل → tx کوتاه ثبت ردیف با authority (+ بازخوانی سبک بقا کارت؛ bank_card_id صرفاً توصیفی است). سمانتیک خطا دست‌نخورده: هر شکست = هیچ ردیفی.
- باقی‌ماندهٔ این لجر: **S4-M5** (completeWithdrawal/cancelWithdrawal بدون CAS + کرون timeout بدون چک نتیجه) — تنها مورد پابرجای جدول Medium؛ در صف موج بعدی، پیش از P3.
