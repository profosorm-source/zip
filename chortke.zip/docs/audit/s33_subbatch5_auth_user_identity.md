# زیربچ ۵ — هویت، کاربر و ارتباطات: Auth + User + KYC + Notification + Cache + ریشه (S33-B5)

> تاریخ: ۲۰۲۶-۰۹-۱۹ | پروتکل: پاس A + پاس B (کور، موازی، ترتیب معکوس) + تقاطع + راستی‌آزمایی خط‌به‌خط توسط عامل اصلی
> پوشش: **۴۴/۴۴ فایل — ~۱۳,۸۹۳ خط** — Auth (۸ فایل/۳,۰۲۱) • User (۸/۳,۲۰۳) • KYC (۳/۱,۰۶۱) • Notification (۱۷/۲,۳۵۰) • Cache (۲/۴۶۶) • ریشه (۶/۳,۷۹۲: SocialAccount، ApiToken، Verification، Captcha، Email، EmailDeliveryStore)
> گزارش‌های خام: `agent-ctx/_audit/s33b5_pass_a.md` (۰C/3H/8M/9L + ۷ کاندید مرده + ۱۹ رد) و `s33b5_pass_b.md` (۰C/2H/4M/12L + ۶ کاندید مرده + ۳۰ رد)
> ⚠️ در زمان تهیهٔ این گزارش بررسی فقط بود و هیچ تغییری در کد اعمال نشده بود؛ فیکس‌ها بعداً در موج‌های جداگانه ثبت شده‌اند.
> راستی‌آزمایی عامل اصلی: خواندن مستقیم ۱۸ فایل + اسکیما (migration `2026_06_10_0047`) + grep سراسری فراخواننده‌ها.

## یافته‌های تأییدشدهٔ تقاطع (A∩B + راستی‌آزمایی عامل اصلی)

### 🔴 High ×۳

**S5-H1 (PA-2≡PB-1) — «ابطال همهٔ نشست‌ها» بی‌اثر است؛ سشن ربوده‌شده از ریست/تغییر رمز جان سالم به‌در می‌برد.**
- `SessionService::invalidateAllUserSessions` (:303-322) فقط `is_active=0` در DB می‌زند (`SecurityModel:202`) و کلید ردیس `session:activity:*` را پاک می‌کند؛ برخلاف `revokeSession` (:282-288) هیچ `Core\Session::destroyById` و پاک‌سازی `CHORTKE_SESSION:*` انجام نمی‌دهد.
- هیچ نقطه‌ای از مسیر درخواست `is_active` را نمی‌خواند: grep سراسری middlewareها = صفر مورد؛ وریفای دوره‌ای ۲دقیقه‌ای `AuthMiddleware` (:232-266) فقط `status='active'` کاربر را چک می‌کند (:249) — نه سشن DB.
- فراخواننده‌ها: `PasswordRecoveryService:172` (پس از ریست رمز) و `ProfileController:268` (خروج از همهٔ دستگاه‌ها). مسیر `UserService::changePassword` (:196-212) اصلاً ابطال نمی‌کند (فقط remember_token — H-03).
- اثر: مهاجمی که سشن قربانی را دارد پس از ریست رمز دسترسی‌اش برقرار می‌ماند؛ پیام موفقیت resetPassword («تمامی نشست‌های فعال و توکن‌های قبلی باطل شدند» :185) دروغ است. توکن‌های API واقعاً revoke می‌شوند (:174-176) — فقط سشن وب نه.

**S5-H2 (PA-3≡PB-2) — تأیید اینفلوئنسر کاملاً خود-اثبات‌پذیر (self-attestation) است.**
- `VerificationService::evaluateScreenshotProof` (:290-320): +40 صرفِ وجود فایل اسکرین‌شات، +25 هاستِ URL (فقط `str_contains` instagram.com/t.me :322-330)، +35 اعلام کد `visible_code` توسط کلاینت — کدی که خود سرویس به کاربر داده و از قبل می‌داند (`hash_equals` فقط «دانستن کد» را اثبات می‌کند). **هیچ تحلیل سمت‌سرورِ محتوای تصویر انجام نمی‌شود.**
- threshold 85 → هر کاربر با سه ورودی دلخواه score=100 می‌سازد → `auto_verified` (:212-232) → `STATUS_VERIFIED` بدون هیچ ادمین؛ پیام «پیج شما با بررسی اسکرین‌شات … تأیید شد» (:245) ادعای بررسی‌ای است که رخ نمی‌دهد (Lie).

**S5-H3 (PA-1؛ تک‌کشف A — راستی‌آزمایی اسکیما) — ساگای حذف حساب ۱۰۰٪ شکست می‌خورد: SQL به ستون ناموجود.**
- `AccountDeletionService:201`: `DELETE FROM password_resets WHERE user_id = ?` — اسکیما (migration `2026_06_10_0047_infrastructure_missing.sql:117-123`) فقط `email/token/created_at` دارد؛ `user_id` وجود ندارد → Unknown column → exception → rollback کل ساگا (:173-244) → `deleteUserAccount` همیشه false.
- اثر: هیچ حسابی حذف‌شدنی نیست (درخواست‌ها pending می‌مانند؛ کرون انقضا هم همین ساگا را صدا می‌زند). اصلاح: `WHERE email = ?` (واکشی email پیش از گام anonymize) یا افزودن ستون user_id در migration کانونی.

### 🟠 Medium ×۷

| ID | محل | خلاصه |
|---|---|---|
| S5-M1 | PA-4≡PB-5 / `UserLevelCommandService.php:25,27-45,119-124` + `Admin/LevelController.php:166` | `adminChangeLevel` همیشه false — سازنده هرگز `userService` را نمی‌سازد و setter وجود ندارد (grep کلاس: فقط :25/:122/:125)؛ مسیر ادمینِ زنده همیشه شکست. منطق قفل‌گذاری M-39 (:128-140+) پشت گارد = کد مردهٔ تله‌دار |
| S5-M2 | PA-8≡PB-3 / `EmailDeliveryStore.php:275-284` + `EmailService.php:297-331` | `getPending` با «FOR UPDATE» بیرون هر تراکنش (اتوکامیت) = قفل بی‌اثر؛ کامنت «قفل‌گذاری اتمیک» (:277-278) دروغ. `processQueue` بدون claim ردیف → کرون + اکشن ادمین + `SendEmailJob` هم‌زمان = ارسال مضاعف ایمیل؛ claim ردیف فقط در مسیر SendEmailJob (release در :261) |
| S5-M3 | PA-10≡PB-7 + PA-18 / `AccountDeletionService.php:186-244` | (پس از رفع S5-H3) ناشناس‌سازی ناقص: `birth_date/gender/address` در UPDATE نیستند (:221-238)؛ فایل‌های KYC/اکسپورت روی دیسک باقی؛ `password='DELETED_ACCOUNT'` literal (:228)؛ کش FCM (TTL ۳۰روز) و payload سشن (تا ۲ دقیقه گیت) پاک نمی‌شوند |
| S5-M4 | PA-5 / `AuthService.php:268-282` | `loginDirectly` فقط `locked` را می‌بندد (:276-278)، نه `locked_2fa` — ناهم‌تراز با `attemptLogin:145`؛ هر ۴ فراخواننده مسیر OAuth هستند (`OAuthController:359`، `OAuthHelperTrait:335/378/410`) → حساب قفل‌شدهٔ 2FA از ورود اجتماعی عبور می‌کند |
| S5-M5 | PA-6 / `AuthService.php:133-231` | قفل ردیف `FOR UPDATE` (`findByCredentialsForUpdate:135`) در طول `usleep` (:181) + bcrypt (:183) + نوشتن security_log (:197-204) + ایمیل قفل‌هشدار (:216-218) با تراکنش باز نگه داشته می‌شود (commit :223-225/:230-232) → زنجیرهٔ قفل/DoS با اسپم لاگین ناموفق روی حساب هدف |
| S5-M6 | PA-7 / `ReferralController.php:312-313` + `UserService.php:374-381` | `referred_by` خارج از whitelist `updateUser` (`['full_name','email','role','status']`)؛ کنترلر پاسخ «معرف با موفقیت ثبت شد» می‌دهد → انتساب معرف هرگز ذخیره نمی‌شود (پیام جعلی؛ پیامد مستقیم بر مایلستون‌های ریفرال) |
| S5-M7 | PB-4 / `CacheInvalidationService.php:204-210` + `NotificationPreferenceService.php:79-102` | `invalidateUser` کلید `user_prefs:{id}` را پاک نمی‌کند (فقط user_settings/profile/tags) و شاخهٔ else (:95) عملاً نمی‌رسد → ترجیح خاموش‌شده تا TTL ۳۰۰ ثانیه نادیده گرفته می‌شود؛ ضمناً forget قبل از UPDATE DB (:90-101) → پنجرهٔ کش‌مجددِ مقدار قدیم |

### 🟡 Low ×۱۷ (ادغام A/B)

| ID | محل | خلاصه |
|---|---|---|
| S5-L1 | PA-12≡PB-8 / `CaptchaService.php:296-317` + `CaptchaMiddleware.php:52,66` | کپچای behavioral: امتیاز (≥60) و رویدادهای خام از ورودی کلاینت (:304-317) — کل تحلیل روی دادهٔ جعل‌شدنی؛ توکن single-use نیست (PA: replay تا پنجرهٔ اعتبار)؛ مسیر زنده از ریسک لاگین (middleware شاخهٔ behavioral را صریحاً مدیریت می‌کند) — ادعای dormant پاس B مردود شد |
| S5-L2 | PA-9 / `ApiTokenService.php:330-341` | افشای وجود ایمیل با زمان‌پاسخ (بدون dummy-hash برخلاف AuthService:139/146)؛ با ریت‌لیمیت 429 (:315) تخفیف شدت |
| S5-L3 | PA-13 / `PasswordRecoveryService.php:113-123` | اوراکل زمانی فراموشی رمز: SMTP همگام برای کاربر موجود در برابر usleep برای ناموجود + سقف قابل‌دورزدن با روتیشن IP |
| S5-L4 | PA-14 / `UserService.php:162-167` | ON DUPLICATE KEY فقط code/expires را تازه می‌کند، نه token (HMAC) → ناسازگاری لینک/OTP در edge-case |
| S5-L5 | PA-15≡PB-16 / `PasswordRecoveryService.php:149-153` + :138-186 | لاگ توکن خام reset در مسیر email_mismatch؛ بدون PasswordPolicy در resetPassword (اعتماد به کنترلر) |
| S5-L6 | PA-16 / `EmailService.php:772-778` | LIKE بدون escape ٪ و _ در جستجوی ادمین (خلاف الگوی درست ApiTokenService:602) |
| S5-L7 | PA-17≡PB-17 / `NotificationTemplateService.php:79-85` | interpolate تک‌گذره → تزریق متغیر-در-متغیر (فقط متن) |
| S5-L8 | PA-19 / `TwoFactorService.php:318` | rateLimiter nullable → ریت‌لیمیت کد بازیابی در ساخت دستی ساکت حذف می‌شود (در DI پروداکشن تزریق می‌شود — سخت‌سازی) |
| S5-L9 | PA-20 / `UserService.php:348` | hierarchy بدون `support` (`['user'=>0,'admin'=>1,'super_admin'=>2]`) در برابر `AuthService:138` — support مثل user سطح‌بندی می‌شود (fail-closed اما ناهم‌خوان) |
| S5-L10 | PB-6 / `UserDashboardService.php:334-337` + `CacheManager.php:34-37` | `!== false` در برابر قرارداد missِ null-محور بقیهٔ کدبیس → اگر handler null برگرداند شمارندهٔ تیکت باز همیشه ۰ (و :345 هرگز اجرا نمی‌شود)؛ نیاز به تست قرارداد handler |
| S5-L11 | PB-9 / `EmailService.php:512-520` + :204 | `sendLotteryWinnerEmail` با priority 'urgent' خارج از whitelist → همیشه Exception؛ بدون caller → مردهٔ تله‌دار |
| S5-L12 | PB-12 / `UserLevelQueryService.php:190-196,256-262` | XP-boost فقط روی درصد نمایشی نوار پیشرفت ضرب می‌شود (تورم نمایشی) — بر پایهٔ پاس B |
| S5-L13 | PB-13 / `UserDashboardService.php:273,282-283` | متریک‌های ساختگی: progress همیشه 0، paid_count=referred_count، pending=0 |
| S5-L14 | PB-15 / `VerificationService.php:425-450` | `rejectVerification` بدون گارد وضعیت (ناهم‌تراز با approve) → ردِ تأییدشده ممکن است |
| S5-L15 | PB-14 / `TwoFactorService.php:203-256` vs :259-266 | `enable()` بدون بازتأیید رمز — ناهم‌تراز با `disable()` (سخت‌گیری نامتقارن) |
| S5-L16 | PA-11 / `NotificationTemplateService.php:13` + `CacheInvalidationService.php:236-240` | کلید invalidation (`notification_template:`) ≠ کلید واقعی کش (`notif_tpl:`) — تخفیف: سرویس خودش در :136/:149 کلید درست را forget می‌کند و TTL کوتاه است |
| S5-L17 | PA-18 / `FcmService.php:77,95,107` | کش توکن FCM در حذف حساب پاک نمی‌شود (invalidateFcmToken فقط در شکست ارسال) — ادغام در S5-M3 |

## ردهای مشترک/تأییدشده (گزیده — ۱۹ A + ۳۰ B)

وریفای واقعی JWT گوگل • state/nonce در OAuth • dummy-hash در لاگین و مسیر unverified (AuthService:139/146/152) • مصرف اتمیک توکن ریست (`findAndConsumePasswordResetToken` :142) + HMAC توکن • کد بازیابی 2FA دولایه HMAC+bcrypt (:295-299) • قفل توزیع‌شده روی enable 2FA (:206-211) • fail-closed middleware در خطای DB (:285-294 destroy) • CAS و گاردهای مالکیت در KYC/تأیید • revokeRememberToken در تغییرات auth-strength (changePassword:203-204، enable/disable 2FA) • گیت 2FA در issueToken (:343-359) • گارد state-machine حذف حساب (FIX-S16-2 :153-167) • RateLimiter fail-closed (recovery :323) • گاردهای سلسله‌مراتب نقش در updateUser (:341-372).

## کاندیدهای کد مرده (سه‌لایه)

| مورد | A | B | حکم |
|---|---|---|---|
| `AuthService::checkRateLimit` (:69) | ✅ | — | بدون فراخواننده — حذف |
| `SessionService::cleanupSessions` (:324) | ✅ | — | کرون موازی در `Kernel.php:379` خودش purge می‌کند — حذف (ویژگی از مسیر کرون زنده است) |
| `SessionService::setSessionCookie` (:483) | ✅ | — | حذف |
| `VerificationService::cleanupExpiredVerifications` (:562) | ✅ | — | داک «hourly via cron» دروغ می‌گوید (هیچ کرونی صدا نمی‌زند) + پیاده‌سازی دوبل (`InfluencerModel:604` / `InfluencerVerification:211`) — یا اتصال به زمان‌بند + یکسان‌سازی مدل، یا حذف |
| `CacheInvalidationService::invalidateByPattern` (:52-55) | ✅ | ✅ | stub خالی؛ فقط تست reflection — پیاده‌سازی SCAN یا حذف |
| بدنهٔ `adminChangeLevel` (:125+) | ✅ | ✅ | پشت گارد null غیرقابل‌دسترس — همراه S5-M1 |
| `EmailService::sendLotteryWinnerEmail` (:512) | — | ✅ | مرده + تله (priority نامعتبر) — حذف یا اصلاح |
| `ProfileService::updateSetting/updateMultipleSettings` | — | ✅ | بدون caller پروداکشن + بدون whitelist (PB-18) — حذف یا whitelist |
| `CaptchaService::getCaptchaTypeByRisk` (:163) | — | ✅ | انتخاب زنده از `LoginRiskService::getCaptchaType` می‌آید؛ این متد فقط تستی — ادغام/حذف |
| predicate `token = $q` در `searchTokens` (ApiTokenService:607) | — | ✅ | ستون هش‌شده هرگز match نمی‌شود — اصلاح یا حذف |

## بستهٔ پیشنهادی فیکس S5 (صف — پس از تصمیم کاربر)

1. **S5-H3 فوری**: `DELETE FROM password_resets WHERE email = ?` (واکشی email پیش از گام anonymize) یا مهاجرت schema + تست انتها-به-انتهای ساگا (فعلاً هیچ حسابی حذف‌شدنی نیست!)
2. **S5-H1**: destroy payload همهٔ سشن‌ها (`Core\Session::destroyById` + `CHORTKE_SESSION:*`) در invalidateAllUserSessions + خواندن `is_active` در وریفای دوره‌ای AuthMiddleware + فراخوانی ابطال در `changePassword`
3. **S5-H2**: بستن مسیر auto_verified یا راستی‌آزمایی سمت‌سرور واقعی (OCR/توکن تصادفی در URL/بازبینی انسانی اجباری)
4. **S5-M1**: تزریق UserService در سازنده (یا کوئری مستقیم) + تست مسیر ادمین
5. **S5-M2**: claim اتمیک ردیف در getPending (الگوی SET NX EX مسیر SendEmailJob یا UPDATE مشروط با claim_until)
6. **S5-M3**: تکمیل ناشناس‌سازی (ستون‌های PII + فایل‌های KYC/اکسپورت + کش FCM) پس از فیکس ۱
7. **S5-M4**: گارد `locked_2fa` در loginDirectly (هم‌تراز attemptLogin:145)
8. **S5-M5**: خروج usleep/bcrypt/ایمیل از قلمرو تراکنش (verify بیرون قفل)
9. **S5-M6**: ذخیرهٔ واقعی referred_by (متد اختصاصی) + پاسخ صادقانه در خطا
10. **S5-M7 + Lهای کش**: forget `user_prefs:{id}` در invalidateUser + اصلاح کلید invalidation قالب + جابه‌جایی forget بعد از UPDATE
+ پاک‌سازی dead-code جدول بالا (به الگوی C-W1)


---

## وضعیت فیکس (موج ۱+۲ — ۲۰۲۶-۰۹-۱۹)

- موج ۱ (S5-H1/H2/H3→ab3cce0؛ M1/M2/M4/M5/M6/M7→d09c182).
- **موج ۲ — S5-M3 (کامیت 6709fd2)**: ناشناس‌سازی حذف حساب کامل شد — ستون‌های PII اضافی (birth_date/gender/address) در UPDATE؛ password با هش تصادفی per-deletion به‌جای literal حدس‌پذیر؛ فایل‌های KYC/اکسپورت با جمع‌آوری مسیر داخل purge و حذف فیزیکی best-effort پس از commit (کانتینمنت سخت‌گیرانه زیر storage/exports)؛ کش FCM برای هر پلتفرم ثبت‌شده پاک می‌شود؛ سشن‌های زنده با الگوی H1 ابطال می‌شوند. سه وابستگی اختیاری جدید (Cache/SessionService/UploadService) پیش‌فرض null = سازگاری کامل DI.
- هیچ Medium پابرجای دیگر در این لجر نیست؛ Lows و dead-code طبق صف.

## وضعیت فیکس (موج ۳ — S5-L3/L12/L17 — ۲۰۲۶-۰۹-۲۶)

- **S5-L17:** پلتفرم‌های FCM پیش از حذف `user_devices` جمع‌آوری می‌شوند تا پاک‌سازی کش پس از commit واقعاً انجام شود.
- **S5-L12:** XP boost دیگر درصد نمایشی progress را متورم نمی‌کند؛ ضریب واقعی جداگانه گزارش می‌شود و موتور ارتقا با XP خام هم‌تراز می‌ماند.
- **S5-L3:** ایمیل reset از مسیر queue/outbox ارسال می‌شود و SMTP داخل درخواست اجرا نمی‌شود؛ هر دو شاخهٔ موجود/ناموجود timing floor مشترک دارند.
- Regression جدید در `tests/Unit/Services/S5LowFindingsRegressionTest.php` اضافه شد.
- تست‌های Unit کامل: `2526` موفق، `1` skip عمدی. PHPStan روی چهار فایل تغییر‌یافته بدون خطا است؛ اسکن کامل پروژه هنوز `168` خطای خارج از این موج دارد.
