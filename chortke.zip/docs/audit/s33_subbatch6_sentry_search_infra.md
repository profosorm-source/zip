# زیربچ ۶ — Sentry + Search + زیرساخت (S33-B6)

> تاریخ: ۲۰۲۶-۰۹-۱۹ | پروتکل: پاس A + پاس B (کور، موازی، ترتیب معکوس) + تقاطع + راستی‌آزمایی خط‌به‌خط توسط عامل اصلی
> پوشش: **۴۷/۴۷ فایل — ~۱۵,۷۳۰ خط** — Sentry (۹/۳,۸۴۹) • Search (۱۵/۳,۵۹۹) • زیرساخت ریشه (۱۶/۵,۴۳۶: Health/Metrics/Cron/DlqWorker/QueueWorker/Migration/DatabaseAnalyzer/Maintenance/CacheAdmin/PerformanceOptimization/OutboxService/OutboxPublisher/SagaOrchestrator/DistributedLock/ValidatorFactory/StateMachine) • Settings (۴/۱,۲۹۸) • Analytics (۳/۱,۵۴۷)
> گزارش‌های خام: `agent-ctx/_audit/s33b6_pass_a.md` (1H/8M/10L + ۲۴ کاندید مرده) و `s33b6_pass_b.md` (3H/10M/7L + ۱۰ کاندید مرده)
> ⚠️ در زمان تهیهٔ گزارش بررسی فقط بود؛ وضعیت فیکس‌های بعدی در انتهای سند ثبت شده است.
> راستی‌آزمایی عامل اصلی: خواندن مستقیم اسکیما (migrations) + Kernel کرون + AppServiceProvider + grep سراسری app/tests/**core**.

## یافته‌های تأییدشدهٔ تقاطع (A∩B + راستی‌آزمایی عامل اصلی)

### 🔴 High ×۳

**S6-H1 (PB-1) — موتور قواعد الرت هرگز کار نکرده: کرون هر دقیقه روی ستون‌های شبح می‌خورد.**
- `AlertDispatcher::processRules` (:84-96) از `$rule->rule_type` / `$rule->time_window` / `$rule->threshold` / `$rule->severity` می‌خواند؛ اسکیما (`2026_06_10_0029_final_infrastructure.sql:24-32`) فقط `rule_name/condition/threshold_value/time_window_minutes/is_active/created_at` (+`last_triggered_at` از migration بعدی) دارد.
- `SentryModel::getActiveRules:444-449` = `SELECT * FROM alert_rules WHERE is_active = 1 ORDER BY severity DESC` — ستون `severity` اصلاً وجود ندارد → SQLSTATE 42S22 در هر اجرا.
- کرون `alert_rule_engine` (`Console/Kernel.php:144-146`، هر دقیقه) → خطای هر-دقیقه در لاگ و الرت مبتنی بر قاعده صفر در کل عمر سیستم.

**S6-H2 (PB-2) — جستجوی سمت کاربر در production کور است: UserSearchProvider هرگز ثبت نشده.**
- `AppServiceProvider:232-243` فقط `AdminSearchProvider` را روی `SearchOrchestrator` ثبت می‌کند.
- `SearchOrchestrator::searchUser:103-108` با `findProvider(UserSearchProvider::class)` → null → بی‌صدا `['items'=>[], 'total'=>0]` برمی‌گرداند (AJAX سایدبار + صفحهٔ جستجوی کاربر همیشه خالی).
- `UserSearchProvider` کلاس کامل و تست‌شده‌ای است که فقط از قطار DI جا مانده.

**S6-H3 (PB-3 ≡ PA-5) — ارزیابی قواعد، تشدید (escalation) و حل‌خودکار الرت ویژگی‌های تماماً مرده‌اند.**
- `AlertRulesEngine::evaluateAllRules` و `EscalationManager::processEscalations`/`autoResolveAlerts` — صفر فراخوان در app/tests/core (rg راستی‌آزمایی شد؛ فقط تعریف).
- تنها مسیر کرون‌شده `AlertDispatcher::processRules` است که خودش شکسته است (S6-H1) → کل زیرسیستم «قاعده‌محور» Sentry دو سرِ قطع دارد.
- تصمیم فیکس: اتصال به زمان‌بند + یکسان‌سازی ستون‌ها (H1) یا حذف مستدل به الگوی C-W1 — با تصمیم کاربر.

### 🟠 Medium ×۱۲

| ID | محل | خلاصه |
|---|---|---|
| S6-M1 | PA-3≡PB-4 / `CacheAdminService:113-128` | «reset circuit breaker» کلیدهای غلط را حذف می‌کند (`circuit_breaker:{name}` و `cb_state_{name}` در برابر واقعی `:status/:failures/:opened_at`) → اکشن ادمین no-op ساکت با پیام موفقیت |
| S6-M2 | PA-2 / `SentryErrorMonitor:480-507` | redaction کلید-به-کلید دقیق است (`token` اما نه `access_token`/`refresh_token`) و regex URI فقط `[?&](?:token\|sig\|...)` را می‌گیرد → توکن‌های `*_token` زنده در `request_context` پایدار می‌مانند |
| S6-M3 | PA-4 / `DistributedLockService::guardFence:569-585` | مسیر DB حصار (fence) دودستوری UPDATE→SELECT است؛ رقابت پنجره‌ای دارندهٔ کهنه را عبور می‌دهد (مسیر Redis با Lua اتمیک است — فقط شاخهٔ DB) |
| S6-M4 | PA-7≡PB-10 / `AlertDispatcher::isSafeUrl:546-573` | گارد SSRF «راستی‌آزمایی-بعد-استفاده»: `gethostbyname` بعد `curl_init` دوباره resolve می‌کند → DNS rebinding (URL ادمین‌محور → Medium) |
| S6-M5 | PA-6 / `AlertDispatcher:133-149` | کلید توقف `sentry.push_alerts_enabled` فقط در شاخهٔ Telegram اعمال می‌شود؛ Slack/webhook/email نادیده می‌گیرند (کامنت خلاف است) |
| S6-M6 | PA-8 / `SearchProjectionListener:469-529` | payload خام رویدادها (`$d`) بدون whitelist در `search_projections.metadata` پایدار می‌شود (kyc/bank_card/crypto/escrow/...) → پخش PII/PCI به read-model جستجو |
| S6-M7 | PB-5 / `HealthCheckService::probeSaga:372-383` | probe وضعیت `running/failed` را می‌شمارد؛ SagaOrchestrator فقط `started/completed/compensated` می‌نویسد → ساگای گیرکرده همیشه invisible، `degraded` غیرقابل‌دسترس |
| S6-M8 | PB-6≈PA-9 / `DashboardService::syncEmergencyLogs:407-503` | فایل اضطراری قبل از پایدارکردن `@unlink` می‌شود و catch همه‌چیز را می‌بلعد → تله‌متری bootstrap-failure دقیقاً در سناریوی DB-down برای همیشه گم می‌شود |
| S6-M9 | PB-7 / `AdvancedAuditTrail::cleanupOldRecords:234-282` | حذف retention حتی وقتی آرشیو شکست می‌خورد ادامه می‌یابد (نه fail-closed؛ خلاف سیاست P2-2 در MaintenanceService) + آرشیو بدون سقف |
| S6-M10 | PB-8 / `MaintenanceService::executeArchival:123-197` | تراکنش‌های >۱ سال به `transactions_archive` منتقل می‌شوند اما هیچ خواننده‌ای (UI/API/ریپورت) آرشیو را نمی‌خواند → تاریخچهٔ کاربر/ادمین بی‌صدا کوتاه می‌شود |
| S6-M11 | PB-9 / `AlertDispatcher:177-184,299-303` | یک کانال بدپیکربندی‌شده زنجیرهٔ ارسال به کانال‌های بعدی را قطع می‌کند |
| S6-M12 | PA-1 / `ModuleSearchProvider:73-113` + `AdminSearchGateway` | رجیستری جستجوی ماژول‌ها (bank_cards/kyc/direct_messages) بدون گزارهٔ اجباری مالکیت — IDOR نهفته (امروز صفر فراخوان production؛ سطح API عمومی) |

### 🟡 Low ×۱۶ (ادغام A/B)

| ID | محل | خلاصه |
|---|---|---|
| S6-L1 | PA-2 (در ادامهٔ M2) | فیلتر کلیدهای حساس از `card`/`key` ضعیف‌تر از الگوی substring است |
| S6-L2 | PA-10/11 ≡ PB-17 / `Cron/CronService` | پارامتر شبح در متد + جدول شبح (`cron_*` ناموجود) |
| S6-L3 | PA-12 / `PerformanceOptimizationService` | پیشنهادهای optimize بدون گارد اثر (اقدام نمایشی) |
| S6-L4 | PA-13≡PB-14 / `MetricsCollector` | get-then-put race → گم‌شدن شمارنده‌ها؛ تگ‌ها بی‌صدا drop |
| S6-L5 | PA-14 / `AdvancedAuditTrail:84-111` | لاگ audit از خودش شکست‌های write را ساکت می‌بلعد |
| S6-L6 | PA-15 / `SagaOrchestrator:86-154` | پنجرهٔ compensate بدون قفل — دو ساگای هم‌زمان ممکن است دو بار جبران کنند |
| S6-L7 | PA-16 / `MaintenanceService:283-326` | باقی‌ماندهٔ مسیر archive-and-delete بدون چک نتیجهٔ INSERT قبل از DELETE |
| S6-L8 | PA-17≡PB-11 / `StateMachineService:389` | متن خام استثنا به فراخواننده برمی‌گردد (`خطای سرور: ...`) |
| S6-L9 | PA-18 / `CacheAdminService:163-187` | فلش کش گروهی بدون allowlist الگو |
| S6-L10 | PA-19 / `SearchOrchestrator:35-85` | findProvider با instance-of زنجیره‌ای — ثبت دو provider هم‌نوع ساکت override می‌شود |
| S6-L11 | PB-12 / `AdvancedAuditTrail:185-228` | خروجی CSV audit بدون دفاع formula-injection (خلاف الگوی ExportService) |
| S6-L12 | PB-13 / `SentryErrorMonitor:619-636` | ترمز burst غیراتمیک و fail-open (ادعای EM1 بیش از واقع) |
| S6-L13 | PB-15 / `AlertDispatcher:168-250` | throttle خواندن-بعد-نوشتن → دوبارسانی الرت هم‌نما در رقابت |
| S6-L14 | PB-16 / `OutboxPublisher:332-337` | dispatch دینامیک متد NotificationService از payload DB بدون allowlist |
| S6-L15 | PB-18 / `SearchProjectionListener:80,276-302` | پیام‌های حذف‌شدهٔ DM در پروجکشن جستجوپذیر می‌مانند |
| S6-L16 | PB-19 / `HealthCheckService:161-180` | probe Redis بدون AUTH → «error» کاذب روی Redis رمزدار |

## ردهای مشترک/ردشده (گزیده)

پروجکشن جستجو idempotent با upsert امن؛ DistributedLockService fail-closed (فیکس P1-1) درست کار می‌کند؛ OutboxPublisher قفل publisher و پنجرهٔ zombie اصلاح‌شده (P2-6)؛ DatabaseAnalyzerService allowlist OPTIMIZE/ANALYZE (P2-8)؛ SSRF در geo با FILTER_VALIDATE_IP دولایه (S3-M8 فیکس) — مورد M4 فقط مربوط به webhook ادمین است؛ وابستگی‌های اختیاری null-safe در Settings/Analytics درست؛ برای جزئیات ردها به گزارش‌های خام مراجعه شود (۱۵ رد در هر پاس).

## کاندیدهای کد مرده (سه‌لایه؛ توافق دو پاس + راستی‌آزمایی عامل اصلی)

| مورد | حکم |
|---|---|
| `AlertRulesEngine::evaluateAllRules` + `EscalationManager::processEscalations/autoResolveAlerts` | مردهٔ زنجیره‌ای با S6-H1/H3 — اتصال یا حذف (تصمیم کاربر) |
| `UserSearchProvider` (کلاس کامل بی‌ثبت) | «مردهٔ اتصال‌نیافته» — فیکس درست = ثبت در DI (S6-H2)، نه حذف |
| `CronService` جدول/پارامتر شبح (PB-17) | حذف مستدل |
| `GraphAnalysisService` متدهای حذف‌شدهٔ موج ۳ | بسته شد (مراجعه نشود) |
| helperهای تک‌فراخوان سالم | نگه داشته شدند (رد) |

## بستهٔ پیشنهادی فیکس S6 (صف — پس از تصمیم کاربر)

1. **S6-H1**: هم‌ترازی ستون‌ها — مایگری‌شنِ کانونی (rename `condition→rule_type`، `time_window_minutes→time_window`، `threshold_value→threshold` + افزودن `severity`) یا اصلاح SELECT/کد؛ + تست قرارداد اسکیما
2. **S6-H2**: ثبت `UserSearchProvider` در `$registerSearchProvider` + تست smoke جستجوی کاربر
3. **S6-H3**: اتصال `evaluateAllRules`/`processEscalations` به کرون (پس از H1) یا حذف مستدل — با تصمیم کاربر
4. **S6-M1**: حذف سه کلید واقعی در resetCircuitBreaker + تست
5. **S6-M2**: redaction substring-محور (`*_token`, `*_secret`, `*_key`, `password*`) + regex `[\w-]*(token\|secret\|key\|password)=`
6. **S6-M3**: حصار DB در یک تراکنش با SELECT ... FOR UPDATE (یا rowCount-based CAS)
7. **S6-M4**: پین‌کردن IP با `CURLOPT_RESOLVE` + بازبینی `CURLINFO_PRIMARY_IP`
8. **S6-M5**: اعمال kill-switch روی هر چهار کانال
9. **S6-M6**: whitelist فیلدهای نمایشی per-domain (الگوی indexTransaction)
10. **S6-M7**: هم‌ترازی وضعیت‌های probe با `started/completed/compensated` (+ شمارش stuck با آستانهٔ updated_at)
11. **S6-M8**: unlink پس از پایداری موفق (و بازنویسی فایل در شکست با پسوند retry)
12. **S6-M9**: fail-closed کردن retention آرشیو audit (هم‌راستا با P2-2) + سقف آرشیو
13. **S6-M10**: تصمیم محصولی: خوانندهٔ آرشیو یا توقف انتقال
14. **S6-M11**: ادامهٔ کانال‌های بعدی در شکست یک کانال (جمع خطاها)
15. **S6-M12**: گزارهٔ مالکیت اجباری برای ماژول‌های user-scoped یا مسدودسازی مسیر تا تصمیم
16. Lows مطابق جدول

## وضعیت فیکس

- بررسی اولیه در ۲۰۲۶-۰۹-۱۹ انجام شد؛ فیکس‌های بعدی در موج‌های مستقل اعمال شدند.

## وضعیت فیکس موج‌های بعدی (تا ۲۰۲۶-۰۹-۲۶)

- **S6-H1/H2/H3:** روی کد حاضر اصلاح‌شده و راستی‌آزمایی شدند؛ موتور alert از ستون‌های migration نهایی استفاده می‌کند، `UserSearchProvider` در DI ثبت است و مسیرهای evaluate/escalation/auto-resolve caller زمان‌بندی‌شده دارند.
- **S6-M1:** reset circuit breaker اکنون سه کلید واقعی `:status`، `:failures` و `:opened_at` را حذف می‌کند.
- **S6-M2:** redaction برای query و URI، شامل `access_token`، `refresh_token`، `*_token`، `*_secret` و `*_key`، کامل شد.
- **S6-M3:** guard حصار DB به CAS تک‌دستوری با `next_fence = fence` و `applied_fence < fence` تبدیل شد.
- **S6-M4:** مقصد webhook با IP عمومی resolve و با `CURLOPT_RESOLVE` pin می‌شود؛ `CURLINFO_PRIMARY_IP` نیز بررسی می‌شود.
- **S6-M5/M6/M8:** در راستی‌آزمایی کد حاضر اصلاح‌شده بودند.
- **S6-M7:** probe ساگا وضعیت‌های واقعی `started`، `compensated` و `compensation_failed` را می‌خواند و وضعیت‌های غیرترمینال را degraded می‌کند.
- **S6-M9:** retention audit سقف batch در هر اجرای cron دارد و fail-closed باقی می‌ماند.
- **S6-M10:** انتقال تراکنش به `transactions_archive` تا زمان وجود reader برنامه‌ای به‌صورت امن disabled شد؛ حذف تاریخچهٔ قابل‌مشاهده رخ نمی‌دهد.
- **S6-M11:** exception یا config ناقص یک کانال alert، کانال‌های بعدی را متوقف نمی‌کند.
- **S6-M12:** در مسیرهای production حاضر false positive تشخیص داده شد؛ برای caller آینده فقط hardening دفاعی باقی است.
- Mediumهای S6 فعلاً بدون مورد پابرجای تأییدشده هستند؛ Lows جدول هنوز باید در چرخهٔ بعدی راستی‌آزمایی/اصلاح شوند.

## وضعیت فیکس موج Low (تا ۲۰۲۶-۰۹-۲۷)

- **S6-L1:** false positive در کد حاضر؛ `sanitizeData` با substring روی کلیدهای حساس، `private_key` و `apiKey` را نیز پوشش می‌دهد.
- **S6-L8:** جزئیات exception از پاسخ StateMachine حذف شد و فقط در log باقی می‌ماند.
- **S6-L9:** پاک‌سازی tag فقط برای allowlist cache انجام می‌شود.
- **S6-L11:** خروجی CSV audit برای مقادیر شروع‌شونده با `=`, `+`, `-`, `@` ضد formula-injection شد.
- **S6-L12:** burst limiter از `add` اتمیک با TTL برای اولین event و `increment` برای eventهای بعدی استفاده می‌کند؛ race `ttl()+set()` حذف شد.
- **S6-L2:** هر دو entrypoint قدیمی cron اکنون از `VerifyCryptoDepositJob` و `RedisSessionHandler::gc` استفاده می‌کنند؛ فراخوانی‌های حذف‌شدهٔ `CronService` و logger خارج از scope حذف شدند.
- **S6-L4:** کلیدهای Metrics با hash تگ‌های canonical از هم جدا می‌شوند؛ timing fallback غیر Redis زیر `Cache::withLock` اجرا می‌شود تا نمونه‌ها در race گم نشوند.
- **S6-L7:** پیش از حذف تراکنش منبع، هم `rowCount()` درج و هم شمارش واقعی رکوردهای آرشیو بررسی می‌شود؛ هر عدم تطابق fail-closed است.
- **S6-L13:** throttle الرت پس از بررسی DB یک claim اتمیک `Cache::add` می‌گیرد و در شکست درج DB آن را آزاد می‌کند.
- **S6-L15:** حذف پیام مستقیم از user/admin outbox event تولید می‌کند؛ listener هر دو شکل شناسهٔ projection را غیرفعال می‌کند، backfill پیام حذف‌شده را inactive می‌نویسد و live search نیز آن را فیلتر می‌کند.
- **S6 Lowها:** همهٔ موارد تأییدشدهٔ L1 تا L16 اکنون اصلاح یا false positive مستند شده‌اند؛ مورد پابرجای تأییدشده‌ای باقی نمانده است.

### راستی‌آزمایی نهایی

- `CHORTKE_TEST_DB_USER=chortke CHORTKE_TEST_DB_PASS=chortke_dev php vendor/bin/phpunit tests/Unit`: **2540 موفق، 1 skip عمدی**.
- `vendor/bin/phpstan analyse --no-progress`: **بدون خطا**.
- تست‌های focused مربوط به Cron، Metrics، Maintenance، AlertDispatcher و Search نیز موفق شدند.
