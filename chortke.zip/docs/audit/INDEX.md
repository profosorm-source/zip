# INDEX — Ledgerهای ممیزی Chortke

> ویرایش بازیابی (۲۰۲۶-۰۹-۱۹): سندباکس به اسنپ‌شات v23 (پایان S18) بازگشته بود؛ ledgerهای سشن قبل از دیسک حذف شده بودند.
> یافته‌های آن سشن از کانتکست عامل اصلی بازتولید و در `PENDING-FIXES-QUEUE.md` ماندگار شد.
> **منبع حقیقت فعلی همین پوشه + `/home/z/my-project/worklog.md` است.**

## فهرست Ledgerها

| فایل | محتوا |
|---|---|
| `PENDING-FIXES-QUEUE.md` | صف فیکس معلق (P0/P1/P2/P3) بازتولیدشده از سشن S31-S33 + وضعیت زیربچ‌های ۱ و ۲ |
| `s33_subbatch3_antifraud_score_gamification.md` | زیربچ ۳ — AntiFraud(۲۷)+Score(۴)+Gamification(۲) = ۳۳ فایل/۹,۶۴۳ خط — پاس A/B/تقاطع/راستی‌آزمایی |
| `s33_subbatch4_payment_wallet_money.md` | زیربچ ۴ — Payment(۱۱)+Wallet(۳)+Withdrawal(۳)+CryptoDeposit(۲)+Dispute(۲)+Investment(۲)+Lottery(۴) = ۲۷ فایل/۹,۲۰۶ خط — ۱C/4H/6M/12L |
| `s33_subbatch5_auth_user_identity.md` | زیربچ ۵ — Auth(۸)+User(۸)+KYC(۳)+Notification(۱۷)+Cache(۲)+ریشه(۶) = ۴۴ فایل/۱۳,۸۹۳ خط — ۳H/7M/17L + ۱۰ کاندید مرده |
| `s33_subbatch6_sentry_search_infra.md` | زیربچ ۶ — Sentry(۹)+Search(۱۵)+زیرساخت+Settings+Analytics = ۴۷ فایل/~۱۵,۷۳۰ خط — ۳H/12M/16L + کاندیدهای مرده |

## پوشش تثبیت‌شدهٔ کل پروژه (تا v23)

Core (S1-S7) / مدل‌ها (S12-S13) / Controllers (S14-S16 — ۱۲۳/۱۲۳) / Jobs+Commands (S17 — ۱۴۰ فایل/۱۵,۸۱۷ خط) / Events+Listeners (S18 — ۶۱ فایل/۶,۲۶۱ خط) — صفر یافتهٔ زندهٔ باقی‌مانده در این نواحی.

## پوشش Services (۲۱۹ فایل/۷۸,۲۰۳ خط — ۶ زیربچ)

| زیربچ | دامنه | وضعیت |
|---|---|---|
| ۱ | سرویس‌های پول/اسکرو (فهرست دقیق باید بازتولید شود) | پاس A+B+تقاطع در سشن گم‌شده انجام شد؛ یافته‌ها → PENDING-FIXES-QUEUE |
| ۲ | ۵۰ فایل/۱۷,۷۱۱ خط | پاس A انجام شد؛ پاس B و تقاطع در سشن گم‌شده؛ یافته‌ها → PENDING-FIXES-QUEUE |
| **۳** | **AntiFraud+Score+Gamification — ۳۳ فایل/۹,۶۴۳ خط** | **✅ تمام شد (۲۰۲۶-۰۹-۱۹): پاس A+B+تقاطع+راستی‌آزمایی — ۴H/11M/16L + ~۱۵ کاندید مرده → `s33_subbatch3_antifraud_score_gamification.md`** |
| **۴** | **Payment+Wallet+Withdrawal+CryptoDeposit+Dispute+Investment+Lottery — ۲۷ فایل/۹,۲۰۶ خط** | **✅ تمام شد (۲۰۲۶-۰۹-۱۹): ۱ Critical (کرون کریپتو بدون وریفای) + ۴H/6M/12L + ۸ کاندید مرده → `s33_subbatch4_payment_wallet_money.md`** |
| **۵** | **Auth+User+KYC+Notification+Cache+ریشه — ۴۴ فایل/۱۳,۸۹۳ خط** | **✅ تمام شد (۲۰۲۶-۰۹-۱۹): ۳H/7M/17L + ۱۰ کاندید مرده → `s33_subbatch5_auth_user_identity.md`** |
| **۶** | **Sentry+Search+زیرساخت+Settings+Analytics — ۴۷ فایل/~۱۵,۷۳۰ خط** | **✅ تمام شد (۲۰۲۶-۰۹-۱۹): پاس A+B+تقاطع+راستی‌آزمایی — ۳H/12M/16L → `s33_subbatch6_sentry_search_infra.md`** |

## قانون zip

zip فقط **تجمعی** ساخته می‌شود (نسخهٔ بعدی: v27) — پس از هر بچ فیکس؛ برای هر مشکل جداگانه zip ساخته نمی‌شود.

## گیت‌های استاندارد هر بچ فیکس

`php -l` روی فایل‌های تغییر یافته → سوییت کامل (phpunit.xml شامل گروه architecture، سرور 8090) → PHPStan کانونی → کامیت → zip تجمعی.

## موج فیکس ۲ — مدیوم‌های باقی‌مانده (۲۰۲۶-۰۹-۱۹، تمام شد)

کمپین «رفع یک‌به‌یک یافته‌های Services» — موج اول (۲۲ یافتهٔ Critical/High/P1 + خوشه‌های Medium اول: S4-M×۴، S5-M×۶) ۱۲ کامیت و موج دوم (همهٔ مدیوم‌های باقی‌مانده) ۴ کامیت:

| بچ | کامیت | یافته‌ها |
|---|---|---|
| S3-M خوشهٔ کامل (۱۱ مورد: M1-M11 + حذف M6/M11 مردهٔ تله‌دار) | `6788083` | M1-residual (allowed برای geo/device)، M2 (میان‌بُر .ir)، M3 (بازسازی اتمیک Tor)، M4/M5 (fail-closed امتیاز)، M7 (احیای کامل جریمهٔ task_rejected + dedup per-execution)، M8 (HTTPS اجباری geo در production)، M9 (CIDR شیءگرای IPv6-safe)، M10 (original_delta پیش از clamp)، M6/M11 حذف کد-مرده |
| S4-M3 | `f0db0b4` | خروج HTTP درگاه از تراکنش/قفل — بازسازی سه‌فازی create |
| S5-M3 | `6709fd2` | تکمیل ناشناس‌سازی حذف حساب (birth_date/gender/address، هش تصادفی به‌جای DELETED_ACCOUNT، حذف فایل KYC/اکسپورت از دیسک، پاک‌سازی کش FCM، ابطال سشن) |
| P2×۸ زیربچ ۲ | `635e581` | توهم-تراکنش ScheduledPayment، حذف audit بدون آرشیو (fail-closed + LIMIT هم‌سقف)، bccomp گیت بودجه + حذف refundToBudget، اسکوپ quickSearchTickets (نشتی PII)، containment پیوست DM، قفل publisher برای Outbox، تراکنش createAdjustment، allowlist برای OPTIMIZE/ANALYZE |

گیت‌ها: سوییت کامل **۲۳۷۲ تست/۸۳۴۲ ادعا — صفر شکست** (۳ skip محیطی) + **PHPStan صفر** روی هر چهار کامیت. انتظارات تستِ از-افتاده (قراردادهای عمدی جدید) تطبیق داده شد؛ تست‌های refundToBudget با خودِ متد مرده حذف شدند.

باقی‌ماندهٔ صف فیکس: S4-M5 (زمان‌بندی برداشت — CAS ردیف hold) ثبت‌شده در لجر ۴ (پایین‌تر از مدیوم‌های همین موج)، Lows بسته‌ها، P3 حذف کد-مردهٔ باقی (۳ فایل تمام‌مرده + ReconcilePayments مشروط + متدهای مرده)، و ماندهٔ بررسی: زیربچ ۶ + پاس B زیربچ ۲.


## موج فیکس ۳ — S4-M5 + Lows + P3 (۲۰۲۶-۰۹-۱۹، تمام شد)

| بچ | کامیت | محتوا |
|---|---|---|
| S4-M5 | `340c145` | CAS گذار وضعیت holdهای برداشت: `recordStatusChange` با پارامتر `allowedFromStatuses` (خوان قفل‌شده FOR UPDATE + گارد وضعیت + UPDATE شرطی + چک rowCount)؛ complete/cancel/finalize×۲ با `['pending','processing']` — بازندهٔ رقابت کل mutation پولی را rollback می‌کند؛ کرون WithdrawalTimeout نتیجهٔ UPDATE ردیف withdrawals را چک می‌کند (refund بدون ردیف ناممکن). ۱۰ تست رگرسیون جدید (سرویس + مدل + کرون) |
| Lows | `77633c0` | ۳۰ یافتهٔ Low فیکس‌شده (S3×۷، S4×۱۰، S5×۱۳) + ردهای مستدل (S3-L2/L6/L11، S4-L8/L11، S5-L3/L12 — با دلیل در پیام کامیت و لجرها) |
| P3 | `8c31f04` | حذف ۳ فایل تمام‌مرده (VideoFingerprint ۴۹۲خط، ReferralManagement ۱۸متد، DatabaseService ۷متد) + زنجیرهٔ مردهٔ Reconcile (جاب + دو متد + تست‌ها) + ۳۴ متد مردهٔ لجر S3/S5 در ۲۱ فایل + پاک‌سازی property/ثابت/هلپر یتیم تا PHPStan سخت‌گیرانه صفر بماند. درس: جستجوی فراخوان باید core/ را هم شامل شود (recordRateLimitExceeded ابتدا حذف شد و با کشف فراخوان زندهٔ core/RateLimiter:79 بازیابی شد) |

گیت‌ها: سوییت کامل **۲۳۷۶ تست/۸۳۳۳ ادعا — صفر شکست** (۳ skip محیطی؛ ۷ تست مرده همراه موضوعشان حذف شدند) + **PHPStan سخت‌گیرانه صفر** روی هر سه کامیت.

با این موج، **صف فیکس یافته‌های زیربچ‌های ۱-۵ خالی است** (P0/P1/P2/S3/S4/S5 Medium+High+Low و P3 حذف کد-مرده بسته شدند).

## بررسی زیربچ ۶ (۲۰۲۶-۰۹-۱۹، تمام شد — بررسی فقط)

پوشش کامل ۴۷ فایل/~۱۵,۷۳۰ خط (Sentry/Search/زیرساخت/Settings/Analytics) با دو پاس کور موازی + تقاطع + راستی‌آزمایی عامل اصلی: **۳ High / ۱۲ Medium / ۱۶ Low** — همهٔ High/Mediumها خط‌به‌خط راستی‌آزمایی شدند (اسکیما، کرون، DI). حساس‌ترین‌ها: موتور قواعد الرت روی ستون‌های شبح (هرگز کار نکرده)، جستجوی کاربر بی‌provider (کور در production)، ارزیابی/تشدید الرت تماماً بی‌زمان‌بند. فیکس‌ها → `PENDING-FIXES-QUEUE.md` بخش S6. **باقی‌ماندهٔ بررسی کل پروژه: فقط پاس B زیربچ ۲.**
