# راهنمای چرخش Secrets و حذف .env از ریپو (CFG-001 / CFG-002)

> **شدت: بحرانی** — این راهنما برای یافته‌های بحرانی CFG-001 (secrets واقعی در `.env` موجود در ریپو) و
> CFG-002 (رمز ادمین plaintext در `.env`) تهیه شده است. تا وقتی چرخش انجام نشود، صرفِ حذف فایل از
> ریپو **کافی نیست** — هر secret‌ای که تاریخچهٔ git دیده است، لو رفته محسوب می‌شود.

## چرا چرخش (Rotate) اجباری است؟

`.env` با مقادیر واقعی (شامل `APP_KEY`، `SECURITY_API_TOKEN_SECRET`، رمز دیتابیس، `WEBHOOK_SECRET` و
`ADMIN_PASSWORD` plaintext) در ریپو بوده است. هر کسی که به ریپو دسترسی داشته (یا داشته) می‌تواند
تمام این مقادیر را از تاریخچهٔ کامیت‌ها استخراج کند. حذف فایل از HEAD، تاریخچه را پاک نمی‌کند.

## گام ۰ — قطع دسترسی فوری (قبل از هر چیز)

- همهٔ نشست‌های فعال و توکن‌های API را باطل کنید (پنل ادمین → نشست‌ها/توکن‌ها).
- رمز حساب ادمین اصلی را از پنل عوض کنید (CFG-002: `ADMIN_PASSWORD` هرگز نباید plaintext باشد؛
  در صورت وجود این کلید در `.env` تولیدیِ شما، مصرف آن را در seed/migrations غیرفعال کنید —
  جست‌وجو: `grep -rn "ADMIN_PASSWORD" database/ config/`).

## گام ۱ — چرخش مقادیر (روی سرور، نه در ریپو)

| کلید | روش چرخش |
|---|---|
| `APP_KEY` | کلید ۳۲+ کاراکتر تصادفی جدید بسازید (`openssl rand -hex 32`). ⚠️ اگر با APP_KEY چیزی رمزنگاری/امضا شده (کوکی‌ها، توکن‌ها) با کلید قدیمی است، طرح re-encryption داشته باشید یا نشست‌ها را باطل کنید. |
| `SECURITY_API_TOKEN_SECRET` | جدید بسازید؛ همهٔ API tokenهای صادرشده باطل و دوباره صادر می‌شوند. |
| `DB_PASS` | در MySQL/MariaDB: `ALTER USER 'chortke'@'localhost' IDENTIFIED BY '<رمز-جدید-قوی>';` سپس `.env` سرور را به‌روز کنید. کاربر `root` را برای اپ استفاده نکنید (CFG-004). |
| `REDIS_PASSWORD` | در redis.conf `requirepass` تنظیم و `.env` را هماهنگ کنید. |
| `WEBHOOK_SECRET` | ۶۴ کاراکتر hex جدید (`openssl rand -hex 32`) و با طرف مقابلِ وبهوک هماهنگ کنید. |
| هر secret دیگری | همهٔ کلیدهای `*_SECRET`/`*_KEY`/`*_PASSWORD` را فرض لو‌رفتگی بگیرید. |

## گام ۲ — حذف `.env` از ریپو و تاریخچه

1. `.env` را به `.gitignore` اضافه/تأیید کنید (الان موجود است) و `git rm --cached .env` بزنید.
2. پاک‌سازی تاریخچه با `git filter-repo` (ابزار رسمی GitHub):
   ```bash
   pip install git-filter-repo
   git clone --mirror <repo-url> repo-mirror && cd repo-mirror
   git filter-repo --path .env --invert-paths
   git push --force --mirror
   ```
   سپس همهٔ هم‌تیمی‌ها clone تازه بگیرند.
3. در GitHub/GitLab: پس از پاک‌سازی، از پشتیبانی بخواهید کش‌ها/فورک‌ها را هم پاک کنند (دسترسی به
   commitهای dangling از طریق SHA ممکن است باقی بماند).
4. **هیچ‌وقت** `.env` واقعی را commit نکنید؛ الگوی مجاز: `.env.example` (بدون مقدار واقعی).

## گام ۳ — گاردهای جدید (در این فیکس اعمال شده)

از این راند، `core/EnvValidator` در بوتِ production این‌ها را fail-fast می‌کند:

- `DB_USER=root` ممنوع؛ `DB_PASS` خالی ممنوع (CFG-004)
- `REDIS_PASSWORD` خالی روی host غیر-loopback ممنوع (CFG-004)
- `APP_DEBUG=true` در production ممنوع (CFG-003)
- `WEBHOOK_SECRET` خالی یا برابر placeholder عمومی ممنوع (CFG-005)
- کلیدهای مرده (`SESSION_SECURE`/`SESSION_HTTPONLY`/`CURRENCY_MODE`) هشدار حذف (CFG-003)

## گام ۴ — تأیید نهایی

- [ ] همهٔ secretها عوض شده‌اند و سرویس‌ها با مقادیر جدید بالا آمده‌اند
- [ ] `.env` از تاریخچهٔ ریپو پاک شده و فورک‌ها پاکسازی شده‌اند
- [ ] لاگ‌های دسترسی DB/Redis/پنل ادمین را برای بازهٔ افشا بازبینی کرده‌اید
- [ ] `php cli.php` (بوت) در production با `.env` جدید بدون violation بالا می‌آید
