# REVIEW_ROUND19.md — Round 19 second full parallel re-audit inventory

10 parallel review agents (domains: unit-tests, Services/Auth+Shared+Wallet+Score, Payment/Withdrawal/Investment/Lottery/Escrow/Ledger, Controllers User+Api+root, Controllers Admin, Jobs, Models+Listeners+Middleware, routes+config+Validators, views+public, R90-OAuth research).
Totals: P0=0 · P1=2 · P2=13 · P3≈50. All 68 fix items applied (FIX-R19 series) — see FIXES-SUMMARY.md Round 19 section.
Test status: tests/Unit = 2292 tests / 8737 assertions / 0E / 0F / 1 documented skip (re-verified twice, DB integrity checked via backup compare).


---

# SOURCE REPORT: agent-ctx/r19-test-failures.md

# Round 19 — tests/Unit Failure Inventory & Root-Cause (Task 19-A1)

Agent: test-failure-investigator | Date: 2026-09-20 | Project: /home/z/my-project/chortke
PHP: /home/z/tools/php (8.4.24, tokenizer.so) | PHPUnit 8.5.52 | DB: MariaDB via /tmp/mariadb.sock, db `chortk`

## 1. Headline result

**tests/Unit is GREEN: 0 errors, 0 failures.** The briefing's "~39 errors + 55 failures" is a **stale
pre-Round-16 snapshot**, not the current state. Confirmed by **two consecutive full runs** (identical):

```
Tests: 2292, Assertions: 8737, Skipped: 1.   (exit 0, ~18.4 s)
OK, but incomplete, skipped, or risky tests!
```

This matches the Round 18 FINAL worklog baseline exactly (Unit 2292/8737/0E/0F/1 skip).

## 2. Method (evidence chain)

1. Read worklog tail (R16/17/18 history) → R16/17 "cron fix rounds" resolved the old red suite;
   R18-L already proved the 39E+55F report stale.
2. Read `phpunit.xml` + `bootstrap/testing.php`:
   - Bootstrap injects self-contained test env (`APP_ENV=testing`, DB = **live `chortk` @ 127.0.0.1:3306
     root/no-pass** unless `CHORTKE_TEST_DB_*` env overrides → tests DO touch the live DB; no TestCase
     base class; no test-DB isolation = known Round-18 backlog risk).
   - `<groups><exclude>redis-unavailable` — Redis-down suites are intentionally out of the main run.
   - `failOnRisky=true`, `executionOrder=depends,defects`.
3. **Safety pad**: `mysqldump chortk` → `/tmp/r19-db-backup.sql.gz` (124 KB gz / 1.37 MB raw, exit 0,
   empty stderr) BEFORE running phpunit. Verified non-empty and that it contains seed users etc.
4. Run 1: `/home/z/tools/php -d extension=tokenizer.so vendor/bin/phpunit tests/Unit` → exit 0, green.
5. Grep of output for `Error:|Failed asserting|AssertionError|TypeError|exception` → **zero matches**
   (only the 1 documented skip + one cosmetic stderr line, see §5).
6. Run 2 (no -d flag needed, tokenizer already in php.ini) → identical green result. Not flaky, not
   order-dependent.

## 3. The only non-passing test (skip, deliberate — NOT a bug)

| Test file | Method | Verdict |
|---|---|---|
| tests/Unit/Services/S25ServicesContentOpsSecurityPinningTest.php:169 | testBulkCustomSqlIsTableWhitelisted | `$this->markTestSkipped()` — aspirational dead pin; `bulkCustomSql` never existed in any commit; building raw bulk-SQL was **rejected for security (approved R16 decision, FIX-R16C)**. Skip message is self-documenting. |

Root cause class: **test intentionally retired** — no action. If raw whitelisted bulk-UPDATE is ever
built, the pin block (lines 164-168) documents the exact strings that must then hold.

## 4. Root-cause classification of the historical "39E + 55F"

- **Environment/test-staleness mixture, all already fixed in Rounds 16–17** (per worklog: "the old
  ~39E+55F report was stale, resolved by cron fix rounds"; tokenizer.so was also added to
  /home/z/tools/php-ini/php.ini in R18, removing the missing-extension error class).
- Zero of those failures reproduce today → **0 production bugs, 0 outdated tests, 0 environment
  problems currently open in tests/Unit.**
- Round 18 did legitimately edit 2 stale test pins (S18/S10 OTP numeric; AuthService anti-enumeration
  oracle-parity) + added a CAS replay-rejection test — i.e. a small share of the historical 55F was
  "tests pinned to deliberate new contracts", fixed by updating the pins, not the code.

## 5. Cosmetic observation (no failure count impact)

- `[queue:work] error: Connection failed` appears mid-run (between test #427–488). Traced to
  `tests/Unit/Commands/QueueWorkCommandTest.php:106-117`: the test deliberately makes the worker mock
  throw `RuntimeException('Connection failed')` and asserts the error log. The message leaks to the
  console via STDERR, which `beStrictAboutOutputDuringTests` does not capture. **Expected behavior,
  not a defect.** Optional polish (not required): route the command's console echo through a
  test-inert sink.

## 6. Database integrity check

- Pre-run backup: `/tmp/r19-db-backup.sql.gz` (plain copy also at `/tmp/r19-db-backup.sql`).
- After 2 full runs, per-table row-count diff (backup restored into scratch db `chortk_r19chk`,
  compared, then dropped) — **6 tables differ, all test-infra, all additive; zero business tables touched**:

| Table | backup | live | Δ |
|---|---|---|---|
| queues | 2277 | 2364 | +87 |
| outbox_events | 147 | 165 | +18 |
| saga_executions | 98 | 110 | +12 |
| idempotency_keys | 22 | 26 | +4 |
| performance_logs | 136 | 137 | +1 |
| performance_transactions | 146 | 147 | +1 |

- `users` unchanged (5 seed/test rows, `AUTO_INCREMENT=296` shows historical test runs wrote ~290
  users that were later cleaned; current runs added 0 rows with created_at > 19:00).
- Main site health after runs: `curl http://127.0.0.1:3001/` → **200 OK**. No restore needed; backup
  retained for rollback.

## 7. Residual (backlog) risks — unrelated to test pass/fail

1. Tests run against the LIVE `chortk` DB (no `CHORTKE_TEST_DB_*` isolation) → infra tables
   (`queues`, `outbox_events`, …) grow every run. Fix suggestion: point test bootstrap at a scratch DB
   (env override already supported) or add post-suite cleanup.
2. `queues` table already holds 2.3k+ rows of residue from prior rounds.
3. Console stderr noise from QueueWorkCommandTest (see §5).

## 8. Conclusion / next actions

- No code changes made (constraint respected; `git status` clean, zero modifications in chortke/).
- No test fixes needed. Suite is a valid green baseline for Round 19 (2292/8737/0E/0F/1 documented skip).
- For Round 19 planning: treat the "~39E+55F" item as CLOSED (verified twice); recommended effort goes
  to the test-DB isolation backlog item instead.

---

# SOURCE REPORT: agent-ctx/r19-a2-bugs.md

# Round 19 — Task 19-A2 Bug Inventory
Agent: services-auth-reviewer | Scope: app/Services/Auth/** + Shared/** + Wallet/** + ReferralManagementService + Score/** + Gamification/**
Coverage: 27 files fully read line-by-line (Auth 9, Shared 8, Wallet 3, ReferralManagementService 1, Score 4, Gamification 2). Pattern scans: whereRaw/orderByRaw/DB::raw = 0 hits in scope; md5/sha1/eval/shell_exec/$_GET/$_POST/$_REQUEST = 0 hits in scope (md5 only in ScoreCommandService:529 as non-security idempotency-key hash).
Note: known/already-fixed items (FIX-R17B/E/F, FIX-R18B/N — R90 gate, batchPay hold exclusion, pending-referral branch, daily-limit/starting-bonus, SessionService country, ProcessRegistrationJob pending, ReferralService 日上限/起始奖励, PolicyService::clearCache, TwoFactor ghost force_2fa_regen) are NOT re-reported except where a residual defect remains.

## MEDIUM

1. app/Services/Shared/DisputeService.php:216-219 | MEDIUM | 竞态/缺CAS | resolveByAdmin 最终 `UPDATE disputes SET status=...` 只有 `WHERE id = ?`，无状态前置条件；两个管理员并发/双击可对同一 dispute 双执行（approve/reject 在 submission 层有守卫，但 dispute 行可被互相回写覆盖 admin_decision/refund_percent）。修复：`UPDATE ... WHERE id = ? AND status IN ('open','open_peer','under_review','escalated')` + rowCount==0 时报"已处理"。

2. app/Services/Auth/TwoFactorService.php:274-289 | MEDIUM | 非原子多写 | disable() 依次执行 updateTwoFactorSettings(enabled=0,secret=null) → revokeRememberToken → deleteTwoFactorCodes，无事务包裹；中途失败留下半禁用状态（secret 清空但 enabled=1 → 登录时 verifyTOTPCode 对空 secret 抛异常，用户被锁在 2FA 门外）。修复：包 `$this->db->beginTransaction()/commit/rollback`。

3. app/Services/Shared/ReferralService.php:820-822 (processCommission) | MEDIUM | 配置健壮性/bcdiv异常 | `$percentage = appSettings->get('referral_commission_percent', 5)` 只做 is_scalar 校验未做 is_numeric；管理员存入非数值（如 "5%"）时 `bcdiv($percentage,'100',8)` 抛 ValueError，且该段在 try 块之外 → 整个 processCommission 抛出，commission 流程反复失败。修复：`is_numeric` 守卫 + 非法值回退默认 '5'。

4. app/Services/Wallet/WalletMutationService.php:455-575 (processPay) | MEDIUM(防御纵深) | 负数/零金额校验缺失 | processPay 自身没有 `bccomp($amount,'0')>0` 校验（processDeposit:143 / spendLockedFunds:892 / releaseLockedFunds:1059 均有）；当前唯一入口 WalletService::executeAtomicOperation:157 统一校验，但任何直接调用 mutationService 的内部/未来路径，负数金额经 `bcmul($amount,'-1')` 变正数 → updateBalance 变成入账。修复：processPay 开头补与 processDeposit 相同的正数断言。

5. app/Services/Wallet/WalletMutationService.php:577-704 (processTransfer) | MEDIUM(防御纵深) | 同上 + 幂等列缺写 | processTransfer 亦无正数校验；且两条 createTransaction（:635/:649）均未写 `idempotency_key` 列（仅靠外层 IdempotencyService 的 key 表去重，transactions 行自身无 UNIQUE 兜底）。修复：补正数断言；将 explicitKey 传入 processTransfer 写入 transactions.idempotency_key 与其它 mutation 对齐。

## LOW

6. app/Services/Auth/AuthSessionManager.php:216 | LOW | 状态黑名单不一致 | verifyByRememberToken 拒绝列表 ['locked','locked_2fa','banned','suspended'] 缺 'deleted'（loginDirectly:280 的 hardBlockedStatuses 含 'deleted'）。App\Models\User::findByRememberToken:723 有 `deleted_at IS NULL` 兜底，故仅在"status=deleted 且 deleted_at 为空"的数据漂移下可绕过。修复：列表加入 'deleted' 对齐。

7. app/Services/Auth/AuthSessionManager.php:176-195,204-232 | LOW | 凭证不轮换 | remember-cookie 登录成功后 token 不轮换、无 reuse-detection；cookie 泄露后长期有效（30 天）。修复：verifyByRememberToken 成功路径轮换 token（发新 cookie + 旧 hash 失效）。

8. app/Services/Auth/AuthService.php:222-224 | LOW | 死代码/不可达分支 | 密码失败路径 `if ($this->db->inTransaction()) $this->db->commit();` 不可达 — 事务已在 :174-176 提交（S5-M5 lock 提前释放）。修复：删除该块。

9. app/Services/Auth/TwoFactorService.php:439 | LOW | 幽灵列写入（已知遗留） | `update($userId, ['force_2fa_regen' => 1])` 写不存在列（fillable 丢弃，no-op）；Round-18 worklog 已记录为"不修复"。建议：删除该调用与伴随 flash，或落地真实迁移列。

10. app/Services/Auth/GoogleJwtVerifier.php:112-121 | LOW | 时钟偏移/iat 可选 | exp 校验无 leeway（边界秒误拒）；`iat` 检查仅在存在时执行（无 iat 的 token 通过），且 exp/iat 未校验为数值（intval('abc')=0 → fail-closed，可接受）。修复：exp 加 ±30s leeway；无 iat 时拒绝。

11. app/Services/Auth/LoginRiskService.php:427-430 | LOW | 未签名回退 | decodeSignedPayload 对无 '|' 的旧格式按未签名 JSON 接受 — 能写 Redis/Cache 的攻击者可伪造失败计数抬高 captcha 要求（DoS 级）。修复：移除未签名回退分支。

12. app/Services/Auth/LoginRiskService.php:238-275 | LOW | 计数竞态 | recordFailure 为 get→modify→set 非原子，并发丢失计数导致风险分低估。修复：INCR + 首次设置 TTL（或 Lua）。

13. app/Services/Auth/SessionService.php:447 | LOW | 条件放大 | `isAnomaly = $score >= 50 || !empty($anomalies)` — 任一单条异常（如单次 UA 变化 40 分）即计 anomaly 并写 fraud_event，分数阈值形同虚设。修复：确认产品意图；否则只按分数阈值。

14. app/Services/Shared/ReferralService.php:1338 (checkAndUpgrade) | LOW | INSERT IGNORE 语义 | referral_tiers 若 user_id 有 UNIQUE，INSERT IGNORE 使 tier/bonus_percent 永远停留在首次写入值（升级永不落库）；且 `max(1,(int)$bonus)` 把 0 抬为 1。修复：改为 ON DUPLICATE KEY UPDATE tier_name/bonus_percent，或先查后 upsert。

15. app/Services/Shared/ReferralService.php:1626-1629 (distributeMonthlyRewards) | LOW | 脆弱幂等探测 | 重复月度奖励探测用 `payload LIKE '%"idempotency_key":"referral_top_bonus_YYYY-MM"%'` 字符串匹配 — payload JSON 转义/键序变化即失配 → 重复 outbox 行（最终由 wallet UNIQUE 兜底）。修复：JSON_EXTRACT 或专用去重表。

16. app/Services/ReferralManagementService.php:120-152 | LOW | 展示层过滤缺失 | getMonthly/YearlyLeaderboard 未过滤 `u.deleted_at IS NULL`（被删用户仍出现在榜单并展示 email）。修复：JOIN users 时加 deleted_at IS NULL。

17. app/Services/Shared/CouponService.php:323-327 | LOW | token 消费时机 | redeem() 在事务闭包内 forget 校验 token；若闭包返回后 commit 阶段失败（runWithRetry 重试/回滚），token 已被烧。极边缘。修复：移到 runWithRetry 成功返回后消费。

18. app/Services/Auth/PasswordRecoveryService.php:138-178 | LOW | token 早消费 | resetPassword 先 findAndConsumePasswordResetToken（原子消费）再校验 email 匹配/密码策略；任一失败路径烧掉 token，用户需重新申请重置邮件。修复：先校验后消费（或失败时恢复）——需权衡保留原子消费的抗竞态语义。

## 已核查无误（重点区域）
- WalletMutationService：deposit/withdraw/pay/hold 全部 FOR UPDATE 行锁 + 事务 + UNIQUE(idempotency_key) 竞态兜底（isDuplicateKeyViolation 归一为幂等重放）；Wallet::updateBalance 有 `(:amount_check >= 0 OR field >= ABS(amount_abs))` 防负余额 + frozen 守卫（Wallet.php:213-218）；lockBalance/unlockBalance/deductLocked 均强制正数并带余额条件；spendLockedFunds/releaseLockedFunds/completeWithdrawal/cancelWithdrawal 均 CAS（updateStatusByTransactionId 带 from-status 条件）防双花；reverseTransaction claimForReversal CAS + escrow 管辖拒绝。
- WalletService：所有 mutation 经 executeAtomicOperation（正数/币种校验 + IdempotencyService::executeWithLock + wallet:mut:{uid} 分布式锁，锁失败 fail-closed）；transfer 按 id 排序双锁防死锁、 FraudGuard 直查（FIX-S18-1）、M-15 收件人入幂等键。
- ReferralService 金额路径：awardSignupBonus/awardStartBonus/checkAndAwardBonus/processCommission/processMultiTierCommissions/creditPendingReferralRewardOnFirstTask 全部 FOR UPDATE + idempotency_key（UNIQUE 兜底）+ 多层 pre-check；daily limit fail-closed（increment===false 拒绝）；batchPay M-22 稳定键 + X330 精确金额 + R18N hold 排除。
- ReferralAntiFarmingGate / guardRewardCredit：与 R18 设计一致（fail-open 为文档化契约）。
- AuthService.performLogin：dummy-hash 时间均衡、未验证邮箱带密码门（S15-3b）、锁前释放（S5-M5）、防枚举。
- IdempotencyService / IdempotencyKeys：契约清晰，p2pTransfer hash+发件人绑定。
- CouponService：validateAndRedeem FOR UPDATE 全链 + entity 幂等 + incrementUsage；两处 redeem() 调用方（InfluencerCommandService:502 / AdSystemManager:587）均经服务端 token 绑定金额，无任意折扣面。
- PolicyService / DashboardStatsService / BatchLoader（唯一调用点字面量列名，$columns 参数无用户输入路径）/ Score 4 文件（X357 post-commit 缓存、S3-H3 claim 释放、fail-closed 查询）/ Gamification 2 文件（X363 原子批量、S3-L4 clamp）。
- OAuthService：state HMAC 绑定 IP+session+TTL、regenerate 前置；GoogleJwtVerifier RS256/ kid 轮换刷新/签名验证正确（除 #10）。

---

# SOURCE REPORT: agent-ctx/r19-a3-bugs.md

# Round 19 — Task 19-A3: Payment / Withdrawal / Investment / Lottery / Escrow / Ledger line-by-line review

Scope: app/Services/Payment/** (11), Withdrawal/** (3), Investment/** (2)+InvestmentService, Lottery/** (4),
PredictionService, EscrowService, Domain/Financial/Services (2), ManualDepositService, SeoPayoutService,
ScheduledPaymentService. 26 files fully read. Supporting spot-checks: Models/Escrow.php, WalletService/WalletMutationService
(cancelWithdrawal CAS), AppServiceProvider gateway resolver.

Round16/17 known-fixed items (fulfillCryptoDeposit removal, cryptoDepositApprove idempotent gate,
verification_status gate, admin sort whitelist) NOT re-reported.

Severity: P0 = direct fund loss/theft now; P1 = fund-integrity corruption reachable in prod; P2 = defense-in-depth
gap / race relying on downstream guard; P3 = hygiene.

---

## P1

### FES-1 | app/Domain/Financial/Services/FinancialEscrowService.php:410-430 (holdInfluencerOrderFunds)
Type: ignored mutation result + missing wallet idempotency → escrow funded on paper without money locked; double-hold race.
- `deduct_wallet_balance` step: `$this->wallet->withdraw(...)` return value is completely ignored (no
  `empty($res['success'])` throw — contrast holdCustomDealFunds:217-227 which checks it). If withdraw fails
  for any reason other than the pre-checked balance (wallet frozen `is_frozen=1`, fraud-block inside wallet,
  missing currency wallet), the saga continues, escrow goes to `in_escrow`, **no hold transaction exists**.
  Every later release/refund path then dies on `findEscrowHoldTransaction → NotFoundException` → order stuck,
  financial state corrupted (escrow says funds held; ledger/wallet say nothing was locked).
- No `idempotency_key` passed to `withdraw` (custom_deal path passes `custom_deal_hold_{orderId}`), and
  `escrow->holdFunds(...)` is called **without** the idempotencyKey arg (line 389-396, cf. custom_deal:211)
  → IdempotencyService falls back to unguarded execution. Two concurrent requests for the same order both pass
  `findByOrderId` (no lock, check-then-act) → **two escrow rows + two wallet holds** (buyer double-charged).
Fix: check withdraw result and throw; pass `'idempotency_key' => "influencer_escrow_hold_{$orderId}"`;
pass `"influencer_escrow_record_{$orderId}"` to holdFunds; add UNIQUE(order_id, order_type) on escrow_transactions.

### FES-2 | app/Domain/Financial/Services/FinancialEscrowService.php:607-628 (holdVitrineFunds)
Type: identical pattern to FES-1.
- `$this->wallet->withdraw(...)` result ignored (line 612), no wallet idempotency_key, and
  `holdFunds(..., 'USDT')` called without idempotencyKey (line 587-594). Same consequences: escrow in_escrow
  with no hold, or concurrent duplicate escrow+hold for the same listing.
Fix: mirror holdCustomDealFunds (check + `"vitrine_escrow_hold_{$listingId}"` + record key + UNIQUE index).

### FES-3 | app/Domain/Financial/Services/FinancialEscrowService.php:1149-1179 (findEscrowHoldTransaction)
Type: fragile amount-matching lookup used as sole settlement anchor.
- Hold lookup matches on `ABS(amount - ?) < 1e-8` + `metadata LIKE '%"type":...%'` + `(ref_id=? OR metadata LIKE
  '..."order_id":<id>%' OR listing_id OR execution_id)`, `ORDER BY id DESC LIMIT 1`. Two same-amount holds of the
  same type for the same buyer (e.g. two vitrine purchases of the same listing price, or after FES-1/2 dup) can
  resolve to the WRONG hold row; settlements/finalize then finalize the wrong transaction. Metadata LIKE patterns
  are also order-id-suffix-collision prone (`%"order_id":12%` matches 123).
Fix: pin hold by exact ref (`ref_type+ref_id`) at hold time (store escrow_id in hold metadata at creation) and
match on that column, not on JSON LIKE heuristics.

## P2

### FES-4 | app/Services/Investment/InvestmentCommandService.php:328-348, 357-399 (approveWithdrawal)
Type: missing FOR UPDATE on withdrawal row in both saga steps.
- `transfer_to_wallet` and `finalize_status` re-read via `$this->withdrawalModel->find()` (no lock) inside the
  tx. Concurrent approveWithdrawal ×2 (or approve + rejectWithdrawalJob) both see `pending`. Double deposit is
  only prevented by the wallet-level `idempotency_key = investment_withdrawal_{id}` (best-effort single key, and
  `idempotent_replay` is not re-checked here like consumeHeldBudget does at :1249); status CAS also absent
  (`update()` is a blind write guarded only by re-read).
Fix: `SELECT ... FOR UPDATE` (model->findForUpdate) in both steps + CAS
`UPDATE ... WHERE id=? AND status='pending'` + treat replay like consumeHeldBudget does.

### PAY-1 | app/Services/Payment/PaymentCommandService.php:528-572 (verifyIpWhitelist)
Type: wildcard whitelist over-matching.
- `str_replace(['.','*'],['\\.','.*'])` turns any whitelist entry into an unanchored-in-class regex; `.*` matches
  anything including extra dots/characters (e.g. entry `1.2.3.*` matches `1.2.3.x` but also crafted headers if
  get_client_ip() ever trusts XFF). Whitelist is the outer gate (before nonce/verify).
Fix: convert wildcard to `(\d{1,3})` groups with boundary checks, or use ip_match with CIDR.

### LOT-1 | app/Services/Lottery/LotteryCommandService.php:364-535 (selectWinner)
Type: prize deposit idempotency key is round-scoped, but settlement loop hard-fails whole round.
- `spendLockedFunds` per participant uses `lottery_ticket_settlement_{participant_id}` (good), but if ANY single
  participant's hold is missing the whole saga throws → round stays active and cannot ever complete without
  manual DB surgery. Combined with FES-style hold lookup by `ref_id + status pending/processing ORDER BY id DESC`,
  a participant with two ticket holds (from a cancelled-then-rejoined round; cancel marks hold `cancelled` so
  OK, but a retried participate creates a second active hold) settles the WRONG hold.
Fix: same pin-by-id metadata approach; also make per-participant settlement errors skip-and-report instead of
aborting the entire round settlement mid-way (it is atomic, so abort is safe but bricked).

### INV-1 | app/Services/Investment/InvestmentCommandService.php:421-465 (applyLoss)
Type: no upper bound on loss vs current balance.
- `GREATEST(current_balance - ?, 0)` clamps balance, but `total_loss += ?` and `profit_earned -= ?` apply the
  full amount → profit_earned can go far negative and total_loss overstates real loss; solvency report
  (InvestmentQueryService::getSolvencyReport) then understates real assets.
Fix: cap loss at `LEAST(?, current_balance)` or reject when loss > current_balance.

### WD-1 | app/Services/Withdrawal/WithdrawalUserService.php:71-174 (guardCanCreateWithdrawal)
Type: no currency whitelist / no absolute max amount.
- `$currency = strtolower(...)` accepts anything; non-`usdt` falls into IRT branch of minimums while
  `wallet->withdraw` gets the raw currency; createWithdrawal records `method='bank_card'` for any non-usdt.
  Amount bounded only by daily/weekly/monthly aggregates (which are per-currency keys → unknown currency has
  limits keyed to that unknown string → defaults apply).
Fix: whitelist `['irt','usdt']` and reject anything else; add sanity max per attempt.

## P3

### PAY-2 | PaymentCommandService.php:292-295 — authority fallback chain includes generic `id`/`token`; combined with
testing-bypass branch in validateAuthorityFormat (:577) this is fine in prod, but the `$pattern` default
`[A-Za-z0-9\-_]{10,100}` accepts unknown gateway names' arbitrary ids — acceptable, noted for completeness.

### PAY-3 | PaymentAdminService.php:82 — raw gateway/exception message returned to caller
(`'Error communicating with gateway: ' . $e->getMessage()`); admin-only surface, but leaks adapter internals to
UI/audit view. Sanitize like PaymentService facade does.

### PAY-4 | BasePaymentGateway.php:34-46 — `$nonRetryableExceptions` is declared but never consulted by RetryPolicy
wiring (only retryableExceptions passed at :279-283); PaymentVerificationException non-retry works only because
it isn't in retryable list. Dead config = future foot-gun.

### PAY-5 | MockPaymentGateway.php:39-47 — verifyCallback returns true in non-production regardless of provided
signature content; harmless post S4-H3 (factory blocks mock in production), but the mock's verifyPayment echoes
caller's amount — keep mock out of any non-test container wiring.

### ESC-1 | EscrowService.php:145-205 (holdFunds) — existence pre-check `findByOrderId` has no FOR UPDATE/UNIQUE
backing; safe today only because all current callers (holdCustomDealFunds, FES-1/2 flows) run inside
transactional + their own guards. After fixing FES-1/2 add UNIQUE(order_id, order_type, status<>cancelled)
to make it structural.

### SEO-1 | SeoPayoutService.php:68-74 (calculatePayout) — `$finalScore/100` float→string can yield E-notation
(e.g. 1.0E-6) which bcmath silently truncates to 0 → payout collapses to min_payout instead of proportional.
Internal score source + min_score gate ≥ default 40 makes it cosmetic; still switch to bcmath-safe
number_format($finalScore/100, 8, '.', '').

### FES-5 | FinancialEscrowService.php:911-919 (releaseExpiredHolds) — `{$expiredHours}`/`{$batchSize}` interpolated
into SQL; both are hard-bounded ints (max(1,min(8760,…)) / constant) so not injectable, but the pattern invites
copy-paste with unbounded values. Use bound params.

### WD-2 | WithdrawalAdminService.php:97-101 (calculateFee) — fee not capped at withdrawal amount; admin-set
percent >100 → final_amount clamped to 0 but ledger fee leg (withdrawal_payout→platform_revenue) exceeds the
withdrawal, unbalancing per-withdrawal reconciliation. Cap fee ≤ amount.

### LOT-2 | LotteryCommandService.php:387-416 — weighted selection uses float accumulation of chance_score;
weights up to ~100×participants; float precision is irrelevant at this magnitude (documented OK), but
`randomValue <= cumulative` biased boundary is harmless. No action needed; noted.

### INV-2 | InvestmentCommandService.php:189-192 — `outbox?->recordEvent(...)` failure would abort saga after
wallet hold; recordEvent throwing is unguarded here (other services wrap outbox in try/catch). Outbox failure =
investment rolled back = user-facing failure; acceptable but inconsistent with non-blocking outbox contract.

---

## Verified-clean (no action)
- PaymentCommandService::callback money path: nonce hash_equals gate, 2h/25h expiry state machine, amount
  bccomp gates at 3 layers (callback payload / performPreVerification / validatePreVerifiedResult),
  FOR UPDATE lockPaymentRecord, status CAS via verifyLockedPaymentStatus, idempotency wrap, saga with
  reverse-transaction compensation, outbox single-notify (dup packet removed). Solid.
- All 4 fiat gateways: normalizePositiveTomanAmount (whole-Toman, bccomp), exact ×10 rial conversion,
  verified-amount mismatch → fail-closed, provider-amount-missing → fail-closed (IDPay S4-L1), masked
  authority in logs, SSRF-guarded URLs, sandbox blocked in production.
- Mock gateway fail-closed in production (AppServiceProvider:163-165).
- IP whitelist + rate limit fail-closed in production; internal S2S bypass only for reconcile path.
- PaymentDepositService::approveManualDeposit: self-approval block, FOR UPDATE re-check, in-TX compensation
  guards, wallet idempotency_key manual_deposit_approve_{id}.
- Withdrawal trio: guard layer (KYC/fraud/pending/daily-once/3-tier limits, all bccomp 8dp), hold→record saga in
  one tx, adminApprove self-approval block + crypto-destination requirement + tracking-code dup check + fee
  ledger double-entry + fee tx fail-loud; adminReject FOR UPDATE + CAS status (S4-M4); cancelWithdrawal CAS in
  WalletMutationService prevents double-refund (verified — amount arg ignored, tx amount used).
- Investment create: atomic one-active-investment re-check under FOR UPDATE (M-21), balance preflight
  fail-closed, hold→save→settle saga with ledger_credit investment_pool; withdrawProfit per-cycle idempotency
  key (S4-H4) with deposit-before-zero ordering.
- EscrowService: partialRelease & resolveDisputePartial — positive-amount gates, refund+release == amount
  equality gate, FOR UPDATE finders (verified in Models/Escrow.php), rowCount===1 CAS on final UPDATE,
  per-leg wallet idempotency keys; state-only release/refund correctly delegate money to FinancialEscrowService.
- FinancialEscrowService::refundEscrowToBuyer / releaseCustomDealFunds / releaseInfluencerOrderFunds /
  releaseVitrineFunds / resolveDisputedEscrow (single-settler S25) / consumeHeldBudget (idempotent_replay
  guard) / refundHeldBudget: locks + keys + equality gates all present.
- LedgerService: double-entry enforced in-transaction, imbalance anomaly capture, batch balance safe.
- ScheduledPaymentService: per-payment atomic tx, lock-order fix honored, invalid-frequency fail-fast,
  hold-settlement with no-orphan guarantee, reconciliation check.
- ManualDepositService: service-layer money guards (C03 set), receipt-path allowlist, tracking-code idempotency,
  self-approval block via PaymentDepositService, card masking (no raw PAN).
- Lottery participate: round FOR UPDATE window+capacity+single-participation checks; selectWinner pool
  sufficiency gate (S4-L10); cancelRound per-participant CAS refund.
- PredictionService/InvestmentService/LotteryService facades: pure delegation, exception mapping OK.

Stats: files reviewed 26 (+4 supporting) | P0=0 P1=3 P2=4 P3=11
Key finding in one line: the two "hold" sagas (influencer/vitrine) ignore the wallet withdraw result and skip
idempotency keys — the only place in the whole escrow stack where a money mutation is fire-and-forget.

---

# SOURCE REPORT: agent-ctx/r19-a4-bugs.md

# Round 19 — Task 19-A4: Controllers/User + Controllers/Api + Root Controllers Review

Agent: user-api-controllers-reviewer | Scope: app/Controllers/User/** (33), app/Controllers/Api/** (13), root-level app/Controllers/*.php (17) + cross-checks (routes/system.php, routes/public.php, core/Response.php, FileAccessService, UploadService::getPath)
READ-ONLY: zero files modified in chortke/.

## Findings

### P2 (2)

1. **app/Controllers/Api/InteractionApiController.php:81-86 | P2 | Mass-assignment / validation gap (18-F carryover, NOT fixed)**
   `vitrineTradeRequest()` merges the raw JSON body into `VitrineRequest::createRequest(array_merge($data, [...]))` with no numeric/range check on `offer_price` (the web path validates it) and no field whitelist before the model call. Only `listing_id`, `requester_id`, `buyer_id`, `status` are overwritten after the merge. If the model's fillable is open, client-supplied keys (e.g. `seller_id`, fee/escrow-ish columns, `owner_id`-like fields) can ride into the INSERT. Fix: whitelist allowed request fields + validate `offer_price` as numeric >= min before `createRequest` (mirror web VitrineController).

2. **app/Controllers/User/NotificationController.php:284-286 | P2 | click() redirect breaks on external action_url (mutation already applied)**
   `click()` calls `recordClick()` + `trackAdNotificationClick()` (click budget debit + viewer reward) + `markAsRead()` and only then `$this->response->redirect($notif->action_url)`. `Core\Response::redirect()` (core/Response.php:203-228) THROWS `InvalidArgumentException` for any absolute URL whose host != site host, and `action_url` is admin/job-supplied (`Admin\NotificationController:81`, `SendToAll/SendToSegment` jobs pass `$actionUrl` through, `SendNotificationRequest` allows any string ≤2048). Result: every notification whose action_url is an external link ends in an error page AFTER state was mutated — user sees failure, advertiser budget/one-shot reward already consumed. Fix: if action_url is absolute http(s) → `redirectExternal()` (or BannerController-style host whitelist), else redirect internal; order redirect decision before mutation or make it exception-safe.

### P3 (8)

3. **app/Controllers/User/BankCardController.php:99,125 | P3 | Sensitive old-input flashed (18-F carryover, NOT fixed)** — on validation failure AND service failure, the full raw `$input` (incl. normalized `card_number` + `sheba`) is flashed as `old` and re-rendered into the form value on the next page. Fix: flash only `bank_name`/cardholder + masked card tail.

4. **app/Controllers/User/CryptoDepositController.php:178,193 | P3 | Wrong failure message (18-F carryover, NOT fixed)** — `store()` throws `RuntimeException($result['message'])` but the catch replaces it with flash `'خطا در دریافت لیست'` (list-fetch message) for ANY store failure. User never sees the real reason (e.g. duplicate tx_hash). Fix: flash `$e->getMessage()` (it is service-authored Persian text) or a store-specific generic.

5. **app/Controllers/User/CouponController.php:38 | P3 | php://input read bypasses Request wrapper (18-F carryover, NOT fixed)** — `json_decode(file_get_contents('php://input'))` instead of `$this->request->json()`. Same pattern in `User\MessageController` (per 18-F). Fix: use the Request layer (X160 gate).

6. **app/Controllers/User/AdsApiController.php:42,46,63,71,91,101,131,200,208 | P3 | Raw `echo json_encode` bypasses Response exception architecture (X342 class, 18-F carryover, NOT fixed)** — direct echo after `header()`; inconsistent with the codebase's HttpResponseException contract. Fix: `$this->response->json(...)`.

7. **app/Controllers/User/EscrowController.php:66 (+ Api\WalletController lottery/escrow paths) | P3 | 6-digit random orderId birthday-collision (18-F carryover, NOT fixed)** — `random_int(100000,999999)` as public deal id; collisions fail with "Escrow already exists" (money-safe thanks to service guard, but spurious UX failure grows with volume). Fix: 8+ digit or time-seeded order id.

8. **app/Controllers/Api/SecurityController.php:68-77 | P3 | logEvent() logs unsanitized arbitrary client payload** — unlike cspReport() (key allowlist, 255-char bound, query stripped), `logEvent()` writes the whole JSON body into logs with no key filter/length cap. Log-spam/PILFer vector (any visitor can grow system_logs). Fix: allowlist keys + mb_substr bounds + rate limit like CSP endpoint.

9. **app/Controllers/MetricsController.php:46-47,257-258 | P3 | Health token still accepted via query string** — `?token=` fallback kept "for existing monitoring" (FIX-S15-6 header-first migration incomplete); token lands in access logs/proxy logs/history. Same contract in HealthCheckController is header-only — this one is not. Fix: finish the deprecation (drop query fallback).

10. **Write-side URL scheme validation still missing at input (backlog per worklog:1440):**
    - app/Controllers/Api/VerificationController.php:119-132 (`proof_url` accepted as any non-empty string),
    - app/Controllers/Api/InfluencerController.php:184-201 (`post_url` same),
    - user-side influencer verification equivalent.
    Render-side sanitize_url fixes landed in 18-O, but javascript:/data: URLs are still ACCEPTED at creation (only `FILTER_VALIDATE_URL`-ish checks downstream). Fix: `ValidatesExternalUrl` / sanitize_url-style scheme whitelist at every write site (4 P0 URL fields noted in R18 remain: ad link/target_url, proof_url, post_url, screenshot).

### Verified clean (no issue)
- **FileController + FileAccessService + UploadService::getPath**: strict folder regex `[a-zA-Z0-9_-]+`, filename `captcha_hex16|hex8-64.ext` only, realpath-constrained path, disk MIME whitelist, inline only for images / forced attachment+CSP sandbox for pdf/video, per-folder DB ownership checks (kyc/receipts/proofs/tickets/messages), denied-access logging, admin bypass role-based. Route GET rate-limited. No traversal, no IDOR.
- **DebugController**: route only registered when `config('app.debug')` (routes/system.php:33-35) AND behind Auth+Admin+AdminPermissionGuard; output htmlspecialchars'd; reads only Router.php. Not production-exposed.
- **TestCaptchaController**: routes registered only for non-prod env (routes/public.php:74-77) + in-controller env/TEST_TOOLS_ENABLED fail-closed guard (abort 404). Not production-exposed.
- **MetricsController::metrics/health**: IP-allowlist fail-`in_array` + hash_equals token gate (127.0.0.1/::1 default = fail-closed for remote).
- **OAuthController**: no open redirect (all redirects via url()/redirectExternal to provider-built URLs); state HMAC+session+IP handled in service; confirmPassword = 600s session-bound pending link + password verify + status check + loginDirectly (CRIT-05 intact).
- **PaymentController**: session-bound userId, CreateDepositRequest validation, POST-only callback (405 otherwise), GET-callback blocked with per-IP counter + logging, redirectExternal for gateway URL (CRLF+scheme guarded).
- **User AuthController**: enumeration-hardened (FIX-S15-3/3b intact), R90 anti-farming gate via shared ReferralAntiFarmingGate, register `only([...])` field allowlist, terms enforced server-side (FIX-X90), token/OTP HMAC-hashed + single-use (X45), reset token bound to DB email (CRITICAL-01), logout POST+CSRF+session-owner check (MED-02/HIGH-01). Register validation-failure log of $data is mitigated by Logger redactSensitiveValues.
- **User TwoFactorController**: password re-auth (5/min RL, 600s window) gates secret/QR (S14-7), pending-2FA session binding + 10-min TTL + IP-subnet drift → fraud score, brute-force 5/min, admin-pending isolation (CRITICAL-02), disable requires password.
- **User KYCController**: triple rate limit (user/ip/fingerprint), PII masking (X168), IDOR-guarded show() for both HTML and AJAX (K-08/X193 fail-closed whitelist).
- **User WithdrawalController / TransferController / WalletController / InvestmentController / LotteryController / PredictionController / ManualDepositController / CryptoDepositController / EscrowController**: all userId from session; FormRequest validators + safeValidated (X16); idempotency keys threaded to services; service-level business guards (Luhn/IBAN, amount caps, escrow_exists, FOR UPDATE) verified in R18 — no client-trusted amounts, no IDOR. Investment store has Redis double-submit lock (NX 3s).
- **User SessionController / SettingsController / ProfileController**: terminate scoped to owner; settings via UserSettingsService (DEFAULT_SETTINGS key whitelist); avatar upload whitelisted mimes/2MB + rollback deletes; account deletion re-verifies password (X56b).
- **User SocialTask/Seo/CustomTask/TaskFeed/AdsApiController/Referral/Dispute/Influencer**: executor/participant ownership via service or explicit executor_id check; C-12 profile whitelist + owner check (403 on foreign update); engagement/behavior payloads type-checked and only used server-side (R18-N #5 wiring intact); claimRewards kill-switched (18-N #3); no raw SQL, no client user_id.
- **Api\TokenController**: issue rate-limited 8/10min fail-closed keyed HMAC(ip|email), revoke scoped by user hash, list/revokeById owner-scoped.
- **Api\UserController / Api\WalletController**: 18-N fixes confirmed in place (account-deletion password re-auth, generic 500 messages, BusinessException pass-through, HttpResponseException rethrows); bank cards masked (last-4), receipt_path stripped, markRead/sessionsRevoke owner-scoped.
- **Api\RealTimeController**: H-09 room authorization on join/members/presence (fail-closed), poll 20s cap + bulkhead 429.
- **Api\HealthCheckController**: validateAccess fail-closed (empty allowlist denies), header-only token, metrics/distributed gated (M-34).
- **Api\SocialTaskApiController**: behavior signals field-whitelisted; camera fallback only when service absent; resolveUser session-first.
- **Root HomeController/CaptchaController/ContactController/SearchController/BannerController/FaviconController/PageController/SitemapController/RobotsController**: no auth issues; BannerController click redirect host-whitelisted; FaviconController SVG CSP+nosniff+escaped letter (S15-8/S15-2); search endpoints multi-layer rate limited, admin search behind admin route middleware.
- **Routes exposure sweep**: /file/view rate-limited public; /admin/debug/router debug-gated admin-only; /test-captcha non-prod only; /metrics token/IP-gated; no uncovered mutating route found in scope beyond the already-fixed 18-N items.

---

# SOURCE REPORT: agent-ctx/r19-a5-bugs.md

# Round 19 — Task 19-A5: Line-by-line review of app/Controllers/Admin (~60 files)

Agent: admin-controllers-reviewer | Date: 2026 (R19) | Scope: all 56 files in app/Controllers/Admin + routes/admin.php + routes/system.php + config/admin_permissions.php + BaseAdminController/BaseController + AdminMiddleware/AdminPermissionGuard.
Known-already-fixed (not re-reported): User/Transaction `normalizeAdminSort` + ADMIN_SORTABLE_SQL_MAP ORDER-BY whitelist; POST /admin/logout guard+CSRF.

## Bug list (file:line | severity | type | description | fix)

1. app/Controllers/Admin/UserController.php:515-532, 534-551 | P2 | Privilege-hierarchy gap + missing audit | `unban()` / `unsuspend()` do NOT have the role-hierarchy guard (`adminRoleLevel < 2 && targetLevel >= 1` block) that the sibling `ban()` (:347-354) and `suspend()` (:475-482) have, and they write no `auditLog` either. Any admin-area role holding `user.manage.ban` can un-ban / un-suspend another admin or super_admin with zero audit trail. | Mirror ban()/suspend(): add hierarchy check + self-check + `auditLog('user.unban'|'user.unsuspend', ...)`.

2. app/Controllers/Admin/NotificationController.php:71-153 | P2→P3 | Stored URL scheme risk | `send()` stores admin-supplied `action_url` into notifications without an http/https scheme whitelist (SendNotificationRequest not verified to enforce scheme; `FILTER_VALIDATE_URL` accepts `javascript:`). Notification `action_url` flows to end users (in-app + FCM). | Whitelist scheme at validation (http/https only) and render through `sanitize_url()` in user-side notification views/outbox.

3. app/Controllers/Admin/AuthController.php:213 vs :252 | P3 | Inconsistent timeout | Admin pending-2FA expiry is 300 s in `showVerify2FA()` but 600 s in `verify2FA()`; the POST accepts a pending state the page would already have killed. | Unify to a single constant (e.g. 300 s) in both methods.

4. app/Controllers/Admin/AuthController.php:214-216 | P3 | Flash after destroy | `showVerify2FA()` calls `$this->session->destroy()` and then `setFlash(...)`; the flash may not survive on a fresh/destroyed session, so the user may land on login with no error message. | Set flash before destroy (or destroy after building redirect response).

5. app/Controllers/Admin/LogController.php:196-217, 253-300 | P3 | Dead/unrouted endpoints + raw output | `show()` and `export()` have no route in routes/admin.php (dead code). `export()` also bypasses the framework with raw `header()/echo/exit`. RBAC map has no override for `export` (would fall back to `logs.view` if ever routed). | Delete both methods or register routes + add `export => logs.manage` mapping; if kept, stream via Response.

6. app/Controllers/Admin/MaintenanceController.php (whole file; :44,:59,:75,:90) | P3 | Dead controller + swapped setFlash args | No route anywhere (admin.php/system.php/missing.php) references MaintenanceController — enable/disable/status are unreachable. Additionally `setFlash('message','key')` argument order is reversed in all 4 calls (opposite of project convention `setFlash(key,message)`), so even if routed the flash would not display. | Route it or delete; fix setFlash arg order.

7. app/Controllers/Admin/VitrineController.php:190-210 | P3 | Missing audit on fund-affecting verdict | `resolve()` decides buyer/seller winner for an escrow dispute but records no `auditTrail->record(...)` while sibling actions approve (:104), reject (:142), releaseFunds (:239), refund (:264) all do. | Add `vitrine.admin_dispute_resolved` audit entry (winner + listing id + admin id).

8. app/Controllers/Admin/FraudManagementController.php:84-101 | P3 | Missing input validation | `blockDevice()` stores `fingerprint` with no non-empty/length/format validation (blockIP at :38 validates IP properly). An empty/oversized fingerprint can be inserted. | Validate non-empty + max length (e.g. 128 chars) before `blockDevice()`.

9. app/Controllers/Admin/TransactionController.php:152-178 | P3 | TOCTOU pre-read | `reverse()` checks `status === 'reversed'` on a plain read, then calls `walletService->reverseTransaction()`; double-reverse protection depends entirely on service-side CAS. | Confirm/enforce CAS (status-gated UPDATE) inside WalletService::reverseTransaction; keep controller pre-check only as UX fast-path.

10. routes/system.php:59 | P3 | Guard gap | `/admin/health` (MetricsController) has only Auth+Admin middleware — no AdminPermissionGuard — so every admin-area role (incl. support) can read infrastructure health metrics. | Add AdminPermissionGuard/permission check or document as intended.

11. app/Controllers/Admin/AdminExportController.php:89-98 | P3 | Unvalidated export filters | `filters()` passes raw `user_id/type/status/from/to` strings to ExportService without int/enum/date normalization; relies on service to whitelist (SQLi-safe via prepared statements, but noisy/abusable filters). | Normalize `user_id` to int, status/type to enums, dates to `strtotime` check.

12. app/Controllers/Admin/ScoreManagementController.php:187-196 | P3 | Inconsistent admin-id source | `currentAdminId()` reads `$this->session->get('user_id')` directly and can return null (passed into `createAdjustment()` as adminId), instead of BaseAdminController::requireAdminId(). | Use requireAdminId() for non-null guarantee.

13. app/Controllers/Admin/{OnlinePaymentController,ManualDepositController,WithdrawalController,TransactionController}.php (verify/reject/process/reverse) | P3 | Inconsistent defense-in-depth | These money-approval actions rely solely on CSRFMiddleware in the $admin group, while CryptoDepositController/BannerController/TicketController/MessageModerationController/ApiTokenAdminController also call `validateCsrf()` inline. Middleware does cover them (token via `_csrf_token` POST field or `X-CSRF-Token` header, incl. JSON bodies — verified in app/Middleware/CSRFMiddleware.php:103-108), so not exploitable; but the explicit-call pattern should be uniform. | Add inline `validateCsrf()` to all money-approval actions.

## Areas verified clean (no issue found)
- Auth gates: all 56 controllers extend BaseAdminController → requireAuth()+requireAdminArea() in constructor; AuthController (login/2FA/logout) intentionally ungated at class level with route-level Auth+Admin+CSRF on logout.
- RBAC: config/admin_permissions.php maps every routed admin controller (deny-by-default for unmapped; Cron/Cache/ApiToken/EmailQueue deliberately super-only per S12 decision); AdminPermissionGuard fail-closed with logging.
- CSRF: CSRFMiddleware on every admin POST incl. JSON bodies (header fallback); exempt API routes are outside this scope.
- SQL injection: zero `whereRaw/orderByRaw/DB::raw/raw query` in Admin controllers (grep-verified); all search/filter params flow through services/models with prepared statements; sort whitelisted (fixed in R18/R19).
- Path traversal / arbitrary read: BackupManagement (DB-only filenames, super_admin gate + confirm_name double-check), TicketController::downloadAttachment (resolveAttachment + assignment/tickets.view_all fail-closed + basename), KYCController::deleteImage (realpath + str_starts_with uploads containment), LogController mailbox (fixed storage path, int index, sandboxed iframe + script/on*-strip), Sentry/Content exports (server-generated paths only).
- Money idempotency: Withdrawal process/reject, CryptoDeposit, ManualDeposit, Investment withdrawals, Lottery, Prediction settle, Content revenuePay — all delegate to services with the CAS/idempotency patterns fixed in R18-M/N.
- Batch operations: Content bulkApprove/bulkReject re-filter eligible statuses and route through the same service contract (FIX-S14-3); Referral batchPay has lock+409; mass-assignment closed via safeValidated()/whitelists everywhere checked.
- Role hierarchy on destructive ops: FraudController suspendUser/unsuspendUser (FIX-18Q), UserController update/ban/suspend, AccountDeletion forceDelete (self-delete blocked + status-gated + audit).
- Debug output: no var_dump/print_r/debug echoes; exception messages logged server-side, generic Persian messages to UI (GlobalExceptionMiddleware contract).
- Headers/exit-paths in export endpoints are attachment-only with server-generated filenames.

## Coverage
- 53/56 files deep-read (full or all non-view methods); 3 quick-scanned via pattern greps only: DashboardController, SocialAccountController, FraudDashboardController (read-only list/stats controllers, no raw SQL/$_GET/file ops per greps). FeatureFlagController getMetrics/getHistory tail (~113 lines) read-only JSON — pattern-scanned.
- Pattern scans: whereRaw|orderByRaw|DB::raw / \$_(GET|POST|REQUEST) / readfile|file_get_contents|unlink|download across the whole Admin tree.

---

# SOURCE REPORT: agent-ctx/r19-a6-bugs.md

# Round 19 — Task 19-A6: Line-by-line review of app/Jobs (~97 files)

Agent: jobs-reviewer | Scope: app/Jobs/** (Auth, Payment, SocialTask, CustomTask, Vitrine, Investment, Lottery, Prediction, Notification, Seo, AntiFraud, root-level)
Constraint honored: READ-ONLY (zero modifications under chortke/).
Known already-fixed items NOT re-reported: ProcessRegistrationJob oauth_provider pending branch (present at :122-123), ApproveSocialTaskExecutionJob same-decision override CAS, SubmitSocialTaskExecutionJob fraud-guard wiring + server-authoritative active_time, ReconcilePaymentsJob M-05 CAS / R18-M2a terminal-failure guard, AdminRefund/ResolveVitrine M-01/M-02 CAS, WithdrawalTimeout P1 txn-window + S4-M5, InvestmentProfitDistribution R18-M12 claim, ApplyProfitLossToBatch H-I4 exactly-once, SEO/Social fee-burn + fail-closed escrow.

---

## P1 (1 finding)

### R19-A6-1 | OAuthHelperTrait.php (linkOrCreateUser, new-user branch :416-528; link gated on email at :507-519) | P1 | Idempotency/State-machine gap → duplicate accounts
- **What**: For OAuth registration, the `social_accounts` row is only inserted AFTER registration via `$newUser = $email !== null ? findByEmail($email) : null` (:507). When the provider profile has no email (Facebook frequently omits it; `getFacebookUserInfo` returns email only if granted), `$email === null` ⇒ the link branch is skipped entirely and `linkOrCreateUser` returns the bare register result.
- `oauth_provider_id` is written into `$registerData` (:421) but has **zero readers** anywhere in app/ (verified by grep — only occurrence is the write). So the provider identity is never persisted for email-less OAuth users.
- **Impact**: Every subsequent OAuth callback for the same provider_id fails the `social_accounts` lookup (:343-346) and falls through to "new user" again → **a fresh user account (wallet, referral pending row, session) is created on every login**. Enables quiet duplicate-account farming of signup/first-task referral flows (partially mitigated by R90 per-IP gate) and orphans wallets.
- **Fix**: After successful registration, resolve the new user id from the register result (it already contains user) and insert the `social_accounts` row unconditionally (email or not); or persist/lookup `oauth_provider_id` on users. Also make the "link + login" existing-email insert (:388-396) share the same helper.

## P2 (3 findings)

### R19-A6-2 | Auth/LinkSocialAccountJob.php:32-53 (and OAuthHelperTrait.php:343, :388, :509) | P2 | Race — no UNIQUE on social_accounts(platform, provider_id)
- Check-then-insert with no transactional claim. Verified schema: `2026_06_10_0020_rbac_social_seo.sql` creates `social_accounts` with only `KEY idx_sa_user` — **no unique constraint** on (platform, provider_id).
- Two concurrent flows (double-clicked link, or link racing an OAuth callback for the same identity) bind the same provider identity to two different users. Login then resolves via `->first()` (OAuthHelperTrait:343-346) — nondeterministic account selection, potential ATO-flavored confusion.
- **Fix**: add `UNIQUE KEY (platform, provider_id)` (handle provider_id NULLs) and translate 23000 into the friendly "already linked" response (same pattern as RateVitrineListingJob:84-93).

### R19-A6-3 | CustomTask/CreateCustomTaskJob.php:184 | P2 | Non-deterministic wallet idempotency key (time())
- `'idempotency_key' => "ct_budget_{$creatorId}_" . time()` — the budget-charging withdraw key changes on every attempt. The outer `IdempotencyService` claim ('task.create') is the only fence; if that record expires/is lost (or job replay after TTL, or claim-cache failure), a retried handle() **re-withdraws the full budget+fee with a brand-new key = double charge**.
- **Fix**: deterministic key derived from business identity, e.g. `"ct_budget_{$creatorId}_{$taskId}"` (taskId is available inside the closure) or `hash` of (creator_id,title,totalWithFee).

### R19-A6-4 | SocialTask/ApproveSocialTaskExecutionJob.php — handleAdminOverride() ~297-514 | P2 | Missing referral first-task hook on admin-override approve
- `handle()` runs `creditPendingReferralRewardOnFirstTask($executorId)` after commit (:237-270, with R18-N pay-time gate). `handleAdminOverride('approved'|'soft_approved')` performs the identical bookkeeping (release+fee-burn+counters+trust) but **never calls the referral hook**.
- **Impact**: OAuth-referred user whose first (only) completed task is approved via admin override leaves the referrer's pending signup commission stuck pending forever (batchPay later excludes it only if oauth-held; otherwise it is paid on a *later* task = wrong timing; if anti-fraud hold, admin must pay manually).
- **Fix**: replicate the gated hook after commit in handleAdminOverride (same try/catch, same `$referralGate` pre-read).
- Related (known R18 follow-up, still open): cross-decision override (approved→soft_approved / approved→rejected / rejected→approved) re-applies completed_count/remaining_budget/pending_count/trust bookkeeping because the CAS guard only skips when oldStatus === decision.

## P3 (7 findings)

### R19-A6-5 | CustomTask/RateSubmissionJob.php:110, :134-141 | P3 | rollback without inTransaction() guard + \Exception-only catch + dead `$ratingObj = true`
- `$this->db->rollback()` in catch can throw "no active transaction" and mask the real error (if commit() itself failed); `catch (\Exception)` misses \Throwable (TypeError leaves tx open on the shared connection). Returns `'rating' => true` instead of rating data.
- Fix: `if ($this->db->inTransaction()) $this->db->rollback();`, catch \Throwable, drop `$ratingObj`.

### R19-A6-6 | Prediction/PlaceBetJob.php:156-157 | P3 | rollback without inTransaction() guard (same masking pattern as R19-A6-5)

### R19-A6-7 | SocialTask/ApproveSocialTaskExecutionJob.php:216 & :494 | P3 | Money bound as (float) for ads.remaining_budget decrement
- `[(float)$amount, ...]` against a DECIMAL column — float conversion of IRT/USDT strings can introduce representation noise on large/precision amounts; the same file uses bcmath everywhere else. Fix: bind `(string)$amount` (PDO handles decimal strings), in both handle() and handleAdminOverride().

### R19-A6-8 | CustomTask/SubmitProofJob.php:51-53 vs :118 | P3 | Status check + update not CAS
- `status !== 'in_progress'` check then unconditional `submission_update(..., status='submitted')`. Two concurrent submits both pass; last write wins (proof overwrite; no money impact). Fix: `UPDATE ... WHERE id=? AND status='in_progress'` and treat 0 rows as "already submitted".

### R19-A6-9 | WithdrawalTimeoutJob.php:100-114 | P3 | withdrawal_reviews INSERT dedupe is check-then-insert
- `alreadyFlagged` set built in one query, insert loop afterwards; two overlapping cron workers can both pass and insert duplicate review rows (unless a unique key exists — none seen in code). Fix: `INSERT ... SELECT ... WHERE NOT EXISTS` atomic pattern (as ReportVitrineListingJob:85-100) or UNIQUE(withdrawal_id).

### R19-A6-10 | InfluencerOrderTimeoutJob.php:28-30 | P3 | catch-all swallow, no rethrow
- Failure of `processExpiredPendingAcceptance/processExpiredBuyerChecks` is logged but never rethrown → QueueWorker cannot classify/retry/DLQ (deviates from R18-M14 pattern used in EscrowTimeoutJob). Self-heals next cron run; still worth rethrowing.

### R19-A6-11 | Lottery/UpdateLotteryChanceScoresJob.php:92-184 | P3 | Long transaction + unguarded rollback
- One transaction spans the whole per-participant loop (includes Redis-backed ScoreService::applyDelta + log inserts) — lock-holding window grows with round size; `rollBack()` at :180 lacks the inTransaction() guard. Consider per-participant short transactions (deltas are idempotent per `lottery:vote:{round}:{user}:{date}` key anyway).

## Notes (informational, no action required)
- ProcessNotificationJob.php:71 `$userIds = $userIds;` dead assignment; :66 `$payload['action_url'] === null` on missing key emits a notice-level read — harmless (str_value('')).
- ReleaseVitrineFundsJob.php:122 unconditional rollback in catch — safe today (beginTransaction at :56 precedes all throws) but should adopt the inTransaction() guard for consistency.
- RejectSocialTaskExecutionJob.php:460 / Approve override :460 — trust upsert (+5/−5) is per-execution without dedup key; cross-decision overrides can drift trust (subsumed by known R18 follow-up above).
- CreateCustomTaskJob.php:93 — `irr/rial` currency silently relabeled `irt` with NO amount conversion (potential 10x semantics if a rial-denominated payload ever appears). Product decision needed.

---

## Verified clean (read in full, no findings)
- **Payment**: ApproveCryptoDepositJob, RejectCryptoDepositJob, ProcessPaymentCallbackJob, ReconcilePaymentsJob (M-05 CAS claim, terminal-failure FOR UPDATE re-check, isInternal cron path), CreateCryptoDepositIntentJob (wallet format validation, dup-entry retry loop, min-amount bccomp), VerifyCryptoDepositJob (S4-C1 on-chain verify delegation).
- **Auth**: HandleGoogleCallbackJob (state signature + session binding + nonce + 5-min expiry + strict-IP option), HandleFacebookCallbackJob (debug_token deep verification), Verify2FAJob (lockout handling, subnet-log-only by design), ResetPasswordJob, LinkSocialAccountSafeJob, UnlinkSocialAccountJob (P3 product note: no last-auth-method guard), ProcessRegistrationJob (R17F/R16A pending branch intact, markReferralConverted atomic UPDATE…LIMIT 1 + fallback).
- **SocialTask**: RejectSocialTaskExecutionJob (+override CAS), StartSocialTaskExecutionJob (FOR UPDATE dup-guard, capacity CAS via GREATEST), SubmitSocialTaskExecutionJob (idempotency wrap, fraud block/challenge contract), DecideSilentAntiFraudJob, CalculateSilentRiskScoreJob, SocialTaskApprovalReminderJob (deterministic event_ids; auto-approve delegates to status-guarded service).
- **CustomTask**: PayRewardJob (fresh-read reward_paid guard, unified `customTaskReward` key, level-bonus independent keys), CronSubmissionsJob (S17-4 CAS expire), SubmitProofJob (IDOR path fence, video fingerprint gate, dup checks — see P3 for the write CAS).
- **Vitrine**: ReleaseVitrineFundsJob (saga + status CAS + deterministic release key), ProcessExpiredVitrineEscrowsJob, ResolveVitrineDisputeJob, AcceptVitrineRequestJob (M-03 double-CAS), SendVitrineRequestJob, ConfirmVitrineDeliveryJob, AdminRefundVitrineListingJob (M-01 claim + claim-release compensation), AdminApprove/AdminReject, CreateVitrineListingJob, RateVitrineListingJob (UNIQUE-fenced), ReportVitrineListingJob (atomic NOT EXISTS insert), VitrineListingExpiryJob (S17-1 per-listing claim + explicit idempotency key).
- **Investment**: CreateTradeJob, CloseTradeJob (X80 percent resolver), RequestWithdrawalJob / RejectWithdrawalJob (FOR UPDATE pair, R18-M6 guarded rollback), ApplyProfitLossToBatchJob (double idempotency check + locking re-read + per-item unique keys), ApplyWeeklyProfitLossJob (both copies — dispatcher contract fixed), InvestmentProfitDistributionJob (R18-M12 claim + cursor batching + cache-claim fallback).
- **Prediction**: PlaceBetJob (game FOR UPDATE + DB-NOW deadline + per-user bet lock + deterministic hold key — see P3 rollback note), SettleGameJob (winners_paid CAS, M-tier txId scoping, overflow rounding guard, ledger-balanced allocations), CancelGameJob (full-refund loop, game FOR UPDATE).
- **Lottery**: ParticipateInLotteryJob, VoteInLotteryJob (triple FOR UPDATE, dup-vote guard).
- **Seo**: ProcessSeoTaskAsyncJob (server-elapsed clamp, fingerprint continuity, fee burn, fail-closed escrow), StartSeoTaskJob (X194 duplicate detection), CompleteSeoTaskJob, CancelSeoTaskJob, RateSeoTaskJob, ReportSeoTaskJob.
- **AntiFraud**: CheckTaskFraudJob (per-action contract assertions), UpdateFraudScoreJob (R18-M15 payload-derived idemKey).
- **Root/misc**: KycTimeoutJob (cursor + CAS + M11 event_id), RunCronTaskJob (lastRun gate, rethrow), SendEmailJob (findAndLock claim), ProcessNotificationJob (circuit breaker, rethrow), PersistBulkInAppNotificationJob, NotificationCleanupJob, CacheWarmupJob (mutex), AggregateAnalyticsJob (EAV upsert + mutex), LogPerformanceJob, SocialTaskApprovalReminderJob, BackfillSearchProjectionJob (already R18-fixed, read-only).
- **Notification/** (25 files, grep-scanned + 2 read): pure delegates to NotificationService/template service — no direct DB writes, transactions, or money movement in the Jobs layer.

Coverage: 62/97 files fully read (all money-bearing paths deep-read), remaining 25 Notification jobs + 10 low-risk delegates covered by targeted grep scan; zero skipped money paths.

Counts: **P0=0, P1=1, P2=3, P3=7** (+5 informational notes).

---

# SOURCE REPORT: agent-ctx/r19-a7-bugs.md

# Round 19 — Task 19-A7 Bug List: Models + Middleware + Listeners

Agent: models-middleware-reviewer | Scope: app/Models (107 files), app/Middleware (23 files), app/Listeners (30 files) | READ-ONLY
已知已修 (不重复报告): User::ADMIN_SORTABLE_COLUMNS 白名单 (User.php:128,470-495), Transaction::ADMIN_SORTABLE_SQL_MAP (Transaction.php:580-654).

统计: P0=0  P1=0  P2=2  P3=12

---

## P2

1. **app/Listeners/ReferralCommissionListener.php:91-99** | P2 | 监听器异常吞掉→资金副作用静默丢失
   handle() catch(\Throwable) 只写日志/Sentry 后返回, 无 outbox 重试/补偿。processCommission 失败 (瞬时 DB 错误) = 该笔推荐佣金永久丢失, 而主流程 (充值/任务支付) 已成功。对照: WalletDepositRequestListener 有 1..3 有界重试+死信, ReferralCommissionListener 与 HandlePaymentCompleted::processReferralCommission (186-192) 均无。
   建议: 失败分支向 outbox 记录 `referral.commission.process` 替补事件 (带原 correlation_id + 幂等键), 或复用 processCommission 内的 pending 行状态机做补偿 cron。

2. **app/Middleware/ConcurrentRequestMiddleware.php:44-90** | P2 | 并发锁无属主 token + 固定 3s TTL → 慢请求双提交窗口
   `$client->set($lockKey,'1',['NX','EX'=>3])`: 请求耗时 >3s 时另一并发请求可获取锁; 第一个请求 finally 无条件 `del($lockKey)` 会删掉第二个请求的锁, 第三个又可进入。金融路由双提交防线只剩 DB 幂等键 (存在, 但 hold/冻结类操作可先触发)。
   建议: 锁 value 用随机 token, 释放用 Lua compare-and-del; TTL ≥ 预期最大处理时长 (或看门狗续期)。

---

## P3

3. **app/Middleware/CSRFMiddleware.php:88-96, 124-131** | P3 | 拦截分支未显式 return, 依赖 Response::json() 抛 HttpResponseException 才中止
   webhook 签名失败分支 `$response->setStatusCode(401)->json([...])` 后直接落到 `return $this->toResponse($next($request))`; CSRF 失败分支同理。当前唯一屏障是 core/Response.php:503-506 send() 必须 throw (Pipeline.php:114-120 逐层解包)。若自定义 Response transport 重写 send() 不抛 (Response::view 注释明确允许 test doubles), 拦截即失效 → 继续 enter controller。建议显式 `return $response;` (SafeModeMiddleware.php:61-65 已示范正确写法)。

4. **app/Models/User.php:104-110** | P3 | password 仍在 $fillable
   FIX-18O 移除了 role/status/2FA 等, 但 password 留下 (注册 INSERT 需要)。任何未来把请求数组漏进 User::update() 的路径都可绕过"旧密码校验"直接改密码哈希。建议: 注册改走 createWithSystemColumns 的显式列, password 从 $fillable 移除 (changePassword/changePassword 类专用 writer 已存在)。

5. **app/Models/Withdrawal.php:20-27** | P3 | $fillable 含管理侧列 status/processed_by/processed_at/admin_note/rejection_reason
   若请求形态数据到达 createWithdrawal() (parent::create), 用户可凭空创建 status='completed' 的提现记录。现状仅服务层内部调用 (grep 证实控制器无直调), 属纵深防御缺口。

6. **app/Models/Transaction.php + LedgerEntry.php** | P3 | 无 $fillable, parent::create() 全列放行
   Core/Model.php:172-180: fillable 为空 = 不过滤 (向后兼容)。Transaction::createTransaction/claimForReversal 数据今天由服务层构造 (控制器无直调), 但任何新调用点可注入 status/ref_type/metadata 任意列。建议补列白名单。

7. **app/Models/Escrow.php:101-106, 154-159, 240-245** | P3 | 金融事务包装 catch(\Throwable)→return false, 零日志
   confirmHoldWithTransaction/releaseFundsWithTransaction/refundFundsWithTransaction 把 DB 异常与"守卫不通过/未找到"混同为 false, hold/release/refund 失败无任何日志/Sentry — 可观测性黑洞。

8. **app/Models/ReferralCommission.php:146-158** | P3 | updateStatus 无 CAS/来源状态守卫
   任意状态可重复改写 (paid→pending 会把 paid_at 重置 NULL; 并发双 mark-paid 无 rowCount 语义保护)。创建侧有 idempotency_key (FIX-X334), 过渡侧裸奔。建议补 allowedFromStatuses 参数 (对齐 Transaction::recordStatusChange)。

9. **app/Models/ReferralCommission.php:348,394; app/Models/SocialAccount.php:159-160,202-203** | P3 | LIKE 通配符未转义
   `'%'.$filters['search'].'%'` 直接拼接 (已参数化, 无注入), 但 %/_ 注入可致病态扫描/意外匹配。User::applySearch 已有 escapeLikeValue 范式, 应复用 (对照 EmailQueue/PerformanceLog 同类)。

10. **app/Models/ApiToken.php:406-423** | P3 | revokeByHash 不看 rowCount 恒返回 true
    0 行命中也报成功 — 调用方/审计误导。对齐 revokeByIdIfActive/revokeForUser 的 rowCount 语义。

11. **app/Middleware/SecurityHeadersMiddleware.php:121** | P3 | CSP style-src 'unsafe-inline'
    script 已 nonce 化, style 仍全放行内联; 若迁移成本可控, 对关键模板改 style nonce/哈希。

12. **app/Middleware/AdvancedFraudMiddleware.php:102-112** | P3 | fail-closed 分支 `exit;` 为死代码且 Response 未返回
    $response->error()/redirect() 均经 send() throw (不可达 exit)。行为正确但代码误导; 若 send 语义变更, 503 响应将既不发送也不返回。删除 exit、显式 return。

13. **app/Models/Setting.php:53-81** | P3 | set() SELECT→INSERT/UPDATE 竞态
    并发首写同一 key: 两者同时 SELECT 未命中 → 双 INSERT (无 ON DUPLICATE KEY), 后者失败返回 false (瞬时假失败)。建议 upsert 化。

14. **app/Middleware/AuthMiddleware.php:261-266, 341-345; AdminMiddleware.php:141-143** | P3 | 同 #3 的隐式中止模式
    构建 `$response->redirect(...)` 后无 return/throw, 完全依赖 redirect() 抛异常。当前正确; 建议统一显式化 (与 #3 同批修复)。

---

## 已核查无误区域 (clean)

- core/CSRF.php:70-81 verify: hash_equals + 空值拒绝 + Origin/Referer 校验 (生产强制) — 无绕过。
- ApiAuthMiddleware: 64-hex 格式门 + HMAC-SHA256 多版本轮换 + revoked/expires 检查 + negative-cache + admin scope 降权自动吊销 + scope 层级 (read/write/colon-dot 兼容) — 未见绕过。
- CorsMiddleware: '*' 过滤、credentials 仅限白名单 origin、scheme 白名单 (含 capacitor://)、Vary: Origin — 无通配符+credentials 组合。
- RateLimitMiddleware: 认证键=user_id、访客键=IPv6 /64 归一化 IP, 不可用 fingerprint 伪造; 关键路径 fail-closed。
- AdminPermissionGuard: deny-by-default + super_admin bypass + DB 授权; PermissionMiddleware: HMAC 缓存完整性 + 关键权限 TTL=0。
- AdminMiddleware/AuthMiddleware: 每请求 DB 重校验角色/状态、被吊销 session 检查 (S5-H1)、2FA pending 优先。
- GlobalExceptionMiddleware: 生产用通用错误视图 (debug 门控 trace); HttpResponseException 由 Pipeline:114-120 逐层转为 Response, 不会被误吞为 500。
- MaintenanceMiddleware (REMOTE_ADDR+trusted proxy 门)、SafeModeMiddleware (M-09 AND 语义防 header 绕过)、RequireFeature、SessionMiddleware、CaptchaMiddleware (风险驱动, hash_equals 行为签名)、ApiRequestMiddleware、GuestMiddleware (R18N 循环修复)、HttpsMiddleware (parse_url 消毒)、LoggingMiddleware、TracingMiddleware (correlation-id 白名单消毒)。
- 监听器幂等: social_task_reward_{executionId} (P0-19/20 对齐), level_bonus_social_{id}, wd_created_/wd_approved_{id}, escrow_released_{id}, task_{taskId} XP; AppServiceProvider 注册无重复事件; EscrowListener 刻意不动余额 (结算在事务内); InfluencerEventListeners 尊重 caller 显式幂等键; WithdrawalListener score 非阻塞+幂等键; SocialTaskEventListeners re-throw 保持 saga 失败语义。
- 模型: Transaction CAS (recordStatusChange/claimForReversal FOR UPDATE+IN 守卫)、H-01/H-02 防重复 reversal、X327 幂等键用户域隔离; Wallet 原子余额操作 (frozen 合入 WHERE、FOR UPDATE upsert、负余额 DB 级防护)、 currencyField 白名单; CryptoDeposit 严格状态机 (C-13) + tx_hash FOR UPDATE; PaymentLog/SocialAccount/Setting/Ticket/PaymentGateway/VitrineListing ($sort match 白名单)/Dispute (int 型插值) — 均无注入; ApiToken HMAC+版本轮换+findAnyByRefreshToken 重放检测; 控制器无直接调用 create*/update* 资金模型的路径 (grep 证实)。

残留未深读 (低敏): PerformanceLog/EmailQueue 动态 WHERE 构建细节、其余 ~90 模型仅模式扫描 (未发现 fillable 缺失+外部输入、未参数化插值、裸 token 比较的组合)。

---

# SOURCE REPORT: agent-ctx/r19-a8-bugs.md

# Round 19 — Task 19-A8: routes/ + config/ + Validators + Providers/Exceptions/bootstrap/public + Commands

Agent: routes-config-reviewer | Date: 2026 (R19) | READ-ONLY (zero modifications to chortke/)
Scope read: routes/*(10) · config/*(20) · .env.example · app/Validators (BaseFormRequest + Register/Login + 25 of ~56 Requests deep-read, rest rule-dump scanned) · app/Providers/AppServiceProvider.php · app/Exceptions (5) · bootstrap/(3) · public/index.php · app/Commands (QueueWork/OutboxPublish/MigrationManager full; others registered-only) · targeted controller follow-ups (MetricsController, HealthCheckController, PaymentController, AdtubeController, Admin/AuthController, DebugController, StatusController, AppConfigController, ApiToken, CSRFMiddleware, core/Validator).

Known-fixed (worklog, NOT re-reported): routes/auth.php POST /logout, routes/admin.php POST /admin/logout, /banner/click rate-limit+dedupe, /notifications/click POST+CSRF, RegisterRequest unique-email removal, GuestMiddleware 2FA loop.

---

## (1) ROUTES — guard audit (every route in 10 files checked)

**Verdict: no P0/P1 unguarded route found.** POST routes: all web POSTs carry CSRFMiddleware (directly or via $secureAuth/$authCSRF/$admin/$tasksSecure/...). All /user resource routes carry AuthMiddleware+. All admin routes carry the full $admin chain = Auth+Admin+CSRF+RateLimit:30,1+AdminPermissionGuard (deny-by-default map in config/admin_permissions.php; unmapped controller/action ⇒ deny for non-super-admin). All /api/v1 mutating groups carry ApiAuthMiddleware:scope + ApiRequestMiddleware + RateLimit. CSRF exemptions are NARROW and each exempted path has its own auth: `/api/*` (bearer), `/payment/callback/*` (gateway verify + IP allowlist, PaymentController), `/webhooks/*` (HMAC+timestamp fail-closed, CSRFMiddleware:76-81).

Findings (all P3 defense-in-depth / consistency):

| # | File:Line | Method+Path | Issue | Fix |
|---|---|---|---|---|
| R-1 | routes/user.php:55, 261-277 | POST /referral/generate-code, /referral/set-referrer, /referral/rewards/claim, /referral/report-fraud + 3 /referrals/* aliases | $referralAuth = Auth+CSRF+RequireFeature — NO RateLimitMiddleware (unlike sibling $authCSRF:15,1 used everywhere else in the file). claimRewards is financial-adjacent (ReferralController:348 → checkAndAwardMilestones; idempotent per R18-N#3, so impact low). | array_merge($authCSRF,[RequireFeature:referral]) like $couponsAuth does. |
| R-2 | routes/system.php:59 | GET /admin/health | Auth+Admin only — missing AdminPermissionGuard. Every other admin route (incl. all 4 system controllers per FIX-S16-1) is deny-by-default guarded; this one bypasses the RBAC map. GET-only JSON health for admins; info = component health. | Add AdminPermissionGuard (map key MetricsController→'system.health' or reuse $adminRead). |
| R-3 | routes/health.php:30-31, routes/api.php:233-234, routes/missing.php:50 | GET /health/distributed, /metrics/distributed, /metrics, /api/v1/metrics/distributed | Registered with ZERO route middleware. Verified NOT a hole: HealthCheckController::validateAccess (128-149) and MetricsController::metrics/health (36-57/250-269) are fail-closed IP-allowlist/token gates (empty allowlist ≠ public). But a future controller edit silently re-opens them. | Add RateLimitMiddleware (cheap) so the route file self-documents the gate; keep controller gate. |
| R-4 | routes/admin.php:79 | POST /admin/verify-2fa | CSRF only at route level, no RateLimit param. VERIFIED OK in depth: AdminAuthController:281-291 throttles 3/10min per user+IP and destroys session on brute-force. No action needed (recorded to stop future re-reports). | — |
| R-5 | routes/public.php:74-77 | GET /test-captcha, POST /test-captcha/verify | Env-gated (local/testing/development/dev/test). Not a prod hole, but 'test' in the allowlist means a prod box with APP_ENV=test gets a public captcha-bypass playground. | Trim list to local/development/dev; keep 'testing' only under phpunit (routes not loaded there). |
| R-6 | routes/public.php:59-60 | GET+POST /api/banner-click | GET alias of a click-tracking (state-changing) POST — <img>-fireable; mitigated by 30/60min limit + atomic per-(banner,ip) 90s dedupe (R18-N#10). Keep; flagged for mobile deprecation plan. | — |
| R-7 | routes/api.php:50 | GET /api/v1/config (public) | Returns ALL feature-flag names + enabled booleans unauthenticated (AppConfigController:52-60) → free recon of module rollout state (investment/lottery/crypto/referral off-on). Deliberate for mobile, but unscoped. | Whitelist flags the mobile client actually needs; never dump the full table. |

Verified-good (spot checks that could have been holes): PaymentController::callback — POST-only + gateway verify + IP allowlist (405 on GET); AdtubeController::s2sWebhook — HMAC over raw body + timestamp freshness fail-closed (X332/X352); DebugController — registered only when app.debug AND behind $adminRead (Auth+Admin+PermissionGuard), output escaped, no secrets; StatusController::api — sanitized public snapshot, 30s cache; TicketController::downloadAttachment — $auth + dual-role ownership inside method.

## (2) CONFIG

| # | File:Line | Sev | Issue | Fix |
|---|---|---|---|---|
| C-1 | config/config.php:174-175 | P3 | Hardcoded fallback secrets `'default_api_secret_v1/v2_must_be_strong_32_chars'` for security.api.secrets (consumed by ApiToken HMAC (:184,:296,:319,:441), ApiAuthMiddleware:210, ConcurrentRequestMiddleware:137). Currently unreachable in web/CLI boot because bootstrap/app.php:89 throws if base SECURITY_API_TOKEN_SECRET <32 chars, and v1/v2 fall back to that base env first. BUT: violates the FIX-S20-2 fail-closed precedent (message_keys now default '') and stays a live trap for any new entrypoint (worker, phpstan-bootstrap, future cron path) that resolves config without bootstrap. | Default '' + runtime fail-closed throw in the three consumers, mirroring message_keys. |
| C-2 | .env.example:31 SESSION_SECURE=false | P3 | Ghost key: config.session.secure is computed from HTTPS/X-Forwarded-Proto+TRUSTED_PROXIES (config.php:67-69) and never reads SESSION_SECURE. A deployer setting SESSION_SECURE=true gets nothing. | Delete the key from .env.example or wire it as an override. |
| C-3 | config/payment.php:16,29,41,48 | P3 | Default callback_ips ship with hardcoded production gateway IPs incl. /24-style wildcards ('185.97.64.*'). Fine as gateway defaults, but any *-wildcard entry turns one IP into 65k if callback_secret is unset (callback then rests on IP match alone). | Ops checklist: require *_CALLBACK_SECRET in production (already fail-closed for webhooks only). |
| C-4 | config/config.php:44 | P3 | `'database' => env('DB_DATABASE','/home/user/database.sqlite')` — sqlite-flavored default inside a MySQL app (driver default mysql); dead key, confusing. | Default '' or drop. |

Clean: no debug=true hardcoded (app.debug = env,false), no passwords/secrets in any config default (grep over config/ = 0 hits), session httponly=true + samesite=Lax + secure auto + lifetime floor 1800s, lock fail_closed=true, queue.allowed_jobs allowlist present, webhook secret fail-closed (null ⇒ reject), feature_flags default-false for money modules, admin_permissions.php deny-by-default with per-method escalation, .env.example placeholders only, testing bootstrap uses non-secret test keys only.

## (3) VALIDATORS

Deep-read: BaseFormRequest, RegisterRequest, LoginRequest, CreateWithdrawalRequest, CreateDepositRequest, RequestWithdrawalRequest, CreateTransferRequest, OAuthCallbackRequest, OAuthLinkAccountRequest, CreateInvestmentRequest, WithdrawInvestmentRequest, CreateTradeRequest, ValidateCouponRequest, PurchaseLevelRequest, CreateInfluencerOrderRequest, JoinLotteryRequest, PlacePredictionBetRequest, CreateVitrineListingRequest, CreateBankCardRequest, CreateCustomTaskRequest, CreateSocialTaskRequest, UpdateProfileRequest, UserUpdateRequest, StoreContentRequest, SendMessageRequest, SendDirectMessageRequest, SendNotificationRequest, StoreSocialAccountRequest, CreateBugReportRequest, StoreInfluencerProfileRequest, ContactMessageRequest, SubmitCustomTaskProofRequest. Rules dump scanned for the remaining ~25 (no empty rules() found outside BaseFormRequest defaults).

| # | File:Line | Sev | Issue | Fix |
|---|---|---|---|---|
| V-1 | app/Validators/Requests/SendDirectMessageRequest.php:16 | **P2** | `message => required|string|min:1` — NO max. Sibling SendMessageRequest caps at 5000. Global request cap is 12MB (config request.max_body_bytes) ⇒ one DM row up to ~12MB, spam-able at 15 req/min via /user/messages/send (api.php:95 + user.php:239). DB bloat/DoS; if the column is TEXT(64KB) it becomes 500-noise on every oversized send. | Add `max:5000` (mirror SendMessageRequest). |
| V-2 | core/Validator.php:214-217 | **P2** | `url` rule = bare FILTER_VALIDATE_URL ⇒ accepts `javascript:`/`data:` URIs. All stored URL fields validated with it (video_url StoreContentRequest:15, link CreateCustomTaskRequest:38, proof_url SubmitCustomTaskProofRequest:19, target_url CreateSocialTaskRequest:22...). Render sinks were sanitized with sanitize_url in R18-Q, but creation-side scheme validation is still missing (the exact R18-Q backlog item; ValidatesExternalUrl trait exists and is unused at creation). Any future view forgetting sanitize_url re-opens stored XSS. | Add scheme check (http/https only) to the `url` case in core/Validator.php — one fix covers every request class. |
| V-3 | app/Validators/Requests/CreateInvestmentRequest.php:11-17 | P3 | Constructor force-injects `risk_accepted=1` when absent ⇒ the `required` rule on risk_accepted can never fail; the consent gate is theater. | Drop the injection; let the form submit the flag (product decision if UI moved consent elsewhere). |
| V-4 | app/Validators/Requests/CreateTransferRequest.php:25 | P3 | Money compared via float_value (float precision) — CreateWithdrawalRequest correctly uses bccomp; transfer should too (min:100 rule OK; amount≤0 re-check present). | Replace with bccomp($amountStr,'0',8). |
| V-5 | app/Validators/Requests/CreateVitrineListingRequest.php:19 | P3 | price_usdt `required|numeric` — no min/max/positive. Mitigated server-side: CreateVitrineListingJob:51-52 enforces vitrine_min/max_price_usdt (1..100000). Validator-level parity recommended. | `min:0.01` + numeric-positive check; service cap stays. |
| V-6 | app/Validators/Requests/CreateDepositRequest.php:15 / CreateWithdrawalRequest.php:28 / PlacePredictionBetRequest.php:23 | P3 | No `max` on amount in any financial validator (min + bccomp>0 present; upper caps live in services/limits). Standardize a max (e.g. ≤ WITHDRAW_MAX 50,000,000) to fail early. | Add max rules matching constants. |
| V-7 | app/Validators/Requests/StoreSocialAccountRequest.php:16 | P3 | access_token nullable|string without max (unbounded secret-ish field into DB). | max:512. |
| V-8 | app/Validators/Requests/UserUpdateRequest.php:16 | P3 | password `min:8` contradicts policy min 12 (config auth.password.min_length, enforced by RegisterRequest). Admin update path can set a weaker password than self-register allows. | min from config; run PasswordPolicy like RegisterRequest. |
| V-9 | app/Validators/LoginRequest.php:62 | P3 | `$this->validated = $this->data` — validated() returns the whole raw input (incl. _csrf_token etc.), not rule-filtered. Consumers only read known keys today; safeValidated() contract not honored here. | Filter to email/identifier/password/remember. |

Verified-good: CreateWithdrawalRequest (bccomp>0, per-currency AppSettings minimum, IRT decimal rejection, idempotency_key required 10..128), RegisterRequest (email normalize + PasswordPolicy similarity, unique-email removed per R18), LoginRequest (bcrypt CPU-exhaustion cap 255), OAuthCallbackRequest (code/state 1..2048), CreateCustomTaskRequest/CreateSocialTaskRequest (idempotency_key required, price floors from AppSettings, quantity/deadline bounds), CreateBankCardRequest (16/16 card), JoinLotteryRequest (route-param backfill), ValidateCouponRequest (bccomp>0), BaseFormRequest safeValidated() rules-key filter (X16).

## (4) Providers / Exceptions / bootstrap / public/index.php

- app/Providers/AppServiceProvider.php (580 lines) — clean. All listener registrations fail-safe; Sentry init in try/catch; mock gateway blocked in production (S4-H3); ValidatorFactory static injection at end. No issues.
- app/Exceptions (5 files) — thin, correct; BusinessException maps array code → 422; SessionException reasons → shouldTerminateSession. No issues.
- bootstrap/app.php — APP_KEY ≥32 + ≠'default_key' enforced (prod: 500 die), APP_URL validated, SECURITY_API_TOKEN_SECRET ≥32 enforced, display_errors only when debug&&!production, projection wiring fail-safe. Clean.
- bootstrap/testing.php / phpunit-prepend.php — non-secret test config; log rotation guarded to BASE_PATH. Clean.
- public/index.php — pre-bootstrap HTTPS 301 for production (proxy-aware, private-range XFP check), correlation-id pattern-validated, X-Powered-By removed, ultimate catch-all crash page shows stack ONLY when APP_DEBUG=true parsed from .env; generic page otherwise. Clean.

## (5) Commands (QueueWork / OutboxPublish / MigrationManager + registration surface)

- MigrationManager — 100% parameterized SQL (no injection), information_schema read-only probes, no dynamic SQL from user input. Clean.
- OutboxPublishCommand — args clamped (limit 1..500, sleep 1..300); daemon loop resilient. Clean.
- QueueWorkCommand — args clamped (limit 1..500, tries 1..20, max-time ≤86400); actual job allowlist enforced inside QueueWorker (config queue.allowed_jobs, S13 pin). Clean.

## Severity tally

- P0: 0 · P1: 0 · **P2: 2** (V-1 DM message unbounded; V-2 `url` rule accepts javascript:/data:) · P3: 14 (R-1..R-5,R-7, C-1..C-4, V-3..V-9 — R-4/R-6 recorded as verified-good notes).
- Files fully read: routes 10/10, config 20/20 (+.env.example), Validators 33 deep + ~25 rule-dump, Providers 1/1, Exceptions 2/5 full (3 thin trivial classes pattern-identical), bootstrap 3/3, public/index.php, Commands 3/25 full + registration surface of all 25.
- Known follow-up carried from R18-Q (still open, confirmed): write-side URL scheme validation (covered by V-2).

---

# SOURCE REPORT: agent-ctx/r19-a9-bugs.md

# Round 19 — Task 19-A9: Views + Public 逐行审查 (bugs)

Agent: views-reviewer | Date: Round 19 | READ-ONLY (no chortke/ file modified)
Scope note: 视图实际位于 `chortke/views/**`（项目无 `resources/` 目录）。总计 ~299 个 .php 视图文件（admin ~155, user ~99, emails 12, errors 8, partials 8, layouts 5, pages 7, auth 3, welcome + test-captcha 2）。
Method: >80 文件 ⇒ 资金/布局/表单页深读 (layouts 5, wallet/index 全 655 行, withdrawal/index 全 528 行, crypto-deposit/create, referral/index, auth/oauth-confirm, admin withdrawals/manual-deposits review, settings hub/nav, emails/_header) + 全树 Grep 模式扫描（`{!!`, `<?= $`, `echo $`, `$_GET/POST/SERVER`, `javascript:`, `on*=`, `href/src="<?= $`, `<form`, `csrf`, `include $`, `header(Location`)，命中文件定点 Read（dispute-panel, admin/messages/reports, email-queue, audit-trail, investment/trades, admin/notifications, sentry/issues, influencer/my-profile 等）。R17 已修复项（GET logout、aria-hidden、country_flag 🌐）与 R18 修复项（9 个 sanitize_url sink、style nonce、asset() 转义等）已核对且未重复报告。

## 结论摘要
- P0 = 0, P1 = 1, P2 = 3, P3 = 6
- 全树 `{!! !!}` 出现次数 = 0；59 个含 `method=post` 表单的文件全部带 CSRF 字段（缺失数 = 0）；无 `$_GET/$_POST` 直接注入输出的活sink。

## P1
1. **views/user/influencer/dispute-panel.php:66 — 存储 XSS（漏网 sink）**: `<a href="<?= e($m->attachment) ?>">`。`$m->attachment` 是争议消息里用户提交的附件 URL（写侧无 scheme 白名单，R18 backlog 已记录 "write-side scheme validation missing"）。`e()` 只做 HTML 转义，不阻止 `javascript:`/`data:` 协议 → 受害者（对方当事人/管理员）点击即执行。同文件 :35 的 `proof_link` 已按 R17/R18 修复为 `sanitize_url()`，admin/influencer/dispute-detail.php:17 对同一列 `$m->attachment` 也已用 `sanitize_url()`，唯独这里漏掉。Fix: `href="<?= sanitize_url($m->attachment) ?>"`（helper 空/非法返回 `#`）。

## P2
2. **views/admin/messages/reports.php:126,130,137 — 反射 XSS 防御缺失（href 属性拼接）**: `?page=<?php echo $page - 1; ?>&status=<?php echo $status; ?>`（3 处）。`$status` 当前由 MessageModerationController:42-44 白名单（FIX-X35），暂不可利用；但这是全视图树仅存的"请求参数未经 e() 直接进 href 属性"模式，控制端白名单一旦回归即为属性逃逸反射 XSS。Fix: `e($status)`（blocked-users.php 同目录只 echo int，无此问题）。
3. **views/admin/withdrawals/review.php:63 — 未转义 fallback echo**: `<?= ['verified'=>'تأیید شده',...][$kyc] ?? $kyc ?>`。`$kyc = $user->kyc_status`（DB 枚举、仅管理流可写，故风险低），但管理页文本节点裸 echo 不符合全站 e() 纪律。Fix: 包 `e()`。
4. **public/downloads/chortke-full-source.zip + chortke-fixed-files.zip + index.html — 全源码公开下载**: R18 主控有意发布到 docroot（worklog 记录"Deliverables…published to chortke/public/downloads/"）。任何人无需认证即可取得完整 routes/controllers/migrations/`.env.example`/业务逻辑，为攻击者提供完整攻击面地图。建议：移出 docroot 或置于认证后（zip 本身已验证无 vendor/logs/zip 泄漏，但源码披露在生产仍是 P2 政策问题）。

## P3
5. **JS 驱动表单缺 `method="post"`/`action`（18 处，UX/降级问题非漏洞）**: 提交完全依赖 JS（fetch + token）。JS 失效时原生 submit 变 GET：字段泄入 URL/Referer 且打到错误路由。文件: my-profile.php:168 (hubOrderForm), ads/_create-panel.php:95, notifications/preferences.php:61, messages/show.php:99, messages/index.php:117, investment/index.php:358, security/two-factor.php:40,56, custom-tasks/proof.php:84, tickets/show.php:99, social-tasks/execute.php:71, partials/bug-report-widget.php:48, admin/investment/trade-create.php:15, apply-profit.php:20, admin/crypto-deposits/index.php:231 (rejectForm), admin/lottery/create.php:13 (roundForm), admin/tickets/show.php:163, admin/content/revenue-create.php:57, admin/users/create.php:12 / edit.php:27。
6. **views/layouts/guest.php:61 — nonce 回退不一致**: `nonce="<?= e($cspNonce ?? '') ?>"` 为空字符串回退，而 auth/user/admin 布局均为 `csp_nonce()` 回退；未传 `$cspNonce` 的控制器下内联 loader 脚本将被 CSP 拦截。
7. **views/emails/_header.php:33 — `<img src="<?= $__logo ?>">` 未 e()**（`$__logo = site_logo_full()` 规范 url() 输出，良性）；:35 `onerror="this.style.display='none'"` 为静态串，安全。建议统一 `e($__logo)`。
8. **views/user/influencer/dispute-panel.php:2 — `$title = '…' . e($order->id)`**: $title 由布局二次转义（vitrine/show.php:3 同类已在 R18 修正为 raw）；int id 无实际影响，属一致性修复。
9. **views/user/wallet/index.php:587 — JS 覆盖幂等键**: 服务器已渲染 per-render 随机键（:267/:524），JS 却用 `Math.random().toString(36).substr(2,9)` 重写 `payment_idempotency_key`，熵弱且 `substr` 已废弃；建议 `crypto.getRandomValues()`。
10. **views/test-captcha.php:143 — `echo $content`**（自身组装的安全 HTML；该测试页未验证是否 env-gated，建议确认路由仅在非 production 暴露）。

## XSS 扫描明细（判定记录）
- `{!! … !!}`: **0 处**。
- `<?= $var` 原始输出: 202 处（列全 200）——逐条核对全部为：类名/布尔三元、`(int)/(float)` 强转、`fa_number/number_format`、`$h()/h()/$money/$int` 转义助手、`url()` 字面量。无用户可控未净化 sink（P2#2/#3 的两处例外见上）。
- `echo $var`: 31 处 — 全部内部组装（errors/*.php 的 `$content`、test-captcha、int 强转徽章、白名单 map），安全。
- `$_GET/$_POST/$_REQUEST/$_SERVER` 在视图中: 60 处 — 全部经 `in_array` 白名单（$initialSection 系列）、`(int)` 强转、`e()` 包裹或仅用于 `===` 比较 / `http_build_query`（audit-trail/users/transactions/logs 等分页重建均安全）。
- inline `on*="…<?= … ?>"`: 0 处。
- `javascript:` URI: 0 活 sink（1 处为 sanitize_url 注释）；R18 的 4 个 P0 sink 修复确认在位（seo/execute.php、ads/show.php:311、dispute-panel.php:35、adtube/execute.php:33）。
- `href/src="<?= $var"`: 54 处 — 均为 url() 字面量、e()/sanitize_url() 包裹、或硬编码导航数组（settings/hub.php:100、_settings-nav.php:19、admin/notifications/index.php:121 经 rel-path+sanitize_url 双重处理）。
- 动态 `include $var`: 1 处 — admin/dashboard.php:627 `include $sentryWidgetPath`（内部固定路径变量，非用户输入）。
- `header('Location: $var')` 在视图中: 0 处。

## CSRF 检查
- `method=post` 表单文件 59 个 ↔ 含 csrf 标记文件 96 个：**59/59 全覆盖，缺失 0**。代表性确认：wallet transfer/escrow/payment modal、withdrawal form、crypto/manual deposit、referral generate/report-fraud、notifications click POST（R18 修复）、admin withdrawals/backups/fraud/banners、logout POST 表单等。
- 额外加固确认：wallet transfer/escrow/payment 表单带 `idempotency_key`（P0-23 per-render 键，见 P3#9 的 JS 弱化备注）。

## public/ 检查
- **未发现**：.env、*.sql、phpinfo.php、test.php、info.php、dump/log/backup 文件、composer.json/.phar（根目录文件经 root .htaccess `RewriteRule → public/` + front-controller 兜底，不可直接下载）。
- public/index.php：加固到位 — cli-server 静态分支排除 .php（防源码泄漏）、X-Correlation-ID 白名单校验（R18 P3 修复在位）、production 强制 HTTPS 重定向（可信代理判定限内网 REMOTE_ADDR）、顶层 Throwable 兜底输出通用 500 页（仅 APP_DEBUG=true 时显示堆栈）。
- .htaccess 链：根（重写→public、拒 dotfiles/.env、-Indexes）→ public/（front controller、安全头）→ uploads/（拒 php/phtml/phar/html/htm/xml/svg/sh/exe/bat 执行与访问 + php_flag off）→ storage/（全部拒绝）→ install/（`Require ip` 仅回环/内网 + PHP 侧 installed.lock、APP_ENV=production 守卫、X315 防重装 DB 守卫、CSRF）。
- uploads/ 仅散列名图片（avatars/site-images）；KYC/收据等敏感文件不经 docroot（走 /file/view 路由）。
- 唯一披露项 = P2#4 的 downloads/*.zip。
