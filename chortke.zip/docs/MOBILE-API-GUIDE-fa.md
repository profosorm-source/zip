# راهنمای یکپارچه‌سازی اپلیکیشن موبایل — Chortke API v1

> 📱 سند بچ **FIX-MOBILE** (۲۰۲۶-۱۱-۰۲) — آماده‌سازی کامل زیرساخت برای طراحی اپ موبایل.
> مخاطب: تیم طراحی/توسعهٔ اپ موبایل (اندروید/iOS/کراس‌پلتفرم).
> هر چیزی که برای شروع طراحی لازم است، این‌جا قرارداد شده است.

---

## ۱. مبانی

| مورد | قرارداد |
|---|---|
| Base URL | `https://<دامنهٔ پلتفرم>/api/v1` |
| نسخه‌گذاری | پیشوند مسیر `/api/v1` (کانonical). هدر `X-API-Version` یا `Accept-Version` اختیاری؛ تعارض با مسیر = `400 VERSION_CONFLICT`. نسخه‌های پشتیبانی‌شده: `v1` |
| Content-Type | درخواست‌های POST/PUT/PATCH: `application/json` (یا form/multipart). غیرمجاز = `415 UNSUPPORTED_MEDIA_TYPE` |
| Accept | `application/json` (یا `*/*`). غیرمجاز = `406 NOT_ACCEPTABLE` |
| CSRF | مسیرهای `/api/*` عمداً معاف‌اند — احراز هویت با Bearer token است، نه cookie |
| قالب پاسخ موفق | `{"success": true, "message": "...", "data": {...}}` |
| قالب پاسخ خطا | `{"success": false, "message": "...", "error": {"code": "ERROR_CODE", "message": "..."}, "error_code": "ERROR_CODE"}` |
| صفحه‌بندی | پاسخ‌های لیستی: `{"success": true, "data": [...], "meta": {total, per_page, current_page, last_page, from, to}}`؛ پارامترهای `page` و `per_page` (حداکثر ۱۰۰) |
| Rate limit عمومی | گروه `/api/v1` پشت RateLimitMiddleware است؛ در صورت عبور از سقف: `429 RATE_LIMITED` |

## ۲. بوت‌استرپ اپ — `GET /config` (عمومی)

اولین درخواست‌ای که اپ باید بزند. نسخهٔ کلاینت با هدر `X-App-Version` (قالب semver) یا پارامتر `app_version` پاس داده می‌شود:

```json
{
  "data": {
    "maintenance": {"enabled": false, "message": "..."},
    "force_update": {"required": false, "min_version": "1.0.0", "latest_version": "1.2.0"},
    "features": {"lottery": true, "tasks": true, "...": "فقط فلگ‌های mobile-facing از allowlist"}
  }
}
```

- `force_update.required=true` ⇒ کاربر باید آپدیت کند (خروجی از فلو یا صفحهٔ آپدیت).
- `maintenance.enabled=true` ⇒ صفحهٔ تعمیرات؛ پیام از `maintenance.message`.
- `features` فقط شامل فلگ‌های مجاز برای موبایل است (fail-closed؛ فلگ ناشناخته مخفی می‌ماند).

## ۳. احراز هویت و چرخهٔ حساب

### ۳.۱ ثبت‌نام — `POST /auth/register` (عمومی)

```json
{
  "full_name": "علی تستی",
  "email": "ali@example.com",
  "password": "رمز قوی حداقل ۱۲ کاراکتر",
  "password_confirmation": "رمز قوی حداقل ۱۲ کاراکتر",
  "username": "ali_t",
  "mobile": "0912...",
  "referral_code": "ABC123",
  "terms": true,
  "g-recaptcha-response": "..."
}
```

- `terms` الزامی است (پذیرش قوانین سمت سرور enforce می‌شود).
- `g-recaptcha-response` فقط وقتی لازم است که موتور ریسک کپچا بخواهد؛ در آن صورت بدون توکن معتبر = `422 CAPTCHA_REQUIRED`. reCAPTCHA از اپ موبایل قابل پیاده‌سازی است (نسخهٔ invisible/v3 روی WebView یا SDK).
- رمز عبور از سیاست رسمی (طول، شباهت به ایمیل/نام، چک HIBP) عبور می‌کند.
- پاسخ موفق: `201` با `{"user_id", "email", "next_step": "verify_email"}`.
- سقف: ۵ ثبت‌نام در ساعت به‌ازای IP.
- **ضد-افشا:** ایمیل تکراری پاسخ عمومی می‌گیرد (وجود حساب اعلام نمی‌شود).

### ۳.۲ تأیید ایمیل با کد — `POST /auth/email/verify-code` (عمومی)

```json
{"email": "ali@example.com", "code": "A1B2C3"}
```

- کد ۶ کاراکتری (حروف بزرگ/رقم) از ایمیل تأیید؛ انقضا ۱ ساعت؛ تک‌مصرف.
- سقف: ۵ تلاش ناموفق در ۱۵ دقیقه به‌ازای ایمیل (+ ۱۰ در ۱۵ دقیقه per-IP) ⇒ `429`.
- کد/ایمیل غلط: `422 INVALID_CODE` (همان پیام برای کاربر غایب — ضد-افشا).
- موفق: `{"email_verified": true, "next_step": "login"}`. حسابِ از-قبل-تأییدشده idempotent است.

### ۳.۳ ارسال مجدد ایمیل تأیید — `POST /auth/email/resend-verification` (عمومی)

```json
{"email": "ali@example.com"}
```
- سقف: ۳ درخواست در ۲ دقیقه به‌ازای جفت email:IP.
- پاسخ همیشه عمومی موفق است (ضد-افشا). توکن قبلی با ارسال مجدد چرخش می‌کند (توکن لو رفته بی‌اعتبار می‌شود).

### ۳.۴ ورود و صدور توکن — `POST /auth/token` (عمومی)

```json
{"email": "ali@example.com", "password": "...", "token_name": "my-phone", "scopes": "user.read,user.write,wallet.read,seo.read,seo.write", "otp": "123456"}
```

- اسکوپ‌ها با **کاما** جدا می‌شوند؛ اسکوپ نامعتبر = `422 INVALID_SCOPES` (رد صریح، بدون حذف بی‌صدا). پوش دستگاه‌ها اسکوپ جدا ندارد — با `user.read/user.write` کار می‌کند.

- 2FA فعال باشد ⇒ بدون `otp`: `403 REQUIRES_2FA`؛ با otp غلط: `403 INVALID_2FA`.
- حساب قفل/ممنوع: `403 ACCOUNT_DISABLED`؛ ایمیل تأییدنشده: `403 EMAIL_UNVERIFIED`.
- موفق: `201`:

```json
{"data": {"token": "<hex-64>", "refresh_token": "<hex-64>", "expires_at": "+1 روز", "refresh_expires_at": "+90 روز", "scopes": [...]}}
```

- عمر access = ۱ روز؛ refresh = ۹۰ روز لغزان (هر چرخش تمدید می‌شود). پاسخ‌های حاوی توکن `Cache-Control: no-store` دارند — هرگز کش نشوند.
- سقف: ۸ تلاش در ۱۰ دقیقه per-IP+email (بعلاوهٔ قفل نرم شناسه پس از ۵ شکست).

### ۳.۵ اسکوپ‌ها — `GET /auth/scopes` (عمومی)

کاتالوگ ماشینی‌خوان همهٔ اسکوپ‌ها + `exact_only` + سطح ریسک. **پیش از صفحهٔ لاگین بگیرید** تا UI درست بسازید:
- اسکوپ عمومی `read` هر `*.read` را می‌پوشاند؛ `write` هر `*.write/.read` را.
- **exact-only** (فقط تطبیق دقیق یا `*` ادمین): `wallet.withdraw` و `account.security` — توکن عمومی write آن‌ها را نمی‌گیرد؛ در UI جدا و صریح درخواست شوند.
- اسکوپ‌های این بچ: `seo.read` / `seo.write` (استاندارد؛ با read/write سراسری پوشش داده می‌شوند).

### ۳.۶ نوسازی توکن — `POST /auth/refresh` (عمومی)

```json
{"refresh_token": "<hex-64>"}
```
- چرخش refresh توکن جدید می‌دهد (روتاسیون). سقف: ۳۰ در دقیقه per-IP.
- توکن باطل/منقضی ⇒ `401 INVALID_REFRESH_TOKEN` ⇒ کاربر به صفحهٔ ورود.
- در اپ: پیش از هر درخواست اگر `expires_at` نزدیک است، refresh بزنید؛ خطای `401` روی مسیر محافظت‌شده = نشانهٔ refresh فوری.

### ۳.۷ فراموشی/بازنشانی رمز — `POST /auth/password/forgot` و `POST /auth/password/reset` (عمومی)

```json
{"email": "ali@example.com"}          // forgot — لینک بازیابی به ایمیل
{"token": "<توکن از ایمیل>", "password": "...", "password_confirm": "..."}   // reset
```
- forgot: پاسخ همیشه عمومی موفق؛ سقف ۵/ساعت IP و ۳/ساعت ایمیل.
- reset موفق ⇒ **همهٔ نشست‌های وب و همهٔ توکن‌های API کاربر باطل می‌شوند** (پاسخ `revoked` را صریح برمی‌گرداند) ⇒ اپ باید کاربر را به لاگین برگرداند. این رفتار امنیتی عمدی است.

### ۳.۸ مدیریت توکن‌ها (نیاز به اسکوپ `auth.manage`)

- `GET /auth/tokens` — لیست توکن‌های فعال
- `POST /auth/revoke` — ابطال توکن جاری (لاگ‌اوت این دستگاه)
- `POST /auth/tokens/{id}/revoke` — ابطال یک توکن خاص (لاگ‌اوت دستگاه دیگر از «نشست‌های من»)

## ۴. پوش نوتیفیکیشن (FCM)

زیرساخت سمت سرور کامل است: کانال FCM در دیسپچر اعلان‌ها ثبت است و ارسال به **همهٔ دستگاه‌های** کاربر fan-out می‌شود (چند-دستگاه، چند-پلتفرم).

### ۴.۱ ثبت دستگاه — `POST /push/devices` (اسکوپ `user.write`)

```json
{"token": "<FCM token>", "platform": "android", "device_name": "گوشی علی"}
```
- `platform`: `android` | `ios` | `web`. `device_name` اختیاری (≤۱۲۰ کاراکتر).
- Idempotent است: ثبت دوبارهٔ همان توکن فقط فعالیت را تازه می‌کند.
- اگر همان دستگاه با حساب دیگری لاگین کند، مالکیت توکن منتقل می‌شود (رفتار صحیح چرخهٔ زندگی دستگاه).
- موفق: `201 {"registered": true}`. نامعتبر: `422 INVALID_DEVICE_TOKEN`.

### ۴.۲ لیست دستگاه‌ها — `GET /push/devices` (اسکوپ `user.read`)

```json
{"devices": [{"id": 3, "platform": "android", "device_name": "گوشی علی", "token_masked": "AAAAbbbb…", "last_activity": "...", "created_at": "..."}], "push_enabled": true, "total": 1}
```
- توکن FCM هرگز کامل برنمی‌گردد (ماسک ۸ کاراکتری).
- `push_enabled=false` یعنی سرور هنوز credentialهای FCM ندارد (تنظیم ادمین) — UI باید این حالت را نشان دهد.

### ۴.۳ حذف دستگاه — `POST /push/devices/{id}/revoke` (اسکوپ `user.write`)

فقط دستگاه خودِ کاربر حذف می‌شود (گارد مالکیت). غایب/متعلق به دیگری: `404 DEVICE_NOT_FOUND`.

**الگوی استفاده:** بلافاصله پس از لاگین موفق (یا refresh)، توکن FCM گوشی را ثبت کنید؛ در لاگ‌اوت `POST /auth/revoke` + حذف دستگاه.

## ۵. تسک‌های سئو (موتور درآمدی)

جریان کامل از اپ، بدون WebView برای فهرست/وضعیت — فقط باز کردن سایت هدف در مرورگر سیستمی/InApp.

### ۵.۱ فهرست آگهی‌های سئو — `GET /seo/ads?search=&page=` (اسکوپ `seo.read`)

ردیف‌ها فقط فیلدهای عمومی دارند: `id, title, keyword, description, min_payout, max_payout, target_duration, currency, proof_mode`.
> ⚠️ آدرس سایت هدف عمداً در فهرست **نشت نمی‌کند** — فقط از مسیر `go_url` عبور داده می‌شود.
>
> 🛡️ FIX-SEO3-01 (۲۰۲۶-۱۱-۰۹): دو فیلد جدید در هر ردیف — `avg_rating` (میانگین رأی
> مجریان به کمپین از ۵؛ رقم اعشار) و `rating_count` (تعداد رأی‌ها). امتیازها فقط از
> مجریانِ اجرای تکمیل‌شدهٔ همین کمپین ثبت می‌شوند (گارد سمت سرور) پس قابل‌اعتمادند؛
> کمپین بدون رأی = 0.0/0.

> 🛡️ FIX-T23-04 (۲۰۲۶-۱۱-۰۸): بازهٔ پاداش واقعی سئو در `min_payout`/`max_payout` است
> (پاداش = min + (score/100) × (max − min)) و مدت هدف تسک در `target_duration` (ثانیه).
> دو کلید قدیمی `price_per_click` و `estimated_time` هم‌چنان حضور دارند ولی **deprecated** هستند:
> مقدارشان به‌ترتیب alias همین `min_payout` و `target_duration` است (قبلاً برای کمپین سئو
> همیشه ۰ برمی‌گشتند). اپ باید نمایش پاداش/زمان را به کلیدهای جدید منتقل کند.
> همچنین فهرست از این به بعد «کاربر-محور» است: آگهی خود کاربر و کمپین‌های بدون بودجهٔ
> کافی در آن ظاهر نمی‌شوند (FIX-T23-03).

### ۵.۲ شروع تسک — `POST /seo/ads/{id}/start` (اسکوپ `seo.write`)

```json
{"execution_id": 5, "go_url": "https://<domain>/seo/5/go/<nonce-48hex>", "proof_mode": "pixel", "next_step": "open_go_url_then_complete"}
```
- `go_url` مطلق است و **بدون لاگین** کار می‌کند (capability URL): در Custom Tab / SFSafariViewController / WebView بازش کنید. عبور از آن، کلیک را در سمت سرور مهر می‌زند (nonce یک‌بارمصرف، اعتبار ۱۵ دقیقه).
- `proof_mode`: `off` (فقط مهر کلیک) | `pixel` (صفحهٔ فرود ردیاب دارد) | `postback` (سرور تبلیغ‌دهنده امضای HMAC برمی‌گرداند). برای پله‌های پاداش: بدون‌اثبات ۶۰٪ ← کلیک‌اثبات‌شده ۸۵٪ ← فروداثبات‌شده ۱۰۰٪.
- خطاهای رایج: «امروز این تسک را انجام داده‌اید»، سقف روزانه/ساعتی، بودجهٔ تمام‌شده ⇒ `422 SEO_START_FAILED` با پیام فارسی.

### ۵.۳ وضعیت اجرا — `GET /seo/executions/{id}` (اسکوپ `seo.read`)

```json
{
  "status": "started", "proof_state": "click", "click_counted": true, "click_counted_at": "...",
  "landing_verified": false, "landing_verified_at": null, "landing_proof_channel": null,
  "proof_mode": "pixel", "go_url": null, "payout_amount": 0, "final_score": null
}
```
- 🛡️ FIX-SEO3-03 (۲۰۲۶-۱۱-۰۹): `proof_state` کلید راحتی سه‌حالته است — `none` |
  `click` | `landing` — همان منطق نشان وب؛ برای نمایش وضعیت پاداش فقط همین یک فیلد
  کافی است (سه بولیان تفکیکی برای سازگاری مانده‌اند).
- پس از مهر کلیک، `go_url=null` می‌شود (بازکردن مجدد لازم نیست).
- بعد از بازگشت کاربر از مرورگر، این وضعیت را poll کنید تا `click_counted` را ببینید.

### ۵.۴ تکمیل — `POST /seo/executions/{id}/complete` (اسکوپ `seo.write`)

```json
{
  "duration": 95, "active_time": 88, "scroll_depth": 72.5, "interactions": 6,
  "target_opened": true, "focus_blur_count": 1, "pause_count": 2,
  "scroll_speed": 1.2, "interaction_types": ["tap", "scroll"],
  "client_mode": "mobile_app"
}
```
- `duration/scroll_depth/interactions` الزامی و عددی‌اند؛ `client_mode` در کانال API فقط `mobile_app` یا `mobile_web` (ادعای `web` رد می‌شود).
- پرداخت **async** است: `duration/active_time` سمت سرور به زمان واقعی گذاشته‌شده بازنویسی می‌شود — ادعای خام کلاینت پاداش نمی‌سازد. نتیجهٔ نهایی را از تاریخچه/کیف پول بگیرید.

### ۵.۵ لغو / تاریخچه — `POST /seo/executions/{id}/cancel` (`seo.write`)، `GET /seo/history` (`seo.read`)

### ۵.۶ گزارش تخلف و امتیاز به کمپین سئو — `POST /interactions/report` و `POST /interactions/rate` (`user.write`)

> 🛡️ FIX-SEO3-01 (۲۰۲۶-۱۱-۰۹ — تصمیم ۱): مسیرهای وب سئو فعال شدند و کانال API هم
> **هم‌ارز گاردشده** شد. برای سئو همان اندپوینت عمومی تعاملات را صدا بزنید:

```json
POST /api/v1/interactions/rate   {"type": "seo_task", "id": 12, "rating": 4, "context": "global"}
POST /api/v1/interactions/report {"type": "seo_task", "id": 12, "reason": "سایت خراب است", "description": "…", "context": "global"}
```

- `id` = شناسهٔ **آگهی** (نه اجرا). گاردهای سمت سرور (هم‌ارز وب): امتیاز فقط برای
  مجریِ اجرای **تکمیل‌شده**ٔ همین کمپین و نه مالک خودش؛ گزارش فقط برای مجری با اجرای
  started/completed. رد ⇒ `422` با `SEO_RATE_GUARDED` / `SEO_REPORT_GUARDED` و پیام فارسی.
- پاسخ rate شامل `average_rating` (میانگین بیزیَن) است؛ برای نمایش فهرست از
  `avg_rating`/`rating_count` در `GET /seo/ads` استفاده کنید.
- گزارش‌ها dedupe اتمیک ۲۴ساعته دارند و در آستانهٔ ۵ گزارش، هشدار به ادمین‌ها می‌رود.

> 🛡️ FIX-SOCGUARD-01 (۲۰۲۶-۱۱-۰۹): `social_task` هم حالا از همان مسیر گاردشده می‌گذرد
> (قبلاً بی‌گارد مستقیم به سرویس می‌رفت — حفرهٔ pre-existing بسته شد). همان اندپوینت:

```json
POST /api/v1/interactions/rate   {"type": "social_task", "id": 34, "rating": 5, "comment": "اختیاری", "context": "global"}
POST /api/v1/interactions/report {"type": "social_task", "id": 34, "reason": "…", "description": "…", "context": "global"}
```

- `id` = شناسهٔ **آگهی/کمپین سوشیال**. گاردها: مالک کمپین به خودش امتیاز نمی‌دهد؛ فقط
  مجریِ اجرای **تأییدشدهٔ** (approved) همین کمپین؛ 🛡️ FIX-SOCREPORT-01 (۲۰۲۶-۱۱-۰۹):
  گزارش فقط برای مجریِ همین کمپین — یعنی کسی که اجرایی از آن دارد — و نه مالک خودش؛
  🛡️ FIX-SOCREPORT2-01 (داوری ۲۰۲۶-۱۱-۰۹): آن اجرا باید **غیر-pending/غیر-cancelled**
  باشد (در جریان، ارسال‌شده، تأیید، ردشده مجاز است). رد ⇒ `422` با
  `SOCIAL_RATE_GUARDED` / `SOCIAL_REPORT_GUARDED` و پیام فارسی.
  تا این بچ گزارش قرارداد ضعیف داشت (هر کاربر لاگین + فقط آگهی موجود)؛ حالا با
  امتیاز متقارن شد. چون سوشیال برخلاف سئو کانال dispute برای اجرای ردشده ندارد،
  مجریِ ردشده هم می‌تواند گزارش بدهد (گزارش تنها کانال شکایت اوست).
- `comment` (اختیاری، حداکثر ۱۰۰۰ نویسه) حالا در rate برای هر دو `type` گاردشده به سرور
  می‌رسد — قبلاً از کانال API بی‌صدا حذف می‌شد (توازن API/وب).
- 🛡️ FIX-SOCRATE-DISPLAY-01 (۲۰۲۶-۱۱-۰۹): میانگین رأی کاربران به کمپین‌های سوشیال حالا
  **عمومی** است — ردیف‌های `GET /api/v1/social/tasks` (اسکوپ `social.read`) دو فیلد تازه
  `avg_rating` (۰ تا ۵) و `rating_count` دارند؛ بدون رأی = `0` صادقانه (نه حذف کلید).
  رأی‌ها فقط از مجریِ اجرای تأییدشده ثبت می‌شوند پس عدد قابل‌اعتماد است. همین نمایش روی
  کارت‌های فید وب `/tasks` و پنل تبلیغ‌دهندهٔ کمپین (`/ads/{id}`) هم اضافه شد — قرینهٔ
  `FIX-SEO3-01` سئو که `avg_rating`/`rating_count` را در `GET /seo/ads` می‌دهد.
- سایر `type` ها (مثل ویترین) همان رفتار مستقیم قبلی را دارند — بدون تغییر و بدون
  whitelist جدید.

## ۶. تسک‌های سفارشی (بازار ماموریت‌های کارفرما)

> 📱 بچ **FIX-MOBCTR** (۲۰۲۶-۱۱-۰۷) — موبایل شهروند کاملِ این جریان است؛ همهٔ انواع مدرک (متن/کد/لینک/اسکرین‌شات/فایل/ویدیو) بدون WebView قابل ارسال‌اند. نوع مدرک (`proof_type`) همیشه سرور-محاسبه است و در هر پاسخ اعلام می‌شود؛ اپ هرگز خودش تشخیص نمی‌دهد.

### ۶.۱ فهرست تسک‌های در دسترس — `GET /custom-tasks/tasks?page=&per_page=` (اسکوپ `customtask.read`)

```json
{
  "data": {
    "tasks": [
      {"id": 12, "title": "...", "description": "...", "reward": "3000.00", "currency": "irt",
         "remaining_slots": 7, "proof_type": "screenshot", "proof_description": "از پنل کاربری اسکرین‌شات بگیرید..."}
    ]
  },
  "meta": {"total": 23, "per_page": 20, "current_page": 1, "last_page": 2, "from": 1, "to": 20}
}
```
- `proof_type`: یکی از `text` · `code` · `url` · `screenshot` · `file` · `video` — قبل از start مشخص است؛ بر اساس آن فرم/آپلودر مناسب را باز کنید.
- `proof_description`: دستورالعمل کارفرما (≤۲۰۰۰ کاراکتر).
- لیست از قبل تسک‌های شروع‌شدهٔ همین کاربر را حذف می‌کند و `meta.total` هم‌شرطِ خودِ لیست است (پایان‌بندی صفحه‌بندی دقیق).

### ۶.۲ شروع — `POST /custom-tasks/tasks/{id}/start` (اسکوپ `customtask.write`)

```json
{"submission_id": 88, "deadline": "2026-11-09 12:00:00", "proof_type": "screenshot", "proof_description": "..."}
```
- `deadline` محلیِ ارسال مدرک است؛ خطاهای رایج: ظرفیت پر/تکرار/گارد ضدتقلب ⇒ `422` با پیام فارسی.

### ۶.۳ ارسال مدرک — `POST /custom-tasks/submissions/{id}/proof` (اسکوپ `customtask.write`)

کدام بدنه بر اساس `proof_type` (از پاسخ start/detail):

| proof_type | بدنه | قاعده
|---|---|---|
| `text` | JSON `{"note": "..."}` | note حداقل ۱۰ کاراکتر (لینک لازم نیست)
| `code` | JSON `{"code": "..."}` | کد/شناسه حداقل ۲ کاراکتر
| `url` | JSON `{"proof_link": "https://..."}` | URL معتبر؛ میزبان لوکال رد
| `video` | JSON `proof_link` **یا** multipart `proof_file` | لینک ویدیو یا فایل mp4/webm/mov تا ۳۰MB
| `screenshot` | multipart `proof_file` | فقط تصویر jpg/jpeg/png/webp تا ۵MB (PDF رد)
| `file` | multipart `proof_file` | تصویر یا PDF تا ۵MB |

- نام‌های قرارداد مشترک (`proof_url`/`proof_text`/`proof_code`) هم پذیرفته می‌شوند؛ `note` و `code` نام‌های موبایل‌پسند همان فیلدها هستند.
- فایل فقط از آپلود multipart می‌آید؛ هر رشتهٔ `proof_file`/`proof_file_hash` در JSON عمداً نادیده گرفته می‌شود (امنیت مسیر فایل، الگوی S17-2).
- پاسخ موفق:
```json
{"data": {"submission_id": 88, "status": "submitted", "submitted_at": "2026-11-07 14:02:11",
           "auto_approve_info": "در صورتی که کارفرما تا 48 ساعت آینده بررسی نکند، بصورت خودکار تایید خواهد شد."}}
```

### ۶.۴ اجراهای من / جزئیات — `GET /custom-tasks/my/submissions?page=` و `GET /custom-tasks/submissions/{id}` (`customtask.read`)

- لیست: ردیف‌ها با `proof_type` (نوع مدرک تسک) + همان `meta` صفحه‌بندی.
- جزئیات: `status`، `proof` (لینک ارسالی)، `proof_code` (کد ارسالی)، `admin_note`، `reward`/`currency`، `proof_type`، `proof_description`.
- وضعیت‌ها: `in_progress` → `submitted` → `approved` | `rejected` (+ مسیر اختلاف: `disputed`).

## ۷. تسک‌های سوشیال

> 📱 بچ‌های FIX-SOCRATE-DISPLAY (۲۰۲۶-۱۱-۰۹) و FIX-SOCRATE-MOBILE-01 (۲۰۲۶-۱۱-۱۰) —
> قرارداد کامل جریان سوشیال برای اپ. این جریان برخلاف تسک سفارشی **بدون مدرک (proofless)**
> است: مجری متن/لینک/اسکرین‌شات ارسال نمی‌کند؛ نتیجه از الگوی رفتاری، زمان فعال و در صورت
> نیاز وریفای دوربین — همگی سمت سرور — تعیین می‌شود. اسکوپ‌ها: `social.read` /
> `social.write` (+فلگ `tasks`).

### ۷.۱ حساب‌های سوشیال من — `GET/POST /social/accounts`، `PUT/DELETE /social/accounts/{id}`

```json
POST /api/v1/social/accounts   {"platform": "instagram", "account_handle": "@ali", "access_token": "اختیاری"}
```
- `platform`: `instagram` | `telegram` | `youtube` | `twitter` | `tiktok`؛ `account_handle` الزامی (بدون این دو ⇒ 422).
- PUT بدنهٔ فیلدهای قابل به‌روزرسانی؛ DELETE گارد مالکیت دارد (حساب متعلق به دیگری/غایب ⇒ 404).

### ۷.۲ فهرست تسک‌های در دسترس — `GET /social/tasks?page=&per_page=` (`social.read`)

- فقط کمپین‌های `social_task` فعالِ دارای ظرفیت و بودجه؛ اجراهای `pending/completed` خودِ کاربر از فهرست حذف می‌شوند (ضدتکرار — کاربر تسکِ در جریان را دوباره نمی‌بیند).
- هر ردیف علاوه بر فیلدهای کمپین (`id, title, description, platform, task_type, price_per_task, …`) دو فیلد ستارهٔ رأی کاربران دارد:
  - `avg_rating` — میانگین رأی مجریان به کمپین (۰ تا ۵، رقم اعشار)؛ `rating_count` — تعداد رأی‌ها. کمپین بدون رأی = `0`/`0` صادقانه (نه حذف کلید). رأی‌ها فقط از مجریِ اجرای تأییدشدهٔ همین کمپین ثبت می‌شوند (گارد سمت سرور) پس عدد قابل‌اعتماد است.

### ۷.۳ جزئیات کمپین — `GET /social/ads/{id}` (`social.read`)

- **غیرمالک (مجری بالفعل/بالقوه):** پاسخ عمومیِ sanitize شده: `id, type, title, description, target_url, platform, action_type, reward_amount, status` + سه فیلد ستاره:
  - `avg_rating` / `rating_count` — همان اعداد فهرست؛
  - `my_rating` — رأی فعلی شما به این کمپین (۱..۵ یا `null` = هنوز رأی نداده‌اید). فرم ستاره را با آن هیدراته کنید؛ رأی مجدد = به‌روزرسانی همان رأی (نه رأی دوم).
- **مالک کمپین:** پاسخ کامل مدیریتی (بودجه/شمارنده‌ها/…) + `avg_rating`/`rating_count` (قرینهٔ کارت بازخورد مجریان پنل وب)؛ `my_rating` ندارد — مالک به کمپین خودش رأی نمی‌دهد (گارد تضاد منافع).
- آگهی غیرسوشیال هیچ فیلد ستاره‌ای نمی‌گیرد (رأی‌ها per-نوع جدا هستند).

### ۷.۴ شروع و ارسال — `POST /social/tasks/{id}/start` و `POST /social/tasks/{id}/submit` (`social.write`)

```json
start  → {"success": true, "execution_id": 5, "status": "in_progress", "expected_time": 60}
submit ← {"active_time": 88, "behavior_signals": {…}, "idempotency_key": "اختیاری"}
```
- `submit` تلومتری رفتاری می‌فرستد نه مدرک (proofless)؛ `idempotency_key` اختیاری است و تکرار امن می‌سازد.
- مسیرهای وریفای رفتاری/دوربینی هم‌مبدأِ مرورگرند (`/social-tasks/verify/*` با سشن + CSRF) — این گام را از WebView صفحهٔ اجرا انجام دهید، نه از کانال Bearer.

### ۷.۵ تاریخچهٔ من — `GET /social/tasks/history?page=` (`social.read`)

- ردیف‌های اجرای کاربر: فیلدهای اجرا + `title, platform, task_type, price_per_task` کمپین.

### ۷.۶ پنل تبلیغ‌دهنده — `GET/POST /social/ads`، `POST /social/ads/{id}/{pause|resume|cancel}` (`social.read`/`social.write`)

- `GET /social/ads` — کمپین‌های خود کاربر؛ هر ردیف `avg_rating`/`rating_count` دارد (قرینهٔ پنل وب).
- `POST /social/ads` ایجاد کمپین؛ pause/resume/cancel چرخهٔ وضعیت (گارد مالکیت).

### ۷.۷ رأی و گزارش — همان اندپوینت عمومی تعاملات (بخش ۵.۶)

- `POST /api/v1/interactions/rate` با `type=social_task` (گارد: فقط مجریِ اجرای تأییدشده، نه مالک) — پاسخ `average_rating` تازه را برمی‌گرداند؛ برای خواندن رأی موجود از `my_rating` در `GET /social/ads/{id}` استفاده کنید.
- گزارش تخلف: `POST /api/v1/interactions/report` با `type=social_task` (گزارش فقط برای مجریِ همین کمپین — جزئیات گاردها در ۵.۶).

## ۸. بقیهٔ قابلیت‌های آمادهٔ API (خلاصه)

| حوزه | مسیرها | اسکوپ |
|---|---|---|
| پروفایل/اعلان‌ها/تیکت/تنظیمات/پیام‌ها | `GET/POST /user/*` | `user.read` / `user.write` |
| 2FA | `GET /user/2fa/status`، `POST /user/2fa/{setup,enable,disable}` | خواندن=user.read؛ disable=`account.security` (exact-only) |
| نشست‌های وب | `GET /user/sessions`، `POST /user/sessions/{id}/revoke` | user.read / user.write |
| KYC | `GET /user/kyc/status`، `POST /user/kyc/submit` | user.read / user.write |
| کیف پول | `GET /wallet*`، `POST /wallet/...` | wallet.read / wallet.write |
| برداشت | `POST /wallet/withdraw` | **`wallet.withdraw` (exact-only)** |
| تسک‌های سوشال | `/social/*` — قرارداد کامل در بخش ۷ | social.read / social.write (+فلگ tasks) |
| مارکت‌پلیس اینفلوئنسر | `/influencer/*` | influencer.read / influencer.write |
| لاتری | `/wallet/lottery/*` | wallet.* (+فلگ lottery) |
| وترین/تعاملات | `/vitrine/*`، `/interactions/*` | user.read / user.write |
| Realtime (polling) | `/real-time/*` | realtime |
| احراز/تأیید هویت سرویس | `/verification/*` | verification.read/write |

## ۹. CORS / WebView

- درخواست‌های native (OkHttp/URLSession) اصلاً مبتنی بر CORS نیستند — هیچ کاری لازم نیست.
- اگر بخشی از اپ در WebView (مثل فرم پرداخت) میزبانی می‌شود، origin آن (مثلاً `https://app.example` یا `capacitor://localhost` / `ionic://localhost`) باید توسط ادمین به `CORS_ALLOWED_ORIGINS` اضافه شود — اسکیم‌های capacitor/ionic پذیرفته می‌شوند.
- هدرهای مجاز CORS: `Content-Type, Authorization, X-Requested-With, X-CSRF-Token, Accept, Origin, X-Request-ID, X-Correlation-ID`.

## ۱۰. چک‌لیست امنیتی برای تیم موبایل

1. توکن access را در Keychain/Keystore ذخیره کنید (نه SharedPrefs/plain storage).
2. هرگز `refresh_token` را لاگ نکنید؛ پاسخ‌های توکن‌دار no-store اند.
3. خطای `401` ⇒ یک‌بار refresh؛ دوباره `401` ⇒ لاگ‌اوت کامل.
4. خطای `403 INSUFFICIENT_SCOPE` ⇒ صفحهٔ «دسترسی به این عملیات داده نشده» + لینک مدیریت اسکوپ‌ها، نه خطای عمومی.
5. `429` ⇒ backoff نمایی با `Retry-After`؛ هرگز retry فوری نکنید.
6. پس از `POST /auth/password/reset` همهٔ توکن‌ها می‌میرند — حالت «رمز عوض شد، دوباره وارد شوید» را بسازید.
7. توکن FCM را بعد از هر لاگین/refresh دوباره ثبت کنید (idempotent است) و در لاگ‌اوت `POST /auth/revoke` + `POST /push/devices/{id}/revoke`.

## ۱۱. نقشهٔ مسیرها (خلاصهٔ یک‌خطی)

```
عمومی:
  POST /api/v1/auth/register
  POST /api/v1/auth/email/verify-code
  POST /api/v1/auth/email/resend-verification
  POST /api/v1/auth/password/forgot
  POST /api/v1/auth/password/reset
محافظت‌شده:
  GET  /api/v1/push/devices                      (user.read)
  POST /api/v1/push/devices                      (user.write)
  POST /api/v1/push/devices/{id}/revoke          (user.write)
  GET  /api/v1/seo/ads                           (seo.read)
  GET  /api/v1/seo/executions/{id}               (seo.read)
  GET  /api/v1/seo/history                       (seo.read)
  POST /api/v1/seo/ads/{id}/start                (seo.write)
  POST /api/v1/seo/executions/{id}/complete      (seo.write)
  POST /api/v1/seo/executions/{id}/cancel        (seo.write)
  GET  /api/v1/custom-tasks/tasks                 (customtask.read)
  GET  /api/v1/custom-tasks/my/submissions        (customtask.read)
  GET  /api/v1/custom-tasks/submissions/{id}      (customtask.read)
  POST /api/v1/custom-tasks/tasks/{id}/start      (customtask.write)
  POST /api/v1/custom-tasks/submissions/{id}/proof (customtask.write)
سوشیال (FIX-SOCRATE-MOBILE-01 — بخش ۷):
  GET  /api/v1/social/accounts                  (social.read)
  GET  /api/v1/social/tasks                      (social.read)
  GET  /api/v1/social/tasks/history              (social.read)
  GET  /api/v1/social/ads                        (social.read)
  GET  /api/v1/social/ads/{id}                   (social.read)
  POST /api/v1/social/accounts                   (social.write)
  PUT  /api/v1/social/accounts/{id}              (social.write)
  DELETE /api/v1/social/accounts/{id}            (social.write)
  POST /api/v1/social/ads                        (social.write)
  POST /api/v1/social/ads/{id}/pause             (social.write)
  POST /api/v1/social/ads/{id}/resume            (social.write)
  POST /api/v1/social/ads/{id}/cancel            (social.write)
  POST /api/v1/social/tasks/{id}/start           (social.write)
  POST /api/v1/social/tasks/{id}/submit          (social.write)
وب (برای اپ، بدون session):
  GET  /seo/{id}/go/{token}   ← لینک شمارندهٔ کلیک؛ از مرورگر سیستمی باز می‌شود
```

---

*این سند با بچ FIX-MOBILE (۲۰۲۶-۱۱-۰۲) همگام است: FIX-MOBILE-01 (چرخهٔ حساب)، FIX-MOBILE-02 (پوش چند-دستگاهی)، FIX-MOBILE-03 (API دستگاه‌ها)، FIX-MOBILE-04 (API سئو + اسکوپ‌ها)، FIX-MOBILE-05 (go بدون session). به‌روزرسانی FIX-MOBCTR (۲۰۲۶-۱۱-۰۷): بخش ۶ — قرارداد کامل تسک‌های سفارشی (proof_type در همهٔ پاسخ‌ها، همهٔ کانال‌های مدرک، meta صفحه‌بندی). به‌روزرسانی FIX-SOCRATE-MOBILE-01 (۲۰۲۶-۱۱-۱۰): بخش ۷ — قرارداد کامل تسک‌های سوشیال (ستاره‌های رأی در tasks/ads/ads/{id} + my_rating؛ مستندات قبلی ستارهٔ سوشیال در ۵.۶ پراکنده بود و جمع شد).*
