# گزارش فاز: یکسان‌سازی قرارداد ورودی کنترلرها (ردیف زرد — FormRequest)

- **تاریخ:** ۲۰۲۶-۰۸-۲۴
- **بازبین:** Anthropic Claude Opus 4.8 (طبق قاعده‌ی طلایی پروژه)
- **وضعیت پایانی سوئیت:** ✅ `2118 tests, 7401 assertions, 0 failures, 3 skipped`
- **وضعیت فاز:** 🏁 **بسته‌شده** — با تصمیم صریح کارفرما، ۱۲ کنترلر مبتنی بر `validatorFactory()->make` مهاجرت داده **نمی‌شوند** (بخش ۶).

---

## ۱) هدف و دامنه

این فاز، ادامه‌ی «ردیف زرد» از گزارش قراردادهای کاری (Item D) بود: حذف الگوی
«خواندن بدنه‌ی خام `php://input` + اعتبارسنجی دستی if/else در کنترلر» و
جایگزینی آن با کلاس‌های `FormRequest` در `app/Validators/Requests/` که از
`App\Validators\BaseFormRequest` ارث می‌برند و از موتور `core/Validator.php` استفاده می‌کنند.

**اصل حاکم بر کل فاز: حفظ رفتار بیرونی.** پیام‌های خطای فارسی، شکل پاسخ JSON،
کدهای وضعیت HTTP و مقادیر پیش‌فرض، عیناً همان قرارداد قبلی باقی ماندند مگر در
موارد «سخت‌سازی» که در بخش ۴ فهرست شده‌اند.

## ۲) کنترلرهای مهاجرت‌کرده (به تفکیک بچ)

### بچ ۱ — Influencer / Level / Referral

| کنترلر / متد | FormRequest | نکته‌ی حفظ رفتار |
|---|---|---|
| `Admin/InfluencerController::approveProfile` | `ApproveInfluencerProfileRequest` | قاعده‌ی شرطی «دلیل ≥ ۵ کاراکتر فقط برای reject/suspend» با override متد `validate()` |
| `Admin/InfluencerController::resolveDispute` | `ResolveInfluencerDisputeRequest` | fallback شناسه از پارامتر مسیر (`route param id`) حفظ شد؛ پیش‌فرض `refund_percent = '0'` بعد از ولیدیشن |
| `Admin/InfluencerController::approveVerification` | `ApproveInfluencerVerificationRequest` | — |
| `Admin/InfluencerController::rejectVerification` | `RejectInfluencerVerificationRequest` | — |
| `Admin/LevelController::changeLevel` | `ChangeUserLevelRequest` | چک‌های مجوز (self/admin) دست‌نخورده؛ پیش‌فرض دلیل «تغییر توسط مدیر» |
| `User/LevelController::purchase` | `PurchaseLevelRequest` | پیش‌فرض ارز `irt` |
| `Admin/ReferralController::cancel` | `AdminActionReasonRequest` ♻️ | کلاس تک‌فیلدیِ قابل استفاده‌ی مجدد (reason) |
| `Admin/ReferralController::batchPay` | `CurrencySelectionRequest` ♻️ | کلاس تک‌فیلدیِ قابل استفاده‌ی مجدد (currency) |

### بچ ۲ — AdTask / Coupon

| کنترلر / متد | FormRequest | نکته‌ی حفظ رفتار |
|---|---|---|
| `Admin/AdTaskController::approve` | `ModerateCustomTaskRequest` | شاخه‌بندی approve/reject حفظ شد؛ پیام تاریخی «تصمیم نامعتبر.» حالا از خود ولیدیشن (`in:approve,reject`) برمی‌گردد |
| `User/CouponController::validate` | `ValidateCouponRequest` | چک «مبلغ > ۰» با BCMath (`bccomp`) در override متد `validate()`؛ ⚠️ پاسخ خطا مثل کد اصلی **بدون status code صریح** می‌ماند تا کلاینت‌های فعلی نشکنند؛ پیش‌فرض‌های `irt` و `all` حفظ شدند |

### بچ ۳ — ExecutorTask (پیچیده‌ترین مورد)

| متد | FormRequest | نکته‌ی حفظ رفتار |
|---|---|---|
| `forceApproveSubmission` | `ForceModerateSubmissionRequest` ♻️ | چک ۴۰۴ «یافت نشد.» بعد از ولیدیشن دست‌نخورده |
| `forceRejectSubmission` | همان کلاس (اشتراکی) | پیش‌فرض «رد توسط ادمین» بعد از ولیدیشن |
| `resolveDispute` | `ResolveExecutorDisputeRequest` | نرمال‌سازی مترادف‌ها (`worker_wins→executor`، `partial→split` و…) و alias `worker_percent→executor_percent` **قبل از** ساخت Request در کنترلر انجام می‌شود تا قواعد ولیدیشن قطعی بمانند؛ پیام «تصمیم نامعتبر است.» عیناً حفظ شد |
| `reviewReport` | `ReviewTaskReportRequest` | پیام «وضعیت نامعتبر است.» حفظ شد؛ متغیر مرده‌ی `executor_percent` (خوانده می‌شد ولی استفاده نمی‌شد) حذف شد |
| `batchAction` | `BatchTaskActionRequest` | چون قاعده‌ی `required` در موتور Validator روی آرایه‌ی خالی هم fail می‌کند، `required|array` هر دو گارد قدیمی را پوشش می‌دهد |

قبلاً نیز (ابتدای ردیف زرد): `User/CustomTaskController::rateSubmission` → `RateSubmissionRequest`.

## ۳) الگوی تثبیت‌شده (قرارداد رسمی از این پس)

1. کلاس Request در `app/Validators/Requests/` با `rules()` + `messages()`؛ پیام‌های فارسی legacy عیناً منتقل می‌شوند.
2. قواعد شرطی/غیرقابل‌بیان با rule string → override:
   ```php
   public function validate(): bool
   {
       if (!parent::validate()) { return false; }
       // چک سفارشی؛ در صورت خطا:
       $this->errors['field'][] = 'پیام فارسی';
       return false / true;
   }
   ```
   (نمونه‌ها: `ApproveInfluencerProfileRequest`، `ValidateCouponRequest`)
3. کنترلر: decode بدنه‌ی JSON → ساخت Request → در صورت شکست، پاسخ ۴۲۲ با
   `{success:false, message: <اولین خطا>, errors: {...}}` (helper خصوصی `firstValidationError()`).
4. پیش‌فرض‌ها **بعد از** ولیدیشن با `?: 'default'` اعمال می‌شوند، نه داخل قواعد.
5. برای بدنه‌های تک‌فیلدی، کلاس‌های قابل استفاده‌ی مجدد (`AdminActionReasonRequest`، `CurrencySelectionRequest`) به‌جای تکثیر فایل per-action.
6. نرمال‌سازی ورودی (مترادف‌ها، alias فیلدها) قبل از ساخت Request در کنترلر انجام می‌شود.
7. ⚠️ نکته‌ی موتور: `min`/`max` فقط وقتی قاعده‌ی `numeric` هم حاضر باشد مقایسه‌ی عددی می‌کنند؛ در غیر این صورت طول رشته سنجیده می‌شود.
8. الفبای ارز در کل پروژه قفل شده: `in:irt,usdt` (حروف کوچک).

## ۴) سخت‌سازی‌های عمدی (تغییرات کنترل‌شده‌ی رفتار)

- `User/LevelController::purchase` و `User/CouponController::validate`: ارز محدود به `irt|usdt` شد (قبلاً هر رشته‌ای عبور می‌کرد).
- `ExecutorTaskController::resolveDispute`: درصد مجری حالا `nullable|numeric` (قبلاً هر scalar).
- شناسه‌های عددی (`task_id`، `submission_id`، `dispute_id`، `report_id` و…) حالا `required|integer|min:1` دارند؛ ورودی‌های زباله به‌جای عبور به لایه‌ی سرویس، در مرز کنترلر با ۴۲۲ رد می‌شوند.

## ۵) نتیجه‌ی راستی‌آزمایی نهایی

`grep` سراسری روی `app/Controllers/`: **هیچ خواندن `php://input` اعتبارسنجی‌نشده‌ای باقی نمانده است.**
تمام ۱۳ نقطه‌ی باقی‌مانده یا مستقیماً خوراک‌دهنده‌ی یک FormRequest هستند یا helperهای
`jsonBody()/getJsonInput()` که خروجی‌شان بلافاصله وارد FormRequest می‌شود
(`ContentController::store → StoreContentRequest`، `CustomTaskController::rateSubmission → RateSubmissionRequest`).

پس از هر بچ، سوئیت کامل اجرا و سبز تأیید شد (آخرین اجرا: 2118/7401، صفر شکست).

## ۶) تصمیم بسته‌شدن: ۱۲ کنترلر `validatorFactory()->make` مهاجرت داده نمی‌شوند

فهرست: `Admin/{Content, Coupon, Investment, KYC, Level, Role, User, Withdrawal}Controller` و
`User/{Auth, KYC, ManualDeposit, Ticket}Controller`.

**دلیل تصمیم (تأییدشده توسط کارفرما):**
- این کنترلرها **همین حالا از موتور ولیدیشن پروژه عبور می‌کنند** — باگ امنیتی یا ورودی کنترل‌نشده ندارند.
- مهاجرتشان صرفاً یکنواختی سبک است: حجم تغییر بالا (۱۲ فایل + ده‌ها کلاس جدید)، ارزش عملی نزدیک صفر، ریسک غیرصفر شکستن پیام‌های خطای موجود.
- هم‌راستا با اصل Item D: یکسان‌سازی فقط جایی که قرارداد واقعاً شکسته است، نه بازنویسی سراسری برای زیبایی.

**قاعده برای آینده:** کد جدید باید FormRequest بسازد (الگوی بخش ۳). کد موجودِ
`validatorFactory()->make` فقط در صورت دست‌خوردن جدیِ همان متد، فرصت‌طلبانه مهاجرت داده شود.

## ۷) فهرست کامل فایل‌های این فاز

**کلاس‌های Request جدید (۱۴):**
`ApproveInfluencerProfileRequest`، `ResolveInfluencerDisputeRequest`، `ApproveInfluencerVerificationRequest`، `RejectInfluencerVerificationRequest`، `ChangeUserLevelRequest`، `PurchaseLevelRequest`، `AdminActionReasonRequest` ♻️، `CurrencySelectionRequest` ♻️، `ModerateCustomTaskRequest`، `ValidateCouponRequest`، `ForceModerateSubmissionRequest` ♻️، `ResolveExecutorDisputeRequest`، `ReviewTaskReportRequest`، `BatchTaskActionRequest`
(+ `RateSubmissionRequest` از ابتدای ردیف زرد)

**کنترلرهای ویرایش‌شده (۸):**
`Admin/InfluencerController`، `Admin/LevelController`، `User/LevelController`، `Admin/ReferralController`، `Admin/AdTaskController`، `User/CouponController`، `Admin/ExecutorTaskController`، `User/CustomTaskController`
