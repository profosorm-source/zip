# Runbook ممیزی مالی Legacy

## هدف

این runbook قبل از migration یا cutover مالی اجرا می‌شود تا اختلاف بین تراکنش، دفتر کل، escrow و دادهٔ legacy بدون تغییر داده مشخص شود.

ابزار اصلی:

```text
tools/legacy_financial_audit.sql
```

## قواعد ایمنی

- فقط روی read replica، snapshot یا اتصال با دسترسی read-only اجرا شود.
- فایل audit شامل `SELECT` و metadata inspection است و migration نیست.
- تا قبل از تعیین owner و evidence برای هر finding، هیچ `UPDATE`، `DELETE` یا backfill اجرا نشود.
- خروجی کامل همراه با زمان UTC، نام snapshot و نسخهٔ migration ذخیره شود.

## اجرا

نمونهٔ اجرای batch روی MariaDB/MySQL:

```bash
mariadb --batch --raw --show-warnings < tools/legacy_financial_audit.sql > legacy-financial-audit.tsv
```

در محیط توسعهٔ فعلی، این SQL فقط روی snapshot دیتابیس تست با دسترسی read-only اجرا شده است؛ اجرای آن روی production یا دادهٔ واقعی بدون snapshot/replica مجاز نیست.

## تفسیر findings

### P0: توقف cutover

- تراکنش `completed/settled` بدون `ledger_entries`.
- اختلاف debit و credit بیشتر از `0.00000001`.
- ledger entry بدون parent transaction.
- اختلاف amount/currency/status بین `transactions_archive` و `transactions`.

### P1: نیازمند مالک و reconciliation

- escrow منقضی با `released_at` و `refunded_at` خالی.
- escrow نوع vitrine بدون listing متناظر.
- hold ویترین با مبلغ مثبت که release نشده است.
- نبودن ستون‌های hold یا archive؛ این مورد schema drift است و باید قبل از حذف/تبدیل legacy تصمیم‌گیری شود.

## معیار پذیرش

Cutover فقط وقتی قابل تأیید است که:

1. تمام P0ها صفر یا با سند reconciliation و تأیید مالک مالی بسته شده باشند.
2. مجموع بدهی escrow باز با گزارش business owner تطبیق داشته باشد.
3. اختلاف archive با canonical برای رکوردهای مالی مورد انتظار صفر باشد.
4. snapshot خروجی audit، migration version و تصمیم rollback ثبت شده باشند.
5. پس از cutover، همین audit دوباره اجرا و با baseline قبل مقایسه شود.

## اقدام بعد از finding

برای هر finding این موارد ثبت شود:

- کلید رکورد و دامنهٔ زمانی
- مقدار legacy و canonical
- علت اختلاف
- تصمیم: reconcile، preserve، quarantine یا reject
- owner، ticket و evidence
- query اصلاحی جداگانه و approval آن
