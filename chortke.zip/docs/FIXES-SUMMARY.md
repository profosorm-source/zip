# چرتکه — خلاصهٔ فیکس‌ها و فایل‌های تغییرکرده | Chortke — FIXES SUMMARY

**پروژه | Project:** چرتکه (پلتفرم کسب درآمد آنلاین PHP) — `/chortke`
**بازهٔ کاری | Scope:** راندهای ۲ تا ۱۶ (بازبینی کامل کد + فیکس) | Rounds 2–16 (full code review + fixes)
**کامیت اصلی آپلود | Original upload commit:** `e5c3c35` (Initial commit — فقط ۳ فایل صوری: `.env`, `.gitignore`, `download/README.md`)
**آخرین وضعیت | HEAD at packaging:** `afdf471` + ۲۸ فایل modified uncommitted + ۲ مایگریشن untracked (`2026_09_20_0004_users_country_flag`، `2026_09_20_0005_audit_trail_context_category`) که همه در بسته لحاظ شده‌اند
**تاریخ بسته‌بندی | Packaged:** 2026-09-20 — Task ID 16-D (به‌روزرسانیِ بستهٔ 15-E)

---

## آمار کلی | Overall numbers

| متریک | مقدار |
|---|---|
| کل فایل‌های تغییرکرده نسبت به کامیت اصلی (git diff e5c3c35..HEAD) | **۵٬۲۷۶ فایل** |
| خطوط افزوده‌شده / حذف‌شده (git diff --shortstat) | **+۹۳۴٬۴۹۴ / −۲** |
| فایل‌های پلتفرم (`chortke/**`) در بستهٔ «فایل‌های فیکس‌شده» (zip A) | **۲٬۵۲۵ فایل** |
| فایل‌های uncommitted هنگام بسته‌بندی (modified) | ۶۶ — همه از قبل در فهرست diff بودند، لحاظ شدند |
| فایل‌های untracked | ۷ فایل `tool-results/*` (آرتِفکت ابزار ایجنت، عمداً خارج از بسته) |

**توضیح مهم:** کامیت اولیه فقط ۳ فایل صوری داشت؛ بنابراین diff کامل عملاً «کل پروژهٔ ساخته/اصلاح‌شده در سندباکس» را نشان می‌دهد. در zip A فقط فایل‌های پلتفرم (`chortke/**`) آمده و سه گروه آشغالِ غیرپلتفرمی حذف شده‌اند: `chortke_extracted/` (۲٬۴۹۱ فایل — کپی تودرتوی ناشی از استخراج zip آپلود)، `tool-results/` (۱۴۰ فایل — لاگ ابزارها)، `src/` و فایل‌های اسکفولد Next.js ریشهٔ ورک‌اسپیس (۵۷+ فایل).

> جزئیات کامل هر راند: `/home/z/my-project/worklog.md` — فهرست یافته‌ها: `/home/z/my-project/REVIEW_FINDINGS.md`

---

## نکات برجستهٔ هر راند | Round highlights (2–15)

- **راند ۲:** تکمیل بازبینی ۱۰گانهٔ ایجنتی سرویس‌ها/ویوها + تست E2E مرورگری + فیکس‌های bring-up.
- **راند ۳:** رفع Criticalهای C-1/C-2/C-3 و ۵ فیکس High.
- **راند ۴:** بازبینی ۶گانهٔ ایجنتی سرویس‌ها (تسک/زیرساخت/مالی/هویت/ارتباطات/مشاهده‌پذیری).
- **راند ۵:** بازبینی کامل ویوهای ادمین (A–Z) با ۳ ایجنت.
- **راند ۶:** فیکس ۱۴ High باقیمانده (H-1..H-24: مالی، احراز هویت، زیرساخت، ارتباطات، ادمین) با ۵ ایجنت موازی + فیکس بحرانی استایل کل سایت + صفحهٔ جدید `/status`.
- **راند ۷:** فیکس ۱۵ یافتهٔ Medium ناسازگاری SQL/Schema (سرویس‌ها + ۲ ویو + ۳ مایگریشن جدید).
- **راند ۸:** فیکس ۹۱ Medium با ۶ ایجنت موازی (شامل بازسازی سیستمی RateLimiter/Cache و کشف کرش SIGSEGV ورکر) + امکان جدید `/status/api` + استایل سایت‌واید.
- **راند ۹:** کشف و رفع شکاف معماری کرون/صف + ۳ باگ کنترلری/کرون + PWA + پولیش استایل.
- **راند ۱۰:** رفع ۴ باگ زنده (شامل OOM زیرساختی) + استایل الزامی + امکانات جدید الزامی.
- **راند ۱۱:** E2E کامل ثبت‌نام/تأیید ایمیل/ورود + فیکس لینک‌های مردهٔ ادمین + Dev Mailbox و مودال میان‌برها.
- **راند ۱۲:** E2E بازیابی رمز + اسکن COEP iframeها + فیکس Lowهای کاربرمواجه + هشدار انقضای نشست.
- **راند ۱۳:** L-UI12 یکتایی username + E2E جریان دعوت/رفرال + تولتیپ CSS-محض + ۱۰ فیکس Low ویوها + بستن ۱۰ Low کاربرمواجه.
- **راند ۱۴:** ۱۴/۱۴ فیکس ادمین (H-29/H-31/H-34، صفحه‌بندی‌ها، Low-28×…) + ۱۵/۱۵ فیکس سرویس (H-19/H-20/H-21، M#1/M#5، Low-6..14) + راستی‌آزمایی Criticalها + بستن ۶ یافتهٔ رفرال.
- **راند ۱۵:** 15-B: ۱۴/۱۴ آیتم UI/روت/JS ادمین؛ 15-C: ۱۵/۱۵ آیتم سرویس (de-dup اسکیلیشن، فیلتر category حسابرسی، geo-velocity، حذف trap مالی مرده، صفحهٔ لاگ ادمین، ۸ Low)؛ 15-D: ۶/۶ آیتم (ایمیل خوش‌آمد، CSS رفرال ۴۴→۲ اینلاین، cache-bust نسخهٔ asset، کلامپ تولتیپ، چرخش لاگ phpunit، دیاگ کوئری کند)؛ **15-E (این سند):** فیکس فانتومِ «کوئری‌های کند=۱» در `getSlowQueries()` (fallback وقتی performance_schema خاموش است حالا `[]` برمی‌گرداند — تأیید /status/api: ۰) + ساخت بسته‌های تحویل.

---

## فهرست کامل فایل‌های تغییرکردهٔ پلتفرم، گروه‌بندی‌شده | Full changed-files list (platform), grouped by top-level dir

| دایرکتوری | تعداد فایل |
|---|---|
| `chortke/app` | 818 |
| `chortke/tests` | 482 |
| `chortke/public` | 406 |
| `chortke/views` | 306 |
| `chortke/database` | 190 |
| `chortke/tools` | 72 |
| `chortke/docs` | 60 |
| `chortke/` (ریشه) | 49 |
| `chortke/core` | 46 |
| `chortke/deploy` | 20 |
| `chortke/config` | 20 |
| `chortke/helpers` | 18 |
| `chortke/browser-test` | 15 |
| `chortke/routes` | 10 |
| `chortke/scripts` | 4 |
| `chortke/docker` | 4 |
| `chortke/bootstrap` | 3 |
| `chortke/storage` | 2 |
| **جمع | ۲٬۵۲۵** |

فهرست کامل فایل‌به‌فایل در همین بسته (zip A) موجود است و در ادامهٔ همین فایل نیز آمده است.

---

### chortke/app

```
app/Adapters/AdSocialAdapter.php
app/Adapters/AdTubeAdapter.php
app/Adapters/AdVideoRewardManager.php
app/Adapters/AdapterBase.php
app/Adapters/BankInquiryAdapter.php
app/Adapters/BankInquiryManager.php
app/Adapters/BannerAdapter.php
app/Adapters/CryptoApiAdapter.php
app/Adapters/CryptoExplorerAdapter.php
app/Adapters/CryptoVerificationAdapter.php
app/Adapters/CustomTaskAdapter.php
app/Adapters/DeepFaceKycAdapter.php
app/Adapters/JibitInquiryAdapter.php
app/Adapters/KycFaceVerificationAdapter.php
app/Adapters/Notification/FcmNotificationAdapter.php
app/Adapters/Notification/LogNotificationAdapter.php
app/Adapters/Notification/PushNotificationAdapter.php
app/Adapters/Notification/SmsNotificationAdapter.php
app/Adapters/NotificationAdAdapter.php
app/Adapters/SeoAdAdapter.php
app/Adapters/VandarInquiryAdapter.php
app/Commands/AlertRulesBootstrapCommand.php
app/Commands/AnalyticsCacheWarmupCommand.php
app/Commands/BackfillSearchProjectionCommand.php
app/Commands/DLQRetryCommand.php
app/Commands/DatabaseAnalyzerCommand.php
app/Commands/DistributedHealthCommand.php
app/Commands/DlqWorkCommand.php
app/Commands/EscrowCleanupCommand.php
app/Commands/FeatureFlagCommand.php
app/Commands/IdempotencyCommand.php
app/Commands/MigrationManager.php
app/Commands/OutboxPublishCommand.php
app/Commands/ProcessScheduledTasksCommand.php
app/Commands/QueueFailedCommand.php
app/Commands/QueueWorkCommand.php
app/Commands/RateLimitAuditCommand.php
app/Commands/RouteAuditCommand.php
app/Commands/ScoresDecayCommand.php
app/Commands/ScoresRebuildCommand.php
app/Commands/SettingsMigrateSecretsCommand.php
app/Commands/SimulateTraceableEventCommand.php
app/Commands/StuckWithdrawalReviewCommand.php
app/Commands/SystemCleanupCommand.php
app/Commands/UpdateTorExitNodesCommand.php
app/Console/Kernel.php
app/Constants/CryptoConstants.php
app/Constants/MagicNumbers.php
app/Constants/SessionKeys.php
app/Contracts/AdSystemContract.php
app/Contracts/AdsRepositoryInterface.php
app/Contracts/AntiFraud/FraudCheckStrategyInterface.php
app/Contracts/AntiFraud/FraudGuardInterface.php
app/Contracts/CacheInterface.php
app/Contracts/CircuitBreakerInterface.php
app/Contracts/CommandInterface.php
app/Contracts/CurrencyServiceInterface.php
app/Contracts/DatabaseErrorReporter.php
app/Contracts/DomainEvent.php
app/Contracts/EmailServiceInterface.php
app/Contracts/ErrorContract.php
app/Contracts/FeatureFlagRepositoryInterface.php
app/Contracts/GamificationStrategyInterface.php
app/Contracts/JobInterface.php
app/Contracts/LoggerInterface.php
app/Contracts/MetricsCollectorInterface.php
app/Contracts/NotificationChannelInterface.php
app/Contracts/NotificationServiceInterface.php
app/Contracts/OutboxServiceInterface.php
app/Contracts/PaymentGatewayInterface.php
app/Contracts/RateLimiterInterface.php
app/Contracts/SearchProviderInterface.php
app/Contracts/SearchServiceInterface.php
app/Contracts/Sentry/SentryAlertRepositoryInterface.php
app/Contracts/Sentry/SentryAuditRepositoryInterface.php
app/Contracts/Sentry/SentryErrorRepositoryInterface.php
app/Contracts/Sentry/SentryEscalationRepositoryInterface.php
app/Contracts/Sentry/SentryLogRepositoryInterface.php
app/Contracts/Sentry/SentryPerformanceRepositoryInterface.php
app/Contracts/Sentry/SentryQueueRepositoryInterface.php
app/Contracts/UploadServiceInterface.php
app/Contracts/ValidatorFactoryInterface.php
app/Contracts/WalletServiceInterface.php
app/Controllers/Admin/AccountDeletionManagementController.php
app/Controllers/Admin/AdTaskController.php
app/Controllers/Admin/AdminAdsController.php
app/Controllers/Admin/AdminAnalyticsController.php
app/Controllers/Admin/AdminExportController.php
app/Controllers/Admin/ApiTokenAdminController.php
app/Controllers/Admin/AuditTrailController.php
app/Controllers/Admin/AuthController.php
app/Controllers/Admin/BackupManagementController.php
app/Controllers/Admin/BankCardController.php
app/Controllers/Admin/BannerController.php
app/Controllers/Admin/BaseAdminController.php
app/Controllers/Admin/BugReportController.php
app/Controllers/Admin/CacheAdminController.php
app/Controllers/Admin/ContentController.php
app/Controllers/Admin/CouponController.php
app/Controllers/Admin/CronController.php
app/Controllers/Admin/CryptoDepositController.php
app/Controllers/Admin/DashboardController.php
app/Controllers/Admin/DatabaseHealthController.php
app/Controllers/Admin/EmailQueueController.php
app/Controllers/Admin/ExecutorTaskController.php
app/Controllers/Admin/FeatureFlagController.php
app/Controllers/Admin/FraudController.php
app/Controllers/Admin/FraudDashboardController.php
app/Controllers/Admin/FraudManagementController.php
app/Controllers/Admin/FraudReportsAdminController.php
app/Controllers/Admin/InfluencerController.php
app/Controllers/Admin/InvestmentController.php
app/Controllers/Admin/KYCController.php
app/Controllers/Admin/KpiController.php
app/Controllers/Admin/LevelController.php
app/Controllers/Admin/LogController.php
app/Controllers/Admin/LotteryController.php
app/Controllers/Admin/MaintenanceController.php
app/Controllers/Admin/ManualDepositController.php
app/Controllers/Admin/MessageModerationController.php
app/Controllers/Admin/NotificationController.php
app/Controllers/Admin/OnlinePaymentController.php
app/Controllers/Admin/PredictionController.php
app/Controllers/Admin/ReferralController.php
app/Controllers/Admin/RiskPolicyController.php
app/Controllers/Admin/RoleController.php
app/Controllers/Admin/ScoreManagementController.php
app/Controllers/Admin/SentryAdminController.php
app/Controllers/Admin/SeoAdController.php
app/Controllers/Admin/SocialAccountController.php
app/Controllers/Admin/SocialTaskController.php
app/Controllers/Admin/SystemController.php
app/Controllers/Admin/SystemSettingController.php
app/Controllers/Admin/TicketController.php
app/Controllers/Admin/TransactionController.php
app/Controllers/Admin/UserController.php
app/Controllers/Admin/VitrineController.php
app/Controllers/Admin/WithdrawalController.php
app/Controllers/Api/AppConfigController.php
app/Controllers/Api/BaseApiController.php
app/Controllers/Api/FingerprintController.php
app/Controllers/Api/HealthCheckController.php
app/Controllers/Api/InfluencerController.php
app/Controllers/Api/InteractionApiController.php
app/Controllers/Api/RealTimeController.php
app/Controllers/Api/SecurityController.php
app/Controllers/Api/SocialTaskApiController.php
app/Controllers/Api/TokenController.php
app/Controllers/Api/UserController.php
app/Controllers/Api/VerificationController.php
app/Controllers/Api/WalletController.php
app/Controllers/BannerController.php
app/Controllers/BaseController.php
app/Controllers/CaptchaController.php
app/Controllers/ContactController.php
app/Controllers/DebugController.php
app/Controllers/FaviconController.php
app/Controllers/FileController.php
app/Controllers/HomeController.php
app/Controllers/MetricsController.php
app/Controllers/OAuthController.php
app/Controllers/PageController.php
app/Controllers/PaymentController.php
app/Controllers/RobotsController.php
app/Controllers/SearchController.php
app/Controllers/SitemapController.php
app/Controllers/StatusController.php
app/Controllers/TestCaptchaController.php
app/Controllers/User/AdsApiController.php
app/Controllers/User/AdsController.php
app/Controllers/User/AdtubeController.php
app/Controllers/User/ApiTokenController.php
app/Controllers/User/AuthController.php
app/Controllers/User/BankCardController.php
app/Controllers/User/BaseUserController.php
app/Controllers/User/BugReportController.php
app/Controllers/User/ContentController.php
app/Controllers/User/CouponController.php
app/Controllers/User/CryptoDepositController.php
app/Controllers/User/CustomTaskController.php
app/Controllers/User/DashboardController.php
app/Controllers/User/DisputeController.php
app/Controllers/User/EscrowController.php
app/Controllers/User/FraudReportController.php
app/Controllers/User/InfluencerController.php
app/Controllers/User/InvestmentController.php
app/Controllers/User/KYCController.php
app/Controllers/User/LevelController.php
app/Controllers/User/LotteryController.php
app/Controllers/User/ManualDepositController.php
app/Controllers/User/MessageController.php
app/Controllers/User/NotificationController.php
app/Controllers/User/PredictionController.php
app/Controllers/User/ProfileController.php
app/Controllers/User/ReferralController.php
app/Controllers/User/SeoController.php
app/Controllers/User/SessionController.php
app/Controllers/User/SettingsController.php
app/Controllers/User/SocialAccountController.php
app/Controllers/User/SocialTaskController.php
app/Controllers/User/TaskFeedController.php
app/Controllers/User/TicketController.php
app/Controllers/User/TransferController.php
app/Controllers/User/TwoFactorController.php
app/Controllers/User/VitrineController.php
app/Controllers/User/WalletController.php
app/Controllers/User/WithdrawalController.php
app/Data/CommonPasswords.php
app/Domain/Financial/Services/FinancialEscrowService.php
app/Domain/Financial/Services/LedgerService.php
app/Domain/Gamification/Strategies/DailySynergyStrategy.php
app/Domain/Gamification/Strategies/InactivityDecayStrategy.php
app/Domain/Gamification/Strategies/TrustEvaluationStrategy.php
app/Enums/InteractionType.php
app/Enums/MetricType.php
app/Enums/ModuleContext.php
app/Enums/ScoreDomain.php
app/Enums/TicketPriority.php
app/Enums/TicketStatus.php
app/Enums/TransactionStatus.php
app/Enums/UserStatus.php
app/Events/AccountDeletedEvent.php
app/Events/AlertRequestedEvent.php
app/Events/AuditRecordedEvent.php
app/Events/CriticalFeatureChangedEvent.php
app/Events/DisputeOpenedEvent.php
app/Events/EscrowReleasedEvent.php
app/Events/FeatureFlagChanged.php
app/Events/FraudScoreUpdatedEvent.php
app/Events/InvestmentCreatedEvent.php
app/Events/KYCApprovedEvent.php
app/Events/LevelUpgradedEvent.php
app/Events/NotificationChannelRequestedEvent.php
app/Events/NotificationRequestedEvent.php
app/Events/PaymentCompletedEvent.php
app/Events/RateLimitExceededEvent.php
app/Events/Registry/EventRegistry.php
app/Events/ScoreDeltaAppendedEvent.php
app/Events/ScoreUpdatedEvent.php
app/Events/SettingsUpdated.php
app/Events/TaskCompletedEvent.php
app/Events/UserLoggedInEvent.php
app/Events/UserRegisteredEvent.php
app/Events/WalletTransferInitiatingEvent.php
app/Events/WithdrawalApprovedEvent.php
app/Events/WithdrawalCreatedEvent.php
app/Events/WithdrawalEvent.php
app/Exceptions/BusinessException.php
app/Exceptions/PaymentGatewayConnectionException.php
app/Exceptions/PaymentGatewayException.php
app/Exceptions/PaymentVerificationException.php
app/Exceptions/SessionException.php
app/Install/InstallerController.php
app/Jobs/AggregateAnalyticsJob.php
app/Jobs/AntiFraud/CheckTaskFraudJob.php
app/Jobs/ApplyWeeklyProfitLossJob.php
app/Jobs/Auth/HandleFacebookCallbackJob.php
app/Jobs/Auth/HandleGoogleCallbackJob.php
app/Jobs/Auth/LinkSocialAccountJob.php
app/Jobs/Auth/LinkSocialAccountSafeJob.php
app/Jobs/Auth/OAuthHelperTrait.php
app/Jobs/Auth/ProcessRegistrationJob.php
app/Jobs/Auth/ResetPasswordJob.php
app/Jobs/Auth/UnlinkSocialAccountJob.php
app/Jobs/Auth/Verify2FAJob.php
app/Jobs/BackfillSearchProjectionJob.php
app/Jobs/CacheWarmupJob.php
app/Jobs/CustomTask/CreateCustomTaskJob.php
app/Jobs/CustomTask/CronSubmissionsJob.php
app/Jobs/CustomTask/PayRewardJob.php
app/Jobs/CustomTask/RateSubmissionJob.php
app/Jobs/CustomTask/SubmitProofJob.php
app/Jobs/EscrowTimeoutJob.php
app/Jobs/InfluencerOrderTimeoutJob.php
app/Jobs/Investment/ApplyProfitLossToBatchJob.php
app/Jobs/Investment/ApplyWeeklyProfitLossJob.php
app/Jobs/Investment/CloseTradeJob.php
app/Jobs/Investment/CreateTradeJob.php
app/Jobs/Investment/RejectWithdrawalJob.php
app/Jobs/Investment/RequestWithdrawalJob.php
app/Jobs/InvestmentProfitDistributionJob.php
app/Jobs/KycTimeoutJob.php
app/Jobs/LogPerformanceJob.php
app/Jobs/Lottery/ParticipateInLotteryJob.php
app/Jobs/Lottery/UpdateLotteryChanceScoresJob.php
app/Jobs/Lottery/VoteInLotteryJob.php
app/Jobs/Notification/ArchiveNotificationJob.php
app/Jobs/Notification/CountUserNotificationsNotificationJob.php
app/Jobs/Notification/DeleteTemplateOverrideNotificationJob.php
app/Jobs/Notification/DepositSuccessNotificationJob.php
app/Jobs/Notification/DispatchNotificationJob.php
app/Jobs/Notification/FindForUserNotificationJob.php
app/Jobs/Notification/GetAllTemplatesWithVariablesNotificationJob.php
app/Jobs/Notification/GetAvailableSegmentsNotificationJob.php
app/Jobs/Notification/GetNewNotificationsNotificationJob.php
app/Jobs/Notification/GetTemplateNotificationJob.php
app/Jobs/Notification/GetUnreadCountNotificationJob.php
app/Jobs/Notification/GetUserNotificationsNotificationJob.php
app/Jobs/Notification/GetUsersBySegmentNotificationJob.php
app/Jobs/Notification/InvalidateUnreadCacheNotificationJob.php
app/Jobs/Notification/InvestmentCompletedNotificationJob.php
app/Jobs/Notification/KycRejectedNotificationJob.php
app/Jobs/Notification/KycVerifiedNotificationJob.php
app/Jobs/Notification/LatestNotificationJob.php
app/Jobs/Notification/LotteryWinnerNotificationJob.php
app/Jobs/Notification/MarkAllAsReadCountNotificationJob.php
app/Jobs/Notification/MarkAllAsReadNotificationJob.php
app/Jobs/Notification/MarkAsReadNotificationJob.php
app/Jobs/Notification/NewTaskAvailableNotificationJob.php
app/Jobs/Notification/PrefetchPreferencesNotificationJob.php
app/Jobs/Notification/ProcessSinglePersistNotificationJob.php
app/Jobs/Notification/RecordClickNotificationJob.php
app/Jobs/Notification/ReferralEarningNotificationJob.php
app/Jobs/Notification/RenderTemplateNotificationJob.php
app/Jobs/Notification/SaveTemplateOverrideNotificationJob.php
app/Jobs/Notification/SecurityAlertNotificationJob.php
app/Jobs/Notification/SendBulkNotificationJob.php
app/Jobs/Notification/SendFromTemplateNotificationJob.php
app/Jobs/Notification/SendNotificationJob.php
app/Jobs/Notification/SendToAdminsNotificationJob.php
app/Jobs/Notification/SendToAllNotificationJob.php
app/Jobs/Notification/SendToSegmentNotificationJob.php
app/Jobs/Notification/SoftDeleteNotificationJob.php
app/Jobs/Notification/WithdrawalApprovedNotificationJob.php
app/Jobs/Notification/WithdrawalRejectedNotificationJob.php
app/Jobs/NotificationCleanupJob.php
app/Jobs/Payment/ApproveCryptoDepositJob.php
app/Jobs/Payment/CreateCryptoDepositIntentJob.php
app/Jobs/Payment/ProcessPaymentCallbackJob.php
app/Jobs/Payment/ReconcilePaymentsJob.php
app/Jobs/Payment/RejectCryptoDepositJob.php
app/Jobs/PersistBulkInAppNotificationJob.php
app/Jobs/Prediction/CancelGameJob.php
app/Jobs/Prediction/PlaceBetJob.php
app/Jobs/Prediction/SettleGameJob.php
app/Jobs/PredictionGameSettlementJob.php
app/Jobs/ProcessNotificationJob.php
app/Jobs/RunCronTaskJob.php
app/Jobs/ScoreRecalculationJob.php
app/Jobs/SendEmailJob.php
app/Jobs/Seo/CancelSeoTaskJob.php
app/Jobs/Seo/CompleteSeoTaskJob.php
app/Jobs/Seo/ProcessSeoTaskAsyncJob.php
app/Jobs/Seo/RateSeoTaskJob.php
app/Jobs/Seo/ReportSeoTaskJob.php
app/Jobs/Seo/StartSeoTaskJob.php
app/Jobs/SocialTask/ApproveSocialTaskExecutionJob.php
app/Jobs/SocialTask/CalculateSilentRiskScoreJob.php
app/Jobs/SocialTask/DecideSilentAntiFraudJob.php
app/Jobs/SocialTask/RejectSocialTaskExecutionJob.php
app/Jobs/SocialTask/StartSocialTaskExecutionJob.php
app/Jobs/SocialTask/SubmitSocialTaskExecutionJob.php
app/Jobs/SocialTaskApprovalReminderJob.php
app/Jobs/UpdateFraudScoreJob.php
app/Jobs/VerifyCryptoDepositJob.php
app/Jobs/Vitrine/AcceptVitrineRequestJob.php
app/Jobs/Vitrine/AdminApproveVitrineListingJob.php
app/Jobs/Vitrine/AdminRefundVitrineListingJob.php
app/Jobs/Vitrine/AdminRejectVitrineListingJob.php
app/Jobs/Vitrine/ConfirmVitrineDeliveryJob.php
app/Jobs/Vitrine/CreateVitrineListingJob.php
app/Jobs/Vitrine/ProcessExpiredVitrineEscrowsJob.php
app/Jobs/Vitrine/RateVitrineListingJob.php
app/Jobs/Vitrine/ReleaseVitrineFundsJob.php
app/Jobs/Vitrine/ReportVitrineListingJob.php
app/Jobs/Vitrine/ResolveVitrineDisputeJob.php
app/Jobs/Vitrine/SendVitrineRequestJob.php
app/Jobs/VitrineListingExpiryJob.php
app/Jobs/WithdrawalTimeoutJob.php
app/Listeners/AlertAdminOnCriticalFeatureChange.php
app/Listeners/AlertAdminOnCriticalTrustDrop.php
app/Listeners/AlertRequestListener.php
app/Listeners/AuditCircuitBreakerState.php
app/Listeners/CacheInvalidateListener.php
app/Listeners/ClearSettingsCache.php
app/Listeners/ContentEventListeners.php
app/Listeners/CreateUserWalletListener.php
app/Listeners/DisputeListener.php
app/Listeners/EscrowListener.php
app/Listeners/FraudGuardListener.php
app/Listeners/HandleAccountDeleted.php
app/Listeners/HandleLevelUpgraded.php
app/Listeners/HandlePaymentCompleted.php
app/Listeners/HandleRateLimitExceeded.php
app/Listeners/InfluencerEventListeners.php
app/Listeners/InvalidateSearchCacheListener.php
app/Listeners/InvestmentEventListeners.php
app/Listeners/KYCListener.php
app/Listeners/LogFeatureFlagChange.php
app/Listeners/LogUserLoggedInActivity.php
app/Listeners/LogUserRegisteredActivity.php
app/Listeners/NotificationChannelDispatchListener.php
app/Listeners/NotificationRequestListener.php
app/Listeners/PersistAuditRecordListener.php
app/Listeners/ProcessFraudAlert.php
app/Listeners/ReferralCommissionListener.php
app/Listeners/ScoreProjectionListener.php
app/Listeners/ScoreUpdateListener.php
app/Listeners/SendNotificationListener.php
app/Listeners/SocialTaskEventListeners.php
app/Listeners/TaskCompletedListener.php
app/Listeners/VitrineNotificationListener.php
app/Listeners/WalletDepositRequestListener.php
app/Listeners/WithdrawalListener.php
app/Middleware/AdminMiddleware.php
app/Middleware/AdminPermissionGuard.php
app/Middleware/AdvancedFraudMiddleware.php
app/Middleware/ApiAuthMiddleware.php
app/Middleware/ApiRequestMiddleware.php
app/Middleware/AuthMiddleware.php
app/Middleware/BaseMiddleware.php
app/Middleware/CSRFMiddleware.php
app/Middleware/CaptchaMiddleware.php
app/Middleware/ConcurrentRequestMiddleware.php
app/Middleware/CorsMiddleware.php
app/Middleware/GlobalExceptionMiddleware.php
app/Middleware/GuestMiddleware.php
app/Middleware/HttpsMiddleware.php
app/Middleware/LoggingMiddleware.php
app/Middleware/MaintenanceMiddleware.php
app/Middleware/PermissionMiddleware.php
app/Middleware/RateLimitMiddleware.php
app/Middleware/RequireFeature.php
app/Middleware/SafeModeMiddleware.php
app/Middleware/SecurityHeadersMiddleware.php
app/Middleware/SessionMiddleware.php
app/Middleware/TracingMiddleware.php
app/Models/AccountDeletionLog.php
app/Models/ActivityLog.php
app/Models/AdTubeExecutionModel.php
app/Models/Ads.php
app/Models/AdvancedAnalytics.php
app/Models/ApiToken.php
app/Models/AuditTrail.php
app/Models/BackupLog.php
app/Models/BankCard.php
app/Models/BannerPlacement.php
app/Models/BulkOperation.php
app/Models/CaptchaLog.php
app/Models/ContactMessage.php
app/Models/ContentAgreement.php
app/Models/ContentRevenue.php
app/Models/ContentSubmission.php
app/Models/Coupon.php
app/Models/CouponRedemption.php
app/Models/CryptoDeposit.php
app/Models/CryptoDepositIntent.php
app/Models/CustomTaskAnalyticsModel.php
app/Models/CustomTaskSubmissionModel.php
app/Models/DataExport.php
app/Models/DirectMessage.php
app/Models/Dispute.php
app/Models/EmailQueue.php
app/Models/Escrow.php
app/Models/ExportData.php
app/Models/FailedJob.php
app/Models/FeatureFlag.php
app/Models/FileAccess.php
app/Models/FraudAnalyticsModel.php
app/Models/FraudReport.php
app/Models/InfluencerModel.php
app/Models/InfluencerVerification.php
app/Models/InteractionModel.php
app/Models/Investment.php
app/Models/InvestmentProfit.php
app/Models/InvestmentWithdrawal.php
app/Models/IpAndDeviceModel.php
app/Models/KYCVerification.php
app/Models/KpiStatistics.php
app/Models/LedgerEntry.php
app/Models/LotteryChanceLog.php
app/Models/LotteryDailyNumber.php
app/Models/LotteryParticipation.php
app/Models/LotteryRound.php
app/Models/LotteryVote.php
app/Models/ManualDeposit.php
app/Models/MessageModerationModel.php
app/Models/Notification.php
app/Models/NotificationPreference.php
app/Models/Page.php
app/Models/PaymentGateway.php
app/Models/PaymentLog.php
app/Models/PerformanceLog.php
app/Models/Permission.php
app/Models/PredictionBet.php
app/Models/PredictionGame.php
app/Models/Rating.php
app/Models/ReferralActivityLog.php
app/Models/ReferralCommission.php
app/Models/RiskPolicy.php
app/Models/Role.php
app/Models/S2sHookEvent.php
app/Models/SagaExecution.php
app/Models/ScheduledPayment.php
app/Models/Score.php
app/Models/SearchProjection.php
app/Models/SecurityLog.php
app/Models/SecurityModel.php
app/Models/SentryModel.php
app/Models/SeoExecution.php
app/Models/Setting.php
app/Models/SocialAccount.php
app/Models/SocialTaskAnalyticsModel.php
app/Models/SocialTaskExecutionModel.php
app/Models/SocialTaskModel.php
app/Models/StoryOrder.php
app/Models/SystemLog.php
app/Models/SystemTelemetryModel.php
app/Models/Ticket.php
app/Models/TicketCategory.php
app/Models/TicketMessage.php
app/Models/TradingRecord.php
app/Models/Transaction.php
app/Models/TransactionQuery.php
app/Models/User.php
app/Models/UserLevel.php
app/Models/UserLevelHistory.php
app/Models/UserSetting.php
app/Models/UserVacation.php
app/Models/UserVerification.php
app/Models/VelocityAndScoreModel.php
app/Models/VitrineListing.php
app/Models/VitrineRating.php
app/Models/VitrineRequest.php
app/Models/Wallet.php
app/Models/Withdrawal.php
app/Policies/FeatureFlagPolicy.php
app/Policies/RateLimitPolicy.php
app/Policies/RolePolicy.php
app/Providers/AppServiceProvider.php
app/Services/AdNotificationDispatcher.php
app/Services/AdSystemManager.php
app/Services/AdminDashboard/AdminDashboardService.php
app/Services/AdminDashboard/DashboardQueryService.php
app/Services/AdminDashboard/SystemMonitoringService.php
app/Services/Ads/AdsBudgetSettlementService.php
app/Services/Analytics/AnalyticsExporter.php
app/Services/Analytics/AnalyticsQueryService.php
app/Services/Analytics/AnalyticsService.php
app/Services/AntiFraud/AccountTakeoverService.php
app/Services/AntiFraud/BehavioralBiometricsService.php
app/Services/AntiFraud/BrowserFingerprintService.php
app/Services/AntiFraud/DeviceIntelligenceService.php
app/Services/AntiFraud/EmailPhoneIntelligenceService.php
app/Services/AntiFraud/FraudDashboardService.php
app/Services/AntiFraud/FraudDetectionService.php
app/Services/AntiFraud/FraudGuardService.php
app/Services/AntiFraud/FraudManagementService.php
app/Services/AntiFraud/FraudStrategyResolver.php
app/Services/AntiFraud/GeoIPService.php
app/Services/AntiFraud/GeolocationIntelligenceService.php
app/Services/AntiFraud/GraphAnalysisService.php
app/Services/AntiFraud/IPQualityService.php
app/Services/AntiFraud/MLFraudDetectionService.php
app/Services/AntiFraud/RateLimitingService.php
app/Services/AntiFraud/RiskDecisionService.php
app/Services/AntiFraud/RiskPolicyService.php
app/Services/AntiFraud/SeoFraudDetector.php
app/Services/AntiFraud/SessionAnomalyService.php
app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php
app/Services/AntiFraud/Strategies/TaskFraudStrategy.php
app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php
app/Services/AntiFraud/TaskExecutionEvaluatorService.php
app/Services/AntiFraud/TorListUpdater.php
app/Services/AntiFraud/VelocityCheckService.php
app/Services/AntiFraud/VideoFingerprintService.php
app/Services/ApiTokenService.php
app/Services/AuditTrail.php
app/Services/Auth/AuthService.php
app/Services/Auth/AuthSessionManager.php
app/Services/Auth/GoogleJwtVerifier.php
app/Services/Auth/LoginRiskService.php
app/Services/Auth/OAuthService.php
app/Services/Auth/PasswordRecoveryService.php
app/Services/Auth/SessionService.php
app/Services/Auth/TwoFactorService.php
app/Services/BackupService.php
app/Services/BankCardService.php
app/Services/BannerService.php
app/Services/BulkOperationsService.php
app/Services/Cache/CacheInvalidationService.php
app/Services/Cache/CacheManager.php
app/Services/CacheAdminService.php
app/Services/CaptchaService.php
app/Services/ContactService.php
app/Services/ContentService.php
app/Services/Cron/CronService.php
app/Services/CryptoDeposit/CryptoDepositService.php
app/Services/CryptoDeposit/CryptoIntentSupportService.php
app/Services/CurrencyService.php
app/Services/CustomTask/AdminCustomTaskService.php
app/Services/CustomTask/CustomTaskExecutorService.php
app/Services/CustomTask/CustomTaskModerationService.php
app/Services/DataExportService.php
app/Services/DatabaseAnalyzerService.php
app/Services/DatabaseService.php
app/Services/DirectMessageCommandService.php
app/Services/DirectMessageQueryService.php
app/Services/DirectMessageService.php
app/Services/Dispute/DisputeCommandService.php
app/Services/Dispute/DisputeQueryService.php
app/Services/DistributedLockService.php
app/Services/DlqWorker.php
app/Services/EmailDeliveryStore.php
app/Services/EmailService.php
app/Services/EscrowService.php
app/Services/ExportService.php
app/Services/FeatureFlagService.php
app/Services/FileAccessService.php
app/Services/Gamification/TrustService.php
app/Services/Gamification/XpService.php
app/Services/Health/HealthCheckService.php
app/Services/Influencer/InfluencerCommandService.php
app/Services/Influencer/InfluencerQueryService.php
app/Services/InfluencerService.php
app/Services/Interaction/FavoriteService.php
app/Services/Interaction/RatingService.php
app/Services/Interaction/ReportService.php
app/Services/Investment/InvestmentCommandService.php
app/Services/Investment/InvestmentQueryService.php
app/Services/InvestmentService.php
app/Services/KYC/KYCCommandService.php
app/Services/KYC/KYCQueryService.php
app/Services/KYCService.php
app/Services/LogService.php
app/Services/Lottery/LotteryCommandService.php
app/Services/Lottery/LotteryParticipationService.php
app/Services/Lottery/LotteryQueryService.php
app/Services/Lottery/LotteryService.php
app/Services/MaintenanceService.php
app/Services/ManualDepositService.php
app/Services/MessageModerationService.php
app/Services/Metrics/MetricsCollector.php
app/Services/MigrationService.php
app/Services/Notification/Channels/FcmChannel.php
app/Services/Notification/Channels/LogChannel.php
app/Services/Notification/Channels/PushChannel.php
app/Services/Notification/Channels/SmsChannel.php
app/Services/Notification/FcmService.php
app/Services/Notification/LogNotificationService.php
app/Services/Notification/NotificationAnalyticsService.php
app/Services/Notification/NotificationDispatcher.php
app/Services/Notification/NotificationJobFactory.php
app/Services/Notification/NotificationOrchestrator.php
app/Services/Notification/NotificationPolicyService.php
app/Services/Notification/NotificationPreferenceService.php
app/Services/Notification/NotificationRetryPolicy.php
app/Services/Notification/NotificationService.php
app/Services/Notification/NotificationTemplateService.php
app/Services/Notification/NotificationTracker.php
app/Services/Notification/SmsNotificationService.php
app/Services/OffsiteBackupService.php
app/Services/OutboxPublisher.php
app/Services/OutboxService.php
app/Services/Payment/BasePaymentGateway.php
app/Services/Payment/DgPayGateway.php
app/Services/Payment/IDPayGateway.php
app/Services/Payment/MockPaymentGateway.php
app/Services/Payment/NextPayGateway.php
app/Services/Payment/PaymentAdminService.php
app/Services/Payment/PaymentCommandService.php
app/Services/Payment/PaymentDepositService.php
app/Services/Payment/PaymentGatewayFactory.php
app/Services/Payment/PaymentService.php
app/Services/Payment/ZarinPalGateway.php
app/Services/PerformanceOptimizationService.php
app/Services/PredictionService.php
app/Services/QueueWorker.php
app/Services/ReconciliationService.php
app/Services/ReferralManagementService.php
app/Services/SagaOrchestrator.php
app/Services/ScheduledPaymentService.php
app/Services/Score/MonthlyLeaderboard.php
app/Services/Score/ScoreCommandService.php
app/Services/Score/ScoreDomainPolicy.php
app/Services/Score/ScoreQueryService.php
app/Services/ScoreService.php
app/Services/Search/AbstractSearchGateway.php
app/Services/Search/AdminSearchGateway.php
app/Services/Search/AdminSearchProvider.php
app/Services/Search/BaseSearchProvider.php
app/Services/Search/ModuleSearchGateway.php
app/Services/Search/ModuleSearchProvider.php
app/Services/Search/SchemaInspector.php
app/Services/Search/SearchIndexer.php
app/Services/Search/SearchOrchestrator.php
app/Services/Search/SearchProjectionListener.php
app/Services/Search/SearchProjectionRepository.php
app/Services/Search/SearchQuery.php
app/Services/Search/SearchResult.php
app/Services/Search/UserSearchGateway.php
app/Services/Search/UserSearchProvider.php
app/Services/Sentry/Alerting/AlertDispatcher.php
app/Services/Sentry/Alerting/AlertRulesEngine.php
app/Services/Sentry/Alerting/EscalationManager.php
app/Services/Sentry/Analytics/DashboardService.php
app/Services/Sentry/Analytics/TrendAnalyzer.php
app/Services/Sentry/Audit/AdvancedAuditTrail.php
app/Services/Sentry/ErrorMonitoring/SentryErrorMonitor.php
app/Services/Sentry/PerformanceMonitoring/SentryPerformanceMonitor.php
app/Services/Sentry/SentryExceptionHandler.php
app/Services/Seo/AdsSeoService.php
app/Services/Seo/SeoService.php
app/Services/SeoPayoutService.php
app/Services/Settings/AppSettings.php
app/Services/Settings/SecretBox.php
app/Services/Settings/SettingsCatalog.php
app/Services/Settings/SettingsManager.php
app/Services/Shared/BatchLoader.php
app/Services/Shared/CouponService.php
app/Services/Shared/DashboardStatsService.php
app/Services/Shared/DisputeService.php
app/Services/Shared/IdempotencyKeys.php
app/Services/Shared/IdempotencyService.php
app/Services/Shared/PolicyService.php
app/Services/Shared/ReferralService.php
app/Services/SitemapService.php
app/Services/SocialAccountService.php
app/Services/SocialTask/BehaviorAnalysisService.php
app/Services/SocialTask/CameraVerificationService.php
app/Services/SocialTask/RatingService.php
app/Services/SocialTask/SilentAntiFraudService.php
app/Services/SocialTask/SocialTaskScoringService.php
app/Services/SocialTask/SocialTaskService.php
app/Services/StateMachineService.php
app/Services/TicketCommandService.php
app/Services/TicketQueryService.php
app/Services/TicketService.php
app/Services/UnifiedTaskService.php
app/Services/UploadService.php
app/Services/User/AccountDeletionService.php
app/Services/User/ProfileService.php
app/Services/User/UserDashboardService.php
app/Services/User/UserLevelCommandService.php
app/Services/User/UserLevelQueryService.php
app/Services/User/UserLevelService.php
app/Services/User/UserService.php
app/Services/User/UserSettingsService.php
app/Services/ValidatorFactory.php
app/Services/VerificationService.php
app/Services/VitrineService.php
app/Services/VitrineSettingsService.php
app/Services/Wallet/WalletMutationService.php
app/Services/Wallet/WalletQueryService.php
app/Services/Wallet/WalletService.php
app/Services/WebSocketService.php
app/Services/Withdrawal/WithdrawalAdminService.php
app/Services/Withdrawal/WithdrawalQueryService.php
app/Services/Withdrawal/WithdrawalUserService.php
app/Support/FallbackLogger.php
app/Traits/ClientInfoTrait.php
app/Traits/ExternalCallTrait.php
app/Traits/Filterable.php
app/Traits/UsesValidatorFactory.php
app/Traits/ValidatesExternalUrl.php
app/Utils/Sentry/BreadcrumbCollector.php
app/Utils/Sentry/ContextEnricher.php
app/Utils/Sentry/StackTraceAnalyzer.php
app/Validators/BaseFormRequest.php
app/Validators/CryptoIntentValidator.php
app/Validators/LoginRequest.php
app/Validators/PasswordPolicy.php
app/Validators/RegisterRequest.php
app/Validators/Requests/AdminActionReasonRequest.php
app/Validators/Requests/ApproveInfluencerProfileRequest.php
app/Validators/Requests/ApproveInfluencerVerificationRequest.php
app/Validators/Requests/ChangeUserLevelRequest.php
app/Validators/Requests/CloseTradeRequest.php
app/Validators/Requests/ContactMessageRequest.php
app/Validators/Requests/CreateBankCardRequest.php
app/Validators/Requests/CreateBannerRequest.php
app/Validators/Requests/CreateBugReportRequest.php
app/Validators/Requests/CreateCustomTaskRequest.php
app/Validators/Requests/CreateDepositRequest.php
app/Validators/Requests/CreateInfluencerOrderRequest.php
app/Validators/Requests/CreateInvestmentRequest.php
app/Validators/Requests/CreatePredictionGameRequest.php
app/Validators/Requests/CreateSocialTaskRequest.php
app/Validators/Requests/CreateTradeRequest.php
app/Validators/Requests/CreateTransferRequest.php
app/Validators/Requests/CreateVitrineListingRequest.php
app/Validators/Requests/CreateWithdrawalRequest.php
app/Validators/Requests/CurrencySelectionRequest.php
app/Validators/Requests/DeleteNotificationTemplateRequest.php
app/Validators/Requests/ExecuteSocialTaskRequest.php
app/Validators/Requests/ForceModerateSubmissionRequest.php
app/Validators/Requests/IssueTokenRequest.php
app/Validators/Requests/JoinLotteryRequest.php
app/Validators/Requests/LotteryRoundRequest.php
app/Validators/Requests/ModerateCustomTaskRequest.php
app/Validators/Requests/OAuthCallbackRequest.php
app/Validators/Requests/OAuthLinkAccountRequest.php
app/Validators/Requests/PlacePredictionBetRequest.php
app/Validators/Requests/PurchaseLevelRequest.php
app/Validators/Requests/RateInteractionRequest.php
app/Validators/Requests/RateSubmissionRequest.php
app/Validators/Requests/RejectInfluencerVerificationRequest.php
app/Validators/Requests/ReportInteractionRequest.php
app/Validators/Requests/RequestWithdrawalRequest.php
app/Validators/Requests/ResolveExecutorDisputeRequest.php
app/Validators/Requests/ResolveInfluencerDisputeRequest.php
app/Validators/Requests/ReviewTaskReportRequest.php
app/Validators/Requests/SaveNotificationTemplateRequest.php
app/Validators/Requests/SendDirectMessageRequest.php
app/Validators/Requests/SendMessageRequest.php
app/Validators/Requests/SendNotificationRequest.php
app/Validators/Requests/StoreContentRequest.php
app/Validators/Requests/StoreInfluencerProfileRequest.php
app/Validators/Requests/StoreSocialAccountRequest.php
app/Validators/Requests/SubmitCustomTaskProofRequest.php
app/Validators/Requests/ToggleFavoriteRequest.php
app/Validators/Requests/UpdateGeneralSettingsRequest.php
app/Validators/Requests/UpdateProfileRequest.php
app/Validators/Requests/UserUpdateRequest.php
app/Validators/Requests/ValidateCouponRequest.php
app/Validators/Requests/Verify2FARequest.php
app/Validators/Requests/VoteLotteryRequest.php
app/Validators/Requests/WithdrawInvestmentRequest.php
```
### chortke/bootstrap

```
bootstrap/app.php
bootstrap/phpunit-prepend.php
bootstrap/testing.php
```
### chortke/browser-test

```
browser-test/ads-ui-advertiser-preview.js
browser-test/content-phase1-preview.js
browser-test/content-phase1-submit-test.js
browser-test/content-phase4-admin-actions-http-test.js
browser-test/content-phase4-admin-preview.js
browser-test/content-phase5-user-show-preview.js
browser-test/influencer-phase1-sidebar-preview.js
browser-test/influencer-phase2-hub-actions.js
browser-test/influencer-phase2-hub-preview.js
browser-test/influencer-phase3-admin-actions.js
browser-test/influencer-phase3-admin-preview.js
browser-test/influencer-phase4-compat-redirects.js
browser-test/prediction-phase1-preview.js
browser-test/prediction-phase2-admin-preview.js
browser-test/prediction-phase2-user-hub-preview.js
```
### chortke/config

```
config/admin_permissions.php
config/auth.php
config/config.php
config/constants.php
config/feature_flags.php
config/health.php
config/lock.php
config/logging.php
config/maintenance.php
config/messages.php
config/oauth.php
config/outbox.php
config/payment.php
config/queue.php
config/rate_limits.php
config/redis.php
config/resilience.php
config/search.php
config/services.php
config/webhook.php
```
### chortke/core

```
core/Application.php
core/Attributes/Inject.php
core/Blueprint.php
core/CSRF.php
core/Cache.php
core/CircuitBreaker.php
core/Command.php
core/Console/CliDispatcher.php
core/Container.php
core/Database.php
core/Encryption.php
core/Event.php
core/EventDispatcher.php
core/ExceptionHandler.php
core/Exceptions.php
core/GenericEvent.php
core/IdempotencyKey.php
core/Lib/QRCode.php
core/Listener.php
core/Logger.php
core/Model.php
core/PathResolver.php
core/Pipeline.php
core/QueryBuilder.php
core/Queue.php
core/RateLimitStrategy.php
core/RateLimiter.php
core/Redis.php
core/RedisSessionHandler.php
core/Request.php
core/Response.php
core/RetryPolicy.php
core/Route.php
core/Router.php
core/Scheduler.php
core/Schema.php
core/Session.php
core/Sql/SafeExpression.php
core/Sql/SqlExpressionException.php
core/Strategies/FixedWindowStrategy.php
core/Strategies/SlidingWindowStrategy.php
core/Strategies/TokenBucketStrategy.php
core/TransactionWrapper.php
core/UrlGenerator.php
core/Validator.php
core/ValueObjects/Money.php
```
### chortke/database

```
database/migrations/2026_04_27_0001_database_recovery.sql
database/migrations/2026_04_28_0001_social_accounts_table.sql
database/migrations/2026_06_08_0001_create_system_settings.php
database/migrations/2026_06_10_0001_identity_real.sql
database/migrations/2026_06_10_0002_financial_real.sql
database/migrations/2026_06_10_0003_influencers_disputes.sql
database/migrations/2026_06_10_0004_tasks_real.sql
database/migrations/2026_06_10_0005_support_real.sql
database/migrations/2026_06_10_0006_referral_real.sql
database/migrations/2026_06_10_0007_support_messaging.sql
database/migrations/2026_06_10_0008_extended_financial.sql
database/migrations/2026_06_10_0009_settings_infra.sql
database/migrations/2026_06_10_0010_engagement_gaming.sql
database/migrations/2026_06_10_0011_investments_gaming.sql
database/migrations/2026_06_10_0012_content_logs.sql
database/migrations/2026_06_10_0013_marketing_content.sql
database/migrations/2026_06_10_0014_infrastructure.sql
database/migrations/2026_06_10_0015_notif_coupons_risk.sql
database/migrations/2026_06_10_0016_specialized_analytics.sql
database/migrations/2026_06_10_0017_escrow_bank_bulk.sql
database/migrations/2026_06_10_0018_final_system.sql
database/migrations/2026_06_10_0019_final_cleanup.sql
database/migrations/2026_06_10_0020_rbac_social_seo.sql
database/migrations/2026_06_10_0021_extended_rewards.sql
database/migrations/2026_06_10_0022_sentry_monitoring.sql
database/migrations/2026_06_10_0023_adv_settings_security.sql
database/migrations/2026_06_10_0024_payment_trading.sql
database/migrations/2026_06_10_0025_task_analytics.sql
database/migrations/2026_06_10_0026_ai_anti_fraud.sql
database/migrations/2026_06_10_0027_legal_marketing.sql
database/migrations/2026_06_10_0028_forensic_detailed_analytics.sql
database/migrations/2026_06_10_0029_final_infrastructure.sql
database/migrations/2026_06_10_0030_auth_security_hardened.sql
database/migrations/2026_06_10_0031_integrity_final.sql
database/migrations/2026_06_10_0032_advanced_analytics.sql
database/migrations/2026_06_10_0033_plans_and_docs.sql
database/migrations/2026_06_10_0034_final_invariants.sql
database/migrations/2026_06_10_0035_intelligence_graph.sql
database/migrations/2026_06_10_0036_analytics_search_ml.sql
database/migrations/2026_06_10_0037_ads_banners_extended.sql
database/migrations/2026_06_10_0038_audit_failures_system.sql
database/migrations/2026_06_10_0039_archive_forensics_final.sql
database/migrations/2026_06_10_0040_user_social_comm.sql
database/migrations/2026_06_10_0041_final_schema_hardening.sql
database/migrations/2026_06_10_0042_task_ticket_level_ext.sql
database/migrations/2026_06_10_0043_realtime_rate_limiting.sql
database/migrations/2026_06_10_0044_sync_missing.sql
database/migrations/2026_06_10_0045_blacklists_views.sql
database/migrations/2026_06_10_0046_final_missing_tables.sql
database/migrations/2026_06_10_0047_infrastructure_missing.sql
database/migrations/2026_06_10_0048_independent_tasks.sql
database/migrations/2026_06_10_0049_missing_business_tables.sql
database/migrations/2026_06_11_0001_fix_risk_policies_schema.sql
database/migrations/2026_06_12_0001_full_enterprise_schema_reconciliation.sql
database/migrations/2026_06_13_0001_finance_schema_reconciliation.sql
database/migrations/2026_06_14_0001_lottery_schema_reconciliation.sql
database/migrations/2026_06_14_0002_referral_schema_reconciliation.sql
database/migrations/2026_06_14_0003_referral_ui_admin_compat.sql
database/migrations/2026_06_14_0004_scheduled_payments_reconciliation.sql
database/migrations/2026_06_14_0005_influencer_marketplace_reconciliation.sql
database/migrations/2026_06_14_0006_dispute_influencer_compat.sql
database/migrations/2026_06_14_0007_social_task_reconciliation.sql
database/migrations/2026_06_14_0008_financial_deep_reconciliation.sql
database/migrations/2026_06_14_0009_users_auth_gaming_compat.sql
database/migrations/2026_06_14_0010_wave3_schema_compat.sql
database/migrations/2026_06_14_0011_wave3_state_schema_compat.sql
database/migrations/2026_06_14_0012_wave3_final_missing_columns.sql
database/migrations/2026_06_14_0013_wave4_kyc_investment_escrow_compat.sql
database/migrations/2026_06_14_0014_currency_normalize_to_irt.sql
database/migrations/2026_06_14_0015_users_kyc_level_columns.sql
database/migrations/2026_06_14_0016_users_level_lifecycle_columns.sql
database/migrations/2026_06_14_0017_audit_trail_observability_columns.sql
database/migrations/2026_06_15_0001_create_adtube_views.sql
database/migrations/2026_06_15_0002_seed_feature_flags.sql
database/migrations/2026_06_15_0003_feature_flags_add_created_at.sql
database/migrations/2026_06_15_0004_users_add_kyc_status_tier.sql
database/migrations/2026_06_15_0005_users_add_kyc_level_verified_at.sql
database/migrations/2026_06_15_0006_create_rate_limits_table.sql
database/migrations/2026_06_15_0007_ratings_add_moderation_columns.sql
database/migrations/2026_06_16_0001_fix_distributed_tables.sql
database/migrations/2026_06_16_0002_final_catch_all_tables.sql
database/migrations/2026_06_16_0003_add_all_foreign_keys.sql
database/migrations/2026_06_16_0004_complete_missing_schema.sql
database/migrations/2026_06_16_0005_seed_initial_data.php
database/migrations/2026_06_16_0006_seed_config_to_db.php
database/migrations/2026_06_16_0007_create_common_passwords_table.php
database/migrations/2026_06_18_0001_create_tasks_view.sql
database/migrations/2026_06_19_0001_notification_granular_preferences.sql
database/migrations/2026_06_19_0002_social_task_mobile_scoring.sql
database/migrations/2026_06_19_0003_custom_task_reconciliation.sql
database/migrations/2026_06_20_0001_custom_task_proof_schema_indexes.sql
database/migrations/2026_06_20_0002_custom_task_phase3_auto_dispute.sql
database/migrations/2026_06_20_0003_custom_task_split_video.sql
database/migrations/2026_06_20_0004_seo_task_reconciliation.sql
database/migrations/2026_06_20_0005_ads_phase4_finance_delivery.sql
database/migrations/2026_06_20_0006_ads_phase6_legacy_surface_cleanup.sql
database/migrations/2026_06_20_0007_content_phase1_schema_route_compat.sql
database/migrations/2026_06_21_0001_prediction_phase1_finance_rules.sql
database/migrations/2026_06_28_0001_add_refresh_token_to_api_tokens.sql
database/migrations/2026_07_16_0001_sentry_performance_transactions_compat.sql
database/migrations/2026_07_16_0002_ml_fraud_predictions_compat.sql
database/migrations/2026_07_16_0003_captcha_attempts_observability_compat.sql
database/migrations/2026_07_16_0004_tickets_workflow_compat.sql
database/migrations/2026_07_16_0005_ticket_messages_workflow_compat.sql
database/migrations/2026_07_16_0006_users_profile_fields_compat.sql
database/migrations/2026_07_16_0007_file_logs_access_compat.sql
database/migrations/2026_07_16_0008_phone_intelligence_compat.sql
database/migrations/2026_07_16_0009_bank_cards_hash_index_compat.sql
database/migrations/2026_07_16_0010_direct_messages_encryption_soft_delete_compat.sql
database/migrations/2026_07_16_0011_crypto_deposits_currency_default_compat.sql
database/migrations/2026_07_16_0012_user_flags_fraud_compat.sql
database/migrations/2026_07_16_0013_task_reports_compat.sql
database/migrations/2026_07_16_0014_user_settings_timestamps_compat.sql
database/migrations/2026_07_16_0015_users_account_deletion_timestamps_compat.sql
database/migrations/2026_07_16_0016_observability_admin_compat.sql
database/migrations/2026_07_16_0017_error_logs_status_code_compat.sql
database/migrations/2026_07_16_0018_finance_card_approve_permission_compat.sql
database/migrations/2026_07_16_0019_tickets_status_workflow_compat.sql
database/migrations/2026_07_23_0023_tickets_assignment_compat.sql
database/migrations/2026_07_23_0024_notifications_soft_delete_compat.sql
database/migrations/2026_07_23_0025_adtube_reject_reason_compat.sql
database/migrations/2026_07_24_0002_crypto_deposits_intent_link.sql
database/migrations/2026_07_24_0003_crypto_deposits_sender_wallet.sql
database/migrations/2026_07_25_0001_backup_offsite_columns.sql
database/migrations/2026_07_26_0001_fraud_dashboard_runtime_contracts.sql
database/migrations/2026_07_26_0001_fraud_reports_wire.sql
database/migrations/2026_07_26_0002_s2s_hook_events.sql
database/migrations/2026_07_26_0002_user_typing_patterns.sql
database/migrations/2026_08_03_0001_notification_ad_analytics.sql
database/migrations/2026_08_03_0002_remove_task_disputes.sql
database/migrations/2026_08_03_0003_remove_vitrine_disputes.sql
database/migrations/2026_08_03_0004_referral_milestone_tracking.sql
database/migrations/2026_08_03_0005_referral_signup_settings.sql
database/migrations/2026_08_08_0001_rbac_full_permissions.sql
database/migrations/2026_08_08_0002_vitrine_ratings_reports_tables.sql
database/migrations/2026_08_09_0001_currency_tag_money_tables.sql
database/migrations/2026_08_11_0001_create_missing_schema_tables_and_views.php
database/migrations/2026_08_11_0002_optimize_indexes_and_foreign_keys.sql
database/migrations/2026_08_11_0003_add_missing_foreign_keys_and_indexes.sql
database/migrations/2026_08_14_0001_queue_dlq_runtime_contract.sql
database/migrations/2026_08_15_0001_file_logs_upload_contract.sql
database/migrations/2026_08_15_0002_replay_returned_schema_migration.php
database/migrations/2026_08_15_0003_message_reactions_runtime_contract.sql
database/migrations/2026_08_15_0004_social_task_execution_unified_ad_fk.sql
database/migrations/2026_08_15_0005_investment_profit_runtime_contract.sql
database/migrations/2026_08_15_0006_investment_profit_settlement_accounting.sql
database/migrations/2026_08_15_0007_phase16_financial_uniqueness_invariants.php
database/migrations/2026_08_15_0007_phase16_financial_uniqueness_invariants.sql
database/migrations/2026_08_16_0001_fcm_device_token_invariants.sql
database/migrations/2026_08_16_0002_distributed_lock_fence_durability.sql
database/migrations/2026_08_17_0001_failed_job_durable_source_identity.sql
database/migrations/2026_08_24_0001_prediction_vitrine_rbac.sql
database/migrations/2026_08_24_0002_escrow_active_order_uniqueness.sql
database/migrations/2026_08_24_0003_payment_log_idempotency_unique.sql
database/migrations/2026_08_25_0001_withdrawal_destination_and_tracking_unique.sql
database/migrations/2026_08_29_0001_seed_banner_placements.sql
database/migrations/2026_08_29_0002_user_levels_full_schema.sql
database/migrations/2026_08_29_0003_seed_default_user_levels.sql
database/migrations/2026_08_30_0001_social_task_executions_full_schema.sql
database/migrations/2026_08_30_0002_coupons_created_by.sql
database/migrations/2026_08_30_0003_lottery_rounds_type_duration.sql
database/migrations/2026_08_30_0004_user_scores_unique_projection.sql
database/migrations/2026_08_30_0005_investment_withdrawals_completed_status.sql
database/migrations/2026_09_02_0001_task_reports_task_type.sql
database/migrations/2026_09_03_0001_round33_schema_repairs.php
database/migrations/2026_09_04_0001_user_level_history_columns.php
database/migrations/2026_09_04_0002_kyc_sla_promise.php
database/migrations/2026_09_04_0003_finance_sla_promise.php
database/migrations/2026_09_05_0001_user_social_accounts_review_columns.php
database/migrations/2026_09_06_0001_users_warning_count.php
database/migrations/2026_09_06_0002_sentry_alerting_columns.php
database/migrations/2026_09_06_0003_withdrawal_reviews_workflow_columns.php
database/migrations/2026_09_08_0001_social_accounts_verification_columns.php
database/migrations/2026_09_09_0001_ghost_column_audit_columns.php
database/migrations/2026_09_09_0001_mysql8_collation_compat.php
database/migrations/2026_09_11_0001_lottery_chance_logs_runtime_contract.php
database/migrations/2026_09_11_0002_interactions_context_widen.php
database/migrations/2026_09_11_0003_coupon_redemption_uniqueness_invariants.php
database/migrations/2026_09_12_0001_api_token_scopes_default_read.php
database/migrations/2026_09_12_0002_drop_orphan_user_fraud_scores.sql
database/migrations/2026_09_16_0001_email_queue_sending_status.php
database/migrations/2026_09_17_0001_drop_dead_review_status_column.php
database/migrations/2026_09_17_0001_drop_dead_schema_items.php
database/migrations/2026_09_18_0001_custom_task_proof_url_hash.sql
database/migrations/2026_09_19_0001_unify_feature_flag_rollout_column.sql
database/migrations/2026_09_19_0002_user_sessions_lat_lon.sql
database/migrations/2026_09_20_0001_users_ban_columns.sql
database/migrations/2026_09_20_0002_daily_statistics_create.sql
database/migrations/2026_09_20_0003_user_fraud_flags_unique_user.php
database/migrations/9999_0001_final_add_foreign_keys.sql
```
### chortke/deploy

```
deploy/README.md
deploy/docker/.dockerignore
deploy/docker/Dockerfile
deploy/docker/README.md
deploy/docker/docker-compose.yml
deploy/docker/docker-entrypoint.sh
deploy/docker/supervisord.conf
deploy/logrotate/chortke.conf
deploy/scripts/health-check-cron.sh
deploy/scripts/start-workers.sh
deploy/scripts/stop-workers.sh
deploy/supervisor/README.md
deploy/supervisor/chortke-dlq.conf
deploy/supervisor/chortke-health-monitor.conf
deploy/supervisor/chortke-outbox.conf
deploy/supervisor/chortke-queue.conf
deploy/supervisor/supervisord.conf
deploy/systemd/README.md
deploy/systemd/chortke-outbox.service
deploy/systemd/chortke-queue.service
```
### chortke/docker

```
docker/nginx/default.conf
docker/nginx/nginx.conf
docker/php/custom.ini
docker/supervisord.conf
```
### chortke/docs

```
docs/ARCHITECTURE_AUDIT_REPORT_2026.md
docs/CHORTKE_PHASE20_CORRECTION_AND_RETRACTION_FA.md
docs/DISTRIBUTED_PATTERNS.md
docs/ENCRYPTION_MIGRATION.md
docs/OPEN-ITEMS-POST-REPORT-2026-08-24-fa.md
docs/PHASE1-BROWSER-HARNESS-HONESTY-FA.md
docs/PRODUCTION_DISTRIBUTED.md
docs/SCALING.md
docs/TEST-STRATEGY-FULL-COVERAGE-FA.md
docs/TRIAGE-159-persian-throws-fa.md
docs/VERIFICATION-PARALLEL-PATHS-FA.md
docs/ads-registration-phase1-2026-06-20-fa.md
docs/ads-registration-phase2-3-2026-06-20-fa.md
docs/ads-registration-phase4-2026-06-20-fa.md
docs/ads-registration-phase5-2026-06-20-fa.md
docs/ads-registration-phase6-2026-06-20-fa.md
docs/ads-registration-phase7-2026-06-20-fa.md
docs/ads-registration-phase8-final-cleanup-2026-06-20-fa.md
docs/ads-ui-phase-2026-06-20-fa.md
docs/api-reference.md
docs/architecture_and_standards.md
docs/architecture_review.md
docs/audit/INDEX.md
docs/audit/PENDING-FIXES-QUEUE.md
docs/audit/s33_subbatch3_antifraud_score_gamification.md
docs/audit/s33_subbatch4_payment_wallet_money.md
docs/audit/s33_subbatch5_auth_user_identity.md
docs/audit/s33_subbatch6_sentry_search_infra.md
docs/content-phase1-route-parse-stabilization-2026-06-20-fa.md
docs/content-phase2-revenue-payment-2026-06-20-fa.md
docs/content-phase3-ui-hub-2026-06-20-fa.md
docs/content-phase4-admin-ui-actions-2026-06-20-fa.md
docs/content-phase5-legacy-events-outbox-cleanup-2026-06-20-fa.md
docs/custom-task-phase1-test-2026-06-20-fa.md
docs/dependency-integrity-report.md
docs/earning-module-audit-2026-06-19-fa.md
docs/event_registry_enhancement.md
docs/idempotency-fixes-summary-fa.md
docs/idempotency-system-audit-report.md
docs/influencer-phase1-escrow-verification-2026-06-21-fa.md
docs/influencer-phase2-single-page-hub-2026-06-21-fa.md
docs/influencer-phase3-admin-ui-actions-2026-06-21-fa.md
docs/influencer-phase4-legacy-route-cleanup-2026-06-21-fa.md
docs/mixed_sync_async_analysis.md
docs/outbox.md
docs/outbox_pattern.md
docs/phpstan-report-2026-07-09.md
docs/pr_checklist.md
docs/prediction-phase1-finance-rules-2026-06-22-fa.md
docs/prediction-phase2-ui-admin-job-2026-06-22-fa.md
docs/repository_migration.md
docs/saga_pattern.md
docs/schema_integrity_pass_2026_06_14.md
docs/seo-task-phase1-2-test-2026-06-20-fa.md
docs/social-camera-verification-test-2026-06-19-fa.md
docs/srp-sentry-model-roadmap.md
docs/task-execution-flow-test-2026-06-19-fa.md
docs/task-marketplace-unified-final-2026-06-20-fa.md
docs/view-asset-standard.md
docs/yellow-tier-formrequest-migration-2026-08-24-fa.md
```
### chortke/helpers

```
helpers/JalaliDate.php
helpers/admin_ui_helper.php
helpers/auth_helper.php
helpers/banner_helpers.php
helpers/captcha_helper.php
helpers/csrf_helper.php
helpers/date_helper.php
helpers/feature_flag_helpers.php
helpers/functions.php
helpers/label_helpers.php
helpers/notifications.php
helpers/rate_limit_helper.php
helpers/response_helper.php
helpers/security.php
helpers/site_helper.php
helpers/url_helper.php
helpers/view_helper.php
helpers/xss_protection.php
```
### chortke/public

```
public/.htaccess
public/assets/css/admin.css
public/assets/css/auth.css
public/assets/css/banners.css
public/assets/css/core.css
public/assets/css/home.css
public/assets/css/main.css
public/assets/css/pages.css
public/assets/css/panel-binance.css
public/assets/css/panel.css
public/assets/css/shared/layout.css
public/assets/css/tasks.css
public/assets/css/tokens.css
public/assets/css/views/admin/adsindex.css
public/assets/css/views/admin/dashboard.css
public/assets/css/views/adminadtasks.css
public/assets/css/views/adminbankcards.css
public/assets/css/views/adminbankcardsindex.css
public/assets/css/views/adminbankcardsreview.css
public/assets/css/views/adminbannerscreate.css
public/assets/css/views/adminbannersedit.css
public/assets/css/views/adminbannersindex.css
public/assets/css/views/adminbannersplacements.css
public/assets/css/views/adminbannersstats.css
public/assets/css/views/admincontent.css
public/assets/css/views/admincron.css
public/assets/css/views/admincryptodeposits.css
public/assets/css/views/adminfeaturesindex.css
public/assets/css/views/adminfrauduserscores.css
public/assets/css/views/admininfluencer.css
public/assets/css/views/admininvestmenttrades.css
public/assets/css/views/adminlogin.css
public/assets/css/views/adminlottery.css
public/assets/css/views/adminmanualdeposits.css
public/assets/css/views/adminnotifications.css
public/assets/css/views/adminprediction.css
public/assets/css/views/adminriskpoliciesindex.css
public/assets/css/views/adminsentrydashboard.css
public/assets/css/views/adminsentryfailedjobdetails.css
public/assets/css/views/adminsentryfailedjobs.css
public/assets/css/views/adminsentryoutboxdlq.css
public/assets/css/views/adminseokeywords.css
public/assets/css/views/adminsocialaccounts.css
public/assets/css/views/admintickets.css
public/assets/css/views/admintransactions.css
public/assets/css/views/adminwithdrawals.css
public/assets/css/views/bugreportwidget.css
public/assets/css/views/emailsdepositconfirmed.css
public/assets/css/views/emailskycapproved.css
public/assets/css/views/emailskycrejected.css
public/assets/css/views/emailslotterywinner.css
public/assets/css/views/emailspasswordreset.css
public/assets/css/views/emailsticketreply.css
public/assets/css/views/emailsverification.css
public/assets/css/views/emailswelcome.css
public/assets/css/views/emailswithdrawalapproved.css
public/assets/css/views/errors503.css
public/assets/css/views/help-hub.css
public/assets/css/views/partialssentrywidget.css
public/assets/css/views/static-pages.css
public/assets/css/views/status.css
public/assets/css/views/tailwind-lite.css
public/assets/css/views/testcaptcha.css
public/assets/css/views/user/dashboard.css
public/assets/css/views/useraccount.css
public/assets/css/views/useradshub.css
public/assets/css/views/useradsindex.css
public/assets/css/views/useradsshow.css
public/assets/css/views/useradtasks.css
public/assets/css/views/useradtubehub.css
public/assets/css/views/userbankcards.css
public/assets/css/views/userbankcardsform.css
public/assets/css/views/userbankcardsindex.css
public/assets/css/views/userbannerrequestbannercreate.css
public/assets/css/views/userbannerrequestbannerrequest.css
public/assets/css/views/userbugreportsshow.css
public/assets/css/views/usercontent.css
public/assets/css/views/usercontentcreate.css
public/assets/css/views/usercontenthub.css
public/assets/css/views/usercontentindex.css
public/assets/css/views/usercontentrevenues.css
public/assets/css/views/usercryptodeposit.css
public/assets/css/views/usercryptodepositindex.css
public/assets/css/views/usercustomtasks.css
public/assets/css/views/usercustomtasksratingmodal.css
public/assets/css/views/userdisputesindex.css
public/assets/css/views/userdisputesshow.css
public/assets/css/views/userearn.css
public/assets/css/views/userfinance.css
public/assets/css/views/userinfluencerdisputepanel.css
public/assets/css/views/userinfluencerhub.css
public/assets/css/views/userinfluencermyprofile.css
public/assets/css/views/userinvestment.css
public/assets/css/views/userinvestmentprofithistory.css
public/assets/css/views/userkyc.css
public/assets/css/views/userkycutils.css
public/assets/css/views/userlevelindex.css
public/assets/css/views/userlottery.css
public/assets/css/views/usermanualdeposit.css
public/assets/css/views/usermanualdepositindex.css
public/assets/css/views/usernotifications.css
public/assets/css/views/userpredictionhub.css
public/assets/css/views/userprofile.css
public/assets/css/views/userreferral.css
public/assets/css/views/userreferralanalytics.css
public/assets/css/views/userreferraldashboard.css
public/assets/css/views/userreferralmilestones.css
public/assets/css/views/usersecurityverify2fa.css
public/assets/css/views/userseo.css
public/assets/css/views/userseoad.css
public/assets/css/views/userseotasks.css
public/assets/css/views/usersocialaccounts.css
public/assets/css/views/usersupport.css
public/assets/css/views/usertasks.css
public/assets/css/views/usertasksfeed.css
public/assets/css/views/usertickets.css
public/assets/css/views/userticketsshow.css
public/assets/css/views/userverifyemail.css
public/assets/css/views/uservitrineindex.css
public/assets/css/views/uservitrinemylistings.css
public/assets/css/views/uservitrineshow.css
public/assets/css/views/userwallet.css
public/assets/css/views/userwalletdeposit.css
public/assets/css/views/userwallethistory.css
public/assets/css/views/userwithdrawal.css
public/assets/css/views/userwithdrawalindex.css
public/assets/css/wizard.css
public/assets/images/default-avatar.png
public/assets/images/favicon.png
public/assets/images/logo-icon-180.png
public/assets/images/logo-icon.png
public/assets/images/logo.png
public/assets/js/admin.js
public/assets/js/admin/adsindex.js
public/assets/js/admin/analyticstransactions.js
public/assets/js/admin/apitokensindex.js
public/assets/js/admin/audittrail.js
public/assets/js/admin/bankcards.js
public/assets/js/admin/bannerscreate.js
public/assets/js/admin/bannersindex.js
public/assets/js/admin/bannersplacements.js
public/assets/js/admin/bugreportsshow.js
public/assets/js/admin/cacheindex.js
public/assets/js/admin/content.js
public/assets/js/admin/couponscreate.js
public/assets/js/admin/couponsedit.js
public/assets/js/admin/couponsindex.js
public/assets/js/admin/couponsredemptions.js
public/assets/js/admin/cronindex.js
public/assets/js/admin/customtasks.js
public/assets/js/admin/dashboard.js
public/assets/js/admin/deposits.js
public/assets/js/admin/emailqueueindex.js
public/assets/js/admin/featuresindex.js
public/assets/js/admin/gatewaypaymentsindex.js
public/assets/js/admin/influencer.js
public/assets/js/admin/inlineactions.js
public/assets/js/admin/investment.js
public/assets/js/admin/kpi.js
public/assets/js/admin/kyc.js
public/assets/js/admin/levelscreate.js
public/assets/js/admin/levelsindex.js
public/assets/js/admin/login.js
public/assets/js/admin/logsdashboard.js
public/assets/js/admin/logsnotificationsettings.js
public/assets/js/admin/lottery.js
public/assets/js/admin/messagesreports.js
public/assets/js/admin/notifications.js
public/assets/js/admin/notificationssend.js
public/assets/js/admin/notificationsstats.js
public/assets/js/admin/predictionindex.js
public/assets/js/admin/predictionshow.js
public/assets/js/admin/referralindex.js
public/assets/js/admin/rolescreate.js
public/assets/js/admin/rolesedit.js
public/assets/js/admin/rolesindex.js
public/assets/js/admin/sentrydashboard.js
public/assets/js/admin/sentryeventfailures.js
public/assets/js/admin/sentryfailedjobdetails.js
public/assets/js/admin/sentryfailedjobs.js
public/assets/js/admin/sentryoutboxdlq.js
public/assets/js/admin/seoadindex.js
public/assets/js/admin/settingsindex.js
public/assets/js/admin/socialaccounts.js
public/assets/js/admin/socialtasks.js
public/assets/js/admin/ticketsshow.js
public/assets/js/admin/userscreate.js
public/assets/js/admin/usersedit.js
public/assets/js/admin/usersindex.js
public/assets/js/admin/vitrinedispute.js
public/assets/js/admin/vitrineindex.js
public/assets/js/admin/withdrawals.js
public/assets/js/app.js
public/assets/js/captcha.js
public/assets/js/carousel.js
public/assets/js/core.js
public/assets/js/fingerprint.js
public/assets/js/home.js
public/assets/js/loader.js
public/assets/js/scroll.js
public/assets/js/security.js
public/assets/js/shared/csrf.js
public/assets/js/shared/event-delegation.js
public/assets/js/shared/flash.js
public/assets/js/shared/footer-status.js
public/assets/js/shared/guest.js
public/assets/js/shared/loader.js
public/assets/js/shared/navbar.js
public/assets/js/shared/theme.js
public/assets/js/shared/user/navbar.js
public/assets/js/shared/ux-extras.js
public/assets/js/sidebar.js
public/assets/js/swal.js
public/assets/js/tracker.js
public/assets/js/user.js
public/assets/js/views/adminadsindex.js
public/assets/js/views/adminanalyticstransactions.js
public/assets/js/views/adminapitokensindex.js
public/assets/js/views/adminaudittrailindex.js
public/assets/js/views/adminbankcardsindex.js
public/assets/js/views/adminbankcardsreview.js
public/assets/js/views/adminbannerscreate.js
public/assets/js/views/adminbannersindex.js
public/assets/js/views/adminbannersplacements.js
public/assets/js/views/adminbugreportsshow.js
public/assets/js/views/admincacheindex.js
public/assets/js/views/admincontentindex.js
public/assets/js/views/admincontentrevenuecreate.js
public/assets/js/views/admincontentshow.js
public/assets/js/views/admincouponscreate.js
public/assets/js/views/admincouponsedit.js
public/assets/js/views/admincouponsindex.js
public/assets/js/views/admincouponsredemptions.js
public/assets/js/views/admincronindex.js
public/assets/js/views/admincryptodepositsindex.js
public/assets/js/views/admincryptodepositsreview.js
public/assets/js/views/admincustomtasksdisputes.js
public/assets/js/views/admincustomtasksindex.js
public/assets/js/views/admindashboard.js
public/assets/js/views/adminemailqueueindex.js
public/assets/js/views/adminfeaturesindex.js
public/assets/js/views/admingatewaypaymentsindex.js
public/assets/js/views/admininfluencerdisputedetail.js
public/assets/js/views/admininfluencerprofiles.js
public/assets/js/views/admininfluencerverifications.js
public/assets/js/views/admininvestmentapplyprofit.js
public/assets/js/views/admininvestmentindex.js
public/assets/js/views/admininvestmenttradecreate.js
public/assets/js/views/admininvestmenttrades.js
public/assets/js/views/admininvestmentwithdrawals.js
public/assets/js/views/adminkpifinancial.js
public/assets/js/views/adminkpiindex.js
public/assets/js/views/adminkpiusers.js
public/assets/js/views/adminkycindex.js
public/assets/js/views/adminkycreview.js
public/assets/js/views/adminlevelscreate.js
public/assets/js/views/adminlevelsindex.js
public/assets/js/views/adminlogin.js
public/assets/js/views/adminlogsdashboard.js
public/assets/js/views/adminlogsnotificationsettings.js
public/assets/js/views/adminlotterycreate.js
public/assets/js/views/adminlotteryshow.js
public/assets/js/views/adminmanualdepositsindex.js
public/assets/js/views/adminmanualdepositsreview.js
public/assets/js/views/adminmessagesreports.js
public/assets/js/views/adminnotificationsindex.js
public/assets/js/views/adminnotificationssend.js
public/assets/js/views/adminnotificationsstats.js
public/assets/js/views/adminnotificationstemplates.js
public/assets/js/views/adminpredictionindex.js
public/assets/js/views/adminpredictionshow.js
public/assets/js/views/adminreferralindex.js
public/assets/js/views/adminrolescreate.js
public/assets/js/views/adminrolesedit.js
public/assets/js/views/adminrolesindex.js
public/assets/js/views/adminsentrydashboard.js
public/assets/js/views/adminsentryfailedjobdetails.js
public/assets/js/views/adminsentryfailedjobs.js
public/assets/js/views/adminseoadindex.js
public/assets/js/views/adminsettingsindex.js
public/assets/js/views/adminsocialaccountsindex.js
public/assets/js/views/adminsocialaccountsshow.js
public/assets/js/views/adminsocialtasksexecutionshow.js
public/assets/js/views/adminsocialtasksindex.js
public/assets/js/views/adminsocialtasksshow.js
public/assets/js/views/adminsocialtasksusertrust.js
public/assets/js/views/adminticketsshow.js
public/assets/js/views/adminuserscreate.js
public/assets/js/views/adminusersedit.js
public/assets/js/views/adminusersindex.js
public/assets/js/views/adminvitrinedispute.js
public/assets/js/views/adminvitrineindex.js
public/assets/js/views/adminwithdrawalsindex.js
public/assets/js/views/adminwithdrawalsreview.js
public/assets/js/views/authforgotpassword.js
public/assets/js/views/bugreportwidget.js
public/assets/js/views/errors503.js
public/assets/js/views/layoutsadmin.js
public/assets/js/views/layoutsauth.js
public/assets/js/views/layoutsguest.js
public/assets/js/views/layoutsuser.js
public/assets/js/views/pageshelp.js
public/assets/js/views/testcaptcha.js
public/assets/js/views/user/dashboard.js
public/assets/js/views/useradscreate.js
public/assets/js/views/useradsindex.js
public/assets/js/views/useradsshow.js
public/assets/js/views/useradtubeexecute.js
public/assets/js/views/useradtubeindex.js
public/assets/js/views/userapitokensindex.js
public/assets/js/views/userbankcardscreate.js
public/assets/js/views/userbankcardsindex.js
public/assets/js/views/userbannerrequestbannercreate.js
public/assets/js/views/userbugreportsshow.js
public/assets/js/views/usercontentcreate.js
public/assets/js/views/usercontentindex.js
public/assets/js/views/usercryptodepositcreate.js
public/assets/js/views/usercustomtaskproof.js
public/assets/js/views/usercustomtaskshow.js
public/assets/js/views/userdashboard.js
public/assets/js/views/userdisputesshow.js
public/assets/js/views/userinfluencerdisputepanel.js
public/assets/js/views/userinfluencerhub.js
public/assets/js/views/userinfluencermyprofile.js
public/assets/js/views/userinvestmentcreate.js
public/assets/js/views/userinvestmentindex.js
public/assets/js/views/userkycupload.js
public/assets/js/views/userlevelindex.js
public/assets/js/views/userlogin.js
public/assets/js/views/userlotteryindex.js
public/assets/js/views/usermanualdepositcreate.js
public/assets/js/views/usermessagesindex.js
public/assets/js/views/usermessagesshow.js
public/assets/js/views/usernotificationsindex.js
public/assets/js/views/usernotificationspreferences.js
public/assets/js/views/userpredictionhub.js
public/assets/js/views/userpredictionshow.js
public/assets/js/views/userprofile.js
public/assets/js/views/userreferraldashboard.js
public/assets/js/views/userreferralindex.js
public/assets/js/views/usersecurityconfirmpassword.js
public/assets/js/views/usersecuritysettings.js
public/assets/js/views/usersecuritytwofactor.js
public/assets/js/views/usersecurityverify2fa.js
public/assets/js/views/userseoexecute.js
public/assets/js/views/userseoindex.js
public/assets/js/views/usersessionsindex.js
public/assets/js/views/usersocialaccountsindex.js
public/assets/js/views/usersocialtasksexecute.js
public/assets/js/views/usersocialtasksindex.js
public/assets/js/views/usertasksfeed.js
public/assets/js/views/userticketscreate.js
public/assets/js/views/userticketsshow.js
public/assets/js/views/userverifyemail.js
public/assets/js/views/uservitrinecreate.js
public/assets/js/views/uservitrineshow.js
public/assets/js/views/userwalletdepositselect.js
public/assets/js/views/userwalletescrowcreate.js
public/assets/js/views/userwalletescrows.js
public/assets/js/views/userwallethistory.js
public/assets/js/views/userwallettransfer.js
public/assets/js/views/userwithdrawalcreate.js
public/assets/js/views/userwithdrawalindex.js
public/assets/js/wizard.js
public/assets/js/youtube.js
public/assets/uploads/.htaccess
public/assets/vendor/bootstrap/css/bootstrap.min.css
public/assets/vendor/bootstrap/css/bootstrap.rtl.min.css
public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js
public/assets/vendor/chartjs/chart.min.js
public/assets/vendor/chartjs/chart.umd.min.js
public/assets/vendor/materialicons/MaterialIcons-Regular.ttf
public/assets/vendor/materialicons/materialicons.css
public/assets/vendor/notyf/notyf.min.css
public/assets/vendor/notyf/notyf.min.js
public/assets/vendor/qrcodejs/qrcode.min.js
public/assets/vendor/sweetalert2/sweetalert2.all.min.js
public/assets/vendor/sweetalert2/sweetalert2.min.css
public/assets/vendor/vazirmatn/Vazirmatn.woff2
public/assets/vendor/vazirmatn/vazirmatn.css
public/images/apple-touch-icon.png
public/images/favicon-16.png
public/images/favicon-32.png
public/images/favicon.png
public/images/logo-dark.png
public/images/pwa-icon-192.png
public/images/pwa-icon-512.png
public/images/pwa-icon-maskable-192.png
public/images/pwa-icon-maskable-512.png
public/index.php
public/install/.htaccess
public/install/README.md
public/install/index.php
public/manifest.json
public/uploads/.htaccess
public/uploads/avatars/34100418a7a7e287dcf9ade2.png
public/uploads/avatars/59ef5f9defcf5891b0468fa8.png
public/uploads/avatars/5ad40cc807cce3bc6eaaa37b.png
public/uploads/avatars/5aef5942515c1dd04cd19d01.png
public/uploads/avatars/6e5139b8fd1fa63bae2aca93.png
public/uploads/avatars/6e5531f7e4ba9e6110abe934.png
public/uploads/avatars/default-avatar.png
public/uploads/avatars/e459c9f2b5d4e5541b1e8b31.png
public/uploads/avatars/f96e8416b0de25963622f56f.png
public/uploads/site-images/24f9e5cdfd2c8dac00afa541.png
public/uploads/site-images/de4b3ca6e04e3cc2aac33e62.png
```
### chortke/routes

```
routes/admin.php
routes/api.php
routes/auth.php
routes/health.php
routes/missing.php
routes/public.php
routes/routes.php
routes/system.php
routes/user.php
routes/wallet.php
```
### chortke/scripts

```
scripts/README.md
scripts/capture_ui_screenshots.js
scripts/dev-router.php
scripts/lint_views.py
```
### chortke/storage

```
storage/.gitignore
storage/.htaccess
```
### chortke/tests

```
tests/AUTH_PROFILE_CODE_REVIEW.md
tests/Chaos/InfrastructureFailureRuntimeTest.php
tests/Contract/ExternalProviderHttpContractTest.php
tests/E2E/RuntimeHttpBehaviorTest.php
tests/E2E/chortke_full_30_modules.spec.js
tests/ENTERPRISE_TEST_ROADMAP_V3.md
tests/EarningAndUserManagementGrandVerification.php
tests/FINANCIAL_CORE_CODE_REVIEW.md
tests/Fixtures/CorruptDashboardCache.php
tests/Fixtures/CorruptSearchCache.php
tests/Fixtures/DeterministicPaymentGateway.php
tests/Fixtures/PaymentRuntimeFactory.php
tests/Fixtures/RuntimeBusinessFailureJob.php
tests/Fixtures/RuntimePoisonJob.php
tests/Fixtures/RuntimeProbeJob.php
tests/Fixtures/RuntimeRaceModel.php
tests/GAMIFICATION_REWARDS_CODE_REVIEW.md
tests/GrandOperationalActionDrivenVerification.php
tests/GrandOperationalExtendedModulesSaga.php
tests/HttpDomScanner.php
tests/INFRA_SEARCH_CODE_REVIEW.md
tests/Integration/AlertDispatcherEventBusBindingTest.php
tests/Integration/Auth/S10RegistrationVerificationTest.php
tests/Integration/BankInquiryContainerIntegrationTest.php
tests/Integration/ContainerBacked/Core/EventDispatcherTest.php
tests/Integration/ContainerBacked/SagaSystemTest.php
tests/Integration/ContainerBacked/Services/AccountDeletionEventWiringTest.php
tests/Integration/ContainerBacked/Services/AuthServiceTest.php
tests/Integration/ContainerBacked/Services/BankCardServiceTest.php
tests/Integration/ContainerBacked/Services/ContactServiceTest.php
tests/Integration/ContainerBacked/Services/CryptoDepositServiceTest.php
tests/Integration/ContainerBacked/Services/DirectMessageServiceTest.php
tests/Integration/ContainerBacked/Services/NotificationDispatcherTest.php
tests/Integration/ContainerBacked/Services/PaymentCryptoFulfillmentTest.php
tests/Integration/ContainerBacked/Services/PaymentServiceTest.php
tests/Integration/ContainerBacked/Services/RemainingCoreServicesTest.php
tests/Integration/ContainerBacked/Services/S15AuthUnverifiedGateTest.php
tests/Integration/ContainerBacked/Services/S5IdentityHardeningTest.php
tests/Integration/ContainerBacked/Services/VideoFingerprintServiceTest.php
tests/Integration/ContainerBacked/Services/WithdrawalAdminServiceTest.php
tests/Integration/ContainerBacked/StabilityTest.php
tests/Integration/ContainerIntegrityTest.php
tests/Integration/Core/CacheIntegrationTest.php
tests/Integration/Core/ErrorLogPersistenceTest.php
tests/Integration/Core/S6CacheTtlGuardTest.php
tests/Integration/Core/ValidatorDatabaseRuleRuntimeTest.php
tests/Integration/Database/DatabaseIntegrationTest.php
tests/Integration/Database/ModelFirstOrCreateConcurrencyRuntimeTest.php
tests/Integration/Database/QueryBuilderAggregateRuntimeTest.php
tests/Integration/Database/S5LikeEscapeRuntimeTest.php
tests/Integration/Database/S6IdempotencyThrowableTest.php
tests/Integration/Database/S6LockingReadRoutingTest.php
tests/Integration/DependencyIntegrityTest.php
tests/Integration/Distributed/DistributedPatternsTest.php
tests/Integration/Distributed/HealthEndpointsTest.php
tests/Integration/Distributed/S8EntryPointGuardsTest.php
tests/Integration/Distributed/TracingPropagationTest.php
tests/Integration/Distributed/WorkerLifecycleTest.php
tests/Integration/Financial/EscrowActiveUniquenessDatabaseTest.php
tests/Integration/Financial/EscrowBudgetConsumptionInvariantTest.php
tests/Integration/Financial/EscrowConcurrentUniquenessDatabaseTest.php
tests/Integration/Financial/EscrowDisputeSplitInvariantTest.php
tests/Integration/Financial/EscrowPartialSettlementInvariantTest.php
tests/Integration/Financial/FinancialCustomDealEscrowInvariantTest.php
tests/Integration/Financial/FinancialSocialTaskEscrowInvariantTest.php
tests/Integration/Financial/InfluencerEscrowCommissionInvariantTest.php
tests/Integration/Financial/InvestmentProfitSettlementRuntimeTest.php
tests/Integration/Financial/PaymentLogIdempotencyDatabaseTest.php
tests/Integration/Financial/VitrineEscrowCommissionInvariantTest.php
tests/Integration/Financial/WalletLockedFundsInvariantTest.php
tests/Integration/HomePageTest.php
tests/Integration/Idempotency/IdempotencySignatureRuntimeTest.php
tests/Integration/LevelIntegrationTest.php
tests/Integration/Listeners/DeadFileWiringRuntimeTest.php
tests/Integration/Models/ModelBoundaryContractsRuntimeTest.php
tests/Integration/Notification/FcmRuntimeContractTest.php
tests/Integration/Payment/PaymentCallbackRuntimeTest.php
tests/Integration/Queue/BusinessExceptionClassificationRuntimeTest.php
tests/Integration/Queue/OutboxQueueDlqRuntimeTest.php
tests/Integration/Queue/RedisDlqCrashConsistencyRuntimeTest.php
tests/Integration/Queue/RedisQueueRuntimeTest.php
tests/Integration/Rbac/PolicyServiceResourceDatabaseTest.php
tests/Integration/Rbac/PredictionVitrineRbacDatabaseTest.php
tests/Integration/Routing/S11RouteWiringSecurityTest.php
tests/Integration/Routing/S12SocialTaskVerifyEndpointsTest.php
tests/Integration/RuntimeInfrastructurePreflightTest.php
tests/Integration/S15ControllersB2HardeningTest.php
tests/Integration/Search/SchemaInspectorContractRuntimeTest.php
tests/Integration/Search/SearchEventRegistrationRuntimeTest.php
tests/Integration/Security/TwoFactorRuntimeTest.php
tests/Integration/Services/FinancialIntegrationTest.php
tests/Integration/Services/SchemaIntegrityTest.php
tests/Integration/Services/UserServiceIntegrationTest.php
tests/Integration/Session/RedisSessionHandlerRuntimeTest.php
tests/Integration/Upload/CustomTaskProofUploadContractTest.php
tests/Integration/View/ViewDataTypePreservationRuntimeTest.php
tests/LOGIC_DRIVEN_E2E_ROADMAP.md
tests/MARKETPLACE_DISPUTE_CODE_REVIEW.md
tests/Master360OperationalSaga.php
tests/OperationalEndToEndVerification.php
tests/ROADMAP.md
tests/SECURITY_FRAUD_CODE_REVIEW.md
tests/SESSION_REPORT.md
tests/SecurityAndPerformanceGrandBenchmark.php
tests/Support/CreatesTypedMockeryMocks.php
tests/Support/QueuePayloadProbeClass.php
tests/Support/ResetsConfiguredRedis.php
tests/Support/ServiceRestarter.php
tests/Support/browser-harness.js
tests/Support/db_disconnect_mid_transaction_worker.php
tests/Support/db_unavailable_worker.php
tests/Support/deadlock_retry_worker.php
tests/Support/fake-provider-server.php
tests/Support/hanging_redis_server.php
tests/Support/migrate_disposable_database.php
tests/Support/model_first_or_create_worker.php
tests/Support/outbox_runtime_worker.php
tests/Support/payment_callback_worker.php
tests/Support/provider_fake_server.php
tests/Support/provider_partition_initial_server.php
tests/Support/provider_partition_recovered_server.php
tests/Support/provider_partition_worker.php
tests/Support/queue_crash_worker.php
tests/Support/queue_runtime_worker.php
tests/Support/redis_restart_lock_worker.php
tests/Support/redis_timeout_worker.php
tests/Support/run-contract-suite.sh
tests/TEST_MATRIX.md
tests/UltraExhaustive360PlatformMasterSaga.php
tests/Unit/Adapters/AdSocialAdapterTest.php
tests/Unit/Adapters/AdTubeAdapterTest.php
tests/Unit/Adapters/AllAdaptersVerificationTest.php
tests/Unit/Adapters/BankInquiryManagerBehaviorTest.php
tests/Unit/Adapters/BannerAdapterTest.php
tests/Unit/Adapters/JibitInquiryAdapterTest.php
tests/Unit/Adapters/NotificationAdAdapterTest.php
tests/Unit/Adapters/SeoAdAdapterTest.php
tests/Unit/Adapters/VandarInquiryAdapterTest.php
tests/Unit/Architecture/ViewDataBoundaryArchitectureTest.php
tests/Unit/Auth/S10EventTokenPropagationTest.php
tests/Unit/Commands/AdminCLICommandsTest.php
tests/Unit/Commands/AllCommandsVerificationTest.php
tests/Unit/Commands/DLQRetryCommandTest.php
tests/Unit/Commands/QueueWorkCommandTest.php
tests/Unit/Commands/S18CommandsSecurityPinningTest.php
tests/Unit/ComprehensiveSecurityTest.php
tests/Unit/Config/S20ConfigMigrationsSecurityPinningTest.php
tests/Unit/ConstantsTest.php
tests/Unit/ContractsTest.php
tests/Unit/Controllers/Admin/AdminControllersStructuralTest.php
tests/Unit/Controllers/Admin/AdminCriticalControllersTest.php
tests/Unit/Controllers/AllControllersStructuralTest.php
tests/Unit/Controllers/Api/ApiControllersStructuralTest.php
tests/Unit/Controllers/Api/AppConfigControllerTest.php
tests/Unit/Controllers/Api/TokenControllerTest.php
tests/Unit/Controllers/Api/WalletControllerTest.php
tests/Unit/Controllers/NoRawSqlInBusinessMethodsTest.php
tests/Unit/Controllers/NoVerifySectionMethodsTest.php
tests/Unit/Controllers/RootControllersStructuralTest.php
tests/Unit/Controllers/S14ControllerGatePinningTest.php
tests/Unit/Controllers/S14ControllersHardeningTest.php
tests/Unit/Controllers/S15UserControllerSecurityTest.php
tests/Unit/Controllers/S16ControllersHardeningTest.php
tests/Unit/Controllers/User/UserControllersStructuralTest.php
tests/Unit/Controllers/User/WalletControllerTest.php
tests/Unit/Core/BlueprintBehaviorTest.php
tests/Unit/Core/CacheTest.php
tests/Unit/Core/CircuitBreakerConfigurationBehaviorTest.php
tests/Unit/Core/CliDispatcherBehaviorTest.php
tests/Unit/Core/ConfigReloadBehaviorTest.php
tests/Unit/Core/DatabaseErrorReporterTest.php
tests/Unit/Core/DatabaseTest.php
tests/Unit/Core/EncryptionTest.php
tests/Unit/Core/EventDispatcherRegistrationBehaviorTest.php
tests/Unit/Core/EventWiringIntegrityTest.php
tests/Unit/Core/ExceptionHandlerPayloadBehaviorTest.php
tests/Unit/Core/GenericEventBehaviorTest.php
tests/Unit/Core/LoggerSecurityBehaviorTest.php
tests/Unit/Core/PathResolverBehaviorTest.php
tests/Unit/Core/PipelineBehaviorTest.php
tests/Unit/Core/QueueBehaviorTest.php
tests/Unit/Core/RedisGracefulTest.php
tests/Unit/Core/RequestTest.php
tests/Unit/Core/ResponseTest.php
tests/Unit/Core/RetryPolicyTest.php
tests/Unit/Core/RouterTest.php
tests/Unit/Core/S4CoreSecurityHardeningTest.php
tests/Unit/Core/S5CoreSecurityHardeningTest.php
tests/Unit/Core/S6CoreSecurityHardeningTest.php
tests/Unit/Core/S7CoreSecurityHardeningTest.php
tests/Unit/Core/S8CoreSecurityHardeningTest.php
tests/Unit/Core/S9CoreClosureTest.php
tests/Unit/Core/SessionTest.php
tests/Unit/Core/UrlGeneratorBehaviorTest.php
tests/Unit/Core/ValidatorSafeAccessorsTest.php
tests/Unit/Data/CommonPasswordsBloomTest.php
tests/Unit/DataIntegrityPerformanceTest.php
tests/Unit/Deploy/S22DeployDockerSecurityPinningTest.php
tests/Unit/DomainEventInterfaceTest.php
tests/Unit/EnumsTest.php
tests/Unit/Events/DomainEventImplementationTest.php
tests/Unit/EventsTest.php
tests/Unit/FinancialIntegrityTest.php
tests/Unit/Helpers/SafeValueHelpersTest.php
tests/Unit/Jobs/AllJobsVerificationTest.php
tests/Unit/Jobs/CreateTradeJobTest.php
tests/Unit/Jobs/CustomTaskProofFingerprintTest.php
tests/Unit/Jobs/JobPayloadBoundaryBehaviorTest.php
tests/Unit/Jobs/JobsBehaviorTest.php
tests/Unit/Jobs/OutboxMigrationJobsTest.php
tests/Unit/Jobs/S17JobsCommandsHardeningTest.php
tests/Unit/Jobs/S17JobsListenersSecurityPinningTest.php
tests/Unit/Jobs/VerifyCryptoDepositJobTest.php
tests/Unit/Jobs/WithdrawalTimeoutJobCasTest.php
tests/Unit/Listeners/ListenersBehaviorTest.php
tests/Unit/Listeners/OutboxMigrationListenersTest.php
tests/Unit/Listeners/S18EventsListenersHardeningTest.php
tests/Unit/Listeners/S18p6NotificationUnityTest.php
tests/Unit/Middleware/AdminMiddlewareTest.php
tests/Unit/Middleware/AdvancedFraudMiddlewareTest.php
tests/Unit/Middleware/ApiRequestMiddlewareTest.php
tests/Unit/Middleware/S12RbacMappingDecisionTest.php
tests/Unit/Middleware/SecurityHeadersMiddlewareTest.php
tests/Unit/MiddlewareTest.php
tests/Unit/Models/FraudReportTest.php
tests/Unit/Models/S12ModelsHardeningTest.php
tests/Unit/Models/S13TelemetryGhostColumnsTest.php
tests/Unit/Models/S14InfluencerMassAssignmentTest.php
tests/Unit/Models/S16ModelsSecurityPinningTest.php
tests/Unit/Models/S2sHookEventTest.php
tests/Unit/ModelsTest.php
tests/Unit/OutboxArchitectureTest.php
tests/Unit/Routes/S19RoutesBootstrapSecurityPinningTest.php
tests/Unit/SecurityAndPerformanceBenchmarkTest.php
tests/Unit/Services/AccountDeletionSettlementTest.php
tests/Unit/Services/AdminDashboardContractBehaviorTest.php
tests/Unit/Services/AdsBudgetSettlementNotificationTest.php
tests/Unit/Services/AdvancedAuditTrailTest.php
tests/Unit/Services/AdvancedNotificationsTest.php
tests/Unit/Services/AlertDispatcherThrottleBehaviorTest.php
tests/Unit/Services/AllEarningModulesBehaviorTest.php
tests/Unit/Services/AllSupportAndMessagingModulesBehaviorTest.php
tests/Unit/Services/AnalyticsServiceTest.php
tests/Unit/Services/AntiFraudSecurityTest.php
tests/Unit/Services/ApiTokenServiceTest.php
tests/Unit/Services/AppSettingsSingleFlightTest.php
tests/Unit/Services/AuditTrailServiceTest.php
tests/Unit/Services/AuthModuleFixTest.php
tests/Unit/Services/AuthOAuthJobsFixTest.php
tests/Unit/Services/BannerServiceTest.php
tests/Unit/Services/BatchLoaderTest.php
tests/Unit/Services/BulkOperationsServiceBehaviorTest.php
tests/Unit/Services/BulkOperationsServiceTest.php
tests/Unit/Services/CacheInvalidationTest.php
tests/Unit/Services/CaptchaBypassHardeningTest.php
tests/Unit/Services/CaptchaServiceTest.php
tests/Unit/Services/CircuitBreakerAtomicTest.php
tests/Unit/Services/CircuitBreakerPaymentTest.php
tests/Unit/Services/ContentServiceTest.php
tests/Unit/Services/CouponServiceTest.php
tests/Unit/Services/CurrencyServiceTest.php
tests/Unit/Services/CustomTaskServicesBehaviorTest.php
tests/Unit/Services/CustomTaskSettlementBehaviorTest.php
tests/Unit/Services/DashboardStatsServiceTest.php
tests/Unit/Services/DataExportServiceTest.php
tests/Unit/Services/DisputeIdempotencyFixTest.php
tests/Unit/Services/DisputeResolveByRefTest.php
tests/Unit/Services/DisputeServiceTest.php
tests/Unit/Services/DistributedLockFailClosedTest.php
tests/Unit/Services/EmailDeliveryStoreTest.php
tests/Unit/Services/EscrowServiceBehaviorTest.php
tests/Unit/Services/EscrowServiceTest.php
tests/Unit/Services/ExportServiceTest.php
tests/Unit/Services/FatJobAuditTest.php
tests/Unit/Services/FeatureFlagRolloutUnificationTest.php
tests/Unit/Services/FraudDetectionServiceBehaviorTest.php
tests/Unit/Services/FraudDetectionServiceTest.php
tests/Unit/Services/FraudGuardServiceTest.php
tests/Unit/Services/FraudPolicyMigrationTest.php
tests/Unit/Services/GamificationTest.php
tests/Unit/Services/GoogleJwtVerifierTest.php
tests/Unit/Services/IdempotencyKeysTest.php
tests/Unit/Services/InfluencerCommandServiceTest.php
tests/Unit/Services/InfluencerModelTest.php
tests/Unit/Services/InvestmentServiceBehaviorTest.php
tests/Unit/Services/InvestmentServiceTest.php
tests/Unit/Services/KycBankCardSecurityTest.php
tests/Unit/Services/LedgerReconciliationTest.php
tests/Unit/Services/LoginFlowFixTest.php
tests/Unit/Services/LotteryCommandServiceBehaviorTest.php
tests/Unit/Services/LotteryServiceTest.php
tests/Unit/Services/MaintenanceAndAuxiliaryTest.php
tests/Unit/Services/ManualDepositServicesGuardTest.php
tests/Unit/Services/MessageModerationBehaviorTest.php
tests/Unit/Services/MessageModerationServiceTest.php
tests/Unit/Services/MigrationServiceSplitterTest.php
tests/Unit/Services/MobileColumnConsistencyTest.php
tests/Unit/Services/MobileToPhoneColumnFixTest.php
tests/Unit/Services/MonthlyLeaderboardTest.php
tests/Unit/Services/NotificationAdAnalyticsTest.php
tests/Unit/Services/NotificationChannelsTest.php
tests/Unit/Services/NotificationModelTest.php
tests/Unit/Services/NotificationRetryPolicyTest.php
tests/Unit/Services/NotificationTemplateTest.php
tests/Unit/Services/NotificationTrackerAndAnalyticsTest.php
tests/Unit/Services/OffsiteBackupServiceTest.php
tests/Unit/Services/OutboxAndDLQResilienceTest.php
tests/Unit/Services/OutboxFirstMigrationTest.php
tests/Unit/Services/OutboxMigrationServicesTest.php
tests/Unit/Services/OutboxPublisherBehaviorTest.php
tests/Unit/Services/OutboxPublisherTest.php
tests/Unit/Services/OutboxRecordEventTest.php
tests/Unit/Services/OutboxServiceTest.php
tests/Unit/Services/PasswordRecoveryServiceBehaviorTest.php
tests/Unit/Services/PasswordRecoveryServiceTest.php
tests/Unit/Services/PaymentCallbackSecurityTest.php
tests/Unit/Services/PaymentGatewaysTest.php
tests/Unit/Services/PerformanceAndOptimizationTest.php
tests/Unit/Services/PolicyServiceResourceAuthorizationTest.php
tests/Unit/Services/ProfileServiceTest.php
tests/Unit/Services/RateLimitStrategiesTest.php
tests/Unit/Services/ReconciliationServiceTest.php
tests/Unit/Services/ReferralBonusMilestoneTest.php
tests/Unit/Services/RemainingStrategiesAndMigrationTest.php
tests/Unit/Services/ReportServiceBehaviorTest.php
tests/Unit/Services/S12FinancialCorePinningTest.php
tests/Unit/Services/S13ServicesSecurityPinningTest.php
tests/Unit/Services/S18p5DeletionGuardAndWithdrawalNoticeTest.php
tests/Unit/Services/S23ServicesFinancialSecurityPinningTest.php
tests/Unit/Services/S24ServicesPlatformSecurityPinningTest.php
tests/Unit/Services/S25MoneyFixesTest.php
tests/Unit/Services/S25ServicesContentOpsSecurityPinningTest.php
tests/Unit/Services/S26InfraContentFixesTest.php
tests/Unit/Services/S27P2SubserviceHardeningTest.php
tests/Unit/Services/S27SubserviceGuardsTest.php
tests/Unit/Services/SagaOrchestratorTest.php
tests/Unit/Services/ScheduledPaymentServiceTest.php
tests/Unit/Services/ScoreCommandServiceTest.php
tests/Unit/Services/ScoreDomainPolicyTest.php
tests/Unit/Services/ScoreRatingFixTest.php
tests/Unit/Services/ScoreSystemDeltaTest.php
tests/Unit/Services/ScoreSystemSetTest.php
tests/Unit/Services/SearchCacheContractBehaviorTest.php
tests/Unit/Services/SearchEcosystemTest.php
tests/Unit/Services/SearchRuntimeBehaviorTest.php
tests/Unit/Services/SearchSystemFixTest.php
tests/Unit/Services/SecurityHardeningTest.php
tests/Unit/Services/SentryModelSRPTest.php
tests/Unit/Services/SentryModuleFix1to6Test.php
tests/Unit/Services/SentryModuleFix7to12Test.php
tests/Unit/Services/SentryModuleRound2Test.php
tests/Unit/Services/SentryProducerContractBehaviorTest.php
tests/Unit/Services/SeoEngagementBoundaryTest.php
tests/Unit/Services/SeoPayoutServiceTest.php
tests/Unit/Services/SessionServiceBehaviorTest.php
tests/Unit/Services/SettingsSecretBoxTest.php
tests/Unit/Services/Shared/ReferralServiceMultiTierTest.php
tests/Unit/Services/SmsNotificationServiceTest.php
tests/Unit/Services/SocialAccountServiceTest.php
tests/Unit/Services/SplitServicesTest.php
tests/Unit/Services/StoryOrderModelTest.php
tests/Unit/Services/ThirdPartyAuthTest.php
tests/Unit/Services/TicketCommandServiceBehaviorTest.php
tests/Unit/Services/TicketServiceTest.php
tests/Unit/Services/TrustServiceTest.php
tests/Unit/Services/TwoFactorServiceTest.php
tests/Unit/Services/UnifiedTaskServiceTest.php
tests/Unit/Services/UploadServicePathIntegrationTest.php
tests/Unit/Services/UserInteractionsTest.php
tests/Unit/Services/UserLevelHistoryTest.php
tests/Unit/Services/UserVacationTest.php
tests/Unit/Services/ValidatesExternalUrlTest.php
tests/Unit/Services/VitrineRatingAndReportTest.php
tests/Unit/Services/VitrineServiceBehaviorTest.php
tests/Unit/Services/VitrineSystemTest.php
tests/Unit/Services/Wallet/WalletMutationReverseTest.php
tests/Unit/Services/Wallet/WithdrawalCasTest.php
tests/Unit/Services/WalletServiceBehaviorTest.php
tests/Unit/Services/WalletServiceTest.php
tests/Unit/Services/WebSocketServiceTest.php
tests/Unit/Services/WithdrawalQueryServiceTest.php
tests/Unit/Services/WithdrawalUserServiceTest.php
tests/Unit/Support/ServiceRestarterTest.php
tests/Unit/Validators/CreateWithdrawalRequestTest.php
tests/Unit/Validators/LoginRequestTest.php
tests/Unit/ValueObjects/MoneyBehaviorTest.php
tests/Unit/ValueObjects/MoneyFormatPrecisionTest.php
tests/Unit/Views/S21ViewsXssSecurityPinningTest.php
tests/Unit/Views/SidebarNoDbInViewTest.php
tests/browser_0_to_100_full_platform_e2e.js
tests/browser_admin.js
tests/browser_admin_governance.js
tests/browser_advanced_action_driven.js
tests/browser_analytics_search.js
tests/browser_antifraud.js
tests/browser_auth.js
tests/browser_chaos_engineering.js
tests/browser_content_revenue.js
tests/browser_coupon.js
tests/browser_custom_sentry.js
tests/browser_deep_test.js
tests/browser_earning_and_user_mgmt_e2e.js
tests/browser_grand_lifecycle_saga.js
tests/browser_infra.js
tests/browser_installer.js
tests/browser_investment.js
tests/browser_kyc.js
tests/browser_logic_auth_profile.js
tests/browser_logic_financial_treasury.js
tests/browser_logic_security_fraud.js
tests/browser_lottery.js
tests/browser_maintenance_tools.js
tests/browser_notification.js
tests/browser_payment.js
tests/browser_prediction.js
tests/browser_profile.js
tests/browser_quick_test.js
tests/browser_referral.js
tests/browser_tasks.js
tests/browser_test.js
tests/browser_ticket.js
tests/browser_vitrine.js
tests/browser_wallet.js
tests/end_to_end_system_test.php
tests/flush_cache.php
tests/logic_auth_profile.py
tests/logic_financial_treasury.py
tests/logic_hardcore_deep_dive.py
tests/logic_security_fraud.py
tests/model_race_test.php
tests/notification_audit_test.php
tests/outbox_dlq_audit_test.php
tests/phase3_revenue_test.php
tests/phase4_gamification_test.php
tests/phase4_influencer_test.php
tests/phase4_payouts_test.php
tests/phase5_infra_heartbeat_test.php
tests/phase5_security_audit_test.php
tests/phase6_manual_deposit_audit_test.php
tests/querybuilder_integration_test.php
tests/run_all.py
tests/safe_expression_test.php
tests/scenario_admin.py
tests/scenario_admin_governance.py
tests/scenario_analytics_search.py
tests/scenario_antifraud.py
tests/scenario_auth.py
tests/scenario_bankcard.py
tests/scenario_chaos_engineering.py
tests/scenario_content_revenue.py
tests/scenario_coupon.py
tests/scenario_crypto.py
tests/scenario_custom_sentry.py
tests/scenario_deep.py
tests/scenario_dispute.py
tests/scenario_escrow.py
tests/scenario_infra.py
tests/scenario_installer.py
tests/scenario_investment.py
tests/scenario_kyc.py
tests/scenario_lottery.py
tests/scenario_maintenance_tools.py
tests/scenario_notification.py
tests/scenario_payment.py
tests/scenario_prediction.py
tests/scenario_profile.py
tests/scenario_referral.py
tests/scenario_tasks.py
tests/scenario_test.py
tests/scenario_ticket.py
tests/scenario_vitrine.py
tests/scenario_wallet.py
tests/sentry_activation_test.php
tests/sentry_monitoring_audit_test.php
tests/session_helper.php
tests/test_9_modules_exhaustive_e2e.py
tests/test_ads_coupon_split.py
tests/test_backup_restore_real.py
tests/test_infra_prod_audit.py
tests/test_performance_explain_real.py
tests/ultra_comprehensive_test.php
tests/validate_raw_sql_test.php
```
### chortke/tools

```
tools/__pycache__/superglobals_linter.cpython-312.pyc
tools/ads-management-phase3-db-test.php
tools/ads-phase4-finance-delivery-db-test.php
tools/ads-phase5-lifecycle-reconciliation-db-test.php
tools/ads-phase6-social-escrow-db-test.php
tools/ads-phase7-admin-social-seo-db-test.php
tools/ads-registration-phase1-db-test.php
tools/asset_renamer.py
tools/browser-preview/account-hub-preview.html
tools/browser-preview/ads-wizard-phase2-preview.html
tools/browser-preview/custom-task-dispute-detail-preview.html
tools/browser-preview/investment-create-insufficient-preview.html
tools/browser-preview/investment-create-preview.html
tools/browser-preview/investment-hub-preview.html
tools/browser-preview/notification-preferences-test.html
tools/browser-preview/screenshots/content-phase5-user-show.png
tools/browser-preview/support-hub-preview.html
tools/browser-preview/task-marketplace-unified-final.html
tools/browser-preview/wallet-hub-preview.html
tools/comprehensive_operational_validator.py
tools/content-phase2-revenue-flow-db-test.php
tools/content-phase4-admin-http-seed.php
tools/content-phase5-legacy-event-guard-db-test.php
tools/custom-task-admanager-db-test.php
tools/custom-task-flow-db-test.php
tools/custom-task-phase3-db-test.php
tools/custom-task-phase4-db-test.php
tools/custom-task-proof-schema-db-test.php
tools/custom-task-split-escrow-db-test.php
tools/describe_tables.php
tools/dev-router.php
tools/dev/run-synthetic-crypto-audit.sh
tools/dev/run-synthetic-crypto-canary.sh
tools/dev/run-synthetic-financial-audit.sh
tools/dev/setup-financial-test-env.sh
tools/dev/verify-financial-stack.sh
tools/enterprise_phpstan_evaluator.py
tools/final_views_assurance.py
tools/influencer-phase1-dispute-escrow-db-test.php
tools/influencer-phase1-escrow-flow-db-test.php
tools/influencer-phase1-screenshot-verification-db-test.php
tools/inline_assets_analyzer.py
tools/list_tables.php
tools/mark_legacy_migrations_done.php
tools/prediction-phase1-finance-rules-db-test.php
tools/prediction-phase2-job-route-flow-db-test.php
tools/qa5_stats_probe.php
tools/replace_user_dashboard_script.py
tools/restamp-checksums.php
tools/scan-truth-parity.php
tools/secret_scan.sh
tools/seo-task-finance-cleanup-db-test.php
tools/seo-task-flow-db-test.php
tools/seo-task-reconciliation-db-test.php
tools/social-camera-db-test.php
tools/subassets_renamer.py
tools/superglobals_linter.py
tools/task-marketplace-unified-db-test.php
tools/universal_views_scanner.py
tools/verify_fix6a.php
tools/verify_fix6b.php
tools/verify_fix6c.php
tools/verify_fix6d.php
tools/verify_fix6e.php
tools/verify_fix8a.php
tools/verify_fix8b.php
tools/verify_fix8c.php
tools/verify_fix8c1.php
tools/verify_fix8c2.php
tools/verify_fix8e.php
tools/verify_fix_c1.php
tools/verify_fix_c2.php
```
### chortke/views

```
views/admin/account-deletion/history.php
views/admin/account-deletion/pending.php
views/admin/account-deletion/stats.php
views/admin/ads/index.php
views/admin/ads/partials/adtube_detail.php
views/admin/ads/partials/banner_detail.php
views/admin/ads/partials/custom_task_detail.php
views/admin/ads/partials/notification_detail.php
views/admin/ads/partials/seo_detail.php
views/admin/ads/partials/social_task_detail.php
views/admin/ads/show.php
views/admin/analytics/custom-tasks.php
views/admin/analytics/dashboard.php
views/admin/analytics/ratings.php
views/admin/analytics/revenue.php
views/admin/analytics/social-tasks.php
views/admin/analytics/system-health.php
views/admin/analytics/transactions.php
views/admin/analytics/users.php
views/admin/api-tokens/index.php
views/admin/audit-trail/index.php
views/admin/audit-trail/show.php
views/admin/audit-trail/stats.php
views/admin/audit-trail/user-history.php
views/admin/backups/index.php
views/admin/backups/stats.php
views/admin/bank-cards/index.php
views/admin/bank-cards/review.php
views/admin/banners/create.php
views/admin/banners/edit.php
views/admin/banners/index.php
views/admin/banners/placements.php
views/admin/banners/stats.php
views/admin/bug-reports/index.php
views/admin/bug-reports/show.php
views/admin/cache/index.php
views/admin/content/_admin-nav.php
views/admin/content/index.php
views/admin/content/revenue-create.php
views/admin/content/revenues.php
views/admin/content/show.php
views/admin/coupons/create.php
views/admin/coupons/details.php
views/admin/coupons/edit.php
views/admin/coupons/index.php
views/admin/coupons/redemptions.php
views/admin/coupons/statistics.php
views/admin/cron/index.php
views/admin/crypto-deposits/index.php
views/admin/crypto-deposits/review.php
views/admin/custom-tasks/analytics.php
views/admin/custom-tasks/dispute-detail.php
views/admin/custom-tasks/disputes.php
views/admin/custom-tasks/index.php
views/admin/custom-tasks/reports.php
views/admin/custom-tasks/show.php
views/admin/dashboard.php
views/admin/database-health.php
views/admin/email-queue/index.php
views/admin/export/index.php
views/admin/features/index.php
views/admin/fraud/dashboard.php
views/admin/fraud/device-blacklist.php
views/admin/fraud/ip-blacklist.php
views/admin/fraud/logs.php
views/admin/fraud/reports.php
views/admin/fraud/user-scores.php
views/admin/gateway-payments/index.php
views/admin/influencer/_admin-nav.php
views/admin/influencer/dispute-detail.php
views/admin/influencer/disputes.php
views/admin/influencer/orders.php
views/admin/influencer/profiles.php
views/admin/influencer/verifications.php
views/admin/investment/apply-profit.php
views/admin/investment/index.php
views/admin/investment/show.php
views/admin/investment/solvency.php
views/admin/investment/trade-create.php
views/admin/investment/trades.php
views/admin/investment/withdrawals.php
views/admin/kpi/financial.php
views/admin/kpi/index.php
views/admin/kpi/s2s.php
views/admin/kpi/users.php
views/admin/kyc/index.php
views/admin/kyc/review.php
views/admin/levels/create.php
views/admin/levels/edit.php
views/admin/levels/index.php
views/admin/levels/user-levels.php
views/admin/login.php
views/admin/logs/activity.php
views/admin/logs/audit.php
views/admin/logs/dashboard.php
views/admin/logs/error-details.php
views/admin/logs/index.php
views/admin/logs/mailbox.php
views/admin/logs/notification-settings.php
views/admin/logs/security.php
views/admin/logs/show.php
views/admin/logs/system.php
views/admin/lottery/create.php
views/admin/lottery/index.php
views/admin/lottery/show.php
views/admin/manual-deposits/index.php
views/admin/manual-deposits/review.php
views/admin/messages/blocked-users.php
views/admin/messages/report-detail.php
views/admin/messages/reports.php
views/admin/messages/stats.php
views/admin/notifications/index.php
views/admin/notifications/send.php
views/admin/notifications/stats.php
views/admin/notifications/templates.php
views/admin/prediction/create.php
views/admin/prediction/index.php
views/admin/prediction/show.php
views/admin/referral/index.php
views/admin/referral/settings.php
views/admin/referral/user-detail.php
views/admin/risk-policies/index.php
views/admin/roles/create.php
views/admin/roles/edit.php
views/admin/roles/index.php
views/admin/sentry/alerts.php
views/admin/sentry/analytics.php
views/admin/sentry/audit-trail.php
views/admin/sentry/dashboard.php
views/admin/sentry/event-failures.php
views/admin/sentry/failed-job-details.php
views/admin/sentry/failed-jobs.php
views/admin/sentry/issue-details.php
views/admin/sentry/issues.php
views/admin/sentry/outbox-dlq.php
views/admin/sentry/performance.php
views/admin/sentry/security.php
views/admin/seo-ad/index.php
views/admin/settings/index.php
views/admin/social-accounts/index.php
views/admin/social-accounts/show.php
views/admin/social-tasks/execution-show.php
views/admin/social-tasks/executions.php
views/admin/social-tasks/index.php
views/admin/social-tasks/rating-review-detail.php
views/admin/social-tasks/rating-reviews.php
views/admin/social-tasks/show.php
views/admin/social-tasks/stats.php
views/admin/social-tasks/trust.php
views/admin/social-tasks/user-trust.php
views/admin/tickets/index.php
views/admin/tickets/show.php
views/admin/transactions/index.php
views/admin/transactions/show.php
views/admin/users/create.php
views/admin/users/edit.php
views/admin/users/index.php
views/admin/verify-2fa.php
views/admin/vitrine/dispute.php
views/admin/vitrine/index.php
views/admin/vitrine/settings.php
views/admin/withdrawals/index.php
views/admin/withdrawals/review.php
views/auth/forgot-password.php
views/auth/oauth-confirm.php
views/auth/reset-password.php
views/emails/_footer.php
views/emails/_header.php
views/emails/account-locked.php
views/emails/deposit-confirmed.php
views/emails/kyc-approved.php
views/emails/kyc-rejected.php
views/emails/lottery-winner.php
views/emails/password-reset.php
views/emails/ticket-reply.php
views/emails/verification.php
views/emails/welcome.php
views/emails/withdrawal-approved.php
views/errors/403.php
views/errors/404.php
views/errors/419.php
views/errors/429.php
views/errors/500.php
views/errors/503.php
views/errors/feature-disabled.php
views/errors/maintenance.php
views/layouts/admin.php
views/layouts/auth.php
views/layouts/footer.php
views/layouts/guest.php
views/layouts/user.php
views/pages/about.php
views/pages/contact.php
views/pages/help.php
views/pages/privacy.php
views/pages/show.php
views/pages/status.php
views/pages/terms.php
views/partials/admin/navbar.php
views/partials/admin/sidebar.php
views/partials/bug-report-widget.php
views/partials/pagination.php
views/partials/sentry-widget.php
views/partials/user/footer.php
views/partials/user/navbar.php
views/partials/user/sidebar.php
views/test-captcha.php
views/user/account/_account-nav.php
views/user/ads/_create-panel.php
views/user/ads/create.php
views/user/ads/index.php
views/user/ads/show.php
views/user/adtube/execute.php
views/user/adtube/history.php
views/user/adtube/index.php
views/user/api-tokens/index.php
views/user/bank-cards/index.php
views/user/bug-reports/index.php
views/user/bug-reports/show.php
views/user/content/_content-nav.php
views/user/content/create.php
views/user/content/index.php
views/user/content/revenues.php
views/user/content/show.php
views/user/coupons/history.php
views/user/crypto-deposit/create.php
views/user/crypto-deposit/index.php
views/user/custom-tasks/executor/dispute-detail.php
views/user/custom-tasks/executor/disputes.php
views/user/custom-tasks/executor/my-submissions.php
views/user/custom-tasks/proof.php
views/user/custom-tasks/show.php
views/user/dashboard.php
views/user/disputes/index.php
views/user/disputes/show.php
views/user/influencer/dispute-panel.php
views/user/influencer/my-profile.php
views/user/investment/create.php
views/user/investment/index.php
views/user/investment/profit-history.php
views/user/kyc/index.php
views/user/kyc/upload.php
views/user/level/index.php
views/user/login.php
views/user/lottery/index.php
views/user/manual-deposit/create.php
views/user/manual-deposit/index.php
views/user/messages/index.php
views/user/messages/show.php
views/user/notifications/index.php
views/user/notifications/preferences.php
views/user/prediction/index.php
views/user/prediction/show.php
views/user/profile.php
views/user/referral/analytics.php
views/user/referral/dashboard.php
views/user/referral/index.php
views/user/referral/milestones.php
views/user/register.php
views/user/search/results.php
views/user/security/confirm-password.php
views/user/security/two-factor.php
views/user/security/verify-2fa.php
views/user/seo/execute.php
views/user/seo/history.php
views/user/seo/index.php
views/user/seo/show-execution.php
views/user/sessions/index.php
views/user/settings/_settings-nav.php
views/user/settings/account-deletion.php
views/user/settings/data-export.php
views/user/settings/general.php
views/user/settings/hub.php
views/user/settings/privacy.php
views/user/settings/security.php
views/user/social-accounts/create.php
views/user/social-accounts/edit.php
views/user/social-accounts/index.php
views/user/social-tasks/dashboard.php
views/user/social-tasks/execute.php
views/user/social-tasks/history.php
views/user/social-tasks/index.php
views/user/support/_support-nav.php
views/user/tasks/_earn-nav.php
views/user/tasks/feed.php
views/user/tickets/create.php
views/user/tickets/index.php
views/user/tickets/show.php
views/user/verify-email.php
views/user/vitrine/create.php
views/user/vitrine/index.php
views/user/vitrine/my-listings.php
views/user/vitrine/my-purchases.php
views/user/vitrine/my-requests.php
views/user/vitrine/show.php
views/user/vitrine/wanted.php
views/user/wallet/_finance-nav.php
views/user/wallet/deposit-select.php
views/user/wallet/escrow-create.php
views/user/wallet/escrows.php
views/user/wallet/history.php
views/user/wallet/index.php
views/user/wallet/transfer.php
views/user/withdrawal/create.php
views/user/withdrawal/index.php
views/welcome.php
```

### chortke/ (ریشهٔ پلتفرم — فایل‌های root)

```
.dockerignore
.editorconfig
.env.example
.gitignore
.htaccess
ARCHITECTURE_QUALITY_FIXES.md
AUDIT_FIXES_2026-07-24.md
CRYPTO_CURRENT_BEHAVIOR_FA.md
CURRENT_STATUS_REPORT_FA.md
Dockerfile
EXECUTIVE_SUMMARY_FA.md
INFRASTRUCTURE_USAGE_AUDIT.md
PHPSTAN_RISK_ASSESSMENT_2026-07-15.md
REVIEW_FINDINGS.md
RULES-AND-STANDARDS-fa.md
WEBHOOK_ARCHITECTURE_ASSESSMENT_2026-07-15.md
app.php
cli.php
composer.json
composer.lock
composer.phar
cron.php
dev-router.php
docker-compose.dev.yml
docker-compose.yml
dump.rdb
migrate.php
package-lock.json
package.json
phpstan-baseline.neon
phpstan-bootstrap.php
phpstan-core-honest.neon
phpstan-exclude-broken.neon
phpstan-full-run.neon
phpstan-run.neon
phpstan-stubs.php
phpstan.neon
phpstan_check.neon
phpstan_core.neon
phpstan_core_check.neon
phpstan_full.neon
phpstan_level9.neon
phpunit.architecture.xml
phpunit.chaos.xml
phpunit.contract.xml
phpunit.e2e.xml
phpunit.redis-unavailable.xml
phpunit.runtime.xml
phpunit.xml
```

---

## دور ۱۶ — ده تصمیم کاربر + قفلِ مجدد P0 کریپتو | Round 16 — 10 user decisions + P0 re-fix

**بسته‌بندی | Packaging:** Task ID 16-D (2026-09-20) — HEAD `afdf471` + ۲۸ فایل modified uncommitted + ۲ مایگریشن untracked؛ همه در بستهٔ «فایل‌های فیکس‌شده» لحاظ شدند. QA نهایی: curl (/, /login = 200؛ `/status/api` = success:true با ok_count=7/8) و جریان کامل مرورگری (لاگین کاربر → dashboard/referral/sessions → خروج POST → لاگین ادمین → users با ستون پرچم + سرستول‌های مرتب‌شو → چرخش sort → audit-trail?category=test بدون 500 → خروج ادمین POST) — همه پاس، صفر خطای کنسول.

| # | تصمیم کاربر | وضعیت | جزئیات پیاده‌سازی |
|---|---|---|---|
| 1 | پاداش شروع زیرمجموعه‌گیری ۵٬۰۰۰ + سقف روزانه ۱۰۰٬۰۰۰ | ✅ فعال + E2E | تنظیمات زنده `referral_start_bonus=5000` و کلید جدید `referral_start_bonus_daily_cap=100000`؛ سقف روزانه در `ReferralService::awardStartBonus` (شمارش تراکنش‌های امروز، fail-open، لاگ daily_cap_reached)؛ E2E: award دقیق ۵٬۰۰۰، re-verify آیدمپوتنت، بلاک با سقف، award موفق پس از آزادسازی سقف |
| 2 | اعلان‌ها فقط درون‌برنامه‌ای | 📄 مستند | تصمیم ثبت شد — هیچ کانال اعلان خارجی (ایمیل/پیامک/push) لحاظ نشده؛ فقط اعلان درون‌برنامهٔ موجود |
| 3 | کمیسیون معرفِ تأییدشده در ثبت‌نام (OAuth/ادمین) → موکول به اولین تسک تکمیل‌شده | ✅ E2E | حذف پرداخت فوری؛ ردیف pending (`source_type='signup'`، کلید یگانهٔ `referral_signup_{ref}_{user}`) + `creditPendingReferralRewardOnFirstTask` بعد از commit در `ApproveSocialTaskExecutionJob`؛ E2E: pending بدون اعتبار فوری → credit دقیق با اولین تسک → فراخوانی مجدد no-op |
| 4 | سطل‌های اعتماد ۲۰/۶۰ | 📄 مستند | آستانه‌های سطل اعتماد ۲۰/۶۰ به‌عنوان تصمیم محصول مستند شد (بدون تغییر کد) |
| 5 | ایندکس فیلتر category حسابرسی | ✅ + EXPLAIN | مایگریشن `2026_09_20_0005`: ستون VIRTUAL `audit_trail.context_category` + `idx_audit_trail_context_category` در یک ALTER اتمیک؛ `AdvancedAuditTrail::search` از ستون ایندکس‌شده می‌خواند (fallback امن به JSON در DB فاقد ستون)؛ EXPLAIN واقعی: `type=ref, key=idx_audit_trail_context_category, ref=const, Using index` |
| 6 | S25/bulkCustomSql | 📄 never-existed → skip | ویژگی در هیچ کامیت/ورژنی وجود نداشت (شواهد ۴گانه در worklog 16-C)؛ تست پین به `markTestSkipped` مستند تبدیل شد (FIX-R16C)؛ ساخت SQL خام ریسک امنیتی دارد |
| 7 | مرتب‌سازی سمت سرور ادمین (کاربران + تراکنش‌ها) | ✅ | users: whitelist `ADMIN_SORTABLE_COLUMNS` + sort/dir در کنترلر/سرویس/مدل؛ transactions: `ADMIN_SORTABLE_SQL_MAP` با ستون امن (شامل `user` روی JOIN)؛ سرستول‌های کلیک‌پذیر با aria-sort؛ ورودی خراب → پیش‌فرض بدون خطا؛ صفحه‌بندی sort/dir را حفظ می‌کند |
| 8 | خروج فقط POST + رفع باگ CSRF سایدبار ادمین | ✅ | همهٔ فرم‌های خروج POST+CSRF (کاربر، ادمین، «خروج از همه دستگاه‌ها»)؛ باگ واقعی: فرم سایدبار ادمین به `/logout` کاربر می‌رفت → `csrf_failed` → 404؛ FIX-R16B اکشن را به `/admin/logout` اصلاح کرد (صفر رخداد csrf_failed پس از فیکس) |
| 9 | ذخیرهٔ country_flag + نمایش | ✅ | مایگریشن `2026_09_20_0004 users.country_flag` + backfill؛ GeoIP آفلاین با MMDB وندورشده (`\MaxMind\Db\Reader` باندل) در `AuthSessionManager::createSession`؛ نمایش در نشست‌های کاربر و ادیت/ایندکس ادمین با fallback 🌐 |
| 10 | فلش‌های مرتب‌سازی aria-hidden | ✅ ۱۳ | ۶ آیکون جدول کاربران + ۷ آیکون جدول تراکنش‌ها داخل `aria-hidden="true"`؛ aria-sort فقط روی ستون فعال؛ جدول‌های data-sortable فلش CSS-محور بی‌متن دارند |

**P0 کریپتو (قفلِ مجدد):** مسیر دوم اعتباردهی (`fulfillCryptoDeposit`) که به درخت کاری بازگشته بود، دوباره از `PaymentDepositService` و `PaymentService` حذف شد (FIX-R16B) — تنها مسیر: `CryptoDepositService::approve()` با کلید idempotency + گیت وضعیت در یک TX (تأیید method_exists چهارگانه)؛ تست قرارداد `PaymentCryptoFulfillmentTest` بازنویسی شد؛ **S25MoneyFixesTest = 6/6 GREEN** (۱۶ assertion) + PaymentCryptoFulfillment OK. سایر شکست‌های tests/Unit (39E/55F) pre-existing و خارج از فایل‌های این راند.

**فایل‌های کلیدی دور ۱۶:** `app/Services/Shared/ReferralService.php`، `app/Jobs/Auth/ProcessRegistrationJob.php`، `app/Jobs/SocialTask/ApproveSocialTaskExecutionJob.php`، `app/Services/AntiFraud/GeoIPService.php`، `app/Services/Auth/AuthSessionManager.php`، `app/Services/Auth/SessionService.php`، `app/Services/Sentry/Audit/AdvancedAuditTrail.php`، `app/Models/User.php`، `app/Models/Transaction.php`، `app/Services/User/UserService.php`، `app/Services/Wallet/WalletQueryService.php`، `app/Services/Wallet/WalletService.php`، `app/Services/Payment/PaymentDepositService.php`، `app/Services/Payment/PaymentService.php`، `app/Controllers/Admin/UserController.php`، `app/Controllers/Admin/TransactionController.php`، `views/admin/users/index.php`، `views/admin/transactions/index.php`، `views/admin/users/edit.php`، `views/user/sessions/index.php`، `views/partials/admin/sidebar.php`، `helpers/functions.php`، `public/assets/css/shared/layout.css`، `public/assets/css/views/useraccount.css`، `database/migrations/2026_09_20_0004_users_country_flag.php`، `database/migrations/2026_09_20_0005_audit_trail_context_category.php`، `tests/Unit/Services/S25MoneyFixesTest.php`، `tests/Unit/Services/S25ServicesContentOpsSecurityPinningTest.php`، `tests/Integration/ContainerBacked/Services/PaymentCryptoFulfillmentTest.php`

---

# ROUND 17 — Multi-Agent Independent Verification + OAuth Wiring Fix / دور ۱۷: راستی‌آزمایی مستقل چندایجنتی + اتصال پاداش OAuth

> Scope: 4 parallel verification agents (financial / auth-security / views / live browser E2E) + DB rebuild after sandbox wipe + root-cause fixes. همهٔ ۱۰ تصمیم دور ۱۶ دوباره به‌صورت مستقل تأیید شدند.

## Verification results (all PASS)

| Area | Agent | Result |
|---|---|---|
| Financial core (start-bonus daily cap, P0 crypto removal, sorting whitelists) | 17-A2 | **6/6 PASS** — S25MoneyFixesTest 6/6, PaymentCryptoFulfillmentTest 4/4, php -l 11/11 |
| Auth / OAuth referral / GeoIP country_flag / audit index | 17-B | **PASS** (+2 fixes below) |
| Views / POST-logout / sort headers / flags / a11y / docs | 17-C | **9/9 PASS** — zero GET logout, zero unwrapped sort arrows, no XSS in sort params |
| Live browser E2E (user+admin, sorting proof, negative tests, downloads) | 17-D2 | **11/11 PASS** — sort asc/desc exactly reversed server-side, `evilcol;DROP` safe, status 8/8, zero console errors |

## Fixes applied in this round

| ID | File(s) | What |
|---|---|---|
| FIX-R17B | app/Services/Auth/SessionService.php | recordSession stored `'XX'` unknown-placeholder as country despite its own NULL contract — now stores NULL (🌐 shown, no wrong label) |
| FIX-R17B | storage/geoip/*.mmdb | Restored byte-identical offline GeoIP MMDB files (wiped by sandbox rebuild; source of truth = full-source zip) |
| FIX-R17F | app/Jobs/Auth/OAuthHelperTrait.php | OAuth new-user registration now reads `register_referral_code` session attribution (mirror of normal path) and passes `referral_code_used` |
| FIX-R17F | app/Jobs/Auth/ProcessRegistrationJob.php | Pending-referral branch gate now also fires for OAuth registrations (`oauth_provider` discriminator) — user decision #3 (deferred referral reward) is now actually reachable end-to-end: pending row → first real task → credited (idempotent, no double-pay, no immediate pay) |
| FIX-R17E | rebuild-runtime.sh (infra) | PHP dev server must use `dev-router.php` (plain `public/index.php` breaks multi-segment routes via SCRIPT_NAME); MariaDB paths + LD_LIBRARY_PATH after sandbox wipe |
| — | .env | Restored full 1,094B env from full-source zip (was truncated to 399B by sandbox rebuild) |

## Environment note

The sandbox was rebuilt mid-round again; the `chortk` database was recreated from the repo itself: **192/192 migrations applied, zero failures → 261 tables**, 5 seed users (4 @chortke.ir accounts password 123456 + testuser_9170), wallets restored, settings `referral_start_bonus=5000` / `referral_start_bonus_daily_cap=100000` live, migrations 0004/0005 applied+tracked. Full browser E2E re-verified after rebuild.

**Known remaining (not bugs):** H-5 real payment gateway credentials; pre-existing tests/Unit baseline failures (39E/55F — untouched files); R90 anti-farming gate intentionally not yet replicated for the OAuth path (documented future hardening).

---

# ROUND 18 — Full Test-Suite Green + OAuth Anti-Farming / دور ۱۸: سبزشدن کامل مجموعهٔ تست + گیت ضد-farming برای OAuth

> User request: «شکست‌های قدیمی تست‌ها را رفع کنید چه کد اصلی مقصر باشد چه تست؛ گیت ضد-farming را روی مسیر OAuth اعمال کنید؛ فایل‌ها را zip کنید.»
> **Result: tests/Unit از ۳۹ Error + ۵۵ Failure (۹۴ مورد) به ۰/۰ رسید — ۲۲۹۱ تست، ۸۷۳۵ assertion، فقط ۱ skip مستند (تصمیم R16/bulkCustomSql).**

## Environment root-cause fixes (first, dissolved 26+ failures)

| Fix | What |
|---|---|
| PHPRC (wrapper) | PHPUnit child processes (separate-process tests) spawned the raw `php8.4` binary without `-c` → zero extensions → 31× "DOMDocument not found" + cascade. `/home/z/tools/php` wrapper now exports `PHPRC`; parent env propagates to children. |
| FIX-R18F (core/UrlGenerator.php) | `testing` environment now canonical like production (host-header pin verifiable); `origin()` kept consistent with `effectiveBaseUrl()` so the redirect allowlist matches generated URLs. Runtime `local` behavior unchanged (dev override intact), production unchanged. |

## R90 anti-farming on OAuth path (user-requested)

- Gate extracted to shared service `app/Services/Auth/ReferralAntiFarmingGate.php` (single source of truth): per-IP daily signup cap (5) → attribution stripping, per-referrer farming threshold (10) with warn/block/ban, kill-switch `referral_commission_enabled`, fail-open.
- `OAuthHelperTrait` now applies the gate (callback request IP) + mirrors `recordSignupActivity` so the per-IP counter sees OAuth signups. Normal path delegates to the same service — behavior identical, no drift.

## 94 baseline failures → 0: decision breakdown

| Decision | Count | Highlights |
|---|---|---|
| (a) Production bugs/regressions fixed | ~30 | **Real security holes closed:** CWE-798 hardcoded HMAC secret in CreateTradeJob (+signature leaked into DB `reason`) removed; CWE-532 zero-redaction logging (passwords/tokens/OTP/cards/Authorization → recursive redaction); ticket-attachment route without AuthMiddleware; crypto-deposit shortcut bypassing RequireFeature; unbounded Redis SCAN (DoS amplifier) capped; loginDirectly missing deleted-account gate. **Financial correctness:** admin-override task payment now via escrow (partialRelease + consumeHeldBudget, idempotent, fail-closed) instead of platform minting; AccountDeletionService escrow settlement + investment-closing saga step restored; WithdrawalAdminService calls to deleted methods (notifications silently lost) migrated to the unified `notification.requested` outbox door. **Hardening:** SecretBox CHBSEC2 encrypt-then-MAC envelope; masked PAN from getUserCards; backup unlink containment; audit purge by canonical owner_id; Redis::add SETNX semantics; dispatcher dedup claim-first; Cache::add atomic. |
| (b) Stale tests repointed to current (newer-pinned) behavior | ~12 | renames/moves verified against documented prior audits (Tor rebuild rename, S24 attestation tombstone, S10 channel rename, Export/Analytics schema alignment, ctor mock alignment for TwoFactor/Lottery/Ticket). |
| (c) Documented skips | 1 | bulkCustomSql aspirational pin (pre-existing FIX-R16C). |
| (d) PHP 8.4 artifacts | ~2 | listener-array instantiation order; static-call in array callable (also a real bug). |

## Verification

- Full suite: `php vendor/bin/phpunit tests/Unit` → **OK (2291 tests, 8735 assertions, 1 skipped)**, exit 0.
- Regression trios per changed area all green; `php -l` clean on every changed file; zero manual DB writes; outbox drained after heavy test runs (status 8/8 ok).
- Live smoke: home 200, login 200, /status/api ok 8/8.

**Known remaining (not bugs):** H-5 real payment gateway credentials (code ready).

---

# دور ۱۸ (میمی اصلی) — ممیزی خط‌به‌خطِ کل کدبیس با ۱۲ ایجنت موازی | Round 18 (main) — full line-by-line audit, 12 parallel agents

**Scope:** entire codebase (~210k lines: app 793 files, core 46, views 306, routes/config/database, tests). Complete inventory with file:line evidence: **`REVIEW_ROUND18.md`**.
**Findings: 154** — P0: 8 · P1: 23 · P2: 47 · P3: 76.

## Fix wave (agents 18-M/N/O/P/Q — 86 items, ~114 files, all `php -l` clean)

| # | Fix | What |
|---|---|---|
| 1 | **R90 pay-time gate (user-ordered)** | `ReferralAntiFarmingGate::guardRewardCredit()` (kill-switch + referrer-status + farming re-check, fail-open) called in `ApproveSocialTaskExecutionJob` before `creditPendingReferralRewardOnFirstTask`; + defense-in-depth inside ReferralService (kill-switch + referrer status, stays pending for admin review). Closes the OAuth deferred-referral gap end-to-end (registration leg was already closed by FIX-R18B). |
| 2 | batchPay P0 | Admin batch-pay no longer pays `oauth_first_task` anti-fraud-held pending rows (excluded + logged). |
| 3 | task.social P0 | `FraudGuardService::checkAction('task.social')` wired into submit path (block→cancelled, challenge→no auto-approve/no escrow release); client `camera_score` bypass closed; `active_time` now server-authoritative. Silent anti-fraud engine no longer orphaned. |
| 4 | banner budget-drain P0 | `GET /banner/click/{id}`: RateLimit:30,60 + atomic `Cache::add` per-(banner,ip) dedupe before `consumeDeliveryBudget`. |
| 5 | User mass-assignment P0 | Privileged keys (`is_admin`, `role`, `status`, `level_slug`, `two_factor_*`, `email_verified_at`, …) removed from `User::$fillable`; explicit writers `createWithSystemColumns()` / `updateAdminManagedFields()` / `storeEmailVerificationToken()` / `updateTwoFactorSettings()`; all callers migrated. |
| 6 | 9 XSS sinks (P0×4 + P1×3 + P3×2) | All `javascript:`-URI hrefs → `sanitize_url()` (seo/execute, ads/show, influencer/dispute-panel, adtube/execute, admin notification_detail, custom-tasks/show, influencer dispute-detail/verifications). |
| 7 | Scheduled payments P1 | Live daily cron no longer leaks money into `locked_reserve` forever: same-tx settle (`spendLockedFunds` → `platform_revenue` + `finalizeLockedSpend`, idem key `sched_settle_*`), fail-closed on settlement error. |
| 8 | QueueWorker P1 | Per-job `timeoutSeconds` (6 long money jobs) + pcntl_alarm heartbeat (visibility/3) → no more concurrent double-execution after Redis self-heal. |
| 9 | Bulk notifications P1 | SendToAll/Segment/Admins: SETNX entry gate + `event_id` stamped through in-app + FCM outbox (dispatcher claim-dedupe engages). |
| 10 | Profit distribution P1 | Durable `IdempotencyService` claim per (trading_record, period); swallow → rethrow. |
| 11 | Database P1 | `fetch/fetchAll/fetchColumn` now honor the `isLockingRead()` replica-guard — `SELECT … FOR UPDATE` can never route to a read replica. |
| 12 | Admin controllers P1×2 | `HttpResponseException` rethrow guards (TransactionController reverse/show, AccountDeletion forceDelete/cancelDeletion) — successes no longer reported as 500/failure. |
| 13 | core Model P1×2 | belongsTo loader implemented (Transaction/Ticket/Investment/KYCVerification); `$hidden` + `toPublicArray()` serializer (User password/2FA/tokens, ApiToken) — raw fetches untouched (auth intact). |
| 14 | Ghost columns P1×2+P2 | Rating (real schema realigned), CaptchaLog (`is_success`), SystemLog filter removed, Dispute closed-status set, TicketPriority MEDIUM/CRITICAL, UserStatus locked/locked_2fa/deleted. |
| 15 | Fillable whitelists | Withdrawal (20 cols), ManualDeposit (20), ScheduledPayment (13), PaymentLog (15), ContactMessage, BulkOperation. |
| 16 | 2FA challenge loop P1 | GuestMiddleware pending-2FA branch now precedes the logged-in redirect — fraud step-up challenge reachable. |
| 17 | notification click P1 | `GET /notifications/click` (mutates + settles money) → POST + CSRF; per-user poll bulkhead (FPM pool protection). |
| 18 | API deletion P1 | `/api/v1/user/account-deletion` now requires + verifies password (parity with web). |
| 19 | Profile P1 | mobile/national_id change requires `current_password` + outbox notice to owner (masked old contact); `website` http(s)-validated. |
| 20 | Search layer | session `max_execution_time` leak closed (set+reset), module-search term restored, single-layer LIKE escaping, cache-TTL min() ceiling, user-search rate limit. |
| 21 | Core infra | DlqWorker allowed_jobs gate, logoutAll SCAN capped (FIX-S8-1 pattern), ExceptionHandler 302-before-Location, TaggedCache exact-seconds, `HTTP_X_CORRELATION_ID`, EXTR_SKIP, batched DM purge, DeepFace TLS hardened, OTP = independent `random_int` 6-digit. |
| 22 | Anti-fraud extras | milestones kill-switch + verified-user counting, referrer resolved for executor-keyed commissions (self-ref guard re-armed), override CAS on Approve/Reject admin override, reconcile terminal-failure guard + internal IP-whitelist bypass, admin double-verify threaded, fraud-role hierarchy guard + audit logs, level/referral-settings validation ranges, RoleController super-admin grant gate. |
| 23 | P2s | PII masking in search projections, KycTimeout rowCount gate, EscrowTimeout rethrow, fraud-score/task-completed idemKeys, event_id on Withdrawal/Escrow/TaskCompleted/Kyc/reminder payloads, API exception-text leaks closed, claimBoost TOCTOU, ReferralCommission paid_at, enum/DB drift. |

## Verification

- `php vendor/bin/phpunit tests/Unit` → **OK (2292 tests, 8737 assertions, 0 errors, 0 failures, 1 documented skip)** — includes 2 stale pins updated to deliberate new contracts (S18/S10 OTP-code numeric independence, AuthService anti-enumeration oracle parity) + 1 new CAS replay-rejection test.
- Baselines: S25MoneyFixes **6/6** ✅ · PaymentCryptoFulfillment **4/4** ✅. Integration: identical to pre-round baseline (21 known defects — e2e-server-down env ×12, PDO/schema ×5, dead-pinning ×5 — no regressions from this round).
- Lint sweep: **114/114** changed files `php -l` clean. One mock-compat fix: `toPublicArray()` untyped param (PHPUnit 8.5 mock generator cannot reflect union types on inherited methods).
- Full audit inventory + coverage table + remaining backlog: **`REVIEW_ROUND18.md`**.

---

# ROUND 19 — Second full parallel re-audit (10 agents) + 68 fixes / دور ۱۹: بازبینی موازی دوم کل پروژه (۱۰ ایجنت) + ۶۸ اصلاح

> User request: «با چندین ایجنت موازی کل کدها را خط‌به‌خط و صددرصدی بررسی کن، همهٔ مشکلات را کامل لیست کن، طوری که بعد از بررسی هیچ مشکل یا خطایی داخل پروژه نمونده باشد.»
> **Result: 10 review agents + 4 fix agents — 68/68 fix items applied (FIX-R19 series), full suite still green, zips rebuilt.**

## Review coverage & findings (full inventory: `REVIEW_ROUND19.md`)

| Domain | Agent | Files | Findings |
|---|---|---|---|
| tests/Unit collection & root-cause | 19-A1 | 2292 tests re-run ×2 | 0E/0F confirmed; «94 failures» snapshot = stale (closed since R18); DB integrity verified via backup compare |
| Services/Auth + Shared + Wallet + Score + Gamification | 19-A2 | 27 | 0C/0H · 5 MED · 13 LOW |
| Payment/Withdrawal/Investment/Lottery/Escrow/Ledger | 19-A3 | 26+4 | 3×P1(FES-1/2/3) + 5×P2 + 10×P3 |
| Controllers User + Api + root | 19-A4 | 63 | 0×P0/P1 · 2×P2 · 8×P3 |
| Controllers Admin (56 files, 14,868 lines) | 19-A5 | 56 | 0×P0/P1 · 2×P2 · 11×P3 |
| app/Jobs (~97 files) | 19-A6 | 62 deep + 35 scan | 1×P1 · 3×P2 · 7×P3 |
| Models + Listeners + Middleware | 19-A7 | ~140 | 0×P0/P1 · 2×P2 · 12×P3 |
| routes + config + Validators + Providers | 19-A8 | ~110 | 0×P0/P1 · 2×P2 · 14×P3 |
| views + public | 19-A9 | ~299 views | 1×P1 · 3×P2 · 6×P3 |
| R90 gate & OAuth insertion research | 19-B | — | Gate already wired (R18B signup leg + R18N pay leg); only `handleAdminOverride` gap remained |

**Totals: P0 = 0 · P1 = 2 · P2 = 13 · P3 ≈ 50.**

## Fix wave (4 parallel agents — 68 items, all `php -l` clean)

| # | Fix | What |
|---|---|---|
| 1 | **FIX-R19-A6-1 (P1)** | Email-less OAuth registrations now always insert a `social_accounts` identity row → same provider login no longer creates duplicate accounts/wallets/pending-referral rows. |
| 2 | **FIX-R19-A3-1/2 (P1)** | `FinancialEscrowService::holdInfluencerOrderFunds` / `holdVitrineFunds`: wallet `withdraw()` result now checked (throw on failure, mirroring holdCustomDealFunds) + deterministic idempotency keys `influencer|vitrine_escrow_record|hold_{id}` → concurrent duplicate escrow rows + double charges closed. |
| 3 | **FIX-R19-A3-3** | Hold transactions now stamp `escrow_id` in metadata; `findEscrowHoldTransaction` prefers exact-integer match (suffix-collision-proof) with backward-compatible fallback for legacy rows. |
| 4 | **FIX-R19-A6-4 (OAuth R90 completion)** | `ApproveSocialTaskExecutionJob::handleAdminOverride` now mirrors `handle()`'s R90 block: pre-read pending referral row → `guardRewardCredit()` → `creditPendingReferralRewardOnFirstTask()` (gated, idempotent, pending-row preserved on reject). Admin-override path can no longer strand OAuth deferred referral rewards. |
| 5 | **FIX-R19-A6-2** | `social_accounts` UNIQUE(platform, provider_id) added (dup-check = 0 rows → live ALTER + idempotent migration `2026_09_20_0006_*` + 23000/1062 translated to friendly "already linked"). |
| 6 | FIX-R19-A3-5/6/7 | `InvestmentCommandService::approveWithdrawal` FOR UPDATE + status CAS + `idempotent_replay` pre-check; `applyLoss` clamped to current balance (profit_earned can't go negative); outbox failure no longer aborts investment saga. |
| 7 | FIX-R19-A2-1..6 | DisputeService resolve CAS (status whitelist + rowCount); TwoFactorService::disable() wrapped in transaction; `referral_commission_percent` is_numeric guard; referral_tiers upsert (0-bonus allowed); WalletMutationService processPay/processTransfer positive-amount assertions + transfer idempotency-key column write (deterministic `:recv` suffix leg). |
| 8 | FIX-R19-A7-1/2 (P2) | ReferralCommissionListener + HandlePaymentCompleted: bounded outbox compensation event `referral.commission.process` (1..3 budget, replay-deduped) → transient DB failure no longer silently loses commissions. ConcurrentRequestMiddleware: owner-token locks + Lua compare-and-del + TTL 3s→15s (no more cross-request lock theft). |
| 9 | FIX-R19-A4-1/2 (P2) | API `vitrineTradeRequest` field whitelist + offer_price bounds (409 on duplicate-pending); notification click() external http(s) action_url now uses redirectExternal() (no more 500 after money mutation). |
| 10 | FIX-R19-A5-1/2 (P2) | Admin `unban()`/`unsuspend()` get role-hierarchy guard + audit logs (parity with ban/suspend); admin notification `action_url` http/https scheme whitelist. |
| 11 | FIX-R19-A8-1/2/6 (P2) | `core/Validator` url rule = scheme whitelist (one gate closes all URL fields: video_url/link/proof_url/target_url/banner); SendDirectMessage max:5000 (12MB DB-spam closed); config API secrets default `''` fail-closed (verified no test/bootstrap dependency). |
| 12 | FIX-R19-A9-1 (P1) | `views/user/influencer/dispute-panel.php` user-controlled attachment href → `sanitize_url()` (+ double-escape fix). |
| 13 | P3 batch (~45) | Middleware explicit `return $response` (CSRF/Auth/Admin), Setting::set atomic upsert, ReferralCommission status CAS + LIKE escaping (SocialAccount too), Escrow catch logging, ApiToken revoke rowCount, GoogleJwt 30s leeway, login-risk unsigned fallback removed, remember-token 'deleted' gate, referral POST routes RateLimit:15,1, /admin/health AdminPermissionGuard + RBAC mapping, test-captcha env hardened, metrics token query-fallback removed, SecurityController log whitelist+truncation, bank-card flash masking, deterministic `ct_budget_{creator}_{task}` key, float→string DECIMAL bindings, SubmitProof CAS, WithdrawalTimeout atomic dedupe, InfluencerOrderTimeout rethrow, rollback guards (RateSubmission/PlaceBet/LotteryScores), lottery winner skip-and-report, fee≤amount clamp, currency whitelist, SEO payout E-notation fix, IP wildcard exact-octet matching, admin export filters normalized, requireAdminId, 2FA TTL unify + flash order, Vitrine resolve audit, blockDevice validation, wallet JS `crypto.getRandomValues` idempotency key, e() hardening (reports/withdrawal-review), etc. |

## Verification

- `php -l` sweep: **66/66 changed files clean** (per-agent runs: 7/7, 22/22, 10/10, 27/27).
- Full suite after fixes: `php vendor/bin/phpunit tests/Unit` → **OK (2292 tests, 8737 assertions, 0 errors, 0 failures, 1 documented skip)**, exit 0.
- Regressions: PaymentCryptoFulfillment **4/4** ✅ · S25MoneyFixes included green ✅.
- Live smoke: home 200 (rendered, RTL nav intact), login 200, downloads zips 200, no PHP fatal/parse errors in logs.

**Deliberately deferred (documented backlog, not bugs left open blindly):** test-DB isolation (suite currently writes prod `chortk`; CHORTKE_TEST_DB_* hooks exist unused); `escrow_transactions` UNIQUE(order_id,order_type) migration; AdsApi raw-echo → response-layer refactor; remaining fillable narrowing (User.password / Withdrawal admin cols / Transaction+LedgerEntry) pending write-path audit; LoginRisk INCR-based counters; monthly-reward dedup via JSON_EXTRACT; CouponService/PasswordRecovery token-consumption ordering (product decision); `public/downloads/*.zip` are intentional deliverables.

---

# دور ۲۰ — بستن کامل backlog تعلیق‌شده | Round 20 — closing the entire deferred backlog

> Scope: 6 approved backlog items in 3 parallel fix agents (20-A/20-B/20-C) + orchestrator verification. **تصمیم کاربر: ایزوله‌سازی DB تست رد شد** — پروژه در فاز تست است و داده واقعی در DB وجود ندارد؛ suite عمداً روی `chortk` می‌ماند. بعد از این دور، هیچ آیتمی از backlog دور ۱۹ باقی نمانده است.

| # | Fix | What |
|---|---|---|
| 1 | **FIX-R20-A1** | `LoginRiskService::recordFailure` → اتمیک با `INCR` + کلید پنجرهٔ همراه `:w` (TTL فقط در افزایش اول + refresh لغزان + مسیر reset پنجره)؛ خواننده‌ها فرمت جدید (int خام) و ردیف‌های قدیمی امضاشده (تا پایان TTL) را می‌فهمند؛ `clearFailures` هر دو کلید را پاک می‌کند. امضای HMAC روی مقدار برای ردیف‌های جدید حذف شد (مستند: مهاجم با دسترسی نوشتن Redis از راه DEL همان بای‌پس را داشت). شاخهٔ fallback کش غیراتمیک ماند (مسیر تنزل‌یافتهٔ fail-open، مستند). |
| 2 | **FIX-R20-A2** | تشخیص تکرار پاداش ماهانهٔ معرفی از `LIKE '%…%'` شکننده به `JSON_UNQUOTE(JSON_EXTRACT(payload,'$.metadata.idempotency_key')) = ?` (ساختار واقعی payload در نقطهٔ نوشتن راستی‌آزمایی شد؛ توابع JSON روی MariaDB زنده تست شد). |
| 3 | **FIX-R20-A3** | `CouponService::redeem` — مصرف توکن یک‌بارمصرف به بعد از موفقیت `runWithRetry` منتقل شد؛ شکست commit دیگر توکن را نمی‌سوزاند (پنجرهٔ دو-ثانیه‌ای submit مضاعف با row-lock و گارد redemption بسته می‌شود). |
| 4 | **FIX-R20-A4** | `PasswordRecoveryService::resetPassword` — اول اعتبارسنجی کامل (وجود توکن/تطابق ایمیل/سیاست رمز) با پیام‌های فعلی بدون سوزاندن توکن، بعد مصرف اتمیک؛ مسابقهٔ باخته → همان خطای «توکن نامعتبر». |
| 5 | **FIX-R20-B1** | `AdsApiController` — ۱۲ نقطه به لایهٔ Response مهاجرت کرد (۹ `echo json_encode` → `$this->response->json(...)` + ۳ هدر دستی حذف)؛ گارد re-throw برای `HttpResponseException` داخل try های `validateField/previewCost` (جلوگیری از بلعیده‌شدن استثنا). دود: 6/6 CLI harness + HTTP 401/419 بدون‌احراز + **HTTP 200 JSON معتبر با نشست احرازشده**. |
| 6 | **FIX-R20-B2** | `escrow_transactions` — مهاجرت `2026_09_20_0007` با UNIQUE(order_id, order_type) (گارد information_schema، idempotent، ثبت در schema_migrations)؛ جدول خالی بود → بدون پاکسازی؛ اثبات 1062 روی DB زنده انجام و تمیز شد. توجه: UNIQUE سخت پس از بسته‌شدن escrow هم می‌ماند (یک retry گذرا یک شناسهٔ ۶ رقمی را بازنشست می‌کند — ناچیز). |
| 7 | **FIX-R20-C1** | `password` از `User::$fillable` حذف شد؛ سازندهٔ صریح‌ستونی `createWithCredentials()` اضافه شد؛ هر ۳ نقطهٔ نوشتن رمز مهاجرت یافتند (ثبت‌نام/OAuth از `UserService::register`، rehash بازیابی → `changePassword()` + ابطال کوکی remember، ریست ادمین → `changePassword()`)؛ `UserService::update` دفاعی مسیر password را می‌فرستد. |
| 8 | **FIX-R20-C2** | `Withdrawal` — ۵ ستون ادمینی از fillable خارج شد؛ نویسندهٔ اختصاصی `applyAdminDecision()` با وایت‌لیست (جریان‌های ادمین از قبل صریح بودند — صفر نقطه برای مهاجرت)؛ `createWithdrawal` وضعیت `pending` را صریح مهر می‌زند. |
| 9 | **FIX-R20-C3** | وایت‌لیست fillable برای `Transaction` (۲۱ ستون) و `LedgerEntry` (۹ ستون) — اتحاد واقعی ستون‌های نوشته‌شدهٔ امروز، راستی‌آزمایی‌شده با اسکیمای زنده؛ هیچ payload نویسنده‌ای ستون خارج وایت‌لیست ندارد (صفر drop خاموش). |

## Verification

- `php -l`: **12/12 green** (11 changed + 1 new migration).
- Full suite: `php vendor/bin/phpunit tests/Unit` → **OK (2292 tests, 8737 assertions, 0 errors, 0 failures, 1 documented skip)** — identical to Round-19 baseline.
- Regressions: S25MoneyFixes **6/6** ✅ · PaymentCryptoFulfillment **4/4** ✅.
- Browser golden path: home render → failed login → math-captcha escalation (**live exercise of new INCR counter, no fatal**) → correct login → dashboard with real data (wallet/XP/tasks) → authenticated `GET /chortke/ads/api/type-info` → **HTTP 200 `application/json` valid payload**.
- DB integrity: `escrow_transactions` starts and ends EMPTY; new UNIQUE index verified via SHOW INDEX + 1062 duplicate-proof.

**Notes for next rounds (non-blocking):** migration 0006 (.sql, R19) never recorded in `schema_migrations` (bookkeeping-only; index exists live); `TwoFactorService` `force_2fa_regen` ghost write is dead code (pre-existing, flagged); non-Redis cache fallback counters remain non-atomic (degraded fail-open path, documented).

---

# دور ۲۲ — موج حذف فایل‌های مرده + سیم‌کشی رویدادها + نظافت ابزار | Round 22 — dead-file deletion wave + event wiring + tool cleanup

> Scope: اجرای ۴ تصمیم مصوب کاربر بعد از اسکن READ-ONLY دور ۲۱ (۳ ایجنت موازی 22-A/22-B/22-C + تکمیل FIX-R22-B7 توسط ارکستراتور). هیچ رفتار مالی/امنیتی تغییر نکرد؛ کش جست‌وجو و read-model اکنون واقعاً به‌روز می‌شوند.

| # | Fix | What |
|---|---|---|
| 1 | **22-A (حذف)** | ۱۶ مسیر مرده حذف شد (~۱,۲۸۶ خط): MaintenanceController (پنل ادمین از قبل toggle دارد: SystemSettingController + SettingsCatalog، views/admin/settings/index.php:104)، SystemController (استاب جانشین‌شده)، DatabaseService (جانشین: BackupService)، ReferralManagementService (صفر فراخوان)، LogNotificationService، Enums TransactionStatus/UserStatus (جانشین: STATUS_* ثابت‌ها)، CryptoExplorerAdapter، CryptoIntentValidator، CreateCustomTaskRequest، config/constants.php + config/outbox.php (draft سیم‌کشی‌نشده — اینتروال واقعی در worker بیرونی)، **scripts/dev-router.php + tools/dev-router.php (کپی‌های بدون گارد FIX-S8-1 — ریسک امنیتی)**، dump.rdb، tools/__pycache__. ویرایش pin تست‌ها: S24 SCOPE (۳ مدخل)، EnumsTest (pin عدم‌وجود)، AllControllersStructuralTest، phpstan_core_check.neon، public/install/index.php (پریش به dev-router گارددار)، docblockهای کهنه. اثبات نهایی: صفر ارجاع به هر ۱۵ basename. |
| 2 | **FIX-R22-B1 (D1 باگ واقعی)** | `CacheInvalidateListener` روی `cache.invalidate` ثبت شد (AppServiceProvider:373) — ۱۱ تولیدکننده (moderation ×5، EscrowTimeoutJob، VitrineListingExpiryJob، lottery و...) تا دیوار بی‌شنونده بودند و کش‌ها بی‌صدا کهنه می‌ماندند. قرارداد payload راستی‌آزمایی شد؛ صفر تغییر در تولیدکننده‌ها. |
| 3 | **FIX-R22-B2 (D2)** | `AuditCircuitBreakerState` روی `circuit_breaker.opened/closed` ثبت شد (CircuitBreaker.php:144/205) — تغییر وضعیت breaker دیگر بی‌ردیپ نیست. |
| 4 | **FIX-R22-B3 (D3 — انحراف مستند)** | `content.revenue_paid`: نقطهٔ پرداخت واقعی (`ContentService::payRevenue:550`) **از قبل** رویداد جانشین `content.revenue.payment_recorded` را fire می‌کند و هندلر قدیمی به همان مسیر notify می‌رفت → dispatch موازی = **اعلان مضاعف**. طبق شاخهٔ «بدون نقطهٔ fire منطقی»: ثبت + متد قدیمی حذف (tombstone) و با تست منفی قفل شد. |
| 5 | **FIX-R22-B4 (D5)** | `FeatureFlagService::dispatchEvent` از فراخوانی مستقیم `new LogFeatureFlagChange()->handle()` به `$eventDispatcher->dispatch()` استاندارد مسیر شد (تنظیم config_reload و لاگ خطا حفظ شد). |
| 6 | **FIX-R22-B5 (D6+D4)** | ۱۱ ثابت خوابیدهٔ EventRegistry حذف (۰ تولیدکننده + ۰ شنونده — با grep نام ثابت و مقدار رشته‌ای)؛ **تصحیح دادهٔ r21-c:** سه رویداد registry عملاً صفر تولیدکنندهٔ درون‌کد دارند (dispatchها در FIX-DEAD-EVENT قبلاً حذف شده بود — r21-c کامنت‌ها را تولیدکننده شمرده بود)؛ با این حال `AuditRegistryEvent` (لاگ سبک) برای پوشش بازپخش outbox تاریخی ثبت شد. |
| 7 | **FIX-R22-B6** | تست جدید `EventWiringR22Test` (۵ تست/۳۳ assertion — قفل منبع ثبت‌ها + رفتار resolve) + `DeadFileWiringRuntimeTest` برای D1 پاس می‌شود و تست circuit breaker گرفت. |
| 8 | **FIX-R22-B7 (کشف بعدی ارکستراتور)** | تست قفل‌کنندهٔ Integration دو سیم‌کشی دیگرِ «مستند ولی اجرا‌نشده» را لو داد: `InvalidateSearchCacheListener` (کلاسش **هرگز ساخته نشده بود**) روی ۵ نام search-bust + `influencer.profile_updated` → `SearchProjectionListener`. رفع: کلاس `app/Listeners/InvalidateSearchCacheListener.php` ساخته شد (invalidateModuleSearch ماژول + invalidateSearch کلی از CacheInvalidationService موجود)، ثبت با الگوی closure تزریق‌نام bootstrap، `'influencer.profile_updated'` به `$projectionSyncEvents` اضافه شد (بازوی match از قبل آماده بود)، و pin کهنهٔ گارد حذف S18.5 (که با قرارداد جدیدتر S20 تناقض داشت) با سند FIX-S33B آپدیت شد + expectOutputRegex جاافتادهٔ تست منفی بسته شد. |
| 9 | **22-C (نظافت ابزار)** | phpstan neons: ۱۱ → **۳** (phpstan.neon + baseline + phpstan_full.neon که composer analyze مصرف می‌کند) — ۸ wrapper/superseded حذف. phpunit xmls: ۷ → ۷ (همگی purpose-built و ارجاع‌دار؛ chaos/e2e به‌عنوان تنها entry-point تست‌های موجود نگه داشته شدند — تصمیم آینده با کارفرما). Docker/composer/env: همگی ارجاع‌دار، صفر حذف. راستی: phpunit 8.5.52 + phpstan 1.12.33 + هر دو کانفیگ kept parse شدند. |

## Verification

- `php -l`: همهٔ فایل‌های تغییر/ساخته سبز.
- **Full suite: 2297 tests / 8752 assertions / 0 errors / 0 failures / 1 documented skip** (+۵ تست جدید نسبت به دور ۲۰).
- Integration قفل سیم‌کشی: **DeadFileWiringRuntimeTest 5/5 سبز** (قبلاً ۱E+2F انتظار-شکست) • EventWiringR22Test 5/5.
- پایه‌ها: S25MoneyFixes **6/6** ✅ · PaymentCryptoFulfillment **4/4** ✅.
- Smoke: home/login/php همه 200، صفر fatal در لاگ.

**یادداشت برای دور بعد:** `tools/verify_fix8e.php` (وریفایر یک‌بارمصرف FIX-8E) به سرویس حذف‌شده ارجاع دارد و خودش مرده است — خارج از لیست مصوب این دور بود و حذف نشد؛ `phpunit.chaos.xml`/`phpunit.e2e.xml` تنها entry-point تست‌های Chaos/E2E هستند (نگه داشته شدند — در صورت بازنشستگی آن suiteها حذف شوند).

---

# دور ۲۴ — ممیزی نماها + یکدست‌سازی بر پالت مصوب بایننس | Round 24 — views audit & unification on approved Binance palette

> Scope: اجرای نتایج ممیزی READ-ONLY دور ۲۳ (۵ ایجنت موازی؛ ۳۰۶ نما / ~۴۳هزار خط → ۸×P1 + ~۴۶×P2 + ~۱۳۹×P3) در سه موج 24-b (P1) و 24-c (P2) و 24-d (یکدست‌سازی)، روی زبان طراحی مصوب کاربر (پالت بایننس #FCD535/#0B0E11/#EAECEF — نمونه‌های قابل تأیید: public/design-preview/index.html + email.html). هیچ قرارداد سرویس/مالی تغییر نکرد؛ متن و متغیرهای ایمیل‌ها byte-identical ماند.

| # | Fix | What |
|---|---|---|
| 1 | **24-b — F1: بازسازی کامل ایمیل‌ها (P1×۱۲ قالب)** | views/emails/ روی اسکلت مصوب email.html بازنویسی شد: _header.php (هدر مشکی #0B0E11 + لوگوی طلایی #FCD535 + چیپ تاریخ جلالی + نوار ۴px طلایی) و _footer.php (خط قرمز امنیتی #F6465D + لینک‌های طلایی + کپی‌رایت) به‌عنوان partial، و ۱۰ قالب بدنه به‌صورت table-based با ۱۰۰٪ استایل inline و dir=rtl (کارت مبلغ، جدول جزئیات، CTA طلایی، کدباکس OTP مشکی/طلایی). TEXT/منطق/متغیرها دست‌نخورده؛ پلوم $headerColor (ناقل injection) با هدر قدیمی حذف شد. اثبات: ۰ `class="` در کل views/emails/ (صفر کلاس تعریف‌نشده). |
| 2 | **24-b — F2: oauth-confirm** | layouts.user → layouts.auth (پشت GuestMiddleware لِی‌اوت کاربر لود نمی‌شود). |
| 3 | **24-b — F3: فیلتر تاریخ audit-trail** | از/to بی‌اثر → date_from/date_to هم‌نام با AuditTrailController:45-46/:161-166؛ خروجی CSV با http_build_query($_GET) خودکار وارث نام‌های جدید شد. |
| 4 | **24-b — F4: force-delete تأیید** | account-deletion/pending.php → data-confirm استاندارد پنل (inlineactions.js) با هشدار «برگشت‌ناپذیر». |
| 5 | **24-b — F5: اکشن‌های ۴۰۴ جدول کاربران** | مسیر واقعی /admin/users/{id}/(edit\|ban\|unban\|suspend\|unsuspend) — URLهای معکوس اصلاح شد: users/index ×5 + withdrawals/review:71 + admin/dashboard:379 (هم‌ریشه). اثبات زنده: صفر لینک سبک قدیم در DOM /admin/users. |
| 6 | **24-b — F6: صداقت دادهٔ نمونهٔ داشبورد** | بج «داده نمونه» روی هیرو لاتاری (وقتی !$lhHasData) و کارت تسک‌های پیشنهادی ($taskSamples) — نشانه‌گذاری صادقانهٔ داده‌های نمایشی. |
| 7 | **24-b — F7: catch جعلی claim-boost** | .catch داشبورد اکنون پیام «خطا در فعال‌سازی شتاب‌دهنده» می‌دهد نه موفقیت. |
| 8 | **24-b — F8: صفحه‌بندی گزارش باگ‌ها** | bug-reports/index روی partials/pagination.php + BugReportController totalPages = ceil(total/15) با TicketService::countBugReports() (COUNT(*) برای هر دو شاخهٔ جدول). |
| 9 | **24-c — F1..F14 (۱۴×P2)** | (۱) نشتی CSRF در GET حذف (export ×4 فرم — اثبات زنده: 0 توکن در 4 GET form)؛ (۲) تیکر فیک trades حذف + `>` مودال؛ (۳) سلکت‌های tickets/index حالا $filters را می‌خوانند (اثبات زنده: status=open&priority=high → selectها همان)؛ (۴) صفحه‌بندی پنجره‌دار مشترک: capهای min(,10)/(,20) حذف و ۱۱ مصرف‌کننده روی partial ±۳+اول/آخر با حفظ GET همگرا شدند + حلقه‌های بی‌کران notifications/tickets/seo-history پنجرهٔ ±۲ گرفتند؛ (۵) messages: دکمهٔ مردهٔ «آمار» و جستجوی بی‌نام حذف، حذف پیام/بن report-detail → data-confirm؛ (۶) ads/show: ۴ تاریخ میلادی → to_jalali + تأیید/رد مدرک + حذف هینت dev؛ (۷) kyc/index: <main> تودرتو → تک‌main؛ (۸) lottery: ادعای جعلی «S2S/۲۵٪» و alert جعلی حذف → کپی صادقانهٔ مکانیک بوست (اتصال به endpoint ثبت-فقط عمداً نشد)؛ (۹) analytics/dashboard: ~۳۰ دسترسی $data[...] گارد شد؛ (۱۰) partial جدید views/partials/empty-state.php ($icon/$title/$text/$cta ??-دار + unset) در fraud/reports، fraud/user-scores ×۲+گارد سوم (events)، coupons/redemptions، risk-policies (+گارد و جدول استاندارد)، social-tasks/dashboard؛ (۱۱) stylesheet اشتباه dashboard → userearn.css؛ (۱۲) «بلاک‌لیست» مرده و دکمه‌های تزئینی 📎/😊 حذف؛ (۱۳) help: ۱۰ متای جعلی حذف؛ errors/503 با اسکلت maintenance بازنویسی (کرون‌جاب جعلی حذف)؛ (۱۴) layouts/admin $flashWarning واقعی + nonce گست csp_nonce() + نشان باگ‌های سایدبار. |
| 10 | **24-d — U1..U8 (یکدست‌سازی)** | (U1) بلوک ~۱۱۰ خطی FIX-X109 → views/partials/reward-video-popup.php با قرارداد $rv* و include در ۴ نما (tickets/vitrine/social-tasks/withdrawal) byte-identical — اثبات زنده در DOM /tickets (wrap+modal رندر)؛ (U2) فونت وزیرمتن woff2 (۴ وزن 400/500/700/800، ~۵۰KB) در public/assets/fonts + @font-face در tokens.css + preload در ۴ لایوت — اثبات زنده: document.fonts.check=true در گست و پنل؛ (U3) سوی میلادی→جلالی ~۲۰ نقطه (error-details ×3، cache، cron fa_digits→fa_number ×4، vitrine ×7، social-tasks، referral) — ورودی‌های date بومی عمداً میلادی؛ (U4) پنجره‌سازی activity + دو حلقهٔ vitrine (±۲ + اول/آخر + fa_number + حفظ GET)؛ (U5) guest.php → اسلات‌های $styles/$scripts با BC fallback؛ settings/security → _settings-nav؛ (U6) title صفحات خطا با e()، حذف $exact مرده و use بی‌استفاده، auth ?v= با config('app.version')، navbar متغیرهای توکن، mb_strtoupper ×3؛ (U7) استایل inline صف خالی → کلاس‌های pg-empty-state__* در tokens.css. |

## Verification (Task 24-e)

- `php -l`: صفر خطا روی ۲۲+۲۹+۳۴ فایل ویرایشی موج‌ها و sweep وریفایر (views/emails/ + views/partials/ + views/layouts/ + ۵۱ نمای پُرریسک) — ALL CLEAN.
- **Full suite: 2297 tests / 8752 assertions / 0 errors / 0 failures / 1 documented skip** — دقیقاً روی baseline دور ۲۲.
- پایه‌های پولی: S25MoneyFixes **6/6** ✅ · PaymentCryptoFulfillment **4/4** ✅ (مسیر: tests/Integration/ContainerBacked/Services — در tests/Unit یافت نمی‌شود).
- رندر ایمیل (اثبات V4): مسیر render زنده به‌دلیل نیاز به boot کانتینر/DB رد شد → اثبات grep: هر ۱۰ قالب بدنه `_header`+`_footer` دارند، همه ۱۲ فایل دارای استایل inline و نشان‌های طلایی (#FCD535/#F0B90B)، ۰ `class="`؛ ارجاع متقابل partialها فقط کامنت است (چرخهٔ include وجود ندارد).
- Browser smoke (Next:3000 → PHP:3001، بدون fatal جدید؛ dev.log از قبل از smoke تغییری نکرد): / ✅ guest layout + Vazirmatn load شد · /login ✅ (کپچای ریسبased فقط با ریسک بالا ظاهر می‌شود — LoginRiskService::getCaptchaType؛ رفتار از قبل موجود، نه رگرسیون راند ۲۴) · لاگین کاربر ✅ → /dashboard ✅ (Vazirmatn فعال، ۷ بج «داده نمونه» = F6) · /wallet ✅ · /tickets ✅ (markup popup partial موجود) · ادمین ✅ → /admin/dashboard ✅ · /admin/users ✅ (۱۳ لینک، صفر سبک قدیم 404) · /admin/tickets?status=open&priority=high ✅ (سلکت‌ها state واقعی) · /admin/export ✅ (4 GET form، 0 CSRF) · /design-preview/index.html ✅ (بدون خطای کنسول). اسکرین‌شات‌ها: /tmp/r24-*.png.
- تست‌های هدف موج‌ها (هر سه موج سبز): 24-b → 413/1380 · 24-c → 348/820 · 24-d → 348/839.

**یادداشت برای دور بعد (deferred):** همگرایی messages → bx-* (U8)؛ ۳ کپی باقی‌ماندهٔ popup در kyc/manual-deposit/disputes؛ pager تاریخ‌محور social-tasks/history نیازمند تغییر کنترلر (count===20)؛ تصمیم تک‌مسیره‌سازی 503/maintenance (مسیر سرو 503 در core یافت نشد)؛ باقی‌ماندهٔ جلالی admin features/rating-reviews؛ جدول eventsfraud/user-scores (گارد شد، partial نشد).

---

# دور ۲۵ — اقلام تعویق‌شده + بازسازی محیط | Round 25 — deferred items + environment rebuild

> Scope: سه قلم تعویق‌شدهٔ دور ۲۴ + بازسازی کامل stack اجرایی پس از پاک‌شدن سندباکس (PHP/MariaDB/Redis/.env باز ساخته شد؛ ۱۹۴/۱۹۴ مایگریشن + seeds). Commit 6f4d982.

| # | Fix | What |
|---|---|---|
| 1 | **25-a — همگرایی messages → bx-*** | ۴ فایل views/admin/messages روی واژگان bx-* همگرا شدند؛ دکمهٔ «آمار» بازگردانده شد (روت /admin/messages/stats زنده بود — حذف R24-c بیش‌ازحدّ تهاجمی بود)؛ tailwind-lite حذف. |
| 2 | **25-b — همگرایی کپی پاپ‌آپ‌ها** | کپی‌های popup در kyc/manual-deposit/disputes → shared partial (reward-video-popup) — ۷/۷ میزبان؛ متغیر قرارداد جدید $rvOpenDelayMs (dep/dispute=1000، بقیه 1200)؛ اثبات byte-equivalence با python diff. |
| 3 | **25-c — صفحه‌بندی واقعی social-tasks/history** | SocialTaskService::countExecutorHistory (COUNT با JOIN parity) + کنترلر total/totalPages/page + shared partial؛ هیوریستیک count===20 حذف شد. |

---

# دور ۲۶ — سویپ راستی‌آزمایی همهٔ نماها | Round 26 — full views re-verification sweep

> Scope: ۵ ممیز READ-ONLY موازی روی هر ۳۰۶ نما (r26-a..e) برای راستی‌آزمایی موج R24/R25 و شکار رگرسیون. Commit c911469.

- **حکم: ۴۱/۴۱ فیکس سالم لند شده؛ ۰ P0/P1.** لینت ۳۰۶ فایل = صفر خطا.
- FIX-R26 (میکروفیکس‌های خودِ سویپ): (۱) partial empty-state اکنون خودش $title را backup/restore می‌کند (ریشه‌ای — ۵ میزبانِ بدون قرارداد دستی امن شدند)؛ (۲) cap بق‌ماندهٔ custom-tasks/disputes:96 حذف → partial مشترک؛ (۳) pager بی‌کران custom-tasks/reports → partial؛ (۴) vitrine escrow_deadline → to_jalali؛ (۵) chmod 644.
- فهرست باقی‌ماندهٔ P2/P3 برای تصمیم کاربر ثبت شد (→ همان «لیست کوچیک» دور ۲۷).

---

# دور ۲۷ — اجرای «لیست کوچک» مصوب کاربر | Round 27 — the user-approved tail, closed

> Scope: ۲۵ فیکس در ۴ ایجنت موازی با scope انحصاری (r27-a..d). هیچ قرارداد سرویس/مالی تغییر نکرد. ۴۰ فایل modified + ۱ فایل جدید.

| ایجنت | فیکس‌ها |
|---|---|
| **27-a (admin-ops)** | ① database-health: گارد `?? []` روی هر دو count ② cron: کل منطق اپ (Scheduler/Kernel/Cache/$intervalLabel/$jobDesc) از ویو → CronController::index (آرایهٔ آمادهٔ $jobs؛ کامنت X130 منتقل؛ ویو فقط رندر، ۱۹۰→۱۰۸ خط) ③ runCron پشت Swal confirm (cronindex.js با الگوی deposits.js + متن فارسی مصوب) ④ backups cleanup → data-confirm هم‌فرمت verify ⑤ manual-deposit: کپی دروغین «فوراً شارژ» → «پس از تأیید ادمین، موجودی کیف پول شما شارژ شود» ($rv* قرارداد سالم) ⑥ users/index jdate→to_jalali ×2 ⑦ seo-ad تاریخ substr→to_jalali ⑧ features date()→to_jalali ×2 ⑨ transactions jdate→to_jalali ⑩ social-accounts: $total/$totalPages ?? + empty-state با آیدیوم fraud/reports |
| **27-b (admin-pagers)** | ⑤ pager همگرا روی partial مشترک: referral/index (حلقهٔ بی‌کران + ?? → closure با حفظ ۴ فیلتر)، vitrine/index، levels/user-levels (cap 20)، ads/index (cap 20)، kyc/index (cap 10) ⑥ partials/pagination.php: همهٔ اعداد از fa_number + ۲ خط قرارداد در docblock ($pageUrl callable خام چاپ می‌شود؛ اعداد fa_number داخلی). هارنس رفتاری ۲۳/۲۳ PASS |
| **27-c (social-family)** | ⑦ redirect()-in-view ×۳ (show/execution-show/user-trust) حذف — کشف: کنترلرها از قبل گارد+فلش داشتند (کد مرده)؛ گارد userTrust بالای ۳ کوئری hoist و findById تکراری ادغام شد ⑧ تاریخ‌های جلالی ×۹ در admin/social-tasks ⑨ format_time → بازنویسی تک‌منبعی جلالی (numeric/string→to_jalali 'Y/m/d H:i'، خالی→«—»، تجزیه‌ناپذیر→passthrough) — ۷ call-site پیام‌ها (کاربر+ادمین) یک‌جا درست شد ⑩ h()→e() در settings general ×9/privacy ×3 (h() اثباتاً alias literal است) ⑪ تک‌مسیره‌سازی 503/maintenance: partial جدید views/errors/_service-unavailable.php + دو wrapper نازک — اثبات رندر: diff فرو‌ریز‌شده = VISUALLY IDENTICAL؛ هر دو middleware دست‌نخورده |
| **27-d (CSS)** | ⑫ همگرایی سطح-تعریف فامیل‌های fin-*/sup-*/acc-* روی توکن‌های بایننس مصوب (userfinance/useraccount/usersupport + strays در shared/layout.css و userreferral و userbankcardsform): bg #0A0D13→#0B0E11، surface→#1E2329، up #1ED9A8→#02C076 (+rgbaها)، متن #EAECEF، dim #848E9C، تم روشن → #F8FAFC/#FFF/#1E293B/#64878B؛ طلایی/قرمز/آبی/بنفش حفظ؛ قوانین مرده با اثبات grep حذف؛ markup دست‌نخورده (به‌عمد — ریسک صفر) ⑬ ارقام پیجر fa_number در notifications/tickets/seo-history |

## Verification (Round 27)

- `php -l` روی هر ۴۱ فایل PHP تغییرکرده = صفر خطا (+ node syntax check روی cronindex.js).
- **Full suite: 2297 tests / 8752 assertions / 0 errors / 0 failures / 1 documented skip** — دقیقاً روی baseline.
- format_time CLI-proof: `۱۴۰۵/۰۶/۳۰ ۱۰:۵۳` برای timestamp و رشتهٔ datetime؛ «—» و passthrough درست.
- هارنس صفحه‌بندی r27-b: ۲۳/۲۳ (پنجره ±۲+اول/آخر+…، صفحات ۹/۱۷ در totalPages=25 حاضر = مرگ cap، حفظ فیلترها، امنیت RAW-echo با http_build_query).
- Browser QA (agent-browser): /admin/cron ✅ («۶۳ جاب از رجیستری واقعی» + Swal confirm دیده‌شد) · /admin/database-health · /admin/social-accounts · /admin/messages/reports · /admin/social-tasks · /admin/referral · /admin/kyc · /admin/levels/history · /admin/features · /admin/transactions · /admin/backups · /admin/ads · /admin/vitrine — همگی بدون fatal/warning · redirectهای null-entity ×۳ → لیست‌ها ✅ · سمت کاربر /wallet /tickets /notifications /settings/general /profile ✅ · همگرایی CSS کیف پول در هر دو تم با اسکرین‌شات تأیید شد · نکته: 403 کاربر admin روی /admin/cron از قبل RBAC بوده (middleware، ارتباطی به این راند ندارد).

**باقی‌ماندهٔ مستند برای راندهای بعد (نیازمند تصمیم/موج بعد):** userearn.css و userinvestment.css هنوز مقادیر کهن (موج دوم CSS)؛ pagerهای دست‌ساز ادمین (bug-reports، investment ×2، content ×2، social-tasks trust/executions، fraud ×2، banners) و ±پنجره‌های inline (crypto-deposits، bank-cards، manual-deposits، users) → کاندیدای همگرایی؛ بهداشت unset $__pg* در partial؛ دنبالهٔ P3 لایهٔ پایه (~۱۹ مورد r26-a §4)؛ tasks/feed و prediction/show (sweep-only)؛ alert() ×۱۲ و ماسک PAN (تصمیم محصولی).

---

# دور ۲۸ — باقی‌مانده‌های مصوب: موج دوم CSS + همگرایی کامل pagerها + دنبالهٔ لایهٔ پایه | Round 28 — CSS wave 2, full pager convergence, foundation tail

- **28-a CSS wave 2:** `userearn.css` + `userinvestment.css` روی پالت canonical بایننس نشستند (bg #0B0E11، surface #1E2329، متن #EAECEF/#848E9C، سبز #02C076، قرمز #F6465D، رامپ روشن slate)؛ `#F0B90B→#FCD535` (اکسنت عمومی برند — هیچ برندینگ BNB وجود نداشت)؛ گرادیان Instagram دست‌نخورده؛ همهٔ rgbaها با همان آلفا بازمحاسبه؛ توازن آکولاد و grep-proof صفر مقدار قدیمی.
- **28-b pagerها گروه A:** users (±۳)، bank-cards (کشف: pager در production مرده بود — کنترلر فقط $cards می‌دهد)، crypto-deposits، manual-deposits (±۲)، investment index/trades/withdrawals → partial مشترک. **بهداشت partial:** unset($__pg*, $page, $currentPage, $pageUrl) بعد از رندر → include چندگانه در یک ویو امن شد. هارنس رفتاری → **۵۶/۵۶ PASS** (تست واقعی double-include + امضاهای جدید).
- **28-c pagerها گروه B:** social-tasks index/trust/executions (دو pager دکمه‌ای هم)، banners، fraud reports/logs، social-accounts، content index/revenues، bug-reports → partial مشترک؛ کلوژر $pageUrl برای معنای URL دقیق هر کنترلر (array_filter و پایهٔ url() عیناً حفظ شد)، fallback $_GET برای page-only. Selfcheck رفتاری ۲۱/۲۱.
- **28-d دنبالهٔ لایهٔ پایه (r26-a §4):** asset_ver یکدست ×۱۴ در admin.php؛ ‎?v=‎ روی CSSهای vendor احراز؛ پیش‌فرض site_name یکدست «چرتکه»؛ BASE_URL با json_encode در guest؛ mutation سشن حذف (remove() مرده بود — بدون setter در کل کد)؛ env() → config('mail.driver') در سایدبار ادمین؛ ۶ واریانت badge → یک قرارداد؛ ناوبار کاربر: شمارنده fa_number + alt فارسی + استخراج CSS به `user-navbar.css`؛ li خالی سایدبار حذف؛ کامنت‌های کهنهٔ sentry/status اصلاح؛ feature-disabled: e() + عنوان قراردادی (کد ۵۰۳ عمداً حفظ — RequireFeature:91)؛ **about: آمار واقعی کاربران از DashboardStatsService** (جای «۵۰,۰۰۰+» جعلی، با fallback)؛ contact: tel: مشروط به وجود شماره؛ show.php: گارد $page + کامنت تصمیم امنیتی e(content)؛ **oauth-confirm: minlength=12 = سیاست واقعی PasswordPolicy** + جفت for/id؛ ایمیل‌ها: verification ??-دار، «۱ ساعت» فارسی، wallet_url ?? url('/wallet') در lottery/withdrawal، گارد ($currency ?? '').
- **راستی‌آزمایی:** php -l همهٔ ۲۰+ فایل PHP = صفر خطا؛ سوئیت کامل **۲۲۹۷/۸۷۵۲/0E/0F/1-skip = بیس‌لاین دقیق**؛ هارنس pager ALL GREEN؛ QA مرورگر: ۱۶ صفحهٔ ادمین تبدیل‌شده صفر خطا (pager در totalPages=1 سلف‌گارد) + رندر زندهٔ pager با ۲۹ ردیف موقت (صفحهٔ ۲ + ارقام فارسی + پاک‌سازی)؛ earn + investment در هر دو تم اسکرین‌شات-وریفای؛ about آمار واقعی «۴+ کاربر فعال»؛ contact سالم.

---

# دور ۲۹ — موارد مصوب خارج از مصوبهٔ R28 + یافته‌های حین بررسی | Round 29 — approved out-of-scope items + in-review findings

- **حذف فایل مرده (یافتهٔ جدید، مصوب «رفع در حین بررسی»):** `userinvestmentprofithistory.css` (۷۸ خط) کاملاً یتیم بود — هیچ ویو/JS آن را load نمی‌کند و صفر کلاس `ph-*` آن در views/js مصرف می‌شود (رد پایگاه صفحهٔ قدیمی مستقل profit-history که حالا shim ۴خطی به hub یکپارچه است). با دو مدرک grep مستقل حذف شد.
- **موج نهایی هم‌راستاسازی CSS (مصوب):** fin/acc/sup + `shared/layout.css` — ۵۲ hex + ۸۰ rgba بازمحاسبه: `#F0B90B→#FCD535` ×۳۶ (اکسنت عمومی برند؛ هیچ برندینگ کوین)، `#1A1304→#0B0E11` ×۱۰ (همه `color:` جوهر-روی-طلایی)، `#0BAF83→#02C076` ×۳، `#B91C33→#F6465D` ×۳. دست‌نخورده: `#041711` ×۳ (جوهر دکمه سبز — سابقهٔ 27-d)، `#7A6212` ×۳ (لنگر رامپ طلایی)، `#34F5B6`/`#ff6b7b`.
- **یافتهٔ حین بررسی #۲ (رفع شد):** `tokens.css:36` هنوز `--brand-gold: #F0B90B` می‌داد → هر ۷ fallback تازه‌همگرای layout.css عملاً طلای قدیمی رندر می‌کردند. توکن مرجع → `#FCD535` + خانوادهٔ rgba آن در tokens.css؛ و `wizard.css` (۱۱ hex + ۱۱ rgba از همان خانواده: `--wiz-primary`، ads tips/selected/check-indicator) هم‌تراز شد. `--brand-gold-deep #C99D0B` به‌عنوان لنگر رامپ حفظ شد.
- **pager استایل‌دار inv-\* (مصوب):** pager بخش سود در `user/investment/index.php` → partial مشترک (کلوژر page-only با پایهٔ `url('/investment/profit-history')` — عین معنای URL قدیم؛ route فعلی shim است و `section` عمداً لو نمی‌رود)؛ سکشن مردهٔ CSS `.inv-pagination/.inv-page` از `userinvestment.css` حذف (مدرک grep؛ توازن آکولاد ۲۸۲→۲۷۹ دقیقاً منهای ۳ rule).
- **تغییرات رفتاری فیلترها (مصوب):** (۱) banners — pager حالا فیلترهای GET (`banner_type/placement/is_active/category/status/search`) را با همان نرمال‌سازی سخت‌گیرانهٔ کنترلر حمل می‌کند (نکتهٔ بحرانی: `is_active='0'` با array_filter پیش‌فرض می‌افتاد — کال‌بک strict حفظ شد و در هارنس پین شد)؛ (۲) fraud/reports — در نبودِ status، لینک‌ها دوباره `status=pending` صریح می‌نویسند (ظاهر URL قدیمی؛ statusهای صریح حفظ، garbage→pending = همان اعمال کنترلر)؛ (۳) bug-reports — کشف: کد کامیت‌شدهٔ R28-c از قبل fallback $_GET داشت (رفتار مصوب موجود بود) — فقط کامنت کهنه اصلاح شد.
- **هارنس‌ها:** `28c-selfcheck` با ۳ انتظار رفتاری جدید + case `is_active='0'` + case inv → **۲۹/۲۹ PASS**؛ `r27b-pager-harness` → **۵۷/۵۷ PASS**.
- **راستی‌آزمایی:** php -l همه = صفر؛ سوئیت کامل **۲۲۹۷/۸۷۵۲/0E/0F/1-skip = بیس‌لاین دقیق**؛ QA مرورگر: `/investment` + `/investment/profit-history` (shim) + `/wallet` + `/tickets` + `/profile` + `/admin/banners` + `/admin/fraud/reports` همگی صفر خطا؛ wallet در تم تیره اسکرین‌شات-وریفای (طلای `#FCD535`، سبز `#02C076`، سطوح canonical).

---

## Round 30 — بازبینی کامل خط‌به‌خط کل کدبیس خارج از views (Audit_ALL-R30)

**روش:** کاربر درخواست کرد «کل فایل‌های پروژه به‌جز views صددرصد خط‌به‌خط با ایجنت‌های موازی بررسی شود و هیچ فایلی الگو/پاک فرض نشود». کل مخزن خارج از views/vendor (~۲۲۰۰ فایل، ~۳۸۰هزار خط: app×790، core×46، JS×233، CSS×126، database×194، tests×483، docs/md×104، infra/root×~120) به ۳۴ اسکوپ مستقل ~۱۲هزار خطی پارتیشن شد (manifestها: `agent-ctx/audit-scope-30-*.txt`) و با ۳۵ ایجنت موازی بازخوانی کامل شد. گزارش تفصیلی هر اسکوپ: `agent-ctx/30-*-report.md`.

**جمع یافته‌ها (تخمین از گزارش‌های اسکوپی): ۱ CRITICAL + ~۵۰ HIGH + ~۲۳۰ MEDIUM + صدها LOW/INFO.** موارد زیر فیکس شد (همگی با راستی‌آزمایی مستقل ارکستراتور):

| # | شدت | فایل | شرح و فیکس |
|---|---|---|---|
| 1 | CRITICAL | tests/test_{9_modules_exhaustive_e2e,backup_restore_real,infra_prod_audit,performance_explain_real}.py | ۴ اسکریپت تست با `sudo mysql` گذرواژهٔ root را پاک (`ALTER USER ... USING ''` + GRANT ALL) و امنیت محیط را تخریب می‌کردند — بخش مخرب حذف شد (فقط CREATE DATABASE ماند) |
| 2 | HIGH | app/Listeners/InfluencerEventListeners.php | کلید ایدمپوتنسی XP «اینفلوئنسر تأییدشده» ثابت بود (`score_idemp:influencer_verified` سراسری، TTL ۷روز) ⇒ فقط اولین کاربرِ هر پنجره پاداش می‌گرفت → `"influencer_verified_{$userId}"` (الگوی influencer_order_) |
| 3 | HIGH | app/Services/Influencer/InfluencerCommandService.php | `cleanupProofFiles` با `media_path` خامِ کاربر (بدون validator از API) هر فایلی را unlink می‌کرد → گارد realpath+prefix روی دو ریشهٔ کانونی آپلود (storage/uploads، public/uploads)؛ خارج از ریشه ⇒ skip+log |
| 4 | HIGH | public/assets/js/admin/customtasks.js | Stored XSS پنل ادمین: `dataset.reason` (خام decode-شده) داخل `Swal.fire({html})` → helper `escHtml()` + تزریق escape‌شده |
| 5 | HIGH-CSS | public/assets/css/wizard.css | ۵ کامای دوبلهٔ `,,` (خطوط 651/679/680/688/689) ⇒ ۵ قانون کامل (استایل فیلد/آیکون/فوکوس‌رینگ فرم ادمز) drop می‌شد → حذف کاما + حذف ۱۹ سلکتور bare دارک (`body.dark` و…) که `background` را به html/body نشت می‌داد |
| 6 | MEDIUM-CSS | public/assets/css/admin.css | ۷ براکت `}` سرگردان سطح ریشه (خطوط 2257-2269) → حذف؛ تعادل براکت 926/926 اثبات‌شده |
| 7 | MEDIUM-CSS | public/assets/css/views/admininvestmenttrades.css | `var(--bg-card2)` تعریف‌نشده (پس‌زمینه invalid) → تعریف توکن (دارک #1E2329/لایت #f8f9fa)؛ بازنویسی سراسری `:root{--up:#00C896}` که کل ادمین را آلوده می‌کرد → اسکوپ به ریشه‌های tr-* صفحه |
| 8 | MEDIUM-core | core/Queue.php | `json_encode` بدون چک (UTF-8 بد ⇒ payload=false) → چک + RuntimeException fail-loud قبل از incr/insert در هر دو درایور redis/db |
| 9 | MEDIUM-core | core/Database.php | `ensureConnected` در خطای ping بدون گارد تراکنش فعال reconnect می‌کرد ⇒ partial-commit مالی → در تراکنش فعال به‌جای reconnect، `TransientException` (retryable کلاس) پرتاب می‌شود |
| 10 | MEDIUM | config/rate_limits.php | بلوک `typing` به‌اشتباه داخل `social.message` تو در تو شده بود (سقف مؤثر به default می‌افتاد) → هم‌سطح‌سازی |
| 11 | MEDIUM | tools/verify_fix8c1.php | credential هاردکد root/رمز-خالی در probe زیرپروسه‌ای → اتصال از config والد با putenv (بدون argv) |
| 12 | MEDIUM | deploy/docker/docker-entrypoint.sh | `cli.php migrate` (ناموجود — واقعی: `migration`) ⇒ استقرار داکر هرگز مهاجرت نمی‌زد → اصلاح + fail-closed (حذف بلع خطا) |
| 13 | MEDIUM | docker-compose.yml | healthcheck ورکر `cli.php queue:health` (ناموجود) ⇒ کانتینر همیشه unhealthy → `queue:failed` (فقط-خواندنی) |
| 14 | MEDIUM | deploy/supervisor/chortke-queue.conf + docker/supervisord.conf | numprocs=3 بدون process_name (بلاک رد می‌شد) + cron با user=www-data مسیر crontab بی‌مجوز ⇒ کرون هرگز استارت نمی‌خورد → process_name اضافه شد؛ cron با root نصب و جاب‌ها با www-data اجرا می‌شوند |
| 15 | MEDIUM | .gitignore | `/.local-runtime-secrets` و `/test-results/` اضافه شد (فایل secret یک `git add -A` از کامیت‌شدن فاصله داشت) |

**False-positiveهای شکارشده (مستند برای آموزش آینده):** (۱) «ParseError در OutboxPublisher.php:295/:317» — لایهٔ نمایش ابزار دنبالهٔ `[m` ابتدای آرایهٔ `[mb_substr(...)` را می‌بلعید؛ php -l و hex-dump سالم بودن فایل را اثبات کرد. (۲) «سلکتور شکستهٔ userpredictionhub.css» — بایت واقعی `}.pred-preview[hidden]{display:none}` کامل بود (بلع `[h`). در کل راند ۳ ایجنت به‌دلیل همین آرتیفکت یافتهٔ کاذب syntax دادند که همگی با بررسی بایتی رد شد.

**راستی‌آزمایی راند:** scope audit دقیق (۱۸ فایل تغییر = اجتماع ۳ فیکسر + فیکس دستی XSS)؛ php -l شش‌شش سبز؛ node --check سبز؛ py_compile ۴/۴؛ **Full suite 2297/8751/1F/1skip — همان transient شناخته‌شدهٔ S25:169 که ایزوله ۹/۹ سبز است (کاملاً مطابق baseline)**؛ browser QA: /admin/custom-tasks، /admin/investment/trades، /ads/create با صفر خطای کنسول + اسکرین‌شات تمیز (فیکس‌های wizard/`--up`/braces در هر دو منظر سالم).

**یافته‌های مستندشدهٔ نیازمند تصمیم/موج بعد (برگزیدهٔ HIGH/MEDIUM — جزئیات کامل در agent-ctx/30-*-report.md):**
- مالی/اسکیما: `social_ratings` و `content_revenues` بدون UNIQUE (ریسک رکورد تکراری/پرداخت مضاعف در race) — نیازمند migration مصوب؛ drift `ad_delivery_events.site_fee_amount` (درآمد تبلیغات همیشه ۰) و `security_logs.context` (500 در جستجوی ادمین)؛ تسویهٔ دستی پرداخت، خطای گذرای درگاه را قطعی failed می‌کند (در تضاد با مسیر callback)؛ scheduled-payment پس از انجماد کیف بی‌صدا برای همیشه pause می‌ماند.
- اعتبارسنجی ساختاری: موتور Validator قواعد ناشناخته را بی‌صدا می‌بلعد (date_format/accepted نادیده؛ integer|min طول رشته را می‌سنجد)؛ `CreateInvestmentRequest` وقتی risk_accepted غایب است خودش ۱ تزریق می‌کند (گیت پذیرش ریسک عملاً خاموش)؛ گیت KYC در POST /content/store نیست.
- امنیت JS سیستمیک: الگوی dataset→innerHTML/Swal-html در ~۷ فایل user/admin دیگر (userreferralindex، userseoindex، usertasksfeed، useradscreate، user/dashboard، sink مشترک Notyf) — موج فیکس بعدی؛ verify اینفلوئنسر: allowlist فقط روی URL اول (ریدایرکت دور می‌زند).
- CSS: رانش طلایی (#F0B90B/#F5C518) در ~۲۳ فایل باقی‌مانده خارج از موج‌های R27-R29 (adminlogin، adminprediction، user/dashboard، userbankcards*، userads*، userkyc، usertickets، userreferral، userseo، …) — کاندیدای موج مکانیکی بعدی؛ wizard سلکتورهای چسبیدهٔ چندخطی؛ usertickets/userkyc/userinfluencerhub با `html.light` (پنل data-theme ست می‌کند ⇒ تم روشن مرده).
- تست‌ها: خانوادهٔ Grand/py با پوشش جعلی (INSERT خام + assert همان مقدار، `or True`، `len(x)>=0`، ۵۲ نقطهٔ تاتولوژیک، exit-0 همیشگی، فلش کامل Redis) — بازنویسی سنگین نیازمند موج مستقل؛ tests-07: ۳ فایل py همیشه exit 0.
- docs: runbook رمزنگاری ENCRYPTION_MIGRATION به ۵ فایل ناموجود ارجاع می‌دهد؛ scripts/README ۷ اسکریپت از ۸ ناموجود؛ ۲ سند هنوز dispatchAsync را «فوری» توصیه می‌کنند (خلاف تست ممنوعیت) — برچسب SUPERSEDED نیازمند تصمیم.
- ابزار dev: ۱۹ اسکریپت verify_fix* بدون گارد production (FIX-S19-6)؛ DELETEهای باز روی جداول مشترک در probeها.

## Round 31 — موج XSS جاوااسکریپت + موج مکانیکی طلای CSS + دو migration UNIQUE (Audit موج بعد)

**روش:** سه موج مصوب‌شده از یافته‌های باز R30 با ۳ فیکسر موازی اجرا شد (گزارش‌ها: `agent-ctx/31-fix-a-report.md`، `31-fix-b-report.md`، `31-fix-c-report.md`). محدوده: دقیقاً همان ۳ قلم مصوب کاربر — بدون هیچ مورد اضافه.

### موج A — XSS تک‌الگوی JS (۷ فایل + گارد سیستمیک Notyf در ۴ layout)

| # | فایل | شرح و فیکس |
|---|---|---|
| 1 | public/assets/js/views/userreferralindex.js | دو سازندهٔ ردیف جدول با `tr.innerHTML` و درج خام `u.full_name` (نام کاربر دیگر)، `c.referred_name`، `c.source_label`، `c.status_label`،… → helper محلی `escHtml()` (الگوی R30 customtasks.js) روی تمام درج‌های متنی؛ فیلدهای عددی `Number().toFixed/toLocaleString` دست‌نخورده |
| 2 | public/assets/js/views/userseoindex.js | `dataset.title` خام داخل `Swal.fire({html})` → `escHtml(title)` (حفظ مارک‌آپ استاتیک) |
| 3 | public/assets/js/views/usertasksfeed.js | سه sink: `platformSymbol` → ساخت `use` با `createElementNS` + `setAttribute('href','#'+symbol)` پس از whitelist `/^[A-Za-z0-9_-]+$/` با fallback به symbol پیش‌فرض فایل؛ `flowNote` و `startLabel` → text node (حفظ `<strong>` استاتیک) |
| 4 | public/assets/js/views/useradscreate.js | پیام validation سرور (`json.message`/`json.errors[0]` که مقدار تایپ‌شده را echo می‌کند) خام در `feedback.innerHTML` → `escHtml(...)` (استفاده از helper موجود خود فایل) |
| 5 | public/assets/js/views/user/dashboard.js | `showToast` با `t.innerHTML = '...'+msg` → بازسازی با createElement/textContent (اسپن آیکون استاتیک حفظ شد)؛ خط 312 عددی بود (`parseInt`) و طبق برآورد امن ماند |
| 6 | public/assets/js/views/userseoexecute.js | `result.message` سرور خام در `Swal html:` → `escHtml(...)`؛ شاخهٔ payout عددی بود و ماند |
| 7 | public/assets/js/views/userwithdrawalcreate.js | الگوی decode-then-inject: `cardDetails.innerHTML = option.textContent.trim()` (خنثی‌سازی escape سرور) → `cardDetails.textContent =` |
| 8 | views/layouts/{guest,user,auth,admin}.php | گارد سیستمیک sink مشترک Notyf (vendor `d.prototype.open` با `innerHTML=t.message`): پس از `new Notyf({...})` در همان اسکریپت inline، `Notyf.prototype.open` wrap می‌شود تا هر message رشته‌ای entity-escape شود (`&<>"'`)؛ پرچم `__chXssGuard` ضد دوباره‌نصب؛ vendor دست‌نخورده؛ پوشش تمام instanceها (window.notyf هر ۴ layout + نمونهٔ core.js) |

### موج B — هم‌ترازی مکانیکی رانش طلایی CSS (۲۹ فایل، ۲۱۹ جایگزینی)

- قاعده: `#F0B90B`→`#FCD535` (۳۷×)، `#F5C518`→`#FCD535` (۱۱×)، `rgba(240,185,11,α)`→`rgba(252,213,53,α)` (۱۱۵×)، `rgba(245,197,24,α)`→`rgba(252,213,53,α)` (۵۵×) + ۱ مورد بافت عجیب: `stroke='%23F0B90B'` داخل data-URI SVG در shared/layout.css → `%23FCD535`.
- فایل‌ها: admin/auth/core/panel-binance/shared-layout + ۲۴ فایل views/* (adminlogin، adminprediction، user/dashboard، userbankcards*، userads*، userkyc، usertickets، userreferral، userseo، …).
- اثبات‌ها: صفر باقی‌مانده (`rg -i` کل درخت css = خالی)؛ بایت‌اندازهٔ هر ۲۹ فایل تغییری نکرد (جایگزینی‌ها طول-برابر)؛ تعادل براکت هر فایل ثابت؛ replay: `transform(git show HEAD:file) == worktree` برای هر ۲۹ فایل (فقط خطوط طلایی تغییر کرده‌اند)؛ سبک فاصله‌گذاری و آلفا هر رخداد حفظ شد.

### موج C — دو migration UNIQUE (بستن مسابقهٔ check-then-insert)

| # | فایل | شرح |
|---|---|---|
| 9 | database/migrations/2026_09_21_0001_social_ratings_exec_rater_unique.php | `social_ratings` فقط PRIMARY(id) داشت و `SocialTaskAnalyticsModel::createRating` با hasUserRated→INSERT رقابت TOCTOU دارد (دو امتیاز برای یک execution). Dedupe نگه‌داشتن MIN(id) به‌ازای (execution_id, rater_id, rater_type) + `ADD UNIQUE KEY uq_social_ratings_exec_rater` — گارد information_schema سه‌ستونی (الگوی 0007)، skip تمیز، idempotent |
| 10 | database/migrations/2026_09_21_0002_content_revenues_live_period_unique.php | `content_revenues` فقط ایندکس غیریکتا روی (submission_id, period) داشت و `ContentRevenue::existsForPeriod` (فقط is_deleted=0) → INSERT رقابت مالی (درآمد تکراری/پرداخت مضاعف). UNIQUE جزئی آگاه-از-soft-delete با ستون تولیدی STORED `live_period_key = IF(is_deleted=0 AND submission_id IS NOT NULL AND period IS NOT NULL, CONCAT(submission_id,':',period), NULL)` + `ADD UNIQUE KEY uq_content_revenues_live_period` (NULLها تداخل ندارند)؛ dedupe سطرهای زنده با نگه‌داشتن MIN(id)؛ ایندکس غیریکتای قدیمی برای کوئری‌پلن‌ها حذف نشد |

**تغییر رفتار (مقصود):** بازندهٔ رقابت اکنون به‌جای رکورد مضاعف، PDOException duplicate-key می‌گیرد (fail-loud) — مسیر عادی از قبل با BusinessException پیام دوستانه دارد (ContentService::427).

**راستی‌آزمایی راند:** scope audit (۴۲ فایل = دقیقاً اجتماع ۳ فیکسر: ۲۹ CSS + ۷ JS + ۴ layout + ۲ migration)؛ `php -l` ۶/۶ سبز (۲ migration + ۴ layout)؛ `node --check` ۷/۷ سبز؛ مایگریشن‌ها روی DB محلی اجرا: executed 2 / errors 0، `SHOW INDEX` هر دو UNIQUE تأیید، ستون تولیدی STORED GENERATED تأیید، اجرای مجدد executed 0 (idempotent)؛ **Full suite 2297/8751/1F/1skip — همان transient شناخته‌شدهٔ S25:169 (ایزوله ۹/۹ سبز، مطابق baseline)**؛ browser QA: /referral، /seo، /ads/create، /tasks، /wallet، /withdrawals، /dashboard (کاربر) و /admin/prediction (سوپرادمین) همگی با صفر خطای کنسول؛ **آزمون نفوذ واقعی گارد Notyf در هر دو layout کاربر/ادمین:** تزریق `<img src=x onerror=...>` در toast به‌صورت متن لفظی رندر شد و handler اجرا نشد (`window.__xss=0`)؛ طلای کانونی در اسکرین‌شات adminprediction یکدست.

## Round 32 — موج «سرعت-بالا»: چهار فیکس مالی/امنیتی مستقیم (برگزیدهٔ R30)

**روش:** چهار مورد مصوب کاربر از فهرست pending R30، همگی فیکس کوچک با اثر مالی/امنیتی مستقیم. فیکس دستی ارکستراتور + راستی‌آزمایی مستقل هر مورد.

| # | شدت | فایل | شرح و فیکس |
|---|---|---|---|
| 1 | P0 | app/Controllers/BannerController.php | گیت احراز هویت روی ثبت کلیک بنر: مسیرهای `/banner/click/{id}` و دوقلوهای `/api/banner-click` (GET/POST) عمومی بودند و با وجود نرخ‌سنجی ۳۰/دقیقه + dedupe اتمیک per-(banner,ip) (FIX-R18N)، تخلیهٔ بودجهٔ تبلیغ‌دهنده با IPهای متعدد ممکن بود. اکنون مهمان: `/api/*` → 401 JSON، مسیر GET → ریدایرکت به `/login`؛ گیت عمداً در کنترلر است تا هر سه واریانت پوشش شود (AuthMiddleware روی `/api/*` طبق CORE-037 session-cookie را رد می‌کند). نکتهٔ کشف‌شده در حین QA: home.js به `/api/banners/{id}/click` (مسیر ناموجود) fetch می‌کند و href بنر صفحهٔ اصلی مستقیم لینک خارجی است — یعنی مصرف واقعی این endpointها فقط دسترسی مستقیم بود (پیگیری جدا، خارج از اسکوپ) |
| 2 | HIGH | app/Services/Analytics/AnalyticsService.php | `getRevenueBreakdown` روی `ad_delivery_events.site_fee_amount` SUM می‌کرد که ستونش وجود ندارد (واقعی: `platform_fee`) و safeSum خطا را می‌بلعید ⇒ **درآمد تبلیغات همیشه ۰** → تغییر به `platform_fee` (ستون site_fee_amount جدول investment_profits است و به این جدول ربط ندارد) |
| 3 | HIGH | app/Models/SecurityLog.php | فیلتر جستجوی ادمین `(message LIKE ? OR context LIKE ?)` به ستون ناموجود `context` اشاره می‌کرد ⇒ SQLSTATE 42S22 (500) در هر جستجوی لاگ امنیتی → حذف `context LIKE`؛ مسیر INSERT (FIX-X210) مقدار context را داخل message ادغام می‌کند پس جستجوی message همان محتوا را هم پوشش می‌دهد |
| 4 | HIGH | app/Validators/Requests/CreateInvestmentRequest.php | خودتزریق `risk_accepted = 1` در constructor حذف شد — چک‌باکس تیک‌نخورده اصلاً POST نمی‌شود و اینجا بی‌صدا ۱ تزریق می‌شد ⇒ **گیت پذیرش ریسک عملاً همیشه خاموش**. اکنون: غیبت فیلد ⇒ 422 با پیام «پذیرش ریسک سرمایه‌گذاری الزامی است.» (messages() جدید)؛ مقدار 0 ⇒ گارد RISK_NOT_ACCEPTED سرویس (لایهٔ دوم). گارد `empty($data['risk_accepted'])` سرویس دست‌نخورده ماند |

**راستی‌آزمایی راند:** php -l ۴/۴ سبز؛ **Full suite 2297/8751/1F/1skip = baseline دقیق** (همان transient شناخته‌شدهٔ S25:169)؛ QA مرورگر/курل:
- بنر: مهمان GET → 302 به /login ✓، مهمان POST/GET api → 401 JSON فارسی ✓، کاربر واردشده → عبور از گیت و جریان عادی trackClick ✓
- درآمد تبلیغات: ردیف تست platform_fee=12.5 درج شد → صفحهٔ /admin/analytics/revenue «درآمد از تبلیغات: ۱۳ تومان» (رند number_format) نشان داد — قبل از فیکس همیشه ۰ بود؛ ردیف تست پاک شد (COUNT=0) ✓
- جستجوی لاگ امنیتی: `/admin/logs/security?search=test` بدون خطا رندر شد (قبلاً 500) ✓
- گیت ریسک: POST /investment/store بدون risk_accepted → 422 با پیام فارسی در errors؛ با risk_accepted=1 → عبور از اعتبارسنجی و رسیدن به چک موجودی (INSUFFICIENT_USDT_BALANCE برای کاربر بدون موجودی) ✓

## Round 33 — موج ترکیبی: اتصال بنر صفحهٔ اصلی، CAS اختلاف‌ها، javascript:-URI و پالایش فهرست pending

**روش:** ۶ کاندیدای مصوب کاربر با ۴ ایجنت اکتشافی موازی دوباره راستی‌آزمایی شد (گزارش‌ها: agent-ctx/32-{a,b,c,d}-*-recon-report.md). نتیجه: ۳ مورد از ۶ مورد **قبلاً در R18/R19 فیکس شده بود** و فهرست pending قدیمی بود؛ ۳ مورد باقی‌مانده + ۲ کشف تازهٔ حین QA فیکس شدند.

| # | شدت | فایل | شرح و فیکس |
|---|---|---|---|
| 1 | HIGH | public/assets/js/home.js | اتصال fetch مردهٔ کلیک بنر صفحهٔ اصلی: به `/api/banners/{id}/click` (مسیر ناموجود = 404 بی‌صدا) با پارام `banner_id` fetch می‌شد؛ اکنون به endpoint واقعی `POST /api/banner-click` با پارام `id` (قرارداد کنترلر `int('id')`) |
| 2 | HIGH (کشف حین QA) | app/Controllers/HomeController.php | اسلاگ جایگاه بنر صفحهٔ اصلی `'home'` در جدول `banner_placements` وجود ندارد (واقعی: `home_hero`) ⇒ ویجت بنر صفحهٔ اصلی برای هیچ بنری رندر نمی‌شد و مصرف واقعی endpoint کلیک نیز صفر بود → هم‌ترازسازی به `home_hero` |
| 3 | MEDIUM (کشف حین QA) | app/Services/Ads/AdsBudgetSettlementService.php | **dedupe کلیک بنر (FIX-R18N) از روز اول no-op بود**: `cache()->add()` روی `CacheManager` وجود ندارد (undefined method → warning → fall-through بدون هیچ ددوپ) ⇒ ضد-تخلیهٔ-بودجهٔ ۹۰ ثانیه‌ای عملاً غیرفعال. فیکس: `\Core\Cache::getInstance()->add()` — همان NX/TTL اتمیک مستند (Redis SET NX EX / فایل حالت 'x') |
| 4 | MEDIUM (کشف حین QA) | app/Services/BannerService.php | ستون `max_banners` در `banner_placements` وجود ندارد ⇒ Warning «Undefined property» در هر رندر صفحهٔ اصلی → خواندن null-safe با پیش‌فرض 5 (= limit پیش‌فرض مدل). افزودن ستون‌های ناهم‌خوان placements به‌عنوان بک‌لاگ schema-drift R30 ماند |
| 5 | HIGH | app/Services/Dispute/DisputeCommandService.php | گپ CAS در `escalateToAdmin`: check-then-act خالص بود و رقابت با resolve توافقی/ادمینِ هم‌زمان پروندهٔ بسته را با escalated بازنویسی می‌کرد → آپدیت شرطی `WHERE status IN ('open','open_peer')` + بررسی rowCount؛ بازنده پیام دوستانه می‌گیرد (از ۳ متد تغییروضعیت، ۳ مورد دیگر قبلاً گارد داشت — adminResolve با FOR UPDATE، resolveByAgreement با re-read قفل‌شده، resolveByAdmin روی facade) |
| 6 | HIGH | app/Services/Dispute/DisputeCommandService.php | گپ CAS در `processExpiredPeerResolutions` (کرون): آپدیت بی‌شرط می‌توانست resolve توافقیِ هم‌زمانِ طرفین را با escalated بازنویسی کند → آپدیت شرطی `WHERE status = 'open_peer'` + rowCount |
| 7 | MEDIUM | views/layouts/footer.php | آخرین sink بازماندهٔ javascript:-URI: `href="<?= e($__site) ?>"` روی `setting('site_url')` (e() جلوی scheme را نمی‌گیرد) → شاخهٔ دوگانهٔ ثبت‌شدهٔ R19: `sanitize_url()` برای مقدار تنظیمات، `e(url('/'))` برای فال‌بک نسبی |
| 8 | LOW (دفاع عمقی) | helpers/security.php | `sanitize_url()`: رد صریح کاراکترهای کنترلی `[\x00-\x1F\x7F]` (ترفند حذف \t/\n/\r توسط مرورگر در href) |

**پالایش فهرست pending (stale):** visibility-timeout ورکر صف = FIX-R18-M9 (lease Lua + self-heal)؛ claim سود توزیعی = FIX-R18-M12 (IdempotencyKey اتمیک)؛ transaction در TwoFactorService::disable = FIX-R19-A2-2 — هر سه **قبلاً اعمال** بودند؛ «javascript:-URI ×4» نیز قدیمی بود — R19 هر ۹ sink را بسته بود و فقط مورد ۷ بالا باقی مانده بود. مشاهدهٔ خارج-از-اسکوپ (بک‌لاگ): دو نمایش نمایشیِ `site_fee_amount` در ویوهای ادمین (custom-tasks show / custom_task_detail) همیشه ۰ می‌دهند.

**تغییر رفتار (مقصود):** بازندهٔ ریسک ارجاع/کرونِ اختلاف به‌جای بازنویسی، rowCount=0 و پیام دوستانه می‌گیرد؛ کلیک تکراری بنر در پنجرهٔ ۹۰ ثانیه (per banner+IP) اکنون واقعاً skip می‌شود (قبلاً هیچ ددوپی اجرا نمی‌شد)؛ URLهای تنظیمات با scheme غیر http(s) در فوتر به `#` تبدیل می‌شوند.

**راستی‌آزمایی راند:** php -l ۶/۶ سبز + `node --check` ۱/۱ سبز؛ **اثبات SQL گیت CAS در ۴ سناریو** (open→1، resolved_peer→0، open_peer→1، بسته→0؛ ROLLBACK — صفر اثر ماندگار)؛ **Full suite 2297/8751/1F/1skip = baseline دقیق** (S25:169 ایزوله ۹/۹ سبز)؛ **اثبات واحد sanitize_url**: `javascript:` و `java\tscript:` و `data:` هر سه → `#`، URL سالم سالم-escaped؛ **QA مرورگری E2E زنجیرهٔ بنر**: مهمان POST → 401 ✓؛ کاربر واردشده: کلیک بنر صفحهٔ اصلی → `ad_delivery_events` (amount=۵۰۰، platform_fee=۵۰) + ردیف `banner_clicks` + شمارنده‌های ads (clicks_count=1) + کاهش بودجه (۱۰۰۰۰→۹۵۰۰) + بدهی کیفِ قفل‌شده (۱۰۰۰۰→۹۴۵۰) ✓؛ کلیک دوم در پنجرهٔ ۹۰ ثانیه → `ads.banner_click.duplicate_skipped` (بدون دوباره‌سوزی) ✓؛ صفر Warning max_banners در رندر ✓؛ همهٔ ردیف‌های fixture تست پس از QA پاک شدند (ads/clicks/events/escrow/transactions/banners/wallet = حالت اولیه)؛ نکتهٔ محیطی QA: کوکی سشن `domain=127.0.0.1` است — مرور باید از `http://127.0.0.1:3000` باشد وگرنه CSRF در Origin/کوکی ناموفق است (تنظیم APP_URL محیط، نه باگ کد).

## Round 34 — موج «مالی-۲»: بستن کامل بخش الف pending (پول گیر‌کردهٔ درگاه، بن‌بست paused، گیت KYC، بازطراحی Validator)

**روش:** ۵ کاندیدای مصوب کاربر با ۴ ایجنت اکتشافی موازی خط‌به‌خط راستی‌آزمایی شد (گزارش‌ها: `agent-ctx/34-{a,b,c,d}-*-recon-report.md`). ۴ مورد تأیید + ۱ مورد stale. کشف کلیدی ریکن اول: در outage واقعی، مدارِ بازِ Circuit Breaker (`CircuitBreakerOpenException` — بدون خویشاوندی با `PaymentGatewayConnectionException`) به `catch (\Exception)` درگاه‌ها می‌افتد و بدون هیچ نشانگر شبکه‌ای `success=false` می‌سازد؛ پچ بدون multi-catch آن ناقص می‌ماند.

| # | شدت | فایل | شرح و فیکس |
|---|---|---|---|
| 1 | HIGH | app/Services/Payment/{IDPay,NextPay,ZarinPal,DgPay}Gateway.php | catch شبکه‌ای وریفای هر ۴ درگاه → multi-catch `(PaymentGatewayConnectionException \| CircuitBreakerOpenException)` + پرچم افزودنی `transient => true` (قرارداد callback با regex روی پیام دست‌نخورده) |
| 2 | HIGH | app/Services/Payment/PaymentAdminService.php | شاخهٔ گذرا در `manuallyVerifyPayment`: ردیف در `pending_verification` می‌ماند (نه failed ابدی)، `response_data` با merge به‌روز می‌شود (حفظ `order_id` IDPay)، شمارندهٔ تلاش + لاگ `payment.manual_verify.transient_retry`؛ کرون ۲۴ساعته و ادمین به retry ادامه می‌دهند. ردِ قطعی همان failed؛ هیچ‌گاه بدون تأیید واقعی درگاه وضعیت عوض نمی‌شود |
| 3 | MEDIUM | app/Models/ScheduledPayment.php + app/Services/ScheduledPaymentService.php | بن‌بست `paused` (فریز موقت = مرگ ابدی، بدون اعلان، بدون resume): due-query اکنون `status IN ('active','paused')` + متد CAS `resumePaused()`؛ skip بی‌tx برای paused-هنوز-فروزن (شمرده نمی‌شود ⇒ حلقهٔ drain کرنل نمی‌چرخد)؛ CAS-resume داخل همان tx (rollback کسر ⇒ rollback resume؛ لغو هم‌زمان ⇒ rowCount=0 بدون کسر)؛ اعلان‌های `scheduled_payment_paused`/`scheduled_payment_resumed` با ایدئوم SP-03. کشف ریکن: `Wallet::unfreezeWallet` dead-code است ⇒ هوک روی آنفریز ناممکن؛ طرح self-heal تنبل در due-scan انتخاب شد |
| 4 | MEDIUM | app/Controllers/User/ContentController.php | گیت KYC روی `POST /content/store` (تا دیروز فقط GETها گیت داشتند): `kyc_status !== 'verified'` → JSON 403 با پیام فارسی گیت create()؛ HttpResponseException توسط catch موجود rethrow می‌شود؛ سطح کنترلر ⇒ ۳ فراخوانی unit سرویس دست‌نخورده |
| 5 | MEDIUM | core/Validator.php | بازطراحی حداقلی: (الف) ۵ قاعدهٔ استفاده‌شده ولی بی‌صدا-نادیده (census کامل): `accepted` (StoreContentRequest)، `same:password` (reset-password — مغایرت تأیید بی‌صدا قبول می‌شد!)، `digits:10` (کدملی KYC — طول چک نمی‌شد)، `alpha_dash` (slug نقش RBAC)، `date_format:Y-m-d H:i:s` (CloseTradeRequest — هر رشته‌ای عبور می‌کرد) با roundtrip سخت‌گیرانه + گارد rollover (2026-02-30 رد)؛ (ب) گیت عددی min/max به زنجیرهٔ `integer` گسترش یافت — پیش‌تر `integer|min:1|max:5` طول رشته را می‌سنجید (rating 99999 عبور!)؛ ~۲۵ فیلد رشته‌ای (پسورد min:6 و…) رفتار strlen قبلی را حفظ کردند؛ (ج) fail-loud: قاعدهٔ ناشناخته/توکن خالی/قاعدهٔ غیررشته‌ای → RuntimeException (از catch InvalidArgumentException در result() عبور می‌کند = ۵۰۰ واقعی) — census اثبات کرد صفر call-site موجود به default نمی‌خورد |
| 6 | stale | app/Services/VerificationService.php | «allowlist اینفلوئنسر فقط URL اول» = false-positive قدیمی: `fetchPublicProofContent` از قبل حلقهٔ دستی ≤۳hop + re-validate هر hop + `follow_location=0` دارد (commit 247324 قبل از audit R30) — بدون پچ، از pending حذف شد |

**کشف حین راستی‌آزمایی (سوئیت):** شکست ۱F از R30 به این‌روز در baseline اشتباهی به S25:169 نسبت داده می‌شد؛ ۱F واقعی `S22DeployDockerSecurityPinningTest` بود که رفتار «قدیمی» entrypoint (`migrate --force || echo`) را pin می‌کرد — در تضاد با فیکس مصوب R30 (`migration --force` fail-closed؛ اثبات با git stash روی HEAD تمیز). پین به رفتار مصوب به‌روز شد.

**تغییر رفتار (مقصود):** outage شبکهٔ ≥۱۰ دقیقه‌ای دیگر پرداخت‌های pending_verification را ابدی failed نمی‌کند؛ فریز موقت کیف دیگر پرداخت زمان‌بندی‌شده را نمی‌کشد (پس از آنفریز، اولین اسکن روزانه resume+کسر می‌کند)؛ کاربر بدون KYC با POST مستقیم نمی‌تواند محتوا ثبت کند؛ rating/reward/بلیت‌لاتاری/timeouts با سقف واقعی عددی اعتبارسنجی می‌شوند؛ قاعدهٔ Validation اشتباه = ۵۰۰ برنامه‌نویس‌مرکز نه پذیرش بی‌صدا.

**راستی‌آزمایی راند:** php -l ۱۰/۱۰ سبز؛ اثبات رفتاری Validator (throwaway read-only) ۲۰/۲۰ PASS؛ سرشماری زندهٔ rule-shaped tokens = صفر ناشناخته باقی‌مانده (توکن‌های مشکوک = redact-list/مرتب‌سازی/کلید ایدمپوتنسی — نویز)؛ **Full suite 2297/8754/0F/1skip = سبز کامل (اولین بار از R30)**؛ QA مرورگر: user@ (unverified) POST /content/store → 403 فارسی ✓، GET create → ریدایرکت /kyc ✓، support@ (verified) POST → 422 اعتبارسنجی (گیت عبور، صفر ردیف ثبت‌شده) ✓، داشبورد و خانه با صفر خطای کنسول ✓.

## Round 35 — «ادمین/اسکیما» + «CSS پایانی»: مایگریشن banner_placements، دو نمایش ghost کارمزد و ۱۷ پچ CSS

**روش:** دو بخش باقی‌ماندهٔ فهرست pending با ۳ ایجنت ریکن موازی راستی‌آزمایی شد (گزارش‌ها: `agent-ctx/35-{a,b,c}-*-recon-report.md`) و موج CSS با فیکسر اختصاصی اعمال شد (گزارش: `agent-ctx/35-c`). طبق قانون جدید کاربر، موارد کهنه/پیشین نیز در همین راند رفع شدند — از جمله تأیید نهایی رفع پین کهنهٔ S22 (در R34 اصلاح شده بود؛ تست ایزوله ۱۲/۱۲ و ۲۰۱ assertion سبز).

| # | شدت | فایل | شرح و فیکس |
|---|---|---|---|
| 1 | HIGH (کشف: دیفرم ۱۱ ستونی، نه ۴) | database/migrations/2026_09_22_0001_banner_placements_schema_drift.php | جدول زنده فقط ۵ ستون داشت ولی مدل ۱۴ fillable ⇒ ۱۱ ستون غایب: `title,page,position,show_on_mobile,show_on_desktop,max_banners,rotation_speed,display_style,auto_rotate,max_width,max_height` ⇒ `POST /admin/banners/placements/{id}/update` با هر فیلد = PDOException 42S22 → ۵۰۰ (لندماین خاموش؛ دکمهٔ فرم استاب alert بود). مایگریشن ایدمپوتنت با گارد information_schema per-column + backfill `title=name`؛ `max_banners DEFAULT 5` == band-aid `??5` ⇒ رفتار خواندن بایت‌به‌بایت ثابت؛ بدون ایندکس جدید (slug از قبل UNIQUE، تکراری صفر) |
| 2 | MEDIUM | views/admin/custom-tasks/show.php:73 + views/admin/ads/partials/custom_task_detail.php:20 | دو نمایش ghost `site_fee_amount` (ستون ناموجود در ads ⇒ همیشه ۰) → کارمزد محاسبه‌شده `total_budget × site_commission_percent / 100` با عین ایدیم FIX 8-e (منبع نرخ مؤثری که AdSystemManager:608 و مسیرهای refund استفاده می‌کنند) |
| 3 | HIGH (کشف جدید) | uservitrineindex.css:28 + ۳ ویو | `.progress-bar[data-width]{width:attr(data-width)}` — `attr()` در width پشتیبانی نمی‌شود ⇒ نوارهای پیشرفت بدون عرض. CSS → `var(--w,0%)` دفاعی + ۶ محل رندر واقعی (social-tasks/dashboard، prediction/show ×3، level/index ×2) به عرض inline تبدیل شد؛ JS`.inv-progress__bar` دست‌نخورده |
| 4 | MEDIUM | userinfluencerhub.css + userkyc.css + usertickets.css | تم روشن مرده: `html.light` هرگز ست نمی‌شد (پنل با `data-theme` کار می‌کند) → تبدیل مکانیکی به `html[data-theme="light"]` (الگوی STY-14C در userreferral) — اثبات مرورگری دوطرفه: dark→#0f172a، light→#f3f6fb |
| 5 | HIGH (a11y) | admin.css + panel.css | گاردهای `prefers-reduced-motion` بدون `!important` ۱۰۰٪ بی‌اثر بودند (specificity صفر در برابر قواعد کلاس‌دار) → هم‌راستا با سبک core.css |
| 6 | HIGH (دارک ادمین) | admin.css | توکن‌های legacy لایتِ tokens.css (`--card-bg:#FFFFFF`، `--icon-bg` آبی) ردیف‌های موبایل ادمینِ دارک را سفید می‌کردند → بلوک `html:not(.light){--card-bg:rgba(255,255,255,0.02);--icon-bg:var(--gold-subtle)}` فقط برای دارک (تم light واقعی ادمین که theme.js می‌سازد دست‌نخورده) |
| 7 | MEDIUM (رگرسیون) | usersocialaccounts.css | بلوک دوبل `.form-control/.form-control:focus` رینگ فوکوس و font-size را می‌کشت → حذف بلوک دوم با حفظ `:disabled` یکتا |
| 8 | MEDIUM (a11y) | tailwind-lite.css + useradsindex.css + useradsshow.css + bugreportwidget.css | چهار نشانگر فوکوس کور (shim بدون ring، دو input جستجو بدون focus-within، fab با outline:none) → رینگ طلای کاننیکال `rgba(252,213,53,.25)` / outline طلایی |
| 9 | MEDIUM (کنتراست) | views/user/dashboard.css | سه متن کم‌کنتراست `rgba(255,255,255,.4/.42/.18)` → `.72/.70/.60` (≥4.5:1 روی کارت تیره) |
| 10 | MEDIUM | useradsshow.css:18 | تنها قاعدهٔ تو-در-توی کل CSS ویوها فلت شد (در مرورگر بدون native nesting کل اعلام ساقط می‌شد) |
| 11 | MEDIUM | panel.css | `.submenu` پس‌زمینهٔ `#FAFAF8` در تم دارک override نداشت → `[data-theme="dark"] .submenu{background:var(--surface)}`؛ حذف بلوک دوبل `.btn-gold` (سلکتور در هیچ مارک‌آپی نیست — صفر تغییر بصری) |
| 12 | MEDIUM | wizard.css | ۴ گرادیان با `#a855f7` هاردکد (بنفش) در تضاد با توکن نهایی طلایی → `var(--wiz-primary-dark)` (#d9a607) |
| 13 | MEDIUM (RTL) | auth.css + userbankcardsform.css + userseo.css | فیزیکی→منطقی: toggle رمز (`left`→`inset-inline-end`، `padding-left`→`padding-inline-end`؛ هم‌ارز critical در auth.php بررسی شد — ندارد)، prefix کارت بانک، اکسنت سئو (`border-left`→`border-inline-start`) |
| 14 | LOW (نشتی) | adminbankcardsindex.css + adminbankcardsreview.css | `:root` ویو `--gold/--gold-glow` کاننیکال ادمین را در کل صفحه بازنویسی می‌کرد → حذف دو خط؛ توکن‌های محلی ماند |
| 15 | LOW (cleanup) | public/assets/css/views/userseoad.css | حذف فایل — دوبلِ کاملِ زیرمجموعهٔ userseo.css با صفر لودر در کل ریپو |
| 16 | LOW | help-hub.css:302 | کامنت/کد متناقض اصلاح شد (بلوک light زیر guest بدون data-theme فعلاً بی‌اثر است) |

**فایل‌های مردهٔ ثبت‌شده (تصمیم مالک — حذف نشدند):** `errors503.css`، `usertickets.css`، `usertasks.css`، `userkyc.css` (صفر لودر؛ برخورد keyframes آنها INFO). **گزارشی بدون پچ:** پالت محلی status.css (بازطراحی ویژوال = تصمیم مالک).

**راستی‌آزمایی راند:** `php -l` ۶/۶ سبز؛ مایگریشن: executed=1/batch=3 → DESCRIBE=۱۶ ستون منطبق با شکل هدف + backfill ۷ ردیف → اجرای مجدد executed=0 (idempotent)؛ **Full suite 2297/8754/0F/1skip = baseline دقیق R34**؛ QA مرورگر/curl:
- کارمزد ghost: ردیف آزمایشی custom_task (بودجه ۱٬۰۰۰٬۰۰۰ × کمیسیون ۱۰٪) → هر دو صفحهٔ ادمین «کارمزد: ۱۰۰,۰۰۰» (قبلاً ۰)؛ ردیف پس از QA حذف شد (ads=0)
- لندماین placements: POST آزمایشی `max_banners=7&display_style=slider` → 302 + ثبت در DB (قبلاً 500)؛ بازگشت به 5/grid با POST دوم؛ صفحهٔ placements صفر warning و ستون «صفحه: all» زنده
- تم روشن اینفلوئنسر: eval دوطرفه `data-theme=dark→#0f172a / light→#f3f6fb` ✓
- نوارهای پیشرفت: level با `style="width: 0%"` زنده (مقدار واقعی کاربر)؛ social صفر data-width باقی‌مانده
- خانه/social/level/ads-create همگی 200 با صفر warning و صفر خطای کنسول؛ ویجت بنر خانه خالی = صحیح (جدول banners پس از پاک‌سازی QA راند ۳۳ خالی است؛ اسلاگ home_hero و max_banners=5 عیناً حفظ شد)
- S22 (قانون جدید موارد کهنه): تست ایزوله `OK (12 tests, 201 assertions)` — پین کهنه در R34 به رفتار مصوب R30 اصلاح شده بود
