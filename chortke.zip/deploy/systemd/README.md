# systemd units for Chortke (alternative to Supervisor)

پوشش کامل سرویس‌های پس‌زمینه: queue worker، outbox publisher،
cron scheduler (dispatch tick) و DLQ retry.

## Units

| Unit | نقش | فرمان |
|------|-----|-------|
| `chortke-queue.service` | ورکر صف اصلی | `php cli.php queue:work --daemon --sleep=1 --tries=3` |
| `chortke-outbox.service` | ناشر transactional outbox | `php cli.php outbox:publish --limit=100 --sleep=5` |
| `chortke-cron.service` + `chortke-cron.timer` | زمان‌بند (dispatch تسک‌های سررسیده به صف) | `php cron.php` — هر دقیقه (OnCalendar=minutely) |
| `chortke-dlq.service` | بازپخش هوشمند Dead Letter Queue | `php cli.php dlq:work --limit=50 --sleep=10` |

## Install

```bash
sudo cp deploy/systemd/*.service deploy/systemd/*.timer /etc/systemd/system/
sudo systemctl daemon-reload

# ورکرها (مداوم)
sudo systemctl enable --now chortke-queue chortke-outbox chortke-dlq

# زمان‌بند: هر دو واحد لازم است — سرویس oneshot + تایر دقیقه‌ای
sudo systemctl enable --now chortke-cron.timer
sudo systemctl start chortke-cron.service   # (اختیاری) اجرای فوری اولین tick

sudo systemctl status chortke-queue
systemctl list-timers chortke-cron.timer
```

## Logs

```bash
journalctl -u chortke-outbox -f
journalctl -u chortke-queue -f
journalctl -u chortke-dlq -f
tail -f /var/log/chortke/cron.log        # خروجی cron.php به فایل log می‌رود
```

## یادداشت‌های عملیاتی

* **درایور صف (FIX-9a-2):** متغیر کانونیکال `QUEUE_DRIVER` است (مثلاً
  `Environment=QUEUE_DRIVER=redis` — در chortke-queue.service ست شده).
  `QUEUE_CONNECTION` قدیمی فقط به‌عنوان fallback منسوخ پذیرفته می‌شود؛ در
  استقرارهای جدید فقط کانونیکال را تنظیم کنید.
* **cron.php (FIX-9a-8):** cron.php هیچ کاری را همزمان اجرا نمی‌کند و فقط
  تسک‌های سررسیده را به صف dispatch می‌کند؛ Type=oneshot + تایر دقیقه‌ای
  کافی است. قفل توزیع‌شدهٔ داخلی آن (Redis، با heartbeat تمدید قفل در اجراهای
  طولانی) اجرای موازی روی multi-node را می‌بندد — پس چند node می‌توانند تایر
  را فعال کنند؛ فقط یکی dispatch می‌کند.
* **DLQ retry (FIX-9a-8):** بازیابی خودکار فقط ردیف‌های `status='retrying'`
  با سررسید `next_retry_at` را برمی‌گرداند (backoff یک‌ساعته/۴ساعته/۱۲ساعتهٔ
  QueueWorker)؛ وضعیت‌های پایانی `dead_letter`/`quarantined` هرگز خودکار
  بازیابی نمی‌شوند و فقط با تصمیم انسانی از پنل Sentry یا دستورات دستی ادمین
  (`php cli.php queue:failed retry <job_id>` / `queue:failed replay --force`)
  برمی‌گردند.
* **اجرا به‌عنوان root ممنوع:** همهٔ یونیت‌ها با `User=www-data` اجرا می‌شوند؛
  اجرای CLI به‌عنوان root یا سپر root در cli.php/مالکیت فایل‌های storage را
  خراب می‌کند یا exit(1) می‌گیرد (bypass مستند: `--allow-root`).
* **migration (پیش‌نیاز بوت):** پیش از start ورکرها یک‌بار
  `sudo -u www-data php cli.php migration --force` را از WorkingDirectory
  اجرا کنید (در Docker entrypoint همین کار خودکار و fail-closed انجام می‌شود).
