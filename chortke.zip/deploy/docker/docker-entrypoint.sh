#!/bin/bash
set -e

echo "=== Chortke Docker Entrypoint ==="

# ─────────────────────────────────────────────────────────────────────────────
# FIX-9a-1 (Audit Task 9-a): قرارداد صریح entrypoint/cli دربارهٔ root
#
# پیشینه: ایمیج بدون USER می‌ساخت و همه‌چیز به‌عنوان root اجرا می‌شد؛ ولی سپر
# cli.php هر «php cli.php ...» بدون --allow-root را با exit(1) می‌بست ⇒
# `php cli.php migration --force` و فرمان‌های ورکر (queue:work و …) در
#کانتینر هرگز بوت نمی‌شدند (crash-loop دائمی worker/app).
#
# قرارداد جدید (coherent + explicit):
#   * اگر entrypoint به‌عنوان root اجرا شود:
#       ۱) مالکیت storage/لاگ‌ها به www-data اصلاح می‌شود (named volume ممکن است
#          root-owned مانت شده باشد) و یک boot smoke-test (قابلیت نوشتن مسیرهای
#          storage توسط کاربر اپ) fail-closed اجرا می‌شود.
#       ۲) هر فرمانِ اپلیکیشن (php/cli/...) با gosu به www-data drop می‌شود —
#          یعنی migration/seed و CMD ورکرها هرگز به‌عنوان root اجرا نمی‌شوند
#          و سپر cli.php هیچ‌گاه بوت کانتینر را نمی‌بندد.
#       ۳) فقط CMD از نوع supervisord به‌عنوان root می‌ماند؛ خودِ supervisor
#          طبق docker/supervisord.conf هر program را با user=www-data اجرا
#          می‌کند (و crond به root نیاز دارد). اپ هیچ‌گاه root نمی‌ماند.
#   * اگر entrypoint غیر-root باشد: بدون تغییر، ادامه.
#   * خارج از کانتینر (shell انسانی) اجرای دستورات به‌عنوان root همچنان با پیام
#     سپر cli.php بسته می‌شود و bypass مستندش همان --allow-root است.
# ─────────────────────────────────────────────────────────────────────────────
APP_USER="${CHORTKE_APP_USER:-www-data}"

is_root() {
    [ "$(id -u)" = "0" ]
}

# FIX-9a-1: اجرای فرمان به‌عنوان کاربر اپ (در حالت root با gosu drop می‌شود)
run_as_app() {
    if is_root; then
        gosu "${APP_USER}" "$@"
    else
        "$@"
    fi
}

if is_root; then
    echo "Running as root — fixing storage ownership for '${APP_USER}' and dropping privileges for app commands..."
    chown -R "${APP_USER}:${APP_USER}" storage /var/log/chortke 2>/dev/null || true

    # Boot smoke-test (fail-closed): کاربر اپ باید بتواند مسیرهای حیاتی storage
    # را بنویسد؛ وگرنه کانتینر بالا نمی‌آید تا restart و رؤیت خطا ممکن باشد.
    if ! run_as_app php -r '
        $base = getcwd() ?: ".";
        foreach (["storage/logs", "storage/cache", "storage/locks"] as $d) {
            $path = $base . "/" . $d;
            if (!is_dir($path)) { @mkdir($path, 0775, true); }
            if (!is_writable($path)) {
                fwrite(STDERR, "FATAL: storage path is not writable by app user: {$path}\n");
                exit(1);
            }
        }
        echo "storage smoke-test OK\n";
    '; then
        echo "ERROR: boot smoke-test failed — storage is not writable by '${APP_USER}'. Aborting entrypoint." >&2
        exit 1
    fi
fi

# Wait for DB (fail-closed: abort after max attempts so the container
# restarts and retries instead of limping without a database)
echo "Waiting for database..."
DB_READY=0
for i in {1..40}; do
    if run_as_app php -r "
        try {
            \$pdo = new PDO('mysql:host='.\$_ENV['DB_HOST'].';port='.\$_ENV['DB_PORT'].';dbname='.\$_ENV['DB_NAME'], \$_ENV['DB_USER'], \$_ENV['DB_PASS'], [PDO::ATTR_TIMEOUT=>2]);
            echo 'DB ready';
            exit(0);
        } catch (Exception \$e) { exit(1); }
    " 2>/dev/null; then
        DB_READY=1
        break
    fi
    echo "DB not ready, retry $i/40..."
    sleep 2
done
if [ "$DB_READY" -ne 1 ]; then
    echo "ERROR: database not reachable after 40 attempts — aborting entrypoint."
    echo "       (container restart will retry; check db service / credentials)"
    exit 1
fi

# Run migrations (idempotent, fail-closed: the container must not come up
# on an unmigrated schema — real output stays in docker logs, and a non-zero
# migration exit aborts the entrypoint instead of being swallowed by a WARN).
# NOTE: the registered CLI command name is `migration` (bootstrap/app.php),
# not `migrate` — the old call failed with "Command not found" (exit 1).
# FIX-9a-1: migration به‌عنوان کاربر اپ اجرا می‌شود (سپر root در cli.php بوت را
# نمی‌بندد) و فایل‌های cache/log تولیدشده مالکیت درست (www-data) دارند.
echo "Running migrations..."
if run_as_app php cli.php migration --force; then
    echo "Migrations OK."
else
    MIGRATION_EXIT=$?
    echo "ERROR: migration command failed (exit $MIGRATION_EXIT) — aborting entrypoint; see output above." >&2
    exit "$MIGRATION_EXIT"
fi

# Seed minimal admin + test users if table is empty.
# SECURITY (parity with FIX-S20-3 in seed_initial_data): known-password
# accounts (123456) must never be created in a production environment.
# APP_ENV is provided by docker-compose (APP_ENV: production) or --env-file.
# Fail-closed: when APP_ENV is unset/unknown, seeding is refused.
echo "Checking default user seeding..."
if [ "${APP_ENV:-production}" = "production" ]; then
    echo "WARN: APP_ENV=production — default user seeding REFUSED."
    echo "      Provide the initial admin via ADMIN_EMAIL + ADMIN_PASSWORD env vars"
    echo "      (consumed by the seed_initial_data migration) or create the user manually."
else
    echo "Seeding default users if needed..."
    run_as_app php -r '
try {
    $pdo = new PDO("mysql:host=".$_ENV["DB_HOST"].";port=".$_ENV["DB_PORT"].";dbname=".$_ENV["DB_NAME"], $_ENV["DB_USER"], $_ENV["DB_PASS"]);
    $count = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($count == 0) {
        $hash = password_hash("123456", PASSWORD_DEFAULT);
        $pdo->exec("INSERT IGNORE INTO users (email, password, role, status, kyc_status, created_at, updated_at) VALUES
            (\"admin@chortke.ir\", \"$hash\", \"admin\", \"active\", \"verified\", NOW(), NOW()),
            (\"superadmin@chortke.ir\", \"$hash\", \"superadmin\", \"active\", \"verified\", NOW(), NOW()),
            (\"testuser@chortke.ir\", \"$hash\", \"user\", \"active\", \"unverified\", NOW(), NOW())
        ");
        echo "Default users created.\n";
    } else {
        echo "Users table has $count rows.\n";
    }
} catch (Exception $e) {
    echo "User seeding skipped: " . $e->getMessage() . "\n";
}
'
fi

echo "=== Chortke container ready ==="

# FIX-9a-1: exec نهایی — فقط supervisord به‌عنوان root می‌ماند (برای setuid
# برنامه‌ها با user=www-data و crond؛ طبق docker/supervisord.conf)؛ هر فرمان
# دیگری (مثلاً `php cli.php queue:work` در سرویس‌های worker) به کاربر اپ
# drop می‌شود تا سپر root در cli.php بوت ورکرها را نبندد.
if is_root; then
    case "$1" in
        *supervisord*)
            exec "$@"
            ;;
        *)
            exec gosu "${APP_USER}" "$@"
            ;;
    esac
fi

exec "$@"
