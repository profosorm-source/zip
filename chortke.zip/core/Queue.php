<?php

declare(strict_types=1);

namespace Core;

use DateTime;

/**
 * Queue System - سیستم صف دوگانه‌سوز (مبتنی بر Redis با Fallback به دیتابیس)
 *
 * جدول queues (برای حالت دیتابیس):
 * - id (primary key)
 * - queue (نام صف)
 * - payload (داده JSON)
 * - attempts (تعداد تلاش)
 * - reserved_at (زمان رزرو)
 * - available_at (زمان قابل دسترس)
 * - created_at
 */
class Queue
{
    private Database $db;
    private Cache $cache;
    private string $defaultQueue = 'default';
    private int $maxAttempts = 5;

    private ?\Redis $redis = null;
    private string $redisPrefix = 'chortke:queue';

    public function __construct(Database $db, Cache $cache, ?string $driver = null) {
        $this->db = $db;
        $this->cache = $cache;

        // سقف تلاش‌ها از کانفیگ خوانده می‌شود تا با فلگ --tries ورکرها (supervisor) هم‌راستا باشد
        // (پیش‌فرض صریح ۵ — اگر کانفیگ در دسترس نباشد سقف به‌طور تصادفی ۱ نمی‌شود)
        $this->maxAttempts = max(1, min(20, int_value(config('queue.max_attempts', 5), 5)));

        $driver ??= config('queue.driver', 'database');
        if (!is_string($driver) || !in_array($driver, ['database', 'redis'], true)) {
            throw new \InvalidArgumentException("Queue driver must be either 'database' or 'redis'.");
        }

        if ($driver === 'database') {
            return;
        }

        $redis = $cache->redis();
        if ($redis === null) {
            // FIX-OP1 (یافتهٔ نوبت تست مرورگری): با قطع Redis، سازندهٔ Queue در چرخهٔ
            // درخواست وب شلیک می‌شد (EventDispatcher → Queue در Container) و استثنای
            // هندل‌نشده به پاسخ 500 می‌رسید — در حالی که سرصفحهٔ همین کلاس «Fallback
            // به دیتابیس» را طراحی اعلام کرده و همهٔ عملیات push/pop/delete/release
            // از قبل روی $this->redis === null مسیر کامل database driver دارند.
            // اکنون: در وب، queue در بدو ساخت به درایور دیتابیس تنزل می‌کند (بدون
            // هیچ fallback میان‌عملیاتی — نگرانی «cross-driver fallback» مطرح نیست
            // چون نمونه از بدو تولد صرفاً database است). در CLI (workerها) رفتار
            // fail-loud قبلی حفظ می‌شود تا ورکر رانتیم بدون درایور خودش بالا نیاید.
            if (PHP_SAPI === 'cli') {
                throw new \RuntimeException('Redis queue driver requires an active Redis connection.');
            }
            @error_log('[Queue] Redis unavailable at construction — web request degrades Queue to the documented database-driver fallback.');
            return;
        }

        $prefix = config('redis.prefix', 'chortke');
        if (!is_string($prefix) || trim($prefix) === '') {
            throw new \InvalidArgumentException('Redis queue prefix must be a non-empty string.');
        }

        $this->redis = $redis;
        $this->redisPrefix = rtrim($prefix, ':') . ':queue';
    }

    private function redisConnection(): \Redis
    {
        if ($this->redis === null) {
            throw new \LogicException('Redis queue operation attempted while database driver is active.');
        }

        return $this->redis;
    }

    private function normalizeQueueName(string $queue): string
    {
        if (
            $queue === ''
            || strlen($queue) > 128
            || strspn($queue, 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.:-') !== strlen($queue)
        ) {
            throw new \InvalidArgumentException('Queue name contains unsupported characters.');
        }

        return $queue;
    }

    private function queueNameFromMetadata(mixed $queue): string
    {
        if (!is_string($queue)) {
            throw new \UnexpectedValueException('Redis queue metadata does not contain a valid queue name.');
        }

        return $this->normalizeQueueName($queue);
    }

    /**
     * اضافه کردن job به صف
     */
    private function resolveQueueName(string $job, ?string $queue = null): string
    {
        if ($queue !== null && $queue !== '') {
            return $this->normalizeQueueName($queue);
        }

        $jobClass = $job;
        while (str_contains($jobClass, '\\\\')) {
            $jobClass = str_replace('\\\\', '\\', $jobClass);
        }
        $jobClass = trim($jobClass, '\\');

        // بررسی صفت به صورت داینامیک بدون نیاز به ساخت کلاس Attribute (Lazy Evaluation)
        try {
            if (class_exists($jobClass)) {
                $reflection = new \ReflectionClass($jobClass);
                foreach ($reflection->getAttributes() as $attribute) {
                    if (str_ends_with($attribute->getName(), 'Queue')) {
                        $args = $attribute->getArguments();
                        $attributeQueue = $args[0] ?? null;
                        if (is_string($attributeQueue) && $attributeQueue !== '') {
                            return $this->normalizeQueueName($attributeQueue);
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            // نادیده گرفتن خطاهای Reflection و رجوع به Fallback
        }

        $mapping = [
            // notifications
            'App\\Jobs\\SendEmailJob' => 'notifications',
            'App\\Jobs\\SendBulkNotificationJob' => 'notifications',
            'App\\Jobs\\PersistBulkInAppNotificationJob' => 'notifications',
            
            // analytics
            'App\\Jobs\\AggregateAnalyticsJob' => 'analytics',
            'App\\Jobs\\ScoreRecalculationJob' => 'analytics',
            'App\\Jobs\\LogPerformanceJob' => 'analytics',
            'App\\Jobs\\UpdateFraudScoreJob' => 'analytics',
            
            // maintenance
            'App\\Jobs\\EscrowTimeoutJob' => 'maintenance',
            'App\\Jobs\\CacheWarmupJob' => 'maintenance',
            'App\\Jobs\\NotificationCleanupJob' => 'maintenance',
            'App\\Jobs\\VitrineListingExpiryJob' => 'maintenance',
            'App\\Jobs\\InfluencerOrderTimeoutJob' => 'maintenance',
            'App\\Jobs\\SocialTaskApprovalReminderJob' => 'maintenance',
            'App\\Jobs\\PredictionGameSettlementJob' => 'maintenance',
            
            // high_priority
            'App\\Jobs\\ApplyWeeklyProfitLossJob' => 'high_priority',
            'App\\Jobs\\InvestmentProfitDistributionJob' => 'high_priority',
        ];

        return $mapping[$jobClass] ?? $this->defaultQueue;
    }

    /**
     * سیستم کنترل ترافیک (Backpressure)
     * در زمان پیک ترافیک اگر سایز صف از حد مجاز بگذرد، درج جاب مسدود می‌شود.
     */
    private function checkBackpressure(string $queue): void
    {
        // سقف مجاز برای صف‌ها را می‌توانیم از تنظیمات بگیریم یا سخت‌افزاری تعیین کنیم
        $limits = [
            'high_priority' => 50000,
            'default' => 100000,
            'analytics' => 5000,
            'notifications' => 20000,
            'maintenance' => 1000,
        ];
        
        $limit = $limits[$queue] ?? 10000;
        
        // کش کردن سایز به مدت ۵ ثانیه برای جلوگیری از سربار I/O هنگام چک کردن سایز
        $cache = $this->cache;
        $cacheKey = "queue_size_cache:{$queue}";
        
        $size = int_value($cache->rememberSeconds($cacheKey, 5, fn() => $this->size($queue)));
        
        if ($size >= $limit) {
            if (function_exists('logger')) { logger()->critical('queue.backpressure.activated', [
                    'queue' => $queue,
                    'size' => $size,
                    'limit' => $limit
                ]); }
            throw new \RuntimeException("Backpressure Active: Queue {$queue} is full (size: {$size}). Please try again later.");
        }
    }

    /**
     * اضافه کردن job به صف
     */
    /** @param array<string, mixed> $data */
    public function push(string $job, array $data = [], ?string $queue = null, int $delay = 0): bool
    {
        $normalizedJob = $job;
        while (str_contains($normalizedJob, '\\\\')) {
            $normalizedJob = str_replace('\\\\', '\\', $normalizedJob);
        }
        $normalizedJob = trim($normalizedJob, '\\');

        $queue = $this->resolveQueueName($normalizedJob, $queue);
        $this->checkBackpressure($queue);
        $availableAt = $delay > 0 ? time() + $delay : time();

        // 🚀 Real-time delta-buffering to eliminate propagation delay/race conditions during async updates!
        if ($normalizedJob === 'App\\Jobs\\UpdateFraudScoreJob') {
            $userId = int_value($data['user_id'] ?? 0);
            $delta  = float_value($data['delta'] ?? 0);
            $domain = str_value($data['domain'] ?? 'fraud');
            
            if ($userId > 0 && $delta !== 0.0) {
                try {
                    $cache = $this->cache;
                    $tempKey = "temp_{$domain}_score:{$userId}";
                    $cache->incrementFloat($tempKey, $delta);
                    $cache->forget("user_score:{$userId}:{$domain}");
                } catch (\Throwable $e) {
                    if (function_exists('logger')) { logger()->warning('queue.delta_buffer.failed', [
                            'user_id' => $userId,
                            'domain' => $domain,
                            'delta' => $delta,
                            'error' => $e->getMessage()
                        ]); }
                }
            }
        }

        // اگر Redis فعال باشد، تلاش برای درج در صف Redis
        if ($this->redis !== null) {
            // R30 FIX: نتیجهٔ json_encode قبل از هر incremento چک می‌شود (fail-loud) —
            // UTF-8 نامعتبر false برمی‌گرداند و قبلاً payload خراب ثبت می‌شد.
            $payloadJson = json_encode([
                'job' => $normalizedJob,
                'data' => $data,
                // FIX-S4-6: meta همبستگی فقط از مسیر validated (traceMeta)
                'meta' => $this->traceMeta(),
            ], JSON_UNESCAPED_UNICODE);
            if ($payloadJson === false) {
                throw new \RuntimeException(
                    'Queue payload is not JSON-encodable (invalid UTF-8?; json error: ' . json_last_error_msg() . ') — refusing to enqueue a corrupt job.'
                );
            }

            try {
                // دریافت شناسه عددی و اتمیک یکتا برای سازگاری کامل با شناسه دیتابیس
                $jobId = (int) $this->redisConnection()->incr("{$this->redisPrefix}:job_id_counter");

                $jobData = [
                    'id' => $jobId,
                    'queue' => $queue,
                    'payload' => $payloadJson,
                    'attempts' => 0,
                    'available_at' => $availableAt,
                    'created_at' => time(),
                    'reserved_at' => null,
                ];

                // FIX-9a-6 (Audit Task 9-a): TTL متادیتا مقیاس‌پذیر با تأخیر — قبلاً
                // ۷ روز ثابت بود؛ جاب با delay طولانی‌تر (مثلاً ۳۰ روز) قبل از pop
                // متادیتایش منقضی می‌شد و در pop به orphan برخورد می‌کرد (جاب گم‌شده).
                // اکنون TTL = max(7 روز, delay + 7 روز).
                $metadataJson = json_encode($jobData);
                if ($metadataJson === false) {
                    throw new \RuntimeException(
                        'Queue metadata is not JSON-encodable (json error: ' . json_last_error_msg() . ').'
                    );
                }
                $metadataTtl = 86400 * 7 + max(0, $delay);

                // FIX-9a-6: درج اتمیک — قبلاً setEx و zAdd دو دستور جدا بودند؛ کرش/قطعی
                // بین این دو، متادیتا یا عضو pending را یتیم می‌گذاشت. اکنون هر دو در
                // یک اسکریپت Lua (اتمیک) اجرا می‌شوند — الگوی release/popSingleQueue.
                $this->runRedisEval(
                    <<<LUA
                        local jobDataKey = KEYS[1]
                        local pendingKey = KEYS[2]
                        local ttl = tonumber(ARGV[1])
                        local metadata = ARGV[2]
                        local availableAt = tonumber(ARGV[3])

                        redis.call('setEx', jobDataKey, ttl, metadata)
                        redis.call('zAdd', pendingKey, availableAt, ARGV[4])
                        return 1
LUA,
                    [
                        "{$this->redisPrefix}:job:{$jobId}",
                        "{$this->redisPrefix}:{$queue}:pending",
                        $metadataTtl,
                        $metadataJson,
                        $availableAt,
                        (string)$jobId,
                    ],
                    2
                );

                return true;
            } catch (\Throwable $e) {
                if (function_exists('logger')) { logger()->error('queue.redis.push_failed', [
                        'job' => $job,
                        'queue' => $queue,
                        'error' => $e->getMessage(),
                        'outcome' => 'ambiguous',
                    ]); }
                throw new \RuntimeException(
                    'Redis queue push failed with an ambiguous outcome; refusing cross-driver fallback.',
                    0,
                    $e
                );
            }
        }

        // Explicit database driver path.
        // R30 FIX: نتیجهٔ encode قبل از insert چک می‌شود (fail-loud) — به‌جای
        // ثبت payload خراب، RuntimeException شفاف پرتاب می‌شود.
        $payloadJson = json_encode([
            'job' => $normalizedJob,
            'data' => $data,
            // FIX-S4-6: meta همبستگی فقط از مسیر validated (traceMeta)
            'meta' => $this->traceMeta(),
        ], JSON_UNESCAPED_UNICODE);
        if ($payloadJson === false) {
            throw new \RuntimeException(
                'Queue payload is not JSON-encodable (invalid UTF-8?; json error: ' . json_last_error_msg() . ') — refusing to insert a corrupt job.'
            );
        }
        $result = $this->db->table('queues')->insert([
            'queue' => $queue,
            'payload' => $payloadJson,
            'attempts' => 0,
            'available_at' => date('Y-m-d H:i:s', $availableAt),
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return (bool)$result;
    }

    /**
     * FIX-S4-6: ساخت meta همبستگی برای payload صف — فقط از مسیرهای validated
     * (get_request_id/get_trace_context). قبلاً هدرهای خام کاربر (HTTP_X_REQUEST_ID /
     * HTTP_X_TRACE_ID) بدون الگو/سقف وارد payload جاب می‌شدند و در لاگ‌های worker
     * جریان می‌یافتند (یادداشت معلق بچ S3). در نبود helpers → مقدار امن/null.
     *
     * @return array{correlation_id: ?string, trace_id: ?string}
     */
    private function traceMeta(): array
    {
        $traceContext = function_exists('get_trace_context') ? get_trace_context() : [];

        return [
            'correlation_id' => function_exists('get_request_id')
                ? get_request_id()
                : ($_SERVER['REQUEST_ID'] ?? null),
            'trace_id' => is_array($traceContext) && is_string($traceContext['trace_id'] ?? null)
                ? $traceContext['trace_id']
                : null,
        ];
    }

    /**
     * Push a job only once for a bounded time-window.
     *
     * این پیاده‌سازی بدون نیاز به migration جدید و با استفاده از Cache atomic counter کار می‌کند.
     * در production اگر Redis موجود نباشد، Core\Cache طبق سیاست fail-closed خطا می‌دهد تا duplicateهای خطرناک ایجاد نشود.
     */
    /** @param array<string, mixed> $data */
    public function pushUnique(
        string $job,
        array $data = [],
        string $dedupKey = '',
        ?string $queue = null,
        int $delay = 0,
        int $uniqueForSeconds = 86400
    ): bool {
        $queue = $this->resolveQueueName($job, $queue);
        $dedupKey = trim((string)$dedupKey);

        if ($dedupKey === '') {
            return $this->push($job, $data, $queue, $delay);
        }

        $cacheKey = 'queue_dedup:' . $queue . ':' . hash('sha256', $dedupKey);
        $count = $this->cache->increment($cacheKey, 1, max(60, $uniqueForSeconds));

        if ($count !== 1) {
            if (function_exists('logger')) { logger()->info('queue.unique_duplicate_skipped', [
                    'queue' => $queue,
                    'job' => $job,
                    'dedup_key' => $dedupKey,
                ]); }
            return false;
        }

        try {
            $pushed = $this->push($job, $data, $queue, $delay);

            // FIX-M6-08: بازگشتِ «تمیز» false از push (مسیر DB: insert ناموفق بدون
            // استثنا) یعنی جاب واقعاً درج نشده — claim باقی‌مانده کلید dedup را تا
            // TTL (تا ۱ روز) قفل می‌کرد و هر enqueue مشروع بعدی با همان کلید
            // duplicate شناخته و رد می‌شد (کار از دست رفته). اکنون claim آزاد
            // می‌شود تا تلاش بعدی آزاد باشد. (مسیر استثنا عمداً مثل قبل: FIX-R2-14
            // outcome مبهم دارد و forget بی‌قید retry مشروع را به duplicate تبدیل می‌کرد.)
            if ($pushed === false) {
                $this->cache->forget($cacheKey);
                if (function_exists('logger')) {
                    logger()->warning('queue.unique_claim_released_on_push_false', [
                        'queue' => $queue,
                        'job' => $job,
                        'dedup_key' => $dedupKey,
                    ]);
                }
            }

            return $pushed;
        } catch (\Throwable $e) {
            // FIX-R2-14: خطای push «مبهم» است (خود push در مسیر Redis/DB صراحتاً
            // outcome:'ambiguous' لاگ می‌کند) — ممکن است enqueue واقعاً پذیرفته شده
            // باشد و استثنا فقط در شبکه/commit رخ داده باشد. forgetِ بی‌قید و شرطِ
            // کلید dedup در این حالت، retry بعدی را به duplicate تبدیل می‌کرد.
            // اکنون کلید حذف نمی‌شود؛ به یک «مهلت کوتاه» کوتاه‌شدن TTL می‌یابد:
            // داخل پنجرهٔ grace حذف مضاعف مسدود می‌ماند و retry مشروع پس از آن
            // مثل قبل آزاد است (backoffهای صف از این مهلت بلندترند).
            $graceSeconds = max(60, min(300, $uniqueForSeconds));
            $currentCount = $this->cache->get($cacheKey);
            if ($currentCount !== null) {
                $this->cache->putSeconds($cacheKey, $currentCount, $graceSeconds);
            } else {
                $this->cache->forget($cacheKey);
            }
            throw $e;
        }
    }

    /**
     * برداشتن جاب از صف با پشتیبانی از اولویت‌بندی
     */
    /** @return array<string, mixed>|null */
    public function pop(?string $queue = null): ?array
    {
        if ($queue === null) {
            $priorities = ['high_priority', 'default', 'notifications', 'analytics', 'maintenance'];
            foreach ($priorities as $q) {
                $job = $this->popSingleQueue($q);
                if ($job) {
                    return $job;
                }
            }
            return null;
        }

        return $this->popSingleQueue($this->normalizeQueueName($queue));
    }

    /** @param array<int, mixed> $args */
    protected function runRedisEval(string $script, array $args, int $numKeys): mixed
    {
        return $this->redisConnection()->eval($script, $args, $numKeys);
    }

    /**
     * برداشتن جاب از یک صف مشخص
     */
    /** @return array<string, mixed>|null */
    private function popSingleQueue(string $queue): ?array
    {
        if ($this->redis !== null) {
            try {
                $now = time();
                $visibilityTimeout = int_value(config('queue.visibility_timeout', 90));
                $reservedUntil = $now + $visibilityTimeout;

                // ۱. مکانیزم Self-healing خودکار برای جاب‌های منقضی شده در وضعیت reserved
                // بازگرداندن جاب‌هایی که زمان رزروشان سر رسیده است به صف آماده جهت جلوگیری از استاک شدن
                $expiredScript = <<<LUA
                    local pendingKey = KEYS[1]
                    local reservedKey = KEYS[2]
                    local now = tonumber(ARGV[1])
                    
                    local expiredJobs = redis.call('zRangeByScore', reservedKey, 0, now)
                    for i, jobId in ipairs(expiredJobs) do
                        redis.call('zRem', reservedKey, jobId)
                        redis.call('zAdd', pendingKey, now, jobId)
                    end
                    return #expiredJobs
LUA;
                $this->runRedisEval(
                    $expiredScript,
                    ["{$this->redisPrefix}:{$queue}:pending", "{$this->redisPrefix}:{$queue}:reserved", $now],
                    2
                );

                // ۲. برداشتن اتمیک جاب آماده به کمک اسکریپت لونا و انتقال آن به لیست رزرو شده
                // FIX-9a-3 (Audit Task 9-a): توکن رزرو یکتا برای هر pop — پیش‌تر جاب فقط
                // با id+زمانِ رزرو شناسایی می‌شد؛ ورکر stall‌شده می‌توانست keepAlive/
                // release/fail/delete جابی را که ورکر دیگری (پس از انقضای visibility و
                // پاپِ دوباره) مالکیت کرده بود دستکاری کند (اثر مضاعف/اجراهای گم‌شده).
                // اکنون توکن در همان اسکریپت اتمیکِ pop در کلید جداگانه (job:rt:{id})
                // با TTL برابر visibility می‌نشیند و همهٔ عملیات چرخهٔ عمر با
                // مقایسهٔ اتمیک توکن (Lua compare-and-act) گیت می‌شوند.
                $reservationToken = bin2hex(random_bytes(16));

                $popScript = <<<LUA
                    local pendingKey = KEYS[1]
                    local reservedKey = KEYS[2]
                    local rtKeyPrefix = KEYS[3]
                    local now = tonumber(ARGV[1])
                    local reservedUntil = tonumber(ARGV[2])
                    local token = ARGV[3]
                    local rtTtl = tonumber(ARGV[4])

                    local jobs = redis.call('zRangeByScore', pendingKey, 0, now, 'LIMIT', 0, 1)
                    if #jobs > 0 then
                        local jobId = jobs[1]
                        redis.call('zRem', pendingKey, jobId)
                        redis.call('zAdd', reservedKey, reservedUntil, jobId)
                        redis.call('setEx', rtKeyPrefix .. jobId, rtTtl, token)
                        return jobId
                    end
                    return nil
LUA;

                // BUGFIX-PHASE3-P318: مسیر orphan (متادیتای گم‌شده) قبلاً با فراخوانی
                // بازگشتی popSingleQueue ادامه می‌یافت؛ در حالت پاتولوژیک (دنبالهٔ طولانی
                // جاب‌های بی‌متادیتا) عمق بازگشت بی‌کران بود. اکنون حلقهٔ محدود با سقف ۵۰
                // orphan پیاپی — همان معناشناسی، بدون ریسک stack overflow.
                $maxOrphanSweeps = 50;
                $orphanSweeps = 0;

                while (true) {
                    $jobId = $this->runRedisEval(
                        $popScript,
                        [
                            "{$this->redisPrefix}:{$queue}:pending",
                            "{$this->redisPrefix}:{$queue}:reserved",
                            "{$this->redisPrefix}:job:rt:",
                            $now,
                            $reservedUntil,
                            $reservationToken,
                            $visibilityTimeout,
                        ],
                        3
                    );

                    if (!$jobId) {
                        return null;
                    }

                    $jobId = int_value($jobId);

                    // ۳. خواندن اطلاعات کامل جاب
                    $jobDataJson = $this->redisConnection()->get("{$this->redisPrefix}:job:{$jobId}");
                    if ($jobDataJson) {
                        break; // جاب سالم — ادامهٔ پردازش بیرون از حلقه
                    }

                    // در صورت از بین رفتن متادیتا، جاب را از لیست رزرو شده حذف کرده و به جاب بعدی می‌رویم
                    $orphanSweeps++;
                    $this->redisConnection()->zRem("{$this->redisPrefix}:{$queue}:reserved", (string)$jobId);
                    // FIX-9a-3: کلید توکنِ رزروِ یتیم هم پاک شود (TTL پشتیبان دارد)
                    $this->redisConnection()->del("{$this->redisPrefix}:job:rt:{$jobId}");
                    if ($orphanSweeps >= $maxOrphanSweeps) {
                        if (function_exists('logger')) { logger()->warning('queue.redis.pop_orphan_sweep_limit', [
                                'queue' => $queue,
                                'limit' => $maxOrphanSweeps,
                            ]); }
                        return null;
                    }
                }

                $decodedJobData = json_decode(str_value($jobDataJson), true);
                $jobData = is_array($decodedJobData) ? $decodedJobData : [];
                $rawAttempts = $jobData['attempts'] ?? 0;
                $attempts = is_int($rawAttempts) || (is_string($rawAttempts) && is_numeric($rawAttempts))
                    ? (int)$rawAttempts
                    : 0;
                $newAttempts = $attempts + 1;

                // به‌روزرسانی تعداد تلاش‌ها و زمان رزرو
                $jobData['attempts'] = $newAttempts;
                $jobData['reserved_at'] = $now;
                $this->redisConnection()->setEx("{$this->redisPrefix}:job:{$jobId}", 86400 * 7, json_encode($jobData));

                $payload = (array)json_decode($jobData['payload'], true);

                return [
                    'id' => $jobId,
                    'job' => $payload['job'] ?? '',
                    'data' => $payload['data'] ?? [],
                    'meta' => $payload['meta'] ?? [],
                    'attempts' => $newAttempts,
                    // H-24 FIX: نام صف واقعی — قبلاً pop() کلید queue برنمی‌گرداند و
                    // QueueWorker (خط handleJob) برای keepAlive همیشه 'default' را تمدید
                    // می‌کرد؛ یعنی جاب طولانی در صف غیر-default پس از visibility_timeout
                    // دوباره pop می‌شد (اجران دوبله — مثلاً ایمیل دوبله).
                    'queue' => $queue,
                    // FIX-9a-3: توکن مالکیت این رزرو — QueueWorker آن را در keepAlive/
                    // ack(delete)/release/fail عبور می‌دهد تا فقط مالک فعلی بتواند عمل کند.
                    'reservation_token' => $reservationToken,
                ];
            } catch (\Throwable $e) {
                if (function_exists('logger')) { logger()->error('queue.redis.pop_failed', [
                        'queue' => $queue,
                        'error' => $e->getMessage(),
                        'outcome' => 'ambiguous',
                    ]); }
                throw new \RuntimeException(
                    'Redis queue pop failed with an ambiguous reservation outcome; refusing cross-driver fallback.',
                    0,
                    $e
                );
            }
        }

        // Explicit database driver path.
        // FIX-M6-05: قبل از pop، ردیف‌های stranded بازیابی می‌شوند — جابی که در
        // «آخرین attempt» workerش قبل از fail() کرش کند دیگر واجد شرایط pop نیست
        // (attempts >= max) و بدون reaper برای همیشه نه در صف قابل اجراست نه در
        // failed_jobs قابل مانیتورینگ (تا حذف بی‌صدای clean()).
        /*
        | FIX-YAFTE7 (یافته ۷): محاسبهٔ visibility/threshold از داخل try-block
        | به بالای فراخوانی reaper منتقل شد — قبلاً reapExpiredMaxAttemptJobs
        | با $timeoutThresholdِ «تعریف‌نشده» صدا زده می‌شد (undefined variable
        | → null) و reaper عملاً بدون آستانهٔ زمانی کار می‌کرد.
        */
        // CORE-046: Use configurable visibility timeout from configs, fallback to 90s.
        $visibilityTimeout = int_value(config('queue.visibility_timeout', 90));
        $timeoutThreshold = date('Y-m-d H:i:s', time() - $visibilityTimeout);
        $this->reapExpiredMaxAttemptJobs($queue, $timeoutThreshold);

        try {
            $this->db->beginTransaction();

            $nowStr = date('Y-m-d H:i:s');

            // SELECT ... FOR UPDATE SKIP LOCKED — ورکرها سطرهای قفل‌شده رو رد میکنن
            // SKIP LOCKED از MySQL 8.0+ — جلوگیری از Lock Contention بین ورکرهای همزمان
            $job = $this->db->selectOne(
                "SELECT * FROM queues
                 WHERE queue = :queue
                   AND attempts < :max_attempts
                   AND available_at <= :now
                   AND (reserved_at IS NULL OR reserved_at <= :timeout)
                 ORDER BY created_at ASC
                 LIMIT 1 FOR UPDATE SKIP LOCKED",
                [
                    'queue' => $queue,
                    'max_attempts' => $this->maxAttempts,
                    'now' => $nowStr,
                    'timeout' => $timeoutThreshold
                ]
            );

            if (!$job) {
                $this->db->commit();
                return null;
            }

            $reservedAt = date('Y-m-d H:i:s');
            $newAttempts = (int)$job->attempts + 1;

            // FIX-9a-3 (Audit Task 9-a): توکن رزرو یکتا — در همان تراکنشِ قفل‌دار
            // (SELECT ... FOR UPDATE) به ردیف الصاق می‌شود؛ همهٔ عملیات چرخهٔ عمر
            // (keepAlive/ack/release/fail) با WHERE reservation_token = ? اتمیک گیت می‌شوند.
            // deploy-order safety: اگر migration هنوز اجرا نشده (ستون غایب)، همان رفتار
            // legacy (بدون توکن) حفظ می‌شود تا صف هرگز به ستون جدید hard-depend نشود.
            $reservationToken = $this->reservationTokenColumnAvailable()
                ? bin2hex(random_bytes(16))
                : null;

            $reservationSql = $reservationToken !== null
                ? ', reservation_token = :reservation_token'
                : '';
            $reservationParams = $reservationToken !== null
                ? ['reservation_token' => $reservationToken]
                : [];

            $this->db->execute(
                "UPDATE queues
                 SET reserved_at = :reserved_at, attempts = :attempts{$reservationSql}
                 WHERE id = :id",
                [
                    'reserved_at' => $reservedAt,
                    'attempts' => $newAttempts,
                    'id' => $job->id,
                    ...$reservationParams,
                ]
            );

            $this->db->commit();

            $payload = (array)json_decode($job->payload, true);

            return [
                'id' => (int)$job->id,
                'job' => $payload['job'] ?? '',
                'data' => $payload['data'] ?? [],
                'meta' => $payload['meta'] ?? [],
                'attempts' => $newAttempts,
                // H-24 FIX: نام صف واقعی (هم‌راستا با مسیر Redis) — heartbeat ورکر
                // و handleFailure باید نام صفی که جاب از آن pop شده را بدانند.
                'queue' => (string)$job->queue,
                // FIX-9a-3: توکن مالکیت (null = ستون هنوز migrate نشده — مسیر legacy)
                'reservation_token' => $reservationToken,
            ];
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    /**
     * FIX-M6-05: reaper تراکنشی جاب‌های stranded — رزروِ منقضی‌شده با
     * attempts >= max_attempts به failed_jobs منتقل و از queues حذف می‌شود.
     *
     * بدون این مسیر، جابی که workerاش در آخرین attempt پیش از fail() کرش کند،
     * پس از انقضای visibility برای همیشه «گم‌شدهٔ بی‌صدا» می‌شد: query رزرو
     * (attempts < max) دیگر آن را برنمی‌دارد و هیچ رکورد DLQ هم ساخته نمی‌شد.
     *
     * اتمیکی/قفل‌گذاری:
     *   - تراکنش مستقل (جدا از تراکنش pop) با SELECT ... FOR UPDATE SKIP LOCKED
     *     فقط روی ردیف‌های stranded → با pop هم‌زمان تداخل ردیفی ندارد.
     *   - fail() هم‌زمانِ worker قدیمی: اگر fail() اول قفل ردیف را بگیرد، reaper
     *     آن ردیف را نمی‌بیند (حذف‌شده)؛ اگر reaper اول بگیرد، fail() با SELECT
     *     خالی false می‌دهد — در هر دو جهت دقیقاً یک رکورد DLQ ساخته می‌شود.
     *   - idempotency با همان sourceKey مشترک failDatabaseJob
     *     ('database|' + id) و upsert ON DUPLICATE KEY تضمین می‌شود؛ اجرای مجدد
     *     reaper (یا fail موازی) رکورد duplicate نمی‌سازد.
     *   - throttle سی‌ثانیه‌ای per-process/per-queue برای صفر نشدن هزینهٔ polls
     *     خالی (بدون تأثیر بر صحت — فقط فاصلهٔ کشف تا ۳۰ ثانیه).
     *
     * شکست reaper حیاتی نیست (log فقط) و هرگز مسیر pop را نمی‌شکند.
     */
    private function reapExpiredMaxAttemptJobs(string $queue, string $timeoutThreshold): void
    {
        static $lastReapAt = [];
        $now = time();
        if (($lastReapAt[$queue] ?? 0) + 30 > $now) {
            return;
        }
        $lastReapAt[$queue] = $now;

        try {
            $this->db->beginTransaction();

            $stranded = $this->db->select(
                "SELECT * FROM queues
                 WHERE queue = :queue
                   AND reserved_at IS NOT NULL
                   AND reserved_at <= :timeout
                   AND attempts >= :max_attempts
                 ORDER BY reserved_at ASC
                 LIMIT 10
                 FOR UPDATE SKIP LOCKED",
                [
                    'queue' => $queue,
                    'timeout' => $timeoutThreshold,
                    'max_attempts' => $this->maxAttempts,
                ]
            );

            foreach ($stranded as $job) {
                $payload = $job->payload ?? null;
                if (!is_string($payload) || $payload === '') {
                    // ردیف بدون payload قابل انتقال به DLQ نیست؛ حذف با لاگ
                    // (نمی‌توانیم رکورد failed_jobs معنادار بنویسیم).
                    $this->db->execute('DELETE FROM queues WHERE id = :id', ['id' => $job->id]);
                    if (function_exists('logger')) {
                        logger()->warning('queue.reaper.dropped_payloadless_row', ['id' => $job->id, 'queue' => $queue]);
                    }
                    continue;
                }

                $this->upsertFailedJob(
                    'database',
                    hash('sha256', 'database|' . $job->id),
                    $this->queueNameFromMetadata($job->queue ?? null),
                    $payload,
                    new \RuntimeException(sprintf(
                        'Queue reaper: job exhausted max attempts (%d) while reserved and its lease expired without fail() — worker crash suspected.',
                        (int)$job->attempts
                    )),
                    'unknown',
                    'pending_analysis',
                    null
                );

                $deleted = $this->db->execute('DELETE FROM queues WHERE id = :id', ['id' => $job->id]);
                if ($deleted !== 1) {
                    throw new \RuntimeException('Queue reaper could not delete a stranded row.');
                }

                if (function_exists('logger')) {
                    logger()->warning('queue.reaper.max_attempt_stranded_reaped', [
                        'id' => $job->id,
                        'queue' => $queue,
                        'attempts' => $job->attempts,
                    ]);
                }
            }

            $this->db->commit();
        } catch (\Throwable $reapError) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            if (function_exists('logger')) {
                logger()->error('queue.reaper.failed', [
                    'queue' => $queue,
                    'error' => $reapError->getMessage(),
                ]);
            }
        }
    }

    /**
     * FIX-9a-3: deploy-order safety — ستون توکن رزرو تا اجرای migration 0004 وجود
     * ندارد. نتیجه یک‌بار در عمر پروسه کش می‌شود (کوئری information_schema سبک است).
     */
    private function reservationTokenColumnAvailable(): bool
    {
        static $available = null;
        if ($available !== null) {
            return $available;
        }

        try {
            $row = $this->db->fetch(
                "SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'queues'
                   AND COLUMN_NAME = 'reservation_token'"
            );
            $available = int_value($row->c ?? 0) > 0;
        } catch (\Throwable $e) {
            if (function_exists('logger')) {
                logger()->warning('queue.reservation_token.probe_failed', ['error' => $e->getMessage()]);
            }
            $available = false;
        }

        return $available;
    }

    /**
     * حذف job از صف (پس از اجرای موفق)
     * FIX-9a-3: پارامتر اختیاری $token — اگر عبور داده شود، حذف فقط وقتی انجام
     * می‌شود که این نمونه هنوز مالکِ رزرو باشد (compare-and-act اتمیک).
     */
    public function delete(int $id, ?string $token = null): bool
    {
        if ($this->redis !== null) {
            try {
                $jobDataJson = $this->redisConnection()->get("{$this->redisPrefix}:job:{$id}");
                if ($jobDataJson) {
                    $jobData = (array)(json_decode(str_value($jobDataJson), true) ?? []);
                    $queue = $this->queueNameFromMetadata($jobData['queue'] ?? null);

                    if ($token !== null) {
                        // FIX-9a-3: ack اتمیک مشروط به توکن — ورکر stall‌شده نمی‌تواند
                        // جابی را که ورکر دیگری مالکیت کرده حذف (ack) کند.
                        $ackScript = <<<LUA
                            local pendingKey = KEYS[1]
                            local reservedKey = KEYS[2]
                            local jobDataKey = KEYS[3]
                            local rtKey = KEYS[4]
                            local jobId = ARGV[1]
                            local token = ARGV[2]

                            if redis.call('get', rtKey) ~= token then
                                return 0
                            end
                            -- FIX-M6-16: ACK بدون عضویتِ زندهٔ reserved ممنوع —
                            -- اگر sweep منقضی، جاب را به pending برگردانده ولی کلید
                            -- توکن هنوز زنده است، holderِ توکن حق حذف pending/
                            -- متادیتای جابی را که مالک جدید برخواهد داشت ندارد.
                            if redis.call('zScore', reservedKey, jobId) == false then
                                return 0
                            end
                            redis.call('zRem', pendingKey, jobId)
                            redis.call('zRem', reservedKey, jobId)
                            redis.call('del', jobDataKey)
                            redis.call('del', rtKey)
                            return 1
LUA;
                        $result = $this->runRedisEval(
                            $ackScript,
                            [
                                "{$this->redisPrefix}:{$queue}:pending",
                                "{$this->redisPrefix}:{$queue}:reserved",
                                "{$this->redisPrefix}:job:{$id}",
                                "{$this->redisPrefix}:job:rt:{$id}",
                                (string)$id,
                                $token,
                            ],
                            4
                        );
                        return int_value($result) === 1;
                    }

                    $this->redisConnection()->zRem("{$this->redisPrefix}:{$queue}:pending", (string)$id);
                    $this->redisConnection()->zRem("{$this->redisPrefix}:{$queue}:reserved", (string)$id);
                    $this->redisConnection()->del("{$this->redisPrefix}:job:rt:{$id}");
                    $this->redisConnection()->del("{$this->redisPrefix}:job:{$id}");
                    return true;
                }
                return false;
            } catch (\Throwable $e) {
                if (function_exists('logger')) { logger()->error('queue.redis.delete_failed', [
                        'id' => $id,
                        'error' => $e->getMessage(),
                        'outcome' => 'ambiguous',
                    ]); }
                throw new \RuntimeException(
                    'Redis queue delete failed with an ambiguous outcome; refusing cross-driver fallback.',
                    0,
                    $e
                );
            }
        }

        // Explicit database driver path.
        // FIX-9a-3: با توکن، حذف فقط برای مالکِ فعلی رزرو (SQL WHERE token = ?) —
        // بدون توکن، رفتار legacy (حذف بی‌قید و شرط).
        if ($token !== null && $this->reservationTokenColumnAvailable()) {
            $deleted = $this->db->execute(
                'DELETE FROM queues WHERE id = :id AND reservation_token = :token',
                ['id' => $id, 'token' => $token]
            );
            return $deleted > 0;
        }

        $result = $this->db->table('queues')
            ->where('id', '=', $id)
            ->delete();

        return $result > 0;
    }

    /**
     * تمدید زمان رزرو جاب (Heartbeat) برای جلوگیری از بازگشت زودهنگام به صف در جاب‌های طولانی
     * FIX-9a-3: پارامتر اختیاری $token — تمدید فقط وقتی معتبر است که این نمونه هنوز
     * مالکِ رزرو باشد (Lua compare-token / SQL WHERE token = ?).
     */
    public function keepAlive(int $id, ?string $queue = null, int $extraTime = 90, ?string $token = null): bool
    {
        if ($queue !== null) {
            $queue = $this->normalizeQueueName($queue);
        }

        if ($this->redis !== null) {
            try {
                if ($queue === null) {
                    $jobDataJson = $this->redisConnection()->get("{$this->redisPrefix}:job:{$id}");
                    if (!$jobDataJson) return false;
                    $jobData = (array)(json_decode(str_value($jobDataJson), true) ?? []);
                    $queue = $this->queueNameFromMetadata($jobData['queue'] ?? null);
                }

                $newTimeout = time() + $extraTime;

                // FIX-9a-3: compare-and-act اتمیک — تمدید score فقط وقتی توکن همان مالکِ
                // فعلی رزرو باشد؛ وگرنه 0 ⇒ false (دستکاریِ رزرو مالک جدید ممنوع).
                // TTL کلید توکن هم هم‌زمان تمدید می‌شود تا با رزرو هم‌قدم بماند.
                if ($token !== null) {
                    $renewScript = <<<LUA
                        local reservedKey = KEYS[1]
                        local rtKey = KEYS[2]
                        local jobId = ARGV[1]
                        local token = ARGV[2]
                        local newTimeout = tonumber(ARGV[3])
                        local rtTtl = tonumber(ARGV[4])

                        if redis.call('get', rtKey) ~= token then
                            return 0
                        end
                        if redis.call('zScore', reservedKey, jobId) == false then
                            return 0
                        end
                        redis.call('zAdd', reservedKey, newTimeout, jobId)
                        redis.call('expire', rtKey, rtTtl)
                        return 1
LUA;
                    $renewed = $this->runRedisEval(
                        $renewScript,
                        [
                            "{$this->redisPrefix}:{$queue}:reserved",
                            "{$this->redisPrefix}:job:rt:{$id}",
                            (string)$id,
                            $token,
                            $newTimeout,
                            $extraTime,
                        ],
                        2
                    );
                    return int_value($renewed) === 1;
                }

                // Update score in reserved set to prevent self-healing script from grabbing it
                $score = $this->redisConnection()->zScore("{$this->redisPrefix}:{$queue}:reserved", (string)$id);
                if ($score !== false) {
                    $this->redisConnection()->zAdd("{$this->redisPrefix}:{$queue}:reserved", $newTimeout, (string)$id);
                    return true;
                }
                return false;
            } catch (\Throwable $e) {
                if (function_exists('logger')) { logger()->error('queue.redis.keepalive_failed', ['id' => $id, 'error' => $e->getMessage()]); }
                return false;
            }
        }

        // Database mode
        try {
            // BUGFIX-PHASE3-P36: قبلاً reserved_at = NOW() می‌شد ⇒ تمدید همیشه دقیقاً
            // به‌اندازهٔ visibility_timeout بود و پارامتر $extraTime نادیده گرفته می‌شد
            // (واگرایی با مسیر Redis که score = now + extraTime می‌گذارد).
            // انقضای مؤثر در DB = reserved_at + visibility_timeout؛ برای رسیدن به
            // انقضای now + extraTime، reserved_at به‌اندازهٔ اختلاف به عقب کشیده می‌شود
            // (اگر extraTime > visibility_timeout باشد، مقدار کمی در آینده می‌افتد که
            // انقضای درست را می‌سازد و در کوئری pop مشکلی ایجاد نمی‌کند).
            $visibilityTimeout = int_value(config('queue.visibility_timeout', 90));
            $newReservedAt = date('Y-m-d H:i:s', time() - ($visibilityTimeout - $extraTime));

            // FIX-9a-3: با توکن، تمدید فقط برای مالکِ فعلی رزرو (SQL WHERE token = ?) —
            // بدون توکن، رفتار legacy (تمدید بی‌قید و شرط).
            if ($token !== null && $this->reservationTokenColumnAvailable()) {
                $result = $this->db->execute(
                    "UPDATE queues SET reserved_at = :reserved_at
                     WHERE id = :id AND reserved_at IS NOT NULL AND reservation_token = :token",
                    ['reserved_at' => $newReservedAt, 'id' => $id, 'token' => $token]
                );
                return $result > 0;
            }

            $result = $this->db->execute(
                "UPDATE queues SET reserved_at = :reserved_at WHERE id = :id AND reserved_at IS NOT NULL",
                ['reserved_at' => $newReservedAt, 'id' => $id]
            );
            return $result > 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * بازگرداندن job به صف (برای retry با تاخیر نمایی)
     * FIX-9a-3: پارامتر اختیاری $token — آزادسازی فقط وقتی معتبر است که این نمونه
     * هنوز مالکِ رزرو باشد (در اسکریپت Lua و SQL گیت می‌شود).
     */
    public function release(int $id, int $delay = 0, ?string $token = null): bool
    {
        if ($this->redis !== null) {
            try {
                $jobDataJson = $this->redisConnection()->get("{$this->redisPrefix}:job:{$id}");
                if ($jobDataJson) {
                    $jobData = (array)(json_decode(str_value($jobDataJson), true) ?? []);
                    $queue = $this->queueNameFromMetadata($jobData['queue'] ?? null);
                    $attempts = int_value($jobData['attempts'] ?? 1);

                    if ($delay === 0) {
                        $baseDelay = 60; // 60 seconds
                        $exponential = $baseDelay * pow(2, $attempts - 1);
                        $jitter = rand(5, 45);
                        $delay = (int) min($exponential + $jitter, 14400); // Max 4 hours
                    }

                    $availableAt = time() + $delay;

                    $jobData['reserved_at'] = null;
                    $jobData['available_at'] = $availableAt;

                    $metadata = json_encode($jobData);
                    if ($metadata === false) {
                        // BUGFIX-PHASE3-P35: متادیتای غیرقابل‌encode نباید کلید job را خالی کند
                        if (function_exists('logger')) { logger()->error('queue.redis.release_metadata_encode_failed', ['id' => $id]); }
                        return false;
                    }

                    // BUGFIX-PHASE3-P35: قبلاً zRem(reserved) و zAdd(pending) دو دستور جدا بودند؛
                    // کرش/قطع اتصال بین این دو، جاب را از هر دو ست خارج می‌کرد و self-healing
                    // (که فقط reserved منقضی‌شده را می‌جوید) دیگر آن را پیدا نمی‌کرد ⇒ گم‌شدن
                    // دائمی جاب. اکنون همهٔ عملیات (بررسی عضویت reserved، setEx متادیتا، zRem و
                    // zAdd) در یک اسکریپت Lua اتمیک اجرا می‌شود — همان الگوی popSingleQueue.
                    // گیت zScore اجرای هم‌زمان دوباره‌کاری را منع می‌کند: اگر جاب دیگر در
                    // reserved نباشد (مثلاً self-healing آن را برگرانده و ورکر دیگری رزروش کرده)
                    // این release چیزی را overwrite نمی‌کند و false برمی‌گرداند.
                    // FIX-9a-3: گیت توکن — رزرو فقط با توکنِ مالک فعلی آزاد می‌شود؛
                    // رزرو ورکرِ دیگر (پس از انقضای visibility و پاپِ دوباره) دست‌نخورده می‌ماند.
                    $releaseScript = <<<LUA
                        local pendingKey = KEYS[1]
                        local reservedKey = KEYS[2]
                        local jobDataKey = KEYS[3]
                        local rtKey = KEYS[4]
                        local jobId = ARGV[1]
                        local availableAt = tonumber(ARGV[2])
                        local ttl = tonumber(ARGV[3])
                        local metadata = ARGV[4]
                        local token = ARGV[5]

                        if token ~= '' and redis.call('get', rtKey) ~= token then
                            return 0
                        end

                        if redis.call('zScore', reservedKey, jobId) == false then
                            return 0
                        end

                        redis.call('setEx', jobDataKey, ttl, metadata)
                        redis.call('zRem', reservedKey, jobId)
                        redis.call('zAdd', pendingKey, availableAt, jobId)
                        if token ~= '' then
                            redis.call('del', rtKey)
                        end
                        return 1
LUA;

                    $result = $this->runRedisEval(
                        $releaseScript,
                        [
                            "{$this->redisPrefix}:{$queue}:pending",
                            "{$this->redisPrefix}:{$queue}:reserved",
                            "{$this->redisPrefix}:job:{$id}",
                            "{$this->redisPrefix}:job:rt:{$id}",
                            (string)$id,
                            $availableAt,
                            86400 * 7,
                            $metadata,
                            is_string($token) ? $token : '',
                        ],
                        4
                    );

                    return int_value($result) === 1;
                }
                return false;
            } catch (\Throwable $e) {
                if (function_exists('logger')) { logger()->error('queue.redis.release_failed', [
                        'id' => $id,
                        'error' => $e->getMessage(),
                        'outcome' => 'ambiguous',
                    ]); }
                throw new \RuntimeException(
                    'Redis queue release failed with an ambiguous outcome; refusing cross-driver fallback.',
                    0,
                    $e
                );
            }
        }

        // Explicit database driver path.
        if ($delay === 0) {
            // Calculate delay based on attempts
            $job = $this->db->selectOne("SELECT attempts FROM queues WHERE id = :id", ['id' => $id]);
            $attempts = $job ? (int)$job->attempts : 1;

            $baseDelay = 60; // 60 seconds
            $exponential = $baseDelay * pow(2, $attempts - 1);
            $jitter = rand(5, 45);
            $delay = (int) min($exponential + $jitter, 14400); // Max 4 hours
        }

        $availableAt = time() + $delay;

        // FIX-9a-3: با توکن، آزادسازی فقط برای مالکِ فعلی رزرو (SQL WHERE token = ?) —
        // بدون توکن، رفتار legacy.
        if ($token !== null && $this->reservationTokenColumnAvailable()) {
            $result = $this->db->table('queues')
                ->where('id', '=', $id)
                ->where('reservation_token', '=', $token)
                ->update([
                    'reserved_at' => null,
                    'available_at' => date('Y-m-d H:i:s', $availableAt)
                ]);

            return $result > 0;
        }

        $result = $this->db->table('queues')
            ->where('id', '=', $id)
            ->update([
                'reserved_at' => null,
                'available_at' => date('Y-m-d H:i:s', $availableAt)
            ]);

        return $result > 0;
    }

    /**
     * پاک کردن jobهای قدیمی دیتابیس (فقط برای حالت دیتابیس لازم است؛ در Redis انقضا خودکار است)
     */
    public function clean(int $days = 7): int
    {
        $cutoff = date('Y-m-d H:i:s', (strtotime("-{$days} days") ?: time()));

        return $this->db->table('queues')
            ->where('created_at', '<', $cutoff)
            ->delete();
    }

    /**
     * شمارش jobهای موجود در صف
     */
    public function size(?string $queue = null): int
    {
        $queue = $this->normalizeQueueName($queue ?: $this->defaultQueue);

        if ($this->redis !== null) {
            try {
                $pending = $this->redisConnection()->zCard("{$this->redisPrefix}:{$queue}:pending");
                $reserved = $this->redisConnection()->zCard("{$this->redisPrefix}:{$queue}:reserved");
                return (int)($pending + $reserved);
            } catch (\Throwable $e) {
                if (function_exists('logger')) { logger()->error('queue.redis.size_failed', [
                        'queue' => $queue,
                        'error' => $e->getMessage(),
                    ]); }
                throw new \RuntimeException('Redis queue size is unavailable; refusing cross-driver fallback.', 0, $e);
            }
        }

        return (int) $this->db->table('queues')
            ->where('queue', '=', $queue)
            ->count();
    }

    /**
     * انتقال جاب شکست خورده نهایی به Dead Letter Queue (DLQ) و حذف از صف اصلی
     * FIX-9a-3: پارامتر اختیاری $token — فقط مالکِ فعلی رزرو حق DLQ کردن دارد؛
     * نمونهٔ stall‌شده‌ای که مالکیتش را از دست داده (visibility منقضی، جاب دوباره
     * پاپ شده) false می‌گیرد و جابِ مالک جدید دست‌نخورده می‌ماند.
     */
    public function fail(int $id, \Throwable $exception, string $errorClass = 'unknown', string $status = 'pending_analysis', ?int $nextRetryAt = null, ?string $token = null): bool
    {
        $errorClass = $this->normalizeDlqIdentifier($errorClass, 'error classification');
        $status = $this->normalizeDlqIdentifier($status, 'DLQ status');

        if ($this->redis !== null) {
            return $this->failRedisJob($id, $exception, $errorClass, $status, $nextRetryAt, $token);
        }

        return $this->failDatabaseJob($id, $exception, $errorClass, $status, $nextRetryAt, $token);
    }

    private function failRedisJob(
        int $id,
        \Throwable $exception,
        string $errorClass,
        string $status,
        ?int $nextRetryAt,
        ?string $token = null
    ): bool {
        // FIX-9a-3: گیت مالکیت — اگر توکن عبور داده شده و دیگر مطابقت ندارد
        // (رزرو منقضی و جاب به ورکر دیگری رسیده)، این نمونه حق DLQ کردن ندارد.
        if (is_string($token) && $token !== '') {
            $rt = $this->redisConnection()->get("{$this->redisPrefix}:job:rt:{$id}");
            if (!is_string($rt) || $rt !== $token) {
                if (function_exists('logger')) {
                    logger()->warning('queue.redis.fail_ownership_lost', [
                        'id' => $id,
                        'outcome' => 'reservation_lost',
                    ]);
                }
                return false;
            }
        }

        try {
            $rawMetadata = $this->redisConnection()->get("{$this->redisPrefix}:job:{$id}");
        } catch (\Throwable $e) {
            if (function_exists('logger')) {
                logger()->error('queue.redis.fail_read_failed', ['id' => $id, 'error' => $e->getMessage()]);
            }
            throw new \RuntimeException('Unable to read Redis job for durable DLQ transfer.', 0, $e);
        }

        if (!is_string($rawMetadata) || $rawMetadata === '') {
            return false;
        }

        $metadata = json_decode($rawMetadata, true);
        if (!is_array($metadata)) {
            throw new \UnexpectedValueException('Redis job metadata is not valid JSON.');
        }

        $queueName = $this->queueNameFromMetadata($metadata['queue'] ?? null);
        $payload = $metadata['payload'] ?? null;
        $createdAt = $metadata['created_at'] ?? null;
        if (!is_string($payload) || $payload === '') {
            throw new \UnexpectedValueException('Redis job metadata does not contain a valid payload.');
        }
        if (!is_int($createdAt) && !(is_string($createdAt) && ctype_digit($createdAt))) {
            throw new \UnexpectedValueException('Redis job metadata does not contain a valid creation timestamp.');
        }

        $sourceKey = hash(
            'sha256',
            'redis|' . $id . '|' . $queueName . '|' . (string)$createdAt . '|' . hash('sha256', $payload)
        );

        $persistedFailedJobId = $this->persistFailedJobIdempotently(
            'redis',
            $sourceKey,
            $queueName,
            $payload,
            $exception,
            $errorClass,
            $status,
            $nextRetryAt
        );

        try {
            // FIX-C03: حذفِ cleanup با توکنِ مالکیت به‌صورت اتمیک (Lua) گیت می‌شود.
            // قبلاً بین گیت یک‌بارهٔ بالا و deleteRedisJobByQueue هیچ اتمیکی نبود؛
            // انقضای visibility در همین فاصله اجازه می‌داد ورکر A کلیدهای جابی را
            // که ورکر B تازه رزروش کرده نابود کند (از دست رفتن تحویل/اثر مضاعف).
            $cleanupDeleted = $this->deleteRedisJobByQueue($id, $queueName, $token);
        } catch (\Throwable $e) {
            if (function_exists('logger')) {
                logger()->error('queue.redis.dlq_cleanup_pending', [
                    'id' => $id,
                    'queue' => $queueName,
                    'source_job_key' => $sourceKey,
                    'error' => $e->getMessage(),
                ]);
            }
            throw new \RuntimeException(
                'DLQ record committed but Redis cleanup is pending; retry is idempotent.',
                0,
                $e
            );
        }

        if ($cleanupDeleted === false) {
            // FIX-C03: مالکیت در فاصلهٔ persist→cleanup باخته شد (visibility منقضی،
            // ورکر B جاب را دوباره رزرو کرده). ردیف DLQ «حدسی» که همین حالا نوشتیم
            // حذف می‌شود تا جابِ زندهٔ B با رکورد failed_jobs کاذب سایه نگیرد؛
            // اگر B واقعاً شکست بخورد، upsert آیدیپوتنتِ خودش رکورد درست را می‌نویسد.
            if ($persistedFailedJobId !== null) {
                try {
                    $this->db->execute('DELETE FROM failed_jobs WHERE id = :id', ['id' => $persistedFailedJobId]);
                } catch (\Throwable $rollbackError) {
                    if (function_exists('logger')) {
                        logger()->warning('queue.redis.dlq_speculative_row_cleanup_failed', [
                            'failed_job_id' => $persistedFailedJobId,
                            'error' => $rollbackError->getMessage(),
                        ]);
                    }
                }
            }
            if (function_exists('logger')) {
                logger()->warning('queue.redis.fail_ownership_lost', [
                    'id' => $id,
                    'outcome' => 'reservation_lost_during_cleanup',
                ]);
            }
            return false;
        }

        return true;
    }

    private function failDatabaseJob(
        int $id,
        \Throwable $exception,
        string $errorClass,
        string $status,
        ?int $nextRetryAt,
        ?string $token = null
    ): bool {
        $this->db->beginTransaction();
        try {
            // FIX-9a-3: با توکن، فقط مالکِ فعلی رزرو می‌تواند ردیف را به DLQ ببرد.
            $ownershipSql = (is_string($token) && $token !== '' && $this->reservationTokenColumnAvailable())
                ? ' AND reservation_token = :token'
                : '';
            $params = ['id' => $id];
            if ($ownershipSql !== '') {
                $params['token'] = $token;
            }

            $job = $this->db->selectOne(
                "SELECT * FROM queues WHERE id = :id{$ownershipSql} FOR UPDATE",
                $params
            );
            if ($job === null) {
                $this->db->commit();
                return false;
            }

            $queueName = $this->queueNameFromMetadata($job->queue ?? null);
            $payload = $job->payload ?? null;
            if (!is_string($payload) || $payload === '') {
                throw new \UnexpectedValueException('Database queue row does not contain a valid payload.');
            }

            $this->upsertFailedJob(
                'database',
                hash('sha256', 'database|' . $id),
                $queueName,
                $payload,
                $exception,
                $errorClass,
                $status,
                $nextRetryAt
            );

            $deleted = $this->db->execute('DELETE FROM queues WHERE id = :id', ['id' => $id]);
            if ($deleted !== 1) {
                throw new \RuntimeException('Database queue row was not deleted during DLQ transfer.');
            }

            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    /**
     * FIX-C03: شناسهٔ ردیف failed_jobs نوشته‌شده برمی‌گردد تا در صورت باختِ
     * مالکیت در فاز cleanup، ردیف «حدسی» قابل حذف باشد.
     *
     * @return int|null شناسهٔ ردیف upsert‌شده (null فقط در حالت خطای خواندن)
     */
    private function persistFailedJobIdempotently(
        string $sourceDriver,
        string $sourceKey,
        string $queueName,
        string $payload,
        \Throwable $exception,
        string $errorClass,
        string $status,
        ?int $nextRetryAt
    ): ?int {
        $this->db->beginTransaction();
        try {
            $this->upsertFailedJob(
                $sourceDriver,
                $sourceKey,
                $queueName,
                $payload,
                $exception,
                $errorClass,
                $status,
                $nextRetryAt
            );
            $row = $this->db->fetch(
                'SELECT id FROM failed_jobs WHERE source_job_key = :sk',
                ['sk' => $sourceKey]
            );
            $id = $row !== null ? (int)($row->id ?? 0) : 0;
            $this->db->commit();
            return $id > 0 ? $id : null;
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    private function upsertFailedJob(
        string $sourceDriver,
        string $sourceKey,
        string $queueName,
        string $payload,
        \Throwable $exception,
        string $errorClass,
        string $status,
        ?int $nextRetryAt
    ): void {
        $exceptionText = get_class($exception) . ': ' . $exception->getMessage() . "\n" . $exception->getTraceAsString();
        $nextRetryFormatted = $nextRetryAt !== null ? date('Y-m-d H:i:s', $nextRetryAt) : null;

        // حافظهٔ پایدار تلاش‌های DLQ: شمارنده از دیتای payload بازخوانی و در ستون
        // retry_count ذخیره می‌شود تا سقف ۳ بازیابی هوشمند در QueueWorker بین
        // چرخه‌های صف↔DLQ حفظ شود (رفع حلقهٔ بی‌نهایت retry).
        $durableRetryCount = 0;
        $decodedPayload = json_decode($payload, true);
        if (is_array($decodedPayload) && is_array($decodedPayload['data'] ?? null)) {
            $durableRetryCount = max(
                int_value($decodedPayload['data']['_dlq_retry_count'] ?? 0),
                int_value($decodedPayload['data']['attempts'] ?? 0)
            );
        }

        $this->db->execute(
            'INSERT INTO failed_jobs '
            . '(source_driver,source_job_key,connection,queue,payload,exception,error_classification,status,retry_count,next_retry_at,failed_at) '
            . 'VALUES (:source_driver,:source_job_key,:connection,:queue,:payload,:exception,:classification,:status,:retry_count,:next_retry_at,NOW()) '
            . 'ON DUPLICATE KEY UPDATE '
            . 'exception=VALUES(exception),error_classification=VALUES(error_classification),'
            . 'status=VALUES(status),next_retry_at=VALUES(next_retry_at),'
            . 'retry_count=GREATEST(retry_count, VALUES(retry_count))',
            [
                'source_driver' => $sourceDriver,
                'source_job_key' => $sourceKey,
                'connection' => $sourceDriver,
                'queue' => $queueName,
                'payload' => $payload,
                'exception' => $exceptionText,
                'classification' => $errorClass,
                'status' => $status,
                'retry_count' => $durableRetryCount,
                'next_retry_at' => $nextRetryFormatted,
            ]
        );

        if (function_exists('logger')) {
            logger()->critical('queue_job_failed_dlq_persisted', [
                'queue' => $queueName,
                'source_driver' => $sourceDriver,
                'source_job_key' => $sourceKey,
                'classification' => $errorClass,
                'status' => $status,
            ]);
        }
    }

    /**
     * FIX-C03: حذف کلیدهای جاب Redis با گیت اتمیک توکن مالکیت.
     *
     * با توکن: یک اسکریپت Lua ابتدا `job:rt:{id}` را می‌خواند؛ اگر موجود و نامطابق
     * با توکن باشد هیچ کلیدی حذف نمی‌شود (false) — یعنی مالکیت به ورکر دیگری
     * رسیده و این نمونه حق نابود کردن رزرو جدید را ندارد. اگر rt غایب یا مطابق
     * باشد، zRem/del ها در همان اتمیک اجرا می‌شوند (بدون پنجرهٔ TOCTOU).
     * بدون توکن (مسیر legacy): رفتار قبلی حفظ می‌شود.
     */
    private function deleteRedisJobByQueue(int $id, string $queueName, ?string $token = null): bool
    {
        $redis = $this->redisConnection();
        $rtKey = "{$this->redisPrefix}:job:rt:{$id}";
        $jobKey = "{$this->redisPrefix}:job:{$id}";
        $pendingKey = "{$this->redisPrefix}:{$queueName}:pending";
        $reservedKey = "{$this->redisPrefix}:{$queueName}:reserved";

        if (is_string($token) && $token !== '') {
            $deleted = $this->runRedisEval(
                <<<LUA
                    local rt = redis.call('get', KEYS[1])
                    if rt and rt ~= ARGV[1] then
                        return 0
                    end
                    redis.call('zRem', KEYS[2], ARGV[2])
                    redis.call('zRem', KEYS[3], ARGV[2])
                    redis.call('del', KEYS[1])
                    redis.call('del', KEYS[4])
                    return 1
LUA,
                [
                    $rtKey,
                    $pendingKey,
                    $reservedKey,
                    $jobKey,
                    $token,
                    (string)$id,
                ],
                4
            );
            return (int)$deleted === 1;
        }

        $redis->zRem($pendingKey, (string)$id);
        $redis->zRem($reservedKey, (string)$id);
        // FIX-9a-3: کلید توکن رزرو هم پاک شود (TTL پشتیبان دارد)
        $redis->del($rtKey);
        $redis->del($jobKey);
        return true;
    }

    private function normalizeDlqIdentifier(string $value, string $label): string
    {
        if ($value === '' || strlen($value) > 32 || preg_match('/^[a-z][a-z0-9_]*$/', $value) !== 1) {
            throw new \InvalidArgumentException("Invalid {$label}.");
        }

        return $value;
    }

    /**
     * دریافت آمار Poison Messages
     */
    /** @return array<string, mixed> */
    public function getDlqMetrics(): array
    {
        try {
            $sql = "SELECT 
                        COUNT(*) as total_failed,
                        SUM(CASE WHEN error_classification = 'transient' THEN 1 ELSE 0 END) as transient_count,
                        SUM(CASE WHEN error_classification = 'permanent' THEN 1 ELSE 0 END) as permanent_count,
                        SUM(CASE WHEN error_classification = 'business' THEN 1 ELSE 0 END) as business_count,
                        SUM(CASE WHEN status = 'quarantined' THEN 1 ELSE 0 END) as quarantined_count,
                        SUM(CASE WHEN status = 'dead_letter' THEN 1 ELSE 0 END) as dead_letter_count,
                        SUM(CASE WHEN status = 'retrying' THEN 1 ELSE 0 END) as retrying_count
                    FROM failed_jobs";
            $row = $this->db->fetch($sql);
            
            return [
                'total' => (int)($row->total_failed ?? 0),
                'by_class' => [
                    'transient' => (int)($row->transient_count ?? 0),
                    'permanent' => (int)($row->permanent_count ?? 0),
                    'business'  => (int)($row->business_count ?? 0),
                ],
                'by_status' => [
                    'quarantined' => (int)($row->quarantined_count ?? 0),
                    'dead_letter' => (int)($row->dead_letter_count ?? 0),
                    'retrying'    => (int)($row->retrying_count ?? 0),
                ]
            ];
        } catch (\Throwable $e) {
            // BUGFIX-PHASE3-P319: خطا بی‌صدا قورت داده نمی‌شود — نابینایی مانیتورینگ DLQ
            // (خالی بودن metrics) باید در لاگ قابل‌تشخیص باشد. در PHPUnit لاگ اضافه نمی‌شود
            // تا خروجی تست کثیف نشود.
            if (function_exists('logger') && !defined('PHPUNIT_RUNNING')) {
                logger()->error('queue.dlq.metrics_failed', ['error' => $e->getMessage()]);
            }
            return [];
        }
    }

    /**
     * حذف خودکار جاب‌های بسیار قدیمی (Expiration Policy) — هر دو وضعیت پایانی:
     * dead_letter (خطای دائمی) و quarantined (خطای بیزینسی قطعی) پاکسازی می‌شوند
     * تا جدول بدون محدودیت رشد نکند.
     */
    public function cleanDeadLetters(int $days = 30): int
    {
        $cutoff = date('Y-m-d H:i:s', (strtotime("-{$days} days") ?: time()));
        $sql = "DELETE FROM failed_jobs WHERE status IN ('dead_letter', 'quarantined') AND failed_at < ?";
        return (int) $this->db->execute($sql, [$cutoff]);
    }

    /**
     * دریافت حداکثر تعداد مجاز تلاش‌ها
     */
    public function getMaxAttempts(): int
    {
        return $this->maxAttempts;
    }

    /**
     * تنظیم سقف تلاش‌ها در زمان اجرا (فلگ --tries ورکرها در supervisor)
     */
    public function setMaxAttempts(int $maxAttempts): void
    {
        $this->maxAttempts = max(1, min(20, $maxAttempts));
    }

    // =========================================================================
    // Section 8.5 / 8.7 — DLQ housekeeping helpers (سازگار با هر دو حالت صف)
    // =========================================================================

    /**
     * حذف failed_jobs قدیمی‌تر از $days روز
     */
    public function purgeFailedJobsOlderThan(int $days, ?string $queue = null, int $batch = 500): int
    {
        $days  = max(1, min(3650, $days));
        $batch = max(50, min(5000, $batch));

        $totalDeleted = 0;
        $safety = 0;

        while ($safety++ < 1000) {
            $sql = "DELETE FROM failed_jobs
                    WHERE failed_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
            $params = [$days];
            if ($queue !== null && $queue !== '') {
                $sql .= " AND queue = ?";
                $params[] = $queue;
            }
            $sql .= " LIMIT " . (int)$batch;

            $deleted = (int) $this->db->execute($sql, $params);
            if ($deleted <= 0) {
                break;
            }
            $totalDeleted += $deleted;
            if ($deleted < $batch) {
                break;
            }
        }
        return $totalDeleted;
    }

    /**
     * شمارش failed_jobs
     */
    public function countFailedJobs(?string $queue = null): int
    {
        $sql = "SELECT COUNT(*) AS c FROM failed_jobs";
        $params = [];
        if ($queue !== null && $queue !== '') {
            $sql .= " WHERE queue = ?";
            $params[] = $queue;
        }
        $row = $this->db->fetch($sql, $params);
        return (int) ($row->c ?? 0);
    }

    /**
     * بازگرداندن دسته‌ای از failed_jobs به صف اصلی (re-queue)
     */
    /** @return array{requeued: int, skipped: int, errors: int} */
    public function retryFailedJobsBatch(?string $queue = null, int $limit = 100): array
    {
        return $this->retryEligibleFailedJobs($queue, $limit, true); // true = دستور دستی ادمین (نادیده گرفتن next_retry_at)
    }

    /**
     * بازپخش هوشمند جاب‌های ناموفق (Poison Message Smart Retry)
     *
     * حالت خودکار (cron): فقط ردیف‌های status='retrying' که سررسیدِ next_retry_at
     * فرا رسیده بازیابی می‌شوند — یعنی backoff نمایی 1h/4h/12h که QueueWorker
     * می‌نویسد واقعاً رعایت می‌شود (قرارداد ایندکس idx_failed_jobs_retry_pickup).
     * وضعیت‌های پایانی (dead_letter/quarantined) هرگز خودکار بازیابی نمی‌شوند.
     *
     * هر ردیف با FOR UPDATE SKIP LOCKED قفل می‌شود تا مصرف‌کنندگان موازی
     * (ورکر dlq:work و cron) بدون تداخل و بدون اجرای مضاعف کار کنند.
     *
     * FIX-C05: enqueue خارجی (Redis push) دیگر داخل تراکنش DB انجام نمی‌شود.
     * قبلاً push→DELETE→commit بود؛ کرش بعد از پذیرش Redis ولی قبل از commit،
     * DELETE را rollback می‌کرد و ردیف در چرخهٔ بعدی دوباره requeue می‌شد
     * (duplicate نامحدود برای کارِ non-idempotent). اکنون:
     *   ۱) claim اتمیک داخل قفل: status='requeueing' با اجارهٔ ۲ دقیقه‌ای → commit
     *   ۲) push خارج از تراکنش
     *   ۳) پس از تأیید push: DELETE ردیف
     * کرش بین ۱ و ۲ → بازیابیِ ردیف‌های 'requeueing'ِ گذشته از اجاره در همین متد؛
     * کرش بین ۲ و ۳ → حداکثر یک duplicate محدود (at-least-once استاندارد).
     */
    /** @return array{requeued: int, skipped: int, errors: int} */
    public function retryEligibleFailedJobs(?string $queue = null, int $limit = 100, bool $forceManual = false): array
    {
        $limit = max(1, min(1000, $limit));
        $stats = ['requeued' => 0, 'skipped' => 0, 'errors' => 0];

        $eligibility = $forceManual
            ? "status NOT IN ('processing', 'requeueing')" // بازیابی دستی ادمین: رزروهای ورکر DLQ و requeueهای در جریان دست‌نخورده
            : "((status = 'retrying' AND (next_retry_at IS NULL OR next_retry_at <= NOW()))
                 OR (status = 'requeueing' AND next_retry_at <= NOW()))"; // FIX-C05: بازیابی claimهای رهاشده (کرش بین claim و push)

        $queueFilter = '';
        $params = [];
        if ($queue !== null && $queue !== '') {
            $queueFilter = ' AND queue = ?';
            $params[] = $queue;
        }

        while (($stats['requeued'] + $stats['skipped'] + $stats['errors']) < $limit) {
            $row = null;
            $payload = null;
            $data = [];
            $claimedId = null;

            // ─── فاز ۱: انتخاب + claim اتمیک داخل تراکنش ───
            $this->db->beginTransaction();
            try {
                $row = $this->db->selectOne(
                    "SELECT id, queue, payload, retry_count FROM failed_jobs
                     WHERE {$eligibility}{$queueFilter}
                     ORDER BY failed_at ASC
                     LIMIT 1 FOR UPDATE SKIP LOCKED",
                    $params
                );

                if ($row === null) {
                    $this->db->commit();
                    break;
                }

                $payload = json_decode((string)$row->payload, true);
                if (!is_array($payload) || empty($payload['job'])) {
                    // payload خراب: پیام سمی قطعی — علامت‌گذاری برای پاکسازی دوره‌ای
                    if (!$forceManual) {
                        $this->db->execute("UPDATE failed_jobs SET status = 'dead_letter' WHERE id = ?", [(int)$row->id]);
                    }
                    $this->db->commit();
                    $stats['skipped']++;
                    continue;
                }

                // حافظهٔ تلاش DLQ از ستون واقعی retry_count خوانده می‌شود (نه مقدار ثابت 0)
                // و در دیتای payload به صف منتقل می‌شود تا در شکست بعدی پایدار بماند.
                $data = (array)($payload['data'] ?? []);
                $retryMemory = max((int)($row->retry_count ?? 0), int_value($data['attempts'] ?? 0));
                $data['attempts'] = $retryMemory + 1;
                $data['_dlq_retry_count'] = $retryMemory + 1;

                // FIX-C05-1: claim پایدار قبل از هر write خارجی
                $this->db->execute(
                    "UPDATE failed_jobs SET status = 'requeueing', next_retry_at = DATE_ADD(NOW(), INTERVAL 2 MINUTE) WHERE id = ?",
                    [(int)$row->id]
                );
                $claimedId = (int)$row->id;

                $this->db->commit();
            } catch (\Throwable $e) {
                if ($this->db->inTransaction()) {
                    $this->db->rollback();
                }
                $stats['errors']++;
                if (function_exists('logger')) { logger()->warning('queue.failed_retry.failed', [
                        'failed_job_id' => is_object($row) ? (int)($row->id ?? 0) : null,
                        'queue'         => $queue,
                        'error'         => $e->getMessage(),
                    ]); }
                // خطای زیرساختی — چرخه را متوقف کن تا موج خطا نسازد
                break;
            }

            // ─── فاز ۲: enqueue خارجی — خارج از هر تراکنش DB ───
            $pushOk = false;
            try {
                $pushOk = $this->push(
                    strval($payload['job']),
                    $data,
                    (string)($row->queue ?? $this->defaultQueue)
                );
            } catch (\Throwable $pushError) {
                if (function_exists('logger')) { logger()->warning('queue.failed_retry.push_failed', [
                        'failed_job_id' => $claimedId,
                        'queue'         => $queue,
                        'error'         => $pushError->getMessage(),
                    ]); }
                $pushOk = false;
            }

            if (!$pushOk) {
                // FIX-C05-2: claim را به حالت 'retrying' برگردان تا زمان‌بند backoff دوباره برش دارد
                try {
                    $this->db->execute(
                        "UPDATE failed_jobs SET status = 'retrying', next_retry_at = NULL WHERE id = ? AND status = 'requeueing'",
                        [$claimedId]
                    );
                } catch (\Throwable $releaseError) {
                    if (function_exists('logger')) { logger()->warning('queue.failed_retry.claim_release_failed', [
                            'failed_job_id' => $claimedId,
                            'error'         => $releaseError->getMessage(),
                        ]); }
                }
                $stats['errors']++;
                // صف پر (backpressure) یا خطای درج — ادامهٔ چرخه در این وضعیت بی‌معناست
                break;
            }

            // ─── فاز ۳: پس از تأیید enqueue، ردیف DLQ حذف می‌شود ───
            try {
                $this->db->execute("DELETE FROM failed_jobs WHERE id = ?", [$claimedId]);
                $stats['requeued']++;
            } catch (\Throwable $deleteError) {
                // FIX-C05-3: enqueue موفق بوده ولی حذف ردیف شکست خورده — بازیابیِ
                // اجاره‌دار حداکثر یک duplicate محدود می‌سازد (at-least-once استاندارد)
                if (function_exists('logger')) { logger()->warning('queue.failed_retry.row_delete_failed', [
                        'failed_job_id' => $claimedId,
                        'queue'         => $queue,
                        'error'         => $deleteError->getMessage(),
                    ]); }
                $stats['errors']++;
                break;
            }
        }
        return $stats;
    }

    /**
     * برداشتن جاب از DLQ (جدول failed_jobs) برای پردازش توسط DlqWorker
     *
     * ردیف حذف نمی‌شود؛ به‌جای آن با status='processing' و ضرب‌الاجل ۱۵ دقیقه‌ای
     * در next_retry_at رزرو می‌شود تا در صورت کرش ورکر، جاب از بین نرود و با
     * بازیابی خودکار زامبی‌ها دوباره در دسترس قرار گیرد (تحویل at-least-once،
     * هم‌ارز الگوی visibility timeout صف اصلی).
     *
     * وضعیت‌های قابل برداشتن:
     *   - retrying (با رعایت next_retry_at): بازیابی هوشمند خطاهای موقتی
     *   - pending_analysis: طبقه‌بندی نامشخص — بازیابی محدود توسط ورکر
     *   - dead_letter: وضعیت پایانی — اجرای compensate/آرشیو/اطلاع به ادمین
     * وضعیت quarantined (خطای بیزینسی قطعی) هرگز خودکار برداشته نمی‌شود و
     * تنها با تصمیم ادمین (پنل Sentry) بازیابی می‌شود.
     */
    /** @return array<string, mixed>|null */
    public function popDlq(): ?array
    {
        try {
            // ۱. بازیابی خودکار رزروهای زامبی (ورکر کرش‌شده یا kill شده)
            // FIX-C04: توکن مالکیتِ رزرو زامبی هم باطل می‌شود تا ورکرِ مرده نتواند
            // بعداً با توکن کهنه delete/release کند.
            $recoverySql = $this->processingTokenColumnAvailable()
                ? "UPDATE failed_jobs SET status = 'pending_analysis', processing_token = NULL
                   WHERE status = 'processing' AND next_retry_at < NOW()"
                : "UPDATE failed_jobs SET status = 'pending_analysis'
                   WHERE status = 'processing' AND next_retry_at < NOW()";
            $this->db->execute($recoverySql);

            $this->db->beginTransaction();

            $job = $this->db->selectOne(
                "SELECT * FROM failed_jobs
                 WHERE (
                        (status = 'retrying' AND (next_retry_at IS NULL OR next_retry_at <= NOW()))
                     OR status IN ('dead_letter', 'pending_analysis')
                 )
                 ORDER BY failed_at ASC
                 LIMIT 1 FOR UPDATE SKIP LOCKED"
            );

            if (!$job) {
                $this->db->commit();
                return null;
            }

            // ۲. رزرو اتمیک: وضعیت processing با ضرب‌الاجل در next_retry_at
            // FIX-C04: هر رزرو یک توکن مالکیت یکتا می‌گیرد (الگوی FIX-9a-3 صف اصلی)
            // تا delete/release ورکر stall‌شده نتواند رزرو ورکر جدید را نابود کند.
            $claimToken = null;
            if ($this->processingTokenColumnAvailable()) {
                $claimToken = bin2hex(random_bytes(16));
                $this->db->execute(
                    "UPDATE failed_jobs
                     SET status = 'processing', next_retry_at = DATE_ADD(NOW(), INTERVAL 15 MINUTE), processing_token = :token
                     WHERE id = :id",
                    ['token' => $claimToken, 'id' => $job->id]
                );
            } else {
                $this->db->execute(
                    "UPDATE failed_jobs
                     SET status = 'processing', next_retry_at = DATE_ADD(NOW(), INTERVAL 15 MINUTE)
                     WHERE id = :id",
                    ['id' => $job->id]
                );
            }

            $this->db->commit();

            $payload = (array)(json_decode((string)$job->payload, true) ?? []);
            $dataFromPayload = is_array($payload['data'] ?? null) ? $payload['data'] : [];

            // حافظهٔ تلاش DLQ: ستون retry_count با کلید قدیمی data.attempts
            // هم‌راستا می‌شود تا ردیف‌های قدیمی هم درست شمرده شوند.
            $retryMemory = max(
                (int)($job->retry_count ?? 0),
                int_value($dataFromPayload['attempts'] ?? 0)
            );

            return [
                'id' => (int)$job->id,
                'queue' => $job->queue,
                'job' => $payload['job'] ?? '',
                'data' => $payload['data'] ?? [],
                'meta' => $payload['meta'] ?? [],
                'exception' => $job->exception,
                'attempts' => $retryMemory,
                'retry_count' => $retryMemory,
                'error_classification' => (string)($job->error_classification ?? 'unknown'),
                'status' => (string)($job->status ?? 'pending_analysis'),
                'next_retry_at' => $job->next_retry_at ?? null,
                'failed_at' => $job->failed_at,
                // FIX-C04: توکن مالکیت رزرو (null = ستون هنوز migrate نشده — مسیر legacy)
                'claim_token' => $claimToken,
            ];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            throw $e;
        }
    }

    /**
     * حذف نهایی ردیف DLQ پس از پردازش موفق (requeue/compensate/archive)
     *
     * FIX-C04: پارامتر اختیاری $token — اگر عبور داده شود، حذف فقط وقتی انجام
     * می‌شود که این نمونه هنوز مالکِ رزرو ('processing' + توکن مطابق) باشد؛
     * ورکر stall‌شده (گذشته از ضرب‌الاجل ۱۵ دقیقه) دیگر نمی‌تواند رزروِ ورکر
     * جدید را با حذف کورکورانه از بین ببرد.
     */
    public function deleteFailedJob(int $id, ?string $token = null): bool
    {
        try {
            if (is_string($token) && $token !== '' && $this->processingTokenColumnAvailable()) {
                return (bool)$this->db->execute(
                    "DELETE FROM failed_jobs WHERE id = :id AND status = 'processing' AND processing_token = :token",
                    ['id' => $id, 'token' => $token]
                );
            }
            return (bool)$this->db->execute("DELETE FROM failed_jobs WHERE id = ?", [$id]);
        } catch (\Throwable $e) {
            if (function_exists('logger')) { logger()->error('queue.dlq.delete_failed', [
                    'id' => $id,
                    'error' => $e->getMessage()
                ]); }
            return false;
        }
    }

    /**
     * آزادسازی رزرو DLQ هنگام خطای غیرمنتظرهٔ ورکر — ردیف به وضعیت امن
     * pending_analysis برمی‌گردد تا قفل‌شده در 'processing' نماند.
     *
     * FIX-C04: با توکن، فقط مالکِ فعلیِ رزرو می‌تواند آن را آزاد کند.
     */
    public function releaseDlqReservation(int $id, ?string $token = null): bool
    {
        try {
            if (is_string($token) && $token !== '' && $this->processingTokenColumnAvailable()) {
                return (bool)$this->db->execute(
                    "UPDATE failed_jobs SET status = 'pending_analysis', next_retry_at = NULL, processing_token = NULL
                     WHERE id = :id AND status = 'processing' AND processing_token = :token",
                    ['id' => $id, 'token' => $token]
                );
            }
            return (bool)$this->db->execute(
                "UPDATE failed_jobs SET status = 'pending_analysis', next_retry_at = NULL WHERE id = ? AND status = 'processing'",
                [$id]
            );
        } catch (\Throwable $e) {
            if (function_exists('logger')) { logger()->error('queue.dlq.release_reservation_failed', [
                    'id' => $id,
                    'error' => $e->getMessage()
                ]); }
            return false;
        }
    }

    /**
     * FIX-C04: deploy-order safety — ستون توکن مالکیت DLQ تا اجرای migration
     * وجود ندارد (هم‌الگوی reservationTokenColumnAvailable). نتیجه یک‌بار در عمر
     * پروسه کش می‌شود (کوئری information_schema سبک است).
     */
    private function processingTokenColumnAvailable(): bool
    {
        static $available = null;
        if ($available !== null) {
            return $available;
        }

        try {
            $row = $this->db->fetch(
                "SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'failed_jobs'
                   AND COLUMN_NAME = 'processing_token'"
            );
            $available = int_value($row->c ?? 0) > 0;
        } catch (\Throwable $e) {
            if (function_exists('logger')) {
                logger()->warning('queue.processing_token.probe_failed', ['error' => $e->getMessage()]);
            }
            $available = false;
        }

        return $available;
    }

    /**
     * آرشیو واقعی جاب مرده در جدول dlq_archive — FIX-C97 (یافتهٔ ۹۷):
     * قبلاً این متد فقط «رویداد آرشیو» را لاگ می‌کرد و payload برای همیشه
     * حذف می‌شد (Data Loss). اکنون payload/exception/queue با چرای آرشیو در
     * dlq_archive (مایگریشن 2026_09_28_0003) ماندگار می‌شود تا بازبینی
     * مدیریتی و کاوش بعدی ممکن باشد. شکستِ آرشیو فقط لاگ می‌شود تا جریان
     * پردازش DLQ متوقف نشود (at-least-once: حداقل لاگ حفظ می‌شود).
     *
     * @param array<string, mixed> $job
     */
    public function archiveDlqJob(array $job, string $reason): void
    {
        try {
            // FIX-C97: payload از همان ساختار popDlq بازسازی می‌شود تا آرشیو
            // برای بازصف‌سازی دستی بعدی قابل استفاده باشد (کاوش + replay).
            $payloadRaw = null;
            if ((isset($job['job']) && $job['job'] !== '') || (isset($job['data']) && $job['data'] !== [])) {
                $payloadRaw = json_encode(
                    ['job' => $job['job'] ?? null, 'data' => $job['data'] ?? [], 'meta' => $job['meta'] ?? []],
                    JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
                );
                if ($payloadRaw === false) {
                    $payloadRaw = null;
                }
            }
            $jobClass = is_string($job['job'] ?? null) && $job['job'] !== '' ? mb_substr((string)$job['job'], 0, 255) : null;
            $this->db->execute(
                "INSERT INTO dlq_archive
                 (original_failed_job_id, queue, job_class, payload, exception, failed_at, archive_reason, archived_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'dlq_worker')",
                [
                    isset($job['id']) && is_numeric($job['id']) ? (int)$job['id'] : null,
                    is_string($job['queue'] ?? null) ? $job['queue'] : null,
                    $jobClass,
                    $payloadRaw,
                    is_string($job['exception'] ?? null) ? mb_substr($job['exception'], 0, 60000) : null,
                    is_string($job['failed_at'] ?? null) ? $job['failed_at'] : null,
                    mb_substr($reason, 0, 64),
                ]
            );
        } catch (\Throwable $e) {
            if (function_exists('logger')) { logger()->error('dlq.archive.persist_failed', [
                'reason' => $reason,
                'error' => $e->getMessage(),
            ]); }
        }
        if (function_exists('logger')) { logger()->warning('dlq.job_archived', [
                'job' => $job['job'] ?? null,
                'reason' => $reason
            ]); }
    }

    /**
     * دریافت آمار لحظه‌ای از وضعیت تمام صف‌های دارای اولویت و DLQ
     */
    /** @return array<string, mixed> */
    public function getQueueStatusReport(): array
    {
        $queues = ['high_priority', 'default', 'notifications', 'analytics', 'maintenance'];
        $report = [];

        foreach ($queues as $q) {
            $total = 0;
            $pending = 0;
            $delayed = 0;
            $running = 0;
            $failed = 0;

            if ($this->redis !== null) {
                try {
                    $now = time();
                    $pendingCount = (int)$this->redisConnection()->zCount("{$this->redisPrefix}:{$q}:pending", "-inf", (string)$now);
                    $delayedCount = (int)$this->redisConnection()->zCount("{$this->redisPrefix}:{$q}:pending", "(" . $now, "+inf");
                    $runningCount = (int)$this->redisConnection()->zCard("{$this->redisPrefix}:{$q}:reserved");

                    $total = $pendingCount + $delayedCount + $runningCount;
                    $pending = $pendingCount;
                    $delayed = $delayedCount;
                    $running = $runningCount;

                    $failedRow = $this->db->selectOne("SELECT COUNT(*) AS c FROM failed_jobs WHERE queue = :queue", ['queue' => $q]);
                    $failed = (int)($failedRow->c ?? 0);
                } catch (\Throwable $e) {
                    if (function_exists('logger')) { logger()->error('queue.redis.status_report_failed', ['queue' => $q, 'error' => $e->getMessage()]); }
                    throw new \RuntimeException('Redis queue status is unavailable; refusing cross-driver fallback.', 0, $e);
                }
            }

            if ($this->redis === null) {
                $totalRow = $this->db->selectOne("SELECT COUNT(*) AS c FROM queues WHERE queue = :queue", ['queue' => $q]);
                $total = (int)($totalRow->c ?? 0);

                $pendingRow = $this->db->selectOne("SELECT COUNT(*) AS c FROM queues WHERE queue = :queue AND available_at <= NOW() AND reserved_at IS NULL", ['queue' => $q]);
                $pending = (int)($pendingRow->c ?? 0);

                $delayedRow = $this->db->selectOne("SELECT COUNT(*) AS c FROM queues WHERE queue = :queue AND available_at > NOW() AND reserved_at IS NULL", ['queue' => $q]);
                $delayed = (int)($delayedRow->c ?? 0);

                $runningRow = $this->db->selectOne("SELECT COUNT(*) AS c FROM queues WHERE queue = :queue AND reserved_at IS NOT NULL", ['queue' => $q]);
                $running = (int)($runningRow->c ?? 0);

                $failedRow = $this->db->selectOne("SELECT COUNT(*) AS c FROM failed_jobs WHERE queue = :queue", ['queue' => $q]);
                $failed = (int)($failedRow->c ?? 0);
            }

            $report[$q] = [
                'total_jobs' => $total,
                'pending_jobs' => $pending,
                'delayed_jobs' => $delayed,
                'running_jobs' => $running,
                'failed_jobs' => $failed,
                'status' => $running > 10 ? 'congested' : ($total > 0 ? 'active' : 'idle')
            ];
        }

        // آمار کلی شکست‌ها
        $totalFailedRow = $this->db->selectOne("SELECT COUNT(*) AS c FROM failed_jobs");
        $totalFailed = (int)($totalFailedRow->c ?? 0);

        $report['meta'] = [
            'total_failed_dlq' => $totalFailed,
            'timestamp' => date('Y-m-d H:i:s')
        ];

        return $report;
    }
}
