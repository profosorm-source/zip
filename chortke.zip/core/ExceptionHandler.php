<?php

declare(strict_types=1);

namespace Core;

use Throwable;
use ErrorException;
use Core\Exceptions\NotFoundException;
use Core\Exceptions\UnauthorizedException;
use Core\Exceptions\ValidationException;
use Core\Exceptions\SecurityException;

/** @phpstan-import-type ErrorPayload from \App\Contracts\ErrorContract */
class ExceptionHandler
{
        
    private static int $exceptionDepth = 0;

    // FIX-P4-12: کشِ یک‌بارهٔ پروب‌های اسکیما در سطح پروسس — قبلاً در پایان «هر»
    // درخواست ۲ کوئری SHOW اجرا می‌شد (۲/۳ بار سربار اضافه در هر ریکوئست).
    // وجود جدول/ستون در طول حیات یک پروسس تغییر نمی‌کند (مایگریشن‌ها خارج از
    // چرخهٔ درخواست اجرا می‌شوند) بنابراین کش یک‌بار-پروب امن و هم‌ارز است.
    private static ?bool $performanceTableExists = null;
    private static ?bool $performanceDetailedSchema = null;
    private const MAX_RECURSION = 3;
    public static function register(): void
    {
        // Do not register exception handler under PHPUnit/testing environment
        if (defined('PHPUNIT_COMPOSER_INSTALL') || defined('__PHPUNIT_PHAR__')) {
            return;
        }

        // تبدیل خطاهای PHP به Exception
        set_error_handler([self::class, 'handleError']);
        
        // گرفتن Exception های catch نشده
        set_exception_handler([self::class, 'handle']);
        
        // گرفتن Fatal Errors
        register_shutdown_function([self::class, 'handleShutdown']);
    }
    
    /** @param array<string, mixed> $context */
    private static function fallbackLog(string $event, array $context = []): void
{
    $line = '[' . date('Y-m-d H:i:s') . '] ' . $event . ' ' . json_encode($context, JSON_UNESCAPED_UNICODE) . PHP_EOL;
    @file_put_contents(__DIR__ . '/../storage/logs/_exception_fallback.log', $line, FILE_APPEND | LOCK_EX);
}

    /**
     * M27 Fix: ذخیره‌سازی نهایی اطلاعات بحرانی درون صف اضطراری آفلاین سنتری شخصی (jsonl)
     * این فایل بعداً در اولین ورود مدیر توسط داشبورد همگام‌سازی و از دیسک حذف می‌شود
     */
    private static function logToEmergencySentry(string $message, ?string $trace = null, string $level = 'ERROR', ?string $errorCode = null): void
    {
        try {
            // FIX-S4-3: مقدار هدر کاربر بدون اعتبارسنجی وارد JSONL اضطراری نمی‌شود؛
            // fallbackTraceId همان الگوی canonical را اعمال می‌کند (وگرنه uniqid امن تولید می‌شود).
            $traceId = self::fallbackTraceId();
            $emergencyData = [
                'message'   => '🔴 ' . $level . ': ' . $message,
                'error_code'=> $errorCode,
                'trace_id'  => $traceId,
                'ip'        => $_SERVER['REMOTE_ADDR'] ?? 'offline_cli',
                'timestamp' => time(),
                'trace'     => $trace ?? 'N/A'
            ];
            
            // استفاده هوشمند و امن از مسیردهی‌ها
            $logPath = function_exists('config')
                ? config('paths.storage', __DIR__ . '/../storage') . '/logs/sentry_emergency.jsonl'
                : __DIR__ . '/../storage/logs/sentry_emergency.jsonl';

            // FIX-EMERG-DIR (بازبینی ۲۰۲۶-۱۰-۲۹): لاگ اضطراری «آخرین تور ایمنی» است، اما
            // file_put_contents با FILE_APPEND پوشهٔ والد نمی‌سازد — روی چک‌اوت/زیپ تازه که
            // storage/logs/ ندارد (پوشهٔ خالی در گیت/زیپ حفظ نمی‌شود؛ تنها زیرپوشهٔ storage
            // بدون .gitkeep بود) نوشتن بی‌صدا شکست می‌خورد و رخداد اضطراری برای همیشه گم
            // می‌شد (اثبات: ران کامل سوئیت روی استخراج تازهٔ گیت‌هاب). اکنون پوشه قبل از
            // نوشتن ساخته می‌شود تا این مسیر هرگز به وجود قبلی پوشه وابسته نباشد.
            $logDir = dirname($logPath);
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0775, true);
            }

            $line = json_encode($emergencyData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL;
            @file_put_contents($logPath, $line, FILE_APPEND | LOCK_EX);
        } catch (\Throwable) {
            // در بدترین شرایط قفل سیستم، جلوی توقف فرآیند PHP را می‌گیرد
        }
    }


    public static function handle(\Throwable $exception): void
{
    self::$exceptionDepth++;
    if (self::$exceptionDepth > self::MAX_RECURSION) {
        self::fallbackLog('exception.recursive.detected', [
            'message' => $exception->getMessage(),
        ]);
        
        // M27 Fix: ثبت بلادرنگ خطای تودرتو و بازگشتی درون صف اضطراری جهت جلوگیری از هدر رفت دیباگ
        self::logToEmergencySentry(
            'Recursive Exception Limit Exceeded: ' . $exception->getMessage(),
            $exception->getTraceAsString(),
            'CRITICAL_RECURSIVE_LIMIT',
            'RECURSION_ERROR'
        );
        
        http_response_code(500);
        die('critical system error: recursion loop');
    }

    try {
        if (!isset($_SERVER['REQUEST_ID']) && !isset($_SERVER['HTTP_X_REQUEST_ID'])) {
            $_SERVER['REQUEST_ID'] = uniqid('req-');
        }

        $payload = self::getJsonPayloadForException($exception);
        $errorCode = $payload['error_code'];
        $traceId = $payload['meta']['trace_id'];

        // استفاده صحیح از Logger - بدون $this
        try {
            if (function_exists('logger')) {
    $context = [
        'message' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
    ];

    if (str_contains($exception->getMessage(), 'SQLSTATE')) {
        $context = self::enrichSqlContext($exception, $context);
    }

    logger()->error('exception.unhandled', $context);
}
        } catch (\Throwable $e) {
            self::fallbackLog('exception.logger.failed', [
                'message' => $e->getMessage(),
            ]);
        }

        // لاگ پیشرفته موجود خود پروژه
        try {
            self::logToAdvancedSystem($exception, $errorCode, $traceId);
        } catch (\Throwable $e) {
            self::fallbackLog('exception.log_to_advanced_system.failed', [
                'message' => $e->getMessage(),
            ]);
        }

        // پاکسازی بافر خروجی قبل از ارسال هدر — جلوگیری از "headers already sent"
        if (ob_get_length()) {
            ob_clean();
        }

        http_response_code(500);

        $isJsonRequest = self::isJsonRequest();

        // Handle Business/Validation exceptions for Web Requests (Flash and Redirect)
        if (!$isJsonRequest && ($exception instanceof \Core\Exceptions\BusinessException || $exception instanceof \Core\Exceptions\ValidationException)) {
            try {
                $session = \Core\Session::getInstance();
                $session->setFlash('error', $exception->getMessage());
                if ($exception instanceof \Core\Exceptions\ValidationException) {
                    $session->setFlash('errors', $exception->getErrors());
                }
                $ref = $_SERVER['HTTP_REFERER'] ?? '/';
                $generator = app(\Core\UrlGenerator::class);
                $refScheme = parse_url($ref, PHP_URL_SCHEME);
                $refHost = parse_url($ref, PHP_URL_HOST);
                $refPort = parse_url($ref, PHP_URL_PORT);
                if (is_string($refScheme) && is_string($refHost)) {
                    $refOrigin = strtolower($refScheme . '://' . $refHost . (is_int($refPort) ? ':' . $refPort : ''));
                    if (!hash_equals(strtolower($generator->origin()), $refOrigin)) {
                        $ref = $generator->to('/');
                    }
                } elseif (
                    !is_string($ref)
                    || !str_starts_with($ref, '/')
                    || str_starts_with($ref, '//')
                ) {
                    $ref = $generator->to('/');
                }
                // FIX (Round-18 P2): the 500 status was set earlier (:http_response_code(500))
                // so this last-resort redirect left with 500+Location and browsers would
                // not follow it. Re-issue 302 immediately before the Location header;
                // the non-redirect terminal path below keeps its 500.
                http_response_code(302);
                header("Location: $ref");
                exit;
            } catch (\Throwable $e) {
                // Fallback to normal error page if session/redirect fails
            }
        }

        if ($isJsonRequest) {
            self::renderJsonError($exception);
            return;
        }

        $debug = (bool) config('app.debug', false);

        if ($debug) {
            self::renderDebugPage($exception);
        } else {
            self::renderProductionPage($exception);
        }
    } catch (\Throwable $e) {
        self::fallbackLog('exception.handler.failed', [
            'message' => $e->getMessage(),
        ]);
        
        // M27 Fix: نجات و ثبت اطلاعات آخرین نفس درایو در صف اضطراری آفلاین در زمان فروپاشی هندلر
        self::logToEmergencySentry(
            'Handler Collapse Catch: ' . $e->getMessage(),
            $e->getTraceAsString(),
            'HANDLER_COLLAPSE',
            'HANDLER_CRASH'
        );
        
        if (!headers_sent() && PHP_SAPI !== 'cli') {
            http_response_code(500);
            die('system error');
        }
    } finally {
        self::$exceptionDepth--;
    }
}

/**
 * @param array<string, mixed> $context
 * @return array<string, mixed>
 */
private static function enrichSqlContext(\Throwable $exception, array $context): array
{
    $dbCtx = null;

    if (class_exists('\\Core\\Database') && method_exists('\\Core\\Database', 'getLastSqlErrorContext')) {
        try {
            $dbCtx = \Core\Database::getLastSqlErrorContext();
        } catch (\Throwable $ignore) {
            $dbCtx = null;
        }
    }

    // مسیر 1: اگر context دیتابیس از Database.php موجود بود
    if (is_array($dbCtx) && !empty($dbCtx)) {
        $context['db_error'] = $dbCtx['error'] ?? $exception->getMessage();
        $context['db_sql'] = $dbCtx['sql'] ?? null;
        $context['db_sql_interpolated'] = $dbCtx['sql_interpolated'] ?? null;
        $context['db_file'] = $dbCtx['file'] ?? null;
        $context['db_line'] = $dbCtx['line'] ?? null;
        $context['db_tables'] = $dbCtx['tables'] ?? [];
        $context['db_unknown_column'] = $dbCtx['unknown_column'] ?? null;
        $context['db_stack'] = $dbCtx['stack'] ?? [];
        $context['db_params_count'] = $dbCtx['params_count'] ?? null;

        // این بخش همانی است که گفتی جاگذاری‌اش نامشخص بود
        $context['db_request'] = [
            // FIX-S4-3: شناسهٔ درخواست فقط از مسیر validated (fallbackTraceId)
            'request_id' => self::fallbackTraceId(),
            'uri' => $_SERVER['REQUEST_URI'] ?? null,
            'method' => $_SERVER['REQUEST_METHOD'] ?? null,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
        ];

        return $context;
    }

    // مسیر 2: fallback از trace خود exception
    [$originFile, $originLine, $stack] = self::extractAppOriginFromTrace($exception);

    $unknownColumn = null;
    if (preg_match("/Unknown column '([^']+)'/i", $exception->getMessage(), $m)) {
        $unknownColumn = $m[1];
    }

    $context['db_error'] = $exception->getMessage();
    $context['db_sql'] = null;
    $context['db_sql_interpolated'] = null;
    $context['db_file'] = $originFile;
    $context['db_line'] = $originLine;
    $context['db_tables'] = [];
    $context['db_unknown_column'] = $unknownColumn;
    $context['db_stack'] = $stack;
    $context['db_params_count'] = null;

    // این بخش هم برای fallback هم اضافه شد
    $context['db_request'] = [
        // FIX-S4-3: شناسهٔ درخواست فقط از مسیر validated (fallbackTraceId)
        'request_id' => self::fallbackTraceId(),
        'uri' => $_SERVER['REQUEST_URI'] ?? null,
        'method' => $_SERVER['REQUEST_METHOD'] ?? null,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
    ];

    return $context;
}



/** @return array{0: ?string, 1: ?int, 2: list<string>} */
private static function extractAppOriginFromTrace(\Throwable $exception): array
{
    $originFile = null;
    $originLine = null;
    $stack = [];

    foreach ($exception->getTrace() as $t) {
        $fileValue = $t['file'] ?? null;
        $lineValue = $t['line'] ?? null;
        $classValue = $t['class'] ?? null;
        $functionValue = $t['function'];

        $file = is_string($fileValue) ? $fileValue : null;
        $line = is_int($lineValue) ? $lineValue : null;
        $class = is_string($classValue) ? $classValue : '';
        $fn = $functionValue;

        $frame = ($class !== '' ? $class . '->' : '') . $fn . '()' . ($line !== null ? ':' . $line : '');

        if ($file) {
            $normalized = str_replace('\\', '/', $file);

            $isAppFrame =
                str_contains($normalized, '/app/') ||
                str_ends_with($normalized, '/cron.php') ||
                str_contains($normalized, '/core/IdempotencyKey.php');

            // فقط فریم‌های کاربردی برای دیباگ محصول
            if ($isAppFrame) {
                $stack[] = $frame;
            }

            // اولین مبدا واقعی خارج از Database
            if (
                $originFile === null &&
                $isAppFrame &&
                !str_contains($normalized, '/core/Database.php')
            ) {
                $originFile = $file;
                $originLine = $line;
            }
        }
    }

    // اگر هیچ app frame پیدا نشد، fallback عمومی
    if (empty($stack)) {
        foreach ($exception->getTrace() as $t) {
            $classValue = $t['class'] ?? null;
            $functionValue = $t['function'];
            $lineValue = $t['line'] ?? null;
            $class = is_string($classValue) ? $classValue : '';
            $fn = $functionValue;
            $line = is_int($lineValue) ? $lineValue : null;
            $stack[] = ($class !== '' ? $class . '->' : '') . $fn . '()' . ($line !== null ? ':' . $line : '');
            if (count($stack) >= 12) {
                break;
            }
        }
    }

    return [$originFile, $originLine, array_slice($stack, 0, 12)];
}

    /**
     * ثبت در سیستم لاگ پیشرفته
     */
    private static function logToAdvancedSystem(\Throwable $exception, string $errorCode = 'UNKNOWN', string $traceId = 'UNKNOWN'): void
    {
        try {
            // فقط اگر جداول وجود داشتن
            $db = Database::getInstance();
            
            // بررسی وجود جدول error_logs
            $tableExists = $db->query(
                "SHOW TABLES LIKE 'error_logs'"
            )->fetch();

            if (!$tableExists) {
                return; // جدول نیست، بی‌خیال
            }

            // ثبت مستقیم؛ وابستگی به ErrorLogService حذف شده تا سرویس حذف‌شده برنگردد.
            $level = self::determineErrorLevel($exception);
            $userId = null;
            try {
                $session = Session::getInstance();
                $userId = $session->get('user_id');
            } catch (\Throwable $e) {}

            // BUGFIX (observability): ستون‌های `level` و `context` در اسکیمای واقعی
            // جدول error_logs وجود ندارند (مهاجرت‌های 2026_07_16_0016 و 0017 نسخه‌ی
            // exception_class را توسعه داده‌اند). چون این درج داخل try/catch خاموش
            // است، PDOException بلعیده می‌شد و عملاً هیچ خطایی ثبت نمی‌شد.
            // اکنون فقط به ستون‌های موجود نگاشت می‌شود و سطح خطا در `status`
            // و زمینه‌ی درخواست در ستون‌های اختصاصی خودشان ذخیره می‌گردد.
            $db->table('error_logs')->insert([
                'message' => mb_substr($exception->getMessage(), 0, 2000),
                'exception_class' => get_class($exception),
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
                'user_id' => $userId,
                'url' => mb_substr((string) ($_SERVER['REQUEST_URI'] ?? ''), 0, 2048),
                'method' => mb_substr((string) ($_SERVER['REQUEST_METHOD'] ?? ''), 0, 10),
                'ip_address' => mb_substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45) ?: null,
                'user_agent' => (string) ($_SERVER['HTTP_USER_AGENT'] ?? '') ?: null,
                'trace' => mb_substr(
                    'level=' . $level
                    . ' error_code=' . $errorCode
                    . ' trace_id=' . $traceId . "\n"
                    . $exception->getTraceAsString(),
                    0,
                    20000
                ),
                'status' => 'unresolved',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

        } catch (\Throwable $e) {
            // اگر سیستم لاگ پیشرفته خراب بود، بی‌خیال
            self::fallbackLog('exception.advanced_logging.failed', [
    'message' => $e->getMessage(),
]);
        }
    }

    /**
     * تعیین سطح خطا
     */
    private static function determineErrorLevel(Throwable $exception): string
    {
        $message = $exception->getMessage();

        // خطاهای بحرانی
        if (
            $exception instanceof \Error ||
            str_contains($message, 'SQLSTATE') ||
            str_contains($message, 'Table') && str_contains($message, "doesn't exist") ||
            str_contains($message, 'Column not found')
        ) {
            return 'CRITICAL';
        }

        // خطاهای مهم
        if (
            str_contains($message, 'Undefined method') ||
            str_contains($message, 'Undefined variable') ||
            str_contains($message, 'Undefined array key')
        ) {
            return 'ERROR';
        }

        return 'WARNING';
    }
    
    /**
     * تبدیل Error به Exception
     */
    public static function handleError(
        int $level,
        string $message,
        string $file = '',
        int $line = 0
    ): bool {
        if (error_reporting() & $level) {
            throw new ErrorException($message, 0, $level, $file, $line);
        }
        
        return false;
    }
    
    /**
     * گرفتن Fatal Errors
     */
    public static function handleShutdown(): void
{
    if (PHP_SAPI === 'cli') {
        return;
    }
    $error = error_get_last();

    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {

        self::logFatalError($error);

        // ✅ استفاده صحیح از Logger
        try {
            \Core\Container::getInstance()->make(\App\Contracts\LoggerInterface::class)->error('Fatal Error: ' . $error['message'], [
                'file' => $error['file'],
                'line' => $error['line'],
                'type' => $error['type'],
            ]);
        } catch (\Throwable $e) {
            self::fallbackLog('exception.fatal', [
                'message' => $error['message'],
                'file' => $error['file'],
                'line' => $error['line'],
                'type' => $error['type'],
            ]);
        }

        if (ob_get_length()) {
            ob_clean();
        }

        if (!headers_sent() && PHP_SAPI !== 'cli') {
            http_response_code(500);
        }

        $debug = (bool) config('app.debug', false);
        $isJson = self::isJsonRequest();

        if ($debug) {
            $sanitizedError = self::sanitizeErrorData($error);
            if ($isJson) {
                echo json_encode($sanitizedError, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            } else {
                echo '<pre>' . e(
                    print_r($sanitizedError, true),
                    ENT_QUOTES,
                    'UTF-8'
                ) . '</pre>';
            }
        } else {
            if ($isJson) {
                echo json_encode(['message' => 'خطای سیستمی'], JSON_UNESCAPED_UNICODE);
            } else {
                echo '<h1>خطای سیستمی</h1><p>لطفاً بعداً تلاش کنید.</p>';
            }
        }

        self::logPerformance();
        exit;
    }

    self::logPerformance();
}
    
    /**
     * ثبت Fatal Error
     */
    /** @param array{type: int, message: string, file: string, line: int} $error */
    private static function logFatalError(array $error): void
    {
        // M27 Fix: استفاده مستقیم از هلپر متمرکز و امن جهت ثبت خطا درون سیستم شخصی سنتری
        $traceInfo = '⚠️ File: ' . $error['file'] . ' | Line: ' . $error['line'] . ' | Type: ' . $error['type'];
        // FIX-S4-3: همان گایت canonical به‌جای خواندن خام هدر کاربر
        $traceId = self::fallbackTraceId();
        self::logToEmergencySentry(
            'FATAL SHUTDOWN: ' . $error['message'],
            $traceInfo,
            'FATAL',
            'PHP_FATAL_ERROR'
        );

        // تلاش ثانویه برای درج بلادرنگ در دیتابیس (در صورت برقراری ارتباط)
        try {
            $db = Database::getInstance();
            
            $tableExists = $db->query("SHOW TABLES LIKE 'error_logs'")->fetch();
            if (!$tableExists) return;

            // BUGFIX (observability): مانند بالا — نگاشت به ستون‌های واقعاً موجود.
            $db->table('error_logs')->insert([
                'message' => mb_substr($error['message'], 0, 2000),
                'exception_class' => 'PHP_FATAL_ERROR',
                'file' => $error['file'],
                'line' => $error['line'],
                'user_id' => null,
                'url' => mb_substr((string) ($_SERVER['REQUEST_URI'] ?? ''), 0, 2048),
                'method' => mb_substr((string) ($_SERVER['REQUEST_METHOD'] ?? ''), 0, 10),
                'trace' => mb_substr(
                    'level=FATAL type=' . $error['type']
                    . ' error_code=PHP_FATAL_ERROR trace_id=' . $traceId,
                    0,
                    20000
                ),
                'status' => 'unresolved',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {
            // خطا در دیتابیس اهمیتی ندارد چون نسخه فیزیکی در jsonl بالاتر ذخیره شد و در داشبورد بازیابی می‌شود
        }
    }

    /**
     * ثبت Performance
     */
    private static function logPerformance(): void
    {
        // FIX-P4-12 (بخش ۱): پروب‌های SHOW فقط یک‌بار در عمر پروسس اجرا می‌شوند.
        if (self::$performanceTableExists === null) {
            try {
                $db = Database::getInstance();
                $exists = $db->query("SHOW TABLES LIKE 'performance_logs'")->fetch();
                if ($exists) {
                    self::$performanceTableExists = true;
                    self::$performanceDetailedSchema = (bool) $db->query("SHOW COLUMNS FROM performance_logs LIKE 'endpoint'")->fetch();
                } else {
                    self::$performanceTableExists = false;
                }
            } catch (\Throwable $e) {
                return; // خطای پروب — مثل قبل بی‌صدا، بدون بازپروب در هر ریکوئست
            }
        }
        if (self::$performanceTableExists !== true) {
            return;
        }

        try {
            $db = Database::getInstance();

            $endpoint = $_SERVER['REQUEST_URI'] ?? '/';
            $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
            $statusCode = http_response_code() ?: 200;

            $userId = null;
            try {
                $session = Session::getInstance();
                $userId = $session->get('user_id');
            } catch (\Throwable $e) {}

            $durationMs = isset($_SERVER['REQUEST_TIME_FLOAT'])
                ? (int)round((microtime(true) - floatval($_SERVER['REQUEST_TIME_FLOAT'])) * 1000)
                : null;

            if (self::$performanceDetailedSchema) {
                $db->table('performance_logs')->insert([
                    'endpoint' => mb_substr($endpoint, 0, 500),
                    'method' => $method,
                    'status_code' => $statusCode,
                    'user_id' => $userId,
                    'duration_ms' => $durationMs,
                    'memory_peak' => memory_get_peak_usage(true),
                    'request_id' => $_SERVER['REQUEST_ID'] ?? null,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            } else {
                // FIX-P4-12 (بخش ۲): در اسکیمای legacy نام متریک باید واقعیت را
                // بگوید — قبلاً حتی برای درخواست‌های موفق هم 'request_failure'
                // ثبت می‌شد و دادهٔ داشبورد گمراه‌کننده بود.
                $db->table('performance_logs')->insert([
                    'metric' => (is_int($statusCode) && $statusCode >= 400) ? 'request_failure' : 'request',
                    'value' => $durationMs ?? 0,
                    'context' => json_encode([
                        'endpoint' => $endpoint,
                        'method' => $method,
                        'status_code' => $statusCode,
                        'user_id' => $userId,
                        'memory_peak' => memory_get_peak_usage(true),
                        'request_id' => $_SERVER['REQUEST_ID'] ?? null,
                    ], JSON_UNESCAPED_UNICODE),
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

        } catch (\Throwable $e) {
            // Silent
        }
    }
    
    private static function maskPII(string $text): string
    {
        $replace = static function (string $pattern, string $replacement, string $subject): string {
            $masked = preg_replace($pattern, $replacement, $subject);
            return is_string($masked) ? $masked : $subject;
        };

        $text = $replace('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', '[EMAIL_MASKED]', $text);
        $text = $replace('/(?:\+98|0)?9\d{9}/', '[PHONE_MASKED]', $text);
        $text = $replace('/\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/', '[IP_MASKED]', $text);

        return $replace(
            '/(password|pass|secret|token|card_number|cvv2|cvv|pin)\s*[:=]\s*[^\s,\'\"]+/i',
            '$1=[MASKED]',
            $text
        );
    }

    /**
     * نمایش صفحه خطا در Debug Mode
     */
    private static function renderDebugPage(Throwable $exception): void
{
    http_response_code(500);

    $isDebug = (bool) config('app.debug', false);

    // [MED-01] Fix: Sanitize exception data to prevent info leakage
    $message = self::maskPII($exception->getMessage());
    $file = $exception->getFile();
    $trace = self::maskPII($exception->getTraceAsString());

    if (!$isDebug) {
        // Fallback safety if someone calls this directly
        self::renderProductionPage($exception);
        return;
    }

    // Mask absolute paths for security
    $baseDir = realpath(__DIR__ . '/../');
    $baseDir = is_string($baseDir) ? $baseDir : '';
    $maskPath = function (string $path) use ($baseDir): string {
        if ($path === '') {
            return $path;
        }
        $path = str_replace($baseDir, '{ROOT}', $path);
        $maskedPath = preg_replace([
            '/\/home\/[^\/\s]+/',
            '/\/var\/www\/[^\/\s]+/',
            '/C:\\\\Users\\\\[^\/\s\\\\]+/i',
            '/C:\\\\xampp\\\\[^\/\s\\\\]+/i',
            '/\/usr\/share\/[^\/\s]+/',
        ], [
            '/home/{USER}',
            '/var/www/{APP}',
            'C:\\\\Users\\\\{USER}',
            'C:\\\\{APP}',
            '/usr/share/{PKG}',
        ], $path);
        return is_string($maskedPath) ? $maskedPath : $path;
    };

    $displayFile = $maskPath($file);
    $displayTrace = $maskPath(mb_substr($trace, 0, 12000));
    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>خطای سیستم (Debug Mode)</title>
        <style>
            body { font-family: Tahoma; background: #f5f5f5; padding: 20px; }
            .error-box { background: #fff; border: 3px solid #f44336; border-radius: 8px; padding: 20px; max-width: 900px; margin: 0 auto; }
            h1 { color: #f44336; margin: 0 0 15px; }
            .message { background: #ffebee; padding: 15px; border-radius: 5px; margin: 15px 0; }
            .trace { background: #263238; color: #aed581; padding: 15px; border-radius: 5px; overflow-x: auto; font-family: monospace; font-size: 12px; white-space: pre-wrap; }
            .meta { color: #666; font-size: 13px; margin-top: 10px; }
        </style>
    </head>
    <body>
        <div class="error-box">
            <h1>خطای سیستم</h1>
            <div class="message">
                <strong><?= e(get_class($exception)) ?>:</strong><br>
                <?php
                    $escapedMsg = e($message);
                    echo preg_replace(
                        '/https?:\/\/[^\s<"\']+/', 
                        '<a href="$0" target="_blank" style="color:#e53935; font-weight:bold; text-decoration:underline;">$0</a>', 
                        $escapedMsg
                    );
                ?>
            </div>
            <div class="meta">
                <strong>فایل:</strong> <?= e($displayFile) ?><br>
                <strong>خط:</strong> <?= e((int) $exception->getLine()) ?>
            </div>

            <h3>Stack Trace:</h3>
            <div class="trace"><?= e($displayTrace) ?></div>
        </div>
    </body>
    </html>
    <?php
}

    /**
     * [MED-01] پاکسازی داده‌های حساس از خروجی خطا
     */
    /**
     * @param array<string, mixed> $error
     * @return array<string, mixed>
     */
    private static function sanitizeErrorData(array $error): array
    {
        $sensitiveKeys = [
            'DB_PASS', 'DB_PASSWORD', 'APP_KEY', 'MAIL_PASSWORD', 
            'REDIS_PASSWORD', 'PASSWORD', 'SECRET'
        ];

        $baseDir = realpath(__DIR__ . '/../');
        $baseDir = is_string($baseDir) ? $baseDir : '';

        $walk = function (&$item, $key) use ($sensitiveKeys, $baseDir) {
            // Mask paths
            if (is_string($item) && str_contains($item, $baseDir)) {
                $item = str_replace($baseDir, '{ROOT}', $item);
            }

            // Mask sensitive values
            foreach ($sensitiveKeys as $sKey) {
                if (is_string($key) && str_contains(strtoupper((string)$key), $sKey)) {
                    $item = '********';
                }
            }

            // Mask PII in error message items
            if (is_string($item)) {
                $item = self::maskPII($item);
            }
        };

        array_walk_recursive($error, $walk);
        return $error;
    }
    
    /**
     * نمایش صفحه خطا در Production
     */
    private static function renderProductionPage(Throwable $exception): void
    {
        http_response_code(500);
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>خطای سیستمی</title>
            <style>
                body { font-family: Tahoma; background: #f5f5f5; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
                .error-container { text-align: center; background: #fff; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
                h1 { color: #f44336; font-size: 72px; margin: 0; }
                p { color: #666; font-size: 18px; }
                a { display: inline-block; margin-top: 20px; padding: 10px 30px; background: #4fc3f7; color: #fff; text-decoration: none; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class="error-container">
                <h1>500</h1>
                <p>متأسفانه خطای سیستمی رخ داده است</p>
                <p>لطفاً چند لحظه دیگر مجدداً تلاش کنید</p>
                <a href="<?= url('/') ?>">بازگشت به صفحه اصلی</a>
            </div>
        </body>
        </html>
        <?php
    }

    /**
     * بررسی آیا درخواست JSON است
     */
    private static function isJsonRequest(): bool
    {
        $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

        return $isAjax || str_contains($accept, 'application/json') || str_contains($contentType, 'application/json');
    }

    /**
     * رندر خطا به صورت JSON (برای استفاده‌های Legacy)
     */
    private static function renderJsonError(\Throwable $exception): void
    {
        $payload = self::getJsonPayloadForException($exception);
        http_response_code($payload['code']);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    /**
     * دریافت ساختار استاندارد خطا بدون بستن پروسه (برای Middleware)
     */
    /** @return ErrorPayload */
    public static function getJsonPayloadForException(\Throwable $exception): array
    {
        // H26 Fix: پیاده‌سازی تور نجات سراسری برای جلوگیری از کرش‌های بازگشتی (Circular Crash Loop)
        try {
            $contract = \App\Contracts\ErrorContract::internalError('خطای سیستمی');

            if ($exception instanceof \Core\Exceptions\ValidationException) {
                $contract = \App\Contracts\ErrorContract::validation(
                    'داده‌های ورودی نامعتبر',
                    $exception->getErrors()
                );
            } elseif ($exception instanceof \Core\Exceptions\UnauthorizedException) {
                $contract = \App\Contracts\ErrorContract::unauthorized(
                    $exception->getMessage() ?: 'احراز هویت لازم است'
                );
            } elseif ($exception instanceof \Core\Exceptions\SecurityException) {
                if ($exception instanceof \Core\Exceptions\FraudDetectedException) {
                    $contract = \App\Contracts\ErrorContract::fraudDetected(
                        $exception->getMessage() ?: 'فعالیت مشکوک شناسایی شد'
                    );
                } else {
                    $contract = \App\Contracts\ErrorContract::forbidden(
                        $exception->getMessage() ?: 'بررسی امنیتی ناموفق'
                    );
                }
            } elseif ($exception instanceof \Core\Exceptions\NotFoundException) {
                $contract = \App\Contracts\ErrorContract::notFound(
                    $exception->getMessage() ?: 'منبع یافت نشد'
                );
            } elseif ($exception instanceof \Core\Exceptions\InsufficientBalanceException) {
                $contract = \App\Contracts\ErrorContract::insufficientFunds(
                    $exception->getMessage() ?: 'موجودی حساب کافی نیست'
                );
            } elseif ($exception instanceof \Core\Exceptions\RateLimitExceededException) {
                $contract = \App\Contracts\ErrorContract::rateLimited(
                    $exception->getMessage() ?: 'تعداد درخواست‌ها بیش از حد مجاز است'
                );
            } elseif ($exception instanceof \Core\Exceptions\InvalidStateException) {
                $contract = \App\Contracts\ErrorContract::conflict(
                    $exception->getMessage() ?: 'وضعیت درخواست نامعتبر است'
                );
            } elseif ($exception instanceof \App\Exceptions\SessionException) {
                $contract = new \App\Contracts\ErrorContract(
                    419,
                    'SESSION_ERROR',
                    $exception->getMessage() ?: 'نشست کاربری نامعتبر یا منقضی شده است'
                );
            } elseif ($exception instanceof \App\Exceptions\PaymentGatewayException) {
                $exceptionCode = $exception->getCode();
                $statusCode = $exceptionCode >= 400 && $exceptionCode <= 599 ? $exceptionCode : 500;
                // FIX-MODULE1-H4: پیام خام provider (شامل authority/transaction id و
                // پاسخ gateway) هرگز به کلاینت نمی‌رود — همان قرارداد شاخهٔ
                // ExternalServiceException. پیام کامل فقط در debug و در لاگ داخلیِ
                // handle() (exception.unhandled) ثبت می‌شود.
                $debug = (bool) config('app.debug', false);
                $contract = new \App\Contracts\ErrorContract(
                    $statusCode,
                    'PAYMENT_GATEWAY_ERROR',
                    ($debug && $exception->getMessage() !== '')
                        ? $exception->getMessage()
                        : 'خطا در پردازش پرداخت؛ لطفاً کمی بعد دوباره تلاش کنید'
                );
                // FIX-MODULE1-H4: جزئیات فقط از allowlist نوع‌دار و غیرمحرمانه؛
                // هر کلید دیگری (پاسخ خام provider، authority، …) حذف می‌شود.
                if ($exception instanceof \App\Exceptions\PaymentVerificationException) {
                    $publicDetails = self::sanitizePublicPaymentDetails($exception->getDetails());
                    if ($publicDetails !== []) {
                        $contract = $contract->withDetails($publicDetails);
                    }
                }
            } elseif ($exception instanceof \Core\Exceptions\PayloadTooLargeException) {
                // CORE-021: در core/Request.php پرتاب می‌شود و هرگز catch نمی‌شود.
                // این خطای کاربر است (بدنه‌ی بیش از حد بزرگ) نه خرابی سرور.
                $contract = new \App\Contracts\ErrorContract(
                    413,
                    'PAYLOAD_TOO_LARGE',
                    'حجم داده‌ی ارسالی بیش از حد مجاز است'
                );
            } elseif ($exception instanceof \Core\Exceptions\CircuitBreakerOpenException) {
                // مدار باز = سرویس موقتاً در دسترس نیست؛ کلاینت می‌تواند بعداً تلاش کند.
                $contract = new \App\Contracts\ErrorContract(
                    503,
                    'SERVICE_UNAVAILABLE',
                    'سرویس موقتاً در دسترس نیست؛ لطفاً کمی بعد تلاش کنید'
                );
            } elseif ($exception instanceof \Core\Exceptions\RateLimitedFailure) {
                // سقف نرخ سمت provider — همان 429 که خود exception حمل می‌کند.
                $contract = new \App\Contracts\ErrorContract(
                    429,
                    'RATE_LIMITED',
                    'محدودیت نرخ درخواست سرویس بیرونی؛ لطفاً کمی بعد تلاش کنید'
                );
            } elseif ($exception instanceof \Core\Exceptions\ProviderUnavailable
                || $exception instanceof \Core\Exceptions\TransientException) {
                // خطای گذرا یا عدم دسترس‌بودن provider → 503 (تلاش مجدد منطقی است).
                $contract = new \App\Contracts\ErrorContract(
                    503,
                    'SERVICE_UNAVAILABLE',
                    'سرویس موقتاً در دسترس نیست؛ لطفاً کمی بعد تلاش کنید'
                );
            } elseif ($exception instanceof \Core\Exceptions\ExternalServiceException) {
                // شکست سرویس بیرونی (شامل PermanentFailure) خطای دروازه است نه
                // خطای داخلی ما. پیام خام هرگز افشا نمی‌شود مگر در حالت debug،
                // چون ممکن است شامل کلید/پاسخ خام provider باشد.
                $contract = new \App\Contracts\ErrorContract(
                    502,
                    'EXTERNAL_SERVICE_ERROR',
                    ((bool) config('app.debug', false) && $exception->getMessage() !== '')
                        ? $exception->getMessage()
                        : 'خطا در ارتباط با سرویس بیرونی'
                );
            } elseif ($exception instanceof \Core\Exceptions\DomainException || $exception instanceof \DomainException) {
                // FIX-P4-5: قبلاً فقط \DomainException سراسری چک می‌شد؛ کلاسِ Core\Exceptions\DomainException
                // از RuntimeException مشتق است (نه \DomainException) و در production هیچ
                // throw سراسری وجود نداشت — شاخهٔ DOMAIN_LOGIC_ERROR در عمل مرده بود و
                // DomainExceptionهای Core به شاخهٔ عمومی BusinessException می‌افتادند.
                // اکنون هر دو تکسونومی (تایپ‌دار Core + سراسری SPL) به همین معناشناسی
                // 400/DOMAIN_LOGIC_ERROR نگاشت می‌شوند.
                $contract = \App\Contracts\ErrorContract::internalError(
                    $exception->getMessage() ?: 'خطای عملیاتی نامعتبر'
                );
                // In ErrorContract, internalError is 500. We need 400 for DomainException
                // Since we might not have a helper for 400 badRequest, we can use a new instance
                $contract = new \App\Contracts\ErrorContract(
                    400,
                    'DOMAIN_LOGIC_ERROR',
                    $exception->getMessage() ?: 'خطای پردازش درخواست'
                );
            } elseif ($exception instanceof \Core\Exceptions\BusinessException) {
                // BUGFIX: خطای بیزینسی یک نقض قانون کسب‌وکار است (خطای سمت کاربر)،
                // نه خرابی سرور. نگاشت آن به 500 باعث می‌شد پیام‌های کاربرپسندی مانند
                // «مبلغ برداشت نامعتبر است» به‌صورت «خطای سرور» به کاربر نمایش داده شود
                // و همچنین این خطاها به‌اشتباه در مانیتورینگ به‌عنوان خطای 5xx ثبت شوند.
                // اگر خودِ exception کد HTTP معتبری (4xx/5xx) داشته باشد همان محترم شمرده
                // می‌شود، در غیر این صورت 422 (Unprocessable Entity) پیش‌فرض است.
                $exceptionCode = $exception->getCode();
                $statusCode = (is_int($exceptionCode) && $exceptionCode >= 400 && $exceptionCode <= 599)
                    ? $exceptionCode
                    : 422;

                $contract = new \App\Contracts\ErrorContract(
                    $statusCode,
                    'BUSINESS_RULE_ERROR',
                    $exception->getMessage() ?: 'خطای بیزینسی'
                );

                // خطاهای فیلدمحور (در صورت وجود) حفظ می‌شوند تا فرانت‌اند بتواند
                // آن‌ها را کنار فیلد مربوطه نمایش دهد.
                $businessErrors = $exception->getErrors();
                if ($businessErrors !== []) {
                    $contract = $contract->withFieldErrors($businessErrors);
                }
            }

            return $contract->toArray();

        } catch (\Throwable $fallbackException) {
            // تور نجات نهایی در صورتی که ErrorContract یا ماژول‌های خارجی دچار شکست شوند:
            // ساخت خروجی JSON خام بدون هیچ‌گونه وابستگی کلاسی برای تضمین پایداری
            $statusCode = 500;
            $message = 'خطای ناشناخته سیستمی';
            $errors = [];
            $errorCode = 'INTERNAL_ERROR';

            if ($exception instanceof \Core\Exceptions\ValidationException) {
                $statusCode = 422;
                $message = 'اعتبارسنجی داده‌ها شکست خورد';
                $errors = $exception->getErrors();
                $errorCode = 'VALIDATION_ERROR';
            } elseif ($exception instanceof \Core\Exceptions\UnauthorizedException) {
                $statusCode = 401;
                $message = $exception->getMessage() ?: 'احراز هویت لازم است';
                $errorCode = 'UNAUTHORIZED';
            } elseif ($exception instanceof \Core\Exceptions\SecurityException) {
                $statusCode = 403;
                $message = $exception->getMessage() ?: ($exception instanceof \Core\Exceptions\FraudDetectedException ? 'فعالیت مشکوک شناسایی شد' : 'بررسی امنیتی ناموفق');
                $errorCode = $exception instanceof \Core\Exceptions\FraudDetectedException ? 'FRAUD_DETECTED' : 'FORBIDDEN';
            } elseif ($exception instanceof \Core\Exceptions\NotFoundException) {
                $statusCode = 404;
                $message = $exception->getMessage() ?: 'آدرس یا منبع یافت نشد';
                $errorCode = 'NOT_FOUND';
            } elseif ($exception instanceof \Core\Exceptions\InsufficientBalanceException) {
                $statusCode = 400;
                $message = $exception->getMessage() ?: 'موجودی حساب کافی نیست';
                $errorCode = 'INSUFFICIENT_FUNDS';
            } elseif ($exception instanceof \Core\Exceptions\RateLimitExceededException) {
                $statusCode = 429;
                $message = $exception->getMessage() ?: 'تعداد درخواست‌ها بیش از حد مجاز است';
                $errorCode = 'RATE_LIMITED';
            } elseif ($exception instanceof \Core\Exceptions\InvalidStateException) {
                $statusCode = 409;
                $message = $exception->getMessage() ?: 'وضعیت درخواست نامعتبر است';
                $errorCode = 'CONFLICT';
            } elseif ($exception instanceof \App\Exceptions\SessionException) {
                $statusCode = 419;
                $message = $exception->getMessage() ?: 'نشست کاربری نامعتبر یا منقضی شده است';
                $errorCode = 'SESSION_ERROR';
            } elseif ($exception instanceof \App\Exceptions\PaymentGatewayException) {
                $exceptionCode = $exception->getCode();
                $statusCode = $exceptionCode >= 400 && $exceptionCode <= 599 ? $exceptionCode : 500;
                // FIX-MODULE1-H4: هم‌راستا با مسیر قرارداد خطا — پیام خام provider
                // فقط در debug؛ در production پیام عمومی ثابت.
                $debug = (bool) config('app.debug', false);
                $message = ($debug && $exception->getMessage() !== '')
                    ? $exception->getMessage()
                    : 'خطا در پردازش پرداخت؛ لطفاً کمی بعد دوباره تلاش کنید';
                $errorCode = 'PAYMENT_GATEWAY_ERROR';
            } elseif ($exception instanceof \Core\Exceptions\PayloadTooLargeException) {
                $statusCode = 413;
                $message = 'حجم داده‌ی ارسالی بیش از حد مجاز است';
                $errorCode = 'PAYLOAD_TOO_LARGE';
            } elseif ($exception instanceof \Core\Exceptions\CircuitBreakerOpenException) {
                $statusCode = 503;
                $message = 'سرویس موقتاً در دسترس نیست؛ لطفاً کمی بعد تلاش کنید';
                $errorCode = 'SERVICE_UNAVAILABLE';
            } elseif ($exception instanceof \Core\Exceptions\RateLimitedFailure) {
                $statusCode = 429;
                $message = 'محدودیت نرخ درخواست سرویس بیرونی؛ لطفاً کمی بعد تلاش کنید';
                $errorCode = 'RATE_LIMITED';
            } elseif ($exception instanceof \Core\Exceptions\ProviderUnavailable
                || $exception instanceof \Core\Exceptions\TransientException) {
                $statusCode = 503;
                $message = 'سرویس موقتاً در دسترس نیست؛ لطفاً کمی بعد تلاش کنید';
                $errorCode = 'SERVICE_UNAVAILABLE';
            } elseif ($exception instanceof \Core\Exceptions\ExternalServiceException) {
                $statusCode = 502;
                $message = 'خطا در ارتباط با سرویس بیرونی';
                $errorCode = 'EXTERNAL_SERVICE_ERROR';
            } elseif ($exception instanceof \Core\Exceptions\DomainException || $exception instanceof \DomainException) {
                // FIX-P4-5: هم‌راستا با شاخهٔ قرارداد خطا — هر دو کلاس (Core و سراسری)
                $statusCode = 400;
                $message = $exception->getMessage() ?: 'خطای پردازش درخواست';
                $errorCode = 'DOMAIN_LOGIC_ERROR';
            } elseif ($exception instanceof \Core\Exceptions\BusinessException) {
                // هم‌راستا با مسیر اصلی: نقض قانون کسب‌وکار خطای سرور نیست.
                $exceptionCode = $exception->getCode();
                $statusCode = (is_int($exceptionCode) && $exceptionCode >= 400 && $exceptionCode <= 599)
                    ? $exceptionCode
                    : 422;
                $message = $exception->getMessage() ?: 'خطای بیزینسی';
                $errorCode = 'BUSINESS_RULE_ERROR';
            } else {
                $debug = (bool) config('app.debug', false);
                $message = $debug 
                    ? ($exception->getMessage() ?: 'خطای سیستمی در حین پردازش رخ داد') 
                    : 'خطای سیستمی در حین پردازش رخ داد';
            }

            return [
                'success'    => false,
                'message'    => $message,
                'errors'     => $errors,
                'error_code' => $errorCode,
                'code'       => $statusCode,
                'meta'       => [
                    'trace_id' => self::fallbackTraceId(),
                    'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
                ],
            ];
        }
    }

    /**
     * FIX-MODULE1-H4: allowlist نوع‌دار جزئیات عمومیِ PaymentVerificationException.
     * فقط کلیدهای غیرمحرمانهٔ مصوب به کلاینت می‌رسند؛ باقی (پاسخ خام provider،
     * authority، شناسه‌های فنی و …) فقط در لاگ داخلی می‌مانند.
     *
     * @param array<string, mixed>|null $details
     * @return array<string, int|string>
     */
    private static function sanitizePublicPaymentDetails(?array $details): array
    {
        if (!$details) {
            return [];
        }

        $public = [];

        // http_code: وضعیت HTTP provider — عددی و غیرمحرمانه (تنها کلید مصوب فعلی).
        if (isset($details['http_code']) && is_numeric($details['http_code'])) {
            $public['http_code'] = (int) $details['http_code'];
        }

        return $public;
    }

    /** @return non-empty-string */
    private static function fallbackTraceId(): string
    {
        foreach (['HTTP_X_REQUEST_ID', 'REQUEST_ID'] as $key) {
            $candidate = $_SERVER[$key] ?? null;
            if (!is_string($candidate)) {
                continue;
            }

            $candidate = trim($candidate);
            // FIX-S4-3: هم‌راستاسازی الگو با get_trace_context/Logger::enrich —
            // افزودن «_» (پذیرش شناسه‌های داخلی REQ_… که قبلاً به‌اشتباه رد و
            // همبستگی درخواست از دست می‌رفت) و یکسان‌سازی کلاس کاراکترها.
            if ($candidate !== '' && preg_match('/^[\w.\-:]{1,128}$/', $candidate) === 1) {
                return $candidate;
            }
        }

        return uniqid('req-', true);
    }
}