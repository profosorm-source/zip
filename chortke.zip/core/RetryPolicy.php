<?php

declare(strict_types=1);

namespace Core;

use Throwable;

class RetryPolicy
{
    private int $maxAttempts;
    private int $initialDelayMs;
    private int $multiplier;
    private int $maxDelayMs;
    private ?CircuitBreaker $circuitBreaker;

    public function __construct(?CircuitBreaker $circuitBreaker = null) {
        $this->circuitBreaker = $circuitBreaker;
        $rawConfig = config('retry_policy', []);
        $config = is_array($rawConfig) ? $rawConfig : [];

        $maxAttempts = $config['max_attempts'] ?? 3;
        $initialDelayMs = $config['initial_delay_ms'] ?? 100;
        $multiplier = $config['multiplier'] ?? 2;
        $maxDelayMs = $config['max_delay_ms'] ?? 2000;

        $this->maxAttempts = is_int($maxAttempts) || (is_string($maxAttempts) && ctype_digit($maxAttempts))
            ? max(1, (int)$maxAttempts) : 3;
        $this->initialDelayMs = is_int($initialDelayMs) || (is_string($initialDelayMs) && ctype_digit($initialDelayMs))
            ? max(0, (int)$initialDelayMs) : 100;
        $this->multiplier = is_int($multiplier) || (is_string($multiplier) && ctype_digit($multiplier))
            ? max(1, (int)$multiplier) : 2;
        $this->maxDelayMs = is_int($maxDelayMs) || (is_string($maxDelayMs) && ctype_digit($maxDelayMs))
            ? max($this->initialDelayMs, (int)$maxDelayMs) : 2000;
    }

    /**
     * اجرای یک عملیات با retry و exponential backoff.
     *
     * @param string $context
     * @param callable $operation
     * @param array|null $retryOnExceptions
     * @return mixed
     * @throws Throwable
     */
    /** @param list<class-string>|null $retryOnExceptions */
    public function executeWithContext(string $context, callable $operation, ?array $retryOnExceptions = null): mixed
    {
        $attempt = 0;
        $delayMs = $this->initialDelayMs;

        self::recordAttempt($context); // Record the primary call in the budget

        while (true) {
            // Fail-fast if circuit breaker is open (for services that use it)
            // FIX-S7-2: خطای state-store (مثلاً قطع Redis) در لحظهٔ خواندن وضعیت مدار
            // نباید خودش استثنا بدهد و عملیات را مسدود کند — فقط پاسخ قطعی «open»
            // fail-fast می‌شود؛ خرابی سنسور = fail-open برای همین بهینه‌سازی.
            $circuitOpen = false;
            if ($this->circuitBreaker !== null) {
                try {
                    $circuitOpen = (bool)$this->circuitBreaker->isOpen($context);
                } catch (\Throwable $stateStoreError) {
                    $circuitOpen = false;
                }
            }
            if ($circuitOpen) {
                throw new \RuntimeException(
                    "Fail-fast: Circuit Breaker is OPEN for context {$context}.",
                    503
                );
            }

            try {
                return $operation();
            } catch (Throwable $exception) {
                $attempt++;

                if ($attempt >= $this->maxAttempts || !$this->shouldRetry($exception, $retryOnExceptions)) {
                    throw $exception;
                }

                // Enforce the cascading failure system-wide Retry Budget
                if (!self::acquireRetryBudget($context)) {
                    // BUGFIX-PHASE3-P31: قبلاً isset($this->logger) روی پراپرتی‌ای که هرگز در
                    // این کلاس تعریف نشده بود، همیشه false ارزیابی می‌شد ⇒ شاخه هشدار بحرانی
                    // «تمام شدن بودجه retry» کدِ مرده بود و رخداد retry_budget_exhausted
                    // هرگز ثبت نمی‌شد. با الگوی fail-safe سایر کلاس‌های core (logger() که
                    // در نبود کانتینر به FallbackLogger برمی‌گردد) جایگزین شد.
                    if (function_exists('logger')) {
                        logger()->alert('retry_budget_exhausted', [
                            'context' => $context,
                            'error' => $exception->getMessage()
                        ]);
                    }
                    // Refuse to execute retry and fail-fast to prevent retry storm
                    throw new \RuntimeException(
                        "Cascading failure protection: system-wide retry budget exhausted for context {$context}. " . $exception->getMessage(),
                        503,
                        $exception
                    );
                }

                // CORE-051: Apply random jitter (0.8x to 1.2x) to avoid synchronized retry storms
                $sleepMs = min($delayMs, $this->maxDelayMs);
                $jitterFactor = mt_rand(800, 1200) / 1000.0;
                $sleepWithJitter = max(1, (int)($sleepMs * $jitterFactor));

                usleep($sleepWithJitter * 1000);
                $delayMs = min($delayMs * $this->multiplier, $this->maxDelayMs);
            }
        }
    }

    /**
     * Backward compatibility. Use executeWithContext instead.
     */
    /** @param list<class-string>|null $retryOnExceptions */
    public function execute(callable $operation, ?array $retryOnExceptions = null): mixed
    {
        return $this->executeWithContext('global', $operation, $retryOnExceptions);
    }

    /**
     * Check and update the system-wide retry budget.
     */
    public static function acquireRetryBudget(string $context = 'global'): bool
    {
        // در تست‌ها budget check را skip می‌کنیم
        if (defined('PHPUNIT_RUNNING') || (function_exists('config') && config('app.env') === 'testing')) {
            return true;
        }
        $cache = Cache::getInstance();
        $resilienceConfig = (array)config('resilience.retry_budget', []);
        $contexts = (array)($resilienceConfig['contexts'] ?? []);
        $global = (array)($resilienceConfig['global'] ?? []);

        // FIX-M4-07: lookup قبلاً «دقیق» بود در حالی که تولیدکننده‌های context
        // namespace اضافه می‌سازند (BasePaymentGateway: 'service:payment_gateway:<gateway>')
        // و config فقط والد را تعریف می‌کرد ('service:payment_gateway') ⇒ override
        // اختصاصی هرگز اعمال نمی‌شد و همه به budget سراسری fallback می‌کردند.
        // اکنون: تطبیق دقیق → بلندترین پیشوندِ تعریف‌شده با مرز جداکننده (':' یا '.')
        // → سراسری. زیررشته‌های بدون مرز (مثل 'service:payment') هرگز match نمی‌شوند.
        $contextCfg = is_array($contexts[$context] ?? null) ? $contexts[$context] : [];
        if ($contextCfg === []) {
            $bestPrefixLen = 0;
            foreach ($contexts as $configKey => $configValue) {
                if (!is_string($configKey) || $configKey === '' || !is_array($configValue)) {
                    continue;
                }
                if (str_starts_with($context, $configKey . ':') || str_starts_with($context, $configKey . '.')) {
                    $keyLen = strlen($configKey);
                    if ($keyLen > $bestPrefixLen) {
                        $bestPrefixLen = $keyLen;
                        $contextCfg = $configValue;
                    }
                }
            }
        }

        $allowedPercentage = (int)($contextCfg['allowed_percentage'] 
                             ?? $global['allowed_percentage'] 
                             ?? 10);
                             
        $minAllowance = (int)($contextCfg['min_allowance'] 
                             ?? $global['min_allowance'] 
                             ?? 5);
        
        try {
            $currentTime = time();
            $totalCalls = 0;
            $retries = 0;
            
            // Sliding window 10 seconds
            for ($i = 0; $i < 10; $i++) {
                $bucket = ($currentTime - $i) % 10;
                $totalCalls += int_value($cache->get("retry_budget:{$context}:total_calls:{$bucket}", 0));
                $retries += int_value($cache->get("retry_budget:{$context}:retries:{$bucket}", 0));
            }
            
            // Cold start allowance
            if ($totalCalls < 50 && $retries < $minAllowance) {
                $currentBucket = $currentTime % 10;
                $cache->increment("retry_budget:{$context}:retries:{$currentBucket}", 1, 10);
                return true;
            }
            
            // Percentage limit
            if ($retries >= (int)($totalCalls * ($allowedPercentage / 100))) {
                return false; 
            }
            
            $currentBucket = $currentTime % 10;
            $cache->increment("retry_budget:{$context}:retries:{$currentBucket}", 1, 10);
            return true;
        } catch (\Throwable) {
            // Probabilistic Load Shedding fallback
            return mt_rand(1, 100) <= $allowedPercentage;
        }
    }

    /**
     * Record a non-retry attempt in the system-wide budget
     */
    public static function recordAttempt(string $context = 'global'): void
    {
        try {
            $currentBucket = time() % 10;
            Cache::getInstance()->increment("retry_budget:{$context}:total_calls:{$currentBucket}", 1, 10);
        } catch (\Throwable) {
            // Safe ignore
        }
    }

    /** @param list<class-string>|null $retryOnExceptions */
    private function shouldRetry(Throwable $exception, ?array $retryOnExceptions): bool
    {
        // Protocol/auth/validation failures are deterministic and must never
        // consume retry budget even though the domain exception hierarchy
        // ultimately extends RuntimeException.
        if ($exception instanceof \Core\Exceptions\PermanentFailure) {
            return false;
        }

        if ($exception instanceof \Error ||
            $exception instanceof \InvalidArgumentException) {
            return false;
        }

        if ($retryOnExceptions === null) {
            return $exception instanceof \Exception;
        }

        foreach ($retryOnExceptions as $type) {
            if ($exception instanceof $type) {
                return true;
            }
        }

        return false;
    }
}
