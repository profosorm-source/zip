<?php

declare(strict_types=1);

namespace Core\Strategies;

use Core\Cache;
use Core\RateLimitStrategy;

/**
 * SlidingWindowStrategy — استراتژی پنجره‌ی لغزنده
 *
 * کیفیت: دقیق‌ترین
 * نقطه ضعف: بیشترین حافظه (لیست تمام timestamps)
 *
 * نحوه کار:
 *   - تمام timestamps درخواست‌ها را ذخیره می‌کند
 *   - درخواست‌های قدیم‌تر از window حذف می‌شوند
 *   - اگر تعداد <= maxAttempts، اجازه می‌دهد
 *
 * بهترین برای: صورت‌حساب‌های دقیق، audit logging
 */
class SlidingWindowStrategy implements RateLimitStrategy
{
    private Cache $cache;
    private string $prefix = 'rl:sw:';

    public function __construct(Cache $cache) {
        $this->cache = $cache;
    }

    public function attempt(string $key, int $maxAttempts, int $decayMinutes): bool
    {
        $cacheKey = $this->prefix . $key;

        // CORE-041: Enforce atomicity using centralized lock to prevent race conditions
        // FIX-R36-W3 (F-A9a-10): کلوژر به‌جای bool از نگه‌دارنده‌های 'allow'/'deny'
        // استفاده می‌کند تا «ردِ واقعیِ لیمیت» از «نگرفتنِ قفل» قابل‌تفکیک شود.
        $result = $this->cache->withLock('lock:' . $cacheKey, function() use ($cacheKey, $maxAttempts, $decayMinutes) {
            $now = time();
            $windowStart = $now - ($decayMinutes * 60);

            // لیست timestamps را دریافت کن
            $timestamps = $this->cache->get($cacheKey, []);
            if (!is_array($timestamps)) {
                $timestamps = [];
            }

            // timestamps قدیم‌تر از window را حذف کن
            $timestamps = array_filter(
                $timestamps,
                fn($ts) => $ts > $windowStart
            );

            // تعداد درخواست‌های معتبر
            $count = count($timestamps);

            if ($count >= $maxAttempts) {
                return 'deny';
            }

            // timestamp جدید را اضافه کن
            $timestamps[] = $now;

            // ذخیره کن
            $this->cache->put($cacheKey, $timestamps, $decayMinutes);

            return 'allow';
        }, 5);

        if ($result === 'allow') {
            return true;
        }
        if ($result === 'deny') {
            return false;
        }

        // FIX-R36-W3 (F-A9a-10): باختِ گرفتن قفل (false از withLock) دیگر «429 کاذب
        // بی‌شمارش» تولید نمی‌کند — روی کلیدهای داغِ درحال-کانتشن (login، banner-click)
        // به شمارندهٔ اتمیک پنجرهٔ ثابت (INCR+EXPIRE اتمیک) fallback می‌شود تا ردّ
        // حاصل از کانتشن با ردّ واقعی ریت‌لیمیت یکی نشود و شمارش مصرف شود.
        // حتی این مسیر هم بدون شمارندهٔ در دسترس fail-closed می‌ماند (CORE-038 هم‌سو).
        $fixedKey = $this->prefix . 'fw:' . $key;
        $count = $this->cache->increment($fixedKey, 1, max(1, $decayMinutes * 60));
        if ($count === false) {
            return false;
        }
        $this->logLockContention($key, $count, $maxAttempts);
        return $count <= $maxAttempts;
    }

    /**
     * FIX-R36-W3 (F-A9a-10): رویداد جدای کانتشن قفل — برای تفکیک در داشبوردها از
     * ردّهای عادی ریت‌لیمیت (fail-silent؛ نباید مسیر حیاتی را بشکند).
     */
    private function logLockContention(string $key, int $count, int $maxAttempts): void
    {
        try {
            if (function_exists('logger')) {
                logger()->warning('rate_limit.lock_contention_fallback', [
                    'channel' => 'rate_limit',
                    'strategy' => $this->getName(),
                    'key_hash' => hash('sha256', $key),
                    'fixed_window_count' => $count,
                    'max_attempts' => $maxAttempts,
                    'allowed' => $count <= $maxAttempts,
                ]);
            }
        } catch (\Throwable) {
            // fail-silent — لاگ هرگز نباید مسیر لیمیت را بشکند
        }
    }

    public function getAttempts(string $key): int
    {
        $cacheKey = $this->prefix . $key;
        $timestamps = $this->cache->get($cacheKey, []);

        if (!is_array($timestamps)) {
            $timestamps = [];
        }

        // FIX-M2M5: شمارندهٔ fallback کانتشن (fw:) بخشی از state مصرفی است —
        // قبلاً فقط در attempt() نوشته می‌شد و اینجا خوانده نمی‌شد؛ در نتیجه
        // quota مؤثر بالاتر از maxAttempts گزارش می‌شد.
        $fallback = $this->cache->get($this->prefix . 'fw:' . $key);
        $fallbackCount = is_numeric($fallback) ? (int)$fallback : 0;

        return count($timestamps) + $fallbackCount;
    }

    public function availableIn(string $key): int
    {
        $cacheKey = $this->prefix . $key;
        $timestamps = $this->cache->get($cacheKey, []);

        if (!empty($timestamps) && is_array($timestamps)) {
            // FIX-P3-16: متغیر بلااستفادهٔ $oldest حذف شد؛ TTL باقی‌ماندهٔ کلید گزارش می‌شود
            $ttl = $this->cache->ttl($cacheKey);
            return max(0, $ttl);
        }

        // FIX-M2M5: وقتی state اصلی خالی است و فقط شمارندهٔ fallback باقی است،
        // Retry-After باید از TTL همان شمارنده بیاید (قبلاً 0 برمی‌گشت — ناقص)
        $fallbackTtl = $this->cache->ttl($this->prefix . 'fw:' . $key);
        return max(0, is_numeric($fallbackTtl) ? (int)$fallbackTtl : 0);
    }

    public function clear(string $key): void
    {
        // FIX-M2M5: پاکسازی هر دو namespace (اصلی + fallback کانتشن)
        $this->cache->forget($this->prefix . $key);
        $this->cache->forget($this->prefix . 'fw:' . $key);
    }

    public function getName(): string
    {
        return 'sliding_window';
    }
}
