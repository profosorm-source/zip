<?php

declare(strict_types=1);

namespace Core\Strategies;

use Core\Cache;
use Core\RateLimitStrategy;

/**
 * TokenBucketStrategy — استراتژی توکن‌های دوبازه‌ای
 *
 * کیفیت: عادل (بدون edge case)
 * استفاده: بهتر برای API rate limiting
 *
 * نحوه کار:
 *   - هر درخواست یک توکن می‌خورد
 *   - توکن‌ها با نرخ ثابت دوبازه‌ای تولید می‌شوند
 *   - مثال: 100 request در دقیقه = 100/60 ~= 1.67 token/second
 *
 * ذخیره‌سازی:
 *   - {count}: تعداد توکن‌های باقی‌مانده
 *   - {timestamp}: آخرین زمان به‌روز‌رسانی
 */
class TokenBucketStrategy implements RateLimitStrategy
{
    private Cache $cache;
    private string $prefix = 'rl:tb:';

    public function __construct(Cache $cache) {
        $this->cache = $cache;
    }

    public function attempt(string $key, int $maxAttempts, int $decayMinutes): bool
    {
        $cacheKey = $this->prefix . $key;

        // CORE-041: Wrap TokenBucket processing inside atomic lock
        // FIX-R36-W3 (F-A9a-10): کلوژر به‌جای bool از نگه‌دارنده‌های 'allow'/'deny'
        // استفاده می‌کند تا «ردِ واقعی (توکن خالی)» از «نگرفتنِ قفل» قابل‌تفکیک شود.
        $result = $this->cache->withLock('lock:' . $cacheKey, function() use ($cacheKey, $maxAttempts, $decayMinutes) {
            $bucket = $this->getBucket($cacheKey, $maxAttempts, $decayMinutes);

            // FIX-M11-R22-26: مصرفِ دورهٔ fallback (کانتشن قفل) از سطلِ اصلی کم می‌شود —
            // قبلاً شمارندهٔ fallback مستقل بود و مجموعِ مجاز تا ~۲ برابر سقف می‌رسید.
            $fallbackSpent = 0;
            // کلید fallback در attempt(): prefix.'fw:'.key — cacheKey = prefix.key است
            $rawKey = substr($cacheKey, strlen($this->prefix));
            $fwState = $this->cache->get($this->prefix . 'fw:' . $rawKey);
            if (is_array($fwState) && isset($fwState['count'])) {
                $fallbackSpent = max(0, (int) $fwState['count']);
            } elseif (is_numeric($fwState)) {
                $fallbackSpent = max(0, (int) $fwState);
            }
            if ($fallbackSpent > 0) {
                $bucket['tokens'] = min((float) $bucket['tokens'], (float) $bucket['max_tokens'] - $fallbackSpent);
            }

            // FIX-M2BR03 (سناریوی مرورگری /admin/verify-2fa): شرط allow قبلی
            // «tokens <= 0 → deny» بود؛ با refill کسری float (مثلاً 0.015 توکن
            // بعد از گذر ~۳ ثانیه از اتمام سطل) درخواست بعدی مجاز می‌شد و سطل
            // را منفی می‌کرد ⇒ گذرِ یک واحدی از سقف اعلامی (max=3 عملاً ۴ عبور).
            // سمانتیک کانونی token bucket: هر درخواست «۱ توکن کامل» هزینه دارد
            // ⇒ allow فقط وقتی tokens >= 1. توکن کسری باقی‌مانده دور ریخته نمی‌شود
            // (ذخیرهٔ float — Fractional Starvation Shield) و با ادامهٔ refill به 1
            // می‌رسد؛ این شرط دقیقاً با قرارداد availableIn() هم‌خوان است که
            // «tokens >= 1 → Retry-After = 0» می‌گوید.
            if ((float) $bucket['tokens'] < 1.0) {
                return 'deny';
            }

            // کاهش یک توکن
            $bucket['tokens']--;
            $bucket['updated_at'] = time();

            // BUGFIX-PHASE3-P312: قبلاً forever() (TTL یک‌سال) ذخیره می‌شد ⇒ رشد بی‌کران
            // حافظه Redis برای کلیدهای پرکاردینال (هر کاربر/IP یک سطل). سطل اکنون فقط تا
            // expire_at خودش زنده می‌ماند که در getBucket با هر فعالیت لغزان تمدید می‌شود
            // ⇒ سطل‌های غیرفعال حداکثر یک بازهٔ decay بعد از آخرین فعالیت حذف می‌شوند.
            $ttlSeconds = max(1, (int) $bucket['expire_at'] - time());
            $this->cache->setSeconds($cacheKey, $bucket, $ttlSeconds);

            return 'allow';
        }, 5);

        if ($result === 'allow') {
            return true;
        }
        if ($result === 'deny') {
            return false;
        }

        // FIX-R36-W3 (F-A9a-10): باختِ گرفتن قفل (false از withLock) دیگر «429 کاذب
        // بی‌شمارش» تولید نمی‌کند — fallback به شمارندهٔ اتمیک پنجرهٔ ثابت تا ردّ
        // ناشی از کانتشن قفل با ردّ واقعی ریت‌لیمیت اشتباه نشود. بدون شمارندهٔ
        // در دسترس، fail-closed می‌ماند (هم‌سو با CORE-038).
        $fixedKey = $this->prefix . 'fw:' . $key;
        $count = $this->cache->increment($fixedKey, 1, max(1, $decayMinutes * 60));
        if ($count === false) {
            return false;
        }
        $this->logLockContention($key, $count, $maxAttempts);
        return $count <= $maxAttempts;
    }

    /**
     * FIX-R36-W3 (F-A9a-10): رویداد جدای کانتشن قفل (fail-silent).
     */
    private function logLockContention(string $key, int $count, int $maxAttempts): void
    {
        try {
            if (function_exists('logger')) {
                logger()->warning('rate_limit.lock_contention_fallback', [
                    'channel' => 'rate_limit',
                    'strategy' => $this->getName(),
                    'key_hash' => hash('sha256', $key),
                    'fixed_window_count' => $count,
                    'max_attempts' => $maxAttempts,
                    'allowed' => $count <= $maxAttempts,
                ]);
            }
        } catch (\Throwable) {
            // fail-silent — لاگ هرگز نباید مسیر لیمیت را بشکند
        }
    }

    public function getAttempts(string $key): int
    {
        $cacheKey = $this->prefix . $key;
        $bucket = $this->cache->get($cacheKey);

        $consumed = 0;
        if (is_array($bucket) && isset($bucket['max_tokens'], $bucket['tokens'])) {
            // M2-Op1 (دقت Remaining): توکن‌ها float هستند (refill کسری — Fractional
            // Starvation Shield). بریدنِ (int) مصرف کسری باعث می‌شد Remaining تا
            // ۱ واحد بیشتر از واقعیت گزارش شود (مثال: tokens=27.4 → (int)2.6=2
            // → Remaining=28 در حالی که فقط ۲۷ درخواست کامل شدنی است).
            // ceil مصرف = سقف درخواست‌های «کامل» مصرف‌شده؛ بنابراین
            // Remaining = max − ceil(max − tokens) = floor(tokens) — عدد دقیق.
            // این قرارداد فقط رو به بالا محافظه‌کارانه است (هیچ‌گاه مصرف را کمتر
            // گزارش نمی‌کند) پس همهٔ مصرف‌کننده‌های امنیتی hits() (throttle،
            // checkLoginAttempt، checkApiLimit، middleware) سازگار می‌مانند.
            $consumed = max(0, (int) ceil((float) $bucket['max_tokens'] - (float) $bucket['tokens']));
        }

        // FIX-M2M5: شمارندهٔ fallback کانتشن بخشی از state مصرفی است — جمع با سطل
        $fallback = $this->cache->get($this->prefix . 'fw:' . $key);
        $fallbackCount = is_numeric($fallback) ? (int)$fallback : 0;

        return $consumed + $fallbackCount;
    }

    public function availableIn(string $key): int
    {
        $cacheKey = $this->prefix . $key;
        $bucket = $this->cache->get($cacheKey);

        if (!is_array($bucket)) {
            return 0;
        }

        // BUGFIX-PHASE3-P312 (هم‌سو): با TTL لغزان، expire_at دیگر «زمان ریست» نیست؛
        // availableIn باید زمانِ رسیدن توکن بعدی را گزارش کند (Retry-After معنادار).
        $tokens = is_numeric($bucket['tokens'] ?? null) ? (float) $bucket['tokens'] : 0.0;
        if ($tokens >= 1) {
            return 0;
        }

        $decaySeconds = (int) ($bucket['decay_seconds'] ?? 0);
        $maxTokens = is_numeric($bucket['max_tokens'] ?? null) ? (float) $bucket['max_tokens'] : 0.0;
        if ($decaySeconds > 0 && $maxTokens > 0) {
            return (int) max(1, (int) ceil(1 / ($maxTokens / $decaySeconds)));
        }

        // سطل‌های قدیمی بدون decay_seconds — رفتار قبلی
        if (!isset($bucket['expire_at'])) {
            return 0;
        }

        $left = $bucket['expire_at'] - time();
        return (int) max(0, $left);
    }

    public function availableInFallbackAware(string $key, bool $hasPrimaryState): int
    {
        // FIX-M2M5: نقطهٔ دسترسی عمومی برای خواندن Retry-After از namespace fallback
        if ($hasPrimaryState) {
            return $this->availableIn($key);
        }
        $fallbackTtl = $this->cache->ttl($this->prefix . 'fw:' . $key);
        return max(0, is_numeric($fallbackTtl) ? (int)$fallbackTtl : 0);
    }

    public function clear(string $key): void
    {
        // FIX-M2M5: پاکسازی هر دو namespace (اصلی + fallback کانتشن)
        $this->cache->forget($this->prefix . $key);
        $this->cache->forget($this->prefix . 'fw:' . $key);
    }

    public function getName(): string
    {
        return 'token_bucket';
    }

    /**
     * Bucket فعلی را دریافت می‌کند و توکن‌ها را دوبازه‌ای تولید می‌کند
     *
     * @return array{max_tokens: int|float, tokens: int|float, updated_at: int, expire_at: int}
     */
    private function getBucket(string $cacheKey, int $maxTokens, int $decayMinutes): array
    {
        $stored = $this->cache->get($cacheKey);

        if (!is_array($stored) || !isset($stored['tokens'])) {
            // Bucket جدید
            return [
                'max_tokens' => $maxTokens,
                'tokens' => $maxTokens, // Will be decremented in attempt()
                'updated_at' => time(),
                'expire_at' => time() + ($decayMinutes * 60),
                'decay_seconds' => $decayMinutes * 60, // BUGFIX-PHASE3-P312: برای availableIn
            ];
        }

        // Bucket موجود — توکن‌ها را دوبازه‌ای تولید کن
        $now = time();
        $elapsed = max(0, $now - $stored['updated_at']);
        // FIX-M11-R22-26: decaySeconds=0 دیگر DivisionByZeroError نمی‌دهد (max(1,...))
        $decaySeconds = max(1, $decayMinutes * 60);

        // نرخ تولید: maxTokens / decaySeconds
        // FIX-M11-R22-26: max_tokensِ مؤثر = min(stored, current) — تغییرِ config
        // (یا فراخوانی با سقف متفاوت روی یک کلید) فوراً اعمال می‌شود؛ قبلاً
        // مقدارِ ذخیره‌شده تا idle شدنِ سطل نادیده گرفته می‌شد.
        $effectiveMax = (float) min((float) $stored['max_tokens'], (float) $maxTokens);
        $tokensPerSecond = $effectiveMax / $decaySeconds;
        $newTokens = $elapsed * $tokensPerSecond;

        // اصلاح کلیدی الگوریتم سطل توکن (Token Bucket Fractional Starvation Shield):
        // تغییر نوع داده ذخیره‌سازی توکن‌ها از (int) به (float) جهت جلوگیری از حذف توکن‌های کسری در درخواست‌های مکرر و رگباری اپلیکیشن‌های موبایل
        $tokens = (float) min(
            min((float) $stored['max_tokens'], (float) $maxTokens),
            $stored['tokens'] + $newTokens
        );

        return [
            'max_tokens' => min((float) $stored['max_tokens'], (float) $maxTokens),
            'tokens' => $tokens,
            'updated_at' => $now,
            // BUGFIX-PHASE3-P312: TTL لغزان — سطل فعال هیچ‌وقت وسط فعالیت منقضی نمی‌شود
            // (که باعث burst اضافی می‌شد) و فقط پس از یک بازهٔ کامل بی‌فعالیتی حذف می‌شود.
            'expire_at' => $now + $decaySeconds,
            'decay_seconds' => $decaySeconds,
        ];
    }
}
