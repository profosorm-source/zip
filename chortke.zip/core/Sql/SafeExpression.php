<?php

declare(strict_types=1);

namespace Core\Sql;

/**
 * SafeExpression — Allowlist-based SQL expression parser & emitter.
 *
 * Philosophy
 * ──────────
 * Instead of asking "is this string dangerous?" (a blacklist), we ask
 * "is this string a member of a tightly-defined safe sub-grammar?"
 * (an allowlist). The output is structurally guaranteed to be:
 *
 *   - read-only (no DDL, no DML, no DCL keywords parsed at all),
 *   - free of stacked statements (parser stops at the first `;`),
 *   - free of comments (the lexer rejects them),
 *   - free of dangerous functions (only a whitelist of names is callable),
 *   - free of subqueries (no SELECT/UNION/parenthesised statements),
 *   - parameter-safe (the only placeholder is `?`, passed through bindings).
 *
 * Grammar (EBNF, simplified)
 * ──────────────────────────
 *   top         := expression [ [ "AS" ] alias_ident ]
 *   expression  := or_expr
 *   or_expr     := and_expr ( ( "OR" )  and_expr )*
 *   and_expr    := not_expr ( ( "AND" ) not_expr )*
 *   not_expr    := [ "NOT" ] cmp_expr
 *   cmp_expr    := add_expr [ cmp_op  ( add_expr | "?" | NULL ) ]
 *               |  add_expr [ "IS" [ "NOT" ] NULL ]
 *               |  add_expr [ "BETWEEN" add_expr "AND" add_expr ]
 *               |  add_expr [ "LIKE" ( string | "?" ) ]
 *   add_expr    := mul_expr ( ( "+" | "-" ) mul_expr )*
 *   mul_expr    := unary    ( ( "*" | "/" | "%" ) unary )*
 *   unary       := [ "-" ] primary
 *   primary     := number
 *               |  string                            // single-quoted literal
 *               |  "?"                               // bound placeholder
 *               |  "NULL" | "TRUE" | "FALSE"
 *               |  identifier ( "." ( identifier | "*" ) )?    // col, table.col, table.*
 *               |  function_call
 *               |  cast_call
 *               |  case_expr
 *               |  "(" expression ")"
 *   function_call := whitelisted_name "(" [ "DISTINCT" ] arg_list? ")"
 *   cast_call   := "CAST" "(" expression "AS" cast_type ")"
 *                | "CONVERT" "(" expression "," cast_type ")"     // MySQL two-arg form
 *   cast_type   := BINARY|CHAR|DATE|DATETIME|DECIMAL|DOUBLE|FLOAT|JSON|NCHAR|REAL
 *                | SIGNED|TIME|UNSIGNED     [ "INTEGER" after SIGNED/UNSIGNED ]
 *                [ "(" digits [ "," digits ] ")" ]           // closed, digits-only params
 *   arg_list    := expression ( "," expression )*
 *   case_expr   := "CASE" ( "WHEN" expression "THEN" expression )+
 *                  [ "ELSE" expression ] "END"
 *
 * NOT in the grammar (by design — silent reject):
 *   SELECT, UNION, INSERT, UPDATE, DELETE, DROP, ALTER, ...
 *   comments  (--, /* ... *​/, #),
 *   semicolons (;),
 *   subqueries,
 *   backslash escapes inside strings (use '' to escape a quote),
 *   nested SELECT in any form,
 *   `INTO OUTFILE`, `LOAD_FILE`, etc.
 *
 * Output
 * ──────
 * After successful parse, ->emit() returns a normalised, requoted SQL
 * fragment where every identifier is backtick-quoted and every literal
 * is properly escaped. This means the *output* string is what hits the
 * database, not the user's raw input — a structural guarantee.
 *
 * Usage
 * ─────
 *   $expr = SafeExpression::parse("SUM(CASE WHEN status='deleted' THEN 1 ELSE 0 END)");
 *   $sql  = $expr->emit();   // → SUM(CASE WHEN `status` = 'deleted' THEN 1 ELSE 0 END)
 *
 *   // With bindings (e.g. for whereRaw):
 *   $expr = SafeExpression::parse("end_date > ? AND status = ?", $allowedColumns);
 *
 * Function allowlist
 * ──────────────────
 * Only PURE, deterministic, READ-ONLY scalar functions are allowed. The list
 * intentionally excludes:
 *   - SLEEP, BENCHMARK, GET_LOCK, RELEASE_LOCK            (DoS / timing)
 *   - LOAD_FILE, INTO OUTFILE                              (file system)
 *   - USER, CURRENT_USER, DATABASE, VERSION, @@variables   (fingerprinting)
 *   - EXTRACTVALUE, UPDATEXML                              (error-based exfil)
 *   - REGEXP_*, RLIKE                                      (ReDoS surface)
 *   - any procedure/UDF
 */
final class SafeExpression
{
    /**
     * Whitelisted SQL function names. Lower-cased; matched case-insensitively.
     * Add to this list ONLY after a security review. Each entry must be:
     *   - deterministic (same inputs → same output),
     *   - read-only (no side effects, no I/O),
     *   - bounded (cannot be made to consume unbounded CPU/memory).
     */
    private const ALLOWED_FUNCTIONS = [
        // Aggregates
        'count', 'sum', 'avg', 'min', 'max',
        // Numeric
        'abs', 'ceil', 'ceiling', 'floor', 'round', 'mod', 'sign', 'truncate',
        'greatest', 'least', 'power', 'sqrt',
        // String (safe, bounded — no REGEXP family)
        'concat', 'concat_ws', 'length', 'char_length', 'lower', 'upper',
        'ltrim', 'rtrim', 'trim', 'substring', 'substr', 'left', 'right',
        'replace', 'lpad', 'rpad', 'reverse', 'locate', 'position', 'instr',
        // Date/time (no NOW with side-effect-y session vars)
        'now', 'curdate', 'curtime', 'current_date', 'current_time',
        'current_timestamp', 'unix_timestamp', 'from_unixtime',
        'date', 'time', 'year', 'month', 'day', 'hour', 'minute', 'second',
        'dayofweek', 'dayofyear', 'weekofyear', 'quarter',
        'date_add', 'date_sub', 'datediff', 'timediff', 'timestampdiff',
        'date_format', 'time_format', 'str_to_date',
        // NULL handling
        'coalesce', 'ifnull', 'nullif', 'isnull', 'if',
        // JSON read-only
        'json_extract', 'json_unquote', 'json_length', 'json_type',
        'json_contains', 'json_valid',
        // Casting (parameterised — see special handling)
        'cast', 'convert',
    ];

    private const COMPARISON_OPERATORS = ['=', '!=', '<>', '<', '>', '<=', '>=', '<=>'];

    /**
     * FIX-R36-W3 (F-A9a-11): سقف عمقِ تو در توییِ پرانتز — parser بازگشتی (~۹ فریم
     * به‌ازای هر سطح) قبلاً تا سقف ۴۰۹۶ کاراکترِ ورودی می‌توانست ~۲۰۴۸ سطح برود
     * (~۱۸k فریم پشته؛ روی PHP<8.3 سگفالت، روی 8.4 فقط Error دیرهنگام). سقف ۶۴
     * بسیار بالاتر از هر اکسپرشنِ مشروع SELECT-سطح-اپ است و fail-loud است.
     */
    private const MAX_PAREN_DEPTH = 64;

    /**
     * FIX-P4-6: انواع بستهٔ مجاز برای CAST/CONVERT — پارس و emit هر دو از این
     * منبع واحد استفاده می‌کنند؛ هر نوع خارج از این فهرست fail-loud می‌ماند.
     */
    private const CAST_TYPES = [
        'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'DOUBLE', 'FLOAT',
        'JSON', 'NCHAR', 'REAL', 'SIGNED', 'TIME', 'UNSIGNED',
    ];

    /** @var list<array{type:string,value:string,pos:int}> */
    private array $tokens;
    private int $pos = 0;
    /** FIX-R36-W3 (F-A9a-11): شمارندهٔ عمق پرانتزِ جاری در طول پارس. */
    private int $parenDepth = 0;
    /** @var list<string> */
    private array $allowedColumns; // empty = allow any identifier shape (still backtick-quoted)
    /**
     * Root AST node after successful parse.
     * @var array<string, mixed>
     */
    private array $ast;

    /** The original input — kept ONLY for error messages, never emitted. */
    private string $source;

    /**
     * Parse a raw expression string. Throws on any deviation from the grammar.
     *
     * @param string                  $sql              the user-provided expression
     * @param list<string>            $allowedColumns   optional whitelist of column names
     *                                                  (incl. "table.col"); empty = any
     * @return self                                     a parsed, ready-to-emit expression
     * @throws SqlExpressionException                   on lex / parse / policy failure
     */
    public static function parse(string $sql, array $allowedColumns = []): self
    {
        $self = new self();
        $self->source         = $sql;
        $self->allowedColumns = array_map('strtolower', $allowedColumns);
        $self->tokens         = $self->lex($sql);
        $self->ast            = $self->parseExpression();

        // BUGFIX-SAFEEXPR-AS-ALIAS-2026-06:
        // پشتیبانی از سینتکس استاندارد ` ... AS alias` در سطح top-level expression.
        // alias فقط یک identifier ساده مجاز است و نمی‌تواند keyword/reserved باشد.
        // فرم بدون AS هم پذیرفته می‌شود (مانند `COUNT(*) c`) چون SQL استاندارد آن را قبول دارد،
        // اما برای ایمنی حداقلی، حالت "implicit alias" را فقط وقتی قبول می‌کنیم که عبارت
        // واقعاً به یک IDENT خالی منتهی شود (تا با اشتباه syntactic مانند `a b` که می‌تواند
        // typo باشد، silent pass نشویم).
        $aliasTok = null;
        if ($self->matchKeyword('as')) {
            $aliasTok = $self->consume();
            if ($aliasTok['type'] !== 'IDENT') {
                $self->fail("expected alias identifier after AS, got '{$aliasTok['value']}'", $aliasTok['pos']);
            }
        } elseif ($self->peek()['type'] === 'IDENT'
                  && $self->peek(1)['type'] === 'EOF') {
            // implicit alias: only accept when EXACTLY one identifier is left before EOF.
            $aliasTok = $self->consume();
        }

        if ($aliasTok !== null) {
            $alias = $aliasTok['value'];
            if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]{0,63}$/', $alias)) {
                $self->fail("invalid alias identifier '{$alias}'", $aliasTok['pos']);
            }
            // یک defense-in-depth کوچک: alias نباید با SQL reserved word اصلی برابر باشد.
            // این مانع اشتباه dev می‌شود (مثلاً `COUNT(*) as select`) که اگرچه با backtick
            // در MariaDB legal است، اما در کوئری‌های مصرف‌کننده‌ی خروجی ابهام‌ساز است.
            $reservedAliases = [
                'select','from','where','join','on','group','order','having','limit',
                'insert','update','delete','drop','alter','create','table','union',
                'as','and','or','not','null','true','false','case','when','then','else','end',
                'distinct','interval','is','in','like','between',
            ];
            if (in_array(strtolower((string)$alias), $reservedAliases, true)) {
                $self->fail("alias '{$alias}' is a reserved SQL keyword", $aliasTok['pos']);
            }
            $self->ast = ['kind' => 'aliased', 'expr' => $self->ast, 'alias' => $alias];
        }

        if ($self->peek()['type'] !== 'EOF') {
            $tok = $self->peek();
            $self->fail("unexpected token '{$tok['value']}' after expression", $tok['pos']);
        }
        return $self;
    }

    /** Emit the canonical, safely-quoted SQL fragment. */
    public function emit(): string
    {
        return $this->emitNode($this->ast);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LEXER
    // ─────────────────────────────────────────────────────────────────────────

    /** @return list<array{type:string,value:string,pos:int}> */
    private function lex(string $sql): array
    {
        if (strlen((string)$sql) > 4096) {
            $this->fail('expression exceeds maximum length (4096)', 0);
        }

        $tokens = [];
        $i = 0;
        $n = strlen((string)$sql);

        while ($i < $n) {
            $c = $sql[$i];

            // whitespace
            if (ctype_space($c)) { $i++; continue; }

            // hard-reject characters that have NO place in a safe expression
            if ($c === ';' || $c === '\\' || $c === '#' || $c === '@' || $c === '$') {
                $this->fail("forbidden character '{$c}' in expression", $i);
            }

            // FIX-MODULE1-M10: quoted identifier `` `col` `` — «شکرِ ورودی» است، نه
            // مسیر تزریق: emitter پس از پارس، هر identifier را به‌صورت canonic
            // بازنویسی/کوت می‌کند، پس محتوای backtick فقط باید کاراکترِ شناسه باشد
            // (همان قرارداد تست contract خود پروژه: IFNULL(`updated_at`, NOW())
            // انتظار pass دارد). backtick معنای «شناسه» می‌دهد، هرگز keyword.
            if ($c === '`') {
                $start = $i;
                $i++;
                $idStart = $i;
                while ($i < $n && $sql[$i] !== '`') {
                    if (ord($sql[$i]) < 32) {
                        $this->fail('control characters are not allowed in quoted identifiers', $i);
                    }
                    $i++;
                }
                if ($i >= $n) {
                    $this->fail('unterminated quoted identifier', $start);
                }
                $word = substr($sql, $idStart, $i - $idStart);
                // سقف ۶۴ = محدودیت طول identifier در MySQL/MariaDB
                if ($word === '' || strlen($word) > 64 || !preg_match('/^[A-Za-z0-9_$]+$/', $word)) {
                    $this->fail('invalid quoted identifier', $start);
                }
                $i++; // consume closing backtick
                $tokens[] = ['type' => 'IDENT', 'value' => $word, 'pos' => $start];
                continue;
            }

            // reject SQL comments early — they only exist to evade scanners
            if ($c === '-' && $i + 1 < $n && $sql[$i + 1] === '-') {
                $this->fail('SQL comments are not allowed', $i);
            }
            if ($c === '/' && $i + 1 < $n && $sql[$i + 1] === '*') {
                $this->fail('SQL comments are not allowed', $i);
            }

            // single-quoted string literal (SQL standard: '' escapes ')
            if ($c === "'") {
                $start = $i;
                $i++;
                $value = '';
                $closed = false;
                while ($i < $n) {
                    if ($sql[$i] === "'") {
                        if ($i + 1 < $n && $sql[$i + 1] === "'") {
                            $value .= "'";
                            $i += 2;
                            continue;
                        }
                        $i++;
                        $closed = true;
                        break;
                    }
                    // explicitly forbid backslash escapes — surprising MySQL behaviour
                    if ($sql[$i] === '\\') {
                        $this->fail('backslash escapes are not allowed in string literals; use \'\' to escape a quote', $i);
                    }
                    // FIX-S6-4: نویسه‌های کنترلی C0 (از جمله NUL) داخل لیترال رد می‌شوند؛
                    // قبلاً هر نویسه‌ای غیر از ' و \ عبور می‌کرد — خروجی emit به‌عنوان
                    // متنِ SQL به لاگ/پروتکل می‌رفت و NUL در ابزارهای خط‌مبنا مختل‌کننده است.
                    // fail-loud هم‌راستا با فلسفهٔ allowlist همین کلاس.
                    if (ord($sql[$i]) < 32) {
                        $this->fail('control characters are not allowed in string literals', $i);
                    }
                    $value .= $sql[$i];
                    $i++;
                }
                if (!$closed) $this->fail('unterminated string literal', $start);
                $tokens[] = ['type' => 'STRING', 'value' => $value, 'pos' => $start];
                continue;
            }

            // placeholder
            if ($c === '?') {
                $tokens[] = ['type' => 'PLACEHOLDER', 'value' => '?', 'pos' => $i];
                $i++;
                continue;
            }

            // numbers (int / decimal — no scientific notation, no hex)
            if (ctype_digit($c) || ($c === '.' && $i + 1 < $n && ctype_digit($sql[$i + 1]))) {
                $start = $i;
                $hasDot = false;
                while ($i < $n && (ctype_digit($sql[$i]) || (!$hasDot && $sql[$i] === '.'))) {
                    if ($sql[$i] === '.') $hasDot = true;
                    $i++;
                }
                // 🛡️ FIX-SAFEEXPR-NUM (خطای از-قبل): لیترالِ عددی هرگز نمی‌تواند
                // بلافاصله به نویسهٔ شناسه/عدد بچسبد — `0x41` و `1e10` قبلاً به
                // [NUMBER 0][IDENT x41] شکسته می‌شدند و مسیر implicit-alias آنها
                // را به‌شکل «0 AS x41» می‌پذیرفت (شکستِ تست safe_expression و
                // سورپرایز امنیتیِ قطع لیترال). حالا fail-loud است.
                if ($i < $n && (ctype_alnum($sql[$i]) || $sql[$i] === '_' || $sql[$i] === '.')) {
                    $this->fail('malformed numeric literal — hex/scientific notation and glued identifiers are not allowed', $start);
                }
                $tokens[] = ['type' => 'NUMBER', 'value' => substr($sql, $start, $i - $start), 'pos' => $start];
                continue;
            }

            // identifiers / keywords (letters, digits, underscore; must start with letter or _)
            if (ctype_alpha($c) || $c === '_') {
                $start = $i;
                while ($i < $n && (ctype_alnum($sql[$i]) || $sql[$i] === '_')) $i++;
                $word = substr($sql, $start, $i - $start);
                $lower = strtolower((string)$word);

                // multi-word operators
                if (in_array($lower, ['and','or','not','is','null','true','false','between','like','in',
                                       'case','when','then','else','end','distinct','as','interval'], true)) {
                    $tokens[] = ['type' => 'KEYWORD', 'value' => $lower, 'pos' => $start];
                } else {
                    $tokens[] = ['type' => 'IDENT', 'value' => $word, 'pos' => $start];
                }
                continue;
            }

            // multi-char operators
            $two = $i + 1 < $n ? $sql[$i] . $sql[$i + 1] : '';
            $three = $i + 2 < $n ? $two . $sql[$i + 2] : '';
            if ($three === '<=>') { $tokens[] = ['type'=>'OP','value'=>'<=>','pos'=>$i]; $i += 3; continue; }
            if (in_array($two, ['<=','>=','!=','<>'], true)) {
                $tokens[] = ['type'=>'OP','value'=>$two,'pos'=>$i]; $i += 2; continue;
            }

            // single-char tokens
            if (in_array($c, ['(',')',',','+','-','*','/','%','=','<','>','.'], true)) {
                // '.' is its own punctuation (used for table.column qualification);
                // other punctuation '(' ')' ',' are also PUNCT; the rest are OP.
                $type = in_array($c, ['(',')',',','.'], true) ? 'PUNCT' : 'OP';
                $tokens[] = ['type' => $type, 'value' => $c, 'pos' => $i];
                $i++;
                continue;
            }

            $this->fail("unexpected character '{$c}'", $i);
        }

        $tokens[] = ['type' => 'EOF', 'value' => '', 'pos' => $n];
        return $tokens;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PARSER (recursive descent, with precedence climbing for binary ops)
    // ─────────────────────────────────────────────────────────────────────────

    /** @return array<string, mixed> */
    private function parseExpression(): array { return $this->parseOr(); }

    /** @return array<string, mixed> */
    private function parseOr(): array
    {
        $left = $this->parseAnd();
        while ($this->matchKeyword('or')) {
            $right = $this->parseAnd();
            $left  = ['kind' => 'logical', 'op' => 'OR', 'left' => $left, 'right' => $right];
        }
        return $left;
    }

    /** @return array<string, mixed> */
    private function parseAnd(): array
    {
        $left = $this->parseNot();
        while ($this->matchKeyword('and')) {
            $right = $this->parseNot();
            $left  = ['kind' => 'logical', 'op' => 'AND', 'left' => $left, 'right' => $right];
        }
        return $left;
    }

    /** @return array<string, mixed> */
    private function parseNot(): array
    {
        if ($this->matchKeyword('not')) {
            return ['kind' => 'not', 'expr' => $this->parseNot()];
        }
        return $this->parseComparison();
    }

    /** @return array<string, mixed> */
    private function parseComparison(): array
    {
        $left = $this->parseAdd();

        // IS [NOT] NULL
        if ($this->matchKeyword('is')) {
            $negate = $this->matchKeyword('not');
            $this->expectKeyword('null');
            return ['kind' => 'is_null', 'expr' => $left, 'negate' => $negate];
        }

        // BETWEEN a AND b
        if ($this->matchKeyword('between')) {
            $lo = $this->parseAdd();
            $this->expectKeyword('and');
            $hi = $this->parseAdd();
            return ['kind' => 'between', 'expr' => $left, 'lo' => $lo, 'hi' => $hi];
        }

        // [NOT] LIKE
        if ($this->matchKeyword('like')) {
            $right = $this->parseAdd();
            return ['kind' => 'like', 'left' => $left, 'right' => $right, 'negate' => false];
        }

        // [NOT] IN (?, ?, ...)
        if ($this->matchKeyword('in')) {
            $this->expectPunct('(');
            $items = [];
            if ($this->peek()['value'] !== ')') {
                $items[] = $this->parseExpression();
                while ($this->matchPunct(',')) $items[] = $this->parseExpression();
            }
            $this->expectPunct(')');
            return ['kind' => 'in', 'expr' => $left, 'items' => $items, 'negate' => false];
        }

        // standard comparison
        if ($this->peek()['type'] === 'OP' && in_array($this->peek()['value'], self::COMPARISON_OPERATORS, true)) {
            $op = $this->consume()['value'];
            $right = $this->parseAdd();
            return ['kind' => 'cmp', 'op' => $op, 'left' => $left, 'right' => $right];
        }

        return $left;
    }

    /** @return array<string, mixed> */
    private function parseAdd(): array
    {
        $left = $this->parseMul();
        while ($this->peek()['type'] === 'OP' && in_array($this->peek()['value'], ['+','-'], true)) {
            $op    = $this->consume()['value'];
            $right = $this->parseMul();
            $left  = ['kind' => 'arith', 'op' => $op, 'left' => $left, 'right' => $right];
        }
        return $left;
    }

    /** @return array<string, mixed> */
    private function parseMul(): array
    {
        $left = $this->parseUnary();
        while ($this->peek()['type'] === 'OP' && in_array($this->peek()['value'], ['*','/','%'], true)) {
            $op    = $this->consume()['value'];
            $right = $this->parseUnary();
            $left  = ['kind' => 'arith', 'op' => $op, 'left' => $left, 'right' => $right];
        }
        return $left;
    }

    /** @return array<string, mixed> */
    private function parseUnary(): array
    {
        if ($this->peek()['type'] === 'OP' && $this->peek()['value'] === '-') {
            $this->consume();
            return ['kind' => 'neg', 'expr' => $this->parseUnary()];
        }
        return $this->parsePrimary();
    }

    /** @return array<string, mixed> */
    private function parsePrimary(): array
    {
        $tok = $this->peek();

        // parenthesised expression
        if ($tok['type'] === 'PUNCT' && $tok['value'] === '(') {
            // FIX-R36-W3 (F-A9a-11): گارد عمق — fail-loud پیش از رشدِ نامحدودِ فریم
            // (شمارنده فقط در طول همین parse زنده است؛ fail() کل پارس را رها می‌کند)
            if (++$this->parenDepth > self::MAX_PAREN_DEPTH) {
                $this->fail('expression nesting too deep (max ' . self::MAX_PAREN_DEPTH . ' parenthesis levels)', $tok['pos']);
            }
            $this->consume();
            $inner = $this->parseExpression();
            $this->parenDepth--;
            $this->expectPunct(')');
            return ['kind' => 'paren', 'expr' => $inner];
        }

        // INTERVAL n unit  (only inside DATE_ADD / DATE_SUB / TIMESTAMPADD-style args)
        if ($tok['type'] === 'KEYWORD' && $tok['value'] === 'interval') {
            $this->consume();
            $n = $this->parseAdd();          // numeric expression
            $unit = $this->peek();
            // unit must be a bare IDENT from a fixed allowlist (matches MySQL units)
            $allowedUnits = [
                'microsecond','second','minute','hour','day','week','month','quarter','year',
                'second_microsecond','minute_microsecond','minute_second',
                'hour_microsecond','hour_second','hour_minute',
                'day_microsecond','day_second','day_minute','day_hour','year_month',
            ];
            if ($unit['type'] !== 'IDENT' || !in_array(strtolower($unit['value']), $allowedUnits, true)) {
                $this->fail("expected INTERVAL unit (e.g. DAY, HOUR), got '{$unit['value']}'", $unit['pos']);
            }
            $this->consume();
            return ['kind' => 'interval', 'value' => $n, 'unit' => strtoupper($unit['value'])];
        }

        // literals
        if ($tok['type'] === 'NUMBER')      { $this->consume(); return ['kind' => 'num', 'value' => $tok['value']]; }
        if ($tok['type'] === 'STRING')      { $this->consume(); return ['kind' => 'str', 'value' => $tok['value']]; }
        if ($tok['type'] === 'PLACEHOLDER') { $this->consume(); return ['kind' => 'placeholder']; }

        if ($tok['type'] === 'KEYWORD') {
            if (in_array($tok['value'], ['null','true','false'], true)) {
                $this->consume();
                return ['kind' => 'const', 'value' => strtoupper($tok['value'])];
            }
            if ($tok['value'] === 'case') return $this->parseCase();
            if ($tok['value'] === 'distinct') {
                // bare DISTINCT only valid inside a function call (handled there)
                $this->fail("'DISTINCT' is only allowed inside a function call", $tok['pos']);
            }
        }

        if ($tok['type'] === 'IDENT') {
            $name = $this->consume()['value'];

            // Read the lookahead once; repeated peek() calls after consume()
            // return different tokens and confuse static narrowing.
            $after = $this->peek();

            // function call?
            if ($after['type'] === 'PUNCT' && $after['value'] === '(') {
                return $this->parseFunctionCall($name, $tok['pos']);
            }

            // column reference, optionally "table.col"
            if ($after['type'] === 'PUNCT' && $after['value'] === '.') {
                $this->consume(); // dot
                $next = $this->peek();
                $isIdent = $next['type'] === 'IDENT';
                $isStar  = $next['type'] === 'OP' && $next['value'] === '*';
                if (!$isIdent && !$isStar) {
                    $this->fail('expected identifier after "."', $next['pos']);
                }
                $col = $this->consume()['value'];
                return $this->makeColumn($name, $col, $tok['pos']);
            }
            return $this->makeColumn(null, $name, $tok['pos']);
        }

        $this->fail("unexpected token '{$tok['value']}'", $tok['pos']);
    }

    /** @return array<string, mixed> */
    private function parseCase(): array
    {
        $this->expectKeyword('case');
        $branches = [];
        while ($this->matchKeyword('when')) {
            $cond = $this->parseExpression();
            $this->expectKeyword('then');
            $then = $this->parseExpression();
            $branches[] = ['when' => $cond, 'then' => $then];
        }
        if (!$branches) $this->fail('CASE expression requires at least one WHEN branch', $this->peek()['pos']);
        $else = null;
        if ($this->matchKeyword('else')) $else = $this->parseExpression();
        $this->expectKeyword('end');
        return ['kind' => 'case', 'branches' => $branches, 'else' => $else];
    }

    /** @return array<string, mixed> */
    private function parseFunctionCall(string $name, int $pos): array
    {
        $lname = strtolower((string)$name);
        if (!in_array($lname, self::ALLOWED_FUNCTIONS, true)) {
            $this->fail("function '{$name}' is not in the allowlist", $pos);
        }

        // FIX-P4-6: CAST/CONVERT سینتکس پارامتری اختصاصی دارند (نه arg_list عمومی).
        // قبلاً CAST(expr AS type) در پارس می‌شکست ("expected ')', got 'as'") و
        // CONVERT(expr, type) به‌صورت SQL نامعتبر ``CONVERT(`x`, `SIGNED`)``
        // ساطع می‌شد (type به‌عنوان identifier backtick می‌شد).
        if ($lname === 'cast' || $lname === 'convert') {
            return $this->parseCastCall($lname, $pos);
        }

        $this->expectPunct('(');
        $distinct = false;
        $args = [];

        if ($this->peek()['value'] !== ')') {
            // DISTINCT only meaningful for COUNT/SUM/AVG, and only as first arg
            if ($this->peek()['type'] === 'KEYWORD' && $this->peek()['value'] === 'distinct') {
                if (!in_array($lname, ['count','sum','avg'], true)) {
                    $this->fail("DISTINCT not allowed in {$name}()", $this->peek()['pos']);
                }
                $this->consume();
                $distinct = true;
            }

            // COUNT(*) special-case
            if ($lname === 'count' && $this->peek()['type'] === 'OP' && $this->peek()['value'] === '*') {
                $this->consume();
                $this->expectPunct(')');
                return ['kind' => 'func', 'name' => $lname, 'distinct' => false, 'args' => [['kind' => 'star']]];
            }

            $args[] = $this->parseExpression();
            while ($this->matchPunct(',')) $args[] = $this->parseExpression();
        }
        $this->expectPunct(')');
        return ['kind' => 'func', 'name' => $lname, 'distinct' => $distinct, 'args' => $args];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EMITTER (canonical, safely-quoted output)
    // ─────────────────────────────────────────────────────────────────────────

    /** @param array<string, mixed> $n */
    private function emitNode(array $n): string
    {
        switch ($n['kind']) {
            case 'num':         return $this->nodeStr($n, 'value');
            case 'str':         return "'" . str_replace("'", "''", $this->nodeStr($n, 'value')) . "'";
            case 'placeholder': return '?';
            case 'const':       return $this->nodeStr($n, 'value');
            case 'star':
                // FIX-P4-6: star کیفیت‌دار (t.*) — جدولِ اعتبارسنجی‌شده با backtick
                $starTable = isset($n['table']) && is_string($n['table']) ? $n['table'] : null;
                return $starTable !== null
                    ? '`' . $starTable . '`.*'
                    : '*';
            case 'column':
                $table = $n['table'] ?? null;
                return $table !== null
                    ? '`' . $this->nodeStr($n, 'table') . '`.`' . $this->nodeStr($n, 'name') . '`'
                    : '`' . $this->nodeStr($n, 'name') . '`';
            case 'paren':       return '(' . $this->emitNode($this->nodeAst($n, 'expr')) . ')';
            case 'neg':         return '-' . $this->emitNode($this->nodeAst($n, 'expr'));
            case 'not':         return 'NOT ' . $this->emitNode($this->nodeAst($n, 'expr'));
            case 'is_null':     return $this->emitNode($this->nodeAst($n, 'expr')) . ' IS ' . ($n['negate'] ? 'NOT ' : '') . 'NULL';
            case 'cmp':         return $this->emitNode($this->nodeAst($n, 'left')) . ' ' . $this->nodeStr($n, 'op') . ' ' . $this->emitNode($this->nodeAst($n, 'right'));
            case 'arith':       return $this->emitNode($this->nodeAst($n, 'left')) . ' ' . $this->nodeStr($n, 'op') . ' ' . $this->emitNode($this->nodeAst($n, 'right'));
            case 'logical':     return $this->emitNode($this->nodeAst($n, 'left')) . ' ' . $this->nodeStr($n, 'op') . ' ' . $this->emitNode($this->nodeAst($n, 'right'));
            case 'between':     return $this->emitNode($this->nodeAst($n, 'expr')) . ' BETWEEN ' .
                                       $this->emitNode($this->nodeAst($n, 'lo')) . ' AND ' . $this->emitNode($this->nodeAst($n, 'hi'));
            case 'like':        return $this->emitNode($this->nodeAst($n, 'left')) . ' LIKE ' . $this->emitNode($this->nodeAst($n, 'right'));
            case 'in':
                $items = array_map(fn($x) => $this->emitNode($x), $this->nodeList($n, 'items'));
                return $this->emitNode($this->nodeAst($n, 'expr')) . ' IN (' . implode(', ', $items) . ')';
            case 'case':
                $s = 'CASE';
                foreach ($this->nodeList($n, 'branches') as $b) {
                    $s .= ' WHEN ' . $this->emitNode($this->nodeAst($b, 'when')) . ' THEN ' . $this->emitNode($this->nodeAst($b, 'then'));
                }
                if ($n['else'] !== null) $s .= ' ELSE ' . $this->emitNode($this->nodeAst($n, 'else'));
                return $s . ' END';
            case 'func':
                $args = array_map(fn($x) => $this->emitNode($x), $this->nodeList($n, 'args'));
                $prefix = $n['distinct'] ? 'DISTINCT ' : '';
                return strtoupper($this->nodeStr($n, 'name')) . '(' . $prefix . implode(', ', $args) . ')';
            case 'cast':
                // FIX-P4-6: emit بستهٔ CAST/CONVERT — type از CAST_TYPES و پارامترها
                // فقط رقم اعتبارسنجی‌شده‌اند، بنابراین emission کلمه‌به‌کلمه امن است.
                /**
                 * FIX-P4S-8: پارامترهای cast از consumeCastParam() همیشه int هستند
                 * (نه node) — باریک‌سازی تایپ مطابق الگوی nodeStr/خط ۷۰۲ همین فایل.
                 * @var list<int> $castParams
                 */
                $castParams = $this->nodeList($n, 'params');
                $castType = $this->nodeStr($n, 'type')
                    . ($castParams ? '(' . implode(',', $castParams) . ')' : '');
                $castExpr = $this->emitNode($this->nodeAst($n, 'expr'));
                return $this->nodeStr($n, 'func') === 'cast'
                    ? 'CAST(' . $castExpr . ' AS ' . $castType . ')'
                    : 'CONVERT(' . $castExpr . ', ' . $castType . ')';
            case 'interval':
                return 'INTERVAL ' . $this->emitNode($this->nodeAst($n, 'value')) . ' ' . $this->nodeStr($n, 'unit');
            case 'aliased':
                // BUGFIX-SAFEEXPR-AS-ALIAS-2026-06: alias در emit همیشه با AS صریح و backtick.
                return $this->emitNode($this->nodeAst($n, 'expr')) . ' AS `' . $this->nodeStr($n, 'alias') . '`';
        }
        throw new SqlExpressionException("internal: unknown node kind '" . $this->nodeStr($n, 'kind') . "'");
    }

    /**
     * Narrow an AST scalar field to a string. All leaf scalar fields are
     * guaranteed by the parser to be strings at runtime.
     * @param array<string, mixed> $n
     */
    private function nodeStr(array $n, string $key): string
    {
        /** @var string $v */
        $v = $n[$key];
        return $v;
    }

    /**
     * Narrow a recursive AST node field to an array node.
     * @param array<string, mixed> $n
     * @return array<string, mixed>
     */
    private function nodeAst(array $n, string $key): array
    {
        /** @var array<string, mixed> $v */
        $v = $n[$key];
        return $v;
    }

    /**
     * Narrow a list-of-nodes field.
     * @param array<string, mixed> $n
     * @return list<array<string, mixed>>
     */
    private function nodeList(array $n, string $key): array
    {
        /** @var list<array<string, mixed>> $v */
        $v = $n[$key];
        return $v;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // helpers
    // ─────────────────────────────────────────────────────────────────────────

    /** @return array<string, mixed> */
    private function parseCastCall(string $fn, int $pos): array
    {
        $this->expectPunct('(');
        $expr = $this->parseExpression();
        if ($fn === 'cast') {
            $this->expectKeyword('as');
        } else {
            $this->expectPunct(','); // MySQL two-arg CONVERT(expr, type)
        }

        $typeTok = $this->peek();
        if ($typeTok['type'] !== 'IDENT') {
            $this->fail("expected CAST/CONVERT target type, got '{$typeTok['value']}'", $typeTok['pos']);
        }
        $type = strtoupper($this->consume()['value']);
        if (in_array($type, ['SIGNED', 'UNSIGNED'], true)
            && $this->peek()['type'] === 'IDENT'
            && strtoupper($this->peek()['value']) === 'INTEGER') {
            $this->consume(); // SIGNED INTEGER / UNSIGNED INTEGER
        }
        if (!in_array($type, self::CAST_TYPES, true)) {
            $this->fail("CAST/CONVERT type '{$type}' is not allowed", $pos);
        }

        $params = [];
        if ($this->peek()['type'] === 'PUNCT' && $this->peek()['value'] === '(') {
            $this->consume();
            $params[] = $this->consumeCastParam($pos);
            if ($this->matchPunct(',')) {
                $params[] = $this->consumeCastParam($pos);
            }
            $this->expectPunct(')');
        }

        // sanity منطقی پارامترها (همه رقم اعتبارسنجی شده‌اند)
        $paramCount = count($params);
        $allowedCounts = match (true) {
            $type === 'DECIMAL' => [0, 1, 2],
            in_array($type, ['BINARY', 'CHAR', 'NCHAR'], true) => [0, 1],
            in_array($type, ['FLOAT', 'DOUBLE', 'REAL'], true) => [0, 1, 2],
            in_array($type, ['TIME', 'DATETIME'], true) => [0, 1],
            default => [0],
        };
        if (!in_array($paramCount, $allowedCounts, true)) {
            $this->fail("CAST/CONVERT type {$type} does not accept {$paramCount} parameter(s)", $pos);
        }
        if ($type === 'DECIMAL' && isset($params[1]) && $params[1] > $params[0]) {
            // FIX-P4S-9: isset معادل runtime دقیق paramCount===2 است (پارامترها فقط push می‌شوند)
            // و به PHPStan برای باریک‌سازی آفست‌ها هم کمک می‌کند.
            $this->fail('DECIMAL scale must not exceed precision', $pos);
        }
        if (in_array($type, ['TIME', 'DATETIME'], true) && isset($params[0]) && $paramCount === 1 && $params[0] > 6) {
            $this->fail("{$type} fractional seconds precision must be between 0 and 6", $pos);
        }

        $this->expectPunct(')');
        return ['kind' => 'cast', 'func' => $fn, 'expr' => $expr, 'type' => $type, 'params' => $params];
    }

    private function consumeCastParam(int $pos): int
    {
        $tok = $this->peek();
        if ($tok['type'] !== 'NUMBER' || !ctype_digit((string)$tok['value'])) {
            $this->fail("expected numeric CAST/CONVERT parameter, got '{$tok['value']}'", $tok['pos']);
        }
        $this->consume();
        return (int)(string)$tok['value'];
    }

    /**
     * FIX-P4S-10: شکل بازگشتی صریح (سطح 9) — دو شکل ممکن per kind.
     * @return array{kind:'star', table:string|null}|array{kind:'column', table:string|null, name:string}
     */
    private function makeColumn(?string $table, string $col, int $pos): array
    {
        // identifier shape was already validated by the lexer; double-check anti-injection
        // FIX-P4-6: '*' فقط از مسیر «t.*» به اینجا می‌رسد. ترتیب گارد قبلی در اولین
        // شرط (شکل identifier) آن را رد می‌کرد و شاخهٔ $col !== '*' عملاً مرده بود؛
        // در نتیجه table.* همیشه fail می‌شد. اکنون star فقط با جدولِ معتبر عبور می‌کند.
        if ($col !== '*' && !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $col)) {
            $this->fail('invalid identifier', $pos);
        }
        if ($table !== null && !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $table)) {
            $this->fail('invalid identifier', $pos);
        }

        // if an allowlist of columns is set, enforce it
        if (!empty($this->allowedColumns)) {
            $fqn = strtolower(($table !== null ? "$table." : '') . $col);
            $bare = strtolower((string)$col);
            if (!in_array($fqn, $this->allowedColumns, true) &&
                !in_array($bare, $this->allowedColumns, true)) {
                $this->fail("column '{$col}' is not in the allowlist", $pos);
            }
        }

        // FIX-P4-6: ستارهٔ کیفیت‌دار، جدول را نگه می‌دارد تا emit به‌صورت `t`.* باشد
        return $col === '*'
            ? ['kind' => 'star', 'table' => $table]
            : ['kind' => 'column', 'table' => $table, 'name' => $col];
    }

    /**
     * Reads relative to the mutable cursor: the same call can yield different
     * tokens after consume(), so it must not be treated as pure.
     *
     * @phpstan-impure
     * @return array{type:string, value:string, pos:int}
     */
    private function peek(int $off = 0): array { return $this->tokens[$this->pos + $off]; }
    /** @return array{type:string, value:string, pos:int} */
    private function consume(): array          { return $this->tokens[$this->pos++]; }

    private function matchKeyword(string $kw): bool
    {
        if ($this->peek()['type'] === 'KEYWORD' && $this->peek()['value'] === $kw) {
            $this->consume();
            return true;
        }
        return false;
    }

    private function matchPunct(string $p): bool
    {
        if ($this->peek()['type'] === 'PUNCT' && $this->peek()['value'] === $p) {
            $this->consume();
            return true;
        }
        return false;
    }

    private function expectKeyword(string $kw): void
    {
        if (!$this->matchKeyword($kw)) {
            $t = $this->peek();
            $this->fail("expected '{$kw}', got '{$t['value']}'", $t['pos']);
        }
    }

    private function expectPunct(string $p): void
    {
        if (!$this->matchPunct($p)) {
            $t = $this->peek();
            $this->fail("expected '{$p}', got '{$t['value']}'", $t['pos']);
        }
    }

    /** @return never */
    private function fail(string $why, int $pos): void
    {
        throw new SqlExpressionException(
            "SafeExpression: {$why} at position {$pos} in [" . substr($this->source, 0, 200) . ']'
        );
    }
}
