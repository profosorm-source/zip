<?php

declare(strict_types=1);

namespace Core;

/**
 * Redis connection wrapper for application services.
 *
 * This wrapper uses the PHP Redis extension and exposes Redis commands via __call().
 *
 * @method mixed    get(string $key)
 * @method bool     set(string $key, mixed $value, mixed $options = null)
 * @method bool     setex(string $key, int $ttl, mixed $value)
 * @method bool     setnx(string $key, mixed $value)
 * @method bool|int delete(string ...$keys)
 * @method bool|int del(string ...$keys)
 * @method bool     expire(string $key, int $ttl)
 * @method int      incr(string $key)
 * @method int      incrBy(string $key, int $value)
 * @method int      decr(string $key)
 * @method int      decrBy(string $key, int $value)
 * @method int      hIncrBy(string $key, string $field, int $value)
 * @method float    hIncrByFloat(string $key, string $field, float $value)
 * @method bool     hSet(string $key, string $field, mixed $value)
 * @method mixed    hGet(string $key, string $field)
 * @method array    hGetAll(string $key)
 * @method bool     hDel(string $key, string ...$fields)
 * @method bool     hExists(string $key, string $field)
 * @method int      lPush(string $key, mixed ...$values)
 * @method int      rPush(string $key, mixed ...$values)
 * @method mixed    lPop(string $key)
 * @method mixed    rPop(string $key)
 * @method int      lLen(string $key)
 * @method array    lRange(string $key, int $start, int $end)
 * @method int      sAdd(string $key, mixed ...$members)
 * @method int      sRem(string $key, mixed ...$members)
 * @method array    sMembers(string $key)
 * @method bool     sIsMember(string $key, mixed $member)
 * @method int      sCard(string $key)
 * @method float    zScore(string $key, mixed $member)
 * @method int      zAdd(string $key, float $score, mixed $member)
 * @method array    zRange(string $key, int $start, int $end, bool $withScores = false)
 * @method array    zRangeByScore(string $key, string $min, string $max, array $options = [])
 * @method array    zRevRangeByScore(string $key, string $max, string $min, array $options = [])
 * @method int      zRem(string $key, mixed ...$members)
 * @method int      zCard(string $key)
 * @method int      zCount(string $key, string $min, string $max)
 * @method int      publish(string $channel, string $message)
 * @method int      lTrim(string $key, int $start, int $end)
 * @method array    blPop(string $key, int $timeout)
 * @method array    brPop(string $key, int $timeout)
 * @method mixed    lMove(string $source, string $destination, string $whereFrom, string $whereTo)
 * @method mixed    blMove(string $source, string $destination, string $whereFrom, string $whereTo, int $timeout)
 * @method bool     select(int $db)
 * @method mixed    getSet(string $key, mixed $value)
 * @method bool     exists(string ...$keys)
 * @method bool     persist(string $key)
 * @method int      ttl(string $key)
 * @method bool     rename(string $key, string $newKey)
 * @method array    keys(string $pattern)
 * @method mixed    eval(string $script, array $args = [], int $numKeys = 0)
 * @method array    scan(mixed $iterator, string ...$options)
 * @method bool     multi()
 * @method array    exec()
 * @method bool     discard()
 * @method bool     flushDB()
 * @method bool     flushAll()
 * @method array    info(string $section = null)
 * @method bool     ping()
 */
class Redis
{
    private ?\Redis $client = null;
    private bool $connected = false;
    /** @var array<string, true> */
    private array $warnedUnavailableMethods = [];

    public function __construct() {
        if (!extension_loaded('redis')) {
            $this->connected = false;
            return;
        }

        $rawConfig = config('redis');
        $config = is_array($rawConfig) ? $rawConfig : [];
        $enabled = $config['enabled'] ?? true;
        if (!$enabled || in_array(strtolower((string)$enabled), ['false', '0', 'no', 'off'], true)) {
            $this->connected = false;
            return;
        }

        $rawHost = $config['host'] ?? '127.0.0.1';
        $rawPort = $config['port'] ?? 6379;
        $rawTimeout = $config['timeout'] ?? 1.5;
        $rawPassword = $config['password'] ?? '';
        $rawDb = $config['db'] ?? 0;

        $host = is_string($rawHost) && $rawHost !== '' ? $rawHost : '127.0.0.1';
        $port = is_int($rawPort) || (is_string($rawPort) && ctype_digit($rawPort)) ? (int)$rawPort : 6379;
        $timeout = is_int($rawTimeout) || is_float($rawTimeout) || (is_string($rawTimeout) && is_numeric($rawTimeout))
            ? (float)$rawTimeout
            : 1.5;
        $password = is_string($rawPassword) ? $rawPassword : '';
        $db = is_int($rawDb) || (is_string($rawDb) && ctype_digit($rawDb)) ? (int)$rawDb : 0;

        try {
            $redis = new \Redis();
            // Apply the same bound to socket reads. A TCP connection can be
            // established while the Redis event loop is stalled; without a
            // read timeout AUTH/SELECT/PING may block indefinitely.
            if (!$redis->connect($host, $port, $timeout, null, 0, $timeout)) {
                // BUGFIX-PHASE3-P320: شکست اتصال بی‌صدا نباشد (fail-noisy برای diagnosing)
                if (function_exists('logger') && !defined('PHPUNIT_RUNNING')) {
                    logger()->warning('redis.connect_failed', ['host' => $host, 'port' => $port]);
                }
                return;
            }
            // Some phpredis builds do not consistently apply connect()'s
            // read_timeout argument to commands issued immediately afterwards.
            $redis->setOption(\Redis::OPT_READ_TIMEOUT, $timeout);

            if ($password !== '') {
                // FIX-M1M20: نتیجهٔ auth/select/ping validate می‌شود — phpredis در برخی
                // شاخه‌ها به‌جای throw مقدار false برمی‌گرداند؛ در آن صورت اتصال باید
                // unavailable علامت بخورد، نه سالم با auth/DB ناموفق.
                if ($redis->auth((string)$password) !== true) {
                    throw new \RuntimeException('Redis AUTH failed.');
                }
            }

            if ($redis->select($db) !== true) {
                throw new \RuntimeException('Redis SELECT failed.');
            }
            $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
            // FIX-M1M22: قرارداد serialization صریح و پین‌شده — phpredis پیش‌فرضِ
            // buildهای متفاوت متفاوت دارد؛ این‌جا عمداً NONE پین می‌شود: مصرف‌کننده
            // (لایهٔ Cache) خودش encode/decode می‌کند و مقدار هرگز به serializer
            // وابستهٔ build نیست. TTLها همیشه int پاس داده می‌شوند (قرارداد caller).
            $redis->setOption(\Redis::OPT_SERIALIZER, \Redis::SERIALIZER_NONE);
            $pong = $redis->ping();
            if ($pong !== true && $pong !== '+PONG' && !is_string($pong)) {
                throw new \RuntimeException('Redis PING failed.');
            }
            if (is_string($pong) && str_contains($pong, 'PONG') === false && $pong !== '') {
                throw new \RuntimeException('Redis PING returned unexpected payload.');
            }

            $this->client = $redis;
            $this->connected = true;
        } catch (\Throwable $e) {
            $this->client = null;
            $this->connected = false;
            // BUGFIX-PHASE3-P320: خطا بدون لاگ قورت داده می‌شد؛ اکنون هشدار ثبت می‌شود
            // (fail-safe: در PHPUnit و پیش از بوت لاگر، بی‌صدا رد می‌شود)
            if (function_exists('logger') && !defined('PHPUNIT_RUNNING')) {
                logger()->warning('redis.unavailable.constructor', ['error' => $e->getMessage()]);
            }
        }
    }

    public function isAvailable(): bool
    {
        return $this->connected && $this->client !== null;
    }

    /**
     * FIX-M1M19: contract صریح — خطای اتصال وسط درخواست هرگز به موفقیت کاذب
     * تبدیل نمی‌شود؛ وضعیت wrapper به unavailable می‌رود (isAvailable() دیگر
     * true کهنه برنمی‌گرداند) و استثنا به caller بازپخش می‌شود تا هر مسیر
     * (lock/مالی/rate-limit) با قرارداد خودش fail-closed/fail-open تصمیم بگیرد.
     */
    private function markUnavailableAndRethrow(\Throwable $e): never
    {
        $this->connected = false;
        $this->client = null;
        if (function_exists('logger') && !defined('PHPUNIT_RUNNING')) {
            try {
                logger()->warning('redis.connection_lost.mid_request', ['error' => $e->getMessage()]);
            } catch (\Throwable) {
                // logger خودش مختل است — مهم نیست
            }
        }
        throw $e;
    }

    public function getClient(): ?\Redis
    {
        return $this->client;
    }

    /**
     * Get keys matching pattern using SCAN (non-blocking alternative to keys())
     * 
     * ✅ Performance: O(N) with server-side iteration (doesn't block Redis)
     * ❌ keys(): O(N) but blocks Redis server completely
     * 
     * @param string $pattern Key pattern to match (e.g., "user:*")
     * @param int $count Hint about number of keys to return per iteration
     * @param int $maxIterations FIX-S8-1: سقف تکرار SCAN (۰ = بدون سقف، رفتار قدیمی).
     *        قبلاً پارامتر dead code بود و فراخواننده‌های مسیر داغ حلقهٔ بدون‌سقف
     *        می‌گرفتند: با OPT_SCAN=SCAN_RETRY هر poll یک اسکن کامل keyspace روی
     *        نمونهٔ پرحجم = تقویت‌کنندهٔ CPU/latency (لنز DoS).
     * @return array<string> All matching keys
     */
    public function scanKeys(string $pattern, int $count = 100, int $maxIterations = 0): array
    {
        if (!$this->isAvailable()) {
            return [];
        }

        $client = $this->client;
        if ($client === null) {
            return [];
        }
        $keys = [];
        $iterator = null;
        $iterations = 0;

        // scan expects &$iterator, performs iterations and updates the pointer
        while (false !== ($batch = $client->scan($iterator, $pattern, $count))) {
            foreach ($batch as $key) {
                $keys[] = $key;
            }
            // FIX-S8-1: اعمال سقف تکرار — پس از جمع‌کردن دستهٔ فعلی قطع می‌کنیم
            // تا هر فراخوان حداکثر maxIterations دسته (و کلیدهای آن‌ها) برگرداند.
            if ($maxIterations > 0 && ++$iterations >= $maxIterations) {
                break;
            }
            if ($iterator === 0 || $iterator === '0') {
                break;
            }
        }

        return $keys;
    }

    /**
     * Graceful degradation: وقتی Redis در دسترس نیست، بجای crash:
     * - warning log میزنه (debug possible)
     * - false/null برمیگردونه (caller میتونه handle کنه)
     * - هرگز process رو kill نمیکنه
     *
     * callerها هنوز میتونن isAvailable() چک کنن — ولی اگه فراموش کردن crash نمیکنه.
     */
    /**
     * @param array<int|string, mixed> $arguments
     */
    public function __call(string $name, array $arguments): mixed
    {
        if (!$this->isAvailable()) {
            // Log once per Redis wrapper instance to avoid spam while keeping
            // independent requests/tests observable and isolated.
            if (!isset($this->warnedUnavailableMethods[$name])) {
                $this->warnedUnavailableMethods[$name] = true;
                try {
                    $eventContext = ['method' => $name];
                    if (function_exists('logger')) {
                        logger()->warning('redis.unavailable.graceful_skip', $eventContext);
                    }
                    if (PHP_SAPI === 'cli' && defined('STDERR')) {
                        // FIX-M1M21: diagnostics به STDERR — stdout ممکن است خروجی
                        // ساختاریافتهٔ worker (JSON/health) باشد و echo آن را خراب می‌کند
                        fwrite(STDERR, 'redis.unavailable.graceful_skip method=' . $name . PHP_EOL);
                    }
                } catch (\Throwable) {
                    if (PHP_SAPI === 'cli' && defined('STDERR')) {
                        fwrite(STDERR, 'redis.unavailable.graceful_skip method=' . $name . PHP_EOL);
                    }
                }
            }

            // Return safe defaults based on method type.
            // FIX-M1M21: متد ناشناخته دیگر با false پنهان نمی‌شود — fail-loud؛
            // فقط commandهای شناخته‌شده قرارداد unavailable typed دارند.
            return match($name) {
                'get', 'hGet', 'lPop', 'rPop', 'sPop' => null,
                'set', 'setex', 'setnx', 'hSet', 'del', 'delete', 'expire',
                'lPush', 'rPush', 'sAdd', 'sRem' => false,
                'incr', 'incrBy', 'decr', 'decrBy' => false,
                'hIncrBy', 'hIncrByFloat' => false,
                'exists', 'sIsMember' => false,
                'mGet', 'hGetAll', 'keys', 'lRange', 'sMembers', 'scan' => [],
                'ping' => false,
                'multi', 'exec', 'pipeline' => false,
                'eval' => false,
                'ttl' => -2, // قرارداد Redis: کلید غایب/در دسترس نبودن → never-expire نه؛ -2 یعنی «کلید وجود ندارد»
                'zRange', 'zRangeByScore', 'zRevRangeByScore' => [],
                'zAdd', 'zRem', 'zCard', 'zCount', 'lLen', 'sCard', 'publish', 'lTrim' => false,
                'hGetAll' => [],
                'info' => false,
                'select' => false,
                'getSet' => null,
                'hExists', 'hDel', 'persist', 'rename', 'flushDB', 'flushAll', 'discard' => false,
                'lMove', 'blMove', 'blPop', 'brPop' => null,
                default => throw new \BadMethodCallException(
                    "[Redis] Unknown command '{$name}' called while Redis is unavailable. "
                    . 'Add a typed unavailable contract for it or fix the method name.'
                ),
            };
        }

        // BUGFIX-REDIS-DEPRECATED-2026-06:
        //   Redis::delete() emits a PHP DEPRECATED notice in phpredis >= 6.0;
        //   callers across the codebase still use the legacy name. We
        //   silently translate delete()/setTimeout() to their canonical
        //   replacements so callers don't have to change and the logs
        //   stop being polluted with `redis_clear_failed` warnings on
        //   every successful login.
        $aliases = [
            'delete'     => 'del',
            'setTimeout' => 'expire',
        ];
        if (isset($aliases[$name])) {
            $name = $aliases[$name];
        }

        try {
            return $this->client->{$name}(...$arguments);
        } catch (\RedisException $e) {
            // FIX-M1M19: قطع‌شدن اتصال وسط درخواست — وضعیت wrapper به‌روز و
            // استثنا fail-noisy بازپخش می‌شود (هرگز موفقیت کاذب ساختگی نیست)
            $this->markUnavailableAndRethrow($e);
        }
    }
}
