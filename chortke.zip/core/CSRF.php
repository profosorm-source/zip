<?php
namespace Core;

/**
 * CSRF Protection
 *
 * از Container می‌خواند — نه app() مستقیم
 */
class CSRF
{
    /**
     * FIX-M2M15 (گزارش ماژول ۲، M15): نام توکن CSRF کانونیک و مرکزی.
     * قبلاً csrf_helper از config('csrf.token_name') می‌خواند و verifier فقط
     * '_csrf_token' هاردکد را می‌پذیرفت — تغییر config فرم‌های تولیدشده را
     * غیرقابل‌پذیرش می‌کرد (availability bug). قرارداد: همیشه این ثابت.
     */
    public const TOKEN_NAME = '_csrf_token';
    private Session $session;
    private Request $request;
    private UrlGenerator $urlGenerator;

    public function __construct(Session $session, Request $request, UrlGenerator $urlGenerator) {
        $this->session = $session;
        $this->request = $request;
        $this->urlGenerator = $urlGenerator;
    }

    public function generateToken(): string
    {
        if (!$this->session->has('_csrf_token')) {
            $this->session->set('_csrf_token', bin2hex(random_bytes(32)));
        }
        $token = $this->session->get('_csrf_token');
        return is_string($token) ? $token : '';
    }

    // CORE-036: Action-specific CSRF tokens for enhanced security on destructive actions
    public function generateTokenFor(string $action): string
    {
        $key = '_csrf_token_' . hash('sha256', $action);
        if (!$this->session->has($key)) {
            $this->session->set($key, bin2hex(random_bytes(32)));
        }
        $token = $this->session->get($key);
        return is_string($token) ? $token : '';
    }

    public function verifyTokenFor(string $action, ?string $token): bool
    {
        $key = '_csrf_token_' . hash('sha256', $action);
        $sessionToken = $this->session->get($key);
        if (!$sessionToken || !$token) {
            return false;
        }
        // FIX-S1-1: توکن‌های اکشن‌محور (CORE-036) مخصوص «اقدامات مخرب» هستند؛
        // بنابراین همان گایت Origin/Referer (MED-04) که verify() دارد را نیز
        // باید عبور کنند. پیش از این، این مسیر بدون بررسی Origin بود و هرگاه
        // فراخوانی‌پذیر می‌شد، لایهٔ دفاع دوم روی مسیرهای تخریبی غایب بود.
        // در CLI همیشه true و در محیط غیر production با Origin خالی عبور
        // می‌کند، پس رفتار تست‌ها و CLI تغییر نمی‌کند.
        if (!$this->validateOrigin()) {
            return false;
        }
        $isValid = hash_equals(str_value($sessionToken), str_value($token));
        if ($isValid) {
            $this->session->remove($key); // One-time usage
        }
        return $isValid;
    }

    public function getToken(): ?string
    {
        $token = $this->session->get('_csrf_token');
        return is_string($token) ? $token : '';
    }

    public function verify(?string $token): bool
    {
        $sessionToken = $this->getToken();
        if (!$sessionToken || !$token) return false;
        
        // MED-04 Fix: Check Origin/Referer for sensitive requests
        if (!$this->validateOrigin()) {
            return false;
        }

        return hash_equals($sessionToken, $token);
    }

    /**
     * MED-04 Fix: Validate Origin or Referer against application URL
     */
    private function validateOrigin(): bool
    {
        if (PHP_SAPI === 'cli') return true;
        $appOrigin = strtolower($this->urlGenerator->origin());

        $origin = str_value($this->request->header('Origin'));
        $referer = str_value($this->request->header('Referer'));
        
        if (config('app.env') === 'production' && $origin === '' && $referer === '') {
            return false;
        }

        if ($origin !== '' && $this->originOf($origin) !== $appOrigin) {
            return false;
        }
        if ($referer !== '' && $this->originOf($referer) !== $appOrigin) {
            return false;
        }

        return true;
    }

    private function originOf(string $url): ?string
    {
        $scheme = parse_url($url, PHP_URL_SCHEME);
        $host = parse_url($url, PHP_URL_HOST);
        $port = parse_url($url, PHP_URL_PORT);
        if (!is_string($scheme) || !is_string($host)) {
            return null;
        }

        return strtolower($scheme . '://' . $host . (is_int($port) ? ':' . $port : ''));
    }

    public function check(): bool
    {
        if (!in_array($this->request->method(), ['POST', 'PUT', 'DELETE', 'PATCH'], true)) {
            return true;
        }
        // Canonical project-wide contract: _csrf_token or X-CSRF-Token only.
        // Legacy names are deliberately rejected so new callers cannot silently
        // reintroduce a second CSRF protocol.
        $token = $this->request->input('_csrf_token');
        if (!is_string($token) || $token === '') {
            $token = $this->request->header('X-CSRF-Token');
        }
        return $this->verify(is_string($token) ? $token : null);
    }

    public function validate(): void
    {
        if (!$this->check()) {
            if (function_exists('logger')) {
                try {
                    logger()->warning('CSRF token validation failed', [
                        'channel' => 'security',
                        'ip' => function_exists('get_client_ip') ? get_client_ip() : 'unknown',
                        'uri' => $this->request->uri(),
                        'method' => $this->request->method(),
                    ]);
                } catch (\Throwable $e) {
                    // ignore logging failure
                }
            }

            // ✅ Fix L1: پرتاب SecurityException به جای exit مستقیم
            // این امکان می‌دهد ExceptionHandler بتواند پاسخ متناسب را هندل کند
            throw new \Core\Exceptions\SecurityException(
                'CSRF token validation failed',
                403
            );
        }
    }

    public function regenerate(): string
    {
        $this->session->remove('_csrf_token');
        return $this->generateToken();
    }
}
