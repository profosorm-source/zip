<?php

declare(strict_types=1);

namespace Core;

/**
 * Canonical filesystem path resolver.
 *
 * This class never generates URLs and never reads request headers. Every
 * returned path is contained under the configured application root.
 */
final class PathResolver
{
    private string $basePath;

    public function __construct(string $basePath)
    {
        if ($basePath === '' || str_contains($basePath, "\0")) {
            throw new \InvalidArgumentException('Application base path must be a non-empty filesystem path.');
        }

        $realBasePath = realpath($basePath);
        if ($realBasePath === false || !is_dir($realBasePath)) {
            throw new \InvalidArgumentException('Application base path must reference an existing directory.');
        }

        $this->basePath = rtrim($realBasePath, DIRECTORY_SEPARATOR);
    }

    public function base(string $path = ''): string
    {
        return $this->resolveWithin($this->basePath, $path);
    }

    public function storage(string $path = ''): string
    {
        return $this->resolveWithin($this->basePath . DIRECTORY_SEPARATOR . 'storage', $path);
    }

    public function public(string $path = ''): string
    {
        return $this->resolveWithin($this->basePath . DIRECTORY_SEPARATOR . 'public', $path);
    }

    private function assertInsideBase(string $realPath): bool
    {
        return $realPath === $this->basePath
            || str_starts_with($realPath, $this->basePath . DIRECTORY_SEPARATOR);
    }

    private function resolveWithin(string $root, string $path): string
    {
        if (str_contains($path, "\0")) {
            throw new \InvalidArgumentException('Filesystem path must not contain null bytes.');
        }

        $normalized = str_replace('\\', '/', trim($path));
        if ($normalized === '') {
            return rtrim($root, '/\\');
        }
        if (str_starts_with($normalized, '/') || preg_match('/^[A-Za-z]:\//', $normalized) === 1) {
            throw new \InvalidArgumentException('Filesystem path must be relative to its configured root.');
        }

        $segments = explode('/', $normalized);
        $safeSegments = [];
        foreach ($segments as $segment) {
            if ($segment === '' || $segment === '.') {
                continue;
            }
            if ($segment === '..') {
                throw new \InvalidArgumentException('Filesystem path traversal is not allowed.');
            }
            $safeSegments[] = $segment;
        }

        $resolved = rtrim($root, '/\\')
            . ($safeSegments === [] ? '' : DIRECTORY_SEPARATOR . implode(DIRECTORY_SEPARATOR, $safeSegments));

        // FIX-M1M6 (گزارش ماژول ۱، M6): اگر هر حلقه‌ای از زنجیرهٔ مسیر (ریشهٔ
        // storage/public یا هر پوشهٔ میانی یا برگ) symlink به بیرون از base باشد،
        // مسیر ظاهراً داخل base است ولی filesystem واقعی بیرون می‌رود. همهٔ
        // prefixهای موجود روی filesystem با realpath بررسی و symlink ناخواسته رد می‌شود.
        $realFinal = realpath($resolved);
        if ($realFinal !== false) {
            if (!$this->assertInsideBase($realFinal)) {
                throw new \InvalidArgumentException('Resolved path must stay inside the application base path.');
            }
            return $realFinal;
        }

        // مسیر نهایی موجود نیست — ولی ممکن است یکی از والدین symlink به بیرون باشد
        $prefix = $this->basePath;
        $rel = ltrim(substr($resolved, strlen($this->basePath)), DIRECTORY_SEPARATOR);
        if ($rel !== '') {
            foreach (explode(DIRECTORY_SEPARATOR, $rel) as $seg) {
                if ($seg === '') {
                    continue;
                }
                $prefix .= DIRECTORY_SEPARATOR . $seg;
                $realPrefix = realpath($prefix);
                if ($realPrefix !== false && !$this->assertInsideBase($realPrefix)) {
                    throw new \InvalidArgumentException('Path must not escape the application base path through symlinks.');
                }
            }
        }

        return $resolved;
    }
}
