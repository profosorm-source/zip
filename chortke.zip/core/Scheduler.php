<?php

namespace Core;

use App\Models\ActivityLog;

/**
 * Scheduler - سیستم زمانبندی وظایف
 *
 * نحوه استفاده:
 *   $scheduler = new Scheduler();
 *   $scheduler->everyMinute(fn() => ...);
 *   $scheduler->hourly(fn() => ...);
 *   $scheduler->daily('02:00', fn() => ...);
 *   $scheduler->weekly('Monday', '03:00', fn() => ...);
 *   $scheduler->run();
 *
 * در crontab:
 *   * * * * * php /var/www/html/cron.php >> /var/log/chortke-cron.log 2>&1
 */
class Scheduler
{
    /**
     * FIX-P4S-11: شکل آرایه کامل شد (کلید schedule در addJob همیشه ست می‌شود؛
     * docblock قبلی آن را نمی‌دید ⇒ خطای «آفست schedule وجود ندارد» روی گیت‌های
     * run()/dispatchAllAsync). کانفلیگ دو @var هم ادغام شد.
     *
     * @var list<array{key: string, name: string, callback: callable(): mixed, interval: int, schedule: string|null}> لیست وظایف ثبت‌شده
     */
    private array $jobs = [];

    /** @var string مسیر فایل lock */
    private string $lockDir;

    // BUGFIX-PHASE3-P315: فلگ مردهٔ $forceRegisterJobs و متد setter آن حذف شد —
    // از FIX-X147 به بعد جاب‌ها همیشه در Scheduler رجیستر می‌شوند (گیت زمان‌بندی
    // در run()/dispatchAllAsync است) و این فلگ هیچ‌جا خوانده نمی‌شد.

    private \App\Contracts\LoggerInterface $logger;

    private ActivityLog $activityLog;
    private Queue $queue;

    public function __construct(PathResolver $paths, ?ActivityLog $activityLog = null, ?string $lockDir = null, ?Queue $queue = null) {
        $this->activityLog = $activityLog ?? app(ActivityLog::class);
        $this->lockDir = $lockDir ?? rtrim($paths->storage('cron'), '/\\') . DIRECTORY_SEPARATOR;
        $this->queue = $queue ?? app(Queue::class);
        if (!is_dir($this->lockDir)) {
            @mkdir($this->lockDir, 0755, true);
        }
        $this->logger = logger();
    }

    // ==========================================
    //  ثبت وظایف با زمانبندی مختلف
    // ==========================================

    /** هر دقیقه */
    public function everyMinute(callable $callback, string $name = ''): self
    {
        return $this->addJob('every_minute', $callback, $name, 60);
    }

    /** هر N ثانیه */
    public function everySeconds(int $seconds, callable $callback, string $name = ''): self
    {
        return $this->addJob("every_{$seconds}_seconds", $callback, $name, $seconds);
    }

    /** هر N دقیقه */
    public function everyMinutes(int $minutes, callable $callback, string $name = ''): self
    {
        return $this->addJob("every_{$minutes}_minutes", $callback, $name, $minutes * 60);
    }

    /** هر ساعت (دقیقه ۰) */
    public function hourly(callable $callback, string $name = ''): self
    {
        return $this->addJob('hourly', $callback, $name, 3600);
    }

    /** هر ساعت در دقیقه مشخص */
    public function hourlyAt(int $minute, callable $callback, string $name = ''): self
    {
        // 🛡️ FIX-X147 (راند 37): گیتِ زمانی از «موقع رجیستر» به «موقع اجرای خودکار»
        // منتقل شد. قبلاً جاب فقط در دقیقهٔ موعدش رجیستر می‌شد → در پنل ادمین دیده
        // نمی‌شد و «اجرای تکی» خارج از موعد با «Cron job not found» ۵۰۰ می‌داد.
        // اکنون همیشه رجیستر می‌شود؛ run() خودش سرِ موعد می‌سنجد.
        return $this->addJob("hourly_at_{$minute}", $callback, $name, 3600, "hourly:{$minute}");
    }

    /** روزانه در ساعت مشخص (مثلاً '02:30') */
    public function daily(string $time, callable $callback, string $name = ''): self
    {
        [$h, $m] = explode(':', $time);
        return $this->addJob("daily_{$time}", $callback, $name, 86400, "daily:{$h}:{$m}");
    }

    /** هفتگی در روز و ساعت مشخص */
    public function weekly(string $day, string $time, callable $callback, string $name = ''): self
    {
        [$h, $m] = explode(':', $time);
        return $this->addJob("weekly_{$day}_{$time}", $callback, $name, 604800, "weekly:{$day}:{$h}:{$m}");
    }

    /** ماهانه در روز و ساعت مشخص */
    public function monthly(int $dayOfMonth, string $time, callable $callback, string $name = ''): self
    {
        [$h, $m] = explode(':', $time);
        return $this->addJob("monthly_{$dayOfMonth}_{$time}", $callback, $name, 2592000, "monthly:{$dayOfMonth}:{$h}:{$m}");
    }

    /**
     * 🛡️ FIX-X147: تطبیق زمان‌بندی صریح (جایگزین گیتِ رجیسترِ قبلی) —
     * فقط برای dispatch خودکار؛ اجرای دستی (تکی) همیشه مجاز است.
     *
     * FIX-M6-11: رفتار قبلی فقط تطبیق «دقیقهٔ دقیقِ فعلی» بود؛ اگر cron همان
     * دقیقه اجرا نمی‌شد (restart/deploy/lock contention)، نوبت روزانه/هفتگی/
     * ماهانه تا دورهٔ بعد به‌کلی از دست می‌رفت. اکنون موعد با مدل «slot»
     * سنجیده می‌شود: نزدیک‌ترین slot گذشته ≤ اکنون محاسبه می‌شود و اگر
     * lastRunِ موفق از آن عقب‌تر باشد، جاب یک‌بار catch-up می‌شود
     * (coalescing: چند دورهٔ از دست رفته = فقط یک اجرا). جابِ هرگزاجرانشده
     * مثل قبل فقط در دقیقهٔ موعد بالا می‌آید (بدون catch-up بی‌صدا) و عبور
     * از چند دورهٔ گم‌شده با warning «scheduler.missed_periods_coalesced»
     * قابل‌مشاهده است.
     */
    private function scheduleDue(?string $schedule, ?int $lastRun = null): bool
    {
        if ($schedule === null) return true;
        return $this->isDueForExplicitSchedule($schedule, $lastRun, time());
    }

    /** FIX-M6-11: محاسبهٔ موعد برای scheduleهای صریح (hourly/daily/weekly/monthly). */
    private function isDueForExplicitSchedule(string $schedule, ?int $lastRun, int $now): bool
    {
        $parts = explode(':', $schedule);
        $kind = $parts[0] ?? '';

        switch ($kind) {
            case 'hourly':
                $minute = max(0, min(59, (int)($parts[1] ?? 0)));
                for ($i = 0; $i < 2; $i++) {
                    $hourStart = strtotime(date('Y-m-d H', $now - $i * 3600) . ':00:00');
                    $ts = $hourStart !== false ? $hourStart + $minute * 60 : false;
                    if ($ts !== false && $ts <= $now) {
                        return $this->explicitSlotDue((int)$ts, 3600, $lastRun, $now, $schedule);
                    }
                }
                return false;

            case 'daily':
                $h = (int)($parts[1] ?? 0);
                $m = (int)($parts[2] ?? 0);
                $time = sprintf('%02d:%02d:00', $h, $m);
                for ($i = 0; $i < 2; $i++) {
                    $ts = strtotime(date('Y-m-d', $now - $i * 86400) . ' ' . $time);
                    if ($ts !== false && $ts <= $now) {
                        return $this->explicitSlotDue((int)$ts, 86400, $lastRun, $now, $schedule);
                    }
                }
                return false;

            case 'weekly':
                $day = strtolower($parts[1] ?? '');
                $h = (int)($parts[2] ?? 0);
                $m = (int)($parts[3] ?? 0);
                $time = sprintf('%02d:%02d:00', $h, $m);
                for ($i = 0; $i < 8; $i++) {
                    $dayStart = strtotime(date('Y-m-d', $now - $i * 86400));
                    $ts = $dayStart !== false ? strtotime($time, $dayStart) : false;
                    if ($ts !== false && $ts <= $now && strtolower(date('l', (int)$ts)) === $day) {
                        return $this->explicitSlotDue((int)$ts, 604800, $lastRun, $now, $schedule);
                    }
                }
                return false;

            case 'monthly':
                $dom = max(1, min(31, (int)($parts[1] ?? 1)));
                $h = (int)($parts[2] ?? 0);
                $m = (int)($parts[3] ?? 0);
                $time = sprintf('%02d:%02d:00', $h, $m);
                for ($i = 0; $i < 32; $i++) {
                    $dayStart = strtotime(date('Y-m-d', $now - $i * 86400));
                    $ts = $dayStart !== false ? strtotime($time, $dayStart) : false;
                    if ($ts !== false && $ts <= $now && (int)date('j', (int)$ts) === $dom) {
                        return $this->explicitSlotDue((int)$ts, 2592000, $lastRun, $now, $schedule);
                    }
                }
                return false;

            default:
                return true;
        }
    }

    /** FIX-M6-11: تصمیم نهایی موعد بر اساس slot و lastRun (coalescing + سقف lag). */
    private function explicitSlotDue(int $slotTs, int $interval, ?int $lastRun, int $now, string $schedule): bool
    {
        if ($lastRun === null || $lastRun <= 0) {
            // جاب هرگز اجرا نشده: رفتار قبلی — فقط در دقیقهٔ موعد (بدون catch-up بی‌صدا)
            return ($now - $slotTs) < 60;
        }

        if ($lastRun >= $slotTs) {
            return false; // این slot پوشش داده شده است
        }

        if (($now - $slotTs) > $interval) {
            // گارد دفاعی سقف lag — با most-recent-slot عملاً رخ نمی‌دهد
            return false;
        }

        // عبورِ چند دورهٔ گم‌شده تا این slot = coalesce به یک اجرا + alert
        if (($slotTs - $lastRun) > $interval && function_exists('logger')) {
            logger()->warning('scheduler.missed_periods_coalesced', [
                'schedule' => $schedule,
                'last_run' => $lastRun,
                'slot' => $slotTs,
                'missed_periods' => (int)floor(($slotTs - $lastRun) / $interval),
            ]);
        }

        return true; // catch-up یک‌بار (تیک‌های بعدی با lastRun بسته می‌شوند)
    }

    // ==========================================
    //  اجرا
    // ==========================================

    /**
     * اجرای همه وظایف واجد شرایط
     */
    /** @return array<string, mixed> */
    public function run(?string $onlyJobName = null): array
    {
        $results = [];

        foreach ($this->jobs as $job) {
            // اگر فیلتر اعمال شده باشد، نام جاب باید مطابقت داشته باشد
            if ($onlyJobName !== null && $job['name'] !== $onlyJobName) {
                continue;
            }

            $lastRunKey = 'cron_last_run:' . md5(str_value($job['key']));
            $mutexKey = 'cron_mutex:' . md5(str_value($job['key']));

            // FIX-M6-11: lastRun پیش از گیت موعد خوانده می‌شود تا مدل slot-based
            // (catch-up coalesced) بتواند تصمیم صحیح بگیرد.
            $lastRunTs = Cache::getInstance()->get($lastRunKey);
            $lastRunInt = $lastRunTs !== null ? int_value($lastRunTs) : 0;

            // 🛡️ FIX-X147: گیتِ زمان‌بندی صریح برای dispatch خودکار — جاب‌های
            // hourlyAt/daily/weekly/monthly همیشه رجیستر شده‌اند و فقط در دقیقهٔ
            // موعدشان اجرا می‌شوند. در اجرای تکی (دستی) زمان‌بندی نادیده گرفته می‌شود.
            if ($onlyJobName === null && !$this->scheduleDue(str_value($job['schedule'] ?? ''), $lastRunInt > 0 ? $lastRunInt : null)) {
                continue; // مثل رفتار قبلی: خارج از موعد اصلاً در صف/لاگ نمی‌آید
            }

            // ۱. بررسی فاصله زمانی از آخرین اجرای موفق (فقط برای کرون اتوماتیک)
            if ($onlyJobName === null) {
                if ($lastRunInt > 0 && (time() - $lastRunInt) < ($job['interval'] - 5)) {
                    $results[$job['name']] = ['status' => 'skipped', 'reason' => 'already_run_within_interval'];
                    continue;
                }
            }

            // ۲. دریافت قفل همزمانی (Finding #14 Fix: Dynamic TTL based on job interval)
            // X129-fix: TTL قبلی max(600,…) بود → برای جاب ۶۰ثانیه‌ای، مرگ دارندهٔ قفل
            // تا ۱۰ دقیقه کل جاب را یخ می‌زد. اکنون TTL ≈ ۲× بازه (کف ۱۲۰، سقف ۷۲۰۰).
            $lockTtl = min(7200, max(120, (int) $job['interval'] * 2));
            try {
                if (!Cache::getInstance()->lock($mutexKey, $lockTtl)) {
                    $results[$job['name']] = ['status' => 'skipped', 'reason' => 'concurrent_mutex'];
                    continue;
                }
            } catch (\Throwable $e) {
                // CORE-055: Gracefully skip execution if the locking mechanism fails (e.g., Redis down or file lock disabled in prod)
                $this->logger->warning("Cron [{$job['name']}] lock mechanism failure: " . $e->getMessage());
                $results[$job['name']] = ['status' => 'skipped', 'reason' => 'lock_failure_skipped'];
                continue;
            }

            $start = microtime(true);
            $heartbeatActive = $this->startLockHeartbeat($mutexKey, $lockTtl);
            try {
                $output = ($job['callback'])();
                $duration = round((microtime(true) - $start) * 1000, 2);

                // ۳. ثبت موفقیت اجرای این بازه
                Cache::getInstance()->forever($lastRunKey, time());
                $results[$job['name']] = [
                    'status'   => 'ok',
                    'duration' => $duration . 'ms',
                    'output'   => $output,
                ];

                // CORE-056: Redact sensitive details from execution output before storing in persistent log files
                $loggedOutput = is_array($output) ? $this->redactSensitiveData($output) : ($output ?? []);

                $this->logger->info("Cron [{$job['name']}] OK in {$duration}ms", is_array($loggedOutput) ? $loggedOutput : []);

                // ثبت لاگ در activity_logs برای نمایش در پنل مدیریت
                try {
                    $this->activityLog->log(
                        'cron',
                        $job['name'] . ' [' . $job['key'] . ']',
                        null,
                        array_merge(
                            is_array($loggedOutput) ? $loggedOutput : [],
                            [
                                'job_key'        => $job['key'],
                                'execution_time' => $duration . 'ms',
                            ]
                        )
                    );
                } catch (\Throwable $logEx) {
                    // لاگ نشدن نباید اجرای cron رو متوقف کنه
                }

            } catch (\Throwable $e) {
                $duration = round((microtime(true) - $start) * 1000, 2);
                $results[$job['name']] = [
                    'status'  => 'error',
                    'message' => $e->getMessage(),
                    // FIX-R36-W3 (F-A9b-14): مسیر مطلق سرور (file:line) قبل از رفتن به
                    // نتایج پنل cron ادمین/activity_log با {ROOT} ماسک می‌شود — هم‌الگوی
                    // ExceptionHandler::maskPath. شمارهٔ خط حفظ می‌شود (عیب‌یابی ممکن).
                    'file'    => $this->maskFilePath($e->getFile()) . ':' . $e->getLine(),
                ];

                $this->logger->error("Cron [{$job['name']}] FAILED: " . $e->getMessage(), [
                    'file' => $this->maskFilePath($e->getFile()),
                    'line' => $e->getLine(),
                ]);

                // release lock در صورت خطا هم
            } finally {
                // release lock after execution — alarm فقط اگر خودمان نصب کرده‌ایم
                if ($heartbeatActive) {
                    $this->stopLockHeartbeat();
                }
                Cache::getInstance()->unlock('cron_mutex:' . md5(str_value($job['key'])));
            }
        }

        return $results;
    }

    /**
     * ارسال تمامی وظایف به Queue به جای اجرای همزمان (Synchronous)
     */
    /** @return array<string, mixed> */
    public function dispatchAllAsync(?string $onlyJobName = null): array
    {
        $results = [];
        $queue = $this->queue;

        foreach ($this->jobs as $job) {
            if ($onlyJobName !== null && $job['name'] !== $onlyJobName) {
                continue;
            }

            $lastRunKey = 'cron_last_run:' . md5(str_value($job['key']));
            // 🛡️ FIX-P34: مارکر in-flight — چون lastRun فقط پس از «اجرای موفق» توسط
            // ورکر ثبت می‌شود، در مدت ماندن جاب در صف (backlog)، هر تیکِ دقیقه‌ایِ
            // cron.php یک کپی تکراری دیگر push می‌کرد و همهٔ کپی‌ها پشت‌سرهم
            // اجرا می‌شدند (mutex فقط همزمانی را می‌بندد نه اجرای ترتیبیِ تکراری).
            $dispatchKey = 'cron_dispatching:' . md5(str_value($job['key']));

            // FIX-M6-11: lastRun پیش از گیت موعد خوانده می‌شود (مدل slot-based).
            $lastRunTs = Cache::getInstance()->get($lastRunKey);
            $lastRunInt = $lastRunTs !== null ? int_value($lastRunTs) : 0;

            // 🛡️ FIX-P34: گیت زمان‌بندی صریح هم‌راستا با run() (FIX-X147) — dispatch
            // خودکار جاب‌های hourlyAt/daily/weekly/monthly فقط در دقیقهٔ موعد.
            // قبلاً جابِ روزانهٔ شکست‌خورده تمام روزِ بعد، هر دقیقه یک‌بار dispatch می‌شد.
            if ($onlyJobName === null && !$this->scheduleDue(str_value($job['schedule'] ?? ''), $lastRunInt > 0 ? $lastRunInt : null)) {
                continue;
            }

            if ($onlyJobName === null) {
                if ($lastRunInt > 0 && (time() - $lastRunInt) < ($job['interval'] - 5)) {
                    $results[$job['name']] = ['status' => 'skipped', 'reason' => 'already_run_within_interval'];
                    continue;
                }
            }

            try {
                // 🛡️ FIX-9a-7 (Audit Task 9-a): claim اتمیک مارکر dispatch با
                // Cache::add (SET NX). الگوی قبلی get-then-put (بررسی get در بالا +
                // put پس از push) بین دو نود/تیک هم‌زمان رقابتی بود: هر دو get=null
                // می‌گرفتند، هر دو push می‌کردند و مارکر فقط آخرین را ثبت می‌کرد ⇒
                // dispatch دوبل. اکنون فقط برندهٔ claim اتمیک push می‌کند؛ TTL بر
                // حسب ثانیه = بازهٔ جاب گردشده به دقیقه (عین semantics put قبلی).
                // مارکر تنها پس از push موفق زنده می‌ماند؛ شکست push → forget تا
                // تیک بعدی بتواند دوباره تلاش کند.
                $dispatchClaimed = true;
                if ($onlyJobName === null) {
                    $dispatchClaimed = Cache::getInstance()->add(
                        $dispatchKey,
                        time(),
                        max(60, (int) ceil(((int) $job['interval']) / 60) * 60)
                    );
                    if (!$dispatchClaimed) {
                        $results[$job['name']] = ['status' => 'skipped', 'reason' => 'dispatch_already_in_flight'];
                        continue;
                    }
                }

                // Finding #15 Fix: Push task to queue without prematurely setting last_run_key.
                // last_run_key is recorded upon successful execution in executeJobByName().
                $queue->push(\App\Jobs\RunCronTaskJob::class, ['task_name' => $job['name']]);
                $results[$job['name']] = ['status' => 'queued'];
            } catch (\Throwable $e) {
                // claimِ مانده از pushِ شکست‌خورده آزاد شود تا retry تیک بعدی ممکن باشد
                if ($onlyJobName === null && $dispatchClaimed === true) {
                    Cache::getInstance()->forget($dispatchKey);
                }
                $results[$job['name']] = ['status' => 'error', 'message' => $e->getMessage()];
                $this->logger->error("Cron Dispatch [{$job['name']}] FAILED: " . $e->getMessage());
            }
        }

        return $results;
    }

    /**
     * اجرای مستقیم یک Job از طریق نام (برای استفاده در Queue Worker)
     *
     * 🛡️ FIX-P34: پارامتر $skipIfRecentlyRan فقط برای مسیر ورکر است (RunCronTaskJob)
     * تا کپی‌های تکراریِ باقی‌مانده در صف از نسخه‌های پیشین، پس از یک اجرای موفق،
     * دوباره callback را اجرا نکنند. اجرای دستی ادمین (CronController) همیشه مجاز
     * است (FIX-X147) و پیش‌فرض false رفتار قبلی را حفظ می‌کند.
     */
    public function executeJobByName(string $name, bool $skipIfRecentlyRan = false): mixed
    {
        foreach ($this->jobs as $job) {
            if ($job['name'] === $name) {
                $mutexKey = 'cron_mutex:' . md5(str_value($job['key']));
                $lastRunKey = 'cron_last_run:' . md5(str_value($job['key']));

                // 🛡️ FIX-P34: گیت lastRun فقط در مسیر ورکر — mutex تنها از اجرای
                // «همزمان» جلوگیری می‌کند؛ کپی تکراری پس از آزادشدن قفل، دوباره
                // اجرا می‌شد. اکنون اگر همین بازه قبلاً موفق اجرا شده، skip می‌شود.
                if ($skipIfRecentlyRan) {
                    $lastRun = Cache::getInstance()->get($lastRunKey);
                    if ($lastRun && (time() - int_value($lastRun)) < ($job['interval'] - 5)) {
                        return ['status' => 'skipped', 'reason' => 'already_run_within_interval'];
                    }
                }

                // X129-fix: هم‌راستا با run() — TTL متناسب با بازهٔ جاب، نه کف ۶۰۰ ثانیه
                $lockTtl = min(7200, max(120, (int) $job['interval'] * 2));

                if (!Cache::getInstance()->lock($mutexKey, $lockTtl)) {
                    $this->logger->warning("Cron Worker [{$job['name']}] skipped due to lock.");
                    return ['status' => 'skipped', 'reason' => 'concurrent_mutex'];
                }

                $start = microtime(true);
                // FIX-M6-12: heartbeat قفل در مسیر ورکر (RunCronTaskJob) — با گارد
                // درهم‌تنیدگی؛ در مسیر worker هیچ SIGALRM دیگری جایگزین نمی‌شود.
                $heartbeatActive = $this->startLockHeartbeat($mutexKey, $lockTtl);
                try {
                    $output = ($job['callback'])();
                    $duration = round((microtime(true) - $start) * 1000, 2);

                    // Finding #15 Fix: Record last_run upon successful execution
                    Cache::getInstance()->forever($lastRunKey, time());

                    $loggedOutput = is_array($output) ? $this->redactSensitiveData($output) : ($output ?? []);
                    $this->logger->info("Cron [{$job['name']}] OK in {$duration}ms", is_array($loggedOutput) ? $loggedOutput : []);

                    try {
                        $this->activityLog->log('cron', $job['name'], null, array_merge(
                            is_array($loggedOutput) ? $loggedOutput : [],
                            ['execution_time' => $duration . 'ms']
                        ));
                    } catch (\Throwable $logEx) {}

                    return $output;
                } finally {
                    if ($heartbeatActive) {
                        $this->stopLockHeartbeat();
                    }
                    Cache::getInstance()->unlock($mutexKey);
                }
            }
        }
        
        throw new \RuntimeException("Cron job not found: {$name}");
    }

    // ==========================================
    //  private helpers
    // ==========================================

    /**
     * FIX-M6-12: قلب تپندهٔ قفل mutex جاب — الگوی FIX-R36-W3/F-A11-11 (Outbox)
     * و FIX-R18-M9 (worker). TTL قفل «۲× بازهٔ جاب» است؛ callbackای که از آن
     * عبور کند، اجازه می‌داد تیک/نود دیگر با قفلِ منقضی موازی اجرا شود. اکنون
     * هر max(15, TTL/3) ثانیه قفل با extendLock اتمیک (compare-owner) تمدید
     * می‌شود؛ شکست تمدید = lease باخته → alert بحرانی و توقف re-arm. لغوِ
     * وسطِ callback ممکن نیست، اما unlock پایین‌دست با مالکیت غایب رد می‌شود
     * و هم‌پوشانی به‌صورت بحرانی ثبت می‌گردد. در نبود pcntl رفتار قبلی —
     * opt-out امن (web SAPI معمولاً pcntl ندارد).
     */
    private function startLockHeartbeat(string $mutexKey, int $lockTtl): bool
    {
        if (!function_exists('pcntl_alarm') || !function_exists('pcntl_signal')) {
            return false;
        }

        // 🛡️ گارد درهم‌تنیدگی: در مسیر worker، heartbeat دیداریِ جابِ صف
        // (FIX-R18-M9) همین SIGALRM را در اختیار دارد؛ جایگزینی آن با
        // heartbeat قفلِ cron، lease رزرو صف را بی‌محافظ می‌گذاشت (جابِ صف
        // منقضی → re-pop → churn/اجرای موازی احتمالی). در این حالت heartbeat
        // قفل نصب نمی‌شود (رفتار قبلی) — زنجیرهٔ lease دوگانه تغییر cross-domain
        // است و خارج از دامنهٔ این فیکس. در cron.php و web (بدون handler فعال)
        // heartbeat معمول نصب می‌شود.
        if (function_exists('pcntl_signal_get_handler')) {
            $current = pcntl_signal_get_handler(\SIGALRM);
            $isCustomHandler = is_object($current) || is_array($current)
                || (is_string($current) && str_contains($current, '::'));
            if ($isCustomHandler) {
                return false;
            }
        }

        $interval = max(15, (int)ceil($lockTtl / 3));

        pcntl_async_signals(true);
        pcntl_signal(\SIGALRM, function (int $signo) use ($mutexKey, $lockTtl, $interval): void {
            $renewed = false;
            try {
                $renewed = Cache::getInstance()->extendLock($mutexKey, $lockTtl);
            } catch (\Throwable $e) {
                try {
                    logger()->warning('scheduler.lock_heartbeat_error', ['error' => $e->getMessage()]);
                } catch (\Throwable $ignored) {}
            }

            if ($renewed === false) {
                try {
                    logger()->critical('scheduler.lock_lease_lost', [
                        'mutex' => $mutexKey,
                        'message' => 'Cron lock lease lost mid-callback; concurrent run by another holder is possible until callback finishes.',
                    ]);
                } catch (\Throwable $ignored) {}
                return; // بدون re-arm
            }

            pcntl_alarm($interval);
        });
        pcntl_alarm($interval);

        return true;
    }

    /** FIX-M6-12: لغو alarm و بازگرداندن handler پیش‌فرض پس از پایان callback. */
    private function stopLockHeartbeat(): void
    {
        if (function_exists('pcntl_alarm')) {
            pcntl_alarm(0);
        }
        if (function_exists('pcntl_signal')) {
            pcntl_signal(\SIGALRM, \SIG_DFL);
        }
    }

    private function addJob(string $key, callable $callback, string $name, int $intervalSeconds, ?string $schedule = null): self
    {
        // X129-fix: کلید پیش‌فرض فقط «بازهٔ زمانی» بود → همهٔ جاب‌های هم‌بازه (مثلاً
        // ۷ جابِ everyMinute) یک کلید last-run/mutex مشترک داشتند؛ نتیجه: یک جابِ
        // متوقف، همهٔ هم‌بازه‌ها را برای مدت TTL میخواباند و «آخرین اجرا»ی هر جاب
        // بی‌معنا می‌شد. اکنون کلید برای هر جاب یکتاست (بازه + نام جاب).
        $uniqueKey = $name !== '' ? $key . ':' . $name : $key;
        $job = [
            'key'      => $uniqueKey,
            'name'     => $name ?: $key,
            'callback' => $callback,
            'interval' => $intervalSeconds,
            // 🛡️ FIX-X147: متادیتای زمان‌بندی صریح (hourly:/daily:/weekly:/monthly:)
            // برای گیتِ dispatch خودکار؛ null = فقط گیتِ last-run/بازه.
            'schedule' => $schedule,
        ];

        // FIX-P3-CMD-097 (یافتهٔ ۰۹۷): ثبت idempotent — قبلاً $this->jobs[] همیشه
        // append می‌شد و رانِ مجدد Kernel::schedule() روی همان instance Scheduler
        // (مسیر CronController؛ ادعای «registration is idempotent» در کامنت آن)
        // ردیف‌های تکراری می‌ساخت. اکنون جابی که کلید یکتایش موجود است «جایگزین»
        // می‌شود (آخرین تعریف برنده است) تا رجیستریِ پنل ادمین و حلقه‌های
        // run()/dispatchAllAsync()/executeJobByName() بدون نویزِ تکراری بمانند.
        foreach ($this->jobs as $index => $existing) {
            if ($existing['key'] === $uniqueKey) {
                $this->jobs[$index] = $job;
                return $this;
            }
        }

        $this->jobs[] = $job;
        return $this;
    }

    /**
     * X129-fix: فهرست جاب‌های ثبت‌شده بدون callback — برای نمایش واقعی در پنل ادمین
     * (نام، کلید یکتا، بازه) تا ویو هرگز با لیست هاردکد کدریفت نکند.
     *
     * @return list<array{key: string, name: string, interval: int}>
     */
    public function registeredJobs(): array
    {
        $out = [];
        foreach ($this->jobs as $job) {
            $out[] = [
                'key'      => str_value($job['key']),
                'name'     => str_value($job['name']),
                'interval' => (int) $job['interval'],
            ];
        }
        return $out;
    }

    /**
     * FIX-R36-W3 (F-A9b-14): ماسک مسیر مطلق سرور با {ROOT} — هم‌الگوی
     * ExceptionHandler (maskPath)؛ چون نتایج run() به activity_log/پنل ادمین
     * می‌رود، افشای مسیر مطلق به مصرف‌کنندهٔ مجاز هم لازم نیست (information hygiene).
     */
    private function maskFilePath(string $path): string
    {
        if ($path === '') {
            return $path;
        }
        $baseDir = realpath(__DIR__ . '/../');
        $baseDir = is_string($baseDir) ? $baseDir : '';
        if ($baseDir !== '' && str_starts_with($path, $baseDir)) {
            return '{ROOT}' . substr($path, strlen($baseDir));
        }
        return $path;
    }

    /**
     * CORE-056: Recursively sanitizes and redacts potentially sensitive keys inside telemetry payloads
     */
    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function redactSensitiveData(array $data): array
    {
        static $sensitiveKeywords = ['pass', 'pwd', 'token', 'secret', 'key', 'auth', 'card', 'phone', 'email', 'wallet', 'hash'];
        
        foreach ((array)$data as $key => $value) {
            if (is_array($value)) {
                $data[$key] = $this->redactSensitiveData($value);
                continue;
            }

            $lowerKey = strtolower((string)$key);
            foreach ($sensitiveKeywords as $word) {
                if (str_contains($lowerKey, $word)) {
                    $data[$key] = '[REDACTED]';
                    break;
                }
            }
        }

        return $data;
    }
}
