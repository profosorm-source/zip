<?php

declare(strict_types=1);

namespace Core;

/**
 * EnvValidator — اعتبارسنجی تجمیعی متغیرهای محیطی در بوت (FIX-C105، یافتهٔ ۱۰۵)
 *
 * قبلاً فقط سه متغیر (APP_KEY / APP_URL / SECURITY_API_TOKEN_SECRET) در
 * bootstrap/app.php بررسی می‌شدند؛ DB_* و REDIS_* و APP_ENV و QUEUE_DRIVER
 * به‌صورت خام خوانده می‌شدند و مقدار غلط فقط به‌صورت خطای runtime میانهٔ
 * درخواست ظاهر می‌شد (یا بدتر: با پیش‌فرض اشتباه بی‌صدا ادامه می‌یافت).
 *
 * اکنون در بوت، همهٔ متغیرهای حیاتی یک‌جا اعتبارسنجی می‌شوند و همهٔ تخلف‌ها در
 * یک پیام تجمیعی گزارش می‌شوند (fail-fast با فهرست کامل، نه شکست逐ی).
 *
 * محدودهٔ مسئولیت: فقط «حضور + فرمت». منطق سرویس‌ها (مثل انتخاب درایور)
 * دست‌نخورده است.
 */
final class EnvValidator
{
    /** @var list<string> */
    private array $violations = [];

    /** @var list<string> */
    private array $warnings = [];

    /**
     * @param array<string, mixed> $env محیط parse‌شدهٔ .env (اولویت) + process env
     */
    public static function validate(array $env): void
    {
        $v = new self();
        $get = static function (string $key) use ($env): ?string {
            // FIX-M3-04: process environment wins over the .env file (same contract
            // as env() in helpers/functions.php) — orchestrator-injected values are
            // the source of truth in containers.
            $raw = getenv($key);
            if ($raw === false || $raw === null || trim((string)$raw) === '') {
                $raw = $_ENV[$key] ?? ($env[$key] ?? null);
            }
            if ($raw === false || $raw === null) {
                return null;
            }
            $raw = trim((string)$raw);
            return $raw === '' ? null : $raw;
        };

        // ── APP_ENV ─────────────────────────────────────────────
        $appEnv = $get('APP_ENV') ?? 'local';
        $allowedEnvs = ['production', 'staging', 'local', 'development', 'testing'];
        if (!in_array($appEnv, $allowedEnvs, true)) {
            $v->add("APP_ENV='{$appEnv}' نامعتبر است؛ مقادیر مجاز: " . implode('|', $allowedEnvs));
        }

        // ── QUEUE_DRIVER ────────────────────────────────────────
        $queueDriver = $get('QUEUE_DRIVER') ?? $get('QUEUE_CONNECTION');
        if ($queueDriver !== null && !in_array($queueDriver, ['database', 'redis', 'sync'], true)) {
            $v->add("QUEUE_DRIVER='{$queueDriver}' نامعتبر است؛ مقادیر مجاز: database|redis|sync");
        }

        // ── مسیر production ─────────────────────────────────────
        if ($appEnv === 'production') {
            foreach (['DB_HOST', 'DB_NAME', 'DB_USER'] as $required) {
                if ($get($required) === null) {
                    $v->add("{$required} در production الزامی است (خالی/ناموجود)");
                }
            }
            // FIX-CFG004 (یافتهٔ ۰۰۴): اتصال DB با root/بدون رمز در production ممنوع —
            // قبلاً DB_USER=root با DB_PASS خالی پذیرفته می‌شد (سورس zip واقعی).
            $dbUser = $get('DB_USER');
            if ($dbUser !== null && strtolower($dbUser) === 'root') {
                $v->add("DB_USER='root' در production ممنوع است — کاربر اختصاصی با حداقل دسترسی بسازید");
            }
            $dbPort = $get('DB_PORT') ?? '3306';
            if (filter_var($dbPort, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]) === false) {
                $v->add("DB_PORT='{$dbPort}' خارج از بازهٔ ۱..65535");
            }
            // رمز DB خالی در production تنها با علامت‌گذاری صریح مجاز است
            if ($get('DB_PASS') === null) {
                $v->add('DB_PASS در production الزامی است (برای DB بدون رمز، مقدار صریح بدهید و ریسک را بپذیرید)');
            }

            // FIX-CFG004: Redis بدون رمز — فقط وقتی روی loopback نیست خطا است؛
            // روی 127.0.0.1/localhost هشدار (اتصال محلی + bind محدود کفایت نسبی دارد).
            if (filter_var($get('REDIS_ENABLED') ?? 'true', FILTER_VALIDATE_BOOLEAN) && $get('REDIS_HOST') === null) {
                $v->add('REDIS_ENABLED=true ولی REDIS_HOST خالی/ناموجود');
            }
            if (filter_var($get('REDIS_ENABLED') ?? 'true', FILTER_VALIDATE_BOOLEAN) && $get('REDIS_PASSWORD') === null) {
                $redisHost = strtolower($get('REDIS_HOST') ?? '127.0.0.1');
                if (in_array($redisHost, ['127.0.0.1', 'localhost', '::1'], true)) {
                    $v->warn('REDIS_PASSWORD خالی است — برای production مقدارگذاری کنید (فعلاً loopback: قابل‌تحمل)');
                } else {
                    $v->add('REDIS_PASSWORD در production برای REDIS_HOST غیر-loopback الزامی است');
                }
            }

            // FIX-CFG003 (یافتهٔ ۰۰۳): debug در production نباید روشن باشد — جزئیات
            // استثنا/مسیرها را به پاسخ‌ها لو می‌دهد.
            if (filter_var($get('APP_DEBUG') ?? 'false', FILTER_VALIDATE_BOOLEAN)) {
                $v->add('APP_DEBUG=true در production ممنوع است (افشای جزئیات داخلی)');
            }

            // FIX-CFG005 (یافتهٔ ۰۰۵): توکن وبهوک placeholder عمومی به‌جای secret واقعی
            // پذیرفته نمی‌شود — HMAC با کلید عمومی‌شده = بی‌اعتبار.
            $webhookSecret = $get('WEBHOOK_SECRET');
            if ($webhookSecret === null) {
                $v->add('WEBHOOK_SECRET در production الزامی است');
            } elseif ($webhookSecret === 'YOUR_64_CHAR_HEX_SECRET_HERE' || strlen($webhookSecret) < 32) {
                $v->add('WEBHOOK_SECRET در production مقدار placeholder/کوتاه دارد — secret واقعی ۶۴+ کاراکتر بگذارید');
            }

            // FIX-CFG006 (یافتهٔ ۰۰۶): ردیابی ۱۰۰٪ کوئری‌ها در production هشدار —
            // فشار I/O و رشد لاگ؛ پیشنهاد: نمونه‌گیری ۰.۱.
            $sampleRate = $get('DB_TRACK_QUERIES_SAMPLE_RATE');
            if ($sampleRate !== null && is_numeric($sampleRate) && (float)$sampleRate >= 1.0
                && filter_var($get('DB_TRACK_QUERIES') ?? 'false', FILTER_VALIDATE_BOOLEAN)) {
                $v->warn('DB_TRACK_QUERIES_SAMPLE_RATE=1.0 در production — ۰.۱ توصیه می‌شود (فشار I/O)');
            }

            // FIX-M4-02: production با «فقط secret نسخه‌دار» (V1/V2 + CURRENT_VERSION)
            // هم بوت‌پذیر است — secret بدون‌پسوند legacy فقط fallback است.
            // کافی است یکی از (V{current}، بدون‌پسوند، V1، V2) ≥۳۲ کاراکتر باشد.
            $m4TokenCandidates = [
                'SECURITY_API_TOKEN_SECRET',
                'SECURITY_API_TOKEN_SECRET_V1',
                'SECURITY_API_TOKEN_SECRET_V2',
            ];
            $currentRaw = $get('SECURITY_API_TOKEN_CURRENT_VERSION');
            // 🛡️ FIX-SECRETROT-2: نرمال‌سازی از منبع کانونی (helpers/functions.php) —
            // هم‌قرارداد با bootstrap و config؛ خروجی همیشه v1/v2 (بدون نگاشت دستی اینجا).
            if (is_string($currentRaw) && trim($currentRaw) !== '') {
                $current = normalize_secret_version($currentRaw);
                array_unshift($m4TokenCandidates, 'SECURITY_API_TOKEN_SECRET_V' . ltrim($current, 'v'));
            }
            $hasHealthyTokenSecret = false;
            foreach ($m4TokenCandidates as $candidateKey) {
                $candidate = $get($candidateKey);
                if ($candidate !== null && strlen($candidate) >= 32) {
                    $hasHealthyTokenSecret = true;
                    break;
                }
            }
            if (!$hasHealthyTokenSecret) {
                $v->add('SECURITY_API_TOKEN_SECRET (یا نسخهٔ‌دار V1/V2) در production الزامی و حداقل ۳۲ کاراکتر است');
            }

            // FIX-M4-15: APP_URL در production باید https و غیر-loopback باشد —
            // قبلاً فقط FILTER_VALIDATE_URL (در bootstrap) و ردِ دقیق
            // http://localhost (در config/oauth.php) وجود داشت؛ http://عمومی و
            // loopbackهای دیگر از گارد عبور می‌کردند و callback/redirect با TLS
            // قرارداد نداشت. اینجا نقطهٔ واحد پیش از بارگذاری config است.
            $appUrl = $get('APP_URL');
            if ($appUrl === null) {
                $v->add('APP_URL در production الزامی است');
            } else {
                $parts = parse_url($appUrl);
                $scheme = isset($parts['scheme']) ? strtolower((string)$parts['scheme']) : '';
                $host = isset($parts['host']) ? strtolower((string)$parts['host']) : '';
                $isLoopback = in_array($host, ['localhost', '127.0.0.1', '::1'], true)
                    || str_ends_with($host, '.localhost');
                if (!filter_var($appUrl, FILTER_VALIDATE_URL)) {
                    $v->add("APP_URL='{$appUrl}' یک URL معتبر نیست");
                } elseif ($scheme !== 'https') {
                    $v->add("APP_URL در production باید scheme https داشته باشد (فعلاً '{$scheme}' است)");
                } elseif ($isLoopback) {
                    $v->add("APP_URL در production نمی‌تواند host loopback داشته باشد ('{$host}')");
                }
            }
        }

        // FIX-CFG003: کلیدهای مرده (ghost) — اگر در .env باقی مانده‌اند هشدار تا پاک شوند
        // (این کلیدها هیچ مصرف‌کننده‌ای در config ندارند و نگه‌داشتن‌شان گمراه‌کننده است).
        foreach (['SESSION_SECURE', 'SESSION_HTTPONLY', 'CURRENCY_MODE'] as $ghost) {
            if (isset($env[$ghost])) {
                $v->warn("کلید مردهٔ {$ghost} در .env — حذف کنید (هیچ مصرف‌کننده‌ای ندارد)");
            }
        }

        // ── پورت‌ها (همیشه) ─────────────────────────────────────
        foreach (['REDIS_PORT' => $get('REDIS_PORT'), 'DB_PORT' => $get('DB_PORT')] as $key => $port) {
            if ($port !== null && filter_var($port, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]) === false) {
                $v->add("{$key}='{$port}' خارج از بازهٔ ۱..65535");
            }
        }

        // ── مسیر testing/CI (بدون .env) مجاز به رد شدن است ──────
        // هشدارها فatal نیستند — فقط در لاگ می‌روند (تجربهٔ عملیاتی حفظ می‌شود).
        foreach ($v->warnings as $warning) {
            error_log('[Chortke] env warning: ' . $warning);
        }
        if (!$v->hasViolations()) {
            return;
        }

        $report = "Environment validation failed (" . count($v->violations) . "):\n - "
            . implode("\n - ", $v->violations);
        // در web پاسخ ۵۰۰ عمومی؛ در CLI پیام کامل به STDERR + exit
        if (PHP_SAPI === 'cli' || defined('STDIN')) {
            fwrite(STDERR, '[Chortke] ' . $report . "\n");
            exit(1);
        }
        error_log('[Chortke] ' . str_replace("\n", ' | ', $report));
        http_response_code(500);
        die('<h1>خطای پیکربندی سرور</h1>');
    }

    private function add(string $message): void
    {
        $this->violations[] = $message;
    }

    private function warn(string $message): void
    {
        $this->warnings[] = $message;
    }

    private function hasViolations(): bool
    {
        return $this->violations !== [];
    }
}
