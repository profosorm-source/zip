<?php

declare(strict_types=1);

namespace Core;

/**
 * Model — پایه تمام Model‌های پروژه
 *
 * ─── جریان صحیح ────────────────────────────────────────────────
 *
 *   Container::make(UserModel)
 *       └─→ Model::__construct()
 *               └─→ Container::make(Database::class)  ← singleton
 *
 * ─── قرارداد ───────────────────────────────────────────────────
 *   همه متدها از $this->db استفاده می‌کنند.
 *   db() متد هم همان $this->db را برمی‌گرداند (نه app()->db).
 *   هیچ‌جا مستقیم Database::getInstance() صدا زده نمی‌شود.
 *
 * ─── تذکر ──────────────────────────────────────────────────────
 *   Model نباید Business Logic داشته باشد.
 *   Logic باید در Service باشد، Model فقط Data Access.
 */
/**
 * @phpstan-type AttributeMap array<string, mixed>
 * @phpstan-type RelationDefinition array{0: class-string, 1: string, 2?: string}
 * @phpstan-type BelongsToRelationDefinition array{0: 'belongsTo', 1: class-string, 2: string, 3?: string}
 */
abstract class Model
{
    /** @var list<string> */
    protected static array $searchable = [];
    protected static string $table = '';

    /**
     * فیلدهایی که مجاز به insert هستند.
     *
     * ── Mass Assignment Protection ────────────────────────────────────────────
     * اگر یک Model این آرایه را پر کند، متد create() فقط همین فیلدها
     * را به DB می‌فرستد و بقیه $data را نادیده می‌گیرد.
     *
     * 🛡️ FIX-S9-03 (گزارش بخش ۹ — drift مستندات): اگر خالی باشد (پیش‌فرض)
     * «هیچ‌چیز» پاس نمی‌شود — filterFillable در قرارداد deny-by-default
     * آرایهٔ خالی برمی‌گرداند و QueryBuilder::insert([]) استثنا می‌پراند.
     * مدل‌هایی که از create()/update() عمومی استفاده می‌کنند باید $fillable
     * را صریح تعریف کنند یا متدِ درجِ اختصاصی (مانند Role::createRole)
     * داشته باشند. متنِ قبلی («همه فیلدها پاس می‌شوند») با کد تناقض داشت.
     *
     * ── همچنین برای update() ─────────────────────────────────────────────────
     * update() هم $fillable را enforce می‌کند تا جلوگیری شود از اینکه
     * فیلدهای حساس (مثل role, is_admin) از طریق updateUser() تغییر کنند.
     * فیلدهای سیستمی (updated_at) که خود Model اضافه می‌کند مشمول نمی‌شوند.
     * ─────────────────────────────────────────────────────────────────────────
     *
     * مثال در Model فرزند:
     *   protected array $fillable = ['title', 'body', 'user_id'];
     */
    /** @var list<string> */
    protected array $fillable = [];

    /** @var list<string> */
    protected array $hidden = [];

    protected static bool $unguarded = false;

    /**
     * FIX-18O (P1): hidden-field serializer.
     *
     * Returns a public-safe copy of a DB row (array or stdClass) with every
     * key listed in the model's $hidden stripped, recursively for nested
     * rows/objects/arrays (e.g. eager-loaded relations).
     *
     * ⚠️ RAW FETCHES ARE NOT AFFECTED: find(), all(), findBy*() and SELECT *
     * keep ALL columns, because internal flows legitimately need them (auth
     * needs the password hash, token verification needs the token hashes). $hidden only
     * applies when a consumer EXPLICITLY asks for the safe shape via this
     * method before handing a row to a view / json_encode / API response.
     *
     * The input type is mirrored: array in → array out, stdClass in →
     * stdClass out.
     *
     * NOTE (FIX-R18-O): the parameter is deliberately UNTYPED (docblock-only).
     * A `object|array` union signature here breaks PHPUnit 8.5 mock generation
     * for EVERY model (mock generator reflects inherited public methods and
     * calls ReflectionUnionType::getName(), which does not exist).
     *
     * @param array<string, mixed>|object $row
     * @return array<string, mixed>|object
     */
    public function toPublicArray($row)
    {
        $result = $this->stripHiddenFields($row);
        if (!is_array($result) && !is_object($result)) {
            throw new \UnexpectedValueException('Public model serialization returned an invalid value.');
        }
        return $result;
    }

    private function stripHiddenFields(mixed $value): mixed
    {
        if (is_array($value)) {
            $out = [];
            foreach ($value as $key => $val) {
                if (is_string($key) && in_array($key, $this->hidden, true)) {
                    continue;
                }
                $out[$key] = $this->stripHiddenFields($val);
            }
            return $out;
        }

        if ($value instanceof \stdClass) {
            $out = new \stdClass();
            foreach (get_object_vars($value) as $key => $val) {
                if (is_string($key) && in_array($key, $this->hidden, true)) {
                    continue;
                }
                $out->{$key} = $this->stripHiddenFields($val);
            }
            return $out;
        }

        return $value;
    }

    protected function fetchObject(\PDOStatement $statement): ?\stdClass
    {
        $row = $statement->fetch(\PDO::FETCH_OBJ);
        return $row instanceof \stdClass ? $row : null;
    }

    /** @return array<string, mixed> */
    protected function fetchAssoc(\PDOStatement $statement): array
    {
        $row = $statement->fetch(\PDO::FETCH_ASSOC);
        return is_array($row) ? $row : [];
    }

    /** @return list<array<string, mixed>> */
    protected function fetchAssocList(\PDOStatement $statement): array
    {
        $rows = $statement->fetchAll(\PDO::FETCH_ASSOC);
        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_filter($rows, 'is_array'));
    }

    /** @return list<\stdClass> */
    protected function fetchObjectList(\PDOStatement $statement): array
    {
        $rows = $statement->fetchAll(\PDO::FETCH_OBJ);
        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_filter(
            $rows,
            static fn(mixed $row): bool => $row instanceof \stdClass
        ));
    }

    public static function unguard(bool $state = true): void
    {
        static::$unguarded = $state;
    }

    public static function reguard(): void
    {
        static::$unguarded = false;
    }

    /**
     * FIX-M1M25 (گزارش ماژول ۱، M25): unguard محدود به دامنه — flag استاتیک
     * سراسری دیگر از طریق این API عمومی بدون رست تضمینی باقی نمی‌ماند؛
     * callback در finally همیشه reguard می‌شود. برای عملیات سیستمی محدود استفاده کنید.
     *
     * @template T
     * @param callable(): T $callback
     * @return T
     */
    public static function unguarded(callable $callback): mixed
    {
        $previous = static::$unguarded;
        static::$unguarded = true;
        try {
            return $callback();
        } finally {
            static::$unguarded = $previous;
        }
    }

    /**
     * Filter data array by $fillable fields unless model is unguarded
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    protected function filterFillable(array $data): array
    {
        if (static::$unguarded) {
            return $data;
        }

        if (!empty($this->fillable)) {
            return array_intersect_key($data, array_flip($this->fillable));
        }

        // Deny by default. A model must explicitly opt in to writable columns.
        // Privileged/system writes should use dedicated methods or unguarded()
        // around a narrowly scoped operation.
        return [];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🛡️ W4-F (F-A2-08): Runtime Column Guard — گارد سیستمی ستون‌ها
    //
    // یافتهٔ ممیزی A2: نوشتارهای ستون-لیستِ داینامیک (array_keys($data) →
    // INSERT/UPDATE) فقط به نظمِ فراخوان تکیه داشتند و هیچ اعتبارسنجیِ
    // runtime نداشتند؛ drift نااَشکار (fillable/پیلود ↔ جدول زنده) تا لحظهٔ
    // 42S22 در تولید بی‌صدا می‌ماند (همان کلاسِ F-A2-01/03/05/06).
    //
    // ─── قرارداد گارد ────────────────────────────────────────────────────────
    //   ● STRICT به‌صورت پیش‌فرض: قبل از ساخته‌شدن لیست ستونِ INSERT/UPDATE،
    //     هر کلید $data نسبت به ستون‌های زندهٔ جدول (INFORMATION_SCHEMA.COLUMNS،
    //     دو لایه کش — Database::getTableColumns) اعتبارسنجی می‌شود.
    //   ● ستون ناشناخته → \InvalidArgumentException با پیام دقیق (جدول، ستون
    //     متخلف، کلاس مدل، عملیات) — FAIL FAST، قبل از رسیدن به DB.
    //     ستون‌ها هرگز silent-drop نمی‌شوند (drop بی‌صدا = گناه اصلیِ یافته).
    //   ● محافظت از کشِ کهنه: پیش از پرتاب استثنا، یک introspection تازه
    //     (Database::getFreshTableColumns) اجرا می‌شود؛ ستونی که مایگریشنِ
    //     زنده تازه اضافه کرده false-positive نمی‌دهد و کش‌ها refresh می‌شوند.
    //   ● fail-open فقط وقتی اسکیما اصلاً قابل‌مشاهده نیست (null/[] گذرا):
    //     در آن حالت خودِ INSERT/UPDATE نامعتبر همچنان در سرور fail-loud
    //     می‌شود (42S22) — گارد «درِ قطع دسترسی» نیست، گاردِ drift است.
    //   ● اسکوپ: فقط مسیرهای ORMِ این کلاس پایه (create/update + firstOrCreate/
    //     updateOrCreate که به همان‌ها funnel می‌شوند). مایگریشن‌ها و SQL خام
    //     (شامل بازنویسی‌های create/update در فرزندان) از این کلاس عبور
    //     نمی‌کنند و خارج از اسکوپ گارد هستند.
    //
    // ─── Escape hatch (opt-out) ──────────────────────────────────────────────
    //   protected bool $strictColumns = true;  ← در مدل فرزند false کنید یا
    //   $model->setStrictColumns(false) برای موارد نادرِ داینامیکِ مشروع.
    //   پیش‌فرض: STRICT.
    // ─────────────────────────────────────────────────────────────────────────

    /** گارد ستون فعال است؟ پیش‌فرض STRICT — برای استثناهای مستند false کنید */
    protected bool $strictColumns = true;

    public function setStrictColumns(bool $strict): void
    {
        $this->strictColumns = $strict;
    }

    public function isStrictColumns(): bool
    {
        return $this->strictColumns;
    }

    /**
     * اعتبارسنجی runtime کلیدهای $data نسبت به ستون‌های زندهٔ جدول.
     *
     * یک کوئری INFORMATION_SCHEMA به‌ازای هر (db,table) در هر پنجرهٔ TTL
     * (نه به‌ازای هر write) — کش استاتیک per-process + کش مشترک با TTL 600s.
     * عملیات چند-ردیفی (batch) در این کلاس پایه وجود ندارد؛ هر ردیف از
     * create()/update() عبور می‌کند و کش استاتیک هزینهٔ ردیف دوم به بعد را
     * به یک array-lookup کاهش می‌دهد.
     *
     * @param array<string, mixed> $data مجموعه‌ای که واقعاً نوشته خواهد شد
     *        (بعد از filterFillable و مهرِ updated_at)
     * @param string $operation 'INSERT'|'UPDATE' — فقط برای پیام خطا
     * @throws \InvalidArgumentException ستون ناشناخته (پیام: جدول، ستون، مدل، عملیات)
     */
    protected function guardColumns(array $data, string $operation): void
    {
        if (!$this->strictColumns || $data === []) {
            return; // escape hatch / nothing to validate
        }

        // Database::resolveTableColumns شکستِ گذرایی را خودش null می‌کند؛ این
        // catch دوم برای هر شکست نادرِ دیگر (مثل تست‌دابل‌های سخت‌گیر) است —
        // گارد هرگز خودش منبعِ شکستِ write مشروع نشود (fail-open همان قراردادِ null).
        try {
            $known = $this->db->getTableColumns(static::$table);
        } catch (\Throwable $ignore) {
            $known = null;
        }
        if ($known === null || $known === []) {
            // اسکیما اکنون قابل‌مشاهده نیست (شکست گذرایی introspection یا
            // جدول غایب) — fail-open؛ خودِ write نامعتبر در سرور fail-loud می‌شود.
            return;
        }

        $unknown = array_values(array_diff(array_map('strval', array_keys($data)), $known));
        if ($unknown === []) {
            return;
        }

        // محافظت از کشِ کهنه (worker طولانی‌عمر پس از مایگریشن زنده):
        // یک introspection تازه؛ اگر ستون واقعاً اضافه شده، کش refresh و
        // write مشروع عبور می‌کند.
        try {
            $fresh = $this->db->getFreshTableColumns(static::$table);
        } catch (\Throwable $ignore) {
            $fresh = null;
        }
        if (is_array($fresh) && $fresh !== []) {
            $unknown = array_values(array_diff($unknown, $fresh));
            if ($unknown === []) {
                return;
            }
        }

        $quoted = array_map(static fn(string $c): string => '`' . $c . '`', $unknown);

        if (function_exists('logger')) {
            try {
                logger()->warning('model.column_guard.violation', [
                    'model' => static::class,
                    'table' => static::$table,
                    'operation' => $operation,
                    'unknown_columns' => $unknown,
                ]);
            } catch (\Throwable $ignore) {}
        }

        throw new \InvalidArgumentException(sprintf(
            '[ColumnGuard] %s on table `%s` (model %s) references unknown column(s): %s. ' .
            'Strict mode (W4-F/F-A2-08): pass only live columns or opt out via setStrictColumns(false).',
            $operation,
            static::$table,
            static::class,
            implode(', ', $quoted)
        ));
    }

    /**
     * 🛡️ Phase 3 (Eager Loading Mini-System): تعریف روابط در Model فرزند
     *
     * قالب هر رابطه:
     *   'relationName' => [RelatedModelClass::class, 'foreign_key_in_related_table', 'mode']
     *
     * mode ها:
     *   'one'  → یک رکورد مرتبط (مثل wallet هر کاربر)
     *   'many' → چند رکورد مرتبط (مثل tasks هر کاربر) — default
     *
     * مثال در User.php:
     *   protected array $relations = [
     *       'wallet'    => [WalletModel::class,    'user_id', 'one'],
     *       'tasks'     => [TaskModel::class,      'user_id', 'many'],
     *       'kycRecord' => [KycModel::class,       'user_id', 'one'],
     *   ];
     *
     * نکته: opt-in است — اگر خالی باشد، Model فعلی بدون تغییر کار می‌کند.
     *
     * FIX-18O (P1): belongsTo — روابطی که کلید خارجی‌شان روی جدولِ «والد»
     * (همین Model) است. دو قالب پشتیبانی می‌شود:
     *
     *   1) ['belongsTo', RelatedModel::class, 'foreignKeyOnThisTable']
     *      → SELECT * FROM related WHERE related.id IN (parent.fk values)
     *        attach بر اساس parent.fk → related.id
     *
     *   2) ['belongsTo', RelatedModel::class, 'fkOnThisTable', 'fkOnRelatedTable']
     *      → SELECT * FROM related WHERE related.fkOnRelated IN (parent.fk values)
     *        attach بر اساس parent.fk → related.fkOnRelated
     *        (مثلاً Transaction->wallet: transactions.user_id → wallets.user_id)
     *
     * قالب قدیمی [RelatedModel::class, 'fk', 'one'|'many'] دست‌نخورده باقی
     * می‌ماند و دقیقاً همان معنای قبلی (hasMany / hasOne با fk روی جدول
     * مرتبط) را دارد.
     *
     * @var array<string, RelationDefinition|BelongsToRelationDefinition>
     */
    protected array $relations = [];

    protected Database $db;

    public function __construct(Database $db) {
        if (empty(static::$table)) {
            throw new \RuntimeException("Model " . static::class . " must define \$table");
        }
        $this->db = $db;
    }

    // ─────────────────────────────────────────────────────────────
    // Internal Helper — یک‌منبعه
    // ─────────────────────────────────────────────────────────────

    /**
     * برای backward compatibility — همان $this->db
     */
    protected function db(): Database
    {
        return $this->db;
    }

    /**
     * دریافت شیء دیتابیس
     */
    public function getDb(): Database
    {
        return $this->db;
    }

    public function getTable(): string
    {
        return static::$table;
    }

    // ─────────────────────────────────────────────────────────────
    // CRUD پایه
    // ─────────────────────────────────────────────────────────────

    /**
     * درج یک رکورد جدید.
     *
     * اگر $fillable پر باشد، فقط فیلدهای مجاز به DB می‌روند (Mass Assignment Protection).
     * 🛡️ FIX-S9-03 (گزارش بخش ۹): اگر $fillable خالی باشد، هیچ $data پاس نمی‌شود
     * (deny-by-default — نه «همه پاس می‌شوند») و insertِ خالی استثنا می‌پراند.
     *
     * @param array<string, mixed> $data
     * @return int|true|false int = ID رکورد (جدول auto-increment)؛ true = موفق بدون ID
     *                        (جدول بدون auto-increment — FIX-R36-W3/F-A9a-14: دیگر به (int)1 قالب نمی‌شود)؛ false = شکست
     * @throws \InvalidArgumentException W4-F (F-A2-08): کلید ناشناخته نسبت به ستون‌های زندهٔ جدول
     *                        (Runtime Column Guard — fail-fast، پیش از رسیدن به DB)
     */
    public function create(array $data): mixed
    {
        $data = $this->filterFillable($data);

        // W4-F (F-A2-08): گارد ستون روی «مجموعه‌ای که واقعاً نوشته می‌شود» —
        // بعد از filterFillable (mass-assignment اول، schema-guard دوم).
        $this->guardColumns($data, 'INSERT');

        $result = $this->db->table(static::$table)->insert($data);
        // FIX-R36-W3 (F-A9a-14): insert سه شکل بازگشت دارد — int (ID جدول AI)،
        // true (جدول بدون auto-increment)، false (شکست). قالب قبلی true را
        // (int)1 می‌فهمید و «ID معتبر ۱» جعل می‌کرد (فراخوانی find(1) روی رکورد
        // نامربوط). true اکنون عیناً true می‌ماند — فراخواننده نمی‌تواند آن را
        // با ID اشتباه بگیرد (احکام truthy مثل `> 0` یا `if($id)` تغییری نمی‌کنند).
        if ($result === false) {
            return false;
        }
        if ($result === true) {
            return true;
        }
        return (int)$result;
    }

    /** @return ?\stdClass */
    public function find(int $id): ?object
    {
        $result = $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->first();

        if ($result === null) {
            return null;
        }
        // ROOT FIX (principled): Always normalize DB row to object.
        // This is the single source of truth for "array vs object" problem.
        // All find* and first/get callers in Services/Controllers will benefit.
        return $this->normalizeToObject($result);
    }

    /**
     * ROOT CAUSE FIX (centralized, principled)
     * Single place to guarantee object (never array) from any DB result.
     * Used by find(), custom findBy*, and can be used by Services.
     */
    /**
     * Normalize only documented database row representations.
     *
     * Database/QueryBuilder return stdClass. A small number of legacy model
     * queries still use PDO::FETCH_ASSOC, so arrays are converted here at the
     * one model boundary. Scalar values and arbitrary objects are not database
     * rows and must fail closed rather than being disguised as an object.
     *
     * @return ?\stdClass
     */
    protected function normalizeToObject(mixed $row): ?\stdClass
    {
        if ($row instanceof \stdClass) {
            return $row;
        }
        if (is_array($row)) {
            return (object)$row;
        }
        return null;
    }

    /**
     * @param AttributeMap $filters
     * @return list<\stdClass>
     */
    public function all(array $filters = [], int $limit = 100, int $offset = 0): array
    {
        // BUGFIX-PHASE2-P2W: پارامتر $filters قبلاً کاملاً نادیده گرفته می‌شد و
        // شرط‌های پاس‌شده هرگز به query اعمال نمی‌شدند. اکنون به‌عنوان فیلترهای
        // تساوی (key => value) اعمال می‌شود. با فراخوان‌های فعلی سازگار است چون
        // همه [] یا بدون آرگومان صدا می‌زنند (تأییدشده با rg).
        $query = $this->db->table(static::$table);
        foreach ($filters as $column => $value) {
            $query->where((string)$column, '=', $value);
        }

        return $query
            ->limit((int)$limit)
            ->offset((int)$offset)
            ->get();
    }

    /**
     * 🛡️ Phase 3: دریافت لیست به همراه eager loaded relations
     *
     * این متد N+1 query problem را حل می‌کند. به جای N+1 query:
     *   $users = $this->userModel->all(100);
     *   foreach ($users as $user) {
     *       $user->wallet = $this->walletModel->findByUserId($user->id);  // N queries!
     *   }
     *
     * از این استفاده کنید:
     *   $users = $this->userModel->allWith(['wallet', 'tasks'], 100);
     *   // فقط ۳ query: ۱ برای users، ۱ برای wallets، ۱ برای tasks
     *
     * @param list<string> $relations لیست نام روابط (از $relations همین Model)
     * @param int $limit
     * @param int $offset
     * @return list<\stdClass> لیست objects با relations به صورت property
     */
    public function allWith(array $relations, int $limit = 100, int $offset = 0): array
    {
        $items = $this->all([], $limit, $offset);
        return $this->loadRelations($items, $relations);
    }

    /**
     * 🛡️ Phase 3: دریافت یک رکورد به همراه eager loaded relations
     *
     * اگر رکورد پیدا نشد، null برمی‌گردد (بدون eager load اضافی).
     *
     * @param int $id
     * @param list<string> $relations
     * @return object|null
     */
    public function findWith(int $id, array $relations): ?object
    {
        $item = $this->find($id);
        if ($item === null) {
            return null;
        }
        $loaded = $this->loadRelations([$item], $relations);
        return $loaded[0] ?? null;
    }

    /**
     * 🛡️ Phase 3 (هسته eager loading): بارگذاری relations برای یک collection
     *
     * - اگر Model فرزند $relations تعریف نکرده باشد، items بدون تغییر برمی‌گردد
     * - اگر relation نامعتبر باشد، silent skip می‌شود (با logger)
     * - اگر items خالی باشد، query اضافی نمی‌زند
     * - اگر relation در $relations نباشد، silent skip می‌شود
     *
     * @param list<\stdClass> $items
     * @param list<string>|null $relations null = همه relations تعریف‌شده
     * @return list<\stdClass>
     */
    public function loadRelations(array $items, ?array $relations = null): array
    {
        if (empty($items) || empty($this->relations)) {
            return $items;
        }

        $relations = $relations ?? array_keys($this->relations);

        foreach ($relations as $relationName) {
            if (!isset($this->relations[$relationName])) {
                continue;
            }

            $definition = $this->relations[$relationName];

            // FIX-18O (P1): explicit belongsTo support (FK lives on THIS model's
            // table). Legacy [class, fk, mode] tuples keep their exact previous
            // hasMany/hasOne semantics further below.
            if (is_array($definition) && ($definition[0] ?? null) === 'belongsTo') {
                $relatedClass = is_string($definition[1] ?? null) ? (string)$definition[1] : '';
                $parentForeignKey = is_string($definition[2] ?? null) ? (string)$definition[2] : '';
                $relatedKey = is_string($definition[3] ?? null) && $definition[3] !== '' ? (string)$definition[3] : 'id';

                if ($relatedClass === '' || $parentForeignKey === '') {
                    if (function_exists('logger')) {
                        try { logger()->warning('model.relation.malformed_belongs_to', [
                            'model' => static::class,
                            'relation' => $relationName,
                        ]); } catch (\Throwable $ignore) {}
                    }
                    continue;
                }

                if (!class_exists($relatedClass)) {
                    if (function_exists('logger')) {
                        try { logger()->warning('model.relation.class_missing', [
                            'model' => static::class,
                            'relation' => $relationName,
                            'class' => $relatedClass,
                        ]); } catch (\Throwable $ignore) {}
                    }
                    continue;
                }

                $items = $this->attachBelongsToRelation($items, $relatedClass, $parentForeignKey, $relatedKey, $relationName);
                continue;
            }

            [$relatedClass, $foreignKey, $mode] = array_pad($definition, 3, 'many');
            $mode = $mode ?: 'many';

            if (!class_exists($relatedClass)) {
                if (function_exists('logger')) {
                    try { logger()->warning('model.relation.class_missing', [
                        'model' => static::class,
                        'relation' => $relationName,
                        'class' => $relatedClass,
                    ]); } catch (\Throwable $ignore) {}
                }
                continue;
            }

            $items = $this->attachRelation($items, $relatedClass, $foreignKey, $relationName, $mode);
        }

        return $items;
    }

    /**
     * 🛡️ Phase 3 (internal): یک relation را با یک query جمع‌آوری و attach می‌کند
     */
    /**
     * @param list<\stdClass> $items
     * @return list<\stdClass>
     */
    private function attachRelation(array $items, string $relatedClass, string $foreignKey, string $relationName, string $mode): array
    {
        // جمع‌آوری parent IDs (id هر item در collection فعلی)
        $parentIds = [];
        foreach ($items as $item) {
            if (isset($item->id)) {
                $parentIds[] = (int)$item->id;
            }
        }
        $parentIds = array_values(array_unique(array_filter($parentIds)));

        if (empty($parentIds)) {
            return $items;
        }

        try {
            /** @var Model $relatedModel */
            $relatedModel = new $relatedClass($this->db);
            $relatedTable = $relatedModel->getTable();
            if (empty($relatedTable)) {
                return $items;
            }

            // یک query برای همه related rows: WHERE foreign_key IN (...)
            $query = $relatedModel->whereIn($foreignKey, $parentIds);

            // mode 'one': فقط یکی (معمولاً آخرین/اولین) — برای wallet هر کاربر
            if ($mode === 'one') {
                $query->orderBy('id', 'DESC')->limit(100000); // همه را بگیر ولی بعد group کن
                $relatedItems = $query->get();

                // group by foreign key (هر parent فقط یک related دارد)
                $grouped = [];
                foreach ($relatedItems as $r) {
                    $fk = (int)($r->{$foreignKey} ?? 0);
                    if ($fk > 0 && !isset($grouped[$fk])) {
                        $grouped[$fk] = $r;
                    }
                }
                foreach ($items as $item) {
                    $item->{$relationName} = $grouped[(int)$item->id] ?? null;
                }
            } else { // mode 'many' — collection
                $relatedItems = $query->get();

                // group by foreign key (هر parent ممکن است چند related داشته باشد)
                $grouped = [];
                foreach ($relatedItems as $r) {
                    $fk = (int)($r->{$foreignKey} ?? 0);
                    if ($fk > 0) {
                        $grouped[$fk][] = $r;
                    }
                }
                foreach ($items as $item) {
                    $item->{$relationName} = $grouped[(int)$item->id] ?? [];
                }
            }
        } catch (\Throwable $e) {
            // Eager load failure should NEVER break the original query result
            if (function_exists('logger')) {
                try { logger()->warning('model.relation.load_failed', [
                    'model' => static::class,
                    'relation' => $relationName,
                    'error' => $e->getMessage(),
                ]); } catch (\Throwable $ignore) {}
            }
        }

        return $items;
    }

    /**
     * FIX-18O (P1): attach a belongsTo relation.
     *
     * The FK column lives on the PARENT (this model's) rows. Related rows are
     * fetched by `related.{relatedKey} IN (parent.{parentFk} values)` and each
     * item gets `$item->{relationName} = relatedRow` matched by
     * parent.{parentFk} → related.{relatedKey} (null when absent).
     *
     * Failure semantics mirror attachRelation(): a load error never breaks the
     * original result set.
     *
     * @param list<\stdClass> $items
     * @return list<\stdClass>
     */
    private function attachBelongsToRelation(array $items, string $relatedClass, string $parentForeignKey, string $relatedKey, string $relationName): array
    {
        $parentValues = [];
        foreach ($items as $item) {
            $val = $item->{$parentForeignKey} ?? null;
            if ($val === null || $val === '') {
                continue;
            }
            $parentValues[] = is_numeric($val) ? (int)$val : (string)$val;
        }
        $parentValues = array_values(array_unique(array_filter(
            $parentValues,
            static fn($v): bool => $v !== 0 && $v !== '0' && $v !== ''
        )));

        if (empty($parentValues)) {
            foreach ($items as $item) {
                $item->{$relationName} = null;
            }
            return $items;
        }

        try {
            /** @var Model $relatedModel */
            $relatedModel = new $relatedClass($this->db);
            $relatedTable = $relatedModel->getTable();
            if (empty($relatedTable)) {
                return $items;
            }

            // یک query برای همه related rows: WHERE {relatedKey} IN (parent fk values)
            $relatedItems = $relatedModel->whereIn($relatedKey, $parentValues)->get();

            $grouped = [];
            foreach ($relatedItems as $r) {
                $rk = $r->{$relatedKey} ?? null;
                if ($rk === null || $rk === '') {
                    continue;
                }
                $grouped[is_numeric($rk) ? (int)$rk : (string)$rk] = $r;
            }

            foreach ($items as $item) {
                $val = $item->{$parentForeignKey} ?? null;
                $item->{$relationName} = ($val === null || $val === '')
                    ? null
                    : ($grouped[is_numeric($val) ? (int)$val : (string)$val] ?? null);
            }
        } catch (\Throwable $e) {
            if (function_exists('logger')) {
                try { logger()->warning('model.relation.belongs_to_load_failed', [
                    'model' => static::class,
                    'relation' => $relationName,
                    'error' => $e->getMessage(),
                ]); } catch (\Throwable $ignore) {}
            }
        }

        return $items;
    }

    /**
     * 🛡️ Phase 3: relations تعریف‌شده در این Model را برمی‌گرداند
     * (برای introspection / debug)
     */
    /** @return array<string, RelationDefinition|BelongsToRelationDefinition> */
    public function getDefinedRelations(): array
    {
        return $this->relations;
    }

    /**
     * بروزرسانی یک رکورد.
     *
     * اگر $fillable پر باشد، فقط فیلدهای مجاز بروزرسانی می‌شوند.
     * فیلد updated_at که خود این متد اضافه می‌کند همیشه مجاز است
     * و نیازی به قرار گرفتن در $fillable ندارد.
     *
     * @throws \InvalidArgumentException W4-F (F-A2-08): کلید ناشناخته نسبت به ستون‌های زندهٔ جدول
     *                        (Runtime Column Guard — fail-fast، شامل updated_at مهرشده)
     */
    /** @param AttributeMap $data */
    public function update(int $id, array $data): bool
    {
        $data = $this->filterFillable($data);
        // FIX-R36-W3 (F-A9a-14) — قراردادِ مستندشده (رفتار تغییر نکرد): updated_at
        // همیشه اینجا مهر می‌شود؛ هر مدلی که از این path عبور می‌کند باید ستون
        // updated_at داشته باشد (ممیزی A2: همهٔ جدول‌های زنده دارند). اگر روزی
        // جدول بدون updated_at به این کلاس وصل شود، UPDATE همین‌جا fail می‌شود —
        // عمداً fail-loud، نه silent-skip که history به‌درغلط مهر نشود.
        $data['updated_at'] = date('Y-m-d H:i:s');

        // W4-F (F-A2-08): گارد ستون بعد از مهرِ updated_at — کل مجموعهٔ نوشتن
        // (شامل updated_at) نسبت به ستون‌های زنده اعتبارسنجی می‌شود.
        $this->guardColumns($data, 'UPDATE');

        $affected = $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->update($data);

        return $affected > 0;
    }

    /** Soft Delete */
    public function delete(int $id): bool
    {
        // FIX C-9: قبلاً بدون چک وجود ردیف، update انجام می‌شد.
        // اگر id وجود نمی‌داشت، 0 ردیف تأثیر می‌گرفت و هیچ خطایی
        // داده نمی‌شد — صداکننده فکر می‌کرد عملیات موفق بوده.
        if (!$this->exists($id)) {
            return false;
        }

        $affected = $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->update(['deleted_at' => date('Y-m-d H:i:s')]);

        return $affected > 0;
    }

    /** Hard Delete — با احتیاط استفاده کنید */
    public function forceDelete(int $id): bool
    {
        return (bool)$this->db->table(static::$table)
            ->where('id', '=', $id)
            ->delete();
    }

    public function count(): int
    {
        return (int) $this->db->table(static::$table)->count();
    }


    // ─────────────────────────────────────────────────────────────
    // Query Builder Bridge — امکان chain کردن روی Model
    // ─────────────────────────────────────────────────────────────

    /**
     * شروع یک query با WHERE روی جدول این Model
     * مثال: $this->model->where('user_id', $id)->whereIn('status', [...])->first()
     */
    public function where(string $column, mixed $operatorOrValue = '=', mixed $value = null): QueryBuilder
    {
        return $this->db->table(static::$table)->where($column, $operatorOrValue, $value);
    }

    /** @param list<mixed> $values */
    public function whereIn(string $column, array $values): QueryBuilder
    {
        return $this->db->table(static::$table)->whereIn($column, $values);
    }

    public function whereNull(string $column): QueryBuilder
    {
        return $this->db->table(static::$table)->whereNull($column);
    }

    public function whereNotNull(string $column): QueryBuilder
    {
        return $this->db->table(static::$table)->whereNotNull($column);
    }

    public function orderBy(string $column, string $direction = 'ASC'): QueryBuilder
    {
        return $this->db->table(static::$table)->orderBy($column, $direction);
    }

    /**
     * دسترسی مستقیم به QueryBuilder برای query های پیچیده‌تر
     */
    public function query(): QueryBuilder
    {
        return $this->db->table(static::$table);
    }

    /**
     * اجرای SQL و بازگشت یک سطر — proxy به Database::fetch
     * @param array<int|string, mixed> $params
     * @return ?\stdClass
     */
    public function fetch(string $sql, array $params = []): ?\stdClass
    {
        return $this->db->fetch($sql, $params);
    }

    /**
     * اجرای SQL و بازگشت همه سطرها — proxy به Database::fetchAll
     * @param array<int|string, mixed> $params
     * @return list<\stdClass>
     */
    public function fetchAll(string $sql, array $params = []): array
    {
        return $this->db->fetchAll($sql, $params);
    }

    public function exists(int $id): bool
    {
        return (bool) $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->selectRaw('1')
            ->first();
    }

    public function beginTransaction(): void
    {
        $this->db->beginTransaction();
    }

    public function commit(): void
    {
        $this->db->commit();
    }

    public function rollback(): void
    {
        $this->db->rollback();
    }

    /**
     * اعمال هوشمند فیلتر کلمه کلیدی (LIKE) بر روی ستون‌های تعریف شده در $searchable
     */
    public function applySearch(QueryBuilder $query, ?string $term): QueryBuilder
    {
        $term = trim((string)$term);
        if (empty($term) || empty(static::$searchable)) {
            return $query;
        }

        $escaped = $this->escapeLikeValue($term);
        $like = "%{$escaped}%";

        return $query->where(function(QueryBuilder $q) use ($like) {
            foreach (static::$searchable as $index => $column) {
                if ($index === 0) {
                    $q->where($column, 'LIKE', $like);
                } else {
                    $q->orWhere($column, 'LIKE', $like);
                }
            }
        });
    }

    /**
     * Escape LIKE wildcards to prevent injection
     *
     * FIX-S5-1: backslash MUST be in the escape set. With '%_' only, a user
     * term like "\%" was emitted as "\\%" which MySQL LIKE parses as a literal
     * backslash followed by a LIVE wildcard — i.e. prefixing % or _ with a
     * backslash silently bypassed the escaping (same class of defect M31 fixed
     * in AuditTrail/Dispute, which already use the correct '%_\\' set).
     * Escaping '\' first makes every produced "\x" sequence unambiguous.
     */
    protected function escapeLikeValue(string $value, int $maxLength = 100): string
    {
        $value = trim((string)$value);

        if (strlen((string)$value) > $maxLength) {
            throw new \InvalidArgumentException("Search term exceeds {$maxLength} characters");
        }

        return addcslashes($value, "\\%_");
    }
    
    /**
     * Chunked update helper
     * @param array<int|string, mixed> $params
     */
    protected function chunkedUpdate(
        string $sql, 
        array $params, 
        int $chunkSize = 1000,
        int $maxIterations = 100
    ): int {
        $totalAffected = 0;

        for ($i = 0; $i < $maxIterations; $i++) {
            // BUGFIX-PHASE2-P2CU: قبلاً prepare/execute مستقیم روی PDOStatement
            // انجام می‌شد که از wrapper مرکزی Database::executeStatement عبور
            // می‌کرد؛ نتیجه: sticky-primary بعد از نوشتن (M-37 read-your-writes)
            // ست نمی‌شد، slow-query log / error reporting / retry هم غیرفعال
            // بود. اکنون از همان مسیر Database::execute() استفاده می‌شود.
            $affected = $this->db->execute($sql . " LIMIT ?", array_merge($params, [$chunkSize]));
            $totalAffected += $affected;

            if ($affected < $chunkSize) {
                break;
            }

            usleep(50000); // 50ms delay
        }
        
        return $totalAffected;
    }
    
    /** @return array<string, mixed> */
    public function paginate(int $perPage = 15, string $pageName = 'page', ?int $page = null): array
    {
        return $this->db->table(static::$table)->paginate($perPage, $pageName, $page);
    }

    /**
     * صفحه‌بندی مبتنی بر نشانگر (Cursor-Based Pagination)
     * جهت اسکرول بی‌نهایت در اپلیکیشن‌های نیتیو موبایل
     */
    /** @return array<string, mixed> */
    public function cursorPaginate(string $cursorColumn = 'id', int $perPage = 15, ?string $cursorValue = null, string $direction = 'desc'): array
    {
        return $this->db->table(static::$table)->cursorPaginate($cursorColumn, $perPage, $cursorValue, $direction);
    }

    /**
     * find-or-create with race-safe semantics.
     *
     * Concurrency model (industry-standard "INSERT-then-recover"):
     * ───────────────────────────────────────────────────────────────────────
     *   1. SELECT with the given attributes. If found → return.
     *   2. Try INSERT inside a (possibly nested) transaction.
     *   3. If INSERT raises a UNIQUE-violation, another writer won the race.
     *      → SELECT again and return the winner's row.
     *   4. Any other PDOException re-throws unchanged.
     *
     * Why not GET_LOCK / ON DUPLICATE KEY UPDATE?
     *   - GET_LOCK is global serialization across the cluster — orders of
     *     magnitude slower under contention and MySQL-only.
     *   - ON DUPLICATE KEY UPDATE is MySQL-only AND semantically wrong for
     *     "first-or-create" (it would overwrite existing rows on race loss).
     *   - "INSERT-then-recover" works on MySQL/PostgreSQL/SQLite alike, only
     *     requires what you already need anyway: a UNIQUE index on $attributes.
     *
     * PREREQUISITE — required of the caller:
     *   The columns named in $attributes MUST form (or be covered by) a UNIQUE
     *   index in the database. Without that, no race-free upsert exists in any
     *   RDBMS at any cost, and this method will throw RuntimeException after
     *   the second race-detection failure to make the missing constraint loud.
     *
     * @param array<string,mixed> $attributes lookup columns (must be UNIQUE-indexed)
     * @param array<string,mixed> $values     extra columns to set on INSERT only
     * @throws \RuntimeException if a race occurs but no UNIQUE constraint exists
     * @throws \PDOException     for non-uniqueness DB errors
     */
    public function firstOrCreate(array $attributes, array $values = []): object
    {
        return $this->createOrFetchAtomically(
            $attributes,
            $values,
            updateExistingWithValues: false,
        );
    }

    /**
     * update-or-create with race-safe semantics.
     * Same concurrency contract as firstOrCreate(); see its docblock.
     * Difference: when a row already exists (initial SELECT *or* race loss),
     * $values are written on top of it.
     *
     * @param array<string,mixed> $attributes lookup columns (must be UNIQUE-indexed)
     * @param array<string,mixed> $values     columns to set on both INSERT and UPDATE
     */
    public function updateOrCreate(array $attributes, array $values = []): object
    {
        return $this->createOrFetchAtomically(
            $attributes,
            $values,
            updateExistingWithValues: true,
        );
    }

    /**
     * Shared core for firstOrCreate / updateOrCreate.
     *
     * Implements the four-step protocol described in firstOrCreate()'s docblock.
     * Wraps the INSERT in beginTransaction()/commit() so the row is fully
     * committed before the post-INSERT SELECT runs — preventing find() from
     * observing a phantom NULL on read replicas. Database::beginTransaction()
     * already issues SAVEPOINTs for nested calls, so a caller's outer
     * transaction is preserved without interference.
     *
     * @param AttributeMap $attributes
     * @param AttributeMap $values
     */
    private function createOrFetchAtomically(
        array $attributes,
        array $values,
        bool $updateExistingWithValues,
    ): object {
        // Step 1: optimistic SELECT (cheap — avoids transaction overhead in the
        // common path where the row already exists).
        $existing = $this->selectByAttributes($attributes);
        if ($existing !== null) {
            if ($updateExistingWithValues && !empty($values)) {
                $this->update((int) $existing->id, $values);
                return $this->find((int) $existing->id) ?? $existing;
            }
            return $existing;
        }

        // Step 2: one INSERT attempt inside a transaction. InnoDB resolves a
        // duplicate-key race only after the competing writer commits or rolls
        // back, so a post-rollback SELECT can observe the committed winner.
        // Retrying INSERT is both redundant and unsafe when the violated UNIQUE
        // constraint is unrelated to the lookup attributes.
        $this->db->beginTransaction();
        try {
            $id = $this->create(array_merge($attributes, $values));
            $this->db->commit();

            // Post-commit fetch by primary key. If a concurrent delete wins in
            // this narrow window, retry lookup by immutable attributes.
            return $this->find((int)$id)
                ?? $this->selectByAttributes($attributes)
                ?? throw new \RuntimeException(
                    'createOrFetch: INSERT succeeded but row vanished before fetch'
                );
        } catch (\PDOException $e) {
            $this->db->rollback();

            if (!$this->isUniqueViolation($e)) {
                // FK, NOT NULL, CHECK, deadlock and connection errors are not
                // idempotency races and must propagate unchanged.
                throw $e;
            }

            $winner = $this->selectByAttributes($attributes);
            if ($winner !== null) {
                if ($updateExistingWithValues && $values !== []) {
                    $this->update((int)$winner->id, $values);
                    return $this->find((int)$winner->id) ?? $winner;
                }

                return $winner;
            }

            throw new \RuntimeException(
                "createOrFetch on " . static::$table . ": a UNIQUE violation occurred " .
                "but no row matches the lookup attributes (" . implode(',', array_keys($attributes)) . "). " .
                "Ensure these columns are covered by a UNIQUE index.",
                0,
                $e
            );
        }
    }

    /**
     * SELECT one row matching every key=>value in $attributes, or null.
     * This database read is intentionally impure: a concurrent transaction may
     * commit between two calls with identical arguments.
     *
     * @phpstan-impure
     * @param AttributeMap $attributes
     */
    private function selectByAttributes(array $attributes): ?\stdClass
    {
        $q = $this->db->table(static::$table);
        foreach ((array)$attributes as $col => $val) {
            $q->where($col, '=', $val);
        }
        $row = $q->first();
        return $row ?: null;
    }

    /**
     * Driver-precise UNIQUE-violation detection.
     *
     * SQLSTATE 23000 alone is too broad: it's the "integrity constraint"
     * umbrella, covering UNIQUE *and* NOT NULL, FK, CHECK violations. Silently
     * retrying any 23000 would hide real bugs (e.g. inserting NULL into a
     * NOT NULL column would loop forever). We narrow to driver-specific codes:
     *
     *   MySQL/MariaDB → errorInfo[1] === 1062  (ER_DUP_ENTRY) or 1586
     *   PostgreSQL    → SQLSTATE === '23505'   (unique_violation)
     *   SQLite        → errorInfo[1] === 2067  (SQLITE_CONSTRAINT_UNIQUE), or
     *                   19 + message check     (extended-result-codes off)
     *
     * Refs: dev.mysql.com/doc/mysql-errors, postgresql.org/docs/current/errcodes-appendix,
     *       sqlite.org/rescode
     */
    private function isUniqueViolation(\PDOException $e): bool
    {
        $info       = $e->errorInfo ?? [];
        $sqlstate   = $info[0] ?? (string) $e->getCode();
        $driverCode = $info[1] ?? null;

        // PostgreSQL: SQLSTATE is precise enough.
        if ($sqlstate === '23505') return true;

        // MySQL: 23000 alone is ambiguous — must inspect driver code.
        if ($sqlstate === '23000' && in_array($driverCode, [1062, 1586], true)) return true;

        // SQLite: 2067 is the precise extended code; 19 is the generic
        // CONSTRAINT and needs a message-text fallback.
        if ($driverCode === 2067) return true;
        if ($driverCode === 19 && stripos($e->getMessage(), 'UNIQUE constraint failed') !== false) {
            return true;
        }

        return false;
    }

    /**
     * Validate integer ID
     */
    protected function validateId(int $id, string $field = 'id'): void
    {
        if ($id <= 0) {
            throw new \InvalidArgumentException("Invalid {$field}: must be positive integer");
        }
    }
    
    /**
     * Validate date string
     */
    protected function validateDate(string $date, string $field = 'date'): void
    {
        $d = \DateTime::createFromFormat('Y-m-d H:i:s', $date);
        if (!$d || $d->format('Y-m-d H:i:s') !== $date) {
            throw new \InvalidArgumentException("Invalid {$field} format");
        }
    }
}
