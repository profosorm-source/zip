<?php

declare(strict_types=1);

/**
 * core/Autoloader.php — شیم سازگاری برای نقاط ورود legacy
 *
 * FIX-REAUDIT-1: ۱۵ فایل از نقاط ورود storage/cron/*.php (که در بستهٔ اصلاحات
 * به‌عنوان کپی سالم تحویل شدند) پیش از bootstrap/app.php این فایل را require
 * می‌کنند:
 *     require_once BASE_PATH . '/core/Autoloader.php';
 * این فایل در اسنپ‌شات GitHub وجود نداشت (احتمالاً فقط روی سرور production
 * به‌صورت untracked موجود بود) — بنابراین اجرای cron روی هر checkout تازه
 * با «Failed opening required core/Autoloader.php» fatal می‌شد.
 *
 * رفتار: load کردن composer autoload (همان منبع کلاس‌هایی که bootstrap/app.php
 * استفاده می‌کند؛ require_once بودن یعنی require دوباره در bootstrap بی‌اثر و
 * بی‌ضرر است). در نبودِ vendor، خطا صریح و fail-fast گزارش می‌شود — با همان
 * قرارداد bootstrap/app.php (CLI → STDERR + exit 1؛ وب → 500).
 */

if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

$composerAutoload = BASE_PATH . '/vendor/autoload.php';

if (!is_file($composerAutoload)) {
    $message = "Error: vendor/autoload.php not found. Run 'composer install'." . PHP_EOL;

    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $message);
        exit(1);
    }

    http_response_code(500);
    exit($message);
}

require_once $composerAutoload;
