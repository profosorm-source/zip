<?php

declare(strict_types=1);

namespace Core;

/**
 * Canonical application and asset URL generator.
 *
 * Origins come exclusively from validated configuration. Request Host headers
 * are never used to construct canonical links.
 */
final class UrlGenerator
{
    private string $applicationUrl;
    private ?string $assetUrl;
    private string $environment;

    public function __construct(
        string $applicationUrl,
        ?string $assetUrl = null,
        ?string $basePath = null,
        string $environment = 'production'
    ) {
        $this->applicationUrl = $this->normalizeConfiguredUrl($applicationUrl, 'Application URL');
        $this->environment = $environment;
        $this->assetUrl = $assetUrl === null || trim($assetUrl) === ''
            ? null
            : $this->normalizeConfiguredUrl($assetUrl, 'Asset URL');

        if ($environment === 'production') {
            foreach ([$this->applicationUrl, $this->assetUrl] as $configuredUrl) {
                if ($configuredUrl === null) {
                    continue;
                }
                $host = strtolower((string)parse_url($configuredUrl, PHP_URL_HOST));
                if (in_array($host, ['localhost', '127.0.0.1', '::1'], true)) {
                    throw new \RuntimeException('Production canonical URLs must not use loopback hosts.');
                }
            }
        }

        $normalizedBasePath = $this->normalizeBasePath($basePath);
        if ($normalizedBasePath !== '') {
            $configuredPath = trim((string)(parse_url($this->applicationUrl, PHP_URL_PATH) ?: ''), '/');
            if ($configuredPath === '') {
                $this->applicationUrl .= '/' . $normalizedBasePath;
            } elseif ($configuredPath !== $normalizedBasePath) {
                throw new \InvalidArgumentException(
                    'Application URL path and configured application base path conflict.'
                );
            }
        }
    }

    public function base(): string
    {
        return $this->applicationUrl;
    }

    public function origin(): string
    {
        // BRINGUP-2026-09 (dev-only): در غیر-production origin درخواست (پشت پراکسی)
        // ترجیح دارد تا CSRF origin-check و redirect allowlist با مرورگر هم‌خوان بمانند.
        // FIX-R18F: environment 'testing' استثنا شد — باید با effectiveBaseUrl هم‌سو
        // و کانonical بماند وگرنه allowlist ریدایرکت با URL تولیدی ناسازگار می‌شود.
        if (!in_array($this->environment, ['production', 'testing'], true)) {
            $req = $this->requestOrigin();
            if ($req !== null) {
                return $req;
            }
        }
        return $this->originOf($this->applicationUrl);
    }

    public function assetBase(): string
    {
        return $this->assetUrl ?? $this->applicationUrl;
    }

    public function assetOrigin(): string
    {
        return $this->originOf($this->assetUrl ?? $this->applicationUrl);
    }

    public function to(string $path = ''): string
    {
        // BRINGUP-2026-09 (dev-only): در محیط غیر-production و پشت پراکسی/پیش‌نمایش،
        // origin کانفیگ (مثلاً http://localhost) با origin واقعی درخواست جایگزین می‌شود
        // تا فرم‌ها/لینک‌های مطلق به مقصد درست POST شوند. در production رفتار کانonical
        // دست‌نخورده می‌ماند (هیچ‌گاه از Host استفاده نمی‌شود — ضد host-header injection).
        return $this->appendRelativePath($this->effectiveBaseUrl(), $path);
    }

    private function effectiveBaseUrl(): string
    {
        // FIX-R18F: environment 'testing' هم مثل production کانonical می‌ماند —
        // پین S-Core («هدر Host هرگز URL کمکی container-backed را تغییر نمی‌دهد»)
        // در محیط تست باید قابل راستی‌آزمایی باشد؛ override فقط برای dev واقعی
        // (local/staging پشت پراکسی پیش‌نمایش) است.
        if ($this->environment === 'production' || $this->environment === 'testing') {
            return $this->applicationUrl;
        }
        $origin = $this->requestOrigin();
        if ($origin === null) {
            return $this->applicationUrl;
        }
        $configuredPath = trim((string)(parse_url($this->applicationUrl, PHP_URL_PATH) ?: ''), '/');
        return $origin . ($configuredPath !== '' ? '/' . $configuredPath : '');
    }

    private function requestOrigin(): ?string
    {
        $forwardedHost = trim((string)($_SERVER['HTTP_X_FORWARDED_HOST'] ?? ''));
        if ($forwardedHost !== '') {
            // FIX-M1M4: هدر Forwarded-Host فقط از proxy صریحاً معتمد پذیرفته می‌شود
            if (!is_trusted_proxy_peer()) {
                $forwardedHost = '';
            }
        }
        $host = $forwardedHost !== ''
            ? $forwardedHost
            : trim((string)($_SERVER['HTTP_HOST'] ?? ''));
        if (str_contains($host, ',')) {
            $host = trim(explode(',', $host)[0]);
        }
        if ($host === '' || preg_match('/^[A-Za-z0-9.\-]+(:\d{1,5})?$/', $host) !== 1) {
            return null;
        }
        // FIX-M1M4: هاست باید در allowlist پیکربندی‌شدهٔ app.allowed_hosts باشد
        // (اگر پیکربندی شده باشد) — مانع تبدیل Host-Header به مبنا của origin/redirect در محیط dev عمومی
        if (!is_allowed_origin_host($host)) {
            return null;
        }
        $proto = strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? $_SERVER['REQUEST_SCHEME'] ?? 'http')));
        if (!in_array($proto, ['http', 'https'], true)) {
            $proto = 'http';
        }
        return $proto . '://' . $host;
    }

    public function asset(string $path): string
    {
        $resolved = $this->appendRelativePath($this->assetUrl ?? $this->applicationUrl, $path);

        // X41: asset همیشه same-host است؛ وقتی asset base اختصاصی (CDN) تنظیم نشده،
        // تولید URL مطلق با هاست کانفیگ‌شده باعث می‌شود اگر صفحه از origin دیگری باز شود
        // (پروکسی، هاست متفاوت، loopback معادل) مرورگر asset را cross-origin بارگیری کند و
        // CSS/JS/فونت اعمال نشوند. root-relative روی هر هاستی درست کار می‌کند و
        // از منظر امنیتی هم هیچ هاستی جاسازی نمی‌کند.
        if ($this->assetUrl === null) {
            $prefix = rtrim($this->applicationUrl, '/') . '/';
            $candidate = str_starts_with($resolved, $prefix)
                ? substr($resolved, strlen($prefix))
                : ltrim($resolved, '/');
            $appPath = trim((string)(parse_url($this->applicationUrl, PHP_URL_PATH) ?: ''), '/');

            return '/' . ($appPath !== '' ? $appPath . '/' : '') . $candidate;
        }

        return $resolved;
    }

    private function originOf(string $url): string
    {
        $scheme = (string)parse_url($url, PHP_URL_SCHEME);
        $host = (string)parse_url($url, PHP_URL_HOST);
        $port = parse_url($url, PHP_URL_PORT);

        return $scheme . '://' . $host . (is_int($port) ? ':' . $port : '');
    }

    private function normalizeConfiguredUrl(string $url, string $label): string
    {
        $url = rtrim(trim($url), '/');
        if ($url === '') {
            throw new \InvalidArgumentException("{$label} must be a non-empty absolute URL.");
        }

        $parts = parse_url($url);
        $scheme = is_array($parts) ? ($parts['scheme'] ?? null) : null;
        $host = is_array($parts) ? ($parts['host'] ?? null) : null;
        if (!in_array($scheme, ['http', 'https'], true) || !is_string($host) || $host === '') {
            throw new \InvalidArgumentException("{$label} must use an absolute HTTP(S) origin.");
        }
        if (isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
            throw new \InvalidArgumentException("{$label} must not contain credentials, query parameters, or fragments.");
        }

        return $url;
    }

    private function normalizeBasePath(?string $basePath): string
    {
        if ($basePath === null || trim($basePath) === '') {
            return '';
        }

        $basePath = trim(str_replace('\\', '/', $basePath), '/');
        if (
            $basePath === ''
            || str_contains($basePath, "\0")
            || in_array('..', explode('/', $basePath), true)
            || preg_match('/^[A-Za-z0-9._~\/-]+$/', $basePath) !== 1
        ) {
            throw new \InvalidArgumentException('Application base path is invalid.');
        }

        return $basePath;
    }

    private function appendRelativePath(string $baseUrl, string $path): string
    {
        if (str_contains($path, "\0")) {
            throw new \InvalidArgumentException('URL path must not contain null bytes.');
        }

        $path = str_replace('\\', '/', trim($path));
        $candidate = ltrim($path, '/');
        if (preg_match('#^[a-z][a-z0-9+.-]*://#i', $candidate) === 1 || str_starts_with($path, '//')) {
            throw new \InvalidArgumentException('URL generator accepts relative paths only.');
        }

        // FIX-M1M5: segmentهای . و .. (پس از decode) رد می‌شوند — ورودی مثل
        // ../admin دیگر لینکی نمی‌سازد که مرورگر/پروکسی آن را به مسیر بالاتر
        // normalize کند؛ شکست صریح به‌جای تولید URL خارج از base path.
        $decoded = rawurldecode($candidate);
        if (preg_match('#(?:^|/)\.{1,2}(?:/|$)#', $decoded) === 1) {
            throw new \InvalidArgumentException('URL path must not contain dot segments.');
        }

        $configuredBasePath = trim((string)(parse_url($baseUrl, PHP_URL_PATH) ?: ''), '/');
        if (
            $configuredBasePath !== ''
            && ($candidate === $configuredBasePath || str_starts_with($candidate, $configuredBasePath . '/'))
        ) {
            $candidate = ltrim(substr($candidate, strlen($configuredBasePath)), '/');
        }

        return $baseUrl . '/' . $candidate;
    }
}
