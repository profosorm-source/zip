<?php

declare(strict_types=1);

namespace Core;

abstract class Command
{
    protected function info(string $message): void
    {
        $this->output("[INFO] {$message}\n");
    }

    protected function line(string $message): void
    {
        $this->output("{$message}\n");
    }

    protected function error(string $message): void
    {
        $this->output("[ERROR] {$message}\n", true);
    }

    /**
     * 🛡️ خروجی هوشمند و تشخیص استریم‌های غیرتعاملی (Non-TTY TTY Log Stripping Guard)
     * حذف خودکار کدهای رنگی ANSI در زمان اجرای دیمن‌ها در داکر، کرون و کوبرنتیز جهت جلوگیری از درج کاراکترهای فاسد در سیستم‌های لاگ
     */
    protected function output(string $message, bool $isErr = false): void
    {
        $stream = $isErr ? (defined('STDERR') ? STDERR : STDOUT) : STDOUT;
        if (!function_exists('stream_isatty') || !stream_isatty($stream)) {
            // FIX-R36-W3 (F-A9b-13): قبلاً فقط SGR (…m) حذف می‌شد (حمل‌شده R30 INFO) —
            // \033[2K، کدهای مکان‌نما و OSC در لاگِ دیمونِ non-TTY می‌ماندند.
            $message = $this->stripAnsiEscapes($message);
        }
        if ($stream !== STDOUT && defined('STDERR')) {
            fwrite(STDERR, $message);
            fflush(STDERR);
        } else {
            echo $message;
        }
    }

    /**
     * FIX-R36-W3 (F-A9b-13): حذف کامل توالی‌های ANSI ESC برای خروجی non-TTY —
     * همهٔ CSI (شامل SGR، پاک‌کردن خط، جابه‌جایی مکان‌نما و مودهای private با «؟»)،
     * توالی‌های OSC (عنوان ترمینال؛ پایانهٔ BEL یا ST) و BELِ باقی‌مانده.
     */
    private function stripAnsiEscapes(string $message): string
    {
        $message = (string)preg_replace(
            [
                '/\x1B\[[0-9;?<=>]*[A-Za-z]/',
                '/\x1B\][^\x07\x1B]*(?:\x07|\x1B\\\\)/',
                '/\x07/',
            ],
            '',
            $message
        );
        return $message;
    }
}
