<?php
namespace Core;

/**
 * Response Handler
 * 
 * مدیریت پاسخ‌های HTTP
 */
class Response
{
    private int $statusCode = 200;
    /** @var array<string, string> */
    private array $headers = [];
    private string $content = '';
    private ?string $downloadPath = null; // H10 Fix: مدیریت استریم دانلود بدون بلاک کردن ترد اجرا
    private ?\Core\Request $request = null;

    public function __construct(?\Core\Request $request = null) {
        $this->request = $request;
    }
    
    // ✅ Whitelist of allowed header names (case-insensitive)
    private const ALLOWED_HEADERS = [
        'cache-control',
        'content-type',
        'content-length',
        'content-encoding',
        'connection',
        'keep-alive',
        'content-disposition',
        'expires',
        'etag',
        'last-modified',
        'pragma',
        'location',
        'set-cookie',
        'x-custom-header',
        'access-control-allow-origin',
        'x-frame-options',
        'x-content-type-options',
        'x-xss-protection',
        'strict-transport-security',
        'content-security-policy',
        'referrer-policy',
        'permissions-policy',
        'cross-origin-opener-policy',
        'cross-origin-resource-policy',
        'cross-origin-embedder-policy',
        'reporting-endpoints',
        'report-to',
        'nel',
        'vary',
        'access-control-allow-credentials',
        'access-control-allow-methods',
        'access-control-allow-headers',
        'access-control-max-age',
        'server',
        'x-ratelimit-limit',
        'x-ratelimit-remaining',
        'retry-after',
        // FIX-M11-R22-8: هدر مدیریت پیش‌دستانهٔ انقضای توکن در کلاینت (MED-04)
        'x-token-expires-at',
        'x-correlation-id',
        'x-request-id',
    ];

    public function setStatusCode(int $code): self
    {
        if ($code < 100 || $code > 599) {
            throw new \InvalidArgumentException("کد وضعیت HTTP نامعتبر است: {$code}");
        }
        $this->statusCode = $code;
        return $this;
    }
    
    /**
     * دریافت Status Code
     */
    public function getStatusCode(): int
    {
        return $this->statusCode;
    }
    
    /**
     * ✅ Validate header name and value to prevent header injection
     */
    private function validateHeader(string $name, string $value): bool
    {
        // ✅ Header name should be alphanumeric and hyphenated only
        if (!preg_match('/^[a-zA-Z0-9\-]+$/', $name)) {
            throw new \InvalidArgumentException("نام Header معتبر نیست: {$name}");
        }
        
        // ✅ Prevent CRLF injection in value
        if (preg_match("/[\r\n]/", $value)) {
            throw new \InvalidArgumentException("مقدار Header نمی‌تواند شامل خط جدید باشد");
        }
        
        // ✅ Check against whitelist
        if (!in_array(strtolower((string)$name), self::ALLOWED_HEADERS, true)) {
            throw new \InvalidArgumentException("Header نام‌گذاری شده نیست: {$name}");
        }
        
        return true;
    }
    
    /**
     * تنظیم Header
     */
    public function setHeader(string $name, string $value): self
    {
        $this->validateHeader($name, $value);
        $this->headers[$name] = $value;
        return $this;
    }

    /**
     * تنظیم Content
     */
    public function setContent(mixed $content): self
    {
        $this->content = str_value($content);
        return $this;
    }

    /**
     * دریافت Content
     */
    public function getContent(): string
    {
        return (string)$this->content;
    }

    /**
     * @param array<mixed> $data
     */
    public function json(array $data, ?int $statusCode = null): void
    {
        // Preserve a status explicitly set through status()/setStatusCode().
        // A fresh Response already defaults to 200, while chained responses
        // such as status(405)->json(...) must not be reset back to 200.
        if ($statusCode !== null) {
            $this->statusCode = $statusCode;
        }
        $this->setHeader('Content-Type', 'application/json; charset=utf-8');

        $options = JSON_UNESCAPED_UNICODE;
        if (config('app.debug')) {
            $options |= JSON_PRETTY_PRINT;
        }
        
        $this->content = json_encode($data, $options | JSON_THROW_ON_ERROR);
        $this->send();
    }

    /**
     * ارسال پاسخ بدون محتوا (204 No Content)
     */
    public function noContent(): void
    {
        $this->statusCode = 204;
        $this->content = '';
        $this->send();
    }

    /**
     * ارسال پاسخ HTML
     */
    public function html(string $content, int $statusCode = 200): void
    {
        $this->statusCode = $statusCode;
        $this->setHeader('Content-Type', 'text/html; charset=utf-8');
        
        $this->content = $content;
        $this->send();
    }
    
    /**
     * پاسخ موفق
     */
    public function success(mixed $message, mixed $data = [], int $statusCode = 200): void
    {
        $this->json([
            'success' => true,
            'message' => $message,
            'data' => $data
        ], $statusCode);
    }

    /**
     * پاسخ خطا
     */
    public function error(mixed $message, mixed $errors = [], int $statusCode = 400): void
    {
        $this->json([
            'success' => false,
            'message' => $message,
            'errors' => $errors
        ], $statusCode);
    }

    /**
     * ✅ Validate URL to prevent open redirect attacks
     */
    private function validateRedirectUrl(string $url): bool
    {
        // Prevent CRLF injection
        if (preg_match("/[\r\n]/", $url)) {
            throw new \InvalidArgumentException('آدرس ریدایرکت شامل کاراکترهای غیرمجاز است');
        }

        // 1. Block protocol-relative or backslash bypasses (e.g. //google.com, ///google.com, /\\google.com)
        if (preg_match('#^[\\\\/]{2,}#', $url) || preg_match('#^/+\\\\#', $url)) {
            throw new \InvalidArgumentException('آدرس ریدایرکت نامعتبر است (آدرس‌های نسبی پروتکل مجاز نیستند)');
        }

        // 2. Allow safe relative paths starting with a single slash (e.g. /dashboard)
        if (strpos($url, '/') === 0 && strpos($url, '//') !== 0 && strpos($url, '/\\') !== 0) {
            return true;
        }

        // 3. For absolute URLs, parse and strictly validate host
        $baseHost = (string)parse_url(app(UrlGenerator::class)->origin(), PHP_URL_HOST);

        // If it starts with a scheme or looks like a full URL
        if (preg_match('#^(https?:)?//#i', $url) || filter_var($url, FILTER_VALIDATE_URL)) {
            $redirectUrl = parse_url($url);
            $redirectHost = $redirectUrl['host'] ?? null;
            if ($redirectHost !== $baseHost) {
                throw new \InvalidArgumentException("تغییر مسیر به دامنه‌های خارجی مجاز نیست");
            }
            return true;
        }

        // 4. Block path traversal or relative tricks (e.g. absolute-path bypasses in relative clothing)
        if (preg_match('#^(https?:)?//#i', ltrim($url, '/\\'))) {
            throw new \InvalidArgumentException('آدرس ریدایرکت نامعتبر است');
        }

        // Safe relative path without leading slash (e.g. "home")
        return true;
    }
    
    /**
     * Redirect
     */
    public function redirect(string $url, int $statusCode = 302): void
    {
        if (!preg_match('#^https?://#i', $url) && function_exists('url')) {
            $url = url($url);
        }
        $this->validateRedirectUrl($url);
        session_write_close();
        
        $this->statusCode = $statusCode;
        $this->setHeader('Location', $url);
        
        $this->send();
    }

    /**
     * Redirect to a trusted external URL.
     * This is used for OAuth provider flows and other explicit external redirects.
     */
    public function redirectExternal(string $url, int $statusCode = 302): void
    {
        // Prevent CRLF injection
        if (preg_match('/[\r\n]/', $url)) {
            throw new \InvalidArgumentException('آدرس ریدایرکت شامل کاراکترهای غیرمجاز است');
        }

        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            throw new \InvalidArgumentException('آدرس ریدایرکت خارجی نامعتبر است');
        }

        $scheme = parse_url($url, PHP_URL_SCHEME);
        if (!in_array(strtolower((string)$scheme), ['http', 'https'], true)) {
            throw new \InvalidArgumentException('آدرس ریدایرکت خارجی باید با http یا https شروع شود');
        }

        session_write_close();
        $this->statusCode = $statusCode;
        $this->setHeader('Location', $url);
        $this->send();
    }
    
    private function validateFilePath(string $filePath): bool
    {
        // ✅ Prevent directory traversal
        if (strpos($filePath, '..') !== false) {
            throw new \InvalidArgumentException("Path traversal نیست مجاز");
        }
        
        // ✅ Get real path
        $realPath = realpath($filePath);
        if ($realPath === false) {
            throw new \InvalidArgumentException("فایل پیدا نشد");
        }
        
        // ✅ Ensure file is within allowed base directories with trailing separator (Issue #25 Fix)
        $paths = app(PathResolver::class);
        $allowedBases = [
            realpath($paths->public('uploads')),
            realpath($paths->storage()),
        ];
        
        $isAllowed = false;
        foreach ($allowedBases as $base) {
            if ($base !== false) {
                $baseDir = rtrim($base, '/\\') . DIRECTORY_SEPARATOR;
                if (str_starts_with($realPath, $baseDir) || $realPath === rtrim($base, '/\\')) {
                    $isAllowed = true;
                    break;
                }
            }
        }
        
        if (!$isAllowed) {
            throw new \InvalidArgumentException("فایل خارج از دایرکتوری مجاز است");
        }
        
        return true;
    }
    
    /**
     * ✅ Validate filename to prevent header injection
     */
    private function validateFileName(string $fileName): string
    {
        // ✅ Remove any path separators
        $fileName = basename($fileName);
        
        // ✅ Prevent CRLF injection
        if (preg_match("/[\r\n]/", $fileName)) {
            throw new \InvalidArgumentException("نام فایل معتبر نیست");
        }
        
        // ✅ Sanitize filename - remove quotes and dangerous characters
        $fileName = str_replace(['"', "'", "\x00"], '', $fileName);
        
        return $fileName;
    }
    
    /**
     * دانلود فایل
     */
    public function download(string $filePath, string $fileName): void
    {
        // FIX-R36-W3 (F-A9b-09): شاخهٔ 404 مرده بود (حمل‌شده R30) — validateFilePath()
        // پیش از file_exists() اجرا می‌شد و برای فایلِ ناموجود realpath()===false →
        // InvalidArgumentException → 500، در حالی که قرارداد 404 بود. ترتیب برعکس شد؛
        // گاردهای traversal/allowlist همچنان پس از وجودِ فایل اجرا و fail-closed می‌مانند.
        if (!file_exists($filePath)) {
            $this->statusCode = 404;
            $this->content = 'فایل پیدا نشد';
            $this->send();
            return;
        }

        // ✅ Validate both path and filename
        $this->validateFilePath($filePath);
        $fileName = $this->validateFileName($fileName);

        // H10 Fix: به جای exit، مسیر دانلود را ست کرده و Response Exception شلیک می‌کنیم
        $this->setHeader('Content-Type', 'application/octet-stream');
        $this->setHeader('Content-Disposition', 'attachment; filename="' . $fileName . '"');
        $this->setHeader('Content-Length', (string)filesize($filePath));
        
        $this->downloadPath = $filePath;
        $this->send();
    }
    
    /**
     * برگشت به صفحه قبل
     */
    public function back(): void
    {
        $generator = app(UrlGenerator::class);
        $referer = $_SERVER['HTTP_REFERER'] ?? $generator->to('/');
        $scheme = parse_url($referer, PHP_URL_SCHEME);
        $host = parse_url($referer, PHP_URL_HOST);
        $port = parse_url($referer, PHP_URL_PORT);
        if (is_string($scheme) && is_string($host)) {
            $refererOrigin = strtolower($scheme . '://' . $host . (is_int($port) ? ':' . $port : ''));
            if (!hash_equals(strtolower($generator->origin()), $refererOrigin)) {
                $referer = $generator->to('/');
            }
        } elseif (!is_string($referer) || !str_starts_with($referer, '/') || str_starts_with($referer, '//')) {
            $referer = $generator->to('/');
        }
        $this->redirect($referer);
    }

    /**
     * ارسال فیزیکی Status Code و هدرهای انباشته شده به کلاینت
     */
    private function sendHeaders(): void
    {
        if (headers_sent()) {
            return;
        }

        // [MED-03] Security Headers: Enforcing best-practice security policies
        if (function_exists('header_remove')) {
            header_remove('X-Powered-By');
        }
        if (!isset($this->headers['X-Frame-Options']) && !isset($this->headers['x-frame-options'])) {
            header('X-Frame-Options: SAMEORIGIN');
        }
        header('X-Content-Type-Options: nosniff');
        header('X-XSS-Protection: 0');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('X-Permitted-Cross-Domain-Policies: none');
        header('Expect-CT: max-age=86400, enforce');
        
        // HIGH-11 Fix: Dynamic Content Security Policy (CSP) with Nonce
        // Permanent Architecture: Single source of truth. If SecurityHeadersMiddleware or
        // a controller already set Content-Security-Policy in $this->headers, do not emit a second CSP header.
        if (!isset($this->headers['Content-Security-Policy']) && !isset($this->headers['content-security-policy'])) {
            try {
                $nonce = $this->request?->nonce() ?? bin2hex(random_bytes(16));
                $envCdn = $_ENV['CSP_CDN_WHITELIST'] ?? getenv('CSP_CDN_WHITELIST') ?: null;
                $configCdn = function_exists('config') ? (array)config('security.csp_cdn_whitelist', []) : [];
                $cdnWhitelist = [];
                if (is_string($envCdn) && trim($envCdn) !== '') {
                    $cdnWhitelist = array_filter(array_map('trim', explode(',', $envCdn)));
                } elseif (!empty($configCdn)) {
                    $cdnWhitelist = array_filter(array_map(
                        static fn(mixed $value): string => is_string($value) ? trim($value) : '',
                        $configCdn
                    ));
                }
                $assetOrigin = app(UrlGenerator::class)->assetOrigin();
                if ($assetOrigin !== app(UrlGenerator::class)->origin()) {
                    $cdnWhitelist[] = $assetOrigin;
                }
                if (empty($cdnWhitelist)) {
                    $cdnWhitelist = [];
                }
                $cdn = implode(' ', array_unique($cdnWhitelist));
                $scriptSrc = trim("'self' 'nonce-{$nonce}' https://www.google.com https://www.gstatic.com {$cdn}");
                $styleSrc = trim("'self' 'unsafe-inline' https://fonts.googleapis.com {$cdn}");
                $fontSrc = trim("'self' https://fonts.gstatic.com {$cdn}");
                $imgSrc = trim("'self' data: https: {$cdn}");
                $connectSrc = trim("'self' {$cdn}");
                header("Content-Security-Policy: default-src 'self'; script-src {$scriptSrc}; style-src {$styleSrc}; font-src {$fontSrc}; img-src {$imgSrc}; frame-src 'self' https://www.google.com; connect-src {$connectSrc};");
            } catch (\Throwable $e) {
                header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:;");
            }
        }
        
        // HSTS (Strict-Transport-Security) only over HTTPS
        // BUGFIX-PHASE1-Y2: مدل اعتماد یکسان با Request::isSecure() — یعنی
        // X-Forwarded-Proto فقط از پروکسی‌های داخل فهرست trusted_proxies
        // پذیرفته می‌شود (قبلاً هدر خام بدون هیچ اعتبارسنجی پذیرفته می‌شد).
        // در دیپلوی docker، nginx خودش هدر HSTS مستقل emits می‌کند؛ پس این
        // تغییر هیچ رگرسیونی برای کاربر نهایی ایجاد نمی‌کند.
        try {
            $isSecure = app(\Core\Request::class)->isSecure();
        } catch (\Throwable $e) {
            // Fallback به رفتار قبلی وقتی Request/کانتینر در دسترس نیست (مثلاً CLI ایزوله)
            $isSecure = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
                        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
        }
        
        if ($isSecure) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
        }

        // اعمال نهایی وضعیت HTTP
        http_response_code($this->statusCode);
        
        // انتشار تمامی هدرهای ساخته شده توسط لایه‌های سیستم
        foreach ($this->headers as $name => $value) {
            header("{$name}: {$value}");
        }
    }

    /**
     * ارسال نهایی فیزیکی به مرورگر (فقط توسط Router صدا زده می‌شود)
     */
    public function sendToBrowser(): void
    {
        $this->sendHeaders();
        
        if ($this->downloadPath && file_exists($this->downloadPath)) {
            // M13 Fix: پیاده‌سازی مکانیزم دانلود امن و کم‌مصرف حافظه (Chunked Memory-Safe Streaming)
            // غیرفعال کردن تمامی بافرهای خروجی فعال جهت آزادسازی رم سرور
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            
            $file = fopen($this->downloadPath, 'rb');
            if ($file !== false) {
                while (!feof($file) && connection_status() === 0) {
                    echo fread($file, 8192); // استریم فایل به صورت تکه‌تکه‌های ۸ کیلوبایتی
                    flush(); // هل دادن فیزیکی داده‌ها به سمت کلاینت و مرورگر
                }
                fclose($file);
            }
        } else {
            // FIX-M1M13 (گزارش ماژول ۱، M13): درخواست HEAD فقط هدر می‌گیرد —
            // بدنه هرگز ارسال نمی‌شود (قرارداد HTTP HEAD؛ رندر GET با side-effect
            // برای HEAD دوباره اجرا شده ولی خروجی‌اش به کلاینت نمی‌رود)
            if (($_SERVER['REQUEST_METHOD'] ?? '') === 'HEAD') {
                return;
            }
            echo $this->content;
        }
    }

    /**
     * H10 Fix: آزادسازی پایپ‌لاین روت‌ها
     * به جای خروج فیزیکی و خاموش شدن پردازش، یک Response Exception پرتاب می‌شود 
     * که توسط لایه Router گرفته شده و به چرخه حیات طبیعی برمی‌گرداند.
     */
    public function send(): void
    {
        throw new \Core\Exceptions\HttpResponseException($this);
    }

    /**
     * نمایش View
     *
     * @param array<string, mixed> $data
     */
    public function view(string $viewName, array $data = []): self
    {
        ob_start();
        view($viewName, $data);
        $content = ob_get_clean();
        $content = $content === false ? '' : $content;
        
        $this->content = $content;
        
        // H10 Fix: شلیک پاسخ استاندارد به جای echo و exit فیزیکی
        $this->send();

        // The normal send path throws HttpResponseException. Returning the
        // instance keeps the contract safe for test doubles and custom
        // response transports that override send().
        return $this;
    }

        /**
     * تنظیم HTTP Status Code
     */
    public function status(int $code): self
    {
        $this->setStatusCode($code);
        return $this;
    }

    /**
     * ارسال Header
     */
    public function header(string $name, string $value): self
    {
        $this->setHeader($name, $value);
        return $this;
    }

    public function getHeader(string $name): ?string
    {
        // BUGFIX-PHASE1-Y3: جستجوی case-insensitive واقعی — قبلاً فقط کلیدِ
        // دقیق یا کلیدِ تمام‌کوچک چک می‌شد؛ هدر ذخیره‌شده با «Content-Type»
        // هرگز با getHeader('content-type') پیدا نمی‌شد.
        $needle = strtolower($name);
        foreach ($this->headers as $key => $value) {
            if (strtolower($key) === $needle) {
                return $value;
            }
        }
        return null;
    }
}
