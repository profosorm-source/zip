<?php

namespace Core;

/**
 * Generic Event (برای رویدادهای ساده)
 *
 * قابل استفاده در هر جایی که نیاز به Event سریع بدون ساخت کلاس اختصاصی دارید.
 * DomainEvent interface رو implement می‌کنه تا با recordEvent سازگار باشه.
 *
 * PSR-4 autoload: Core\GenericEvent → core/GenericEvent.php
 */
class GenericEvent extends Event implements \App\Contracts\VersionedDomainEvent
{
    public function aggregateType(): string
    {
        $agg = $this->getData('aggregate_type');
        if (is_string($agg) && $agg !== '') return $agg;
        $evt = $this->getData('event_name');
        if (is_string($evt) && $evt !== '') return $evt;
        return 'general';
    }

    public function aggregateId(): string
    {
        $data = (array)$this->getData();
        foreach (['user_id', 'userId', 'id', 'aggregate_id'] as $key) {
            if (isset($data[$key])) {
                // FIX-S9-1: str_value بدون default با مقدار غیراسکالر «رشتهٔ خالی»
                // برمی‌گرداند — نقض قرارداد مستند متد (fallback «0»)؛ شناسهٔ
                // aggregate تهی در audit-trail ثبت می‌شد. اکنون مثل شاخهٔ
                // هیچ-کلیدی، «0» برمی‌گردد.
                return str_value($data[$key], '0');
            }
        }
        return '0';
    }

    public function toPayload(): array
    {
        return (array) $this->getData();
    }

    /**
     * FIX-C65 (یافتهٔ ۶۵): هویت رویداد — شناسهٔ یکتا با fallback دترمینستیک؛
     * اگر caller صریحاً event_id نگذاشته باشد، از hash محتوا ساخته می‌شود تا
     * ردیابی/کاوشِ outbox برای رویدادهای عمومی هم ممکن باشد.
     */
    public function eventId(): string
    {
        $id = $this->getData('event_id');
        if (is_string($id) && $id !== '') return $id;
        if (is_int($id) || is_float($id)) return (string)$id;
        $evt = $this->getData('event_name');
        $agg = $this->aggregateId();
        $base = is_string($evt) && $evt !== '' ? $evt : $this->aggregateType();
        return substr(md5($base . ':' . $agg . ':' . json_encode($this->toPayload())), 0, 32);
    }

    public function occurredAt(): string
    {
        $at = $this->getData('occurred_at');
        if (is_string($at) && $at !== '') return $at;
        return date('Y-m-d H:i:s');
    }

    public function actorId(): ?int
    {
        $actor = $this->getData('actor_id') ?? $this->getData('user_id');
        if ($actor === null) return null;
        return is_numeric($actor) ? max(0, (int)$actor) : null;
    }

    public function eventVersion(): int
    {
        $version = $this->getData('event_version');
        return is_numeric($version) ? max(1, (int)$version) : 1;
    }
}
