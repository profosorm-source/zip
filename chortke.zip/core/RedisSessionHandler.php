<?php

declare(strict_types=1);
namespace Core;

/**
 * Redis Session Handler
 * 
 * مدیریت Session با Redis + Fallback به File
 * خودکار بین Redis و فایل سوئیچ می‌کند
 */
class RedisSessionHandler implements \SessionHandlerInterface
{
    private ?\Redis $redis = null;
    private static bool $hasFailed = false; // H13 Fix: جلوگیری از تلاش مجدد در طول کل حیات این پروسس (مخصوصاً در CLI)
    private string $prefix = 'chortke:session:';
    private int $ttl = 7200; // 2 hours default — overridden from config in __construct
    private bool $slidingTtl = true; // 🛡️ FIX P2: refresh TTL on every successful read (active users stay logged in)
    private string $savePath = '';

    // ─── FIX-X15 (Task 13): قفل per-session ───
    // هندلر Redis برخلاف فایلِ پیش‌فرض PHP هیچ قفل session-level نداشت؛ در سرورهای
    // موازی (FPM/nginx/workers) دو درخواست هم‌سشن می‌توانستند اسنپ‌شات‌های قدیمی را
    // روی هم بازنویسی کنند یا بعد از session_regenerate_id(true) سشنِ سمت کلاینت
    // حذف‌شده را «خالی» بخوانند → نوشتن اسکلت خالی → ۴۱۹ CSRF + پرت‌شدن لاگین
    // (الگوی بازتولیدشدهٔ X8). قفل با SET NX + TTL کوتاه و fail-open ایمن است.
    private const LOCK_TTL = 15;          // ثانیه — آزادسازی خودکار در مرگ پروسس
    private const LOCK_WAIT_MS = 4000;    // حداکثر انتظار برای به‌دست‌آوردن قفل
    private const LOCK_POLL_US = 50000;   // گام polling (۵۰ms)
    private string $lockKey = '';
    private string $lockToken = '';       // 🔒 AUDIT-FIX (R4): توکن تصادفیِ یکتا برای هر acquisition
    private bool $lockAcquired = false;
    /** 🔒 AUDIT-FIX (R4): fallback اشتراکی/فایل در production فقط با پیکربندی صریح */
    private bool $failClosedFallback = false;

    public function __construct(
        ?Cache $cache = null,
        ?string $sessionDriver = null,
        ?PathResolver $paths = null
    ) {
        $basePath = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__);
        $this->savePath = ($paths ?? new PathResolver($basePath))->storage('sessions');
        $sessionDriver ??= config('session.driver', 'redis');
        if (!is_string($sessionDriver) || !in_array($sessionDriver, ['redis', 'file'], true)) {
            throw new \InvalidArgumentException("Session driver must be either 'redis' or 'file'.");
        }

        // 🔒 S7-FIX (S7-F01): حالتِ fallback باید «قبل از» تلاش اتصال تعیین شود؛
        // قبلاً بعد از tryConnectRedis محاسبه می‌شد و مسیرِ null اولیه هرگز
        // fail-closed را نمی‌دید (تا بی‌صدا فایلِ محلیِ هر نود را می‌خواند).
        $fallbackMode = strtolower(str_value(config('session.fallback', 'file')));
        $this->failClosedFallback = in_array($fallbackMode, ['none', 'off', 'disabled', 'false'], true);

        $this->tryConnectRedis($cache ?? Cache::getInstance(), $sessionDriver);

        $rawTtl = config('session.lifetime', 7200);
        if (is_int($rawTtl)) {
            $ttl = $rawTtl;
        } elseif (is_string($rawTtl) && ctype_digit($rawTtl)) {
            $ttl = (int)$rawTtl;
        } else {
            throw new \InvalidArgumentException('Session lifetime must be a positive integer number of seconds.');
        }
        if ($ttl < 1 || $ttl > 31_536_000) {
            throw new \InvalidArgumentException('Session lifetime must be between 1 and 31536000 seconds.');
        }
        $this->ttl = $ttl;

        // 🛡️ FIX P2: sliding TTL keeps active sessions alive; idle sessions expire after TTL.
        // Disable via SESSION_SLIDING_TTL=false for stricter security policies (e.g. admin sessions).
        $this->slidingTtl = filter_var(
            env('SESSION_SLIDING_TTL', config('session.sliding_ttl', true)),
            FILTER_VALIDATE_BOOLEAN
        );

        // 🔒 AUDIT-FIX (R4-LOW/OPS): (متن تاریخی) در deployment چندنودی، fallback خودکار به فایل
        // state نشست را بین نودها جدا می‌کند (revocation/تغییرات ناسازگار). با
        // session.fallback=none حالت fail-closed فعال می‌شود: خطای Redis به‌جای
        // downgrade بی‌صدا، شکست صریح عملیات سشن است.
        // (محاسبهٔ failClosedFallback به پیش از tryConnectRedis منتقل شد — S7-F01)
    }

    private function tryConnectRedis(Cache $cache, string $sessionDriver): void
    {
        // S7-FIX (S7-F01): با fallback=none، پرشِ H13 یعنی backend در دسترس نیست —
        // بی‌صدا فایلِ محلی ممنوع؛ fail-closed صریح (تست S7-T01).
        if (self::$hasFailed) {
            if ($this->failClosedFallback) {
                throw new \RuntimeException(
                    'Redis session store unavailable (previous failure) and file fallback is disabled (session.fallback=none).'
                );
            }
            return;
        }

        if ($sessionDriver !== 'redis') {
            // File sessions are an intentional configured mode, not an operational event.
            return;
        }

        $redis = $cache->redis();
        if ($redis !== null) {
            try {
                $redis->ping();
                $this->redis = $redis;

                // A successful normal connection is deliberately not logged per request/process.
            } catch (\Throwable $e) {
                self::$hasFailed = true;
                    if (function_exists('logger')) {
                    try {
                        logger()->critical('Session handler: Redis connection failed on production. Falling back to file-based sessions to prevent complete system outage.', ['error' => $e->getMessage()]);
                    } catch (\Throwable $ignore) {}
                }
                // 🔒 S7-FIX (S7-F01): شکست ping با fallback=none = خطای صریح، نه سقوط بی‌صدای فایل
                if ($this->failClosedFallback) {
                    throw new \RuntimeException(
                        'Redis session store unavailable and file fallback is disabled (session.fallback=none).',
                        0,
                        $e
                    );
                }
                }
        } else {
            $this->redis = null;

            // 🔒 S7-FIX (S7-F01): null اولیه (کشِ غیرِRedis/نبود اکستنشن/چندنودی) با
            // session.driver=redis یعنی storeِ اعلام‌شده در دسترس نیست؛ با fallback=none
            // fail-closed صریح — وضعیت ورود/خروج/pending-2FA دیگر بین نودها واگرا نمی‌شود.
            if ($this->failClosedFallback) {
                throw new \RuntimeException(
                    'Redis session store unavailable (cache redis handler is null) and file fallback is disabled (session.fallback=none).'
                );
            }

            // Cache driver fallback is normal in non-Redis environments; only failures log critically.
        }
    }

    public function open(string $path, string $name): bool
    {
        if ($this->redis === null) {
            if (!is_dir($this->savePath)) {
                // L-18 Fix: مجوز محدود 0700 به‌جای 0755 (فقط مالک) برای پوشهٔ session
                mkdir($this->savePath, 0700, true);
            }
        }
        return true;
    }

    public function close(): bool
    {
        // FIX-X15: اطمینان از آزادشدن قفل در پایان هر چرخهٔ سشن
        if ($this->redis !== null) {
            $this->releaseLock();
        }
        return true;
    }

    public function read(string $id): string|false
    {
        if (!$this->isValidSessionId($id)) {
            return '';
        }
        if ($this->redis !== null) {
            try {
                // FIX-X15: تا نوشتنِ درخواستِ قبلیِ همان سشن تمام نشده، صبر کن
                $this->acquireLock($id);
                $key = $this->prefix . $id;
                $data = $this->redis->get($key);

                // 🛡️ FIX P2 (Sliding TTL): اگر session فعال است، TTL را refresh کن
                // این کار باعث می‌شود کاربران فعال logout نشوند ولی sessionهای idle منقضی شوند
                // فقط در صورت فعال بودن SESSION_SLIDING_TTL اعمال می‌شود
                // L-18 Fix: سقف مطلق عمر session؛ TTL لغزان فقط تا وقتی نشانگر created موجود
                // است refresh می‌شود تا session فعال هم بی‌نهایت زنده نماند.
                if ($this->slidingTtl && $data !== false) {
                    // FIX-P4-11: گیت نشانگر created فقط وقتی معنا دارد که سقف مطلق
                    // (session.absolute_lifetime) فعال باشد. با absolute_lifetime=0
                    // (یعنی «سقف مطلق غیرفعال») نشانگر هرگز ساخته نمی‌شد و به‌دنبالش
                    // TTL لغزان هم هرگز refresh نمی‌شد — یعنی معنای کانفیگ وارونه
                    // بود و کاربرانِ فعال بعد از ttl ثانیه بی‌فعالیتی از نوشتنِ آخر
                    // بیرون می‌افتادند. اکنون با غیرفعال‌بودنِ سقف، refresh لغزان
                    // بدون گیت انجام می‌شود (رفتارِ مفهوم «بدون سقف مطلق»).
                    $withinAbsolute = true;
                    $absoluteMax = int_value(config('session.absolute_lifetime', 86400));
                    if ($absoluteMax > 0) {
                        try {
                            $withinAbsolute = (bool) $this->redis->exists($key . ':created');
                        } catch (\Throwable $absEx) {
                            $withinAbsolute = true; // در تردید، رفتار قبلی حفظ می‌شود
                        }
                        // 🔒 AUDIT-FIX (R4-HIGH absolute lifetime): نبودنِ نشانگر created
                        // برای «کلید نشست موجود» یعنی سقف عمر مطلق تمام شده — قبلاً فقط
                        // refresh لغزان متوقف می‌شد ولی خودِ داده زنده می‌ماند و write
                        // بعدی نشانگر را از نو می‌ساخت (دور زدن سقف). اکنون نشستِ متجاوز
                        // صریحاً منقضی و حذف می‌شود.
                        if ($data !== false && !$withinAbsolute) {
                            try {
                                $this->redis->del($key);
                            } catch (\Throwable $delEx) {
                            }
                            return '';
                        }
                    }
                    if ($withinAbsolute) {
                        try {
                            $this->redis->expire($key, $this->ttl);
                        } catch (\Throwable $ttlEx) {
                            // TTL refresh failure should not break session read
                        }
                    }
                }

                return ($data === false) ? '' : str_value($data);
            } catch (\Throwable $e) {
                $this->fallbackToFile($e);
                return $this->fileRead($id);
            }
        }

        return $this->fileRead($id);
    }

    public function write(string $id, string $data): bool
    {
        if (!$this->isValidSessionId($id)) {
            return false;
        }
        if ($this->redis !== null) {
            try {
                // 🔒 S7-FIX (S7-F05): fencing دو لایه برای نوشتن — فقط در SAPI وب
                // (رقابتِ درخواست‌های هم‌زمان؛ CLI/worker طبق FIX-X15 با سشن وب
                // تداخل ندارند و قفل نمی‌گیرند — در CLI هر دو گارد معنا نمی‌یابند):
                // (۱) tombstone: نشستِ destroy‌شده (logout/terminate/regenerate) هرگز
                //     با snapshot قدیمی زنده نمی‌شود؛
                // (۲) الزامِ قفل: snapshotِ خوانده‌شده بدون قفل (timeout/خطای backend)
                //     قابل نوشتن نیست — نوشتنِ بدون قفل یعنی احتمالِ overwriteِ حالتِ
                //     جدید با snapshot قدیمی (باززنده‌سازی revoked/2FA).
                if (PHP_SAPI !== 'cli') {
                    $tombKey = $this->prefix . 'tomb:' . $id;
                    $tombstoned = false;
                    try {
                        $tombstoned = (bool) $this->redis->exists($tombKey);
                    } catch (\Throwable $tombProbeEx) {
                        // در تردیدِ بررسیِ tombstone، ادامه با مسیرِ قفلِ سخت‌گیرانه
                    }
                    if ($tombstoned) {
                        if (function_exists('logger')) {
                            try {
                                logger()->warning('session.write_denied_tombstone', ['session_id_masked' => substr($id, 0, 4) . '***']);
                            } catch (\Throwable $ignore) {}
                        }
                        $this->releaseLock();
                        return false; // نوشتنِ رد‌شده — نشست باید مرده بماند
                    }

                    if (!$this->lockAcquired) {
                        // قفل از فاز read نزد ما نیست (timeout/خطا) — تلاشِ کوتاهِ مجدد؛
                        // شکست = ردِ نوشتن (fail-closed امن‌تر از overwriteِ رقابتی)
                        $this->acquireLock($id, 500);
                        if (!$this->lockAcquired) {
                            if (function_exists('logger')) {
                                try {
                                    logger()->warning('session.write_denied_lock_timeout', ['session_id_masked' => substr($id, 0, 4) . '***']);
                                } catch (\Throwable $ignore) {}
                            }
                            return false;
                        }
                    }
                }

                // L-18 Fix: نشانگر created را یک‌بار (NX) با TTL برابر سقف مطلق عمر session ثبت می‌کنیم.
                // وقتی این نشانگر منقضی شود، TTL لغزان دیگر refresh نمی‌شود و session نهایتاً منقضی می‌گردد.
                //
                // 🔒 AUDIT-FIX (R4-HIGH absolute lifetime): نشانگر فقط برای «چرخهٔ جدید»
                // ساخته می‌شود؛ اگر دادهٔ نشست هنوز موجود است ولی نشانگر منقضی شده،
                // سقف مطلق تمام است: داده حذف و نوشتن رد می‌شود — بازسازی نشانگر
                // دیگر نمی‌تواند عمر نشستِ فعال را بی‌نهایت تمدید کند.
                $sessionKey = $this->prefix . $id;
                $absoluteMax = int_value(config('session.absolute_lifetime', 86400));
                if ($absoluteMax > 0) {
                    try {
                        $markerExists = (bool) $this->redis->exists($sessionKey . ':created');
                        $sessionExists = (bool) $this->redis->exists($sessionKey);
                        if (!$markerExists && $sessionExists) {
                            // سقف عمر مطلق گذشته و نشست هنوز زنده است → منقضی کن
                            try {
                                $this->redis->del($sessionKey);
                            } catch (\Throwable $delEx) {
                            }
                            if (function_exists('logger')) {
                                try {
                                    logger()->info('session.absolute_lifetime_exceeded_discarded', ['session_id_masked' => substr($id, 0, 4) . '***']);
                                } catch (\Throwable $ignore) {}
                            }
                            $this->releaseLock();
                            return true; // نوشتنِ عمداً دور ریخته‌شده — چرخهٔ سشن به پایان رسیده
                        }
                        if (!$markerExists && !$sessionExists) {
                            $this->redis->set($sessionKey . ':created', (string)time(), ['NX', 'EX' => $absoluteMax]);
                        }
                    } catch (\Throwable $createdEx) {
                        // ثبت نشانگر created حیاتی نیست
                    }
                }
                $ok = (bool) $this->redis->setEx(
                    $this->prefix . $id,
                    $this->ttl,
                    $data
                );
                // FIX-X15: پس از پایدارشدن داده، قفل را آزاد کن
                $this->releaseLock();
                return $ok;
            } catch (\Throwable $e) {
                $this->releaseLock();
                $this->fallbackToFile($e);
                return $this->fileWrite($id, $data);
            }
        }

        return $this->fileWrite($id, $data);
    }

    public function destroy(string $id): bool
    {
        if (!$this->isValidSessionId($id)) {
            return false;
        }
        if ($this->redis !== null) {
            try {
                // FIX-C07: destroy هم همان قفلِ per-session read/write را می‌گیرد.
                // قبلاً حذف کلیدها بدون قفل انجام می‌شد؛ logout-all/terminate می‌توانست
                // payload را بین read و write یک درخواستِ فعال حذف کند و همان درخواست
                // اسنپ‌شاتِ قدیمی را برگرداند (resurrect سشنِ revoked تا سقف عمرش).
                $this->acquireLock($id);
                $this->redis->del($this->prefix . $id);
                $this->redis->del($this->prefix . $id . ':created');
                // 🔒 S7-FIX (S7-F05): tombstone نسل‌بندی — هر writer قدیمیِ بی‌قفل
                // که بعد از destroy بیدار شود، با گاردِ write_denied_tombstone رد
                // می‌شود (باززنده‌سازیِ payload auth قدیمی ممنوع). TTL = عمر نشست؛
                // حافظه محدود و خودپاک‌شونده می‌ماند.
                try {
                    $this->redis->set($this->prefix . 'tomb:' . $id, (string) time(), ['EX' => $this->ttl]);
                } catch (\Throwable $tombEx) {
                    // شکستِ tombstone به معنای بازگشت به رفتارِ قبلیِ destroy است؛
                    // قفلِ همین لحظه هنوز پنجرهٔ رقابت را می‌بندد.
                }
                // FIX-X15: اگر قفل همین سشن نزد ماست، آزادش کن (regenerate/destroy)
                $this->releaseLock();
                return true;
            } catch (\Throwable $e) {
                $this->releaseLock();
                $this->fallbackToFile($e);
                return $this->fileDestroy($id);
            }
        }

        return $this->fileDestroy($id);
    }

    /**
     * FIX-X15: به‌دست‌آوردن قفل کوتاه‌مدت روی سشن پیش از خواندن.
     * در CLI قفل نمی‌گیریم (_migration/worker با سشن وب تداخل ندارند)؛
     * در نبود قفل پس از LOCK_WAIT_MS با fail-open ادامه می‌دهیم تا هرگز
     * درخواستی هنگ نکند — فقط رقابت مجدد ممکن می‌شود نه بن‌بست.
     */
    private function acquireLock(string $id, int $waitMs = self::LOCK_WAIT_MS): void
    {
        if (PHP_SAPI === 'cli' || $this->lockAcquired) {
            return;
        }
        $key = $this->prefix . 'lock:' . $id;
        $deadline = (int) (microtime(true) * 1000) + $waitMs;
        do {
            try {
                // 🔒 AUDIT-FIX (R4-MEDIUM): توکن هر acquisition تصادفیِ یکتاست.
                // قبلاً مقدار قفل getmypid() بود؛ در multi-process/multi-container
                // PIDها تکرار می‌شوند و پس از انقضای قفل، یک process قدیمی می‌توانست
                // قفل process دیگر را آزاد کند (release بر اساس مقایسهٔ PID).
                $token = bin2hex(random_bytes(16));
                $ok = $this->redis->set($key, $token, ['NX', 'EX' => self::LOCK_TTL]);
                if ($ok) {
                    $this->lockKey = $key;
                    $this->lockToken = $token;
                    $this->lockAcquired = true;
                    return;
                }
            } catch (\Throwable $e) {
                return; // خطای ردیس → رفتار قبلی (بدون قفل)
            }
            usleep(self::LOCK_POLL_US);
        } while ((int) (microtime(true) * 1000) < $deadline);
        // fail-open: قفل گیر نیامد؛ بدون قفل ادامه بده (log سطح debug)
    }

    /** FIX-X15: آزادسازی امن قفل — فقط اگر نزد ماست */
    private function releaseLock(): void
    {
        if (!$this->lockAcquired || $this->lockKey === '') {
            return;
        }
        // FIX-P4S-7: $redis می‌تواند در مسیر handleRedisFailure (خط ۹۶/۳۶۲) null
        // شده باشد — بدون این گارد، get() روی null پرتاب Error می‌کرد که فقط به
        // لطف catch(\Throwable) بی‌اثر می‌ماند. گارد صریح = همان fail-open، بدون
        // exception-as-control-flow؛ TTL خودش قفل را می‌ترکاند.
        if ($this->redis === null) {
            $this->lockAcquired = false;
            $this->lockKey = '';
            $this->lockToken = '';
            return;
        }
        try {
            // 🔒 AUDIT-FIX (R4-MEDIUM): آزادسازی اتمیک با اسکریپت Lua و توکن تصادفی
            // (compare-and-delete) — جایگزین الگوی non-atomic get+del مبتنی بر PID.
            // فقط دارندهٔ توکنِ همان acquisition قفل را می‌ترکاند؛ release قدیمی‌ها
            // هرگز قفل دارندهٔ فعلی را نمی‌شکند.
            if ($this->lockToken !== '') {
                $client = method_exists($this->redis, 'getClient') ? $this->redis->getClient() : null;
                if ($client instanceof \Redis) {
                    $client->eval(
                        'if redis.call("get", KEYS[1]) == ARGV[1] then return redis.call("del", KEYS[1]) else return 0 end',
                        [$this->lockKey, $this->lockToken],
                        1
                    );
                } else {
                    // fallback legacy (کلاینت غیر Redis): رفتار قبلی
                    $owner = $this->redis->get($this->lockKey);
                    if (is_string($owner) && $owner === $this->lockToken) {
                        $this->redis->del($this->lockKey);
                    }
                }
            }
        } catch (\Throwable $e) {
            // TTL خودش قفل را می‌ترکاند
        }
        $this->lockAcquired = false;
        $this->lockKey = '';
        $this->lockToken = '';
    }

    public function gc(int $max_lifetime): int|false
    {
        if ($this->redis !== null) {
            // Redis automatically handles TTL
            return 0;
        }

        return $this->fileGc($max_lifetime);
    }

    // ─────────────────────────────────────────────────
    //  File Fallback Methods
    // ─────────────────────────────────────────────────

    private function fileRead(string $id): string
    {
        $file = $this->getFilePath($id);
        if (!file_exists($file)) {
            return '';
        }

        $data = @file_get_contents($file);
        if ($data === false) {
            return '';
        }

        return $data;
    }

    private function fileWrite(string $id, string $data): bool
    {
        $file = $this->getFilePath($id);
        return file_put_contents($file, $data, LOCK_EX) !== false;
    }

    private function fileDestroy(string $id): bool
    {
        $file = $this->getFilePath($id);
        if (file_exists($file)) {
            return @unlink($file);
        }
        return true;
    }

    private function fileGc(int $max_lifetime): int
    {
        $files = glob($this->savePath . '/sess_*') ?: [];
        $now = time();
        $deleted = 0;

        foreach ($files as $file) {
            if (is_file($file) && ($now - filemtime($file) > $max_lifetime)) {
                if (@unlink($file)) {
                    $deleted++;
                }
            }
        }

        return $deleted;
    }

    private function getFilePath(string $id): string
    {
        // L-18 Fix: اعتبارسنجی سخت‌گیرانهٔ شناسهٔ session برای جلوگیری از path traversal
        if (!$this->isValidSessionId($id)) {
            throw new \InvalidArgumentException('Invalid session id');
        }
        return $this->savePath . '/sess_' . $id;
    }

    /**
     * L-18 Fix: فقط شناسه‌های session با الگوی مجاز پذیرفته می‌شوند (دفاع در برابر
     * path traversal در مسیر فایل و آلودگی کلید در Redis).
     */
    private function isValidSessionId(string $id): bool
    {
        return $id !== '' && preg_match('/^[A-Za-z0-9,\-]{1,128}$/', $id) === 1;
    }

    private function fallbackToFile(\Throwable $e): void
    {
        self::$hasFailed = true; // ثبت وضعیت خرابی سیستمی برای بقیه درخواست یا لوپ

        if ($this->redis !== null) {
            // 🔒 AUDIT-FIX (R4-LOW/OPS): با session.fallback=none حالت fail-closed:
            // در deployment چندنودی downgrade بی‌صدای Redis→File، state نشست را بین
            // نودها جدا می‌کند (revocation/تغییرات ناسازگار می‌شوند). عملیات صریحاً
            // شکست می‌خورد تا قرارداد recovery مشخص بماند.
            if ($this->failClosedFallback) {
                throw new \RuntimeException(
                    'Redis session store unavailable and file fallback is disabled (session.fallback=none).',
                    0,
                    $e
                );
            }
            $this->redis = null;

            if (function_exists('logger')) {
                try {
                    logger()->critical('Redis session store connection was lost. Downgrading to file session handler in production to maintain availability.', [
                        'channel' => 'session',
                        'error' => $e->getMessage()
                    ]);
                } catch (\Throwable $ignore) {}
            }

            // Initialize file path securely with strict permissions in production
            if (!is_dir($this->savePath)) {
                mkdir($this->savePath, 0700, true);
            }
        }
    }

    /**
     * Get current driver
     */
    public function driver(): string
    {
        return $this->redis !== null ? 'redis' : 'file';
    }
}
