<?php

declare(strict_types=1);
namespace Core;

/**
 * Cache System — Redis + File Fallback
 *
 * اگر Redis موجود باشد، از آن استفاده می‌کند؛
 * در غیر این صورت به‌صورت خودکار به کش فایلی
 * (همان رفتار قدیمی) سوئیچ می‌کند.
 *
 * 📏 قرارداد واحد TTL (FIX-8a — ۲۰۲۶-۰۹):
 *   - put()/set()/setMinutes()/putMinutes()/remember() → «دقیقه» (API تاریخی)
 *   - setSeconds()/putSeconds()/rememberSeconds()/writeValue() → «ثانیه»ی «دقیق»
 *     (FIX-8a: TTL زیردقیقه‌ای دیگر به ۶۰ ثانیه گرد نمی‌شود؛ هر دو درایور از
 *     TTL ثانیه‌ای پشتیبانی می‌کنند — Redis setEx بومی ثانیه است و درایور فایل
 *     expire_at=timestamp ذخیره می‌کند.)
 *   - increment()/decrement() → TTL آرگومان سوم «ثانیه» است؛ خروجی int یا false
 *     (false = شکست مخزن — مصرف‌کننده‌های fail-closed مثل سقف کمیسیون به آن تکیه دارند)
 *
 * متدها:
 *   put($key, $value, $minutes)
 *   get($key, $default)
 *   has($key)
 *   forget($key)
 *   flush()
 *   remember($key, $minutes, callable)
 *   rememberSeconds($key, $seconds, callable)   → دقیق بر حسب ثانیه
 *   rememberForever($key, callable)
 *   forever($key, $value)
 *   increment($key, $step, $ttlSeconds)
 *   decrement($key, $step, $ttlSeconds)
 *   ttl($key)             → ثانیه‌های باقی‌مانده
 *   tags(array $tags)     → TaggedCache
 *   cleanup()             → فقط در حالت فایل
 *   driver()              → 'redis' | 'file'
 */
class Cache
{
    private ?\Redis $redis = null;
    private string $redisPrefix = 'chortke:';

    private string $cacheDir;
    private string $tagCacheDir;
    /** @var array<string, resource> */
    private array $fileLocks = [];
    /** @var array<string, string> */
    private array $redisLocks = [];

    private static ?self $instance = null;

    // ─────────────────────────────────────────────────
    //  Bootstrap
    // ─────────────────────────────────────────────────

    public function __construct(
        ?\Redis $redis = null,
        ?string $fileCacheDirectory = null,
        ?PathResolver $paths = null
    ) {
        $this->cacheDir = $fileCacheDirectory
            ?? ($paths !== null ? $paths->storage('cache/app') : (__DIR__ . '/../storage/cache/app'));
        // BUGFIX-PHASE3-P13: PathResolver::resolveWithin رشته را بدون trailing slash
        // برمی‌گرداند (PathResolver.php:54) ⇒ cacheFile/glob فایل‌ها را به‌صورت
        // cache/app<md5>.cache (مستقیم در cache/) می‌نوشتند و قفل‌ها در cache/applocks/
        // ساخته می‌شدند (فانکشنال ولی چیدمان غلط). یک‌بار در سازنده نرمالایز می‌شود تا
        // همهٔ الحاق‌ها (cacheFile، glob، locks) همیشه صحیح باشند. TaggedCache خودش
        // در tagIndexFile نرمالایز می‌کند و تأثیر نمی‌پذیرد.
        $this->cacheDir = rtrim($this->cacheDir, '/\\') . DIRECTORY_SEPARATOR;
        $this->tagCacheDir = $paths !== null
            ? rtrim($paths->storage('cache/tags'), '/\\') . DIRECTORY_SEPARATOR
            : rtrim($this->cacheDir, '/\\') . DIRECTORY_SEPARATOR . 'tags';

        if (!is_dir($this->cacheDir) && !mkdir($this->cacheDir, 0755, true) && !is_dir($this->cacheDir)) {
            throw new \RuntimeException("Unable to create cache directory: {$this->cacheDir}");
        }

        if ($redis !== null) {
            $this->redis = $redis;
            return;
        }

        // An explicit file directory is an explicit file-backed composition.
        // The default composition discovers Redis from canonical configuration.
        if ($fileCacheDirectory === null) {
            $this->tryConnectRedis();
        }
    }

    public static function getInstance(): self
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        try {
            $resolved = \Core\Container::getInstance()->make(self::class);
            if (!$resolved instanceof self) {
                throw new \RuntimeException('Container returned invalid Cache instance.');
            }
            self::$instance = $resolved;
            return $resolved;
        } catch (\Throwable $e) {
            // Fallback: if Container not ready, create directly.
            $instance = new self();
            self::$instance = $instance;
            return $instance;
        }
    }

    public function __destruct() {
        $this->flushAllLocks();
    }

    /** نوع درایور فعال: 'redis' یا 'file' */
    /** @return 'redis'|'file' */
    public function driver(): string
    {
        return $this->redis !== null ? 'redis' : 'file';
    }

    /**
     * @param string|false|null $raw
     * @param array<string> $allowedClasses
     * @return mixed
     */
    public function safeUnserialize(string|false|null $raw, array $allowedClasses = [\stdClass::class]): mixed
    {
        if ($raw === null || $raw === false) {
            return null;
        }

        // JSON first (recommended) - preserves type correctly
        $decoded = json_decode($raw, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $decoded;
        }

        // Legacy serialized payloads: allow specified classes (e.g. stdClass)
        $allowed = empty($allowedClasses) ? [\stdClass::class] : $allowedClasses;
        $value = @unserialize($raw, ['allowed_classes' => $allowed]);

        // distinguish unserialize failure from valid serialized false ("b:0;")
        if ($value === false && $raw !== 'b:0;') {
            return null;
        }

        return $value;
    }
    // ─────────────────────────────────────────────────
    //  اتصال Redis
    // ─────────────────────────────────────────────────

    private function tryConnectRedis(): void
    {
        if (!extension_loaded('redis')) {
            return;
        }

        $rawConfig = config('redis');
        $config = is_array($rawConfig) ? $rawConfig : [];

        $enabled = $config['enabled'] ?? true;
        if (!$enabled || in_array(strtolower((string)$enabled), ['false', '0', 'no', 'off'], true)) {
            return;
        }

        $rawHost = $config['host'] ?? '127.0.0.1';
        $rawPort = $config['port'] ?? 6379;
        $rawPassword = $config['password'] ?? '';
        $rawDb = $config['db'] ?? 0;
        $rawTimeout = $config['timeout'] ?? 1.5;

        $host = is_string($rawHost) && $rawHost !== '' ? $rawHost : '127.0.0.1';
        $port = is_int($rawPort) || (is_string($rawPort) && ctype_digit($rawPort)) ? (int)$rawPort : 6379;
        $password = is_string($rawPassword) ? $rawPassword : '';
        $db = is_int($rawDb) || (is_string($rawDb) && ctype_digit($rawDb)) ? (int)$rawDb : 0;
        $timeout = is_int($rawTimeout) || is_float($rawTimeout) || (is_string($rawTimeout) && is_numeric($rawTimeout))
            ? (float)$rawTimeout
            : 1.5;
        $this->redisPrefix = ($config['prefix'] ?? 'chortke') . ':';

        // 🛡️ FIX P1 (Distributed Cache Safety): حالت require_redis
        // وقتی CACHE_REQUIRE_REDIS=true تنظیم شود، در صورت عدم موفقیت اتصال به Redis
        // یک exception پرتاب می‌شود به جای silent fallback به فایل.
        // این تنظیم برای production توصیه می‌شود زیرا file fallback در سیستم‌های
        // distributed (multi-instance) باعث cache divergence می‌شود.
        //
        // 📌 M2-Op1(b) — پیامد rate-limit در استقرار چندنودی: در حالت file fallback
        // هر node شمارندهٔ مستقل خودش را دارد (increment/ttl روی فایل محلی node)؛
        // بنابراین سهمیهٔ RateLimitMiddleware به «به ازای هر node» می‌شود و هدرهای
        // X-RateLimit-* / Retry-After از دید کلاینت ناسازگار گزارش می‌شوند.
        // قرارداد این پروژه: استقرار چندنودی فقط با Redis-required (fail-loud).
        // production به‌صورت پیش‌فرض fail-loud است (زیر) و CORE-038 در increment()
        // شمارنده‌های اتمیک بدون Redis را در production مسدود می‌کند — لایهٔ دوم
        // همین گارد. file fallback فقط برای تک‌نود / dev / test مجاز است.
        $requireRedis = filter_var(
            env('CACHE_REQUIRE_REDIS', config('cache.require_redis', false)),
            FILTER_VALIDATE_BOOLEAN
        );
        $isProduction = (config('app.env', 'production') === 'production');

        try {
            $r = new \Redis();
            if (!$r->connect($host, $port, $timeout, null, 0, $timeout)) {
                $this->handleRedisFailure(
                    "Cannot connect to Redis at {$host}:{$port}",
                    $requireRedis,
                    $isProduction
                );
                return;
            }
            $r->setOption(\Redis::OPT_READ_TIMEOUT, $timeout);

            if ($password !== '') {
                $r->auth($password);
            }

            $r->select($db);
            $r->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
            $r->ping(); // تست واقعی اتصال

            $this->redis  = $r;
        } catch (\Throwable $e) {
            $this->handleRedisFailure(
                $e->getMessage(),
                $requireRedis,
                $isProduction
            );
        }
    }

    /**
     * 🛡️ FIX P1: رسیدگی متمرکز به خطای Redis
     * - در حالت require_redis=true یا production: exception پرتاب می‌شود
     * - در غیر این صورت: silent fallback به file (رفتار قبلی برای backward compatibility)
     */
    private function handleRedisFailure(string $error, bool $requireRedis, bool $isProduction): void
    {
        $this->redis  = null;

        // لاگ کنیم حتی در حالت silent fallback
        // FIX-TEST: در PHPUnit این لاگ critical از طریق LogService به stdout echo
        // می‌شود و خروجی تست‌ها را آلوده/risky می‌کند؛ fallback در محیط تست رویداد
        // عادی و انتظارشدهٔ فایل‌محور است — زیر PHPUnit لاگ نمی‌شود.
        if (function_exists('logger') && !defined('PHPUNIT_RUNNING')) {
            try {
                logger()->critical('cache.redis.fallback_to_file', [
                    'error' => $error,
                    'require_redis' => $requireRedis,
                    'production' => $isProduction,
                    'warning' => 'File fallback is unsafe for distributed systems — set CACHE_REQUIRE_REDIS=true',
                ]);
            } catch (\Throwable $ignore) {}
        }

        // در production یا حالت require_redis، fail-loud
        if ($requireRedis || $isProduction) {
            throw new \RuntimeException(
                "Redis cache is required (require_redis={$requireRedis}, production={$isProduction}) but connection failed: {$error}. " .
                "Set CACHE_REQUIRE_REDIS=false for silent file fallback (NOT recommended for distributed deployments).",
                0
            );
        }
    }

    // ─────────────────────────────────────────────────
    //  عملیات اصلی
    // ─────────────────────────────────────────────────

    public function put(string $key, mixed $value, int $minutes = 60): bool
    {
        $this->assertStorableValue($value);
        return $this->writeValue($key, $value, $minutes * 60);
    }

    /**
     * FIX-8a: گارد آبجکتِ غیر stdClass (CORE-040) به هلپر مشترک منتقل شد؛
     * همهٔ مسیرهای نوشتن (put/setSeconds/forever) همان قرارداد را دارند.
     */
    private function assertStorableValue(mixed $value): void
    {
        // BUGFIX-PHASE3-P33: آبجکتِ غیر stdClass هنگام get با allowed_classes=[stdClass]
        // (سخت‌سازی امنیتی CORE-040) به __PHP_Incomplete_Class تبدیل و بی‌صدا خراب
        // می‌شد. هیچ فراخواننده‌ای در app/ و core/ آبجکت در کش ذخیره نمی‌کند (با rg
        // تأیید شد) — از این پس به‌جای خرابیِ بی‌صدا، خطای صریح که توسعه‌دهنده را
        // با قالب ذخیره‌سازی هم‌راستا می‌کند.
        if (is_object($value) && !($value instanceof \stdClass)) {
            throw new \InvalidArgumentException(
                'Cache::put() does not support non-stdClass objects: the get() allowlist '
                . '[stdClass] would turn them into __PHP_Incomplete_Class. Store arrays, '
                . 'scalars or stdClass instances instead.'
            );
        }
    }

    /**
     * FIX-8a: هستهٔ مشترک نوشتن با TTL «ثانیه‌ای دقیق».
     * Redis: setEx بومی ثانیه است. فایل: expire_at = time() + ttlSeconds (timestamp).
     * پس هر دو درایور TTL زیردقیقه‌ای (مثلاً ۵ ثانیه) را عیناً اجرا می‌کنند —
     * قبلاً setSeconds آن را ceil به ۱ دقیقه گرد می‌کرد (یافتهٔ Medium «CacheManager::set
     * گرد کردن TTL زیردقیقه‌ای به ۶۰ ثانیه»).
     */
    private function writeValue(string $key, mixed $value, int $ttlSeconds): bool
    {
        // FIX-S6-2 (یادداشت معلق S3): TTL <= 0 در مسیر Redis قبلاً به setEx می‌رسید
        // و RedisException («invalid expire time») پرتاب می‌شد، در حالی که مسیر فایل
        // همان مقدار را «بلافاصله منقضی» تلقی می‌کند (fileGet حذفش می‌کند) و
        // قرارداد setSeconds() نیز TTL<=0 را forget() می‌داند. اکنون هر دو درایور
        // هم‌رفتارند: مقدار با TTL غیرمثبت = حذف کلید + true (نه کرش خام).
        if ($ttlSeconds <= 0) {
            return $this->forget($key);
        }

        // BUGFIX-PHASE3-P32 / CORE-040: JSON ترجیحی است (کاهش ریسک deserialization)؛
        // اگر json_encode شکست بخورد (UTF-8 نامعتبر / resource / NaN)، مسیر فایل
        // سریالایز دارد — مسیر Redis هم همین تقارن را دارد.
        $payload = is_object($value) ? serialize($value) : json_encode($value, JSON_UNESCAPED_UNICODE);
        if ($payload === false) {
            // FIX-P4S-1: serialize() طبق امضای PHP 8 همیشه string برمی‌گرداند
            // (شکست ⇒ Exception، نه false) — مسیر fallback همیشه موفق است.
            $payload = serialize($value);
        }

        if ($this->redis !== null) {
            return (bool) $this->redis->setEx(
                $this->redisKey($key),
                $ttlSeconds,
                $payload
            );
        }

        return $this->filePutTtl($key, $value, $ttlSeconds);
    }

    /**
     * Alias برای put (برای سازگاری)
     */
    public function set(string $key, mixed $value, int $minutes = 60): bool
    {
        return $this->put($key, $value, $minutes);
    }

    /**
     * ذخیره با TTL صریح بر حسب دقیقه.
     * این متد برای جلوگیری از ابهام API قدیمی set/put اضافه شده است.
     */
    public function setMinutes(string $key, mixed $value, int $minutes = 60): bool
    {
        return $this->put($key, $value, $minutes);
    }

    public function putMinutes(string $key, mixed $value, int $minutes = 60): bool
    {
        return $this->put($key, $value, $minutes);
    }

    /**
     * ذخیره با TTL صریح بر حسب ثانیه — «دقیق».
     * FIX-8a: قبلاً ceil(seconds/60) دقیقه می‌شد ⇒ TTL ۵ ثانیه‌ای عملاً ۶۰ ثانیه
     * زندگی می‌کرد (گارد‌های کوتاه‌مدت مثل جلوگیری از double-submit بی‌اثر می‌شدند).
     * اکنون مقدار عیناً اعمال می‌شود (حداقلِ معنادار: seconds<=0 = حذف کلید).
     */
    public function setSeconds(string $key, mixed $value, int $seconds = 3600): bool
    {
        $this->assertStorableValue($value);
        return $this->writeValue($key, $value, $seconds);
    }

    public function putSeconds(string $key, mixed $value, int $seconds = 3600): bool
    {
        return $this->setSeconds($key, $value, $seconds);
    }

    /**
     * S27B-F7 (FIX-R18B — restore): claim اتمیک دو-حالته (دلالت SETNX).
     * مقدار را فقط در صورت «نبودن» کلید می‌نویسد؛ true = claim برنده شد،
     * false = کلید از قبل زنده است (claim دیگری برنده شده). برای گیت‌های
     * dedup/قفلِ کوتاه‌مدت (مثل NotificationDispatcher) که check-then-act
     * با get+set اتمیک نیست و رقابت دو worker = ارسال مضاعف می‌سازد.
     *
     * TTL بر حسب «ثانیه» (قرارداد FIX-8a؛ مثل setSeconds). TTL غیرمثبت =
     * InvalidArgumentException (نه forget خاموش) — قرارداد پین‌شدهٔ
     * S27P2SubserviceHardeningTest::cache_add_rejects_non_positive_ttl.
     */
    public function add(string $key, mixed $value, int $seconds = 60): bool
    {
        if ($seconds <= 0) {
            throw new \InvalidArgumentException("Cache::add() requires a positive TTL in seconds, got {$seconds}.");
        }
        $this->assertStorableValue($value);

        if ($this->redis !== null) {
            // CORE-040: همان قرارداد payload مسیر writeValue (JSON، serialize fallback)
            $payload = is_object($value) ? serialize($value) : json_encode($value, JSON_UNESCAPED_UNICODE);
            if ($payload === false) {
                $payload = serialize($value);
            }
            $result = $this->redis->set($this->redisKey($key), $payload, ['nx', 'ex' => $seconds]);
            return $result !== false && $result !== null;
        }

        // File driver — claim اتمیک با حالت 'x' (fopen فقط-اگر-نبود؛ خودِ هستهٔ
        // فایل اتمیک است، بدون رقابت read-then-write)؛ قالب payload = filePutTtl
        // تا get()/forget() عادی روی کلیدِ claim‌شده کار کنند.
        $file = $this->cacheFile($key);
        $dir  = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $fh = @fopen($file, 'x');
        if ($fh === false) {
            return false; // کلید از قبل زنده — claim باخته شد
        }
        $data = [
            'expire_at' => time() + $seconds,
            'value'     => $value,
        ];
        $encoded = json_encode($data, JSON_UNESCAPED_UNICODE);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $encoded = serialize($data);
        }
        $written = fwrite($fh, (string)$encoded);
        fclose($fh);
        if ($written === false) {
            @unlink($file); // claim نیم‌کاره را رها کن تا retry ممکن بماند
            return false;
        }
        return true;
    }

    /** FIX-8a: دقیق بر حسب ثانیه (قبلاً ceil به دقیقه گرد می‌شد). */
    public function rememberSeconds(string $key, int $seconds, callable $callback): mixed
    {
        return $this->rememberTtlSeconds($key, $seconds, $callback);
    }

    public function get(string $key, mixed $default = null): mixed
    {
        if ($this->redis !== null) {
            $raw = $this->redis->get($this->redisKey($key));
            if ($raw === false) {
                return $default;
            }
            return $this->safeUnserialize(is_string($raw) ? $raw : null);
        }

        return $this->fileGet($key, $default);
    }

    /**
     * خواندن مقدار کش و حذف فوری آن (Get and Forget)
     */
    public function pull(string $key, mixed $default = null): mixed
    {
        $value = $this->get($key, $default);
        $this->forget($key);
        return $value;
    }

    public function has(string $key): bool
    {
        if ($this->redis !== null) {
            return (bool) $this->redis->exists($this->redisKey($key));
        }

        return $this->fileHas($key);
    }

    public function forget(string $key): bool
    {
        if ($this->redis !== null) {
            return (bool) $this->redis->del($this->redisKey($key));
        }

        return $this->fileForget($key);
    }

    public function flush(): bool
    {
        if ($this->redis !== null) {
            $iterator = null;
            $pattern = $this->redisPrefix . '*';

            while (false !== ($batch = $this->redis->scan($iterator, $pattern, 100))) {
                if (!empty($batch)) {
                    $this->redis->del($batch);
                }
                if ($iterator === 0 || $iterator === '0') {
                    break;
                }
            }

            return true;
        }

        return $this->fileFlush();
    }

    public function remember(string $key, int $minutes, callable $callback): mixed
    {
        return $this->rememberTtlSeconds($key, $minutes * 60, $callback);
    }

    /**
     * FIX-8a: نسخهٔ ثانیه‌محورِ دقیقِ remember با همان قفل ضدمیلگرد CORE-039.
     * remember() دقیقه‌محور فقط یک wrapper ($minutes × 60) روی همین متد است.
     *
     * FIX-M6-13 (قرارداد صریح single-flight):
     *   این API ادعای single-flight مطلق ندارد. قفل ضدمیلگرد تنها بهترینِ تلاش
     *   است:
     *   - اگر قفل گرفته شد → double-check + فقط یک پروسه callback را اجرا می‌کند.
     *   - اگر قفل در دسترس نبود ( contention یا backend قفلِ fail-closed) →
     *     پس از backoff کوتاه و یک re-read، callback به‌صورت «بدون قفل» اجرا
     *     می‌شود؛ یعنی چند پروسه می‌توانند هم‌زمان آن را اجرا کنند.
     *   قرارداد فراخواننده: callback باید pure یا حداقل idempotent باشد یا
     *   اثر جانبی‌اش در برابر اجرای هم‌زمان محافظت شده باشد. برای callbackهای
     *   دارای اثر جانبیِ حساس، از lock()+withLock(fencing) صریح استفاده کنید.
     */
    public function rememberTtlSeconds(string $key, int $ttlSeconds, callable $callback): mixed
    {
        if ($ttlSeconds <= 0) {
            return $callback();
        }

        $value = $this->get($key);
        if ($value !== null) {
            return $value;
        }

        // CORE-039: Cache Stampede mitigation using distributed double-check lock
        $lockKey = 'remember:' . $key;
        $lockAcquired = false;
        try {
            $lockAcquired = $this->lock($lockKey, 30, 5);
        } catch (\RuntimeException $e) {
            // Lock is fail-closed in production without Redis. Proceed without locking for non-atomic operations.
            $lockAcquired = false;
        }

        if ($lockAcquired) {
            try {
                // Double check
                $value = $this->get($key);
                if ($value !== null) {
                    return $value;
                }

                $value = $callback();
                $this->writeValue($key, $value, $ttlSeconds);
                return $value;
            } finally {
                $this->unlock($lockKey);
            }
        }

        // Fallback if lock could not be acquired: introduce random backoff sleep and secondary read attempt
        usleep(random_int(50000, 150000)); // 50ms to 150ms sleep
        $secondaryValue = $this->get($key);
        if ($secondaryValue !== null) {
            return $secondaryValue;
        }

        return $callback();
    }

    public function rememberForever(string $key, callable $callback): mixed
    {
        if ($this->has($key)) {
            return $this->get($key);
        }

        $value = $callback();
        $this->forever($key, $value);
        return $value;
    }

    public function forever(string $key, mixed $value): bool
    {
        // BUGFIX-PHASE3-P33/P32: همان گارد put() — آبجکت غیر stdClass ممنوع (گارد مشترک)
        $this->assertStorableValue($value);

        // FIX-8a: منطق payload با put/writeValue یکسان شد (Redis setEx ۱ سال =
        // ۳۱۵۳۶۰۰۰ ثانیه، همسان با رانر فایل برای جلوگیری از انباشت بی‌نهایت حافظه).
        return $this->writeValue($key, $value, 31536000); // ~1 سال
    }

    // ─────────────────────────────────────────────────
    //  Counter (atomic در Redis)
    // ─────────────────────────────────────────────────

    public function increment(string $key, int $step = 1, int $ttlSeconds = 0): int|false
    {
        // CORE-038: Fail-closed if distributed state operations called without real-time central store
        if ($this->redis === null && (config('app.env') === 'production' || env('APP_ENV') === 'production')) {
            throw new \RuntimeException('Atomic counters/limiters require Redis driver in production to prevent split-brain.', 500);
        }

        if ($this->redis !== null) {
            // اسکریپت لوآ برای اتمیک اینکریمنت + تنظیم انقضا در صورتی که از قبل ندارد
            $script = <<<'LUA'
local current = redis.call('INCRBY', KEYS[1], ARGV[1])
local ttl = redis.call('TTL', KEYS[1])
local targetTtl = tonumber(ARGV[2])
-- فقط اگر کلید تازه ساخته شده یا انقضا ندارد (TTL = -1) و درخواست TTL داده شده باشد
if ttl == -1 and targetTtl > 0 then
    redis.call('EXPIRE', KEYS[1], targetTtl)
end
return current
LUA;
            $result = $this->redis->eval($script, [$this->redisKey($key), $step, $ttlSeconds], 1);
            return $result !== false ? int_value($result) : false;
        }

        // M20 Fix: افزایش اتمیک فایل با flock برای مسدود کردن تداخلات همزمانی
        $file = $this->cacheFile($key);
        $dir  = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $fh = fopen($file, 'c+');
        if (!$fh) {
            return false;
        }

        $new = false;
        if (flock($fh, LOCK_EX)) {
            $size = @filesize($file);
            $raw = ($size > 0) ? fread($fh, $size) : '';

            $currentValue = 0;
            // یک سال پیش‌فرض (بر حسب ثانیه)
            $expireAt = time() + ($ttlSeconds > 0 ? $ttlSeconds : (525_600 * 60));

            if (!empty($raw)) {
                $data = $this->safeUnserialize($raw);
                if (is_array($data) && isset($data['expire_at'])) {
                    // اگر کلید منقضی شده باشد مقدار قبلی نادیده گرفته می‌شود
                    if ($data['expire_at'] >= time()) {
                        $currentValue = intval($data['value'] ?? 0);
                        // اگر انقضای جدید تعیین نشده، انقضای قبلی را حفظ کن
                        if ($ttlSeconds <= 0) {
                            $expireAt = $data['expire_at'];
                        }
                    }
                }
            }

            $new = $currentValue + $step;

            $newData = serialize([
                'expire_at' => $expireAt,
                'value'     => $new,
            ]);

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, $newData);
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        return $new;
    }

    public function decrement(string $key, int $step = 1, int $ttlSeconds = 0): int|false
    {
        return $this->increment($key, -$step, $ttlSeconds);
    }

    public function incrementFloat(string $key, float $step = 1.0, int $ttlSeconds = 0): float|false
    {
        if ($this->redis === null && (config('app.env') === 'production' || env('APP_ENV') === 'production')) {
            throw new \RuntimeException('Atomic float counters require Redis driver in production.', 500);
        }

        if ($this->redis !== null) {
            $script = <<<'LUA'
local current = redis.call('INCRBYFLOAT', KEYS[1], ARGV[1])
local ttl = redis.call('TTL', KEYS[1])
local targetTtl = tonumber(ARGV[2])
if ttl == -1 and targetTtl > 0 then
    redis.call('EXPIRE', KEYS[1], targetTtl)
end
return current
LUA;
            $result = $this->redis->eval($script, [$this->redisKey($key), $step, $ttlSeconds], 1);
            return $result !== false ? float_value($result) : false;
        }

        // M20 Fix: افزایش اعشاری اتمیک فایل با flock
        $file = $this->cacheFile($key);
        $dir  = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $fh = fopen($file, 'c+');
        if (!$fh) {
            return false;
        }

        $new = false;
        if (flock($fh, LOCK_EX)) {
            $size = @filesize($file);
            $raw = ($size > 0) ? fread($fh, $size) : '';

            $currentValue = 0.0;
            $expireAt = time() + ($ttlSeconds > 0 ? $ttlSeconds : (525_600 * 60));

            if (!empty($raw)) {
                $data = $this->safeUnserialize($raw);
                if (is_array($data) && isset($data['expire_at'])) {
                    if ($data['expire_at'] >= time()) {
                        $currentValue = floatval($data['value'] ?? 0.0);
                        if ($ttlSeconds <= 0) {
                            $expireAt = $data['expire_at'];
                        }
                    }
                }
            }

            $new = $currentValue + $step;

            $newData = serialize([
                'expire_at' => $expireAt,
                'value'     => $new,
            ]);

            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, $newData);
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);

        return $new;
    }

    // ─────────────────────────────────────────────────
    //  TTL باقی‌مانده (ثانیه)
    // ─────────────────────────────────────────────────

    public function ttl(string $key): int
    {
        if ($this->redis !== null) {
            return (int) $this->redis->ttl($this->redisKey($key));
        }

        $file = $this->cacheFile($key);
        if (!file_exists($file)) {
            return -2;
        }
        $raw = file_get_contents($file);
$data = (array)$this->safeUnserialize($raw === false ? null : $raw);
        if (empty($data) || !isset($data['expire_at'])) {
            return -2;
        }
        $left = (int)($data['expire_at'] - time());
        return max(-1, $left);
    }

    // ─────────────────────────────────────────────────
    //  Tagged Cache
    // ─────────────────────────────────────────────────

    /**
     * کش با تگ — امکان flush گروهی
     *
     * مثال:
     *   cache()->tags(['users'])->put('user:1', $data, 10);
     *   cache()->tags(['users'])->flush();
     */
    /** @param list<string> $tags */
    public function tags(array $tags): TaggedCache
    {
        return new TaggedCache($this, $tags, $this->tagCacheDir);
    }

    // ─────────────────────────────────────────────────
    //  Redis Raw (برای RateLimiter و سایر موارد خاص)
    // ─────────────────────────────────────────────────

    public function redis(): ?\Redis
    {
        return $this->redis;
    }

    // ─────────────────────────────────────────────────
    //  Distributed Locking (برای عملیات concurrent)
    // ─────────────────────────────────────────────────

    /**
     * Acquire a distributed lock
     *
     * Redis: استفاده از SET NX EX برای atomic locking
     * File: استفاده از file locking با timeout
     *
     * @param string $key نام lock
     * @param int $ttl ثانیه‌های timeout (فقط Redis)
     * @return bool آیا lock گرفته شد؟
     */
    /**
     * Acquire a distributed lock
     *
     * Redis: استفاده از SET NX EX برای atomic locking
     * File: استفاده از file locking با timeout
     *
     * @param string $key نام lock
     * @param int $ttl ثانیه‌های timeout (فقط Redis)
     * @param int $wait حداکثر ثانیه‌های انتظار برای آزادسازی قفل (فایل)
     * @return bool آیا lock گرفته شد؟
     */
    public function lock(string $key, int $ttl = 30, int $wait = 1): bool
    {
        // CORE-038: Prevent unsafe local lock fallback on production
        if ($this->redis === null && (config('app.env') === 'production' || env('APP_ENV') === 'production')) {
            throw new \RuntimeException('Distributed locking functionality requires the Redis driver in production.', 500);
        }

        $lockKey = 'lock:' . $key;

        if ($this->redis !== null) {
            // M19 Fix: ذخیره سازی شناسه مالکیت قفل در سشن پردازش جاری (اصلاح تصادم کلید در کلاسترها)
            // جایگزینی uniqid با مکانیزم میکروثانیه‌ای و تصادفی جهت مسدودسازی دستکاری قفل‌های توزیع‌شده توسط ورکرهای موازی
            $uniqueId = md5((string)microtime(true) . bin2hex(random_bytes(8)));
            $result = $this->redis->set(
                $this->redisKey($lockKey),
                $uniqueId,
                ['nx', 'ex' => $ttl]
            );

            if ($result !== false) {
                $this->redisLocks[$lockKey] = $uniqueId;
                return true;
            }
            return false;
        }

        // M18 Fix: پیاده‌سازی قفل‌گذاری فایل با قابلیت تعیین زمان داینامیک انتظار ($wait)
        $lockFile = $this->cacheDir . 'locks/' . md5($lockKey) . '.lock';
        $lockDir = dirname($lockFile);
        if (!is_dir($lockDir)) {
            mkdir($lockDir, 0755, true);
        }

        $fh = fopen($lockFile, 'c');
        if (!$fh) {
            return false;
        }

        // Try to acquire lock with timeout (simulate)
        $start = microtime(true);
        while (!flock($fh, LOCK_EX | LOCK_NB)) {
            if ((microtime(true) - $start) > $wait) { // استفاده از پارامتر پویا
                fclose($fh);
                return false;
            }
            usleep(1000); // 1ms
        }

        // Store file handle for unlock
        $this->fileLocks[$lockKey] = $fh;
        return true;
    }

    /**
     * FIX-M6-12: تمدید اتمیک TTL قفلِ متعلق به این پروسه (compare-owner).
     *
     * قفل با TTL ثابت ممکن است «وسط کار» منقضی شود و دارندهٔ دوم acquire کند
     * (همان ریسک M6-12 برای mutex جاب‌های cron). این متد با همان توکن مالکیت
     * ثبت‌شده در lock()، TTL را فقط وقتی تمدید می‌کند که مالکِ فعلی هنوز ما
     * باشیم (Lua compare-and-EXPIRE — بدون TOCTOU). false = مالکیت باخته یا
     * قفل غایب؛ فراخواننده باید آن را «از دست رفتن lease» تفسیر کند.
     *
     * در مسیر فایل (بدون Redis)، flock خودش تا unlock معتبر است؛ true بی‌عمل.
     *
     * @param string $key نام قفل (بدون پیشوند lock:)
     * @param int $ttl ثانیه‌های جدید از اکنون
     */
    public function extendLock(string $key, int $ttl): bool
    {
        $lockKey = 'lock:' . $key;

        if ($this->redis !== null) {
            $owner = $this->redisLocks[$lockKey] ?? null;
            if ($owner === null) {
                return false; // این پروسه مالک ثبت‌شده‌ای برای این قفل ندارد
            }

            $script = '
                if redis.call("get", KEYS[1]) == ARGV[1] then
                    return redis.call("expire", KEYS[1], ARGV[2])
                else
                    return 0
                end
            ';

            return (bool) $this->redis->eval($script, [$this->redisKey($lockKey), $owner, max(1, $ttl)], 1);
        }

        // File driver: قفل فایل با unlock صاحبش آزاد می‌شود و TTL ندارد؛
        // تمدید معنا ندارد — مالکِ ثبت‌شده وجودش را به‌عنوان موفقیت گزارش می‌کند.
        return isset($this->fileLocks[$lockKey]);
    }

    /**
     * Release a distributed lock
     *
     * @param string $key نام lock
     * @return bool آیا unlock موفق بود؟
     */
    public function unlock(string $key): bool
    {
        $lockKey = 'lock:' . $key;

        if ($this->redis !== null) {
            // M19 Ultimate Fix: آزادسازی کاملاً امن و اتمیک قفل صرفاً در صورت تطابق توکن مالکیت (Lua)
            $owner = $this->redisLocks[$lockKey] ?? null;
            if ($owner === null) {
                return false; // این پردازش مالک قفل نبوده و اجازه آزاد سازی ندارد
            }

            unset($this->redisLocks[$lockKey]);

            $script = '
                if redis.call("get", KEYS[1]) == ARGV[1] then
                    return redis.call("del", KEYS[1])
                else
                    return 0
                end
            ';

            return (bool) $this->redis->eval($script, [$this->redisKey($lockKey), $owner], 1);
        }

        // File-based unlock
        if (!isset($this->fileLocks[$lockKey])) {
            return false;
        }

        $fh = $this->fileLocks[$lockKey];
        flock($fh, LOCK_UN);
        fclose($fh);
        unset($this->fileLocks[$lockKey]);

        return true;
    }

    /**
     * FIX-36/F-A11-01 (راند R36-W2-D) — Fencing tokens (M-26) روی قفل هسته.
     * ------------------------------------------------------------------
     * مشکل: قفل با TTL ثابت ممکن است «وسط کار» منقضی شود؛ نگهدارندهٔ دوم acquire
     * می‌کند و نگهدارندهٔ کهنه هم‌زمان در ناحیهٔ بحرانی می‌نویسد. قفل به‌تنهایی
     * این را حل نمی‌کند — نقطهٔ enforce، «نوشتار» است نه acquisition.
     *
     * این فیکس سه پریمیتیو به قفل هسته اضافه می‌کند (کاملاً backward-compatible؛
     * هیچ مصرف‌کنندهٔ فعلی مجبور به تغییر نیست):
     *   1) nextFenceToken(): صدور توکن مونوتونیک (شمارندهٔ اتمیک INCR — روی Redis
     *      با Lua اتمیک، روی فایل با flock) — هر acquisition موفق توکنی سخت‌بزرگ‌تر
     *      از توکن نگهدارنده‌های قبلی می‌گیرد.
     *   2) withLock(): اگر callback پارامتر بپذیرد، توکن fence به‌عنوان آرگومان اول
     *      پاس می‌شود (هم‌الگوی DistributedLockService::synchronized). callbackهای
     *      بدون پارامتر — یعنی هر ۲ مصرف‌کنندهٔ فعلی (SlidingWindow/TokenBucket) —
     *      دقیقاً مثل قبل اجرا می‌شوند و صفر هزینهٔ INCR اضافه می‌پردازند.
     *   3) validateFence($key, $fence): CAS-max اتمیکِ نشان‌گرِ سرب (high-water mark)
     *      per-resource؛ true فقط اگر $fence جدیدترین باشد. نگهدارندهٔ کهنه‌ای که
     *      بعد از انقضای TTL بیدار شود با توکن کوچک‌تر رد می‌شود.
     *
     * ⚠️ صدور توکن با increment() است؛ در production بدون Redis این همان قرارداد
     * fail-loud CORE-038 را دارد (قفل هم در همان حالت throw می‌کند). مصرف‌کننده‌های
     * پولی که واقعاً fence را در commit enforce می‌کنند (WALLET و…) — سیم‌کشی‌شان
     * change دامنهٔ دیگر است (cross-domain) و در گزارش W2-D فهرست شده است.
     */

    /**
     * صدور توکن fence مونوتونیک سراسری (شمارندهٔ اتمیک «lockfence»).
     * مونوتونیکِ سراسری برای هر resource هم مونوتونیک است — برای مقایسهٔ
     * high-water mark per-resource کافی و سخت‌گیرانه‌تر است.
     */
    public function nextFenceToken(): int
    {
        $value = $this->increment('lockfence', 1, 0);
        if (!is_int($value) || $value <= 0) {
            // شمارنده در دسترس نیست (RedisException/شکست مخزن) — fail-loud:
            // مصرف‌کنندهٔ fence-aware بهتر است بداند توکنش قابل‌اعتماد نیست.
            throw new \RuntimeException('Fencing token counter is unavailable (cache store failure).');
        }
        return $value;
    }

    /**
     * enforce per-resource fencing: CAS-max اتمیک high-water mark.
     * true = این توکن جدیدترین است (نوشتار مجاز)، false = نگهدارندهٔ stale.
     *
     * Redis: اسکریپت لوآ مقایسه-و-ست (اتمیک). فایل: خواندن/نوشتار با flock.
     * اگر پشتیبان اصلاً در دسترس نباشد فایل‌محورِ single-server fail-OPEN
     * برمی‌گردد (هم‌قرارداد DistributedLockService::guardFence) — ایمنی چندسروره
     * آنجا با fail-closed بودن acquire پوشش داده می‌شود.
     */
    public function validateFence(string $key, int $fence): bool
    {
        if ($fence <= 0) {
            return false;
        }

        if ($this->redis !== null) {
            $script = <<<LUA
local cur = tonumber(redis.call("GET", KEYS[1]) or "0")
local fence = tonumber(ARGV[1])
if fence >= cur then
    redis.call("SET", KEYS[1], fence)
    return 1
else
    return 0
end
LUA;
            $result = $this->redis->eval($script, [$this->redisKey('fence:' . $key), $fence], 1);
            return is_int($result) && $result === 1;
        }

        return $this->validateFenceFile($key, $fence);
    }

    /** خواندن نشان‌گر سرب فعلی fence برای یک resource (۰ = هیچ). */
    public function currentFence(string $key): int
    {
        if ($this->redis !== null) {
            $val = $this->redis->get($this->redisKey('fence:' . $key));
            return is_numeric($val) ? (int) $val : 0;
        }

        $file = $this->fenceFile($key);
        if (!file_exists($file)) {
            return 0;
        }
        $raw = @file_get_contents($file);
        return is_string($raw) && is_numeric(trim($raw)) ? (int) trim($raw) : 0;
    }

    /** CAS-max فایل‌محور برای high-water mark (فقط single-server). */
    private function validateFenceFile(string $key, int $fence): bool
    {
        $file = $this->fenceFile($key);
        $dir = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $fp = @fopen($file, 'c+');
        if (!$fp) {
            return true; // fail-open روی single-server (قرارداد مستند)
        }
        if (!flock($fp, LOCK_EX)) {
            fclose($fp);
            return true;
        }

        try {
            rewind($fp);
            $content = stream_get_contents($fp);
            $cur = is_string($content) && is_numeric(trim($content)) ? (int) trim($content) : 0;
            if ($fence < $cur) {
                return false;
            }
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, (string) $fence);
            fflush($fp);
            return true;
        } catch (\Throwable) {
            return true; // fail-open (قرارداد DistributedLockService::guardFenceFile)
        } finally {
            fclose($fp);
        }
    }

    private function fenceFile(string $key): string
    {
        return $this->cacheDir . 'fences/' . md5($key) . '.fence';
    }

    /**
     * Execute callback with automatic lock/unlock
     *
     * مثال:
     *   $result = cache()->withLock('user:123:update', function() {
     *       // عملیات atomic
     *       return doSomething();
     *   });
     *
     * FIX-36/F-A11-01: برای مصرف‌کننده‌های fencing-aware — اگر callback پارامتر
     * بپذیرد، توکن fence مونوتونیک به‌عنوان آرگومان اول پاس می‌شود:
     *   cache()->withLock('wallet:'.$id, function(int $fence) {
     *       if (!cache()->validateFence('wallet:'.$id, $fence)) { throw ... } // قبل از نوشتار
     *       ...
     *   });
     * callbackهای بدون پارامتر دقیقاً مثل قبل اجرا می‌شوند (هیچ INCR اضافه‌ای).
     *
     * @param string $key نام lock
     * @param callable $callback عملیات مورد نظر
     * @param int $ttl ثانیه‌های timeout
     * @return mixed نتیجه callback یا false اگر lock شکست خورد
     */
    public function withLock(string $key, callable $callback, int $ttl = 30, int $waitMs = 250): mixed
    {
        // BUGFIX-PHASE3-P314: قبلاً یک تلاشِ lock بدون هیچ انتظاری بود؛ در مسیر Redis
        // (SET NX EX) یک برخورد لحظه‌ای فوراً false برمی‌گرداند که نزد فراخواننده‌های
        // RateLimiter (SlidingWindow/TokenBucket) به‌صورت 429 کاذب دیده می‌شد.
        // اکنون تا سقف $waitMs با backoff کوتاه تلاش می‌شود؛ پس از آن قرارداد قبلی
        // (false) حفظ می‌شود. امضای backward-compatible است (پارامتر جدید اختیاری).
        $deadline = microtime(true) + (max(0, $waitMs) / 1000);

        // FIX-36/F-A11-01: تشخیص fencing-aware بودن callback قبل از حلقه — توکن فقط
        // هنگام نیاز صادر می‌شود (reflection روی شکل callable). صدور پس از acquire
        // و درون try است؛ شکست صدور با finally قفل را آزاد و استثنا را بلند می‌کند.
        try {
            $wantsFence = (new \ReflectionFunction(\Closure::fromCallable($callback)))->getNumberOfParameters() > 0;
        } catch (\ReflectionException) {
            $wantsFence = false;
        }

        do {
            if ($this->lock($key, $ttl)) {
                try {
                    if ($wantsFence) {
                        $fence = $this->nextFenceToken();
                        return $callback($fence);
                    }
                    return $callback();
                } finally {
                    $this->unlock($key);
                }
            }
            usleep(25000); // 25ms بین تلاش‌ها
        } while (microtime(true) < $deadline);

        return false; // Could not acquire lock
    }

    /**
     * پاکسازی تمام قفل‌های ثبت‌شده در مموری (کاربرد در فرآیندهای طولانی مثل Queue Workers)
     *
     * FIX-M6-14: قبلاً برای Redis فقط map محلی owner پاک می‌شد و قفل‌های backend
     * تا TTL باقی می‌ماندند (کار بعدی/جابی دیگر تا پایان TTL بلاک می‌شد و
     * «آزادسازی» وعده‌داده‌شده توسط cleanup واقعاً رخ نمی‌داد). اکنون هر قفل
     * ثبت‌شدهٔ این پروسه با compare-and-delete اتمیک (همان Lua unlock) واقعاً
     * آزاد می‌شود: فقط قفل‌هایی که ownerشان هنوز ما هستیم حذف می‌شوند؛ قفل‌های
     * takeover‌شده توسط پروسهٔ دیگر دست‌نخورده می‌مانند (false و لاگ debug).
     * قفل‌هایی که عمداً باید تا TTL بمانند، در این map ثبت نشده‌اند و تحت
     * تأثیر قرار نمی‌گیرند.
     */
    public function flushAllLocks(): void
    {
        // 1. Close file handles
        foreach ($this->fileLocks as $key => $fh) {
            if (is_resource($fh)) {
                flock($fh, LOCK_UN);
                fclose($fh);
            }
        }
        $this->fileLocks = [];

        // 2. Release Redis locks actually owned by this process (compare-and-delete)
        foreach (array_keys($this->redisLocks) as $lockKey) {
            try {
                // unlock() خودش compare-and-delete اتمیک با owner token انجام
                // می‌دهد و بعد از حذف، map محلی را هم پاک می‌کند.
                $this->unlock(substr($lockKey, strlen('lock:')));
            } catch (\Throwable $e) {
                // شکست آزادسازی تک‌قفل نباید بقیه را قطع کند؛ TTL پشتیبان است.
                if (function_exists('logger')) {
                    try {
                        logger()->debug('cache.flush_all_locks.release_failed', [
                            'lock' => $lockKey,
                            'error' => $e->getMessage(),
                        ]);
                    } catch (\Throwable $ignored) {}
                }
            }
        }

        // 3. Clear any residual local owner map entries (defensive — unlock معمولاً پاک کرده)
        $this->redisLocks = [];
    }

    // ─────────────────────────────────────────────────
    //  Cleanup — فقط در حالت فایل
    // ─────────────────────────────────────────────────

    public function cleanup(): int
    {
        $logger = null;
        if (function_exists('logger')) {
            try {
                $logger = logger();
            } catch (\Throwable) {
                $logger = null;
            }
        }

        if ($this->redis !== null) {
            if ($logger) {
                $logger->info('Cache cleanup skipped — Redis manages TTL automatically', []);
            }
            return 0;
        }

        $files   = glob($this->cacheDir . '*.cache') ?: [];
        $cleaned = 0;

        foreach ($files as $file) {
            $raw = file_get_contents($file);
            $data = (array)$this->safeUnserialize($raw === false ? null : $raw);
            if (empty($data) || !isset($data['expire_at']) || $data['expire_at'] < time()) {
                @unlink($file);
                $cleaned++;
            }
        }

        $context = [
            'channel' => 'cache',
            'cleaned' => $cleaned,
        ];
        if ($logger) {
            $logger->info('cache.file.cleanup.completed', $context);
        }
        if (PHP_SAPI === 'cli') {
            // Preserve the operational event when the application logger is
            // unavailable or routed away from the CLI stream.
            echo 'cache.file.cleanup.completed' . PHP_EOL;
        }

        return $cleaned;
    }

    // ─────────────────────────────────────────────────
    //  پشتیبان فایل
    // ─────────────────────────────────────────────────

    /**
     * FIX-8a: نام و واحد تغییر کرد — filePutTtl ttlSecondsِ «دقیق» می‌گیرد
     * (قبلاً filePut دقیقه می‌گرفت و ×۶۰ می‌کرد). درایور فایل expire_at از نوع
     * timestamp ذخیره می‌کند پس TTL زیردقیقه‌ای هم عیناً معتبر است.
     */
    private function filePutTtl(string $key, mixed $value, int $ttlSeconds): bool
    {
        $data = [
            'expire_at' => time() + $ttlSeconds,
            'value'     => $value,
        ];

        // CORE-040: Write as JSON to avoid dangerous deserialization payload risk.
        $encoded = json_encode($data, JSON_UNESCAPED_UNICODE);
        if (json_last_error() !== JSON_ERROR_NONE) {
            // Fallback safe serialization only for objects
            $encoded = serialize($data);
        }

        return (bool) file_put_contents($this->cacheFile($key), $encoded, LOCK_EX);
    }

    private function fileGet(string $key, mixed $default): mixed
    {
        $file = $this->cacheFile($key);
        if (!file_exists($file)) {
            return $default;
        }

        $raw = file_get_contents($file);
        if ($raw === false) {
            return $default;
        }

        // CORE-040: Try json_decode first to enforce secure formats
        $decoded = json_decode($raw, true);
        $data = is_array($decoded) && !empty($decoded) ? $decoded : null;
        if ($data === null) {
            $data = $this->safeUnserialize($raw);
        }

        if (!is_array($data) || !isset($data['expire_at']) || $data['expire_at'] < time()) {
            @unlink($file);
            return $default;
        }

        return $data['value'];
    }

    private function fileHas(string $key): bool
    {
        $file = $this->cacheFile($key);
        if (!file_exists($file)) {
            return false;
        }
        $raw = file_get_contents($file);
        if ($raw === false) {
            return false;
        }

        $decoded = json_decode($raw, true);
        $data = is_array($decoded) && !empty($decoded) ? $decoded : null;
        if ($data === null) {
            $data = $this->safeUnserialize($raw);
        }

        if (!is_array($data) || !isset($data['expire_at']) || $data['expire_at'] < time()) {
            @unlink($file);
            return false;
        }
        return true;
    }

    private function fileForget(string $key): bool
    {
        $file = $this->cacheFile($key);
        if (file_exists($file)) {
            return unlink($file);
        }
        return false;
    }

    private function fileFlush(): bool
    {
        foreach (glob($this->cacheDir . '*.cache') ?: [] as $file) {
            @unlink($file);
        }
        return true;
    }

    private function cacheFile(string $key): string
    {
        return $this->cacheDir . md5($key) . '.cache';
    }

    public function redisKey(string $key): string
    {
        return $this->redisPrefix . $key;
    }

    private function __clone() {}

    public function __wakeup(): void
    {
        throw new \RuntimeException('Cannot unserialize singleton Cache');
    }
}



// ═══════════════════════════════════════════════════════════════
//  Tagged Cache
// ═══════════════════════════════════════════════════════════════

/**
 * کش تگ‌دار — امکان flush گروهی کلیدها
 *
 * Redis: از Sets استفاده می‌کند (سریع و atomic)
 * File:  کلیدهای هر تگ را در یک فایل JSON ذخیره می‌کند
 */
class TaggedCache
{
    /** @param list<string> $tags */
    public function __construct(
        private Cache $cache,
        private array $tags,
        private string $tagCacheDir
    ) {}

    public function put(string $key, mixed $value, int $minutes = 60): bool
    {
        $taggedKey = $this->taggedKey($key);
        $this->registerKey($taggedKey);
        return $this->cache->put($taggedKey, $value, $minutes);
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->cache->get($this->taggedKey($key), $default);
    }

    /**
     * FIX-P4S-2: وضعیت خارجی (Redis/فایل) را می‌خواند و بین دو فراخوانی با
     * آرگومان یکسان می‌تواند نتیجهٔ متفاوت بدهد (پروسس دیگر ممکن است کلید را
     * بنویسد). یادسپاری نتیجهٔ فراخوانی اول توسط PHPStan الگوی double-check در
     * remember() را «همیشه false» گزارش می‌کرد — متد صریحاً impure اعلام می‌شود.
     *
     * @phpstan-impure
     */
    public function has(string $key): bool
    {
        return $this->cache->has($this->taggedKey($key));
    }

    public function forget(string $key): bool
    {
        $taggedKey = $this->taggedKey($key);
        $this->unregisterKey($taggedKey);
        return $this->cache->forget($taggedKey);
    }

    public function remember(string $key, int $minutes, callable $callback): mixed
    {
        if ($this->has($key)) {
            return $this->get($key);
        }

        // BUGFIX-PHASE3-P317: بدون قفل توزیع‌شده، N درخواست هم‌زمان همه callback
        // را اجرا می‌کردند (stampede). الگوی CORE-039 از remember اصلی اعمال شد.
        $lockKey = 'remember:' . $this->taggedKey($key);
        $lockAcquired = false;
        try {
            $lockAcquired = $this->cache->lock($lockKey, 30, 5);
        } catch (\RuntimeException $e) {
            $lockAcquired = false;
        }

        if ($lockAcquired) {
            try {
                // Double check بعد از گرفتن قفل
                if ($this->has($key)) {
                    return $this->get($key);
                }
                $value = $callback();
                $this->put($key, $value, $minutes);
                return $value;
            } finally {
                $this->cache->unlock($lockKey);
            }
        }

        // Fallback: backoff کوتاه و تلاش مجدد خواندن، وگرنه اجرا (رفتار بدون قفل)
        usleep(random_int(50000, 150000));
        if ($this->has($key)) {
            return $this->get($key);
        }
        return $callback();
    }

    public function rememberSeconds(string $key, int $seconds, callable $callback): mixed
    {
        if ($this->has($key)) {
            return $this->get($key);
        }

        // FIX-R36-W3 (F-A9a-13): قفل ضدمیلگرد CORE-039 — عین الگوی remember() بالا؛
        // بدون این قفل، N درخواستِ هم‌زمان روی کلید tag-دارِ ثانیه‌ای همه callback
        // را اجرا می‌کردند (stampede؛ مصرف‌کنندهٔ زنده ندارد ولی تلهٔ آینده است).
        $lockKey = 'remember:' . $this->taggedKey($key);
        $lockAcquired = false;
        try {
            $lockAcquired = $this->cache->lock($lockKey, 30, 5);
        } catch (\RuntimeException $e) {
            $lockAcquired = false;
        }

        if ($lockAcquired) {
            try {
                // Double check بعد از گرفتن قفل
                if ($this->has($key)) {
                    return $this->get($key);
                }
                $value = $callback();
                // FIX (Round-18 P2): exact-seconds contract (FIX-8a) — storage is delegated
                // to the main Cache::writeValue() path via setSeconds() instead of
                // ceil(seconds/60) minutes (a 5s TTL used to live 60s). Tag invalidation
                // semantics are unchanged: the tagged key is still registered first.
                $taggedKey = $this->taggedKey($key);
                $this->registerKey($taggedKey);
                $this->cache->setSeconds($taggedKey, $value, $seconds);
                return $value;
            } finally {
                $this->cache->unlock($lockKey);
            }
        }

        // Fallback: backoff کوتاه و تلاش مجدد خواندن، وگرنه اجرا (رفتار بدون قفل — هم‌الگوی remember())
        usleep(random_int(50000, 150000));
        if ($this->has($key)) {
            return $this->get($key);
        }
        return $callback();
    }

    /** حذف تمام کلیدهای این تگ */
    public function flush(): void
    {
        $redis = $this->cache->redis();
        if ($redis !== null) {
            foreach ($this->tags as $tag) {
                $setKey  = $this->cache->redisKey('tag:' . $tag);
                $members = $redis->sMembers($setKey);
                if (!empty($members)) {
                    $redis->del($members);
                }
                $redis->del($setKey);
            }
            return;
        }

        // File mode
        foreach ($this->tags as $tag) {
            $indexFile = $this->tagIndexFile($tag);
            if (!file_exists($indexFile)) {
                continue;
            }
            $raw = file_get_contents($indexFile);
            $decoded = $raw !== false ? json_decode($raw, true) : null;
            $keys = is_array($decoded) ? $decoded : [];
            foreach ($keys as $k) {
                $this->cache->forget($k);
            }
            @unlink($indexFile);
        }
    }

    // ─────────────────────────────────────────────────

    private function taggedKey(string $key): string
    {
        return implode('|', $this->tags) . ':' . $key;
    }

    private function registerKey(string $taggedKey): void
    {
        $redis = $this->cache->redis();
        if ($redis !== null) {
            $fullTaggedKey = $this->cache->redisKey($taggedKey);
            foreach ($this->tags as $tag) {
                $redis->sAdd($this->cache->redisKey('tag:' . $tag), $fullTaggedKey);
            }
            return;
        }

        // FIX C-8: TaggedCache در حالت File بدون قفل بود.
        // دو درخواست همزمان هر دو فایل را می‌خواندند، یکی را می‌نوشتند
        // و کلید دیگری گم می‌شد. فلاک مانع این race condition می‌شود.
        foreach ($this->tags as $tag) {
            $indexFile = $this->tagIndexFile($tag);
            $fh = fopen($indexFile, 'c+');
            if (!$fh) {
                continue;
            }
            if (flock($fh, LOCK_EX)) {
                $content  = stream_get_contents($fh);
                $existing = $content ? ((array)json_decode($content, true)) : [];
                if (!in_array($taggedKey, $existing, true)) {
                    $existing[] = $taggedKey;
                    ftruncate($fh, 0);
                    rewind($fh);
                    fwrite($fh, (string)json_encode($existing));
                }
                flock($fh, LOCK_UN);
            }
            fclose($fh);
        }
    }

    private function unregisterKey(string $taggedKey): void
    {
        $redis = $this->cache->redis();
        if ($redis !== null) {
            $fullTaggedKey = $this->cache->redisKey($taggedKey);
            foreach ($this->tags as $tag) {
                $redis->sRem($this->cache->redisKey('tag:' . $tag), $fullTaggedKey);
            }
            return;
        }

        foreach ($this->tags as $tag) {
            $indexFile = $this->tagIndexFile($tag);
            if (!file_exists($indexFile)) {
                continue;
            }
            
            $fh = fopen($indexFile, 'c+');
            if (!$fh) {
                continue;
            }
            if (flock($fh, LOCK_EX)) {
                $content  = stream_get_contents($fh);
                $existing = $content ? ((array)json_decode($content, true)) : [];
                $filtered = array_values(array_filter($existing, fn($k) => $k !== $taggedKey));
                
                if (count($filtered) !== count($existing)) {
                    ftruncate($fh, 0);
                    rewind($fh);
                    fwrite($fh, (string)json_encode($filtered));
                }
                flock($fh, LOCK_UN);
            }
            fclose($fh);
        }
    }

    private function tagIndexFile(string $tag): string
    {
        if (!is_dir($this->tagCacheDir)) {
            mkdir($this->tagCacheDir, 0755, true);
        }
        return rtrim($this->tagCacheDir, '/\\') . DIRECTORY_SEPARATOR . md5($tag) . '.json';
    }

    // M17 Fix: متد منقضی شده و بلااستفاده به نفع متد تجمیع شده و پابلیک کلاس والد حذف شد
}
