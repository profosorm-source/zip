<?php

declare(strict_types=1);

namespace Core;

use App\Contracts\LoggerInterface;
use App\Services\LogService;

/**
 * Logger — Facade/Wrapper (PSR-3 Compatible)
 *
 * این کلاس فقط یک wrapper ساده است که همه کال‌ها را به LogService می‌فرستد
 * هیچ منطقی اینجا نیست - فقط delegate کردن
 *
 * استفاده:
 *   - در سرویس‌ها: DI injection
 *   - در کنترلرها: DI injection
 *   - متدهای اضافی: system(), activity(), audit(), security(), performance()
 */
class Logger implements LoggerInterface
{
    private LogService $logService;
    private ?int $userId = null;
    /** @var array<string, mixed> */
    private array $defaultContext = [];

    /**
     * FIX-S15-1 (CWE-532): کلیدهای حساس که مقدارشان هرگز نباید به استریم لاگ
     * برسد. تطبیق «دقیق» (نه زیررشته) پس از نرمال‌سازی حروف/جداکننده‌ها است —
     * بنابراین کلیدهای بی‌ضرر هم‌خانواده مثل token_name و oauth_state سالم
     * می‌مانند. نام کلید در خروجی حفظ می‌شود تا مصرف‌کنندهٔ تشخیصی نشکند.
     */
    private const SENSITIVE_LOG_KEYS = [
        'password', 'password_confirmation', 'password_confirm', 'new_password',
        'current_password', 'old_password', 'password_old',
        'token', 'access_token', 'refresh_token', 'id_token', 'api_token',
        'auth_token', 'bearer_token', 'session_token', 'personal_access_token',
        'otp', 'otp_code', 'one_time_password', 'verification_code', 'verify_code',
        'card_number', 'card_cvv', 'cvv', 'cvc', 'card_pin', 'pin',
        'authorization', 'proxy_authorization', 'cookie', 'set_cookie',
        'api_key', 'apikey', 'client_secret', 'secret', 'private_key',
        'secret_key', 'signature_key', 'hmac_key',
    ];

    public function __construct(LogService $logService) {
    $this->logService = $logService;
}

    /**
     * تنظیم User ID برای لاگ‌های بعدی
     */
    public function setUserId(?int $userId): self
    {
        $this->userId = $userId;
        return $this;
    }


    /** @param array<string, mixed> $context */
    public function withContext(array $context): self
    {
        $this->defaultContext = array_merge($this->defaultContext, $context);
        return $this;
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function enrich(array $context): array
    {
        $traceContext = function_exists('get_trace_context') ? get_trace_context() : [
            'trace_id' => $_SERVER['HTTP_X_TRACE_ID'] ?? ($_SERVER['REQUEST_ID'] ?? null),
            'span_id' => $_SERVER['HTTP_X_SPAN_ID'] ?? null,
            'parent_span_id' => $_SERVER['HTTP_X_PARENT_SPAN_ID'] ?? null,
        ];

        $enriched = array_merge(
            [
                'request_id' => $_SERVER['REQUEST_ID'] ?? ($_SERVER['HTTP_X_REQUEST_ID'] ?? null),
                'trace_id' => $traceContext['trace_id'] ?? null,
                'span_id' => $traceContext['span_id'] ?? null,
                'parent_span_id' => $traceContext['parent_span_id'] ?? null,
            ],
            $this->defaultContext,
            $context
        );

        // FIX-S4-2: آخرین خط دفاعی در سطح facade — شناسه‌های همبستگی (چه از هدر کاربر
        // آمده باشند و چه از context فراخواننده مثل meta صف) پیش از رسیدن به sink لاگ
        // به الگوی canonical محدود می‌شوند؛ مقدار طولانی/چندخطی/غیرمجاز → null
        // (ضد تزریق لاگ، ضد سیل‌آب حجمی، حفظ UTF-8 معتبر برای json_encode).
        foreach (['request_id', 'trace_id', 'span_id', 'parent_span_id'] as $correlationKey) {
            $correlationValue = $enriched[$correlationKey] ?? null;
            if ($correlationValue === null) {
                continue;
            }
            if (is_string($correlationValue)) {
                $correlationValue = trim($correlationValue);
                if ($correlationValue !== '' && preg_match('/^[\w.\-:]{1,128}$/', $correlationValue) === 1) {
                    continue; // معتبر — دست‌نخورده
                }
            }
            $enriched[$correlationKey] = null;
        }

        return $this->redactSensitiveValues($enriched);
    }

    /**
     * FIX-S15-1 (CWE-532): آخرین خط دفاعی در سطح facade — هیچ مقداری از
     * کلیدهای حساس (در هر عمق از context) به sink لاگ نمی‌رسد. مقادیر اسکالر
     * به [redacted] و مقادیر غیراسکالر به [redacted:<type>] تبدیل می‌شوند؛
     * نام کلیدها حفظ می‌شود. کلیدهای غیرحساس بازگشتی پیمایش می‌شوند.
     *
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function redactSensitiveValues(array $context): array
    {
        $redacted = [];
        foreach ($context as $key => $value) {
            if (is_string($key) && self::isSensitiveLogKey($key)) {
                $redacted[$key] = '[redacted' . (is_scalar($value) || $value === null ? '' : ':' . strtolower(gettype($value))) . ']';
                continue;
            }
            $redacted[$key] = is_array($value) ? $this->redactSensitiveValues($value) : $value;
        }
        return $redacted;
    }

    /** تطبیق دقیق کلید حساس پس از نرمال‌سازی (case/جداکننده) — نه زیررشته. */
    private static function isSensitiveLogKey(string $key): bool
    {
        $normalized = strtolower(str_replace([' ', '-', '.'], '_', trim($key)));
        return in_array($normalized, self::SENSITIVE_LOG_KEYS, true);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PSR-3 METHODS
    // ─────────────────────────────────────────────────────────────────────────

    public function emergency(string|\Stringable $message, array $context = []): void
    {
        $this->logService->logSystem('emergency', $message, $this->enrich($context));
    }

    public function alert(string|\Stringable $message, array $context = []): void
    {
        $this->logService->logSystem('alert', $message, $this->enrich($context));
    }

    public function critical(string|\Stringable $message, array $context = []): void
    {
        $this->logService->logSystem('critical', $message, $this->enrich($context));
    }

    public function error(string|\Stringable $message, array $context = []): void
    {
        $this->logService->logSystem('error', $message, $this->enrich($context));
    }

    public function warning(string|\Stringable $message, array $context = []): void
    {
        $this->logService->logSystem('warning', $message, $this->enrich($context));
    }

    public function notice(string|\Stringable $message, array $context = []): void
    {
        $this->logService->logSystem('notice', $message, $this->enrich($context));
    }

    public function info(string|\Stringable $message, array $context = []): void
    {
        $this->logService->logSystem('info', $message, $this->enrich($context));
    }

    public function debug(string|\Stringable $message, array $context = []): void
    {
        $this->logService->logSystem('debug', $message, $this->enrich($context));
    }

    /**
     * FIX-C71 (یافتهٔ ۷۱): امضا با Psr\Log\LoggerInterface سازگار شد
     * (mixed $level + Stringable) — قبلاً امضای باریک‌تر ارث‌بری از
     * قرارداد PSR-3 را می‌شکست. سطح نامعتبر طبق PSR-3 استثنای مشخص می‌دهد.
     */
    public function log(mixed $level, string|\Stringable $message, array $context = []): void
    {
        $levelString = is_string($level) ? $level : str_value($level);
        if (!in_array(strtolower($levelString), ['debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency'], true)) {
            throw new \Psr\Log\InvalidArgumentException("Unknown log level: {$levelString}");
        }
        $this->logService->logSystem(strtolower($levelString), (string)$message, $this->enrich($context));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EXTENDED METHODS (غیر PSR-3 ولی مفید)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * لاگ سیستمی
     */
    /** @param array<string, mixed> $context */
    public function system(string $level, string $message, array $context = []): void
    {
        $this->logService->logSystem($level, $message, $this->enrich($context));
    }

    /**
     * لاگ فعالیت کاربر
     */
    public function activity(string $action, string $description, ?int $userId = null, array $metadata = []): void
    {
        $this->logService->logActivity($action, $description, $userId ?? $this->userId, $this->enrich($metadata));
    }

     /**
     * لاگ امنیتی
     */
    /** @param array<string, mixed> $context */
    public function security(string $level, string $message, array $context = []): void
    {
        $rawType = $context['type'] ?? 'security';
        $type = is_string($rawType) && preg_match('/^[a-z][a-z0-9_.-]{0,63}$/', $rawType) === 1
            ? $rawType
            : 'security';

        $this->logService->logSecurity($type, $message, $level, $this->enrich($context));
    }

    /**
     * لاگ Performance
     */
    /** @param array<string, mixed> $context */
    public function performance(string $metric, float $value, array $context = []): void
    {
        $this->logService->logPerformance($metric, $value, $this->enrich($context));
    }

    /**
 * لاگ Exception
 */
/** @param array<string, mixed> $context */
public function exception(\Throwable $e, string $message = '', array $context = []): void
{
    $context['exception'] = get_class($e);
    $context['exception_message'] = $e->getMessage();
    $context['file'] = $e->getFile();
    $context['line'] = $e->getLine();

    // M25 Fix: ثبت ردپا (Trace) خطاها حتی در پروداکشن جهت دیباگ اصولی حوادث در اولین فرصت
    // اما در حالت عملیاتی طول کمتری (مثلاً ۲۵۰۰ کاراکتر) را ذخیره می‌کنیم تا دیتابیس سنگین نشود
    $isDebug = (bool) config('app.debug', false);
    $traceLimit = $isDebug ? 8000 : 2500;
    $context['trace'] = mb_substr($e->getTraceAsString(), 0, $traceLimit);

    $this->error($message ?: $e->getMessage(), $context);
}
}

