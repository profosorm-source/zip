<?php

declare(strict_types=1);
namespace Core;

/**
 * Idempotency Key System - Version 2.0
 *
 * @package Core
 * @version 2.0
 *
 * @internal  این کلاس زیرساخت داخلی است و نباید مستقیم از لایه Application فراخوانی شود.
 *            تنها مصرف‌کننده‌های مجاز:
 *              - App\Services\Shared\IdempotencyService  (تنها نقطه ورود برای Application)
 *              - Core\TransactionWrapper::runIdempotentWithRetry()
 *
 *            برای استفاده در سرویس‌ها:
 *              $this->idempotencyService->execute(...)           // ساده
 *              $this->idempotencyService->executeWithLock(...)   // با distributed lock
 *              $this->idempotencyService->cleanup()              // نظافت دوره‌ای
 *              $this->idempotencyService->getStats()             // آمار
 */
class IdempotencyKey
{
    private \Core\Database $db;
    private ?\Core\Cache $cache = null;
    private string $table = 'idempotency_keys';
    
    // تنظیمات
    private const TIMEOUT_SECONDS = 300; // 5 دقیقه
    private const RETRY_DELAY_SECONDS = 60; // پس از چه مدت خطای retryable قابل تلاش دوباره است
    private const CLEANUP_DAYS = 90; // نگهداری پیش‌فرض برای عملیات مالی
    private const MAX_RETRIES = 3;

    private const STATUS_PENDING = 'pending';
    private const STATUS_COMPLETED = 'completed';
    private const STATUS_FAILED_RETRYABLE = 'failed_retryable';
    private const STATUS_FAILED_FINAL = 'failed_final';
    private const STATUS_LEGACY_PROCESSING = 'processing';
    private const STATUS_LEGACY_FAILED = 'failed';

    public function __construct(Database $db, Cache $cache) {
        $this->db = $db;
        $this->cache = $cache;
    }

    /** @param array<string, mixed> $context */
    private function logEvent(string $event, array $context, string $level = 'info'): void
    {
        try {
            if (function_exists('logger')) {
                $log = logger();
                $method = strtolower((string)$level);
                if (method_exists($log, $method)) {
                    $log->$method($event, $context);
                } else {
                    $log->info($event, $context);
                }
            }
        } catch (\Throwable $e) {
            // Fail-silent to avoid crashing the main operation due to logging failure
        }
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function redactSensitiveData(array $data): array

    {
        $sensitiveKeys = [
            'password', 'password_confirmation', 'pin', 'cvv2', 'card_number', 'card_num',
            'token', 'secret', 'authorization', 'api_key', 'key', 'pass', 'ssn', 'national_code',
            'cvv', 'card', 'pan', 'otp', 'code', 'email', 'mobile',
            // FIX-S34-B14-F07 (گزارش بخش ۱۴): داده‌های مالی-PII کارت بانکی — card_holder
            // و iban/sheba به‌صورت متن‌واضح در request_data ذخیره می‌شدند در حالی که
            // همان مقادیر در bank_cards رمزنگاری/محافظت می‌شوند. تشخیص برخورد کلید
            // unaffected می‌ماند چون data_hash از دادهٔ خامِ «پیش از» redaction ساخته می‌شود.
            'card_holder', 'owner_name', 'iban', 'sheba',
        ];

        $redacted = [];
        foreach ((array)$data as $k => $v) {
            if (is_array($v)) {
                $redacted[$k] = $this->redactSensitiveData($v);
            } elseif (is_string($k) && in_array(strtolower((string)$k), $sensitiveKeys, true)) {
                $redacted[$k] = '[REDACTED]';
            } else {
                $redacted[$k] = $v;
            }
        }
        return $redacted;
    }

    /**
     * BUGFIX-PHASE3-P310/P39: نرمالایز بازگشتی برای مقایسهٔ قطعی payload —
     * مرتب‌سازی کلیدها (بی‌اثرکردن ترتیب)، تبدیل stdClass به آرایه، نمایش قطعی
     * سایر آبجکت‌ها و یکسان‌سازی رشتهٔ عددی با عدد ('5' === 5 برای مقایسه).
     * رشته‌های عددی با صفر ابتدایی (مثل شماره موبایل '0912…') رشته می‌مانند.
     */
    private static function normalizeForComparison(mixed $value): mixed
    {
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k => $v) {
                $out[$k] = self::normalizeForComparison($v);
            }
            ksort($out, SORT_STRING);
            return $out;
        }

        if ($value instanceof \stdClass) {
            return self::normalizeForComparison((array)$value);
        }

        if (is_object($value)) {
            // سایر آبجکت‌ها: نمایش قطعی حالت (Closure در serialize می‌ترکد ⇒ خطای صریح، نه برخورد کاذب)
            return '@obj:' . serialize($value);
        }

        if (is_string($value) && is_numeric($value) && !preg_match('/^-?0\d+$/', $value)) {
            return $value + 0; // '5' => 5 ، '5.50' => 5.5
        }

        // 5.0 (float صحیح) با 5 (int) یکی می‌شود تا retry با نمایش متفاوتِ همان مقدار،
        // برخورد کاذب نسازد؛ INF/NaN دست‌نخورده می‌مانند.
        if (is_float($value) && is_finite($value) && floor($value) === $value) {
            return (int)$value;
        }

        return $value;
    }

    /**
     * مقایسهٔ payload ذخیره‌شده با payload ورودی بدون حساسیت به ترتیب کلیدها
     * و تفاوت نمایش عددی — برای ردیف‌های legacy بدون data_hash.
     * مقایسهٔ === روی خروجی نرمالایز (ksort بازگشتی ⇒ ترتیب بی‌اثر؛ رشتهٔ عددی
     * و float صحیح به int ⇒ '5'==5 ولی شمارهٔ با صفرِ ابتدایی با عدد یکی نمی‌شود).
     *
     * FIX-P4S-5: شکل جنریک آرگومان‌ها صریح شد (سطح 9).
     *
     * @param array<string, mixed> $stored
     * @param array<string, mixed> $incoming
     */
    private static function payloadMatches(array $stored, array $incoming): bool
    {
        return self::normalizeForComparison($stored) === self::normalizeForComparison($incoming);
    }

    /**
     * BUGFIX-PHASE3-P322: هش HMAC از دادهٔ خام درخواست (پیش از redaction) —
     * برخوردسنجی کامل بدون ذخیرهٔ PII. کلید HMAC همان secure_key است.
     *
     * FIX-P4S-5: شکل جنریک آرگومان صریح شد (سطح 9).
     *
     * @param array<string, mixed> $originalRequestData
     */
    private static function originalDataHash(array $originalRequestData): string
    {
        return hash_hmac('sha256', serialize(self::normalizeForComparison($originalRequestData)), secure_key());
    }

    public static function generate(?string $seed = null): string
    {
        if ($seed !== null) {
            $key = secure_key();
            // تولید deterministic key برای debugging
            return hash('sha256', $seed . $key);
        }
        
        // تولید random key با امنیت بالا
        return bin2hex(random_bytes(32)); // 64 کاراکتر hex
    }

    /**
     * ساخت یک کلید امن و قطعی بر اساس اطلاعات دقیق عملیات
     * جلوگیری قطعی از استفاده از time() و خطر Race Condition
     *
     * @param string $action نام بیزینسی عملیات (مثلاً 'referral_commission')
     * @param array<string, mixed> $context دیتاهایی که این تراکنش را منحصربه‌فرد می‌کنند (userId, transactionId, ...)
     */
    public static function generateFromPayload(string $action, array $context): string
    {
        // CORE-049: Auto-incorporate request URI and Method in context to prevent collision bypass
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $method = $_SERVER['REQUEST_METHOD'] ?? '';

        $appKey = secure_key();

        // BUGFIX-PHASE3-P39: قبلاً array_filter فقط مقادیر scalar/null را نگه می‌داشت و
        // فیلدهای تودرتو (آرایه/آبجکت) بی‌صدا حذف می‌شدند ⇒ دو کانتکست که فقط در
        // فیلدهای تودرتو تفاوت داشتند «کلید یکسان» می‌گرفتند و عملیات دوم به‌اشتباه
        // duplicate تشخیص داده می‌شد (dedup کاذب). اکنون کانتکست کامل به‌صورت
        // بازگشتی نرمالایز می‌شود؛ کانتکستِ all-scalar دقیقاً با الگوریتم قدیمی
        // هش می‌شود تا کلیدهای قبلی سازگار بمانند.
        $hasComplexValue = false;
        foreach ($context as $v) {
            if (is_array($v) || is_object($v)) {
                $hasComplexValue = true;
                break;
            }
        }

        if (!$hasComplexValue) {
            ksort($context);
            $payloadStr = serialize($context);
        } else {
            $payloadStr = serialize(self::normalizeForComparison($context));
        }

        // ترکیب امن: اکشن + مسیر + متد + داده‌ها + اپ‌کی
        $finalSeed = $action . '|' . $uri . '|' . $method . '|' . $payloadStr . '|' . $appKey;

        return hash('sha256', $finalSeed);
    }

    /**
     * بررسی و ذخیره کلید با قابلیت‌های پیشرفته
     *
     * FIX C-1: Race Condition — از INSERT IGNORE + SELECT FOR UPDATE استفاده می‌کنیم
     *          تا بین CHECK و INSERT هیچ پنجره‌ای برای race condition نباشد.
     * FIX C-2: Infinite Recursion — پارامتر $retryCount اضافه شد و حداکثر
     *          MAX_RETRIES بار تلاش می‌شود.
     * FIX C-3: Fail-Open — در صورت خطای DB که duplicate entry نباشد،
     *          به جای ['is_duplicate'=>false]، exception پرتاب می‌شود
     *          تا عملیات مالی بدون چک idempotency اجرا نشود.
     */
    /**
     * @param array<string, mixed>|null $requestData
     * @return array<string, mixed>
     */
    public function check(string $key, int $userId, string $action, ?array $requestData = null, int $retryCount = 0): array
    {
        // FIX C-2: محدودیت عمق recursion
        if ($retryCount >= self::MAX_RETRIES) {
            throw new \RuntimeException("Idempotency check failed after {$retryCount} retries for key: {$key}");
        }

        $logId = uniqid('IDEM_', true);
        $lockKey = "idempotency_lock:{$userId}:" . hash('sha256', $key);
        $cache = $this->cache;
        $isLocked = false;

        // 🔧 FIX 8-c (M — rollback-ownership): مالکیت تراکنش فقط تا سطحی که «خودمان"
        // باز کرده‌ایم معتبر است. قبلاً catchِ پایین متد با گارد inTransaction()
        // rollback می‌زد — وقتی beginTransaction شکست می‌خورد یا commitِ خودِ helper
        // انجام شده بود ولی تراکنشِ بیرونیِ مالک فعال می‌ماند، rollback در «سطح تراکنش
        // بیرونی» اجرا و کارِ مالک نابود می‌شد. اکنون سطحِ قبل از begin ثبت می‌شود و
        // rollback فقط وقتی مجاز است که سطحِ خودِ helper هنوز روی پشته باشد.
        $transactionLevelBefore = $this->db->transactionLevel();

        if ($retryCount === 0) {
            if (!$cache || !$cache->lock($lockKey, 30, 5)) {
                throw new \RuntimeException("Concurrency lock failed. Another request is being processed.", 409);
            }
            $isLocked = true;
        }

        try {
            // CORE-048: Start a dedicated DB transaction so SELECT FOR UPDATE holds a real row lock
            $this->db->beginTransaction();

            // Redact sensitive parameters to prevent plain-text PII storage in the database
            $safeRequestData = is_array($requestData) ? $this->redactSensitiveData($requestData) : [];

            // BUGFIX-PHASE3-P322: هش HMAC از دادهٔ «خام» (پیش از redaction) تا برخوردسنجی
            // روی فیلدهای حساس هم ممکن باشد؛ مقدار حساس هرگز ذخیره نمی‌شود — فقط هش آن.
            // ردیف‌های قدیمی بدون data_hash به مقایسهٔ قبلی (روی دادهٔ redacted) برمی‌گردند.
            $originalDataHash = self::originalDataHash(is_array($requestData) ? $requestData : []);

            // CORE-049: Enrich payload tracking with structural request signatures to block cross-endpoint key reuse
            $payloadSignature = [
                'uri'       => $_SERVER['REQUEST_URI'] ?? '',
                'method'    => $_SERVER['REQUEST_METHOD'] ?? '',
                'data'      => $safeRequestData,
                'data_hash' => $originalDataHash,
            ];
            $encodedSignature = json_encode(
                $payloadSignature,
                JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
            );

            // FIX C-1: ابتدا INSERT با ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id) می‌کنیم
            // تا شناسه دقیق سطر را بگیریم و با FOR UPDATE قفل کنیم
            $insertSql = "INSERT INTO {$this->table}
                          (`key`, `user_id`, `action`, `status`, `request_data`, `created_at`, `expires_at`)
                          VALUES (:key, :user_id, :action, '" . self::STATUS_PENDING . "', :request_data, NOW(),
                                  DATE_ADD(NOW(), INTERVAL " . self::CLEANUP_DAYS . " DAY))
                          ON DUPLICATE KEY UPDATE `id` = LAST_INSERT_ID(`id`)";

            $stmt = $this->db->prepare($insertSql);
            $stmt->execute([
                'key'          => $key,
                'user_id'      => $userId,
                'action'       => $action,
                'request_data' => $encodedSignature,
            ]);

            $lastId = (int)$this->db->lastInsertId();
            $wasInserted = ($stmt->rowCount() === 1);

            $selectSql = "SELECT * FROM {$this->table}
                          WHERE `id` = :id
                          FOR UPDATE";

            $stmt = $this->db->prepare($selectSql);
            $stmt->execute(['id' => $lastId]);
            $existing = $stmt->fetch(\PDO::FETCH_ASSOC);

            if (!$existing) {
                $this->db->commit();
                throw new \RuntimeException("Idempotency key not found after insert: {$key}");
            }
            $existing = (array)$existing;

            if (!$wasInserted) {
                // FIX-C01-1 (actor-bound keys): کلید صریح باید به همان actor مقید بماند.
                // قبلاً فقط URI/method/payload مقایسه می‌شد و user_id سطرِ موجود هرگز
                // بررسی نمی‌شد؛ کاربر B می‌توانست کلید COMPLETED کاربر A را با همان
                // ردپای درخواست replay کند و نتیجهٔ مالیِ A را دریافت کند (چون
                // UNIQUE(`key`) سراسری است). اکنون ناسازگاری مالک = collision قطعی.
                $storedOwnerId = (int)($existing['user_id'] ?? 0);
                if ($storedOwnerId !== $userId) {
                    $this->db->commit();
                    $this->logEvent('idempotency.collision', [
                        'key'      => $key,
                        'user_id'  => $userId,
                        'owner_id' => $storedOwnerId,
                        'action'   => $action,
                        'reason'   => 'actor_mismatch',
                    ], 'warning');
                    throw new \RuntimeException("Idempotency Collision: Key '{$key}' is bound to a different actor.", 409);
                }

                $storedRequestData = $existing['request_data'] ?? null;
                if (!is_string($storedRequestData) || $storedRequestData === '') {
                    throw new \RuntimeException('Stored idempotency request signature is missing or invalid.');
                }

                try {
                    $storedSignature = json_decode(
                        $storedRequestData,
                        true,
                        512,
                        JSON_THROW_ON_ERROR
                    );
                } catch (\JsonException $jsonException) {
                    throw new \RuntimeException(
                        'Stored idempotency request signature is corrupted.',
                        0,
                        $jsonException
                    );
                }
                if (!is_array($storedSignature)) {
                    throw new \RuntimeException('Stored idempotency request signature must be a JSON object.');
                }

                $storedUri = $storedSignature['uri'] ?? null;
                $storedMethod = $storedSignature['method'] ?? null;
                $storedPayload = $storedSignature['data'] ?? null;
                if (!is_string($storedUri) || !is_string($storedMethod) || !is_array($storedPayload)) {
                    throw new \RuntimeException('Stored idempotency request signature has an invalid schema.');
                }

                if ($storedUri !== $payloadSignature['uri'] || $storedMethod !== $payloadSignature['method']) {
                    $this->db->commit();
                    $this->logEvent('idempotency.collision', [
                        'key'      => $key,
                        'user_id'  => $userId,
                        'action'   => $action,
                        'reason'   => 'uri_or_method_mismatch',
                    ], 'warning');
                    throw new \RuntimeException("Idempotency Collision: Reusing key '{$key}' for a different URI/Method footprint.", 409);
                }

                $storedDataHash = $storedSignature['data_hash'] ?? null;
                if (is_string($storedDataHash) && $storedDataHash !== '') {
                    // BUGFIX-PHASE3-P322: برخوردسنجی قوی روی دادهٔ خام از طریق HMAC
                    if (!hash_equals($storedDataHash, $originalDataHash)) {
                        $this->db->commit();
                        $this->logEvent('idempotency.collision', [
                            'key'      => $key,
                            'user_id'  => $userId,
                            'action'   => $action,
                            'reason'   => 'payload_mismatch',
                        ], 'warning');
                        throw new \RuntimeException("Idempotency Collision: Reusing key '{$key}' with modified payload data.", 409);
                    }
                } elseif (!self::payloadMatches($storedPayload, $payloadSignature['data'])) {
                    // BUGFIX-PHASE3-P310: مقایسه با json_encode خام حساس به ترتیب کلیدها
                    // و تفاوت نوع ('5' vs 5) بود ⇒ retry مشروع 409 کاذب می‌گرفت.
                    // FIX-P4S-4: گاردهای is_array روی هر دو آرگومان مرده بودند —
                    // $storedPayload در گارد اسکیما (خط بالاتر) و 'data' در ساخت
                    // $payloadSignature (خروجی همیشه-آرایهٔ redactSensitiveData/[])
                    // هم‌اکنون به‌صورت استاتیک هم array تایید می‌شوند.
                    $this->db->commit();
                    $this->logEvent('idempotency.collision', [
                        'key'      => $key,
                        'user_id'  => $userId,
                        'action'   => $action,
                        'reason'   => 'payload_mismatch',
                    ], 'warning');
                    throw new \RuntimeException("Idempotency Collision: Reusing key '{$key}' with modified payload data.", 409);
                }
            }

            if ($wasInserted) {
                $this->logEvent('idempotency.key.created', [
                    'log_id' => $logId,
                    'key'    => $key,
                    'action' => $action,
                ]);
                $this->db->commit();
                return ['is_duplicate' => false, 'status' => self::STATUS_PENDING];
            }

            $status = $existing['status'] ?? '';
            $this->logEvent('idempotency.key.exists', [
                'log_id' => $logId,
                'key'    => $key,
                'status' => $status,
            ]);

            $result = null;
            if (!empty($existing['result'])) {
                $decoded = (array)(json_decode($existing['result'], true) ?? []);
                $result = json_last_error() === JSON_ERROR_NONE ? $decoded : $existing['result'];
            }

            if ($status === self::STATUS_COMPLETED) {
                $this->db->commit();
                if (is_array($result)) {
                    $result['idempotent_replay'] = true;
                }
                return [
                    'is_duplicate' => true,
                    'status'       => self::STATUS_COMPLETED,
                    'result'       => $result,
                    'cached_at'    => $existing['completed_at'] ?? $existing['created_at'],
                    'http_status'  => 200, // 200 OK: returning cached successful result
                ];
            }

            if ($status === self::STATUS_FAILED_FINAL || $status === self::STATUS_LEGACY_FAILED) {
                $this->db->commit();
                return [
                    'is_duplicate' => true,
                    'status'       => self::STATUS_FAILED_FINAL,
                    'result'       => $result,
                    'is_error'     => true,
                    'http_status'  => 400, // 400 Bad Request: unrecoverable failure, do not retry
                    'retry_allowed' => false,
                ];
            }

            if ($status === self::STATUS_FAILED_RETRYABLE) {
                $elapsed = time() - strtotime($existing['created_at']);
                $retryAfter = max(0, self::RETRY_DELAY_SECONDS - $elapsed);
                
                if ($elapsed > self::RETRY_DELAY_SECONDS) {
                    // Sufficient time has passed, allow retry
                    $this->updateStatusWithMetadata($key, $userId, self::STATUS_PENDING, [
                        'retry_allowed' => true,
                        'previous_attempt_at' => $existing['created_at'],
                        'elapsed_seconds' => $elapsed,
                    ]);
                    $this->db->commit();
                    return ['is_duplicate' => false, 'status' => self::STATUS_PENDING];
                }

                // Still within cooldown period
                $this->db->commit();
                return [
                    'is_duplicate' => true,
                    'status'       => self::STATUS_FAILED_RETRYABLE,
                    'result'       => $result,
                    'is_error'     => true,
                    'http_status'  => 202, // 202 Accepted: still processing, retry later
                    'retry_after'  => $retryAfter,
                    'retry_allowed' => true,
                ];
            }

            if ($status === self::STATUS_PENDING || $status === self::STATUS_LEGACY_PROCESSING) {
                $elapsed = time() - strtotime($existing['created_at']);
                if ($elapsed < self::TIMEOUT_SECONDS) {
                    // Operation still in progress
                    $this->db->commit();
                    return [
                        'is_duplicate'  => true,
                        'status'        => self::STATUS_PENDING,
                        'result'        => [
                            'success'         => false,
                            'message'         => 'درخواست شما در حال پردازش است. لطفاً صبر کنید.',
                            'elapsed_seconds' => $elapsed,
                            'retry_after'     => min(self::TIMEOUT_SECONDS - $elapsed, 30),
                        ],
                        'is_processing' => true,
                        'http_status'   => 409, // 409 Conflict: operation already in progress
                    ];
                }

                // Timeout occurred, reset to allow retry
                $this->updateStatusWithMetadata($key, $userId, self::STATUS_PENDING, ['timeout_occurred' => true]);
                $this->db->commit();
                return ['is_duplicate' => false, 'status' => self::STATUS_PENDING];
            }

            $this->db->commit();
            return ['is_duplicate' => false, 'status' => self::STATUS_PENDING];

        } catch (\Throwable $e) {
            // 🔧 FIX 8-c (M — rollback-ownership): helper فقط تراکنشی را rollback می‌کند که
            // «خودش باز کرده و هنوز باز است» (سطح > سطحِ قبل از begin). اگر begin شکست
            // خورده باشد یا commitِ خودِ helper تمام شده باشد (و فقط تراکنشِ مالکِ بیرونی
            // فعال باشد)، rollback توسط OWNER همان تراکنش انجام می‌شود نه این helper.
            if ($this->db->transactionLevel() > $transactionLevelBefore && $this->db->inTransaction()) {
                $this->db->rollback();
            }

            $errCode = (string)($e->errorInfo[1] ?? '');
            if (($e instanceof \PDOException) && ($errCode === '1062' || $errCode === '1586' || str_contains($e->getMessage(), 'Duplicate entry') || str_contains($e->getMessage(), '1062'))) {
                $this->logEvent('idempotency.key.race_retry', [
                    'log_id' => $logId,
                    'key'    => $key,
                    'retry'  => $retryCount,
                ], 'warning');
                usleep(50000 * ($retryCount + 1));
                return $this->check($key, $userId, $action, $requestData, $retryCount + 1);
            }

            $this->logEvent('idempotency.check.database_error', [
                'log_id' => $logId,
                'key'    => $key,
                'error'  => $e->getMessage(),
            ], 'error');
            
            if ($e instanceof \RuntimeException) {
                throw $e;
            }
            
            throw new \RuntimeException(
                "Idempotency check failed: " . $e->getMessage(),
                (int)$e->getCode(),
                $e
            );
        } finally {
            if ($isLocked) {
                $this->cache?->unlock($lockKey);
            }
        }
    }

    /**
     * به‌روزرسانی وضعیت کلید
     */
    /** @param array<string, mixed>|null $metadata */
    private function updateStatus(string $key, int $userId, string $status, ?array $metadata = null): bool
    {
        $sql = "UPDATE {$this->table} 
                SET `status` = :status, `created_at` = NOW()";
        
        $params = [
            'key' => $key,
            'user_id' => $userId,
            'status' => $status
        ];
        
        if ($metadata) {
            $sql .= ", `result` = :metadata";
            $params['metadata'] = json_encode($metadata, JSON_UNESCAPED_UNICODE);
        }
        
        $sql .= " WHERE `key` = :key AND `user_id` = :user_id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Proxy for updateStatus to maintain compatibility
     */
    /** @param array<string, mixed>|null $metadata */
    private function updateStatusWithMetadata(string $key, int $userId, string $status, ?array $metadata = null): bool
    {
        return $this->updateStatus($key, $userId, $status, $metadata);
    }

    private function isRetryableException(\Throwable $exception): bool
    {
        // ✅ **Explicit Retryable Exceptions** — عملیات دوباره قابل تلاش است
        if ($exception instanceof \Core\Exceptions\TransientException) {
            return true;  // Temporary failures (network timeouts, brief unavailability)
        }

        if ($exception instanceof \Core\Exceptions\RateLimitedFailure) {
            return true;  // Rate limiting — retry after backoff
        }

        if ($exception instanceof \Core\Exceptions\ProviderUnavailable) {
            return true;  // Gateway/provider temporarily unavailable
        }

        if ($exception instanceof \PDOException) {
            return true;  // Database errors (connection timeout, deadlock, etc.)
        }

        // ✅ **Non-Retryable Exceptions** — خطاهایی که دوباره تلاش مفید نیست
        if ($exception instanceof \Core\Exceptions\BusinessException) {
            return false;  // Business logic violations (insufficient balance, invalid state)
        }

        if ($exception instanceof \Core\Exceptions\ValidationException) {
            return false;  // Validation errors (invalid input, schema mismatch)
        }

        // ❌ **Default: Non-Retryable**
        // اگر exception نوع شناخت‌شده‌ای نیست، آن را non-retryable فرض می‌کنیم
        // تا عملیات مالی به دلایل نامعلوم دوباره اجرا نشوند
        return false;
    }

    private function prepareResultForStorage(mixed $result): mixed
    {
        if (is_array($result) || is_object($result)) {
            return json_encode($this->normalizeResultForStorage($result), JSON_UNESCAPED_UNICODE);
        }

        if (is_bool($result) || is_numeric($result)) {
            return (string)json_encode($result, JSON_UNESCAPED_UNICODE);
        }

        return str_value($result);
    }

    /** @return array<string, mixed> */
    private function normalizeResultForStorage(mixed $result): array
    {
        $payload = is_object($result) ? get_object_vars($result) : $result;
        $allowed = [
            'transaction_id', 'escrow_id', 'status', 'success', 'ok', 'message', 'error',
            'amount', 'currency', 'net_amount', 'commission', 'refund_amount',
            'wallet_transaction', 'request_id', 'order_id', 'listing_id', 'execution_id',
            'to_user_id', 'from_user_id', 'seller_id', 'buyer_id'
        ];

        $normalized = [];
        foreach ((array)$payload as $key => $value) {
            if (is_scalar($value) || $value === null) {
                $normalized[$key] = $value;
                continue;
            }

            if (is_array($value) && $this->isFlatScalarArray($value)) {
                $normalized[$key] = $value;
                continue;
            }

            $normalized[$key] = [
                'type' => is_object($value) ? 'object' : 'array',
                'count' => is_countable($value) ? count($value) : null,
            ];
        }

        if (count($normalized) > 20) {
            $normalized = array_slice($normalized, 0, 20, true);
            $normalized['truncated'] = true;
        }

        return $normalized;
    }

    /** @param array<int|string, mixed> $value */
    private function isFlatScalarArray(array $value): bool
    {
        foreach ($value as $item) {
            if (is_array($item) || is_object($item)) {
                return false;
            }
        }
        return true;
    }

    private function isFailedCallbackResult(mixed $result): bool
    {
        if (!is_array($result)) {
            return false;
        }

        foreach (['success', 'ok'] as $key) {
            if (array_key_exists($key, $result) && $result[$key] === false) {
                return true;
            }
        }

        return false;
    }

    /**
     * 🛡️ FIX-IDEM-PAUSE: آیا نتیجهٔ callback یک «توقفِ عادی» است (نه شکست)؟
     * قرارداد: آرایهٔ نتیجه با کلید 'pause' => true و ترجیحاً 'pause_reason'.
     * فقط برای وضعیت‌هایی که اجرا را موقتاً متوقف می‌کنند و منتظرِ اقدامِ
     * بیرونی (کاربر) هستند — هرگز برای شکست‌های واقعی.
     */
    private function isPauseCallbackResult(mixed $result): bool
    {
        // 🛡️ بازبینی W1-REV #12 (دفاع عمقی): pause بدون دلیلِ صریح معتبر نیست —
        // کال‌بکِ آینده‌ای که تصادفاً 'pause' برگرداند، بدون pause_reason رها نمی‌شود
        // و به مسیر شکستِ معمول می‌رود (پنجرهٔ اجرای دوبارهٔ ناخواسته بسته می‌ماند).
        return is_array($result)
            && array_key_exists('pause', $result)
            && $result['pause'] === true
            && trim(str_value($result['pause_reason'] ?? '')) !== '';
    }

    /**
     * 🛡️ FIX-IDEM-PAUSE: رهاکردنِ کلیدِ متوقف‌شده — حذفِ سطر تا ریسابمیتِ
     * بعد از اقدامِ کاربر، اجرای تازه باشد. حذفِ best-effort است: اگر به‌هر
     * دلیل حذف نشد، سطر در وضعیت pending می‌ماند و بعد از TIMEOUT_SECONDS
     * به‌طور عادی قابل retry می‌شود (رفتار امنِ موجود).
     */
    private function release(string $key, int $userId): void
    {
        try {
            $stmt = $this->db->prepare(
                "DELETE FROM {$this->table} WHERE `key` = :key AND `user_id` = :user_id AND `status` IN ('" . self::STATUS_PENDING . "', '" . self::STATUS_LEGACY_PROCESSING . "')"
            );
            $stmt->execute(['key' => $key, 'user_id' => $userId]);
        } catch (\PDOException $e) {
            $this->logEvent('idempotency.release.failed', [
                'key'   => $key,
                'error' => $e->getMessage(),
            ], 'warning');
        }
    }

    /**
     * FIX-C02: نهایی‌سازی وضعیت کلید با retry کوتاه.
     *
     * مسیر موفق (finalize=false): اگر complete() بعد از همه تلاش‌ها false بماند،
     * RuntimeException پرتاب می‌شود تا نتیجهٔ «موفق» برای صدا زننده گزارش نشود؛
     * سطر pending می‌ماند و replay داخل پنجرهٔ timeout پاسخ 409 processing می‌گیرد.
     *
     * مسیر شکست (finalize=true): فقط retry + لاگ بحرانی؛ استثنای اصلیِ callback
     * باید دست‌نخورده به بالا برود (پوشاندن آن با استثنای finalize نادرست است).
     *
     * @param string $key
     * @param mixed $result
     * @param int $userId
     * @param bool  $isFailure true ⇒ fail() ، false ⇒ complete()
     */
    private function finalizeWithRetry(string $key, mixed $result, int $userId, bool $isFailure, string $logId): void
    {
        $maxAttempts = 3;
        $ok = false;
        for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
            $ok = $isFailure
                ? $this->fail($key, $result, $userId, true)
                : $this->complete($key, $result, $userId);
            if ($ok) {
                return;
            }
            if ($attempt < $maxAttempts) {
                usleep(100000 * $attempt);
            }
        }

        $this->logEvent('idempotency.finalize.failed', [
            'log_id'    => $logId,
            'key'       => $key,
            'user_id'   => $userId,
            'op'        => $isFailure ? 'fail' : 'complete',
            'attempts'  => $maxAttempts,
        ], 'error');

        if (!$isFailure) {
            throw new \RuntimeException(
                "Idempotency finalization failed: operation result was produced but the idempotency row for key '{$key}' could not be marked completed.",
                500
            );
        }
    }

    /**
     * ذخیره نتیجه موفق
     *
     * @param string $key
     * @param mixed $result
     * @param int $userId
     * @return bool
     */
    public function complete(string $key, $result, int $userId): bool
    {
        try {
            $sql = "UPDATE {$this->table} 
                    SET `status` = :status,
                        `result` = :result,
                        `completed_at` = NOW()
                    WHERE `key` = :key AND `user_id` = :user_id";

            $params = [
                'key' => $key,
                'user_id' => $userId,
                'status' => self::STATUS_COMPLETED,
                'result' => $this->prepareResultForStorage($result),
            ];

            $stmt = $this->db->prepare($sql);
            $success = $stmt->execute($params);

            if ($success) {
                $this->logEvent('idempotency.key.completed', [
                    'key' => $key,
                ]);
            }

            return $success;

        } catch (\PDOException $e) {
            $this->logEvent('idempotency.complete.failed', [
                'key' => $key,
                'error' => $e->getMessage(),
            ], 'error');
            return false;
        }
    }

    /**
     * علامت‌گذاری به عنوان شکست خورده
     * 
     * @param string $key
     * @param string|array<string, mixed> $error
     * @param int $userId
     * @return bool
     */
    /** @param array<string, mixed>|mixed $error Non-array input is wrapped under 'error'. */
    public function fail(string $key, $error, int $userId, bool $retryable = false): bool
    {
        try {
            $errorData = is_array($error) ? $error : ['error' => $error];
            $status = $retryable ? self::STATUS_FAILED_RETRYABLE : self::STATUS_FAILED_FINAL;

            // 🛡️ FIX-IDEM-PAUSE (بخش دوم — نگهداری): شکستِ retryable یعنی «کلید
            // عملیاتی فقط تا پنجرهٔ RETRY_DELAY معنا دارد»؛ نگه‌داشتنش ۹۰ روز
            // فقط ردیف یتیم می‌سازد. انقضای ۱روزه برای retryable؛ failed_final
            // برای ممیزی ۹۰روزه می‌ماند.
            $retention = $retryable
                ? "`expires_at` = DATE_ADD(NOW(), INTERVAL 1 DAY),"
                : "`expires_at` = DATE_ADD(NOW(), INTERVAL " . self::CLEANUP_DAYS . " DAY),";

            $sql = "UPDATE {$this->table} 
                    SET `status` = :status,
                        `result` = :result,
                        {$retention}
                        `completed_at` = NOW()
                    WHERE `key` = :key AND `user_id` = :user_id";

            $params = [
                'key' => $key,
                'user_id' => $userId,
                'status' => $status,
                'result' => $this->prepareResultForStorage($errorData),
            ];

            $stmt = $this->db->prepare($sql);
            $success = $stmt->execute($params);

            if ($success) {
                $this->logEvent('idempotency.key.failed', [
                    'key' => $key,
                    'status' => $status,
                ], 'warning');
            }

            return $success;

        } catch (\PDOException $e) {
            $this->logEvent('idempotency.fail_mark.failed', [
                'key' => $key,
                'error' => $e->getMessage(),
            ], 'error');
            return false;
        }
    }

    public function abort(string $key, int $userId): bool
    {
        try {
            $sql = "DELETE FROM {$this->table} WHERE `key` = :key AND `user_id` = :user_id";
            $stmt = $this->db->prepare($sql);
            $success = $stmt->execute(['key' => $key, 'user_id' => $userId]);
            
            if ($success) {
                $this->logEvent('idempotency.key.aborted', ['key' => $key], 'warning');
            }
            return $success;
        } catch (\PDOException $e) {
            $this->logEvent('idempotency.abort.failed', ['key' => $key, 'error' => $e->getMessage()], 'error');
            return false;
        }
    }


    /**
     * Scope-aware idempotency wrapper for general application use-cases.
     */
    /** @param array<string, mixed> $requestData */
    /** @param array<string, mixed>|null $requestData */
    public function run(string $scope, int $actorId, string $key, callable $callback, ?array $requestData = null): mixed
    {
        $scope = preg_replace('/[^A-Za-z0-9_.:-]/', '_', trim((string)$scope)) ?: 'default';
        $scopedKey = hash('sha256', $scope . '|' . $actorId . '|' . $key);
        return $this->wrapInstance($scopedKey, $actorId, $scope, $callback, $requestData);
    }

    /**
     * FIX-M1BR01 (سناریوی مرورگری M1-BR-01 — ثبت مالی با پاسخ قطع‌شده پس از commit):
     * peek فقط‌خواندنیِ نتیجهٔ «completed» یک کلید، بدون INSERT/lock/transaction.
     *
     * چرا لازم است؟ در wallet::transfer گارد ضدتقلب (velocity) «پیش از» لایهٔ
     * idempotency اجرا می‌شود؛ در نتیجه retryای که با همان کلید کلاینت بعد از
     * یک قطع‌شدن پاسخ (commit واقعی سمت DB، پاسخ گمشده سمت کاربر) می‌رسد،
     * پیش از رسیدن به مسیر replay، با پیام «محدودیت‌های امنیتی» رد می‌شد —
     * یعنی کاربرِ صاحبِ یک انتقالِ موفق، پاسخ گمراه‌کنندهٔ «رد شد» می‌دید و
     * انگیزهٔ ساخت انتقال دوم با کلید تازه (ریسک واقعی double-spend) پیدا می‌کرد.
     *
     * قرارداد:
     *   - فقط-خواندنی است: هیچ ردیفی نمی‌سازد، قفل نمی‌گیرد، تراکنش باز نمی‌کند؛
     *     مسیر wrap بعدی (check/insert/locking) دست‌نخورده می‌ماند.
     *   - فقط status=completed و result غیرخالی → آرایهٔ ذخیره‌شده با پرچم
     *     idempotent_replay=true؛ در غیر این صورت null (جریان عادی ادامه می‌یابد).
     *   - مقید به همان actor است (user_id در WHERE) — کلیدِ کاربر دیگر هرگز
     *     replay نمی‌شود؛ مرجع نهایی مالکیت، collision-check داخل check() باقی می‌ماند.
     *   - فرمول scoping دقیقاً همان run() است تا peek همیشه همان ردیفی را ببیند
     *     که wrap می‌نویسد. هر خطای DB → null (fail-open به جریان عادی).
     */
    public function peekCompleted(string $scope, int $actorId, string $key, ?array $expectedPayload = null): ?array
    {
        $scope = preg_replace('/[^A-Za-z0-9_.:-]/', '_', trim((string)$scope)) ?: 'default';
        $scopedKey = hash('sha256', $scope . '|' . $actorId . '|' . $key);

        try {
            $stmt = $this->db->prepare(
                "SELECT status, result, request_data FROM {$this->table}
                 WHERE `key` = :k AND user_id = :u
                 LIMIT 1"
            );
            $stmt->execute(['k' => $scopedKey, 'u' => $actorId]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            $this->logEvent('idempotency.peek.failed', [
                'key'   => $scopedKey,
                'error' => $e->getMessage(),
            ], 'error');
            return null;
        }

        if (!$row || ($row['status'] ?? '') !== self::STATUS_COMPLETED) {
            return null;
        }

        // FIX-M12-02 (گزارش ماژول ۱۲): تطبیق payload در مسیر peek — قبلاً بازپخشِ
        // shortcut فقط scope/actor/key را می‌سنجید و همان کلید با مبلغ/ارز/گیرندهٔ
        // متفاوت بی‌صدا نتیجهٔ عملیات قبلی را می‌گرفت (intent جدید اجرا نمی‌شد و
        // collision-check مرکزی دور زده می‌شد). mismatch → نشانگر صریح برای caller
        // تا قرارداد 409 همان collision-check مرکزی اجرا شود.
        if ($expectedPayload !== null) {
            if (!$this->storedPayloadMatches((string)($row['request_data'] ?? ''), $expectedPayload)) {
                $this->logEvent('idempotency.replay.payload_mismatch', [
                    'key'     => $scopedKey,
                    'user_id' => $actorId,
                ], 'warning');
                return ['__idempotency_payload_mismatch' => true];
            }
        }

        $raw = $row['result'] ?? null;
        if (!is_string($raw) || $raw === '') {
            return null;
        }

        $decoded = json_decode($raw, true);
        $result = json_last_error() === JSON_ERROR_NONE ? $decoded : $raw;
        if (is_array($result)) {
            $result['idempotent_replay'] = true;
        }
        return $result;
    }

    /**
     * FIX-M12-02: تطبیق payload ذخیره‌شده (request_data) با payload موردانتظار —
     * همان قرارداد collision-check مرکزی: اول data_hash (HMAC دادهٔ خام)، سپس
     * fallback مقایسهٔ نرمال‌شده برای ردیف‌های legacy بدون data_hash.
     *
     * @param array<string, mixed> $expectedPayload
     */
    private function storedPayloadMatches(string $storedRequestData, array $expectedPayload): bool
    {
        if (trim($storedRequestData) === '') {
            // ردیف بدون request_data (legacy) → تطبیق ناممکن؛ fail-open به جریان عادی
            // (collision-check مرکزی در مسیر execute همان ردیف را می‌سنجد)
            return true;
        }
        $decoded = json_decode($storedRequestData, true);
        if (!is_array($decoded)) {
            return true; // schema نامعتبر legacy — همان fail-open
        }
        $storedDataHash = $decoded['data_hash'] ?? null;
        if (is_string($storedDataHash) && $storedDataHash !== '') {
            return hash_equals($storedDataHash, self::originalDataHash($expectedPayload));
        }
        $storedData = is_array($decoded['data'] ?? null) ? $decoded['data'] : [];
        return self::payloadMatches($storedData, $expectedPayload);
    }

    /** @param array<string, mixed> $payload */
    public function keyFromPayload(string $scope, array $payload): string
    {
        // FIX-M6-09: canonicalization بازگشتی + نسخهٔ الگوریتم در seed.
        // قبلاً فقط ksort سطح اول انجام می‌شد؛ دو payload معنایی یکسان با ترتیب
        // کلیدهای «تودرتو» متفاوت، hashهای متفاوت می‌گرفتند و از dedup عبور
        // می‌کردند (اجرای تکراری عملیات). قرارداد v2:
        //   - آرایهٔ انجمنی: مرتب‌سازی کلیدها (string keys) سپس پیمایش
        //   - لیست ترتیبی: ترتیب اصلی حفظ می‌شود (ترتیب لیست معنادار است)
        //   - scalarها: نوع حفظ (int/float/bool/null/string)؛ float با
        //     بازنمایی JSON استاندارد
        //   - object: به آرایهٔ تو در تو تبدیل و کانونیکال می‌شود
        //   - seed نسخهٔ «v2» در ورودی hash تا کلیدهای قدیمی/جدید تداخل نکنند
        return hash('sha256', $scope . '|v2|' . json_encode(
            $this->canonicalizePayload($payload),
            JSON_UNESCAPED_UNICODE
        ));
    }

    /**
     * FIX-M6-09: کانونیکال‌سازی بازگشتی payload برای hash پایدار معنایی.
     *
     * @param mixed $value
     * @return mixed
     */
    private function canonicalizePayload(mixed $value): mixed
    {
        if (is_array($value)) {
            if (array_is_list($value)) {
                // لیست ترتیبی: ترتیب حفظ، مقادیر کانونیکال
                $out = [];
                foreach ($value as $item) {
                    $out[] = $this->canonicalizePayload($item);
                }
                return $out;
            }

            $out = [];
            $keys = array_keys($value);
            sort($keys);
            foreach ($keys as $key) {
                $out[$key] = $this->canonicalizePayload($value[$key]);
            }
            return $out;
        }

        if (is_object($value)) {
            // object → آرایهٔ انجمنی کانونیکال (کلیدهای object هم ترتیب‌پذیرند)
            return $this->canonicalizePayload(get_object_vars($value));
        }

        return $value;
    }

    /**
     * پاک کردن کلیدهای قدیمی و منقضی شده
     * 
     * @param bool $dryRun فقط شمارش بدون حذف
     * @return int تعداد کلیدهای حذف شده
     */
    public function cleanup(bool $dryRun = false): int
    {
        try {
            $expiryDate = date('Y-m-d H:i:s', strtotime('-' . self::CLEANUP_DAYS . ' days'));
            
            if ($dryRun) {
                // فقط شمارش
                $sql = "SELECT COUNT(*) as count FROM {$this->table} 
                        WHERE `created_at` < :expiry_date OR `expires_at` < NOW()";
                
                $stmt = $this->db->prepare($sql);
                $stmt->execute(['expiry_date' => $expiryDate]);
                $result = $stmt->fetch(\PDO::FETCH_ASSOC);
                $count = is_array($result) ? ($result['count'] ?? 0) : 0;

                return is_int($count) || (is_string($count) && is_numeric($count))
                    ? (int)$count
                    : 0;
            }
            
            // حذف واقعی
            $sql = "DELETE FROM {$this->table} 
                    WHERE `created_at` < :expiry_date OR `expires_at` < NOW()";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['expiry_date' => $expiryDate]);
            
            $deleted = $stmt->rowCount();
            
            if ($deleted > 0) {
                $this->logEvent('idempotency.cleanup.completed', [
    'deleted' => $deleted,
    'expiry_date' => $expiryDate,
]);
                }
            
            return $deleted;
            
        } catch (\PDOException $e) {
            $this->logEvent('idempotency.cleanup.failed', [
    'error' => $e->getMessage(),
], 'error');
            return 0;
        }
    }

    /**
     * Wrapper برای اجرای عملیات با idempotency check
     * 
     * @param string $key کلید idempotency
     * @param int $userId شناسه کاربر
     * @param string $action نوع عملیات
     * @param callable $callback تابعی که باید اجرا شود
     * @param array|null $requestData داده‌های درخواست
     * @return mixed نتیجه callback یا نتیجه cached
     * @throws \Throwable
     */
    /** @param array<string, mixed> $requestData */
    /** @param array<string, mixed>|null $requestData */
    public function wrap(string $key, int $userId, string $action, callable $callback, ?array $requestData = null): mixed
    {
        return $this->wrapInstance($key, $userId, $action, $callback, $requestData);
    }

    /**
     * Instance version of wrap for dependency injection
     */
    /** @param array<string, mixed> $requestData */
    /** @param array<string, mixed>|null $requestData */
    public function wrapInstance(string $key, int $userId, string $action, callable $callback, ?array $requestData = null): mixed
    {
        $logId = uniqid('WRAP_', true);
        
        $this->logEvent('idempotency.wrap.started', [
            'log_id' => $logId,
            'key' => $key,
            'user_id' => $userId,
            'action' => $action,
        ]);
        // بررسی کلید
        $check = $this->check($key, $userId, $action, $requestData);
        
        if ($check['is_duplicate']) {
            $this->logEvent('idempotency.wrap.duplicate_returned', [
                'log_id' => $logId,
                'key' => $key,
            ], 'warning');

            // BUGFIX-PHASE3-P311: duplicate از نوع failed_final/failed_retryable نتیجهٔ
            // خطا را مثل نتیجهٔ موفق برنمی‌گردانیم؛ اجرای اول exception پرتاب کرده بود
            // و صدا زنندهٔ دوم هم باید همان معناشناسی خطا را بگیرد، نه آرایهٔ خطا
            // را به‌عنوان خروجی موفق عملیات.
            if (!empty($check['is_error'])) {
                $storedError = is_array($check['result'] ?? null) ? str_value($check['result']['error'] ?? '') : '';
                throw new \RuntimeException(
                    'Idempotent operation previously failed and must not be treated as successful: ' . $storedError,
                    // FIX-P4S-6: مقدار از DB می‌آید (mixed) — int_value امن‌تر از cast خام:
                    // '422' ⇒ 422؛ مقدار غایب/غیرعددی ⇒ 409 پیش‌فرض (قبلاً garbage ⇒ 0 می‌شد)
                    int_value($check['http_status'] ?? 409, 409)
                );
            }

            return $check['result'];
        }
        
        try {
            // اجرای عملیات
            $this->logEvent('idempotency.wrap.callback.executing', [
                'log_id' => $logId,
                'key' => $key,
            ]);
            $result = $callback();

            // 🛡️ FIX-IDEM-PAUSE (کلیدهای idempotency یتیم — ریشه‌ای): پاسخِ «pause»
            // یعنی عملیات به‌طور عادی متوقف شد و منتظر اقدامِ کاربر است (مثل
            // camera_required) — نه شکستِ قابل‌تلاشِ مجدد و نه نتیجهٔ نهایی.
            // کاش‌کردنِ آن به‌عنوان failed_retryable دو مشکل می‌ساخت: (۱) ردیفِ
            // یتیمِ ۹۰روزه، (۲) ریسابمیتِ داخلِ پنجرهٔ cooldown با خطای ۴۰۹
            // کاذب. کلید رها می‌شود (سطر حذف) تا retryِ بعد از اقدامِ کاربر،
            // اجرای تازه با همان کلید باشد؛ هیچ ردیف یتیمی نمی‌ماند.
            if ($this->isPauseCallbackResult($result)) {
                $this->release($key, $userId);
                $this->logEvent('idempotency.wrap.paused_released', [
                    'log_id' => $logId,
                    'key'    => $key,
                    'reason' => str_value($result['pause_reason'] ?? 'awaiting_user_action'),
                ]);
                return $result;
            }

            // A business-level failure is retryable even when the callback did
            // not throw. Never cache such a response as a successful replay.
            if ($this->isFailedCallbackResult($result)) {
                $this->finalizeWithRetry($key, $result, $userId, true, $logId);
            } else {
                // FIX-C02 (finalize surfacing): complete() روی خطای persistence فقط false
                // برمی‌گرداند و wrapInstance آن را نادیده می‌گرفت ⇒ جهشِ commit‌شده با
                // سطرِ pending می‌ماند و «موفق بی‌صدا» گزارش می‌شد. اکنون نهایی‌سازی با
                // retry کوتاه انجام می‌شود؛ اگر باز هم نشد، استثنا پرتاب می‌کنیم تا
                // موفقیتِ کاذب گزارش نشود. سطر در وضعیت pending می‌ماند، پس replay
                // داخل پنجرهٔ TIMEOUT به‌عنوان «در حال پردازش» پاسخ می‌گیرد نه اجرای مجدد.
                $this->finalizeWithRetry($key, $result, $userId, false, $logId);
            }

            $this->logEvent('idempotency.wrap.callback.success', [
                'log_id' => $logId,
                'key' => $key,
            ]);

            return $result;
            
        } catch (\Throwable $e) {
            // FIX-S6-1 (یادداشت معلق S3): catch(\Exception) خطاهای Throwable-غیر-Exception
            // (TypeError/ValueError/Error) را عبور می‌داد بدون آنکه fail() ثبت شود ⇒
            // کلید تا TIMEOUT_SECONDS=300 در وضعیت pending می‌ماند و retry مشروعِ
            // کاربر با ۴۰۹ کاذب رد می‌شد. اکنون هر Throwable شکست را ثبت و rethrow
            // می‌کند؛ isRetryableException(\Throwable) و fail() از قبل سازگارند.
            $retryable = $this->isRetryableException($e);
            $this->fail($key, [
                'error' => $e->getMessage(),
                'exception' => get_class($e),
            ], $userId, $retryable);

            // FIX-R36-W3 (F-A9a-07): فراخوانی مستقیم logger()->error در catchِ مسیر پول
            // بدون گارد بود؛ اگر خودِ لاگر در همان لحظه استثنا می‌داد، \Error جای
            // خطای اصلیِ بیزینسی را می‌گرفت (diag خراب می‌شد). همان idiom بی‌خطرِ
            // logEvent() (try/catch fail-silent، کانال/سطح یکسان) استفاده شد؛
            // استثنای اصلی $e در پایان مثل قبل rethrow می‌شود.
            $this->logEvent('callback.failed', [
                'channel' => 'payment_callback',
                'log_id' => $logId,
                'user_id' => $userId,
                'key' => $key,
                'error' => $e->getMessage(),
                'code' => $e->getCode(),
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'retryable' => $retryable,
            ], 'error');

            throw $e;
        }
    }
    
    /**
     * دریافت آمار استفاده از idempotency keys
     * 
     * @return array<string, mixed>
     */
    public function getStats(): array
    {
        try {
            $sql = "SELECT 
                        `status`,
                        COUNT(*) as count,
                        COUNT(CASE WHEN `created_at` >= DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN 1 END) as last_hour,
                        COUNT(CASE WHEN `created_at` >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as last_24h
                    FROM {$this->table}
                    GROUP BY `status`";
            
            $stmt = $this->db->query($sql);
            $results = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            $stats = [
                'total' => 0,
                'by_status' => []
            ];
            
            foreach ($results as $row) {
                $stats['total'] += $row['count'];
                $stats['by_status'][$row['status']] = $row;
            }
            
            return $stats;
            
        } catch (\PDOException $e) {
            $this->logEvent('idempotency.stats.failed', [
    'error' => $e->getMessage(),
], 'error');
            return ['error' => 'internal_error'];
        }
    }
}
