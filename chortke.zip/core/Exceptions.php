<?php

declare(strict_types=1);

namespace Core\Exceptions;

use RuntimeException;

class AppException extends RuntimeException
{
}

class PayloadTooLargeException extends AppException
{
    public function __construct(string $message = 'Payload too large', int $code = 413) {
        parent::__construct($message, $code);
    }
}

class ValidationException extends AppException
{
    /** @var array<string, mixed> */
    private array $errors;

    /** @param array<string, mixed> $errors */
    public function __construct(array $errors, string $message = 'Validation failed', int $code = 422) {
        parent::__construct($message, $code);
        $this->errors = $errors;
    }

    /** @return array<string, mixed> */
    public function getErrors(): array
    {
        return $this->errors;
    }
}

class NotFoundException extends AppException
{
    public function __construct(string $message = 'Not found', int $code = 404) {
        parent::__construct($message, $code);
    }
}

class UnauthorizedException extends AppException
{
    public function __construct(string $message = 'Unauthorized', int $code = 401) {
        parent::__construct($message, $code);
    }
}

class SecurityException extends AppException
{
    public function __construct(string $message = 'Security validation failed', int $code = 403) {
        parent::__construct($message, $code);
    }
}

class BusinessException extends AppException
{
    /** @var array<string, mixed> */
    private array $errors = [];

    /** @param int|array<string, mixed> $code */
    public function __construct(string $message = 'خطای بیزینسی رخ داد', int|array $code = 0, ?\Throwable $previous = null) {
        if (is_array($code)) {
            $this->errors = $code;
            parent::__construct($message, 422, $previous);
        } else {
            parent::__construct($message, (int)$code, $previous);
        }
    }

    /** @return array<string, mixed> */
    public function getErrors(): array
    {
        return $this->errors;
    }
}

class DomainException extends BusinessException
{
}

class ApplicationException extends AppException
{
}

class InfrastructureException extends AppException
{
}

class TransientException extends InfrastructureException
{
}

class ExternalServiceException extends InfrastructureException
{
}

class InsufficientBalanceException extends BusinessException
{
    public function __construct(string $message = 'موجودی حساب کافی نیست', int $code = 400) {
        parent::__construct($message, $code);
    }
}

class EntityNotFoundException extends NotFoundException
{
    public function __construct(string $message = 'موجودیت مورد نظر یافت نشد', int $code = 404) {
        parent::__construct($message, $code);
    }
}

class RateLimitExceededException extends AppException
{
    public function __construct(string $message = 'تعداد درخواست‌ها بیش از حد مجاز است', int $code = 429) {
        parent::__construct($message, $code);
    }
}

class FraudDetectedException extends SecurityException
{
    public function __construct(string $message = 'فعالیت مشکوک شناسایی شد', int $code = 403) {
        parent::__construct($message, $code);
    }
}

class InvalidStateException extends BusinessException
{
    public function __construct(string $message = 'وضعیت درخواست نامعتبر است', int $code = 409) {
        parent::__construct($message, $code);
    }
}

/**
 * 🛡️ FIX-X194 (راند ۵۰ — الگوی X163): نشانگر تایپ‌دارِ «پخش مجددِ idempotent».
 * قبلاً جریان‌های مالی برای تشخیص replay، متن پیام را می‌بوییدند
 * (str_contains($e->getMessage(), 'قبلاً پردازش')) — یعنی صرفِ بازنویسیِ یک جمله
 * می‌توانست خطای واقعی را «موفقِ بی‌کار» کند یا replay را «شکست» (ریسک دوباره‌پرداخت).
 * قاعدهٔ X163: تشخیص با تایپ انجام می‌شود، نه محتوای پیام؛ پیام فقط برای انسان است.
 */
class IdempotentReplayException extends InvalidStateException
{
}

/**
 * Section 8.4 — Failure classification for external adapters.
 *
 * Retry/CB matrix:
 *   TransientException     -> retry + count toward circuit-breaker failures
 *   RateLimitedFailure     -> back off (don't count toward CB tripping)
 *   ProviderUnavailable    -> retry + STRONGLY count toward CB
 *   PermanentFailure       -> DO NOT retry, DO NOT count toward CB
 *
 * All four extend ExternalServiceException so existing catch sites keep working.
 */
class PermanentFailure extends ExternalServiceException
{
}

class RateLimitedFailure extends ExternalServiceException
{
    private int $retryAfterSeconds;

    public function __construct(
        string $message = 'Provider rate limit exceeded',
        int $retryAfterSeconds = 0,
        int $code = 429
    ) {
        parent::__construct($message, $code);
        $this->retryAfterSeconds = max(0, $retryAfterSeconds);
    }

    public function getRetryAfterSeconds(): int
    {
        return $this->retryAfterSeconds;
    }
}

class ProviderUnavailable extends ExternalServiceException
{
}

class HttpResponseException extends AppException
{
    private \Core\Response $response;

    public function __construct(\Core\Response $response, string $message = "HTTP Response Terminated", int $code = 0) {
        parent::__construct($message, $code);
        $this->response = $response;
    }

    public function getResponse(): \Core\Response
    {
        return $this->response;
    }
}

/**
 * Exception thrown when a CircuitBreaker rejects an operation because the circuit is OPEN.
 *
 * FIX-C60/62 (یافته‌های ۶۰ و ۶۲): متادیتای retry-after — callerها (دیمن‌ها،
 * آداپتورها، لایهٔ HTTP) اکنون می‌توانند «چند ثانیه تا نیمه‌وقتِ retry» را
 * بخوانند (Retry-After header / backoff حلقه) به‌جای parse کردن پیام.
 */
class CircuitBreakerOpenException extends ExternalServiceException
{
    private string $serviceName;
    private int $retryAfterSeconds;

    public function __construct(string $serviceName, string $message = "", int $code = 503, ?\Throwable $previous = null, int $retryAfterSeconds = 0) {
        $this->serviceName = $serviceName;
        $this->retryAfterSeconds = max(0, $retryAfterSeconds);
        $message = $message ?: "Circuit breaker for {$serviceName} is OPEN. Request aborted.";
        parent::__construct($message, $code, $previous);
    }

    public function getServiceName(): string
    {
        return $this->serviceName;
    }

    /** ثانیه‌های باقی‌مانده تا گذار half_open (۰ = نامعلوم). */
    public function getRetryAfterSeconds(): int
    {
        return $this->retryAfterSeconds;
    }
}
