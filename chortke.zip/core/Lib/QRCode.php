<?php

declare(strict_types=1);

namespace Core\Lib;

use chillerlan\QRCode\QRCode as ChillerlanQRCode;
use chillerlan\QRCode\QROptions;

/**
 * QRCode - SVG QR code generator.
 *
 * This is a thin adapter around the maintained `chillerlan/php-qrcode` package
 * (MIT, PHP 8.2+). The previous in-repo copy was a vendored port of
 * `splitbrain/php-qrcode` that had drifted out of maintenance and produced a
 * large number of static-analysis findings. Delegating to the maintained
 * upstream library keeps the public surface (`svg()`) stable for callers while
 * removing the legacy implementation.
 */
class QRCode
{
    protected mixed $data;
    /** @var array<string, mixed> */
    protected array $options;

    /**
     * @param array<string, mixed> $options
     */
    public function __construct(mixed $data, array $options = [])
    {
        $this->data = $data;
        $this->options = $options;
    }

    /**
     * Generate a standalone SVG string for the given data.
     *
     * @param mixed $data
     * @param array<string, mixed> $options
     */
    public static function svg(mixed $data, array $options = []): string
    {
        // FIX-M1M23: سقف اندازه — scale/quietzone فقط حد پایین نداشتند؛
        // ورودی بزرگ می‌توانست SVG های عظیم تولید کند (DoS منابع)
        $scaleValue = $options['scale'] ?? 4;
        $scale = is_numeric($scaleValue) ? min(20, max(1, (int)$scaleValue)) : 4;

        $quietzoneValue = $options['quietzone'] ?? 4;
        $quietzone = is_numeric($quietzoneValue) ? min(10, max(0, (int)$quietzoneValue)) : 4;

        $qrOptions = new QROptions([
            'outputType'    => 'svg',
            'outputBase64'  => false,
            'scale'         => $scale,
            'addQuietzone'  => true,
            'quietzoneSize' => $quietzone,
        ]);

        $qr = new ChillerlanQRCode($qrOptions);
        // FIX-M1M23: payload نامعتبر دیگر بی‌صدا به رشتهٔ خالی (QR خالی)
        // تبدیل نمی‌شود — شکست صریح با استثنا
        if (is_string($data)) {
            $payload = $data;
        } elseif (is_scalar($data)) {
            $payload = (string)$data;
        } else {
            try {
                $payload = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            } catch (\JsonException $e) {
                throw new \InvalidArgumentException('QR payload must be JSON-encodable.', 0, $e);
            }
        }
        if (trim($payload) === '') {
            throw new \InvalidArgumentException('QR payload must not be empty.');
        }
        $output = $qr->render($payload);
        return is_string($output) ? $output : '';
    }

    /**
     * Instance-based equivalent of {@see self::svg()}.
     */
    public function createSVG(): string
    {
        return self::svg($this->data, $this->options);
    }
}
