<?php

namespace Core;

use App\Middleware\TracingMiddleware;

/**
 * Router
 *
 * جریان صحیح dispatch:
 *
 *   User Request
 *       ↓
 *   Router::dispatch()
 *       ↓
 *   matchRoute()  →  پیدا کردن route
 *       ↓
 *   Container::make(Middleware)  →  اجرای middleware‌ها
 *       ↓
 *   Container::make(ControllerClass)
 *       ├─→ Container::make(ServiceClass)   [auto-wire از constructor]
 *       │       └─→ Container::make(Model)  [auto-wire از constructor]
 *       └─→ Controller::__construct(Service, ...)
 *       ↓
 *   Controller::method($routeParams)
 *       ↓
 *   Response::send()
 */
class Router
{
    /** @var array{prefix?: string, middleware?: array<int, string>} */
    protected array $groupAttributes = [];
    private Request $request;
    private Container $container;

    /** @var array<string, list<array{uri:string, route:Route}>> */
    private array $routes = [
        'GET'     => [],
        'POST'    => [],
        'PUT'     => [],
        'DELETE'  => [],
        'PATCH'   => [],
        'OPTIONS' => [], // M10 Fix: پشتیبانی بومی از متد پیش‌پرواز OPTIONS جهت تکمیل استاندارد REST
        'HEAD'    => [], // M10 Fix: پشتیبانی از درخواست‌های صرفاً هدر HEAD
    ];

    // CORE-027: Middleware Priority Registry
    /** @var list<class-string> */
    protected array $middlewarePriority = [
        TracingMiddleware::class,
        \App\Middleware\GlobalExceptionMiddleware::class,
        // FIX-M2M17: HTTPS پیش از Session/CSRF/Concurrent — درخواست HTTP در production
        // پیش از آن‌که session راه بیفتد یا قفل concurrency گرفته شود به 301 هدایت می‌شود
        \App\Middleware\HttpsMiddleware::class,
        \App\Middleware\SessionMiddleware::class,
        \App\Middleware\CSRFMiddleware::class, // 🔐 Architectural Fix: Enforced automatic CSRF validation globally (Phase 3 Fix)
        \App\Middleware\ConcurrentRequestMiddleware::class,
        \App\Middleware\SecurityHeadersMiddleware::class,
        \App\Middleware\CorsMiddleware::class,
        \App\Middleware\MaintenanceMiddleware::class,
        \App\Middleware\SafeModeMiddleware::class,
        \App\Middleware\LoggingMiddleware::class,
    ];

    public function __construct(Request $request, Container $container) {
        $this->request = $request;
        $this->container = $container;
    }

    public function setContainer(Container $container): void
    {
        $this->container = $container;
    }

    // ─────────────────────────────────────────────────────────────
    // Route Registration
    // ─────────────────────────────────────────────────────────────

    /** @param array<int, string> $middleware */
    public function get(string $uri, mixed $action, array $middleware = []): Route
    {
        return $this->addRoute('GET', $uri, $action, $middleware);
    }

    /** @param array<int, string> $middleware */
    public function post(string $uri, mixed $action, array $middleware = []): Route
    {
        return $this->addRoute('POST', $uri, $action, $middleware);
    }

    /** @param array<int, string> $middleware */
    public function put(string $uri, mixed $action, array $middleware = []): Route
    {
        return $this->addRoute('PUT', $uri, $action, $middleware);
    }

    /** @param array<int, string> $middleware */
    public function delete(string $uri, mixed $action, array $middleware = []): Route
    {
        return $this->addRoute('DELETE', $uri, $action, $middleware);
    }

    /** @param array<int, string> $middleware */
    public function patch(string $uri, mixed $action, array $middleware = []): Route
    {
        return $this->addRoute('PATCH', $uri, $action, $middleware);
    }

    /** @param array<int, string> $middleware */
    public function options(string $uri, mixed $action, array $middleware = []): Route
    {
        return $this->addRoute('OPTIONS', $uri, $action, $middleware);
    }

    /** @param array<int, string> $middleware */
    public function head(string $uri, mixed $action, array $middleware = []): Route
    {
        return $this->addRoute('HEAD', $uri, $action, $middleware);
    }

    /** @param array<int, string> $routeMiddleware */
    private function addRoute(string $method, string $uri, mixed $action, array $routeMiddleware = []): Route
    {
        // اعمال group prefix
        $prefix = $this->groupAttributes['prefix'] ?? '';
        $routePath = trim($prefix . '/' . ltrim($uri, '/'), '/');
        $fullUri = $routePath === '' ? '/' : '/' . $routePath;

        $route = new Route($fullUri, $action);

        // اعمال group middleware
        if (!empty($this->groupAttributes['middleware'])) {
            foreach ((array)$this->groupAttributes['middleware'] as $mw) {
                $route->middleware($mw);
            }
        }

        // اعمال inline middleware (پارامتر سوم مستقیم)
        foreach ($routeMiddleware as $mw) {
            $route->middleware($mw);
        }

        $this->routes[$method][] = [
            'uri'   => $fullUri,
            'route' => $route,
        ];

        return $route;
    }

    // ─────────────────────────────────────────────────────────────
    // Group
    // ─────────────────────────────────────────────────────────────

    /** @param array<string, mixed> $attributes */
    public function group(array $attributes, callable $callback): void
    {
        $previous = $this->groupAttributes;

        if (isset($attributes['middleware'])) {
            $mw = is_array($attributes['middleware'])
                ? $attributes['middleware']
                : [$attributes['middleware']];

            $this->groupAttributes['middleware'] = array_merge(
                $this->groupAttributes['middleware'] ?? [],
                $mw
            );
        }

        if (array_key_exists('prefix', $attributes)) {
            $prefixValue = $attributes['prefix'];
            if (!is_string($prefixValue)) {
                throw new \InvalidArgumentException('Route group prefix must be a string.');
            }

            $currentPrefix = trim($this->groupAttributes['prefix'] ?? '', '/');
            $nextPrefix = trim($prefixValue, '/');
            $combinedPrefix = implode('/', array_filter(
                [$currentPrefix, $nextPrefix],
                static fn(string $segment): bool => $segment !== ''
            ));
            $this->groupAttributes['prefix'] = $combinedPrefix === '' ? '' : '/' . $combinedPrefix;
        }

        $callback($this);

        $this->groupAttributes = $previous;
    }

    // ─────────────────────────────────────────────────────────────
    // Dispatch — قلب Router
    // ─────────────────────────────────────────────────────────────

    public function dispatch(): void
    {
        // H15 Fix: اطمینان از تمیز بودن استک وابستگی‌های کانتینر در هر ورودی جدید
        Container::resetTraceStack();

        // Session initialization is now fully decoupled and handled cleanly by SessionMiddleware at the head of the global pipeline

        // ── Global Middleware Stack ─────────────────────────────────────
        // این میدل‌ویرها برای تمامی درخواست‌ها (حتی صفحات ۴۰۴) اجرا می‌شوند
        $globalMiddlewares = [
            TracingMiddleware::class,
            \App\Middleware\GlobalExceptionMiddleware::class,
            // FIX-M2M17: HTTPS پیش از Session/CSRF/Concurrent (هم‌راستا با priority registry)
            \App\Middleware\HttpsMiddleware::class,
            \App\Middleware\SessionMiddleware::class,
            \App\Middleware\CSRFMiddleware::class,
            \App\Middleware\ConcurrentRequestMiddleware::class,
            \App\Middleware\LoggingMiddleware::class,         // رصد دقیق پرفورمنس و مدیریت آسنکرون لاگ
            \App\Middleware\CorsMiddleware::class,
            \App\Middleware\SecurityHeadersMiddleware::class,
            \App\Middleware\MaintenanceMiddleware::class,     // جایگزین هوشمند لایه سنتی تعمیرات در هسته
            \App\Middleware\SafeModeMiddleware::class         // سپر نهایی محافظت فقط خواندنی (Read-only)
        ];

        // CORE-027: Sort middlewares according to the policy priority registry
        $globalMiddlewares = $this->sortMiddlewares($globalMiddlewares);

        // H10 Fix: کپسوله کردن پایپ‌لاین روت‌ها در try/catch برای گرفتن Exceptionهای پاسخدهی استاندارد
        try {
            // اجرای حلقه اصلی مسیریابی از میان Pipeline سراسری
            $response = (new Pipeline($this->container))
                ->send($this->request)
                ->through($globalMiddlewares)
                ->then(function ($request) use ($globalMiddlewares) {

                    $method = $request->method();
                    $uri    = $request->uri();

                    // CORE-029: HEAD fallback to GET
                    $routesToMatch = $this->routes[$method] ?? [];
                    if ($method === 'HEAD' && empty($routesToMatch)) {
                        $routesToMatch = $this->routes['GET'] ?? [];
                    }

                    // ① جستجوی مسیر منطبق (Route Matching)
                    foreach ($routesToMatch as $routeData) {
                        $params = $this->matchRoute($routeData['uri'], $uri);

                        if ($params === false) {
                            continue;
                        }

                        $request->setParams($params);
                        $GLOBALS['_route_params'] = $params;

                        // RBAC: قرار دادن action مسیرِ منطبق روی Request تا middlewareها
                        // (مثل AdminPermissionGuard) بتوانند Controller@method را تشخیص دهند.
                        $request->setAttribute('_resolved_action', $routeData['route']->getAction());

                        // ② اجرای پایپ‌لاین اختصاصی روت
                        // BUGFIX: میان‌افزارهایی که همین حالا در پایپ‌لاین سراسری
                        // اجرا شده‌اند نباید بار دوم در پایپ‌لاین روت اجرا شوند.
                        // ConcurrentRequestMiddleware در اجرای دوم قفل Redis خودش
                        // را (که در اجرای اول گرفته شده و هنوز آزاد نشده) می‌بیند و
                        // هر درخواست POST تکیْ روی پشته‌های $secure را با ۴۲۹
                        // «درخواست همزمان مجاز نیست» رد می‌کرد. CSRFMiddleware نیز
                        // در ۲۴ نقطه همین تکرار را داشت.
                        $middlewares = array_values(array_filter(
                            $routeData['route']->getMiddleware(),
                            static function ($mw) use ($globalMiddlewares): bool {
                                // میان‌افزارهای پارامتردار ('Class:arg') هرگز سراسری
                                // نیستند و باید دست‌نخورده باقی بمانند.
                                return !is_string($mw) || !in_array($mw, $globalMiddlewares, true);
                            }
                        ));

                        return (new Pipeline($this->container))
                            ->send($request)
                            ->through($middlewares)
                            ->then(function ($req) use ($routeData, $params) {
                                // مقصد نهایی: اجرای Action کنترلر
                                return $this->executeAction($routeData['route']->getAction(), $params);
                            });
                    }

                    // ③ در صورت عدم یافتن مسیر، خروجی ۴۰۴ استاندارد برگردانده می‌شود
                    return $this->generateNotFoundResponse($uri, $method);
                });

            // ④ نهایی‌سازی و تحویل پاسخ نهایی به خروجی
            $this->handleResult($response);
            
        } catch (\Core\Exceptions\HttpResponseException $e) {
            // اگر کنترلر یا میدل‌ویرها Response->send() زده باشند، در اینجا گرفته و منتشر می‌شود
            $this->handleResult($e->getResponse());
        } catch (\Throwable $e) {
            // سایر خطاها جهت مدیریت متمرکز به ExceptionHandler سراسری ارجاع می‌شوند
            throw $e;
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Middleware Execution — از Container ساخته می‌شه
    // ─────────────────────────────────────────────────────────────

    // runMiddleware removed - handled by Pipeline class

    // ─────────────────────────────────────────────────────────────
    // Controller Execution — از Container ساخته می‌شه
    // ─────────────────────────────────────────────────────────────

    /** @param array<string, mixed> $params */
    protected function executeAction(mixed $action, array $params = []): mixed
    {
        // ── Closure action ───────────────────────────────────────
        if ($action instanceof \Closure) {
            // ✅ Fix L2: اجرای Closure با DI خودکار از طریق Container::call
            return $this->container->call($action, $params);
        }

        // ── [ControllerClass, 'method'] ──────────────────────────
        if (!is_array($action) || count($action) !== 2) {
            throw new \RuntimeException('[Router] Invalid route action format.');
        }

        [$controllerClass, $method] = array_values($action);
        if (!is_string($controllerClass) || !class_exists($controllerClass)) {
            throw new \RuntimeException('[Router] Controller action must reference an existing class.');
        }
        if (!is_string($method) || $method === '') {
            throw new \RuntimeException('[Router] Controller action method must be a non-empty string.');
        }

        // ساخت Controller از Container — همه وابستگی‌ها auto-wire می‌شن
        try {
            $controller = $this->container->make($controllerClass);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            // 🛡️ FIX-X226 (راند 59): HttpResponseException جریانِ کنترل است —
            // requireAuth()/redirect() می‌تواند داخل سازندهٔ کنترلر پرتاب شود
            // (BaseAdminController::__construct → requireAuth برای مهمان).
            // چون HttpResponseException از RuntimeException ارث می‌برد، catchِ بعدی
            // آن را در پیام «Cannot resolve Controller» پیچیده و ۳۰۲ را ۵۰۰ می‌کرد (ایسوی #80).
            throw $e;
        } catch (\RuntimeException $e) {
            // BUGFIX-PHASE1-Y13: exception اصلی به‌عنوان previous زنجیر می‌شود
            // تا stack trace ریشه در لاگ‌ها و ExceptionHandler گم نشود.
            throw new \RuntimeException(
                "[Router] Cannot resolve Controller '{$controllerClass}': " . $e->getMessage(),
                0,
                $e
            );
        }

        if (!method_exists($controller, $method)) {
            throw new \RuntimeException(
                "[Router] Method '{$method}' not found in '{$controllerClass}'."
            );
        }

        // اجرای action method با route params
        try {
            $ref = new \ReflectionMethod($controller, $method);
            if (!$ref->isPublic()) {
                throw new \RuntimeException("[Router] Action {$controllerClass}::{$method} must be public.");
            }

            // FIX-R36-W3 (F-A9b-06): اتصال پوزیشنیِ کور (`array_values($params)`)
            // نام پارامترها را تزئینی می‌کرد — مسیرِ «{slug}/{id}» با کنترلری به
            // ترتیبِ (id, slug) بی‌صدا مقادیر را جابه‌جا می‌کرد. اکنون اگر مجموعهٔ
            // نام‌های متد با کلیدهای params دقیقاً یکی باشد، اتصال نام‌محور انجام
            // می‌شود؛ در غیر این صورت (همهٔ ۷۴۹ هندلر زندهٔ وریفای‌شدهٔ A3: ترتیب
            // declaration == ترتیب {param} و متد فقط پارامترهای مسیر را می‌شناسد)
            // همان رفتار پوزیشنیِ قبلی عیناً حفظ می‌شود تا صفر رگرسیون داشته باشیم.
            $refParamNames = array_map(
                static fn(\ReflectionParameter $p): string => $p->getName(),
                $ref->getParameters()
            );
            if ($refParamNames !== [] && array_keys($params) !== [] && $refParamNames === array_keys($params)) {
                $args = array_values($params);
            } else {
                $expectedCount = $ref->getNumberOfParameters();
                $args          = $expectedCount > 0
                    ? array_slice(array_values($params), 0, $expectedCount)
                    : [];
            }

            return $ref->invokeArgs($controller, $args);

        } catch (\ReflectionException $e) {
            // BUGFIX-PHASE1-Y13: حفظ زنجیره‌ی exception ریشه
            throw new \RuntimeException(
                "[Router] Reflection error for {$controllerClass}::{$method}: " . $e->getMessage(),
                0,
                $e
            );
        }
    }

    /**
     * مدیریت نتیجه‌ی action
     */
    private function handleResult(mixed $result): void
    {
        if ($result instanceof Response) {
            // H10 Fix: صدا زدن امیتور فیزیکی به جای متد Send برای جلوگیری از حلقه تکرار exception
            $result->sendToBrowser();
            return;
        }
        if (is_string($result)) {
            // Some legacy helpers (notably helpers/view_helper.php::view) both echo
            // the rendered HTML and return it. When a controller uses
            // `return view(...)`, blindly echoing here duplicates the whole page.
            if (!isset($GLOBALS['_last_view_helper_echo_hash'])) {
                echo $result;
            }
            unset($GLOBALS['_last_view_helper_echo_hash']);
            return;
        }
        if (is_array($result) || is_object($result)) {
            $response = new Response();
            $response->json((array)$result);
            return;
        }
    }

    // ─────────────────────────────────────────────────────────────
    // URI Matching
    // ─────────────────────────────────────────────────────────────

    /** @return array<string, string>|false */
    private function matchRoute(string $routeUri, string $currentUri): array|false
    {
        $routeUri   = trim($routeUri, '/');
        $currentUri = trim($currentUri, '/');

        $paramNames = [];

        // FIX-M1M14 (گزارش ماژول ۱، M14): literalهای مسیر با preg_quote escape
        // می‌شوند و فقط placeholderها به الگوی regex تبدیل می‌شوند — قبلاً نقطهٔ
        // /sitemap.xml و /robots.txt هر کاراکتری را می‌پذیرفت (/sitemapXtxt).
        $parts = preg_split('/(\{[a-zA-Z0-9_]+(?::[a-zA-Z0-9_]+)?\})/', $routeUri, -1, PREG_SPLIT_DELIM_CAPTURE) ?: [];
        $pattern = '';
        foreach ($parts as $part) {
            if ($part === '') {
                continue;
            }
            if ($part[0] === '{' && str_ends_with($part, '}')) {
                $pattern .= $this->convertPlaceholderToRegex($part, $paramNames);
            } else {
                $pattern .= preg_quote($part, '#');
            }
        }

        // BUGFIX-PHASE1-Y6 (تأیید رانتایم): modifier «D» تضمین می‌کند «$» فقط به
        // انتهای واقعی رشته بخورد نه قبل از «\n» انتهایی؛ در غیر این صورت پارامتری
        // مثل «foo%0A» بعد از urldecode با newline انتهایی پذیرفته می‌شد.
        $pattern = '#^' . $pattern . '$#uD';

        if (!preg_match($pattern, $currentUri, $matches)) {
            return false;
        }

        $params = [];
        foreach ((array)$paramNames as $i => $name) {
            $decoded = urldecode($matches[$i + 1] ?? '');
            // H7: جلوگیری از Path Traversal یا تزریق سگمنت با / بعد از دیکد شدن
            // FIX-R36-W3 (F-A9b-05): NUL بایت (%00) بعد از urldecode جان سالم‌به‌در
            // می‌برد (حمل‌شده R30) — strpbrk هم '/' و هم "\0" را یکجا رد می‌کند؛
            // رشتهٔ خالی هم fail-closed رد می‌شود (الگوهای پارامتر همگی + هستند،
            // پس هیچ مسیرِ مجازی خالی نمی‌ماند).
            if ($decoded === '' || strpbrk($decoded, "/\0") !== false) {
                return false;
            }
            // FIX-M1M15 (گزارش ماژول ۱، M15): پس از decode، تمام کنترل‌کدهای C0،
            // DEL و backslash رد می‌شوند (%0d%0a و مشابه‌ها پارامتر نمی‌شوند؛
            // مصرف‌کننده‌های downstream دیگر به CRLF در پارامتر برخورد نمی‌کنند)
            if (preg_match('/[\x00-\x1F\x7F\\\\]/', $decoded) === 1) {
                return false;
            }
            $params[$name] = $decoded;
        }

        return $params;
    }

    /**
     * CORE-028 & CORE-062: تبدیل یک placeholder مسیر به الگوی regex با
     * اعتبارسنجی نوع سخت‌گیرانه و inference پیش‌فرض.
     *
     * @param array<int, string> $paramNames
     */
    private function convertPlaceholderToRegex(string $placeholder, array &$paramNames): string
    {
        preg_match('/\{([a-zA-Z0-9_]+)(?::([a-zA-Z0-9_]+))?\}/', $placeholder, $m);
        $name = $m[1] ?? '';
        $paramNames[] = $name;
        $type = $m[2] ?? null;

        // CORE-062: Automatically infer constraint type based on parameter names if omitted
        if ($type === null) {
            $lowerName = strtolower((string)$name);
            if ($lowerName === 'id' || str_ends_with($lowerName, '_id')) {
                $type = 'int';
            } elseif (str_contains($lowerName, 'slug')) {
                $type = 'slug';
            } else {
                $type = 'safe_string';
            }
        }

        if ($type === 'int') {
            return '([0-9]+)';
        }
        if ($type === 'slug') {
            return '([a-z0-9\-]+)';
        }
        if ($type === 'alpha') {
            return '([a-zA-Z]+)';
        }

        // Safe fallback (alphanumeric plus basic safe url characters, not wild arbitrary symbols)
        return '([a-zA-Z0-9\-\_\.\%\@]+)';
    }

    // ─────────────────────────────────────────────────────────────
    // 404 Handler
    // ─────────────────────────────────────────────────────────────

    /**
     * ایجاد پاسخ استاندارد ۴۰۴ بدون قطع اجرای سیستم
     */
    private function generateNotFoundResponse(string $uri, string $method): Response
    {
        $response = new Response();
        $response->status(404);

        ob_start();
        
        if (config('app.debug') && config('app.env') === 'local') {
            // FIX-QA4-STYLE: صفحهٔ 404 دیباگ برندشد — قبلاً Tahoma خاکستریِ بی‌رابطه با
            // هویت سایت بود. اطلاعات دیاگ نوستیک (Method/URI/پیشنهاد مسیرها) حفظ شد.
            $suggestions = $this->suggestRoutes($uri, $method, 3);
            $suggestionsHtml = '';
            if (!empty($suggestions)) {
                $suggestionsHtml .= "<div class='cf-hint'><p>آیا منظورتان یکی از این‌ها بود؟</p><ul>";
                foreach ($suggestions as $s) {
                    $suggestionsHtml .= "<li><code>" . htmlspecialchars($s, ENT_QUOTES, 'UTF-8') . "</code></li>";
                }
                $suggestionsHtml .= "</ul></div>";
            }
            echo "<!DOCTYPE html><html lang='fa' dir='rtl'><head><meta charset='UTF-8'>";
            echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
            echo "<title>404 - صفحه یافت نشد | چرتکه (debug)</title>";
            echo "<link rel='stylesheet' href='" . asset('assets/vendor/vazirmatn/vazirmatn.css') . "'>";
            echo "<style>
:root{--gold:#F0B90B;--bg:#0B0E11;--card:#14171C;--line:#23272F;--txt:#EAECEF;--muted:#848E9C}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Vazirmatn',Tahoma,sans-serif;min-height:100vh;background:radial-gradient(1200px 600px at 50% -10%,rgba(240,185,11,.08),transparent 60%),var(--bg);color:var(--txt);display:flex;align-items:center;justify-content:center;padding:24px}
.cf-box{background:var(--card);border:1px solid var(--line);border-radius:18px;max-width:680px;width:100%;padding:40px 36px;text-align:center;box-shadow:0 24px 60px -24px rgba(0,0,0,.7)}
.cf-code{font-size:76px;font-weight:800;line-height:1;color:var(--gold);letter-spacing:2px}
.cf-code small{font-size:22px;color:var(--muted);font-weight:400;letter-spacing:0}
.cf-title{margin:14px 0 6px;font-size:22px;font-weight:700}
.cf-desc{color:var(--muted);font-size:14px;margin-bottom:22px}
.cf-meta{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-bottom:20px}
.cf-meta span{background:rgba(255,255,255,.04);border:1px solid var(--line);border-radius:99px;padding:6px 14px;font-size:13px;color:var(--muted)}
.cf-meta code{color:var(--txt);background:rgba(240,185,11,.08);padding:2px 8px;border-radius:6px;direction:ltr;display:inline-block}
.cf-hint{background:rgba(240,185,11,.05);border:1px solid rgba(240,185,11,.18);border-radius:12px;padding:14px 18px;margin:0 0 20px;text-align:right}
.cf-hint p{font-size:13px;margin-bottom:8px;color:var(--txt)}
.cf-hint ul{list-style:none;padding:0;margin:0}
.cf-hint li{margin:6px 0}
.cf-hint code{color:#7BD88F;background:rgba(123,216,143,.08);padding:3px 10px;border-radius:6px;direction:ltr;display:inline-block;font-size:13px}
.cf-actions{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}
.cf-btn{display:inline-flex;align-items:center;gap:8px;padding:11px 22px;border-radius:12px;font-size:14px;font-weight:600;text-decoration:none;transition:transform .18s ease,box-shadow .18s ease}
.cf-btn:hover{transform:translateY(-2px)}
.cf-btn-gold{background:var(--gold);color:#0B0E11;box-shadow:0 8px 20px -8px rgba(240,185,11,.5)}
.cf-btn-ghost{border:1px solid var(--line);color:var(--txt)}
.cf-btn-ghost:hover{border-color:var(--gold)}
.cf-foot{margin-top:22px;padding-top:16px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}
.cf-foot code{background:rgba(255,255,255,.05);padding:2px 8px;border-radius:6px;direction:ltr;display:inline-block}
</style></head><body><div class='cf-box'>";
            echo "<div class='cf-code'>404 <small>— debug</small></div>";
            echo "<h1 class='cf-title'>صفحه یافت نشد</h1>";
            echo "<p class='cf-desc'>این صفحه فقط در حالت توسعه نمایش داده می‌شود؛ در production برندِ اصلی جایگزین است.</p>";
            echo "<div class='cf-meta'><span>Method: <code>" . htmlspecialchars($method, ENT_QUOTES, 'UTF-8') . "</code></span><span>URI: <code>" . htmlspecialchars($uri, ENT_QUOTES, 'UTF-8') . "</code></span></div>";
            echo $suggestionsHtml;
            echo "<div class='cf-actions'>";
            // 16-W (گزینهٔ ۳): لینک‌های صفحهٔ 404 دیباگ از url() مرکزی ساخته می‌شوند —
            // هاردکد href='/chortke/admin/dashboard' حذف شد (در نصب ریشه‌ای 404 می‌داد و
            // در نصب زیرپوشه‌ای با تغییر prefix می‌شکست). الگوی escape همان متد است.
            echo "<a href='" . htmlspecialchars(url('/'), ENT_QUOTES, 'UTF-8') . "' class='cf-btn cf-btn-gold'>صفحهٔ اصلی</a>";
            echo "<a href='" . htmlspecialchars(url('/admin/dashboard'), ENT_QUOTES, 'UTF-8') . "' class='cf-btn cf-btn-ghost'>داشبورد ادمین</a>";
            echo "</div>";
            echo "<p class='cf-foot'>لیست کامل مسیرها: <code>php cli.php route:list</code></p>";
            echo "</div></body></html>";
        } else {
            $view = __DIR__ . '/../views/errors/404.php';
            if (file_exists($view)) {
                require $view;
            } else {
                echo '404 - Not Found';
            }
        }

        $response->setContent(ob_get_clean());
        return $response;
    }

    /**
     * پیشنهاد نزدیک‌ترین مسیرها به URI درخواستی — برای استفاده در صفحه‌ی 404 توسعه.
     * فقط N مسیر نزدیک‌تر را برمی‌گرداند (هرگز کل جدول routeها را نشون نمی‌دهد).
     *
     * @return list<string>
     */
    private function suggestRoutes(string $uri, string $method, int $limit = 3): array
    {
        $candidates = [];
        $routes = $this->routes[$method] ?? [];
        foreach ($routes as $r) {
            $routeUri = $r['uri'] ?? null;
            if (!is_string($routeUri) || $routeUri === '') {
                continue;
            }
            // similar_text: percentage similarity (0-100)
            similar_text($uri, $routeUri, $percent);
            if ($percent >= 40.0) {
                $candidates[] = ['uri' => $routeUri, 'score' => $percent];
            }
        }
        // Sort by score desc
        usort($candidates, function ($a, $b) {
            return $b['score'] <=> $a['score'];
        });
        $out = [];
        foreach (array_slice($candidates, 0, $limit) as $c) {
            $out[] = $c['uri'];
        }
        return $out;
    }

    /**
     * تولید آدرس URL بر اساس نام Route
     */
    /** @param array<string, mixed> $params */
    public function route(string $name, array $params = []): string
    {
        foreach ($this->routes as $method => $routes) {
            foreach ($routes as $routeData) {
                /** @var Route $route */
                $route = $routeData['route'];
                if ($route->getName() === $name) {
                    $uri = $route->getUri();
                    
                    // جایگزینی پارامترها در URI (مانند /users/{id})
                    foreach ((array)$params as $key => $value) {
                        // BUGFIX-PHASE1 (تأیید رانتایم): str_replace با مقدار آرایه‌ای
                        // TypeError می‌اندازد؛ خطای صریح و معنادار جایگزین می‌شود.
                        if (!is_scalar($value) && $value !== null) {
                            throw new \InvalidArgumentException(
                                "[Router] Route parameter '{$key}' for route '{$name}' must be scalar, " . get_debug_type($value) . " given."
                            );
                        }
                        // FIX-R36-W3 (F-A9b-11): جایگذاری خام مقدار پارامتر، تزریق
                        // ؟ / # / سگمنتِ اضافه در URL تولیدی را ممکن می‌کرد. rawurlencode
                        // برای id/slug عددی-ایمن همانی است؛ کensus زنده: صفر فراخوانِ
                        // route()-نامی در app/ ⇒ ریسک رگرسیون صفر، هاردنینگ برای آینده.
                        /** @var string|int|float|bool|null $value */
                        $uri = str_replace('{' . $key . '}', rawurlencode((string)$value), $uri);
                        $uri = str_replace('{' . $key . '?}', rawurlencode((string)$value), $uri);
                    }
                    
                    // پاک‌سازی پارامترهای اختیاری خالی باقی‌مانده
                    $normalizedUri = preg_replace('/\/\{[a-zA-Z0-9_]+\?\}/', '', $uri);
                    $uri = $normalizedUri === null ? $uri : $normalizedUri;

                    // استفاده از هلپر سراسری url() برای تکمیل آدرس نهایی
                    return function_exists('url') ? url($uri) : $uri;
                }
            }
        }

        throw new \InvalidArgumentException("مسیر با نام '{$name}' یافت نشد.");
    }

    // ─────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────

    /**
     * @param list<class-string> $middlewares
     * @return list<class-string>
     */
    protected function sortMiddlewares(array $middlewares): array
    {
        $priority = array_flip($this->middlewarePriority);
        
        usort($middlewares, function($a, $b) use ($priority) {
            $aPrio = $priority[$a] ?? 999;
            $bPrio = $priority[$b] ?? 999;
            return $aPrio <=> $bPrio;
        });
        
        return $middlewares;
    }

    /** @return array<string, list<array{uri:string, route:Route}>> */
    public function getRoutes(): array
    {
        return $this->routes;
    }
}
