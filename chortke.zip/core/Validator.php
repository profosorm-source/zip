<?php
declare(strict_types=1);

namespace Core;

class Validator
{
    /** @var array<string, mixed> */
    protected array $data = [];
    /** @var array<string, mixed> */
    protected array $rules = [];
    /** @var array<string, list<string>> */
    protected array $errors = [];
    /** @var array<string, array{callback: callable, message: string}> */
    protected array $customValidations = [];

    /** @var callable|null */
    protected $authorizationCheck = null;

    /** @var array<string, mixed> */
    protected array $messages = [];

    private ?Database $db = null;

    /** FIX-R36-W3 (F-A9b-10): آیا قواعد حداقل یک‌بار اجرا شده‌اند؟ (بازحساب fluent messages) */
    private bool $rulesEvaluated = false;

    /**
     * FIX-S4-5: الگوی عددِ سازگار با bcmath و accessors عددی.
     * is_numeric رشته‌هایی مثل «1e999 / 1e5 / 0x… /  12» را هم می‌پذیرد؛
     * bccomp در PHP 8 روی چنین ورودی‌هایی ValueError می‌اندازد (کرش ۵۰۰ در
     * مسیر numeric|min/max — ۱۶ اعتبارسنج مالی پروژه) و (float) آن‌ها INF
     * می‌سازد که به منطق مالی نشت می‌کند. فقط نماد دهدهی ساده مجاز است.
     */
    private const BC_MATH_NUMBER_PATTERN = '/^[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)$/';

    private static function isBcMathNumber(mixed $value): bool
    {
        if (is_int($value)) {
            return true;
        }
        if (is_float($value)) {
            return is_finite($value);
        }
        if (!is_string($value)) {
            return false;
        }
        return preg_match(self::BC_MATH_NUMBER_PATTERN, $value) === 1;
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $rules
     * @param array<string, mixed> $messages
     */
    public function __construct(array $data, array $rules = [], ?Database $db = null, array $messages = []) {
        $this->data = $data;
        $this->rules = [];
        
        // H17 Fix: تزریق دیتابیس از طریق DI به جای فراخوانی مستقیم Singleton در لایه Core
        $this->db = $db;

        // FIX-P4-3: پیام‌های سفارشی باید «پیش از» اجرای اعتبارسنجی ست شوند؛
        // سازنده بلافاصله validate() را اجرا می‌کند و ست‌کردن messages پس از سازنده
        // (مسیر قبلی ValidatorFactory::make) عملاً بی‌اثر بود.
        $this->messages = $messages;

        if (!empty($rules)) {
            $this->validate($rules);
        }
    }

    /**
     * Lazy resolution of Database — falls back to app() helper when not injected.
     * ValidatorFactory always provides Database, but direct `new Validator()` calls
     * may not — this ensures graceful degradation.
     */
    private function getDb(): Database
    {
        if ($this->db === null) {
            $this->db = app(Database::class);
        }
        return $this->db;
    }

    /** @param array<string, mixed>|null $rules */
    public function validate(?array $rules = null): void
    {
        // اگر rules پاس داده شد، ست کن
        if ($rules !== null) {
            $this->rules = $rules;
        }

        // اگر هنوز rules نداریم، خطای پیکربندی پرتاب کن (Fail-Closed)
        if (empty($this->rules)) {
            throw new \InvalidArgumentException('Validation rules cannot be empty.');
        }

        foreach ($this->rules as $field => $ruleString) {
            // R34-FAIL-LOUD: قاعدهٔ غیررشته‌ای (آرایه/عدد) خطای برنامه‌نویس است، نه دادهٔ کاربر
            if (!\is_string($ruleString)) {
                throw new \RuntimeException(
                    "Validation rule for field \"{$field}\" must be a pipe-separated string, "
                    . \get_debug_type($ruleString) . ' given (programmer error).'
                );
            }
            $fieldRules = \explode('|', str_value($ruleString));
            $value = $this->data[$field] ?? null;

            $skipRemaining = false;
            foreach ($fieldRules as $rule) {
                // R34-FAIL-LOUD: توکن خالی یعنی pipe اضافی/دوبل در رشتهٔ قواعد
                if (\trim($rule) === '') {
                    throw new \RuntimeException(
                        "Empty validation rule token for field \"{$field}\" — stray pipe in \"{$ruleString}\" (programmer error)."
                    );
                }
                if ($rule === 'nullable' && ($value === null || $value === '')) {
                    $skipRemaining = true;
                    break;
                }
                $this->applyRule($field, $value, $rule);
            }

            if ($skipRemaining) {
                continue;
            }
        }

        $this->rulesEvaluated = true;
    }

    private function applyRule(string $field, mixed $value, string $rule): void
    {
        $param = null;

        if (\strpos($rule, ':') !== false) {
            [$ruleName, $param] = \explode(':', $rule, 2);
        } else {
            $ruleName = $rule;
        }

        switch ($ruleName) {
            case 'required':
                if ($value === null || $value === '' || (\is_array($value) && empty($value))) {
                    $this->addError($field, 'این فیلد الزامی است', 'required');
                }
                break;

            case 'email':
                if ($value !== null && $value !== '' && !\filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $this->addError($field, 'ایمیل نامعتبر است', 'email');
                }
                break;

            case 'min':
                if ($value !== null && $value !== '') {
                    $rules = \explode('|', str_value($this->rules[$field] ?? ''));
                    // R34: زنجیرهٔ 'integer' نیز مقایسهٔ عددی را فعال می‌کند — پیش‌تر فقط 'numeric'
                    // گیت بود و integer|min/max طولِ رشته را می‌سنجید (rating 99999 با max:5 عبور
                    // می‌کرد). فیلدهای رشته‌ای بدون integer/numeric همان رفتار strlen قبلی را دارند.
                    $isNumeric = \in_array('numeric', $rules, true) || \in_array('integer', $rules, true);
                    if ($isNumeric) {
                        // اگر مقدار واقعاً عددی نیست، bccomp کرش می‌کند — خطای numeric توسط rule جداگانه گزارش می‌شود
                        // FIX-S4-5: گارد well-formed برای ریشه‌کن‌کردن ValueError بccomp (مثل «1e999»)
                        if (!self::isBcMathNumber($value)) {
                            break;
                        }
                        // FIX-S6-5 (اسکن کامل پروژه — pre-existing): cast خام mixed با
                        // str_value جایگزین شد (الگوی FIX-PS-C1) — رفتار روی اسکالرها یکسان
                        $minVal = str_value($param);
                        if (bccomp(str_value($value), $minVal, 8) < 0) {
                            $this->addError($field, "حداقل مقدار مجاز {$minVal} است", 'min');
                        }
                    } else {
                        $min = (int)$param;
                        if (\mb_strlen(str_value($value)) < $min) {
                            $this->addError($field, "حداقل {$min} کاراکتر مجاز است", 'min');
                        }
                    }
                }
                break;

            case 'max':
                if ($value !== null && $value !== '') {
                    $rules = \explode('|', str_value($this->rules[$field] ?? ''));
                    // R34: زنجیرهٔ 'integer' نیز مقایسهٔ عددی را فعال می‌کند (همان توضیح case 'min').
                    // قبلاً is_numeric($value) هم چک می‌شد که باعث می‌شد tracking_code='1234567890'
                    // اشتباه عددی فرض شود و max:50 بجای طول رشته، مقایسه عددی بشود.
                    $isNumeric = \in_array('numeric', $rules, true) || \in_array('integer', $rules, true);
                    if ($isNumeric) {
                        // اگر مقدار واقعاً عددی نیست، bccomp کرش می‌کند — خطای numeric توسط rule جداگانه گزارش می‌شود
                        // FIX-S4-5: گارد well-formed برای ریشه‌کن‌کردن ValueError بccomp (مثل «1e999»)
                        if (!self::isBcMathNumber($value)) {
                            break;
                        }
                        // FIX-S6-5: هم‌الگوی شاخهٔ min
                        $maxVal = str_value($param);
                        if (bccomp(str_value($value), $maxVal, 8) > 0) {
                            $this->addError($field, "حداکثر مقدار مجاز {$maxVal} است", 'max');
                        }
                    } else {
                        $max = (int)$param;
                        if (\mb_strlen(str_value($value)) > $max) {
                            $this->addError($field, "حداکثر {$max} کاراکتر مجاز است", 'max');
                        }
                    }
                }
                break;

            case 'in':
                if ($value !== null && $value !== '') {
                    $allowed = \explode(',', (string)$param);
                    if (!\in_array(str_value($value), $allowed, true)) {
                        $this->addError($field, 'مقدار نامعتبر است', 'in');
                    }
                }
                break;

            case 'date':
                if ($value !== null && $value !== '' && \strtotime(str_value($value)) === false) {
                    $this->addError($field, 'تاریخ نامعتبر است', 'date');
                }
                break;

            // ✅ جدید: regex
            case 'regex':
                if ($value !== null && $value !== '' && !\preg_match((string)$param, str_value($value))) {
                    $this->addError($field, 'فرمت نامعتبر است', 'regex');
                }
                break;

            // ✅ جدید: url
            case 'url':
                // FIX-R19-A8-1: FILTER_VALIDATE_URL مقدارهایی مثل javascript:/data: را هم
                // می‌پذیرد — پس از اعتبارسنجی ساختاری، scheme به http/https محدود می‌شود.
                // یک اصلاح در اینجا همهٔ فیلدهای url (video_url/link/proof_url/target_url) را می‌پوشاند.
                if ($value !== null && $value !== '' && (
                    !\filter_var($value, FILTER_VALIDATE_URL)
                    || !\in_array(strtolower((string)\parse_url(str_value($value), PHP_URL_SCHEME)), ['http', 'https'], true)
                )) {
                    $this->addError($field, 'URL نامعتبر است', 'url');
                }
                break;

            // ✅ جدید: ip
            case 'ip':
                if ($value !== null && $value !== '' && !\filter_var($value, FILTER_VALIDATE_IP)) {
                    $this->addError($field, 'آدرس IP نامعتبر است', 'ip');
                }
                break;

            // ✅ جدید: numeric
            case 'numeric':
                // FIX-S4-5: به‌جای is_numeric، فقط نماد دهدهیِ سازگار با bcmath
                if ($value !== null && $value !== '' && !self::isBcMathNumber($value)) {
                    $this->addError($field, 'این فیلد باید عددی باشد', 'numeric');
                }
                break;

            // ✅ جدید: integer
            case 'integer':
                if ($value !== null && $value !== '' && !\filter_var($value, FILTER_VALIDATE_INT)) {
                    $this->addError($field, 'این فیلد باید عدد صحیح باشد', 'integer');
                }
                break;

            // ✅ جدید: boolean
            case 'boolean':
                if ($value !== null && $value !== '' && !\in_array($value, [true, false, 1, 0, '1', '0', 'true', 'false'], true)) {
                    $this->addError($field, 'این فیلد باید boolean باشد', 'boolean');
                }
                break;

            // ✅ جدید: string
            case 'string':
                if ($value !== null && $value !== '' && !\is_string($value)) {
                    $this->addError($field, 'این فیلد باید متن باشد', 'string');
                }
                break;

            // ✅ جدید: nullable
            case 'nullable':
                // Nullable fields are handled before applying other rules.
                break;

            // ✅ جدید: array
            case 'array':
                if ($value !== null && $value !== '' && !\is_array($value)) {
                    $this->addError($field, 'این فیلد باید آرایه باشد', 'array');
                }
                break;

            // ✅ جدید: confirmed - فیلدی برابر با field_confirmation
            case 'confirmed':
                $confirmationField = $field . '_confirmation';
                $confirmationValue = $this->data[$confirmationField] ?? null;
                if ($value !== $confirmationValue) {
                    $this->addError($field, 'تایید مطابقت ندارد', 'confirmed');
                }
                break;

            // ✅ جدید: phone
            case 'phone':
                if ($value !== null && $value !== '' && !\preg_match('/^(\+98|0)?9\d{9}$/', str_value($value))) {
                    $this->addError($field, 'شماره تلفن نامعتبر است', 'phone');
                }
                break;

            // ✅ جدید: mobile
            // FIX-P4-4: کلاس‌های پیشوند واقعی اپراتورهای ایران 090/091/092/093/099
            // پوشش داده می‌شوند؛ الگوی قبلی فقط 91x/92[1-9]/93[1-9] را می‌پذیرفت و
            // 090x و 099x (بخش بزرگی از شماره‌های واقعی) را رد می‌کرد.
            case 'mobile':
                if ($value !== null && $value !== '' && !\preg_match('/^(\+98|0)?9[01239]\d{8}$/', str_value($value))) {
                    $this->addError($field, 'شماره موبایل نامعتبر است', 'mobile');
                }
                break;

            // ✅ جدید: national_code (کد ملی ایران)
            case 'national_code':
                if (!$this->validateNationalCode(str_value($value))) {
                    $this->addError($field, 'کد ملی نامعتبر است', 'national_code');
                }
                break;

            // ✅ جدید: unique - فیلد در DB منحصر به فرد باشد
            case 'unique':
                // param: table.column
                if ($value !== null && $value !== '') {
                    if (!$this->isUnique($param, $value)) {
                        $this->addError($field, 'این مقدار قبلاً استفاده شده است', 'unique');
                    }
                }
                break;

            // ✅ جدید: exists - فیلد در DB موجود باشد
            case 'exists':
                // param: table.column
                if ($value !== null && $value !== '') {
                    if (!$this->valueExists($param, $value)) {
                        $this->addError($field, 'مقدار موجود نیست', 'exists');
                    }
                }
                break;

            // ✅ جدید: timezone
            case 'timezone':
                if ($value !== null && $value !== '' && !\in_array($value, \timezone_identifiers_list(), true)) {
                    $this->addError($field, 'منطقه زمانی نامعتبر است', 'timezone');
                }
                break;

            // ✅ جدید: json
            case 'json':
                if ($value !== null && $value !== '') {
                    \json_decode(str_value($value));
                    if (\json_last_error() !== JSON_ERROR_NONE) {
                        $this->addError($field, 'JSON نامعتبر است', 'json');
                    }
                }
                break;

            // ✅ جدید: uppercase
            case 'uppercase':
                if ($value !== null && $value !== '' && $value !== \strtoupper(str_value($value))) {
                    $this->addError($field, 'باید حروف بزرگ باشد', 'uppercase');
                }
                break;

            // ✅ جدید: lowercase
            case 'lowercase':
                if ($value !== null && $value !== '' && $value !== \strtolower(str_value($value))) {
                    $this->addError($field, 'باید حروف کوچک باشد', 'lowercase');
                }
                break;

            // ✅ جدید: persian
            case 'persian':
                if ($value !== null && $value !== '' && !\preg_match('/^[\x{0600}-\x{06FF}\s]+$/u', str_value($value))) {
                    $this->addError($field, 'فقط حروف فارسی مجاز است', 'persian');
                }
                break;

            // ✅ جدید: english
            case 'english':
                if ($value !== null && $value !== '' && !\preg_match('/^[a-zA-Z\s]+$/', str_value($value))) {
                    $this->addError($field, 'فقط حروف انگلیسی مجاز است', 'english');
                }
                break;

            // ─── R34: قواعدی که تا امروز بی‌صدا نادیده گرفته می‌شدند (یافتهٔ R30) ───

            case 'accepted':
                // FIX-R36-W3 (F-A9b-03): `accepted` ضمناً required است (قرارداد
                // Laravel) — قبلاً null/'' از این قاعده می‌گذشت و زنجیرهٔ bare
                // `accepted` بدون `required`، گیتِ رضایت/تعهد unchecked را پاس
                // می‌داد. اکنون مقدارِ غایب/خالی/غیرِپذیرفته همه شکست می‌خورند.
                if (!\in_array($value, [1, '1', true, 'true', 'on', 'yes'], true)) {
                    $this->addError($field, 'این فیلد باید پذیرفته شود', 'accepted');
                }
                break;

            case 'same':
                // param: نام فیلد هدف — مقایسهٔ سخت (reset-password: password_confirm)
                if ($value !== ($this->data[(string)$param] ?? null)) {
                    $this->addError($field, 'مقدار با فیلد تایید مطابقت ندارد', 'same');
                }
                break;

            case 'after_or_equal':
                // FIX-S17-F04 (بازبینی بخش ۱۷): قاعدهٔ مقایسه‌ای بین‌فیلدی برای تاریخ —
                // هم‌الگوی «same»؛ param نام فیلد مرجع است و مقدار باید >= تاریخ مرجع باشد.
                // قرارداد خطاها (هر خطا مالِ همان قاعده‌ای است که مسئولش را دارد):
                //  - مقدار خالی/غایب ⇒ skip (required خودِ فیلد مالک خطاست)
                //  - مرجع غایب/خالی ⇒ skip (required خودِ فیلد مرجع مالک خطاست)
                //  - هر یک از دو طرف غیرقابل‌تجزیه ⇒ skip (قاعدهٔ date همان فیلد مالک خطاست)
                //  - هر دو قابل‌تجزیه و مقدار < مرجع ⇒ خطای after_or_equal
                // هر دو طرف با strtotime در یک منطقهٔ زمانی (سرور) تفسیر می‌شوند، پس
                // مقایسهٔ امضای زمانی سازگار درون‌است؛ فرمت‌های ناهم‌جنس
                // (Y-m-d در برابر datetime-local) هم درست مقایسه می‌شوند.
                if ($param === null || $param === '') {
                    // R34-FAIL-LOUD: قاعده بدون فیلد مرجع = خطای برنامه‌نویس، نه دادهٔ کاربر
                    throw new \RuntimeException(
                        "Rule \"after_or_equal\" requires a reference field parameter for field \"{$field}\" (programmer error — rule string: \""
                        . str_value($this->rules[$field] ?? '') . '").'
                    );
                }
                if ($value !== null && $value !== '') {
                    $reference = $this->data[(string)$param] ?? null;
                    if ($reference === null || $reference === '') {
                        break;
                    }
                    $valueTs = \strtotime(str_value($value));
                    $referenceTs = \strtotime(str_value($reference));
                    if ($valueTs === false || $referenceTs === false) {
                        break;
                    }
                    if ($valueTs < $referenceTs) {
                        $this->addError($field, 'تاریخ باید برابر یا بعد از تاریخ مقایسه باشد', 'after_or_equal');
                    }
                }
                break;

            case 'alpha_dash':
                if ($value !== null && $value !== '' && \preg_match('/^[a-zA-Z0-9_-]+$/u', str_value($value)) !== 1) {
                    $this->addError($field, 'فقط حروف لاتین، اعداد، خط تیره و زیرخط مجاز است', 'alpha_dash');
                }
                break;

            case 'digits':
                $digitsLen = (int)$param;
                if ($digitsLen <= 0) {
                    throw new \RuntimeException("Rule \"digits\" requires a positive length parameter for field \"{$field}\" (programmer error).");
                }
                if ($value !== null && $value !== '' && \preg_match('/^[0-9]{' . $digitsLen . '}$/', str_value($value)) !== 1) {
                    $this->addError($field, "این فیلد باید دقیقاً {$digitsLen} رقم باشد", 'digits');
                }
                break;

            case 'date_format':
                if ($value !== null && $value !== '' && !$this->matchesDateFormat((string)$param, str_value($value))) {
                    $this->addError($field, 'قالب تاریخ نامعتبر است', 'date_format');
                }
                break;

            default:
                // R34-FAIL-LOUD: قاعدهٔ ناشناخته = خطای برنامه‌نویس؛ تا دیروز بی‌صدا رد می‌شد
                // و دادهٔ نامعتبر accepted می‌شد. RuntimeException عمداً از catch
                // (\InvalidArgumentException) در result() عبور می‌کند تا fail-loud باشد.
                throw new \RuntimeException(
                    "Unknown validation rule \"{$ruleName}\" for field \"{$field}\" (programmer error — rule string: \""
                    . str_value($this->rules[$field] ?? '') . '").'
                );
        }
    }

    // ✅ Helper functions برای validation

    /** R34: پشتیبان قاعدهٔ date_format — سخت‌گیرانه (rollover/نویسهٔ اضافی = رد) */
    private function matchesDateFormat(string $format, string $value): bool
    {
        $dt = \DateTime::createFromFormat($format, $value);
        if ($dt === false) {
            return false;
        }
        $errors = \DateTime::getLastErrors();
        if (is_array($errors) && ((int)($errors['warning_count'] ?? 0) > 0 || (int)($errors['error_count'] ?? 0) > 0)) {
            return false; // مثلاً 2026-02-30 که به مارس rollover می‌شود
        }
        return $dt->format($format) === $value; // roundtrip — نویسه‌های انتهایی اضافی را رد می‌کند
    }

    private function validateNationalCode(string $code): bool
    {
        // فرمت: 10 رقم
        if (!\preg_match('/^[0-9]{10}$/', $code)) {
            return false;
        }

        // الگوریتم check digit
        // FIX-P4-2: جمع فقط روی ۹ رقم اول (وزن‌های ۱۰ تا ۲) باید باشد؛ حلقهٔ قبلی
        // تا i<10 ادامه می‌یافت و رقم کنترل با وزن ۱ در جمع دخیل بود — نتیجه:
        // کدهای معتبر (مثل 1111111111 و 0499370899) رد و کدهای نامعتبر (مثل
        // 0000000001) قبول می‌شدند؛ با الگوریتم درست ProfileService نیز ناسازگار بود.
        $check = 0;
        for ($i = 0; $i < 9; $i++) {
            $check += (int)$code[$i] * (10 - $i);
        }
        $check = $check % 11;

        if ($check < 2) {
            return (int)$code[9] === $check;
        } else {
            return (int)$code[9] === 11 - $check;
        }
    }

    private function isUnique(?string $param, mixed $value): bool
    {
        $target = $this->parseDatabaseRuleTarget($param);
        if ($target === null) {
            return false;
        }
        [$table, $column] = $target;

        try {
            return (int)$this->getDb()->fetchColumn(
                "SELECT COUNT(*) FROM `{$table}` WHERE `{$column}` = ?",
                [$value]
            ) === 0;
        } catch (\Throwable) {
            // A failed uniqueness check must not silently authorize a duplicate.
            return false;
        }
    }

    private function valueExists(?string $param, mixed $value): bool
    {
        $target = $this->parseDatabaseRuleTarget($param);
        if ($target === null) {
            return false;
        }
        [$table, $column] = $target;

        try {
            return (int)$this->getDb()->fetchColumn(
                "SELECT COUNT(*) FROM `{$table}` WHERE `{$column}` = ?",
                [$value]
            ) > 0;
        } catch (\Throwable) {
            return false;
        }
    }

    /** @return array{string, string}|null */
    private function parseDatabaseRuleTarget(?string $param): ?array
    {
        if ($param === null || $param === '') {
            return null;
        }

        // Accept the established Laravel-style `table,column` syntax and the
        // legacy `table.column` form without destructuring an incomplete pair.
        $parts = preg_split('/[,.]/', $param, 2);
        if (!is_array($parts) || count($parts) !== 2) {
            return null;
        }
        [$table, $column] = array_map('trim', $parts);
        $identifier = '/^[a-zA-Z_][a-zA-Z0-9_]*$/';
        if (preg_match($identifier, $table) !== 1 || preg_match($identifier, $column) !== 1) {
            return null;
        }

        return [$table, $column];
    }

    protected function addError(string $field, string $message, ?string $rule = null): void
    {
        // FIX-P4-3: پیام سفارشی فقط برای همان «فیلد.قاعده» یا کل «فیلد» جایگزین
        // پیام پیش‌فرض می‌شود (قالب مصرف‌شدهٔ BaseFormRequest/ValidatorFactory).
        // قبلاً $this->messages ست می‌شد اما در addError هرگز خوانده نمی‌شد و
        // پیام‌های سفارشی بی‌صدا نادیده گرفته می‌شدند.
        if ($rule !== null && $this->messages !== []) {
            $custom = $this->messages[$field . '.' . $rule] ?? $this->messages[$field] ?? null;
            if (is_string($custom) && $custom !== '') {
                $message = $custom;
            }
        }

        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        $this->errors[$field][] = $message;
    }

    public function fails(): bool
    {
        return !empty($this->errors);
    }

    /** @return array<string, list<string>> */
    public function errors(): array
    {
        return $this->errors;
    }

    /**
     * FIX-M1M2 (گزارش ماژول ۱، M2): خروجی allowlist‌شده — فقط فیلدهایی که
     * واقعاً rule دارند. ورودی خام اضافه (مثل _csrf_token یا فیلد تزریقی)
     * هرگز از این مسیر بیرون نمی‌رود؛ این قراردادِ validated() استاندارد است.
     *
     * @return array<string, mixed>
     */
    public function validated(): array
    {
        $safe = [];
        foreach (array_keys($this->rules) as $field) {
            if (is_string($field) && array_key_exists($field, $this->data)) {
                $safe[$field] = $this->data[$field];
            }
        }
        return $safe;
    }

    // قانون 20
    /**
     * ورودی خام — صرفاً برای مصرف‌کننده‌هایی که آگاهانه به دادهٔ تیم نیاز دارند.
     * برای عبور داده به سرویس/مدل همیشه validated() را استفاده کنید.
     *
     * @return array<string, mixed>
     */
    public function data(): array
    {
        return $this->data;
    }

    /**
     * دریافت یک مقدار اعتبارسنجیشده بهصورت عدد صحیحِ امن.
     * مقدارِ نامعتبر (غیرعددی یا غیراسکالر) به default برمیگردد.
     */
    public function int(string $key, int $default = 0): int
    {
        $value = $this->data[$key] ?? $default;
        // FIX-S4-5: فقط اعداد معتبرِ متناهی؛ «1e999» به‌جای (int)INF خاموش، default برمی‌گردد
        if (is_int($value)) {
            return $value;
        }
        if (is_float($value)) {
            return is_finite($value) ? (int)$value : $default;
        }
        if (is_string($value) && preg_match(self::BC_MATH_NUMBER_PATTERN, $value) === 1) {
            return (int)$value;
        }
        return $default;
    }

    /**
     * دریافت یک مقدار اعتبارسنجیشده بهصورت عدد اعشاریِ امن.
     * مقدارِ نامعتبر (غیرعددی یا غیراسکالر) به default برمیگردد.
     */
    public function float(string $key, float $default = 0.0): float
    {
        $value = $this->data[$key] ?? $default;
        // FIX-S4-5: «1e999» دیگر INF تحویل نمی‌دهد؛ default برمی‌گردد
        if (is_int($value)) {
            return (float)$value;
        }
        if (is_float($value)) {
            return is_finite($value) ? $value : $default;
        }
        if (is_string($value) && preg_match(self::BC_MATH_NUMBER_PATTERN, $value) === 1) {
            return (float)$value;
        }
        return $default;
    }

    /**
     * دریافت یک مقدار اعتبارسنجیشده بهصورت رشتهی امن.
     * مقدارِ غیراسکالر (array/object/null) به default برمیگردد.
     */
    public function str(string $key, string $default = ''): string
    {
        $value = $this->data[$key] ?? $default;
        return is_scalar($value) ? (string)$value : $default;
    }

    /** @return array<string, mixed> */
    public function all(): array
    {
        return $this->data;
    }

    // ============================================================
    // Pipeline Methods - برای chain-able fluent validation
    // ============================================================

    /**
     * Set custom error messages for fields
     * 
     * @param array<string, mixed> $messages Custom messages
     * @return self
     */
    public function messages(array $messages): self
    {
        $this->messages = $messages;

        // FIX-R36-W3 (F-A9b-10): زنجیرهٔ fluent «create(data, rules)->messages([...])»
        // بی‌اثر بود (حمل‌شده R30 LOW) — سازنده بلافاصله validate() را با پیام‌های
        // پیش‌فرض اجرا می‌کرد و ست‌کردن messages پس از آن دیر بود (addError پیام‌های
        // سفارشی را می‌خواند ولی errors قبلاً با default بسته شده بود). اکنون اگر
        // قواعد اجرا شده‌اند، با پیام‌های تازه از نو محاسبه می‌شوند؛ مسیر سازنده‌ای
        // (ValidatorFactory/BaseFormRequest که messages را پیش از validate می‌دهند)
        // دست‌نخورده می‌ماند.
        if ($this->rulesEvaluated && !empty($this->rules)) {
            $this->errors = [];
            $this->validate($this->rules);
        }

        return $this;
    }

    /**
     * Add a custom validation rule (callback-based)
     * 
     * @param string $field Field name
     * @param callable $callback Validation callback (receives field value, returns bool)
     * @param string $errorMessage Error message if validation fails
     * @return self
     */
    public function custom(string $field, callable $callback, string $errorMessage): self
    {
        $this->customValidations[$field] = [
            'callback' => $callback,
            'message' => $errorMessage
        ];
        return $this;
    }

    /**
     * Set an authorization check (runs before validation)
     * 
     * @param callable $callback Authorization check (returns bool)
     * @return self
     */
    public function authorize(callable $callback): self
    {
        $this->authorizationCheck = $callback;
        return $this;
    }

    /**
     * Run validation and return result array (no exception)
     * 
     * @return array{valid: false, data: null, errors: array<string, mixed>, message: string}|array{valid: true, data: array<string, mixed>, errors: array<never, never>, message: ''}
     */
    public function result(): array
    {
        // Step 1: Authorization check
        if ($this->authorizationCheck !== null) {
            try {
                if (!($this->authorizationCheck)()) {
                    return [
                        'valid' => false,
                        'data' => null,
                        'errors' => ['authorization' => 'درخواست غیرمجاز'],
                        'message' => 'شما دسترسی لازم برای این عملیات را ندارید'
                    ];
                }
            } catch (\Throwable $e) {
                // FIX-M1M27 (گزارش ماژول ۱، M27): پیام خام استثنا به پاسخ کاربر
                // نمی‌رود — فقط لاگ داخلی؛ پاسخ generic است.
                try {
                    if (function_exists('logger')) {
                        logger()->error('validator.authorization_check_failed', ['error' => $e->getMessage()]);
                    } elseif (function_exists('error_log')) {
                        @error_log('[Chortke] validator.authorization_check_failed: ' . $e->getMessage());
                    }
                } catch (\Throwable) {
                    // لاگ هرگز جریان اعتبارسنجی را نمی‌شکند
                }
                return [
                    'valid' => false,
                    'data' => null,
                    'errors' => ['authorization' => 'درخواست غیرمجاز'],
                    'message' => 'خطا در بررسی دسترسی'
                ];
            }
        }

        // Step 2: Run standard rules validation if rules are set
        if (!empty($this->rules)) {
            try {
                $this->validate($this->rules);
            } catch (\InvalidArgumentException $e) {
                return [
                    'valid' => false,
                    'data' => null,
                    'errors' => [],
                    'message' => $e->getMessage()
                ];
            }
        }

        // If standard validation failed, return errors
        if (!empty($this->errors)) {
            return [
                'valid' => false,
                'data' => null,
                'errors' => $this->errors,
                'message' => 'اطلاعات ورودی نامعتبر است'
            ];
        }

        // Step 3: Run custom validations
        if (!empty($this->customValidations)) {
            foreach ($this->customValidations as $field => $validation) {
                try {
                    $value = $this->data[$field] ?? null;
                    if (!($validation['callback'])($value)) {
                        $this->addError($field, $validation['message']);
                    }
                } catch (\Throwable $e) {
                    $this->addError($field, 'خطا در بررسی: ' . $e->getMessage());
                }
            }

            if (!empty($this->errors)) {
                return [
                    'valid' => false,
                    'data' => null,
                    'errors' => $this->errors,
                    'message' => 'اطلاعات ورودی نامعتبر است'
                ];
            }
        }

        return [
            'valid' => true,
            'data' => $this->data,
            'errors' => [],
            'message' => ''
        ];
    }

    /**
     * Validate and throw ValidationException on failure
     *
     * @return array<string, mixed> Validated data
     * @throws \Core\Exceptions\ValidationException If validation fails
     */
    public function validateOrFail(): array
    {
        $result = $this->result();
        if (!$result['valid']) {
            throw new \Core\Exceptions\ValidationException(
                $result['errors'],
                $result['message'] ?: 'اطلاعات ورودی نامعتبر است'
            );
        }
        return $result['data'];
    }

    /**
     * Check if validation passed (alias for !fails())
     * 
     * @return bool
     */
    public function passes(): bool
    {
        return !$this->fails();
    }

    /**
     * Static factory for fluent interface
     * 
     * @param array<string, mixed> $data Input data
     * @param array<string, mixed> $rules Validation rules
     * @return self
     */
    public static function create(array $data, array $rules = []): self
    {
        return new self($data, $rules);
    }
}
