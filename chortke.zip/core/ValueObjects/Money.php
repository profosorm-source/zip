<?php

declare(strict_types=1);

namespace Core\ValueObjects;

use InvalidArgumentException;

/**
 * Money Value Object
 *
 * مدیریت امن مبالغ برای جلوگیری از خطای اعشار و تداخل محاسباتی.
 * تمام مبالغ به صورت string (سازگار با bcmath) نگهداری می‌شوند.
 *
 * 🛡️ استانداردهای مالی ارتقا یافته (مبارزه با float):
 *   - طبق دستورالعمل طلایی، استفاده از float برای ذخیره یا محاسبه مبالغ اکیداً ممنوع است.
 *   - مبالغ فقط به صورت عدد صحیح (Integer) یا رشته‌های بزرگ محاسباتی (BCMath) پردازش می‌شوند.
 *   - تمام ورودی‌های float بلافاصله رد شده و استثنا پرتاب می‌کنند.
 *
 * Scale پیش‌فرض بر اساس ارز:
 *   IRT (تومان)            → 4 رقم اعشار  ← واحد رسمی پلتفرم چرتکه
 *   IRR (ریال)             → 4 رقم اعشار  ← فقط برای سازگاری با درگاه‌های پرداخت
 *   USDT / BTC / ...       → 8 رقم اعشار (سازگار با crypto)
 *
 * توجه ارزی (CURRENCY-UNIT-2026-06):
 *   واحد پایه‌ی همه‌ی نمایش‌ها، ذخیره‌سازی DB، و گزارش‌ها در چرتکه «تومان» (IRT) است.
 *   ریال (IRR) فقط در لایه‌ی آداپتر درگاه پرداخت (DgPay, IDPay, NextPay) و در
 *   لحظه‌ی تبدیل برای ارسال به API بانکی استفاده می‌شود — و سپس فوراً به IRT
 *   بازمی‌گردد. هیچ ستون DB، هیچ نمایش UI، و هیچ default سرویس در سطح اپ
 *   نباید IRR را به‌عنوان واحد ذخیره‌سازی یا نمایش استفاده کند.
 */
readonly class Money
{
    /** scale پیش‌فرض برای ارزهای fiat (IRT / IRR) */
    public const SCALE_FIAT   = 4;

    /** scale پیش‌فرض برای ارزهای دیجیتال (USDT/BTC/...) */
    public const SCALE_CRYPTO = 8;

    /** scale داخلی میانی برای محاسبات درصدی (جلوگیری از تجمع خطا) */
    private const INTERNAL_SCALE = 10;

    /** واحد پولی پیش‌فرض پلتفرم — تومان */
    public const DEFAULT_CURRENCY = 'IRT';

    private string $amount;
    private string $currency;

    /**
     * @param string|int $amount مبلغ به صورت رشته یا عدد صحیح — float مجاز نیست
     */
    public function __construct(string|int|float $amount, string $currency = self::DEFAULT_CURRENCY) {
        // Float is deliberately excluded by the public contract (see @param).
        // نوع نیتیو عمداً float را هم می‌پذیرد تا به‌جای coercion خاموشِ PHP
        // (که 0.1 را به 0 تبدیل می‌کند و پول را نابود می‌کند) یک TypeError
        // صریح پرتاب شود — حتی وقتی فراخوان از فایلی بدون strict_types یا از
        // مسیر Reflection/کانتینر انجام شده باشد.
        self::rejectFloat($amount, 1, 'amount', __FUNCTION__);

        $cleaned = trim((string)$amount);
        if (!preg_match('/^-?\d+(\.\d+)?$/', $cleaned)) {
            throw new InvalidArgumentException("Invalid monetary amount: '{$cleaned}'");
        }
        $this->currency = strtoupper((string)$currency);
        // FIX-M12-04 (گزارش ماژول ۱۲): کانونی‌سازی یک‌باره در سازنده — قبلاً مقدار خام
        // بیش‌ازscale ذخیره می‌شد و مقایسه/نمایش آن را در scale قطع می‌کردند (value object
        // با دو قرارداد دقت). اکنون با همان معناشناسی قطعِ bccomp (truncate) در scale ارز
        // کانونی می‌شود تا getAmount/comparison/format همیشه یک invariant داشته باشند.
        // ردِ مقدار بیش‌ازscale در مرزهای ورودی (validatorها) باید جداگانه اعمال شود.
        $this->amount = $this->canonicalize($cleaned);
    }

    /** FIX-M12-04: کوانتیزه به scale ارز (truncate، هم‌معنای bccomp) + حذف صفرهای انتهایی */
    private function canonicalize(string $cleaned): string
    {
        $quantized = bcmul($cleaned, '1', $this->getScale());
        return self::stripTrailingZeroesStatic($quantized);
    }

    /**
     * نگهبان صریح ضد float در مرز عمومی Money.
     *
     * تایپ‌های نیتیو PHP فقط زمانی float را رد می‌کنند که فراخوان در فایلی با
     * declare(strict_types=1) باشد. در حالت coercive (یا از مسیر Reflection،
     * call_user_func_array، کانتینر DI و ...) مقدار float بی‌سروصدا cast می‌شود
     * و مثلاً 0.1 به 0 تبدیل می‌گردد — یعنی از دست رفتن خاموشِ پول. این متد
     * صرف‌نظر از حالت فراخوان، همان TypeError مورد انتظار قرارداد عمومی را
     * پرتاب می‌کند.
     *
     * @throws \TypeError
     */
    private static function rejectFloat(mixed $value, int $position, string $name, string $method): void
    {
        if (is_float($value)) {
            throw new \TypeError(sprintf(
                '%s::%s(): Argument #%d ($%s) must be of type string|int, float given. '
                . 'Floats are forbidden for monetary values; pass a decimal string instead.',
                self::class,
                $method === '__construct' ? '__construct' : $method,
                $position,
                $name
            ));
        }
    }

    // ─── Factory methods ──────────────────────────────────────────────────────

    public static function fromString(string $amount, string $currency = self::DEFAULT_CURRENCY): self
    {
        return new self($amount, $currency);
    }

    public static function fromInt(int $amount, string $currency = self::DEFAULT_CURRENCY): self
    {
        return new self($amount, $currency);
    }

    /**
     * Factory با scale خودکار بر اساس ارز
     */
    public static function of(string $amount, string $currency = self::DEFAULT_CURRENCY): self
    {
        return new self($amount, $currency);
    }

    // ─── Getters ──────────────────────────────────────────────────────────────

    public function getAmount(): string
    {
        return $this->amount;
    }

    public function getCurrency(): string
    {
        return $this->currency;
    }

    /** scale مناسب برای ارز این شیء */
    public function getScale(): int
    {
        return self::scaleForCurrency($this->currency);
    }

    public static function scaleForCurrency(string $currency): int
    {
        // FIX-M12-28 (گزارش ماژول ۱۲): fallback پنهانِ «ارز ناشناخته → crypto scale» حذف
        // شد — IRR فقط در مرز آداپتر درگاه مجاز است (CURRENCY-UNIT-2026-06) و ارزِ ناشناخته
        // دیگر بی‌صدا scale هشت‌رقمی نمی‌گیرد؛ رد صریح با InvalidArgumentException تا
        // misuse در caller/آداپتر آینده زود-شکست و آشکار شود.
        return match (strtoupper((string)$currency)) {
            'IRR', 'IRT', 'TOMAN' => self::SCALE_FIAT,
            'USDT', 'BTC', 'ETH', 'TRX', 'TON', 'SOL', 'BNB' => self::SCALE_CRYPTO,
            default => throw new InvalidArgumentException(
                "Unsupported currency '{$currency}'. Allowed: IRT/TOMAN (fiat), IRR (gateway adapter only), USDT/BTC/ETH/TRX/TON/SOL/BNB (crypto)."
            ),
        };
    }

    /** FIX-M12-04: نسخهٔ استاتیک حذف صفرهای انتهایی برای کانونی‌ساز سازنده */
    private static function stripTrailingZeroesStatic(string $amount): string
    {
        if (!str_contains($amount, '.')) {
            return $amount;
        }
        $trimmed = rtrim(rtrim($amount, '0'), '.');
        return $trimmed === '' || $trimmed === '-' ? '0' : $trimmed;
    }

    // ─── Arithmetic ───────────────────────────────────────────────────────────

    public function add(Money $other): self
    {
        $this->assertSameCurrency($other);
        $scale  = $this->getScale();
        $result = bcadd($this->amount, $other->getAmount(), $scale);
        return new self($this->stripTrailingZeroes($result), $this->currency);
    }

    public function subtract(Money $other): self
    {
        $this->assertSameCurrency($other);
        $scale  = $this->getScale();
        $result = bcsub($this->amount, $other->getAmount(), $scale);
        return new self($this->stripTrailingZeroes($result), $this->currency);
    }

    /**
     * @param string|int $multiplier ضریب — float مجاز نیست (خطای دقت اعشاری)
     */
    public function multiply(string|int|float $multiplier): self
    {
        self::rejectFloat($multiplier, 1, 'multiplier', __FUNCTION__);

        // FIX-M12-31 (گزارش ماژول ۱۲): operand هم‌گرامار سازنده اعتبارسنجی می‌شود —
        // قبلاً رشتهٔ خام مستقیم به bcmul می‌رفت و exponent/malformed به خطای پایین‌دست
        // نامشخص (ValueError/ناخوانا) می‌رسید نه InvalidArgumentException قراردادی.
        $multiplierStr = (string)$multiplier;
        self::assertDecimalOperand($multiplierStr, __FUNCTION__);

        $scale = $this->getScale();
        $result = bcmul($this->amount, $multiplierStr, $scale);
        return new self($this->stripTrailingZeroes($result), $this->currency);
    }

    /**
     * تقسیم مقدار بر یک عدد
     */
    /**
     * @param string|int $divisor مقسوم‌علیه — float مجاز نیست (خطای دقت اعشاری)
     */
    public function divide(string|int|float $divisor): self
    {
        self::rejectFloat($divisor, 1, 'divisor', __FUNCTION__);

        $scale = $this->getScale();
        $dStr  = (string)$divisor;
        // FIX-M12-31: گارماری operand + پیام دامنه‌ای روشن برای صفر
        self::assertDecimalOperand($dStr, __FUNCTION__);
        if (bccomp($dStr, '0', self::INTERNAL_SCALE) === 0) {
            throw new InvalidArgumentException('Division by zero is not allowed.');
        }
        $result = bcdiv($this->amount, $dStr, $scale);
        return new self($this->stripTrailingZeroes($result), $this->currency);
    }

    /**
     * محاسبه X درصد از این مبلغ (برای کارمزد، مالیات و...)
     *
     * @param string|int $percent درصد — float مجاز نیست (خطای دقت اعشاری)
     */
    public function percentage(string|int|float $percent): self
    {
        self::rejectFloat($percent, 1, 'percent', __FUNCTION__);

        // FIX-M12-31: گارماری operand برای درصد هم (هم‌قرارداد multiply/divide)
        $percentStr = (string)$percent;
        self::assertDecimalOperand($percentStr, __FUNCTION__);

        $scale = $this->getScale();
        $factor = bcdiv($percentStr, '100', self::INTERNAL_SCALE);
        $result = bcmul($this->amount, $factor, $scale);
        return new self($this->stripTrailingZeroes($result), $this->currency);
    }

    /**
     * FIX-M12-31: نگهبان گارماری operandهای دهدهی — همان قرارداد سازنده.
     * رشته‌های علمی (1e2)، float-shaped و malformed با InvalidArgumentException
     * قراردادی رد می‌شوند، نه با خطای BCMath پایین‌دست.
     */
    private static function assertDecimalOperand(string $operand, string $method): void
    {
        if (!preg_match('/^-?\d+(\.\d+)?$/', trim($operand))) {
            throw new InvalidArgumentException(
                "Invalid decimal operand '{$operand}' for Money::{$method}() — plain decimal string required."
            );
        }
    }

    /**
     * نگه‌داشتن فقط scale رقم اعشار (بدون گرد کردن — truncate)
     */
    public function toScale(int $scale): self
    {
        $result = bcadd($this->amount, '0', $scale);
        return new self($result, $this->currency);
    }

    // ─── Comparison ───────────────────────────────────────────────────────────

    public function isGreaterThan(Money $other): bool
    {
        $this->assertSameCurrency($other);
        return bccomp($this->amount, $other->getAmount(), $this->getScale()) === 1;
    }

    public function isGreaterThanOrEqual(Money $other): bool
    {
        $this->assertSameCurrency($other);
        return bccomp($this->amount, $other->getAmount(), $this->getScale()) >= 0;
    }

    public function isLessThan(Money $other): bool
    {
        $this->assertSameCurrency($other);
        return bccomp($this->amount, $other->getAmount(), $this->getScale()) === -1;
    }

    public function isZero(): bool
    {
        return bccomp($this->amount, '0', $this->getScale()) === 0;
    }

    public function isNegative(): bool
    {
        return bccomp($this->amount, '0', $this->getScale()) === -1;
    }

    public function isPositive(): bool
    {
        return bccomp($this->amount, '0', $this->getScale()) === 1;
    }

    public function equals(Money $other): bool
    {
        $this->assertSameCurrency($other);
        return bccomp($this->amount, $other->getAmount(), $this->getScale()) === 0;
    }

    // ─── Output ───────────────────────────────────────────────────────────────

    /**
     * فرمت‌سازی کاملاً دقیق و رشته‌ای بدون استفاده از float و تابع لرزان number_format
     */
    public function format(): string
    {
        $scale = $this->getScale();
        
        $parts = explode('.', $this->amount);
        $integerPart = $parts[0];
        $decimalPart = $parts[1] ?? '';
        
        // FIX-R36-W3 (F-A9b-02): گروه‌بندی هزارگان برای مبالغ منفی — علامتِ '-' در
        // حلقهٔ قبلی داخل شمارش طول بود و وقتی تعداد ارقام مضربِ ۳ بود، ویرگولِ
        // واهی بلافاصله بعد از علامت می‌نشست (‎-617 → "‎-,617"؛ ‎-123456 → "‎-,123,456").
        // اکنون فقط ارقامِ بعد از علامت گروه‌بندی می‌شوند.
        $sign = '';
        $digits = (string)$integerPart;
        if ($digits !== '' && $digits[0] === '-') {
            $sign = '-';
            $digits = substr($digits, 1);
        }
        $formattedInteger = '';
        $len = strlen($digits);
        for ($i = 0; $i < $len; $i++) {
            if ($i > 0 && ($len - $i) % 3 === 0) {
                $formattedInteger .= ',';
            }
            $formattedInteger .= $digits[$i];
        }
        if ($sign !== '') {
            $formattedInteger = $sign . $formattedInteger;
        }
        
        if ($scale === self::SCALE_FIAT || $decimalPart === '') {
            // 🛡️ FIX-S6-1: قبلاً شاخهٔ fiat کل بخش اعشاری را بدون هیچ شرطی حذف می‌کرد —
            // 617.2500 تومان «617 تومان» نمایش داده می‌شد (0.9999 → «0 تومان»؛ -0.5 → «-0 تومان»)
            // در حالی که همان مقدار کسری در DB ثبت و به کیف پول واریز شده است؛ یعنی
            // نوتیفیکیشن/ایمیل/نمایش با واقعیت دیتابیس یکی نبود — نقض قرارداد
            // SCALE_FIAT=4 (docblock کلاس: «IRT → 4 رقم اعشار ← واحد رسمی») و ادعای
            // «فرمت‌سازی کاملاً دقیق» همین متد. اکنون بخش اعشاریِ معنادار تا سقف scale
            // نمایش داده می‌شود و صفرهای انتهایی حذف می‌شوند؛ مبالغ صحیح عیناً مثل
            // قبل (بدون .00) و مسیر crypto بدون تغییر باقی می‌ماند.
            $visibleDecimals = $decimalPart === ''
                ? ''
                : rtrim(substr(str_pad($decimalPart, $scale, '0'), 0, $scale), '0');
            $formattedAmount = $visibleDecimals === ''
                ? $formattedInteger
                : $formattedInteger . '.' . $visibleDecimals;
        } else {
            $formattedAmount = $formattedInteger . '.' . substr(str_pad($decimalPart, $scale, '0'), 0, $scale);
        }

        $currencyName = match ($this->currency) {
            'IRR'   => 'ریال',
            'IRT'   => 'تومان',
            'USDT'  => 'USDT',
            default => $this->currency,
        };
        return "{$formattedAmount} {$currencyName}";
    }

    /** خروجی رشته‌ای برای ذخیره در DB */
    public function __toString(): string
    {
        return $this->amount;
    }

    // ─── Private helpers ──────────────────────────────────────────────────────

    private function assertSameCurrency(Money $other): void
    {
        if ($this->currency !== $other->getCurrency()) {
            throw new InvalidArgumentException(
                "Currency mismatch: {$this->currency} vs {$other->getCurrency()}"
            );
        }
    }

    private function stripTrailingZeroes(string $value): string
    {
        if (str_contains($value, '.')) {
            $value = rtrim(rtrim($value, '0'), '.');
        }
        return $value === '' ? '0' : $value;
    }
}
