<?php

declare(strict_types=1);

namespace Core\Console;

use Core\Container;
use ReflectionMethod;
use ReflectionNamedType;

/** @phpstan-type CommandConfig array{class: class-string<object>, description: string} */
class CliDispatcher
{
    private Container $container;
    /** @var array<string, CommandConfig> */
    private array $commands = [];

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    public function register(string $name, string $commandClass, string $description = ''): void
    {
        if ($name === '' || preg_match('/^[a-z][a-z0-9_-]*(?::[a-z0-9_*_-]+)*$/', $name) !== 1) {
            throw new \InvalidArgumentException('CLI command name has an invalid format.');
        }
        if (!class_exists($commandClass)) {
            throw new \InvalidArgumentException("CLI command class '{$commandClass}' does not exist.");
        }

        $hasPublicEntryPoint = false;
        foreach (['execute', 'run'] as $methodName) {
            if (method_exists($commandClass, $methodName) && (new ReflectionMethod($commandClass, $methodName))->isPublic()) {
                $hasPublicEntryPoint = true;
                break;
            }
        }
        if (!$hasPublicEntryPoint) {
            throw new \InvalidArgumentException(
                "CLI command class '{$commandClass}' must define a public run() or execute() method."
            );
        }

        $this->commands[$name] = ['class' => $commandClass, 'description' => $description];
    }

    /** @param list<string> $argv */
    public function run(array $argv): void
    {
        if (count($argv) < 2 || in_array('--help', $argv, true) || in_array('-h', $argv, true) || in_array('help', $argv, true)) {
            $this->showHelp();
            return;
        }
        $action = $argv[1];
        $matchedCommand = $this->resolveCommand($action);
        if ($matchedCommand === null) {
            $this->output("\n❌ Error: Command '{$action}' not found.\n", true);
            $this->showHelp();
            exit(1);
        }
        try {
            $commandClass = $matchedCommand['class'];
            $instance = $this->container->make($commandClass);
            $args = array_values(array_slice($argv, 2));
            $exitCode = $this->executeCommand($instance, $argv, $args, $commandClass);
            if ($exitCode !== 0) {
                exit($exitCode);
            }
        } catch (\Throwable $e) {
            $this->output("\n❌ CLI execution failed: " . $e->getMessage() . "\n", true);
            exit(1);
        }
    }

    /** @return CommandConfig|null */
    private function resolveCommand(string $action): ?array
    {
        foreach ($this->commands as $name => $config) {
            if ($action === $name || (str_ends_with($name, ':*') && str_starts_with($action, rtrim($name, '*')))) {
                return $config;
            }
        }
        return null;
    }

    /**
     * @param list<string> $argv
     * @param list<string> $args
     */
    private function executeCommand(object $instance, array $argv, array $args, string $className): int
    {
        // FIX-C141 (یافتهٔ ۱۴۱): قرارداد کد خروج — besides int return, an array
        // result may carry an explicit `exit_code` key so one-shot commands can
        // report failure to cron/supervisor without breaking their structured
        // result contract (queue:work / dlq:work style commands).
        if (method_exists($instance, 'execute')) {
            $method = new ReflectionMethod($instance, 'execute');
            $result = $this->invokeBySignature($instance, $method, $argv, $args);
            $this->printReturnValue($result);
            return $this->normalizeExitCode($result);
        }
        if (method_exists($instance, 'run')) {
            $method = new ReflectionMethod($instance, 'run');
            $result = $this->invokeBySignature($instance, $method, $argv, $args);
            $this->printReturnValue($result);
            return $this->normalizeExitCode($result);
        }
        throw new \RuntimeException("Command class {$className} must implement run() or execute() method.");
    }

    /**
     * FIX-C141: نگاشت نتیجهٔ فرمان به کد خروج.
     *  - int ⇒ همان کد خروج
     *  - array با کلید 'exit_code' (int) ⇒ همان کد (فرمان‌های ساختارمند)
     *  - بقیه (void/array معمولی) ⇒ 0
     */
    private function normalizeExitCode(mixed $result): int
    {
        if (is_int($result)) {
            return $result;
        }
        if (is_array($result) && isset($result['exit_code']) && is_int($result['exit_code'])) {
            return $result['exit_code'];
        }
        return 0;
    }

    /**
     * @param list<string> $argv
     * @param list<string> $args
     */
    private function invokeBySignature(object $instance, ReflectionMethod $method, array $argv, array $args): mixed
    {
        $params = $method->getParameters();
        if (count($params) === 0) {
            return $method->invoke($instance);
        }
        $first = $params[0];
        $type = $first->getType();
        $typeName = $type instanceof ReflectionNamedType ? $type->getName() : null;
        if ($typeName === 'array' || $first->isArray()) {
            $name = strtolower($first->getName());
            return $method->invoke($instance, in_array($name, ['argv', 'rawargv'], true) ? $argv : $args);
        }
        if ($method->getNumberOfRequiredParameters() === 0) {
            return $method->invoke($instance);
        }
        return $method->invoke($instance, $args);
    }

    private function printReturnValue(mixed $value): void
    {
        if ($value === null || is_int($value)) {
            return;
        }
        if (is_string($value)) {
            $this->output($value . (str_ends_with($value, "\n") ? '' : "\n"));
            return;
        }
        if (is_array($value)) {
            $encoded = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
            $this->output(($encoded !== false ? $encoded : print_r($value, true)) . "\n");
            return;
        }
        if (is_scalar($value)) {
            $this->output((string)$value . "\n");
        }
    }

    private function showHelp(): void
    {
        $buffer = "\nChortke Enterprise CLI\n========================\nUsage:\n  php cli.php <command> [options] [--help|-h]\n\nAvailable Commands:\n";
        $groups = [];
        foreach ($this->commands as $name => $config) {
            $parts = explode(':', $name, 2);
            $prefix = count($parts) > 1 ? $parts[0] : 'system';
            $groups[$prefix][$name] = $config['description'];
        }
        ksort($groups);
        foreach ($groups as $prefix => $commands) {
            $buffer .= "\n  " . ucfirst($prefix) . "\n";
            foreach ($commands as $name => $desc) {
                $buffer .= "    " . str_pad($name, 25) . " " . $desc . "\n";
            }
        }
        $buffer .= "\n";
        $this->output($buffer);
    }

    private function output(string $message, bool $isErr = false): void
    {
        $stream = $isErr ? (defined('STDERR') ? STDERR : STDOUT) : STDOUT;
        if (!function_exists('stream_isatty') || !stream_isatty($stream)) {
            // FIX-R36-W3 (F-A9b-13): قبلاً فقط SGR (…m) حذف می‌شد (حمل‌شده R30 INFO) —
            // \033[2K، کدهای مکان‌نما و OSC در لاگِ دیمونِ non-TTY می‌ماندند.
            $message = $this->stripAnsiEscapes($message);
        }
        if ($stream !== STDOUT && defined('STDERR')) {
            fwrite(STDERR, $message);
            fflush(STDERR);
        } else {
            echo $message;
        }
    }

    /**
     * FIX-R36-W3 (F-A9b-13): حذف کامل توالی‌های ANSI ESC برای خروجی non-TTY —
     * همهٔ CSI (شامل SGR، پاک‌کردن خط، جابه‌جایی مکان‌نما و مودهای private با «؟»)،
     * توالی‌های OSC (عنوان ترمینال؛ پایانهٔ BEL یا ST) و BELِ باقی‌مانده.
     */
    private function stripAnsiEscapes(string $message): string
    {
        $message = (string)preg_replace(
            [
                '/\x1B\[[0-9;?<=>]*[A-Za-z]/',
                '/\x1B\][^\x07\x1B]*(?:\x07|\x1B\\\\)/',
                '/\x07/',
            ],
            '',
            $message
        );
        return $message;
    }
}
