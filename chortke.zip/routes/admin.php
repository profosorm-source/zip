<?php

/**
 * مسیرهای پنل مدیریت
 */

use App\Middleware\AuthMiddleware;
use App\Middleware\AdminMiddleware;
use App\Middleware\AdminGuestMiddleware;
use App\Middleware\CSRFMiddleware;
use App\Middleware\RateLimitMiddleware;
use App\Middleware\AdminPermissionGuard;
use App\Controllers\Admin\AuthController          as AdminAuthController;
use App\Controllers\Admin\DashboardController     as AdminDashboardController;
use App\Controllers\Admin\UserController          as AdminUserController;
use App\Controllers\Admin\KYCController           as AdminKYCController;
use App\Controllers\Admin\LogController           as AdminLogController;
use App\Controllers\Admin\NotificationController  as AdminNotificationController;
use App\Controllers\Admin\BankCardController      as AdminBankCardController;
use App\Controllers\Admin\ManualDepositController as AdminManualDepositController;
use App\Controllers\Admin\CryptoDepositController as AdminCryptoDepositController;
use App\Controllers\Admin\WithdrawalController    as AdminWithdrawalController;
use App\Controllers\Admin\TransactionController   as AdminTransactionController;
use App\Controllers\Admin\OnlinePaymentController as AdminOnlinePaymentController;
use App\Controllers\Admin\SocialAccountController as AdminSocialAccountController;
use App\Controllers\Admin\AdTaskController        as AdminAdTaskController;
use App\Controllers\Admin\ExecutorTaskController  as AdminExecutorTaskController;
use App\Controllers\Admin\RoleController          as AdminRoleController;
use App\Controllers\Admin\ReferralController      as AdminReferralController;
use App\Controllers\Admin\LevelController         as AdminLevelController;
use App\Controllers\Admin\InfluencerController     as AdminInfluencerController;
use App\Controllers\Admin\ContentController       as AdminContentController;
use App\Controllers\Admin\InvestmentController    as AdminInvestmentController;
use App\Controllers\Admin\LotteryController       as AdminLotteryController;
use App\Controllers\Admin\AdminAdsController;
use App\Controllers\Admin\BannerController        as AdminBannerController;
use App\Controllers\Admin\BugReportController     as AdminBugReportController;
use App\Controllers\Admin\SeoAdController         as AdminSeoAdController;
use App\Controllers\Admin\KpiController;
use App\Controllers\Admin\SystemSettingController;
use App\Controllers\Admin\TicketController        as AdminTicketController;
use App\Controllers\Admin\CouponController        as AdminCouponController;
use App\Controllers\Admin\FraudController;
use App\Controllers\Admin\FraudDashboardController;
use App\Controllers\Admin\FraudManagementController;
use App\Controllers\Admin\FraudReportsAdminController; // X372 (راند ۹۳): صف بررسی گزارش‌های تخلف

use App\Controllers\Admin\AuditTrailController;
use App\Controllers\Admin\AdminExportController;
use App\Controllers\Admin\FeatureFlagController;
use App\Controllers\SearchController;
use App\Controllers\Admin\RiskPolicyController;
use App\Controllers\Admin\ScoreManagementController;
use App\Controllers\Admin\SentryAdminController;
use App\Controllers\Admin\SocialTaskController as AdminSocialTaskController;
use App\Controllers\Admin\MessageModerationController;
use App\Controllers\Admin\AccountDeletionManagementController;
use App\Controllers\Admin\BackupManagementController;
use App\Controllers\Admin\DatabaseHealthController;
use App\Controllers\Admin\AdminAnalyticsController;

// RBAC (M-10): AdminPermissionGuard در انتهای زنجیره قرار دارد تا پس از احراز هویت/ادمین
// برای هر مسیرِ پنل، مجوزِ ریزدانه (deny-by-default) را از config/admin_permissions.php اعمال کند.
// چون تمامی routeهای ادمین از $admin (یا array_merge($admin, ...)) استفاده می‌کنند، گارد خودکار روی همه اعمال می‌شود.
$admin     = [AuthMiddleware::class, AdminMiddleware::class, CSRFMiddleware::class, RateLimitMiddleware::class . ':30,1', AdminPermissionGuard::class];
$adminCSRF = $admin;
$r         = app()->router;

// ── داشبورد یکپارچه تبلیغات ───────────────────────────────────────────────
$r->get('/admin/ads',        [AdminAdsController::class, 'index'],      $admin);
$r->get('/admin/ads/stats',  [AdminAdsController::class, 'stats'],       $admin);
$r->post('/admin/ads/bulk', [AdminAdsController::class, 'bulkAction'],  $admin);
$r->post('/admin/ads/{id}/action', [AdminAdsController::class, 'action'], $admin);
$r->get('/admin/ads/{id}',  [AdminAdsController::class, 'show'],        $admin);

// ── ورود/خروج ──────────────────────────────────────────────────────────────
// FIX-R36-W3 (F-A3-08): صفحات مهمانِ ادمین گارد سبک AdminGuestMiddleware گرفتند —
// کاربرِ کاملاً لاگین‌شده (هر نقشی) دیگر فرم ورود/تأیید 2FA ادمین را نمی‌بیند.
// سشنِ pending-2FA (بدون LOGGED_IN) عبور می‌کند تا جریان 2FA ادمین نشکند.
$r->get('/admin/login',   [AdminAuthController::class, 'showLogin'], [AdminGuestMiddleware::class]);
// FIX-36/F-A3-04: پارامتر صریح ':10,1' حذف شد — سقف تیون‌شدهٔ config
// (admin.login = 3/10دقیقه) حالا از route_map اعمال می‌شود (ورودی '/admin/login'
// به config/rate_limits.php اضافه شد؛ پارامتر صریح overrideِ config را خفه می‌کرد).
$r->post('/admin/login',  [AdminAuthController::class, 'login'], [AdminGuestMiddleware::class, CSRFMiddleware::class, RateLimitMiddleware::class]);
$r->get('/admin/verify-2fa',  [AdminAuthController::class, 'showVerify2FA'], [AdminGuestMiddleware::class]);
// FIX-MODULE2-M3: RateLimitMiddleware به POST /admin/verify-2fa اضافه شد —
// ورودی route_map '/admin/verify-2fa' => ['admin','2fa_verify'] (سقف ۳/۱۰دقیقه)
// از ابتدا تعریف شده بود ولی چون این روت RateLimitMiddleware نداشت، آن map
// dead config بود و این اندپوینت حساس سقف عمومی را می‌گرفت.
$r->post('/admin/verify-2fa', [AdminAuthController::class, 'verify2FA'], [AdminGuestMiddleware::class, CSRFMiddleware::class, RateLimitMiddleware::class]);
$r->post('/admin/logout', [AdminAuthController::class, 'logout'], [AuthMiddleware::class, AdminMiddleware::class, CSRFMiddleware::class, RateLimitMiddleware::class . ':20,1']);

// ── داشبورد ────────────────────────────────────────────────────────────────
// FIX-X112: closure → controller (رفتار عیناً حفظ شده: ریدایرکت ساده بدون middleware)
$r->get('/admin', [AdminDashboardController::class, 'redirectToPanel']);
$r->get('/admin/dashboard',                   [AdminDashboardController::class, 'index'],          $admin);
$r->get('/admin/dashboard/recent-activity',   [AdminDashboardController::class, 'recentActivity'], $admin);
$r->get('/admin/dashboard/system-status',     [AdminDashboardController::class, 'systemStatus'],   $admin);

// ── کاربران ────────────────────────────────────────────────────────────────
$r->get('/admin/users',                [AdminUserController::class, 'index'], $admin);
$r->get('/admin/users/create',         [AdminUserController::class, 'create'], $admin);
$r->post('/admin/users/store',         [AdminUserController::class, 'store'], $admin);
$r->get('/admin/users/{id}/edit',      [AdminUserController::class, 'edit'], $admin);
$r->post('/admin/users/{id}/update',   [AdminUserController::class, 'update'], $admin);
$r->post('/admin/users/{id}/ban',      [AdminUserController::class, 'ban'], $admin);
$r->post('/admin/users/{id}/unban',    [AdminUserController::class, 'unban'], $admin);
$r->post('/admin/users/{id}/suspend',  [AdminUserController::class, 'suspend'], $admin);
$r->post('/admin/users/{id}/unsuspend',[AdminUserController::class, 'unsuspend'], $admin);
$r->post('/admin/users/{id}/verify-email',        [AdminUserController::class, 'verifyEmail'], $admin);
$r->post('/admin/users/{id}/resend-verification', [AdminUserController::class, 'resendVerificationEmail'], $admin);

// ── KYC ────────────────────────────────────────────────────────────────────
$r->get('/admin/kyc',                       [AdminKYCController::class, 'index'],          $admin);
$r->get('/admin/kyc/review/{id}',           [AdminKYCController::class, 'review'],         $admin);
$r->post('/admin/kyc/verify/{id}',          [AdminKYCController::class, 'verify'],         $admin);
$r->post('/admin/kyc/reject/{id}',          [AdminKYCController::class, 'reject'],         $admin);
$r->post('/admin/kyc/mark-reviewing/{id}',  [AdminKYCController::class, 'markAsReviewing'],$admin);
$r->post('/admin/kyc/delete-image/{id}',    [AdminKYCController::class, 'deleteImage'],    $admin);

// لاگ‌ها
$r->get('/admin/logs',             [AdminLogController::class, 'index'],         $admin);
$r->get('/admin/logs/audit',        [AdminLogController::class, 'audit'],         $admin);
$r->get('/admin/logs/security',     [AdminLogController::class, 'security'],      $admin);
$r->get('/admin/logs/system',       [AdminLogController::class, 'system'],        $admin);
$r->post('/admin/logs/cleanup',    [AdminLogController::class, 'cleanup'],       $admin);

// سیستم لاگ پیشرفته
$r->get('/admin/logs/dashboard',             [AdminLogController::class, 'dashboard'],           $admin);
$r->get('/admin/logs/errors',                [AdminLogController::class, 'errors'],              $admin);
$r->get('/admin/logs/error-details',         [AdminLogController::class, 'errorDetails'],        $admin);
$r->post('/admin/logs/resolve-error',        [AdminLogController::class, 'resolveError'],         $admin);
$r->get('/admin/logs/notification-settings', [AdminLogController::class, 'notificationSettings'], $admin);
$r->post('/admin/logs/save-channel',         [AdminLogController::class, 'saveChannel'],         $admin);
$r->post('/admin/logs/test-channel',         [AdminLogController::class, 'testChannel'],         $admin);
// FIX-X89: toggle قواعد هشدار لاگ — JS این endpoint را صدا می‌زد ولی روت نداشت (الگوی FIX-DEAD/X74)
$r->post('/admin/logs/toggle-rule',          [AdminLogController::class, 'toggleRule'],          $admin);
$r->get('/admin/logs/api-stats',             [AdminLogController::class, 'apiStats'],            $admin);

// FEAT-R11: صندوق ایمیل محیطی (MAIL_DRIVER=log → mail.log) — فقط-خواندنی
$r->get('/admin/logs/mailbox',               [AdminLogController::class, 'mailbox'],             $admin);
$r->get('/admin/logs/mailbox/{idx}',         [AdminLogController::class, 'mailboxShow'],         $admin);

// ── اعلان‌ها ────────────────────────────────────────────────────────────────
$r->get('/admin/notifications',                  [AdminNotificationController::class, 'index'],             $admin);
$r->get('/admin/notifications/unread-count',     [AdminNotificationController::class, 'unreadCount'],       $admin);
$r->get('/admin/notifications/fetch',            [AdminNotificationController::class, 'fetch'],             $admin);
$r->get('/admin/notifications/send',             [AdminNotificationController::class, 'showSend'],          $admin);
$r->post('/admin/notifications/send',            [AdminNotificationController::class, 'send'],              $admin);
$r->get('/admin/notifications/stats',            [AdminNotificationController::class, 'stats'],             $admin);
$r->get('/admin/notifications/stats/fetch',      [AdminNotificationController::class, 'statsFetch'],        $admin);
$r->get('/admin/notifications/templates',        [AdminNotificationController::class, 'templates'],         $admin);
$r->post('/admin/notifications/templates/save',  [AdminNotificationController::class, 'saveTemplate'],      $admin);
$r->post('/admin/notifications/templates/delete',[AdminNotificationController::class, 'deleteTemplate'],    $admin);
$r->post('/admin/notifications/mark-read/{id}',  [AdminNotificationController::class, 'markAsRead'],        $admin);
$r->post('/admin/notifications/mark-all-read',   [AdminNotificationController::class, 'markAllAsRead'],     $admin);

// ── کارت‌های بانکی ──────────────────────────────────────────────────────────
$r->get('/admin/bank-cards',         [AdminBankCardController::class, 'index'], $admin);
$r->get('/admin/bank-cards/review',  [AdminBankCardController::class, 'review'], $admin);
$r->post('/admin/bank-cards/verify', [AdminBankCardController::class, 'verify'], $admin);
$r->post('/admin/bank-cards/reject', [AdminBankCardController::class, 'reject'], $admin);

// ── واریز دستی ─────────────────────────────────────────────────────────────
$r->get('/admin/manual-deposits',         [AdminManualDepositController::class, 'index'], $admin);
$r->get('/admin/manual-deposits/review',  [AdminManualDepositController::class, 'review'], $admin);
$r->post('/admin/manual-deposits/verify', [AdminManualDepositController::class, 'verify'], $admin);
$r->post('/admin/manual-deposits/reject', [AdminManualDepositController::class, 'reject'], $admin);

// ── واریز کریپتو ───────────────────────────────────────────────────────────
$r->get('/admin/crypto-deposits',         [AdminCryptoDepositController::class, 'index'], $admin);
$r->get('/admin/crypto-deposits/review',  [AdminCryptoDepositController::class, 'review'], $admin);
$r->post('/admin/crypto-deposits/preflight', [AdminCryptoDepositController::class, 'preflight'], $admin);
$r->post('/admin/crypto-deposits/verify', [AdminCryptoDepositController::class, 'verify'], $admin);
$r->post('/admin/crypto-deposits/reject', [AdminCryptoDepositController::class, 'reject'], $admin);

// ── برداشت‌ها ────────────────────────────────────────────────────────────────
$r->get('/admin/withdrawals',         [AdminWithdrawalController::class, 'index'], $admin);
$r->get('/admin/withdrawals/review',  [AdminWithdrawalController::class, 'review'], $admin);
$r->post('/admin/withdrawals/process',[AdminWithdrawalController::class, 'process'], $admin);
$r->post('/admin/withdrawals/reject', [AdminWithdrawalController::class, 'reject'], $admin);

// ── تراکنش‌ها ────────────────────────────────────────────────────────────────
$r->get('/admin/transactions',       [AdminTransactionController::class, 'index'], $admin);
$r->get('/admin/transactions/show',  [AdminTransactionController::class, 'show'], $admin);
$r->post('/admin/transactions/reverse', [AdminTransactionController::class, 'reverse'], $admin);

// ── بررسی پرداخت‌های آنلاین معلق ─────────────────────────────────────────────
$r->get('/admin/gateway-payments',         [AdminOnlinePaymentController::class, 'index'], $admin);
$r->post('/admin/gateway-payments/verify', [AdminOnlinePaymentController::class, 'verify'], $admin);

// ── حساب‌های اجتماعی ────────────────────────────────────────────────────────
$r->get('/admin/social-accounts',               [AdminSocialAccountController::class, 'index'],  $admin);
$r->get('/admin/social-accounts/{id}',          [AdminSocialAccountController::class, 'show'],   $admin);
$r->post('/admin/social-accounts/{id}/verify',  [AdminSocialAccountController::class, 'verify'], $admin);
$r->post('/admin/social-accounts/{id}/reject',  [AdminSocialAccountController::class, 'reject'], $admin);

// ─────────────────────────────────────────────────
// Admin Routes (routes/admin.php)
// ─────────────────────────────────────────────────

// لیست همه وظایف
$r->get('/admin/custom-tasks', [AdminAdTaskController::class, 'index'], $admin);
$r->get('/admin/custom-tasks/reports', [AdminExecutorTaskController::class, 'reports'], $admin);
// FIX-X85b: بررسی گزارش تخلف (متد تا راند ۲۴ بدون route بود — الگوی FIX-DEAD)
$r->post('/admin/custom-tasks/task-reports/review', [AdminExecutorTaskController::class, 'reviewReport'], $admin);

// اختلافات تسک‌های سفارشی
$r->get('/admin/custom-tasks/disputes', [AdminExecutorTaskController::class, 'disputes'], $admin);
$r->get('/admin/custom-tasks/disputes/{id}', [AdminExecutorTaskController::class, 'disputeDetail'], $admin);
$r->post('/admin/custom-tasks/disputes/{id}/reply', [AdminExecutorTaskController::class, 'replyDispute'], $admin);

// FIX-36/F-A3-02 (راند R36-W2-D): مسیر استاتیک stats باید «قبل از» وایلدکارت
// {id} ثبت شود (همان قرارداد /admin/ads/stats در L70).
// راستی‌آزمایی W2-D1 با php -r probe: با استنتاج نوع CORE-062، {id} فقط عددی است
// ([0-9]+) و «stats» را تطبیق نمی‌دهد؛ ترتیب static-before-wildcard برای مقاومت
// در برابر تغییر آیندهٔ نام/نوع پارامتر (مثلاً {slug}) حفظ می‌شود.
$r->get('/admin/custom-tasks/stats', [AdminAdTaskController::class, 'stats'], $admin);

// 🛡️ FIX-N22-02 (بازبینی ۲۲): صفحهٔ دید ادمین بر ردیف‌های پارک‌شدهٔ sweep تأیید
// خودکار — استاتیک، پس مثل stats (F-A3-02) «قبل از» وایلدکارت {id} ثبت می‌شود.
$r->get('/admin/custom-tasks/parked', [AdminExecutorTaskController::class, 'parkedSubmissions'], $admin);

// جزئیات وظیفه
$r->get('/admin/custom-tasks/{id}', [AdminAdTaskController::class, 'show'], $admin);

// تایید/رد وظیفه (Ajax)
$r->post('/admin/custom-tasks/approve', [AdminAdTaskController::class, 'approve'], $admin);

// تایید/رد اجباری submission (Ajax)
$r->post('/admin/custom-tasks/submissions/force-approve', [AdminExecutorTaskController::class, 'forceApproveSubmission'], $admin);
$r->post('/admin/custom-tasks/submissions/force-reject', [AdminExecutorTaskController::class, 'forceRejectSubmission'], $admin);
// 🛡️ FIX-N22-02 (بازبینی ۲۲ — راه بازگشت): بازگردانی ردیف پارک‌شدهٔ sweep به صف
$r->post('/admin/custom-tasks/submissions/reset-attempts', [AdminExecutorTaskController::class, 'resetParkedSubmission'], $admin);

// آمار و گزارش (Ajax)
// FIX-36/F-A3-02: مسیر stats قبلاً همین‌جا (بعد از وایلدکارت {id}) بود و به بالای
// آن منتقل شد — برای حفظ قرارداد static-before-wildcard (ثبت جدید در L208).
$r->post('/admin/custom-tasks/disputes/resolve',  [AdminExecutorTaskController::class, 'resolveDispute'], $admin);

// ── مدیریت اختلافات و نظارت بر تسک‌ها ─────────────────────────────────────────
// حذف ۹ مسیر مرده (task-disputes / task-executions / task-rechecks):
// این مسیرها به App\Controllers\ExecutorTaskController ارجاع می‌دادند که هرگز
// وجود نداشته است (فقط Admin\ExecutorTaskController وجود دارد). نسخه‌های
// canonical همین عملکردها بالاتر با AdminExecutorTaskController تحت
// /admin/custom-tasks/... ثبت شده‌اند و ویوهای قدیمی مرتبط
// (views/admin/task-{disputes,executions,rechecks}/) نیز به‌عنوان ویو یتیم حذف شدند.

// ── نقش‌ها ──────────────────────────────────────────────────────────────────
$r->get('/admin/roles',              [AdminRoleController::class, 'index'], $admin);
$r->get('/admin/roles/create',       [AdminRoleController::class, 'create'], $admin);
$r->post('/admin/roles/store',       [AdminRoleController::class, 'store'], $admin);
$r->get('/admin/roles/{id}/edit',    [AdminRoleController::class, 'edit'], $admin);
$r->post('/admin/roles/{id}/update', [AdminRoleController::class, 'update'], $admin);
$r->post('/admin/roles/{id}/delete', [AdminRoleController::class, 'delete'], $admin);
$r->post('/admin/roles/{id}/toggle', [AdminRoleController::class, 'toggle'], $admin);

// ── Referral ─────────────────────────────────────────────────────────────────
$r->get('/admin/referral',                    [AdminReferralController::class, 'index'], $admin);
$r->get('/admin/referral/settings',           [AdminReferralController::class, 'settings'], $admin);
$r->post('/admin/referral/settings/save',     [AdminReferralController::class, 'saveSettings'], $admin);
$r->get('/admin/referral/user/{id}',          [AdminReferralController::class, 'userDetail'], $admin);
$r->post('/admin/referral/{id}/cancel',       [AdminReferralController::class, 'cancel'], $admin);
$r->post('/admin/referral/batch-pay',         [AdminReferralController::class, 'batchPay'], $admin);

// ── سطوح ────────────────────────────────────────────────────────────────────
$r->get('/admin/levels',                          [AdminLevelController::class, 'index'], $admin);
$r->get('/admin/levels/history',                  [AdminLevelController::class, 'history'], $admin);
$r->get('/admin/levels/create',                   [AdminLevelController::class, 'create'], $admin);
$r->post('/admin/levels/create',                  [AdminLevelController::class, 'store'], $admin);
$r->get('/admin/levels/{id}/edit',                [AdminLevelController::class, 'edit'], $admin);
$r->post('/admin/levels/{id}/update',             [AdminLevelController::class, 'update'], $admin);
$r->post('/admin/levels/{id}/delete',             [AdminLevelController::class, 'destroy'], $admin);
$r->post('/admin/levels/change-user-level',       [AdminLevelController::class, 'changeUserLevel'], $admin);

// ── اینفلوئنسر — ماژول مستقل Marketplace / ADMIN_ONLY ─────────────────────
$r->get('/admin/influencer/orders',                   [AdminInfluencerController::class, 'orders'], $admin);   // PRIMARY / ADMIN_ONLY
$r->get('/admin/influencer/profiles',                 [AdminInfluencerController::class, 'profiles'], $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/influencer/profiles/approve',        [AdminInfluencerController::class, 'approveProfile'], $admin); // PRIMARY_ACTION / ADMIN_ONLY
$r->get('/admin/influencer/verifications',            [AdminInfluencerController::class, 'verificationRequests'], $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/influencer/verifications/approve',   [AdminInfluencerController::class, 'approveVerification'], $admin); // PRIMARY_ACTION / ADMIN_ONLY
$r->post('/admin/influencer/verifications/reject',    [AdminInfluencerController::class, 'rejectVerification'], $admin); // PRIMARY_ACTION / ADMIN_ONLY
$r->get('/admin/influencer/disputes',                 [AdminInfluencerController::class, 'disputes'], $admin); // PRIMARY / ADMIN_ONLY
$r->get('/admin/influencer/disputes/{id}',            [AdminInfluencerController::class, 'disputeDetail'], $admin); // PRIMARY_DETAIL / ADMIN_ONLY
$r->post('/admin/influencer/disputes/{id}/resolve',   [AdminInfluencerController::class, 'resolveDispute'], $admin); // PRIMARY_ACTION / ADMIN_ESCROW_RESOLUTION
$r->post('/admin/influencer/orders/{id}/action',      [AdminInfluencerController::class, 'orderAction'], $admin); // PRIMARY_ACTION / ADMIN_ESCROW_RESOLUTION (T25-01: refund/force-complete)

// ── محتوا ────────────────────────────────────────────────────────────────────
$r->get('/admin/content',                           [AdminContentController::class, 'index'],        $admin); // PRIMARY / ADMIN_ONLY
$r->get('/admin/content/revenues',                  [AdminContentController::class, 'revenues'],     $admin); // PRIMARY / ADMIN_ONLY
$r->get('/admin/content/export',                    [AdminContentController::class, 'export'],       $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/bulk-approve',             [AdminContentController::class, 'bulkApprove'],  $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/bulk-reject',              [AdminContentController::class, 'bulkReject'],   $admin); // PRIMARY / ADMIN_ONLY
$r->get('/admin/content/{id}',                      [AdminContentController::class, 'show'],         $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/{id}/approve',             [AdminContentController::class, 'approve'],      $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/{id}/reject',              [AdminContentController::class, 'reject'],       $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/{id}/publish',             [AdminContentController::class, 'publish'],      $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/{id}/suspend',             [AdminContentController::class, 'suspend'],      $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/{id}/unsuspend',           [AdminContentController::class, 'unsuspend'],    $admin); // 🛡️ FIX-MOD24-06: رفع تعلیق (متقارن suspend)
$r->get('/admin/content/{id}/revenue/create',       [AdminContentController::class, 'createRevenue'],$admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/{id}/revenue/store',       [AdminContentController::class, 'storeRevenue'], $admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/revenue/{rid}/approve',    [AdminContentController::class, 'revenueApprove'],$admin); // PRIMARY / ADMIN_ONLY
$r->post('/admin/content/revenue/{rid}/pay',        [AdminContentController::class, 'revenuePay'],   $admin); // PRIMARY / ADMIN_ONLY

// ── سرمایه‌گذاری ─────────────────────────────────────────────────────────────
$r->get('/admin/investment',                              [AdminInvestmentController::class, 'index'],         $admin);
$r->get('/admin/investment/solvency-report',              [AdminInvestmentController::class, 'solvencyReport'], $admin);
$r->get('/admin/investment/trades',                       [AdminInvestmentController::class, 'trades'],        $admin);
$r->get('/admin/investment/trades/create',                [AdminInvestmentController::class, 'tradeCreate'],   $admin);
$r->post('/admin/investment/trades/store',                [AdminInvestmentController::class, 'tradeStore'],    $admin);
$r->post('/admin/investment/trades/{id}/close',           [AdminInvestmentController::class, 'tradeClose'],    $admin);
$r->get('/admin/investment/apply-profit',                 [AdminInvestmentController::class, 'applyProfitForm'],$admin);
$r->post('/admin/investment/apply-profit',                [AdminInvestmentController::class, 'applyProfit'],   $admin);
$r->get('/admin/investment/withdrawals',                  [AdminInvestmentController::class, 'withdrawals'],   $admin);
$r->post('/admin/investment/withdrawals/{id}/approve',    [AdminInvestmentController::class, 'withdrawalApprove'],$admin);
$r->post('/admin/investment/withdrawals/{id}/reject',     [AdminInvestmentController::class, 'withdrawalReject'], $admin);
$r->get('/admin/investment/{id}',                         [AdminInvestmentController::class, 'show'],          $admin);
$r->post('/admin/investment/{id}/suspend',                [AdminInvestmentController::class, 'suspend'],       $admin);

// ── قرعه‌کشی ─────────────────────────────────────────────────────────────────
$r->get('/admin/lottery',                          [AdminLotteryController::class, 'index'],         $admin);
$r->get('/admin/lottery/create',                   [AdminLotteryController::class, 'create'],        $admin);
$r->post('/admin/lottery/store',                   [AdminLotteryController::class, 'store'],         $admin);
$r->get('/admin/lottery/{id}',                     [AdminLotteryController::class, 'show'],          $admin);
$r->post('/admin/lottery/{id}/generate-numbers',   [AdminLotteryController::class, 'generateNumbers'],$admin);
$r->post('/admin/lottery/daily/{did}/finalize',    [AdminLotteryController::class, 'finalizeDaily'], $admin);
$r->post('/admin/lottery/{id}/select-winner',      [AdminLotteryController::class, 'selectWinner'],  $admin);
$r->post('/admin/lottery/{id}/cancel',             [AdminLotteryController::class, 'cancel'],        $admin);

// ── بنرها ────────────────────────────────────────────────────────────────────
$r->get('/admin/banners',                          [AdminBannerController::class, 'index'],           $admin);
$r->get('/admin/banners/placements',               [AdminBannerController::class, 'placements'],      $admin);
$r->post('/admin/banners/placements/toggle',       [AdminBannerController::class, 'togglePlacement'], $admin); // COMPATIBILITY_REDIRECT old form action
$r->post('/admin/banners/placements/{id}/update',  [AdminBannerController::class, 'updatePlacement'], $admin);
$r->post('/admin/banners/placements/{id}/toggle',  [AdminBannerController::class, 'togglePlacement'], $admin);
$r->get('/admin/banners/create',                   [AdminBannerController::class, 'showCreate'],      $admin);
$r->get('/admin/banners/edit',                     [AdminBannerController::class, 'showEdit'],        $admin); // COMPATIBILITY_REDIRECT old query-string URL
$r->get('/admin/banners/stats',                    [AdminBannerController::class, 'stats'],           $admin); // COMPATIBILITY_REDIRECT old stats URL
$r->post('/admin/banners/store',                   [AdminBannerController::class, 'store'],           $admin);
$r->post('/admin/banners/update',                  [AdminBannerController::class, 'update'],          $admin); // COMPATIBILITY_REDIRECT old form action
$r->post('/admin/banners/approve',                 [AdminBannerController::class, 'approve'],         $admin); // COMPATIBILITY_REDIRECT old form action
$r->post('/admin/banners/reject',                  [AdminBannerController::class, 'reject'],          $admin); // COMPATIBILITY_REDIRECT old JS action
$r->post('/admin/banners/delete',                  [AdminBannerController::class, 'delete'],          $admin); // COMPATIBILITY_REDIRECT old form action
$r->get('/admin/banners/{id}/edit',                [AdminBannerController::class, 'showEdit'],        $admin);
$r->get('/admin/banners/{id}/stats',               [AdminBannerController::class, 'stats'],           $admin);
$r->post('/admin/banners/{id}/update',             [AdminBannerController::class, 'update'],          $admin);
$r->post('/admin/banners/{id}/approve',            [AdminBannerController::class, 'approve'],         $admin);
$r->post('/admin/banners/{id}/reject',             [AdminBannerController::class, 'reject'],          $admin);
$r->post('/admin/banners/{id}/delete',             [AdminBannerController::class, 'delete'],          $admin);
$r->post('/admin/banners/{id}/toggle',             [AdminBannerController::class, 'toggle'],          $admin);

// ── SEO و کلیک ───────────────────────────────────────────────────────────
$r->get('/admin/seo-ad',                       [AdminSeoAdController::class, 'index'],   $admin);
$r->post('/admin/seo-ad/{id}/approve',         [AdminSeoAdController::class, 'approve'], $admin);
$r->post('/admin/seo-ad/{id}/reject',          [AdminSeoAdController::class, 'reject'],    $admin);
$r->post('/admin/seo-ad/{id}/pause',           [AdminSeoAdController::class, 'pause'],     $admin);

// ── گزارش باگ ────────────────────────────────────────────────────────────────
$r->get('/admin/bug-reports',                  [AdminBugReportController::class, 'index'],           $admin);
$r->get('/admin/bug-reports/{id}',             [AdminBugReportController::class, 'show'],            $admin);
$r->post('/admin/bug-reports/{id}/status',     [AdminBugReportController::class, 'updateStatus'],    $admin);
$r->post('/admin/bug-reports/{id}/priority',   [AdminBugReportController::class, 'updatePriority'],  $admin);
$r->post('/admin/bug-reports/{id}/comment',    [AdminBugReportController::class, 'addComment'],      $admin);
$r->post('/admin/bug-reports/{id}/suspicious', [AdminBugReportController::class, 'toggleSuspicious'],$admin);
$r->post('/admin/bug-reports/{id}/delete',     [AdminBugReportController::class, 'delete'],          $admin);

// ── KPI ──────────────────────────────────────────────────────────────────────
$r->get('/admin/kpi',                       [KpiController::class, 'index'],               $admin);
$r->get('/admin/kpi/financial',             [KpiController::class, 'financial'],            $admin);
$r->get('/admin/kpi/users',                 [KpiController::class, 'users'],               $admin);
$r->get('/admin/kpi/chart-data',            [KpiController::class, 'chartData'],           $admin);
$r->get('/admin/kpi/export/users',          [KpiController::class, 'exportUsers'],         $admin);
$r->get('/admin/kpi/export/transactions',   [KpiController::class, 'exportTransactions'],  $admin);
$r->get('/admin/kpi/export/summary',        [KpiController::class, 'exportSummary'],       $admin);

// ── تنظیمات ──────────────────────────────────────────────────────────────────
$r->get('/admin/settings',               [SystemSettingController::class, 'index'], $admin);
$r->post('/admin/settings/{id}/update',  [SystemSettingController::class, 'update'], $admin);
$r->post('/admin/settings/upload-image', [SystemSettingController::class, 'uploadImage'], $admin);
$r->post('/admin/settings/remove-image', [SystemSettingController::class, 'removeImage'], $admin);

// ── صفحات استاتیک ─────────────────────────────────────────────────────────────
// Stale admin legacy page management routes removed: Admin\PageController does not exist.

// ── تیکت‌ها (ادمین فقط) ───────────────────────────────────────────────────────────────────
$r->get('/admin/tickets',                  [AdminTicketController::class, 'index'],        $admin);
$r->get('/admin/tickets/show/{id}',        [AdminTicketController::class, 'show'],         $admin);
// FIX-X85: دانلود امن پیوست از پنل ادمین (قاعدهٔ HIGH-01: انتساب یا tickets.view_all)
$r->get('/admin/tickets/attachments/{filename}', [AdminTicketController::class, 'downloadAttachment'], $admin);
$r->post('/admin/tickets/reply',           [AdminTicketController::class, 'reply'],        $admin);
$r->post('/admin/tickets/change-status',   [AdminTicketController::class, 'changeStatus'], $admin);
$r->post('/admin/tickets/assign',          [AdminTicketController::class, 'assign'],       $admin);

// ── کوپن ─────────────────────────────────────────────────────────────────────
$r->get('/admin/coupons',                  [AdminCouponController::class, 'index'],       $admin);
$r->get('/admin/coupons/create',           [AdminCouponController::class, 'create'],      $admin);
$r->get('/admin/coupons/redemptions',      [AdminCouponController::class, 'redemptions'], $admin);
$r->get('/admin/coupons/statistics',       [AdminCouponController::class, 'statistics'],  $admin);
$r->post('/admin/coupons/store',           [AdminCouponController::class, 'store'],       $admin);
$r->post('/admin/coupons/delete',          [AdminCouponController::class, 'delete'],      $admin);
$r->post('/admin/coupons/toggle-active',   [AdminCouponController::class, 'toggleActive'],$admin);
$r->get('/admin/coupons/{id}/edit',        [AdminCouponController::class, 'edit'],        $admin);
$r->post('/admin/coupons/{id}/update',     [AdminCouponController::class, 'update'],      $admin);
$r->get('/admin/coupons/{id}',             [AdminCouponController::class, 'details'],     $admin);

// ── تقلب ─────────────────────────────────────────────────────────────────────
$r->get('/admin/fraud/dashboard',          [FraudDashboardController::class,  'index'],         $admin);
$r->get('/admin/fraud/logs',               [FraudManagementController::class, 'fraudLogs'],     $admin);
$r->get('/admin/fraud/ip-blacklist',       [FraudManagementController::class, 'ipBlacklist'],   $admin);
$r->post('/admin/fraud/ip-block',          [FraudManagementController::class, 'blockIP'],       $admin);
$r->post('/admin/fraud/ip-unblock',        [FraudManagementController::class, 'unblockIP'],     $admin);
$r->get('/admin/fraud/device-blacklist',   [FraudManagementController::class, 'deviceBlacklist'],$admin);
$r->post('/admin/fraud/device-block',      [FraudManagementController::class, 'blockDevice'],   $admin);
$r->post('/admin/fraud/device-unblock',    [FraudManagementController::class, 'unblockDevice'], $admin);
$r->post('/admin/fraud/reset-score',       [FraudManagementController::class, 'resetFraudScore'],$admin);
// 🛡️ X372 (راند ۹۳): صف بررسی گزارش‌های تخلف کاربران — همان گروه $admin همسایه‌ها
// (Auth + Admin + CSRF + RateLimit + AdminPermissionGuard؛ نگاشت RBAC در
// config/admin_permissions.php تا پیش از این افزودن نشده بود → برای غیرسوپر fail-closed)
$r->get('/admin/fraud/reports',                 [FraudReportsAdminController::class, 'index'],   $admin);
$r->post('/admin/fraud/reports/{id}/review',    [FraudReportsAdminController::class, 'review'],  $admin);
$r->post('/admin/fraud/reports/{id}/dismiss',   [FraudReportsAdminController::class, 'dismiss'], $admin);

// ── Feature Flags ─────────────────────────────────────────────────────────────
$r->get('/admin/features',             [FeatureFlagController::class, 'index'],         $admin);
$r->post('/admin/features/toggle',     [FeatureFlagController::class, 'toggle'],        $admin);
$r->post('/admin/features/create',     [FeatureFlagController::class, 'create'],        $admin);
$r->post('/admin/features/update',     [FeatureFlagController::class, 'update'],        $admin);
$r->post('/admin/features/advanced-update', [FeatureFlagController::class, 'advancedUpdate'], $admin);
$r->post('/admin/features/delete',     [FeatureFlagController::class, 'delete'],        $admin);
$r->get('/admin/features/stats',       [FeatureFlagController::class, 'getStats'],      $admin);
$r->get('/admin/features/metrics/{name}', [FeatureFlagController::class, 'getMetrics'], $admin);
$r->get('/admin/features/history/{name}', [FeatureFlagController::class, 'getHistory'], $admin);

// ── Audit Trail ───────────────────────────────────────────────────────────────
$r->get('/admin/audit-trail',        [AuditTrailController::class, 'index'],  $admin);
$r->get('/admin/audit-trail/show/{id}',  [AuditTrailController::class, 'show'], $admin);
$r->get('/admin/audit-trail/stats',      [AuditTrailController::class, 'stats'], $admin);
$r->get('/admin/audit-trail/export',     [AuditTrailController::class, 'export'], $admin);
$r->get('/admin/audit-trail/user/{id}',  [AuditTrailController::class, 'userHistory'], $admin);

// ── Export ────────────────────────────────────────────────────────────────────
$r->get('/admin/export',              [AdminExportController::class, 'index'],        $admin);
$r->get('/admin/export/users',        [AdminExportController::class, 'users'],        $admin);
$r->get('/admin/export/transactions', [AdminExportController::class, 'transactions'], $admin);
$r->get('/admin/export/withdrawals',  [AdminExportController::class, 'withdrawals'],  $admin);
$r->get('/admin/export/audit-trail',  [AdminExportController::class, 'auditTrail'],   $admin);
// ── Account Deletion Management (Phase 5e) ─────────────────────────────────
$r->get('/admin/account-deletion/pending',      [AccountDeletionManagementController::class, 'pending'],      $admin);
$r->get('/admin/account-deletion/history',      [AccountDeletionManagementController::class, 'history'],      $admin);
$r->post('/admin/account-deletion/force-delete',[AccountDeletionManagementController::class, 'forceDelete'],  $admin);
$r->post('/admin/account-deletion/cancel',      [AccountDeletionManagementController::class, 'cancelDeletion'], $admin);
$r->get('/admin/account-deletion/user-details', [AccountDeletionManagementController::class, 'getUserDetails'], $admin);
// FIX-X36: /stats باید صفحهٔ ویو را رندر کند (متد stats)؛ JSON برای AJAX به /stats/fetch منتقل شد
$r->get('/admin/account-deletion/stats',        [AccountDeletionManagementController::class, 'stats'],       $admin);
$r->get('/admin/account-deletion/stats/fetch',  [AccountDeletionManagementController::class, 'getStats'],    $admin);

// ── Backup Management (Phase 5e) ───────────────────────────────────────────
$r->get('/admin/backups',                       [BackupManagementController::class, 'index'],           $admin);
$r->post('/admin/backups/create',               [BackupManagementController::class, 'createBackup'],   $admin);
$r->post('/admin/backups/{id}/restore',         [BackupManagementController::class, 'restoreBackup'],  $admin);
$r->post('/admin/backups/{id}/verify',          [BackupManagementController::class, 'verifyBackup'],   $admin);
$r->get('/admin/backups/stats',                 [BackupManagementController::class, 'stats'],          $admin);
// [FIX-R91-B] آپلود آف‌سایت: همگام‌سازی دستی + تست اتصال مقصد (همان گروه گارددار $admin)
$r->post('/admin/backups/offsite-sync',         [BackupManagementController::class, 'offsiteSync'],    $admin);
$r->post('/admin/backups/offsite-test',         [BackupManagementController::class, 'offsiteTest'],    $admin);
$r->post('/admin/backups/cleanup',              [BackupManagementController::class, 'cleanup'],        $admin);

// ── سلامت دیتابیس ──────────────────────────────────────────────
$r->get('/admin/database-health', [App\Controllers\Admin\DatabaseHealthController::class, 'index'], $admin);
// ── جستجو ─────────────────────────────────────────────────────────────────────
$r->get('/admin/search', [SearchController::class, 'adminSearch'], $admin);

// Risk policies
$r->get('/admin/risk-policies',              [RiskPolicyController::class, 'index'], $admin);
$r->post('/admin/risk-policies/update',      [RiskPolicyController::class, 'update'], $admin);

// User score management
$r->get('/admin/users/{id}/scores',                 [ScoreManagementController::class, 'showUserScores'], $admin);
$r->post('/admin/users/{id}/scores/adjust',         [ScoreManagementController::class, 'adjustScore'], $admin);
$r->post('/admin/scores/adjustments/{id}/revoke',   [ScoreManagementController::class, 'revokeAdjustment'], $admin);
$r->get('/admin/users/{id}/scores/history',         [ScoreManagementController::class, 'history'], $admin);

// ── مانیتورینگ سیستم (Sentry) ────────────────────────────────────────
$r->get('/admin/sentry',                              [SentryAdminController::class, 'index'],            $admin);
$r->get('/admin/sentry/issues',                       [SentryAdminController::class, 'issues'],           $admin);
$r->get('/admin/sentry/failed-jobs',                   [SentryAdminController::class, 'failedJobs'],       $admin);
$r->get('/admin/sentry/outbox-dlq',                    [SentryAdminController::class, 'outboxDLQ'],       $admin);
$r->get('/admin/sentry/event-failures',                 [SentryAdminController::class, 'eventFailures'],    $admin);
$r->get('/admin/sentry/failed-jobs/{id}',              [SentryAdminController::class, 'failedJobDetails'], $admin);
$r->get('/admin/sentry/issues/{id}',                  [SentryAdminController::class, 'issueDetails'],     $admin);
$r->get('/admin/sentry/performance',                  [SentryAdminController::class, 'performance'],      $admin);
$r->get('/admin/sentry/analytics',                    [SentryAdminController::class, 'analytics'],        $admin);
$r->get('/admin/sentry/alerts',                       [SentryAdminController::class, 'alerts'],           $admin);
$r->get('/admin/sentry/audit',                        [SentryAdminController::class, 'auditTrail'],       $admin);
$r->get('/admin/sentry/security',                     [SentryAdminController::class, 'security'],         $admin);

// Sentry API endpoints
$r->post('/admin/sentry/issues/{id}/resolve',         [SentryAdminController::class, 'resolveIssue'],     $admin);
$r->post('/admin/sentry/issues/{id}/mute',            [SentryAdminController::class, 'muteIssue'],        $admin);
$r->post('/admin/sentry/failed-jobs/{id}/retry',      [SentryAdminController::class, 'retryFailedJob'],   $admin);
$r->post('/admin/sentry/failed-jobs/{id}/forget',     [SentryAdminController::class, 'forgetFailedJob'],  $admin);
// 🛡️ FIX-OUTBOX-DLQ-MANAGEMENT + FIX-EVENT-FAILURES-VISIBILITY (ممیزی outbox ۲۰۲۶-۰۸-۲۸)
$r->post('/admin/sentry/outbox-dlq/{id}/retry',        [SentryAdminController::class, 'retryOutboxEvent'], $admin);
$r->post('/admin/sentry/outbox-dlq/{id}/delete',       [SentryAdminController::class, 'deleteOutboxEvent'], $admin);
$r->post('/admin/sentry/event-failures/{id}/delete',   [SentryAdminController::class, 'deleteEventFailure'], $admin);
$r->post('/admin/sentry/alerts/{id}/acknowledge',     [SentryAdminController::class, 'acknowledgeAlert'], $admin);
$r->get('/admin/sentry/api/chart-data',               [SentryAdminController::class, 'getChartData'],     $admin);
$r->get('/admin/sentry/api/health',                   [SentryAdminController::class, 'healthCheck'],      $admin);
$r->post('/admin/sentry/audit/export',                [SentryAdminController::class, 'exportAudit'],      $admin);
$r->post('/admin/sentry/audit/report',                [SentryAdminController::class, 'generateReport'],   $admin);

/*
|--------------------------------------------------------------------------
| Analytics — Dashboard & Reports
|--------------------------------------------------------------------------
*/
$r->get('/admin/analytics',                         [AdminAnalyticsController::class, 'dashboard'],        $admin);
$r->get('/admin/analytics/users',                   [AdminAnalyticsController::class, 'users'],            $admin);
$r->get('/admin/analytics/transactions',            [AdminAnalyticsController::class, 'transactions'],     $admin);
$r->get('/admin/analytics/social-tasks',            [AdminAnalyticsController::class, 'socialTasks'],      $admin);
$r->get('/admin/analytics/custom-tasks',            [AdminAnalyticsController::class, 'customTasks'],      $admin);
$r->get('/admin/analytics/ratings',                 [AdminAnalyticsController::class, 'ratings'],          $admin);
$r->get('/admin/analytics/revenue',                 [AdminAnalyticsController::class, 'revenue'],          $admin);
$r->get('/admin/analytics/system-health',           [AdminAnalyticsController::class, 'systemHealth'],     $admin);
$r->get('/admin/analytics/chart-data',              [AdminAnalyticsController::class, 'getChartData'],     $admin);
$r->post('/admin/analytics/export',                 [AdminAnalyticsController::class, 'exportReport'],     $admin);

/*
|--------------------------------------------------------------------------
| Social Tasks — Admin Panel
|--------------------------------------------------------------------------
*/
// آگهی‌ها
$r->get('/admin/social-tasks',                          [AdminSocialTaskController::class, 'index'],          $admin);
$r->get('/admin/social-tasks/stats',                    [AdminSocialTaskController::class, 'stats'],          $admin);
$r->get('/admin/social-tasks/{id}',                     [AdminSocialTaskController::class, 'show'],           $admin);
$r->post('/admin/social-tasks/{id}/approve',            [AdminSocialTaskController::class, 'approve'],        $admin);
$r->post('/admin/social-tasks/{id}/reject',             [AdminSocialTaskController::class, 'reject'],         $admin);
$r->post('/admin/social-tasks/{id}/pause',              [AdminSocialTaskController::class, 'pause'],          $admin);
$r->post('/admin/social-tasks/{id}/resume',             [AdminSocialTaskController::class, 'resume'],         $admin);
$r->post('/admin/social-tasks/{id}/cancel',             [AdminSocialTaskController::class, 'cancel'],         $admin);

// اجراها
$r->get('/admin/social-executions',                     [AdminSocialTaskController::class, 'executions'],     $admin);
$r->get('/admin/social-executions/{id}',                [AdminSocialTaskController::class, 'executionShow'],  $admin);
$r->post('/admin/social-executions/{id}/flag',          [AdminSocialTaskController::class, 'flagExecution'],  $admin);
$r->post('/admin/social-executions/{id}/override',      [AdminSocialTaskController::class, 'overrideDecision'],$admin);

// نظرات و امتیازات
$r->get('/admin/social-task-reviews',                   [AdminSocialTaskController::class, 'reviewRatings'],      $admin);
$r->get('/admin/social-task-reviews/{id}',              [AdminSocialTaskController::class, 'reviewRatingDetail'], $admin);
$r->post('/admin/social-task-reviews/{id}/moderate',    [AdminSocialTaskController::class, 'moderateRating'],     $admin);

// Trust
$r->get('/admin/social-trust',                          [AdminSocialTaskController::class, 'trustDashboard'], $admin);
$r->get('/admin/social-trust/user/{id}',                [AdminSocialTaskController::class, 'userTrust'],      $admin);
$r->post('/admin/social-trust/user/{id}/adjust',        [AdminSocialTaskController::class, 'adjustTrust'],    $admin);

// ── Fraud Detection ───────────────────────────────────────────────────────────
$r->get('/admin/fraud/risk-report',         [FraudController::class, 'getRiskReport'],     $admin);
$r->post('/admin/fraud/recalculate-score',  [FraudController::class, 'recalculateScore'],  $admin);
$r->post('/admin/fraud/execute-actions',    [FraudController::class, 'executeActions'],    $admin);
$r->get('/admin/fraud/high-risk-users',     [FraudController::class, 'getHighRiskUsers'],  $admin);
$r->post('/admin/fraud/clear-flags',        [FraudController::class, 'clearFlags'],        $admin);
$r->post('/admin/fraud/suspend-user',       [FraudController::class, 'suspendUser'],       $admin);
$r->post('/admin/fraud/unsuspend-user',     [FraudController::class, 'unsuspendUser'],     $admin);


// ── Message Moderation ────────────────────────────────────────────────────────
$r->get('/admin/messages/reports',              [MessageModerationController::class, 'reports'],       $admin);
$r->get('/admin/messages/reports/{id}',         [MessageModerationController::class, 'show'],          $admin);
$r->post('/admin/messages/reports/approve',     [MessageModerationController::class, 'approve'],       $admin);
$r->post('/admin/messages/reports/dismiss',     [MessageModerationController::class, 'dismiss'],       $admin);
$r->get('/admin/messages/blocked-users',        [MessageModerationController::class, 'blockedUsers'],  $admin);
$r->get('/admin/messages/stats',                [MessageModerationController::class, 'stats'],         $admin);

// End of Admin Routes
