<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Logging Configuration
    |--------------------------------------------------------------------------
    |
    | FIX-M4-12: فقط کلیدهایی که مصرف‌کنندهٔ واقعی دارند اینجا می‌مانند (wire-or-remove).
    | مصرف‌کننده‌ها:
    |   - log_to_file  → app/Services/LogService::log() (گیت sink استریم/error_log)
    |   - min_level    → app/Services/LogService::log() (فیلتر سطح)
    |   - performance.*→ LoggingMiddleware + DatabaseAnalyzerService + PerformanceOptimizationService
    | کلیدهای بی‌مصرف قبلی (log_dir, log_to_database, database_sample_rate,
    | async_logging, database_levels, retention_days, max_file_size, format,
    | throttle.*, enabled.*, auto_log.*) حذف شدند — هیچ‌کدام در core/Logger.php
    | یا LogService خوانده نمی‌شدند و تغییرشان behavior را عوض نمی‌کرد (dead config
    | گمراه‌کنندهٔ اپراتور). نگهداری/پاک‌سازی لاگ‌ها مسیرهای خودش را در
    | MaintenanceService (maintenance.*_retention_days) و AuditTrail دارد.
    */

    // گیت sink اصلی لاگ (استریم stdout در CLI / error_log در FPM). false = خروجی لاگ اپ خاموش.
    'log_to_file' => filter_var(env('LOG_TO_FILE', true), FILTER_VALIDATE_BOOLEAN),

    // حداقل سطح لاگ (debug|info|notice|warning|error|critical|alert|emergency)
    'min_level' => env('LOG_LEVEL', 'info'),

    // تنظیمات پایش عملکرد و کوئری‌های کند
    'performance' => [
        'log_performance' => filter_var(env('LOG_PERFORMANCE', true), FILTER_VALIDATE_BOOLEAN),
        'performance_threshold_ms' => (float)env('LOG_PERFORMANCE_THRESHOLD', 500),
        'slow_query_threshold' => (float)env('SLOW_QUERY_THRESHOLD', 1.0), // ثانیه
        'log_slow_queries' => (bool)env('LOG_SLOW_QUERIES', true),
    ],
];
