<?php

return [
    // FIX-9a-2 (Audit Task 9-a): QUEUE_DRIVER نامِ کانونیکال است. قبلاً فقط
    // QUEUE_DRIVER خوانده می‌شد در حالی که همهٔ استقرارهای production
    // (compose/supervisor/systemd/.env) متغیر QUEUE_CONNECTION=redis ست می‌کردند
    // ⇒ صف بی‌صدا روی درایور اشتباه (database) می‌افتاد.
    // اکنون: QUEUE_DRIVER کانونیکال؛ QUEUE_CONNECTION به‌صورت fallback منسوخ
    // (deprecation-style) پذیرفته می‌شود تا .envهای موجود بلافاصله نشکنند.
    'driver' => env('QUEUE_DRIVER') ?? env('QUEUE_CONNECTION', 'database'),
    // FIX-R18-M9: این مقدار فقط visibility «پایهٔ» هر جاب است؛ QueueWorker برای هر جاب
    // TTL مؤثر = max(این‌مقدار, timeoutSeconds*2, 300) اعمال می‌کند و برای جاب‌های
    // طولانی (timeoutSeconds > visibility) heartbeat دوره‌ای pcntl_alarm می‌سازد.
    'visibility_timeout' => (int)env('QUEUE_VISIBILITY_TIMEOUT', 90),

    // سقف تلاش‌های هر جاب قبل از رفتن به DLQ — فلگ --tries ورکرها این مقدار را override می‌کند
    'max_attempts' => (int)env('QUEUE_MAX_ATTEMPTS', 5),

    // FIX راند ۷۹ (X310): کلید سایه‌ای QueueWorker (default = عین کد)
    'memory_limit_mb' => (int)env('QUEUE_MEMORY_LIMIT_MB', 128),

    'allowed_jobs' => [
        \App\Jobs\RunCronTaskJob::class,
        \App\Jobs\ProcessNotificationJob::class,
        \App\Jobs\ApplyWeeklyProfitLossJob::class,
        \App\Jobs\LogPerformanceJob::class,
        \App\Jobs\PersistBulkInAppNotificationJob::class,
        \App\Jobs\SendEmailJob::class,
        \App\Jobs\UpdateFraudScoreJob::class,
        \App\Jobs\InvestmentProfitDistributionJob::class,
        \App\Jobs\NotificationCleanupJob::class,
        \App\Jobs\EscrowTimeoutJob::class,
        \App\Jobs\CacheWarmupJob::class,
        // FIX-DEAD-JOB (راند ۹۱): ScoreRecalculationJob پران شد — بدون تولیدکننده/کرون؛
        // «اصلاح» drift با applyDelta(diff) خودِ لجر را هم جابه‌جا می‌کرد و هر اجرا
        // دوباره فعال می‌شد. جانشین: scores:rebuild (بازسازی از لجر).
        \App\Jobs\PredictionGameSettlementJob::class,
        \App\Jobs\VitrineListingExpiryJob::class,
        \App\Jobs\InfluencerOrderTimeoutJob::class,
        \App\Jobs\SocialTaskApprovalReminderJob::class,
        \App\Jobs\AggregateAnalyticsJob::class,
        \App\Jobs\KycTimeoutJob::class,
        \App\Jobs\WithdrawalTimeoutJob::class,
        \App\Jobs\BackfillSearchProjectionJob::class,
        \App\Jobs\CustomTask\CronSubmissionsJob::class,
        // FIX-9a-9 (Audit Task 9-a): PayRewardJob و ProcessPaymentCallbackJob از
        // allowlist حذف شدند — قرارداد handle آن‌ها چندآرگومانی/شی‌گراست
        // (PayRewardJob::handle(\stdClass)، ProcessPaymentCallbackJob::handle(string, array, ...))
        // و با handle($data) ورکر سازگار نیست ⇒ هر enqueue فرضی = TypeError →
        // DLQ noise. هیچ تولیدکنندهٔ صفی هم ندارند (تنها فراخوانِ هر دو، فراخوانی
        // همگام in-process است: CustomTaskModerationService::payWorkerReward و
        // ReconcilePaymentsJob) — همان توصیهٔ مستند در docblock خودِ کلاس‌ها
        // (FIX-R36-W3). خودِ کلاس‌ها حذف نشدند تا مسیر همگام موجود نشکند.
        \App\Jobs\CustomTask\SubmitProofJob::class,
        \App\Jobs\CustomTask\RateSubmissionJob::class,
        \App\Jobs\Seo\ProcessSeoTaskAsyncJob::class,
        \App\Jobs\SocialTask\ApproveSocialTaskExecutionJob::class,
        \App\Jobs\SocialTask\RejectSocialTaskExecutionJob::class,
        \App\Jobs\Vitrine\ProcessExpiredVitrineEscrowsJob::class,
        \App\Jobs\Auth\ProcessRegistrationJob::class,
        \App\Jobs\Auth\ResetPasswordJob::class,
    ],
];
