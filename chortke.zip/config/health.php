<?php

/**
 * Health Check Configuration
 *
 * تنظیمات نقطه پایان بررسی سلامت سیستم
 */

return [

    // IP های مجاز برای دریافت وضعیت سلامت
    'allowed_ips' => array_filter(array_map('trim', explode(',', env('HEALTH_ALLOWED_IPS', '127.0.0.1,::1')))),

    // توکن امنیتی جایگزین برای احراز هویت ابزارهای مانیتورینگ خارجی
    'check_token' => env('HEALTH_CHECK_TOKEN', ''),

    // FIX راند ۷۹ (X310): کلیدهای سایه‌ای HealthCheckController (default = عین کد)
    'ready_cache_ttl' => env('HEALTH_READY_CACHE_TTL', 5),
    'degraded_is_ready' => env('HEALTH_DEGRADED_IS_READY', false),
    
    // زمان توقف (Timeout)
    'timeout' => (int)env('HEALTH_CHECK_TIMEOUT', 5),
    
    // بررسی وابستگی‌ها
    // FIX-M4-05: پرچم enabled هر وابستگی اکنون در HealthCheckService::checkReadiness
    // واقعاً مصرف می‌شود (وابستگی غیرفعال probe نمی‌شود و 'disabled' گزارش می‌شود).
    // کلید timeout فقط برای redis معنا دارد (اتصال جدید همان‌جا ساخته می‌شود) و
    // مصرف می‌شود؛ برای database/queue اتصال DI از قبل برقرار است و timeout
    // همگام‌سازی‌پذیر نیست — کلید بی‌اثر حذف شد (wire-or-remove).
    'dependencies' => [
        'database' => ['enabled' => true],
        'redis' => ['enabled' => true, 'timeout' => 1],
        'queue' => ['enabled' => false],
    ],
    
    // آستانه‌های مجاز مانیتورینگ
    'thresholds' => [
        'disk_usage' => (int)env('HEALTH_DISK_THRESHOLD', 90),
        'memory_usage' => (int)env('HEALTH_MEMORY_THRESHOLD', 85),
        'cpu_load' => (int)env('HEALTH_CPU_THRESHOLD', 80),
    ],
    
    // تنظیمات ارسال هشدار (Alerts)
    'alerts' => [
        'slack_webhook' => env('HEALTH_SLACK_WEBHOOK'),
        'email' => env('HEALTH_ALERT_EMAIL'),
    ],

];
