<?php
/**
 * Authentication configuration
 *
 * This file centralizes auth-specific settings used by password policy,
 * login risk, and account security features.
 */

return [
    'password' => [
        'min_length' => env('AUTH_PASSWORD_MIN_LENGTH', 12),
        'max_length' => env('AUTH_PASSWORD_MAX_LENGTH', 128),
        'require_uppercase' => env('AUTH_PASSWORD_REQUIRE_UPPERCASE', true),
        'require_lowercase' => env('AUTH_PASSWORD_REQUIRE_LOWERCASE', true),
        'require_numbers' => env('AUTH_PASSWORD_REQUIRE_NUMBERS', true),
        'require_special_chars' => env('AUTH_PASSWORD_REQUIRE_SPECIAL_CHARS', true),
        'prevent_common' => env('AUTH_PASSWORD_PREVENT_COMMON', true),
        'check_hibp' => env('AUTH_PASSWORD_CHECK_HIBP', true),
    ],

    'max_concurrent_sessions' => env('AUTH_MAX_CONCURRENT_SESSIONS', 5),
    // FIX-R36-W3 (F-A24a-05): secure_key() از defaultِ آرگومان حذف شد — PHP آرگومان
    // default را eager ارزیابی می‌کند و این یعنی بارگذاری config/auth.php به APP_KEY
    // وابسته می‌شد. مصرف‌کنندهٔ یکتا (app/Services/Auth/LoginRiskService.php:509)
    // خودش fallback امن دارد: config('auth.risk_cache_key', secure_key()) ⇒ وقتی
    // env تنظیم نشده باشد خروجی نهایی عین قبل (APP_KEY به‌عنوان salt HMAC) —
    // رفتار مو‌به‌مو حفظ شده، فقط ارزیابی load-time حذف شد.
    'risk_cache_key' => env('AUTH_RISK_CACHE_KEY'),

    // FIX راند ۷۹ (X310): کلید سایه‌ای PasswordRecoveryService/AuthController (default = عین کد: ۳۶۰۰ ثانیه)
    'password_reset_ttl' => env('AUTH_PASSWORD_RESET_TTL', 3600),
    // FIX-R36-W3 (F-A7-10): بلاکِ سختِ تغییر IP در وریفای 2FA سمت کاربر —
    // اختیاری (opt-in) هم‌ترازِ oauth.strict_ip_binding. پیش‌فرض false = رفتار
    // فعلی (تغییر ساب‌نت فقط +۱۰ امتیاز تقلب و لاگ، بدون بلاک). true = تغییر
    // ساب‌نت در پنجرهٔ pending-2FA نشست را نابود و وریفای را رد می‌کند (هم‌سطح ادمین).
    '2fa_user_strict_ip_binding' => (bool)env('AUTH_2FA_USER_STRICT_IP_BINDING', false),

];
