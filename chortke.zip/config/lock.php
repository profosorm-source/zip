<?php

/**
 * تنظیمات قفل توزیع‌شده (DistributedLockService)
 *
 * 🛡️ FIX-S34-LOCK-FAIL-CLOSED (2026-09-19 — تصمیم تأییدشدهٔ کاربر، S33-P1):
 * پیش از این در قطع Redis، فراخواننده‌هایی که failClosed صریح نمی‌دادند
 * (۹ مسیر شناسایی‌شده در پاس A/B زیربچ ۱ — از جمله IdempotencyService:143،
 * EscrowService:185، PlaceBetJob:73، CustomTaskExecutorService:87) به قفل
 * فایلِ fail-open سقوط می‌کردند که در استقرار چند-سروری «قفل قلابی» است
 * و در مسیرهای مالی ریسک دوبل-خرج دارد.
 * از این پس پیش‌فرض سراسری fail-closed است: در قطع Redis، بخش بحرانی
 * به‌جای ادامهٔ ناامن، RuntimeException می‌دهد (شکست آشکار + retry).
 * برای بازگشت به رفتار قدیمی (فقط استقرار تک‌سرور): LOCK_FAIL_CLOSED=false
 */

return [
    'fail_closed' => env('LOCK_FAIL_CLOSED', true),
];
