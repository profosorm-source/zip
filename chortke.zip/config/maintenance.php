<?php
/**
 * Maintenance Mode Configuration
 * 
 * تنظیمات حالت تعمیر
 */

return [
    // فعال/غیرفعال بودن حالت تعمیر
    'enabled' => env('MAINTENANCE_MODE', false),
    
    // IP های مجاز برای دسترسی در حالت تعمیر
    'allowed_ips' => array_filter(
        array_map('trim', explode(',', env('MAINTENANCE_ALLOWED_IPS', '127.0.0.1,::1')))
    ),
    
    // پیام نمایشی
    'message' => env('MAINTENANCE_MESSAGE', 'ما در حال بهبود سیستم هستیم. لطفاً کمی صبر کنید.'),
    
    // زمان تخمینی پایان (اختیاری)
    'retry_after' => env('MAINTENANCE_RETRY_AFTER', 3600), // ثانیه
    
    // نمایش زمان باقیمانده
    'show_timer' => env('MAINTENANCE_SHOW_TIMER', true),
    
    // اجازه دسترسی به ادمین‌ها
    'allow_admins' => true,
    
    // Fix #7: به‌جای wildcard '/api/*' (که ممکن است matcher support نکند)،
    // از prefix ثابت استفاده می‌شود.
    // Middleware باید با str_starts_with($path, $prefix) تطابق دهد.
    'except' => [
        '/login',
        '/api',      // هر مسیری که با /api شروع شود (prefix match در middleware)
        '/health',
        '/ping',
    ],

    // FIX راند ۷۹ (X310): کلیدهای سایه‌ای MaintenanceService (default = عین کد)
    'archive_batch_limit' => env('MAINTENANCE_ARCHIVE_BATCH_LIMIT', 5000),
    // Transaction archive has no application reader yet; keep destructive moves disabled.
    'transaction_archival_enabled' => false,
    'log_retention_days' => env('MAINTENANCE_LOG_RETENTION_DAYS', 90),
    'ops_retention_days' => env('MAINTENANCE_OPS_RETENTION_DAYS', 30),
    'audit_retention_days' => env('MAINTENANCE_AUDIT_RETENTION_DAYS', 180),
];
