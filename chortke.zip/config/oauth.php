<?php

/**
 * OAuth Configuration
 * 
 * Google و Facebook OAuth settings
 */

$appUrl = env('APP_URL', 'http://localhost');
$isProduction = (env('APP_ENV', 'production') === 'production');

if ($isProduction && ($appUrl === 'http://localhost' || empty($appUrl) || !filter_var($appUrl, FILTER_VALIDATE_URL))) {
    throw new \RuntimeException('Production environment detected but APP_URL is invalid or set to localhost in environment variables.');
}

// FIX-R36-W3 (F-A24a-06/3): خطایِ Google-credentials قبلاً «مشروط‌ناشده» بود —
// config(null) در bootstrap/app.php:94 هر فایل config را (از جمله همین فایل) لود
// می‌کند، پس یک استقرار production که OAuth نمی‌خواهد بدون GOOGLE_CLIENT_ID/SECRET
// اصلاً boot نمی‌کرد. اکنون فقط وقتی fail-fast می‌مانیم که Google «نیمه‌تنظیم» باشد
// (یکی از جفت credential موجود و دیگری خالی = تایپو/فراموشی واقعی)؛ عدم‌تنظیم کامل
// = استقرار بدون OAuth که مسیرهای OAuth آن در مصرف‌کنندهٔ runtime fail می‌شوند
// (اعتبارسنجی سطح مصرف‌کننده = OAuthController، دامنهٔ app/ — پیشنهاد cross-domain).
$googleConfigured = !empty(env('GOOGLE_CLIENT_ID')) || !empty(env('GOOGLE_CLIENT_SECRET'));
$googlePartial = $googleConfigured && (empty(env('GOOGLE_CLIENT_ID')) || empty(env('GOOGLE_CLIENT_SECRET')));

if ($isProduction && $googlePartial) {
    throw new \RuntimeException('Google OAuth credentials are partially configured in production: set both GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET, or remove both.');
}

return [
    // Default false: strict IP binding is only enabled in high-security contexts
    // and can be controlled by feature flag or environment.
    'strict_ip_binding' => (bool)env('OAUTH_STRICT_IP_BINDING', false),

    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID', ''),
        'client_secret' => env('GOOGLE_CLIENT_SECRET', ''),
        'redirect_uri' => rtrim($appUrl, '/') . '/auth/callback/google',
    ],

    'facebook' => [
        'app_id' => env('FACEBOOK_APP_ID', ''),
        'app_secret' => env('FACEBOOK_APP_SECRET', ''),
        'redirect_uri' => rtrim($appUrl, '/') . '/auth/callback/facebook',
    ],
];
