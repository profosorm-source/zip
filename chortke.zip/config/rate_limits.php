<?php
/**
 * Rate Limiting Configuration
 * 
 * تنظیمات محدودیت درخواست برای endpoint های مختلف
 * هر endpoint می‌تواند تنظیمات خاص خودش را داشته باشد
 * 
 * SECURITY NOTES:
 * - Admin operations have appropriate rate limits (not overly permissive)
 * - Critical endpoints use fail-closed rate limiting
 * - Rate limits are configured per-action for granular control
 */

return [
    /**
     * تنظیمات پیش‌فرض
     * اگر برای endpoint خاصی تنظیم نشده باشد، این مقادیر استفاده می‌شود
     */
    // FIX راند ۷۹ (X310): کلید سایه‌ای RateLimitPolicy (default = عین کد: لیست خالی)
    // FIX-R36-W3 (F-A24a-07): env('RATE_LIMIT_WHITELIST') قبلاً خام برمی‌گشت — وقتی
    // اپراتور در .env مقدار comma-separated می‌گذاشت، رشته می‌شد و مصرف‌کننده
    // (RateLimitPolicy::isWhitelisted با گارد is_array) بی‌صدا آن را نادیده می‌گرفت
    // ⇒ knob بی‌اثر. نرمال‌سازی به آرایه با همان الگوی WEBHOOK_ALLOWED_IPS
    // (config/webhook.php). رفتار وقتی env خالی است: [] (عین default قبلی).
    'whitelist' => array_values(array_filter(array_map('trim', explode(',', (string) env('RATE_LIMIT_WHITELIST', ''))))),

    'default' => [
        'max_attempts' => env('RATE_LIMIT_MAX_ATTEMPTS', 60),
        'decay_minutes' => env('RATE_LIMIT_DECAY_MINUTES', 1),
    ],

    /**
     * Authentication & Security Endpoints
     */
    'auth' => [
        'login' => [
            'max_attempts' => env('RATE_LIMIT_LOGIN_MAX', 5),
            'decay_minutes' => env('RATE_LIMIT_LOGIN_DECAY', 5),
            'message' => 'تعداد تلاش‌های ورود بیش از حد مجاز. لطفاً کمی صبر کنید.'
        ],
        // FIX-M11-R22-10: endpointهای ورودِ API (صدور/نوسازی توکن) سیاستِ اختصاصیِ
        // زنده گرفتند — قبلاً ورودی‌های مردهٔ '/api/auth' و '/api/token' با هدف
        // auth.login وجود داشتند ولی هیچ‌وقت match نمی‌شدند. هدفِ auth.login
        // (۵/۵دقیقه، تیونِ فرمِ وب) صدورِ توکن را برای کلاینت‌های پشت CGNAT
        // می‌بندد؛ ۶۰/دقیقه هم‌پوشانِ سقف‌های درونی سرویس (IP 10/min، شکستِ
        // شناسه ۵، کنترلر 8/10min) است و فقط flood خام را می‌بندد.
        'api_token' => [
            'max_attempts' => 60,
            'decay_minutes' => 1,
            'message' => 'تعداد درخواست‌های صدور/نوسازی توکن بیش از حد مجاز است.'
        ],
        'register' => [
            'max_attempts' => env('RATE_LIMIT_REGISTER_MAX', 3),
            'decay_minutes' => env('RATE_LIMIT_REGISTER_DECAY', 60),
        ],
        'forgot_password' => [
            'max_attempts' => 3,
            'decay_minutes' => 60,
        ],
        'reset_password' => [
            'max_attempts' => 3,
            'decay_minutes' => 60,
        ],
    ],

    /**
     * Financial Operations
     */
    'financial' => [
        'deposit' => [
            'max_attempts' => env('RATE_LIMIT_DEPOSIT_MAX', 10),
            'decay_minutes' => 60,
        ],
        'withdrawal' => [
            'max_attempts' => env('RATE_LIMIT_WITHDRAWAL_MAX', 5),
            'decay_minutes' => 60,
        ],
        // FIX-MODULE2-M3: انتقال هم‌تاب و صندوق امانات هم عملیات مالی مبتنی بر
        // پول‌اند — بدون endpoint اختصاصی، ورودی‌های route_map (که اکنون اضافه
        // شدند) به گروه تنظیمات می‌رسیدند ولی کلید پیدا نمی‌کرد.
        'transfer' => [
            'max_attempts' => env('RATE_LIMIT_TRANSFER_MAX', 10),
            'decay_minutes' => 60,
        ],
        'escrow' => [
            'max_attempts' => env('RATE_LIMIT_ESCROW_MAX', 10),
            'decay_minutes' => 60,
        ],
    ],

    /**
     * API Endpoints
     */
    'api' => [
        'general' => [
            'max_attempts' => env('RATE_LIMIT_API_MAX', 100),
            'decay_minutes' => 1,
        ],
        'authenticated' => [
            'max_attempts' => env('RATE_LIMIT_API_AUTH_MAX', 200),
            'decay_minutes' => 1,
        ],
        'fast_test' => [
            'max_attempts' => 10,
            'decay_minutes' => 1,
        ],
    ],

    /**
     * FIX-X343 (راند ۸۴) — Webhook S2S
     * وب‌هوک‌های سرور-به-سرور: شبکه‌های تبلیغاتی از IPهای محدود اما پُرتکرار
     * پاداش می‌فرستند؛ سقف پیش‌فرض عمومی (۵/دقیقه در سندباکس) برایشان کُشنده است.
     */
    'webhook' => [
        'video_reward' => [
            'max_attempts' => env('RATE_LIMIT_WEBHOOK_VIDEO_REWARD_MAX', 300),
            'decay_minutes' => 1,
        ],
    ],

    /**
     * Task & Execution
     * محدودیت‌های تسک‌ها
     */
    'task' => [
        'create' => [
            'max_attempts' => 10,
            'decay_minutes' => 60,
            'message' => 'تعداد ایجاد تسک بیش از حد. لطفاً 1 ساعت صبر کنید.'
        ],
        'execute' => [
            'max_attempts' => 50,
            'decay_minutes' => 60,
            'message' => 'تعداد اجرای تسک بیش از حد. لطفاً 1 ساعت صبر کنید.'
        ],
        'submit' => [
            'max_attempts' => 30,
            'decay_minutes' => 60,
        ],
        'dispute' => [
            'max_attempts' => 5,
            'decay_minutes' => 60,
        ],
    ],

    /**
     * Social & Communication
     * محدودیت‌های ارتباطی
     */
    'social' => [
        'comment' => [
            'max_attempts' => 20,
            'decay_minutes' => 60,
        ],
        'message' => [
            'max_attempts' => 30,
            'decay_minutes' => 60,
        ],
        'typing' => [
            'max_attempts' => 20,
            'decay_minutes' => 1,
            'message' => 'تعداد درخواست‌های تایپ بیش از حد مجاز است.',
        ],
        'ticket_create' => [
            'max_attempts' => 5,
            'decay_minutes' => 60,
            'message' => 'تعداد ایجاد تیکت بیش از حد. لطفاً 1 ساعت صبر کنید.'
        ],
        'ticket_reply' => [
            'max_attempts' => 20,
            'decay_minutes' => 60,
        ],
    ],

    /**
     * Admin Operations
     * محدودیت‌های ادمین (سخت‌گیرانه‌تر از کاربران عادی برای امنیت)
     * 
     * LOW-03 Fix: Reduced admin.general from 500 to 100 requests per minute
     * Previous value of 500 was dangerously high and could allow DoS attacks
     * A value of 100 is reasonable for admin operations while still
     * accommodating legitimate bulk operations.
     */
    'admin' => [
        'bugreport_reply' => [
            'max_attempts' => 100,
            'decay_minutes' => 60,
            'message' => 'تعداد پاسخ‌های شما به گزارش باگ غیرعادی است.',
        ],
        'ticket_reply' => [
            'max_attempts' => 100,
            'decay_minutes' => 60,
            'message' => 'تعداد پاسخ‌های شما به تیکت غیرعادی است.',
        ],
        'login' => [
            'max_attempts' => 3,
            'decay_minutes' => 10,
            'message' => 'تعداد تلاش‌های ورود ادمین بیش از حد. لطفاً 10 دقیقه صبر کنید.'
        ],
        // LOW-03 Fix: Reduced from 500 to 100 requests per minute
        // This prevents abuse while still allowing legitimate admin operations
        'general' => [
            'max_attempts' => 100,  // Reduced from 500 for security
            'decay_minutes' => 1,
            'message' => 'تعداد درخواست‌های ادمین بیش از حد مجاز است.'
        ],
        // Admin 2FA verification is stricter than user 2FA
        '2fa_verify' => [
            'max_attempts' => 3,
            'decay_minutes' => 10,
            'message' => 'تعداد تلاش‌های تایید 2FA ادمین بیش از حد. لطفاً 10 دقیقه صبر کنید.'
        ],
    ],

    /**
     * Content Creation
     * محدودیت‌های ایجاد محتوا
     */
    'content' => [
        'create' => [
            'max_attempts' => 10,
            'decay_minutes' => 60,
        ],
        'update' => [
            'max_attempts' => 20,
            'decay_minutes' => 60,
        ],
        'delete' => [
            'max_attempts' => 10,
            'decay_minutes' => 60,
        ],
    ],

    /**
     * Reports & Analytics
     * محدودیت‌های گزارش‌گیری
     */
    'reports' => [
        'generate' => [
            'max_attempts' => 5,
            'decay_minutes' => 60,
            'message' => 'تعداد درخواست گزارش بیش از حد. لطفاً 1 ساعت صبر کنید.'
        ],
        'export' => [
            'max_attempts' => 3,
            'decay_minutes' => 60,
        ],
    ],

    /**
     * KYC & Verification
     * محدودیت‌های احراز هویت
     */
    'kyc' => [
        'submit' => [
            'max_attempts' => 3,
            'decay_minutes' => 1440, // 24 ساعت
            'message' => 'تعداد ارسال مدارک احراز هویت بیش از حد. لطفاً 24 ساعت صبر کنید.'
        ],
        'update' => [
            'max_attempts' => 5,
            'decay_minutes' => 1440,
        ],
    ],

    /**
     * Investment Operations
     * محدودیت‌های سرمایه‌گذاری
     */
    'investment' => [
        'create' => [
            'max_attempts' => 10,
            'decay_minutes' => 60,
        ],
        'withdraw' => [
            'max_attempts' => 5,
            'decay_minutes' => 60,
        ],
    ],

    /**
     * Lottery & Games
     * محدودیت‌های قرعه‌کشی
     */
    'lottery' => [
        'participate' => [
            'max_attempts' => 20,
            'decay_minutes' => 60,
        ],
        'vote' => [
            'max_attempts' => 10,
            'decay_minutes' => 60,
        ],
    ],

    /**
     * Referral System
     * محدودیت‌های سیستم دعوت
     */
    'referral' => [
        'check_code' => [
            'max_attempts' => 30,
            'decay_minutes' => 60,
        ],
    ],

    /**
     * Two-Factor Authentication
     * محدودیت‌های 2FA
     */
    /**
     * Search endpoints — DB-heavy, must be stricter than default API.
     * Section 8.8 — moved here from SearchController hardcodes.
     */
    'score' => [
        'apply' => [
            'max_attempts' => 60,
            'decay_minutes' => 1,
            'message' => 'تعداد درخواست‌های امتیاز بیش از حد. لطفاً ۱ دقیقه صبر کنید.',
        ],
    ],

    'social_account' => [
        'add' => [
            'max_attempts' => 5,
            'decay_minutes' => 60,
            'message' => 'تعداد افزودن حساب اجتماعی بیش از حد. لطفاً ۱ ساعت صبر کنید.',
        ],
    ],

    // 🛡️ FIX-F21-01 (گزینهٔ C): سقف نرخ دریافت چالش دوربین — هر شروع فلو
    // «چالش → ضبط → verify» یک چالش می‌خواهد؛ سقف ساعتی جلوی سیلاب nonce
    // (و پمپاژ رکوردهای pending) را می‌گیرد. مسیر retry طبیعی (۲-۳ بار)
    // راحت زیر سقف می‌ماند.
    'camera_challenge' => [
        'challenge' => [
            'max_attempts' => 12,
            'decay_minutes' => 60,
            'message' => 'تعداد درخواست چالش دوربین بیش از حد. لطفاً ۱ ساعت صبر کنید.',
        ],
        // 🛡️ FIX-CAM-VERIFY-CAP (چرخهٔ اصلاحی 2026-10-28 — رفع یافتهٔ 17-RV):
        // سقف نرخ «تأیید» (گام ۳) — ۳۰/ساعت. هر verify یک nonce را مصرف
        // می‌کند و مسیر سنگین تحلیل (فریم + spot + در صورت لزوم GD) را اجرا
        // می‌کند؛ سقفِ چالشِ ۱۲/ساعت به‌تنهایی جلوی بارِ verify را نمی‌گرفت
        // (کلاینت می‌توانست چالش‌های اندک را با verifyهای متوالیِ بی‌فایده
        // سنگین کند). مسیر retry طبیعی (۲-۴ بار) راحت زیر سقف می‌ماند.
        'verify' => [
            'max_attempts' => 30,
            'decay_minutes' => 60,
            'message' => 'تعداد درخواست‌های تأیید دوربین بیش از حد. لطفاً ۱ ساعت صبر کنید.',
        ],
    ],

    // 🛡️ FIX-S15-4: سهمیهٔ اختصاصی اعتبارسنجی کوپن — شکل قبلی فقط سقف عمومی
    // ۶۰/دقیقهٔ گروه مسیر را داشت (کدکاوی کد تخفیف)؛ هم‌ترازِ سایر نقاط
    // حدس‌زنی (۳ تا ۱۰ در دقیقه). usage_limit و توکن سمت‌سرور همچنان لایهٔ دوم‌اند.
    'coupon' => [
        'validate' => [
            'max_attempts' => 10,
            'decay_minutes' => 1,
            'message' => 'تعداد اعتبارسنجی کد تخفیف بیش از حد. لطفاً یک دقیقه صبر کنید.',
        ],
    ],

    'message' => [
        'typing' => [
            'max_attempts' => 20,
            'decay_minutes' => 1,
            'message' => 'تعداد درخواست‌های تایپ بیش از حد مجاز است.',
        ],
        'send' => [
            'max_attempts' => 20,
            'decay_minutes' => 1,
            'message' => 'تعداد ارسال پیام بیش از حد. لطفاً کمی صبر کنید.',
        ],
    ],

    'search' => [
        'general' => [
            'max_attempts' => env('RATE_LIMIT_SEARCH_MAX', 30),
            'decay_minutes' => 1,
        ],
        'advanced' => [
            'max_attempts' => env('RATE_LIMIT_SEARCH_ADV_MAX', 20),
            'decay_minutes' => 1,
        ],
        // Admin-side bulk search panel.
        'admin_user' => [
            'max_attempts' => env('RATE_LIMIT_ADMIN_SEARCH_USER_MAX', 50),
            'decay_minutes' => 1,
        ],
        'admin_ip' => [
            'max_attempts' => env('RATE_LIMIT_ADMIN_SEARCH_IP_MAX', 100),
            'decay_minutes' => 1,
        ],
        'admin_fingerprint' => [
            'max_attempts' => env('RATE_LIMIT_ADMIN_SEARCH_FP_MAX', 60),
            'decay_minutes' => 1,
        ],
    ],

    /**
     * Payment gateway callbacks — extremely sensitive (replay/DoS surface).
     * Section 8.8 — moved here from PaymentService hardcode (20/1m).
     */
    'payment' => [
        'callback' => [
            'max_attempts' => env('RATE_LIMIT_PAYMENT_CALLBACK_MAX', 20),
            'decay_minutes' => 1,
            'fail_closed' => true,
        ],
        'verify' => [
            'max_attempts' => env('RATE_LIMIT_PAYMENT_VERIFY_MAX', 10),
            'decay_minutes' => 1,
            'fail_closed' => true,
        ],
    ],

    'two_factor' => [
        'verify' => [
            'max_attempts' => 5,
            'decay_minutes' => 10,
            'message' => 'تعداد تلاش‌های تایید 2FA بیش از حد. لطفاً 10 دقیقه صبر کنید.'
        ],
        'enable' => [
            'max_attempts' => 5,
            'decay_minutes' => 60,
        ],
        'disable' => [
            'max_attempts' => 3,
            'decay_minutes' => 60,
        ],
        // MEDIUM-M-14 Fix: Separate rate limit for recovery code attempts
        // Recovery codes are high-value credentials and need stricter limits
        'recovery_code' => [
            'max_attempts' => 3,
            'decay_minutes' => 5,  // 5 minutes instead of 10 for TOTP
            'message' => 'تعداد تلاش‌های کد بازیابی بیش از حد. لطفاً 5 دقیقه صبر کنید.'
        ],
    ],
    /**
     * Section 8.8 — Centralized route → (group, endpoint) mapping.
     * Used by App\Middleware\RateLimitMiddleware to replace its
     * hardcoded ROUTE_LIMITS table. Match is done with str_starts_with.
     *
     * Order matters: most specific prefixes first.
     */
    'route_map' => [
        // Auth
        '/login'                  => ['auth', 'login'],
        '/register'               => ['auth', 'register'],
        '/forgot-password'        => ['auth', 'forgot_password'],
        '/reset-password'         => ['auth', 'reset_password'],

        // Financial
        '/wallet/deposit/crypto'  => ['financial', 'deposit'],
        // FIX-MODULE2-M3: همگام‌سازی route_map با route table واقعی (routes/wallet.php).
        // این POSTها RateLimitMiddleware داشتند ولی ورودی map نداشتند ⇒ به default
        // عمومی می‌افتادند: نه سقف مالی تنظیم‌شده، نه token-bucket critical-path
        // (CORE-042) و نه fail-closed.
        '/wallet/deposit/online'  => ['financial', 'deposit'],
        '/wallet/deposit/manual'  => ['financial', 'deposit'],
        '/wallet/withdraw'        => ['financial', 'withdrawal'],
        '/wallet/transfer'        => ['financial', 'transfer'],
        '/wallet/escrow'          => ['financial', 'escrow'],
        '/payment/callback'       => ['payment',   'callback'],
        '/payment/verify'         => ['payment',   'verify'],
        '/payment'                => ['financial', 'deposit'],
        '/withdrawal'             => ['financial', 'withdrawal'],

        // KYC
        '/kyc'                    => ['kyc',       'submit'],

        // 2FA
        // FIX-X349 (راند ۸۵): کلید قدیمی '/two-factor/verify' با هیچ روت واقعی تطبیق
        // نمی‌شد (اندپوینت واقعی تأیید دومرحله‌ای '/verify-2fa' است — routes/auth.php:38)
        // → سقف ۵/۱۰ دقیقهٔ two_factor.verify هرگز اعمال نمی‌شد. کلید اصلاح شد.
        '/verify-2fa'             => ['two_factor','verify'],
        // FIX-36/F-A3-04 (راند R36-W2-D): ورودی اختصاصی disable باید «قبل از»
        // '/two-factor' بیاید (first-match-wins روی str_starts_with) وگرنه
        // two_factor.disable (3/60min) زیر '/two-factor' => enable دفن می‌شد.
        '/two-factor/disable'     => ['two_factor','disable'],
        '/two-factor'             => ['two_factor','enable'],

        // FIX-S10-1 (بچ S10): سیم‌کشی گمشدهٔ سقف 2FA ادمین — بلوک config
        // rate_limits.admin.2fa_verify (3/10دقیقه) از ابتدا تعریف شده بود ولی
        // هیچ ورودی route_map به آن اشاره نمی‌کرد ⇒ /admin/verify-2fa عملاً
        // سقف loose admin.general (100/دقیقه) را می‌گرفت. باید «قبل از»
        // catch-all '/admin' باشد (اولین تطبیق prefix می‌برد).
        '/admin/verify-2fa'       => ['admin',     '2fa_verify'],

        // API
        '/api/v1/real-time/poll'  => ['api',       'authenticated'],
        '/api/v1/ping'            => ['api',       'fast_test'],
        // FIX-M11-R22-10: ورودی‌های endpoint توکن «قبل از» catch-all '/api/v1' —
        // first-match-wins روی prefix؛ قبلاً '/api/v1/auth/token' و '/api/v1/auth/refresh'
        // هیچ‌وقت به auth.login نمی‌رسیدند (policy مستند عملاً خاموش بود — همان
        // الگوی FIX-M11-H1 روی sensitive_paths). ورودی‌های مردهٔ '/api/auth' و
        // '/api/token' و '/api/public' حذف شدند (هیچ route واقعی با این پیشوند نیست).
        '/api/v1/auth/token'      => ['auth',      'api_token'],
        '/api/v1/auth/refresh'    => ['auth',      'api_token'],
        '/api/v1'                 => ['api',       'general'],

        // FIX-X343 (راند ۸۴): وب‌هوک‌های S2S ویدیو-پاداشی — پیش‌تر بدون ورودی
        // route_map، سقف پیش‌فرض (در سندباکس ۵/دقیقه!) را می‌گرفتند؛ پاداش‌های
        // هم‌زمان چند کاربر از IP سرورِ شبکه بعد از چند درخواست ۴۲۹ می‌شد.
        // سقف اختصاصی: ۳۰۰/دقیقه بر IP (سرورهای شبکه‌ها IP محدودی دارند).
        '/webhooks/video-reward'  => ['webhook',    'video_reward'],

        // Search
        '/search/advanced'        => ['search',    'advanced'],
        '/search'                 => ['search',    'general'],

        // Reports / exports
        '/reports/export'         => ['reports',   'export'],
        '/reports'                => ['reports',   'generate'],

        // Tasks
        '/task/submit'            => ['task',      'submit'],
        '/task/dispute'           => ['task',      'dispute'],
        '/task'                   => ['task',      'execute'],

        // Admin (catch-all)
        // FIX-X349: ورودی مردهٔ '/admin/auth' حذف شد — هیچ روتی با این پیشوند وجود ندارد
        // (لاگین ادمین '/admin/login' است)؛ '/admin' همه‌چیزِ ادمین را از قبل می‌پوشاند.
        // FIX-36/F-A3-04 (راند R36-W2-D): '/admin/login' به‌صورت اختصاصی و «قبل از»
        // catch-all '/admin' اضافه شد — با حذف پارامتر صریح ':10,1' از روت، سقف
        // تیون‌شدهٔ admin.login (3/10دقیقه) حالا واقعاً اعمال می‌شود (بدون این ورودی،
        // روت به catch-all '/admin' = admin.general 100/min می‌افتاد و شُل‌تر می‌شد).
        '/admin/login'            => ['admin',     'login'],
        '/admin'                  => ['admin',     'general'],
    ],

    /**
     * Section 8.8 — Centralized action → (group, endpoint) mapping for
     * App\Policies\RateLimitPolicy. When a FeatureFlag override is absent
     * the Policy now falls back to this mapping instead of the previous
     * restrictive "3 per 24h" lockout.
     */
    'action_map' => [
        'withdrawal'      => ['financial',  'withdrawal'],
        'manual_deposit'  => ['financial',  'deposit'],
        'crypto_deposit'  => ['financial',  'deposit'],
        'bank_card_add'   => ['financial',  'deposit'],
        'task_submit'     => ['task',       'submit'],
        'task_dispute'    => ['task',       'dispute'],
        'task_execute'    => ['task',       'execute'],
        'task_create'     => ['task',       'create'],
        'kyc_submit'      => ['kyc',        'submit'],
        'profile_update'  => ['content',    'update'],
        'password_change' => ['auth',       'reset_password'],
        'ticket_create'   => ['social',     'ticket_create'],
        'ticket_reply'    => ['social',     'ticket_reply'],
        'login'           => ['auth',       'login'],
        'register'        => ['auth',       'register'],
        'two_factor_verify'  => ['two_factor', 'verify'],
        'two_factor_enable'  => ['two_factor', 'enable'],
        'two_factor_disable' => ['two_factor', 'disable'],
        'two_factor_recovery'=> ['two_factor', 'recovery_code'],
        'payment_callback'   => ['payment', 'callback'],
        'payment_verify'     => ['payment', 'verify'],
        'admin_search_user'        => ['search', 'admin_user'],
        'admin_search_ip'          => ['search', 'admin_ip'],
        'admin_search_fingerprint' => ['search', 'admin_fingerprint'],
        'lottery_participate' => ['lottery', 'participate'],
        'referral_check_code' => ['referral', 'check_code'],
        'investment_create'   => ['investment', 'create'],
        'lottery_vote'   => ['lottery', 'vote'],
        'social_account_add' => ['social_account', 'add'],
        'camera_challenge'   => ['camera_challenge', 'challenge'],
        'camera_verify'     => ['camera_challenge', 'verify'],
        'coupon_validate'    => ['coupon', 'validate'],
        'score_apply'    => ['score', 'apply'],
        'message_send'   => ['message', 'send'],
        'admin_bugreport_reply' => ['admin', 'bugreport_reply'],
        'admin_ticket_reply'    => ['admin', 'ticket_reply'],
        'typing_limit'          => ['message', 'typing'],
        'investment_withdraw' => ['investment', 'withdraw'],
        'content_create'      => ['content',    'create'],
        'content_update'      => ['content',    'update'],
        'content_delete'      => ['content',    'delete'],
    ],

];