<?php
/**
 * تنظیمات اصلی سیستم
 * 
 * این فایل تنظیمات از .env را بارگذاری می‌کند
 */

return [
    'app' => [
        'name' => env('APP_NAME', 'Chortke'),
        'env' => env('APP_ENV', 'local'),
        'debug' => env('APP_DEBUG', false),
        'url' => env('APP_URL', 'http://localhost'),
        'asset_url' => env('ASSET_URL', env('CDN_URL', '')),
        'base_path' => env('APP_BASE_PATH', ''),
        'timezone' => env('APP_TIMEZONE', 'Asia/Tehran'),
        'key' => env('APP_KEY', ''),
        'trusted_proxies' => array_filter(array_map('trim', explode(',', env('TRUSTED_PROXIES', '127.0.0.1')))),
        // FIX-M2M16: گات صریح opt-in برای هدرهای سمت‌کلاینت (Client-IP) — پیش‌فرض OFF
        'trust_proxy_headers' => filter_var(env('TRUST_PROXY_HEADERS', false), FILTER_VALIDATE_BOOLEAN),
        // FIX-M1M4: allowlist هاست مجاز برای origin در محیط‌های غیر-production
        // (مبنای CSRF origin-check و redirect same-origin). خالی = رفتار dev.
        'allowed_hosts' => array_filter(array_map('trim', explode(',', (string)env('APP_ALLOWED_HOSTS', '')))),
        'safe_mode' => env('APP_SAFE_MODE', false),
        'version' => env('APP_VERSION', '2.4.0-hardened'),
        'release' => env('APP_RELEASE', '1.0.0'),
        'encryption_key_version' => env('APP_ENCRYPTION_KEY_VERSION', 1),
        // Fix L4: لیست سفید مسیرهایی که در Safe Mode مجاز برای تغییر هستند
        'safe_mode_whitelist' => env('SAFE_MODE_WHITELIST', '/login,/logout,/verify-2fa')
            ? array_filter(array_map('trim', explode(',', (string)env('SAFE_MODE_WHITELIST', '/login,/logout,/verify-2fa'))))
            : ['/login', '/logout', '/verify-2fa'],
        // FIX راند ۷۹ (X310 کلیدهای سایه‌ای): ارتقای کلیدهای شبح به پیکربندی رسمی
        // (مقادیر = عین defaultهای درون‌خطی قبلی — صفر تغییر رفتار)
        'sla_threshold_ms' => 1000,
        'mobile' => [
            'scheme' => 'chortke',
        ],
        'websocket' => [
            'bulkhead_limit' => 500,
            'presence_ttl' => 300,
        ],
    ],
    
    'database' => [
        'driver' => env('DB_DRIVER', 'mysql'),
        'host' => env('DB_HOST', 'localhost'),
        'port' => env('DB_PORT', 3306),
        'name' => env('DB_NAME', 'chortk'),
        // FIX-R36-W3 (F-A24a-06/1): کلید مردهٔ 'database' حذف شد — consumer واقعی
        // (core/Database::normalizeDbConfig) فقط 'name' را می‌شناسد و
        // config('database.database') صفر مصرف‌کننده داشت (grep کل درخت؛ همان
        // توصیهٔ REVIEW_ROUND19 C-4). default قبلی «/home/user/database.sqlite»
        // در پروژهٔ MySQL-تنها گمراه‌کنندهٔ اپراتور/ابزار بود؛ DB_DATABASE env
        // همچنان جایی که واقعاً مصرف می‌شود (installer) خوانده می‌شود.
        // FIX راند ۷۵ (یکسان‌سازی DB_USERNAME/DB_USER): نام رسمی DB_USER/DB_PASS است
        // (نوشتهٔ installer و .env.example)؛ DB_USERNAME/DB_PASSWORD به‌عنوان
        // نام‌های جایگزین سازگار با Laravel پذیرفته می‌شوند تا .envهای قدیمی ساکت نشکنند.
        'user' => env('DB_USER', env('DB_USERNAME', 'root')),
        'pass' => env('DB_PASS', env('DB_PASSWORD', '')),
        'charset' => env('DB_CHARSET', 'utf8mb4'),
        'mysqldump_path' => env('DB_DUMP_PATH', 'mysqldump'),
        'mysql_path' => env('DB_MYSQL_PATH', 'mysql'),
        // FIX راند ۷۹: کلیدهای سایه‌ای core/Database (default = عین کد)
        'track_queries' => false,
        'track_queries_sample_rate' => 1.0,
    ],
    
    'session' => [
        // حداقل عمر کوکی سشن ۳۰ دقیقه است؛ Idle timeout واقعی در AuthMiddleware کنترل می‌شود.
        // اگر SESSION_LIFETIME خیلی کم باشد (مثلاً 120 ثانیه)، کاربر قبل از timeout تنظیم‌شده از سایت خارج می‌شود.
        'lifetime' => max(1800, (int)env('SESSION_LIFETIME', 7200)),
        'driver' => env('SESSION_DRIVER', 'redis'),
        'fallback' => env('SESSION_FALLBACK_STORAGE', 'file'),
        'name' => 'CHORTKE_SESSION',
        // ── Fix #1: Lax برای سازگاری با OAuth callback (Google/Facebook)
        // ── Fix #2: secure بر اساس HTTPS واقعی + trusted proxy (نه فقط APP_ENV)
        'secure' => (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
                 || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https'
                     && in_array($_SERVER['REMOTE_ADDR'] ?? '', array_filter(array_map('trim', explode(',', env('TRUSTED_PROXIES', '127.0.0.1')))), true)),
        'httponly' => true,
        'samesite' => 'Lax',
        // FIX راند ۷۹: کلیدهای سایه‌ای RedisSessionHandler (default = عین کد)
        'sliding_ttl' => true,
        // AUDIT-FIX (R4): سقف عمر مطلق نشست — قابل تنظیم از env (SESSION_ABSOLUTE_LIFETIME)
        'absolute_lifetime' => (int)env('SESSION_ABSOLUTE_LIFETIME', 86400),
    ],
    
    'csrf' => [
        // FIX-M2M15: نام توکن کانونیک — pin به Core\CSRF::TOKEN_NAME
        // (تغییر از env حذف شد تا drift بین فرم‌ساز و verifier ممکن نباشد)
        'token_name' => \Core\CSRF::TOKEN_NAME,
        'token_length' => 64,
    ],


    'retry_policy' => [
        'max_attempts' => env('RETRY_MAX_ATTEMPTS', 3),
        'initial_delay_ms' => env('RETRY_INITIAL_DELAY_MS', 100),
        'multiplier' => env('RETRY_BACKOFF_MULTIPLIER', 2),
        'max_delay_ms' => env('RETRY_MAX_DELAY_MS', 2000),
    ],

    'circuit_breaker' => [
        // ── تنظیمات سراسری پیش‌فرض ────────────────────────────────────────
        'failure_threshold'    => env('CIRCUIT_FAILURE_THRESHOLD', 5),
        'retry_timeout_seconds' => env('CIRCUIT_RETRY_TIMEOUT_SECONDS', 60),

        // ── تنظیمات per-gateway درگاه‌های پرداخت ───────────────────────────
        // کلید: نامی که BasePaymentGateway::executeWithCircuitBreaker() به CB پاس می‌دهد
        //       = 'payment_gateway:' . getGatewayName()
        //
        // threshold : تعداد خطای متوالی تا باز شدن مدار
        // timeout   : مدت باز ماندن مدار (ثانیه) قبل از HALF_OPEN
        'payment_gateway:zarinpal' => [
            'threshold' => env('CIRCUIT_ZARINPAL_THRESHOLD',  3),
            'timeout'   => env('CIRCUIT_ZARINPAL_TIMEOUT',  120),   // 2 دقیقه
        ],
        'payment_gateway:idpay' => [
            'threshold' => env('CIRCUIT_IDPAY_THRESHOLD',  3),
            'timeout'   => env('CIRCUIT_IDPAY_TIMEOUT',  120),
        ],
        'payment_gateway:nextpay' => [
            'threshold' => env('CIRCUIT_NEXTPAY_THRESHOLD',  3),
            'timeout'   => env('CIRCUIT_NEXTPAY_TIMEOUT',  120),
        ],
        'payment_gateway:dgpay' => [
            'threshold' => env('CIRCUIT_DGPAY_THRESHOLD',  3),
            'timeout'   => env('CIRCUIT_DGPAY_TIMEOUT',  120),
        ],
    ],
    
    // ── Fix #5: feature_flags از اینجا حذف شد
    // ── منبع حقیقت واحد: config/feature_flags.php
    // ── (برای دسترسی: config_load('feature_flags')['cache_enabled'])
    
    'upload' => [
        'max_size' => env('MAX_UPLOAD_SIZE', 10485760), // 10MB
        // ── Fix #3: مسیر آپلود خارج از public (برای فایل‌های خصوصی)
        // ── UploadService خودش public/uploads vs storage/uploads را مدیریت می‌کند
        'path' => env('UPLOAD_PATH', __DIR__ . '/../storage/uploads/'),
        // ── Fix #4: allowed_videos حذف شد
        // ── UploadService منبع حقیقت واحد برای MIME های مجاز است (IMAGE_MIMES)
        // ── ویدیو توسط UploadService::DANGEROUS_EXT صریحاً رد می‌شود
    ],
    
    'mail' => [
        'driver' => env('MAIL_DRIVER', 'smtp'),
        'host' => env('MAIL_HOST'),
        'port' => env('MAIL_PORT', 587),
        'username' => env('MAIL_USERNAME'),
        'password' => env('MAIL_PASSWORD'),
        'encryption' => env('MAIL_ENCRYPTION', 'tls'),
        'from' => [
            'address' => env('MAIL_FROM_ADDRESS'),
            'name' => env('MAIL_FROM_NAME'),
        ],
    ],

    // FIX-M4-14: بلاک مردهٔ crypto.usdt حذف شد — نگاشت env USDT_*_ADDRESS هیچ
    // مصرف‌کننده‌ای نداشت؛ مسیرهای زندهٔ UI/API (CryptoDepositController/
    // CryptoDepositService) آدرس‌ها را از AppSettings با کلیدهای site_usdt_*_address
    // (پنل ادمین) می‌خوانند. منبع حقیقت = تنظیمات DB؛ متغیر env بلااستفاده فقط
    // اپراتور را گمراه می‌کرد که تغییرش اثری ندارد.
        'captcha' => [
  'recaptcha_site_key'   => env('RECAPTCHA_SITE_KEY', ''),
  'recaptcha_secret_key' => env('RECAPTCHA_SECRET_KEY', ''),
],

    'cors' => [
        'allowed_origins' => env('CORS_ALLOWED_ORIGINS', ''),
        // FIX راند ۷۹: کلید سایه‌ای CorsMiddleware (default = عین کد)
        'credential_origins' => env('CORS_CREDENTIAL_ORIGINS', ''),
    ],
    
    'security' => [
        // CDN/static origins allowed by CSP. Override with CSP_CDN_WHITELIST in .env.
        'csp_cdn_whitelist' => array_filter(array_map('trim', explode(',', env(
            'CSP_CDN_WHITELIST',
            ''
        )))),
        'api' => [
            'secrets' => [
                // FIX-R19-A8-6: default '' (fail-closed) — fallback هاردکد برای هر entrypoint
                // تازه‌ای که config را بدون bootstrap ریسولو کند، secret جعلی نمی‌دهد؛
                // مصرف‌کننده‌ها (ApiAuthMiddleware/ConcurrentRequestMiddleware/ApiToken)
                // secret خالی/کوتاه‌تر از ۳۲ را skip می‌کنند ⇒ 401، نه پذیرش توکن.
                // بوت واقعی (bootstrap/app.php) نبودِ SECURITY_API_TOKEN_SECRET <32 را throw می‌کند.
                'v1' => env('SECURITY_API_TOKEN_SECRET_V1', env('SECURITY_API_TOKEN_SECRET', '')),
                'v2' => env('SECURITY_API_TOKEN_SECRET_V2', env('SECURITY_API_TOKEN_SECRET', '')),
            ],
            'current_secret_version' => normalize_secret_version(env('SECURITY_API_TOKEN_CURRENT_VERSION', 'v2')),
            // 🛡️ FIX-SECRETROT-2: نرمال‌سازی از منبع کانونی — قبلاً مقدار خام env
            // پاس می‌شد؛ «1» (بدون «v»، همان پیش‌فرض .env.example قدیمی) به
            // کلید ناموجود security.api.secrets.1 می‌انجامید و ApiToken::create
            // توکنی با برچسب نسخهٔ نامعتبر می‌ساخت (هرگز validate نمی‌شد).
            // FIX راند ۷۹: کلید سایه‌ای ApiAuthMiddleware (default = عین کد) — داخل security.api
            // FIX-M11-H1 (گزارش ماژول ۱۱): پیشوندهای نسخه‌دارِ /api/v1 — مسیرهای واقعی
            // routeها (routes/api.php) زیر این پیشوندهاند و گیتِ مالکیت بدونشان خاموش بود.
            'sensitive_paths' => [
                '/api/payment',
                '/api/withdrawal',
                '/api/wallet',
                '/api/account',
                '/api/profile/update',
                '/api/admin',
                '/api/security',
                '/api/2fa',
                '/api/token',
                '/api/v1/wallet',
                '/api/v1/payment',
                '/api/v1/withdrawal',
                '/api/v1/account',
                '/api/v1/profile',
                '/api/v1/admin',
                '/api/v1/security',
                '/api/v1/2fa',
                '/api/v1/user',
                '/api/v1/auth/token',
                '/api/v1/auth/revoke',
                '/api/v1/auth/tokens',
            ],
        ],
    ],
    
    'encryption' => [
        'message_keys' => [
            // FIX-S20-2 (fail-closed): بدون env صریح = خالی — هیچ مصرف‌کنندهٔ آینده‌ای
            // نباید بی‌صدا روی کلید ساختگیِ هاردکد (عمومی) رمز کند (CWE-798/ضد تله).
            1 => env('MESSAGE_ENCRYPTION_KEY_V1', ''),
        ]
    ],

    // ── FIX راند ۷۹ (X310): بخش‌های تازه برای کلیدهای شبح — مقادیر = عین defaultهای درون‌خطی کد ──
    'cache' => [
        'require_redis' => false,
    ],
    'request' => [
        'max_body_bytes' => 12 * 1024 * 1024, // 12 MB؛ validatorهای سطح feature سقف سخت‌گیرانه‌تر دارند
    ],
    'paths' => [
        'storage' => __DIR__ . '/../storage',
    ],
    'lock' => [
        // P1-1 FIX (S33 audit): fail-CLOSED is the global policy — when Redis (the
        // lock backend) is unavailable, critical sections refuse to run instead of
        // degrading to a multi-server-unsafe file lock. Only explicitly-reviewed
        // read-only paths opt out at the call site. Set false to restore the old
        // single-server graceful fallback.
        'fail_closed' => true,
    ],
    'api' => [
        'default_version' => 'v1',
        'supported_versions' => ['v1', 'v2'],
    ],
    'webhooks' => [
        // FIX-R36-W3 (F-A24a-06/2): تلهٔ دوگانه‌ی secret وب‌هوک مستند شد —
        // این کلید (جمع، webhooks.secret) فقط برای امضای وب‌هوک ورودیِ
        // CSRFMiddleware:262 است؛ secret وب‌هوک‌های مالی/Reconciliation در
        // config/webhook.php (مفرد، env WEBHOOK_SECRET) است. هر دو fail-closed‌اند؛
        // secret را در فایل اشتباه نگذارید (اتحاد آینده نیازمند تغییر consumerها در
        // app/ است — پیشنهاد cross-domain در گزارش W3-M ثبت شد).
        'secret' => '',
    ],
    'account' => [
        'deletion_grace_days' => 7,
    ],
    // دو املای antifraud/anti_fraud در کد موجودند — هر دو حفظ شدند (مستندسازی املاهای دوگانه)
    'antifraud' => [
        'fail_open_actions' => [],
    ],
    'anti_fraud' => [
        'datacenter_ip_ranges' => [],
        // 🛡️ FIX-R36-W2-E2 (F-A10-03): امتیازِ وضعیت «unknown» برای IPهای
        // loopback/private/reserved/unparseable در IPQualityService::check.
        // غیرِ clean (دیگر fail-open نیست) ولی سقف ۸۹ = زیر آستانهٔ hard-block
        // گارد (FraudGuard فقط risk_score>=90 را می‌بندد). هم‌خانوادهٔ
        // ip.private_range_points در policy (۵۰).
        'private_ip_unknown_score' => 50,
        // 🛡️ FIX-R36-W2-E2 (F-A10-02): سقف سهمِ دوربین در نمرهٔ نهایی تسک.
        // وزن اسمی در SubmitSocialTaskExecutionJob ۰.۳۰ (=۳۰ امتیاز) است؛ چون
        // camera_score عدد ادعایی کلاینت است (فقط clamp — بدون ML/attestation
        // سمت سرور)، سهم مؤثرش با این سقف محدود می‌شود. مقادیر مجاز ۰..۳۰.
        'camera_contribution_cap' => 15,
        // 🛡️ FIX-R36-W2-E2 (F-A10-05): حلقهٔ سوءاستفادهٔ گزارش.
        // پنجرهٔ dedupe per (reporter,target,type) — یک گزارشده در این پنجره
        // فقط یک بار می‌تواند روی یک هدف رکورد REPORT بسازد (ثانیه).
        'report_dedupe_ttl' => 86400,
        // پنجرهٔ تک‌فیرِ آلارم آستانهٔ گزارش (per target) — از هر آستانه‌گذری
        // فقط یک اعلان ادمین در این پنجره صادر می‌شود (ثانیه).
        'report_alarm_ttl' => 86400,
    ],
    'filesystems' => [
        's3' => [
            'bucket' => env('AWS_BUCKET', 'chortke-cloud-storage'),
            'endpoint' => env('AWS_ENDPOINT', 'https://s3.amazonaws.com'),
            'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
        ],
    ],
    // کلیدهای تخت (بدون نقطه) — resolve مسیر fallback به کلید کامل در همین فایل است
    'site_currency' => 'irt',
    'min_withdrawal_usdt' => '10',
    'min_withdrawal_irt' => '50000',
];