<?php

declare(strict_types=1);

return [
    /*
    |--------------------------------------------------------------------------
    | System-wide Retry Budget Config
    |--------------------------------------------------------------------------
    | این بخش سهمیه تلاش مجدد (Retry Budget) را برای بخش‌های مختلف سیستم تعریف می‌کند.
    | مقادیر بر اساس درصد کل درخواست‌ها محاسبه می‌شوند.
    */
    'retry_budget' => [
        // تنظیمات سراسری پیش‌فرض (Global Default)
        'global' => [
            'allowed_percentage' => 10, // حداکثر ۱۰ درصد از کل درخواست‌ها اجازه Retry دارند
            'min_allowance' => 5,      // حداقل تعداد Retry مجاز قبل از اعمال درصد (Cold start)
        ],
        // تنظیمات اختصاصی برای کانتکست‌ها و صف‌های خاص
        'contexts' => [
            'queue:high_priority' => [
                'allowed_percentage' => 20, // صف‌های با اولویت بالا سهمیه بیشتری دارند
                'min_allowance' => 10,
            ],
            'queue:notifications' => [
                'allowed_percentage' => 5,  // نوتیفیکیشن‌ها اولویت پایین‌تری برای Retry دارند
                'min_allowance' => 2,
            ],
            'service:payment_gateway' => [
                'allowed_percentage' => 15,
                'min_allowance' => 3,
            ]
        ],
    ],

    // FIX-M4-06: بلاک «circuit_breaker» که اینجا بود هیچ مصرف‌کننده‌ای نداشت —
    // مصرف‌کنندهٔ واقعی (core/CircuitBreaker.php) کلید «circuit_breaker» (سطح ریشه،
    // config/config.php) را می‌خواند که env-driven است با کلیدهای CIRCUIT_* و
    // پیکربندی per-gateway ('payment_gateway:<name>'). دو ساختار شبیه‌هم اپراتور را
    // گمراه می‌کرد: تغییر اینجا هرگز اثری نداشت. مسیر کانونی فقط همان config.php است؛
    // برای تنظیم درگاه‌ها CIRCUIT_ZARINPAL_THRESHOLD / CIRCUIT_IDPAY_TIMEOUT / ... را
    // در .env مقدار بدهید.
];
