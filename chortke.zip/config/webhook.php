<?php
/**
 * تنظیمات Webhook
 *
 * SECURITY: مقدار WEBHOOK_SECRET باید در .env تنظیم شود.
 * اگر تنظیم نشده باشد، null برمی‌گردد و ReconciliationService
 * با پرتاب RuntimeException از پردازش هر webhook جلوگیری می‌کند.
 *
 * تولید یک secret امن:
 *   php -r "echo bin2hex(random_bytes(32)) . PHP_EOL;"
 */

return [
    /*
    |--------------------------------------------------------------------------
    | Webhook HMAC Secret
    |--------------------------------------------------------------------------
    |
    | این مقدار برای تأیید امضای HMAC-SHA256 تمام webhookهای ورودی استفاده
    | می‌شود. این کلید باید حداقل ۳۲ کاراکتر تصادفی باشد.
    |
    | ⚠️  هرگز مقدار پیش‌فرض یا hardcoded نگذارید.
    | ⚠️  در صورت عدم تنظیم، سیستم webhook را رد خواهد کرد.
    |
    */
    // FIX-R36-W3 (F-A24a-06/2): تلهٔ دوگانه — این secret (مفرد، WEBHOOK_SECRET)
    // مصرف‌کننده‌های ReconciliationService/MockPaymentGateway دارد؛ secretِ امضای
    // وب‌هوک ورودیِ CSRFMiddleware کلید «webhooks.secret» (جمع) در config/config.php
    // است — دومی env ندارد و فقط با config_set مقدار می‌گیرد. هر دو fail-closed.
    'secret' => env('WEBHOOK_SECRET', null),

    /*
    |--------------------------------------------------------------------------
    | IP Allowlist
    |--------------------------------------------------------------------------
    |
    | لیست IPهای مجاز برای ارسال webhook. خالی = همه مجازند (توصیه نمی‌شود).
    | مثال: WEBHOOK_ALLOWED_IPS=1.2.3.4,5.6.7.8
    |
    */
    'allowed_ips' => array_filter(
        array_map('trim', explode(',', (string) env('WEBHOOK_ALLOWED_IPS', '')))
    ),

    /*
    |--------------------------------------------------------------------------
    | Signature Header Name
    |--------------------------------------------------------------------------
    |
    | نام header که امضای HMAC در آن ارسال می‌شود.
    |
    */
    'signature_header' => env('WEBHOOK_SIGNATURE_HEADER', 'X-Signature'),
];
