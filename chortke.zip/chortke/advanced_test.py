#!/usr/bin/env python3
"""
🔬 Chortke Advanced Test Suite
================================
تست‌های پیشرفته شامل:
- تست API endpoints
- تست Performance
- تست Security
- تست Database Queries
- تست Queue System
"""

import requests
import time
import json
from typing import Dict, List
from colorama import Fore, Style
from dataclasses import dataclass

@dataclass
class ApiTestResult:
    endpoint: str
    method: str
    status_code: int
    response_time: float
    passed: bool
    error: str = None

class ChortkeAdvancedTests:
    """تست‌های پیشرفته"""
    
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.results = []
    
    def test_api_endpoints(self) -> List[ApiTestResult]:
        """تست تمام API endpoints کلیدی"""
        print(f"\n{Fore.CYAN}{'='*60}")
        print(f"{Fore.CYAN}🔌 تست API Endpoints")
        print(f"{Fore.CYAN}{'='*60}\n")
        
        endpoints = [
            ("GET", "/health"),
            ("GET", "/api/health"),
            ("GET", "/"),
            ("GET", "/login"),
            ("GET", "/register"),
        ]
        
        results = []
        
        for method, endpoint in endpoints:
            try:
                url = f"{self.base_url}{endpoint}"
                start = time.time()
                
                if method == "GET":
                    response = self.session.get(url, timeout=10, allow_redirects=True)
                elif method == "POST":
                    response = self.session.post(url, timeout=10, allow_redirects=True)
                
                response_time = time.time() - start
                
                # تعیین موفقیت
                passed = response.status_code in [200, 201, 302, 401, 403]
                
                result = ApiTestResult(
                    endpoint=endpoint,
                    method=method,
                    status_code=response.status_code,
                    response_time=response_time,
                    passed=passed
                )
                
                status_color = Fore.GREEN if passed else Fore.RED
                status_icon = "✅" if passed else "❌"
                
                print(f"{status_icon} {method:4} {endpoint:30} → {status_color}{response.status_code}{Style.RESET_ALL} ({response_time*1000:.0f}ms)")
                
                results.append(result)
                
            except Exception as e:
                result = ApiTestResult(
                    endpoint=endpoint,
                    method=method,
                    status_code=0,
                    response_time=0,
                    passed=False,
                    error=str(e)
                )
                print(f"❌ {method:4} {endpoint:30} → {Fore.RED}ERROR{Style.RESET_ALL}: {e}")
                results.append(result)
            
            time.sleep(0.5)
        
        return results
    
    def test_database_connection(self) -> bool:
        """تست اتصال به دیتابیس (غیرمستقیم از طریق health check)"""
        print(f"\n{Fore.CYAN}💾 تست اتصال دیتابیس...")
        
        try:
            response = self.session.get(f"{self.base_url}/health", timeout=5)
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    db_status = data.get('database', {}).get('status', 'unknown')
                    
                    if db_status == 'ok' or db_status == 'connected':
                        print(f"{Fore.GREEN}✅ دیتابیس متصل است{Style.RESET_ALL}")
                        return True
                    else:
                        print(f"{Fore.YELLOW}⚠️  وضعیت دیتابیس: {db_status}{Style.RESET_ALL}")
                        return False
                except:
                    # اگر JSON نبود، فقط status code را چک می‌کنیم
                    print(f"{Fore.GREEN}✅ Health endpoint پاسخ داد (فرض: DB OK){Style.RESET_ALL}")
                    return True
            else:
                print(f"{Fore.RED}❌ Health check ناموفق: {response.status_code}{Style.RESET_ALL}")
                return False
                
        except Exception as e:
            print(f"{Fore.RED}❌ خطا در تست دیتابیس: {e}{Style.RESET_ALL}")
            return False
    
    def test_redis_connection(self) -> bool:
        """تست اتصال به Redis"""
        print(f"\n{Fore.CYAN}🔴 تست اتصال Redis...")
        
        try:
            response = self.session.get(f"{self.base_url}/health", timeout=5)
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    redis_status = data.get('redis', {}).get('status', 'unknown')
                    
                    if redis_status == 'ok' or redis_status == 'connected':
                        print(f"{Fore.GREEN}✅ Redis متصل است{Style.RESET_ALL}")
                        return True
                    else:
                        print(f"{Fore.YELLOW}⚠️  وضعیت Redis: {redis_status}{Style.RESET_ALL}")
                        return False
                except:
                    print(f"{Fore.YELLOW}⚠️  نمی‌توان وضعیت Redis را تشخیص داد{Style.RESET_ALL}")
                    return False
            else:
                return False
                
        except Exception as e:
            print(f"{Fore.RED}❌ خطا: {e}{Style.RESET_ALL}")
            return False
    
    def test_response_times(self) -> Dict:
        """تست زمان پاسخ‌دهی صفحات"""
        print(f"\n{Fore.CYAN}⏱️  تست Performance (Response Times)")
        print(f"{Fore.CYAN}{'='*60}\n")
        
        pages = [
            "/",
            "/login",
            "/register",
            "/health",
        ]
        
        results = {}
        
        for page in pages:
            try:
                url = f"{self.base_url}{page}"
                
                # اندازه‌گیری 3 بار و میانگین گرفتن
                times = []
                for _ in range(3):
                    start = time.time()
                    response = self.session.get(url, timeout=10)
                    elapsed = time.time() - start
                    times.append(elapsed)
                    time.sleep(0.3)
                
                avg_time = sum(times) / len(times)
                min_time = min(times)
                max_time = max(times)
                
                results[page] = {
                    'avg': avg_time,
                    'min': min_time,
                    'max': max_time
                }
                
                # تعیین رنگ بر اساس سرعت
                if avg_time < 0.5:
                    color = Fore.GREEN
                    status = "عالی"
                elif avg_time < 1.0:
                    color = Fore.YELLOW
                    status = "خوب"
                else:
                    color = Fore.RED
                    status = "کند"
                
                print(f"{page:30} → {color}{avg_time*1000:.0f}ms{Style.RESET_ALL} (min:{min_time*1000:.0f} max:{max_time*1000:.0f}) [{status}]")
                
            except Exception as e:
                print(f"{page:30} → {Fore.RED}ERROR{Style.RESET_ALL}: {e}")
                results[page] = {'error': str(e)}
        
        return results
    
    def test_security_headers(self) -> Dict:
        """تست Security Headers"""
        print(f"\n{Fore.CYAN}🔒 تست Security Headers")
        print(f"{Fore.CYAN}{'='*60}\n")
        
        important_headers = [
            'X-Frame-Options',
            'X-Content-Type-Options',
            'X-XSS-Protection',
            'Strict-Transport-Security',
            'Content-Security-Policy',
        ]
        
        try:
            response = self.session.get(self.base_url, timeout=10)
            headers = response.headers
            
            results = {}
            
            for header in important_headers:
                value = headers.get(header, None)
                present = value is not None
                
                results[header] = {
                    'present': present,
                    'value': value
                }
                
                icon = "✅" if present else "⚠️ "
                status = f"{Fore.GREEN}موجود" if present else f"{Fore.YELLOW}ندارد"
                
                print(f"{icon} {header:35} → {status}{Style.RESET_ALL}")
                if present:
                    print(f"   {Fore.CYAN}└─ {value}{Style.RESET_ALL}")
            
            return results
            
        except Exception as e:
            print(f"{Fore.RED}❌ خطا در تست headers: {e}{Style.RESET_ALL}")
            return {}
    
    def test_error_pages(self) -> List:
        """تست صفحات خطا"""
        print(f"\n{Fore.CYAN}🚨 تست Error Pages")
        print(f"{Fore.CYAN}{'='*60}\n")
        
        error_urls = [
            ("/this-page-does-not-exist-404", 404),
            ("/admin/secret-page", [401, 403, 404]),  # ممکن است 401, 403 یا 404 بدهد
        ]
        
        results = []
        
        for url, expected_codes in error_urls:
            try:
                if not isinstance(expected_codes, list):
                    expected_codes = [expected_codes]
                
                response = self.session.get(f"{self.base_url}{url}", timeout=10, allow_redirects=False)
                
                matched = response.status_code in expected_codes
                icon = "✅" if matched else "⚠️ "
                color = Fore.GREEN if matched else Fore.YELLOW
                
                print(f"{icon} {url:40} → {color}{response.status_code}{Style.RESET_ALL} (expected: {expected_codes})")
                
                results.append({
                    'url': url,
                    'status': response.status_code,
                    'expected': expected_codes,
                    'matched': matched
                })
                
            except Exception as e:
                print(f"❌ {url:40} → {Fore.RED}ERROR{Style.RESET_ALL}: {e}")
                results.append({
                    'url': url,
                    'error': str(e)
                })
        
        return results
    
    def run_all_advanced_tests(self):
        """اجرای تمام تست‌های پیشرفته"""
        print(f"\n{Fore.CYAN}{'='*60}")
        print(f"{Fore.CYAN}🔬 شروع تست‌های پیشرفته")
        print(f"{Fore.CYAN}{'='*60}")
        
        # تست API Endpoints
        api_results = self.test_api_endpoints()
        
        # تست اتصالات
        db_ok = self.test_database_connection()
        redis_ok = self.test_redis_connection()
        
        # تست Performance
        perf_results = self.test_response_times()
        
        # تست Security
        security_results = self.test_security_headers()
        
        # تست Error Pages
        error_results = self.test_error_pages()
        
        # خلاصه نهایی
        print(f"\n{Fore.CYAN}{'='*60}")
        print(f"{Fore.CYAN}📊 خلاصه نتایج تست‌های پیشرفته")
        print(f"{Fore.CYAN}{'='*60}\n")
        
        api_passed = sum(1 for r in api_results if r.passed)
        api_total = len(api_results)
        
        print(f"🔌 API Endpoints: {Fore.GREEN}{api_passed}/{api_total}{Style.RESET_ALL} موفق")
        print(f"💾 Database: {Fore.GREEN if db_ok else Fore.RED}{'✅ OK' if db_ok else '❌ FAIL'}{Style.RESET_ALL}")
        print(f"🔴 Redis: {Fore.GREEN if redis_ok else Fore.YELLOW}{'✅ OK' if redis_ok else '⚠️  Unknown'}{Style.RESET_ALL}")
        print(f"⏱️  Performance: {len(perf_results)} صفحه تست شد")
        print(f"🔒 Security Headers: {len(security_results)} header چک شد")
        
        # ذخیره گزارش
        report = {
            'api_endpoints': [
                {
                    'endpoint': r.endpoint,
                    'method': r.method,
                    'status_code': r.status_code,
                    'response_time': r.response_time,
                    'passed': r.passed,
                    'error': r.error
                }
                for r in api_results
            ],
            'database': db_ok,
            'redis': redis_ok,
            'performance': perf_results,
            'security_headers': security_results,
            'error_pages': error_results
        }
        
        from datetime import datetime
        report_file = f"advanced_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"\n{Fore.GREEN}💾 گزارش ذخیره شد: {report_file}{Style.RESET_ALL}\n")


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Chortke Advanced Testing')
    parser.add_argument('--url', default='http://localhost', help='Base URL')
    
    args = parser.parse_args()
    
    suite = ChortkeAdvancedTests(args.url)
    suite.run_all_advanced_tests()


if __name__ == "__main__":
    main()
