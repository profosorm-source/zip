<?php

declare(strict_types=1);

namespace App\Domain\Gamification\Strategies;

use App\Contracts\GamificationStrategyInterface;
use App\Enums\ModuleContext;
use App\Enums\MetricType;

/**
 * استراتژی محاسبه ضریب هم‌افزایی (Synergy Multiplier) بر اساس فعالیت در ماژول‌های مختلف
 */
class DailySynergyStrategy implements GamificationStrategyInterface
{
    public function calculate(object $user, ModuleContext $context, array $payload = []): float|int
    {
        $activeDomainsCount = int_value($payload['active_domains_count'] ?? 1);
        $yesterdayMultiplier = float_value($payload['yesterday_multiplier'] ?? 1.0);
        
        $activeDomainsCount = max(1, $activeDomainsCount);

        // 🛡️ FIX-X135 (راند 37): ضرایب هم‌افزایی قبلاً هاردکد بودند (۱.۱۰/۱.۲۵/۱.۴۰)
        // — نقض خواستهٔ «درصدها باید از پنل قابل تغییر باشند». اکنون از تنظیمات
        // پنل (تب امتیازها) خوانده می‌شوند؛ حذف رکورد = بازگشت به پیش‌فرض.
        $mult2 = float_value(setting('xp_synergy_mult_2', 1.10) ?: 1.10);
        $mult3 = float_value(setting('xp_synergy_mult_3', 1.25) ?: 1.25);
        $mult4 = float_value(setting('xp_synergy_mult_4', 1.40) ?: 1.40);

        // ضرایب بر اساس تعداد ماژول‌های فعال امروز کاربر
        $rawMultiplier = match($activeDomainsCount) {
            1 => 1.0,
            2 => $mult2,
            3 => $mult3,
            default => $mult4, // فعالین حرفه‌ای (چهار ماژول به بالا)
        };

        // 🛡️ FIX-X135: سقف رشد روزانهٔ ضریب هم‌افزایی — اکنون قابل تنظیم از پنل
        $capStep = float_value(setting('xp_synergy_daily_cap', 0.15) ?: 0.15);
        $capStep = max(0.0, $capStep);
        $maxAllowed = $yesterdayMultiplier + $capStep;
        
        return min($rawMultiplier, $maxAllowed);
    }

    public function getMetricType(): MetricType
    {
        return MetricType::XP;
    }
}
