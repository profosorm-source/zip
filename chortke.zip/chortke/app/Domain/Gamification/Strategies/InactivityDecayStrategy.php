<?php

declare(strict_types=1);

namespace App\Domain\Gamification\Strategies;

use App\Contracts\GamificationStrategyInterface;
use App\Enums\ModuleContext;
use App\Enums\MetricType;

/**
 * استراتژی محاسبه ریزش امتیاز (XP) به دلیل عدم فعالیت کاربر
 */
class InactivityDecayStrategy implements GamificationStrategyInterface
{
    public function calculate(object $user, ModuleContext $context, array $payload = []): float|int
    {
        $inactiveDays = int_value($payload['inactive_days'] ?? 0);
        $currentScore = float_value($payload['current_score'] ?? 0.0);
        $isVip = (bool)($payload['is_vip'] ?? false);

        // اگر کاربر فعال بوده یا امتیازی برای کسر ندارد
        if ($inactiveDays < 1 || $currentScore <= 0) {
            return 0.0;
        }

        // 🛡️ FIX-X136 (راند 37): درصدهای ریزش قبلاً هاردکد بودند — نقض خواستهٔ
        // «درصدها باید از پنل قابل تغییر باشند». اکنون از تنظیمات پنل (تب امتیازها)
        // خوانده می‌شوند؛ حذف رکورد = بازگشت به پیش‌فرض.
        $vipFirst = max(0.0, float_value(setting('xp_decay_vip_first_day', 0.50) ?: 0.50));
        $vipRest  = max(0.0, float_value(setting('xp_decay_vip_rest', 0.10) ?: 0.10));
        $d1 = max(0.0, float_value(setting('xp_decay_day1', 0.20) ?: 0.20));
        $d2 = max(0.0, float_value(setting('xp_decay_day2', 0.15) ?: 0.15));
        $d3 = max(0.0, float_value(setting('xp_decay_day3', 0.10) ?: 0.10));
        $dAfter = max(0.0, float_value(setting('xp_decay_after', 0.05) ?: 0.05));

        $decayPercent = 0.0;

        if ($isVip) {
            // قانون کاربران ویژه (پولی): روز اول ریزش سنگین، روزهای بعد ریزش ثابت
            $decayPercent = ($inactiveDays === 1) ? $vipFirst : $vipRest;
        } else {
            // قانون کاربران عادی: ریزش پلکانی نزولی
            $decayPercent = match($inactiveDays) {
                1 => $d1,
                2 => $d2,
                3 => $d3,
                default => $dAfter,
            };
        }

        // مقدار خروجی همیشه منفی است چون مربوط به ریزش (Decay) است
        return -($currentScore * $decayPercent);
    }

    public function getMetricType(): MetricType
    {
        return MetricType::XP;
    }
}
