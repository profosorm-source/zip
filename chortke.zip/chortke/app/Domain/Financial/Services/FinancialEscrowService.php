<?php

declare(strict_types=1);

namespace App\Domain\Financial\Services;

use App\Contracts\WalletServiceInterface;
use App\Models\User;
use App\Contracts\LoggerInterface;
use App\Contracts\AntiFraud\FraudGuardInterface;
use App\Services\EscrowService;
use App\Services\Settings\AppSettings;
use App\Services\SagaOrchestrator;
use Core\Database;
use App\Services\Shared\IdempotencyService;
use Core\ValueObjects\Money;

/**
 * FinancialEscrowService - Unified escrow management for all financial modules
 * 
 * Uses EscrowService as foundation + module-specific business logic
 * Modules: SocialTask (advertiser→executor), Influencer (buyer→seller), Vitrine (buyer→seller)
 */
class FinancialEscrowService
{
    private EscrowService $escrow;
    private User $userModel;
    private WalletServiceInterface $wallet;
    protected Database $db;
    private LoggerInterface $logger;
    private AppSettings $appSettings;
    private SagaOrchestrator $saga;
    private FraudGuardInterface $fraudGuard;
    private ?IdempotencyService $idempotencyService;

    public function __construct(
        EscrowService $escrow,
        User $userModel,
        WalletServiceInterface $wallet,
        AppSettings $appSettings,
        SagaOrchestrator $saga,
        Database $db,
        LoggerInterface $logger,
        FraudGuardInterface $fraudGuard,
        ?IdempotencyService $idempotencyService = null
    ) {
        $this->escrow = $escrow;
        $this->userModel = $userModel;
        $this->wallet = $wallet;
        $this->appSettings = $appSettings;
        $this->saga = $saga;
        $this->db = $db;
        $this->logger = $logger;
        $this->fraudGuard = $fraudGuard;
        $this->idempotencyService = $idempotencyService;
    }

    private function executeWithIdempotency(?string $key, int $userId, string $action, callable $logic, ?array $requestData = null): array
    {
        if ($key && $this->idempotencyService) {
            // از IdempotencyService::execute() استفاده می‌کنیم — نقطه مرکزی idempotency.
            // قرارداد عمومی FinancialEscrowService حفظ می‌شود: در صورت خطا ['ok'=>false] برمی‌گردد.
            try {
                return (array)$this->idempotencyService->execute($action, $userId, $requestData ?? [], $logic, $key);
            } catch (\Throwable $e) {
                $this->logger->error('financial_escrow.operation_failed', ['action' => $action, 'error' => $e->getMessage()]);
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }

        // Fallback when idempotency service isn't available
        try {
            $result = $logic();
            return is_array($result) ? $result : ['ok' => (bool)$result];
        } catch (\Throwable $e) {
            $this->logger->error('financial_escrow.operation_failed', ['error' => $e->getMessage()]);
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * درخواست نگهداری پول از تبلیغ‌دهنده برای اجرا
     * Flow: Executor submits → Escrow holds → Admin approves → Funds released
     */
    public function holdSocialTaskFunds(
        int    $executionId,
        int    $executorId,
        int    $advertiserId,
        string $reward,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['execution_id' => $executionId, 'executor_id' => $executorId, 'advertiser_id' => $advertiserId, 'amount' => $reward];
        return $this->executeWithIdempotency($idempotencyKey, $advertiserId, "hold_social_task_{$executionId}", function() use ($executionId, $executorId, $advertiserId, $reward, $payload) {
        try {
            // BUGFIX-SAGA-TX-ROOT: کامنت قدیمی می‌گفت beginTransaction عمداً حذف شده
            // تا Saga «توزیع‌شده‌ی واقعی» باشد، اما مکانیزم جبران (compensate) این
            // پروژه از Closure استفاده می‌کند که — طبق کد خودِ SagaRecoveryWorker —
            // اصلاً قابل بازیابی از دیتابیس نیست، و آن Worker هم هرگز در
            // Console\Kernel زمان‌بندی نشده. یعنی جبران واقعی فقط همان لحظه (in-process)
            // ممکن است و اگر بین دو Step کرش رخ دهد، وضعیت ناقص برای همیشه باقی می‌ماند.
            // راه‌حل: کل Saga داخل یک Transaction Root اجرا می‌شود (با پشتیبانی
            // SAVEPOINT از Core\Database برای سازگاری با تراکنش‌های بیرونی موجود
            // مثل DisputeCommandService::adminResolve).
            $result = $this->db->transactional(function () use ($executionId, $executorId, $advertiserId, $reward, $payload) {
            return $this->saga
                ->setSaga('hold_social_task_escrow', $payload)
                ->addStep(
                    'verify_and_lock_balance',
                    function () use ($advertiserId, $reward) {
                        $this->db->query("SELECT id FROM wallets WHERE user_id = ? FOR UPDATE", [(int)$advertiserId])->fetch();
                        $advertiserBalance = $this->wallet->getBalanceForUpdate($advertiserId, 'irt');

                        $advertiserMoney = Money::fromString($advertiserBalance, 'irt');
                        $rewardMoney = Money::fromString($reward, 'irt');

                        if ($rewardMoney->isGreaterThan($advertiserMoney)) {
                            throw new \Core\Exceptions\InsufficientBalanceException('موجودی کیف پول تبلیغ‌دهنده کافی نیست');
                        }
                        return true;
                    },
                    function () {
                        // هیچ نیازی به جبران برای مرحله فقط‌خواندنی/قفل‌گذاری نیست
                    }
                )
                ->addStep(
                    'create_escrow_record',
                    function () use ($executionId, $executorId, $advertiserId, $reward) {
                        $result = $this->escrow->holdFunds(
                            $executionId,
                            'social_task_execution',
                            $executorId,
                            $advertiserId,
                            $reward,
                            'IRT'
                        );
                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException('خطا در ایجاد صندوق امانات: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        return $result['escrow_id'];
                    },
                    function ($error) use ($executionId, $advertiserId) {
                        // Compensation: refund funds if escrow was partially created
                        $this->logger->warning('saga_compensate: cancelling escrow record', ['execution_id' => $executionId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'cancelled' WHERE order_id = ? AND order_type = ? AND status = 'pending'")
                                 ->execute([$executionId, 'social_task_execution']);
                    }
                )
                ->addStep(
                    'deduct_wallet_balance',
                    function ($escrowId) use ($executionId, $advertiserId, $reward) {
                        $this->assertFraudAllowed((int)$advertiserId, 'escrow.hold', []);
                        $this->wallet->withdraw($advertiserId, $reward, 'irt', [
                            'type' => 'social_task_escrow',
                            'execution_id' => $executionId,
                            'ref_id' => $executionId,
                            'ref_type' => 'social_task_execution'
                        ]);
                        return $escrowId;
                    },
                    function ($error) use ($executionId, $advertiserId, $reward) {
                        // Compensation: deposit funds back to wallet if deduction partially failed
                        $this->logger->warning('saga_compensate: reverting wallet deduction', ['advertiser_id' => $advertiserId]);
                        $this->wallet->deposit($advertiserId, $reward, 'irt', [
                            'type' => 'saga_compensation',
                            'execution_id' => $executionId
                        ]);
                    }
                )
                ->execute(); // اجرای تمام مراحل پشت سر هم
            });

            $this->logger->info('social_task.escrow_hold', [
                'execution_id' => $executionId,
                'executor_id' => $executorId,
                'adS_id' => $advertiserId,
                'amount' => $reward,
            ]);

            return ['ok' => true, 'escrow_id' => $result];

        } catch (\Throwable $e) {
            $this->logger->error('social_task.escrow_hold.failed', ['error' => $e->getMessage()]);
            return ['ok' => false, 'error' => $e->getMessage()];
        }
        }, $payload);
    }

    /**
     * تایید و نگهداری مالی برای SocialTask
     * Admin approves execution → Move to in_escrow
     */
    public function confirmSocialTaskEscrow(int $executionId, int $adviserId, ?string $idempotencyKey = null): array
    {
        $payload = ['execution_id' => $executionId, 'adviser_id' => $adviserId];
        return $this->executeWithIdempotency($idempotencyKey, $adviserId, "confirm_social_task_{$executionId}", function() use ($executionId, $adviserId, $payload) {
        try {
            // BUGFIX-SAGA-TX-ROOT + BUGFIX-SAGA-STALE-STEPS:
            // ۱) کل Saga داخل Transaction Root اجرا می‌شود (رجوع به توضیح holdSocialTaskFunds).
            // ۲) این متد قبلاً به‌جای setSaga()، مستقیم addStep() صدا می‌زد. چون
            //    SagaOrchestrator::execute() هرگز $this->steps را ریست نمی‌کند، اگر همین
            //    instance قبلاً برای Saga دیگری استفاده شده باشد، مراحلِ قدیمی هم دوباره
            //    اجرا می‌شدند (تأیید شده با تست). افزودن setSaga() این نشتِ state را می‌بندد.
            $result = $this->db->transactional(function () use ($executionId, $adviserId, $payload) {
                $stepResult = null;
                $this->saga
                    ->setSaga('confirm_social_task_escrow', $payload)
                    ->addStep(
                        'confirm_escrow_hold',
                        function () use ($executionId, $adviserId, &$stepResult) {
                            $stepResult = $this->escrow->confirmHold($executionId, 'social_task_execution', $adviserId);
                            if (!$stepResult['ok']) {
                                throw new \Core\Exceptions\ApplicationException($stepResult['error'] ?? 'خطا در تأیید صندوق امانات');
                            }
                            return true;
                        },
                        function () {}
                    )->execute();
                return $stepResult;
            });

            return $result;
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
        }, $payload);
    }

    /**
     * تحویل پول به executor
     * Admin releases → Transfer to executor wallet
     */
    public function releaseSocialTaskFunds(
        int    $executionId,
        int    $executorId,
        int    $advertiserId,
        string $amount,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['execution_id' => $executionId, 'executor_id' => $executorId, 'advertiser_id' => $advertiserId, 'amount' => $amount];
        return $this->executeWithIdempotency($idempotencyKey, $executorId, "release_social_task_{$executionId}", function() use ($executionId, $executorId, $advertiserId, $amount, $payload) {
        try {
            // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
            $this->db->transactional(function () use ($executionId, $executorId, $advertiserId, $amount, $payload) {
            return $this->saga
                ->setSaga('release_social_task_escrow', $payload)
                ->addStep(
                    'verify_and_lock_escrow',
                    function () use ($executionId) {
                        // ✅ Lock the escrow row FOR UPDATE to resolve HIGH-NEW-02 double release race condition
                        $escrow = $this->db->query("
                            SELECT * FROM escrow_transactions 
                            WHERE order_id = ? AND order_type = ? 
                            FOR UPDATE
                        ", [$executionId, 'social_task_execution'])->fetch(\PDO::FETCH_OBJ);

                        if (!$escrow || $escrow->status !== 'in_escrow') {
                            throw new \Core\Exceptions\InvalidStateException('صندوق امانات در وضعیت مناسب نیست');
                        }
                        return $escrow->id;
                    },
                    function () {
                        // No compensation needed
                    }
                )
                ->addStep(
                    'release_escrow_funds',
                    function ($escrowId) use ($executorId) {
                        // ✅ Release via core escrow service
                        $result = $this->escrow->releaseFunds($escrowId, $executorId, 'admin_release');
                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException('خطا در آزادسازی وجه امانی: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        return true;
                    },
                    function ($error) use ($executionId) {
                        $this->logger->warning('saga_compensate: reverting escrow release', ['execution_id' => $executionId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'in_escrow', released_at = NULL, released_by = NULL WHERE order_id = ? AND order_type = ? AND status = 'released'")
                                 ->execute([$executionId, 'social_task_execution']);
                    }
                )
                ->addStep(
                    'deposit_wallet_balance',
                    function () use ($executorId, $amount, $executionId) {
                        // ✅ Transfer to executor wallet - calling deposit since we are inside a database transaction
                        $this->wallet->deposit($executorId, $amount, 'irt', [
                            'type' => 'social_task_reward',
                            'execution_id' => $executionId
                        ]);
                        return true;
                    },
                    function ($error) use ($executorId, $amount, $executionId) {
                        $this->logger->warning('saga_compensate: reverting wallet deposit', ['executor_id' => $executorId]);
                        $this->assertFraudAllowed((int)$executorId, 'escrow.release', []);
                        $this->wallet->withdraw($executorId, $amount, 'irt', [
                            'type' => 'saga_compensation',
                            'execution_id' => $executionId
                        ]);
                    }
                )
                ->execute();
            });

            $this->logger->info('social_task.escrow_released', [
                'execution_id' => $executionId,
                'executor_id' => $executorId,
                'amount' => $amount,
            ]);

            return ['ok' => true, 'wallet_transaction' => 'completed'];

        } catch (\Throwable $e) {
            $this->logger->error('social_task.escrow_release.failed', ['error' => $e->getMessage()]);
            return ['ok' => false, 'error' => $e->getMessage()];
        }
        }, $payload);
    }

    /**
     * بازگرداندی پول به تبلیغ‌دهنده (رد شدن، dispute)
     */
    public function refundSocialTaskFunds(
        int    $executionId,
        int    $advertiserId,
        string $reason,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['execution_id' => $executionId, 'advertiser_id' => $advertiserId, 'reason' => $reason];
        return $this->executeWithIdempotency($idempotencyKey, $advertiserId, "refund_social_task_{$executionId}", function() use ($executionId, $advertiserId, $reason, $payload) {
        try {
            // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
            $result = $this->db->transactional(function () use ($executionId, $advertiserId, $reason, $payload) {
            return $this->saga
                ->setSaga('refund_social_task_escrow', $payload)
                ->addStep(
                    'verify_and_lock_escrow_refund',
                    function () use ($executionId) {
                        // ✅ Lock the escrow row FOR UPDATE to prevent concurrent refund/release races
                        $escrow = $this->db->query("
                            SELECT * FROM escrow_transactions 
                            WHERE order_id = ? AND order_type = ? 
                            FOR UPDATE
                        ", [$executionId, 'social_task_execution'])->fetch(\PDO::FETCH_OBJ);

                        if (!$escrow) {
                            throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                        }
                        return $escrow;
                    },
                    function () {
                        // No compensation needed
                    }
                )
                ->addStep(
                    'refund_escrow_funds',
                    function ($escrow) use ($reason) {
                        // ✅ Refund via core service
                        $result = $this->escrow->refundFunds(
                            $escrow->id,
                            $escrow->buyer_id,
                            $reason,
                            'admin_refund'
                        );

                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException('خطا در بازگشت وجه امانی: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        return clone $escrow; // pass to next step
                    },
                    function ($error) use ($executionId) {
                        $this->logger->warning('saga_compensate: reverting escrow refund', ['execution_id' => $executionId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'in_escrow' WHERE order_id = ? AND order_type = ? AND status = 'refunded'")
                                 ->execute([$executionId, 'social_task_execution']);
                    }
                )
                ->addStep(
                    'deposit_refund_balance',
                    function ($escrow) use ($advertiserId, $executionId) {
                        // ✅ Return to advertiser wallet - calling deposit since we are inside a database transaction
                        $this->wallet->deposit(
                            $advertiserId,
                            $escrow->amount,
                            'irt',
                            [
                                'type' => 'social_task_refund',
                                'execution_id' => $executionId
                            ]
                        );
                        return $escrow->amount;
                    },
                    function ($error) use ($advertiserId, $executionId) {
                        $this->logger->warning('saga_compensate: reverting wallet refund deposit', ['advertiser_id' => $advertiserId]);
                        // We must fetch the amount to reverse it, or we can assume it was passed if we restructure the closure.
                        // Since we just need compensation logic, we withdraw what was just deposited.
                        $escrow = $this->escrow->getByOrder($executionId, 'social_task_execution');
                        if ($escrow) {
                            $this->assertFraudAllowed((int)$advertiserId, 'escrow.refund', []);
                            $this->wallet->withdraw($advertiserId, $escrow->amount, 'irt', [
                                'type' => 'saga_compensation',
                                'execution_id' => $executionId
                            ]);
                        }
                    }
                )
                ->execute();
            });

            $this->logger->info('social_task.escrow_refunded', [
                'execution_id' => $executionId,
                'amount' => $result,
                'reason' => $reason,
            ]);

            return ['ok' => true, 'refund_amount' => $result];

        } catch (\Throwable $e) {
            $this->logger->error('social_task.escrow_refund.failed', ['error' => $e->getMessage()]);
            return ['ok' => false, 'error' => $e->getMessage()];
        }
        }, $payload);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Influencer Escrow (Buyer → Seller Payment)
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * نگهداری پول برای سفارش اینفلوئنسر
     */
    public function holdInfluencerOrderFunds(
        int    $orderId,
        int    $buyerId,
        int    $sellerId,
        string $amount,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['order_id' => $orderId, 'buyer_id' => $buyerId, 'seller_id' => $sellerId, 'amount' => $amount];
        return $this->executeWithIdempotency($idempotencyKey, $buyerId, "hold_influencer_order_{$orderId}", function() use ($orderId, $buyerId, $sellerId, $amount, $payload) {
            // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
            $result = $this->db->transactional(function () use ($orderId, $buyerId, $sellerId, $amount, $payload) {
            return $this->saga
                ->setSaga('hold_influencer_order_escrow', $payload)
                ->addStep(
                    'verify_and_lock_buyer_balance',
                    function () use ($buyerId, $amount) {
                        // 🔒 Pessimistically lock the wallet row to prevent TOCTOU race conditions (BUG-02)
                        $this->db->query("SELECT id FROM wallets WHERE user_id = ? FOR UPDATE", [(int)$buyerId])->fetch();

                        // ✅ Verify buyer balance
                        $buyerBalance = $this->wallet->getBalanceForUpdate($buyerId, 'irt');

                        $buyerMoney = Money::fromString($buyerBalance, 'irt');
                        $amountMoney = Money::fromString($amount, 'irt');

                        if ($amountMoney->isGreaterThan($buyerMoney)) {
                            throw new \Core\Exceptions\InsufficientBalanceException('موجودی کیف پول خریدار کافی نیست');
                        }
                        return true;
                    },
                    function () {}
                )
                ->addStep(
                    'create_escrow_record',
                    function () use ($orderId, $buyerId, $sellerId, $amount) {
                        // ✅ Hold in escrow
                        $result = $this->escrow->holdFunds(
                            $orderId,
                            'influencer_order',
                            $buyerId,
                            $sellerId,
                            $amount,
                            'IRT'
                        );

                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException('خطا در ایجاد صندوق امانات: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        return $result['escrow_id'];
                    },
                    function ($error) use ($orderId) {
                        $this->logger->warning('saga_compensate: cancelling influencer escrow record', ['order_id' => $orderId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'cancelled' WHERE order_id = ? AND order_type = ? AND status = 'pending'")
                                 ->execute([$orderId, 'influencer_order']);
                    }
                )
                ->addStep(
                    'deduct_wallet_balance',
                    function ($escrowId) use ($buyerId, $amount, $orderId) {
                        // ✅ Deduct from buyer wallet - calling withdraw since we are inside a database transaction
                        $this->assertFraudAllowed((int)$buyerId, 'escrow.hold', []);
                        $this->wallet->withdraw($buyerId, $amount, 'irt', [
                            'type' => 'influencer_escrow',
                            'order_id' => $orderId,
                            'ref_id' => $orderId,
                            'ref_type' => 'influencer_order'
                        ]);
                        return $escrowId;
                    },
                    function ($error) use ($buyerId, $amount, $orderId) {
                        $this->logger->warning('saga_compensate: reverting wallet deduction', ['buyer_id' => $buyerId]);
                        $this->wallet->deposit($buyerId, $amount, 'irt', [
                            'type' => 'saga_compensation',
                            'order_id' => $orderId
                        ]);
                    }
                )
                ->execute();
            });

            $escrow = $this->escrow->getByOrder($orderId, 'influencer_order');
            return ['ok' => true, 'escrow_id' => (int)($escrow->id ?? $result)];
        }, $payload);
    }

    /**
     * تأیید نگهداری امن سفارش اینفلوئنسر پس از برداشت موفق از کیف پول خریدار.
     * وضعیت escrow از pending به in_escrow می‌رود تا فقط از مسیرهای release/refund حل شود.
     */
    public function confirmInfluencerOrderFunds(int $orderId, int $sellerId, ?string $idempotencyKey = null): array
    {
        $payload = ['order_id' => $orderId, 'seller_id' => $sellerId];
        return $this->executeWithIdempotency($idempotencyKey, $sellerId, "confirm_influencer_order_{$orderId}", function() use ($orderId, $sellerId) {
            $result = $this->escrow->confirmHold($orderId, 'influencer_order', $sellerId);
            if (!empty($result['ok'])) {
                return $result;
            }

            $escrow = $this->escrow->getByOrder($orderId, 'influencer_order');
            if ($escrow && in_array((string)$escrow->status, ['in_escrow', 'released', 'refunded', 'disputed'], true)) {
                return ['ok' => true, 'escrow_id' => (int)$escrow->id, 'already_confirmed' => true];
            }

            return ['ok' => false, 'error' => $result['error'] ?? 'Escrow confirm failed'];
        }, $payload);
    }

    /**
     * تحویل پول به فروشنده (اینفلوئنسر).
     *
     * نکته مالی مهم: مبلغ نگهداری‌شده در escrow برابر قیمت کامل سفارش است،
     * اما مبلغ واریزی به اینفلوئنسر بعد از کسر سهم سایت است. بنابراین هنگام
     * complete، hold کامل خریدار settle می‌شود و فقط sellerAmount به فروشنده واریز می‌شود.
     */
    public function releaseInfluencerOrderFunds(int $orderId, int $sellerId, string $sellerAmount, ?string $idempotencyKey = null): array
    {
        $payload = ['order_id' => $orderId, 'seller_id' => $sellerId, 'seller_amount' => $sellerAmount];
        return $this->executeWithIdempotency($idempotencyKey, $sellerId, "release_influencer_order_{$orderId}", function() use ($orderId, $sellerId, $sellerAmount, $payload) {
            try {
                // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
                $depositResult = null;
                $this->db->transactional(function () use ($orderId, $sellerId, $sellerAmount, $payload, &$depositResult) {
                return $this->saga
                ->setSaga('release_influencer_order_escrow', $payload)
                ->addStep(
                    'verify_and_lock_escrow',
                    function () use ($orderId, $sellerId) {
                        $escrow = $this->db->query(
                            "SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = ? FOR UPDATE",
                            [$orderId, 'influencer_order']
                        )->fetch(\PDO::FETCH_OBJ);

                        if (!$escrow) {
                            throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                        }
                        if ((int)$escrow->seller_id !== $sellerId) {
                            throw new \Core\Exceptions\SecurityException('عدم تطابق فروشنده با صندوق امانات');
                        }
                        if (!in_array((string)$escrow->status, ['in_escrow', 'pending'], true)) {
                            if ((string)$escrow->status === 'released') {
                                return ['escrow_id' => (int)$escrow->id, 'already_released' => true, 'escrow' => $escrow];
                            }
                            throw new \Core\Exceptions\InvalidStateException('وضعیت صندوق امانات نامعتبر است');
                        }
                        return ['escrow_id' => (int)$escrow->id, 'already_released' => false, 'escrow' => $escrow];
                    },
                    function () {}
                )
                ->addStep(
                    'release_escrow_funds',
                    function (array $ctx) use ($sellerId) {
                        if (!empty($ctx['already_released'])) {
                            return $ctx;
                        }
                        $result = $this->escrow->releaseFunds((int)$ctx['escrow_id'], $sellerId, 'influencer_order_complete');
                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException('خطا در آزادسازی وجه امانی: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        return $ctx;
                    },
                    function ($error) use ($orderId) {
                        $this->logger->warning('saga_compensate: reverting influencer escrow release', ['order_id' => $orderId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'in_escrow', released_at = NULL, released_by = NULL WHERE order_id = ? AND order_type = ? AND status = 'released'")
                                 ->execute([$orderId, 'influencer_order']);
                    }
                )
                ->addStep(
                    'settle_buyer_hold_and_deposit_seller',
                    function (array $ctx) use ($sellerId, $sellerAmount, $orderId, &$depositResult) {
                        if (!empty($ctx['already_released'])) {
                            return true;
                        }
                        $escrow = $this->escrow->getByOrder($orderId, 'influencer_order');
                        if (!$escrow) {
                            throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                        }

                        // Complete the full buyer hold (full order price), not the seller share.
                        $this->settleEscrowHold($escrow, 'complete', (string)$escrow->amount);

                        if (bccomp((string)$sellerAmount, '0', 8) > 0) {
                            $depositResult = $this->wallet->deposit($sellerId, (string)$sellerAmount, strtolower((string)$escrow->currency), [
                                'type' => 'influencer_order_payment',
                                'description' => "درآمد سفارش اینفلوئنسر #{$orderId}",
                                'order_id' => $orderId,
                                'ref_id' => $orderId,
                                'ref_type' => 'influencer_order',
                                'idempotency_key' => "story_payout_{$orderId}",
                            ]);
                            if (empty($depositResult['success'])) {
                                throw new \Core\Exceptions\ApplicationException($depositResult['message'] ?? 'خطا در واریز به کیف پول فروشنده');
                            }
                        }
                        return true;
                    },
                    function ($error) use ($sellerId, $sellerAmount, $orderId) {
                        $this->logger->warning('saga_compensate: influencer seller deposit compensation requested', ['seller_id' => $sellerId, 'order_id' => $orderId]);
                    }
                )
                ->execute();
                });

                return ['ok' => true, 'transaction_id' => $depositResult['transaction_id'] ?? null];

            } catch (\Throwable $e) {
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    /**
     * بازگشت کامل مبلغ سفارش اینفلوئنسر به خریدار از escrow.
     */
    public function refundInfluencerOrderFunds(int $orderId, int $buyerId, string $reason, ?string $idempotencyKey = null): array
    {
        $payload = ['order_id' => $orderId, 'buyer_id' => $buyerId, 'reason' => $reason];
        return $this->executeWithIdempotency($idempotencyKey, $buyerId, "refund_influencer_order_{$orderId}", function() use ($orderId, $buyerId, $reason) {
            try {
                // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
                $refundAmount = null;
                $this->db->transactional(function () use ($orderId, $buyerId, $reason, &$refundAmount) {
                return $this->saga
                    ->setSaga('refund_influencer_order_escrow', ['order_id' => $orderId, 'buyer_id' => $buyerId])
                    ->addStep(
                        'verify_and_refund_escrow',
                        function () use ($orderId, $buyerId, $reason) {
                            $escrow = $this->escrow->getByOrder($orderId, 'influencer_order');
                            if (!$escrow) {
                                throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                            }
                            if ((int)$escrow->buyer_id !== $buyerId) {
                                throw new \Core\Exceptions\SecurityException('عدم تطابق خریدار با صندوق امانات');
                            }
                            if ((string)$escrow->status === 'refunded') {
                                return ['escrow_id' => (int)$escrow->id, 'amount' => (string)$escrow->amount, 'already_refunded' => true];
                            }
                            if (!in_array((string)$escrow->status, ['pending', 'in_escrow', 'disputed'], true)) {
                                throw new \Core\Exceptions\InvalidStateException('در وضعیت فعلی امکان بازگشت وجه وجود ندارد');
                            }

                            $result = $this->escrow->refundFunds((int)$escrow->id, $buyerId, $reason, 'influencer_order_refund');
                            if (!$result['ok']) {
                                throw new \Core\Exceptions\ApplicationException('خطا در بازگشت وجه امانی: ' . ($result['error'] ?? 'خطای نامشخص'));
                            }
                            return ['escrow_id' => (int)$escrow->id, 'amount' => (string)$escrow->amount, 'already_refunded' => false];
                        },
                        function ($error) use ($orderId) {
                            $this->logger->warning('saga_compensate: reverting influencer escrow refund', ['order_id' => $orderId]);
                            $this->db->prepare("UPDATE escrow_transactions SET status = 'in_escrow', refunded_at = NULL, refunded_by = NULL, refund_reason = NULL WHERE order_id = ? AND order_type = ? AND status = 'refunded'")
                                ->execute([$orderId, 'influencer_order']);
                        }
                    )
                    ->addStep(
                        'cancel_buyer_hold',
                        function (array $ctx) use ($orderId, &$refundAmount) {
                            $refundAmount = (string)$ctx['amount'];
                            if (!empty($ctx['already_refunded'])) {
                                return true;
                            }
                            $escrow = $this->escrow->getByOrder($orderId, 'influencer_order');
                            if (!$escrow) {
                                throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                            }
                            $this->settleEscrowHold($escrow, 'cancel', (string)$ctx['amount']);
                            return true;
                        },
                        function ($error) use ($orderId) {
                            $this->logger->warning('saga_compensate: influencer refund wallet hold cancel failed', ['order_id' => $orderId]);
                        }
                    )
                    ->execute();
                });

                return ['ok' => true, 'refund_amount' => $refundAmount];
            } catch (\Throwable $e) {
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Vitrine Escrow (Buyer → Seller Payment)
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * نگهداری پول برای آگهی ویترین
     */
    public function holdVitrineFunds(
        int    $listingId,
        int    $buyerId,
        int    $sellerId,
        string $amount,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['listing_id' => $listingId, 'buyer_id' => $buyerId, 'seller_id' => $sellerId, 'amount' => $amount];
        return $this->executeWithIdempotency($idempotencyKey, $buyerId, "hold_vitrine_{$listingId}", function() use ($listingId, $buyerId, $sellerId, $amount, $payload) {
            // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
            $result = $this->db->transactional(function () use ($listingId, $buyerId, $sellerId, $amount, $payload) {
            return $this->saga
                ->setSaga('hold_vitrine_escrow', $payload)
                ->addStep(
                    'verify_and_lock_buyer_balance',
                    function () use ($buyerId, $amount) {
                        // 🔒 Pessimistically lock the wallet row to prevent TOCTOU race conditions (BUG-02)
                        $this->db->query("SELECT id FROM wallets WHERE user_id = ? FOR UPDATE", [(int)$buyerId])->fetch();

                        // ✅ Verify buyer
                        $buyerBalance = $this->wallet->getBalanceForUpdate($buyerId, 'usdt');

                        $buyerMoney = Money::fromString($buyerBalance, 'usdt');
                        $amountMoney = Money::fromString($amount, 'usdt');

                        if ($amountMoney->isGreaterThan($buyerMoney)) {
                            throw new \Core\Exceptions\InsufficientBalanceException('موجودی حساب کافی نیست');
                        }
                        return true;
                    },
                    function () {}
                )
                ->addStep(
                    'create_escrow_record',
                    function () use ($listingId, $buyerId, $sellerId, $amount) {
                        // ✅ Hold escrow
                        $result = $this->escrow->holdFunds(
                            $listingId,
                            'vitrine_listing',
                            $buyerId,
                            $sellerId,
                            $amount,
                            'USDT'
                        );

                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException('خطا در ایجاد صندوق امانات: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        return $result['escrow_id'];
                    },
                    function ($error) use ($listingId) {
                        $this->logger->warning('saga_compensate: cancelling vitrine escrow record', ['listing_id' => $listingId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'cancelled' WHERE order_id = ? AND order_type = ? AND status = 'pending'")
                                 ->execute([$listingId, 'vitrine_listing']);
                    }
                )
                ->addStep(
                    'deduct_wallet_balance',
                    function ($escrowId) use ($buyerId, $amount, $listingId) {
                        // ✅ Deduct from buyer - calling withdraw since we are inside a database transaction
                        $this->assertFraudAllowed((int)$buyerId, 'escrow.hold', []);
                        $this->wallet->withdraw($buyerId, $amount, 'usdt', [
                            'type' => 'vitrine_escrow',
                            'listing_id' => $listingId,
                            'ref_id' => $listingId,
                            'ref_type' => 'vitrine_listing'
                        ]);
                        return $escrowId;
                    },
                    function ($error) use ($buyerId, $amount, $listingId) {
                        $this->logger->warning('saga_compensate: reverting wallet deduction', ['buyer_id' => $buyerId]);
                        $this->wallet->deposit($buyerId, $amount, 'usdt', [
                            'type' => 'saga_compensation',
                            'listing_id' => $listingId
                        ]);
                    }
                )
                ->execute();
            });

            return ['ok' => true, 'escrow_id' => $result];
        }, $payload);
    }

    /**
     * تحویل پول به فروشنده (ویترین)
     */
    public function releaseVitrineFunds(int $listingId, int $sellerId, string $amount, ?string $idempotencyKey = null): array
    {
        $payload = ['listing_id' => $listingId, 'seller_id' => $sellerId, 'amount' => $amount];
        return $this->executeWithIdempotency($idempotencyKey, $sellerId, "release_vitrine_{$listingId}", function() use ($listingId, $sellerId, $amount, $payload) {
            try {
            // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
                $result = $this->db->transactional(function () use ($listingId, $sellerId, $amount, $payload) {
                return $this->saga
                ->setSaga('release_vitrine_escrow', $payload)
                ->addStep(
                    'verify_and_lock_escrow',
                    function () use ($listingId) {
                        $escrow = $this->db->query(
                            "SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = ? FOR UPDATE",
                            [$listingId, 'vitrine_listing']
                        )->fetch(\PDO::FETCH_OBJ);

                        if (!$escrow || $escrow->status !== 'in_escrow') {
                            throw new \Core\Exceptions\InvalidStateException('وضعیت صندوق امانات نامعتبر است');
                        }
                        return ['escrow_id' => (int)$escrow->id];
                    },
                    function () {}
                )
                ->addStep(
                    'release_escrow_funds',
                    function (array $ctx) use ($sellerId) {
                        // ✅ Release
                        $result = $this->escrow->releaseFunds((int)$ctx['escrow_id'], $sellerId, 'vitrine_sale_complete');
                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException('خطا در آزادسازی وجه امانی: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        return true;
                    },
                    function ($error) use ($listingId) {
                        $this->logger->warning('saga_compensate: reverting escrow release', ['listing_id' => $listingId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'in_escrow', released_at = NULL, released_by = NULL WHERE order_id = ? AND order_type = ? AND status = 'released'")
                                 ->execute([$listingId, 'vitrine_listing']);
                    }
                )
                ->addStep(
                    'deposit_seller_balance',
                    function () use ($sellerId, $amount, $listingId) {
                        $escrow = $this->escrow->getByOrder($listingId, 'vitrine_listing');
                        if (!$escrow) {
                            throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                        }
                        $this->settleEscrowHold($escrow, 'complete', $amount);

                        // ✅ Calculate commission & transfer net
                        // BUGFIX: قبلاً درصد کمیسیون 5% به‌صورت هاردکد بود و با تنظیم
                        // داینامیک ادمین (vitrine_commission_percent) که در مسیر واقعی
                        // ReleaseVitrineFundsJob/VitrineSettingsService استفاده می‌شود
                        // ناهماهنگ بود. این‌جا هم اکنون همان کلید تنظیمات خوانده می‌شود.
                        $commissionPercent = (string)$this->appSettings->get('vitrine_commission_percent', '5');
                        $amountMoney = Money::fromString($amount, 'usdt');
                        $commissionMoney = $amountMoney->percentage($commissionPercent);
                        $netAmountMoney = $amountMoney->subtract($commissionMoney);

                        $this->wallet->deposit($sellerId, $netAmountMoney->getAmount(), 'usdt', [
                            'type' => 'vitrine_sale',
                            'listing_id' => $listingId
                        ]);
                        return ['net_amount' => $netAmountMoney->getAmount(), 'commission' => $commissionMoney->getAmount()];
                    },
                    function ($error) use ($sellerId, $amount, $listingId) {
                        $this->logger->warning('saga_compensate: reverting seller wallet deposit', ['seller_id' => $sellerId]);
                        // Commission logic needs to be reversed
                        $commissionPercent = (string)$this->appSettings->get('vitrine_commission_percent', '5');
                        $amountMoney = Money::fromString($amount, 'usdt');
                        $commissionMoney = $amountMoney->percentage($commissionPercent);
                        $netAmountMoney = $amountMoney->subtract($commissionMoney);

                        $this->assertFraudAllowed((int)$sellerId, 'escrow.release', []);
                        $this->wallet->withdraw($sellerId, $netAmountMoney->getAmount(), 'usdt', [
                            'type' => 'saga_compensation',
                            'listing_id' => $listingId
                        ]);
                    }
                )
                ->execute();
                });

            return ['ok' => true, 'net_amount' => $result['net_amount'], 'commission' => $result['commission']];

        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
        }, $payload);
    }

    /**
     * بازگرداندی پول به خریدار (ویترین)
     */
    public function refundVitrineFunds(
        int    $listingId,
        int    $buyerId,
        string $reason,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['listing_id' => $listingId, 'buyer_id' => $buyerId, 'reason' => $reason];
        return $this->executeWithIdempotency($idempotencyKey, $buyerId, "refund_vitrine_{$listingId}", function() use ($listingId, $buyerId, $reason, $payload) {
        try {
            // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
            $result = $this->db->transactional(function () use ($listingId, $buyerId, $reason, $payload) {
            return $this->saga
                ->setSaga('refund_vitrine_escrow', $payload)
                ->addStep(
                    'verify_and_lock_escrow_refund',
                    function () use ($listingId) {
                        $escrow = $this->escrow->getByOrder($listingId, 'vitrine_listing');
                        if (!$escrow) {
                            throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                        }
                        return ['escrow_id' => (int)$escrow->id, 'escrow_amount' => (string)$escrow->amount];
                    },
                    function () {}
                )
                ->addStep(
                    'refund_escrow_funds',
                    function (array $ctx) use ($buyerId, $reason) {
                        // ✅ Refund
                        $result = $this->escrow->refundFunds(
                            (int)$ctx['escrow_id'],
                            $buyerId,
                            $reason,
                            'vitrine_refund'
                        );

                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException('خطا در بازگشت وجه امانی: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        return ['refund_amount' => (string)$ctx['escrow_amount']];
                    },
                    function ($error) use ($listingId) {
                        $this->logger->warning('saga_compensate: reverting escrow refund', ['listing_id' => $listingId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'in_escrow' WHERE order_id = ? AND order_type = ? AND status = 'refunded'")
                                 ->execute([$listingId, 'vitrine_listing']);
                    }
                )
                ->addStep(
                    'deposit_refund_balance',
                    function (array $ctx) use ($buyerId, $listingId) {
                        $escrow = $this->escrow->getByOrder($listingId, 'vitrine_listing');
                        if (!$escrow) {
                            throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                        }
                        $this->settleEscrowHold($escrow, 'cancel', (string)$ctx['refund_amount']);
                        return ['refund_amount' => (string)$ctx['refund_amount']];
                    },
                    function ($error) use ($buyerId, $listingId) {
                        $this->logger->warning('saga_compensate: reverting buyer wallet deposit', ['buyer_id' => $buyerId]);
                        $escrow = $this->escrow->getByOrder($listingId, 'vitrine_listing');
                        if ($escrow) {
                            $this->assertFraudAllowed((int)$buyerId, 'escrow.refund', []);
                            $this->wallet->withdraw($buyerId, $escrow->amount, 'usdt', [
                                'type' => 'saga_compensation',
                                'listing_id' => $listingId
                            ]);
                        }
                    }
                )
                ->execute();
            });

            return ['ok' => true, 'refund_amount' => $result];

        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
        }, $payload);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Common Dispute Handling
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Mark escrow as disputed (freezes funds)
     */
    public function markEscrowDisputed(int $orderId, string $orderType, string $reason, ?string $idempotencyKey = null): array
    {
        $payload = ['order_id' => $orderId, 'order_type' => $orderType, 'reason' => $reason];
        $escrowForUser = $this->escrow->getByOrder($orderId, $orderType);
        $idempotencyUserId = (int)($escrowForUser->buyer_id ?? 1);
        return $this->executeWithIdempotency($idempotencyKey, $idempotencyUserId, "mark_disputed_{$orderType}_{$orderId}", function() use ($orderId, $orderType, $reason, $payload) {
            try {
                // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
                $result = $this->db->transactional(function () use ($orderId, $orderType, $reason, $payload) {
                    $stepResult = null;
                    $this->saga->setSaga('mark_escrow_disputed', $payload)->addStep(
                        'mark_escrow_disputed',
                        function () use ($orderId, $orderType, $reason, &$stepResult) {
                            $escrow = $this->escrow->getByOrder($orderId, $orderType);
                            if (!$escrow) {
                                throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                            }

                            $stepResult = $this->escrow->markAsDisputed((int)$escrow->id, $reason);
                            if (!$stepResult['ok']) {
                                throw new \Core\Exceptions\ApplicationException($stepResult['error'] ?? 'خطا در ثبت وضعیت اختلاف');
                            }
                            return true;
                        },
                        function () {}
                    )->execute();
                    return $stepResult;
                });

                return $result;
            } catch (\Throwable $e) {
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    /**
     * Resolve dispute and release/refund based on verdict
     */
    public function resolveDisputedEscrow(
        int    $orderId,
        string $orderType,
        string $verdict,
        float  $refundPercent,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['order_id' => $orderId, 'order_type' => $orderType, 'verdict' => $verdict, 'refund_percent' => $refundPercent];
        $escrowForUser = $this->escrow->getByOrder($orderId, $orderType);
        $idempotencyUserId = (int)($escrowForUser->buyer_id ?? 1);
        return $this->executeWithIdempotency($idempotencyKey, $idempotencyUserId, "resolve_disputed_{$orderType}_{$orderId}", function() use ($orderId, $orderType, $verdict, $refundPercent, $payload) {
            try {
                // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کامل در holdSocialTaskFunds()
                $releaseAmount = null;
                $refundAmount = null;

                $this->db->transactional(function () use ($orderId, $orderType, $verdict, $refundPercent, $payload, &$releaseAmount, &$refundAmount) {
                return $this->saga->setSaga('resolve_disputed_escrow', $payload)->addStep(
                    'verify_and_resolve_dispute',
                    function () use ($orderId, $orderType, $verdict, $refundPercent, &$releaseAmount, &$refundAmount) {
                        $escrow = $this->escrow->getByOrder($orderId, $orderType);
                        if (!$escrow || $escrow->status !== 'disputed') {
                            throw new \Core\Exceptions\InvalidStateException('پرونده در وضعیت اختلاف نیست');
                        }

                        $scale = strtolower((string)$escrow->currency) === 'usdt' ? 8 : 4;
                        $percent = bcdiv((string)$refundPercent, '100', 8);
                        $refundAmount = \Core\ValueObjects\Money::fromString((string)((string)$escrow->amount))->multiply((string)($percent))->getAmount();
                        $releaseAmount = \Core\ValueObjects\Money::fromString((string)((string)$escrow->amount))->subtract(\Core\ValueObjects\Money::fromString((string)($refundAmount)))->getAmount();

                        $result = $this->escrow->resolveDisputePartial(
                            (int)$escrow->id,
                            (int)$escrow->buyer_id,
                            (int)$escrow->seller_id,
                            $refundAmount,
                            $releaseAmount,
                            'admin_dispute_resolution',
                            $verdict
                        );

                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException($result['error'] ?? 'خطا در حل‌وفصل اختلاف');
                        }
                        return ['escrow_id' => (int)$escrow->id];
                    },
                    function ($error) use ($orderId, $orderType) {
                        $this->logger->warning('saga_compensate: reverting dispute resolution', ['order_id' => $orderId, 'order_type' => $orderType]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'disputed', released_at = NULL, released_by = NULL WHERE order_id = ? AND order_type = ?")
                                 ->execute([$orderId, $orderType]);
                    }
                )->addStep(
                    'deposit_resolved_funds',
                    function (array $ctx) use ($orderId, $orderType, &$releaseAmount, &$refundAmount) {
                        $escrow = $this->escrow->getByOrder($orderId, $orderType);
                        if (!$escrow) {
                            throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                        }
                        $currency = strtoupper((string)$escrow->currency) === 'USDT' ? 'usdt' : 'irt';

                        // First unlock the original escrow hold back to buyer. Then, if the
                        // verdict releases part/all of the funds to seller, spend exactly that
                        // amount from buyer and credit seller. This keeps wallet locked balances
                        // consistent for partial dispute resolutions.
                        $this->settleEscrowHold($escrow, 'cancel', (string)$escrow->amount);

                        if (bccomp((string)$releaseAmount, '0', 8) > 0) {
                            $this->spendReleasedBuyerAmount($escrow, (string)$releaseAmount, $currency);
                            $this->wallet->deposit((int)$escrow->seller_id, (string)$releaseAmount, $currency, [
                                'type' => 'dispute_release',
                                'order_id' => $orderId
                            ]);
                        }
                        return true;
                    },
                    function (\Throwable $e) use ($orderId) {
                        $this->logger->warning('saga_compensate: reverting dispute resolution deposits', ['order_id' => $orderId]);
                    }
                )->execute();
                });

                return ['ok' => true, 'released' => $releaseAmount, 'refunded' => $refundAmount];

            } catch (\Throwable $e) {
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    /**
     * Cron task to automatically release expired holds back to the advertiser.
     * CRITICAL-NEW-02: Prevent funds from being locked forever if executor never submits proof.
     */
    /**
     * Bug Fix: پشتیبانی از همه انواع escrow به جای فقط social_task_execution
     * 
     * انواع پشتیبانی شده:
     * - social_task_execution → refundSocialTaskFunds()
     * - influencer_order     → refund از طریق EscrowService (Outbox)
     * - vitrine              → refundVitrineFunds()
     * - lottery_participation→ refund از طریق EscrowService
     * - custom_task          → refund از طریق EscrowService
     */
    public function releaseExpiredHolds(): int
    {
        $expiredHours = (int)$this->appSettings->get('escrow_expiry_hours', 48);
        
        // اصلاح کلیدی معماری همزمانی در ابطال اعتبارهای صندوق امانی (Escrow Hold Expiry Concurrency Guard):
        // استفاده از قفل‌گذاری اتمیک FOR UPDATE جهت جلوگیری از واکشی موازی توسط ورکرهای کرون و استرداد مضاعف وجه به خریداران در کلاسترها
        $expired = $this->db->query("
            SELECT e.id, e.order_id, e.buyer_id, e.seller_id, e.amount, e.currency, e.order_type
            FROM escrow_transactions e
            WHERE e.status = 'pending'
              AND e.held_at < DATE_SUB(NOW(), INTERVAL ? HOUR) FOR UPDATE
        ", [$expiredHours])->fetchAll(\PDO::FETCH_OBJ);
        
        $totalReleased = 0;
        
        foreach ($expired as $row) {
            try {
                switch ($row->order_type) {
                    case 'social_task_execution':
                        $this->refundSocialTaskFunds(
                            (int)$row->order_id,
                            (int)$row->buyer_id,
                            'auto_expired_after_' . $expiredHours . 'h'
                        );
                        $totalReleased++;
                        break;
                        
                    case 'vitrine':
                        $this->refundVitrineFunds(
                            (int)$row->id,
                            (int)$row->buyer_id,
                            'auto_expired_after_' . $expiredHours . 'h'
                        );
                        $totalReleased++;
                        break;
                        
                    case 'influencer_order':
                    case 'custom_task':
                    case 'lottery_participation':
                        // Generic refund: بازگرداندن وجه به خریدار
                        $this->refundGenericFunds(
                            (int)$row->id,
                            (int)$row->order_id,
                            (int)$row->buyer_id,
                            (float)$row->amount,
                            (string)$row->currency,
                            $row->order_type,
                            'auto_expired_after_' . $expiredHours . 'h'
                        );
                        $totalReleased++;
                        break;
                        
                    default:
                        $this->logger->warning('escrow.unknown_order_type_on_release', [
                            'escrow_id' => $row->id,
                            'order_type' => $row->order_type,
                        ]);
                        break;
                }
            } catch (\Throwable $e) {
                $this->logger->error('escrow.release_failed_for_row', [
                    'escrow_id' => $row->id ?? 0,
                    'order_type' => $row->order_type ?? 'unknown',
                    'error' => $e->getMessage(),
                ]);
            }
        }
        
        return $totalReleased;
    }
    
    /**
     * Generic refund for non-specific escrow types
     */
    /**
     * Generic refund for non-specific escrow types.
     * 🛡️ Atomicity: wrapped in DB transaction to prevent double-refund race conditions.
     * Matches the saga-based pattern used by refundSocialTaskFunds/refundVitrineFunds.
     */
    private function refundGenericFunds(
        int $escrowId,
        int $orderId,
        int $buyerId,
        float $amount,
        string $currency,
        string $orderType,
        string $reason
    ): void {
        $this->db->transactional(function () use ($escrowId, $orderId, $buyerId, $amount, $currency, $orderType, $reason) {
            // 1. Lock escrow row FOR UPDATE to prevent concurrent refunds
            $escrow = $this->db->fetch(
                "SELECT * FROM escrow_transactions WHERE id = ? FOR UPDATE",
                [$escrowId]
            );

            if (!$escrow) {
                $this->logger->warning('escrow.refund_not_found', ['escrow_id' => $escrowId]);
                return;
            }

            // 2. Guard: only refund pending or in_escrow rows
            if (!in_array((string)$escrow->status, ['pending', 'in_escrow'], true)) {
                $this->logger->warning('escrow.already_processed', [
                    'escrow_id' => $escrowId,
                    'status'    => $escrow->status,
                ]);
                return;
            }

            // 3. Settle the hold (cancel mode releases locked funds)
            $this->settleEscrowHold($escrow, 'cancel', (string)$amount);

            // 4. Update escrow status atomically
            $this->db->query(
                "UPDATE escrow_transactions
                 SET status = 'refunded', refunded_at = NOW(), refund_reason = ?,
                     refunded_by = 'escrow_timeout_job', updated_at = NOW()
                 WHERE id = ? AND status IN ('pending', 'in_escrow')",
                [$reason, $escrowId]
            );

            $this->logger->info('escrow.auto_released', [
                'escrow_id' => $escrowId,
                'order_type' => $orderType,
                'buyer_id' => $buyerId,
                'amount' => $amount,
            ]);
        });
    }

    private function settleEscrowHold(object $escrow, string $mode, ?string $amount = null): void
    {
        $currency = strtolower((string)$escrow->currency) === 'usdt' ? 'usdt' : 'irt';
        $holdType = match ((string)$escrow->order_type) {
            'influencer_order' => 'influencer_escrow',
            'vitrine_listing', 'vitrine' => 'vitrine_escrow',
            'social_task_execution' => 'social_task_escrow',
            default => 'escrow_hold',
        };

        $tx = $this->findEscrowHoldTransaction(
            (int)$escrow->buyer_id,
            $holdType,
            (string)$escrow->order_id,
            $amount ?? (string)$escrow->amount,
            $currency
        );

        if (!$tx) {
            throw new \Core\Exceptions\NotFoundException('تراکنش نگهداری وجه امانی یافت نشد');
        }

        if ($mode === 'complete') {
            if (!$this->wallet->completeWithdrawal((int)$escrow->buyer_id, (string)$tx->amount, $currency, (string)$tx->transaction_id)) {
                throw new \Core\Exceptions\ApplicationException('خطا در تکمیل تراکنش صندوق امانات');
            }
            return;
        }

        if ($mode === 'cancel') {
            if (!$this->wallet->cancelWithdrawal((int)$escrow->buyer_id, (string)$tx->amount, $currency, (string)$tx->transaction_id)) {
                throw new \Core\Exceptions\ApplicationException('خطا در لغو تراکنش صندوق امانات');
            }
            return;
        }

        throw new \InvalidArgumentException('Invalid escrow settlement mode');
    }

    private function findEscrowHoldTransaction(int $userId, string $type, string $orderId, string $amount, string $currency): ?object
    {
        $currency = strtolower($currency) === 'usdt' ? 'usdt' : 'irt';
        return $this->db->fetch(
            "SELECT * FROM transactions
             WHERE user_id = ? AND type = 'withdraw' AND currency = ?
               AND status IN ('pending', 'processing')
               AND ABS(amount - ?) < 0.00000001
               AND metadata LIKE ?
               AND (
                    ref_id = ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
               )
             ORDER BY id DESC LIMIT 1",
            [
                $userId,
                $currency,
                $amount,
                '%"type":"' . $type . '"%',
                $orderId,
                '%"order_id":' . $orderId . '%',
                '%"listing_id":' . $orderId . '%',
                '%"execution_id":' . $orderId . '%',
            ]
        );
    }

    private function spendReleasedBuyerAmount(object $escrow, string $amount, string $currency): void
    {
        if (bccomp($amount, '0', 8) <= 0) {
            return;
        }

        $res = $this->wallet->withdraw((int)$escrow->buyer_id, $amount, $currency, [
            'type' => 'escrow_dispute_release_spend',
            'order_id' => (int)$escrow->order_id,
            'ref_id' => (string)$escrow->order_id . ':dispute_release',
            'ref_type' => (string)$escrow->order_type,
        ]);
        if (empty($res['success']) || empty($res['transaction_id'])) {
            throw new \Core\Exceptions\ApplicationException('خطا در رزرو مبلغ حل اختلاف');
        }
        if (!$this->wallet->completeWithdrawal((int)$escrow->buyer_id, $amount, $currency, (string)$res['transaction_id'])) {
            throw new \Core\Exceptions\ApplicationException('خطا در تسویه مبلغ حل اختلاف');
        }
    }

    /**
     * INTERNAL_API: مصرف بخشی از یک بودجه قفل‌شده بدون واریز به کاربر دیگر.
     *
     * این متد ad-specific نیست؛ فقط escrow.amount و wallets.locked_* را اتمیک کم می‌کند.
     * برای درآمد پلتفرم/مصرف بودجه کمپین‌هایی استفاده می‌شود که seller user ندارند.
     */
    public function consumeHeldBudget(
        int $escrowId,
        int $buyerId,
        string $amount,
        string $currency,
        string $reason,
        string $releasedBy = 'system'
    ): array {
        $operation = function () use ($escrowId, $buyerId, $amount, $currency, $reason, $releasedBy) {
            if (bccomp($amount, '0', 8) <= 0) {
                return ['ok' => true, 'released' => '0'];
            }
            $currency = strtolower($currency) === 'usdt' ? 'usdt' : 'irt';
            $lockedField = $currency === 'usdt' ? 'locked_usdt' : 'locked_irt';

            $escrow = $this->db->fetch(
                "SELECT * FROM escrow_transactions WHERE id = ? AND buyer_id = ? AND status IN ('pending','in_escrow','partial') FOR UPDATE",
                [$escrowId, $buyerId]
            );
            if (!$escrow) {
                return ['ok' => false, 'error' => 'Escrow not found or not consumable'];
            }
            if (bccomp((string)$escrow->amount, $amount, 8) < 0) {
                return ['ok' => false, 'error' => 'Escrow amount is insufficient'];
            }

            // آزادسازی locked → balance (refund to buyer wallet)
            $releaseResult = $this->wallet->releaseLockedFunds(
                $buyerId, $amount, strtolower((string)$escrow->currency),
                ['type' => 'escrow_settle', 'ref_id' => $escrowId, 'description' => 'تسویه اسکرو']
            );
            if (empty($releaseResult['success'])) {
                throw new \Core\Exceptions\ApplicationException('خطا در کسر بودجه قفل‌شده کیف پول');
            }

            $remaining = bcsub((string)$escrow->amount, $amount, 8);
            if (bccomp($remaining, '0', 8) < 0) {
                $remaining = '0';
            }
            $status = bccomp($remaining, '0', 8) <= 0 ? 'released' : 'partial';
            $this->db->query(
                "UPDATE escrow_transactions
                 SET status = ?, amount = ?, partial_released = COALESCE(partial_released, 0) + ?,
                     released_at = CASE WHEN ? = 'released' THEN NOW() ELSE released_at END,
                     released_by = CASE WHEN ? = 'released' THEN ? ELSE released_by END,
                     updated_at = NOW()
                 WHERE id = ?",
                [$status, $remaining, $amount, $status, $status, $releasedBy, $escrowId]
            );

            $this->logger->info('financial_escrow.held_budget_consumed', [
                'escrow_id' => $escrowId,
                'buyer_id' => $buyerId,
                'amount' => $amount,
                'reason' => $reason,
            ]);

            return ['ok' => true, 'released' => $amount, 'remaining' => $remaining, 'status' => $status];
        };

        if ($this->db->inTransaction()) {
            return $operation();
        }
        return $this->db->transactional(fn() => $operation());
    }

    /**
     * INTERNAL_API: refund موجودی باقی‌مانده یک budget escrow به خریدار.
     * این متد عمومی escrow/wallet است و منطق جدول ads را نمی‌شناسد.
     */
    public function refundHeldBudget(
        int $escrowId,
        int $buyerId,
        string $reason,
        string $refundedBy = 'system'
    ): array {
        $operation = function () use ($escrowId, $buyerId, $reason, $refundedBy) {
            $escrow = $this->db->fetch(
                "SELECT * FROM escrow_transactions WHERE id = ? AND buyer_id = ? AND status IN ('pending','in_escrow','partial') FOR UPDATE",
                [$escrowId, $buyerId]
            );
            if (!$escrow) {
                return ['ok' => false, 'error' => 'Escrow not found or not refundable'];
            }
            $amount = (string)$escrow->amount;
            $currency = strtolower((string)$escrow->currency) === 'usdt' ? 'usdt' : 'irt';
            $balanceField = $currency === 'usdt' ? 'balance_usdt' : 'balance_irt';
            $lockedField = $currency === 'usdt' ? 'locked_usdt' : 'locked_irt';

            if (bccomp($amount, '0', 8) > 0) {
                $releaseResult = $this->wallet->releaseLockedFunds(
                    $buyerId, $amount, $currency,
                    ['type' => 'escrow_refund', 'ref_id' => $escrowId, 'description' => 'بازگشت وجه امانی']
                );
                if (empty($releaseResult['success'])) {
                    throw new \Core\Exceptions\ApplicationException('خطا در بازگشت بودجه قفل‌شده کیف پول');
                }
            }

            $this->db->query(
                "UPDATE escrow_transactions
                 SET status = 'refunded', amount = 0, refunded_at = NOW(), refund_reason = ?, refunded_by = ?, updated_at = NOW()
                 WHERE id = ?",
                [$reason, $refundedBy, $escrowId]
            );

            $this->logger->info('financial_escrow.held_budget_refunded', [
                'escrow_id' => $escrowId,
                'buyer_id' => $buyerId,
                'amount' => $amount,
                'reason' => $reason,
            ]);

            return ['ok' => true, 'amount' => $amount, 'currency' => $currency];
        };

        if ($this->db->inTransaction()) {
            return $operation();
        }
        return $this->db->transactional(fn() => $operation());
    }

    /**
     * 🛡️ Fraud Policy Guard — بررسی ضدتقلب قبل از عملیات مالی escrow
     */
    private function assertFraudAllowed(int $userId, string $action, array $context = []): void
    {
        try {
            $risk = $this->fraudGuard->checkAction($userId, $action, $context);

            if (empty($risk['allowed'])) {
                throw new \App\Exceptions\BusinessException(
                    'عملیات مالی به دلیل محدودیت‌های امنیتی مجاز نیست.'
                );
            }
        } catch (\App\Exceptions\BusinessException $e) {
            throw $e;
        } catch (\Throwable $e) {
            $this->logger->warning('escrow.fraud_check_unavailable', [
                'user_id' => $userId, 'error' => $e->getMessage(),
            ]);
        }
    }
}

