<?php

declare(strict_types=1);

namespace App\Domain\Financial\Services;

use App\Contracts\WalletServiceInterface;
use App\Contracts\LoggerInterface;
use App\Contracts\AntiFraud\FraudGuardInterface;
use App\Services\EscrowService;
use App\Services\Settings\AppSettings;
use App\Services\SagaOrchestrator;
use Core\Database;
use App\Services\Shared\IdempotencyService;
use Core\ValueObjects\Money;

/**
 * FinancialEscrowService - Unified escrow management for all financial modules
 * 
 * Uses EscrowService as foundation + module-specific business logic
 * Modules: SocialTask (advertiser→executor), Influencer (buyer→seller), Vitrine (buyer→seller)
 */
/**
 * @phpstan-type FinancialResult array<string, mixed>
 * @phpstan-type EscrowRow object{
 *     id: int|string,
 *     order_id: int|string,
 *     order_type: string,
 *     buyer_id: int|string,
 *     seller_id: int|string,
 *     amount: int|float|string,
 *     currency: string,
 *     status: string
 * }
 * @phpstan-type EscrowHoldRow object{transaction_id: string, amount: int|float|string}
 */
class FinancialEscrowService
{
    private EscrowService $escrow;
    private WalletServiceInterface $wallet;
    /** FIX-CH01: primitive داخلی دو-لگی platform_revenue→wallet→locked */
    private ?\App\Services\Wallet\WalletMutationService $walletMutation = null;
    protected Database $db;
    private LoggerInterface $logger;
    private AppSettings $appSettings;
    private SagaOrchestrator $saga;
    private FraudGuardInterface $fraudGuard;
    private ?IdempotencyService $idempotencyService;
    private ?\App\Contracts\OutboxServiceInterface $outboxService = null;

    public function __construct(
        EscrowService $escrow,
        WalletServiceInterface $wallet,
        AppSettings $appSettings,
        SagaOrchestrator $saga,
        Database $db,
        LoggerInterface $logger,
        FraudGuardInterface $fraudGuard,
        ?IdempotencyService $idempotencyService = null,
        ?\App\Contracts\OutboxServiceInterface $outboxService = null,
        ?\App\Services\Wallet\WalletMutationService $walletMutation = null
    ) {
        $this->escrow = $escrow;
        $this->wallet = $wallet;
        $this->appSettings = $appSettings;
        $this->saga = $saga;
        $this->db = $db;
        $this->logger = $logger;
        $this->fraudGuard = $fraudGuard;
        $this->idempotencyService = $idempotencyService;
        $this->outboxService = $outboxService;
        // FIX-CH01: primitive دو-لگی بازگرداندن بودجه hold؛ غیبت = fail-closed
        $this->walletMutation = $walletMutation;
    }


    /** @param array<string, mixed> $context */
    private function captureEscrowException(\Throwable $e, string $operation, array $context = []): void
    {
        try {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, array_merge([
                'operation' => 'financial_escrow.' . $operation,
            ], $context));
        } catch (\Throwable $ignored) {
            // Sentry must never break financial fallback paths.
        }
    }

    /**
     * @param callable(): mixed $logic
     * @param array<string, mixed>|null $requestData
     * @return FinancialResult
     */
    private function executeWithIdempotency(?string $key, int $userId, string $action, callable $logic, ?array $requestData = null): array
    {
        if ($key && $this->idempotencyService) {
            // از IdempotencyService::execute() استفاده می‌کنیم — نقطه مرکزی idempotency.
            // قرارداد عمومی FinancialEscrowService حفظ می‌شود: در صورت خطا ['ok'=>false] برمی‌گردد.
            try {
                return $this->normalizeFinancialResult(
                    $this->idempotencyService->execute($action, $userId, $requestData ?? [], $logic, $key)
                );
            } catch (\Throwable $e) {
            $this->captureEscrowException($e, 'executeWithIdempotency');
                $this->logger->error('financial_escrow.operation_failed', ['action' => $action, 'error' => $e->getMessage()]);
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }

        // Fallback when idempotency service isn't available
        try {
            $result = $logic();
            return $this->normalizeFinancialResult($result);
        } catch (\Throwable $e) {
            $this->captureEscrowException($e, 'executeWithIdempotency');
            $this->logger->error('financial_escrow.operation_failed', ['error' => $e->getMessage()]);
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /** @param array<string, mixed> $result */
    private function resultMessage(array $result, string $key, string $fallback): string
    {
        return is_string($result[$key] ?? null) ? $result[$key] : $fallback;
    }

    /**
     * @return FinancialResult
     */
    private function normalizeFinancialResult(mixed $result): array
    {
        if (!is_array($result)) {
            return ['ok' => (bool)$result];
        }

        foreach (array_keys($result) as $key) {
            if (!is_string($key)) {
                throw new \UnexpectedValueException('Financial operation result must be an associative array');
            }
        }

        /** @var FinancialResult $result */
        return $result;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Generic custom-deal escrow (Buyer → Seller)
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Canonical refund contract for escrow flows backed by a pending wallet hold.
     * It performs the wallet mutation and escrow state transition atomically.
     * @return FinancialResult
     */
    /**
     * 🛡️ FIX-S36-B15-S12: پارامتر $inTxHook — قلابی که «داخل» تراکنش بازپرداخت و
     * درست پیش از commit اجرا می‌شود تا ثبتِ قصد اعلان (outbox) اتمیک با جابه‌جایی
     * وجه باشد؛ شکستش کل بازپرداخت را rollback می‌کند و اعلان هرگز گم نمی‌شود.
     */
    public function refundEscrowToBuyer(int $escrowId, int $buyerId, string $reason, string $initiatedBy = 'system', ?string $idempotencyKey = null, ?callable $inTxHook = null): array
    {
        $payload=['escrow_id'=>$escrowId,'buyer_id'=>$buyerId,'reason'=>$reason,'initiated_by'=>$initiatedBy];
        return $this->executeWithIdempotency($idempotencyKey,$buyerId,"refund_escrow_{$escrowId}",function()use($escrowId,$buyerId,$reason,$initiatedBy,$inTxHook){
            try{return $this->db->transactional(function()use($escrowId,$buyerId,$reason,$initiatedBy,$inTxHook){
                $escrow=$this->db->fetch('SELECT * FROM escrow_transactions WHERE id=? FOR UPDATE',[$escrowId]);
                if(!$escrow)throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                $escrow = $this->requireEscrowRow($escrow);
                if((int)$escrow->buyer_id!==$buyerId)throw new \Core\Exceptions\SecurityException('خریدار صندوق امانات مطابقت ندارد');
                if(!in_array((string)$escrow->status,['pending','in_escrow','partial','disputed'],true))throw new \Core\Exceptions\InvalidStateException('وضعیت صندوق امانات برای refund معتبر نیست');
                $holdType=match((string)$escrow->order_type){'custom_deal'=>'custom_deal_escrow','social_task_execution'=>'social_task_escrow','influencer_order'=>'influencer_escrow','vitrine_listing'=>'vitrine_escrow',default=>throw new \Core\Exceptions\InvalidStateException('نوع escrow برای refund یکپارچه پشتیبانی نمی‌شود')};
                $currency=strtolower((string)$escrow->currency)==='usdt'?'usdt':'irt';
                $hold=$this->findEscrowHoldTransaction($buyerId,$holdType,(string)$escrow->order_id,(string)$escrow->amount,$currency,(int)$escrow->id);
                if(!$hold)throw new \Core\Exceptions\NotFoundException('تراکنش hold متناظر یافت نشد');
                $refund=$this->escrow->refundFunds($escrowId,$buyerId,$reason,$initiatedBy,"refund_state_{$escrowId}");
                if(empty($refund['ok']))throw new \Core\Exceptions\ApplicationException($this->resultMessage($refund, 'error', 'تغییر وضعیت refund ناموفق بود'));
                $walletRefund=$this->wallet->releaseLockedFunds($buyerId,(string)$escrow->amount,$currency,['type'=>'escrow_refund','ref_id'=>$escrowId,'ref_type'=>'escrow','description'=>$reason,'idempotency_key'=>"escrow_refund_wallet_{$escrowId}"]);
                if(empty($walletRefund['success']))throw new \Core\Exceptions\ApplicationException($this->resultMessage($walletRefund, 'message', 'بازگشت وجه کیف پول ناموفق بود'));
                if(!$this->wallet->finalizeLockedRefund($buyerId,(string)$hold->transaction_id))throw new \Core\Exceptions\ApplicationException('نهایی‌سازی hold refund ناموفق بود');
                if($inTxHook!==null){$inTxHook($escrowId,$buyerId,(string)$escrow->amount,$currency);}
                return ['ok'=>true,'amount'=>(string)$escrow->amount,'currency'=>$currency,'transaction_id'=>$walletRefund['transaction_id']??null];
            });}catch(\Throwable $e){$this->captureEscrowException($e,'refundEscrowToBuyer',['escrow_id'=>$escrowId]);return['ok'=>false,'error'=>$e->getMessage()];}
        },$payload);
    }

    /**
     * Creates and funds a user-to-user escrow atomically. The old controller
     * only created an escrow row; this flow also creates the buyer wallet hold
     * and confirms the escrow before returning success.
     * @return FinancialResult
     */
    public function holdCustomDealFunds(
        int $orderId,
        int $buyerId,
        int $sellerId,
        string $amount,
        ?string $idempotencyKey = null
    ): array {
        if ($buyerId <= 0 || $sellerId <= 0 || $buyerId === $sellerId) {
            return ['ok' => false, 'error' => 'طرفین معاملهٔ امانی نامعتبر هستند'];
        }
        if (bccomp($amount, '0', 8) <= 0) {
            return ['ok' => false, 'error' => 'مبلغ صندوق امانات باید بیشتر از صفر باشد'];
        }

        // 🛡️ FIX-S36-B15-S01: در مسیر «نیت‌محور» (کلید صریح از request_id کلاینت)،
        // هم scope و هم payload باید بین retryها پایدار باشند — IdempotencyKey::run
        // کلید نهایی را به‌صورت hash(scope|actor|key) می‌سازد؛ اگر orderId تصادفی
        // در scope یا payload بماند، retry با کلید یکسان، کلید متفاوت می‌گیرد و
        // امانت دوم ساخته می‌شود (باگ S15-01). در مسیر بدون کلید (فراخوان داخلی
        // قدیمی)، رفتار قبلی (orderId در scope و payload) حفظ می‌شود.
        // (مسیر influencer/vitrine orderId پایدار دارد و دست نخورده ماند.)
        $hasIntentKey = is_string($idempotencyKey) && $idempotencyKey !== '';
        $scope = $hasIntentKey ? 'hold_custom_deal' : "hold_custom_deal_{$orderId}";
        $payload = $hasIntentKey
            ? ['buyer_id' => $buyerId, 'seller_id' => $sellerId, 'amount' => $amount]
            : ['order_id' => $orderId, 'buyer_id' => $buyerId, 'seller_id' => $sellerId, 'amount' => $amount];
        return $this->executeWithIdempotency($idempotencyKey, $buyerId, $scope, function () use ($orderId, $buyerId, $sellerId, $amount) {
            try {
                return $this->db->transactional(function () use ($orderId, $buyerId, $sellerId, $amount) {
                    $this->db->query('SELECT id FROM wallets WHERE user_id = ? FOR UPDATE', [$buyerId]);
                    $balance = $this->wallet->getBalanceForUpdate($buyerId, 'irt');
                    if (Money::fromString($amount, 'irt')->isGreaterThan(Money::fromString($balance, 'irt'))) {
                        throw new \Core\Exceptions\InsufficientBalanceException('موجودی کیف پول خریدار کافی نیست');
                    }

                    $record = $this->escrow->holdFunds(
                        $orderId,
                        'custom_deal',
                        $buyerId,
                        $sellerId,
                        $amount,
                        'IRT',
                        "custom_deal_escrow_record_{$orderId}"
                    );
                    if (empty($record['ok']) || empty($record['escrow_id'])) {
                        throw new \Core\Exceptions\ApplicationException($this->resultMessage($record, 'error', 'ایجاد صندوق امانات انجام نشد'));
                    }

                    $hold = $this->wallet->withdraw($buyerId, $amount, 'irt', [
                        'type' => 'custom_deal_escrow',
                        'order_id' => $orderId,
                        'ref_id' => $orderId,
                        'ref_type' => 'custom_deal',
                        // 🛡️ FIX-S36-B15-C01: escrow_id در متادیتای hold ثبت می‌شود (هم‌الگوی
                        // influencer/vitrine) تا تسویه/refund از تطبیق دقیقِ escrow_id عبور کند
                        // و به fallback متنیِ order_id نیفتد (مسیر جاری این‌فال‌بک بود).
                        'escrow_id' => (int)$record['escrow_id'],
                        'description' => "رزرو وجه معاملهٔ امن #{$orderId}",
                        // 🛡️ FIX-S36-B15-S07: کلید چرخه‌آگاه — پیوند escrowId به کلید،
                        // replay کلید چرخهٔ قدیم روی امانت فعال جدید را ناممکن می‌کند.
                        'idempotency_key' => "custom_deal_hold_{$orderId}_{$record['escrow_id']}",
                    ]);
                    if (empty($hold['success'])) {
                        throw new \Core\Exceptions\ApplicationException($this->resultMessage($hold, 'message', 'قفل‌کردن وجه معاملهٔ امن انجام نشد'));
                    }

                    $confirmed = $this->escrow->confirmHold($orderId, 'custom_deal', $sellerId, "custom_deal_confirm_{$orderId}_{$record['escrow_id']}");
                    if (empty($confirmed['ok'])) {
                        throw new \Core\Exceptions\ApplicationException($this->resultMessage($confirmed, 'error', 'تأیید صندوق امانات انجام نشد'));
                    }

                    return ['ok' => true, 'escrow_id' => (int)$record['escrow_id']];
                });
            } catch (\Throwable $e) {
                $this->captureEscrowException($e, 'holdCustomDealFunds', ['order_id' => $orderId]);
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    /** Releases a fully-funded custom deal after buyer authorization.
     * @return FinancialResult
     */
    public function releaseCustomDealFunds(int $escrowId, int $buyerId, ?string $idempotencyKey = null): array
    {
        $payload = ['escrow_id' => $escrowId, 'buyer_id' => $buyerId];
        return $this->executeWithIdempotency($idempotencyKey, $buyerId, "release_custom_deal_{$escrowId}", function () use ($escrowId, $buyerId) {
            try {
                return $this->db->transactional(function () use ($escrowId, $buyerId) {
                    $escrow = $this->db->fetch('SELECT * FROM escrow_transactions WHERE id = ? FOR UPDATE', [$escrowId]);
                    if (!$escrow || (string)$escrow->order_type !== 'custom_deal') {
                        throw new \Core\Exceptions\NotFoundException('صندوق امانات معاملهٔ امن یافت نشد');
                    }
                    $escrow = $this->requireEscrowRow($escrow);
                    if ((int)$escrow->buyer_id !== $buyerId) {
                        throw new \Core\Exceptions\SecurityException('فقط خریدار می‌تواند وجه معاملهٔ امن را آزاد کند');
                    }
                    if ((string)$escrow->status !== 'in_escrow') {
                        throw new \Core\Exceptions\InvalidStateException('وضعیت صندوق امانات برای آزادسازی معتبر نیست');
                    }

                    // 🛡️ FIX-S36-B15-S05 (طبقه‌بندی دفترکل یکدست اسکرو): مسیر قبلی hold را با
                    // completeWithdrawal مصرف می‌کرد (ledger: locked_reserve→withdrawal_payout
                    // — شبیه برداشت واقعی) و واریز فروشنده بدون ledger_debit_account صریح بود
                    // (پیش‌فرض external_payment — شبیه ورود وجه بیرونی). اکنون همان الگوی
                    // رسمی influencer/vitrine: spendLockedFunds با escrow_payout + واریز با
                    // debit escrow_payout + finalizeLockedSpend ⇒ زنجیرهٔ حساب واسط اسکرو
                    // بسته می‌شود و ورود/خروج خارجی کاذب در دفتر ثبت نمی‌شود.
                    $currency = strtolower((string)$escrow->currency) === 'usdt' ? 'usdt' : 'irt';
                    $hold = $this->findEscrowHoldTransaction((int)$escrow->buyer_id, 'custom_deal_escrow', (string)$escrow->order_id, (string)$escrow->amount, $currency, (int)$escrow->id);
                    if (!$hold) {
                        throw new \Core\Exceptions\NotFoundException('تراکنش نگهداری وجه امانی یافت نشد');
                    }

                    $release = $this->escrow->releaseFunds((int)$escrow->id, (int)$escrow->seller_id, "buyer_{$buyerId}");
                    if (empty($release['ok'])) {
                        throw new \Core\Exceptions\ApplicationException($this->resultMessage($release, 'error', 'آزادسازی صندوق امانات انجام نشد'));
                    }

                    $spent = $this->wallet->spendLockedFunds((int)$escrow->buyer_id, (string)$escrow->amount, $currency, [
                        'type' => 'custom_deal_escrow_spend',
                        'ref_id' => $escrowId,
                        'ref_type' => 'escrow',
                        'description' => "تسویه وجه معاملهٔ امن #{$escrowId}",
                        'ledger_credit_account' => 'escrow_payout',
                        'idempotency_key' => "custom_deal_spend_{$escrowId}",
                    ]);
                    if (empty($spent['success'])) {
                        throw new \Core\Exceptions\ApplicationException($this->resultMessage($spent, 'message', 'مصرف وجه قفل‌شده انجام نشد'));
                    }

                    $payout = $this->wallet->deposit((int)$escrow->seller_id, (string)$escrow->amount, $currency, [
                        'type' => 'custom_deal_payout',
                        'ref_id' => $escrowId,
                        'ref_type' => 'custom_deal',
                        'description' => "دریافت وجه معاملهٔ امن #{$escrowId}",
                        'ledger_debit_account' => 'escrow_payout',
                        'idempotency_key' => "custom_deal_payout_{$escrowId}",
                    ]);
                    if (empty($payout['success'])) {
                        throw new \Core\Exceptions\ApplicationException($this->resultMessage($payout, 'message', 'واریز وجه به فروشنده انجام نشد'));
                    }

                    if (!$this->wallet->finalizeLockedSpend((int)$escrow->buyer_id, (string)$hold->transaction_id)) {
                        throw new \Core\Exceptions\ApplicationException('نهایی‌سازی hold خریدار انجام نشد');
                    }

                    return ['ok' => true, 'escrow_id' => $escrowId, 'transaction_id' => $payout['transaction_id'] ?? null];
                });
            } catch (\Throwable $e) {
                $this->captureEscrowException($e, 'releaseCustomDealFunds', ['escrow_id' => $escrowId]);
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    /** Cancels a custom deal and unlocks the buyer's original hold.
     * @return FinancialResult
     */
    private function refundOrderEscrow(int $orderId, string $orderType, int $buyerId, string $reason, string $initiatedBy, ?string $idempotencyKey, ?callable $inTxHook = null): array
    {
        $escrow = $this->escrow->getByOrder($orderId, $orderType);
        if (!$escrow) {
            return ['ok' => false, 'error' => 'صندوق امانات یافت نشد'];
        }
        $escrow = $this->requireEscrowRow($escrow);
        return $this->refundEscrowToBuyer((int)$escrow->id, $buyerId, $reason, $initiatedBy, $idempotencyKey, $inTxHook);
    }

    /** Compatibility entrypoint; canonical refund logic lives in refundEscrowToBuyer().
     * @return FinancialResult
     */
    public function refundCustomDealFunds(int $escrowId, int $buyerId, string $reason, ?string $idempotencyKey = null, ?callable $inTxHook = null): array
    {
        return $this->refundEscrowToBuyer($escrowId, $buyerId, $reason, 'custom_deal', $idempotencyKey, $inTxHook);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Social Task Escrow
    //
    // 🧹 DEAD-CODE REMOVED: متدهای holdSocialTaskFunds / confirmSocialTaskEscrow /
    // releaseSocialTaskFunds حذف شدند. آن‌ها برای مدل قدیمی «اسکروی per-execution»
    // طراحی شده بودند (hold هنگام اجرا، confirm و release هنگام تأیید ادمین)؛ اما
    // معماری به مدل «اسکروی مرکزی per-campaign» مهاجرت کرد: کل بودجه هنگام ساخت
    // آگهی با order_type=social_task_budget در AdSystemManager قفل می‌شود و پاداش
    // هر اجرا با partialRelease (کلید social_task_reward_{executionId}) از همان
    // اسکروی مرکزی آزاد می‌گردد (ApproveSocialTaskExecutionJob). نگه‌داشتن این
    // متدها یعنی موتور مالی موازی با کلیدهای متفاوت = ریسک پرداخت دوبل.
    // refundSocialTaskFunds عمداً باقی مانده تا ردیف‌های legacy با
    // order_type=social_task_execution توسط sweep انقضا (releaseExpiredHolds)
    // تخلیه شوند.
    //
    // BUGFIX-SAGA-TX-ROOT (توضیح کانونیکال — سایر متدها به همین‌جا ارجاع می‌دهند):
    // کامنت قدیمی می‌گفت beginTransaction عمداً حذف شده تا Saga «توزیع‌شده‌ی واقعی»
    // باشد، اما مکانیزم جبران (compensate) این پروژه از Closure استفاده می‌کند که —
    // طبق کد Worker بازیابی سابق (SagaRecoveryWorker — حذف‌شده) قابل بازیابی از دیتابیس نبود، و آن Worker هم
    // هرگز در Console\Kernel زمان‌بندی نشده. یعنی جبران فقط in-process ممکن است و
    // اگر بین دو Step کرش رخ دهد، وضعیت ناقص برای همیشه می‌ماند. راه‌حل: کل Saga
    // داخل یک Transaction Root اجرا می‌شود (با پشتیبانی SAVEPOINT از Core\Database
    // برای سازگاری با تراکنش‌های بیرونی مثل DisputeCommandService::adminResolve).
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * بازگرداندی پول به تبلیغ‌دهنده (رد شدن، dispute)
     * @return FinancialResult
     */
    public function refundSocialTaskFunds(int $executionId, int $advertiserId, string $reason, ?string $idempotencyKey = null, ?callable $inTxHook = null): array
    {
        return $this->refundOrderEscrow($executionId, 'social_task_execution', $advertiserId, $reason, 'admin_refund', $idempotencyKey, $inTxHook);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Influencer Escrow (Buyer → Seller Payment)
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * نگهداری پول برای سفارش اینفلوئنسر
     * @return FinancialResult
     */
    public function holdInfluencerOrderFunds(
        int    $orderId,
        int    $buyerId,
        int    $sellerId,
        string $amount,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['order_id' => $orderId, 'buyer_id' => $buyerId, 'seller_id' => $sellerId, 'amount' => $amount];
        return $this->executeWithIdempotency($idempotencyKey, $buyerId, "hold_influencer_order_{$orderId}", function() use ($orderId, $buyerId, $sellerId, $amount, $payload) {
            // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کانونیکال در ابتدای بخش Social Task Escrow همین کلاس
            $result = $this->db->transactional(function () use ($orderId, $buyerId, $sellerId, $amount, $payload) {
            return $this->saga
                ->setSaga('hold_influencer_order_escrow', $payload)
                ->addStep(
                    'verify_and_lock_buyer_balance',
                    function () use ($buyerId, $amount) {
                        // 🔒 Pessimistically lock the wallet row to prevent TOCTOU race conditions (BUG-02)
                        $this->db->query("SELECT id FROM wallets WHERE user_id = ? FOR UPDATE", [(int)$buyerId])->fetch();

                        // ✅ Verify buyer balance
                        $buyerBalance = $this->wallet->getBalanceForUpdate($buyerId, 'irt');

                        $buyerMoney = Money::fromString($buyerBalance, 'irt');
                        $amountMoney = Money::fromString($amount, 'irt');

                        if ($amountMoney->isGreaterThan($buyerMoney)) {
                            throw new \Core\Exceptions\InsufficientBalanceException('موجودی کیف پول خریدار کافی نیست');
                        }
                        return true;
                    },
                    function () {}
                )
                ->addStep(
                    'create_escrow_record',
                    function () use ($orderId, $buyerId, $sellerId, $amount) {
                        // ✅ Hold in escrow
                        // FIX-R19-A3-1: کلید idempotency رکورد — مسیر همزمان نباید دو escrow برای یک سفارش بسازد
                        $result = $this->escrow->holdFunds(
                            $orderId,
                            'influencer_order',
                            $buyerId,
                            $sellerId,
                            $amount,
                            'IRT',
                            "influencer_escrow_record_{$orderId}"
                        );

                        if (!$result['ok'] || !isset($result['escrow_id'])) {
                            throw new \Core\Exceptions\ApplicationException('خطا در ایجاد صندوق امانات: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        // FIX-R19-A3-3: escrow_id را به context saga تزریق می‌کنیم تا گام hold wallet آن را در metadata ثبت کند
                        return ['escrow_id' => (int)$result['escrow_id']];
                    },
                    function ($error) use ($orderId) {
                        $this->logger->warning('saga_compensate: cancelling influencer escrow record', ['order_id' => $orderId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'cancelled' WHERE order_id = ? AND order_type = ? AND status = 'pending'")
                                 ->execute([$orderId, 'influencer_order']);
                    }
                )
                ->addStep(
                    'deduct_wallet_balance',
                    function ($stepContext) use ($buyerId, $amount, $orderId) {
                        // ✅ Deduct from buyer wallet - calling withdraw since we are inside a database transaction
                        $this->assertFraudAllowed((int)$buyerId, 'escrow.hold', []);
                        // FIX-R19-A3-1: نتیجه withdraw نادیده گرفته نمی‌شود — شکست قفل وجه باید saga را متوقف کند
                        // FIX-R19-A3-3: escrow_id در metadata hold ثبت می‌شود تا تسویه بعدی با مطابقت دقیق انجام شود
                        $escrowId = is_array($stepContext) ? (int)($stepContext['escrow_id'] ?? 0) : (int)$stepContext;
                        $withdraw = $this->wallet->withdraw($buyerId, $amount, 'irt', [
                            'type' => 'influencer_escrow',
                            'order_id' => $orderId,
                            'ref_id' => $orderId,
                            'ref_type' => 'influencer_order',
                            // 🛡️ FIX-S36-B15-S07: کلید چرخه‌آگاه — escrowId در کلید و متادیتا
                            'idempotency_key' => "influencer_escrow_hold_{$orderId}_{$escrowId}",
                            'escrow_id' => $escrowId,
                        ]);
                        if (empty($withdraw['success'])) {
                            throw new \Core\Exceptions\ApplicationException($this->resultMessage($withdraw, 'message', 'قفل‌کردن وجه سفارش اینفلوئنسر انجام نشد'));
                        }
                        return $stepContext;
                    },
                    function ($error) use ($buyerId, $amount, $orderId) {
                        $this->logger->warning('saga_compensate: reverting wallet deduction', ['buyer_id' => $buyerId]);
                        $this->wallet->deposit($buyerId, $amount, 'irt', [
                            'type' => 'saga_compensation',
                            'order_id' => $orderId
                        ]);
                    }
                )
                ->execute();
            });

            $escrow = $this->escrow->getByOrder($orderId, 'influencer_order');
            if ($escrow === null) {
                throw new \Core\Exceptions\ApplicationException('رکورد صندوق امانات اینفلوئنسر پس از نگهداری یافت نشد');
            }
            $escrow = $this->requireEscrowRow($escrow);
            return ['ok' => true, 'escrow_id' => (int)$escrow->id];
        }, $payload);
    }

    /**
     * تأیید نگهداری امن سفارش اینفلوئنسر پس از برداشت موفق از کیف پول خریدار.
     * وضعیت escrow از pending به in_escrow می‌رود تا فقط از مسیرهای release/refund حل شود.
     * @return FinancialResult
     */
    public function confirmInfluencerOrderFunds(int $orderId, int $sellerId, ?string $idempotencyKey = null): array
    {
        $payload = ['order_id' => $orderId, 'seller_id' => $sellerId];
        return $this->executeWithIdempotency($idempotencyKey, $sellerId, "confirm_influencer_order_{$orderId}", function() use ($orderId, $sellerId) {
            $result = $this->escrow->confirmHold($orderId, 'influencer_order', $sellerId);
            if (!empty($result['ok'])) {
                return $result;
            }

            $escrow = $this->escrow->getByOrder($orderId, 'influencer_order');
            if ($escrow !== null) {
                $escrow = $this->requireEscrowRow($escrow);
            }
            if ($escrow && in_array((string)$escrow->status, ['in_escrow', 'released', 'refunded', 'disputed'], true)) {
                return ['ok' => true, 'escrow_id' => (int)$escrow->id, 'already_confirmed' => true];
            }

            return ['ok' => false, 'error' => $result['error'] ?? 'Escrow confirm failed'];
        }, $payload);
    }

    /**
     * تحویل پول به فروشنده (اینفلوئنسر).
     *
     * نکته مالی مهم: مبلغ نگهداری‌شده در escrow برابر قیمت کامل سفارش است،
     * اما مبلغ واریزی به اینفلوئنسر بعد از کسر سهم سایت است. بنابراین هنگام
     * complete، hold کامل خریدار settle می‌شود و فقط sellerAmount به فروشنده واریز می‌شود.
     * @return FinancialResult
     */
    public function releaseInfluencerOrderFunds(int $orderId, int $sellerId, string $sellerAmount, ?string $idempotencyKey = null): array
    {
        $payload = ['order_id' => $orderId, 'seller_id' => $sellerId, 'seller_amount' => $sellerAmount];
        return $this->executeWithIdempotency($idempotencyKey, $sellerId, "release_influencer_order_{$orderId}", function () use ($orderId, $sellerId, $sellerAmount) {
            try {
                return $this->db->transactional(function () use ($orderId, $sellerId, $sellerAmount) {
                    $escrow = $this->db->fetch(
                        // 🛡️ FIX-S36-B15-S07: انتخاب مرتبِ آخرین چرخه — بدون ORDER BY، با دو
                        // رکورد تاریخی برای یک سفارش، تسویه می‌توانست رکورد قدیم را هدف بگیرد.
                        'SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = ? ORDER BY id DESC LIMIT 1 FOR UPDATE',
                        [$orderId, 'influencer_order']
                    );
                    if (!$escrow) throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                    $escrow = $this->requireEscrowRow($escrow);
                    if ((int)$escrow->seller_id !== $sellerId) throw new \Core\Exceptions\SecurityException('عدم تطابق فروشنده با صندوق امانات');
                    if ((string)$escrow->status === 'released') return ['ok' => true, 'already_released' => true];
                    if (!in_array((string)$escrow->status, ['in_escrow', 'pending'], true)) throw new \Core\Exceptions\InvalidStateException('وضعیت صندوق امانات نامعتبر است');
                    if (bccomp($sellerAmount, '0', 8) < 0 || bccomp($sellerAmount, (string)$escrow->amount, 8) > 0) throw new \Core\Exceptions\InvalidStateException('مبلغ سهم فروشنده نامعتبر است');

                    $currency = strtolower((string)$escrow->currency) === 'usdt' ? 'usdt' : 'irt';
                    $platformAmount = bcsub((string)$escrow->amount, $sellerAmount, 8);
                    $holdType = 'influencer_escrow';
                    $hold = $this->findEscrowHoldTransaction((int)$escrow->buyer_id, $holdType, (string)$escrow->order_id, (string)$escrow->amount, $currency, (int)$escrow->id);
                    if (!$hold) throw new \Core\Exceptions\NotFoundException('تراکنش نگهداری وجه امانی یافت نشد');

                    $release = $this->escrow->releaseFunds((int)$escrow->id, $sellerId, 'influencer_order_complete');
                    if (empty($release['ok'])) throw new \Core\Exceptions\ApplicationException($release['error'] ?? 'خطا در آزادسازی وجه امانی');

                    if (bccomp($sellerAmount, '0', 8) > 0) {
                        $spent = $this->wallet->spendLockedFunds((int)$escrow->buyer_id, $sellerAmount, $currency, [
                            'type' => 'influencer_escrow_seller_spend', 'ref_id' => (int)$escrow->id, 'ref_type' => 'escrow',
                            'description' => "تسویه سهم اینفلوئنسر #{$orderId}", 'ledger_credit_account' => 'escrow_payout',
                            'idempotency_key' => "influencer_seller_spend_{$orderId}",
                        ]);
                        if (empty($spent['success'])) throw new \Core\Exceptions\ApplicationException($this->resultMessage($spent, 'message', 'مصرف وجه قفل‌شده انجام نشد'));
                        $payout = $this->wallet->deposit($sellerId, $sellerAmount, $currency, [
                            'type' => 'influencer_order_payment', 'order_id' => $orderId, 'ref_id' => $orderId, 'ref_type' => 'influencer_order',
                            'description' => "درآمد سفارش اینفلوئنسر #{$orderId}", 'ledger_debit_account' => 'escrow_payout',
                            'idempotency_key' => \App\Services\Shared\IdempotencyKeys::influencerPayout($orderId),
                        ]);
                        if (empty($payout['success'])) throw new \Core\Exceptions\ApplicationException($this->resultMessage($payout, 'message', 'واریز سهم فروشنده انجام نشد'));
                    }
                    if (bccomp($platformAmount, '0', 8) > 0) {
                        $platform = $this->wallet->spendLockedFunds((int)$escrow->buyer_id, $platformAmount, $currency, [
                            'type' => 'influencer_escrow_platform_fee', 'ref_id' => (int)$escrow->id, 'ref_type' => 'escrow',
                            'description' => "کارمزد سفارش اینفلوئنسر #{$orderId}", 'ledger_credit_account' => 'platform_revenue',
                            'idempotency_key' => "influencer_platform_fee_{$orderId}",
                        ]);
                        if (empty($platform['success'])) throw new \Core\Exceptions\ApplicationException($this->resultMessage($platform, 'message', 'مصرف کارمزد انجام نشد'));
                    }
                    if (!$this->wallet->finalizeLockedSpend((int)$escrow->buyer_id, (string)$hold->transaction_id)) throw new \Core\Exceptions\ApplicationException('نهایی‌سازی hold خریدار انجام نشد');
                    return ['ok' => true, 'seller_amount' => $sellerAmount, 'platform_amount' => $platformAmount];
                });
            } catch (\Throwable $e) {
                $this->captureEscrowException($e, 'releaseInfluencerOrderFunds', ['order_id' => $orderId]);
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    /**
     * بازگشت کامل مبلغ سفارش اینفلوئنسر به خریدار از escrow.
     * @return FinancialResult
     */
    public function refundInfluencerOrderFunds(int $orderId, int $buyerId, string $reason, ?string $idempotencyKey = null, ?callable $inTxHook = null): array
    {
        return $this->refundOrderEscrow($orderId, 'influencer_order', $buyerId, $reason, 'influencer_order_refund', $idempotencyKey, $inTxHook);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Vitrine Escrow (Buyer → Seller Payment)
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * نگهداری پول برای آگهی ویترین
     * @return FinancialResult
     */
    public function holdVitrineFunds(
        int    $listingId,
        int    $buyerId,
        int    $sellerId,
        string $amount,
        ?string $idempotencyKey = null
    ): array {
        $payload = ['listing_id' => $listingId, 'buyer_id' => $buyerId, 'seller_id' => $sellerId, 'amount' => $amount];
        return $this->executeWithIdempotency($idempotencyKey, $buyerId, "hold_vitrine_{$listingId}", function() use ($listingId, $buyerId, $sellerId, $amount, $payload) {
            // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کانونیکال در ابتدای بخش Social Task Escrow همین کلاس
            $result = $this->db->transactional(function () use ($listingId, $buyerId, $sellerId, $amount, $payload) {
            return $this->saga
                ->setSaga('hold_vitrine_escrow', $payload)
                ->addStep(
                    'verify_and_lock_buyer_balance',
                    function () use ($buyerId, $amount) {
                        // 🔒 Pessimistically lock the wallet row to prevent TOCTOU race conditions (BUG-02)
                        $this->db->query("SELECT id FROM wallets WHERE user_id = ? FOR UPDATE", [(int)$buyerId])->fetch();

                        // ✅ Verify buyer
                        $buyerBalance = $this->wallet->getBalanceForUpdate($buyerId, 'usdt');

                        $buyerMoney = Money::fromString($buyerBalance, 'usdt');
                        $amountMoney = Money::fromString($amount, 'usdt');

                        if ($amountMoney->isGreaterThan($buyerMoney)) {
                            throw new \Core\Exceptions\InsufficientBalanceException('موجودی حساب کافی نیست');
                        }
                        return true;
                    },
                    function () {}
                )
                ->addStep(
                    'create_escrow_record',
                    function () use ($listingId, $buyerId, $sellerId, $amount) {
                        // ✅ Hold escrow
                        // FIX-R19-A3-2: کلید idempotency رکورد — مسیر همزمان نباید دو escrow برای یک آگهی بسازد
                        $result = $this->escrow->holdFunds(
                            $listingId,
                            'vitrine_listing',
                            $buyerId,
                            $sellerId,
                            $amount,
                            'USDT',
                            "vitrine_escrow_record_{$listingId}"
                        );

                        if (!$result['ok'] || !isset($result['escrow_id'])) {
                            throw new \Core\Exceptions\ApplicationException('خطا در ایجاد صندوق امانات: ' . ($result['error'] ?? 'خطای نامشخص'));
                        }
                        // FIX-R19-A3-3: escrow_id را به context saga تزریق می‌کنیم تا گام hold wallet آن را در metadata ثبت کند
                        return ['escrow_id' => (int)$result['escrow_id']];
                    },
                    function ($error) use ($listingId) {
                        $this->logger->warning('saga_compensate: cancelling vitrine escrow record', ['listing_id' => $listingId]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'cancelled' WHERE order_id = ? AND order_type = ? AND status = 'pending'")
                                 ->execute([$listingId, 'vitrine_listing']);
                    }
                )
                ->addStep(
                    'deduct_wallet_balance',
                    function ($stepContext) use ($buyerId, $amount, $listingId) {
                        // ✅ Deduct from buyer - calling withdraw since we are inside a database transaction
                        $this->assertFraudAllowed((int)$buyerId, 'escrow.hold', []);
                        // FIX-R19-A3-2: نتیجه withdraw نادیده گرفته نمی‌شود — شکست قفل وجه باید saga را متوقف کند
                        // FIX-R19-A3-3: escrow_id در metadata hold ثبت می‌شود تا تسویه بعدی با مطابقت دقیق انجام شود
                        $escrowId = is_array($stepContext) ? (int)($stepContext['escrow_id'] ?? 0) : (int)$stepContext;
                        $withdraw = $this->wallet->withdraw($buyerId, $amount, 'usdt', [
                            'type' => 'vitrine_escrow',
                            'listing_id' => $listingId,
                            'ref_id' => $listingId,
                            'ref_type' => 'vitrine_listing',
                            // 🛡️ FIX-S36-B15-S07: کلید چرخه‌آگاه — escrowId در کلید و متادیتا
                            'idempotency_key' => "vitrine_escrow_hold_{$listingId}_{$escrowId}",
                            'escrow_id' => $escrowId,
                        ]);
                        if (empty($withdraw['success'])) {
                            throw new \Core\Exceptions\ApplicationException($this->resultMessage($withdraw, 'message', 'قفل‌کردن وجه خرید ویترین انجام نشد'));
                        }
                        return $stepContext;
                    },
                    function ($error) use ($buyerId, $amount, $listingId) {
                        $this->logger->warning('saga_compensate: reverting wallet deduction', ['buyer_id' => $buyerId]);
                        $this->wallet->deposit($buyerId, $amount, 'usdt', [
                            'type' => 'saga_compensation',
                            'listing_id' => $listingId
                        ]);
                    }
                )
                ->execute();
            });

            $escrow = $this->escrow->getByOrder($listingId, 'vitrine_listing');
            if ($escrow === null) {
                throw new \Core\Exceptions\ApplicationException('رکورد صندوق امانات ویترین پس از نگهداری یافت نشد');
            }
            $escrow = $this->requireEscrowRow($escrow);
            return ['ok' => true, 'escrow_id' => (int)$escrow->id];
        }, $payload);
    }

    /**
     * تحویل پول به فروشنده (ویترین)
     * @return FinancialResult
     */
    public function releaseVitrineFunds(int $listingId, int $sellerId, string $amount, ?string $idempotencyKey = null): array
    {
        $payload = ['listing_id' => $listingId, 'seller_id' => $sellerId, 'amount' => $amount];
        return $this->executeWithIdempotency($idempotencyKey, $sellerId, "release_vitrine_{$listingId}", function () use ($listingId, $sellerId, $amount) {
            try {
                return $this->db->transactional(function () use ($listingId, $sellerId, $amount) {
                    $escrow=$this->db->fetch('SELECT * FROM escrow_transactions WHERE order_id=? AND order_type=? ORDER BY id DESC LIMIT 1 FOR UPDATE',[$listingId,'vitrine_listing']);
                    if(!$escrow) throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                    $escrow = $this->requireEscrowRow($escrow);
                    if((int)$escrow->seller_id!==$sellerId) throw new \Core\Exceptions\SecurityException('عدم تطابق فروشنده با صندوق امانات');
                    if((string)$escrow->status==='released') return ['ok'=>true,'already_released'=>true];
                    if((string)$escrow->status!=='in_escrow') throw new \Core\Exceptions\InvalidStateException('وضعیت صندوق امانات نامعتبر است');
                    if(bccomp((string)$escrow->amount,$amount,8)!==0) throw new \Core\Exceptions\InvalidStateException('مبلغ تسویه با مبلغ escrow مطابقت ندارد');
                    $currency=strtolower((string)$escrow->currency)==='usdt'?'usdt':'irt';
                    $commissionSetting = $this->appSettings->get('vitrine_commission_percent', '5');
                    if (!is_scalar($commissionSetting) || trim((string)$commissionSetting) === '') {
                        throw new \UnexpectedValueException('درصد کارمزد ویترین معتبر نیست');
                    }
                    $commissionPercent = (string)$commissionSetting;
                    $total=Money::fromString($amount,$currency);$commission=$total->percentage($commissionPercent);$net=$total->subtract($commission);
                    $hold=$this->findEscrowHoldTransaction((int)$escrow->buyer_id,'vitrine_escrow',(string)$escrow->order_id,(string)$escrow->amount,$currency,(int)$escrow->id);
                    if(!$hold) throw new \Core\Exceptions\NotFoundException('تراکنش نگهداری وجه امانی یافت نشد');
                    $release=$this->escrow->releaseFunds((int)$escrow->id,$sellerId,'vitrine_sale_complete');
                    if(empty($release['ok'])) throw new \Core\Exceptions\ApplicationException($this->resultMessage($release, 'error', 'خطا در آزادسازی وجه امانی'));
                    if(!$net->isZero()) {
                        $spend=$this->wallet->spendLockedFunds((int)$escrow->buyer_id,$net->getAmount(),$currency,['type'=>'vitrine_seller_spend','ref_id'=>(int)$escrow->id,'ref_type'=>'escrow','description'=>"تسویه فروش ویترین #{$listingId}",'ledger_credit_account'=>'escrow_payout','idempotency_key'=>"vitrine_seller_spend_{$listingId}"]);
                        if(empty($spend['success'])) throw new \Core\Exceptions\ApplicationException($this->resultMessage($spend, 'message', 'مصرف سهم فروشنده ناموفق بود'));
                        $payout=$this->wallet->deposit($sellerId,$net->getAmount(),$currency,['type'=>'vitrine_sale','listing_id'=>$listingId,'ref_id'=>$listingId,'ref_type'=>'vitrine_listing','description'=>"درآمد فروش ویترین #{$listingId}",'ledger_debit_account'=>'escrow_payout','idempotency_key'=>"vitrine_payout_{$listingId}"]);
                        if(empty($payout['success'])) throw new \Core\Exceptions\ApplicationException($this->resultMessage($payout, 'message', 'واریز فروشنده ناموفق بود'));
                    }
                    if(!$commission->isZero()) {
                        $fee=$this->wallet->spendLockedFunds((int)$escrow->buyer_id,$commission->getAmount(),$currency,['type'=>'vitrine_platform_fee','ref_id'=>(int)$escrow->id,'ref_type'=>'escrow','description'=>"کارمزد فروش ویترین #{$listingId}",'ledger_credit_account'=>'platform_revenue','idempotency_key'=>"vitrine_platform_fee_{$listingId}"]);
                        if(empty($fee['success'])) throw new \Core\Exceptions\ApplicationException($this->resultMessage($fee, 'message', 'مصرف کارمزد ناموفق بود'));
                    }
                    if(!$this->wallet->finalizeLockedSpend((int)$escrow->buyer_id,(string)$hold->transaction_id)) throw new \Core\Exceptions\ApplicationException('نهایی‌سازی hold خریدار ناموفق بود');
                    return ['ok'=>true,'net_amount'=>$net->getAmount(),'commission'=>$commission->getAmount()];
                });
            }catch(\Throwable $e){$this->captureEscrowException($e,'releaseVitrineFunds',['listing_id'=>$listingId]);return['ok'=>false,'error'=>$e->getMessage()];}
        },$payload);
    }

    /**
     * بازگرداندی پول به خریدار (ویترین)
     * @return FinancialResult
     */
    public function refundVitrineFunds(int $listingId, int $buyerId, string $reason, ?string $idempotencyKey = null, ?callable $inTxHook = null): array
    {
        return $this->refundOrderEscrow($listingId, 'vitrine_listing', $buyerId, $reason, 'vitrine_refund', $idempotencyKey, $inTxHook);
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Common Dispute Handling
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Mark escrow as disputed (freezes funds)
     * @return FinancialResult
     */
    public function markEscrowDisputed(int $orderId, string $orderType, string $reason, ?string $idempotencyKey = null): array
    {
        $payload = ['order_id' => $orderId, 'order_type' => $orderType, 'reason' => $reason];
        $escrowForUser = $this->escrow->getByOrder($orderId, $orderType);
        $idempotencyUserId = $escrowForUser === null
            ? 1
            : (int)$this->requireEscrowRow($escrowForUser)->buyer_id;
        return $this->executeWithIdempotency($idempotencyKey, $idempotencyUserId, "mark_disputed_{$orderType}_{$orderId}", function() use ($orderId, $orderType, $reason, $payload) {
            try {
                // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کانونیکال در ابتدای بخش Social Task Escrow همین کلاس
                $result = $this->db->transactional(function () use ($orderId, $orderType, $reason, $payload) {
                    $stepResult = null;
                    $this->saga->setSaga('mark_escrow_disputed', $payload)->addStep(
                        'mark_escrow_disputed',
                        function () use ($orderId, $orderType, $reason, &$stepResult) {
                            $escrow = $this->escrow->getByOrder($orderId, $orderType);
                            if (!$escrow) {
                                throw new \Core\Exceptions\NotFoundException('صندوق امانات یافت نشد');
                            }
                            $escrow = $this->requireEscrowRow($escrow);

                            $stepResult = $this->escrow->markAsDisputed((int)$escrow->id, $reason);
                            if (!$stepResult['ok']) {
                                throw new \Core\Exceptions\ApplicationException($stepResult['error'] ?? 'خطا در ثبت وضعیت اختلاف');
                            }
                            return true;
                        },
                        function () {}
                    )->execute();
                    return $stepResult;
                });

                return $result;
            } catch (\Throwable $e) {
            $this->captureEscrowException($e, 'markEscrowDisputed');
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    /**
     * Resolve dispute and release/refund based on verdict
     * @return FinancialResult
     */
    public function resolveDisputedEscrow(
        int    $orderId,
        string $orderType,
        string $verdict,
        string $refundPercent,
        ?string $idempotencyKey = null
    ): array {
        if (!is_numeric($refundPercent) || bccomp($refundPercent, '0', 8) < 0 || bccomp($refundPercent, '100', 8) > 0) {
            return ['ok' => false, 'error' => 'Refund percentage must be between 0 and 100'];
        }
        $payload = ['order_id' => $orderId, 'order_type' => $orderType, 'verdict' => $verdict, 'refund_percent' => $refundPercent];
        $escrowForUser = $this->escrow->getByOrder($orderId, $orderType);
        $idempotencyUserId = $escrowForUser === null
            ? 1
            : (int)$this->requireEscrowRow($escrowForUser)->buyer_id;
        return $this->executeWithIdempotency($idempotencyKey, $idempotencyUserId, "resolve_disputed_{$orderType}_{$orderId}", function() use ($orderId, $orderType, $verdict, $refundPercent, $payload) {
            try {
                // BUGFIX-SAGA-TX-ROOT: رجوع به توضیح کانونیکال در ابتدای بخش Social Task Escrow همین کلاس
                $releaseAmount = null;
                $refundAmount = null;
                $feeAmount = null;

                $this->db->transactional(function () use ($orderId, $orderType, $verdict, $refundPercent, $payload, &$releaseAmount, &$refundAmount, &$feeAmount) {
                return $this->saga->setSaga('resolve_disputed_escrow', $payload)->addStep(
                    'verify_and_resolve_dispute',
                    function () use ($orderId, $orderType, $verdict, $refundPercent, &$releaseAmount, &$refundAmount, &$feeAmount) {
                        $escrow = $this->escrow->getByOrder($orderId, $orderType);
                        if (!$escrow) {
                            throw new \Core\Exceptions\InvalidStateException('پرونده در وضعیت اختلاف نیست');
                        }
                        $escrow = $this->requireEscrowRow($escrow);
                        if ($escrow->status !== 'disputed') {
                            throw new \Core\Exceptions\InvalidStateException('پرونده در وضعیت اختلاف نیست');
                        }

                        // FIX-S25-P1-F12 (scale): محاسبهٔ قبلی با Money::fromString
                        // بدون ارز (IRT/4dp) بود؛ برای escrowهای USDT با بیش از ۴ رقم
                        // اعشار، refund+release دیگر دقیقاً برابر amount نمی‌شد و گارد
                        // تساویِ resolveDisputePartial می‌سوخت. (متغیر $scale هم
                        // محاسبه می‌شد ولی هرگز مصرف نمی‌شد.) اکنون مستقیم با bcmath
                        // در 8dp: جمعِ دو سهم همیشه دقیقاً برابر amount است.
                        $percent = bcdiv($refundPercent, '100', 8);
                        $refundAmount = bcmul((string)$escrow->amount, $percent, 8);
                        $releaseAmount = bcsub((string)$escrow->amount, $refundAmount, 8);

                        // 🛡️ FIX-S37-B15-P1 (S15-19 — سیاست مصوب مالک): کارمزد مسیر اختلاف.
                        // – کار انجام نشود (favor_customer/refund=100): خریدار ۱۰۰٪ وجه را
                        //   پس می‌گیرد؛ سهم کارمزد هم ضمن همین بازگشت به کارفرما برمی‌گردد.
                        // – انجام‌دهنده برنده شود (favor_influencer/refund=0): کارمزد از مبلغ
                        //   کسر می‌شود؛ سهم آزادشده به فروشنده خالصِ کارمزد است و کارمزد
                        //   مستقیم به platform_revenue می‌رود (هم‌الگوی مسیر عادی).
                        // – partial: کارمزد به‌تناسبِ بخش آزادشده اعمال می‌شود
                        //   (fee = release × fullFee/amount) تا مجموع سه‌سهم همیشه amount باشد.
                        $feeAmount = $this->disputePlatformFeeAmount($escrow, $releaseAmount);

                        // FIX-S25-P1-F1 (single-settler — بخش ۱): شناسهٔ hold تراکنش
                        // «قبل از» تسویه (وقتی amount هنوز اصلی است) پیدا و به ctx
                        // داده می‌شود؛ گام دوم فقط bookkeeping آن را می‌بندد.
                        $currency = strtolower((string)$escrow->currency) === 'usdt' ? 'usdt' : 'irt';
                        $hold = $this->findEscrowHoldTransaction(
                            (int)$escrow->buyer_id,
                            $this->escrowHoldType($escrow),
                            (string)$escrow->order_id,
                            (string)$escrow->amount,
                            $currency,
                            (int)$escrow->id
                        );
                        $holdTxId = $hold !== null ? (string)$hold->transaction_id : null;

                        $result = $this->escrow->resolveDisputePartial(
                            (int)$escrow->id,
                            (int)$escrow->buyer_id,
                            (int)$escrow->seller_id,
                            $refundAmount,
                            $releaseAmount,
                            'admin_dispute_resolution',
                            $verdict,
                            null,
                            $feeAmount
                        );

                        if (!$result['ok']) {
                            throw new \Core\Exceptions\ApplicationException($result['error'] ?? 'خطا در حل‌وفصل اختلاف');
                        }
                        return [
                            'escrow_id' => (int)$escrow->id,
                            'buyer_id' => (int)$escrow->buyer_id,
                            'hold_tx_id' => $holdTxId,
                            'release_amount' => $releaseAmount,
                            'refund_amount' => $refundAmount,
                            'fee_amount' => $feeAmount,
                        ];
                    },
                    function ($error) use ($orderId, $orderType) {
                        $this->logger->warning('saga_compensate: reverting dispute resolution', ['order_id' => $orderId, 'order_type' => $orderType]);
                        $this->db->prepare("UPDATE escrow_transactions SET status = 'disputed', released_at = NULL, released_by = NULL WHERE order_id = ? AND order_type = ?")
                                 ->execute([$orderId, $orderType]);
                    }
                )->addStep(
                    // FIX-S25-P1-F1 (single-settler — بخش ۲): گام دوم قبلی
                    // «deposit_resolved_funds» علاوه بر settleEscrowHold (لغو hold
                    // با حرکت پول!) دوباره spendReleasedBuyerAmount + deposit(seller)
                    // اجرا می‌کرد — تسویهٔ دوبل روی پاهای مالی گام اول؛ و عملاً هم
                    // هیچ‌وقت نمی‌رسید: settleEscrowHold با amount=0ِ صفرشدهٔ گام اول
                    // findEscrowHoldTransaction را می‌باخت ⇒ NotFoundException ⇒
                    // rollback همیشگی کل رأی (اختلاف‌ها stuck با وجه قفل‌شده).
                    // اکنون گام دوم فقط bookkeepingِ بستن ردیف hold است (پایان‌حالت
                    // بر اساس سهم آزادشده: spend→completed، refund→cancelled —
                    // هم‌مفهوم finalizeLockedSpend/Refund) — بدون هیچ حرکت پولی؛
                    // پاهای مالی تنها در resolveDisputePartial (گام اول) هستند.
                    'finalize_hold_tx',
                    function (array $ctx) {
                        $holdTxId = $ctx['hold_tx_id'] ?? null;
                        if (!is_string($holdTxId) || $holdTxId === '') {
                            $this->logger->warning('financial_escrow.dispute_hold_tx_missing', ['escrow_id' => $ctx['escrow_id'] ?? null]);
                            return $ctx;
                        }
                        $hasRelease = bccomp((string)($ctx['release_amount'] ?? '0'), '0', 8) > 0;
                        // FIX-S25 (اصلاح PHPStan): ترتیب آرگومان‌های قرارداد S24:
                        // (userId, transactionId) — در نگارش اولیهٔ این بچ برعکس
                        // بود و PHPStan گرفت.
                        $finalized = $hasRelease
                            ? $this->wallet->finalizeLockedSpend((int)($ctx['buyer_id'] ?? 0), $holdTxId)
                            : $this->wallet->finalizeLockedRefund((int)($ctx['buyer_id'] ?? 0), $holdTxId);
                        if (!$finalized) {
                            throw new \Core\Exceptions\ApplicationException('نهایی‌سازی hold اختلاف ناموفق بود');
                        }
                        return $ctx;
                    },
                    function ($error) use ($orderId) {
                        // rollback تراکنش root همه‌چیز را برمی‌گرداند
                        $this->logger->warning('saga_compensate: dispute hold finalize failed', ['order_id' => $orderId]);
                    }
                )->execute();
                });

                return ['ok' => true, 'released' => $releaseAmount, 'refunded' => $refundAmount, 'fee_amount' => $feeAmount];

            } catch (\Throwable $e) {
            $this->captureEscrowException($e, 'resolveDisputedEscrow');
                return ['ok' => false, 'error' => $e->getMessage()];
            }
        }, $payload);
    }

    /**
     * 🛡️ FIX-S37-B15-P1 (S15-19): محاسبهٔ سهم کارمزد پلتفرم در تسویهٔ اختلاف.
     *
     * منبع حقیقت کارمزد سفارش اینفلوئنسر همان مسیر عادی است:
     * fullFee = amount − influencer_earning (سهم سایت ثبت‌شده هنگام ساخت سفارش).
     * برای رأی جزئی، کارمزد به‌تناسبِ بخش آزادشده اعمال می‌شود:
     *   fee = releaseAmount × fullFee / amount
     * و سهم فروشنده = releaseAmount − fee (مشتق با تفریق ⇒ صفر رَندشدن؛
     * جمع refund+seller+fee همیشه دقیقاً amount می‌ماند).
     * fail-open محدود: سفارش غایب/دادهٔ ناسازگار ⇒ کارمزد صفر + هشدار —
     * تسویهٔ رأی ادمین هرگز به‌خاطر غیبت ردیف کارمزد متوقف نمی‌شود.
     */
    private function disputePlatformFeeAmount(\stdClass $escrow, string $releaseAmount): string
    {
        if ((string)$escrow->order_type !== 'influencer_order' || bccomp($releaseAmount, '0', 8) <= 0) {
            return '0.00000000';
        }
        $amount = (string)$escrow->amount;
        if (bccomp($amount, '0', 8) <= 0) {
            return '0.00000000';
        }
        $orderRow = $this->db->fetch(
            "SELECT influencer_earning FROM story_orders WHERE id = ? LIMIT 1",
            [(string)$escrow->order_id]
        );
        $earning = null;
        if (is_array($orderRow)) {
            $earning = $orderRow['influencer_earning'] ?? null;
        } elseif ($orderRow !== null) {
            $earning = $orderRow->influencer_earning ?? null;
        }
        if ($earning === null || !is_numeric((string)$earning)) {
            $this->logger->warning('escrow.dispute_fee.order_missing', [
                'escrow_id' => (int)$escrow->id,
                'order_id' => (string)$escrow->order_id,
            ]);
            return '0.00000000';
        }
        $fullFee = bcsub($amount, (string)$earning, 8);
        if (bccomp($fullFee, '0', 8) < 0) {
            // دادهٔ ناسازگار (earning > amount) ⇒ کارمزد منفی بی‌معناست؛ صفر و هشدار.
            $this->logger->warning('escrow.dispute_fee.negative_full_fee_clamped', [
                'escrow_id' => (int)$escrow->id,
                'amount' => $amount,
                'earning' => (string)$earning,
            ]);
            $fullFee = '0';
        }
        if (bccomp($fullFee, '0', 8) === 0) {
            return '0.00000000';
        }
        $fee = bcdiv(bcmul($releaseAmount, $fullFee, 8), $amount, 8);
        if (bccomp($fee, $releaseAmount, 8) > 0) {
            $fee = $releaseAmount;
        }
        return $fee;
    }

    /**
     * Cron task to automatically release expired holds back to the advertiser.
     * CRITICAL-NEW-02: Prevent funds from being locked forever if executor never submits proof.
     *
     * 🛡️ FIX-S37-B15-P2 (C03 — سیاست مصوب مالک): انقضای خودکار دو لایه شد:
     * - pending (رفتار پیشین، escrow_expiry_hours=48h پیش‌فرض) — امانتِ بدون تأیید
     * - in_escrow (تازه) — امانتِ تأییدشده‌ای که ۳۰ روز (escrow_in_escrow_expiry_days)
     *   بدون آزادسازی/حل اختلاف مانده؛ سقف = expires_atِ موجود ردیف (اگر تنظیم شده
     *   باشد، هرکدام زودتر برسد ملاک است)؛ پس از انقضا وجه به خریدار بازمی‌گردد و
     *   هم خریدار و هم فروشنده اعلان دریافت می‌کنند (اتمیک با refund در outbox).
     */
    public function releaseExpiredHolds(): int
    {
        return $this->releaseExpiredHoldsByStatus('pending')
             + $this->releaseExpiredHoldsByStatus('in_escrow');
    }

    /**
     * انواع منقضی‌شونده بر اساس قرارداد واقعی order_type dispatch می‌شوند:
     * - social_task_execution / influencer_order / vitrine_listing / custom_deal
     *   از مسیر refund canonical خودشان
     * - custom_task / lottery_participation از مسیر generic locked-hold refund
     */
    private function releaseExpiredHoldsByStatus(string $status): int
    {
        if ($status === 'pending') {
            $expirySetting = $this->appSettings->get('escrow_expiry_hours', 48);
            $expiredHours = is_scalar($expirySetting)
                ? max(1, min(8760, (int)$expirySetting))
                : 48;
            $deadlineParam = (int)$expiredHours;
            $deadlineSql = 'e.held_at < DATE_SUB(NOW(), INTERVAL ? HOUR)';
            $reasonSuffix = 'auto_expired_after_' . $expiredHours . 'h';
            $notifyTitle = 'بازگشت خودکار وجه امانی ⏰';
            $notifyTpl = static fn (string $amountStr): string =>
                "به دلیل عدم تایید در مهلت مقرر ({$expiredHours} ساعت)، مبلغ {$amountStr} امانی شما به کیف پولتان بازگشت داده شد.";
        } elseif ($status === 'in_escrow') {
            $daysSetting = $this->appSettings->get('escrow_in_escrow_expiry_days', 30);
            $expiryDays = is_scalar($daysSetting)
                ? max(1, min(3650, (int)$daysSetting))
                : 30;
            $deadlineParam = (int)$expiryDays;
            // FIX-S37-B15-P2 (C03): مهلت = COALESCE(confirmed_at, held_at) + D روز،
            // «تا سقف expires_at موجود» — یعنی اگر expires_at زودتر تنظیم شده باشد،
            // همان زودتر ملاک انقضا است (معنای MIN دو مهلت: هرکدام گذشته باشد کافی است).
            $deadlineSql = '(DATE_ADD(COALESCE(e.confirmed_at, e.held_at), INTERVAL ? DAY) <= NOW() OR (e.expires_at IS NOT NULL AND e.expires_at <= NOW()))';
            $reasonSuffix = 'auto_expired_in_escrow_after_' . $expiryDays . 'd';
            $notifyTitle = 'انقضای خودکار اسکرو تأییدشده ⏰';
            $notifyTpl = static fn (string $amountStr): string =>
                "پس از {$expiryDays} روز بدون آزادسازی یا حل اختلاف، مبلغ {$amountStr} امانی به کیف پول خریدار بازگشت داده شد.";
        } else {
            // فقط دو وضعیتِ سیاست‌گذاری‌شده منقضی می‌شوند؛ disputed/partial/... هرگز.
            return 0;
        }

        // The interval is materialized only after a strict integer bound, keeping
        // the SQL cutoff explicit without accepting a dynamic SQL fragment.
        // Concrete refund methods lock their individual escrow rows inside their
        // own transactions; FOR UPDATE on this discovery query would be released
        // immediately under autocommit and give a false sense of safety.
        $totalReleased = 0;
        $batchSize     = 200;
        $lastId        = 0;
        $guard         = 0;
        // cursor: هر batch حداکثر 200 ردیف؛ چون هر refund تراکنشی و سنگین است حافظه/زمان را
        // مهار می‌کنیم. ردیفِ refundشده دیگر با statusِ فیلتر خارج می‌شود؛
        // ردیف‌های ناموفق در همان status می‌مانند، پس cursorِ id لازم است تا دوباره انتخاب/لوپ نشوند.
        do {
            if (++$guard > 100000) {
                $this->logger->warning('escrow.release_expired.guard_tripped', ['last_id' => $lastId, 'status' => $status]);
                break;
            }

            // FIX-R19-A3-4: پارامترهای مقیدشده به‌صورت bind می‌شوند تا هیچ مقدارِ
            // پویایی داخل SQL درج نشود (شرط مهلت هم پارامتری است).
            $expired = $this->db->fetchAll(
                "SELECT e.*
                 FROM escrow_transactions e
                 WHERE e.status = ?
                   AND {$deadlineSql}
                   AND e.id > ?
                 ORDER BY e.id ASC
                 LIMIT ?",
                [$status, $deadlineParam, $lastId, (int)$batchSize]
            ) ?: [];
            $fetched = count($expired);

        foreach ($expired as $row) {
            try {
                $rawId = is_object($row) ? (int)($row->id ?? 0) : (int)(($row['id'] ?? 0));
                if ($rawId > $lastId) {
                    $lastId = $rawId;
                }
                $row = $this->requireEscrowRow($row);
                // 🛡️ FIX-S36-B15-S12: ثبت قصد اعلان «داخل» تراکنش بازپرداخت — قبلاً
                // record() بعد از commitِ refund و در try/catchِ بی‌اثر (warning-only)
                // بود؛ شکستش یعنی بازپرداخت موفق بدون هیچ intent پایدارِ اعلان و اسکن
                // بعدی هرگز آن را جبران نمی‌کرد. اکنون قلاب درون‌تراکنشی
                // intent را اتمیک با جابه‌جایی وجه می‌کند: شکست ⇒ rollback بازپرداخت ⇒
                // ردیف در همان status می‌ماند و اجرای بعدی دوباره refund+اعلان را با هم انجام می‌دهد.
                // FIX-S37-B15-P2: در مسیر in_escrow فروشنده هم اعلان می‌گیرد (وجه به
                // خریدار برگشته) — intent دوم، همان تراکنش، همان تضمین اتمیسیتی.
                $escrowRowRef = $row;
                $notifyHook = function (int $hookEscrowId, int $buyerId, string $amountStr, string $currency) use ($status, $notifyTitle, $notifyTpl, $escrowRowRef) {
                    if ($buyerId > 0) {
                        $this->outboxService?->record('notification', $buyerId, 'notification.requested', [
                            'user_id'    => $buyerId,
                            'type'       => 'escrow_auto_released',
                            'title'      => $notifyTitle,
                            'message'    => $notifyTpl($amountStr),
                            'data'       => [
                                'escrow_id'   => (int)($escrowRowRef->id ?? $hookEscrowId),
                                'order_type'  => (string)($escrowRowRef->order_type ?? ''),
                                'order_id'    => (int)($escrowRowRef->order_id ?? 0),
                                'amount'      => $amountStr,
                            ],
                            'action_url' => '/wallet',
                        ]);
                    }
                    if ($status === 'in_escrow') {
                        $sellerId = (int)($escrowRowRef->seller_id ?? 0);
                        if ($sellerId > 0 && $sellerId !== $buyerId) {
                            $this->outboxService?->record('notification', $sellerId, 'notification.requested', [
                                'user_id'    => $sellerId,
                                'type'       => 'escrow_auto_released_seller',
                                'title'      => 'انقضای خودکار اسکرو سفارش ⏰',
                                'message'    => "مهلت اسکرو سفارش #{$escrowRowRef->order_id} بدون تسویه منقضی شد و مبلغ {$amountStr} به خریدار بازگشت داده شد.",
                                'data'       => [
                                    'escrow_id'   => (int)($escrowRowRef->id ?? $hookEscrowId),
                                    'order_type'  => (string)($escrowRowRef->order_type ?? ''),
                                    'order_id'    => (int)($escrowRowRef->order_id ?? 0),
                                    'amount'      => $amountStr,
                                ],
                                'action_url' => '/wallet',
                            ]);
                        }
                    }
                };

                switch ($row->order_type) {
                    case 'social_task_execution':
                        $result = $this->refundSocialTaskFunds((int)$row->order_id, (int)$row->buyer_id, $reasonSuffix, null, $notifyHook);
                        break;
                    case 'vitrine_listing':
                        $result = $this->refundVitrineFunds((int)$row->order_id, (int)$row->buyer_id, $reasonSuffix, null, $notifyHook);
                        break;
                    case 'influencer_order':
                        $result = $this->refundInfluencerOrderFunds((int)$row->order_id, (int)$row->buyer_id, $reasonSuffix, null, $notifyHook);
                        break;
                    case 'custom_deal':
                        $result = $this->refundCustomDealFunds((int)$row->id, (int)$row->buyer_id, $reasonSuffix, null, $notifyHook);
                        break;
                    case 'custom_task':
                    case 'lottery_participation':
                        $this->refundGenericFunds((int)$row->id, (int)$row->buyer_id, $row->order_type, $reasonSuffix, $notifyHook);
                        $result = ['ok' => true];
                        break;
                    default:
                        $this->logger->warning('escrow.unknown_order_type_on_release', [
                            'escrow_id' => $row->id,
                            'order_type' => $row->order_type,
                            'status' => $status,
                        ]);
                        continue 2;
                }

                if (!empty($result['ok'])) {
                    $totalReleased++;
                    // FIX-S36-B15-S12: اعلان داخل تراکنشِ بازپرداخت ثبت شد (بالای)؛
                    // بلوک warn-onlyِ پس از commit حذف شد.
                }
            } catch (\Throwable $e) {
                $this->captureEscrowException($e, 'releaseExpiredHolds');
                $this->logger->error('escrow.release_failed_for_row', [
                    'escrow_id' => $row->id ?? 0,
                    'order_type' => $row->order_type ?? 'unknown',
                    'status' => $status,
                    'error' => $e->getMessage(),
                ]);
            }
        }
        } while ($fetched === $batchSize);

        return $totalReleased;
    }

    /**
     * Generic refund for non-specific escrow types
     */
    /**
     * Generic refund for non-specific escrow types.
     * 🛡️ Atomicity: wrapped in DB transaction to prevent double-refund race conditions.
     * Matches the saga-based pattern used by refundSocialTaskFunds/refundVitrineFunds.
     */
    private function refundGenericFunds(
        int $escrowId,
        int $buyerId,
        string $orderType,
        string $reason,
        ?callable $inTxHook = null
    ): void {
        // FIX-S36-B15-S12: قلاب درون‌تراکنشی ثبت قصد اعلان (اتمیک با refund)
        $this->db->transactional(function () use ($escrowId, $buyerId, $orderType, $reason, $inTxHook) {
            // 1. Lock escrow row FOR UPDATE to prevent concurrent refunds
            $escrow = $this->db->fetch(
                "SELECT * FROM escrow_transactions WHERE id = ? FOR UPDATE",
                [$escrowId]
            );

            if (!$escrow) {
                $this->logger->warning('escrow.refund_not_found', ['escrow_id' => $escrowId]);
                return;
            }
            $escrow = $this->requireEscrowRow($escrow);

            // 2. Guard: only refund pending or in_escrow rows
            if (!in_array((string)$escrow->status, ['pending', 'in_escrow'], true)) {
                $this->logger->warning('escrow.already_processed', [
                    'escrow_id' => $escrowId,
                    'status'    => $escrow->status,
                ]);
                return;
            }

            // 3. Settle the hold (cancel mode releases locked funds)
            $this->settleEscrowHold($escrow, 'cancel', (string)$escrow->amount);

            // 4. Update escrow status atomically
            $this->db->query(
                "UPDATE escrow_transactions
                 SET status = 'refunded', refunded_at = NOW(), refund_reason = ?,
                     refunded_by = 'escrow_timeout_job', updated_at = NOW()
                 WHERE id = ? AND status IN ('pending', 'in_escrow')",
                [$reason, $escrowId]
            );

            if ($inTxHook !== null) {
                $inTxHook($escrowId, $buyerId, (string)$escrow->amount, 'irt');
            }

            $this->logger->info('escrow.auto_released', [
                'escrow_id' => $escrowId,
                'order_type' => $orderType,
                'buyer_id' => $buyerId,
                'amount' => (string)$escrow->amount,
            ]);
        });
    }


    /**
     * Database rows are dynamic stdClass values. Validate the financial columns once
     * at the boundary, then use a precise contract throughout settlement code.
     *
     * @param object $escrow
     * @return EscrowRow
     */
    private function requireEscrowRow(object $escrow): object
    {
        foreach (['id', 'order_id', 'order_type', 'buyer_id', 'seller_id', 'amount', 'currency', 'status'] as $field) {
            if (!isset($escrow->{$field}) || !is_scalar($escrow->{$field})) {
                throw new \UnexpectedValueException("Invalid escrow row: missing or non-scalar {$field}");
            }
        }

        /** @var EscrowRow $escrow */
        return $escrow;
    }

    /**
     * @param object $transaction
     * @return EscrowHoldRow
     */
    private function requireEscrowHoldRow(object $transaction): object
    {
        if (!isset($transaction->transaction_id) || !is_string($transaction->transaction_id)
            || !isset($transaction->amount) || !is_scalar($transaction->amount)) {
            throw new \UnexpectedValueException('Invalid escrow hold transaction row');
        }

        /** @var EscrowHoldRow $transaction */
        return $transaction;
    }

    /**
     * FIX-S25-P1-F1: نگاشت order_type به نوع hold تراکنش (یک منبع حقیقت —
     * قبلاً در settleEscrowHold تکرار می‌شد و در گام اولِ resolveDisputedEscrow
     * هم لازم شد).
     * @param EscrowRow $escrow
     */
    private function escrowHoldType(object $escrow): string
    {
        return match ((string)$escrow->order_type) {
            'influencer_order' => 'influencer_escrow',
            'vitrine_listing', 'vitrine' => 'vitrine_escrow',
            'social_task_execution' => 'social_task_escrow',
            'custom_deal' => 'custom_deal_escrow',
            default => 'escrow_hold',
        };
    }

    /** @param EscrowRow $escrow */
    private function settleEscrowHold(object $escrow, string $mode, ?string $amount = null): void
    {
        $currency = strtolower((string)$escrow->currency) === 'usdt' ? 'usdt' : 'irt';
        $holdType = $this->escrowHoldType($escrow);

        $tx = $this->findEscrowHoldTransaction(
            (int)$escrow->buyer_id,
            $holdType,
            (string)$escrow->order_id,
            $amount ?? (string)$escrow->amount,
            $currency,
            (int)$escrow->id
        );

        if (!$tx) {
            throw new \Core\Exceptions\NotFoundException('تراکنش نگهداری وجه امانی یافت نشد');
        }

        if ($mode === 'complete') {
            if (!$this->wallet->completeWithdrawal((int)$escrow->buyer_id, (string)$tx->amount, $currency, (string)$tx->transaction_id)) {
                throw new \Core\Exceptions\ApplicationException('خطا در تکمیل تراکنش صندوق امانات');
            }
            return;
        }

        if ($mode === 'cancel') {
            if (!$this->wallet->cancelWithdrawal((int)$escrow->buyer_id, (string)$tx->amount, $currency, (string)$tx->transaction_id)) {
                throw new \Core\Exceptions\ApplicationException('خطا در لغو تراکنش صندوق امانات');
            }
            return;
        }

        throw new \InvalidArgumentException('Invalid escrow settlement mode');
    }

    /** @return EscrowHoldRow|null */
    private function findEscrowHoldTransaction(int $userId, string $type, string $orderId, string $amount, string $currency, ?int $escrowId = null): ?object
    {
        $currency = strtolower($currency) === 'usdt' ? 'usdt' : 'irt';

        // 🔒 AUDIT-FIX (financial review R5-P1 partial escrow): پس از partialRelease،
        // escrow->amount «باقی‌مانده» است درحالی‌که hold اصلی با مبلغ کامل ثبت شده.
        // مطابقتِ مبلغ‌محور hold را پیدا نمی‌کرد → refund escrow جزئی fail می‌شد.
        // تطابق metadata escrow_id مرجعِ معتبر است؛ اول با آن (بدون فیلتر مبلغ)
        // جست‌وجو می‌شود، سپس مسیرهای مبلغ‌محور قبلی به‌عنوان fallback.
        if ($escrowId !== null && $escrowId > 0) {
            $byEscrowId = $this->db->fetch(
                "SELECT * FROM transactions
                 WHERE user_id = ? AND type = 'withdraw' AND currency = ?
                   AND status IN ('pending', 'processing')
                   AND metadata LIKE ?
                   AND (metadata LIKE ? OR metadata LIKE ?)
                 ORDER BY id DESC LIMIT 1",
                [
                    $userId,
                    $currency,
                    '%"type":"' . $type . '"%',
                    '%"escrow_id":' . $escrowId . ',%',
                    '%"escrow_id":' . $escrowId . '}%',
                ]
            );
            if ($byEscrowId !== null) {
                return $this->requireEscrowHoldRow($byEscrowId);
            }
        }

        // FIX-R19-A3-3: اولویت با مطابقت دقیق escrow_id ثبت‌شده در metadata hold
        // (مرز `,` یا `}` تضمین می‌کند :12 روی :123 تطابق نکند). ردیف‌های قدیمی
        // فاقد این نشان به الگوی LIKE قبلی برمی‌گردند — سازگاری رو به عقب حفظ شده است.
        if ($escrowId !== null && $escrowId > 0) {
            $exact = $this->db->fetch(
                "SELECT * FROM transactions
                 WHERE user_id = ? AND type = 'withdraw' AND currency = ?
                   AND status IN ('pending', 'processing')
                   AND ABS(amount - ?) < 0.00000001
                   AND metadata LIKE ?
                   AND (metadata LIKE ? OR metadata LIKE ?)
                 ORDER BY id DESC LIMIT 1",
                [
                    $userId,
                    $currency,
                    $amount,
                    '%"type":"' . $type . '"%',
                    '%"escrow_id":' . $escrowId . ',%',
                    '%"escrow_id":' . $escrowId . '}%',
                ]
            );
            if ($exact !== null) {
                return $this->requireEscrowHoldRow($exact);
            }
        }

        // 🛡️ FIX-S36-B15-C01: مرز پایان عدد در الگوهای متنی fallback —
        // قبلاً %"order_id":12% با ۱۲۳ هم تطبیق می‌کرد (مسیر زندهٔ custom_deal
        // فاقد escrow_id بود)؛ اکنون فقط ,} یا } یا " پایانی تطبیق می‌دهد —
        // ردیف‌های جدید از مسیر دقیق escrow_id عبور می‌کنند.
        $transaction = $this->db->fetch(
            "SELECT * FROM transactions
             WHERE user_id = ? AND type = 'withdraw' AND currency = ?
               AND status IN ('pending', 'processing')
               AND ABS(amount - ?) < 0.00000001
               AND metadata LIKE ?
               AND (
                    ref_id = ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
                    OR metadata LIKE ?
               )
             ORDER BY id DESC LIMIT 1",
            [
                $userId,
                $currency,
                $amount,
                '%"type":"' . $type . '"%',
                $orderId,
                '%"order_id":' . $orderId . ',%',
                '%"order_id":' . $orderId . '}%',
                '%"order_id":' . $orderId . '"%',
                '%"listing_id":' . $orderId . ',%',
                '%"listing_id":' . $orderId . '}%',
                '%"listing_id":' . $orderId . '"%',
                '%"execution_id":' . $orderId . ',%',
                '%"execution_id":' . $orderId . '}%',
                '%"execution_id":' . $orderId . '"%',
            ]
        );

        return $transaction === null ? null : $this->requireEscrowHoldRow($transaction);
    }

    // 🧹 DEAD-CODE REMOVED (FIX-S25): spendReleasedBuyerAmount — تنها caller آن
    // گام دومِ قبلیِ resolveDisputedEscrow بود که با single-settler حذف شد؛
    // نگاه داشتنش مسیر withdraw موازی بدون لحاظ ترتیب تسویهٔ رأی بود.

    /**
     * INTERNAL_API: مصرف بخشی از یک بودجه قفل‌شده بدون واریز به کاربر دیگر.
     *
     * این متد ad-specific نیست؛ فقط escrow.amount و wallets.locked_* را اتمیک کم می‌کند.
     * برای درآمد پلتفرم/مصرف بودجه کمپین‌هایی استفاده می‌شود که seller user ندارند.
     * @return FinancialResult
     * @param array<string, mixed> $extraMetadata
     */
    public function consumeHeldBudget(
        int $escrowId,
        int $buyerId,
        string $amount,
        string $currency,
        string $reason,
        string $releasedBy = 'system',
        ?string $idempotencyKey = null,
        array $extraMetadata = []
    ): array {
        $operation = function () use ($escrowId, $buyerId, $amount, $currency, $reason, $releasedBy, $idempotencyKey, $extraMetadata) {
            if (bccomp($amount, '0', 8) <= 0) {
                return ['ok' => true, 'released' => '0'];
            }
            $currency = strtolower((string)$currency) === 'usdt' ? 'usdt' : 'irt';

            $escrow = $this->db->fetch(
                "SELECT * FROM escrow_transactions WHERE id = ? AND buyer_id = ? AND status IN ('pending','in_escrow','partial') FOR UPDATE",
                [$escrowId, $buyerId]
            );
            if (!$escrow) {
                return ['ok' => false, 'error' => 'Escrow not found or not consumable'];
            }
            $escrow = $this->requireEscrowRow($escrow);
            if (bccomp((string)$escrow->amount, $amount, 8) < 0) {
                return ['ok' => false, 'error' => 'Escrow amount is insufficient'];
            }

            // Consumption is not a refund. It removes funds from locked balance
            // and settles them to platform revenue without crediting the buyer.
            $spendKey = $idempotencyKey ?: hash('sha256', implode('|', [
                'escrow.consume', $escrowId, (string)$escrow->amount, $amount, $reason, $releasedBy,
            ]));
            $spendResult = $this->wallet->spendLockedFunds(
                $buyerId,
                $amount,
                $currency,
                [
                    'type' => 'escrow_budget_consumption',
                    'ref_id' => $escrowId,
                    'ref_type' => 'escrow',
                    'description' => $reason,
                    'ledger_credit_account' => 'platform_revenue',
                    'idempotency_key' => $spendKey,
                ] + $extraMetadata
            );
            if (empty($spendResult['success'])) {
                throw new \Core\Exceptions\ApplicationException($this->resultMessage($spendResult, 'message', 'خطا در مصرف بودجه قفل‌شده کیف پول'));
            }

            // FIX-S25-P0-2 / S25B-F10 (تقارن حصار replay): اگر پاکت کیف
            // «idempotent_replay» گزارش کرد یعنی پول حرکتی نکرده است؛ کاهش
            // ردیف escrow در این حالت = انحراف دائمی دفاتر (amount کم می‌شد
            // بدون هیچ debit واقعی و در پایان کمپین refundHeldBudget فقط
            // ماندهٔ صفرشده را آزاد می‌کرد). اکنون روی replay، ردیف escrow
            // دست‌نخورده می‌ماند و پاسخ با پرچم replay بازمی‌گردد.
            if (($spendResult['idempotent_replay'] ?? false) === true) {
                $this->logger->warning('financial_escrow.held_budget_consume_replay', [
                    'escrow_id' => $escrowId,
                    'buyer_id'  => $buyerId,
                    'amount'    => $amount,
                    'reason'    => $reason,
                ]);
                return ['ok' => true, 'released' => '0', 'remaining' => (string)$escrow->amount, 'status' => (string)$escrow->status, 'idempotent_replay' => true];
            }

            $remaining = bcsub((string)$escrow->amount, $amount, 8);
            if (bccomp($remaining, '0', 8) < 0) {
                $remaining = '0';
            }
            $status = bccomp($remaining, '0', 8) <= 0 ? 'released' : 'partial';
            $this->db->query(
                "UPDATE escrow_transactions
                 SET status = ?, amount = ?, partial_released = COALESCE(partial_released, 0) + ?,
                     released_at = CASE WHEN ? = 'released' THEN NOW() ELSE released_at END,
                     released_by = CASE WHEN ? = 'released' THEN ? ELSE released_by END,
                     updated_at = NOW()
                 WHERE id = ?",
                [$status, $remaining, $amount, $status, $status, $releasedBy, $escrowId]
            );

            $this->logger->info('financial_escrow.held_budget_consumed', [
                'escrow_id' => $escrowId,
                'buyer_id' => $buyerId,
                'amount' => $amount,
                'reason' => $reason,
            ]);

            return ['ok' => true, 'released' => $amount, 'remaining' => $remaining, 'status' => $status];
        };

        if ($this->db->inTransaction()) {
            return $this->normalizeFinancialResult($operation());
        }
        return $this->normalizeFinancialResult($this->db->transactional(fn() => $operation()));
    }

    /**
     * INTERNAL_API: top-up بودجهٔ مصرف‌شدهٔ escrow — آینهٔ consumeHeldBudget.
     *
     * FIX-N03/R2-20: مسیر استرداد واحدهای تحویل‌نشدهٔ تبلیغات. consumeHeldBudget
     * پول را از locked به platform_revenue می‌برد و escrow.amount را کم می‌کند؛ این متد
     * دقیقاً برعکس آن است: پول از platform_revenue به کیف تبلیغ‌دهنده برمی‌گردد
     * (deposit با ledger_debit_account='platform_revenue')، به موجودی locked بازمی‌گردد
     * (پشتیبانی hold بازسازی می‌شود) و escrow.amount دوباره شارژ می‌شود.
     * وضعیت 'released' به 'partial' باز می‌شود؛ در replay ایدمپوتنت، escrow دست‌نخورده می‌ماند.
     *
     * @param array<string, mixed> $extraMetadata
     * @return array<string, mixed>
     */
    public function topUpHeldBudget(
        int $escrowId,
        int $buyerId,
        string $amount,
        string $currency,
        string $reason,
        string $issuedBy = 'system',
        ?string $idempotencyKey = null,
        array $extraMetadata = []
    ): array {
        $operation = function () use ($escrowId, $buyerId, $amount, $currency, $reason, $issuedBy, $idempotencyKey, $extraMetadata) {
            if (bccomp($amount, '0', 8) <= 0) {
                return ['ok' => true, 'topped_up' => '0'];
            }
            $currency = strtolower((string)$currency) === 'usdt' ? 'usdt' : 'irt';

            $escrow = $this->db->fetch(
                "SELECT * FROM escrow_transactions WHERE id = ? AND buyer_id = ? FOR UPDATE",
                [$escrowId, $buyerId]
            );
            if (!$escrow) {
                return ['ok' => false, 'error' => 'Escrow not found for top-up'];
            }
            $escrow = $this->requireEscrowRow($escrow);

            $topupKey = $idempotencyKey ?: hash('sha256', implode('|', [
                'escrow.topup', $escrowId, $amount, $reason, $issuedBy,
            ]));

            // 🛡️ FIX-CH01: primitive داخلی دو-لگی — leg 1: platform_revenue→wallet
            // (قبلاً با deposit+ledger_debit_account بی‌صدا external_payment می‌شد)،
            // leg 2: wallet→locked_reserve با leg دفترکل (قبلاً SQL خامِ بی‌ledger بود).
            // هر دو در یک مرز اتمیک با idempotency؛ حساب‌ها hardcoded (هرگز از metadata).
            $walletMutation = $this->walletMutation ?? throw new \Core\Exceptions\ApplicationException(
                'WalletMutationService برای بازگرداندن بودجه hold در دسترس نیست (FIX-CH01 fail-closed).'
            );
            $mutationResult = $walletMutation->topUpHeldBudgetFromRevenue(
                $buyerId,
                $amount,
                $currency,
                $reason,
                $topupKey,
                array_merge([
                    'ref_id' => $escrowId,
                    'ref_type' => 'escrow',
                ], $extraMetadata)
            );
            if (($mutationResult['idempotent_replay'] ?? false) === true) {
                $this->logger->warning('financial_escrow.held_budget_topup_replay', [
                    'escrow_id' => $escrowId,
                    'buyer_id' => $buyerId,
                    'amount' => $amount,
                ]);
                return ['ok' => true, 'topped_up' => '0', 'idempotent_replay' => true, 'remaining' => (string)$escrow->amount];
            }

            // ۳) escrow.amount دوباره شارژ می‌شود؛ 'released' به 'partial' باز می‌گشد
            $newAmount = bcadd((string)$escrow->amount, $amount, 8);
            $newStatus = ((string)$escrow->status === 'released') ? 'partial' : (string)$escrow->status;
            $this->db->query(
                "UPDATE escrow_transactions SET status = ?, amount = ?, updated_at = NOW() WHERE id = ?",
                [$newStatus, $newAmount, $escrowId]
            );

            $this->logger->info('financial_escrow.held_budget_topped_up', [
                'escrow_id' => $escrowId,
                'buyer_id' => $buyerId,
                'amount' => $amount,
                'reason' => $reason,
                'issued_by' => $issuedBy,
            ]);

            return ['ok' => true, 'topped_up' => $amount, 'remaining' => $newAmount, 'status' => $newStatus];
        };

        if ($this->db->inTransaction()) {
            return $this->normalizeFinancialResult($operation());
        }
        return $this->normalizeFinancialResult($this->db->transactional(fn () => $operation()));
    }

    /**
     * INTERNAL_API: refund موجودی باقی‌مانده یک budget escrow به خریدار.
     * این متد عمومی escrow/wallet است و منطق جدول ads را نمی‌شناسد.
     * @return FinancialResult
     * @param array<string, mixed> $extraMetadata
     */
    public function refundHeldBudget(
        int $escrowId,
        int $buyerId,
        string $reason,
        string $refundedBy = 'system',
        ?string $idempotencyKey = null,
        array $extraMetadata = []
    ): array {
        $operation = function () use ($escrowId, $buyerId, $reason, $refundedBy, $idempotencyKey, $extraMetadata) {
            $escrow = $this->db->fetch(
                "SELECT * FROM escrow_transactions WHERE id = ? AND buyer_id = ? AND status IN ('pending','in_escrow','partial') FOR UPDATE",
                [$escrowId, $buyerId]
            );
            if (!$escrow) {
                return ['ok' => false, 'error' => 'Escrow not found or not refundable'];
            }
            $escrow = $this->requireEscrowRow($escrow);
            $amount = (string)$escrow->amount;
            $currency = strtolower((string)$escrow->currency) === 'usdt' ? 'usdt' : 'irt';
            $balanceField = $currency === 'usdt' ? 'balance_usdt' : 'balance_irt';
            $lockedField = $currency === 'usdt' ? 'locked_usdt' : 'locked_irt';

            if (bccomp($amount, '0', 8) > 0) {
                $releaseResult = $this->wallet->releaseLockedFunds(
                    $buyerId, $amount, $currency,
                    ['type' => 'escrow_refund', 'ref_id' => $escrowId, 'description' => 'بازگشت وجه امانی', 'idempotency_key' => $idempotencyKey ?: ('escrow_budget_refund:' . $escrowId)] + $extraMetadata
                );
                if (empty($releaseResult['success'])) {
                    throw new \Core\Exceptions\ApplicationException('خطا در بازگشت بودجه قفل‌شده کیف پول');
                }
            }

            $this->db->query(
                "UPDATE escrow_transactions
                 SET status = 'refunded', amount = 0, refunded_at = NOW(), refund_reason = ?, refunded_by = ?, updated_at = NOW()
                 WHERE id = ?",
                [$reason, $refundedBy, $escrowId]
            );

            $this->logger->info('financial_escrow.held_budget_refunded', [
                'escrow_id' => $escrowId,
                'buyer_id' => $buyerId,
                'amount' => $amount,
                'reason' => $reason,
            ]);

            return ['ok' => true, 'amount' => $amount, 'currency' => $currency];
        };

        if ($this->db->inTransaction()) {
            return $this->normalizeFinancialResult($operation());
        }
        return $this->normalizeFinancialResult($this->db->transactional(fn() => $operation()));
    }

    /**
     * 🛡️ Fraud Policy Guard — بررسی ضدتقلب قبل از عملیات مالی escrow
     */
    /** @param array<string, mixed> $context */
    private function assertFraudAllowed(int $userId, string $action, array $context = []): void
    {
        try {
            $risk = $this->fraudGuard->checkAction($userId, $action, $context);

            if (empty($risk['allowed'])) {
                throw new \App\Exceptions\BusinessException(
                    'عملیات مالی به دلیل محدودیت‌های امنیتی مجاز نیست.'
                );
            }
        } catch (\App\Exceptions\BusinessException $e) {
            throw $e;
        } catch (\Throwable $e) {
            // FIX-R36-W3 (F-A10-09): این wrapper دور «مسیر پول» است (escrow.hold).
            // قبلاً هر Throwable به‌جز BusinessException بی‌صدا بلعیده و عملیات
            // ادامه می‌یافت (fail-open) — اگر قرارداد FraudGuardService::checkAction
            // روزی روی outage شروع به throw کردن کند، گیت تقلبِ escrow خاموش
            // می‌شد (نقض H-11/M-24 fail-closed). امروز checkAction هرگز throw
            // نمی‌کند (handleSystemFailure → حکم fail-closed)، پس این تغییر
            // رفتارِ زنده‌ای عوض نمی‌کند؛ فقط قرارداد را fail-closed می‌بندد.
            $this->captureEscrowException($e, 'assertFraudAllowed');
            $this->logger->warning('escrow.fraud_check_unavailable', [
                'user_id' => $userId, 'error' => $e->getMessage(),
            ]);
            throw $e;
        }
    }
}

