<?php

declare(strict_types=1);

namespace App\Adapters;

use Core\ValueObjects\Money;
use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use App\Models\Ads;
use App\Contracts\WalletServiceInterface;
use App\Services\Shared\IdempotencyService;
use Core\Database;
use App\Services\Settings\AppSettings;

/**
 * NotificationAdAdapter - creates mass push-notification ad records only.
 * Financial hold/withdraw is handled centrally by AdSystemManager.
 */
class NotificationAdAdapter extends AdapterBase implements AdSystemContract
{
    // FIX-P3-ADP-134: سقف‌های طول برای محتوای نوتیفیکیشن‌آگهی
    private const MAX_AD_TITLE_LENGTH = 100;
    private const MAX_AD_BODY_LENGTH  = 500;

    public function __construct(
        private Ads $adModel,
        WalletServiceInterface $walletService,
        Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory,
        IdempotencyService $idempotencyService,
        \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlementService
    ) {
        unset($walletService, $db, $idempotencyService, $adsBudgetSettlementService);
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string { return 'notification'; }

    public function create(int $userId, array $data): array
    {
        try {
            $data = $this->normalize($data);
            $validation = $this->validate($data);
            if (!$validation['valid']) {
                return $this->errorResponse('ورودی‌های آگهی معتبر نیستند.', $validation['errors']);
            }

            $adId = $this->adModel->create([
                'user_id' => $userId,
                'type' => 'notification',
                'title' => $data['title'],
                'description' => $data['body'],
                'budget' => $data['budget'],
                'total_budget' => $data['budget'],
                'remaining_budget' => $data['budget'],
                'site_commission_percent' => $data['site_commission_percent'],
                'status' => $data['requires_admin_review'] ? 'pending_review' : 'active',
                'is_active' => $data['requires_admin_review'] ? 0 : 1,
                'link' => $data['target_link'] ?: null,
                'target_url' => $data['target_link'] ?: null,
                'restrictions' => json_encode([
                    'push_body' => $data['body'],
                    'image_path' => $data['image_path'] ?: null,
                    'icon' => $data['icon'],
                    'scheduled_time' => $data['scheduled_time'] ?: null,
                ], JSON_UNESCAPED_UNICODE),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            // FIX-P3-ADP-135: id صفر/منفی/غیرعددی success نیست — همان گاردِ create در AdTubeAdapter.
            // نرمال‌سازی قبل از گارد تا create()=0/false هم پیام صادقانهٔ «شناسه نامعتبر» بگیرد، نه پیام عمومی.
            $id = is_object($adId) ? (is_numeric(get_object_vars($adId)['id'] ?? null) ? (int)get_object_vars($adId)['id'] : 0) : (is_numeric($adId) ? (int)$adId : 0);
            if ($id <= 0) {
                $this->logError('create', 'created notification ad id is invalid', ['user_id' => $userId, 'raw_type' => get_debug_type($adId)]);
                return $this->errorResponse('شناسه آگهی ایجادشده نامعتبر است.');
            }
            return $this->successResponse('آگهی نوتیفیکیشنی شما ثبت شد.', ['id' => $id, 'ad_id' => $id]);
        } catch (\Throwable $e) {
            $this->logError('create', $e->getMessage(), ['user_id' => $userId]);
            return $this->errorResponse('خطای سیستمی در ایجاد آگهی نوتیفیکیشن رخ داد.');
        }
    }

    public function validate(array $data, bool $isUpdate = false): array
    {
        $data = $this->normalize($data);
        $errors = [];
        if (mb_strlen($data['title']) < 3) $errors[] = 'عنوان نوتیفیکیشن الزامی است.';
        if (mb_strlen($data['body']) < 10) $errors[] = 'متن پیام نوتیفیکیشن باید حداقل ۱۰ کاراکتر باشد.';
        // FIX-P3-ADP-134: سقف طول — فقط حداقل کافی نبود
        if (mb_strlen($data['title']) > self::MAX_AD_TITLE_LENGTH) $errors[] = 'عنوان نوتیفیکیشن حداکثر ۱۰۰ کاراکتر است.';
        if (mb_strlen($data['body']) > self::MAX_AD_BODY_LENGTH) $errors[] = 'متن پیام نوتیفیکیشن حداکثر ۵۰۰ کاراکتر است.';
        if (bccomp($data['budget'], '1000', 8) < 0) $errors[] = 'بودجه نوتیفیکیشن باید حداقل ۱۰۰۰ تومان باشد.';
        if ($data['target_link'] !== '') {
            if (!filter_var($data['target_link'], FILTER_VALIDATE_URL)) {
                $errors[] = 'لینک مقصد نوتیفیکیشن معتبر نیست.';
            } elseif (!$this->isHttpsUrl($data['target_link'])) {
                // FIX-P3-ADP-133: policy scheme مقصد — فقط https (مثل اکوسیستم FCM)
                $errors[] = 'لینک مقصد نوتیفیکیشن باید HTTPS باشد.';
            }
        }
        // FIX-P3-ADP-133: image_path/icon مسیرِ نسبیِ امن (بدون traversal/scheme/absolute)
        if ($data['image_path'] !== '' && !$this->isSafeRelativePath($data['image_path'])) {
            $errors[] = 'مسیر تصویر نوتیفیکیشن نامعتبر است.';
        }
        if ($data['icon'] !== 'default_ad_icon' && !$this->isSafeRelativePath($data['icon'])) {
            $errors[] = 'آیکن نوتیفیکیشن نامعتبر است.';
        }
        // FIX-P3-ADP-134: scheduled_time — فرمت canonical و در آینده
        if ($data['scheduled_time'] !== '') {
            if (preg_match('/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}$/', $data['scheduled_time']) !== 1) {
                $errors[] = 'زمان‌بندی ارسال باید با فرمت Y-m-d H:i:s باشد.';
            } else {
                $scheduledTs = strtotime($data['scheduled_time']);
                if ($scheduledTs === false) {
                    $errors[] = 'زمان‌بندی ارسال نوتیفیکیشن نامعتبر است.';
                } elseif ($scheduledTs < time() - 60) {
                    $errors[] = 'زمان‌بندی ارسال نوتیفیکیشن باید در آینده باشد.';
                }
            }
        }
        return ['valid' => empty($errors), 'errors' => $errors];
    }

    /**
     * FIX-P3-ADP-133: فقط https با host — policy مقصدِ لینکِ نوتیفیکیشن‌آگهی.
     */
    private function isHttpsUrl(string $url): bool
    {
        $parts = parse_url($url);
        return is_array($parts)
            && strtolower((string)($parts['scheme'] ?? '')) === 'https'
            && !empty($parts['host']);
    }

    /**
     * FIX-P3-ADP-133: مسیرِ نسبیِ امن برای image/icon — بدون absolute، traversal،
     * scheme و کاراکترهای خارج از allowlist (حروف/ارقام/داش/اسلش/نقطه/آندرلاین).
     */
    private function isSafeRelativePath(string $path): bool
    {
        if ($path === '' || strlen($path) > 255) {
            return false;
        }
        if (str_contains($path, '..') || str_starts_with($path, '/') || str_contains($path, "\\")) {
            return false;
        }
        if (preg_match('#^[a-zA-Z][a-zA-Z0-9+.-]*:#', $path) === 1) {
            return false; // scheme-like prefix (http:, file:, ...)
        }
        return preg_match('#^[A-Za-z0-9][A-Za-z0-9_\-./]*$#', $path) === 1;
    }

    /**
     * FIX-R36-W3 (F-A19d-09): هم‌ترازی با الگوی bccomp آداپتورهای دیگر
     * (AdTube:113/Seo:88/Banner:134) — (float) در مقادیر مرزی (0.000001 باقی‌مانده)
     * رفتار متفاوت داشت.
     * FIX-R36-W3 (F-A19d-03): @deprecated — صفر call-site.
     */
    public function isExpired(int $adId): bool
    {
        $ad = $this->adModel->find($adId);
        if (!is_object($ad)) return true;
        $vars = get_object_vars($ad);
        return !is_numeric($vars['remaining_budget'] ?? null) || bccomp((string)$vars['remaining_budget'], '0', 8) <= 0;
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        $feeValue = $this->appSettings->get('notification_ad_fee_percent', 15);
        $fee = is_numeric($feeValue) ? (string)$feeValue : '15';
        // FIX-P3-ADP-136: واحدِ این آداپتر canonical 'irt' است (validate در تومان،
        // بودجه در تومان) — ارزِ بیگانهٔ caller خاموش واحد را قاطی نمی‌کند؛ pin + لاگ.
        $currency = is_string($context['currency'] ?? null) ? strtolower(trim($context['currency'])) : 'irt';
        if ($currency !== 'irt') {
            $this->logError('calculateCost', 'non-canonical currency pinned to irt', ['requested_currency' => $currency]);
            $currency = 'irt';
        }
        // float→decimal: محاسبهٔ کارمزد با Money/BCMath به‌جای float
        return Money::fromString($amount, $currency)->percentage($fee)->getAmount();
    }

    /**
     * FIX-C52 (یافتهٔ ممیزی ۵۲): fail-loud — همان الگوی SeoAdAdapter؛ پرداخت ساختگی حذف شد.
     * تسویهٔ مالی فقط از مسیر متمرکز escrow/AdsBudgetSettlementService انجام می‌شود.
     * @deprecated Dead contract surface (F-A19d-03) — صفر call-site
     */
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        throw new \LogicException(
            'NotificationAdAdapter::processPayment غیرفعال است (F-A19d-03/59): تسویهٔ مالی فقط از مسیر متمرکز escrow/AdsBudgetSettlementService انجام می‌شود.'
        );
    }

    /**
     * FIX-R36-W3 (F-A19d-03): consumeDeliveryBudget واقعی در بدنهٔ متدِ بدون call-site
     * = مسیر دومِ کسر بودجه — fail-loud برای دیده‌شدن فوری هر فراخوانی آینده.
     * @deprecated Dead contract surface (r36 audit F-A19d-03)
     */
    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        throw new \LogicException(
            'NotificationAdAdapter::track غیرفعال است (F-A19d-03): تسویهٔ کلیک/ارسال فقط از AdsBudgetSettlementService انجام می‌شود.'
        );
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function getStatus(int $adId): ?array
    {
        $ad = $this->adModel->find($adId);
        if (!$ad) return null;
        $vars = get_object_vars($ad);
        return ['id' => is_numeric($vars['id'] ?? null) ? (int)$vars['id'] : 0, 'type' => 'notification', 'status' => is_string($vars['status'] ?? null) ? $vars['status'] : 'unknown', 'impressions' => is_numeric($vars['impressions'] ?? null) ? (int)$vars['impressions'] : 0, 'clicks' => is_numeric($vars['clicks'] ?? null) ? (int)$vars['clicks'] : 0];
    }

    /**
     * @param array<string, mixed> $data
     * @return array{
     *   title: string,
     *   body: string,
     *   budget: string,
     *   target_link: string,
     *   image_path: string,
     *   icon: string,
     *   scheduled_time: string,
     *   site_commission_percent: string,
     *   requires_admin_review: bool
     * }
     */
    private function normalize(array $data): array
    {
        $toString = static fn(mixed $v): string => is_scalar($v) ? trim((string)$v) : '';
        $feeValue = $this->appSettings->get('notification_ad_fee_percent', 15);
        $fee = is_numeric($feeValue) ? (string)$feeValue : '15';
        // float→decimal: بودجه به‌صورت رشتهٔ decimal
        $budgetInput = $data['budget'] ?? $data['total_budget'] ?? 0;
        return [
            'title' => $toString($data['title'] ?? ''),
            'body' => $toString($data['body'] ?? $data['description'] ?? ''),
            'budget' => is_numeric($budgetInput) ? (string)$budgetInput : '0',
            'target_link' => $toString($data['target_link'] ?? $data['link'] ?? $data['target_url'] ?? ''),
            'image_path' => $toString($data['image_path'] ?? ''),
            'icon' => $toString($data['icon'] ?? 'default_ad_icon'),
            'scheduled_time' => $toString($data['scheduled_time'] ?? ''),
            'site_commission_percent' => $fee,
            // FIX-P3-ADP-137: (bool) cast خاموش جایگزین پارسِ سخت‌گیرانه شد —
            // رشتهٔ 'false' دیگر true جعل نمی‌کند (الگوی BannerAdapter::parseBoolean).
            'requires_admin_review' => $this->parseBooleanSetting(
                $this->appSettings->get('notification_ad_requires_admin_review', 1),
                'notification_ad_requires_admin_review',
                true
            ),
        ];
    }

    /**
     * FIX-P3-ADP-137: پارسِ سخت‌گیرانهٔ boolean در مرزِ setting — allowlist توکن‌ها؛
     * مقدار بدشکل به default مستند برمی‌گردد با لاگ warning (نه cast خاموش).
     */
    private function parseBooleanSetting(mixed $value, string $setting, bool $default): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) && ($value === 0 || $value === 1)) {
            return $value === 1;
        }
        if (is_string($value)) {
            $normalized = strtolower(trim($value));
            if ($normalized === 'true' || $normalized === '1' || $normalized === 'yes' || $normalized === 'on') return true;
            if ($normalized === 'false' || $normalized === '0' || $normalized === 'no' || $normalized === 'off' || $normalized === '') return false;
        }
        $this->logger->warning('adapter.notification.setting_boolean_malformed', ['setting' => $setting]);
        return $default;
    }
}
