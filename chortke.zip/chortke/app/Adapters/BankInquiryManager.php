<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Contracts\LoggerInterface;

/**
 * BankInquiryManager
 * یک الگو (Provider Chain / Composite) برای مدیریت چندین آداپتور استعلام بانکی.
 * در صورت خطا در یک آداپتور، به طور خودکار به سراغ آداپتور بعدی (Fallback) می‌رود.
 *
 * FIX-P3-ADP-032: قرارداد نتیجهٔ موفق در «مرز منیجر» اعتبارسنجی می‌شود —
 *   success=true به‌همراه owner_name/bank غیرخالیِ رشته‌ای الزامی است و اگر
 *   پروایدر IBAN را در نتیجه برگرداند، باید دقیقاً با شِبا درخواستی یکسان باشد
 *   (ضد cross-IBAN cache poisoning). پروایدرهایی که شِبا را echo نمی‌کنند
 *   (سازگاری عقب‌رو با اینترفیس) پذیرفته می‌شوند؛ هر دو پیاده‌سازی فعلی
 *   (Vandar/Jibit) شِبا را برمی‌گردانند و binding آن‌ها همین‌جا چک می‌شود.
 */
class BankInquiryManager implements BankInquiryAdapter
{
    /**
     * FIX-P3-ADP-034: بودجهٔ wall-clock کل زنجیره (ثانیه).
     * پیش‌فرض ۶۰ و کلمپ‌شده در بازهٔ 1..300 — قبل از هر fan-out چک می‌شود.
     */
    private const DEADLINE_DEFAULT_SECONDS = 60;
    private const DEADLINE_MIN_SECONDS = 1;
    private const DEADLINE_MAX_SECONDS = 300;

    /**
     * @var list<BankInquiryAdapter>
     */
    private array $adapters;
    private LoggerInterface $logger;

    /** @param list<BankInquiryAdapter> $adapters */
    public function __construct(LoggerInterface $logger, array $adapters) {
        $this->logger = $logger;
        // FIX-P3-ADP-035: dedupe بر اساس کلاس — هر پیاده‌سازی حداکثر یک‌بار در زنجیره.
        $this->adapters = $this->normalizeAdapters($adapters);
    }

    public function addAdapter(BankInquiryAdapter $adapter): void
    {
        // FIX-P3-ADP-035: dedupe در addAdapter — کلاس تکراری نادیده گرفته می‌شود (قابل‌مشاهده در لاگ).
        $normalized = $this->normalizeAdapters(array_merge($this->adapters, [$adapter]));
        if (count($normalized) === count($this->adapters)) {
            $this->logger->warning('bank_inquiry_manager.duplicate_adapter_ignored', [
                'adapter' => get_class($adapter),
            ]);
            return;
        }
        $this->adapters = $normalized;
    }

    /**
     * FIX-P3-ADP-035: حذف موارد تکراری (بر اساس get_class) و entries غیر-آداپتور.
     * حذفِ بی‌صدا نیست: هر کنارگذاشته‌ای لاگ می‌شود (fail-closed قابل‌مشاهده).
     *
     * @param list<BankInquiryAdapter> $adapters
     * @return list<BankInquiryAdapter>
     */
    private function normalizeAdapters(array $adapters): array
    {
        $seen = [];
        $unique = [];
        foreach ($adapters as $adapter) {
            if (!$adapter instanceof BankInquiryAdapter) {
                $this->logger->warning('bank_inquiry_manager.invalid_adapter_ignored', [
                    'adapter' => is_object($adapter) ? get_class($adapter) : get_debug_type($adapter),
                ]);
                continue;
            }
            $class = get_class($adapter);
            if (isset($seen[$class])) {
                $this->logger->warning('bank_inquiry_manager.duplicate_adapter_ignored', ['adapter' => $class]);
                continue;
            }
            $seen[$class] = true;
            $unique[] = $adapter;
        }
        return $unique;
    }

    /**
     * @inheritDoc
     * @return array<string, mixed>
     */
    public function inquireIban(string $iban): array
    {
        // FIX-P3-ADP-033: نرمال‌سازی و اعتبارسنجی IBAN یک‌بار در مرز منیجر —
        // ورودی خراب هرگز به هیچ پروایدر نمی‌رسد (نتیجهٔ ساختاریافته، نه exception).
        $iban = strtoupper(str_replace(' ', '', trim($iban)));
        if (!$this->isValidIranianIban($iban)) {
            $this->logger->warning('bank_inquiry_manager.invalid_iban', ['iban' => $this->maskIban($iban)]);
            return [
                'success' => false,
                'message' => 'شماره شبا نامعتبر است.'
            ];
        }

        // FIX-P3-ADP-035: فقط پروایدرهای پیکربندی‌شده در زنجیره fan-out می‌شوند؛
        // اگر هیچ‌کدام config نداشتند → گارد سرویسِ غایب (بدون فراخوانی شبکه).
        $configured = [];
        foreach ($this->adapters as $adapter) {
            try {
                if ($adapter->isConfigured()) {
                    $configured[] = $adapter;
                }
            } catch (\Throwable $e) {
                // خرابی health-check پروایدر = آن پروایدر این‌بار مصرف نمی‌شود (fail-closed).
                $this->logger->warning('bank_inquiry_manager.adapter_health_check_failed', [
                    'provider' => get_class($adapter),
                    'error' => mb_substr($e->getMessage(), 0, 300),
                ]);
            }
        }

        if (empty($configured)) {
            $this->logger->error('bank_inquiry_manager.empty_chain', ['iban' => $this->maskIban($iban)]);
            return [
                'success' => false,
                'message' => 'هیچ سرویس استعلام بانکی پیکربندی نشده است.'
            ];
        }

        // FIX-P3-ADP-034: deadline کلی زنجیره — fan-out بعد از عبور از بودجهٔ زمانی متوقف می‌شود.
        $deadlineSeconds = max(
            self::DEADLINE_MIN_SECONDS,
            min(self::DEADLINE_MAX_SECONDS, int_value(config('services.bank_inquiry.deadline_seconds', self::DEADLINE_DEFAULT_SECONDS), self::DEADLINE_DEFAULT_SECONDS))
        );
        $startTime = microtime(true);
        $deadline = $startTime + $deadlineSeconds;
        $deadlineExceeded = false;

        $lastError = 'خطای نامشخص';
        $adapterCount = count($configured);

        foreach ($configured as $index => $adapter) {
            if (microtime(true) >= $deadline) {
                $deadlineExceeded = true;
                $this->logger->warning('bank_inquiry_manager.deadline_exceeded', [
                    'iban' => $this->maskIban($iban),
                    'providers_total' => $adapterCount,
                    'providers_attempted' => $index,
                    'deadline_seconds' => $deadlineSeconds,
                ]);
                break;
            }

            $providerName = get_class($adapter);
            try {
                $result = $adapter->inquireIban($iban);

                // FIX-P3-ADP-032: نتیجهٔ موفق فقط با schema معتبر به caller برمی‌گردد.
                if (is_array($result) && !empty($result['success']) && $this->isValidInquiryResult($result, $iban)) {
                    return $result;
                }

                // FIX-P3-ADP-032: success ادعاشده اما ردِ schema = نتیجهٔ مسموم؛
                // متنِ نتیجهٔ نامعتبر جایی منتشر نمی‌شود — پیام ثابت جایگزین می‌شود.
                $schemaRejected = is_array($result) && !empty($result['success']);
                if ($schemaRejected) {
                    $lastError = 'پاسخ موفق اما نامعتبر از نظر ساختار.';
                } else {
                    $candidate = is_array($result) ? ($result['message'] ?? null) : null;
                    $lastError = is_string($candidate) && trim($candidate) !== '' ? $candidate : 'خطای سرویس';
                }

                $this->logger->warning('bank_inquiry_manager.adapter_failed', [
                    'provider' => $providerName,
                    'iban' => $this->maskIban($iban), // FIX-P3-ADP-031
                    'error' => mb_substr($lastError, 0, 300),
                    'schema_rejected' => $schemaRejected,
                    'fallback_to_next' => $index < ($adapterCount - 1)
                ]);

            } catch (\Throwable $e) {
                $lastError = $e->getMessage();
                $this->logger->error('bank_inquiry_manager.adapter_exception', [
                    'provider' => $providerName,
                    'iban' => $this->maskIban($iban), // FIX-P3-ADP-031
                    'error' => mb_substr($lastError, 0, 300),
                    'fallback_to_next' => $index < ($adapterCount - 1)
                ]);
            }
        }

        // All providers failed (یا بودجهٔ زمانی تمام شد)
        $this->logger->critical('bank_inquiry_manager.all_providers_failed', [
            'iban' => $this->maskIban($iban), // FIX-P3-ADP-031
            'last_error' => mb_substr($lastError, 0, 300),
            'deadline_exceeded' => $deadlineExceeded, // FIX-P3-ADP-034
            'providers_total' => $adapterCount,
            'elapsed_ms' => (int) round((microtime(true) - $startTime) * 1000),
        ]);

        // FIX-R36-W3 (F-A19d-06): قرارداد پیام ژنریک R18 در «مرز منیجر» اعمال شد —
        // متن خام lastError (شامل جزئیات شبکه/پروایدر از هر آداپتر آینده‌ای که
        // exception بدهد) دیگر به caller/UI نشت نمی‌کند؛ جزئیات فقط در لاگ بالا.
        // FIX-P3-ADP-034: اگر زنجیره با deadline متوقف شده، پیام صادقانهٔ deadline
        // برمی‌گردد (نه «تمامی سرویس‌ها خطا دادند» — شکست واقعی اعلام می‌شود).
        if ($deadlineExceeded) {
            return [
                'success' => false,
                'message' => 'زمان مجاز استعلام بانکی به پایان رسید. لطفاً بعداً تلاش کنید.'
            ];
        }

        return [
            'success' => false,
            'message' => 'تمامی سرویس‌های استعلام بانکی با خطا مواجه شدند. لطفاً بعداً دوباره تلاش کنید.'
        ];
    }

    /**
     * @inheritDoc
     */
    public function isConfigured(): bool
    {
        foreach ($this->adapters as $adapter) {
            if ($adapter->isConfigured()) {
                return true;
            }
        }
        return false;
    }

    /**
     * FIX-P3-ADP-032: اعتبارسنجی schema نتیجهٔ موفق در مرز منیجر.
     * الزامی: success + owner_name غیرخالی (string) + bank غیرخالی (string).
     * شرطی: اگر پروایدر «iban» را در نتیجه برگرداند باید با درخواست یکی باشد.
     *
     * @param mixed $result
     */
    private function isValidInquiryResult($result, string $requestedIban): bool
    {
        if (!is_array($result) || empty($result['success'])) {
            return false;
        }
        $ownerName = $result['owner_name'] ?? null;
        if (!is_string($ownerName) || trim($ownerName) === '') {
            return false;
        }
        $bank = $result['bank'] ?? null;
        if (!is_string($bank) || trim($bank) === '') {
            return false;
        }
        $returnedIban = $result['iban'] ?? null;
        if ($returnedIban !== null
            && (!is_string($returnedIban) || strtoupper(trim($returnedIban)) !== $requestedIban)) {
            return false; // نقض binding — نتیجه برای شِبای دیگری است
        }
        return true;
    }

    /**
     * FIX-P3-ADP-033: همان اعتبارسنجی mod-97 پروایدرها، در مرز منیجر.
     */
    private function isValidIranianIban(string $iban): bool
    {
        if (preg_match('/^IR\d{24}$/', $iban) !== 1) return false;
        $rearranged = substr($iban, 4) . '1827' . substr($iban, 2, 2);
        $remainder = 0;
        foreach (str_split($rearranged) as $digit) {
            $remainder = ($remainder * 10 + (int)$digit) % 97;
        }
        return $remainder === 1;
    }

    /**
     * FIX-P3-ADP-031: IBAN هرگز خام لاگ نمی‌شود — فقط ۴ کاراکتر آخر.
     */
    private function maskIban(string $iban): string
    {
        $iban = trim($iban);
        $length = strlen($iban);
        if ($length === 0) {
            return '';
        }
        if ($length <= 4) {
            return str_repeat('*', $length);
        }
        return '****' . substr($iban, -4);
    }
}
