<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Contracts\CacheInterface;
use App\Contracts\CircuitBreakerInterface;
use App\Contracts\LoggerInterface;
use App\Traits\ExternalCallTrait;
use App\Traits\ValidatesExternalUrl;

/** Vandar IBAN inquiry provider. */
class VandarInquiryAdapter implements BankInquiryAdapter
{
    use ExternalCallTrait;
    use ValidatesExternalUrl;

    private LoggerInterface $logger;
    private CacheInterface $cache;
    private CircuitBreakerInterface $circuitBreaker;
    private string $apiToken;
    private string $business;
    private string $baseUrl;
    private int $timeout;

    /** FIX-P3-ADP-155: سقف طول فیلدهای متنی پاسخِ پروایدر، پیش از نرمال‌سازی/کش. */
    private const MAX_FIELD_LENGTH = 200;
    private const MAX_OWNERS = 10;

    /**
     * FIX-P3-ADP-154: پین هاستِ سرویس وندار برای production — حتی اگر base_url
     * در config مسموم/اشتباه تنظیم شده باشد، توکن Bearer به هاستِ غیروندار
     * ارسال نمی‌شود. چکِ هاست «رشته‌ای و قبل از DNS» است (بدون cost شبکه).
     * خارج از production (تست/هارنسِ قرارداد) allowlist اعمال نمی‌شود.
     */
    private const ALLOWED_HOSTS = ['vandar.io', 'www.vandar.io', 'api.vandar.io'];

    /** FIX-P3-ADP-154: فرمت مجاز business identifier (slug وندار). */
    private const BUSINESS_PATTERN = '/^[A-Za-z0-9_-]{1,64}$/';

    public function __construct(
        LoggerInterface $logger,
        CacheInterface $cache,
        CircuitBreakerInterface $circuitBreaker
    ) {
        $this->logger = $logger;
        $this->cache = $cache;
        $this->circuitBreaker = $circuitBreaker;
        $this->apiToken = str_value(config('services.vandar.api_token', ''));
        $this->business = str_value(config('services.vandar.business', ''));
        $this->baseUrl = rtrim(str_value(config('services.vandar.base_url', 'https://api.vandar.io')), '/');
        $timeout = int_value(config('services.vandar.timeout', 10));
        $this->timeout = max(2, min(30, $timeout));
    }

    public function inquireIban(string $iban): array
    {
        $iban = strtoupper(str_replace(' ', '', trim($iban)));
        if (!$this->isValidIranianIban($iban)) {
            return ['success'=>false,'message'=>'شماره شبا نامعتبر است.'];
        }
        if (!$this->isConfigured()) {
            return ['success'=>false,'message'=>'پیکربندی Vandar انجام نشده است.'];
        }

        $cacheKey = 'vandar:iban:' . hash('sha256', $iban);
        try {
            $cached = $this->cache->get($cacheKey);
            if (is_string($cached)) {
                $decoded = json_decode($cached, true);
                $cached = is_array($decoded) ? $decoded : null;
            }
            // FIX-P3-ADP-153: گارد cache poisoning — مقدار کش فقط با schema کامل
            // (success + owner/bank غیرخالی + binding شِبا با درخواست) برمی‌گردد؛
            // هر چیز دیگری مثل cache-miss رفتار می‌کند و مسیر شبکه می‌رود.
            if ($this->isValidCachedResult($cached, $iban)) {
                /** @var array<string,mixed> $cached */
                return $cached;
            }
        } catch (\Throwable) {
        }

        $url = $this->baseUrl . '/v3/business/' . rawurlencode($this->business) . '/customers/inquiry/iban';

        // FIX-P3-ADP-154: پین هاست provider در production (رشته‌ای، قبل از DNS/SSRF check).
        if ($this->isHostPinned() && !in_array($this->urlHost($url), self::ALLOWED_HOSTS, true)) {
            $this->logger->critical('vandar.unsafe_url_blocked', [
                'host' => $this->urlHost($url),
                'reason' => 'host_not_in_provider_allowlist',
            ]);
            return ['success'=>false,'message'=>'آدرس سرویس وندار مجاز نیست.'];
        }
        if (!$this->isExternalUrlSafe($url)) {
            $this->logger->critical('vandar.unsafe_url_blocked', ['host'=>parse_url($url, PHP_URL_HOST)]);
            return ['success'=>false,'message'=>'آدرس سرویس وندار مجاز نیست.'];
        }

        // FIX-P3-ADP-158: track_id یک‌بار در هر inquireIban تولید می‌شود (خارج از
        // حلقهٔ retry) تا همهٔ attemptهای یک استعلام برای audit/correlation هم‌شناسه باشند.
        $trackId = bin2hex(random_bytes(12));

        try {
            $result = $this->circuitBreaker->call('vandar_iban', function () use ($url, $iban, $trackId): array {
                return $this->retryTransient(function () use ($url, $iban, $trackId): array {
                    $payload = json_encode(['iban'=>$iban,'track_id'=>$trackId], JSON_THROW_ON_ERROR);
                    $ch = curl_init($url);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER=>true,
                        CURLOPT_POST=>true,
                        CURLOPT_POSTFIELDS=>$payload,
                        CURLOPT_HTTPHEADER=>[
                            'Accept: application/json',
                            'Content-Type: application/json',
                            'Authorization: Bearer ' . $this->apiToken,
                        ],
                        CURLOPT_TIMEOUT=>$this->timeout,
                        CURLOPT_CONNECTTIMEOUT=>max(1, min(5, $this->timeout - 1)),
                        CURLOPT_SSL_VERIFYPEER=>true,
                        CURLOPT_FOLLOWLOCATION=>false,
                    ]);
                    $body = curl_exec($ch);
                    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $errno = (int)curl_errno($ch);
                    curl_close($ch);
                    if ($code < 200 || $code >= 300 || !is_string($body) || $body === '') {
                        throw $this->classifyHttpFailure($code, $errno, (string)$body, ['provider'=>'vandar']);
                    }
                    $decoded = json_decode($body, true);
                    if (!is_array($decoded)) {
                        throw new \Core\Exceptions\PermanentFailure('Vandar returned malformed JSON');
                    }
                    return $decoded;
                }, 3, 300, 3000);
            });

            if (!is_array($result)) {
                return ['success'=>false,'message'=>'پاسخ نامعتبر از سرویس وندار.'];
            }

            // FIX-P3-ADP-155: نرمال‌سازی با type-check و کپ طول owner/bank.
            $normalized = $this->normalizeProviderResult($result, $iban);
            if ($normalized === null) {
                return ['success'=>false,'message'=>'پاسخ استعلام شبا وندار ناقص است.'];
            }

            // FIX-P3-ADP-152: IBAN کامل داخل «مقدار کش» طبق قرارداد بازگشت باقی می‌ماند؛
            // ماسک‌کردن فقط در لاگ اعمال می‌شود (پایین).
            try { $this->cache->put($cacheKey, $normalized, 1440); } catch (\Throwable) {}
            return $normalized;
        } catch (\Throwable $e) {
            // FIX (Round-18 P3): raw provider exception text must not reach callers —
            // the detail stays in the log; callers get a stable generic message.
            // FIX-P3-ADP-152: IBAN در لاگ ماسک می‌شود و بدنهٔ خام پاسخ (body=…) که
            // classifyHttpFailure در message جاسازی می‌کند، پیش از لاگ حذف می‌شود.
            $this->logger->error('vandar.inquiry.failed', [
                'iban' => $this->maskIban($iban),
                'exception_class' => get_class($e),
                'error' => $this->safeLogError($e)
            ]);
            return ['success' => false, 'message' => 'عدم برقراری ارتباط با سرویس استعلام شبا. لطفاً بعداً تلاش کنید.'];
        }
    }

    public function isConfigured(): bool
    {
        // FIX-P3-ADP-154: به‌جز خالی‌نبودن مقادیر، فرمت business identifier هم
        // allowlist می‌شود؛ مقدار خراب = پروایدر پیکربندی‌نشده (fail-closed، بدون شبکه).
        return $this->apiToken !== ''
            && $this->business !== ''
            && $this->baseUrl !== ''
            && preg_match(self::BUSINESS_PATTERN, $this->business) === 1;
    }

    private function isValidIranianIban(string $iban): bool
    {
        if (preg_match('/^IR\d{24}$/', $iban) !== 1) return false;
        $rearranged = substr($iban, 4) . '1827' . substr($iban, 2, 2);
        $remainder = 0;
        foreach (str_split($rearranged) as $digit) {
            $remainder = ($remainder * 10 + (int)$digit) % 97;
        }
        return $remainder === 1;
    }

    /**
     * FIX-P3-ADP-154: پین هاست فقط در production فعال است؛ در testing/development
     * هارنسِ قرارداد (fake-provider server) باید بتواند base_url را redirect کند.
     */
    private function isHostPinned(): bool
    {
        return config('app.env') === 'production';
    }

    /** FIX-P3-ADP-154: استخراج امن هاست از URL (lowercase، بدون credentials). */
    private function urlHost(string $url): string
    {
        return strtolower(strval(parse_url($url, PHP_URL_HOST) ?? ''));
    }

    /**
     * FIX-P3-ADP-155: اعتبارسنجی semantic + type و کپ طول پاسخ خام وندار.
     * null = پاسخ ناقص (owners خالی / bank نامعتبر) → شکست ساختاریافته.
     *
     * @param array<string,mixed> $result
     * @return array<string,mixed>|null
     */
    private function normalizeProviderResult(array $result, string $iban): ?array
    {
        $data = is_array($result['data'] ?? null) ? $result['data'] : $result;
        $owners = is_array($data['account_owners'] ?? null) ? $data['account_owners'] : [];
        $ownerNames = [];
        foreach ($owners as $owner) {
            if (!is_array($owner)) continue;
            $name = trim(str_value($owner['firstName'] ?? $owner['first_name'] ?? '') . ' ' . str_value($owner['lastName'] ?? $owner['last_name'] ?? ''));
            if ($name !== '') $ownerNames[] = $name;
        }
        // FIX-P3-ADP-155: bound تعداد صاحبان + کپ طول هر نام.
        $ownerNames = array_slice($ownerNames, 0, self::MAX_OWNERS);
        $ownerNames = array_map(static fn (string $name): string => mb_substr($name, 0, self::MAX_FIELD_LENGTH), $ownerNames);

        $bank = $data['bank_name'] ?? $data['bank'] ?? null;
        if ($ownerNames === [] || !is_string($bank) || trim($bank) === '') {
            return null;
        }

        return [
            'success'=>true,
            'owner_name'=>mb_substr(implode('، ', $ownerNames), 0, self::MAX_FIELD_LENGTH),
            'bank'=>mb_substr(trim($bank), 0, self::MAX_FIELD_LENGTH), // FIX-P3-ADP-155
            'iban'=>$iban,
            'message'=>'استعلام با موفقیت انجام شد.',
        ];
    }

    /**
     * FIX-P3-ADP-153: schema-guard مقدار کش — success + owner/bank غیرخالی +
     * binding دقیق شِبای کش‌شده با شِبای درخواستی (ضد cross-IBAN poisoning).
     *
     * @param mixed $cached
     */
    private function isValidCachedResult($cached, string $requestedIban): bool
    {
        if (!is_array($cached) || empty($cached['success'])) {
            return false;
        }
        $ownerName = $cached['owner_name'] ?? null;
        if (!is_string($ownerName) || trim($ownerName) === '') {
            return false;
        }
        $bank = $cached['bank'] ?? null;
        if (!is_string($bank) || trim($bank) === '') {
            return false;
        }
        $cachedIban = $cached['iban'] ?? null;
        return is_string($cachedIban) && strtoupper(trim($cachedIban)) === $requestedIban;
    }

    /**
     * FIX-P3-ADP-152: متن امن برای لاگ — قطعهٔ «body=<raw provider response>» که
     * ExternalCallTrait::classifyHttpFailure در message جاسازی می‌کند حذف و طول پیام کپ می‌شود.
     */
    private function safeLogError(\Throwable $e): string
    {
        $message = preg_replace('/body=.*$/s', 'body=[redacted]', $e->getMessage());
        return mb_substr(is_string($message) ? $message : $e->getMessage(), 0, 300);
    }

    /**
     * FIX-P3-ADP-152: IBAN هرگز خام لاگ نمی‌شود — فقط ۴ کاراکتر آخر.
     */
    private function maskIban(string $iban): string
    {
        $iban = trim($iban);
        $length = strlen($iban);
        if ($length === 0) {
            return '';
        }
        if ($length <= 4) {
            return str_repeat('*', $length);
        }
        return '****' . substr($iban, -4);
    }
}
