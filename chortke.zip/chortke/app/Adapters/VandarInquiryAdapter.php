<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Contracts\LoggerInterface;

/**
 * VandarInquiryAdapter
 * یک آداپتور جایگزین و صوری برای استعلام بانکی (به عنوان Fallback دوم)
 */
class VandarInquiryAdapter implements BankInquiryAdapter
{
    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger) {
        $this->logger = $logger;
    }

    /**
     * @inheritDoc
     */
    public function inquireIban(string $iban): array
    {
        try {
            $this->logger->info('vandar.inquire_iban', ['iban' => $iban]);

            return [
                'success' => false,
                'message' => 'سرویس وندار در حال حاضر در دسترس نیست (تستی)'
            ];
        } catch (\Throwable $e) {
            return [
                'success' => false,
                'message' => 'خطا در برقراری ارتباط با سرویس استعلام'
            ];
        }
    }

    /**
     * @inheritDoc
     */
    public function isConfigured(): bool
    {
        return true;
    }
}
