<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use Core\Database;
use App\Services\Settings\AppSettings;
use App\Constants\PercentageConstants;
use App\Services\Shared\IdempotencyService;
use App\Models\Ads;

/**
 * AdSocialAdapter - creates SocialTask ad records only.
 * Financial hold/withdraw is handled centrally by AdSystemManager.
 */
class AdSocialAdapter extends AdapterBase implements AdSystemContract
{
    public function __construct(
        private Ads $adModel,
        private \App\Contracts\WalletServiceInterface $walletService,
        private Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory,
        private IdempotencyService $idempotencyService
    ) {
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string
    {
        return 'social_task';
    }

    public function create(int $userId, array $data): array
    {
        $data = $this->normalize($data);
        $valid = $this->validate($data);
        if (!$valid['valid']) {
            return $this->errorResponse('اطلاعات وارد شده معتبر نیست', $valid['errors']);
        }

        $ad = $this->adModel->create([
            'user_id' => $userId,
            'type' => 'social_task',
            'platform' => $data['platform'],
            'task_type' => $data['task_type'],
            'title' => $data['title'],
            'description' => $data['description'] ?: null,
            'link' => $data['link'],
            'target_url' => $data['link'],
            'price_per_task' => $data['price_per_task'],
            'currency' => $data['currency'],
            'total_budget' => $data['total_budget'],
            'remaining_budget' => $data['total_budget'],
            'total_count' => $data['total_count'],
            'remaining_count' => $data['total_count'],
            'pending_count' => 0,
            'completed_count' => 0,
            'site_commission_percent' => $data['site_commission_percent'],
            'status' => $data['requires_admin_review'] ? 'pending_review' : 'active',
            'created_by' => $userId,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        if (!$ad) {
            return $this->errorResponse('خطا در نهایی‌سازی تبلیغ در سیستم.');
        }
        $adId = is_object($ad) ? (int)$ad->id : (int)$ad;

        return $this->successResponse('تسک شبکه اجتماعی با موفقیت ثبت شد.', ['id' => $adId, 'ad_id' => $adId]);
    }

    public function validate(array $data, bool $isUpdate = false): array
    {
        $data = $this->normalize($data);
        $errors = [];

        if (!in_array($data['platform'], ['instagram', 'telegram', 'twitter', 'tiktok', 'facebook', 'other'], true)) {
            $errors[] = 'پلتفرم نامعتبر است';
        }
        if ($data['platform'] === 'youtube') {
            $errors[] = 'YouTube باید از مسیر AdTube ثبت شود.';
        }
        if (!in_array($data['task_type'], ['follow', 'like', 'comment', 'share', 'view', 'join', 'subscribe', 'retweet', 'other'], true)) {
            $errors[] = 'نوع تسک نامعتبر است';
        }
        if (mb_strlen($data['title']) < 3) {
            $errors[] = 'عنوان تبلیغ نباید خالی باشد';
        }
        if ($data['link'] === '') {
            $errors[] = 'آدرس یا آیدی کانال/صفحه الزامی است';
        } elseif (!filter_var($data['link'], FILTER_VALIDATE_URL) && !preg_match('/^@?[a-zA-Z0-9_.]+$/', $data['link'])) {
            $errors[] = 'فرمت لینک یا آیدی وارد شده معتبر نیست';
        }
        $minPrice = (float)$this->appSettings->get('social_task_min_price', 100);
        if ($data['price_per_task'] < $minPrice) {
            $errors[] = "حداقل قیمت هر تسک در شبکه‌های اجتماعی {$minPrice} تومان است";
        }
        if ($data['total_count'] < 1) {
            $errors[] = 'تعداد درخواست حداقل باید ۱ عدد باشد';
        }

        return ['valid' => empty($errors), 'errors' => $errors];
    }

    public function isExpired(int $adId): bool
    {
        $ad = $this->adModel->find($adId);
        return !$ad || in_array($ad->status, ['expired', 'completed'], true) || (isset($ad->remaining_budget) && (float)$ad->remaining_budget <= 0);
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        $feePercent = (float)$this->appSettings->get('social_task_site_fee_percent', PercentageConstants::SOCIAL_TASK_FEE_PERCENT);
        return (string)round(((float)$amount) * ($feePercent / 100), 8);
    }

    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        return $this->successResponse('پرداخت با بودجه اولیه و escrow مرکزی مدیریت می‌شود.');
    }

    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        $this->logInfo('track', ['event' => $eventType, 'ad_id' => $adId, 'user_id' => $userId]);
        return $this->successResponse('تراک رویداد انجام شد');
    }

    public function getStatus(int $adId): ?array
    {
        $ad = $this->adModel->find($adId);
        return $ad ? ['id' => $ad->id, 'type' => 'social_task', 'status' => $ad->status] : null;
    }

    private function normalize(array $data): array
    {
        $currency = strtolower((string)($data['currency'] ?? 'irt'));
        if (in_array($currency, ['irr', 'rial'], true)) $currency = 'irt';
        if (!in_array($currency, ['irt', 'usdt'], true)) $currency = 'irt';
        $price = (float)($data['price_per_task'] ?? 0);
        $count = max(1, (int)($data['total_count'] ?? $data['quantity'] ?? 1));
        $feePercent = (float)$this->appSettings->get('social_task_site_fee_percent', PercentageConstants::SOCIAL_TASK_FEE_PERCENT);

        return [
            'platform' => strtolower((string)($data['platform'] ?? 'instagram')),
            'task_type' => strtolower((string)($data['task_type'] ?? 'follow')),
            'title' => trim((string)($data['title'] ?? '')),
            'description' => trim((string)($data['description'] ?? '')),
            'link' => trim((string)($data['link'] ?? $data['target_link'] ?? $data['target_url'] ?? '')),
            'price_per_task' => $price,
            'currency' => $currency,
            'total_count' => $count,
            'total_budget' => $price * $count,
            'site_commission_percent' => $feePercent,
            'requires_admin_review' => (bool)$this->appSettings->get('social_task_requires_admin_review', 0),
        ];
    }
}
