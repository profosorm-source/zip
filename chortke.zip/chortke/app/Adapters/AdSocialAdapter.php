<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use Core\Database;
use App\Services\Settings\AppSettings;
use App\Constants\PercentageConstants;
use Core\ValueObjects\Money;
use App\Services\Shared\IdempotencyService;
use App\Models\Ads;

/**
 * AdSocialAdapter - creates SocialTask ad records only.
 * Financial hold/withdraw is handled centrally by AdSystemManager.
 */
/**
 * @phpstan-type SocialAdInput array<string, mixed>
 * @phpstan-type SocialAdNormalized array{
 *   platform: string, task_type: string, title: string, description: string,
 *   link: string, price_per_task: string, currency: string, total_count: int,
 *   total_budget: string, site_commission_percent: string, requires_admin_review: bool
 * }
 * @phpstan-type AdAdapterResult array<string, mixed>
 */
class AdSocialAdapter extends AdapterBase implements AdSystemContract
{
    public function __construct(
        private Ads $adModel,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory
    ) {
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    private function decimalSetting(string $key, string $default): string
    {
        $value = $this->appSettings->get($key, $default);
        // FIX-P3-ADP-003: فقط decimal خوش‌فرم (نماد علمی/غیرعددی → default) —
        // مقدار بدشکل به bccomp می‌رفت و در PHP 8 ValueError می‌داد.
        return self::wellFormedDecimal($value) ?? self::wellFormedDecimal($default) ?? '0';
    }

    public function getType(): string
    {
        return 'social_task';
    }

    /**
         * @param SocialAdInput $data
         * @return AdAdapterResult
         */
    public function create(int $userId, array $data): array
    {
        try {
            // FIX-P3-ADP-005: نرمال‌سازی تک‌گذر — create() دیتای نرمال‌شده را از
            // validate() می‌گیرد (validate تنها نقطهٔ normalize است) و دوباره normalize نمی‌کند.
            $validation = $this->validate($data);
            if (!$validation['valid']) {
                return $this->errorResponse('اطلاعات وارد شده معتبر نیست', $validation['errors']);
            }
            $data = $validation['data'];

            $ad = $this->adModel->create([
                'user_id' => $userId,
                'type' => 'social_task',
                'platform' => $data['platform'],
                'task_type' => $data['task_type'],
                'title' => $data['title'],
                'description' => $data['description'] ?: null,
                'link' => $data['link'],
                'target_url' => $data['link'],
                'price_per_task' => $data['price_per_task'],
                'currency' => $data['currency'],
                'total_budget' => $data['total_budget'],
                'remaining_budget' => $data['total_budget'],
                'total_count' => $data['total_count'],
                'remaining_count' => $data['total_count'],
                'pending_count' => 0,
                'completed_count' => 0,
                'site_commission_percent' => $data['site_commission_percent'],
                'status' => $data['requires_admin_review'] ? 'pending_review' : 'active',
                'created_by' => $userId,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            if (!$ad) {
                return $this->errorResponse('خطا در نهایی‌سازی تبلیغ در سیستم.');
            }
            // FIX-P3-ADP-006: استخراج شناسه هم‌الگوی AdTubeAdapter — علاوه بر int،
            // شکل‌های object/numeric هم استخراج می‌شوند؛ شکل true مدل (insert موفق
            // بدون ID) «موفقیتِ بدون شناسه» جعل نمی‌شود چون قرارداد ساگا
            // (AdSystemManager::create_ad_record) شناسهٔ int را الزامی می‌کند —
            // شکست صادقانه + رؤیت‌پذیری در لاگ برای پیگیری دستی رکورد یتیم.
            $adId = 0;
            if (is_object($ad)) {
                $adVars = get_object_vars($ad);
                $adId = is_numeric($adVars['id'] ?? null) ? (int)$adVars['id'] : 0;
            } elseif (is_numeric($ad)) {
                $adId = (int)$ad;
            }
            if ($adId <= 0) {
                $this->logError('create_id_unavailable', 'ads insert succeeded without a retrievable id', ['user_id' => $userId]);
                return $this->errorResponse('خطا در نهایی‌سازی تبلیغ در سیستم.');
            }

            return $this->successResponse('تسک شبکه اجتماعی با موفقیت ثبت شد.', ['id' => $adId, 'ad_id' => $adId]);
        } catch (\Throwable $e) {
            $this->logError('create', $e->getMessage(), ['user_id' => $userId]);
            return $this->errorResponse('خطای سیستمی در ایجاد تبلیغ شبکه اجتماعی رخ داد.');
        }
    }

    /**
         * قرارداد validate (FIX-P3-ADP-024/067): خروجی همیشه شکل
         * ['valid' => bool, 'errors' => list<string>, 'data' => array] است؛
         * خرابی نرمال‌سازی/Money هرگز به‌صورت exception بیرون نمی‌زند (valid=false عمومی).
         * کلید 'data' حاصل normalize تک‌گذر است (مصرف create بدون normalize دوباره).
         *
         * @param SocialAdInput $data
         * @return array{valid: bool, errors: list<string>, data: array<string, mixed>}
         */
    public function validate(array $data, bool $isUpdate = false): array
    {
        $errors = [];
        // FIX-P3-ADP-002: گیت خام تعداد — قبل از هر clamp؛ ورودی ۰/منفی/اعشاری/غیرعددی
        // رد می‌شود نه اینکه خاموشاً به «خرید ۱ واحد» تبدیل شود.
        $countInput = $data['total_count'] ?? $data['quantity'] ?? 1;
        $countRaw = is_string($countInput) ? trim($countInput) : $countInput;
        $countIsInteger = (is_int($countRaw) && $countRaw >= 1)
            || (is_string($countRaw) && $countRaw !== '' && ctype_digit($countRaw) && (int)$countRaw >= 1);
        if (!$countIsInteger) {
            $errors[] = 'تعداد درخواست حداقل باید ۱ عدد باشد';
        }
        try {
            $data = $this->normalize($data);
        } catch (\InvalidArgumentException $e) {
            // FIX-P3-ADP-067: خطای Money/normalize = ردّ دامنه‌ای، نه نشت استثنا.
            $this->logger->warning("adapter.{$this->getType()}.validate_normalize_failed", ['error' => self::sanitizeLogText($e->getMessage())]);
            return ['valid' => false, 'errors' => ['ورودی ارسالی معتبر نیست.'], 'data' => []];
        }

        $errors = array_merge($errors, $this->validateNormalized($data));
        return ['valid' => empty($errors), 'errors' => $errors, 'data' => $data];
    }

    /** @param SocialAdNormalized $data @return list<string> */
    private function validateNormalized(array $data): array
    {
        $errors = [];

        if (!in_array($data['platform'], ['instagram', 'telegram', 'twitter', 'tiktok', 'facebook', 'other'], true)) {
            $errors[] = 'پلتفرم نامعتبر است';
        }
        if ($data['platform'] === 'youtube') {
            $errors[] = 'YouTube باید از مسیر AdTube ثبت شود.';
        }
        if (!in_array($data['task_type'], ['follow', 'like', 'comment', 'share', 'view', 'join', 'subscribe', 'retweet', 'other'], true)) {
            $errors[] = 'نوع تسک نامعتبر است';
        }
        if (mb_strlen($data['title']) < 3) {
            $errors[] = 'عنوان تبلیغ نباید خالی باشد';
        }
        if ($data['link'] === '') {
            $errors[] = 'آدرس یا آیدی کانال/صفحه الزامی است';
        } elseif (preg_match('/^@?[a-zA-Z0-9_.]+$/', $data['link']) !== 1 && !self::isSafeHttpUrl($data['link'])) {
            // FIX-P3-ADP-001: لینک‌های URL-شکل باید http/https با هاست معتبر باشند؛
            // فرم @handle/آیدی ساده مثل قبل مجاز است. FILTER_VALIDATE_URL تنها
            // هر scheme دلخواه (javascript:، data:، ftp:) را می‌پذیرفت.
            $errors[] = 'فرمت لینک یا آیدی وارد شده معتبر نیست';
        }
        $minPrice = $this->decimalSetting('social_task_min_price', '100');
        if (bccomp($data['price_per_task'], $minPrice, 8) < 0) {
            $errors[] = "حداقل قیمت هر تسک در شبکه‌های اجتماعی {$minPrice} تومان است";
        }
        // FIX-P3-ADP-003: سیاست مقیاس قیمت — حداکثر ۴ رقم اعشار (هم‌راستا با SCALE_FIAT)
        if (preg_match('/^\d+(\.\d{1,4})?$/', $data['price_per_task']) !== 1) {
            $errors[] = 'قیمت هر تسک باید عددی با حداکثر ۴ رقم اعشار باشد';
        }
        if ($data['total_count'] < 1) {
            $errors[] = 'تعداد درخواست حداقل باید ۱ عدد باشد';
        }

        return $errors;
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function isExpired(int $adId): bool
    {
        $ad = $this->adModel->find($adId);
        if (!$ad || !isset($ad->status) || !is_string($ad->status)) return true;
        if (in_array($ad->status, ['expired', 'completed'], true)) return true;
        // FIX-P3-ADP-008: بودجهٔ مفقود/غیراسکالر fail-closed است (منقضی در نظر گرفته
        // می‌شود) — حالت قبلی false برمی‌گرداند و کمپین بدون بودجهٔ قابل‌خواندن زنده می‌ماند.
        if (!isset($ad->remaining_budget) || !is_scalar($ad->remaining_budget)) return true;
        return Money::fromString((string)$ad->remaining_budget, isset($ad->currency) && is_string($ad->currency) ? $ad->currency : 'irt')->isZero();
    }

    /** @param SocialAdInput $context */
    public function calculateCost(string $amount, array $context = []): string
    {
        // FIX-P3-ADP-003: کارمزد همیشه clamp‌شدهٔ [0,100] (boundedFeePercent مشترک).
        $feePercent = $this->boundedFeePercent('social_task_site_fee_percent', (string)PercentageConstants::SOCIAL_TASK_FEE_PERCENT);
        $currency = is_string($context['currency'] ?? null) ? $context['currency'] : 'irt';
        return Money::fromString($amount, $currency)->percentage($feePercent)->getAmount();
    }

    /**
     * FIX-C52 (یافتهٔ ممیزی ۵۲): fail-loud — همان الگوی SeoAdAdapter؛ پرداخت ساختگی حذف شد.
     * @return AdAdapterResult
     * @deprecated Dead contract surface (F-A19d-03) — صفر call-site
     */
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        throw new \LogicException(
            'AdSocialAdapter::processPayment غیرفعال است (F-A19d-03/59): تسویهٔ مالی فقط از مسیر متمرکز escrow/AdsBudgetSettlementService انجام می‌شود.'
        );
    }

    /**
     * FIX-C52 (یافتهٔ ممیزی ۵۲): fail-loud — موفقیت ساختگی حذف شد.
     * @deprecated Dead contract surface (F-A19d-03) — صفر call-site
     */
    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        throw new \LogicException(
            'AdSocialAdapter::track غیرفعال است (F-A19d-03/59): ثبت رویداد فقط از مسیر AdsBudgetSettlementService انجام می‌شود.'
        );
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function getStatus(int $adId): ?array
    {
        $ad = $this->adModel->find($adId);
        if (!$ad) return null;
        $values = get_object_vars($ad);
        if (!isset($values['id'], $values['status']) || !is_scalar($values['id']) || !is_string($values['status'])) return null;
        return ['id' => (int)$values['id'], 'type' => 'social_task', 'status' => $values['status']];
    }

    /**
         * @param SocialAdInput $data
         * @return SocialAdNormalized
         */
    private function normalize(array $data): array
    {
        $currency = strtolower(is_scalar($data['currency'] ?? null) ? (string)$data['currency'] : 'irt');
        if (in_array($currency, ['irr', 'rial'], true)) {
            // FIX-R36-W3 (F-A19d-10): irr→irt بدون بازمقیاس ×10 — رؤیت‌پذیری با لاگ
            // (تصمیم محصول برای ردّ/مقیاس در رجیستر).
            $this->logger->warning('ads.currency.irr_relabelled_irt', ['ad_type' => $this->getType(), 'received' => $currency]);
            $currency = 'irt';
        }
        if (!in_array($currency, ['irt', 'usdt'], true)) $currency = 'irt';
        // FIX-P3-ADP-003: قیمت فقط decimal خوش‌فرم (نماد علمی → '0' → خطای حداقل قیمت)
        $priceInput = $data['price_per_task'] ?? null;
        $price = self::wellFormedDecimal($priceInput) ?? '0';
        $quantityInput = $data['total_count'] ?? $data['quantity'] ?? 1;
        $count = is_scalar($quantityInput) && is_numeric((string)$quantityInput) ? max(1, (int)$quantityInput) : 1;
        $feePercent = $this->boundedFeePercent('social_task_site_fee_percent', (string)PercentageConstants::SOCIAL_TASK_FEE_PERCENT); // FIX-P3-ADP-003
        $reviewSetting = $this->appSettings->get('social_task_requires_admin_review', 0);

        return [
            'platform' => strtolower(is_scalar($data['platform'] ?? null) ? (string)$data['platform'] : 'instagram'),
            'task_type' => strtolower(is_scalar($data['task_type'] ?? null) ? (string)$data['task_type'] : 'follow'),
            'title' => trim(is_scalar($data['title'] ?? null) ? (string)$data['title'] : ''),
            'description' => trim(is_scalar($data['description'] ?? null) ? (string)$data['description'] : ''),
            'link' => trim(is_scalar($data['link'] ?? null) ? (string)$data['link'] : (is_scalar($data['target_link'] ?? null) ? (string)$data['target_link'] : (is_scalar($data['target_url'] ?? null) ? (string)$data['target_url'] : ''))),
            'price_per_task' => $price,
            'currency' => $currency,
            'total_count' => $count,
            'total_budget' => Money::fromString($price, $currency)->multiply((string)$count)->getAmount(),
            'site_commission_percent' => $feePercent,
            'requires_admin_review' => is_scalar($reviewSetting) && (bool)$reviewSetting,
        ];
    }
}
