<?php

namespace App\Adapters;

use Core\ValueObjects\Money;
use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use App\Models\Ads;
use App\Contracts\WalletServiceInterface;
use App\Services\Shared\IdempotencyService;
use Core\Database;
use App\Services\Settings\AppSettings;

/**
 * @phpstan-type SeoAdNormalized array{
 *   title: string, site_url: string, target_url: string, keyword: string,
 *   description: string, budget: string, min_payout: string, max_payout: string,
 *   target_duration: int, min_score: int, max_per_day: int, currency: string,
 *   site_commission_percent: string, requires_admin_review: bool
 * }
 */
class SeoAdAdapter extends AdapterBase implements AdSystemContract
{
    private Ads $adModel;

    public function __construct(
        Ads $adModel,
        WalletServiceInterface $walletService,
        Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory,
        IdempotencyService $idempotencyService
    ) {
        $this->adModel = $adModel;
        unset($walletService, $db, $idempotencyService);
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string { return 'seo'; }

    public function create(int $userId, array $data): array
    {
        try {
            // FIX-P3-ADP-144: normalize/validate داخل try — خرابی نرمال‌سازی دیگر
            // create() را با استثنای خام ترک نمی‌کند (به valid=false نقشه می‌خورد).
            // قرارداد تک‌گذر: دیتای نرمال‌شده از validate() گرفته می‌شود.
            $validation = $this->validate($data);
            if (!$validation['valid']) {
                return $this->errorResponse('ورودی‌های تبلیغ سئو معتبر نیستند', $validation['errors']);
            }
            $data = $validation['data'];
            $adId = $this->adModel->create([
                'user_id' => $userId,
                'type' => 'seo',
                'title' => $data['title'],
                'site_url' => $data['site_url'],
                'target_url' => $data['target_url'],
                'link' => $data['target_url'],
                'keyword' => $data['keyword'],
                'description' => $data['description'] ?: null,
                'budget' => $data['budget'],
                'total_budget' => $data['budget'],
                'remaining_budget' => $data['budget'],
                'min_payout' => $data['min_payout'],
                'max_payout' => $data['max_payout'],
                'target_duration' => $data['target_duration'],
                'min_score' => $data['min_score'],
                'max_per_day' => $data['max_per_day'],
                'currency' => $data['currency'],
                'site_commission_percent' => $data['site_commission_percent'],
                'status' => $data['requires_admin_review'] ? 'pending_review' : 'active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            if (!$adId) {
                return $this->errorResponse('خطا در ایجاد رکورد SEO');
            }
            $id = is_object($adId) ? (is_numeric(get_object_vars($adId)['id'] ?? null) ? (int)get_object_vars($adId)['id'] : 0) : (is_numeric($adId) ? (int)$adId : 0);
            // FIX-P3-ADP-145: شناسهٔ <= 0 (شامل شکل true مدل = insert بدون ID) دیگر
            // «موفقیت با id صفر» نیست — هم‌الگوی AdTubeAdapter رد صادقانه است.
            if ($id <= 0) {
                $this->logError('create_id_unavailable', 'ads insert succeeded without a retrievable id', ['user_id' => $userId]);
                return $this->errorResponse('خطا در ایجاد رکورد SEO');
            }
            return $this->successResponse('تبلیغ SEO ایجاد شد', ['id' => $id, 'ad_id' => $id]);
        } catch (\Throwable $e) {
            $this->logError('create', $e->getMessage(), ['user_id' => $userId]);
            // FIX-P3-ADP-144: متن خام exception به پاسخ کاربر الصاق نمی‌شود؛ جزئیات فقط در لاگ.
            return $this->errorResponse('خطا در ایجاد تبلیغ سئو رخ داد.');
        }
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function isExpired(int $adId): bool
    {
        $ad = $this->adModel->find($adId);
        if (!is_object($ad)) return true;
        $vars = get_object_vars($ad);
        $status = is_string($vars['status'] ?? null) ? $vars['status'] : '';
        $remaining = is_numeric($vars['remaining_budget'] ?? null) ? (string)$vars['remaining_budget'] : '0';
        // FIX-P3-ADP-149: وضعیت 'completed' هم منقضی محسوب می‌شود (هم‌راستا با AdTubeAdapter).
        return in_array($status, ['expired', 'completed'], true) || bccomp($remaining, '0', 8) <= 0;
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        // FIX-P3-ADP-143: کارمزد همیشه clamp‌شدهٔ [0,100] (تنظیمات >100/منفی/نماد علمی).
        $feePercent = $this->boundedFeePercent('seo_ad_site_fee_percent', '15');
        $currency = is_string($context['currency'] ?? null) ? $context['currency'] : 'irt';
        // float→decimal: محاسبهٔ کارمزد با Money/BCMath به‌جای float
        return Money::fromString($amount, $currency)->percentage($feePercent)->getAmount();
    }

    /**
     * FIX-R36-W3 (F-A19d-03): برداشت واقعی wallet در این بدنه، «مسیر دومِ پرداخت»
     * بدون escrow/کسر بودجهٔ متمرکز بود — دقیقاً همان دبل-پرداختِ خاموش که قراردادِ
     * مرده نگاه می‌داشت (صفر call-site؛ تسویهٔ زندهٔ سئو از مسیر seo-payout است).
     * اکنون fail-loud: هر فراخوانی آینده فوراً دیده می‌شود.
     * @deprecated Dead contract surface (r36 audit F-A19d-03)
     */
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        throw new \LogicException(
            'SeoAdAdapter::processPayment غیرفعال است (F-A19d-03): تسویهٔ مالی سئو فقط از مسیر متمرکز seo-payout/AdSystemManager انجام می‌شود.'
        );
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        $this->logInfo('track', ['event' => $eventType, 'ad_id' => $adId, 'user_id' => $userId]);
        return $this->successResponse('رویداد ثبت شد');
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function getStatus(int $adId): ?array
    {
        $ad = $this->adModel->find($adId);
        if (!is_object($ad)) return null;
        $vars = get_object_vars($ad);
        return ['id' => is_numeric($vars['id'] ?? null) ? (int)$vars['id'] : 0, 'type' => 'seo', 'status' => is_string($vars['status'] ?? null) ? $vars['status'] : 'unknown'];
    }

    /**
     * قرارداد validate (FIX-P3-ADP-024/067): خروجی همیشه ['valid'=>bool,'errors'=>list,'data'=>array].
     * FIX-P3-ADP-141: target_url هم مثل site_url با policy URL امن اعتبارسنجی می‌شود.
     * FIX-P3-ADP-150: سقف طول keyword و سقف max_payout نسبت به budget.
     *
     * @param array<string, mixed> $data
     * @return array{valid: bool, errors: list<string>, data: array<string, mixed>}
     */
    public function validate(array $data, bool $isUpdate = false): array
    {
        try {
            $data = $this->normalize($data);
        } catch (\InvalidArgumentException $e) {
            $this->logger->warning("adapter.{$this->getType()}.validate_normalize_failed", ['error' => self::sanitizeLogText($e->getMessage())]);
            return ['valid' => false, 'errors' => ['ورودی ارسالی معتبر نیست.'], 'data' => []];
        }
        $errors = $this->validateNormalized($data);
        return ['valid' => empty($errors), 'errors' => $errors, 'data' => $data];
    }

    /**
     * @param SeoAdNormalized $data
     * @return list<string>
     */
    private function validateNormalized(array $data): array
    {
        $errors = [];

        if (mb_strlen($data['title']) < 3) $errors[] = 'عنوان کمپین الزامی است.';
        // FIX-P3-ADP-141: هر دو URL با policy امن http(s)+host — نه فقط FILTER_VALIDATE_URL
        if (!self::isSafeHttpUrl($data['site_url'])) $errors[] = 'آدرس سایت معتبر نیست.';
        if (!self::isSafeHttpUrl($data['target_url'])) $errors[] = 'آدرس مقصد معتبر نیست.';
        if (mb_strlen($data['keyword']) < 2) $errors[] = 'کلمه کلیدی الزامی است.';
        // FIX-P3-ADP-150: سقف طول کلمه کلیدی (cap صریح؛ سقف پایین‌دستیِ max_payout نسبت
        // به commission/day منتظر sign-off محصول است — این‌جا کف سالم: max_payout ≤ budget).
        if (mb_strlen($data['keyword']) > 100) $errors[] = 'کلمه کلیدی حداکثر ۱۰۰ کاراکتر است.';
        if (bccomp($data['budget'], '0', 8) <= 0) $errors[] = 'بودجه کل نامعتبر است.';
        if (bccomp($data['min_payout'], '0', 8) <= 0) $errors[] = 'حداقل پرداخت نامعتبر است.';
        if (bccomp($data['max_payout'], $data['min_payout'], 8) < 0) $errors[] = 'حداکثر پرداخت باید بیشتر یا برابر حداقل پرداخت باشد.';
        // FIX-P3-ADP-150: invariant سالم — یک کلیک هرگز نمی‌تواند بیش از کل بودجه پرداخت کند.
        if (bccomp($data['max_payout'], $data['budget'], 8) > 0) $errors[] = 'حداکثر پرداخت نمی‌تواند از بودجه کل بیشتر باشد.';
        if (bccomp($data['budget'], $data['min_payout'], 8) < 0) $errors[] = 'بودجه باید حداقل به اندازه حداقل پرداخت باشد.';
        if ($data['target_duration'] < 10 || $data['target_duration'] > 900) $errors[] = 'زمان هدف باید بین ۱۰ تا ۹۰۰ ثانیه باشد.';
        if ($data['min_score'] < 1 || $data['min_score'] > 100) $errors[] = 'حداقل امتیاز باید بین ۱ تا ۱۰۰ باشد.';

        return $errors;
    }

    /**
     * @param array<string, mixed> $data
     * @return SeoAdNormalized
     */
    private function normalize(array $data): array
    {
        $toString = static fn(mixed $v): string => is_scalar($v) ? trim((string)$v) : '';
        $toInt = static fn(mixed $v): int => is_numeric($v) ? (int)$v : 0;
        $currency = strtolower($toString($data['currency'] ?? 'irt'));
        if (in_array($currency, ['irr', 'rial'], true)) {
            // FIX-R36-W3 (F-A19d-10) + W4-D قرارداد کانونی تک‌ارز: برچسب‌زنی irr→irt
            // «بدون بازمقیاس ×10». مبلغ داخل سایت همیشه تومان است؛ کلاینتی که
            // currency=irr می‌فرستد فقط «برچسب» را اعلام کرده، نه واحدِ مبلغ را.
            // مقیاس‌کردن فقط در مرز آداپتورهای درگاه بانکی مجاز است، نه این‌جا.
            $this->logger->warning('ads.currency.irr_relabelled_irt', ['ad_type' => $this->getType(), 'received' => $currency]);
            $currency = 'irt';
        }
        if (!in_array($currency, ['irt', 'usdt'], true)) $currency = 'irt';

        $siteUrl = $toString($data['site_url'] ?? $data['target_link'] ?? $data['target_url'] ?? $data['link'] ?? '');
        $targetUrl = $toString($data['target_url'] ?? $data['target_link'] ?? $data['site_url'] ?? $data['link'] ?? $siteUrl);
        // float→decimal: مبالغ به‌صورت رشتهٔ decimal نگه داشته می‌شوند
        // FIX-P3-ADP-143: فقط decimal خوش‌فرم (نماد علمی → '0' → خطای اعتبارسنجی)
        $budgetInput = $data['budget'] ?? $data['total_budget'] ?? 0;
        $budget = self::wellFormedDecimal($budgetInput) ?? '0';
        $minPayoutInput = $data['min_payout'] ?? $data['price_per_click'] ?? $data['price_per_task'] ?? 0;
        $minPayout = self::wellFormedDecimal($minPayoutInput) ?? '0';
        $maxPayoutInput = $data['max_payout'] ?? null;
        $maxPayoutNumeric = self::wellFormedDecimal($maxPayoutInput);
        if ($maxPayoutNumeric !== null) {
            $maxPayout = $maxPayoutNumeric;
        } else {
            $ppc = self::wellFormedDecimal($data['price_per_click'] ?? null) ?? '0';
            $maxPayout = bccomp($minPayout, $ppc, 8) >= 0 ? $minPayout : $ppc;
        }
        // FIX-P3-ADP-143: کارمزد همیشه clamp‌شدهٔ [0,100].
        $feePercent = $this->boundedFeePercent('seo_ad_site_fee_percent', '15');

        return [
            'title' => $toString($data['title'] ?? ''),
            'site_url' => $siteUrl,
            'target_url' => $targetUrl,
            'keyword' => $toString($data['keyword'] ?? ''),
            'description' => $toString($data['description'] ?? ''),
            'budget' => $budget,
            'min_payout' => $minPayout,
            'max_payout' => $maxPayout,
            'target_duration' => max(10, min(900, $toInt($data['target_duration'] ?? 60))),
            'min_score' => max(1, min(100, $toInt($data['min_score'] ?? 40))),
            'max_per_day' => max(1, min(1000, $toInt($data['max_per_day'] ?? 10))),
            'currency' => $currency,
            'site_commission_percent' => $feePercent,
            'requires_admin_review' => (bool)$this->appSettings->get('seo_ad_requires_admin_review', 0),
        ];
    }
}
