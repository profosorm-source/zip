<?php

namespace App\Adapters;

use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use App\Models\Ads;
use App\Contracts\WalletServiceInterface;
use App\Services\Shared\IdempotencyService;
use Core\Database;
use App\Services\Settings\AppSettings;

class SeoAdAdapter extends AdapterBase implements AdSystemContract
{
    private Ads $adModel;
    private WalletServiceInterface $walletService;
    private Database $db;
    private IdempotencyService $idempotencyService;

    public function __construct(
        Ads $adModel,
        WalletServiceInterface $walletService,
        Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory,
        IdempotencyService $idempotencyService
    ) {
        $this->adModel = $adModel;
        $this->walletService = $walletService;
        $this->db = $db;
        $this->idempotencyService = $idempotencyService;
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string { return 'seo'; }

    public function create(int $userId, array $data): array
    {
        $data = $this->normalize($data);
        $validation = $this->validate($data);
        if (!$validation['valid']) {
            return $this->errorResponse('ورودی‌های تبلیغ سئو معتبر نیستند', $validation['errors']);
        }

        try {
            $adId = $this->adModel->create([
                'user_id' => $userId,
                'type' => 'seo',
                'title' => $data['title'],
                'site_url' => $data['site_url'],
                'target_url' => $data['target_url'],
                'link' => $data['target_url'],
                'keyword' => $data['keyword'],
                'description' => $data['description'] ?: null,
                'budget' => $data['budget'],
                'total_budget' => $data['budget'],
                'remaining_budget' => $data['budget'],
                'min_payout' => $data['min_payout'],
                'max_payout' => $data['max_payout'],
                'target_duration' => $data['target_duration'],
                'min_score' => $data['min_score'],
                'max_per_day' => $data['max_per_day'],
                'currency' => $data['currency'],
                'site_commission_percent' => $data['site_commission_percent'],
                'status' => $data['requires_admin_review'] ? 'pending_review' : 'active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            if (!$adId) {
                return $this->errorResponse('خطا در ایجاد رکورد SEO');
            }
            $id = is_object($adId) ? (int)$adId->id : (int)$adId;
            return $this->successResponse('تبلیغ SEO ایجاد شد', ['id' => $id, 'ad_id' => $id]);
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->logError('create', $e->getMessage());
            return $this->errorResponse('خطا در ایجاد تبلیغ SEO: ' . $e->getMessage());
        }
    }

    public function isExpired(int $adId): bool
    {
        $ad = $this->adModel->find($adId);
        return !$ad || $ad->status === 'expired' || (float)$ad->remaining_budget <= 0;
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        $feePercent = (float)$this->appSettings->get('seo_ad_site_fee_percent', 15);
        return (string)round(((float)$amount) * ($feePercent / 100), 8);
    }

    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        $this->assertFraudAllowed($userId, 'ad.payment', ['amount' => $amount, 'currency' => $currency, 'ad_id' => $adId]);
        $result = $this->walletService->withdraw($userId, $amount, $currency, ['type' => 'seo_payment']);
        return $result ? $this->successResponse('پرداخت موفق', ['transaction_id' => $result]) : $this->errorResponse('خطا در پرداخت');
    }

    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        $this->logInfo('track', ['event' => $eventType, 'ad_id' => $adId, 'user_id' => $userId]);
        return $this->successResponse('رویداد ثبت شد');
    }

    public function getStatus(int $adId): ?array
    {
        $ad = $this->adModel->find($adId);
        return $ad ? ['id' => $ad->id, 'type' => 'seo', 'status' => $ad->status] : null;
    }

    public function validate(array $data, bool $isUpdate = false): array
    {
        $data = $this->normalize($data);
        $errors = [];

        if (mb_strlen($data['title']) < 3) $errors[] = 'عنوان کمپین الزامی است.';
        if (!filter_var($data['site_url'], FILTER_VALIDATE_URL)) $errors[] = 'آدرس سایت معتبر نیست.';
        if (mb_strlen($data['keyword']) < 2) $errors[] = 'کلمه کلیدی الزامی است.';
        if ($data['budget'] <= 0) $errors[] = 'بودجه کل نامعتبر است.';
        if ($data['min_payout'] <= 0) $errors[] = 'حداقل پرداخت نامعتبر است.';
        if ($data['max_payout'] < $data['min_payout']) $errors[] = 'حداکثر پرداخت باید بیشتر یا برابر حداقل پرداخت باشد.';
        if ($data['budget'] < $data['min_payout']) $errors[] = 'بودجه باید حداقل به اندازه حداقل پرداخت باشد.';
        if ($data['target_duration'] < 10 || $data['target_duration'] > 900) $errors[] = 'زمان هدف باید بین ۱۰ تا ۹۰۰ ثانیه باشد.';
        if ($data['min_score'] < 1 || $data['min_score'] > 100) $errors[] = 'حداقل امتیاز باید بین ۱ تا ۱۰۰ باشد.';

        return ['valid' => empty($errors), 'errors' => $errors];
    }

    private function normalize(array $data): array
    {
        $currency = strtolower((string)($data['currency'] ?? 'irt'));
        if (in_array($currency, ['irr', 'rial'], true)) $currency = 'irt';
        if (!in_array($currency, ['irt', 'usdt'], true)) $currency = 'irt';

        $siteUrl = trim((string)($data['site_url'] ?? $data['target_link'] ?? $data['target_url'] ?? $data['link'] ?? ''));
        $targetUrl = trim((string)($data['target_url'] ?? $data['target_link'] ?? $data['site_url'] ?? $data['link'] ?? $siteUrl));
        $budget = (float)($data['budget'] ?? $data['total_budget'] ?? 0);
        $minPayout = (float)($data['min_payout'] ?? $data['price_per_click'] ?? $data['price_per_task'] ?? 0);
        $maxPayout = (float)($data['max_payout'] ?? max($minPayout, (float)($data['price_per_click'] ?? 0)));
        $feePercent = (float)$this->appSettings->get('seo_ad_site_fee_percent', 15);

        return [
            'title' => trim((string)($data['title'] ?? '')),
            'site_url' => $siteUrl,
            'target_url' => $targetUrl,
            'keyword' => trim((string)($data['keyword'] ?? '')),
            'description' => trim((string)($data['description'] ?? '')),
            'budget' => $budget,
            'min_payout' => $minPayout,
            'max_payout' => $maxPayout,
            'target_duration' => max(10, min(900, (int)($data['target_duration'] ?? 60))),
            'min_score' => max(1, min(100, (int)($data['min_score'] ?? 40))),
            'max_per_day' => max(1, min(1000, (int)($data['max_per_day'] ?? 10))),
            'currency' => $currency,
            'site_commission_percent' => $feePercent,
            'requires_admin_review' => (bool)$this->appSettings->get('seo_ad_requires_admin_review', 0),
        ];
    }
}
