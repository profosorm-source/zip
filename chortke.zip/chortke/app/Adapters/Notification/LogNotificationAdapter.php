<?php

declare(strict_types=1);

namespace App\Adapters\Notification;

use App\Models\Notification;
use App\Models\SystemTelemetryModel;
use App\Traits\ExternalCallTrait;
use App\Traits\ValidatesExternalUrl;
use Core\CircuitBreaker;
use Core\Logger;

/**
 * LogNotificationAdapter
 *
 * آداپتور ارسال نوتیفیکیشن‌ها و مدیریت هشدارها (عنوان قدیمیِ کپی‌شده از سرویسِ حذف‌شده در موج Round 22-A اصلاح شد)
 *
 * Section 8.3/8.4 — فراخوانی‌های HTTP خارجی (Telegram, Webhook) از طریق
 * ExternalCallTrait درون Core\CircuitBreaker اجرا می‌شوند تا در صورت
 * cascading failure مسیر hot به‌سرعت fail-fast شود.
 */
class LogNotificationAdapter
{
    use ExternalCallTrait;
    use ValidatesExternalUrl;

    // FIX-P3-ADP-105: schema bounds برای sendAlert — allowlist severity و سقف طول قبل از fan-out
    private const ALERT_SEVERITIES          = ['low', 'medium', 'high', 'critical'];
    private const MAX_ALERT_TITLE_LENGTH    = 200;
    private const MAX_ALERT_MESSAGE_LENGTH  = 4000;
    // FIX-P3-ADP-110: سقف حجم payload وب‌هوک
    private const MAX_WEBHOOK_PAYLOAD_BYTES = 65536;

    /**
     * @internal exposed for ExternalCallTrait::resolveCircuitBreaker()
     */
    protected CircuitBreaker $circuit;

    private \App\Services\Notification\NotificationOrchestrator $orchestrator;
    private Notification $notification;
    private SystemTelemetryModel $telemetry;
    private \App\Contracts\LoggerInterface $logger;
    public function __construct(
        Notification $notification,
        SystemTelemetryModel $telemetry,
        Logger $logger,
        CircuitBreaker $circuit,
        \App\Services\Notification\NotificationOrchestrator $orchestrator
    ) {
        $this->orchestrator = $orchestrator;
        unset($logger, $circuit);
        $this->logger       = $this->orchestrator->logger();
        $this->circuit      = $this->orchestrator->circuitBreaker();
        
        $this->notification = $notification;
        $this->telemetry = $telemetry;
    }

    /**
     * ارسال هشدار به تمام کانال‌های فعال
     */
    /**
     * FIX-C78 (یافتهٔ ۷۸): خروجی bool — قبلاً void بود و LogChannel همیشه
     * «موفق» برمی‌گشت حتی اگر همهٔ کانال‌ها شکست بخورند (retry policy
     * شکست را reset می‌کرد). اکنون true = حداقل یک کانال موفق.
     */
    public function sendAlert(string $title, string $message, string $severity = 'medium'): bool
    {
        // FIX-P3-ADP-105: قبل از fan-out — allowlist severity (نامعتبر → medium با لاگِ
        // دیدنی) و سقف طول title/message (سطح هر کانال سایز خام نمی‌بیند).
        if (!in_array($severity, self::ALERT_SEVERITIES, true)) {
            $this->logger->warning('log_notification.alert.severity_normalized', [
                'requested' => $severity,
                'normalized_to' => 'medium',
            ]);
            $severity = 'medium';
        }
        $title = mb_substr($title, 0, self::MAX_ALERT_TITLE_LENGTH);
        $message = mb_substr($message, 0, self::MAX_ALERT_MESSAGE_LENGTH);

        $channels = $this->notification->getActiveChannelsBySeverity($severity);
        $anySent = false;

        foreach ($channels as $channel) {
            try {
                $config = $this->decodeConfig($channel->config ?? null);

                $sent = match($channel->channel_type) {
                    'telegram' => $this->sendTelegram($config, $title, $message, $severity),
                    'email' => $this->sendEmail($config, $title, $message),
                    'sms' => $this->sendSMS($config, $title, $message),
                    'webhook' => $this->sendWebhook($config, $title, $message, $severity),
                    default => false
                };

                if ($sent) {
                    $anySent = true;
                }

                $this->notification->logHistory(
                    (int)$channel->id,
                    'alert',
                    $title,
                    $message,
                    $sent ? 'sent' : 'failed'
                );

            } catch (\Throwable $e) {
                // FIX-P3-ADP-115: history روی مسیر استثنا هم کامل می‌شود — قبلاً
                // logHistory('failed') فقط از مسیر موفقیت/شکستِ عادی رد می‌شد.
                $channelId = (isset($channel->id) && is_numeric($channel->id)) ? (int)$channel->id : null;
                if ($channelId !== null) {
                    try {
                        $this->notification->logHistory($channelId, 'alert', $title, $message, 'failed');
                    } catch (\Throwable) {
                        // history best-effort است؛ لاگِ خطای زیر مرجع است
                    }
                }
                $this->logger->error('log_notification.channel.send.failed', [
                    'channel' => 'notification',
                    'channel_id' => $channel->id ?? null,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return $anySent;
    }

    /**
     * ارسال پیام تلگرام (با CircuitBreaker + retry روی خطاهای transient)
     */
    /** @param array<string, mixed> $config */
    private function sendTelegram(array $config, string $title, string $message, string $severity): bool
    {
        if (empty($config['bot_token']) || empty($config['chat_id'])) {
            return false;
        }

        $emoji = match($severity) {
            'low' => '🔵',
            'medium' => '🟡',
            'high' => '🟠',
            'critical' => '🔴',
            default => '⚪'
        };

        // FIX-P3-ADP-106: title/message در Markdown escape می‌شوند — کاراکترهای
        // خاصِ Telegram (\ * _ ` [) دیگر فرمتِ پیام را نمی‌شکنند (backslash اول).
        $escapeLegacyMarkdown = static function (string $text): string {
            return str_replace(
                ['\\', '*', '_', '`', '['],
                ['\\\\', '\\*', '\\_', '\\`', '\\['],
                $text
            );
        };
        $safeTitle = $escapeLegacyMarkdown($title);
        $safeMessage = $escapeLegacyMarkdown($message);

        $text = "{$emoji} *{$safeTitle}*\n\n{$safeMessage}\n\n⏰ " . date('Y-m-d H:i:s');
        $botToken = is_string($config['bot_token'] ?? null) ? trim($config['bot_token']) : '';
        if (preg_match('/^\d{5,}:[A-Za-z0-9_-]{20,}$/', $botToken) !== 1) {
            $this->logger->warning('log_notification.telegram.invalid_bot_token');
            return false;
        }
        $apiBase = config('services.telegram.api_base_url', 'https://api.telegram.org');
        $apiBase = is_string($apiBase) && $apiBase !== '' ? rtrim($apiBase, '/') : 'https://api.telegram.org';
        $url = $apiBase . '/bot' . $botToken . '/sendMessage';
        if (!$this->isExternalUrlSafe($url)) {
            $this->logger->warning('log_notification.telegram.ssrf_blocked', ['host'=>parse_url($url, PHP_URL_HOST)]);
            return false;
        }

        $chatId = is_string($config['chat_id'] ?? null) || is_int($config['chat_id'] ?? null)
            ? (string)$config['chat_id']
            : '';
        // FIX-P3-ADP-106: فرمت chat_id اعتبارسنجی می‌شود — عددی (منفی مجاز) یا
        // @channelusername؛ chat_id خام/آلوده به درخواست راه ندارد.
        if (preg_match('/^-?\d{1,20}$/', $chatId) !== 1 && preg_match('/^@[A-Za-z0-9_]{4,64}$/', $chatId) !== 1) {
            $this->logger->warning('log_notification.telegram.invalid_chat_id');
            return false;
        }

        $data = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'Markdown'
        ];

        try {
            return (bool) $this->callWithBreaker('log_notif_telegram', function () use ($url, $data): bool {
                return $this->retryTransient(function () use ($url, $data): bool {
                    $ch = curl_init($url);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $data,
                        CURLOPT_TIMEOUT        => 10,
                        CURLOPT_CONNECTTIMEOUT => 5,
                    ]);
                    $response = curl_exec($ch);
                    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $errno    = (int) curl_errno($ch);
                    curl_close($ch);

                    if ($httpCode === 200) {
                        // FIX-P3-ADP-106: Telegram موفقیت را با ok==true اعلام می‌کند —
                        // HTTP 200 تنها success نیست (ok=false روی 200 خطای semantic است).
                        $decoded = json_decode((string)$response, true);
                        if (is_array($decoded) && ($decoded['ok'] ?? null) === true) {
                            return true;
                        }
                        $this->logger->warning('log_notification.telegram.semantic_failure', [
                            'body' => mb_substr((string)$response, 0, 200),
                        ]);
                        throw new \Core\Exceptions\PermanentFailure('Telegram response ok!=true');
                    }
                    throw $this->classifyHttpFailure($httpCode, $errno, (string)$response, ['provider' => 'log_notif_telegram']);
                });
            });
        } catch (\Core\Exceptions\PermanentFailure $e) {
            $this->logger->warning('log_notification.telegram.permanent_failure', [
                'channel' => 'notification',
                'error' => $e->getMessage(),
            ]);
            return false;
        } catch (\Throwable $e) {
            $this->logger->error('log_notification.telegram.send.failed', [
                'channel' => 'notification',
                'class' => get_class($e),
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * ارسال ایمیل
     */
    /** @param array<string, mixed> $config */
    private function sendEmail(array $config, string $title, string $message): bool
    {
        $email = is_string($config['email'] ?? null) ? trim($config['email']) : '';
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        // AL2/Finding #15: Strip CRLF from subject to prevent Email Header Injection
        $cleanTitle = str_replace(["\r", "\n"], ' ', $title);
        $subject = "🔔 {$cleanTitle}";

        // Finding #16: Escape HTML title and message
        $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $safeMessage = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

        $body = "
        <html>
        <body style='font-family: Tahoma, Arial; direction: rtl;'>
            <h2 style='color: #d32f2f;'>{$safeTitle}</h2>
            <p>{$safeMessage}</p>
            <hr>
            <small>زمان: " . date('Y-m-d H:i:s') . "</small>
        </body>
        </html>
        ";

        $headers = [
            'From: System Alert <noreply@chortke.com>',
            'Content-Type: text/html; charset=UTF-8',
            'MIME-Version: 1.0'
        ];

        return mail($email, $subject, $body, implode("\r\n", $headers));
    }

    /**
     * ارسال SMS
     */
    /** @param array<string, mixed> $config */
    private function sendSMS(array $config, string $title, string $message): bool
    {
        // FIX-P3-ADP-109: کانالِ فعالِ بدون پیاده‌سازی باید شکستِ دیدنی بدهد،
        // نه false خاموش — operator می‌فهمد که باید کانال sms را غیرفعال کند.
        $this->logger->warning('log_notification.sms_channel_unimplemented', [
            'title' => mb_substr($title, 0, 80),
        ]);
        return false;
    }

    /**
     * ارسال به Webhook (با CircuitBreaker + retry روی خطاهای transient)
     */
    /** @param array<string, mixed> $config */
    private function sendWebhook(array $config, string $title, string $message, string $severity): bool
    {
        if (empty((is_string($config['url'] ?? null) ? $config['url'] : ''))) {
            return false;
        }

        // FIX-P3-ADP-111: json_encode با JSON_THROW_ON_ERROR — false هرگز به
        // CURLOPT_POSTFIELDS نمی‌رسد؛ شکستِ encode = شکستِ صریحِ کانال.
        try {
            $payload = json_encode([
                'title' => $title,
                'message' => $message,
                'severity' => $severity,
                'timestamp' => time()
            ], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        } catch (\JsonException $e) {
            $this->logger->error('log_notification.webhook.json_encode_failed', ['error' => $e->getMessage()]);
            return false;
        }

        // FIX-P3-ADP-110: سقف حجم payload قبل از transport — payload بزرگ‌تر از 64KB ارسال نمی‌شود.
        if (strlen($payload) > self::MAX_WEBHOOK_PAYLOAD_BYTES) {
            $this->logger->warning('log_notification.webhook.payload_too_large', ['bytes' => strlen($payload)]);
            return false;
        }

        if (!$this->isExternalUrlSafe((string)(is_string($config['url'] ?? null) ? $config['url'] : ''))) {
            $this->logger->warning('log_notification.webhook.ssrf_blocked', ['host' => parse_url((string)(is_string($config['url'] ?? null) ? $config['url'] : ''), PHP_URL_HOST)]);
            return false;
        }

        // مشتق نام برای CB از host وب‌هوک تا breakerهای کانال‌های جدا مستقل باشند
        $host = parse_url((string)(is_string($config['url'] ?? null) ? $config['url'] : ''), PHP_URL_HOST) ?: 'unknown';
        $providerName = 'log_notif_webhook_' . $host;

        try {
            return (bool) $this->callWithBreaker($providerName, function () use ($config, $payload, $providerName): bool {
                return $this->retryTransient(function () use ($config, $payload, $providerName): bool {
                    $ch = curl_init((string)(is_string($config['url'] ?? null) ? $config['url'] : ''));
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $payload,
                        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                        CURLOPT_TIMEOUT        => 10,
                        CURLOPT_CONNECTTIMEOUT => 5,
                    ]);
                    $response = curl_exec($ch);
                    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $errno    = (int) curl_errno($ch);
                    curl_close($ch);

                    if ($httpCode >= 200 && $httpCode < 300) {
                        return true;
                    }
                    throw $this->classifyHttpFailure($httpCode, $errno, (string)$response, ['provider' => $providerName ?? 'log_notif_webhook']);
                });
            });
        } catch (\Core\Exceptions\PermanentFailure $e) {
            $this->logger->warning('log_notification.webhook.permanent_failure', [
                'channel' => 'notification',
                'error' => $e->getMessage(),
            ]);
            return false;
        } catch (\Throwable $e) {
            $this->logger->error('log_notification.webhook.send.failed', [
                'channel' => 'notification',
                'class' => get_class($e),
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * تست کانال نوتیفیکیشن
     */
    /** @return array<string, mixed> */
    public function testChannel(int $channelId): array
    {
        $channel = $this->notification->getChannel($channelId);

        if (!$channel) {
            return ['success' => false, 'message' => 'کانال یافت نشد'];
        }

        $channelVars = get_object_vars($channel);
        $config = $this->decodeConfig($channelVars['config'] ?? null);
        $channelType = is_string($channelVars['channel_type'] ?? null) ? $channelVars['channel_type'] : '';

        // FIX-P3-ADP-112: پیامِ صادقانه برای کانالِ بدون پیاده‌سازی (sms)
        if ($channelType === 'sms') {
            return ['success' => false, 'message' => 'کانال پیامک هنوز پیاده‌سازی نشده است'];
        }

        $success = match($channelType) {
            'telegram' => $this->sendTelegram(
                $config,
                'تست سیستم',
                'این یک پیام تست است',
                'low'
            ),
            'email' => $this->sendEmail($config, 'تست سیستم', 'این یک ایمیل تست است'),
            'webhook' => $this->sendWebhook($config, 'تست سیستم', 'این یک تست وبهوک است', 'low'),
            default => false
        };

        return [
            'success' => $success,
            'message' => $success ? 'پیام با موفقیت ارسال شد' : 'ارسال پیام ناموفق بود'
        ];
    }

    /**
     * بررسی و اجرای قوانین هشدار
     */
    public function checkAlertRules(): void
    {
        $rules = $this->telemetry->getActiveAlertRules();

        foreach ($rules as $rule) {
            try {
                $condition = $this->decodeConfig($rule->condition ?? null);
                $triggered = $this->evaluateRule($rule, $condition);

                if ($triggered) {
                    $lastTrigger = $rule->last_triggered_at ? strtotime((string)$rule->last_triggered_at) : 0;

                    // fast-path: پنجرهٔ suppression از روی ردیف خوانده‌شده — مسیر گرمِ
                    // بدون کوئری؛ تصمیمِ نهایی با claim اتمیک پایین‌تر است.
                    if (time() - $lastTrigger < 3600) {
                        continue;
                    }

                    // FIX-P3-ADP-113: claim اتمیک قبل از ارسال — خواندن last_triggered_at
                    // و UPDATE بی‌قیدی بعد از آن TOCTOU داشت و دو worker همزمان هر دو
                    // ارسال می‌کردند. الان فقط برندهٔ claim ارسال می‌کند.
                    if (!$this->telemetry->claimAlertRuleTrigger((int)$rule->id, 3600)) {
                        $this->logger->info('log_notification.alert_rule.claim_lost', [
                            'rule_id' => $rule->id ?? null,
                        ]);
                        continue;
                    }

                    $sent = $this->sendAlert(
                        (string)$rule->rule_name,
                        "قانون '{$rule->rule_name}' فعال شد",
                        (string)$rule->severity
                    );

                    // FIX-P3-ADP-114 + FIX-P3-ADP-113: خودِ claim ack است؛ اما اگر ارسال
                    // کاملاً شکست خورد claim پس داده می‌شود تا suppression یک‌ساعته به
                    // خاطر قطعیِ گذرای کانال‌ها مسلح نشود.
                    if (!$sent) {
                        $this->telemetry->releaseAlertRuleClaim((int)$rule->id, $rule->last_triggered_at ?? null);
                        $this->logger->warning('log_notification.alert_rule.not_acked_all_channels_failed', [
                            'rule_id' => $rule->id ?? null,
                        ]);
                    }
                }
            } catch (\Throwable $e) {
                $this->logger->error('log_notification.alert_rule.check.failed', [
                    'channel' => 'notification',
                    'rule_id' => $rule->id ?? null,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }

    /**
     * ارزیابی قانون هشدار
     */
    /** @return array<string, mixed> */
    private function decodeConfig(mixed $raw): array
    {
        if (is_array($raw)) return $raw;
        if (!is_string($raw) || trim($raw) === '') return [];
        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    /** @param array<string, mixed> $condition */
    private function evaluateRule(object $rule, array $condition): bool
    {
        $metric = is_string($condition['metric'] ?? null) ? $condition['metric'] : '';
        $operator = is_string($condition['operator'] ?? null) ? $condition['operator'] : '>';
        $ruleVars = get_object_vars($rule);
        $timeWindow = is_numeric($ruleVars['time_window'] ?? null) ? (int)$ruleVars['time_window'] : 0;
        $threshold = is_numeric($ruleVars['threshold'] ?? null) ? (int)$ruleVars['threshold'] : 0;

        // FIX-P3-ADP-116: سقفِ سخت روی پنجرهٔ زمانی (ساعت → دقیقه، حداکثر یک روز)
        $timeWindow = max(0, min($timeWindow, 1440));

        // FIX-P3-ADP-116: متریکِ ناشناخته = قانونِ خراب — بی‌صدا ۰ نمی‌شود؛
        // با لاگ warning دیده می‌شود و false برمی‌گردد.
        $value = match($metric) {
            'error_count' => $this->telemetry->getErrorCount($timeWindow),
            'critical_errors' => $this->telemetry->getCriticalErrorCount($timeWindow),
            'slow_requests' => $this->telemetry->getSlowRequestCount($timeWindow),
            'failed_login' => $this->telemetry->getFailedLoginCount($timeWindow),
            default => null,
        };
        if ($value === null) {
            $this->logger->warning('log_notification.alert_rule.unknown_metric', [
                'rule_id' => $ruleVars['id'] ?? null,
                'metric' => $metric,
            ]);
            return false;
        }

        // FIX-P3-ADP-116: عملگرِ ناشناخته هم دیدنی می‌شود (default => false خاموش ممنوع)
        $result = match($operator) {
            '>' => $value > $threshold,
            '>=' => $value >= $threshold,
            '<' => $value < $threshold,
            '<=' => $value <= $threshold,
            '==' => $value === $threshold, // FIX-P3-ADP-117: مقایسهٔ strict — هر دو int
            default => null,
        };
        if ($result === null) {
            $this->logger->warning('log_notification.alert_rule.unknown_operator', [
                'rule_id' => $ruleVars['id'] ?? null,
                'operator' => $operator,
            ]);
            return false;
        }

        return $result;
    }
}
