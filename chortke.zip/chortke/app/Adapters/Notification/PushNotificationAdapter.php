<?php

declare(strict_types=1);

namespace App\Adapters\Notification;

use App\Contracts\LoggerInterface;

class PushNotificationAdapter
{
    private \App\Services\Notification\FcmService $fcmService;
    // FIX-P3-ADP-121: وابستگی logger با delegate (FcmService) هم‌قرارداد شد —
    // App\Contracts\LoggerInterface به‌جای concrete Core\Logger.
    private LoggerInterface $logger;

    public function __construct(\App\Services\Notification\FcmService $fcmService, LoggerInterface $logger) {
        $this->fcmService = $fcmService;
        $this->logger = $logger;
    }

    /** @param array<string, mixed> $data */
    public function sendToUser(int $userId, string $title, string $body, array $data = [], ?string $imageUrl = null, ?string $clickUrl = null): bool
    {
        try {
            return $this->fcmService->sendToUser($userId, $title, $body, $data, $imageUrl, $clickUrl);
        } catch (\Throwable $e) {
            $this->logger->error('push.sendToUser.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * @param list<string> $tokens
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function sendToTokens(array $tokens, string $title, string $body, array $data = [], ?string $imageUrl = null, ?string $clickUrl = null): array
    {
        try {
            return $this->fcmService->sendToTokens($tokens, $title, $body, $data, $imageUrl, $clickUrl);
        } catch (\Throwable $e) {
            $this->logger->error('push.sendToTokens.failed', ['tokens_count' => count($tokens), 'error' => $e->getMessage()]);
            return ['sent' => 0, 'failed' => count($tokens)]; // FIX-C78: هم‌کلید با FcmNotificationAdapter (sent/failed)
        }
    }
}
