<?php

declare(strict_types=1);

namespace App\Adapters\Notification;

use Core\Logger;

class PushNotificationAdapter
{
    private FcmNotificationAdapter $fcmAdapter;
    private Logger $logger;

    public function __construct(FcmNotificationAdapter $fcmAdapter, Logger $logger) {
        $this->fcmAdapter = $fcmAdapter;
        $this->logger = $logger;
    }

    public function sendToUser(int $userId, string $title, string $body, array $data = [], ?string $imageUrl = null, ?string $clickUrl = null): bool
    {
        try {
            return $this->fcmAdapter->sendToUser($userId, $title, $body, $data, $imageUrl, $clickUrl);
        } catch (\Throwable $e) {
            $this->logger->error('push.sendToUser.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            return false;
        }
    }
    
    public function sendToTokens(array $tokens, string $title, string $body, array $data = [], ?string $imageUrl = null, ?string $clickUrl = null): array
    {
        try {
            return $this->fcmAdapter->sendToTokens($tokens, $title, $body, $data, $imageUrl, $clickUrl);
        } catch (\Throwable $e) {
            $this->logger->error('push.sendToTokens.failed', ['tokens_count' => count($tokens), 'error' => $e->getMessage()]);
            return ['success' => 0, 'failure' => count($tokens)];
        }
    }
}


