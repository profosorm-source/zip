<?php

namespace App\Adapters\Notification;

use Core\Logger;
use Core\Cache;
use Core\Database;
use Core\CircuitBreaker;
use App\Contracts\MetricsCollectorInterface;
use App\Traits\ExternalCallTrait;
use App\Traits\ValidatesExternalUrl;

/**
 * FcmNotificationAdapter — ارسال Push Notification با Firebase Cloud Messaging (FCM)
 *
 * ─── تنظیمات .env مورد نیاز ────────────────────────────────────────────────
 *  FCM_SERVICE_ACCOUNT_JSON=/path/to/storage/firebase-service-account.json
 *  FCM_PROJECT_ID=your-firebase-project-id
 *
 * ─── نحوه استفاده ──────────────────────────────────────────────────────────
 *  $fcm->sendToToken($fcmToken, 'عنوان', 'متن', ['key' => 'val']);
 *  $fcm->sendToTokens([$token1, $token2], 'عنوان', 'متن');
 */

class FcmNotificationAdapter
{
    use \App\Traits\ValidatesExternalUrl;
    use ExternalCallTrait;

    private \App\Services\Notification\NotificationOrchestrator $orchestrator;
    private \App\Contracts\LoggerInterface $logger;
    private MetricsCollectorInterface $metrics;
    private CircuitBreaker $circuit;
    private ?\App\Services\Notification\FcmService $fcmService;
    private ?\App\Contracts\OutboxServiceInterface $outbox;
    private ?\Core\Queue $queue;
    private ?string   $projectId;
    private ?string   $serviceAccountPath;

    private const FCM_ENDPOINT     = 'https://fcm.googleapis.com/v1/projects/%s/messages:send';
    private const TOKEN_CACHE_KEY  = 'fcm:access_token';
    private const TOKEN_TTL        = 55;   // دقیقه (access token هر ساعت expire می‌شود)
    private const BATCH_SIZE       = 500;  // حداکثر FCM multicast batch

    public function __construct(
        MetricsCollectorInterface $metrics,
        \App\Services\Notification\NotificationOrchestrator $orchestrator,
        ?\App\Services\Notification\FcmService $fcmService = null,
        ?\App\Contracts\OutboxServiceInterface $outbox = null,
        ?\Core\Queue $queue = null
    ) {
        $this->orchestrator       = $orchestrator;
        $this->logger             = $this->orchestrator->logger();
        $this->circuit            = $this->orchestrator->circuitBreaker();
        $this->fcmService         = $fcmService;
        $this->outbox             = $outbox;
        $this->queue              = $queue;
        
        $this->metrics            = $metrics;
        $this->projectId          = config('services.fcm.project_id');
        $this->serviceAccountPath = config('services.fcm.service_account_json');
    }

    /**
     * ارسال به یک token
     */
    public function sendToToken(
        string $fcmToken,
        string $title,
        string $body,
        array  $data      = [],
        ?string $imageUrl = null,
        ?string $clickUrl = null
    ): bool {
        if (!$this->isConfigured()) {
            $this->logger->warning('fcm.not_configured');
            return false;
        }

        if ($this->isFcmCircuitOpen()) {
            $this->logger->warning('fcm.circuit_open_skipped', ['token' => substr($fcmToken, 0, 8) . '...']);
            $this->metrics->increment('fcm.circuit.open_skipped');
            return false;
        }

        $payload = $this->buildPayload($title, $body, $data, $imageUrl, $clickUrl);
        $payload['message']['token'] = $fcmToken;

        $startTime = microtime(true);
        try {
            $success = $this->dispatch($payload);
            $duration = microtime(true) - $startTime;
            $this->metrics->timing('fcm.dispatch.latency', $duration);

            if ($success) {
                $this->recordFcmSuccess();
                $this->metrics->increment('fcm.send.success');
            } else {
                $this->recordFcmFailure();
                $this->metrics->increment('fcm.send.failure');
            }
            return $success;
        } catch (\Throwable $e) {
            $duration = microtime(true) - $startTime;
            $this->metrics->timing('fcm.dispatch.latency', $duration);
            $this->recordFcmFailure();
            $this->metrics->increment('fcm.send.error');
            throw $e;
        }
    }

    /**
     * ارسال به چند token (batch) - بازطراحی شده با curl_multi جهت حذف گلوگاه I/O مسدودکننده
     */
    public function sendToTokens(
        array  $fcmTokens,
        string $title,
        string $body,
        array  $data      = [],
        ?string $imageUrl = null,
        ?string $clickUrl = null
    ): array {
        if (!$this->isConfigured() || empty($fcmTokens)) {
            return ['sent' => 0, 'failed' => count($fcmTokens)];
        }

        if ($this->isFcmCircuitOpen()) {
            $this->logger->warning('fcm.circuit_open_skipped_batch');
            $this->metrics->increment('fcm.circuit.open_skipped', count($fcmTokens));
            return ['sent' => 0, 'failed' => count($fcmTokens)];
        }

        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return ['sent' => 0, 'failed' => count($fcmTokens)];
        }

        $sent   = 0;
        $failed = 0;
        $url    = sprintf(self::FCM_ENDPOINT, $this->projectId);
        $basePayload = $this->buildPayload($title, $body, $data, $imageUrl, $clickUrl);

        $startTime = microtime(true);

        // پردازش دسته‌ای موازی با curl_multi جهت اجرای بهینه بدون قفل کردن صف‌ها
        foreach (array_chunk($fcmTokens, 50) as $batch) {
            $mh = curl_multi_init();
            $handles = [];

            foreach ($batch as $token) {
                $payload = $basePayload;
                $payload['message']['token'] = $token;

                $json = json_encode(array_filter($payload['message'], fn($v) => $v !== null), JSON_UNESCAPED_UNICODE);
                $bodyJson = json_encode(['message' => json_decode($json, true)], JSON_UNESCAPED_UNICODE);

                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $bodyJson,
                    CURLOPT_HTTPHEADER     => [
                        'Authorization: Bearer ' . $accessToken,
                        'Content-Type: application/json',
                    ],
                    CURLOPT_TIMEOUT        => 10,
                    CURLOPT_CONNECTTIMEOUT => 5,
                ]);

                curl_multi_add_handle($mh, $ch);
                $handles[$token] = ['ch' => $ch, 'body' => $bodyJson];
            }

            $active = null;
            do {
                $mrc = curl_multi_exec($mh, $active);
            } while ($mrc === CURLM_CALL_MULTI_PERFORM);

            while ($active && $mrc === CURLM_OK) {
                if (curl_multi_select($mh) === -1) {
                    usleep(100);
                }
                do {
                    $mrc = curl_multi_exec($mh, $active);
                } while ($mrc === CURLM_CALL_MULTI_PERFORM);
            }

            foreach ($handles as $token => $item) {
                $ch = $item['ch'];
                $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $response = curl_multi_getcontent($ch);

                if ($httpCode === 200) {
                    $sent++;
                    $this->metrics->increment('fcm.send.success');
                } else {
                    $failed++;
                    $this->metrics->increment('fcm.send.failure');

                    if ($httpCode === 401) {
                        $this->orchestrator->cache()->forget(self::TOKEN_CACHE_KEY);
                    }
                    if ($httpCode === 404 || $httpCode === 400 || str_contains((string)$response, 'UNREGISTERED') || str_contains((string)$response, 'INVALID_ARGUMENT')) {
                        if ($this->fcmService !== null) {
                            try {
                                $db = \Core\Database::getInstance();
                                $db->query("DELETE FROM user_devices WHERE fcm_token = ?", [$token]);
                                $this->logger->info('fcm.dead_token_purged_batch', ['token' => substr($token, 0, 10)]);
                            } catch (\Throwable $err) { /* intentional: non-blocking operation */ }
                        }
                    }
                }
                curl_multi_remove_handle($mh, $ch);
                curl_close($ch);
            }
            curl_multi_close($mh);
        }

        $duration = microtime(true) - $startTime;
        $this->metrics->timing('fcm.batch_dispatch.latency', $duration);
        $this->logger->info('fcm.batch_sent_parallel', ['sent' => $sent, 'failed' => $failed, 'time' => $duration]);

        return ['sent' => $sent, 'failed' => $failed];
    }

    /**
     * ذخیره FCM token برای یک کاربر در کش و پایگاه داده فیزیکی
     */
    public function saveUserToken(int $userId, string $token, string $platform = 'web'): bool
    {
        if ($this->fcmService === null) {
            $this->logger->warning('fcm.token_service_not_injected');
            return false;
        }
        return $this->fcmService->saveUserToken($userId, $token, $platform);
    }

    /**
     * دریافت FCM token کاربر (ابتدا از کش و سپس دیتابیس به عنوان پشتیبان)
     */
    public function getUserToken(int $userId, string $platform = 'web'): ?string
    {
        if ($this->fcmService === null) {
            $this->logger->warning('fcm.token_service_not_injected');
            return null;
        }
        return $this->fcmService->getUserToken($userId, $platform);
    }

    /**
     * حذف FCM token (logout / token invalid) از تمام لایه‌ها
     */
    public function removeUserToken(int $userId, string $platform = 'web'): void
    {
        if ($this->fcmService === null) {
            $this->logger->warning('fcm.token_service_not_injected');
            return;
        }
        $this->fcmService->removeUserToken($userId, $platform);
    }

    /**
     * ارسال push به یک کاربر (با lookup token از cache/db)
     */
    public function sendToUser(
        int    $userId,
        string $title,
        string $body,
        array  $data      = [],
        ?string $imageUrl = null,
        ?string $clickUrl = null
    ): bool {
        $token = $this->getUserToken($userId);
        if (!$token) {
            return false; // کاربر token نداشت — ok، نه error
        }

        return $this->sendToToken($token, $title, $body, $data, $imageUrl, $clickUrl);
    }

    /**
     * بررسی آماده بودن FCM
     */
    public function isConfigured(): bool
    {
        return !empty($this->projectId)
            && !empty($this->serviceAccountPath)
            && file_exists($this->serviceAccountPath);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Internal — Authentication (OAuth2 با Service Account)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * دریافت access token از Google (با cache)
     */
    private function getAccessToken(): ?string
    {
        // بررسی cache
        $cached = $this->orchestrator->cache()->get(self::TOKEN_CACHE_KEY);
        if ($cached) {
            return $cached;
        }

        try {
            $serviceAccount = json_decode(file_get_contents($this->serviceAccountPath), true);

            $now     = time();
            $expiry  = $now + 3600;
            $scope   = 'https://www.googleapis.com/auth/firebase.messaging';

            $header  = $this->base64UrlEncode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
            $payload = $this->base64UrlEncode(json_encode([
                'iss'   => $serviceAccount['client_email'],
                'scope' => $scope,
                'aud'   => 'https://oauth2.googleapis.com/token',
                'iat'   => $now,
                'exp'   => $expiry,
            ]));

            $signingInput = "{$header}.{$payload}";
            openssl_sign($signingInput, $signature, $serviceAccount['private_key'], 'SHA256');
            $jwt = "{$signingInput}." . $this->base64UrlEncode($signature);

            // Section 8.3/8.4 — exchange JWT → access token (under CircuitBreaker + retry)
            // OAuth با Google نیز یک external call است و باید با همان الگوی FCM dispatch
            // محافظت شود تا یک خرابی OAuth، کل سیستم نوتیفیکیشن را قفل نکند.
            try {
                $response = $this->callWithBreaker('fcm_oauth', function () use ($jwt): string {
                    return $this->retryTransient(function () use ($jwt): string {
                        $ch = curl_init('https://oauth2.googleapis.com/token');
                        curl_setopt_array($ch, [
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => http_build_query([
                                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                                'assertion'  => $jwt,
                            ]),
                            CURLOPT_TIMEOUT        => 10,
                            CURLOPT_CONNECTTIMEOUT => 5,
                        ]);
                        $body  = curl_exec($ch);
                        $code  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                        $errno = (int) curl_errno($ch);
                        curl_close($ch);

                        if ($code === 200 && is_string($body) && $body !== '') {
                            return $body;
                        }
                        throw $this->classifyHttpFailure($code, $errno, (string)$body, ['provider' => 'fcm_oauth']);
                    });
                });
            } catch (\Core\Exceptions\PermanentFailure $e) {
                // اطلاعات اعتباری اشتباه/ساعت سیستم اشتباه → 4xx — retry بی‌فایده است.
                $this->logger->error('fcm.token_exchange_permanent', ['error' => $e->getMessage()]);
                return null;
            } catch (\Throwable $e) {
                // CB-open، یا خطای transient که retry نتوانست برطرف کند.
                $this->logger->error('fcm.token_exchange_failed', [
                    'class' => get_class($e),
                    'error' => $e->getMessage(),
                ]);
                return null;
            }

            $data  = json_decode($response, true);
            $token = $data['access_token'] ?? null;

            if ($token) {
                $this->orchestrator->cache()->put(self::TOKEN_CACHE_KEY, $token, self::TOKEN_TTL);
            }

            return $token;

        } catch (\Throwable $e) {
            $this->logger->error('fcm.auth_failed', ['error' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * ساخت payload پیام FCM
     */
    private function buildPayload(
        string  $title,
        string  $body,
        array   $data,
        ?string $imageUrl,
        ?string $clickUrl
    ): array {
        $isSilent = ($title === '' && $body === '');

        $notification = null;
        if (!$isSilent) {
            $notification = [
                'title' => $title,
                'body'  => $body,
            ];
            if ($imageUrl) {
                $notification['image'] = $imageUrl;
            }
        }

        $webpush = [];
        if ($clickUrl && !$isSilent) {
            $webpush = [
                'fcm_options' => ['link' => $clickUrl],
            ];
        }

        // data باید string-string باشد
        $stringData = array_map('strval', $data);

        $message = [
            'data'    => $stringData,
            'webpush' => $webpush ?: null,
        ];

        if ($notification !== null) {
            $message['notification'] = $notification;
            $message['android'] = [
                'notification' => [
                    'sound'       => 'default',
                    'click_action'=> 'FLUTTER_NOTIFICATION_CLICK',
                ],
            ];
            $message['apns'] = [
                'payload' => [
                    'aps' => ['sound' => 'default'],
                ],
            ];
        } else {
            // ساختار پوش سایلنت (Silent Push / Background Data Sync)
            $message['android'] = [
                'priority' => 'high',
            ];
            $message['apns'] = [
                'payload' => [
                    'aps' => [
                        'content-available' => 1,
                    ],
                ],
            ];
        }

        return ['message' => $message];
    }

    /**
     * ارسال واقعی به FCM API
     */
    /**
     * Section 8.3/8.4 — wraps HTTP call in Core\CircuitBreaker via the trait
     * and classifies failures into the standard hierarchy.
     */
    private function dispatch(array $payload): bool
    {
        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return false;
        }

        $url  = sprintf(self::FCM_ENDPOINT, $this->projectId);
        $json = json_encode(array_filter($payload['message'] ?? $payload, fn($v) => $v !== null), JSON_UNESCAPED_UNICODE);
        $body = json_encode(['message' => json_decode($json, true)], JSON_UNESCAPED_UNICODE);

        try {
            return (bool) $this->callWithBreaker('fcm', function () use ($url, $body): bool {
                return $this->retryTransient(function () use ($url, $body): bool {
                    $ch = curl_init($url);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $body,
                        CURLOPT_HTTPHEADER     => [
                            'Authorization: Bearer ' . $this->getAccessToken(),
                            'Content-Type: application/json',
                        ],
                        CURLOPT_TIMEOUT        => 10,
                        CURLOPT_CONNECTTIMEOUT => 5,
                    ]);
                    $response = curl_exec($ch);
                    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $errno    = (int) curl_errno($ch);
                    $error    = curl_error($ch);
                    curl_close($ch);

                    if ($httpCode === 200) {
                        return true;
                    }
                    if ($httpCode === 401) {
                        // token expired → invalidate cache so the next attempt re-issues
                        $this->orchestrator->cache()->forget(self::TOKEN_CACHE_KEY);
                    }
                    if ($httpCode === 404 || $httpCode === 400 || str_contains((string)$response, 'UNREGISTERED') || str_contains((string)$response, 'INVALID_ARGUMENT')) {
                        // اصلاح راهبردی معماری پاکسازی توکن‌های غیرفعال موبایل (FCM Auto-Purge Guard):
                        // حذف خودکار توکن‌های مسدود یا حذف‌شده از سوی کاربران موبایل جهت جلوگیری از اسپم سرورهای گوگل و هدررفت منابع شبکه
                        $deadToken = json_decode($body, true)['message']['token'] ?? null;
                        if ($deadToken && $this->fcmService !== null) {
                            try {
                                $db = \Core\Database::getInstance();
                                $db->query("DELETE FROM user_devices WHERE fcm_token = ?", [$deadToken]);
                                $this->logger->info('fcm.dead_token_purged', ['token' => substr($deadToken, 0, 10)]);
                            } catch (\Throwable $err) { /* intentional: non-blocking operation */ }
                        }
                    }
                    $this->logger->warning('fcm.send_failed', [
                        'http'  => $httpCode,
                        'errno' => $errno,
                        'error' => $error ?: (is_string($response) ? mb_substr($response, 0, 200) : ''),
                    ]);
                    throw $this->classifyHttpFailure($httpCode, $errno, (string)$response, ['provider' => 'fcm']);
                });
            }, function (\Core\Exceptions\CircuitBreakerOpenException $e) use ($payload) {
                // Fallback: circuit open → outbox-first (publisher بعداً retry میکنه)
                $this->logger->warning('fcm.circuit_open_fallback_to_outbox');
                
                try {
                    if ($this->outbox === null) {
                        throw new \RuntimeException('Outbox service not injected');
                    }
                    $this->outbox->record('notification', 0, 'notification.fcm.circuit_retry', [
                        'job' => 'App\\Jobs\\SendFcmJob',
                        'notification' => ['payload' => $payload],
                    ]);
                    return true;
                } catch (\Throwable $outboxErr) {
                    // Last resort: queue مستقیم
                    try {
                        if ($this->queue === null) {
                            throw new \RuntimeException('Queue service not injected');
                        }
                        $this->queue->push('App\\Jobs\\SendFcmJob', [
                            'payload' => $payload
                        ], 'notifications', 60);
                        return true;
                    } catch (\Throwable $qe) {
                        $this->logger->error('fcm.all_fallbacks_failed', ['error' => $qe->getMessage()]);
                        return false;
                    }
                }
            });
        } catch (\Core\Exceptions\PermanentFailure $e) {
            // Permanent 4xx — log + return false (do NOT propagate up to caller as exception)
            $this->logger->warning('fcm.permanent_failure', ['error' => $e->getMessage()]);
            return false;
        } catch (\Throwable $e) {
            // Transient/Provider/RateLimited or CB-open → log + return false (matches old behavior)
            $this->logger->warning('fcm.transient_failure', [
                'class' => get_class($e),
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * رمزگذاری Base64 URL-safe بدون padding (الزامی برای JWT)
     */
    private function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    // -------------------------------------------------------------------------
    // Legacy home-grown circuit breaker — kept as no-ops for binary compatibility.
    // The real CB is Core\CircuitBreaker invoked via ExternalCallTrait::callWithBreaker('fcm').
    // -------------------------------------------------------------------------
    private function isFcmCircuitOpen(): bool { return false; }
    private function recordFcmSuccess(): void {}
    private function recordFcmFailure(): void {}
}
