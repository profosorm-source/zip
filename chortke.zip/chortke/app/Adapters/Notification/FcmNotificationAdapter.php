<?php

namespace App\Adapters\Notification;

use Core\Logger;
use Core\Cache;
use Core\Database;
use Core\CircuitBreaker;
use App\Contracts\MetricsCollectorInterface;
use App\Traits\ExternalCallTrait;
use App\Traits\ValidatesExternalUrl;

/**
 * FcmNotificationAdapter — ارسال Push Notification با Firebase Cloud Messaging (FCM)
 *
 * ─── تنظیمات .env مورد نیاز ────────────────────────────────────────────────
 *  FCM_SERVICE_ACCOUNT_JSON=/path/to/storage/firebase-service-account.json
 *  FCM_PROJECT_ID=your-firebase-project-id
 *
 * ─── نحوه استفاده ──────────────────────────────────────────────────────────
 *  $fcm->sendToToken($fcmToken, 'عنوان', 'متن', ['key' => 'val']);
 *  $fcm->sendToTokens([$token1, $token2], 'عنوان', 'متن');
 */

class FcmNotificationAdapter
{
    use \App\Traits\ValidatesExternalUrl;
    use ExternalCallTrait;

    private \App\Services\Notification\NotificationOrchestrator $orchestrator;
    private \App\Contracts\LoggerInterface $logger;
    private MetricsCollectorInterface $metrics;
    /** @internal used by ExternalCallTrait */
    protected CircuitBreaker $circuit;
    private Database $db;
    private ?string   $projectId;
    private ?string   $serviceAccountPath;
    private string $endpointTemplate;
    private string $oauthUrl;

    private const FCM_ENDPOINT     = 'https://fcm.googleapis.com/v1/projects/%s/messages:send';
    private const OAUTH_ENDPOINT   = 'https://oauth2.googleapis.com/token';
    private const TOKEN_CACHE_KEY  = 'fcm:access_token';
    private const TOKEN_TTL        = 55;   // دقیقه (access token هر ساعت expire می‌شود)

    // ── FIX-P3-ADP-090/101: schema/bounds policy برای payload (قبل از dispatch) ──
    private const MAX_TITLE_LENGTH       = 200;   // کاراکتر (mb)
    private const MAX_BODY_LENGTH        = 1000;  // کاراکتر (mb)
    private const MAX_URL_LENGTH         = 2048;
    private const MAX_DATA_KEYS          = 100;
    private const MAX_DATA_KEY_LENGTH    = 64;    // کاراکتر
    private const MAX_DATA_VALUE_LENGTH  = 4096;  // بایت
    private const MAX_DATA_TOTAL_BYTES   = 4096;  // بودجهٔ کل data در FCM (4KB)
    /** کلیدهای رزروشدهٔ FCM/GCM در data — case-insensitive */
    private const RESERVED_DATA_KEY_PREFIXES = ['google.', 'gcm.'];
    private const RESERVED_DATA_KEYS         = ['from', 'notification', 'message_type', 'message_id', 'collapse_key', 'send_error'];
    private const FCM_BATCH_CHUNK_SIZE   = 50;


    public function __construct(
        MetricsCollectorInterface $metrics,
        \App\Services\Notification\NotificationOrchestrator $orchestrator,
        Database $db
    ) {
        $this->orchestrator       = $orchestrator;
        $this->logger             = $this->orchestrator->logger();
        $this->circuit            = $this->orchestrator->circuitBreaker();
        $this->db                 = $db;
        
        $this->metrics            = $metrics;
        $projectId = config('services.fcm.project_id');
        $serviceAccount = config('services.fcm.service_account_json');
        $this->projectId = is_string($projectId) ? $projectId : null;
        $this->serviceAccountPath = is_string($serviceAccount) ? $serviceAccount : null;
        $endpoint = config('services.fcm.endpoint', self::FCM_ENDPOINT);
        $oauthUrl = config('services.fcm.oauth_url', self::OAUTH_ENDPOINT);
        $this->endpointTemplate = is_string($endpoint) && $endpoint !== '' ? $endpoint : self::FCM_ENDPOINT;
        $this->oauthUrl = is_string($oauthUrl) && $oauthUrl !== '' ? $oauthUrl : self::OAUTH_ENDPOINT;
    }

    /**
     * ارسال به یک token
     */
    /** @param array<string, mixed> $data */
    public function sendToToken(
        string $fcmToken,
        string $title,
        string $body,
        array  $data      = [],
        ?string $imageUrl = null,
        ?string $clickUrl = null
    ): bool {
        if (!$this->isConfigured()) {
            $this->logger->warning('fcm.not_configured');
            return false;
        }

        // FIX-P3-ADP-090: گیتِ فرمت توکن در مرزِ ارسال — همان bounds ثبت‌نام
        // (FcmService::saveUserToken: 20..4096، بدون کاراکتر کنترلی).
        if (!$this->isValidFcmToken($fcmToken)) {
            $this->logger->warning('fcm.invalid_token_format', ['token' => substr($fcmToken, 0, 8) . '...']);
            $this->metrics->increment('fcm.send.failure');
            return false;
        }

        $payload = $this->buildPayload($title, $body, $data, $imageUrl, $clickUrl);
        $message = is_array($payload['message'] ?? null) ? $payload['message'] : [];
        $message['token'] = $fcmToken;
        $payload['message'] = $message;

        $startTime = microtime(true);
        try {
            $success = $this->dispatch($payload);
            $duration = microtime(true) - $startTime;
            $this->metrics->timing('fcm.dispatch.latency', $duration);

            $this->metrics->increment($success ? 'fcm.send.success' : 'fcm.send.failure');
            return $success;
        } catch (\Core\Exceptions\CircuitBreakerOpenException $e) {
            // FIX-P3-ADP-104: گیت واقعی مدار — dispatch داخل callWithBreaker('fcm') اجرا
            // می‌شود؛ باز بودن مدار دیگر به no-op قدیمی تکیه ندارد. شکستِ صادقانه، نه موفقیتِ فیک.
            $duration = microtime(true) - $startTime;
            $this->metrics->timing('fcm.dispatch.latency', $duration);
            $this->metrics->increment('fcm.circuit.open_skipped');
            $this->logger->warning('fcm.circuit_open_skipped', ['token' => substr($fcmToken, 0, 8) . '...']);
            return false;
        } catch (\Throwable $e) {
            // FIX-P3-ADP-103: قرارداد failure واحد برای single/batch — log + متریک + false،
            // هیچ استثنایی به caller نشت نمی‌کند (قبلاً rethrow می‌شد و قرارداد single با batch فرق داشت).
            $duration = microtime(true) - $startTime;
            $this->metrics->timing('fcm.dispatch.latency', $duration);
            $this->metrics->increment('fcm.send.error');
            $this->logger->error('fcm.send_to_token_failed', [
                'class' => get_class($e),
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * ارسال به چند token (batch) - بازطراحی شده با curl_multi جهت حذف گلوگاه I/O مسدودکننده
     */
    /**
     * @param list<string> $fcmTokens
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function sendToTokens(
        array  $fcmTokens,
        string $title,
        string $body,
        array  $data      = [],
        ?string $imageUrl = null,
        ?string $clickUrl = null
    ): array {
        // FIX-P3-ADP-092: شمارش مقابل ورودیِ اصلی — dedupe/توکنِ نامعتبر یعنی failed، نه گم‌شده.
        $originalCount = count($fcmTokens);
        if (!$this->isConfigured() || $originalCount === 0) {
            return ['sent' => 0, 'failed' => $originalCount];
        }

        // FIX-P3-ADP-092: type-safe بودن توکن‌ها — فقط stringِ معتبر ارسال می‌شود.
        $validTokens = [];
        foreach ($fcmTokens as $token) {
            if (!is_string($token) || !$this->isValidFcmToken($token)) {
                continue;
            }
            if (!in_array($token, $validTokens, true)) {
                $validTokens[] = $token;
            }
        }
        if ($validTokens === []) {
            $this->logger->warning('fcm.batch_all_tokens_invalid', ['count' => $originalCount]);
            $this->metrics->increment('fcm.send.failure', ['count' => $originalCount]);
            return ['sent' => 0, 'failed' => $originalCount];
        }

        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return ['sent' => 0, 'failed' => $originalCount];
        }

        $url    = sprintf($this->endpointTemplate, rawurlencode((string)$this->projectId));
        if (!$this->isExternalUrlSafe($url)) {
            $this->logger->critical('fcm.unsafe_endpoint_blocked', ['host' => parse_url($url, PHP_URL_HOST)]);
            return ['sent' => 0, 'failed' => $originalCount];
        }

        // FIX-P3-ADP-090/101: payload با schema/bounds یکسان برای کل batch
        $basePayload = $this->buildPayload($title, $body, $data, $imageUrl, $clickUrl);

        $startTime = microtime(true);

        // FIX-P3-ADP-091/104: کل batch پشتِ مدارِ واقعی (callWithBreaker('fcm_batch')) —
        // باز بودن مدار کل batch را skip می‌کند و شکستِ تجمعیِ ۱۰۰٪، breaker را ترک می‌کند.
        try {
            $result = $this->callWithBreaker('fcm_batch', function () use ($validTokens, $url, $accessToken, $basePayload): array {
                return $this->executeBatch($validTokens, $url, $accessToken, $basePayload);
            });
            $sent   = (int)($result['sent'] ?? 0);
            $failed = (int)($result['failed'] ?? 0);
        } catch (\Core\Exceptions\CircuitBreakerOpenException $e) {
            $this->logger->warning('fcm.circuit_open_skipped_batch');
            $this->metrics->increment('fcm.circuit.open_skipped', ['count' => $originalCount]);
            $sent = 0;
            $failed = $originalCount;
        } catch (\Throwable $e) {
            $this->logger->error('fcm.batch_failed', [
                'class' => get_class($e),
                'error' => $e->getMessage(),
            ]);
            $this->metrics->increment('fcm.batch.total_failure');
            $sent = 0;
            $failed = $originalCount;
        }

        // FIX-P3-ADP-092: گزارش در برابر ورودی اصلی — هر توکنِ تکراری/نامعتبر/شکست‌خورده failed است.
        $sent   = max(0, min($sent, $originalCount));
        $failed = max($originalCount - $sent, 0);

        $duration = microtime(true) - $startTime;
        $this->metrics->timing('fcm.batch_dispatch.latency', $duration);
        $this->logger->info('fcm.batch_sent_parallel', ['sent' => $sent, 'failed' => $failed, 'time' => $duration]);

        return ['sent' => $sent, 'failed' => $failed];
    }

    /**
     * FIX-P3-ADP-091/094: اجرای chunked curl_multi پشتِ breaker 'fcm_batch'.
     *
     * retry per-handle با curl_multi عملی نیست (یافتهٔ ADP-091)؛ به‌جای آن:
     *   - کل batch پشت breaker واقعی است (CB-open → skip کامل)؛
     *   - خطای سطح multi-exec (mrc !== CURLM_OK) و curl_errno هر handle
     *     به‌عنوان «شکست انتقال» شمرده می‌شود (بدون خواندن نتیجهٔ احتمالاً خالی)؛
     *   - شکست تجمعی ۱۰۰٪ (هیچ پیامی نرفت) ProviderUnavailable پرتاب می‌کند تا
     *     breaker شکست را ثبت کند (trip) — موفقیتِ فیک وجود ندارد.
     *
     * @param list<string> $tokens
     * @param array<string, mixed> $basePayload
     * @return array{sent: int, failed: int}
     * @throws \Core\Exceptions\ProviderUnavailable در شکست تجمعی ۱۰۰٪
     */
    private function executeBatch(array $tokens, string $url, string $accessToken, array $basePayload): array
    {
        $sent = 0;
        $failed = 0;
        $attempted = 0;

        foreach (array_chunk($tokens, self::FCM_BATCH_CHUNK_SIZE) as $batch) {
            $mh = curl_multi_init();
            $handles = [];

            // 🛡️ FIX-R36-W2-E2 (F-A19d-02): کل بدنهٔ multi در try/finally — هر
            // خروجِ زودهنگام همهٔ handleها را remove/close و $mh را می‌بندد.
            try {
            foreach ($batch as $token) {
                $payload = $basePayload;
                $message = is_array($payload['message'] ?? null) ? $payload['message'] : [];
                $message['token'] = $token;
                $payload['message'] = $message;

                // FIX-P3-ADP-099: شکست json_encode = شکست واقعی این توکن، نه ارسال {"message":[]}
                $bodyJson = $this->encodeFcmMessage($message);
                if ($bodyJson === null) {
                    $failed++;
                    $this->metrics->increment('fcm.send.failure');
                    continue;
                }

                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $bodyJson,
                    CURLOPT_HTTPHEADER     => [
                        'Authorization: Bearer ' . $accessToken,
                        'Content-Type: application/json',
                    ],
                    CURLOPT_TIMEOUT        => 10,
                    CURLOPT_CONNECTTIMEOUT => 5,
                    // FIX-P3-ADP-098: TLS verification صریح (libcurl پیش‌فرض on است — قفلش می‌کنیم)
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2,
                    CURLOPT_FOLLOWLOCATION => false,
                ]);

                curl_multi_add_handle($mh, $ch);
                // کلید یکتا: handle جدا برای هر توکن (حتی پس از dedupe) — بدون overwrite.
                $handles[] = ['ch' => $ch, 'token' => $token];
            }

            $attempted += count($handles);

            $active = null;
            do {
                $mrc = curl_multi_exec($mh, $active);
            } while ($mrc === CURLM_CALL_MULTI_PERFORM);

            while ($active && $mrc === CURLM_OK) {
                if (curl_multi_select($mh) === -1) {
                    usleep(100);
                }
                do {
                    $mrc = curl_multi_exec($mh, $active);
                } while ($mrc === CURLM_CALL_MULTI_PERFORM);
            }

            // FIX-P3-ADP-094: خطای سطح multi-exec — نتیجه‌ها نامعتبرند؛ همهٔ handleهای
            // این chunk شکستِ انتقال شمرده می‌شوند (بدون purge، بدون خواندن body).
            if ($mrc !== CURLM_OK) {
                $this->logger->error('fcm.batch.multi_exec_failed', [
                    'mrc'     => $mrc,
                    'handles' => count($handles),
                ]);
                $failed += count($handles);
                $this->metrics->increment('fcm.send.failure', ['count' => count($handles)]);
                continue;
            }

            foreach ($handles as $item) {
                $ch = $item['ch'];
                $token = (string) $item['token'];

                // FIX-P3-ADP-094: curl_errno per-handle — خطای انتقال یعنی نتیجهٔ HTTP معتبر نیست
                $errno = (int) curl_errno($ch);
                $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $response = curl_multi_getcontent($ch);

                if ($errno !== 0) {
                    $failed++;
                    $this->metrics->increment('fcm.send.transport_error');
                    continue;
                }

                if ($httpCode === 200) {
                    $sent++;
                    $this->metrics->increment('fcm.send.success');
                    continue;
                }

                $failed++;
                $this->metrics->increment('fcm.send.failure');

                if ($httpCode === 401) {
                    try {
                        $this->orchestrator->cache()->forget(self::TOKEN_CACHE_KEY);
                    } catch (\Throwable) {
                        // FIX-P3-ADP-096: outage cache هرگز پردازشِ handleهای بعدی را نمی‌شکند
                    }
                }

                // 🛡️ FIX-R36-W2-E2 (F-A19d-02): purge per-token فقط روی پاسخِ
                // token-invalid (بدنهٔ semantics‌دار — FIX-P3-ADP-093 گیتِ 404 را
                // هم مشروط به semantics بدنه کرد).
                if ($this->isFcmTokenInvalidResponse($httpCode, (string) $response)) {
                    try {
                        $this->db->query("DELETE FROM user_devices WHERE fcm_token = ?", [$token]);
                        $this->logger->info('fcm.dead_token_purged_batch', ['token' => substr($token, 0, 10)]);
                    } catch (\Throwable) { /* intentional: non-blocking operation */ }
                }
            }
            } finally {
                foreach ((array)$handles as $item) {
                    curl_multi_remove_handle($mh, $item['ch']);
                    curl_close($item['ch']);
                }
                curl_multi_close($mh);
            }
        }

        // FIX-P3-ADP-091: شکستِ تجمعی ۱۰۰٪ — breaker باید بفهمد provider پایین است.
        if ($attempted > 0 && $sent === 0 && $failed >= $attempted) {
            throw new \Core\Exceptions\ProviderUnavailable(
                'FCM batch dispatch: all ' . $attempted . ' message(s) failed',
                503
            );
        }

        return ['sent' => $sent, 'failed' => $failed];
    }

    /**
     * بررسی آماده بودن FCM
     */
    public function isConfigured(): bool
    {
        // FIX-P3-ADP-095: فقط فایلِ واقعیِ خواندنی «آماده» محسوب می‌شود — دایرکتوری یا
        // مسیر غیرقابل‌خواندن دیگر به‌عنوان configured جعل نمی‌شود.
        return !empty($this->projectId)
            && !empty($this->serviceAccountPath)
            && is_file($this->serviceAccountPath)
            && is_readable($this->serviceAccountPath);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Internal — Authentication (OAuth2 با Service Account)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * دریافت access token از Google (با cache)
     */
    private function getAccessToken(): ?string
    {
        // بررسی cache — FIX-P3-ADP-096: خواندن cache نباید خارج از try باشد؛ outage
        // cache باید مثل cache-miss رفتار کند، نه شکستِ کل dispatch نوتیفیکیشن.
        try {
            $cached = $this->orchestrator->cache()->get(self::TOKEN_CACHE_KEY);
        } catch (\Throwable $e) {
            $this->logger->warning('fcm.token_cache_read_failed', ['error' => $e->getMessage()]);
            $cached = null;
        }
        if (is_string($cached) && $cached !== '') {
            return $cached;
        }

        try {
            if (!$this->isConfigured()) {
                $this->logger->warning('fcm.auth_not_configured');
                return null;
            }
            $rawCredentials = file_get_contents((string)$this->serviceAccountPath);
            $serviceAccount = is_string($rawCredentials) ? json_decode($rawCredentials, true) : null;
            if (!is_array($serviceAccount) || !is_string($serviceAccount['client_email'] ?? null) || !is_string($serviceAccount['private_key'] ?? null) || $serviceAccount['client_email'] === '' || $serviceAccount['private_key'] === '') {
                $this->logger->error('fcm.service_account_invalid');
                return null;
            }

            // FIX-P3-ADP-097: اعتبارسنجیِ credential — فرمت PEM و سازگاریِ پروژه.
            $pemBeginMarker = '-----BEGIN PRIVATE KEY-----';
            $pemEndMarker   = '-----END PRIVATE KEY-----';
            $privateKey = (string)$serviceAccount['private_key'];
            if (!str_contains($privateKey, $pemBeginMarker) || !str_contains($privateKey, $pemEndMarker)) {
                $this->logger->error('fcm.service_account_invalid_key_format');
                return null;
            }
            $clientEmail = (string)$serviceAccount['client_email'];
            if ($this->projectId !== null && $this->projectId !== ''
                && preg_match('/@([A-Za-z0-9-]+)\./', $clientEmail, $emailProjectMatch) === 1
                && $emailProjectMatch[1] !== $this->projectId) {
                $this->logger->error('fcm.credential_project_mismatch', [
                    'credential_project' => $emailProjectMatch[1],
                ]);
                return null;
            }

            $now     = time();
            $expiry  = $now + 3600;
            $scope   = 'https://www.googleapis.com/auth/firebase.messaging';

            $headerJson = json_encode(['alg' => 'RS256', 'typ' => 'JWT']);
            $payloadJson = json_encode([
                'iss'   => $serviceAccount['client_email'],
                'scope' => $scope,
                'aud'   => 'https://oauth2.googleapis.com/token',
                'iat'   => $now,
                'exp'   => $expiry,
            ]);
            if (!is_string($headerJson) || !is_string($payloadJson)) {
                return null;
            }
            $header  = $this->base64UrlEncode($headerJson);
            $payload = $this->base64UrlEncode($payloadJson);

            $signingInput = "{$header}.{$payload}";
            $signature = '';
            if (!openssl_sign($signingInput, $signature, $serviceAccount['private_key'], 'SHA256') || !is_string($signature) || $signature === '') {
                $this->logger->error('fcm.jwt_signing_failed');
                return null;
            }
            $jwt = "{$signingInput}." . $this->base64UrlEncode($signature);

            // Section 8.3/8.4 — exchange JWT → access token (under CircuitBreaker + retry)
            // OAuth با Google نیز یک external call است و باید با همان الگوی FCM dispatch
            // محافظت شود تا یک خرابی OAuth، کل سیستم نوتیفیکیشن را قفل نکند.
            try {
                $response = $this->callWithBreaker('fcm_oauth', function () use ($jwt): string {
                    return $this->retryTransient(function () use ($jwt): string {
                        if (!$this->isExternalUrlSafe($this->oauthUrl)) {
                            throw new \Core\Exceptions\PermanentFailure('Unsafe FCM OAuth endpoint blocked');
                        }
                        $ch = curl_init($this->oauthUrl);
                        curl_setopt_array($ch, [
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_POST           => true,
                            CURLOPT_POSTFIELDS     => http_build_query([
                                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                                'assertion'  => $jwt,
                            ]),
                            CURLOPT_TIMEOUT        => 10,
                            CURLOPT_CONNECTTIMEOUT => 5,
                            // FIX-P3-ADP-098: TLS verification صریح — به پیش‌فرضِ ضمنی libcurl تکیه نمی‌کنیم
                            CURLOPT_SSL_VERIFYPEER => true,
                            CURLOPT_SSL_VERIFYHOST => 2,
                            CURLOPT_FOLLOWLOCATION => false,
                        ]);
                        $body  = curl_exec($ch);
                        $code  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                        $errno = (int) curl_errno($ch);
                        curl_close($ch);

                        if ($code === 200 && is_string($body) && $body !== '') {
                            return $body;
                        }
                        throw $this->classifyHttpFailure($code, $errno, (string)$body, ['provider' => 'fcm_oauth']);
                    });
                });
            } catch (\Core\Exceptions\PermanentFailure $e) {
                // اطلاعات اعتباری اشتباه/ساعت سیستم اشتباه → 4xx — retry بی‌فایده است.
                $this->logger->error('fcm.token_exchange_permanent', ['error' => $e->getMessage()]);
                return null;
            } catch (\Throwable $e) {
                // CB-open، یا خطای transient که retry نتوانست برطرف کند.
                $this->logger->error('fcm.token_exchange_failed', [
                    'class' => get_class($e),
                    'error' => $e->getMessage(),
                ]);
                return null;
            }

            $data  = is_string($response) ? json_decode($response, true) : null;
            $token = is_array($data) && is_string($data['access_token'] ?? null) ? $data['access_token'] : null;

            if ($token !== null && $token !== '') {
                // FIX-P3-ADP-098: validation شکلِ پاسخ OAuth — access_token تنها کافی نیست؛
                // expires_in و token_type باید هم presence و سازگاری داشته باشند.
                $expiresIn = $data['expires_in'] ?? null;
                $tokenType = is_string($data['token_type'] ?? null) ? strtolower($data['token_type']) : '';
                if (!is_numeric($expiresIn) || (int)$expiresIn < 1 || !str_contains($tokenType, 'bearer')) {
                    $this->logger->warning('fcm.oauth_response_shape_invalid', [
                        'token_type' => $tokenType !== '' ? $tokenType : null,
                        'has_expires_in' => $expiresIn !== null,
                    ]);
                    return null;
                }
                $this->orchestrator->cache()->put(self::TOKEN_CACHE_KEY, $token, self::TOKEN_TTL);
                return $token;
            }
            $this->logger->warning('fcm.oauth_response_invalid');
            return null;

        } catch (\Throwable $e) {
            $this->logger->error('fcm.auth_failed', ['error' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * ساخت payload پیام FCM
     */
    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function buildPayload(
        string  $title,
        string  $body,
        array   $data,
        ?string $imageUrl,
        ?string $clickUrl
    ): array {
        // FIX-P3-ADP-090: سقف سختِ طول — عنوان/متن نامحدود به FCM نمی‌رود؛
        // برش با لاگ warning دیده می‌شود (پیامِ کاربر کامل حذف نمی‌شود).
        if (mb_strlen($title) > self::MAX_TITLE_LENGTH) {
            $this->logger->warning('fcm.payload.title_truncated', ['length' => mb_strlen($title)]);
            $title = mb_substr($title, 0, self::MAX_TITLE_LENGTH);
        }
        if (mb_strlen($body) > self::MAX_BODY_LENGTH) {
            $this->logger->warning('fcm.payload.body_truncated', ['length' => mb_strlen($body)]);
            $body = mb_substr($body, 0, self::MAX_BODY_LENGTH);
        }

        $isSilent = ($title === '' && $body === '');

        // FIX-P3-ADP-090: URL‌ها raw وارد payload نمی‌شوند — فقط https معتبر؛
        // URL نامعتبر حذف (fail-closed) و با لاگ دیده می‌شود.
        $safeImageUrl = $this->sanitizeHttpsUrl($imageUrl, 'image');
        $safeClickUrl = $this->sanitizeHttpsUrl($clickUrl, 'click');

        $notification = null;
        if (!$isSilent) {
            $notification = [
                'title' => $title,
                'body'  => $body,
            ];
            if ($safeImageUrl !== null) {
                $notification['image'] = $safeImageUrl;
            }
        }

        $webpush = [];
        if ($safeClickUrl !== null && !$isSilent) {
            $webpush = [
                'fcm_options' => ['link' => $safeClickUrl],
            ];
        }

        // FIX-P3-ADP-090/101: data باید string-string باشد + سیاستِ کلید/مقدار:
        // کلیدهای رزروشدهٔ FCM ممنوع، سقف تعداد/طول کلید، سقف طول مقدار و سقف حجمِ کل.
        $stringData = [];
        $droppedKeys = 0;
        $totalBytes = 0;
        foreach ($data as $key => $value) {
            if (!is_string($key) || !is_scalar($value)) {
                $droppedKeys++;
                continue;
            }
            if ($this->isReservedFcmDataKey($key)
                || mb_strlen($key) > self::MAX_DATA_KEY_LENGTH
                || strlen($key . (string)$value) > self::MAX_DATA_VALUE_LENGTH) {
                $droppedKeys++;
                continue;
            }
            if (count($stringData) >= self::MAX_DATA_KEYS) {
                $droppedKeys++;
                continue;
            }
            $entryBytes = strlen($key) + strlen((string)$value) + 4; // + quotes/colon JSON overhead
            if ($totalBytes + $entryBytes > self::MAX_DATA_TOTAL_BYTES) {
                $droppedKeys++;
                continue;
            }
            $stringData[$key] = (string)$value;
            $totalBytes += $entryBytes;
        }
        if ($droppedKeys > 0) {
            $this->logger->warning('fcm.payload.data_keys_dropped', ['count' => $droppedKeys]);
        }

        $message = [
            'data'    => $stringData,
            'webpush' => $webpush ?: null,
        ];

        if ($notification !== null) {
            $message['notification'] = $notification;
            $message['android'] = [
                'notification' => [
                    'sound'       => 'default',
                    'click_action'=> 'FLUTTER_NOTIFICATION_CLICK',
                ],
            ];
            $message['apns'] = [
                'payload' => [
                    'aps' => ['sound' => 'default'],
                ],
            ];
        } else {
            // ساختار پوش سایلنت (Silent Push / Background Data Sync)
            $message['android'] = [
                'priority' => 'high',
            ];
            $message['apns'] = [
                'payload' => [
                    'aps' => [
                        'content-available' => 1,
                    ],
                ],
            ];
        }

        return ['message' => $message];
    }

    /**
     * FIX-P3-ADP-090: گیتِ کلیدهای رزروشدهٔ FCM/GCM در data (case-insensitive).
     */
    private function isReservedFcmDataKey(string $key): bool
    {
        $lower = strtolower($key);
        foreach (self::RESERVED_DATA_KEY_PREFIXES as $prefix) {
            if (str_starts_with($lower, $prefix)) {
                return true;
            }
        }
        return in_array($lower, self::RESERVED_DATA_KEYS, true);
    }

    /**
     * FIX-P3-ADP-090: فقط URL https ساختارمند به payload راه دارد (الزام FCM برای
     * notification.image و webpush.fcm_options.link)؛ نامعتبر → null (حذف از payload).
     */
    private function sanitizeHttpsUrl(?string $url, string $field): ?string
    {
        if ($url === null || trim($url) === '') {
            return null;
        }
        $url = trim($url);
        $invalid = strlen($url) > self::MAX_URL_LENGTH
            || preg_match('/[\x00-\x1F\x7F]/', $url) === 1;
        if (!$invalid) {
            $parts = parse_url($url);
            $invalid = !is_array($parts)
                || !isset($parts['host'])
                || strtolower((string)($parts['scheme'] ?? '')) !== 'https'
                || filter_var('https://' . $parts['host'], FILTER_VALIDATE_URL) === false;
        }
        if ($invalid) {
            $this->logger->warning('fcm.payload.url_dropped', ['field' => $field]);
            return null;
        }
        return $url;
    }

    /**
     * FIX-P3-ADP-090/092: گیتِ فرمت توکن FCM در مرزِ ارسال — همان bounds ثبت‌نام
     * (FcmService::saveUserToken): 20..4096 بایت، بدون کاراکتر کنترلی.
     */
    private function isValidFcmToken(string $token): bool
    {
        $length = strlen($token);
        if ($length < 20 || $length > 4096) {
            return false;
        }
        return preg_match('/[\x00-\x1F\x7F]/', $token) !== 1;
    }

    /**
     * FIX-P3-ADP-099: انکودِ JSON مرزِ سخت است — شکستِ encode یعنی null (شکستِ ارسال
     * برای فراخوان)؛ دیگر هرگز {"message":[]} بی‌صدا به FCM ارسال نمی‌شود.
     *
     * @param array<string, mixed> $message
     */
    private function encodeFcmMessage(array $message): ?string
    {
        try {
            $body = json_encode(
                ['message' => array_filter($message, static fn($v) => $v !== null)],
                JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
            );
            return is_string($body) && $body !== '' ? $body : null;
        } catch (\JsonException $e) {
            $this->logger->error('fcm.json_encode_failed', ['error' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * ارسال واقعی به FCM API
     */
    /**
     * Section 8.3/8.4 — wraps HTTP call in Core\CircuitBreaker via the trait
     * and classifies failures into the standard hierarchy.
     */
    /** @param array<string, mixed> $payload */
    private function dispatch(array $payload): bool
    {
        $accessToken = $this->getAccessToken();
        if (!$accessToken) {
            return false;
        }

        $url  = sprintf($this->endpointTemplate, rawurlencode((string)$this->projectId));
        if (!$this->isExternalUrlSafe($url)) {
            $this->logger->critical('fcm.unsafe_endpoint_blocked', ['host' => parse_url($url, PHP_URL_HOST)]);
            return false;
        }
        $message = is_array($payload['message'] ?? null) ? $payload['message'] : $payload;
        $body = $this->encodeFcmMessage($message);
        if ($body === null) {
            // FIX-P3-ADP-099: encode failure = hard send failure (caller false می‌بیند)
            return false;
        }

        try {
            return (bool) $this->callWithBreaker('fcm', function () use ($url, $body, $accessToken): bool {
                return $this->retryTransient(function () use ($url, $body, $accessToken): bool {
                    $ch = curl_init($url);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST           => true,
                        CURLOPT_POSTFIELDS     => $body,
                        CURLOPT_HTTPHEADER     => [
                            'Authorization: Bearer ' . $accessToken,
                            'Content-Type: application/json',
                        ],
                        CURLOPT_TIMEOUT        => 10,
                        CURLOPT_CONNECTTIMEOUT => 5,
                        // FIX-P3-ADP-098: TLS verification صریح
                        CURLOPT_SSL_VERIFYPEER => true,
                        CURLOPT_SSL_VERIFYHOST => 2,
                        CURLOPT_FOLLOWLOCATION => false,
                    ]);
                    $response = curl_exec($ch);
                    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $errno    = (int) curl_errno($ch);
                    $error    = curl_error($ch);
                    curl_close($ch);

                    if ($httpCode === 200) {
                        return true;
                    }
                    if ($httpCode === 401) {
                        // token expired → invalidate cache so the next attempt re-issues
                        $this->orchestrator->cache()->forget(self::TOKEN_CACHE_KEY);
                    }
                    if ($httpCode === 404 || $httpCode === 400 || str_contains((string)$response, 'UNREGISTERED') || str_contains((string)$response, 'INVALID_ARGUMENT')) {
                        // 🛡️ FIX-R36-W2-E2 (F-A19d-02): گیتِ token-invalid — purge فقط وقتی
                        // بدنهٔ پاسخِ گوگل semanticsِ توکن‌مرده دارد (UNREGISTERED /
                        // REGISTRATION_TOKEN_NOT_REGISTERED / INVALID_REGISTRATION /
                        // NOT_FOUND). 400ِ payload-محور دیگر توکنِ سالم را DELETE نمی‌کند.
                        if (!$this->isFcmTokenInvalidResponse($httpCode, (string)$response)) {
                            $this->logger->warning('fcm.token_purge_skipped_non_token_error', [
                                'http' => $httpCode,
                                'body' => mb_substr((string)$response, 0, 200),
                            ]);
                        } else {
                        // اصلاح راهبردی معماری پاکسازی توکن‌های غیرفعال موبایل (FCM Auto-Purge Guard):
                        // حذف خودکار توکن‌های مسدود یا حذف‌شده از سوی کاربران موبایل جهت جلوگیری از اسپم سرورهای گوگل و هدررفت منابع شبکه
                        $decodedBody = is_string($body) ? json_decode($body, true) : null;
                        $deadTokenRaw = null;
                        if (is_array($decodedBody)) {
                            $messagePayload = $decodedBody['message'] ?? null;
                            if (is_array($messagePayload)) {
                                $deadTokenRaw = $messagePayload['token'] ?? null;
                            }
                        }
                        $deadToken = is_string($deadTokenRaw) ? $deadTokenRaw : null;
                        if ($deadToken) {
                            try {
                                $this->db->query("DELETE FROM user_devices WHERE fcm_token = ?", [$deadToken]);
                                $this->logger->info('fcm.dead_token_purged', ['token' => substr($deadToken, 0, 10)]);
                            } catch (\Throwable) { /* intentional: non-blocking operation */ }
                        }
                        }
                    }
                    $this->logger->warning('fcm.send_failed', [
                        'http'  => $httpCode,
                        'errno' => $errno,
                        'error' => $error ?: (is_string($response) ? mb_substr($response, 0, 200) : ''),
                    ]);
                    throw $this->classifyHttpFailure($httpCode, $errno, (string)$response, ['provider' => 'fcm']);
                });
            });
            // 🛡️ FIX-PHANTOM-JOB-FALLBACK (P0 — pre-existing):
            // قبلاً این‌جا یک fallback برای CircuitBreakerOpenException وجود داشت که:
            // ۱) رویداد outbox با کلاس جاب «App\Jobs\SendFcmJob» ثبت می‌کرد — کلاسی که
            //    در کل پروژه وجود خارجی ندارد → worker با «Queue job not found» شکست می‌خورد؛
            // ۲) و true برمی‌گرداند → dispatch() موفقیت «جعلی» گزارش می‌کرد و پیام عملاً
            //    گم می‌شد. اکنون استثنای circuit-open مثل بقیهٔ خطاهای گذرا به catch بیرونی
            //    می‌رسد و false صادقانه برگردانده می‌شود (قرارداد یکسان با خطای transient).
        } catch (\Core\Exceptions\CircuitBreakerOpenException $e) {
            // FIX-P3-ADP-104: باز بودن مدارِ واقعی به caller (sendToToken) منتقل می‌شود تا
            // متریک fcm.circuit.open_skipped ثبت و false صادقانه برگردد — دیگر no-op نیست.
            throw $e;
        } catch (\Core\Exceptions\PermanentFailure $e) {
            // Permanent 4xx — log + return false (do NOT propagate up to caller as exception)
            $this->logger->warning('fcm.permanent_failure', ['error' => $e->getMessage()]);
            return false;
        } catch (\Throwable $e) {
            // Transient/Provider/RateLimited → log + return false (matches old behavior)
            $this->logger->warning('fcm.transient_failure', [
                'class' => get_class($e),
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * 🛡️ FIX-R36-W2-E2 (F-A19d-02): تشخیص «پاسخِ توکن‌مرده» برای گیتِ پاکسازی.
     *
     * قرارداد: purge فقط وقتی مجاز است که پاسخِ FCM صراحتاً semanticsِ
     * توکن-نامعتبر داشته باشد؛ 400/INVALID_ARGUMENTِ payload-محور (data بزرگ،
     * notification نامعتبر، عنوان خالی) هرگز purge نمی‌کند.
     * FIX-P3-ADP-093: 404ِ بی‌بدنه هم دیگر purge نمی‌کند — 404 می‌تواند سطح
     * project/endpoint باشد (project id غلط) و purgeِ آن یعنی wipeِ سالمِ همهٔ
     * توکن‌ها؛ purge فقط با semantics توکن‌مرده در بدنه انجام می‌شود.
     * نیمهٔ قدیمیِ HTTP API (UNREGISTERED / INVALID_REGISTRATION) و v1
     * (error.details[].errorCode + error.status=NOT_FOUND + پیام «Requested entity
     * was not found») پوشش داده می‌شوند. تطبیق case-insensitive است.
     */
    private function isFcmTokenInvalidResponse(int $httpCode, string $responseBody): bool
    {
        if ($httpCode < 400) {
            return false; // موفق / redirect — ربطی به purge ندارد
        }
        if (trim($responseBody) === '') {
            // FIX-P3-ADP-093: بدون بدنه، purge ممنوع (404 ممکن است project/endpoint-level باشد)
            return false;
        }

        // ۱) کدهای قراردادیِ token-invalid — legacy HTTP API و v1 message:
        $needles = [
            'UNREGISTERED',
            'REGISTRATION_TOKEN_NOT_REGISTERED',
            'INVALID_REGISTRATION',
            'SENDER_ID_MISMATCH',
            'Requested entity was not found',
        ];
        foreach ($needles as $needle) {
            if (stripos($responseBody, $needle) !== false) {
                return true;
            }
        }

        // ۲) بدنهٔ JSON ساختاریافتهٔ v1 — error.status / error.details[].errorCode:
        $decoded = json_decode($responseBody, true);
        if (is_array($decoded)) {
            $error = is_array($decoded['error'] ?? null) ? $decoded['error'] : [];
            if (($error['status'] ?? null) === 'NOT_FOUND') {
                return true;
            }
            foreach ((array)($error['details'] ?? []) as $detail) {
                $errorCode = is_array($detail) ? ($detail['errorCode'] ?? null) : null;
                if (is_string($errorCode) && in_array($errorCode, [
                    'UNREGISTERED',
                    'REGISTRATION_TOKEN_NOT_REGISTERED',
                    'INVALID_REGISTRATION',
                    'SENDER_ID_MISMATCH',
                ], true)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * رمزگذاری Base64 URL-safe بدون padding (الزامی برای JWT)
     */
    private function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    // FIX-P3-ADP-104: no-opهای گمراه‌کنندهٔ legacy circuit breaker حذف شدند.
    // مدارِ واقعی Core\CircuitBreaker است: مسیر single درون callWithBreaker('fcm')
    // و مسیر batch درون callWithBreaker('fcm_batch') — CircuitBreakerOpenException
    // در هر دو مسیر صادقانه به failed ترجمه می‌شود، نه موفقیتِ فیک.
}
