<?php

namespace App\Adapters\Notification;

use Core\Logger;
use Core\CircuitBreaker;
use Core\ValueObjects\Money;
use App\Models\User;
use App\Traits\ExternalCallTrait;
use App\Traits\ValidatesExternalUrl;

/**
 * SmsNotificationAdapter — ارسال پیامک برای نوتیفیکیشن‌های فوری
 *
 * ─── وضعیت فعلی ────────────────────────────────────────────────────────────
 *  آماده‌سازی برای اتصال به پنل پیامکی — پنل هنوز انتخاب نشده.
 *  برای فعال‌سازی، متد sendViaSmsProvider() را با SDK پنل موردنظر پر کنید.
 *
 * ─── تنظیمات .env مورد نیاز (بعد از اتصال) ──────────────────────────────
 *  SMS_PROVIDER=kavenegar        # kavenegar | melipayamak | idehpayam
 *  SMS_API_KEY=your-api-key
 *  SMS_FROM=1000...              # شماره فرستنده
 *  SMS_ENABLED=false
 *
 * ─── Section 8.3/8.4 ─────────────────────────────────────────────────────
 *  متدهای provider-specific (sendKavenegar/sendMelipayamak/sendIdehpayam)
 *  در صورت خطای انتقال یا HTTP، یک Failure استاندارد throw می‌کنند تا
 *  CircuitBreaker و retryTransient (در send()) بتوانند به‌درستی رفتار کنند:
 *
 *    - HTTP 408/429/5xx یا curl errno (timeout/DNS/reset) → Transient/Provider/RateLimited
 *      (retry با backoff نمایی، در صورت تکرار خطا CB ترک می‌خورد)
 *    - HTTP 4xx یا خطای منطقی provider (api_error) → PermanentFailure
 *      (بدون retry، شکست بازگردانده می‌شود)
 */
class SmsNotificationAdapter
{
    use ExternalCallTrait;
    use ValidatesExternalUrl;

    /** FIX-P3-ADP-125: ارزهای مجاز پیامک برداشت — الفبای واحد ارز پروژه (lowercase) */
    private const WITHDRAWAL_CURRENCIES = ['irt', 'usdt'];

    private \App\Services\Notification\NotificationOrchestrator $orchestrator;
    private User   $userModel;
    private \App\Contracts\LoggerInterface $logger;
    /**
     * @internal exposed for ExternalCallTrait::resolveCircuitBreaker()
     */
    protected CircuitBreaker $circuit;
    private bool   $enabled;
    private string $provider;
    private string $apiKey;
    private string $from;

    public function __construct(
        User $userModel,
        Logger $logger,
        CircuitBreaker $circuit,
        \App\Services\Notification\NotificationOrchestrator $orchestrator
    ) {
        $this->orchestrator = $orchestrator;
        $this->logger       = $this->orchestrator->logger();
        unset($logger, $circuit);
        $this->circuit      = $this->orchestrator->circuitBreaker();
        
        $this->userModel = $userModel;
        // FIX-P3-ADP-122: (bool) cast روی config خطرناک است — (bool)'false' === true.
        // پارسِ سخت‌گیرانه با allowlist توکن‌های boolean (الگوی BannerAdapter::parseBoolean).
        $this->enabled = $this->parseBooleanSetting(config('services.sms.enabled', false), 'services.sms.enabled', false);
        $provider = config('services.sms.provider', '');
        $apiKey = config('services.sms.api_key', '');
        $from = config('services.sms.from', '');
        $this->provider = is_string($provider) ? $provider : '';
        $this->apiKey = is_string($apiKey) ? $apiKey : '';
        $this->from = is_string($from) ? $from : '';
    }

    public function sendToUser(int $userId, string $message): bool
    {
        try {
            $user = $this->userModel->find((int)$userId);
            if (!$user || empty($user->mobile)) {
                $this->logger->warning('sms.user_missing_mobile', ['user_id' => $userId]);
                return false;
            }

            return $this->send((string)$user->mobile, $message);
        } catch (\Throwable $e) {
            $this->logger->error('sms.send_to_user_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * ارسال پیامک
     *
     * FIX-P3-ADP-124: rate-limit/dedupe مسئولیت لایهٔ orchestration/job است (هر
     * فراخوان اینجا یک ارسال provider است)؛ این آداپتر فقط retry را bound می‌کند
     * (retryTransient با ۳ تلاش + backoff) و هر فراخوان را پشت CircuitBreaker می‌گذارد.
     *
     * @param  string $mobile  شماره موبایل (مثلاً 09121234567)
     * @param  string $message متن پیامک
     * @return bool
     */
    public function send(string $mobile, string $message): bool
    {
        // FIX-P3-ADP-131: اول validation، بعد هرگونه log/mask — maskMobile روی ورودی
        // کوتاه دیگر خروجی عجیب نمی‌سازد (کلاً mask می‌شود).
        if (!$this->isValidMobile($mobile)) {
            $this->logger->warning('sms.invalid_mobile', ['mobile' => $this->maskMobile($mobile)]);
            return false;
        }

        // FIX-P3-ADP-123: gate واقعیِ readiness (enabled + provider + apiKey) —
        // کلید غایب دیگر تا لایهٔ provider نمی‌رود تا آنجا PermanentFailure بخورد.
        if (!$this->isEnabled()) {
            $this->logger->info('sms.disabled', ['mobile' => $this->maskMobile($mobile)]);
            return false;
        }

        try {
            $providerName = 'sms_' . ($this->provider !== '' ? $this->provider : 'unknown');
            $result = (bool) $this->callWithBreaker($providerName, function () use ($mobile, $message): bool {
                // retry روی خطاهای transient (timeout, 5xx, 429)
                return $this->retryTransient(function () use ($mobile, $message): bool {
                    return $this->sendViaSmsProvider($mobile, $message);
                }, 3, 300, 3000);
            });
            // 🛡️ FIX-PHANTOM-JOB-FALLBACK (P0 — pre-existing):
            // قبلاً fallback برای circuit-open رویداد outbox/جاب صف با کلاس «App\Jobs\SendSmsJob»
            // ثبت می‌کرد — کلاسی که در پروژه وجود ندارد → worker با «Queue job not found» شکست
            // می‌خورد؛ و fallback مقدار true برمی‌گرداند → send() موفقیت «جعلی» گزارش می‌کرد و
            // پیامک عملاً گم می‌شد. اکنون استثنا به catch بیرونی می‌رسد و false صادقانه
            // برمی‌گردد (هم‌قرارداد با خطای transient/پرmanent).

            $this->logger->info('sms.sent', [
                'mobile'   => $this->maskMobile($mobile),
                'provider' => $this->provider,
                'success'  => $result,
            ]);

            return $result;

        } catch (\Core\Exceptions\PermanentFailure $e) {
            $this->logger->warning('sms.permanent_failure', [
                'mobile' => $this->maskMobile($mobile),
                'error'  => $e->getMessage(),
            ]);
            return false;
        } catch (\Throwable $e) {
            $this->logger->error('sms.send_failed', [
                'mobile' => $this->maskMobile($mobile),
                'class'  => get_class($e),
                'error'  => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * پیامک هشدار امنیتی (OTP / login alert)
     */
    public function sendSecurityAlert(string $mobile, string $message): bool
    {
        return $this->send($mobile, "هشدار امنیتی چرتکه:\n{$message}");
    }

    public function sendSecurityAlertToUser(int $userId, string $message): bool
    {
        try {
            $user = $this->userModel->find((int)$userId);
            if (!$user || empty($user->mobile)) return false;
            return $this->sendSecurityAlert((string)$user->mobile, $message);
        } catch (\Throwable $e) {
            // FIX-P3-ADP-126: catchِ بی‌صدا ممنوع — هم‌راستا با sendToUser لاگ می‌شود
            $this->logger->error('sms.send_security_alert_to_user_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * پیامک تأیید برداشت
     */
    public function sendWithdrawalAlert(string $mobile, string|int $amount, string $currency): bool
    {
        // FIX-P3-ADP-125: ورودیِ خام به متن پیامک interpolate نمی‌شود —
        // مبلغ با Money::fromString canonical می‌شود و ارز allowlist دارد (irt/usdt).
        $canonicalCurrency = strtolower(trim($currency));
        if (!in_array($canonicalCurrency, self::WITHDRAWAL_CURRENCIES, true)) {
            $this->logger->warning('sms.withdrawal.currency_rejected', ['currency' => $canonicalCurrency]);
            return false;
        }
        try {
            $amountText = Money::fromString((string)$amount, $canonicalCurrency)->getAmount();
        } catch (\Throwable $e) {
            $this->logger->warning('sms.withdrawal.amount_rejected', ['error' => $e->getMessage()]);
            return false;
        }
        $msg = "برداشت {$amountText} {$canonicalCurrency} از حساب چرتکه شما پردازش شد.";
        return $this->send($mobile, $msg);
    }

    public function sendWithdrawalAlertToUser(int $userId, string|int $amount, string $currency): bool
    {
        try {
            $user = $this->userModel->find((int)$userId);
            if (!$user || empty($user->mobile)) return false;
            return $this->sendWithdrawalAlert((string)$user->mobile, $amount, $currency);
        } catch (\Throwable $e) {
            // FIX-P3-ADP-126: catchِ بی‌صدا ممنوع — هم‌راستا با sendToUser لاگ می‌شود
            $this->logger->error('sms.send_withdrawal_alert_to_user_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * بررسی فعال بودن سرویس
     */
    public function isEnabled(): bool
    {
        return $this->enabled && !empty($this->apiKey) && !empty($this->provider);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Internal — اتصال به پنل (پر کردن این متد بعد از انتخاب پنل)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @throws \Core\Exceptions\TransientException|\Core\Exceptions\PermanentFailure|\Core\Exceptions\ProviderUnavailable|\Core\Exceptions\RateLimitedFailure
     */
    private function sendViaSmsProvider(string $mobile, string $message): bool
    {
        return match ($this->provider) {
            'kavenegar'   => $this->sendKavenegar($mobile, $message),
            'melipayamak' => $this->sendMelipayamak($mobile, $message),
            'idehpayam'   => $this->sendIdehpayam($mobile, $message),
            default       => throw new \Core\Exceptions\PermanentFailure(
                "SMS provider not configured: '{$this->provider}'"
            ),
        };
    }

    /**
     * @throws \Throwable Failure standardized
     */
    private function sendKavenegar(string $mobile, string $message): bool
    {
        if (empty($this->apiKey)) {
            $this->logger->error('sms.kavenegar.missing_apikey');
            throw new \Core\Exceptions\PermanentFailure('Kavenegar API key missing');
        }

        $baseUrl = config('services.sms.kavenegar_base_url', 'https://api.kavenegar.com');
        $baseUrl = rtrim(is_string($baseUrl) ? $baseUrl : 'https://api.kavenegar.com', '/');
        $url = "{$baseUrl}/v1/{$this->apiKey}/sms/send.json";
        $this->assertExternalUrlSafe($url, 'sms provider');
        $sender = !empty($this->from) ? $this->from : '10008663';

        $params = [
            'receptor' => $mobile,
            'sender'   => $sender,
            'message'  => $message
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($params),
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            // FIX-P3-ADP-127: TLS verification صریح در هر سه provider
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
        ]);

        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno    = (int) curl_errno($ch);
        curl_close($ch);

        if ($httpCode === 200 && is_string($response) && $response !== '') {
            $decoded = json_decode($response, true);
            $data = is_array($decoded) ? $decoded : [];
            $returnData = is_array($data['return'] ?? null) ? $data['return'] : [];
            $status = is_numeric($returnData['status'] ?? null) ? (int)$returnData['status'] : 0;
            if ($status === 200) {
                return true;
            }
            // FIX-P3-ADP-129: لاگ فقط status/message سایز-سقف‌خورده — نه کل body خام provider
            $this->logger->error('sms.kavenegar.api_error', [
                'status' => $status,
                'msg'    => mb_substr((string)($returnData['message'] ?? ''), 0, 200),
            ]);
            // Kavenegar status code-های نوع 4xx/5xx مستندند:
            // 401-414 → permanent (auth, validation, balance), 5xx → transient
            if ($status >= 500) {
                throw new \Core\Exceptions\ProviderUnavailable("Kavenegar transient error status={$status}");
            }
            throw new \Core\Exceptions\PermanentFailure("Kavenegar api_error status={$status}");
        }

        $this->logger->error('sms.kavenegar.http_error', ['http_code' => $httpCode, 'errno' => $errno]);
        throw $this->classifyHttpFailure($httpCode, $errno, (string)$response, ['provider' => 'kavenegar']);
    }

    /**
     * @throws \Throwable Failure standardized
     */
    private function sendMelipayamak(string $mobile, string $message): bool
    {
        if (empty($this->apiKey)) {
            $this->logger->error('sms.melipayamak.missing_apikey');
            throw new \Core\Exceptions\PermanentFailure('Melipayamak API key missing');
        }

        $baseUrl = config('services.sms.melipayamak_base_url', 'https://rest.payamak-panel.com');
        $baseUrl = rtrim(is_string($baseUrl) ? $baseUrl : 'https://rest.payamak-panel.com', '/');
        $url = $baseUrl . '/api/SendSMS/SendSMS';
        $this->assertExternalUrlSafe($url, 'sms provider');
        $username = config('services.sms.username', '');

        $params = [
            'username' => $username,
            'password' => $this->apiKey,
            'to'       => $mobile,
            'from'     => $this->from,
            'text'     => $message,
            'isFlash'  => false
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($params),
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            // FIX-P3-ADP-127: TLS verification صریح در هر سه provider
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
        ]);

        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno    = (int) curl_errno($ch);
        curl_close($ch);

        if ($httpCode === 200 && is_string($response) && $response !== '') {
            $decoded = json_decode($response, true);
            $data = is_array($decoded) ? $decoded : [];
            if (is_numeric($data['RetStatus'] ?? null) && (int)$data['RetStatus'] === 1) {
                return true;
            }
            // FIX-P3-ADP-129: لاگ فقط status/message سایز-سقف‌خورده — نه کل body خام provider
            $this->logger->error('sms.melipayamak.api_error', [
                'RetStatus' => is_numeric($data['RetStatus'] ?? null) ? (int)$data['RetStatus'] : null,
                'message'   => mb_substr((string)($data['StrRetStatus'] ?? $data['Message'] ?? ''), 0, 200),
            ]);
            // Melipayamak RetStatus != 1 → معمولاً خطای منطقی permanent
            throw new \Core\Exceptions\PermanentFailure('Melipayamak api_error RetStatus=' . ($data['RetStatus'] ?? 'null'));
        }

        $this->logger->error('sms.melipayamak.http_error', ['http_code' => $httpCode, 'errno' => $errno]);
        throw $this->classifyHttpFailure($httpCode, $errno, (string)$response, ['provider' => 'melipayamak']);
    }

    /**
     * @throws \Throwable Failure standardized
     */
    private function sendIdehpayam(string $mobile, string $message): bool
    {
        if (empty($this->apiKey)) {
            $this->logger->error('sms.idehpayam.missing_apikey');
            throw new \Core\Exceptions\PermanentFailure('Idehpayam API key missing');
        }

        $baseUrl = config('services.sms.idehpayam_base_url', 'https://panel.idehpayam.com');
        $baseUrl = rtrim(is_string($baseUrl) ? $baseUrl : 'https://panel.idehpayam.com', '/');
        $url = $baseUrl . '/api/v1/sms/send/simple';
        $this->assertExternalUrlSafe($url, 'sms provider');
        $params = [
            'receptor' => $mobile,
            'sender'   => $this->from,
            'message'  => $message
        ];

        // FIX-P3-ADP-127: json_encode بدون throw ممنوع — شکستِ encode شکستِ صریح است
        try {
            $requestBody = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        } catch (\JsonException $e) {
            $this->logger->error('sms.idehpayam.json_encode_failed', ['error' => $e->getMessage()]);
            throw new \Core\Exceptions\PermanentFailure('Idehpayam payload encoding failed');
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $requestBody,
            CURLOPT_HTTPHEADER     => [
                'ApiKey: ' . $this->apiKey,
                'Content-Type: application/json'
            ],
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            // FIX-P3-ADP-127: TLS verification صریح در هر سه provider
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
        ]);

        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno    = (int) curl_errno($ch);
        curl_close($ch);

        if ($httpCode === 200 && is_string($response) && $response !== '') {
            $data = (array)(json_decode(is_string($response) ? $response : "", true) ?? []);
            if (isset($data['status']) && $data['status'] === 'success') {
                return true;
            }
            // FIX-P3-ADP-129: لاگ فقط status/message سایز-سقف‌خورده — نه کل body خام provider
            $this->logger->error('sms.idehpayam.api_error', [
                'status'  => is_scalar($data['status'] ?? null) ? $data['status'] : null,
                'message' => mb_substr((string)($data['message'] ?? $data['messageId'] ?? ''), 0, 200),
            ]);
            throw new \Core\Exceptions\PermanentFailure('Idehpayam api_error status=' . ($data['status'] ?? 'null'));
        }

        $this->logger->error('sms.idehpayam.http_error', ['http_code' => $httpCode, 'errno' => $errno]);
        throw $this->classifyHttpFailure($httpCode, $errno, (string)$response, ['provider' => 'idehpayam']);
    }

    private function isValidMobile(string $mobile): bool
    {
        return (bool)preg_match('/^09[0-9]{9}$/', $mobile);
    }

    /**
     * FIX-P3-ADP-131: mask طول-امن — ورودی کوتاه‌تر از قالبِ شمارهٔ موبایل
     * کاملاً mask می‌شود (substr روی ورودی کوتاه خروجی گمراه‌کننده می‌ساخت).
     */
    private function maskMobile(string $mobile): string
    {
        if (strlen($mobile) < 8) {
            return '****';
        }
        return substr($mobile, 0, 4) . '****' . substr($mobile, -3);
    }

    /**
     * FIX-P3-ADP-122: پارسِ سخت‌گیرانهٔ boolean در مرزِ config — allowlist توکن‌ها
     * (الگوی BannerAdapter::parseBoolean)؛ مقدارِ بدشکل به default مستند برمی‌گردد
     * با لاگ warning (به‌جای (bool)'false' === true خاموش).
     */
    private function parseBooleanSetting(mixed $value, string $setting, bool $default): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) && ($value === 0 || $value === 1)) {
            return $value === 1;
        }
        if (is_string($value)) {
            $normalized = strtolower(trim($value));
            if ($normalized === 'true' || $normalized === '1' || $normalized === 'yes' || $normalized === 'on') return true;
            if ($normalized === 'false' || $normalized === '0' || $normalized === 'no' || $normalized === 'off' || $normalized === '') return false;
        }
        $this->logger->warning('sms.setting_boolean_malformed', ['setting' => $setting]);
        return $default;
    }
}
