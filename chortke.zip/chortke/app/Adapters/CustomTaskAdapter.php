<?php

namespace App\Adapters;

use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use App\Models\Ads;
use App\Contracts\WalletServiceInterface;
use Core\Database;
use App\Services\Settings\AppSettings;

/**
 * CustomTaskAdapter — نسخه اصلاح شده (بدون مدیریت تراکنش مالی)
 */
class CustomTaskAdapter extends AdapterBase implements AdSystemContract
{
    private Ads $taskModel;
    private WalletServiceInterface $walletService;
    private Database $db;

    public function __construct(
        Ads $taskModel,
        WalletServiceInterface $walletService,
        Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory
    ) {
        $this->taskModel = $taskModel;
        $this->walletService = $walletService;
        $this->db = $db;
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string { return 'custom_task'; }

    public function create(int $userId, array $data): array
    {
        // فقط ایجاد رکورد - تراکنش مالی توسط AdSystemManager مدیریت می‌شود
        $task = $this->taskModel->create([
            'user_id' => $userId,
            'title' => $data['title'],
            'description' => $data['description'],
            'price_per_task' => $data['price_per_task'],
            'currency' => $data['currency'] ?? 'irt',
            'total_budget' => $data['total_budget'] ?? 0,
            'status' => 'pending_review',
            'type' => 'custom_task'
        ]);

        if (!$task) return $this->errorResponse('خطا در ایجاد رکورد دیتابیس');
        return $this->successResponse('تسک ایجاد شد', ['id' => $task->id]);
    }

    public function validate(array $data, bool $isUpdate = false): array
    {
        $errors = [];
        if (empty($data['title'])) $errors[] = 'عنوان الزامی است';
        if (empty($data['description'])) $errors[] = 'توضیح الزامی است';
        return ['valid' => empty($errors), 'errors' => $errors];
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        $feePercent = (string) $this->appSettings->get('custom_task_site_fee_percent', 10);
        return \Core\ValueObjects\Money::of($amount, 'IRT')->percentage($feePercent)->getAmount();
    }

    // سایر متدها برای حفظ سازگاری...
    public function isExpired(int $adId): bool { return false; }
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array { return []; }
    public function track(int $adId, string $eventType, ?int $userId = null): array { return []; }
    public function getStatus(int $adId): ?array { return null; }
}
