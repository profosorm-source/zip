<?php

namespace App\Adapters;

use Core\ValueObjects\Money;
use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use App\Models\Ads;
use App\Contracts\WalletServiceInterface;
use Core\Database;
use App\Services\Settings\AppSettings;

/**
 * CustomTaskAdapter — creates the Ads row only. Financial hold is handled by AdSystemManager.
 */
class CustomTaskAdapter extends AdapterBase implements AdSystemContract
{
    /** FIX-P3-ADP-065: allowlist انواع تسک سفارشی (هم‌خانوادهٔ انواع شناخته‌شدهٔ پلتفرم). */
    private const ALLOWED_TASK_TYPES = ['custom', 'follow', 'like', 'comment', 'share', 'view', 'join', 'subscribe', 'install', 'register', 'download', 'other'];

    /** FIX-P3-ADP-066: allowlist محدودیت دستگاه (پیش‌فرض محصول 'all'). */
    private const ALLOWED_DEVICE_RESTRICTIONS = ['all', 'mobile', 'desktop', 'web'];

    private Ads $taskModel;

    public function __construct(
        Ads $taskModel,
        WalletServiceInterface $walletService,
        Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory
    ) {
        $this->taskModel = $taskModel;
        unset($walletService, $db);
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string { return 'custom_task'; }

    public function create(int $userId, array $data): array
    {
        try {
            // FIX-P3-ADP-064 (قرارداد تک‌گذر): دیتای نرمال‌شده از validate() می‌آید؛
            // گیت خام تعداد داخل validate پیش از clamp اعمال می‌شود.
            $validation = $this->validate($data);
            if (!$validation['valid']) {
                return $this->errorResponse('اطلاعات تسک سفارشی معتبر نیست.', $validation['errors']);
            }
            $normalized = $validation['data'];

            $taskId = $this->taskModel->create([
                'user_id' => $userId,
                'type' => 'custom_task',
                'title' => $normalized['title'],
                'description' => $normalized['description'],
                'link' => $normalized['link'] ?: null,
                'target_url' => $normalized['link'] ?: null,
                'task_type' => $normalized['task_type'],
                'proof_type' => $normalized['proof_type'],
                'proof_description' => $normalized['proof_description'],
                'proof_schema' => json_encode($normalized['proof_schema'], JSON_UNESCAPED_UNICODE),
                'price_per_task' => $normalized['price_per_task'],
                'currency' => $normalized['currency'],
                'total_budget' => $normalized['total_budget'],
                'remaining_budget' => $normalized['total_budget'],
                'total_count' => $normalized['total_count'],
                'remaining_count' => $normalized['total_count'],
                'pending_count' => 0,
                'completed_count' => 0,
                'deadline_hours' => $normalized['deadline_hours'],
                'device_restriction' => $normalized['device_restriction'],
                'site_commission_percent' => $normalized['site_commission_percent'],
                'auto_approve_hours' => $normalized['auto_approve_hours'],
                'reject_rules' => json_encode($normalized['reject_rules'], JSON_UNESCAPED_UNICODE),
                'restrictions' => json_encode([
                    'daily_limit_per_user' => $normalized['daily_limit_per_user'],
                    'device_restriction' => $normalized['device_restriction'],
                    'proof_type' => $normalized['proof_type'],
                ], JSON_UNESCAPED_UNICODE),
                'status' => $normalized['requires_admin_review'] ? 'pending_review' : 'active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            if (!$taskId) {
                return $this->errorResponse('خطا در ایجاد رکورد دیتابیس');
            }
            $id = 0;
            if (is_object($taskId)) {
                $vars = get_object_vars($taskId);
                $id = is_numeric($vars['id'] ?? null) ? (int)$vars['id'] : 0;
            } elseif (is_numeric($taskId)) {
                $id = (int)$taskId;
            }
            // FIX-P3-ADP-068: شناسهٔ نامعتبر (شامل شکل true مدل = insert بدون ID) دیگر
            // «موفقیت با id صفر» نیست — هم‌الگوی AdTubeAdapter (قرارداد ساگا نیاز به int دارد).
            if ($id <= 0) {
                $this->logError('create_id_unavailable', 'task insert succeeded without a retrievable id', ['user_id' => $userId]);
                return $this->errorResponse('خطا در ایجاد رکورد دیتابیس');
            }
            return $this->successResponse('تسک سفارشی ایجاد شد', ['id' => $id, 'ad_id' => $id]);
        } catch (\Throwable $e) {
            $this->logError('create', $e->getMessage(), ['user_id' => $userId]);
            return $this->errorResponse('خطای سیستمی در ایجاد تسک سفارشی رخ داد.');
        }
    }

    /**
     * قرارداد validate (FIX-P3-ADP-024/067): خروجی همیشه ['valid'=>bool,'errors'=>list,'data'=>array].
     * FIX-P3-ADP-064: گیت خام تعداد قبل از clamp — ۰/منفی/اعشاری رد می‌شود نه coerce به ۱.
     * FIX-P3-ADP-065: task_type و link هر دو allowlist/policy دارند.
     * FIX-P3-ADP-067: خرابی Money/normalize = valid=false عمومی، نه استثنای نشت‌کننده.
     */
    public function validate(array $data, bool $isUpdate = false): array
    {
        $errors = [];
        $countInput = $data['total_count'] ?? $data['total_quantity'] ?? $data['quantity'] ?? 1;
        $countRaw = is_string($countInput) ? trim($countInput) : $countInput;
        $countIsInteger = (is_int($countRaw) && $countRaw >= 1)
            || (is_string($countRaw) && $countRaw !== '' && ctype_digit($countRaw) && (int)$countRaw >= 1);
        if (!$countIsInteger) {
            $errors[] = 'تعداد درخواست باید حداقل ۱ باشد.';
        }
        try {
            $data = $this->normalize($data);
        } catch (\InvalidArgumentException $e) {
            $this->logger->warning("adapter.{$this->getType()}.validate_normalize_failed", ['error' => self::sanitizeLogText($e->getMessage())]);
            return ['valid' => false, 'errors' => ['ورودی ارسالی معتبر نیست.'], 'data' => []];
        }
        $errors = array_merge($errors, $this->validateNormalized($data));
        return ['valid' => empty($errors), 'errors' => $errors, 'data' => $data];
    }

    /** @return list<string> */
    private function validateNormalized(array $data): array
    {
        $errors = [];

        if (mb_strlen($data['title']) < 5) $errors[] = 'عنوان تسک باید حداقل ۵ کاراکتر باشد.';
        if (mb_strlen($data['description']) < 20) $errors[] = 'شرح تسک باید حداقل ۲۰ کاراکتر باشد.';
        if (bccomp($data['price_per_task'], '0', 8) <= 0) $errors[] = 'پاداش هر تسک نامعتبر است.';
        if ($data['total_count'] <= 0) $errors[] = 'تعداد درخواست باید حداقل ۱ باشد.';
        if (!in_array($data['currency'], ['irt', 'usdt'], true)) $errors[] = 'ارز انتخاب‌شده معتبر نیست.';
        if (!in_array($data['proof_type'], ['screenshot', 'text', 'video', 'code', 'file', 'url'], true)) $errors[] = 'نوع مدرک معتبر نیست.';
        // FIX-P3-ADP-065: allowlist نوع تسک — ورودی دلخواهِ آزاد ذخیره نمی‌شود.
        if (!in_array($data['task_type'], self::ALLOWED_TASK_TYPES, true)) $errors[] = 'نوع تسک معتبر نیست.';
        // FIX-P3-ADP-065: policy لینک — در صورت ارسال، باید @handle/آیدی ساده یا
        // http(s) با هاست معتبر باشد (الگوی FIX-P3-ADP-001).
        if ($data['link'] !== '' && preg_match('/^@?[a-zA-Z0-9_.]+$/', $data['link']) !== 1 && !self::isSafeHttpUrl($data['link'])) {
            $errors[] = 'لینک هدف معتبر نیست.';
        }
        // FIX-P3-ADP-066: محدودیت دستگاه فقط از مقادیر مجاز (پیش‌فرض محصول 'all').
        if (!in_array($data['device_restriction'], self::ALLOWED_DEVICE_RESTRICTIONS, true)) {
            $errors[] = 'محدودیت دستگاه معتبر نیست.';
        }
        if (mb_strlen($data['proof_description']) < 5) $errors[] = 'دستورالعمل مدرک باید مشخص باشد.';

        $minPriceValue = $data['currency'] === 'usdt'
            ? $this->appSettings->get('custom_task_min_price_usdt', 0.5)
            : $this->appSettings->get('custom_task_min_price_irt', 5000);
        $minPrice = self::wellFormedDecimal($minPriceValue) ?? '0';
        if (bccomp($data['price_per_task'], $minPrice, 8) < 0) {
            $errors[] = 'پاداش هر تسک کمتر از حداقل مجاز است.';
        }

        return $errors;
    }

    /**
     * FIX-P3-ADP-069 — قرارداد context این متد (مستند):
     * فقط فراخوان‌های داخلیِ مورد اعتماد (AdSystemManager::create/quoteCoupon و
     * AdsApiController::previewCost) اجازهٔ ارسال context دارند؛ در حالت
     * عادی amount همان total_budget خود کمپین است. fallback به
     * normalize($context)['total_budget'] برای سازگاری با فراخوان‌های داخلیِ موجود
     * حفظ شده اما ورودی context هم از همان نرمال‌سازی/گاردهای decimal عبور می‌کند.
     * این متد API عمومی برای ورودی کاربر نیست.
     */
    public function calculateCost(string $amount, array $context = []): string
    {
        $baseAmount = self::wellFormedDecimal($amount) ?? '0'; // FIX-P3-ADP-069: فقط decimal خوش‌فرم
        if (bccomp($baseAmount, '0', 8) <= 0) {
            $normalized = $this->normalize($context);
            $baseAmount = (string)$normalized['total_budget'];
        }
        // FIX-P3-ADP-066: کارمزد همیشه clamp‌شدهٔ [0,100].
        $feePercent = $this->boundedFeePercent('custom_task_site_fee_percent', '10');
        $currency = is_string($context['currency'] ?? null) ? $context['currency'] : 'irt';
        // float→decimal: محاسبهٔ کارمزد با Money/BCMath به‌جای float
        return Money::fromString($baseAmount, $currency)->percentage($feePercent)->getAmount();
    }

    /**
     * @param array<string, mixed> $data
     * @return array{
     *   title: string,
     *   description: string,
     *   link: string,
     *   task_type: string,
     *   proof_type: string,
     *   proof_description: string,
     *   proof_schema: array<string, mixed>,
     *   price_per_task: string,
     *   currency: string,
     *   total_count: int,
     *   total_budget: string,
     *   deadline_hours: int,
     *   device_restriction: string,
     *   daily_limit_per_user: int,
     *   site_commission_percent: string,
     *   auto_approve_hours: int,
     *   reject_rules: array<string, mixed>,
     *   requires_admin_review: bool
     * }
     */
    private function normalize(array $data): array
    {
        $toString = static fn(mixed $value): string => is_scalar($value) ? trim((string)$value) : '';
        $toInt = static fn(mixed $value): int => is_numeric($value) ? (int)$value : 0;
        $currency = strtolower($toString($data['currency'] ?? 'irt'));
        if ($currency === 'irr' || $currency === 'rial') {
            // FIX-R36-W3 (F-A19d-10): irr→irt بدون بازمقیاس ×10 — رؤیت‌پذیری با لاگ
            // (تصمیم محصول برای ردّ/مقیاس در رجیستر).
            $this->logger->warning('ads.currency.irr_relabelled_irt', ['ad_type' => $this->getType(), 'received' => $currency]);
            $currency = 'irt';
        }
        // float→decimal: قیمت به‌صورت رشتهٔ decimal
        // FIX-P3-ADP-069: فقط decimal خوش‌فرم (نماد علمی/غیرعددی → '0' → خطای اعتبارسنجی)
        $priceInput = $data['price_per_task'] ?? 0;
        $price = self::wellFormedDecimal($priceInput) ?? '0';
        $count = $toInt($data['total_count'] ?? $data['total_quantity'] ?? $data['quantity'] ?? 1);
        $proofType = strtolower($toString($data['proof_type'] ?? 'text'));
        // FIX-P3-ADP-066: کارمزد همیشه clamp‌شدهٔ [0,100].
        $feePercent = $this->boundedFeePercent('custom_task_site_fee_percent', '10');

        return [
            'title' => $toString($data['title'] ?? ''),
            'description' => $toString($data['description'] ?? ''),
            'link' => $toString($data['link'] ?? $data['target_link'] ?? $data['target_url'] ?? ''),
            'task_type' => strtolower($toString($data['task_type'] ?? 'custom')),
            'proof_type' => $proofType,
            'proof_description' => $toString($data['proof_description'] ?? $data['instructions'] ?? 'مدرک انجام تسک را طبق توضیح تسک ارسال کنید.'),
            'proof_schema' => [
                'type' => $proofType,
                'required' => true,
                'description' => $toString($data['proof_description'] ?? ''),
            ],
            'price_per_task' => $price,
            'currency' => $currency,
            'total_count' => max(1, $count),
            'total_budget' => Money::fromString($price, $currency)->multiply((string)max(1, $count))->getAmount(),
            'deadline_hours' => max(1, min(168, $toInt($data['deadline_hours'] ?? 24))),
            'device_restriction' => $toString($data['device_restriction'] ?? 'all'),
            'daily_limit_per_user' => max(1, $toInt($data['daily_limit_per_user'] ?? 1)),
            'site_commission_percent' => $feePercent,
            // FIX-P3-ADP-066: ساعت تأیید خودکار clamp‌شده در بازهٔ منطقی ۰..۷۲۰ (۳۰ روز) —
            // مقدار منفی/غیرمنطقی از تنظیمات دیگر مستقیم ذخیره نمی‌شود.
            'auto_approve_hours' => max(0, min(720, $toInt($this->appSettings->get('custom_task_auto_approve_hours', 48)))),
            // FIX-P3-ADP-066: reject_rules عمداً [] می‌ماند — محصول فعلاً هیچ ورودی
            // قواعد ردّ از کاربر ندارد (سطح API این فیلد را نمی‌پذیرد)؛ ورودی مستقیم مسدود است.
            'reject_rules' => [],
            // FIX-P3-ADP-066: پارس boolean سخت‌گیرانه — رشتهٔ 'false' دیگر truthy نیست؛
            // مقدار ناشناخته fail-safe (نیاز به بازبینی ادمین) + لاگ هشدار.
            'requires_admin_review' => $this->parseBooleanSetting(
                $this->appSettings->get('custom_task_requires_admin_review', 0),
                'custom_task_requires_admin_review'
            ),
        ];
    }

    /**
     * FIX-P3-ADP-066 — پارس boolean سخت‌گیرانه (هم‌الگوی BannerAdapter::parseBoolean).
     */
    private function parseBoolean(mixed $value, string $field): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) && ($value === 0 || $value === 1)) {
            return $value === 1;
        }
        if (is_string($value)) {
            $normalized = strtolower(trim($value));
            if ($normalized === 'true' || $normalized === '1') return true;
            if ($normalized === 'false' || $normalized === '0') return false;
        }
        throw new \InvalidArgumentException("{$field} must be a boolean.");
    }

    /**
     * FIX-P3-ADP-066 — پارس boolean برای پرچم «تنظیمات» (نه ورودی کاربر):
     * مقدار ناشناخته fail-safe روی true (نیاز به بازبینی ادمین) + هشدار لاگ.
     */
    private function parseBooleanSetting(mixed $value, string $field): bool
    {
        try {
            return $this->parseBoolean($value, $field);
        } catch (\InvalidArgumentException $e) {
            $this->logger->warning("adapter.{$this->getType()}.boolean_setting_invalid", [
                'field' => $field,
                'fail_safe' => 'admin_review_required',
                'error' => self::sanitizeLogText($e->getMessage()),
            ]);
            return true;
        }
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function isExpired(int $adId): bool { return false; }
    /**
     * FIX-C52 (یافتهٔ ممیزی ۵۲): fail-loud — قبلاً آرایهٔ خالی (بدون کلیدهای قرارداد) برمی‌گرداند.
     * @deprecated Dead contract surface (F-A19d-03) — صفر call-site
     */
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        throw new \LogicException(
            'CustomTaskAdapter::processPayment غیرفعال است (F-A19d-03/59): تسویهٔ مالی فقط از مسیر متمرکز escrow/AdsBudgetSettlementService انجام می‌شود.'
        );
    }
    /**
     * FIX-C52 (یافتهٔ ممیزی ۵۲): fail-loud — قبلاً آرایهٔ خالی برمی‌گرداند (نقض شکل قرارداد — R30-12).
     * @deprecated Dead contract surface (F-A19d-03) — صفر call-site
     */
    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        throw new \LogicException(
            'CustomTaskAdapter::track غیرفعال است (F-A19d-03/59): ثبت رویداد فقط از مسیر AdsBudgetSettlementService انجام می‌شود.'
        );
    }
    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function getStatus(int $adId): ?array { return null; }
}
