<?php

namespace App\Adapters;

use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use App\Models\Ads;
use App\Contracts\WalletServiceInterface;
use Core\Database;
use App\Services\Settings\AppSettings;

/**
 * CustomTaskAdapter — creates the Ads row only. Financial hold is handled by AdSystemManager.
 */
class CustomTaskAdapter extends AdapterBase implements AdSystemContract
{
    private Ads $taskModel;
    private WalletServiceInterface $walletService;
    private Database $db;

    public function __construct(
        Ads $taskModel,
        WalletServiceInterface $walletService,
        Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory
    ) {
        $this->taskModel = $taskModel;
        $this->walletService = $walletService;
        $this->db = $db;
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string { return 'custom_task'; }

    public function create(int $userId, array $data): array
    {
        try {
            $normalized = $this->normalize($data);
            $validation = $this->validate($normalized);
            if (!$validation['valid']) {
                return $this->errorResponse('اطلاعات تسک سفارشی معتبر نیست.', $validation['errors']);
            }

            $taskId = $this->taskModel->create([
                'user_id' => $userId,
                'type' => 'custom_task',
                'title' => $normalized['title'],
                'description' => $normalized['description'],
                'link' => $normalized['link'] ?: null,
                'target_url' => $normalized['link'] ?: null,
                'task_type' => $normalized['task_type'],
                'proof_type' => $normalized['proof_type'],
                'proof_description' => $normalized['proof_description'],
                'proof_schema' => json_encode($normalized['proof_schema'], JSON_UNESCAPED_UNICODE),
                'price_per_task' => $normalized['price_per_task'],
                'currency' => $normalized['currency'],
                'total_budget' => $normalized['total_budget'],
                'remaining_budget' => $normalized['total_budget'],
                'total_count' => $normalized['total_count'],
                'remaining_count' => $normalized['total_count'],
                'pending_count' => 0,
                'completed_count' => 0,
                'deadline_hours' => $normalized['deadline_hours'],
                'device_restriction' => $normalized['device_restriction'],
                'site_commission_percent' => $normalized['site_commission_percent'],
                'auto_approve_hours' => $normalized['auto_approve_hours'],
                'reject_rules' => json_encode($normalized['reject_rules'], JSON_UNESCAPED_UNICODE),
                'restrictions' => json_encode([
                    'daily_limit_per_user' => $normalized['daily_limit_per_user'],
                    'device_restriction' => $normalized['device_restriction'],
                    'proof_type' => $normalized['proof_type'],
                ], JSON_UNESCAPED_UNICODE),
                'status' => $normalized['requires_admin_review'] ? 'pending_review' : 'active',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            if (!$taskId) {
                return $this->errorResponse('خطا در ایجاد رکورد دیتابیس');
            }
            $id = is_object($taskId) ? (int)$taskId->id : (int)$taskId;
            return $this->successResponse('تسک سفارشی ایجاد شد', ['id' => $id, 'ad_id' => $id]);
        } catch (\Throwable $e) {
            $this->logError('create', $e->getMessage(), ['user_id' => $userId]);
            return $this->errorResponse('خطای سیستمی در ایجاد تسک سفارشی رخ داد.');
        }
    }

    public function validate(array $data, bool $isUpdate = false): array
    {
        $data = $this->normalize($data);
        $errors = [];

        if (mb_strlen($data['title']) < 5) $errors[] = 'عنوان تسک باید حداقل ۵ کاراکتر باشد.';
        if (mb_strlen($data['description']) < 20) $errors[] = 'شرح تسک باید حداقل ۲۰ کاراکتر باشد.';
        if ($data['price_per_task'] <= 0) $errors[] = 'پاداش هر تسک نامعتبر است.';
        if ($data['total_count'] <= 0) $errors[] = 'تعداد درخواست باید حداقل ۱ باشد.';
        if (!in_array($data['currency'], ['irt', 'usdt'], true)) $errors[] = 'ارز انتخاب‌شده معتبر نیست.';
        if (!in_array($data['proof_type'], ['screenshot', 'text', 'video', 'code', 'file', 'url'], true)) $errors[] = 'نوع مدرک معتبر نیست.';
        if (mb_strlen($data['proof_description']) < 5) $errors[] = 'دستورالعمل مدرک باید مشخص باشد.';

        $minPrice = $data['currency'] === 'usdt'
            ? (float)$this->appSettings->get('custom_task_min_price_usdt', 0.5)
            : (float)$this->appSettings->get('custom_task_min_price_irt', 5000);
        if ($data['price_per_task'] < $minPrice) {
            $errors[] = 'پاداش هر تسک کمتر از حداقل مجاز است.';
        }

        return ['valid' => empty($errors), 'errors' => $errors];
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        $baseAmount = (float)$amount;
        if ($baseAmount <= 0) {
            $normalized = $this->normalize($context);
            $baseAmount = $normalized['total_budget'];
        }
        $feePercent = (float)$this->appSettings->get('custom_task_site_fee_percent', 10);
        return (string)round($baseAmount * ($feePercent / 100), 8);
    }

    private function normalize(array $data): array
    {
        $currency = strtolower((string)($data['currency'] ?? 'irt'));
        if ($currency === 'irr' || $currency === 'rial') $currency = 'irt';
        $price = (float)($data['price_per_task'] ?? 0);
        $count = (int)($data['total_count'] ?? $data['total_quantity'] ?? $data['quantity'] ?? 1);
        $proofType = strtolower((string)($data['proof_type'] ?? 'text'));
        $feePercent = (float)$this->appSettings->get('custom_task_site_fee_percent', 10);

        return [
            'title' => trim((string)($data['title'] ?? '')),
            'description' => trim((string)($data['description'] ?? '')),
            'link' => trim((string)($data['link'] ?? $data['target_link'] ?? $data['target_url'] ?? '')),
            'task_type' => strtolower((string)($data['task_type'] ?? 'custom')),
            'proof_type' => $proofType,
            'proof_description' => trim((string)($data['proof_description'] ?? $data['instructions'] ?? 'مدرک انجام تسک را طبق توضیح تسک ارسال کنید.')),
            'proof_schema' => [
                'type' => $proofType,
                'required' => true,
                'description' => trim((string)($data['proof_description'] ?? '')),
            ],
            'price_per_task' => $price,
            'currency' => $currency,
            'total_count' => max(1, $count),
            'total_budget' => max(0, $price * max(1, $count)),
            'deadline_hours' => max(1, min(168, (int)($data['deadline_hours'] ?? 24))),
            'device_restriction' => (string)($data['device_restriction'] ?? 'all'),
            'daily_limit_per_user' => max(1, (int)($data['daily_limit_per_user'] ?? 1)),
            'site_commission_percent' => $feePercent,
            'auto_approve_hours' => (int)$this->appSettings->get('custom_task_auto_approve_hours', 48),
            'reject_rules' => [],
            'requires_admin_review' => (bool)$this->appSettings->get('custom_task_requires_admin_review', 0),
        ];
    }

    public function isExpired(int $adId): bool { return false; }
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array { return []; }
    public function track(int $adId, string $eventType, ?int $userId = null): array { return []; }
    public function getStatus(int $adId): ?array { return null; }
}
