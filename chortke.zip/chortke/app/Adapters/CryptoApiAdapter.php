<?php

namespace App\Adapters;

use App\Services\Settings\AppSettings;
use App\Contracts\LoggerInterface;
use Core\CircuitBreaker;
use Core\RateLimiter;
use App\Traits\ExternalCallTrait;
use App\Traits\ValidatesExternalUrl;

class CryptoApiAdapter implements CryptoVerificationAdapter
{
    use \App\Traits\ValidatesExternalUrl;
    use ExternalCallTrait;

    private LoggerInterface $logger;
    private AppSettings $appSettings;

    private CircuitBreaker $circuit;
    private ?RateLimiter $rateLimiter;

    public function __construct(
        LoggerInterface $logger,
        AppSettings $appSettings,
        CircuitBreaker $circuit,
        ?RateLimiter $rateLimiter = null
    ) {
        $this->logger = $logger;
        $this->appSettings = $appSettings;
        $this->circuit = $circuit;
        $this->rateLimiter = $rateLimiter;
    }

    /**
     * Verify a crypto transaction using API calls to blockchain explorers
     */
    protected function circuitBreakerForExternalCalls(): ?CircuitBreaker
    {
        return $this->circuit;
    }

    public function verify(string $network, string $txHash, string $fromWallet, string $toWallet, string $expectedAmount): array
    {
        $network = strtoupper(trim($network));
        $txHash = trim($txHash);
        $toWallet = trim($toWallet);
        $expectedAmount = trim($expectedAmount);
        if (!in_array($network, ['TRC20','BNB20','TON','SOL'], true)) {
            return ['status'=>'error','reason'=>'شبکه پشتیبانی نمی‌شود'];
        }
        if (!$this->isValidTxHashForNetwork($network, $txHash)) {
            return ['status'=>'error','reason'=>'هش تراکنش نامعتبر است'];
        }
        // FIX-P3-ADP-052: اعتبارسنجی فرمت آدرس مقصد per-network پیش از هر تماس provider —
        // آدرس ساختگی/بدون چک‌سامِ شبکهٔ اشتباه هرگز به provider نمی‌رسد.
        if (!$this->isValidDestinationAddress($network, $toWallet)) {
            return ['status' => 'error', 'reason' => 'فرمت آدرس مقصد با شبکهٔ انتخاب‌شده هم‌خوانی ندارد'];
        }
        // FIX-P3-ADP-062: مقیاس مبلغ حداکثر ۸ رقم اعشار (USDT=۶؛ ۸ سقف قرارداد پین) —
        // regex قبلی هر تعداد اعشار را می‌پذیرفت.
        if ($toWallet === '' || preg_match('/^(?:0|[1-9]\d*)(?:\.\d{1,8})?$/', $expectedAmount) !== 1 || bccomp($expectedAmount, '0', 8) <= 0) {
            return ['status'=>'error','reason'=>'مقصد یا مبلغ مورد انتظار نامعتبر است'];
        }
        return $this->verifyTransaction($network, $txHash, trim($fromWallet), $toWallet, $expectedAmount);
    }

    /**
     * FIX-P3-ADP-052: گارد فرمت آدرس مقصد به تفکیک شبکه (fail-closed).
     * TRC20: base58check شکل ۳۴ کاراکتری T-prefixed؛ BNB20: 0x+40hex؛
     * TON: user-friendly با tag/CRC معتبر یا wc:hex (via tonAddressToWcHash)؛
     * SOL: base58 با طول ۴۳/۴۴.
     */
    private function isValidDestinationAddress(string $network, string $toWallet): bool
    {
        return match ($network) {
            'TRC20' => preg_match('/^T[1-9A-HJ-NP-Za-km-z]{33}$/', $toWallet) === 1,
            'BNB20' => preg_match('/^0x[0-9a-fA-F]{40}$/', $toWallet) === 1,
            'TON' => $this->tonAddressToWcHash($toWallet) !== null,
            'SOL' => preg_match('/^[1-9A-HJ-NP-Za-km-z]{43,44}$/', $toWallet) === 1,
            default => false,
        };
    }

    private function isValidTxHashForNetwork(string $network, string $txHash): bool
    {
        return match ($network) {
            'BNB20' => preg_match('/^0x[a-f0-9]{64}$/i', $txHash) === 1,
            'TRC20' => preg_match('/^[a-f0-9]{64}$/i', $txHash) === 1,
            'SOL' => preg_match('/^[1-9A-HJ-NP-Za-km-z]{88}$/', $txHash) === 1,
            'TON' => preg_match('/^[a-f0-9]{64}$/i', $txHash) === 1
                || preg_match('/^[A-Za-z0-9\/+]{43}=$/', $txHash) === 1,
            default => false,
        };
    }

    private function providerUrl(string $key, string $default): string
    {
        $value = config('services.crypto.' . $key, $default);
        return is_string($value) && $value !== '' ? $value : $default;
    }

    /**
     * Verify transaction based on network
     */
    /** @return array<string, mixed> */
    private function verifyTransaction(string $network, string $txHash, string $fromWallet, string $toWallet, string $expectedAmount): array
    {
        switch ($network) {
            case 'TRC20':
                $result = $this->verifyTronTransaction($txHash, $fromWallet, $toWallet, $expectedAmount);
                break;
            case 'BNB20':
                $result = $this->verifyBscTransaction($txHash, $fromWallet, $toWallet, $expectedAmount);
                break;
            case 'TON':
                $result = $this->verifyTonTransaction($txHash, $fromWallet, $toWallet, $expectedAmount);
                break;
            case 'SOL':
                $result = $this->verifySolanaTransaction($txHash, $fromWallet, $toWallet, $expectedAmount);
                break;
            default:
                $result = ['status' => 'error', 'reason' => 'شبکه پشتیبانی نمی‌شود'];
        }

        return $result;
    }

    /**
     * Section 8.3/8.4 — single source of truth for circuit-breaker + retry +
     * failure classification via App\Traits\ExternalCallTrait.
     * Supports multiple URLs for Provider Chain / Fallback Strategy.
     *
     * Returns the response body on success, or null on (Permanent/CB-open) across all URLs.
     */
    /**
     * @param list<string> $urls
     * @param array<string, mixed>|null $jsonPayload
     */
    private function executeWithRetry(array $urls, ?array $jsonPayload = null): ?string
    {
        // FIX-S33-R14 (گزارش بخش ۱۳): timeout تنظیمی بدون clamp به CURLOPT_TIMEOUT
        // می‌رفت؛ مقدار 0 = انتظار بی‌نهایت cURL (provider متصل ولی بی‌پاسخ، worker
        // معلق). اکنون بازهٔ امن ۱..۱۲۰ اعمال می‌شود (هم‌الگوی FIX-P3-ADP-050).
        $rawTimeout = $this->appSettings->get('crypto_api_timeout', 15);
        $timeout = is_numeric($rawTimeout) ? max(1, min(120, (int)$rawTimeout)) : 15;
        $lastError = null;

        // L-25 Fix: allowlist دامنه برای مسیر خارجیِ ورودی منطق مالی؛ در صورت خالی بودن
        // رفتار قبلی (فقط SSRF) حفظ می‌شود تا سازگاری به عقب حفظ گردد.
        $allowedHosts = array_values(array_filter(array_map(
            'trim',
            explode(',', str_value($this->appSettings->get('crypto_api_allowed_hosts', '')))
        ), static fn($h) => $h !== ''));

        foreach ((array)$urls as $index => $url) {
            // ✅ SSRF check + L-25 allowlist دامنه — جلوگیری از تماس با شبکهٔ داخلی و دامنهٔ غیرمجاز
            if (!$this->isExternalUrlSafe($url, $allowedHosts)) {
                $this->logger->warning('crypto.api.ssrf_blocked', ['url' => $url]);
                continue;
            }
            // Every external verification call is rate-limited per provider,
            // regardless of whether the URL contains an API key. The key only
            // changes provider quota, never our own request budget.
            if ($this->rateLimiter !== null) {
                $host = parse_url($url, PHP_URL_HOST);
                $provider = is_string($host) && $host !== '' ? strtolower($host) : 'unknown';
                $maxPerMinute = max(1, min(120, (is_numeric($this->appSettings->get('crypto_provider_requests_per_minute', 30)) ? (int)$this->appSettings->get('crypto_provider_requests_per_minute', 30) : 30)));
                if (!$this->rateLimiter->attempt('crypto_provider:' . $provider, $maxPerMinute, 1, true)) {
                    $this->logger->warning('crypto.api.rate_limited_locally', ['provider' => $provider]);
                    continue;
                }
            }

            try {
                // Use a separate breaker for each endpoint to isolate failures
                $breakerName = 'crypto_api_' . parse_url($url, PHP_URL_HOST);
                
                $response = $this->callWithBreaker($breakerName, function () use ($url, $timeout, $jsonPayload): string {
                    return $this->retryTransient(function () use ($url, $timeout, $jsonPayload): string {
                        $ch = \curl_init($url);
                        \curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        \curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
                        \curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(8, max(2, (int)floor($timeout / 2))));
                        \curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
                        \curl_setopt($ch, CURLOPT_HTTPHEADER, array_merge([
                            'User-Agent: ChortkeSecureApp/1.0 (+https://chortke.com)',
                            'Accept: application/json',
                        ], $jsonPayload !== null ? ['Content-Type: application/json'] : [], trace_headers()));
                        // FIX-R36-W1 (F-A19d-01): پشتیبانی POST-JSON برای runGetMethod Toncenter
                        // (resolve کردن jetton-wallet از قرارداد مادر) — مسیر GET قبلی دست‌نخورده.
                        if ($jsonPayload !== null) {
                            \curl_setopt($ch, CURLOPT_POST, true);
                            \curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($jsonPayload, JSON_UNESCAPED_UNICODE));
                        }
                        $response = \curl_exec($ch);
                        $httpCode = (int) \curl_getinfo($ch, CURLINFO_HTTP_CODE);
                        $errno    = (int) \curl_errno($ch);
                        $error    = \curl_error($ch);
                        \curl_close($ch);

                        if ($httpCode === 200 && is_string($response) && $response !== '') {
                            return $response;
                        }

                        $this->logger->warning('crypto.api.attempt_failed', [
                            'url'       => $url,
                            'http_code' => $httpCode,
                            'errno'     => $errno,
                            'error'     => $error ?: 'HTTP Status ' . $httpCode,
                        ]);
                        throw $this->classifyHttpFailure($httpCode, $errno, (string)$response, ['provider' => 'crypto_api']);
                    }, 3, 500, 4000);
                });

                if ($response !== null) {
                    return $response;
                }
            } catch (\Core\Exceptions\PermanentFailure $e) {
                $lastError = $e->getMessage();
                $this->logger->warning('crypto.api.permanent_failure', ['url' => $url, 'error' => $lastError]);
                // If permanent failure (e.g., 400 Bad Request), it's usually bad input, not a node issue.
                // However, we still try the next node just in case it's a proxy error.
            } catch (\Throwable $e) {
                $lastError = $e->getMessage();
                $this->logger->error('crypto.api.unavailable', [
                    'url'   => $url,
                    'class' => get_class($e),
                    'error' => $lastError,
                ]);
            }
        }
        
        $this->logger->critical('crypto.api.all_nodes_failed', [
            'urls' => $urls,
            'last_error' => $lastError
        ]);
        
        return null;
    }

    /**
     * Normalize Tron/BSC addresses to lower-case / hexadecimal representation for safe matches
     */
    private function normalizeAddress(string $address, string $network): string
    {
        $address = trim((string)$address);
        $net = strtolower((string)$network);
        if ($net === 'tron') {
            // نگاشت قرارداد USDT (base58/hex) حفظ می‌شود؛ تطبیقِ هر دو نمایش
            // canonicalize می‌شود تا آداپتور/تنظیمات با نمایش‌های مختلف قرارداد نشکند.
            // FIX: ثابت hex قبلی (41a614f803b6c480…) مقدار واقعی decode نشده بود —
            // hex صحیح قرارداد USDT/TRON همان 41a614f803b6fd78… است.
            $base58Contract = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
            $hexContract = '41a614f803b6fd780986a42c78ec9c7f77e6ded13c710277f5';
            if (strcasecmp($address, $base58Contract) === 0 || strcasecmp($address, $hexContract) === 0) {
                return 'tr7nhqjekqxgwtci8q8zy4pl8otszgjlj6t';
            }
            // نمایش hex مستقیم ۴۲ کاراکتری — lowercase امن است (hex حرف‌حساس نیست)
            if (ctype_xdigit($address) && strlen($address) === 42) {
                return strtolower($address);
            }
            // FIX-P3-ADP-053: base58 → payload hex (۲۱ بایت) بدون case-folding؛
            // دو آدرسِ فقط-متفاوت-در-حروف هرگز به شکل واحد نمی‌رسند (FIX-S33-R13 حفظ).
            $payloadHex = $this->base58ToPayloadHex($address);
            if ($payloadHex !== null) {
                return $payloadHex;
            }
            // ورودی ناپارس‌پذیر — همان رشته برای مقایسهٔ دقیق (fail-closed)
            return $address;
        }
        if (in_array($net, ['bsc', 'evm', 'bnb20'], true)) {
            // آدرس‌های hex EVM به‌طور قراردادی case-insensitive‌اند — lowercase امن است.
            return strtolower($address);
        }
        // بقیهٔ شبکه‌ها (SOL/TON/…) — بدون تغییر case (Base58/bech32 حرف‌حساس‌اند).
        return $address;
    }

    /**
     * FIX-P3-ADP-053: decode Base58 → payload hex ۲۱ بایتی (بدون تحمیل checksum —
     * canonicalization صرفاً برای مقایسهٔ برابری است؛ آدرس‌های با checksum متفاوت
     * payload متفاوت دارند و به‌طور طبیعی برابر نمی‌شوند).
     */
    private function base58ToPayloadHex(string $address): ?string
    {
        if ($address === '' || strlen($address) > 44 || preg_match('/^[1-9A-HJ-NP-Za-km-z]+$/', $address) !== 1) {
            return null;
        }
        $alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
        $n = '0';
        foreach (str_split($address) as $char) {
            $pos = strpos($alphabet, $char);
            if ($pos === false) {
                return null;
            }
            $n = bcadd(bcmul($n, '58', 0), (string)$pos, 0);
        }
        $hex = '';
        while (bccomp($n, '0', 0) > 0) {
            $hex = str_pad(dechex((int)bcmod($n, '256')), 2, '0', STR_PAD_LEFT) . $hex;
            $n = bcdiv($n, '256', 0);
        }
        // کاراکترهای '1' پیشوند = بایت‌های صفرِ پیشوند
        foreach (str_split($address) as $char) {
            if ($char === '1') {
                $hex = '00' . $hex;
            } else {
                break;
            }
        }
        $bin = @hex2bin($hex);
        if ($bin === false || strlen($bin) !== 25) {
            return null;
        }
        return bin2hex(substr($bin, 0, 21));
    }

    /**
     * Verify TRON transaction
     */
    /** @return array<string, mixed> */
    private function verifyTronTransaction(string $txHash, string $fromWallet, string $toWallet, string $expectedAmount): array
    {
        try {
            $urls = [
                sprintf($this->providerUrl('tronscan_transaction_url', 'https://apilist.tronscan.org/api/transaction-info?hash=%s'), rawurlencode($txHash)),
                sprintf($this->providerUrl('trongrid_events_url', 'https://api.trongrid.io/v1/transactions/%s/events'), rawurlencode($txHash)),
            ];
            $response = $this->executeWithRetry($urls);

            if (!$response) {
                return ['status' => 'error', 'reason' => 'خطا در اتصال به TronScan API یا فعال بودن مدار قطع‌کننده (Circuit Breaker)'];
            }

            $decoded = json_decode((string)$response, true);
            if (!is_array($decoded)) {
                return ['status' => 'error', 'reason' => 'پاسخ نامعتبر از API'];
            }
            // TronGrid event endpoint has a different response schema from
            // TronScan. Parse it separately; never force it through the
            // TronScan contractData parser.
            if (!isset($decoded['contractData']) && isset($decoded['data']) && is_array($decoded['data'])) {
                return $this->verifyTronGridEvents($decoded, $fromWallet, $toWallet, $expectedAmount);
            }
            if (!isset($decoded['contractData']) && isset($decoded['token_transfers']) && is_array($decoded['token_transfers'])) {
                return $this->verifyTronScanTransferFeed($decoded, $txHash, $fromWallet, $toWallet, $expectedAmount);
            }
            if (!isset($decoded['contractData']) || !is_array($decoded['contractData'])) {
                return ['status' => 'error', 'reason' => 'پاسخ نامعتبر از TronScan'];
            }
            $data = $decoded;
            $contractData = $data['contractData'];

            if (trim($fromWallet) !== '') {
                $chainFrom = $contractData['owner_address'] ?? $contractData['from_address'] ?? '';
                if (!is_string($chainFrom) || $chainFrom === '') {
                    return ['status' => 'error', 'reason' => 'آدرس مبدا برای تطبیق در پاسخ TRON موجود نیست'];
                }
                if ($this->normalizeAddress($chainFrom, 'tron') !== $this->normalizeAddress($fromWallet, 'tron')) {
                    return ['status' => 'mismatch', 'reason' => 'آدرس مبدا تراکنش با آدرس ثبت‌شده مطابقت ندارد'];
                }
            }

            // Issue 1: Check status and confirmations
            if (!isset($data['confirmed']) || $data['confirmed'] !== true || !isset($data['contractRet']) || $data['contractRet'] !== 'SUCCESS') {
                return ['status' => 'pending', 'reason' => 'تراکنش هنوز تایید نهایی نشده است'];
            }

            // Get dynamic block confirmations count (C-05)
            $currentBlockUrls = [
                $this->providerUrl('tronscan_status_url', 'https://apilist.tronscan.org/api/system/status'),
                $this->providerUrl('trongrid_block_url', 'https://api.trongrid.io/wallet/getnowblock'),
            ];
            $blockResponse = $this->executeWithRetry($currentBlockUrls);
            $currentBlock = 0;
            if (is_string($blockResponse) && $blockResponse !== '') {
                $blockData = json_decode($blockResponse, true);
                if (is_array($blockData)) {
                    // FIX-S33-R11: هر دو schema بلوک پارس می‌شود — TronScan (database.block)
                    // و TronGrid getnowblock (block_header.raw_data.number)؛ schema دوم
                    // در مسیر contractData قبلاً currentBlock=0 می‌داد (fallback به
                    // confirmations خودِ tx). هم‌تراز با مسیر verifyTronGridEvents.
                    $rawBlock = $blockData['database']['block'] ?? $blockData['block_header']['raw_data']['number'] ?? 0;
                    $currentBlock = is_int($rawBlock) || (is_string($rawBlock) && ctype_digit($rawBlock)) ? (int)$rawBlock : 0;
                }
            }

            $txBlock = (int)($data['block'] ?? 0);
            $confirmations = ($currentBlock > 0 && $txBlock > 0) ? ($currentBlock - $txBlock) : (isset($data['confirmations']) ? (int)$data['confirmations'] : 0);
            // FIX-C103 (یافتهٔ ۱۰۳): منبع واحد تأییدها — لیترال 19 حذف شد؛
            // مقدار تنظیمی هم با بازهٔ امن اعتبارسنجی می‌شود (C101).
            $confRaw = $this->appSettings->get(
                \App\Constants\CryptoConstants::CONFIRMATION_SETTING_KEYS['trc20'],
                \App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_TRC20
            );
            $minConfirmations = \App\Constants\CryptoConstants::resolveMinConfirmations(
                'trc20',
                is_numeric($confRaw) ? (int)$confRaw : null
            );

            if ($confirmations < $minConfirmations) {
                return ['status' => 'pending', 'reason' => "تعداد تاییدهای تراکنش TRON کافی نیست (نیاز به حداقل $minConfirmations تایید دارد، فعلی: $confirmations)"];
            }

            // Issue 2: Poisoning check (Fake Token Transfer) with config support and normalization
            $validContract = $this->appSettings->get('crypto_contract_trc20_usdt', 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t');
            $receivedContract = $contractData['contract_address'] ?? '';
            if (!is_string($validContract) || !is_string($receivedContract) || $validContract === '' || $receivedContract === '') {
                return ['status' => 'error', 'reason' => 'پاسخ یا تنظیمات قرارداد USDT نامعتبر است'];
            }

            if ($this->normalizeAddress($receivedContract, 'tron') !== $this->normalizeAddress($validContract, 'tron')) {
                return ['status' => 'mismatch', 'reason' => 'توکن ارسالی USDT نیست'];
            }

            // Check if transaction is to our wallet
            $to = $contractData['to_address'] ?? '';
            if (!is_string($to) || $to === '') {
                return ['status' => 'error', 'reason' => 'آدرس گیرنده در پاسخ API نامعتبر است'];
            }
            if ($this->normalizeAddress($to, 'tron') !== $this->normalizeAddress($toWallet, 'tron')) {
                return ['status' => 'mismatch', 'reason' => 'آدرس گیرنده مطابقت ندارد'];
            }

            // Check amount using integer comparisons to avoid float precision bugs (H-02)
            $rawAmount = $contractData['amount'] ?? null;
            if (!is_int($rawAmount) && !(is_string($rawAmount) && ctype_digit($rawAmount))) {
                return ['status' => 'error', 'reason' => 'مبلغ تراکنش در پاسخ API نامعتبر است'];
            }
            $amountRaw = (int)$rawAmount;
            $expectedRaw = (int)\bcadd(\bcmul($expectedAmount, '1000000', 8), '0.5', 0);
            $toleranceRaw = 10000; // 0.01 USDT tolerance in SUN units

            // 🛡️ FIX-CH02: tolerance یک‌طرفهٔ محافظه‌کارانه — کم‌پرداختی (هر مقدار
            // کمتر از expected) mismatch است و هرگز verified نمی‌شود؛ فقط
            // overpayment تا سقف tolerance (گردِ غبار زنجیره) پذیرفته می‌شود.
            // invariant: اعتبار کیف پول ≤ مبلغ واقعاً دریافت‌شده.
            if ($amountRaw < $expectedRaw || ($amountRaw - $expectedRaw) > $toleranceRaw) {
                return ['status' => 'mismatch', 'reason' => 'مبلغ تراکنش مطابقت ندارد'];
            }

            return ['status' => 'verified', 'details' => $data];

        } catch (\Exception $e) {
            $this->logger->error('crypto.verify.tron.failed', [
                'tx_hash' => $txHash,
                'error' => $e->getMessage()
            ]);
            return ['status' => 'error', 'reason' => 'خطا در بررسی تراکنش TRON'];
        }
    }

    /** Parse TronScan token transfer feed responses (different from transaction-info). */
    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function verifyTronScanTransferFeed(array $payload, string $txHash, string $fromWallet, string $toWallet, string $expectedAmount): array
    {
        $transfers = $payload['token_transfers'] ?? null;
        if (!is_array($transfers)) return ['status' => 'error', 'reason' => 'فهرست انتقال‌های TronScan نامعتبر است'];
        $tx = null;
        foreach ($transfers as $candidate) {
            if (is_array($candidate) && isset($candidate['transaction_id']) && is_string($candidate['transaction_id']) && strtolower($candidate['transaction_id']) === strtolower($txHash)) { $tx = $candidate; break; }
        }
        if (!is_array($tx)) return ['status' => 'pending', 'reason' => 'انتقال موردنظر در feed TronScan یافت نشد'];
        if (($tx['confirmed'] ?? false) !== true || ($tx['contractRet'] ?? '') !== 'SUCCESS') return ['status' => 'pending', 'reason' => 'تاییدهای TronScan کافی نیست'];
        $contract=$tx['contract_address']??''; $from=$tx['from_address']??''; $to=$tx['to_address']??''; $quant=$tx['quant']??null;
        if (!is_string($contract)||!is_string($from)||!is_string($to)||(!is_int($quant)&&!(is_string($quant)&&ctype_digit($quant)))) return ['status'=>'error','reason'=>'دادهٔ انتقال TronScan ناقص است'];
        $valid=$this->appSettings->get('crypto_contract_trc20_usdt','TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t');
        if(!is_string($valid)||$this->normalizeAddress($contract,'tron')!==$this->normalizeAddress($valid,'tron')) return ['status'=>'mismatch','reason'=>'توکن feed TronScan USDT نیست'];
        if($this->normalizeAddress($to,'tron')!==$this->normalizeAddress($toWallet,'tron')) return ['status'=>'mismatch','reason'=>'گیرنده feed TronScan مطابقت ندارد'];
        if(trim($fromWallet)!==''&&$this->normalizeAddress($from,'tron')!==$this->normalizeAddress($fromWallet,'tron')) return ['status'=>'mismatch','reason'=>'فرستنده feed TronScan مطابقت ندارد'];
        // FIX-S33-R10 (گزارش بخش ۱۳): tolerance یک‌طرفه در همهٔ verifierها — fallback
        // feed قبلاً قدرمطلق اختلاف را می‌پذیرفت (کم‌پرداختی تا 0.01 USDT verified
        // می‌شد در حالی که primary رد می‌کرد). invariant: اعتبار ≤ مبلغ واقعی.
        $amountRawFeed = (int)$quant;
        $expectedRawFeed = (int)\bcadd(\bcmul($expectedAmount, '1000000', 8), '0.5', 0);
        if ($amountRawFeed < $expectedRawFeed || ($amountRawFeed - $expectedRawFeed) > 10000) return ['status'=>'mismatch','reason'=>'مبلغ feed TronScan مطابقت ندارد'];
        // FIX-S33-R11: گیت تأییدهای حداقلیِ سیاست مشترک — feed قبلاً با «confirmed=true»
        // خودِ provider (۱ تأیید) verified می‌شد در حالی که سیاست تنظیمی TRC20 (۱۹) بود.
        $feedBlock = $tx['block'] ?? null;
        if (!is_int($feedBlock) && !(is_string($feedBlock) && ctype_digit($feedBlock))) {
            return ['status' => 'error', 'reason' => 'شماره بلاک feed TronScan برای تاییدها موجود نیست'];
        }
        $feedBlockResponse = $this->executeWithRetry([
            $this->providerUrl('tronscan_status_url', 'https://apilist.tronscan.org/api/system/status'),
            $this->providerUrl('trongrid_block_url', 'https://api.trongrid.io/wallet/getnowblock'),
        ]);
        $feedBlockData = is_string($feedBlockResponse) ? json_decode($feedBlockResponse, true) : null;
        $feedCurrentBlock = 0;
        if (is_array($feedBlockData)) {
            $feedRaw = $feedBlockData['database']['block'] ?? $feedBlockData['block_header']['raw_data']['number'] ?? 0;
            $feedCurrentBlock = is_int($feedRaw) || (is_string($feedRaw) && ctype_digit($feedRaw)) ? (int)$feedRaw : 0;
        }
        $feedConfRaw = $this->appSettings->get(
            \App\Constants\CryptoConstants::CONFIRMATION_SETTING_KEYS['trc20'],
            \App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_TRC20
        );
        $feedMinConf = \App\Constants\CryptoConstants::resolveMinConfirmations(
            'trc20',
            is_numeric($feedConfRaw) ? (int)$feedConfRaw : null
        );
        if ($feedCurrentBlock <= (int)$feedBlock || ($feedCurrentBlock - (int)$feedBlock) < $feedMinConf) {
            return ['status' => 'pending', 'reason' => 'تاییدهای feed TronScan کافی نیست'];
        }
        return ['status'=>'verified','details'=>$tx];
    }

    /**
     * Parse the public TronGrid event endpoint. This endpoint intentionally has
     * a separate parser because its schema differs from TronScan's contractData.
     */
    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function verifyTronGridEvents(array $payload, string $fromWallet, string $toWallet, string $expectedAmount): array
    {
        $events = $payload['data'] ?? null;
        if (!is_array($events)) {
            return ['status' => 'error', 'reason' => 'فهرست رویدادهای TronGrid نامعتبر است'];
        }

        $event = null;
        foreach ($events as $candidate) {
            if (!is_array($candidate) || ($candidate['event_name'] ?? '') !== 'Transfer') {
                continue;
            }
            $result = $candidate['result'] ?? null;
            if (is_array($result)) {
                $event = $candidate;
                break;
            }
        }
        if ($event === null) {
            return ['status' => 'pending', 'reason' => 'رویداد انتقال USDT در TronGrid یافت نشد'];
        }

        $result = $event['result'];
        $contract = $event['contract_address'] ?? '';
        $from = $result['from'] ?? '';
        $to = $result['to'] ?? '';
        $value = $result['value'] ?? null;
        if (!is_string($contract) || !is_string($from) || !is_string($to) || (!is_int($value) && !(is_string($value) && ctype_digit($value)))) {
            return ['status' => 'error', 'reason' => 'دادهٔ رویداد TronGrid برای تطبیق کافی نیست'];
        }

        $validContract = $this->appSettings->get('crypto_contract_trc20_usdt', 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t');
        if (!is_string($validContract) || $this->normalizeAddress($contract, 'tron') !== $this->normalizeAddress($validContract, 'tron')) {
            return ['status' => 'mismatch', 'reason' => 'توکن رویداد TronGrid USDT نیست'];
        }
        if ($this->normalizeAddress($to, 'tron') !== $this->normalizeAddress($toWallet, 'tron')) {
            return ['status' => 'mismatch', 'reason' => 'آدرس گیرنده TronGrid مطابقت ندارد'];
        }
        if (trim($fromWallet) !== '' && $this->normalizeAddress($from, 'tron') !== $this->normalizeAddress($fromWallet, 'tron')) {
            return ['status' => 'mismatch', 'reason' => 'آدرس مبدا TronGrid با آدرس ثبت‌شده مطابقت ندارد'];
        }

        $amountRaw = (int)$value;
        $expectedRaw = (int)\bcadd(\bcmul($expectedAmount, '1000000', 8), '0.5', 0);
        // FIX-S33-R10: tolerance یک‌طرفه — کم‌پرداختی (علامت منفی) mismatch قطعی است؛
        // فقط overpayment تا سقف 0.01 USDT (گردِ غبار) پذیرفته می‌شود.
        $eventsDiff = $amountRaw - $expectedRaw;
        if ($eventsDiff < 0 || $eventsDiff > 10000) {
            return ['status' => 'mismatch', 'reason' => 'مبلغ رویداد TronGrid مطابقت ندارد'];
        }

        $eventBlock = $event['block_number'] ?? null;
        if (!is_int($eventBlock) && !(is_string($eventBlock) && ctype_digit($eventBlock))) {
            return ['status' => 'error', 'reason' => 'شماره بلاک TronGrid برای تاییدها موجود نیست'];
        }
        $blockResponse = $this->executeWithRetry([
            $this->providerUrl('tronscan_status_url', 'https://apilist.tronscan.org/api/system/status'),
            $this->providerUrl('trongrid_block_url', 'https://api.trongrid.io/wallet/getnowblock'),
        ]);
        $blockData = is_string($blockResponse) ? json_decode($blockResponse, true) : null;
        $currentBlock = 0;
        if (is_array($blockData)) {
            $raw = $blockData['database']['block'] ?? $blockData['block_header']['raw_data']['number'] ?? 0;
            $currentBlock = is_int($raw) || (is_string($raw) && ctype_digit($raw)) ? (int)$raw : 0;
        }
        if ($currentBlock <= (int)$eventBlock) {
            return ['status' => 'pending', 'reason' => 'تاییدهای TronGrid هنوز کافی نیست'];
        }
        // FIX-C103 (یافتهٔ ۱۰۳): منبع واحد تأییدها — مقدار تنظیمی فقط یک‌بار خوانده
        // و همیشه اعتبارسنجی می‌شود (قبلاً دو get و سه لیترال 19 تکرار شده بود).
        $confRaw = $this->appSettings->get(
            \App\Constants\CryptoConstants::CONFIRMATION_SETTING_KEYS['trc20'],
            \App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_TRC20
        );
        $min = \App\Constants\CryptoConstants::resolveMinConfirmations(
            'trc20',
            is_numeric($confRaw) ? (int)$confRaw : null
        );
        if (($currentBlock - (int)$eventBlock) < $min) {
            return ['status' => 'pending', 'reason' => 'تعداد تاییدهای TronGrid کافی نیست'];
        }

        return ['status' => 'verified', 'details' => $event];
    }

    /**
     * Public JSON-RPC fallback for EVM chains when explorer data is unavailable.
     * @return array<string, mixed>
     */
    private function verifyEvmRpcFallback(string $network, string $settingKey, string $defaultUrl, string $txHash, string $fromWallet, string $toWallet, string $expectedAmount, string $usdtContract, int $decimals, string $confirmationSetting, string $networkKey = 'bnb20'): array
    {
        $rpcUrl = $this->appSettings->get($settingKey, $defaultUrl);
        if (!is_string($rpcUrl) || !$this->isExternalUrlSafe($rpcUrl)) return ['status' => 'error', 'reason' => 'RPC عمومی این شبکه تنظیم یا معتبر نیست'];
        $receipt = $this->executeJsonRpc($rpcUrl, 'eth_getTransactionReceipt', [$txHash]);
        if (!is_array($receipt) || !array_key_exists('result', $receipt)) return ['status' => 'error', 'reason' => 'پاسخ RPC برای receipt کافی نیست'];
        if ($receipt['result'] === null) return ['status' => 'pending', 'reason' => 'تراکنش هنوز در RPC عمومی یافت نشده است'];
        $r = $receipt['result'];
        if (!is_array($r) || ($r['status'] ?? '') !== '0x1') return ['status' => 'mismatch', 'reason' => 'receipt تراکنش ناموفق است'];
        // receipt.from is the transaction caller and may be a router contract.
        // The relevant sender for a BEP20 USDT deposit is the Transfer topic[1].
        $transferTopic = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';
        $matched = null;
        foreach (($r['logs'] ?? []) as $log) {
            if (!is_array($log) || strtolower((string)($log['address'] ?? '')) !== strtolower($usdtContract)) continue;
            $topics = $log['topics'] ?? [];
            if (!is_array($topics) || count($topics) < 3 || strtolower((string)$topics[0]) !== $transferTopic) continue;
            $recipient = '0x' . substr((string)$topics[2], -40);
            if ($this->normalizeAddress($recipient, 'evm') !== $this->normalizeAddress($toWallet, 'evm')) continue;
            $matched = $log; break;
        }
        if (!is_array($matched)) return ['status' => 'mismatch', 'reason' => 'رویداد انتقال USDT به آدرس مقصد یافت نشد'];
        if (trim($fromWallet) !== '') {
            $topics = $matched['topics'] ?? [];
            $tokenFrom = is_array($topics) && isset($topics[1]) ? '0x' . substr((string)$topics[1], -40) : '';
            if ($tokenFrom === '' || $this->normalizeAddress($tokenFrom, 'evm') !== $this->normalizeAddress($fromWallet, 'evm')) {
                return ['status' => 'mismatch', 'reason' => 'آدرس فرستنده انتقال USDT با آدرس ثبت‌شده مطابقت ندارد'];
            }
        }
        $raw = $this->hexToDecimal((string)($matched['data'] ?? ''));
        if ($raw === null) return ['status' => 'error', 'reason' => 'مبلغ raw در RPC نامعتبر است'];
        $expected = bcmul((string)$expectedAmount, bcpow('10', (string)$decimals, 0), 0);
        $tolerance = bcmul('0.01', bcpow('10', (string)$decimals, 0), 0);
        // FIX-S33-R10: tolerance یک‌طرفه — علامت قبلاً strip می‌شد (قدرمطلق) و
        // کم‌پرداختی تا 0.01 هم verified می‌شد؛ اکنون کم‌پرداختی mismatch قطعی است.
        $diff = bcsub($raw, $expected, 0);
        if (str_starts_with($diff, '-')) return ['status' => 'mismatch', 'reason' => 'مبلغ انتقال RPC مطابقت ندارد'];
        if (bccomp($diff, $tolerance, 0) === 1) return ['status' => 'mismatch', 'reason' => 'مبلغ انتقال RPC مطابقت ندارد'];
        $block = $this->executeJsonRpc($rpcUrl, 'eth_blockNumber', []);
        $current = is_array($block) && is_string($block['result'] ?? null) ? hexdec((string)$block['result']) : 0;
        $txBlock = isset($r['blockNumber']) && is_string($r['blockNumber']) ? hexdec($r['blockNumber']) : 0;
        // FIX-C103 (یافتهٔ ۱۰۳): پیش‌فرض fallback RPC دیگر لیترال ثابت 12 نیست —
        // بر اساس networkKey از نقشهٔ کانونیک خوانده می‌شود (قبلاً واریز BNB20 در مسیر
        // fallback با ۱۲ تأیید تأیید می‌شد در حالی که سیاست تنظیمی ۱۵ بود).
        $defaultConfirmations = \App\Constants\CryptoConstants::MIN_CONFIRMATIONS[$networkKey]
            ?? \App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_BNB20;
        $minValue = $this->appSettings->get($confirmationSetting, $defaultConfirmations);
        $min = \App\Constants\CryptoConstants::resolveMinConfirmations(
            $networkKey,
            is_numeric($minValue) ? (int)$minValue : null
        );
        if ($current <= $txBlock || ($current - $txBlock) < $min) return ['status' => 'pending', 'reason' => 'تاییدهای RPC کافی نیست'];
        return ['status' => 'verified', 'details' => $r];
    }

    /**
     * @param array<int|string, mixed> $params
     * @return array<string, mixed>|null
     */
    private function executeJsonRpc(string $url, string $method, array $params): ?array
    {
        $host = parse_url($url, PHP_URL_HOST);
        if ($this->rateLimiter !== null && !$this->rateLimiter->attempt('crypto_provider:' . strtolower(is_string($host) ? $host : 'rpc'), max(1, min(120, (is_numeric($this->appSettings->get('crypto_provider_requests_per_minute', 30)) ? (int)$this->appSettings->get('crypto_provider_requests_per_minute', 30) : 30))), 1, true)) return null;
        $payload = json_encode(['jsonrpc' => '2.0', 'id' => 1, 'method' => $method, 'params' => $params]);
        if (!is_string($payload)) return null;
        try {
            $response = $this->callWithBreaker('crypto_rpc_' . strtolower(is_string($host) ? $host : 'rpc'), function () use ($url, $payload): string {
                return $this->retryTransient(function () use ($url, $payload): string {
                    $rawT = $this->appSettings->get('crypto_api_timeout',15);
                    // FIX-S33-R14: clamp ۱..۱۲۰ — timeout=0 قبلاً مستقیم به CURLOPT_TIMEOUT
                    // می‌رسید (انتظار بی‌نهایت روی provider بی‌پاسخ)
                    $timeout = is_numeric($rawT) ? max(1, min(120, (int)$rawT)) : 15;
                    $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$payload,CURLOPT_TIMEOUT=>$timeout,CURLOPT_CONNECTTIMEOUT=>max(2,min(8,(int)floor($timeout/2))),CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json']]);
                    $body=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $errno=curl_errno($ch); curl_close($ch);
                    if ($code===200 && is_string($body) && $body!=='') return $body;
                    throw $this->classifyHttpFailure($code,$errno,(string)$body,['provider'=>'crypto_rpc']);
                }, 2, 500, 2000);
            });
            $decoded = json_decode((string)$response, true);
            // FIX-P3-ADP-057: پاسخ باید schema کامل JSON-RPC 2.0 با id منطبق بدهد —
            // پاسخ schema-broken یا error-member هرگز به مسیر وریفای نمی‌رسد.
            if (is_array($decoded) && self::isValidJsonRpcResponse($decoded, 1)) {
                /** @var array<string, mixed> $decoded */
                return $decoded;
            }
            return null;
        } catch (\Throwable) { return null; }
    }

    /**
     * FIX-P3-ADP-057: اعتبارسنجی schema پاسخ JSON-RPC 2.0 (fail-closed):
     * آرایه با jsonrpc==='2.0'، id منطبق (int یا رشتهٔ هم‌ارزش)، بدون error-member،
     * و با کلید result (مقدار result می‌تواند null باشد).
     */
    private static function isValidJsonRpcResponse(mixed $response, int|string $requestId): bool
    {
        if (!is_array($response)) {
            return false;
        }
        if (($response['jsonrpc'] ?? null) !== '2.0') {
            return false;
        }
        $id = $response['id'] ?? null;
        if (!is_int($id) && !is_string($id)) {
            return false;
        }
        if ((string)$id !== (string)$requestId) {
            return false;
        }
        if (array_key_exists('error', $response)) {
            return false;
        }
        return array_key_exists('result', $response);
    }

    private function hexToDecimal(string $hex): ?string
    {
        $hex = strtolower(preg_replace('/^0x/', '', trim($hex)) ?? '');
        if ($hex === '' || !ctype_xdigit($hex)) return null;
        $value = '0'; foreach (str_split($hex) as $digit) $value = bcadd(bcmul($value, '16', 0), (string)hexdec($digit), 0);
        return $value;
    }

    /**
     * Verify BSC transaction
     */
    /** @return array<string, mixed> */
    private function verifyBscTransaction(string $txHash, string $fromWallet, string $toWallet, string $expectedAmount): array
    {
        try {
            $apiKey = $this->appSettings->get('bscscan_api_key', '');
            // API key only raises provider rate limits; public BscScan access
            // remains a valid verification path when the admin leaves it empty.
            $apiSuffix = is_string($apiKey) && trim($apiKey) !== ''
                ? '&apikey=' . urlencode($apiKey)
                : '';
            $urls = [
                sprintf($this->providerUrl('bscscan_url', 'https://api.bscscan.com/api?module=account&action=tokentx&txhash=%s'), rawurlencode($txHash)) . $apiSuffix,
                sprintf($this->providerUrl('bscscan_fallback_url', 'https://api-testnet.bscscan.com/api?module=account&action=tokentx&txhash=%s'), rawurlencode($txHash)) . $apiSuffix,
            ];
            
            $response = $this->executeWithRetry($urls);

            if (!$response) {
                return ['status' => 'error', 'reason' => 'خطا در اتصال به BscScan API یا فعال بودن مدار قطع‌کننده (Circuit Breaker)'];
            }

            $data = json_decode((string)$response, true);
            $tx = null;
            if (is_array($data) && isset($data['result']) && is_array($data['result']) && isset($data['result'][0]) && is_array($data['result'][0])) {
                $tx = $data['result'][0];
            }

            if (!is_array($tx)) {
                // FIX-S33-R11: قرارداد USDT در fallback RPC هم از تنظیم خوانده می‌شود؛
                // هاردکد قبلی تغییر قرارداد تنظیمیِ ادمین را در مسیر fallback نادیده می‌گرفت.
                $fallbackContract = $this->appSettings->get('crypto_contract_bnb20_usdt', '0x55d398326f99059ff775485246999027b3197955');
                $fallbackContract = is_string($fallbackContract) && $fallbackContract !== ''
                    ? $fallbackContract
                    : '0x55d398326f99059ff775485246999027b3197955';
                return $this->verifyEvmRpcFallback('BNB20', 'bsc_rpc_url', 'https://bsc-dataseed.binance.org/', $txHash, $fromWallet, $toWallet, $expectedAmount, $fallbackContract, 18, 'crypto_min_confirmations_bnb20', 'bnb20');
            }

            // FIX-R2-18: مقایسهٔ هش تراکنش پاسخ‌شده با هش درخواستی (defense-in-depth).
            // کوئری به txhash فیلتر شده اما مسیر TON همین مقایسه را دارد و BSC نداشت؛
            // پاسخ ناهم‌راستا/آلوده (proxy/cache/API تغییررفتار) می‌توانست جزئیات یک
            // تراکنش متفاوت را به‌عنوان «verified» این تراکنش بپذیرد. اکنون ناهم‌خوانی
            // هش = mismatch صریح.
            $returnedHash = $tx['hash'] ?? null;
            if (!is_string($returnedHash) || $returnedHash === '') {
                return ['status' => 'error', 'reason' => 'هش تراکنش در پاسخ BscScan موجود نیست'];
            }
            if (strtolower($returnedHash) !== strtolower($txHash)) {
                $this->logger->warning('crypto.verify.bsc.hash_mismatch', [
                    'expected_hash' => $txHash,
                    'returned_hash' => $returnedHash,
                ]);
                return ['status' => 'mismatch', 'reason' => 'هش تراکنش پاسخ‌شده با درخواست مطابقت ندارد'];
            }

            if (trim($fromWallet) !== '') {
                $chainFrom = $tx['from'] ?? '';
                if (!is_string($chainFrom) || $chainFrom === '') {
                    return ['status' => 'error', 'reason' => 'آدرس مبدا برای تطبیق در پاسخ BSC موجود نیست'];
                }
                if ($this->normalizeAddress($chainFrom, 'bsc') !== $this->normalizeAddress($fromWallet, 'bsc')) {
                    return ['status' => 'mismatch', 'reason' => 'آدرس مبدا تراکنش با آدرس ثبت‌شده مطابقت ندارد'];
                }
            }

            // Issue 1: Confirmation check (C-05)
            if (!isset($tx['blockNumber']) || empty($tx['blockNumber'])) {
                return ['status' => 'pending', 'reason' => 'تراکنش هنوز در بلاک قرار نگرفته است'];
            }

            $confirmations = isset($tx['confirmations']) ? (int)$tx['confirmations'] : 0;
            // FIX-C103: منبع واحد — مقدار تنظیمی با resolveMinConfirmations اعتبارسنجی می‌شود
            $confRaw = $this->appSettings->get(
                \App\Constants\CryptoConstants::CONFIRMATION_SETTING_KEYS['bnb20'],
                \App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_BNB20
            );
            $minConfirmations = \App\Constants\CryptoConstants::resolveMinConfirmations(
                'bnb20',
                is_numeric($confRaw) ? (int)$confRaw : null
            );
            if ($confirmations < $minConfirmations) {
                return ['status' => 'pending', 'reason' => "تعداد تاییدهای تراکنش BSC کافی نیست (حداقل $minConfirmations تایید نیاز است، فعلی: $confirmations)"];
            }

            // Issue 2: Poisoning check (USDT BEP20) from Settings/Config
            $validContract = $this->appSettings->get('crypto_contract_bnb20_usdt', '0x55d398326f99059ff775485246999027b3197955');
            $contractAddress = $tx['contractAddress'] ?? '';
            if (!is_string($validContract) || !is_string($contractAddress) || $validContract === '' || $contractAddress === '') {
                return ['status' => 'error', 'reason' => 'پاسخ یا تنظیمات قرارداد BEP20 نامعتبر است'];
            }
            if ($this->normalizeAddress($contractAddress, 'bsc') !== $this->normalizeAddress($validContract, 'bsc')) {
                return ['status' => 'mismatch', 'reason' => 'توکن ارسالی USDT (BEP20) نیست'];
            }

            // Check receiver
            if ($this->normalizeAddress($tx['to'] ?? '', 'bsc') !== $this->normalizeAddress($toWallet, 'bsc')) {
                return ['status' => 'mismatch', 'reason' => 'آدررس گیرنده مطابقت ندارد'];
            }

            // Check amount using integer raw comparisons (H-02, M-05)
            $decimals = (int)($tx['tokenDecimal'] ?? 18);
            $amountRaw = $tx['value'] ?? '0';

            // Convert expected amount to raw token units using BCMath to avoid float issues
            $tokenUnit = bcpow('10', (string)$decimals, 0);
            $expectedRaw = bcmul((string)$expectedAmount, $tokenUnit, 0);
            $toleranceRaw = bcmul('0.01', $tokenUnit, 0);

            $diff = bcsub((string)$amountRaw, (string)$expectedRaw, 0);

            // 🛡️ FIX-CH02: tolerance یک‌طرفه — علامت منفی = کم‌پرداختی = mismatch قطعی
            // (قبلاً قدرمطلق می‌شد و تا ۰٫۰۱ کمبود هم verified می‌شد: پول از هیچ).
            if (str_starts_with($diff, '-')) {
                return ['status' => 'mismatch', 'reason' => 'مبلغ تراکنش مطابقت ندارد'];
            }

            if (bccomp($diff, $toleranceRaw, 0) === 1) {
                return ['status' => 'mismatch', 'reason' => 'مبلغ تراکنش مطابقت ندارد'];
            }

            return ['status' => 'verified', 'details' => $tx];

        } catch (\Exception $e) {
            $this->logger->error('crypto.verify.bsc.failed', [
                'tx_hash' => $txHash,
                'error' => $e->getMessage()
            ]);
            return ['status' => 'error', 'reason' => 'خطا در بررسی تراکنش BSC'];
        }
    }

    /**
     * Verify TON transaction (M-03)
     *
     * FIX-R36-W1 (F-A19d-01): واریز «USDT روی TON» یک jetton-transfer (TEP-74) است؛
     * در پاسخ getTransactions مقدار in_msg.value فقط گسِ nanoTON پیام داخلی است و
     * مبلغ واقعی USDT در بدنهٔ پیام با op=0x7362d09c (transfer_notification) است.
     * نسخهٔ قبلی بدنه را پارس نمی‌کرد و value را با expected×1e6 مقایسه می‌کرد →
     * واریزِ گسِ ~0.01 TON به‌عنوان شارژ کامل USDT وریفای می‌شد و واریزهای واقعی
     * رد می‌شدند. اکنون: پارس بدنه (op/query_id/amount ۶-رقمی/sender) + اثبات
     * جتون-مادر با resolve کردن jetton-wallet فرستنده از crypto_contract_ton_usdt
     * (runGetMethod) — ضد جتون جعلی؛ هر شکست = mismatch/error (fail-closed).
     */
    /** @return array<string, mixed> */
    private function verifyTonTransaction(string $txHash, string $fromWallet, string $toWallet, string $expectedAmount): array
    {
        try {
            $apiKeyValue = $this->appSettings->get('toncenter_api_key', '');
            $apiKey = is_string($apiKeyValue) ? $apiKeyValue : '';
            // FIX-R36-W3 (F-A19d-11): پنجرهٔ اسکن تنظیم‌پذیر (crypto_scan_limit_ton،
            // پیش‌فرض همان ۲۰ قدیمی، کران ۱..۱۰۰) — اسکن ثابتِ ۲۰تایی برای کیف‌پول‌های
            // پرتراکنش یعنی واریزِ عقب‌مانده هرگز found نمی‌شود (pending ابدی).
            $limitValue = $this->appSettings->get('crypto_scan_limit_ton', 20);
            $scanLimit = is_numeric($limitValue) ? max(1, min(100, (int)$limitValue)) : 20;
            $buildQuery = static function (string $extra) use ($toWallet, $apiKey): string {
                $q = '?address=' . rawurlencode($toWallet) . $extra;
                if ($apiKey) {
                    $q .= '&api_key=' . rawurlencode($apiKey);
                }
                return $q;
            };
            $urls = [
                rtrim($this->providerUrl('toncenter_url', 'https://toncenter.com/api/v2/getTransactions'), '?') . $buildQuery('&limit=' . $scanLimit . '&archival=true'),
                rtrim($this->providerUrl('toncenter_fallback_url', 'https://testnet.toncenter.com/api/v2/getTransactions'), '?') . $buildQuery('&limit=' . $scanLimit . '&archival=true'),
            ];

            // FIX-R36-W3 (F-A19d-11): جست‌وجوی hash-targeted — toncenter v2 پارامتر hash
            // دارد (شروع صفحه‌بندی از خودِ tx). اگر tx روی این آدرس موجود باشد، خارج بودنش
            // از پنجرهٔ اسکن هم دیگر «pending ابدی» نمی‌سازد؛ خالی/ناموفق → fallback به
            // اسکن پنجره‌ای (رفتار قبلی محفوظ).
            $txHashQuery = $txHash;
            if (preg_match('/^[0-9a-fA-F]{64}$/', $txHash)) {
                $rawHash = @hex2bin($txHash);
                if ($rawHash !== false) {
                    $txHashQuery = base64_encode($rawHash);
                }
            }
            $targetedUrls = [
                rtrim($this->providerUrl('toncenter_url', 'https://toncenter.com/api/v2/getTransactions'), '?') . $buildQuery('&limit=1&hash=' . rawurlencode($txHashQuery)),
                rtrim($this->providerUrl('toncenter_fallback_url', 'https://testnet.toncenter.com/api/v2/getTransactions'), '?') . $buildQuery('&limit=1&hash=' . rawurlencode($txHashQuery)),
            ];

            $foundTx = null;
            $reachedApi = false;
            foreach ([$targetedUrls, $urls] as $attemptUrls) {
                $response = $this->executeWithRetry($attemptUrls);
                if (!$response) {
                    continue;
                }
                $data = json_decode((string)$response, true);
                if (!is_array($data) || ($data['ok'] ?? false) !== true || !isset($data['result']) || !is_array($data['result'])) {
                    $reachedApi = true;
                    continue;
                }
                $reachedApi = true;
                foreach ($data['result'] as $tx) {
                    if (!is_array($tx) || !isset($tx['transaction_id']) || !is_array($tx['transaction_id'])) {
                        continue;
                    }
                    $hash = $tx['transaction_id']['hash'] ?? '';
                    if (is_string($hash) && (strtolower($hash) === strtolower($txHash) || base64_encode(hex2bin($hash) ?: '') === $txHash)) {
                        $foundTx = $tx;
                        break;
                    }
                }
                if ($foundTx !== null) {
                    break;
                }
            }

            if (!$reachedApi) {
                return ['status' => 'error', 'reason' => 'خطا در اتصال به Toncenter API'];
            }
            if (!isset($data) || !is_array($data) || ($data['ok'] ?? false) !== true || !isset($data['result']) || !is_array($data['result'])) {
                return ['status' => 'error', 'reason' => 'پاسخ نامعتبر از API TON'];
            }

            if (!$foundTx) {
                return ['status' => 'pending', 'reason' => 'تراکنش یافت نشد یا هنوز تأیید نشده است'];
            }

            $inMsg = $foundTx['in_msg'] ?? null;
            if (!is_array($inMsg)) {
                return ['status' => 'error', 'reason' => 'اطلاعات ورودی تراکنش TON ناقص است'];
            }
            // FIX-R36-W1 (F-A19d-01): برای USDT-TON باید بدنهٔ jetton-transfer پارس شود؛
            // in_msg.value فقط گس/فوروارد-فیِ nanoTON است و هرگز مبلغ USDT نیست.
            $msgData = $inMsg['msg_data'] ?? null;
            $bodyHex = is_array($msgData) ? ($msgData['body'] ?? null) : null;
            if (!is_string($bodyHex) || trim($bodyHex) === '') {
                return ['status' => 'mismatch', 'reason' => 'انتقال یافت‌شده یک انتقال جتون USDT نیست (بدنهٔ پیام موجود نیست)'];
            }
            $parsed = $this->tonParseJettonTransferNotification($bodyHex);
            if ($parsed === null) {
                return ['status' => 'mismatch', 'reason' => 'انتقال یافت‌شده یک انتقال جتون USDT (transfer_notification 0x7362d09c) نیست'];
            }

            // مالکیت جتون: jetton-wallet فرستنده باید از قرارداد مادرِ کانفیگ‌شده مشتق شود
            $master = $this->appSettings->get('crypto_contract_ton_usdt', 'EQCxE6mUtQJKFnGfaROTKOt1lZbDiiX1kCix5v7PVkyfkMqN');
            if (!is_string($master) || $master === '') {
                return ['status' => 'error', 'reason' => 'تنظیمات قرارداد USDT روی TON ناقص است (crypto_contract_ton_usdt)'];
            }
            $chainFromWcHash = $this->tonAddressToWcHash(is_string($inMsg['source'] ?? null) ? (string)$inMsg['source'] : '');
            if ($chainFromWcHash === null) {
                return ['status' => 'error', 'reason' => 'آدرس مبدا برای تطبیق در پاسخ TON موجود نیست'];
            }
            if (trim($fromWallet) !== '') {
                $declaredWcHash = $this->tonAddressToWcHash($fromWallet);
                if ($declaredWcHash === null) {
                    return ['status' => 'error', 'reason' => 'آدرس مبدا ثبت‌شده برای TON قابل تفسیر نیست'];
                }
                if ($declaredWcHash['wc'] !== $parsed['sender_wc'] || strtolower($declaredWcHash['hash']) !== $parsed['sender_hash']) {
                    return ['status' => 'mismatch', 'reason' => 'آدرس مبدا تراکنش با آدرس ثبت‌شده مطابقت ندارد'];
                }
            }
            $expectedJettonWallet = $this->tonResolveJettonWalletAddress($master, $parsed['sender_wc'], $parsed['sender_hash']);
            if ($expectedJettonWallet === null) {
                return ['status' => 'error', 'reason' => 'بررسی قرارداد جتون USDT-TON ناموفق بود (fail-closed)'];
            }
            if ($expectedJettonWallet['wc'] !== $chainFromWcHash['wc'] || strtolower($expectedJettonWallet['hash']) !== strtolower($chainFromWcHash['hash'])) {
                return ['status' => 'mismatch', 'reason' => 'توکن ارسالی USDT (TON) نیست'];
            }
            
            $expectedRaw = \Core\ValueObjects\Money::fromString((string)$expectedAmount)->multiply('1000000')->getAmount();
            $toleranceRaw = \Core\ValueObjects\Money::fromString((string)('0.01'))->multiply((string)('1000000'))->getAmount();
            
            $diff = \Core\ValueObjects\Money::fromString((string)$parsed['amount'])->subtract(\Core\ValueObjects\Money::fromString((string)($expectedRaw)))->getAmount();
            // 🛡️ FIX-CH02: tolerance یک‌طرفه — کم‌پرداختی (علامت منفی) mismatch قطعی است.
            if (str_starts_with($diff, '-')) {
                return ['status' => 'mismatch', 'reason' => 'مبلغ تراکنش مطابقت ندارد'];
            }
            if (\Core\ValueObjects\Money::fromString((string)($diff))->isGreaterThan(\Core\ValueObjects\Money::fromString((string)($toleranceRaw)))) {
                return ['status' => 'mismatch', 'reason' => 'مبلغ تراکنش مطابقت ندارد'];
            }

            // FIX-R36-W3 (F-A19d-11): گیت تأییدِ تنظیم‌پذیر — پاسخ getTransactions
            // confirmations صریح ندارد؛ معادل عملی: سنِ tx ≥ N×~5s (زمان بلاک
            // مسترچین TON). پیش‌فرض 0 = گیت خاموش (سازگار با وریفایر زنده/قرارداد
            // HTTP — گیت opt-in است). پیشنهاد پیکربندی production: ۲-۳. حلقهٔ کرون
            // crypto_verify هر دقیقه pendingها را دوباره وریفای می‌کند، پس گیتِ فعال
            // فقط 'pending' موقت می‌سازد، نه ردِ واریز.
            // FIX-C101/C103 (یافته‌های ۱۰۱/۱۰۳): مقدار تنظیمی TON هم از نقشهٔ کانونیک خوانده و
            // به بازهٔ [0، 200] محدود می‌شود (0 = گیت خاموش، رفتار عمدی opt-in حفظ می‌شود).
            $tonConfRaw = $this->appSettings->get(
                \App\Constants\CryptoConstants::CONFIRMATION_SETTING_KEYS['ton'],
                \App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_TON
            );
            $minConfirmations = \App\Constants\CryptoConstants::resolveMinConfirmations(
                'ton',
                is_numeric($tonConfRaw) ? (int)$tonConfRaw : null
            );
            $txUtime = isset($foundTx['utime']) && is_numeric($foundTx['utime']) ? (int)$foundTx['utime'] : 0;
            if ($minConfirmations > 0 && $txUtime > 0 && (time() - $txUtime) < ($minConfirmations * 5)) {
                return ['status' => 'pending', 'reason' => 'تاییدهای TON هنوز کافی نیست (crypto_min_confirmations_ton=' . $minConfirmations . ')'];
            }

            return ['status' => 'verified', 'details' => $foundTx];
        } catch (\Exception $e) {
            $this->logger->error('crypto.verify.ton.failed', [
                'tx_hash' => $txHash,
                'error' => $e->getMessage()
            ]);
            return ['status' => 'error', 'reason' => 'خطا در بررسی تراکنش TON'];
        }
    }

    // ─── FIX-R36-W1 (F-A19d-01): هلپرهای وریفایر جتون TON ─────────────

    /** تبدیل آدرس TON (user-friendly base64 یا wc:hex) به {wc, hash-hex} */
    /** @return array{wc: int, hash: string}|null */
    private function tonAddressToWcHash(string $address): ?array
    {
        $address = trim($address);
        if ($address === '') {
            return null;
        }
        if (preg_match('/^(-?\d+):([0-9a-fA-F]{64})$/', $address, $m) === 1) {
            return ['wc' => (int)$m[1], 'hash' => strtolower($m[2])];
        }
        if (preg_match('/^(?:EQ|UQ|0Q)[A-Za-z0-9_\-]{46}={0,2}$/', $address) === 1) {
            $raw = base64_decode(strtr(substr($address, 0, 48), '-_', '+/'), true);
            if ($raw === false || strlen($raw) !== 36) {
                return null;
            }
            // FIX-P3-ADP-047: بایت tag باید استاندارد باشد (0x11 bounceable /
            // 0x51 non-bounceable / 0x91 testnet) — آدرس‌های tag ساختگی رد می‌شوند.
            if (!in_array(ord($raw[0]), [0x11, 0x51, 0x91], true)) {
                return null;
            }
            // FIX-P3-ADP-047: CRC16-XMODEM روی ۳۴ بایت اول باید با ۲ بایت آخر بخواند —
            // آدرس corrupt/ساختگی با CRC نامعتبر هرگز پذیرفته نمی‌شود (fail-closed).
            if (substr($raw, 34, 2) !== self::crc16Xmodem(substr($raw, 0, 34))) {
                return null;
            }
            $wc = ord($raw[1]);
            if ($wc >= 128) {
                $wc -= 256;
            }
            return ['wc' => $wc, 'hash' => bin2hex(substr($raw, 2, 32))];
        }
        return null;
    }

    /**
     * FIX-P3-ADP-047: CRC16-XMODEM (poly 0x1021, init 0x0000) — چک‌سام آدرس‌های TON.
     * ورودی: بایت‌های payload؛ خروجی: ۲ بایت CRC به‌صورت رشتهٔ باینری.
     */
    private static function crc16Xmodem(string $bytes): string
    {
        $crc = 0;
        $len = strlen($bytes);
        for ($i = 0; $i < $len; $i++) {
            $crc ^= ord($bytes[$i]) << 8;
            for ($j = 0; $j < 8; $j++) {
                $crc = ($crc & 0x8000) ? (($crc << 1) ^ 0x1021) & 0xFFFF : ($crc << 1) & 0xFFFF;
            }
        }
        return pack('n', $crc);
    }

    /**
     * پارس بدنهٔ transfer_notification جتون (TEP-74):
     * op(32)=0x7362d09c، query_id(64)، amount(VarUInteger16)، sender(MsgAddressInt)،
     * forward_payload(نادیده). خروجی: amount دهدهی (واحد جتون) + sender {wc,hash}.
     * هر ساختار ناقص/ناخوانا = null (fail-closed).
     */
    /** @return array{amount: string, sender_wc: int, sender_hash: string}|null */
    private function tonParseJettonTransferNotification(string $bodyHex): ?array
    {
        $bodyHex = strtolower(preg_replace('/^0x/', '', trim($bodyHex)) ?? '');
        if (strlen($bodyHex) < 24 || substr($bodyHex, 0, 8) !== '7362d09c') {
            return null;
        }
        $bytes = @pack('H*', $bodyHex);
        if (!is_string($bytes)) {
            return null;
        }
        $totalBits = strlen($bytes) * 8;
        $pos = 0;
        $read = static function (int $n) use (&$pos, $bytes, $totalBits): ?string {
            if ($n <= 0 || $pos + $n > $totalBits) {
                return null;
            }
            $out = '';
            for ($i = 0; $i < $n; $i++) {
                $p = $pos + $i;
                $out .= ((ord($bytes[$p >> 3]) >> (7 - ($p & 7))) & 1) ? '1' : '0';
            }
            $pos += $n;
            return $out;
        };
        $read(32); // op — بالاتر چک شد
        if ($read(64) === null) { // query_id
            return null;
        }
        $lenNibble = $read(4);
        if ($lenNibble === null) {
            return null;
        }
        $lenBytes = (int)bindec($lenNibble);
        $amountBits = $read($lenBytes * 8);
        if ($amountBits === null) {
            return null;
        }
        $amount = $this->tonBitsToDec($amountBits);
        if ($read(2) !== '10') { // MsgAddressInt tag
            return null;
        }
        if ($read(1) !== '0') { // anycast پشتیبانی نمی‌شود
            return null;
        }
        $wcBits = $read(8);
        $hashBits = $read(256);
        if ($wcBits === null || $hashBits === null) {
            return null;
        }
        $wc = (int)bindec($wcBits);
        if ($wc >= 128) {
            $wc -= 256;
        }
        return ['amount' => $amount, 'sender_wc' => $wc, 'sender_hash' => $this->tonBitsToHex($hashBits)];
    }

    private function tonBitsToHex(string $bits): string
    {
        $pad = strlen($bits) % 4;
        if ($pad !== 0) {
            $bits .= str_repeat('0', 4 - $pad);
        }
        $hex = '';
        foreach (str_split($bits, 4) as $nibble) {
            $hex .= dechex((int)bindec($nibble));
        }
        return $hex;
    }

    private function tonBitsToDec(string $bits): string
    {
        return self::tonHexToDec($this->tonBitsToHex($bits));
    }

    private static function tonHexToDec(string $hex): string
    {
        $hex = ltrim($hex, '0');
        if ($hex === '') {
            return '0';
        }
        $dec = '0';
        foreach (str_split($hex) as $ch) {
            $dec = bcadd(bcmul($dec, '16'), (string)hexdec($ch));
        }
        return $dec;
    }

    /**
     * resolve کردن jetton-wallet مالک از قرارداد مادر (get_wallet_address با
     * runGetMethod) — اثبات اینکه انتقال از jetton-wallet واقعیِ USDTِ
     * کانفیگ‌شده بوده (ضد جتون جعلی). هر شکست = null (fail-closed).
     */
    /** @return array{wc: int, hash: string}|null */
    private function tonResolveJettonWalletAddress(string $master, int $ownerWc, string $ownerHash): ?array
    {
        if ($this->tonAddressToWcHash($master) === null) {
            return null;
        }
        // آدرس به‌عنوان int دو-مکمل: (wc × 2^256) + hash
        $ownerInt = bcadd(bcmul((string)$ownerWc, bcpow('2', '256', 0)), self::tonHexToDec($ownerHash));
        $query = '';
        $apiKeyValue = $this->appSettings->get('toncenter_api_key', '');
        if (is_string($apiKeyValue) && $apiKeyValue !== '') {
            $query = '?api_key=' . rawurlencode($apiKeyValue);
        }
        $urls = [
            rtrim($this->providerUrl('toncenter_run_url', 'https://toncenter.com/api/v2/runGetMethod'), '?') . $query,
            rtrim($this->providerUrl('toncenter_fallback_run_url', 'https://testnet.toncenter.com/api/v2/runGetMethod'), '?') . $query,
        ];
        $response = $this->executeWithRetry($urls, [
            'address' => $master,
            'method'  => 'get_wallet_address',
            'stack'   => [[[ 'type' => 'int', 'value' => $ownerInt ]]],
        ]);
        if (!is_string($response) || $response === '') {
            return null;
        }
        $data = json_decode($response, true);
        if (!is_array($data) || ($data['ok'] ?? false) !== true || !is_array($data['result'] ?? null)) {
            return null;
        }
        if ((int)($data['result']['exit_code'] ?? -1) !== 0) {
            return null;
        }
        $stack = $data['result']['stack'] ?? null;
        if (!is_array($stack) || !isset($stack[0]) || !is_array($stack[0])) {
            return null;
        }
        $cell = $stack[0][1] ?? null;
        $bytesHex = is_array($cell) ? ($cell['bytes'] ?? null) : null;
        if (!is_string($bytesHex) || $bytesHex === '') {
            return null;
        }
        $sliceBytes = @pack('H*', strtolower($bytesHex));
        if (!is_string($sliceBytes) || strlen($sliceBytes) < 34) {
            return null;
        }
        $bits = '';
        foreach (str_split($sliceBytes) as $b) {
            $bits .= str_pad(decbin(ord($b)), 8, '0', STR_PAD_LEFT);
        }
        // ساختار slice آدرس: tag(2)='10'، anycast(1)=0، wc(8)، hash(256)
        if (substr($bits, 0, 2) !== '10' || substr($bits, 2, 1) !== '0') {
            return null;
        }
        $wc = (int)bindec(substr($bits, 3, 8));
        if ($wc >= 128) {
            $wc -= 256;
        }
        return ['wc' => $wc, 'hash' => $this->tonBitsToHex(substr($bits, 11, 256))];
    }

    /**
     * Verify Solana transaction (M-03)
     */
    /** @return array<string, mixed> */
    private function verifySolanaTransaction(string $txHash, string $fromWallet, string $toWallet, string $expectedAmount): array
    {
        try {
            $rpcValue = $this->appSettings->get('solana_rpc_url', 'https://api.mainnet-beta.solana.com');
            $rpcUrl = is_string($rpcValue) ? $rpcValue : 'https://api.mainnet-beta.solana.com';
            if (!$this->isExternalUrlSafe($rpcUrl)) {
                $this->logger->warning('crypto.solana.ssrf_blocked', ['host' => parse_url($rpcUrl, PHP_URL_HOST)]);
                return ['status' => 'error', 'reason' => 'آدرس RPC سولانا از نظر امنیتی مجاز نیست'];
            }
            // FIX-R36-W3 (F-A19d-11): گیت تأییدِ تنظیم‌پذیر (crypto_min_confirmations_sol،
            // پیش‌فرض ۳۲ = 'finalized' — دقیقاً هم‌ترازِ تکیهٔ قبلی بر commitment پیش‌فرضِ
            // RPC، اما اکنون صریح و قابل‌اجرا؛ مقدار <۳۲ = commitment 'confirmed').
            // getTransaction در آن سطحِ commitment هنوز نرسیده باشد null می‌دهد →
            // 'pending' موقت؛ حلقهٔ کرون crypto_verify هر دقیقه pendingها را دوباره
            // وریفای می‌کند. درخواست اضافه‌ای زده نمی‌شود.
            $solMinValue = $this->appSettings->get(
                \App\Constants\CryptoConstants::CONFIRMATION_SETTING_KEYS['sol'],
                \App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_SOL
            );
            // FIX-C103: منبع واحد + حفظ سقف ۳۲ (بالاتر از finalized معنا ندارد)
            $solMinConf = is_numeric($solMinValue)
                ? max(1, min(\App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_SOL, (int)$solMinValue))
                : \App\Constants\CryptoConstants::DEFAULT_MIN_CONFIRMATIONS_SOL;
            $solCommitment = $solMinConf >= 32 ? 'finalized' : 'confirmed';
            $data = $this->executeJsonRpc($rpcUrl, 'getTransaction', [
                $txHash,
                ['encoding' => 'jsonParsed', 'commitment' => $solCommitment, 'maxSupportedTransactionVersion' => 0],
            ]);
            if (!is_array($data)) {
                return ['status' => 'error', 'reason' => 'پاسخ RPC سولانا نامعتبر یا سرویس غیرقابل دسترس است'];
            }
            $result = $data['result'] ?? null;
            if ($result === null) {
                return ['status' => 'pending', 'reason' => 'تراکنش در شبکه سولانا یافت نشد یا هنوز به سطح تأییدِ لازم (' . $solCommitment . ') نرسیده است'];
            }
            if (!is_array($result) || !isset($result['meta']) || !is_array($result['meta'])) {
                return ['status' => 'error', 'reason' => 'اطلاعات تراکنش سولانا ناقص است'];
            }

            $meta = $result['meta'];
            if (isset($meta['err']) && $meta['err'] !== null) {
                return ['status' => 'mismatch', 'reason' => 'تراکنش ناموفق در شبکه سولانا'];
            }

            if (trim($fromWallet) !== '') {
                $message = $result['transaction']['message'] ?? null;
                $accountKeys = is_array($message) ? ($message['accountKeys'] ?? null) : null;
                $chainFrom = '';
                if (is_array($accountKeys)) {
                    foreach ($accountKeys as $account) {
                        if (is_array($account) && ($account['signer'] ?? false) === true && isset($account['pubkey']) && is_string($account['pubkey'])) {
                            $chainFrom = $account['pubkey'];
                            break;
                        }
                    }
                }
                if ($chainFrom === '') {
                    return ['status' => 'error', 'reason' => 'آدرس امضاکننده برای تطبیق در پاسخ سولانا موجود نیست'];
                }
                if ($chainFrom !== $fromWallet) {
                    // Solana swaps and multisig transfers may use a signer that
                    // differs from the token-account owner. This is not enough
                    // evidence for an automatic rejection.
                    return ['status' => 'error', 'reason' => 'امضاکننده سولانا با آدرس ثبت‌شده متفاوت است؛ بررسی دستی لازم است'];
                }
            }

            $postBalances = $meta['postTokenBalances'] ?? [];
            $preBalances = $meta['preTokenBalances'] ?? [];
            if (!is_array($postBalances) || !is_array($preBalances)) {
                return ['status' => 'error', 'reason' => 'اطلاعات موجودی توکن سولانا ناقص است'];
            }

            $usdtMint = 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB';
            $receivedRaw = '0';
            $decimals = 6;
            foreach ($postBalances as $post) {
                // FIX-S33-R13: مقایسهٔ owner به‌صورت case-sensitive (Base58 حرف‌حساس است)
                if (!is_array($post) || ($post['mint'] ?? '') !== $usdtMint || (string)($post['owner'] ?? '') !== (string)$toWallet) continue;
                $postInfo = $post['uiTokenAmount'] ?? null;
                $postRaw = is_array($postInfo) ? ($postInfo['amount'] ?? null) : null;
                $postDecimals = is_array($postInfo) ? ($postInfo['decimals'] ?? 6) : 6;
                if (!(is_string($postRaw) && ctype_digit($postRaw)) || (!is_int($postDecimals) && !(is_string($postDecimals) && ctype_digit($postDecimals)))) {
                    return ['status' => 'error', 'reason' => 'موجودی خام USDT در پاسخ سولانا نامعتبر است'];
                }
                $decimals = (int)$postDecimals;
                $preRaw = '0';
                foreach ($preBalances as $pre) {
                    if (is_array($pre) && ($pre['accountIndex'] ?? null) === ($post['accountIndex'] ?? null) && ($pre['mint'] ?? '') === $usdtMint) {
                        $info = $pre['uiTokenAmount'] ?? null;
                        $candidate = is_array($info) ? ($info['amount'] ?? '0') : '0';
                        if (is_string($candidate) && ctype_digit($candidate)) $preRaw = $candidate;
                        break;
                    }
                }
                $delta = bcsub($postRaw, $preRaw, 0);
                // FIX-S33-R12 (گزارش بخش ۱۳): جمع «خالصِ» همهٔ دلتاها — شمارشِ فقط-مثبتِ
                // قبلی، انتقال داخلی بین دو token accountِ هم‌مالک (+X/−X) را «دریافت X»
                // می‌گرفت (from_wallet اختیاری است و گاردی وجود نداشت). اکنون جفت‌های
                // داخلی خنثی می‌شوند؛ دریافتِ خارجیِ واقعی همچنان خالصِ مثبت می‌دهد.
                $receivedRaw = bcadd($receivedRaw, $delta, 0);
            }

            if (bccomp($receivedRaw, '0', 0) !== 1) {
                return ['status' => 'mismatch', 'reason' => 'افزایش موجودی USDT برای آدرس گیرنده یافت نشد'];
            }

            $expectedRaw = bcmul((string)$expectedAmount, bcpow('10', (string)$decimals, 0), 0);
            $toleranceRaw = bcmul('0.01', bcpow('10', (string)$decimals, 0), 0);
            $diff = bcsub($receivedRaw, $expectedRaw, 0);
            // 🛡️ FIX-CH02: tolerance یک‌طرفه — کم‌پرداختی (علامت منفی) mismatch قطعی است.
            if (str_starts_with($diff, '-')) {
                return ['status' => 'mismatch', 'reason' => 'مبلغ تراکنش سولانا مطابقت ندارد'];
            }
            if (bccomp($diff, $toleranceRaw, 0) === 1) {
                return ['status' => 'mismatch', 'reason' => 'مبلغ تراکنش سولانا مطابقت ندارد'];
            }

            return ['status' => 'verified', 'details' => $result];
        } catch (\Exception $e) {
            $this->logger->error('crypto.verify.solana.failed', [
                'tx_hash' => $txHash,
                'error' => $e->getMessage()
            ]);
            return ['status' => 'error', 'reason' => 'خطا در بررسی تراکنش Solana'];
        }
    }
}
