<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use App\Models\Ads;
use App\Contracts\WalletServiceInterface;
use App\Services\Shared\IdempotencyService;
use Core\Database;
use App\Services\Settings\AppSettings;

/**
 * BannerAdapter - creates Banner ad records only.
 * Financial hold/withdraw is handled centrally by AdSystemManager / Saga.
 */
class BannerAdapter extends AdapterBase implements AdSystemContract
{
    public function __construct(
        private Ads $adModel,
        private WalletServiceInterface $walletService,
        private Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory,
        private IdempotencyService $idempotencyService,
        private \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlementService
    ) {
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string
    {
        return 'banner';
    }

    public function create(int $userId, array $data): array
    {
        $data = $this->normalize($data);
        $valid = $this->validate($data, false);
        if (!$valid['valid']) {
            return $this->errorResponse('ورودی‌های بنر معتبر نیستند', $valid['errors']);
        }

        try {
            $adId = $this->adModel->create([
                'user_id'                 => $userId,
                'type'                    => 'banner',
                'title'                   => $data['title'],
                'description'             => $data['description'] ?: null,
                'link'                    => $data['link'],
                'target_url'              => $data['link'],
                'image_path'              => $data['image_path'] ?? null,
                'placement'               => $data['placement'],
                'price_per_task'          => 0,
                'currency'                => $data['currency'],
                'total_budget'            => $data['total_budget'],
                'remaining_budget'        => $data['total_budget'],
                'total_count'             => 0,
                'remaining_count'         => 0,
                'pending_count'           => 0,
                'completed_count'         => 0,
                'site_commission_percent' => $data['site_commission_percent'],
                'status'                  => $data['requires_admin_review'] ? 'pending_review' : 'active',
                'restrictions'            => json_encode([
                    'is_startup' => $data['is_startup'],
                    'target_devices' => $data['target_devices'],
                    'dimensions' => $this->inferDimensions($data['placement']),
                ], JSON_UNESCAPED_UNICODE),
                'created_by'              => $userId,
                'created_at'              => date('Y-m-d H:i:s'),
                'updated_at'              => date('Y-m-d H:i:s'),
            ]);

            if (!$adId) {
                return $this->errorResponse('خطا در نهایی‌سازی تبلیغ بنری.');
            }
            $id = is_object($adId) ? (int)$adId->id : (int)$adId;

            return $this->successResponse('تبلیغ بنری با موفقیت ثبت شد.', ['id' => $id, 'ad_id' => $id]);
        } catch (\Throwable $e) {
            $this->logError('banner_creation_fail', $e->getMessage());
            return $this->errorResponse('سیستم در حال حاضر امکان ثبت بنر ندارد: ' . $e->getMessage());
        }
    }

    public function validate(array $data, bool $isUpdate = false): array
    {
        $data = $this->normalize($data);
        $errors = [];

        if (mb_strlen($data['title']) < 3) {
            $errors[] = 'عنوان تبلیغ الزامی است.';
        }
        if ($data['placement'] === '') {
            $errors[] = 'انتخاب جایگاه تبلیغ الزامی است.';
        }
        if (!$isUpdate && empty($data['image_path'])) {
            $errors[] = 'فایل تصویر بنر الزامی است.';
        }
        if (!filter_var($data['link'], FILTER_VALIDATE_URL)) {
            $errors[] = 'لینک مقصد معتبر نیست.';
        }
        $minBudget = (float)$this->appSettings->get('banner_min_budget', 100);
        if ($data['total_budget'] < $minBudget) {
            $errors[] = "حداقل بودجه بنر {$minBudget} تومان است.";
        }

        return ['valid' => empty($errors), 'errors' => $errors];
    }

    public function isExpired(int $adId): bool
    {
        $ad = $this->adModel->find($adId);
        return !$ad || in_array($ad->status, ['expired', 'completed'], true) || (float)($ad->remaining_budget ?? 0) <= 0;
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        $placement = $context['placement'] ?? 'general';
        $isStartup = filter_var($context['is_startup'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $feePercent = $this->calculateDynamicFeePercent($placement, $isStartup);
        return (string)round(((float)$amount) * ($feePercent / 100), 8);
    }

    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        return $this->successResponse('پرداخت با بودجه اولیه و escrow مرکزی مدیریت می‌شود.');
    }

    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        $finance = $this->adsBudgetSettlementService;
        $result = $finance->consumeDeliveryBudget($adId, 'banner', $eventType === 'click' ? 'click' : 'impression', 1, $userId, [
            'source' => 'banner_adapter.track',
        ]);
        return !empty($result['success'])
            ? $this->successResponse('آمار و مصرف بودجه بنر با موفقیت ثبت شد.', $result)
            : $this->errorResponse($result['message'] ?? 'ثبت آمار بنر انجام نشد.');
    }

    public function getStatus(int $adId): ?array
    {
        $banner = $this->adModel->find($adId);
        if (!$banner) return null;
        return [
            'id' => $banner->id,
            'type' => 'banner',
            'status' => $banner->status,
            'budget_left' => $banner->remaining_budget
        ];
    }

    private function normalize(array $data): array
    {
        $currency = strtolower((string)($data['currency'] ?? 'irt'));
        if (in_array($currency, ['irr', 'rial'], true)) $currency = 'irt';
        if (!in_array($currency, ['irt', 'usdt'], true)) $currency = 'irt';

        $placement = trim((string)($data['placement'] ?? 'general'));
        $isStartup = filter_var($data['is_startup'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $budget = (float)($data['budget'] ?? $data['total_budget'] ?? 0);
        $feePercent = $this->calculateDynamicFeePercent($placement, $isStartup);

        $targetDevices = $data['target_devices'] ?? ['web', 'mobile'];
        if (is_string($targetDevices)) {
            $targetDevices = (array)(json_decode($targetDevices, true) ?? []) ?: ['web', 'mobile'];
        }
        if (!is_array($targetDevices)) $targetDevices = ['web', 'mobile'];

        return [
            'title' => trim((string)($data['title'] ?? '')),
            'description' => trim((string)($data['description'] ?? '')),
            'link' => trim((string)($data['link'] ?? $data['target_url'] ?? '')),
            'image_path' => trim((string)($data['image_path'] ?? '')),
            'placement' => $placement,
            'is_startup' => $isStartup,
            'target_devices' => $targetDevices,
            'total_budget' => $budget,
            'currency' => $currency,
            'site_commission_percent' => $feePercent,
            'requires_admin_review' => (bool)$this->appSettings->get('banner_requires_admin_review', 1),
        ];
    }

    private function calculateDynamicFeePercent(string $placement, bool $isStartup): float
    {
        $standardFee = (float) $this->appSettings->get('banner_fee_percent', 12.0);
        if ($placement === 'homepage_slider' && $isStartup) {
            return (float) $this->appSettings->get('banner_startup_slider_fee_percent', 2.0);
        }
        return $standardFee;
    }

    private function inferDimensions(string $placement): array
    {
        return match($placement) {
            'homepage_slider' => ['width' => 1920, 'height' => 600],
            'sidebar'        => ['width' => 300, 'height' => 600],
            'footer'         => ['width' => 728, 'height' => 90],
            default          => ['width' => 800, 'height' => 400],
        };
    }
}
