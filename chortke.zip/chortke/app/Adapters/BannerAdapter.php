<?php

declare(strict_types=1);

namespace App\Adapters;

use Core\ValueObjects\Money;
use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use App\Models\Ads;
use App\Contracts\WalletServiceInterface;
use App\Services\Shared\IdempotencyService;
use Core\Database;
use App\Services\Settings\AppSettings;

/**
 * BannerAdapter - creates Banner ad records only.
 * Financial hold/withdraw is handled centrally by AdSystemManager / Saga.
 */
class BannerAdapter extends AdapterBase implements AdSystemContract
{
    public function __construct(
        private Ads $adModel,
        WalletServiceInterface $walletService,
        Database $db,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory,
        IdempotencyService $idempotencyService,
        \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlementService
    ) {
        // Kept for constructor compatibility; settlement is centralized in
        // AdSystemManager and these legacy dependencies are intentionally not retained.
        unset($walletService, $db, $idempotencyService, $adsBudgetSettlementService);
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string
    {
        return 'banner';
    }

    public function create(int $userId, array $data): array
    {
        try {
            // FIX-P3-ADP-039: normalize/validate داخل try — InvalidArgumentExceptionِ
            // parseBoolean/normalizeTargetDevices دیگر از create() بیرون نمی‌زند و به
            // پاسخ خطای دامنهٔ استاندارد نقشه می‌خورد.
            // FIX-P3-ADP-040 (قرارداد تک‌گذر): دیتای نرمال‌شده از validate() گرفته می‌شود.
            $validation = $this->validate($data, false);
            if (!$validation['valid']) {
                return $this->errorResponse('ورودی‌های بنر معتبر نیستند', $validation['errors']);
            }
            $data = $validation['data'];
            $adId = $this->adModel->create([
                'user_id'                 => $userId,
                'type'                    => 'banner',
                'title'                   => $data['title'],
                'description'             => $data['description'] ?: null,
                'link'                    => $data['link'],
                'target_url'              => $data['link'],
                'image_path'              => $data['image_path'] ?? null,
                'placement'               => $data['placement'],
                'price_per_task'          => 0,
                'currency'                => $data['currency'],
                'total_budget'            => $data['total_budget'],
                'remaining_budget'        => $data['total_budget'],
                'total_count'             => 0,
                'remaining_count'         => 0,
                'pending_count'           => 0,
                'completed_count'         => 0,
                'site_commission_percent' => $data['site_commission_percent'],
                'status'                  => $data['requires_admin_review'] ? 'pending_review' : 'active',
                'restrictions'            => json_encode([
                    'is_startup' => $data['is_startup'],
                    'target_devices' => $data['target_devices'],
                    'dimensions' => $this->inferDimensions($data['placement']),
                ], JSON_UNESCAPED_UNICODE),
                'created_by'              => $userId,
                'created_at'              => date('Y-m-d H:i:s'),
                'updated_at'              => date('Y-m-d H:i:s'),
            ]);

            if (!$adId) {
                return $this->errorResponse('خطا در نهایی‌سازی تبلیغ بنری.');
            }
            $id = 0;
            if (is_object($adId)) {
                $vars = get_object_vars($adId);
                $id = is_numeric($vars['id'] ?? null) ? (int)$vars['id'] : 0;
            } elseif (is_numeric($adId)) {
                $id = (int)$adId;
            }
            // FIX-P3-ADP-040: id<=0 (از جمله شکل true مدل = insert بدون ID) دیگر
            // «موفقیت با شناسهٔ صفر» نیست — هم‌الگوی AdTubeAdapter رد صادقانه است
            // (قرارداد ساگا در AdSystemManager شناسهٔ int را الزامی می‌کند).
            if ($id <= 0) {
                $this->logError('create_id_unavailable', 'ads insert succeeded without a retrievable id', ['user_id' => $userId]);
                return $this->errorResponse('خطا در نهایی‌سازی تبلیغ بنری.');
            }

            return $this->successResponse('تبلیغ بنری با موفقیت ثبت شد.', ['id' => $id, 'ad_id' => $id]);
        } catch (\InvalidArgumentException $e) {
            // FIX-P3-ADP-039: خطای اعتبارسنجی ورودی = پاسخ دامنهٔ استاندارد، نه استثنای خام.
            $this->logError('banner_input_invalid', $e->getMessage(), ['user_id' => $userId]);
            return $this->errorResponse('ورودی‌های بنر معتبر نیستند.');
        } catch (\Throwable $e) {
            $this->logError('banner_creation_fail', $e->getMessage());
            // FIX-P3-ADP-039: متن خام exception به پاسخ کاربر الصاق نمی‌شود؛ جزئیات فقط در لاگ.
            return $this->errorResponse('سیستم در حال حاضر امکان ثبت بنر ندارد.');
        }
    }

    /**
     * قرارداد validate (FIX-P3-ADP-024/067): خروجی همیشه ['valid'=>bool,'errors'=>list,'data'=>array].
     * خرابی normalize (parseBoolean/normalizeTargetDevices/Money) = valid=false عمومی، نه استثنا.
     */
    public function validate(array $data, bool $isUpdate = false): array
    {
        try {
            $data = $this->normalize($data);
        } catch (\InvalidArgumentException $e) {
            $this->logger->warning("adapter.{$this->getType()}.validate_normalize_failed", ['error' => self::sanitizeLogText($e->getMessage())]);
            return ['valid' => false, 'errors' => ['ورودی ارسالی معتبر نیست.'], 'data' => []];
        }
        $errors = $this->validateNormalized($data, $isUpdate);
        return ['valid' => empty($errors), 'errors' => $errors, 'data' => $data];
    }

    /** @return list<string> */
    private function validateNormalized(array $data, bool $isUpdate = false): array
    {
        $errors = [];

        if (mb_strlen($data['title']) < 3) {
            $errors[] = 'عنوان تبلیغ الزامی است.';
        }
        if ($data['placement'] === '') {
            $errors[] = 'انتخاب جایگاه تبلیغ الزامی است.';
        }
        if (!$isUpdate && empty($data['image_path'])) {
            $errors[] = 'فایل تصویر بنر الزامی است.';
        }
        // FIX-P3-ADP-036: مسیر تصویر باید مرجع نسبی امن داخل ریشهٔ storage باشد —
        // بدون traversal/absolute/scheme و فقط با پسوند تصویر مجاز.
        if (!$isUpdate && $data['image_path'] !== '' && !self::isSafeStorageImagePath($data['image_path'])) {
            $errors[] = 'مسیر تصویر بنر معتبر نیست.';
        }
        if ($data['link'] === '' || !self::isSafeHttpUrl($data['link'])) {
            // FIX-P3-ADP-037: لینک مقصد فقط http/https با هاست معتبر —
            // FILTER_VALIDATE_URL تنها scheme دلخواه (javascript:، data:) را می‌پذیرفت.
            $errors[] = 'لینک مقصد معتبر نیست.';
        }
        $minBudgetValue = $this->appSettings->get('banner_min_budget', 100);
        $minBudget = self::wellFormedDecimal($minBudgetValue) ?? '100'; // FIX-P3-ADP-041
        if (bccomp($data['total_budget'], $minBudget, 8) < 0) {
            $errors[] = "حداقل بودجه بنر {$minBudget} تومان است.";
        }

        return $errors;
    }

    /**
     * FIX-P3-ADP-036 — گارد مسیر تصویر: مرجع نسبی امن (بدون ..، بدون شروع با /،
     * بدون backslash، بدون scheme، حداکثر ۲۵۵ کاراکتر) با پسوند تصویر مجاز.
     * اعتبارسنجی MIME/حجم فایل در لایهٔ آپلود (مسیر جدا) انجام می‌شود؛ این گارد
     * ذخیرهٔ مسیر دلخواه/خروج از ریشهٔ storage در DB را مسدود می‌کند.
     */
    private static function isSafeStorageImagePath(string $path): bool
    {
        $path = trim($path);
        if ($path === '' || strlen($path) > 255) return false;
        if (str_contains($path, '..') || str_starts_with($path, '/') || str_contains($path, "\\")) return false;
        if (preg_match('/[\x00-\x1F\x7F]/', $path) === 1) return false;
        if (preg_match('/^[a-zA-Z][a-zA-Z0-9+.-]*:/', $path) === 1) return false; // scheme (http:, phar:, data:)
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        return in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true);
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function isExpired(int $adId): bool
    {
        $ad = $this->adModel->find($adId);
        if (!is_object($ad)) return true;
        $vars = get_object_vars($ad);
        $status = is_string($vars['status'] ?? null) ? $vars['status'] : '';
        $remaining = is_numeric($vars['remaining_budget'] ?? null) ? (string)$vars['remaining_budget'] : '0';
        return in_array($status, ['expired', 'completed'], true) || bccomp($remaining, '0', 8) <= 0;
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        $placementValue = $context['placement'] ?? 'general';
        $placement = is_string($placementValue) ? $placementValue : 'general';
        // FIX-P3-ADP-042: هم‌راستاسازی با normalize — پارس strict با parseBoolean؛
        // مقدار بدشکل به false می‌رود ولی با لاگ هشدار قابل‌مشاهده است (نه silent).
        try {
            $isStartup = $this->parseBoolean($context['is_startup'] ?? false, 'is_startup');
        } catch (\InvalidArgumentException $e) {
            $this->logger->warning("adapter.{$this->getType()}.cost_is_startup_invalid", ['error' => self::sanitizeLogText($e->getMessage())]);
            $isStartup = false;
        }
        $feePercent = $this->calculateDynamicFeePercent($placement, $isStartup);
        $currency = is_string($context['currency'] ?? null) ? $context['currency'] : 'irt';
        // float→decimal: محاسبهٔ کارمزد با Money/BCMath به‌جای float
        return Money::fromString($amount, $currency)->percentage($feePercent)->getAmount();
    }

    /**
     * FIX-C52 (یافتهٔ ممیزی ۵۲): قرارداد پرداخت آداپتورها یکسان شد — قبلاً بعضی
     * آداپتورها موفقیت ساختگی برمی‌گرداندند و بعضی استثنا می‌دادند. اکنون همهٔ
     * پیاده‌سازی‌های سطح قراردادِ مرده fail-loud هستند (هم‌الگوی SeoAdAdapter).
     * تسویهٔ مالی بنر فقط از مسیر متمرکز escrow/AdsBudgetSettlementService انجام می‌شود.
     * @deprecated Dead contract surface (F-A19d-03) — صفر call-site
     */
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        throw new \LogicException(
            'BannerAdapter::processPayment غیرفعال است (F-A19d-03/59): تسویهٔ مالی فقط از مسیر متمرکز escrow/AdsBudgetSettlementService انجام می‌شود.'
        );
    }

    /**
     * FIX-R36-W3 (F-A19d-03): consumeDeliveryBudget واقعی در بدنهٔ متدِ بدون call-site
     * = مسیر دومِ کسر بودجه (دبل-کسر بالقوه در کنار AdsBudgetSettlementService).
     * fail-loud برای دیده‌شدن فوری هر فراخوانی آینده.
     * @deprecated Dead contract surface (r36 audit F-A19d-03)
     */
    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        throw new \LogicException(
            'BannerAdapter::track غیرفعال است (F-A19d-03): مصرف بودجه/آمار بنر فقط از AdsBudgetSettlementService انجام می‌شود.'
        );
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function getStatus(int $adId): ?array
    {
        $banner = $this->adModel->find($adId);
        if (!$banner) return null;
        $vars = get_object_vars($banner);
        return [
            'id' => is_numeric($vars['id'] ?? null) ? (int)$vars['id'] : 0,
            'type' => 'banner',
            'status' => is_string($vars['status'] ?? null) ? $vars['status'] : 'unknown',
            'budget_left' => is_numeric($vars['remaining_budget'] ?? null) ? (float)$vars['remaining_budget'] : 0.0
        ];
    }

    /**
     * @param array<string, mixed> $data
     * @return array{
     *   title: string,
     *   description: string,
     *   link: string,
     *   image_path: string,
     *   placement: string,
     *   is_startup: bool,
     *   target_devices: list<string>,
     *   total_budget: string,
     *   currency: string,
     *   site_commission_percent: string,
     *   requires_admin_review: bool
     * }
     */
    private function normalize(array $data): array
    {
        $currencyValue = $data['currency'] ?? 'irt';
        $currency = strtolower(is_scalar($currencyValue) ? (string)$currencyValue : 'irt');
        if (in_array($currency, ['irr', 'rial'], true)) {
            // FIX-R36-W3 (F-A19d-10): برچسب‌زنی irr→irt بدون بازمقیاس ×10 — رؤیت‌پذیری
            // (تصمیم محصول برای ردّ/مقیاس در رجیستر).
            $this->logger->warning('ads.currency.irr_relabelled_irt', ['ad_type' => $this->getType(), 'received' => $currency]);
            $currency = 'irt';
        }
        if (!in_array($currency, ['irt', 'usdt'], true)) $currency = 'irt';

        $placementValue = $data['placement'] ?? 'general';
        $placement = is_scalar($placementValue) ? trim((string)$placementValue) : 'general';
        $isStartup = $this->parseBoolean($data['is_startup'] ?? false, 'is_startup');
        $budgetValue = $data['budget'] ?? $data['total_budget'] ?? 0;
        // float→decimal: بودجه به‌صورت رشتهٔ decimal
        // FIX-P3-ADP-041: بودجه فقط decimal خوش‌فرم (نماد علمی → '0' → خطای حداقل بودجه)
        $budget = self::wellFormedDecimal($budgetValue) ?? '0';
        $feePercent = $this->calculateDynamicFeePercent($placement, $isStartup);

        $targetDevices = $this->normalizeTargetDevices($data['target_devices'] ?? null);

        $linkValue = $data['link'] ?? $data['target_url'] ?? null;
        $link = is_scalar($linkValue) ? trim((string)$linkValue) : '';

        return [
            'title' => is_scalar($data['title'] ?? null) ? trim((string)$data['title']) : '',
            'description' => is_scalar($data['description'] ?? null) ? trim((string)$data['description']) : '',
            'link' => $link,
            'image_path' => is_scalar($data['image_path'] ?? null) ? trim((string)$data['image_path']) : '',
            'placement' => $placement,
            'is_startup' => $isStartup,
            'target_devices' => $targetDevices,
            'total_budget' => $budget,
            'currency' => $currency,
            'site_commission_percent' => $feePercent,
            'requires_admin_review' => $this->parseBoolean(
                $this->appSettings->get('banner_requires_admin_review', true),
                'banner_requires_admin_review'
            ),
        ];
    }

    /**
     * Parse booleans at the input/configuration boundary without silently
     * converting malformed values to false.
     */
    private function parseBoolean(mixed $value, string $field): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) && ($value === 0 || $value === 1)) {
            return $value === 1;
        }
        if (is_string($value)) {
            $normalized = strtolower(trim($value));
            if ($normalized === 'true' || $normalized === '1') return true;
            if ($normalized === 'false' || $normalized === '0') return false;
        }
        throw new \InvalidArgumentException("{$field} must be a boolean.");
    }

    /**
     * FIX-P3-ADP-038 — allowlist دستگاه‌های هدف: فقط web/mobile (مقادیر پیش‌فرض
     * محصول)، حداکثر ۴ مقدار و هر مقدار حداکثر ۲۰ کاراکتر؛ خارج از allowlist
     * خطای صریح است (نه drop خاموش و نه ذخیرهٔ مقدار دلخواه).
     */
    private const ALLOWED_TARGET_DEVICES = ['web', 'mobile'];

    /** @return list<string> */
    private function normalizeTargetDevices(mixed $value): array
    {
        if ($value === null || $value === '') {
            return ['web', 'mobile'];
        }
        if (is_string($value)) {
            $decoded = json_decode($value, true);
            if (!is_array($decoded)) {
                throw new \InvalidArgumentException('target_devices must be a JSON array.');
            }
            $value = $decoded;
        }
        if (!is_array($value)) {
            throw new \InvalidArgumentException('target_devices must be an array of strings.');
        }
        if (count($value) > 4) {
            throw new \InvalidArgumentException('target_devices allows at most 4 entries.');
        }

        $devices = [];
        foreach ($value as $device) {
            if (!is_string($device) || trim($device) === '') {
                throw new \InvalidArgumentException('target_devices must contain only non-empty strings.');
            }
            $normalized = strtolower(trim($device));
            if (mb_strlen($normalized) > 20) {
                throw new \InvalidArgumentException('target_devices entries are too long.');
            }
            if (!in_array($normalized, self::ALLOWED_TARGET_DEVICES, true)) {
                throw new \InvalidArgumentException('target_devices contains a non-allowed device.');
            }
            $devices[] = $normalized;
        }
        return array_values(array_unique($devices));
    }

    private function calculateDynamicFeePercent(string $placement, bool $isStartup): string
    {
        // FIX-P3-ADP-041: کارمزد پویا همیشه clamp‌شدهٔ [0,100] (تنظیمات منفی/>100 ممکن بود).
        $standardFee = $this->boundedFeePercent('banner_fee_percent', '12');
        if ($placement === 'homepage_slider' && $isStartup) {
            return $this->boundedFeePercent('banner_startup_slider_fee_percent', '2');
        }
        return $standardFee;
    }

    /** @return array{width: int, height: int} */
    private function inferDimensions(string $placement): array
    {
        return match($placement) {
            'homepage_slider' => ['width' => 1920, 'height' => 600],
            'sidebar'        => ['width' => 300, 'height' => 600],
            'footer'         => ['width' => 728, 'height' => 90],
            default          => ['width' => 800, 'height' => 400],
        };
    }
}
