<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Traits\ValidatesExternalUrl;

use App\Contracts\CircuitBreakerInterface;
use App\Contracts\LoggerInterface;

/**
 * JibitInquiryAdapter
 * پیاده‌سازی آداپتر استعلام اطلاعات بانکی از طریق سرویس جی‌بیت
 */
class JibitInquiryAdapter implements BankInquiryAdapter
{
    use \App\Traits\ValidatesExternalUrl;
    use \App\Traits\ExternalCallTrait;

    private ?string $apiKey;
    private ?string $apiSecret;
    private string $baseUrl = 'https://api.jibit.ir/v1/';
    private LoggerInterface $logger;
    private \App\Contracts\CacheInterface $cache;
    private CircuitBreakerInterface $circuitBreaker;

    /**
     * FIX-P3-ADP-088: کش کوتاه‌مدت access token (الگوی TOKEN_CACHE_KEY در
     * FcmNotificationAdapter) — به‌جای درخواست tokens/generate در هر استعلام.
     */
    private const TOKEN_CACHE_KEY = 'jibit:access_token';
    private const TOKEN_CACHE_TTL_MINUTES = 10;

    /** FIX-P3-ADP-085: محدودهٔ مجاز timeout (ثانیه) — هم‌الگو با VandarInquiryAdapter. */
    private const TIMEOUT_MIN = 2;
    private const TIMEOUT_MAX = 30;

    /** FIX-P3-ADP-084: کپ طول فیلدهای متنی پاسخ پروایدر (هم‌الگو با Vandar). */
    private const MAX_FIELD_LENGTH = 200;

    private int $timeout = 10;

    public function __construct(LoggerInterface $logger, \App\Contracts\CacheInterface $cache, CircuitBreakerInterface $circuitBreaker) {
        $this->logger = $logger;
        $this->cache  = $cache;
        $this->circuitBreaker = $circuitBreaker;
        // دریافت متغیرهای اتصال از .env
        $apiKey = config('services.jibit.api_key');
        $apiSecret = config('services.jibit.api_secret');
        // FIX-P3-ADP-087: trim در زمان ساخت؛ secret فقط-فاصله‌ای = پیکربندی‌نشده
        // (دیگر درخواست token بی‌حاصل در هر استعلام صادر نمی‌شود).
        $this->apiKey = is_string($apiKey) && trim($apiKey) !== '' ? trim($apiKey) : null;
        $this->apiSecret = is_string($apiSecret) && trim($apiSecret) !== '' ? trim($apiSecret) : null;
        $configuredBase = config('services.jibit.base_url', 'https://api.jibit.ir/v1/');
        $this->baseUrl = rtrim(is_string($configuredBase) ? $configuredBase : 'https://api.jibit.ir/v1/', '/') . '/';
        // FIX-P3-ADP-085: صفر/منفی/غیرعددی/بزرگِ پیکربندی → کلمپ 2..30
        // (قبلاً مقدار خام مستقیم به CURLOPT_TIMEOUT می‌رفت و timeout=0 یعنی بی‌نهایت).
        $this->timeout = max(self::TIMEOUT_MIN, min(self::TIMEOUT_MAX, int_value(config('services.jibit.timeout', 10), 10)));
    }

    /**
     * بررسی می‌کند که آیا کلیدهای اتصال تنظیم شده‌اند یا خیر
     */
    public function isConfigured(): bool
    {
        // FIX-P3-ADP-087: مقادیر در سازنده trim شده‌اند؛ null/رشتهٔ خالی = پیکربندی‌نشده.
        return $this->apiKey !== null && $this->apiSecret !== null;
    }

    /**
     * استعلام نام صاحب شبا
     */
    public function inquireIban(string $iban): array
    {
        if (!$this->isConfigured()) {
            return [
                'success' => false,
                'message' => 'پیکربندی Jibit انجام نشده است.'
            ];
        }

        $iban = strtoupper(str_replace(' ', '', trim($iban)));
        if (!$this->isValidIranianIban($iban)) {
            return ['success'=>false,'message'=>'شماره شبا نامعتبر است.'];
        }
        $cacheKey = 'iban_inquiry:' . hash('sha256', $iban);

        // 1. Check cache first
        try {
            $cached = $this->cache->get($cacheKey);
            if (is_string($cached)) {
                $decoded = json_decode($cached, true);
                $cached = is_array($decoded) ? $decoded : null;
            }
            // FIX-P3-ADP-083: گارد cache poisoning — مقدار کش فقط با schema کامل
            // (success + owner/bank غیرخالی + binding شِبا با درخواست) بازگردانده
            // می‌شود؛ هر چیز دیگری مثل cache-miss رفتار می‌کند و مسیر شبکه می‌رود.
            if ($this->isValidCachedResult($cached, $iban)) {
                /** @var array<string,mixed> $cached */
                return $cached;
            }
        } catch (\Throwable $ignore) { /* intentional: non-blocking operation */ }

        try {
            // 2. Execute within Circuit Breaker and retry with backoff using central ExternalCallTrait
            $result = $this->circuitBreaker->call('jibit', function() use ($iban) {
                return $this->retryTransient(function() use ($iban) {
                    // ۱. دریافت Token
                    $token = $this->getAccessToken();
                    if (!$token) {
                        throw new \Core\Exceptions\PermanentFailure('خطا در احراز هویت با سرویس بانکی.');
                    }

                    // ۲. درخواست استعلام شبا
                    $response = $this->makeRequest('GET', 'services/iban?value=' . $iban, [], $token);

                    // FIX-P3-ADP-084: اعتبارسنجی type-safe و ساخت نتیجهٔ استاندارد
                    // (شامل binding شِبا) — هر فیلد قبل از استفاده is_string چک می‌شود.
                    return $this->parseIbanResponse($response, $iban);
                }, 3, 500, 3000);
            });

            if (!is_array($result)) {
                throw new \UnexpectedValueException('Jibit circuit breaker returned an invalid response.');
            }

            // 3. Cache successful results for 24 hours (1440 minutes)
            if (!empty($result['success'])) {
                try {
                    $this->cache->put($cacheKey, $result, 1440);
                } catch (\Throwable $ignore) { /* intentional: non-blocking operation */ }
            }

            return $result;

        } catch (\Throwable $e) {
            // FIX (Round-18 P3): raw provider exception text must not reach callers —
            // the detail stays in the log; callers get a stable generic message.
            // FIX-P3-ADP-081: IBAN در لاگ ماسک می‌شود و بدنهٔ خام پاسخ (body=…) که
            // classifyHttpFailure در message جاسازی می‌کند، پیش از لاگ حذف می‌شود.
            $this->logger->error('jibit.inquiry.failed', [
                'iban' => $this->maskIban($iban),
                'exception_class' => get_class($e),
                'error' => $this->safeLogError($e)
            ]);

            if (strpos($e->getMessage(), 'Circuit breaker') !== false) {
                return [
                    'success' => false,
                    'message' => 'سرویس استعلام موقتاً در دسترس نیست. لطفا بعدا تلاش کنید.'
                ];
            }

            return [
                'success' => false,
                'message' => 'عدم برقراری ارتباط با سرویس استعلام شبا. لطفاً بعداً تلاش کنید.'
            ];
        }
    }

    /**
     * تولید Access Token جی‌بیت — FIX-P3-ADP-088: با کش کوتاه‌مدت.
     * توکن معتبر کش‌شده مصرف می‌شود؛ token تازه فقط در cache-miss گرفته و
     * ذخیره می‌شود؛ روی HTTP 401 کلید کش باطل می‌شود (invalidate در makeRequest).
     */
    private function getAccessToken(): ?string
    {
        try {
            $cachedToken = $this->cache->get(self::TOKEN_CACHE_KEY);
            if (is_string($cachedToken) && trim($cachedToken) !== '') {
                return $cachedToken;
            }
        } catch (\Throwable $ignore) { /* intentional: non-blocking operation */ }

        $payload = [
            'apiKey' => $this->apiKey,
            'secretKey' => $this->apiSecret,
        ];

        $result = $this->makeRequest('POST', 'tokens/generate', $payload);
        $token = $result['accessToken'] ?? null;
        if (!is_string($token) || trim($token) === '') {
            return null;
        }
        try {
            $this->cache->put(self::TOKEN_CACHE_KEY, $token, self::TOKEN_CACHE_TTL_MINUTES);
        } catch (\Throwable $ignore) { /* intentional: non-blocking operation */ }
        return $token;
    }

    /**
     * FIX-P3-ADP-088: ابطال کش توکن (روی HTTP 401) — الگوی forget در FcmNotificationAdapter.
     */
    private function forgetCachedAccessToken(): void
    {
        try {
            $this->cache->forget(self::TOKEN_CACHE_KEY);
        } catch (\Throwable $ignore) { /* intentional: non-blocking operation */ }
    }

    /**
     * اجرای درخواست خام با CURL - with comprehensive timeout and error handling
     */
    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function makeRequest(string $method, string $endpoint, array $data = [], ?string $token = null): array
    {
        $url = $this->baseUrl . $endpoint;
        // ✅ SSRF check — baseUrl از config می‌آید اما باید verify شود
        if (!$this->isExternalUrlSafe($url)) {
            // FIX-P3-ADP-081: URL (که شِبا در query دارد) هرگز در متن exception
            // قرار نمی‌گیرد — این متن به لاگ هم می‌رود.
            throw new \RuntimeException('SSRF Protection: Jibit request URL blocked.');
        }
        $ch = curl_init($url);

        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
        ];

        if ($token) {
            $headers[] = 'Authorization: Bearer ' . $token;
        }

        // Comprehensive timeout handling to prevent hanging requests
        // FIX-P3-ADP-085: timeout در سازنده کلمپ شده (2..30)؛ connect timeout
        // زیرمجموعهٔ امن آن است (هم‌الگوی Vandar: max(1, min(5, timeout-1))).
        $timeout = $this->timeout;
        $connectTimeout = max(1, min(5, $timeout - 1));

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,                    // Total timeout
            CURLOPT_CONNECTTIMEOUT => $connectTimeout,      // Connection timeout
            CURLOPT_DNS_CACHE_TIMEOUT => 120,               // Cache DNS for 2 minutes
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_FAILONERROR => false,                   // Don't fail silently on HTTP errors
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr = curl_errno($ch);
        $curlErrMsg = curl_error($ch);
        curl_close($ch);

        // FIX-P3-ADP-088: 401 با token کش‌شده = توکن منقضی/باطل — کش ابطال می‌شود
        // تا استعلام بعدی token تازه بگیرد (شکستِ همین استعلام fail-closed می‌ماند).
        if ($httpCode === 401 && $token !== null) {
            $this->forgetCachedAccessToken();
        }

        if ($httpCode >= 200 && $httpCode < 300 && $response) {
            $decoded = json_decode((string)$response, true);
            return is_array($decoded) ? $decoded : [];
        }

        throw $this->classifyHttpFailure($httpCode, $curlErr, (string)$response, ['provider' => 'jibit']);
    }

    /**
     * FIX-P3-ADP-084: parse type-safe پاسخ استعلام — هر فیلد قبل از مصرف
     * is_string و غیرخالی چک می‌شود؛ نتیجهٔ موفق همیشه شامل binding شِبا است.
     * پاسخ ناقص/بدنوع = PermanentFailure (fail-closed — رفتار ADP-086 دست‌نخورده).
     *
     * @param array<string, mixed> $response
     * @return array<string, mixed>
     */
    private function parseIbanResponse(array $response, string $iban): array
    {
        $name = $response['name'] ?? null;
        $familyName = $response['familyName'] ?? null;
        $bank = $response['bank'] ?? null;

        if (!is_string($name) || trim($name) === '') {
            $errorPayload = is_array($response['error'] ?? null) ? $response['error'] : [];
            $errorMessage = is_string($errorPayload['message'] ?? null)
                ? $errorPayload['message']
                : 'پاسخ نامعتبر از سمت سرویس بانکی.';
            throw new \Core\Exceptions\PermanentFailure($errorMessage);
        }
        if (!is_string($bank) || trim($bank) === '') {
            throw new \Core\Exceptions\PermanentFailure('پاسخ استعلام شبا سرویس بانکی ناقص است.');
        }

        $family = is_string($familyName) ? trim($familyName) : '';
        // FIX-P3-ADP-084: کپِ نهایی رشتهٔ owner_name (نه فقط اجزا) — ترکیب دو
        // جزء کپ‌شده ممکن است از سقف بلندتر شود.
        $ownerName = mb_substr(trim(mb_substr(trim($name), 0, self::MAX_FIELD_LENGTH) . ' ' . mb_substr($family, 0, self::MAX_FIELD_LENGTH)), 0, self::MAX_FIELD_LENGTH);

        return [
            'success' => true,
            'owner_name' => $ownerName,                                   // FIX-P3-ADP-084 (کپ طول)
            'bank' => mb_substr(trim($bank), 0, self::MAX_FIELD_LENGTH),  // FIX-P3-ADP-084
            'iban' => $iban,                                              // binding برای گارد ADP-032/083
            'message' => 'استعلام با موفقیت انجام شد.'
        ];
    }

    private function isValidIranianIban(string $iban): bool
    {
        if (preg_match('/^IR\d{24}$/', $iban) !== 1) return false;
        $rearranged = substr($iban, 4) . '1827' . substr($iban, 2, 2);
        $remainder = 0;
        foreach (str_split($rearranged) as $digit) {
            $remainder = ($remainder * 10 + (int)$digit) % 97;
        }
        return $remainder === 1;
    }

    /**
     * FIX-P3-ADP-083: schema-guard مقدار کش — success + owner/bank غیرخالی +
     * binding دقیق شِبای کش‌شده با شِبای درخواستی (ضد cross-IBAN poisoning).
     * رکوردهای قدیمی بدون «iban» هم رد می‌شوند (cache miss → refresh با شکل جدید).
     *
     * @param mixed $cached
     */
    private function isValidCachedResult($cached, string $requestedIban): bool
    {
        if (!is_array($cached) || empty($cached['success'])) {
            return false;
        }
        $ownerName = $cached['owner_name'] ?? null;
        if (!is_string($ownerName) || trim($ownerName) === '') {
            return false;
        }
        $bank = $cached['bank'] ?? null;
        if (!is_string($bank) || trim($bank) === '') {
            return false;
        }
        $cachedIban = $cached['iban'] ?? null;
        return is_string($cachedIban) && strtoupper(trim($cachedIban)) === $requestedIban;
    }

    /**
     * FIX-P3-ADP-081: متن امن برای لاگ — قطعهٔ «body=<raw provider response>» که
     * ExternalCallTrait::classifyHttpFailure در message جاسازی می‌کند حذف و طول پیام کپ می‌شود.
     */
    private function safeLogError(\Throwable $e): string
    {
        $message = preg_replace('/body=.*$/s', 'body=[redacted]', $e->getMessage());
        return mb_substr(is_string($message) ? $message : $e->getMessage(), 0, 300);
    }

    /**
     * FIX-P3-ADP-081: IBAN هرگز خام لاگ نمی‌شود — فقط ۴ کاراکتر آخر.
     */
    private function maskIban(string $iban): string
    {
        $iban = trim($iban);
        $length = strlen($iban);
        if ($length === 0) {
            return '';
        }
        if ($length <= 4) {
            return str_repeat('*', $length);
        }
        return '****' . substr($iban, -4);
    }
}
