<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use Core\Exceptions\ValidationException;
use App\Services\Settings\AppSettings;

/**
 * AdapterBase - پایه مشترک برای همه آداپترهای خارجی
 *
 * وظایف:
 * - تزریق LoggerInterface
 * - تزریق SettingService
 * - استانداردسازی response shape
 * - wrapper برای validation
 * - logging امن و یکپارچه
 */
abstract class AdapterBase
{
    use \App\Traits\ExternalCallTrait;

    protected LoggerInterface $logger;
    protected AppSettings $appSettings;
    protected ?ValidatorFactoryInterface $validatorFactory;
    protected ?\App\Contracts\AntiFraud\FraudGuardInterface $fraudGuard;

    public function __construct(
        LoggerInterface $logger,
        AppSettings $appSettings,
        ?ValidatorFactoryInterface $validatorFactory = null,
        ?\App\Contracts\AntiFraud\FraudGuardInterface $fraudGuard = null
    ) {
        $this->logger = $logger;
        $this->appSettings = $appSettings;
        $this->validatorFactory = $validatorFactory;
        $this->fraudGuard = $fraudGuard;
    }

    /**
     * Wrapper استاندارد برای validation
     * اکنون می‌تواند هم فلگ bool (برود به validate فرزند) و هم یک آرایه مستقیم rules بگیرد.
     *
     * FIX-R36-W3 (F-A19d-03): صفر call-site در کل repo (AdSystemManager مستقیماً
     * validate() فرزند را صدا می‌زند). حذف = پیشنهاد cleanup-wave.
     *
     * @deprecated Dead helper (r36 audit F-A19d-03) — هیچ مصرف‌کننده‌ای ندارد.
     * @param array<string, mixed> $data
     * @param bool|array<string, mixed> $rulesOrUpdate
     */
    protected function validateData(array $data, mixed $rulesOrUpdate = false): void
    {
        // 1. اگر مستقیماً آرایه‌ای از Rules ارسال شده، خودکار با Validator سیستمی ولیدیت کن
        if (is_array($rulesOrUpdate)) {
            $validator = $this->validatorFactory
                ? $this->validatorFactory->make($data, $rulesOrUpdate)
                : new \Core\Validator($data, $rulesOrUpdate);
            if (!$validator->passes()) {
                $validationErrors = $validator->errors();
                throw new ValidationException(is_array($validationErrors) ? $validationErrors : []);
            }
            return;
        }

        // 2. وگرنه از سیستم کلاس فرزند استفاده کن
        $result = $this->validate($data, (bool)$rulesOrUpdate);
        // FIX-P3-ADP-024: خواندن کلید 'valid' با گارد صریح — نتیجهٔ بدشکل/بدون کلید
        // (فرزندی که قرارداد ['valid'=>bool,'errors'=>[]] را نقض کند) fail-closed
        // به‌عنوان «نامعتبر» تفسیر می‌شود، نه خطای undefined-key یا عبور خاموش.
        $valid = is_array($result) && array_key_exists('valid', $result) && $result['valid'] === true;
        if (!$valid) {
            $errors = (is_array($result) && ($result['errors'] ?? null) !== null) ? $result['errors'] : ['دیتا نامعتبر است.'];
            throw new ValidationException(is_array($errors) ? $errors : ['دیتا نامعتبر است.']);
        }
    }

    /**
     * Response shape استاندارد برای موفقیت
     * @param array<string, mixed> $data
     * @return array{success: true, message: string, data: array<string, mixed>}
     */
    protected function successResponse(string $message, array $data = []): array
    {
        return [
            'success' => true,
            'message' => $message,
            'data' => $data,
        ];
    }

    /**
     * Response shape استاندارد برای خطا
     * @return array{success: false, message: string, errors: array<int|string, mixed>}
     */
    protected function errorResponse(string $message, mixed $errors = []): array
    {
        return [
            'success' => false,
            'message' => $message,
            'errors' => is_array($errors) ? $errors : [$errors],
        ];
    }

    /**
     * Logging استاندارد برای عملیات موفق
     * @param array<string, mixed> $context
     */
    protected function logSuccess(string $operation, array $context = []): void
    {
        $this->logger->info("adapter.{$this->getType()}.{$operation}.success", $context);
    }

    /**
     * Logging استاندارد اطلاعات عمومی (مورد نیاز فرزندان)
     * @param array<string, mixed> $context
     */
    protected function logInfo(string $operation, array $context = []): void
    {
        $this->logger->info("adapter.{$this->getType()}.{$operation}.info", $context);
    }

    /**
     * Logging استاندارد برای خطا
     * @param array<string, mixed> $context
     */
    protected function logError(string $operation, string $error, array $context = []): void
    {
        // FIX-P3-ADP-026: متن خام خطا/exception قبل از ورود به لاگ پاک‌سازی می‌شود
        // (کنترل‌کاراکتر/خط جدید → فاصله، ماسک الگوهای credential، سقف طول) —
        // جزئیات سرور عمداً حفظ می‌شود (فشار حذف کامل جزئیات مطلوب نیست)،
        // فقط تزریق خط جدید به لاگ و لو رفتن secret مسدود است.
        $this->logger->error("adapter.{$this->getType()}.{$operation}.failed", array_merge($context, ['error' => self::sanitizeLogText($error)]));
    }

    /**
     * FIX-P3-ADP-026 — پاک‌سازی متن خطا در مرز logging آداپترها:
     * - کنترل‌کاراکترها و خطوط جدید به فاصله تبدیل می‌شوند (جلوگیری از log-forging)
     * - مقادیر الگوهای credential (password/secret/token/api_key/...) ماسک می‌شوند
     * - طول متن سقف دارد (جلوگیری از تورم رکورد لاگ)
     */
    protected static function sanitizeLogText(string $text): string
    {
        $text = preg_replace('/[\x00-\x08\x0A-\x1F\x7F]/', ' ', $text) ?? '';
        $text = preg_replace(
            '/(\b(?:password|passwd|secret|token|api[_-]?key|authorization|bearer)\b\s*[:=]\s*)\S+/i',
            '$1[MASKED]',
            $text
        ) ?? '';
        if (strlen($text) > 500) {
            $text = substr($text, 0, 500) . '…[truncated]';
        }
        return $text;
    }

    /**
     * FIX-P3-ADP-003/012/041/143/066 — نرمال‌ساز decimal خوش‌فرم برای BCMath.
     * فقط رشته‌های ^-?\d+(\.\d+)?$ قبول‌اند؛ نماد علمی ('1e5') و مقادیر غیرعددی
     * که is_numeric می‌پذیرد ولی BCMath در PHP 8 برایشان ValueError می‌اندازد،
     * این‌جا رد (و به fallback می‌روند) — نه coercion خاموش، نه استثنای خام.
     */
    protected static function wellFormedDecimal(mixed $value, ?string $fallback = null): ?string
    {
        if (!is_scalar($value)) {
            return $fallback;
        }
        $candidate = trim((string)$value);
        if (preg_match('/^-?\d{1,30}(\.\d{1,12})?$/', $candidate) !== 1) {
            return $fallback;
        }
        return $candidate;
    }

    /**
     * FIX-P3-ADP-003/012/041/143 — کارمزد درصدی همیشه در بازهٔ [0,100].
     * مقدار خارج از بازه/بدشکل clamp یا به default برمی‌گردد و با لاگ هشدار
     * قابل‌مشاهده می‌شود (بدون فیک‌ساکسس، بدون استثنای خام به سمت کاربر).
     */
    protected function boundedFeePercent(string $settingKey, string $fallback): string
    {
        $raw = $this->appSettings->get($settingKey, $fallback);
        $value = self::wellFormedDecimal($raw);
        if ($value === null) {
            $this->logger->warning("adapter.{$this->getType()}.fee_percent_invalid", [
                'setting' => $settingKey,
                'fallback_applied' => true,
            ]);
            return self::wellFormedDecimal($fallback) ?? '0';
        }
        if (bccomp($value, '0', 4) < 0) {
            $this->logger->warning("adapter.{$this->getType()}.fee_percent_out_of_range", ['setting' => $settingKey, 'clamped_to' => '0']);
            return '0';
        }
        if (bccomp($value, '100', 4) > 0) {
            $this->logger->warning("adapter.{$this->getType()}.fee_percent_out_of_range", ['setting' => $settingKey, 'clamped_to' => '100']);
            return '100';
        }
        return $value;
    }

    /**
     * FIX-P3-ADP-001/037/065/141 — سیاست URL امن برای لینک‌های تبلیغاتی:
     * فقط http/https با هاست عمومی (شامل نقطه)، بدون credential و بدون
     * کنترل‌کاراکتر. FILTER_VALIDATE_URL تنها، scheme دلخواه (javascript:, ftp:،
     * data:) را می‌پذیرفت — این نگهبان جایگزین مرز واحد است.
     */
    protected static function isSafeHttpUrl(string $url): bool
    {
        $url = trim($url);
        if ($url === '' || mb_strlen($url) > 2048 || preg_match('/[\x00-\x1F\x7F]/', $url) === 1) {
            return false;
        }
        $parsed = parse_url($url);
        if (!is_array($parsed)) {
            return false;
        }
        if (isset($parsed['user']) || isset($parsed['pass'])) {
            return false; // credential-embedded URL
        }
        $scheme = strtolower(is_string($parsed['scheme'] ?? null) ? $parsed['scheme'] : '');
        $host = strtolower(is_string($parsed['host'] ?? null) ? $parsed['host'] : '');
        return in_array($scheme, ['http', 'https'], true)
            && $host !== '' && str_contains($host, '.')
            && filter_var("{$scheme}://{$host}/", FILTER_VALIDATE_URL) !== false;
    }

    /**
     * Logging استاندارد برای عملیات شروع
     * @param array<string, mixed> $context
     */
    protected function logStart(string $operation, array $context = []): void
    {
        $this->logger->info("adapter.{$this->getType()}.{$operation}.started", $context);
    }

    /**
     * متد abstract برای نوع آداپتر
     */
    abstract public function getType(): string;

    /**
     * متد abstract برای validation
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    abstract public function validate(array $data, bool $isUpdate = false): array;

    /**
     * 🛡️ Fraud Policy Guard — بررسی ضدتقلب قبل از عملیات مالی
     *
     * طبق معماری مورد توافق: Application Layer مسئول اجرای Policy هست.
     * Wallet فقط Financial Engine خالص خواهد بود.
     *
     * FIX-P3-ADP-027: گارد مفقود (null) روی مسیر پول fail-closed است.
     * FIX-P3-ADP-028: هر Throwable خامِ گارد به BusinessException دامنه‌ای نقشه می‌خورد.
     *
     * @throws \App\Exceptions\BusinessException اگه fraud blocked بشه، گارد مفقود باشد
     *         یا خود گارد با خطا مواجه شود (fail-closed)
     * @param array<string, mixed> $context
     */
    protected function assertFraudAllowed(int $userId, string $action, array $context = []): void
    {
        try {
            if ($this->fraudGuard === null) {
                // FIX-P3-ADP-027: fail-open حذف شد — نبودِ گارد ضدتقلب روی «مسیر پول»
                // دیگر «ادامهٔ عملیات با هشدار» نیست؛ بلوک صریح است. حالت قبلی یعنی
                // هر آداپتری که guard تزریق‌نشده باشد عملاً بدون کنترل تقلب پرداخت می‌کند.
                $this->logger->warning("adapter.{$this->getType()}.fraud_check_unavailable", [
                    'user_id' => $userId,
                    'reason' => 'fraud_guard_not_injected_fail_closed',
                ]);
                throw new \App\Exceptions\BusinessException(
                    'عملیات مالی موقتاً در دسترس نیست؛ لطفاً بعداً تلاش کنید.'
                );
            }
            $risk = $this->fraudGuard->checkAction($userId, $action, $context);

            if (empty($risk['allowed'])) {
                $reason = $risk['reason'] ?? 'security_block';
                $this->logger->warning("adapter.{$this->getType()}.fraud_blocked", [
                    'user_id' => $userId,
                    'action' => $action,
                    'reason' => $reason,
                ]);
                throw new \App\Exceptions\BusinessException(
                    'عملیات مالی به دلیل محدودیت‌های امنیتی مجاز نیست.'
                );
            }
        } catch (\App\Exceptions\BusinessException $e) {
            throw $e;
        } catch (\Throwable $e) {
            // FIX-R36-W3 (F-A10-09): این wrapper دور «مسیر پول» است (پرداخت‌های
            // تبلیغات). قبلاً هر Throwable به‌جز BusinessException بی‌صدا بلعیده
            // و عملیات ادامه می‌یافت (fail-open) — اگر قرارداد
            // FraudGuardService::checkAction روزی روی outage شروع به throw کردن
            // کند، گیت تقلبِ همهٔ آداپترهای پولی خاموش می‌شد (نقض H-11/M-24
            // fail-closed). امروز checkAction هرگز throw نمی‌کند
            // (handleSystemFailure → حکم fail-closed)، پس این تغییر رفتارِ
            // زنده‌ای عوض نمی‌کند؛ فقط قرارداد را fail-closed می‌بندد.
            // FIX-P3-ADP-028: rethrow یکدست — هر Throwable خام به BusinessException
            // دامنه‌ای نقشه می‌خورد (هم‌الگوی errorResponse در create()) تا مرز
            // آداپتر هرگز استثنای خام (پیام/کلاسِ زیرساختی) به بیرون نشت ندهد؛
            // جزئیات کامل فقط در لاگ (پاک‌سازی‌شدهٔ FIX-P3-ADP-026) می‌ماند.
            $this->logger->warning("adapter.{$this->getType()}.fraud_check_unavailable", [
                'user_id' => $userId,
                'error' => self::sanitizeLogText($e->getMessage()),
            ]);
            throw new \App\Exceptions\BusinessException(
                'عملیات مالی موقتاً در دسترس نیست؛ لطفاً بعداً تلاش کنید.',
                0,
                $e
            );
        }
    }
}

