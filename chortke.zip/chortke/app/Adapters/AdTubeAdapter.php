<?php

namespace App\Adapters;

use Core\ValueObjects\Money;
use App\Contracts\AdSystemContract;
use App\Contracts\LoggerInterface;
use App\Contracts\ValidatorFactoryInterface;
use Core\Database;
use App\Services\Settings\AppSettings;
use App\Constants\PercentageConstants;
use App\Services\Shared\IdempotencyService;
use App\Models\Ads;

/**
 * AdTubeAdapter - creates AdTube campaign records only.
 * Financial hold/withdraw is handled centrally by AdSystemManager.
 */
class AdTubeAdapter extends AdapterBase implements AdSystemContract
{
    public function __construct(
        private Ads $adModel,
        LoggerInterface $logger,
        AppSettings $appSettings,
        ValidatorFactoryInterface $validatorFactory
    ) {
        parent::__construct($logger, $appSettings, $validatorFactory);
    }

    public function getType(): string { return 'adtube'; }

    public function create(int $userId, array $data): array
    {
        try {
            // FIX-P3-ADP-011 (قرارداد تک‌گذر، هم‌الگوی FIX-P3-ADP-005): create() دیتای
            // نرمال‌شده را از validate() می‌گیرد؛ گیت خام تعداد هم این‌جا اعمال می‌شود.
            $validation = $this->validate($data);
            if (!$validation['valid']) {
                return $this->errorResponse('اطلاعات وارد شده معتبر نیست', $validation['errors']);
            }
            $data = $validation['data'];

            $ad = $this->adModel->create([
                'user_id' => $userId,
                'type' => 'adtube',
                'platform' => 'youtube',
                'task_type' => 'view',
                'title' => $data['title'],
                'description' => $data['description'] ?: null,
                'link' => $data['link'],
                'target_url' => $data['link'],
                'price_per_task' => $data['price_per_task'],
                'currency' => $data['currency'],
                'total_budget' => $data['total_budget'],
                'remaining_budget' => $data['total_budget'],
                'total_count' => $data['total_count'],
                'remaining_count' => $data['total_count'],
                'pending_count' => 0,
                'completed_count' => 0,
                'site_commission_percent' => $data['site_commission_percent'],
                'status' => $data['requires_admin_review'] ? 'pending_review' : 'active',
                'created_by' => $userId,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            if (!$ad) {
                return $this->errorResponse('خطا در ذخیره نهایی تبلیغ');
            }
            $adId = 0;
            if (is_object($ad)) {
                $adVars = get_object_vars($ad);
                $adId = is_numeric($adVars['id'] ?? null) ? (int)$adVars['id'] : 0;
            } elseif (is_numeric($ad)) {
                $adId = (int)$ad;
            }
            if ($adId <= 0) {
                return $this->errorResponse('شناسه آگهی ایجادشده نامعتبر است');
            }
            return $this->successResponse('تبلیغ AdTube با موفقیت ثبت شد', ['id' => $adId, 'ad_id' => $adId]);
        } catch (\Throwable $e) {
            $this->logError('create', $e->getMessage(), ['user_id' => $userId]);
            return $this->errorResponse('خطای سیستمی در ایجاد تبلیغ AdTube رخ داد.');
        }
    }

    /**
     * قرارداد validate (FIX-P3-ADP-024/067): خروجی همیشه ['valid'=>bool,'errors'=>list,'data'=>array].
     * FIX-P3-ADP-011: گیت خام تعداد قبل از clamp — ۰/منفی/اعشاری رد می‌شود نه coerce به ۱.
     * FIX-P3-ADP-067: خرابی Money/normalize = valid=false عمومی، نه استثنای نشت‌کننده.
     */
    public function validate(array $data, bool $isUpdate = false): array
    {
        $errors = [];
        $countInput = $data['total_count'] ?? $data['quantity'] ?? 1;
        $countRaw = is_string($countInput) ? trim($countInput) : $countInput;
        $countIsInteger = (is_int($countRaw) && $countRaw >= 1)
            || (is_string($countRaw) && $countRaw !== '' && ctype_digit($countRaw) && (int)$countRaw >= 1);
        if (!$countIsInteger) {
            $errors[] = 'تعداد نمایش‌های درخواستی باید حداقل ۱ عدد باشد';
        }
        try {
            $data = $this->normalize($data);
        } catch (\InvalidArgumentException $e) {
            $this->logger->warning("adapter.{$this->getType()}.validate_normalize_failed", ['error' => self::sanitizeLogText($e->getMessage())]);
            return ['valid' => false, 'errors' => ['ورودی ارسالی معتبر نیست.'], 'data' => []];
        }
        $errors = array_merge($errors, $this->validateNormalized($data));
        return ['valid' => empty($errors), 'errors' => $errors, 'data' => $data];
    }

    /** @return list<string> */
    private function validateNormalized(array $data): array
    {
        $errors = [];
        if (mb_strlen($data['title']) < 3) $errors[] = 'عنوان تبلیغ الزامی است';
        if ($data['link'] === '') {
            $errors[] = 'لینک ویدیوی یوتیوب الزامی است';
        }
        // 🛡️ FIX-R3-F5 (P2): allowlist واقعی هاست + https + شناسهٔ ویدیوی ۱۱ کاراکتری.
        // regex قبلی فقط «youtube.com|youtu.be در هر جای رشته» را می‌خواست و دامنه‌های
        // جعلی (مثل https://evil.tld/?x=youtube.com) را می‌پذیرفت. منبع واحد:
        // youtube_video_id() در helpers/security.php (همان allowlist در execute.php هم).
        elseif (youtube_video_id($data['link']) === null) {
            $errors[] = 'لینک وارد شده باید یک لینک معتبر یوتیوب باشد';
        }
        $minPriceValue = $this->appSettings->get('adtube_min_price_per_view', 100);
        // FIX-P3-ADP-016: حداقل قیمت هم decimal خوش‌فرم (نماد علمی → پیش‌فرض ۱۰۰)
        $minPrice = self::wellFormedDecimal($minPriceValue) ?? '100';
        if (bccomp($data['price_per_task'], $minPrice, 8) < 0) {
            $errors[] = "حداقل هزینه هر نمایش {$minPrice} تومان می‌باشد";
        }
        if ($data['total_count'] < 1) $errors[] = 'تعداد نمایش‌های درخواستی باید حداقل ۱ عدد باشد';
        return $errors;
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function isExpired(int $adId): bool
    {
        $ad = $this->adModel->find($adId);
        if (!is_object($ad)) {
            return true;
        }
        $adVars = get_object_vars($ad);
        $status = is_string($adVars['status'] ?? null) ? $adVars['status'] : '';
        $remaining = is_numeric($adVars['remaining_budget'] ?? null) ? (string)$adVars['remaining_budget'] : '0';
        return in_array($status, ['expired', 'completed'], true) || bccomp($remaining, '0', 8) <= 0;
    }

    public function calculateCost(string $amount, array $context = []): string
    {
        // FIX-P3-ADP-016: preflight — مبلغ باید decimal خوش‌فرم مثبت باشد و کارمزد
        // clamp‌شدهٔ [0,100]؛ ورودی بدشکل (مثل نماد علمی از cast float) به‌جای
        // InvalidArgumentException خامِ Money، خطای دامنه‌ای با پیام عمومی می‌دهد
        // (کنترلر previewCost طبق FIX-R20-B1 آن را به پاسخ خطای دامنه نقشه می‌کند).
        $amount = trim($amount);
        if (preg_match('/^\d{1,20}(\.\d{1,8})?$/', $amount) !== 1 || bccomp($amount, '0', 8) <= 0) {
            throw new \InvalidArgumentException('مبلغ وارد شده برای محاسبه هزینه معتبر نیست.');
        }
        // FIX-P3-ADP-012: کارمزد همیشه در بازهٔ [0,100].
        $feePercent = $this->boundedFeePercent('adtube_site_fee_percent', (string)PercentageConstants::AD_TUBE_FEE_PERCENT);
        $currency = is_string($context['currency'] ?? null) ? $context['currency'] : 'irt';
        // float→decimal: محاسبهٔ کارمزد با Money/BCMath به‌جای float برای جلوگیری از خطای اعشار
        return Money::fromString($amount, $currency)->percentage($feePercent)->getAmount();
    }

    /**
     * FIX-C52 (یافتهٔ ممیزی ۵۲): fail-loud — همان الگوی SeoAdAdapter؛ پرداخت ساختگی حذف شد.
     * @deprecated Dead contract surface (F-A19d-03) — صفر call-site
     */
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array
    {
        throw new \LogicException(
            'AdTubeAdapter::processPayment غیرفعال است (F-A19d-03/59): تسویهٔ مالی فقط از مسیر متمرکز escrow/AdsBudgetSettlementService انجام می‌شود.'
        );
    }

    /**
     * FIX-C52 (یافتهٔ ممیزی ۵۲): fail-loud — موفقیت ساختگی/لاگِ بدون اثر حذف شد.
     * @deprecated Dead contract surface (F-A19d-03) — صفر call-site
     */
    public function track(int $adId, string $eventType, ?int $userId = null): array
    {
        throw new \LogicException(
            'AdTubeAdapter::track غیرفعال است (F-A19d-03/59): ثبت رویداد فقط از مسیر AdsBudgetSettlementService انجام می‌شود.'
        );
    }

    /** @deprecated Dead contract surface (F-A19d-03) — صفر call-site */
    public function getStatus(int $adId): ?array
    {
        $ad = $this->adModel->find($adId);
        if (!is_object($ad)) {
            return null;
        }
        $adVars = get_object_vars($ad);
        return [
            'id' => is_numeric($adVars['id'] ?? null) ? (int)$adVars['id'] : 0,
            'type' => 'adtube',
            'status' => is_string($adVars['status'] ?? null) ? $adVars['status'] : 'unknown',
        ];
    }

    /**
     * @param array<string, mixed> $data
     * @return array{title: string, description: string, link: string, price_per_task: string, currency: string, total_count: int, total_budget: string, site_commission_percent: string, requires_admin_review: bool}
     */
    private function normalize(array $data): array
    {
        $toString = static fn(mixed $value): string => is_scalar($value) ? trim((string)$value) : '';
        $toInt = static fn(mixed $value): int => is_numeric($value) ? (int)$value : 0;

        $currency = strtolower($toString($data['currency'] ?? 'irt'));
        if (in_array($currency, ['irr', 'rial'], true)) {
            // FIX-R36-W3 (F-A19d-10): irr→irt بدون بازمقیاس ×10 — رؤیت‌پذیری با لاگ
            // (تصمیم محصول برای ردّ/مقیاس در رجیستر).
            $this->logger->warning('ads.currency.irr_relabelled_irt', ['ad_type' => $this->getType(), 'received' => $currency]);
            $currency = 'irt';
        }
        if (!in_array($currency, ['irt', 'usdt'], true)) $currency = 'irt';
        // float→decimal: قیمت به‌صورت رشتهٔ decimal نگه داشته می‌شود
        // FIX-P3-ADP-016: فقط decimal خوش‌فرم (نماد علمی/غیرعددی → '0' → خطای حداقل قیمت)
        $priceInput = $data['price_per_task'] ?? 0;
        $price = self::wellFormedDecimal($priceInput) ?? '0';
        $count = max(1, $toInt($data['total_count'] ?? $data['quantity'] ?? 1));
        // FIX-P3-ADP-012: کارمزد همیشه در بازهٔ [0,100] (boundedFeePercent مشترک).
        $feePercent = $this->boundedFeePercent('adtube_site_fee_percent', (string)PercentageConstants::AD_TUBE_FEE_PERCENT);
        // 🛡️ FIX-R3-F5 (P2): کانونی‌سازی لینک — شناسهٔ معتبر استخراج و لینک همیشه
        // به شکل کانونی https://www.youtube.com/watch?v=<id> ذخیره می‌شود تا
        // iframe صفحهٔ execute و تاریخچه هرگز به دامنهٔ خامِ کاربر وابسته نباشند.
        $linkRaw = $toString($data['link'] ?? $data['target_link'] ?? $data['target_url'] ?? '');
        $videoId = youtube_video_id($linkRaw);
        $link = $videoId !== null ? 'https://www.youtube.com/watch?v=' . $videoId : $linkRaw;
        return [
            'title' => $toString($data['title'] ?? ''),
            'description' => $toString($data['description'] ?? ''),
            'link' => $link,
            'price_per_task' => $price,
            'currency' => $currency,
            'total_count' => $count,
            'total_budget' => Money::fromString($price, $currency)->multiply((string)$count)->getAmount(),
            'site_commission_percent' => $feePercent,
            // FIX-P3-ADP-012: پارس boolean سخت‌گیرانه — رشتهٔ 'false' دیگر truthy نیست؛
            // مقدار ناشناخته fail-safe (نیاز به بازبینی ادمین) + لاگ هشدار.
            'requires_admin_review' => $this->parseBooleanSetting(
                $this->appSettings->get('adtube_requires_admin_review', 0),
                'adtube_requires_admin_review'
            ),
        ];
    }

    /**
     * FIX-P3-ADP-012 — پارس boolean سخت‌گیرانه (هم‌الگوی BannerAdapter::parseBoolean):
     * مقادیر شناخته‌شده را بدون coercion می‌فهمد؛ ناشناخته → InvalidArgumentException.
     */
    private function parseBoolean(mixed $value, string $field): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) && ($value === 0 || $value === 1)) {
            return $value === 1;
        }
        if (is_string($value)) {
            $normalized = strtolower(trim($value));
            if ($normalized === 'true' || $normalized === '1') return true;
            if ($normalized === 'false' || $normalized === '0') return false;
        }
        throw new \InvalidArgumentException("{$field} must be a boolean.");
    }

    /**
     * FIX-P3-ADP-012 — پارس boolean برای پرچم‌های «تنظیمات» (نه ورودی کاربر):
     * مقادیر شناخته‌شده (bool/0/1/'true'/'false'/'0'/'1') سخت‌گیرانه پارس می‌شوند؛
     * مقدار ناشناخته هرگز به (bool) خاموش coerce نمی‌شود و به‌جای شکستن ثبت
     * کمپین، fail-safe روی true (نیاز به بازبینی ادمین) می‌رود + هشدار لاگ.
     */
    private function parseBooleanSetting(mixed $value, string $field): bool
    {
        try {
            return $this->parseBoolean($value, $field);
        } catch (\InvalidArgumentException $e) {
            $this->logger->warning("adapter.{$this->getType()}.boolean_setting_invalid", [
                'field' => $field,
                'fail_safe' => 'admin_review_required',
                'error' => self::sanitizeLogText($e->getMessage()),
            ]);
            return true;
        }
    }
}
