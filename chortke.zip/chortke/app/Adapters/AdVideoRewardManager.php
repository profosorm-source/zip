<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Services\Settings\AppSettings;
use App\Contracts\LoggerInterface;
use Core\Database;
use Core\ValueObjects\Money;

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * قرارداد پایه آداپتورهای تبلیغات ویدیویی جایزه‌دار (Rewarded Video Interface)
 * ─────────────────────────────────────────────────────────────────────────────
 */
// FIX-X352 (راند ۸۷): قرارداد امضا — HMAC روی «بایت‌های خام بدنه» است نه بازسازی
// json_encode آرایهٔ پارس‌شده؛ هر سریالیزیشنِ معتبری از شبکه (ترتیب کلید، فاصله،
// \uXXXX و...) حالا وریفای می‌شود و امضا دقیقاً به بایت‌های ارسالی مقید است.
//
// FIX-P3-ADP-018 — قرارداد دو‌لایهٔ امنیت وب‌هوک (split contract):
//   • لایهٔ آداپتور (verifyS2SHmac): فقط اصالت امضا (HMAC روی بایت‌های خام — X352).
//   • لایهٔ کنترلر وب‌هوک (AdtubeController::webhook): محافظت replay/ضدتکرار —
//     پنجرهٔ زمانی Timestamp (FIX-X332، fail-closed روی هدر مفقود) و idempotency
//     بر پایهٔ شناسهٔ تراکنش خودِ شبکه (FIX-X333 + پروب replay X374).
// این تفکیک عمدی است؛ هر مصرف‌کنندهٔ جدیدِ verifyS2SHmac موظف است پیش از
// اعتبار پاداش، همان دو گیتِ لایهٔ کنترلر را خودش اجرا کند.
//
// FIX-P3-ADP-019 — سیاست گردکردن (rounding policy) پرداخت ویدیویی:
//   • محاسبهٔ payout همیشه رشته‌ای/BCMath است؛ float فقط در مرز settings و
//     با %.10F به decimal-string تبدیل می‌شود (AdVideoRewardDecimal::fromFloat).
//   • IRT: حاصل با scale 4 محاسبه و سپس با bcdiv(...,'1',0) «قطع» (truncate)
//     به تومان صحیح می‌شود — قطع به سمت صفر عمدی و محافظه‌کارانه است (پاداش
//     هرگز به سمت بالا گرد نمی‌شود)؛ تست مرزی در P3AdAdaptersPinTest.
//   • USDT: قطع به ۴ رقم اعشار با bcdiv(...,'1',4).
interface AdVideoRewardAdapterInterface
{
    public function getNetworkName(): string;
    public function getCurrency(): string;
    public function getBaseRate(): float;
    public function getUserSharePercent(): float;
    public function calculateUserPayout(): Money;
    /** @param string $rawBody بایت‌های خام php://input — دقیقاً همان‌چه شبکه فرستاده (X352) */
    public function verifyS2SHmac(string $rawBody, string $receivedSignature): bool;

    /**
     * FIX-P3-ADP-021: آیا شبکه پیکربندی‌شده است (وب‌هوک HMAC secret تنظیم شده)؟
     * هاب کاربری (getAvailableRewardAds) شبکهٔ پیکربندی‌نشده را با is_active=false
     * نمایش می‌دهد تا provider غیرپیکربندی‌شده به کاربر «فعال» تبلیغ نشود.
     */
    public function isConfigured(): bool;
}

/**
 * FIX-R36-W3 (F-A19d-05): نرمال‌سازی float→decimal-string برای bcmath.
 * ریشه: getBaseRate/getUserSharePercent از settings float می‌آیند؛ cast رشته‌ایِ
 * مستقیمِ float کوچک به نماد علمی می‌افتد ((string)1.0E-5 === '1.0E-5') و bcmul
 * با ورودی غیر-decimal خطا/صفر می‌دهد → پاداش خوش‌بینانهٔ 0. %.10F همیشه
 * نماد اعشاریِ کامل می‌دهد؛ صفرهای انتهایی بعداً تراشیده می‌شوند.
 */
final class AdVideoRewardDecimal
{
    public static function fromFloat(float $value): string
    {
        $s = sprintf('%.10F', $value);
        $s = rtrim(rtrim($s, '0'), '.');
        return ($s === '' || $s === '-' || $s === '-0') ? '0' : $s;
    }
}

/**
 * FIX-P3-ADP-017 — سیاست bounds پرداخت ویدیویی (قبل از هر bcmul):
 *  • نرخ پایه باید عددی مثبت و متناهی باشد؛ تنظیمات بی‌معنا (۰/منفی/NaN/INF)
 *    با RuntimeException شکست سریع می‌دهد و شبکه از هاب حذف می‌شود (لاگ + skip).
 *  • سهم کاربر باید متناهی باشد و به بازهٔ [0,100] clamp می‌شود.
 *  • خروجی رشته‌های decimal آمادهٔ BCMath است (بدون محاسبهٔ float share/100).
 */
final class AdVideoRewardPayoutPolicy
{
    /** @return array{base: string, share: string} رشته‌های decimal آمادهٔ bcmul */
    public static function resolve(float $baseRate, float $sharePercent, string $network): array
    {
        if (!is_finite($baseRate) || $baseRate <= 0.0) {
            throw new \RuntimeException(
                "تنظیمات نرخ پایه شبکه '{$network}' نامعتبر است؛ باید عدد مثبت متناهی باشد."
            );
        }
        if (!is_finite($sharePercent)) {
            throw new \RuntimeException(
                "تنظیمات سهم کاربر شبکه '{$network}' نامعتبر است (NaN/INF)."
            );
        }
        $share = self::clampSharePercent($sharePercent);
        return [
            'base'  => AdVideoRewardDecimal::fromFloat($baseRate),
            'share' => bcdiv(AdVideoRewardDecimal::fromFloat($share), '100', 10),
        ];
    }

    /** سهم clamp‌شده در [0,100]؛ مقدار غیرمتناهی صفر می‌شود (مسیر نمایش هاب). */
    public static function clampSharePercent(float $sharePercent): float
    {
        if (!is_finite($sharePercent)) {
            return 0.0;
        }
        return max(0.0, min(100.0, $sharePercent));
    }

    /**
     * FIX-P3-ADP-020/021 — خواندن یکنواخت secret وب‌هوک: config() اولویت دارد،
     * AppSettings مسیر قدیمی مستند در SettingsCatalog است؛ خروجی همیشه trim
     * شده و رشته است (هرگز مقدار خام با فاصله/غیررشته‌ای hash نمی‌شود).
     */
    public static function webhookSecret(AppSettings $settings, string $network): string
    {
        $secret = config('services.' . $network . '.webhook_secret', $settings->get($network . '_webhook_secret', ''));
        return is_string($secret) ? trim($secret) : '';
    }
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * 1️⃣ آداپتور تبلیغات بومی تپسل (Tapsell) — واحد پولی: تومان (IRT)
 * ─────────────────────────────────────────────────────────────────────────────
 */
class TapsellVideoRewardAdapter implements AdVideoRewardAdapterInterface
{
    private const HMAC_WARN_INTERVAL = 60; // FIX-P3-ADP-020: پنجرهٔ rate-limit هشدار mismatch (ثانیه)

    private AppSettings $settings;
    private LoggerInterface $logger;
    private ?int $lastHmacWarnAt = null; // FIX-P3-ADP-020

    public function __construct(AppSettings $settings, LoggerInterface $logger) {
        $this->settings = $settings;
        $this->logger = $logger;
    }

    public function getNetworkName(): string { return 'tapsell'; }
    public function getCurrency(): string { return 'IRT'; }
    public function getBaseRate(): float { return $this->settings->getFloat('tapsell_base_rate_irt', 150.0); }
    public function getUserSharePercent(): float { return $this->settings->getFloat('tapsell_user_share', 70.0); }

    public function calculateUserPayout(): Money
    {
        // FIX-P3-ADP-017: bounds پیش از bcmul — share clamp به [0,100]، نرخ پایه مثبت/متناهی.
        $resolved = AdVideoRewardPayoutPolicy::resolve($this->getBaseRate(), $this->getUserSharePercent(), $this->getNetworkName());
        $payoutValue = bcmul($resolved['base'], $resolved['share'], 4); // FIX-R36-W3 (F-A19d-05)
        // FIX-P3-ADP-019: قطع (truncate) به تومان صحیح — سیاست رسمی مستند در سربرگ فایل.
        $payoutClean = bcdiv($payoutValue, '1', 0);
        return Money::fromString($payoutClean, 'IRT');
    }

    /** FIX-P3-ADP-021: بدون secret وب‌هوک، شبکه پیکربندی‌شده نیست. */
    public function isConfigured(): bool
    {
        return AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'tapsell') !== '';
    }

    public function verifyS2SHmac(string $rawBody, string $receivedSignature): bool
    {
        // FIX-P3-ADP-020: secret/امضا قبل از استفاده trim می‌شوند (قبلاً مقدار با
        // فاصلهٔ اضافه مستقیم hash می‌شد). زنجیرهٔ fallback به AppSettings مسیر
        // قدیمیِ مستند در SettingsCatalog است و عمداً حفظ شده (پرچم در سربرگ helper).
        $secret = AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'tapsell');
        $signature = trim($receivedSignature);
        if ($secret === '' || $signature === '') {
            $this->logger->warning('tapsell.webhook.hmac_configuration_invalid');
            return false;
        }
        $calculated = hash_hmac('sha256', $rawBody, $secret);
        $match = hash_equals($calculated, $signature);
        if (!$match) $this->warnHmacMismatchRateLimited('tapsell'); // FIX-P3-ADP-020: rate-limit
        return $match;
    }

    /** FIX-P3-ADP-020: هشدار mismatch حداکثر هر ۶۰ ثانیه (ضد سیل لاگ در حمله). */
    private function warnHmacMismatchRateLimited(string $network): void
    {
        $now = time();
        if ($this->lastHmacWarnAt !== null && ($now - $this->lastHmacWarnAt) < self::HMAC_WARN_INTERVAL) {
            return;
        }
        $this->lastHmacWarnAt = $now;
        $this->logger->warning($network . '.webhook.hmac_mismatch');
    }
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * 2️⃣ آداپتور تبلیغات بومی ادیوری (Adivery) — واحد پولی: تومان (IRT)
 * ─────────────────────────────────────────────────────────────────────────────
 */
class AdiveryVideoRewardAdapter implements AdVideoRewardAdapterInterface
{
    private const HMAC_WARN_INTERVAL = 60; // FIX-P3-ADP-020

    private AppSettings $settings;
    private LoggerInterface $logger;
    private ?int $lastHmacWarnAt = null; // FIX-P3-ADP-020

    public function __construct(AppSettings $settings, LoggerInterface $logger) {
        $this->settings = $settings;
        $this->logger = $logger;
    }

    public function getNetworkName(): string { return 'adivery'; }
    public function getCurrency(): string { return 'IRT'; }
    public function getBaseRate(): float { return $this->settings->getFloat('adivery_base_rate_irt', 140.0); }
    public function getUserSharePercent(): float { return $this->settings->getFloat('adivery_user_share', 70.0); }

    public function calculateUserPayout(): Money
    {
        // FIX-P3-ADP-017: bounds پیش از bcmul — share clamp به [0,100]، نرخ پایه مثبت/متناهی.
        $resolved = AdVideoRewardPayoutPolicy::resolve($this->getBaseRate(), $this->getUserSharePercent(), $this->getNetworkName());
        $payoutValue = bcmul($resolved['base'], $resolved['share'], 4); // FIX-R36-W3 (F-A19d-05)
        // FIX-P3-ADP-019: قطع (truncate) به تومان صحیح — سیاست رسمی مستند در سربرگ فایل.
        $payoutClean = bcdiv($payoutValue, '1', 0);
        return Money::fromString($payoutClean, 'IRT');
    }

    /** FIX-P3-ADP-021: بدون secret وب‌هوک، شبکه پیکربندی‌شده نیست. */
    public function isConfigured(): bool
    {
        return AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'adivery') !== '';
    }

    public function verifyS2SHmac(string $rawBody, string $receivedSignature): bool
    {
        // FIX-P3-ADP-020: secret/امضا قبل از استفاده trim می‌شوند.
        $secret = AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'adivery');
        $signature = trim($receivedSignature);
        if ($secret === '' || $signature === '') {
            $this->logger->warning('adivery.webhook.hmac_configuration_invalid');
            return false;
        }
        $calculated = hash_hmac('sha256', $rawBody, $secret);
        $match = hash_equals($calculated, $signature);
        if (!$match) $this->warnHmacMismatchRateLimited('adivery'); // FIX-P3-ADP-020: rate-limit
        return $match;
    }

    /** FIX-P3-ADP-020: هشدار mismatch حداکثر هر ۶۰ ثانیه (ضد سیل لاگ در حمله). */
    private function warnHmacMismatchRateLimited(string $network): void
    {
        $now = time();
        if ($this->lastHmacWarnAt !== null && ($now - $this->lastHmacWarnAt) < self::HMAC_WARN_INTERVAL) {
            return;
        }
        $this->lastHmacWarnAt = $now;
        $this->logger->warning($network . '.webhook.hmac_mismatch');
    }
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * 3️⃣ آداپتور تبلیغات بومی صباویژن (SabaVision) — واحد پولی: تومان (IRT)
 * ─────────────────────────────────────────────────────────────────────────────
 */
class SabaVisionVideoRewardAdapter implements AdVideoRewardAdapterInterface
{
    private const HMAC_WARN_INTERVAL = 60; // FIX-P3-ADP-020

    private AppSettings $settings;
    private LoggerInterface $logger;
    private ?int $lastHmacWarnAt = null; // FIX-P3-ADP-020

    public function __construct(AppSettings $settings, LoggerInterface $logger) {
        $this->settings = $settings;
        $this->logger = $logger;
    }

    public function getNetworkName(): string { return 'sabavision'; }
    public function getCurrency(): string { return 'IRT'; }
    public function getBaseRate(): float { return $this->settings->getFloat('sabavision_base_rate_irt', 160.0); }
    public function getUserSharePercent(): float { return $this->settings->getFloat('sabavision_user_share', 70.0); }

    public function calculateUserPayout(): Money
    {
        // FIX-P3-ADP-017: bounds پیش از bcmul — share clamp به [0,100]، نرخ پایه مثبت/متناهی.
        $resolved = AdVideoRewardPayoutPolicy::resolve($this->getBaseRate(), $this->getUserSharePercent(), $this->getNetworkName());
        $payoutValue = bcmul($resolved['base'], $resolved['share'], 4); // FIX-R36-W3 (F-A19d-05)
        // FIX-P3-ADP-019: قطع (truncate) به تومان صحیح — سیاست رسمی مستند در سربرگ فایل.
        $payoutClean = bcdiv($payoutValue, '1', 0);
        return Money::fromString($payoutClean, 'IRT');
    }

    /** FIX-P3-ADP-021: بدون secret وب‌هوک، شبکه پیکربندی‌شده نیست. */
    public function isConfigured(): bool
    {
        return AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'sabavision') !== '';
    }

    public function verifyS2SHmac(string $rawBody, string $receivedSignature): bool
    {
        // FIX-P3-ADP-020: secret/امضا قبل از استفاده trim می‌شوند.
        $secret = AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'sabavision');
        $signature = trim($receivedSignature);
        if ($secret === '' || $signature === '') {
            $this->logger->warning('sabavision.webhook.hmac_configuration_invalid');
            return false;
        }
        $calculated = hash_hmac('sha256', $rawBody, $secret);
        $match = hash_equals($calculated, $signature);
        if (!$match) $this->warnHmacMismatchRateLimited('sabavision'); // FIX-P3-ADP-020: rate-limit
        return $match;
    }

    /** FIX-P3-ADP-020: هشدار mismatch حداکثر هر ۶۰ ثانیه (ضد سیل لاگ در حمله). */
    private function warnHmacMismatchRateLimited(string $network): void
    {
        $now = time();
        if ($this->lastHmacWarnAt !== null && ($now - $this->lastHmacWarnAt) < self::HMAC_WARN_INTERVAL) {
            return;
        }
        $this->lastHmacWarnAt = $now;
        $this->logger->warning($network . '.webhook.hmac_mismatch');
    }
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * 4️⃣ آداپتور تبلیغات ارزی ادموب (AdMob) — واحد پولی: تتر (USDT)
 * ─────────────────────────────────────────────────────────────────────────────
 */
class AdMobVideoRewardAdapter implements AdVideoRewardAdapterInterface
{
    private const HMAC_WARN_INTERVAL = 60; // FIX-P3-ADP-020

    private AppSettings $settings;
    private LoggerInterface $logger;
    private ?int $lastHmacWarnAt = null; // FIX-P3-ADP-020

    public function __construct(AppSettings $settings, LoggerInterface $logger) {
        $this->settings = $settings;
        $this->logger = $logger;
    }

    public function getNetworkName(): string { return 'admob'; }
    public function getCurrency(): string { return 'USDT'; }
    public function getBaseRate(): float { return $this->settings->getFloat('admob_base_rate_usdt', 0.02); }
    public function getUserSharePercent(): float { return $this->settings->getFloat('admob_user_share', 70.0); }

    public function calculateUserPayout(): Money
    {
        // FIX-P3-ADP-017: bounds پیش از bcmul — share clamp به [0,100]، نرخ پایه مثبت/متناهی.
        $resolved = AdVideoRewardPayoutPolicy::resolve($this->getBaseRate(), $this->getUserSharePercent(), $this->getNetworkName());
        $payoutValue = bcmul($resolved['base'], $resolved['share'], 8); // FIX-R36-W3 (F-A19d-05)
        // FIX-P3-ADP-019: قطع (truncate) به ۴ رقم اعشار — سیاست رسمی مستند در سربرگ فایل.
        $payoutClean = bcdiv($payoutValue, '1', 4);
        return Money::fromString($payoutClean, 'USDT');
    }

    /** FIX-P3-ADP-021: بدون secret وب‌هوک، شبکه پیکربندی‌شده نیست. */
    public function isConfigured(): bool
    {
        return AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'admob') !== '';
    }

    public function verifyS2SHmac(string $rawBody, string $receivedSignature): bool
    {
        // FIX-P3-ADP-020: secret/امضا قبل از استفاده trim می‌شوند.
        $secret = AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'admob');
        $signature = trim($receivedSignature);
        if ($secret === '' || $signature === '') {
            $this->logger->warning('admob.webhook.hmac_configuration_invalid');
            return false;
        }
        $calculated = hash_hmac('sha256', $rawBody, $secret);
        $match = hash_equals($calculated, $signature);
        if (!$match) $this->warnHmacMismatchRateLimited('admob'); // FIX-P3-ADP-020: rate-limit
        return $match;
    }

    /** FIX-P3-ADP-020: هشدار mismatch حداکثر هر ۶۰ ثانیه (ضد سیل لاگ در حمله). */
    private function warnHmacMismatchRateLimited(string $network): void
    {
        $now = time();
        if ($this->lastHmacWarnAt !== null && ($now - $this->lastHmacWarnAt) < self::HMAC_WARN_INTERVAL) {
            return;
        }
        $this->lastHmacWarnAt = $now;
        $this->logger->warning($network . '.webhook.hmac_mismatch');
    }
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * 5️⃣ آداپتور تبلیغات ارزی یونیتی (Unity Ads) — واحد پولی: تتر (USDT)
 * ─────────────────────────────────────────────────────────────────────────────
 */
class UnityVideoRewardAdapter implements AdVideoRewardAdapterInterface
{
    private const HMAC_WARN_INTERVAL = 60; // FIX-P3-ADP-020

    private AppSettings $settings;
    private LoggerInterface $logger;
    private ?int $lastHmacWarnAt = null; // FIX-P3-ADP-020

    public function __construct(AppSettings $settings, LoggerInterface $logger) {
        $this->settings = $settings;
        $this->logger = $logger;
    }

    public function getNetworkName(): string { return 'unity'; }
    public function getCurrency(): string { return 'USDT'; }
    public function getBaseRate(): float { return $this->settings->getFloat('unity_base_rate_usdt', 0.025); }
    public function getUserSharePercent(): float { return $this->settings->getFloat('unity_user_share', 70.0); }

    public function calculateUserPayout(): Money
    {
        // FIX-P3-ADP-017: bounds پیش از bcmul — share clamp به [0,100]، نرخ پایه مثبت/متناهی.
        $resolved = AdVideoRewardPayoutPolicy::resolve($this->getBaseRate(), $this->getUserSharePercent(), $this->getNetworkName());
        $payoutValue = bcmul($resolved['base'], $resolved['share'], 8); // FIX-R36-W3 (F-A19d-05)
        // FIX-P3-ADP-019: قطع (truncate) به ۴ رقم اعشار — سیاست رسمی مستند در سربرگ فایل.
        $payoutClean = bcdiv($payoutValue, '1', 4);
        return Money::fromString($payoutClean, 'USDT');
    }

    /** FIX-P3-ADP-021: بدون secret وب‌هوک، شبکه پیکربندی‌شده نیست. */
    public function isConfigured(): bool
    {
        return AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'unity') !== '';
    }

    public function verifyS2SHmac(string $rawBody, string $receivedSignature): bool
    {
        // FIX-P3-ADP-020: secret/امضا قبل از استفاده trim می‌شوند.
        $secret = AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'unity');
        $signature = trim($receivedSignature);
        if ($secret === '' || $signature === '') {
            $this->logger->warning('unity.webhook.hmac_configuration_invalid');
            return false;
        }
        $calculated = hash_hmac('sha256', $rawBody, $secret);
        $match = hash_equals($calculated, $signature);
        if (!$match) $this->warnHmacMismatchRateLimited('unity'); // FIX-P3-ADP-020: rate-limit
        return $match;
    }

    /** FIX-P3-ADP-020: هشدار mismatch حداکثر هر ۶۰ ثانیه (ضد سیل لاگ در حمله). */
    private function warnHmacMismatchRateLimited(string $network): void
    {
        $now = time();
        if ($this->lastHmacWarnAt !== null && ($now - $this->lastHmacWarnAt) < self::HMAC_WARN_INTERVAL) {
            return;
        }
        $this->lastHmacWarnAt = $now;
        $this->logger->warning($network . '.webhook.hmac_mismatch');
    }
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * 6️⃣ آداپتور تبلیغات ارزی اپ‌لاوین (AppLovin MAX) — واحد پولی: تتر (USDT)
 * ─────────────────────────────────────────────────────────────────────────────
 */
class AppLovinVideoRewardAdapter implements AdVideoRewardAdapterInterface
{
    private const HMAC_WARN_INTERVAL = 60; // FIX-P3-ADP-020

    private AppSettings $settings;
    private LoggerInterface $logger;
    private ?int $lastHmacWarnAt = null; // FIX-P3-ADP-020

    public function __construct(AppSettings $settings, LoggerInterface $logger) {
        $this->settings = $settings;
        $this->logger = $logger;
    }

    public function getNetworkName(): string { return 'applovin'; }
    public function getCurrency(): string { return 'USDT'; }
    public function getBaseRate(): float { return $this->settings->getFloat('applovin_base_rate_usdt', 0.018); }
    public function getUserSharePercent(): float { return $this->settings->getFloat('applovin_user_share', 70.0); }

    public function calculateUserPayout(): Money
    {
        // FIX-P3-ADP-017: bounds پیش از bcmul — share clamp به [0,100]، نرخ پایه مثبت/متناهی.
        $resolved = AdVideoRewardPayoutPolicy::resolve($this->getBaseRate(), $this->getUserSharePercent(), $this->getNetworkName());
        $payoutValue = bcmul($resolved['base'], $resolved['share'], 8); // FIX-R36-W3 (F-A19d-05)
        // FIX-P3-ADP-019: قطع (truncate) به ۴ رقم اعشار — سیاست رسمی مستند در سربرگ فایل.
        $payoutClean = bcdiv($payoutValue, '1', 4);
        return Money::fromString($payoutClean, 'USDT');
    }

    /** FIX-P3-ADP-021: بدون secret وب‌هوک، شبکه پیکربندی‌شده نیست. */
    public function isConfigured(): bool
    {
        return AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'applovin') !== '';
    }

    public function verifyS2SHmac(string $rawBody, string $receivedSignature): bool
    {
        // FIX-P3-ADP-020: secret/امضا قبل از استفاده trim می‌شوند.
        $secret = AdVideoRewardPayoutPolicy::webhookSecret($this->settings, 'applovin');
        $signature = trim($receivedSignature);
        if ($secret === '' || $signature === '') {
            $this->logger->warning('applovin.webhook.hmac_configuration_invalid');
            return false;
        }
        $calculated = hash_hmac('sha256', $rawBody, $secret);
        $match = hash_equals($calculated, $signature);
        if (!$match) $this->warnHmacMismatchRateLimited('applovin'); // FIX-P3-ADP-020: rate-limit
        return $match;
    }

    /** FIX-P3-ADP-020: هشدار mismatch حداکثر هر ۶۰ ثانیه (ضد سیل لاگ در حمله). */
    private function warnHmacMismatchRateLimited(string $network): void
    {
        $now = time();
        if ($this->lastHmacWarnAt !== null && ($now - $this->lastHmacWarnAt) < self::HMAC_WARN_INTERVAL) {
            return;
        }
        $this->lastHmacWarnAt = $now;
        $this->logger->warning($network . '.webhook.hmac_mismatch');
    }
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * هسته مرکزی مدیریت آداپتورها (AdVideoRewardManager)
 * ─────────────────────────────────────────────────────────────────────────────
 */
class AdVideoRewardManager
{
    /** @var array<string, AdVideoRewardAdapterInterface> */
    private array $adapters = [];
    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger, AppSettings $settings) {
        $this->logger = $logger;
        // ثبت خودکار آداپتورهای بومی (تومانی) و بین‌المللی (تتری)
        $this->adapters['tapsell']    = new TapsellVideoRewardAdapter($settings, $logger);
        $this->adapters['adivery']    = new AdiveryVideoRewardAdapter($settings, $logger);
        $this->adapters['sabavision'] = new SabaVisionVideoRewardAdapter($settings, $logger);
        $this->adapters['admob']      = new AdMobVideoRewardAdapter($settings, $logger);
        $this->adapters['unity']      = new UnityVideoRewardAdapter($settings, $logger);
        $this->adapters['applovin']   = new AppLovinVideoRewardAdapter($settings, $logger);
    }

    public function getAdapter(string $network): AdVideoRewardAdapterInterface
    {
        $network = strtolower(trim((string)$network));
        if (!isset($this->adapters[$network])) {
            throw new \InvalidArgumentException("آداپتور تبلیغاتی برای شبکه '{$network}' یافت نشد.");
        }
        return $this->adapters[$network];
    }

    /**
     * دریافت لیست پاداش‌های در دسترس جهت نمایش در هاب کاربری
     */
    /** @return array<string, mixed> */
    public function getAvailableRewardAds(): array
    {
        $ads = [];
        $meta = [
            'tapsell'    => ['title' => 'کمپین تبلیغاتی تپسل (Tapsell)', 'desc' => 'تماشای ویدیوهای تبلیغاتی کوتاه بومی و دریافت آنی پاداش تومانی'],
            'adivery'    => ['title' => 'شبکه هوشمند ادیوری (Adivery)', 'desc' => 'پخش هوشمند سودآورترین ویدیوهای تبلیغاتی بومی با تسویه تومانی'],
            'sabavision' => ['title' => 'شبکه تبلیغاتی صباویژن (SabaVision)', 'desc' => 'تماشای تیزرهای ویدیویی اختصاصی برندهای برتر ایران و کسب درآمد تومانی'],
            'admob'      => ['title' => 'تبلیغات بین‌المللی ادموب (AdMob)', 'desc' => 'تماشای ویدیوهای تبلیغاتی خارجی و دریافت پاداش ارزی بر پایه تتر (USDT)'],
            'unity'      => ['title' => 'شبکه دلاری یونیتی (Unity Ads)', 'desc' => 'پخش تیزر بازی‌های ویدیویی بین‌المللی و کسب درآمد تتری با کیفیت HD'],
            'applovin'   => ['title' => 'شبکه ارزی اپ‌لاوین (AppLovin MAX)', 'desc' => 'تماشای تبلیغات ثانیه‌ای پربازده بین‌المللی با تسویه سریع تتری'],
        ];

        foreach ($this->adapters as $network => $adapter) {
            try {
                $ads[$network] = [
                    'network'            => $network,
                    'currency'           => $adapter->getCurrency(),
                    'base_rate'          => $adapter->getBaseRate(),
                    // FIX-P3-ADP-017: سهم نمایشی هم clamp‌شدهٔ [0,100] است (هم‌پوشان با payout واقعی).
                    'user_share_percent' => AdVideoRewardPayoutPolicy::clampSharePercent($adapter->getUserSharePercent()),
                    'payout_amount'      => $adapter->calculateUserPayout()->getAmount(),
                    'title'              => $meta[$network]['title'],
                    'description'        => $meta[$network]['desc'],
                    'duration_seconds'   => 15,
                    // FIX-P3-ADP-021: is_active از پیکربندی واقعی مشتق می‌شود — provider
                    // پیکربندی‌نشده (بدون secret وب‌هوک) به‌عنوان فعال تبلیغ نمی‌شود.
                    'is_active'          => $adapter->isConfigured(),
                ];
            } catch (\Throwable $e) {
                // FIX-P3-ADP-017: تنظیمات بی‌معنا (نرخ/سهم) → شکست سریعِ آداپتور →
                // این‌جا شبکه حذف می‌شود (log + skip) نه نمایش پاداش ساختگی.
                $this->logger->warning('video_reward.manager.calculate_payout_failed', ['network' => $network, 'error' => $e->getMessage()]);
            }
        }
        return $ads;
    }
}
