<?php

declare(strict_types=1);

namespace App\Adapters;

use App\Contracts\LoggerInterface;
use App\Traits\ExternalCallTrait;
use Core\CircuitBreaker;

/**
 * DeepFaceKycAdapter
 * پیاده‌سازی برای فراخوانی یک میکروسرویس هوش مصنوعی (مثلاً پایتونی خودمیزبان یا کلود)
 * جهت بررسی وجود چهره، تشخیص زنده‌بودن (Liveness) و جلوگیری از تقلب در تصاویر ارسالی KYC.
 *
 * Section 8.3/8.4 — کل HTTP call داخل Core\CircuitBreaker انجام می‌شود و خطاهای
 * transient (timeout, 5xx) با retryTransient() تکرار می‌شوند. خطاهای 4xx
 * permanent محسوب شده و بدون retry پاس می‌شوند.
 *
 * FIX-P3 (p3-crypto round):
 *  - ADP-072/073: سرویس پیکربندی‌نشده / فایل ناموجود هرگز «is_valid=true» نمی‌دهند
 *    (fail-closed + needs_manual_review)؛ نبود سرویس و نبود فایل خطای سیستم است.
 *  - ADP-074: مسیر آپلود فقط پس از realpath + containment در ریشهٔ مجاز
 *    (services.deepface.allowed_base_dir، پیش‌فرض storage/uploads) + allowlist
 *    پسوند/MIME + is_readable قابل ارسال است (ضد path-traversal/file-disclosure).
 *  - ADP-075: مسیرهای SSRF-block و پاسخ نامعتبر fail-closed شدند؛ fallback خطای
 *    کلی به manual review می‌ماند اما متن exception دیگر در ai_notes نشت نمی‌کند.
 *  - ADP-076: timeout کل روی بازهٔ ۵..۱۲۰ ثانیه clamp می‌شود.
 *  - ADP-077: پاسخ AI با schema سخت‌گیرانه اعتبارسنجی می‌شود (verified فقط bool؛
 *    confidence به [0,1] clamp؛ notes پاک‌سازی و سقف‌دار).
 *  - ADP-078: سقف حجم فایل آپلود (10MB) و سقف حجم پاسخ HTTP (2MiB).
 *  - ADP-079: هر فراخوانی تحلیل یک کلید idempotency یکتا (X-Idempotency-Key /
 *    X-Request-Id) می‌فرستد و برای endpoint پولی حداکثر ۲ تلاش transient انجام می‌شود.
 */
class DeepFaceKycAdapter implements KycFaceVerificationAdapter
{
    use \App\Traits\ValidatesExternalUrl;
    use ExternalCallTrait;

    // FIX-P3-ADP-076: بازهٔ مجاز timeout کل برای تحلیل AI
    private const MIN_TIMEOUT_SECONDS = 5;
    private const MAX_TIMEOUT_SECONDS = 120;
    private const DEFAULT_TIMEOUT_SECONDS = 30;

    // FIX-P3-ADP-078: سقف حجم فایل آپلود و سقف حجم پاسخ HTTP
    private const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;   // 10 MB
    private const MAX_RESPONSE_BYTES = 2 * 1024 * 1024;  // 2 MiB

    // FIX-P3-ADP-074: allowlist پسوند/MIME برای تصاویر بیومتریک
    private const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    private const ALLOWED_MIMES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

    // FIX-P3-ADP-077: سقف طول ai_notes
    private const MAX_NOTES_CHARS = 500;

    // FIX-P3-ADP-079: endpoint پولی — حداکثر ۲ تلاش transient
    private const AI_MAX_ATTEMPTS = 2;

    private ?string $apiUrl;
    private ?string $apiToken;
    private LoggerInterface $logger;

    /**
     * @internal exposed for ExternalCallTrait::resolveCircuitBreaker()
     */
    protected CircuitBreaker $circuitBreaker;

    public function __construct(LoggerInterface $logger, CircuitBreaker $circuitBreaker) {
        $this->logger = $logger;
        $this->circuitBreaker = $circuitBreaker;
        // این تنظیمات از فایل .env خوانده می‌شوند.
        $apiUrl = config('services.deepface.api_url');
        $apiToken = config('services.deepface.api_token');
        $this->apiUrl = is_string($apiUrl) ? $apiUrl : null;
        $this->apiToken = is_string($apiToken) ? $apiToken : null;
    }

    public function isConfigured(): bool
    {
        return !empty($this->apiUrl);
    }

    /**
     * بررسی تصویر از طریق ارسال آن به هوش مصنوعی
     *
     * @return array<string, mixed>
     */
    public function analyzeImage(string $absoluteFilePath): array
    {
        // FIX-P3-ADP-072: نبودِ سرویس هرگز «تأیید» تلقی نمی‌شود — fail-closed +
        // needs_manual_review؛ failure به‌صورت قابل‌مشاهده ثبت می‌شود.
        if (!$this->isConfigured()) {
            $this->logger->warning('deepface_kyc.service_unconfigured', []);
            return [
                'success' => false,
                'is_valid' => false,
                'needs_manual_review' => true,
                'ai_notes' => 'سرویس هوش مصنوعی پیکربندی نشده است؛ بررسی دستی لازم است.',
            ];
        }

        // FIX-P3-ADP-074/078: containment + allowlist + سقف حجم، پیش از هر HTTP call
        $validatedFile = $this->validateUploadFile($absoluteFilePath);
        if (!is_array($validatedFile)) {
            // دلیل دقیق در لاگ (deepface_kyc.file_rejected) ثبت شده است.
            return [
                'success' => false,
                'is_valid' => false,
                'needs_manual_review' => true,
                'ai_notes' => 'فایل تصویر برای تحلیل معتبر نیست؛ بررسی دستی لازم است.',
            ];
        }

        // FIX-P3-ADP-076: timeout با clamp صریح
        $timeout = self::clampTimeout(config('services.deepface.timeout', self::DEFAULT_TIMEOUT_SECONDS));
        $connectTimeout = max(3, (int)floor($timeout / 4));
        $apiUrl   = $this->apiUrl;
        $apiToken = $this->apiToken;
        if (!$this->isExternalUrlSafe((string)$apiUrl)) {
            $this->logger->error('deepface_kyc.ssrf_blocked', ['host' => parse_url((string)$apiUrl, PHP_URL_HOST)]);
            // FIX-P3-ADP-075: مسیر SSRF-block fail-closed شد (قبلاً is_valid=true بود)
            return [
                'success' => false,
                'is_valid' => false,
                'needs_manual_review' => true,
                'ai_notes' => 'آدرس سرویس هوش مصنوعی از نظر امنیتی مجاز نیست؛ بررسی دستی لازم است.',
            ];
        }

        // FIX-P3-ADP-079: کلید idempotency یکتا برای کل فراخوانی منطقی (تکرارهای
        // transient همان کلید را می‌فرستند تا ارائه‌دهندهٔ سازگار، دوباره‌کاری نکند)
        $idempotencyKey = 'kyc-' . bin2hex(random_bytes(16));
        $requestHeaders = $this->buildRequestHeaders($apiToken, $idempotencyKey);

        try {
            // CB + retry روی فراخوانی AI — یک curl handle جدید در هر retry تا
            // در صورت خطای انتقال داده، state تمیز بماند.
            $responseRaw = $this->callWithBreaker('deepface_kyc', function () use ($apiUrl, $requestHeaders, $validatedFile, $timeout, $connectTimeout): string {
                return $this->retryTransient(function () use ($apiUrl, $requestHeaders, $validatedFile, $timeout, $connectTimeout): string {
                    $ch = curl_init();
                    try {
                        $cFile = new \CURLFile($validatedFile['path'], $validatedFile['mime'], $validatedFile['name']);
                        $postData = ['image' => $cFile];

                        curl_setopt_array($ch, [
                            CURLOPT_URL => $apiUrl,
                            CURLOPT_POST => true,
                            CURLOPT_POSTFIELDS => $postData,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_TIMEOUT => $timeout,                    // Total timeout for AI analysis (FIX-P3-ADP-076: clamped)
                            CURLOPT_CONNECTTIMEOUT => $connectTimeout,      // Connection timeout
                            CURLOPT_DNS_CACHE_TIMEOUT => 120,               // Cache DNS
                            // FIX (Round-18 P2): TLS verification on biometric uploads must
                            // never be config-disableable (audit Round-18) — hardcoded on.
                            CURLOPT_SSL_VERIFYPEER => true,
                            CURLOPT_FAILONERROR => false,                   // Don't fail silently
                            // FIX-P3-ADP-078: سقف حجم پاسخ HTTP
                            CURLOPT_MAXFILESIZE => self::MAX_RESPONSE_BYTES,
                        ]);

                        if ($requestHeaders !== []) {
                            curl_setopt($ch, CURLOPT_HTTPHEADER, $requestHeaders); // FIX-P3-ADP-079
                        }

                        $raw  = curl_exec($ch);
                        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                        $errno = (int) curl_errno($ch);
                    } finally {
                        @curl_close($ch);
                    }

                    if ($code === 200 && is_string($raw) && $raw !== '' && strlen($raw) <= self::MAX_RESPONSE_BYTES) {
                        return $raw;
                    }

                    if (is_string($raw) && strlen($raw) > self::MAX_RESPONSE_BYTES) {
                        // FIX-P3-ADP-078: پاسخ بیش از سقف — مثل errno 63 (FILESIZE_EXCEEDED) → transient
                        $this->logger->warning('deepface_kyc.response_too_large', ['bytes' => strlen($raw)]);
                        throw $this->classifyHttpFailure(0, 63, '', ['provider' => 'deepface_kyc']);
                    }

                    // طبقه‌بندی استاندارد: 4xx → PermanentFailure (no retry)،
                    // 5xx/timeout/network → Transient/Provider (retry)
                    throw $this->classifyHttpFailure($code, $errno, (string)$raw, ['provider' => 'deepface_kyc']);
                }, self::AI_MAX_ATTEMPTS, 500, 4000);
            });

            // FIX-P3-ADP-075/077: پاسخ با schema/bounds سخت‌گیرانه تفسیر می‌شود؛
            // پاسخ نامعتبر fail-closed است (قبلاً is_valid=true برمی‌گشت).
            return $this->interpretAiResponse((string)$responseRaw, basename($absoluteFilePath));

        } catch (\Core\Exceptions\PermanentFailure $e) {
            // 4xx از سرویس AI: درخواست نامعتبر — بازگشت به مسیر دستی
            $this->logger->warning('kyc.ai.permanent_failure', [
                'error' => $e->getMessage(),
                'file' => basename($absoluteFilePath),
            ]);
            return [
                'success' => false,
                'is_valid' => false,
                'needs_manual_review' => true,
                'ai_notes' => 'پاسخ نامعتبر از سرویس هوش مصنوعی.',
            ];
        } catch (\Throwable $e) {
            // CB-open، یا transient که پس از retry هم برطرف نشد، یا خطای داخلی
            $this->logger->error('kyc.ai.failed', [
                'error' => $e->getMessage(),
                'class' => get_class($e),
                'file' => basename($absoluteFilePath)
            ]);

            // FIX-P3-ADP-075: fallback به manual review حفظ شد (تصمیم صریح brief)،
            // اما متن exception دیگر در ai_notes نشت نمی‌کند؛ جزئیات فقط در لاگ است.
            return [
                'success' => false,
                'is_valid' => true, // Fallback to manual review
                'needs_manual_review' => true,
                'ai_notes' => 'خطا در تحلیل هوش مصنوعی؛ بررسی دستی لازم است.'
            ];
        }
    }

    /**
     * FIX-P3-ADP-074/078: اعتبارسنجی کامل فایل پیش از آپلود — realpath containment
     * در ریشهٔ مجاز، is_file/is_readable، allowlist پسوند، سقف حجم، و sniffing MIME
     * با finfo (اعتماد به محتوا، نه نام فایل).
     *
     * @return array{path: string, mime: string, name: string}|null
     */
    private function validateUploadFile(string $absoluteFilePath): ?array
    {
        $basename = basename($absoluteFilePath);

        $baseDir = $this->allowedBaseDir();
        $real = realpath($absoluteFilePath);
        if ($baseDir === null || $real === false) {
            $this->logger->warning('deepface_kyc.file_rejected', ['file' => $basename, 'reason' => 'unresolved_path']);
            return null;
        }
        if (!str_starts_with($real, $baseDir . DIRECTORY_SEPARATOR)) {
            $this->logger->warning('deepface_kyc.file_rejected', ['file' => $basename, 'reason' => 'outside_base_dir']);
            return null;
        }
        if (!is_file($real) || !is_readable($real)) {
            $this->logger->warning('deepface_kyc.file_rejected', ['file' => $basename, 'reason' => 'not_readable_file']);
            return null;
        }
        $ext = strtolower(pathinfo($real, PATHINFO_EXTENSION));
        if (!in_array($ext, self::ALLOWED_EXTENSIONS, true)) {
            $this->logger->warning('deepface_kyc.file_rejected', ['file' => $basename, 'reason' => 'extension_not_allowed', 'ext' => $ext]);
            return null;
        }
        $size = (int)filesize($real);
        if ($size <= 0 || $size > self::MAX_UPLOAD_BYTES) {
            $this->logger->warning('deepface_kyc.file_rejected', ['file' => $basename, 'reason' => 'size_out_of_range', 'size' => $size]);
            return null;
        }
        $mime = 'application/octet-stream';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo !== false) {
                $sniffed = finfo_file($finfo, $real);
                if (is_string($sniffed) && $sniffed !== '') {
                    $mime = strtolower($sniffed);
                }
                finfo_close($finfo);
            }
        }
        if (!in_array($mime, self::ALLOWED_MIMES, true)) {
            $this->logger->warning('deepface_kyc.file_rejected', ['file' => $basename, 'reason' => 'mime_not_allowed', 'mime' => $mime]);
            return null;
        }

        return ['path' => $real, 'mime' => $mime, 'name' => $basename];
    }

    /**
     * FIX-P3-ADP-074: ریشهٔ مجاز فایل‌های بیومتریک. کلید تنظیمی
     * services.deepface.allowed_base_dir اولویت دارد؛ پیش‌فرض storage/uploads
     * (هم‌محلِ خروجی UploadService::getPath('kyc/...')). تعیین‌نشده/تعویض‌ناپذیر → null (fail-closed).
     */
    private function allowedBaseDir(): ?string
    {
        $configured = config('services.deepface.allowed_base_dir');
        $raw = is_string($configured) && $configured !== ''
            ? $configured
            : (function_exists('storage_path') ? (string)storage_path('uploads') : '');
        if ($raw === '') {
            return null;
        }
        $real = realpath($raw);
        return is_string($real) && $real !== '' ? $real : null;
    }

    /** FIX-P3-ADP-076: clamp بازهٔ timeout کل (۵..۱۲۰ ثانیه). */
    private static function clampTimeout(mixed $raw): int
    {
        $value = is_numeric($raw) ? (int)floor((float)$raw) : self::DEFAULT_TIMEOUT_SECONDS;
        return max(self::MIN_TIMEOUT_SECONDS, min(self::MAX_TIMEOUT_SECONDS, $value));
    }

    /**
     * FIX-P3-ADP-079: هدرهای درخواست — Bearer اختیاری + کلید idempotency یکتا
     * (X-Idempotency-Key و X-Request-Id) برای جلوگیری از دوباره‌کاریِ تحلیل پولی در retry.
     *
     * @return list<string>
     */
    private function buildRequestHeaders(?string $apiToken, string $idempotencyKey): array
    {
        $headers = [];
        if (is_string($apiToken) && $apiToken !== '') {
            $headers[] = 'Authorization: Bearer ' . $apiToken;
        }
        $headers[] = 'X-Idempotency-Key: ' . $idempotencyKey;
        $headers[] = 'X-Request-Id: ' . $idempotencyKey;
        return $headers;
    }

    /**
     * FIX-P3-ADP-075/077/078: تفسیر سخت‌گیرانهٔ پاسخ AI.
     * پاسخ خالی/بزرگ‌تر از سقف/غیر-JSON/خارج از schema = fail-closed
     * (success=false، is_valid=false، needs_manual_review=true).
     *
     * @return array<string, mixed>
     */
    private function interpretAiResponse(string $raw, string $fileBasename): array
    {
        if ($raw === '' || strlen($raw) > self::MAX_RESPONSE_BYTES) {
            $this->logger->warning('kyc.ai.response_unusable', ['file' => $fileBasename, 'bytes' => strlen($raw)]);
            return $this->invalidAiResult('پاسخ سرویس هوش مصنوعی قابل استفاده نبود؛ بررسی دستی لازم است.');
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded) || json_last_error() !== JSON_ERROR_NONE) {
            $this->logger->warning('kyc.ai.malformed_response', [
                'json_error' => json_last_error_msg(),
                'file' => $fileBasename,
            ]);
            return $this->invalidAiResult('پاسخ سرویس هوش مصنوعی نامعتبر بود؛ بررسی دستی لازم است.');
        }

        // مفروضات خروجی میکروسرویس AI:
        // { "verified": true, "confidence": 0.98, "has_face": true, "error_code": 0 }
        // FIX-P3-ADP-077: verified فقط bool معتبر است — بقیهٔ مقادیر نقض schema است
        $verified = $decoded['verified'] ?? null;
        if (!is_bool($verified)) {
            $this->logger->warning('kyc.ai.schema_violation', [
                'file' => $fileBasename,
                'field' => 'verified',
                'type' => get_debug_type($verified),
            ]);
            return $this->invalidAiResult('پاسخ سرویس هوش مصنوعی مطابق الگوی مورد انتظار نبود؛ بررسی دستی لازم است.');
        }

        // FIX-P3-ADP-077: confidence عددی به [0,1] clamp می‌شود؛ مقدار نامعتبر → 0.0
        $confidenceRaw = $decoded['confidence'] ?? 0.0;
        if (is_int($confidenceRaw) || is_float($confidenceRaw)) {
            $confidence = (float)$confidenceRaw;
        } elseif (is_string($confidenceRaw) && is_numeric($confidenceRaw)) {
            $confidence = (float)$confidenceRaw;
        } else {
            $confidence = 0.0;
        }
        if ($confidence < 0.0) {
            $confidence = 0.0;
        }
        if ($confidence > 1.0) {
            $confidence = 1.0;
        }

        // FIX-P3-ADP-077: notes هر نوع/اندازه‌ای نبود — پاک‌سازی کاراکترهای کنترلی + سقف
        $notesRaw = $decoded['notes'] ?? null;
        if (is_string($notesRaw) && $notesRaw !== '') {
            $notes = trim((string)preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $notesRaw));
            if (mb_strlen($notes) > self::MAX_NOTES_CHARS) {
                $notes = mb_substr($notes, 0, self::MAX_NOTES_CHARS) . '…';
            }
        } else {
            $notes = 'تحلیل با موفقیت انجام شد.';
        }

        $this->logger->info('kyc.ai.analyzed', [
            'file' => $fileBasename,
            'is_valid' => $verified,
            'confidence' => $confidence
        ]);

        return [
            'success' => true,
            'is_valid' => $verified,
            'confidence' => $confidence,
            'ai_notes' => $notes
        ];
    }

    /**
     * FIX-P3-ADP-072/073/075: نتیجهٔ استاندارد نامعتبر — هرگز «is_valid=true» نیست.
     *
     * @return array<string, mixed>
     */
    private function invalidAiResult(string $note): array
    {
        return [
            'success' => false,
            'is_valid' => false,
            'needs_manual_review' => true,
            'ai_notes' => $note,
        ];
    }
}
