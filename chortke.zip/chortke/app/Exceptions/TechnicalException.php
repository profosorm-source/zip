<?php

declare(strict_types=1);

namespace App\Exceptions;

/**
 * TechnicalException - خطای فنیِ زیرساختی (FIX-S34-B14-F14 — گزارش بخش ۱۴)
 *
 * این کلاس مرزِ «پیام امن کاربر-رو» و «جزئیات فنی» را صریح می‌کند:
 * - BusinessException → پیام دامنه، امن برای نمایش مستقیم به کاربر (422).
 * - TechnicalException → خطای زیرساخت/وابستگی (DB، Outbox، مدل، …)؛ متن آن فقط
 *   برای لاگ/Sentry است و در پاسخ وب/API باید با پیام عمومی جایگزین شود.
 *
 * عمداً از \RuntimeException ارث‌بری می‌کند تا همهٔ catchهای موجودِ
 * RuntimeException بدون تغییر رفتار کنند (سازگاری رو‌به‌عقب)؛ کنترلرها برای
 * پیام عمومی، فقط کافی است TechnicalException را «قبل از» RuntimeException
 * بگیرند.
 */
class TechnicalException extends \RuntimeException
{
}
