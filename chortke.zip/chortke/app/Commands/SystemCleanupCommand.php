<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\CommandInterface;

/**
 * System Cleanup Command
 */
class SystemCleanupCommand implements CommandInterface
{
    public function __construct() {
        // Constructor اختیاری
    }

    /** @param array<string, mixed> $args */

    public function run(array $args = []): int
    {
        // FIX-R36-W3 (F-A19e-10): پیام قبلی «پاکسازی با موفقیت انجام شد (نسخه موقتی)»
        // برای اپس/کرون گمراه‌کننده بود — این کامند هیچ عملیات پاکسازی واقعی انجام
        // نمی‌دهد (stub). خروجی اکنون صادقانه است؛ پیاده‌سازی واقعی (اتصال به
        // سرویس‌های cleanup موجود: SecurityLog/PerformanceLog/SystemLog
        // deleteOlderThanChunked، FeatureFlag::cleanupMetrics، EscrowCleanupCommand،
        // ProcessScheduledTasksCommand::deleteExpiredExports) یا حذف از bootstrap =
        // پیشنهاد رجیستر (نیازمند تصمیم مالک cron).
        $this->output("[SystemCleanupCommand] ⚠️  این کامند در حال حاضر عملیات پاکسازی واقعی انجام نمی‌دهد (stub).\n");
        $this->output("هیچ رکوردی حذف نشد و هیچ سرویسی فراخوانی نشد.\n");
        $this->output("پاکسازی‌های واقعی موجود: ProcessScheduledTasksCommand (ساعت‌بندی‌شده) و EscrowCleanupCommand.\n");
        $this->output("[SystemCleanupCommand] پایان — وضعیت: NO-OP (هیچ عملیاتی انجام نشد).\n");
        return 0; // FIX-C61: قرارداد کد خروج اینترفیس
    }

    /**
     * 🛡️ خروجی هوشمند و تشخیص استریم‌های غیرتعاملی (Non-TTY TTY Log Stripping Guard)
     * حذف خودکار کدهای رنگی ANSI در زمان اجرای دیمن‌ها در داکر، کرون و کوبرنتیز جهت جلوگیری از درج کاراکترهای فاسد در سیستم‌های لاگ
     */
    private function output(string $message, bool $isErr = false): void
    {
        // FIX-P3-CMD-136 (یافتهٔ ۱۳۶): هر دو ثابت STDIN-family گارد می‌شوند —
        // قبلاً نبودِ STDERR به STDOUT ارجاع می‌داد (و نبودِ STDOUT در SAPIهای
        // غیر-CLI به یک ثابت تعریف‌نشده). اکنون fallback نهایی echo است.
        $stream = null;
        if ($isErr && defined('STDERR')) {
            $stream = STDERR;
        } elseif (defined('STDOUT')) {
            $stream = STDOUT;
        }

        $isTty = $stream !== null && function_exists('stream_isatty') && @stream_isatty($stream);
        if (!$isTty) {
            $message = (string)preg_replace('/\033\[[0-9;]*m/', '', $message);
        }

        if ($stream !== null) {
            fwrite($stream, $message);
            fflush($stream);
        } else {
            echo $message;
        }
    }
}
