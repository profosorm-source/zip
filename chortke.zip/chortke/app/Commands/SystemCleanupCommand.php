<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\CommandInterface;

/**
 * System Cleanup Command
 */
class SystemCleanupCommand implements CommandInterface
{
    public function __construct() {
        // Constructor اختیاری
    }

    /** @param array<string, mixed> $args */

    public function run(array $args = []): void
    {
        // FIX-R36-W3 (F-A19e-10): پیام قبلی «پاکسازی با موفقیت انجام شد (نسخه موقتی)»
        // برای اپس/کرون گمراه‌کننده بود — این کامند هیچ عملیات پاکسازی واقعی انجام
        // نمی‌دهد (stub). خروجی اکنون صادقانه است؛ پیاده‌سازی واقعی (اتصال به
        // سرویس‌های cleanup موجود: SecurityLog/PerformanceLog/SystemLog
        // deleteOlderThanChunked، FeatureFlag::cleanupMetrics، EscrowCleanupCommand،
        // ProcessScheduledTasksCommand::deleteExpiredExports) یا حذف از bootstrap =
        // پیشنهاد رجیستر (نیازمند تصمیم مالک cron).
        $this->output("[SystemCleanupCommand] ⚠️  این کامند در حال حاضر عملیات پاکسازی واقعی انجام نمی‌دهد (stub).\n");
        $this->output("هیچ رکوردی حذف نشد و هیچ سرویسی فراخوانی نشد.\n");
        $this->output("پاکسازی‌های واقعی موجود: ProcessScheduledTasksCommand (ساعت‌بندی‌شده) و EscrowCleanupCommand.\n");
        $this->output("[SystemCleanupCommand] پایان — وضعیت: NO-OP (هیچ عملیاتی انجام نشد).\n");
    }

    /**
     * 🛡️ خروجی هوشمند و تشخیص استریم‌های غیرتعاملی (Non-TTY TTY Log Stripping Guard)
     * حذف خودکار کدهای رنگی ANSI در زمان اجرای دیمن‌ها در داکر، کرون و کوبرنتیز جهت جلوگیری از درج کاراکترهای فاسد در سیستم‌های لاگ
     */
    private function output(string $message, bool $isErr = false): void
    {
        $stream = $isErr ? (defined('STDERR') ? STDERR : STDOUT) : STDOUT;
        if (!function_exists('stream_isatty') || !stream_isatty($stream)) {
            $message = (string)preg_replace('/\033\[[0-9;]*m/', '', $message);
        }
        if ($stream !== STDOUT && defined('STDERR')) {
            fwrite(STDERR, $message);
            fflush(STDERR);
        } else {
            echo $message;
        }
    }
}
