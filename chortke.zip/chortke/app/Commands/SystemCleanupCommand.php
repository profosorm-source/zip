<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\CommandInterface;
use App\Services\Settings\AppSettings;
use Core\Container;

/**
 * System Cleanup Command — 🛡️ F21-01/V7 (۲۰۲۶-۱۰-۲۲، بازسازی ۲۰۲۶-۱۰-۲۴)
 *
 * پاکسازیِ نگهداری‌محورِ رکوردهای راستی‌آزمایی دوربین:
 *   ۱) حذف رکوردهای social_camera_requests قدیمی‌تر از camera_retention_days
 *      (کلید پنل، پیش‌فرض ۳۰ روز؛ بازهٔ مجاز ۱..۳۶۵۰).
 *   ۲) انقضای رکوردهای pending که expires_atشان گذشته ولی هنوز 'pending'‌اند
 *      (سوئیپ سراسری — مکمل expireCameraRequests از مسیر اجرای تسک).
 *
 * حریم خصوصی: هیچ تصویری از ابتدا ذخیره نمی‌شود (raw_image_stored=0 و مسیر
 * Option C فقط آمار عددی نگه می‌دارد)؛ این کامند صرفاً چرخهٔ عمرِ ردیف‌های
 * متادیتا را می‌بندد.
 *
 * خروجی صادقانه است: تعداد واقعی حذف/انقضا گزارش می‌شود.
 * کرون: php cron.php system:cleanup  (رجیسترِ cron با مالک — Decision Record).
 */
class SystemCleanupCommand implements CommandInterface
{
    public function __construct() {
        // Constructor اختیاری
    }

    /** @param array<string, mixed> $args */
    public function run(array $args = []): int
    {
        $this->output("[SystemCleanupCommand] شروع پاکسازی نگهداری‌محور...\n");

        try {
            $container = Container::getInstance();
            $settings  = $container->make(AppSettings::class);
            $db        = $container->make(\Core\Database::class);
        } catch (\Throwable $e) {
            $this->output("[SystemCleanupCommand] ⚠️ کانتینر/DB در دسترس نیست: " . $e->getMessage() . "\n", true);
            $this->output("[SystemCleanupCommand] پایان — وضعیت: FAILED (هیچ رکوردی حذف نشد).\n", true);
            return 1;
        }

        $retentionDays = int_value($settings->get('camera_retention_days', 30));
        $retentionDays = max(1, min(3650, $retentionDays));

        // ۱) حذف رکوردهای دوربین بالاتر از مهلت نگهداری
        $deleted = 0;
        try {
            $stmt = $db->query(
                "DELETE FROM social_camera_requests
                 WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)",
                [$retentionDays]
            );
            $deleted = $stmt->rowCount();
        } catch (\Throwable $e) {
            $this->output("[SystemCleanupCommand] ⚠️ حذف رکوردهای دوربین شکست خورد: " . $e->getMessage() . "\n", true);
        }

        // ۲) انقضای pendingهای سررسیدشده (سوئیپ سراسری)
        $expired = 0;
        try {
            $stmt = $db->query(
                "UPDATE social_camera_requests
                 SET status = 'expired'
                 WHERE status = 'pending' AND expires_at IS NOT NULL AND expires_at < NOW()",
                []
            );
            $expired = $stmt->rowCount();
        } catch (\Throwable $e) {
            $this->output("[SystemCleanupCommand] ⚠️ انقضای pendingها شکست خورد: " . $e->getMessage() . "\n", true);
        }

        $this->output(sprintf(
            "[SystemCleanupCommand] camera_retention_days=%d | حذف‌شده: %d رکورد | منقضی‌شده: %d رکورد\n",
            $retentionDays,
            $deleted,
            $expired
        ));
        $this->output("[SystemCleanupCommand] پایان — وضعیت: OK.\n");

        return 0; // FIX-C61: قرارداد کد خروج اینترفیس
    }

    /**
     * 🛡️ خروجی هوشمند و تشخیص استریم‌های غیرتعاملی (Non-TTY TTY Log Stripping Guard)
     * حذف خودکار کدهای رنگی ANSI در زمان اجرای دیمن‌ها در داکر، کرون و کوبرنتیز جهت جلوگیری از درج کاراکترهای فاسد در سیستم‌های لاگ
     */
    private function output(string $message, bool $isErr = false): void
    {
        // FIX-P3-CMD-136 (یافتهٔ ۱۳۶): هر دو ثابت STDIN-family گارد می‌شوند —
        // قبلاً نبودِ STDERR به STDOUT ارجاع می‌داد (و نبودِ STDOUT در SAPIهای
        // غیر-CLI به یک ثابت تعریف‌نشده). اکنون fallback نهایی echo است.
        $stream = null;
        if ($isErr && defined('STDERR')) {
            $stream = STDERR;
        } elseif (defined('STDOUT')) {
            $stream = STDOUT;
        }

        $isTty = $stream !== null && function_exists('stream_isatty') && @stream_isatty($stream);
        if (!$isTty) {
            $message = (string)preg_replace('/\033\[[0-9;]*m/', '', $message);
        }

        if ($stream !== null) {
            fwrite($stream, $message);
            fflush($stream);
        } else {
            echo $message;
        }
    }
}
