<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\CommandInterface;
use App\Services\Settings\AppSettings;
use Core\Container;

/**
 * System Cleanup Command — 🛡️ F21-01/V7 (۲۰۲۶-۱۰-۲۲، بازسازی ۲۰۲۶-۱۰-۲۴)
 *
 * پاکسازیِ نگهداری‌محورِ رکوردهای راستی‌آزمایی دوربین:
 *   ۱) حذف رکوردهای social_camera_requests قدیمی‌تر از camera_retention_days
 *      (کلید پنل، پیش‌فرض ۳۰ روز؛ بازهٔ مجاز ۱..۳۶۵۰).
 *   ۲) انقضای رکوردهای pending که expires_atشان گذشته ولی هنوز 'pending'‌اند
 *      (سوئیپ سراسری — مکمل expireCameraRequests از مسیر اجرای تسک).
 *
 * حریم خصوصی: هیچ تصویری از ابتدا ذخیره نمی‌شود (raw_image_stored=0 و مسیر
 * Option C فقط آمار عددی نگه می‌دارد)؛ این کامند صرفاً چرخهٔ عمرِ ردیف‌های
 * متادیتا را می‌بندد.
 *
 * خروجی صادقانه است: تعداد واقعی حذف/انقضا گزارش می‌شود.
 * کرون: php cron.php system:cleanup  (رجیسترِ cron با مالک — Decision Record).
 *
 * 🛡️ FIX-CAM-CLEANUP-V7 (چرخهٔ اصلاحی 2026-10-28 — رفع یافتهٔ 17-RV):
 * منطق پاکسازی به cleanup() جدا شد تا زمان‌بندیِ Kernel (system_camera_cleanup،
 * هر روز ۰۴:۰۰ — app/Console/Kernel.php) بتواند همان منطق را بدون آلودگیِ
 * stdout صدا بزند؛ run() فقط قالب‌بندی CLI همان است. این همان درس
 * FIX-P3-CMD-161 است (closureهای زمان‌بندی از CronController وب ادمین هم
 * اجرا می‌شوند — echo خروجی وب را خراب می‌کرد).
 */
class SystemCleanupCommand implements CommandInterface
{
    public function __construct() {
        // Constructor اختیاری
    }

    /** @param array<string, mixed> $args */
    public function run(array $args = []): int
    {
        $this->output("[SystemCleanupCommand] شروع پاکسازی نگهداری‌محور...\n");

        $result = $this->cleanup();

        if (($result['status'] ?? '') !== 'ok') {
            $this->output("[SystemCleanupCommand] ⚠️ " . str_value($result['error'] ?? 'unknown') . "\n", true);
            $this->output("[SystemCleanupCommand] پایان — وضعیت: FAILED (هیچ رکوردی حذف نشد).\n", true);
            return 1;
        }

        $this->output(sprintf(
            "[SystemCleanupCommand] camera_retention_days=%d | حذف‌شده: %d رکورد | منقضی‌شده: %d رکورد\n",
            (int)($result['retention_days'] ?? 0),
            (int)($result['deleted'] ?? 0),
            (int)($result['expired'] ?? 0)
        ));
        $this->output("[SystemCleanupCommand] پایان — وضعیت: OK.\n");

        return 0; // FIX-C61: قرارداد کد خروج اینترفیس
    }

    /**
     * 🛡️ FIX-CAM-CLEANUP-V7: منطق پاکسازی — بدون echo (نام cleanup؛ «execute» ممنوع چون CliDispatcher آن را به run() ترجیح می‌دهد) (ایمن برای فراخوان از
     * Kernel/CronController). خروجی صادقانه: شمارنده‌های واقعی هر مرحله؛
     * خطای مرحله‌ای = status=failed با همان شمارنده‌ها — هرگز جعل موفقیت نمی‌شود.
     *
     * @return array{status: 'ok'|'failed', retention_days?: int, deleted?: int, expired?: int, error?: string}
     */
    public function cleanup(): array
    {
        try {
            $container = Container::getInstance();
            $settings  = $container->make(AppSettings::class);
            $db        = $container->make(\Core\Database::class);
        } catch (\Throwable $e) {
            return ['status' => 'failed', 'error' => 'container/db unavailable: ' . $e->getMessage()];
        }

        $retentionDays = int_value($settings->get('camera_retention_days', 30));
        $retentionDays = max(1, min(3650, $retentionDays));

        // 🛡️ FIX-SCR-BATCH (بازبینی نهایی 2026-10-28 — تکمیل FIX-CAM-CLEANUP-V7):
        // DELETE دسته‌ای با LIMIT (هم‌الگوی S31-VF2 cleanOldFingerprints) — این
        // جدول تا قبل از فعال‌شدن پاک‌سازی، ماه‌ها رشد نامحدود داشته؛ یک DELETE
        // تک‌فراخوانی روی میلیون‌ها ردیف، قفل‌های طولانی و binlog حجیم می‌سازد.
        // دسته‌های ۱۰۰۰تایی قفل‌ها را کوتاه نگه می‌دارند و شکست وسط راه = ادامه
        // فردا شب (شمارنده‌های صادقانه تا همان لحظه). مقدار بعد از (int)-cast
        // سخت مستقیم در SQL می‌نشیند (placeholder برای DELETE...LIMIT در
        // prepared statements پشتیبانی پایدار ندارد؛ پس از cast تزریق ناممکن است).
        $batchLimit = 1000;

        $deleted = 0;
        $expired = 0;
        $errors  = [];

        // ۱) حذف رکوردهای دوربین بالاتر از مهلت نگهداری — دسته‌ای
        try {
            while (true) {
                $stmt = $db->query(
                    "DELETE FROM social_camera_requests
                     WHERE created_at < DATE_SUB(NOW(), INTERVAL " . (int)$retentionDays . " DAY)
                     LIMIT " . (int)$batchLimit,
                    []
                );
                $batch = (int)$stmt->rowCount();
                $deleted += $batch;
                if ($batch < $batchLimit) {
                    break;
                }
            }
        } catch (\Throwable $e) {
            $errors[] = 'delete: ' . $e->getMessage();
        }

        // ۲) انقضای pendingهای سررسیدشده (سوئیپ سراسری)
        try {
            $stmt = $db->query(
                "UPDATE social_camera_requests
                 SET status = 'expired'
                 WHERE status = 'pending' AND expires_at IS NOT NULL AND expires_at < NOW()",
                []
            );
            $expired = $stmt->rowCount();
        } catch (\Throwable $e) {
            $errors[] = 'expire: ' . $e->getMessage();
        }

        $out = [
            'status'         => 'ok',
            'retention_days' => $retentionDays,
            'deleted'        => $deleted,
            'expired'        => $expired,
        ];
        if ($errors !== []) {
            $out['status'] = 'failed';
            $out['error']  = implode('; ', $errors);
        }
        return $out;
    }

    /**
     * 🛡️ خروجی هوشمند و تشخیص استریم‌های غیرتعاملی (Non-TTY TTY Log Stripping Guard)
     * حذف خودکار کدهای رنگی ANSI در زمان اجرای دیمن‌ها در داکر، کرون و کوبرنتیز جهت جلوگیری از درج کاراکترهای فاسد در سیستم‌های لاگ
     */
    private function output(string $message, bool $isErr = false): void
    {
        // FIX-P3-CMD-136 (یافتهٔ ۱۳۶): هر دو ثابت STDIN-family گارد می‌شوند —
        // قبلاً نبودِ STDERR به STDOUT ارجاع می‌داد (و نبودِ STDOUT در SAPIهای
        // غیر-CLI به یک ثابت تعریف‌نشده). اکنون fallback نهایی echo است.
        $stream = null;
        if ($isErr && defined('STDERR')) {
            $stream = STDERR;
        } elseif (defined('STDOUT')) {
            $stream = STDOUT;
        }

        $isTty = $stream !== null && function_exists('stream_isatty') && @stream_isatty($stream);
        if (!$isTty) {
            $message = (string)preg_replace('/\033\[[0-9;]*m/', '', $message);
        }

        if ($stream !== null) {
            fwrite($stream, $message);
            fflush($stream);
        } else {
            echo $message;
        }
    }
}
