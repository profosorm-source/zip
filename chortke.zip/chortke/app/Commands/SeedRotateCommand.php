<?php

declare(strict_types=1);

namespace App\Commands;

use App\Models\ApiToken;
use App\Models\AuditTrail;
use App\Validators\PasswordPolicy;
use Core\Database;

use App\Contracts\LoggerInterface;

/**
 * 🛡️ FIX-M23-R2 (یادآوری ②): چرخش رمز حساب‌های seed با رمز پیش‌فرض «123456».
 *
 * چرا؟ رمز seed ادمین (admin@chortke.ir / 123456 و هم‌خانواده‌ها) یک اعتبارِ
 * شناخته‌شده است و پیش از production باید حتماً rotate شود. این دستور چرخشِ
 * تضمین‌شده و قابلِ ممیزی را یک‌جا می‌دهد:
 *
 *   - شناساییِ هر حساب «فعال» که رمزش هنوز «123456» است (به‌صورت پیش‌فرض فقط
 *     ایمیل‌های شناخته‌شدهٔ seed؛ با --all همهٔ کاربران فعال — برای ممیزیِ
 *     پیش از production).
 *   - رمز جدید: تصادفیِ CSPRNG (PasswordPolicy::generate(20)) یا --password=…
 *     (باید سیاست رمز را پاس کند و «123456» نباشد).
 *   - هم‌قرارداد با تغییر رمزِ پنل (FIX-M11-R22-3): ابطالِ همهٔ توکن‌های API
 *     (revokeAllForUserWithReason 'password_changed')، غیرفعال‌سازی نشست‌های
 *     وب (user_sessions.is_active=0) و خالی‌کردن remember_token.
 *   - ثبت در audit_trail با زنجیرهٔ hash (بدون رمزِ خام در context).
 *
 * مصرف:
 *   php cli.php security:seed-rotate --check            (فقط گزارش — بدون تغییر)
 *   php cli.php security:seed-rotate --check --all      (ممیزیِ کامل همهٔ کاربران)
 *   php cli.php security:seed-rotate --dry-run          (شبیه‌سازی چرخش)
 *   php cli.php security:seed-rotate                    (چرخش حساب‌های seed)
 *   php cli.php security:seed-rotate --email=x --password=… (هدفمند)
 *
 * در محیط production گذراندن --confirm الزامی است (fail-closed برابر اجرای
 * تصادفیِ مخرب/اشتباه).
 */
final class SeedRotateCommand
{
    private Database $db;
    private LoggerInterface $logger;
    private AuditTrail $auditTrail;
    private ApiToken $apiTokenModel;

    /** ایمیل‌های seedِ شناخته‌شده — همان مجموعه‌ای که migration 2026_06_16_0005 می‌سازد. */
    private const SEED_EMAILS = [
        'user@chortke.ir',
        'support@chortke.ir',
        'admin@chortke.ir',
        'superadmin@chortke.ir',
    ];

    private const DEFAULT_SEED_PASSWORD = '123456';

    /**
     * FIX-M23-R2b (باگ کشف‌شده در همین راند): تشخیص باید عیناً معناشناسیِ
     * verify_user_password باشد — دو فرم هش در میدان است:
     *   1) کانونیکال: bcrypt/argon2 از base64(sha384(password)) — مسیر hash_password()
     *   2) legacy: هشِ خامِ password (الگوی seeder: password_hash('123456'))
     *      — فقط از طریق fallback لاگین می‌شود.
     * سنجیدنِ فقط فرم خام، حساب‌هایی مثل admin@chortke.ir (که در DB زنده با فرمِ
     * کانونیکالِ «123456» هش شده بود) را از قلم می‌انداخت.
     */
    private function matchesDefaultSeedPassword(string $hash): bool
    {
        if ($hash === '') {
            return false;
        }
        $canonicalPreHash = base64_encode(hash('sha384', self::DEFAULT_SEED_PASSWORD, true));
        return password_verify($canonicalPreHash, $hash) || password_verify(self::DEFAULT_SEED_PASSWORD, $hash);
    }

    public function __construct(Database $db, LoggerInterface $logger, AuditTrail $auditTrail, ApiToken $apiTokenModel)
    {
        $this->db = $db;
        $this->logger = $logger;
        $this->auditTrail = $auditTrail;
        $this->apiTokenModel = $apiTokenModel;
    }

    /**
     * @param list<int|string, mixed> $argv
     */
    public function run(array $argv): int
    {
        $mode = 'rotate';
        $targetEmail = null;
        $newPassword = null;
        $allUsers = false;
        $confirm = false;

        foreach (array_slice($argv, 2) as $arg) {
            $arg = (string)$arg;
            if ($arg === '--check') {
                $mode = 'check';
            } elseif ($arg === '--dry-run') {
                $mode = 'dry-run';
            } elseif ($arg === '--all') {
                $allUsers = true;
            } elseif ($arg === '--confirm') {
                $confirm = true;
            } elseif (str_starts_with($arg, '--email=')) {
                $targetEmail = strtolower(trim(substr($arg, 8)));
            } elseif (str_starts_with($arg, '--password=')) {
                $newPassword = substr($arg, 11);
            }
        }

        $isProduction = (config('app.env') === 'production' || env('APP_ENV') === 'production');
        if ($isProduction && $mode === 'rotate' && !$confirm) {
            echo "❌ محیط production: برای چرخش واقعی، اجرای عمدی با --confirm الزامی است (fail-closed).\n";
            echo "   پیشنهاد: اول «--check» برای گزارش، بعد «--dry-run» و در نهایت «--confirm».\n";
            return 1;
        }

        // ── واکشیِ نامزدها ──────────────────────────────────────────────
        try {
            if ($targetEmail !== null) {
                $rows = $this->db->fetchAll(
                    "SELECT id, email, username, role, is_admin, status, password FROM users WHERE email = ? AND status = 'active'",
                    [$targetEmail]
                );
            } elseif ($allUsers) {
                $rows = $this->db->fetchAll(
                    "SELECT id, email, username, role, is_admin, status, password FROM users WHERE status = 'active'"
                );
            } else {
                $placeholders = implode(',', array_fill(0, count(self::SEED_EMAILS), '?'));
                $rows = $this->db->fetchAll(
                    "SELECT id, email, username, role, is_admin, status, password FROM users
                     WHERE email IN ({$placeholders}) AND status = 'active'",
                    self::SEED_EMAILS
                );
            }
        } catch (\Throwable $e) {
            echo "❌ خواندن کاربران ناموفق: " . $e->getMessage() . "\n";
            return 1;
        }

        // ── تشخیصِ رمزِ پیش‌فرض (دو فرمِ هش — پس از واکشی، verify در PHP) ──
        $affected = [];
        foreach ($rows as $row) {
            $hash = (string)($row->password ?? '');
            if ($this->matchesDefaultSeedPassword($hash)) {
                $affected[] = $row;
            }
        }

        $adminCount = count(array_filter($affected, static fn ($r) => (int)($r->is_admin ?? 0) === 1));

        if ($mode === 'check') {
            echo "── گزارش رمز seed پیش‌فرض («123456») ──\n";
            echo "دامنه: " . ($allUsers ? 'همهٔ کاربران فعال' : ($targetEmail ?? 'ایمیل‌های seed شناخته‌شده')) . "\n";
            echo "بررسی‌شده: " . count($rows) . " | با رمز پیش‌فرض: " . count($affected) . " (ادمین: {$adminCount})\n";
            foreach ($affected as $r) {
                echo sprintf(
                    "  • [%d] %s (%s | role=%s | is_admin=%d)\n",
                    (int)$r->id,
                    (string)$r->email,
                    (string)$r->username,
                    (string)$r->role,
                    (int)$r->is_admin
                );
            }
            if ($affected !== []) {
                echo $isProduction
                    ? "🚨 PRODUCTION: حساب با رمز پیش‌فرض موجود است — چرخش فوری الزامی است (php cli.php security:seed-rotate --confirm).\n"
                    : "⚠️  برای چرخش: php cli.php security:seed-rotate\n";
            } else {
                echo "✅ هیچ حساب فعالی با رمز پیش‌فرض یافت نشد.\n";
            }
            return $affected === [] ? 0 : ($isProduction ? 2 : 0);
        }

        if ($affected === []) {
            echo "✅ هیچ حساب فعالی با رمز پیش‌فرض «123456» یافت نشد — کاری برای انجام نیست (idempotent).\n";
            return 0;
        }

        if ($newPassword !== null) {
            $errors = PasswordPolicy::validate($newPassword);
            if ($newPassword === self::DEFAULT_SEED_PASSWORD) {
                $errors[] = 'رمز جدید نباید همان رمز پیش‌فرض «123456» باشد.';
            }
            if ($errors !== []) {
                echo "❌ رمز ارائه‌شده سیاست رمز را پاس نمی‌کند:\n  - " . implode("\n  - ", $errors) . "\n";
                return 1;
            }
        }

        echo ($mode === 'dry-run' ? "── شبیه‌سازی چرخش (dry-run، بدون تغییر) ──\n" : "── چرخش رمز حساب‌های seed ──\n");
        $report = [];

        foreach ($affected as $row) {
            $userId = (int)$row->id;
            $email = (string)$row->email;
            $passwordForUser = $newPassword ?? PasswordPolicy::generate(20);

            if ($mode === 'dry-run') {
                $report[$email] = '<generated>';
                echo sprintf("  • [%d] %s ← (رمز تصادفی %s)\n", $userId, $email, $newPassword !== null ? 'ارائه‌شده' : '۲۰ کاراکتری CSPRNG');
                continue;
            }

            try {
                $this->db->beginTransaction();

                $this->db->query(
                    // FIX-M23-R2b: نوشتن با مسیر کانونیکالِ hash_password() (پیش‌هش sha384 +
                    // Argon2id) — نوشتنِ هشِ خام، حساب را «legacy» می‌کرد و لاگینِ بعدی به
                    // auto-rehash می‌افتاد (رفتار ناخواسته برای یک چرخشِ نظارتی).
                    "UPDATE users SET password = ?, remember_token = NULL, updated_at = NOW() WHERE id = ?",
                    [hash_password($passwordForUser), $userId]
                );
                // هم‌قرارداد با تغییر رمز پنل: نشست‌های وب مرده شوند
                $this->db->query(
                    "UPDATE user_sessions SET is_active = 0 WHERE user_id = ? AND is_active = 1",
                    [$userId]
                );
                // ابطال توکن‌های API با دلیلِ صریح (قرارداد راند ۲۲)
                $revokedTokens = $this->apiTokenModel->revokeAllForUserWithReason($userId, 'password_changed');

                $this->auditTrail->createEntry([
                    'user_id' => $userId,
                    'actor_id' => AuditTrail::SYSTEM_ACTOR_ID,
                    'event' => 'security.seed_password_rotated',
                    // 🔒 رمزِ خام هرگز در ممیزی ثبت نمی‌شود
                    'context' => [
                        'email' => $email,
                        'is_admin' => (int)($row->is_admin ?? 0) === 1,
                        'revoked_api_tokens' => $revokedTokens,
                        'source' => 'cli:security:seed-rotate',
                    ],
                    'ip_address' => '127.0.0.1',
                    'user_agent' => 'CLI security:seed-rotate',
                ]);

                $this->db->commit();

                $report[$email] = $passwordForUser;
                echo sprintf("  ✓ [%d] %s چرخش شد (توکن ابطال‌شده: %d)\n", $userId, $email, $revokedTokens);
                $this->logger->info('security.seed_password_rotated', [
                    'user_id' => $userId,
                    'email' => $email,
                    'revoked_api_tokens' => $revokedTokens,
                ]);
            } catch (\Throwable $e) {
                if ($this->db->inTransaction()) {
                    $this->db->rollBack();
                }
                echo "  ❌ چرخش {$email} ناموفق: " . $e->getMessage() . "\n";
                $this->logger->error('security.seed_password_rotate_failed', ['user_id' => $userId, 'email' => $email, 'error' => $e->getMessage()]);
            }
        }

        if ($mode === 'dry-run') {
            echo "dry-run تمام شد — هیچ تغییری اعمال نشد.\n";
            return 0;
        }

        // ⚠️ نمایشِ یک‌بارِ اعتبارهای جدید — تنها راهِ بازیابی برای اپراتور
        if ($report !== []) {
            echo "\n═══ اعتبارهای جدید (فقط همین یک‌بار نمایش داده می‌شود — همین حالا ذخیره کنید) ═══\n";
            foreach ($report as $email => $password) {
                echo "  {$email}  →  {$password}\n";
            }
            echo "════════════════════════════════════════════════════════════════════════════\n";
        }

        return 0;
    }
}
