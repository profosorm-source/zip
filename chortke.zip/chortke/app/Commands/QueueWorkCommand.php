<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\QueueWorker;
use App\Contracts\LoggerInterface;

/**
 * CLI command daemon to run the QueueWorker and process jobs.
 *
 * Usage:
 *   php cli.php queue:work [--queue=default] [--limit=10] [--daemon] [--sleep=1] [--tries=5] [--max-time=3600] [--stop-when-empty]
 *
 * حالت پیش‌فرض (بدون --daemon) تک‌مرحله‌ای است (سازگار با cron و تست‌ها)؛
 * حالت --daemon حلقهٔ دائمی برای supervisor است: بین نظرسنجی‌های خالی sleep
 * می‌کند، با --max-time بازیافت نرم دارد و با سیگنال SIGTERM به‌صورت گراس‌فول خارج می‌شود.
 */
class QueueWorkCommand
{
    private QueueWorker $worker;
    private LoggerInterface $logger;
    public function __construct(
        QueueWorker $worker,
        LoggerInterface $logger
    ) {        $this->worker = $worker;
        $this->logger = $logger;
}

    /**
     * Executes the CLI command.
     */
    /**
     * @param array<int, string> $argv
     * @return array<string, mixed>
     */
    public function run(array $argv = []): array
    {
        $queue = null;
        $limit = 10;
        $daemon = false;
        $sleep = 1;
        $tries = null;
        $maxTime = 0;
        $stopWhenEmpty = false;

        foreach ($argv as $arg) {
            if (is_string($arg)) {
                if (str_starts_with($arg, '--queue=')) {
                    $queue = substr($arg, 8);
                } elseif (str_starts_with($arg, '--limit=')) {
                    $limit = (int)substr($arg, 8);
                } elseif ($arg === '--daemon') {
                    $daemon = true;
                } elseif (str_starts_with($arg, '--sleep=')) {
                    $sleep = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--tries=')) {
                    $tries = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--max-time=')) {
                    $maxTime = (int)substr($arg, 11);
                } elseif ($arg === '--stop-when-empty') {
                    $stopWhenEmpty = true;
                }
            }
        }

        // Validate range limits
        $limit = max(1, min(500, $limit));
        $sleep = max(0, min(300, $sleep));
        $maxTime = max(0, min(86400, $maxTime));
        if ($tries !== null) {
            $this->worker->setMaxAttempts(max(1, min(20, $tries)));
        }

        $this->logger->info('queue.command.work.starting', [
            'queue' => $queue ?? 'all',
            'limit' => $limit,
            'daemon' => $daemon,
            'sleep' => $sleep,
            'max_time' => $maxTime
        ]);

        if ($daemon) {
            return $this->runDaemonLoop($queue, $limit, $sleep, $maxTime, $stopWhenEmpty);
        }

        try {
            $result = $this->worker->work($queue, $limit);
            $processed = int_value($result['processed_jobs'] ?? 0);
            $failed = int_value($result['failed_jobs'] ?? 0);

            $this->logger->info('queue.command.work.completed', [
                'processed' => $processed,
                'failed' => $failed,
                'queue' => $queue ?? 'all'
            ]);

            echo "[queue:work] processed={$processed} failed={$failed} (limit={$limit})\n";

            return [
                'processed_jobs' => $processed,
                'failed_jobs' => $failed
            ];
        } catch (\Throwable $e) {
            $this->logger->error('queue.command.work.failed', [
                'queue' => $queue ?? 'all',
                'error' => $e->getMessage()
            ]);
            fwrite(STDERR, "[queue:work] error: " . $e->getMessage() . "\n");
            return [
                'processed_jobs' => 0,
                'failed_jobs' => 0,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * حلقهٔ دیمن برای supervisor — بدون این حلقه، کامند تک‌اجرایی است و
     * supervisor با ری‌استارت سریع آن را پس از startretries=10 به FATAL می‌برد.
     *
     * @return array<string, mixed>
     */
    private function runDaemonLoop(?string $queue, int $limit, int $sleep, int $maxTime, bool $stopWhenEmpty): array
    {
        $startedAt = time();
        $totalProcessed = 0;
        $totalFailed = 0;

        while (true) {
            if ($this->worker->shouldQuit()) {
                $this->logger->info('queue.command.work.daemon_stopped_by_signal', [
                    'processed' => $totalProcessed
                ]);
                break;
            }

            try {
                $result = $this->worker->work($queue, $limit);
                $iterationProcessed = int_value($result['processed_jobs'] ?? 0);
                $iterationFailed = int_value($result['failed_jobs'] ?? 0);
            } catch (\Throwable $e) {
                // خطای زیرساختی موقت (مثلاً قطعی لحظه‌ای DB): دیمن نمی‌میرد، با فاصله ادامه می‌دهد
                $this->logger->error('queue.command.work.daemon_iteration_failed', [
                    'error' => $e->getMessage()
                ]);
                sleep(max($sleep, 5));
                continue;
            }

            $totalProcessed += $iterationProcessed;
            $totalFailed += $iterationFailed;

            if ($iterationProcessed + $iterationFailed === 0) {
                if ($stopWhenEmpty) {
                    break;
                }
                if ($sleep > 0) {
                    sleep($sleep);
                }
            }

            if ($maxTime > 0 && (time() - $startedAt) >= $maxTime) {
                // بازیافت نرم دوره‌ای (deployment recycling) — supervisor دوباره بالا می‌آورد
                $this->logger->info('queue.command.work.max_time_reached', [
                    'elapsed_seconds' => time() - $startedAt,
                    'processed' => $totalProcessed
                ]);
                break;
            }
        }

        $this->logger->info('queue.command.work.completed', [
            'processed' => $totalProcessed,
            'failed' => $totalFailed,
            'queue' => $queue ?? 'all',
            'daemon' => true
        ]);

        echo "[queue:work] processed={$totalProcessed} failed={$totalFailed} (daemon exit)\n";

        return [
            'processed_jobs' => $totalProcessed,
            'failed_jobs' => $totalFailed
        ];
    }
}
