<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\QueueWorker;
use App\Contracts\LoggerInterface;
use Core\CircuitBreaker;
use Core\Exceptions\CircuitBreakerOpenException;

/**
 * CLI command daemon to run the QueueWorker and process jobs.
 *
 * Usage:
 *   php cli.php queue:work [--queue=default] [--limit=10] [--daemon] [--sleep=1] [--tries=5] [--max-time=3600] [--stop-when-empty] [--memory=256] [--max-jobs=0]
 *
 * حالت پیش‌فرض (بدون --daemon) تک‌مرحله‌ای است (سازگار با cron و تست‌ها)؛
 * حالت --daemon حلقهٔ دائمی برای supervisor است: بین نظرسنجی‌های خالی sleep
 * می‌کند، با --max-time / --memory / --max-jobs بازیافت نرم دارد و با سیگنال
 * SIGTERM به‌صورت گراس‌فول خارج می‌شود.
 * FIX-R36-W3 (F-A19e-09): --memory (پیش‌فرض ۲۵۶MB، 0=خاموش) و --max-jobs
 * (پیش‌فرض 0=خاموش) — ورکر PHPِ پردازش‌گرِ جاب‌های مالی بدون بازچرخانی حافظه
 * ریسک OOM-kill وسط کار/رشد نشت داشت؛ حالا بین iterationها soft-break می‌کند
 * (مثل max-time — supervisor دوباره بالا می‌آورد؛ هیچ جابی وسط اجرا قطع نمی‌شود).
 */
class QueueWorkCommand
{
    /**
     * FIX-P3-CMD-087 (یافتهٔ ۰۸۷): allowlist نام صف — هم‌سو با فهرست اولویت
     * core/Queue::pop (تنها مصرف‌کنندهٔ نام صف). صف ناشناخته قبلاً بی‌صدا کار می‌کرد
     * (pop همیشه خالی) و operator فکر می‌کرد صف فقط خالی است.
     */
    private const KNOWN_QUEUES = ['high_priority', 'default', 'notifications', 'analytics', 'maintenance'];

    private QueueWorker $worker;
    private LoggerInterface $logger;
    private ?CircuitBreaker $circuitBreaker;
    public function __construct(
        QueueWorker $worker,
        LoggerInterface $logger,
        ?CircuitBreaker $circuitBreaker = null
    ) {        $this->worker = $worker;
        $this->logger = $logger;
        $this->circuitBreaker = $circuitBreaker;
}

    /**
     * Executes the CLI command.
     */
    /**
     * @param array<int, string> $argv
     * @return array<string, mixed>
     */
    public function run(array $argv = []): array
    {
        $queue = null;
        $limit = 10;
        $daemon = false;
        $sleep = 1;
        $tries = null;
        $maxTime = 0;
        $maxMemoryMb = 256; // FIX-R36-W3 (F-A19e-09): 0 = خاموش
        $maxJobs = 0;       // FIX-R36-W3 (F-A19e-09): 0 = خاموش
        $stopWhenEmpty = false;

        foreach ($argv as $arg) {
            if (is_string($arg)) {
                if (str_starts_with($arg, '--queue=')) {
                    $queue = substr($arg, 8);
                } elseif (str_starts_with($arg, '--limit=')) {
                    $limit = (int)substr($arg, 8);
                } elseif ($arg === '--daemon') {
                    $daemon = true;
                } elseif (str_starts_with($arg, '--sleep=')) {
                    $sleep = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--tries=')) {
                    $tries = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--max-time=')) {
                    $maxTime = (int)substr($arg, 11);
                } elseif (str_starts_with($arg, '--memory=')) {
                    $maxMemoryMb = (int)substr($arg, 9);
                } elseif (str_starts_with($arg, '--max-jobs=')) {
                    $maxJobs = (int)substr($arg, 11);
                } elseif ($arg === '--stop-when-empty') {
                    $stopWhenEmpty = true;
                }
            }
        }

        // Validate range limits
        $limit = max(1, min(500, $limit));
        $sleep = max(0, min(300, $sleep));
        $maxTime = max(0, min(86400, $maxTime));
        $maxMemoryMb = max(0, min(4096, $maxMemoryMb)); // FIX-R36-W3 (F-A19e-09)
        $maxJobs = max(0, min(1000000, $maxJobs));       // FIX-R36-W3 (F-A19e-09)
        if ($tries !== null) {
            $this->worker->setMaxAttempts(max(1, min(20, $tries)));
        }

        // FIX-P3-CMD-087: اعتبارسنجی ‎--queue مقابل نام‌های شناخته‌شده (پیش از هر کار)
        if ($queue !== null && !in_array($queue, self::KNOWN_QUEUES, true)) {
            $this->logger->error('queue.command.work.unknown_queue', [
                'queue' => $queue,
                'known' => self::KNOWN_QUEUES,
            ]);
            fwrite(STDERR, "[queue:work] error: unknown queue '{$queue}' (valid: "
                . implode(', ', self::KNOWN_QUEUES) . ")\n");
            return [
                'processed_jobs' => 0,
                'failed_jobs' => 0,
                'error' => 'unknown queue',
                'exit_code' => 1,
            ];
        }

        $this->logger->info('queue.command.work.starting', [
            'queue' => $queue ?? 'all',
            'limit' => $limit,
            'daemon' => $daemon,
            'sleep' => $sleep,
            'max_time' => $maxTime
        ]);

        if ($daemon) {
            return $this->runDaemonLoop($queue, $limit, $sleep, $maxTime, $stopWhenEmpty, $maxMemoryMb, $maxJobs);
        }

        try {
            $result = $this->worker->work($queue, $limit);
            $processed = int_value($result['processed_jobs'] ?? 0);
            $failed = int_value($result['failed_jobs'] ?? 0);

            $this->logger->info('queue.command.work.completed', [
                'processed' => $processed,
                'failed' => $failed,
                'queue' => $queue ?? 'all'
            ]);

            echo "[queue:work] processed={$processed} failed={$failed} (limit={$limit})\n";

            return [
                'processed_jobs' => $processed,
                'failed_jobs' => $failed
            ];
        } catch (\Throwable $e) {
            // FIX-P3-CMD-088 (یافتهٔ ۰۸۸): جزئیات ماسک‌شدهٔ استثنا (کلاس/فایل/خط) به
            // لاگ ساختاریافته اضافه شد؛ پیام کوتاه CLI بدون تغییر (هم‌الگوی CMD-067).
            $this->logger->error('queue.command.work.failed', [
                'queue' => $queue ?? 'all',
                'error' => $e->getMessage(),
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
            // FIX (یافتهٔ ۱۲۵): پیام خام استثنا (DSN/SQL/مسیر) به stderr operator نمی‌رود
            fwrite(STDERR, "[queue:work] error: queue work failed (details in logs)\n");
            // FIX (یافتهٔ ۱۴۱): شکست با exit_code صریح به dispatcher/Cron اعلام می‌شود
            // (قرارداد جدید dispatcher: کلید exit_code در آرایهٔ نتیجه = کد خروج)
            return [
                'processed_jobs' => 0,
                'failed_jobs' => 0,
                'error' => $e->getMessage(),
                'exit_code' => 1,
            ];
        }
    }

    /**
     * حلقهٔ دیمن برای supervisor — بدون این حلقه، کامند تک‌اجرایی است و
     * supervisor با ری‌استارت سریع آن را پس از startretries=10 به FATAL می‌برد.
     *
     * @return array<string, mixed>
     */
    private function runDaemonLoop(?string $queue, int $limit, int $sleep, int $maxTime, bool $stopWhenEmpty, int $maxMemoryMb = 0, int $maxJobs = 0): array
    {
        $startedAt = time();
        $totalProcessed = 0;
        $totalFailed = 0;
        // FIX-C142: شمارندهٔ شکست‌های متوالی برای backoff نمایی
        $consecutiveFailures = 0;

        while (true) {
            if ($this->worker->shouldQuit()) {
                $this->logger->info('queue.command.work.daemon_stopped_by_signal', [
                    'processed' => $totalProcessed
                ]);
                break;
            }

            try {
                // FIX-P3-CMD-085 (یافتهٔ ۰۸۵): بودجهٔ دور — نزدیکِ سقف ‎--max-jobs،
                // به‌جای بچ کامل، فقط min(limit, باقی‌مانده) فچ می‌شود تا overshoot
                // حداکثر یک جاب باشد (قبلاً تا یک بچ کامل ۵۰۰تایی از سقف عبور می‌کرد).
                $iterationLimit = $limit;
                if ($maxJobs > 0) {
                    $remainingJobs = $maxJobs - ($totalProcessed + $totalFailed);
                    if ($remainingJobs <= 0) {
                        break;
                    }
                    $iterationLimit = min($limit, $remainingJobs);
                }

                // FIX-C141 (یافتهٔ ۱۴۱): circuit breaker دور work() — شکست‌های
                // متوالی زیرساختی مدار را باز می‌کنند (fail-open breaker: وقتی
                // خودِ state-store در دسترس نیست، مدار بسته می‌ماند) تا فشار
                // روی DB/Redis از فچِ مداوم برداشته شود. بدون breaker تزریق‌شده
                // (تست‌ها)، همان backoff نمایی درون‌حلقه‌ای فعال است.
                if ($this->circuitBreaker !== null) {
                    $result = $this->circuitBreaker->call(
                        'queue_worker',
                        fn (): array => $this->worker->work($queue, $iterationLimit)
                    );
                } else {
                    $result = $this->worker->work($queue, $iterationLimit);
                }
                $iterationProcessed = int_value($result['processed_jobs'] ?? 0);
                $iterationFailed = int_value($result['failed_jobs'] ?? 0);
                // FIX-C142 (یافتهٔ ۱۴۲): شمارش خطاهای متوالی ریست می‌شود.
                $consecutiveFailures = 0;
            } catch (CircuitBreakerOpenException $e) {
                // مدار باز: به‌جای فچ مداوم، تا نیمه‌وقت retry فاصله می‌گیریم
                // (signal-interruptible تا SIGTERM بلافاصله پذیرفته شود).
                $this->logger->warning('queue.command.work.circuit_open', [
                    'service' => $e->getServiceName(),
                ]);
                $this->interruptibleSleep(min(60, max($sleep, 5)));
                continue;
            } catch (\Throwable $e) {
                // خطای زیرساختی موقت (مثلاً قطعی لحظه‌ای DB): دیمن نمی‌میرد، با فاصله ادامه می‌دهد.
                // FIX-C142 (یافتهٔ ۱۴۲): خطای دائمی بدون backoff → چرخهٔ بی‌نهایت
                // CPU/log/provider را تحت فشار می‌گذارد. اکنون شکست‌های متوالی
                // به‌صورت نمایی backoff می‌شوند (تا سقف ۶۰ ثانیه)؛ با نخستین
                // موفقیت، ریست. (circuit breaker کامل در core/CircuitBreaker
                // موجود است؛ این حداقلِ دفاع درون‌حلقه‌ای است.)
                $consecutiveFailures++;
                $backoff = min(60, max($sleep, 5) * (2 ** min($consecutiveFailures, 4)));
                // FIX-P3-CMD-088: جزئیات کلاس/فایل/خط در لاگ ساختاریافته
                $this->logger->error('queue.command.work.daemon_iteration_failed', [
                    'error' => $e->getMessage(),
                    'exception' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'consecutive_failures' => $consecutiveFailures,
                    'backoff_seconds' => $backoff,
                ]);
                $this->interruptibleSleep($backoff);
                continue;
            }

            $totalProcessed += $iterationProcessed;
            $totalFailed += $iterationFailed;

            if ($iterationProcessed + $iterationFailed === 0) {
                if ($stopWhenEmpty) {
                    break;
                }
                if ($sleep > 0) {
                    $this->interruptibleSleep($sleep);
                }
            }

            if ($maxTime > 0 && (time() - $startedAt) >= $maxTime) {
                // بازیافت نرم دوره‌ای (deployment recycling) — supervisor دوباره بالا می‌آورد
                $this->logger->info('queue.command.work.max_time_reached', [
                    'elapsed_seconds' => time() - $startedAt,
                    'processed' => $totalProcessed
                ]);
                break;
            }

            // FIX-R36-W3 (F-A19e-09): بازیافت نرم حافظه/شمارش جاب — فقط بین iterationها
            // (هرگز وسط اجرای جاب)؛ OOM-kill وسط کار مالی + رشد نشت خاموش می‌بندد.
            // FIX-P3-CMD-086 (یافتهٔ ۰۸۶): peak هم بررسی می‌شود — memory_get_usage(true)
            // اوجِ درون‌بچ را نمی‌بیند؛ یک بچ بزرگ که اوج را از آستانه عبور داده،
            // در همان تیک بعدی بازیافت می‌شود (نه چند دور بعد یا هرگز).
            if ($maxMemoryMb > 0) {
                $usedMb = (int)(memory_get_usage(true) / 1048576);
                $peakMb = (int)(memory_get_peak_usage(true) / 1048576);
                if ($usedMb >= $maxMemoryMb || $peakMb >= $maxMemoryMb) {
                    $this->logger->info('queue.command.work.memory_limit_reached', [
                        'used_mb' => $usedMb,
                        'peak_mb' => $peakMb,
                        'threshold_mb' => $maxMemoryMb,
                        'processed' => $totalProcessed,
                    ]);
                    break;
                }
            }
            if ($maxJobs > 0 && ($totalProcessed + $totalFailed) >= $maxJobs) {
                $this->logger->info('queue.command.work.max_jobs_reached', [
                    'max_jobs' => $maxJobs,
                    'processed' => $totalProcessed,
                    'failed' => $totalFailed,
                ]);
                break;
            }
        }

        $this->logger->info('queue.command.work.completed', [
            'processed' => $totalProcessed,
            'failed' => $totalFailed,
            'queue' => $queue ?? 'all',
            'daemon' => true
        ]);

        echo "[queue:work] processed={$totalProcessed} failed={$totalFailed} (daemon exit)\n";

        return [
            'processed_jobs' => $totalProcessed,
            'failed_jobs' => $totalFailed
        ];
    }

    /**
     * FIX-C141 (یافتهٔ ۱۴۱): خوابِ قابل‌وقفه با سیگنال — sleep() خام با
     * pcntl_async_signals پس از اجرای handler ادامه می‌یابد؛ SIGTERM در میانهٔ
     * backoff ۶۰ ثانیه‌ای تا پایان sleep پذیرفته نمی‌شد و supervisor
     * (stopwaitsecs=5) به SIGKILL می‌رفت. اکنون در گام‌های ۱ثانیه‌ای فلگ
     * shouldQuit بررسی می‌شود.
     */
    private function interruptibleSleep(int $seconds): void
    {
        $remaining = max(0, $seconds);
        while ($remaining > 0) {
            if ($this->worker->shouldQuit()) {
                return;
            }
            sleep(1);
            $remaining--;
        }
    }
}
