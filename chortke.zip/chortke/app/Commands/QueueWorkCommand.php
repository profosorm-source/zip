<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\QueueWorker;
use App\Contracts\LoggerInterface;

/**
 * CLI command daemon to run the QueueWorker and process jobs.
 *
 * Usage:
 *   php cli.php queue:work [--queue=default] [--limit=10] [--daemon] [--sleep=1] [--tries=5] [--max-time=3600] [--stop-when-empty] [--memory=256] [--max-jobs=0]
 *
 * حالت پیش‌فرض (بدون --daemon) تک‌مرحله‌ای است (سازگار با cron و تست‌ها)؛
 * حالت --daemon حلقهٔ دائمی برای supervisor است: بین نظرسنجی‌های خالی sleep
 * می‌کند، با --max-time / --memory / --max-jobs بازیافت نرم دارد و با سیگنال
 * SIGTERM به‌صورت گراس‌فول خارج می‌شود.
 * FIX-R36-W3 (F-A19e-09): --memory (پیش‌فرض ۲۵۶MB، 0=خاموش) و --max-jobs
 * (پیش‌فرض 0=خاموش) — ورکر PHPِ پردازش‌گرِ جاب‌های مالی بدون بازچرخانی حافظه
 * ریسک OOM-kill وسط کار/رشد نشت داشت؛ حالا بین iterationها soft-break می‌کند
 * (مثل max-time — supervisor دوباره بالا می‌آورد؛ هیچ جابی وسط اجرا قطع نمی‌شود).
 */
class QueueWorkCommand
{
    private QueueWorker $worker;
    private LoggerInterface $logger;
    public function __construct(
        QueueWorker $worker,
        LoggerInterface $logger
    ) {        $this->worker = $worker;
        $this->logger = $logger;
}

    /**
     * Executes the CLI command.
     */
    /**
     * @param array<int, string> $argv
     * @return array<string, mixed>
     */
    public function run(array $argv = []): array
    {
        $queue = null;
        $limit = 10;
        $daemon = false;
        $sleep = 1;
        $tries = null;
        $maxTime = 0;
        $maxMemoryMb = 256; // FIX-R36-W3 (F-A19e-09): 0 = خاموش
        $maxJobs = 0;       // FIX-R36-W3 (F-A19e-09): 0 = خاموش
        $stopWhenEmpty = false;

        foreach ($argv as $arg) {
            if (is_string($arg)) {
                if (str_starts_with($arg, '--queue=')) {
                    $queue = substr($arg, 8);
                } elseif (str_starts_with($arg, '--limit=')) {
                    $limit = (int)substr($arg, 8);
                } elseif ($arg === '--daemon') {
                    $daemon = true;
                } elseif (str_starts_with($arg, '--sleep=')) {
                    $sleep = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--tries=')) {
                    $tries = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--max-time=')) {
                    $maxTime = (int)substr($arg, 11);
                } elseif (str_starts_with($arg, '--memory=')) {
                    $maxMemoryMb = (int)substr($arg, 9);
                } elseif (str_starts_with($arg, '--max-jobs=')) {
                    $maxJobs = (int)substr($arg, 11);
                } elseif ($arg === '--stop-when-empty') {
                    $stopWhenEmpty = true;
                }
            }
        }

        // Validate range limits
        $limit = max(1, min(500, $limit));
        $sleep = max(0, min(300, $sleep));
        $maxTime = max(0, min(86400, $maxTime));
        $maxMemoryMb = max(0, min(4096, $maxMemoryMb)); // FIX-R36-W3 (F-A19e-09)
        $maxJobs = max(0, min(1000000, $maxJobs));       // FIX-R36-W3 (F-A19e-09)
        if ($tries !== null) {
            $this->worker->setMaxAttempts(max(1, min(20, $tries)));
        }

        $this->logger->info('queue.command.work.starting', [
            'queue' => $queue ?? 'all',
            'limit' => $limit,
            'daemon' => $daemon,
            'sleep' => $sleep,
            'max_time' => $maxTime
        ]);

        if ($daemon) {
            return $this->runDaemonLoop($queue, $limit, $sleep, $maxTime, $stopWhenEmpty, $maxMemoryMb, $maxJobs);
        }

        try {
            $result = $this->worker->work($queue, $limit);
            $processed = int_value($result['processed_jobs'] ?? 0);
            $failed = int_value($result['failed_jobs'] ?? 0);

            $this->logger->info('queue.command.work.completed', [
                'processed' => $processed,
                'failed' => $failed,
                'queue' => $queue ?? 'all'
            ]);

            echo "[queue:work] processed={$processed} failed={$failed} (limit={$limit})\n";

            return [
                'processed_jobs' => $processed,
                'failed_jobs' => $failed
            ];
        } catch (\Throwable $e) {
            $this->logger->error('queue.command.work.failed', [
                'queue' => $queue ?? 'all',
                'error' => $e->getMessage()
            ]);
            fwrite(STDERR, "[queue:work] error: " . $e->getMessage() . "\n");
            return [
                'processed_jobs' => 0,
                'failed_jobs' => 0,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * حلقهٔ دیمن برای supervisor — بدون این حلقه، کامند تک‌اجرایی است و
     * supervisor با ری‌استارت سریع آن را پس از startretries=10 به FATAL می‌برد.
     *
     * @return array<string, mixed>
     */
    private function runDaemonLoop(?string $queue, int $limit, int $sleep, int $maxTime, bool $stopWhenEmpty, int $maxMemoryMb = 0, int $maxJobs = 0): array
    {
        $startedAt = time();
        $totalProcessed = 0;
        $totalFailed = 0;

        while (true) {
            if ($this->worker->shouldQuit()) {
                $this->logger->info('queue.command.work.daemon_stopped_by_signal', [
                    'processed' => $totalProcessed
                ]);
                break;
            }

            try {
                $result = $this->worker->work($queue, $limit);
                $iterationProcessed = int_value($result['processed_jobs'] ?? 0);
                $iterationFailed = int_value($result['failed_jobs'] ?? 0);
            } catch (\Throwable $e) {
                // خطای زیرساختی موقت (مثلاً قطعی لحظه‌ای DB): دیمن نمی‌میرد، با فاصله ادامه می‌دهد
                $this->logger->error('queue.command.work.daemon_iteration_failed', [
                    'error' => $e->getMessage()
                ]);
                sleep(max($sleep, 5));
                continue;
            }

            $totalProcessed += $iterationProcessed;
            $totalFailed += $iterationFailed;

            if ($iterationProcessed + $iterationFailed === 0) {
                if ($stopWhenEmpty) {
                    break;
                }
                if ($sleep > 0) {
                    sleep($sleep);
                }
            }

            if ($maxTime > 0 && (time() - $startedAt) >= $maxTime) {
                // بازیافت نرم دوره‌ای (deployment recycling) — supervisor دوباره بالا می‌آورد
                $this->logger->info('queue.command.work.max_time_reached', [
                    'elapsed_seconds' => time() - $startedAt,
                    'processed' => $totalProcessed
                ]);
                break;
            }

            // FIX-R36-W3 (F-A19e-09): بازیافت نرم حافظه/شمارش جاب — فقط بین iterationها
            // (هرگز وسط اجرای جاب)؛ OOM-kill وسط کار مالی + رشد نشت خاموش می‌بندد.
            if ($maxMemoryMb > 0) {
                $usedMb = (int)(memory_get_usage(true) / 1048576);
                if ($usedMb >= $maxMemoryMb) {
                    $this->logger->info('queue.command.work.memory_limit_reached', [
                        'used_mb' => $usedMb,
                        'threshold_mb' => $maxMemoryMb,
                        'processed' => $totalProcessed,
                    ]);
                    break;
                }
            }
            if ($maxJobs > 0 && ($totalProcessed + $totalFailed) >= $maxJobs) {
                $this->logger->info('queue.command.work.max_jobs_reached', [
                    'max_jobs' => $maxJobs,
                    'processed' => $totalProcessed,
                    'failed' => $totalFailed,
                ]);
                break;
            }
        }

        $this->logger->info('queue.command.work.completed', [
            'processed' => $totalProcessed,
            'failed' => $totalFailed,
            'queue' => $queue ?? 'all',
            'daemon' => true
        ]);

        echo "[queue:work] processed={$totalProcessed} failed={$totalFailed} (daemon exit)\n";

        return [
            'processed_jobs' => $totalProcessed,
            'failed_jobs' => $totalFailed
        ];
    }
}
