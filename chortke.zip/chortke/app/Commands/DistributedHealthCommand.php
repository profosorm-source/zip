<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\CommandInterface;
use Core\Container;
use App\Services\Health\HealthCheckService;

/**
 * Distributed Systems Health Check (refactored to reuse HealthCheckService).
 * 
 * Usage: php cli.php distributed:health
 * 
 * This command now reuses the centralized probes in HealthCheckService
 * instead of duplicating SQL logic. It still has a standalone PDO fallback
 * for robustness when full bootstrap fails.
 */
class DistributedHealthCommand implements CommandInterface
{
    private Container $container;

    /**
     * FIX-CMD029: دلیلِ ماسک‌شدهٔ آخرین شکست اتصال fallback مستقل — فقط طبقه‌بندی
     * کلی + کلاس کوتاه استثنا + sqlstate؛ هرگز DSN/credential/متن کامل.
     */
    private ?string $connectFailureReason = null;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /** @param array<string, mixed> $args */
    public function run(array $args = []): int
    {
        echo "=== Chortke Distributed Systems Health Check ===\n\n";

        $healthService = null;
        try {
            $healthService = $this->container->make(HealthCheckService::class);
        } catch (\Throwable $e) {
            // Fall through to standalone mode
        }

        if ($healthService instanceof HealthCheckService) {
            // Preferred path: reuse existing service
            $this->printUsingService($healthService);
        } else {
            // Robust standalone fallback (direct PDO)
            // FIX-CMD029 (یافتهٔ ۰۲۹): شکست اتصال fallback دیگر «سلامت» گزارش نمی‌شود —
            // خط ✅ چاپ نمی‌شود، دلیل ماسک‌شده چاپ و کد خروج ۱ برمی‌گردد (FIX-C61).
            $standaloneExit = $this->printStandalone();
            if ($standaloneExit !== 0) {
                return $standaloneExit;
            }
        }

        echo "\n✅ Health check finished at " . date('Y-m-d H:i:s') . "\n";
        return 0; // FIX-C61: قرارداد کد خروج اینترفیس
    }

    private function printUsingService(HealthCheckService $svc): void
    {
        echo "📊 Using centralized HealthCheckService\n\n";

        $outbox = $svc->probeOutbox();
        $outboxPending = is_numeric($outbox['pending'] ?? null) ? (int)$outbox['pending'] : 0;
        $outboxFailed = is_numeric($outbox['failed_or_dlq'] ?? null) ? (int)$outbox['failed_or_dlq'] : 0;
        $outboxStatus = is_string($outbox['status'] ?? null) ? $outbox['status'] : 'unknown';
        printf("📤 Outbox: pending=%d failed/dlq=%d (status: %s)\n", $outboxPending, $outboxFailed, $outboxStatus);

        $dlq = $svc->probeDLQ();
        $dlqTotal = is_numeric($dlq['total_failed_jobs'] ?? null) ? (int)$dlq['total_failed_jobs'] : 0;
        $dlqStatus = is_string($dlq['status'] ?? null) ? $dlq['status'] : 'unknown';
        printf("💀 DLQ (failed_jobs): %d (status: %s)\n", $dlqTotal, $dlqStatus);

        $saga = $svc->probeSaga();
        // FIX-M6-07: نمایش کامل واژگان وضعیت — incomplete = started + running؛
        // failed = failed + compensation_failed (سگال‌های نیمه‌تمام/جبرانِ شکسته
        // دیگر نامرئی نیستند).
        $sagaIncomplete = (is_numeric($saga['started'] ?? null) ? (int)$saga['started'] : 0)
            + (is_numeric($saga['running'] ?? null) ? (int)$saga['running'] : 0);
        $sagaFailed = (is_numeric($saga['failed'] ?? null) ? (int)$saga['failed'] : 0)
            + (is_numeric($saga['compensation_failed'] ?? null) ? (int)$saga['compensation_failed'] : 0);
        $sagaCompensated = is_numeric($saga['compensated'] ?? null) ? (int)$saga['compensated'] : 0;
        $sagaCompleted = is_numeric($saga['completed'] ?? null) ? (int)$saga['completed'] : 0;
        $sagaStatus = is_string($saga['status'] ?? null) ? $saga['status'] : 'unknown';
        printf(
            "🔄 Saga: incomplete=%d failed=%d compensated=%d completed=%d (status: %s)\n",
            $sagaIncomplete,
            $sagaFailed,
            $sagaCompensated,
            $sagaCompleted,
            $sagaStatus
        );

        $idemp = $svc->probeIdempotency();
        $pendingKeys = is_numeric($idemp['pending_keys'] ?? null) ? (int)$idemp['pending_keys'] : 0;
        printf("🔁 Idempotency pending keys: %d\n", $pendingKeys);

        echo "\n";
    }

    private function printStandalone(): int
    {
        echo "⚠️  Using standalone PDO fallback (HealthCheckService not available)\n\n";

        $this->connectFailureReason = null;
        $pdo = $this->getPdo();
        if (!$pdo) {
            // FIX-CMD029 (یافتهٔ ۰۲۹): دلیلِ کوتاه و ماسک‌شده (طبقه‌بندی + sqlstate) —
            // متنِ کامل استثنا/DSN هرگز به خروجی نمی‌رود؛ جزئیات فقط error_log.
            $reason = $this->connectFailureReason ?? 'unknown (details in error log)';
            echo "❌ Could not connect to database (reason: {$reason}).\n";
            return 1;
        }

        // Same queries as before for robustness
        // FIX-P3-CMD-031 (یافتهٔ ۰۳۱): هر پروبِ مستقل شکستش را با error_log ثبت می‌کند
        // (کلاس + پیام کامل در لاگ) — خروجی operator همان نشانگر عمومی '(error)' می‌ماند
        // اما دیگر غیرقابل‌تشخیص نیست (الگوی خانه: پیام عمومی به خروجی، جزئیات به لاگ).
        try {
            $pending = $this->queryCount($pdo, "SELECT COUNT(*) FROM outbox_events WHERE status='pending'");
            $bad = $this->queryCount($pdo, "SELECT COUNT(*) FROM outbox_events WHERE status IN ('failed','dlq')");
            printf("📤 Outbox: Pending=%d Failed/DLQ=%d\n", $pending, $bad);
        } catch (\Throwable $e) {
            @error_log('[DistributedHealthCommand] outbox probe failed: ' . get_class($e) . ' — ' . $e->getMessage());
            echo "📤 Outbox: (error)\n";
        }

        try {
            $c = $this->queryCount($pdo, "SELECT COUNT(*) FROM failed_jobs");
            printf("💀 DLQ (failed_jobs): %d\n", $c);
        } catch (\Throwable $e) {
            @error_log('[DistributedHealthCommand] dlq probe failed: ' . get_class($e) . ' — ' . $e->getMessage());
            echo "💀 DLQ: (error)\n";
        }

        try {
            // FIX-M6-07: واژگان کامل — started (ناکامل/گیرکرده پس از crash) و
            // compensation_failed هم شمرده می‌شوند؛ قبلاً فقط running/failed legacy
            // دیده می‌شد و sagaهای نیمه‌تمام واقعی نامرئی بودند.
            $run = $this->queryCount($pdo, "SELECT COUNT(*) FROM saga_executions WHERE status IN ('started','running')");
            $fail = $this->queryCount($pdo, "SELECT COUNT(*) FROM saga_executions WHERE status IN ('failed','compensation_failed')");
            $comp = $this->queryCount($pdo, "SELECT COUNT(*) FROM saga_executions WHERE status='compensated'");
            $done = $this->queryCount($pdo, "SELECT COUNT(*) FROM saga_executions WHERE status='completed'");
            printf("🔄 Saga: incomplete=%d failed=%d compensated=%d completed=%d\n", $run, $fail, $comp, $done);
        } catch (\Throwable $e) {
            @error_log('[DistributedHealthCommand] saga probe failed: ' . get_class($e) . ' — ' . $e->getMessage());
            echo "🔄 Saga: (error)\n";
        }

        try {
            $p = $this->queryCount($pdo, "SELECT COUNT(*) FROM idempotency_keys WHERE status='pending'");
            printf("🔁 Idempotency pending: %d\n", $p);
        } catch (\Throwable $e) {
            @error_log('[DistributedHealthCommand] idempotency probe failed: ' . get_class($e) . ' — ' . $e->getMessage());
            echo "🔁 Idempotency: (error)\n";
        }

        return 0;
    }

    /**
     * FIX-CMD029: طبقه‌بندی کوتاه و ماسک‌شدهٔ شکست اتصال — فقط پیامِ عمومی +
     * کلاس کوتاه استثنا + sqlstate؛ رشتهٔ DSN/credential استخراج نمی‌شود.
     */
    private function classifyConnectionFailure(\Throwable $e): string
    {
        $short = (new \ReflectionClass($e))->getShortName();
        $sqlstate = (string)$e->getCode();
        $msg = strtolower($e->getMessage());
        if (str_contains($msg, 'connection refused')) {
            $kind = 'connection_refused';
        } elseif (str_contains($msg, 'timed out') || str_contains($msg, 'timeout')) {
            $kind = 'connection_timeout';
        } elseif (str_contains($msg, 'unknown mysql server host') || str_contains($msg, 'getaddrinfo') || str_contains($msg, 'name or service not known')) {
            $kind = 'dns_resolution_failed';
        } elseif (str_contains($msg, 'access denied')) {
            $kind = 'auth_rejected';
        } else {
            $kind = 'connection_failed';
        }
        return "{$kind} ({$short}/sqlstate {$sqlstate})";
    }

    private function queryCount(\PDO $pdo, string $sql): int
    {
        $statement = $pdo->query($sql);
        if ($statement === false) {
            throw new \RuntimeException('Database health-check query failed to execute.');
        }

        $value = $statement->fetchColumn();
        if (!is_int($value) && !is_string($value)) {
            throw new \UnexpectedValueException('Database health-check count query returned a non-scalar value.');
        }
        if (!is_numeric($value)) {
            throw new \UnexpectedValueException('Database health-check count query returned a non-numeric value.');
        }

        return (int)$value;
    }

    private function getPdo(): ?\PDO
    {
        try {
            $db = $this->container->make(\Core\Database::class);
            if ($db instanceof \Core\Database) {
                return $db->getPdo();
            }
        } catch (\Throwable $e) {
            @error_log('[DistributedHealthCommand\] ' . $e->getMessage());
        }

        $envPath = __DIR__ . '/../../.env';
        if (!file_exists($envPath)) return null;

        // FIX-P3-CMD-030 (یافتهٔ ۰۳۰): نتیجهٔ parse_ini_file بدون گارد مصرف نمی‌شود —
        // سینتکس خراب .env ⇒ false و دسترسی $env['DB_HOST'] روی false خطا/هشدار می‌داد؛
        // اکنون is_array-guard با error_log و بازگشت null (fallback طبق قرارداد شکست می‌کند).
        $env = parse_ini_file($envPath, false, INI_SCANNER_RAW);
        if (!is_array($env)) {
            @error_log('[DistributedHealthCommand] standalone fallback: .env could not be parsed (ini syntax error?).');
            return null;
        }
        $host = is_scalar($env['DB_HOST'] ?? null) ? (string)$env['DB_HOST'] : '127.0.0.1';
        $port = is_scalar($env['DB_PORT'] ?? null) ? (string)$env['DB_PORT'] : '3306';
        $db   = is_scalar($env['DB_NAME'] ?? null) ? (string)$env['DB_NAME'] : 'chortke';
        // FIX راند ۷۵: هم‌راستا با config.php — نام رسمی DB_USER/DB_PASS،
        // alias قدیمی DB_USERNAME/DB_PASSWORD هم پذیرفته می‌شود.
        $userRaw = $env['DB_USER'] ?? $env['DB_USERNAME'] ?? 'root';
        $passRaw = $env['DB_PASS'] ?? $env['DB_PASSWORD'] ?? '';
        $user = is_scalar($userRaw) ? (string)$userRaw : 'root';
        $pass = is_scalar($passRaw) ? (string)$passRaw : '';

        try {
            $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4";
            // FIX-C138 (یافتهٔ ۱۳۸): تایم‌اوت اتصال — قبلاً fallback PDO بدون
            // ATTR_TIMEOUT ساخته می‌شد و DB غیرقابل‌دسترس (accept-queue پر /
            // firewall drop) کانکشن را نامحدود معطل می‌کرد و پروبِ
            // distributed:health (کرون ۵ دقیقه‌ای) هنگ می‌کرد. هم‌راستا با
            // core/Database.php: connect ۲ ثانیه + timeout خواندن/نوشتن ۳ ثانیه.
            return new \PDO($dsn, $user, $pass, [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_OBJ,
                \PDO::ATTR_TIMEOUT => 2,
                \Pdo\Mysql::ATTR_READ_TIMEOUT => 3,
                \Pdo\Mysql::ATTR_WRITE_TIMEOUT => 3,
            ]);
        } catch (\Throwable $e) {
            // FIX-CMD029: جزئیات کامل فقط در error_log؛ خروجی فقط reason ماسک‌شده.
            $this->connectFailureReason = $this->classifyConnectionFailure($e);
            @error_log('[DistributedHealthCommand] standalone PDO connect failed: ' . get_class($e) . ' ' . $e->getMessage());
            return null;
        }
    }
}
