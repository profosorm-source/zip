<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\DatabaseAnalyzerService;
use Core\Command;

/**
 * db:analyze — ابزار تحلیل/سلامت دیتابیس
 *
 * FIX-C136 (یافتهٔ ۱۳۶): action ناشناخته دیگر بی‌صدا به overview تبدیل نمی‌شود
 * (usage error + exit 1)؛ و ایندکس آرگومان‌ها با هر دو قرارداد فراخوانی سازگار شد —
 * dispatcher آرگومان بریده‌شده می‌دهد (sub-action روی args[0])، درحالی‌که تست‌ها/مستندات
 * full argv می‌دهند (sub-action روی args[2])؛ قبلاً از مسیر dispatcher همهٔ
 * sub-actionها به overview می‌افتادند.
 *
 * FIX-C135 (یافتهٔ ۱۳۵): شکست بخش‌های پروب دیگر «سالم‌نما» نیست —
 * (unavailable) با فلش ❌ همراه می‌شود، healthCheck غیرسالم exit 1 می‌دهد و
 * هر شکست به کد خروج غیرصفر منعکس می‌شود (کرون/سوپروایزر retry را تشخیص می‌دهند).
 */
class DatabaseAnalyzerCommand extends Command
{
    private const SUB_ACTIONS = [
        'overview', 'indexes', 'suggest-indexes', 'query',
        'slow-queries', 'deadlocks', 'health', 'connections', 'optimize',
    ];

    private DatabaseAnalyzerService $analyzer;
    private bool $hadFailure = false;

    /** FIX-P3-CMD-025: پنجره‌های خروجی خام — پیش‌فرض ماسک؛ فقط با --raw بی‌ماسک. */
    private bool $rawOutput = false;

    public function __construct(DatabaseAnalyzerService $analyzer)
    {
        $this->analyzer = $analyzer;
    }

    /**
     * @param list<string> $args
     */
    /** @param array<int|string, mixed> $args */
    public function run(array $args = []): int
    {
        // FIX-C136: نرمال‌سازی قرارداد آرگومان (full argv یا args بریده‌شده)
        if (isset($args[1]) && $args[1] === 'db:analyze') {
            $args = array_values(array_slice($args, 2));
        } elseif (isset($args[0]) && $args[0] === 'db:analyze') {
            $args = array_values(array_slice($args, 1));
        }
        $subAction = $args[0] ?? 'overview';

        // FIX-P3-CMD-025: فلگ --raw — نمایش عمدیِ literalها فقط با پرچم صریح
        $this->rawOutput = in_array('--raw', $args, true);

        // FIX-C136: اکشن ناشناخته → خطای صریح (نه fallback خاموش به overview)
        if (!in_array($subAction, self::SUB_ACTIONS, true)) {
            $this->error("Unknown db:analyze action: {$subAction}");
            $this->line('');
            $this->showUsage();
            return 1;
        }

        switch ($subAction) {
            case 'indexes':
                $table = $args[1] ?? '';
                if ($table === '') {
                    $this->error('Usage: php cli.php db:analyze indexes <table_name>');
                    return 1;
                }
                $this->showIndexRecommendations($table);
                break;

            case 'suggest-indexes':
                $table = $args[1] ?? '';
                if ($table === '') {
                    $this->error('Usage: php cli.php db:analyze suggest-indexes <table_name>');
                    return 1;
                }
                $this->showSuggestedIndexes($table);
                break;

            case 'query':
                $sql = $args[1] ?? '';
                if ($sql === '') {
                    $this->error('Usage: php cli.php db:analyze query "SELECT ..."');
                    return 1;
                }
                $this->analyzeQuery($sql);
                break;

            case 'slow-queries':
                $this->showSlowQueries();
                break;

            case 'deadlocks':
                $this->showDeadlockInfo();
                break;

            case 'health':
                $this->showHealth();
                break;

            case 'connections':
                $this->showConnections();
                break;

            case 'optimize':
                $this->runOptimize();
                break;

            case 'overview':
                $this->showOverview();
                break;
        }

        return $this->hadFailure ? 1 : 0;
    }

    private function showUsage(): void
    {
        $this->info("Available sub-commands:");
        $this->line("  php cli.php db:analyze overview                     — Aggregate overview");
        $this->line("  php cli.php db:analyze indexes <table>        — FK-based index recommendations");
        $this->line("  php cli.php db:analyze suggest-indexes <table> — Smart index suggestions");
        $this->line("  php cli.php db:analyze query \"<SQL>\"           — EXPLAIN a query");
        $this->line("  php cli.php db:analyze slow-queries              — List slow queries");
        $this->line("  php cli.php db:analyze deadlocks                 — Check for deadlocks");
        $this->line("  php cli.php db:analyze health                    — Full health check");
        $this->line("  php cli.php db:analyze connections               — Connection pool stats");
        $this->line("  php cli.php db:analyze optimize                  — Run optimization");
    }

    private function markFailure(string $section, string $message): void
    {
        $this->hadFailure = true;
        $this->line("  ❌ {$section} unavailable — {$message}");
    }

    /**
     * FIX-P3-CMD-025: ماسکِ literalهای SQL (رشته‌های کوتیشن‌دار و اعداد) —
     * DIGEST_TEXT/خلاصهٔ deadlock می‌توانند مقدار واقعی ستون‌ها (ایمیل، توکن، مبلغ)
     * را به ترمینال operator بیاورند. خروجی پیش‌فرض نرمال‌شده است؛ --raw عمدی آن
     * را نشان می‌دهد.
     */
    private function maskSqlLiterals(string $sql): string
    {
        if ($this->rawOutput) {
            return $sql;
        }
        $masked = (string)preg_replace("/'(?:[^'\\\\]|\\\\.)*'/", "'?'", $sql);
        $masked = (string)preg_replace('/"(?:[^"\\\\]|\\\\.)*"/', '"?"', $masked);
        $masked = (string)preg_replace('/\b\d+(?:\.\d+)?\b/', '?', $masked);
        return $masked;
    }

    /**
     * FIX-P3-CMD-028 (یافتهٔ ۰۲۸): ✅/❌ از قواعد شکل‌آگاه (bool vs array vs scalar)
     * مشتق می‌شود — قبلاً empty() روی آرایهٔ خالی (issues/recommendations سالم)
     * ❌ و hadFailure می‌ساخت و یک DB سالمِ کاملاً سبز، overview را «شکست‌خورده»
     * گزارش می‌کرد؛ برعکس رشتهٔ غیرخالیِ همیشه-حقیقت هم بدون معنا ✅ می‌گرفت.
     *
     * @return array{ok: bool, display: string, failed: bool}
     */
    private function classifyHealthEntry(string $key, mixed $val): array
    {
        if (is_bool($val)) {
            return ['ok' => $val, 'display' => $val ? 'OK' : 'NOT OK', 'failed' => !$val];
        }
        if (is_array($val)) {
            // کلیدهای «فهرستِ مشکل» — خالی = سالم؛ پر = یافتهٔ واقعی
            $isFindings = $key === 'issues' || $key === 'recommendations';
            if ($isFindings) {
                $ok = $val === [];
                return ['ok' => $ok, 'display' => $ok ? 'OK' : count($val) . ' item(s)', 'failed' => $key === 'issues' && !$ok];
            }
            return ['ok' => $val !== [], 'display' => $val === [] ? 'OK' : count($val) . ' item(s)', 'failed' => $val === []];
        }
        // اسکالر/نال — non-empty یعنی معنادار (مثلاً checked_at)
        $ok = $val !== null && $val !== '' && $val !== 0 && $val !== '0';
        $display = is_scalar($val) ? str_value($val) : 'OK';
        return ['ok' => $ok, 'display' => $display !== '' ? $display : 'OK', 'failed' => !$ok];
    }

    private function showOverview(): void
    {
        $this->info('═══ Database Health Overview ═══');

        $this->line('');
        $this->info('Connection Pool:');
        try {
            $stats = $this->analyzer->getConnectionStats();
            foreach ((array)$stats as $key => $val) {
                $this->line("  " . str_value($key) . ": " . str_value($val));
            }
        } catch (\Throwable $e) {
            $this->markFailure('Connection pool', $e->getMessage());
        }

        $this->line('');
        $this->info('Health Check:');
        try {
            $health = $this->analyzer->healthCheck();
            foreach ((array)$health as $key => $val) {
                // FIX-P3-CMD-028: استخراج ✅/❌ از قواعد شکل‌آگاه (بالا)
                $entry = $this->classifyHealthEntry((string)$key, $val);
                if ($entry['failed']) {
                    $this->hadFailure = true;
                }
                $status = $entry['ok'] ? '✅' : '❌';
                $this->line("  {$status} {$key}: " . $entry['display']);
            }
        } catch (\Throwable $e) {
            $this->markFailure('Health check', $e->getMessage());
        }

        $this->line('');
        $this->info('Table Statistics:');
        try {
            $tables = $this->analyzer->getTableStats();
            foreach ($tables as $row) {
                $item = (object)$row;
                $name = (string)($item->table_name ?? $item->TABLE_NAME ?? '?');
                $rows = (string)($item->row_count ?? $item->TABLE_ROWS ?? '?');
                $size = (string)($item->size_mb ?? $item->SIZE_MB ?? '?');
                $this->line(sprintf("  %-40s %10s rows   %10s", $name, $rows, $size));
            }
        } catch (\Throwable $e) {
            $this->markFailure('Table statistics', $e->getMessage());
        }

        $this->line('');
        $this->showUsage();
    }

    private function showIndexRecommendations(string $table): void
    {
        $this->info("FK-based index recommendations for: {$table}");
        try {
            $recs = $this->analyzer->getIndexRecommendations($table);
            if (empty($recs)) {
                $this->line("  No recommendations.");
                return;
            }
            foreach ($recs as $rec) {
                $col = str_value($rec['column'] ?? '');
                $sug = str_value($rec['suggestion'] ?? '');
                $this->line(sprintf("  %-30s → %s", $col, $sug));
            }
        } catch (\Throwable $e) {
            $this->hadFailure = true;
            $this->error("Error: " . $e->getMessage());
        }
    }

    private function showSuggestedIndexes(string $table): void
    {
        $this->info("Smart index suggestions for: {$table}");
        try {
            $suggestions = $this->analyzer->suggestIndexes($table);
            if (empty($suggestions)) {
                $this->line("  No suggestions.");
                return;
            }
            foreach ($suggestions as $s) {
                $idxName = str_value($s['index_name'] ?? '');
                $score = str_value($s['score'] ?? '-');
                $this->line(sprintf("  %-40s (score: %s)", $idxName, $score));
            }
        } catch (\Throwable $e) {
            $this->hadFailure = true;
            $this->error("Error: " . $e->getMessage());
        }
    }

    private function analyzeQuery(string $sql): void
    {
        $this->info("Analyzing query...");
        try {
            $result = $this->analyzer->analyzeQuery($sql);
            $json = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $this->line($json === false ? 'Unable to encode query analysis.' : $json);
        } catch (\Throwable $e) {
            $this->hadFailure = true;
            $this->error("Error: " . $e->getMessage());
        }
    }

    private function showSlowQueries(): void
    {
        $this->info('Recent Slow Queries:');

        try {
            $queries = $this->analyzer->getSlowQueries();
            if ($queries === []) {
                $this->line('  No slow-query data is available.');
                return;
            }

            // FIX-P3-CMD-025: ماسک literalهای DIGEST_TEXT قبل از چاپ (بدون --raw)
            if (!$this->rawOutput) {
                foreach ($queries as $i => $row) {
                    if (is_array($row) && isset($row['sql_text']) && is_string($row['sql_text'])) {
                        $queries[$i]['sql_text'] = $this->maskSqlLiterals($row['sql_text']);
                    }
                }
                $this->line('  (SQL literals masked — pass --raw to show unmasked text)');
            }

            $json = json_encode($queries, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $this->line($json === false ? '  Unable to encode slow-query data.' : $json);
        } catch (\Throwable $e) {
            $this->hadFailure = true;
            $this->error('Error: ' . $e->getMessage());
        }
    }

    private function showDeadlockInfo(): void
    {
        $this->info('Recent InnoDB Deadlocks:');

        try {
            $deadlocks = $this->analyzer->getDeadlockInfo();
            if ($deadlocks === []) {
                $this->line('  No recent deadlocks detected.');
                return;
            }

            // FIX-P3-CMD-025: خلاصهٔ deadlock قطعه‌های SQL با literal دارد — ماسک
            if (!$this->rawOutput) {
                foreach ($deadlocks as $i => $row) {
                    if (is_array($row) && isset($row['summary']) && is_string($row['summary'])) {
                        $deadlocks[$i]['summary'] = $this->maskSqlLiterals($row['summary']);
                    }
                }
                $this->line('  (SQL literals masked — pass --raw to show unmasked text)');
            }

            $json = json_encode($deadlocks, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $this->line($json === false ? '  Unable to encode deadlock data.' : $json);
        } catch (\Throwable $e) {
            $this->hadFailure = true;
            $this->error('Error: ' . $e->getMessage());
        }
    }

    private function showHealth(): void
    {
        $this->info('Database Health Check:');
        try {
            $health = $this->analyzer->healthCheck();
            foreach ((array)$health as $key => $val) {
                // FIX-P3-CMD-028: همان قواعد شکل‌آگاه در زیراکشن health —
                // آرایهٔ خالیِ issues/recommendations دیگر «NEEDS ATTENTION» نیست.
                $entry = $this->classifyHealthEntry((string)$key, $val);
                if ($entry['failed']) {
                    $this->hadFailure = true;
                }
                $status = $entry['ok'] ? '✅' : '❌';
                $this->line("  {$status} {$key}" . ($entry['ok'] ? '' : ' — NEEDS ATTENTION'));
            }
        } catch (\Throwable $e) {
            $this->hadFailure = true;
            $this->error("Error: " . $e->getMessage());
        }
    }

    private function showConnections(): void
    {
        $this->info('Connection Pool Stats:');
        try {
            $stats = $this->analyzer->getConnectionStats();
            foreach ((array)$stats as $key => $val) {
                $this->line("  " . str_value($key) . ": " . str_value($val));
            }
        } catch (\Throwable $e) {
            $this->hadFailure = true;
            $this->error("Error: " . $e->getMessage());
        }
    }

    private function runOptimize(): void
    {
        $this->info('Running database optimization...');
        try {
            $result = $this->analyzer->optimizeDatabase();
            $json = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $this->line($json === false ? 'Unable to encode optimization result.' : $json);
        } catch (\Throwable $e) {
            $this->hadFailure = true;
            $this->error("Error: " . $e->getMessage());
        }
    }
}
