<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Database;
use App\Contracts\LoggerInterface;
use App\Services\Shared\RoleAssignmentService;

/**
 * Command: RbacReconcileCommand — 🛡️ FIX-S9-01 (گزارش بخش ۹)
 *
 * Usage: php cli.php rbac:reconcile-roles [--apply] [--user=42]
 *
 * همگام‌سازی idempotent «سه‌گانهٔ نقش» (users.role / users.role_id / user_roles):
 *   · گزارش drift بدون نوشتن (پیش‌فرض): تعداد checked / role_id_missing /
 *     pivot_missing / pivot_stale / orphan_role
 *   · --apply: اجرای ensurePivotForPrimary برای همهٔ کاربران دارای drift
 *     (نوشتن همیشه تراکنشی و از طریق RoleAssignmentService است)
 *
 * پس از این دستور، هیچ ادمینِ دارایِ users.role='admin' بدون ردیف pivot
 * نمی‌ماند و ستون role_id همه با نقش واقعی همگام است.
 */
class RbacReconcileCommand
{
    private Database $db;
    private LoggerInterface $logger;
    private RoleAssignmentService $roleAssignment;

    public function __construct(Database $db, LoggerInterface $logger, RoleAssignmentService $roleAssignment)
    {
        $this->db = $db;
        $this->logger = $logger;
        $this->roleAssignment = $roleAssignment;
    }

    /** @param array<int, string> $argv */
    public function run(array $argv): int
    {
        $apply = in_array('--apply', $argv, true);
        $targetUser = null;
        foreach ($argv as $arg) {
            if (str_starts_with((string)$arg, '--user=')) {
                $targetUser = (int)substr((string)$arg, 7);
            }
        }

        echo "── rbac:reconcile-roles — گزارش همگام‌سازی نقش‌ها ──\n";

        if ($targetUser !== null) {
            $ok = $this->roleAssignment->ensurePivotForPrimary($targetUser);
            echo ($ok ? "  ✓" : "  ✗") . " user #{$targetUser} همگام شد.\n";
            return $ok ? 0 : 1;
        }

        $stats = $this->roleAssignment->driftReport();
        echo "  checked         : {$stats['checked']}\n";
        echo "  role_id_missing : {$stats['role_id_missing']}\n";
        echo "  pivot_missing   : {$stats['pivot_missing']}\n";
        echo "  pivot_stale     : {$stats['pivot_stale']}\n";
        echo "  orphan_role     : {$stats['orphan_role']}\n";

        if (!$apply) {
            if ($stats['role_id_missing'] + $stats['pivot_missing'] > 0) {
                echo "\n  برای اصلاح: php cli.php rbac:reconcile-roles --apply\n";
            } else {
                echo "\n  ✓ هیچ drift فعالی یافت نشد.\n";
            }
            return 0;
        }

        if ($stats['role_id_missing'] + $stats['pivot_missing'] === 0) {
            echo "\n  ✓ چیزی برای اصلاح نیست.\n";
            return 0;
        }

        echo "\n  ── اعمال اصلاحات ──\n";
        $fixed = 0;
        $failed = 0;

        $rows = $this->db->fetchAll(
            "SELECT u.id FROM users u
             LEFT JOIN roles r ON r.slug = u.role AND r.deleted_at IS NULL AND r.is_active = 1
             WHERE u.deleted_at IS NULL
               AND (
                     (u.role_id IS NULL AND r.id IS NOT NULL)
                  OR (u.role_id IS NOT NULL AND u.role_id != r.id)
                  OR (u.role IN ('admin','super_admin','support')
                      AND NOT EXISTS (SELECT 1 FROM user_roles ur
                                        INNER JOIN roles r3 ON r3.id = ur.role_id
                                       WHERE ur.user_id = u.id AND r3.slug = u.role))
               )"
        );

        foreach ($rows as $row) {
            $uid = (int)$row->id;
            if ($this->roleAssignment->ensurePivotForPrimary($uid)) {
                echo "  ✓ user #{$uid} همگام شد.\n";
                $fixed++;
            } else {
                echo "  ✗ user #{$uid} شکست (لاگ rbac را ببینید).\n";
                $failed++;
            }
        }

        $this->logger->activity('rbac.reconcile_applied', 'اجرای rbac:reconcile-roles --apply (FIX-S9-01)', 0, [
            'fixed'  => $fixed,
            'failed' => $failed,
        ]);

        echo "\n  جمع: {$fixed} اصلاح شد، {$failed} شکست.\n";
        return $failed > 0 ? 1 : 0;
    }
}
