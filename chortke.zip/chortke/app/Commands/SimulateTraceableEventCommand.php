<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\CommandInterface;
use Core\Container;
use Core\Database;

/**
 * Simulate a traceable distributed event (for testing tracing + outbox flow).
 * Usage: php cli.php simulate:traceable-event --type=wallet.transfer --user=5 [--confirm]
 *
 * FIX-CMD121 (یافتهٔ ۱۲۱ — بحرانی): این ابزار قبلاً بدون هیچ گارد محیطی/تأییدی،
 * ردیف واقعی در outbox_events می‌نوشت (INSERT با status='pending') — در
 * production یعنی تولید رویداد تقلبی در لایهٔ توزیع واقعی. اکنون:
 *   ۱) در production به‌طور قطعی ممنوع است (fail-closed، خروجی ۱)؛
 *   ۲) در محیط‌های غیرتولیدی، پیش‌فرض DRY-RUN است و درج واقعی نیازمند --confirm؛
 *   ۳) قبلاً فلگ‌های --type/--user از CLI اصلاً parse نمی‌شدند (dispatcher
 *      آرگومان‌ها را لیست می‌دهد) و همیشه پیش‌فرض‌ها ('test.event'، کاربر ۵)
 *      مصرف می‌شد؛ اکنون پارس صحیح هر دو شکل لیست/مقداری انجام می‌شود.
 *
 * FIX-CMD122 (یافتهٔ ۱۲۲): --type دارای allowlist سخت‌گیرانه است — هر رشتهٔ
 * دلخواهی دیگر event_type جعلی در outbox تولید نمی‌کند.
 *
 * FIX-CMD123 (یافتهٔ ۱۲۳): --user اجباری، صحت‌سنجی‌شده و باید در جدول users
 * وجود داشته باشد — پیش‌فرضِ خاموش «کاربر ۵» و aggregate یتیم (الگوی نویز
 * X368) دیگر ممکن نیست.
 *
 * FIX-P3-CMD-124 (یافتهٔ ۱۲۴): این ابزار فقط برای محیط‌های تست/دمو است (در
 * production fail-closed — بند CMD-121). ایدمپوتنسی تکرار: correlation_id از
 * این راند به‌صورت قطعی از (event_type، user_id) ساخته می‌شود و پیش از INSERT،
 * ردیف شبیه‌سازی‌شدهٔ pendingِ همان (type، user) جست‌وجو و بازاستفاده می‌شود —
 * تکرار اجرای ‎--confirm دیگر ردیف‌های pending تکراری در outbox نمی‌سازد.
 */
class SimulateTraceableEventCommand implements CommandInterface
{
    /**
     * FIX-CMD122: allowlist انواع رویداد شبیه‌سازی‌شدنی — عمداً محدود به
     * الگوهای واقعیِ استفاده‌شده در دموی tracing؛ گسترش آن تصمیم صریح کد است.
     */
    private const ALLOWED_EVENT_TYPES = [
        'test.event',
        'wallet.transfer',
        'wallet.deposit',
        'payment.completed',
        'user.registered',
    ];

    private Database $db;

    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    private function getDb(): Database
    {
        // FIX-P3-CMD-126: صحت‌سنجی instanceof فقط یک‌جا — نسخه‌های تکراریِ مرده حذف شدند.
        if (!isset($this->db)) {
            $resolved = $this->container->make(Database::class);
            if (!$resolved instanceof Database) {
                throw new \RuntimeException("Invalid database instance");
            }
            $this->db = $resolved;
        }
        return $this->db;
    }

    /**
     * پارس آرگومان‌ها به شکل یکسان برای دو حالت:
     *  - لیستی (CliDispatcher): ['--type=wallet.transfer', '--user=5', '--confirm']
     *  - مقداری (فراخوانی برنامه‌نویسی/تست): ['type' => 'wallet.transfer', 'user' => 5]
     *
     * @param array<int|string, mixed> $args
     * @return array{options: array<string, mixed>, flags: array<string, bool>}
     */
    private function parseArgs(array $args): array
    {
        $options = [];
        $flags = [];
        foreach ($args as $k => $v) {
            if (is_int($k) && is_string($v) && str_starts_with($v, '--')) {
                $body = substr($v, 2);
                if (str_contains($body, '=')) {
                    [$key, $val] = explode('=', $body, 2);
                    $options[$key] = $val;
                } elseif ($body !== '') {
                    $flags[$body] = true;
                }
            } elseif (is_string($k) && str_starts_with($k, '--')) {
                $options[substr($k, 2)] = $v; // شکل 'type=...' مقداری
            } elseif (is_string($k)) {
                $options[$k] = $v;
            } elseif (is_string($v) && str_starts_with($v, '--') === false) {
                // مقادیر متنی لیستی بدون -- نادیده گرفته می‌شوند (اکتشن و غیره)
            }
        }
        return ['options' => $options, 'flags' => $flags];
    }

    /** @param array<string, mixed> $args */

    public function run(array $args = []): int
    {
        // FIX-CMD121 (بند ۱): ممنوعیت مطلق در production — fail-closed
        $isProduction = (config('app.env') === 'production' || env('APP_ENV') === 'production');
        if ($isProduction) {
            fwrite(STDERR, "[simulate] REFUSED: simulator never writes to the production outbox (CMD-121 fail-closed).\n");
            return 1;
        }

        $parsed = $this->parseArgs($args);
        $options = $parsed['options'];
        $flags = $parsed['flags'];

        // FIX-CMD122: allowlist نوع رویداد
        $typeRaw = $options['type'] ?? 'test.event';
        $type = is_string($typeRaw) ? $typeRaw : '';
        if (!in_array($type, self::ALLOWED_EVENT_TYPES, true)) {
            fwrite(STDERR, "[simulate] REFUSED: --type must be one of: " . implode(', ', self::ALLOWED_EVENT_TYPES) . " (CMD-122 allowlist).\n");
            return 1;
        }

        // FIX-CMD123: کاربر صریح، مثبت و موجود
        $userRaw = $options['user'] ?? null;
        if (!is_numeric($userRaw) || (int)$userRaw <= 0) {
            fwrite(STDERR, "[simulate] REFUSED: explicit --user=<positive id of an existing user> is required (CMD-123; no silent default).\n");
            return 1;
        }
        $userId = (int)$userRaw;
        $userRow = $this->getDb()->fetch("SELECT id FROM users WHERE id = ? LIMIT 1", [$userId]);
        if ($userRow === null || $userRow === false) {
            fwrite(STDERR, "[simulate] REFUSED: user id {$userId} does not exist — orphan aggregates are not allowed.\n");
            return 1;
        }

        $confirm = isset($flags['confirm']);

        // FIX-P3-CMD-124: correlation قطعی بر پایهٔ (type، user) — شناسهٔ تکرارِ
        // همان شبیه‌سازی قابل‌ردیابی و قابل‌dedup می‌شود.
        $correlationId = 'sim-' . substr(md5($type . ':' . $userId), 0, 16);
        echo "Simulating traceable event... (test/demo only — never writes in production)\n";
        echo "correlation_id: $correlationId\n";
        echo "event_type: $type\n";
        echo "user_id: $userId\n\n";

        if (!$confirm) {
            // FIX-CMD121 (بند ۲): پیش‌فرض DRY-RUN — هیچ نوشتنی بدون تأیید صریح
            echo "[simulate] DRY-RUN: nothing was inserted. Re-run with --confirm to insert into outbox_events.\n";
            return 0; // FIX-C61: قرارداد کد خروج اینترفیس
        }

        // Insert into outbox (this is what real code does)
        // FIX-P3-CMD-124: dedup per (type، user) — ردیف شبیه‌سازی‌شدهٔ pendingِ موجود
        // (متمایز از رویدادهای واقعی با simulated_by) بازاستفاده می‌شود، نه تکرار.
        $existing = $this->getDb()->fetch(
            "SELECT id, payload FROM outbox_events
             WHERE event_type = ? AND aggregate_id = ? AND status = 'pending'
             ORDER BY id DESC LIMIT 1",
            [$type, (string)$userId]
        );
        if ($existing !== null && $existing !== false) {
            $existingPayloadRaw = is_object($existing) ? (string)($existing->payload ?? '') : '';
            $decoded = json_decode($existingPayloadRaw, true);
            if (is_array($decoded) && ($decoded['simulated_by'] ?? null) === 'simulate:traceable-event') {
                $existingId = is_object($existing) ? (string)($existing->id ?? '?') : '?';
                echo "[simulate] existing pending simulated event found (id={$existingId}) — no duplicate inserted (CMD-124 dedup).\n";
                return 0; // FIX-C61: قرارداد کد خروج اینترفیس
            }
        }

        // FIX-P3-CMD-125 (یافتهٔ ۱۲۵): خروجی json_encode و نتیجهٔ insert کنترل می‌شود —
        // payload ناقص/insert ناموفق دیگر بی‌صدا lastInsertId=0 گزارش نمی‌شود.
        $payloadJson = json_encode([
            'user_id' => $userId,
            'correlation_id' => $correlationId,
            'simulated_at' => date('c'),
            'simulated_by' => 'simulate:traceable-event',
        ]);
        if ($payloadJson === false) {
            fwrite(STDERR, "[simulate] error: payload encoding failed — event not inserted.\n");
            return 1;
        }

        try {
            $this->getDb()->query(
                "INSERT INTO outbox_events (aggregate_type, aggregate_id, event_type, payload, status, attempts, available_at, created_at, updated_at)
                 VALUES (?, ?, ?, ?, 'pending', 0, NOW(), NOW(), NOW())",
                ['user', (string)$userId, $type, $payloadJson]
            );
        } catch (\Throwable $e) {
            $this->logInsertFailure($e);
            fwrite(STDERR, "[simulate] error: insert into outbox_events failed (details in logs, id: "
                . substr(md5((string)$e->getMessage()), 0, 12) . ").\n");
            return 1;
        }

        $id = $this->getDb()->lastInsertId();
        if ($id <= 0) {
            fwrite(STDERR, "[simulate] error: insert reported success but no valid row id was returned.\n");
            return 1;
        }
        echo "✓ Event inserted into outbox_events (id=$id)\n";
        echo "Now run: php cli.php outbox:publish   (or queue:work if using real queue)\n";
        echo "Then check: php cli.php distributed:health\n";
        return 0; // FIX-C61: قرارداد کد خروج اینترفیس
    }

    /**
     * FIX-P3-CMD-125: لاگ ساختاریافتهٔ شکست insert با جزئیات ماسک‌شده
     * (کلاس/فایل/خط) — پیام خام استثنا به خروجی نمی‌رود.
     */
    private function logInsertFailure(\Throwable $e): void
    {
        @error_log('[SimulateTraceableEventCommand] outbox insert failed: '
            . get_class($e) . ' at ' . $e->getFile() . ':' . $e->getLine()
            . ' — ' . $e->getMessage());
    }
}
