<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\CommandInterface;
use Core\Container;
use Core\Database;

/**
 * Simulate a traceable distributed event (for testing tracing + outbox flow).
 * Usage: php cli.php simulate:traceable-event --type=wallet.transfer --user=5 [--confirm]
 *
 * قرارداد پین‌شده (بستهٔ P3):
 *  - FIX-CMD121: حالت پیش‌فرض DRY-RUN است — بدون --confirm هیچ ردیفی نوشته نمی‌شود.
 *  - FIX-CMD123: aggregate یتیم ممنوع — کاربر باید واقعاً موجود باشد.
 *  - FIX-CMD124: idempotent — ردیف pending شبیه‌سازی‌شدهٔ قبلی دوباره درج نمی‌شود.
 *  - FIX-CMD125: شکست INSERT با پیام عمومی + exit 1 (متن خام استثنا فقط در لاگ
 *    ساختاریافته، نه خروجی CLI).
 */
class SimulateTraceableEventCommand implements CommandInterface
{
    private const SIMULATED_BY = 'simulate:traceable-event';

    private ?Database $db = null;

    public function __construct(private Container $container)
    {
    }

    private function getDb(): Database
    {
        if ($this->db === null) {
            $resolved = $this->container->make(Database::class);
            if (!$resolved instanceof Database) {
                throw new \RuntimeException('Failed to resolve Database from container');
            }
            $this->db = $resolved;
        }
        return $this->db;
    }

    /**
     * لاگ ساختاریافتهٔ best-effort — کامند diagnostic است؛ شکستِ لاگ هرگز
     * جریان اصلی را نمی‌شکند.
     *
     * @param array<string, mixed> $context
     */
    private function log(string $level, string $event, array $context): void
    {
        try {
            if (function_exists('logger') && function_exists('app')) {
                app()->logger->{$level}($event, $context);
            }
        } catch (\Throwable) {
            // لاگ در دسترس نیست (CLI بدون bootstrap کامل) — نادیده
        }
    }

    /** @param array<string|int, mixed> $args */
    public function run(array $args = []): int
    {
        // FIX-M-03: dispatcher آرگومان‌ها را به‌صورت لیست عددی از رشته‌های خام
        // '--type=...' پاس می‌دهد (CliDispatcher پارس فلگ ندارد) در حالی که
        // associative keys هرگز موجود نبودند و فلگ‌ها بی‌صدا نادیده گرفته
        // می‌شدند. اکنون فلگ‌ها از هر دو شکل استخراج می‌شوند.
        $flags = [];
        foreach ($args as $argKey => $argValue) {
            if (is_int($argKey) && is_string($argValue) && str_starts_with($argValue, '--')) {
                $body = substr($argValue, 2);
                $eq = strpos($body, '=');
                if ($eq !== false) {
                    $flags[substr($body, 0, $eq)] = substr($body, $eq + 1);
                } else {
                    $flags[$body] = true;
                }
            } elseif (is_string($argKey)) {
                $flags[$argKey] = $argValue;
            }
        }

        $typeValue = $flags['type'] ?? 'test.event';
        $type = (is_string($typeValue) && $typeValue !== '') ? $typeValue : 'test.event';
        $userValue = $flags['user'] ?? 5;
        $userId = is_numeric($userValue) ? (int)$userValue : 5;
        $confirm = (bool)($flags['confirm'] ?? false);

        $correlationId = 'sim-' . bin2hex(random_bytes(8));

        echo "Simulating traceable event...\n";
        echo "correlation_id: $correlationId\n";
        echo "event_type: $type\n";
        echo "user_id: $userId\n\n";

        // FIX-CMD123: aggregate یتیم ممنوع — کاربر باید موجود باشد
        try {
            $user = $this->getDb()->fetch('SELECT id FROM users WHERE id = ? LIMIT 1', [$userId]);
        } catch (\Throwable $e) {
            echo "✗ Failed to verify user — generic failure (see logs)\n";
            $this->log('error', 'simulate.traceable_event.failed', [
                'stage' => 'user_lookup',
                'exception_class' => $e::class,
                'user_id' => $userId,
            ]);
            return 1;
        }
        if (!$user) {
            echo "✗ User #{$userId} not found — refusing to create orphan aggregate\n";
            $this->log('warning', 'simulate.traceable_event.user_missing', ['user_id' => $userId]);
            return 1;
        }

        // FIX-CMD121: حالت پیش‌فرض DRY-RUN — بدون --confirm فقط گزارش طرح
        if (!$confirm) {
            echo "DRY-RUN (no --confirm): would insert one outbox_events row\n";
            echo "  aggregate_type=user, aggregate_id={$userId}, event_type={$type}, payload.simulated_by=" . self::SIMULATED_BY . "\n";
            echo "Re-run with --confirm to insert.\n";
            $this->log('info', 'simulate.traceable_event.dry_run', [
                'user_id' => $userId,
                'event_type' => $type,
            ]);
            return 0;
        }

        // FIX-CMD124: ردیف pending شبیه‌سازی‌شدهٔ قبلی را دوباره استفاده کن —
        // درج تکراری، خروجیِ تستِ توزیع‌شده را آلوده می‌کند و consumerهای
        // واقعی را با رویداد تکراری مواجه می‌سازد.
        try {
            $existing = $this->getDb()->fetch(
                "SELECT id, payload FROM outbox_events
                 WHERE aggregate_type = 'user' AND aggregate_id = ? AND event_type = ?
                   AND status = 'pending'
                   AND payload LIKE ?
                 ORDER BY id DESC
                 LIMIT 1",
                [(string)$userId, $type, '%' . self::SIMULATED_BY . '%']
            );
        } catch (\Throwable $e) {
            echo "✗ Failed to check existing simulated event — generic failure (see logs)\n";
            $this->log('error', 'simulate.traceable_event.failed', [
                'stage' => 'dedup_lookup',
                'exception_class' => $e::class,
                'user_id' => $userId,
            ]);
            return 1;
        }
        if ($existing) {
            $existingId = is_array($existing) ? (int)($existing['id'] ?? 0) : (int)($existing->id ?? 0);
            echo "✓ Reusing existing pending simulated event (id={$existingId}) — no duplicate inserted\n";
            echo "Now run: php cli.php outbox:publish   (or queue:work if using real queue)\n";
            echo "Then check: php cli.php distributed:health\n";
            $this->log('info', 'simulate.traceable_event.reused', [
                'outbox_event_id' => $existingId,
                'user_id' => $userId,
                'event_type' => $type,
            ]);
            return 0;
        }

        // Insert into outbox (this is what real code does)
        try {
            $this->getDb()->query(
                "INSERT INTO outbox_events (aggregate_type, aggregate_id, event_type, payload, status, attempts, available_at, created_at, updated_at)
                 VALUES (?, ?, ?, ?, 'pending', 0, NOW(), NOW(), NOW())",
                ['user', (string)$userId, $type, json_encode([
                    'user_id' => $userId,
                    'correlation_id' => $correlationId,
                    'simulated_by' => self::SIMULATED_BY,
                    'simulated_at' => date('c'),
                ])]
            );
        } catch (\Throwable $e) {
            // FIX-CMD125: شکست INSERT = exit 1 با پیام عمومی؛ متن خام استثنا
            // فقط در لاگ ساختاریافته می‌نشیند (نه خروجی CLI).
            echo "✗ Failed to insert simulated event — generic failure (see logs)\n";
            $this->log('error', 'simulate.traceable_event.insert_failed', [
                'exception_class' => $e::class,
                'error' => $e->getMessage(),
                'user_id' => $userId,
                'event_type' => $type,
            ]);
            return 1;
        }

        $id = $this->getDb()->lastInsertId();
        echo "✓ Event inserted into outbox_events (id=$id)\n";
        echo "Now run: php cli.php outbox:publish   (or queue:work if using real queue)\n";
        echo "Then check: php cli.php distributed:health\n";
        $this->log('info', 'simulate.traceable_event.inserted', [
            'outbox_event_id' => $id,
            'user_id' => $userId,
            'event_type' => $type,
            'correlation_id' => $correlationId,
        ]);
        return 0; // FIX-C61: قرارداد کد خروج اینترفیس
    }
}
