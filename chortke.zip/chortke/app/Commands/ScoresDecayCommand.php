<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Cache;
use Core\Database;
use App\Contracts\LoggerInterface;
use App\Services\Score\ScoreCommandService;

/**
 * Command: ScoresDecayCommand — hourly decay of stale fraud scores + purge of old score events.
 *
 * Usage: php cli.php scores:decay [--force] [--keep-days=30] [--idle-minutes=30] [--factor=0.9]
 *
 * FIX-X17-deep (رانده ۱۵): سقف ۱۰۰ (FIX-X17) از انباشت بی‌رویه جلوگیری می‌کند ولی
 * کاربری که یک بار امتیاز تقلب گرفته و سپس رفتار سالم دارد، برای همیشه با همان
 * امتیاز بالای آستانه (fraud_block_threshold) می‌ماند. قرارداد دامنهٔ fraud یک
 * امتیاز زندهٔ 0..100 است که باید با گذر زمان بدون ریسک تازه به سمت صفر برگردد.
 *
 * سیاست واپاشی (deterministic و idempotent):
 *  1) فقط امتیازهای fraud «بی‌کار» (بدون هیچ ایونت تازه در --idle-minutes دقیقهٔ
 *     گذشته؛ ملاک updated_at پروجکشن است) ضرب در --factor می‌شوند.
 *  2) بقایای کمتر از 0.5 صفر می‌شوند (رفع سرگردانی مقادیر جزئی).
 *  3) score_events قدیمی‌تر از --keep-days روز پاک می‌شوند (کنترل رشد جدول).
 *  4) کش امتیاز (score:user:{id}) برای کاربران واپاشیده باطل می‌شود.
 *  5) گارد اجرای ساعتی با کلید redis (chortke::scores:decay:last_run) — بدون آن،
 *     هر فراخوانی پشت‌سرهم واپاشی مضاعف می‌داد. --force گارد را دور می‌زند (QA).
 *
 * در سندباکس از outbox-worker.sh (هر loop) فراخوانی می‌شود؛ گارد ساعتی هزینه را
 * به یک UPDATE سبک در ساعت محدود می‌کند. در پروداکشن همان cron اپ قابل استفاده است.
 */
class ScoresDecayCommand
{
    private Database $db;
    private Cache $cache;
    private LoggerInterface $logger;
    private ScoreCommandService $scoreCommandService;

    public function __construct(
        Database $db,
        Cache $cache,
        LoggerInterface $logger,
        ScoreCommandService $scoreCommandService
    ) {
        $this->db = $db;
        $this->cache = $cache;
        $this->logger = $logger;
        $this->scoreCommandService = $scoreCommandService;
    }

    /** @param array<int, string> $argv */
    public function run(array $argv = []): int
    {
        $force = in_array('--force', $argv, true);
        $keepDays = 30;
        $idleMinutes = 30;
        $factor = 0.9;

        foreach ($argv as $arg) {
            if (is_string($arg) && str_starts_with($arg, '--keep-days=')) {
                $keepDays = max(1, (int)substr($arg, 12));
            } elseif (is_string($arg) && str_starts_with($arg, '--idle-minutes=')) {
                $idleMinutes = max(5, (int)substr($arg, 15));
            } elseif (is_string($arg) && str_starts_with($arg, '--factor=')) {
                $candidate = (float)substr($arg, 9);
                if ($candidate > 0.0 && $candidate < 1.0) {
                    $factor = $candidate;
                }
            }
        }

        // گارد ساعتی: اجرای مضاعف در بازهٔ کوتاه واپاشی مضاعف می‌دهد.
        if (!$force) {
            try {
                $redis = $this->cache->redis();
                if ($redis) {
                    // FIX-X17-deep: کلید با redisKey() تا پیشوند chortke: رعایت شود؛
                    // PhpRedis set با ['nx','ex'] تنها بار اول TRUE برمی‌گرداند.
                    $guardKey = $this->cache->redisKey('scores:decay:last_run');
                    if (!$redis->set($guardKey, (string)time(), ['nx', 'ex' => 3600])) {
                        $this->logger->debug('scores.decay.skipped_throttled', []);
                        return 0;
                    }
                }
            } catch (\Throwable $e) {
                // fail-open: اگر گارد در دسترس نبود، واپاشی انجام می‌شود (idempotent بودن
                // ضرب در فاکتور برای دیتای ثابت تکرار یک‌ساعته را قابل تحمل می‌کند).
                $this->logger->debug('scores.decay.guard_unavailable', ['error' => $e->getMessage()]);
            }
        }

        try {
            // ۱) واپاشی امتیازهای fraud بی‌کار (بدون به‌روزرسانی updated_at — ایونت تازه
            //    خودش updated_at را نوسازی می‌کند و کاربر فعال را از واپاشی معاف نگه می‌دارد).
            $decayed = $this->db->execute(
                "UPDATE user_scores
                 SET score = ROUND(score * ?, 4)
                 WHERE domain = 'fraud'
                   AND score >= 0.5
                   AND updated_at < (NOW() - INTERVAL " . (int)$idleMinutes . " MINUTE)",
                [$factor]
            );
            $decayedCount = is_numeric($decayed) ? (int)$decayed : 0;

            // ۲) صفر کردن بقایای جزئی
            $floored = $this->db->execute(
                "UPDATE user_scores
                 SET score = 0
                 WHERE domain = 'fraud'
                   AND score > 0
                   AND score < 0.5
                   AND updated_at < (NOW() - INTERVAL " . (int)$idleMinutes . " MINUTE)"
            );
            $flooredCount = is_numeric($floored) ? (int)$floored : 0;

            // ۳) پاک‌سازی ایونت‌های قدیمی (کنترل رشد جدول رویدادها)
            $purged = $this->db->execute(
                "DELETE FROM score_events WHERE created_at < (NOW() - INTERVAL " . (int)$keepDays . " DAY)"
            );
            $purgedCount = is_numeric($purged) ? (int)$purged : 0;

            // ۴) باطل‌سازی کش امتیاز کاربرانی که امتیازشان تغییر کرد
            $staleUsers = [];
            try {
                $rows = $this->db->select(
                    "SELECT user_id FROM user_scores
                     WHERE domain = 'fraud' AND updated_at < (NOW() - INTERVAL " . (int)$idleMinutes . " MINUTE)"
                );
                foreach ((array)$rows as $row) {
                    $uid = (int)($row->user_id ?? 0);
                    if ($uid > 0) {
                        $staleUsers[] = $uid;
                        $this->scoreCommandService->clearScoresCache('user', $uid);
                    }
                }
            } catch (\Throwable $e) {
                $this->logger->debug('scores.decay.cache_invalidate_failed', ['error' => $e->getMessage()]);
            }

            $summary = [
                'decayed_rows' => $decayedCount,
                'floored_rows' => $flooredCount,
                'purged_events' => $purgedCount,
                'cache_invalidated_users' => count($staleUsers),
                'factor' => $factor,
                'keep_days' => $keepDays,
                'idle_minutes' => $idleMinutes,
            ];
            $this->logger->info('scores.decay.completed', $summary);

            if (PHP_SAPI === 'cli') {
                echo json_encode(['success' => true] + $summary, JSON_UNESCAPED_UNICODE) . PHP_EOL;
            }

            return 0;
        } catch (\Throwable $e) {
            $this->logger->error('scores.decay.failed', ['error' => $e->getMessage()]);
            if (PHP_SAPI === 'cli') {
                echo json_encode(['success' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE) . PHP_EOL;
            }
            return 1;
        }
    }
}
