<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Cache;
use Core\Database;
use App\Contracts\LoggerInterface;
use App\Services\Score\ScoreCommandService;

/**
 * Command: ScoresDecayCommand — hourly decay of stale fraud scores (ledger-based).
 *
 * Usage: php cli.php scores:decay [--force] [--idle-minutes=30] [--factor=0.9] [--keep-days=…]
 *
 * FIX-X17-deep (رانده ۱۵): سقف ۱۰۰ (FIX-X17) از انباشت بی‌رویه جلوگیری می‌کند ولی
 * کاربری که یک بار امتیاز تقلب گرفته و سپس رفتار سالم دارد، برای همیشه با همان
 * امتیاز بالای آستانه (fraud_block_threshold) می‌ماند. قرارداد دامنهٔ fraud یک
 * امتیاز زندهٔ 0..100 است که باید با گذر زمان بدون ریسک تازه به سمت صفر برگردد.
 *
 * سیاست واپاشی (deterministic و idempotent):
 *  1) فقط امتیازهای fraud «بی‌کار» (بدون هیچ ایونت تازه در --idle-minutes دقیقهٔ
 *     گذشته؛ ملاک updated_at پروجکشن است) ضرب در --factor می‌شوند.
 *  2) بقایای کمتر از 0.5 صفر می‌شوند (رفع سرگردانی مقادیر جزئی).
 *  3) کش امتیاز (score:user:{id}) برای کاربران واپاشیده باطل می‌شود.
 *  4) گارد اجرای ساعتی با کلید redis (chortke::scores:decay:last_run) — بدون آن،
 *     هر فراخوانی پشت‌سرهم واپاشی مضاعف می‌داد. --force گارد را دور می‌زند (QA).
 *
 * 🛡️ FIX-X359 (راند ۹۱): واپاشی و صفرکردنِ بقایا دیگر مستقیم روی پروجکشن
 * (UPDATE user_scores) نوشته نمی‌شوند — ریشهٔ همیشگیِ drift همین دورزدنِ لجر
 * بود و پروجکشنِ مستقیم، بازسازیِ دامنهٔ fraud از لجر را هم ناممکن می‌کرد.
 * جانشین: هر دو مسیر از مسیر دلتای سیستمیِ ScoreCommandService::applySystemDelta
 * عبور می‌کنند (INSERT score_events با reason «fraud_decay» /
 * «fraud_decay_floor» + رویداد ScoreDeltaAppendedEvent در outbox) تا پروجکشن
 * از مسیر عادی outbox→ScoreProjectionListener به‌روز شود. به‌روزرسانی پروجکشن
 * async است (worker loop) — الگوی خانه همین است. ایدمپوتنسی هر ایونت با کلید
 * ساعتی (fraud_decay:{uid}:{Y-m-d-H}) است تا اجرای دوبارهٔ --force در همان
 * ساعت واپاشی مضاعف نزند.
 *
 * 🛡️ FIX-X358 (راند ۹۱): پاکسازی score_events قدیمی‌تر از --keep-days روز
 * کامل حذف شد. لجر (score_events) لجرِ append-only است و ستون فقرات
 * scores:rebuild؛ لجری که خودش را پاک کند نمی‌تواند بازسازی را پشتیبانی کند
 * (شواهد: AUTO_INCREMENT=426 با فقط 63 ردیف = پاکسازی تاریخیِ انبوه).
 * حجم این جدول ناچیز است؛ اگر روزی آرشیو لازم شد تصمیم محصولی است، نه کرون
 * خاموشِ تخریب. فلگ --keep-days برای سازگاری CLI پذیرفته می‌شود ولی no-op است.
 *
 * در سندباکس از outbox-worker.sh (هر loop) فراخوانی می‌شود؛ گارد ساعتی هزینه را
 * به یک UPDATE سبک در ساعت محدود می‌کند. در پروداکشن همان cron اپ قابل استفاده است.
 */
class ScoresDecayCommand
{
    private Database $db;
    private Cache $cache;
    private LoggerInterface $logger;
    private ScoreCommandService $scoreCommandService;

    public function __construct(
        Database $db,
        Cache $cache,
        LoggerInterface $logger,
        ScoreCommandService $scoreCommandService
    ) {
        $this->db = $db;
        $this->cache = $cache;
        $this->logger = $logger;
        $this->scoreCommandService = $scoreCommandService;
    }

    /** @param array<int, string> $argv */
    public function run(array $argv = []): int
    {
        $force = in_array('--force', $argv, true);
        $idleMinutes = 30;
        $factor = 0.9;

        foreach ($argv as $arg) {
            if (is_string($arg) && str_starts_with($arg, '--idle-minutes=')) {
                // FIX-C121 (یافتهٔ ۱۲۱): سقف بالایی — قبلاً فقط کف ۵ اعمال می‌شد و
                // --idle-minutes=99999999 به INTERVAL ... MINUTE هر دو کوئری و
                // کلیدهای ایدمپوتنسی تزریق می‌شد. هم‌سو با ReconciliationService: ۵ تا ۷ روز.
                $idleMinutes = max(5, min(10080, (int)substr($arg, 15)));
            } elseif (is_string($arg) && str_starts_with($arg, '--factor=')) {
                $candidate = (float)substr($arg, 9);
                if ($candidate > 0.0 && $candidate < 1.0) {
                    $factor = $candidate;
                }
            }
            // FIX-X358: --keep-days دیگر مصرف‌کننده ندارد (پاکسازی لجر حذف شد)؛
            // فلگ فقط برای سازگاری فراخوان‌های قدیمی پذیرفته و نادیده گرفته می‌شود.
        }

        // گارد ساعتی: اجرای مضاعف در بازهٔ کوتاه، ایدمپوتنسی ساعتیِ هر ایونت را
        // هم دارد ولی گارد از ساخت ردیف‌های outbox بی‌دلیل هم جلوگیری می‌کند.
        // FIX-CMD100 (یافتهٔ ۱۰۰): کلید گارد دیگر «قبل از کار» مصرف‌شده رها نمی‌ماند؛
        // اگر اجرای واپاشی با exception بشکند، کلید در مسیر خطا آزاد می‌شود تا
        // تیک بعدی cron همان ساعت از دست نرود (قبلاً یک ساعت کامل واپاشی گم می‌شد).
        $guardKey = null;
        if (!$force) {
            try {
                $redis = $this->cache->redis();
                if ($redis) {
                    // FIX-X17-deep: کلید با redisKey() تا پیشوند chortke: رعایت شود؛
                    // PhpRedis set با ['nx','ex'] تنها بار اول TRUE برمی‌گرداند.
                    $guardKey = $this->cache->redisKey('scores:decay:last_run');
                    if (!$redis->set($guardKey, (string)time(), ['nx', 'ex' => 3600])) {
                        $this->logger->debug('scores.decay.skipped_throttled', []);
                        return 0;
                    }
                }
            } catch (\Throwable $e) {
                // fail-open: اگر گارد در دسترس نبود، واپاشی انجام می‌شود (idempotent بودن
                // ضرب در فاکتور برای دیتای ثابت تکرار یک‌ساعته را قابل تحمل می‌کند).
                $this->logger->debug('scores.decay.guard_unavailable', ['error' => $e->getMessage()]);
            }
        }

        try {
            $decayedCount = 0;
            $flooredCount = 0;
            $touchedUsers = [];

            // ۱) واپاشی امتیازهای fraud بی‌کار (بدون به‌روزرسانی updated_at — ایونت تازه
            //    خودش updated_at را نوسازی می‌کند و کاربر فعال را از واپاشی معاف نگه می‌دارد).
            //    FIX-X359: خوانشِ نامزدها از پروجکشن، نوشتنِ اثر از لجر.
            //    🛡️ X368 (راند ۹۲): گارد «کاربر موجود» — جفت‌های یتیمِ پروجکشن
            //    (entity_idهای کاربران حذف‌شدهٔ qa) نباید هر ساعت رویداد لجرِ
            //    fraud_decay برای کاربرِ ناموجود بنویسند (نویز +۷۶ ردیف/چند روز).
            //    FIX-CMD101 (یافتهٔ ۱۰۱): خوانش دسته‌ای با keyset pagination
            //    (بچ ۵۰۰ روی user_id) — قبلاً کل جدول نامزدها یک‌جا به حافظه
            //    کشیده می‌شد و با رشد کاربران peak حافظه و طول کوئری بی‌سقف بود.
            //    FIX-CMD099 (یافتهٔ ۰۹۹): سیاست مستند «ضرب در factor» یعنی بقای
            //    امتیاز = score×factor؛ پس دلتای حذفی = score×(1−factor). کد قبلی
            //    score×factor را «کم» می‌کرد و عملاً امتیاز را score×(1−factor)
            //    می‌گذاشت — با فاکتور پیش‌فرض 0.9 یعنی ~۱۰ برابر واپاشیِ بیش از
            //    سیاست (باقی‌ماندهٔ آینهٔ مسیر legacy که در FIX-X359 عمداً حفظ شده
            //    بود). اکنون با docblock سیاست هم‌سو شده؛ تغییر عددی عمدی است.
            //    CMD-102 (بقای پذیرفته‌شده): بین خوانش اسنپ‌شات و ثبت دلتا پنجرهٔ
            //    رقابت هست؛ با ایدمپوتنسی ساعتی و floor صفرِ پروجکشن، خطای آن
            //    محدود و در حد سهم یک‌ساعته است — بجای قفل سنگین، همین کفایت
            //    آماری پذیرفته شد (شرح در گزارش راستی‌آزمایی).
            $decayBatch = 500;
            $lastUserId = 0;
            while (true) {
            $rows = $this->db->select(
                "SELECT user_id, score FROM user_scores
                 WHERE domain = 'fraud' AND score >= 0.5
                   AND user_id > ?
                   AND updated_at < (NOW() - INTERVAL " . (int)$idleMinutes . " MINUTE)
                   AND EXISTS (SELECT 1 FROM users u WHERE u.id = user_scores.user_id)
                 ORDER BY user_id ASC LIMIT ?",
                [$lastUserId, $decayBatch]
            );
            $rowList = array_values((array)$rows);
            if ($rowList === []) {
                break;
            }
            foreach ($rowList as $row) {
                $userId = (int)($row->user_id ?? 0);
                $score  = (float)($row->score ?? 0);
                if ($userId <= 0 || $score <= 0.0) {
                    continue;
                }
                // FIX-CMD099: دلتا = سهمِ حذفی (score − score×factor) نه خودِ score×factor
                $amount = round($score - round($score * $factor, 4), 4);
                if ($amount <= 0.0) {
                    continue;
                }
                $ok = $this->scoreCommandService->applySystemDelta(
                    'user',
                    $userId,
                    'fraud',
                    -$amount,
                    'fraud_decay',
                    ['factor' => $factor, 'pre_score' => $score],
                    'fraud_decay:' . $userId . ':' . date('Y-m-d-H')
                );
                if ($ok) {
                    $decayedCount++;
                    $touchedUsers[$userId] = true;
                }
            }
            $lastUserId = (int)($rowList[count($rowList) - 1]->user_id ?? 0);
            if (count($rowList) < $decayBatch) {
                break;
            }
            }

            // ۲) صفر کردن بقایای جزئی (FIX-X359: از مسیر لجر با reason «fraud_decay_floor»)
            //    FIX-CMD101: هم‌سو با واپاشی اصلی — keyset pagination
            $floorBatch = 500;
            $lastFloorUserId = 0;
            while (true) {
            $tinyRows = $this->db->select(
                "SELECT user_id, score FROM user_scores
                 WHERE domain = 'fraud' AND score > 0 AND score < 0.5
                   AND user_id > ?
                   AND updated_at < (NOW() - INTERVAL " . (int)$idleMinutes . " MINUTE)
                   AND EXISTS (SELECT 1 FROM users u WHERE u.id = user_scores.user_id)
                 ORDER BY user_id ASC LIMIT ?",
                [$lastFloorUserId, $floorBatch]
            );
            $tinyList = array_values((array)$tinyRows);
            if ($tinyList === []) {
                break;
            }
            foreach ($tinyList as $row) {
                $userId = (int)($row->user_id ?? 0);
                $score  = (float)($row->score ?? 0);
                if ($userId <= 0 || $score <= 0.0) {
                    continue;
                }
                $ok = $this->scoreCommandService->applySystemDelta(
                    'user',
                    $userId,
                    'fraud',
                    -$score,
                    'fraud_decay_floor',
                    ['pre_score' => $score],
                    'fraud_floor:' . $userId . ':' . date('Y-m-d-H')
                );
                if ($ok) {
                    $flooredCount++;
                    $touchedUsers[$userId] = true;
                }
            }
            $lastFloorUserId = (int)($tinyList[count($tinyList) - 1]->user_id ?? 0);
            if (count($tinyList) < $floorBatch) {
                break;
            }
            }

            // ۳) FIX-X358: پاکسازی ایونت‌های قدیمی حذف شد — لجر append-only است؛
            //    بازنگری به کامنت کلاس.

            // ۴) باطل‌سازی کش امتیاز کاربرانی که واپاشی‌شان به لجر ثبت شد
            //    (پروجکشن خودش async از outbox می‌آید؛ این hDel فقط خوانشِ بین‌راهی
            //    را زودتر از کشِ کهنه آزاد می‌کند — هم‌سلوک مسیر قبلی)
            //    FIX-P3-CMD-105 (یافتهٔ ۱۰۵): شکست ابطال کش دیگر debug (نامرئی) نیست —
            //    warning + شمارندهٔ fail در خلاصهٔ run (غیرمسدودکننده، طبق یافته).
            $cacheInvalidationFailures = 0;
            foreach (array_keys($touchedUsers) as $userId) {
                try {
                    $this->scoreCommandService->clearScoresCache('user', (int)$userId);
                } catch (\Throwable $e) {
                    $cacheInvalidationFailures++;
                    $this->logger->warning('scores.decay.cache_invalidate_failed', ['error' => $e->getMessage()]);
                }
            }

            $summary = [
                'decayed_rows' => $decayedCount,
                'floored_rows' => $flooredCount,
                'cache_invalidated_users' => count($touchedUsers),
                // FIX-P3-CMD-105: شمارش شکست‌های ابطال کش در خلاصهٔ run — قابل‌مشاهده
                'cache_invalidate_failures' => $cacheInvalidationFailures,
                'factor' => $factor,
                'idle_minutes' => $idleMinutes,
            ];
            $this->logger->info('scores.decay.completed', $summary);

            if (PHP_SAPI === 'cli') {
                echo json_encode(['success' => true] + $summary, JSON_UNESCAPED_UNICODE) . PHP_EOL;
            }

            return 0;
        } catch (\Throwable $e) {
            // FIX-CMD100: آزادسازی best-effort کلید گارد ساعتی — شکستِ این اجرا
            // نباید تیک بعدی cron را هم قربانی کند (کلید تا ۳۶۰۰ ثانیه می‌ماند).
            if ($guardKey !== null) {
                try {
                    $redis = $this->cache->redis();
                    if ($redis) {
                        $redis->del($guardKey);
                    }
                } catch (\Throwable $e2) {
                    $this->logger->debug('scores.decay.guard_release_failed', ['error' => $e2->getMessage()]);
                }
            }
            $this->logger->error('scores.decay.failed', ['error' => $e->getMessage()]);
            if (PHP_SAPI === 'cli') {
                echo json_encode(['success' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE) . PHP_EOL;
            }
            return 1;
        }
    }
}
