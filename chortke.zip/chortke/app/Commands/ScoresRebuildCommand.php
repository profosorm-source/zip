<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Cache;
use Core\Database;
use App\Contracts\LoggerInterface;
use App\Services\Score\ScoreDomainPolicy;

/**
 * Command: ScoresRebuildCommand — بازسازی پروجکشن user_scores از لجر score_events.
 *
 * Usage: php cli.php scores:rebuild [--domain=fraud] [--user=42] [--dry-run] [--force]
 *
 * 🛡️ FIX-X358/X359 (راند ۹۱): تا دیروز هیچ مسیر بازسازی وجود نداشت — لجر خودش
 * با کرون decay پاک می‌شد (X358) و واپاشی هم مستقیم پروجکشن را می‌نوشت (X359)
 * یعنی پروجکشن هیچ‌وقت از لجر مشتق‌پذیر نبود. با append-only شدن لجر و
 * لجر-محور شدن واپاشی، این دستور مرجعِ reset پروجکشن است.
 *
 * معناشناسی:
 *  1) مجموعهٔ جفت‌های (entity_id, domain) از اجتماعِ user_scores و score_events
 *     (فقط entity_type='user') ساخته می‌شود — هم drift مثبت (پروجکشنِ جلوتر از
 *     لجر) و هم ردیف گم‌شده پوشش داده می‌شود.
 *  2) دلتاهای لجر به‌ترتیب id برای هر جفت replay می‌شوند و در هر گام با
 *     ScoreDomainPolicy::clamp (تک‌منبعِ مشترک با listener) مهار می‌شوند تا
 *     بازسازی «وفادار به معناشناسی زندهٔ» GREATEST/LEASTِ listener باشد:
 *       - fraud/task و دامنه‌های ناشناخته: clamp [0, 100]
 *       - xp_*: کف ۰ بدون سقف
 *       - social_trust / trust_*: clamp ‎[-100, 100]‎
 *  3) مقدار هدف با UPSERT داخل user_scores نوشته می‌شود؛ سپس فیلد همان دامنه
 *     از هش ردیس score:user:{id} باطل می‌شود تا کش از پروجکشنِ اصلاح‌شده
 *     rehydrate شود.
 *  4) بهداشت outbox: این دستور عمداً هیچ ScoreDeltaAppendedEvent ای ثبت
 *     نمی‌کند. بازسازی یعنی «خودِ پروجکشن، مرجعِ reset است»؛ اگر رویداد ثبت
 *     می‌شد، listener همان اختلاف را دوباره روی پروجکشن اعمال می‌کرد
 *     (double-apply) و چرخهٔ واگرایی از نو باز می‌شد.
 *  5) گارد اجرای ساعتی با کلید redis (chortke::scores:rebuild:last_run) —
 *     --force آن را دور می‌زند (QA). --dry-run فقط-خواندنی است و گارد را هم
 *     مصرف نمی‌کند.
 *
 * کروندار: در سندباکس از outbox-worker.sh فراخوانی می‌شود؛ در پروداکشن cron اپ.
 */
class ScoresRebuildCommand
{
    private const USER_BATCH_SIZE = 500;

    private Database $db;
    private Cache $cache;
    private LoggerInterface $logger;
    private ?\Core\TransactionWrapper $transactionWrapper;

    public function __construct(
        Database $db,
        Cache $cache,
        LoggerInterface $logger,
        ?\Core\TransactionWrapper $transactionWrapper = null
    ) {
        $this->db = $db;
        $this->cache = $cache;
        $this->logger = $logger;
        $this->transactionWrapper = $transactionWrapper;
    }

    /** @param array<int, string> $argv */
    public function run(array $argv = []): int
    {
        $force   = in_array('--force', $argv, true);
        $dryRun  = in_array('--dry-run', $argv, true);
        $domain  = null;
        $userId  = null;

        foreach ($argv as $arg) {
            if (is_string($arg) && str_starts_with($arg, '--domain=')) {
                $domain = trim(substr($arg, 9));
            } elseif (is_string($arg) && str_starts_with($arg, '--user=')) {
                // FIX-P3-CMD-112 (یافتهٔ ۱۱۲): قبلاً max(1, (int)...) بود و ‎--user=abc
                // بی‌صدا به کاربر ۱ نگاشت می‌شد (بازسازی هدف اشتباه). اکنون فقط
                // ارقامِ مثبت پذیرفته می‌شود؛ ورودی نامعتبر = خطای usage با خروج ۱.
                $userRaw = substr($arg, 7);
                if (!ctype_digit($userRaw) || (int)$userRaw <= 0) {
                    if (PHP_SAPI === 'cli') {
                        fwrite(STDERR, "Usage error: --user expects a positive integer id (got '{$userRaw}')." . PHP_EOL);
                    }
                    return 1;
                }
                $userId = (int)$userRaw;
            }
        }

        // FIX-C122 (یافتهٔ ۱۲۲): اعتبارسنجی دامنه — قبلاً --domain دلخواه بود و
        // دامنهٔ غلط (مثلاً --domain=farud) به‌جای خطای استفاده، «بازسازی موفقِ
        // ۰ رکورد» گزارش می‌کرد. اکنون دامنه باید عضو App\Enums\ScoreDomain یا
        // یکی از پیشوندهای مجاز سیاست (xp_* / trust_*) باشد؛ در غیر این صورت
        // خطای usage با کد خروج ۱.
        if (is_string($domain) && $domain !== '') {
            $validEnum = in_array($domain, array_map(
                static fn (\App\Enums\ScoreDomain $d): string => $d->value,
                \App\Enums\ScoreDomain::cases()
            ), true);
            $validPrefix = $domain === 'xp' || $domain === 'trust' || str_starts_with($domain, 'xp_') || str_starts_with($domain, 'trust_');
            if (!$validEnum && !$validPrefix) {
                if (PHP_SAPI === 'cli') {
                    fwrite(STDERR, "Usage error: unknown --domain '{$domain}'. Valid values: "
                        . implode('|', array_map(static fn (\App\Enums\ScoreDomain $d): string => $d->value, \App\Enums\ScoreDomain::cases()))
                        . ' or xp*|trust* prefixes' . PHP_EOL);
                }
                return 1;
            }
        }

        // گارد ساعتی (آینهٔ scores:decay) — dry-run فقط-خواندنی است و نباید
        // اجرای واقعی بعدی را قفل کند.
        if (!$force && !$dryRun) {
            try {
                $redis = $this->cache->redis();
                if ($redis) {
                    $guardKey = $this->cache->redisKey('scores:rebuild:last_run');
                    if (!$redis->set($guardKey, (string)time(), ['nx', 'ex' => 3600])) {
                        $this->logger->debug('scores.rebuild.skipped_throttled', []);
                        if (PHP_SAPI === 'cli') {
                            echo json_encode(['success' => true, 'skipped' => 'throttled'], JSON_UNESCAPED_UNICODE) . PHP_EOL;
                        }
                        return 0;
                    }
                }
            } catch (\Throwable $e) {
                // fail-open: rebuild خودش idempotent است (مرجعِ reset) — اجرای مجدد بی‌ضرر
                $this->logger->debug('scores.rebuild.guard_unavailable', ['error' => $e->getMessage()]);
            }
        }

        try {
            // ۱) جفت‌های (entity_id, domain) از اجتماع پروجکشن و لجر + مقدار فعلی پروجکشن
            $pairs = $this->collectPairs($domain, $userId);

            // FIX-CMD107 (یافتهٔ ۱۰۷): جفت‌های یتیم (کاربر حذف‌شده) وارد plan نمی‌شوند —
            // قبلاً rebuild ردیف پروجکشنِ کاربران حذف‌شده را دوباره INSERT می‌کرد و
            // یتیم‌ها هر بار بازتولید می‌شدند (همان نویز X368 در مسیر rebuild).
            $pairsBefore = count($pairs);
            $pairs = $this->filterExistingUsers($pairs);
            $orphanPairsSkipped = $pairsBefore - count($pairs);

            // ۲) replay دلتاها به‌ترتیب id، گروه‌بندی‌شده بر (entity_id, domain)
            $computed = $pairs === [] ? [] : $this->replayLedger($pairs);

            // ۳) مقایسه با پروجکشن فعلی + (در غیر dry-run) upsert داخل تراکنشِ هر کاربر
            $examined = 0;
            $changed = 0;
            /** @var array<string, int> $perDomainExamined */
            $perDomainExamined = [];
            /** @var array<string, int> $perDomainChanged */
            $perDomainChanged = [];
            /** @var array<int, array<string, float>> $targetsByUser */
            $targetsByUser = [];
            /** @var list<array{user_id: int, domain: string, current: ?float, target: float, diff: float}> $plan */
            $plan = [];

            foreach ($pairs as $pairKey => $pair) {
                $uid = $pair['user_id'];
                $dom = $pair['domain'];
                $current = $pair['score'];
                $target = round($computed[$pairKey] ?? 0.0, 4);
                $examined++;
                $perDomainExamined[$dom] = ($perDomainExamined[$dom] ?? 0) + 1;

                $currentVal = $current === null ? null : round($current, 4);
                $diff = round($target - ($currentVal ?? 0.0), 4);
                if ($currentVal !== null && abs($diff) < 0.0001) {
                    continue; // هم‌ارز — هیچ نوشتنی لازم نیست
                }

                $changed++;
                $perDomainChanged[$dom] = ($perDomainChanged[$dom] ?? 0) + 1;
                $targetsByUser[$uid][$dom] = $target;
                $plan[] = ['user_id' => $uid, 'domain' => $dom, 'current' => $currentVal, 'target' => $target, 'diff' => $diff];
            }

            if (!$dryRun && $targetsByUser !== []) {
                $this->applyPlan($targetsByUser);
                foreach ($targetsByUser as $uid => $domainTargets) {
                    $this->invalidateCache((int)$uid, array_keys($domainTargets));
                }
            }

            // FIX-CMD110 (یافتهٔ ۱۱۰): همگام‌سازی پروجکشن سوم users.fraud_score برای
            // کاربرانی که هیچ جفت fraud‌ای در plan ندارند (بدون لجر و بدون پروجکشن)
            // ولی ستونشان به‌دلیل drift قدیمی nonzero مانده — فقط در rebuild کامل
            // (بدون --domain/--user) و بعد از applyPlan تا نتیجهٔ تازه ملاک باشد.
            $fraudReconciled = 0;
            if (!$dryRun && $domain === null && $userId === null) {
                $fraudReconciled = $this->reconcileUsersFraudProjection();
            }

            $summary = [
                'success'      => true,
                'dry_run'      => $dryRun,
                'rows_examined' => $examined,
                'rows_changed' => $changed,
                'orphan_pairs_skipped' => $orphanPairsSkipped,
                'fraud_projection_reconciled' => $fraudReconciled,
                'per_domain'   => $this->mergePerDomain($perDomainExamined, $perDomainChanged),
            ];
            $this->logger->info('scores.rebuild.completed', [
                'dry_run' => $dryRun,
                'rows_examined' => $examined,
                'rows_changed' => $changed,
            ]);

            if (PHP_SAPI === 'cli') {
                if ($plan !== []) {
                    $this->printPlanTable($plan, $dryRun);
                }
                echo json_encode($summary, JSON_UNESCAPED_UNICODE) . PHP_EOL;
            }

            return 0;
        } catch (\Throwable $e) {
            $this->logger->error('scores.rebuild.failed', ['error' => $e->getMessage()]);
            if (PHP_SAPI === 'cli') {
                echo json_encode(['success' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE) . PHP_EOL;
            }
            return 1;
        }
    }

    /**
     * جفت‌های (entity_id, domain) از اجتماع user_scores و score_events (entity_type='user')
     * به‌همراه مقدار فعلی پروجکشن (null = ردیف پروجکشن ندارد). شاخهٔ لجر عمداً
     * score=NULL می‌گذارد تا MAX فقط مقدار پروجکشن را انتخاب کند (جفت‌هایی که فقط
     * در لجرند → current=null یعنی INSERT تازه).
     *
     * @return array<string, array{user_id: int, domain: string, score: float|null}>
     */
    private function collectPairs(?string $domain, ?int $userId): array
    {
        $whereProjection = [];
        $whereLedger = ["entity_type = 'user'"];
        $paramsP = [];
        $paramsL = [];
        if ($domain !== null && $domain !== '') {
            $whereProjection[] = 'domain = ?';
            $paramsP[] = $domain;
            $whereLedger[] = 'domain = ?';
            $paramsL[] = $domain;
        }
        if ($userId !== null) {
            $whereProjection[] = 'user_id = ?';
            $paramsP[] = $userId;
            $whereLedger[] = 'entity_id = ?';
            $paramsL[] = $userId;
        }
        $whereP = $whereProjection === [] ? '' : 'WHERE ' . implode(' AND ', $whereProjection);
        // PS-fix: $whereLedger با «entity_type = 'user'» مقداردهی اولیه می‌شود و هرگز
        // خالی نیست؛ مقایسهٔ === [] همیشه false است (یافتهٔ PHPStan) — گارد مرده حذف و
        // شاخهٔ همیشه-اجرا مستقیم شد. رفتار runtime یکسان.
        $whereL = 'WHERE ' . implode(' AND ', $whereLedger);

        $rows = $this->db->fetchAll(
            "SELECT user_id, domain, MAX(score) AS score FROM (
                SELECT us.user_id, us.domain, us.score
                FROM user_scores us {$whereP}
                UNION ALL
                SELECT se.entity_id AS user_id, se.domain, NULL AS score
                FROM score_events se {$whereL}
            ) t
            GROUP BY user_id, domain
            ORDER BY user_id, domain",
            array_merge($paramsP, $paramsL)
        );

        /** @var array<string, array{user_id: int, domain: string, score: float|null}> $pairs */
        $pairs = [];
        foreach ((array)$rows as $row) {
            $uid = (int)($row->user_id ?? 0);
            $dom = (string)($row->domain ?? '');
            if ($uid <= 0 || $dom === '') {
                continue;
            }
            $score = isset($row->score) && $row->score !== null ? (float)$row->score : null;
            $pairs[$uid . '|' . $dom] = ['user_id' => $uid, 'domain' => $dom, 'score' => $score];
        }

        return $pairs;
    }

    /**
     * FIX-CMD107: حذف جفت‌های کاربران ناموجود (حذف‌شده) از plan.
     *
     * @param array<string, array{user_id: int, domain: string, score: float|null}> $pairs
     * @return array<string, array{user_id: int, domain: string, score: float|null}>
     */
    private function filterExistingUsers(array $pairs): array
    {
        if ($pairs === []) {
            return $pairs;
        }
        $userIds = [];
        foreach ($pairs as $p) {
            $userIds[$p['user_id']] = true;
        }

        $existing = [];
        foreach (array_chunk(array_keys($userIds), self::USER_BATCH_SIZE) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            $rows = (array)$this->db->fetchAll(
                "SELECT id FROM users WHERE id IN ({$in})",
                $chunk
            );
            foreach ($rows as $row) {
                $existing[(int)($row->id ?? 0)] = true;
            }
        }

        return array_filter($pairs, static function (array $p) use ($existing): bool {
            return isset($existing[$p['user_id']]);
        });
    }

    /**
     * FIX-CMD110: صفرکردن users.fraud_score کاربرانی که هیچ وضعیت fraud‌ای
     * (نه لجر، نه پروجکشن) ندارند ولی ستون سومشان nonzero مانده (drift قدیمی).
     * بعد از applyPlan اجرا می‌شود؛ پس «NULL بودن پروجکشن» = واقعاً بدون وضعیت.
     * دسته‌ای و محدود (پیش‌فرض حداکثر ۵۰۰۰ ردیف) تا rebuild کامل سنگین نشود.
     */
    private function reconcileUsersFraudProjection(int $maxRows = 5000): int
    {
        $fixed = 0;
        $lastId = 0;
        while ($fixed < $maxRows) {
            $rows = (array)$this->db->fetchAll(
                "SELECT u.id, u.fraud_score
                 FROM users u
                 LEFT JOIN user_scores us ON us.user_id = u.id AND us.domain = 'fraud'
                 WHERE us.user_id IS NULL AND u.fraud_score <> 0 AND u.id > ?
                 ORDER BY u.id ASC
                 LIMIT 500",
                [$lastId]
            );
            if ($rows === []) {
                break;
            }
            foreach ($rows as $row) {
                $uid = (int)($row->id ?? 0);
                if ($uid <= 0) {
                    continue;
                }
                $this->db->execute(
                    'UPDATE users SET fraud_score = 0 WHERE id = ? AND fraud_score <> 0',
                    [$uid]
                );
                $fixed++;
                $lastId = $uid;
            }
        }
        return $fixed;
    }

    /**
     * replay دلتاهای لجر برای همهٔ جفت‌ها — مهارِ هر گام با ScoreDomainPolicy
     * (وفادار به معناشناسی زندهٔ listener: clamp هر گام، نه فقط جمعِ نهایی).
     * دلتاهای لجر خودِ «دلتای اعمال‌شده»اند (کپ‌ها قبل از addEvent اتفاق می‌افتند)
     * پس replay دقیقاً همان چیزی است که listener دیده/می‌دید.
     * لجرِ هر جفت ممکن است تهی باشد (پروجکشنِ یتیم) → مقدار هدف = 0.
     *
     * 🛡️ X362 (راند ۹۲): ردیف‌های reason='admin_set' لنگرِ مطلق‌اند، نه دلتا —
     * applySystemSet مقدار metadata.target را به‌عنوان «جمع مطلق پس از این ردیف»
     * لنگر می‌زند؛ پس replay به‌جای جمع‌کردن دلتای آن ردیف، مقدار computed را
     * به clamp(target) بازمی‌گرداند. ردیف‌های admin_setِ بدون metadata.target
     * fallback به رفتار جمع معمولی می‌شوند تا replay هرگز کرش نکند.
     *
     * FIX-CMD111 (یافتهٔ ۱۱۱): خوانش لجر صفحه‌بندی‌شده شد (keyset روی id، بچ ۵۰۰۰)
     * — قبلاً کل ردیف‌های هر بچِ کاربر یک‌جا fetch می‌شد و کاربرِ با لجر عظیم
     * مصرف حافظهٔ بی‌سقف می‌ساخت. state هر (user|domain) بین صفحات ادامه می‌یابد.
     *
     * @param array<string, array{user_id: int, domain: string, score: float|null}> $pairs
     * @return array<string, float>
     */
    private function replayLedger(array $pairs): array
    {
        /** @var array<string, float> $computed */
        $computed = [];
        $userIds = [];
        foreach ($pairs as $p) {
            $userIds[$p['user_id']] = true;
        }

        $pageSize = 5000;
        foreach (array_chunk(array_keys($userIds), self::USER_BATCH_SIZE) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            /** @var array<string, float> $state */
            $state = [];
            $lastId = 0;
            // FIX-P3-CMD-111: رویدادهای هر chunk با نشانگر id صفحه‌بندی می‌شود (LIMIT 5000)
            // — کاربرانِ پررویداد دیگر حافظه را بی‌سقف نمی‌گیرند.
            while (true) {
                $rows = (array)$this->db->fetchAll(
                    "SELECT id, entity_id, domain, delta, reason, metadata FROM score_events
                     WHERE entity_type = 'user' AND entity_id IN ({$in}) AND id > ?
                     ORDER BY id ASC
                     LIMIT ?",
                    array_merge($chunk, [$lastId, $pageSize])
                );
                if ($rows === []) {
                    break;
                }
                foreach ($rows as $row) {
                    $lastId = max($lastId, (int)($row->id ?? 0));
                    $uid = (int)($row->entity_id ?? 0);
                    $dom = (string)($row->domain ?? '');
                    if ($dom === '' || !isset($pairs[$uid . '|' . $dom])) {
                        continue; // جفتِ بیرون از فیلتر/--domain — نباید حساب شود
                    }
                    $key = $uid . '|' . $dom;
                    $state[$key] = $this->foldDelta($state[$key] ?? 0.0, $row, $dom);
                }
                if (count($rows) < $pageSize) {
                    break;
                }
            }
            $computed += $state;
        }

        return $computed;
    }

    /**
     * یک گامِ لجر را روی value فعلی تا می‌زند (clamp + لنگر admin_set).
     * منطق مشترک replayLedger (استریم) و computeDomainTarget (خوانش کامل).
     */
    private function foldDelta(float $value, object $row, string $dom): float
    {
        $delta = float_value($row->delta ?? 0);
        $reason = str_value($row->reason ?? '');

        if ($reason === 'admin_set') {
            // 🛡️ X362: لنگر مطلق — metadata.target جایگزین جمع می‌شود
            $meta = null;
            if (!empty($row->metadata)) {
                $decoded = json_decode(str_value($row->metadata), true);
                if (is_array($decoded)) {
                    $meta = $decoded;
                }
            }
            if ($meta !== null && array_key_exists('target', $meta)) {
                return ScoreDomainPolicy::clamp($dom, (float)$meta['target']);
            }
            // fallback: admin_set بدون target → رفتار جمعِ معمولی
        }

        return ScoreDomainPolicy::clamp($dom, $value + $delta);
    }

    /**
     * FIX-R36-W3 (F-A19e-11): محاسبهٔ target یک جفت (user, domain) از ردیف‌های لجر —
     * منطق مشترک replayLedger (snapshot بیرونی) و re-خواندنِ تازهٔ داخلِ تراکنشِ
     * نوشتن در applyPlan (بستنِ پنجرهٔ snapshot→write race).
     *
     * مهارِ هر گام با ScoreDomainPolicy (وفادار به معناشناسی زندهٔ listener:
     * clamp هر گام، نه فقط جمعِ نهایی)؛ admin_set لنگرِ مطلق (X362).
     *
     * @param list<\stdClass> $rowsForKey
     */
    private function computeDomainTarget(array $rowsForKey, string $dom): float
    {
        $value = 0.0;
        foreach ($rowsForKey as $row) {
            $delta = float_value($row->delta ?? 0);
            $reason = str_value($row->reason ?? '');

            if ($reason === 'admin_set') {
                // 🛡️ X362: لنگر مطلق — metadata.target جایگزین جمع می‌شود
                $meta = null;
                if (!empty($row->metadata)) {
                    $decoded = json_decode(str_value($row->metadata), true);
                    if (is_array($decoded)) {
                        $meta = $decoded;
                    }
                }
                if ($meta !== null && array_key_exists('target', $meta)) {
                    $value = ScoreDomainPolicy::clamp($dom, (float)$meta['target']);
                    continue;
                }
                // fallback: admin_set بدون target → رفتار جمعِ معمولی
            }

            $value = ScoreDomainPolicy::clamp($dom, $value + $delta);
        }

        return $value;
    }

    /**
     * نوشتن plan داخل user_scores — تراکنشِ per-user (تجمیعِ upsertهای یک کاربر
     * اتمیک می‌ماند) با retry استاندارد TransactionWrapper.
     *
     * 🛡️ FIX-R36-W3 (F-A19e-11): target از «خوانش مجددِ تازهٔ لجر داخل همان تراکنش»
     * محاسبه می‌شود نه از snapshot بیرونیِ replayLedger — دلتای تازه‌ای که listener
     * زنده بین replay و write روی پراجکشن اعمال کرده بود، قبلاً توسط نوشتنِ rebuild
     * پس زده می‌شد (واگرایی گذرا تا rebuild بعدی). SELECT ... FOR UPDATE با
     * هم‌ترتیبِ قفلِ listener (اول score_events، بعد user_scores) هر دلتای هم‌زمان
     * را یا در محاسبهٔ ما وارد می‌کند یا بعد از commit ما روی مقدارِ تازه اعمال می‌کند.
     * مقادیر snapshot فقط برای گزارش/plan-table باقی‌اند.
     *
     * 🛡️ X364 (راند ۹۲): برای دامنهٔ fraud، مقدار هدف به «پروجکشن سوم»
     * users.fraud_score (int) هم در همان تراکنش نوشته می‌شود تا rebuild
     * drift این ستون را هم ببندد (دقیقاً همان قراردادی که listener زنده
     * پس از upsert user_scores اجرا می‌کند). UPDATE برای entity_idهای یتیم
     * به‌طور طبیعی no-op است (گاردِ «بودنِ ردیف» لازم نیست).
     *
     * @param array<int, array<string, float>> $targetsByUser
     */
    private function applyPlan(array $targetsByUser): void
    {
        foreach ($targetsByUser as $uid => $domainTargets) {
            $uid = (int)$uid;
            $executor = function () use ($uid, $domainTargets): void {
                // FIX-R36-W3 (F-A19e-11): خوانش مجدد لجر داخل تراکنش + قلِ ردیف‌ها
                $freshRows = (array)$this->db->fetchAll(
                    "SELECT domain, delta, reason, metadata FROM score_events
                     WHERE entity_type = 'user' AND entity_id = ? ORDER BY id ASC FOR UPDATE",
                    [$uid]
                );
                $grouped = [];
                foreach ($freshRows as $freshRow) {
                    $freshDom = (string)($freshRow->domain ?? '');
                    $grouped[$freshDom][] = $freshRow;
                }

                foreach ($domainTargets as $dom => $snapshotTarget) {
                    // target تازه از لجرِ داخل تراکنش (fallback: خالی = پراجکشنِ یتیم → 0)
                    $target = $this->computeDomainTarget($grouped[$dom] ?? [], $dom);
                    $stmt = $this->db->prepare(
                        'INSERT INTO user_scores (user_id, domain, score, updated_at)
                         VALUES (?, ?, ?, NOW())
                         ON DUPLICATE KEY UPDATE score = VALUES(score), updated_at = NOW()'
                    );
                    $stmt->execute([$uid, $dom, $target]);

                    // 🛡️ X364: پروجکشن سوم users.fraud_score — فقط دامنهٔ fraud
                    if ($dom === 'fraud') {
                        $stmtUsers = $this->db->prepare(
                            'UPDATE users SET fraud_score = ?, updated_at = NOW() WHERE id = ?'
                        );
                        $stmtUsers->execute([(int)round($target), $uid]);
                    }
                }
            };

            if ($this->transactionWrapper !== null) {
                $this->transactionWrapper->runWithRetry($executor);
            } else {
                $executor();
            }
        }
    }

    /** @param list<string> $domains */
    private function invalidateCache(int $userId, array $domains): void
    {
        try {
            if ($domains === []) {
                return;
            }
            $redis = $this->cache->redis();
            if ($redis !== null) {
                $redis->hDel('score:user:' . $userId, ...$domains);
            }
        } catch (\Throwable $e) {
            // غیرمسدودکننده: کش با TTL یک‌ساعته خودش منقضی می‌شود
            $this->logger->debug('scores.rebuild.cache_invalidate_failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * @param array<string, int> $examined
     * @param array<string, int> $changed
     * @return array<string, array{examined: int, changed: int}>
     */
    private function mergePerDomain(array $examined, array $changed): array
    {
        $out = [];
        foreach ($examined as $dom => $count) {
            $out[$dom] = ['examined' => (int)$count, 'changed' => (int)($changed[$dom] ?? 0)];
        }
        foreach ($changed as $dom => $count) {
            if (!isset($out[$dom])) {
                $out[$dom] = ['examined' => 0, 'changed' => (int)$count];
            }
        }
        ksort($out);
        return $out;
    }

    /**
     * جدول تغییرات برای خروجی CLI / dry-run.
     * @param list<array{user_id: int, domain: string, current: ?float, target: float, diff: float}> $plan
     */
    private function printPlanTable(array $plan, bool $dryRun): void
    {
        $title = $dryRun ? 'scores:rebuild — DRY-RUN (هیچ نوشتنی انجام نشد)' : 'scores:rebuild — تغییرات اعمال‌شده';
        echo $title . PHP_EOL;
        printf("%-10s %-24s %14s %14s %12s\n", 'user_id', 'domain', 'current', 'target', 'diff');
        foreach ($plan as $row) {
            printf(
                "%-10d %-24s %14s %14s %12s\n",
                $row['user_id'],
                mb_substr($row['domain'], 0, 24),
                $row['current'] === null ? '—' : (string)$row['current'],
                (string)$row['target'],
                (string)$row['diff']
            );
        }
    }
}
