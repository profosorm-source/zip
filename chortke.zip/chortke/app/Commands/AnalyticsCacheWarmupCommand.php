<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\Analytics\AnalyticsService;
use App\Contracts\LoggerInterface;

/**
 * 🚀 UPG-04: AnalyticsCacheWarmupCommand - پیش‌گرمایش کش‌های آماری سنگین داشبورد
 *
 * استفاده: php cli.php analytics:warmup  (FIX-C135: هم‌نام با ثبتِ bootstrap — قبلاً analytics:warm بود)
 */
class AnalyticsCacheWarmupCommand
{
    private AnalyticsService $analytics;
    private LoggerInterface $logger;
    public function __construct(
        AnalyticsService $analytics,
        LoggerInterface $logger
    ) {        $this->analytics = $analytics;
        $this->logger = $logger;
}

    /**
     * اجرای فرایند پیش‌گرمایش
     */
    /** @param array<string, mixed> $argv */
    public function run(array $argv): void
    {
        $this->logger->info('command.analytics_warmup.starting');
        echo "\n\033[1;34m🚀 Starting Analytics Cache Warmup...\033[0m\n";

        try {
            echo "📈 Pre-loading User Metrics...\n";
            $userMetrics = $this->analytics->getUserMetrics();
            echo "   ✓ Loaded " . count($userMetrics) . " user data points.\n";

            echo "💸 Pre-loading Transaction Metrics...\n";
            $txMetrics = $this->analytics->getTransactionMetrics();
            echo "   ✓ Loaded " . count($txMetrics) . " financial data points.\n";

            echo "📋 Pre-loading Task Metrics...\n";
            $taskMetrics = $this->analytics->getTaskMetrics();
            echo "   ✓ Loaded " . count($taskMetrics) . " operational data points.\n";
            
            echo "📅 Pre-loading Daily Registrations (30 days)...\n";
            $registrations = $this->analytics->getDailyRegistrations(30);
            echo "   ✓ Loaded " . count($registrations) . " daily registration records.\n";

            $this->logger->info('command.analytics_warmup.completed', [
                'user_metrics_count' => count($userMetrics),
                'tx_metrics_count' => count($txMetrics),
                'task_metrics_count' => count($taskMetrics),
                // FIX-P3-CMD-008 (یافتهٔ ۰۰۸): شمارندهٔ registrations در گزارشِ پایان
                // جا مانده بود — پیش‌گرمایش روزیِ ۳۰روزهٔ ثبت‌نام‌ها در لاگ دیده نمی‌شد.
                'registrations_count' => count($registrations),
            ]);
            
            echo "\n\033[1;32m✅ Analytics Cache Warmup Successfully Completed!\033[0m\n\n";
        } catch (\Throwable $e) {
            $this->logger->error('command.analytics_warmup.failed', [
                'error' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            // FIX-CMD005 (یافتهٔ ۰۰۵): متن خام استثنا (SQL/DSN/مسیر سرور) قبلاً مستقیم به
            // خروجی operator می‌رفت. اکنون پیام عمومی + شناسهٔ کوتاه md5 چاپ می‌شود و
            // جزئیات کامل فقط در لاگ ساختاریافته می‌ماند (الگوی رایج DLQRetryCommand).
            echo "\n\033[1;31m❌ Analytics Cache Warmup Failed: operation failed (details in logs, id: " . substr(md5((string)$e->getMessage()), 0, 12) . ")\033[0m\n\n";
            exit(1);
        }
    }
}
