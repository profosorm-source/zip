<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;

/**
 * Section 8.8 — Audit the unified rate-limit policy.
 *
 * این کامند فقط config/rate_limits.php را می‌خواند و گزارش می‌دهد —
 * هیچ side-effect ندارد (idempotent).
 *
 * Usage:
 *   php cli.php ratelimit:audit
 */
class RateLimitAuditCommand
{
    /** FIX-P3-CMD-090 (یافتهٔ ۰۹۰): سقف decay منطقی (دقیقه) برای پرچم مقادیر غیرواقعی. */
    private const MAX_REASONABLE_DECAY_MINUTES = 1440;

    public function __construct(LoggerInterface $logger) {
        unset($logger);
    }

    /** @param array<string, mixed> $argv */

    public function run(array $argv): int
    {
        $cfg = function_exists('config') ? config('rate_limits') : null;
        if (!is_array($cfg)) {
            fwrite(STDERR, "[ratelimit:audit] config/rate_limits.php not loaded.\n");
            return 1;
        }

        // FIX-P3-CMD-089 (یافتهٔ ۰۸۹): شمارندهٔ یافته‌ها — اورفان/مقدار غیرواقعی/
        // mapping خراب دیگر با exit 0 از CI/cron عبور نمی‌کند؛ run() کد خروج
        // ۱ برمی‌گرداند (قرارداد FIX-C141: dispatcher return int را نگاشت می‌کند).
        $findings = 0;

        $groups = array_filter(
            $cfg,
            fn($v, $k) => is_array($v) && !in_array($k, ['default', 'route_map', 'action_map'], true),
            ARRAY_FILTER_USE_BOTH
        );

        echo "═══════════════════════════════════════════════════════════════\n";
        echo " Rate-Limit Policy Audit (single source of truth)\n";
        echo "═══════════════════════════════════════════════════════════════\n\n";

        // Default
        $default = $cfg['default'] ?? [];
        $defaultMax = (int)($default['max_attempts'] ?? 0);
        $defaultDecay = (int)($default['decay_minutes'] ?? 0);
        echo sprintf(
            "DEFAULT: %d req / %d min\n\n",
            $defaultMax,
            $defaultDecay
        );

        // FIX-P3-CMD-090 (یافتهٔ ۰۹۰): مقادیر غیرواقعی به‌جای cast بی‌صدا، یافتهٔ ممیزی‌اند —
        // max_attempts<=0 یعنی همه درخواست‌ها رد/همه مجاز (بسته به policy consumer)،
        // decay<=0 پنجرهٔ بی‌معنا و decay بسیار بزرگ عملاً پاک‌نشده می‌ماند.
        if ($this->isImplausiblePolicy($defaultMax, $defaultDecay)) {
            echo sprintf(
                "  ⚠ implausible DEFAULT policy: max_attempts=%d decay_minutes=%d (expected 1..100000 / 1..%d)\n\n",
                $defaultMax,
                $defaultDecay,
                self::MAX_REASONABLE_DECAY_MINUTES
            );
            $findings++;
        }

        // Groups
        echo "── Groups ─────────────────────────────────────────────────────\n";
        foreach ((array)$groups as $group => $entries) {
            $count = 0;
            foreach ((array)$entries as $endpoint => $entry) {
                if (!is_array($entry) || !isset($entry['max_attempts'])) {
                    continue;
                }
                $count++;
                $maxAttempts = (int)$entry['max_attempts'];
                $decayMinutes = (int)($entry['decay_minutes'] ?? 0);
                $fc = !empty($entry['fail_closed']) ? ' [fail-closed]' : '';
                printf(
                    "  %-12s %-22s %4d req / %4d min%s\n",
                    $group,
                    (string)$endpoint,
                    $maxAttempts,
                    $decayMinutes,
                    $fc
                );
                // FIX-P3-CMD-090: مقدار غیرواقعی policy به‌جای cast بی‌صدا، یافته است
                if ($this->isImplausiblePolicy($maxAttempts, $decayMinutes)) {
                    echo sprintf(
                        "      ⚠ implausible policy value for %s.%s (max_attempts=%d, decay_minutes=%d)\n",
                        $group,
                        (string)$endpoint,
                        $maxAttempts,
                        $decayMinutes
                    );
                    $findings++;
                }
            }
            if ($count === 0) {
                printf("  %-12s (no entries)\n", $group);
            }
        }

        // Route map
        echo "\n── Route → Policy map ─────────────────────────────────────────\n";
        $routeMap = $cfg['route_map'] ?? [];
        if (!$routeMap) {
            echo "  (empty — middleware will use defaults for everything!)\n";
        } else {
            $orphans = [];
            foreach ((array)$routeMap as $pattern => $target) {
                // FIX-P3-CMD-091 (یافتهٔ ۰۹۱): اعتبارسنجی شکل هدف — رشته/int/آرایهٔ
                // ناقص قبلاً به «کاراکتر اول» یا '' فرو می‌کافت و گروه الکی حل می‌شد.
                if (!is_array($target) || !isset($target[0], $target[1]) || !is_string($target[0]) || $target[0] === '') {
                    echo sprintf(
                        "  %-30s → ⚠ malformed mapping (expected [group, endpoint])\n",
                        (string)$pattern
                    );
                    $findings++;
                    continue;
                }
                $group    = $target[0];
                $endpoint = is_string($target[1]) && $target[1] !== '' ? $target[1] : 'general';
                $resolved = config("rate_limits.{$group}.{$endpoint}");
                if (!is_array($resolved) || !isset($resolved['max_attempts'])) {
                    $resolved = config("rate_limits.{$group}");
                }
                $ok = is_array($resolved) && isset($resolved['max_attempts']);
                if (!$ok) {
                    $orphans[] = "{$pattern} → {$group}.{$endpoint}";
                }
                printf(
                    "  %-30s → %s.%s %s\n",
                    (string)$pattern,
                    $group,
                    $endpoint,
                    $ok ? '' : '  ⚠ orphan (no matching config entry)'
                );
            }
            if ($orphans) {
                echo "\n  ⚠ " . count($orphans) . " orphan route mappings detected.\n";
                // FIX-P3-CMD-089: اورفان‌ها در شمارندهٔ یافته‌ها می‌روند (خروج ۱)
                $findings += count($orphans);
            }
        }

        // Action map
        echo "\n── Action → Policy map ────────────────────────────────────────\n";
        $actionMap = $cfg['action_map'] ?? [];
        if (!$actionMap) {
            echo "  (empty — RateLimitPolicy will use legacy ACTIONS const)\n";
        } else {
            foreach ((array)$actionMap as $action => $target) {
                // FIX-P3-CMD-091: همان گارد شکل برای action_map
                if (!is_array($target) || !isset($target[0], $target[1]) || !is_string($target[0]) || $target[0] === '') {
                    echo sprintf(
                        "  %-25s → ⚠ malformed mapping (expected [group, endpoint])\n",
                        (string)$action
                    );
                    $findings++;
                    continue;
                }
                printf(
                    "  %-25s → %s.%s\n",
                    (string)$action,
                    $target[0],
                    is_string($target[1]) && $target[1] !== '' ? $target[1] : 'general'
                );
            }
        }

        echo "\n═══════════════════════════════════════════════════════════════\n";
        printf("  routes: %d   actions: %d   groups: %d\n",
            count($routeMap),
            count($actionMap),
            count($groups)
        );
        echo "═══════════════════════════════════════════════════════════════\n";

        // FIX-P3-CMD-089: هر یافته (اورفان/ناقص/غیرواقعی) ⇒ خروج ۱ برای CI/cron
        return $findings > 0 ? 1 : 0;
    }

    /**
     * FIX-P3-CMD-090: تشخیص مقدار غیرواقعی policy — max_attempts خارج [1، ۱۰۰۰۰۰]
     * یا decay خارج [1، ۱۴۴۰ دقیقه].
     */
    private function isImplausiblePolicy(int $maxAttempts, int $decayMinutes): bool
    {
        return $maxAttempts <= 0 || $maxAttempts > 100000
            || $decayMinutes <= 0 || $decayMinutes > self::MAX_REASONABLE_DECAY_MINUTES;
    }
}
