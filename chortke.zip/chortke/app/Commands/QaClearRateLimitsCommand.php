<?php

declare(strict_types=1);

namespace App\Commands;

use Core\RateLimiter;

/**
 * Command: QaClearRateLimitsCommand — 🛡️ FIX-R80-Q1
 *
 * استفاده: php cli.php qa:clear-rate-limits
 *
 * پاک‌سازی کلیدهای ریت‌لیمیت پنجرهٔ ثابت (chortke:rl:fw:*) در Redis برای
 * باتری تست/QA — سهمیه‌های باقی‌مانده از ران قبلی (پنجرهٔ ۶۰دقیقه‌ای) مانع
 * اجرای تمیز تست‌های بعدی می‌شوند (درس سگای ۱۳، CHANGES-R79 §۵.۲).
 *
 * عمداً در production اجرا نمی‌شود: سهمیه‌های واقعی کاربران پاک نخواهند شد.
 */
class QaClearRateLimitsCommand
{
    private RateLimiter $rateLimiter;

    public function __construct(RateLimiter $rateLimiter) {
        $this->rateLimiter = $rateLimiter;
    }

    /** @param array<string, mixed> $argv */
    public function run(array $argv): int
    {
        $env = strtolower(str_value(env('APP_ENV', 'local') ?: 'local'));
        if ($env === 'production') {
            echo "ERROR: qa:clear-rate-limits is a QA-only command and refuses to run in production.\n";
            return 1;
        }

        // 🛡️ FIX-R81-Q1: کلیدهای سطلِ توکن (chortke:rl:tb:* — شامل fallback
        // rl:tb:fw:*) نیز پاک می‌شوند؛ در R80 فقط پنجرهٔ ثابت پاک می‌شد و
        // سهمیهٔ token-bucketِ مسیر لاگین بین سوئیت‌های مرورگری زنده می‌ماند.
        $deletedFw = $this->rateLimiter->clearFixedWindow('*');
        $deletedTb = $this->rateLimiter->clearTokenBucket('*');
        $deleted = $deletedFw + $deletedTb;
        echo "SUCCESS: deleted {$deletedFw} fixed-window (rl:fw:*) + {$deletedTb} token-bucket (rl:tb:*) rate-limit key(s).\n";
        return 0;
    }
}
