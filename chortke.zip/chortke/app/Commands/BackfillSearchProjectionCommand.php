<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Jobs\BackfillSearchProjectionJob;

/**
 * CLI entry point برای Backfill اولیه‌ی Read-Model جستجو (CQRS).
 *
 * Usage:
 *   php cli.php search:backfill                 # همه‌ی منابع
 *   php cli.php search:backfill --source=transactions
 *   php cli.php search:backfill --batch=1000
 */
final class BackfillSearchProjectionCommand
{
    private BackfillSearchProjectionJob $job;
    private LoggerInterface $logger;
    public function __construct(
        BackfillSearchProjectionJob $job,
        LoggerInterface $logger
    ) {        $this->job = $job;
        $this->logger = $logger;

    }

    /** @param array<int|string, mixed> $argv */

    public function run(array $argv): void
    {
        $source = 'all';
        $batch = 500;

        foreach ($argv as $arg) {
            if (is_string($arg) && str_starts_with($arg, '--source=')) {
                $source = substr($arg, 9);
            } elseif (is_string($arg) && str_starts_with($arg, '--batch=')) {
                $batch = (int)substr($arg, 8);
            }
        }

        echo "[search:backfill] starting (source={$source}, batch={$batch})...\n";

        try {
            $this->job->handle(['source' => $source, 'batch_size' => $batch]);
            echo "[search:backfill] completed. See logs for per-source totals.\n";
        } catch (\Throwable $e) {
            // FIX-P3-CMD-011 (یافتهٔ ۰۱۱): متن خام خطای جاب (SQL/DSN/مسیر سرور) قبلاً
            // مستقیم به STDERR operator می‌رفت؛ اکنون پیام عمومی + شناسهٔ کوتاه md5 و
            // جزئیات کامل فقط در لاگ ساختاریافتهٔ search.backfill.cli_failed می‌ماند
            // (هم‌الگوی DLQRetryCommand/AnalyticsCacheWarmupCommand).
            $this->logger->error('search.backfill.cli_failed', [
                'error' => $e->getMessage(),
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
            $stderr = defined('STDERR') ? STDERR : null;
            $message = "[search:backfill] error: job failed (details in logs, id: "
                . substr(md5((string)$e->getMessage()), 0, 12) . ")\n";
            if ($stderr !== null) {
                fwrite($stderr, $message);
            } else {
                echo $message;
            }
            exit(1);
        }
    }
}
