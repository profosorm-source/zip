<?php

declare(strict_types=1);

/**
 * Feature Flag CLI Management
 *
 * استفاده:
 * php cli.php feature:list
 * php cli.php feature:enable crypto_wallet
 * php cli.php feature:disable crypto_wallet
 * php cli.php feature:status crypto_wallet
 * php cli.php feature:create new_feature "توضیحات"
 * php cli.php feature:delete old_feature
 * php cli.php feature:rollout lottery 50
 * php cli.php feature:schedule lottery "2026-05-01 00:00:00" "2026-05-31 23:59:59"
 */

namespace App\Commands;

use App\Services\FeatureFlagService;
use App\Contracts\LoggerInterface;

class FeatureFlagCommand
{
    private FeatureFlagService $featureService;
    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger, FeatureFlagService $featureService) {
        // FIX-CMD041 (یافتهٔ ۰۴۱): لاگر دیگر دور ریخته نمی‌شود — برای هشدارِ
        // ساختاریافتهٔ شکست update در schedule لازم است.
        $this->logger = $logger;
        $this->featureService = $featureService;
    }

    /**
     * FIX-P3-CMD-047 (یافتهٔ ۰۴۷): پاک‌سازی کاراکترهای کنترلی/ANSI از مقادیر دیتابیسی
     * قبل از چاپ به ترمینال — name/description/تاریخچهٔ old/new (که از دستکاری DB
     * می‌توانند حاوی \n/ESC/CR باشند) دیگر بستر ترمینال را نمی‌شکنند؛ طول هم سقف
     * امن (۲۰۰) می‌گیرد.
     */
    private function termSafe(mixed $value): string
    {
        $str = is_scalar($value) ? (string)$value : '';
        $str = (string)preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $str);
        return mb_substr($str, 0, 200);
    }

    /**
     * FIX-P3-CMD-048 (یافتهٔ ۰۴۸): دیکد ستون‌های JSON نقش/وابستگی/تگ با آشکارسازی خطا —
     * قبلاً ستونِ خراب بی‌صدا به لیست خالی فرو می‌کافت و operator فکر می‌کرد واقعاً
     * هیچ نقش/تگی تنظیم نشده است. اکنون خطای JSON هشدار داده می‌شود (خروجی + لاگ).
     *
     * @return array{items: list<string>, error: ?string}
     */
    private function decodeJsonList(?string $raw): array
    {
        if (!is_string($raw) || trim($raw) === '') {
            return ['items' => [], 'error' => null];
        }
        $decoded = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            return ['items' => [], 'error' => 'invalid JSON (review DB value)'];
        }
        $items = [];
        foreach ($decoded as $v) {
            if (is_scalar($v)) {
                $items[] = $this->termSafe($v);
            }
        }
        return ['items' => $items, 'error' => null];
    }

    /**
     * لیست همه فیچرها
     */
    public function list(): int
    {
        $features = $this->featureService->getAll();

        if (empty($features)) {
            echo "هیچ فیچری یافت نشد.\n";
            return 0;
        }

        echo "\n┌─────────────────────────────────────────────────────────────────────────┐\n";
        echo "│                         Feature Flags List                             │\n";
        echo "├──────────────────────────────┬──────────┬──────────┬───────────────────┤\n";
        echo "│ Name                         │ Enabled  │ Rollout  │ Priority          │\n";
        echo "├──────────────────────────────┼──────────┼──────────┼───────────────────┤\n";

        foreach ($features as $feature) {
            /** @var object{name: string, enabled: bool|int, enabled_percentage: int|float|string, priority: mixed, description: string, enabled_for_roles: string|null, enabled_for_users: string|null, enabled_from: string|null, enabled_until: string|null, depends_on: string|null, tags: string|null, created_at: string, updated_at: string} $feature */
            $name = str_pad(substr($this->termSafe($feature->name), 0, 28), 28);
            $enabled = $feature->enabled ? '✓ Yes' : '✗ No ';
            $enabled = str_pad($enabled, 8);
            $rollout = str_pad($feature->enabled_percentage . '%', 8);
            $priorityValue = $feature->priority;
            $priority = str_pad(is_scalar($priorityValue) ? (string)$priorityValue : '0', 17);

            echo "│ {$name} │ {$enabled} │ {$rollout} │ {$priority} │\n";
        }

        echo "└──────────────────────────────┴──────────┴──────────┴───────────────────┘\n";

        $stats = $this->featureService->getStats();
        echo "\nآمار: " . int_value($stats['total'] ?? 0)
            . " فیچر | " . int_value($stats['enabled'] ?? 0)
            . " فعال | " . int_value($stats['disabled'] ?? 0) . " غیرفعال\n\n";
        return 0;
    }

    /**
     * فعال کردن فیچر
     * FIX-C121 (یافتهٔ ۱۲۱): exit() حذف شد — کد خروج برگردانده می‌شود تا dispatcher
     * (که آن را به exit code نگاشت می‌کند) و تست‌پذیری و ترکیب‌پذیری حفظ شود.
     */
    public function enable(string $name): int
    {
        $feature = $this->featureService->findByName($name);

        if (!$feature) {
            echo "❌ فیچر '{$name}' یافت نشد.\n";
            return 1;
        }
        /** @var object{name: string, enabled: bool|int, enabled_percentage: int|float|string, priority: mixed, description: string, enabled_for_roles: string|null, enabled_for_users: string|null, enabled_from: string|null, enabled_until: string|null, depends_on: string|null, tags: string|null, created_at: string, updated_at: string} $feature */

        if ($feature->enabled) {
            echo "ℹ️  فیچر '{$name}' از قبل فعال است.\n";
            return 0;
        }

        if ($this->featureService->update($name, ['enabled' => true])) {
            echo "✅ فیچر '{$name}' با موفقیت فعال شد.\n";
            return 0;
        }
        echo "❌ خطا در فعال‌سازی فیچر.\n";
        return 1;
    }

    /**
     * غیرفعال کردن فیچر
     */
    public function disable(string $name): int
    {
        $feature = $this->featureService->findByName($name);

        if (!$feature) {
            echo "❌ فیچر '{$name}' یافت نشد.\n";
            return 1;
        }
        /** @var object{name: string, enabled: bool|int, enabled_percentage: int|float|string, priority: mixed, description: string, enabled_for_roles: string|null, enabled_for_users: string|null, enabled_from: string|null, enabled_until: string|null, depends_on: string|null, tags: string|null, created_at: string, updated_at: string} $feature */

        if (!$feature->enabled) {
            echo "ℹ️  فیچر '{$name}' از قبل غیرفعال است.\n";
            return 0;
        }

        if ($this->featureService->update($name, ['enabled' => false])) {
            echo "✅ فیچر '{$name}' با موفقیت غیرفعال شد.\n";
            return 0;
        }
        echo "❌ خطا در غیرفعال‌سازی فیچر.\n";
        return 1;
    }

    /**
     * نمایش وضعیت فیچر
     */
    public function status(string $name): int
    {
        $feature = $this->featureService->findByName($name);

        if (!$feature) {
            echo "❌ فیچر '{$name}' یافت نشد.\n";
            return 1;
        }
        /** @var object{name: string, enabled: bool|int, enabled_percentage: int|float|string, priority: mixed, description: string, enabled_for_roles: string|null, enabled_for_users: string|null, enabled_from: string|null, enabled_until: string|null, depends_on: string|null, tags: string|null, created_at: string, updated_at: string} $feature */

        echo "\n╔═══════════════════════════════════════════════════════════════╗\n";
        echo "║              Feature Status: " . $this->termSafe($name) . "\n";
        echo "╠═══════════════════════════════════════════════════════════════╣\n";
        echo "║ Enabled:         " . ($feature->enabled ? '✓ Yes' : '✗ No') . "\n";
        // FIX-P3-CMD-047: description ستون دیتابیس است — قبل از چاپ escape می‌شود
        echo "║ Description:     " . $this->termSafe($feature->description) . "\n";
        echo "║ Rollout:         {$feature->enabled_percentage}%\n";
        echo "║ Priority:        " . ($feature->priority ?? 0) . "\n";

        if ($feature->enabled_for_roles ?? null) {
            // FIX-P3-CMD-048: JSON خراب هشدار داده می‌شود، نه لیست خالیِ بی‌صدا
            $roles = $this->decodeJsonList($feature->enabled_for_roles);
            if ($roles['error'] !== null) {
                $this->logger->warning('feature.cli.invalid_json_field', ['name' => $name, 'field' => 'enabled_for_roles']);
                echo "║ Allowed Roles:   ⚠ {$roles['error']}\n";
            } else {
                echo "║ Allowed Roles:   " . implode(', ', $roles['items']) . "\n";
            }
        }

        if ($feature->enabled_from ?? null) {
            echo "║ Enabled From:    {$feature->enabled_from}\n";
        }

        if ($feature->enabled_until ?? null) {
            echo "║ Enabled Until:   {$feature->enabled_until}\n";
        }

        if ($feature->depends_on ?? null) {
            $deps = $this->decodeJsonList($feature->depends_on);
            if ($deps['error'] !== null) {
                $this->logger->warning('feature.cli.invalid_json_field', ['name' => $name, 'field' => 'depends_on']);
                echo "║ Dependencies:    ⚠ {$deps['error']}\n";
            } else {
                echo "║ Dependencies:    " . implode(', ', $deps['items']) . "\n";
            }
        }

        if ($feature->tags ?? null) {
            $tags = $this->decodeJsonList($feature->tags);
            if ($tags['error'] !== null) {
                $this->logger->warning('feature.cli.invalid_json_field', ['name' => $name, 'field' => 'tags']);
                echo "║ Tags:            ⚠ {$tags['error']}\n";
            } else {
                echo "║ Tags:            " . implode(', ', $tags['items']) . "\n";
            }
        }

        echo "║ Created:         {$feature->created_at}\n";
        echo "║ Updated:         {$feature->updated_at}\n";
        echo "╚═══════════════════════════════════════════════════════════════╝\n\n";

        // نمایش متریک‌ها
        $metrics = $this->featureService->getMetrics($name);

        if (!empty($metrics)) {
            echo "📊 Metrics (Last 24 hours):\n";
            foreach ($metrics as $metric) {
                echo "   - Total checks: {$metric->total_checks}\n";
                echo "   - Allowed: {$metric->allowed_count}\n";
                echo "   - Denied: {$metric->denied_count}\n";
                if (isset($metric->avg_response_time)) {
                    echo "   - Avg response: " . round((float)$metric->avg_response_time, 2) . "ms\n";
                }
            }
            echo "\n";
        }

        return 0;
    }

    /**
     * ایجاد فیچر جدید
     */
    public function create(string $name, string $description): int
    {
        try {
            if ($this->featureService->create([
                'name' => $name,
                'description' => $description,
                'enabled' => false,
            ])) {
                echo "✅ فیچر '{$name}' با موفقیت ایجاد شد.\n";
                return 0;
            }
            echo "❌ خطا: ایجاد فیچر ناموفق بود.\n";
            return 1;
        } catch (\Exception $e) {
            echo "❌ خطا: {$e->getMessage()}\n";
            return 1;
        }
    }

    /**
     * حذف فیچر
     */
    public function delete(string $name, bool $force = false): int
    {
        if ($force) {
            $confirm = 'yes';
        } elseif (!defined('STDIN') || !stream_isatty(STDIN)) {
            echo "❌ خطا: عملیات حذف در محیط غیرتعاملی غیرمجاز است؛ مگر اینکه از فلگ --force استفاده کنید.\n";
            return 1;
        } else {
            echo "⚠️  آیا از حذف فیچر '{$name}' مطمئن هستید؟ (yes/no): ";
            $confirm = trim(fgets(STDIN) ?: '');
        }

        if (strtolower((string)$confirm) !== 'yes') {
            echo "❌ عملیات لغو شد.\n";
            return 0;
        }

        if ($this->featureService->delete($name)) {
            echo "✅ فیچر '{$name}' با موفقیت حذف شد.\n";
            return 0;
        }
        echo "❌ خطا در حذف فیچر یا فیچر یافت نشد.\n";
        return 1;
    }

    /**
     * تنظیم درصد Rollout
     */
    public function rollout(string $name, int $percentage): int
    {
        if ($percentage < 0 || $percentage > 100) {
            echo "❌ درصد باید بین 0 تا 100 باشد.\n";
            return 1;
        }

        if ($this->featureService->update($name, ['enabled_percentage' => $percentage])) {
            echo "✅ درصد rollout فیچر '{$name}' به {$percentage}% تغییر کرد.\n";
            return 0;
        }
        echo "❌ خطا در تغییر rollout.\n";
        return 1;
    }

    /**
     * زمان‌بندی فیچر
     * FIX-C149 (یافتهٔ ۱۴۹): پارس تاریخ با timezone صریح برنامه (نه implicit);
     * ورودی مبهم/نامعتبر fail-loud است.
     */
    public function schedule(string $name, string $from, string $until): int
    {
        $timezone = new \DateTimeZone((string)(config('app.timezone') ?: 'Asia/Tehran'));
        $format = 'Y-m-d H:i:s';
        $fromTime = \DateTimeImmutable::createFromFormat($format, trim($from), $timezone)
            ?: \DateTimeImmutable::createFromFormat('Y-m-d H:i', trim($from), $timezone);
        $untilTime = \DateTimeImmutable::createFromFormat($format, trim($until), $timezone)
            ?: \DateTimeImmutable::createFromFormat('Y-m-d H:i', trim($until), $timezone);

        if ($fromTime === false || $untilTime === false) {
            echo "❌ خطا: فرمت زمان ارسال شده نامعتبر است (الگوی مورد انتظار: {$format}).\n";
            return 1;
        }

        if ($untilTime <= $fromTime) {
            echo "❌ خطا: زمان پایان زمان‌بندی باید بعد از زمان شروع باشد.\n";
            return 1;
        }

        try {
            $ok = $this->featureService->update($name, [
                'enabled_from' => $fromTime->format($format),
                'enabled_until' => $untilTime->format($format),
            ]);

            // FIX-CMD041 (یافتهٔ ۰۴۱): نتیجهٔ bool تغییر update قبلاً نادیده گرفته
            // می‌شد و شکستِ نوشتن هم «✅ زمان‌بندی شد» + exit 0 گزارش می‌شد. اکنون
            // false ⇒ پیام شکست عمومی (بدون خطای خام DB) + warning لاگ + exit 1.
            if (!$ok) {
                $this->logger->warning('feature.schedule.update_failed', ['name' => $name]);
                echo "❌ خطا: به‌روزرسانی زمان‌بندی فیچر '{$name}' ناموفق بود (جزئیات در لاگ).\n";
                return 1;
            }

            echo "✅ فیچر '{$name}' برای بازه زمانی زیر زمان‌بندی شد (timezone: {$timezone->getName()}):\n";
            echo "   از: " . $fromTime->format($format) . "\n";
            echo "   تا: " . $untilTime->format($format) . "\n";
            return 0;
        } catch (\Exception $e) {
            echo "❌ خطا: {$e->getMessage()}\n";
            return 1;
        }
    }

    /**
     * نمایش تاریخچه تغییرات
     */
    public function history(string $name, int $limit = 20): int
    {
        // FIX-CMD042 (یافتهٔ ۰۴۲): سقف کوئری تاریخچه — قبلاً getHistory بدون limitِ
        // CLI صدا زده می‌شد (پیش‌فرض ۵۰) در حالی که header مقدار CLI را چاپ می‌کرد؛
        // اکنون همان مقدار (کلمپ‌شده به [1، ۱۰۰]) به کوئری می‌رود — LIMIT پارامتری است.
        $history = $this->featureService->getHistory($name, max(1, min($limit, 100)));

        if (empty($history)) {
            echo "هیچ تاریخچه‌ای برای '{$name}' یافت نشد.\n";
            return 0;
        }

        echo "\n📜 History for '" . $this->termSafe($name) . "' (Last {$limit} changes):\n";
        echo "─────────────────────────────────────────────────────────────\n";

        foreach ($history as $entry) {
            // FIX-P3-CMD-047: مقادیر تاریخچه (old/new) از نوع‌های cast شدنی DB می‌آیند —
            // قبل از چاپ escape می‌شوند (سطرهای تاریخچه از ستون‌های varchar/JSON).
            echo "[" . $this->termSafe($entry->changed_at) . "] ";
            echo $this->termSafe($entry->action) . ": " . $this->termSafe($entry->field_changed) . " ";
            echo "(" . $this->termSafe($entry->old_value) . " → " . $this->termSafe($entry->new_value) . ")\n";
        }

        echo "\n";
        return 0;
    }

    /**
     * پاکسازی Cache
     * FIX-C148 (یافتهٔ ۱۴۸): در محیط غیرتعاملی (cron/CI) دیگر روی STDIN منتظر
     * نمی‌ماند (fgets(STDIN) می‌توانست تا ابد بلاک کند)؛ تأیید غیرتعاملی فقط با
     * فلگ --yes. خروجی int برای dispatcher.
     */
    public function clearCache(bool $yes = false): int
    {
        $count = $this->featureService->getCacheCount();
        if ($count === 0) {
            echo "ℹ️ کش خالی است.\n";
            return 0;
        }

        if ($yes) {
            $confirm = 'yes';
        } elseif (!defined('STDIN') || !stream_isatty(STDIN)) {
            echo "❌ پاک‌سازی کش در محیط غیرتعاملی نیازمند فلگ --yes است ({$count} رکورد).\n";
            return 1;
        } else {
            echo "⚠️ این عمل {$count} رکورد کش را حذف میکند. تأیید کنید (yes/no): ";
            $confirm = trim((string)(fgets(STDIN) ?: ''));
        }

        if (strtolower((string)$confirm) !== 'yes') {
            echo "❌ عملیات لغو شد.\n";
            return 0;
        }

        $this->featureService->clearCache();
        echo "✅ Cache فیچرها پاک شد.\n";
        return 0;
    }

    /**
     * پاکسازی Metrics قدیمی
     * FIX-C150 (یافتهٔ ۱۵۰): بازهٔ ورودی به [1، 3650] روز محدود می‌شود —
     * مقدار نجومی آستانه را به «اکنون» می‌برد و همهٔ metrics پاک می‌شد؛
     * strtotime false هم fail-loud می‌شود (نه سقوط به time()).
     */
    public function cleanupMetrics(int $days = 30): int
    {
        $days = max(1, min(3650, $days));
        $this->featureService->cleanupMetrics($days);
        echo "✅ Metrics قدیمی‌تر از {$days} روز پاک شدند.\n";
        return 0;
    }
    /**
     * اجرای دستورات
     *
     * FIX-C136/C121: سازگار با هر دو قرارداد فراخوانی — dispatcher آرگومان
     * بریده‌شده می‌دهد (['feature:list', ...])، تست‌ها full argv — و کد خروج int
     * برمی‌گرداند (exit() حذف شد؛ dispatcher آن را به exit code نگاشت می‌کند).
     */
    /** @param list<mixed> $argv */
    public function run(array $argv): int
    {
        // نرمال‌سازی قرارداد: اگر اکشن روی args[0] است (dispatcher)، placeholder
        // اضافه می‌شود تا ریاضی ایندکس‌های قدیمی (نام روی args[2]) حفظ شود.
        if (isset($argv[0]) && is_string($argv[0]) && str_starts_with($argv[0], 'feature:')) {
            array_unshift($argv, 'cli.php');
        }
        $action = $argv[1] ?? 'help';
        if (!is_string($action)) {
            $this->usageError('Command name must be a string.');
        }

        $exit = 0;
        switch ($action) {
            case 'feature:list':
                $exit = $this->list();
                break;

            case 'feature:enable':
                $name = $this->requiredStringArgument($argv, 2, 'Usage: php cli.php feature:enable <name>');
                $exit = $this->enable($name);
                break;

            case 'feature:disable':
                $name = $this->requiredStringArgument($argv, 2, 'Usage: php cli.php feature:disable <name>');
                $exit = $this->disable($name);
                break;

            case 'feature:status':
                $name = $this->requiredStringArgument($argv, 2, 'Usage: php cli.php feature:status <name>');
                $exit = $this->status($name);
                break;

            case 'feature:create':
                $name = $this->requiredStringArgument($argv, 2, 'Usage: php cli.php feature:create <name> <description>');
                $description = $this->requiredStringArgument($argv, 3, 'Usage: php cli.php feature:create <name> <description>');
                $exit = $this->create($name, $description);
                break;

            case 'feature:delete':
                $force = in_array('--force', $argv, true);
                // فیلتر کردن فلگ --force از آرگومان‌ها برای استخراج صحیح نام فیچر
                $argsWithoutFlags = array_values(array_filter(
                    $argv,
                    static fn(mixed $value): bool => $value !== '--force'
                ));
                $name = $this->requiredStringArgument(
                    $argsWithoutFlags,
                    2,
                    'Usage: php cli.php feature:delete <name> [--force]'
                );
                $exit = $this->delete($name, $force);
                break;

            case 'feature:rollout':
                $name = $this->requiredStringArgument($argv, 2, 'Usage: php cli.php feature:rollout <name> <percentage>');
                $percentage = $this->requiredIntegerArgument($argv, 3, 'Usage: php cli.php feature:rollout <name> <percentage>');
                $exit = $this->rollout($name, $percentage);
                break;

            case 'feature:schedule':
                $name = $this->requiredStringArgument($argv, 2, 'Usage: php cli.php feature:schedule <name> <from> <until>');
                $from = $this->requiredStringArgument($argv, 3, 'Usage: php cli.php feature:schedule <name> <from> <until>');
                $until = $this->requiredStringArgument($argv, 4, 'Usage: php cli.php feature:schedule <name> <from> <until>');
                $exit = $this->schedule($name, $from, $until);
                break;

            case 'feature:history':
                $name = $this->requiredStringArgument($argv, 2, 'Usage: php cli.php feature:history <name> [limit]');
                $limit = array_key_exists(3, $argv)
                    ? $this->requiredIntegerArgument($argv, 3, 'Usage: php cli.php feature:history <name> [limit]')
                    : 20;
                $exit = $this->history($name, $limit);
                break;

            case 'feature:clear-cache':
                // FIX-C148: تأیید غیرتعاملی با --yes
                $exit = $this->clearCache(in_array('--yes', $argv, true) || in_array('--force', $argv, true));
                break;

            case 'feature:cleanup-metrics':
                $days = array_key_exists(2, $argv)
                    ? $this->requiredIntegerArgument($argv, 2, 'Usage: php cli.php feature:cleanup-metrics [days]')
                    : 30;
                $exit = $this->cleanupMetrics($days);
                break;

            default:
                // FIX-C136: اکشن ناشناخته (شبیه feature:*) دیگر بی‌صدا help نمی‌شود —
                // خطای usage + exit 1؛ help واقعی فقط برای help/ناکامل‌شده.
                if (str_starts_with($action, 'feature:')) {
                    echo "Unknown feature command: {$action}\n\n";
                    $this->printHelp();
                    return 1;
                }
                $this->printHelp();
                $exit = 0;
                break;
        }

        return $exit;
    }

    private function printHelp(): void
    {
        echo "Feature Flag Management Commands:\n";
        echo "  feature:list                           - List all features\n";
        echo "  feature:enable <name>                  - Enable a feature\n";
        echo "  feature:disable <name>                 - Disable a feature\n";
        echo "  feature:status <name>                  - Show feature status\n";
        echo "  feature:create <name> <description>    - Create new feature\n";
        echo "  feature:delete <name>                  - Delete a feature\n";
        echo "  feature:rollout <name> <percentage>    - Set rollout percentage\n";
        echo "  feature:schedule <name> <from> <until> - Schedule feature\n";
        echo "  feature:history <name> [limit]         - Show change history\n";
        echo "  feature:clear-cache [--yes]            - Clear feature cache\n";
        echo "  feature:cleanup-metrics [days]         - Clean old metrics\n";
    }

    /** @param list<mixed> $argv */
    private function requiredStringArgument(array $argv, int $index, string $usage): string
    {
        $value = $argv[$index] ?? null;
        if (!is_string($value) || trim($value) === '') {
            $this->usageError($usage);
        }
        return $value;
    }

    /** @param list<mixed> $argv */
    private function requiredIntegerArgument(array $argv, int $index, string $usage): int
    {
        $value = $argv[$index] ?? null;
        $parsed = is_string($value) ? filter_var($value, FILTER_VALIDATE_INT) : false;
        if (!is_int($parsed)) {
            $this->usageError($usage);
        }
        return $parsed;
    }

    /**
     * FIX-C121 (یافتهٔ ۱۲۱): exit() حذف شد — به‌جای آن استثنای usage پرتاب
     * می‌شود که در run() گرفته و به کد خروج ۱ نگاشت می‌شود (تست‌پذیری/ترکیب‌پذیری).
     */
    private function usageError(string $message): never
    {
        throw new FeatureFlagCommandUsageException($message);
    }
}

/**
 * استثنای داخلی usage برای FeatureFlagCommand — نگاشت به exit 1 در run().
 */
class FeatureFlagCommandUsageException extends \RuntimeException
{
}