<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Command;
use Core\Database;
use Core\Queue;
use App\Contracts\LoggerInterface;

/**
 * QueueFailedCommand - مدیریت کامل DLQ (Dead Letter Queue)
 *
 * وظیفه این دستور مانیتورینگ، پاکسازی و اجرای مجدد (Replay) جاب‌های شکست خورده است.
 */
class QueueFailedCommand extends Command
{
    private Database $db;
    private Queue $queue;
    private LoggerInterface $logger;
    public function __construct(
        Database $db,
        Queue $queue,
        LoggerInterface $logger
    ) {        $this->db = $db;
        $this->queue = $queue;
        $this->logger = $logger;
}

    /**
     * لیست کردن آخرین جاب‌های شکست خورده
     *
     * FIX-P3-CMD-080 (یافتهٔ ۰۸۰): ستون status واکشی و نمایش داده می‌شود — قبلاً
     * ردیف‌های claim‌شده (processing) هم بدون وضعیت چاپ می‌شدند و operator فکر
     * می‌کرد همه pending‌اند. شمارش در هدر هم فقط ردیف‌های غیر-processing را
     * «آمادهٔ بازصف» می‌شمارد.
     *
     * FIX-P3-CMD-081 (یافتهٔ ۰۸۱): کد خروج int — شکست واکشی دیگر exit 0 نیست.
     */
    public function list(): int
    {
        try {
            $failed = $this->db->fetchAll("SELECT id, queue, status, failed_at FROM failed_jobs ORDER BY failed_at DESC LIMIT 50");

            if (empty($failed)) {
                $this->info("هیچ جابی در صف شکست (DLQ) یافت نشد.");
                return 0;
            }

            $pendingCount = 0;
            foreach ($failed as $job) {
                $status = isset($job->status) && is_string($job->status) && $job->status !== '' ? $job->status : 'failed';
                if ($status !== 'processing') {
                    $pendingCount++;
                }
                $this->line("ID: {$job->id} | Queue: {$job->queue} | Status: {$status} | Failed at: {$job->failed_at}");
            }
            $this->info("تعداد " . count($failed) . " جاب شکست خورده اخیر ({$pendingCount} آمادهٔ بازصف، بقیه processing/in-flight):");
            return 0;
        } catch (\Throwable $e) {
            $this->error("خطا در واکشی لیست: جزئیات در لاگ‌ها ثبت شد.");
            $this->logger->error('queue.failed.list.error', ['error' => $e->getMessage()]);
            return 1;
        }
    }

    /**
     * اجرای مجدد یک جاب خاص بر اساس شناسه
     *
     * FIX-P3-CMD-081: کد خروج int (موفق ۰ / ناموفق ۱).
     */
    public function retry(int $id): int
    {
        $this->info("در حال تلاش مجدد برای جاب #{$id}...");

        if ($this->processRetry($id)) {
            $this->info("جاب با موفقیت به صف اصلی بازگشت و از لیست خطاها حذف شد.");
            return 0;
        }
        $this->error("عملیات شکست خورد. گزارش‌های سیستم (Logs) را بررسی کنید.");
        return 1;
    }

    /**
     * حذف یک جاب از لیست شکست‌ها (بدون اجرای مجدد)
     *
     * FIX-CMD077 (یافتهٔ ۰۷۷): ردیف in-flight (claim ورکر/آدمین با status='processing')
     * حذف نمی‌شود و حذف واقعی پس از آرشیو در dlq_archive انجام می‌شود
     * (حذف بدون آرشیو = Data Loss نهایی payload — هم‌سو با FIX-C97/FIX-C132).
     *
     * FIX-P3-CMD-081: کد خروج int — حذف‌نشدن/خطا ۱ برمی‌گرداند.
     */
    public function forget(int $id): int
    {
        try {
            $this->db->beginTransaction();
            $this->db->execute(
                "INSERT INTO dlq_archive
                 (original_failed_job_id, queue, job_class, payload, exception, failed_at, archive_reason, archived_by)
                 SELECT id, queue, NULL, payload, exception, failed_at, 'manual_forget', 'queue_failed_command'
                 FROM failed_jobs
                 WHERE id = ? AND (status IS NULL OR status <> 'processing')",
                [$id]
            );
            $deleted = $this->db->execute(
                "DELETE FROM failed_jobs WHERE id = ? AND (status IS NULL OR status <> 'processing')",
                [$id]
            );
            $this->db->commit();
            if (is_int($deleted) && $deleted > 0) {
                $this->info("جاب #{$id} پس از آرشیو با موفقیت پاکسازی شد.");
                return 0;
            }
            $this->line("جاب #{$id} حذف نشد — یا وجود ندارد یا در حال پردازش (claim فعال) است.");
            return 1;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            $this->error("خطا در پاکسازی: جزئیات در لاگ‌ها ثبت شد.");
            $this->logger->error('queue.failed.forget.error', ['id' => $id, 'error' => $e->getMessage()]);
            return 1;
        }
    }

    /**
     * اجرای مجدد تمام جاب‌های شکست خورده به صورت دسته‌ای
     *
     * FIX-R36-W3 (F-A19e-12): بازپخش انبوه (تا ۱۰۰۰ جاب) بدون هیچ گاردی به صف زنده
     * تزریق می‌شد — شامل جاب‌های با خطای قطعی (Validation/Business/...) که بازپخششان
     * فقط چرنِ DLQ می‌سازد. اکنون: بدون --force فقط پیش‌نمایش شمارش چاپ می‌شود؛
     * اجرای واقعی نیازمند پرچم صریح --force است (سازگار با CLI غیرتعاملی).
     *
     * FIX-P3-CMD-082 (یافتهٔ ۰۸۲): حلقهٔ drain — ‎--drain تا خالی‌شدن DLQ ادامه می‌دهد
     * (سقف امن ۱۰۰ دور × ۱۰۰۰ = ۱۰۰هزار جاب در هر اجرا)؛ بدون ‎--drain یک بچ ۱۰۰۰تایی
     * مثل قبل + راهنمای صریح برای backlog بزرگ‌تر.
     *
     * FIX-P3-CMD-081: کد خروج int — خطای stats/استثنا ۱ برمی‌گرداند.
     */
    public function replayAll(bool $force = false, bool $drain = false): int
    {
        try {
            $pendingCount = (int)$this->db->fetchColumn(
                "SELECT COUNT(*) FROM failed_jobs WHERE status <> 'processing'"
            );
            if ($pendingCount === 0) {
                $this->info("هیچ جابی در صف شکست (DLQ) برای بازپخش وجود ندارد.");
                return 0;
            }
            if (!$force) {
                $this->line("بازپخش انبوه {$pendingCount} جاب شکست‌خورده به صف زنده بدون تایید انجام نمی‌شود (F-A19e-12).");
                $this->line("برای اجرای واقعی پرچم صریح بدهید: php cli.php queue:failed replay --force");
                $this->line("(برای بازپخش انتخابی/فیلترشده از dlq:retry با --exclude-fatal و --exception= استفاده کنید.)");
                return 0;
            }

            $maxRounds = 100;
            $round = 0;
            $totalRequeued = 0;
            $totalErrors = 0;
            $totalSkipped = 0;
            $this->line("بازپخش انبوه {$pendingCount} جاب شکست‌خورده با --force شروع شد..." . ($drain ? ' (drain mode)' : ''));

            do {
                $stats = $this->queue->retryFailedJobsBatch(null, 1000);
                $requeued = int_value($stats['requeued'] ?? 0);
                $totalRequeued += $requeued;
                $totalErrors += int_value($stats['errors'] ?? 0);
                $totalSkipped += int_value($stats['skipped'] ?? 0);
                $round++;
                // FIX-P3-CMD-082: ادامه فقط در حالت drain و تا وقتی بچ «پُر» برگشته —
                // بچِ ناتمام یعنی DLQ زیر سقف بچ خالی شده؛ دور اضافه نزنیم.
                $lastBatchFull = ($requeued >= 1000);
            } while ($drain && $lastBatchFull && $round < $maxRounds);

            $this->info("عملیات پایان یافت (rounds={$round}): {$totalRequeued} موفق، {$totalErrors} خطا و {$totalSkipped} نادیده گرفته شد.");
            if (!$drain && $totalRequeued >= 1000) {
                $this->line("بازپخش تا سقف ۱۰۰۰ جاب در یک اجرا انجام شد؛ برای backlog بزرگ‌تر مجدداً اجرا کنید یا ‎--drain بدهید.");
            }
            return $totalErrors > 0 ? 1 : 0;
        } catch (\Throwable $e) {
            $this->error("خطای کلی در Replay: جزئیات در لاگ‌ها ثبت شد.");
            $this->logger->error('queue.failed.replay.error', ['error' => $e->getMessage()]);
            return 1;
        }
    }

    /**
     * منطق اتمیک انتقال جاب از DLQ به صف اصلی
     *
     * FIX-C127: هماهنگ با الگوی اصلاح‌شدهٔ DLQRetryCommand —
     *  (۱) allowlist مشترک QueueWorker::isJobAllowed() قبل از push (کلاس خارج از
     *      allowlist هرگز وارد صف زنده نمی‌شود)؛
     *  (۲) حذف با گارد status تا ردیف claim‌شده توسط ورکر DLQ (status='processing')
     *      دوباره‌صف نشود (رقابت دو مسیر → جاب دوبله)؛
     *
     * FIX-CMD075/CMD076 (یافته‌های ۰۷۵ و ۰۷۶): الگوی claim-first —
     *  (الف) SELECT گارددار دیگر حصار نیست (check-then-act)؛ claim با UPDATE
     *      اتمیک به status='processing' انجام می‌شود و دو replay هم‌زمان/ورکر
     *      فقط یکی می‌تواند برنده شود؛
     *  (ب) push (اثر جانبی خارجی در درایور redis) دیگر داخل تراکنش DB نیست —
     *      rollback بعد از push موفقِ redis قبلاً جاب دوبله می‌ساخت. ترتیب جدید:
     *      claim → push → حذف گارددارِ مالکیت claim. crash بعد از push ردیف را
     *      processing (نشان in-flight) نگه می‌دارد و هیچ منبع retry دوباره push نمی‌کند.
     */
    private function processRetry(int $id): bool
    {
        // ردیف رزروشده توسط ورکر DLQ (status='processing') و قرنطینه از مسیر دستی ادمین مستثنی‌اند
        $job = $this->db->query(
            "SELECT * FROM failed_jobs WHERE id = ? AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
            [$id]
        )->fetch(\PDO::FETCH_OBJ);

        if (!is_object($job)) {
            $this->logger->warning('queue.retry.not_found', ['id' => $id]);
            return false;
        }
        $jobData = get_object_vars($job);

        // claim اتمیک — حصار واقعی در برابر ورکر و replayهای موازی
        $claimed = $this->db->execute(
            "UPDATE failed_jobs SET status = 'processing'
             WHERE id = ? AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
            [$id]
        );
        if (!is_int($claimed) || $claimed === 0) {
            $this->logger->warning('queue.retry.lost_claim', ['id' => $id]);
            return false;
        }

        $releaseClaim = function () use ($id): void {
            try {
                $this->db->execute(
                    "UPDATE failed_jobs SET status = 'retry_pending' WHERE id = ? AND status = 'processing'",
                    [$id]
                );
            } catch (\Throwable $e) {
                $this->logger->warning('queue.retry.claim_release_failed', ['id' => $id, 'error' => $e->getMessage()]);
            }
        };

        try {
            $payloadRaw = $jobData['payload'] ?? null;
            $payload = is_string($payloadRaw) ? json_decode($payloadRaw, true) : null;
            if (!is_array($payload) || !is_string($payload['job'] ?? null) || $payload['job'] === '') {
                $releaseClaim();
                $this->logger->warning('queue.retry.invalid_payload', ['id' => $id]);
                return false;
            }

            // FIX-C127 (یافتهٔ ۱۲۷): allowlist مشترک قبل از push — یکسان با مسیر
            // اصلاح‌شدهٔ dlq:retry؛ کلاس خارج از allowlist وارد صف زنده نمی‌شود.
            $jobClass = (string)$payload['job'];
            if (!\App\Services\QueueWorker::isJobAllowed($jobClass)) {
                $releaseClaim();
                $this->logger->warning('queue.retry.job_not_allowed', ['id' => $id, 'job_class' => $jobClass]);
                return false;
            }

            // درج در سیستم صف واقعی (چه دیتابیس باشد چه ردیس) — بیرون از تراکنش
            $success = $this->queue->push(
                $jobClass,
                (array)($payload['data'] ?? []),
                is_string($jobData['queue'] ?? null) && $jobData['queue'] !== '' ? $jobData['queue'] : 'default'
            );

            if (!$success) {
                $releaseClaim();
                return false;
            }

            // حذف فقط با گاردِ مالکیتِ claim خودمان (status='processing')
            $deleted = $this->db->execute(
                "DELETE FROM failed_jobs WHERE id = ? AND status = 'processing'",
                [$id]
            );
            if (is_int($deleted) && $deleted === 0) {
                // push انجام شد ولی claim بین‌راه از دست رفت (at-least-once؛
                // ایدمپوتنسی جاب‌ها اجرای مضاعف را بی‌اثر می‌کند) — شفاف لاگ می‌شود.
                $this->logger->warning('queue.retry.lost_claim_after_push', ['id' => $id]);
                return false;
            }

            $this->logger->info('queue.retry.success', ['id' => $id, 'queue' => $jobData['queue'] ?? 'default']);
            return true;
        } catch (\Throwable $e) {
            $releaseClaim();
            $this->logger->error('queue.retry.failed', ['id' => $id, 'error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * FIX-P3-CMD-081 (یافتهٔ ۰۸۱): run() کد خروج int برمی‌گرداند — قبلاً void بود و
     * شکست‌های runtime (list/retry/forget/replay) همیشه exit 0 می‌گرفتند؛ dispatcher
     * (FIX-C141) return int را به کد خروج نگاشت می‌کند.
     *
     * @param list<mixed> $args
     */
    public function run(array $args = []): int
    {
        $subAction = $args[0] ?? 'list';
        if (!is_string($subAction)) {
            $this->usageError('Unknown queue sub-action.');
        }

        switch ($subAction) {
            case 'list':
                return $this->list();
            case 'retry':
                return $this->retry($this->requiredPositiveId($args, 1, 'Usage: php cli.php queue:failed retry <job_id>'));
            case 'forget':
                return $this->forget($this->requiredPositiveId($args, 1, 'Usage: php cli.php queue:failed forget <job_id>'));
            case 'replay':
                // FIX-R36-W3 (F-A19e-12): بدون --force فقط پیش‌نمایش؛ اجرای واقعی صریح است
                // FIX-P3-CMD-082: ‎--drain حلقه تا خالی‌شدن DLQ
                return $this->replayAll(
                    in_array('--force', $args, true),
                    in_array('--drain', $args, true)
                );
            default:
                $this->error("Unknown sub-action: {$subAction}");
                $this->line("Available: list, retry <id>, forget <id>, replay [--drain]");
                return 1;
        }
    }

    /** @param list<mixed> $args */
    private function requiredPositiveId(array $args, int $index, string $usage): int
    {
        $rawId = $args[$index] ?? null;
        $id = is_string($rawId) ? filter_var($rawId, FILTER_VALIDATE_INT) : false;
        if (!is_int($id) || $id <= 0) {
            $this->usageError($usage);
        }
        return $id;
    }

    private function usageError(string $message): never
    {
        $this->error($message);
        exit(1);
    }
}