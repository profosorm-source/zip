<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Services\AntiFraud\ReputationSignalService;

/**
 * 🛡️ FIX-R69 — بک‌فیل یک‌بارهٔ سیگنال مستقل شهرت (پالایش ۴).
 *
 * سیگنال شهرت رویدادمحور است (بعد از تسویه/اخلاف بازمحاسبه می‌شود)؛ این
 * فرمان ردیف اولیه را برای همهٔ کاربران موجود می‌سازد. idempotent است —
 * اجرای مجدد همان مقادیر قطعی را بازمی‌نویسد؛ برای کاربر تازه تا اولین
 * رویداد، عامل شهرت در موتور خنثی می‌ماند (قرارداد R60-A5-4).
 *
 * Usage:
 *   php cli.php reputation:backfill
 *   php cli.php reputation:backfill --batch=1000
 */
final class ReputationBackfillCommand
{
    private ReputationSignalService $service;
    private LoggerInterface $logger;

    public function __construct(
        ReputationSignalService $service,
        LoggerInterface $logger
    ) {
        $this->service = $service;
        $this->logger = $logger;
    }

    /** @param array<int|string, mixed> $argv */
    public function run(array $argv = []): int
    {
        $batch = 500;
        foreach ($argv as $arg) {
            if (is_string($arg) && str_starts_with($arg, '--batch=')) {
                $batch = (int)substr($arg, 8);
            }
        }
        if ($batch < 10) {
            $batch = 10;
        }

        echo "[reputation:backfill] starting (batch={$batch})...\n";
        try {
            $result = $this->service->backfill($batch);
        } catch (\Throwable $e) {
            $this->logger->error('reputation.backfill_command_failed', [
                'error' => $e->getMessage(),
            ]);
            echo "[reputation:backfill] FAILED: " . $e->getMessage() . "\n";
            return 1;
        }

        echo "[reputation:backfill] completed: processed={$result['processed']}, failed={$result['failed']}\n";
        // FIX-C141: شکست‌های جزئی را با کد خروج گزارش می‌کنیم تا cron/CI بتواند گیت کند.
        return $result['failed'] > 0 ? 2 : 0;
    }
}
