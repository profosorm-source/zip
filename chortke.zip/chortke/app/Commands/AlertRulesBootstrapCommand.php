<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Command;
use Core\Database;
use Core\Logger;

/**
 * 🚀 AlertRulesBootstrapCommand - رجسٹر کردن DLQ Alert Rule
 * 
 * این کمند DLQ alert rule را درج می‌کند:
 * - failed_jobs > 50 => CRITICAL alert
 * - failed_jobs > 20 => WARNING alert
 */
class AlertRulesBootstrapCommand extends Command
{
    private Database $db;
    private Logger $logger;

    public function __construct(Database $db, Logger $logger)
    {
        $this->db = $db;
        $this->logger = $logger;
    }

    public function handle(): void
    {
        $this->registerDLQAlertRules();
        $this->registerDatabaseAlertRules();
        $this->line('✅ DLQ + Database Alert Rules Registered');
    }

    private function registerDLQAlertRules(): void
    {
        // چک کنید آیا rule وجود دارد
        $existing = $this->db->fetchColumn(
            "SELECT id FROM alert_rules WHERE rule_name = ?",
            ['DLQ Failed Jobs Critical']
        );

        if ($existing) {
            return; // Rule تالاً موجود است
        }

        // Critical Rule: failed_jobs > 50
        $this->db->table('alert_rules')->insert([
            'rule_name' => 'DLQ Failed Jobs Critical',
            'rule_type' => 'queue_dlq',
            'condition' => json_encode([
                'metric' => 'failed_jobs',
                'operator' => '>',
            ], JSON_UNESCAPED_UNICODE),
            'threshold' => 50,
            'severity' => 'critical',
            'time_window' => 5, // 5 minutes
            'is_active' => 1,
            'description' => 'تعداد failed jobs بیش از 50 است',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // Warning Rule: failed_jobs > 20
        $this->db->table('alert_rules')->insert([
            'rule_name' => 'DLQ Failed Jobs Warning',
            'rule_type' => 'queue_dlq',
            'condition' => json_encode([
                'metric' => 'failed_jobs',
                'operator' => '>',
            ], JSON_UNESCAPED_UNICODE),
            'threshold' => 20,
            'severity' => 'warning',
            'time_window' => 5,
            'is_active' => 1,
            'description' => 'تعداد failed jobs بیش از 20 است',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $this->logger->info('alert_rules.dlq_bootstrap', [
            'message' => 'DLQ alert rules registered',
            'critical_threshold' => 50,
            'warning_threshold' => 20,
        ]);
    }

    private function registerDatabaseAlertRules(): void
    {
        $existing = $this->db->fetchColumn(
            "SELECT id FROM alert_rules WHERE rule_name = ?",
            ['DB Slow Queries Critical']
        );
        if ($existing) return;

        // Critical: slow queries > 50
        $this->db->table('alert_rules')->insert([
            'rule_name'   => 'DB Slow Queries Critical',
            'rule_type'   => 'database_performance',
            'condition'   => json_encode(['metric' => 'slow_queries', 'operator' => '>'], JSON_UNESCAPED_UNICODE),
            'threshold'   => 50,
            'severity'    => 'critical',
            'time_window' => 15,
            'is_active'   => 0,
            'description' => 'تعداد کوئری‌های کند دیتابیس بیش از ۵۰ مورد',
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        // Warning: slow queries > 20
        $this->db->table('alert_rules')->insert([
            'rule_name'   => 'DB Slow Queries Warning',
            'rule_type'   => 'database_performance',
            'condition'   => json_encode(['metric' => 'slow_queries', 'operator' => '>'], JSON_UNESCAPED_UNICODE),
            'threshold'   => 20,
            'severity'    => 'warning',
            'time_window' => 15,
            'is_active'   => 0,
            'description' => 'تعداد کوئری‌های کند دیتابیس بیش از ۲۰ مورد',
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        // Warning: deadlocks > 0
        $this->db->table('alert_rules')->insert([
            'rule_name'   => 'DB Deadlocks Detected',
            'rule_type'   => 'database_performance',
            'condition'   => json_encode(['metric' => 'deadlocks', 'operator' => '>'], JSON_UNESCAPED_UNICODE),
            'threshold'   => 0,
            'severity'    => 'warning',
            'time_window' => 10,
            'is_active'   => 0,
            'description' => 'بن‌بست (Deadlock) در دیتابیس شناسایی شد',
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        // Warning: missing indexes
        $this->db->table('alert_rules')->insert([
            'rule_name'   => 'DB Missing Index Recommendations',
            'rule_type'   => 'database_performance',
            'condition'   => json_encode(['metric' => 'missing_indexes', 'operator' => '>'], JSON_UNESCAPED_UNICODE),
            'threshold'   => 5,
            'severity'    => 'info',
            'time_window' => 1440,
            'is_active'   => 0,
            'description' => 'بیش از ۵ جدول نیاز به ایندکس جدید دارند',
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        $this->logger->info('alert_rules.database_bootstrap', [
            'message' => 'Database alert rules registered (inactive by default)',
        ]);
    }

    public function run(array $args = []): void
    {
        $this->handle();
    }
}
