<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Command;
use Core\Database;
use Core\Logger;

/**
 * 🚀 AlertRulesBootstrapCommand - ثبت قواعد هشدار پایه (Sentry Alert Rules)
 *
 * FIX-S27B-F1: نگارش قبلی با ستون‌های شبح alert_rules (rule_type/threshold/
 * time_window/description — هیچ‌کدام در شمای واقعی وجود خارجی ندارند) INSERT
 * می‌زد → یا SQL error یا ثبت ردیف‌های تهی، و پیام «✅ Registered» چاپ می‌کرد.
 * اکنون با ستون‌های واقعی نوشته می‌شود:
 *   rule_name / condition(JSON: metric+operator) / threshold_value /
 *   time_window_minutes / severity / is_active / created_at
 * و فقط قواعدی که متریک‌شان در رجیستری واقعی SentryModel::getMetricValue
 * وجود دارد ثبت می‌شوند (قواعد «deadlocks» و «missing_indexes» که متریک‌شان
 * هیچ‌گاه عدد واقعی نمی‌گرفت و قاعدهٔ slow_queries که نام غلط داشت — حذف/
 * اصلاح شدند تا «پوشش ادعایی» نسازیم).
 */
class AlertRulesBootstrapCommand extends Command
{
    private Database $db;
    private Logger $logger;

    public function __construct(Database $db, Logger $logger) {
        $this->db = $db;
        $this->logger = $logger;
    }

    public function handle(): void
    {
        // FIX-C117 (یافتهٔ ۱۱۷): کل bootstrap در یک تراکنش — شکست وسط کار
        // مجموعه‌ای ناقص از قوانین باقی نمی‌گذارد (rollback کامل).
        // FIX-C116 (یافتهٔ ۱۱۶): race ثبت هم‌زمان با قید UNIQUE (rule_name) در
        // DB + INSERT ... ON DUPLICATE KEY UPDATE بسته می‌شود.
        $this->db->transactional(function (): void {
            $this->upsertRule('DLQ Failed Jobs Critical', 'failed_jobs', '>', 50, 'critical', 5, 'تعداد failed jobs بیش از 50 است', true);
            $this->upsertRule('DLQ Failed Jobs Warning', 'failed_jobs', '>', 20, 'warning', 5, 'تعداد failed jobs بیش از 20 است', true);

            // متریک واقعی رجیستری: db_slow_queries (پیش‌تر «slow_queries» ناموجود بود)
            $this->upsertRule('DB Slow Queries Critical', 'db_slow_queries', '>', 50, 'critical', 15, 'تعداد کوئری‌های کند دیتابیس بیش از ۵۰ مورد', false);
            $this->upsertRule('DB Slow Queries Warning', 'db_slow_queries', '>', 20, 'warning', 15, 'تعداد کوئری‌های کند دیتابیس بیش از ۲۰ مورد', false);

            $this->upsertRule('Wallet Ledger Mismatch Critical', 'wallet_anomalies', '>', 1, 'critical', 10, 'عدم تطابق موجودی wallet با ledger شناسایی شد', true);
            $this->upsertRule('Payment Failures High', 'payment_failures', '>', 10, 'high', 15, 'بیش از ۱۰ پرداخت ناموفق در ۱۵ دقیقه اخیر', true);
            $this->upsertRule('Payment Failures Warning', 'payment_failures', '>', 5, 'warning', 15, 'بیش از ۵ پرداخت ناموفق در ۱۵ دقیقه اخیر', true);

            $this->upsertRule('Brute Force Login Critical', 'failed_login', '>', 50, 'critical', 5, 'بیش از ۵۰ تلاش ناموفق ورود در ۵ دقیقه — احتمال Brute Force', true);
            $this->upsertRule('Brute Force Login Warning', 'failed_login', '>', 20, 'warning', 5, 'بیش از ۲۰ تلاش ناموفق ورود در ۵ دقیقه', true);
            $this->upsertRule('Suspicious IPs Alert', 'suspicious_ips', '>', 5, 'high', 15, 'بیش از ۵ IP مشکوک (Tor/VPN/Proxy) در ۱۵ دقیقه', true);

            $this->upsertRule('Stuck Sagas Critical', 'stuck_sagas', '>', 0, 'critical', 30, 'Saga(های) گیر کرده بیش از ۳۰ دقیقه — نیاز به بررسی فوری', true);
            $this->upsertRule('High Risk Users Spike', 'fraud_score_high', '>', 10, 'high', 60, 'بیش از ۱۰ کاربر با امتیاز ریسک بالا (≥۷۵) در یک ساعت اخیر', true);
        });

        $this->line('✅ DLQ + Database + Financial + Security + Saga + Fraud Alert Rules Registered');
    }

    /**
     * ثبت idempotent یک قاعده با ستون‌های واقعی alert_rules (سبک PUT).
     * FIX-C116: INSERT ... ON DUPLICATE KEY UPDATE — race دو اجرای هم‌زمان
     * دیگر ردیف تکراری نمی‌سازد (قید UNIQUE در مایگریشن 2026_09_28_0002).
     * FIX-C118 (یافتهٔ ۱۱۸): description در DB ذخیره می‌شود (قبلاً فقط لاگ می‌شد
     * و توضیح مدیریتی هر بار گم می‌شد).
     */
    private function upsertRule(string $name, string $metric, string $operator, float $threshold, string $severity, int $windowMinutes, string $description, bool $active): void
    {
        $condition = json_encode(['metric' => $metric, 'operator' => $operator], JSON_UNESCAPED_UNICODE);

        $this->db->execute(
            "INSERT INTO alert_rules
             (rule_name, `condition`, threshold_value, time_window_minutes, severity, is_active, created_at, description)
             VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)
             ON DUPLICATE KEY UPDATE
                `condition` = VALUES(`condition`),
                threshold_value = VALUES(threshold_value),
                time_window_minutes = VALUES(time_window_minutes),
                severity = VALUES(severity),
                is_active = VALUES(is_active),
                description = VALUES(description)",
            [$name, $condition, $threshold, $windowMinutes, $severity, $active ? 1 : 0, $description]
        );
        $this->logger->info('alert_rules.registered', [
            'rule_name' => $name, 'metric' => $metric, 'description' => $description,
        ]);
    }

    /** @param array<string, mixed> $args */

    public function run(array $args = []): void
    {
        $this->handle();
    }
}
