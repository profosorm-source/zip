<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Command;
use Core\Database;
use Core\Logger;

/**
 * 🚀 AlertRulesBootstrapCommand - ثبت قواعد هشدار پایه (Sentry Alert Rules)
 *
 * FIX-S27B-F1: نگارش قبلی با ستون‌های شبح alert_rules (rule_type/threshold/
 * time_window/description — هیچ‌کدام در شمای واقعی وجود خارجی ندارند) INSERT
 * می‌زد → یا SQL error یا ثبت ردیف‌های تهی، و پیام «✅ Registered» چاپ می‌کرد.
 * اکنون با ستون‌های واقعی نوشته می‌شود:
 *   rule_name / condition(JSON: metric+operator) / threshold_value /
 *   time_window_minutes / severity / is_active / created_at
 * و فقط قواعدی که متریک‌شان در رجیستری واقعی SentryModel::getMetricValue
 * وجود دارد ثبت می‌شوند (قواعد «deadlocks» و «missing_indexes» که متریک‌شان
 * هیچ‌گاه عدد واقعی نمی‌گرفت و قاعدهٔ slow_queries که نام غلط داشت — حذف/
 * اصلاح شدند تا «پوشش ادعایی» نسازیم).
 */
class AlertRulesBootstrapCommand extends Command
{
    private Database $db;
    private Logger $logger;

    public function __construct(Database $db, Logger $logger) {
        $this->db = $db;
        $this->logger = $logger;
    }

    public function handle(): void
    {
        $this->upsertRule('DLQ Failed Jobs Critical', 'failed_jobs', '>', 50, 'critical', 5, 'تعداد failed jobs بیش از 50 است', true);
        $this->upsertRule('DLQ Failed Jobs Warning', 'failed_jobs', '>', 20, 'warning', 5, 'تعداد failed jobs بیش از 20 است', true);

        // متریک واقعی رجیستری: db_slow_queries (پیش‌تر «slow_queries» ناموجود بود)
        $this->upsertRule('DB Slow Queries Critical', 'db_slow_queries', '>', 50, 'critical', 15, 'تعداد کوئری‌های کند دیتابیس بیش از ۵۰ مورد', false);
        $this->upsertRule('DB Slow Queries Warning', 'db_slow_queries', '>', 20, 'warning', 15, 'تعداد کوئری‌های کند دیتابیس بیش از ۲۰ مورد', false);

        $this->upsertRule('Wallet Ledger Mismatch Critical', 'wallet_anomalies', '>', 1, 'critical', 10, 'عدم تطابق موجودی wallet با ledger شناسایی شد', true);
        $this->upsertRule('Payment Failures High', 'payment_failures', '>', 10, 'high', 15, 'بیش از ۱۰ پرداخت ناموفق در ۱۵ دقیقه اخیر', true);
        $this->upsertRule('Payment Failures Warning', 'payment_failures', '>', 5, 'warning', 15, 'بیش از ۵ پرداخت ناموفق در ۱۵ دقیقه اخیر', true);

        $this->upsertRule('Brute Force Login Critical', 'failed_login', '>', 50, 'critical', 5, 'بیش از ۵۰ تلاش ناموفق ورود در ۵ دقیقه — احتمال Brute Force', true);
        $this->upsertRule('Brute Force Login Warning', 'failed_login', '>', 20, 'warning', 5, 'بیش از ۲۰ تلاش ناموفق ورود در ۵ دقیقه', true);
        $this->upsertRule('Suspicious IPs Alert', 'suspicious_ips', '>', 5, 'high', 15, 'بیش از ۵ IP مشکوک (Tor/VPN/Proxy) در ۱۵ دقیقه', true);

        $this->upsertRule('Stuck Sagas Critical', 'stuck_sagas', '>', 0, 'critical', 30, 'Saga(های) گیر کرده بیش از ۳۰ دقیقه — نیاز به بررسی فوری', true);
        $this->upsertRule('High Risk Users Spike', 'fraud_score_high', '>', 10, 'high', 60, 'بیش از ۱۰ کاربر با امتیاز ریسک بالا (≥۷۵) در یک ساعت اخیر', true);

        $this->line('✅ DLQ + Database + Financial + Security + Saga + Fraud Alert Rules Registered');
    }

    /**
     * ثبت idempotent یک قاعده با ستون‌های واقعی alert_rules (سبک PUT: اگر
     * rule_name موجود است، مقادیر عملیاتی به‌روزرسانی می‌شوند تا bootstrap
     * همیشه با پیکربندی درست هم‌خوان باشد).
     */
    private function upsertRule(string $name, string $metric, string $operator, float $threshold, string $severity, int $windowMinutes, string $description, bool $active): void
    {
        $condition = json_encode(['metric' => $metric, 'operator' => $operator], JSON_UNESCAPED_UNICODE);

        $existing = $this->db->fetchColumn(
            "SELECT id FROM alert_rules WHERE rule_name = ?",
            [$name]
        );

        if ($existing) {
            $this->db->execute(
                "UPDATE alert_rules
                 SET `condition` = ?, threshold_value = ?, time_window_minutes = ?, severity = ?, is_active = ?
                 WHERE rule_name = ?",
                [$condition, $threshold, $windowMinutes, $severity, $active ? 1 : 0, $name]
            );
            $this->logger->info('alert_rules.updated', ['rule_name' => $name, 'metric' => $metric]);
            return;
        }

        $this->db->table('alert_rules')->insert([
            'rule_name'           => $name,
            'condition'           => $condition,
            'threshold_value'     => $threshold,
            'time_window_minutes' => $windowMinutes,
            'severity'            => $severity,
            'is_active'           => $active ? 1 : 0,
            'created_at'          => date('Y-m-d H:i:s'),
        ]);
        $this->logger->info('alert_rules.registered', [
            'rule_name' => $name, 'metric' => $metric, 'description' => $description,
        ]);
    }

    /** @param array<string, mixed> $args */

    public function run(array $args = []): void
    {
        $this->handle();
    }
}
