<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\DlqWorker;
use App\Contracts\LoggerInterface;
use Core\Cache;
use Core\CircuitBreaker;
use Core\Exceptions\CircuitBreakerOpenException;

/**
 * CLI command daemon to run the DlqWorker and process dead letter jobs.
 *
 * Usage:
 *   php cli.php dlq:work [--limit=10] [--sleep=10]
 *
 * حالت پیش‌فرض تک‌مرحله‌ای است (تست/cron)؛ با --sleep=N به حلقهٔ دائمی
 * supervisor تبدیل می‌شود و بین نظرسنجی‌های خالی sleep می‌کند.
 */
class DlqWorkCommand
{
    private DlqWorker $worker;
    private LoggerInterface $logger;
    private ?CircuitBreaker $circuitBreaker;
    /** FIX-P3-CMD-037: کش اختیاری برای قفل اجرای سطح command (تست‌ها بدون کش). */
    private ?Cache $cache;
    private ?string $runLockKey = null;

    public function __construct(
        DlqWorker $worker,
        LoggerInterface $logger,
        ?CircuitBreaker $circuitBreaker = null,
        ?Cache $cache = null
    ) {        $this->worker = $worker;
        $this->logger = $logger;
        $this->circuitBreaker = $circuitBreaker;
        $this->cache = $cache;
}

    /**
     * Executes the CLI command.
     */
    /**
     * @param array<string, mixed> $argv
     * @return array<string, mixed>
     */
    public function run(array $argv = []): array
    {
        $limit = 10;
        $sleep = null;

        foreach ($argv as $arg) {
            if (is_string($arg)) {
                if (str_starts_with($arg, '--limit=')) {
                    $limit = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--sleep=')) {
                    $sleep = (int)substr($arg, 8);
                }
            }
        }

        // Validate range limits
        $limit = max(1, min(500, $limit));
        $sleep = ($sleep === null) ? null : max(1, min(300, $sleep));

        // FIX-P3-CMD-037 (یافتهٔ ۰۳۷): قفل اجرای سطح command — claim اتمیک لایهٔ صف
        // جاب دوبله نمی‌سازد، اما دو instance موازی هر دو poll می‌کنند و لاگ/CPU
        // دوبله می‌شود. قفل Redis nx/ex اجرای موازی را حذف می‌کند؛ بدون کش fail-open
        // است (لایهٔ claim همچنان صحت را تضمین می‌کند — مستند در docblock).
        if ($sleep !== null) {
            $skip = $this->skipIfLocked(3600);
            if ($skip !== null) {
                return $skip;
            }
            try {
                return $this->runDaemonLoop($limit, $sleep);
            } finally {
                $this->releaseRunLock($this->runLockKey);
                $this->runLockKey = null;
            }
        }

        $skip = $this->skipIfLocked(300);
        if ($skip !== null) {
            return $skip;
        }

        $this->logger->info('dlq.command.work.starting', [
            'limit' => $limit
        ]);

        try {
            $result = $this->worker->work($limit);
            $processed = int_value($result['processed'] ?? 0);
            $compensated = int_value($result['compensated'] ?? 0);
            $archived = int_value($result['archived'] ?? 0);

            $this->logger->info('dlq.command.work.completed', [
                'processed' => $processed,
                'compensated' => $compensated,
                'archived' => $archived
            ]);

            echo "[dlq:work] processed={$processed} compensated={$compensated} archived={$archived} (limit={$limit})\n";

            return [
                'processed' => $processed,
                'compensated' => $compensated,
                'archived' => $archived
            ];
        } catch (\Throwable $e) {
            $this->logger->error('dlq.command.work.failed', [
                'error' => $e->getMessage()
            ]);
            // FIX (یافتهٔ ۱۲۵): پیام خام استثنا (SQL/DSN) به stderr operator نمی‌رود
            fwrite(STDERR, "[dlq:work] error: dlq work failed (details in logs)\n");
            // FIX-C141: شکست با exit_code صریح به dispatcher اعلام می‌شود
            return [
                'processed' => 0,
                'compensated' => 0,
                'archived' => 0,
                'error' => $e->getMessage(),
                'exit_code' => 1,
            ];
        } finally {
            // FIX-P3-CMD-037: آزادسازی قفل در خروج عادی و خطا
            $this->releaseRunLock($this->runLockKey);
            $this->runLockKey = null;
        }
    }

    /**
     * حلقهٔ دیمن برای supervisor (dlq:work --limit=50 --sleep=10) —
     * بدون این حلقه، کامند بلافاصله خارج می‌شود و supervisor پس از ری‌استارت‌های
     * سریع (startretries=10) برنامه را FATAL می‌کند و پردازش DLQ متوقف می‌شود.
     *
     * @return array<string, mixed>
     */
    private function runDaemonLoop(int $limit, int $sleep): array
    {
        $this->logger->info('dlq.command.work.daemon_starting', [
            'limit' => $limit,
            'sleep' => $sleep
        ]);

        $totals = ['processed' => 0, 'compensated' => 0, 'archived' => 0];
        // FIX-C142: شمارندهٔ شکست‌های متوالی برای backoff نمایی (سقف ۶۰ ثانیه)
        $consecutiveFailures = 0;

        while (!$this->worker->shouldQuit()) {
            try {
                // FIX-C142 (یافتهٔ ۱۴۲): circuit breaker دور work() — هم‌سو با
                // queue:work؛ fail-open breaker (خاموشی state-store = مدار بسته).
                if ($this->circuitBreaker !== null) {
                    $result = $this->circuitBreaker->call(
                        'dlq_worker',
                        fn (): array => $this->worker->work($limit)
                    );
                } else {
                    $result = $this->worker->work($limit);
                }
                $iterationProcessed = int_value($result['processed'] ?? 0);
                $totals['processed'] += $iterationProcessed;
                $totals['compensated'] += int_value($result['compensated'] ?? 0);
                $totals['archived'] += int_value($result['archived'] ?? 0);
                $consecutiveFailures = 0;

                // فقط وقتی صف مرده خالی است صبر می‌کنیم؛ در حال کار بین batch‌ها مکث نمی‌کنیم
                if ($iterationProcessed === 0) {
                    $this->interruptibleSleep($sleep);
                }
            } catch (CircuitBreakerOpenException $e) {
                $this->logger->warning('dlq.command.work.circuit_open', [
                    'service' => $e->getServiceName(),
                ]);
                $this->interruptibleSleep(min(60, max($sleep, 5)));
            } catch (\Throwable $e) {
                // FIX-C142 (یافتهٔ ۱۴۲): خطای دائمی بدون backoff → چرخهٔ بی‌نهایت؛
                // اکنون شکست‌های متوالی به‌صورت نمایی backoff می‌شوند.
                $consecutiveFailures++;
                $backoff = min(60, max($sleep, 5) * (2 ** min($consecutiveFailures, 4)));
                $this->logger->error('dlq.command.work.daemon_iteration_failed', [
                    'error' => $e->getMessage(),
                    'consecutive_failures' => $consecutiveFailures,
                    'backoff_seconds' => $backoff,
                ]);
                $this->interruptibleSleep($backoff);
            }
        }

        $this->logger->info('dlq.command.work.daemon_stopped', $totals);
        echo "[dlq:work] processed={$totals['processed']} compensated={$totals['compensated']} archived={$totals['archived']} (daemon exit)\n";

        return $totals;
    }

    /**
     * FIX-C142: خواب قابل‌وقفه با سیگنال — گام‌های ۱ثانیه‌ای با بررسی shouldQuit
     * تا SIGTERM بدون انتظار برای پایان backoff پذیرفته شود.
     */
    private function interruptibleSleep(int $seconds): void
    {
        $remaining = max(0, $seconds);
        while ($remaining > 0) {
            if ($this->worker->shouldQuit()) {
                return;
            }
            sleep(1);
            $remaining--;
        }
    }

    /**
     * FIX-P3-CMD-037 (یافتهٔ ۰۳۷): قفل اجرای سطح command (الگوی Redis nx/ex واپاشی امتیاز).
     *
     * duplicate work در لایهٔ claim اتمیک (core/Queue: FOR UPDATE SKIP LOCKED +
     * SET status='processing') جلوگیری می‌شود؛ این قفل فقط poll/لاگِ دوبلهٔ
     * دو instance موازی را حذف می‌کند. وقتی cache/redis در دسترس نیست fail-open
     * است (همان تضمین قبلیِ لایهٔ claim) و در لاگ ثبت می‌شود.
     *
     * @return array{status: string, key: ?string} status: held|busy|unavailable
     */
    private function acquireRunLock(int $ttl): array
    {
        if ($this->cache === null) {
            return ['status' => 'unavailable', 'key' => null];
        }
        try {
            $redis = $this->cache->redis();
            if (!$redis) {
                return ['status' => 'unavailable', 'key' => null];
            }
            $key = $this->cache->redisKey('dlq:work:run_lock');
            if (!$redis->set($key, (string)time(), ['nx', 'ex' => $ttl])) {
                return ['status' => 'busy', 'key' => $key];
            }
            return ['status' => 'held', 'key' => $key];
        } catch (\Throwable $e) {
            $this->logger->debug('dlq.command.work.run_lock_unavailable', ['error' => $e->getMessage()]);
            return ['status' => 'unavailable', 'key' => null];
        }
    }

    /** FIX-P3-CMD-037: آزادسازی best-effort قفل — TTL پشتیبان هم دارد. */
    private function releaseRunLock(?string $key): void
    {
        if ($key === null || $this->cache === null) {
            return;
        }
        try {
            $redis = $this->cache->redis();
            if ($redis) {
                $redis->del($key);
            }
        } catch (\Throwable $e) {
            $this->logger->debug('dlq.command.work.run_lock_release_failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * FIX-P3-CMD-037: اگر instance دیگری قفل را دارد، نتیجهٔ skip صادقانه برمی‌گردد.
     *
     * @return array<string, mixed>|null null = ادامهٔ اجرا مجاز است
     */
    private function skipIfLocked(int $ttl): ?array
    {
        $lock = $this->acquireRunLock($ttl);
        if ($lock['status'] === 'held') {
            $this->runLockKey = $lock['key'];
            return null;
        }
        if ($lock['status'] === 'busy') {
            $this->logger->info('dlq.command.work.skipped_lock_busy', []);
            echo "[dlq:work] skipped: another dlq:work instance holds the run lock\n";
            return [
                'processed' => 0,
                'compensated' => 0,
                'archived' => 0,
                'skipped' => 'lock_busy',
            ];
        }
        return null; // fail-open مستند — لایهٔ claim جاب دوبله نمی‌سازد
    }
}
