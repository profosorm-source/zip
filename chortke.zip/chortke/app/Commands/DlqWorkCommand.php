<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\DlqWorker;
use App\Contracts\LoggerInterface;

/**
 * CLI command daemon to run the DlqWorker and process dead letter jobs.
 *
 * Usage:
 *   php cli.php dlq:work [--limit=10] [--sleep=10]
 *
 * حالت پیش‌فرض تک‌مرحله‌ای است (تست/cron)؛ با --sleep=N به حلقهٔ دائمی
 * supervisor تبدیل می‌شود و بین نظرسنجی‌های خالی sleep می‌کند.
 */
class DlqWorkCommand
{
    private DlqWorker $worker;
    private LoggerInterface $logger;
    public function __construct(
        DlqWorker $worker,
        LoggerInterface $logger
    ) {        $this->worker = $worker;
        $this->logger = $logger;
}

    /**
     * Executes the CLI command.
     */
    /**
     * @param array<string, mixed> $argv
     * @return array<string, mixed>
     */
    public function run(array $argv = []): array
    {
        $limit = 10;
        $sleep = null;

        foreach ($argv as $arg) {
            if (is_string($arg)) {
                if (str_starts_with($arg, '--limit=')) {
                    $limit = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--sleep=')) {
                    $sleep = (int)substr($arg, 8);
                }
            }
        }

        // Validate range limits
        $limit = max(1, min(500, $limit));
        $sleep = ($sleep === null) ? null : max(1, min(300, $sleep));

        if ($sleep !== null) {
            return $this->runDaemonLoop($limit, $sleep);
        }

        $this->logger->info('dlq.command.work.starting', [
            'limit' => $limit
        ]);

        try {
            $result = $this->worker->work($limit);
            $processed = int_value($result['processed'] ?? 0);
            $compensated = int_value($result['compensated'] ?? 0);
            $archived = int_value($result['archived'] ?? 0);

            $this->logger->info('dlq.command.work.completed', [
                'processed' => $processed,
                'compensated' => $compensated,
                'archived' => $archived
            ]);

            echo "[dlq:work] processed={$processed} compensated={$compensated} archived={$archived} (limit={$limit})\n";

            return [
                'processed' => $processed,
                'compensated' => $compensated,
                'archived' => $archived
            ];
        } catch (\Throwable $e) {
            $this->logger->error('dlq.command.work.failed', [
                'error' => $e->getMessage()
            ]);
            fwrite(STDERR, "[dlq:work] error: " . $e->getMessage() . "\n");
            return [
                'processed' => 0,
                'compensated' => 0,
                'archived' => 0,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * حلقهٔ دیمن برای supervisor (dlq:work --limit=50 --sleep=10) —
     * بدون این حلقه، کامند بلافاصله خارج می‌شود و supervisor پس از ری‌استارت‌های
     * سریع (startretries=10) برنامه را FATAL می‌کند و پردازش DLQ متوقف می‌شود.
     *
     * @return array<string, mixed>
     */
    private function runDaemonLoop(int $limit, int $sleep): array
    {
        $this->logger->info('dlq.command.work.daemon_starting', [
            'limit' => $limit,
            'sleep' => $sleep
        ]);

        $totals = ['processed' => 0, 'compensated' => 0, 'archived' => 0];

        while (!$this->worker->shouldQuit()) {
            try {
                $result = $this->worker->work($limit);
                $iterationProcessed = int_value($result['processed'] ?? 0);
                $totals['processed'] += $iterationProcessed;
                $totals['compensated'] += int_value($result['compensated'] ?? 0);
                $totals['archived'] += int_value($result['archived'] ?? 0);

                // فقط وقتی صف مرده خالی است صبر می‌کنیم؛ در حال کار بین batch‌ها مکث نمی‌کنیم
                if ($iterationProcessed === 0) {
                    sleep($sleep);
                }
            } catch (\Throwable $e) {
                // خطای زیرساختی موقت: دیمن زنده می‌ماند و با فاصله ادامه می‌دهد
                $this->logger->error('dlq.command.work.daemon_iteration_failed', [
                    'error' => $e->getMessage()
                ]);
                sleep(max($sleep, 5));
            }
        }

        $this->logger->info('dlq.command.work.daemon_stopped', $totals);
        echo "[dlq:work] processed={$totals['processed']} compensated={$totals['compensated']} archived={$totals['archived']} (daemon exit)\n";

        return $totals;
    }
}
