<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\User\AccountDeletionService;
use App\Services\DataExportService;
use App\Contracts\LoggerInterface;

/**
 * Command: ProcessScheduledTasksCommand
 * شامل: حذف خودکار حساب‌ها، پاک‌کردن فایل‌های منقضی
 * 
 * استفاده: php app.php process:scheduled-tasks
 */
class ProcessScheduledTasksCommand
{
    private AccountDeletionService $accountDeletionService;
    private DataExportService $dataExportService;
    private \App\Domain\Financial\Services\FinancialEscrowService $escrowService;
    private \Core\Database $db;
    private LoggerInterface $logger;

    public function __construct(
        AccountDeletionService $accountDeletionService,
        DataExportService $dataExportService,
        \App\Domain\Financial\Services\FinancialEscrowService $escrowService,
        \Core\Database $db,
        LoggerInterface $logger
    ) {
        $this->accountDeletionService = $accountDeletionService;
        $this->dataExportService = $dataExportService;
        $this->escrowService = $escrowService;
        $this->db = $db;
        $this->logger = $logger;
    }

    /**
     * اجرای کمند با پشتیبانی از CliDispatcher
     * FIX-C145 (یافتهٔ ۱۴۵): شکست گام‌ها دیگر خاموش نمی‌ماند — اگر هر گامی
     * شکست بخورد، exit_code غیرصفر به dispatcher/cron برمی‌گردد.
     * FIX-C145: حذف مخرب (حساب‌ها، فایل‌ها، پیام‌ها) به‌صورت پیش‌فرض در حالت
     * پیش‌نمایش (dry-run) اجرا می‌شود؛ اجرای واقعی نیازمند ‎--force است
     * (مسیر cron/Kernel مستقل است و تحت‌تأثیر نیست).
     */
    /** @param array<string, mixed> $argv */
    public function run(array $argv = []): int
    {
        if (in_array('--dry-run', $argv, true) || !in_array('--force', $argv, true)) {
            return $this->dryRun();
        }
        return $this->handle();
    }

    /**
     * FIX-C145: پیش‌نمایش فقط-خواندنی — شمارش کاندیدهای هر گام حذف/آزادسازی.
     */
    private function dryRun(): int
    {
        $counts = [
            'accounts' => 0,
            'exports' => 0,
            'messages' => 0,
            'escrows' => 0,
        ];
        try {
            // FIX-C145: کوئری‌های شمارش، آینهٔ دقیق WHERE سرویس‌های واقعی‌اند
            // (AccountDeletionLog::getExpiredDeletionRequests و DataExport::getExpiredExports).
            $c = $this->db->fetchColumn(
                "SELECT COUNT(*) FROM account_deletion_logs
                 WHERE status = 'requested' AND expires_at < NOW()"
            );
            $counts['accounts'] = is_numeric($c) ? (int)$c : 0;
        } catch (\Throwable $e) {
            $this->logger->warning('command.scheduled_tasks.dry_run.accounts_failed', ['error' => $e->getMessage()]);
        }
        try {
            $c = $this->db->fetchColumn(
                "SELECT COUNT(*) FROM data_exports WHERE status = 'completed' AND expires_at < NOW()"
            );
            $counts['exports'] = is_numeric($c) ? (int)$c : 0;
        } catch (\Throwable $e) {
            $this->logger->warning('command.scheduled_tasks.dry_run.exports_failed', ['error' => $e->getMessage()]);
        }
        try {
            $c = $this->db->fetchColumn(
                // FIX-P3-CMD-072: پنجرهٔ retention از نرمالایزر مشترک (کف ۱ / سقف ۳۶۵۰ روز)
                'SELECT COUNT(*) FROM direct_messages WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)',
                [$this->normalizeRetentionDays()]
            );
            $counts['messages'] = is_numeric($c) ? (int)$c : 0;
        } catch (\Throwable $e) {
            $this->logger->warning('command.scheduled_tasks.dry_run.messages_failed', ['error' => $e->getMessage()]);
        }
        try {
            $expirySetting = config('escrow_expiry_hours', 48);
            $expiredHours = is_scalar($expirySetting) ? max(1, min(8760, (int)$expirySetting)) : 48;
            $c = $this->db->fetchColumn(
                "SELECT COUNT(*) FROM escrow_transactions
                 WHERE status = 'pending' AND held_at < DATE_SUB(NOW(), INTERVAL ? HOUR)",
                [$expiredHours]
            );
            $counts['escrows'] = is_numeric($c) ? (int)$c : 0;
        } catch (\Throwable $e) {
            $this->logger->warning('command.scheduled_tasks.dry_run.escrows_failed', ['error' => $e->getMessage()]);
        }

        echo sprintf(
            "[schedule:run] DRY-RUN: accounts=%d exports=%d messages=%d escrows=%d would be processed. Run with --force to apply.\n",
            $counts['accounts'],
            $counts['exports'],
            $counts['messages'],
            $counts['escrows']
        );
        $this->logger->info('command.scheduled_tasks.dry_run', $counts);
        return 0;
    }

    /**
     * اجرای کمند با ایزوله‌سازی کامل خطاها
     * FIX-C145: خروجی int — 0 = همهٔ گام‌ها موفق، 1 = حداقل یک گام شکست خورد
     * (جزئیات هر گام در لاگ ساختاریافته همان گام).
     */
    public function handle(): int
    {
        $this->logger->info('command.scheduled_tasks.starting');

        $deletedCount = 0;
        $deletedFiles = 0;
        $deletedMessages = 0;
        $releasedEscrows = 0;
        $hadFailure = false;

        // ۱. حذف خودکار حساب‌های درخواست‌شده
        try {
            $deletedCount = $this->accountDeletionService->processExpiredDeletionRequests();
            $this->logger->info('command.scheduled_tasks.accounts_deleted', ['count' => $deletedCount]);
        } catch (\Throwable $e) {
            $hadFailure = true;
            $this->logger->error('command.scheduled_tasks.accounts.failed', ['error' => $e->getMessage()]);
        }

        // ۲. حذف فایل‌های منقضی‌شده
        try {
            $deletedFiles = $this->dataExportService->deleteExpiredExports();
            $this->logger->info('command.scheduled_tasks.files_deleted', ['count' => $deletedFiles]);
        } catch (\Throwable $e) {
            $hadFailure = true;
            $this->logger->error('command.scheduled_tasks.files.failed', ['error' => $e->getMessage()]);
        }

        // ۳. سیاست انقضای پیام‌ها (Message Retention Policy - حذف پیام‌های چت قدیمی‌تر از ۱ سال)
        try {
            // FIX (Round-18 P2): retention window from config/setting with the
            // 365-day fallback (was hardcoded).
            // FIX-P3-CMD-072 (یافتهٔ ۰۷۲): سقف مؤثر — قبلاً فقط کف اعمال می‌شد و
            // مقدار نجومی ‎direct_messages.retention_days (مثلاً ‎99999999) بدون سقف
            // به INTERVAL ... DAY می‌رفت؛ اکنون بازهٔ [1، 3650] مثل cleanupMetrics/escrow.
            $retentionDays = $this->normalizeRetentionDays();

            // حذف پیوست‌های مرتبط با پیام‌های تاریخ‌گذشته ابتدا جهت ممانعت از یتیم شدن کلید خارجی (در صورت وجود ساختار ارتباطی)
            // TODO (Round-18 backlog): attachment orphan cleanup — physical file
            // deletion for expired direct-message attachments is intentionally NOT
            // implemented here (needs a storage-layout contract first); only the
            // DB rows are purged below.

            // FIX (Round-18 P2): the unbounded single DELETE locked the whole table
            // and built one huge binlog transaction. Batched with LIMIT 5000 until
            // a batch affects fewer rows, with per-batch logging.
            $batchSize = 5000;
            $deletedMessages = 0;
            while (true) {
                $stmt = $this->db->query(
                    // FIX-P3-CMD-073 (یافتهٔ ۰۷۳): ترتیب پایدار (ORDER BY id) — بدون آن،
                    // InnoDB ترتیب حذف را تضمین نمی‌کرد و بازه‌های binlog/replica بین
                    // رانرها ناسازگار می‌شد؛ LIMIT هم‌چنان پارامتری/داخلی int است.
                    "DELETE FROM direct_messages WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY) ORDER BY id LIMIT " . $batchSize,
                    [$retentionDays]
                );
                $affected = (int)$stmt->rowCount();
                $deletedMessages += $affected;
                $this->logger->info('command.scheduled_tasks.messages_purged_batch', [
                    'count' => $affected,
                    'retention_days' => $retentionDays,
                ]);
                if ($affected < $batchSize) {
                    break;
                }
            }
            $this->logger->info('command.scheduled_tasks.messages_purged', ['count' => $deletedMessages]);
        } catch (\Throwable $e) {
            $hadFailure = true;
            $this->logger->error('command.scheduled_tasks.messages.failed', ['error' => $e->getMessage()]);
        }

        // ۴. انقضا و برگشت وجه سپرهای موقت تاریخ‌گذشته (Escrow Cleanup)
        try {
            $releasedEscrows = $this->escrowService->releaseExpiredHolds();
            $this->logger->info('command.scheduled_tasks.escrows_released', ['count' => $releasedEscrows]);
        } catch (\Throwable $e) {
            $hadFailure = true;
            $this->logger->error('command.scheduled_tasks.escrows.failed', ['error' => $e->getMessage()]);
        }

        $this->logger->info('command.scheduled_tasks.completed', [
            'deleted_accounts' => $deletedCount,
            'deleted_files' => $deletedFiles,
            'deleted_messages' => $deletedMessages,
            'released_escrows' => $releasedEscrows,
            'had_failure' => $hadFailure,
        ]);

        return $hadFailure ? 1 : 0;
    }

    /**
     * FIX-P3-CMD-072: نرمالایزر مشترک پنجرهٔ retention پیام‌ها (dry-run + handle) —
     * کف ۱، fallback ۳۶۵ برای مقدار نامعتبر، و سقف ۳۶۵۰ روز (۱۰ سال) برای INTERVAL.
     */
    private function normalizeRetentionDays(): int
    {
        $retentionDays = int_value(config('direct_messages.retention_days', 365));
        if ($retentionDays <= 0) {
            $retentionDays = 365;
        }
        return max(1, min(3650, $retentionDays));
    }
}
