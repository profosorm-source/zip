<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Services\ReconciliationService;
use App\Services\Withdrawal\WithdrawalAdminService;
use Core\Database;

/**
 * CLI for the safe stuck-withdrawal review workflow (Section 8.5 / 8.7).
 *
 * This command is a thin orchestrator on top of:
 *   - ReconciliationService (detect/flag/list/admin-ops)
 *   - WithdrawalAdminService::autoResolveStuck() (safe auto-fix)
 *
 * FIX-C136 (یافتهٔ ۱۳۶): ثبت با wildcard «withdrawals:review:*» در bootstrap —
 * قبلاً با نام «stuck-withdrawal:review» ثبت شده بود ولی run() روی نام‌های
 * «withdrawals:review:*» سوییچ می‌کرد؛ نتیجه: هر فراخوانی CLI با
 * InvalidArgumentException شکست می‌خورد و هیچ زیر-اکشنی قابل دسترس نبود.
 *
 * FIX-C150 (یافتهٔ ۱۵۰): run(): int — کدهای خروج به cron/supervisor گزارش
 * می‌شوند (۰ = موفق، ۱ = شکست/استفادهٔ نادرست).
 *
 * Usage:
 *   php cli.php withdrawals:review:scan      [--minutes=120] [--limit=200]
 *   php cli.php withdrawals:review:auto-fix  [--stable=2880] [--limit=50] --admin-id=<id>
 *   php cli.php withdrawals:review:list      [--limit=50]    [--offset=0]
 *   php cli.php withdrawals:review:resolve   <id> --note="..." --admin-id=<id>
 *   php cli.php withdrawals:review:dismiss   <id> --note="..." --admin-id=<id>
 */
class StuckWithdrawalReviewCommand
{
    private ReconciliationService $reconciliation;
    private WithdrawalAdminService $withdrawalAdminService;
    /** FIX-P3-CMD-133: DB اختیاری برای راستی‌آزمایی وجود اپراتور (تست‌ها بدون DB). */
    private ?Database $db;

    public function __construct(
        ReconciliationService $reconciliation,
        WithdrawalAdminService $withdrawalAdminService,
        LoggerInterface $logger,
        ?Database $db = null
    ) {        $this->reconciliation = $reconciliation;
        $this->withdrawalAdminService = $withdrawalAdminService;
        $this->db = $db;
        unset($logger);
}

    /** @param array<int|string, mixed> $argv */

    public function run(array $argv): int
    {
        $command = str_value($argv[1] ?? 'withdrawals:review:list');
        $opts = $this->parseOptions($argv);

        try {
            switch ($command) {
                case 'withdrawals:review:scan':
                    $this->scan($opts);
                    return 0;
                case 'withdrawals:review:auto-fix':
                    return $this->autoFix($opts);
                case 'withdrawals:review:list':
                    $this->listOpen($opts);
                    return 0;
                case 'withdrawals:review:resolve':
                    return $this->resolve($argv[2] ?? null, $opts);
                case 'withdrawals:review:dismiss':
                    return $this->dismiss($argv[2] ?? null, $opts);
                default:
                    throw new \InvalidArgumentException("Unsupported command: {$command}");
            }
        } catch (\InvalidArgumentException $e) {
            fwrite(STDERR, "Usage error: " . $e->getMessage() . "\n");
            return 1;
        }
    }

    /** @param array<string, mixed> $opts */
    private function optionInt(array $opts, string $key, int $default, int $min = 0, int $max = PHP_INT_MAX): int
    {
        $value = $opts[$key] ?? $default;
        // FIX-C149: مقادیر غیرعددی/خارج از بازه به پیش‌فرض سقوط می‌کنند؛
        // مقدار منفی دیگر به LIMIT/INTerval نمی‌رسد.
        if (!is_numeric($value)) {
            return $default;
        }
        $int = (int)$value;
        if ($int < $min) {
            return $default;
        }
        return min($int, $max);
    }

    /** @param array<string, mixed> $opts */
    private function scan(array $opts): void
    {
        $minutes = $this->optionInt($opts, 'minutes', ReconciliationService::DEFAULT_STUCK_MINUTES);
        $limit = $this->optionInt($opts, 'limit', ReconciliationService::STUCK_SCAN_BATCH);

        $r = $this->reconciliation->flagStuckWithdrawals($minutes, $limit);
        echo sprintf(
            "[scan] scanned=%d flagged=%d notified=%d skipped=%d (older_than=%dmin)\n",
            $r['scanned'], $r['flagged'], $r['notified'], $r['skipped'], $minutes
        );
    }

    /** @param array<string, mixed> $opts */
    private function autoFix(array $opts): int
    {
        // FIX-C149 (یافتهٔ ۱۴۹): ‎--stable یک مقدار دقیقه‌ای است نه boolean —
        // قبلاً ‎--stable=30 به true تبدیل و به پنجرهٔ ثابت ۴۸ساعته نقشه می‌خورد
        // و خروجی «(stable=%d)» همیشه ۰/۱ چاپ می‌کرد. اکنون دقیقهٔ خام به
        // autoResolveStuck پاس می‌شود (clamp سرویس: ۶۰دقیقه تا ۷روز).
        $stableRaw = $opts['stable'] ?? null;
        $stableMinutes = is_numeric($stableRaw) ? (int)$stableRaw : null;
        $stable = $stableMinutes !== null && $stableMinutes >= 60;
        $limit = $this->optionInt($opts, 'limit', 50, 1, 500);
        // L-15 FIX: defaulting to admin-id 0 wrote financial/administrative audit entries with a
        // non-existent actor, destroying accountability for withdrawal decisions. The acting
        // admin must now be identified explicitly.
        $adminId = $this->requireAdminId($opts);

        $r = $this->withdrawalAdminService->autoResolveStuck($adminId, $stable, $limit, $stableMinutes);
        $errors = int_value($r['errors'] ?? $r['failed'] ?? 0);
        echo sprintf(
            "[auto-fix] scanned=%d fixed=%d escalated=%d errors=%d (stable=%dmin)\n",
            int_value($r['scanned'] ?? 0),
            int_value($r['fixed'] ?? $r['resolved'] ?? 0),
            int_value($r['escalated'] ?? 0),
            $errors,
            $stableMinutes !== null ? max(60, min(10080, $stableMinutes)) : ($stable ? 2880 : 1440)
        );
        // FIX-C150: شکست‌های جزئی، کد خروج غیرصفر به cron می‌دهند.
        return $errors > 0 ? 1 : 0;
    }

    /** @param array<string, mixed> $opts */
    private function listOpen(array $opts): void
    {
        $limit = $this->optionInt($opts, 'limit', 50);
        $offset = $this->optionInt($opts, 'offset', 0);

        $rows = $this->reconciliation->listOpenReviews($limit, $offset);
        if (empty($rows)) {
            echo "No open stuck-withdrawal reviews.\n";
            return;
        }
        foreach ($rows as $r) {
            echo sprintf(
                "#%d  w=#%d  user=%d  status=%s  sev=%s  reason=%s  stuck=%dmin  amount=%s %s  notified=%s\n",
                (int)$r->id,
                (int)$r->withdrawal_id,
                (int)$r->user_id,
                // 🛡️ FIX-S20-REVIEW: ستون مردهٔ review_status (همیشه 'open') حذف شد؛
                // وضعیت واقعی چرخهٔ بازبینی در status است (قرارداد ReconciliationService).
                (string)($r->status ?? $r->review_status ?? 'unknown'),
                (string)$r->severity,
                (string)$r->reason_code,
                (int)$r->stuck_minutes,
                (string)($r->withdrawal_amount ?? '?'),
                strtoupper((string)($r->withdrawal_currency ?? '')),
                $r->notified_admin_at ? 'yes' : 'no'
            );
        }
    }

    /** @param array<string, mixed> $opts */
    private function resolve(?string $idArg, array $opts): int
    {
        $id = $this->parseReviewId($idArg);
        $noteValue = $opts['note'] ?? '';
        $note = is_string($noteValue) ? $noteValue : '';
        if ($note === '') {
            throw new \InvalidArgumentException('--note="..." is required.');
        }
        // L-15 FIX: defaulting to admin-id 0 wrote financial/administrative audit entries with a
        // non-existent actor, destroying accountability for withdrawal decisions. The acting
        // admin must now be identified explicitly.
        $adminId = $this->requireAdminId($opts);
        $ok = $this->reconciliation->adminResolveReview($id, $adminId, $note);
        echo $ok ? "Resolved review #{$id}.\n" : "Review #{$id} not in resolvable state.\n";
        // FIX-C150: نتیجهٔ عملیات به کد خروج منعکس می‌شود.
        return $ok ? 0 : 1;
    }

    /** @param array<string, mixed> $opts */
    private function dismiss(?string $idArg, array $opts): int
    {
        $id = $this->parseReviewId($idArg);
        $noteValue = $opts['note'] ?? '';
        $note = is_string($noteValue) ? $noteValue : '';
        if ($note === '') {
            throw new \InvalidArgumentException('--note="..." is required.');
        }
        // L-15 FIX: defaulting to admin-id 0 wrote financial/administrative audit entries with a
        // non-existent actor, destroying accountability for withdrawal decisions. The acting
        // admin must now be identified explicitly.
        $adminId = $this->requireAdminId($opts);
        $ok = $this->reconciliation->dismissReview($id, $adminId, $note);
        echo $ok ? "Dismissed review #{$id}.\n" : "Review #{$id} not in dismissable state.\n";
        // FIX-C150: نتیجهٔ عملیات به کد خروج منعکس می‌شود.
        return $ok ? 0 : 1;
    }

    /**
     * FIX-P3-CMD-131: پارس سخت‌گیر شناسهٔ review — فقط رشتهٔ عددیِ تمام‌ارقام؛
     * '12abc'/'abc'/'' دیگر به شناسهٔ ناخواسته cast نمی‌شود.
     */
    private function parseReviewId(?string $idArg): int
    {
        $raw = $idArg ?? '';
        if (!is_string($raw) || !ctype_digit($raw) || (int)$raw <= 0) {
            throw new \InvalidArgumentException('A positive integer review id is required.');
        }
        return (int)$raw;
    }

    /**
     * L-15: resolve the acting admin id, refusing the unattributed default.
     *
     * FIX-P3-CMD-131 (یافتهٔ ۱۳۱) در مسیر resolve/dismiss: شناسهٔ review فقط با
     * ctype_digit پذیرفته می‌شود — '12abc' قبلاً بی‌صدا به ۱۲ cast می‌شد.
     *
     * FIX-P3-CMD-133 (یافتهٔ ۱۳۳): --admin-id فقط مثبت‌بودن را چک می‌کرد و هر id
     * دلخواه (حتی کاربر ناموجود) به ردیف‌های audit می‌رفت؛ اکنون وقتی DB در دسترس
     * است، وجود کاربر راستی‌آزمایی می‌شود (در ساخت‌های دستی بدون DB، گارد با
     * توضیح fail-open می‌ماند تا سازگاری فراخوان‌های موجود حفظ شود).
     *
     * @param array<string, mixed> $opts
     */
    private function requireAdminId(array $opts): int
    {
        $adminId = $this->optionInt($opts, 'admin-id', 0);
        if ($adminId <= 0) {
            throw new \InvalidArgumentException('--admin-id=<id> is required so the action is attributable.');
        }
        if ($this->db !== null) {
            $row = $this->db->fetch("SELECT id FROM users WHERE id = ? LIMIT 1", [$adminId]);
            if ($row === null || $row === false) {
                throw new \InvalidArgumentException("--admin-id={$adminId} does not reference an existing user — audit attribution requires a real operator.");
            }
        }
        return $adminId;
    }

    /**
     * @param array<int|string, mixed> $argv
     * @return array<string, mixed>
     */
    private function parseOptions(array $argv): array
    {
        $opts = [];
        $count = count($argv);
        for ($i = 2; $i < $count; $i++) {
            $arg = (string)$argv[$i];
            if (!str_starts_with($arg, '--')) {
                continue;
            }
            $arg = substr($arg, 2);
            if (str_contains($arg, '=')) {
                [$k, $v] = explode('=', $arg, 2);
                $opts[$k] = trim($v, "\"' ");
            } else {
                $next = $argv[$i + 1] ?? null;
                if ($next !== null && !str_starts_with((string)$next, '--')) {
                    $opts[$arg] = trim((string)$next, "\"' ");
                    $i++;
                } else {
                    $opts[$arg] = true;
                }
            }
        }
        return $opts;
    }
}
