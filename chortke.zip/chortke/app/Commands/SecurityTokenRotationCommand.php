<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Models\ApiToken;
use App\Models\AuditTrail;
use Core\Database;

/**
 * 🛡️ FIX-SECRETROT-4 (باقی‌ماندهٔ چرخش رمز — توکن‌های هرگز-استفاده‌نشدهٔ نسخهٔ قدیمی):
 * ممیزی و پاکسازیِ ردیف‌هایی که بعد از چرخشِ رمز، هنوز روی برچسبِ نسخهٔ قدیمی‌اند.
 *
 * چرا این فرمان لازم است؟ مهاجرتِ توکن به نسخهٔ جدید «در اولین استفاده» رخ می‌دهد
 * (ApiAuthMiddleware::validateTokenWithRotation) — توکن‌هایی که هرگز استفاده نشوند
 * برای همیشه روی نسخهٔ قدیمی می‌مانند و تا وقتی رمزِ آن نسخه در .env حاضر است
 * معتبر می‌مانند؛ یعنی رمز قدیمی هرگز بازنشسته نمی‌شود.
 *
 * نکتهٔ صادقانهٔ معماری: «مهاجرت یکجای واقعی» این ردیف‌ها ناممکن است — DB فقط
 * هشِ HMAC توکن را با رمزِ همان نسخه نگه می‌دارد (توکن خام هرگز ذخیره نمی‌شود)
 * و بدون توکنِ خام، بازهاش با رمز جدید ممکن نیست. بنابراین تنها اهرمِ یکجا،
 * «ابطال» (revoke) با دلیلِ صریح rotation_cleanup است؛ پس از صفر شدن وابستگی‌ها،
 * رمزِ نسخهٔ قدیمی قابل حذف از .env است (حکم بازنشستگی در گزارش چاپ می‌شود).
 *
 * مصرف:
 *   php cli.php security:token-rotation                      (گزارش ممیزی — فقط‌خواندنی؛
 *                                                             خروج ۰ = تمیز، ۲ = ردیف کهنهٔ فعال موجود)
 *   php cli.php security:token-rotation --list               (+ لیست ردیف‌های نامزد، حداکثر ۵۰)
 *   php cli.php security:token-rotation --revoke=never-used [--dry-run] [--confirm]
 *   php cli.php security:token-rotation --revoke=dormant    [--dry-run] [--confirm]
 *   php cli.php security:token-rotation --revoke=all-stale  [--dry-run] [--confirm]
 *
 * دامنه‌های ابطال:
 *   never-used = ردیف‌های فعالِ نسخهٔ کهنه بدون last_used_at (هرگز استفاده نشده)
 *   dormant    = ردیف‌های فعالِ نسخهٔ کهنه با last_used_at (قبل از چرخش استفاده می‌شد،
 *                از آن موقع خفته — مراقب باشید: ممکن است اسکریپت دوره‌ایِ آهسته باشد)
 *   all-stale  = هر ردیف فعالِ نسخهٔ کهنه (هر دو گروه)
 *
 * در production اجرای ابطالِ واقعی بدون --confirm رد می‌شود (fail-closed —
 * هم‌قرارداد با security:seed-rotate). ابطال دائمی است: کلاینتی که توکنش ابطال
 * شده باید توکن جدید بسازد.
 */
final class SecurityTokenRotationCommand
{
    /** دلیل ثبت‌شده در revoke_reason — VARCHAR(32)؛ امضای سرقت نمی‌سازد (FIX-M11-R22-2) */
    private const REVOKE_REASON = 'rotation_cleanup';

    private const LIST_LIMIT = 50;

    private Database $db;
    private ApiToken $apiTokenModel;
    private AuditTrail $auditTrail;
    private LoggerInterface $logger;

    public function __construct(Database $db, ApiToken $apiTokenModel, AuditTrail $auditTrail, LoggerInterface $logger)
    {
        $this->db = $db;
        $this->apiTokenModel = $apiTokenModel;
        $this->auditTrail = $auditTrail;
        $this->logger = $logger;
    }

    /** @param list<string> $argv */
    public function run(array $argv): int
    {
        $list = false;
        $dryRun = false;
        $confirm = false;
        /** @var string|null $revokeScope */
        $revokeScope = null;

        foreach (array_slice($argv, 2) as $arg) {
            $arg = str_value($arg);
            if ($arg === '--list') {
                $list = true;
            } elseif ($arg === '--dry-run') {
                $dryRun = true;
            } elseif ($arg === '--confirm') {
                $confirm = true;
            } elseif (str_starts_with($arg, '--revoke=')) {
                $revokeScope = substr($arg, strlen('--revoke='));
            } else {
                echo "❌ پارامتر ناشناخته: {$arg}\n";
                self::printUsage();
                return 1;
            }
        }

        if ($revokeScope !== null && !in_array($revokeScope, ['never-used', 'dormant', 'all-stale'], true)) {
            echo "❌ مقدار --revoke نامعتبر است: {$revokeScope} (مجاز: never-used | dormant | all-stale)\n";
            self::printUsage();
            return 1;
        }

        // ── وضعیت config: نسخهٔ جاری و رمزهای نسخه‌دار ────────────────────
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) && $currentVersionValue !== ''
            ? $currentVersionValue
            : 'v2';

        /** @var array<string, string> $usableSecrets نسخه‌هایی که رمزِ قابل‌اعتبارسنجی (≥۳۲ کاراکتر) دارند */
        $usableSecrets = [];
        foreach ($secrets as $label => $secret) {
            $labelStr = str_value($label);
            $secretStr = str_value($secret);
            if ($labelStr !== '' && strlen($secretStr) >= 32) {
                $usableSecrets[$labelStr] = $secretStr;
            }
        }

        $isRealRotation = count(array_unique(array_values($usableSecrets))) >= 2;

        // ── آمار DB ──────────────────────────────────────────────────────
        try {
            $stats = $this->apiTokenModel->getSecretVersionRotationStats();
        } catch (\Throwable $e) {
            echo '❌ خواندن آمار api_tokens ناموفق: ' . $e->getMessage() . "\n";
            return 1;
        }
        $accessStats = $stats['access'];
        $refreshStats = $stats['refresh'];

        /** @var list<string> $staleVersions نسخه‌های کهنه با حداقل یک ردیف فعال (دسترسی) — برچسب‌ها با str_value نرمال می‌شوند (کلیدهای عددی آرایه در PHP به int تبدیل می‌شوند) */
        $staleVersions = [];
        foreach ($accessStats as $label => $counts) {
            $labelStr = str_value($label);
            if ($labelStr !== $currentVersion && $counts['live'] > 0) {
                $staleVersions[] = $labelStr;
            }
        }
        sort($staleVersions);

        $staleLive = 0;
        foreach ($staleVersions as $label) {
            $staleLive += $accessStats[$label]['live'];
        }
        /** @var int $staleRefreshDeps وابستگی refreshِ ردیف‌های فعال به نسخه‌های غیرجاری */
        $staleRefreshDeps = 0;
        foreach ($refreshStats as $label => $count) {
            if (str_value($label) !== $currentVersion) {
                $staleRefreshDeps += $count;
            }
        }

        // ── گزارش ────────────────────────────────────────────────────────
        echo "── ممیزی چرخش رمز توکن API (FIX-SECRETROT-4) ──\n";
        echo 'نسخهٔ جاری: ' . $currentVersion;
        echo $usableSecrets === []
            ? " (⚠️ هیچ رمز نسخه‌داری در config فعال نیست — صدور/اعتبارسنجی توکن کار نمی‌کند)\n"
            : ' | رمزهای فعال: ' . implode(', ', array_keys($usableSecrets)) . "\n";
        if ($usableSecrets !== [] && !$isRealRotation) {
            echo "⚠️ همهٔ رمزهای نسخه‌دار یک مقدارند (V1 === V2) — چرخش هنوز واقعی نیست؛ نسخهٔ قدیمی‌ای برای پاکسازی وجود ندارد.\n";
        }

        echo "\n── توکن‌های دسترسی به تفکیک نسخهٔ رمز ──\n";
        if ($accessStats === []) {
            echo "  (جدول api_tokens خالی است)\n";
        }
        foreach ($accessStats as $label => $counts) {
            $labelStr = str_value($label);
            $isCurrent = $labelStr === $currentVersion;
            $isOrphan = !$isCurrent && !isset($usableSecrets[$labelStr]);
            $tag = $isCurrent
                ? 'جاری'
                : ($isOrphan ? 'یتیم — رمزی در config ندارد' : 'قدیمی');
            echo sprintf(
                "  • %s [%s]: فعال=%d (هرگز-استفاده‌نشده=%d | خفته=%d | منقضی=%d | دارای-refresh=%d) | کل ردیف‌ها=%d\n",
                $labelStr === '' ? '(NULL)' : $labelStr,
                $tag,
                $counts['live'],
                $counts['live_never_used'],
                $counts['live_used_before'],
                $counts['live_expired'],
                $counts['live_with_refresh'],
                $counts['total']
            );
            if ($isOrphan) {
                echo "      ↳ ردیف‌های این نسخه هرگز اعتبارسنجی نمی‌شوند (کلید رمزشان در config نیست) — مردهٔ قطعی‌اند.\n";
            }
        }

        echo "\n── وابستگی refresh ردیف‌های فعال به نسخهٔ رمز ──\n";
        if ($refreshStats === []) {
            echo "  (هیچ ردیف فعالی refresh_token ندارد)\n";
        }
        foreach ($refreshStats as $label => $count) {
            $labelStr = str_value($label);
            echo sprintf(
                "  • %s: %d ردیف فعال%s\n",
                $labelStr === '' ? '(NULL)' : $labelStr,
                $count,
                $labelStr === $currentVersion
                    ? ' (نسخهٔ جاری ✓)'
                    : ' — حذف رمز این نسخه از .env، refresh همین ردیف‌ها را باطل می‌کند'
            );
        }

        echo "\n── حکم بازنشستگی رمزهای config ──\n";
        foreach ($usableSecrets as $label => $secret) {
            if ($label === $currentVersion) {
                echo "  • {$label} [جاری]: هرگز حذف نشود — توکن‌های تازه با این رمز صادر می‌شوند.\n";
                continue;
            }
            $accessDeps = isset($accessStats[$label]) ? $accessStats[$label]['live'] : 0;
            $refreshDeps = isset($refreshStats[$label]) ? $refreshStats[$label] : 0;
            if ($accessDeps === 0 && $refreshDeps === 0) {
                echo "  • {$label}: ✅ هیچ ردیف فعالی به این رمز وابسته نیست — می‌توانید مقدارش را از .env حذف/خالی کنید.\n";
            } else {
                echo "  • {$label}: ⛔ ردیف‌های فعالِ وابسته (دسترسی: {$accessDeps} | refresh: {$refreshDeps}) — قبل از حذف از .env، پاکسازی با security:token-rotation --revoke=all-stale لازم است.\n";
            }
        }

        // نسخه‌های DB که در config نیستند (یتیم) — رمزی برای بازنشستگی ندارند ولی گزارش می‌شوند
        foreach ($accessStats as $label => $counts) {
            $labelStr = str_value($label);
            if ($labelStr !== $currentVersion && $labelStr !== '' && !isset($usableSecrets[$labelStr]) && $counts['live'] > 0) {
                echo "  • {$labelStr}: ردیف فعال دارد ولی رمزش در config نیست — ردیف‌ها مرده‌اند؛ با --revoke=all-stale پاکسازی می‌شوند.\n";
            }
        }

        // ── حالت گزارش خالص ──────────────────────────────────────────────
        if ($revokeScope === null) {
            if ($staleVersions === []) {
                if ($staleRefreshDeps > 0) {
                    echo "\nℹ️ هیچ ردیفِ دسترسیِ کهنه‌ای نیست ولی {$staleRefreshDeps} ردیف فعال refreshِ وابسته به رمز قدیمی دارد (دسترسی‌شان روی نسخهٔ جاری است — با refresh بعدی خودشان می‌چرخند، یا از پنل باطلشان کنید).\n";
                } else {
                    echo "\n✅ هیچ ردیف فعالی روی نسخهٔ غیرجاری نیست — چرخش کامل است.\n";
                }
                return ($staleRefreshDeps > 0) ? 2 : 0;
            }
            echo "\n⚠️ {$staleLive} ردیف فعال روی نسخهٔ کهنه مانده‌اند (هرگز بعد از چرخش استفاده نشده‌اند).\n";
            if ($list) {
                $this->printCandidateRows($staleVersions, 'all');
            }
            echo "گام بعدی: php cli.php security:token-rotation --revoke=never-used --dry-run\n";
            return ($staleLive > 0 || $staleRefreshDeps > 0) ? 2 : 0;
        }

        // ── حالت ابطال ───────────────────────────────────────────────────
        if ($staleVersions === []) {
            echo "\n✅ هیچ ردیف فعالی روی نسخهٔ غیرجاری نیست — کاری برای انجام نیست (idempotent).\n";
            return 0;
        }

        /** @var 'never_used'|'used'|'all' $usageFilter */
        $usageFilter = match ($revokeScope) {
            'never-used' => 'never_used',
            'dormant' => 'used',
            default => 'all',
        };

        $isProduction = (config('app.env') === 'production' || env('APP_ENV') === 'production');
        if ($isProduction && !$dryRun && !$confirm) {
            echo "\n❌ محیط production: برای ابطالِ واقعی، اجرای عمدی با --confirm الزامی است (fail-closed).\n";
            echo "   پیشنهاد: اول گزارش بدون پارامتر، بعد --dry-run و در نهایت --confirm.\n";
            return 1;
        }

        echo "\n── " . ($dryRun ? 'شبیه‌سازی ابطال (dry-run، بدون تغییر)' : "ابطال ردیف‌های نسخهٔ کهنه — دامنه: {$revokeScope}") . " ──\n";
        echo 'نسخه‌های هدف: ' . implode(', ', array_map(
            static fn (string $label): string => $label === '' ? '(NULL)' : $label,
            $staleVersions
        )) . "\n";
        echo "⚠️ ابطال دائمی است — توکن خام در DB نیست تا «بازهاش» کنیم؛ کلاینت باید توکن جدید بسازد.\n";

        $shown = $this->printCandidateRows($staleVersions, $usageFilter);

        if ($dryRun) {
            echo "dry-run تمام شد — هیچ تغییری اعمال نشد.\n";
            return 0;
        }

        $revoked = 0;
        try {
            $this->db->beginTransaction();
            $revoked = $this->apiTokenModel->revokeByStaleSecretVersion($staleVersions, self::REVOKE_REASON, $usageFilter);
            $this->auditTrail->createEntry([
                'actor_id' => AuditTrail::SYSTEM_ACTOR_ID,
                'event' => 'security.token_rotation_cleanup',
                'context' => [
                    'scope' => $revokeScope,
                    'current_version' => $currentVersion,
                    'versions_targeted' => $staleVersions,
                    'revoked_count' => $revoked,
                    'listed_count' => $shown,
                    'source' => 'cli:security:token-rotation',
                ],
                'ip_address' => '127.0.0.1',
                'user_agent' => 'CLI security:token-rotation',
            ]);
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            echo '❌ ابطال ناموفق (rollback شد): ' . $e->getMessage() . "\n";
            $this->logger->error('security.token_rotation_cleanup_failed', [
                'scope' => $revokeScope,
                'error' => $e->getMessage(),
            ]);
            return 1;
        }

        echo "✓ {$revoked} ردیف ابطال شد (دلیل: " . self::REVOKE_REASON . ")\n";
        $this->logger->info('security.token_rotation_cleanup', [
            'scope' => $revokeScope,
            'versions' => $staleVersions,
            'revoked' => $revoked,
        ]);

        // حکم پس از پاکسازی — آمارِ تازه از DB (آمارِ قبل از ابطال دیگر معتبر نیست:
        // ردیف‌های ابطال‌شده هم در وابستگی refresh شمرده می‌شدند)
        try {
            $freshStats = $this->apiTokenModel->getSecretVersionRotationStats();
        } catch (\Throwable $e) {
            $freshStats = ['access' => [], 'refresh' => []];
        }
        $remainingAccess = 0;
        foreach ($freshStats['access'] as $label => $counts) {
            if (str_value($label) !== $currentVersion) {
                $remainingAccess += $counts['live'];
            }
        }
        $remainingRefresh = 0;
        foreach ($freshStats['refresh'] as $label => $count) {
            if (str_value($label) !== $currentVersion) {
                $remainingRefresh += $count;
            }
        }
        if ($remainingAccess === 0 && $remainingRefresh === 0) {
            echo "✅ هیچ ردیف فعالی روی نسخهٔ کهنه نماند — رمز قدیمی را می‌توانید از .env حذف/خالی کنید.\n";
        } elseif ($remainingAccess === 0) {
            echo "ℹ️ ردیفِ دسترسیِ کهنه نماند ولی {$remainingRefresh} ردیف فعال هنوز refreshِ وابسته به رمز قدیمی دارد (دسترسی‌شان روی نسخهٔ جاری است — با refresh بعدی خودشان می‌چرخند، یا از پنل باطلشان کنید).\n";
        } else {
            echo "ℹ️ {$remainingAccess} ردیف فعالِ کهنه هنوز باقی است — برای پاکسازی کامل: --revoke=all-stale --dry-run\n";
        }

        return 0;
    }

    /**
     * چاپ ردیف‌های نامزد ابطال (تا LIST_LIMIT ردیف) — خروجی: تعداد ردیف‌های نمایش‌داده‌شده.
     *
     * @param list<string> $staleVersions
     * @param 'never_used'|'used'|'all' $usageFilter
     */
    private function printCandidateRows(array $staleVersions, string $usageFilter): int
    {
        try {
            $rows = $this->apiTokenModel->listStaleSecretVersionRows($staleVersions, $usageFilter, self::LIST_LIMIT);
        } catch (\Throwable $e) {
            echo '⚠️ واکشی لیست نامزدها ناموفق بود: ' . $e->getMessage() . "\n";
            return 0;
        }

        if ($rows === []) {
            echo "  (هیچ ردیفی در این دامنه نیست)\n";
            return 0;
        }

        foreach ($rows as $row) {
            echo sprintf(
                "  • id=%d | کاربر #%d (%s) | %s | نوع=%s | نسخه=%s | آخرین استفاده=%s | use_count=%s | ساخته‌شده=%s%s\n",
                int_value($row->id ?? 0),
                int_value($row->user_id ?? 0),
                str_value($row->username ?? '؟'),
                str_value($row->name ?? 'بی‌نام'),
                str_value($row->token_type ?? 'personal'),
                str_value($row->secret_version ?? '') === '' ? '(NULL)' : str_value($row->secret_version ?? ''),
                str_value($row->last_used_at ?? 'هرگز'),
                str_value($row->use_count ?? '0'),
                str_value($row->created_at ?? '؟'),
                int_value($row->has_refresh ?? 0) === 1 ? ' | دارای-refresh' : ''
            );
        }
        return count($rows);
    }

    private static function printUsage(): void
    {
        echo "مصرف:\n";
        echo "  php cli.php security:token-rotation                    گزارش ممیزی (فقط‌خواندنی)\n";
        echo "  php cli.php security:token-rotation --list             + لیست ردیف‌های نامزد\n";
        echo "  php cli.php security:token-rotation --revoke=never-used [--dry-run] [--confirm]\n";
        echo "  php cli.php security:token-rotation --revoke=dormant    [--dry-run] [--confirm]\n";
        echo "  php cli.php security:token-rotation --revoke=all-stale  [--dry-run] [--confirm]\n";
    }
}
