<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Services\Settings\SecretBox;
use App\Services\Settings\SettingsCatalog;
use App\Services\Settings\SettingsManager;
use Core\Cache;
use Core\Database;

/**
 * 🛡️ X385 (راند ۱۰۴) — مهاجرت نرم plaintext میراثی → پاکت CHBSEC1.
 *
 * چرا؟ از راند X371 مسیرِ «نوشتن» مقادیر secret را با پاکت CHBSEC1 مهر می‌کند
 * و مسیر «خواندن» پاکت را شفاف باز می‌کند؛ ولی ردیف‌هایی که پیش از X371 با
 * plaintext ذخیره شده بودند به‌صورت ماندگار plaintext می‌ماندند (فقط با خوانش
 * شفاف کار می‌کردند). این دستور آن‌ها را یک‌جا — و لَخت (idempotent) — مهاجرت
 * می‌دهد: مقدار plaintext میراثی داخل پاکت CHBSEC1 می‌رود؛ مقدار خالی و
 * پاکت‌شده دست‌نخورده می‌ماند.
 *
 * چرا «نرم»؟
 *  - هیچ سرویسی restart نمی‌خواهد (پاکت self-describing است؛ مسیر خواندن از قبل
 *    هر دو حالت را می‌فهمد — X371).
 *  - هیچ رازی بازتولید نمی‌شود؛ همان مقدار بایت‌به‌بایت داخل پاکت می‌رود.
 *  - APP_KEY غایب → fail-closed: مهاجرت بدون هیچ تغییری متوقف می‌شود.
 *  - idempotent: اجرای تکراری صفر مهاجرت دیگر گزارش می‌کند (خروجی مناسب
 *    ensure-stack: هیچ‌کاری/هیچ‌خروجی‌ای وقتی کار نیست).
 *
 * مصرف:
 *   php cli.php settings:migrate-secrets            (اجرا)
 *   php cli.php settings:migrate-secrets --dry-run  (فقط گزارش)
 *   در سندباکس: ensure-stack پس از migration این را با --quiet اجرا می‌کند.
 */
final class SettingsMigrateSecretsCommand
{
    private Database $db;
    private LoggerInterface $logger;
    private ?SettingsManager $settingsManager;
    /** FIX-P3-CMD-117: کش اختیاری برای قفل اجرا (مسیرهای بدون redis قابل ساخت می‌مانند). */
    private ?Cache $cache;

    public function __construct(Database $db, LoggerInterface $logger, ?SettingsManager $settingsManager = null, ?Cache $cache = null)
    {
        $this->db = $db;
        $this->logger = $logger;
        $this->settingsManager = $settingsManager;
        $this->cache = $cache;
    }

    /** FIX-P3-CMD-119: تشخیص محیط production — هم‌الگوی OutboxPublishCommand. */
    private function isProductionEnv(): bool
    {
        return (config('app.env') === 'production' || env('APP_ENV') === 'production');
    }

    /**
     * FIX-P3-CMD-119: باطل‌سازی best-effort کش تنظیمات پس از نوشتن مستقیم DB
     * (مسیر fallback بدون SettingsManager) — کلید همان CACHE_KEY مسیر رسمی است.
     */
    private function flushSettingsCacheBestEffort(): void
    {
        if ($this->cache === null) {
            return;
        }
        try {
            // AppSettings::CACHE_KEY private است؛ مقدار کانونیکال با مسیر رسمی
            // (ClearSettingsCache) یکسان نگه داشته می‌شود.
            $this->cache->forget('system:settings:v2');
        } catch (\Throwable $e) {
            $this->logger->debug('settings.migrate_secrets.cache_flush_failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * FIX-P3-CMD-117: قفل اجرا (Redis nx/ex، الگوی scores:decay) — دو اجرای هم‌زمان
     * قبلاً هر دو از گارد isEncrypted عبور می‌کردند (TOCTOU) و دوبل می‌نوشتند/
     * SettingsUpdated دوباره دیسپچ می‌کردند. مشغول بودن قفل ⇒ خروج صادقانهٔ ۰.
     * بدون redis، fail-open مستند (مهاجرت لخت/idempotent است؛ فقط هم‌پوشانی حذف نمی‌شود).
     *
     * @return array{status: string, key: ?string} status: held|busy|unavailable
     */
    private function acquireRunLock(): array
    {
        if ($this->cache === null) {
            return ['status' => 'unavailable', 'key' => null];
        }
        try {
            $redis = $this->cache->redis();
            if (!$redis) {
                return ['status' => 'unavailable', 'key' => null];
            }
            $key = $this->cache->redisKey('settings:migrate_secrets:run_lock');
            if (!$redis->set($key, (string)time(), ['nx', 'ex' => 900])) {
                return ['status' => 'busy', 'key' => $key];
            }
            return ['status' => 'held', 'key' => $key];
        } catch (\Throwable $e) {
            $this->logger->warning('settings.migrate_secrets.run_lock_unavailable', ['error' => $e->getMessage()]);
            return ['status' => 'unavailable', 'key' => null];
        }
    }

    /** FIX-P3-CMD-117: آزادسازی best-effort قفل — TTL پشتیبان هم دارد. */
    private function releaseRunLock(?string $key): void
    {
        if ($key === null || $this->cache === null) {
            return;
        }
        try {
            $redis = $this->cache->redis();
            if ($redis) {
                $redis->del($key);
            }
        } catch (\Throwable $e) {
            $this->logger->debug('settings.migrate_secrets.run_lock_release_failed', ['error' => $e->getMessage()]);
        }
    }

    /** @param array<int, string> $argv */
    public function run(array $argv = []): int
    {
        $dryRun = in_array('--dry-run', $argv, true);
        $quiet  = in_array('--quiet', $argv, true);

        // کلیدهای نوع secret از منبع واحد حقیقت (کاتالوگ) — نه حدس الگویی
        $secretKeys = [];
        foreach (SettingsCatalog::all() as $category) {
            foreach (is_array($category) ? $category : [] as $entry) {
                if (is_array($entry)
                    && isset($entry['key'], $entry['type'])
                    && strtolower(trim((string)$entry['type'])) === 'secret') {
                    $secretKeys[] = (string)$entry['key'];
                }
            }
        }
        $secretKeys = array_values(array_unique($secretKeys));
        if ($secretKeys === []) {
            if (!$quiet) { echo "settings:migrate-secrets — کلید secret در کاتالوگ نیست؛ کاری نیست.\n"; }
            return 0;
        }

        // FIX-P3-CMD-117: قفل فقط برای اجرای واقعی (dry-run فقط-خواندنی است)
        $runLockKey = null;
        if (!$dryRun) {
            $lock = $this->acquireRunLock();
            if ($lock['status'] === 'busy') {
                $this->logger->info('settings.migrate_secrets.skipped_concurrent_run', []);
                if (!$quiet) { echo "settings:migrate-secrets — another run is active; skipped (run lock held).\n"; }
                return 0;
            }
            $runLockKey = $lock['key'];
        }

        try {
            $completed = $this->migrateRows($secretKeys, $dryRun, $quiet, $scanned, $migrated);
        } finally {
            $this->releaseRunLock($runLockKey);
        }

        if (!$quiet) {
            echo "settings:migrate-secrets — scanned={$scanned} migrated={$migrated}"
                . ($dryRun ? ' (dry-run)' : '') . "\n";
        }
        if ($completed && $migrated > 0 && !$dryRun) {
            $this->logger->info('settings.migrate_secrets.completed', [
                'scanned' => $scanned, 'migrated' => $migrated, 'dry_run' => false,
            ]);
        }
        // FIX-P3-CMD-117: شکست هر ردیف (seal/update) همچنان کد خروج ۱ می‌دهد —
        // فقط آزادسازی قفل با finally تضمین شده است.
        return $completed ? 0 : 1;
    }

    /**
     * FIX-P3-CMD-117: بدنهٔ مهاجرت استخراج شد تا قفل دور کل حلقه بماند و در
     * هر خروجی (شامل returnهای میانی) با finally آزاد شود.
     *
     * @param list<string> $secretKeys
     * @return bool true = همهٔ ردیف‌ها پردازش شد؛ false = شکست (seal/update)
     */
    private function migrateRows(array $secretKeys, bool $dryRun, bool $quiet, int &$scanned, int &$migrated): bool
    {
        // فقط ردیف‌های موجود و غیرخالی — هیچ INSERT ردیف‌های پیش‌فرض انجام نمی‌شود
        $placeholders = implode(',', array_fill(0, count($secretKeys), '?'));
        $rows = $this->db->fetchAll(
            "SELECT id, `key`, value FROM system_settings WHERE `key` IN ({$placeholders})",
            $secretKeys
        );

        $scanned = 0;
        $migrated = 0;
        foreach ($rows as $row) {
            $scanned++;
            $value = (string)($row->value ?? '');
            if ($value === '' || SecretBox::isEncrypted($value)) {
                continue; // خالی = پاک‌کردن؛ پاکت‌شده = idempotency
            }
            try {
                $sealed = SecretBox::encrypt($value);
            } catch (\Throwable $e) {
                // fail-closed: APP_KEY غایب/خراب → ردیف دست‌نخورده؛ plaintext به‌زور مهاجرت نمی‌شود
                $this->logger->error('settings.migrate_secrets.seal_failed', [
                    'key'   => (string)$row->key,
                    'error' => $e->getMessage(),
                ]);
                // FIX-P3-CMD-120 (یافتهٔ ۱۲۰): نام کلید تنظیم و متن خام استثنا از
                // خروجی operator حذف شد — پیام عمومی + شناسهٔ کوتاه md5؛ جزئیات و
                // نام کلید فقط در لاگ ساختاریافتهٔ بالا می‌ماند.
                if (!$quiet) {
                    echo "FAIL: seal failed for a settings row (details in logs, id: "
                        . substr(md5((string)$e->getMessage()), 0, 12) . ")\n";
                }
                return false;
            }
            if ($dryRun) {
                if (!$quiet) { echo "DRY: {$row->key} مهاجرت می‌شد\n"; }
                $migrated++;
                continue;
            }

            // FIX-CMD116 (یافتهٔ ۱۱۶): خواندن بدون قفل + نوشتن جدا = lost update —
            // read-modify-write هر ردیف اکنون داخل تراکنش با SELECT ... FOR UPDATE روی
            // همان اتصال Database انجام می‌شود (الگوی SettingsManager::set): مقدار
            // «تازه» دوباره خوانده، اعتبارسنجی و تحت همان قفل نوشته می‌شود؛ مسیر
            // updateValueById از همان singleton Database می‌گذرد و UPDATE داخل
            // تراکنش شرکت می‌کند.
            $this->db->beginTransaction();
            try {
                $fresh = $this->db->fetch(
                    "SELECT id, `key`, value FROM system_settings WHERE id = ? FOR UPDATE",
                    [(int)$row->id]
                );
                if ($fresh === null) {
                    // ردیف بین اسکن و قفل حذف شده — کاری نیست
                    $this->db->rollback();
                    continue;
                }
                $freshValue = (string)($fresh->value ?? '');
                if ($freshValue === '' || SecretBox::isEncrypted($freshValue)) {
                    // هم‌زمان خالی/پاکت شده — idempotent، بدون نوشتن، فقط آزادسازی قفل
                    $this->db->commit();
                    continue;
                }
                // مسیر خانه (درس میدانی 2026-09-12): نوشتن مستقیم DB کش system:settings:v2
                // را کهنه می‌گذارد — SettingsManager::updateValueById هم مهر می‌کند و هم
                // SettingsUpdated را دیسپچ می‌کند (ClearSettingsCache کش را می‌شوید).
                $mgr = $this->settingsManager;
                if ($mgr !== null) {
                    // ⚠️ امضای متد: updateValueById(int $id, string $value, ?string $key = null)
                    // (درس میدانی: ترتیب (id, key, value) نام کلید را به‌جای مقدار مهر می‌کرد)
                    $ok = $mgr->updateValueById((int)$fresh->id, $freshValue, (string)$fresh->key);
                    if (!$ok) {
                        throw new \RuntimeException('settings row update affected 0 rows');
                    }
                } else {
                    // fallback بدون منیجر (تست‌های ایزوله)
                    // FIX-P3-CMD-118 (یافتهٔ ۱۱۸): کار رمزنگاری دوباره حذف شد — مقدار
                    // زیرِ قفل همان مقدارِ زمانِ اسکن است (idempotency گارد بالا)؛
                    // پاکت آمادهٔ $sealed بازاستفاده می‌شود (اگر ردیف بین‌راه تغییر کند،
                    // مقدار تازه دوباره مهر می‌شود — صحت مقدم بر صرفه است).
                    $sealedForWrite = $freshValue === $value ? $sealed : SecretBox::encrypt($freshValue);
                    // FIX-P3-CMD-119 (یافتهٔ ۱۱۹): fallback دیگر در production مجاز نیست —
                    // نوشتن مستقیم DB بدون SettingsUpdated، کش system:settings:v2 را کهنه
                    // می‌گذاشت و مسیر خواندن secret «تا ابطال کش» مقدار plaintext قبلی را
                    // برمی‌گرداند. در production fail-closed؛ در غیر-production پس از
                    // نوشتن، کش best-effort باطل می‌شود.
                    if ($this->isProductionEnv()) {
                        throw new \RuntimeException('SettingsManager unavailable in production — direct-DB fallback would leave the settings cache stale (fail-closed).');
                    }
                    $this->db->execute(
                        'UPDATE system_settings SET value = ? WHERE id = ?',
                        [$sealedForWrite, (int)$fresh->id]
                    );
                    $this->flushSettingsCacheBestEffort();
                }
                $this->db->commit();
            } catch (\Throwable $e) {
                if ($this->db->inTransaction()) {
                    $this->db->rollback();
                }
                $this->logger->error('settings.migrate_secrets.update_failed', [
                    'key'   => (string)$row->key,
                    'error' => $e->getMessage(),
                ]);
                if (!$quiet) { echo "FAIL: update failed for a settings row (details in logs)\n"; }
                return false;
            }

            $migrated++;
            $this->logger->info('settings.migrate_secrets.migrated', ['key' => (string)$row->key]);
            if (!$quiet) { echo "MIGRATED: {$row->key}\n"; }
        }

        return true;
    }
}
