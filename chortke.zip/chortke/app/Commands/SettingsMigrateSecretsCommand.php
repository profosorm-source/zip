<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Services\Settings\SecretBox;
use App\Services\Settings\SettingsCatalog;
use App\Services\Settings\SettingsManager;
use Core\Database;

/**
 * 🛡️ X385 (راند ۱۰۴) — مهاجرت نرم plaintext میراثی → پاکت CHBSEC1.
 *
 * چرا؟ از راند X371 مسیرِ «نوشتن» مقادیر secret را با پاکت CHBSEC1 مهر می‌کند
 * و مسیر «خواندن» پاکت را شفاف باز می‌کند؛ ولی ردیف‌هایی که پیش از X371 با
 * plaintext ذخیره شده بودند به‌صورت ماندگار plaintext می‌ماندند (فقط با خوانش
 * شفاف کار می‌کردند). این دستور آن‌ها را یک‌جا — و لَخت (idempotent) — مهاجرت
 * می‌دهد: مقدار plaintext میراثی داخل پاکت CHBSEC1 می‌رود؛ مقدار خالی و
 * پاکت‌شده دست‌نخورده می‌ماند.
 *
 * چرا «نرم»؟
 *  - هیچ سرویسی restart نمی‌خواهد (پاکت self-describing است؛ مسیر خواندن از قبل
 *    هر دو حالت را می‌فهمد — X371).
 *  - هیچ رازی بازتولید نمی‌شود؛ همان مقدار بایت‌به‌بایت داخل پاکت می‌رود.
 *  - APP_KEY غایب → fail-closed: مهاجرت بدون هیچ تغییری متوقف می‌شود.
 *  - idempotent: اجرای تکراری صفر مهاجرت دیگر گزارش می‌کند (خروجی مناسب
 *    ensure-stack: هیچ‌کاری/هیچ‌خروجی‌ای وقتی کار نیست).
 *
 * مصرف:
 *   php cli.php settings:migrate-secrets            (اجرا)
 *   php cli.php settings:migrate-secrets --dry-run  (فقط گزارش)
 *   در سندباکس: ensure-stack پس از migration این را با --quiet اجرا می‌کند.
 */
final class SettingsMigrateSecretsCommand
{
    private Database $db;
    private LoggerInterface $logger;
    private ?SettingsManager $settingsManager;

    public function __construct(Database $db, LoggerInterface $logger, ?SettingsManager $settingsManager = null)
    {
        $this->db = $db;
        $this->logger = $logger;
        $this->settingsManager = $settingsManager;
    }

    /** @param array<int, string> $argv */
    public function run(array $argv = []): int
    {
        $dryRun = in_array('--dry-run', $argv, true);
        $quiet  = in_array('--quiet', $argv, true);

        // کلیدهای نوع secret از منبع واحد حقیقت (کاتالوگ) — نه حدس الگویی
        $secretKeys = [];
        foreach (SettingsCatalog::all() as $category) {
            foreach (is_array($category) ? $category : [] as $entry) {
                if (is_array($entry)
                    && isset($entry['key'], $entry['type'])
                    && strtolower(trim((string)$entry['type'])) === 'secret') {
                    $secretKeys[] = (string)$entry['key'];
                }
            }
        }
        $secretKeys = array_values(array_unique($secretKeys));
        if ($secretKeys === []) {
            if (!$quiet) { echo "settings:migrate-secrets — کلید secret در کاتالوگ نیست؛ کاری نیست.\n"; }
            return 0;
        }

        // فقط ردیف‌های موجود و غیرخالی — هیچ INSERT ردیف‌های پیش‌فرض انجام نمی‌شود
        $placeholders = implode(',', array_fill(0, count($secretKeys), '?'));
        $rows = $this->db->fetchAll(
            "SELECT id, `key`, value FROM system_settings WHERE `key` IN ({$placeholders})",
            $secretKeys
        );

        $scanned = 0;
        $migrated = 0;
        foreach ($rows as $row) {
            $scanned++;
            $value = (string)($row->value ?? '');
            if ($value === '' || SecretBox::isEncrypted($value)) {
                continue; // خالی = پاک‌کردن؛ پاکت‌شده = idempotency
            }
            try {
                $sealed = SecretBox::encrypt($value);
            } catch (\Throwable $e) {
                // fail-closed: APP_KEY غایب/خراب → ردیف دست‌نخورده؛ plaintext به‌زور مهاجرت نمی‌شود
                $this->logger->error('settings.migrate_secrets.seal_failed', [
                    'key'   => (string)$row->key,
                    'error' => $e->getMessage(),
                ]);
                if (!$quiet) { echo "FAIL: seal {$row->key} — {$e->getMessage()}\n"; }
                return 1;
            }
            if ($dryRun) {
                if (!$quiet) { echo "DRY: {$row->key} مهاجرت می‌شد\n"; }
                $migrated++;
                continue;
            }
            // مسیر خانه (درس میدانی 2026-09-12): نوشتن مستقیم DB کش system:settings:v2
            // را کهنه می‌گذارد — SettingsManager::updateValueById هم مهر می‌کند و هم
            // SettingsUpdated را دیسپچ می‌کند (ClearSettingsCache کش را می‌شوید).
            $mgr = $this->settingsManager;
            if ($mgr !== null) {
                // ⚠️ امضای متد: updateValueById(int $id, string $value, ?string $key = null)
                // (درس میدانی: ترتیب (id, key, value) نام کلید را به‌جای مقدار مهر می‌کرد)
                $ok = $mgr->updateValueById((int)$row->id, $value, (string)$row->key);
                if (!$ok) {
                    $this->logger->error('settings.migrate_secrets.update_failed', ['key' => (string)$row->key]);
                    if (!$quiet) { echo "FAIL: update {$row->key}\n"; }
                    return 1;
                }
            } else {
                // fallback بدون منیجر (تست‌های ایزوله): کش کهنه می‌ماند — فقط برای محیط‌های بدون ردیس
                $this->db->execute('UPDATE system_settings SET value = ? WHERE id = ?', [SecretBox::encrypt($value), (int)$row->id]);
            }
            $migrated++;
            $this->logger->info('settings.migrate_secrets.migrated', ['key' => (string)$row->key]);
            if (!$quiet) { echo "MIGRATED: {$row->key}\n"; }
        }

        if (!$quiet) {
            echo "settings:migrate-secrets — scanned={$scanned} migrated={$migrated}"
                . ($dryRun ? ' (dry-run)' : '') . "\n";
        }
        if ($migrated > 0 && !$dryRun) {
            $this->logger->info('settings.migrate_secrets.completed', [
                'scanned' => $scanned, 'migrated' => $migrated, 'dry_run' => false,
            ]);
        }
        return 0;
    }
}
