<?php

declare(strict_types=1);

namespace App\Commands;

/**
 * ═══════════════════════════════════════════════════════════════════
 * FIX-DB-12 / FIX-DB-16 (راند ۱۲) — Preflight داده برای قیود مالی
 * ═══════════════════════════════════════════════════════════════════
 *
 * پیشینه (گزارش ماژول ۵): قیود UNIQUE/FK مالی در زنجیره با dedupe
 * «نگه‌داشتن کمترین id» اجرا شده‌اند؛ بین cleanup و DDL یک concurrent
 * writer می‌تواند duplicate تازه بسازد و unique(int) روی ستون nullable
 * ردیف‌های NULL را یکتا نمی‌کند (investment_profits.trading_record_id).
 * گزارش خواستار «duplicate/orphan preflight، گزارش و recovery» است.
 *
 * این کامند read-only است (هیچ write، هیچ DDL، هیچ lock جدولی) و
 * پیش از اجرای migration/استقرار قابل استفاده است:
 *   php cli.php migration:preflight
 *
 * خروجی: گزارش structured + exit_code (قرارداد FIX-C141):
 *   ۰ = داده تمیز؛ ۱ = duplicate/orphan/ناسازگاری ارزی یافت شد
 * (CI/cron می‌تواند گیت کند).
 *
 * پوشش:
 *   ۱) payment_logs.idempotency_key تکراری زنده (قید 2026_08_24_0003)
 *   ۲) escrow_transactions.active_order_key تکراری زنده (2026_08_24_0002)
 *   ۳) content_revenues زندهٔ تکراری (submission_id, period) (2026_09_21_0002)
 *   ۴) investment_profits تکراری (trading_record_id, investment_id) +
 *      هشدار NULL-uniqueness ستون nullable (2026_08_15_0006)
 *   ۵) orphan references به users (transactions/withdrawals/investments/
 *      escrow_transactions/social_accounts) — پیش‌نیاز هر FK سخت‌گیرتر
 *   ۶) audit واحد ارزی (FIX-DB-16): ارزهای غیرکانونی در
 *      transactions/wallets — تبدیل عددی بدون اثبات واحدِ تاریخی ممنوع؛
 *      این audit فقط count/فهرست می‌دهد
 *   ۷) duplicate sequence prefixes migrationها (FIX-DB-18، دید CLI)
 */
class MigratePreflightCommand
{
    /** @var list<array<string, mixed>> */
    private array $rows = [];

    public function __construct() {}

    /** @param list<string> $args */
    public function run(array $args = []): int
    {
        $db = \Core\Database::getInstance();
        $this->rows = [];
        $failures = 0;

        $failures += $this->checkDuplicate($db, 'payment_logs.idempotency_key (قید 2026_08_24_0003)',
            "SELECT idempotency_key AS k, COUNT(*) c FROM payment_logs
              WHERE idempotency_key IS NOT NULL GROUP BY idempotency_key HAVING c > 1 LIMIT 20",
            "SELECT COUNT(*) FROM (SELECT idempotency_key FROM payment_logs WHERE idempotency_key IS NOT NULL GROUP BY idempotency_key HAVING COUNT(*) > 1) t");

        $failures += $this->checkDuplicate($db, 'escrow_transactions.active_order_key زنده (قید 2026_08_24_0002)',
            "SELECT active_order_key AS k, COUNT(*) c FROM escrow_transactions
              WHERE active_order_key IS NOT NULL GROUP BY active_order_key HAVING c > 1 LIMIT 20",
            "SELECT COUNT(*) FROM (SELECT active_order_key FROM escrow_transactions WHERE active_order_key IS NOT NULL GROUP BY active_order_key HAVING COUNT(*) > 1) t");

        $failures += $this->checkDuplicate($db, 'content_revenues زندهٔ تکراری (submission_id, period)',
            "SELECT submission_id, period, COUNT(*) c FROM content_revenues
              WHERE is_deleted = 0 GROUP BY submission_id, period HAVING c > 1 LIMIT 20",
            "SELECT COUNT(*) FROM (SELECT submission_id, period FROM content_revenues WHERE is_deleted = 0 GROUP BY submission_id, period HAVING COUNT(*) > 1) t",
            true);

        $failures += $this->checkDuplicate($db, 'investment_profits تکراری (trading_record_id, investment_id)',
            "SELECT trading_record_id, investment_id, COUNT(*) c FROM investment_profits
              WHERE trading_record_id IS NOT NULL GROUP BY trading_record_id, investment_id HAVING c > 1 LIMIT 20",
            "SELECT COUNT(*) FROM (SELECT trading_record_id, investment_id FROM investment_profits WHERE trading_record_id IS NOT NULL GROUP BY trading_record_id, investment_id HAVING COUNT(*) > 1) t",
            true);

        // nullable-unique warning (رفتار MySQL: چند NULL در unique مجاز است)
        $nullPairs = $this->scalar($db, "SELECT COUNT(*) FROM investment_profits WHERE trading_record_id IS NULL");
        if ($nullPairs > 0) {
            $this->row('WARN', 'investment_profits.trading_record_id NULL',
                ["null_rows" => $nullPairs,
                 'note' => 'unique (trading_record_id, investment_id) چند NULL را یکتا نمی‌کند — ردیف‌های بدون trade تحت قید نیستند (رفتار engine، نه نقص داده)']);
        }

        $failures += $this->checkOrphans($db, 'transactions.user_id',
            "SELECT COUNT(*) c FROM transactions t LEFT JOIN users u ON u.id = t.user_id WHERE t.user_id IS NOT NULL AND u.id IS NULL");
        $failures += $this->checkOrphans($db, 'withdrawals.user_id',
            "SELECT COUNT(*) c FROM withdrawals w LEFT JOIN users u ON u.id = w.user_id WHERE u.id IS NULL");
        $failures += $this->checkOrphans($db, 'investments.user_id',
            "SELECT COUNT(*) c FROM investments i LEFT JOIN users u ON u.id = i.user_id WHERE u.id IS NULL");
        $failures += $this->checkOrphans($db, 'escrow_transactions.buyer_id/seller_id',
            "SELECT COUNT(*) c FROM escrow_transactions e LEFT JOIN users ub ON ub.id = e.buyer_id LEFT JOIN users us ON us.id = e.seller_id WHERE (e.buyer_id IS NOT NULL AND ub.id IS NULL) OR (e.seller_id IS NOT NULL AND us.id IS NULL)");
        $failures += $this->checkOrphans($db, 'social_accounts.user_id',
            "SELECT COUNT(*) c FROM social_accounts sa LEFT JOIN users u ON u.id = sa.user_id WHERE u.id IS NULL");

        // FIX-DB-16: audit واحد ارزی (فقط گزارش — تبدیل عددی تصمیم اپراتور است)
        $badCurrency = $this->scalar($db, "SELECT COUNT(*) FROM transactions WHERE currency IS NOT NULL AND LOWER(currency) NOT IN ('irt','usdt')");
        if ($badCurrency > 0) {
            $failures++;
            $this->row('FAIL', 'transactions.currency خارج از کانونی (irt/usdt)', ['rows' => $badCurrency,
                'note' => 'FIX-DB-16: تبدیل عددی بدون اثبات واحد تاریخی انجام نشود — audit جدول‌به‌جدول الزامی است']);
        } else {
            $this->row('OK', 'transactions.currency همگی کانونی (irt/usdt)', []);
        }
        $ricCnt = $this->scalar($db, "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE table_schema = DATABASE() AND table_name = 'investments' AND column_name = 'current_balance' AND (numeric_scale IS NULL OR numeric_scale < 8)");
        if ($ricCnt > 0) {
            $this->row('WARN', 'investments.current_balance دقت < 8 (FIX-DB-03 هنوز اجرا نشده؟)', ['columns' => $ricCnt]);
        }

        // FIX-DB-18: duplicate prefixes — دید CLI بدون اجرای migrate
        $mDir = realpath(__DIR__ . '/../../database/migrations') ?: null;
        if ($mDir !== null) {
            $prefixGroups = [];
            foreach ((glob($mDir . '/*.sql') ?: []) + (glob($mDir . '/*.php') ?: []) as $f) {
                if (preg_match('/^(2026_\d{2}_\d{2}_\d{4})_/', (string) basename((string) $f), $m) === 1) {
                    $prefixGroups[$m[1]][] = basename((string) $f);
                }
            }
            $dups = array_filter($prefixGroups, static fn (array $v): bool => count($v) > 1);
            if ($dups !== []) {
                $this->row('WARN', 'duplicate sequence prefixes (FIX-DB-18)', [
                    'prefixes' => implode(', ', array_keys($dups)),
                    'note' => 'runner با نام کامل track می‌کند؛ برای بازبینی/rollback دستی sequence یکتا بدهید']);
            }
        }

        // ── گزارش ──
        fwrite(STDOUT, "\n=== Chortke Migration Preflight (read-only) ===\n");
        foreach ($this->rows as $r) {
            fwrite(STDOUT, sprintf("[%s] %s%s\n", $r['level'], $r['check'], isset($r['detail']) && $r['detail'] !== '' ? " :: {$r['detail']}" : ''));
        }
        fwrite(STDOUT, sprintf("\nSummary: %d check group(s), %d FAIL\n", count($this->rows), $failures));
        return $failures > 0 ? 1 : 0;
    }

    private function scalar(\Core\Database $db, string $sql): int
    {
        try {
            return (int) ($db->fetchColumn($sql) ?? 0);
        } catch (\Throwable $e) {
            $this->row('WARN', 'check skipped (schema mismatch — معمولاً روی DB نیمه‌راه)', ['error' => $e->getMessage()]);
            return 0;
        }
    }

    /** @return int تعداد FAILها */
    private function checkDuplicate(\Core\Database $db, string $label, string $sampleSql, string $countSql, bool $twoCols = false): int
    {
        $count = $this->scalar($db, $countSql);
        if ($count === 0) {
            $this->row('OK', $label, []);
            return 0;
        }
        $detail = "duplicate_groups={$count}";
        try {
            $samples = (array) $db->fetchAll($sampleSql);
            $flat = [];
            foreach (array_slice($samples, 0, 5) as $s) {
                $arr = (array) $s;
                if ($twoCols) {
                    $flat[] = "#{$arr['submission_id']}/{$arr['period']} x{$arr['c']}";
                } else {
                    $flat[] = "{$arr['k']} x{$arr['c']}";
                }
            }
            if ($flat !== []) {
                $detail .= ' [' . implode('; ', $flat) . ']';
            }
        } catch (\Throwable) {}
        $this->row('FAIL', $label, ['detail' => $detail,
            'note' => 'پیش از اجرای migration قیددار: dedupe با سیاست تأییدشدهٔ business + quiesce نویسنده + آرشیو ردیف‌های حذفشده']);
        return 1;
    }

    /** @return int تعداد FAILها */
    private function checkOrphans(\Core\Database $db, string $label, string $countSql): int
    {
        $count = $this->scalar($db, $countSql);
        if ($count === 0) {
            $this->row('OK', "orphan-free: {$label}", []);
            return 0;
        }
        $this->row('FAIL', "orphan: {$label}", ['orphans' => $count,
            'note' => 'پیش از FK سخت‌گیرتر یا حذف فیزیکی: repair/reject orphanها؛ ledger را archive کنید، cascade نکنید']);
        return 1;
    }

    /** @param array<string, mixed> $fields */
    private function row(string $level, string $check, array $fields): void
    {
        $detail = '';
        if (isset($fields['detail']) && is_string($fields['detail'])) {
            $detail = $fields['detail'];
            unset($fields['detail']);
        }
        $extra = [];
        foreach ($fields as $k => $v) {
            if (is_scalar($v)) {
                $extra[] = "{$k}=" . (string) $v;
            }
        }
        if ($extra !== []) {
            $detail = $detail === '' ? implode(' ', $extra) : ($detail . ' ' . implode(' ', $extra));
        }
        $this->rows[] = ['level' => $level, 'check' => $check, 'detail' => $detail];
    }
}
