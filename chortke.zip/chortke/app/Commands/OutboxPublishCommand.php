<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Services\DistributedLockService;
use App\Services\OutboxPublisher;

/**
 * CLI entry point for the OutboxPublisher (Section 8.1 — transactional outbox).
 *
 * Usage:
 *   php cli.php outbox:publish [--limit=50] [--sleep=5]
 *
 * حالت پیش‌فرض تک‌مرحله‌ای است (تست/cron)؛ با --sleep=N به حلقهٔ دائمی
 * supervisor تبدیل می‌شود و بین نظرسنجی‌های خالی sleep می‌کند.
 */
class OutboxPublishCommand
{
    /** FIX-P3-CMD-066 (یافتهٔ ۰۶۶): آستانهٔ abort دیمن — بعد از این تعداد شکست متوالی،
     * حلقه بی‌نهایت (فقط با backoff کُندتر) ادامه نمی‌دهد؛ خروج تمیز تا supervisor
     * ری‌استارت کند و فشارِ خطای پایدار به سطح مدیریت برود. */
    private const MAX_CONSECUTIVE_FAILURES = 10;

    private OutboxPublisher $publisher;
    private LoggerInterface $logger;
    private ?DistributedLockService $lockService;

    /**
     * FIX-CMD065 (یافتهٔ ۰۶۵): فلگ خاموشی نرم دیمن — SIGTERM/SIGINT این فلگ را
     * می‌گذارد و حلقه بعد از پایان دورِ جاری، تمیز خارج می‌شود (بدون قطعِ
     * وسطِ پابلیش/تراکنش).
     */
    private bool $stopRequested = false;

    public function __construct(
        OutboxPublisher $publisher,
        LoggerInterface $logger,
        ?DistributedLockService $lockService = null
    ) {
        $this->publisher = $publisher;
        $this->logger = $logger;
        $this->lockService = $lockService;
    }

    private function isProductionEnv(): bool
    {
        return (config('app.env') === 'production' || env('APP_ENV') === 'production');
    }

    /** @param array<int|string, mixed> $argv */

    public function run(array $argv): void
    {
        $limit = 50;
        $sleep = null;
        foreach ($argv as $arg) {
            if (is_string($arg)) {
                if (str_starts_with($arg, '--limit=')) {
                    $limit = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--sleep=')) {
                    $sleep = (int)substr($arg, 8);
                }
            }
        }
        $limit = max(1, min(500, $limit));
        $sleep = ($sleep === null) ? null : max(1, min(300, $sleep));

        // FIX-9a-4 (Audit Task 9-a): fail-closed روی خطای قفل در production —
        // پیش از هر پابلیشی سلامتِ lock backend سنجیده می‌شود.
        $this->assertLockBackendAvailableInProduction();

        if ($sleep !== null) {
            $this->runDaemonLoop($limit, $sleep);
            return;
        }

        try {
            // FIX-CMD063 (یافتهٔ ۰۶۳): در production پابلیشِ خودِ publisher هم
            // fail-closed اجرا می‌شود (نه فقط probe) — قطعِ backend قفل بعد از
            // probe دیگر پابلیشِ بدون قفل نمی‌سازد؛ در غیر-production fail-open مستند.
            $result = $this->publisher->publishPending($limit, $this->isProductionEnv());
            $this->logger->info('outbox.cli.publish.completed', $result);

            $published = int_value($result['published'] ?? 0);
            $failed    = int_value($result['failed'] ?? 0);
            $skippedValue = $result['skipped'] ?? null;

            // FIX-CMD068 (یافتهٔ ۰۶۸): شکلِ skipped نرمال شد — قبلاً فقط رشته
            // نمایش داده می‌شد و bool true (نشان busy بودن قفل publisher) بی‌صدا
            // حذف می‌شد و خروجی کرون گمراه‌کننده می‌شد.
            if ($skippedValue === true) {
                echo "[outbox] skipped: publisher lock busy (another instance active)\n";
                return;
            }
            if (is_string($skippedValue) && $skippedValue !== '') {
                echo "[outbox] skipped: {$skippedValue}\n";
                return;
            }
            echo "[outbox] published={$published} failed={$failed} (limit={$limit})\n";
        } catch (\Throwable $e) {
            // FIX-P3-CMD-067 (یافتهٔ ۰۶۷): stderr دیگر متن کامل استثنا را نمی‌برد —
            // پیام عمومی + شناسهٔ کوتاه md5؛ جزئیات ماسک‌شده (کلاس/فایل/خط) در لاگ
            // ساختاریافته با همان شناسه قابل‌ردیابی است.
            $this->logger->error('outbox.cli.publish.failed', [
                'error' => $e->getMessage(),
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
            fwrite(STDERR, "[outbox] error: outbox publish failed (details in logs, id: "
                . substr(md5((string)$e->getMessage()), 0, 12) . ")\n");
            exit(1);
        }
    }

    /**
     * FIX-9a-4 (Audit Task 9-a): fail-closed روی خطای acquisition قفل در production.
     *
     * پیشینه: OutboxPublisher خطای acquisition قفل را catch و با fail-open مستند
     * ادامه می‌دهد (OutboxPublisher::publishPending — پارامتر failClosed=false). در
     * production پابلیشِ بدون ناظرِ قفلِ سالم، هم‌پوشانی دو publisher و ریسک
     * دابل‌پابلیش را باز می‌گذارد. فرمان CLI پیش از هر دورِ publish با یک probe
     * fail-closed (acquire با failClosed=true — فقط وقتی backend قفل واقعاً
     * در دسترس نیست پرتاب می‌کند) سلامتِ backend را می‌آزماید؛ خطا ⇒ خروج با کد
     * غیرصفر (supervisor/cron ری‌استارت می‌کند) و هرگز بدون قفلِ قابل‌اتکا پابلیش
     * نمی‌شود. probe یک قفل کوتاه‌عمر مستقل با release توکن‌دار است و مزاحم قفل
     * publisher ('outbox_publisher') نمی‌شود. در غیر production (تست/local)
     * رفتار قبلی حفظ می‌شود و probe انجام نمی‌شود.
     */
    private function assertLockBackendAvailableInProduction(): void
    {
        $isProduction = $this->isProductionEnv();
        if (!$isProduction) {
            return;
        }

        // FIX-CMD062 (یافتهٔ ۰۶۲): production بدون DistributedLockService =
        // پیکربندی ناقص؛ قبلاً این گارد خودش را بی‌اثر می‌کرد (lockService===null
        // ⇒ return بی‌صدا) و پابلیش بدون ناظر قفل ادامه می‌یافت (fail-open).
        // اکنون fail-closed است: خروج با کد غیرصفر تا supervisor/cron مشکل را
        // آشکار کند — پیکربندی ناقص هرگز بی‌صدا از گارد عبور نمی‌کند.
        if ($this->lockService === null) {
            $this->logger->critical('outbox.cli.lock_service_missing_in_production', []);
            fwrite(STDERR, "[outbox] FATAL: DistributedLockService not configured in production — refusing to publish (fail-closed).\n");
            exit(1);
        }

        $lock = null;
        try {
            $lock = $this->lockService->acquire('outbox_command_probe', 5, 0, true);
        } catch (\Throwable $e) {
            $this->logger->critical('outbox.cli.lock_backend_unavailable', [
                'error' => $e->getMessage(),
            ]);
            fwrite(STDERR, "[outbox] FATAL: lock backend unavailable in production — refusing to publish without a reliable lock (fail-closed).\n");
            exit(1);
        } finally {
            $token = is_array($lock) ? ($lock['token'] ?? null) : null;
            if (is_string($token) && $token !== '' && $this->lockService !== null) {
                try {
                    $this->lockService->release('outbox_command_probe', $token);
                } catch (\Throwable $ignored) {
                    // probe کوتاه‌عمر (TTL 5s) است — شکست release بی‌ضرر
                }
            }
        }
    }

    /**
     * حلقهٔ دیمن برای supervisor (outbox:publish --limit=100 --sleep=5) —
     * بدون این حلقه، کامند بلافاصله خارج می‌شود و supervisor پس از ری‌استارت‌های
     * سریع (startretries=10) برنامه را FATAL می‌کند و انتشار outbox متوقف می‌شود.
     */
    private function runDaemonLoop(int $limit, int $sleep): void
    {
        $this->logger->info('outbox.cli.publish.daemon_starting', [
            'limit' => $limit,
            'sleep' => $sleep
        ]);

        // FIX-CMD065: نصب هندلر سیگنال — SIGTERM (supervisor stop) و SIGINT (Ctrl+C)
        // خاموشی نرم را آغاز می‌کنند. اگر pcntl در دسترس نبود، رفتار قبلی حفظ می‌شود.
        if (function_exists('pcntl_async_signals')) {
            pcntl_async_signals(true);
            foreach ([defined('SIGTERM') ? constant('SIGTERM') : 15, defined('SIGINT') ? constant('SIGINT') : 2] as $sig) {
                pcntl_signal($sig, function (int $signo): void {
                    $this->stopRequested = true;
                    $this->logger->info('outbox.cli.publish.shutdown_requested', ['signal' => $signo]);
                });
            }
        }

        // FIX-C142 (یافتهٔ ۱۴۲): backoff نمایی برای شکست‌های متوالی — قبلاً هر
        // شکست فقط max(sleep,5) ثانیه صبر می‌کرد و در قطعِ طولانی DB/Redis،
        // حلقه با آهنگ ثابت ۵ثانیه‌ای CPU/log/probe را زیر فشار می‌برد.
        $consecutiveFailures = 0;

        // PS-fix: ایدیوم for(;;) برای حلقهٔ بی‌نهایتِ عمدی دیمن — رفتار runtime
        // دقیقاً برابر while(true) است؛ PHPStan «شرط همیشه-درست» را دیگر گزارش
        // نمی‌کند چون for بدون شرط، قرارداد استاندارد حلقهٔ عمدی است.
        for (;;) {
            // FIX-CMD065: بررسی فلگ خاموشی پیش از آغاز دور جدید
            if ($this->stopRequested) {
                $this->logger->info('outbox.cli.publish.graceful_shutdown', []);
                fwrite(STDOUT, "[outbox] graceful shutdown complete.\n");
                return;
            }

            // FIX-9a-4: probe در هر دور هم تکرار می‌شود تا قطعِ backend قفل در
            // میانهٔ کار دیمن هم fail-closed بماند (نه فقط در بوت).
            $this->assertLockBackendAvailableInProduction();

            try {
                // FIX-CMD063: در production پابلیش fail-closed است
                $result = $this->publisher->publishPending($limit, $this->isProductionEnv());
                $this->logger->info('outbox.cli.publish.completed', $result);
                $consecutiveFailures = 0;

                // فقط وقتی هیچ رویداد قابل انتشار نیست صبر می‌کنیم
                $activity = int_value($result['published'] ?? 0) + int_value($result['failed'] ?? 0);
                if ($activity === 0) {
                    sleep($sleep);
                }
            } catch (\Throwable $e) {
                // خطای زیرساختی موقت: دیمن زنده می‌ماند و با فاصلهٔ نمایی ادامه می‌دهد
                $consecutiveFailures++;
                $backoff = min(60, max($sleep, 5) * (2 ** min($consecutiveFailures, 4)));
                $this->logger->error('outbox.cli.publish.daemon_iteration_failed', [
                    'error' => $e->getMessage(),
                    'consecutive_failures' => $consecutiveFailures,
                    'backoff_seconds' => $backoff,
                ]);

                // FIX-P3-CMD-066 (یافتهٔ ۰۶۶): شکستِ پایدار دیگر بی‌نهایت ادامه نمی‌یابد —
                // بعد از آستانه، خروج تمیز (supervisor restart)؛ فقط log+sleep کند،
                // نه حلقهٔ بی‌نهایت.
                if ($consecutiveFailures >= self::MAX_CONSECUTIVE_FAILURES) {
                    $this->logger->critical('outbox.cli.publish.daemon_aborted', [
                        'consecutive_failures' => $consecutiveFailures,
                        'last_error' => $e->getMessage(),
                    ]);
                    fwrite(STDOUT, "[outbox] aborting daemon after {$consecutiveFailures} consecutive failures — supervisor restart expected.\n");
                    return;
                }

                sleep($backoff);
            }

            // FIX-CMD065: پایان تمیز پس از دور جاری — نه وسط پابلیش
            if ($this->stopRequested) {
                $this->logger->info('outbox.cli.publish.graceful_shutdown', []);
                fwrite(STDOUT, "[outbox] graceful shutdown complete.\n");
                return;
            }
        }
    }
}
