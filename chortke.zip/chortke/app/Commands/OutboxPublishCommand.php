<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Services\DistributedLockService;
use App\Services\OutboxPublisher;

/**
 * CLI entry point for the OutboxPublisher (Section 8.1 — transactional outbox).
 *
 * Usage:
 *   php cli.php outbox:publish [--limit=50] [--sleep=5]
 *
 * حالت پیش‌فرض تک‌مرحله‌ای است (تست/cron)؛ با --sleep=N به حلقهٔ دائمی
 * supervisor تبدیل می‌شود و بین نظرسنجی‌های خالی sleep می‌کند.
 */
class OutboxPublishCommand
{
    private OutboxPublisher $publisher;
    private LoggerInterface $logger;
    private ?DistributedLockService $lockService;
    public function __construct(
        OutboxPublisher $publisher,
        LoggerInterface $logger,
        ?DistributedLockService $lockService = null
    ) {
        $this->publisher = $publisher;
        $this->logger = $logger;
        $this->lockService = $lockService;
    }

    /** @param array<int|string, mixed> $argv */

    public function run(array $argv): void
    {
        $limit = 50;
        $sleep = null;
        foreach ($argv as $arg) {
            if (is_string($arg)) {
                if (str_starts_with($arg, '--limit=')) {
                    $limit = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--sleep=')) {
                    $sleep = (int)substr($arg, 8);
                }
            }
        }
        $limit = max(1, min(500, $limit));
        $sleep = ($sleep === null) ? null : max(1, min(300, $sleep));

        // FIX-9a-4 (Audit Task 9-a): fail-closed روی خطای قفل در production —
        // پیش از هر پابلیشی سلامتِ lock backend سنجیده می‌شود.
        $this->assertLockBackendAvailableInProduction();

        if ($sleep !== null) {
            $this->runDaemonLoop($limit, $sleep);
            return;
        }

        try {
            $result = $this->publisher->publishPending($limit);
            $this->logger->info('outbox.cli.publish.completed', $result);

            $published = int_value($result['published'] ?? 0);
            $failed    = int_value($result['failed'] ?? 0);
            $skippedValue = $result['skipped'] ?? null;
            $skipped = is_string($skippedValue) ? $skippedValue : null;

            if ($skipped) {
                echo "[outbox] skipped: {$skipped}\n";
                return;
            }
            echo "[outbox] published={$published} failed={$failed} (limit={$limit})\n";
        } catch (\Throwable $e) {
            $this->logger->error('outbox.cli.publish.failed', ['error' => $e->getMessage()]);
            fwrite(STDERR, "[outbox] error: " . $e->getMessage() . "\n");
            exit(1);
        }
    }

    /**
     * FIX-9a-4 (Audit Task 9-a): fail-closed روی خطای acquisition قفل در production.
     *
     * پیشینه: OutboxPublisher خطای acquisition قفل را catch و با fail-open مستند
     * ادامه می‌دهد (OutboxPublisher::publishPending — پارامتر failClosed=false). در
     * production پابلیشِ بدون ناظرِ قفلِ سالم، هم‌پوشانی دو publisher و ریسک
     * دابل‌پابلیش را باز می‌گذارد. فرمان CLI پیش از هر دورِ publish با یک probe
     * fail-closed (acquire با failClosed=true — فقط وقتی backend قفل واقعاً
     * در دسترس نیست پرتاب می‌کند) سلامتِ backend را می‌آزماید؛ خطا ⇒ خروج با کد
     * غیرصفر (supervisor/cron ری‌استارت می‌کند) و هرگز بدون قفلِ قابل‌اتکا پابلیش
     * نمی‌شود. probe یک قفل کوتاه‌عمر مستقل با release توکن‌دار است و مزاحم قفل
     * publisher ('outbox_publisher') نمی‌شود. در غیر production (تست/local)
     * رفتار قبلی حفظ می‌شود و probe انجام نمی‌شود.
     */
    private function assertLockBackendAvailableInProduction(): void
    {
        $isProduction = (config('app.env') === 'production' || env('APP_ENV') === 'production');
        if (!$isProduction || $this->lockService === null) {
            return;
        }

        $lock = null;
        try {
            $lock = $this->lockService->acquire('outbox_command_probe', 5, 0, true);
        } catch (\Throwable $e) {
            $this->logger->critical('outbox.cli.lock_backend_unavailable', [
                'error' => $e->getMessage(),
            ]);
            fwrite(STDERR, "[outbox] FATAL: lock backend unavailable in production — refusing to publish without a reliable lock (fail-closed).\n");
            exit(1);
        } finally {
            $token = is_array($lock) ? ($lock['token'] ?? null) : null;
            if (is_string($token) && $token !== '' && $this->lockService !== null) {
                try {
                    $this->lockService->release('outbox_command_probe', $token);
                } catch (\Throwable $ignored) {
                    // probe کوتاه‌عمر (TTL 5s) است — شکست release بی‌ضرر
                }
            }
        }
    }

    /**
     * حلقهٔ دیمن برای supervisor (outbox:publish --limit=100 --sleep=5) —
     * بدون این حلقه، کامند بلافاصله خارج می‌شود و supervisor پس از ری‌استارت‌های
     * سریع (startretries=10) برنامه را FATAL می‌کند و انتشار outbox متوقف می‌شود.
     */
    private function runDaemonLoop(int $limit, int $sleep): void
    {
        $this->logger->info('outbox.cli.publish.daemon_starting', [
            'limit' => $limit,
            'sleep' => $sleep
        ]);

        // PS-fix: ایدیوم for(;;) برای حلقهٔ بی‌نهایتِ عمدی دیمن — رفتار runtime
        // دقیقاً برابر while(true) است؛ PHPStan «شرط همیشه-درست» را دیگر گزارش
        // نمی‌کند چون for بدون شرط، قرارداد استاندارد حلقهٔ عمدی است.
        for (;;) {
            // FIX-9a-4: probe در هر دور هم تکرار می‌شود تا قطعِ backend قفل در
            // میانهٔ کار دیمن هم fail-closed بماند (نه فقط در بوت).
            $this->assertLockBackendAvailableInProduction();

            try {
                $result = $this->publisher->publishPending($limit);
                $this->logger->info('outbox.cli.publish.completed', $result);

                // فقط وقتی هیچ رویداد قابل انتشار نیست صبر می‌کنیم
                $activity = int_value($result['published'] ?? 0) + int_value($result['failed'] ?? 0);
                if ($activity === 0) {
                    sleep($sleep);
                }
            } catch (\Throwable $e) {
                // خطای زیرساختی موقت: دیمن زنده می‌ماند و با فاصله ادامه می‌دهد
                $this->logger->error('outbox.cli.publish.daemon_iteration_failed', [
                    'error' => $e->getMessage()
                ]);
                sleep(max($sleep, 5));
            }
        }
    }
}
