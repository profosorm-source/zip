<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Services\OutboxPublisher;

/**
 * CLI entry point for the OutboxPublisher (Section 8.1 — transactional outbox).
 *
 * Usage:
 *   php cli.php outbox:publish [--limit=50] [--sleep=5]
 *
 * حالت پیش‌فرض تک‌مرحله‌ای است (تست/cron)؛ با --sleep=N به حلقهٔ دائمی
 * supervisor تبدیل می‌شود و بین نظرسنجی‌های خالی sleep می‌کند.
 */
class OutboxPublishCommand
{
    private OutboxPublisher $publisher;
    private LoggerInterface $logger;
    public function __construct(
        OutboxPublisher $publisher,
        LoggerInterface $logger
    ) {        $this->publisher = $publisher;
        $this->logger = $logger;
}

    /** @param array<int|string, mixed> $argv */

    public function run(array $argv): void
    {
        $limit = 50;
        $sleep = null;
        foreach ($argv as $arg) {
            if (is_string($arg)) {
                if (str_starts_with($arg, '--limit=')) {
                    $limit = (int)substr($arg, 8);
                } elseif (str_starts_with($arg, '--sleep=')) {
                    $sleep = (int)substr($arg, 8);
                }
            }
        }
        $limit = max(1, min(500, $limit));
        $sleep = ($sleep === null) ? null : max(1, min(300, $sleep));

        if ($sleep !== null) {
            $this->runDaemonLoop($limit, $sleep);
            return;
        }

        try {
            $result = $this->publisher->publishPending($limit);
            $this->logger->info('outbox.cli.publish.completed', $result);

            $published = int_value($result['published'] ?? 0);
            $failed    = int_value($result['failed'] ?? 0);
            $skippedValue = $result['skipped'] ?? null;
            $skipped = is_string($skippedValue) ? $skippedValue : null;

            if ($skipped) {
                echo "[outbox] skipped: {$skipped}\n";
                return;
            }
            echo "[outbox] published={$published} failed={$failed} (limit={$limit})\n";
        } catch (\Throwable $e) {
            $this->logger->error('outbox.cli.publish.failed', ['error' => $e->getMessage()]);
            fwrite(STDERR, "[outbox] error: " . $e->getMessage() . "\n");
            exit(1);
        }
    }

    /**
     * حلقهٔ دیمن برای supervisor (outbox:publish --limit=100 --sleep=5) —
     * بدون این حلقه، کامند بلافاصله خارج می‌شود و supervisor پس از ری‌استارت‌های
     * سریع (startretries=10) برنامه را FATAL می‌کند و انتشار outbox متوقف می‌شود.
     */
    private function runDaemonLoop(int $limit, int $sleep): void
    {
        $this->logger->info('outbox.cli.publish.daemon_starting', [
            'limit' => $limit,
            'sleep' => $sleep
        ]);

        // PS-fix: ایدیوم for(;;) برای حلقهٔ بی‌نهایتِ عمدی دیمن — رفتار runtime
        // دقیقاً برابر while(true) است؛ PHPStan «شرط همیشه-درست» را دیگر گزارش
        // نمی‌کند چون for بدون شرط، قرارداد استاندارد حلقهٔ عمدی است.
        for (;;) {
            try {
                $result = $this->publisher->publishPending($limit);
                $this->logger->info('outbox.cli.publish.completed', $result);

                // فقط وقتی هیچ رویداد قابل انتشار نیست صبر می‌کنیم
                $activity = int_value($result['published'] ?? 0) + int_value($result['failed'] ?? 0);
                if ($activity === 0) {
                    sleep($sleep);
                }
            } catch (\Throwable $e) {
                // خطای زیرساختی موقت: دیمن زنده می‌ماند و با فاصله ادامه می‌دهد
                $this->logger->error('outbox.cli.publish.daemon_iteration_failed', [
                    'error' => $e->getMessage()
                ]);
                sleep(max($sleep, 5));
            }
        }
    }
}
