<?php

declare(strict_types=1);

namespace App\Commands;

use App\Services\AntiFraud\TorListUpdater;

/**
 * Command: UpdateTorExitNodesCommand
 * 
 * استفاده: php cli.php tor:update-exit-nodes
 */
class UpdateTorExitNodesCommand
{
    private TorListUpdater $updater;

    public function __construct(TorListUpdater $updater) {
        $this->updater = $updater;
    }

    /** @param array<string, mixed> $argv */

    public function run(array $argv): int
    {
        echo "Updating Tor exit nodes list...\n";

        $result = $this->updater->update();

        if (!$result['success']) {
            // FIX-C141 (یافتهٔ ۱۴۱): شکست دیگر exit 0 نیست؛ پیام حساس (لاگ/جزئیات provider)
            // به خروجی نمی‌رود — فقط وضعیت کلاسیه‌شده.
            echo "ERROR: Tor exit nodes list update failed (details in logs).\n";
            return 1;
        }

        echo "SUCCESS: " . $result['message'] . "\n";
        echo "Last update: " . ($this->updater->getLastUpdate() ?? 'N/A') . "\n";
        return 0;
    }
}
