<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use ReflectionClass;
use ReflectionException;

/**
 * RouteAuditCommand - سیستم یکپارچه ممیزی و صحت‌سنجی روت‌ها
 *
 * استفاده: php cli.php route:audit
 */
class RouteAuditCommand
{
    /** @var list<string> */
    private array $errors = [];
    /** @var list<string> */
    private array $warnings = [];
    private int $successCount = 0;
    /** @var list<string> */
    private array $missingFiles = [];
    private ?LoggerInterface $logger;

    public function __construct(?LoggerInterface $logger = null)
    {
        $this->logger = $logger;
    }

    /** FIX-CMD093: هشدار ساختاریافته وقتی لاگر در دسترس است؛ وگرنه error_log. */
    private function logWarning(string $event, array $context): void
    {
        if ($this->logger !== null) {
            $this->logger->warning($event, $context);
            return;
        }
        @error_log('[RouteAuditCommand] ' . $event . ' ' . json_encode($context));
    }

    /** @param array<string, mixed> $argv */

    public function run(array $argv): void
    {
        echo "\n\033[1;36m=== Route Audit Started ===\033[0m\n\n";

        // 1. بررسی فایل‌های روت
        $routeFiles = [
            BASE_PATH . '/routes/api.php',
            BASE_PATH . '/routes/admin.php',
            BASE_PATH . '/routes/system.php',
            BASE_PATH . '/routes/user.php',
            BASE_PATH . '/routes/missing.php',
        ];

        foreach ($routeFiles as $file) {
            if (file_exists($file)) {
                echo "Checking " . basename($file) . " structural presence...\n";
            }
        }

        $this->verifyRouteFiles($routeFiles);

        // 2. اعتبارسنجی دستی اندپوینت‌های کلیدی سیستم
        echo "\n\033[1;36mVerifying Critical API Endpoints...\033[0m\n";

        $criticalEndpoints = [
            ['GET',  '/api/v1/social/accounts', 'App\Controllers\Api\SocialTaskApiController', 'accounts'],
            ['POST', '/api/v1/social/accounts', 'App\Controllers\Api\SocialTaskApiController', 'storeAccount'],
            ['GET',  '/api/v1/social/ads',      'App\Controllers\Api\SocialTaskApiController', 'myAds'],
            ['GET',  '/api/v1/social/tasks',    'App\Controllers\Api\SocialTaskApiController', 'tasks'],
        ];

        foreach ($criticalEndpoints as [$httpMethod, $path, $controller, $method]) {
            $this->verifyRoute($httpMethod, $path, $controller, $method);
        }

        // 3. نمایش نتایج نهایی
        echo "\n\033[1;36m=== Audit Results ===\033[0m\n";
        echo "\033[1;32m✅ Passed: {$this->successCount}\033[0m\n";

        // FIX-CMD093 (یافتهٔ ۰۹۳): فایل‌های روتِ غایب در خلاصه شمرده می‌شوند —
        // ممیزی با فایلِ پیکربندی‌شدهٔ غایب دیگر هرگز بی‌صدا سبز نمی‌شود.
        echo "Missing route files: " . count($this->missingFiles) . "\n";

        if (!empty($this->warnings)) {
            echo "\033[1;33m⚠️ Warnings: " . count($this->warnings) . "\033[0m\n";
            foreach ($this->warnings as $warning) {
                echo "  {$warning}\n";
            }
        }

        if (!empty($this->errors)) {
            echo "\033[1;31m❌ Errors: " . count($this->errors) . "\033[0m\n";
            foreach ($this->errors as $error) {
                echo "  {$error}\n";
            }
            exit(1);
        }

        echo "\033[1;32m\n✅ All critical routes verified successfully!\033[0m\n";
    }

    /** @param list<string> $routeFiles */
    private function verifyRouteFiles(array $routeFiles): void
    {
        echo "\n\033[1;36mVerifying route definitions in route files...\033[0m\n";

        foreach ($routeFiles as $file) {
            if (!file_exists($file)) {
                // FIX-CMD093 (یافتهٔ ۰۹۳): فایل روتِ پیکربندی‌شدهٔ غایب قبلاً بی‌صدا
                // skip می‌شد و ممیزی سبزِ جعلی می‌داد؛ اکنون شمرده، لاگ و به‌عنوان
                // خطا در نتیجهٔ ممیزی ثبت می‌شود (شکست = exit 1).
                $this->missingFiles[] = $file;
                $this->logWarning('route_audit.missing_route_file', ['file' => $file]);
                $this->errors[] = "❌ Missing configured route file: {$file}";
                continue;
            }

            $contents = file_get_contents($file);
            if ($contents === false) {
                $this->warnings[] = "⚠️ Could not read route file: {$file}";
                continue;
            }

            $aliasMap = $this->parseUseAliases($contents);

            // FIX-CMD094 (یافتهٔ ۰۹۴): الگوی قبلی فقط یک شکلِ [Controller::class,
            // 'method'] را می‌دید؛ اکنون همهٔ شکل‌های رایج هندلر به‌ترتیب اسکن و
            // dedupe می‌شوند (فقط regex خواندنی — Router هرگز نمونه‌سازی نمی‌شود):
            //   (a/c) [Controller::class, 'method'] با \s* کامل بین توکن‌ها، از جمله
            //         شکل first-class callable [Controller::class, 'method'](...)
            //   (b)   'Controller@method'
            //   (d)   'App\\...\\Controller', 'method' (نام کلاس رشته‌ای در quotes)
            $references = [];

            preg_match_all('/\[\s*([A-Za-z0-9_\\\\]+)\s*::\s*class\s*,\s*["\']([A-Za-z0-9_]+)["\']\s*\]\s*(?:\(\s*\))?/', $contents, $matches, PREG_SET_ORDER);
            foreach ($matches as $match) {
                $class = $this->normalizeClassRef($match[1]);
                $references[$file . '|' . $class . '|' . $match[2]] = [$class, $match[2]];
            }

            preg_match_all('/["\']([A-Za-z0-9_\\\\]+)@([A-Za-z0-9_]+)["\']/', $contents, $matches, PREG_SET_ORDER);
            foreach ($matches as $match) {
                $class = $this->normalizeClassRef($match[1]);
                if (!str_contains($class, '\\') && !str_ends_with($class, 'Controller')) {
                    continue; // فقط ارجاع‌های شبیه هندلر روت — نه رشتهٔ دلخواه (مثل ایمیل)
                }
                $references[$file . '|' . $class . '|' . $match[2]] = [$class, $match[2]];
            }

            preg_match_all('/["\']([A-Za-z0-9_\\\\]+)["\']\s*,\s*["\']([A-Za-z0-9_]+)["\']/', $contents, $matches, PREG_SET_ORDER);
            foreach ($matches as $match) {
                $class = $this->normalizeClassRef($match[1]);
                if (!str_contains($class, '\\') && !str_ends_with($class, 'Controller')) {
                    continue;
                }
                $references[$file . '|' . $class . '|' . $match[2]] = [$class, $match[2]];
            }

            foreach ($references as [$className, $method]) {
                $resolvedClass = $this->resolveRouteClass($className, $aliasMap);
                if ($resolvedClass === null) {
                    $this->errors[] = "❌ {$file}: Route references unimported controller alias '{$className}'";
                    continue;
                }
                $this->verifyRoute('UNKNOWN', $file, $resolvedClass, $method);
            }
        }
    }

    /**
     * FIX-CMD094: فروکاستن runهای بک‌اسلش (escapeهای سورس مثل App\\Foo) به یک
     * بک‌اسلش واقعی تا class_exists/resolution درست کار کند.
     */
    private function normalizeClassRef(string $class): string
    {
        return (string)preg_replace('/\\\\+/', '\\', $class);
    }

    /**
     * FIX-P3-CMD-095 (یافتهٔ ۰۹۵): پارسر alias — فقط use های کلاس مجازند؛
     * قبلاً «use function X\y;» و «use const» هم به‌عنوان alias ثبت می‌شدند و
     * group use (use A\{B, C as D};) یک رشتهٔ کل کلاسِ آجدار را alias می‌گرفت.
     * اکنون: function/const رد می‌شوند و اعضای group use جداگانه (با as) حل می‌شوند.
     */
    /** @return array<string, string> */
    private function parseUseAliases(string $contents): array
    {
        $aliases = [];
        preg_match_all('/^use\s+([^;]+);/m', $contents, $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $useStatement = trim($match[1]);

            // FIX-P3-CMD-095: use function / use const — alias کلاس نمی‌سازند
            if (preg_match('/^(function|const)\s/i', $useStatement)) {
                continue;
            }

            // FIX-P3-CMD-095: group use — use App\Controllers\{A, B as C,};
            if (str_ends_with($useStatement, '}') && str_contains($useStatement, '{')) {
                $bracePos = strpos($useStatement, '{');
                $prefix = rtrim(substr($useStatement, 0, $bracePos));
                $inner = substr($useStatement, $bracePos + 1, -1);
                foreach (explode(',', $inner) as $member) {
                    $member = trim($member);
                    if ($member === '') {
                        continue; // trailing comma
                    }
                    if (stripos($member, ' as ') !== false) {
                        $parts = preg_split('/\s+as\s+/i', $member, 2);
                        if ($parts === false || count($parts) !== 2) {
                            continue;
                        }
                        [$memberFqcn, $memberAlias] = $parts;
                    } else {
                        $memberFqcn = $member;
                        $segments = explode('\\', trim($memberFqcn));
                        $memberAlias = end($segments);
                    }
                    $memberFqcn = trim($memberFqcn);
                    $memberAlias = trim($memberAlias);
                    if ($memberFqcn === '' || $memberAlias === '') {
                        continue;
                    }
                    $aliases[$memberAlias] = ltrim($prefix . $memberFqcn, '\\');
                }
                continue;
            }

            if (stripos($useStatement, ' as ') !== false) {
                $parts = preg_split('/\s+as\s+/i', $useStatement, 2);
                if ($parts === false) continue;
                [$fqcn, $alias] = $parts;
            } else {
                $fqcn = $useStatement;
                $parts = explode('\\', $fqcn);
                $alias = end($parts);
            }
            $aliases[$alias] = ltrim($fqcn, '\\');
        }
        return $aliases;
    }

    /** @param array<string, string> $aliasMap */
    private function resolveRouteClass(string $className, array $aliasMap): ?string
    {
        if (str_contains($className, '\\')) {
            return ltrim($className, '\\');
        }
        return $aliasMap[$className] ?? null;
    }

    /**
     * FIX-P3-CMD-096 (یافتهٔ ۰۹۶): دامنهٔ بررسی — «حضور ساختاری» است، نه اعتبارسنجی
     * کامل روت: وجود کلاس + وجود متد + public. امضای متد، نوع بازگشتی، میدل‌ور
     * و ثبتِ واقعی روت در Router عمداً خارج از دامنهٔ این ممیزی‌اند (واژهٔ
     * «structural presence» در خروجی همین را می‌گوید). ممیزیِ ثبت واقعی روت‌ها
     * نیازمند بوت کامل Router است و به ابزار جداگانه‌ای تعلق دارد.
     */
    private function verifyRoute(string $method, string $path, string $controllerClass, string $controllerMethod): void
    {
        try {
            // بررسی وجود کلاس کنترولر
            if (!class_exists($controllerClass)) {
                $this->errors[] = "❌ {$method} {$path}: Controller class does not exist: {$controllerClass}";
                return;
            }

            $reflection = new ReflectionClass($controllerClass);

            // بررسی وجود متد کنترولر
            if (!$reflection->hasMethod($controllerMethod)) {
                $this->errors[] = "❌ {$method} {$path}: Method not found: {$controllerClass}::{$controllerMethod}()";
                return;
            }

            $methodObj = $reflection->getMethod($controllerMethod);

            // بررسی پابلیک بودن متد
            if (!$methodObj->isPublic()) {
                $this->errors[] = "❌ {$method} {$path}: Method is not public: {$controllerClass}::{$controllerMethod}()";
                return;
            }

            $this->successCount++;
        } catch (ReflectionException $e) {
            $this->errors[] = "❌ {$method} {$path}: Reflection failure for {$controllerClass} -> " . $e->getMessage();
        }
    }
}
