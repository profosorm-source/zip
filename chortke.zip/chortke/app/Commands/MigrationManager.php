<?php

namespace App\Commands;

use App\Contracts\LoggerInterface;
use Core\Database;

/**
 * MigrationManager - مدیریت migrations و schema versioning
 *
 * این سرویس تمام database migrations را ردیابی می‌کند و اطمینان می‌دهد
 * که schema در تمام محیط‌ها یکپارچه است.
 */
class MigrationManager
{
    private Database $db;
    private ?LoggerInterface $logger;

    public function __construct(Database $db, ?LoggerInterface $logger = null) {
        $this->db = $db;
        $this->logger = $logger;
    }

    /**
     * FIX-CMD056 (یافتهٔ ۰۵۶): خطای DB هرگز بی‌صدا بلعیده نمی‌شود — ابتدا لاگ
     * ساختاریافته (یا error_log وقتی لاگر در دسترس نیست) و سپس RuntimeException
     * با پیام عمومی و exception قبلی زنجیرشده پرتاب می‌شود.
     */
    private function logAndRethrow(string $event, \Exception $e, string $genericMessage): never
    {
        if ($this->logger !== null) {
            $this->logger->error($event, ['error' => $e->getMessage(), 'exception' => get_class($e)]);
        } else {
            @error_log('[MigrationManager] ' . $event . ': ' . get_class($e) . ' — ' . $e->getMessage());
        }
        throw new \RuntimeException($genericMessage, 0, $e);
    }

    /**
     * Run all pending migrations
     * @return array<string, mixed>
     */
    public function run(): array
    {
        $container = \Core\Container::getInstance();
        $service = new \App\Services\MigrationService(
            $container->make(\Core\Redis::class),
            $this->db,
            $container->make(\App\Contracts\LoggerInterface::class)
        );

        $result = $service->runMigrations();

        return [
            'executed' => $result['executed'] ?? 0,
            'batch' => $result['batch'] ?? 1,
            'errors' => $result['errors'] ?? [],
            'message' => $result['message'] ?? 'Migration completed.'
        ];
    }

    /**
     * Initialize migration table if not exists
     */
    public function initialize(): bool
    {
        try {
            $this->db->query(
                "CREATE TABLE IF NOT EXISTS schema_migrations (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    migration VARCHAR(255) UNIQUE NOT NULL,
                    batch INT NOT NULL,
                    checksum VARCHAR(64) NULL,
                    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )"
            );
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get all executed migrations
     * @return list<\stdClass>
     */
    public function getExecuted(): array
    {
        try {
            return (array)$this->db->fetchAll(
                "SELECT migration, batch, checksum, executed_at FROM schema_migrations ORDER BY batch, id"
            );
        } catch (\Exception $e) {
            // FIX-CMD056 (یافتهٔ ۰۵۶): بازگشت [] بی‌صدا لیست مهاجرت‌های اجراشده را
            // «خالی» جلوه می‌داد؛ اکنون fail-loud است.
            $this->logAndRethrow('migration.manager.get_executed_failed', $e, 'Could not read executed migrations (details in logs).');
        }
    }

    /**
     * Record a migration execution
     */
    public function record(string $migrationName, int $batch, ?string $checksum = null): bool
    {
        try {
            $this->db->query(
                "INSERT INTO schema_migrations (migration, batch, checksum) VALUES (?, ?, ?)",
                [$migrationName, $batch, $checksum]
            );
            return true;
        } catch (\Exception $e) {
            // FIX-CMD056 (یافتهٔ ۰۵۶): ثبت‌نشدنِ migration با return false بی‌صدا،
            // اجرای دوباره/drift schema می‌سازد؛ اکنون fail-loud است.
            $this->logAndRethrow('migration.manager.record_failed', $e, 'Could not record migration execution (details in logs).');
        }
    }

    /**
     * Check if migration was executed
     */
    public function isExecuted(string $migrationName): bool
    {
        try {
            $result = $this->db->fetch(
                "SELECT 1 FROM schema_migrations WHERE migration = ?",
                [$migrationName]
            );
            return (bool)$result;
        } catch (\Exception $e) {
            // FIX-CMD056 (یافتهٔ ۰۵۶): false بی‌صدا در خطای DB یعنی «اجرا نشده» و
            // دعوت به re-execution؛ اکنون fail-loud است.
            $this->logAndRethrow('migration.manager.is_executed_failed', $e, 'Could not check migration execution status (details in logs).');
        }
    }

    /**
     * Get next batch number
     *
     * FIX-CMD055 (یافتهٔ ۰۵۵): MAX(batch)+1 بدون قفل، زیر رقابتِ دو runner موازی
     * batch تکراری می‌سازد. مسیر رسمیِ قفل‌شده (Redis lock + heartbeat در حین اجرا)
     * MigrationService::getNextMigrationBatch داخل runMigrations() است؛ این helper
     * deprecate شده و فقط برای گزارش/تاریخ‌نگاری مجاز است و باید حتماً تحت قفلِ
     * مهاجرت فراخوانی شود. (Delegation مستقیم ممکن نیست — متد مقصد private است.)
     *
     * @deprecated به‌جای این متد از MigrationService::runMigrations() (مسیر
     *             قفل‌شده) استفاده کنید؛ این helper فقط گزارش‌گیرانه است.
     */
    public function getNextBatch(): int
    {
        try {
            $result = $this->db->fetch(
                "SELECT COALESCE(MAX(batch), 0) as max_batch FROM schema_migrations"
            );
            return ((int)($result?->max_batch ?? 0)) + 1;
        } catch (\Exception $e) {
            // FIX-CMD056 (یافتهٔ ۰۵۶): بازگشت ۱ بی‌صدا batch اشتباه می‌سازد؛
            // اکنون fail-loud است.
            $this->logAndRethrow('migration.manager.get_next_batch_failed', $e, 'Could not compute next migration batch (details in logs).');
        }
    }


    /**
     * Verify schema integrity
     * 
     * بررسی می‌کند که:
     * 1. تمام ستون‌های ضروری وجود دارند
     * 2. تمام indexes وجود دارند
     * 3. تمام constraints تعریف شده‌اند
     * @return list<string>
     */
    public function verifySchema(): array
    {
        $issues = [];
        // FIX-P3-CMD-060: جدول‌های غایب یک‌بار گزارش می‌شوند — فاز ایندکس برای همان
        // جدول‌ها دیگر «Table not found (index check skipped)» تکراری نمی‌سازد.
        $missingTables = [];

        // Critical tables to verify
        $criticalTables = [
            'users' => ['id', 'email', 'password', 'status', 'created_at'],
            'wallets' => ['id', 'user_id', 'balance_irt', 'balance_usdt', 'created_at'],
            'transactions' => ['id', 'user_id', 'type', 'amount', 'status', 'created_at'],
            'api_tokens' => ['id', 'user_id', 'token', 'refresh_token', 'expires_at', 'is_active'],
            'investments' => ['id', 'user_id', 'amount', 'status', 'created_at'],
            'withdrawals' => ['id', 'user_id', 'amount', 'status', 'created_at'],
        ];

        foreach ((array)$criticalTables as $table => $requiredColumns) {
            // Check if table exists
            $exists = $this->db->fetch(
                "SELECT 1 FROM information_schema.TABLES 
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?",
                [$table]
            );

            if (!$exists) {
                $issues[] = "❌ Table not found: {$table} (column and index checks skipped)";
                $missingTables[$table] = true;
                continue;
            }

            // Check required columns
            foreach ($requiredColumns as $column) {
                $columnExists = $this->db->fetch(
                    "SELECT 1 FROM information_schema.COLUMNS 
                     WHERE TABLE_SCHEMA = DATABASE() 
                       AND TABLE_NAME = ? AND COLUMN_NAME = ?",
                    [$table, $column]
                );

                if (!$columnExists) {
                    $issues[] = "❌ Column missing: {$table}.{$column}";
                }
            }
        }

        // Check critical indexes using information_schema.STATISTICS
        $criticalIndexes = [
            'transactions' => ['user_id', 'status', 'created_at'],
            'withdrawals' => ['user_id', 'status', 'created_at'],
            'api_tokens' => ['user_id', 'token'],
            'realtime_messages' => ['room', 'user_id', 'expires_at'],
            'queues' => ['queue', 'available_at', 'reserved_at'],
            'rate_limit_requests' => ['identifier_key', 'action', 'created_at'],
        ];

        foreach ((array)$criticalIndexes as $table => $columns) {
            // FIX-P3-CMD-060 (یافتهٔ ۰۶۰): گارد وجود جدول قبل از حلقهٔ ایندکس —
            // برای جدولِ غایب قبلاً STATISTICS هم پرسیده می‌شد و به‌ازای هر ستون
            // «Index missing» گزارش می‌شد؛ اکنون گاردِ یک‌پیام: اگر فاز ستون‌ها
            // همان جدول را گزارش کرده، اینجا سکوت می‌کنیم.
            if (isset($missingTables[$table])) {
                continue;
            }

            $indexTableExists = $this->db->fetch(
                "SELECT 1 FROM information_schema.TABLES 
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?",
                [$table]
            );

            if (!$indexTableExists) {
                $issues[] = "❌ Table not found (index check skipped): {$table}";
                continue;
            }

            foreach ($columns as $column) {
                // FIX-P3-CMD-059 (یافتهٔ ۰۵۹): فقط حضور ستون در STATISTICS ملاک نبود —
                // هر ایندکسی که ستون را «غیر-پیشرو» داشته باشد (مثلاً (created_at, user_id))
                // برای lookup روی آن ستون استفاده نمی‌شود. اکنون شرکت ستون به‌عنوان
                // پیشرو (SEQ_IN_INDEX = 1) الزام است؛ نام/یکتایی به عهدهٔ migrationها.
                $indexExists = $this->db->fetch(
                    "SELECT INDEX_NAME FROM information_schema.STATISTICS 
                     WHERE TABLE_SCHEMA = DATABASE() 
                       AND TABLE_NAME = ? AND COLUMN_NAME = ? AND SEQ_IN_INDEX = 1",
                    [$table, $column]
                );

                if (!$indexExists) {
                    $issues[] = "⚠️ Index missing for column: {$table}.{$column}";
                }
            }
        }

        return $issues;
    }

    /**
     * Generate migration info report
     */
    public function report(): string
    {
        $executed = $this->getExecuted();
        $schemaIssues = $this->verifySchema();

        $report = "=== Migration Report ===\n\n";
        $report .= "Executed Migrations:\n";

        if (empty($executed)) {
            $report .= "  (none)\n";
        } else {
            foreach ($executed as $m) {
                // FIX-P3-CMD-061 (یافتهٔ ۰۶۱): report() قبلاً شیء بودن ردیف‌ها را فرض
                // می‌کرد — ردیف آرایه‌ای (تغییر fetch mode) هشدار/خطای "property on array"
                // می‌داد. اکنون هر دو شکل نرمال می‌شوند.
                if (is_array($m)) {
                    $batch = (string)($m['batch'] ?? '?');
                    $migration = (string)($m['migration'] ?? '?');
                    $executedAt = (string)($m['executed_at'] ?? '?');
                } elseif (is_object($m)) {
                    $batch = (string)($m->batch ?? '?');
                    $migration = (string)($m->migration ?? '?');
                    $executedAt = (string)($m->executed_at ?? '?');
                } else {
                    $batch = '?';
                    $migration = '?';
                    $executedAt = '?';
                }
                $report .= "  [{$batch}] {$migration} ({$executedAt})\n";
            }
        }

        $report .= "\n\nSchema Verification:\n";
        if (empty($schemaIssues)) {
            $report .= "  ✅ All checks passed\n";
        } else {
            foreach ($schemaIssues as $issue) {
                $report .= "  {$issue}\n";
            }
        }

        return $report;
    }
}
