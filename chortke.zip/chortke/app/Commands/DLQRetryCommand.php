<?php

declare(strict_types=1);

namespace App\Commands;

use Core\Database;
use Core\Queue;
use App\Contracts\LoggerInterface;
use App\Services\QueueWorker;
use App\Models\FailedJob;

/**
 * DLQRetryCommand
 *
 * Fetches failed jobs from the dead-letter queue (failed_jobs table)
 * and requeues them or purges them permanently.
 *
 * Usage:
 *   php cli.php dlq:retry [queue_name] [--limit=50] [--exclude-fatal] [--include-fatal] [--exception=SomeClass]
 *   php cli.php dlq:retry purge [older_than_days]  (FIX-C135: purge زیر-اکشن dlq:retry است، فرمان مستقل dlq:purge ثبت نشده)
 *
 * FIX-R36-W3 (F-A19e-12): فیلتر خطاهای قطعی (Validation/Business/InvalidArgument/
 * TypeError) به‌صورت پیش‌فرض روشن است — بازپخشِ این‌ها به‌صورت پیش‌فرض فقط چرنِ DLQ
 * می‌سازد (با قرارداد ناهمگون idempotency جاب‌ها ریسک اثر مضاعف هم دارد). برای
 * بازپخش صریحِ آن‌ها --include-fatal بدهید.
 *
 * اصلاحات ممیزی (C126/C128/C129/C130/C131/C132):
 *   - C126: ردیف‌های claim‌شده (status='processing' با lease فعال ورکر) بازصف
 *     نمی‌شوند ⇒ دو مسیر موازی دیگر جاب دوبله نمی‌سازند.
 *   - C128: گزینهٔ --exception واقعاً فیلتر می‌کند (قبلاً parse می‌شد و هیچ
 *     اثری نداشت؛ حتی در help تبلیغ می‌شد!).
 *   - C129: --limit به بازهٔ [1، 500] محدود می‌شود (هم‌سقف DlqWorkCommand).
 *   - C130: قبل از push، کلاس جاب با allowlist مشترک QueueWorker::isJobAllowed()
 *     گیت می‌شود — payload دستکاری‌شده دیگر کلاس دلخواه را وارد صف نمی‌کند.
 *   - C131: payload خراب به‌جای skip خاموش، quarantine می‌شود (status + لاگ).
 *   - C132: purge فقط ردیف‌های ترمینال (نه processing) را حذف می‌کند و قبل از
 *     حذف در dlq_archive آرشیو می‌کند (Data Loss نمی‌سازد).
 *   - run(): سازگار با هر دو فراخوانی dispatcher (args بریده‌شده) و مستقیم/تست
 *     (full argv با پیشوند dlq:) — دیگر purge از مسیر dispatcher گم نمی‌شود.
 */
class DLQRetryCommand
{
    private const MAX_LIMIT = 500;

    private Database $db;
    private LoggerInterface $logger;
    private ?FailedJob $failedJobModel;
    private ?Queue $queue = null;

    public function __construct(?Database $db = null, ?LoggerInterface $logger = null, ?FailedJob $failedJobModel = null, ?Queue $queue = null) {
        $this->db = $db ?? \Core\Database::getInstance();
        $this->logger = $logger ?? throw new \InvalidArgumentException('LoggerInterface is required');
        $this->failedJobModel = $failedJobModel ?? new FailedJob($this->db);
        $this->queue = $queue;
    }

    /**
     * صف واقعی (database یا redis) — از Container فقط در لحظهٔ نیاز حل می‌شود
     * تا ساخت دستی کامند در تست‌ها بدون کانتینر کامل ممکن بماند.
     */
    private function resolveQueue(): Queue
    {
        if ($this->queue === null) {
            $this->queue = \Core\Container::getInstance()->make(Queue::class);
        }
        return $this->queue;
    }

    /**
     * FIX-CMD017 (یافتهٔ ۰۱۷): قرارداد کد خروج — قبلاً execute()/run() همیشه void
     * بودند و شکست بازصفِ جاب‌ها (استثنا در catch) هم با exit 0 از CLI بیرون می‌رفت؛
     * cron/supervisor شکست را نمی‌دیدند. اکنون شمارندهٔ $failedCount در catch بالا
     * می‌رود و execute()/run() کد خروج غیرصفر (۱) برمی‌گردانند (FIX-C141: نگاشت
     * return int در CliDispatcher::normalizeExitCode). خروجی‌های متنی بدون تغییر.
     *
     * @param array<int|string, mixed> $args
     */
    public function execute(array $args): int
    {
        $action = $args[0] ?? 'retry';

        if ($action === 'purge') {
            return $this->purge($args);
        }

        // FIX-C132: با args بریده‌شدهٔ dispatcher، نام صف روی args[0] است؛
        // 'purge' فقط به‌عنوان اکشن صریح شناخته می‌شود.
        $queueName = $args[1] ?? ($action !== 'retry' && !str_starts_with((string)$action, '--') ? (string)$action : 'default');
        $limit = 50;
        // FIX-R36-W3 (F-A19e-12): پیش‌فرضِ روشن — خطاهای قطعی بازصف نمی‌شوند؛
        // opt-out صریح با --include-fatal.
        $excludeFatal = true;
        // FIX-C128 (یافتهٔ ۱۲۸): فیلتر استثنا — قبلاً parse می‌شد اما در حلقهٔ
        // بازصف هیچ‌گاه اعمال نمی‌شد (همهٔ موارد پردازش می‌شدند).
        $exceptionFilter = '';

        foreach ($args as $rawArg) {
            if (!is_string($rawArg)) {
                continue;
            }
            $arg = $rawArg;
            if (str_starts_with($arg, '--limit=')) {
                $parsed = (int)str_replace('--limit=', '', $arg);
                // FIX-C129 (یافتهٔ ۱۲۹): سقف بازه — --limit=0/منفی/نجومی دیگر
                // منابع را تخریب یا خطای SQL نمی‌سازد (هم‌سقف DlqWorkCommand=500).
                $limit = max(1, min(self::MAX_LIMIT, $parsed));
            }
            if ($arg === '--exclude-fatal') {
                $excludeFatal = true;
            }
            if ($arg === '--include-fatal') {
                $excludeFatal = false;
            }
            if (str_starts_with($arg, '--exception=')) {
                $exceptionFilter = trim(str_replace('--exception=', '', $arg));
            }
        }

        echo "Fetching up to {$limit} failed jobs for queue '{$queueName}'...\n";

        $failedJobs = $this->failedJobModel
            ? $this->failedJobModel->fetchByQueue($queueName, $limit)
            : $this->db->fetchAll(
                "SELECT * FROM failed_jobs
                 WHERE queue = ? AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))
                 ORDER BY failed_at DESC LIMIT ?",
                [$queueName, $limit]
            );

        if (empty($failedJobs)) {
            echo "No failed jobs found.\n";
            return 0;
        }

        $retriedCount = 0;
        $skippedCount = 0;
        $lostClaimCount = 0;
        $quarantinedCount = 0;
        $exceptionSkipped = 0;
        // FIX-CMD017: شمارندهٔ شکست‌های واقعی بازصف — قبلاً catch هیچ شمارنده‌ای را
        // افزایش نمی‌داد و شکستِ هر جاب در کد خروج گم می‌شد.
        $failedCount = 0;
        foreach ($failedJobs as $job) {
            if ($excludeFatal) {
                $exceptionStr = (string)$job->exception;
                if (
                    str_contains($exceptionStr, 'ValidationException') ||
                    str_contains($exceptionStr, 'BusinessException') ||
                    str_contains($exceptionStr, 'InvalidArgumentException') ||
                    str_contains($exceptionStr, 'TypeError')
                ) {
                    $skippedCount++;
                    continue;
                }
            }

            // FIX-C128: اعمال واقعی فیلتر --exception (تطابق زیررشته‌ای با پیام/کلاس استثنا)
            if ($exceptionFilter !== '' && !str_contains((string)$job->exception, $exceptionFilter)) {
                $exceptionSkipped++;
                continue;
            }

            try {
                $jobId = (int)$job->id;

                // FIX-CMD013 (یافتهٔ ۰۱۳): claim اتمیک قبل از هر اثر جانبی —
                // دو فرمان retry موازی یا ورکر DLQ فقط یکی می‌تواند برنده شود
                // (UPDATE گارددار؛ برنده affected=1 می‌گیرد). قبلاً فچ سادهٔ بدون
                // claim بود و دو اجرای هم‌زمان هر دو push می‌کردند (جاب دوبله).
                if (!$this->claimJob($jobId)) {
                    $lostClaimCount++;
                    continue;
                }

                $payloadRaw = is_string($job->payload ?? null) ? $job->payload : '';
                $payload = json_decode($payloadRaw, true);
                if (!is_array($payload) || !is_string($payload['job'] ?? null) || $payload['job'] === '') {
                    // FIX-C131 (یافتهٔ ۱۳۱): payload خراب به‌جای skip خاموش،
                    // quarantine می‌شود تا دلیل خرابی برای بازبینی مدیریتی بماند.
                    $this->quarantineBrokenJob($jobId, $payloadRaw, (string)$job->exception, 'malformed_payload');
                    $quarantinedCount++;
                    continue;
                }

                // FIX-C130 (یافتهٔ ۱۳۰): allowlist مشترک قبل از push — کلاس خارج از
                // allowlist دیگر وارد صف زنده نمی‌شود (فقط quarantine + لاگ).
                $jobClass = (string)$payload['job'];
                if (!QueueWorker::isJobAllowed($jobClass)) {
                    $this->quarantineBrokenJob($jobId, $payloadRaw, (string)$job->exception, 'job_not_in_allowlist');
                    $quarantinedCount++;
                    $this->logger->warning('dlq.retry.job_not_allowed', [
                        'failed_job_id' => $jobId,
                        'job_class' => $jobClass,
                    ]);
                    continue;
                }

                // درج در سیستم صف واقعی (چه دیتابیس باشد چه redis) از مسیر استاندارد
                // Queue::push — قبلاً INSERT مستقیم به جدول ناموجود «jobs» انجام می‌شد.
                // FIX-CMD014 (یافتهٔ ۰۱۴): push دیگر داخل تراکنش DB نیست — اثر جانبی
                // خارجی (درایور redis) در تراکنش شرکت نمی‌کند؛ rollback بعد از push
                // موفقِ redis قبلاً جاب دوبله می‌ساخت. ترتیب جدید: claim → push →
                // حذف گارددار؛ crash بعد از push ردیف را processing (in-flight) نگه
                // می‌دارد و هیچ منبع retry دوباره push نمی‌کند (at-most-once push
                // به‌ازای هر claim؛ at-least-once اجرا در صف مقصد).
                $ok = $this->resolveQueue()->push(
                    $jobClass,
                    (array)($payload['data'] ?? []),
                    is_string($job->queue ?? null) && $job->queue !== '' ? $job->queue : 'default'
                );

                if (!$ok) {
                    $this->releaseClaim($jobId);
                    $skippedCount++;
                    continue;
                }

                // حذف فقط با گاردِ مالکیتِ claim خودمان (status='processing')
                $deleted = $this->db->execute(
                    "DELETE FROM failed_jobs WHERE id = ? AND status = 'processing'",
                    [$jobId]
                );
                if (is_int($deleted) && $deleted === 0) {
                    $this->logger->warning('dlq.retry.lost_claim_after_push', ['failed_job_id' => $jobId]);
                    $lostClaimCount++;
                    continue;
                }

                $retriedCount++;

                $this->logger->info("dlq.job_retried", ['failed_job_id' => $jobId]);
            } catch (\Throwable $e) {
                // FIX-P3-CMD-019 (یافتهٔ ۰۱۹): catch فقط \Exception بود — یک \Error
                // (مثلاً TypeError در مسیر push/decode) از حلقهٔ per-job فرار می‌کرد و
                // releaseClaim/شمارش شکست/ادامهٔ ایزولهٔ بقیهٔ جاب‌ها را رد می‌شد.
                // اکنون \Throwable — rollback ناهمگون در کار نیست (push بیرون txn است)
                // و آزادسازی claim در هر دو حالت انجام می‌شود.
                if (isset($jobId) && is_int($jobId) && $jobId > 0) {
                    $this->releaseClaim($jobId);
                }
                $this->logger->error("dlq.retry_failed", ['failed_job_id' => $job->id, 'error' => $e->getMessage()]);
                // FIX (یافتهٔ ۱۲۵): پیام خام استثنا (SQL/DSN/مسیر) به خروجی operator
                // نمی‌رود — جزئیات فقط در لاگ ساختاریافته و Sentry.
                echo "Failed to retry job {$job->id}: retry failed (details in logs, id: " . substr(md5((string)$e->getMessage()), 0, 12) . ")\n";
                // FIX-CMD017: شکستِ این جاب در شمارنده ثبت می‌شود تا کد خروج غیرصفر برگردد.
                $failedCount++;
            }
        }

        echo "Successfully requeued {$retriedCount} jobs.\n";
        if ($skippedCount > 0) {
            echo "Skipped {$skippedCount} fatal errors.\n";
        }
        if ($exceptionSkipped > 0) {
            echo "Filtered {$exceptionSkipped} jobs by --exception={$exceptionFilter}.\n";
        }
        if ($lostClaimCount > 0) {
            echo "{$lostClaimCount} jobs were claimed by another worker and left untouched.\n";
        }
        if ($quarantinedCount > 0) {
            echo "Quarantined {$quarantinedCount} jobs (malformed payload or not in allowlist) — review in admin DLQ.\n";
        }

        // FIX-CMD017: کد خروج — حداقل یک شکست بازصف ⇒ ۱ (برای cron/supervisor).
        return $failedCount > 0 ? 1 : 0;
    }

    /**
     * FIX-C131: قرنطینهٔ ردیف شکست‌خورده — وضعیت صریح + reason؛ از چرخهٔ
     * بازصف خودکار خارج می‌شود اما برای بازبینی مدیریتی باقی می‌ماند.
     */
    /**
     * FIX-CMD013/CMD075: claim اتمیک retry — از مدل وقتی موجود است، وگرنه SQL خام
     * با همان گارد (سازگاری با حالت مدل null).
     */
    private function claimJob(int $id): bool
    {
        if ($this->failedJobModel) {
            return $this->failedJobModel->claimForRetry($id);
        }
        $affected = $this->db->execute(
            "UPDATE failed_jobs SET status = 'processing'
             WHERE id = ? AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
            [$id]
        );
        return is_int($affected) && $affected > 0;
    }

    /**
     * آزادسازی claim در شکست push — ردیف دوباره retryable می‌شود (retry_pending).
     */
    private function releaseClaim(int $id): bool
    {
        if ($this->failedJobModel) {
            return $this->failedJobModel->releaseRetryClaim($id);
        }
        $affected = $this->db->execute(
            "UPDATE failed_jobs SET status = 'retry_pending' WHERE id = ? AND status = 'processing'",
            [$id]
        );
        return is_int($affected) && $affected > 0;
    }

    private function quarantineBrokenJob(int $id, string $payloadRaw, string $exception, string $reason): void
    {
        try {
            // آرشیو واقعی (FIX-C97) + علامت‌گذاری وضعیت
            $this->db->execute(
                "INSERT INTO dlq_archive
                 (original_failed_job_id, queue, job_class, payload, exception, archive_reason, archived_by)
                 VALUES (?, NULL, NULL, ?, NULL, ?, 'dlq_retry_command')",
                [$id, $payloadRaw !== '' ? $payloadRaw : null, $reason]
            );
            $this->db->execute(
                "UPDATE failed_jobs SET status = 'quarantined' WHERE id = ?",
                [$id]
            );
            $this->logger->warning('dlq.job_quarantined', [
                'failed_job_id' => $id,
                'reason' => $reason,
            ]);
        } catch (\Throwable $e) {
            // قرنطینه نباید بازصف را نجات‌ناپذیر کند؛ اما شفاف لاگ می‌شود.
            $this->logger->warning('dlq.quarantine_failed', [
                'failed_job_id' => $id,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * CLI entry-point required by CliDispatcher.
     * Delegates to execute() with parsed arguments.
     *
     * FIX-C132: سازگار با هر دو فراخوانی — dispatcher آرگومان بریده‌شده می‌دهد
     * (args[0] = اکشن/صف)، تست‌ها full argv می‌دهند (args[0] = 'dlq:retry').
     * قبلاً slicing کور باعث می‌شد «dlq:retry purge» به «retry صفِ purge»
     * تفسیر شود و purge از مسیر dispatcher غیرقابل‌دسترس باشد.
     *
     * FIX-CMD017: کد خروج execute() عیناً به caller برمی‌گردد (FIX-C141).
     *
     * @param array<int|string, mixed> $args
     */
    public function run(array $args = []): int
    {
        $first = is_string($args[0] ?? null) ? (string)$args[0] : '';
        if ($first !== '' && str_starts_with($first, 'dlq:')) {
            // full argv: ['dlq:retry', ...] → command name را حذف کن
            $args = array_values(array_slice($args, 1));
        }
        if (empty($args)) {
            $args = ['retry', 'default'];
        }
        return $this->execute($args);
    }

    /**
     * FIX-CMD017: purge هم کد خروج برمی‌گرداند (شکست آرشیو/حذف ⇒ ۱).
     *
     * @param array<int|string, mixed> $args
     */
    private function purge(array $args): int
    {
        $daysValue = $args[1] ?? 30;
        $days = is_numeric($daysValue) ? (int)$daysValue : 30;
        // FIX-C150-style bound: بازهٔ منطقی 1..3650 روز
        $days = max(1, min(3650, $days));

        echo "Purging failed jobs older than {$days} days (archiving first)...\n";

        // FIX-C132 (یافتهٔ ۱۳۲): purge دیگر با retry رقابت نمی‌کند —
        // ردیف‌های claim‌شده (processing) حذف نمی‌شوند؛ و قبل از حذف، ردیف‌ها
        // در dlq_archive آرشیو می‌شوند (FIX-C97: حذفِ بدون آرشیو = Data Loss).
        try {
            // FIX-C132/C97: قبل از حذف، ردیف‌ها در dlq_archive آرشیو می‌شوند و
            // ردیف‌های claim‌شدهٔ ورکر (processing) هرگز حذف نمی‌شوند. مسیر مدل
            // (FailedJob::purge) همین قرارداد را با تراکنش داخلی اجرا می‌کند.
            if ($this->failedJobModel) {
                $count = $this->failedJobModel->purge($days);
            } else {
                $this->db->beginTransaction();
                $this->db->execute(
                    "INSERT INTO dlq_archive
                     (original_failed_job_id, queue, job_class, payload, exception, failed_at, archive_reason, archived_by)
                     SELECT id, queue, NULL, payload, exception, failed_at, 'manual_purge', 'dlq_retry_command'
                     FROM failed_jobs
                     WHERE failed_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                       AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
                    [$days]
                );
                $count = (int) $this->db->execute(
                    "DELETE FROM failed_jobs
                     WHERE failed_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                       AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
                    [$days]
                );
                $this->db->commit();
            }
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            $this->logger->error('dlq.purge_failed', ['error' => $e->getMessage()]);
            echo "Purge failed (see logs for details).\n";
            return 1;
        }

        echo "Purged {$count} failed jobs permanently (archived first, quarantined/processing rows preserved).\n";
        $this->logger->info("dlq.purged", ['count' => $count, 'older_than_days' => $days]);
        return 0;
    }
}
