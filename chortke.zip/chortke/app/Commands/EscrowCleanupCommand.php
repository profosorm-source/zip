<?php

declare(strict_types=1);

namespace App\Commands;

use App\Domain\Financial\Services\FinancialEscrowService;
use Core\Database;
use Core\Cache;
use App\Contracts\LoggerInterface;

/**
 * Command: EscrowCleanupCommand - Automatically cleanup/refund expired escrows
 *
 * Usage: php app.php escrow:cleanup [--dry-run] [--force]
 *
 * FIX-C145 (یافتهٔ ۱۴۵): عملیات مالی بازگشت وجه — اجرای تعاملی بدون پرچم صریح
 * فقط پیش‌نمایش (تعداد سپرده‌های منقضی) چاپ می‌کند؛ اجرای واقعی نیازمند
 * ‎--force (یا ‎--dry-run صریح) است. cron/Kernel مسیر مستقل خودش را دارد و
 * تحت‌تأثیر نیست.
 *
 * FIX-P3-CMD-039 (یافتهٔ ۰۳۹): قفل اجرای سطح command (Redis nx/ex، الگوی scores:decay)
 * — صحتِ مالی در سرویس با قفل ردیفی هر escrow تضمین می‌شود؛ این قفل فقط اسکنِ
 * موازی/لاگ دوبلهٔ دو instance را حذف می‌کند. بدون cache fail-open مستند است.
 */
class EscrowCleanupCommand
{
    private FinancialEscrowService $financialEscrowService;
    private LoggerInterface $logger;
    private Database $db;
    private ?Cache $cache;

    public function __construct(
        FinancialEscrowService $financialEscrowService,
        Database $db,
        LoggerInterface $logger,
        ?Cache $cache = null
    ) {
        $this->financialEscrowService = $financialEscrowService;
        $this->db = $db;
        $this->logger = $logger;
        $this->cache = $cache;
    }

    /** @param array<string, mixed> $argv */

    public function run(array $argv = []): int
    {
        // FIX-C145: پیش‌نمایش پیش‌فرض برای اجرای دستی — خروجی واقعی فقط با --force
        $dryRun = in_array('--dry-run', $argv, true) || !in_array('--force', $argv, true);
        if ($dryRun) {
            return $this->dryRun();
        }

        // FIX-P3-CMD-039: قفل اجرا فقط دور مسیرِ واقعی (dry-run فقط-خواندنی نیازی به قفل ندارد).
        // مشغول بودن قفل = instance دیگری در حال اجراست ⇒ skip صادقانه با کد ۰ (رقابت عادی است،
        // نه شکست)؛ بدون cache/redis اجرا مثل قبل ادامه می‌یابد (fail-open — قفل ردیفی سرویس برجاست).
        $lock = $this->acquireRunLock(300);
        if ($lock['status'] === 'busy') {
            $this->logger->info('command.escrow_cleanup.skipped_lock_busy', []);
            echo "[escrow:cleanup] skipped: another escrow:cleanup instance holds the run lock\n";
            return 0;
        }
        try {
            // FIX-C141 (یافتهٔ ۱۴۱): نتیجهٔ handle() قبلاً دور ریخته می‌شد و dispatcher
            // همیشه exit 0 می‌گرفت — سیستم بیرونی اجرای موفق را تصور می‌کرد و retry نمی‌کرد.
            return $this->handle();
        } finally {
            $this->releaseRunLock($lock['key']);
        }
    }

    /**
     * FIX-C145: پیش‌نمایش فقط-خواندنی — همان فیلتر releaseExpiredHolds
     * (status='pending' + held_at منقضی) فقط با COUNT.
     */
    private function dryRun(): int
    {
        try {
            $expirySetting = config('escrow_expiry_hours', 48);
            $expiredHours = is_scalar($expirySetting) ? max(1, min(8760, (int)$expirySetting)) : 48;
            $count = (int)$this->db->fetchColumn(
                "SELECT COUNT(*) FROM escrow_transactions
                 WHERE status = 'pending'
                   AND held_at < DATE_SUB(NOW(), INTERVAL ? HOUR)",
                [$expiredHours]
            );
            echo "[escrow:cleanup] DRY-RUN: {$count} expired escrow hold(s) would be refunded (expiry={$expiredHours}h). Run with --force to apply.\n";
            $this->logger->info('command.escrow_cleanup.dry_run', ['candidates' => $count, 'expired_hours' => $expiredHours]);
            return 0;
        } catch (\Throwable $e) {
            $this->logger->error('command.escrow_cleanup.dry_run_failed', ['error' => $e->getMessage()]);
            return 1;
        }
    }

    public function handle(): int
    {
        $this->logger->info('command.escrow_cleanup.starting');
        try {
            $released = $this->financialEscrowService->releaseExpiredHolds();
            $this->logger->info('command.escrow_cleanup.completed', ['released' => $released]);
            return 0;
        } catch (\Throwable $e) {
            $this->logger->error('command.escrow_cleanup.failed', ['error' => $e->getMessage()]);
            return 1;
        }
    }

    /**
     * FIX-P3-CMD-039: قفل Redis nx/ex — الگوی scores:decay/scores:rebuild.
     *
     * @return array{status: string, key: ?string} status: held|busy|unavailable
     */
    private function acquireRunLock(int $ttl): array
    {
        if ($this->cache === null) {
            return ['status' => 'unavailable', 'key' => null];
        }
        try {
            $redis = $this->cache->redis();
            if (!$redis) {
                return ['status' => 'unavailable', 'key' => null];
            }
            $key = $this->cache->redisKey('escrow:cleanup:run_lock');
            if (!$redis->set($key, (string)time(), ['nx', 'ex' => $ttl])) {
                return ['status' => 'busy', 'key' => $key];
            }
            return ['status' => 'held', 'key' => $key];
        } catch (\Throwable $e) {
            // fail-open مستند — قفل ردیفی FinancialEscrowService صحت مالی را نگه می‌دارد
            $this->logger->debug('command.escrow_cleanup.run_lock_unavailable', ['error' => $e->getMessage()]);
            return ['status' => 'unavailable', 'key' => null];
        }
    }

    /** FIX-P3-CMD-039: آزادسازی best-effort قفل — TTL پشتیبان هم دارد. */
    private function releaseRunLock(?string $key): void
    {
        if ($key === null || $this->cache === null) {
            return;
        }
        try {
            $redis = $this->cache->redis();
            if ($redis) {
                $redis->del($key);
            }
        } catch (\Throwable $e) {
            $this->logger->debug('command.escrow_cleanup.run_lock_release_failed', ['error' => $e->getMessage()]);
        }
    }
}
