<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\LoggerInterface;
use App\Services\Shared\IdempotencyService;

/**
 * CLI wrapper برای مدیریت جدول idempotency_keys (Section 8.2).
 *
 * MIGRATION: از Core\IdempotencyKey به App\Services\Shared\IdempotencyService
 *
 * Usage:
 *   php cli.php idempotency:stats
 *   php cli.php idempotency:cleanup [--dry-run]
 */
class IdempotencyCommand
{
    private IdempotencyService $idempotency;
    private LoggerInterface $logger;

    public function __construct(
        IdempotencyService $idempotency,
        LoggerInterface $logger
    ) {
        $this->idempotency = $idempotency;
        $this->logger      = $logger;
    }

    /** @param list<mixed> $argv */

    public function run(array $argv): void
    {
        $command = $argv[1] ?? 'idempotency:stats';
        if (!is_string($command)) {
            throw new \InvalidArgumentException('Idempotency command name must be a string.');
        }
        $opts    = $this->parseOptions($argv);

        // FIX-P3-CMD-052 (یافتهٔ ۰۵۲): فلگ ناشناخته دیگر بی‌صدا نادیده گرفته نمی‌شود —
        // قبلاً parseOptions هر ‎--foo=bar را جمع می‌کرد و فقط dry-run مصرف می‌شد؛
        // غلط تایپی اپراتور (مثلاً ‎--dryrun) بی‌صدا dry-run را از دست می‌داد و
        // cleanup واقعی اجرا می‌شد. اکنون allowlist صریح.
        $this->assertKnownOptions($opts);

        switch ($command) {
            case 'idempotency:stats':
                $this->stats();
                return;
            case 'idempotency:cleanup':
                $this->cleanup($this->parseBooleanOption($opts, 'dry-run'));
                return;
            default:
                throw new \InvalidArgumentException('Unsupported idempotency command: ' . $command);
        }
    }

    /**
     * FIX-P3-CMD-052: allowlist گزینه‌ها — تنها گزینهٔ مصرفی این فرمان.
     *
     * @param array<string, mixed> $opts
     */
    private function assertKnownOptions(array $opts): void
    {
        $known = ['dry-run'];
        foreach ($opts as $key => $unused) {
            if (!is_string($key) || !in_array($key, $known, true)) {
                $shown = is_string($key) ? $key : '';
                throw new \InvalidArgumentException(
                    "Unknown option --{$shown}. Supported options: " . implode(', ', array_map(static fn (string $k): string => "--{$k}", $known)) . '.'
                );
            }
        }
    }

    private function stats(): void
    {
        $stats = $this->idempotency->getStats();
        if (isset($stats['error'])) {
            fwrite(STDERR, "[idempotency:stats] error: " . str_value($stats['error']) . "\n");
            exit(1);
        }
        echo "Total idempotency keys: " . int_value($stats['total'] ?? 0) . "\n";
        $byStatus = $stats['by_status'] ?? [];
        if (!empty($byStatus)) {
            echo "By status:\n";
            foreach ((array)$byStatus as $status => $rowValue) {
                if (!is_array($rowValue)) throw new \UnexpectedValueException('Idempotency status statistics must be arrays.');
                $row = $rowValue;
                echo sprintf(
                    "  %-12s count=%-8d  last_hour=%-6d  last_24h=%-6d\n",
                    // FIX-P3-CMD-053 (یافتهٔ ۰۵۳): status از DB می‌آید — کاراکترهای کنترلی
                    // (CR/LF/ESC) قبل از چاپ حذف می‌شوند تا بستر ترمینال/لاگ نشکند.
                    $this->statusKeySafe((string)$status),
                    int_value($row['count'] ?? 0),
                    int_value($row['last_hour'] ?? 0),
                    int_value($row['last_24h'] ?? 0)
                );
            }
        }
    }

    /**
     * FIX-P3-CMD-053: حذف کاراکترهای کنترلی/ANSI از کلید status دیتابیس‌محور و
     * سقف طول ۲۴ (هم‌ترازِ عرضِ ستون در فرمت چاپ).
     */
    private function statusKeySafe(string $status): string
    {
        // همهٔ کاراکترهای کنترلی شامل CR/LF/TAB حذف می‌شوند — کلیدِ خراب نباید
        // حتی یک خط جدید به خروجی تزریق کند.
        $clean = (string)preg_replace('/[\x00-\x1F\x7F]/', '', $status);
        return mb_substr($clean, 0, 24);
    }

    private function cleanup(bool $dryRun): void
    {
        $count = $this->idempotency->cleanup($dryRun);
        echo $dryRun
            ? "[idempotency:cleanup] dry-run: {$count} rows would be deleted.\n"
            : "[idempotency:cleanup] deleted={$count}\n";
        $this->logger->info('idempotency.cli.cleanup', [
            'dry_run' => $dryRun,
            'count'   => $count,
        ]);
    }

    /** @param array<string, mixed> $options */
    private function parseBooleanOption(array $options, string $name): bool
    {
        $value = $options[$name] ?? false;
        if (is_bool($value)) {
            return $value;
        }
        if (!is_string($value)) {
            throw new \InvalidArgumentException("Option --{$name} must be a boolean flag.");
        }

        $normalized = strtolower(trim($value));
        if (in_array($normalized, ['1', 'true', 'yes'], true)) {
            return true;
        }
        if (in_array($normalized, ['0', 'false', 'no'], true)) {
            return false;
        }

        throw new \InvalidArgumentException("Option --{$name} must be true or false.");
    }

    /**
     * @param list<mixed> $argv
     * @return array<string, mixed>
     */
    private function parseOptions(array $argv): array
    {
        $opts  = [];
        $count = count($argv);
        for ($i = 2; $i < $count; $i++) {
            $arg = is_scalar($argv[$i]) ? (string)$argv[$i] : '';
            if (!str_starts_with($arg, '--')) {
                continue;
            }
            $arg = substr($arg, 2);
            if (str_contains($arg, '=')) {
                [$k, $v] = explode('=', $arg, 2);
                $opts[$k] = trim($v, "\"' ");
            } else {
                $opts[$arg] = true;
            }
        }
        return $opts;
    }
}