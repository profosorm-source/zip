<?php
namespace App\Console;
use Core\Scheduler;
use Core\Container;
use App\Services\EmailService;
use App\Services\CryptoDeposit\CryptoDepositService;
use App\Services\User\UserLevelService;
use App\Services\BannerService;
use App\Services\InfluencerService;
use App\Services\Shared\DisputeService;
use App\Services\Notification\NotificationService;
use App\Services\AdNotificationDispatcher;
use App\Services\Ads\AdsBudgetSettlementService;
use App\Models\Notification as NotificationModel;
use App\Models\Advertisement;
use Core\Cache;
use Core\Database;
use Core\Queue;
use App\Services\Gamification\TrustService;

class Kernel {
    public static function schedule(Scheduler $scheduler): void {
        $container = app();
/**
 * ─────────────────────────────────────────
 * هر دقیقه
 * ─────────────────────────────────────────
 */

// پردازش صف ایمیل‌ها
$scheduler->everyMinute(function () use ($container) {
    $service = $container->make(EmailService::class);
    $batchSize = int_value(feature_config('cron_email_batch_size', 'rollout_percentage', 20));
    $result  = $service->processQueue($batchSize);
    return [
        'sent'   => $result['sent']   ?? 0,
        'failed' => $result['failed'] ?? 0,
    ];
}, 'email_queue');

// Finding #10 & #11 Fix: Automatic recovery of email file fallbacks
$scheduler->everyMinutes(15, function () use ($container) {
    $emailStore = $container->make(\App\Services\EmailDeliveryStore::class);
    $recovered = $emailStore->recoverFileFallbacks();
    return ['recovered_file_fallbacks' => $recovered];
}, 'email_fallback_recovery');

// پردازش صف عمومی سیستم
$scheduler->everyMinute(function () use ($container) {
    $maxJobsToProcess = max(1, min(100, int_value(feature_config('cron_queue_jobs_limit', 'rollout_percentage', 10))));
    
    $command = $container->make(\App\Commands\QueueWorkCommand::class);
    $result = $command->run(['cli.php', 'queue:work', "--limit={$maxJobsToProcess}"]);
    
    return ['processed_jobs' => $result['processed_jobs'] ?? 0];
}, 'system_queue_processor');

// Poison Message Handler: بازپخش هوشمند خطاهای موقت
$scheduler->everyMinutes(5, function () use ($container) {
    $queue = $container->make(Queue::class);
    $limit = max(1, min(100, int_value(feature_config('cron_dlq_retry_limit', 'rollout_percentage', 50))));
    
    $stats = $queue->retryEligibleFailedJobs(null, $limit, false);
    
    return [
        'requeued_poison_messages' => $stats['requeued'] ?? 0,
        'failed_retries' => $stats['errors'] ?? 0
    ];
}, 'poison_message_smart_retry');

// تأیید خودکار واریزهای کریپتو در انتظار
$scheduler->everyMinute(function () use ($container) {
    $db      = Database::getInstance();
    $job = $container->make(\App\Jobs\VerifyCryptoDepositJob::class);

    // واریزهای pending که هنوز تأیید نشده‌اند
    // مشکل #10: cast + validate — هرگز مستقیم در SQL interpolate نمی‌شوند
    $hours = max(1, min(720, int_value(feature_config('cron_verification_hours', 'rollout_percentage', 12))));
    $limit = max(1, min(500, int_value(feature_config('cron_verification_limit', 'rollout_percentage', 10))));

    $pending = $db->fetchAll(
        "SELECT id FROM crypto_deposits
         WHERE verification_status = 'pending'
           AND created_at >= DATE_SUB(NOW(), INTERVAL ? HOUR)
         ORDER BY created_at ASC
         LIMIT ?",
        [$hours, $limit]
    );

    $verified = 0;
    $failed = 0;
    foreach ($pending as $row) {
        $id     = is_array($row) ? (int)$row['id'] : (int)$row->id;
        // FIX-CMD141 (یافتهٔ ۱۴۱): خطای per-item حلقه را نمی‌شکند — یک واریز خراب
        // قبلاً کل تیک crypto_verify را abort می‌کرد و بقیهٔ صف واریزی آن تیک پردازش
        // نمی‌شدند؛ اکنون هر آیتم جدا catch، شمارش و لاگ می‌شود.
        try {
            $result = $job->handle($id);
            if (($result['auto'] ?? false) === true) {
                $verified++;
            } else {
                $failed++;
            }
        } catch (\Throwable $e) {
            $failed++;
            logger()->error('crypto_verify.item_failed', [
                'deposit_id' => $id,
                'error' => $e->getMessage(),
            ]);
        }
    }

    return ['pending_checked' => count($pending), 'verified' => $verified, 'failed' => $failed];
}, 'crypto_verify');

// تایید خودکار پرداخت‌های معلق درگاه‌های آنلاین
$scheduler->everyMinutes(10, function () use ($container) {
    $paymentService = $container->make(\App\Services\Payment\PaymentService::class);
    $pending = $paymentService->getPendingVerificationPayments();
    
    $completed = 0;
    $failed = 0;
    
    foreach ($pending as $payment) {
        $createdAt = strtotime($payment->created_at);
        $age = time() - $createdAt;
        
        // فقط برای تراکنش‌های کمتر از ۲۴ ساعت و بیشتر از ۵ دقیقه (جهت فرصت دادن به پردازش‌های آنی و عادی درگاه)
        if ($age > 300 && $age < 86400) {
            try {
                // تایید خودکار با شناسهٔ سیستم (0)
                // CMD-140 (پذیرش مستند + شفاف‌سازی audit): اکتر «سیستم» به‌عمد ۰ است
                // (خارج از فضای شناسهٔ کاربران، غیرقابل جعل به کاربر خاص)؛ این مسیر
                // فقط تأییدِ پرداختِ ثبت‌شده در درگاه را انجام می‌دهد نه پرداخت جدید.
                // برای هم‌بستگی audit، هر تأیید خودکار با ایونت لاگ صریح ثبت می‌شود.
                $result = $paymentService->manuallyVerifyPayment((int)$payment->id, 0);
                if (!empty($result['success'])) {
                    $completed++;
                    logger()->info('payment.auto_verified_by_system', [
                        'payment_id' => (int)$payment->id,
                        'actor_type' => 'system',
                        'actor_id' => 0,
                        'gateway' => $payment->gateway ?? null,
                    ]);
                } else {
                    $failed++;
                }
            } catch (\Throwable $e) {
                logger()->error('payment.auto_retry_verification_failed', [
                    'payment_id' => $payment->id,
                    'error' => $e->getMessage()
                ]);
                $failed++;
            }
        }
    }
    
    return [
        'total_pending' => count($pending),
        'auto_completed' => $completed,
        'auto_failed' => $failed
    ];
}, 'payment_pending_verification_retry');

// پردازش خودکار قوانین هشدار (Alert Engine)
// 🛡️ FIX-QA5-3 (راند ۱۰): قبلاً AlertDispatcher::processRules() صدا زده می‌شد که
// وجود ندارد → این جاب هر دقیقه با Error «Call to undefined method» شکست می‌خورد
// و failed_jobs هر ~۱ دقیقه +۱ رشد می‌کرد (اثبات زنده: ۲۷ ردیف failed_jobs در
// ~۲۵ دقیقه، کارت Saga/DLQ صفحهٔ /status = degraded). موتور واقعی قوانین
// AlertRulesEngine::evaluateAllRules() است (همان الگوی قدیمی processRules:
// ارزیابی همهٔ قوانین فعال + برگرداندن فهرست قوانین تریگرشده).
$scheduler->everyMinute(function () use ($container) {
    $engine = $container->make(\App\Services\Sentry\Alerting\AlertRulesEngine::class);
    $triggered = $engine->evaluateAllRules();
    return ['triggered_rules' => count($triggered)];
}, 'alert_rule_engine');

// 🛡️ S31 — پاک‌سازی دسته‌ای اثر انگشت ویدیوهای قدیمی (VideoFingerprintService)
// هوک کرون FIX-S31-VF3: پیش از این، cleanOldFingerprints هیچ فراخوانی نداشت
// (جدول بدون پاک‌سازی بزرگ می‌شد). حذف دسته‌ای با LIMIT = قفل کوتاه.
$scheduler->daily('03:40', function () use ($container) {
    $cleaned = $container->make(\App\Services\AntiFraud\VideoFingerprintService::class)
        ->cleanOldFingerprints(90, 1000);
    return ['cleaned_fingerprints' => $cleaned];
}, 'video_fingerprint_cleanup');

// بررسی وضعیت دیسک و حافظه (مانیتورینگ پیشگیرانه)
$scheduler->everyMinutes(5, function () use ($container) {
    $monitoring = $container->make(\App\Services\AdminDashboard\SystemMonitoringService::class);
    $monitoring->checkAndAlert();
    return ['checked' => true];
}, 'system_monitoring_alert');


// پاک‌سازی کش منقضی‌شده
$scheduler->everyMinutes(int_value(feature_config('cron_scheduler_interval', 'rollout_percentage', 5)), function () {
    $cleaned = Cache::getInstance()->cleanup();
    return ['cleaned_files' => $cleaned];
}, 'cache_cleanup');

// 📢 ارسال اعلان‌های پس‌زمینه کمپین‌های فعال (Ad Notifications)
// اجرا در فواصل کوتاه برای ارسال موازی و کم‌بار بدون سنگین کردن سرور
$scheduler->everyMinutes(int_value(feature_config('cron_ad_push_interval', 'rollout_percentage', 3)), function () use ($container) {
    $dispatcher = $container->make(AdNotificationDispatcher::class);
    $result = $dispatcher->processAdNotifications();
    $adsProcessed = int_value($result['ads_processed'] ?? 0);
    $totalSent = int_value($result['total_sent'] ?? 0);
    if ($totalSent > 0) {
        // FIX-P3-CMD-164: echo در callback مشترک CLI/web ممنوع — خروجی از logger می‌رود
        // (CronController همین closure را در رجیستری وب ادمین اجرا می‌کند؛ echo
        // خروجی صفحهٔ وب را خراب می‌کرد).
        logger()->info("AdPush: processed {$adsProcessed} ads, sent {$totalSent} push packets");
    }
    return $result;
}, 'ad_notification_push');

// H-06 Fix: تخلیه بافر بازدید بنرها از Redis به دیتابیس هر ۵ دقیقه
$scheduler->everyMinutes(5, function () use ($container) {
    $service = $container->make(\App\Services\BannerService::class);
    $count   = $service->flushImpressionsBuffer();
    return ['flushed_banners' => $count];
}, 'flush_banner_impressions');

/**
 * ─────────────────────────────────────────
 * هر ساعت (دقیقه ۰)
 * ─────────────────────────────────────────
 */

// reconcile چرخه عمر تبلیغات unified ads؛ جایگزین query قدیمی روی جدول advertisements
$scheduler->hourly(function () use ($container) {
    $service = $container->make(AdsBudgetSettlementService::class);
    return $service->reconcileLifecycle(200);
}, 'ads_lifecycle_reconcile');

// غیرفعال کردن بنرهای منقضی‌شده
$scheduler->hourly(function () use ($container) {
    $service = $container->make(BannerService::class);
    $count   = $service->deactivateExpiredBanners();
    return ['deactivated_banners' => $count];
}, 'expire_banners');

// پاک‌سازی ساعتی فایل‌های جلسه‌ی فایلی در صورت fallback از Redis
$scheduler->hourly(function () {
    try {
        $handler = new \Core\RedisSessionHandler();
        $maxLifetime = max(60, min(86400, int_value(config('session.lifetime', 7200))));
        $deleted = $handler->gc($maxLifetime);
        return [
            'session_gc_deleted' => $deleted === false ? 0 : $deleted,
            'session_driver' => $handler->driver(),
        ];
    } catch (\Throwable $e) {
        logger()->error('cron.session_file_gc.failed', [
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);
        return ['error' => $e->getMessage()];
    }
}, 'session_file_gc');

// غیرفعال کردن فیچر فلگ‌های منقضی شده و cleanup metrics
$scheduler->hourly(function () use ($container) {
    try {
        $db = Database::getInstance();
        $model = $container->make(\App\Models\FeatureFlag::class);

        $affected = (int) $db->execute(
            "UPDATE feature_flags
             SET enabled = 0, updated_at = NOW()
             WHERE enabled = 1
               AND enabled_until IS NOT NULL
               AND enabled_until < NOW()"
        );

        $metricDays = max(7, min(365, int_value(feature_config('feature_flag_metrics_retention_days', 'rollout_percentage', 30))));
        $model->cleanupMetrics($metricDays);

        return [
            'expired_feature_flags_disabled' => $affected,
            'feature_flag_metrics_retention_days' => $metricDays,
        ];
    } catch (\Throwable $e) {
        logger()->error('cron.expired_feature_flag_cleanup.failed', [
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);
        return ['error' => $e->getMessage()];
    }
}, 'expired_feature_flag_cleanup');

// پاکسازی کش جستجو/تگ‌های سالمند: حذف index فایل خراب در File mode و orphan members در Redis
$scheduler->hourly(function () {
    $cache = Cache::getInstance();
    $driver = $cache->driver();
    $cleaned = 0;

    if ($driver === 'redis') {
        $redis = $cache->redis();
        if ($redis instanceof \Redis) {
            $iterator = null;
            $pattern = $cache->redisKey('tag:*');

            while (false !== ($setKeys = $redis->scan($iterator, $pattern, 100))) {
                foreach ($setKeys as $setKey) {
                    $membersResult = $redis->sMembers($setKey);
                    $members = is_array($membersResult) ? $membersResult : [];
                    if (empty($members)) {
                        $redis->del($setKey);
                        continue;
                    }

                    $validMembers = [];
                    foreach ($members as $member) {
                        if ($redis->exists($member)) {
                            $validMembers[] = $member;
                        }
                    }

                    if (count($validMembers) !== count($members)) {
                        // FIX-P3-CMD-152 (یافتهٔ ۱۵۲): del + re-add قبلی دو دستور جداگانه و
                        // غیراتمیک بود و نویسندهٔ هم‌زمان می‌توانست بین دو دستور، set نیمه‌خالی
                        // ببیند. اکنون جایگزینی اعضا در یک تراکنش Redis MULTI اتمیک انجام
                        // می‌شود — بدون اسکریپت Lua (لایهٔ Commands/Console primitive اجرای
                        // کد پویا ندارد؛ قرارداد پین S18). اگر MULTI نبود/شکست خورد، به
                        // مسیر قبلی best-effort برمی‌گردیم (پاکسازی طبق شواهد، best-effort
                        // مستند است).
                        $replaced = false;
                        if (method_exists($redis, 'multi') && method_exists($redis, 'exec')) {
                            try {
                                $pipe = $redis->multi(\Redis::MULTI);
                                $pipe->del($setKey);
                                if (!empty($validMembers)) {
                                    $pipe->sAdd($setKey, ...$validMembers);
                                }
                                $txResult = $pipe->exec();
                                $replaced = is_array($txResult);
                            } catch (\Throwable $txError) {
                                $replaced = false;
                            }
                        }
                        if (!$replaced) {
                            $redis->del($setKey);
                            if (!empty($validMembers)) {
                                $redis->sAdd($setKey, ...$validMembers);
                            }
                        }
                        $cleaned += count($members) - count($validMembers);
                    }
                }
            }
        }
    } else {
        $tagsDir = base_path('storage/cache/tags/');
        foreach (glob($tagsDir . '*.json') ?: [] as $indexFile) {
            $content = @file_get_contents($indexFile);
            $decodedContent = $content !== false ? json_decode($content, true) : null;
            $keys = is_array($decodedContent) ? $decodedContent : [];
            $valid = [];

            foreach ($keys as $key) {
                if (is_string($key) && $cache->has($key)) {
                    $valid[] = $key;
                }
            }

            if (empty($valid)) {
                @unlink($indexFile);
                $cleaned += count($keys);
            } elseif (count($valid) !== count($keys)) {
                // FIX-P3-CMD-152 (یافتهٔ ۱۵۲): بازنویسی index قبلاً مستقیم و بدون قفل/
                // اتمیک بود و خوانندهٔ هم‌زمان می‌توانست index نیمه‌نوشته ببیند. اکنون
                // نوشتن در tmp + rename اتمیک است؛ شکستِ نوشتن ⇒ index فعلی دست‌نخورده
                // می‌ماند و دور بعد دوباره تلاش می‌شود (شمارش cleaned فقط روی موفقیت).
                $tmpIndex = $indexFile . '.tmp-' . getmypid();
                $bytesWritten = @file_put_contents($tmpIndex, json_encode(array_values($valid)));
                if ($bytesWritten !== false && @rename($tmpIndex, $indexFile)) {
                    $cleaned += count($keys) - count($valid);
                } else {
                    @unlink($tmpIndex);
                }
            }
        }
    }

    return [
        'stale_search_cache_cleaned' => $cleaned,
        'cache_driver' => $driver,
    ];
}, 'stale_search_cache_cleanup');

// ✅ **ممیزی ساعتی تراکنش‌ها و دفاتر کل** 🔄
// بررسی و مانیتورینگ سلامت سیستم مالی (فقط گزارش مغایرت)
$scheduler->hourly(function () {
    try {
        $db = Database::getInstance();
        
        // ⚠️ حذف منطق ناامن تایید خودکار تراکنش‌های یتیم که پیش‌تر اینجا بود و یک حفره مالی محسوب می‌شد.
        // ممیزی از این پس فقط به صورت پسیو (تحلیلی) ناسازگاری‌ها را به لاگر اطلاع می‌دهد.
        
        // بررسی ناسازگاری‌های ledger (debit vs credit)
        // 🔐 RECON FIX (out-of-batch): ledger_entries جدول double-entry است (ستون‌های account,
        // debit, credit — ستون‌های قدیمی user_id/amount هرگز وجود نداشتند؛ FIX راند ۷۷ ستون شبح).
        // ناورایی واقعی در دفتر کل: هر transaction باید جمع debit == جمع credit باشد؛
        // بررسی به تفکیک ارز انجام می‌شود تا IRT و USDT مخلوط نشوند.
        //
        // FIX-P3-CMD-159 (یافتهٔ ۱۵۹): پنجرهٔ ۲ساعته عمدی است و همین‌جا مستند می‌شود —
        // این جاب ساعتی است و پنجره با تیک بعدی هم‌پوشانی دارد (تیکِ عقب‌افتاده هم
        // ردیف‌های تیکِ گم‌شده را می‌بیند؛ حفرهٔ زمانی وجود ندارد). اسکنِ ردیف‌های
        // مغایرت نیز سقف LIMIT گرفت و برخورد به سقف با truncated=true صادقانه در
        // خروجی گزارش می‌شود؛ ماندگاریِ cursor ممیزی (ریزش دستی سنگین‌تر روی state
        // فایل/جدول) عمداً رد شد — این اسکن فقط گزارشگرِ منفعل است.
        $auditCap = 1000;
        $mismatches = $db->fetchAll(
            "SELECT transaction_id, currency, SUM(debit) - SUM(credit) as balance
             FROM ledger_entries
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR)
             GROUP BY transaction_id, currency
             HAVING balance IS NOT NULL AND balance <> 0
             LIMIT ?",
            [$auditCap]
        );
        $truncated = count($mismatches) >= $auditCap;

        $warnings = 0;
        $bcmathMissingLogged = false;
        foreach ($mismatches as $mismatch) {
            // 🔐 float→decimal FIX: compare the ledger balance with exact BCMath decimal math.
            // The DECIMAL SUM(amount) arrives as a string; casting to float and testing
            // !== 0.0 could both miss a real mismatch and raise a false alarm from binary
            // rounding. bccomp yields an exact zero / non-zero verdict at 8-dp precision.
            //
            // FIX-P3-CMD-160 (یافتهٔ ۱۶۰): bccomp قبلاً بدون پروب اکستنشن صدا زده می‌شد —
            // نبودِ BCMath فatal می‌داد و کل ممیزی ساعتی را می‌شکست. اکنون fail-closed:
            // بدون BCMath هیچ ردیفی بی‌صدا «سالم» فرض نمی‌شود (همه مغایرت شمرده می‌شوند)
            // و یک‌بار error لاگ می‌شود تا اپراتور اکستنشن را نصب کند.
            $balanceStr = (string)($mismatch->balance ?? '0');
            if (!is_numeric($balanceStr)) {
                continue;
            }
            if (function_exists('bccomp')) {
                $isMismatch = bccomp($balanceStr, '0', 8) !== 0;
            } else {
                $isMismatch = true;
                if (!$bcmathMissingLogged) {
                    $bcmathMissingLogged = true;
                    logger()->error('reconciliation.bcmath_missing', [
                        'hint' => 'BCMath extension is required for exact ledger audit; until it is installed every scanned row is treated as a mismatch.',
                    ]);
                }
            }
            if ($isMismatch) {
                $warnings++;
                logger()->warning('reconciliation.ledger_mismatch', [
                    'transaction_id' => $mismatch->transaction_id ?? null,
                    'currency' => $mismatch->currency ?? 'irt',
                    'balance_mismatch' => $mismatch->balance,
                    'timestamp' => date('Y-m-d H:i:s')
                ]);
            }
        }

        return [
            'ledger_mismatches_detected' => $warnings,
            'scan_window' => '2h',
            'scan_cap' => $auditCap,
            'truncated' => $truncated,
            'timestamp' => date('Y-m-d H:i:s')
        ];
    } catch (\Throwable $e) {
        logger()->error('reconciliation.hourly_audit.failed', [
            'error' => $e->getMessage(),
            'exception' => get_class($e),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);
        return ['error' => $e->getMessage()];
    }
}, 'hourly_reconciliation_audit');

// انقضای نشست‌های قدیمی کاربران (بیش از ۳۰ روز)
$scheduler->hourly(function () {
    $db = Database::getInstance();
    // FIX-P3-CMD-154 (یافتهٔ ۱۵۴): DELETE تک‌عبارتیِ بی‌LIMIT روی user_sessions در
    // جدول بزرگ مدت‌ها قفل می‌گرفت (برخلاف پاکسازی chunked سنتری). اکنون دسته‌ای با
    // LIMIT 5000 تا خالی‌شدنِ پنجره تکرار می‌شود؛ سقف ایمنی ۲۰۰۰ دور (۱۰M ردیف در
    // هر تیک) — باقیمانده به تیک ساعتی بعد می‌رود و برخورد به سقف لاگ می‌شود.
    $batchSize = 5000;
    $deletedTotal = 0;
    $guard = 0;
    do {
        $deleted = (int) $db->execute(
            "DELETE FROM user_sessions
             WHERE last_activity < DATE_SUB(NOW(), INTERVAL 30 DAY)
             LIMIT {$batchSize}"
        );
        $deletedTotal += $deleted;
    } while ($deleted === $batchSize && ++$guard < 2000);

    if ($deleted === $batchSize) {
        logger()->warning('cron.cleanup_sessions.batch_cap_reached', [
            'deleted_total' => $deletedTotal,
            'note' => 'more expired sessions remain; next hourly tick continues',
        ]);
    }

    return ['deleted_sessions' => $deletedTotal];
}, 'cleanup_sessions');

// MED-04 Fix: پاک‌سازی توکن‌های بازیابی رمز عبور منقضی شده (بیش از یک ساعت)
$scheduler->hourly(function () use ($container) {
    $model = $container->make(\App\Models\SecurityModel::class);
    $count = $model->deleteExpiredPasswordResets(3600);
    return ['deleted_tokens' => $count];
}, 'cleanup_password_resets');

// چرخش لاگ‌های اپلیکیشن (جلوگیری از حجیم شدن فایل‌ها)
$scheduler->hourly(function () use ($container) {
    $logService = $container->make(\App\Services\LogService::class);
    
    // استفاده از متد بازتابی یا فراخوانی مستقیم در صورتی که عمومی شود
    // اما در اینجا می‌توانیم cleanup را با 0 روز صدا بزنیم که هم لاگ‌های دیتابیس را پاک نکند، هم فایل‌ها را بچرخاند.
    // یا اینکه از یک Job یا تابع عمومی برای Rotate استفاده کنیم.
    $logService->cleanup(90); // این هم rotate می‌کند و هم قدیمی‌ها را پاک می‌کند
    return ['status' => 'rotated'];
}, 'rotate_logs');

// پاک‌سازی پیام‌های realtime منقضی‌شده
$scheduler->hourly(function () use ($container) {
    $service = $container->make(\App\Services\WebSocketService::class);
    $deleted = $service->cleanupExpiredMessages();
    $processed = $service->processAllDelayedMessages();
    return ['deleted_messages' => $deleted, 'processed_delayed' => $processed];
}, 'websocket_cleanup');

/**
 * ─────────────────────────────────────────
 * روزانه ساعت ۰۲:۰۰
 * ─────────────────────────────────────────
 */

// بررسی سطح کاربران (downgrade/upgrade/expire)
$scheduler->daily('02:00', function () use ($container) {
    $service = $container->make(UserLevelService::class);

    $downgrades = $service->checkDowngrades();
    $expired    = $service->checkExpiredPurchases();

    return [
        'downgraded' => count($downgrades),
        'expired'    => $expired,
    ];
}, 'user_levels');

// ==============================
// Retention: Activity/System/Security Logs (Weekly - Sunday)
// ==============================
$scheduler->daily('02:30', function () use ($container) {
    if ((int) date('w') !== 0) {
        return ['skipped' => 'cleanup_logs weekly (sunday only)'];
    }

    $logService = $container->make(\App\Services\LogService::class);
    $days = int_value(feature_config('cron_cleanup_days', 'rollout_percentage', 30));

    return [
        'log_cleanup' => $logService->cleanup($days),
    ];
}, 'cleanup_logs');


// ==============================
// Financial Export Backup (Daily)
// ==============================
// FIX-CMD145 (یافتهٔ ۱۵۰… یافتهٔ ۱۴۵): این اکسپورتِ سنگین قبلاً هم‌زمان با پردازش
// حذف حساب و monthly_level_reset روی ۰۴:۰۰ بود (سه مسیر سنگین روی یک رأس)
// — به ۰۳:۰۵ منتقل شد تا پیکِ فشار DB پخش شود.
$scheduler->daily('03:05', function () {
    $db = Database::getInstance();
    $exportDir = base_path('storage/exports/financial/');
    // FIX-CMD146 (یافتهٔ ۱۴۶): دایرکتوری اکسپورت مالی حاوی PII/دادهٔ مالی کامل است —
    // مجوز ۰۷۵۰ (نه ۰۷۵۵ جهان‌خوان) + .htaccess deny-all برای دیپلوی‌های Apache.
    if (!is_dir($exportDir)) {
        if (!@mkdir($exportDir, 0750, true) && !is_dir($exportDir)) {
            logger()->error('financial_export.mkdir_failed', ['dir' => $exportDir]);
            return ['error' => 'export_dir_unwritable'];
        }
    }
    // deny-all برای هر وب‌سروری که storage/ را serve کند (دفاع لایه‌ای)
    $ht = $exportDir . '.htaccess';
    if (!is_file($ht)) {
        @file_put_contents($ht, "Require all denied\nDeny from all\n");
        @chmod($ht, 0640);
    }

    $windowStart = date('Y-m-d 00:00:00', (strtotime('yesterday') ?: time()));
    $windowEnd = date('Y-m-d 23:59:59', (strtotime('yesterday') ?: time()));
    $timeTag = date('Ymd_His');

    $files = [];
    $written = 0;
    $errors = [];

    // FIX-CMD148 (یافتهٔ ۱۴۸): نوشتن در فایل tmp و rename اتمیک — فایل نهایی هرگز
    // نیمه‌کاره دیده نمی‌شود و تصادم نام بر اساس ثانیه حذف می‌شود (نشان متفاوت در tmp).
    $transactionsFile = $exportDir . 'transactions_' . $timeTag . '.csv';
    $ledgerFile = $exportDir . 'ledger_entries_' . $timeTag . '.csv';

    // FIX-CMD147 (یافتهٔ ۱۴۷): LIMIT ۱۰۰٬۰۰۰ حذف شد — به‌جای آن keyset pagination
    // روی id؛ روزهای پرتراکنش دیگر truncate بی‌صدا نمی‌شوند (خروجی مالی کامل است؛
    // سقف ایمنی ۲٬۰۰۰٬۰۰۰ ردیف برای هر خروجی).
    // FIX-CMD148: نوشتن در tmp و rename اتمیک — فایل نهایی هرگز نیمه‌کاره دیده نمی‌شود.
    // FIX-CMD149: خطاهای فایل (mkdir/fopen/fputcsv/fclose/rename) نادیده گرفته
    // نمی‌شوند — صریح بررسی، لاگ و در خروجی کرون گزارش می‌شوند.
    $exportTable = function (string $table, string $finalPath) use ($db, $windowStart, $windowEnd, &$written, &$errors): int {
        $tmpPath = $finalPath . '.tmp-' . getmypid();
        $handle = fopen($tmpPath, 'w');
        if ($handle === false) {
            $errors[] = 'fopen_failed: ' . basename($finalPath);
            logger()->error('financial_export.fopen_failed', ['file' => $tmpPath]);
            return 0;
        }

        $first = true;
        $count = 0;
        $lastId = 0;
        $batch = 5000;
        $maxRows = 2000000;
        try {
            while ($count < $maxRows) {
                $stmt = $db->query(
                    "SELECT * FROM {$table}
                     WHERE created_at BETWEEN ? AND ?
                       AND id > ?
                     ORDER BY id ASC
                     LIMIT ?",
                    [$windowStart, $windowEnd, $lastId, $batch]
                );
                $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
                if (!is_array($rows) || $rows === []) {
                    break;
                }
                foreach ($rows as $row) {
                    if ($first) {
                        if (fputcsv($handle, array_keys($row)) === false) {
                            throw new \RuntimeException('header_write_failed: ' . basename($finalPath));
                        }
                        $first = false;
                    }
                    $csvValues = [];
                    foreach (array_values($row) as $value) {
                        $csvValues[] = is_scalar($value) || $value === null
                            ? $value
                            : json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    }
                    if (fputcsv($handle, $csvValues) === false) {
                        throw new \RuntimeException('row_write_failed: ' . basename($finalPath));
                    }
                    $count++;
                    if ((int)$row['id'] > $lastId) {
                        $lastId = (int)$row['id'];
                    }
                }
            }
        } catch (\Throwable $e) {
            @fclose($handle);
            @unlink($tmpPath);
            $errors[] = $e->getMessage();
            logger()->error('financial_export.write_failed', ['file' => $tmpPath, 'error' => $e->getMessage()]);
            return 0;
        }

        if (@fclose($handle) === false) {
            @unlink($tmpPath);
            $errors[] = 'fclose_failed: ' . basename($finalPath);
            logger()->error('financial_export.fclose_failed', ['file' => $tmpPath]);
            return 0;
        }
        // FIX-CMD146: فایل فقط برای مالک سرویس خوانا (۰۶۰۰)
        @chmod($tmpPath, 0600);
        if (!rename($tmpPath, $finalPath)) {
            @unlink($tmpPath);
            $errors[] = 'rename_failed: ' . basename($finalPath);
            logger()->error('financial_export.rename_failed', ['from' => $tmpPath, 'to' => $finalPath]);
            return 0;
        }
        $written += $count;
        return $count;
    };

    $txCount = $exportTable('transactions', $transactionsFile);
    $ledgerCount = $exportTable('ledger_entries', $ledgerFile);

    if ($txCount > 0) {
        $files[] = $transactionsFile;
    }
    if ($ledgerCount > 0) {
        $files[] = $ledgerFile;
    }

    return [
        'transactions_exported' => $txCount,
        'ledger_entries_exported' => $ledgerCount,
        'files' => $files,
        'export_window' => date('Y-m-d', (strtotime('yesterday') ?: time())),
    ];
}, 'financial_export_backup');


// ==============================
// Retention: Audit Trail Archive (Check daily, run every 30 days)
// ==============================
$scheduler->daily('02:40', function () use ($container) {
    $archiveDir = base_path('storage/audit-archives');
    if (!is_dir($archiveDir)) {
        @mkdir($archiveDir, 0755, true);
    }

    $stateFile = $archiveDir . '/.last_archive_at';
    $now = time();

    // FIX-P3-CMD-151 (یافتهٔ ۱۵۱): چک‌اند‌رایتِ state فایل قبلاً با
    // file_exists/file_get_contents و نوشتن با file_put_contents ساده بود —
    // بدون flock و غیراتمیک، پس دو کرون موازی می‌توانستند هر دو آرشیو کنند.
    // اکنون: (۱) قفل exclusive غیرمسدودکننده دورِ کل چک‌اند‌رایت (کرون موازی ⇒
    // skip، نه آرشیو دوباره)، (۲) نوشتنِ نهایی با tmp + rename اتمیک (الگوی
    // FIX-CMD148) تا state هرگز نیمه‌کاره دیده نشود. قفل روی فایل جانبیِ
    // .last_archive_at.lock نگه داشته می‌شود تا rename اتمیک، inodeِ قفل را
    // عوض نکند.
    $lockFile = $archiveDir . '/.last_archive_at.lock';
    $lockHandle = @fopen($lockFile, 'c');
    if ($lockHandle === false) {
        logger()->error('archive_audit_trail.state_lock_unavailable', ['file' => $lockFile]);
        return ['error' => 'archive_state_lock_unavailable'];
    }
    if (!flock($lockHandle, LOCK_EX | LOCK_NB)) {
        fclose($lockHandle);
        return ['skipped' => 'archive_audit_trail locked by another run'];
    }

    if (is_file($stateFile)) {
        $last = (int) trim((string) @file_get_contents($stateFile));
        if ($last > 0 && ($now - $last) < (30 * 86400)) {
            flock($lockHandle, LOCK_UN);
            fclose($lockHandle);
            return ['skipped' => 'archive_audit_trail every 30 days'];
        }
    }

    $audit = $container->make(\App\Services\AuditTrail::class);
    $result = $audit->archiveOlderThan(30, 2000);

    if (!empty($result['file'])) {
        $tmpState = $stateFile . '.tmp-' . getmypid();
        if (@file_put_contents($tmpState, (string) $now) !== false && @rename($tmpState, $stateFile)) {
            // state با موفقیت اتمیک به‌روز شد
        } else {
            @unlink($tmpState);
            logger()->error('archive_audit_trail.state_write_failed', ['file' => $stateFile]);
        }
    }

    flock($lockHandle, LOCK_UN);
    fclose($lockHandle);

    return $result;
}, 'archive_audit_trail');


// ==============================
// Retention: Sentry-like Tables (Weekly - Sunday, chunked)
// ==============================
$scheduler->daily('02:50', function () {
    if ((int) date('w') !== 0) {
        return ['skipped' => 'cleanup_sentry weekly (sunday only)'];
    }

    $db = \Core\Database::getInstance();
    $result = [
        'deleted_sentry_issues' => 0,
        'deleted_system_alerts' => 0,
    ];

    // sentry_issues
    $stmt = $db->query("SHOW TABLES LIKE ?", ['sentry_issues']);
    if ($stmt->fetchColumn()) {
        do {
            $deleted = (int) $db->execute(
                "DELETE FROM sentry_issues
                 WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)
                 LIMIT 5000"
            );
            $result['deleted_sentry_issues'] += $deleted;
        } while ($deleted === 5000);
    }

    // system_alerts
    $stmt = $db->query("SHOW TABLES LIKE ?", ['system_alerts']);
    if ($stmt->fetchColumn()) {
        do {
            $deleted = (int) $db->execute(
                "DELETE FROM system_alerts
                 WHERE is_active = 0
                   AND created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)
                 LIMIT 5000"
            );
            $result['deleted_system_alerts'] += $deleted;
        } while ($deleted === 5000);
    }

    return $result;
}, 'cleanup_sentry');

// ==========================================
// Log Growth Guard (Daily 03:10)
// اگر حجم لاگ در یک ساعت اخیر غیرعادی شد، هشدار ثبت می‌کند
// ==========================================
$scheduler->daily('03:10', function () {
    $db = \Core\Database::getInstance();

    $threshold = 2000; // می‌تونی بعدا از env بخونی
    $result = [
        'activity_logs_last_hour' => 0,
        'system_logs_last_hour' => 0,
        'security_logs_last_hour' => 0,
        'performance_logs_last_hour' => 0,
        'alerts' => [],
    ];

    $queries = [
        'activity_logs_last_hour' => "SELECT COUNT(*) FROM activity_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
        'system_logs_last_hour' => "SELECT COUNT(*) FROM system_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
        'security_logs_last_hour' => "SELECT COUNT(*) FROM security_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
        'performance_logs_last_hour' => "SELECT COUNT(*) FROM performance_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
    ];

    foreach ((array)$queries as $key => $sql) {
        try {
            $stmt = $db->query($sql);
            $count = (int)$stmt->fetchColumn();
            $result[$key] = $count;

            if ($count >= $threshold) {
                logger()->warning('logs.growth.spike.detected', [
                    'channel' => 'monitoring',
                    'metric' => $key,
                    'count' => $count,
                    'threshold' => $threshold,
                ]);
                $result['alerts'][] = ['metric' => $key, 'count' => $count];
            }
        } catch (\Throwable $e) {
            logger()->error('logs.growth.guard.failed', [
                'channel' => 'monitoring',
                'metric' => $key,
                'error' => $e->getMessage(),
            ]);
        }
    }

    return $result;
}, 'log_growth_guard');

// پاک‌سازی ایمیل‌های ارسال‌شده قدیمی (بیش از ۳۰ روز)
$scheduler->daily('03:00', function () {
    $db      = Database::getInstance();
    $affected = $db->execute(
        // FIX-X213: جدول email_queue ستون sent_at ندارد (شِما: updated_at) — DELETE قبلی
        // هر اجرا با SQLSTATE[42S22] شکست می‌خورد (کشف از ردیف ERROR خودکار تب «سیستم»).
        // updated_at همان لحظهٔ تغییر وضعیت به sent است.
        "DELETE FROM email_queue
         WHERE status = 'sent'
           AND updated_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
    return ['deleted_emails' => $affected];
}, 'cleanup_email_queue');

// پاک‌سازی خطاهای قدیمی نهایی شده در Poison Messages (بیش از ۳۰ روز)
$scheduler->daily('03:05', function () use ($container) {
    $queue = $container->make(Queue::class);
    $publisher = $container->make(\App\Services\OutboxPublisher::class);
    $days = max(1, min(365, int_value(feature_config('cron_dlq_retention_days', 'rollout_percentage', 30))));
    
    // هر دو مخزن صف-مرده پاکسازی می‌شوند: failed_jobs (dead_letter/quarantined)
    // و outbox_events (status='dlq') که قبلاً هیچ مسیر پاکسازی نداشت.
    $deleted = $queue->cleanDeadLetters($days);
    $deletedOutbox = $publisher->purgeDeadLetters($days);
    
    return [
        'deleted_dead_letters' => $deleted,
        'deleted_outbox_dlq'   => $deletedOutbox
    ];
}, 'cleanup_dead_letters');

// پردازش پرداخت‌های زمانبندی‌شده
$scheduler->daily('03:15', function () use ($container) {
    $service = $container->make(\App\Services\ScheduledPaymentService::class);
    $limit   = int_value(feature_config('cron_scheduled_payment_batch_size', 'rollout_percentage', 50));
    if ($limit < 1) { $limit = 50; }

    // cursor/drain: هر batch حداکثر $limit پرداختِ سررسیده را پردازش می‌کند؛ چون پرداختِ
    // پردازش‌شده از پنجرهٔ due خارج می‌شود (next_run_at جلو می‌رود یا وضعیت failed/paused/
    // completed می‌گیرد)، تا خالی‌شدنِ کاملِ صف تکرار می‌کنیم تا backlog نماند. گاردِ اطمینان.
    // FIX-CMD155 (یافتهٔ ۱۵۵): به‌جای گارد تعدادیِ بی‌اثر (۱۰۰٬۰۰۰ iteration = busy-loop
    // چندساعته روی backlog عظیم)، بودجهٔ زمانی ۵۰ ثانیه‌ای + سقف ۲۰۰ batch اعمال می‌شود؛
    // باقیمانده به تیک روزانهٔ بعد می‌رود (کرون روزانه است، backlog همیشه فردا زهکش می‌شود).
    $totals = ['processed' => 0, 'failed' => 0, 'batches' => 0];
    $guard  = 0;
    $startedAt = microtime(true);
    $timeBudgetExhausted = false;
    do {
        if (++$guard > 200 || (microtime(true) - $startedAt) > 50.0) {
            $timeBudgetExhausted = true;
            break;
        }
        $result = $service->processDuePayments($limit);
        $p = int_value($result['processed'] ?? 0);
        $f = int_value($result['failed'] ?? 0);
        $totals['processed'] += $p;
        $totals['failed']    += $f;
        $totals['batches']++;
    } while (($p + $f) >= $limit);

    if ($timeBudgetExhausted) {
        $totals['drain_incomplete'] = true;
        logger()->info('scheduled_payments.drain_time_budget', $totals);
    }

    return $totals;
}, 'scheduled_payments');

// پاک‌سازی تصاویر KYC رد شده قدیمی (۶۰ روز)
$scheduler->daily('03:30', function () {
    $db   = Database::getInstance();
    $cleaned   = 0;
    $errors    = 0;
    $batchSize = 1000;
    $lastId    = 0;
    $guard     = 0;
    // cursor: به‌جای بارگذاری همهٔ ردیف‌ها یک‌جا، batch‌به‌batch با cursorِ id تا خالی‌شدنِ
    // کامل پیش می‌رویم تا مصرف حافظه مهار شود. ردیفِ پاک‌شده documents_deleted=1 می‌گیرد
    // و از فیلتر خارج می‌شود؛ cursorِ id هم جلوی لوپ روی ردیفی که UPDATEاش شکست بخورد را می‌گیرد.
    do {
        if (++$guard > 100000) { break; }

        $rows = $db->fetchAll(
            // FIX-X212: ستون‌های واقعی جدول front_image/back_image/selfie_image هستند؛
            // SELECT قبلی document_front/document_back/selfie می‌خواند و هر اجرا با
            // SQLSTATE[42S22] شکست می‌خورد (از ردیف ERROR خودکار تب «سیستم» کشف شد).
            "SELECT id, front_image, back_image, selfie_image
             FROM kyc_verifications
             WHERE status = 'rejected'
               AND updated_at < DATE_SUB(NOW(), INTERVAL 60 DAY)
               AND documents_deleted = 0
               AND id > ?
             ORDER BY id ASC
             LIMIT {$batchSize}",
            [$lastId]
        ) ?: [];
        $fetched = count($rows);

        foreach ($rows as $row) {
            $row = (array)$row;
            if ((int)$row['id'] > $lastId) {
                $lastId = (int)$row['id'];
            }
            // FIX-P3-CMD-153 (یافتهٔ ۱۵۳): کارِ per-row در try/catch جدا — استثنای
            // UPDATE (یا هر خطای دیگری) دیگر کل batch و دورهای بعدی را abort نمی‌کند؛
            // شمرده، لاگ و حلقه ادامه می‌یابد. cursorِ id تضمین می‌کند ردیفِ
            // شکست‌خورده در تیک بعدی دوباره برداشته شود. شکستِ unlink (فقط warning
            // PHP است) طبق شواهد مسیر را متوقف نمی‌کرد و همچنان نمی‌کند.
            try {
                foreach (['front_image', 'back_image', 'selfie_image'] as $field) { // FIX-X212: نام ستون‌های واقعی
                    if (!empty($row[$field])) {
                        $baseDir = realpath(storage_path('uploads/kyc'));
                        $file = basename((string) $row[$field]);
                        $path = realpath($baseDir . DIRECTORY_SEPARATOR . $file);

                        if (
                            $path !== false &&
                            $baseDir !== false &&
                            str_starts_with($path, $baseDir . DIRECTORY_SEPARATOR)
                        ) {
                            unlink($path);
                        }
                    }
                }
                $db->execute(
                    "UPDATE kyc_verifications SET documents_deleted = 1 WHERE id = ?",
                    [$row['id']]
                );
                $cleaned++;
            } catch (\Throwable $e) {
                $errors++;
                logger()->error('cleanup_kyc_files.row_failed', [
                    'document_id' => (int)$row['id'],
                    'error' => $e->getMessage(),
                ]);
            }
        }
    } while ($fetched === $batchSize);

    return ['cleaned_kyc_files' => $cleaned, 'errors' => $errors];
}, 'cleanup_kyc_files');

// ✅ **Idempotency Key Cleanup - مهم برای جلوگیری از رشد نامحدود DB**
// حذف کلیدهای منقضی‌شده (۹۰ روز برای عملیات مالی)
$scheduler->daily('03:45', function () use ($container) {
    try {
        $idempotencyKey = $container->make(\App\Services\Shared\IdempotencyService::class);
        $deleted = $idempotencyKey->cleanup(false); // Live delete
        
        if ($deleted > 0) {
            logger()->info('idempotency.cleanup.completed', [
                'channel' => 'maintenance',
                'deleted_keys' => $deleted,
                'timestamp' => date('Y-m-d H:i:s'),
            ]);
        }
        
        return [
            'deleted_idempotency_keys' => $deleted,
            'retention_days' => 90,
        ];
    } catch (\Throwable $e) {
        logger()->error('idempotency.cleanup.failed', [
            'channel' => 'maintenance',
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);
        return ['error' => $e->getMessage()];
    }
}, 'idempotency_cleanup');

/**
 * ─────────────────────────────────────────
 * روزانه ساعت ۰۴:۰۰ - ریست ماهانه
 * ─────────────────────────────────────────
 */

// ریست آمار ماهانه سطح کاربران (اول هر ماه)
$scheduler->daily('04:00', function () use ($container) {
    if ((int)date('j') !== 1) {
        return ['skipped' => 'not first day of month'];
    }
    $service = $container->make(UserLevelService::class);
    $reset   = $service->monthlyReset();
    return ['reset_users' => $reset];
}, 'monthly_level_reset');

// R90 فاز N-4 — پاداش ماهانهٔ صدرنشین جدول رفرال (اول هر ماه، بعد از ریست سطح‌ها).
// عمداً Job class ساخته نشده (FatJobAuditTest وجود DistributeMonthlyReferralRewardsJob را
// به‌عنوان کد مرده ممنوع می‌کند) — الگوی همان monthly_level_reset: closure با make از کانتینر.
// گیت opt-in (referral_monthly_bonus_enabled؛ پیش‌فرض خاموش) + ایدمپوتنسی ماهانه داخل خودِ
// ReferralService::distributeMonthlyRewards است؛ در حالت خاموش no-op خالص برمی‌گردد.
$scheduler->daily('04:10', function () use ($container) {
    if ((int)date('j') !== 1) {
        return ['skipped' => 'not first day of month'];
    }
    $service = $container->make(\App\Services\Shared\ReferralService::class);
    $result  = $service->distributeMonthlyRewards();
    return [
        'rewarded' => (bool)($result['rewarded'] ?? false),
        'user_id'  => $result['user_id'] ?? null,
    ];
}, 'referral_monthly_bonus');

/**
 * ─────────────────────────────────────────
 * هفتگی - یکشنبه ساعت ۰۵:۰۰
 * ─────────────────────────────────────────
 */

// گزارش هفتگی KPI به ادمین
$scheduler->weekly('Sunday', '05:00', function () {
    $db = Database::getInstance();

    // تعداد ثبت‌نام‌های هفته گذشته
    $newUsers = (int)$db->fetchColumn(
        "SELECT COUNT(*) FROM users
         WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );

    // ذخیره در cache برای داشبورد ادمین
    // FIX-CMD157 (یافتهٔ ۱۵۷): KPI مالی به‌صورت رشتهٔ decimal (قرارداد پولِ سامانه)
    // نگه داشته می‌شود — float cast قبلاً دقت ۱۳+ رقم را خراب می‌کرد؛
    // این خروجی برای محاسبهٔ پولی مجدد استفاده می‌شود، نه نمایش ریاضی JS.
    // FIX-CMD158 (یافتهٔ ۱۵۸): پنجرهٔ گزارش با NOW() خودِ DB ساخته می‌شود تا با
    // ساعت DB هم‌خوان باشد؛ ساعتِ فراخوانیِ خودِ scheduler از APP_TIMEZONE پیروی
    // می‌کند (بوت‌استرپ date_default_timezone_set را از .env می‌گذارد) — قرارداد:
    // مرز تقویمِ هفتگی = APP_TIMEZONE، پنجرهٔ داده = DB.
    $txVolume = (string)$db->fetchColumn(
        "SELECT COALESCE(SUM(amount), 0) FROM transactions
         WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
           AND status = 'completed'"
    );

    Cache::getInstance()->put('kpi_weekly_report', [
        'new_users'    => $newUsers,
        'tx_volume'    => $txVolume,
        'generated_at' => date('Y-m-d H:i:s'),
    ], 10080); // یک هفته

    return ['new_users' => $newUsers, 'tx_volume' => $txVolume];
}, 'weekly_kpi_report');

// توزیع سود/ضرر سرمایه‌گذاری هفتگی به صورت Asynchronous (جلوگیری از قفل شدن Cron)
$scheduler->weekly('Sunday', '05:10', function () use ($container) {
    // FIX-CMD156: dedup صریح در سطح هفته — صف اگر کند باشد، pushهای هفتگی
    // انباشت نمی‌شوند (کلید هفتهٔ ISO؛ TTL ۸ روز).
    $container->make(Queue::class)->pushUnique(
        \App\Jobs\InvestmentProfitDistributionJob::class,
        [],
        'investment_profit_distribution:' . date('oW'),
        null,
        0,
        8 * 86400
    );
    return ['status' => 'queued'];
}, 'investment_profit_distribution');

// ==========================================
//  SocialTask Jobs
// ==========================================


// ── هر شب ساعت ۱:۳۰ — Trust Score هفتگی (بهبود + جریمه soft_excess)
$scheduler->daily('01:30', function () use ($container) {
    $svc    = $container->make(TrustService::class);
    $result = $svc->recoverWeekly(\App\Enums\ModuleContext::SOCIAL_TASKS);
    return $result;
}, 'social_task_trust_recovery');

// ── هر روز صبح — ارسال یادآوری برای بررسی تسک‌های انجام‌شده (Task Management)
$scheduler->daily('09:00', function () use ($container) {
    // FIX-CMD156: dedup روزانه — تیک‌های هم‌پوشان/backlog صف، یادآوری تکراری نمی‌سازد
    $container->make(Queue::class)->pushUnique(
        \App\Jobs\SocialTaskApprovalReminderJob::class,
        [],
        'social_task_approval_reminder:' . date('Ymd'),
        null,
        0,
        2 * 86400
    );
    return ['status' => 'queued'];
}, 'social_task_approval_reminder');

// ── هر ساعت — انقضای execution های زمان‌گذشته (بیش از ۲۴ ساعت pending)
// FIX-9a-5 (Audit Task 9-a): هر slot دقیقاً یک‌بار برگردانده می‌شود. نسخهٔ قبلی
// اول UPDATE انقضا را می‌زد و بعد شمارش «همهٔ» expiredهای یک ساعتِ اخیر (شامل
// اجراهایی که ران‌های قبلی منقضی کرده بودند) را به remaining_slots اضافه
// می‌کرد ⇒ slotها چند بار برمی‌گشتند (تورم ظرفیت آگهی). اکنون در یک تراکنش،
// دقیقاً همان سطرهایی که این ران منقضی می‌کند (claim با FOR UPDATE) منقضی و
// slot همان idهای claimed برگردانده می‌شود — اتمیک و بدون شمارش مضاعف.
$scheduler->hourly(function () {
    $db = Database::getInstance();
    $expired = 0;
    $restored = 0;

    $db->beginTransaction();
    try {
        // ۱) claim سطرهای واجد شرایط انقضا (سقف ۱۰۰۰ در هر ران — بقیه در تیک بعدی)
        $rows = $db->fetchAll(
            "SELECT id, ad_id FROM social_task_executions
             WHERE status = 'pending'
               AND created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)
             ORDER BY id ASC
             LIMIT 1000
             FOR UPDATE"
        );

        if (!empty($rows)) {
            $ids = [];
            foreach ($rows as $row) {
                $ids[] = (int)$row->id;
            }
            $idList = implode(',', $ids); // int-cast شده — امن برای IN

            // ۲) انقضای فقط همین سطرهای claimed
            $expired = (int) $db->execute(
                "UPDATE social_task_executions
                 SET status = 'expired', updated_at = NOW()
                 WHERE id IN ({$idList})"
            );

            // ۳) بازگرداندن slot دقیقاً به تعداد/idهای همین ران (دقیقاً یک‌بار)
            if ($expired > 0) {
                $restored = (int) $db->execute(
                    "UPDATE social_ads sa
                     JOIN (
                         SELECT ad_id, COUNT(*) AS cnt
                         FROM social_task_executions
                         WHERE id IN ({$idList})
                         GROUP BY ad_id
                     ) ex ON ex.ad_id = sa.id
                     SET sa.remaining_slots = sa.remaining_slots + ex.cnt
                     WHERE sa.status = 'active'"
                );
            }
        }

        $db->commit();
    } catch (\Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollback();
        }
        throw $e;
    }

    return ['expired' => $expired, 'slot_updates' => $restored];
}, 'social_task_expire_pending');

// ==========================================
//  اجرا
// ==========================================
// X130-fix: echo سرگردان در سطح متد حذف شد — این متد در وب هم فراخوانی می‌شود
// (رجیستری پنل ادمین) و echo خروجی صفحه را خراب می‌کرد؛ cron.php بنر خودش را دارد.

// ─────────────────────────────────────────────────────────────────
//  اینفلوئنسر مارکت‌پلیس
// ─────────────────────────────────────────────────────────────────

/**
 * هر ساعت: تایید خودکار buyer check هایی که مهلتشان گذشته
 * وقتی buyer در ۲۴ ساعت پاسخ ندهد → auto-approve → پرداخت به اینفلوئنسر
 */
// مشکل #12: نام job برای مانیتورینگ/دیباگ اضافه شد
$scheduler->hourly(function () use ($container) {
    $service = $container->make(InfluencerService::class);
    $count   = $service->processExpiredBuyerChecks();
    if ($count > 0) {
        // FIX-P3-CMD-164: echo → logger (اجرای مشترک CLI/web)
        logger()->info("Influencer: auto-approved {$count} buyer-check timeout orders");
    }
    return ['approved' => $count];
}, 'influencer_buyer_check_timeout');

/**
 * هر ساعت: رد خودکار سفارش‌هایی که اینفلوئنسر در مهلت پاسخ نداده
 */
$scheduler->hourly(function () use ($container) {
    $service = $container->make(InfluencerService::class);
    $count   = $service->processExpiredPendingAcceptance();
    if ($count > 0) {
        // FIX-P3-CMD-164: echo → logger (اجرای مشترک CLI/web)
        logger()->info("Influencer: auto-rejected {$count} orders with no influencer response");
    }
    return ['rejected' => $count];
}, 'influencer_expire_pending_acceptance');

/**
 * هر ساعت: escalate اختلاف‌هایی که peer resolution timeout شده
 */
$scheduler->hourly(function () use ($container) {
    $service = $container->make(DisputeService::class);
    $count   = $service->processExpiredPeerResolutions();
    if ($count > 0) {
        // FIX-P3-CMD-164: echo → logger (اجرای مشترک CLI/web)
        logger()->info("Influencer: escalated {$count} peer-resolution timeouts to admin");
    }
    return ['escalated' => $count];
}, 'influencer_escalate_peer_resolution');

/**
 * روزانه: پاکسازی فایل‌های مدرک قدیمی
 */
$scheduler->daily('05:00', function () use ($container) {
    $service = $container->make(InfluencerService::class);
    $count   = $service->cleanupOldFiles(3);
    if ($count > 0) {
        // FIX-P3-CMD-164: echo → logger (اجرای مشترک CLI/web)
        logger()->info("Influencer: cleaned up proof files for {$count} orders");
    }
    return ['cleaned_orders' => $count];
}, 'influencer_cleanup_proof_files');

// ─────────────────────────────────────────────────────────────────────────────
// Phase 5e — Advanced Settings & Management
// ─────────────────────────────────────────────────────────────────────────────

/**
 * روزانه: حذف خودکار حساب‌های منقضی و پاک‌سازی فایل‌های صادر شده
 */
$scheduler->daily('04:00', function () use ($container) {
    try {
        $accountDeletionService = $container->make(\App\Services\User\AccountDeletionService::class);
        $dataExportService = $container->make(\App\Services\DataExportService::class);

        // حذف حساب‌های منقضی
        $deletedCount = $accountDeletionService->processExpiredDeletionRequests();

        // پاک‌سازی فایل‌های منقضی
        $deletedFiles = $dataExportService->deleteExpiredExports();

        // FIX-P3-CMD-161 (یافتهٔ ۱۶۱): نتیجه از stdout به logger منتقل شد — این
        // closure از CronController (رجیستری وب ادمین) هم اجرا می‌شود و echo خروجی
        // وب را خراب می‌کرد؛ پیام خام استثنا هم جایی جز لاگ نمی‌رود.
        logger()->info('cron.process_scheduled_tasks.completed', [
            'expired_deletions_processed' => (int) $deletedCount,
            'expired_export_files_deleted' => (int) $deletedFiles,
        ]);
        return ['expired_deletions_processed' => (int) $deletedCount, 'expired_export_files_deleted' => (int) $deletedFiles];
    } catch (\Exception $e) {
        // FIX-P3-CMD-163 (یافتهٔ ۱۶۳): شکست دیگر success-like پنهان نمی‌شود —
        // وضعیت failed با پیام کلی (جزئیات فقط در لاگ) به مانیتورینگ می‌رسد.
        logger()->error('cron.process_scheduled_tasks.failed', ['error' => $e->getMessage()]);
        return ['status' => 'failed', 'reason' => 'scheduled_tasks_failed (details in logs)'];
    }
}, 'process_scheduled_tasks');

/**
 * هر ساعت: آزادسازی خودکار escrow های منقضی شده
 */
$scheduler->hourly(function () use ($container) {
    $container->make(Queue::class)->push(\App\Jobs\EscrowTimeoutJob::class);
    return ['status' => 'queued'];
}, 'escrow_timeout_release');

/**
 * هر ۱۰ دقیقه: اسکن خودکار برداشت‌های گیر کرده (stuck withdrawal)
 * 🛡️ Bug Fix: قبلاً فقط به صورت CLI دستی قابل اجرا بود
 */
$scheduler->everyMinutes(10, function () use ($container) {
    $job = $container->make(\App\Jobs\WithdrawalTimeoutJob::class);
    $result = $job->handle();
    return [
        'scanned' => $result['scanned'] ?? 0,
        'flagged' => $result['flagged'] ?? 0,
    ];
}, 'withdrawal_stuck_timeout');

/**
 * هر ساعت: رد خودکار KYCهای منقضی شده
 * 🛡️ Bug Fix: قبلاً هیچ cron ای برای timeout KYC وجود نداشت
 */
$scheduler->hourly(function () use ($container) {
    $job = $container->make(\App\Jobs\KycTimeoutJob::class);
    $result = $job->handle();
    return [
        'scanned'       => $result['scanned'] ?? 0,
        'auto_rejected' => $result['auto_rejected'] ?? 0,
    ];
}, 'kyc_timeout_reject');

/**
 * روزانه: پاکسازی اعلان‌های قدیمی
 */
$scheduler->daily('04:10', function () use ($container) {
    $container->make(Queue::class)->push(\App\Jobs\NotificationCleanupJob::class);
    return ['status' => 'queued'];
}, 'notification_cleanup');

/**
 * هر ساعت: انقضای لیست ویترین و آزادسازی Holdهای منقضی شده
 */
$scheduler->hourly(function () use ($container) {
    // FIX-CMD156: dedup ساعتی برای Job دوره‌ای — بدون آن کندی ورکر به انباشت
    // ردیف‌های تکراری در صف می‌انجامید
    $container->make(Queue::class)->pushUnique(
        \App\Jobs\VitrineListingExpiryJob::class,
        [],
        'vitrine_listing_expiry:' . date('Ymd-H'),
        null,
        0,
        2 * 3600
    );
    return ['status' => 'queued'];
}, 'vitrine_listing_expiry');

/**
 * روزانه: ریزش امتیاز کاربران غایب
 */
$scheduler->daily('02:20', function () use ($container) {
    $cronService = $container->make(\App\Services\Cron\CronService::class);
    return $cronService->applyInactivityScoreDecay();
}, 'inactivity_score_decay');

/**
 * FIX-X320 (تسک ۸۳): زمان‌بندی بازوزن‌کردن شانس لاتاری — UpdateLotteryChanceScoresJob
 * موجود بود ولی هیچ ورودی زمان‌بندی نداشت (فقط import بلااستفادهٔ LotteryService) و
 * chance_score شرکت‌کنندگان هرگز تغییر نمی‌کرد. روزانه ۰۳:۲۰ برای هر دورهٔ فعال/رأی‌گیریِ
 * دارای عدد روزانهٔ امروز اجرا می‌شود؛ Job خودش idempotent است (کلید
 * lottery:vote:{round}:{user}:{date} در ScoreService) و تراکنش داخلی دارد.
 */
$scheduler->daily('03:20', function () use ($container) {
    $db  = $container->make(\Core\Database::class);
    $job = $container->make(\App\Jobs\Lottery\UpdateLotteryChanceScoresJob::class);

    $rounds = $db->fetchAll(
        "SELECT DISTINCT r.id AS round_id
         FROM lottery_rounds r
         JOIN lottery_daily_numbers d ON d.round_id = r.id AND d.date = CURDATE() AND d.is_deleted = 0
         WHERE r.status IN ('active','voting') AND r.is_deleted = 0"
    );

    $processed = 0;
    $failed    = 0;
    foreach ($rounds as $row) {
        $res = $job->handle((int) $row->round_id, date('Y-m-d'));
        if (!empty($res['success'])) {
            $processed++;
        } else {
            $failed++;
        }
    }

    return ['rounds_found' => count($rounds), 'processed' => $processed, 'failed' => $failed];
}, 'lottery_chance_scores');

/**
 * هر ۱۵ دقیقه: تسویه خودکار بازی‌های پیش‌بینی
 */
$scheduler->everyMinutes(15, function () use ($container) {
    // FIX-CMD156: dedup در سطح بازهٔ ۱۵ دقیقه‌ای (بازهٔ زمانی به سقف رند شده)
    $bucket = date('Ymd-Hi', (int)(time() - (time() % 900)));
    $container->make(Queue::class)->pushUnique(
        \App\Jobs\PredictionGameSettlementJob::class,
        [],
        'prediction_game_settlement:' . $bucket,
        null,
        0,
        1800
    );
    return ['status' => 'queued'];
}, 'prediction_game_settlement');

/**
 * روزانه: به‌روزرسانی لیست Tor Exit Nodes
 */
$scheduler->daily('04:20', function () use ($container) {
    $command = $container->make(\App\Commands\UpdateTorExitNodesCommand::class);
    // FIX-CMD137 (یافتهٔ ۱۳۷): شکست update دیگر با status=ok پوشانده نمی‌شود —
    // استثنا catch و status=failed با پیام کلی (جزئیات در لاگ) برگردانده می‌شود.
    // FIX-P3-CMD-162 (یافتهٔ ۱۶۲): run() از FIX-C141 به بعد int برمی‌گرداند؛
    // قبلاً کد خروج نادیده گرفته می‌شد و هر شکستِ بدون استثنا (exit=1، مثل
    // خطای دانلود provider) هم status=ok گزارش می‌شد. اکنون نتیجهٔ واقعی
    // آینه می‌شود: exit غیرصفر ⇒ failed با کد خروج (بدون متن خام provider).
    try {
        $exitCode = $command->run([]);
        if ($exitCode !== 0) {
            logger()->error('tor_exit_nodes.update_failed', ['exit_code' => $exitCode]);
            return ['status' => 'failed', 'reason' => "update_failed (exit_code={$exitCode}; details in logs)"];
        }
        return ['status' => 'ok'];
    } catch (\Throwable $e) {
        logger()->error('tor_exit_nodes.update_failed', ['error' => $e->getMessage()]);
        return ['status' => 'failed', 'reason' => 'update_failed (details in logs)'];
    }
}, 'update_tor_exit_nodes');


// ─────────────────────────────────────────────────────────────────────────────
// نوتیفیکیشن — Scheduling & Analytics
// ─────────────────────────────────────────────────────────────────────────────

/**
 * هر دقیقه: ارسال نوتیفیکیشن‌های زمان‌بندی‌شده
 */
$scheduler->everyMinute(function () use ($container) {
    $notifModel = $container->make(NotificationModel::class);
    $pending    = $notifModel->getPendingScheduled(50);

    if (empty($pending)) {
        return ['processed' => 0];
    }

    $notifService = $container->make(NotificationService::class);
    $processed    = 0;

foreach ($pending as $notif) {
    // FIX-CMD143/CMD144: claim اتمیک تحویل — علامت‌گذاری فقط وقتی مالکیت این
    // تیک را داریم (sent_at خالی؛ rowCount=1) و اثر جانبی (بطلان کش) بعد از آن.
    // قبلاً markAsSent بدون گارد قبل از هر اثر جانبی زده می‌شد و دو تیک هم‌پوشان
    // بدون حصار همان ردیف را دوبار پردازش می‌کردند.
    if (!$notifModel->claimAsSent((int)$notif->id)) {
        continue; // تیک موازی قبلاً تحویل را انجام داده
    }

    $notifService->invalidateUnreadCache((int)$notif->user_id);
    $processed++;
}

    if ($processed > 0) {
        // FIX-P3-CMD-164: echo → logger (اجرای مشترک CLI/web) — فقط تیکِ دارای کار
        // لاگ می‌شود تا system_logs با تیک دقیقه‌ایِ خالی اسپم نشود.
        logger()->info("Notification: processed {$processed} scheduled notifications");
    }

    return ['processed' => $processed];
}, 'notification_scheduled');


/**
 * هر ساعت: آرشیو نوتیفیکیشن‌های منقضی‌شده
 */
$scheduler->hourly(function () use ($container) {
    $notifModel = $container->make(NotificationModel::class);
    $count      = $notifModel->archiveExpired();

    // مشکل #11: رشته echo صحیح
    if ($count > 0) {
        // FIX-P3-CMD-164: echo → logger (اجرای مشترک CLI/web)
        logger()->info("Notification: archived {$count} expired notifications");
    }

    return ['archived' => $count];
}, 'notification_expire');

/**
 * هر ساعت: batch aggregation آمار نوتیفیکیشن
 */
$scheduler->hourly(function () use ($container) {
    $notifService = $container->make(NotificationService::class);
    $result       = $notifService->runBatchAggregation();
    if (($result['updated'] ?? 0) > 0) {
        // FIX-P3-CMD-164: echo → logger (اجرای مشترک CLI/web)
        logger()->info("Notification: aggregated {$result['sent']} notifications across {$result['updated']} groups");
    }
    return $result;
}, 'notification_analytics');

// اجرای OutboxPublisher هر X ثانیه (قابل تنظیم توسط ادمین)
$scheduler->everySeconds(int_value(setting('outbox_publish_interval', 60)), function () {
    // توضیح: OutboxPublisher مسئول ارسال رویدادهای ذخیره‌شده در جدول Outbox به سیستم پیام‌رسان است.
    // کاهش این مقدار باعث ارسال سریع‌تر پیام‌ها می‌شود اما بار سرور را افزایش می‌دهد.
    // X129-fix: «php» در PATH سرور وجود ندارد (exit_code=127 در هر اجرا) → اکنون
    // باینری PHPِ درحال اجرا (PHP_BINARY) استفاده می‌شود و مسیرها escape می‌شوند.
    $command = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg(BASE_PATH . '/cli.php') . ' outbox:publish --limit=100';
    exec($command, $output, $exitCode);
    if ($exitCode !== 0) {
        logger()->error('cron.outbox_publish.failed', ['output' => $output, 'exit_code' => $exitCode]);
    }
    return ['output' => $output, 'exit_code' => $exitCode];
}, 'outbox_publisher');

$scheduler->daily('04:30', function () use ($container) {
    // FIX-P3-CMD-161 (یافتهٔ ۱۶۱): echoهای نتیجه و خطای خام از stdout حذف و به
    // logger منتقل شدند — این closure از CronController (رجیستری وب ادمین) هم
    // اجرا می‌شود و echo خروجی وب را خراب می‌کرد؛ پیام خام استثنا فقط در لاگ.
    logger()->info('cron.database_maintenance.started');
    try {
        $maintenanceService = $container->make(\App\Services\MaintenanceService::class);
        $results = $maintenanceService->runDailyMaintenance();

        logger()->info('cron.database_maintenance.completed', ['results' => $results]);
        return is_array($results) ? $results : ['results' => $results];
    } catch (\Throwable $e) {
        // FIX-P3-CMD-163 (یافتهٔ ۱۶۳): شکست maintenance دیگر success-like نیست.
        logger()->error('cron.database_maintenance.failed', ['error' => $e->getMessage()]);
        return ['status' => 'failed', 'reason' => 'maintenance_failed (details in logs)'];
    }
}, 'database_maintenance');

// هر ۵ دقیقه: تازه‌سازی داده‌های داشبورد (Materialized View)
$scheduler->everyMinutes(5, function () use ($container) {
    // FIX-P3-CMD-161 (یافتهٔ ۱۶۱): خروجی پیشرفت/خطای خام از stdout حذف شد (اجرای
    // مشترک CLI/web؛ echo خروجی وب را خراب می‌کرد). موفقیتِ این جاب پرفرکانس
    // بی‌صدا است (result توسط Scheduler لاگ می‌شود) تا system_logs اسپم نشود.
    try {
        $transactionQuery = $container->make(\App\Models\TransactionQuery::class);
        $transactionQuery->refreshMaterializedView();
        return ['status' => 'ok'];
    } catch (\Throwable $e) {
        // FIX-P3-CMD-163 (یافتهٔ ۱۶۳): شکست refresh دیگر success-like نیست.
        logger()->error('cron.mv_refresh.failed', ['error' => $e->getMessage()]);
        return ['status' => 'failed', 'reason' => 'mv_refresh_failed (details in logs)'];
    }
}, 'dashboard_mv_refresh');

// [FIX-R91-B] راند ۹۱ — جاروب شبانهٔ آپلود آف‌سایت: بکاپ‌های completed با
// offsite_status='pending'/'failed' (مثلاً شکستِ آپلودِ همان‌لحظه‌ای پس از createBackup)
// به مقصد خارجی (S3 سازگار / FTPS) ارسال می‌شوند. خودِ سرویس no-op امن است اگر
// offsite_backup_enabled=0 باشد (fail-open به «هیچ‌کاری نکردن»).
$scheduler->daily('05:15', function () use ($container) {
    // FIX-P3-CMD-161 (یافتهٔ ۱۶۱): echo نتیجه/خطای خام به logger منتقل شد (اجرای
    // مشترک CLI/web). FIX-P3-CMD-163 (یافتهٔ ۱۶۳): شکست sync دیگر success-like پنهان نمی‌ماند.
    try {
        $offsite = $container->make(\App\Services\OffsiteBackupService::class);
        $result = $offsite->syncPending(10);
        logger()->info('cron.offsite_backup_sync.completed', ['result' => $result]);
        return is_array($result) ? $result : ['result' => $result];
    } catch (\Throwable $e) {
        logger()->error('cron.offsite_backup_sync.failed', ['error' => $e->getMessage()]);
        return ['status' => 'failed', 'reason' => 'offsite_sync_failed (details in logs)'];
    }
}, 'offsite_backup_sync');

// [FIX-X358/X359] راند ۹۱ — بازسازی دوره‌ای پروجکشن user_scores از لجر score_events
// (هفتگی، پشتِ پنجرهٔ نگهداری شبانه). در سندباکس همان کامند از outbox-worker.sh با
// گارد ساعتی redis هم فراخوانی می‌شود؛ این ورودی برای پروداکشن است (بدون worker).
// --force لازم نیست: گارد ساعتیِ داخل کامند برای فراخوانی هفتگی گذراست.
$scheduler->weekly('Sunday', '05:30', function () use ($container) {
    // FIX-P3-CMD-161 (یافتهٔ ۱۶۱): echo به logger منتقل شد. FIX-P3-CMD-163:
    // شکست (استثنا یا exit code غیرصفرِ FIX-C141) دیگر success-like گزارش نمی‌شود.
    try {
        $command = $container->make(\App\Commands\ScoresRebuildCommand::class);
        $exitCode = $command->run([]);
        if ($exitCode !== 0) {
            logger()->error('cron.scores_rebuild.failed', ['exit_code' => $exitCode]);
            return ['status' => 'failed', 'reason' => "scores_rebuild_failed (exit_code={$exitCode})"];
        }
        logger()->info('cron.scores_rebuild.completed');
        return ['status' => 'ok'];
    } catch (\Throwable $e) {
        logger()->error('cron.scores_rebuild.failed', ['error' => $e->getMessage()]);
        return ['status' => 'failed', 'reason' => 'scores_rebuild_failed (details in logs)'];
    }
}, 'scores_rebuild');

// هر یک دقیقه: مانیتورینگ بلادرنگ عمق صف‌ها (Queue Depth Monitoring)
$scheduler->everyMinutes(1, function () use ($container) {
    try {
        $queue = $container->make(Queue::class);
        $queues = ['high_priority', 'default', 'analytics', 'notifications', 'maintenance'];
        
        $stats = [];
        $hasBacklog = false;
        
        foreach ($queues as $qName) {
            $size = $queue->size($qName);
            $stats[$qName] = $size;
            
            // آستانه هشدار برای هر صف
            $threshold = match($qName) {
                'high_priority' => 1000,
                'default' => 5000,
                default => 10000,
            };
            
            if ($size >= $threshold) {
                $hasBacklog = true;
                logger()->critical('queue_monitoring.backlog_alert', [
                    'queue' => $qName,
                    'current_depth' => $size,
                    'threshold' => $threshold,
                    'action_required' => 'Auto-scale consumers or investigate blockages'
                ]);
            }
        }
        
        // ارسال متریک‌ها به سرویس مانیتورینگ/گرافانا
        logger()->info('queue_monitoring.depth_metrics', $stats);
        
        if ($hasBacklog) {
            // FIX-P3-CMD-164: echo → logger (اجرای مشترک CLI/web)؛ جزئیات هر صف
            // قبلاً با queue_monitoring.backlog_alert (critical) لاگ شده است.
            logger()->warning('queue_monitoring.backlog_detected', ['depth' => $stats]);
        }
        
        return ['status' => 'ok', 'depth' => $stats];
    } catch (\Throwable $e) {
        logger()->error('queue_monitoring.failed', ['error' => $e->getMessage()]);
        return ['status' => 'error', 'message' => $e->getMessage()];
    }
}, 'queue_depth_monitor');
    }
}
