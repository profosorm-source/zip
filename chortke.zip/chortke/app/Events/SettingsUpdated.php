<?php

declare(strict_types=1);

namespace App\Events;

class SettingsUpdated
{
    /** @var array<int|string, mixed> */
    public array $changedKeys;

    /**
     * @param array<int|string, mixed> $changedKeys
     */
    public function __construct(array $changedKeys = []) {
        $this->changedKeys = $changedKeys;
    }
}
