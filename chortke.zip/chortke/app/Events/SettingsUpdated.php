<?php

declare(strict_types=1);

namespace App\Events;

class SettingsUpdated
{
    /** @var array<string, mixed> */
    public array $changedKeys;

    /**
     * @param array<string, mixed> $changedKeys
     */
    public function __construct(array $changedKeys = []) {
        $this->changedKeys = $changedKeys;
    }
}
