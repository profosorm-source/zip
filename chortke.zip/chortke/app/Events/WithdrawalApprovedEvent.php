<?php

declare(strict_types=1);

namespace App\Events;

use Core\Event;

class WithdrawalApprovedEvent extends Event
{
    public int $userId;
    public int $withdrawalId;
    /**
     * FIX-R36-W3 (F-A19d-08): money follows the platform decimal-string contract
     * (never float in money - pattern InvestmentCreatedEvent). Union float|string
     * keeps legacy float callers working: floats are normalized to decimal strings
     * (sprintf %%.10F) so scientific notation can never leak into payloads.
     */
    public float|string $amount;
    public string $currency;
    public int $approvedBy;
    public \DateTimeInterface $occurredAt;
    public function __construct(
        int $userId,
        int $withdrawalId,
        float|string $amount,
        string $currency = 'irt',
        int $approvedBy = 0,
        \DateTimeInterface $occurredAt = new \DateTimeImmutable()
    ) {        $this->userId = $userId;
        $this->withdrawalId = $withdrawalId;
        // FIX-R36-W3 (F-A19d-08): normalize legacy float callers to decimal-string
        $this->amount = is_float($amount)
            ? rtrim(rtrim(sprintf('%.10F', $amount), '0'), '.')
            : $amount;
        $this->currency = $currency;
        $this->approvedBy = $approvedBy;
        $this->occurredAt = $occurredAt;

        parent::__construct([
            'user_id' => $userId,
            'withdrawal_id' => $withdrawalId,
            'amount' => $this->amount,
            'currency' => $currency,
            'approved_by' => $approvedBy,
            'occurred_at' => $occurredAt->format(\DateTime::ATOM)
        ]);
    }
}
