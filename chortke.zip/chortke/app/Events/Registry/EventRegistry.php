<?php

declare(strict_types=1);

namespace App\Events\Registry;

/**
 * EventRegistry
 * 
 * Defines standardized domain event names across the application.
 * Replaces hardcoded string-based events (like 'wallet.deposit.requested')
 * with context-aware Domain Events to enable true EDA and Choreography.
 */
class EventRegistry
{
    // Content & Marketing
    public const CONTENT_REVENUE_GENERATED = 'content.revenue.generated';
    public const BANNER_REVENUE_GENERATED  = 'banner.revenue.generated';
    
    // Finance & Crypto
    public const CRYPTO_DEPOSIT_CONFIRMED  = 'crypto.deposit.confirmed';
    public const GATEWAY_PAYMENT_SUCCESS   = 'gateway.payment.success';

    // Social & Influencers
    public const CUSTOM_TASK_VERIFIED      = 'custom_task.verified';
    public const CUSTOM_TASK_REFUNDED      = 'custom_task.refunded';
    public const INFLUENCER_ORDER_COMPLETED = 'influencer_order.completed';
    public const INFLUENCER_ORDER_REFUNDED  = 'influencer_order.refunded';
    public const INFLUENCER_ORDER_PARTIAL_REFUNDED = 'influencer_order.partial_refunded';
    
    // Investment & Escrow
    public const INVESTMENT_MATURED        = 'investment.matured';
    public const ESCROW_RELEASED           = 'escrow.released';
    
    // Gamification & Prediction
    public const LOTTERY_ROUND_FINISHED    = 'lottery_round.finished';
    public const LOTTERY_ROUND_CANCELLED   = 'lottery_round.cancelled';
    public const PREDICTION_BET_WON        = 'prediction_bet.won';
    public const PREDICTION_BET_REFUNDED   = 'prediction_bet.refunded';
    
    // Moderation & Users
    public const DISPUTE_RESOLVED_REFUND   = 'dispute.resolved.refund';
    public const REFERRAL_COMMISSION_EARNED= 'referral.commission.earned';
    
    // Legacy Events (To be deprecated)
    public const WALLET_DEPOSIT_REQUESTED  = 'wallet.deposit.requested';

    // 🧹 S31-C-W1-6: getDepositTriggerEvents() و getDepositTriggerPatterns() حذف شدند
    // (حذف مستدل با تأیید کاربر — CONSULT-6: هیچ فراخوان کدی نداشتند؛ فقط داک کهنه
    // docs/event_registry_enhancement.md به آن‌ها ارجاع می‌داد که علامت superseded خورد).
    // ثابت‌های بالا (Financial Events) زنده‌اند و توسط InfluencerCommandService و
    // CryptoDepositService استفاده می‌شوند.
}

