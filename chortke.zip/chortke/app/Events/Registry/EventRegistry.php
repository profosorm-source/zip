<?php

declare(strict_types=1);

namespace App\Events\Registry;

/**
 * EventRegistry
 * 
 * Defines standardized domain event names across the application.
 * Replaces hardcoded string-based events (like 'wallet.deposit.requested')
 * with context-aware Domain Events to enable true EDA and Choreography.
 *
 * 🧹 FIX-R22-B5 (D6 راند ۲۱-C): ۱۱ ثابتِ خفته (۰ تولیدکننده + ۰ شنونده) حذف شدند:
 * content.revenue.generated، banner.revenue.generated، gateway.payment.success،
 * custom_task.verified، custom_task.refunded، investment.matured،
 * lottery_round.finished، lottery_round.cancelled، prediction_bet.won،
 * prediction_bet.refunded، dispute.resolved.refund — هر یک پیش از حذف با
 * جستجوی نام ثابت + مقدار رشته‌ای در کل کدبیس تأیید شد که بی‌مصرف‌اند.
 * (رویدادهای زندهٔ هم‌ارزِ این نام‌ها از مسیرهای canonical سیم‌شده
 * مثل wallet.deposit.requested پردازش می‌شوند — FIX-OUTBOX-DEAD-WALLET.)
 */
class EventRegistry
{
    // Finance & Crypto (ثبت‌های outbox زنده: InfluencerCommandService / CryptoDepositService)
    public const CRYPTO_DEPOSIT_CONFIRMED  = 'crypto.deposit.confirmed';

    // Social & Influencers
    public const INFLUENCER_ORDER_COMPLETED = 'influencer_order.completed';
    public const INFLUENCER_ORDER_REFUNDED  = 'influencer_order.refunded';
    public const INFLUENCER_ORDER_PARTIAL_REFUNDED = 'influencer_order.partial_refunded';
    
    // Investment & Escrow
    public const ESCROW_RELEASED           = 'escrow.released';
    
    // Moderation & Users
    public const REFERRAL_COMMISSION_EARNED= 'referral.commission.earned';
    
    // Legacy Events (To be deprecated)
    public const WALLET_DEPOSIT_REQUESTED  = 'wallet.deposit.requested';

    // 🧹 S31-C-W1-6: getDepositTriggerEvents() و getDepositTriggerPatterns() حذف شدند
    // (حذف مستدل با تأیید کاربر — CONSULT-6: هیچ فراخوان کدی نداشتند؛ فقط داک کهنه
    // docs/event_registry_enhancement.md به آن‌ها ارجاع می‌داد که علامت superseded خورد).
    // ثابت‌های بالا (Financial Events) زنده‌اند و توسط InfluencerCommandService و
    // CryptoDepositService استفاده می‌شوند.
}

