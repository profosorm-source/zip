<?php

declare(strict_types=1);

namespace App\Events;

use Core\Event;

/**
 * Observability event fired when a P2P wallet transfer passes the effective
 * fraud gate (FIX-S18-1) and is about to acquire locks.
 *
 * ⚠️ Phase-3 E2E finding (RuntimeHttpBehaviorTest, 2026-09-23): this class was
 * dispatched by WalletService::transfer() but never defined — every P2P web
 * transfer crashed with 500 «خطای سیستمی در انتقال» ("Class not found").
 * The class is intentionally listener-free (pure observability payload), so
 * defining it restores the documented behavior without changing the gate.
 */
class WalletTransferInitiatingEvent extends Event
{
    public int $fromUserId;
    public int $toUserId;
    public string $amount;
    public string $currency;
    public \DateTimeInterface $occurredAt;

    public function __construct(
        int $fromUserId,
        int $toUserId,
        string|int|float $amount,
        string $currency = 'irt',
        \DateTimeInterface $occurredAt = new \DateTimeImmutable()
    ) {
        $this->fromUserId = $fromUserId;
        $this->toUserId = $toUserId;
        $this->amount = (string)$amount;
        $this->currency = $currency;
        $this->occurredAt = $occurredAt;

        parent::__construct([
            'from_user_id' => $fromUserId,
            'to_user_id'   => $toUserId,
            'amount'       => (string)$amount,
            'currency'     => $currency,
            'occurred_at'  => $occurredAt->format(\DateTime::ATOM),
        ]);
    }
}
