<?php

declare(strict_types=1);

namespace App\Events;

use Core\Event;

class AuditRecordedEvent extends Event
{
    public string $eventName;
    public ?int $userId;
    /** @var array<string, mixed> */
    public array $context;
    public ?int $actorId;

    /**
     * 🛡️ FIX-X217: نتیجهٔ واقعی ماندگاری شنونده.
     * قبلاً record() پس از dispatch همیشه true برمی‌گرداند — حتی وقتی شنونده
     * غایب بود (باگ X209) یا INSERT شکست می‌خورد؛ یعنی «صدای دروغ موفقیت».
     * حالا PersistAuditRecordListener نتیجهٔ واقعی را روی همین پرچم می‌نویسد و
     * AuditTrail::record() همان را صادقانه برمی‌گرداند.
     */
    public bool $persisted = false;

    /**
     * @param array<string, mixed> $context
     */
    public function __construct(string $eventName, ?int $userId = null, array $context = [], ?int $actorId = null) {
        parent::__construct();
        $this->eventName = $eventName;
        $this->userId = $userId;
        $this->context = $context;
        $this->actorId = $actorId;
    }
}
