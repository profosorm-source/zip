<?php

declare(strict_types=1);

namespace App\Events;

use Core\Event;

class EscrowReleasedEvent extends Event
{
    public int $escrowId;
    public int $userId;
    /**
     * FIX-R36-W3 (F-A19d-08): money follows the platform decimal-string contract
     * (never float in money - pattern InvestmentCreatedEvent). Union float|string
     * keeps legacy float callers working: floats are normalized to decimal strings
     * (sprintf %%.10F) so scientific notation can never leak into payloads.
     */
    public float|string $amount;
    public string $currency;
    public \DateTimeInterface $occurredAt;
    public function __construct(
        int $escrowId,
        int $userId,
        float|string $amount,
        string $currency = 'irt',
        \DateTimeInterface $occurredAt = new \DateTimeImmutable()
    ) {        $this->escrowId = $escrowId;
        $this->userId = $userId;
        // FIX-R36-W3 (F-A19d-08): normalize legacy float callers to decimal-string
        $this->amount = is_float($amount)
            ? rtrim(rtrim(sprintf('%.10F', $amount), '0'), '.')
            : $amount;
        $this->currency = $currency;
        $this->occurredAt = $occurredAt;

        parent::__construct([
            'escrow_id' => $escrowId,
            'user_id' => $userId,
            'amount' => $this->amount,
            'currency' => $currency,
            'occurred_at' => $occurredAt->format(\DateTime::ATOM)
        ]);
    }
}
