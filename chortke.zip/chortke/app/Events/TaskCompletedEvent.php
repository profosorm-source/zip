<?php

declare(strict_types=1);

namespace App\Events;

use Core\Event;

class TaskCompletedEvent extends Event
{
    public int $userId;
    public int $taskId;
    /** ⚠️ FIX-M22-MED (D1-N3): این فیلد در عمل «مبلغ پاداش» مجری است نه مقدار XP —
     * مقدار XP واقعی از تنظیمات (xp_custom_task) در TaskCompletedListener خوانده
     * می‌شود. نام فیلد برای سازگاری با payloadهای outbox قدیمی حفظ شده است. */
    public float $xp;
    public string $context;
    /**
     * شناسهٔ ارسانی که رویداد برای آن صادر شده (FIX-M22-03).
     * TaskCompletedListener کلیدهای idempotency XP/trust را per-submission
     * می‌سازد تا در تسک‌های چندمجریه فقط اولین مجری پاداش گیمیفیکیشن نگیرد
     * (کلید نهایی ScoreCommandService یعنی «score_idemp:{key}» نه entityId دارد
     * نه userId). null = رویدادهای legacy که هنوز submission ندارند (fallback کلید per-task).
     */
    public ?int $submissionId;
    public \DateTimeInterface $occurredAt;
    public function __construct(
        int $userId,
        int $taskId,
        float $xp = 0.0,
        string $context = '',
        ?int $submissionId = null,
        \DateTimeInterface $occurredAt = new \DateTimeImmutable()
    ) {        $this->userId = $userId;
        $this->taskId = $taskId;
        $this->xp = $xp;
        $this->context = $context;
        $this->submissionId = $submissionId;
        $this->occurredAt = $occurredAt;

        parent::__construct([
            'user_id' => $userId,
            'task_id' => $taskId,
            'xp' => $xp,
            'context' => $context,
            'submission_id' => $submissionId,
            'occurred_at' => $occurredAt->format(\DateTime::ATOM)
        ]);
    }
}
