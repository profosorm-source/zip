<?php

declare(strict_types=1);

namespace App\Events;

use Core\Event;

class TaskCompletedEvent extends Event
{
    public int $userId;
    public int $taskId;
    public float $xp;
    public string $context;
    /**
     * شناسهٔ ارسانی که رویداد برای آن صادر شده (FIX-M22-03).
     * TaskCompletedListener کلیدهای idempotency XP/trust را per-submission
     * می‌سازد تا در تسک‌های چندمجریه فقط اولین مجری پاداش گیمیفیکیشن نگیرد
     * (کلید نهایی ScoreCommandService یعنی «score_idemp:{key}» نه entityId دارد
     * نه userId). null = رویدادهای legacy که هنوز submission ندارند (fallback کلید per-task).
     */
    public ?int $submissionId;
    public \DateTimeInterface $occurredAt;
    public function __construct(
        int $userId,
        int $taskId,
        float $xp = 0.0,
        string $context = '',
        ?int $submissionId = null,
        \DateTimeInterface $occurredAt = new \DateTimeImmutable()
    ) {        $this->userId = $userId;
        $this->taskId = $taskId;
        $this->xp = $xp;
        $this->context = $context;
        $this->submissionId = $submissionId;
        $this->occurredAt = $occurredAt;

        parent::__construct([
            'user_id' => $userId,
            'task_id' => $taskId,
            'xp' => $xp,
            'context' => $context,
            'submission_id' => $submissionId,
            'occurred_at' => $occurredAt->format(\DateTime::ATOM)
        ]);
    }
}
