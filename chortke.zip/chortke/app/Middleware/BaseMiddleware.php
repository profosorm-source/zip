<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Response;

/**
 * BaseMiddleware — کلاس پایه انتزاعی برای به اشتراک‌گذاری کدهای تکراری میان‌افزارها
 */
abstract class BaseMiddleware
{
    /**
     * کپسوله‌سازی پاسخ برگشتی جهت یکپارچگی خروجی‌ها (حل تکرار کد در ۱۴ فایل Middleware)
     */
    protected function toResponse(mixed $result): Response
    {
        if ($result instanceof Response) {
            return $result;
        }

        $response = new Response();
        $str = str_value($result);

        // FIX-R42: رشته‌ای که view helper/BaseController::view همین حالا echo کرده
        // (نشانهٔ hash فعال است) نباید دوباره به‌عنوان content پاسخ ثبت شود — وگرنه
        // همان HTML یک‌بار با flush بافر خروجی و یک‌بار با send پاسخ emit می‌شود و
        // کل صفحه دوبار رندر می‌شود (باگ صفحهٔ لاتاری: doctype=2 و SyntaxError
        // «Identifier '__rvBodyOrigHtml_boost' has already been declared»).
        if ($str !== ''
            && isset($GLOBALS['_last_view_helper_echo_hash'])
            && hash_equals($GLOBALS['_last_view_helper_echo_hash'], hash('sha256', $str))) {
            return $response; // محتوا قبلاً emit شده است؛ پاسخِ بدون content کافی است.
        }

        $response->setContent($str);
        return $response;
    }
}
