<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Closure;

/**
 * HttpsMiddleware — اجبار به استفاده از پروتکل امن HTTPS
 */
class HttpsMiddleware
{
    public function handle(Request $request, Closure $next): mixed
    {
        $env = config('app.env', 'production');

        if ($env === 'production' && !$request->isSecure()) {
            // Obtain authoritative host ONLY from application configuration to prevent Host Header Injection.
            $appUrl = rtrim((string)config('app.url', ''), '/');
            
            if (empty($appUrl)) {
                // Critical Fallback: اگر APP_URL تنظیم نشده، از Host header استفاده می‌کنیم
                // 'localhost' حذف شد — در production هرگز نباید localhost باشد
                $host = $request->header('host') ?? '';
                if (empty($host)) {
                    // آخرین fallback — از SERVER_NAME استفاده می‌کنیم نه hardcoded
                    $host = $_SERVER['SERVER_NAME'] ?? $_SERVER['HTTP_HOST'] ?? '';
                }
                $appUrl = 'https://' . $host;
            }

            $uri = $request->uri();
            // MEDIUM-M-10 Fix: Robust URI sanitization using parse_url to prevent header injection or redirection bypasses
            $cleanPath = parse_url($uri, PHP_URL_PATH) ?: '/';
            $query = parse_url($uri, PHP_URL_QUERY);
            
            $redirectUrl = $appUrl . '/' . ltrim($cleanPath, '/') . ($query ? '?' . $query : '');

            // Redirect before the rest of the response pipeline to avoid downstream
            // production-only header/rendering failures from turning HTTPS enforcement
            // into a 500 response.
            if (!headers_sent()) {
                header('Location: ' . $redirectUrl, true, 301);
            }
            exit;
        }

        return $this->toResponse($next($request));
    }

    private function toResponse(mixed $result): Response
    {
        if ($result instanceof Response) {
            return $result;
        }

        if ($result instanceof \Throwable) {
            $response = new Response();
            $response->status(500);
            $response->setContent('Internal Server Error');
            return $response;
        }

        $response = new Response();
        $response->setContent((string)$result);
        return $response;
    }
}
