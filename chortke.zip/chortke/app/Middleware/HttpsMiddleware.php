<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Closure;

/**
 * HttpsMiddleware — اجبار به استفاده از پروتکل امن HTTPS
 */
class HttpsMiddleware
{
    public function __construct(private \Core\UrlGenerator $urlGenerator)
    {
    }

    public function handle(Request $request, Closure $next): mixed
    {
        $env = config('app.env', 'production');

        if ($env === 'production' && !$request->isSecure()) {
            // Canonical host comes only from immutable UrlGenerator configuration.
            $uri = $request->uri();
            // MEDIUM-M-10 Fix: Robust URI sanitization using parse_url to prevent header injection or redirection bypasses
            $cleanPath = parse_url($uri, PHP_URL_PATH) ?: '/';
            $query = parse_url($uri, PHP_URL_QUERY);

            $redirectUrl = $this->urlGenerator->to(
                '/' . ltrim((string)$cleanPath, '/') . ($query ? '?' . $query : '')
            );
            $redirectUrl = preg_replace('#^http://#i', 'https://', $redirectUrl) ?? $redirectUrl;

            // FIX-M1M16 + FIX-M2M17 (گزارش‌های ماژول ۱ و ۲): دیگر exit()/header() خام نیست —
            // پاسخ استاندارد 301 Return می‌شود تا pipeline استثنا/هدرها/تست‌ها دور زده نشوند
            // و lifecycle فریم‌ورک (GlobalException/emit یکپارچه) سالم بماند.
            $response = new Response();
            $response->status(301);
            $response->setHeader('Location', $redirectUrl);
            $response->setContent('');
            return $response;
        }

        return $this->toResponse($next($request));
    }

    private function toResponse(mixed $result): Response
    {
        if ($result instanceof Response) {
            return $result;
        }

        if ($result instanceof \Throwable) {
            $response = new Response();
            $response->status(500);
            $response->setContent('Internal Server Error');
            return $response;
        }

        $response = new Response();
        $response->setContent(str_value($result));
        return $response;
    }
}
