<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Core\Session;
use Closure;
use App\Constants\SessionKeys;

/**
 * GuestMiddleware — محدودسازی دسترسی فقط برای کاربران مهمان (وارد نشده)
 */
class GuestMiddleware extends BaseMiddleware
{
    private Session $session;

    public function __construct(Session $session) {
        $this->session = $session;
    }

    public function handle(Request $request, Closure $next): mixed
    {
        // FIX-R18N (Task 18-N — P1 REVIEW_ROUND18 #17): شاخهٔ pending-2FA باید قبل از
        // ریدایرکت کاربرِ لاگین‌شده بررسی شود. موتور ضد-تقلب PENDING_2FA_USER_ID را روی
        // سشنِ «لاگین‌شده» ست می‌کند (چالش 2FA مرحله‌بعد)؛ ترتیب قبلی کاربرِ لاگین‌شده
        // را قبل از رسیدن به شاخهٔ pending-2FA به /dashboard می‌فرستاد (کد مرده) و
        // AuthMiddleware کاربر را به /verify-2fa برمی‌گرداند ⇒ حلقهٔ بی‌نهایت 302.
        // MEDIUM-09 Fix: Redirect users with pending 2FA to verification page (avoid loop)
        if ($this->session->has(SessionKeys::PENDING_2FA_USER_ID) && $request->uri() !== '/verify-2fa') {
            $response = new Response();
            $response->redirect(url('verify-2fa'));
            return $response;
        }

        // CRITICAL-C3 Fix: Consistent check using SessionKeys and LOGGED_IN flag
        // HIGH-07 Fix: Double check both flag and user_id to prevent session partial state bypass
        if ($this->session->get(SessionKeys::LOGGED_IN) && int_value($this->session->get(SessionKeys::USER_ID)) > 0) {
            // FIX-R2-03: نیت linking حساب OAuth — کاربرِ لاگین‌شده‌ای که از
            // linkAccount به provider رفته، به callback برمی‌گردد؛ GuestMiddleware
            // قبلاً او را به dashboard می‌فرستاد و linking هرگز کامل نمی‌شد.
            // نیت در SessionKeys::OAUTH_LINKING_USER_ID با TTL (FIX-C96) ثبت
            // می‌شود؛ فقط برای همان user_id و روی مسیر callback معتبر است.
            $linkingIntent = $this->session->get(SessionKeys::OAUTH_LINKING_USER_ID);
            $uri = $request->uri();
            $isOAuthCallback = str_starts_with($uri, '/auth/callback/google')
                || str_starts_with($uri, '/auth/callback/facebook');
            $linkingUserId = is_array($linkingIntent) ? (int)($linkingIntent['user_id'] ?? 0) : 0;
            $linkingExpires = is_array($linkingIntent) ? (int)($linkingIntent['expires_at'] ?? 0) : 0;
            if ($isOAuthCallback
                && $linkingUserId > 0
                && $linkingUserId === int_value($this->session->get(SessionKeys::USER_ID))
                && $linkingExpires > time()) {
                return $this->toResponse($next($request));
            }

            $response = new Response();
            $response->redirect(url('dashboard'));
            return $response;
        }

        return $this->toResponse($next($request));
    }
}
