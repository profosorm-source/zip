<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Core\Session;
use Closure;
use App\Constants\SessionKeys;

/**
 * AdminGuestMiddleware — گارد «فقط مهمان» برای صفحات ورود ادمین
 *
 * FIX-R36-W3 (F-A3-08): پیش از این، GET/POST /admin/login و /admin/verify-2fa
 * هیچ گارد سطح-روت نداشتند و AdminAuthController::showLogin() فقط نقش‌های
 * admin|super_admin|support را ریدایرکت می‌کرد ⇒ کاربرِ کاملاً لاگین‌شدهٔ
 * «غیر-ادمین» می‌توانست فرم ورود ادمین را ببیند (اطلاعاتی/آرایشی؛ پنل خودش
 * با AdminMiddleware + RBAC محافظت می‌شود).
 *
 * قرارداد عمدی (برخلاف GuestMiddleware عادی):
 *  - شاخهٔ pending-2FA اینجا وجود ندارد — سشنِ pending-2FA هرگز LOGGED_IN /
 *    USER_ID ندارد (AuthSessionManager::createPending2FASession) و از این
 *    گارد عبور می‌کند تا جریان 2FA ادمین (/admin/verify-2fa) نشکند.
 *  - نقش‌های ناحیهٔ ادمین (admin|super_admin|support) → /admin/dashboard
 *    (همان مقصد L-04 در showLogin؛ فقط یک hop کمتر).
 *  - سایر کاربرانِ لاگین‌شده → داشبورد کاربری (آینهٔ GuestMiddleware).
 */
class AdminGuestMiddleware extends BaseMiddleware
{
    private Session $session;

    public function __construct(Session $session) {
        $this->session = $session;
    }

    public function handle(Request $request, Closure $next): mixed
    {
        // CRITICAL-C3/HIGH-07 semantics (هم‌سو با GuestMiddleware): هم فلگ و هم
        // user_id چک می‌شود تا سشن ناقص/ساختگی عبور نکند.
        if ($this->session->get(SessionKeys::LOGGED_IN) && int_value($this->session->get(SessionKeys::USER_ID)) > 0) {
            $role = str_value($this->session->get(SessionKeys::USER_ROLE) ?? '');
            $response = new Response();
            if (in_array($role, ['admin', 'super_admin', 'support'], true)) {
                $response->redirect('/admin/dashboard');
            } else {
                $response->redirect(url('dashboard'));
            }
            return $response;
        }

        return $this->toResponse($next($request));
    }
}
