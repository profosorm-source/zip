<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Contracts\LoggerInterface;
use Core\CSRF;
use Core\Request;
use Core\Response;
use Closure;

/**
 * CSRFMiddleware — محافظت در برابر حملات CSRF
 * 
 * SECURITY NOTES:
 * - CSRF validation is enforced for all state-changing requests
 * - Webhooks require signature verification (not just IP allowlisting)
 * - API routes are exempt (use token-based auth instead)
 */
class CSRFMiddleware extends BaseMiddleware
{
    private LoggerInterface $logger;
    private CSRF $csrf;
    private ?\Core\Session $session = null;

    // Webhook endpoints that require signature verification
    private const WEBHOOK_SIGNED_PATHS = [
        '/webhooks/stripe',
        '/webhooks/paypal',
        '/webhooks/payment',
        '/webhooks/notification',
    ];

    // FIX-X341 (راند ۸۴): وب‌هوک‌هایی که لایهٔ امضای دامنه‌محورِ خودشان را داخل
    // کنترلر دارند (HMAC per-network، fail-closed). چکِ عمومیِ این میدل‌ور با
    // secret پرداخت (config webhooks.secret) است که هیچ شبکهٔ تبلیغاتی‌ای
    // ندارد — بدون این معافیت، اندپوینت S2S ویدیو-پاداشی عملاً غیرقابل‌استفاده
    // بود (هر درخواست معتبر با ۴۰۱ «Webhook signature verification failed» رد
    // می‌شد — اثبات پراب qa/round84-webhook-s2s.php). دفاع جایگزین در خود
    // کنترلر: X332 (timestamp fail-closed) + HMAC-SHA256 زمان‌ایمن per-network +
    // مبلغ سمت‌سرور + idempotency scope-دار (الگوی معافیت /payment/callback/ — X179b).
    private const WEBHOOK_SELF_SIGNED_PATHS = [
        '/webhooks/video-reward/',
    ];

    public function __construct(LoggerInterface $logger, CSRF $csrf, ?\Core\Session $session = null) {
        $this->logger = $logger;
        $this->csrf = $csrf;
        // 🧹 DI-CLEANUP (2026-08-24): به‌جای Service Locator در بدنه‌ی handle().
        $this->session = $session;
    }

    public function handle(Request $request, Closure $next): mixed
    {
        $uri = $request->uri();
        
        // API routes are exempt (they use token-based authentication)
        if (str_starts_with($uri, '/api/')) {
            return $this->toResponse($next($request));
        }

        // X179b (ریشه‌یابی باتری راند ۴۶): callback درگاه‌های پرداخت هرگز CSRF توکن
        // ندارند — کاربر از سایتِ درگاه (زرین‌پال/نکست‌پی/...) برمی‌گردد. بدون این
        // معافیت، «هیچ» پرداختی هرگز تکمیل نمی‌شد (لاگ security.csrf_failed روی
        // /payment/callback/*). دفاع لایه‌به‌لایه در خودِ PaymentCommandService است:
        // nonce یک‌بارمصرف (hash_equals، H-06) + verifyCallback امضای درگاه +
        // validateAuthorityFormat + تطبیق مبلغ + نرخ‌سنج + IP-whitelist اختیاری.
        // الگوی همان فلسفهٔ webhook: «امضای دامنه‌محور به‌جای توکن سشن».
        if (str_starts_with($uri, '/payment/callback/')) {
            return $this->toResponse($next($request));
        }
        
        // HIGH-06 Fix: Webhook routes require signature verification (not just IP allowlisting)
        // This prevents CSRF attacks on webhooks even from allowed IPs
        if (str_starts_with($uri, '/webhooks/')) {
            // FIX-M4-09: allowlist «webhook.allowed_ips» (env WEBHOOK_ALLOWED_IPS در
            // config/webhook.php) قبلاً هیچ مصرف‌کننده‌ای نداشت — تنظیم اپراتور بی‌اثر
            // بود. اکنون فهرستِ غیرخالی = صرفاً همان IPها مجازند. منبع معتبر
            // REMOTE_ADDR است (الگوی L-08: X-Forwarded-For قابل جعل است و برای یک
            // امتیاز حساس مبنا قرار نمی‌گیرد)؛ فهرست خالی = همه مجاز (رفتار قبلی).
            if (!self::webhookIpAllowed((string)($_SERVER['REMOTE_ADDR'] ?? ''))) {
                $this->logger->warning('security.webhook_ip_not_allowed', [
                    'ip' => get_client_ip(),
                    'uri' => $uri,
                ]);
                $response = new Response();
                return $response->setStatusCode(403)->json([
                    'success' => false,
                    'message' => 'Webhook source is not allowed.'
                ]);
            }
            // Check if this webhook requires signature verification
            $requiresSignature = $this->webhookRequiresSignature($uri);
            
            if ($requiresSignature) {
                if (!$this->verifyWebhookSignature($request, $uri)) {
                    $this->logger->warning('security.webhook_signature_failed', [
                        'ip' => get_client_ip(),
                        'uri' => $uri,
                        'user_agent' => $request->userAgent()
                    ]);
                    
                    $response = new Response();
                    $response->setStatusCode(401)->json([
                        'success' => false,
                        'message' => 'Webhook signature verification failed.'
                    ]);
                    // FIX-R19-A7-3: explicit abort — do not rely on json()/send() throwing
                    // (SafeModeMiddleware pattern); a Response transport that does not throw
                    // must still end the pipeline here.
                    return $response;
                }
            }
            
            return $this->toResponse($next($request));
        }

        // فقط برای متدهای تغییر دهنده وضعیت
        $method = $request->method();
        if (in_array(strtoupper((string)$method), ['POST', 'PUT', 'PATCH', 'DELETE'])) {
            try {
                $rawPostToken = $request->post('_csrf_token');
                if (is_array($rawPostToken)) {
                    $rawPostToken = reset($rawPostToken);
                }
                $tokenVal = $rawPostToken ?? $request->header('X-CSRF-Token');
                $csrfValid = $this->csrf->verify(str_value($tokenVal));
            } catch (\Core\Exceptions\HttpResponseException $e) {
                throw $e;
            } catch (\Throwable $e) {
                $this->logger->error('csrf.check.exception', ['error' => $e->getMessage()]);
                $response = new Response();
                return $response->setStatusCode(419)->setContent('Session Expired');
            }

            if (!$csrfValid) {
                $this->logger->warning('security.csrf_failed', [
                    'ip' => get_client_ip(),
                    'uri' => $request->uri(),
                    'method' => $request->method()
                ]);

                $response = new Response();
                if ($request->isAjax()) {
                    $response->json(['success' => false, 'message' => 'توکن امنیتی نامعتبر است.'], 419);
                }

                ($this->session ?? throw new \RuntimeException('Session در دسترس نیست؛ تنظیم فلش CSRF متوقف شد.'))->setFlash('error', 'توکن امنیتی نامعتبر است. لطفاً صفحه را دوباره بارگذاری کنید.');
                $response->redirect(url($request->uri()));
                // FIX-R19-A7-3: explicit abort — same rationale as the webhook branch above.
                return $response;
            }
        }

        $result = $next($request);
        
        if ($result instanceof Response) {
            return $result;
        }

        $response = new Response();
        $response->setContent((string)$result);
        return $response;
    }
    
    /**
     * HIGH-06 Fix: Check if webhook requires signature verification
     * 
     * Some webhooks might be internal-only and not need signature verification,
     * but payment/notification webhooks should always require signatures.
     */
    private function webhookRequiresSignature(string $uri): bool
    {
        // FIX-X341 (راند ۸۴): وب‌هوک‌های خود-امضا — امضایشان داخل کنترلر و دامنه‌محور است
        foreach (self::WEBHOOK_SELF_SIGNED_PATHS as $path) {
            if (str_starts_with($uri, $path)) {
                return false;
            }
        }

        foreach (self::WEBHOOK_SIGNED_PATHS as $path) {
            if (str_starts_with($uri, $path)) {
                return true;
            }
        }
        
        // By default, all webhooks require signature verification
        // unless explicitly configured otherwise
        return true;
    }
    
    /**
     * HIGH-06 Fix: Verify webhook signature to prevent unauthorized access
     * 
     * Webhook signature verification ensures that:
     * 1. The request came from the expected source (e.g., Stripe, PayPal)
     * 2. The payload was not tampered with in transit
     * 3. The request is not a replay (using timestamp and idempotency)
     * 
     * @param Request $request
     * @param string $uri Webhook URI for key selection
     * @return bool True if signature is valid, false otherwise
     */
    private function verifyWebhookSignature(Request $request, string $uri): bool
    {
        // Get signature header (different providers use different header names)
        $signature = $request->header('X-Signature') 
            ?? $request->header('X-Webhook-Signature')
            ?? $request->header('Stripe-Signature')
            ?? $request->header('Paypal-Signature')
            ?? $request->header('Authorization');
        
        if (empty($signature)) {
            $this->logger->warning('webhook.missing_signature', ['uri' => $uri]);
            return false;
        }
        
        // Get webhook secret for this endpoint
        $secret = $this->getWebhookSecret($uri);
        if (empty($secret)) {
            $this->logger->error('webhook.secret_not_configured', ['uri' => $uri]);
            return false; // Fail closed - don't allow webhooks without configured secrets
        }
        
        // Get timestamp header (for replay attack prevention)
        $timestamp = $request->header('X-Webhook-Timestamp') ?? '0';
        
        // Verify timestamp is within acceptable window (5 minutes)
        // This prevents replay attacks where old valid webhooks are replayed
        if (is_numeric($timestamp)) {
            $age = abs(time() - (int)$timestamp);
            if ($age > 300) { // 5 minutes
                $this->logger->warning('webhook.timestamp_too_old', [
                    'uri' => $uri,
                    'timestamp' => $timestamp,
                    'age_seconds' => $age
                ]);
                return false;
            }
        }
        
        // Get raw body for signature verification
        $rawBody = $request->getRawBody();
        
        // Compute expected signature
        // For Stripe-style: timestamp.payload signed with HMAC-SHA256
        // For generic: HMAC-SHA256 of timestamp + body
        $payload = $timestamp . '.' . $rawBody;
        $expectedSignature = hash_hmac('sha256', $payload, $secret);
        
        // Support multiple signature schemes for compatibility
        if (!is_string($signature)) return false;
        $valid = hash_equals($expectedSignature, $signature);
        
        // Also check raw body signature (some providers don't include timestamp)
        // Note: Replay attack protection is handled by the timestamp check above.
        // If a provider doesn't use timestamps, they must be handled separately.
        
        return $valid;
    }
    
    /**
     * FIX-M4-09: مصرف‌کنندهٔ allowlist وب‌هوک — config/webhook.php مقدارش را از
     * env WEBHOOK_ALLOWED_IPS می‌سازد (از قبل trim/filter شده). خالی = بدون محدودیت
     * (رفتار پیشین)؛ غیرخالی = تطبیق دقیق با REMOTE_ADDR.
     */
    public static function webhookIpAllowed(string $remoteAddr): bool
    {
        $allowed = function_exists('config') ? config('webhook.allowed_ips', []) : [];
        if (!is_array($allowed) || $allowed === []) {
            return true;
        }
        if ($remoteAddr === '') {
            return false;
        }
        foreach ($allowed as $ip) {
            if (is_string($ip) && $ip !== '' && hash_equals($ip, $remoteAddr)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get webhook secret based on URI
     * Secrets should be configured per-webhook in config or environment
     */
    private function getWebhookSecret(string $uri): string
    {
        // Check for webhook-specific secret in config
        $configKey = 'webhooks.secrets.' . $this->getWebhookProvider($uri);
        $secret = config($configKey);

        if (!empty($secret)) {
            return str_value($secret);
        }

        // Fall back to general webhook secret
        $generic = str_value(config('webhooks.secret', ''));
        if ($generic !== '') {
            return $generic;
        }

        // FIX-M4-09: قرارداد سوم (کانونی، env-bound) — WEBHOOK_SECRET در
        // config/webhook.php ('secret' مفرد) از قبل برای ReconciliationService/
        // MockPaymentGateway مصرف می‌شد ولی middleware امضای عمومی آن را نمی‌دید و
        // endpointهای عمومیِ بدون config_set، حتی با secret سالم در .env هم fail-closed
        // می‌شدند. اکنون آخرین حلقهٔ زنجیره همان secret کانونی است (همچنان fail-closed
        // وقتی هیچ‌کدام تنظیم نشده باشند).
        return str_value(config('webhook.secret', ''));
    }
    
    /**
     * Extract webhook provider name from URI
     */
    private function getWebhookProvider(string $uri): string
    {
        // Extract provider from URI like /webhooks/stripe/payment
        $parts = explode('/', trim($uri, '/'));
        if (count($parts) >= 2 && $parts[0] === 'webhooks') {
            return $parts[1];
        }
        return 'generic';
    }
}