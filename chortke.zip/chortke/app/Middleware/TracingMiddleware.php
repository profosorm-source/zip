<?php

namespace App\Middleware;

use Core\Container;
use App\Services\LogService;
use App\Middleware\BaseMiddleware;
use Core\Request;
use Core\Response;
use Closure;

/**
 * Middleware for Distributed Tracing (Option 3).
 * 
 * Sets correlation_id VERY EARLY in the pipeline so that:
 * - Listeners (Escrow, Referral, Notification, Audit, Outbox)
 * - Outbox events
 * - Saga executions
 * - LogService
 * can all carry the same trace id across the distributed flow.
 * 
 * This is the ONLY new middleware added in the refactor.
 * It extends BaseMiddleware for consistency with the rest of the project.
 */
class TracingMiddleware extends BaseMiddleware
{
    #[ \Core\Attributes\Inject ]
    private \App\Services\LogService $logService;

    public function handle(Request $request, Closure $next): mixed
    {
        // Try to get from incoming header (for distributed calls / gateways)
        // اصلاح کلیدی معماری ردیابی توزیع‌شده (Distributed Tracing Header Case Guard):
        // تغییر حروف هدرهای درخواستی به کوچک (x-correlation-id) جهت تطابق کامل با استانداردهای نرمال‌سازی Request و حفظ پشته ردیابی موبایل
        $correlationId = $request->headers['x-correlation-id'] 
            ?? $request->headers['x-request-id'] 
            ?? $request->header('X-Correlation-ID') 
            ?? bin2hex(random_bytes(16));

        // Set in server superglobal for easy access everywhere (listeners, jobs, outbox)
        $request->setAttribute('request_id', $correlationId);
        $request->setAttribute('x_correlation_id', $correlationId);

        // Inject into LogService if available
        try {
            if (method_exists($this->logService, 'setCorrelationId')) {
                $this->logService->setCorrelationId($correlationId);
            }
        } catch (\Throwable $e) {
            // Logger not critical for tracing
        }

        // 🚀 Sentry Performance: شروع transaction برای کل HTTP request
        // این تنها جایی است که startTransaction صدا زده می‌شود — یک بار به ازای هر request
        $transactionName = $request->method() . ' ' . $request->uri();
        \App\Services\Sentry\SentryExceptionHandler::startTransaction(
            $transactionName,
            'http.request',
            [
                'correlation_id' => $correlationId,
                'method'         => $request->method(),
                'uri'            => $request->uri(),
            ]
        );

        // Continue the request pipeline
        $response = $next($request);

        // Use BaseMiddleware helper to normalize response
        $response = $this->toResponse($response);

        // Add correlation header to response (for clients and downstream services)
        $response->header('X-Correlation-ID', $correlationId);

        return $response;
    }
}
