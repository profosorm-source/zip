<?php

namespace App\Middleware;

use Core\Container;
use App\Services\LogService;
use App\Middleware\BaseMiddleware;
use Core\Request;
use Core\Response;
use Closure;

/**
 * Middleware for Distributed Tracing (Option 3).
 * 
 * Sets correlation_id VERY EARLY in the pipeline so that:
 * - Listeners (Escrow, Referral, Notification, Audit, Outbox)
 * - Outbox events
 * - Saga executions
 * - LogService
 * can all carry the same trace id across the distributed flow.
 * 
 * This is the ONLY new middleware added in the refactor.
 * It extends BaseMiddleware for consistency with the rest of the project.
 */
class TracingMiddleware extends BaseMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $container = Container::getInstance();
        
        // Try to get from incoming header (for distributed calls / gateways)
        $correlationId = $request->headers['X-Correlation-ID'] 
            ?? $request->headers['X-Request-ID'] 
            ?? bin2hex(random_bytes(16));

        // Set in server superglobal for easy access everywhere (listeners, jobs, outbox)
        $_SERVER['REQUEST_ID'] = $correlationId;
        $_SERVER['X_CORRELATION_ID'] = $correlationId;

        // Inject into LogService if available
        try {
            $logService = $container->make(\App\Services\LogService::class);
            if (method_exists($logService, 'setCorrelationId')) {
                $logService->setCorrelationId($correlationId);
            }
        } catch (\Throwable $e) {
            // Logger not critical for tracing
        }

        // Continue the request pipeline
        $response = $next($request);

        // Use BaseMiddleware helper to normalize response
        $response = $this->toResponse($response);

        // Add correlation header to response (for clients and downstream services)
        $response->header('X-Correlation-ID', $correlationId);

        return $response;
    }
}
