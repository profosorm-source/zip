<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Closure;

/**
 * ApiRequestMiddleware — اعتبارسنجی درخواست‌های API
 *
 * مسئولیت‌ها:
 * ۱. API Version detection و validation
 * ۲. Content-Type enforcement (POST/PUT/PATCH باید application/json باشه)
 * ۳. Accept header enforcement (همیشه JSON response)
 * ۴. تضمین JSON error response (هیچوقت HTML برنگرده)
 */
class ApiRequestMiddleware extends BaseMiddleware
{
    // Evaluates Authorization headers for token checks
    private string $defaultVersion;
    /** @var list<string> */
    private array $supportedVersions;

    public function __construct() {
        $dv = config('api.default_version', 'v1');
        $this->defaultVersion = is_string($dv) ? $dv : 'v1';
        $sv = config('api.supported_versions', ['v1', 'v2']);
        $this->supportedVersions = is_array($sv) ? $sv : ['v1', 'v2'];
    }

    public function handle(Request $request, Closure $next): Response
    {
        // ─── 1. API Version ─────────────────────────────────────
        // FIX-M11-07 (گزارش دوم): نسخهٔ header و path کانونی می‌شوند — تعارض
        // (مثلاً /api/v1/... با X-API-Version: v2) → 400 VERSION_CONFLICT؛
        // قبلاً header بر path مقدم بود و attribute از route جدا می‌افتاد.
        [$version, $headerVersion, $pathVersion] = $this->resolveVersions($request);

        if (!in_array($version, $this->supportedVersions, true)) {
            return $this->jsonError(400, 'UNSUPPORTED_API_VERSION',
                "The API version '{$version}' is no longer supported.",
                ['supported_versions' => $this->supportedVersions]
            );
        }

        if ($headerVersion !== null && $pathVersion !== null && $headerVersion !== $pathVersion) {
            return $this->jsonError(400, 'VERSION_CONFLICT',
                'Version header conflicts with the URL path version.',
                ['header_version' => $headerVersion, 'path_version' => $pathVersion]
            );
        }

        $request->setAttribute('api_version', $version);

        // ─── 2. Content-Type (فقط POST/PUT/PATCH) ───────────────
        $method = strtoupper($request->method());
        if (in_array($method, ['POST', 'PUT', 'PATCH'], true)) {
            $contentTypeValue = $request->header('Content-Type');
            $contentType = is_string($contentTypeValue) ? $contentTypeValue : '';

            // FIX-M11-02 (گزارش دوم): media typeهای رسمی گزارش CSP هم پذیرفته
            // می‌شوند (allowlist در isValidContentType) — قبلاً 415 پیش از action.
            if (!$this->isValidContentType($contentType)) {
                return $this->jsonError(415, 'UNSUPPORTED_MEDIA_TYPE',
                    'Content-Type must be application/json, multipart/form-data, or a registered report media type.',
                    ['received' => $contentType]
                );
            }
        }

        // ─── 3. Accept header ───────────────────────────────────
        // FIX-M11-03 (گزارش دوم): مسیر metrics خروجی text/plain (Prometheus) رسمی
        // دارد — قبلاً گیت JSON-only پیش از action با 406 مانعش می‌شد و شاخهٔ
        // Prometheus unreachable بود. سایر مسیرها JSON-only می‌مانند.
        $accept = str_value($request->header('Accept') ?? '*/*');
        $isMetricsRoute = str_starts_with($request->uri(), '/api/v1/metrics/');
        if (!$this->isAcceptable($accept, $isMetricsRoute)) {
            return $this->jsonError(406, 'NOT_ACCEPTABLE',
                'This API only supports application/json responses' . ($isMetricsRoute ? ' (or text/plain for metrics).' : '.'),
                ['received_accept' => $accept]
            );
        }

        // ─── 4. Execute request ─────────────────────────────────
        $response = $next($request);
        $response = $this->toResponse($response);

        // FIX-M11-R22-25: هدرهای hop-by-hop (Connection/Keep-Alive) حذف شدند —
        // در HTTP/2 ممنوع‌اند (RFC 9113 §8.2.2) و برخی کلاینت‌ها پاسخ را malformed
        // می‌گیرند. تنظیم keep-alive مسئولیت لایهٔ وب‌سرور (nginx) است.

        return $response;
    }

    /**
     * FIX-M11-07: تفکیک نسخهٔ header و path برای کانونی‌سازی.
     * @return array{0:string,1:?string,2:?string} [resolved, headerVersion, pathVersion]
     */
    private function resolveVersions(Request $request): array
    {
        $headerVersion = $request->header('Accept-Version');
        if (!is_string($headerVersion) || $headerVersion === '') {
            $headerVersion = $request->header('X-API-Version');
        }
        $headerVersion = (is_string($headerVersion) && $headerVersion !== '') ? $headerVersion : null;

        $pathVersion = null;
        $uri = $request->uri();
        if (preg_match('#^/api/(v\d+)/#', $uri, $m)) {
            $pathVersion = $m[1];
        }

        $version = $headerVersion ?? $pathVersion ?? (string) $this->defaultVersion;
        return [$version, $headerVersion, $pathVersion];
    }

    /**
     * FIX-M11-05 (گزارش دوم): پارس واقعی media type — قبلاً str_contains بود و
     * «text/plain; application/json» هم گیت را رد نمی‌کرد (content-type confusion
     * بین proxy/WAF و parser). اکنون base type دقیق (پس از جداسازی پارامترهای «;»)
     * استخراج و با allowlist مقایسه می‌شود؛ پارامترهای مجاز (charset/boundary) سالم.
     */
    public static function mediaTypeBase(?string $headerValue): ?string
    {
        if ($headerValue === null) {
            return null;
        }
        $first = trim(explode(';', (string)$headerValue, 2)[0]);
        $first = strtolower($first);
        return $first === '' ? null : $first;
    }

    private function isValidContentType(string $contentType): bool
    {
        // خالی = form-urlencoded default → مجاز
        $base = self::mediaTypeBase($contentType);
        if ($base === null) return true;

        return in_array($base, [
            'application/json',
            'multipart/form-data',
            'application/x-www-form-urlencoded',
            // FIX-M11-02: media typeهای رسمی گزارش‌دهی مرورگر (CSP / Reporting API)
            'application/csp-report',
            'application/reports+json',
        ], true);
    }

    /**
     * FIX-M11-05: پارس واقعی Accept (لیست media rangeها) — substring نیست.
     * مجاز: wildcard کامل، application wildcard، application/json
     * (و برای مسیر metrics: text/plain و text wildcard).
     */
    private function isAcceptable(string $accept, bool $isMetricsRoute): bool
    {
        $accept = trim($accept);
        if ($accept === '') {
            return true;
        }

        $ranges = array_map('trim', explode(',', $accept));
        foreach ($ranges as $range) {
            $base = self::mediaTypeBase($range);
            if ($base === null) {
                continue;
            }
            if ($base === '*/*' || $base === 'application/json' || $base === 'application/*') {
                return true;
            }
            if ($isMetricsRoute && ($base === 'text/plain' || $base === 'text/*')) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param array<string, mixed> $extra
     */
    private function jsonError(int $httpCode, string $errorCode, string $message, array $extra = []): Response
    {
        $response = new Response();
        $response->setStatusCode($httpCode);
        $response->header('Content-Type', 'application/json; charset=utf-8');
        // FIX-M11-R22-16: قرارداد واحد خطا — همان ErrorContract مشترک همهٔ لایه‌ها
        $response->setContent(json_encode(array_merge([
            'success' => false,
            'message' => $message,
            'error' => [
                'code' => $errorCode,
                'message' => $message,
            ],
            'error_code' => $errorCode,
        ], $extra), JSON_UNESCAPED_UNICODE));

        return $response;
    }
}
