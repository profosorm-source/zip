<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Core\Redis;
use Core\Database;
use Closure;

/**
 * ConcurrentRequestMiddleware — جلوگیری از ثبت همزمان و مضاعف درخواست‌ها
 */
class ConcurrentRequestMiddleware extends BaseMiddleware
{
    private Redis $redis;
    private ?Database $db;

    public function __construct(Redis $redis, ?Database $db = null) {
        $this->redis = $redis;
        // 🛡️ FIX #4 (P1): برای استخراج هویتِ درخواست‌های Bearer به آن نیاز داریم؛
        // اختیاری است تا سازنده‌های موجود (تست‌ها) نشکنند.
        $this->db = $db;
    }

    public function handle(Request $request, Closure $next): mixed
    {
        $identity = $this->resolveIdentity($request);
        $isMutating = in_array(strtoupper($request->method()), ['POST', 'PUT', 'DELETE', 'PATCH'], true);

        // قفل گذاری فقط برای متدهایی که تغییر دهنده هستند (POST, PUT, DELETE, PATCH)
        //
        // 🛡️ FIX #4 (P1): قبلاً هویت فقط از session('user_id') می‌آمد؛ درخواست‌های
        // API (Bearer) سشن ندارند و ApiAuthMiddleware هم بعد از این لایه اجرا می‌شود،
        // بنابراین برای آن‌ها نه قفل NX زده می‌شد و نه شاخهٔ fail-closedِ نبودِ Redis
        // reachable بود — دو درخواست موازیِ API می‌توانستند هر دو از گاردِ pending
        // رد شوند و دو hold بسازند. اکنون هویت از خودِ توکن هم قابل استخراج است.
        if ($identity !== null && $isMutating) {
            $isFinancial = $this->isFinancialRoute($request->uri());
            if ($this->redis->isAvailable()) {
                $uriHash = md5($request->uri());
                $lockKey = "lock:user:{$identity}:{$uriHash}";

                // FIX-R19-A7-2: the lock value is a random per-request owner token and the
                // TTL is 15s (was: static '1' + 3s, so a request slower than 3s let a second
                // request take the lock and the first finally-del then killed the new owner's
                // lock — a double-submit window). Fail semantics below are unchanged.
                $ownerToken = bin2hex(random_bytes(16));
                $acquiredLock = false;

                // تلاش برای ایجاد قفل غیرهمزمان با انقضای ۱۵ ثانیه
                // در کتابخانه Redis افزونه php، متد set با پارامترهای ['nx', 'ex' => 15] کار می‌کند
                try {
                    $client = $this->redis->getClient();
                    if ($client === null) throw new \RuntimeException('Redis client unavailable.');
                    $acquiredLock = $client->set($lockKey, $ownerToken, ['NX', 'EX' => 15]) === true;
                    if (!$acquiredLock) {
                        $response = new Response();
                        if ($request->isAjax()) {
                            $response->json([
                                'success' => false,
                                'message' => 'درخواست قبلی شما در حال پردازش است. لطفا چند لحظه صبر کنید.'
                            ], 429);
                        }
                        
                        $response->setContent('درخواست همزمان مجاز نیست. لطفا صبر کنید.');
                        $response->status(429);
                        return $response;
                    }
                } catch (\Throwable $e) {
                    // L-07 Fix: روی مسیرهای مالی/حساس به‌جای fail-open باید fail-closed شویم
                    // تا در صورت خطای Redis امکان ثبت مضاعف (double-submit) مالی وجود نداشته باشد.
                    if ($isFinancial) {
                        return $this->serviceUnavailable($request);
                    }
                    // مسیرهای غیرمالی: برای حفظ دسترس‌پذیری، fail-open می‌مانند.
                }
            } elseif ($isFinancial) {
                // L-07 Fix: Redis در دسترس نیست و مسیر مالی است → fail-closed
                return $this->serviceUnavailable($request);
            }
        }

        try {
            $response = $next($request);
        } finally {
            // در پایان درخواست، قفل آزاد می‌شود
            // FIX-R19-A7-2: release only if WE acquired it, and only if we still own it
            // (atomic compare-and-del) — never delete another request's lock.
            if (isset($lockKey) && isset($ownerToken) && ($acquiredLock ?? false) && $this->redis->isAvailable()) {
                $this->releaseOwnedLock($lockKey, $ownerToken);
            }
        }

        return $this->toResponse($response);
    }

    /**
     * FIX-R19-A7-2: owner-aware lock release. Primary path = Redis Lua
     * compare-and-del (atomic); if EVAL is unavailable, falls back to
     * GET + compare + DEL which can only mis-delete in a microscopic race
     * and only ever deletes a lock carrying OUR owner token.
     */
    private function releaseOwnedLock(string $lockKey, string $ownerToken): void
    {
        try {
            $client = $this->redis->getClient();
            if ($client === null) {
                return;
            }
            $script = <<<'LUA'
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('DEL', KEYS[1])
end
return 0
LUA;
            try {
                $client->eval($script, [$lockKey, $ownerToken], 1);
                return;
            } catch (\Throwable $luaEx) {
                // EVAL unavailable/restricted → non-atomic fallback with the same intent.
            }
            $current = $client->get($lockKey);
            if ($current === $ownerToken) {
                $client->del($lockKey);
            }
        } catch (\Throwable $e) {
            // نادیده گرفتن خطا
        }
    }

    /**
     * هویتِ درخواست برای قفل‌گذاری: شناسهٔ کاربر از سشن (مسیر وب) یا از توکنِ
     * Bearer (مسیر API). خروجی null یعنی «هویت قابل تعیین نیست» — چنین درخواستی
     * اگر واقعاً محافظت‌شده باشد، بعداً در ApiAuthMiddleware با 401 رد می‌شود.
     */
    private function resolveIdentity(Request $request): ?string
    {
        $userIdValue = session()->get('user_id');
        $userId = is_numeric($userIdValue) ? int_value($userIdValue) : 0;
        if ($userId > 0) {
            return (string)$userId;
        }

        $rawToken = $this->extractBearerToken($request);
        if ($rawToken === null) {
            return null;
        }
        return $this->identityForToken($rawToken);
    }

    /** توکن خام Bearer با فرمت ۶۴ کاراکتر hex (همان قالب ApiAuthMiddleware). */
    private function extractBearerToken(Request $request): ?string
    {
        $authHeader = $request->header('Authorization') ?? $request->header('authorization');
        if (!is_string($authHeader) || !preg_match('/Bearer\s+([a-f0-9]{64})/i', $authHeader, $m)) {
            return null;
        }
        return strtolower(trim($m[1]));
    }

    /**
     * نگاشت توکن → هویت پایدار برای قفل.
     *
     * تناظر با ApiAuthMiddleware::validateTokenWithRotation: توکن با هر secret
     * فعال HMAC می‌شود و hash آن در api_tokens جستجو می‌شود. این جستجو فقط برای
     * «نام‌گذاری قفل» است؛ احراز هویت واقعی همچنان در ApiAuthMiddleware انجام
     * می‌شود، پس خطای این‌جا هرگز امنیت را تغییر نمی‌دهد — بدترین حالت، fallback
     * به قفلِ مبتنی بر hash خودِ توکن است که retryهای همان کلاینت را serialize می‌کند.
     */
    private function identityForToken(string $rawToken): string
    {
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        if (empty($secrets) && \defined('SECURITY_API_TOKEN_SECRET')) {
            $secrets = ['v2' => SECURITY_API_TOKEN_SECRET];
        }

        if ($this->db !== null) {
            foreach ((array)$secrets as $version => $secret) {
                if (empty($secret) || strlen((string)$secret) < 32) {
                    continue;
                }
                try {
                    $row = $this->db->fetch(
                        'SELECT user_id FROM api_tokens WHERE token = ? AND revoked = 0 LIMIT 1',
                        [hash_hmac('sha256', $rawToken, (string)$secret)]
                    );
                    if ($row !== null && isset($row->user_id)) {
                        return (string)(int)$row->user_id;
                    }
                } catch (\Throwable $e) {
                    // fail-soft: به قفل مبتنی بر hash توکن برمی‌گردیم (زیر)
                }
            }
        }

        return 'tok:' . substr(hash('sha256', 'concurrent-identity' . $rawToken), 0, 16);
    }

    /**
     * L-07: تشخیص مسیرهای مالی/حساس که در آن‌ها باید fail-closed باشیم.
     */
    private function isFinancialRoute(string $uri): bool
    {
        $path = strtok($uri, '?');
        $path = strtolower(trim((string)($path === false ? $uri : $path)));
        // C06-باگ۴: مسیرهای ساخت/مدیریت کمپین تبلیغاتی هم مالی‌اند (hold + قفل بودجه)
        // و باید fail-closed باشند تا دابل‌سابمیت در نبود Redis نکند.
        $prefixes = ['/wallet', '/payment', '/withdrawal', '/deposit', '/transfer', '/vitrine', '/ads', '/api/v1/wallet', '/api/v1/payment', '/api/v1/ads'];
        foreach ($prefixes as $p) {
            if (str_starts_with($path, $p)) {
                return true;
            }
        }
        return false;
    }

    /**
     * L-07: پاسخ fail-closed (503) برای مسیرهای مالی وقتی Redis در دسترس نیست.
     */
    private function serviceUnavailable(Request $request): Response
    {
        $response = new Response();
        if ($request->isAjax()) {
            $response->json([
                'success' => false,
                'message' => 'سرویس موقتاً در دسترس نیست. لطفاً چند لحظه بعد دوباره تلاش کنید.'
            ], 503);
        }
        $response->setContent('سرویس موقتاً در دسترس نیست. لطفاً چند لحظه بعد دوباره تلاش کنید.');
        $response->status(503);
        return $response;
    }
}
