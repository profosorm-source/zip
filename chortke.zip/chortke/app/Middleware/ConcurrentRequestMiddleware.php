<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Core\Redis;
use Core\Database;
use Closure;

/**
 * ConcurrentRequestMiddleware — جلوگیری از ثبت همزمان و مضاعف درخواست‌ها
 */
class ConcurrentRequestMiddleware extends BaseMiddleware
{
    /** FIX-M2M18: TTL قفل هم‌زمانی — عادی ۱۵s، مالی ۶۰s (بالای سقف timeout کنترل‌شده) */
    private const LOCK_TTL = 15;
    private const FINANCIAL_LOCK_TTL = 60;

    private Redis $redis;
    private ?Database $db;

    public function __construct(Redis $redis, ?Database $db = null) {
        $this->redis = $redis;
        // 🛡️ FIX #4 (P1): برای استخراج هویتِ درخواست‌های Bearer به آن نیاز داریم؛
        // اختیاری است تا سازنده‌های موجود (تست‌ها) نشکنند.
        $this->db = $db;
    }

    public function handle(Request $request, Closure $next): mixed
    {
        $identity = $this->resolveIdentity($request);
        $isMutating = in_array(strtoupper($request->method()), ['POST', 'PUT', 'DELETE', 'PATCH'], true);

        // قفل گذاری فقط برای متدهایی که تغییر دهنده هستند (POST, PUT, DELETE, PATCH)
        //
        // 🛡️ FIX #4 (P1): قبلاً هویت فقط از session('user_id') می‌آمد؛ درخواست‌های
        // API (Bearer) سشن ندارند و ApiAuthMiddleware هم بعد از این لایه اجرا می‌شود،
        // بنابراین برای آن‌ها نه قفل NX زده می‌شد و نه شاخهٔ fail-closedِ نبودِ Redis
        // reachable بود — دو درخواست موازیِ API می‌توانستند هر دو از گاردِ pending
        // رد شوند و دو hold بسازند. اکنون هویت از خودِ توکن هم قابل استخراج است.
        if ($identity !== null && $isMutating) {
            $isFinancial = $this->isFinancialRoute($request->uri());
            if ($this->redis->isAvailable()) {
                $uriHash = md5($request->uri());
                $lockKey = "lock:user:{$identity}:{$uriHash}";

                // FIX-R19-A7-2: the lock value is a random per-request owner token and the
                // TTL is 15s (was: static '1' + 3s, so a request slower than 3s let a second
                // request take the lock and the first finally-del then killed the new owner's
                // lock — a double-submit window). Fail semantics below are unchanged.
                // FIX-M2M18 (گزارش ماژول ۲، M18): TTL واقع‌بینانه — عملیات مالی
                // (فراخوانی provider تا ۲۰s + تراکنش DB) می‌توانست از lease ۱۵ثانیه‌ای
                // طولانی‌تر شود و درخواست دوم وارد می‌گشت (پنجرهٔ overlap)؛ مسیر مالی
                // ۶۰ثانیه (بالای سقف timeout کنترل‌شده) و بقیه ۱۵ثانیه می‌مانند.
                $lockTtl = $isFinancial ? self::FINANCIAL_LOCK_TTL : self::LOCK_TTL;
                $ownerToken = bin2hex(random_bytes(16));
                $acquiredLock = false;

                // تلاش برای ایجاد قفل غیرهمزمان با انقضای TTL متناسب مسیر
                // در کتابخانه Redis افزونه php، متد set با پارامترهای ['nx', 'ex' => ttl] کار می‌کند
                try {
                    $client = $this->redis->getClient();
                    if ($client === null) throw new \RuntimeException('Redis client unavailable.');
                    $acquiredLock = $client->set($lockKey, $ownerToken, ['NX', 'EX' => $lockTtl]) === true;
                    if (!$acquiredLock) {
                        // FIX-R21-AJAX (چرخهٔ اصلاحی 2026-10-28): شاخهٔ Ajax قبلاً از
                        // Response::json() استفاده می‌کرد که send() → HttpResponseException
                        // پرتاب می‌کند؛ آن پرتاب توسط catch(\Throwable) همین try (که برای
                        // خطاهای Redis بود) بلعیده می‌شد ⇒ مسیر غیرمالی به‌جای رد شدن،
                        // بی‌قفل به کنترلر می‌رسید (fail-open = خنثی‌شدن حفاظت
                        // دابل‌سابمیت برای کلاینت‌های Ajax) و مسیر مالی به‌جای ۴۲۹، ۵۰۳ می‌گرفت.
                        // الگوی Response-builder بدون پرتاب — هم‌سبک RateLimitMiddleware.
                        return $this->concurrentConflictResponse($request, $lockTtl);
                    }

                    // FIX-R21-LOCK (چرخهٔ اصلاحی 2026-10-28): exit پالیسی (مثلاً
                    // RateLimitPolicy::tooManyResponse) داخل $next فینالیِ پایین را
                    // نمی‌سوزاند — PHP در exit بلوک‌های finally زنجیرهٔ فراخوان را اجرا
                    // نمی‌کند ⇒ قفل تا پایان TTL (15s/60s) نشتی می‌کرد و درخواستِ
                    // بعدیِ بی‌درنگِ همان کاربر 429 «درخواست هم‌زمان» می‌گرفت.
                    // shutdown handler در هر ختم پروسه (exit/fatal) اجرا می‌شود و
                    // قفلِ متعلق به ما را آزاد می‌کند؛ در جریان عادی، فینالیِ پایین
                    // زودتر آزاد می‌کند و این handler با compare-and-del صاحب‌آگاه
                    // no-op می‌شود (هرگز قفل درخواست دیگر را نمی‌بُزد).
                    register_shutdown_function(function () use ($lockKey, $ownerToken): void {
                        $this->releaseOwnedLock($lockKey, $ownerToken);
                    });
                } catch (\Throwable $e) {
                    // L-07 Fix: روی مسیرهای مالی/حساس به‌جای fail-open باید fail-closed شویم
                    // تا در صورت خطای Redis امکان ثبت مضاعف (double-submit) مالی وجود نداشته باشد.
                    if ($isFinancial) {
                        return $this->serviceUnavailable($request);
                    }
                    // مسیرهای غیرمالی: برای حفظ دسترس‌پذیری، fail-open می‌مانند.
                }
            } elseif ($isFinancial) {
                // L-07 Fix: Redis در دسترس نیست و مسیر مالی است → fail-closed
                return $this->serviceUnavailable($request);
            }
        }

        try {
            $response = $next($request);
        } finally {
            // در پایان درخواست، قفل آزاد می‌شود
            // FIX-R19-A7-2: release only if WE acquired it, and only if we still own it
            // (atomic compare-and-del) — never delete another request's lock.
            if (isset($lockKey) && isset($ownerToken) && ($acquiredLock ?? false) && $this->redis->isAvailable()) {
                $this->releaseOwnedLock($lockKey, $ownerToken);
            }
        }

        return $this->toResponse($response);
    }

    /**
     * FIX-R21-AJAX: پاسخ ۴۲۹ «درخواست هم‌زمان» بدون شلیک HttpResponseException
     * (توضیح ریشه در محل فراخوانی). مذاکرهٔ محتوا هم‌قاعدهٔ
     * RateLimitPolicy::tooManyResponse: Ajax یا Accept-JSON → بدنهٔ JSON؛
     * وگرنه متن ساده. Retry-After به‌اندازهٔ TTL قفلِ همین نوع مسیر است.
     */
    private function concurrentConflictResponse(Request $request, int $lockTtl): Response
    {
        $wantsJson = $request->isAjax()
            || str_contains(strtolower((string)$request->header('accept') ?? ''), 'application/json');

        $response = new Response();
        $response->setStatusCode(429);
        $response->setHeader('Retry-After', (string)$lockTtl);
        if ($wantsJson) {
            $response->setHeader('Content-Type', 'application/json; charset=utf-8');
            $response->setContent(json_encode([
                'success' => false,
                'message' => 'درخواست قبلی شما در حال پردازش است. لطفاً چند لحظه صبر کنید.',
                'retry_after' => $lockTtl,
            ], JSON_UNESCAPED_UNICODE));
        } else {
            $response->setHeader('Content-Type', 'text/html; charset=utf-8');
            $response->setContent('درخواست همزمان مجاز نیست. لطفا صبر کنید.');
        }
        return $response;
    }

    /**
     * FIX-R19-A7-2: owner-aware lock release. Primary path = Redis Lua
     * compare-and-del (atomic); if EVAL is unavailable, falls back to
     * GET + compare + DEL which can only mis-delete in a microscopic race
     * and only ever deletes a lock carrying OUR owner token.
     */
    private function releaseOwnedLock(string $lockKey, string $ownerToken): void
    {
        try {
            $client = $this->redis->getClient();
            if ($client === null) {
                return;
            }
            $script = <<<'LUA'
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('DEL', KEYS[1])
end
return 0
LUA;
            try {
                $client->eval($script, [$lockKey, $ownerToken], 1);
                return;
            } catch (\Throwable $luaEx) {
                // EVAL unavailable/restricted → non-atomic fallback with the same intent.
            }
            $current = $client->get($lockKey);
            if ($current === $ownerToken) {
                $client->del($lockKey);
            }
        } catch (\Throwable $e) {
            // نادیده گرفتن خطا
        }
    }

    /**
     * هویتِ درخواست برای قفل‌گذاری: شناسهٔ کاربر از سشن (مسیر وب) یا از توکنِ
     * Bearer (مسیر API). خروجی null یعنی «هویت قابل تعیین نیست» — چنین درخواستی
     * اگر واقعاً محافظت‌شده باشد، بعداً در ApiAuthMiddleware با 401 رد می‌شود.
     */
    private function resolveIdentity(Request $request): ?string
    {
        $userIdValue = session()->get('user_id');
        $userId = is_numeric($userIdValue) ? int_value($userIdValue) : 0;
        if ($userId > 0) {
            return (string)$userId;
        }

        $rawToken = $this->extractBearerToken($request);
        if ($rawToken === null) {
            return null;
        }
        return $this->identityForToken($rawToken);
    }

    /** توکن خام Bearer با فرمت ۶۴ کاراکتر hex (همان قالب ApiAuthMiddleware). */
    private function extractBearerToken(Request $request): ?string
    {
        $authHeader = $request->header('Authorization') ?? $request->header('authorization');
        if (!is_string($authHeader) || !preg_match('/Bearer\s+([a-f0-9]{64})/i', $authHeader, $m)) {
            return null;
        }
        return strtolower(trim($m[1]));
    }

    /**
     * نگاشت توکن → هویت پایدار برای قفل.
     *
     * تناظر با ApiAuthMiddleware::validateTokenWithRotation: توکن با هر secret
     * فعال HMAC می‌شود و hash آن در api_tokens جستجو می‌شود. این جستجو فقط برای
     * «نام‌گذاری قفل» است؛ احراز هویت واقعی همچنان در ApiAuthMiddleware انجام
     * می‌شود، پس خطای این‌جا هرگز امنیت را تغییر نمی‌دهد — بدترین حالت، fallback
     * به قفلِ مبتنی بر hash خودِ توکن است که retryهای همان کلاینت را serialize می‌کند.
     */
    private function identityForToken(string $rawToken): string
    {
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        if (empty($secrets) && \defined('SECURITY_API_TOKEN_SECRET')) {
            $secrets = ['v2' => SECURITY_API_TOKEN_SECRET];
        }

        if ($this->db !== null) {
            foreach ((array)$secrets as $version => $secret) {
                if (empty($secret) || strlen((string)$secret) < 32) {
                    continue;
                }
                try {
                    $row = $this->db->fetch(
                        'SELECT user_id FROM api_tokens WHERE token = ? AND revoked = 0 LIMIT 1',
                        [hash_hmac('sha256', $rawToken, (string)$secret)]
                    );
                    if ($row !== null && isset($row->user_id)) {
                        return (string)(int)$row->user_id;
                    }
                } catch (\Throwable $e) {
                    // fail-soft: به قفل مبتنی بر hash توکن برمی‌گردیم (زیر)
                }
            }
        }

        return 'tok:' . substr(hash('sha256', 'concurrent-identity' . $rawToken), 0, 16);
    }

    /**
     * L-07: تشخیص مسیرهای مالی/حساس که در آن‌ها باید fail-closed باشیم.
     */
    private function isFinancialRoute(string $uri): bool
    {
        $path = strtok($uri, '?');
        $path = strtolower(trim((string)($path === false ? $uri : $path)));
        // C06-باگ۴: مسیرهای ساخت/مدیریت کمپین تبلیغاتی هم مالی‌اند (hold + قفل بودجه)
        // و باید fail-closed باشند تا دابل‌سابمیت در نبود Redis رخ نکند.
        // FIX-MODULE2-M2: طبق گزارش، فهرست قبلی جاهای خالی داشت:
        //   • aliasهای کاربری /manual-deposits و /crypto-deposits (routes/wallet.php)
        //   • گروه‌های مالی ادمین (routes/admin.php): تأیید/رد کارت بانکی، واریز
        //     دستی/کریپتو، پردازش/رد برداشت، معکوس‌سازی تراکنش، تأیید پرداخت درگاه.
        //     بدون این‌ها، Redis outage در این مسیرها به‌جای 503 به کنترلر مالی
        //     می‌رسید (ریسک دابل‌پردازش).
        $prefixes = [
            '/wallet', '/payment', '/withdrawal', '/deposit', '/transfer', '/vitrine', '/ads',
            '/manual-deposits', '/crypto-deposits',
            '/admin/bank-cards', '/admin/manual-deposits', '/admin/crypto-deposits',
            '/admin/withdrawals', '/admin/transactions', '/admin/gateway-payments',
            '/api/v1/wallet', '/api/v1/payment', '/api/v1/ads',
        ];
        foreach ($prefixes as $p) {
            if (str_starts_with($path, $p)) {
                return true;
            }
        }
        return false;
    }

    /**
     * L-07: پاسخ fail-closed (503) برای مسیرهای مالی وقتی Redis در دسترس نیست.
     * FIX-R21-AJAX: هم‌الگوی concurrentConflictResponse — Response-builder بدون
     * پرتاب (قبلاً شاخهٔ Ajax از json() پرتاب می‌کرد و رندر به global-exception
     * handler واگذار می‌شد) + مذاکرهٔ محتوای هم‌قاعده (Ajax یا Accept-JSON → JSON).
     */
    private function serviceUnavailable(Request $request): Response
    {
        $wantsJson = $request->isAjax()
            || str_contains(strtolower((string)$request->header('accept') ?? ''), 'application/json');

        $response = new Response();
        $response->setStatusCode(503);
        if ($wantsJson) {
            $response->setHeader('Content-Type', 'application/json; charset=utf-8');
            $response->setContent(json_encode([
                'success' => false,
                'message' => 'سرویس موقتاً در دسترس نیست. لطفاً چند لحظه بعد دوباره تلاش کنید.',
            ], JSON_UNESCAPED_UNICODE));
        } else {
            $response->setHeader('Content-Type', 'text/html; charset=utf-8');
            $response->setContent('سرویس موقتاً در دسترس نیست. لطفاً چند لحظه بعد دوباره تلاش کنید.');
        }
        return $response;
    }
}
