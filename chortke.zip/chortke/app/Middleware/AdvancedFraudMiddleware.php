<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Contracts\LoggerInterface;
use App\Contracts\NotificationServiceInterface;
use App\Services\AntiFraud\AccountTakeoverService;
use App\Services\AntiFraud\BrowserFingerprintService;
use App\Services\AntiFraud\GeoIPService;
use App\Services\Auth\SessionService;
use App\Services\AntiFraud\RiskDecisionService;
use App\Services\ScoreService;
use Core\Request;
use Core\Response;
use Core\Session;
use Closure;

/**
 * AdvancedFraudMiddleware — سیستم پیشرفته شناسایی تقلب و ریسک
 */
class AdvancedFraudMiddleware extends BaseMiddleware
{
    private BrowserFingerprintService $fingerprintService;
    private GeoIPService $ipQualityService;
    private SessionService $sessionService;
    private AccountTakeoverService $accountTakeoverService;
    private ScoreService $scoreService;
    private RiskDecisionService $decisionService;
    private LoggerInterface $logger;
    private Session $session;
    private NotificationServiceInterface $notifications;

    public function __construct(
        BrowserFingerprintService $fingerprintService,
        GeoIPService $ipQualityService,
        SessionService $sessionService,
        AccountTakeoverService $accountTakeoverService,
        ScoreService $scoreService,
        RiskDecisionService $decisionService,
        LoggerInterface $logger,
        Session $session,
        NotificationServiceInterface $notifications
    ) {
        $this->fingerprintService = $fingerprintService;
        $this->ipQualityService = $ipQualityService;
        $this->sessionService = $sessionService;
        $this->accountTakeoverService = $accountTakeoverService;
        $this->scoreService = $scoreService;
        $this->decisionService = $decisionService;
        $this->logger = $logger;
        $this->session = $session;
        $this->notifications = $notifications;
    }

    public function handle(Request $request, Closure $next): mixed
    {
        $session = $this->session;
        if (!$session->has('user_id')) {
            return $this->toResponse($next($request));
        }

        // Graceful degradation: اگه سرویس‌های fraud (DB tables, Redis) در دسترس نباشن، request بلاک نشه
        //
        // BUGFIX-FRAUD-SWALLOW-2026-08:
        //   قبلاً فراخوانی کنترلر ($next) داخل همین try بود. در نتیجه هر استثنای
        //   مشروعِ دامنه که کنترلر پرتاب می‌کرد — مثلاً BusinessException با پیام
        //   «سودی برای برداشت وجود ندارد» در POST /investment/withdraw — به‌عنوان
        //   «خرابی موتور ضدتقلب» تفسیر می‌شد، در catch عمومی بلعیده می‌شد و چون
        //   مسیرهای پولی sensitive هستند، منطق fail-closed پاسخ ۵۰۳ می‌داد.
        //   کاربر به‌جای پیام ۴۲۲ی قابل‌فهم، خطای «سرویس در دسترس نیست» می‌دید و
        //   خطای واقعی هم زیر عنوان fraud.middleware.check_failed گم می‌شد.
        //   حالا فقط خودِ بررسی‌ها داخل try هستند و کنترلر بیرون از آن اجرا می‌شود.
        try {
            $this->performFraudChecks($request, $session);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            // Redirect exceptions باید propagate بشن (block/challenge actions)
            throw $e;
        } catch (\Throwable $e) {
            $this->logger->error('fraud.middleware.check_failed', [
                'error' => $e->getMessage(),
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'uri' => $request->uri(),
                'user_id' => $session->get('user_id'),
            ]);

            // M-24 FIX: previously the middleware failed OPEN for ALL requests when the fraud engine
            // threw — a crafted input that reliably crashed a check would bypass IP blacklisting, the
            // account-takeover 2FA challenge and the risk decision entirely. Graceful degradation is
            // still acceptable for ordinary browsing, but security-sensitive routes (money movement,
            // account/security settings, admin) must fail CLOSED so an outage cannot be weaponised to
            // strip protection. This mirrors the fail-closed default already enforced by
            // FraudGuardService::handleSystemFailure() at the action layer.
            if ($this->isSensitivePath($request->uri())) {
                $this->logger->warning('fraud.middleware.fail_closed', [
                    'uri' => $request->uri(),
                    'user_id' => $session->get('user_id'),
                ]);
                $response = new Response();
                if ($request->isPost() || str_contains($request->uri(), '/api/')) {
                    $response->error(
                        'سرویس ارزیابی امنیتی موقتاً در دسترس نیست. لطفاً دقایقی دیگر دوباره تلاش کنید.',
                        [],
                        503
                    );
                } else {
                    $response->redirect(url('/login?error=security_unavailable'));
                }
                exit;
            }

            // مسیر غیرحساس: تخریب آرام (fail-open) و ادامه‌ی پردازش درخواست.
        }

        // کنترلر بیرون از try/catch موتور ضدتقلب اجرا می‌شود تا استثناهای
        // مشروع دامنه (BusinessException/ValidationException/...) دست‌نخورده
        // به ExceptionHandler برسند و کد وضعیت درست خودشان را بگیرند.
        return $this->toResponse($next($request));
    }

    /**
     * آیا مسیر درخواست حساس است و در صورت خرابی موتور ضدتقلب باید fail-closed شود؟
     */
    private function isSensitivePath(string $uri): bool
    {
        $path = strtolower(parse_url($uri, PHP_URL_PATH) ?: $uri);
        $sensitivePrefixes = [
            '/wallet', '/withdraw', '/deposit', '/payment', '/transfer', '/invest',
            '/vitrine', '/dispute', '/bank', '/card', '/kyc', '/admin',
            '/settings/security', '/security', '/2fa', '/api/user/wallet',
            '/api/wallet', '/api/payment', '/api/withdraw',
        ];
        foreach ($sensitivePrefixes as $prefix) {
            if (str_starts_with($path, $prefix) || str_contains($path, $prefix)) {
                return true;
            }
        }
        return false;
    }

    private function performFraudChecks(Request $request, Session $session): void
    {
        $userId = int_value($session->get('user_id'));
        $ip = get_client_ip();
        $userAgent = get_user_agent();
        $sessionId = $session->getId();
        $acceptLanguage = str_value($request->header('accept-language') ?? '');
        $acceptEncoding = str_value($request->header('accept-encoding') ?? '');

        $geoData = $this->ipQualityService->getGeolocation($ip);
        $this->sessionService->updateActivity($sessionId);

        if (!$session->get('fraud_check_done')) {
            // ✅ Pass all HTTP data explicitly
            $this->sessionService->recordSession(
                userId: $userId,
                sessionId: $sessionId,
                userAgent: $userAgent,
                ipAddress: $ip,
                acceptLanguage: $acceptLanguage,
                acceptEncoding: $acceptEncoding,
                geoData: $geoData
            );
            $session->set('fraud_check_done', true);
        }

        if ($this->ipQualityService->isIPBlacklisted($ip)) {
            $this->logger->warning('fraud.blocked_ip', ['ip' => $ip, 'user_id' => $userId]);
            $session->destroy();
            (new Response())->redirect(url('/login?error=blocked'));
        }

        $ipCheck = $this->ipQualityService->check($ip);
        if ($ipCheck['is_suspicious']) {
            $this->ipQualityService->logIPCheck($userId, $ip, $ipCheck);
            // BUG FIX: کیفیت IP یک سیگنال ایستا است (رِنج خصوصی، اشتراکی بودن، Tor…) و با
            // هر درخواست تغییر نمی‌کند؛ اما این دلتا روی هر درخواست اعمال می‌شد و امتیاز
            // تقلبِ یک کاربر کاملاً سالم را به‌صورت انباشتی بالا می‌برد تا از آستانه‌ی
            // challenge/block عبور کند و کاربر بی‌دلیل به 2FA یا خروج اجباری بیفتد.
            // applyDelta از پیش کلید idempotency را پشتیبانی می‌کند؛ سیگنال را به ازای
            // هر (کاربر، IP، مجموعه‌ی دلایل) فقط یک‌بار اعمال می‌کنیم.
            $ipSignalKey = 'ip_quality:' . $userId . ':' . $ip . ':' . md5(json_encode($ipCheck['reasons']) ?: '');
            $this->scoreService->applyDelta('user', $userId, \App\Enums\ScoreDomain::Fraud->value, float_value($ipCheck['score']) / 4, 'ip_quality', [
                'ip' => $ip,
                'reasons' => $ipCheck['reasons'],
            ], $ipSignalKey);

            $ipDetails = is_array($ipCheck['details'] ?? null) ? $ipCheck['details'] : [];
            if (!empty($ipDetails['is_tor'])) {
                $this->ipQualityService->blacklistIP($ip, 'Tor Network', 86400 * 7);
                $session->destroy();
                (new Response())->redirect(url('/login?error=tor_blocked'));
            }
        }

        // BUGFIX-FRAUD-LOGANOMALY-2026-06:
        //   The previous code called $sessionService->logAnomaly(...) which
        //   does not exist on SessionService — analyzeAnomaly() already
        //   performs the logging and fraud_logs persistence internally via
        //   its private logAnalysisResult() helper. The undefined-method
        //   call threw on every authenticated request and was silently
        //   swallowed by the outer try/catch in performFraudChecks(),
        //   logging "fraud.middleware.check_failed" for each hit and
        //   skipping the score delta below.
        $sessionCheck = $this->sessionService->analyzeAnomaly($userId, $sessionId);
        if ($sessionCheck['is_anomaly']) {
            // FIX-X69: کلید idempotency — همان نشست با همان ترکیب آنومالی فقط یک‌بار
            // باید امتیاز بگیرد (الگوی FIX-X63؛ نشست‌های مختلف کلید مستقل دارند).
            $anomalySignalKey = 'session_anomaly:' . $userId . ':' . $sessionId . ':' . float_value($sessionCheck['score']) . ':' . md5(json_encode($sessionCheck['anomalies']) ?: '');
            $this->scoreService->applyDelta('user', $userId, \App\Enums\ScoreDomain::Fraud->value, float_value($sessionCheck['score']) / 2, 'session_anomaly', [
                'anomalies' => $sessionCheck['anomalies'],
                'session_id' => $sessionId,
            ], $anomalySignalKey);
        }

        $currentFingerprint = $this->fingerprintService->generate([
            'user_agent' => $userAgent,
            'language' => $acceptLanguage,
            'encoding' => $acceptEncoding
        ]);

        $takeoverCheck = $this->accountTakeoverService->detect($userId, $ip, $userAgent, $currentFingerprint);
        if ($takeoverCheck['is_takeover']) {
            $this->accountTakeoverService->logDetection($userId, $ip, $userAgent, $takeoverCheck);
            // FIX-X69: کلید idempotency برای سیگنال account_takeover (الگوی FIX-X63)
            // — جلوگیری از انباشت تکراری روی هر درخواست با همان ترکیب سیگنال.
            $takeoverSignalKey = 'account_takeover:' . $userId . ':' . md5(json_encode($takeoverCheck['signals'] ?? []) ?: '') . ':' . float_value($takeoverCheck['risk_score'] ?? 0);
            $this->scoreService->applyDelta('user', $userId, \App\Enums\ScoreDomain::Fraud->value, (float) $takeoverCheck['risk_score'] / 2, 'account_takeover', [
                'signals' => $takeoverCheck['signals'],
            ], $takeoverSignalKey);

            if ($takeoverCheck['action'] === 'notify') {
                // FIX-T1: type 'warning' خارج از ثابت‌های مدل Notification بود → TYPE_SECURITY
                // با اولویت high تا در ترتیب اولویت-محور لیست اعلان‌ها دفن نشود.
                $this->notifications->send($userId, \App\Models\Notification::TYPE_SECURITY, 'هشدار امنیتی', str_value(config('messages.security.suspicious')), [], null, null, \App\Models\Notification::PRIORITY_HIGH);
            }
        }

        $decision = $this->decisionService->decide($userId, ['action' => 'general']);
        
        $decisionResult = str_value($decision['result'] ?? $decision['decision'] ?? 'allow');

        switch ($decisionResult) {
            case 'block':
                // FIX-T1: type 'danger' خارج از ثابت‌های مدل بود → TYPE_SECURITY؛
                // بلاک = نابودی سشن، پس اولویت urgent تا کاربر فوراً ببیند.
                $this->notifications->send($userId, \App\Models\Notification::TYPE_SECURITY, 'هشدار امنیتی', str_value(config('messages.security.high_risk')), [], null, null, \App\Models\Notification::PRIORITY_URGENT);
                $session->destroy();
                (new Response())->redirect(url('/login?error=high_risk'));

            case 'challenge':
                if (!$session->get('2fa_verified')) {
                    // FIX-X25: ریدایرکت کورکورانه به /verify-2fa بن‌بست UX بود —
                    // showVerify() وقتی PENDING_2FA_USER_ID ست نشده باشد کاربر را بی‌صدا
                    // به /login برمی‌گرداند؛ برای کاربر بدون 2FA هم صفحهٔ «کد ۶ رقمی از
                    // Google Authenticator» گمراه‌کننده بود.
                    // اکنون: کاربر 2FA-دار → سشن pending واقعی (step-up درست) + /verify-2fa؛
                    // کاربر بدون 2FA → خاتمهٔ سشن و بازگشت به /login با پیام واضح
                    // (ورود مجدد = ارزیابی مجدد ریسک — طراحی عمدی step-up حفظ می‌شود).
                    $has2FA = false;
                    try {
                        $challengeUser = db()->table('users')->where('id', $userId)->first();
                        $has2FA = $challengeUser && !empty($challengeUser->two_factor_enabled);
                    } catch (\Throwable $e) {
                        $this->logger->warning('fraud.challenge.2fa_lookup_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
                    }
                    if ($has2FA) {
                        $session->set(\App\Constants\SessionKeys::PENDING_2FA_USER_ID, $userId);
                        $session->set('pending_2fa_created_at', time());
                        $session->setFlash('warning', config('messages.security.challenge_2fa'));
                        (new Response())->redirect(url('/verify-2fa'));
                    } else {
                        $session->destroy();
                        (new Response())->redirect(url('/login?error=security_challenge'));
                    }
                }
                break;

            case 'review':
                // وضعیت بررسی دستی (Review) — فلگ بررسی دستی را فعال کرده و لاگ ثبت می‌کنیم
                $session->set('under_manual_review', true);
                $this->logger->info('fraud.manual_review_triggered', [
                    'user_id' => $userId,
                    'ip' => $ip,
                ]);
                break;

            case 'allow':
            default:
                $session->remove('under_manual_review');
                break;
        }
    }
}
