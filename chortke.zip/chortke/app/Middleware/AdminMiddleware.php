<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Core\Session;
use App\Policies\RolePolicy;
use Closure;
use App\Constants\SessionKeys;

/**
 * AdminMiddleware — محدودسازی دسترسی به مدیران سیستم
 *
 * SECURITY-FIX: حذف کامل backdoor تست (پارامتر مخرب + debug log file)
 * که به هر کاربر ناشناس امکان دور زدن احراز هویت را می‌داد.
 *
 * جریان اعتبارسنجی:
 *   1. بررسی 2FA pending
 *   2. بررسی وجود session معتبر (USER_ID + LOGGED_IN)
 *   3. DB re-validation هر ۱۵ ثانیه (از Redis یا session)
 *   4. بررسی نقش از طریق RolePolicy::isAdmin()
 */
class AdminMiddleware extends BaseMiddleware
{
    private \App\Contracts\LoggerInterface $logger;
    private \App\Models\User $userModel;
    private Session $session;
    private ?\Core\Redis $redis = null;

    public function __construct(Session $session, \App\Models\User $userModel, \App\Contracts\LoggerInterface $logger, ?\Core\Redis $redis = null) {
        $this->session   = $session;
        $this->userModel = $userModel;
        $this->logger    = $logger;
        // 🧹 DI-CLEANUP (2026-08-24): به‌جای Service Locator در بدنه‌ی handle().
        $this->redis     = $redis;
    }

    public function handle(Request $request, Closure $next): mixed
    {
        $session = $this->session;

        // ── 1. بررسی 2FA pending ─────────────────────────────────────────────
        // CRITICAL-NEW-02: جلوگیری از session confusion bypass
        if ($session->has(SessionKeys::PENDING_2FA_USER_ID)) {
            if ($session->get('admin_pending_2fa')) {
                $response = new Response();
                $response->redirect(url('/admin/verify-2fa'));
                return $response;
            }
            // Non-admin pending 2FA نباید به پنل ادمین دسترسی داشته باشد
            $session->destroy();
            $response = new Response();
            $response->redirect(url('login'));
            return $response;
        }

        // ── 2. بررسی وجود session معتبر ──────────────────────────────────────
        if (!$session->has(SessionKeys::USER_ID) || !$session->get(SessionKeys::LOGGED_IN)) {
            $response = new Response();
            if ($request->isAjax()) {
                $response->json(['success' => false, 'message' => 'لطفاً ابتدا وارد شوید.'], 401);
            }
            // FIX-X44: مهمانِ مسیرهای ادمین باید به صفحهٔ ورود ادمین برود نه ورود کاربر؛
            // ریدایرکت به /login کاربر عادی باعث 403 زنجیره‌ای (ورود کاربر عادی → 403) می‌شد.
            $session->setFlash('error', 'برای دسترسی به پنل مدیریت ابتدا وارد حساب مدیریتی شوید.');
            $response->redirect(url('/admin/login'));
        }

        $userId = int_value($session->get(SessionKeys::USER_ID));
        $role   = str_value($session->get(SessionKeys::USER_ROLE) ?? '');

        // ── 3. DB re-validation (در هر درخواست) ──────────────────────────────────────────
        // H-01 / L-04 (بازطراحی): در هر درخواست یک‌بار نقش/وضعیت مستقیم از DB خوانده
        // می‌شود تا revoke/بنِ نقش فوری اعمال شود. enforcementِ ریزدانهٔ هر عمل
        // توسط AdminPermissionGuard.
        //
        // 🛡️ FIX-S9-15 (گزارش بخش ۹): کدِ مردهٔ «lastVerify» حذف شد — پس از حذف
        // polling، خواندنِ Redis هر درخواست و نوشتنِ کلیدِ تأییدِ ادمین هیچ
        // مصرف‌کننده‌ای نداشتند (۱ خواندن + ۱ نوشتنِ بیهودهٔ Redis در هر درخواست ادمین).
        try {
                $user = $this->userModel->find($userId);
                $statusOk = $user !== null
                    && empty($user->deleted_at)
                    && (string)($user->status ?? '') === 'active';

                if (!$user || !$statusOk || !RolePolicy::isAdmin((string)($user->role ?? ''))) {
                    $this->logger->warning('admin.middleware.access_denied', [
                        'user_id' => $userId,
                        'reason'  => !$user
                            ? 'user_not_found'
                            : (!$statusOk ? 'account_not_active' : 'insufficient_role'),
                    ]);

                    // ابطال فوری نشست + پاک‌سازی کلیدهای تأیید — هم‌قرارداد با FIX-R19-A7-3/S7-F02
                    try { $session->destroy(); } catch (\Throwable $e) {
                        $this->logger->debug('admin.middleware.session_destroy_failed', ['error' => $e->getMessage()]);
                    }
                    $redis = $this->redis;
                    if ($redis !== null && $redis->isAvailable()) {
                        try { $redis->delete('user_verify:' . $userId); } catch (\Throwable $e) {}
                    }

                    $res403 = new Response();
                    if ($request->isAjax()) {
                        $res403->json(['success' => false, 'message' => 'دسترسی شما منقضی یا محدود شده است.'], 403);
                    }
                    ob_start();
                    try { view('errors/403'); } catch (\Throwable $e) {
            // non-critical middleware cleanup — log only
            @error_log('[AdminMiddleware] cleanup failed: ' . $e->getMessage());
        }
                    $content = ob_get_clean();
                    $res403->setStatusCode(403);
                    $res403->setContent($content ?: '403 Forbidden');
                    return $res403;
                }

                // همگام‌سازی session با DB
                $session->set(SessionKeys::USER_ROLE, $user->role);
                $session->set(SessionKeys::LOGGED_IN, true);

                $role = $user->role;

            } catch (\Core\Exceptions\HttpResponseException $e) {
                // HttpResponseException از json()/redirect() داخل بلاک if بالا آمده —
                // نباید swallow شود؛ مستقیماً re-throw می‌شود تا router آن را مدیریت کند.
                throw $e;
            } catch (\Throwable $e) {
                $this->logger->error('admin.middleware.db_error', ['error' => $e->getMessage()]);
                $session->destroy();
                $response = new Response();
                // 🛡️ FIX-S9-15: مقصدِ ریدایرکت یکسان شد — مهمان/خطای DB هر دو به
                // صفحهٔ ورود ادمین می‌روند (قبلاً این شاخه به login کاربر عادی می‌رفت).
                $response->redirect(url('/admin/login'));
                // FIX-R19-A7-3: explicit fail-closed abort — must not fall through to the
                // role check / $next() when admin status could not be verified.
                return $response;
            }

        // ── 4. بررسی نهایی نقش ───────────────────────────────────────────────
        if (!RolePolicy::isAdmin($role)) {
            $response = new Response();
            if ($request->isAjax()) {
                $response->json(['success' => false, 'message' => 'دسترسی غیرمجاز'], 403);
            }

            ob_start();
            view('errors/403');
            $content = ob_get_clean();

            $response->setStatusCode(403);
            $response->setContent($content ?: '403 Forbidden');
            return $response;
        }

        return $this->toResponse($next($request));
    }
}
