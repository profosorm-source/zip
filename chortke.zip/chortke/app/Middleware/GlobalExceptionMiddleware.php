<?php

declare(strict_types=1);

namespace App\Middleware;

use Core\Request;
use Core\Response;
use Closure;

class GlobalExceptionMiddleware extends BaseMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        try {
            $result = $next($request);
            return $this->toResponse($result);
        } catch (\Throwable $e) {
            // لاگ خطا (بدون throw مجدد)
            try {
                error_log('[GlobalException] ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
            } catch (\Throwable $ignore) {}

            // تشخیص نوع درخواست: API/AJAX → JSON، بقیه → HTML
            $wantsJson = $request->isAjax()
                || str_starts_with($request->uri() ?? '', '/api/')
                || str_contains($request->header('Accept') ?? '', 'application/json');

            if ($wantsJson) {
                // API / AJAX → JSON response
                if (class_exists(\Core\ExceptionHandler::class)) {
                    $payload = \Core\ExceptionHandler::getJsonPayloadForException($e);
                } else {
                    $payload = ['success' => false, 'message' => 'خطای سیستمی رخ داده است.', 'code' => 500];
                }

                $response = new Response();
                $response->setStatusCode($payload['code'] ?? 500);
                $response->header('Content-Type', 'application/json; charset=utf-8');
                $response->setContent(json_encode($payload, JSON_UNESCAPED_UNICODE));
                return $response;
            }

            // HTML → نمایش صفحه خطای کاربرپسند (یا redirect)
            $isDebug = (config('app.debug') === true || config('app.debug') === 'true');

            $response = new Response();
            $response->setStatusCode(500);
            $response->header('Content-Type', 'text/html; charset=utf-8');

            if ($isDebug) {
                // حالت debug — نمایش جزئیات خطا
                $msg = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
                $file = htmlspecialchars($e->getFile(), ENT_QUOTES, 'UTF-8');
                $line = $e->getLine();
                $trace = htmlspecialchars($e->getTraceAsString(), ENT_QUOTES, 'UTF-8');
                $html = <<<HTML
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><meta charset="UTF-8"><title>خطای سیستمی</title>
<style>body{font-family:Tahoma,sans-serif;background:#f5f5f5;padding:40px;direction:rtl}
.box{background:#fff;border-radius:12px;padding:30px;max-width:800px;margin:0 auto;box-shadow:0 2px 20px rgba(0,0,0,.1)}
h1{color:#e53935;font-size:20px}pre{background:#f8f8f8;padding:15px;border-radius:8px;overflow-x:auto;font-size:13px;direction:ltr;text-align:left}
.file{color:#666;font-size:13px}</style></head>
<body><div class="box">
<h1>⚠️ خطای سیستمی</h1>
<p><strong>{$msg}</strong></p>
<p class="file">📁 {$file}:{$line}</p>
<pre>{$trace}</pre>
<p style="margin-top:20px"><a href="javascript:history.back()" style="color:#1976d2">← بازگشت</a></p>
</div></body></html>
HTML;
            } else {
                // حالت production — پیام عمومی
                $html = <<<HTML
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><meta charset="UTF-8"><title>خطای سیستمی</title>
<style>body{font-family:Tahoma,sans-serif;background:#f5f5f5;display:flex;align-items:center;justify-content:center;min-height:100vh;direction:rtl}
.box{background:#fff;border-radius:12px;padding:40px;text-align:center;box-shadow:0 2px 20px rgba(0,0,0,.1)}
h1{color:#e53935;font-size:24px}p{color:#666}</style></head>
<body><div class="box">
<h1>⚠️ خطای سیستمی</h1>
<p>متأسفانه مشکلی پیش آمده. لطفاً دوباره تلاش کنید.</p>
<p style="margin-top:20px"><a href="javascript:history.back()" style="color:#1976d2">← بازگشت</a></p>
</div></body></html>
HTML;
            }

            $response->setContent($html);
            return $response;
        }
    }
}
