<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * SecurityLog Model — Data Access Layer
 * 
 * مسئولیت: CRUD operations روی security_logs table
 * نوشتاری: رویدادهای امنیتی، حملات، ورودها
 */
class SecurityLog extends Model
{
    protected static string $table = 'security_logs';
    private ?\App\Contracts\LoggerInterface $logger = null;

    /**
     * درج رکورد جدید
     */
    /** @param array<string, mixed> $data */
    public function insert(array $data): bool
    {
        try {
            $stmt = $this->db->prepare(
                // FIX-X210: شِمای واقعی جدول (id, user_id, level, message, ip_address, created_at) —
                // INSERT قبلی ستون‌های ناموجود (request_id/type/context/user_agent) داشت و
                // همیشه ساکت شکست می‌خورد. کلیدهای اضافی به انتهای message چسبانده می‌شوند.
                "INSERT INTO security_logs
                (level, message, user_id, ip_address, created_at)
                VALUES (?, ?, ?, ?, NOW())"
            );

            $message = str_value($data['message'] ?? '');
            // FIX-R36-W3 (F-A7-05): ضد جعل لاگ — شناسهٔ خام کاربر (مثلاً ایمیل ورود
            // ناموفق با \n + متن ساختگی CRITICAL) نباید کنترل-کاراکتر [\x00-\x1F\x7F]
            // را به رد امنیتی تزریق کند. بازنویسی بایت-سطح (بدون /u) چون کلاسِ کنترل
            // ASCII است و ترتیب بایت‌های UTF-8 را نمی‌شکند؛ برای هر نویسندهٔ این مدل
            // اعمال می‌شود (نقطهٔ گلویی). با فضای خالی جایگزین می‌شود تا توکن‌ها به
            // هم نچسبند و متن گمراه‌کننده ساخته نشود.
            $message = preg_replace('/[\x00-\x1F\x7F]+/', ' ', $message) ?? $message;
            $context = $data['context'] ?? null;
            if ($context !== null && $context !== '') {
                $message .= ' | context: ' . (is_string($context) ? $context : json_encode($context, JSON_UNESCAPED_UNICODE));
            }

            return $stmt->execute([
                $data['level'] ?? 'WARNING',
                mb_substr($message, 0, 1000),
                $data['user_id'] ?? null,
                $data['ip_address'] ?? null,
            ]);
        } catch (\Throwable $e) {
            $this->logger?->error('model.security_log.insert.failed', [
                'channel' => 'model',
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * دریافت لاگ‌های امنیتی با فیلتر
     */
    /**
     * @param array<string, mixed> $filters
     * @return array{rows: list<array<string, mixed>>, total: int, page: int, perPage: int, totalPages: int}
     */
    public function getPaginated(
        array $filters = [],
        int $page = 1,
        int $perPage = 20
    ): array {
        // C-04: Enforce hard ceiling on pagination depths to prevent unbounded pagination
        $page = max(1, min(10000, $page));
        $perPage = max(1, min(100, $perPage));
        $offset = ($page - 1) * $perPage;

        $where = [];
        $params = [];

        if (!empty($filters['level'])) {
            $where[] = 'level = ?';
            $params[] = $filters['level'];
        }

        if (!empty($filters['user_id'])) {
            $where[] = 'user_id = ?';
            $params[] = $filters['user_id'];
        }

        if (!empty($filters['ip_address'])) {
            $where[] = 'ip_address = ?';
            $params[] = $filters['ip_address'];
        }

        if (array_key_exists('search', $filters)) {
            if (!is_string($filters['search'])) {
                throw new \InvalidArgumentException('Security log search filter must be a string.');
            }
            if ($filters['search'] !== '') {
                // FIX-R36-W3 (F-A7-04): escape وایلدکاردهای LIKE (% _ \) هم‌ترازِ
                // الگوی فیکس HIGH-01 (AuditTrail:315 / ApiTokenService:608) —
                // ورودی ادمین با % یا _ نباید اسکن کامل جدول/واگرای معنا تحمیل کند.
                $like = '%' . addcslashes($filters['search'], '%_\\') . '%';
                // R32 (HIGH ممیزی R30): ستون context در security_logs وجود ندارد
                // (مسیر INSERT از FIX-X210 مقدار context را داخل message ادغام
                // می‌کند) ⇒ جستجوی context LIKE به SQLSTATE 42S22 (500 ادمین)
                // می‌رفت. جستجو فقط روی message — که context ادغام‌شده را هم
                // پوشش می‌دهد — کافی است.
                $where[] = 'message LIKE ?';
                $params[] = $like;
            }
        }

        if (!empty($filters['date_from'])) {
            $where[] = 'created_at >= ?';
            $params[] = $filters['date_from'] . ' 00:00:00';
        }

        if (!empty($filters['date_to'])) {
            $where[] = 'created_at <= ?';
            $params[] = $filters['date_to'] . ' 23:59:59';
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        // Count
        $countStmt = $this->db->prepare("SELECT COUNT(*) FROM security_logs {$whereClause}");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        // Data
        $dataStmt = $this->db->prepare(
            "SELECT * FROM security_logs {$whereClause}
             ORDER BY created_at DESC
             LIMIT ? OFFSET ?"
        );
        $dataStmt->execute([...$params, $perPage, $offset]);

        $rows = $dataStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => (int) ceil($total / $perPage),
        ];
    }

    /**
     * دریافت یک رکورد با ID
     */
    /** @return array<string, mixed>|null */
    public function findById(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM security_logs WHERE id = ?");
        $stmt->execute([$id]);
        return $this->fetchAssoc($stmt) ?: null;
    }

    /**
     * دریافت لاگ‌های اخیر
     */
    /** @return list<array<string, mixed>> */
    public function getRecent(int $limit = 50, ?string $level = null): array
    {
        $limit = max(1, min(500, $limit));

        $where = [];
        $params = [];

        if ($level !== null) {
            $where[] = 'level = ?';
            $params[] = $level;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT * FROM security_logs {$whereClause}
             ORDER BY created_at DESC
             LIMIT ?"
        );

        $stmt->execute([...$params, $limit]);
        return $this->fetchAssocList($stmt);
    }

    /**
     * دریافت لاگ‌های خطرناک (CRITICAL, ALERT, EMERGENCY)
     */
    /** @return list<array<string, mixed>> */
    public function getCriticalLogs(?int $days = null, int $limit = 500): array
    {
        $limit = max(1, min(2000, $limit));

        $where = ['level IN (?, ?, ?)'];
        $params = ['CRITICAL', 'ALERT', 'EMERGENCY'];

        if ($days !== null) {
            $where[] = 'created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)';
            $params[] = $days;
        }

        $whereClause = 'WHERE ' . implode(' AND ', $where);

        // ✅ LIMIT اضافه شد — جلوگیری از full scan روی security_logs بزرگ
        $stmt = $this->db->prepare(
            "SELECT * FROM security_logs {$whereClause}
             ORDER BY created_at DESC
             LIMIT ?"
        );

        $stmt->execute([...$params, $limit]);
        return $this->fetchAssocList($stmt);
    }

    /**
     * شمارش لاگ‌های امنیتی
     */
    public function count(?string $level = null): int
    {
        $where = [];
        $params = [];

        if ($level !== null) {
            $where[] = 'level = ?';
            $params[] = $level;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare("SELECT COUNT(*) FROM security_logs {$whereClause}");
        $stmt->execute($params);

        return (int) $stmt->fetchColumn();
    }

    /**
     * شمارش لاگ‌های خطرناک
     */
    public function countCriticalByUser(int $userId, ?int $days = null): int
    {
        $where = ['user_id = ?', 'level IN (?, ?, ?)'];
        $params = [$userId, 'CRITICAL', 'ALERT', 'EMERGENCY'];

        if ($days !== null) {
            $where[] = 'created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)';
            $params[] = $days;
        }

        $whereClause = 'WHERE ' . implode(' AND ', $where);

        $stmt = $this->db->prepare("SELECT COUNT(*) FROM security_logs {$whereClause}");
        $stmt->execute($params);

        return (int) $stmt->fetchColumn();
    }

    /**
     * حذف لاگ‌های قدیمی تر از تعداد روز
     */
    public function deleteOlderThan(int $days = 90): int
    {
        try {
            $stmt = $this->db->prepare(
                "DELETE FROM security_logs
                 WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)"
            );
            $stmt->execute([$days]);
            return $stmt->rowCount();
        } catch (\Throwable $e) {
            $this->logger?->error('model.security_log.delete_older_than.failed', [
                'channel' => 'model',
                'error' => $e->getMessage(),
            ]);
            return 0;
        }
    }

    /**
     * حذف لاگ‌های قدیمی به‌صورت chunked (برای جداول بزرگ)
     */
    public function deleteOlderThanChunked(int $days = 90, int $chunkSize = 5000): int
    {
        $totalDeleted = 0;
        $maxIterations = 100;

        try {
            for ($i = 0; $i < $maxIterations; $i++) {
                $stmt = $this->db->prepare(
                    "DELETE FROM security_logs
                     WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                     LIMIT ?"
                );
                $stmt->execute([$days, $chunkSize]);
                $batchDeleted = $stmt->rowCount();

                $totalDeleted += $batchDeleted;

                if ($batchDeleted < $chunkSize) {
                    break;
                }
            }
        } catch (\Throwable $e) {
            $this->logger?->error('model.security_log.delete_older_than_chunked.failed', [
                'channel' => 'model',
                'error' => $e->getMessage(),
            ]);
        }

        return $totalDeleted;
    }

    /**
     * دریافت آمارهای سطح
     */
    /** @return list<array<string, mixed>> */
    public function getLevelStats(?string $dateFrom = null, ?string $dateTo = null): array
    {
        $where = [];
        $params = [];

        if ($dateFrom !== null) {
            $where[] = 'created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }

        if ($dateTo !== null) {
            $where[] = 'created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT level, COUNT(*) as count
             FROM security_logs {$whereClause}
             GROUP BY level
             ORDER BY count DESC"
        );

        $stmt->execute($params);
        return $this->fetchAssocList($stmt);
    }

    /**
     * دریافت آمارهای IP (حملات از کدام IP‌ها)
     */
    /** @return list<array<string, mixed>> */
    public function getIpStats(?int $days = null, int $limit = 20): array
    {
        $where = [];
        $params = [];

        if ($days !== null) {
            $where[] = 'created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)';
            $params[] = $days;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT ip_address, COUNT(*) as count
             FROM security_logs {$whereClause}
             GROUP BY ip_address
             ORDER BY count DESC
             LIMIT ?"
        );

        $stmt->execute([...$params, $limit]);
        return $this->fetchAssocList($stmt);
    }
}
