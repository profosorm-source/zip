<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class BulkOperation extends Model
{
    protected static string $table = 'bulk_operations';

    /**
     * FIX-18O (P2): whitelist ستون‌های واقعی bulk_operations
     * (2026_06_10_0017_escrow_bank_bulk.sql: admin_id, type, total_items,
     * processed_items, status, log_file, created_at).
     */
    protected array $fillable = [
        'admin_id', 'type', 'total_items', 'processed_items',
        'status', 'log_file', 'created_at',
    ];

    private const ALLOWED_TABLES = [
        'users', 'transactions', 'submissions', 'content_submissions',
        'custom_tasks', 'bug_reports', 'bulk_operations', 'content_revenues', 'banners'
    ];

    private const ALLOWED_COLUMNS = [
        'id', 'user_id', 'task_id', 'submission_id', 'content_id'
    ];

    private function validateTableName(string $table): void
    {
        if (!\in_array($table, self::ALLOWED_TABLES, true)) {
            throw new \InvalidArgumentException("Invalid table name: " . $table);
        }
    }

    private function validateColumnName(string $column): void
    {
        if (!\in_array($column, self::ALLOWED_COLUMNS, true)) {
            throw new \InvalidArgumentException("Invalid column name: " . $column);
        }
    }
    /**
     * FIX-18O (P2): payload ورودی با $fillable فیلتر می‌شود تا کلیدهای
     * ناموجود (مثل processed/processed_at که فراخوان‌ها می‌فرستادند) باعث
     * SQLSTATE 42S22 نشوند.
     * @param array<string, mixed> $payload
     */
    public function queueOperation(array $payload): int
    {
        return (int)$this->db->table(self::$table)
            ->insert($this->filterFillable($payload));
    }
    /**
     * @return list<object>
     */

    /**
     * FIX-18O (P2): ستون شبح «processed» وجود ندارد — معادل واقعیِ
     * «هنوز پردازش‌نشده» = status='pending'
     * (bulk_operations.status ENUM('pending','processing','completed','failed')).
     */
    public function getPendingOperations(int $limit = 100): array
    {
        return $this->db->table(self::$table)
            ->select('*')
            ->where('status', '=', 'pending')
            ->orderBy('created_at', 'ASC')
            ->limit($limit)
            ->get();
    }

    /**
     * FIX-18O (P2): ستون‌های شبح processed/processed_at → ستون واقعی status.
     */
    public function markProcessed(int $operationId): bool
    {
        return (bool)$this->db->table(self::$table)
            ->where('id', '=', $operationId)
            ->update(['status' => 'completed']);
    }

    private const ALLOWED_UPDATE_COLUMNS = [
        'status', 'kyc_status', 'level_slug', 'priority', 'processed', 'processed_at', 'updated_at', 'admin_note', 'resolved_at'
    ];
    /**
     * @param list<int|string> $ids
     * @param array<string, mixed> $data
     */
    public function applyBatchUpdate(string $table, array $ids, array $data, string $idColumn = 'id'): int
    {
        $this->validateTableName($table);
        $this->validateColumnName($idColumn);

        if (empty($ids) || empty($data)) {
            return 0;
        }

        // Limit maximum IDs in a single batch
        $ids = \array_slice($ids, 0, 1000);

        if (!isset($data['updated_at'])) {
            $data['updated_at'] = date('Y-m-d H:i:s');
        }

        $sets = [];
        $params = [];

        foreach ((array)$data as $column => $value) {
            if (!\in_array($column, self::ALLOWED_UPDATE_COLUMNS, true)) {
                throw new \InvalidArgumentException("Invalid or restricted update column: " . $column);
            }
            $sets[] = "`{$column}` = ?";
            $params[] = $value;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $params = array_merge($params, $ids);

        $sql = "UPDATE `{$table}` SET " . implode(', ', $sets) . " WHERE `{$idColumn}` IN ({$placeholders})";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $stmt->rowCount();
    }
    /**
     * @param list<int|string> $ids
     */

    public function applyBatchDelete(string $table, array $ids, string $idColumn = 'id'): int
    {
        $this->validateTableName($table);
        $this->validateColumnName($idColumn);

        if (empty($ids)) {
            return 0;
        }

        // Limit maximum IDs in a single batch
        $ids = \array_slice($ids, 0, 1000);

        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $sql = "DELETE FROM `{$table}` WHERE `{$idColumn}` IN ({$placeholders})";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($ids);

        return $stmt->rowCount();
    }
}
