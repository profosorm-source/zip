<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * SagaExecution Model
 * 
 * جدول: saga_executions
 */
class SagaExecution extends Model
{
    protected static string $table = 'saga_executions';

    // FIX-M6-07: واژگان کانونیک — orchestrator واقعاً started/completed/
    // compensated/compensation_failed می‌نویسد. «running/failed» فقط برای
    // ردیف‌های legacy نگهداری می‌شوند و در شمارنده‌های زیر ادغام شده‌اند تا
    // مصرف‌کننده‌ها هیچ وضعیت actionable ای را از دست ندهند.
    public const STATUS_STARTED              = 'started';
    public const STATUS_COMPLETED            = 'completed';
    public const STATUS_COMPENSATED          = 'compensated';
    public const STATUS_COMPENSATION_FAILED  = 'compensation_failed';
    // legacy (فقط خواندنی — هیچ مسیری جدیدی نمی‌نویسد)
    public const STATUS_RUNNING              = 'running';
    public const STATUS_FAILED               = 'failed';

    /**
     * Create a new saga execution record.
     */
    /** @param array<string, mixed> $payload */
    public function createSaga(string $id, string $sagaName, array $payload = []): bool
    {
        return (bool) $this->db->execute(
            "INSERT INTO saga_executions (id, saga_name, status, payload, executed_steps, created_at, updated_at)
             VALUES (?, ?, ?, ?, '[]', NOW(), NOW())",
            [$id, $sagaName, self::STATUS_RUNNING, json_encode($payload, JSON_UNESCAPED_UNICODE)]
        );
    }

    /**
     * Update executed steps.
     */
    /** @param array<string, mixed> $steps */
    public function updateSteps(string $id, array $steps): bool
    {
        return (bool) $this->db->execute(
            "UPDATE saga_executions SET executed_steps = ?, updated_at = NOW() WHERE id = ?",
            [json_encode($steps, JSON_UNESCAPED_UNICODE), $id]
        );
    }

    /**
     * Mark saga as completed.
     */
    public function markCompleted(string $id): bool
    {
        return (bool) $this->db->execute(
            "UPDATE saga_executions SET status = ?, updated_at = NOW() WHERE id = ?",
            [self::STATUS_COMPLETED, $id]
        );
    }

    /**
     * Mark saga as failed.
     */
    public function markFailed(string $id): bool
    {
        return (bool) $this->db->execute(
            "UPDATE saga_executions SET status = ?, updated_at = NOW() WHERE id = ?",
            [self::STATUS_FAILED, $id]
        );
    }

    /**
     * Get running sagas count.
     *
     * FIX-M6-07: «در حال اجرا/ناکامل» = started (وضعیت واقعی orchestrator،
     * شامل sagaهای نیمه‌تمام پس از crash) + running (legacy). قبلاً فقط
     * running شمرده می‌شد و sagaهای گیرکردهٔ started نامرئی بودند.
     */
    public function countRunning(): int
    {
        return (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM saga_executions WHERE status IN (?, ?)",
            [self::STATUS_STARTED, self::STATUS_RUNNING]
        );
    }

    /**
     * Get failed sagas count.
     *
     * FIX-M6-07: failed + compensation_failed (شکست جبران هم شکست است و
     * قبلاً از شمارنده پنهان بود) + legacy failed.
     */
    public function countFailed(): int
    {
        return (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM saga_executions WHERE status IN (?, ?)",
            [self::STATUS_FAILED, self::STATUS_COMPENSATION_FAILED]
        );
    }
}
