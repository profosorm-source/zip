<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * Interaction Model - مدل اشتراکی مدیریت تعاملات کاربری
 * 
 * شامل علاقه‌مندی‌ها (Favorites)، و گزارش تخلفات (Reports) برای موجودیت‌های مختلف
 */
class InteractionModel extends Model
{
    /**
     * نام جدول (الزام قرارداد Core\\Model).
     * این مدل عمدتاً از کوئری‌های خام استفاده می‌کند، اما برای سازگاری با
     * متدهای پایه‌ی Model، جدول مرجع آن تعریف می‌شود.
     */
    protected static string $table = 'task_favorites';

    // ==========================================
    // Favorites (TaskFavorite)
    // ==========================================
    // 🧹 FIX-COSMET-25 (A1-N9+N10/پایین): پنج متد صفر-فراخوانِ این بخش حذف شدند
    // (isFavorite، getUserFavorites — که حتی ستون ناموجود custom_tasks.total_quantity
    // را می‌خواند —، countUserFavorites، updateTaskReport، getTaskReportCount).
    // docblock قبلی که createTaskReport/hasPendingTaskReport را هم «صفر-فراخوان»
    // می‌نامید اشتباه بود (A1-N10): هر دو زنده‌اند و مسیر گزارش تخلف
    // (CustomTaskExecutorService:244,257) به آن‌ها متکی است — ریسک حذف کد زنده.
    // جدول task_favorites و سرویس‌های علاقه‌مندی وب از این مدل جدا هستند.

    // ==========================================
    // Task Reports (TaskReport)
    // ==========================================

    /**
     * ایجاد گزارش جدید تسک
     *
     * 🧾 FIX-M22-CLOSE (D2-N8): task_type صریح (پیش‌فرض 'custom_task' — همان
     * دیفالت اسکیمای ۲۰۲۶_۰۹_۰۲) تا ردیف‌های intake تسک سفارشی با مسیر
     * اینفلوئنسر ('influencer_order') قابل تفکیک باشند؛ adminListTaskReports
     * بر اساس همین ستون JOIN می‌زند.
     */
    /** @param array<string, mixed> $data */
    public function createTaskReport(array $data): ?\stdClass
    {
        $taskType = str_value($data['task_type'] ?? 'custom_task');
        $stmt = $this->db->prepare("
            INSERT INTO task_reports
            (task_id, task_type, reporter_id, reason, description, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 'pending', NOW(), NOW())
        ");

        $result = $stmt->execute([
            $data['task_id'],
            $taskType,
            $data['reporter_id'],
            $data['reason'],
            $data['description'],
        ]);

        if (!$result) {
            return null;
        }

        return $this->findTaskReport((int) $this->db->lastInsertId());
    }

    /**
     * یافتن یک گزارش تسک
     */
    public function findTaskReport(int $id): ?\stdClass
    {
        // 🛡️ FIX-M22-MED (D2-N14): JOIN قبلی به جدول legacy خالی custom_tasks می‌زد
        // (task_title همیشه NULL) — هم‌قرارداد adminListTaskReportsِ اصلاح‌شده (FIX-X86c):
        // بر اساس task_type به ads / influencer_orders وصل می‌شود.
        $stmt = $this->db->prepare("
            SELECT r.*,
                   COALESCE(ads_t.title,
                            CASE WHEN io_t.id IS NOT NULL
                                 THEN CONCAT('سفارش اینفلوئنسر #', io_t.id)
                                 ELSE NULL END) AS task_title,
                   u.full_name AS reporter_name,
                   a.full_name AS admin_name
            FROM task_reports r
            LEFT JOIN ads ads_t ON r.task_type = 'custom_task' AND ads_t.id = r.task_id
            LEFT JOIN influencer_orders io_t ON r.task_type = 'influencer_order' AND io_t.id = r.task_id
            LEFT JOIN users u ON u.id = r.reporter_id
            LEFT JOIN users a ON a.id = r.admin_id
            WHERE r.id = ?
        ");
        $stmt->execute([$id]);
        return $this->fetchObject($stmt);
    }

    /**
     * بررسی گزارش تکراری
     */
    public function hasPendingTaskReport(int $taskId, int $reporterId): bool
    {
        // 🧾 FIX-M22-CLOSE (D2-N8): دِداپ per (task, reporter, type) — دو نوع گزارش
        // روی یک task_id واحد (تسک سفارشی + سفارش اینفلوئنسرِ هم‌شناسه) نباید
        // همدیگر را مسدود کنند.
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM task_reports
            WHERE task_id = ? AND reporter_id = ?
            AND task_type = 'custom_task'
            AND status = 'pending'
        ");
        $stmt->execute([$taskId, $reporterId]);
        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * @param array<string, mixed> $filters
     * @return list<\stdClass>
     */
    public function adminListTaskReports(array $filters = [], int $limit = 30, int $offset = 0): array
    {
        $where = ['1=1'];
        $params = [];

        if (!empty($filters['status'])) {
            $where[] = "r.status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['reason'])) {
            $where[] = "r.reason = ?";
            $params[] = $filters['reason'];
        }

        $whereStr = implode(' AND ', $where);

        // FIX-X86c: JOIN قبلی به جدول legacy خالی custom_tasks می‌خورد (همیشه
        // task_title = NULL). اکنون بر اساس task_type به جدول درست وصل می‌شود:
        // custom_task → ads، influencer_order → influencer_orders.
        // FIX-X86e: خواندن با wrapper (بایند تایپ‌دار LIMIT/OFFSET) — prepare
        // خام PDO با execute(array) مقدار LIMIT را رشته‌ای بایند می‌کرد → 1064.
        $sql = "
            SELECT r.*,
                   /* influencer_orders ستون title ندارد → برچسب از نوع + شناسه */
                   COALESCE(ads_t.title,
                             CASE WHEN io_t.id IS NOT NULL
                                  THEN CONCAT('سفارش اینفلوئنسر #', io_t.id)
                                  ELSE NULL END) AS task_title,
                   u.full_name AS reporter_name
            FROM task_reports r
            LEFT JOIN ads ads_t
                   ON r.task_type = 'custom_task' AND ads_t.id = r.task_id
            LEFT JOIN influencer_orders io_t
                   ON r.task_type = 'influencer_order' AND io_t.id = r.task_id
            LEFT JOIN users u ON u.id = r.reporter_id
            WHERE {$whereStr}
            ORDER BY r.created_at DESC
            LIMIT ? OFFSET ?
        ";

        $params[] = (int)$limit;
        $params[] = (int)$offset;

        return $this->db->fetchAll($sql, $params) ?: [];
    }

    /** @param array<string, mixed> $filters */
    public function adminCountTaskReports(array $filters = []): int
    {
        $where = ['1=1'];
        $params = [];

        if (!empty($filters['status'])) {
            $where[] = "r.status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['reason'])) {
            $where[] = "r.reason = ?";
            $params[] = $filters['reason'];
        }

        $whereStr = implode(' AND ', $where);

        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM task_reports r WHERE {$whereStr}
        ");
        $stmt->execute($params);

        return (int) $stmt->fetchColumn();
    }

    /**
     * FIX-X86: شمارش گزارش‌ها به تفکیک وضعیت برای کارت‌های آماری ادمین
     * (ویوی قبلی «آمار تسک‌ها» را از فیلدهای موهومی می‌خواند)
     * @return array<string, int>
     */
    public function adminTaskReportStatusCounts(): array
    {
        $stmt = $this->db->prepare(
            "SELECT status, COUNT(*) AS c FROM task_reports GROUP BY status"
        );
        $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

        $counts = ['pending' => 0, 'reviewed' => 0, 'resolved' => 0, 'rejected' => 0];
        foreach ($rows as $row) {
            $key = (string)$row['status'];
            $counts[$key] = (int)$row['c'];
        }
        $counts['total'] = array_sum($counts);
        return $counts;
    }

    /** @return array<string, string> */
    public function taskReportReasonLabels(): array
    {
        return [
            'spam' => 'اسپم',
            'fraud' => 'تقلب',
            'inappropriate' => 'نامناسب',
            'misleading' => 'گمراه‌کننده',
            'other' => 'سایر',
        ];
    }

    /** @return array<string, string> */
    public function taskReportStatusLabels(): array
    {
        return [
            'pending' => 'در انتظار',
            'reviewed' => 'بررسی شده',
            'resolved' => 'حل شده',
            'rejected' => 'رد شده',
        ];
    }

    // ==========================================
    // Message Reports (MessageReport)
    // ==========================================

    /** @return list<\stdClass> */
    public function findMessageReportsPaginated(
        int $limit,
        int $offset,
        ?string $status = null
    ): array {
        $where = '1=1';
        $params = [];

        if ($status && $status !== 'all') {
            $where .= ' AND mr.status = ?';
            $params[] = $status;
        }

        $sql = "SELECT 
                mr.id, mr.message_id, mr.reason, mr.status, mr.created_at,
                dm.message, dm.sender_id, dm.recipient_id,
                u.full_name as reporter_name, u.email as reporter_email
             FROM message_reports mr
             JOIN direct_messages dm ON mr.message_id = dm.id
             JOIN users u ON mr.reporter_id = u.id
             WHERE {$where}
             ORDER BY mr.created_at DESC
             LIMIT ? OFFSET ?";

        $stmt = $this->db->prepare($sql);
        $index = 1;
        foreach ($params as $val) {
            $stmt->bindValue($index++, $val);
        }
        $stmt->bindValue($index++, $limit, \PDO::PARAM_INT);
        $stmt->bindValue($index++, $offset, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll() ?: [];
    }

    public function countMessageReports(?string $status = null): int
    {
        $where = '1=1';
        $params = [];

        if ($status && $status !== 'all') {
            $where .= ' AND status = ?';
            $params[] = $status;
        }

        $stmt = $this->db->query(
            "SELECT COUNT(*) as count FROM message_reports WHERE {$where}",
            $params
        );
        $count = $this->fetchObject($stmt);

        return (int) ($count->count ?? 0);
    }

    /** @return array<string, mixed>|null */
    public function findMessageReportById(int $id): ?array
    {
        $stmt = $this->db->query(
            "SELECT mr.*, dm.* 
             FROM message_reports mr
             JOIN direct_messages dm ON mr.message_id = dm.id
             WHERE mr.id = ?",
            [$id]
        );

        return $this->fetchAssoc($stmt) ?: null;
    }

    /**
     * ثبت گزارش (report) عمومی
     */
    public function createReport(int $userId, string $interactableType, int $interactableId, string $interactionType, string $context, string $metaJson): int
    {
        // FIX راند ۷۷ (ستون شبح — تصمیم meta_json): جدول interactions ستون meta_json ندارد؛
        // ستون واقعی context است. متادیتا به‌صورت JSON داخل همان context ادغام می‌شود (بدون از‌دست‌رفتن داده).
        $contextValue = $context;
        $metaTrim = trim($metaJson);
        if ($metaTrim !== '') {
            $decoded = json_decode($metaTrim, true);
            $contextValue = json_encode(
                ['context' => $context, 'meta' => ($decoded === null ? $metaTrim : $decoded)],
                JSON_UNESCAPED_UNICODE
            );
        }
        $stmt = $this->db->prepare("
            INSERT INTO interactions 
            (user_id, interactable_type, interactable_id, interaction_type, context, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        ");
        $stmt->execute([$userId, $interactableType, $interactableId, $interactionType, $contextValue]);
        return (int)$this->db->lastInsertId();
    }

    /**
     * تعداد گزارش‌های یک entity
     */
    public function countReports(string $interactableType, int $interactableId, string $interactionType): int
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(id) FROM interactions 
            WHERE interactable_type = ? AND interactable_id = ? AND interaction_type = ?
        ");
        $stmt->execute([$interactableType, $interactableId, $interactionType]);
        return (int)$stmt->fetchColumn();
    }
}
