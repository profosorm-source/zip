<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * Rating Model - مدل اشتراکی نظرات و امتیازات عددی
 *
 * FIX-18O (P1): هم‌ترازی با شمای واقعی جدول ratings
 * (2026_06_10_0010_engagement_gaming.sql: user_id, target_id, target_type,
 * rating, comment). fillable قبلی ستون‌های شبح stars/status داشت و
 * getAverage/hasRated روی rated_id/rated_type/rater_id/ref_type/ref_id
 * (ستون‌های ناموجود = SQLSTATE 42S22) کوئری می‌زدند.
 */
class Rating extends Model
{
    protected static string $table = 'ratings';

    protected array $fillable = ['user_id', 'target_id', 'target_type', 'rating', 'comment'];

    /**
     * میانگین امتیاز یک هدف.
     * امضای متد (و فراخوان‌ها) حفظ شده: $ratedId → ratings.target_id،
     * $ratedType → ratings.target_type.
     */
    public function getAverage(int $ratedId, string $ratedType): float
    {
        return (float)$this->db->table(static::$table)
            ->where('target_id', '=', $ratedId)
            ->where('target_type', '=', $ratedType)
            ->avg('rating');
    }

    // createOnce() حذف شد — dead code بود (هیچ caller نداشت)
    // برای ثبت rating از RatingService::rate() استفاده کنید

    /**
     * بررسی اینکه آیا کاربر قبلاً برای این هدف امتیاز ثبت کرده است یا خیر.
     * امضای متد حفظ شده: $raterId → user_id، $refType → target_type،
     * $refId → target_id (کلید یکتای user_id+target_id+target_type).
     */
    public function hasRated(int $raterId, string $refType, int $refId): bool
    {
        $row = $this->db->table(static::$table)
            ->where('user_id', '=', $raterId)
            ->where('target_type', '=', $refType)
            ->where('target_id', '=', $refId)
            ->selectRaw('1')
            ->first();

        return (bool)$row;
    }
}
