<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * FraudReport — مدل گزارش تخلف (X372، راند ۹۳)
 *
 * ─── زمینه ──────────────────────────────────────────────────────
 * جدول fraud_reports از مایگریشن 2026_06_10_0049 ساخته شده بود اما یتیم بود:
 * هیچ مدل/کنترلر/نویسنده‌ای نداشت (تنها خواننده KpiStatistics::getFraudStats).
 * X372 سیم‌کشی سرتاسری: ثبت گزارش از هاب رفرال (کاربر) + صف بررسی ادمین
 * (/admin/fraud/reports) — سه‌لایه، آینهٔ خانوادهٔ MessageModeration.
 *
 * ─── قرارداد ────────────────────────────────────────────────────
 *  - reason آزاد (TEXT) است اما لایهٔ کنترلر ورودی را به لیست مجاز REASONS
 *    محدود می‌کند (کلید انگلیسی ذخیره می‌شود؛ برچسب فارسی فقط برای نمایش).
 *  - evidence JSON: {text: ..., source: "referral_hub"}.
 *  - ضد تکرار: یک گزارشِ pending باز برای جفت (reporter, reported) کافی است.
 *  - سقف نرخ: حداکثر ۳ گزارش pending باز در ۲۴ ساعت به‌ازای هر گزارش‌دهنده
 *    (منبع شمارش: pendingCountForReporter).
 *
 * @phpstan-type FraudReportRow object{id:int, reporter_id:int, reported_user_id:int, reason:string, evidence:string|null, status:string, admin_note:string|null, reviewed_by:int|null, reviewed_at:string|null, created_at:string}
 */
class FraudReport extends Model
{
    /** نام جدول (الزام قرارداد Core\Model) */
    protected static string $table = 'fraud_reports';

    /** ماشین وضعیت: pending → reviewed | dismissed */
    public const STATUS_PENDING  = 'pending';
    public const STATUS_REVIEWED = 'reviewed';
    public const STATUS_DISMISSED = 'dismissed';

    /** سقف گزارش‌های pending بازِ هر کاربر در پنجرهٔ ۲۴ساعته (rate-limit) */
    public const MAX_PENDING_PER_24H = 3;

    /** حداکثر طول متن شواهد اختیاری */
    public const MAX_EVIDENCE_LENGTH = 1000;

    /**
     * واژه‌نامهٔ کنترل‌شدهٔ دلیل گزارش — کلید = مقدار ذخیره‌شده در DB.
     * منبع واحد حقیقت؛ ویو هاب رفرال همین ثابت را برای <select> مصرف می‌کند.
     *
     * @var array<string, string>
     */
    public const REASONS = [
        'spam_link'     => 'ارسال لینک هرزنامه یا تبلیغات',
        'fake_promises' => 'قول دروغ یا وعدهٔ غیرواقعی درآمد',
        'impersonation' => 'جعل هویت یا وانمودکردن به دیگران',
        'farming'       => 'ساخت حساب‌های تقلبی برای سوءاستفاده از رفرال',
        'other'         => 'سایر موارد',
    ];

    /**
     * وزن دلتای حکم تخلف روی دامنهٔ fraud (X381، راند ۱۰۱) — به‌ازای هر گزارش
     * تأییدشدهٔ ادمین به امتیاز fraud گزارش‌شونده اضافه می‌شود.
     *
     * قرارداد مقیاس: دامنهٔ fraud در بازهٔ [0,100] بسته است (ScoreDomainPolicy::bounds)
     * و آستانه‌های تصمیم limit/challenge/block به‌ترتیب 40/60/80 هستند
     * (RiskDecisionService). وزن‌ها عمداً محافظه‌کارانه انتخاب شده‌اند تا «یک» حکم
     * منفرد هیچ‌گاه به‌تنهایی آستانهٔ block را نتواند عبور دهد؛ گذر از آستانه‌ها
     * نیازمند تجمع چند حکم مستقل است. مرتب‌شده بر اساس شدت تخلف.
     * منبع واحد حقیقت — مصرف‌کنندگان: UserService::confirmFraudReportScore (دلتای
     * سیستمی) و views/admin/fraud/reports.php (badge وزن).
     *
     * @var array<string, int>
     */
    public const REASON_WEIGHTS = [
        'spam_link'     => 10,
        'fake_promises' => 15,
        'impersonation' => 20,
        'farming'       => 25,
        'other'         => 5,
    ];

    /** وزن پیش‌فرض fail-safe برای کلید ناشناخته (هم‌تراز با other) */
    public const DEFAULT_REASON_WEIGHT = 5;

    /**
     * وزن دلتای دلیل‌محور برای حکم تأیید گزارش تخلف.
     *
     * @param string $reasonKey کلید دلیل (کلیدهای REASONS) — کلید ناشناخته
     *                          به‌جای پرتاب استثنا، وزن پیش‌فرض برمی‌گرداند
     *                          (fail-safe: مسیر ویو و حکم ادمین هرگز به خطا
     *                          فرو نریزد).
     */
    public static function weightFor(string $reasonKey): int
    {
        return self::REASON_WEIGHTS[$reasonKey] ?? self::DEFAULT_REASON_WEIGHT;
    }

    /**
     * ثبت گزارش جدید. از QueryBuilder استفاده می‌کند (سبک خانه).
     * نام createReport (نه create) چون Core\Model::create(array $data) را overload نمی‌توان
     * امضای متفاوت داشت — آینهٔ MessageModerationModel::createReport.
     *
     * @param array<string, mixed> $evidence — پیش از فراخوانی JSON-encode نمی‌شود؛ اینجا encode می‌شود
     * @return int شناسهٔ ردیف تازه
     * @throws \RuntimeException در صورت شکست INSERT
     */
    public function createReport(int $reporterId, int $reportedUserId, string $reason, array $evidence): int
    {
        $id = $this->db->table('fraud_reports')->insert([
            'reporter_id'      => $reporterId,
            'reported_user_id' => $reportedUserId,
            'reason'           => $reason,
            'evidence'         => json_encode($evidence, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'status'           => self::STATUS_PENDING,
        ]);

        if (!is_int($id) || $id <= 0) {
            throw new \RuntimeException('خطا در ثبت گزارش تخلف.');
        }
        return $id;
    }

    /**
     * ضد تکرار: آیا همین گزارش‌دهنده برای همین کاربرِ گزارش‌شده یک گزارشِ pending باز دارد؟
     */
    public function hasPendingReport(int $reporterId, int $reportedUserId): bool
    {
        return $this->db->table('fraud_reports')
            ->where('reporter_id', $reporterId)
            ->where('reported_user_id', $reportedUserId)
            ->where('status', self::STATUS_PENDING)
            ->exists();
    }

    /**
     * شمارش گزارش‌های pending بازِ گزارش‌دهنده در ۲۴ ساعت اخیر —
     * منبع rate-limit (سقف MAX_PENDING_PER_24H).
     */
    public function pendingCountForReporter(int $reporterId): int
    {
        return (int)$this->db->table('fraud_reports')
            ->where('reporter_id', $reporterId)
            ->where('status', self::STATUS_PENDING)
            ->whereRaw('created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)')
            ->count();
    }

    /**
     * صف بررسی ادمین با نام گزارش‌دهنده/گزارش‌شده (JOIN users).
     * سبک خانه: کوئری خام داخل مدل (آینهٔ MessageModerationModel::getBlockedUsers).
     *
     * @return array{items: list<\stdClass>, total: int, page: int, per_page: int, last_page: int}
     */
    public function paginateReports(int $page, int $perPage, ?string $status = null): array
    {
        $page    = max(1, $page);
        $perPage = max(1, $perPage);
        $offset  = ($page - 1) * $perPage;

        $where  = '';
        $params = [];
        if ($status !== null && $status !== 'all') {
            $where = ' WHERE fr.status = ?';
            $params[] = $status;
        }

        $sql = "SELECT fr.id, fr.reporter_id, fr.reported_user_id, fr.reason, fr.evidence,
                       fr.status, fr.admin_note, fr.reviewed_by, fr.reviewed_at, fr.created_at,
                       rp.full_name AS reporter_name, rp.username AS reporter_username,
                       ru.full_name AS reported_name, ru.username AS reported_username
                FROM fraud_reports fr
                LEFT JOIN users rp ON rp.id = fr.reporter_id
                LEFT JOIN users ru ON ru.id = fr.reported_user_id"
            . $where
            . " ORDER BY fr.created_at DESC, fr.id DESC
                LIMIT ? OFFSET ?";

        $stmt = $this->db->prepare($sql);
        foreach (array_merge($params, [$perPage, $offset]) as $i => $binding) {
            $stmt->bindValue($i + 1, $binding, is_int($binding) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->execute();
        /** @var list<\stdClass> $items */
        $items = $this->fetchObjectList($stmt);

        $countSql = 'SELECT COUNT(*) FROM fraud_reports fr' . $where;
        $total    = (int)$this->db->fetchColumn($countSql, $params);

        return [
            'items'     => $items,
            'total'     => $total,
            'page'      => $page,
            'per_page'  => $perPage,
            'last_page' => max(1, (int)ceil($total / $perPage)),
        ];
    }

    /**
     * گذار به وضعیت «بررسی شد» + امضای ادمین.
     */
    public function review(int $id, int $adminId, ?string $note): bool
    {
        return $this->transition($id, $adminId, $note, self::STATUS_REVIEWED);
    }

    /**
     * گذار به وضعیت «رد شد» + امضای ادمین.
     */
    public function dismiss(int $id, int $adminId, ?string $note): bool
    {
        return $this->transition($id, $adminId, $note, self::STATUS_DISMISSED);
    }

    /**
     * هستهٔ مشترک گذار وضعیت (reviewed/dismissed) — اتمام صف با امضای ادمین.
     * 🛡️ X376 (راند ۹۸): گارد وضعیت در خود SQL — گذار فقط از pending.
     * پیش از این گارد، گذارِ مجدد روی ردیفِ حل‌شده true برمی‌گرداند (پیام
     * خطای کنترلر دربارهٔ «قبلاً بررسی شده» دروغ می‌گفت) و بدتر: با سیم‌کشی
     * سیگنال لجریِ X376، دابل‌کلیک review یعنی دوبار رویداد fraud_report_confirmed
     * در لجر. این گارد، گیتِ once-only سیگنال لجری است (لایهٔ ۱؛ لایهٔ ۲:
     * کلید ایدمپوتنسی SETNX در applySystemDelta).
     */
    private function transition(int $id, int $adminId, ?string $note, string $status): bool
    {
        // reviewed_at با مقدار PHP تولید می‌شود (QueryBuilder مقدار خام SQL نمی‌پذیرد)؛
        // APP_TIMEZONE = Asia/Tehran و DB سرور همان منطقهٔ زمانی را دارد.
        $affected = $this->db->table('fraud_reports')
            ->where('id', $id)
            ->where('status', self::STATUS_PENDING)
            ->update([
                'status'      => $status,
                'admin_note'  => $note !== null ? mb_substr($note, 0, 1000) : null,
                'reviewed_by' => $adminId,
                'reviewed_at' => date('Y-m-d H:i:s'),
            ]);

        return $affected > 0;
    }

    /**
     * 🛡️ X376 (راند ۹۸): یابندهٔ تک‌ردیفی برای لایهٔ کنترلر — پس از گذارِ موفق
     * review، برای شلیک سیگنال لجری به reported_user_id نیاز است.
     *
     * 🛡️ FIX-PS-C2: شکل واقعیِ برگشتی stdClass است (ردیف دیتابیس)؛ مصرف‌کننده‌ها با
     * int_value/str_value امن می‌خوانند.
     * @return \stdClass|null
     */
    public function findById(int $id): ?\stdClass
    {
        $row = $this->db->table('fraud_reports')
            ->select('id', 'reporter_id', 'reported_user_id', 'reason', 'status')
            ->where('id', $id)
            ->first();
        return $row !== null ? (object)$row : null;
    }

    /**
     * آمار ماه جاری صف — کلیدها را برای پنل ادمین/KPI صادق نگه می‌دارد:
     *  - pending: کل صف بازِ الان
     *  - reviewed_30d / dismissed_30d: گذارهای ۳۰ روز اخیر
     *
     * @return array{pending: int, reviewed_30d: int, dismissed_30d: int}
     */
    public function monthlyStats(): array
    {
        $pending = (int)$this->db->table('fraud_reports')
            ->where('status', self::STATUS_PENDING)
            ->count();

        $reviewed = (int)$this->db->table('fraud_reports')
            ->where('status', self::STATUS_REVIEWED)
            ->whereRaw('reviewed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)')
            ->count();

        $dismissed = (int)$this->db->table('fraud_reports')
            ->where('status', self::STATUS_DISMISSED)
            ->whereRaw('reviewed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)')
            ->count();

        return [
            'pending'       => $pending,
            'reviewed_30d'  => $reviewed,
            'dismissed_30d' => $dismissed,
        ];
    }
}
