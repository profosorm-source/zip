<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

/**
 * ApiToken Model - Secured and Optimized
 */
class ApiToken extends Model
{
    // Evaluates is_active status of tokens
    protected static string $table = 'api_tokens';

    /**
     * FIX-18O (P1): توکن‌های هش‌شده (access/refresh) secrets هستند و با
     * toPublicArray() از خروجی عمومی حذف می‌شوند. واکشی خام (SELECT *،
     * findByHash و…) دست‌نخورده همه ستون‌ها را برمی‌گرداند — راستی‌آزمایی
     * توکن به آن‌ها نیاز دارد.
     * FIX-M11-L2: مسیرهای ادمین (findAllPaginated/findById) دیگر از SELECT * عبور
     * نمی‌کنند و به ADMIN_SAFE_COLUMNS محدود شدند (مرز DTO در خود کوئری).
     */
    protected array $hidden = ['token', 'refresh_token'];

    public const ALLOWED_SCOPES = [
        'read', 'write', 'admin', 'delete',
        'profile:read', 'profile:write', 
        'wallet:read', 'wallet:write', 
        'transactions:read', 'tasks:read', 'tasks:write',
        'security:read', 'security:write', 
        'settings:read', 'settings:write',
        // Scopes used by /api/v1 route middleware. Keep legacy colon scopes above
        // for backwards compatibility, but allow the actual route-level scopes too.
        'auth.manage',
        'user.read', 'user.write',
        'wallet.read', 'wallet.write',
        'social.read', 'social.write',
        'influencer.read', 'influencer.write',
        'verification.read', 'verification.write',
        'realtime',
        // FIX-M11-M3 (گزارش ماژول ۱۱): wildcard «*» هم‌راستا شد — سرویس (ADMIN_SCOPES)
        // و middleware آن را می‌پذیرند ولی allowlist قبلی فاقدش بود ⇒ ادمین هرگز
        // نمی‌توانست توکن wildcard بسازد و قرارداد سه‌گانه بود. صدورش فقط برای
        // ادمین است (گیت createToken پایین + گیت سرویس) و به‌عنوان کمترین
        // امتیازِ صریحِ مدیریتی مستند شده است.
        '*'
    ];

    /**
     * FIX-M11-L2 (گزارش ماژول ۱۱): allowlist ستون‌های غیرحساس برای خروجی
     * ادمین/DTO — token و refresh_token هشِ HMAC اند (secret) و هرگز نباید
     * به لایهٔ view/API نشت کنند. واکشیِ خام at.* مرزِ secrets را نمی‌بست.
     */
    private const ADMIN_SAFE_COLUMNS = [
        'at.id', 'at.user_id', 'at.name', 'at.scopes',
        'at.revoked', 'at.revoked_at', 'at.expires_at',
        'at.secret_version', 'at.refresh_secret_version',
        'at.use_count', 'at.last_used_at', 'at.created_at',
    ];

    public function __construct(Database $db) {
        parent::__construct($db);
    }

    public function findById(int $id): ?\stdClass
    {
        $this->validateId($id);

        // FIX-M11-L2: ستون‌های حساس (token/refresh_token) از خروجی حذف شدند.
        $token = $this->db->fetch(
            "SELECT " . implode(', ', self::ADMIN_SAFE_COLUMNS) . ", u.full_name, u.email
             FROM api_tokens at
             LEFT JOIN users u ON u.id = at.user_id
             WHERE at.id = ?",
            [$id]
        );

        return $token ?: null;
    }

    /**
     * FIX-M11-H2/M2 (گزارش ماژول ۱۱): شرطِ کانونیِ وضعیت — وضعیت توکن ستونِ
     * فیزیکی نیست و از revoked + expires_at مشتق می‌شود. همهٔ مسیرهای فهرست/جستجو
     * باید از همین predicate استفاده کنند تا قرارداد یکدست باشد.
     *
     * @return array{0:string, 1:list<mixed>} [sql, params]
     */
    private static function statusPredicate(string $statusFilter): array
    {
        return match ($statusFilter) {
            'active' => ['at.revoked = 0 AND (at.expires_at IS NULL OR at.expires_at > NOW())', []],
            'revoked' => ['at.revoked = 1', []],
            'expired' => ['at.revoked = 0 AND at.expires_at IS NOT NULL AND at.expires_at < NOW()', []],
            default => ['', []],
        };
    }

    /**
     * FIX-M11-H2/M2: جستجوی کانونی — نام/ایمیل LIKE و اگر ورودی ۶۴-hex باشد
     * تطبیقِ exact با هشِ HMAC نسخهٔ جاری (هم‌قرارداد searchTokens سرویس).
     *
     * @return array{0:string, 1:list<mixed>}
     */
    private static function searchPredicate(string $search): array
    {
        $escaped = addcslashes(trim($search), '%_\\');
        $like = '%' . $escaped . '%';
        $sql = '(at.name LIKE ? OR u.email LIKE ?';
        $params = [$like, $like];
        if (preg_match('/^[a-f0-9]{64}$/i', trim($search))) {
            $apiSecret = config('security.api.secrets.' . config('security.api.current_secret_version', 'v2'));
            if (!is_string($apiSecret) || strlen($apiSecret) < 32) {
                $apiSecret = \defined('SECURITY_API_TOKEN_SECRET') ? (string) SECURITY_API_TOKEN_SECRET : '';
            }
            if ($apiSecret !== '') {
                $sql .= ' OR at.token = ?';
                $params[] = hash_hmac('sha256', trim($search), $apiSecret);
            }
        }
        $sql .= ')';
        return [$sql, $params];
    }

    /** @return list<object> */
    public function findAllPaginated(
        int $limit,
        int $offset,
        ?string $search = null,
        ?string $statusFilter = null
    ): array {
        $query = $this->db->table('api_tokens as at')
            ->leftJoin('users as u', 'u.id', '=', 'at.user_id');

        if ($search) {
            [$sql, $params] = self::searchPredicate($search);
            $query->whereRaw($sql, $params);
        }

        if ($statusFilter !== null && $statusFilter !== '') {
            [$sql, $params] = self::statusPredicate($statusFilter);
            if ($sql !== '') {
                $query->whereRaw($sql, $params);
            }
        }

        // FIX-M11-L2: SELECT کانونیِ بدونِ هش‌ها (به‌جای at.*).
        // نکته: QueryBuilder ستون‌ها را به‌صورت آرگومان‌های جدا می‌پذیرد (رشتهٔ
        // join‌شده یک شناسه واحد تلقی و توسط SafeExpression رد می‌شود).
        $results = $query->select(...array_merge(self::ADMIN_SAFE_COLUMNS, ['u.full_name', 'u.email']))
                         ->orderBy('at.created_at', 'DESC')
                         ->limit($limit)
                         ->offset($offset)
                         ->get();

        return $results ?: [];
    }

    public function countAll(?string $search = null, ?string $statusFilter = null): int
    {
        $query = $this->db->table('api_tokens as at')
            ->leftJoin('users as u', 'u.id', '=', 'at.user_id');

        if ($search) {
            [$sql, $params] = self::searchPredicate($search);
            $query->whereRaw($sql, $params);
        }

        if ($statusFilter !== null && $statusFilter !== '') {
            [$sql, $params] = self::statusPredicate($statusFilter);
            if ($sql !== '') {
                $query->whereRaw($sql, $params);
            }
        }

        return $query->count();
    }

    public function revokeById(int $id): bool
    {
        $this->validateId($id);

        // FIX-M11-H5 (گزارش ماژول ۱۱): قرارداد rowCount — قبلاً حتی برای id ناموجود
        // یا توکنِ ازقبل-باطل‌شده true برمی‌گشت (موفقیتِ کاذب + audit دروغین در
        // کنترلر). اکنون 0 ردیفِ تغییرکرده ⇒ false؛ تمایزِ already_revoked/not_found
        // در سرویس (revokeToken) انجام می‌شود.
        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW() WHERE id = ? AND revoked = 0"
        );
        $stmt->execute([$id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * W4-E: تمدید عمر توکن — expires_at به مقدار جدید (الان + N روز، محاسبه در سرویس)
     * به‌روزرسانی می‌شود. فقط ردیف‌های غیرباطل (revoked=0) قابل تمدیدند؛ شرط در WHERE،
     * رقابت هم‌زمانِ revoke-در-برابر-renew را می‌بندد (rowCount=0 → تمدید ناموفق).
     */
    public function renewById(int $id, string $newExpiresAt): bool
    {
        $this->validateId($id);
        $this->validateDate($newExpiresAt, 'new_expires_at');

        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET expires_at = ? WHERE id = ? AND revoked = 0"
        );
        $stmt->execute([$newExpiresAt, $id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * Atomic Compare-And-Swap revocation for Refresh Token Rotation (Finding #5)
     */
    public function revokeByIdIfActive(int $id): bool
    {
        $this->validateId($id);

        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW() WHERE id = ? AND revoked = 0"
        );
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

    /**
     * M-25: revoke every non-revoked token belonging to a user. Used for refresh-token-reuse
     * (theft) response — when a already-rotated refresh token is replayed we must kill the whole
     * family, not just the presented one, because the attacker likely holds a live descendant.
     */
    public function revokeAllForUser(int $userId): int
    {
        $this->validateId($userId, 'user_id');
        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW() WHERE user_id = ? AND revoked = 0"
        );
        $stmt->execute([$userId]);
        return $stmt->rowCount();
    }

    /**
     * M-25: locate a token by its refresh token INCLUDING already-revoked / expired rows.
     * findByRefreshToken() intentionally filters revoked=0; this variant lets the service detect
     * replay of a previously-rotated (and therefore revoked) refresh token.
     */
    public function findAnyByRefreshToken(string $plainRefreshToken): ?\stdClass
    {
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        if (empty($secrets)) {
            $legacySecret = \defined('SECURITY_API_TOKEN_SECRET') ? SECURITY_API_TOKEN_SECRET : null;
            if ($legacySecret) {
                $secrets = ['v2' => $legacySecret];
            }
        }
        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) ? $currentVersionValue : 'v2';
        $orderedSecrets = [];
        if (isset($secrets[$currentVersion])) {
            $orderedSecrets[$currentVersion] = $secrets[$currentVersion];
        }
        foreach ((array)$secrets as $version => $secret) {
            if ($version !== $currentVersion) {
                $orderedSecrets[$version] = $secret;
            }
        }
        foreach ((array)$orderedSecrets as $version => $secret) {
            if (empty($secret) || strlen((string)$secret) < 32) {
                continue;
            }
            $hashedToken = hash_hmac('sha256', $plainRefreshToken, $secret);
            // FIX-M11-C1: هم‌قرارداد findByRefreshToken — ستون مستقلِ نسخهٔ refresh.
            $tokenRow = $this->db->fetch(
                "SELECT at.*, u.status as user_status, u.email, u.role
                 FROM api_tokens at
                 LEFT JOIN users u ON u.id = at.user_id
                 WHERE at.refresh_token = ? AND at.refresh_secret_version = ?
                 LIMIT 1",
                [$hashedToken, $version]
            );
            if ($tokenRow) {
                return (object)['row' => $tokenRow, 'hashed' => $hashedToken, 'version' => $version];
            }
        }
        return null;
    }

    public function revokeForUser(int $id, int $userId): bool
    {
        $this->validateId($id);
        $this->validateId($userId, 'user_id');

        $stmt = $this->db->prepare(
            "UPDATE api_tokens 
             SET revoked = 1, revoked_at = NOW() 
             WHERE id = ? AND user_id = ? AND revoked = 0"
        );
        $stmt->execute([$id, $userId]);
        return $stmt->rowCount() > 0;
    }

    public function revokeByHashForUser(string $plainToken, int $userId): bool
    {
        if (empty($plainToken)) {
            throw new \InvalidArgumentException('Token cannot be empty');
        }
        $this->validateId($userId, 'user_id');

        $details = $this->getHashedTokenDetails($plainToken);
        if (!$details) {
            return false;
        }

        $stmt = $this->db->prepare(
            "UPDATE api_tokens 
             SET revoked = 1, revoked_at = NOW() 
             WHERE token = ? AND secret_version = ? AND user_id = ? AND revoked = 0"
        );
        $stmt->execute([$details->hashed, $details->version, $userId]);
        return $stmt->rowCount() > 0;
    }

    public function createToken(
        int $userId, 
        string $plainToken, 
        string $name, 
        string $scopes, 
        ?string $expiresAt,
        ?string $plainRefreshToken = null
    ): int {
        $this->validateId($userId, 'user_id');

        if (empty($plainToken) || strlen((string)$plainToken) < 32) {
            throw new \InvalidArgumentException('Token too weak');
        }
        
        if (empty($name) || strlen((string)$name) > 100) {
            throw new \InvalidArgumentException('Invalid token name');
        }
        
        $userRow = $this->db->fetch("SELECT role FROM users WHERE id = ?", [$userId]);
        $isAdminUser = in_array($userRow->role ?? '', ['admin', 'super_admin'], true);

        $scopesArray = explode(',', $scopes);
        foreach ($scopesArray as $scope) {
            $trimmed = trim((string)$scope);
            if (!in_array($trimmed, self::ALLOWED_SCOPES, true)) {
                throw new \InvalidArgumentException("Invalid scope: {$scope}");
            }
            // FIX-M11-M3: wildcard «*» هم مثل «admin» فقط برای ادمین — گیتِ مدل
            // (دفاع در عمق؛ گیت اصلی در سرویس validateAndFilterScopes است).
            if (($trimmed === 'admin' || $trimmed === '*') && !$isAdminUser) {
                throw new \InvalidArgumentException("Normal user cannot create API token with admin scope.");
            }
        }

        if ($expiresAt !== null) {
            $this->validateDate($expiresAt, 'expires_at');
        }

        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) ? $currentVersionValue : 'v2';
        $secret = config("security.api.secrets.{$currentVersion}");
        if (empty($secret)) {
            $secret = \defined('SECURITY_API_TOKEN_SECRET') ? SECURITY_API_TOKEN_SECRET : null;
        }
        
        if (!$secret || strlen((string)$secret) < 32) {
            throw new \RuntimeException('API secret key is not configured or too weak (minimum 32 characters required)');
        }
        
        $hashedToken = hash_hmac('sha256', $plainToken, $secret);
        $hashedRefreshToken = $plainRefreshToken ? hash_hmac('sha256', $plainRefreshToken, $secret) : null;

        // FIX-M11-C1: در لحظهٔ صدور، access و refresh هر دو با همان secret جاری
        // هش می‌شوند — نسخهٔ refresh به‌طور مستقل ثبت می‌شود تا چرخشِ بعدیِ access
        // هرگز refresh را یتیم نکند (قرارداد نسخهٔ جدا برای هر هش).
        $this->db->query(
            "INSERT INTO api_tokens (user_id, token, refresh_token, secret_version, refresh_secret_version, name, scopes, expires_at, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())",
            [$userId, $hashedToken, $hashedRefreshToken, $currentVersion, $currentVersion, $name, $scopes, $expiresAt]
        );

        return (int)$this->db->lastInsertId();
    }

    public function findByRefreshToken(string $plainRefreshToken): ?\stdClass
    {
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        if (empty($secrets)) {
            $legacySecret = \defined('SECURITY_API_TOKEN_SECRET') ? SECURITY_API_TOKEN_SECRET : null;
            if ($legacySecret) {
                $secrets = ['v2' => $legacySecret];
            }
        }

        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) ? $currentVersionValue : 'v2';
        
        $orderedSecrets = [];
        if (isset($secrets[$currentVersion])) {
            $orderedSecrets[$currentVersion] = $secrets[$currentVersion];
        }
        foreach ((array)$secrets as $version => $secret) {
            if ($version !== $currentVersion) {
                $orderedSecrets[$version] = $secret;
            }
        }

        foreach ((array)$orderedSecrets as $version => $secret) {
            if (empty($secret) || strlen((string)$secret) < 32) {
                continue;
            }

            $hashedToken = hash_hmac('sha256', $plainRefreshToken, $secret);
            
            // FIX-M11-C1: تطبیق با «نسخهٔ secret هشِ refresh» (ستون مستقل) — نه
            // secret_version ردیف که چرخش access آن را جلو می‌برد.
            $tokenRow = $this->db->fetch(
                "SELECT at.*, u.status as user_status, u.email, u.role 
                 FROM api_tokens at
                 LEFT JOIN users u ON u.id = at.user_id
                 WHERE at.refresh_token = ?
                   AND at.refresh_secret_version = ?
                   AND at.revoked = 0
                   AND (at.expires_at IS NULL OR at.expires_at > NOW())
                 LIMIT 1",
                [$hashedToken, $version]
            );

            if ($tokenRow) {
                return (object)[
                    'row' => $tokenRow,
                    'hashed' => $hashedToken,
                    'version' => $version
                ];
            }
        }

        return null;
    }

    /**
     * @return array<object>
     */
    public function findByUserId(int $userId): array
    {
        $this->validateId($userId);

        $results = $this->db->fetchAll(
            "SELECT id, name, scopes, last_used_at, use_count, expires_at, created_at
             FROM api_tokens
             WHERE user_id = ? AND revoked = 0
             ORDER BY created_at DESC",
            [$userId]
        );

        return $results ?: [];
    }

    public function countActiveByUserId(int $userId): int
    {
        $this->validateId($userId);

        // 🛡️ FIX-CH16: شمارش «فعال» با expires_at هم‌راستا شد — قبلاً توکن‌های
        // منقضیِ revokeنشده هم در سقف ۱۰ حساب می‌شدند و کاربر تا اجرای cleanup
        // نمی‌توانست توکن تازه بسازد؛ اعتبارسنجی واقعی (findByRefreshToken)
        // expiry را می‌سنجد، پس شمارنده هم باید همان قرارداد را داشته باشد.
        $count = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens
             WHERE user_id = ? AND revoked = 0
               AND (expires_at IS NULL OR expires_at > NOW())",
            [$userId]
        );

        if (!$count) {
            return 0;
        }

        return $this->scalarCount($count);
    }

    /**
     * FIX-M11-M1 (گزارش ماژول ۱۱): همان قرارداد countActiveByUserId ولی با
     * FOR UPDATE — فقط «داخل تراکنش» معنا دارد و قفلِ رنجِ ایندکس user_id را
     * می‌گیرد تا شمارشِ سقف ۱۰ در برابر درجِ هم‌زمان اتمیک بماند.
     */
    public function countActiveByUserIdForUpdate(int $userId): int
    {
        $this->validateId($userId);

        $count = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens
             WHERE user_id = ? AND revoked = 0
               AND (expires_at IS NULL OR expires_at > NOW())
             FOR UPDATE",
            [$userId]
        );

        if (!$count) {
            return 0;
        }

        return $this->scalarCount($count);
    }

    public function revokeByHash(string $plainToken): bool
    {
        if (empty($plainToken)) {
            throw new \InvalidArgumentException('Token cannot be empty');
        }

        $details = $this->getHashedTokenDetails($plainToken);
        if (!$details) {
            return false;
        }

        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW() WHERE token = ? AND secret_version = ?"
        );
        $stmt->execute([$details->hashed, $details->version]);

        // FIX-R19-A7-4: real rowCount semantics (aligned with revokeByIdIfActive) —
        // 0 matched rows (unknown token or already revoked) must not report success.
        return $stmt->rowCount() > 0;
    }

    public function findByHash(string $plainToken): ?\stdClass
    {
        if (empty($plainToken)) {
            throw new \InvalidArgumentException('Token cannot be empty');
        }

        $details = $this->getHashedTokenDetails($plainToken);
        return $details ? $details->row : null;
    }

    /**
     * Helper to lookup hashed token details iteratively over active secret versions
     */
    /** @return \stdClass|null */
    private function getHashedTokenDetails(string $plainToken): ?\stdClass
    {
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        if (empty($secrets)) {
            $legacySecret = \defined('SECURITY_API_TOKEN_SECRET') ? SECURITY_API_TOKEN_SECRET : null;
            if ($legacySecret) {
                $secrets = ['v2' => $legacySecret];
            }
        }

        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) ? $currentVersionValue : 'v2';
        
        $orderedSecrets = [];
        if (isset($secrets[$currentVersion])) {
            $orderedSecrets[$currentVersion] = $secrets[$currentVersion];
        }
        foreach ((array)$secrets as $version => $secret) {
            if ($version !== $currentVersion) {
                $orderedSecrets[$version] = $secret;
            }
        }

        foreach ((array)$orderedSecrets as $version => $secret) {
            if (empty($secret) || strlen((string)$secret) < 32) {
                continue;
            }

            $hashedToken = hash_hmac('sha256', $plainToken, $secret);
            
            // Check if this hash and version exists in database
            $tokenRow = $this->db->fetch(
                "SELECT * FROM api_tokens WHERE token = ? AND secret_version = ? LIMIT 1",
                [$hashedToken, $version]
            );

            if ($tokenRow) {
                return (object)[
                    'row' => $tokenRow,
                    'hashed' => $hashedToken,
                    'version' => $version
                ];
            }
        }

        return null;
    }

    public function revokeAllExpired(): int
    {
        $stmt = $this->db->prepare(
            "UPDATE api_tokens 
             SET revoked = 1, revoked_at = NOW() 
             WHERE revoked = 0 AND expires_at IS NOT NULL AND expires_at < NOW()"
        );
        $stmt->execute();
        return (int)$stmt->rowCount();
    }

    private function scalarCount(mixed $row): int
    {
        if (is_object($row)) {
            $vars = get_object_vars($row);
            return is_numeric($vars['count'] ?? null) ? (int)$vars['count'] : 0;
        }
        if (is_array($row)) {
            return is_numeric($row['count'] ?? null) ? (int)$row['count'] : 0;
        }
        return 0;
    }

    /** @return array<string, int> */
    public function getStats(): array
    {
        $activeCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens 
             WHERE revoked = 0 AND (expires_at IS NULL OR expires_at > NOW())"
        );

        $revokedCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens WHERE revoked = 1"
        );

        $expiredCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens 
             WHERE revoked = 0 AND expires_at IS NOT NULL AND expires_at < NOW()"
        );

        $usedTodayCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens WHERE DATE(last_used_at) = CURDATE()"
        );

        $active = $this->scalarCount($activeCount);
        $revoked = $this->scalarCount($revokedCount);
        $expired = $this->scalarCount($expiredCount);
        $usedToday = $this->scalarCount($usedTodayCount);

        return [
            'active' => (int)$active,
            'revoked' => (int)$revoked,
            'expired' => (int)$expired,
            'used_today' => (int)$usedToday,
        ];
    }
}
