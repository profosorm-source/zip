<?php

declare(strict_types=1);

namespace App\Models;

use Core\Database;
use Core\Model;

/**
 * ApiToken Model - Secured and Optimized
 */
class ApiToken extends Model
{
    // Evaluates is_active status of tokens
    protected static string $table = 'api_tokens';

    /**
     * FIX-18O (P1): توکن‌های هش‌شده (access/refresh) secrets هستند و با
     * toPublicArray() از خروجی عمومی حذف می‌شوند. واکشی خام (SELECT *،
     * findByHash و…) دست‌نخورده همه ستون‌ها را برمی‌گرداند — راستی‌آزمایی
     * توکن به آن‌ها نیاز دارد.
     * FIX-M11-L2: مسیرهای ادمین (findAllPaginated/findById) دیگر از SELECT * عبور
     * نمی‌کنند و به ADMIN_SAFE_COLUMNS محدود شدند (مرز DTO در خود کوئری).
     */
    protected array $hidden = ['token', 'refresh_token'];

    public const ALLOWED_SCOPES = [
        'read', 'write', 'admin', 'delete',
        'profile:read', 'profile:write', 
        'wallet:read', 'wallet:write', 
        'transactions:read', 'tasks:read', 'tasks:write',
        'security:read', 'security:write', 
        'settings:read', 'settings:write',
        // Scopes used by /api/v1 route middleware. Keep legacy colon scopes above
        // for backwards compatibility, but allow the actual route-level scopes too.
        'auth.manage',
        'user.read', 'user.write',
        'wallet.read', 'wallet.write',
        // FIX-M11-R22-13: اسکوپ‌های پرریسک از پوششِ سراسریِ write خارج شدند —
        // فقط تطبیقِ دقیق (یا «*») آن‌ها را اعطا می‌کند؛ هیچ hierarchy‌ای
        // (write/wallet.write/user.write) دیگر این دو را پوشش نمی‌دهد.
        'wallet.withdraw',
        'account.security',
        'social.read', 'social.write',
        'influencer.read', 'influencer.write',
        'verification.read', 'verification.write',
        'realtime',
        // 📱 FIX-MOBILE-04 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲): تسک‌های سئو
        // فقط مسیر وب داشتند؛ مسیرهای /api/v1/seo/* با این دو اسکوپ گیت می‌شوند
        // (هم‌الگوی social.read/social.write — پوشش‌پذیر با read/write سراسری).
        'seo.read', 'seo.write',
        // FIX-M11-M3 (گزارش ماژول ۱۱): wildcard «*» هم‌راستا شد — سرویس (ADMIN_SCOPES)
        // و middleware آن را می‌پذیرند ولی allowlist قبلی فاقدش بود ⇒ ادمین هرگز
        // نمی‌توانست توکن wildcard بسازد و قرارداد سه‌گانه بود. صدورش فقط برای
        // ادمین است (گیت createToken پایین + گیت سرویس) و به‌عنوان کمترین
        // امتیازِ صریحِ مدیریتی مستند شده است.
        '*'
    ];

    /**
     * FIX-M23-R1 (یادآوری ① تغییر breaking): متادیتای کاتالوگ اسکوپ‌ها —
     * منبعِ واحدِ حقیقت برای «GET /api/v1/auth/scopes» و مستندسازی قرارداد
     * پوشش برای کلاینت‌های موبایل.
     *
     * قراردادِ تغییر breaking (از راند ۲۲، بند ۱۳، پین‌شده):
     *   - «exact_only=true» یعنی هیچ سلسله‌مراتبی (write/read سراسری، wallet.write،
     *     user.write، قرارداد colon/dot) این اسکوپ را پوشش نمی‌دهد — فقط تطبیقِ
     *     دقیق یا «*» (ادمین). مبنای اعمال: ApiAuthMiddleware::EXACT_ONLY_SCOPES.
     *   - «covered_by» فقط توصیفِ پوششِ نرمال است؛ برای exact_only همیشه [].
     */
    public const SCOPE_METADATA = [
        'wallet.withdraw' => [
            'exact_only' => true,
            'risk' => 'high',
            'description' => 'ایجاد درخواست برداشت از کیف پول (POST /wallet/withdraw). تغییر breaking: توکن‌های write/wallet.write دیگر این عملیات را نمی‌پوشانند.',
        ],
        'account.security' => [
            'exact_only' => true,
            'risk' => 'high',
            'description' => 'غیرفعال‌سازی 2FA و درخواست حذف حساب. تغییر breaking: توکن‌های write/user.write دیگر این عملیات‌ها را نمی‌پوشانند.',
        ],
        // 📱 FIX-MOBILE-04: متادیتای اسکوپ‌های سئو برای کاتالوگ عمومی
        // /auth/scopes — استاندارد (پوشش‌پذیر با read/write سراسری؛ نه exact-only).
        'seo.read' => [
            'exact_only' => false,
            'risk' => 'standard',
            'description' => 'فهرست آگهی‌های سئو، وضعیت اجرا و تاریخچه (GET /api/v1/seo/*). با read سراسری هم پوشش داده می‌شود.',
        ],
        'seo.write' => [
            'exact_only' => false,
            'risk' => 'standard',
            'description' => 'شروع/تکمیل/لغو تسک سئو (POST /api/v1/seo/*). با write سراسری هم پوشش داده می‌شود.',
        ],
    ];

    /**
     * کاتالوگ ماشینی‌خوان برای کلاینت‌های موبایل
     *
     * FIX-PHPSTAN (بچ phpstan-2026-10-30): شکل دقیق — list ردیف‌های scope (نه نگاشت).
     *
     * @return list<array{scope: string, exact_only: bool, risk: string, description: string|null}>
     */
    public static function scopeCatalog(): array
    {
        $catalog = [];
        foreach (self::ALLOWED_SCOPES as $scope) {
            $meta = self::SCOPE_METADATA[$scope] ?? null;
            $catalog[] = [
                'scope' => $scope,
                'exact_only' => is_array($meta) ? (bool)$meta['exact_only'] : false,
                // FIX-PHPSTAN: SCOPE_METADATA همیشه risk/description دارد — دسترسی مستقیم
                'risk' => is_array($meta) ? str_value($meta['risk']) : 'standard',
                'description' => is_array($meta) ? (str_value($meta['description']) ?: null) : null,
            ];
        }
        return $catalog;
    }

    /**
     * FIX-M11-L2 (گزارش ماژول ۱۱): allowlist ستون‌های غیرحساس برای خروجی
     * ادمین/DTO — token و refresh_token هشِ HMAC اند (secret) و هرگز نباید
     * به لایهٔ view/API نشت کنند. واکشیِ خام at.* مرزِ secrets را نمی‌بست.
     */
    private const ADMIN_SAFE_COLUMNS = [
        'at.id', 'at.user_id', 'at.name', 'at.scopes',
        'at.revoked', 'at.revoked_at', 'at.revoke_reason',
        'at.expires_at', 'at.refresh_expires_at',
        'at.family_id', 'at.family_started_at', 'at.token_type',
        'at.secret_version', 'at.refresh_secret_version',
        'at.use_count', 'at.last_used_at', 'at.created_at',
    ];

    public function __construct(Database $db) {
        parent::__construct($db);
    }

    public function findById(int $id): ?\stdClass
    {
        $this->validateId($id);

        // FIX-M11-L2: ستون‌های حساس (token/refresh_token) از خروجی حذف شدند.
        $token = $this->db->fetch(
            "SELECT " . implode(', ', self::ADMIN_SAFE_COLUMNS) . ", u.full_name, u.email
             FROM api_tokens at
             LEFT JOIN users u ON u.id = at.user_id
             WHERE at.id = ?",
            [$id]
        );

        return $token ?: null;
    }

    /**
     * FIX-M11-H2/M2 (گزارش ماژول ۱۱): شرطِ کانونیِ وضعیت — وضعیت توکن ستونِ
     * فیزیکی نیست و از revoked + expires_at مشتق می‌شود. همهٔ مسیرهای فهرست/جستجو
     * باید از همین predicate استفاده کنند تا قرارداد یکدست باشد.
     *
     * @return array{0:string, 1:list<mixed>} [sql, params]
     */
    private static function statusPredicate(string $statusFilter): array
    {
        return match ($statusFilter) {
            'active' => ['at.revoked = 0 AND (at.expires_at IS NULL OR at.expires_at > NOW())', []],
            'revoked' => ['at.revoked = 1', []],
            'expired' => ['at.revoked = 0 AND at.expires_at IS NOT NULL AND at.expires_at < NOW()', []],
            default => ['', []],
        };
    }

    /**
     * FIX-M11-H2/M2: جستجوی کانونی — نام/ایمیل LIKE و اگر ورودی ۶۴-hex باشد
     * تطبیقِ exact با هشِ HMAC (هم‌قرارداد searchTokens سرویس).
     *
     * FIX-QA2-MULTIVER (بچ فاز-۲ سئو، ۲۰۲۶-۱۱-۰۲ — بستن مورد معوق جلسات قبل):
     * قبلاً فقط هشِ «نسخهٔ جاری» جست‌وجو می‌شد؛ توکن‌های هنوز-مهاجرت‌نکرده
     * (هش‌شده با راز نسخهٔ دیگر تا اولین استفاده) با جست‌وجوی مقدار خام پیدا
     * نمی‌شدند — در حالی که مسیر اعتبارسنجی (findValidToken/refresh) همهٔ
     * نسخه‌ها را می‌پذیرد. حالا جست‌وجو هم‌قراردادِ اعتبارسنجی شد: تک‌تک
     * نسخه‌های security.api.secrets با جفتِ (token = هشِ آن نسخه AND
     * secret_version = همان نسخه) تطبیق داده می‌شوند؛ fallback قدیمی به
     * SECURITY_API_TOKEN_SECRET فقط وقتی هیچ نسخهٔ configی معتبری وجود ندارد.
     *
     * @return array{0:string, 1:list<mixed>}
     */
    private static function searchPredicate(string $search): array
    {
        $escaped = addcslashes(trim($search), '%_\\');
        $like = '%' . $escaped . '%';
        $sql = '(at.name LIKE ? OR u.email LIKE ?';
        $params = [$like, $like];
        if (preg_match('/^[a-f0-9]{64}$/i', trim($search))) {
            $secrets = config('security.api.secrets');
            $matchedAny = false;
            if (is_array($secrets)) {
                foreach ($secrets as $version => $apiSecret) {
                    if (!is_string($apiSecret) || strlen($apiSecret) < 32) {
                        continue;
                    }
                    $normVersion = normalize_secret_version((string)$version);
                    if ($normVersion === '') {
                        continue;
                    }
                    $sql .= ' OR (at.token = ? AND at.secret_version = ?)';
                    $params[] = hash_hmac('sha256', trim($search), $apiSecret);
                    $params[] = $normVersion;
                    $matchedAny = true;
                }
            }
            if (!$matchedAny) {
                $apiSecret = \defined('SECURITY_API_TOKEN_SECRET') ? (string) SECURITY_API_TOKEN_SECRET : '';
                if ($apiSecret !== '' && strlen($apiSecret) >= 32) {
                    $sql .= ' OR at.token = ?';
                    $params[] = hash_hmac('sha256', trim($search), $apiSecret);
                }
            }
        }
        $sql .= ')';
        return [$sql, $params];
    }

    /** @return list<object> */
    public function findAllPaginated(
        int $limit,
        int $offset,
        ?string $search = null,
        ?string $statusFilter = null
    ): array {
        $query = $this->db->table('api_tokens as at')
            ->leftJoin('users as u', 'u.id', '=', 'at.user_id');

        if ($search) {
            [$sql, $params] = self::searchPredicate($search);
            $query->whereRaw($sql, $params);
        }

        if ($statusFilter !== null && $statusFilter !== '') {
            [$sql, $params] = self::statusPredicate($statusFilter);
            if ($sql !== '') {
                $query->whereRaw($sql, $params);
            }
        }

        // FIX-M11-L2: SELECT کانونیِ بدونِ هش‌ها (به‌جای at.*).
        // نکته: QueryBuilder ستون‌ها را به‌صورت آرگومان‌های جدا می‌پذیرد (رشتهٔ
        // join‌شده یک شناسه واحد تلقی و توسط SafeExpression رد می‌شود).
        $results = $query->select(...array_merge(self::ADMIN_SAFE_COLUMNS, ['u.full_name', 'u.email']))
                         ->orderBy('at.created_at', 'DESC')
                         ->limit($limit)
                         ->offset($offset)
                         ->get();

        return $results ?: [];
    }

    public function countAll(?string $search = null, ?string $statusFilter = null): int
    {
        $query = $this->db->table('api_tokens as at')
            ->leftJoin('users as u', 'u.id', '=', 'at.user_id');

        if ($search) {
            [$sql, $params] = self::searchPredicate($search);
            $query->whereRaw($sql, $params);
        }

        if ($statusFilter !== null && $statusFilter !== '') {
            [$sql, $params] = self::statusPredicate($statusFilter);
            if ($sql !== '') {
                $query->whereRaw($sql, $params);
            }
        }

        return $query->count();
    }

    public function revokeById(int $id): bool
    {
        $this->validateId($id);

        // FIX-M11-H5 (گزارش ماژول ۱۱): قرارداد rowCount — قبلاً حتی برای id ناموجود
        // یا توکنِ ازقبل-باطل‌شده true برمی‌گشت (موفقیتِ کاذب + audit دروغین در
        // کنترلر). اکنون 0 ردیفِ تغییرکرده ⇒ false؛ تمایزِ already_revoked/not_found
        // در سرویس (revokeToken) انجام می‌شود.
        // FIX-M11-R22-2: ابطال از پنل ادمین — دلیلِ صریح ثبت می‌شود
        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW(), revoke_reason = 'admin_revoked' WHERE id = ? AND revoked = 0"
        );
        $stmt->execute([$id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * W4-E: تمدید عمر توکن — expires_at به مقدار جدید (الان + N روز، محاسبه در سرویس)
     * به‌روزرسانی می‌شود. فقط ردیف‌های غیرباطل (revoked=0) قابل تمدیدند؛ شرط در WHERE،
     * رقابت هم‌زمانِ revoke-در-برابر-renew را می‌بندد (rowCount=0 → تمدید ناموفق).
     */
    public function renewById(int $id, string $newExpiresAt): bool
    {
        $this->validateId($id);
        $this->validateDate($newExpiresAt, 'new_expires_at');

        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET expires_at = ? WHERE id = ? AND revoked = 0"
        );
        $stmt->execute([$newExpiresAt, $id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * Atomic Compare-And-Swap revocation for Refresh Token Rotation (Finding #5)
     */
    public function revokeByIdIfActive(int $id): bool
    {
        $this->validateId($id);

        // FIX-M11-R22-2: ابطالِ ناشی از چرخش RTR همیشه با دلیل «rotated» ثبت می‌شود —
        // امضای replayِ بعدیِ این ردیف دقیقاً همین دلیل است (تنها دلیلِ دلالت‌کننده بر سرقت).
        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW(), revoke_reason = 'rotated' WHERE id = ? AND revoked = 0"
        );
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

    /**
     * FIX-M11-R22-7: ابطالِ یک ردیف با دلیلِ صریح — نسخهٔ reason-awareِ
     * revokeByIdIfActive برای شاخهٔ SCOPES_NO_LONGER_ALLOWED (دلیل «rotated»
     * فقط برای چرخشِ واقعی RTR است؛ ابطالِ اسکوپ نباید امضای سرقت بسازد).
     */
    public function revokeByIdWithReason(int $id, string $reason): bool
    {
        $this->validateId($id);
        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW(), revoke_reason = ? WHERE id = ? AND revoked = 0"
        );
        $stmt->execute([$reason, $id]);
        return $stmt->rowCount() > 0;
    }

    /**
     * FIX-M11-R22-2: ابطالِ هدفمندِ «یک خانواده» (نسل RTR) — در replayِ refresh token،
     * فقط نسلِ همان توکن زنده است (خانوادهٔ آن)؛ بقیهٔ توکن‌های کاربر (پنل،
     * integrationهای مستقل، دستگاه‌های دیگر) نباید قربانی شوند.
     */
    public function revokeAllForFamily(string $familyId, string $reason = 'reuse_detected'): int
    {
        if ($familyId === '' || !preg_match('/^[a-f0-9-]{36}$/i', $familyId)) {
            return 0;
        }
        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW(), revoke_reason = ? WHERE family_id = ? AND revoked = 0"
        );
        $stmt->execute([$reason, $familyId]);
        return $stmt->rowCount();
    }

    /**
     * FIX-M11-R22-3: ابطالِ همهٔ توکن‌های کاربر با دلیلِ ثبت‌شده —
     * (password_reset / password_changed / role_change / admin_revoked …).
     */
    public function revokeAllForUserWithReason(int $userId, string $reason): int
    {
        $this->validateId($userId, 'user_id');
        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW(), revoke_reason = ? WHERE user_id = ? AND revoked = 0"
        );
        $stmt->execute([$reason, $userId]);
        return $stmt->rowCount();
    }

    /**
     * M-25: revoke every non-revoked token belonging to a user. Used for refresh-token-reuse
     * (theft) response — when a already-rotated refresh token is replayed we must kill the whole
     * family, not just the presented one, because the attacker likely holds a live descendant.
     * FIX-M11-R22-2: در مسیر reuse از revokeAllForFamily استفاده می‌شود (هدفمند)؛
     * این متد فقط برای پاسخ‌های سراسری (ریست رمز، بن) با دلیلِ صریح مانده است.
     */
    public function revokeAllForUser(int $userId, string $reason = 'reuse_detected'): int
    {
        $this->validateId($userId, 'user_id');
        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW(), revoke_reason = ? WHERE user_id = ? AND revoked = 0"
        );
        $stmt->execute([$reason, $userId]);
        return $stmt->rowCount();
    }

    /**
     * M-25: locate a token by its refresh token INCLUDING already-revoked / expired rows.
     * findByRefreshToken() intentionally filters revoked=0; this variant lets the service detect
     * replay of a previously-rotated (and therefore revoked) refresh token.
     */
    public function findAnyByRefreshToken(string $plainRefreshToken): ?\stdClass
    {
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        if (empty($secrets)) {
            $legacySecret = \defined('SECURITY_API_TOKEN_SECRET') ? SECURITY_API_TOKEN_SECRET : null;
            if ($legacySecret) {
                $secrets = ['v2' => $legacySecret];
            }
        }
        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) ? $currentVersionValue : 'v2';
        $orderedSecrets = [];
        if (isset($secrets[$currentVersion])) {
            $orderedSecrets[$currentVersion] = $secrets[$currentVersion];
        }
        foreach ((array)$secrets as $version => $secret) {
            if ($version !== $currentVersion) {
                $orderedSecrets[$version] = $secret;
            }
        }
        foreach ((array)$orderedSecrets as $version => $secret) {
            if (empty($secret) || strlen((string)$secret) < 32) {
                continue;
            }
            $hashedToken = hash_hmac('sha256', $plainRefreshToken, $secret);
            // FIX-M11-C1: هم‌قرارداد findByRefreshToken — ستون مستقلِ نسخهٔ refresh.
            $tokenRow = $this->db->fetch(
                "SELECT at.*, u.status as user_status, u.email, u.role
                 FROM api_tokens at
                 LEFT JOIN users u ON u.id = at.user_id
                 WHERE at.refresh_token = ? AND at.refresh_secret_version = ?
                 LIMIT 1",
                [$hashedToken, $version]
            );
            if ($tokenRow) {
                return (object)['row' => $tokenRow, 'hashed' => $hashedToken, 'version' => $version];
            }
        }
        return null;
    }

    public function revokeForUser(int $id, int $userId): bool
    {
        $this->validateId($id);
        $this->validateId($userId, 'user_id');

        // FIX-M11-R22-2: دلیلِ ابطالِ کاربر — در replay بعدی «سرقت» حساب نمی‌شود.
        $stmt = $this->db->prepare(
            "UPDATE api_tokens 
             SET revoked = 1, revoked_at = NOW(), revoke_reason = 'user_revoked' 
             WHERE id = ? AND user_id = ? AND revoked = 0"
        );
        $stmt->execute([$id, $userId]);
        return $stmt->rowCount() > 0;
    }

    public function revokeByHashForUser(string $plainToken, int $userId): bool
    {
        if (empty($plainToken)) {
            throw new \InvalidArgumentException('Token cannot be empty');
        }
        $this->validateId($userId, 'user_id');

        $details = $this->getHashedTokenDetails($plainToken);
        if (!$details) {
            return false;
        }

        // FIX-M11-R22-2: دلیلِ ابطالِ کاربر — در replay بعدی «سرقت» حساب نمی‌شود.
        $stmt = $this->db->prepare(
            "UPDATE api_tokens 
             SET revoked = 1, revoked_at = NOW(), revoke_reason = 'user_revoked' 
             WHERE token = ? AND secret_version = ? AND user_id = ? AND revoked = 0"
        );
        $stmt->execute([$details->hashed, $details->version, $userId]);
        return $stmt->rowCount() > 0;
    }

    /**
     * FIX-M11-R22-5/23: صدور با چرخهٔ عمر جداشدهٔ access/refresh + خانواده + نوع.
     *  - $expiresAt          انقضای access (برای توکن login کوتاه‌عمر؛ ۱ روز)
     *  - $refreshExpiresAt   انقضای مستقل refresh (۹۰ روز لغزان؛ برای personal NULL)
     *  - $familyId           شناسهٔ نسل RTR (personal → NULL/تک‌عضوی)
     *  - $familyStartedAt    لنگر سقف مطلق خانواده
     *  - $tokenType          «login» | «personal»
     *
     * FIX-M11-R22-6: سقف نام با mb_strlen سنجیده می‌شود (قبلاً strlen بایتی —
     * نام فارسیِ ۵۱+ کاراکتر = ۱۰۲+ بایت → InvalidArgumentException → 500).
     * سقف واحد ۸۰ کاراکتر با سرویس/validator/فرم هم‌تراز است؛ سرویس پیش از
     * اینجا با 422 TOKEN_NAME_TOO_LONG رد می‌کند (خطای 500 دیگر قابل وقوع نیست).
     */
    public function createToken(
        int $userId, 
        string $plainToken, 
        string $name, 
        string $scopes, 
        ?string $expiresAt,
        ?string $plainRefreshToken = null,
        ?string $refreshExpiresAt = null,
        ?string $familyId = null,
        ?string $familyStartedAt = null,
        string $tokenType = 'personal'
    ): int {
        $this->validateId($userId, 'user_id');

        if (empty($plainToken) || strlen((string)$plainToken) < 32) {
            throw new \InvalidArgumentException('Token too weak');
        }
        
        if (empty($name) || mb_strlen((string)$name) > 80) {
            throw new \InvalidArgumentException('Invalid token name');
        }
        
        $userRow = $this->db->fetch("SELECT role FROM users WHERE id = ?", [$userId]);
        $isAdminUser = in_array($userRow->role ?? '', ['admin', 'super_admin'], true);

        $scopesArray = explode(',', $scopes);
        foreach ($scopesArray as $scope) {
            $trimmed = trim((string)$scope);
            if (!in_array($trimmed, self::ALLOWED_SCOPES, true)) {
                throw new \InvalidArgumentException("Invalid scope: {$scope}");
            }
            // FIX-M11-M3: wildcard «*» هم مثل «admin» فقط برای ادمین — گیتِ مدل
            // (دفاع در عمق؛ گیت اصلی در سرویس validateAndFilterScopes است).
            if (($trimmed === 'admin' || $trimmed === '*') && !$isAdminUser) {
                throw new \InvalidArgumentException("Normal user cannot create API token with admin scope.");
            }
        }

        if ($expiresAt !== null) {
            $this->validateDate($expiresAt, 'expires_at');
        }

        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) ? $currentVersionValue : 'v2';
        $secret = config("security.api.secrets.{$currentVersion}");
        if (empty($secret)) {
            $secret = \defined('SECURITY_API_TOKEN_SECRET') ? SECURITY_API_TOKEN_SECRET : null;
        }
        
        if (!$secret || strlen((string)$secret) < 32) {
            throw new \RuntimeException('API secret key is not configured or too weak (minimum 32 characters required)');
        }
        
        $hashedToken = hash_hmac('sha256', $plainToken, $secret);
        $hashedRefreshToken = $plainRefreshToken ? hash_hmac('sha256', $plainRefreshToken, $secret) : null;

        // FIX-M11-C1: در لحظهٔ صدور، access و refresh هر دو با همان secret جاری
        // هش می‌شوند — نسخهٔ refresh به‌طور مستقل ثبت می‌شود تا چرخشِ بعدیِ access
        // هرگز refresh را یتیم نکند (قرارداد نسخهٔ جدا برای هر هش).
        // FIX-M11-R22-5: refresh بدون $plainRefreshToken هش نمی‌شود و ستونش NULL می‌ماند
        // (توکن personal پنل قابلیت refresh ندارد — همان قرارداد /auth/revoke).
        if ($refreshExpiresAt !== null) {
            $this->validateDate($refreshExpiresAt, 'refresh_expires_at');
        }
        if ($familyStartedAt !== null) {
            $this->validateDate($familyStartedAt, 'family_started_at');
        }
        if (!in_array($tokenType, ['login', 'personal'], true)) {
            $tokenType = 'personal';
        }
        $this->db->query(
            "INSERT INTO api_tokens (user_id, token, refresh_token, secret_version, refresh_secret_version, name, scopes, expires_at, refresh_expires_at, family_id, family_started_at, token_type, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())",
            [$userId, $hashedToken, $hashedRefreshToken, $currentVersion, $currentVersion, $name, $scopes, $expiresAt, $refreshExpiresAt, $familyId, $familyStartedAt, $tokenType]
        );

        return (int)$this->db->lastInsertId();
    }

    public function findByRefreshToken(string $plainRefreshToken): ?\stdClass
    {
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        if (empty($secrets)) {
            $legacySecret = \defined('SECURITY_API_TOKEN_SECRET') ? SECURITY_API_TOKEN_SECRET : null;
            if ($legacySecret) {
                $secrets = ['v2' => $legacySecret];
            }
        }

        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) ? $currentVersionValue : 'v2';
        
        $orderedSecrets = [];
        if (isset($secrets[$currentVersion])) {
            $orderedSecrets[$currentVersion] = $secrets[$currentVersion];
        }
        foreach ((array)$secrets as $version => $secret) {
            if ($version !== $currentVersion) {
                $orderedSecrets[$version] = $secret;
            }
        }

        foreach ((array)$orderedSecrets as $version => $secret) {
            if (empty($secret) || strlen((string)$secret) < 32) {
                continue;
            }

            $hashedToken = hash_hmac('sha256', $plainRefreshToken, $secret);
            
            // FIX-M11-C1: تطبیق با «نسخهٔ secret هشِ refresh» (ستون مستقل) — نه
            // secret_version ردیف که چرخش access آن را جلو می‌برد.
            // FIX-M11-R22-5: گیتِ اعتبارِ refresh با «پنجرهٔ مستقل refresh» سنجیده
            // می‌شود، نه expires_at مشترک — COALESCE(refresh_expires_at, expires_at)
            // ردیف‌های pre-migration را هم با رفتار قدیمی پوشش می‌دهد.
            $sql = "SELECT at.*, u.status as user_status, u.email, u.role, u.email_verified_at 
                 FROM api_tokens at
                 LEFT JOIN users u ON u.id = at.user_id
                 WHERE at.refresh_token = ?
                   AND at.refresh_secret_version = ?
                   AND at.revoked = 0
                   AND (COALESCE(at.refresh_expires_at, at.expires_at) IS NULL OR COALESCE(at.refresh_expires_at, at.expires_at) > NOW())";
            $params = [$hashedToken, $version];

            // FIX-M11-TOK-03 (گزارش دوم ماژول ۱۱): retirement نسخهٔ secret در مسیر
            // refresh هم enforce می‌شود — ستون در schema موجود بود ولی فقط Bearer
            // middleware آن را می‌سنجید؛ refresh می‌توانست جفتِ تازه با نسخهٔ
            // بازنشسته بسازد و حکم اضطراریِ retirement را بی‌اثر می‌کرد. گاردِ
            // پروب ستون سازگاری با استقرارهای قدیمی‌تر را نگه می‌دارد.
            if (self::secretVersionExpiryColumnExists($this->db)) {
                $sql .= " AND (at.secret_version_expires_at IS NULL OR at.secret_version_expires_at > NOW())";
            }
            $sql .= " LIMIT 1";

            $tokenRow = $this->db->fetch($sql, $params);

            if ($tokenRow) {
                return (object)[
                    'row' => $tokenRow,
                    'hashed' => $hashedToken,
                    'version' => $version
                ];
            }
        }

        return null;
    }

    /**
     * FIX-M11-TOK-03: پروب یک‌بارهٔ وجود ستون secret_version_expires_at
     * (همان قرارداد گارد ApiAuthMiddleware::isSecretVersionExpirySupported).
     */
    private static ?bool $secretVersionExpiryCol = null;

    private static function secretVersionExpiryColumnExists(Database $db): bool
    {
        if (self::$secretVersionExpiryCol !== null) {
            return self::$secretVersionExpiryCol;
        }
        try {
            $row = $db->fetch("SHOW COLUMNS FROM api_tokens LIKE 'secret_version_expires_at'");
            self::$secretVersionExpiryCol = (bool)$row;
        } catch (\Throwable) {
            self::$secretVersionExpiryCol = false;
        }
        return self::$secretVersionExpiryCol;
    }

    /**
     * @return array<object>
     */
    public function findByUserId(int $userId): array
    {
        $this->validateId($userId);

        $results = $this->db->fetchAll(
            "SELECT id, name, scopes, last_used_at, use_count, expires_at, created_at
             FROM api_tokens
             WHERE user_id = ? AND revoked = 0
             ORDER BY created_at DESC",
            [$userId]
        );

        return $results ?: [];
    }

    public function countActiveByUserId(int $userId): int
    {
        $this->validateId($userId);

        // 🛡️ FIX-CH16: شمارش «فعال» با expires_at هم‌راستا شد — قبلاً توکن‌های
        // منقضیِ revokeنشده هم در سقف ۱۰ حساب می‌شدند و کاربر تا اجرای cleanup
        // نمی‌توانست توکن تازه بسازد؛ اعتبارسنجی واقعی (findByRefreshToken)
        // expiry را می‌سنجد، پس شمارنده هم باید همان قرارداد را داشته باشد.
        $count = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens
             WHERE user_id = ? AND revoked = 0
               AND (expires_at IS NULL OR expires_at > NOW())",
            [$userId]
        );

        if (!$count) {
            return 0;
        }

        return $this->scalarCount($count);
    }

    /**
     * FIX-M11-M1 (گزارش ماژول ۱۱): همان قرارداد countActiveByUserId ولی با
     * FOR UPDATE — فقط «داخل تراکنش» معنا دارد و قفلِ رنجِ ایندکس user_id را
     * می‌گیرد تا شمارشِ سقف ۱۰ در برابر درجِ هم‌زمان اتمیک بماند.
     */
    public function countActiveByUserIdForUpdate(int $userId): int
    {
        $this->validateId($userId);

        $count = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens
             WHERE user_id = ? AND revoked = 0
               AND (expires_at IS NULL OR expires_at > NOW())
             FOR UPDATE",
            [$userId]
        );

        if (!$count) {
            return 0;
        }

        return $this->scalarCount($count);
    }

    public function revokeByHash(string $plainToken): bool
    {
        if (empty($plainToken)) {
            throw new \InvalidArgumentException('Token cannot be empty');
        }

        $details = $this->getHashedTokenDetails($plainToken);
        if (!$details) {
            return false;
        }

        $stmt = $this->db->prepare(
            "UPDATE api_tokens SET revoked = 1, revoked_at = NOW() WHERE token = ? AND secret_version = ?"
        );
        $stmt->execute([$details->hashed, $details->version]);

        // FIX-R19-A7-4: real rowCount semantics (aligned with revokeByIdIfActive) —
        // 0 matched rows (unknown token or already revoked) must not report success.
        return $stmt->rowCount() > 0;
    }

    public function findByHash(string $plainToken): ?\stdClass
    {
        if (empty($plainToken)) {
            throw new \InvalidArgumentException('Token cannot be empty');
        }

        $details = $this->getHashedTokenDetails($plainToken);
        return $details ? $details->row : null;
    }

    /**
     * Helper to lookup hashed token details iteratively over active secret versions
     */
    /** @return \stdClass|null */
    private function getHashedTokenDetails(string $plainToken): ?\stdClass
    {
        $secretsValue = config('security.api.secrets', []);
        $secrets = is_array($secretsValue) ? $secretsValue : [];
        if (empty($secrets)) {
            $legacySecret = \defined('SECURITY_API_TOKEN_SECRET') ? SECURITY_API_TOKEN_SECRET : null;
            if ($legacySecret) {
                $secrets = ['v2' => $legacySecret];
            }
        }

        $currentVersionValue = config('security.api.current_secret_version', 'v2');
        $currentVersion = is_string($currentVersionValue) ? $currentVersionValue : 'v2';
        
        $orderedSecrets = [];
        if (isset($secrets[$currentVersion])) {
            $orderedSecrets[$currentVersion] = $secrets[$currentVersion];
        }
        foreach ((array)$secrets as $version => $secret) {
            if ($version !== $currentVersion) {
                $orderedSecrets[$version] = $secret;
            }
        }

        foreach ((array)$orderedSecrets as $version => $secret) {
            if (empty($secret) || strlen((string)$secret) < 32) {
                continue;
            }

            $hashedToken = hash_hmac('sha256', $plainToken, $secret);
            
            // Check if this hash and version exists in database
            $tokenRow = $this->db->fetch(
                "SELECT * FROM api_tokens WHERE token = ? AND secret_version = ? LIMIT 1",
                [$hashedToken, $version]
            );

            if ($tokenRow) {
                return (object)[
                    'row' => $tokenRow,
                    'hashed' => $hashedToken,
                    'version' => $version
                ];
            }
        }

        return null;
    }

    public function revokeAllExpired(): int
    {
        // FIX-M11-R22-19: cleanup منقضی‌ها دیگر «باطلِ بی‌دلیل» نیست —
        // دلیلِ expired_cleanup ثبت می‌شود تا (۱) در replay بعدی به‌عنوان سرقت
        // تشخیص داده نشود (FIX-M11-R22-2)، (۲) آمار ادمین بتواند تفکیک کند.
        // قرارداد renew (صریح‌شده): توکنِ منقضی/پاکسازی‌شده قابل تمدید نیست؛
        // کلاینت باید دوباره احراز هویت کند (ApiTokenService::renewToken).
        $stmt = $this->db->prepare(
            "UPDATE api_tokens 
             SET revoked = 1, revoked_at = NOW(), revoke_reason = 'expired_cleanup' 
             WHERE revoked = 0 AND expires_at IS NOT NULL AND expires_at < NOW()"
        );
        $stmt->execute();
        return (int)$stmt->rowCount();
    }

    private function scalarCount(mixed $row): int
    {
        if (is_object($row)) {
            $vars = get_object_vars($row);
            return is_numeric($vars['count'] ?? null) ? (int)$vars['count'] : 0;
        }
        if (is_array($row)) {
            return is_numeric($row['count'] ?? null) ? (int)$row['count'] : 0;
        }
        return 0;
    }

    /** @return array<string, int> */
    public function getStats(): array
    {
        $activeCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens 
             WHERE revoked = 0 AND (expires_at IS NULL OR expires_at > NOW())"
        );

        $revokedCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens WHERE revoked = 1"
        );

        $expiredCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens 
             WHERE revoked = 0 AND expires_at IS NOT NULL AND expires_at < NOW()"
        );

        $usedTodayCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM api_tokens WHERE DATE(last_used_at) = CURDATE()"
        );

        $active = $this->scalarCount($activeCount);
        $revoked = $this->scalarCount($revokedCount);
        $expired = $this->scalarCount($expiredCount);
        $usedToday = $this->scalarCount($usedTodayCount);

        return [
            'active' => (int)$active,
            'revoked' => (int)$revoked,
            'expired' => (int)$expired,
            'used_today' => (int)$usedToday,
        ];
    }

    // ══ FIX-SECRETROT-4 (بازگردانی آشتی بچ‌ها — ۲۰۲۶-۱۱-۰۳): بلوک عین بچ V2CLEAN ══
    /**
     * 🛡️ FIX-SECRETROT-4 (باقی‌ماندهٔ چرخش — توکن‌های هرگز-استفاده‌نشده):
     * آمار چرخش رمز به تفکیک نسخه، برای ممیزی و تصمیمِ بازنشستگیِ رمز قدیمی.
     *
     * چرا؟ مهاجرتِ توکنِ نسخهٔ قدیمی «در اولین استفاده» رخ می‌دهد
     * (ApiAuthMiddleware::validateTokenWithRotation) — توکن‌هایی که هرگز
     * استفاده نشوند برای همیشه روی برچسب قدیمی می‌مانند و تا وقتی رمزِ آن
     * نسخه در config حاضر است معتبر می‌مانند (هیچ مهاجرت پس‌زمینه‌ای وجود
     * ندارد). این متد تصویر کاملِ وابستگیِ جدول به نسخه‌های رمز را می‌دهد.
     *
     * قرارداد خروجی:
     *  - access[نسخه]: total = همهٔ ردیف‌ها؛ live = revoked=0؛
     *    live_never_used = فعالِ بدون last_used_at (هرگز استفاده نشده —
     *    کاندیدای اصلی پاکسازی)؛ live_used_before = فعالِ با last_used_at
     *    (خفته از قبلِ چرخش)؛ live_expired = فعال ولی منقضی؛
     *    live_with_refresh = فعالِ دارای refresh_token.
     *  - refresh[نسخه]: تعداد ردیف‌های «فعالِ دارای refresh» که refresh آن‌ها
     *    به آن نسخهٔ رمز وابسته است (حذف رمزِ آن نسخه، refresh همین ردیف‌ها
     *    را باطل می‌کند — قرارداد FIX-M11-C1: نسخهٔ refresh مستقل است).
     *  - کلید '' یعنی ستون NULL در DB (ردیف‌های پیش از ستون‌دار‌شدن؛ سخت‌گیرانه
     *    «یتیم» در نظر گرفته می‌شوند چون validation با secret_version = ? آن‌ها را نمی‌یابد).
     *
     * نکتهٔ PHP: برچسب‌های عددی (مثل «1» باگ pre-SECRETROT) به‌عنوان کلید آرایه
     * به int تبدیل می‌شوند (رفتار ذاتی PHP) — به همین دلیل نوع کلید int|string است؛
     * مصرف‌کننده باید برچسب را با str_value نرمال کند.
     *
     * @return array{
     *     access: array<int|string, array{total: int, live: int, live_never_used: int, live_used_before: int, live_expired: int, live_with_refresh: int}>,
     *     refresh: array<int|string, int>
     * }
     */
    public function getSecretVersionRotationStats(): array
    {
        $accessRows = $this->db->fetchAll(
            "SELECT COALESCE(secret_version, '') AS version_label,
                    COUNT(*) AS total_rows,
                    SUM(revoked = 0) AS live_rows,
                    SUM(revoked = 0 AND last_used_at IS NULL) AS live_never_used,
                    SUM(revoked = 0 AND last_used_at IS NOT NULL) AS live_used_before,
                    SUM(revoked = 0 AND expires_at IS NOT NULL AND expires_at <= NOW()) AS live_expired,
                    SUM(revoked = 0 AND refresh_token IS NOT NULL) AS live_with_refresh
             FROM api_tokens
             GROUP BY COALESCE(secret_version, '')"
        );

        $access = [];
        foreach ($accessRows as $row) {
            $label = str_value($row->version_label ?? '');
            $access[$label] = [
                'total' => int_value($row->total_rows ?? 0),
                'live' => int_value($row->live_rows ?? 0),
                'live_never_used' => int_value($row->live_never_used ?? 0),
                'live_used_before' => int_value($row->live_used_before ?? 0),
                'live_expired' => int_value($row->live_expired ?? 0),
                'live_with_refresh' => int_value($row->live_with_refresh ?? 0),
            ];
        }

        $refreshRows = $this->db->fetchAll(
            "SELECT COALESCE(refresh_secret_version, '') AS version_label,
                    COUNT(*) AS live_refresh_rows
             FROM api_tokens
             WHERE revoked = 0 AND refresh_token IS NOT NULL
             GROUP BY COALESCE(refresh_secret_version, '')"
        );

        $refresh = [];
        foreach ($refreshRows as $row) {
            $refresh[str_value($row->version_label ?? '')] = int_value($row->live_refresh_rows ?? 0);
        }

        return ['access' => $access, 'refresh' => $refresh];
    }

    /**
     * 🛡️ FIX-SECRETROT-4: لیست ردیف‌های «فعالِ نسخهٔ کهنه» برای نمایش dry-run/--list.
     *
     * @param list<int|string> $versions برچسب‌های نسخهٔ هدف (هرگز شامل نسخهٔ جاری نباید باشد؛ '' یعنی ستون NULL)
     * @param 'never_used'|'used'|'all' $usageFilter
     * @return list<\stdClass>
     */
    public function listStaleSecretVersionRows(array $versions, string $usageFilter, int $limit): array
    {
        $labels = self::staleVersionLabels($versions);
        $placeholders = implode(',', array_fill(0, count($labels), '?'));
        $usageSql = self::usagePredicateSql($usageFilter);

        return $this->db->fetchAll(
            "SELECT at.id, at.user_id, u.username, at.name, at.token_type,
                    at.secret_version, at.refresh_secret_version,
                    at.last_used_at, at.use_count, at.expires_at, at.created_at,
                    (at.refresh_token IS NOT NULL) AS has_refresh
             FROM api_tokens at
             LEFT JOIN users u ON u.id = at.user_id
             WHERE at.revoked = 0
               AND (at.secret_version IN ({$placeholders})" . self::nullVersionClauseSql($versions) . ")
               {$usageSql}
             ORDER BY at.created_at ASC, at.id ASC
             LIMIT " . max(1, $limit),
            $labels
        );
    }

    /**
     * 🛡️ FIX-SECRETROT-4: ابطالِ یک‌جای ردیف‌های «فعالِ نسخهٔ کهنه» — تنها اهرم
     * واقعی برای خالی‌کردن وابستگیِ رمز قدیمی، چون توکن خام هرگز ذخیره نمی‌شود
     * (فقط HMAC-SHA256 هش‌شده با رمزِ همان نسخه در DB هست) و «بازهاش» به رمز
     * جدید بدون توکنِ خام ناممکن است. ابطال با دلیلِ صریح ثبت می‌شود تا در
     * replay بعدی امضای سرقت نسازد (هم‌قرارداد FIX-M11-R22-2 با expired_cleanup).
     *
     * @param list<int|string> $versions برچسب‌های نسخهٔ هدف (هرگز شامل نسخهٔ جاری نباید باشد)
     * @param 'never_used'|'used'|'all' $usageFilter
     *        never_used = فقط ردیف‌های بدون last_used_at (هرگز استفاده نشده)
     *        used = فقط ردیف‌های با last_used_at (خفته از قبلِ چرخش)
     *        all = هر دو
     * @return int تعداد ردیف‌های ابطال‌شده (rowCount — قرارداد FIX-M11-H5)
     */
    public function revokeByStaleSecretVersion(array $versions, string $reason, string $usageFilter = 'all'): int
    {
        $labels = self::staleVersionLabels($versions);
        $placeholders = implode(',', array_fill(0, count($labels), '?'));
        $usageSql = self::usagePredicateSql($usageFilter);

        $stmt = $this->db->prepare(
            "UPDATE api_tokens
             SET revoked = 1, revoked_at = NOW(), revoke_reason = ?
             WHERE revoked = 0
               AND (secret_version IN ({$placeholders})" . self::nullVersionClauseSql($versions) . ")
               {$usageSql}"
        );
        $stmt->execute(array_merge([$reason], $labels));

        return (int)$stmt->rowCount();
    }

    /**
     * @param list<int|string> $versions
     * @return list<string> برچسب‌های یکتا و اعتبارسنجی‌شده برای IN (...) —
     *         برچسب‌ها از GROUP BY خود DB می‌آیند ولی دفاع در عمق: هر برچسب باید
     *         alnum/حروف نسخه باشد و طول ستون VARCHAR(20) را رعایت کند؛
     *         برچسب '' مجاز است (نشانگر ستون NULL — با شرط IS NULL همراه می‌شود)
     */
    private static function staleVersionLabels(array $versions): array
    {
        $clean = [];
        foreach ($versions as $version) {
            $label = str_value($version);
            if ($label !== '' && (strlen($label) > 20 || preg_match('/^[A-Za-z0-9_.-]+$/', $label) !== 1)) {
                throw new \InvalidArgumentException('Invalid secret version label: ' . var_export($version, true));
            }
            $clean[] = $label;
        }
        $unique = array_values(array_unique($clean));
        if ($unique === []) {
            throw new \InvalidArgumentException('At least one secret version label is required.');
        }
        return $unique;
    }

    /** @return 'never_used'|'used'|'all' اعتبارسنجیٔ مقدار فیلتر استفاده */
    private static function normalizeUsageFilter(string $usageFilter): string
    {
        if (!in_array($usageFilter, ['never_used', 'used', 'all'], true)) {
            throw new \InvalidArgumentException("Invalid usage filter: {$usageFilter}");
        }
        return $usageFilter;
    }

    /** @param 'never_used'|'used'|'all' $usageFilter */
    private static function usagePredicateSql(string $usageFilter): string
    {
        return match (self::normalizeUsageFilter($usageFilter)) {
            'never_used' => 'AND last_used_at IS NULL',
            'used' => 'AND last_used_at IS NOT NULL',
            default => '',
        };
    }

    /**
     * اگر برچسب خالی ('' = ستون NULL) در فهرست نسخه‌ها باشد، شرط IS NULL هم
     * لازم است — IN ('') ردیف‌های NULL را نمی‌گیرد (مقایسهٔ SQL با NULL).
     *
     * @param list<int|string> $versions
     */
    private static function nullVersionClauseSql(array $versions): string
    {
        return in_array('', array_map('str_value', $versions), true) ? ' OR secret_version IS NULL' : '';
    }
}
