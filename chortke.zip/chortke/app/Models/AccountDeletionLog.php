<?php

namespace App\Models;

use Core\Database;
use Core\Model;

/**
 * AccountDeletionLog Model - Secured against SQL Injection and Race Conditions
 */
class AccountDeletionLog extends Model
{
    protected static string $table = 'account_deletion_logs';
    protected array $fillable = [
        'user_id',
        'status',
        'requested_at',
        'expires_at',
        'deleted_at',
        'reason',
        'deleted_by'
    ];
    protected bool $timestamps = false;

    /**
     * دریافت درخواست‌های حذف
     */
    public function getUserDeletionRequest(int $userId): ?\stdClass
    {
        $row = $this->db->fetch(
            "SELECT * FROM `account_deletion_logs` WHERE user_id = ? AND status IN ('requested', 'cancelled') ORDER BY requested_at DESC LIMIT 1",
            [$userId]
        );
        return $row ?: null;
    }

    /**
     * دریافت درخواست‌های حذف منقضی‌شده
     */
    /** @return list<object> */
    public function getExpiredDeletionRequests(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM `account_deletion_logs` WHERE status = 'requested' AND expires_at < NOW()"
        ) ?: [];
    }

    /**
     * دریافت درخواست‌های حذف معلق
     */
    /** @return list<object> */
    /**
     * FIX-CMD169 (یافتهٔ ۱۶۹): صفحه‌بندی اجباری — قبلاً کل جدول بدون LIMIT فچ
     * می‌شد و با رشد درخواست‌های حذف، peak حافظه و رندر بی‌سقف می‌شد.
     */
    public function getPendingDeletions(int $limit = 200, int $offset = 0): array
    {
        $limit = max(1, min(500, $limit));
        $offset = max(0, $offset);
        return $this->db->fetchAll(
            "SELECT d.id, d.user_id, d.status, d.requested_at, d.expires_at, u.username, u.email FROM `account_deletion_logs` d
             JOIN users u ON d.user_id = u.id
             WHERE d.status = 'requested'
             ORDER BY d.expires_at ASC
             LIMIT $limit OFFSET $offset"
        ) ?: [];
    }

    /** FIX-CMD169: شمارش دقیق برای total_count بدون فچ ردیف‌ها */
    public function countPendingDeletions(): int
    {
        return (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM `account_deletion_logs` WHERE status = 'requested'"
        );
    }

    /**
     * S7-FIX (UI-DEL-002): شمارش دقیق حساب‌های حذف‌شده برای total_count/stats —
     * قبلاً stats فقط count(getDeletedAccounts(500)) داشت و جمعیتِ بالای سقفِ ۵۰۰
     * نامرئی بود. اکنون COUNT(*) مستقل.
     */
    public function countDeletedAccounts(): int
    {
        return (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM `account_deletion_logs` WHERE status = 'deleted'"
        );
    }

    /**
     * S7-FIX (UI-DEL-002): شمارش دقیق «به‌زودی منقضی» (۰ تا ۲۴ ساعت آینده) در SQL —
     * جایگزین فیلتر PHP روی نمونهٔ سقف‌دار ۵۰۰ ردیفی؛ timezone مرجع همان timezone
     * سشن DB است (همان منبعی که expires_at با DATE_ADD در آن نوشته می‌شود).
     */
    public function countExpiringSoon(): int
    {
        return (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM `account_deletion_logs`
             WHERE status = 'requested'
               AND expires_at IS NOT NULL
               AND expires_at >= NOW()
               AND expires_at <= DATE_ADD(NOW(), INTERVAL 24 HOUR)"
        );
    }

    /**
     * دریافت حساب‌های حذف‌شده
     */
    /** @return list<object> */
    public function getDeletedAccounts(int $limit = 100, int $offset = 0): array
    {
        // S7-FIX (UI-DEL-003): join جداگانهٔ actor — قبلاً فقط users بر اساس d.user_id
        // (کاربرِ هدف) join می‌شد و view «حذف توسط» را هم با usernameِ همان هدف پر
        // می‌کرد؛ deleted_by هرگز render نمی‌شد و ردپای حسابرسی به شخص نادرست منسوب
        // می‌شد. اکنون actor username از join مستقل (deleted_by) می‌آید؛ actor سیستمی
        // (deleted_by = 0 یا NULL) بدون username → view برچسب «سیستم» می‌گذارد.
        return $this->db->fetchAll(
            "SELECT d.id, d.user_id, d.status, d.requested_at, d.deleted_at, d.deleted_by, d.reason,
                    u.username, u.email, u.deleted_at AS user_deleted_at,
                    actor.username AS deleted_by_username
             FROM `account_deletion_logs` d
             LEFT JOIN users u ON d.user_id = u.id
             LEFT JOIN users actor ON actor.id = d.deleted_by
             WHERE d.status = 'deleted'
             ORDER BY d.deleted_at DESC LIMIT ? OFFSET ?",
            [$limit, $offset]
        ) ?: [];
    }

    /**
     * ایجاد درخواست حذف جدید با محافظ تراکنش و قفل ایمن جهت جلوگیری از Race Condition
     */
    public function createDeletionRequest(int $userId, ?string $reason = null): int
    {
        $this->db->beginTransaction();
        try {
            $lastId = $this->createDeletionRequestInTx($userId, $reason);
            $this->db->commit();
            return $lastId;
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    /**
     * S7-FIX (DEL-001): گونهٔ هم‌ترازِ تراکنشِ محیطی — بدون beginTransaction/commit
     * خودمختار. قرارداد: caller باید درون تراکنش باشد؛ INSERT و UPDATE هم‌زمانِ
     * users (هم‌ترازسازی فلگ‌های کاربر) در «یک» تراکنش اتمیک commit/rollback می‌شوند.
     * قبلاً لاگِ requested جدا commit می‌شد و شکستِ UPDATE users بعدی، کاربر را
     * «ناموفق» نشان می‌داد درحالی‌که کرون درخواستِ زندهٔ حذف را در انتظار داشت.
     */
    public function createDeletionRequestInTx(int $userId, ?string $reason = null): int
    {
        // قفل انحصاری جهت جلوگیری از ثبت درخواست تکراری همزمان
        $existing = $this->db->fetch(
            "SELECT id FROM `account_deletion_logs` WHERE user_id = ? AND status = 'requested' FOR UPDATE",
            [$userId]
        );

        if ($existing) {
            throw new \RuntimeException('Deletion request already exists');
        }

        // L-27 Fix: مهلت حذف از یک منبع واحد config خوانده می‌شود تا با سایر مسیرها ناسازگار نباشد.
        $graceDays = max(1, int_value(config('account.deletion_grace_days', 7)));
        try {
            $this->db->query(
                "INSERT INTO `account_deletion_logs` (user_id, status, requested_at, expires_at, reason)
                 VALUES (?, 'requested', NOW(), DATE_ADD(NOW(), INTERVAL ? DAY), ?)",
                [$userId, $graceDays, $reason]
            );
        } catch (\PDOException $dup) {
            // S7-FIX (DEL-003): حصار یکتای دیتابیسی (uq_adl_active_request) — رقابت
            // هم‌زمان دو connector بدون ردیفِ قبلی را 1062 می‌گیرد؛ همان قراردادِ
            // «درخواست تکراری» RuntimeException بالادستی حفظ می‌شود.
            $isDup = ((string)$dup->getCode() === '23000')
                || (isset($dup->errorInfo[1]) && (int)$dup->errorInfo[1] === 1062);
            if ($isDup) {
                throw new \RuntimeException('Deletion request already exists', 0, $dup);
            }
            throw $dup;
        }

        return (int)$this->db->lastInsertId();
    }

    /**
     * لغو درخواست حذف
     */
    public function cancelDeletionRequest(int $userId): bool
    {
        return $this->db->execute(
            "UPDATE `account_deletion_logs` SET status = 'cancelled' WHERE user_id = ? AND status = 'requested'",
            [$userId]
        ) > 0;
    }

    /**
     * ثبت حذف حساب
     */
    public function recordDeletion(int $userId, ?int $deletedBy = null, ?string $reason = null): bool
    {
        // S7-FIX (DEL-002): ساگا ابتدا درخواست را داخل تراکنش به 'processing' claim
        // می‌کند؛ ثبتِ نهایی حذف باید همان claim را بپذیرد ('requested' برای سازگاری
        // مسیرهای بدون claim حفظ شد). صفر ردیف = باختِ رقابت و در ساگا rollback کامل است.
        return $this->db->execute(
            "UPDATE `account_deletion_logs` SET status = 'deleted', deleted_at = NOW(), deleted_by = ?, reason = ?
             WHERE user_id = ? AND status IN ('requested', 'processing')",
            [$deletedBy, $reason, $userId]
        ) > 0;
    }

    /**
     * دریافت تاریخچه حذف‌ها برای ادمین
     */
    /** @return list<object> */
    public function getDeletionHistory(int $limit = 50, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT d.*, u.username FROM `account_deletion_logs` d
             LEFT JOIN users u ON d.deleted_by = u.id
             ORDER BY d.requested_at DESC LIMIT ? OFFSET ?",
            [$limit, $offset]
        ) ?: [];
    }
}
