<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * IdempotencyKey Model
 * 
 * جدول: idempotency_keys
 */
class IdempotencyKey extends Model
{
    protected static string $table = 'idempotency_keys';

    public const STATUS_PENDING   = 'pending';
    public const STATUS_COMPLETED = 'completed';
    public const STATUS_FAILED    = 'failed';

    /**
     * Find an existing idempotency key.
     */
    public function findByKey(string $key): ?object
    {
        return $this->db->fetch(
            "SELECT * FROM idempotency_keys WHERE `key` = ? LIMIT 1",
            [$key]
        );
    }

    /**
     * Store a new idempotency key.
     */
    public function createKey(string $key, int $userId, string $action, array $requestData = []): bool
    {
        return (bool) $this->db->execute(
            "INSERT INTO idempotency_keys (`key`, user_id, action, status, request_data, created_at) 
             VALUES (?, ?, ?, ?, ?, NOW())",
            [$key, $userId, $action, self::STATUS_PENDING, json_encode($requestData, JSON_UNESCAPED_UNICODE)]
        );
    }

    /**
     * Mark a key as completed with result.
     */
    public function markCompleted(string $key, string $result = ''): bool
    {
        return (bool) $this->db->execute(
            "UPDATE idempotency_keys SET status = ?, result = ? WHERE `key` = ?",
            [self::STATUS_COMPLETED, $result, $key]
        );
    }

    /**
     * Mark a key as failed.
     */
    public function markFailed(string $key, string $error = ''): bool
    {
        return (bool) $this->db->execute(
            "UPDATE idempotency_keys SET status = ?, result = ? WHERE `key` = ?",
            [self::STATUS_FAILED, $error, $key]
        );
    }

    /**
     * Clean up expired keys (older than N hours).
     */
    public function cleanupExpired(int $hours = 24): int
    {
        return (int) $this->db->execute(
            "DELETE FROM idempotency_keys WHERE created_at < DATE_SUB(NOW(), INTERVAL ? HOUR) LIMIT 10000",
            [$hours]
        );
    }
}
