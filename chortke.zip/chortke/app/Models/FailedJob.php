<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * FailedJob Model — Dead Letter Queue
 * 
 * جدول: failed_jobs
 */
class FailedJob extends Model
{
    protected static string $table = 'failed_jobs';

    /**
     * Fetch recent failed jobs.
     */
    /** @return list<\stdClass> */
    public function fetchRecent(int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM failed_jobs ORDER BY failed_at DESC LIMIT ?",
            [$limit]
        ) ?: [];
    }

    /**
     * Fetch failed jobs for a specific queue.
     */
    /** @return list<\stdClass> */
    public function fetchByQueue(string $queue, int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM failed_jobs WHERE queue = ? ORDER BY failed_at DESC LIMIT ?",
            [$queue, $limit]
        ) ?: [];
    }

    /**
     * Re-queue a failed job and remove from failed_jobs.
     *
     * از مسیر استاندارد Queue::push استفاده می‌کند (سازگار با هر دو درایور
     * database/redis) — قبلاً INSERT مستقیم به جدول ناموجود «jobs» انجام می‌شد.
     */
    public function retry(int $id): bool
    {
        // FIX-R36-W3 (F-A19a-03): قبلاً بدون گارد status و بدون تراکنش بود —
        // claim-first با SELECT … FOR UPDATE گارددار داخل tx (هم‌خوان با
        // SentryModel::retryFailedJob و retryEligibleFailedJobs در core/Queue.php):
        // اگر ورکر DLQ ردیف را claim کرده باشد requeue نمی‌شود و push+delete اکنون یکجا هستند.
        $this->db->beginTransaction();
        try {
            $job = $this->db->fetch(
                "SELECT * FROM failed_jobs WHERE id = ? AND (status IS NULL OR status <> 'processing') FOR UPDATE",
                [$id]
            );
            if (!$job) {
                $this->db->rollback();
                return false;
            }

            $payloadRaw = is_string($job->payload ?? null) ? $job->payload : '';
            $payload = json_decode($payloadRaw, true);
            if (!is_array($payload) || !is_string($payload['job'] ?? null) || $payload['job'] === '') {
                $this->db->rollback();
                return false;
            }

            $queue = \Core\Container::getInstance()->make(\Core\Queue::class);
            $pushed = $queue->push(
                (string)$payload['job'],
                (array)($payload['data'] ?? []),
                is_string($job->queue ?? null) && $job->queue !== '' ? $job->queue : 'default'
            );

            if (!$pushed) {
                $this->db->rollback();
                return false;
            }

            $this->db->execute("DELETE FROM failed_jobs WHERE id = ?", [$id]);
            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            return false;
        }
    }

    /**
     * Forget (delete) a failed job without retrying.
     */
    public function forget(int $id): bool
    {
        return (bool) $this->db->execute("DELETE FROM failed_jobs WHERE id = ?", [$id]);
    }

    /**
     * Purge failed jobs older than N days.
     */
    public function purge(int $days = 30): int
    {
        return (int) $this->db->execute(
            "DELETE FROM failed_jobs WHERE failed_at < DATE_SUB(NOW(), INTERVAL ? DAY)",
            [$days]
        );
    }

    /**
     * Count total failed jobs.
     */
    public function count(): int
    {
        return (int) $this->db->fetchColumn("SELECT COUNT(*) FROM failed_jobs");
    }
}
