<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * FailedJob Model — Dead Letter Queue
 * 
 * جدول: failed_jobs
 */
class FailedJob extends Model
{
    protected static string $table = 'failed_jobs';

    /**
     * Fetch recent failed jobs.
     */
    /** @return list<\stdClass> */
    public function fetchRecent(int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM failed_jobs ORDER BY failed_at DESC LIMIT ?",
            [$limit]
        ) ?: [];
    }

    /**
     * Fetch failed jobs for a specific queue.
     * FIX-C126 (یافتهٔ ۱۲۶): ردیف‌های claim‌شدهٔ ورکر (status='processing' با
     * lease فعال) دیگر فچ نمی‌شوند — دو مسیر موازی دیگر جاب دوبله نمی‌سازند.
     * FIX-CMD013 (یافتهٔ ۰۱۳): ردیف‌های quarantined هم از منبع retry انبوه خارج
     * شدند — payload خراب/خارج از allowlist هر بار در چرخهٔ retry دوباره
     * quarantine+archive می‌شد (رشد بی‌پایان dlq_archive). ردیف قرنطینه فقط
     * با تصمیم صریح ادمین (پنل) بازیابی می‌شود.
     */
    /** @return list<\stdClass> */
    public function fetchByQueue(string $queue, int $limit = 50): array
    {
        $limit = max(1, min(500, $limit));
        return $this->db->fetchAll(
            "SELECT * FROM failed_jobs
             WHERE queue = ? AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))
             ORDER BY failed_at DESC LIMIT ?",
            [$queue, $limit]
        ) ?: [];
    }

    /**
     * FIX-CMD013/CMD075: claim اتمیک برای مسیرهای retry دستی.
     * UPDATE تک‌دستوری اتمیک است و هم‌زمان: (الف) دو فرمان retry موازی را حصار
     * می‌کند (تنها یکی affected می‌گیرد)، (ب) ردیف claim‌شدهٔ ورکر (processing)
     * و قرنطینه‌شده را دور می‌زند. این claim در صورت crash نیمه‌راه، ردیف را در
     * حالت processing نگه می‌دارد که هیچ منبع retry دوباره برنمی‌دارد (at-least-once).
     */
    public function claimForRetry(int $id): bool
    {
        $affected = $this->db->execute(
            "UPDATE failed_jobs SET status = 'processing'
             WHERE id = ? AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
            [$id]
        );
        return is_int($affected) && $affected > 0;
    }

    /**
     * آزادسازی claim در شکست push — ردیف دوباره retryable می‌شود.
     */
    public function releaseRetryClaim(int $id): bool
    {
        $affected = $this->db->execute(
            "UPDATE failed_jobs SET status = 'retry_pending'
             WHERE id = ? AND status = 'processing'",
            [$id]
        );
        return is_int($affected) && $affected > 0;
    }

    /**
     * Re-queue a failed job and remove from failed_jobs.
     *
     * از مسیر استاندارد Queue::push استفاده می‌کند (سازگار با هر دو درایور
     * database/redis) — قبلاً INSERT مستقیم به جدول ناموجود «jobs» انجام می‌شد.
     */
    public function retry(int $id): bool
    {
        // FIX-CMD014 (یافتهٔ ۰۱۴): الگوی claim-first — push (اثر جانبی خارجی در
        // درایور redis) دیگر داخل تراکنش DB نیست؛ ترتیب: claim اتمیک → push →
        // حذف گارددار مالکیتِ claim. crash بعد از push ردیف را processing می‌گذارد
        // (نشان in-flight) و هیچ منبع retry دوباره push نمی‌کند (exactly-once push
        // به‌ازای هر claim موفق) — قبلاً rollback بعد از push موفقِ redis، جاب دوبله می‌ساخت.
        $job = $this->db->fetch(
            "SELECT * FROM failed_jobs WHERE id = ? AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
            [$id]
        );
        if (!$job) {
            return false;
        }

        if (!$this->claimForRetry($id)) {
            return false; // ورکر یا retry موازی زودتر رسید
        }

        try {
            $payloadRaw = is_string($job->payload ?? null) ? $job->payload : '';
            $payload = json_decode($payloadRaw, true);
            if (!is_array($payload) || !is_string($payload['job'] ?? null) || $payload['job'] === '') {
                $this->releaseRetryClaim($id);
                return false;
            }

            // FIX-C130 (یافتهٔ ۱۳۰): allowlist مشترک قبل از push — قبلاً هر کلاس
            // داخل payload (حتی دستکاری‌شده) وارد صف زنده می‌شد.
            if (!\App\Services\QueueWorker::isJobAllowed((string)$payload['job'])) {
                $this->releaseRetryClaim($id);
                return false;
            }

            $queue = \Core\Container::getInstance()->make(\Core\Queue::class);
            $pushed = $queue->push(
                (string)$payload['job'],
                (array)($payload['data'] ?? []),
                is_string($job->queue ?? null) && $job->queue !== '' ? $job->queue : 'default'
            );

            if (!$pushed) {
                $this->releaseRetryClaim($id);
                return false;
            }

            // حذف فقط با گاردِ مالکیتِ claim خودمان (status='processing')
            $deleted = $this->db->execute(
                "DELETE FROM failed_jobs WHERE id = ? AND status = 'processing'",
                [$id]
            );
            if (is_int($deleted) && $deleted === 0) {
                // push انجام شد ولی claim بین‌راه از دست رفت (at-least-once؛
                // ایدمپوتنسی جاب‌ها اجرای مضاعف را بی‌اثر می‌کند) — شفاف لاگ می‌شود.
                logger()->warning('failed_job.retry.lost_claim_after_push', ['id' => $id]);
                return false;
            }
            return true;
        } catch (\Throwable $e) {
            $this->releaseRetryClaim($id);
            logger()->error('failed_job.retry.failed', ['id' => $id, 'error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * Forget (delete) a failed job without retrying.
     *
     * FIX-CMD077 (یافتهٔ ۰۷۷): ردیف in-flight (claim ورکر/آدمین با status='processing')
     * حذف نمی‌شود — حذفِ آن، رد حافظهٔ عملیاتی و گم‌شدن audit trail بود.
     * ضمناً هم‌سو با purge (FIX-C97)، حذف واقعی پس از آرشیو انجام می‌شود تا
     * payload برای بازبینی مدیریتی از بین نرود (حذف بدون آرشیو = Data Loss نهایی).
     */
    public function forget(int $id): bool
    {
        $this->db->beginTransaction();
        try {
            $this->db->execute(
                "INSERT INTO dlq_archive
                 (original_failed_job_id, queue, job_class, payload, exception, failed_at, archive_reason, archived_by)
                 SELECT id, queue, NULL, payload, exception, failed_at, 'manual_forget', 'failed_job_model'
                 FROM failed_jobs
                 WHERE id = ? AND (status IS NULL OR status <> 'processing')",
                [$id]
            );
            $count = (int) $this->db->execute(
                "DELETE FROM failed_jobs WHERE id = ? AND (status IS NULL OR status <> 'processing')",
                [$id]
            );
            $this->db->commit();
            return $count > 0;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            return false;
        }
    }

    /**
     * Purge failed jobs older than N days.
     * FIX-C132 (یافتهٔ ۱۳۲): purge دیگر ردیف‌های claim‌شدهٔ ورکر را حذف نمی‌کند
     * (status guard) و قبل از حذف واقعی، در dlq_archive آرشیو می‌شود
     * (FIX-C97: حذفِ بدون آرشیو = Data Loss نهایی payload بود).
     */
    public function purge(int $days = 30): int
    {
        $days = max(1, min(3650, $days));
        $this->db->beginTransaction();
        try {
            $this->db->execute(
                "INSERT INTO dlq_archive
                 (original_failed_job_id, queue, job_class, payload, exception, failed_at, archive_reason, archived_by)
                 SELECT id, queue, NULL, payload, exception, failed_at, 'retention_purge', 'failed_job_model'
                 FROM failed_jobs
                 WHERE failed_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                   AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
                [$days]
            );
            $count = (int) $this->db->execute(
                "DELETE FROM failed_jobs
                 WHERE failed_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                   AND (status IS NULL OR status NOT IN ('processing', 'quarantined'))",
                [$days]
            );
            $this->db->commit();
            return $count;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            throw $e;
        }
    }

    /**
     * Count total failed jobs.
     */
    public function count(): int
    {
        return (int) $this->db->fetchColumn("SELECT COUNT(*) FROM failed_jobs");
    }
}
