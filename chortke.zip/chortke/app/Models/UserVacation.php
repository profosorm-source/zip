<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * UserVacation - مدل مدیریت مرخصی کاربران چرتکه
 */
class UserVacation extends Model
{
    protected static string $table = 'user_vacations';

    /**
     * محاسبه مجموع روزهای مرخصی کاربر در بازه زمانی گذشته
     */
    public function getCumulativeVacationDays(int $userId, int $daysBack = 90): int
    {
        $stmt = $this->db->prepare("
            SELECT SUM(duration_days) FROM user_vacations
            WHERE user_id = ?
            AND status IN ('active', 'completed')
            AND start_date >= DATE_SUB(CURRENT_DATE(), INTERVAL ? DAY)
        ");
        $stmt->execute([$userId, $daysBack]);
        return (int) $stmt->fetchColumn();
    }

    /**
     * بررسی اینکه آیا کاربر در ۹۰ روز گذشته از مرخصی استفاده کرده است یا خیر
     */
    public function hasRecentVacation(int $userId): bool
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM user_vacations
            WHERE user_id = ?
            AND status IN ('active', 'completed')
            AND start_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)
            LIMIT 1
        ");
        $stmt->execute([$userId]);
        return ((int)$stmt->fetchColumn()) > 0;
    }

    /**
     * بررسی اینکه آیا کاربر در حال حاضر در مرخصی فعال به سر می‌برد یا خیر
     */
    public function isUserOnVacation(int $userId): bool
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM user_vacations
            WHERE user_id = ?
            AND status = 'active'
            AND CURRENT_DATE() BETWEEN start_date AND end_date
            LIMIT 1
        ");
        $stmt->execute([$userId]);
        return ((int)$stmt->fetchColumn()) > 0;
    }

    /**
     * ثبت مرخصی جدید برای کاربر
     *
     * @param int $userId شناسه کاربر
     * @param int $durationDays مدت مرخصی (بین ۳ تا ۷ روز)
     * @param float $costPaid هزینه پرداخت‌شده (کیف پول یا امتیاز)
     */
    public function registerVacation(int $userId, int $durationDays, float $costPaid): ?\stdClass
    {
        // 🔒 FIX-M8-10 (راند ۱۶): مقدار خارج از بازه CLAMP نمی‌شود — قبلاً
        // max(3,min(7,...)) ورودی نامعتبر (مثلاً ۰ یا ۹۹) را بی‌صدا به ۳ یا ۷
        // تبدیل می‌کرد: دادهٔ نادرست با ظاهرِ موفق (هزینهٔ غلط، سابقهٔ غلط).
        // اکنون خطای صریح (fail-loud) — همان قرارداد بقیهٔ سرویس‌های دامنه.
        if ($durationDays < 3 || $durationDays > 7) {
            throw new \InvalidArgumentException('مدت مرخصی باید بین ۳ تا ۷ روز باشد');
        }

        // FIX-R36-W3 (F-A19b-09): بررسی سقف و درج اکنون داخل یک تراکنش با قفل
        // FOR UPDATE روی ردیف‌های مرخصیِ همان کاربر است — قبلاً check-then-insert
        // بدون قفل بود و دو درخواست هم‌زمان می‌توانستند هر دو از گارد ۳۰ روزه عبور
        // کنند. (توجه: ردیف‌های موجود همان کاربر قفل می‌شوند؛ رقابت روی کاربرِ
        // بدون ردیف به گپ‌لاک InnoDB و یک deadlock محتمل منجر می‌شود که fail-closed است.)
        $this->db->beginTransaction();
        try {
            // ✅ بررسی سقف کل مرخصی در ۹۰ روز اخیر (حداکثر ۳۰ روز) — با قفل
            $stmt = $this->db->prepare("
                SELECT COALESCE(SUM(duration_days), 0) FROM user_vacations
                WHERE user_id = ?
                AND status IN ('active', 'completed')
                AND start_date >= DATE_SUB(CURRENT_DATE(), INTERVAL ? DAY)
                FOR UPDATE
            ");
            $stmt->execute([$userId, 90]);
            $cumulative = (int) $stmt->fetchColumn();

            if (($cumulative + $durationDays) > 30) {
                $this->db->rollback();
                throw new \RuntimeException('مجموع روزهای مرخصی شما در ۹۰ روز گذشته نمی‌تواند از ۳۰ روز بیشتر شود');
            }

            // شروع مرخصی از امروز یا از فردا
            $startDate = date('Y-m-d');
            $endTimestamp = $this->parseTimestamp("+{$durationDays} days");
            $endDate = date('Y-m-d', $endTimestamp);

            $stmt = $this->db->prepare("
                INSERT INTO user_vacations (user_id, start_date, end_date, duration_days, cost_paid, status, created_at)
                VALUES (?, ?, ?, ?, ?, 'active', NOW())
            ");

            $ok = $stmt->execute([
                $userId,
                $startDate,
                $endDate,
                $durationDays,
                $costPaid
            ]);

            if (!$ok) {
                $this->db->rollback();
                return null;
            }

            $id = (int)$this->db->lastInsertId();
            $row = $this->find($id);
            $this->db->commit();
            return $row;
        } catch (\Throwable $e) {
            // قرارداد اصل مدل حفظ شود: هر استثنایی (به‌جز مسیر گارد که خودش
            // rollback کرده) بعد از cleanup به بالا propagate می‌شود.
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            throw $e;
        }
    }

    /**
     * یافتن یک رکورد مرخصی با شناسه
     */
    public function find(int $id): ?\stdClass
    {
        $stmt = $this->db->prepare("SELECT * FROM user_vacations WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);
        return $result instanceof \stdClass ? $result : null;
    }

    /**
     * دریافت لیست تاریخچه مرخصی‌های یک کاربر
     */
    /** @return list<\stdClass> */
    public function getByUser(int $userId): array
    {
        $stmt = $this->db->prepare("
            SELECT * FROM user_vacations
            WHERE user_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    private function parseTimestamp(string $expression): int
    {
        $timestamp = strtotime($expression);
        if ($timestamp === false) {
            throw new \RuntimeException('Unable to calculate vacation end date.');
        }
        return $timestamp;
    }
}