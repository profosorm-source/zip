<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * IpAndDeviceModel - IP Quality, Geolocation, Device Fingerprinting & Biometrics Data Access Layer
 */
class IpAndDeviceModel extends Model
{
    protected static string $table = 'user_fingerprints';

    // ═══════════════════════════════════════════════════════════════════════
    // IP Quality & Geolocation
    // ═══════════════════════════════════════════════════════════════════════

    /** @return list<\stdClass> */
    public function getSuspiciousIpRanges(): array
    {
        return $this->db->fetchAll("SELECT ip_range FROM vpn_ranges");
    }

    public function isTorNode(string $ip): bool
    {
        $row = $this->db->fetch("SELECT id FROM tor_exit_nodes WHERE ip_address = ? LIMIT 1", [$ip]);
        return (bool)$row;
    }

    public function getUserCountByIp(string $ip, int $days = 7): int
    {
        $row = $this->db->fetch(
            "SELECT COUNT(DISTINCT user_id) as count FROM user_sessions 
             WHERE ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? DAY)",
            [$ip, $days]
        );
        return (int)($row->count ?? 0);
    }

    public function getIpVelocity(string $ip): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT user_id, COUNT(DISTINCT ip_address) AS ip_count FROM user_sessions 
             WHERE ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR) 
             GROUP BY user_id HAVING ip_count > 5 LIMIT 1",
            [$ip]
        );
    }

    public function isIpBlacklisted(string $ip): bool
    {
        $row = $this->db->fetch(
            "SELECT id FROM ip_blacklist WHERE ip_address = ? AND (expires_at IS NULL OR expires_at > NOW()) LIMIT 1",
            [$ip]
        );
        return (bool)$row;
    }

    public function blacklistIp(string $ip, string $reason, ?string $expiresAt): bool
    {
        return (bool)$this->db->query(
            "INSERT INTO ip_blacklist (ip_address, reason, auto_blocked, expires_at) VALUES (?, ?, 1, ?)
             ON DUPLICATE KEY UPDATE reason = VALUES(reason), expires_at = VALUES(expires_at)",
            [$ip, $reason, $expiresAt]
        );
    }

    /**
     * S3-M3 FIX (S33-B3 audit): بازسازی اتمیک لیست Tor — جایگزین جفتِ
     * truncateTorNodes (TRUNCATE = DDL؛ implicit commit) + insert حلقه‌ایِ
     * بدون تراکنش. اکنون DELETE+INSERT در یک تراکنش: یا لیست نو کامل
     * جایگزین می‌شود یا لیست کهنه دست‌نخورده می‌ماند (rollback) — پنجرهٔ
     * کور سیگنال تور پس از کرش منتفی است.
     *
     * @param array<int, string> $ips
     * @return int تعداد ردیف‌های درج‌شده
     */
    public function rebuildTorNodes(array $ips): int
    {
        $this->db->beginTransaction();
        try {
            $this->db->query("DELETE FROM tor_exit_nodes");
            $inserted = 0;
            $stmt = $this->db->prepare(
                "INSERT INTO tor_exit_nodes (ip_address, last_verified) VALUES (?, NOW())
                 ON DUPLICATE KEY UPDATE last_verified = NOW()"
            );
            foreach ($ips as $ip) {
                $stmt->execute([$ip]);
                if ($stmt->rowCount() > 0) {
                    $inserted++;
                }
            }
            $this->db->commit();
            return $inserted;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            throw $e;
        }
    }

    public function getTorNodesCount(): int
    {
        $row = $this->db->fetch("SELECT COUNT(*) as count FROM tor_exit_nodes");
        return (int)($row->count ?? 0);
    }

    public function getLastUpdateTime(): ?string
    {
        $row = $this->db->fetch("SELECT MAX(last_verified) as last_update FROM tor_exit_nodes");
        return $row ? $row->last_update : null;
    }

    // M-01: Missing method - Count unique devices in 7 days
    public function getDeviceCountLast7Days(int $userId): int
    {
        $row = $this->db->fetch(
            "SELECT COUNT(DISTINCT device_fingerprint) as count FROM user_sessions 
             WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)",
            [$userId]
        );
        return (int)($row->count ?? 0);
    }

    // M-01: Missing method - Count unique IPs in 24 hours
    public function getIPCountLast24Hours(int $userId): int
    {
        $row = $this->db->fetch(
            "SELECT COUNT(DISTINCT ip_address) as count FROM user_sessions 
             WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)",
            [$userId]
        );
        return (int)($row->count ?? 0);
    }

    // M-01: Missing method - Add user to blacklist
    public function addToBlacklist(int $userId, string $reason): bool
    {
        // FIX راند ۷۷ (ستون شبح): user_blacklist ستون blocked_at ندارد (created_at خودکار ثبت می‌شود)
        // و هیچ UNIQUE KEY روی user_id نیست؛ ON DUPLICATE KEY UPDATE هرگز fire نمی‌شد.
        // رفتار درست: اگر رکورد بود reason به‌روز شود، وگرنه INSERT.
        $existing = $this->db->fetch(
            "SELECT id FROM user_blacklist WHERE user_id = ? LIMIT 1",
            [$userId]
        );
        if ($existing !== false && $existing !== null) {
            return (bool)$this->db->query(
                "UPDATE user_blacklist SET reason = ? WHERE user_id = ?",
                [$reason, $userId]
            );
        }
        return (bool)$this->db->query(
            "INSERT INTO user_blacklist (user_id, reason) VALUES (?, ?)",
            [$userId, $reason]
        );
    }

    /**
     * بررسی وضعیت بلک‌لیست کاربر بر اساس user_id (جدول user_blacklist).
     */
    public function isUserBlacklisted(int $userId): bool
    {
        $row = $this->db->query(
            "SELECT id FROM user_blacklist WHERE user_id = ? LIMIT 1",
            [$userId]
        );
        return $row !== false;
    }

    public function getLastLoginLocation(int $userId): ?\stdClass
    {
        // S3-H1 FIX (S33-B3 audit): OFFSET 1 skipped the LATEST login and
        // compared against an older one; the check runs BEFORE the current
        // session row is written, so the latest row IS the previous login.
        // latitude/longitude are now selected so the distance is real.
        $sql = "SELECT ip_address, country, city, latitude, longitude, created_at as login_at
                FROM user_sessions 
                WHERE user_id = ? 
                AND country IS NOT NULL 
                AND city IS NOT NULL
                ORDER BY created_at DESC 
                LIMIT 1";
        
        return $this->db->fetch($sql, [$userId]);
    }

    /**
     * Look up geolocation components matching numerical IPv4 ranges.
     */
    public function getLocationByIpRange(int $ipLong): ?\stdClass
    {
        $sql = "SELECT country_code, country_name, city, latitude, longitude
                FROM ip_locations
                WHERE ip_start <= ? AND ip_end >= ?
                LIMIT 1";
        
        return $this->db->fetch($sql, [$ipLong, $ipLong]);
    }

    public function getFromCache(string $ip): ?\stdClass
    {
        $cache = cache();
        $payload = $cache->get('geoip:' . $ip);
        if ($payload === null) {
            return null;
        }

        if (is_string($payload)) {
            $payload = (array)(json_decode($payload, true) ?? []);
        }

        if (!is_array($payload)) {
            return null;
        }

        return (object) [
            'country_code' => $payload['country_code'] ?? null,
            'country_name' => $payload['country_name'] ?? null,
            'city' => $payload['city'] ?? null,
            'latitude' => $payload['latitude'] ?? null,
            'longitude' => $payload['longitude'] ?? null,
            'timezone' => $payload['timezone'] ?? null,
        ];
    }

    /** @param array<string, mixed> $location */
    public function saveToCache(string $ip, array $location): bool
    {
        $cache = cache();
        return $cache->put('geoip:' . $ip, $location, 60 * 24 * 7);
    }

    /** @return list<\stdClass> */
    public function getSessionsForVelocity(int $userId, string $since): array
    {
        $sql = "SELECT ip_address, country, city, created_at
                FROM user_sessions 
                WHERE user_id = ? 
                AND created_at >= ?
                AND country IS NOT NULL 
                AND city IS NOT NULL
                ORDER BY created_at ASC";
        
        return $this->db->fetchAll($sql, [$userId, $since]);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Device Fingerprint & Biometrics
    // ═══════════════════════════════════════════════════════════════════════

    /** @param array<string, mixed> $metadata */
    public function upsertFingerprint(int $userId, string $fingerprint, array $metadata): bool
    {
        return (bool)$this->db->query(
            "INSERT INTO user_fingerprints (user_id, fingerprint, metadata, created_at) VALUES (?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE last_seen = NOW(), seen_count = seen_count + 1",
            [$userId, $fingerprint, json_encode($metadata)]
        );
    }

    public function getFingerprintUserCount(string $fingerprint, int $days = 30): int
    {
        $row = $this->db->fetch(
            "SELECT COUNT(DISTINCT user_id) as count FROM user_fingerprints 
             WHERE fingerprint = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? DAY)",
            [$fingerprint, $days]
        );
        return (int)($row->count ?? 0);
    }



    public function blacklistFingerprint(string $fingerprint, string $reason, ?string $expiresAt): bool
    {
        return (bool)$this->db->query(
            "INSERT INTO device_blacklist (fingerprint, reason, auto_blocked, expires_at) VALUES (?, ?, 1, ?)
             ON DUPLICATE KEY UPDATE reason = VALUES(reason), expires_at = VALUES(expires_at)",
            [$fingerprint, $reason, $expiresAt]
        );
    }

    /** @param array<string, mixed> $metadata */
    public function storeFingerprint(int $userId, string $fingerprint, array $metadata): bool
    {
        return $this->upsertFingerprint($userId, $fingerprint, $metadata);
    }

    /** @return list<\stdClass> */
    public function getRecentFingerprints(int $userId, int $limit = 5): array
    {
        $sql = "SELECT * FROM user_fingerprints WHERE user_id = ? ORDER BY created_at DESC LIMIT ?";
        return $this->db->fetchAll($sql, [$userId, $limit]);
    }

    /** @return list<\stdClass> */
    public function getAllUserFingerprints(int $userId, int $limit = 10): array
    {
        $sql = "SELECT * FROM user_fingerprints WHERE user_id = ? ORDER BY created_at DESC LIMIT ?";
        return $this->db->fetchAll($sql, [$userId, $limit]);
    }

    /** @param array<string, mixed> $analysis */
    public function logSuspicion(int $userId, int $score, array $analysis): bool
    {
        return (bool)$this->db->query(
            "INSERT INTO fraud_logs (user_id, fraud_type, risk_score, details, created_at)
             VALUES (?, 'browser_fingerprint', ?, ?, NOW())",
            [$userId, $score, json_encode($analysis, JSON_UNESCAPED_UNICODE)]
        );
    }

    public function getLastTypingPattern(int $userId): ?\stdClass
    {
        $sql = "SELECT avg_interval, stddev_interval 
                FROM user_typing_patterns 
                WHERE user_id = ? 
                ORDER BY created_at DESC 
                LIMIT 1";
        return $this->db->fetch($sql, [$userId]);
    }

    /** @param array<string, mixed> $pattern */
    public function saveTypingPattern(int $userId, array $pattern): bool
    {
        $sql = "INSERT INTO user_typing_patterns 
                (user_id, avg_interval, stddev_interval, avg_hold_time, keystroke_count, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())";
        
        $stmt = $this->db->query($sql, [
            $userId,
            $pattern['avg_interval'],
            $pattern['stddev_interval'],
            $pattern['avg_hold_time'],
            $pattern['keystroke_count']
        ]);

        return (bool) $stmt;
    }

        
            /** @param array<string, mixed> $data */
    public function logFraudEvent(array $data): bool
    {
        return (bool)$this->db->query(
            "INSERT INTO fraud_logs (user_id, fraud_type, risk_score, details, created_at) 
             VALUES (?, ?, ?, ?, NOW())",
            [
                $data['user_id'], 
                $data['type'], 
                $data['score'], 
                json_encode($data['details'], JSON_UNESCAPED_UNICODE)
            ]
        );
    }


    /** @return list<\stdClass> */
    public function getDeviceSharing(int $userId): array
    {
        $sql = "SELECT device_fingerprint, COUNT(DISTINCT id) as account_count
                FROM users
                WHERE device_fingerprint IN (
                    SELECT device_fingerprint 
                    FROM users 
                    WHERE id = ?
                )
                GROUP BY device_fingerprint
                HAVING account_count > 1";

        return $this->db->fetchAll($sql, [$userId]);
    }

    /**
     * @param array<string, mixed> $deviceInfo
     * @param array<string, mixed> $analysis
     */
    public function saveAnalysis(int $userId, string $fingerprint, array $deviceInfo, array $analysis, string $riskLevel = 'unknown'): bool
    {
        // FIX راند ۷۷ (ستون شبح): ستون‌های واقعی device_analyses عبارت‌اند از
        // (device_fingerprint, risk_score INT NOT NULL, details) — fingerprint/device_info/analysis/risk_level نبودند؛
        // سطح ریسک متنی در details (JSON) حفظ می‌شود و risk_score صفر خنثی می‌ماند.
        $stmt = $this->db->query(
            "INSERT INTO device_analyses (user_id, device_fingerprint, risk_score, details, created_at) 
             VALUES (?, ?, 0, ?, NOW())",
            [
                $userId,
                $fingerprint,
                json_encode(['device_info' => $deviceInfo, 'analysis' => $analysis, 'risk_level' => $riskLevel], JSON_UNESCAPED_UNICODE),
            ]
        );
        return $stmt !== false;
    }

    /**
     * ثبت رویداد سفر غیرممکن (Impossible Travel)
     */
    public function logImpossibleTravel(int $userId, string $prevLocation, string $newLocation, float $distanceKm, float $riskScore): bool
    {
        try {
            // FIX راند ۷۷ (ستون شبح): ستون‌های واقعی ip_from/ip_to (varchar 45) و time_diff_sec هستند؛
            // prev_location/new_location/risk_score هرگز وجود نداشتند.
            $stmt = $this->db->query(
                "INSERT INTO impossible_travel_logs (user_id, ip_from, ip_to, distance_km, created_at) 
                 VALUES (?, ?, ?, ?, NOW())",
                [$userId, mb_substr($prevLocation, 0, 45), mb_substr($newLocation, 0, 45), $distanceKm]
            );
            return $stmt !== false;
        } catch (\Throwable) {
            return false;
        }
    }


}
