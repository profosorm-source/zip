<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * OutboxEvent Model — transactional outbox pattern
 * 
 * جدول: outbox_events
 */
class OutboxEvent extends Model
{
    protected static string $table = 'outbox_events';

    public const STATUS_PENDING    = 'pending';
    public const STATUS_PROCESSING = 'processing';
    public const STATUS_PUBLISHED  = 'published';
    public const STATUS_FAILED     = 'failed';
    public const STATUS_DLQ        = 'dlq';

    /**
     * Fetch pending events ready for publishing.
     */
    public function fetchPending(int $limit = 100): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM outbox_events 
             WHERE status = ? AND available_at <= NOW() 
             ORDER BY id ASC LIMIT ?",
            [self::STATUS_PENDING, $limit]
        ) ?: [];
    }

    /**
     * Mark an event as processing.
     */
    public function markProcessing(int $id): bool
    {
        return (bool) $this->db->execute(
            "UPDATE outbox_events SET status = ?, attempts = attempts + 1, updated_at = NOW() WHERE id = ?",
            [self::STATUS_PROCESSING, $id]
        );
    }

    /**
     * Mark an event as published.
     */
    public function markPublished(int $id): bool
    {
        return (bool) $this->db->execute(
            "UPDATE outbox_events SET status = ?, published_at = NOW(), updated_at = NOW() WHERE id = ?",
            [self::STATUS_PUBLISHED, $id]
        );
    }

    /**
     * Mark an event as failed with error message.
     */
    public function markFailed(int $id, string $error): bool
    {
        return (bool) $this->db->execute(
            "UPDATE outbox_events SET status = ?, last_error = ?, updated_at = NOW() WHERE id = ?",
            [self::STATUS_FAILED, mb_substr($error, 0, 2000), $id]
        );
    }

    /**
     * Move to DLQ.
     */
    public function moveToDlq(int $id, string $error): bool
    {
        return (bool) $this->db->execute(
            "UPDATE outbox_events SET status = ?, last_error = ?, updated_at = NOW() WHERE id = ?",
            [self::STATUS_DLQ, mb_substr($error, 0, 2000), $id]
        );
    }
}
