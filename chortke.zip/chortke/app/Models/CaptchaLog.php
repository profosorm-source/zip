<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class CaptchaLog extends Model
{
    protected static string $table = 'captcha_attempts';

    /**
     * FIX-18O (P1): ستون شبح «success» حذف شد — ستون واقعی جدول is_success است
     * (2026_06_10_0014_infrastructure.sql + 2026_07_16_0003_captcha_attempts_
     * observability_compat.sql). Whitelist = دقیقاً ستون‌های زندهٔ جدول.
     */
    protected array $fillable = [
        'user_id', 'session_id', 'type', 'challenge', 'response',
        'ip_address', 'user_agent', 'is_success', 'score', 'solved_at', 'created_at',
    ];

    /**
     * FIX-18O (P1): ورودی قبل از insert با $fillable فیلتر می‌شود و کلیدِ
     * قدیمی «success» (در صورت رسیدن از فراخوان‌های legacy) به is_success
     * نگاشت می‌شود — قبلاً ستون ناموجود باعث SQLSTATE 42S22 می‌شد.
     *
     * @param array<string, mixed> $data
     */
    public function recordAttempt(array $data): int
    {
        if (array_key_exists('success', $data)) {
            if (!array_key_exists('is_success', $data)) {
                $data['is_success'] = !empty($data['success']) ? 1 : 0;
            }
            unset($data['success']);
        }

        return (int)$this->db->table(self::$table)
            ->insert($this->filterFillable($data));
    }
    /**
     * @return list<object>
     */

    public function getRecentAttempts(int $limit = 50): array
    {
        return $this->db->table(self::$table)
            ->select('id', 'user_id', 'ip_address', 'is_success AS success', 'created_at')
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }

    public function countFailedByIp(string $ip, string $since): int
    {
        return (int)$this->db->table(self::$table)
            ->where('ip_address', '=', $ip)
            ->where('created_at', '>=', $since)
            ->where('is_success', '=', 0)
            ->count();
    }
}
