<?php
// app/Models/SocialAccount.php

namespace App\Models;
use Core\Model;

use Core\Database;

class SocialAccount extends Model {
    /**
     * نام جدول (الزام قرارداد Core\\Model).
     * این مدل عمدتاً از کوئری‌های خام استفاده می‌کند، اما برای سازگاری با
     * متدهای پایه‌ی Model، جدول مرجع آن تعریف می‌شود.
     */
    protected static string $table = 'user_social_accounts';

    
    public int $id;
    public int $user_id;
    public string $platform;
    public string $username;
    public string $profile_url;
    public int $follower_count;
    public int $following_count;
    public int $post_count;
    public float $engagement_rate;
    public int $account_age_months;
    public string $status;
    public ?string $rejection_reason;
    public ?string $rejection_history;
    public ?int $verified_by;
    public ?string $verified_at;
    public bool $is_active;
    public string $created_at;
    public ?string $updated_at;
    public ?string $deleted_at;
/**
     * پیدا کردن بر اساس ID
     */
    public function find(int $id): ?self
    {
        $stmt = $this->db->prepare("
            SELECT * FROM user_social_accounts 
            WHERE id = ? AND deleted_at IS NULL
        ");
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!\is_array($row)) {
            return null;
        }
        /** @var array<string, mixed> $row */
        return $this->hydrate($row);
    }
    
    /**
     * پیدا کردن بر اساس user و platform
     */
    public function findByUserAndPlatform(int $userId, string $platform): ?self
    {
        $stmt = $this->db->prepare("
            SELECT * FROM user_social_accounts 
            WHERE user_id = ? AND platform = ? AND deleted_at IS NULL
            LIMIT 1
        ");
        $stmt->execute([$userId, $platform]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!\is_array($row)) {
            return null;
        }
        /** @var array<string, mixed> $row */
        return $this->hydrate($row);
    }
    
    /**
     * لیست حساب‌های یک کاربر
     */
    /** @return list<self> */
    public function getByUser(int $userId): array
    {
        $stmt = $this->db->prepare("
            SELECT * FROM user_social_accounts 
            WHERE user_id = ? AND deleted_at IS NULL
            ORDER BY created_at DESC
        ");
        $stmt->execute([$userId]);
        /** @var list<array<string, mixed>> $rows */
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        return \array_values(\array_map([$this, 'hydrate'], $rows));
    }
    
    /**
     * حساب‌های تایید‌شده کاربر
     * X286: شرط is_active = 1 حذف شد — جدول هرگز ستون is_active نداشته و این
     * کوئری را با «Unknown column» می‌کشت؛ وضعیت با status = 'verified' پوشش داده می‌شود.
     */
    /** @return list<self> */
    public function getVerifiedByUser(int $userId): array
    {
        $stmt = $this->db->prepare("
            SELECT * FROM user_social_accounts 
            WHERE user_id = ? AND status = 'verified' AND deleted_at IS NULL
            ORDER BY platform ASC
        ");
        $stmt->execute([$userId]);
        /** @var list<array<string, mixed>> $rows */
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        return \array_values(\array_map([$this, 'hydrate'], $rows));
    }
    
    /**
     * لیست در انتظار تایید (Admin)
     */
    /** @return list<\stdClass> */
    public function getPending(int $limit = 50, int $offset = 0): array
    {
        $stmt = $this->db->prepare("
            SELECT sa.*, u.full_name as user_name, u.email as user_email
            FROM user_social_accounts sa
            JOIN users u ON u.id = sa.user_id
            WHERE sa.status = 'pending' AND sa.deleted_at IS NULL
            ORDER BY sa.created_at ASC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$limit, $offset]);
        /** @var list<\stdClass> $rows */
        $rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
    }
    
    /**
     * لیست همه (Admin) با فیلتر
     */
    /** @param array<string, mixed> $filters */
    /** @return list<\stdClass> */
    /** @param array<string, mixed> $filters */
    /**
     * @param array<string, mixed> $filters
     * @return list<\stdClass>
     */
    public function getAll(array $filters = [], int $limit = 50, int $offset = 0): array
    {
        $where = ['sa.deleted_at IS NULL'];
        $params = [];
        
        if (!empty($filters['status'])) {
            $where[] = 'sa.status = ?';
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['platform'])) {
            $where[] = 'sa.platform = ?';
            $params[] = $filters['platform'];
        }
        
        if (!empty($filters['search'])) {
            $where[] = '(sa.username LIKE ? OR u.full_name LIKE ?)';
            // FIX-R19-A7-6: escape LIKE wildcards (reuse core Model::escapeLikeValue)
            $s = '%' . $this->escapeLikeValue(str_value($filters['search'])) . '%';
            $params[] = $s;
            $params[] = $s;
        }
        
        $whereStr = \implode(' AND ', $where);
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->db->prepare("
            SELECT sa.*, u.full_name as user_name, u.email as user_email
            FROM user_social_accounts sa
            JOIN users u ON u.id = sa.user_id
            WHERE {$whereStr}
            ORDER BY sa.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute($params);
        /** @var list<\stdClass> $rows */
        $rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
        return $rows;
    }
    
    /**
     * تعداد کل (برای صفحه‌بندی)
     */
    /** @param array<string, mixed> $filters */
    public function countAll(array $filters = []): int
    {
        $where = ['sa.deleted_at IS NULL'];
        $params = [];
        
        if (!empty($filters['status'])) {
            $where[] = 'sa.status = ?';
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['platform'])) {
            $where[] = 'sa.platform = ?';
            $params[] = $filters['platform'];
        }
        
        if (!empty($filters['search'])) {
            $where[] = '(sa.username LIKE ? OR u.full_name LIKE ?)';
            // FIX-R19-A7-6: escape LIKE wildcards (reuse core Model::escapeLikeValue)
            $s = '%' . $this->escapeLikeValue(str_value($filters['search'])) . '%';
            $params[] = $s;
            $params[] = $s;
        }
        
        $whereStr = \implode(' AND ', $where);
        
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM user_social_accounts sa
            JOIN users u ON u.id = sa.user_id
            WHERE {$whereStr}
        ");
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }
    
    /**
     * ایجاد حساب جدید
     */
    /** @param array<string, mixed> $data */
    public function createAccount(array $data): ?self
    {
        // X285: هم‌تراز با schema واقعی (migration 2026_06_10_0040) — ستون‌های
        // following_count/post_count/engagement_rate/account_age_months وجود خارجی ندارند.
        $stmt = $this->db->prepare("
            INSERT INTO user_social_accounts 
            (user_id, platform, username, profile_url, follower_count, status)
            VALUES (?, ?, ?, ?, ?, 'pending')
        ");
        
        $result = $stmt->execute([
            $data['user_id'],
            $data['platform'],
            $data['username'],
            $data['profile_url'],
            $data['follower_count'] ?? 0,
        ]);
        
        if ($result) {
            return $this->find((int) $this->db->lastInsertId());
        }
        
        return null;
    }
    
    /**
     * بروزرسانی
     */
    /** @param array<string, mixed> $data */
    public function update(int $id, array $data): bool
    {
        $fields = [];
        $params = [];
        
        // X286: ستون‌های rejection_reason/verified_by/verified_at با مایگریشن
        // 2026_09_08_0001 واقعی شدند و به whitelist برگشتند. بقیه کلیدهای حذف‌شدهٔ
        // X285 (following_count، post_count، engagement_rate، account_age_months،
        // is_active) همچنان ستون شبح‌اند و نباید برگردند.
        $allowed = [
            'username', 'profile_url', 'follower_count', 'status',
            'rejection_reason', 'verified_by', 'verified_at',
        ];
        
        foreach ($allowed as $field) {
            if (\array_key_exists($field, $data)) {
                $fields[] = "{$field} = ?";
                $params[] = $data[$field];
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $fields[] = "updated_at = NOW()";
        $params[] = $id;
        
        $fieldStr = \implode(', ', $fields);
        $stmt = $this->db->prepare("
            UPDATE user_social_accounts SET {$fieldStr} WHERE id = ?
        ");
        
        return $stmt->execute($params);
    }
    
    /**
     * Soft Delete
     */
    public function softDelete(int $id): bool
    {
        $stmt = $this->db->prepare("
            UPDATE user_social_accounts 
            SET deleted_at = NOW(), updated_at = NOW() 
            WHERE id = ?
        ");
        return $stmt->execute([$id]);
    }
    
    /**
     * بررسی وجود حساب تکراری
     */
    public function existsByPlatformAndUsername(string $platform, string $username, ?int $excludeId = null): bool
    {
        $sql = "SELECT COUNT(*) FROM user_social_accounts 
                WHERE platform = ? AND username = ? AND deleted_at IS NULL";
        $params = [$platform, $username];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn() > 0;
    }
    
    /**
     * نام فارسی پلتفرم
     *
     * FIX-F21-02-LT (بستهٔ ۷): labelها به منبع واحد SocialPlatform منتقل
     * شدند — این متد دلیگیت است؛ پلتفرم ناشناخته عیناً همان رشتهٔ خام
     * برمی‌گردد (رفتار سابق حفظ شده).
     */
    public function platformLabel(string $platform): string
    {
        return \App\Enums\SocialPlatform::tryFrom($platform)?->label() ?? $platform;
    }
    
    /**
     * نام فارسی وضعیت
     */
    public function statusLabel(string $status): string
    {
        $labels = [
            'pending'  => 'در انتظار بررسی',
            'verified' => 'تایید شده',
            'rejected' => 'رد شده',
        ];
        return $labels[$status] ?? $status;
    }
    
    /**
     * کلاس CSS وضعیت
     */
    public function statusBadge(string $status): string
    {
        $badges = [
            'pending'  => 'warning',
            'verified' => 'success',
            'rejected' => 'danger',
        ];
        return $badges[$status] ?? 'secondary';
    }
    
    /**
     * تبدیل ردیف به شیء
     */
/** @param array<string, mixed> $row */
    private function hydrate(array $row): self
    {
        $obj = new self($this->db);
        
        $obj->id = int_value($row['id'] ?? 0);
        $obj->user_id = int_value($row['user_id'] ?? 0);
        $obj->platform = str_value($row['platform'] ?? '');
        $obj->username = str_value($row['username'] ?? '');
        $obj->profile_url = str_value($row['profile_url'] ?? '');
        $obj->follower_count = int_value($row['follower_count'] ?? 0);
        $obj->following_count = int_value($row['following_count'] ?? 0);
        $obj->post_count = int_value($row['post_count'] ?? 0);
        $obj->engagement_rate = float_value($row['engagement_rate'] ?? 0);
        $obj->account_age_months = int_value($row['account_age_months'] ?? 0);
        $obj->status = str_value($row['status'] ?? '');
        $obj->rejection_reason = isset($row['rejection_reason']) ? str_value($row['rejection_reason']) : null;
        $obj->rejection_history = isset($row['rejection_history']) ? str_value($row['rejection_history']) : null;
        $obj->verified_by = isset($row['verified_by']) ? int_value($row['verified_by']) : null;
        $obj->verified_at = isset($row['verified_at']) ? str_value($row['verified_at']) : null;
        $obj->is_active = (bool) ($row['is_active'] ?? false);
        $obj->created_at = str_value($row['created_at'] ?? '');
        $obj->updated_at = isset($row['updated_at']) ? str_value($row['updated_at']) : null;
        $obj->deleted_at = isset($row['deleted_at']) ? str_value($row['deleted_at']) : null;
        
        return $obj;
    }
}
