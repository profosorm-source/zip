<?php

namespace App\Models;

use Core\Model;
use Core\Database;

class InvestmentProfit extends Model {
    protected static string $table = 'investment_profits';

    /** 🛡️ FIX-S16-13 (بچ S16): سفیدلیست ستون‌های investment_profits — کلیدهای مجاز =
     * دقیقاً آرایهٔ ثابت فراخوان زندهٔ ApplyProfitLossToBatchJob + پیش‌فرض‌های create. */
    private const ALLOWED_COLUMNS = [
        'investment_id', 'user_id', 'amount', 'gross_amount', 'site_fee_amount',
        'tax_amount', 'net_amount', 'balance_before', 'balance_after',
        'trading_record_id', 'currency', 'profit_type', 'status',
        'transaction_id', 'period_date', 'period',
        'created_at', 'updated_at', 'is_deleted',
    ];

    /**
     * ایجاد رکورد سود/ضرر
     * خروجی: id یا null
     */
    /** @param array<string, mixed> $data */
    public function create(array $data): ?int
    {
        $now = \date('Y-m-d H:i:s');

        $data['created_at'] = $data['created_at'] ?? $now;
        $data['updated_at'] = $data['updated_at'] ?? $now;
        $data['is_deleted'] = $data['is_deleted'] ?? 0;
        if (!isset($data['net_amount']) && isset($data['amount'])) {
            $data['net_amount'] = $data['amount'];
        }

        $filtered = [];
        foreach (self::ALLOWED_COLUMNS as $col) {
            if (\array_key_exists($col, $data)) {
                $filtered[$col] = $data[$col];
            }
        }

        $columns = \array_keys($filtered);
        $values  = \array_values($filtered);

        $placeholders = \array_fill(0, \count($columns), '?');
        $colsSql = '`' . \implode('`,`', $columns) . '`';

        $sql = "INSERT INTO `investment_profits` ({$colsSql}) VALUES (" . \implode(',', $placeholders) . ")";

        $stmt = $this->db->prepare($sql);
        $ok = $stmt->execute($values);

        if (!$ok) {
            return null;
        }

        $id = (int)$this->db->lastInsertId();
        return $id > 0 ? $id : null;
    }

    public function find(int $id): ?\stdClass
    {
        $stmt = $this->db->query(
            "SELECT * FROM investment_profits WHERE id = ? AND is_deleted = 0 LIMIT 1",
            [$id]
        );

        $row = $stmt->fetch(\PDO::FETCH_OBJ) ?: false;
        return $row instanceof \stdClass ? $row : null;
    }

    /** @return list<\stdClass> */
    public function getByInvestment(int $investmentId, int $limit = 50): array
    {
        $limit = \max(1, (int)$limit);

        $stmt = $this->db->prepare(
            "SELECT ip.*, t.pair, t.direction, t.open_price, t.close_price
             FROM investment_profits ip
             LEFT JOIN trading_records t ON ip.trading_record_id = t.id
             WHERE ip.investment_id = :investment_id AND ip.is_deleted = 0
             ORDER BY ip.created_at DESC
             LIMIT :limit"
        );
        $stmt->bindValue(':investment_id', $investmentId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
    }

    /** @return list<\stdClass> */
    public function getByUser(int $userId, int $limit = 20, int $offset = 0): array
    {
        $limit  = \max(1, (int)$limit);
        $offset = \max(0, (int)$offset);

        // BUGFIX-INVPROFIT-USERID-2026-06:
        // جدول investment_profits ستون user_id ندارد؛ user_id فقط در جدول والد
        // investments وجود دارد. کوئری قبلی روی ip.user_id باعث 500 می‌شد.
        // اصلاح: فیلتر بر اساس i.user_id (پس از JOIN) و الزام جدا نبودن investment.
        $stmt = $this->db->prepare(
            "SELECT ip.*, i.amount as investment_amount
             FROM investment_profits ip
             JOIN investments i ON ip.investment_id = i.id
             WHERE i.user_id = :user_id
               AND ip.is_deleted = 0
               AND i.deleted_at IS NULL
             ORDER BY ip.created_at DESC
             LIMIT :limit OFFSET :offset"
        );
        $stmt->bindValue(':user_id', $userId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
    }

    public function countByUser(int $userId): int
    {
        // BUGFIX-INVPROFIT-USERID-2026-06: same root cause as getByUser().
        $stmt = $this->db->query(
            "SELECT COUNT(*) as total
             FROM investment_profits ip
             JOIN investments i ON ip.investment_id = i.id
             WHERE i.user_id = ?
               AND ip.is_deleted = 0
               AND i.deleted_at IS NULL",
            [$userId]
        );

        $row = $this->fetchObject($stmt);
        return (int)($row->total ?? 0);
    }

    /**
     * مجموع سود/ضرر یک سرمایه‌گذاری
     */
    public function getTotalByInvestment(int $investmentId): object
    {
        $stmt = $this->db->query(
            "SELECT
                COALESCE(SUM(CASE WHEN net_amount > 0 THEN net_amount ELSE 0 END), 0) as total_profit,
                COALESCE(SUM(CASE WHEN net_amount < 0 THEN ABS(net_amount) ELSE 0 END), 0) as total_loss,
                COALESCE(SUM(net_amount), 0) as net_total
             FROM investment_profits
             WHERE investment_id = ? AND is_deleted = 0",
            [$investmentId]
        );

        $row = $this->fetchObject($stmt);

        return $row ?: (object)[
            'total_profit' => 0,
            'total_loss' => 0,
            'net_total' => 0,
        ];
    }
}