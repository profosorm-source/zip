<?php

namespace App\Models;

use Core\Model;

class NotificationPreference extends Model
{
    protected static string $table = 'notification_preferences_v2';

    public function __construct(\Core\Database $db)
    {
        parent::__construct($db);
    }

    public function getOrCreate(int $userId): object
    {
        $prefs = $this->db->query(
            "SELECT * FROM " . static::$table . " WHERE user_id = ? LIMIT 1",
            [$userId]
        )->fetch(\PDO::FETCH_OBJ);

        if (!$prefs) {
            try {
                $now = date('Y-m-d H:i:s');
                $this->db->query(
                    "INSERT INTO " . static::$table . " (user_id, created_at, updated_at)
                     VALUES (?, ?, ?)",
                    [$userId, $now, $now]
                );
            } catch (\Throwable $e) {
            }

            $prefs = $this->db->query(
                "SELECT * FROM " . static::$table . " WHERE user_id = ? LIMIT 1",
                [$userId]
            )->fetch(\PDO::FETCH_OBJ);
        }

        if (!$prefs) {
            return (object)[
                'user_id'         => $userId,
                'in_app_enabled'  => 1,
                'email_enabled'   => 1,
                'push_enabled'    => 1,
                'sms_enabled'     => 0,
                'dnd_enabled'     => 0,
                'dnd_start'       => '23:00:00',
                'dnd_end'         => '07:00:00',
            ];
        }

        return $prefs;
    }

    public function updateForUser(int $userId, array $data): bool
    {
        if (empty($data)) {
            return true;
        }

        $sets   = implode(', ', array_map(fn($k) => "`{$k}` = ?", array_keys($data)));
        $values = array_values($data);
        $values[] = $userId;

        $stmt = $this->db->query(
            "UPDATE " . static::$table . " SET {$sets}, updated_at = NOW() WHERE user_id = ?",
            $values
        );

        return $stmt instanceof \PDOStatement;
    }

    public function getByUsers(array $userIds): array
    {
        if (empty($userIds)) return [];
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));
        return $this->db->fetchAll(
            "SELECT * FROM " . static::$table . " WHERE user_id IN ($placeholders)",
            $userIds
        ) ?: [];
    }

    public function getAllowedFields(): array
    {
        return ['in_app_enabled', 'email_enabled', 'push_enabled', 'sms_enabled', 'dnd_enabled', 'dnd_start', 'dnd_end'];
    }

    public function getEnabledChannelsForType(int $userId, string $type): array
    {
        // This is a simplified check for the new V2 schema.
        // Since V2 uses global flags, we just return the enabled channels.
        $pref = $this->getOrCreate($userId);
        $enabled = [];
        if ($pref->in_app_enabled) $enabled[] = 'in_app';
        if ($pref->push_enabled) $enabled[] = 'push';
        if ($pref->email_enabled) $enabled[] = 'email';
        if ($pref->sms_enabled) $enabled[] = 'sms';
        return $enabled;
    }
}
