<?php
declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * MessageModerationModel
 */
class MessageModerationModel extends Model
{
    /**
     * نام جدول (الزام قرارداد Core\\Model).
     * این مدل عمدتاً از کوئری‌های خام استفاده می‌کند، اما برای سازگاری با
     * متدهای پایه‌ی Model، جدول مرجع آن تعریف می‌شود.
     */
    protected static string $table = 'direct_messages';

    /**
     * دریافت پیام‌های یک کاربر برای بررسی تاریخچه (بدون اطلاعات حساس طرف مقابل)
     */
    /** @return list<\stdClass> */
    public function getUserMessages(int $senderId, int $limit = 10): array
    {
        $sql = "SELECT id, message, created_at, is_encrypted 
                FROM direct_messages 
                WHERE sender_id = ? 
                ORDER BY created_at DESC 
                LIMIT ?";
        
        return $this->db->fetchAll($sql, [$senderId, $limit]);
    }

    /**
     * بروزرسانی وضعیت گزارش
     */
    public function updateReportStatus(int $reportId, string $status, int $adminId): bool
    {
        // FIX راند ۷۷ (ستون شبح): message_reports فقط (reporter_id, message_id, reason, status, created_at)
        // دارد — ستون‌های admin_id/updated_at نبودند؛ اکشن ادمین در لاگ سطح سرویس ثبت می‌شود.
        $sql = "UPDATE message_reports 
                SET status = ?
                WHERE id = ?";
        
        return (bool)$this->db->query($sql, [$status, $reportId]);
    }

    /**
     * فاز G (تسک ۸۳): ثبت گزارش تخلف پیام توسط کاربر — تاکنون هیچ مسیر
     * INSERT‌ای برای message_reports وجود نداشت و صف بررسی ادمین
     * (/admin/messages/reports) همیشه خالی بود.
     */
    public function createReport(int $reporterId, int $messageId, string $reason): ?int
    {
        $stmt = $this->db->prepare(
            "INSERT INTO message_reports (reporter_id, message_id, reason, status, created_at)
             VALUES (?, ?, ?, 'pending', NOW())"
        );
        if (!$stmt->execute([$reporterId, $messageId, $reason])) {
            return null;
        }
        $id = (int)$this->db->lastInsertId();
        return $id > 0 ? $id : null;
    }

    /**
     * فاز G (تسک ۸۳): ضد تکرار — هر گزارش‌دهنده فقط یک‌بار می‌تواند
     * یک پیام را گزارش کند.
     */
    public function hasReportedByUser(int $reporterId, int $messageId): bool
    {
        return $this->db->fetch(
            "SELECT id FROM message_reports WHERE reporter_id = ? AND message_id = ? LIMIT 1",
            [$reporterId, $messageId]
        ) !== null;
    }

    /**
     * دریافت کاربران مسدود شده
     */
    /** @return list<array<string, mixed>> */
    public function getBlockedUsers(int $limit, int $offset): array
    {
        $sql = "SELECT ub.blocker_id, ub.blocked_id,
                       blocker.full_name as blocker_name, blocker.email as blocker_email,
                       blocked.full_name as blocked_name, blocked.email as blocked_email
                FROM user_blocks ub
                JOIN users blocker ON ub.blocker_id = blocker.id
                JOIN users blocked ON ub.blocked_id = blocked.id
                ORDER BY ub.blocker_id DESC
                LIMIT ? OFFSET ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(1, $limit, \PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $this->fetchAssocList($stmt);
    }
}
