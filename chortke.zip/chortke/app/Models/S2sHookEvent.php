<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * S2sHookEvent — لجر مشاهده‌پذیری وب‌هوک‌های S2S ویدیو-پاداشی (X374، راند ۹۳)
 *
 * برای هر خروجی نهایی AdtubeController::s2sWebhook یک ردیف best-effort ثبت
 * می‌شود تا داشبورد ادمین (KPI) نرخ پذیرش، الگوی ردشدگی و مجموع پاداش هر
 * شبکهٔ تبلیغاتی را نشان دهد.
 *
 * ⚠ این جدول «لجر KPI» است نه لجر مالی — پول فقط از مسیر WalletService::
 * depositInTransaction حرکت می‌کند؛ شکست نوشتن این ردیف نباید هیچ‌گاه
 * نتیجهٔ وب‌هوک را عوض کند (کنترلر record() را در try/catch می‌پیچد و
 * فقط logger->error('s2s_hook_event.write_failed') می‌زند).
 *
 * حریم خصوصی: txid خام هرگز ذخیره نمی‌شود — فقط hash('sha256', network|txid)
 * که همان بخشِ هشِ کلید idempotency تراکنش است و برای correlate با
 * transactions.idempotency_key کافی است.
 *
 * @phpstan-type S2sEventRow array{
 *     network: string, outcome: string, reject_reason: string|null,
 *     user_id: int|null, txid_hash: string|null, payout_amount: string|null,
 *     currency: string|null, http_status: int, ip: string|null
 * }
 */
class S2sHookEvent extends Model
{
    protected static string $table = 's2s_hook_events';

    /** خروجی‌های نهایی مجاز وب‌هوک */
    public const OUTCOME_CREDITED = 'credited';
    public const OUTCOME_REPLAY   = 'replay';
    public const OUTCOME_REJECTED = 'rejected';

    /** @var list<string> */
    public const OUTCOMES = [self::OUTCOME_CREDITED, self::OUTCOME_REPLAY, self::OUTCOME_REJECTED];

    /** دلایل ردشدگی (bad_timestamp/bad_signature/unknown_network/invalid_user + server_error) */
    public const REJECT_BAD_TIMESTAMP   = 'bad_timestamp';
    public const REJECT_BAD_SIGNATURE   = 'bad_signature';
    public const REJECT_UNKNOWN_NETWORK = 'unknown_network';
    public const REJECT_INVALID_USER    = 'invalid_user';
    public const REJECT_SERVER_ERROR    = 'server_error';

    protected array $fillable = [
        'network', 'outcome', 'reject_reason', 'user_id', 'txid_hash',
        'payout_amount', 'currency', 'http_status', 'ip',
    ];

    /**
     * ثبت یک رویداد S2S — از دید وب‌هوک best-effort است و می‌تواند استثنا بدهد؛
     * لایهٔ کنترلر مسئول پوشش try/catch و فقط-لاگ‌کردن شکست است.
     *
     * @param S2sEventRow $data
     */
    public function record(array $data): void
    {
        $outcome = str_value($data['outcome'] ?? '');
        if (!in_array($outcome, self::OUTCOMES, true)) {
            $outcome = self::OUTCOME_REJECTED; // fail-safe: هر چیز ناشناخته‌ای «ردشده» است
        }

        $stmt = $this->db->prepare("
            INSERT INTO s2s_hook_events
                (network, outcome, reject_reason, user_id, txid_hash, payout_amount, currency, http_status, ip)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            str_value($data['network'] ?? ''),
            $outcome,
            $data['reject_reason'] ?? null,
            isset($data['user_id']) && (int)$data['user_id'] > 0 ? (int)$data['user_id'] : null,
            isset($data['txid_hash']) && str_value($data['txid_hash']) !== '' ? str_value($data['txid_hash']) : null,
            isset($data['payout_amount']) && $data['payout_amount'] !== null ? (string)$data['payout_amount'] : null,
            isset($data['currency']) && str_value($data['currency']) !== '' ? strtolower(str_value($data['currency'])) : null,
            (int)($data['http_status'] ?? 0),
            isset($data['ip']) && str_value($data['ip']) !== '' ? str_value($data['ip']) : null,
        ]);
    }

    /**
     * آمار تجمیعی به تفکیک شبکه در پنجرهٔ N روز گذشته.
     *
     * خروجی: فهرستِ
     *   network, attempts, credited, replays, rejected,
     *   rejects  => map(reason => count)          — فقط ردشده‌ها
     *   payouts  => map(currency => sum)          — فقط credited (پاداشِ واقعی پرداخت‌شده)
     *
     * @return list<array<string, mixed>>
     */
    public function networkStats(int $days = 30): array
    {
        $days = max(1, $days);

        $stmt = $this->db->prepare("
            SELECT network,
                   COUNT(*) AS attempts,
                   COALESCE(SUM(CASE WHEN outcome = 'credited' THEN 1 ELSE 0 END), 0) AS credited,
                   COALESCE(SUM(CASE WHEN outcome = 'replay'   THEN 1 ELSE 0 END), 0) AS replays,
                   COALESCE(SUM(CASE WHEN outcome = 'rejected' THEN 1 ELSE 0 END), 0) AS rejected
            FROM s2s_hook_events
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
            GROUP BY network
            ORDER BY attempts DESC, network ASC
        ");
        $stmt->bindValue(1, $days, \PDO::PARAM_INT);
        $stmt->execute();
        /** @var list<\stdClass> $rows */
        $rows = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        // تبارش دلیل‌های ردشدگی و مجموع پاداش از کوئری‌های جانبی
        $rejectsByNetwork = [];
        $stmt = $this->db->prepare("
            SELECT network, reject_reason, COUNT(*) AS cnt
            FROM s2s_hook_events
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) AND outcome = 'rejected'
            GROUP BY network, reject_reason
        ");
        $stmt->bindValue(1, $days, \PDO::PARAM_INT);
        $stmt->execute();
        foreach (($stmt->fetchAll(\PDO::FETCH_OBJ) ?: []) as $r) {
            $reason = (string)($r->reject_reason ?? 'unknown');
            $rejectsByNetwork[(string)$r->network][$reason] = (int)$r->cnt;
        }

        $payoutsByNetwork = [];
        $stmt = $this->db->prepare("
            SELECT network, currency, SUM(payout_amount) AS total
            FROM s2s_hook_events
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) AND outcome = 'credited'
            GROUP BY network, currency
        ");
        $stmt->bindValue(1, $days, \PDO::PARAM_INT);
        $stmt->execute();
        foreach (($stmt->fetchAll(\PDO::FETCH_OBJ) ?: []) as $r) {
            $currency = strtolower((string)($r->currency ?? 'irt'));
            $payoutsByNetwork[(string)$r->network][$currency] = (string)$r->total;
        }

        $stats = [];
        foreach ($rows as $r) {
            $network = (string)$r->network;
            $stats[] = [
                'network'  => $network,
                'attempts' => (int)$r->attempts,
                'credited' => (int)$r->credited,
                'replays'  => (int)$r->replays,
                'rejected' => (int)$r->rejected,
                'rejects'  => $rejectsByNetwork[$network] ?? [],
                'payouts'  => $payoutsByNetwork[$network] ?? [],
            ];
        }
        return $stats;
    }

    /**
     * آمار کل پنجرهٔ N روز: مجموع‌ها + نرخ پذیرش (credited/attempts) +
     * شایع‌ترین دلیل ردشدگی + مجموع پاداش به تفکیک ارز.
     *
     * @return array<string, mixed>
     */
    public function overallStats(int $days = 30): array
    {
        $days = max(1, $days);

        $stmt = $this->db->prepare("
            SELECT COUNT(*) AS attempts,
                   COALESCE(SUM(CASE WHEN outcome = 'credited' THEN 1 ELSE 0 END), 0) AS credited,
                   COALESCE(SUM(CASE WHEN outcome = 'replay'   THEN 1 ELSE 0 END), 0) AS replays,
                   COALESCE(SUM(CASE WHEN outcome = 'rejected' THEN 1 ELSE 0 END), 0) AS rejected
            FROM s2s_hook_events
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
        ");
        $stmt->bindValue(1, $days, \PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC) ?: [];

        $attempts = (int)($row['attempts'] ?? 0);
        $credited = (int)($row['credited'] ?? 0);

        // شایع‌ترین دلیل ردشدگی
        $stmt = $this->db->prepare("
            SELECT reject_reason, COUNT(*) AS cnt
            FROM s2s_hook_events
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) AND outcome = 'rejected'
            GROUP BY reject_reason
            ORDER BY cnt DESC, reject_reason ASC
            LIMIT 1
        ");
        $stmt->bindValue(1, $days, \PDO::PARAM_INT);
        $stmt->execute();
        $topReject = $stmt->fetch(\PDO::FETCH_OBJ);

        // مجموع پاداشِ واقعاً پرداخت‌شده (فقط credited) به تفکیک ارز
        $stmt = $this->db->prepare("
            SELECT currency, SUM(payout_amount) AS total
            FROM s2s_hook_events
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) AND outcome = 'credited'
            GROUP BY currency
        ");
        $stmt->bindValue(1, $days, \PDO::PARAM_INT);
        $stmt->execute();
        $payouts = [];
        foreach (($stmt->fetchAll(\PDO::FETCH_OBJ) ?: []) as $r) {
            $payouts[strtolower((string)($r->currency ?? 'irt'))] = (string)$r->total;
        }

        return [
            'attempts'          => $attempts,
            'credited'          => $credited,
            'replays'           => (int)($row['replays'] ?? 0),
            'rejected'          => (int)($row['rejected'] ?? 0),
            'acceptance_rate'   => $attempts > 0 ? round($credited * 100.0 / $attempts, 1) : 0.0,
            'top_reject_reason' => $topReject !== false && $topReject !== null ? (string)$topReject->reject_reason : null,
            'payouts'           => $payouts,
        ];
    }

    /**
     * تازه‌ترین رویدادها برای جدول ادمین.
     *
     * @return list<\stdClass>
     */
    public function recent(int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        $stmt = $this->db->prepare("
            SELECT *
            FROM s2s_hook_events
            ORDER BY id DESC
            LIMIT ?
        ");
        $stmt->bindValue(1, $limit, \PDO::PARAM_INT);
        $stmt->execute();
        /** @var list<\stdClass> */
        return $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
    }
}
