<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * 🛡️ FIX-SEO-23-01 (فاز ۲ — دکمهٔ تست یکپارچگی): رفت‌وبرگشت تست پیکسل/پست‌بک.
 *
 * تبلیغ‌دهنده‌ای که حالت اثبات فرود (pixel/postback) را فعال کرده باید بتواند
 * پیاده‌سازی خودش را بدون اجرای واقعی تسکِ کاربر، راستی‌آزمایی کند. این مدل
 * چرخهٔ تست را نگه می‌دارد: صدور توکن موقت → استقرار کد سمت تبلیغ‌دهنده →
 * رسیدن همان پیکسل/پست‌بک (کانال‌های عمومی ابتدا seo_executions را می‌بینند،
 * سپس این جدول) → نمایش وضعیت «دریافت شد» در صفحهٔ جزئیات آگهی.
 *
 * ردیف‌های تست هرگز با اجراهای واقعی کاربران ترکیب نمی‌شوند؛ پاکسازی ردیف‌های
 * منقضی رویِ خواندنِ بعدی (best-effort) انجام می‌شود.
 */
class SeoLandingProofTest extends Model
{
    protected static string $table = 'seo_landing_proof_tests';

    /** پنجرهٔ اعتبار تست (ثانیه) — ۱۰ دقیقه */
    public const TEST_TOKEN_TTL_SECONDS = 600;

    /**
     * صدور توکن تست برای آگهی (مالکیت در سرویس بررسی می‌شود).
     *
     * @return array{token: string, expires_at: string}
     */
    public function issue(int $adId): array
    {
        $token = bin2hex(random_bytes(24)); // 48 هگز — هم‌قالب nonce مسیر go
        $stmt = $this->db->prepare(
            "INSERT INTO seo_landing_proof_tests (ad_id, token, expires_at)
             VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND))"
        );
        $stmt->execute([$adId, $token, self::TEST_TOKEN_TTL_SECONDS]);
        $row = $this->findByToken($token);
        return ['token' => $token, 'expires_at' => $row !== null ? $row['expires_at'] : ''];
    }

    /**
     * یافتن ردیف تست با توکن (بدون تغییر وضعیت).
     *
     * @return array{id: int, ad_id: int, token: string, expires_at: string, received_at: ?string, channel: ?string, ip: ?string}|null
     */
    public function findByToken(string $token): ?array
    {
        if ($token === '' || strlen($token) > 64) {
            return null;
        }
        $stmt = $this->db->prepare(
            "SELECT id, ad_id, token, expires_at, received_at, channel, ip
             FROM seo_landing_proof_tests WHERE token = ?"
        );
        $stmt->execute([$token]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            return null;
        }
        return [
            'id'          => int_value($row['id'] ?? 0),
            'ad_id'       => int_value($row['ad_id'] ?? 0),
            'token'       => str_value($row['token'] ?? ''),
            'expires_at'  => str_value($row['expires_at'] ?? ''),
            'received_at' => is_string($row['received_at'] ?? null) ? $row['received_at'] : null,
            'channel'     => is_string($row['channel'] ?? null) ? $row['channel'] : null,
            'ip'          => is_string($row['ip'] ?? null) ? $row['ip'] : null,
        ];
    }

    /**
     * مهر دریافتِ تست — idempotent: اگر قبلاً دریافت شده، فقط true برمی‌گردد
     * (کانال/زمان اولین رسیدن حفظ می‌شود؛ فراخوانی‌های تکراری بی‌اثرند).
     */
    public function markReceived(string $token, string $channel, string $ip): bool
    {
        if (!in_array($channel, ['pixel', 'postback'], true)) {
            return false;
        }
        $stmt = $this->db->prepare(
            "UPDATE seo_landing_proof_tests
             SET received_at = NOW(), channel = ?, ip = ?
             WHERE token = ? AND received_at IS NULL AND expires_at > NOW()"
        );
        $stmt->execute([$channel, $ip, $token]);
        if ($stmt->rowCount() === 1) {
            return true;
        }
        // دریافتِ تکراری/منقضی — وضعیت فعلی تعیین می‌کند
        $row = $this->findByToken($token);
        return $row !== null && $row['received_at'] !== null;
    }

    /**
     * وضعیت تست برای پنل تبلیغ‌دهنده (مالکیت در سرویس).
     *
     * @return array{found: bool, received: bool, expired: bool, channel: ?string, received_at: ?string}
     */
    public function statusFor(string $token): array
    {
        $row = $this->findByToken($token);
        if ($row === null) {
            return ['found' => false, 'received' => false, 'expired' => false, 'channel' => null, 'received_at' => null];
        }
        return [
            'found'       => true,
            'received'    => $row['received_at'] !== null,
            'expired'     => $row['received_at'] === null && strtotime($row['expires_at']) <= time(),
            'channel'     => $row['channel'],
            'received_at' => $row['received_at'],
        ];
    }

    /** پاکسازی best-effort ردیف‌های منقضیِ فراتر از یک ساعت گذشته. */
    public function purgeExpired(): void
    {
        try {
            $this->db->query(
                "DELETE FROM seo_landing_proof_tests
                 WHERE expires_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)"
            );
        } catch (\Throwable) {
            // best-effort — پاکسازی هرگز نباید مسیر اصلی را بشکند
        }
    }
}
