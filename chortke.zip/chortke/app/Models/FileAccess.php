<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class FileAccess extends Model
{
    protected static string $table = 'file_logs';

    public function sanitizeFilename(string $filename): string
    {
        $filename = \str_replace(['../', '..\\', './', '.\\'], '', $filename);
        return \basename($filename);
    }

    public function checkKycOwnership(string $filename, int $userId): bool
    {
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "SELECT user_id FROM kyc_verifications
             WHERE verification_image = ?
             ORDER BY id DESC LIMIT 1",
            [$filename]
        );

        $row = $this->fetchObject($stmt);
        return $row && (int)$row->user_id === $userId;
    }

    public function checkReceiptOwnership(string $filename, int $userId): bool
    {
        // 🛡️ FIX-FILEACCESS-01 (D4-N1 خانواده): ستون receipt_image هرگز در
        // manual_deposits وجود نداشت — ستون زندهٔ سرویس ManualDepositService
        // receipt_path است و مقدار «receipts/<hash>.<ext>» ذخیره می‌کند
        // (RECEIPT_PATH_PATTERN). کوئری قبلی ⇒ خطای SQL «Unknown column» روی هر
        // چکِ غیرادمینی. هم‌الگوی N10: مقایسه روی basename ستون.
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "SELECT user_id FROM manual_deposits
             WHERE SUBSTRING_INDEX(receipt_path, '/', -1) = ?
             ORDER BY id DESC LIMIT 1",
            [$filename]
        );

        $row = $this->fetchObject($stmt);
        return $row && (int)$row->user_id === $userId;
    }

    public function checkTaskProofOwnership(string $filename, int $userId): bool
    {
        // 🛡️ FIX-M22-MED (N10/D3-N17): کوئری قبلی روی ستون ناموجود task_executions.ads_id
        // (ستون واقعی advertisement_id است) و proof_image می‌زد → هر دسترسی غیرادمین
        // به /file/view/task-proofs/ خطای SQL می‌گرفت. مالکیت مدرک تسک سفارشی از
        // custom_task_submissions.proof_file خوانده می‌شود (لینک‌های M22-05 سالم بمانند).
        $filename = $this->sanitizeFilename($filename);
        // 🛡️ FIX-M22-MED (N10/E2-review): پارامتر filename از FileController با
        // basename می‌آید (regex 24hex.ext) ولی ستون proof_file همیشه با پیشوند
        // پوشه ذخیره می‌شود («task-proofs/24hex.ext») — مقایسهٔ مستقیم هرگز match
        // نمی‌شد و دسترسی مجری/کارفرما به مدرک همیشه ۴۰۳ می‌شد.
        // 🚀 FIX-V22-04a (بازبینی ۲۲): مقایسه روی ستون generated ایندکس‌پذیر
        // proof_file_basename انجام می‌شود (SUBSTRING_INDEX در تعریف ستون —
        // migration 2026_11_08_0001). کوئری قبلیِ SUBSTRING_INDEX(proof_file,'/',-1)
        // در WHERE غیرقابل ایندکس بود و با رشد جدول ارسال‌ها، هر بازدید مدرک یک
        // full-table-scan می‌ساخت. عقد قرارداد جدید: ستون generated همیشه هم‌ارزش
        // basename واقعی است (DB خودش نگه می‌دارد) پس معنای مالکیت تغییر نکرده.
        $stmt = $this->db->query(
            "SELECT s.worker_id, a.user_id
             FROM custom_task_submissions s
             JOIN ads a ON a.id = s.task_id
             WHERE s.proof_file_basename = ?
             ORDER BY s.id DESC LIMIT 1",
            [$filename]
        );

        $row = $this->fetchObject($stmt);
        return $row && ((int)$row->worker_id === $userId || (int)$row->user_id === $userId);
    }

    public function checkTaskSampleOwnership(string $filename, int $userId): bool
    {
        // 🛡️ FIX-FILEACCESS-02: کوئری‌های قبلی روی جدول legacyِ custom_tasks
        // می‌زدند که نه ستون sample_image دارد و نه هیچ writer زنده‌ای (ماژول ۲۲
        // روی ads اجرا می‌شود — مستند FIX-M22-MED N7/D3-N6) و cts.user_id نیز
        // ستون legacy بدون نویسنده بود (ستون زنده worker_id است). بازنویسی
        // هم‌قرارداد checkAdTaskSampleOwnership روی منابع زنده: سازنده از
        // ads.user_id و مجری از custom_task_submissions.worker_id (task_id→ads.id).
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "SELECT user_id FROM ads
             WHERE type = 'custom_task' AND SUBSTRING_INDEX(sample_image, '/', -1) = ?
             LIMIT 1",
            [$filename]
        );

        $row = $this->fetchObject($stmt);

        if ($row && (int)$row->user_id === $userId) {
            return true;
        }

        $stmt = $this->db->query(
            "SELECT s.id FROM custom_task_submissions s
             JOIN ads a ON a.id = s.task_id
             WHERE a.type = 'custom_task'
               AND SUBSTRING_INDEX(a.sample_image, '/', -1) = ?
               AND s.worker_id = ?
             LIMIT 1",
            [$filename, $userId]
        );

        $submission = $this->fetchObject($stmt);
        return (bool) $submission;
    }

    public function checkAdTaskSampleOwnership(string $filename, int $userId): bool
    {
        // 🛡️ FIX-FILEACCESS-03 (D4-N1): ستون task_executions.ads_id وجود ندارد
        // (ستون واقعی advertisement_id است — همان خانوادهٔ N10 در
        // checkTaskProofOwnership) ⇒ مسیر «مجریِ آگهی» همیشه خطای SQL می‌گرفت.
        // مقایسهٔ sample_image هم basename-امن شد (ستون ممکن است با پیشوند
        // پوشه ذخیره شود — هم‌الگوی proof_file).
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "SELECT user_id FROM ads
             WHERE SUBSTRING_INDEX(sample_image, '/', -1) = ?
             LIMIT 1",
            [$filename]
        );

        $row = $this->fetchObject($stmt);
        if ($row && (int)$row->user_id === $userId) {
            return true;
        }

        $stmt = $this->db->query(
            "SELECT te.id FROM task_executions te
             JOIN ads a ON a.id = te.advertisement_id
             WHERE SUBSTRING_INDEX(a.sample_image, '/', -1) = ? AND te.executor_id = ?
             LIMIT 1",
            [$filename, $userId]
        );

        $executor = $this->fetchObject($stmt);
        return (bool) $executor;
    }

    public function checkDisputeEvidenceOwnership(string $filename, int $userId): bool
    {
        // 🛡️ FIX-FILEACCESS-04 (D4-N1): کوئری قبلی روی دو ستون ناموجودِ
        // task_executions می‌زد (ads_id و dispute_evidence — دومی جدول مستقل
        // است نه ستون) ⇒ همیشه خطای SQL. محل واقعی ذخیرهٔ پیوست‌های اختلاف
        // dispute_messages.attachment است (آپلود InfluencerController از پوشهٔ
        // dispute-evidence → DisputeCommandService::sendMessage). مجاز: فرستندهٔ
        // پیام یا هر یک از طرفین پرونده (user_id/target_user_id) — گفت‌وگوی
        // اختلاف برای هر دو طرف قابل مشاهده است؛ ادمین از قبل در checkAccess
        // پاس می‌شود. هم‌الگوی N10: مقایسه روی basename ستون.
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "SELECT dm.user_id AS sender_id, d.user_id AS opener_id, d.target_user_id AS target_id
             FROM dispute_messages dm
             JOIN disputes d ON d.id = dm.dispute_id
             WHERE dm.attachment IS NOT NULL
               AND SUBSTRING_INDEX(dm.attachment, '/', -1) = ?
             ORDER BY dm.id DESC LIMIT 1",
            [$filename]
        );

        $row = $this->fetchObject($stmt);
        return $row && (
            (int)$row->sender_id === $userId
            || (int)$row->opener_id === $userId
            || (int)$row->target_id === $userId
        );
    }

    public function checkStoryProofOwnership(string $filename, int $userId): bool
    {
        // 🛡️ FIX-BEHAV1-07 (A3-N1): پنجمین گارد هم‌الگوی FILEACCESS (D4-N1).
        // ستون proof_screenshot وجود دارد ولی نویسنده‌ها (Api/InfluencerController:440
        // و User/InfluencerController:372 از UploadService::upload) مقدارِ
        // «inf-proof/<hash>.<ext>» ذخیره می‌کنند (buildDest: relativePath =
        // folder/filename) و پارامتر اینجا از FileController با basename می‌آید ⇒
        // مقایسهٔ «ستونِ پیشونددار = basename» هرگز برابر نمی‌شد و
        // /file/view/inf-proof/* همیشه ۴۰۳ می‌شد. هم‌الگوی FIX-FILEACCESS-01:
        // مقایسه روی basenameِ ستون.
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "SELECT customer_id, influencer_user_id
             FROM story_orders
             WHERE SUBSTRING_INDEX(proof_screenshot, '/', -1) = ?
             ORDER BY id DESC LIMIT 1",
            [$filename]
        );

        $row = $this->fetchObject($stmt);
        return $row && ((int)$row->customer_id === $userId || (int)$row->influencer_user_id === $userId);
    }

    public function checkStoryMediaOwnership(string $filename, int $userId): bool
    {
        $filename = $this->sanitizeFilename($filename);
        $escaped = \addcslashes($filename, '%_\\'); // FIX-S5-2: '\' escaped (S5-1 family)
        $stmt = $this->db->query(
            "SELECT customer_id, influencer_user_id
             FROM story_orders
             WHERE media_path LIKE ?
             ORDER BY id DESC LIMIT 1",
            ['%' . $escaped]
        );

        $row = $this->fetchObject($stmt);
        return $row && ((int)$row->customer_id === $userId || (int)$row->influencer_user_id === $userId);
    }

    public function checkInfluencerProfileOwnership(string $filename, int $userId): bool
    {
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "SELECT user_id FROM influencer_profiles
             WHERE profile_image = ?
             LIMIT 1",
            [$filename]
        );

        $row = $this->fetchObject($stmt);
        return $row && (int)$row->user_id === $userId;
    }

    public function checkMessageAttachmentOwnership(string $filename, int $userId): bool
    {
        // M-14 FIX: direct-message attachments live in the private 'messages' folder but had no
        // per-folder authorization branch, so FileAccessService fell through to the default deny
        // (breaking legitimate access) while leaving no positive ownership rule. A DM attachment
        // may only be served to the two parties of the conversation it belongs to. Match the
        // served hashed filename against the stored file_path and require the requester to be the
        // sender or the recipient of the owning message.
        $filename = $this->sanitizeFilename($filename);
        if ($filename === '') {
            return false;
        }
        $escaped = \addcslashes($filename, '%_\\'); // FIX-S5-2: '\' escaped (S5-1 family)
        $stmt = $this->db->query(
            "SELECT dm.id
             FROM message_attachments ma
             JOIN direct_messages dm ON dm.id = ma.message_id
             WHERE ma.file_path LIKE ?
               AND (dm.sender_id = ? OR dm.recipient_id = ?)
             ORDER BY ma.id DESC LIMIT 1",
            ['%' . $escaped . '%', $userId, $userId]
        );

        $row = $this->fetchObject($stmt);
        return (bool)$row;
    }

    public function checkTicketAttachmentOwnership(string $filename, int $userId): bool
    {
        $filename = $this->sanitizeFilename($filename);
        $escaped = \addcslashes($filename, '%_\\'); // FIX-S5-2: '\' escaped (S5-1 family)
        $stmt = $this->db->query(
            "SELECT t.user_id
             FROM ticket_messages tm
             JOIN tickets t ON t.id = tm.ticket_id
             WHERE tm.attachments LIKE ?
             ORDER BY tm.id DESC LIMIT 1",
            ['%' . $escaped . '%']
        );

        $row = $this->fetchObject($stmt);
        return $row && (int)$row->user_id === $userId;
    }

    public function logFileAccess(string $folder, string $filename, int $userId, string $action, string $ip): bool
    {
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "INSERT INTO file_logs
             (folder, filename, viewer_id, action, ip_address, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())",
            [$folder, $filename, $userId, $action, $ip]
        );

        return $stmt->rowCount() > 0;
    }

    public function logDeniedFileAccess(string $folder, string $filename, int $userId, string $ip): bool
    {
        $filename = $this->sanitizeFilename($filename);
        $stmt = $this->db->query(
            "INSERT INTO file_logs
             (folder, filename, viewer_id, action, ip_address, created_at)
             VALUES (?, ?, ?, 'denied', ?, NOW())",
            [$folder, $filename, $userId, $ip]
        );

        return $stmt->rowCount() > 0;
    }
}