<?php

namespace App\Models;

use Core\Model;

class PaymentLog extends Model
{
    protected static string $table = 'payment_logs';

    /**
     * FIX-18O (P2): whitelist ستون‌های واقعی payment_logs (شمای زنده:
     * user_id, gateway, amount, currency, payload, status, authority, ref_id,
     * request_data, response_data, paid_at, bank_card_id, idempotency_key,
     * created_at, updated_at). ستون id عمداً نیست.
     */
    protected array $fillable = [
        'user_id', 'gateway', 'amount', 'currency', 'payload',
        'status', 'authority', 'ref_id', 'request_data', 'response_data',
        'paid_at', 'bank_card_id', 'idempotency_key',
        'created_at', 'updated_at',
    ];

    public function findByAuthority(string $authority): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT * FROM `" . static::$table . "` WHERE authority = ? LIMIT 1",
            [$authority]
        ) ?: null;
    }

    /** @return list<\stdClass> */
    public function getUserPayments(int $userId, int $limit = 20): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM `" . static::$table . "`
             WHERE user_id = ?
             ORDER BY created_at DESC
             LIMIT ?",
            [$userId, $limit]
        );
    }

    /** @return list<\stdClass> */
    public function getSuccessfulPayments(int $userId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM `" . static::$table . "`
             WHERE user_id = ? AND status IN ('verified','completed')
             ORDER BY created_at DESC",
            [$userId]
        );
    }

    public function sumPayments(int $userId, string $status = 'completed'): string
    {
        return (string)$this->db->fetchColumn(
            "SELECT COALESCE(SUM(amount),0) FROM `" . static::$table . "`
             WHERE user_id = ? AND status = ?",
            [$userId, $status]
        );
    }
}
