<?php

namespace App\Models;

use Core\Model;
use Core\Database;

class LotteryChanceLog extends Model {

    protected static string $table = 'lottery_chance_logs';

    /** 🛡️ FIX-S16-11 (بچ S16): سفیدلیست ستون‌های lottery_chance_logs — کلیدهای
     * مجاز = دقیقاً آرایهٔ ثابتی که UpdateLotteryChanceScoresJob می‌سازد. */
    private const ALLOWED_COLUMNS = [
        'participation_id', 'user_id', 'round_id', 'date',
        'score_before', 'score_change', 'score_after', 'reason',
        // FIX-R36-W3 (F-A6b-07): 'details' یک ستون واقعی جدول است (varchar 255،
        // SHOW COLUMNS تأیید) و Job آن را می‌سازد (selected/matched و یادداشت no-vote)
        // ولی این سفیدلیست بی‌صدا drop می‌کرد — مدرک تطبیق رأی از لجر ممیزی گم می‌شد.
        'details',
        'created_at',
    ];

/**
     * ثبت لاگ تغییر شانس
     * خروجی: id یا null
     */
    /** @param array<string, mixed> $data */
    public function create(array $data): ?int
    {
        $now = \date('Y-m-d H:i:s');

        // اگر جدول این ستون‌ها را دارد
        $data['created_at'] = $data['created_at'] ?? $now;

        $filtered = [];
        foreach (self::ALLOWED_COLUMNS as $col) {
            if (\array_key_exists($col, $data)) {
                $filtered[$col] = $data[$col];
            }
        }

        $columns = \array_keys($filtered);
        $values  = \array_values($filtered);

        $placeholders = \array_fill(0, \count($columns), '?');
        $colsSql = '`' . \implode('`,`', $columns) . '`';

        $sql = "INSERT INTO `lottery_chance_logs` ({$colsSql}) VALUES (" . \implode(',', $placeholders) . ")";

        $stmt = $this->db->prepare($sql);
        $ok = $stmt->execute($values);

        if (!$ok) {
            return null;
        }

        $id = (int)$this->db->lastInsertId();
        return $id > 0 ? $id : null;
    }

    /** @return list<\stdClass> */
    public function getByParticipation(int $participationId, int $limit = 30): array
    {
        $limit = \max(1, (int)$limit);

        $stmt = $this->db->prepare(
            "SELECT * FROM lottery_chance_logs
             WHERE participation_id = ?
             ORDER BY date DESC
             LIMIT ?"
        );
        $stmt->bindValue(1, $participationId, \PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * FIX-R36-W3 (F-A6b-05): processed marker برای UpdateLotteryChanceScoresJob —
     * وجود ردیف chance-log برای (participation_id, date) یعنی تسویهٔ روزانهٔ شانس
     * همین شرکت‌کننده قبلاً اجرا و commit شده؛ re-run کرون باید او را skip کند.
     * (پوشش ایندکس idx_lcl_participation_date — lookup ارزان.)
     */
    public function existsForParticipationDate(int $participationId, string $date): bool
    {
        $stmt = $this->db->prepare(
            "SELECT 1 FROM lottery_chance_logs WHERE participation_id = ? AND date = ? LIMIT 1"
        );
        $stmt->execute([$participationId, $date]);
        return $stmt->fetchColumn() !== false;
    }

    /**
     * FIX-F-06: claim اتمیک روزانهٔ شانس — همان ردیف لاگ، هم marker است.
     *
     * با قید UNIQUE (participation_id, date) (migration 2026_10_01_0002)، دو اجرای
     * هم‌پوشان دیگر نمی‌توانند هر دو claim بزنند؛ خطای 1062 = قبلاً پردازش شده →
     * null. داخل تراکنشِ handle() اجرا می‌شود، پس شکست مراحل بعد (لجر/پارتی‌سیپیشن)
     * claim را هم rollback می‌کند و retryهای بعدی آزاد می‌مانند.
     *
     * @param array<string, mixed> $data همان ساختار create()
     */
    public function claimForParticipationDate(array $data): ?int
    {
        try {
            return $this->create($data);
        } catch (\PDOException $e) {
            $driverCode = (string)($e->errorInfo[1] ?? '');
            if ($driverCode === '1062' || $driverCode === '1586' || str_contains($e->getMessage(), 'Duplicate entry')) {
                return null; // concurrent run already claimed this (participation, date)
            }
            throw $e;
        }
    }
}