<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;
use App\Enums\ScoreDomain;

/**
 * Score Model - مدل اشتراکی امتیازات
 * 
 * Consolidated from: UserScoreEvent.php, UserScoreAdjustment.php, Score.php
 * 
 * این مدل تمام عملیات امتیازدهی را مدیریت می‌کند:
 * - ثبت رویدادهای امتیازدهی (events)
 * - اعمال تنظیمات امتیاز (adjustments)
 * - محاسبه امتیازات موثر (effective scores)
 * 
 * 🛡️ H-3 Fix: addEvent() همیشه به DB می‌نویسد (مسیر اصلی و قابل اطمینان)
 *              Single write path → فقط DB (Redis buffer حذف شد)
 * 
 * جداول: score_events, user_score_adjustments (legacy), user_score_events (legacy)
 */
class Score extends Model
{
    protected static string $table = 'score_events';

    protected array $fillable = ['entity_type', 'entity_id', 'domain', 'delta', 'source', 'meta', 'created_at'];

    public const DOMAIN_FRAUD = 'fraud';
    public const DOMAIN_TASK = 'task';
    public const DOMAIN_SOCIAL_TRUST = 'social_trust';
    public const DOMAIN_REFERRAL = 'referral';
    public const DOMAIN_ACTIVITY = 'activity';
    public const DOMAIN_LOYALTY = 'loyalty';

    public static function normalizeDomain(string $domain): string
    {
        $normalized = ScoreDomain::normalize($domain);
        if (!ScoreDomain::isValid($normalized)) {
            throw new \InvalidArgumentException("Unsupported score domain: {$domain}");
        }
        return $normalized;
    }

    /** @return list<string> */

    public static function allowedDomains(): array
    {
        return ScoreDomain::values();
    }

    // ==========================================
    // Event Management (from UserScoreEvent)
    // ==========================================

    // FIX-DEAD-METHOD (راند ۹۱): createEvent حذف شد — مسیرِ نوشتنِ لجر فقط
    // ScoreCommandService::applyDelta/applySystemDelta است (تک‌مسیرِ
    // addEvent + outbox) و این متد از همیشه بی‌فراخوان بود (grep-proof در
    // app/، tests/، routes/، config/)؛ نوشتنِ لجرِ بدون outbox، پروجکشن را
    // همیشه عقب می‌انداخت.

    /** @return list<\stdClass> */
    public function getEventsByUser(int $userId, ?string $domain = null, int $limit = 200): array
    {
        $limit = \max(1, (int)$limit);
        $domain = $domain !== null ? self::normalizeDomain($domain) : null;
        if ($domain === null) {
            $stmt = $this->db->prepare("
                SELECT id, domain, reason, delta, metadata, created_at FROM score_events
                WHERE entity_type = 'user' AND entity_id = ?
                ORDER BY created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$userId, $limit]);
        } else {
            $stmt = $this->db->prepare("
                SELECT id, domain, reason, delta, metadata, created_at FROM score_events
                WHERE entity_type = 'user' AND entity_id = ? AND domain = ?
                ORDER BY created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$userId, $domain, $limit]);
        }

        return $this->fetchObjectList($stmt);
    }

    // ==========================================
    // Adjustment Management (from UserScoreAdjustment)
    // ==========================================

    /**
     * دریافت تنظیمات فعال امتیازدهی
     */
    /** @return list<\stdClass> */
    public function getActiveAdjustments(int $userId, string $domain): array
    {
        $domain = self::normalizeDomain($domain);
        $stmt = $this->db->prepare("
            SELECT * FROM user_score_adjustments
            WHERE user_id = ? AND domain = ? AND status = 'active'
            AND (expires_at IS NULL OR expires_at > NOW())
            ORDER BY created_at DESC
        ");
        $stmt->execute([$userId, $domain]);

        return $this->fetchObjectList($stmt);
    }

    // FIX-DEAD-METHOD (راند ۹۱): createAdjustment مدل حذف شد — صفر فراخوان
    // (grep-proof)؛ مسیر زندهٔ اصلاح ادمین ScoreService::createAdjustment است
    // که با INSERT مستقیم خودش کار می‌کند (جدول user_score_adjustments).

    /**
     * دریافت تنظیمات امتیاز کاربر
     */
    /** @return list<\stdClass> */
    public function getAdjustmentsByUser(int $userId): array
    {
        $stmt = $this->db->prepare("
            SELECT * FROM user_score_adjustments 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT 200
        ");
        $stmt->execute([$userId]);

        return $this->fetchObjectList($stmt);
    }

    // ==========================================
    // Unified Score Events (New)
    // ==========================================

    /**
     * ثبت رویداد امتیازدهی unified
     * 
     * 🛡️ H-3 Fix: همیشه مستقیم به DB می‌نویسد (منبع حقیقت = DB)
     *              Redis buffer فقط یک کپی ثانویه غیرضروری است.
     */
    /** @param array<string, mixed> $data اضافه‌کردن رویداد امتیازدهی unified — خروجی: id ردیف لجر (X380) */
    public function addEvent(array $data): int
    {
        $data['domain'] = self::normalizeDomain(str_value($data['domain'] ?? ''));

        // 🛡️ H-3 Fix: DB مسیر اصلی و همیشگی (single source of truth)
        $stmt = $this->db->prepare("
            INSERT INTO score_events (entity_type, entity_id, domain, delta, reason, metadata, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");

        $ok = $stmt->execute([
            $data['entity_type'],
            $data['entity_id'],
            $data['domain'],
            $data['delta'],
            $data['source'],
            json_encode($data['meta'] ?? [])
        ]);

        // 🛡️ X379 (راند ۹۹): با ERRMODE_EXCEPTION این شاخه عملاً مرده است؛ اما
        // رخداد میدانی 2026-09-12 12:45 (سنت‌ری issue 318 — دو بار «false نظری»
        // در applyDeltaBatch/xp_global) نشان داد اگر روزی اجرا شود، تنها اثرش
        // RuntimeException عمومیِ «batch_add_event_failed» است بدون هیچ سرنخ
        // SQL. اکنون شکست با errorInfo واقعی پرتاب می‌شود (semantics شکستِ
        // تراکنشی همان قبلی است — فقط تشخیص‌پذیر).
        if (!$ok) {
            $err = $stmt->errorInfo();
            throw new \RuntimeException(
                'score.add_event_failed: sqlstate=' . ($err[0] ?? '?')
                . ' driver_code=' . ($err[1] ?? '?')
                . ' driver_msg=' . mb_substr((string)($err[2] ?? 'unknown'), 0, 200)
            );
        }
        // 🛡️ X380 (راند ۹۹): شناسهٔ ردیف لجر برگردانده می‌شود تا رویداد outbox آن را
        // حمل کند و listener پروجکشن بتواند موجودیِ ردیف را وارسی کند (ناوردای
        // «پروجکشن هرگز از لجر جلو نمی‌زند»). تماس‌گیرنده‌ها boolean-مانند چک می‌کردند؛
        // id>0 همیشه truthy است — سازگار کامل.
        return (int)$this->db->lastInsertId();
    }

    /**
     * دریافت امتیاز کل unified
     */
    public function getTotal(int $entityId, string $entityType, string $domain): float
    {
        $domain = self::normalizeDomain($domain);
        $stmt = $this->db->prepare("
            SELECT SUM(delta) FROM score_events
            WHERE entity_id = ? AND entity_type = ? AND domain = ?
        ");
        $stmt->execute([$entityId, $entityType, $domain]);
        return (float)$stmt->fetchColumn();
    }

    public function getDomainScore(int $userId, string $domain): float
    {
        $domain = self::normalizeDomain($domain);

        // جدول یکپارچه score_events
        $stmt = $this->db->prepare("
            SELECT COALESCE(SUM(delta), 0.0) FROM score_events
            WHERE entity_id = ? AND entity_type = 'user' AND domain = ?
        ");
        $stmt->execute([$userId, $domain]);
        return (float)$stmt->fetchColumn();
    }



    /**
     * دریافت آمار هفتگی اجرا برای trust score
     */
    public function getWeeklyExecutionStats(int $userId): ?\stdClass
    {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' AND final_score >= 80 THEN 1 ELSE 0 END) as good_tasks,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN status = 'soft_approved' THEN 1 ELSE 0 END) as soft_approved,
                AVG(final_score) as avg_score
            FROM social_task_executions
            WHERE executor_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ");
        $stmt->execute([$userId]);

        return $this->fetchObject($stmt);
    }

    /**
     * ذخیره snapshot trust score
     */
    /** @param array<string, mixed> $data */
    public function saveTrustSnapshot(array $data): bool
    {
        // FIX راند ۷۷ (ستون شبح): جدول social/user_trust_snapshots فقط (user_id, score, created_at) دارد؛
        // ستون‌های trust_score/week_* هرگز وجود نداشتند. آمار هفتگی در همان لحظه از social_task_executions قابل محاسبه است.
        $stmt = $this->db->prepare("
            INSERT INTO user_trust_snapshots 
            (user_id, score, created_at)
            VALUES (?, ?, NOW())
        ");

        return $stmt->execute([
            $data['user_id'],
            $data['trust_score'] ?? ($data['score'] ?? 0),
        ]);
    }

    // ==========================================
    // Legacy Methods (for backward compatibility)
    // ==========================================

    public function getTaskRawRisk(int $userId): float
    {
        // FIX راند ۷۷ (ستون شبح): task_executions ستون fraud_score ندارد؛ امتیاز واقعی ضدتقلب
        // در social_task_executions.anti_fraud_score است (فراخوان: صفحهٔ ادمین ScoreManagement).
        $stmt = $this->db->prepare("
            SELECT COALESCE(AVG(anti_fraud_score), 0) AS avg_score
            FROM social_task_executions
            WHERE executor_id = ?
        ");
        $stmt->execute([$userId]);

        return (float)$stmt->fetchColumn();
    }

    /** @return list<\stdClass> */
    public function getRecentEvents(int $userId, int $limit = 50): array
    {
        $limit = \max(1, (int)$limit);
        // FIX-X360 (راند ۹۱): خوانندهٔ unionِ لجرِ اصلی (score_events) + دفترِ legacy
        // اصلاحات ادمین (user_score_events) — قبلاً از همیشه بی‌فراخوان بود و پنل
        // ادمین فقط user_score_events را می‌دید (کور به لجر اصلی).
        // نام ستون‌ها از SELECT اول می‌آید؛ با alias به قرارداد ویو
        // (views/admin/fraud/user-scores.php: source/meta_json) هم‌سان شد و ستون
        // origin برای تفکیک منبع هر ردیف اضافه شد.
        $stmt = $this->db->prepare("
            SELECT id, domain, reason AS source, delta, metadata AS meta_json, 'ledger' AS origin, created_at
            FROM score_events
            WHERE entity_type = 'user' AND entity_id = ?
            UNION ALL
            SELECT id, domain, source, delta, meta_json, 'admin_adjustment' AS origin, created_at
            FROM user_score_events
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$userId, $userId, $limit]);

        return $this->fetchObjectList($stmt);
    }

    // FIX-DEAD-METHOD (راند ۹۱): revokeAdjustment مدل حذف شد — صفر فراخوان
    // (grep-proof)؛ مسیر زندهٔ ابطال ScoreService::revokeScoreAdjustment است.
    // X365 (راند ۹۲): متد «فلاش بافر امتیازات» (لینک انتهایی زنجیرهٔ no-op کرون
    // راند ۹۱) نیز پران شد؛ همهٔ نوشتارهای امتیاز مستقیم به DB می‌روند.

}
