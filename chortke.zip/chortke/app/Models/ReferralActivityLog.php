<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * ReferralActivityLog — ردیف‌های جدول referral_activity_logs
 *
 * ─── هدف ────────────────────────────────────────────────────────
 * ردِ حسابرسیِ رویدادهای سیستم رفرال + منبعِ دادهٔ ضد-فارمینگ:
 * خواننده‌های موجود (ReferralService::todaySignupCountByIp و
 * ReferralCommission) روی action='signup' و شمارش per-IP-per-day
 * سوارند؛ تا راند ۸۹ این جدول صفر نویسنده داشت (شکاف R13/راند ۸۹).
 *
 * ─── قرارداد best-effort ────────────────────────────────────────
 * ثبت لاگ هرگز نباید جریان اصلی (ثبت‌نام/کمیسیون/پاداش) را بشکند:
 * log() هیچ استثنایی بیرون نمی‌دهد — هر خطا (اقدام نامعتبر، metadata
 * غیرقابل JSON، خطای DB یا CHECK(json_valid)) فقط warning لاگ می‌شود
 * و false برمی‌گردد. به همین دلیل فراخوان‌ها نیازی به try/catch ندارند.
 *
 * ─── ستون metadata ──────────────────────────────────────────────
 * WITH CHECK(json_valid(metadata)) دارد → هر مقدارِ ارسالی باید
 * JSON معتبر باشد؛ آرایهٔ خالی به‌صورت '{}' ذخیره می‌شود (هم‌سانی
 * شکلِ ردیف‌ها برای خواننده‌های بعدی).
 *
 * ─── دسترسی DB/لاگر ──────────────────────────────────────────
 * log() استاتیک است (فراخوان از سرویس‌ها بدون وابستگی). پارامترهای پنجم/ششم
 * اختیاری «هندلِ فراخوان» اند: سرویس/کنترلرِ دارای وابستگی باید $db و $logger
 * خودش را پاس دهد (قرارداد $this->db/$this->logger) تا (۱) مثل بقیهٔ مدل‌ها
 * از همان کانکشنِ تزریقی استفاده شود، (۲) در یونیت‌تست‌ها با هندل Mock قابل
 * عایق‌سازی باشد (نه نشت به DB واقعی، نه نویزِ لاگر روی خروجی تست) و (۳)
 * هشدارِ شکست از لاگرِ همان فراخوان بیاید. اگر null باشند (فراخوانِ بدون
 * وابستگی)، از کانتینر resolve می‌شود (db()/logger() — همان مسیر خانه‌ای
 * Core\Model: Container::make(Database) singleton). الگوی خانه‌ای
 * QueryBuilder ($db->table(...)->insert) حفظ شده — بدون SQL خام.
 */
class ReferralActivityLog extends Model
{
    protected static string $table = 'referral_activity_logs';

    // FIX-R89-RACTOR — فهرست بستهٔ اقدام‌های مجاز (گارد ورودی log())
    public const ACTION_SIGNUP           = 'signup';
    public const ACTION_COMMISSION       = 'commission';
    public const ACTION_MONTHLY_REWARD   = 'monthly_reward';
    public const ACTION_SETTINGS_UPDATED = 'settings_updated';
    // FIX-R90-AF — پرچم فارمینگ گیت ضد-فارمینگ ثبت‌نام (AuthController) — متادیتا: ip/count/action
    public const ACTION_FARMING_FLAG     = 'farming_flag';

    /** @var list<string> */
    private const ALLOWED_ACTIONS = [
        self::ACTION_SIGNUP,
        self::ACTION_COMMISSION,
        self::ACTION_MONTHLY_REWARD,
        self::ACTION_SETTINGS_UPDATED,
        self::ACTION_FARMING_FLAG,
    ];

    /**
     * ثبت best-effort یک ردیف فعالیت رفرال.
     *
     * محافظت‌های ورودی: action باید در فهرست بستهٔ مجاز باشد؛ action
     * (۵۰ نویسه) و ip (۴۵ نویسه) دفاعی بریده می‌شوند تا INSERT هرگز
     * به‌خاطر طول ستون نشکند؛ metadata با JSON_UNESCAPED_UNICODE|
     * JSON_UNESCAPED_SLASHES encode و با JSON_THROW_ON_ERROR اعتبار
     * سنجی می‌شود (مثل float INF/NAN → false بدون استثنا).
     * user_id=0 یعنی «کنشگر نامشخص» (مثلاً مسیر CLI) — ستون NOT NULL است.
     *
     * @param array<string, mixed> $metadata
     * @param \Core\Database|null $db هندلِ فراخوان (الگوی $this->db)؛ null → resolve از کانتینر
     * @param \App\Contracts\LoggerInterface|null $logger لاگرِ فراخوان (الگوی $this->logger)؛ null → logger() سراسری
     */
    public static function log(int $userId, string $action, ?string $ipAddress = null, array $metadata = [], ?\Core\Database $db = null, ?\App\Contracts\LoggerInterface $logger = null): bool
    {
        try {
            if (!in_array($action, self::ALLOWED_ACTIONS, true)) {
                return false;
            }

            // CHECK(json_valid(metadata)) ستون — رشتهٔ خالی/آرایهٔ خالی → '{}' هم‌شکل
            $json = $metadata === []
                ? '{}'
                : json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);

            $handle = $db ?? db();

            $handle->table(self::$table)->insert([
                'user_id'    => $userId,
                'action'     => mb_substr($action, 0, 50),
                'ip_address' => ($ipAddress !== null && $ipAddress !== '') ? substr($ipAddress, 0, 45) : null,
                'metadata'   => $json,
            ]);
            return true;
        } catch (\Throwable $e) {
            // best-effort واقعی: شکست لاگ فقط warning می‌شود و هرگز پرتاب نمی‌گردد
            // (لاگرِ فراخوان اول — در یونیت‌تست Mock است و بی‌صدا بلعیده می‌شود)
            try {
                ($logger ?? logger())->warning('referral.activity_log_failed', [
                    'user_id' => $userId,
                    'action'  => $action,
                    'error'   => $e->getMessage(),
                ]);
            } catch (\Throwable) {
                // لاگر هم در دسترس نیست — سکوت امن
            }
            return false;
        }
    }
}
