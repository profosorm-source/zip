<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * CustomTaskAnalyticsModel - Custom Task Analytics, Performance Dashboards & Stats Data Access Layer
 */
class CustomTaskAnalyticsModel extends Model
{
    protected static string $table = 'task_analytics';
    /** @return list<array<string, mixed>> */
    public function analytics_getTrendingTasks(int $limit = 10): array
    {
        $limit = \max(1, $limit);
        // FIX-R36-W3 (F-A19b-10): جدول ads چندریختی است (social_task/banner/
        // custom_task) — فیلتر type='custom_task' جا افتاده بود و ترندینگ بنر و
        // تسک اجتماعی را هم مخلوط می‌کرد (قرینهٔ درست: getAdminTaskStats:266).
        $stmt = $this->db->prepare(
            "SELECT id, title, user_id AS creator_id, currency, impressions AS view_count, total_budget, (total_budget - remaining_budget) AS spent_budget, completed_count, pending_count
             FROM ads
             WHERE deleted_at IS NULL AND type = 'custom_task'
             ORDER BY impressions DESC, created_at DESC
             LIMIT ?"
        );
        $stmt->execute([$limit]);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
    /** @return array<string, mixed> */

    public function analytics_getCreatorDashboard(int $userId): array
    {
        // 🛡️ FIX-M22-MED (D1-N6/T22-10): دو بازنویسی —
        //  ۱) total_budget/spent_budget بدون تفکیک ارز جمع می‌شد (IRT+USDT در یک عدد).
        //  ۲) کوئری امتیاز از task_ratings می‌خواند با ستون‌هایی که در اسکیما وجود
        //     ندارند (rated_user_id/rating_type — جدول هیچ writer ای ندارد)؛ منبع
        //     حقیقت interactions است (RatingService::rate آنجا می‌نویسد).
        $stmt = $this->db->prepare(
            "SELECT
                status,
                currency,
                COUNT(*) as count,
                SUM(CASE WHEN currency = 'usdt' THEN total_budget ELSE 0 END) as total_budget_usdt,
                SUM(CASE WHEN currency = 'irt' THEN total_budget ELSE 0 END) as total_budget_irt
            FROM ads
            WHERE user_id = ? AND deleted_at IS NULL
            GROUP BY status, currency"
        );
        $stmt->execute([$userId]);
        $tasksByStatus = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $stmt = $this->db->prepare(
            "SELECT
                COUNT(*) as total_submissions,
                SUM(CASE WHEN s.status = 'submitted' THEN 1 ELSE 0 END) as pending_review,
                SUM(CASE WHEN s.status = 'approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN s.status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                AVG(CASE
                    WHEN s.status = 'approved'
                    THEN TIMESTAMPDIFF(MINUTE, s.submitted_at, s.reviewed_at)
                    ELSE NULL
                END) as avg_review_time_minutes
            FROM custom_task_submissions s
            INNER JOIN ads t ON t.id = s.task_id
            WHERE t.user_id = ?"
        );
        $stmt->execute([$userId]);
        $submissions = $this->fetchAssoc($stmt);

        // امتیازِ کارفرما = امتیازهایی که «مجری‌ها» به او داده‌اند: ردیف‌های
        // interactions روی تسک‌های او که ارسالنده‌اش مجریِ تأییدشدهٔ همان تسک است.
        $stmt = $this->db->prepare(
            "SELECT
                AVG(i.value) as avg_rating,
                COUNT(*) as total_ratings
            FROM interactions i
            INNER JOIN ads a ON a.id = i.interactable_id
            WHERE i.interactable_type = 'custom_task'
              AND i.interaction_type = 'rating'
              AND a.user_id = ?
              AND EXISTS (
                  SELECT 1 FROM custom_task_submissions s
                  WHERE s.task_id = i.interactable_id AND s.worker_id = i.user_id AND s.status = 'approved'
              )"
        );
        $stmt->execute([$userId]);
        $rating = $this->fetchAssoc($stmt);

        return [
            'tasks_by_status' => $tasksByStatus,
            'submissions' => $submissions,
            'rating' => $rating,
        ];
    }
    /** @return array<string, mixed> */

    public function analytics_getWorkerDashboard(int $userId): array
    {
        // 🛡️ FIX-M22-MED (D1-N6/T22-10): total_earned بدون تفکیک ارز جمع می‌شد
        // (IRT+USDT در یک عدد) → دو کلید per-currency؛ و امتیاز از task_ratings با
        // ستون‌های ناموجود (rated_user_id/rating_type) خوانده می‌شد — منبع حقیقت
        // interactions است.
        // 🛡️ FIX-BEHAV1-01 (A1-N1/بالا): ستون completion_time_minutes هرگز در هیچ
        // مایگریشنی ساخته نشده (SQL 1054) ⇒ کل این کوئری — شامل totalTasks/
        // in_progress/submitted/approved/rejected/total_earned_irt/usdt — روی
        // DB واقعی می‌مُرد؛ earnNavStats (T22-20) آن را catch می‌کرد و totalDoneِ
        // _earn-nav همیشه صفر می‌ماند. زمان تکمیل از timestampهای واقعی محاسبه
        // می‌شود (هم‌الگوی avg_review_time_minutes:۶۳ و COALESCE :۱۷۵):
        // شروع = created_at (ساخت ردیف با in_progress در ExecutorService:182)،
        // پایان = COALESCE(approved_at, reviewed_at) (ردیف‌های قدیمی فقط
        // reviewed_at دارند). ستون شبح بدون writer بود؛ افزودن مایگریشن فقط
        // یک NULL دائمی دیگر می‌ساخت.
        $stmt = $this->db->prepare(
            "SELECT
                COUNT(*) as total_tasks,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) as submitted,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN status = 'approved' AND reward_currency = 'irt' THEN reward_amount ELSE 0 END) as total_earned_irt,
                SUM(CASE WHEN status = 'approved' AND reward_currency = 'usdt' THEN reward_amount ELSE 0 END) as total_earned_usdt,
                AVG(CASE
                    WHEN status = 'approved' AND COALESCE(approved_at, reviewed_at) IS NOT NULL
                    THEN TIMESTAMPDIFF(MINUTE, created_at, COALESCE(approved_at, reviewed_at))
                    ELSE NULL
                END) as avg_completion_time
            FROM custom_task_submissions
            WHERE worker_id = ?"
        );
        $stmt->execute([$userId]);
        $submissions = $this->fetchAssoc($stmt);

        // امتیازِ مجری = امتیازهایی که «کارفرماها» به او داده‌اند: ردیف‌های
        // interactions روی تسک‌هایی که مجریِ تأییدشدهٔ آن‌ها هستم، ارسالنده‌اش
        // صاحب همان تسک است.
        $stmt = $this->db->prepare(
            "SELECT
                AVG(i.value) as avg_rating,
                COUNT(*) as total_ratings
            FROM interactions i
            INNER JOIN ads a ON a.id = i.interactable_id
            WHERE i.interactable_type = 'custom_task'
              AND i.interaction_type = 'rating'
              AND a.user_id = i.user_id
              AND EXISTS (
                  SELECT 1 FROM custom_task_submissions s
                  WHERE s.task_id = i.interactable_id AND s.worker_id = ? AND s.status = 'approved'
              )"
        );
        $stmt->execute([$userId]);
        $rating = $this->fetchAssoc($stmt);

        return [
            'submissions' => $submissions,
            'rating' => $rating,
        ];
    }

    /**
     * 🛡️ FIX-M22-MED (N7/D3-N6): متریک‌های دوره‌ای تسک سفارشی از «منابع واقعی» —
     * جایگزین safeCount(custom_tasks) از جدول legacy که هیچ writer ای در جریان
     * زنده ندارد (module 22 روی ads اجرا می‌شود) و پارامتر period آن بی‌اثر بود.
     * قرارداد کلیدها: period/total_tasks/active_tasks/total_budget_irt/usdt/
     * reward_paid_irt/usdt/submissions/approved/pending/rejected/completions/
     * unique_workers.
     * معنای بازه: شمارش‌ها/وضعیت‌ها/بودجه بر پایهٔ created_at؛ پاداش‌های پرداخت‌شده
     * و مجری‌های یکتا بر پایهٔ approved_at (COALESCE reviewed_at برای ردیف‌های قدیمی).
     * @return array<string, int|float|string>
     */
    public function analytics_getCustomTaskPeriodMetrics(?string $period = 'month'): array
    {
        $period = in_array($period, ['today', 'week', 'month', 'year', 'all'], true) ? $period : 'month';
        $since = match ($period) {
            'today' => 'CURDATE()',
            'week' => "DATE_SUB(NOW(), INTERVAL 7 DAY)",
            'month' => "DATE_SUB(NOW(), INTERVAL 30 DAY)",
            'year' => "DATE_SUB(NOW(), INTERVAL 365 DAY)",
            default => null,
        };
        $adsWhere = $since !== null ? "AND a.created_at >= {$since}" : '';
        $subWhere = $since !== null ? "AND s.created_at >= {$since}" : '';
        $approvedExpr = "COALESCE(s.approved_at, s.reviewed_at, s.created_at)";
        $approvedWhere = $since !== null ? "AND {$approvedExpr} >= {$since}" : '';

        $stmt = $this->db->prepare(
            "SELECT
                COUNT(*) AS total_tasks,
                SUM(CASE WHEN a.status = 'active' THEN 1 ELSE 0 END) AS active_tasks,
                COALESCE(SUM(CASE WHEN a.currency = 'irt' THEN a.total_budget ELSE 0 END), 0) AS total_budget_irt,
                COALESCE(SUM(CASE WHEN a.currency = 'usdt' THEN a.total_budget ELSE 0 END), 0) AS total_budget_usdt
            FROM ads a
            WHERE a.type = 'custom_task' AND a.deleted_at IS NULL {$adsWhere}"
        );
        $stmt->execute();
        $taskRow = $this->fetchAssoc($stmt) ?: [];

        $stmt = $this->db->prepare(
            "SELECT
                COUNT(*) AS submissions,
                SUM(CASE WHEN s.status = 'approved' THEN 1 ELSE 0 END) AS completions,
                SUM(CASE WHEN s.status = 'in_progress' THEN 1 ELSE 0 END) + SUM(CASE WHEN s.status = 'submitted' THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN s.status = 'rejected' THEN 1 ELSE 0 END) AS rejected,
                COUNT(DISTINCT CASE WHEN s.status = 'approved' THEN s.worker_id END) AS unique_workers
            FROM custom_task_submissions s
            WHERE 1 = 1 {$subWhere}"
        );
        $stmt->execute();
        $subRow = $this->fetchAssoc($stmt) ?: [];

        $stmt = $this->db->prepare(
            "SELECT
                COALESCE(SUM(CASE WHEN s.reward_currency = 'irt' THEN
                    CASE WHEN s.status = 'approved' THEN s.reward_amount ELSE COALESCE(s.paid_amount, 0) END
                    ELSE 0 END), 0) AS reward_paid_irt,
                COALESCE(SUM(CASE WHEN s.reward_currency = 'usdt' THEN
                    CASE WHEN s.status = 'approved' THEN s.reward_amount ELSE COALESCE(s.paid_amount, 0) END
                    ELSE 0 END), 0) AS reward_paid_usdt
            FROM custom_task_submissions s
            WHERE s.status IN ('approved', 'resolved_split') {$approvedWhere}"
        );
        $stmt->execute();
        $paidRow = $this->fetchAssoc($stmt) ?: [];

        // int_value/float_value (helperهای امنِ mixed) به‌جای cast مستقیم — هم‌الگوی بچ PHPSTAN
        return [
            'period' => $period,
            'total_tasks' => int_value($taskRow['total_tasks'] ?? 0),
            'active_tasks' => int_value($taskRow['active_tasks'] ?? 0),
            'total_budget_irt' => float_value($taskRow['total_budget_irt'] ?? 0),
            'total_budget_usdt' => float_value($taskRow['total_budget_usdt'] ?? 0),
            'reward_paid_irt' => float_value($paidRow['reward_paid_irt'] ?? 0),
            'reward_paid_usdt' => float_value($paidRow['reward_paid_usdt'] ?? 0),
            'submissions' => int_value($subRow['submissions'] ?? 0),
            'approved' => int_value($subRow['completions'] ?? 0),
            'pending' => int_value($subRow['pending'] ?? 0),
            'rejected' => int_value($subRow['rejected'] ?? 0),
            'completions' => int_value($subRow['completions'] ?? 0),
            'unique_workers' => int_value($subRow['unique_workers'] ?? 0),
        ];
    }
}
