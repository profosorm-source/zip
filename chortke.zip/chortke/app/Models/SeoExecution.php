<?php

namespace App\Models;

use Core\Model;
use Core\Database;

/**
 * SeoExecution — اجرای تسک توسط Worker
 * جدول: seo_executions
 */
class SeoExecution extends Model
{
    protected static string $table = 'seo_executions';

    /** 🛡️ FIX-SEO-23-01 (فاز ۱): طول عمر پیش‌فرض nonce مسیر go (۱۵ دقیقه) */
    public const CLICK_TOKEN_TTL_SECONDS = 900;

    public int     $id;
    public int     $ad_id;              // seo_ads.id
    public int     $user_id;            // انجام‌دهنده
    public float   $time_score;         // 0-30
    public float   $scroll_score;       // 0-25
    public float   $interaction_score;  // 0-25
    public float   $quality_score;      // 0-20
    public float   $final_score;        // 0-100
    public float   $payout_amount;      // محاسبه شده
    // 🛡️ FIX-Q4-SEO23-09 (آشتی ۲۰۲۶-۱۱-۰۳): جایگاه یکتای روز برای وضعیت‌های
    // اشغال‌کننده — UNIQUE (ad_id, user_id, slot_date)؛ NULL برای cancelled/fraud/rejected.
    public ?string $slot_date = null;
    // 🛡️ FIX-Q4-SEO23-13 (آشتی): ستون‌های NULLپذیرِ اسکیما nullable شدند —
    // hydrate قبلاً مقدار خام نسبت می‌داد و یک ردیف ناسالم، کل صفحهٔ تاریخچه
    // را با TypeError ۵۰۰ می‌انداخت.
    public ?string $status = null;             // started|completed|rejected|fraud
    public ?string $engagement_data;    // JSON
    public ?string $fraud_flags;        // JSON
    public ?string $ip_address = null;
    public ?string $device_fingerprint;
    public ?string $click_token = null;
    public ?string $click_token_expires_at = null;
    public ?string $click_counted_at = null;
    public ?string $landing_verified_at = null;
    public ?string $landing_proof_channel = null;
    public ?string $session_id = null;
    public ?string $target_keyword = null;
    public ?string $rejection_reason = null;
    public ?string $cancel_reason = null;
    public ?int $fraud_score = null;
    public ?string $score_breakdown = null;
    public ?string $started_at = null;
    public ?string $completed_at;
    public ?string $created_at = null;
    public ?string $updated_at;

    // --------------------------------------------------------
    // READ
    // --------------------------------------------------------

    public function find(int $id): ?self
    {
        $stmt = $this->db->prepare("SELECT * FROM seo_executions WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $this->hydrate((array)$row) : null;
    }

    /** یافتن با قفل تراکنشی */
    public function findByIdForUpdate(int $id): ?self
    {
        $stmt = $this->db->prepare("SELECT * FROM seo_executions WHERE id = ? FOR UPDATE");
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $this->hydrate((array)$row) : null;
    }

    /** پیدا کردن با تایید مالکیت */
    public function findByUser(int $id, int $userId): ?self
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM seo_executions WHERE id = ? AND user_id = ?"
        );
        $stmt->execute([$id, $userId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $this->hydrate((array)$row) : null;
    }

    /** تاریخچه اجراها توسط یک کاربر */
    /** @return list<\stdClass> */
    public function getByUser(int $userId, int $limit = 20, int $offset = 0): array
    {
        $stmt = $this->db->prepare(
            "SELECT e.*, a.title AS ad_title, a.keyword, a.currency AS currency
             FROM seo_executions e
             LEFT JOIN ads a ON a.id = e.ad_id
             WHERE e.user_id = ?
             ORDER BY e.created_at DESC
             LIMIT ? OFFSET ?"
        );
        $stmt->bindValue(1, $userId, \PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, \PDO::PARAM_INT);
        $stmt->bindValue(3, $offset, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /** شمارش کل اجراها توسط کاربر */
    public function countByUser(int $userId): int
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM seo_executions WHERE user_id = ?"
        );
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    }

    /**
     * 🛡️ FIX-SEO3-01 (تصمیم ۱ — فعال‌سازی report/rate سئو): آیا این کاربر
     * اجرایی با یکی از وضعیت‌های داده‌شده برای این آگهی دارد؟ — گارد سمت
     * جاب (دفاع در عمق هم‌الگوی SocialTaskService::rateTask): rate فقط با
     * اجرای completed مجاز است و report با started/completed؛ کنترلرِ وب
     * مالکیت اجرا را از URL می‌سنجد ولی جاب باید خودش هم مستقل تأیید کند
     * (ادغام ad_id از ماژول دیگر / فراخوانی از کانال‌های دیگر).
     *
     * @param list<string> $statuses
     */
    public function userHasExecutionForAd(int $userId, int $adId, array $statuses): bool
    {
        $statuses = array_values(array_filter($statuses, 'is_string'));
        if ($statuses === []) {
            return false;
        }
        $placeholders = implode(',', array_fill(0, count($statuses), '?'));
        $stmt = $this->db->prepare(
            "SELECT id FROM seo_executions
             WHERE ad_id = ? AND user_id = ? AND status IN ({$placeholders})
             LIMIT 1"
        );
        $stmt->execute(array_merge([$adId, $userId], $statuses));
        return $stmt->fetchColumn() !== false;
    }

    /** اجراهای امروز کاربر */
    // 🛡️ FIX-Q4-SEO23-04 (بازگردانی آشتی بچ‌ها — ۲۰۲۶-۱۱-۰۳): سقف روزانهٔ
    // «همین کمپین» — پیاده‌سازی عین بچ Q4؛ نسخهٔ فعلی درخت پس از اعمال
    // بچ‌های سئو این متد را نداشت و StartSeoTaskJob (نسخهٔ Q4) به آن وابسته است.
    public function countByAdAndUserToday(int $adId, int $userId): int
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM seo_executions
             WHERE ad_id = ? AND user_id = ? AND DATE(created_at) = CURDATE()
               AND status IN ('started', 'completed')"
        );
        $stmt->execute([$adId, $userId]);
        return (int)$stmt->fetchColumn();
    }

    // 🛡️ FIX-M23R-02 (T23-02 — سقف روزانهٔ «کل کمپین»): شمارش همهٔ اجراهای
    // started/completed امروزِ این آگهی از همهٔ کاربران. شمارش per-user بالا
    // در کنار گیتِ یک‌بار-در-روزِ کاربر (existsByAdAndUserToday) هرگز به
    // max_per_day نمی‌رسید؛ سقفِ واقعی کمپین این شمارش است.
    public function countByAdToday(int $adId): int
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM seo_executions
             WHERE ad_id = ? AND DATE(created_at) = CURDATE()
               AND status IN ('started', 'completed')"
        );
        $stmt->execute([$adId]);
        return (int)$stmt->fetchColumn();
    }

    public function countByUserToday(int $userId): int
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM seo_executions
             WHERE user_id = ? AND DATE(created_at) = CURDATE()
               AND status IN ('started', 'completed')"
        );
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    }

    /** بررسی تکراری بودن (یک کاربر برای یک آگهی در روز) */
    public function existsByAdAndUserToday(int $adId, int $userId): bool
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM seo_executions
             WHERE ad_id = ? AND user_id = ? AND execution_date = CURDATE()
               AND status IN ('started', 'completed')"
        );
        $stmt->execute([$adId, $userId]);
        return (int)$stmt->fetchColumn() > 0;
    }

    /** محدودیت ساعتی کاربر */
    public function countByUserLastHour(int $userId): int
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM seo_executions
             WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)"
        );
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    }

    /** محدودیت IP ساعتی */
    public function countByIPLastHour(string $ip): int
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM seo_executions
             WHERE ip_address = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)"
        );
        $stmt->execute([$ip]);
        return (int)$stmt->fetchColumn();
    }

    /**
     * 🛡️ FIX-SEO-23-01 (فاز ۱ — ریدایرکت شمارنده): صدور nonce یک‌بارمصرف
     * برای مسیر ‎/seo/{id}/go/{token}‎.
     *
     * فقط وقتی توکن تازه صادر می‌کند که اجرا هنوز اثبات‌نشده باشد
     * (click_counted_at IS NULL) و توکنِ معتبری از قبل وجود نداشته باشد
     * (NULL یا منقضی). رندر دومِ همان صفحه (رفرش/دو تب) توکنِ زندهٔ قبلی را
     * برمی‌گرداند تا UX نشکند؛ اتمی‌بودن به‌واسطهٔ خودِ UPDATE است — در رقابت
     * دو رندر هم‌زمان فقط یک UPDATE موفق می‌شود و بازنده توکن برنده را از
     * DB می‌خواند.
     *
     * @return string|null توکن زنده؛ null = اجرا قبلاً اثبات شده (توکن لازم نیست)
     */
    public function issueClickToken(int $id): ?string
    {
        $token = bin2hex(random_bytes(24)); // 48 هگز — غیرقابل حدس
        $stmt = $this->db->prepare(
            "UPDATE seo_executions
             SET click_token = ?,
                 click_token_expires_at = DATE_ADD(NOW(), INTERVAL ? SECOND),
                 updated_at = NOW()
             WHERE id = ?
               AND click_counted_at IS NULL
               AND (click_token IS NULL OR click_token_expires_at <= NOW())"
        );
        $stmt->execute([$token, self::CLICK_TOKEN_TTL_SECONDS, $id]);
        if ($stmt->rowCount() === 1) {
            return $token;
        }

        // رندر دوم (توکن زنده از قبل) یا اجرای قبلاً اثبات‌شده — وضعیت از DB خوانده می‌شود
        $row = $this->find($id);
        if ($row === null || $row->click_counted_at !== null) {
            return null;
        }
        return $row->click_token;
    }

    /**
     * 🛡️ FIX-SEO-23-01 (فاز ۱): مصرف اتمیک nonce و مهرِ سرورِ کلیک.
     *
     * تک UPDATE با گاردهای کامل (مالکیت + وضعیت started + تطابق توکن +
     * مصرف‌نشده + منقضی‌نشده) — فقط اولین عبور معتبر rowCount=1 می‌دهد؛
     * بازپخش لینک، توکنِ کاربر دیگر یا اجرای بسته هرگز شمرده نمی‌شود.
     */
    public function consumeClickToken(int $id, int $userId, string $token): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE seo_executions
             SET click_counted_at = NOW(), updated_at = NOW()
             WHERE id = ? AND user_id = ? AND click_token = ? AND status = 'started'
               AND click_counted_at IS NULL AND click_token_expires_at > NOW()"
        );
        $stmt->execute([$id, $userId, $token]);
        return $stmt->rowCount() === 1;
    }

    /**
     * 🛡️ FIX-SEO-23-01 (فاز ۲): یافتن اجرا با توکن فرود (پیکسل/پست‌بک).
     *
     * جست‌وجوی مستقیم با کلیک روی ایندکس idx_seo_exec_click_token — مسیر
     * پیکسل عمومی است و نباید هیچ اسکن کامل یا خطای مبهمی تولید کند.
     * فقط ستون‌های لازم برای تصمیم‌گیری کانال برگردانده و نرمال می‌شوند
     * (شکل تختِ array — PHPStan-safe، هم‌سبک fetchAssoc خانه).
     *
     * @return array{id: int, ad_id: int, user_id: int, status: string, click_counted_at: ?string, click_token_expires_at: ?string, landing_verified_at: ?string}|null
     */
    public function findByClickToken(string $token): ?array
    {
        if ($token === '' || strlen($token) > 64) {
            return null;
        }
        $stmt = $this->db->prepare(
            "SELECT id, ad_id, user_id, status, click_counted_at,
                    click_token_expires_at, landing_verified_at
             FROM seo_executions WHERE click_token = ?"
        );
        $stmt->execute([$token]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            return null;
        }
        return [
            'id' => int_value($row['id'] ?? 0),
            'ad_id' => int_value($row['ad_id'] ?? 0),
            'user_id' => int_value($row['user_id'] ?? 0),
            'status' => str_value($row['status'] ?? ''),
            'click_counted_at' => is_string($row['click_counted_at'] ?? null) ? $row['click_counted_at'] : null,
            'click_token_expires_at' => is_string($row['click_token_expires_at'] ?? null) ? $row['click_token_expires_at'] : null,
            'landing_verified_at' => is_string($row['landing_verified_at'] ?? null) ? $row['landing_verified_at'] : null,
        ];
    }

    /**
     * 🛡️ FIX-SEO-23-01 (فاز ۲ — اثبات فرود): مصرف اتمیک توکن فرود.
     *
     * همان nonce مسیر go حالا توکن فرود هم هست: در لحظهٔ ریدایرکت به پارامتر
     * ckp آدرس هدف الصاق می‌شود و سایت تبلیغ‌دهنده با پیکسل یا پست‌بک آن را
     * برمی‌گرداند. گاردها: توکن تطبیق‌شده + کلیکِ قبلاً مهرشده (فرود بدون
     * کلیک بی‌معناست) + فرودِ هنوز‌تأییدنشده + پنجرهٔ زمانی زنده. پس از
     * تأیید، خودِ توکن پاک می‌شود (یک‌بارمصرف واقعی) و مهر landing_verified_at
     * + کانال برای ممیزی ثبت می‌شود.
     */
    public function verifyLandingProof(int $id, string $token, string $channel): bool
    {
        if (!in_array($channel, ['pixel', 'postback'], true)) {
            return false;
        }
        $stmt = $this->db->prepare(
            "UPDATE seo_executions
             SET landing_verified_at = NOW(),
                 landing_proof_channel = ?,
                 click_token = NULL,
                 updated_at = NOW()
             WHERE id = ?
               AND click_token = ?
               AND click_counted_at IS NOT NULL
               AND landing_verified_at IS NULL
               AND click_token_expires_at > NOW()"
        );
        $stmt->execute([$channel, $id, $token]);
        return $stmt->rowCount() === 1;
    }

    /** آمار کاربر */
    public function getUserStats(int $userId): object
    {
        // FIX-CY3-A2 (یافتهٔ ۲ بچ CY3): seo_executions ستون ارز ندارد و payout
        // از قیمت‌گذاری کلیدواژهٔ دو-ارزی (ads.currency) می‌آید — SUM بدون تفکیک،
        // درآمد تومانی و تتری یک کاربر را با هم می‌افکند. حالا درآمد per-currency
        // با JOIN به ارز آگهی محاسبه می‌شود؛ کلید legacy «total_earned» برای
        // سازگاری = جمع IRT (مصرف‌کنندهٔ تنهاش ویوی seo است که per-currency شد).
        $stmt = $this->db->prepare(
            "SELECT
                COUNT(*) AS total_executions,
                COUNT(CASE WHEN e.status = 'completed' THEN 1 END) AS completed,
                COALESCE(SUM(CASE WHEN e.status = 'completed' AND COALESCE(a.currency,'irt') = 'irt' THEN e.payout_amount ELSE 0 END), 0) AS total_earned_irt,
                COALESCE(SUM(CASE WHEN e.status = 'completed' AND COALESCE(a.currency,'irt') = 'usdt' THEN e.payout_amount ELSE 0 END), 0) AS total_earned_usdt,
                COALESCE(SUM(CASE WHEN e.status = 'completed' AND COALESCE(a.currency,'irt') = 'irt' THEN e.payout_amount ELSE 0 END), 0) AS total_earned,
                COALESCE(AVG(CASE WHEN e.status = 'completed' THEN e.final_score END), 0) AS avg_score
             FROM seo_executions e
             LEFT JOIN ads a ON a.id = e.ad_id
             WHERE e.user_id = ?"
        );
        $stmt->execute([$userId]);
        return $this->fetchObject($stmt) ?? (object)[
            'total_executions' => 0,
            'completed' => 0,
            'total_earned_irt' => 0,
            'total_earned_usdt' => 0,
            'total_earned' => 0,
            'avg_score' => 0
        ];
    }

    /** آمار آگهی برای تبلیغ‌دهنده */
    public function getAdStats(int $adId): object
    {
        $stmt = $this->db->prepare(
            "SELECT
                COUNT(*) AS total_executions,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) AS completed,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN payout_amount ELSE 0 END), 0) AS total_spent,
                COALESCE(AVG(CASE WHEN status = 'completed' THEN final_score END), 0) AS avg_score,
                COUNT(CASE WHEN fraud_flags IS NOT NULL THEN 1 END) AS fraud_count
             FROM seo_executions
             WHERE ad_id = ?"
        );
        $stmt->execute([$adId]);
        return $this->fetchObject($stmt) ?? (object)[
            'total_executions' => 0,
            'completed' => 0,
            'total_spent' => 0,
            'avg_score' => 0,
            'fraud_count' => 0
        ];
    }

    // --------------------------------------------------------
    // WRITE
    // --------------------------------------------------------

    /** @param array<string, mixed> $d */
    public function createExecution(array $d): ?self
    {
        $stmt = $this->db->prepare(
            "INSERT INTO seo_executions
             -- 🛡️ FIX-Q4-SEO23-09 (آشتی): slot_date برای وضعیت‌های اشغال‌کننده (started/completed)
             -- پر می‌شود؛ UNIQUE (ad_id, user_id, slot_date) محافظ تکرارِ همان روز است.
             (ad_id, user_id, status, ip_address, device_fingerprint, session_id, target_keyword, started_at, execution_date, slot_date)
             VALUES (?, ?, 'started', ?, ?, ?, ?, NOW(), CURDATE(), CURDATE())"
        );
        
        $ok = $stmt->execute([
            int_value($d['ad_id'] ?? 0),
            int_value($d['user_id'] ?? 0),
            $d['ip_address'] ?? get_client_ip(),
            $d['device_fingerprint'] ?? null,
            $d['session_id'] ?? null,
            $d['target_keyword'] ?? null,
        ]);

        return $ok ? $this->find((int)$this->db->lastInsertId()) : null;
    }

    /**
     * Server-authoritative seconds elapsed since the execution started.
     * Uses the DB clock (TIMESTAMPDIFF vs NOW()) so it is timezone-safe and cannot
     * be influenced by the client. Root fix (H-10).
     */
    public function secondsSinceStart(int $id): int
    {
        $stmt = $this->db->prepare(
            "SELECT TIMESTAMPDIFF(SECOND, started_at, NOW()) FROM seo_executions WHERE id = ?"
        );
        $stmt->execute([$id]);
        $val = $stmt->fetchColumn();
        return ($val === false || $val === null) ? 0 : max(0, (int)$val);
    }

    /** تکمیل اجرا با امتیازها */
    /** @param array<string, mixed> $scores */
    public function complete(int $id, array $scores, string $payout): bool
    {
        $engagementData = is_array($scores['engagement_data'] ?? null) ? $scores['engagement_data'] : [];
        $this->validateEngagementData($engagementData);

        $stmt = $this->db->prepare(
            "UPDATE seo_executions
             SET time_score = ?,
                 scroll_score = ?,
                 interaction_score = ?,
                 quality_score = ?,
                 final_score = ?,
                 payout_amount = ?,
                 engagement_data = ?,
                 score_breakdown = ?,
                 fraud_score = ?,
                 client_mode = ?,
                 status = 'completed',
                 completed_at = NOW(),
                 updated_at = NOW()
             WHERE id = ? AND status = 'started'"
        );

        // 🛡️ FIX-M23R-06 (T23-06 — معناشناسی rowCount): قبلاً خروجی execute()
        // (true حتی وقتی ۰ ردیف تغییر کرد) برگردانده می‌شد؛ گارد CAS در
        // ProcessSeoTaskAsyncJob («این تسک قبلاً تکمیل یا لغو شده») هرگز شلیک
        // نمی‌کرد. اکنون false یعنی واقعاً وضعیت started نبود.
        $stmt->execute([
            float_value($scores['time_score'] ?? 0),
            float_value($scores['scroll_score'] ?? 0),
            float_value($scores['interaction_score'] ?? 0),
            float_value($scores['quality_score'] ?? 0),
            float_value($scores['final_score'] ?? 0),
            str_value($payout),
            json_encode($engagementData, JSON_UNESCAPED_UNICODE),
            json_encode($scores, JSON_UNESCAPED_UNICODE),
            int_value($scores['fraud_score'] ?? 0),
            str_value($engagementData['client_mode'] ?? 'web'),
            $id
        ]);
        return $stmt->rowCount() > 0;
    }

    /** @param array<string, mixed> $data */
    private function validateEngagementData(array $data): void
    {
        $required = ['duration', 'scroll_depth', 'interactions'];
        foreach ($required as $field) {
            if (!isset($data[$field]) || !is_numeric($data[$field])) {
                throw new \InvalidArgumentException("Missing or invalid {$field}");
            }
        }
        
        // Range validation
        if ($data['duration'] < 0 || $data['duration'] > 3600) {
            throw new \InvalidArgumentException('Invalid duration');
        }
        
        if ($data['scroll_depth'] < 0 || $data['scroll_depth'] > 100) {
            throw new \InvalidArgumentException('Invalid scroll_depth');
        }

        // 🛡️ FIX-Q4-SEO23-14 (آشتی): interactions منفی هم اینجا رد می‌شود — سرویس
        // (SeoService::validateEngagementData) از قبل می‌گرفت ولی مدل نمی‌گرفت؛
        // دو اعتبارسنجی با قواعد متفاوت = ریسک drift.
        if ($data['interactions'] < 0) {
            throw new \InvalidArgumentException('Invalid interactions');
        }
    }

    /** علامت‌گذاری به عنوان تقلب */
    /** @param array<string, mixed> $flags */
    public function markAsFraud(int $id, array $flags): bool
    {
        // L-26 Fix: guard روی وضعیت تا برچسب‌گذاری تکراری audit/score را چندبار تغییر ندهد (idempotent).
        $stmt = $this->db->prepare(
            "UPDATE seo_executions
             SET status = 'fraud',
                 fraud_flags = ?,
                 fraud_score = 100,
                 slot_date = NULL, -- FIX-Q4-SEO23-09 (آشتی): جایگاه روز آزاد می‌شود
                 updated_at = NOW()
             WHERE id = ? AND status <> 'fraud'"
        );

        $stmt->execute([json_encode($flags), $id]);
        // فقط وقتی true که رکورد واقعاً برای اولین بار fraud شده باشد.
        return $stmt->rowCount() > 0;
    }

    /** رد شدن */
    public function reject(int $id, string $reason): bool
    {
        // FIX-R36-W3 (F-A19a-04): متد مرده بود (zero call-site) و بی‌گارد — اگر روزی
        // احیا می‌شد هر وضعیتی (از جمله completed/paid) را rejected می‌کرد. اکنون
        // فقط از وضعیت 'started' (هم‌خوان با complete()) و با معناشناسی rowCount.
        $stmt = $this->db->prepare(
            "UPDATE seo_executions
             SET status = 'rejected',
                 rejection_reason = ?,
                 fraud_flags = ?,
                 slot_date = NULL, -- FIX-Q4-SEO23-09 (آشتی): جایگاه روز آزاد می‌شود
                 updated_at = NOW()
             WHERE id = ? AND status = 'started'"
        );

        $stmt->execute([$reason, json_encode(['reason' => $reason], JSON_UNESCAPED_UNICODE), $id]);
        return $stmt->rowCount() > 0;
    }

    // --------------------------------------------------------
    // PRIVATE
    // --------------------------------------------------------

/** @param array<int|string, mixed> $row */
    private function hydrate(array $row): self
    {
        $o = clone $this;
        $o->id                  = int_value($row['id'] ?? 0);
        $o->ad_id               = int_value($row['ad_id'] ?? 0);
        $o->user_id             = int_value($row['user_id'] ?? 0);
        $o->time_score          = float_value($row['time_score']         ?? 0);
        $o->scroll_score        = float_value($row['scroll_score']       ?? 0);
        $o->interaction_score   = float_value($row['interaction_score']  ?? 0);
        $o->quality_score       = float_value($row['quality_score']      ?? 0);
        $o->final_score         = float_value($row['final_score']        ?? 0);
        $o->payout_amount       = float_value($row['payout_amount']      ?? 0);
        $o->status              =         $row['status']            ?? null;
        $o->engagement_data     =         $row['engagement_data']     ?? null;
        $o->fraud_flags         =         $row['fraud_flags']         ?? null;
        $o->ip_address          =         $row['ip_address']        ?? null;
        $o->device_fingerprint  =         $row['device_fingerprint']  ?? null;
        $o->click_token         =         $row['click_token']         ?? null;
        $o->click_token_expires_at =      $row['click_token_expires_at'] ?? null;
        $o->click_counted_at    =         $row['click_counted_at']    ?? null;
        $o->landing_verified_at =         $row['landing_verified_at'] ?? null;
        $o->landing_proof_channel =       $row['landing_proof_channel'] ?? null;
        $o->slot_date           =         $row['slot_date']           ?? null; // FIX-Q4-SEO23-09 (آشتی)
        $o->session_id          =         $row['session_id']          ?? null;
        $o->target_keyword      =         $row['target_keyword']      ?? null;
        $o->rejection_reason    =         $row['rejection_reason']    ?? null;
        $o->cancel_reason       =         $row['cancel_reason']       ?? null;
        $o->fraud_score         = isset($row['fraud_score']) ? int_value($row['fraud_score']) : null;
        $o->score_breakdown     =         $row['score_breakdown']     ?? null;
        $o->started_at          =         $row['started_at']        ?? null;
        $o->completed_at        =         $row['completed_at']        ?? null;
        $o->created_at          =         $row['created_at']        ?? null;
        $o->updated_at          =         $row['updated_at']          ?? null;
        return $o;
    }
}
