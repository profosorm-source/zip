<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class ContactMessage extends Model
{
    protected static string $table = 'contact_messages';

    /**
     * FIX-18O (P2): whitelist ستون‌های واقعی جدول (full_name, email, subject,
     * message, is_read, created_at). is_read عمداً سیستمی می‌ماند (پیش‌فرض 0)
     * و توسط فرم تماس قابل تنظیم نیست.
     */
    protected array $fillable = ['full_name', 'email', 'subject', 'message', 'ip_address', 'user_agent', 'created_at']; // 🛡️ FIX-S30-10 (R75): ستون‌های جدید

    /**
     * @param array<string, mixed> $payload
     */
    public function createMessage(array $payload): int
    {
        // FIX-18O (P2): payload ورودی با $fillable فیلتر می‌شود
        return (int)$this->db->table(self::$table)
            ->insert($this->filterFillable($payload));
    }
    /**
     * @return list<object>
     */

    public function getPendingMessages(int $limit = 50): array
    {
        // X43c: جدول ستون name و status ندارد؛ ستون واقعی full_name و پرچم is_read است
        return $this->db->table(self::$table)
            ->select('id', 'full_name', 'email', 'subject', 'message', 'is_read', 'created_at')
            ->where('is_read', '=', 0)
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }

    public function markAsProcessed(int $messageId, string $status = 'processed'): bool
    {
        // X43c: معادل schema واقعی = پرچم is_read؛ ستون status/updated_at وجود ندارد
        unset($status);
        return (bool)$this->db->table(self::$table)
            ->where('id', '=', $messageId)
            ->update(['is_read' => 1]);
    }

    // ─── 🛡️ FIX-S30-10 (R75): صندوق ادمین — صفحه‌بندی + فیلتر خوانده‌شده ──────

    private const INBOX_COLUMNS = ['id', 'full_name', 'email', 'subject', 'message', 'ip_address', 'user_agent', 'is_read', 'created_at'];

    /** @return array{messages: list<object>, total: int} */
    public function getInbox(int $page = 1, int $perPage = 20, ?bool $isRead = null): array
    {
        $page = max(1, $page);
        $perPage = max(1, min(100, $perPage));
        $offset = ($page - 1) * $perPage;

        $query = $this->db->table(self::$table);
        if ($isRead !== null) {
            $query = $query->where('is_read', '=', $isRead ? 1 : 0);
        }

        $total = (int)(clone $query)->count();
        $messages = $query
            ->select(...self::INBOX_COLUMNS)
            ->orderBy('created_at', 'DESC')
            ->limit($perPage)
            ->offset($offset)
            ->get();

        return ['messages' => $messages, 'total' => $total];
    }

    public function findMessage(int $id): ?object
    {
        $rows = $this->db->table(self::$table)
            ->select(...self::INBOX_COLUMNS)
            ->where('id', '=', $id)
            ->limit(1)
            ->get();
        return $rows[0] ?? null;
    }
}
