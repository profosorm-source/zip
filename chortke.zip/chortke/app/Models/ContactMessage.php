<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class ContactMessage extends Model
{
    protected static string $table = 'contact_messages';
    /**
     * @param array<string, mixed> $payload
     */

    public function createMessage(array $payload): int
    {
        return (int)$this->db->table(self::$table)
            ->insert($payload);
    }
    /**
     * @return list<object>
     */

    public function getPendingMessages(int $limit = 50): array
    {
        // BUGFIX 2026-08-27: ستون‌های name/status در schema وجود ندارند —
        // ستون واقعی full_name است و وضعیت با is_read نشان داده می‌شود.
        return $this->db->table(self::$table)
            ->select('id', 'full_name', 'email', 'subject', 'message', 'created_at')
            ->where('is_read', '=', 0)
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }

    public function markAsProcessed(int $messageId, string $status = 'processed'): bool
    {
        // BUGFIX 2026-08-27: ستون‌های status/updated_at وجود ندارند — از is_read استفاده می‌شود.
        return (bool)$this->db->table(self::$table)
            ->where('id', '=', $messageId)
            ->update(['is_read' => 1]);
    }
}
