<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class ContactMessage extends Model
{
    protected static string $table = 'contact_messages';

    /**
     * FIX-18O (P2): whitelist ستون‌های واقعی جدول (full_name, email, subject,
     * message, is_read, created_at). is_read عمداً سیستمی می‌ماند (پیش‌فرض 0)
     * و توسط فرم تماس قابل تنظیم نیست.
     */
    protected array $fillable = ['full_name', 'email', 'subject', 'message', 'created_at'];

    /**
     * @param array<string, mixed> $payload
     */
    public function createMessage(array $payload): int
    {
        // FIX-18O (P2): payload ورودی با $fillable فیلتر می‌شود
        return (int)$this->db->table(self::$table)
            ->insert($this->filterFillable($payload));
    }
    /**
     * @return list<object>
     */

    public function getPendingMessages(int $limit = 50): array
    {
        // X43c: جدول ستون name و status ندارد؛ ستون واقعی full_name و پرچم is_read است
        return $this->db->table(self::$table)
            ->select('id', 'full_name', 'email', 'subject', 'message', 'is_read', 'created_at')
            ->where('is_read', '=', 0)
            ->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->get();
    }

    public function markAsProcessed(int $messageId, string $status = 'processed'): bool
    {
        // X43c: معادل schema واقعی = پرچم is_read؛ ستون status/updated_at وجود ندارد
        unset($status);
        return (bool)$this->db->table(self::$table)
            ->where('id', '=', $messageId)
            ->update(['is_read' => 1]);
    }
}
