<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * CustomTaskSubmissionModel - Custom Task Submissions Data Access Layer
 */
class CustomTaskSubmissionModel extends Model
{
    protected static string $table = 'custom_task_submissions';

    /** 🛡️ FIX-V22-03c: سقف شکست‌های متوالی پیش از پارکِ ردیف در sweep تأیید خودکار.
     *  منبع واحد حقیقت — کرون (CronSubmissionsJob) همین ثابت را می‌خواند. */
    public const AUTO_APPROVE_PARK_THRESHOLD = 10;

    // 🧹 FIX-M22-MED (T22-21/D1-N13): ۹ متد مردهٔ این مدل حذف شدند (صفر فراخوان
    // با Grep اثبات شد): submission_getByWorker، submission_findWithTask،
    // submission_getUnreviewedSubmissions، submission_markExpired/markApproved/
    // markRewardPaid (CASهای زندهٔ FIX-S17-4 جایگزینشان هستند)،
    // submission_isDuplicateImage و submission_checkIdempotency (منطق زنده inline
    // در SubmitProofJob) و getAdminSubmissionStats (زنجیرهٔ آنالیتیکس مردهٔ T22-11).
    // خطرشان: submission_markApproved اگر وصل می‌شد approved_at/reward_paid نمی‌نوشت.


    public function submission_find(int $id): ?\stdClass
    {
        $stmt = $this->db->prepare("
            SELECT s.*, ct.title AS task_title, ct.user_id AS creator_id, ct.proof_type,
                   ct.proof_description, w.full_name AS worker_name, w.email AS worker_email
            FROM custom_task_submissions s
            LEFT JOIN ads ct ON ct.id = s.task_id
            LEFT JOIN users w ON w.id = s.worker_id
            WHERE s.id = ?
        ");
        $stmt->execute([$id]);
        $r = $stmt->fetch(\PDO::FETCH_OBJ);
        return $r ? (object) $r : null;
    }

    public function submission_findById(int $id): ?\stdClass
    {
        return $this->submission_find($id);
    }

    public function submission_findByIdForUpdate(int $id): ?\stdClass
    {
        if (!$this->db->inTransaction()) {
            throw new \RuntimeException("submission_findByIdForUpdate must be called within an active database transaction.");
        }
        $stmt = $this->db->prepare("SELECT * FROM custom_task_submissions WHERE id = ? FOR UPDATE");
        $stmt->execute([$id]);
        $r = $stmt->fetch(\PDO::FETCH_OBJ);
        return $r ? (object) $r : null;
    }

    /** @param array<string, mixed> $d */
    public function submission_create(array $d): ?\stdClass
    {
        try {
            $this->db->beginTransaction();

            // 1. Lock custom task to prevent concurrent workers from exceeding limits
            $stmt = $this->db->prepare("SELECT id FROM ads WHERE id = ? FOR UPDATE");
            $stmt->execute([$d['task_id']]);
            $task = $stmt->fetch(\PDO::FETCH_OBJ);

            if (!$task) {
                $this->db->rollback();
                return null;
            }

            // 2. Lock duplicate check in transaction (lock actual rows to prevent concurrent TOCTOU races)
            $stmt = $this->db->prepare("
                SELECT id FROM custom_task_submissions
                WHERE task_id = ? AND worker_id = ? AND status NOT IN ('expired','rejected')
                FOR UPDATE
            ");
            $stmt->execute([$d['task_id'], $d['worker_id']]);
            $existing = $stmt->fetch(\PDO::FETCH_OBJ);

            if ($existing) {
                $this->db->rollback();
                return null;
            }

            $ip = $d['worker_ip'] ?? '127.0.0.1';
            $fingerprint = $d['worker_fingerprint'] ?? 'unknown';

            $stmt = $this->db->prepare("
                INSERT INTO custom_task_submissions
                (task_id, worker_id, user_id, deadline_at, status, reward_amount, reward_currency,
                 idempotency_key, worker_ip, worker_fingerprint)
                VALUES (?,?,?,?,?,?,?,?,?,?)
            ");
            $result = $stmt->execute([
                $d['task_id'], 
                $d['worker_id'], 
                $d['worker_id'], 
                $d['deadline_at'],
                $d['status'] ?? 'in_progress', 
                $d['reward_amount'] ?? 0,
                $d['reward_currency'] ?? 'irt', 
                $d['idempotency_key'] ?? \uniqid('idemp_', true),
                $ip,
                $fingerprint,
            ]);
            
            if (!$result) {
                $this->db->rollback();
                return null;
            }

            $lastId = (int)$this->db->lastInsertId();
            $this->db->commit();

            return $this->submission_find($lastId);

        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            return null;
        }
    }

    /**
     * 🛡️ FIX-S17-4: claim اتمیک انتقال in_progress → expired (CAS).
     * تنها زمانی true برمی‌گرداند که رکورد هنوز in_progress باشد؛ از بازنویسی
     * هم‌زمانِ approved/processed توسط کرون انقضا جلوگیری می‌کند.
     */
    public function submission_expireIfInProgress(int $id): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE custom_task_submissions SET status = 'expired' WHERE id = ? AND status = 'in_progress'"
        );
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

    /** @param array<string, mixed> $data */
    public function submission_update(int $id, array $data): bool
    {
        $fields = []; 
        $values = [];
        
        $allowed = [
            'proof_url', 'proof_text', 'proof_code', 'proof_file', 'proof_file_hash', 'proof_data',
            // 🛡️ FIX-S19-VFP: لنگرِ اثر انگشت نرمال‌شدهٔ proof_url (گیت cross-task)
            'proof_url_hash',
            'submitted_at', 'approved_at', 'reviewed_at', 'reviewed_by', 'auto_approved_at',
            'status', 'rejection_reason', 'reward_paid', 'reward_transaction_id', 'paid_amount', 'resolution_type', 'resolution_note', 'metadata', 'dispute_id'
        ];
        
        foreach ($allowed as $f) {
            if (\array_key_exists($f, $data)) {
                $fields[] = "{$f} = ?";
                $values[] = $data[$f];
            }
        }
        
        if (empty($fields)) return false;
        
        $values[] = $id;
        $stmt = $this->db->prepare("UPDATE custom_task_submissions SET " . \implode(', ', $fields) . " WHERE id = ?");
        return $stmt->execute($values);
    }

    public function submission_hasWorkerDone(int $taskId, int $workerId): bool
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM custom_task_submissions
            WHERE task_id = ? AND worker_id = ? AND status NOT IN ('expired','rejected')
        ");
        $stmt->execute([$taskId, $workerId]);
        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * 🛡️ FIX-M22-07: آیا این مجری اختلاف «باز» روی ارسال‌های این تسک دارد؟
     * چک‌های تکراری/hasWorkerDone ارسال‌های rejected را استثنا می‌گذارند تا شروع
     * مجدد پس از رد ممکن باشد؛ همین یعنی با اختلاف باز روی ارسال ردشده می‌توان
     * هم‌زمان اجرای دوم شروع کرد (نیمهٔ اول سناریوی دوبل‌پرداخت). مجموعهٔ
     * وضعیت‌های باز همان قرارداد NOT EXISTS در getOldSubmissionsForAutoApproval است.
     */
    public function submission_hasOpenDispute(int $taskId, int $workerId): bool
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM disputes d
            INNER JOIN custom_task_submissions s ON s.id = d.ref_id
            WHERE d.ref_type = 'custom_task_submission'
              AND s.task_id = ? AND s.worker_id = ?
              AND d.status IN ('open', 'open_peer', 'under_review', 'escalated')
        ");
        $stmt->execute([$taskId, $workerId]);
        return (int) $stmt->fetchColumn() > 0;
    }

    /** 🛡️ FIX-M22-04: آیا اصلاً اختلاف بازی روی ارسال‌های این تسک هست؟ (گارد رد تسک) */
    public function submission_taskHasOpenDispute(int $taskId): bool
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM disputes d
            INNER JOIN custom_task_submissions s ON s.id = d.ref_id
            WHERE d.ref_type = 'custom_task_submission'
              AND s.task_id = ?
              AND d.status IN ('open', 'open_peer', 'under_review', 'escalated')
        ");
        $stmt->execute([$taskId]);
        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * 🛡️ FIX-M22-07: آیا ارسال «تأییدشده یا در-اختلاف» دیگری از همین مجری روی
     * همین تسک وجود دارد؟ گارد approveSubmission زیر قفل — جلوی دومین پاداش
     * برای همان (task, worker) وقتی ارسال موازی دیگری باقی مانده است. قید
     * UNIQUE(task_id, worker_id) عمداً گذاشته نشد چون رد→شروع مجدد→تأیید
     * مجازِ کاربر سالم است؛ این گارد فقط ترکیب‌های درآمدزا را می‌بندد.
     */
    public function submission_hasOtherApprovedOrDisputed(int $taskId, int $workerId, int $excludeSubmissionId): bool
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM custom_task_submissions
            WHERE task_id = ? AND worker_id = ? AND id != ?
              AND status IN ('approved', 'disputed')
        ");
        $stmt->execute([$taskId, $workerId, $excludeSubmissionId]);
        return (int) $stmt->fetchColumn() > 0;
    }

    /** 🛡️ FIX-M22-04: انقضای گروهیِ CAS اجراهای in_progress هنگام رد تسک توسط مدیریت (الگوی FIX-S17-4) */
    public function submission_expireInProgressForTask(int $taskId): int
    {
        $stmt = $this->db->prepare(
            "UPDATE custom_task_submissions SET status = 'expired' WHERE task_id = ? AND status = 'in_progress'"
        );
        $stmt->execute([$taskId]);
        return $stmt->rowCount();
    }

    /** 🛡️ FIX-M22-04: رد گروهی ارسال‌های submitted هنگام رد تسک توسط مدیریت */
    public function submission_rejectSubmittedForTask(int $taskId, string $reason): int
    {
        $stmt = $this->db->prepare(
            "UPDATE custom_task_submissions SET status = 'rejected', rejection_reason = ?, reviewed_at = NOW() WHERE task_id = ? AND status = 'submitted'"
        );
        $stmt->execute([$reason, $taskId]);
        return $stmt->rowCount();
    }

    public function submission_todayCount(int $workerId): int
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM custom_task_submissions
            WHERE worker_id = ? AND DATE(created_at) = CURDATE()
        ");
        $stmt->execute([$workerId]);
        return (int) $stmt->fetchColumn();
    }

    /**
     * 🛡️ FIX-M22-MED (T22-12): تعداد شروع‌های امروزِ همین کاربر روی «همین تسک» —
     * برای اعمال daily_limit_per_userِ ذخیره‌شده در restrictions (قبلاً فقط سقف
     * سراسری custom_task_max_daily_submissions اعمال می‌شد و قید per-task هیچ‌جا
     * خوانده نمی‌شد).
     */
    public function submission_todayCountForTask(int $taskId, int $workerId): int
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM custom_task_submissions
            WHERE task_id = ? AND worker_id = ? AND DATE(created_at) = CURDATE()
        ");
        $stmt->execute([$taskId, $workerId]);
        return (int) $stmt->fetchColumn();
    }
    /** @return list<object> */
    public function submission_getByTask(int $taskId, ?string $status = null, int $limit = 30, int $offset = 0): array
    {
        $where = ["s.task_id = ?"];
        $params = [$taskId];
        
        if ($status) { 
            $where[] = "s.status = ?"; 
            $params[] = $status; 
        }
        
        $whereStr = \implode(' AND ', $where);
        
        $stmt = $this->db->prepare("
            SELECT s.*, w.full_name AS worker_name, w.email AS worker_email
            FROM custom_task_submissions s
            LEFT JOIN users w ON w.id = s.worker_id
            WHERE {$whereStr} 
            ORDER BY s.created_at DESC 
            LIMIT ? OFFSET ?
        ");
        
        $params[] = $limit; 
        $params[] = $offset;
        $stmt->execute($params);
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * 🧹 FIX-COSMET-15 (A2-N3/متوسط): شمارش هم‌شرطِ submission_getByTask برای
     * صفحه‌بندی واقعی جدول submissions ادمین (قبلاً سقف ۳۰ بدون pager بود و
     * ردیف ۳۱+ از هیچ UIای قابل‌دسترس نبود).
     */
    public function submission_countByTask(int $taskId, ?string $status = null): int
    {
        $where = ["task_id = ?"];
        $params = [$taskId];
        if ($status !== null && $status !== '') {
            $where[] = "status = ?";
            $params[] = $status;
        }
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM custom_task_submissions WHERE " . \implode(' AND ', $where));
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }
    /** @return list<object> */
    /** @return list<\stdClass> */
    public function submission_getExpiredSubmissions(): array
    {
        $stmt = $this->db->prepare("
            SELECT id, task_id FROM custom_task_submissions
            WHERE status = 'in_progress' AND deadline_at <= NOW()
        ");
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }
    /**
     * 🛡️ FIX-M22-MED (T22-16): بازنویسی کوئری تأیید خودکار —
     *  ۱) FOR UPDATE حذف شد: در autocommit قفل بلافاصله آزاد می‌شود و فقط هزینه
     *     داشت؛ ایمنی واقعی از قفل و گاردهای داخل approveSubmission می‌آید
     *     (FOR UPDATE + CAS) که دست‌نخورده است.
     *  ۲) COALESCE(ct.auto_approve_hours, ?): ساعتِ «هر تسک» (ستونی که آداپتر موقع
     *     ساخت ذخیره می‌کند ولی هرگز خوانده نمی‌شد) با فالبک به تنظیم سراسری —
     *     تغییر تنظیم سراسری دیگر وعدهٔ داده‌شده به مجری‌های تسک‌های قدیمی را
     *     بی‌صدا عوض نمی‌کند.
     *  ۳) LIMIT + ORDER BY قدیمی‌ترین‌ها: بدون سقف، همهٔ ردیف‌های واجد شرایط بار
     *     می‌شد (ریسک بار سنگین در اولین اجرای کرون).
     *
     * 🛡️ FIX-V22-03 (بازبینی ۲۲):
     *  b) گارد «> 0» روی خودِ COALESCE: تنظیم سراسری ≤۰ دیگر کل sweep را نمی‌کشد؛
     *     فقط فالبکِ تسک‌های بی‌ساعت را خاموش می‌کند و ساعتِ اختصاصیِ ذخیره‌شدهٔ
     *     هر تسک مستقل اجرا می‌شود (وعدهٔ T22-16). همچنین بازگشت ردیفِ بی‌ساعت
     *     وقتی سراسریِ ≤۰ است ممکن نیست → INTERVAL صفر/منفی («تأیید آنی» ناخواسته)
     *     غیرممکن می‌شود — هم‌راستا با FIX-COSMET-14.
     *  c) ضدگرسنگی: ردیف‌های پارک‌شده (attempts ≥ سقف) حذف و ORDER BY بر اساس
     *     attempts سپس submitted_at است تا ردیف‌های همیشه‌شکست‌خورده صف را نگیرند.
     *  d) FIX-V22-04c: ارسالِ هم‌زمانِ همان مجری که خواهرِ approved/disputed دارد
     *     (گارد T22-07 در approveSubmission هرگز اجازهٔ تأییدش را نمی‌دهد) از
     *     کاندیدها حذف می‌شود — قبلاً هر ساعت لاگ warning می‌ساخت (نویز).
     * @return list<\stdClass>
     */
    public function getOldSubmissionsForAutoApproval(int $hoursOld = 48, int $limit = 200): array
    {
        $limit = max(1, min(500, $limit));
        $stmt = $this->db->prepare("
            SELECT s.*, ct.title AS task_title, ct.user_id AS creator_id, ct.proof_type,
                   w.full_name AS worker_name, w.email AS worker_email
            FROM custom_task_submissions s
            LEFT JOIN ads ct ON ct.id = s.task_id
            LEFT JOIN users w ON w.id = s.worker_id
            WHERE s.status = 'submitted'
            AND COALESCE(ct.auto_approve_hours, ?) > 0
            AND s.submitted_at <= DATE_SUB(NOW(), INTERVAL COALESCE(ct.auto_approve_hours, ?) HOUR)
            AND s.auto_approve_attempts < ?
            AND NOT EXISTS (
                SELECT 1 FROM disputes d
                WHERE d.ref_type = 'custom_task_submission'
                  AND d.ref_id = s.id
                  AND d.status IN ('open', 'open_peer', 'under_review', 'escalated')
            )
            AND NOT EXISTS (
                SELECT 1 FROM custom_task_submissions s2
                WHERE s2.task_id = s.task_id
                  AND s2.worker_id = s.worker_id
                  AND s2.id <> s.id
                  AND s2.status IN ('approved', 'disputed')
            )
            ORDER BY s.auto_approve_attempts ASC, s.submitted_at ASC
            LIMIT {$limit}
        ");
        $stmt->execute([$hoursOld, $hoursOld, self::AUTO_APPROVE_PARK_THRESHOLD]);
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * 🛡️ FIX-V22-03c (بازبینی ۲۲ — ضدگرسنگی sweep): افزایش اتمیک شمارندهٔ شکست‌های
     * متوالی auto-approve. مقدار تازهٔ شمارنده را برمی‌گرداند تا فراخوان (کرون)
     * بتواند آستانهٔ پارک را فقط روی نفسِ عبور تشخیص دهد (لاگ error یک‌بار).
     * اتمیک بودن: افزایش در خودِ SQL انجام می‌شود (خواندن-سپس-نوشتن نیست)؛ دو
     * sweep موازی هرگز مقدار گم‌شده نمی‌بینند.
     */
    public function submission_incrementAutoApproveAttempts(int $submissionId): int
    {
        $stmt = $this->db->prepare(
            "UPDATE custom_task_submissions SET auto_approve_attempts = auto_approve_attempts + 1 WHERE id = ?"
        );
        $stmt->execute([$submissionId]);

        $row = $this->db->query(
            "SELECT auto_approve_attempts AS attempts FROM custom_task_submissions WHERE id = ?",
            [$submissionId]
        )->fetch(\PDO::FETCH_OBJ);

        return ($row instanceof \stdClass && isset($row->attempts)) ? (int)$row->attempts : 0;
    }
    /**
     * لیست اجراهای یک worker با اطلاعات تسک (برای صفحه mySubmissions).
     * جایگزین Raw SQL در CustomTaskController::mySubmissions()
     */
    /** @return list<object> */
    public function submission_getByWorkerWithTask(int $workerId, int $limit = 100, int $offset = 0): array
    {
        $limit  = max(1, min(500, $limit));
        $offset = max(0, $offset);
        $stmt   = $this->db->prepare("
            SELECT s.*, a.title AS task_title, a.description AS task_description, a.currency AS task_currency,
                   a.proof_type AS task_proof_type
            FROM custom_task_submissions s
            LEFT JOIN ads a ON a.id = s.task_id
            WHERE s.worker_id = ?
            ORDER BY s.created_at DESC
            LIMIT {$limit} OFFSET {$offset}
        ");
        $stmt->execute([$workerId]);
        return $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
    }

    /**
     * یافتن submission با اطلاعات کامل تسک برای ارسال مدرک (proof).
     * جایگزین Raw SQL در CustomTaskController::findSubmissionForProof()
     */
    public function submission_findForProof(int $submissionId, int $workerId): ?\stdClass
    {
        $stmt = $this->db->prepare("
            SELECT s.*,
                   a.title            AS task_title,
                   a.description      AS task_description,
                   a.proof_type,
                   a.proof_description,
                   a.proof_schema,
                   a.price_per_task,
                   a.currency,
                   a.user_id          AS advertiser_id
            FROM custom_task_submissions s
            LEFT JOIN ads a ON a.id = s.task_id
            WHERE s.id = ? AND s.worker_id = ?
            LIMIT 1
        ");
        $stmt->execute([$submissionId, $workerId]);
        $row = $stmt->fetch(\PDO::FETCH_OBJ);
        return $row ? (object) $row : null;
    }
    /**
     * 🛡️ FIX-M22-MED (T22-20/F3): تعداد کل ردیف‌های worker برای صفحه‌بندی
     * my-submissions (کنترلر قبلاً صفحه را نادیده می‌گرفت و همیشه ۱۰۰ ردیف
     * اول را برمی‌گرداند).
     */
    public function submission_countByWorkerWithTask(int $workerId): int
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM custom_task_submissions WHERE worker_id = ?");
        $stmt->execute([$workerId]);
        return (int) $stmt->fetchColumn();
    }
}
