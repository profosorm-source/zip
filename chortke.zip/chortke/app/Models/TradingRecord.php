<?php

namespace App\Models;

use Core\Model;
use Core\Database;

class TradingRecord extends Model {
    protected static string $table = 'trading_records';

    public const STATUS_OPEN = 'open';
    public const STATUS_CLOSED = 'closed';
    public const STATUS_STOPPED = 'stopped';

    public const DIRECTION_BUY = 'buy';
    public const DIRECTION_SELL = 'sell';

    /**
     * 🛡️ FIX-S16-6 (بچ S16): سفیدلیست ستون‌های واقعی trading_records.
     * پیش از این create/update هر کلیدی را در "`{{$k}}` = ?" درون‌یابی می‌کرد.
     * فراخوان‌های زنده (CreateTradeJob/CloseTradeJob) آرایه‌های کلید-ثابت می‌سازند
     * اما این متدها public هستند — سفیدلیست، بردار نهفته را می‌بندد.
     */
    private const ALLOWED_COLUMNS = [
        'user_id', 'admin_id', 'investment_id', 'direction', 'pair', 'amount',
        'open_price', 'close_price', 'stop_loss', 'take_profit',
        'profit_loss_amount', 'profit_loss_percent', 'currency', 'status',
        'reason', 'open_time', 'close_time', 'closed_at',
        'created_at', 'updated_at', 'is_deleted',
    ];
/**
     * ایجاد ترید جدید
     * خروجی: id یا null
     */
    /** @param array<string, mixed> $data */
    public function create(array $data): ?int
    {
        $now = \date('Y-m-d H:i:s');

        $data['created_at'] = $data['created_at'] ?? $now;
        $data['updated_at'] = $data['updated_at'] ?? $now;
        $data['is_deleted'] = $data['is_deleted'] ?? 0;

        $filtered = [];
        foreach (self::ALLOWED_COLUMNS as $col) {
            if (\array_key_exists($col, $data)) {
                $filtered[$col] = $data[$col];
            }
        }

        $columns = \array_keys($filtered);
        $values  = \array_values($filtered);

        $placeholders = \array_fill(0, \count($columns), '?');
        $colsSql = '`' . \implode('`,`', $columns) . '`';

        $sql = "INSERT INTO `trading_records` ({$colsSql}) VALUES (" . \implode(',', $placeholders) . ")";

        $stmt = $this->db->prepare($sql);
        $ok = $stmt->execute($values);

        if (!$ok) {
            return null;
        }

        $id = (int)$this->db->lastInsertId();
        return $id > 0 ? $id : null;
    }

    public function find(int $id): ?\stdClass
    {
        $stmt = $this->db->query(
            "SELECT * FROM trading_records WHERE id = ? AND is_deleted = 0 LIMIT 1",
            [$id]
        );

        $row = $stmt->fetch(\PDO::FETCH_OBJ) ?: false;
        return $row instanceof \stdClass ? $row : null;
    }

    public function findWithAdmin(int $id): ?\stdClass
    {
        $stmt = $this->db->query(
            "SELECT t.*, u.full_name as admin_name
             FROM trading_records t
             JOIN users u ON t.admin_id = u.id
             WHERE t.id = ? AND t.is_deleted = 0
             LIMIT 1",
            [$id]
        );

        $row = $stmt->fetch(\PDO::FETCH_OBJ) ?: false;
        return $row instanceof \stdClass ? $row : null;
    }

    /**
     * لیست تریدها
     */
    /** @param array<string, mixed> $filters */
    /** @return list<\stdClass> */
    /** @param array<string, mixed> $filters */
    /**
     * @param array<string, mixed> $filters
     * @return list<\stdClass>
     */
    public function getAll(array $filters = [], int $limit = 20, int $offset = 0): array
    {
        $limit  = \max(1, (int)$limit);
        $offset = \max(0, (int)$offset);

        $sql = "SELECT t.*, u.full_name as admin_name
                FROM trading_records t
                JOIN users u ON t.admin_id = u.id
                WHERE t.is_deleted = 0";

        $params = [];

        if (!empty($filters['status'])) {
            $sql .= " AND t.status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['direction'])) {
            $sql .= " AND t.direction = ?";
            $params[] = $filters['direction'];
        }

        $sql .= " ORDER BY t.open_time DESC LIMIT ? OFFSET ?";

        $stmt = $this->db->prepare($sql);
        $index = 1;
        foreach ($params as $val) {
            $stmt->bindValue($index++, $val);
        }
        $stmt->bindValue($index++, $limit, \PDO::PARAM_INT);
        $stmt->bindValue($index++, $offset, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /** @param array<string, mixed> $filters */
    public function countAll(array $filters = []): int
    {
        $sql = "SELECT COUNT(*) as total FROM trading_records WHERE is_deleted = 0";
        $params = [];

        if (!empty($filters['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['direction'])) {
            $sql .= " AND direction = ?";
            $params[] = $filters['direction'];
        }

        $stmt = $this->db->query($sql, $params);
        $row = $this->fetchObject($stmt);

        return (int)($row->total ?? 0);
    }

    /**
     * تریدهای باز
     */
    /** @return list<\stdClass> */
    public function getOpenTrades(): array
    {
        $stmt = $this->db->query(
            "SELECT * FROM trading_records
             WHERE status = ? AND is_deleted = 0
             ORDER BY open_time DESC",
            [self::STATUS_OPEN]
        );

        return $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
    }

    /**
     * آخرین تریدهای بسته شده (برای نمایش به کاربر)
     */
    /** @return list<\stdClass> */
    public function getRecentClosed(int $limit = 10): array
    {
        $limit = \max(1, (int)$limit);

        $stmt = $this->db->prepare(
            "SELECT * FROM trading_records
             WHERE status IN (?, ?) AND is_deleted = 0
             ORDER BY close_time DESC
             LIMIT ?"
        );

        $stmt->bindValue(1, self::STATUS_CLOSED);
        $stmt->bindValue(2, self::STATUS_STOPPED);
        $stmt->bindValue(3, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * بروزرسانی ترید
     */
    /** @param array<string, mixed> $data */
    public function update(int $id, array $data): bool
    {
        if (empty($data)) {
            return false;
        }

        $data['updated_at'] = \date('Y-m-d H:i:s');

        $fields = [];
        $values = [];

        foreach ((array)$data as $k => $v) {
            if (!\is_string($k) || !\in_array($k, self::ALLOWED_COLUMNS, true)) {
                throw new \InvalidArgumentException("Invalid trading record column: " . (string)$k);
            }
            $fields[] = "`{$k}` = ?";
            $values[] = $v;
        }

        $values[] = $id;

        $sql = "UPDATE trading_records
                SET " . \implode(', ', $fields) . "
                WHERE id = ? AND is_deleted = 0";

        $stmt = $this->db->query($sql, $values);

        return $stmt->rowCount() > 0;
    }

    /**
     * آمار تریدها
     */
    public function getStats(): object
    {
        $stmt = $this->db->query(
            "SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_count,
                SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_count,
                SUM(CASE WHEN profit_loss_amount > 0 THEN 1 ELSE 0 END) as profit_count,
                SUM(CASE WHEN profit_loss_amount < 0 THEN 1 ELSE 0 END) as loss_count,
                COALESCE(SUM(CASE WHEN profit_loss_amount > 0 THEN profit_loss_amount ELSE 0 END), 0) as total_profit,
                COALESCE(SUM(CASE WHEN profit_loss_amount < 0 THEN ABS(profit_loss_amount) ELSE 0 END), 0) as total_loss
             FROM trading_records
             WHERE is_deleted = 0"
        );

        $row = $this->fetchObject($stmt);
        return $row ?: (object)[];
    }
}