<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class BackupLog extends Model
{
    protected static string $table = 'backup_logs';

    /** [FIX-R91-B] وضعیت‌های آپلود آف‌سایت — منبع یگانهٔ رشته‌ها (NULL = هرگز تلاش نشده: ردیف‌های failed بکاپ) */
    public const OFFSITE_PENDING = 'pending';
    public const OFFSITE_UPLOADED = 'uploaded';
    public const OFFSITE_FAILED = 'failed';

    /** @return list<object> */
    public function getRecentBackups(int $limit = 20, int $offset = 0, ?string $status = null): array
    {
        $query = $this->db->table(self::$table)
            // [FIX-R91-B] ستون‌های آف‌سایت هم برای ستون وضعیت آپلود در جدول ادمین
            // [X377 راند ۹۸] description/filename هم — ویو از قبل این دو ستون را
            // مصرف می‌کرد ولی select نمی‌شدند (سیم‌کشی مرده: ستون «توضیح» همیشه
            // «-» می‌شد و suffix X361 DEFINER و دلیل شکستِ ردیف failed نامرئی بود)
            ->select('id', 'status', 'type', 'file_path', 'filename', 'size_bytes', 'created_at', 'completed_at',
                     'description', 'offsite_status', 'offsite_uploaded_at', 'offsite_error')
            ->orderBy('created_at', 'DESC')
            ->limit($limit);

        // [X382 راند ۱۰۲] فیلتر وضعیت — صف شکست‌ها باید قابل‌یافتن باشد؛
        // ورودی فقط از لیست سفید (completed|failed)؛ نال = همه (رفتار موروثی)
        if ($status !== null && in_array($status, ['completed', 'failed'], true)) {
            $query->where('status', '=', $status);
        }

        if ($offset > 0) {
            $query->offset($offset);
        }

        return $query->get();
    }

    /** @return array<string, mixed>|null */
    /** @return array<string, mixed>|null */
    public function findById(int $backupId): ?array
    {
        $row = $this->db->table(self::$table)
            ->select('file_path', 'checksum', 'request_id')
            ->where('id', '=', $backupId)
            ->first();
        return $row ? (array)$row : null;
    }

    /** @return array<string, mixed>|null */
    public function findByFilename(string $filename): ?array
    {
        $result = $this->db->table(self::$table)
            ->select('file_path', 'checksum', 'request_id')
            ->where('file_path', '=', $filename)
            ->first();
        return $result ? (array) $result : null;
    }

    /** @param array<string, mixed> $data */
    public function logBackup(array $data): int
    {
        return (int)$this->db->table(self::$table)
            ->insert($data);
    }

    /**
     * [FIX-R91-B] ردیف‌های آمادهٔ آپلود آف‌سایت: بکاپ سالم (completed) که هنوز
     * با موفقیت به مقصد خارجی نرفته (pending یا شکستِ قبلی).
     * مدلِ صاحبِ جدول است — سرویس از اینجا می‌خواند (بدون SQL خام در سرویس).
     *
     * @return list<object>
     */
    public function findOffsitePending(int $limit = 10): array
    {
        return $this->db->table(self::$table)
            ->select('id', 'file_path', 'size_bytes')
            ->where('status', '=', 'completed')
            ->whereIn('offsite_status', [self::OFFSITE_PENDING, self::OFFSITE_FAILED])
            ->orderBy('id', 'ASC')
            ->limit(max(1, min(100, $limit)))
            ->get();
    }

    /**
     * [FIX-R91-B] ثبت نتیجهٔ آپلود آف‌سایت یک ردیف.
     * uploaded → کلید ریموت + زمان؛ failed → فقط پیام خطا (کلید/زمان پاک می‌شوند).
     */
    public function markOffsite(int $id, string $status, ?string $remoteKey, ?string $error): bool
    {
        $data = [
            'offsite_status' => $status,
            'offsite_uploaded_at' => $status === self::OFFSITE_UPLOADED ? date('Y-m-d H:i:s') : null,
            'offsite_remote_key' => $status === self::OFFSITE_UPLOADED ? $remoteKey : null,
            'offsite_error' => $status === self::OFFSITE_FAILED ? mb_substr(str_value($error), 0, 1000) : null,
        ];
        return (bool)$this->db->table(self::$table)
            ->where('id', '=', $id)
            ->update($data);
    }

    /** @return array<string, mixed>|null */
    public function getBackupStatus(string $backupId): ?array
    {
        $row = $this->db->table(self::$table)
            ->select('*')
            ->where('id', '=', $backupId)
            ->first();
        return $row ? (array)$row : null;
    }

    /** @return list<object> */
    public function getOlderThan(string $cutoffDate): array
    {
        return $this->db->table(self::$table)
            ->select('file_path')
            ->where('created_at', '<', $cutoffDate)
            ->get();
    }

    public function deleteOlderThan(string $cutoffDate): int
    {
        return (int)$this->db->table(self::$table)
            ->where('created_at', '<', $cutoffDate)
            ->delete();
    }

    /**
     * FIX-R36-W3 (F-A11-06): رکوردهای قدیمی با id + file_path — cleanup
     * fail-closed به id برای حذفِ «فقط» رکوردهای فایل‌های واقعاً حذف‌شده نیاز دارد.
     * @return list<object>
     */
    public function getOlderThanRecords(string $cutoffDate): array
    {
        return $this->db->table(self::$table)
            ->select('id')
            ->select('file_path')
            ->where('created_at', '<', $cutoffDate)
            ->get();
    }

    /**
     * FIX-R36-W3 (F-A11-06): حذف دقیق رکوردها با id — جایگزین deleteOlderThan
     * در cleanupOldBackups تا رکوردِ فایلی که unlink آن شکست خورده در DB بماند
     * (قابل جاروبِ دوباره) و فایل یتیم بی‌صدا نشود.
     * @param list<int> $ids
     */
    public function deleteByIds(array $ids): int
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $i): bool => $i > 0)));
        if ($ids === []) {
            return 0;
        }
        $deleted = 0;
        foreach (array_chunk($ids, 500) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '?'));
            $deleted += (int)$this->db->execute(
                "DELETE FROM " . self::$table . " WHERE id IN ({$placeholders})",
                $chunk
            );
        }
        return $deleted;
    }

    /** @return array<string, mixed> */
    public function getStats(): array
    {
        // [X377 راند ۹۸] وضعیت‌های شکست/آف‌سایت برای کارت‌های آمار ادمین
        $stats = $this->db->fetch(
            "SELECT
                COUNT(*) AS total_backups,
                SUM(size_bytes) AS total_size,
                MAX(created_at) AS last_backup,
                MIN(created_at) AS first_backup,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed_backups,
                SUM(CASE WHEN offsite_status = 'pending' THEN 1 ELSE 0 END) AS offsite_pending,
                SUM(CASE WHEN offsite_status = 'failed' THEN 1 ELSE 0 END) AS offsite_failed
             FROM " . self::$table
        );

        return [
            'total_backups' => (int)($stats->total_backups ?? 0),
            'total_size' => (int)($stats->total_size ?? 0),
            'last_backup' => $stats->last_backup ?? null,
            'first_backup' => $stats->first_backup ?? null,
            'failed_backups' => (int)($stats->failed_backups ?? 0),
            'offsite_pending' => (int)($stats->offsite_pending ?? 0),
            'offsite_failed' => (int)($stats->offsite_failed ?? 0),
        ];
    }

    /**
     * [X377 راند ۹۸] شمارش DEFINER-strip آخرین بکاپ completed — منبع: suffix
     * «X361: DEFINER-strip=n» که BackupService همیشه (از این راند حتی با توضیحِ
     * خالی) در description می‌نویسد. پارسی از خود description عمدی است تا
     * بدون مایگریشن/ستون جدید کار کند؛ رونویسی‌های قبل از راند ۹۸ (بکاپ بدون
     * توضیح) null برمی‌گردانند — نمایش UI «—» می‌گیرد.
     */
    public function getLastDefinerStrip(): ?int
    {
        $row = $this->db->table(self::$table)
            ->select('description')
            ->where('status', '=', 'completed')
            ->whereNotNull('description')
            ->where('description', 'LIKE', '%X361: DEFINER-strip=%')
            ->orderBy('id', 'DESC')
            ->limit(1)
            ->first();
        if ($row === null) {
            return null;
        }
        return preg_match('/X361: DEFINER-strip=(\\d+)/', (string)$row->description, $m) === 1
            ? (int)$m[1]
            : null;
    }
}
