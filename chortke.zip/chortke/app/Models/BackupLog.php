<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class BackupLog extends Model
{
    protected static string $table = 'backup_logs';

    /** [FIX-R91-B] وضعیت‌های آپلود آف‌سایت — منبع یگانهٔ رشته‌ها (NULL = هرگز تلاش نشده: ردیف‌های failed بکاپ) */
    public const OFFSITE_PENDING = 'pending';
    public const OFFSITE_UPLOADED = 'uploaded';
    public const OFFSITE_FAILED = 'failed';

    /** @return list<object> */
    public function getRecentBackups(int $limit = 20, int $offset = 0): array
    {
        $query = $this->db->table(self::$table)
            // [FIX-R91-B] ستون‌های آف‌سایت هم برای ستون وضعیت آپلود در جدول ادمین
            ->select('id', 'status', 'type', 'file_path', 'size_bytes', 'created_at', 'completed_at',
                     'offsite_status', 'offsite_uploaded_at', 'offsite_error')
            ->orderBy('created_at', 'DESC')
            ->limit($limit);

        if ($offset > 0) {
            $query->offset($offset);
        }

        return $query->get();
    }

    /** @return array<string, mixed>|null */
    /** @return array<string, mixed>|null */
    public function findById(int $backupId): ?array
    {
        $row = $this->db->table(self::$table)
            ->select('file_path', 'checksum', 'request_id')
            ->where('id', '=', $backupId)
            ->first();
        return $row ? (array)$row : null;
    }

    /** @return array<string, mixed>|null */
    public function findByFilename(string $filename): ?array
    {
        $result = $this->db->table(self::$table)
            ->select('file_path', 'checksum', 'request_id')
            ->where('file_path', '=', $filename)
            ->first();
        return $result ? (array) $result : null;
    }

    /** @param array<string, mixed> $data */
    public function logBackup(array $data): int
    {
        return (int)$this->db->table(self::$table)
            ->insert($data);
    }

    /**
     * [FIX-R91-B] ردیف‌های آمادهٔ آپلود آف‌سایت: بکاپ سالم (completed) که هنوز
     * با موفقیت به مقصد خارجی نرفته (pending یا شکستِ قبلی).
     * مدلِ صاحبِ جدول است — سرویس از اینجا می‌خواند (بدون SQL خام در سرویس).
     *
     * @return list<object>
     */
    public function findOffsitePending(int $limit = 10): array
    {
        return $this->db->table(self::$table)
            ->select('id', 'file_path', 'size_bytes')
            ->where('status', '=', 'completed')
            ->whereIn('offsite_status', [self::OFFSITE_PENDING, self::OFFSITE_FAILED])
            ->orderBy('id', 'ASC')
            ->limit(max(1, min(100, $limit)))
            ->get();
    }

    /**
     * [FIX-R91-B] ثبت نتیجهٔ آپلود آف‌سایت یک ردیف.
     * uploaded → کلید ریموت + زمان؛ failed → فقط پیام خطا (کلید/زمان پاک می‌شوند).
     */
    public function markOffsite(int $id, string $status, ?string $remoteKey, ?string $error): bool
    {
        $data = [
            'offsite_status' => $status,
            'offsite_uploaded_at' => $status === self::OFFSITE_UPLOADED ? date('Y-m-d H:i:s') : null,
            'offsite_remote_key' => $status === self::OFFSITE_UPLOADED ? $remoteKey : null,
            'offsite_error' => $status === self::OFFSITE_FAILED ? mb_substr(str_value($error), 0, 1000) : null,
        ];
        return (bool)$this->db->table(self::$table)
            ->where('id', '=', $id)
            ->update($data);
    }

    /** @return array<string, mixed>|null */
    public function getBackupStatus(string $backupId): ?array
    {
        $row = $this->db->table(self::$table)
            ->select('*')
            ->where('id', '=', $backupId)
            ->first();
        return $row ? (array)$row : null;
    }

    /** @return list<object> */
    public function getOlderThan(string $cutoffDate): array
    {
        return $this->db->table(self::$table)
            ->select('file_path')
            ->where('created_at', '<', $cutoffDate)
            ->get();
    }

    public function deleteOlderThan(string $cutoffDate): int
    {
        return (int)$this->db->table(self::$table)
            ->where('created_at', '<', $cutoffDate)
            ->delete();
    }

    /** @return array<string, mixed> */
    public function getStats(): array
    {
        $stats = $this->db->fetch(
            "SELECT
                COUNT(*) AS total_backups,
                SUM(size_bytes) AS total_size,
                MAX(created_at) AS last_backup,
                MIN(created_at) AS first_backup
             FROM " . self::$table
        );

        return [
            'total_backups' => (int)($stats->total_backups ?? 0),
            'total_size' => (int)($stats->total_size ?? 0),
            'last_backup' => $stats->last_backup ?? null,
            'first_backup' => $stats->first_backup ?? null,
        ];
    }
}
