<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * ExportData Model — Data Export & Bulk Operations
 * 
 * مسئولیت: عملیات صادرات data و bulk operations
 * استفاده می‌شود در: ExportService, AnalyticsService
 */
class ExportData extends Model
{
    /**
     * نام جدول (الزام قرارداد Core\\Model).
     * این مدل عمدتاً از کوئری‌های خام استفاده می‌کند، اما برای سازگاری با
     * متدهای پایه‌ی Model، جدول مرجع آن تعریف می‌شود.
     */
    protected static string $table = 'users';

    private const MAX_EXPORT_LIMIT = 5000;

    /**
     * پاکسازی داده‌ها از تزریق فرمول در اکسل/CSV (CSV Injection)
     */
    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function sanitizeRow(array $row): array
    {
        foreach ((array)$row as $key => $value) {
            if (\is_string($value)) {
                $val = \trim((string)$value);
                if ($val !== '' && \in_array($val[0], ['=', '+', '-', '@'], true)) {
                    $row[$key] = "'" . $value;
                }
            }
        }
        return $row;
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return list<array<string, mixed>>
     */
    private function sanitizeRows(array $rows): array
    {
        return \array_map([$this, 'sanitizeRow'], $rows);
    }

    public function getUsersStatement(?string $dateFrom = null, ?string $dateTo = null, ?string $kycStatus = null, ?string $tierLevel = null, int $limit = self::MAX_EXPORT_LIMIT): \PDOStatement
    {
        // CSV columns: email, mobile, kyc_status
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $where = [];
        $params = [];

        if ($dateFrom !== null) {
            // 🛡️ FIX-KYC-ENUM (باگ نهفتهٔ دوم، پروب): ستون‌ها باید با نام جدول صریح
            // شوند — «created_at» با JOIN wallets دوپهلو بود (1052) و هر کوئریِ
            // تاریخ‌دار می‌ترکید (ماسک شده بود: فیلترها هرگز از کنترلر عبور نمی‌کردند).
            $where[] = 'u.created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }
        if ($dateTo !== null) {
            $where[] = 'u.created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }
        if ($kycStatus !== null) {
            $where[] = 'u.kyc_status = ?';
            $params[] = $kycStatus;
        }
        // 🔒 FIX-KYC-ENUM (فرم CSV مرده): $tierLevel پذیرفته می‌شد اما هرگز در WHERE
        // اعمال نمی‌شد — فیلتر «سطح» فرم ادمین صرفاً تزئینی بود. اکنون همان
        // parameterized روی ستون واقعی level_slug اعمال می‌شود.
        if ($tierLevel !== null) {
            $where[] = 'u.level_slug = ?';
            $params[] = $tierLevel;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        // 🛡️ FIX-KYC-ENUM (باگ نهفتهٔ کشف‌شده با پروب): کوئری قبلاً «? موقعیتی» و
        // «:limit نامی» را مخلوط می‌کرد ⇒ PDOException HY093 به‌محض وجود هر فیلتری
        // (تاریخ/kyc). باگ تا امروز صدا نشده بود چون AdminExportController::filters()
        // همهٔ فیلترهای فرم را دور می‌ریخت (مسیر production همیشه بدون فیلتر می‌رفت).
        // ریشه‌ای: همهٔ bindها موقعیتی شدند (الگوی SendToSegmentNotificationJob با
        // LIMIT ?) و LIMIT هم به‌عنوان آخرین پارامتر int بسته می‌شود.
        $params[] = $limit;

        $stmt = $this->db->prepare(
            "SELECT u.id, u.full_name, u.email, u.mobile, u.kyc_status, u.level_slug, u.status, u.created_at, u.last_login,
                    COALESCE(w.balance_irt, 0) AS balance_irt, COALESCE(w.balance_usdt, 0) AS balance_usdt
             FROM users u
             LEFT JOIN wallets w ON w.user_id = u.id
             {$whereClause}
             ORDER BY u.created_at DESC
             LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->execute();

        return $stmt;
    }

    /** @return list<array<string, mixed>> */
    public function getUsers(?string $dateFrom = null, ?string $dateTo = null, ?string $kycStatus = null, ?string $tierLevel = null): array
    {
        $stmt = $this->getUsersStatement($dateFrom, $dateTo, $kycStatus, $tierLevel);
        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات تراکنش‌ها (Streamable)
     */
    public function getTransactionsStatement(?string $dateFrom = null, ?string $dateTo = null, ?string $type = null, ?string $status = null, int $limit = self::MAX_EXPORT_LIMIT): \PDOStatement
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $where = [];
        $params = [];

        if ($dateFrom !== null) {
            $where[] = 't.created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }
        if ($dateTo !== null) {
            $where[] = 't.created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }
        if ($type !== null) {
            $where[] = 't.type = ?';
            $params[] = $type;
        }
        if ($status !== null) {
            $where[] = 't.status = ?';
            $params[] = $status;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT t.id, t.transaction_id, u.full_name, t.type, t.currency, t.amount, t.balance_before, t.balance_after, t.status, t.created_at
              FROM transactions t
              LEFT JOIN users u ON t.user_id = u.id
              {$whereClause}
              ORDER BY t.created_at DESC
              LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        // 🛡️ FIX-KYC-ENUM: LIMIT به‌عنوان آخرین پارامتر موقعیتی (رفع HY093 — قبلاً
        // bind نامی :limit با پارامترهای موقعیتی ? مخلوط می‌شد و هر کوئریِ فیلتردار
        // می‌ترکید؛ الگو-یکسان با getUsersStatement)
        $stmt->bindValue(count((array)$params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt;
    }

    /** @return list<array<string, mixed>> */
    public function getTransactions(?string $dateFrom = null, ?string $dateTo = null, ?string $type = null, ?string $status = null): array
    {
        $stmt = $this->getTransactionsStatement($dateFrom, $dateTo, $type, $status);
        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات تسک‌ها
     */
    /** @return list<array<string, mixed>> */
    public function exportTasks(?string $status = null, int $limit = self::MAX_EXPORT_LIMIT): array
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $where = [];
        $params = [];

        if ($status !== null) {
            $where[] = 'status = ?';
            $params[] = $status;
        }

        // 🧹 FIX-COSMET-28: شرط اضافی (بدون WHERE — شرط ثابت type/deleted_at در SQL اصلی است)
        $whereClause = !empty($where) ? ' AND ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            // 🧹 FIX-COSMET-28 (X3/خارج از لنز): منبع واقعی — جدول legacy custom_tasks
            // نویسنده ندارد (۰ ردیف ⇒ اکسپورت همیشه خالی)؛ تسک‌های سفارشی واقعی در
            // ads با type='custom_task' زندگی می‌کنند. نام کلید creator_id (قرارداد
            // قبلی خروجی) با alias حفظ شد؛ deleted_at هم رعایت می‌شود.
            "SELECT id, user_id AS creator_id, title, description, category, price_per_task, total_budget, status, created_at, updated_at
              FROM ads
              WHERE type = 'custom_task' AND deleted_at IS NULL {$whereClause}
              ORDER BY created_at DESC
              LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        // 🛡️ FIX-KYC-ENUM: LIMIT به‌عنوان آخرین پارامتر موقعیتی (رفع HY093 — قبلاً
        // bind نامی :limit با پارامترهای موقعیتی ? مخلوط می‌شد و هر کوئریِ فیلتردار
        // می‌ترکید؛ الگو-یکسان با getUsersStatement)
        $stmt->bindValue(count((array)$params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات submissions
     */
    /** @return list<array<string, mixed>> */
    public function exportSubmissions(?string $status = null, int $limit = self::MAX_EXPORT_LIMIT): array
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $where = [];
        $params = [];

        if ($status !== null) {
            $where[] = 'status = ?';
            $params[] = $status;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            // FIX راند ۷۷ (ستون شبح): custom_task_submissions ستون rating ندارد — حذف از خروجی.
            "SELECT id, task_id, worker_id, status, submitted_at, approved_at, created_at
              FROM custom_task_submissions {$whereClause}
              ORDER BY submitted_at DESC
              LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        // 🛡️ FIX-KYC-ENUM: LIMIT به‌عنوان آخرین پارامتر موقعیتی (رفع HY093 — قبلاً
        // bind نامی :limit با پارامترهای موقعیتی ? مخلوط می‌شد و هر کوئریِ فیلتردار
        // می‌ترکید؛ الگو-یکسان با getUsersStatement)
        $stmt->bindValue(count((array)$params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات آمارهای سرانه
     * L-08: Note - For large datasets (>5000 users), consider cursor-based pagination
     * to avoid memory overflow. Current implementation loads all data into memory.
     * Consider implementing chunked export: export in batches of 1000 rows
     */
    /** @return list<array<string, mixed>> */
    public function exportUserAnalytics(?string $dateFrom = null, ?string $dateTo = null, int $limit = self::MAX_EXPORT_LIMIT): array
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        // FIX-R36-W3 (F-A19b-07): شرط تاریخ روی activity_logs در WHERE قرار داشت —
        // روی LEFT JOIN عملاً INNER JOIN می‌سازد و کاربرانِ بی‌فعالیت در بازه از
        // «تحلیل کاربر به کاربر» ناپدید می‌شوند. گزارهٔ تاریخ به ON منتقل شد.
        $on = [];
        $params = [];

        if ($dateFrom !== null) {
            $on[] = 'al.created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }

        if ($dateTo !== null) {
            $on[] = 'al.created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }

        $onClause = !empty($on) ? 'AND ' . implode(' AND ', $on) : '';

        $stmt = $this->db->prepare(
            "SELECT
                u.id, u.full_name, u.email,
                COUNT(al.id) as activity_count,
                COUNT(DISTINCT DATE(al.created_at)) as active_days
              FROM users u
              LEFT JOIN activity_logs al ON u.id = al.user_id {$onClause}
              GROUP BY u.id, u.full_name, u.email
              ORDER BY activity_count DESC
              LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        // 🛡️ FIX-KYC-ENUM: LIMIT به‌عنوان آخرین پارامتر موقعیتی (رفع HY093 — قبلاً
        // bind نامی :limit با پارامترهای موقعیتی ? مخلوط می‌شد و هر کوئریِ فیلتردار
        // می‌ترکید؛ الگو-یکسان با getUsersStatement)
        $stmt->bindValue(count((array)$params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات شکایات و اختلافات
     */
    /** @return list<array<string, mixed>> */
    public function exportDisputes(?string $status = null, int $limit = self::MAX_EXPORT_LIMIT): array
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $where = [];
        $params = [];

        if ($status !== null) {
            $where[] = 'status = ?';
            $params[] = $status;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            // FIX راند ۷۷ (ستون شبح): ستون‌های واقعی user_id/target_user_id هستند؛
            // با ALIAS همان قرارداد خروجی قبلی (reporter_id/respondent_id) حفظ شد.
            "SELECT id, ref_type, ref_id, user_id AS reporter_id, target_user_id AS respondent_id, reason, status, created_at, resolved_at
              FROM disputes {$whereClause}
              ORDER BY created_at DESC
              LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        // 🛡️ FIX-KYC-ENUM: LIMIT به‌عنوان آخرین پارامتر موقعیتی (رفع HY093 — قبلاً
        // bind نامی :limit با پارامترهای موقعیتی ? مخلوط می‌شد و هر کوئریِ فیلتردار
        // می‌ترکید؛ الگو-یکسان با getUsersStatement)
        $stmt->bindValue(count((array)$params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات لاگ‌های امنیتی
     */
    /** @return list<array<string, mixed>> */
    public function exportSecurityLogs(int $days = 30, int $limit = self::MAX_EXPORT_LIMIT): array
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $stmt = $this->db->prepare(
            // FIX راند ۷۷ (ستون شبح): security_logs ستون user_agent ندارد — حذف از خروجی.
            "SELECT id, level, message, user_id, ip_address, created_at
             FROM security_logs
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
             ORDER BY created_at DESC
             LIMIT ?"
        );
        $stmt->bindValue(1, $days, \PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات wallet transactions
     */
    /** @return list<array<string, mixed>> */
    public function exportWalletTransactions(?int $userId = null, int $limit = self::MAX_EXPORT_LIMIT): array
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $where = [];
        $params = [];

        if ($userId !== null) {
            // FIX راند ۷۷ (ستون شبح): ledger_entries جدول double-entry است؛ تراکنش‌های کیف پول کاربر
            // با account = 'wallet:{id}' شناسایی می‌شوند (ستون user_id هرگز وجود نداشت).
            $where[] = "account = CONCAT('wallet:', ?)";
            $params[] = $userId;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT id, account, currency, debit, credit, description, created_at
              FROM ledger_entries {$whereClause}
              ORDER BY created_at DESC
              LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        // 🛡️ FIX-KYC-ENUM: LIMIT به‌عنوان آخرین پارامتر موقعیتی (رفع HY093 — قبلاً
        // bind نامی :limit با پارامترهای موقعیتی ? مخلوط می‌شد و هر کوئریِ فیلتردار
        // می‌ترکید؛ الگو-یکسان با getUsersStatement)
        $stmt->bindValue(count((array)$params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات برداشت‌ها (Streamable)
     */
    public function getWithdrawalsStatement(?string $dateFrom = null, ?string $dateTo = null, ?string $status = null, ?string $currency = null, int $limit = self::MAX_EXPORT_LIMIT): \PDOStatement
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $where = [];
        $params = [];

        if ($dateFrom !== null) {
            $where[] = 'w.created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }
        if ($dateTo !== null) {
            $where[] = 'w.created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }
        if ($status !== null) {
            $where[] = 'w.status = ?';
            $params[] = $status;
        }
        if ($currency !== null) {
            $where[] = 'w.currency = ?';
            $params[] = $currency;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT w.id, w.transaction_id, u.full_name, u.email, w.amount, w.fee, w.final_amount, w.currency, w.status, w.method, w.created_at
              FROM withdrawals w
              LEFT JOIN users u ON w.user_id = u.id
              {$whereClause}
              ORDER BY w.created_at DESC
              LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        // 🛡️ FIX-KYC-ENUM: LIMIT به‌عنوان آخرین پارامتر موقعیتی (رفع HY093 — قبلاً
        // bind نامی :limit با پارامترهای موقعیتی ? مخلوط می‌شد و هر کوئریِ فیلتردار
        // می‌ترکید؛ الگو-یکسان با getUsersStatement)
        $stmt->bindValue(count((array)$params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt;
    }

    /** @return list<array<string, mixed>> */
    public function getWithdrawals(?string $dateFrom = null, ?string $dateTo = null, ?string $status = null, ?string $currency = null): array
    {
        $stmt = $this->getWithdrawalsStatement($dateFrom, $dateTo, $status, $currency);
        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }

    /**
     * صادرات Audit Trail (Streamable)
     */
    public function getAuditTrailStatement(?string $dateFrom = null, ?string $dateTo = null, ?string $event = null, ?int $userId = null, int $limit = self::MAX_EXPORT_LIMIT): \PDOStatement
    {
        $limit = \max(1, \min($limit, self::MAX_EXPORT_LIMIT));
        $where = [];
        $params = [];

        if ($dateFrom !== null) {
            $where[] = 'at.created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }
        if ($dateTo !== null) {
            $where[] = 'at.created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }
        if ($event !== null) {
            $where[] = 'at.event = ?';
            $params[] = $event;
        }
        if ($userId !== null) {
            $where[] = 'at.user_id = ?';
            $params[] = $userId;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT at.id, at.event, u.full_name as user_name, au.full_name as actor_name, at.context, at.ip_address, at.created_at
              FROM audit_trail at
              LEFT JOIN users u ON at.user_id = u.id
              LEFT JOIN users au ON at.actor_id = au.id
              {$whereClause}
              ORDER BY at.created_at DESC
              LIMIT ?"
        );

        /** @var mixed $val FIX-PSTAN: پارامترهای فعلی همه رشته‌اند؛ گارد int برای پارامترهای عددیِ آتی می‌ماند */
        foreach ((array)$params as $index => $val) {
            $stmt->bindValue($index + 1, $val, is_int($val) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        // 🛡️ FIX-KYC-ENUM: LIMIT به‌عنوان آخرین پارامتر موقعیتی (رفع HY093 — قبلاً
        // bind نامی :limit با پارامترهای موقعیتی ? مخلوط می‌شد و هر کوئریِ فیلتردار
        // می‌ترکید؛ الگو-یکسان با getUsersStatement)
        $stmt->bindValue(count((array)$params) + 1, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt;
    }

    /** @return list<array<string, mixed>> */
    public function getAuditTrail(?string $dateFrom = null, ?string $dateTo = null, ?string $event = null, ?int $userId = null): array
    {
        $stmt = $this->getAuditTrailStatement($dateFrom, $dateTo, $event, $userId);
        $rows = $this->fetchAssocList($stmt);
        return $this->sanitizeRows($rows);
    }
}
