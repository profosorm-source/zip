<?php

namespace App\Models;

use Core\Model;
use Core\Database;

class LotteryRound extends Model {
    protected static string $table = 'lottery_rounds';
    public const STATUS_UPCOMING = 'upcoming';
    public const STATUS_ACTIVE = 'active';
    public const STATUS_VOTING = 'voting';
    public const STATUS_CALCULATING = 'calculating';
    public const STATUS_COMPLETED = 'completed';
    public const STATUS_CANCELLED = 'cancelled';

    public const TYPE_WEEKLY = 'weekly';
    public const TYPE_MONTHLY = 'monthly';
/**
     * ایجاد دوره قرعه‌کشی
     * خروجی: id یا null
     */
    /** @param array<string, mixed> $data */
    public function create(array $data): ?int
    {
        $now = \date('Y-m-d H:i:s');

        $data['created_at'] = $data['created_at'] ?? $now;
        $data['updated_at'] = $data['updated_at'] ?? $now;
        $data['is_deleted'] = $data['is_deleted'] ?? 0;

        // 🛡️ FIX-S16-10 (بچ S16): سفیدلیست ستون‌های واقعی lottery_rounds —
        // کلیدهای مجاز = همان intersect_key کنترلر ادمین (X16) + ستون‌های وضعیت
        // مورد استفادهٔ LotteryCommandService (winner_user_id و …).
        $allowed = [
            'title', 'type', 'duration_days', 'prize_description',
            'prize_pool', 'prize_amount', 'ticket_price', 'max_capacity', 'currency',
            'entry_fee', 'start_date', 'end_date', 'status', 'draw_at',
            'winner_user_id', 'winner_ticket', 'drawn_at', 'completed_at',
            'created_at', 'updated_at', 'is_deleted',
        ];
        $filtered = [];
        foreach ($allowed as $col) {
            if (\array_key_exists($col, $data)) {
                $filtered[$col] = $data[$col];
            }
        }

        $columns = \array_keys($filtered);
        $values  = \array_values($filtered);

        $placeholders = \array_fill(0, \count($columns), '?');
        $colsSql = '`' . \implode('`,`', $columns) . '`';

        $sql = "INSERT INTO `lottery_rounds` ({$colsSql}) VALUES (" . \implode(',', $placeholders) . ")";

        $stmt = $this->db->prepare($sql);
        $ok = $stmt->execute($values);

        if (!$ok) return null;

        if (isset($data['id']) && int_value($data['id']) > 0) {
            return int_value($data['id']);
        }

        $id = (int)$this->db->lastInsertId();
        return $id > 0 ? $id : null;
    }

    public function find(int $id): ?\stdClass
    {
        $stmt = $this->db->query(
            "SELECT * FROM lottery_rounds WHERE id = ? AND is_deleted = 0 LIMIT 1",
            [$id]
        );

        $row = $stmt->fetch(\PDO::FETCH_OBJ) ?: false;
        return $this->normalizeToObject($row);
    }

    public function findWithWinner(int $id): ?\stdClass
    {
        $stmt = $this->db->query(
            "SELECT lr.*, u.full_name as winner_name
             FROM lottery_rounds lr
             LEFT JOIN users u ON lr.winner_user_id = u.id
             WHERE lr.id = ? AND lr.is_deleted = 0
             LIMIT 1",
            [$id]
        );

        $row = $stmt->fetch(\PDO::FETCH_OBJ) ?: false;
        return $this->normalizeToObject($row);
    }

    public function getActiveRound(): ?\stdClass
    {
        $stmt = $this->db->query(
            "SELECT * FROM lottery_rounds
             WHERE status IN (?, ?) AND is_deleted = 0
             ORDER BY start_date DESC
             LIMIT 1",
            [self::STATUS_ACTIVE, self::STATUS_VOTING]
        );

        $row = $stmt->fetch(\PDO::FETCH_OBJ) ?: false;
        return $this->normalizeToObject($row);
    }

    /** @param array<string, mixed> $filters */
    /** @return list<\stdClass> */
    /** @param array<string, mixed> $filters */
    /**
     * @param array<string, mixed> $filters
     * @return list<\stdClass>
     */
    public function getAll(array $filters = [], int $limit = 20, int $offset = 0): array
    {
        $limit  = \max(1, (int)$limit);
        $offset = \max(0, (int)$offset);

        $sql = "SELECT lr.*, u.full_name as winner_name
                FROM lottery_rounds lr
                LEFT JOIN users u ON lr.winner_user_id = u.id
                WHERE lr.is_deleted = 0";

        $params = [];

        if (!empty($filters['status'])) {
            $sql .= " AND lr.status = ?";
            $params[] = $filters['status'];
        }

        $sql .= " ORDER BY lr.start_date DESC LIMIT ? OFFSET ?";

        $stmt = $this->db->prepare($sql);
        $index = 1;
        foreach ($params as $val) {
            $stmt->bindValue($index++, $val);
        }
        $stmt->bindValue($index++, $limit, \PDO::PARAM_INT);
        $stmt->bindValue($index++, $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /** @param array<string, mixed> $filters */
    public function countAll(array $filters = []): int
    {
        $sql = "SELECT COUNT(*) as total FROM lottery_rounds WHERE is_deleted = 0";
        $params = [];

        if (!empty($filters['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        }

        $stmt = $this->db->query($sql, $params);
        $row = $this->fetchObject($stmt);

        return (int)($row->total ?? 0);
    }

    /** @param array<string, mixed> $data */
    public function update(int $id, array $data): bool
    {
        if (empty($data)) return false;

        $data['updated_at'] = \date('Y-m-d H:i:s');

        $allowed = [
            'title', 'type', 'duration_days', 'prize_description',
            'prize_pool', 'prize_amount', 'ticket_price', 'max_capacity', 'currency',
            'entry_fee', 'start_date', 'end_date', 'status', 'draw_at',
            'winner_user_id', 'winner_ticket', 'drawn_at', 'completed_at',
            'updated_at', 'is_deleted',
        ];

        $fields = [];
        $values = [];

        foreach ((array)$data as $k => $v) {
            if (!\is_string($k) || !\in_array($k, $allowed, true)) {
                throw new \InvalidArgumentException("Invalid lottery round column: " . (string)$k);
            }
            $fields[] = "`{$k}` = ?";
            $values[] = $v;
        }

        $values[] = $id;

        $sql = "UPDATE lottery_rounds
                SET " . \implode(', ', $fields) . "
                WHERE id = ? AND is_deleted = 0";

        $stmt = $this->db->query($sql, $values);

        return $stmt->rowCount() > 0;
    }

    /** @return list<\stdClass> */
    public function getCompletedRounds(int $limit = 10): array
    {
        $limit = \max(1, (int)$limit);

        $stmt = $this->db->prepare(
            "SELECT lr.*, u.full_name as winner_name
             FROM lottery_rounds lr
             LEFT JOIN users u ON lr.winner_user_id = u.id
             WHERE lr.status = ? AND lr.is_deleted = 0
             ORDER BY lr.end_date DESC
             LIMIT ?"
        );
        $stmt->bindValue(1, self::STATUS_COMPLETED);
        $stmt->bindValue(2, $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    public function getStats(): object
    {
        $stmt = $this->db->query(
            "SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN prize_amount ELSE 0 END), 0) as total_prizes
             FROM lottery_rounds
             WHERE is_deleted = 0"
        );

        $row = $this->fetchObject($stmt);
        return $row ?: (object)[];
    }
}
