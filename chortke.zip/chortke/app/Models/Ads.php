<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;
use App\Contracts\AdsRepositoryInterface;
use App\Enums\AdsStatus;
use App\Traits\Filterable;
use Core\ValueObjects\Money;

/**
 * Ads Model - متمرکزکننده تمام انواع تبلیغات در سیستم
 */
class Ads extends Model implements AdsRepositoryInterface
{
    use Filterable;

    protected static string $table = 'ads';

    /**
     * Only normalized adapter payloads reach Ads::create(). These campaign
     * columns are required to persist the same budget/count snapshot that the
     * central escrow manager locked; silently dropping them creates an ad whose
     * database budget disagrees with its locked funds.
     *
     * @var list<string>
     */
    protected array $fillable = [
        'user_id', 'title', 'description', 'type', 'status', 'currency',
        'platform', 'task_type', 'link', 'target_url',
        'price_per_task', 'price_per_click',
        'total_budget', 'remaining_budget', 'spent_budget',
        'total_count', 'remaining_count', 'pending_count', 'completed_count',
        'site_commission_percent', 'created_by',
        // F-A2-05: ستون «reward» در جدول ads وجود خارجی ندارد (تعلقش به
        // social_ads است) → از fillable حذف شد تا اگر روزی کلیدی با این نام
        // به مسیر mass-assignment برسد، 42S22 نهفته نسازد.
        'budget', 'metadata', 'created_at', 'updated_at',
        // FIX-R36-W2 (F-A19a-01): هفت ستون زندهٔ جدول ads که همهٔ مسیرهای
        // کانونیِ ایجاد آگهی پاس می‌دهند ولی filterFillable ساکت می‌ریخت →
        // آگهی اعلانی بدون push_body/icon/تارگتینگ (ارسال همگانی بی‌هدف)،
        // تسک سفارشی بدون proof_schema/reject_rules و بنر بدون restrictions
        // ثبت می‌شد؛ همه با SHOW COLUMNS زندهٔ ads تأیید شده‌اند.
        'restrictions', 'proof_schema', 'sample_image', 'auto_approve_hours',
        'country_restriction', 'os_restriction', 'reject_rules',
        // FIX-T6 (باگ V): ستون‌های بنری در fillable نبودند → filterFillable همه را
        // دور می‌ریخت → بنرهای ساخته‌شده از پنل ادمین placement/تصویر/زمان‌بندی
        // نداشتند و در سمت کاربر هرگز نمایش داده نمی‌شدند.
        'image_path', 'placement', 'banner_type', 'category', 'sort_order',
        'target', 'alt_text', 'is_active', 'start_date', 'end_date',
        // FIX-X199 (راند ۵۲): ستون‌های اختصاصی سئو و تسک سفارشی در fillable نبودند →
        // filterFillable هنگام create از آداپتورها ساکت حذف می‌کرد → کمپین سئوی
        // خریداری‌شده از پنل با min_payout/max_payout=صفر و target_duration=۶۰ و
        // keyword/site_url=NULL ثبت می‌شد (پاداش همیشه صفر = کمپین مرده‌به‌هنگام
        // در حالی که وجه تبلیغ‌دهنده قفل شده بود)؛ تسک سفارشی هم proof/deadline
        // را از دست می‌داد. حالا هر دو دسته ستون مجازند.
        'keyword', 'site_url', 'min_payout', 'max_payout',
        'target_duration', 'min_score', 'max_per_day',
        'proof_type', 'proof_description', 'deadline_hours', 'device_restriction',
        // 🛡️ FIX-SEO-23-01 (فاز ۲): حالت سه‌گانهٔ اثبات فرود (off/pixel/postback) و
        // راز HMAC پست‌بک — بدون این دو، filterFillable انتخاب تبلیغ‌دهنده را ساکت
        // دور می‌ریخت و آگهی همیشه off ثبت می‌شد (پلهٔ پاداش ۳ هرگز باز نمی‌شد).
        'seo_landing_proof_mode', 'seo_postback_secret',
    ];
    protected static array $searchable = ['ads.title', 'ads.description'];

    /** @var array<string, string|array{0: string, 1: string}> */
    protected static array $filterable = [
        'type' => '=',
        'status' => '=',
        'user_id' => '=',
        'a.type' => ['a.type', '='],
        'a.status' => ['a.status', '='],
        // 🛡️ FIX-M22-MED (N6): فیلتر نوع تسک برای adminList (قبلاً کلید در applyFilters نبود)
        'a.task_type' => ['a.task_type', '='],
        // 🛡️ FIX-M22-MED (N6): adminCount با table بدون alias — کلید بدون alias.
        'task_type' => ['task_type', '='],
    ];

    private function rowString(\stdClass $row, string $field, string $default = ''): string
    {
        $value = get_object_vars($row)[$field] ?? null;
        return is_scalar($value) ? (string)$value : $default;
    }

    private function rowInt(\stdClass $row, string $field, int $default = 0): int
    {
        $value = get_object_vars($row)[$field] ?? null;
        if (is_int($value)) return $value;
        if (is_string($value) && preg_match('/^-?\d+$/', $value) === 1) return (int)$value;
        return $default;
    }

    /** @param array<string, mixed> $filters */
    private function filterString(array $filters, string $field): ?string
    {
        $value = $filters[$field] ?? null;
        if (!is_scalar($value)) return null;
        $value = trim((string)$value);
        return $value === '' ? null : $value;
    }

    /** @param array<string, mixed> $filters */
    private function filterPositiveInt(array $filters, string $field): ?int
    {
        $value = $filters[$field] ?? null;
        if (is_int($value)) return $value > 0 ? $value : null;
        if (is_string($value) && ctype_digit($value)) {
            $integer = (int)$value;
            return $integer > 0 ? $integer : null;
        }
        return null;
    }

    /**
     * یافتن با قفل تراکنشی
     */
    public function findByIdForUpdate(int $id): ?\stdClass
    {
        if (!$this->db->inTransaction()) {
            throw new \RuntimeException("findByIdForUpdate must be called within an active database transaction.");
        }
        $stmt = $this->db->prepare("SELECT * FROM ads WHERE id = ? FOR UPDATE");
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_OBJ);
        return $row instanceof \stdClass ? $row : null;
    }

    public function cancelAdRemainingBudget(int $id): bool
    {
        $stmt = $this->db->prepare("UPDATE ads SET remaining_budget = 0, updated_at = NOW() WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function completeAdAndClearBudget(int $id, bool $softDelete = false): bool
    {
        $sql = "UPDATE ads SET remaining_budget = 0, status = 'completed', updated_at = NOW()";
        if ($softDelete) {
            $sql .= ", deleted_at = NOW()";
        }
        $sql .= " WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    // 🧹 FIX-COSMET-25 (A1-N11/پایین): cancelUserCustomTasks حذف شد — جدول legacy
    // custom_tasks هیچ نویسنده‌ای ندارد (۰ ردیف؛ تسک‌های سفارشی واقعی در ads با
    // type='custom_task' زنده‌اند) پس این UPDATE همیشه no-op بود. تسک‌های واقعیِ کاربر
    // در حذف حساب توسط cancelActiveTasksForUser (بستن همهٔ ردیف‌های ads کاربر)
    // پوشش داده می‌شوند؛ فراخوان مرده هم در همان سرویس حذف شد.

    /** @return list<\stdClass> */
    public function getByAdvertiser(int $userId, int $limit = 20, int $offset = 0, ?string $type = null, ?string $status = null): array
    {
        $q = $this->db->table(static::$table)
            ->where('user_id', '=', $userId);
            
        $this->applyFilters($q, [
            'type' => $type,
            'status' => $status
        ]);

        if ($type === 'custom_task') {
            // FIX-MODULE1-M10: این fragment عمداً از تیرِ selectRawUnsafe عبور
            // می‌کند نه selectRaw — scalar subquery از نظر گرامر SafeExpression
            // ممنوع است (تضمین ساختاری read-only) و عمداً هم باز نمی‌شود.
            // این رشته ۱۰۰٪ ثابتِ کد است (بدون هیچ ورودی کاربر: نام جدول/ستون‌ها
            // literal هستند)، لذا دقیقاً مصرف‌کنندهٔ مستندِ تیر Unsafe است:
            // بلاک ';' و کامنت + ثبت audit لاگ. نقل به selectRaw عادی باعث
            // SqlExpressionException پیش از اجرا می‌شد.
            $q->select('ads.*')
              ->selectRawUnsafe('(SELECT COUNT(s.id) FROM custom_task_submissions s WHERE s.task_id = ads.id) as submission_count');
        }

        return $q->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->offset($offset)
            ->get();
    }

    /**
     * دریافت آگهی بر اساس شناسه و کاربر
     */
    public function findByIdAndUser(int $id, int $userId): ?\stdClass
    {
        return $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->where('user_id', '=', $userId)
            ->first() ?: null;
    }

    /**
     * بروزرسانی وضعیت آگهی توسط مالک
     *
     * FIX-R36-W3 (F-A19a-10): قبلاً هر رشتهٔ دلخواهی را به status می‌نوشت (بدون
     * whitelist) — تلهٔ پنهان برای هر فراخوانِ آینده. اکنون فقط گذارهای مجازِ
     * مالک (فعال‌سازی/توقف آگهی خودش) مجاز است؛ با خروجی rowCount صادق.
     */
    public function updateStatusByUser(int $id, int $userId, string $status): bool
    {
        if (!in_array($status, ['active', 'paused'], true)) {
            return false;
        }
        return $this->db->table(static::$table)
            ->where('id', '=', $id)
            ->where('user_id', '=', $userId)
            ->update([
                'status' => $status,
                'updated_at' => date('Y-m-d H:i:s')
            ]) > 0;
    }

    /**
     * لیست ادمین با فیلتر نوع و وضعیت
     */
    /** @return list<\stdClass> */
    public function adminList(string $type = '', string $status = '', int $limit = 30, int $offset = 0, ?string $taskType = null): array
    {
        $q = $this->db->table(static::$table . ' as a')
            ->select('a.*', 'u.full_name as user_name', 'u.email as user_email')
            ->leftJoin('users as u', 'u.id', '=', 'a.user_id');

        // 🛡️ FIX-M22-MED (N6/T22-21): فیلتر «نوع تسک» (a.task_type) در مسیر بدون‌جستجو
        // کاملاً دور ریخته می‌شد (کنترلر می‌ساختش، این متد نمی‌خواندش) — انتخاب مدیر
        // هیچ اثری روی لیست نداشت.
        $this->applyFilters($q, [
            'a.type' => $type,
            'a.status' => $status,
            'a.task_type' => $taskType,
        ]);
        
        return $q->orderBy('a.created_at', 'DESC')
            ->limit($limit)
            ->offset($offset)
            ->get();
    }

    /**
     * شمارش ادمین با فیلتر نوع و وضعیت
     */
    public function adminCount(string $type = '', string $status = '', ?string $taskType = null): int
    {
        $q = $this->db->table(static::$table);
            
        $this->applyFilters($q, [
            'type' => $type,
            'status' => $status,
            // 🛡️ FIX-M22-MED (N6): شمارشِ هم‌شرط با لیست — قبلاً فیلتر نوع تسک فقط روی
            // ردیف‌ها اعمال می‌شد نه روی total صفحات.
            'task_type' => $taskType,
        ]);

        return $q->count();
    }

    /**
     * جستجوی ادمین/ماژول برای آگهی‌ها و تسک‌ها از طریق مدل Ads.
     */
    /**
         * @param array<string, mixed> $filters
         * @return array{items: list<\stdClass>, total: int}
         */
    public function searchAdminTasks(string $q = '', array $filters = [], int $limit = 20, int $offset = 0): array
    {
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);

        $where = ['a.deleted_at IS NULL'];
        $params = [];

        $type = $this->filterString($filters, 'type');
        if ($type !== null) {
            $type = strtolower($type);
            if ($type === 'social' || $type === 'social_task') {
                $where[] = "a.type IN ('social', 'social_task')";
            } elseif ($type === 'custom' || $type === 'custom_task') {
                $where[] = 'a.type = ?';
                $params[] = 'custom_task';
            } else {
                $where[] = 'a.type = ?';
                $params[] = $type;
            }
        }

        // 🛡️ FIX-M22-MED (N6/T22-21): شاخهٔ جستجو فقط 'type' عمومی را می‌خواند و
        // «نوع تسک» (task_type) بی‌صدا دور ریخته می‌شد.
        $taskTypeFilter = $this->filterString($filters, 'task_type');
        if ($taskTypeFilter !== null) {
            $where[] = 'a.task_type = ?';
            $params[] = $taskTypeFilter;
        }
        $status = $this->filterString($filters, 'status');
        if ($status !== null) {
            $where[] = 'a.status = ?';
            $params[] = $status;
        }
        $platform = $this->filterString($filters, 'platform');
        if ($platform !== null) {
            $where[] = 'a.platform = ?';
            $params[] = $platform;
        }
        $userId = $this->filterPositiveInt($filters, 'user_id');
        if ($userId !== null) {
            $where[] = 'a.user_id = ?';
            $params[] = $userId;
        }
        if ($q !== '') {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
            $where[] = '(a.title LIKE ? OR a.description LIKE ? OR a.keyword LIKE ?)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $whereSql = implode(' AND ', $where);
        $items = $this->db->fetchAll(
            "SELECT a.*, u.full_name AS user_name, u.email AS user_email
             FROM ads a
             LEFT JOIN users u ON u.id = a.user_id
             WHERE {$whereSql}
             ORDER BY a.created_at DESC
             LIMIT {$limit} OFFSET {$offset}",
            $params
        ) ?: [];
        $total = (int)$this->db->fetchColumn("SELECT COUNT(*) FROM ads a WHERE {$whereSql}", $params);

        return ['items' => $items, 'total' => $total];
    }

    /**
     * جستجوی تبلیغات SEO فعال
     * M08: Fixed LIKE injection with proper escaping
     */
    /** @return list<\stdClass> */
    public function getActiveForSearch(string $keyword, int $limit = 5): array
    {
        $now = date('Y-m-d H:i:s');
        // M08: Use escapeLikeValue() to prevent wildcard injection
        $escaped = $this->escapeLikeValue($keyword);
        $likeKeyword = '%' . $escaped . '%';
        
        return $this->db->table(static::$table)
            ->where('type', '=', 'seo')
            ->where('status', '=', 'active')
            ->where('remaining_budget', '>', 0)
            ->whereRaw('(deadline IS NULL OR deadline > ?)', [$now])
            ->where('keyword', 'LIKE', $likeKeyword)
            ->orderBy('price_per_click', 'DESC')
            ->orderBy('created_at', 'ASC')
            ->limit($limit)
            ->get();
    }

    /**
     * Atomically deduct a decimal monetary click cost. Counter updates remain
     * integer/float metrics, while budget never passes through float.
     */
    public function deductClick(int $id, string $amount): bool
    {
        if (bccomp($amount, '0', 8) < 0) {
            throw new \InvalidArgumentException("Deduction amount cannot be negative: {$amount}");
        }
        if (!$this->db->inTransaction()) {
            throw new \RuntimeException("deductClick must be executed within an active database transaction.");
        }
        $stmt = $this->db->prepare("SELECT id, remaining_budget, status, currency FROM `" . static::$table . "` WHERE id = ? AND status = 'active' FOR UPDATE");
        $stmt->execute([$id]);
        $row = $this->fetchObject($stmt);
        if ($row === null) return false;
        $currentRemaining = $this->rowString($row, 'remaining_budget');
        if ($currentRemaining === '') return false;
        $currency = $this->rowString($row, 'currency', 'irt');
        if (bccomp($currentRemaining, '0', 8) <= 0) {
            $this->db->prepare("UPDATE `" . static::$table . "` SET status = 'exhausted', updated_at = NOW() WHERE id = ?")->execute([$id]);
            return false;
        }
        $newRemaining = Money::fromString($currentRemaining, $currency)->subtract(Money::fromString($amount, $currency))->getAmount();
        if (bccomp($newRemaining, '0', 8) < 0) $newRemaining = '0';
        $newStatus = bccomp($newRemaining, '0', 8) <= 0 ? 'exhausted' : 'active';
        $success = $this->db->prepare("UPDATE `" . static::$table . "` SET clicks_count = clicks_count + 1, remaining_budget = ?, status = ?, updated_at = NOW() WHERE id = ?")->execute([$newRemaining, $newStatus, $id]);
        if ($success) return true;
        throw new \RuntimeException("Failed to update ad budget. Ad ID: {$id}, Amount: {$amount}");
    }

    /**
     * دریافت بنرهای فعال بر اساس موقعیت (Placement)
     */
    /** @return list<\stdClass> */
    /** @return list<\stdClass> */
    public function getActiveBannersByPlacement(string $placement, int $limit = 5): array
    {
        $now = date('Y-m-d H:i:s');
        
        // M43: Replaced MySQL ORDER BY RAND() with application-layer shuffle to optimize large dataset queries.
        $banners = $this->db->table(static::$table)
            ->where('type', '=', 'banner')
            ->where('placement', '=', $placement)
            ->where('status', '=', 'active')
            ->whereRaw('(start_date IS NULL OR start_date <= ?)', [$now])
            ->whereRaw('(end_date IS NULL OR end_date >= ?)', [$now])
            ->orderBy('sort_order', 'ASC')
            ->limit(100) // Cap fetched list size to prevent large-volume overhead
            ->get();
            
        if (!empty($banners)) {
            \shuffle($banners);
            return \array_slice($banners, 0, $limit);
        }
        
        return [];
    }

    /**
     * افزایش شمارنده نمایش به صورت گروهی برای بهینه‌سازی عملکرد N+1
     */
    /** @param list<int> $ids */
    public function bulkIncrementImpressions(array $ids, int $step = 1): bool
    {
        if (empty($ids)) return true;
        
        // ✅ H-04: Validate all IDs are positive integers
        $ids = array_filter($ids, fn($id) => is_int($id) && $id > 0);
        if (empty($ids)) return false;
        
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $sql = "UPDATE `" . static::$table . "` 
                SET impressions = impressions + ?,
                    ctr = CASE WHEN impressions > 0 THEN ROUND((clicks / (impressions + ?)) * 100, 2) ELSE 0 END 
                WHERE id IN ($placeholders)";
                
        $params = array_merge([$step, $step], $ids);
        return $this->db->prepare($sql)->execute($params);
    }

    /**
     * افزایش شمارنده نمایش (Impression) به صورت اتمیک
     */
    public function incrementImpression(int $id): bool
    {
        return $this->bulkIncrementImpressions([$id]);
    }

    /**
     * ثبت کلیک و آپدیت آمار CTR به صورت ترنزکشنال
     */
    public function registerInteractionClick(int $id, ?int $userId, string $ip): bool
    {
        if (!$this->db->inTransaction()) {
            throw new \RuntimeException("registerInteractionClick must be executed within an active database transaction.");
        }

        // قفل ردیف برای ثبت کلیک
        $stmt = $this->db->prepare("SELECT id, clicks, impressions FROM `" . static::$table . "` WHERE id = ? FOR UPDATE");
        $stmt->execute([$id]);
        $ad = $this->fetchObject($stmt);

        if ($ad === null) {
            return false;
        }

        // ثبت رکورد کلیک در لاگ سیستم
        $stmt = $this->db->prepare("INSERT INTO banner_clicks (banner_id, user_id, ip_address, clicked_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$id, $userId, $ip]);

        // بروزرسانی شمارنده کلی در جدول تبلیغات
        $newClicks = $this->rowInt($ad, 'clicks') + 1;
        $impressions = $this->rowInt($ad, 'impressions');
        $newCtr = $impressions > 0 ? \round(($newClicks / $impressions) * 100, 2) : 0.0;

        $stmt = $this->db->prepare("UPDATE `" . static::$table . "` SET clicks = ?, ctr = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$newClicks, $newCtr, $id]);

        return true;
    }

    /**
     * دریافت لیست تسک‌های سفارشی در دسترس برای کاربران انجام‌دهنده (Worker)
     */
    /**
         * @param array<string, mixed> $filters
         * @return list<\stdClass>
         */
    public function getAvailableCustomTasks(int $workerId, array $filters = [], int $limit = 20, int $offset = 0, string $type = 'custom_task'): array
    {
        $now = date('Y-m-d H:i:s');
        $q = $this->db->table(static::$table . ' as a')
            ->select('a.*', 'u.full_name as creator_name')
            ->selectRaw('(a.total_count - a.completed_count - a.pending_count) as remaining_slots')
            ->leftJoin('users as u', 'u.id', '=', 'a.user_id')
            ->where('a.type', '=', $type)
            ->where('a.status', '=', 'active')
            ->where('a.user_id', '!=', $workerId)
            ->where('a.remaining_budget', '>', 0)
            ->whereRaw('(a.total_count - a.completed_count - a.pending_count) > 0')
            ->whereRaw('(a.end_date IS NULL OR a.end_date > ?)', [$now])
            ->whereNull('a.deleted_at');

        if (!empty($filters['task_type'])) {
            $q->where('a.task_type', '=', $filters['task_type']);
        }

        if (!empty($filters['platform'])) {
            $q->where('a.platform', '=', $filters['platform']);
        }

        // 🛡️ FIX-M22-MED (N1-fold/D2-N15): فید وب ارسال‌های قبلاً-شروع‌شدهٔ همان
        // کاربر را با NOT EXISTS حذف می‌کند ولی لیست API نمی‌کرد — موبایل تسک‌هایی
        // نشان می‌داد که startTask آنها را رد می‌کند («شما قبلاً شروع کرده‌اید»).
        // قرارداد همان NOT EXISTS فید؛ SafeExpression ساب‌کوئری نمی‌پذیرد پس
        // شناسه‌ها با یک کوئری ساده و whereNotIn اعمال می‌شوند (الگوی FIX-YT-2).
        // فقط برای نوع custom_task — مسیر adtube منطق انحصاری خودش را دارد.
        if ($type === 'custom_task') {
            $startedIds = $this->startedCustomTaskIds($workerId);
            if ($startedIds !== []) {
                $q->whereNotIn('a.id', $startedIds);
            }
        }

        // ═══ 🛡️ FIX-YT-2 (تصمیم ۱-گزینه A) — فیلترهای ضدتکرار/کول‌داون/مدت، مختص AdTube ═══
        //  ۱) ممنوعیت مطلق تماشای تکراری: هر کمپینی که کاربر قبلاً «کامل تماشا کرده»
        //     (reward_paid=1) برای همیشه از لیست او خارج می‌شود.
        //  ۲) کول‌داون شبه‌تصادفی ۲۴–۷۲ ساعته: کمپین‌هایی که آخرین اجرای قطعی‌شده
        //     (rejected/completed) کاربر برای آن‌ها هنوز در بازهٔ کول‌داون است مخفی می‌مانند —
        //     طول کول‌داون از هش قطعی (ad, executor, execution) در AdTubeExecutionModel::cooldownHours
        //     محاسبه می‌شود تا روی سرور و در گارد start() یک نتیجه بدهد.
        //  ۳) بدون مدت ثبت‌شده (metadata.video_duration_seconds) → fail-closed از لیست حذف
        //     (FIX-YT-7: هیچ پیش‌فرضی مجاز نیست).
        //  پیاده‌سازی: گارد SafeExpression کوئری‌بیلدر subquery (EXISTS/IN-SELECT) را نمی‌پذیرد؛
        //  بنابراین شناسه‌های مستثنا ابتدا با دو کوئری ساده محاسبه و با whereNotIn اعمال می‌شوند —
        //  همان فرمول CRC32 در PHP (AdTubeExecutionModel::cooldownHours) تا هم‌نتیجهٔ گارد start() باشد.
        if ($type === 'adtube') {
            [$cdMinH, $cdMaxH] = \App\Models\AdTubeExecutionModel::cooldownBounds(); // FIX-YT-8: منبع واحد تنظیمات
            $cdSpan = max(1, $cdMaxH - $cdMinH + 1);

            $q->whereRaw("JSON_EXTRACT(a.metadata, '$.\"video_duration_seconds\"') IS NOT NULL
                          AND CAST(JSON_EXTRACT(a.metadata, '$.\"video_duration_seconds\"') AS UNSIGNED) > 0");

            // ① ممنوعیت مطلق تماشای تکراری
            $everCompleted = $this->db->fetchAll(
                "SELECT DISTINCT ad_id FROM adtube_views
                 WHERE executor_id = ? AND status = 'completed' AND reward_paid = 1",
                [$workerId]
            ) ?: [];
            // ② کول‌داون شبه‌تصادفی [min..max] ساعت از آخرین اجرای قطعی‌شده (completed/rejected)
            $lastSettled = $this->db->fetchAll(
                "SELECT id, ad_id, COALESCE(completed_at, updated_at) AS anchor_at
                 FROM adtube_views
                 WHERE executor_id = ? AND status IN ('completed','rejected')",
                [$workerId]
            ) ?: [];
            $excluded = [];
            foreach ($everCompleted as $row) {
                $excluded[(int)$row->ad_id] = true;
            }
            $nowTs = time();
            foreach ($lastSettled as $row) {
                if (isset($excluded[(int)$row->ad_id])) continue;
                $anchorTs = strtotime((string)$row->anchor_at);
                if ($anchorTs === false || $anchorTs <= 0) continue;
                // هم‌فرمول با AdTubeExecutionModel::cooldownHours (محدودهٔ [cdMinH..cdMaxH])
                $cooldownH = $cdMinH + (int)(crc32(((int)$row->ad_id) . ':' . $workerId . ':' . ((int)$row->id)) % $cdSpan);
                if ($anchorTs + $cooldownH * 3600 > $nowTs) {
                    $excluded[(int)$row->ad_id] = true;
                }
            }
            if (!empty($excluded)) {
                $q->whereNotIn('a.id', array_map('intval', array_keys($excluded)));
            }
        }

        return $q->orderBy('a.is_active', 'DESC') // First sticky/active
                 ->orderBy('a.created_at', 'DESC')
                 ->limit($limit)
                 ->offset($offset)
                 ->get();
    }

    /**
     * 🛡️ FIX-YT-5 (راند YT): اجراهای واقعی AdTube برای پنل ادمین — با کاربر، مدت،
     * پاداش و دلیل رد؛ جایگزین فیلدهای تزئینی partial قبلی.
     *
     * @return list<\stdClass>
     */
    public function getAdtubeExecutionsForAdmin(int $adId, int $limit = 25): array
    {
        return $this->db->fetchAll(
            "SELECT av.id, av.status, av.watch_time, av.progress_percent, av.video_duration,
                    av.playback_speed, av.reward_amount, av.reward_currency, av.reward_paid,
                    av.reject_reason, av.started_at, av.completed_at, av.created_at,
                    av.ip_address, u.username, u.email
             FROM adtube_views av
             LEFT JOIN users u ON u.id = av.executor_id
             WHERE av.ad_id = ?
             ORDER BY av.created_at DESC
             LIMIT ?",
            [$adId, max(1, $limit)]
        ) ?: [];
    }

    /**
     * شمارش تسک‌های سفارشی فعال و در دسترس
     */
    /** @param array<string, mixed> $filters */
    public function countAvailableCustomTasks(int $workerId, array $filters = [], string $type = 'custom_task'): int
    {
        $now = date('Y-m-d H:i:s');
        $q = $this->db->table(static::$table)
            ->where('type', '=', $type)
            ->where('status', '=', 'active')
            ->where('user_id', '!=', $workerId)
            ->where('remaining_budget', '>', 0)
            ->whereRaw('(total_count - completed_count - pending_count) > 0')
            ->whereRaw('(end_date IS NULL OR end_date > ?)', [$now])
            ->whereNull('deleted_at');

        if (!empty($filters['task_type'])) {
            $q->where('task_type', '=', $filters['task_type']);
        }

        return $q->count();
    }

    /**
     * 📱 FIX-MOBCTR-02 (A3-N7 — بچ قرارداد API موبایل ۲۰۲۶-۱۱-۰۷): شمارشِ
     * «هم‌شرطِ لیستِ API» برای meta.total — همان قیدهای countAvailableCustomTasks
     * به‌علاوهٔ حذف تسک‌های قبلاً-شروع‌شدهٔ همین کاربر (آینهٔ شاخهٔ custom_task در
     * getAvailableCustomTasks). بدون این شمارنده، meta.total از تعداد ردیف‌های
     * واقعیِ data.tasks بزرگ‌تر می‌شد (تسک‌های شروع‌شده در count می‌ماندند ولی در
     * لیست نبودند) و کلاینت آخرین صفحه را خالی می‌دید.
     * شمارندهٔ قدیمی countAvailableCustomTasks عمداً دست‌نخورده ماند — تمایز
     * معنایی دارد: آن یکی «همهٔ فعال‌ها» (badge وب) است، این یکی «قابل-شروع برای
     * این کاربر» (صفحه‌بندی API) است.
     */
    public function countStartableCustomTasks(int $workerId): int
    {
        $now = date('Y-m-d H:i:s');
        $q = $this->db->table(static::$table)
            ->where('type', '=', 'custom_task')
            ->where('status', '=', 'active')
            ->where('user_id', '!=', $workerId)
            ->where('remaining_budget', '>', 0)
            ->whereRaw('(total_count - completed_count - pending_count) > 0')
            ->whereRaw('(end_date IS NULL OR end_date > ?)', [$now])
            ->whereNull('deleted_at');

        $startedIds = $this->startedCustomTaskIds($workerId);
        if ($startedIds !== []) {
            $q->whereNotIn('id', $startedIds);
        }

        return $q->count();
    }

    /**
     * 📱 FIX-MOBCTR-02: شناسهٔ تسک‌هایی که این کاربر قبلاً شروع کرده و هنوز
     * تمام‌نشده است (expired/cancelled/rejected آزادند) — تک‌منبع برای لیست و
     * شمارش تا meta با data هم‌قید بماند.
     *
     * @return list<int>
     */
    private function startedCustomTaskIds(int $workerId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT DISTINCT task_id FROM custom_task_submissions WHERE worker_id = ? AND status NOT IN ('expired','cancelled','rejected')",
            [$workerId]
        ) ?: [];
        $ids = [];
        foreach ($rows as $row) {
            $ids[] = (int)(is_array($row) ? ($row['task_id'] ?? 0) : ($row->task_id ?? 0));
        }
        return $ids;
    }

    /**
     * افزایش شمارنده در حال انجام (برای جلوگیری از دریافت بیش از ظرفیت)
     */
    public function incrementPendingCount(int $id): bool
    {
        $stmt = $this->db->prepare("UPDATE `" . static::$table . "` SET pending_count = COALESCE(pending_count,0) + 1, remaining_count = GREATEST(COALESCE(remaining_count,total_count) - 1, 0) WHERE id = ?");
        return $stmt->execute([$id]);
    }

    /**
     * Re-consume one freed slot, used when a rejected/disputed custom task submission
     * is later resolved in favor of the worker.
     */
    public function decrementAdSlots(int $id): bool
    {
        $stmt = $this->db->prepare("UPDATE `" . static::$table . "` SET remaining_count = GREATEST(COALESCE(remaining_count,0) - 1, 0), updated_at = NOW() WHERE id = ?");
        return $stmt->execute([$id]);
    }

    /**
     * کاهش شمارنده در حال انجام
     */
    public function decrementPendingCount(int $id): bool
    {
        $stmt = $this->db->prepare("UPDATE `" . static::$table . "` SET pending_count = GREATEST(0, COALESCE(pending_count,0) - 1), remaining_count = COALESCE(remaining_count,0) + 1 WHERE id = ?");
        return $stmt->execute([$id]);
    }

    /**
     * Complete a custom task while deducting its decimal reward from budget.
     */
    public function incrementCustomTaskCompletion(int $id, string $costAmount, bool $shouldDecrementPending = true): bool
    {
        if (bccomp($costAmount, '0', 8) < 0) throw new \InvalidArgumentException('Custom-task cost cannot be negative');
        if (!$this->db->inTransaction()) throw new \RuntimeException("incrementCustomTaskCompletion must be executed within an active database transaction.");
        $stmt = $this->db->prepare("SELECT id, remaining_budget, completed_count, pending_count, total_count, status, currency FROM `" . static::$table . "` WHERE id = ? FOR UPDATE");
        $stmt->execute([$id]);
        $task = $this->fetchObject($stmt);
        if ($task === null) return false;
        $remainingBudget = $this->rowString($task, 'remaining_budget');
        if ($remainingBudget === '') return false;
        $currency = $this->rowString($task, 'currency', 'irt');
        $newRemainingBudget = Money::fromString($remainingBudget, $currency)->subtract(Money::fromString($costAmount, $currency))->getAmount();
        if (bccomp($newRemainingBudget, '0', 8) < 0) $newRemainingBudget = '0';
        $newCompletedCount = $this->rowInt($task, 'completed_count') + 1;
        $pendingCount = $this->rowInt($task, 'pending_count');
        $newPendingCount = $shouldDecrementPending ? max(0, $pendingCount - 1) : $pendingCount;
        $totalCount = $this->rowInt($task, 'total_count');
        $newStatus = bccomp($newRemainingBudget, '0', 8) <= 0 || ($totalCount > 0 && $newCompletedCount >= $totalCount) ? 'completed' : $this->rowString($task, 'status', 'active');
        return $this->db->prepare("UPDATE `" . static::$table . "` SET completed_count = ?, pending_count = ?, remaining_budget = ?, status = ?, updated_at = NOW() WHERE id = ?")->execute([$newCompletedCount, $newPendingCount, $newRemainingBudget, $newStatus, $id]);
    }

    /**
     * 🛡️ FIX H-15 — آینهٔ incrementCustomTaskCompletion برای ردِ اجباریِ
     * یک submissionِ «تأییدشده»: completed_count را یکی کم می‌کند و اگر وضعیت
     * «completed» صرفاً به‌خاطر همان تأیید فعال شده باشد و اکنون ظرفیت/بودجه
     * اجازه دهد، کمپین را به «active» برمی‌گرداند.
     *
     * توجه: remaining_budget عمداً دست‌نخورده می‌ماند — پاداشِ پس‌گرفته‌شده از
     * مجری به کیف پولِ تبلیغ‌دهنده برمی‌گردد نه به escrow؛ پس bookkeeping
     * بودجهٔ ردیف باید هم‌گام با escrow بماند (افزودنِ بودجه بدون شارژ اسکرو
     * یعنی تسویهٔ fail-closed برای اجرای بعدی).
     */
    public function decrementCustomTaskCompletion(int $id): bool
    {
        if (!$this->db->inTransaction()) throw new \RuntimeException("decrementCustomTaskCompletion must be executed within an active database transaction.");
        $stmt = $this->db->prepare("SELECT id, remaining_budget, completed_count, total_count, status FROM `" . static::$table . "` WHERE id = ? FOR UPDATE");
        $stmt->execute([$id]);
        $task = $this->fetchObject($stmt);
        if ($task === null) return false;
        $newCompletedCount = max(0, $this->rowInt($task, 'completed_count') - 1);
        $newStatus = $this->rowString($task, 'status', 'active');
        $remainingBudget = $this->rowString($task, 'remaining_budget', '0');
        $totalCount = $this->rowInt($task, 'total_count');
        if ($newStatus === 'completed'
            && is_numeric($remainingBudget) && bccomp($remainingBudget, '0', 8) > 0
            && ($totalCount <= 0 || $newCompletedCount < $totalCount)) {
            $newStatus = 'active';
        }
        return $this->db->prepare("UPDATE `" . static::$table . "` SET completed_count = ?, status = ?, updated_at = NOW() WHERE id = ?")->execute([$newCompletedCount, $newStatus, $id]);
    }

    // 🧹 FIX-M22-MED (T22-21/D1-N14): expireOldAdvertisements حذف شد — صفر فراخوان
    // داشت (مسیر زنده CronService::expireOldAdvertisements → AdsBudgetSettlement-
    // Service::reconcileLifecycle است) و منطقِ خودش هم معیوب بود: شرط
    // remaining_count <= 0 «پرشدنِ موقتِ ظرفیت با pending» را پایان کار می‌پنداشت و
    // بدون هیچ settle اسکروی ردیف را completed می‌کرد؛ بعد از رد آن اجراها،
    // decrementPendingCount ظرفیت را برمی‌گرداند ولی status مرده می‌ماند.
    /** @return array<string, string> */
    public function taskTypes(): array
    {
        return [
            'signup'  => 'ثبت‌نام',
            'install' => 'نصب برنامه',
            'review'  => 'نظر دادن',
            'vote'    => 'رأی دادن',
            'follow'  => 'دنبال کردن',
            'join'    => 'عضویت',
            'custom'  => 'سفارشی',
        ];
    }

    // 🧹 FIX-COSMET-26 (A1-N12/پایین): proofTypes() حذف شد — صفر فراخوان در کل
    // درخت (برچسب‌های نمایشی نوع مدرک از CustomTaskProofSchema + ویو proof.php
    // می‌آیند؛ منبع واحد نرمال‌سازی همان normalizeType است). الگوی پاک‌سازی
    // T22-21 (متدهای صفر-فراخوان).

    /**
     * FIX-STATUS-ENUM: به AdsStatus::labelsMap() delegate می‌شود — منبع واحد
     * برچسب/رنگ تبلیغات (مصوب مالک: مهاجرت سه‌گانه به الگوی Enum).
     * امضای عمومی بدون تغییر تا ۴ نقطهٔ مصرف بدون تغییر بمانند.
     *
     * @return array<string, string>
     */
    public function statusLabels(): array
    {
        return AdsStatus::labelsMap();
    }

    /**
     * FIX-STATUS-ENUM: به AdsStatus::badgesMap() delegate می‌شود (منبع واحد).
     *
     * @return array<string, string>
     */
    public function statusClasses(): array
    {
        return AdsStatus::badgesMap();
    }

    /** @return array<string, string> */
    public function submissionStatusLabels(): array
    {
        return [
            'in_progress' => 'در حال انجام',
            'submitted'   => 'ارسال شده',
            'approved'    => 'تایید شده',
            'rejected'    => 'رد شده',
            'expired'     => 'منقضی شده',
            'disputed'    => 'در اختلاف',
            // 🧹 FIX-COSMET-02 (A2-N7/پایین): resolved_split که DisputeService (تسویه
            // توافقی) روی submission می‌نویسد اضافه شد — قبلاً کلید خام در
            // admin/custom-tasks/show.php:122 رندر می‌شد.
            'resolved_split' => 'تسویه اختلاف (تقسیم)',
        ];
    }

    /**
     * جستجوی ادمین با JOIN کامل کاربر (user email/full_name).
     * جایگزین adminSearchAds() در AdminAdsController که از getDb() استفاده می‌کرد.
     */
    /**
         * @param array<string, mixed> $filters
         * @return array{items: list<\stdClass>, total: int}
         */
    public function searchAdminWithUser(
        string $q = '',
        array $filters = [],
        int $limit = 30,
        int $offset = 0
    ): array {
        $limit  = max(1, min(100, $limit));
        $offset = max(0, $offset);

        $where  = ['a.deleted_at IS NULL'];
        $params = [];

        $typeFilter = $this->filterString($filters, 'type');
        if ($typeFilter !== null) {
            $where[] = 'a.type = ?';
            $params[] = $typeFilter;
        }
        $statusFilter = $this->filterString($filters, 'status');
        if ($statusFilter !== null) {
            $where[] = 'a.status = ?';
            $params[] = $statusFilter;
        }
        $userIdFilter = $this->filterPositiveInt($filters, 'user_id');
        if ($userIdFilter !== null) {
            $where[] = 'a.user_id = ?';
            $params[] = $userIdFilter;
        }
        $dateFrom = $this->filterString($filters, 'date_from');
        if ($dateFrom !== null) {
            $where[] = 'DATE(a.created_at) >= ?';
            $params[] = $dateFrom;
        }
        $dateTo = $this->filterString($filters, 'date_to');
        if ($dateTo !== null) {
            $where[] = 'DATE(a.created_at) <= ?';
            $params[] = $dateTo;
        }

        if ($q !== '') {
            $like     = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
            $where[]  = '(a.title LIKE ? OR a.description LIKE ? OR a.keyword LIKE ? OR u.email LIKE ? OR u.full_name LIKE ?)';
            array_push($params, $like, $like, $like, $like, $like);
        }

        $whereSql = implode(' AND ', $where);

        $items = $this->db->fetchAll(
            "SELECT a.*, u.full_name AS user_name, u.email AS user_email
             FROM ads a
             LEFT JOIN users u ON u.id = a.user_id
             WHERE {$whereSql}
             ORDER BY a.created_at DESC
             LIMIT {$limit} OFFSET {$offset}",
            $params
        ) ?: [];

        $total = (int)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM ads a LEFT JOIN users u ON u.id = a.user_id WHERE {$whereSql}",
            $params
        );

        return ['items' => $items, 'total' => $total];
    }

    // ── Favorites (Task Bookmarks) ────────────────────────────────────────

    public function isTaskFavorited(int $userId, int $adId): bool
    {
        return (bool)$this->db->fetchColumn(
            "SELECT COUNT(*) FROM user_favorites WHERE user_id = ? AND target_id = ? AND target_type = 'ad'",
            [$userId, $adId]
        );
    }

    public function addToFavorites(int $userId, int $adId): bool
    {
        try {
            $this->db->query(
                "INSERT IGNORE INTO user_favorites (user_id, target_id, target_type, created_at) VALUES (?, ?, 'ad', NOW())",
                [$userId, $adId]
            );
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    public function removeFromFavorites(int $userId, int $adId): bool
    {
        try {
            $this->db->execute(
                "DELETE FROM user_favorites WHERE user_id = ? AND target_id = ? AND target_type = 'ad'",
                [$userId, $adId]
            );
            return true;
        } catch (\Throwable) {
            return false;
        }
    }
}
