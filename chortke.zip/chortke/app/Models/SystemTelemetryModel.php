<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * SystemTelemetryModel — سلامت سیستمی، کارایی و امنیت پلتفرم
 */
class SystemTelemetryModel extends Model
{
    protected static string $table = 'performance_logs';

    /** @return list<\stdClass> */
    public function getActiveAlertRules(): array
    {
        // FIX-R70-D1 (O-R70-1 — راند ۷۰، deep-dive آداپتورهای اعلان):
        // مصرف‌کنندهٔ این خروجی (LogNotificationAdapter::evaluateRule) قرارداد
        // «threshold» و «time_window» را می‌خواند — همان شکل مرجع موتور یکم
        // (SentryModel::getAlertRules با alias مستقیم ستون‌ها) و همان شکلِ
        // pin‌شده در tests/Unit/Adapters/P3NotifyAdaptersPinTest.php.
        // SELECT * خام، ستون‌های threshold_value/time_window_minutes را بدون
        // alias می‌داد ⇒ آستانه/پنجره در evaluateRule همیشه ۰ خوانده می‌شد
        // (قانون با operator>= در مقدار صفر هم fire می‌شد — هشدار کاذب).
        // last_triggered_at واقعی حفظ شده تا fast-path suppression موتور دوم
        // (LogNotificationAdapter::checkAlertRules:421) همچنان کار کند.
        return $this->db->fetchAll(
            "SELECT id, rule_name, `condition`, threshold_value AS threshold,
                    time_window_minutes AS time_window, severity, is_active,
                    last_triggered_at, created_at
             FROM alert_rules
             WHERE is_active = 1"
        ) ?: [];
    }

    public function updateRuleLastTriggered(int $ruleId): bool
    {
        return (bool)$this->db->table('alert_rules')
            ->where('id', '=', $ruleId)
            ->update(['last_triggered_at' => date('Y-m-d H:i:s')]);
    }

    /**
     * FIX-P3-ADP-113: claim اتمیک برای ارسال هشدار قانون.
     *
     * UPDATE شرطی اتمیک انجام می‌دهد: فقط وقتی برد که rule داخل پنجرهٔ suppression
     * نباشد؛ هر دو worker همزمان که claim بگیرند، فقط یکی affected=1 می‌گیرد و
     * ریسهٔ «هر دو ارسال می‌کنند» بسته می‌شود (بر خلاف خواندن last_triggered_at +
     * UPDATE بی‌قید که TOCTOU داشت).
     *
     * @param int $ruleId شناسهٔ قانون
     * @param int $suppressionSeconds پنجرهٔ suppression به ثانیه (clamp 0..86400)
     * @return bool true یعنی این فراخوانی claim را برد و اجازهٔ ارسال دارد
     */
    public function claimAlertRuleTrigger(int $ruleId, int $suppressionSeconds = 3600): bool
    {
        $suppressionSeconds = max(0, min($suppressionSeconds, 86400));
        $affected = $this->db->execute(
            'UPDATE alert_rules SET last_triggered_at = NOW()'
            . ' WHERE id = ? AND (last_triggered_at IS NULL OR last_triggered_at <= DATE_SUB(NOW(), INTERVAL ? SECOND))',
            [$ruleId, $suppressionSeconds]
        );
        return $affected === 1;
    }

    /**
     * FIX-P3-ADP-113: آزادسازی best-effort claim — وقتی ارسال بعد از claimِ موفق
     * کاملاً شکست خورد، مقدار قبلی last_triggered_at برمی‌گردد تا suppression
     * یک‌ساعته به خاطر قطعیِ گذرای کانال مسلح نشود (قرارداد FIX-P3-ADP-114).
     *
     * گارد زمانی در WHERE جلوی بازنویسیِ claimِ تازه‌ترِ worker دیگری را می‌گیرد.
     */
    public function releaseAlertRuleClaim(int $ruleId, ?string $previousLastTriggeredAt): bool
    {
        try {
            if ($previousLastTriggeredAt === null) {
                $this->db->execute(
                    'UPDATE alert_rules SET last_triggered_at = NULL'
                    . ' WHERE id = ? AND last_triggered_at >= DATE_SUB(NOW(), INTERVAL 10 SECOND)',
                    [$ruleId]
                );
            } else {
                $this->db->execute(
                    'UPDATE alert_rules SET last_triggered_at = ?'
                    . ' WHERE id = ? AND last_triggered_at >= DATE_SUB(NOW(), INTERVAL 10 SECOND)',
                    [$previousLastTriggeredAt, $ruleId]
                );
            }
            return true;
        } catch (\Throwable) {
            return false;
        }
    }

    public function getErrorCount(int $minutes): int
    {
        // 🛡️ FIX-R36-W3 (F-A19a-06): شمارش از error_logs بود — جدولی که به‌خودی‌خود
        // همیشه خالی است (FIX-X207: نگاشت به sentry_events انجام شد ولی این خواننده
        // جا ماند) → قانون هشدار «error_count» در موتور دوم (LogNotificationAdapter:371)
        // هرگز آتش نمی‌زد. نگاشت canonical همان SentryModel::getMetricValue:471.
        return (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM sentry_events WHERE created_at >= ?",
            [date('Y-m-d H:i:s', $this->relativeTimestamp("-{$minutes} minutes"))]
        );
    }

    public function getCriticalErrorCount(int $minutes): int
    {
        // 🛡️ FIX-S13-2: کوئری قبلی روی error_logs.level می‌رفت — ستونی که هرگز در
        // error_logs وجود نداشته (اسکیمای واقعی: exception_class/message/status/...)
        // → هر ارزیابیِ قانون «critical_errors» با SQLSTATE 42S22 شکست می‌خورد و
        // catch بیرونی آن را بی‌صدا می‌بلعید (قانون هشدار همیشه کور بود — همان
        // الگوی FIX-X354 که موتور دوم هشدار یعنی LogNotificationAdapter از قلم
        // افتاده بود). نگاشت canonical همان SentryModel::getMetricValue است تا هر
        // دو موتور برای یک نام متریک، عدد یکسان ببینند (sentry_events.level ∈
        // {'critical','fatal'}؛ SHOW COLUMNS sentry_events — ستون level موجود است).
        return (int) $this->db->table('sentry_events')
            ->whereIn('level', ['critical', 'fatal'])
            ->where('created_at', '>=', date('Y-m-d H:i:s', $this->relativeTimestamp("-{$minutes} minutes")))
            ->count();
    }

    public function getSlowRequestCount(int $minutes): int
    {
        $hasIsSlowColumn = (bool) $this->db->query("SHOW COLUMNS FROM performance_logs LIKE 'is_slow'")->fetch();

        if ($hasIsSlowColumn) {
            return (int) $this->db->table('performance_logs')
                ->where('is_slow', '=', 1)
                ->where('created_at', '>=', date('Y-m-d H:i:s', $this->relativeTimestamp("-{$minutes} minutes")))
                ->count();
        }

        return (int) $this->db->table('performance_logs')
            ->where('metric', '=', 'request_duration_ms')
            ->where('created_at', '>=', date('Y-m-d H:i:s', $this->relativeTimestamp("-{$minutes} minutes")))
            ->count();
    }

    public function getFailedLoginCount(int $minutes): int
    {
        // 🛡️ FIX-S13-1: کوئری قبلی روی security_logs.event_type می‌رفت — ستونی که
        // هرگز در security_logs وجود نداشت (اسکیمای واقعی: id, user_id, level,
        // message, ip_address, created_at — اثبات SHOW COLUMNS + اثبات اجرایی
        // 42S22 قبل از فیکس) → قانون هشدار «failed_login» در موتور
        // LogNotificationAdapter روی هر ارزیابی استثنا می‌داد و catch بیرونی
        // بی‌صدا آن را می‌بلعید (قانون همیشه کور). نگاشت canonical همان
        // FIX-X354 در SentryModel::getMetricValue است: پیشوند پیام
        // «ورود ناموفق» که AuthService با level=WARNING می‌نویسد.
        return (int) $this->db->table('security_logs')
            ->where('message', 'LIKE', 'ورود ناموفق%')
            ->where('created_at', '>=', date('Y-m-d H:i:s', $this->relativeTimestamp("-{$minutes} minutes")))
            ->count();
    }

    public function getSystemHealth(): object
    {
        $dbSize = $this->db->fetch(
            "SELECT ROUND(SUM(DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS size_mb
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE()"
        );

        // 🛡️ FIX-R36-W3 (F-A19a-06): پرس‌وجوی قبلی type/level را از activity_logs
        // می‌خواند — ستون‌هایی که در جدول زنده وجود ندارند (DESCRIBE: id,user_id,
        // event,action,description,channel,context,ip_address,created_at,deleted_at)
        // → 42S22 اگر روزی فراخوانی می‌شد. نگاشت به sentry_events (گروه‌بندی per-level)
        // — متد امروز zero-caller است (AnalyticsQueryService مسیر رسمی است)؛ اصلاح
        // صرفاً مین را از حالت خراب-اگر-صدا‌شده خارج می‌کند.
        $recentErrors = $this->db->fetchAll(
            "SELECT level AS type, COUNT(*) AS count
             FROM sentry_events
             WHERE created_at >= ?
             GROUP BY level
             ORDER BY count DESC
             LIMIT 5",
            [date('Y-m-d H:i:s', $this->relativeTimestamp('-24 hours'))]
        ) ?: [];

        $rateLimitHits = $this->db->table('rate_limits')
            ->where('created_at', '>=', date('Y-m-d H:i:s', $this->relativeTimestamp('-24 hours')))
            ->where('exceeded', '=', 1)
            ->count();

        return (object)[
            'database_size_mb' => (float)($dbSize->size_mb ?? 0),
            'recent_errors' => $recentErrors,
            'rate_limit_hits' => (int)$rateLimitHits,
        ];
    }

    private function relativeTimestamp(string $expression): int
    {
        $timestamp = strtotime($expression);
        if ($timestamp === false) {
            throw new \RuntimeException('Unable to calculate telemetry time window.');
        }
        return $timestamp;
    }
}