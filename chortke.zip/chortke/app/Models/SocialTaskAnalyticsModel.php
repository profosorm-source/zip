<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * SocialTaskAnalyticsModel - Handles Ratings, User Trust, Adjustments, Snapshots, and Execution Stats
 */
class SocialTaskAnalyticsModel extends Model
{
    protected static string $table = 'social_ratings';

    // --- Rating Operations ---

    /** @param array<string, mixed> $data */
    public function createRating(array $data): int
    {
        // ۱. بررسی وضعیت execution (فقط تسک‌های با موفقیت انجام‌شده قابل امتیازدهی هستند)
        $exec = $this->db->fetch(
            "SELECT id FROM social_task_executions 
             WHERE id = ? AND status IN ('approved', 'soft_approved') LIMIT 1",
            [$data['execution_id']]
        );
        
        if (!$exec) {
            throw new \RuntimeException('Cannot rate incomplete or rejected execution');
        }

        // ۲. بررسی عدم ارسال امتیاز تکراری
        if ($this->hasUserRated(int_value($data['execution_id']), int_value($data['rater_id']), str_value($data['rater_type']))) {
            throw new \RuntimeException('You have already rated this execution');
        }

        return $this->db->insert(
            "INSERT INTO social_ratings
               (execution_id, rater_id, rated_id, rater_type, stars, comment, status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, 'approved', NOW())",
            [
                $data['execution_id'],
                $data['rater_id'],
                $data['rated_id'],
                $data['rater_type'],
                $data['stars'],
                $data['comment']
            ]
        );
    }

    public function getAvgRating(int $userId, string $raterType): ?\stdClass
    {
        // FIX-R36-W3 (F-A19a-05): فیلتر status='approved' اضافه شد تا با
        // getUserRatingHistory هم‌سان باشد (اگر روزی صف moderation غیرمرده شود،
        // رأی‌های pending/rejected وارد میانگین عمومی نمی‌شوند). امروز all-approved
        // است (createRating هاردکد 'approved') — تغییر فعلاً no-op ایمن است.
        return $this->db->fetch(
            "SELECT AVG(stars) AS avg_stars, COUNT(*) AS total_ratings
             FROM social_ratings
             WHERE rated_id = ? AND rater_type = ? AND status = 'approved'",
            [$userId, $raterType]
        );
    }

    /** @return list<\stdClass> */
    public function getUserRatingHistory(int $userId, string $raterType, int $limit): array
    {
        return $this->db->fetchAll(
            "SELECT sr.stars, sr.comment, sr.created_at, u.full_name AS rater_name
             FROM social_ratings sr
             JOIN users u ON u.id = sr.rater_id
             WHERE sr.rated_id = ? AND sr.rater_type = ? AND sr.status = 'approved'
             ORDER BY sr.created_at DESC
             LIMIT ?",
            [$userId, $raterType, $limit]
        );
    }

    /** @return list<\stdClass> */
    public function getPendingRatings(int $limit, int $offset): array
    {
        return $this->db->fetchAll(
            "SELECT sr.*, u.full_name AS rater_name, rated.full_name AS rated_name, sa.title AS ad_title
             FROM social_ratings sr
             JOIN users u ON u.id = sr.rater_id
             JOIN users rated ON rated.id = sr.rated_id
             JOIN social_task_executions ste ON ste.id = sr.execution_id
             JOIN ads sa ON sa.id = ste.ad_id
             WHERE sr.status = 'pending'
             ORDER BY sr.created_at DESC
             LIMIT ? OFFSET ?",
            [$limit, $offset]
        );
    }

    public function getRatingById(int $id): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT sr.*, u.full_name AS rater_name, rated.full_name AS rated_name, sa.title AS ad_title
             FROM social_ratings sr
             JOIN users u ON u.id = sr.rater_id
             JOIN users rated ON rated.id = sr.rated_id
             JOIN social_task_executions ste ON ste.id = sr.execution_id
             JOIN ads sa ON sa.id = ste.ad_id
             WHERE sr.id = ?",
            [$id]
        );
    }

    public function updateRatingStatus(int $id, string $status, int $adminId): bool
    {
        return (bool)$this->db->query(
            "UPDATE social_ratings SET status = ?, reviewed_by = ?, reviewed_at = NOW(), updated_at = NOW() WHERE id = ?",
            [$status, $adminId, $id]
        );
    }

    public function getRatingStats(): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT
                SUM(status = 'pending') AS pending_reviews,
                SUM(status = 'approved') AS approved_reviews,
                SUM(status = 'rejected') AS rejected_reviews
             FROM social_ratings"
        );
    }

    /** @return list<\stdClass> */
    public function getRatingHistoryFull(int $userId, string $column, int $limit, int $offset): array
    {
        $allowedColumns = ['rater_id', 'rated_id'];
        if (!in_array($column, $allowedColumns, true)) {
            throw new \InvalidArgumentException('Invalid column name');
        }

        return $this->db->fetchAll(
            "SELECT sr.*, u.full_name AS rater_name, rated.full_name AS rated_name, sa.title AS ad_title
             FROM social_ratings sr
             JOIN users u ON u.id = sr.rater_id
             JOIN users rated ON rated.id = sr.rated_id
             JOIN social_task_executions ste ON ste.id = sr.execution_id
             JOIN ads sa ON sa.id = ste.ad_id
             WHERE sr.{$column} = ?
             ORDER BY sr.created_at DESC
             LIMIT ? OFFSET ?",
            [$userId, $limit, $offset]
        );
    }

    public function hasUserRated(int $executionId, int $raterId, string $raterType): bool
    {
        $row = $this->db->fetch(
            "SELECT id FROM social_ratings
             WHERE execution_id = ? AND rater_id = ? AND rater_type = ? LIMIT 1",
            [$executionId, $raterId, $raterType]
        );
        return (bool)$row;
    }

    public function recalculateUserStats(int $userId, string $type): bool
    {
        // FIX راند ۷۷ (ستون شبح): ستون‌های social_advertiser_rating/social_executor_rating/social_rating_count
        // در users وجود ندارند (اسکیمای فعلی). این متد در کل کد بی‌فراخوان است و aggregate امتیازها
        // همیشه on-the-fly از social_ratings محاسبه می‌شود؛ فقط محاسبه و اعتبارسنجی انجام می‌دهیم تا
        // خطای 42S22 رخ ندهد. هیچ داده‌ای نوشته نمی‌شود.
        $raterType = $type === 'advertiser' ? 'executor' : 'advertiser';
        
        $stats = $this->db->fetch("
            SELECT AVG(stars) as avg_rating, COUNT(*) as count
            FROM social_ratings
            WHERE rated_id = ? AND rater_type = ? AND status = 'approved'
        ", [$userId, $raterType]);
        
        return $stats !== null && $stats !== false;
    }

    // --- Trust & Scoring Operations ---

    public function getUserTrust(int $userId, bool $forUpdate = false): ?\stdClass
    {
        $sql = "SELECT trust_score FROM social_user_trust WHERE user_id = ? LIMIT 1";
        if ($forUpdate) {
            if (!$this->db->inTransaction()) {
                throw new \RuntimeException('Database transaction required for pessimistic locking in getUserTrust');
            }
            $sql .= " FOR UPDATE";
        }
        return $this->db->fetch($sql, [$userId]);
    }

    public function upsertUserTrust(int $userId, float $score): bool
    {
        return (bool)$this->db->query(
            "INSERT INTO social_user_trust (user_id, trust_score, updated_at, created_at)
             VALUES (?, ?, NOW(), NOW())
             ON DUPLICATE KEY UPDATE trust_score = ?, updated_at = NOW()",
            [$userId, $score, $score]
        );
    }

    /** @param array<string, mixed> $data */
    public function recordTrustAdjustment(array $data): bool
    {
        // FIX راند ۷۷ (ستون شبح): جدول social_trust_adjustments فقط (user_id, delta, reason, created_at) دارد؛
        // ستون‌های admin_id/old_trust/new_trust هرگز وجود نداشتند (42S22).
        return (bool)$this->db->insert(
            "INSERT INTO social_trust_adjustments
             (user_id, delta, reason, created_at)
             VALUES (?, ?, ?, NOW())",
            [
                $data['user_id'],
                $data['delta'],
                $data['reason']
            ]
        );
    }

    /** @param array<string, mixed> $data */
    public function saveTrustSnapshot(array $data): bool
    {
        // FIX راند ۷۷ (ستون شبح): جدول social_trust_snapshots فقط (user_id, score, created_at) دارد؛
        // ستون‌های trust_score/week_*/snapshot_date هرگز وجود نداشتند و ON DUPLICATE هم بدون
        // UNIQUE KEY عملاً never-fire بود. حالا INSERT سادهٔ idempotent-safe.
        return (bool)$this->db->query(
            "INSERT INTO social_trust_snapshots
               (user_id, score, created_at)
             VALUES (?, ?, NOW())",
            [
                $data['user_id'],
                $data['trust_score'] ?? ($data['score'] ?? 0),
            ]
        );
    }

    // --- Statistics Operations ---

    public function getExecutorStats(int $userId): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT
                COUNT(*) AS total,
                SUM(status = 'approved') AS approved,
                0 AS soft_approved,
                SUM(status = 'rejected') AS rejected,
                100.0 AS avg_score,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*),0) AS success_rate
             FROM social_task_executions
             WHERE executor_id = ?",
            [$userId]
        );
    }

    public function getAdvertiserAdStats(int $adId, int $advertiserId): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT
                sa.*,
                COUNT(ste.id) AS total_executions,
                SUM(ste.status = 'approved') AS approved,
                0 AS soft_approved,
                SUM(ste.status = 'rejected') AS rejected,
                100.0 AS avg_score,
                60.0 AS avg_time
             FROM ads sa
             LEFT JOIN social_task_executions ste ON ste.ad_id = sa.id
             WHERE sa.id = ? AND sa.user_id = ?
             GROUP BY sa.id
             LIMIT 1",
            [$adId, $advertiserId]
        );
    }

    public function getWeeklyExecutionStats(int $userId): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS good_tasks,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected,
                0 AS soft_approved,
                100.0 AS avg_score
             FROM social_task_executions
             WHERE executor_id = ?
               AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)",
            [$userId]
        );
    }

    /** @return list<\stdClass> */
    public function getRecentActiveExecutors(int $days = 7): array
    {
        return $this->db->fetchAll(
            "SELECT DISTINCT executor_id AS user_id
             FROM social_task_executions
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)",
            [$days]
        );
    }

    /** @return list<\stdClass> */
    public function getExecutorHistory(int $userId, int $limit, int $offset): array
    {
        return $this->db->fetchAll(
            "SELECT ste.*, sa.title, sa.platform, sa.task_type, sa.price_per_task
             FROM social_task_executions ste
             JOIN ads sa ON sa.id = ste.ad_id
             WHERE ste.executor_id = ?
             ORDER BY ste.created_at DESC
             LIMIT ? OFFSET ?",
            [$userId, $limit, $offset]
        );
    }

    public function getMedianReward(): float
    {
        $count = (int)$this->db->fetchColumn("SELECT COUNT(*) FROM ads WHERE status = 'active'");
        if ($count === 0) return 0.0;
        $offset = (int)floor($count / 2);
        $row = $this->db->fetch("SELECT price_per_task FROM ads WHERE status = 'active' ORDER BY price_per_task LIMIT 1 OFFSET {$offset}");
        return (float)($row->price_per_task ?? 0);
    }

    public function updateUserStats(int $userId, float $rating, int $count, string $type): bool
    {
        // FIX راند ۷۷ (ستون شبح): جدول user_stats فقط (total_earned, total_tasks) دارد و ستون‌های
        // rating/count/type هرگز وجود نداشتند (42S22). کل زنجیرهٔ SocialTaskModel::updateUserStats
        // در کد بی‌فراخوان است و aggregate امتیاز on-the-fly از social_ratings می‌آید؛ پس بدون
        // نوشتن DB با قرارداد bool سازگار برمی‌گردیم.
        return true;
    }
}
