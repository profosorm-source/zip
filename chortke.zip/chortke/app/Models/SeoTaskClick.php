<?php

namespace App\Models;

use Core\Model;

/**
 * SeoTaskClick — ثبت سرورمحور کلیک‌های «باز کردن سایت هدف» تسک سئو
 *
 * 🛡️ FIX-SEOCLICK-P1 (فاز ۱ کانال سنجش سرورمحور — ریشه‌ایِ SEO-23-01):
 * تا پیش از این، دکمهٔ باز کردن سایت، لینک مستقیم بود و سرور هیچ اثری از
 * عبور کاربر نداشت. اکنون مسیر از روت سرور (GET /seo/{id}/out) می‌گذرد و
 * هر عبور این‌جا ثبت می‌شود؛ ProcessSeoTaskAsyncJob برای اجراهای دارای
 * کلیک، سقف پاداش غیرقابل‌اثبات را برمی‌دارد.
 *
 * جدول: seo_task_clicks (مایگریشن 2026_11_01_0001)
 */
class SeoTaskClick extends Model
{
    /** سقف ردیف‌های ثبت‌شده به‌ازای هر اجرا — جلوی سیل‌بارگیری ربات را می‌گیرد؛
     *  برای «آیا کلیک شده؟» یک ردیف هم کافی است. */
    public const MAX_CLICKS_PER_EXECUTION = 5;

    protected static string $table = 'seo_task_clicks';

    /**
     * ثبت یک کلیک (best-effort با سقف)
     *
     * @return bool آیا ردیف جدیدی ثبت شد (false = سقف پر شده یا خطا)
     */
    public function record(int $executionId, int $userId, int $adId, ?string $ip = null, ?string $userAgent = null): bool
    {
        try {
            if ($this->countByExecution($executionId) >= self::MAX_CLICKS_PER_EXECUTION) {
                return false;
            }
            $stmt = $this->db->prepare(
                'INSERT INTO seo_task_clicks (execution_id, user_id, ad_id, ip_address, user_agent, clicked_at)
                 VALUES (?, ?, ?, ?, ?, NOW())'
            );
            $stmt->execute([
                $executionId,
                $userId,
                $adId,
                $ip !== null ? mb_substr($ip, 0, 45) : null,
                $userAgent !== null ? mb_substr($userAgent, 0, 255) : null,
            ]);
            return $stmt->rowCount() > 0;
        } catch (\Throwable $e) {
            // ثبت کلیک هرگز نباید مسیر باز کردن سایت را بشکند — گیت پاداش در
            // نبودِ رکورد، محافظه‌کارانه (سقف‌خورده) عمل می‌کند.
            return false;
        }
    }

    /** شمارش کلیک‌های یک اجرا */
    public function countByExecution(int $executionId): int
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM seo_task_clicks WHERE execution_id = ?');
        $stmt->execute([$executionId]);
        return (int)$stmt->fetchColumn();
    }

    /**
     * آیا کاربرِ مالکِ اجرا، کلیکِ سرور-ثبت‌شده دارد؟
     *
     * شرط user_id عمدی است: کلیکِ ثبت‌شدهٔ کاربرِ دیگری (اگر روزی باگ/دستکاری
     * رخ دهد) نباید پاداش این اجرا را از سقف خارج کند.
     */
    public function hasClickForUser(int $executionId, int $userId): bool
    {
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) FROM seo_task_clicks WHERE execution_id = ? AND user_id = ?'
        );
        $stmt->execute([$executionId, $userId]);
        return (int)$stmt->fetchColumn() > 0;
    }
}
