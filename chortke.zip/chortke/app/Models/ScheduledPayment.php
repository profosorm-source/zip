<?php

namespace App\Models;

use Core\Model;

class ScheduledPayment extends Model
{
    protected static string $table = 'scheduled_payments';

    /**
     * FIX-18O (P2): whitelist ستون‌های واقعی scheduled_payments (شمای زنده:
     * 2026_06_10_0008_extended_financial.sql + ALTER 2026_06_12_0001 که
     * description/metadata/idempotency_key و frequency varchar را اضافه کرد).
     * ستون id عمداً نیست.
     */
    protected array $fillable = [
        'user_id', 'amount', 'currency', 'frequency',
        'next_run_at', 'status', 'description', 'metadata',
        'idempotency_key', 'last_run_at', 'processed_count',
        'created_at', 'updated_at',
    ];

    /** @param array<string, mixed> $data */
    public function createSchedule(array $data): ?\stdClass
    {
        $data['user_id'] = int_value($data['user_id'] ?? 0);
        $data['amount'] = str_value($data['amount'] ?? '0');
        $data['currency'] = strtolower(str_value($data['currency'] ?? 'irt'));
        $data['frequency'] = $data['frequency'] ?? 'one_time';
        if ($data['frequency'] === 'once') {
            $data['frequency'] = 'one_time';
        }
        $data['next_run_at'] = $data['next_run_at'] ?? date('Y-m-d H:i:s');
        $data['status'] = $data['status'] ?? 'active';
        $data['description'] = $data['description'] ?? null;
        $data['metadata'] = isset($data['metadata']) && is_array($data['metadata']) ? json_encode($data['metadata'], JSON_UNESCAPED_UNICODE) : ($data['metadata'] ?? null);
        $data['created_at'] = $data['created_at'] ?? date('Y-m-d H:i:s');
        $data['updated_at'] = $data['updated_at'] ?? date('Y-m-d H:i:s');
        if (!empty($data['idempotency_key'])) {
            $data['idempotency_key'] = substr(str_value($data['idempotency_key']), 0, 128);
        } else {
            unset($data['idempotency_key']);
        }

        $id = parent::create($data);
        return is_int($id) ? $this->find($id) : null;
    }

    /** @return list<\stdClass> */
    public function getDuePayments(int $limit = 50): array
    {
        $limit = max(1, (int)$limit);
        // R34 FIX (paused dead-end): ردیف‌های paused (پازِ موقتِ فریز کیف) هم «سررسیده»اند —
        // قبلاً فقط active انتخاب می‌شد و پرداختِ paused پس از یک فریز موقت برای همیشه
        // می‌مرد (هیچ مسیر resume ای در کل کدبیس وجود نداشت). تصمیم وضعیت با سرویس است:
        // کیف هنوز فروزن → skip؛ کیف سالم → CAS resume و ادامهٔ مسیر عادی پرداخت.
        $sql = "SELECT * FROM `" . static::$table . "` 
                WHERE status IN ('active', 'paused') AND next_run_at <= NOW() 
                ORDER BY next_run_at ASC 
                LIMIT :limit FOR UPDATE SKIP LOCKED";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
    }

    /**
     * دریافت لیست پرداخت‌های معوق با گارانتی تراکنش و قفل ایمن ردیف
     */
    /** @return list<\stdClass> */
    public function getDuePaymentsWithTransaction(int $limit = 50): array
    {
        try {
            $this->db->beginTransaction();
            $payments = $this->getDuePayments($limit);
            if (empty($payments)) {
                $this->db->rollback();
                return [];
            }
            return $payments;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            return [];
        }
    }

    public function updateNextRun(int $id, string $nextRunAt, string $status = 'active'): bool
    {
        // FIX-R36-W3 (F-A1-13): شمارش اتمیک — قبلاً processed_count با «SELECT + 1 در PHP»
        // محاسبه و سپس نوشته می‌شد (ریس read-modify-write): دو ورکر هم‌زمان می‌توانستند
        // یک increment را گم کنند. اکنون افزایش در خود UPDATE انجام می‌شود
        // (processed_count = processed_count + 1) — اتمیک روی سطر قفل‌شده.
        // سمانتیک بازگشت با Model::update یکسان است (rowCount > 0؛ شمارنده همیشه
        // تغییر می‌کند پس سطرِ موجود همیشه «affected» حساب می‌شود).
        $sql = "UPDATE `" . static::$table . "`
                SET next_run_at = :next_run_at,
                    status = :status,
                    last_run_at = NOW(),
                    processed_count = processed_count + 1,
                    updated_at = NOW()
                WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'next_run_at' => $nextRunAt,
            'status'      => $status,
            'id'          => $id,
        ]);
        return $stmt->rowCount() > 0;
    }

    /**
     * FIX-R36-W3 (F-A1-06): claim اتمیک «اسلات سررسید» — حلقهٔ دفاع-در-عمقِ ازدست‌رفته.
     *
     * SKIP LOCKED در getDuePayments بیرون از تراکنشِ نگه‌دارنده اجرا می‌شود (autocommit)
     * ⇒ قفل‌ها در پایان همان statement آزاد می‌شوند و گارد ضد-ورکر-موازی عملاً بی‌اثر است.
     * پیچیدن کل حلقهٔ پردازش در یک tx هم ممنوع است (P2-1: زنجیرهٔ قفل بین‌کاربری/DoS کرون).
     *
     * جایگزین کم‌ریسک: نخستین statement داخل تراکنشِ اتمیکِ هر پرداخت، اسلاتِ سررسیدِ
     * دیده‌شده (id + next_run_at عیناً از snapshot انتخاب) را با «SELECT ... FOR UPDATE»
     * claim می‌کند: (۱) قفل سطر تا commit/rollback همان tx نگه داشته می‌شود — ورکر
     * موازی روی همین سطر منتظر می‌ماند و بعد از commit ما، خوانِ قفل‌دارِ او آخرین
     * نسخهٔ کامیت‌شده را می‌بیند (next_run_at جلو رفته یا status تغییر کرده) ⇒ claim
     * از دست می‌رود و بدون کسر/بدون شمارش رد می‌شود (هم‌الگوی resume_race_lost)؛
     * (۲) بدون side-effect است — برخلاف UPDATEِ شرطی روی updated_at، در ثانیهٔ تکراری
     * rowCount=0 گمراه‌کننده نمی‌سازد. با rollback شدنِ پرداخت، قفلِ claim هم آزاد
     * می‌شود (خود-درمان)؛ ضد-دوبار-کسرِ اصلی همان کلید idempotency قطعی است.
     *
     * باید داخل تراکنشِ فعالِ فراخواننده اجرا شود.
     */
    public function claimDueSlot(int $id, string $expectedNextRunAt): bool
    {
        $sql = "SELECT id FROM `" . static::$table . "`
                WHERE id = :id
                  AND next_run_at = :expected_next_run_at
                  AND status IN ('active', 'paused')
                LIMIT 1
                FOR UPDATE";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'id'                   => $id,
            'expected_next_run_at' => $expectedNextRunAt,
        ]);
        $row = $stmt->fetch(\PDO::FETCH_COLUMN);
        return $row !== false && $row !== null;
    }

    public function updateStatus(int $id, string $status): bool
    {
        return $this->update($id, ['status' => $status]);
    }

    /**
     * R34 FIX (paused dead-end — self-heal): بیدارسازیِ CAS پرداختِ paused
     * (پازِ موقتِ فریز کیف). فقط اگر واقعاً هنوز paused بمانده باشد به active
     * می‌رود؛ اگر همزمان لغو/completed/failed شده باشد، CAS از دست می‌رود
     * (rowCount=0) و تماس‌گیرنده باید «بدون کسر» رد شود (ضد دو-بار-کسر).
     */
    public function resumePaused(int $id): bool
    {
        $sql = "UPDATE `" . static::$table . "` SET status = 'active', updated_at = NOW() 
                WHERE id = :id AND status = 'paused'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }
}
