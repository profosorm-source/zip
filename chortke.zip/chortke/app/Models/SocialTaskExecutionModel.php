<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * SocialTaskExecutionModel - Manage Social Task Executions and Camera Verification Requests
 */
class SocialTaskExecutionModel extends Model
{
    protected static string $table = 'social_task_executions';

    public function getExecutionById(int $id, bool $forUpdate = false): ?\stdClass
    {
        $sql = "SELECT * FROM social_task_executions WHERE id = ?";
        if ($forUpdate) {
            if (!$this->db->inTransaction()) {
                throw new \RuntimeException('FOR UPDATE must be called inside an active transaction');
            }
            $sql .= " FOR UPDATE";
        }
        return $this->db->fetch($sql, [$id]);
    }

    public function getExecutionWithAd(int $executionId, int $userId, bool $forUpdate = false): ?\stdClass
    {
        // FIX-CYB (بچ تومان): currency آگهی هم خوانده می‌شود تا ویوی اجرا، پاداش را
        // با ارز خودِ آگهی نمایش دهد (ستون فقط-خواندنی؛ مسیر پرداخت دست‌نخورده).
        $sql = "SELECT e.*, a.price_per_task, a.task_type, a.id AS ad_id, a.user_id, a.title AS ad_title, a.currency AS ad_currency
                FROM social_task_executions e
                INNER JOIN ads a ON a.id = e.ad_id
                WHERE e.id = ? AND e.executor_id = ?";
        if ($forUpdate) {
            if (!$this->db->inTransaction()) {
                throw new \RuntimeException('FOR UPDATE must be called inside an active transaction');
            }
            $sql .= " FOR UPDATE";
        }
        return $this->db->fetch($sql, [$executionId, $userId]);
    }

    public function getExecutionWithAdForAdvertiser(int $executionId, int $advertiserId, bool $forUpdate = false): ?\stdClass
    {
        $sql = "SELECT e.*, a.price_per_task, a.task_type, a.id AS ad_id, a.user_id, a.title AS ad_title
                FROM social_task_executions e
                INNER JOIN ads a ON a.id = e.ad_id
                WHERE e.id = ? AND a.user_id = ?";
        if ($forUpdate) {
            if (!$this->db->inTransaction()) {
                throw new \RuntimeException('FOR UPDATE must be called inside an active transaction');
            }
            $sql .= " FOR UPDATE";
        }
        return $this->db->fetch($sql, [$executionId, $advertiserId]);
    }

    /** @return list<\stdClass> */
    public function getExecutionsByAd(int $adId, int $limit = 20, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT ste.*, u.full_name AS executor_name
             FROM social_task_executions ste
             JOIN users u ON u.id = ste.executor_id
             WHERE ste.ad_id = ?
             ORDER BY ste.created_at DESC
             LIMIT ? OFFSET ?",
            [$adId, $limit, $offset]
        );
    }

    /** @param array<string, mixed> $data */
    public function createExecution(array $data): int
    {
        return (int)$this->db->insert(
            "INSERT INTO social_task_executions
             (ad_id, executor_id, status, ip_address, user_agent, started_at, expected_time, created_at)
             VALUES (?, ?, 'pending', ?, ?, NOW(), ?, NOW())",
            [
                $data['ad_id'],
                $data['executor_id'],
                $data['ip_address'],
                $data['user_agent'],
                $data['expected_time']
            ]
        );
    }

    private const STATE_TRANSITIONS = [
        'pending' => ['started', 'in_progress', 'cancelled'],
        'started' => ['in_progress', 'submitted', 'expired', 'cancelled'],
        'in_progress' => ['submitted', 'expired', 'cancelled'],
        'submitted' => ['approved', 'soft_approved', 'rejected'],
        'approved' => [], // terminal
        'rejected' => [], // terminal
        'cancelled' => [], // terminal
        'expired' => [], // terminal
    ];

    // FIX-F21-05 (بازبینی بخش ۲۱): «status» از allow-list حذف شد — ستون وضعیت
    // فقط از آرگومان transition-validatedِ updateExecutionStatus نوشته می‌شود.
    // ریشه: این کلید قبلاً در allow-list بود و چون status = ? (مقدار کنترل‌شده)
    // اولین SET بود، کلیدِ status در $data همان ستون را در ادامهٔ SET بازنویسی
    // می‌کرد — یعنی هر فراخوانی که data['status'] می‌فرستاد می‌توانست نتیجهٔ
    // ماشین حالت را بی‌سروصدا دور بزند (گذارِ غیرمجاز از این مسیر). در
    // callsiteهای فعلی چنین caller ای وجود ندارد (بررسی کامل jobs/controls)
    // پس latent بود؛ حالا fail-loud است: کلید status در data همان خطای
    // «Invalid or restricted update column» را می‌گیرد که بقیهٔ ستون‌های
    // ممنوعه می‌گیرند. تغییر وضعیت = فقط از API اختصاصی transition.
    private const ALLOWED_UPDATE_FIELDS = [
        'task_score', 'active_time', 'decision', 'rejection_reason',
        'behavior_data', 'flag_review', 'flag_note', 'proof_url', 'proof_text',
        'anti_fraud_score', 'reward_paid', 'reward_amount', 'override_reason',
        'overridden_by', 'overridden_at',
        'reviewed_by', 'reviewed_at', 'reject_reason', 'submitted_at', 'completed_at',
        'client_mode', 'client_version', 'device_context', 'behavior_score', 'time_score',
        'interaction_score', 'camera_score', 'final_score', 'score_breakdown',
        'verification_required', 'verification_method', 'verification_requested_at',
        'verification_completed_at'
    ];

    /** @param array<string, mixed> $data */
    public function updateExecutionStatus(int $id, string $status, array $data = []): bool
    {
        // گرفتن وضعیت فعلی
        $current = $this->db->fetch("SELECT status FROM social_task_executions WHERE id = ? LIMIT 1", [$id]);
        
        if (!$current) {
            throw new \RuntimeException('Execution not found');
        }
        
        $currentStatus = $current->status;
        
        // بررسی معتبر بودن transition (تغییر وضعیت به خودش همیشه مجاز است)
        if ($currentStatus !== $status) {
            $allowed = self::STATE_TRANSITIONS[$currentStatus] ?? [];
            if (!in_array($status, $allowed, true)) {
                throw new \InvalidArgumentException(
                    "Invalid state transition: {$currentStatus} → {$status}"
                );
            }
        }

        $updates = ["status = ?", "updated_at = NOW()"];
        $params = [$status];

        foreach ((array)$data as $key => $value) {
            if (!\in_array($key, self::ALLOWED_UPDATE_FIELDS, true)) {
                throw new \InvalidArgumentException("Invalid or restricted update column: " . $key);
            }
            $updates[] = "{$key} = ?";
            $params[] = $value;
        }

        $params[] = $id;
        return (bool)$this->db->query(
            "UPDATE social_task_executions SET " . implode(', ', $updates) . " WHERE id = ?",
            $params
        );
    }

    public function updateExecutionBehavior(int $id, string $behaviorData): bool
    {
        return (bool)$this->db->query(
            "UPDATE social_task_executions SET behavior_data = ?, updated_at = NOW() WHERE id = ?",
            [$behaviorData, $id]
        );
    }

    /**
     * FIX-BOOKKEEPING-REWARD: بوک‌کیپینگ پرداخت پاداش روی ردیف اجرا.
     * پیش از این، پاداش فقط به کیف پول/ledger واریز می‌شد و ستون‌های
     * reward_amount/reward_currency/reward_paid در ردیف social_task_executions
     * همیشه NULL/0 می‌ماندند (نمایش «پرداخت‌نشده» علی‌رغم واریز واقعی).
     * این متد وضعیت پرداخت را بدون عبور از ماشین حالت (state machine) ثبت می‌کند.
     */
    public function markRewardPaid(int $id, string $amount, string $currency = 'irt'): bool
    {
        return (bool)$this->db->query(
            "UPDATE social_task_executions
             SET reward_amount = ?, reward_currency = ?, reward_paid = 1, updated_at = NOW()
             WHERE id = ?",
            [$amount, strtolower($currency) === 'irt' ? 'IRT' : strtoupper($currency), $id]
        );
    }

    public function updateExecutionBehaviorJson(int $id, int $cameraScore, string $verifiedSignals, string $verdict = 'pass'): bool
    {
        return (bool)$this->db->query(
            "UPDATE social_task_executions
             SET behavior_data = JSON_SET(
                   COALESCE(behavior_data, '{}'),
                   '$.camera_score', ?,
                   '$.camera_signals', ?,
                   '$.camera_verified', ?,
                   '$.camera_verdict', ?
                 ),
                 camera_score = ?,
                 verification_completed_at = NOW(),
                 updated_at = NOW()
             WHERE id = ?",
            [$cameraScore, $verifiedSignals, ($verdict === 'pass' ? 1 : 0), $verdict, $cameraScore, $id]
        );
    }

    public function getBehaviorData(int $id): ?string
    {
        $row = $this->db->fetch("SELECT behavior_data FROM social_task_executions WHERE id = ?", [$id]);
        return $row->behavior_data ?? null;
    }

    public function flagExecution(int $id, string $note): bool
    {
        return (bool)$this->db->query(
            "UPDATE social_task_executions SET flag_review = 1, flag_note = ?, updated_at = NOW() WHERE id = ?",
            [$note, $id]
        );
    }

    public function getRecentExecutionsByIp(string $ip, int $excludeUserId, int $hours = 24): int
    {
        $row = $this->db->fetch(
            "SELECT COUNT(DISTINCT executor_id) AS cnt
             FROM social_task_executions
             WHERE ip_address = ?
               AND executor_id != ?
               AND created_at >= DATE_SUB(NOW(), INTERVAL ? HOUR)",
            [$ip, $excludeUserId, $hours]
        );
        return (int)($row->cnt ?? 0);
    }

    public function getSharedFingerprintUsers(string $fingerprint, int $excludeUserId): int
    {
        $row = $this->db->fetch(
            "SELECT COUNT(DISTINCT user_id) AS cnt
             FROM user_fingerprints
             WHERE fingerprint = ?
               AND user_id != ?",
            [$fingerprint, $excludeUserId]
        );
        return (int)($row->cnt ?? 0);
    }

    public function getRapidTaskStats(int $userId, int $minutes = 10): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT COUNT(*) AS cnt,
                    AVG(active_time) AS avg_time,
                    STDDEV(active_time) AS stddev_time
             FROM social_task_executions
             WHERE executor_id = ?
               AND created_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)",
            [$userId, $minutes]
        );
    }

    // --- Camera Request Operations ---

    /**
     * 🛡️ FIX-S16-4 (بچ S16): وضعیت‌ها دیگر درون‌یابی خام نمی‌شوند.
     * پیش از این $statusList با implode('...','...') مستقیم داخل IN() می‌نشست —
     * فراخوان فعلی ثابت است (['completed','pending']) اما این الگو با ورودیِ
     * غیرثابت تبدیل به بردار SQLi می‌شد. اکنون placeholder داینامیک با بایند.
     *
     * @param list<string> $statusList
     */
    public function getCameraRequest(int $executionId, array $statusList): ?\stdClass
    {
        $statusList = array_values(array_filter(array_map(
            static fn ($s): string => \is_string($s) ? \trim($s) : '',
            $statusList
        ), static fn (string $s): bool => $s !== ''));
        if ($statusList === []) {
            return null;
        }
        $placeholders = implode(',', array_fill(0, count($statusList), '?'));
        // 🛡️ FIX-R36-W2-E2 (F-A10-02): camera_score/frame_count هم select می‌شوند —
        // CameraVerificationService::effectiveCameraContribution برای گاردِ
        // «متادیتای capture ناموجود/غیرواقع‌گرانه = صفر» به آن‌ها نیاز دارد.
        // فراخوان‌های موجود (isRequired/existence-check) سازگارند.
        // 🛡️ FIX-F21-01: آخرین رکورد تعیین‌کننده است (retry = capture جدید) —
        // ORDER BY id DESC برای معناشناسی قطعی «آخرین capture برنده است».
        return $this->db->fetch(
            "SELECT id, status, camera_score, frame_count, server_verdict, server_score,
                    nonce_consumed_at, spot_check_status FROM social_camera_requests
             WHERE execution_id = ? AND status IN ({$placeholders})
             ORDER BY id DESC
             LIMIT 1",
            array_merge([$executionId], $statusList)
        );
    }

    /**
     * 🛡️ FIX-F21-01 (گزینهٔ C) + FIX-F21-01-R2 (تصمیم D2 مالک): nonce
     * یک‌بارمصرف فقط به‌صورت هش SHA-256 ذخیره می‌شود — مقدار خام هرگز به DB
     * نمی‌رود و فقط یک‌بار در پاسخ همان چالش به کلاینت تحویل می‌شود. retry =
     * فراخوانی چالش جدید = رکورد جدید با nonce تازه (سقف نرخ سمت endpoint).
     * service مقدار خام را می‌سازد و هش را در 'nonce_hash' می‌فرستد.
     *
     * @param array<string, mixed> $data
     */
    public function createCameraRequest(array $data): int
    {
        // 🛡️ FIX-F21-01-R3: نبودِ هش = NULL (نه رشتهٔ خالی). ایندکس یکتای
        // uq_scr_nonce_hash روی '' برای دومین رکوردِ بدون-هش duplicate-key می‌داد
        // و مسیر camera_required را می‌شکست؛ در MariaDB چند NULL مجازند.
        $nonceHash = str_value($data['nonce_hash'] ?? '');
        $nonceHash = $nonceHash !== '' ? $nonceHash : null;

        return (int)$this->db->insert(
            "INSERT INTO social_camera_requests
               (execution_id, user_id, status, method, expires_at, client_context, raw_image_stored,
                nonce_hash, nonce_issued_at, spot_required, spot_consent, spot_indices, created_at)
             VALUES (?, ?, 'pending', ?, DATE_ADD(NOW(), INTERVAL ? SECOND), ?, 0,
                     ?, IF(? IS NULL, NULL, NOW()), ?, ?, ?, NOW())",
            [
                $data['execution_id'],
                $data['user_id'],
                $data['method'] ?? 'mobile_camera',
                $data['expiry'],
                !empty($data['client_context']) ? json_encode($data['client_context'], JSON_UNESCAPED_UNICODE) : null,
                $nonceHash,
                $nonceHash,
                !empty($data['spot_required']) ? 1 : 0,
                !empty($data['spot_consent']) ? 1 : 0,
                str_value($data['spot_indices'] ?? '') !== '' ? str_value($data['spot_indices']) : null,
            ]
        );
    }

    /**
     * 🛡️ FIX-F21-01-R3: صدور nonce روی رکورد pending موجود که هنوز هش ندارد
     * (ساخته‌شده توسط مسیر camera_required). فقط وقتی اجرا می‌شود که رکورد
     * pending، منقضی‌نشده و بدون هش باشد؛ rowCount=0 یعنی «صادر نشد».
     */
    public function issueCameraNonce(int $requestId, string $nonceHash, bool $spotRequired = false, bool $spotConsent = false, ?string $spotIndices = null): bool
    {
        $stmt = $this->db->query(
            "UPDATE social_camera_requests
             SET nonce_hash = ?,
                 nonce_issued_at = NOW(),
                 spot_required = ?,
                 spot_consent = ?,
                 spot_indices = ?
             WHERE id = ? AND status = 'pending' AND expires_at > NOW()
               AND nonce_hash IS NULL AND nonce_consumed_at IS NULL",
            [$nonceHash, $spotRequired ? 1 : 0, $spotConsent ? 1 : 0, $spotIndices, $requestId]
        );
        return (bool)$stmt->rowCount();
    }

    /**
     * 🛡️ FIX-F21-01-R2 (تصمیم D2): واکشی رکورد چالش با هش nonce — برای
     * خواندن الزامات spot (رضایت/ایندکس‌ها) پیش از مصرف اتمیک.
     */
    public function getCameraRequestByNonceHash(string $nonceHash): ?\stdClass
    {
        if ($nonceHash === '') {
            return null;
        }
        return $this->db->fetch(
            "SELECT * FROM social_camera_requests WHERE nonce_hash = ? LIMIT 1",
            [$nonceHash]
        );
    }

    /**
     * 🛡️ FIX-F21-01-R2 (تصمیم D2): با هر چالش جدید، رکوردهای pendingِ قبلیِ
     * همین user/execution منقضی می‌شوند (retry = رکورد جدید؛ فقط آخرین
     * رکوردِ زنده معتبر است). رکوردهای completed دست‌نخورده می‌مانند.
     */
    public function expirePendingCameraRequestsForUser(int $executionId, int $userId, int $exceptId): int
    {
        $stmt = $this->db->query(
            "UPDATE social_camera_requests
             SET status = 'expired'
             WHERE execution_id = ? AND user_id = ? AND status = 'pending' AND id <> ?",
            [$executionId, $userId, $exceptId]
        );
        return (int)$stmt->rowCount();
    }

    /**
     * 🛡️ FIX-F21-01 (هستهٔ یک‌بارمصرف بودن) + FIX-F21-01-R2 (تصمیم D2):
     * مصرف اتمیک nonce همراه نوشتن نتیجهٔ تحلیل سمت‌سرور. مقایسه بر روی هش
     * SHA-256 انجام می‌شود (مقدار خام هرگز در DB/کوئری نیست). UPDATE فقط وقتی
     * اجرا می‌شود که:
     *   - هش nonce عیناً همین باشد (توکن ناشناسِ دیگر-execution/کاربر رد می‌شود)
     *   - رکورد هنوز 'pending' باشد (replay روی رکوردِ مصرف‌شده rowCount=0)
     *   - منقضی نشده باشد (nonce مرده ارزش ندارد)
     *   - nonce قبلاً مصرف نشده باشد (nonce_consumed_at IS NULL — دفاع دوم
     *     در سطح DB حتی اگر status در مسیر دیگری دستکاری شده باشد)
     * rowCount=0 یعنی «مصرف نشد» → fail-closed در فراخوان.
     * camera_score از این پس «امتیاز سرور» است، نه عدد ادعایی کلاینت.
     */
    public function consumeCameraNonce(
        string $nonceHash,
        int    $userId,
        int    $executionId,
        int    $serverScore,
        string $findingsJson,
        int    $frameCount,
        ?string $framesJson,
        ?string $clientContextJson,
        string $verdict,
        ?string $analysisJson,
        ?string $attestationStatus,
        ?string $spotStatus = null
    ): bool {
        $stmt = $this->db->query(
            "UPDATE social_camera_requests
             SET status = 'completed',
                 camera_score = ?,
                 verification_score = ?,
                 server_score = ?,
                 server_verdict = ?,
                 server_analysis = ?,
                 verified_signals = ?,
                 frame_count = ?,
                 frame_signals = ?,
                 client_context = COALESCE(?, client_context),
                 attestation_status = ?,
                 spot_check_status = ?,
                 spot_check_at = IF(? IS NULL, NULL, NOW()),
                 nonce_consumed_at = NOW(),
                 raw_image_stored = 0,
                 completed_at = NOW()
             WHERE nonce_hash = ? AND user_id = ? AND execution_id = ?
               AND status = 'pending' AND expires_at > NOW()
               AND nonce_consumed_at IS NULL",
            [$serverScore, $serverScore, $serverScore, $verdict, $analysisJson, $findingsJson,
             $frameCount, $framesJson, $clientContextJson, $attestationStatus, $spotStatus, $spotStatus,
             $nonceHash, $userId, $executionId]
        );
        return (bool)$stmt->rowCount();
    }

    /**
     * 🛡️ FIX-F21-01-R4: تعداد حکم‌های pass سروری یک کاربر در N ساعت اخیر
     * (پایش «تعداد pass به ازای هر کاربر» برای ارجاع به بازبینی ادمین).
     */
    public function countTrustedPassesSince(int $userId, int $hours = 24): int
    {
        return int_value($this->db->fetchColumn(
            "SELECT COUNT(*) FROM social_camera_requests
             WHERE user_id = ? AND status = 'completed' AND server_verdict = 'pass'
               AND nonce_consumed_at IS NOT NULL
               AND completed_at > DATE_SUB(NOW(), INTERVAL ? HOUR)",
            [$userId, max(1, $hours)]
        ));
    }

    public function getPendingCameraRequest(int $executionId): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT * FROM social_camera_requests
             WHERE execution_id = ?
               AND status = 'pending'
               AND expires_at > NOW()
             LIMIT 1",
            [$executionId]
        );
    }

    public function getCameraRequestForUser(int $executionId, int $userId): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT * FROM social_camera_requests
             WHERE execution_id = ? AND user_id = ? AND status = 'pending' AND expires_at > NOW()
             ORDER BY id DESC
             LIMIT 1",
            [$executionId, $userId]
        );
    }

    /**
     * 🛡️ FIX-F21-01: واکشی رکورد با id (برای camera-challenge پس از ساخت
     * درخواست تازه در مسیر retry).
     */
    public function getCameraRequestById(int $id): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT * FROM social_camera_requests WHERE id = ? LIMIT 1",
            [$id]
        );
    }

    /**
     * 🛡️ FIX-10a-F2 (R10 audit P2): آپدیتِ نتیجهٔ دوربین دیگر «فقط با id» نیست.
     * UPDATE شرطی است: رکورد فقط از وضعیت 'pending' و تنها پیش از انقضا
     * (expires_at > NOW()) completed می‌شود. درخواستِ دیرهنگام یا رقابتی که بعد از
     * انقضا/تکمیل می‌رسد rowCount=0 می‌بیند و false برمی‌گرداند — نتیجهٔ دوربینِ
     * رکوردِ منقضی/تکمیل‌شده دیگر بازنویسی نمی‌شود. false یعنی «نوشته نشده»،
     * نه «کوئری شکست خورد»؛ فراخوان (CameraVerificationService::processResult)
     * موظف است false را به‌عنوان شکست گزارش کند.
     */
    public function updateCameraRequestResult(int $id, int $score, string $signals, int $frameCount = 0, ?string $frameSignals = null, ?string $clientContext = null): bool
    {
        $stmt = $this->db->query(
            "UPDATE social_camera_requests
             SET status = 'completed',
                 camera_score = ?,
                 verification_score = ?,
                 verified_signals = ?,
                 frame_count = ?,
                 frame_signals = ?,
                 client_context = COALESCE(?, client_context),
                 raw_image_stored = 0,
                 completed_at = NOW()
             WHERE id = ? AND status = 'pending' AND expires_at > NOW()",
            [$score, $score, $signals, $frameCount, $frameSignals, $clientContext, $id]
        );
        return (bool)$stmt->rowCount();
    }

    public function expireCameraRequests(int $executionId): bool
    {
        return (bool)$this->db->query(
            "UPDATE social_camera_requests
             SET status = 'expired'
             WHERE execution_id = ? AND status = 'pending' AND expires_at < NOW()",
            [$executionId]
        );
    }

    public function getCameraStats(): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT
                COUNT(*) AS total,
                SUM(status = 'completed') AS completed,
                SUM(status = 'expired')   AS expired,
                SUM(status = 'pending')   AS pending,
                AVG(CASE WHEN status = 'completed' THEN camera_score END) AS avg_score,
                SUM(CASE WHEN status = 'completed' AND camera_score >= 60 THEN 1 ELSE 0 END) AS passed
             FROM social_camera_requests"
        );
    }
}
