<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;
use App\Traits\Filterable;

/**
 * User Model - Centralized data access for users table
 * @property int $id
 * @property string $email
 * @property string $mobile
 * @property string $full_name
 * @property string $role
 * @property string $status
 * @property string|null $kyc_status
 * @property string $password
 * @property string $referral_code
 * @property int|null $referred_by
 * @property string $created_at
 * @property string|null $updated_at
 * @property string|null $deleted_at
 * @property string|null $email_verified_at
 * @property string|null $email_verification_token
 * @property string|null $remember_token
 * @property string $level_slug
 * @property int $fraud_score
 * @property int $id
 * @property string $email
 * @property string|null $mobile
 * @property string|null $avatar
 * @property string|null $username
 * @property string|null $two_factor_secret
 * @property int $two_factor_enabled
 * @property string|null $two_factor_method
 * @property string|null $national_id
 * @property string|null $birth_date
 * @property string|null $gender
 * @property string|null $address
 * @property string|null $bio
 * @property float|string|null $current_balance
 * @property float|string|null $usdt_balance
 * @property float|string|null $wallet_usdt
 * @property float|string|null $balance_irt
 * @property float|string|null $referral_quality_score
 */
#[\AllowDynamicProperties]
class User extends Model
{
    protected static string $table = 'users';

    /**
     * FIX-RAW-SQL: قدیمی‌ترین created_at ثبت‌نام — مبنای «uptime روز» صفحهٔ
     * عمومی /status. مالکیت SQL با مدل است؛ خطای DB کنترل‌شده null برمی‌گردد.
     */
    public function findEarliestCreatedAt(): ?string
    {
        try {
            $row = $this->db->fetch("SELECT MIN(created_at) AS first FROM `" . static::$table . "`");
            $first = $row->first ?? null;
            return is_string($first) && $first !== '' ? $first : null;
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * 🛡️ Phase 3: Relations برای eager loading
     *
     * استفاده در Controller:
     *   $users = $this->userModel->allWith(['wallet', 'transactions'], 50);
     *   // به جای N+1 query، فقط ۳ query اجرا می‌شود
     *
     * در view/template:
     *   foreach ($users as $user) {
     *       echo $user->full_name;
     *       echo $user->wallet->balance ?? 0;        // loaded eagerly
     *       echo count($user->transactions);         // loaded eagerly
     *   }
     */
    protected array $relations = [
        'wallet'       => [\App\Models\Wallet::class,      'user_id', 'one'],
        'transactions' => [\App\Models\Transaction::class, 'user_id', 'many'],
    ];

    /**
     * FIX-18O (P0 mass-assignment): privileged columns REMOVED from $fillable.
     *
     * role / status / level_slug / is_admin / fraud_score / two_factor_* /
     * email_verified_at / email_verification_token are no longer writable
     * through create()/update() — a request-shaped array funnelled into
     * update() could previously self-promote to admin or inject a 2FA secret.
     *
     * Legitimate writers use explicit-column methods:
     *   - createWithCredentials()       → registration INSERT (password + role/status/…)
     *   - createWithSystemColumns()     → system-column INSERT (kept for API stability)
     *   - updateAdminManagedFields()    → admin user management (role/status/level_slug)
     *   - storeEmailVerificationToken() → verification flow
     *   - updateTwoFactorSettings()     → 2FA service
     *   - verifyEmail()                 → email verification timestamp
     *   - changePassword()/storeRememberToken()/lockIfExceededAttempts()  → security columns
     *
     * FIX-R20-C1: 'password' REMOVED from $fillable. It is request-shaped, but
     * only legitimate at birth (registration) — any post-creation write must go
     * through changePassword(), which atomically revokes the remember cookie.
     * A stray mass-assign path can no longer swap the password hash bypassing
     * old-password / rehash checks.
     */
    protected array $fillable = [
        'full_name', 'email', 'mobile', 'username',
        'bio', 'avatar', 'website', 'location', 'gender',
        'birth_date', 'national_id', 'address',
        'referral_code', 'referred_by',
        'country_code', 'country_name', 'country_flag', // FIX-R16A: country_flag اکنون ستون واقعی دارد (migration 2026_09_20_0004)
    ];

    /**
     * FIX-18O (P1): credential/secret columns stripped by toPublicArray().
     * Raw fetches (findByCredentials, find(), SELECT *) intentionally keep
     * every column — auth and token verification need them.
     */
    protected array $hidden = [
        'password', 'remember_token', 'two_factor_secret', 'email_verification_token',
    ];
    protected static array $searchable = ['full_name', 'email', 'mobile'];

    /**
     * FIX-R16B (ITEM 7): whitelist ستون‌های مجازِ مرتب‌سازیِ لیست ادمین.
     * ورودی خام کاربر هرگز interpolat نمی‌شود — فقط ستونِ همین فهرست به
     * QueryBuilder::orderBy می‌رسد (خود orderBy هم identifier را validate می‌کند).
     * «wallet_balance» عمداً نیست: ستون users نیست (نمایش ویو جعلی است).
     */
    public const ADMIN_SORTABLE_COLUMNS = ['id', 'full_name', 'email', 'mobile', 'role', 'status', 'created_at', 'last_login'];

    /**
     * FIX-R16B (ITEM 7): نرمال‌سازی ورودی GET (sort/dir) به جفتِ امن.
     * ورودی نامعتبر/غایب = ترتیب پیش‌فرضِ فعلی (created_at DESC).
     * @return array{0: string, 1: string} [column, direction]
     */
    public static function normalizeAdminSort(?string $sort, ?string $dir): array
    {
        $s = strtolower(trim((string)$sort));
        if (!in_array($s, self::ADMIN_SORTABLE_COLUMNS, true)) {
            return ['created_at', 'desc'];
        }
        return [$s, strtolower(trim((string)$dir)) === 'asc' ? 'asc' : 'desc'];
    }

    /** @var array<string, array{string, string}> */
    protected static array $filterable = [
        'status' => ['status', '='],
        'role' => ['role', '='],
    ];

    /**
     * شخصی‌سازی جستجو برای مدل کاربر (افزودن تطبیق دقیق برای کد معرف)
     */
    public function applySearch(\Core\QueryBuilder $query, ?string $term): \Core\QueryBuilder
    {
        $term = trim((string)$term);
        if (empty($term)) {
            return $query;
        }

        $escaped = $this->escapeLikeValue($term);
        $like = "%{$escaped}%";

        return $query->where(function(\Core\QueryBuilder $q) use ($like, $term) {
            // ۱. جستجوی مشابهت (LIKE) روی فیلدهای استاندارد
            foreach (static::$searchable as $index => $column) {
                if ($index === 0) {
                    $q->where((string)$column, 'LIKE', $like);
                } else {
                    $q->orWhere((string)$column, 'LIKE', $like);
                }
            }
            // ۲. جستجوی دقیق (EXACT) روی فیلدهای خاص دامنه
            $q->orWhere('referral_code', '=', $term);
        });
    }

    public function findByEmail(string $email): ?\stdClass
    {
        $row = $this->db->fetch("SELECT * FROM users WHERE email = ? LIMIT 1", [$email]);
        return $this->normalizeToObject($row);
    }

    public function findByMobile(string $mobile): ?\stdClass
    {
        $row = $this->db->fetch("SELECT * FROM users WHERE mobile = ? LIMIT 1", [$mobile]);
        return $this->normalizeToObject($row);
    }

    /**
     * FIX F-A13-02: کد معرفِ حسابِ حذف‌شده زنده می‌ماند (AccountDeletionService
     * users.referral_code را پاک نمی‌کند؛ email/username ناشناس می‌شوند و
     * self-referral check هم دیگر نمی‌گیرد) — بدون فیلتر، ثبت‌نام/اتصال به
     * معرفِ حذف‌شده ممکن بود و پاداش به کیف یتیم (بی‌صاحب) واریز می‌شد.
     * پیش‌فرض فقط حساب‌های زنده (deleted_at IS NULL AND status <> 'deleted')
     * برگردانده می‌شود؛ $includeDeleted=true برای مصرف‌کننده‌هایی است که به
     * فضای کامل کدها (از جمله حساب‌های حذف‌شده) نیاز دارند — مثلاً بررسی
     * یکتاییِ تولید کد (users.referral_code UNIQUE است و کدِ ردیفِ حذف‌شده
     * همچنان آن کلید را اشغال می‌کند).
     */
    public function findByReferralCode(string $code, bool $includeDeleted = false): ?\stdClass
    {
        $sql = "SELECT * FROM users WHERE referral_code = ?";
        if (!$includeDeleted) {
            $sql .= " AND deleted_at IS NULL AND status <> 'deleted'";
        }
        $sql .= " LIMIT 1";
        $row = $this->db->fetch($sql, [$code]);
        return $this->normalizeToObject($row);
    }

    public function findByCredentials(string $identifier): ?\stdClass
    {
        $row = $this->db->fetch(
            "SELECT * FROM users WHERE (email = ? OR username = ? OR mobile = ?) AND deleted_at IS NULL LIMIT 1",
            [$identifier, $identifier, $identifier]
        );
        return $this->normalizeToObject($row);
    }

    public function findByCredentialsForUpdate(string $identifier): ?\stdClass
    {
        $row = $this->db->fetch(
            "SELECT * FROM users WHERE (email = ? OR username = ? OR mobile = ?) AND deleted_at IS NULL LIMIT 1 FOR UPDATE",
            [$identifier, $identifier, $identifier]
        );
        return $this->normalizeToObject($row);
    }

    public function findById(int $userId): ?\stdClass
    {
        $row = $this->db->table('users')
            ->where('id', '=', $userId)
            ->whereNull('deleted_at')
            ->first();
        return $this->normalizeToObject($row);
    }

    public function findByIdForUpdate(int $userId): ?\stdClass
    {
        if (!$this->db->inTransaction()) {
            throw new \RuntimeException("findByIdForUpdate must be called within an active database transaction.");
        }

        $stmt = $this->db->prepare("SELECT id FROM users WHERE id = ? FOR UPDATE");
        $stmt->execute([$userId]);
        $row = $this->fetchObject($stmt);
        return $this->normalizeToObject($row);
    }

    /**
     * BUGFIX-CTRL-RAW-SQL-2026-06.
     *
     * Return the id of every non-deleted user holding a given role.
     * Used by RoleController::update() and RoleController::toggle() to
     * walk the affected users and clear their permission cache after a
     * role definition changes. The controller used to inline the
     * `SELECT id FROM users WHERE role_id = ? AND deleted_at IS NULL`
     * twice; we centralise it here so the column reference and the
     * soft-delete predicate live in exactly one place.
     *
     * @return int[]  list of user ids
     */
    public function findIdsByRoleId(int $roleId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT id FROM users WHERE role_id = ? AND deleted_at IS NULL",
            [$roleId]
        );
        return array_map(static fn($r) => (int)($r->id ?? 0), $rows);
    }

    // FIX-DEAD-METHOD (راند ۹۲ / X364): incrementFraudScore حذف شد — صفر فراخوان
    // (grep-proof در app/، tests/، qa/) و مسیر زندهٔ افزایش fraud_score فقط
    // UserService::incrementFraudScore است که اکنون (X364) از مسیر لجر
    // (ScoreCommandService::applySystemDelta) می‌گذرد؛ UPDATE مستقیم users
    // دیگر مجاز نیست (پروجکشن سوم باید از رویداد لجر مشتق شود).

    public function isBlacklisted(int $userId): bool
    {
        $row = $this->db->fetch("SELECT is_blacklisted FROM users WHERE id = ?", [$userId]);
        return (bool)($row->is_blacklisted ?? false);
    }

    public function updateLastLogin(int $userId, string $ip, string $userAgent): bool
    {
        return (bool)$this->db->query(
            "UPDATE users SET last_login = NOW(), last_ip = ?, last_user_agent = ?, updated_at = NOW() WHERE id = ?",
            [$ip, $userAgent, $userId]
        );
    }

    /**
     * 🛡️ S27C-F3 (v33): انتساب معرف با CAS — «فقط اگر خالی» در همان SQL.
     * نگارش قبلی (updateUser با فیلد referred_by) no-op خاموش بود: فیلد در
     * updatableFields نبود، «موفق» گزارش و پیام موفقیت دروغ نمایش داده می‌شد.
     *
     * @return bool true = منتسب شد؛ false = معرف قبلاً ثبت شده یا کاربر ناموجود
     */
    public function claimReferrerIfEmpty(int $userId, int $referrerId): bool
    {
        if ($userId <= 0 || $referrerId <= 0 || $userId === $referrerId) {
            return false;
        }
        $stmt = $this->db->query(
            "UPDATE users SET referred_by = ?, updated_at = NOW()
             WHERE id = ? AND referred_by IS NULL",
            [$referrerId, $userId]
        );
        return $stmt !== false && $stmt->rowCount() > 0;
    }

    public function storeRememberToken(int $userId, string $hashedToken, string $expiresAt): bool
    {
        $statement = $this->db->query(
            'UPDATE users SET remember_token=?, remember_expires_at=?, updated_at=NOW() WHERE id=?',
            [$hashedToken, $expiresAt, $userId]
        );
        return $statement->rowCount() === 1;
    }

    public function revokeRememberToken(int $userId): bool
    {
        $statement = $this->db->query(
            'UPDATE users SET remember_token=NULL, remember_expires_at=NULL, updated_at=NOW() WHERE id=?',
            [$userId]
        );
        return $statement->rowCount() > 0;
    }

    /**
     * 🛡️ H-09 Fix: تعویض هش رمز + ابطال توکن «مرا به خاطر بسپار» در یک UPDATE اتمیک.
     *
     * ستون‌های remember_* سیستم‌متعلق‌اند و عمداً در $fillable نیستند؛ بنابراین
     * Model::update() آن‌ها را دور می‌ریخت و کوکی remember مسروقه پس از تغییر رمز
     * معتبر می‌ماند (H-03 شکسته). نوشتن مستقیم SQL — همان الگوی رسمی
     * storeRememberToken/revokeRememberToken — برای این ستون‌های امنیتی است.
     */
    public function changePassword(int $userId, string $passwordHash): bool
    {
        $statement = $this->db->query(
            'UPDATE users SET password=?, remember_token=NULL, remember_expires_at=NULL, updated_at=NOW() WHERE id=?',
            [$passwordHash, $userId]
        );
        return $statement->rowCount() > 0;
    }

    /**
     * FIX-18O (P0): system-managed users columns that must NEVER come from
     * request-shaped input. Used ONLY by createWithSystemColumns() which is
     * called from the registration service after its own input allowlist.
     */
    private const SYSTEM_ONLY_COLUMNS = [
        'role', 'status', 'is_admin',
        'email_verified_at', 'email_verification_token',
        'level_slug', 'fraud_score',
        'two_factor_secret', 'two_factor_enabled', 'two_factor_method',
    ];

    /**
     * FIX-R20-C1: credential columns removed from $fillable. 'password' is
     * written at birth only, through createWithCredentials() from the
     * registration service (after REGISTER_ALLOWED_FIELDS + PasswordPolicy);
     * every post-creation password write MUST go through changePassword().
     */
    private const CREDENTIAL_ONLY_COLUMNS = ['password'];

    /**
     * FIX-18O (P0): INSERT for the registration path with explicit system
     * columns.
     *
     * UserService::register() sets role/status/is_admin/email_verified_at/
     * email_verification_token server-side (never from user input). With the
     * privileged keys removed from $fillable, plain create() would silently
     * drop them and break registration; this explicit-column writer keeps the
     * system defaults flowing while request-shaped data stays fillable-filtered.
     *
     * @param array<string, mixed> $data
     * @return int|false
     */
    public function createWithSystemColumns(array $data): mixed
    {
        return $this->insertWithPrivilegedColumns($data, self::SYSTEM_ONLY_COLUMNS);
    }

    /**
     * FIX-R20-C1: INSERT for the credential-bearing registration path.
     *
     * 'password' left $fillable, so a plain create() (and even
     * createWithSystemColumns()) would silently drop it and create a user that
     * can never log in. Registration is the ONLY legitimate password-at-birth
     * writer; this explicit-column creator merges the password (and any system
     * columns) back after the fillable filter, mirroring createWithSystemColumns().
     *
     * @param array<string, mixed> $data
     * @return int|false
     */
    public function createWithCredentials(array $data): mixed
    {
        return $this->insertWithPrivilegedColumns(
            $data,
            array_merge(self::CREDENTIAL_ONLY_COLUMNS, self::SYSTEM_ONLY_COLUMNS)
        );
    }

    /**
     * Shared explicit-column INSERT core: extract the privileged columns,
     * fillable-filter the rest, then merge the privileged values back so they
     * reach the DB in one single INSERT.
     *
     * @param array<string, mixed> $data
     * @param list<string> $privileged
     * @return int|false
     */
    private function insertWithPrivilegedColumns(array $data, array $privileged): mixed
    {
        $privilegedData = [];
        foreach ($privileged as $column) {
            if (array_key_exists($column, $data)) {
                $privilegedData[$column] = $data[$column];
                unset($data[$column]);
            }
        }

        $data = $this->filterFillable($data);
        foreach ($privilegedData as $column => $value) {
            $data[$column] = $value;
        }

        $result = $this->db->table(static::$table)->insert($data);
        return $result === false ? false : (int)$result;
    }

    /**
     * FIX-18O (P0): dedicated writer for the admin-managed profile columns.
     * Whitelist = role / status / level_slug ONLY (see audit round 18, P0-4).
     *
     * FIX-R36-W3 (F-A13-11): علاوه بر whitelistِ ستونی، مقادیر هم whitelist شدند —
     * قبلاً هر رشتهٔ دلخواهی (مثلاً role='hacker') عیناً در DB نوشته می‌شد و در
     * گاردهای سلسله‌مراتب به‌عنوان سطح ۰ تفسیر می‌شد (نقش خراب/بی‌پرمیژن).
     * مقادیر مجاز = دقیقاً مقادیر enum ستون‌ها در اسکیمای زندهٔ users
     * (شامل status='locked_2fa' که مسیر TwoFactorService این نوشتار را صدا می‌زند)
     * و level_slug فقط قالب اسلاگ امن (varchar(60)).
     *
     * @param array<string, mixed> $explicit
     */
    public function updateAdminManagedFields(int $userId, array $explicit): bool
    {
        $allowed = ['role', 'status', 'level_slug'];
        $data = array_intersect_key($explicit, array_flip($allowed));

        if (array_key_exists('role', $data) && !in_array($data['role'], ['user', 'support', 'admin', 'super_admin'], true)) {
            unset($data['role']);
        }
        if (array_key_exists('status', $data) && !in_array($data['status'], ['active', 'inactive', 'suspended', 'locked', 'locked_2fa', 'banned', 'deleted'], true)) {
            unset($data['status']);
        }
        if (array_key_exists('level_slug', $data) && (is_string($data['level_slug']) ? preg_match('/^[a-z0-9_-]{1,60}$/', $data['level_slug']) !== 1 : true)) {
            unset($data['level_slug']);
        }
        if ($data === []) {
            return false;
        }

        $data['updated_at'] = date('Y-m-d H:i:s');
        $affected = $this->db->table(static::$table)
            ->where('id', '=', $userId)
            ->update($data);

        return $affected > 0;
    }

    /**
     * FIX-18O (P0): explicit-column writer for the (HMAC-hashed) email
     * verification token — same pattern as storeRememberToken().
     */
    public function storeEmailVerificationToken(int $userId, string $hashedToken): bool
    {
        $statement = $this->db->query(
            'UPDATE users SET email_verification_token=?, updated_at=NOW() WHERE id=?',
            [$hashedToken, $userId]
        );
        return $statement->rowCount() > 0;
    }

    /**
     * FIX-18O (P0): explicit-column writer for 2FA columns (service-owned).
     * Whitelist = two_factor_secret / two_factor_enabled / two_factor_method.
     *
     * @param array<string, mixed> $settings
     */
    public function updateTwoFactorSettings(int $userId, array $settings): bool
    {
        $allowed = ['two_factor_secret', 'two_factor_enabled', 'two_factor_method'];
        $data = array_intersect_key($settings, array_flip($allowed));
        if ($data === []) {
            return false;
        }

        $data['updated_at'] = date('Y-m-d H:i:s');
        $affected = $this->db->table(static::$table)
            ->where('id', '=', $userId)
            ->update($data);

        return $affected > 0;
    }

    public function verifyEmail(int $userId): bool
    {
        return (bool)$this->db->query(
            "UPDATE users SET email_verified_at = NOW(), email_verification_token = NULL, updated_at = NOW() WHERE id = ?",
            [$userId]
        );
    }

    /**
     * CRITICAL-03 Fix: Atomic check and update for account lockout to prevent race conditions.
     * Checks if the user status is 'active' and updates it to 'locked' if rowCount matches.
     */
    public function lockIfExceededAttempts(int $userId): bool
    {
        $stmt = $this->db->query(
            "UPDATE users SET status = 'locked', updated_at = NOW()
             WHERE id = ? AND status = 'active'",
            [$userId]
        );
        return $stmt->rowCount() === 1;
    }

    /**
     * CRIT-06 Fix: به‌روزرسانی اتمیک تایم‌اسلایس 2FA برای جلوگیری از Race Condition و Replay Attack
     */
    public function update2FATimeslice(int $userId, int $slice): bool
    {
        $stmt = $this->db->query(
            "UPDATE users SET last_2fa_timeslice = ?
             WHERE id = ? AND (last_2fa_timeslice IS NULL OR last_2fa_timeslice < ?)",
            [$slice, $userId, $slice]
        );
        return $stmt->rowCount() > 0;
    }

    /**
     * @param array<string, mixed> $filters
     * @param array<string, string>|null $orderBy
     * @return list<\stdClass>
     */
    public function searchWithFilters(array $filters = [], int $limit = 20, int $offset = 0, ?array $orderBy = null): array
    {
        $query = $this->db->table('users')->whereNull('deleted_at');

        if (!empty($filters['search'])) {
            $this->applySearch($query, str_value($filters['search']));
        }

        $query = $this->applyFilters($query, $filters);

        // FIX-R16B (ITEM 7): مرتب‌سازی سمت سرور با whitelist (پیش‌فرض = ترتیب فعلی).
        $sortColumn = 'created_at';
        $sortDirection = 'DESC';
        if (is_array($orderBy)
            && isset($orderBy['column'], $orderBy['direction'])
            && in_array($orderBy['column'], self::ADMIN_SORTABLE_COLUMNS, true)) {
            $sortColumn = (string)$orderBy['column'];
            $sortDirection = strtolower((string)$orderBy['direction']) === 'asc' ? 'ASC' : 'DESC';
        }

        return $query->orderBy($sortColumn, $sortDirection)
                     ->limit($limit)
                     ->offset($offset)
                     ->get();
    }

    /** @param array<string, mixed> $filters */
    public function countWithFilters(array $filters = []): int
    {
        $query = $this->db->table('users')->whereNull('deleted_at');

        if (!empty($filters['search'])) {
            $this->applySearch($query, str_value($filters['search']));
        }

        $query = $this->applyFilters($query, $filters);

        return $query->count();
    }

    public function getAdminStats(): object
    {
        return $this->db->fetch(
            "SELECT
                COUNT(*) AS total_count,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_count,
                SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) AS suspended_count,
                SUM(CASE WHEN status = 'banned' THEN 1 ELSE 0 END) AS banned_count
             FROM users
             WHERE deleted_at IS NULL"
        ) ?: (object)[];
    }

    /** @return list<\stdClass> */
    public function getUserSettings(int $userId): array
    {
        return $this->db->fetchAll(
            "SELECT setting_key, setting_value FROM user_settings WHERE user_id = ?",
            [$userId]
        );
    }

    public function upsertSetting(int $userId, string $key, string $value): bool
    {
        return (bool)$this->db->query(
            "INSERT INTO user_settings (user_id, setting_key, setting_value, updated_at)
             VALUES (?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()",
            [$userId, $key, $value]
        );
    }

    public function deleteSettings(int $userId): bool
    {
        return (bool)$this->db->query("DELETE FROM user_settings WHERE user_id = ?", [$userId]);
    }

    // ==================== ANALYTICS METHODS ====================

    /**
     * آمار کلی کاربران
     * M39: Fixed status inconsistency (int vs string) - use string values
     */
    /** @return array<string, mixed> */
    public function getUserCountStats(): array
    {
        $row = $this->db->fetch("
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'banned' THEN 1 ELSE 0 END) as banned,
                SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) as suspended
            FROM users
            WHERE deleted_at IS NULL
        ");
        return [
            'total' => (int)($row->total ?? 0),
            'active' => (int)($row->active ?? 0),
            'banned' => (int)($row->banned ?? 0),
            'suspended' => (int)($row->suspended ?? 0),
        ];
    }

    /**
     * آمار ثبت‌نام جدید
     */
    /** @return array<string, mixed> */
    public function getNewUserStats(): array
    {
        $today = date('Y-m-d');
        $row = $this->db->fetch("
            SELECT
                SUM(CASE WHEN DATE(created_at) = ? THEN 1 ELSE 0 END) as new_today,
                SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as new_this_week,
                SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as new_this_month
            FROM users
            WHERE deleted_at IS NULL
        ", [$today]);
        return [
            'new_today' => (int)($row->new_today ?? 0),
            'new_this_week' => (int)($row->new_this_week ?? 0),
            'new_this_month' => (int)($row->new_this_month ?? 0),
        ];
    }

    /**
     * آمار فعالیت کاربران (DAU, WAU, MAU)
     */
    /** @return array<string, mixed> */
    public function getUserActivityStats(): array
    {
        $today = date('Y-m-d');
        $row = $this->db->fetch("
            SELECT
                SUM(CASE WHEN DATE(last_login) = ? THEN 1 ELSE 0 END) as dau,
                SUM(CASE WHEN last_login >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as wau,
                SUM(CASE WHEN last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as mau
            FROM users
            WHERE deleted_at IS NULL
        ", [$today]);
        return [
            'dau' => (int)($row->dau ?? 0),
            'wau' => (int)($row->wau ?? 0),
            'mau' => (int)($row->mau ?? 0),
        ];
    }

    /**
     * آمار سطح‌بندی کاربران
     */
    /** @return array<string, mixed> */
    public function getUserTierStats(): array
    {
        $rows = $this->db->fetchAll("
            SELECT COALESCE(level_slug, 'silver') as tier, COUNT(*) as count
            FROM users
            WHERE deleted_at IS NULL
            GROUP BY level_slug
        ");
        $tiers = ['silver' => 0, 'gold' => 0, 'vip' => 0];
        foreach ($rows as $row) {
            $tiers[(string)$row->tier] = (int)$row->count;
        }
        return $tiers;
    }

    // ==================== RBAC (ROLES & PERMISSIONS) HELPER METHODS ====================

    public function hasPermission(int $userId, string $slug): bool
    {
        $userRow = $this->db->fetch("SELECT role FROM users WHERE id = ? LIMIT 1", [$userId]);
        if ($userRow && in_array((string)($userRow->role ?? ''), ['super_admin', 'superadmin'], true)) {
            return true;
        }

        $result = $this->db->table('user_roles as ur')
            ->join('role_permissions as rp', 'ur.role_id', '=', 'rp.role_id')
            ->join('permissions as p', 'rp.permission_id', '=', 'p.id')
            ->where('ur.user_id', '=', $userId)
            ->where('p.slug', '=', $slug)
            ->selectRaw('1')
            ->first();

        return (bool)$result;
    }

    /** @return list<string> */
    public function getUserPermissions(int $userId): array
    {
        $result = $this->db->table('user_roles as ur')
            ->join('role_permissions as rp', 'ur.role_id', '=', 'rp.role_id')
            ->join('permissions as p', 'rp.permission_id', '=', 'p.id')
            ->where('ur.user_id', '=', $userId)
            ->select('p.slug')
            ->get();

        return array_map(fn($p) => (string)($p->slug ?? ''), $result);
    }

    public function assignRole(int $userId, int $roleId, ?int $grantedBy = null): bool
    {
        return (bool)$this->db->query(
            "INSERT IGNORE INTO user_roles (user_id, role_id, granted_by, granted_at) VALUES (?, ?, ?, NOW())",
            [$userId, $roleId, $grantedBy]
        );
    }

    public function removeRole(int $userId, int $roleId): bool
    {
        return (bool)$this->db->table('user_roles')
            ->where('user_id', '=', $userId)
            ->where('role_id', '=', $roleId)
            ->delete();
    }


    /**
     * اعمال فیلترهای جستجو روی QueryBuilder
     * @param \Core\QueryBuilder $query
     * @param array<string, mixed> $filters
     * @return \Core\QueryBuilder
     */
    public function applyFilters(\Core\QueryBuilder $query, array $filters): \Core\QueryBuilder
    {
        if (!empty($filters['status'])) {
            $query->where('status', '=', $filters['status']);
        }
        if (!empty($filters['kyc_status'])) {
            $query->where('kyc_status', '=', $filters['kyc_status']);
        }
        if (!empty($filters['role'])) {
            $query->where('role', '=', $filters['role']);
        }
        if (!empty($filters['date_from'])) {
            $query->where('created_at', '>=', $filters['date_from'] . ' 00:00:00');
        }
        if (!empty($filters['date_to'])) {
            $query->where('created_at', '<=', $filters['date_to'] . ' 23:59:59');
        }
        if (isset($filters['is_verified'])) {
            // 🔒 AUDIT-FIX (R4-MEDIUM): از API صریح whereNull/whereNotNull استفاده
            // می‌شود — فرم سه‌پارامتری where('email_verified_at', 'IS NULL', null)
            // قبلاً توسط shorthand دوارگامی به مقایسهٔ رشته‌ای نادرست تبدیل می‌شد.
            if ($filters['is_verified']) {
                $query->whereNotNull('email_verified_at');
            } else {
                $query->whereNull('email_verified_at');
            }
        }
        return $query;
    }

    /**
     * Auto-generate a unique referral code on new user creation.
     */
    /** پیدا کردن کاربر با remember token */
    public function findByRememberToken(string $hashedToken): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT * FROM users WHERE remember_token = ? AND deleted_at IS NULL LIMIT 1",
            [$hashedToken]
        );
    }

    public function generateReferralCode(): string
    {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do {
            $code = '';
            for ($i = 0; $i < 8; $i++) {
                $code .= $chars[random_int(0, strlen((string)$chars) - 1)];
            }
        } while ($this->db->fetchColumn("SELECT COUNT(*) FROM users WHERE referral_code = ?", [$code]) > 0);
        return $code;
    }
}
