<?php

namespace App\Models;

use Core\Model;

class CryptoDepositIntent extends Model
{
    private function objectOrNull(mixed $value): ?\stdClass
    {
        return $value instanceof \stdClass ? $value : null;
    }

    protected static string $table = 'crypto_deposit_intents';

    public function validateIntentData(string $network, string $expectedAmount, string $address): void
    {
        $network = strtoupper(trim($network));
        if (!in_array($network, ['TRC20', 'BNB20', 'TON', 'SOL'], true)) {
            throw new \InvalidArgumentException('Unsupported crypto network: ' . $network);
        }
        if (!is_numeric($expectedAmount) || \bccomp((string)$expectedAmount, '0', 8) <= 0) {
            throw new \InvalidArgumentException('Expected amount must be positive.');
        }
        $validAddress = match ($network) {
            'BNB20' => (bool)preg_match('/^0x[a-f0-9]{40}$/i', $address),
            'TRC20' => (bool)preg_match('/^T[1-9A-HJ-NP-Za-km-z]{33}$/', $address),
            'TON' => (bool)preg_match('/^(?:0:-?[a-f0-9]{64}|[EU]Q[A-Za-z0-9_-]{46})$/', $address),
            'SOL' => (bool)preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $address),
        };
        if (!$validAddress) {
            throw new \InvalidArgumentException('Invalid crypto wallet address format.');
        }
    }

    public function getOpenIntentForUser(int $userId): ?\stdClass
    {
        $sql = "SELECT * FROM `" . static::$table . "`
                WHERE user_id = :user_id AND status = 'open'
                ORDER BY id DESC LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute(['user_id' => $userId]);
        $row = $stmt->fetch(\PDO::FETCH_OBJ);

        return $this->objectOrNull($row);
    }

    /**
     * FIX-R36-W3 (F-A17-08): ساخت اتمیک intent فقط وقتی کاربر intent بازِ دیگری
     * ندارد. الگوی قبلی در سرویس check-then-create بود (getOpenIntentForUser →
     * create) — دو درخواست هم‌زمان هر دو «نبودِ intent» را می‌دیدند و هر دو
     * می‌ساختند (دو expected_amount یکتا روی یک ولت سایت؛ double-tracking).
     * بدون تغییر schema: INSERT..SELECT..WHERE NOT EXISTS (همان الگوی
     * ReportVitrineListingJob:85) — در گارد WHERE قید status='open' داخل خود
     * INSERT اتمیک ارزیابی می‌شود؛ 0 = مسابقه باخته شده.
     *
     * @param array<string, mixed> $data کلیدهای user_id/currency/amount/address/
     *        network/requested_amount/expected_amount/to_wallet/expires_at/
     *        ip_address/user_agent/created_at/updated_at (status همیشه 'open' قفل است)
     * @return int id ردیف جدید، یا 0 اگر intent باز دیگری وجود داشت
     */
    public function createIfNoOpenIntent(array $data): int
    {
        $sql = "INSERT INTO `" . static::$table . "`
                (user_id, currency, amount, address, network, requested_amount, expected_amount, to_wallet, expires_at, status, ip_address, user_agent, created_at, updated_at)
                SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?, ?
                FROM DUAL
                WHERE NOT EXISTS (
                    SELECT 1 FROM `" . static::$table . "`
                    WHERE user_id = ? AND status = 'open'
                )";

        $stmt = $this->db->prepare($sql);
        $ok = $stmt->execute([
            $data['user_id'],
            $data['currency'],
            $data['amount'],
            $data['address'],
            $data['network'],
            $data['requested_amount'],
            $data['expected_amount'],
            $data['to_wallet'],
            $data['expires_at'],
            $data['ip_address'],
            $data['user_agent'],
            $data['created_at'],
            $data['updated_at'],
            $data['user_id'],
        ]);

        return ($ok && $stmt->rowCount() === 1) ? $this->db->lastInsertId() : 0;
    }

    public function expireIfPassed(int $intentId): void
    {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare("SELECT * FROM `" . static::$table . "` WHERE id = ? FOR UPDATE");
            $stmt->execute([$intentId]);
            $intent = $stmt->fetch(\PDO::FETCH_OBJ);

            $intentVars = is_object($intent) ? get_object_vars($intent) : [];
            if (is_string($intentVars['status'] ?? null) && $intentVars['status'] === 'open' && is_string($intentVars['expires_at'] ?? null) && \strtotime($intentVars['expires_at']) < \time()) {
                $stmt = $this->db->prepare("UPDATE `" . static::$table . "` SET status = 'expired', updated_at = NOW() WHERE id = ?");
                $stmt->execute([$intentId]);
            }

            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            // FIX-R36-W3 (F-A1-09): بلع بی‌صدا ممنوع — شکستِ انقضا یعنی intent منقضی
            // open می‌ماند (اشغال اسلات تک-intent کاربر) بدون هیچ ردِّ لاگ.
            try {
                logger()->warning('crypto_intent.expire_if_passed_failed', [
                    'intent_id' => $intentId,
                    'error'     => $e->getMessage(),
                ]);
            } catch (\Throwable) {
                // لاگ هرگز نباید مسیر فراخوان را بشکند
            }
        }
    }

    public function findByIdAndUser(int $id, int $userId): ?\stdClass
    {
        $sql = "SELECT * FROM `" . static::$table . "` WHERE id = :id AND user_id = :user_id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['id' => $id, 'user_id' => $userId]);
        return $this->objectOrNull($stmt->fetch(\PDO::FETCH_OBJ));
    }

    /** Intent is loaded under the caller's transaction to prevent two hashes claiming it. */
    /** @return ?\stdClass */
    public function findOpenForUpdate(int $id, int $userId): ?\stdClass
    {
        $stmt = $this->db->prepare("SELECT * FROM `" . static::$table . "` WHERE id = ? AND user_id = ? AND status = 'open' LIMIT 1 FOR UPDATE");
        $stmt->execute([$id, $userId]);
        return $this->objectOrNull($stmt->fetch(\PDO::FETCH_OBJ));
    }

    /** Must be called inside the service transaction after deposit row creation. */
    public function claimForDeposit(int $id, int $userId): bool
    {
        $stmt = $this->db->prepare("UPDATE `" . static::$table . "` SET status = 'claimed', claimed_at = NOW(), updated_at = NOW() WHERE id = ? AND user_id = ? AND status = 'open'");
        $stmt->execute([$id, $userId]);
        return $stmt->rowCount() === 1;
    }

    public function markAsClaimed(int $id): bool
    {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare("SELECT * FROM `" . static::$table . "` WHERE id = ? FOR UPDATE");
            $stmt->execute([$id]);
            $intent = $stmt->fetch(\PDO::FETCH_OBJ);

            $intentVars = is_object($intent) ? get_object_vars($intent) : [];
            $status = array_key_exists('status', $intentVars) ? $intentVars['status'] : null;
            if (is_string($status) && $status === 'open') {
                $stmt = $this->db->prepare("UPDATE `" . static::$table . "` SET status = 'claimed', claimed_at = NOW(), updated_at = NOW() WHERE id = ?");
                $stmt->execute([$id]);
                $this->db->commit();
                return true;
            }

            $this->db->rollback();
            return false;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            // FIX-R36-W3 (F-A1-09): بلع بی‌صدا ممنوع — شکستِ claim وضعیتِ پول-مجاورِ
            // intent را بدون هیچ ردِّ لاگ عوض نمی‌کند/نیمه‌کاره می‌گذارد.
            try {
                logger()->warning('crypto_intent.mark_as_claimed_failed', [
                    'intent_id' => $id,
                    'error'     => $e->getMessage(),
                ]);
            } catch (\Throwable) {
                // لاگ هرگز نباید مسیر فراخوان را بشکند
            }
            return false;
        }
    }

    public function findOpenByNetworkAndAmount(string $network, string $expectedAmount): ?\stdClass
    {
        $sql = "SELECT id FROM `" . static::$table . "`
                WHERE network = :network AND status = 'open' AND expected_amount = :expected_amount
                LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['network' => $network, 'expected_amount' => $expectedAmount]);
        return $this->objectOrNull($stmt->fetch(\PDO::FETCH_OBJ));
    }
}