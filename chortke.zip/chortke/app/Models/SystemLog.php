<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

/**
 * SystemLog Model — Data Access Layer
 * 
 * مسئولیت: CRUD operations روی system_logs table
 * نوشتاری: خطاها، هشدارها، اطلاعات سیستمی
 */
class SystemLog extends Model
{
    protected static string $table = 'system_logs';
    private ?\App\Contracts\LoggerInterface $logger = null;

    protected array $fillable = ['level', 'channel', 'message', 'context', 'created_at'];

    /**
     * درج رکورد جدید
     */
    /** @param array<string, mixed> $data */
    public function insert(array $data): bool
    {
        try {
            $stmt = $this->db->prepare(
                // FIX-X210: شِمای واقعی جدول (id, level, channel, message, context, created_at) —
                // INSERT قبلی ستون‌های ناموجود (request_id/type/user_id/ip_address/user_agent)
                // داشت و همیشه ساکت شکست می‌خورد.
                "INSERT INTO system_logs
                (level, channel, message, context, created_at)
                VALUES (?, ?, ?, ?, NOW())"
            );

            return $stmt->execute([
                $data['level'] ?? 'INFO',
                $data['channel'] ?? 'system',
                mb_substr(str_value($data['message'] ?? ''), 0, 1000),
                isset($data['context']) && !is_string($data['context'])
                    ? json_encode($data['context'], JSON_UNESCAPED_UNICODE)
                    : ($data['context'] ?? null),
            ]);
        } catch (\Throwable $e) {
            $this->logger?->error('model.system_log.insert.failed', [
                'channel' => 'model',
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * دریافت لاگ‌های سیستمی با فیلتر
     *
     * FIX-18O (P2): پارامتر/user_id filter حذف شد — جدول system_logs ستون
     * user_id ندارد (2026_06_10_0046_final_missing_tables.sql: id, level,
     * channel, message, context, created_at) و شرط `user_id = ?` همیشه
     * SQLSTATE 42S22 می‌داد. فراخوان‌زنده‌ای وجود نداشت (فقط
     * MaintenanceService::deleteOlderThanChunked از این مدل استفاده می‌کند).
     *
     * @return array{rows: list<array<string, mixed>>, total: int, page: int, perPage: int, totalPages: int}
     */
    public function getPaginated(
        int $page = 1,
        int $perPage = 20,
        ?string $level = null,
        ?string $search = null,
        ?string $dateFrom = null,
        ?string $dateTo = null
    ): array {
        // C-04: Enforce hard ceiling on pagination depths to prevent unbounded pagination
        $page = max(1, min(10000, $page));
        $perPage = max(1, min(100, $perPage));
        $offset = ($page - 1) * $perPage;

        $where = [];
        $params = [];

        if ($level !== null) {
            $where[] = 'level = ?';
            $params[] = $level;
        }

        if ($search !== null) {
            $like = '%' . addcslashes($search, '%_\\') . '%'; // FIX-R36-W3 (F-A19a-08)
            $where[] = '(message LIKE ? OR context LIKE ?)';
            $params[] = $like;
            $params[] = $like;
        }

        if ($dateFrom !== null) {
            $where[] = 'created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }

        if ($dateTo !== null) {
            $where[] = 'created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        // Count
        $countStmt = $this->db->prepare("SELECT COUNT(*) FROM system_logs {$whereClause}");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        // Data
        $dataStmt = $this->db->prepare(
            "SELECT * FROM system_logs {$whereClause}
             ORDER BY created_at DESC
             LIMIT ? OFFSET ?"
        );
        $dataStmt->execute([...$params, $perPage, $offset]);

        $rows = $dataStmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => (int) ceil($total / $perPage),
        ];
    }

    /**
     * دریافت یک رکورد با ID
     */
    /** @return array<string, mixed>|null */
    public function findById(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM system_logs WHERE id = ?");
        $stmt->execute([$id]);
        return $this->fetchAssoc($stmt) ?: null;
    }

    /**
     * دریافت لاگ‌های اخیر
     */
    /** @return list<array<string, mixed>> */
    public function getRecent(int $limit = 50, ?string $level = null): array
    {
        $limit = max(1, min(500, $limit));

        $where = [];
        $params = [];

        if ($level !== null) {
            $where[] = 'level = ?';
            $params[] = $level;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT * FROM system_logs {$whereClause}
             ORDER BY created_at DESC
             LIMIT ?"
        );

        $stmt->execute([...$params, $limit]);
        return $this->fetchAssocList($stmt);
    }

    /**
     * شمارش لاگ‌ها
     */
    public function count(?string $level = null): int
    {
        $where = [];
        $params = [];

        if ($level !== null) {
            $where[] = 'level = ?';
            $params[] = $level;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare("SELECT COUNT(*) FROM system_logs {$whereClause}");
        $stmt->execute($params);

        return (int) $stmt->fetchColumn();
    }

    /**
     * حذف soft - علامت‌گذاری برای حذف
     */
    public function softDelete(int $id): bool
    {
        try {
            // FIX راند ۷۷ (ستون شبح): system_logs هیچ ستون نشان‌گر حذف (updated_at/deleted_at) ندارد؛
            // «حذف نرم» در این جدول قابل نمایش نیست — حذف قطعی انجام می‌شود (متد بی‌فراخوان).
            $stmt = $this->db->prepare("DELETE FROM system_logs WHERE id = ?");
            return $stmt->execute([$id]);
        } catch (\Throwable $e) {
            $this->logger?->error('model.system_log.soft_delete.failed', [
                'channel' => 'model',
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * حذف لاگ‌های قدیمی تر از تعداد روز
     */
    public function deleteOlderThan(int $days = 90): int
    {
        try {
            $stmt = $this->db->prepare(
                "DELETE FROM system_logs
                 WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)"
            );
            $stmt->execute([$days]);
            return $stmt->rowCount();
        } catch (\Throwable $e) {
            $this->logger?->error('model.system_log.delete_older_than.failed', [
                'channel' => 'model',
                'error' => $e->getMessage(),
            ]);
            return 0;
        }
    }

    /**
     * حذف لاگ‌های قدیمی به‌صورت chunked (برای جداول بزرگ)
     */
    public function deleteOlderThanChunked(int $days = 90, int $chunkSize = 5000): int
    {
        $totalDeleted = 0;
        $maxIterations = 100;

        try {
            for ($i = 0; $i < $maxIterations; $i++) {
                $stmt = $this->db->prepare(
                    "DELETE FROM system_logs
                     WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                     LIMIT ?"
                );
                $stmt->execute([$days, $chunkSize]);
                $batchDeleted = $stmt->rowCount();

                $totalDeleted += $batchDeleted;

                if ($batchDeleted < $chunkSize) {
                    break;
                }
            }
        } catch (\Throwable $e) {
            $this->logger?->error('model.system_log.delete_older_than_chunked.failed', [
                'channel' => 'model',
                'error' => $e->getMessage(),
            ]);
        }

        return $totalDeleted;
    }

    /**
     * دریافت آمارهای سطح
     */
    /** @return list<array<string, mixed>> */
    public function getLevelStats(?string $dateFrom = null, ?string $dateTo = null): array
    {
        $where = [];
        $params = [];

        if ($dateFrom !== null) {
            $where[] = 'created_at >= ?';
            $params[] = $dateFrom . ' 00:00:00';
        }

        if ($dateTo !== null) {
            $where[] = 'created_at <= ?';
            $params[] = $dateTo . ' 23:59:59';
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $stmt = $this->db->prepare(
            "SELECT level, COUNT(*) as count
             FROM system_logs {$whereClause}
             GROUP BY level
             ORDER BY count DESC"
        );

        $stmt->execute($params);
        return $this->fetchAssocList($stmt);
    }
}
