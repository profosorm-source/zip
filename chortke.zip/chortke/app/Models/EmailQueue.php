<?php

namespace App\Models;

use Core\Model;

class EmailQueue extends Model
{
    protected static string $table = 'email_queue';

    /*
     * F-A2-04: پایپ‌لاین زندهٔ ایمیل «EmailDeliveryStore» است (claim اتمیک با
     * status/attempts/last_error/updated_at — همهٔ ستون‌های واقعی جدول).
     * متدهای مردهٔ این مدل که به ستون‌های شبح جدول ارجاع می‌دادند
     * (sent_at / error_message / is_archived / archived_at — هیچ‌کدام در
     * email_queue وجود ندارد) حذف شدند: markAsSent، markAsFailed،
     * cleanOldSent، archiveOldSent، retryAllFailed. اثبات مرده‌بودن (grep
     * روی app/ routes/ tests/: صفر فراخوانی؛ مسیرهای زنده فقط
     * EmailDeliveryStore::markAsSent/markAsFailed/retryAllFailed را صدا
     * می‌زنند). هر فراخوانی آیندهٔ این متدها یک 42S22 نهفته بود.
     */

    /**
     * FIX-RAW-SQL: شمارش ایمیل‌های «در انتظار / در حال ارسال» برای کارت وضعیت
     * صف ایمیل (/status). مالکیت SQL با مدل است — کنترلر فقط متد را صدا می‌زند.
     * خطای DB به‌صورت کنترل‌شده null برمی‌گردد (حالت «unknown» در ویو).
     */
    public function countPendingOrSending(): ?int
    {
        try {
            $row = $this->db->fetch(
                "SELECT COUNT(*) AS c FROM `" . static::$table . "` WHERE status IN ('pending','sending')"
            );
            return (int)($row->c ?? 0);
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * دریافت ایمیل‌های آماده ارسال (با اولویت‌بندی)
     */
    /** @return list<object> */
    public function getPendingEmails(int $limit = 10): array
    {
        $now = date('Y-m-d H:i:s');

        return $this->db->fetchAll(
            "SELECT * FROM `" . static::$table . "`
             WHERE status = 'pending'
               AND attempts < 3
               AND (scheduled_at IS NULL OR scheduled_at <= :now)
             ORDER BY
               CASE priority
                 WHEN 'urgent' THEN 1
                 WHEN 'high'   THEN 2
                 WHEN 'normal' THEN 3
                 ELSE 4
               END ASC,
               created_at ASC
             LIMIT :limit",
            ['now' => $now, 'limit' => $limit]
        );
    }

    /**
     * علامت‌گذاری به عنوان در حال ارسال
     */
    public function markAsSending(int $emailId): bool
    {
        return $this->db->execute(
            "UPDATE `" . static::$table . "`
             SET status = 'sending', updated_at = NOW()
             WHERE id = ? AND status = 'pending'",
            [$emailId]
        ) !== false;
    }

    /**
     * آمار صف
     */
    /** @return array<string, int> */
    public function getStats(): array
    {
        $rows = $this->db->fetchAll(
            "SELECT status, COUNT(*) as cnt FROM `" . static::$table . "`
             GROUP BY status"
        );
        $stats = ['pending' => 0, 'sending' => 0, 'sent' => 0, 'failed' => 0];
        foreach ($rows as $r) {
            $r = (array)$r;
            $stats[$r['status']] = (int)$r['cnt'];
        }
        return $stats;
    }

    /** @return list<object> */
    public function findAllPaginated(
        int $limit,
        int $offset,
        ?string $status = null,
        ?string $search = null
    ): array {
        $where = '1=1';
        $params = [];

        if ($status) {
            $where .= ' AND status = ?';
            $params[] = $status;
        }

        if ($search) {
            $where .= ' AND (to_email LIKE ? OR subject LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }

        return $this->db->fetchAll(
            "SELECT * FROM `" . static::$table . "` WHERE {$where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            array_merge($params, [$limit, $offset])
        ) ?: [];
    }

    public function countAll(?string $status = null, ?string $search = null): int
    {
        $where = '1=1';
        $params = [];

        if ($status) {
            $where .= ' AND status = ?';
            $params[] = $status;
        }

        if ($search) {
            $where .= ' AND (to_email LIKE ? OR subject LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }

        $count = $this->db->fetchColumn("SELECT COUNT(*) FROM `" . static::$table . "` WHERE {$where}", $params);
        return (int)$count;
    }

    public function retryById(int $id): bool
    {
        $result = $this->db->execute(
            "UPDATE `" . static::$table . "` SET status = 'pending', attempts = 0 WHERE id = ? AND status IN ('failed','pending')",
            [$id]
        );

        return $result !== false && $result > 0;
    }

    /**
     * ایمیل‌های ناموفق برای بررسی ادمین
     */
    /** @return list<object> */
    public function getFailedEmails(int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT eq.*, u.full_name, u.email as user_email
             FROM `" . static::$table . "` eq
             LEFT JOIN users u ON u.id = eq.user_id
             WHERE eq.status = 'failed'
             ORDER BY eq.updated_at DESC
             LIMIT ?",
            [$limit]
        );
    }
}