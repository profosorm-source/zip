<?php

namespace App\Models;

use Core\Model;
use Core\Database;

class Role extends Model {
    protected static string $table = 'roles';

    /**
     * یافتن نقش با ID
     */
    public function find(int $id): ?\stdClass
    {
        $stmt = $this->db->prepare("SELECT * FROM roles WHERE id = ? AND deleted_at IS NULL");
        $stmt->execute([$id]);
        $result = $stmt->fetch(\PDO::FETCH_OBJ);

        return $result instanceof \stdClass ? $result : null;
    }

    /**
     * یافتن نقش با slug
     */
    public function findBySlug(string $slug): ?\stdClass
    {
        $stmt = $this->db->prepare("SELECT * FROM roles WHERE slug = ? AND deleted_at IS NULL");
        $stmt->execute([$slug]);
        /** @var \stdClass|false $result */
        $result = $stmt->fetch(\PDO::FETCH_OBJ);

        return $result instanceof \stdClass ? $result : null;
    }

    /**
     * دریافت تمام نقش‌ها (سازگار با Core\Model)
     */
    /** @param array<string, mixed> $filters */
    public function all(array $filters = [], int $limit = 100, int $offset = 0): array
    {
        return $this->allRoles(true);
    }

    /**
     * دریافت تمام نقش‌ها با فیلتر فعال/غیرفعال
     *
     * 🛡️ FIX-M9-03 (گزارش ماژول ۹): user_count اکنون از user_roles (اتحادِ نقشِ
     * primary و ثانویه) شمرده می‌شود — قبلاً فقط users.role_id و اعضایِ نقشِ ثانویه
     * صفر دیده می‌شدند و نقشِ دارایِ عضوِ فعال قابلِ حذفِ نرم بود.
     * (شمارش با یک کوئریِ raw جداگانه محاسبه و ادغام می‌شود — SafeExpressionِ
     * QueryBuilder زیر‌کوئریِ count داخل selectRaw را مجاز نمی‌داند.)
     */
    /** @return list<\stdClass> */
    public function allRoles(bool $onlyActive = true): array
    {
        $query = $this->db->table('roles as r')
            ->select('r.*')
            ->whereNull('r.deleted_at');

        if ($onlyActive) {
            $query->where('r.is_active', '=', 1);
        }

        /** @var list<\stdClass> $roles */
        $roles = $query->groupBy('r.id')
            ->orderBy('r.id', 'ASC')
            ->get();

        if ($roles === []) {
            return $roles;
        }

        // FIX-M9-03: اتحادِ دارندگانِ pivot و primary (بدونِ تکرار) در یک کوئری
        $roleIds = array_map(static fn($r) => (int)$r->id, $roles);
        $placeholders = implode(',', array_fill(0, count($roleIds), '?'));
        $rows = $this->db->fetchAll(
            "SELECT role_id, COUNT(DISTINCT uid) AS cnt FROM (
                SELECT ur.role_id AS role_id, ur.user_id AS uid
                FROM user_roles ur
                INNER JOIN users u ON u.id = ur.user_id AND u.deleted_at IS NULL
                WHERE ur.role_id IN ($placeholders)
                UNION
                SELECT u2.role_id AS role_id, u2.id AS uid
                FROM users u2
                WHERE u2.deleted_at IS NULL AND u2.role_id IS NOT NULL
                  AND u2.role_id IN ($placeholders)
            ) AS members GROUP BY role_id",
            array_merge($roleIds, $roleIds)
        );
        $counts = [];
        foreach ($rows as $row) {
            $counts[(int)$row->role_id] = (int)$row->cnt;
        }
        foreach ($roles as $r) {
            $r->user_count = $counts[(int)$r->id] ?? 0;
        }

        return $roles;
    }

    /**
     * ایجاد نقش جدید
     */
    /** @param array<string, mixed> $data */
    public function createRole(array $data): ?\stdClass
    {
        $stmt = $this->db->prepare("
            INSERT INTO roles (name, slug, description, is_system, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        ");

        $ok = $stmt->execute([
            str_value($data['name'] ?? ''),
            str_value($data['slug'] ?? ''),
            $data['description'] ?? null,
            0, // 🚀 BUG FIX [L-02]: Force is_system = 0. System roles should only be created via migrations.
            int_value($data['is_active'] ?? 1),
        ]);

        if (!$ok) {
            return null;
        }

        // نیازمند Database::lastInsertId()
        $newId = (int)$this->db->lastInsertId();
        return $newId > 0 ? $this->find($newId) : null;
    }

    /**
     * بروزرسانی نقش
     */
    /** @param array<string, mixed> $data */
    public function update(int $id, array $data): bool
    {
        $fields = [];
        $values = [];

        $allowed = ['name', 'description', 'is_active'];

        foreach ($allowed as $field) {
            if (\array_key_exists($field, $data)) {
                $fields[] = "{$field} = ?";
                $values[] = $data[$field];
            }
        }

        if (empty($fields)) {
            return false;
        }

        // updated_at هم آپدیت شود
        $fields[] = "updated_at = NOW()";

        $values[] = $id;

        $stmt = $this->db->prepare("
            UPDATE roles SET " . \implode(', ', $fields) . "
            WHERE id = ? AND deleted_at IS NULL
        ");

        return $stmt->execute($values);
    }

    /**
     * حذف نرم نقش (فقط غیر سیستمی)
     */
    public function delete(int $id): bool
    {
        $role = $this->find($id);
        if (!$role || (int)$role->is_system === 1) {
            return false;
        }

        $stmt = $this->db->prepare("
            UPDATE roles SET deleted_at = NOW(), updated_at = NOW()
            WHERE id = ? AND is_system = 0
        ");

        return $stmt->execute([$id]);
    }

    /**
     * دریافت دسترسی‌های یک نقش
     */
    /** @return list<\stdClass> */
    public function getPermissions(int $roleId): array
    {
        $stmt = $this->db->prepare("
            SELECT p.* FROM permissions p
            INNER JOIN role_permissions rp ON rp.permission_id = p.id
            WHERE rp.role_id = ?
            ORDER BY p.group_name ASC, p.name ASC
        ");
        $stmt->execute([$roleId]);

        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    /**
     * دریافت slug های دسترسی‌های یک نقش
     */
    /** @return list<string> */
    public function getPermissionSlugs(int $roleId): array
    {
        $stmt = $this->db->prepare("
            SELECT p.slug FROM permissions p
            INNER JOIN role_permissions rp ON rp.permission_id = p.id
            WHERE rp.role_id = ?
        ");
        $stmt->execute([$roleId]);

        return $stmt->fetchAll(\PDO::FETCH_COLUMN);
    }

    /**
     * همگام‌سازی دسترسی‌های نقش
     * (حذف/درج روی pivot طبیعی است؛ چون role_permissions ستون deleted_at ندارد)
     *
     * 🛡️ FIX-M9-05 (گزارش ماژول ۹): شکلِ «خود-تراکنشی» فقط wrapper سازگاری است؛
     * کنترلرها از syncPermissionsInTx داخلِ تراکنشِ خودشان استفاده می‌کنند تا
     * شکستِ sync کلِ ایجاد/ویرایشِ نقش را rollback کند و پاسخِ موفقیتِ دروغ حذف شود.
     */
    /** @param list<int> $permissionIds */
    public function syncPermissions(int $roleId, array $permissionIds): bool
    {
        try {
            $this->db->beginTransaction();
            $ok = $this->syncPermissionsInTx($roleId, $permissionIds);
            $this->db->commit();
            return $ok;
        } catch (\InvalidArgumentException $e) {
            $this->db->rollback();
            if (\function_exists('logger')) {
                logger()->error('role.sync_permissions.failed', [
                    'channel' => 'rbac',
                    'role_id' => $roleId,
                    'error' => $e->getMessage(),
                    'exception' => get_class($e),
                ]);
            }
            return false;
        } catch (\Throwable $e) {
            $this->db->rollback();
            if (\function_exists('logger')) {
                logger()->error('role.sync_permissions.failed', [
                    'channel' => 'rbac',
                    'role_id' => $roleId,
                    'error' => $e->getMessage(),
                    'exception' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]);
            }
            return false;
        }
    }

    /**
     * 🛡️ FIX-M9-05: همگام‌سازیِ pivot بدونِ تراکنشِ مستقل — باید داخلِ تراکنشِ
     * والدِ کنترلر صدا زده شود. شکستِ اعتبارسنجی/درج exception می‌دهد تا کلِ
     * عملیاتِ نقش (create/update + sync) اتمیک بماند.
     *
     * @param list<int> $permissionIds
     * @throws \InvalidArgumentException روی شناسهٔ مجوز نامعتبر
     * @throws \Throwable روی خطای DB
     */
    public function syncPermissionsInTx(int $roleId, array $permissionIds): bool
    {
        // درج جدیدها
        $permissionIds = \array_values(\array_unique(\array_map('intval', $permissionIds)));

        // 🛡️ FIX-M9-05 (سخت‌گیرانه‌تر): اعتبارسنجیِ شناسه‌ها «قبل از» حذفِ pivot فعلی —
        // حتی خارج از تراکنشِ والد هم هیچ حالتِ نیمه‌کاره (حذف‌شده بدون درج) باقی نمی‌ماند.
        if (!empty($permissionIds)) {
            // 🚀 BUG FIX [M-04]: Validate permission IDs existence
            $placeholders = implode(',', array_fill(0, count($permissionIds), '?'));
            $sql = "SELECT COUNT(*) FROM permissions WHERE id IN ($placeholders)";
            $count = (int)$this->db->fetchColumn($sql, $permissionIds);

            if ($count !== count($permissionIds)) {
                throw new \InvalidArgumentException("One or more permission IDs are invalid.");
            }
        }

        // حذف قبلی‌ها (بعد از اطمینان از اعتبار ورودی)
        $this->db->table('role_permissions')
            ->where('role_id', '=', $roleId)
            ->delete();

        if (!empty($permissionIds)) {
            foreach ($permissionIds as $permId) {
                $this->db->table('role_permissions')->insert([
                    'role_id' => $roleId,
                    'permission_id' => $permId,
                ]);
            }
        }

        return true;
    }

    /**
     * تعداد کاربران هر نقش
     *
     * 🛡️ FIX-M9-03 (گزارش ماژول ۹): شمارش از user_roles (نقشِ ثانویه هم عضو است)
     * + دارندگانِ primaryِ بدونِ ردیفِ pivot. مبنایِ حذفِ نقش و UI شمارش.
     */
    public function getUserCount(int $roleId): int
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(DISTINCT uid) FROM (
                SELECT ur.user_id AS uid
                FROM user_roles ur
                INNER JOIN users u ON u.id = ur.user_id AND u.deleted_at IS NULL
                WHERE ur.role_id = ?
                UNION
                SELECT u2.id AS uid
                FROM users u2
                WHERE u2.role_id = ? AND u2.deleted_at IS NULL
            ) AS members
        ");
        $stmt->execute([$roleId, $roleId]);

        return (int)$stmt->fetchColumn();
    }

    /**
     * بررسی وجود slug
     */
    public function slugExists(string $slug, ?int $excludeId = null): bool
    {
        $sql = "SELECT COUNT(*) FROM roles WHERE slug = ? AND deleted_at IS NULL";
        $params = [$slug];

        if ($excludeId !== null) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return (int)$stmt->fetchColumn() > 0;
    }
}