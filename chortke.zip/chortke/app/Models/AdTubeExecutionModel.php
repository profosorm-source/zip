<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;
use Core\Database;

/**
 * AdTubeExecutionModel — Execution records for AdTube (video watch) ads.
 * Separate from social_task_executions due to domain-specific metrics (watch_time, progress).
 */
class AdTubeExecutionModel extends Model
{
    protected static string $table = 'adtube_views';

    public function __construct(Database $db) {
        parent::__construct($db);
    }

    /**
     * Find or create a pending execution for user+ad.
     * Returns the existing execution if one is already pending/watching.
     *
     * 🛡️ FIX-R3-F6: برای سازگاری حفظ شد — بدنه به reserveSlot() با سقف نامحدود
     * delegation می‌کند (بدون سقفِ همزمانی؛ سقف ۳تایی در کنترلر با reserveSlot اعمال می‌شود).
     */
    /** @param array<string, mixed> $context */
    public function findOrCreate(int $adId, int $executorId, array $context = []): ?\stdClass
    {
        return $this->reserveSlot($adId, $executorId, $context, PHP_INT_MAX);
    }

    /**
     * 🛡️ FIX-R3-F6 (P2 — R3 Ads/AdTube): رزرو «اسلات تماشای همزمان» داخل یک
     * تراکنش با قفل ردیفی — بستن TOCTOU سقف ۳ تماشای همزمان.
     *
     * الگوی قبلی: countActiveForUser در کنترلر (خارج از هر قفل مشترک) و بعد
     * findOrCreate؛ دو درخواست هم‌زمان برای دو آگهی متفاوت هر دو «۲ از ۳» را
     * می‌دیدند و هر دو INSERT می‌کردند → بیش از ۳ اجرای فعال. اکنون:
     *  ۱) ردیف users این executor با FOR UPDATE قفل می‌شود → رزروهای هم‌زمانِ
     *     همان کاربر سریال می‌شوند (قفل ردیفی موجود، بدون migration جدید)؛
     *  ۲) dedup همان user+ad (قفل FOR UPDATE ردیف فعال) حفظ شد؛
     *  ۳) شمارش فعال‌ها داخل همان تراکنشِ قفل‌دار انجام و در صورت پر بودن
     *     ظرفیت، کل تراکنش rollback می‌شود (هیچ رکوردی ساخته نمی‌شود) و null
     *     برمی‌گردد؛ فقط بعد از موفقیتِ رزرو، رکورد اجرا ساخته می‌شود.
     *
     * @param array<string, mixed> $context
     * @return \stdClass|null رکورد اجرا؛ null یعنی «ظرفیت پر است» (یا خطای دیتابیس خفیف)
     */
    /** @param array<string, mixed> $context */
    public function reserveSlot(int $adId, int $executorId, array $context = [], int $maxActive = 3): ?\stdClass
    {
        try {
            $this->db->beginTransaction();
            // ۱) قفل ردیف کاربر: سریال‌سازی رزرو اسلات برای همین executor
            //    (قفل ردیفیِ کوتاه‌عمر روی کلیدِ از قبل موجود — بدون تغییر اسکیما)
            $this->db->fetch("SELECT id FROM users WHERE id = ? FOR UPDATE", [$executorId]);

            // ۲) dedup همان user+ad — الگوی قبلی (AdTube Mobile Concurrency Lock) حفظ شد
            $existing = $this->db->fetch(
                "SELECT * FROM adtube_views WHERE ad_id = ? AND executor_id = ? AND status IN ('pending','watching') LIMIT 1 FOR UPDATE",
                [$adId, $executorId]
            );
            if ($existing) {
                $this->db->commit();
                return $existing;
            }

            // ۳) سقف همزمانی — داخل همان قفل، پس اتمیک نسبت به رزروهای موازی
            $activeCount = (int)($this->db->fetch(
                "SELECT COUNT(*) as c FROM adtube_views WHERE executor_id = ? AND status IN ('pending','watching')",
                [$executorId]
            )->c ?? 0);
            if ($activeCount >= $maxActive) {
                // ظرفیت پر است → rollback (هیچ رکوردی ساخته نمی‌شود)
                $this->db->rollback();
                return null;
            }

            $this->db->query(
                "INSERT INTO adtube_views (ad_id, executor_id, status, ip_address, user_agent, created_at, updated_at)
                 VALUES (?, ?, 'pending', ?, ?, NOW(), NOW())",
                [
                    $adId, $executorId,
                    $context['ip'] ?? (get_client_ip()),
                    $context['user_agent'] ?? (get_user_agent())
                ]
            );
            $newRecord = $this->db->fetch("SELECT * FROM adtube_views WHERE id = ?", [(int)$this->db->lastInsertId()]);
            $this->db->commit();
            return $newRecord;
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function findById(int $id): ?\stdClass
    {
        return $this->db->fetch("SELECT * FROM adtube_views WHERE id = ?", [$id]);
    }

    public function findByIdWithAd(int $id, int $executorId): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT av.*, a.title as ad_title, a.description as ad_description, a.link as video_link,
                    a.price_per_task as reward_amount, a.currency as reward_currency, a.total_count, a.completed_count
             FROM adtube_views av
             JOIN ads a ON a.id = av.ad_id
             WHERE av.id = ? AND av.executor_id = ?
             LIMIT 1",
            [$id, $executorId]
        );
    }

    /**
     * Start watching (transition from pending to watching).
     */
    public function startWatching(int $executionId): bool
    {
        $stmt = $this->db->query(
            "UPDATE adtube_views SET status = 'watching', started_at = NOW(), updated_at = NOW()
             WHERE id = ? AND status = 'pending'",
            [$executionId]
        );
        return $stmt->rowCount() > 0;
    }

    /**
     * Submit completed watch with metrics.
     */
    public function submitCompleted(int $executionId, int $watchTime, int $progressPercent, float $playbackSpeed): bool
    {
        $stmt = $this->db->query(
            "UPDATE adtube_views
             SET status = 'completed', watch_time = ?, progress_percent = ?, playback_speed = ?,
                 completed_at = NOW(), updated_at = NOW()
             WHERE id = ? AND status IN ('watching','pending')",
            [$watchTime, $progressPercent, $playbackSpeed, $executionId]
        );
        return $stmt->rowCount() > 0;
    }

    /**
     * Mark as rejected (fraud or insufficient watch).
     */
    public function markRejected(int $executionId, string $reason): bool
    {
        $stmt = $this->db->query(
            "UPDATE adtube_views SET status = 'rejected', reject_reason = ?, updated_at = NOW() WHERE id = ?",
            [$reason, $executionId]
        );
        return $stmt->rowCount() > 0;
    }

    /**
     * Executor history (completed/rejected for a user).
     */
    /** @return list<object> */
    public function getHistory(int $executorId, int $limit = 20, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT av.*, a.title as ad_title, a.link as video_link
             FROM adtube_views av
             JOIN ads a ON a.id = av.ad_id
             WHERE av.executor_id = ? AND av.status IN ('completed','rejected')
             ORDER BY av.updated_at DESC
             LIMIT ? OFFSET ?",
            [$executorId, $limit, $offset]
        ) ?: [];
    }

    /**
     * Count active executions for a user (pending or watching).
     */
    public function countActiveForUser(int $executorId): int
    {
        return (int)($this->db->fetch(
            "SELECT COUNT(*) as c FROM adtube_views WHERE executor_id = ? AND status IN ('pending','watching')",
            [$executorId]
        )->c ?? 0);
    }

    /**
     * Count completed executions for a user today.
     */
    public function countCompletedToday(int $executorId): int
    {
        return (int)($this->db->fetch(
            "SELECT COUNT(*) as c FROM adtube_views
             WHERE executor_id = ? AND status = 'completed' AND DATE(completed_at) = CURDATE()",
            [$executorId]
        )->c ?? 0);
    }

    /**
     * 🛡️ FIX-R3-F3: جدیدترین تماشاهای «تکمیل‌شده و پرداخت‌شده» کاربر برای اثباتِ
     * پذیرش پاپ‌آپ بوست هدیه (proof-of-watch). فقط ردیف‌های واقعاً تسویه‌شدهٔ
     * ۲۴ ساعت اخیر با کمپینِ حذف‌نشده برمی‌گردند؛ اثباتِ نهایی (مدت‌زمان واقعی +
     * claim تک‌مصرف) در AdtubeController::acceptBoostPopup انجام می‌شود.
     *
     * @return list<\stdClass> رکوردهای {id, started_at, completed_at} مرتب از جدید به قدیم
     */
    public function getRecentCompletedForBoost(int $executorId, int $limit = 5): array
    {
        return $this->db->fetchAll(
            "SELECT av.id, av.started_at, av.completed_at
             FROM adtube_views av
             JOIN ads a ON a.id = av.ad_id
             WHERE av.executor_id = ? AND av.status = 'completed' AND av.reward_paid = 1
               AND av.completed_at >= (NOW() - INTERVAL 24 HOUR)
               AND a.deleted_at IS NULL
             ORDER BY av.completed_at DESC
             LIMIT ?",
            [$executorId, max(1, $limit)]
        ) ?: [];
    }
}
