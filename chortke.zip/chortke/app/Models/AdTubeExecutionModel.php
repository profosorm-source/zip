<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;
use Core\Database;

/**
 * AdTubeExecutionModel — Execution records for AdTube (video watch) ads.
 * Separate from social_task_executions due to domain-specific metrics (watch_time, progress).
 */
class AdTubeExecutionModel extends Model
{
    protected static string $table = 'adtube_views';

    public function __construct(Database $db) {
        parent::__construct($db);
    }

    /**
     * Find or create a pending execution for user+ad.
     * Returns the existing execution if one is already pending/watching.
     *
     * 🛡️ FIX-R3-F6: برای سازگاری حفظ شد — بدنه به reserveSlot() با سقف نامحدود
     * delegation می‌کند (بدون سقفِ همزمانی؛ سقف ۳تایی در کنترلر با reserveSlot اعمال می‌شود).
     */
    /** @param array<string, mixed> $context */
    public function findOrCreate(int $adId, int $executorId, array $context = []): ?\stdClass
    {
        return $this->reserveSlot($adId, $executorId, $context, PHP_INT_MAX);
    }

    /**
     * 🛡️ FIX-R3-F6 (P2 — R3 Ads/AdTube): رزرو «اسلات تماشای همزمان» داخل یک
     * تراکنش با قفل ردیفی — بستن TOCTOU سقف ۳ تماشای همزمان.
     *
     * الگوی قبلی: countActiveForUser در کنترلر (خارج از هر قفل مشترک) و بعد
     * findOrCreate؛ دو درخواست هم‌زمان برای دو آگهی متفاوت هر دو «۲ از ۳» را
     * می‌دیدند و هر دو INSERT می‌کردند → بیش از ۳ اجرای فعال. اکنون:
     *  ۱) ردیف users این executor با FOR UPDATE قفل می‌شود → رزروهای هم‌زمانِ
     *     همان کاربر سریال می‌شوند (قفل ردیفی موجود، بدون migration جدید)؛
     *  ۲) dedup همان user+ad (قفل FOR UPDATE ردیف فعال) حفظ شد؛
     *  ۳) شمارش فعال‌ها داخل همان تراکنشِ قفل‌دار انجام و در صورت پر بودن
     *     ظرفیت، کل تراکنش rollback می‌شود (هیچ رکوردی ساخته نمی‌شود) و null
     *     برمی‌گردد؛ فقط بعد از موفقیتِ رزرو، رکورد اجرا ساخته می‌شود.
     *
     * @param array<string, mixed> $context
     * @return \stdClass|null رکورد اجرا؛ null یعنی «ظرفیت پر است» (یا خطای دیتابیس خفیف)
     */
    /** @param array<string, mixed> $context */
    public function reserveSlot(int $adId, int $executorId, array $context = [], int $maxActive = 3): ?\stdClass
    {
        try {
            $this->db->beginTransaction();
            // ۱) قفل ردیف کاربر: سریال‌سازی رزرو اسلات برای همین executor
            //    (قفل ردیفیِ کوتاه‌عمر روی کلیدِ از قبل موجود — بدون تغییر اسکیما)
            $this->db->fetch("SELECT id FROM users WHERE id = ? FOR UPDATE", [$executorId]);

            // ۲) dedup همان user+ad — الگوی قبلی (AdTube Mobile Concurrency Lock) حفظ شد
            $existing = $this->db->fetch(
                "SELECT * FROM adtube_views WHERE ad_id = ? AND executor_id = ? AND status IN ('pending','watching') LIMIT 1 FOR UPDATE",
                [$adId, $executorId]
            );
            if ($existing) {
                $this->db->commit();
                return $existing;
            }

            // ۳) سقف همزمانی — داخل همان قفل، پس اتمیک نسبت به رزروهای موازی
            $activeCount = (int)($this->db->fetch(
                "SELECT COUNT(*) as c FROM adtube_views WHERE executor_id = ? AND status IN ('pending','watching')",
                [$executorId]
            )->c ?? 0);
            if ($activeCount >= $maxActive) {
                // ظرفیت پر است → rollback (هیچ رکوردی ساخته نمی‌شود)
                $this->db->rollback();
                return null;
            }

            $this->db->query(
                "INSERT INTO adtube_views (ad_id, executor_id, status, video_duration, ip_address, user_agent, created_at, updated_at)
                 VALUES (?, ?, 'pending',
                    COALESCE(CAST(JSON_EXTRACT((SELECT metadata FROM ads WHERE id = ?), '$.\"video_duration_seconds\"') AS UNSIGNED), 0),
                    ?, ?, NOW(), NOW())",
                [
                    $adId, $executorId, $adId,
                    $context['ip'] ?? (get_client_ip()),
                    $context['user_agent'] ?? (get_user_agent())
                ]
            );
            $newRecord = $this->db->fetch("SELECT * FROM adtube_views WHERE id = ?", [(int)$this->db->lastInsertId()]);
            $this->db->commit();
            return $newRecord;
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    /**
     * 🛡️ FIX-YT-2 (تصمیم ۱-گزینه A): طول کول‌داون شبه‌تصادفی بازهٔ [min,max] ساعت
     * (پیش‌فرض ۲۴–۷۲ از تنظیمات ادمین؛ FIX-YT-8) — تابع قطعی (deterministic) از
     * (ad, executor, execution)؛ در SQL هم با همان فرمول CRC32 محاسبه می‌شود
     * (فیلتر لیست Ads::getAvailableCustomTasks) تا همیشه هم‌نتیجه است.
     */
    public function cooldownHours(int $adId, int $executorId, int $executionId): int
    {
        [$minH, $maxH] = self::cooldownBounds();
        $span = max(1, $maxH - $minH + 1);
        return $minH + (int)(crc32($adId . ':' . $executorId . ':' . $executionId) % $span);
    }

    /** 🛡️ FIX-YT-8: بازهٔ کول‌داون از تنظیمات ادمین (پیش‌فرض ۲۴–۷۲ ساعت) — منبع واحد برای PHP و SQL */
    /** @return array{0: int, 1: int} */
    public static function cooldownBounds(): array
    {
        $minH = max(1, int_value(setting('adtube_cooldown_min_hours', 24)));
        $maxH = max(1, int_value(setting('adtube_cooldown_max_hours', 72)));
        if ($minH > $maxH) { [$minH, $maxH] = [$maxH, $minH]; }
        return [$minH, $maxH];
    }

    /**
     * 🛡️ FIX-YT-2: آخرین اجرای قطعی‌شده (completed/rejected) کاربر برای یک کمپین —
     * مبنای گارد کول‌داون در start().
     */
    public function findLastSettledForAd(int $adId, int $executorId): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT * FROM adtube_views
             WHERE ad_id = ? AND executor_id = ? AND status IN ('completed','rejected')
             ORDER BY COALESCE(completed_at, updated_at) DESC LIMIT 1",
            [$adId, $executorId]
        );
    }

    /**
     * 🛡️ FIX-R1-5: «همهٔ» اجراهای قطعی‌شده (completed/rejected) کاربر برای یک کمپین —
     * گارد start() باید دقیقاً هم‌قرارداد فیلتر لیست باشد (هر ردیفی که کول‌داونش فعال است).
     *
     * @return list<\stdClass>
     */
    public function fetchAllSettledForAd(int $adId, int $executorId): array
    {
        return $this->db->fetchAll(
            "SELECT id, completed_at, updated_at FROM adtube_views
             WHERE ad_id = ? AND executor_id = ? AND status IN ('completed','rejected')
             ORDER BY COALESCE(completed_at, updated_at) DESC",
            [$adId, $executorId]
        ) ?: [];
    }

    /**
     * 🛡️ FIX-YT-2: ممنوعیت مطلق تماشای تکراری — آیا کاربر این کمپین را قبلاً کامل تماشا کرده؟
     */
    public function hasCompletedForAd(int $adId, int $executorId): bool
    {
        $row = $this->db->fetch(
            "SELECT id FROM adtube_views
             WHERE ad_id = ? AND executor_id = ? AND status = 'completed' AND reward_paid = 1
             LIMIT 1",
            [$adId, $executorId]
        );
        return $row !== null;
    }

    public function findById(int $id): ?\stdClass
    {
        return $this->db->fetch("SELECT * FROM adtube_views WHERE id = ?", [$id]);
    }

    public function findByIdWithAd(int $id, int $executorId): ?\stdClass
    {
        return $this->db->fetch(
            "SELECT av.*, a.title as ad_title, a.description as ad_description, a.link as video_link,
                    a.price_per_task as reward_amount, a.currency as reward_currency, a.total_count, a.completed_count
             FROM adtube_views av
             JOIN ads a ON a.id = av.ad_id
             WHERE av.id = ? AND av.executor_id = ?
             LIMIT 1",
            [$id, $executorId]
        );
    }

    /**
     * Start watching (transition from pending to watching).
     */
    public function startWatching(int $executionId): bool
    {
        $stmt = $this->db->query(
            "UPDATE adtube_views SET status = 'watching', started_at = NOW(), updated_at = NOW()
             WHERE id = ? AND status = 'pending'",
            [$executionId]
        );
        return $stmt->rowCount() > 0;
    }

    /**
     * Submit completed watch with metrics.
     */
    public function submitCompleted(int $executionId, int $watchTime, int $progressPercent, float $playbackSpeed): bool
    {
        $stmt = $this->db->query(
            "UPDATE adtube_views
             SET status = 'completed', watch_time = ?, progress_percent = ?, playback_speed = ?,
                 completed_at = NOW(), updated_at = NOW()
             WHERE id = ? AND status IN ('watching','pending')",
            [$watchTime, $progressPercent, $playbackSpeed, $executionId]
        );
        return $stmt->rowCount() > 0;
    }

    /**
     * Mark as rejected (fraud or insufficient watch).
     */
    public function markRejected(int $executionId, string $reason): bool
    {
        $stmt = $this->db->query(
            "UPDATE adtube_views SET status = 'rejected', reject_reason = ?, updated_at = NOW() WHERE id = ?",
            [$reason, $executionId]
        );
        return $stmt->rowCount() > 0;
    }

    /**
     * Executor history (completed/rejected for a user).
     */
    /** @return list<object> */
    public function getHistory(int $executorId, int $limit = 20, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT av.*, a.title as ad_title, a.link as video_link
             FROM adtube_views av
             JOIN ads a ON a.id = av.ad_id
             WHERE av.executor_id = ? AND av.status IN ('completed','rejected')
             ORDER BY av.updated_at DESC
             LIMIT ? OFFSET ?",
            [$executorId, $limit, $offset]
        ) ?: [];
    }

    /**
     * Count active executions for a user (pending or watching).
     */
    public function countActiveForUser(int $executorId): int
    {
        return (int)($this->db->fetch(
            "SELECT COUNT(*) as c FROM adtube_views WHERE executor_id = ? AND status IN ('pending','watching')",
            [$executorId]
        )->c ?? 0);
    }

    /**
     * Count completed executions for a user today.
     */
    public function countCompletedToday(int $executorId): int
    {
        return (int)($this->db->fetch(
            "SELECT COUNT(*) as c FROM adtube_views
             WHERE executor_id = ? AND status = 'completed' AND DATE(completed_at) = CURDATE()",
            [$executorId]
        )->c ?? 0);
    }

    /**
     * FIX-S20-F3 (بازبینی بخش ۲۰): درآمد امروز اجراکننده به تفکیک ارز — قبلاً
     * hubData مقدار ثابت ۰ با label ثابت «تومان» می‌فرستاد؛ حالا جمع واقعیِ
     * reward_amount تماشاهای تکمیل‌شدهٔ امروز، GROUP BY ارز پاداش. هم‌قرارداد
     * countCompletedToday (status='completed' + DATE(completed_at)=CURDATE())
     * تا عدد «ویدیوهای امروز» و «درآمد امروز» همیشه از یک جامعهٔ آماری بیایند.
     * @return array<string, string> ارز => جمع decimal-string ('irt'|'usdt')
     */
    public function getEarningsTodayByCurrency(int $executorId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT COALESCE(NULLIF(LOWER(TRIM(reward_currency)), ''), 'irt') AS currency,
                    COALESCE(SUM(reward_amount), 0) AS total
             FROM adtube_views
             WHERE executor_id = ? AND status = 'completed' AND DATE(completed_at) = CURDATE()
             GROUP BY COALESCE(NULLIF(LOWER(TRIM(reward_currency)), ''), 'irt')",
            [$executorId]
        ) ?: [];
        $out = [];
        foreach ($rows as $row) {
            $cur = strtolower((string)($row->currency ?? 'irt'));
            if ($cur !== 'usdt') {
                $cur = 'irt';
            }
            $total = $row->total ?? 0;
            $out[$cur] = (is_scalar($total) && is_numeric((string)$total)) ? (string)$total : '0';
        }
        return $out;
    }
}
