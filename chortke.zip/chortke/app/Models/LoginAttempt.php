<?php

declare(strict_types=1);

namespace App\Models;

use Core\Model;

class LoginAttempt extends Model
{
    protected static string $table = 'login_attempts';

    // Tracks ip_address for security monitoring
}
