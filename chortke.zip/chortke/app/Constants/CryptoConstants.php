<?php

namespace App\Constants;

/**
 * FIX-C100..C103 (یافته‌های ممیزی ۱۰۰-۱۰۳): منبع واحد ثابت‌های کریپتو.
 *
 * قبلاً پیش‌فرض‌های تأییدِ شبکه‌ها در چهار جای جدا پراکنده بود و از هم فاصله داشتند:
 *   - CryptoApiAdapter (TRC20: لیترال 19 در دو مسیر، BNB20-fallback RPC: لیترال 12!)
 *   - SettingsCatalog (crypto_min_confirmations_trc20=19 / bnb20=15)
 *   - همین کلاس (DEFAULT_MIN_CONFIRMATIONS_*)
 * نتیجه: مسیر fallback EVM-RPC (وقتی اکسپلورر down است) واریز BNB20 را با ۱۲ تأیید
 * تأیید می‌کرد در حالی که سیاست تنظیمی ۱۵ بود — یعنی policy drift بین دو مسیرِ
 * تأیید همان شبکه. اکنون همهٔ مسیرها از MIN_CONFIRMATIONS (نقشهٔ per-network)
 * تغذیه می‌شوند و هر مقدارِ خوانده‌شده از تنظیمات با clampedMinConfirmations()
 * به بازهٔ امن محدود می‌شود (C101: بدون validation، مقدار 0/منفی واریز را
 * بی‌تأیید تأیید می‌کرد و مقدار نجومی انقضا را می‌بست).
 */
final class CryptoConstants
{
    /** پیش‌فرض تأیید TRC20 (TronGrid + مسیر block URL) — هم‌تراز SettingsCatalog */
    public const DEFAULT_MIN_CONFIRMATIONS_TRC20 = 19;
    /** پیش‌فرض تأیید BNB20 (اکسپلورر و fallback EVM-RPC — قبلاً fallback لیترال 12 داشت) */
    public const DEFAULT_MIN_CONFIRMATIONS_BNB20 = 15;
    /** گیت تأیید TON بر مبنای سنِ tx (۰ = گیت خاموش، opt-in) */
    public const DEFAULT_MIN_CONFIRMATIONS_TON = 0;
    /** پیش‌فرض تأیید SOL (32 = finalized) */
    public const DEFAULT_MIN_CONFIRMATIONS_SOL = 32;

    /** FIX-C103: نقشهٔ واحد per-network — تک‌منبعِ حقیقت برای همهٔ مسیرهای وریفای */
    public const MIN_CONFIRMATIONS = [
        'trc20' => self::DEFAULT_MIN_CONFIRMATIONS_TRC20,
        'bnb20' => self::DEFAULT_MIN_CONFIRMATIONS_BNB20,
        'ton'   => self::DEFAULT_MIN_CONFIRMATIONS_TON,
        'sol'   => self::DEFAULT_MIN_CONFIRMATIONS_SOL,
    ];

    /** کلید تنظیم per-network برای appSettings */
    public const CONFIRMATION_SETTING_KEYS = [
        'trc20' => 'crypto_min_confirmations_trc20',
        'bnb20' => 'crypto_min_confirmations_bnb20',
        'ton'   => 'crypto_min_confirmations_ton',
        'sol'   => 'crypto_min_confirmations_sol',
    ];

    /** سقف امن تأییدها (جلوگیری از مقدار نجومی تنظیمی که واریزها را برای همیشه pending نگه می‌دارد) */
    public const MAX_MIN_CONFIRMATIONS = 200;
    /** کف تأیید برای شبکه‌های تأیید-دار (0 فقط برای TON که گیتش opt-in است) */
    public const MIN_ALLOWED_CONFIRMATIONS = 0;

    /** FIX-C101 (یافتهٔ ۱۰۱): بازهٔ مجاز انقضای intent — 5 دقیقه تا 24 ساعت */
    public const INTENT_EXPIRE_MIN_MINUTES = 5;
    public const INTENT_EXPIRE_MAX_MINUTES = 1440;
    public const DEFAULT_INTENT_EXPIRE_MINUTES = 30;

    /** FIX-C102 (یافتهٔ ۱۰۲): این ثابت در generateUniqueAmount مصرف می‌شود —
     *  قبلاً مرده بود و دقت 8 به‌صورت لیترال '100000000' تکرار می‌شد (تصور امنیت کاذب). */
    public const MAX_UNIQUE_AMOUNT_DECIMALS = 8;
    public const MAX_UNIQUE_AMOUNT_ATTEMPTS = 30;

    /**
     * FIX-C101/C103: خواندن و اعتبارسنجی مقدار تأییدِ هر شبکه از تنظیمات.
     * مقدار تنظیمی نامعتبر (غیرعددی، منفی، فراتر از سقف) به پیش‌فرض کانونیک
     * شبکه برمی‌گردد و همیشه لاگ‌پذیر است — رفتار مسیرها دیگر به محل فراخوانی
     * وابسته نیست.
     */
    public static function resolveMinConfirmations(string $network, ?int $configured, &$wasInvalid = null): int
    {
        $default = self::MIN_CONFIRMATIONS[$network] ?? self::DEFAULT_MIN_CONFIRMATIONS_TRC20;
        $wasInvalid = false;
        if ($configured === null || $configured < self::MIN_ALLOWED_CONFIRMATIONS || $configured > self::MAX_MIN_CONFIRMATIONS) {
            $wasInvalid = true;
            return $default;
        }
        return $configured;
    }

    /** FIX-C101: محدودسازی انقضای intent به بازهٔ امن؛ نامعتبر ⇒ پیش‌فرض کانونیک */
    public static function clampIntentExpireMinutes(int $minutes, &$wasInvalid = null): int
    {
        $wasInvalid = ($minutes < self::INTENT_EXPIRE_MIN_MINUTES || $minutes > self::INTENT_EXPIRE_MAX_MINUTES);
        if ($minutes < self::INTENT_EXPIRE_MIN_MINUTES || $minutes > self::INTENT_EXPIRE_MAX_MINUTES) {
            return self::DEFAULT_INTENT_EXPIRE_MINUTES;
        }
        return $minutes;
    }
}
