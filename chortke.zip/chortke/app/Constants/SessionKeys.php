<?php

declare(strict_types=1);

namespace App\Constants;

/**
 * SessionKeys
 *
 * کلیدهای ثابت برای مدیریت نشست‌ها (Session) در سراسر اپلیکیشن.
 * جهت جلوگیری از خطاهای تایپی و ناهماهنگی بین کنترلرها.
 *
 * ═══════════════════════════════════════════════════════════════
 * FIX-C98 (یافتهٔ ۹۸): سیاست namespace و ممنوعیت کلید جادویی
 * ═══════════════════════════════════════════════════════════════
 *  - هر کلید نشست/کشِ نشستِ جدید «باید» از این کلاس تعریف و مصرف شود؛
 *    کلید جادویی رشته‌ای (set('...')) در code review ممنوع است.
 *  - پیشوند namespace کلیدهای جدید: خود NS (پیش‌فرض 'ck.') تا در یک
 *    Redis session store مشترک با اپ دیگر، برخورد نام‌ها بی‌صدا رخ ندهد.
 *  - مقادیر Legacy (بدون پیشوند) عمداً دست‌نخورده مانده‌اند: تغییر مقدار
 *    = بی‌اعتبارشدن یک‌بارهٔ همهٔ نشست‌های زنده (logout جمعی). مهاجرت به
 *    NS باید در پنجرهٔ نگهداری با sweep یک‌جای همهٔ سایت‌های read/write
 *    انجام شود (سند: docs/OPEN-ITEMS-POST-REPORT-2026-08-24-fa.md).
 *
 * FIX-C96 (یافتهٔ ۹۶): سیمانتیک هر کلید (TTL / یک‌بارمصرف) در docblock
 * خودِ ثابت مستند شده است — کلید یک‌بارمصرف باید با Session::once()
 * خوانده شود (get+remove اتمیکِ معنایی) یا بلافاصله remove گردد.
 */
class SessionKeys
{
    /** پیشوند namespace کلیدهای جدید (FIX-C98) */
    public const NS = 'ck.';

    // ── Identity (Legacy namespace — مهاجرت برنامه‌ریزی‌شده) ──────────
    /** TTL: عمر نشست (session lifetime)؛ حذف در logout. کلید هویتی. */
    public const USER_ID = 'user_id';
    /** TTL: عمر نشست؛ مقدار نقشِ لحظهٔ ورود — بعد از تغییر نقش باید refresh شود. */
    public const USER_ROLE = 'user_role';
    /** TTL: عمر نشست؛ فلگ ورود موفق. */
    public const LOGGED_IN = 'logged_in';
    /** TTL: عمر نشست؛ نمایشی. */
    public const USERNAME = 'username';
    /** TTL: عمر نشست؛ فلگ ادمین — باید با USER_ROLE هم‌خوان بماند. */
    public const IS_ADMIN = 'is_admin';
    /** TTL: عمر نشست. */
    public const USER_EMAIL = 'user_email';

    // ── 2FA pending family (شامل docblock TTL در هر ثابت — FIX-C96) ────
    /**
     * TTL: ۶۰۰ ثانیه (پنجرهٔ pending 2FA با pending_2fa_created_at سنجیده می‌شود؛
     * انقضا = destroy نشست). یک‌بارمصرف: در finalizeSessionAfter2FA حذف می‌شود.
     */
    public const PENDING_2FA_USER_ID = 'pending_2fa_user_id';
    /** TTL: هم‌زمان PENDING_2FA_USER_ID (۶۰۰ ثانیه)؛ زمان‌سنج انقضای pending. */
    public const PENDING_2FA_CREATED_AT = 'pending_2fa_created_at';
    /** TTL: هم‌زمان PENDING_2FA_USER_ID؛ مقیدشدن pending به IP وروددهنده. */
    public const PENDING_2FA_IP = 'pending_2fa_ip';
    /** TTL: هم‌زمان PENDING_2FA_USER_ID؛ حافظهٔ «مرا به خاطر بسپار». */
    public const PENDING_2FA_REMEMBER = 'pending_2fa_remember';

    // ── Admin 2FA pending family ────────────────────────────────────────
    /**
     * TTL: پنجرهٔ ۲FA ادمین (سنجش با ADMIN_PENDING_2FA_CREATED)؛
     * یک‌بارمصرف: در تکمیل/انقضای ۲FA ادمین حذف می‌شود.
     */
    public const ADMIN_PENDING_2FA = 'admin_pending_2fa';
    /** TTL: هم‌زمان ADMIN_PENDING_2FA (پنجرهٔ ادمین)؛ زمان‌سنج انقضا. */
    public const ADMIN_PENDING_2FA_CREATED = 'admin_pending_2fa_created';
    /** TTL: هم‌زمان ADMIN_PENDING_2FA؛ مقیدشدن pending به IP. */
    public const ADMIN_PENDING_2FA_IP = 'admin_pending_2fa_ip';

    // ── Security/OAuth ─────────────────────────────────────────────────
    /** TTL: کوتاه‌عمر (per-response)؛ nonce امنیت محتوایی. */
    public const CSP_NONCE = 'csp_nonce';
    /**
     * TTL: پنجرهٔ state OAuth (created_at امضاشده داخل خود state + binding
     * session/IP). یک‌بارمصرف: بلافاصله پس از خواندن حذف می‌شود (Once).
     */
    public const OAUTH_STATE = 'oauth_state';
    /**
     * FIX-C98: کلید مشتق‌شدهٔ ضد-دوباره‌مصرفِ state (پیش‌تر رشتهٔ جادویی
     * OAUTH_STATE . '_used' بود). یک‌بارمصرف: پس از مصرف state حذف می‌شود.
     */
    public const OAUTH_STATE_USED = 'oauth_state_used';
    /**
     * FIX-C96: کلید linking حساب OAuth — قبلاً بدون هیچ TTL نوشته/خوانده
     * می‌شد (نیتِ linking در نشست‌های طولانی تا ابد می‌ماند). اکنون payload
     * شامل expires_at است و خوانندهٔ آن را می‌سنجد (OAuthService/OAuthHelperTrait).
     * یک‌بارمصرف: get+remove در callback.
     */
    public const OAUTH_LINKING_USER_ID = 'oauth_linking_user_id';
    /** پنجرهٔ مجاز linking (ثانیه) — مصرف در OAuthService/OAuthHelperTrait */
    public const OAUTH_LINKING_TTL = 600;

    // ── 2FA Setup ───────────────────────────────────────────────────────
    /**
     * TTL: ۶۰۰ ثانیه (time() در مقدار ذخیره می‌شود و کنترلر سنجیده می‌کند).
     * یک‌بارمصرف: در هر مصرف (انقضا/تکمیل enable/disable) حذف می‌شود.
     */
    public const TWO_FACTOR_SETUP_AUTHORIZED = '2fa_setup_authorized';

    // ── Session activity metadata (Legacy namespace) ────────────────────
    /** TTL: عمر نشست؛ به‌روزرسانی لغزان در هر فعالیت (RedisSessionHandler). */
    public const LAST_ACTIVITY = 'last_activity';
    /** TTL: عمر نشست؛ IP لحظهٔ ورود (تشخیص session hijack). */
    public const LOGIN_IP = 'login_ip';
    /** TTL: عمر نشست؛ زمان لحظهٔ ورود. */
    public const LOGIN_TIME = 'login_time';
    /** TTL: پنجرهٔ re-auth حساس (سنجش با time()). */
    public const USER_VERIFY_TIME = 'user_verify_time';
    /** TTL: عمر نشست؛ آخرین احراز هویت کامل. */
    public const LAST_AUTH_TIME = 'last_auth_time';
    /** TTL: عمر نشست؛ فلگ عبور موفق چالش 2FA در نشست جاری. */
    public const TWO_FACTOR_VERIFIED = '2fa_verified';
}
