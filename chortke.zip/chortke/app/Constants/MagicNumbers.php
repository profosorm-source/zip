<?php

declare(strict_types=1);

namespace App\Constants;

/**
 * MagicNumbers - تمام Magic Numbers کو Constants میں تبدیل کریں
 *
 * یہ فائل تمام hard-coded numbers کو centralize کرتی ہے
 * تاکہ کوڈ maintainable اور readable رہے
 *
 * 🛡️ FIX-S20-DEADFILE (روش کارفرما: تحقیق → حذف مستدل):
 * ۸ کلاسِ بی‌استفادهٔ این فایل (TrustScoreConstants، RateLimitConstants،
 * TaskScoringConstants، PaginationConstants، RedisConstants، PaymentConstants،
 * ValidationConstants، FeatureConstants) حذف شدند — تنها مصرف‌شان تستِ
 * tautological بود و مقادیرشان نسبت به مسیر واقعی production دریفت خورده بود
 * (نمونه: LOGIN_DECAY_MINUTES=60 در برابر TTL واقعی ۹۰۰ ثانیه در AuthService؛
 * TrustScoreConstants::MINIMUM=0 در برابر کف واقعی ‎-50.0 در TrustService).
 * پذیرش این ثابت‌ها بدون تغییر رفتار ممکن نبود و هر تغییر رفتاری خارج از
 * دامنهٔ این بچ است. سه کلاسِ زنده (TimeConstants، PercentageConstants،
 * SystemConstants) که مصرف production واقعی دارند حفظ شدند.
 */
class TimeConstants
{
    // ⏱️ وقت کی constants (seconds میں)
    public const SECONDS_PER_MINUTE = 60;
    public const SECONDS_PER_HOUR = 3600;
    public const SECONDS_PER_DAY = 86400;
    public const SECONDS_PER_WEEK = 604800;
    public const SECONDS_PER_MONTH = 2592000;  // 30 days
    public const SECONDS_PER_YEAR = 31536000;  // 365 days

    // ⏱️ منٹوں میں
    public const MINUTES_PER_HOUR = 60;
    public const MINUTES_PER_DAY = 1440;
    public const MINUTES_PER_WEEK = 10080;

    // ⏱️ Decay durations (rate limiting)
    public const DECAY_MINUTES_STANDARD = 60;
    public const DECAY_MINUTES_SHORT = 10;
    public const DECAY_MINUTES_LONG = 120;

    // ⏱️ Timeouts (seconds)
    public const CURL_TIMEOUT_STANDARD = 30;
    public const CURL_TIMEOUT_CONNECT = 10;
    public const CURL_TIMEOUT_SHORT = 5;
    public const CURL_TIMEOUT_LONG = 60;
}

class PercentageConstants
{
    // 💯 Fee percentages
    public const AD_TUBE_FEE_PERCENT = 20;
    public const BANNER_FEE_PERCENT = 12;
    public const SOCIAL_TASK_FEE_PERCENT = 15;
    public const DEFAULT_FEE_PERCENT = 15;

    // 💯 Quality thresholds (in percentages)
    public const QUALITY_EXCELLENT = 90;
    public const QUALITY_GOOD = 75;
    public const QUALITY_AVERAGE = 50;
    public const QUALITY_POOR = 25;
}

class SystemConstants
{
    // 💾 Storage sizes (bytes)
    public const GB_100 = 107374182400;    // 100GB
    public const GB_40 = 42949672960;      // 40GB
    public const GB_16 = 17179869184;      // 16GB
    public const GB_8 = 8589934592;        // 8GB
    public const GB_1 = 1073741824;        // 1GB
    public const MB_1 = 1048576;           // 1MB

    // 📊 Default system values
    public const DEFAULT_DISK_TOTAL = 107374182400;    // 100GB
    public const DEFAULT_DISK_FREE = 42949672960;      // 40GB
    public const DEFAULT_MEMORY_TOTAL = 17179869184;   // 16GB
    public const DEFAULT_MEMORY_FREE = 8589934592;     // 8GB

    // ⏱️ System monitoring
    public const UPTIME_FORMAT_DAYS = 'روز';
    public const UPTIME_FORMAT_HOURS = 'ساعت';
}
