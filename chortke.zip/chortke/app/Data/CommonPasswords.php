<?php

namespace App\Data;

use Core\Cache;

/**
 * Common Passwords Database - بهبود یافته
 * 
 * لیست گسترده‌تر پسوردهای رایج برای جلوگیری از استفاده
 * منبع: OWASP, Have I Been Pwned Top 1000
 * 
 * بهبود‌ها:
 * 1. Cache normalized = بدون تکرار array_map
 * 2. Bloom Filter option = بسیار سریع
 */
class CommonPasswords
{
    /** @var array<string, true>|null */
    private static ?array $normalizedCache = null;
    
    /**
     * لیست ۱۰۰ پسورد پرتکرار
     * در production باید از یک دیتابیس ۱۰۰۰۰+ تایی استفاده شود
     *
     * @var list<string>
     */
    private static array $passwords = [
        // Top 20 Most Common
        '123456', 'password', '12345678', 'qwerty', '123456789',
        '12345', '1234', '111111', '1234567', 'dragon',
        '123123', 'baseball', 'iloveyou', 'trustno1', '1234567890',
        'sunshine', 'master', 'welcome', 'shadow', 'ashley',
        
        // Common Patterns
        'football', 'jesus', 'monkey', 'ninja', 'mustang',
        'password1', 'password123', 'Password1', 'Password123', 'password!',
        'qwerty123', 'qwertyuiop', 'abc123', 'admin', 'administrator',
        'letmein', 'login', 'passw0rd', 'access', 'secret',
        
        // Persian Common
        '123456789', 'چیزی', 'رمزعبور', 'پسورد', 'admin123',
        
        // Sequential & Keyboard Patterns
        'qazwsx', 'zxcvbnm', 'asdfgh', 'qweasd', '1qaz2wsx',
        '1q2w3e4r', 'qwe123', 'asd123', 'zxc123', 'zaq12wsx',
        
        // Names (Popular)
        'mohammad', 'ali', 'hassan', 'hussein', 'fatima',
        'zahra', 'sara', 'maryam', 'mehdi', 'reza',
        
        // Years & Dates
        '2020', '2021', '2022', '2023', '2024', '2025',
        '1990', '1991', '1992', '1993', '1994', '1995',
        '1980', '1985', '2000', '2010',
        
        // Common Words
        'welcome123', 'admin123', 'user123', 'test123', 'demo123',
        'root', 'toor', 'pass', 'guest', 'user',
        
        // Simple Combinations
        'a1b2c3', '1a2b3c', 'aa123456', 'aaa123', 'aaaa1111',
        '11111111', '00000000', '99999999', '88888888', '12341234',
        
        // Sports & Teams
        'manchester', 'chelsea', 'arsenal', 'liverpool', 'barcelona',
        'realmadrid', 'persepolis', 'esteghlal', 'barcelona',
        
        // Technology
        'windows', 'linux', 'ubuntu', 'android', 'samsung',
        'iphone', 'google', 'facebook', 'instagram', 'twitter',
    ];
    
    /**
     * ✅ بهبور #1: دریافت لیست normalized (یک بار cache می‌شود)
     * بدون تکرار array_map هر بار
     */
    /** @return array<string, true> */
    private static function getNormalizedPasswords(): array
    {
        // In-memory cache
        if (self::$normalizedCache !== null) {
            return self::$normalizedCache;
        }
        
        // خیلی سریع - O(1) lookup
        $normalized = array_map('strtolower', self::$passwords);
        self::$normalizedCache = array_combine($normalized, array_fill(0, count($normalized), true));
        
        return self::$normalizedCache;
    }
    
    /**
     * بررسی اینکه پسورد در لیست رایج هست یا نه
     */
    public static function isCommon(string $password): bool
    {
        $lower = strtolower((string)$password);
        
        // ✅ بهبور: O(1) lookup instead of array_map + in_array
        $normalized = self::getNormalizedPasswords();
        if (isset($normalized[$lower])) {
            return true;
        }
        
        // بررسی الگوهای عددی ساده
        if (self::isSimpleNumericPattern($lower)) {
            return true;
        }
        
        // بررسی الگوهای کیبوردی
        if (self::isKeyboardPattern($lower)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Bloom Filter (اختیاری) — ابزار کمکی نگه‌داشته‌شده به تصمیم کاربر (C-S20-7)
     *
     * FIX-S20-C7: قرارداد اصلاح شد — فیلتر بلوم فقط «پیش‌فیلتر» است؛ خروجی منفی
     * یعنی قطعاً در لیست نیست (بررسی الگوها جداگانه اجرا می‌شود) و خروجی مثبت
     * (که می‌تواند false-positive باشد) با isCommon() دقیق تأیید می‌شود.
     * بنابراین معناشناسی این متد دقیقاً برابر isCommon() است، با fast-path سرعت.
     */
    public static function isCommonBloomFilter(string $password): bool
    {
        $cache = self::getCache();
        if (!$cache) {
            return self::isCommon($password);
        }

        // Bloom filter stored in Redis
        $bloom = $cache->get('bloom:common_passwords');
        if (!is_string($bloom)) {
            // یک بار ساخت و cache
            $bloom = self::buildBloomFilter(self::$passwords);
            $cache->set('bloom:common_passwords', $bloom, 604800); // 7 days
        }

        $lower = strtolower((string)$password);
        if (!self::checkBloomFilter($bloom, $lower)) {
            // قطعاً در لیست نیست — اما الگوهای عددی/کیبوردی مستقل از لیست‌اند
            return self::isSimpleNumericPattern($lower) || self::isKeyboardPattern($lower);
        }

        // مثبت بلوم (احتمال false-positive) → تأیید دقیق
        return self::isCommon($password);
    }

    /**
     * ساخت Bloom Filter
     *
     * @param list<string> $passwords
     */
    private static function buildBloomFilter(array $passwords): string
    {
        $size = 1024 * 512; // 512KB
        $bits = str_split(str_repeat("\x00", $size));
        
        foreach ($passwords as $password) {
            for ($i = 0; $i < 7; $i++) {
                $hash = crc32($password . $i);
                $index = abs($hash) % ($size * 8);
                $byteIndex = intdiv($index, 8);
                $bitIndex = $index % 8;
                
                // تبدیل به int، set bit، دوباره به chr
                $byte = ord($bits[$byteIndex]);
                $byte |= (1 << $bitIndex);
                $bits[$byteIndex] = chr($byte);
            }
        }
        
        return base64_encode(implode('', $bits));
    }
    
    /**
     * دریافت Cache instance
     */
    private static function getCache(): ?\Core\Cache
    {
        try {
            $cache = cache();
            if ($cache instanceof \Core\Cache) {
                return $cache;
            }
            return null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * بررسی در Bloom Filter
     *
     * FIX-S20-C7 (رفع باگ): خواندن بایت با cast (int) انجام می‌شد که برای هر
     * رشتهٔ غیرعددی همیشه 0 می‌دهد — بیت اشتباه خوانده می‌شد و فیلتر عملاً
     * برای تقریباً هر ورودی «ناموجود» برمی‌گشت. قرارداد صحیح: ord().
     */
    private static function checkBloomFilter(string $bloom, string $password): bool
    {
        $bits = base64_decode($bloom);
        $size = strlen((string)$bits);

        for ($i = 0; $i < 7; $i++) {
            $hash = crc32($password . $i);
            $index = abs($hash) % ($size * 8);
            $byteIndex = intdiv($index, 8);
            $bitIndex = $index % 8;

            if (!((ord((string)$bits[$byteIndex]) >> $bitIndex) & 1)) {
                return false;
            }
        }

        return true;
    }

    /**
     * بررسی الگوهای عددی ساده
     */
    private static function isSimpleNumericPattern(string $password): bool
    {
        // فقط عدد
        if (preg_match('/^\d+$/', $password)) {
            $length = strlen((string)$password);

            // تکرار یک رقم
            if (preg_match('/^(\d)\1+$/', $password)) {
                return true;
            }

            // الگوی صعودی: 12345678
            if ($length >= 6) {
                $isAscending = true;
                for ($i = 1; $i < $length; $i++) {
                    if ((int)$password[$i] !== ((int)$password[$i-1] + 1) % 10) {
                        $isAscending = false;
                        break;
                    }
                }
                if ($isAscending) return true;
            }

            // الگوی نزولی: 87654321
            if ($length >= 6) {
                $isDescending = true;
                for ($i = 1; $i < $length; $i++) {
                    if ((int)$password[$i] !== ((int)$password[$i-1] - 1 + 10) % 10) {
                        $isDescending = false;
                        break;
                    }
                }
                if ($isDescending) return true;
            }
        }

        return false;
    }

    /**
     * بررسی الگوهای کیبوردی
     */
    private static function isKeyboardPattern(string $password): bool
    {
        /** @var list<string> $keyboardPatterns */
        $keyboardPatterns = [
            'qwertyuiop', 'asdfghjkl', 'zxcvbnm',
            'qazwsxedc', '1qaz2wsx', 'qweasdzxc',
            'qweasd', 'asdzxc', 'zxcasd',
        ];
        
        $password = strtolower((string)$password);
        
        foreach ($keyboardPatterns as $pattern) {
            if (strpos($password, $pattern) !== false) {
                return true;
            }
            // معکوس الگو
            if (strpos($password, strrev($pattern)) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * دریافت تعداد کل پسوردهای رایج
     */
    public static function count(): int
    {
        return count(self::$passwords);
    }
    
    /**
     * بررسی performance
     *
     * @return array<string, string>
     */
    public static function benchmarkMethods(string $testPassword): array
    {
        $results = [];
        
        foreach ([
            'Array (Cached)' => fn() => self::isCommon($testPassword),
            'Bloom Filter' => fn() => self::isCommonBloomFilter($testPassword),
        ] as $method => $callback) {
            $start = microtime(true);
            for ($i = 0; $i < 10000; $i++) {
                $callback();
            }
            $time = (microtime(true) - $start) * 1000;
            $results[$method] = round($time, 2) . 'ms';
        }
        
        return $results;
    }
    
    /**
     * پیشنهاد پسورد امن
     */
    public static function suggest(): string
    {
        $words = ['Sun', 'Moon', 'Star', 'Cloud', 'Rain', 'Storm', 'Thunder', 
                  'Sky', 'Ocean', 'River', 'Mountain', 'Forest', 'Desert'];
        $symbols = ['!', '@', '#', '$', '%', '&', '*'];
        
        $word1 = $words[array_rand($words)];
        $word2 = $words[array_rand($words)];
        $num = random_int(10, 99);
        $symbol = $symbols[array_rand($symbols)];
        
        return $word1 . $num . $word2 . $symbol;
    }
    
    /**
     * ابزار setup (نگه‌داشته‌شده به تصمیم کاربر — C-S20-7)
     *
     * FIX-S20-C7: به‌جای echo مستقیم (که در زمینهٔ وب خروجی را خراب می‌کند)،
     * وضعیت به‌صورت آرایه برمی‌گردد و چاپ فقط در CLI انجام می‌شود.
     *
     * @return array<string,string> وضعیت (cached/size/usage) برای مصرف CLI
     */
    public static function setupBloomFilterInCache(): array
    {
        $cache = self::getCache();
        if (!$cache) {
            $status = ['status' => 'no_cache', 'message' => 'Cache instance is not available; bloom filter not set up.'];
        } else {
            $bloom = self::buildBloomFilter(self::$passwords);
            $cache->set('bloom:common_passwords', $bloom, 604800); // 7 روز
            $status = [
                'status' => 'cached',
                'size'   => '512KB (raw bitmap)',
                'usage'  => 'CommonPasswords::isCommonBloomFilter($password)',
                'note'   => 'Bloom = pre-filter only; positives are confirmed exactly via isCommon()',
            ];
        }

        // FIX-S20-C7: هیچ echo مستقیمی انجام نمی‌شود (وب-امن و PHPUnit-امن)؛
        // فراخوانِ CLI در صورت نیاز خودش آرایهٔ وضعیت را چاپ می‌کند.
        return $status;
    }
}
