<?php
namespace App\Contracts;

interface CacheInterface
{
    public function get(string $key, mixed $default = null): mixed;
    /** FIX-8a: $ttlSeconds بر حسب «ثانیه» است و مقدار دقیق آن معتبر (زیردقیقه‌ای گرد نمی‌شود). */
    public function set(string $key, mixed $value, ?int $ttlSeconds = null): bool;
    public function delete(string $key): bool;
    /** FIX-8a: $minutes بر حسب «دقیقه» است — فقط این متد واحد دقیقه دارد (API تاریخی). */
    public function put(string $key, mixed $value, int $minutes = 60): bool;
    public function forget(string $key): bool;
    /**
     * FIX-8a: قرارداد false-محور با Core\Cache هم‌راستا شد. قبلاً CacheManager شکست
     * زیرین را به ۰ تبدیل می‌کرد (۰ یک «تعداد معتبر» است) و گاردهای fail-closed
     * مالی (سقف کمیسیون روزانه ReferralService، قفل حساب پس از ۱۰ خطای AuthService)
     * عملاً مرده بودند. اکنون شکست مخزن = false؛ مصرف‌کننده با `=== false` fail-closed می‌شود.
     *
     * نکتهٔ امضا (FIX-8a): عمداً بدون return-type declaration در اینترفیس نگه داشته شد
     * (phpstan: @return int|false) تا پیاده‌سازی‌های موجود با `: int` (مثل فیکسچر
     * CorruptSearchCache) سازگار بمانند؛ پیاده‌سازی مرجع (CacheManager) خودش
     * `int|false` اعلام می‌کند. در پیاده‌سازی مرجع: شکست مخزن = false نه ۰.
     *
     * @return int|false مقدار جدید شمارنده، یا false در شکست مخزن شمارنده (Redis/file در دسترس نیست)
     */
    public function increment(string $key, int $step = 1);
    /** @return int|false مثل increment — شکست مخزن false برمی‌گرداند. */
    public function decrement(string $key, int $step = 1);
    public function getOrSet(string $key, callable $callback, ?int $ttlSeconds = null): mixed;
    public function remember(string $key, ?int $ttlSeconds, \Closure $callback): mixed;
    public function rememberForever(string $key, \Closure $callback): mixed;
    public function has(string $key): bool;
    public function ttl(string $key): int;
    public function flush(): bool;
    public function driver(): string;
    /** @param list<string> $tags */
    public function tags(array $tags): self;
    public function redis(): ?\Redis;
    public function lock(string $key, int $ttl = 30, int $wait = 1): bool;
    public function unlock(string $key): bool;
    public function redisKey(string $key): string;
}
