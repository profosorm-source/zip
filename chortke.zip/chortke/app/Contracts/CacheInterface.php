<?php
namespace App\Contracts;

interface CacheInterface
{
    public function get(string $key, mixed $default = null): mixed;
    /** FIX-8a: $ttlSeconds بر حسب «ثانیه» است و مقدار دقیق آن معتبر (زیردقیقه‌ای گرد نمی‌شود). */
    public function set(string $key, mixed $value, ?int $ttlSeconds = null): bool;
    public function delete(string $key): bool;
    /** FIX-8a: $minutes بر حسب «دقیقه» است — فقط این متد واحد دقیقه دارد (API تاریخی). */
    public function put(string $key, mixed $value, int $minutes = 60): bool;
    public function forget(string $key): bool;
    /**
     * FIX-36/F-A9a-01 (راند R36-W2-D): پریمیتیو claim اتمیک «فقط اگر نبود» (SET NX —
     * دلالت SETNX با TTL)؛ ستون فقرات dedupe/گیت‌های claim (R33 بنر، FIX-R18N
     * bulkhead long-poll، claim توزیع سود). true = claim برنده شد، false = کلید
     * زنده است (claim دیگری برنده شده) «یا» مخزن در دسترس نیست (fail-closed).
     *
     * FIX-8a: $seconds بر حسب «ثانیه» است (هم‌قرارداد setSeconds — Core\Cache::add).
     * TTL غیرمثبت روی پیاده‌سازی مرجع InvalidArgumentException است (پین S27).
     */
    public function add(string $key, mixed $value, int $seconds = 60): bool;
    /**
     * FIX-8a: قرارداد false-محور با Core\Cache هم‌راستا شد. قبلاً CacheManager شکست
     * زیرین را به ۰ تبدیل می‌کرد (۰ یک «تعداد معتبر» است) و گاردهای fail-closed
     * مالی (سقف کمیسیون روزانه ReferralService، قفل حساب پس از ۱۰ خطای AuthService)
     * عملاً مرده بودند. اکنون شکست مخزن = false؛ مصرف‌کننده با `=== false` fail-closed می‌شود.
     *
     * نکتهٔ امضا (FIX-8a): عمداً بدون return-type declaration در اینترفیس نگه داشته شد
     * (phpstan: @return int|false) تا پیاده‌سازی‌های موجود با `: int` (مثل فیکسچر
     * CorruptSearchCache) سازگار بمانند؛ پیاده‌سازی مرجع (CacheManager) خودش
     * `int|false` اعلام می‌کند. در پیاده‌سازی مرجع: شکست مخزن = false نه ۰.
     *
     * FIX-P3-CFG-036: قید گام (step) — $step باید مثبت (>= 1) باشد. decrement
     * همین متد را با گام معکوس صدا می‌زند؛ پیاده‌سازی مرجع (Core\Cache::increment)
     * گامِ صفر/منفی را مستقیماً به INCRBY پاس می‌دهد (۰ = خواندنِ بدون تغییر،
     * منفی = جهت برعکس) و آن را «رفتار پشتیبانی‌شده» تلقی نکنید: هیچ تضمینی برای
     * رفتار زیر صفر بین درایورها نیست (ممکن است key/درایورها خطا بدهند یا مقدار
     * منفی بسازند)؛ منطق کسب‌وکار هرگز نباید به گام غیرمثبت تکیه کند. شکست مخزن
     * همچنان false است (بالا).
     *
     * @param int $step گام افزایش — مقدار مثبت (>= 1)
     * @return int|false مقدار جدید شمارنده، یا false در شکست مخزن شمارنده (Redis/file در دسترس نیست)
     */
    public function increment(string $key, int $step = 1);
    /**
     * @return int|false مثل increment — شکست مخزن false برمی‌گرداند.
     * FIX-P3-CFG-036: $step مثبت (>= 1)؛ گام غیرمثبت پشتیبانی‌شده نیست (نگاه increment).
     */
    public function decrement(string $key, int $step = 1);
    public function getOrSet(string $key, callable $callback, ?int $ttlSeconds = null): mixed;
    public function remember(string $key, ?int $ttlSeconds, \Closure $callback): mixed;
    public function rememberForever(string $key, \Closure $callback): mixed;
    public function has(string $key): bool;
    public function ttl(string $key): int;
    public function flush(): bool;
    public function driver(): string;
    /** @param list<string> $tags */
    public function tags(array $tags): self;
    /**
     * FIX-P3-CFG-037 (ACCEPT — گزینهٔ مستندسازی، بدون شکستن ۳۰+ فراخوانندهٔ فعلی):
     * escape hatch صریح و «دلسوز» به کلاینت خام \Redis. این متد ابهام درایور-آگنوستیک
     * بودن قرارداد را عمداً می‌شکند و به‌عنوان deprecated/discouraged تلقی می‌شود:
     *   - فقط زیر Redis driver مقدار \Redis برمی‌گرداند؛ file driver = null
     *     (فراخواننده «باید» null را بپذیرد و مسیر جایگزین داشته باشد).
     *   - هر کدی که به این متد وابسته است، تست‌پذیری و قابلیت جایگزینی درایور را
     *     از دست می‌دهد؛ primitiveهای همین interface (add/increment/lock/ttl/...)
     *     ترجیح داده می‌شوند. کاربردهای مشروع: قابلیت‌های Redis-خاص (pub/sub،
     *     SCAN، pipeline) که هنوز primitive معادلی در این قرارداد ندارند.
     *   - ورودی/خروجی این کلاینت از قراردادهای این interface عبور نمی‌کند؛
     *     پیشوند redisKey() و قفل‌ها را دست‌کاری نکنید (مالکیت FIX-CFG034 می‌شکند).
     * حذف کامل یا انتقال به زیر-interface مخصوص Redis مستلزم مهاجرت ۳۰+ call-site
     * است (به worklog راند p3-cfg ارجاع شود) و در همین راند انجام نشد.
     */
    public function redis(): ?\Redis;
    /**
     * FIX-CFG034 (یافتهٔ ۰۳۴): قرارداد مالکیت قفل — تابع پیاده‌سازی مرجع
     * core/Cache.php: در acquire، برای هر فرایند مالک یک توکن یکتا (uniqueId)
     * ذخیره می‌شود و release فقط با همان توکن ممکن است؛ unlock توسط فرایند
     * غیرمالک false برمی‌گرداند و قفل مالک دیگری را آزاد نمی‌کند (ضد
     * cross-process release). قفل منقضی‌شده (TTL) خودکار آزاد است.
     *
     * @param string $key  نام قفل (با redisKey() پیشوند می‌گیرد)
     * @param int    $ttl  عمر قفل بر حسب ثانیه
     * @param int    $wait حداکثر انتظار برای acquire بر حسب ثانیه
     * @return bool true = قفل گرفته شد؛ false = قفل نزد مالک دیگری است یا backend در دسترس نیست
     */
    public function lock(string $key, int $ttl = 30, int $wait = 1): bool;

    /**
     * FIX-CFG034: آزادسازی قفل فقط توسط مالک توکن — فرایند غیرمالک false
     * می‌گیرد و قفل دست‌نخورده می‌ماند (release توکن‌دار در پیاده‌سازی مرجع).
     */
    public function unlock(string $key): bool;
    public function redisKey(string $key): string;
}
