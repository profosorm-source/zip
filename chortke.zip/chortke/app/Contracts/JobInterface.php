<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * JobInterface - Marker interface اختیاری برای Queue Jobs
 *
 * 📜 قرارداد واقعی (وضعیت موجود، نه ادعا): صف بر اساس «نام کلاس رشته‌ای» کار
 * می‌کند و این marker هیچ متدی تحمیل نمی‌کند. در عمل فقط Job های نوتیفیکیشن
 * آن را implement کرده‌اند؛ Job های مالی/دامنه کلاس ساده با handle() هستند.
 * implement کردن آن الزامی نیست و نبودنش نقض قانون نیست.
 */
interface JobInterface
{
}
