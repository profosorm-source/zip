<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * قرارداد Transactional Outbox (FIX-C66 — یافتهٔ ممیزی ۶۶)
 *
 * 📜 قرارداد اتمیک بودن ثبت:
 *   record() باید «داخل همان تراکنش دیتابیسِ عملیات کسب‌وکار» فراخوانی شود تا
 *   ثبتِ رویداد با تغییر وضعیتِ کسب‌وکار اتمیک باشد (هم‌دیگر-devamanee: یا هر دو
 *   اعمال می‌شوند یا هیچ‌کدام). خروجی false ⇒ فراخواننده موظف است تراکنش را
 *   rollback کند. انتشار واقعی و اتصال به صف/نوتیفیکیشن فقط و فقط در
 *   OutboxPublisher (خارج از تراکنش) انجام می‌شود.
 *
 * 📜 قرارداد idempotent بودن ثبت:
 *   با ارسال $idempotencyKey (کلید پایدار مشتق‌شده از هویت عملیات، مثلاً
 *   "withdraw:{txId}") ثبت تکراری همان رویداد در retryهای سطح کسب‌وکار «no-op
 *   اتمیک» است و ردیف دوبله ساخته نمی‌شود (قید UNIQUE ترکیبی
 *   aggregate_type+aggregate_id+event_type+idempotency_key در outbox_events؛
 *   مایگریشن 2026_09_28_0001). کلید NULL = رفتار legacy (بدون dedupe).
 *   نکته: no-op بودن ثبتِ تکراری، «موفقیت» شمرده می‌شود (true) و نباید باعث
 *   rollback شود؛ رویداد از قبل ثبت‌شده است.
 */
interface OutboxServiceInterface
{
    /**
     * Records an event in the transactional outbox.
     *
     * @param string $aggregateType
     * @param string|int $aggregateId
     * @param string $eventType
     * @param array<string, mixed> $payload
     * @param string|null $availableAt زمانِ آماده‌شدن برای انتشار (NULL = اکنون)
     * @param string|null $eventId شناسهٔ یکتای خود رویداد (FIX-C65)
     * @param string|null $occurredAt زمان وقوع واقعی (FIX-C65)
     * @param int|null $actorId کنشگر (0 = سامانه؛ NULL = نامشخص) (FIX-C65)
     * @param int $eventVersion نسخهٔ شِمای رویداد (FIX-C65)
     * @param string|null $idempotencyKey کلید یکتای ثبت برای dedupe (FIX-C66)
     * @return bool false ⇒ فراخواننده موظف به rollback تراکنش business است
     */
    public function record(
        string $aggregateType,
        string|int $aggregateId,
        string $eventType,
        array $payload = [],
        ?string $availableAt = null,
        ?string $eventId = null,
        ?string $occurredAt = null,
        ?int $actorId = null,
        int $eventVersion = 1,
        ?string $idempotencyKey = null
    ): bool;

    /**
     * فاز ۱ - ثبت Domain Event بدون نیاز به دانش aggregate.
     *
     * FIX-CFG043 (یافتهٔ ۰۴۳): قرارداد واقعی — $event «باید» App\Contracts\DomainEvent
     * را پیاده کرده باشد؛ در غیر این صورت InvalidArgumentException پرتاب می‌شود.
     * مسیر قدیمیِ «استنتاج aggregate/payload از آبجکت خام» حذف شد (منبع ردیف‌های
     * ناقص و قابل‌تصادم در outbox_events بود). آبجکت‌های بدون قرارداد باید با
     * record() و aggregate/payload صریح ثبت شوند یا به Core\GenericEvent مپ شوند.
     * اگر رویداد VersionedDomainEvent باشد متادیتای هویتی هم ثبت می‌شود.
     */
    public function recordEvent(object $event, ?string $availableAt = null): bool;

    /**
     * انتشار دستی رویدادهای pending (عموماً توسط OutboxPublishCommand).
     * جزو چرخهٔ ثبت نیست؛ برای مشاهده‌پذیری و پشتیبانی عملیاتی نگه داشته شده است.
     *
     * @return array<string, mixed>
     */
    public function publishPending(int $limit = 50): array;
}
