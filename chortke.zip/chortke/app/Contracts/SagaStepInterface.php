<?php

namespace App\Contracts;

interface SagaStepInterface
{
    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function execute(array $context): array;
    /** @param array<string, mixed> $context */
    public function compensate(array $context): void;
}
