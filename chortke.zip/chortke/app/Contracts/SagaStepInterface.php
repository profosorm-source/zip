<?php

namespace App\Contracts;

interface SagaStepInterface
{
    public function execute(array $context): array;
    public function compensate(array $context): void;
}
