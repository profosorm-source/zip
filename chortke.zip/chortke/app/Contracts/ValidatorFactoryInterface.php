<?php

declare(strict_types=1);

namespace App\Contracts;

use Core\Database;

/**
 * قرارداد کارخانهٔ Validator
 *
 * FIX-P3-CFG-065 (MODIFY — تصمیم مستندشده): coupling به concreteهای Core
 * (\Core\Database و \Core\Validator) عمدی و پذیرفته‌شده است. در این کدبیس
 * Core همان هستهٔ فریم‌ورک (kernel) است و «همهٔ» قراردادهای app/Contracts
 * به اجزای Core ارجاع می‌دهند (نگاه AdsRepositoryInterface → QueryBuilder،
 * SearchServiceInterface → SearchQuery و…). لایهٔ App بدون Core معنا ندارد؛
 * ساخت انتزاع موازی (AppValidator/AppDb) فقط لایهٔ عبوری بدون مصرف‌کننده
 * می‌ساخت. این interface فقط نقش تست‌پذیری/جایگزینی کارخانه را دارد، نه
 * جداسازی از فریم‌ورک.
 */
interface ValidatorFactoryInterface
{
    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $rules
     * @param array<string, mixed> $messages
     */
    public function make(array $data, array $rules = [], array $messages = [], ?Database $db = null): \Core\Validator;
}
