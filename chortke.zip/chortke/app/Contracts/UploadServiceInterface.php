<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * UploadServiceInterface — قرارداد سرویس آپلود فایل
 * 
 * این interface سرویس آپلود تصاویر و فایل‌ها را انتزاعی می‌کند و امکان:
 * - تست‌های واحد (Mock)
 * - پیاده‌سازی‌های جایگزین (S3, GCS, Azure)
 * - حاکمیت منطق آپلود
 * 
 * را فراهم می‌آورد.
 */
interface UploadServiceInterface
{
    /**
     * آپلود تصویر امن
     * 
     * لایه‌های امنیتی:
     * - بررسی اطلاعات فایل PHP
     * - تحقق اصلی MIME type (magic bytes)
     * - نام‌گذاری تصادفی
     * - محدودیت اندازه
     * - سفیدلیست extension
     * 
     * @param array<string, mixed> $file فایل از $_FILES
     * @param string $folder مسیر پوشه (validated)
     * @param list<string> $allowedMimes MIME types مجاز یا extensions
     * @param int $maxBytes حداکثر اندازه بایت
     * @return array<string, mixed>
     */
    public function upload(
        array $file,
        string $folder,
        array $allowedMimes = [],
        int $maxBytes = 0
    ): array;

    /**
     * حذف فایل
     * 
     * @param string $path مسیر فایل نسبی
     * @return bool
     */
    public function delete(string $path): bool;

    /**
     * بازیابی و validation فایل آپلود‌شده
     */
    public function getFile(string $path): array;

    /**
     * بررسی وجود فایل
     */
    public function exists(string $path): bool;

    /**
     * دریافت محتوای فایل
     */
    public function read(string $path): ?string;

    /**
     * نوشتن محتوا در فایل
     */
    public function write(string $path, string $content): bool;

    // 🛡️ FIX-S34-DEAD-UPLOAD-CONTRACT (2026-09-19، اصلاح S34): getFile/exists/read/write
    // test-locked بازگشتند (تست‌های Chaos/Contract آن‌ها را فراخوانی می‌کنند)؛
    // تنها generatePreSignedUrl/isPublicFolder/fail (بدون تست) حذف ماندند.
}
