<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * UploadServiceInterface — قرارداد سرویس آپلود فایل
 *
 * این interface سرویس آپلود تصاویر و فایل‌ها را انتزاعی می‌کند و امکان:
 * - تست‌های واحد (Mock)
 * - پیاده‌سازی‌های جایگزین (S3, GCS, Azure)
 * - حاکمیت منطق آپلود
 *
 * را فراهم می‌آورد.
 *
 * FIX-CFG063 (یافتهٔ CFG-063): قرارداد امنیتی الزامی هر پیاده‌سازی — منطبق بر
 * protections واقعی App\Services\UploadService (لایه‌های ۱ تا ۱۶ آن کلاس):
 *
 * ── مسیر (path traversal) ─────────────────────────────────────────────────
 *   - $folder فقط [a-z0-9_-] است: هر «..»، «/»، «\» یا کاراکتر خارج از این
 *     مجموعه با BusinessException رد می‌شود؛ خروجی sanitize هرگز از ریشهٔ
 *     آپلود بیرون نمی‌زند.
 *   - متدهای دسترسی (delete/getFile/exists/read/write): ورودی path با «..» رد
 *     می‌شود و مسیر نهایی با realpath confined به ریشه‌های مجاز
 *     (storage/uploads | public/uploads | storage/captcha) گارد می‌شود؛
 *     escape از ریشه‌ها = ردِ عملیات.
 *
 * ── سیاست اجرا و نام‌گذاری (file-execution policy) ────────────────────────
 *   - نام فایل ذخیره‌شده همیشه «سرورساخت» است: bin2hex(random_bytes(12))؛
 *     نام اصلی کاربر فقط برای ولیدیشن خوانده می‌شود و هرگز به دیسک نمی‌رود
 *     (نه اطلاعات لو می‌رود، نه collision، نه مسیر کنترل‌شدهٔ کاربر).
 *   - پسوند خروجی فقط از جدول MIME→ext سرور (MIME_TO_EXT) ساخته می‌شود، نه از
 *     ورودی کاربر.
 *   - نام اصلی حاوی پسوندهای خطرناک (php/phtml/phar/htaccess/user.ini/svg/
 *     html/exe/sh/...) رد می‌شود — شامل حملهٔ double-extension مثل
 *     avatar.php.jpg؛ فایل اجرایی/اسکریپتی هرگز ذخیره نمی‌شود (no execution
 *     bit به معنای «محتوای اجرایی هرگز پذیرفته نمی‌شود»).
 *
 * ── allowlist‌ها و سقف‌ها ──────────────────────────────────────────────────
 *   - MIME واقعی با finfo (magic bytes) تعیین می‌شود؛ $_FILES['type']
 *     (جعل‌پذیر) هرگز ملاک نیست؛ WebP با امضای RIFF????WEBP و PDF با هدر %PDF-
 *     دوباره تأیید می‌شوند؛ سقف ابعاد decode تصویر ۲۴ مگاپیکسل.
 *   - $allowedMimes زیرمجموعهٔ allowlist سرور است (MIME یا extension — هر دو
 *     پذیرفته می‌شود) و با MIME واقعی تطبیق داده می‌شود.
 *   - حجم دوبار چک می‌شود ($_FILES['size'] و filesize() واقعی؛ بزرگ‌ترِ دو
 *     مقدار ملاک)؛ پیش‌فرض ۵MB و سقف مطلق ۱۰MB — هیچ پیاده‌سازی‌ای حق ندارد
 *     سقف مطلق را بالا ببرد.
 *
 * ── محل ذخیره ─────────────────────────────────────────────────────────────
 *   - پیش‌فرض ذخیره «خارج از webroot» است (storage/uploads)؛ فقط پوشه‌های
 *     اعلامی عمومی (avatars/banners/site-images) در public/uploads می‌روند؛
 *     PDF/ویدیوها فقط با forced-download سرو می‌شوند نه اجرای درجای.
 */
interface UploadServiceInterface
{
    /**
     * آپلود تصویر امن
     *
     * لایه‌های امنیتی:
     * - بررسی اطلاعات فایل PHP
     * - تحقق اصلی MIME type (magic bytes)
     * - نام‌گذاری تصادفی
     * - محدودیت اندازه
     * - سفیدلیست extension
     *
     * FIX-CFG063: همهٔ گاردهای بخش سربرگ (پوشه، MIME واقعی، magic bytes،
     * double-extension، سقف حجم، نام سرورساخت) برای این متد «الزامی»اند.
     *
     * FIX-P3-CFG-064 (docblock-only): معناشناسی مقادیر sentinel دو پارامتر —
     * پیش‌فرض‌ها هرگز «بدون محدودیت» تفسیر نمی‌شوند:
     *   - $allowedMimes خالی ([]): به‌جای «همه‌چیز مجاز»، به allowlist تصویرِ
     *     سرور (UploadService::IMAGE_MIMES — jpeg/png/webp/gif/heic/heif)
     *     برمی‌گردد (resolveAllowedMimes: نتیجهٔ خالی ⇒ IMAGE_MIMES). هر عضوِ
     *     داده‌شده هم فقط «زیرمجموعهٔ» همان allowlist سرور می‌تواند باشد
     *     (MIME یا extension؛ اعضای ناشناخته نادیده گرفته می‌شوند) — یعنی
     *     فراخوانی هرگز نمی‌تواند نوعی خارج از whitelist سرور باز کند.
     *   - $maxBytes <= 0: به پیش‌فرضِ پیکربندی‌شده (upload_default_max_bytes؛
     *     ۵MB) رجوع می‌شود (resolveMaxBytes)؛ مقادیر < 1024 به‌عنوان «مگابایت»
     *     تفسیر و اصلاح می‌شوند (۲ ⇒ ۲۰۹۷۱۵۲)؛ مقدار نهایی در هر حالت به
     *     سقف مطلق upload_absolute_max_bytes (۱۰MB) محدود می‌شود. «unlimited»
     *     در این قرارداد وجود خارجی ندارد.
     *
     * @param array<string, mixed> $file فایل از $_FILES
     * @param string $folder مسیر پوشه (validated — فقط [a-z0-9_-])
     * @param list<string> $allowedMimes MIME types مجاز یا extensions؛ خالی = whitelist تصویر سرور
     * @param int $maxBytes حداکثر اندازه بایت؛ <=0 = پیش‌فرض پیکربندی، <1024 = مگابایت، همیشه ≤ سقف مطلق
     * @return array<string, mixed> پاکت نتیجه: success/filename/path/url/size/mime/message
     * @throws \Core\Exceptions\BusinessException هر نقض اعتبارسنجی (نام پوشه،
     *         خطای آپلود PHP، فایل خالی، حجم بیش از حد، پسوند خطرناک، MIME
     *         ناهم‌خوان)
     * @throws \RuntimeException در دسترس‌نبودن finfo
     */
    public function upload(
        array $file,
        string $folder,
        array $allowedMimes = [],
        int $maxBytes = 0
    ): array;

    /**
     * حذف فایل
     *
     * FIX-CFG063: $path باید پس از resolve داخل ریشه‌های مجاز بماند (بدون «..»).
     *
     * @param string $path مسیر فایل نسبی
     * @return bool
     */
    public function delete(string $path): bool;

    /**
     * بازیابی و validation فایل آپلود‌شده
     * FIX-CFG063: مسیر با همان گارد traversal ریشه‌محور resolve می‌شود.
     * @return array<string, mixed>
     */
    public function getFile(string $path): array;

    /**
     * بررسی وجود فایل (مسیر traversal-garded)
     */
    public function exists(string $path): bool;

    /**
     * دریافت محتوای فایل (مسیر traversal-garded)
     */
    public function read(string $path): ?string;

    /**
     * نوشتن محتوا در فایل (مسیر traversal-garded)
     */
    public function write(string $path, string $content): bool;

    // 🛡️ FIX-S34-DEAD-UPLOAD-CONTRACT (2026-09-19، اصلاح S34): getFile/exists/read/write
    // test-locked بازگشتند (تست‌های Chaos/Contract آن‌ها را فراخوانی می‌کنند)؛
    // تنها generatePreSignedUrl/isPublicFolder/fail (بدون تست) حذف ماندند.
}
