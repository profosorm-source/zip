<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * 🛡️ FIX-CH10 (گزارش بخش‌های ۸-۴۰): قرارداد جاب‌هایی که باید هنگام شکستِ
 * قطعی (ورود به DLQ بدون smart-retry بعدی) جبرانِ durable انجام دهند.
 *
 * پیشینه: AdNotificationDispatcher بودجه را قبل از صف‌شدن مصرف می‌کند و
 * ProcessNotificationJob بعداً FCM را می‌فرستد؛ شکستِ قطعیِ async (DLQ)
 * قبلاً هیچ جبرانی نداشت — پول مصرف‌شده می‌ماند در حالی که گیرنده پیام را
 * نگرفته. QueueWorker در شاخهٔ terminal این متد را دقیقاً یک‌بار صدا می‌زند
 * (بدون smart-retry در انتظار). پیاده‌سازی باید idempotent باشد.
 */
interface FinalFailureAwareInterface
{
    /**
     * شکست قطعی جاب (ورود terminal به DLQ): جبرانِ idempotent مصرف‌های
     * تحویل‌نشده. Worker همان payload خود جاب را پاس می‌دهد. هر استثنایی
     * که اینجا پرتاب شود فقط لاگ می‌شود — سلامت مسیر DLQ نباید به نتیجهٔ
     * جبران وابسته باشد.
     *
     * @param array<string, mixed> $payload
     */
    public function onFinalFailure(array $payload, \Throwable $e): void;
}
