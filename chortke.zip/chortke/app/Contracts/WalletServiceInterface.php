<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * @phpstan-type WalletMetadata array<string, mixed>
 * @phpstan-type WalletResult array<string, mixed>
 * @phpstan-type WalletFilters array<string, mixed>
 *
 * FIX-CFG040 (یافتهٔ CFG-040): قرارداد واحد پول این interface — «فقط numeric-string»:
 *
 *   1) همهٔ مبالغ ($amount و خروجی‌های مالی مثل getBalance/new_balance) از نوع
 *      string هستند: numeric-string دهدهی با مقیاس رسمی ۸ (مثل '100.50000000').
 *   2) float مطلقاً ممنوع است — نه در ورودی، نه در محاسبه. این فایل
 *      declare(strict_types=1) دارد، پس پاس‌دادن float به هر متد، در همان لحظه
 *      TypeError می‌دهد (نه تبدیل خاموش). تمام مقایسه/جمع مالی سمت پیاده‌سازی
 *      با bccomp/bcadd در scale 8 انجام می‌شود (هیچ float-math در مسیر پول نیست).
 *   3) قالب پذیرفته‌شدهٔ واقعی (App\Services\Wallet\WalletService::
 *      executeAtomicOperation): is_numeric($amount) && bccomp($amount,'0',8) > 0 —
 *      یعنی صفر، منفی و رشتهٔ غیرعددی با InvalidArgumentException رد می‌شود؛
 *      مقیاس بیش از ۸ رقم اعشار در مقایسه‌ها قطع/گرد نمی‌شود بلکه با همان
 *      دقتِ bccomp(…,8) سنجیده می‌شود — فراخواننده باید مبلغ را پیش از فراخوانی
 *      با مقیاس ۸ نرمال کند.
 *   4) $currency فقط 'irt' یا 'usdt' (حروف کوچک؛ موارد دیگر در
 *      validateCurrency رد می‌شود).
 *
 * FIX-CFG067 (یافتهٔ CFG-067): شکل پاکت خروجی عملیات mutation (deposit/withdraw/
 * pay/transfer/spendLockedFunds/releaseLockedFunds) همان WalletResult است:
 * array{success: bool, transaction_id: string|null, message: string,
 * new_balance: string|null, amount: string|null, currency: string|null,
 * status: string|null, error: string|null, balance_before/after,
 * locked_before/after, idempotent_replay: bool} (نگاه WalletService).
 */
interface WalletServiceInterface
{
    public function getOrCreateWallet(int $userId): ?object;
    
    /**
     * واریز به کیف پول. اتمیک: distributed lock + DB transaction + idempotency
     * (IdempotencyService::executeWithLock) — تکرار همین درخواست (همان کلید
     * idempotency) تراکنش دوبل نمی‌سازد و نتیجهٔ موجود را با
     * idempotent_replay=true برمی‌گرداند.
     *
     * FIX-CFG040: $amount numeric-string دهدهی scale 8؛ float ممنوع (TypeError).
     *
     * @param WalletMetadata $metadata کلیدهای شناخته‌شده: request_id/ip_address/
     *        device_fingerprint/idempotency_key/description/ref_id/ref_type
     * @return WalletResult
     */
    public function deposit(int $userId, string $amount, string $currency = 'irt', array $metadata = []): array;
    
    /**
     * FIX-CFG067: نام تاریخی است — پیاده‌سازی مرجع دقیقاً deposit() را صدا می‌زند
     * (قفل و تراکنش داخلی خودِ سرویس کفایت می‌کند). هم‌قرارداد deposit().
     *
     * @param WalletMetadata $metadata
     * @return WalletResult
     */
    public function depositInTransaction(int $userId, string $amount, string $currency = 'irt', array $metadata = []): array;
    
    /**
     * برداشت: «رزرو» وجه است، نه پرداخت بیرونی — موجودی کاربر بلافاصله
     * balance → locked می‌رود (lockBalance اتمیک زیر قفل ردیف) و تراکنش با
     * status='pending' ثبت می‌شود؛ تکمیل/لغو بعدی با completeWithdrawal/
     * cancelWithdrawal انجام می‌شود.
     *
     * FIX-CFG067 (یافتهٔ CFG-067) — مجوز و state machine:
     *   - مجوزدهی تجاری (سقف مبلغ، وضعیت KYC، تصمیم ادمین و…) مسئولیت لایهٔ
     *     فراخواننده است؛ این متد تنها گاردهای داخلی را زیر قفل اعمال می‌کند:
     *     کیف پول قفل‌شده (is_frozen)، موجودی ناکافی
     *     (InsufficientBalanceException)، قاعدهٔ «روزی یک برداشت» و fraudGuard.
     *   - وضعیت تراکنش: withdraw تراکنش را فقط با status='pending' می‌سازد؛
     *     گذارهای مجاز بعدی: pending|processing → completed (completeWithdrawal)
     *     یا pending|processing → cancelled (cancelWithdrawal)؛ گذار معکوس و
     *     پرشِ وضعیت ممنوع است.
     *   - idempotency: با کلید idempotency (metadata یا مشتق‌شدهٔ خودکار) زیر قفل
     *     کیف پول؛ درخواست تکراری وجه را دوباره قفل نمی‌کند و نتیجهٔ تراکنشِ
     *     موجود را برمی‌گرداند.
     *
     * FIX-CFG040: $amount numeric-string دهدهی scale 8؛ float ممنوع (TypeError).
     *
     * @param WalletMetadata $metadata
     * @return WalletResult success=true با status='pending' و transaction_id
     * @throws \Core\Exceptions\InsufficientBalanceException موجودی ناکافی
     * @throws \Core\Exceptions\InvalidStateException کیف پول مسدود
     * @throws \InvalidArgumentException مبلغ غیرمثبت/غیرعددی
     */
    public function withdraw(int $userId, string $amount, string $currency = 'irt', array $metadata = []): array;

    /**
     * FIX-CFG067: نام تاریخی است — پیاده‌سازی مرجع دقیقاً withdraw() را صدا می‌زند.
     * هم‌قرارداد withdraw() (رزرو balance→locked، وضعیت pending، idempotent).
     *
     * @param WalletMetadata $metadata
     * @return WalletResult
     */
    public function withdrawInTransaction(int $userId, string $amount, string $currency = 'irt', array $metadata = []): array;
    
    /**
     * پرداخت مستقیم از کیف پول (کسر فوری balance؛ بدون مرحلهٔ pending).
     * اتمیک و idempotent مثل deposit؛ مبلغ غیرمثبت InvalidArgumentException.
     *
     * FIX-CFG040: $amount numeric-string دهدهی scale 8؛ float ممنوع.
     *
     * @param WalletMetadata $metadata
     * @return WalletResult
     */
    public function pay(int $userId, string $amount, string $currency = 'irt', array $metadata = []): array;

    /**
     * FIX-CFG040: مقایسهٔ خالص با bccomp(balance, $amount, 8) — ورودی باید
     * numeric-string دهدهی باشد؛ float ممنوع.
     */
    public function hasBalance(int $userId, string $amount, string $currency = 'irt'): bool;

    /**
     * FIX-CFG067: نهایی‌سازی برداشتِ در انتظار (pending|processing → completed).
     * - مالکیت: تراکنش باید متعلق به همین $userId با type='withdraw' باشد؛
     *   در غیر این صورت false.
     * - idempotent: تراکنشِ از پیش completed دوباره true برمی‌گرداند (بدون اثر
     *   مضاعف)؛ گذار فقط از pending/processing انجام می‌شود (updateStatus با
     *   گارد وضعیت) — پس دو فراخوانی هم‌زمان تنها یکی عبور می‌کند.
     * - transactionId الزامی است (null → false بدون اثر جانبی).
     */
    public function completeWithdrawal(int $userId, string $amount, string $currency, ?string $transactionId): bool;

    /** Marks an already-spent locked hold as completed without touching balance/locked again. */
    public function finalizeLockedSpend(int $userId, string $transactionId): bool;

    /** Marks a hold as cancelled after releaseLockedFunds already refunded it. */
    public function finalizeLockedRefund(int $userId, string $transactionId): bool;
    
    /**
     * FIX-CFG067: لغو برداشتِ در انتظار (pending|processing → cancelled) و آزادسازی
     * وجه قفل‌شده به balance مالک. idempotent: تراکنشِ از پیش cancelled/failed
     * دوباره true برمی‌گرداند؛ مالکیت (transactionId, userId) گارد می‌شود؛
     * transactionId الزامی است (null → false).
     */
    public function cancelWithdrawal(int $userId, string $amount, string $currency, ?string $transactionId): bool;

    public function reverseTransaction(string $transactionId, ?int $adminId = null, string $reason = ''): bool;
    
    /**
     * FIX-CFG040: $amount numeric-string دهدهی؛ سنجش با bccomp در scale 8.
     * @return array{can_withdraw: bool, message: string}
     */
    public function canWithdraw(int $userId, string $amount, string $currency = 'irt'): array;

    /** آیا کاربر امروز حق برداشت جدید دارد؟ (قاعدهٔ «روزی یک برداشت» — FIX #6) */
    public function canWithdrawToday(int $userId): bool;
    
    public function getWalletSummary(int $userId): \stdClass;
    
    /**
     * FIX-C88: خروجی، پاکت ساختاریافتهٔ WalletResult (آرایه) است — هم‌شکل
     * deposit/withdraw (success/transaction_id/status/error/…)، دیگر ?object نیست.
     *
     * @param string|null $clientIdempotencyKey P0-23: کلید idempotency سمت کلاینت (اختیاری)
     * @return array<string, mixed>
     */
    public function transfer(int $fromUserId, int $toUserId, string $amount, string $currency = 'irt', string $description = '', ?string $clientIdempotencyKey = null): array;
    
    /**
     * FIX-CFG040: خروجی همیشه numeric-string دهدهی (scale پایگاه‌ داده، مقیاس ۸)
     * است — هرگز float. مصرف‌کننده موظف است مقدار را مستقیم به متدهای مالی همین
     * interface برگرداند یا با bccomp بسنجد.
     */
    public function getBalance(int $userId, string $currency = 'irt'): string;

    /** مانند getBalance() ولی با قفل ردیف (SELECT … FOR UPDATE) داخل تراکنش جاری. */
    public function getBalanceForUpdate(int $userId, string $currency = 'irt'): string;

    public function isWalletFrozen(int $userId): bool;

    // ── Query methods (CQRS Read Model) ────────────────────────
    /** @return array<string, string|null> */
    public function getWalletBalances(int $userId): array;
    /**
     * FIX-P3-CFG-068: کرانه‌ها — $limit حداقل ۱ و $offset حداقل ۰ در پیاده‌سازی
     * مرجع (Transaction::getUserTransactions) clamp و به‌صورت parameterized بایند
     * می‌شوند؛ سقف سخت در مخزن وجود ندارد، پس فراخواننده page-size را کوچک نگه
     * دارد (الگوی مرجع ≤ ۱۰۰؛ خوراک داشبورد/خروجی‌ها). $filters کلیدهای شناخته‌شده:
     * type، currency (مقدار نامعتبر به‌عنوان فیلتر بی‌اثر می‌شود نه خطا).
     *
     * @param WalletFilters $filters
     * @return list<\stdClass>
     */
    public function getUserTransactions(int $userId, int $limit, int $offset, array $filters = []): array;
    /** @param WalletFilters $filters */
    public function countUserTransactions(int $userId, array $filters = []): int;
    /**
     * FIX-P3-CFG-068: کرانه‌ها مثل getUserTransactions — limit ≥ ۱ / offset ≥ ۰
     * clamp و بایند می‌شوند؛ page-size کوچک (≤ ۱۰۰) مسئولیت فراخواننده است.
     *
     * @return list<\stdClass>
     */
    public function getAllTransactions(?string $status = null, ?string $type = null, ?string $currency = null, int $limit = 50, int $offset = 0): array;
    public function countAllTransactions(?string $status = null, ?string $type = null, ?string $currency = null): int;
    public function findTransactionById(int $id): ?\stdClass;
    /** @return list<\stdClass> */
    public function quickSearchTransactions(string $term, ?int $userId = null, int $limit = 5): array;

    /**
     * Consumes reserved/locked funds without returning them to the owner's
     * available balance. This is the settlement primitive for escrow payouts.
     */
    /**
     * @param WalletMetadata $metadata
     * @return WalletResult
     */
    public function spendLockedFunds(int $userId, string $amount, string $currency = 'irt', array $metadata = []): array;

    /**
     * Refund primitive: locked funds are returned to the owner's available
     * balance. It must never be used for an escrow payout.
     */
    /**
     * @param WalletMetadata $metadata
     * @return WalletResult
     */
    public function releaseLockedFunds(int $userId, string $amount, string $currency = 'irt', array $metadata = []): array;
}
