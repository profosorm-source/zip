<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * Rate Limiter Interface
 *
 * تعریف قراردادی برای Rate Limiting سرویس‌ها
 * از استراتژی‌های مختلف (Fixed Window, Token Bucket, Sliding Window) پشتیبانی می‌کند
 *
 * FIX-CFG060 (یافتهٔ CFG-060): مستندسازی واحدها، اتمیک‌بودن و رفتار خرابی،
 * منطبق بر پیاده‌سازی مرجع Core\RateLimiter (+ Core\Strategies\*) — واقعیت، نه آرزو:
 *
 * ── واحدها ─────────────────────────────────────────────────────────────────
 *   - واحد «پنجره» در سراسر این قرارداد «دقیقه» است، نه ثانیه:
 *     $decayMinutes × 60 = TTL ثانیه در Redis (قرارداد واحد زمان FIX-8a).
 *     attempt('k', 3, 60) یعنی ۳ تلاش در ۱ ساعت (نه ۶۰ ثانیه!) — بایاس رایجِ
 *     ثانیه‌پنداری را ببینید؛ پنجرهٔ ثانیه‌محور با max(1, ceil($seconds/60)) به
 *     دقیقه تبدیل می‌شود (الگوی RateLimitPolicy::forWindowSeconds).
 *   - availableIn() برعکس، «ثانیه»ی باقی‌مانده تا ریست را برمی‌گرداند (برای هدر
 *     Retry-After). maxAttempts واحد «تعداد» است (cost واحد — هر attempt یک hit).
 *
 * ── اتمیک بودن ────────────────────────────────────────────────────────────
 *   - درایور Redis (پیاده‌سازی مرجع): ارزیابی+افزایش در «یک اسکریپت Lua» اتمیک
 *     انجام می‌شود (INCR + EXPIRE مشروط به current==1) — بین شمارش و سقف‌سنجی
 *     هیچ پنجرهٔ race وجود ندارد.
 *   - درایور فایل: increment با قفل اتمیک flock گارد می‌شود.
 *
 * ── رفتار وقتی backend در دسترس نیست ──────────────────────────────────────
 *   پیاده‌سازی مرجع fail-closed است: شکست زیرین (Redis قطع) در attempt() لاگ
 *     می‌شود و false برمی‌گرداند (رد درخواست؛ امنیت اول). پیاده‌سازی پارامتر
 *     اختیاری چهارم $failClosed (پیش‌فرض true) دارد که فراخواننده‌های آگاه
 *     (مثل جستجو) صریحاً fail-open انتخاب می‌کنند — پیش‌فرض قرارداد، fail-closed
 *     بماند. توجه: این حالت با «کلید سرد» فرق دارد؛ getAttempts()/availableIn()
 *     برای کلید مفقود 0 برمی‌گردانند (بدون استثنا).
 */
interface RateLimiterInterface
{
    /**
     * بررسی و ثبت یک تلاش
     * اگر از حد مجاز تجاوز کرد false برمی‌گرداند
     *
     * FIX-CFG060: یک فراخوانی = یک hit (هر attempt هم می‌شمارد هم تصمیم می‌گیرد،
     * اتمیک). پیش‌فرض‌ها: maxAttempts=60 در $decayMinutes=1 دقیقه.
     * $decayMinutes واحدش «دقیقه» است (بالا را ببینید).
     */
    public function attempt(string $key, ?int $maxAttempts = null, ?int $decayMinutes = null): bool;

    /**
     * دریافت تعداد تلاش‌های فعلی (کلید مفقود → 0؛ بدون استثنا)
     */
    public function getAttempts(string $key): int;

    /**
     * alias برای getAttempts
     */
    public function hits(string $key): int;

    /**
     * افزایش شمارنده
     * FIX-CFG060: $decayMinutes «دقیقه» است؛ پیاده‌سازی مرجع با سقف
     * PHP_INT_MAX افزایش می‌دهد (فقط ثبت، بدون تصمیم رد).
     */
    public function incrementAttempts(string $key, int $decayMinutes): void;

    /**
     * حذف کامل کلید (reset)
     */
    public function clear(string $key): void;

    /**
     * ثانیه‌های باقی‌مانده تا ریست (واحد: ثانیه — برای Retry-After)
     */
    public function availableIn(string $key): int;

    /**
     * بررسی تلاش‌های ورود
     * FIX-CFG060: پیکربندی از config('rate_limits.admin.login') خوانده می‌شود و
     * خروجی، پاکت ساختاریافتهٔ زیر است (کلیدها اجباری‌اند):
     * array{allowed: bool, remaining: int, reset_at: int(timestamp),
     *       retry_after: int(ثانیه), message: string|null}
     * @return array<string, mixed>
     */
    public function checkLoginAttempt(string $identifier): array;

    /**
     * پاک کردن بعد از ورود موفق
     */
    public function clearLoginAttempts(string $identifier): void;

    /**
     * بررسی لیمیت API
     * FIX-CFG060: همان پاکت checkLoginAttempt — کلید Redis «api:{userId}».
     * @return array<string, mixed>
     */
    public function checkApiLimit(int $userId, int $maxRequests = 60, int $perMinutes = 1): array;

    /**
     * پاکسازی فایل‌های منقضی
     * FIX-CFG060: استراتژی‌های بدون پشتیبانی cleanup، بی‌صدا 0 برمی‌گردانند
     * (بدون استثنا) — تعداد کلیدهای پاک‌شده.
     */
    public function cleanup(): int;
}
