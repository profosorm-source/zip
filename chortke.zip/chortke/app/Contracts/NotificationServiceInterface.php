<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * NotificationServiceInterface
 *
 * FIX-P3-CFG-056/057 (docblock-only): واژگان و معناشناسی مشترک —
 *
 * - $type: رشتهٔ آزاد در امضا، اما واژگان واقعی ثابت‌های \App\Models\Notification::TYPE_*
 *   هستند: system | deposit | withdrawal | task | kyc | lottery | referral |
 *   security | investment | info | marketing. مقدار خارج از این واژگان ممکن است
 *   فیلترهای ترجیحات (canSendInApp) و رندر قالب‌ها را از کار بیندازد.
 * - $priority: مقادیر مجاز ثابت‌های Notification::PRIORITY_* — low | normal |
 *   high | urgent. مورد خاص: type='security' با priority='normal' به‌صورت
 *   خودکار به high ارتقا می‌یابد (پیاده‌سازی مرجع، NotificationService::send).
 * - $expiresAt / $scheduledAt: رشتهٔ زمان قابل‌پذیرش ستون datetime (قالب
 *   توصیه‌شده 'Y-m-d H:i:s'، همان چیزی که strtotime می‌خواند)؛ null = بدون
 *   انقضا/ارسال فوری. ارسال آینده در scheduled_at ذخیره و توسط پردازشگر
 *   زمان‌بندی برداشته می‌شود (شکست‌های DND/policy ممکن است آن را جابه‌جا کنند).
 * - $groupKey: برای API حفظ شده؛ مسیر in-app مرجع آن را در DB ذخیره «نمی‌کند»
 *   (ستون group_key حذف شده — FIX-X219)؛ امروز فقط یک صفر-مانند (no-op)
 *   سازگاری است و گروه‌بندی/dedupe اعمال نمی‌شود.
 * - $actionText: برچسب متنی دکمهٔ CTA کنار $actionUrl (مثلاً 'مشاهده').
 * - $data: payload آزاد؛ کلیدهای idempotency_key/event_id/notif_id/message_id
 *   (در صورت وجود) به‌عنوان کلید idempotency رکورد در-app استفاده می‌شوند.
 */
interface NotificationServiceInterface
{
    /**
     * ارسال اعلان درون-برنامه‌ای به یک کاربر (درِ واحد notification).
     *
     * FIX-P3-CFG-056: معنای بازگشتی — ?int شناسهٔ رکورد notifications ساخته‌شده
     * است؛ null یعنی «اعلان ساخته نشد» (سیاست/ترجیحات/نرخ‌محدودیت آن را بلاک
     * کرد). این خروجی «تولید رکورد» است نه تحویل به کانال‌های بیرونی؛
     * ارسال به FCM/SMS/Email مسیر dispatch/outbox خودش را دارد.
     *
     * @param array<string, mixed>|null $data
     */
    public function send(
        int     $userId,
        string  $type,
        string  $title,
        string  $message,
        ?array  $data        = null,
        ?string $actionUrl   = null,
        ?string $actionText  = null,
        string  $priority    = 'normal',
        ?string $expiresAt   = null,
        ?string $imageUrl    = null,
        ?string $groupKey    = null,
        ?string $scheduledAt = null
    ): ?int;

    /**
     * اعلان همگانی به همهٔ ادمین‌ها.
     *
     * FIX-P3-CFG-056: بازگشت int = «تعداد رکوردهای اعلان ادمین ساخته‌شده» است،
     * نه تعداد تحویل‌های موفق به کانال؛ صفر یعنی ادمینی یافت/مجاز نشد.
     *
     * @param array<string, mixed>|null $data
     */
    public function sendToAdmins(
        string $type,
        string $title,
        string $message,
        ?array $data = null,
        string $priority = 'normal'
    ): int;

    /**
     * dispatch مستقیم به یک کانال بیرونی (fcm/sms/email/log) بدون رکورد in-app.
     *
     * FIX-P3-CFG-056: قرارداد bool هم‌معنای NotificationChannelInterface::send —
     * true = «به کانال/ارائه‌دهنده سپرده شد و رد نشد»؛ تحویل نهایی async است و
     * تضمین نمی‌شود. فراخوانی ترتیبی روی چند کانال، شکستِ یک کانال نباید
     * بقیه را قطع کند (مسئولیت فراخواننده/NotificationDispatcher).
     *
     * @param array<string, mixed>|null $data
     */
    public function dispatch(
        string $channel,
        int $userId,
        string $title,
        string $message,
        ?array $data = null,
        ?string $imageUrl = null,
        ?string $actionUrl = null,
        ?string $actionText = null,
        string $priority = 'normal'
    ): bool;

    // 🧹 FIX-S18-6S (S18.6): depositSuccess حذف شد — تولیدکننده‌ای نداشت؛
    // اعلان‌های واریز از درِ واحد notification.requested (outbox) عبور می‌کنند.

    /**
     * آمار کلی notification analytics
     * @return array<string, mixed>
     */
    public function getAnalyticsOverview(int $days = 30): array;

    /**
     * آمار funnel نوتیفیکیشن‌ها
     * @return array<string, mixed>
     */
    public function getAnalyticsFunnelStats(int $days = 30): array;
}
