<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * CircuitBreakerInterface — قرارداد ماشین‌حالت مدار (Circuit Breaker)
 *
 * FIX-CFG038 (یافتهٔ CFG-038): مستندسازی کامل معناشناسی ماشین‌حالت، منطبق بر
 * پیاده‌سازی مرجع Core\CircuitBreaker (state-store: Redis) — رفتار واقعی، نه آرزویی:
 *
 * ─── حالت‌ها و گذارها ──────────────────────────────────────────────────────
 *   CLOSED   → حالت عادی؛ عملیات اجرا می‌شود. شکست‌ها با شمارندهٔ اتمیک
 *              (Cache::increment — Lua) روی کلید circuit_breaker:{service}:failures
 *              با TTL = timeout شمرده می‌شوند. رسیدن شمارنده به آستانه (پیش‌فرض ۵،
 *              پیکربندی circuit_breaker.failure_threshold و per-service threshold)
 *              → گذار به OPEN + ثبت opened_at + رویداد circuit_breaker.opened.
 *   OPEN     → درخواست‌ها fast-fail می‌شوند (بخش call()). پس از انقضای
 *              retry_timeout_seconds (پیش‌فرض ۶۰؛ per-service timeout) گذار خودکار
 *              به HALF_OPEN در اولین call() بعدی رخ می‌دهد (+ رویداد
 *              circuit_breaker.half_open).
 *   HALF_OPEN→ پروب (probe): همان call() بعدی عملیات را واقعاً اجرا می‌کند.
 *              موفقیت → reset به CLOSED (پاک‌شدن شمارنده + رویداد circuit_breaker.closed).
 *              شکست → بازگشت فوری به OPEN (re-trip؛ شمارندهٔ منقضی مسئله‌ساز نیست).
 *              نکته: HALF_OPEN «تک‌پروبِ» قفل‌شده نیست — N درخواست هم‌زمانِ پس از
 *              timeout همه پروب می‌شوند (thundering-herd ملایم؛ تعادل آگاهانه).
 *
 * ── قرارداد استثنا وقتی مدار باز است ──────────────────────────────────────
 *   call() روی حالت OPEN (قبل از انقضای timeout) هیچ‌گاه operation را اجرا نمی‌کند و
 *   Core\Exceptions\CircuitBreakerOpenException پرتاب می‌کند (کد HTTP 503؛
 *   retry-after = timeout − زمان‌سپری‌شده از opened_at). اگر fallback به call()
 *   داده شده باشد، به‌جای پرتاب، fallback($exception) اجرا و نتیجهٔ آن برگردانده
 *   می‌شود. خرابی state-store (Redis قطع) مدار را «باز» نمی‌کند: وضعیت پیش‌فرض
 *   'closed' است (fail-open) و شکست ثبتِ شکست فقط لاگ می‌شود؛ قرارداد call()
 *   (rethrow عین خطای عملیات یا اجرای fallback) هرگز با خطای state-store جایگزین
 *   نمی‌شود.
 *
 * ── چه کسی شکست می‌شمارد؟ ─────────────────────────────────────────────────
 *   مسیر ترجیحی call() است که موفقیت/شکست را خودکار ثبت می‌کند. فراخواننده‌ای که
 *   به هر دلیل operation را بیرون از call() اجرا می‌کند، موظف است نتیجه را دستی
 *   با reportSuccess()/reportFailure() گزارش کند؛ reportFailure نیز از همان
 *   شمارندهٔ اتمیک و آستانهٔ واحد استفاده می‌کند (و در HALF_OPEN همان re-trip را
 *   انجام می‌دهد) — یعنی مسیر دستی و مسیر call() قابل‌جمع‌اند و ناسازگار نیستند.
 */
interface CircuitBreakerInterface
{
    /**
     * Executes an operation behind the circuit breaker.
     *
     * رفتار واقعی (Core\CircuitBreaker::call):
     *   - حالت OPEN و timeout منقضی‌نشده → CircuitBreakerOpenException (یا fallback).
     *   - حالت OPEN و timeout منقضی‌شده → گذار به HALF_OPEN و سپس اجرای operation.
     *   - CLOSED/HALF_OPEN → اجرای operation؛ موفقیت = reset به CLOSED،
     *     شکست = ثبت شکست اتمیک (در HALF_OPEN: re-trip فوری به OPEN).
     *
     * @param string $serviceName شناسهٔ سرویس (کلید state-store و پیکربندی per-service)
     * @param callable $operation عملیات محافظت‌شده
     * @return mixed نتیجهٔ operation یا نتیجهٔ fallback (در صورت داده‌شدن)
     * @throws \Core\Exceptions\CircuitBreakerOpenException وقتی مدار باز است و fallback داده نشده
     * @throws \Throwable عین استثنای operation (پس از ثبت شکست) وقتی fallback داده نشده
     */
    public function call(string $serviceName, callable $operation);

    /**
     * Returns true when the circuit for the given service is open.
     *
     * قرائت صرفِ state است (بدون اثر جانبی)؛ وضعیت مفقود/در-دسترس‌نبودنِ
     * state-store «closed» تعبیر می‌شود (fail-open — مدار خودش عامل قطع نیست).
     */
    public function isOpen(string $serviceName): bool;

    /**
     * معکوس isOpen() — «در دسترس» یعنی مدار باز نیست.
     * توجه: half_open هم «در دسترس» شمرده می‌شود (پروب مجاز است).
     */
    public function isAvailable(string $serviceName): bool;

    /**
     * ثبت موفقیت دستی (برای فراخواننده‌هایی که operation را بیرون از call() اجرا
     * می‌کنند): مدار را به CLOSED reset می‌کند (پاک‌شدن شمارندهٔ شکست و opened_at).
     */
    public function reportSuccess(string $serviceName): void;

    /**
     * ثبت شکست دستی: شمارندهٔ اتمیک را افزایش می‌دهد و در رسیدن به آستانه مدار را
     * می‌بندد (OPEN)؛ در حالت HALF_OPEN فوراً re-trip می‌کند. شکستِ ثبتِ شکست
     * (state-store قطع) هرگز استثنا به فراخواننده نمی‌دهد — فقط لاگ می‌شود.
     */
    public function reportFailure(string $serviceName): void;
}
