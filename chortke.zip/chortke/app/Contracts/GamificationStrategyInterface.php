<?php

declare(strict_types=1);

namespace App\Contracts;

use App\Enums\ModuleContext;

/**
 * قرارداد استراتژی‌های گیمیفیکیشن و تعاملات
 */
interface GamificationStrategyInterface
{
    /**
     * اجرای منطق استراتژی
     * 
     * @param object $user کاربری که اکشن را انجام داده یا مشمول استراتژی است
     * @param ModuleContext $context ماژولی که استراتژی در آن اجرا می‌شود
     * @param array<string, mixed> $payload دیتای اضافی مورد نیاز برای محاسبه (مثل مبلغ سرمایه‌گذاری، نوع اکشن)
     * @return float|int مقدار محاسبه شده برای تغییرات (مثلا +10 XP یا -5 Trust)
     *
     * FIX-P3-CFG-051 (MODIFY — داک‌بلاک، بدون تغییر امضا): قید دامنهٔ خروجی —
     *   - مقدار باید «متناهی و معتبر» باشد: NAN/INF و اشباع float ممنوع
     *     (مقدار مستقیماً به لجر امتیاز/Trust و پروجکشن users می‌رود).
     *   - علامت دلخواه است (دلتای مثبت پاداش، منفی جریمه/decay) اما «کران» را
     *     استراتژی تعیین نمی‌کند؛ مصرف‌کننده (ScoreCommandService::applyDelta)
     *     هر دلتا را با کف/سقف دامنهٔ خودش clamp می‌کند (ScoreDomainPolicy؛
     *     مثلاً کف منفی دامنهٔ Trust و ذخیرهٔ مقدار pre-clamp در audit trail).
     *   - پس استراتژی‌ها اجازه دارند مقدار خامِ منطقی برگردانند، ولی نباید به
     *     عبور از کرانه‌ها تکیه کنند: مصرف‌کننده دلتا را خط‌به‌خط اعمال نمی‌کند.
     */
    public function calculate(object $user, ModuleContext $context, array $payload = []): float|int;
    
    /**
     * مشخص می‌کند این استراتژی برای کدام نوع از متریک‌هاست
     */
    public function getMetricType(): \App\Enums\MetricType;
}
