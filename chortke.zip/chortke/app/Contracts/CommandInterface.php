<?php

namespace App\Contracts;

/**
 * Command Interface برای دستورات CLI
 *
 * 📜 قرارداد واقعی (وضعیت موجود، نه ادعا): CliDispatcher فرمان‌ها را بدون نیاز
 * به این اینترفیس ثبت می‌کند و اکثر فرمان‌ها متد handle یا سازنده‌ی اختصاصی
 * دارند. پیاده‌سازی این اینترفیس اختیاری است (تنها ۳ فرمان از آن استفاده
 * می‌کنند)؛ «الزام» قبلی هرگز enforce نشده بود و برداشته شد.
 */
interface CommandInterface
{
    /**
     * اجرای دستور
     *
     * FIX-C61 (یافتهٔ ۶۱): خروجی int به‌جای void — قبلاً امضای void عملاً
     * امکان گزارش کد خروج به dispatcher/cron/supervisor را از فرمان‌های
     * منقاد به اینترفیس می‌گرفت، در حالی که dispatcher خودش (normalizeExitCode)
     * int و ['exit_code' => int] را پشتیبانی می‌کند. قرارداد: ۰ = موفق،
     * غیرصفر = شکست.
     *
     * @param array<string, mixed> $args آرگومان‌های دستور
     * @return int کد خروج (۰ = موفق)
     */
    public function run(array $args = []): int;
}