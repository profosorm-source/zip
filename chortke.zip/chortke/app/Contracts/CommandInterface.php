<?php

namespace App\Contracts;

/**
 * Command Interface برای دستورات CLI
 *
 * 📜 قرارداد واقعی (وضعیت موجود، نه ادعا): CliDispatcher فرمان‌ها را بدون نیاز
 * به این اینترفیس ثبت می‌کند و اکثر فرمان‌ها متد handle یا سازنده‌ی اختصاصی
 * دارند. پیاده‌سازی این اینترفیس اختیاری است (تنها ۳ فرمان از آن استفاده
 * می‌کنند)؛ «الزام» قبلی هرگز enforce نشده بود و برداشته شد.
 */
interface CommandInterface
{
    /**
     * اجرای دستور
     *
     * @param array<string, mixed> $args آرگومان‌های دستور
     * @return void
     */
    public function run(array $args = []): void;
}