<?php

namespace App\Contracts;

/**
 * Contract برای تمام سیستم‌های تبلیغاتی
 *
 * این interface تمام سیستم‌های تبلیغاتی را یکسان‌سازی می‌کند:
 * - CustomTask, SeoAd, Banner, Vitrine, StoryPromotion, AdTube/Influencer
 *
 * FIX-C53 (یافتهٔ ممیزی ۵۳): شکل خروجی اجباری و واحد همهٔ متدهای خروجی‌دهنده،
 * همان دو شکل استاندارد AdapterBase است و کلیدهای زیر در آن «اجباری»اند:
 *   موفقیت: array{success: true,  message: string, data: array<string, mixed>}
 *   خطا:    array{success: false, message: string, errors: array<int|string, mixed>}
 * قرارداد قبلی (['success','id','message'] در create و ['success','transaction_id',...]
 * در processPayment) با پیاده‌سازی‌ها هم‌خوان نبود و فراخواننده مجبور بود کلیدهای
 * چندگانه (data.id / ad_id) را حدس بزند. identifier اصلی آگهی فقط داخل data.id است
 * (successResponse('...', ['id' => $id])) و فراخوانندهٔ مرجع AdSystemManager
 * همین را می‌خواند. برخورد با کلید مفقود «موفقیت» تلقی نمی‌شود: فراخواننده موظف است
 * "empty($result['success'])" را شکست بگیرد (الگوی AdsBudgetSettlementService).
 *
 * FIX-P3-CFG-030 (docblock-only): پین نوعی همان دو پاکت به‌عنوان @phpstan-type —
 * هر متد جدید این interface و هر adapter تازه باید یکی از همین دو type alias را
 * برگرداند؛ پاکت ناقص (success بدون data/errors) از دید قرارداد «موفقیت» نیست.
 *
 * @phpstan-type AdSuccessEnvelope array{success: true, message: string, data: array<string, mixed>}
 * @phpstan-type AdErrorEnvelope array{success: false, message: string, errors: array<int|string, mixed>}
 *
 * FIX-CFG028 (یافتهٔ CFG-028): نقشهٔ سطح قرارداد — زنده در برابر مرده — پس از
 * grep همهٔ پیاده‌سازی‌ها (۶ آداپتور: AdSocial/CustomTask/Banner/AdTube/
 * NotificationAd/SeoAd) و فراخوانندهٔ مرجع (AdSystemManager):
 *
 *   سطح زنده (active surface) — پشتیبانی‌شده و مصرف عمومی:
 *     - create() / validate()   → مسیر اصلی ساخت آگهی؛ خروجی، پاکت اجباری
 *                                 AdapterBase::successResponse/errorResponse است
 *                                 (کلیدهای success/message/data یا errors).
 *     - calculateCost()         → مسیر مالی زندهٔ کمیسیون؛ خروجی numeric-string
 *                                 دهدهی (Money::fromString؛ ممنوعیت float).
 *     - getType()               → شناسهٔ سیستم برای factory/registry.
 *
 *   سطح مرده (dead surface) — صفر call-site در کل repo؛ نگه‌داری فقط برای
 *   سازگاری و با @deprecated صریح (حذف نیازمند sign-off):
 *     - isExpired()  (همهٔ آداپتورها، بی‌خطر)   → @deprecated
 *     - getStatus()  (خواندنی، بی‌خطر)          → @deprecated
 *     - track()      (مسیر دومِ consumeDeliveryBudget؛ دبل-کسر بالقوه) → @deprecated
 *     - processPayment() (خطرناک‌ترین عضو؛ پیاده‌سازی‌های پولی اکنون LogicException
 *       می‌دهند — fail-loud)                     → @deprecated
 *   هرگونه متد جدید در این interface نباید بدون شکل پاکت استاندارد بالا اضافه شود.
 */
interface AdSystemContract
{
    /**
     * ایجاد آگهی/تسک جدید
     *
     * FIX-C53 (یافتهٔ ۵۳): شکل خروجی با استاندارد AdapterBase هم‌راستا شد —
     * شناسهٔ آگهی فقط داخل data.id است (قبلاً داک‌بلاک ['success','id','message']
     * می‌گفت که با پیاده‌سازی‌ها نمی‌خواند و caller مجبور به حدس چندکلیدی بود).
     *
     * @param int $userId کاربر ایجادکننده
     * @param array<string, mixed> $data داده‌های آگهی
     * @return AdSuccessEnvelope|AdErrorEnvelope
     *         success=true ⇒ data.id = شناسهٔ آگهی (int)
     */
    public function create(int $userId, array $data): array;

    /**
     * بررسی اعتبار داده‌های آگهی
     *
     * FIX-C53 (یافتهٔ ۵۳): شکل خروجی اجباری استاندارد AdapterBase.
     *
     * @param array<string, mixed> $data داده‌های آگهی
     * @param bool $isUpdate آیا این یک بروزرسانی است؟
     * @return AdErrorEnvelope شکل استاندارد AdapterBase —
     *         valid=true وقتی errors خالی است (هم‌قرارداد AdapterBase::validate());
     *         فراخواننده باید errors را بررسی کند نه کلیدهای ساختگی id/valid.
     */
    public function validate(array $data, bool $isUpdate = false): array;

    /**
     * بررسی انقضای آگهی
     *
     * FIX-R36-W3 (F-A19d-03): سطح قرارداد مرده است — صفر call-site در کل repo
     * (AdSystemManager فقط create/validate/calculateCost را صدا می‌زند).
     * @deprecated Dead contract surface (r36 audit F-A19d-03) — نگه‌داری فقط برای
     *             سازگاری; حذف از قرارداد نیازمند sign-off (پیشنهاد cleanup-wave).
     * @param int $adId شناسه آگهی
     * @return bool
     */
    public function isExpired(int $adId): bool;

    /**
     * محاسبه هزینه/کمیسیون سایت
     *
     * FIX-CFG028 (یافتهٔ CFG-028): invariant مالی این متد — $amount ورودی و خروجی
     * هر دو numeric-string دهدهی هستند (مثل '1500.00000000') و محاسبه فقط با
     * Money::fromString/bccomp انجام می‌شود؛ float و رشتهٔ غیرعددی ممنوع.
     * این تنها مسیر «زندهٔ» مالی این قرارداد است؛ برداشت واقعی بودجه هرگز از
     * این interface انجام نمی‌شود (تسویه: AdsBudgetSettlementService/seo-payout).
     *
     * @param string $amount مبلغ اولیه (numeric-string دهدهی)
     * @param array<string, mixed> $context متادیتای اضافی
     * @return string numeric-string دهدهی (همان مقیاس Money)
     */
    public function calculateCost(string $amount, array $context = []): string;

    /**
     * پردازش پرداخت/کسب بودجه
     *
     * FIX-R36-W3 (F-A19d-03): خطرناک‌ترین عضو سطح مردهٔ قرارداد — پیاده‌سازی
     * SeoAdAdapter برداشت واقعی wallet داشت و Banner/NotificationAdapter::track
     * consumeDeliveryBudget واقعی صدا می‌زد؛ مسیر دومِ برداشتِ بدون escrow/کسر
     * بودجهٔ متمرکز. تسویهٔ واقعی: AdSystemManager + AdsBudgetSettlementService +
     * seo-payout. پیاده‌سازی‌های پولی این متد اکنون LogicException می‌دهند.
     * @deprecated Dead contract surface (r36 audit F-A19d-03) — حذف نیازمند sign-off.
     * @param int $adId شناسه آگهی
     * @param int $userId آیدی کاربر
     * @param string $amount مبلغ
     * @param string $currency واحد پول
     * @return AdSuccessEnvelope|AdErrorEnvelope
     *         FIX-C53 (یافتهٔ ۵۳): شکل استاندارد AdapterBase — هر پیاده‌سازی موفقیت
     *         ساختگی (بدون کلیدهای اجباری) ممنوع؛ پیاده‌سازی‌های فعلی LogicException می‌دهند.
     */
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array;

    /**
     * ردیابی تعاملات (کلیک، نمایش، تکمیل)
     *
     * FIX-R36-W3 (F-A19d-03): مسیر دومِ consumeDeliveryBudget (دبل-کسر بالقوه) —
     * صفر call-site؛ تسویهٔ زنده فقط از AdsBudgetSettlementService.
     * @deprecated Dead contract surface (r36 audit F-A19d-03) — حذف نیازمند sign-off.
     * @param int $adId شناسه آگهی
     * @param string $eventType نوع رویداد (click, view, complete)
     * @param int|null $userId آیدی کاربر (اختیاری)
     * @return AdSuccessEnvelope|AdErrorEnvelope
     *         FIX-C53 (یافتهٔ ۵۳): شکل استاندارد AdapterBase — آرایهٔ خالی/بدون کلید success ممنوع.
     */
    public function track(int $adId, string $eventType, ?int $userId = null): array;

    /**
     * دریافت وضعیت آگهی
     *
     * FIX-R36-W3 (F-A19d-03): صفر call-site (خواندنی و بی‌خطر، ولی نگه‌داریِ
     * موازی حقیقت).
     * @deprecated Dead contract surface (r36 audit F-A19d-03) — حذف نیازمند sign-off.
     * @param int $adId شناسه آگهی
     * @return array<string, mixed>|null
     */
    public function getStatus(int $adId): ?array;

    /**
     * دریافت نوع سیستم
     * 
     * @return string
     */
    public function getType(): string;
}
