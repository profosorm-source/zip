<?php

namespace App\Contracts;

/**
 * Contract برای تمام سیستم‌های تبلیغاتی
 * 
 * این interface تمام سیستم‌های تبلیغاتی را یکسان‌سازی می‌کند:
 * - CustomTask, SeoAd, Banner, Vitrine, StoryPromotion, AdTube/Influencer
 */
interface AdSystemContract
{
    /**
     * ایجاد آگهی/تسک جدید
     * 
     * @param int $userId کاربر ایجادکننده
     * @param array<string, mixed> $data داده‌های آگهی
     * @return array<string, mixed> ['success' => bool, 'id' => int|null, 'message' => string]
     */
    public function create(int $userId, array $data): array;

    /**
     * بررسی اعتبار داده‌های آگهی
     * 
     * @param array<string, mixed> $data داده‌های آگهی
     * @param bool $isUpdate آیا این یک بروزرسانی است؟
     * @return array<string, mixed> ['valid' => bool, 'errors' => array]
     */
    public function validate(array $data, bool $isUpdate = false): array;

    /**
     * بررسی انقضای آگهی
     *
     * FIX-R36-W3 (F-A19d-03): سطح قرارداد مرده است — صفر call-site در کل repo
     * (AdSystemManager فقط create/validate/calculateCost را صدا می‌زند).
     * @deprecated Dead contract surface (r36 audit F-A19d-03) — نگه‌داری فقط برای
     *             سازگاری; حذف از قرارداد نیازمند sign-off (پیشنهاد cleanup-wave).
     * @param int $adId شناسه آگهی
     * @return bool
     */
    public function isExpired(int $adId): bool;

    /**
     * محاسبه هزینه/کمیسیون سایت
     * 
     * @param string $amount مبلغ اولیه
     * @param array<string, mixed> $context متادیتای اضافی
     * @return string
     */
    public function calculateCost(string $amount, array $context = []): string;

    /**
     * پردازش پرداخت/کسب بودجه
     *
     * FIX-R36-W3 (F-A19d-03): خطرناک‌ترین عضو سطح مردهٔ قرارداد — پیاده‌سازی
     * SeoAdAdapter برداشت واقعی wallet داشت و Banner/NotificationAdapter::track
     * consumeDeliveryBudget واقعی صدا می‌زد؛ مسیر دومِ برداشتِ بدون escrow/کسر
     * بودجهٔ متمرکز. تسویهٔ واقعی: AdSystemManager + AdsBudgetSettlementService +
     * seo-payout. پیاده‌سازی‌های پولی این متد اکنون LogicException می‌دهند.
     * @deprecated Dead contract surface (r36 audit F-A19d-03) — حذف نیازمند sign-off.
     * @param int $adId شناسه آگهی
     * @param int $userId آیدی کاربر
     * @param string $amount مبلغ
     * @param string $currency واحد پول
     * @return array<string, mixed> ['success' => bool, 'transaction_id' => int|null, 'message' => string]
     */
    public function processPayment(int $adId, int $userId, string $amount, string $currency): array;

    /**
     * ردیابی تعاملات (کلیک، نمایش، تکمیل)
     *
     * FIX-R36-W3 (F-A19d-03): مسیر دومِ consumeDeliveryBudget (دبل-کسر بالقوه) —
     * صفر call-site؛ تسویهٔ زنده فقط از AdsBudgetSettlementService.
     * @deprecated Dead contract surface (r36 audit F-A19d-03) — حذف نیازمند sign-off.
     * @param int $adId شناسه آگهی
     * @param string $eventType نوع رویداد (click, view, complete)
     * @param int|null $userId آیدی کاربر (اختیاری)
     * @return array<string, mixed> ['success' => bool, 'message' => string]
     */
    public function track(int $adId, string $eventType, ?int $userId = null): array;

    /**
     * دریافت وضعیت آگهی
     *
     * FIX-R36-W3 (F-A19d-03): صفر call-site (خواندنی و بی‌خطر، ولی نگه‌داریِ
     * موازی حقیقت).
     * @deprecated Dead contract surface (r36 audit F-A19d-03) — حذف نیازمند sign-off.
     * @param int $adId شناسه آگهی
     * @return array<string, mixed>|null
     */
    public function getStatus(int $adId): ?array;

    /**
     * دریافت نوع سیستم
     * 
     * @return string
     */
    public function getType(): string;
}
