<?php

declare(strict_types=1);

namespace App\Contracts;

interface NotificationChannelInterface
{
    /**
     * Get the unique string identifier for this channel (e.g., 'sms', 'email', 'fcm').
     */
    public function getName(): string;

    /**
     * Send the notification through the channel.
     *
     * FIX-P3-CFG-056: قرارداد bool — true یعنی «اعلان به ارائه‌دهنده/کانال سپرده
     * شد و رد نشد» (hand-off accepted: HTTP 2xx از درگاه، enqueue موفق FCM/SMS،
     * یا ثبت موفق در کانال لاگ). true به هیچ معنایی «تحویل‌شده به کاربر نهایی»
     * نیست: تحویل async است و توسط این قرارداد تضمین نمی‌شود (bounce/delay/
     * opt-out بعدی خارج از قراردادند). فراخواننده‌ها اجازه ندارند true را به
     * عنوان delivered در analytics/گارانتی ثبت کنند — برای وضعیت تحویل واقعی از
     * NotificationTracker/وبهوک‌های وضعیت استفاده کنید. false یعنی hand-off
     * رد شد یا کانال در دسترس نبود.
     *
     * @param int $userId The recipient's user ID.
     * @param string $title The notification title.
     * @param string $message The notification message body.
     * @param array<string, mixed>|null $data Additional contextual data.
     * @param string|null $imageUrl URL of an image attachment.
     * @param string|null $actionUrl Call-to-action URL.
     * @return bool True = پذیرفته‌شده توسط کانال/ارائه‌دهنده (تحویل نهایی تضمین نمی‌شود)، false = رد شد.
     */
    public function send(
        int $userId,
        string $title,
        string $message,
        ?array $data = null,
        ?string $imageUrl = null,
        ?string $actionUrl = null
    ): bool;
}
