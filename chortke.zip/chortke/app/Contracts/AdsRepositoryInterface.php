<?php

declare(strict_types=1);

namespace App\Contracts;

use Core\QueryBuilder;

/**
 * قرارداد مخزن تبلیغات
 *
 * FIX-P3-CFG-031 (MODIFY — docblock-only): نکات اعتماد قرارداد —
 *
 * 1) coupling به Core\QueryBuilder عمدی است: در این کدبیس Core همان هستهٔ
 *    فریم‌ورک است (الگوی مشترک همهٔ قراردادها) و این interface فقط passthrough
 *    تایپ‌شدهٔ Model (core/Model.php:843 where / :854 whereNull / :864 orderBy)
 *    روی جدول ads است؛ انتزاع کامل QueryBuilder متناسب این کدبیس نیست.
 *
 * 2) «شناسه‌های خام» — $column و $direction مستقیماً داخل SQL جایگذاری می‌شوند
 *    (نه به‌عنوان bind param) و بر عکسِ مقدارها، هیچ‌گاه توسط مخزن quote نمی‌شوند:
 *      - $column فقط باید نام ستونِ کد-مالک باشد (لیست ثابت در کد، مثل
 *        Filterable::$filterable یا ستون‌های known جدول ads)؛ هرگز رشتهٔ ورودی
 *        کاربر را به where/whereNull/orderBy پاس ندهید.
 *      - $direction فقط 'ASC' یا 'DESC' (پیاده‌سازی مرجع هر مقدار دیگر را
 *        بدون تغییر پاس می‌دهد — مسئولیت نرمال‌سازی با فراخواننده است).
 *    مقدارهای شرط ($value و رشتهٔ operator) به‌صورت parameterized بایند می‌شوند
 *    و تزریق‌پذیر نیستند؛ سطح تزریق فقط همان شناسه‌های بالاست.
 */
interface AdsRepositoryInterface
{
    public function find(int $id): ?object;

    /** @param array<string, mixed> $data */
    public function update(int $id, array $data): bool;

    /**
     * @param string $column نام ستون کد-مالک (هرگز ورودی کاربر — نگاه سربرگ)
     * @param string $operatorOrValue عملگر مقایسه ('=', '>', ...) یا خود مقدار
     * @param mixed $value مقدار شرط (parameterized بایند می‌شود)
     */
    public function where(string $column, string $operatorOrValue = '=', mixed $value = null): QueryBuilder;

    /** @param string $column نام ستون کد-مالک (هرگز ورودی کاربر — نگاه سربرگ) */
    public function whereNull(string $column): QueryBuilder;

    /**
     * @param string $column نام ستون کد-مالک (هرگز ورودی کاربر — نگاه سربرگ)
     * @param string $direction فقط 'ASC' یا 'DESC'
     */
    public function orderBy(string $column, string $direction = 'ASC'): QueryBuilder;
}
