<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * قرارداد گزارش خطای دیتابیس
 *
 * این interface وابستگی core/Database.php به لایه App را معکوس می‌کند (DIP).
 * هر سیستم مانیتورینگ (Sentry, Datadog, ...) می‌تواند این قرارداد را پیاده‌سازی کند.
 *
 * FIX-P3-CFG-041 (MODIFY — invariantهای الزامی هر پیاده‌سازی):
 * 1) «هرگز نمی‌اندازد» (MUST NOT throw): گزارش‌گیری نباید هرگز مسیر اصلی را
 *    بشکند — حتی وقتی خودِ مانیتورینگ خراب است (شبکه قطع، rate-limit، ...).
 *    پیاده‌سازی باید هر خطای داخلی را بلعیده و به لاگ محلی (error_log/fallback)
 *    بفرماید. این invariant در تنها فراخوانندهٔ production (core/Database.php
 *    captureException wrapper با گارد reentry و fallbackLog) هم به‌صورت
 *    دفاعی اعمال شده؛ این داک‌بلاک همان قرارداد را به سطح interface می‌آورد.
 * 2) «redaction الزامی» (MUST redact): پیلوودها هرگز نباید PII/اعتبارنامه
 *    خام حمل کنند — bind params و مقادیر حساس context نباید درج شوند
 *    (فراخوانندهٔ مرجع فقط params_count می‌فرستد و interpolated_sql را به
 *    ۱۰۰۰ کاراکتر می‌بُرد)؛ پیاده‌سازی موظف است رمز/توکن/PII را از
 *    $context و message ماسک کند و هرگز exception/response خام را ثبت نکند.
 */
interface DatabaseErrorReporter
{
    /**
     * ثبت Exception دیتابیس (مثل query failure, deadlock)
     *
     * @param \Throwable $exception
     * @param array<string, mixed> $context اطلاعات اضافی (sql, params, ...)
     * @param string $level سطح خطا (error, critical, ...)
     * @param int|null $userId شناسه کاربر (اختیاری)
     * @return string|null شناسه خطا (مثل Sentry event ID)
     */
    public function captureException(\Throwable $exception, array $context = [], string $level = 'error', ?int $userId = null): ?string;

    /**
     * ثبت پیام دیتابیس (مثل slow query warning)
     *
     * @param string $message
     * @param string $level سطح (info, warning, error)
     * @param array<string, mixed> $context اطلاعات اضافی
     * @param int|null $userId شناسه کاربر (اختیاری)
     * @return string|null
     */
    public function captureMessage(string $message, string $level = 'info', array $context = [], ?int $userId = null): ?string;
}
