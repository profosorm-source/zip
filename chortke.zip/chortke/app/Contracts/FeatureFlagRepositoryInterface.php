<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * Feature Flag Repository Interface
 * 
 * تعریف قراردادی برای مدیریت Feature Flags
 * پشتیبانی می‌کند: targeting پیشرفته، زمان‌بندی، درصد کاربران، caching
 */
interface FeatureFlagRepositoryInterface
{
    /**
     * بررسی آیا یک فیچر برای کاربر خاص فعال است
     * شامل: targeting (role, country, plan, device, route)، زمان‌بندی، درصد کاربران
     */
    /** @param array<string, mixed>|null $context */
    public function isEnabled(string $name, ?int $userId = null, ?array $context = null): bool;

    /**
     * بررسی چند فیچر به صورت AND
     */
    /** @param list<string> $names @param array<string, mixed>|null $context */
    // 🛡️ FIX-S34-DEAD (S33-P3): areEnabled/getEnabled/enable/disable از قرارداد حذف شدند —
    // پیاده‌سازی‌های آن‌ها در FeatureFlagService صفر فراخواننده داشتند (پاس A زیربچ ۲) و حذف شدند.
    /**
     * دریافت تمام فیچرها
     */
    /** @return list<\App\Models\FeatureFlag> */
    public function getAll(): array;

    /**
     * یافتن یک فیچر با نام
     *
     * FIX-P3-CFG-050: coupling به مدل concrete (\App\Models\FeatureFlag) در این
     * کدبیس عمدی و پذیرفته‌شده است (مدل، رکورد جدول feature_flags است و همهٔ
     * قراردادهای مخزن این الگو را دارند) — قرارداد موازی مدل-مستقل اضافه نشد.
     */
    public function findByName(string $name): ?\App\Models\FeatureFlag;

    /**
     * دریافت مقدار پارامتر فیچر (برای اعداد dynamic)
     *
     * FIX-P3-CFG-050: قرارداد مقدار بازگشتی — کلید 'value' از config_values
     * (JSON) همان فیچر خوانده می‌شود (FeatureFlagService::getValue → getConfigAll):
     *   - types پشتیبانی‌شده: هر آنچه json_decode تولید می‌کند — string، int،
     *     float، bool، null و آرایه (list/assoc)؛ اشیای تو در تو هم آرایه برمی‌گردند.
     *   - فیچر ناموجود یا config_values ناموجود/غیر-JSON ⇒ همان $default پاس‌داده‌شده
     *     (بدون coercion، بدون exception).
     *   - فراخواننده مسئول validate/narrow نوع است (مثلاً is_numeric / toInt)
     *     قبل از استفاده در منطق مالی یا bounds؛ قرارداد، نوع را تضمین نمی‌کند.
     *
     * @param mixed $default مقدار بازگشتی وقتی فیچر/کلید value وجود ندارد
     */
    public function getValue(string $name, mixed $default = null): mixed;

    /**
     * پاک کردن cache فیچرها
     */
    public function clearCache(): void;
}
