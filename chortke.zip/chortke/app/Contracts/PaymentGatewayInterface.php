<?php

namespace App\Contracts;

/**
 * PaymentGatewayInterface - قرارداد مشترک برای همه پردازشگرهای پرداخت
 *
 * این interface تضمین می‌کند که همه gatewayها متدهای یکسانی داشته باشند
 *
 * ─── FIX-CFG058 (یافتهٔ CFG-058): واحد مقداری کانونی قرارداد ───────────────
 * واحد کانونیِ همهٔ پارامترهای $amount در این قرارداد، «numeric-string واحد بزرگ
 * (major unit) تومان/IRT» است — مثال '1500000' — با این الزامات:
 *   - هرگز float (ورودی، خروجی، محاسبه)؛ ارقام اعشاری تومان مجاز نیست.
 *   - مقایسهٔ نهایی مبالغ (verify) همیشه در تومان و با bccomp انجام می‌شود.
 *   - تبدیل واحد فقط و فقط در مرز آداپتور مجاز است و در همان فایل مستند می‌شود:
 *       ZarinPal  → تومان را as-is می‌فرستد (بدون تبدیل).
 *       NextPay   → تومان را as-is می‌فرستد (بدون تبدیل).
 *       IDPay     → خروجی: تومان ×۱۰ = ریال (bcmul)؛ پاسخ بانک: ریال ÷۱۰ = تومان
 *                   (bcdiv scale 4) — همان قانون W4-D/H-2 در خود آداپتور.
 *       DgPay     → مانند IDPay (تومان ×۱۰ برای درگاه، ÷۱۰ در verify).
 *   هر آداپتور جدید موظف است مبالغ ورودی را با
 *   BasePaymentGateway::normalizePositiveTomanAmount() نرمال کند (ردِ منفی/صفر/
 *   اعشاری/غیرعددی پیش از هر تماس بیرونی) و اگر واحد مستند درگاه غیر از تومان
 *   است، تبدیل را فقط در مرز خودِ آداپتور انجام دهد.
 */
interface PaymentGatewayInterface
{
    /**
     * ایجاد پرداخت جدید
     *
     * FIX-CFG058: $amount numeric-string تومان (واحد کانونی قرارداد — بالا را ببینید).
     *
     * @param string $amount مبلغ (numeric-string تومان؛ float و اعشار ممنوع)
     * @param string $description توضیحات
     * @param string $callbackUrl آدرس بازگشت
     * @param array<string, mixed> $options اختیاری (ایمیل، موبایل و ...)
     * @return array<string, mixed> نتیجه شامل success, authority, message
     *         (success=true ⇒ کلیدهای authority و url نیز پر می‌شوند؛ url مقصد
     *         پرداخت کاربر است)؛ خطای درگاه در پاکت success=false برمی‌گردد
     *         نه به‌صورت استثنا.
     */
    public function createPayment(string $amount, string $description, string $callbackUrl, array $options = []): array;

    /**
     * بررسی وضعیت پرداخت (Verify payment with gateway)
     *
     * FIX-CFG058: $amount همیشه numeric-string «تومان» است (واحد کانونی)؛ هر
     * تبدیل ریالی، داخل آداپتور و پیش/پس از تماس بیرونی انجام می‌شود.
     * تأییدِ سمت‌سرور همین متد، تنها منبع حقیقت پرداخت است — دادهٔ callback
     * هرگز به‌تنهایی مبنای اعتبار (credit) قرار نمی‌گیرد (بخش verifyCallback).
     *
     * @param string $authority شناسه پرداخت (Transaction ID from gateway)
     * @param string $amount مبلغ تراکنش به تومان جهت تطابق (Amount in TOMAN - IRT)
     *                      - ZarinPal: sends Toman as-is
     *                      - NextPay: sends Toman as-is
     *                      - IDPay: doesn't send amount (API limitation)
     *                      - DgPay: converts Toman to Rial (*10)
     * @return array<string, mixed> نتیجه شامل success, status, amount, refId؛
     *         خطای گذرا (شبکه/timeout/مدار باز) با کلید transient=true علامت
     *         می‌خورد تا فراخواننده retry کند نه رد قطعی.
     * @throws \InvalidArgumentException authority خالی یا مبلغ نامعتبر
     */
    public function verifyPayment(string $authority, string $amount): array;

    /**
     * تایید اعتبار callback دریافتی از gateway
     *
     * FIX-CFG059 (یافتهٔ CFG-059) — قرارداد callback:
     *   - امضای پیلود: قبل از اعتماد به هر فیلدی از $callbackData، صحت امضا باید
     *     بررسی شود (HMAC-SHA256 با hash_equals در BasePaymentGateway).
     *     آداپتورهایی که امضا می‌فرستند usesSignedCallbacks()=true دارند؛ برای
     *     درگاه‌های بدون امضا (اکثر درگاه‌های ایرانی) این گیت true برمی‌گرداند و
     *     صحت تراکنش الزاماً با تأیید سمت‌سرور verifyPayment + nonce یک‌بارمصرف
     *     (H-06) محقق می‌شود — یعنی trueِ این متد هرگز به‌تنهایی مجوزِ اعتبار
     *     (credit) نیست و فراخواننده (PaymentCommandService) هر دو گیت را
     *     اجرا می‌کند.
     *   - replay protection: این متد stateless است و خودش تکرار callback را رد
     *     نمی‌کند؛ جلوگیری از replay/دوبار-crediting مسئولیت فراخواننده است
     *     (وضعیت one-time ردیف پرداخت + idempotency key درختوان پرداخت).
     *   - secret: در هر محیطی secret پیکربندی‌نشده ممنوع است؛ در production کلید
     *     کوتاه‌تر از ۳۲ کاراکتر نیز ممنوع است (شکست brute-force امضا).
     *
     * @param array<string, mixed> $callbackData داده‌های callback
     * @return bool true اگر callback معتبر باشد
     * @throws \RuntimeException secret مفقود (هر محیط) یا ضعیف‌تر از ۳۲ کاراکتر (production)
     */
    public function verifyCallback(array $callbackData): bool;

    /**
     * برگرداندن پرداخت (در صورت امکان)
     *
     * FIX-CFG059 (یافتهٔ CFG-059) — قرارداد refund:
     *   - وضعیت فعلی: هیچ آداپتور فعلی refund واقعی ندارد؛ همه پاکت
     *     array{success: false, message: string} برمی‌گردانند (بدون اثر جانبی).
     *   - هر پیاده‌سازی آینده موظف است: (الف) refund را idempotent بر اساس
     *     $authority کند — تکرار refund همان authority هرگز دوبار وجه برنمی‌گرداند
     *     و همان نتیجهٔ اول را بازپخش می‌کند؛ (ب) فقط پس از verifyPayment سمت‌سرور
     *     و تطابق مبلغِ تومانی کانونی (FIX-CFG058) اجرا شود؛ (ج) نتیجه را در
     *     پاکت استاندارد success/message (+ شناسهٔ refund درگاه در صورت موفقیت)
     *     برگرداند.
     *
     * @param string $authority شناسه پرداخت
     * @return array<string, mixed> نتیجه برگرداندن (پاکت success/message)
     */
    public function refundPayment(string $authority): array;

    /**
     * نام gateway
     */
    public function getName(): string;

    /**
     * آیا gateway فعال است
     */
    public function isActive(): bool;
}
