<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * MetricsCollectorInterface — قرارداد جمع‌آوری متریک (FIX-C74/75/76)
 *
 * 📜 قرارداد واحد (قبلاً ضمنی و مستندنشده بود):
 *
 * ۱) واحد زمان (FIX-C74):
 *    - `timing()` همیشه «ثانیه» (float؛ مثلاً delta microtime(true)) می‌گیرد.
 *      هیچ متدی میلی‌ثانیه نمی‌پذیرد — مبدل مسئولیت فراخواننده است.
 *
 * ۲) نام‌گذاری متریک (FIX-C75):
 *    - نام متریک: الگوی dot-namespaced حروف کوچک — `^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$`
 *      (مثال: fcm.send.success) — هم‌سو با تنها مبدل فعال فعلی (FcmNotificationAdapter).
 *    - کلیدِ tag: snake_case حروف کوچک — `^[a-z][a-z0-9_]*$`
 *    - مقدار tag: اسکالر محدود (بدون ورودیِ آزادِ کاربر — ضد انفجار cardininality)
 *
 * ۳) سقف cardinality (FIX-C76):
 *    - هر پیاده‌سازی باید تعداد سری‌های فعالِ (metric+tags) را محدود کند؛
 *      پس از عبور از سقف (پیش‌فرض ۱۰٬۰۰۰)، tagها دور ریخته و به سریِ
 *      fallback `<metric>.cardinality_dropped` می‌روند (fail-soft — متریک
 *      هرگز نباید درخواست/جاب را بشکند).
 */
interface MetricsCollectorInterface
{
    /** @param array<string, scalar|null> $tags */
    public function increment(string $metric, array $tags = []): void;
    /** @param array<string, scalar|null> $tags */
    public function gauge(string $metric, float $value, array $tags = []): void;
    /**
     * @param float $seconds مدت‌زمان بر حسب «ثانیه» (delta microtime(true)) — FIX-C74
     * @param array<string, scalar|null> $tags
     */
    public function timing(string $metric, float $seconds, array $tags = []): void;

    /**
     * FIX-C74: تایمر کمکی — واحد «ثانیه» در یک نقطه متمرکز می‌شود.
     * Usage: $timer = $metrics->timer('fcm.dispatch.latency'); … $timer();
     *
     * @param array<string, scalar|null> $tags
     * @return callable فراخوانی = ثبت مدت از moment ساخت تا فراخوانی
     */
    public function timer(string $metric, array $tags = []): callable;
}
