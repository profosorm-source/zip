<?php

declare(strict_types=1);

namespace App\Contracts;

interface CurrencyServiceInterface
{
    public function getCurrentMode(): string;
    public function isIRT(): bool;
    public function isUSDT(): bool;
    public function getCurrencySymbol(?string $currency = null): string;

    /**
     * FIX-CFG040 (یافتهٔ CFG-040): این متد «فقط» قالب‌سازِ نمایشی (display-only) است.
     * پذیرش float در امضای آن مخصوص همین نمایش است (مثلاً نرخ محاسبه‌شدهٔ لحظه‌ای)
     * و هرگز مجوزِ float-math در مسیر پول نیست. هر عملیات مالی (مانده، واریز،
     * برداشت، انتقال، مقایسهٔ مبالغ) باید با numeric-string دهدهی و از طریق
     * WalletServiceInterface / Money (bccomp/bcadd — ممنوعیت float) انجام شود؛
     * خروجی این متد را به هیچ متد مالی پاس ندهید.
     *
     * FIX-P3-CFG-068 (docblock-only): راهنمای ورودی — امضا عمداً float|string
     * نگه داشته شد (پیاده‌سازی/تست‌های فعلی مقدار نمایشی float/int می‌فرستند و
     * باریک‌سازی به string-only فقط TypeError نمایشی می‌ساخت، نه حفاظت مالی):
     *   - هر مقدار از مسیر پول/DB numeric-string است: همان را مستقیم پاس بدهید
     *     (ترجیح اول؛ تبدیل float ⇄ string در display مقیاس را جابه‌جا می‌کند).
     *   - float فقط برای «نمایش مقدار محاسبه‌شدهٔ لحظه‌ای» (نرخ، سهم درآمد) است.
     *   - خروجی رشتهٔ نمایشی قالب‌بندی‌شده است (جداکنندهٔ هزارگان/نماد) و
     *     numeric-string معتبر برای parse/مقایسهٔ مالی «نیست» — بازخوانی ممنوع.
     *
     * @param float|string $amount مقدار نمایشی؛ برای مسیر مالی فقط numeric-string دهدهی معتبر است
     */
    public function formatAmount(float|string $amount, ?string $currency = null): string;
    // FIX-S34-DEAD (S33-P3): getSectionCurrency حذف شد — صفر فراخواننده؛ پیاده‌سازی مرده هم حذف شد
}
