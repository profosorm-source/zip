<?php

declare(strict_types=1);

namespace App\Contracts;

interface CurrencyServiceInterface
{
    public function getCurrentMode(): string;
    public function isIRT(): bool;
    public function isUSDT(): bool;
    public function getCurrencySymbol(?string $currency = null): string;
    public function formatAmount(float|string $amount, ?string $currency = null): string;
    // FIX-S34-DEAD (S33-P3): getSectionCurrency حذف شد — صفر فراخواننده؛ پیاده‌سازی مرده هم حذف شد
}
