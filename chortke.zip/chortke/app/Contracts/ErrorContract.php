<?php

namespace App\Contracts;

/**
 * ErrorContract - قالب استاندارد خطا برای «مسیر استثناهای گرفته‌شده در هسته»
 *
 * 📜 قرارداد واقعی (وضعیت موجود، نه ادعا): این قالب فقط توسط
 * core/ExceptionHandler ساخته می‌شود (خطاهای unhandled). کنترلرها پاسخ خطا را
 * خودشان می‌سازند: BaseApiController کد خطا را در data.error_code می‌گذارد و
 * کنترلرهای وب {success,message} یا flash+redirect دارند. ادعای «استاندارد
 * سراسر API و Web» با کد نمی‌خواند و حذف شد؛ یکسان‌سازی پاسخ HTTP یک تصمیم
 * آینده است (فاز زرد گزارش قراردادها).
 */
/**
 * @phpstan-type ErrorMeta array{trace_id: non-empty-string, timestamp: string}
 * @phpstan-type ErrorPayload array{
 *     success: false,
 *     message: non-empty-string,
 *     errors: array<string, mixed>,
 *     error_code: non-empty-string,
 *     code: int<400, 599>,
 *     details?: array<string, mixed>,
 *     meta: ErrorMeta
 * }
 */
class ErrorContract
{
    // FIX-C69 (یافتهٔ ۶۹): سقف‌های طول و ماسک خروجی — مسیر JSON قرارداد خطا قبلاً
    // هیچ سقفی روی message/details/fieldErrors و هیچ ماسک PII/راز نداشت (سقف‌ها
    // فقط در رندرهای HTML debug بودند). اکنون به‌صورت خود-نگه‌دارنده در همین
    // قرارداد اعمال می‌شود (بدون وابستگی به ExceptionHandler).
    private const MAX_MESSAGE_LENGTH = 300;
    private const MAX_STRING_LENGTH = 512;
    private const MAX_DETAILS_JSON_LENGTH = 4096;
    private const SENSITIVE_KEY_PATTERN = '/password|passwd|pass|secret|token|api[_-]?key|authorization|credential|card_number|cvv2?|pin|ssn|national[_-]?id/i';
    // HTTP Status Codes
    public const STATUS_BAD_REQUEST = 400;
    public const STATUS_UNAUTHORIZED = 401;
    public const STATUS_FORBIDDEN = 403;
    public const STATUS_NOT_FOUND = 404;
    public const STATUS_CONFLICT = 409;
    public const STATUS_UNPROCESSABLE = 422;
    public const STATUS_RATE_LIMITED = 429;
    public const STATUS_INTERNAL_ERROR = 500;

    // Error Codes (Business)
    public const CODE_VALIDATION_ERROR = 'VALIDATION_ERROR';
    public const CODE_UNAUTHORIZED = 'UNAUTHORIZED';
    public const CODE_FORBIDDEN = 'FORBIDDEN';
    public const CODE_NOT_FOUND = 'NOT_FOUND';
    public const CODE_CONFLICT = 'CONFLICT';
    public const CODE_RATE_LIMITED = 'RATE_LIMITED';
    public const CODE_INTERNAL_ERROR = 'INTERNAL_ERROR';
    
    // Business-specific error codes
    public const CODE_PAYMENT_FAILED = 'PAYMENT_FAILED';
    public const CODE_INSUFFICIENT_FUNDS = 'INSUFFICIENT_FUNDS';
    public const CODE_FRAUD_DETECTED = 'FRAUD_DETECTED';
    public const CODE_CONTENT_REJECTED = 'CONTENT_REJECTED';
    public const CODE_DUPLICATE_SUBMISSION = 'DUPLICATE_SUBMISSION';
    public const CODE_INVALID_PLATFORM = 'INVALID_PLATFORM';
    public const CODE_WALLET_ERROR = 'WALLET_ERROR';
    public const CODE_ESCROW_FAILED = 'ESCROW_FAILED';
    public const CODE_BACKUP_FAILED = 'BACKUP_FAILED';
    public const CODE_AUDIT_FAILED = 'AUDIT_FAILED';

    /** @var int<400, 599> */
    private int $statusCode;
    /** @var non-empty-string */
    private string $errorCode;
    /** @var non-empty-string */
    private string $message;
    /** @var array<string, mixed>|null */
    private ?array $details;
    /** @var array<string, mixed>|null */
    private ?array $fieldErrors;

    /**
     * Static factory for validation errors
     */
    /** @param array<string, mixed> $fieldErrors */
    public static function validation(string $message, array $fieldErrors = []): self
    {
        $error = new self(
            self::STATUS_UNPROCESSABLE,
            self::CODE_VALIDATION_ERROR,
            $message ?: 'Validation failed'
        );
        $error->fieldErrors = $fieldErrors;
        return $error;
    }

    /**
     * Static factory for unauthorized
     */
    public static function unauthorized(string $message = 'Unauthorized'): self
    {
        return new self(
            self::STATUS_UNAUTHORIZED,
            self::CODE_UNAUTHORIZED,
            $message
        );
    }

    /**
     * Static factory for forbidden
     */
    public static function forbidden(string $message = 'Forbidden'): self
    {
        return new self(
            self::STATUS_FORBIDDEN,
            self::CODE_FORBIDDEN,
            $message
        );
    }

    /**
     * Static factory for not found
     */
    public static function notFound(string $message = 'Not found'): self
    {
        return new self(
            self::STATUS_NOT_FOUND,
            self::CODE_NOT_FOUND,
            $message
        );
    }

    /**
     * Static factory for conflict
     */
    public static function conflict(string $message = 'Conflict'): self
    {
        return new self(
            self::STATUS_CONFLICT,
            self::CODE_CONFLICT,
            $message
        );
    }

    /**
     * Static factory for rate limited
     */
    public static function rateLimited(string $message = 'Rate limit exceeded'): self
    {
        return new self(
            self::STATUS_RATE_LIMITED,
            self::CODE_RATE_LIMITED,
            $message
        );
    }

    /**
     * Static factory for internal error
     */
    public static function internalError(string $message = 'Internal server error'): self
    {
        return new self(
            self::STATUS_INTERNAL_ERROR,
            self::CODE_INTERNAL_ERROR,
            $message
        );
    }

    /**
     * Static factory for payment failed
     */
    public static function paymentFailed(string $message = 'Payment failed'): self
    {
        return new self(
            self::STATUS_BAD_REQUEST,
            self::CODE_PAYMENT_FAILED,
            $message
        );
    }

    /**
     * Static factory for insufficient funds
     */
    public static function insufficientFunds(string $message = 'Insufficient funds'): self
    {
        return new self(
            self::STATUS_BAD_REQUEST,
            self::CODE_INSUFFICIENT_FUNDS,
            $message
        );
    }

    /**
     * Static factory for fraud detected
     */
    public static function fraudDetected(string $message = 'Fraud detected'): self
    {
        return new self(
            self::STATUS_FORBIDDEN,
            self::CODE_FRAUD_DETECTED,
            $message
        );
    }

    /**
     * Static factory for content rejected
     */
    public static function contentRejected(string $message = 'Content rejected'): self
    {
        return new self(
            self::STATUS_BAD_REQUEST,
            self::CODE_CONTENT_REJECTED,
            $message
        );
    }

    /**
     * Static factory for duplicate submission
     */
    public static function duplicateSubmission(string $message = 'Duplicate submission'): self
    {
        return new self(
            self::STATUS_CONFLICT,
            self::CODE_DUPLICATE_SUBMISSION,
            $message
        );
    }

    /**
     * Static factory for invalid platform
     */
    public static function invalidPlatform(string $message = 'Invalid platform'): self
    {
        return new self(
            self::STATUS_BAD_REQUEST,
            self::CODE_INVALID_PLATFORM,
            $message
        );
    }

    /**
     * Static factory for wallet error
     */
    public static function walletError(string $message = 'Wallet error'): self
    {
        return new self(
            self::STATUS_BAD_REQUEST,
            self::CODE_WALLET_ERROR,
            $message
        );
    }

    /**
     * Static factory for escrow failed
     */
    public static function escrowFailed(string $message = 'Escrow failed'): self
    {
        return new self(
            self::STATUS_BAD_REQUEST,
            self::CODE_ESCROW_FAILED,
            $message
        );
    }


    /**
     * Static factory for backup failed
     */
    public static function backupFailed(string $message = 'Backup failed'): self
    {
        return new self(
            self::STATUS_INTERNAL_ERROR,
            self::CODE_BACKUP_FAILED,
            $message
        );
    }

    /**
     * Static factory for audit failed
     */
    public static function auditFailed(string $message = 'Audit failed'): self
    {
        return new self(
            self::STATUS_INTERNAL_ERROR,
            self::CODE_AUDIT_FAILED,
            $message
        );
    }

    public function __construct(int $statusCode, string $errorCode, string $message) {
        if ($statusCode < 400 || $statusCode > 599) {
            throw new \InvalidArgumentException('ErrorContract status code must be between 400 and 599.');
        }

        $normalizedErrorCode = trim($errorCode);
        if ($normalizedErrorCode === '' || !preg_match('/^[A-Z][A-Z0-9_]*$/', $normalizedErrorCode)) {
            throw new \InvalidArgumentException('ErrorContract error code must be a non-empty uppercase identifier.');
        }

        $normalizedMessage = trim($message);
        if ($normalizedMessage === '') {
            throw new \InvalidArgumentException('ErrorContract message must not be empty.');
        }

        $this->statusCode = $statusCode;
        $this->errorCode = $normalizedErrorCode;
        $this->message = $normalizedMessage;
        $this->details = null;
        $this->fieldErrors = null;
    }

    /** @param array<string, mixed> $details */
    public function withDetails(array $details): self
    {
        $this->details = $details;
        return $this;
    }

    /**
     * خطاهای فیلدمحور را روی قرارداد خطا می‌نشاند.
     *
     * پیش‌تر تنها factory متد validation() می‌توانست fieldErrors را مقداردهی کند؛
     * این متد همان قابلیت را برای سایر انواع خطا (مانند خطاهای بیزینسی که خطای
     * فیلدمحور همراه دارند) فراهم می‌کند تا کلید «errors» در خروجی JSON پر شود.
     *
     * @param array<string, mixed> $fieldErrors
     */
    public function withFieldErrors(array $fieldErrors): self
    {
        $this->fieldErrors = $fieldErrors;
        return $this;
    }

    /**
     * تبدیل به array برای JSON response
     *
     * فرمت خروجی عمداً «تخت» (Flat) است تا با قرارداد واقعیِ استفاده‌شده در
     * سراسر کنترلرها (۲۶۰+ نقطه) و فرانت‌اند (resData.message / resData.errors)
     * یکسان باشد. پیش‌تر این متد ساختار تودرتوی {error:{code,message}} می‌ساخت
     * که با هیچ مصرف‌کننده‌ای در پروژه (نه PHP، نه JS) سازگار نبود و باعث می‌شد
     * ExceptionHandler/GlobalExceptionMiddleware همیشه کد وضعیت ۵۰۰ برگردانند
     * (چون به‌دنبال کلید سطح‌بالای «code» می‌گشتند که وجود نداشت).
     */
    /** @return ErrorPayload */
    public function toArray(): array
    {
        $response = [
            'success'    => false,
            'message'    => $this->capped($this->message, self::MAX_MESSAGE_LENGTH),
            'errors'     => $this->fieldErrors === null ? [] : $this->sanitizeTree($this->fieldErrors),
            'error_code' => $this->errorCode,
            'code'       => $this->statusCode,
        ];

        if ($this->details !== null && $this->details !== []) {
            $details = $this->sanitizeTree($this->details);
            // سقف حجم سریالی‌شدهٔ details — payload‌های حجیم (شیء/استک بزرگ)
            // به یک مارکر کوتاه بریده می‌شوند تا پاسخ خطا هیچ‌وقت مگابایتی نشود.
            $encoded = json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (is_string($encoded) && strlen($encoded) > self::MAX_DETAILS_JSON_LENGTH) {
                $response['details'] = ['truncated' => true, 'bytes' => strlen($encoded)];
            } else {
                $response['details'] = $details;
            }
        }

        $response['meta'] = [
            'trace_id' => self::resolveTraceId(),
            'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
        ];

        return $response;
    }

    /** برش با حفظ کامل بودن کاراکتر (mb) و افزودن نشانگر برش. */
    private function capped(string $value, int $max): string
    {
        if (mb_strlen($value) <= $max) {
            return $value;
        }
        return mb_substr($value, 0, $max) . '…[truncated]';
    }

    /**
     * پاک‌سازی بازگشتی برگ‌های خروجی:
     *  - مقادیر کلیدهای حساس (password/token/…) کامل ماسک می‌شوند
     *  - PII متنی (ایمیل/موبایل/IP/جفت‌های «password=…») در رشته‌ها ماسک می‌شود
     *  - رشته‌های طولانی به سقف می‌رسند
     *
     * @param mixed $value
     * @return mixed
     */
    private function sanitizeTree($value, int $depth = 0)
    {
        if ($depth > 8) {
            return '[depth_limit]';
        }
        if (is_array($value)) {
            $out = [];
            foreach ($value as $k => $v) {
                $key = is_string($k) ? $k : (string)$k;
                if (is_string($v) || is_numeric($v)) {
                    if (preg_match(self::SENSITIVE_KEY_PATTERN, $key) === 1) {
                        $out[$k] = '[MASKED]';
                        continue;
                    }
                }
                $out[$k] = $this->sanitizeTree($v, $depth + 1);
            }
            return $out;
        }
        if (is_string($value)) {
            $masked = preg_replace(
                [
                    '/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/',
                    '/(?:\\+98|0)?9\\d{9}/',
                    '/\\b(?:[0-9]{1,3}\\.){3}[0-9]{1,3}\\b/',
                    '/(password|pass|secret|token|card_number|cvv2|cvv|pin)\\s*[:=]\\s*[^\\s,\'\"]+/i',
                ],
                ['[EMAIL_MASKED]', '[PHONE_MASKED]', '[IP_MASKED]', '$1=[MASKED]'],
                $value
            );
            $masked = is_string($masked) ? $masked : $value;
            return $this->capped($masked, self::MAX_STRING_LENGTH);
        }
        if (is_object($value)) {
            return '[' . get_class($value) . ']';
        }
        return $value;
    }

    /** @return non-empty-string */
    private static function resolveTraceId(): string
    {
        // FIX-CFG046 (یافتهٔ ۰۴۶): شناسهٔ trace قبلاً مستقیم از app()->request
        // (وابستگی به app سراسری) خوانده می‌شد و مقدار کلاینت با الگویی ناسازگار
        // با بقیهٔ سیستم بازتاب داده می‌شد. اکنون منبعِ یکتای canonical همان
        // get_request_id() است: هدر X-Request-Id را فقط با الگوی سخت‌گیرانهٔ
        // ^[a-zA-Z0-9\-_]{8,64}$ می‌پذیرد و در غیر این صورت شناسهٔ تازهٔ REQ_*
        // تولید می‌کند — یعنی هیچ ورودی خام/نامعتبر کلاینت هرگز بازتاب نمی‌یابد
        // و وابستگی به app() هم حذف شد (در نبود helpers، شناسهٔ تازهٔ امن).
        if (function_exists('get_request_id')) {
            return get_request_id();
        }

        return uniqid('req-', true);
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    public function getErrorCode(): string
    {
        return $this->errorCode;
    }

    public function getMessage(): string
    {
        return $this->message;
    }
}
