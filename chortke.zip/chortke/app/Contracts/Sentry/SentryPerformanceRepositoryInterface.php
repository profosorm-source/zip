<?php

declare(strict_types=1);

namespace App\Contracts\Sentry;

/**
 * SentryPerformanceRepositoryInterface
 *
 * مسئولیت: ذخیره و بازیابی داده‌های Performance Monitoring
 *
 * Consumers: SentryPerformanceMonitor، DashboardService
 *
 * FIX-P3-CFG-074 (docblock-only — read-model داشبوردی، امضاها عمداً ثابت):
 *   - storePerformanceTransaction: کلیدهای اجباری $data (پیاده‌سازی مرجع
 *     SentryModel دقیقاً همین‌ها را می‌خواند): transaction_id، name، op،
 *     duration (ms)، memory_used، peak_memory، query_count، slow_queries_count،
 *     status؛ و spans/queries/issues/context که قبل از پاس‌دادن باید
 *     JSON-encoded (رشته) باشند. request_id توسط پیاده‌سازی از درخواست جاری
 *     تزریق می‌شود و جزو $data نیست.
 *   - limit/period: همهٔ limit ها به‌صورت parameterized بایند می‌شوند (نه
 *     درج خام) اما در مخزن clamp نمی‌شوند — فراخواننده باید مقدار کوچک بدهد
 *     (داشبوردهای مرجع ≤ 100؛ پیش‌فرض‌های امضا 10) و periodHours/intervalMinutes
 *     را معقول نگه دارد. getPerformanceAggregates واژگان period: today | week
 *     | month (مقدار ناشناخته = today).
 */
interface SentryPerformanceRepositoryInterface
{
    /**
     * @param array<string, mixed> $data نگاه سربرگ: کلیدهای اجباری و JSON-encoded بودن spans/queries/issues/context
     */
    public function storePerformanceTransaction(array $data): bool;
    /** @param string $period واژگان: today|week|month (ناشناخته = today) */
    public function getPerformanceAggregates(string $period): ?object;
    /** @return array<int, \stdClass> */
    public function getSlowestTransactions(int $limit = 10): array;
    public function getP95ResponseTime(int $minutes = 60): float;
    public function getHealthMetricsBundle(int $minutes = 60): object;
    public function getPerformanceStatsSummary(int $hours = 24): ?object;
    /**
     * سری زمانی ساعتی؛ $periodHours بایند می‌شود (INTERVAL ? HOUR). $intervalMinutes
     * در پیاده‌سازی مرجع فعلاً در SQL مصرف نمی‌شود (سطل‌ها ساعتی‌اند) — برای
     * گرانولاریتهٔ زیر ساعت به آن تکیه نکنید.
     *
     * @return array<int, \stdClass>
     */
    public function getPerformanceTimeSeries(int $periodHours, int $intervalMinutes): array;
    /** @return array<int, \stdClass> */
    public function getTopSlowestEndpoints(int $limit = 10): array;
    /** @return array<int, \stdClass> */
    public function getPerformanceHistoricalData(int $days): array;
    public function getWeeklyPerformanceAvg(int $offset): float;
}
