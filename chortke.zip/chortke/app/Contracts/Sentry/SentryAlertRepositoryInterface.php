<?php

declare(strict_types=1);

namespace App\Contracts\Sentry;

/**
 * SentryAlertRepositoryInterface
 *
 * مسئولیت: ذخیره و بازیابی داده‌های Alerting & Rules
 *
 * Consumers: AlertDispatcher، AlertRulesEngine
 *
 * FIX-P3-CFG-069 (docblock-only — امضاها عمداً ثابت): schema و واژگان —
 *
 * @phpstan-type AlertPayload array{
 *   type: string,            // نوع alert (مثل 'custom', 'escalation', 'performance')
 *   severity: string,        // واژگان: low | medium | high | critical (throttle/config بر همین کلید است)
 *   title: string,           // غیرخالی
 *   message: string,
 *   metadata: array<string, mixed>,  // JSON-encoded ذخیره می‌شود
 *   event_id: string|null,
 *   environment: string,     // غیرخالی (مثل production/staging)
 *   fingerprint: string      // توسط فراخواننده ساخته می‌شود (AlertDispatcher::createAlertFingerprint)
 * }
 */
interface SentryAlertRepositoryInterface
{
    public function getLastAlert(string $fingerprint, string $severity): ?object;
    /**
     * FIX-P3-CFG-069: کلیدهای اجباری $data (پیاده‌سازی مرجع، SentryModel::storeAlert،
     * دقیقاً همین‌ها را می‌خواند و برای کلید مفقود warning/undefined می‌دهد):
     * type، severity (low|medium|high|critical)، title، message، metadata (array —
     * JSON می‌شود)، fingerprint، event_id، environment. رکورد با is_active=1
     * درج می‌شود؛ خروجی int شناسهٔ رکورد system_alerts است.
     *
     * @param AlertPayload $data
     */
    public function storeAlert(array $data): int;
    /** @return array<int, \stdClass> */
    public function getActiveChannels(string $severity): array;
    /**
     * FIX-P3-CFG-069: واژگان مجاز $status — فقط 'sent' یا 'failed'
     * (فراخوانندهٔ مرجع AlertDispatcher پس از sendToChannel این دو را ثبت
     * می‌کند؛ مقدار دیگر واژگان dashboards/history را بی‌معنا می‌کند).
     * سطر با sent_at=NOW() در notification_history درج می‌شود.
     */
    public function recordNotificationHistory(int $channelId, int $alertId, string $status): void;
    /**
     * گذار lifecycle فعلی قرارداد: تنتی یک‌طرفه به is_sent=1/sent_at=NOW().
     * شکست/ردِ ارسال از مسیر recordNotificationHistory(status='failed') ثبت
     * می‌شود نه با گذار وضعیت alert (فاز failed/resolved هنوز عضو قرارداد نیست —
     * افزودن آن نیاز به مهاجرت مصرف‌کنندگان دارد و در این راند عمداً انجام نشد).
     */
    public function markAlertAsSent(int $alertId): void;
    /** @return array<int, \stdClass> */
    public function getActiveAlerts(): array;
    /** @return array<int, \stdClass> */
    public function getActiveRules(): array;
    public function getRuleStatus(int $ruleId): ?object;
    public function updateRuleLastTriggered(int $ruleId): void;
    public function getMetricValue(string $type, int $minutes): float;
    /** @return array<int, \stdClass> */
    public function getNotificationChannelsForSettings(): array;
    /** @return array<int, \stdClass> */
    public function getAlertRulesForSettings(): array;
    /** @return array<int, \stdClass> */
    public function getActiveAlertsForDashboard(): array;
}
