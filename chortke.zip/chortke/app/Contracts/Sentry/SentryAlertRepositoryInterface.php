<?php

declare(strict_types=1);

namespace App\Contracts\Sentry;

/**
 * SentryAlertRepositoryInterface
 *
 * مسئولیت: ذخیره و بازیابی داده‌های Alerting & Rules
 *
 * Consumers: AlertDispatcher، AlertRulesEngine
 */
interface SentryAlertRepositoryInterface
{
    public function getLastAlert(string $fingerprint, string $severity): ?object;
    public function storeAlert(array $data): int;
    public function getActiveChannels(string $severity): array;
    public function recordNotificationHistory(int $channelId, int $alertId, string $status): void;
    public function markAlertAsSent(int $alertId): void;
    public function getActiveAlerts(): array;
    public function getActiveRules(): array;
    public function getRuleStatus(int $ruleId): ?object;
    public function updateRuleLastTriggered(int $ruleId): void;
    public function getMetricValue(string $type, int $minutes): float;
    public function getNotificationChannelsForSettings(): array;
    public function getAlertRulesForSettings(): array;
    public function getActiveAlertsForDashboard(): array;
}
