<?php

declare(strict_types=1);

namespace App\Contracts\Sentry;

/**
 * SentryAuditRepositoryInterface
 *
 * مسئولیت: بازیابی داده‌های Audit Trail از دیتابیس
 *
 * Consumers: AdvancedAuditTrail
 */
interface SentryAuditRepositoryInterface
{
    public function getAuditCount(string $where, array $params): int;
    public function searchAuditRecords(string $where, array $params, int $limit, int $offset): array;
    public function getAuditEventsByCategory(string $start, string $end): array;
    public function getAuditUserActivity(string $start, string $end): array;
    public function getAuditAccessPatterns(string $start, string $end): array;
    public function getAuditFailedOperations(string $start, string $end): array;
    public function deleteOldAuditRecords(string $cutoff): int;
    public function getOldAuditRecords(string $cutoff): array;
    public function getAuditRecordById(int $id): ?object;
    public function getActivityTimeline(?int $userId, int $days): array;
    public function getAuditReportSummary(string $start, string $end): ?object;
    public function getAuditCriticalEvents(array $critical, string $start, string $end): array;
}
