<?php

declare(strict_types=1);

namespace App\Contracts\Sentry;

/**
 * SentryAuditRepositoryInterface
 *
 * مسئولیت: بازیابی داده‌های Audit Trail از دیتابیس
 *
 * Consumers: AdvancedAuditTrail
 */
interface SentryAuditRepositoryInterface
{
    /**
     * FIX-CFG070 (یافتهٔ ۰۷۰): فیلترهای ساخت‌یافته به‌جای رشتهٔ WHERE خام از فراخوان.
     * کلیدهای مجاز (allowlist): user_id, event, category, date_from, date_to,
     * ip_address, context_search — هر کلید دیگر نادیده گرفته می‌شود و SQL در
     * مخزن با قطعات ثابت + پارامترسازی ساخته می‌شود.
     *
     * @param array<string, mixed> $filters
     */
    public function getAuditCount(array $filters): int;
    /**
     * FIX-CFG070: هم‌قرارداد با getAuditCount — فیلتر ساخت‌یافته، نه رشتهٔ WHERE خام.
     *
     * @param array<string, mixed> $filters
     * @return array<int, \stdClass>
     */
    public function searchAuditRecords(array $filters, int $limit, int $offset): array;
    /** @return array<int, \stdClass> */
    public function getAuditEventsByCategory(string $start, string $end): array;
    /** @return array<int, \stdClass> */
    public function getAuditUserActivity(string $start, string $end): array;
    /** @return array<int, \stdClass> */
    public function getAuditAccessPatterns(string $start, string $end): array;
    /** @return array<int, \stdClass> */
    public function getAuditFailedOperations(string $start, string $end): array;
    /**
     * FIX-S27B-F12: حذف فقط id-محور روی ردیف‌های آرشیوشده مجاز است.
     * FIX-CFG070 (یافتهٔ ۰۷۰): گارد سنی — ردیف‌های جوان‌تر از سقف حداقل نگه‌داری
     * (۳۰ روز) هرگز حذف نمی‌شوند حتی اگر id صریح داده شده باشد.
     * @param list<int> $ids
     */
    public function deleteAuditRecordsByIds(array $ids): int;
    /** @return array<int, \stdClass> */
    public function getOldAuditRecords(string $cutoff): array;
    public function getAuditRecordById(int $id): ?object;
    /** @return array<int, \stdClass> */
    public function getActivityTimeline(?int $userId, int $days): array;
    public function getAuditReportSummary(string $start, string $end): ?object;
    /** @return array<int, \stdClass> */
    /** @param array<int|string, mixed> $critical */
    /** @return array<int, \stdClass> */
    /**
     * @param array<int|string, mixed> $critical
     * @return array<int, \stdClass>
     */
    public function getAuditCriticalEvents(array $critical, string $start, string $end): array;
}
