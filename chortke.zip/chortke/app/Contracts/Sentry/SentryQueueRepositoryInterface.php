<?php

declare(strict_types=1);

namespace App\Contracts\Sentry;

/**
 * SentryQueueRepositoryInterface
 *
 * مسئولیت: داده‌های Failed Jobs و Outbox DLQ
 *
 * Consumers: DashboardService
 *
 * FIX-CFG075 (یافتهٔ CFG-075): مرز مسئولیت‌های DLQ و قرارداد claim/status —
 * منطبق بر پیاده‌سازی مرجع App\Models\SentryModel و primitives اتمیک
 * App\Models\FailedJob (FIX-CMD013/CMD014/CMD075/CMD077):
 *
 * ── پوشش اکشن‌های DLQ در چه چیزی است؟ ─────────────────────────────────────
 *   - retry/forget در سطح قرارداد همین interface هستند (پیاده‌سازی:
 *     SentryModel::retryFailedJob/forgetFailedJob).
 *   - archive و purge و claim اتمیک روی همین جدول، عمداً در این interface
 *     (read-model داشبورد) نیستند و مالکشان App\Models\FailedJob است:
 *     FailedJob::purge() و FailedJob::forget() هر دو «آرشیو-اول»اند (کپی به
 *     dlq_archive پیش از حذف واقعی — ضد Data Loss) و FailedJob::retry() الگوی
 *     claim-first را اجرا می‌کند. مسیرهای CLI (dlq:retry/queue:failed) از همین
 *     primitives مصرف می‌کنند؛ داشبورد فقط read + retry/forget دارد.
 *
 * ── قرارداد status جدول failed_jobs ───────────────────────────────────────
 *   NULL            → ردیف کلاسیک/در انتظار (قابل retry).
 *   'processing'    → نشانگر in-flight: claim ورکر DLQ یا retry دستی در جریان
 *                     است (FIX-CMD013). هیچ منبع retry دوم حق re-push ندارد —
 *                     در هر دو جهت گارد می‌شود (fetch/claim/DELETE).
 *   'retry_pending' → claim پس از شکست push آزاد شده و ردیف دوباره retryable است
 *                     (FailedJob::releaseRetryClaim — فقط از 'processing' عبور می‌کند).
 *   'quarantined'   → payload خراب/خارج از allowlist؛ فقط با تصمیم صریح ادمین
 *                     بازیابی می‌شود و از هیچ منبع انبوه retry برنمی‌گردد.
 *
 * ── claim اتمیک (claimForRetry/releaseRetryClaim — FIX-CMD013) ────────────
 *   claim یک UPDATE تک‌دستوری اتمیک است: SET status='processing' WHERE … NOT IN
 *   ('processing','quarantined') — دو retry موازی تنها یکی affected می‌گیرد و
 *   ردیف in-flight/قرنطینه دور زده نمی‌شود. ترتیب الزامی retry: claim اتمیک ←
 *   push (بیرون از تراکنش DB) ← DELETE گارددارِ مالکیت claim؛ در شکست push،
 *   releaseRetryClaim ردیف را retry_pending می‌کند. crash نیمه‌راه ردیف را
 *   'processing' نگه می‌دارد (at-least-once؛ ایدمپوتنسی جاب، اجرای مضاعف را
 *   بی‌اثر می‌کند).
 */
interface SentryQueueRepositoryInterface
{
    /** خلاصهٔ داشبورد failed_jobs (شمارنده‌ها) یا null در نبود داده. */
    public function getFailedJobsSummary(): ?object;

    /** شمارش ردیف‌های failed به تفکیک صف. @return array<int, \stdClass> */
    public function getFailedJobQueueCounts(int $limit = 10): array;

    public function getFailedJobsCount(?string $queue = null): int;

    /** خلاصهٔ داشبورد outbox DLQ یا null در نبود داده. */
    public function getOutboxDLQSummary(): ?object;

    /** @return array<int, \stdClass> */
    public function getOutboxDLQList(int $limit, int $offset): array;

    /**
     * صفحهٔ ردیف‌های failed_jobs برای داشبورد.
     * توجه: برخلاف FailedJob::fetchByQueue، گارد status='processing'/'quarantined'
     * ندارد — خوانندهٔ صرف است و هرگز مبنا retry انبوه قرار نمی‌گیرد.
     * @return array<int, \stdClass>
     */
    public function getFailedJobsPaged(int $limit, int $offset, ?string $queue = null): array;

    public function getFailedJobById(int $id): ?object;

    /**
     * requeue اتمیک با گارد claim/status (قرارداد FIX-CMD013):
     *   - ردیف 'processing' (claim ورکر/ادمین دیگر) رد می‌شود → false.
     *   - payload باید JSON معتبر با کلاس داخل allowlist مشترک
     *     (QueueWorker::isJobAllowed) باشد؛ در غیر این صورت هیچ pushی رخ نمی‌دهد.
     *   - push از مسیر استاندارد Queue::push (هر دو درایور database/redis) و
     *     حذفِ ردیف با گارد «status ≠ processing» داخل همان تراکنش انجام می‌شود.
     * claim-firstِ خالص با claim آزادشونده در شکست، FailedJob::retry است.
     */
    public function retryFailedJob(int $id): bool;

    /**
     * حذف یک ردیف failed_jobs از مسیر داشبورد (بدون retry).
     * تفاوت عمدی با FailedJob::forget: این نسخه read-model/ادمین سریع است و
     * آرشیو نمی‌کند؛ مسیر آرشیو-اول (dlq_archive) با purge/forget مربوط به
     * FailedJob است — استفادهٔ انبوه از همین متد برای پاکسازی نگهداری، ممنوع.
     */
    public function forgetFailedJob(int $id): bool;
}
