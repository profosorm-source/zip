<?php

declare(strict_types=1);

namespace App\Contracts\Sentry;

/**
 * SentryEscalationRepositoryInterface
 *
 * مسئولیت: مدیریت Escalation و Auto-resolve
 *
 * Consumers: EscalationManager
 *
 * FIX-P3-CFG-072 (docblock-only): واژگان level و معناشناسی شکست —
 *   - واژگان مجاز level (newLevel/oldLevel/new/old): info | warning | error |
 *     critical | fatal (منبع: EscalationManager::getNextLevel / پیکربندی alert_levels
 *     کانال‌ها). مقدار خارج از واژگان در UPDATE می‌ماند اما، next-level و
 *     severity-map را گمراه می‌کند — واژگان را نقض نکنید.
 *   - «failure-silent» عمدی و مستند: هر دو متد void هستند و در پیاده‌سازی مرجع
 *     (SentryModel::escalateIssue) خطای DB/ثبت رویداد بلعیده و فقط log می‌شود
 *     ('sentry.escalation.failed')؛ هیچ سیگنال affected-rows به فراخواننده
 *     نمی‌رسد. فراخواننده‌هایی که به موفقیت اهمیت دارند باید از
 *     recordIssueEscalationMeta / خواندن مجدد وضعیت (getPendingEscalations)
 *     تحقق را بسنجند، نه از بازگشت این متدها (چیزی برای سنجیدن نیست).
 *   - escalateAlert(): @deprecated — passthrough نازک به escalateIssue (نگاه
 *     پیاده‌سازی مرجع)؛ فراخوانی تازه از escalateIssue انجام شود.
 */
interface SentryEscalationRepositoryInterface
{
    /** @return array<int, \stdClass> */
    public function getPendingEscalations(): array;
    /**
     * @param string $newLevel واژگان: info|warning|error|critical|fatal
     * @param string $oldLevel level فعلی (فقط برای لاگ/رویداد escalation)
     */
    public function escalateIssue(int $id, string $newLevel, string $oldLevel): void;
    /**
     * @deprecated با escalateIssue جایگزین شده (backward compat — passthrough).
     *
     * @param string $new واژگان: info|warning|error|critical|fatal
     * @param string $old level فعلی (لاگ/رویداد)
     */
    public function escalateAlert(int $id, string $new, string $old): void;
    public function acknowledgeAlert(int $id, ?int $userId, ?string $note): bool;
    public function autoResolveErrorAlerts(): int;
    public function getEscalationStatistics(): object;
}
