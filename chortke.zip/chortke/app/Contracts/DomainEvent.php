<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * قرارداد Domain Event
 *
 * 📜 قرارداد واقعی (وضعیت موجود، نه ادعا): این interface برای رویدادهای
 * کلاس‌محوری که با OutboxService::recordEvent(object) ثبت می‌شوند «الزامی» است —
 * FIX-CFG043 (یافتهٔ ۰۴۳): recordEvent در زمان اجرا instanceof این قرارداد را
 * بررسی می‌کند و هر payload غیر DomainEvent را با InvalidArgumentException رد
 * می‌کند (مسیر قدیمیِ استنتاج aggregate/payload از آبجکت خام حذف شد).
 * رویدادهای رکوردیِ بدون کلاس همچنان با record(aggregate, id, 'name.string',
 * payload) ثبت می‌شوند و نیازی به این interface ندارند.
 */
interface DomainEvent
{
    /**
     * نوع aggregate (مثلاً 'wallet', 'investment', 'score')
     */
    public function aggregateType(): string;

    /**
     * شناسه aggregate (مثلاً user_id, order_id)
     */
    public function aggregateId(): string;

    /**
     * داده‌های event به صورت آرایه — برای ذخیره در outbox_events.payload
     * @return array<string, mixed>
     */
    public function toPayload(): array;
}
