<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * قرارداد Domain Event
 *
 * 📜 قرارداد واقعی (وضعیت موجود، نه ادعا): این interface «اختیاری» است و فقط
 * برای رویدادهای کلاس‌محوری که با OutboxService::recordEvent(object) ثبت
 * می‌شوند لازم است تا aggregate/payload بدون حدس استخراج شود. اکثر رویدادهای
 * پروژه با record(aggregate, id, 'name.string', payload) ثبت می‌شوند و نیازی
 * به این interface ندارند. «الزام برای هر Event بیزینسی» هرگز واقعیت نداشت.
 */
interface DomainEvent
{
    /**
     * نوع aggregate (مثلاً 'wallet', 'investment', 'score')
     */
    public function aggregateType(): string;

    /**
     * شناسه aggregate (مثلاً user_id, order_id)
     */
    public function aggregateId(): string;

    /**
     * داده‌های event به صورت آرایه — برای ذخیره در outbox_events.payload
     * @return array<string, mixed>
     */
    public function toPayload(): array;
}
