<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * FIX-C65 (یافتهٔ ممیزی ۶۵): قرارداد اختیاریِ متادیتای رویداد دامنه.
 *
 * DomainEvent پایه شناسهٔ یکتا، زمان وقوع، کنشگر و نسخهٔ رویداد را نمی‌خواست و
 * جدول outbox هیچ جای ثبت‌شان نبود — هر رویدادِ ثبت‌شده در outbox بدون هویت
 * و قابل‌ردیابی نبود. رویدادهایی که این قرارداد را پیاده کنند، هنگام
 * OutboxService::recordEvent() به‌صورت خودکار ستون‌های event_id / occurred_at /
 * actor_id / event_version را پر می‌کنند (همه nullable — رویدادهای قدیمی
 * سالم می‌مانند).
 */
interface VersionedDomainEvent extends DomainEvent
{
    /**
     * شناسهٔ یکتای خود رویداد (uuid/ulid) — متمایز از aggregateId.
     */
    public function eventId(): string;

    /**
     * زمان وقوع واقعی رویداد (Y-m-d H:i:s) — ممکن است با زمانِ ثبت فاصله داشته باشد.
     */
    public function occurredAt(): string;

    /**
     * کنشگر رویداد: شناسهٔ کاربر، یا 0 برای سامانه/سیستم، null = نامشخص.
     */
    public function actorId(): ?int;

    /**
     * نسخهٔ شِمای رویداد برای evolution آینده (شروع از 1).
     */
    public function eventVersion(): int;
}
