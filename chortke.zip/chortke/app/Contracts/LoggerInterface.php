<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * PSR-3 Logger Interface
 *
 * قرارداد واحد لاگینگ در کل پروژه
 *
 * FIX-C71 (یافتهٔ ۷۱): این قرارداد اکنون «واقعاً» PSR-3 است، نه فقط ادعا —
 * قبلاً امضاهای باریک‌تر (string $message بدون Stringable و log(string $level))
 * ساختاراً با Psr\Log\LoggerInterface ناسازگار بودند و یک کلاس نمی‌توانست هر دو
 * را پیاده کند (fatal «must be compatible»). اکنون مستقیماً از PSR-3 ارث‌بری
 * می‌شود و فقط اکستنشن project-specific (activity) اضافه دارد؛ هر پیاده‌سازیِ
 * این قرارداد به‌طور خودش قابل پاس‌دادن به هر APIِ انتظار PSR-3 است.
 */
interface LoggerInterface extends \Psr\Log\LoggerInterface
{
    /**
     * ثبت فعالیت کاربر برای audit trail (اکستنشن پروژه، خارج از PSR-3)
     *
     * FIX-P3-CFG-054 (docblock-only): schema $metadata —
     *   - کلیدهای رزرو (توسط خط لوله بازنویسی می‌شوند، پاس‌دادنشان بی‌اثر است):
     *     type، action، description، user_id — این چهار مقدار از پارامترهای خود
     *     متد ساخته و به context تزریق می‌شوند (LogService::logActivity؛ رکورد
     *     نهایی system_logs با type='activity').
     *   - بقیهٔ کلیدها آزادند ولی باید scalar یا JSON-encode پذیر باشند (context
     *     به JSON ذخیره می‌شود)؛ کلیدها را مختصر و استاندارد نگه دارید
     *     (مثل entity_type/entity_id/ip/ref).
     *   - ممنوع در metadata: PII خام (موبایل/ایمیل/کد ملی)، رمز/توکن/secret،
     *     stack/exception خام — همان سیاست ماسک‌کردن بقیهٔ لاگ‌ها؛ اگر داده
     *     حساس لازم است، ماسک‌شده (****last4) بفرستید.
     *
     * @param array<string, mixed> $metadata نگاه بالا: کلیدهای رزرو + scalar/JSON-safe + بدون PII/secret
     */
    public function activity(
        string $action,
        string $description,
        ?int $userId = null,
        array $metadata = []
    ): void;
}
