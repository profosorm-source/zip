<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * EmailServiceInterface — قرارداد سرویس ارسال ایمیل
 */
interface EmailServiceInterface
{
    /**
     * ارسال فوری ایمیل (بدون صف)
     * 
     * @param string $toEmail آدرس ایمیل گیرنده
     * @param string $toName نام گیرنده
     * @param string $subject موضوع ایمیل
     * @param string $bodyHtml بدن ایمیل (HTML)
     * @return bool
     */
    public function sendDirect(
        string $toEmail,
        string $toName,
        string $subject,
        string $bodyHtml
    ): bool;

    /**
     * ارسال ایمیل به صف (پردازش async)
     *
     * FIX-P3-CFG-045 (docblock-only): واژگان و معناشناسی که پیاده‌سازی مرجع
     * (EmailService::enqueue) fail-loud اعمال می‌کند —
     *   - $priority فقط 'low' | 'normal' | 'high' (مقدار دیگر InvalidArgumentException).
     *   - $scheduledAt هر رشته‌ای که strtotime() بپذیرد ('2026-09-30 08:00:00'،
     *     '+2 hours'، ...) و به unix timestamp ذخیره می‌شود؛ null = ارسال فوری
     *     (بدون به‌صف‌آمدن زمان‌بندی‌شده).
     *   - بازگشت: شناسهٔ رکورد ایمیل در EmailDeliveryStore (string|int) یعنی
     *     «پذیرفته شد و برای ارسال برنامه‌ریزی شد»؛ null یعنی enqueue انجام نشد
     *     (کاربر بدون email، کانال غیرفعال در ترجیحات، یا خطای ثبت).
     *   - خروجی non-null «تحویل‌شده» نیست: ارسال واقعی async از طریق
     *     outbox/queue (SendEmailJob) انجام می‌شود.
     *
     * @param int $userId شناسه کاربر
     * @param string $subject موضوع ایمیل
     * @param string $bodyHtml بدن ایمیل (HTML)
     * @param string|null $bodyText بدن متنی (اختیاری)
     * @param string $priority اولویت ارسال — فقط low|normal|high (fail-loud)
     * @param string|null $scheduledAt زمان ارسال برنامه‌ریزی‌شده (قابل‌پارس با strtotime؛ null = فوری)
     * @return string|int|null شناسهٔ رکورد ایمیل ثبت‌شده، یا null در عدم پذیرش
     */
    public function enqueue(
        int     $userId,
        string  $subject,
        string  $bodyHtml,
        ?string $bodyText    = null,
        string  $priority    = 'normal',
        ?string $scheduledAt = null
    ): string|int|null;
}
