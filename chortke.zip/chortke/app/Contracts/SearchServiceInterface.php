<?php

declare(strict_types=1);

namespace App\Contracts;

/**
 * SearchServiceInterface — قرارداد جامع خدمات جستجوی سیستم
 *
 * FIX-CFG061 (یافتهٔ CFG-061): وضعیت @methodهای زیر — «متد فانتزی» نیستند؛
 * سطح passthrough ماژیک SearchOrchestrator::__call را مستند می‌کنند که هر متدِ
 * عمومیِ Provider ثبت‌شده را به همان Provider فوروارد می‌کند. پس از grep، هر ده
 * امضا، یک‌به‌یک با متدهای واقعی App\Services\Search\AdminSearchProvider تطبیق
 * داده شد (searchBanners/searchContent/searchContentForExport/searchTokens/
 * searchEmails/searchInvestments/searchTickets/searchInfluencers با
 * limit=DEFAULT_LIMIT=20، و quickSearchAds/quickSearchSubmissions) — هیچ‌کدام
 * با متدهای واقعی declare‌شدهٔ همین interface هم‌نام نیستند و حذفشان توانایی
 * فراخواننده‌ها را می‌شکست. قاعدهٔ نگه‌داری: این فهرست باید دقیقاً با متدهای
 * عمومی AdminSearchProvider هم‌گام بماند — افزودن/تغییر متد در Provider بدون
 * به‌روزرسانی همین @methodها، قرارداد static-analysis را می‌شکند.
 *
 * FIX-P3-CFG-062 (MODIFY — docblock-only): وضعیت و کرانه‌های سطح passthrough —
 *   - این ده @method «سطح قدیمی» (legacy) است؛ مسیر توصیه‌شده searchQuery()
 *     با VO است. مسیر VO کرانه‌ها را خودش اعمال می‌کند: SearchQuery
 *     limit را [1..200] و offset را ≥ 0 clamp می‌کند (FIX-R36-W3 F-A14-13).
 *   - سطح passthrough هم بی‌کرانه نیست: پیاده‌سازی مرجع (AdminSearchProvider)
 *     در هر متدِ جستجو limit را به MAX_LIMIT همان کلاس محدود و offset را ≥ 0
 *     می‌کند؛ یعنی مقدار بزرگِ limit منفجرشونده نیست، ولی «کرانهٔ قراردادیِ
 *     واحد» فقط در مسیر searchQuery تضمین می‌شود.
 *   - این @methodها deprecated-leaning هستند (حذف‌شان توانایی فراخواننده‌ها را
 *     می‌شکست — FIX-CFG061)؛ هر متد تازه به سطح searchQuery اضافه شود، نه اینجا.
 *
 * @method array searchBanners(string $q, array $filters = [], int $limit = 20, int $offset = 0)
 * @method array searchContent(string $q, array $filters = [], int $limit = 20, int $offset = 0)
 * @method array searchContentForExport(string $q, array $filters = [], int $limit = 1000, int $offset = 0)
 * @method array searchTokens(string $q, array $filters = [], int $limit = 20, int $offset = 0)
 * @method array searchEmails(string $q, array $filters = [], int $limit = 20, int $offset = 0)
 * @method array searchInvestments(string $q, array $filters = [], int $limit = 20, int $offset = 0)
 * @method array searchTickets(string $q, array $filters = [], int $limit = 20, int $offset = 0)
 * @method array searchInfluencers(string $q, array $filters = [], int $limit = 20, int $offset = 0)
 * @method array quickSearchAds(string $q, ?int $userId, int $limit)
 * @method array quickSearchSubmissions(string $q, ?int $userId, int $limit)
 */
interface SearchServiceInterface
{
    /**
     * روش جدید و اصلی برای جستجو (استفاده از الگوی Strategy و اشیاء Query)
     */
    public function searchQuery(\App\Services\Search\SearchQuery $query): \App\Services\Search\SearchResult;

    /**
     * @deprecated استفاده از searchQuery توصیه می‌شود
     */
    /** @return array<string, mixed> */
    public function searchAdmin(\App\Services\Search\SearchQuery $query): array;
    
    /**
     * @deprecated استفاده از searchQuery توصیه می‌شود
     */
    /** @return array<string, mixed> */
    public function searchUser(\App\Services\Search\SearchQuery $query, int $userId): array;
    
    /**
     * @deprecated استفاده از searchQuery توصیه می‌شود
     */
    /**
     * @param list<string> $modules
     * @return array<string, mixed>
     */
    public function searchModules(array $modules, \App\Services\Search\SearchQuery $query): array;
    
    public function invalidateModuleCache(string $module): void;

    /**
     * @deprecated استفاده از searchQuery توصیه می‌شود
     */
    /** @return array<string, mixed> */
    public function searchAdminModule(string $module, \App\Services\Search\SearchQuery $query): array;

    /** @return list<string> */
    public function registeredAdminModules(): array;
}
