<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\AuditRecordedEvent;
use App\Models\AuditTrail as AuditTrailModel;
use App\Contracts\LoggerInterface;

class PersistAuditRecordListener
{
    private AuditTrailModel $model;
    private LoggerInterface $logger;
    public function __construct(
        AuditTrailModel $model,
        LoggerInterface $logger
    ) {        $this->model = $model;
        $this->logger = $logger;
}

    public function handle(AuditRecordedEvent $event): void
    {
        try {
            $id = $this->model->createEntry([
                'request_id' => (PHP_SAPI !== 'cli' ? (app()->request->header('x-request-id') ?? 'cli') : 'cli'),
                'event' => $this->sanitizeEvent($event->eventName),
                'user_id' => $event->userId,
                'actor_id' => $event->actorId ?? null,
                'context' => json_encode($this->sanitizeContext($event->context), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'ip_address' => get_client_ip(),
                'user_agent' => get_user_agent(),
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            // 🛡️ FIX-X217: نتیجهٔ واقعی INSERT به نویسندهٔ رویداد برگردد (پرچم persisted
            // روی خود Event) — record() بدون این خبر، موفقیت/شکست ماندگاری را نمی‌فهمد.
            $event->persisted = (bool)$id;
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.PersistAuditRecordListener.handle']);
            $this->logger->error('persist_audit_record.failed', [
                'event' => $event->eventName,
                'user_id' => $event->userId,
                'error' => $e->getMessage()
            ]);
        }
    }

    private function sanitizeEvent(string $event): string
    {
        return (string)preg_replace('/[^a-z0-9_\.]/i', '_', $event);
    }

    /**
     * 🛡️ FIX-S18-7 (S18-AUDIT): ماسک «بازگشتی» — هم‌سمانت با استاندارد
     * AuditTrail::sanitizeContext (array_walk_recursive). نسخهٔ قبلی فقط سطحِ
     * اول را می‌پوشاند ⇒ توچه‌های تودرتو (مثل old_values.password یا
     * outbox payload metadata) بدون ماسک در audit_trail ماندگار می‌شد.
     *
     * @param array<string, mixed> $context
     * @return array<int|string, mixed>
     */
    private function sanitizeContext(array $context): array
    {
        $sensitive = ['password', 'pwd', 'token', 'secret', 'ssn', 'cvv', 'card', 'pan', 'key', 'sheba', 'iban', 'api_key', 'private_key'];
        $masked = $context;
        array_walk_recursive($masked, function (&$value, $key) use ($sensitive): void {
            $k = strtolower((string)$key);
            foreach ($sensitive as $p) {
                if (str_contains($k, $p)) {
                    $value = '********';
                    return;
                }
            }
            // سقف طول رشته — هم‌سمانت با استاندارد AuditTrail (ضد تورم ردیف)
            if (is_string($value) && mb_strlen($value) > 2000) {
                $value = mb_substr($value, 0, 2000) . '...';
            }
        });
        return $this->limitArrayDepth($masked, 5);
    }

    /**
     * سقف عمق آرایه — هم‌سمانت با AuditTrail (ضد انفجار حجم ردیف حسابرسی).
     *
     * @param array<int|string, mixed> $array
     * @return array<int|string, mixed>
     */
    private function limitArrayDepth(array $array, int $maxDepth, int $currentDepth = 0): array
    {
        if ($currentDepth >= $maxDepth) {
            return ['[MAX_DEPTH_REACHED]'];
        }
        $out = [];
        foreach ($array as $k => $v) {
            $out[$k] = is_array($v) ? $this->limitArrayDepth($v, $maxDepth, $currentDepth + 1) : $v;
        }
        return $out;
    }
}
