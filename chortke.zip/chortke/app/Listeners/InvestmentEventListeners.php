<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Contracts\LoggerInterface;
use Core\Container;

/**
 * InvestmentEventListeners - Centralized event handling for investment domain
 * 
 * Decouples InvestmentService from WalletServiceInterface, NotificationService, UserService, and ReferralService
 * by replacing direct method calls with event-driven handlers.
 * 
 * Dependencies are lazy-loaded via Container to avoid constructor bloat.
 */
class InvestmentEventListeners
{
    private Container $container;
    private LoggerInterface $logger;

    public function __construct(Container $container, LoggerInterface $logger) {
        // 🧹 DI-CLEANUP (2026-08-24): IdempotencyService حذف شد — تنها مصرف‌کننده‌ی
        // آن تزریق بود و هیچ متد زنده‌ای از آن استفاده نمی‌کند؛ تمام وابستگی‌های
        // عملیاتی (ReferralService, CacheInvalidationService, CurrencyService,
        // NotificationService) طبق سیاست کلاس به‌صورت lazy از Container گرفته
        // می‌شوند (container->make در متدهای کمکی پایین).
        $this->container = $container;
        $this->logger = $logger;
    }

    /**
     * Handle investment.created event
     * 
     * Triggers:
     * - Referral commission processing
     * - Wallet cache invalidation
     * - User notification
     */
    public function handleInvestmentCreated(mixed $event): void
    {
        try {
            if ($event instanceof \Core\Event) {
                $data = $event->getData();
            } elseif (is_array($event)) {
                $candidate = $event['data'] ?? $event;
                $data = is_array($candidate) ? $candidate : [];
            } else {
                $data = [];
            }
            $userId = $data['user_id'] ?? null;
            $amount = $data['amount'] ?? 0;
            $investmentId = $data['investment_id'] ?? null;

            if (!$userId || !$investmentId) {
                $this->logger->warning('investment.created event missing user_id or investment_id', $data);
                return;
            }

            $this->processReferralCommission($userId, $amount, 'investment_creation', [
                'investment_id' => $investmentId,
            ]);

            $this->invalidateWalletCache($userId);

            $this->notifyUser($userId, 'سرمایه‌گذاری ثبت شد', "سرمایه‌گذاری شما با موفقیت ثبت شد.");

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.InvestmentEventListeners.handleInvestmentCreated']);
            $this->logger->error('investment.created handler failed', [
                'error' => $e->getMessage(),
                'event' => $event,
            ]);
        }
    }

    /**
     * Handle investment.profit_applied event
     * 
     * Triggers:
     * - Wallet balance update notification
     * - User notification with profit/loss details
     */
    public function handleInvestmentProfitApplied(mixed $event): void
    {
        try {
            if ($event instanceof \Core\Event) {
                $data = $event->getData();
            } elseif (is_array($event)) {
                $candidate = $event['data'] ?? $event;
                $data = is_array($candidate) ? $candidate : [];
            } else {
                $data = [];
            }
            $userId = $data['user_id'] ?? null;
            $investmentId = $data['investment_id'] ?? null;
            $netAmount = $data['net_amount'] ?? 0;
            $balanceAfter = $data['balance_after'] ?? 0;
            $period = $data['period'] ?? null;
            $profitType = $data['profit_type'] ?? 'profit';

            if (!$userId || !$investmentId) {
                $this->logger->warning('investment.profit_applied event missing user_id or investment_id', $data);
                return;
            }

            $this->invalidateWalletCache($userId);

            $typeLabel = $profitType === 'profit' ? 'سود' : 'ضرر';
            $currencyService = $this->container->make('App\Services\CurrencyService');
            $amountFormatted = $currencyService->formatAmount(abs($netAmount), 'usdt');
            $balanceFormatted = $currencyService->formatAmount($balanceAfter, 'usdt');

            $this->notifyUser(
                $userId,
                "گزارش سرمایه‌گذاری: {$typeLabel}",
                "دوره {$period}: {$typeLabel} {$amountFormatted} | موجودی جدید: {$balanceFormatted}"
            );

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.InvestmentEventListeners.handleInvestmentProfitApplied']);
            $this->logger->error('investment.profit_applied handler failed', [
                'error' => $e->getMessage(),
                'event' => $event,
            ]);
        }
    }

    // 🧹 DEAD-CODE REMOVED: سه handler حذف شدند چون رویدادهایشان هیچ producer ای
    // ندارند (نه رشته‌ای، نه کلاس Event) و هرگز هم bind نشده بودند:
    //  • handleInvestmentWithdrawn — خطرناک‌ترین: واریز پول با کلید
    //    investment_withdrawal:{id} در حالی که مسیر زنده (saga ی
    //    investment_withdrawal_approval در InvestmentCommandService) با کلید
    //    investment_withdrawal_{id} پرداخت می‌کند؛ اگر روزی bind می‌شد = واریز دوبل.
    //  • handleInvestmentCompleted — اعلان تکمیل از مسیر زنده‌ی
    //    NotificationService → InvestmentCompletedNotificationJob ارسال می‌شود.
    //  • handleInvestmentFrozen — رویداد investment.frozen هیچ‌جا تولید نمی‌شود.
    // handleInvestmentCreated نگه داشته شد چون producer واقعی دارد
    // (InvestmentCreatedEvent در outbox ثبت می‌شود) و اکنون در AppServiceProvider
    // به همان FQCN بایند شده است.

    // ========== HELPER METHODS ==========

    /**
     * Process referral commission for investment actions
     *
     * @param string|int|float $amount
     * @param array<string, mixed> $metadata
     */
    private function processReferralCommission(int $userId, string|int|float $amount, string $action, array $metadata = []): void
    {
        try {
            $userService = $this->container->make('App\Services\User\UserService');
            $userRecord = $userService->findById($userId);

            if (!$userRecord || empty($userRecord->referred_by)) {
                return;
            }

            $amountStr = str_value($amount);
            $referralService = $this->container->make('App\Services\Shared\ReferralService');
            $referralService->processCommission((int)$userRecord->referred_by, $amountStr, 'usdt', [
                'action' => $action,
                'investor_id' => $userId,
                ...$metadata,
            ]);

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.InvestmentEventListeners.processReferralCommission']);
            $this->logger->warning('referral commission processing failed', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Invalidate wallet cache for a user
     */
    private function invalidateWalletCache(int $userId): void
    {
        try {
            $cacheService = $this->container->make('App\Services\Cache\CacheInvalidationService');
            $cacheService->invalidateWallet($userId);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.InvestmentEventListeners.invalidateWalletCache']);
            $this->logger->warning('wallet cache invalidation failed', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Send notification to user
     */
    private function notifyUser(int $userId, string $title, string $message, string $type = 'investment_update'): void
    {
        try {
            $notificationService = $this->container->make('App\Contracts\NotificationServiceInterface');
            $notificationService->send($userId, $type, $title, $message);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.InvestmentEventListeners.notifyUser']);
            $this->logger->warning('notification sending failed', [
                'user_id' => $userId,
                'title' => $title,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
