<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Contracts\LoggerInterface;
use Core\Event;

/**
 * AuditRegistryEvent — 🛡️ FIX-R22-B5 (راند ۲۲-B — سیم‌کشی رویدادهای بی‌شنونده)
 *
 * شنوندهٔ سبک فقط-مشاهده‌پذیری برای نام‌های رجیستریِ فاقد شنونده
 * (App\Events\Registry\EventRegistry) که در AppServiceProvider ثبت می‌شود:
 *   - crypto.deposit.confirmed
 *   - referral.commission.earned
 *   - influencer_order.partial_refunded
 *
 * زمینه: تولیدکننده‌های درون‌کد این سه نام در پاس‌های FIX-DEAD-EVENT حذف و به
 * رویدادهای canonical سیم‌شده (wallet.deposit.requested و ...) یکسان‌سازی شدند؛
 * اما ردیف‌های pending قدیمی outbox هنوز می‌توانند از مسیر OutboxPublisher
 * (dispatchOrFail) دیسپچ شوند. این شنونده تضمین می‌کند چنین رویدادی لاگ
 * ساختاریافته بگیرد (به‌جای event.no_listeners) و بازپخش/تماس‌های آینده
 * بی‌صدا گم نشوند. هیچ اثر جانبی مالی/اعلانی ندارد (مرز مسئولیت).
 */
class AuditRegistryEvent
{
    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    public function handle(Event $event): void
    {
        try {
            $data = $event->getData();

            // فقط شناسه‌ها/متادیتای بی‌خطر — نه payload خام (بهداشت لاگ)
            $ids = [];
            foreach (['id', 'user_id', 'order_id', 'deposit_id', 'transaction_id', 'amount', 'currency', 'service'] as $field) {
                if (isset($data[$field])) {
                    $ids[$field] = $data[$field];
                }
            }

            $this->logger->info('registry.event.observed', $ids);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'app.Listeners.AuditRegistryEvent.handle',
            ]);
        }
    }
}
