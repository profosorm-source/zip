<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\WithdrawalCreatedEvent;
use App\Events\WithdrawalApprovedEvent;
use App\Services\Notification\NotificationService;
use App\Services\AuditTrail;
use App\Contracts\LoggerInterface;
use Core\Container;

/**
 * WithdrawalListener - Decouples withdrawal events from service layer
 * 
 * Handles:
 * - WithdrawalCreatedEvent: audit logging, notifications
 * - WithdrawalApprovedEvent: score updates, notifications
 */
/**
 * ⚠️ الگوی رسمی (A4): وابستگی‌های سنگین عمداً به‌صورت lazy از Container گرفته
 * می‌شوند (سازنده فقط Container/Logger) تا از چرخه‌ی رویدادی
 * (Event → Service → dispatch → Listener) جلوگیری شود.
 * مرجع: docs/architecture_and_standards.md §۶
 */

class WithdrawalListener
{
    private Container $container;
    private LoggerInterface $logger;

    public function __construct(Container $container, LoggerInterface $logger) {
        $this->container = $container;
        $this->logger = $logger;
    }

    /**
     * 🧹 S31-C-W1-3: handleWithdrawalEvent(WithdrawalEvent) حذف شد — کلاس
     * WithdrawalEvent هیچ‌گاه produce/register نشده بود (حذف مستدل با تأیید کاربر).
     * مسیرهای زندهٔ withdrawal.created/approved همان متدهای untyped پایین‌اند.
     */
    public function handleWithdrawalCreated(\Core\Event $event): void
    {
        try {
            $this->processWithdrawalCreated((array)$event->getData());
        } catch (\Throwable $e) {
            $this->logger->error('withdrawal.created listener failed', [
                'error' => $e->getMessage(),
                'event' => $event->getData()
            ]);
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'withdrawal.listener.created',
            ]);
        }
    }

    public function handleWithdrawalApproved(\Core\Event $event): void
    {
        try {
            $this->processWithdrawalApproved((array)$event->getData());
        } catch (\Throwable $e) {
            $this->logger->error('withdrawal.approved listener failed', [
                'error' => $e->getMessage(),
                'event' => $event->getData()
            ]);
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'withdrawal.listener.approved',
            ]);
        }
    }

    /** @param array<string, mixed> $data */
    private function processWithdrawalCreated(array $data): void
    {
        $userId = int_value($data['user_id'] ?? 0);
        $withdrawalId = int_value($data['withdrawal_id'] ?? 0);
        $amount = str_value($data['amount'] ?? 0);
        $currency = str_value($data['currency'] ?? 'irt');

        if (!$userId || !$withdrawalId) {
            $this->logger->warning('withdrawal.created event missing required data', $data);
            return;
        }

        $auditTrail = $this->container->make(AuditTrail::class);
        $auditTrail->logEvent([
            'user_id' => $userId,
            'action' => 'withdrawal.created',
            'resource_id' => $withdrawalId,
            'metadata' => [
                'amount' => $amount,
                'currency' => $currency,
                'status' => $data['status'] ?? 'pending'
            ]
        ]);

        // FIX-S18-6 (unity): اعلان فقط از درِ واحد notification.requested (outbox)
        // — فراخوانی مستقیم NotificationService در شنونده‌ها ممنوع است.
        $outbox = $this->container->make(\App\Contracts\OutboxServiceInterface::class);
        $outbox->record('notification', $userId, 'notification.requested', [
            'event_id'   => 'wd_created_' . $withdrawalId, // 🛡️ FIX-R18-M11: dedupe قطعی
            'user_id'    => $userId,
            'type'       => 'withdrawal.created',
            'title'      => 'درخواست برداشت ثبت شد',
            'message'    => "درخواست برداشت #{$withdrawalId} با مبلغ {$amount} {$currency} ثبت شد.",
            'data'       => ['withdrawal_id' => $withdrawalId, 'event_id' => 'wd_created_' . $withdrawalId],
        ]);
    }

    /** @param array<string, mixed> $data */
    private function processWithdrawalApproved(array $data): void
    {
        $userId = int_value($data['user_id'] ?? 0);
        $withdrawalId = int_value($data['withdrawal_id'] ?? 0);
        $amount = str_value($data['amount'] ?? 0);

        if (!$userId || !$withdrawalId) {
            $this->logger->warning('withdrawal.approved event missing required data', $data);
            return;
        }

        // FIX-X5a: دامنهٔ 'score_trust' در ScoreDomain وجود ندارد (فقط social_trust معتبر است).
        // قبلاً exception در applyDelta کل listener را می‌کُشت و اعلان تأیید برداشت هرگز
        // به کاربر نمی‌رسید (لاگ: "Unsupported score domain: score_trust").
        try {
            $scoreService = $this->container->make(\App\Services\ScoreService::class);
            // L-13 Fix: idempotency key تا تحویل تکراری رویداد approve امتیاز trust را چندبار افزایش ندهد.
            $scoreService->applyDelta('user', $userId, 'social_trust', 5, 'withdrawal_approved', [], 'withdrawal_approved_' . $withdrawalId);
        } catch (\Throwable $scoreError) {
            // امتیاز جانبی است؛ نباید مانع audit و اعلان کاربر شود.
            $this->logger->warning('withdrawal.approved.score_failed_nonblocking', [
                'user_id' => $userId,
                'withdrawal_id' => $withdrawalId,
                'error' => $scoreError->getMessage(),
            ]);
        }

        try {
            $auditTrail = $this->container->make(AuditTrail::class);
            $auditTrail->logEvent([
                'user_id' => $userId,
                'action' => 'withdrawal.approved',
                'resource_id' => $withdrawalId,
                'metadata' => ['amount' => $amount]
            ]);
        } catch (\Throwable $auditError) {
            $this->logger->warning('withdrawal.approved.audit_failed_nonblocking', [
                'user_id' => $userId,
                'withdrawal_id' => $withdrawalId,
                'error' => $auditError->getMessage(),
            ]);
        }

        // FIX-S18-6 (unity): اعلان فقط از درِ واحد notification.requested (outbox)
        // — فراخوانی مستقیم NotificationService در شنونده‌ها ممنوع است.
        $outbox = $this->container->make(\App\Contracts\OutboxServiceInterface::class);
        $outbox->record('notification', $userId, 'notification.requested', [
            'event_id'   => 'wd_approved_' . $withdrawalId, // 🛡️ FIX-R18-M11: dedupe قطعی
            'user_id'    => $userId,
            'type'       => 'withdrawal.approved',
            'title'      => 'درخواست برداشت تأیید شد',
            'message'    => "درخواست برداشت #{$withdrawalId} تأیید شد و به زودی پردازش خواهد شد.",
            'data'       => ['withdrawal_id' => $withdrawalId, 'event_id' => 'wd_approved_' . $withdrawalId],
        ]);
    }

    // 🧹 S31-C-W1-3: processWithdrawalCancelled() و processWithdrawalReversed() حذف شدند —
    // تنها فراخوان‌شان handleWithdrawalEvent(WithdrawalEvent) بود که خودش هیچ‌گاه
    // register نشده بود (کد مردهٔ از قبل). منطق cancelled/reversed در تاریخچهٔ git
    // و دفتر کل حذف rule-6 این بچ ثبت است؛ مسیر زنده فقط created/approved است.
}
