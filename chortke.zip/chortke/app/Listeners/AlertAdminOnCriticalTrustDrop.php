<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Contracts\NotificationServiceInterface;
use App\Contracts\LoggerInterface;

/**
 * AlertAdminOnCriticalTrustDrop
 *
 * 🛡️ WIRE-DEAD-EVENT (فاز N-4 / تسک ۹۰-c): رویداد trust.critical_drop از
 * TrustService::evaluate (وقتی افت اعتماد منفی بود و امتیاز فعلی زیر ۵۰- سقوط کرد)
 * در outbox ثبت می‌شد اما از همیشه هیچ شنونده‌ای نداشت — هشدار «کاربر متقلب در
 * آستانهٔ بحرانی» بی‌صدا گم می‌شد.
 *
 * با رزولوشن نامِ payload['event_name'] در OutboxPublisher (FIX-X347) این رویداد
 * اکنون به‌صورت «trust.critical_drop» دیسپچ می‌شود و این شنونده (ثبت‌شده در
 * AppServiceProvider) اعلان ادمین‌ها را می‌سازد.
 *
 * الگوی خانه: آینهٔ AlertAdminOnCriticalFeatureChange (sendToAdmins + لاگ critical)
 * با امضای \Core\Event چون رویداد از outbox به‌صورت GenericEvent می‌رسد.
 *
 * قصد محصولی: فقط هشدار — مسدودسازی خودکار کاربر (auto-ban) خارج از دامنهٔ این تسک است.
 */
class AlertAdminOnCriticalTrustDrop
{
    private NotificationServiceInterface $notificationService;
    private LoggerInterface $logger;
    private \Core\Cache $cache;
    public function __construct(
        NotificationServiceInterface $notificationService,
        LoggerInterface $logger,
        \Core\Cache $cache
    ) {        $this->notificationService = $notificationService;
        $this->logger = $logger;
        $this->cache = $cache;
}

    public function handle(\Core\Event $event): void
    {
        $rawData = $event->getData();
        $data = is_array($rawData) ? $rawData : [];
        $userId = int_value($data['user_id'] ?? 0);
        $currentTrust = float_value($data['current_trust'] ?? 0.0);
        $context = str_value($data['context'] ?? 'global');

        try {
            if ($userId <= 0) {
                return;
            }

            // 🛡️ FIX-EV-5 (بازبینی مجدد ایونت‌ها): گارد cooldown ساعتی per-user — نوسان امتیاز
            // اعتماد زیر آستانه در هر دلتای منفی ادمین‌ها را دوباره هشدار می‌داد (alert storm).
            // الگوی ScoreUpdateListener::shouldSendThresholdAlert؛ کشِ نام available → fail-open.
            $cooldownKey = "trust:critical_drop_alert:{$userId}";
            try {
                if ($this->cache->has($cooldownKey)) {
                    return;
                }
                $this->cache->putSeconds($cooldownKey, 1, 3600);
            } catch (\Throwable) {
                // کش ناموجود: fail-open — بهتر از از دست دادن هشدار تقلب
            }

            $title = "🚨 افت شدید امتیاز اعتماد کاربر #{$userId}";
            $message = "امتیاز اعتماد کاربر #{$userId} در ماژول «{$context}» به عدد {$currentTrust} رسیده است (آستانهٔ بحرانی: -50). بررسی دستی رفتار اخیر کاربر توصیه می‌شود.";

            $sent = $this->notificationService->sendToAdmins(
                'critical_trust_drop',
                $title,
                $message,
                [
                    'user_id'       => $userId,
                    'current_trust' => $currentTrust,
                    'context'       => $context,
                    'action_required' => true,
                    'automated_trigger' => true,
                ],
                'high'
            );

            if ($sent === 0) {
                $this->logger->warning('critical_trust_drop.no_admin_notified', ['user_id' => $userId]);
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.AlertAdminOnCriticalTrustDrop.handle']);
            $this->logger->error('critical_trust_drop.admin_alert_failed', [
                'user_id' => int_value($data['user_id'] ?? 0),
                'error'   => $e->getMessage(),
            ]);
            return;
        }

        $this->logger->critical('critical_trust_drop.alert_sent', [
            'user_id'       => $userId,
            'current_trust' => $currentTrust,
            'context'       => $context,
            'notified'      => $sent,
        ]);
    }
}
