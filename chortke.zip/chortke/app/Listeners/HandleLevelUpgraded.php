<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\LevelUpgradedEvent;
use App\Contracts\NotificationServiceInterface;
use App\Contracts\LoggerInterface;
use Core\Database;

/**
 * HandleLevelUpgraded
 *
 * پس از ارتقاء سطح کاربر:
 * ۱. ارسال notification تبریک لِوِل‌آپ
 * ۲. ثبت در جدول audit برای traceability
 * ۳. اعطای badge متناظر با سطح جدید
 */
class HandleLevelUpgraded
{
    /**
     * نقشه badge به سطح کاربر
     */
    // 🛡️ FIX-X143 (B6 — راند 37): نقشهٔ نشان قبلاً ناقص بود (bronze→silver→gold→
    // diamond→«elite» که سطحش وجود ندارد) و انتقال به vip/platinum بدون نشان می‌ماند.
    // 🛡️ FIX-X152 (راند 37): کلید نقشه اکنون «سطح جدید» است نه سطح قبلی — چون
    // ارتقا جهشی است (مثلاً برنز → VIP در یک award) و نشان باید متناظر با سطحی
    // باشد که کاربر به آن رسیده؛ نگاشت قدیمی (بر پایهٔ سطح قبلی) در پرش‌ها نشان
    // اشتباه می‌داد (برنز→VIP نشان نقره‌ای می‌گرفت!). برنز سطح پایه است و نشان ندارد.
    private const LEVEL_BADGE_MAP = [
        'silver'   => ['badge_silver',   'نقره‌ای'],
        'gold'     => ['badge_gold',     'طلایی'],
        'vip'      => ['badge_vip',      'VIP'],
        'platinum' => ['badge_platinum', 'پلاتینیوم'],
        'diamond'  => ['badge_diamond',  'الماس'],
    ];

    private NotificationServiceInterface $notificationService;
    private LoggerInterface $logger;
    private Database $db;
    public function __construct(
        NotificationServiceInterface $notificationService,
        LoggerInterface $logger,
        Database $db
    ) {        $this->notificationService = $notificationService;
        $this->logger = $logger;
        $this->db = $db;
}

    public function handle(LevelUpgradedEvent $event): void
    {
        $userId   = $event->userId;
        $oldLevel = $event->oldLevel;
        $newLevel = $event->newLevel;

        // ۱. Notification
        $this->sendLevelUpNotification($userId, $oldLevel, $newLevel);

        // ۲. ثبت در Audit Trail
        $this->recordAudit($userId, $oldLevel, $newLevel, $event->reason);

        // ۳. اعطای Badge
        $this->awardBadge($userId, $oldLevel, $newLevel);
    }

    private function sendLevelUpNotification(int $userId, string $oldLevel, string $newLevel): void
    {
        try {
            $this->notificationService->send(
                $userId,
                'level_upgraded',
                '🎉 ارتقاء سطح!',
                "تبریک! سطح شما از {$oldLevel} به {$newLevel} ارتقاء یافت.",
                [
                    'old_level' => $oldLevel,
                    'new_level' => $newLevel,
                ],
                null,
                null,
                'high'
            );
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleLevelUpgraded.sendLevelUpNotification']);
            $this->logger->error('level.notification_failed', [
                'user_id'   => $userId,
                'new_level' => $newLevel,
                'error'     => $e->getMessage(),
            ]);
        }
    }

    private function recordAudit(int $userId, string $oldLevel, string $newLevel, string $reason): void
    {
        try {
            // 🛡️ FIX-X154 (راند 37): جدول audit_logs ستون `event` ندارد (ستون واقعی
            // `action` است) — در نتیجه ثبت audit ارتقا همیشه شکست می‌خورد و فقط در
            // لاگ ردی می‌شد. اکنون با اسکیمای واقعی هم‌راستا شد.
            $this->db->prepare(
                "INSERT INTO audit_logs (user_id, action, details, created_at)
                 VALUES (?, 'level.upgraded', ?, NOW())"
            )->execute([
                $userId,
                json_encode([
                    'old_level' => $oldLevel,
                    'new_level' => $newLevel,
                    'reason'    => $reason,
                ], JSON_UNESCAPED_UNICODE),
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleLevelUpgraded.recordAudit']);
            $this->logger->error('level.audit_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
        }
    }

    private function awardBadge(int $userId, string $oldLevel, string $newLevel): void
    {
        // 🛡️ FIX-X152: نشان بر اساس «سطح جدید» انتخاب می‌شود (نگاه به کامنت نگروه بالا)
        if (!isset(self::LEVEL_BADGE_MAP[$newLevel])) {
            return;
        }

        [$badgeSlug, $badgeLabel] = self::LEVEL_BADGE_MAP[$newLevel];

        try {
            // Upsert badge: در صورت وجود قبلی، updated_at را بروز می‌کند
            $this->db->prepare(
                "INSERT INTO user_badges (user_id, badge_slug, awarded_at)
                 VALUES (?, ?, NOW())
                 ON DUPLICATE KEY UPDATE awarded_at = NOW()"
            )->execute([$userId, $badgeSlug]);

            $this->logger->info('level.badge_awarded', [
                'user_id'    => $userId,
                'badge_slug' => $badgeSlug,
                'badge'      => $badgeLabel,
                'new_level'  => $newLevel,
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleLevelUpgraded.awardBadge']);
            // جدول ممکن است هنوز وجود نداشته باشد؛ fallback به log
            $this->logger->warning('level.badge_award_failed', [
                'user_id'    => $userId,
                'badge_slug' => $badgeSlug,
                'error'      => $e->getMessage(),
            ]);
        }
    }
}
