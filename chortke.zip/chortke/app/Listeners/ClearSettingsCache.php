<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\SettingsUpdated;
use Core\Cache;
use App\Services\Settings\AppSettings;

class ClearSettingsCache
{
    private Cache $cache;
    private AppSettings $appSettings;

    public function __construct(Cache $cache, AppSettings $appSettings) {
        $this->cache = $cache;
        $this->appSettings = $appSettings;
    }

    public function handle(SettingsUpdated $event): void
    {
        try {
            // 1. Clear Distributed/Redis cache
            $this->cache->forget('system:settings:v2');

            // 2. Clear Local Instance Cache
            $this->appSettings->clearInstanceCache();
        } catch (\Throwable $e) {
            // 🛡️ FIX-EV-8 (بازبینی مجدد ایونت‌ها): شکست cache backend هرگز نباید پخش
            // settings را به خطا بکشد — بدترین حالت، کش موقتی stale است (بر اساس الگوی
            // fail-safe سایر شنونده‌ها).
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ClearSettingsCache.handle']);
        }
    }
}
