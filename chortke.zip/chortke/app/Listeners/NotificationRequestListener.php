<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Contracts\LoggerInterface;
use Core\Container;

/**
 * NotificationRequestListener
 *
 * Centralized handler for all notification request events.
 * Supports multiple event shapes for flexibility.
 */
/**
 * ⚠️ الگوی رسمی (A4): وابستگی‌های سنگین عمداً به‌صورت lazy از Container گرفته
 * می‌شوند (سازنده فقط Container/Logger) تا از چرخه‌ی رویدادی
 * (Event → Service → dispatch → Listener) جلوگیری شود.
 * مرجع: docs/architecture_and_standards.md §۶
 */

class NotificationRequestListener
{
    private Container $container;
    private LoggerInterface $logger;

    public function __construct(Container $container, LoggerInterface $logger) {
        $this->container = $container;
        $this->logger = $logger;
    }

    public function handle(mixed $event): void
    {
        try {
            // FIX: Listener may run from HTTP request OR CLI/Job context.
            $correlationId = null;
            if (PHP_SAPI !== 'cli' && function_exists('app')) {
                try {
                    $correlationId = app()->request->header('x-request-id');
                } catch (\Throwable $e) {
                    \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.NotificationRequestListener.handle']);
                    $this->logger->warning('notificationrequestlistener.operation_failed', ['error' => $e->getMessage()]);
                }
            }

            $userId = null;
            $type = '';
            $title = '';
            $message = '';
            $data = [];
            $actionUrl = null;
            $actionText = null;
            $priority = 'normal';

            // 🧹 S31-C-W1-5: شاخهٔ typed NotificationRequestedEvent حذف شد (کلاس حذف شد —
            // هیچ producer ای آن را نمی‌سازد؛ مسیر زندهٔ outbox همین دو شاخهٔ زیر است).
            if ($event instanceof \Core\Event) {
                $d = $event->getData();
                $d = is_array($d) ? $d : [];
                $userId = $d['user_id'] ?? ($d['recipient_id'] ?? null);
                $type = $d['type'] ?? 'system';
                $title = $d['title'] ?? '';
                $message = $d['message'] ?? '';
                $data = $d['data'] ?? [];
                $actionUrl = $d['action_url'] ?? null;
                $actionText = $d['action_text'] ?? null;
                $priority = $d['priority'] ?? 'normal';
            } elseif (is_array($event)) {
                $userId = $event['user_id'] ?? ($event['recipient_id'] ?? null);
                $type = $event['type'] ?? 'system';
                $title = $event['title'] ?? '';
                $message = $event['message'] ?? '';
                $data = $event['data'] ?? [];
                $actionUrl = $event['action_url'] ?? null;
                $actionText = $event['action_text'] ?? null;
                $priority = $event['priority'] ?? 'normal';
            } else {
                return;
            }

            // Inject correlation into data for tracing in notifications
            if (!is_array($data)) $data = [];
            if (empty($correlationId)) {
                $correlationId = $data['correlation_id'] ?? 'cli-' . bin2hex(random_bytes(4));
            }
            $data['correlation_id'] = $correlationId;

            // FIX-S18-6A: درِ واحد سه شکل رسمی payload را روت می‌کند —
            //   ۱) ساده   {user_id, type, title, message, ...}            → send()
            //   ۲) قالبی   {user_id, template, template_vars, ...}        → sendFromTemplate()
            //   ۳) ادمین   {target: 'admins', type, title, message, ...}  → sendToAdmins()
            // (شکل ادمین user_id ندارد ⇒ پیش از گارد user_id بررسی می‌شود.)
            $target = null;
            if ($event instanceof \Core\Event) {
                $rawTarget = $d['target'] ?? null;
                $target = is_string($rawTarget) ? strtolower(trim($rawTarget)) : null;
            } elseif (is_array($event)) {
                $rawTarget = $event['target'] ?? null;
                $target = is_string($rawTarget) ? strtolower(trim($rawTarget)) : null;
            }

            if ($target === 'admins') {
                /** @var \App\Services\Notification\NotificationService $notificationService */
                $notificationService = $this->container->make(\App\Services\Notification\NotificationService::class);
                $notificationService->sendToAdmins(
                    (string)$type,
                    (string)$title,
                    (string)$message,
                    (array)$data,
                    (string)$priority
                );
                $this->logger->debug('notification.request.processed', [
                    'target' => 'admins',
                    'type' => $type,
                    'correlation_id' => $correlationId
                ]);
                return;
            }

            if (empty($userId)) {
                $this->logger->warning('notification.request.missing_user', [
                    'event' => $event,
                    'correlation_id' => $correlationId
                ]);
                return;
            }

            $template = null;
            if ($event instanceof \Core\Event) {
                $template = isset($d['template']) && is_string($d['template']) && $d['template'] !== '' ? $d['template'] : null;
            } elseif (is_array($event)) {
                $template = isset($event['template']) && is_string($event['template']) && $event['template'] !== '' ? $event['template'] : null;
            }

            /** @var \App\Services\Notification\NotificationService $notificationService */
            $notificationService = $this->container->make(\App\Services\Notification\NotificationService::class);

            if ($template !== null) {
                $templateVars = $event instanceof \Core\Event
                    ? ($d['template_vars'] ?? [])
                    : ($event['template_vars'] ?? []);
                if (!is_array($templateVars)) $templateVars = [];

                $notificationService->sendFromTemplate(
                    (int)$userId,
                    $template,
                    $templateVars,
                    (string)$priority,
                    $actionUrl,
                    $actionText,
                    null,
                    null
                );
            } else {
                $notificationService->send(
                    (int)$userId,
                    (string)$type,
                    (string)$title,
                    (string)$message,
                    (array)$data,
                    $actionUrl,
                    $actionText,
                    $priority
                );
            }

            $this->logger->debug('notification.request.processed', [
                'user_id' => $userId,
                'type' => $type,
                'correlation_id' => $correlationId
            ]);

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.NotificationRequestListener.handle']);
            $this->logger->error('notification.request.listener_failed', [
                'error' => $e->getMessage(),
                'event' => $event,
                'correlation_id' => $correlationId ?? null
            ]);
        }
    }
}
