<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Contracts\LoggerInterface;
use App\Contracts\NotificationServiceInterface;
use App\Models\FraudAnalyticsModel;
use Core\Database;

class ProcessFraudAlert
{
    private LoggerInterface $logger;
    private Database $db;
    private NotificationServiceInterface $notifications;
    private FraudAnalyticsModel $fraudAnalytics;

    public function __construct(
        LoggerInterface $logger,
        Database $db,
        NotificationServiceInterface $notifications,
        FraudAnalyticsModel $fraudAnalytics
    ) {
        $this->logger = $logger;
        $this->db = $db;
        $this->notifications = $notifications;
        $this->fraudAnalytics = $fraudAnalytics;
    }

    public function handle(\Core\Event $event): void
    {
        // FIX-EVENT-WIRING-2: رویداد fraud.score_updated از طریق outbox با
        // payload آرایه‌ای {user_id, fraud_score} منتشر می‌شود (GenericEvent)؛
        // امضای تایپ‌دار قبلی TypeError می‌داد و هشدارهای امتیاز تقلب بالا
        // هرگز پردازش نمی‌شد.
        try {
            $rawData = $event->getData();
            $data = is_array($rawData) ? $rawData : [];
            $userId = int_value($data['user_id'] ?? 0);
            $score = (int) float_value($data['fraud_score'] ?? ($data['score'] ?? 0));

            // Ignore normal scores to reduce noise
            if ($score < 75 || $userId <= 0) {
                return;
            }

            // 🚨 1. Log massive security threat to system loggers asynchronously
            $severity = $score >= 90 ? 'CRITICAL' : 'WARNING';
            $this->logger->critical("anti_fraud.high_risk_detected", [
                'user_id' => $userId,
                'score' => $score,
                'severity' => $severity,
                'message' => "User #{$userId} exceeded safe fraud score thresholds with value {$score}"
            ]);

            // 🛡️ FIX-M28-05 (T28-09 + A5-2): مسیر درست هشدار بحرانی — قبلاً
            // نوتیفیکیشن «امتیاز تقلب بحرانی» با SQL مستقیم به خودِ کاربر مظنون
            // درج می‌شد (افشای عدد و آستانه به مظنون — تصمیم محصول C6 در همین
            // روند معکوس شد) و ادمین از هیچ کانالی باخبر نمی‌شد: جدول fraud_alerts
            // هیچ نویسنده‌ای نداشت و پنل «فعالیت‌های مشکوک» داشبورد ضدتقلب همیشه
            // خالی بود. اکنون: (۱) dedup ساعتی روی fraud_alerts، (۲) ردیف
            // fraud_alerts برای داشبورد امنیت، (۳) هشدار به همهٔ ادمین‌ها از طریق
            // sendToAdmins (الگوی HandleRateLimitExceeded) — کاربر مظنون دیگر
            // نوتیفیکیشن امتیاز نمی‌گیرد.
            $recentAlerts = (int)$this->db->fetchColumn(
                "SELECT COUNT(*) FROM fraud_alerts
                  WHERE user_id = ? AND alert_type = 'high_fraud_score'
                    AND created_at > (NOW() - INTERVAL 1 HOUR)
                  LIMIT 1",
                [$userId]
            );
            if ($recentAlerts > 0) {
                return;
            }

            $this->fraudAnalytics->createAlert([
                'user_id' => $userId,
                'alert_type' => 'high_fraud_score',
                'severity' => $score >= 90 ? 'critical' : 'high',
                'title' => "امتیاز تقلب بحرانی: کاربر #{$userId}",
                'description' => "امتیاز تقلب کاربر #{$userId} به {$score} رسید (آستانهٔ بحرانی ۷۵).",
                'details' => [
                    'score' => $score,
                    'action_required' => true,
                    'automated_trigger' => true,
                ],
            ]);

            $this->notifications->sendToAdmins(
                'high_fraud_alert',
                '🚨 هشدار امنیتی: امتیاز تقلب بحرانی',
                "امتیاز تقلب کاربر #{$userId} به مرز بحرانی {$score} رسید.",
                [
                    'user_id' => $userId,
                    'score' => $score,
                    'action_required' => true,
                    'automated_trigger' => true,
                ],
                'high'
            );

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ProcessFraudAlert.handle']);
            $this->logger->error('listener.process_fraud_alert.failed', [
                'user_id' => $userId ?? 0,
                'error' => $e->getMessage()
            ]);
        }
    }
}
