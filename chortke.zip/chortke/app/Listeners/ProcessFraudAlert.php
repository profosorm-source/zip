<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\FraudScoreUpdatedEvent;
use App\Contracts\LoggerInterface;
use Core\Database;

class ProcessFraudAlert
{
    private LoggerInterface $logger;
    private Database $db;
    public function __construct(
        LoggerInterface $logger,
        Database $db
    ) {        $this->logger = $logger;
        $this->db = $db;
}

    public function handle(\Core\Event $event): void
    {
        // FIX-EVENT-WIRING-2: رویداد fraud.score_updated از طریق outbox با
        // payload آرایه‌ای {user_id, fraud_score} منتشر می‌شود (GenericEvent)؛
        // امضای تایپ‌دار قبلی TypeError می‌داد و هشدارهای امتیاز تقلب بالا
        // هرگز پردازش نمی‌شد.
        try {
            $rawData = $event->getData();
            $data = is_array($rawData) ? $rawData : [];
            $userId = int_value($data['user_id'] ?? 0);
            $score = (int) float_value($data['fraud_score'] ?? ($data['score'] ?? 0));

            // Ignore normal scores to reduce noise
            if ($score < 75) {
                return;
            }

            // 🚨 1. Log massive security threat to system loggers asynchronously
            $severity = $score >= 90 ? 'CRITICAL' : 'WARNING';
            $this->logger->critical("anti_fraud.high_risk_detected", [
                'user_id' => $userId,
                'score' => $score,
                'severity' => $severity,
                'message' => "User #{$userId} exceeded safe fraud score thresholds with value {$score}"
            ]);

            // 🚨 2. Write to system_notifications table for dashboard alerts (heavy I/O decoupled!)
            $this->db->query(
                "INSERT INTO notifications (user_id, type, message, data, created_at) VALUES (?, ?, ?, ?, NOW())",
                [
                    $userId,
                    'high_fraud_alert',
                    "امتیاز تقلب کاربر به مرز بحرانی {$score} رسید.",
                    json_encode([
                        'score' => $score,
                        'action_required' => true,
                        'automated_trigger' => true
                    ])
                ]
            );

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ProcessFraudAlert.handle']);
            $this->logger->error('listener.process_fraud_alert.failed', [
                'user_id' => $userId ?? 0,
                'error' => $e->getMessage()
            ]);
        }
    }
}
