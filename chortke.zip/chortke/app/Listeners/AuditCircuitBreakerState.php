<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Contracts\LoggerInterface;

/**
 * AuditCircuitBreakerState — 🛡️ FIX-EV-8 (S21 — بازبینی سیم‌کشی رویدادها)
 *
 * CircuitBreaker برای هر تغییر وضعیت (open → نیمه‌باز → بسته) رویداد
 * 'circuit_breaker.opened' / 'circuit_breaker.closed' دیسپچ می‌کرد اما هیچ
 * شنونده‌ای روی آن‌ها ثبت نبود — یعنی از کار افتادن یک سرویس خارجی (یا بازگشت آن)
 * فقط در لاگ لحظه‌ایِ breaker دیده می‌شد و هیچ ردیهٔ ماندگار/هشداری تولید نمی‌شد.
 *
 * این شنونده فقط «مشاهده‌پذیری» می‌سازد:
 *   - لاگ ساختاریافته با سطح مناسب (warning برای open، info برای close)
 *   - ثبت در audit_trail از مسیر استاندارد AuditTrail::record (event-driven)
 *
 * هیچ منطق بازیابی/مسدودسازی اینجا انجام نمی‌شود (مرز مسئولیت با CircuitBreaker).
 *
 * الگوی خانه: آینهٔ سایر شنونده‌های اطلاع‌رسانی؛ امضای \Core\Event چون رویداد
 * به‌صورت GenericEvent (آرایهٔ payload) می‌رسد.
 */
class AuditCircuitBreakerState
{
    private LoggerInterface $logger;
    private \App\Services\AuditTrail $auditTrail;

    public function __construct(LoggerInterface $logger, \App\Services\AuditTrail $auditTrail)
    {
        $this->logger = $logger;
        $this->auditTrail = $auditTrail;
    }

    public function handleOpened(\Core\Event $event): void
    {
        $this->record('circuit_breaker.opened', 'warning', $event->getData());
    }

    public function handleClosed(\Core\Event $event): void
    {
        $this->record('circuit_breaker.closed', 'info', $event->getData());
    }

    /** @param array<string, mixed> $data */
    private function record(string $eventName, string $level, array $data): void
    {
        $service = is_scalar($data['service'] ?? null) ? (string)($data['service'] ?? '') : '';
        $error = is_scalar($data['error'] ?? null) ? (string)($data['error'] ?? '') : '';

        try {
            $this->logger->$level($eventName, [
                'channel' => 'circuit_breaker',
                'service' => $service,
                'error'   => $error !== '' ? $error : null,
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'app.Listeners.AuditCircuitBreakerState.record',
            ]);
        }

        // ثبت ماندگار در audit_trail — توجه: AuditTrail::record خودش dispatch می‌کند؛
        // حلقه‌ای نمی‌سازیم چون AuditRecordedEvent رویداد دیگری است و این شنونده
        // فقط به circuit_breaker.* گوش می‌دهد.
        try {
            $this->auditTrail->record($eventName, null, [
                'service' => $service,
                'error'   => $error !== '' ? mb_substr($error, 0, 500) : null,
            ]);
        } catch (\Throwable $e) {
            // audit غیربحرانی است — شکست آن نباید جریان breaker را بشکند
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'app.Listeners.AuditCircuitBreakerState.audit_failed',
            ]);
        }
    }
}
