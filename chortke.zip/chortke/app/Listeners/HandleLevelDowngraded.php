<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\LevelDowngradedEvent;
use App\Contracts\NotificationServiceInterface;
use App\Contracts\LoggerInterface;
use Core\Database;

/**
 * HandleLevelDowngraded (T27-13)
 *
 * پس از کاهش سطح کاربر:
 * ۱. ارسال اعلان (انقضای سطح خریداری‌شده یا تنزل بر اساس XP)
 * ۲. ثبت در audit
 * ۳. فقط در انقضای خرید: برداشتن نشان سطح منقضی‌شده (نشان همراه انقضا می‌رود)
 */
class HandleLevelDowngraded
{
    // هم‌نقشهٔ HandleLevelUpgraded::LEVEL_BADGE_MAP (کلید: slug سطح)
    private const LEVEL_BADGE_SLUGS = [
        'silver'   => 'badge_silver',
        'gold'     => 'badge_gold',
        'vip'      => 'badge_vip',
        'platinum' => 'badge_platinum',
        'diamond'  => 'badge_diamond',
    ];

    private NotificationServiceInterface $notificationService;
    private LoggerInterface $logger;
    private Database $db;

    public function __construct(NotificationServiceInterface $notificationService, LoggerInterface $logger, Database $db)
    {
        $this->notificationService = $notificationService;
        $this->logger = $logger;
        $this->db = $db;
    }

    public function handle(LevelDowngradedEvent $event): void
    {
        $expired = $event->reason === 'expired';

        $this->notify($event, $expired);
        $this->recordAudit($event);
        if ($expired) {
            $this->removeBadge($event->userId, $event->oldLevel);
        }
    }

    private function notify(LevelDowngradedEvent $event, bool $expired): void
    {
        try {
            $title = $expired ? '⏳ انقضای سطح' : '📉 کاهش سطح';
            $body = $expired
                ? "مدت اعتبار سطح {$event->oldLevel} به پایان رسید و سطح شما به {$event->newLevel} بازگشت."
                : "به‌دلیل کاهش امتیاز، سطح شما از {$event->oldLevel} به {$event->newLevel} کاهش یافت.";
            $this->notificationService->send(
                $event->userId,
                $expired ? 'level_expired' : 'level_downgraded',
                $title,
                $body,
                ['old_level' => $event->oldLevel, 'new_level' => $event->newLevel],
                null,
                null,
                'high'
            );
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleLevelDowngraded.notify']);
            $this->logger->error('level.downgrade_notification_failed', ['user_id' => $event->userId, 'error' => $e->getMessage()]);
        }
    }

    private function recordAudit(LevelDowngradedEvent $event): void
    {
        try {
            $this->db->prepare(
                "INSERT INTO audit_logs (user_id, action, details, created_at) VALUES (?, 'level.downgraded', ?, NOW())"
            )->execute([
                $event->userId,
                json_encode([
                    'old_level' => $event->oldLevel,
                    'new_level' => $event->newLevel,
                    'reason'    => $event->reason,
                ], JSON_UNESCAPED_UNICODE),
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleLevelDowngraded.recordAudit']);
            $this->logger->error('level.downgrade_audit_failed', ['user_id' => $event->userId, 'error' => $e->getMessage()]);
        }
    }

    private function removeBadge(int $userId, string $oldLevel): void
    {
        if (!isset(self::LEVEL_BADGE_SLUGS[$oldLevel])) {
            return;
        }
        try {
            $this->db->prepare("DELETE FROM user_badges WHERE user_id = ? AND badge_slug = ?")
                ->execute([$userId, self::LEVEL_BADGE_SLUGS[$oldLevel]]);
            $this->logger->info('level.badge_removed', ['user_id' => $userId, 'badge_slug' => self::LEVEL_BADGE_SLUGS[$oldLevel]]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleLevelDowngraded.removeBadge']);
            $this->logger->warning('level.badge_remove_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }
    }
}
