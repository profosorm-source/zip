<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\EscrowReleasedEvent;
use App\Contracts\WalletServiceInterface;
use App\Services\Shared\IdempotencyService;
use App\Services\Notification\NotificationService;
use App\Services\AuditTrail;
use App\Contracts\LoggerInterface;
use Core\Container;

/**
 * EscrowListener - Handles escrow release events
 * 
 * Decouples escrow management from:
 * - Wallet operations
 * - User notifications
 * - Audit logging
 * - Ledger updates
 */
class EscrowListener
{
    private Container $container;
    private LoggerInterface $logger;
    private IdempotencyService $idempotencyService;

    public function __construct(Container $container, LoggerInterface $logger, IdempotencyService $idempotencyService)
    {
        $this->container = $container;
        $this->logger = $logger;
        $this->idempotencyService = $idempotencyService;
    }

    /**
     * Handle escrow.released event
     * 
     * Credits wallet
     * Updates ledger
     * Sends notification
     */
    public function handle(EscrowReleasedEvent $event): void
    {
        try {
            $data = $event->getData();

            // FIX: Listener may run from HTTP request OR CLI/Job context.
            // app()->request is only valid in HTTP context.
            $correlationId = null;
            if (PHP_SAPI !== 'cli' && function_exists('app')) {
                try { $correlationId = app()->request?->header('x-request-id'); } catch (\Throwable $e) {}
            }
            $correlationId = $correlationId ?? ($data['correlation_id'] ?? 'cli-' . bin2hex(random_bytes(4)));

            $escrowId = $data['escrow_id'] ?? null;
            $recipientId = $data['recipient_id'] ?? null;
            $amount = $data['amount'] ?? 0;
            $currency = $data['currency'] ?? 'irt';

            if (!$escrowId || !$recipientId) {
                $this->logger->warning('escrow.released event missing required data', $data);
                return;
            }

            // Credit wallet (prefer async Outbox)
            $walletService = $this->container->make(WalletServiceInterface::class);
            $outbox = null;
            try {
                $outbox = $this->container->make(\App\Services\OutboxService::class);
            } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
                // no outbox available
            }

            $idemKey = 'escrow_rel:' . $escrowId;

            $payload = [
                'user_id' => (int)$recipientId,
                'amount' => (string)$amount,
                'currency' => $currency,
                'metadata' => [
                    'type' => 'escrow_release',
                    'escrow_id' => $escrowId,
                    'idempotency_key' => $idemKey,
                    'correlation_id' => $correlationId,
                ],
            ];

            if ($outbox) {
                $ok = $outbox->record('escrow', $escrowId, 'wallet.deposit.requested', $payload);
                if (!$ok) {
                    $this->logger->error('escrow.outbox_record_failed', ['escrow_id' => $escrowId]);
                    return;
                }
                $result = ['transaction_id' => null];
            } else {
                $depositResult = $this->idempotencyService->executeWithTransaction(
                    'wallet.deposit',
                    (int)$recipientId,
                    $payload,
                    function () use ($walletService, $recipientId, $amount, $currency, $correlationId) {
                        return $walletService->deposit($recipientId, $amount, $currency, ['correlation_id' => $correlationId]);
                    },
                    $idemKey
                );

                if (empty($depositResult['success'])) {
                    $this->logger->error('Failed to deposit escrow release to wallet', [
                        'escrow_id' => $escrowId,
                        'recipient_id' => $recipientId,
                        'amount' => $amount,
                        'result' => $depositResult,
                    ]);
                    return;
                }

                $result = $depositResult;
            }

            // Log to audit trail
            $auditTrail = $this->container->make(AuditTrail::class);
            $auditTrail->log([
                'user_id' => $recipientId,
                'action' => 'escrow.released',
                'resource_id' => $escrowId,
                'metadata' => [
                    'amount' => $amount,
                    'currency' => $currency,
                    'wallet_transaction_id' => $result['transaction_id'] ?? null,
                    'correlation_id' => $correlationId,
                ]
            ]);

            // Send notification
            $notificationService = $this->container->make(NotificationService::class);
            $notificationService->send(
                $recipientId,
                'escrow.released',
                'وجه کسری آزاد شد',
                "مبلغ $amount $currency از escrow #$escrowId به حساب شما منتقل شد.",
                [
                    'escrow_id' => $escrowId,
                    'amount' => $amount,
                    'transaction_id' => $result['transaction_id'] ?? null,
                    'correlation_id' => $correlationId,
                ]
            );

        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->logger->error('escrow.released listener failed', [
                'error' => $e->getMessage(),
                'event' => $event->getData()
            ]);
        }
    }
}
