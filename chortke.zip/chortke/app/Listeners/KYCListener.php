<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Services\AuditTrail;
use App\Contracts\LoggerInterface;
use Core\Container;
use Core\Database;

/**
 * KYCListener - Handles KYC approval events
 *
 * Decouples KYC verification from:
 * - Audit logging (دسته‌بندی رویداد تایید هویت در audit trail)
 *
 * FIX-EVENT-WIRING-2 (بازطراحی کامل):
 * این listener قبلاً هرگز به EventDispatcher وصل نشده بود. در بازبینی برای
 * اتصال، مشخص شد بدنه‌ی قدیمی آن با وضعیت فعلی پروژه ناسازگار است و اتصالِ
 * همان نسخه‌ی قدیمی سه باگ جدید ایجاد می‌کرد:
 *
 * ۱) UPDATE users SET kyc_level = 1 → سرویس KYCCommandService خودش سطح را با
 *    GREATEST(COALESCE(kyc_level,0),1) به‌روز می‌کند؛ نوشتن مجدد سطحِ ۱ توسط
 *    listener می‌توانست کاربرِ سطح ۲/۳ را به سطح ۱ تنزل دهد (downgrade).
 *    این نوشتن حذف شد.
 *
 * ۲) unlockFeatures() روی جدول user_features می‌نوشت؛ این جدول در هیچ
 *    migration ای تعریف نشده و هیچ کدی هم آن را نمی‌خواند (قابلیت مرده).
 *    حذف شد.
 *
 * ۳) updateWithdrawalLimits() ستون‌های daily/monthly_withdrawal_limit را روی
 *    جدول user_settings به‌روز می‌کرد؛ ساختار واقعی این جدول key-value است
 *    (user_id, setting_key, setting_value) و کوئری همیشه خطای unknown column
 *    می‌داد. حذف شد.
 *
 * ۴) اعلان «تایید هویت» توسط خود سرویس از طریق
 *    NotificationService::kycVerified() ارسال می‌شود؛ ارسال دوباره در listener
 *    باعث اعلان تکراری می‌شد. حذف شد.
 *
 * آنچه باقی مانده و واقعاً ارزشمند است: ثبت رویداد تایید هویت در audit trail
 * (که در هیچ جای مسیر سرویس انجام نمی‌شود) به‌همراه سطح واقعی کاربر خوانده‌شده
 * از جدول users (نه مقدار پیش‌فرض payload).
 *
 * ⚠️ الگوی رسمی (A4): وابستگی‌های سنگین عمداً به‌صورت lazy از Container گرفته
 * می‌شوند (سازنده فقط Container/Logger) تا از چرخه‌ی رویدادی
 * (Event → Service → dispatch → Listener) جلوگیری شود.
 * مرجع: docs/architecture_and_standards.md §۶
 */
class KYCListener
{
    private Container $container;
    private LoggerInterface $logger;

    public function __construct(Container $container, LoggerInterface $logger) {
        $this->container = $container;
        $this->logger = $logger;
    }

    /**
     * Handle kyc.approved event
     *
     * KYCApprovedEvent از سرویس KYCCommandService از طریق outbox با payload
     * {user_id, kyc_id} ارسال می‌شود (GenericEvent). امضای قبلی تایپ‌دار
     * TypeError می‌داد؛ اکنون \Core\Event است و داده از getData() خوانده می‌شود.
     */
    public function handle(\Core\Event $event): void
    {
        try {
            $rawData = $event->getData();
            $data = is_array($rawData) ? $rawData : [];
            $userId = isset($data['user_id']) ? int_value($data['user_id']) : null;
            $kycId = isset($data['kyc_id']) ? int_value($data['kyc_id']) : null;

            if (!$userId) {
                $this->logger->warning('kyc.approved event missing user_id', $data);
                return;
            }

            // سطح واقعی کاربر را از دیتابیس می‌خوانیم (سرویس مبدأ پیش از ارسال
            // رویداد، users.kyc_level را به‌روز کرده است) — نه مقدار پیش‌فرض.
            $db = $this->container->make(Database::class);
            $kycLevel = 1;
            try {
                $stmt = $db->prepare('SELECT kyc_level FROM users WHERE id = ? LIMIT 1');
                $stmt->execute([$userId]);
                $level = $stmt->fetchColumn();
                if ($level !== false && is_numeric($level)) {
                    $kycLevel = (int)$level;
                }
            } catch (\Throwable $e) {
                // خواندن سطح اختیاری است؛ audit با سطح پیش‌فرض ادامه می‌یابد.
                $this->logger->warning('kyc.approved level lookup failed', [
                    'user_id' => $userId,
                    'error' => $e->getMessage(),
                ]);
            }

            // Log to audit trail — تنها اثر جانبی‌ای که در هیچ نقطه‌ی دیگرِ
            // جریان تایید هویت ثبت نمی‌شود.
            $auditTrail = $this->container->make(AuditTrail::class);
            $auditTrail->logEvent([
                'user_id' => $userId,
                'action' => 'kyc.approved',
                'resource_id' => $kycId,
                'metadata' => [
                    'kyc_id' => $kycId,
                    'kyc_level' => $kycLevel,
                ]
            ]);

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.KYCListener.handle']);
            $this->logger->error('kyc.approved listener failed', [
                'error' => $e->getMessage(),
                'event' => $event->getData()
            ]);
        }
    }
}
