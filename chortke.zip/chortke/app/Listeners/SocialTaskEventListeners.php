<?php

declare(strict_types=1);

namespace App\Listeners;

use Core\Event;
use Core\Database;
use App\Contracts\LoggerInterface;
use App\Contracts\WalletServiceInterface;
use App\Services\Shared\IdempotencyService;
use App\Services\Gamification\TrustService;
use App\Enums\ModuleContext;
use App\Services\User\UserService;
use App\Contracts\OutboxServiceInterface;
use App\Models\SocialTaskExecutionModel;

/**
 * SocialTask Event Listeners
 */
class SocialTaskEventListeners
{
    protected LoggerInterface $logger;
    protected WalletServiceInterface $walletService;
    protected TrustService $trustService;
    protected UserService $userService;
    protected IdempotencyService $idempotencyService;
    protected ?OutboxServiceInterface $outbox;

    public function __construct(
        LoggerInterface $logger,
        WalletServiceInterface $walletService,
        TrustService $trustService,
        UserService $userService,
        IdempotencyService $idempotencyService,
        ?OutboxServiceInterface $outbox = null
    ) {
        $this->logger = $logger;
        $this->walletService = $walletService;
        $this->trustService = $trustService;
        $this->userService = $userService;
        $this->idempotencyService = $idempotencyService;
        $this->outbox = $outbox;
    }

    /**
     * وقتی تسک تایید نهایی می‌شود و نیاز به پرداخت دارد
     *
     * FIX-R36-W3 (F-A19e-02): تلهٔ re-pay بسته شد. این شنوندهٔ پرداخت‌پرداز روی
     * 'social_task.reward_approved' ثبت بود ولی این رویداد هیچ تولیدکننده‌ای ندارد
     * (emit قدیمی مسیر override در S27D-F1 حذف شد؛ ApproveSocialTaskExecutionJob:316).
     * اگر روزی دوباره emit می‌شد، همین متد پاداش را «از جیب پلتفرم بدون burn اسکرو/
     * کارمزد» می‌پرداخت — دقیقاً باگ اصلی S27D-F1. مسیر پرداختِ واحدِ زنده:
     * ApproveSocialTaskExecutionJob (escrow-burn با همان کلید socialTaskReward).
     * اکنون fail-closed: هیچ پرداختی از این در انجام نمی‌شود؛ ثبت شنونده هم از
     * AppServiceProvider برداشته شد. حذف کامل متد = پیشنهاد cleanup-wave.
     * @deprecated Dead money-path (r36 audit F-A19e-02) — fail-closed.
     */
    public function handleRewardApproved(Event $event): void
    {
        $data = [];
        try {
            $data = $event->getData();
        } catch (\Throwable) {
            // payload non-standard — فقط برای لاگ
        }
        $executionId = int_value($data['execution_id'] ?? 0);
        $this->logger->warning('social_task.reward_approved.dead_event_blocked', [
            'reason' => 'F-A19e-02: reward_approved producer ندارد؛ پرداخت فقط از ApproveSocialTaskExecutionJob (escrow-burn)',
            'execution_id' => $executionId,
            'user_id' => int_value($data['user_id'] ?? $data['executor_id'] ?? 0),
            // کلید canonicalِ مسیر زنده (پین P0-19/P0-20 — S17) برای تشخیص:
            'canonical_key' => $executionId > 0
                ? \App\Services\Shared\IdempotencyKeys::socialTaskReward($executionId)
                : null,
        ]);
    }
    /**
     * وقتی تسک توسط ادورتازیر رد می‌شود، کاهش تراست رخ می‌دهد
     */
    public function handleTaskRejected(Event $event): void
    {
        try {
            $data = $event->getData();
            $executorId = int_value($data['executor_id'] ?? 0);

            if ($executorId <= 0) {
                return;
            }

            $executorObj = $this->userService->findById($executorId);
            if ($executorObj) {
                // S3-M7 FIX (S33-B3 audit): بدون dedup_id، کلید ایدمپوتنسی
                // trust:{uid}:{domain}:task_rejected با SETNX هفت‌روزه فقط
                // «اولین» جریمه را اعمال می‌کرد و رد شدن‌های بعدی بی‌اثر بودند
                // (خنثی‌سازی پاداش ضدتقلب). کلید per-execution (تکمیل FIX-S18-6):
                // replay همان اجرا dedup می‌ماند، رد شدن‌های متفاوت جریمهٔ واقعی
                // می‌گیرند.
                $dedupExecutionId = int_value($data['execution_id'] ?? 0);
                $payload = $dedupExecutionId > 0
                    ? ['dedup_id' => 'execution:' . $dedupExecutionId]
                    : [];
                $this->trustService->evaluate((object)['id' => int_value($executorObj->id ?? 0)], ModuleContext::SOCIAL_TASKS, 'task_rejected', $payload);
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.SocialTaskEventListeners.handleTaskRejected']);
            $this->logger->error('social_task.task_rejected.failed', [
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * وقتی تسک لغو (Cancel) می‌شود، ردیف Outbox برای بازگشت وجه ادورتایزر نوشته می‌شود
     *
     * FIX-R36-W3 (F-A19e-03): مسیر مالی مرده — هیچ‌جا ثبت یا فراخوانی نمی‌شود
     * (grep کل repo = فقط تعریف؛ ثبت شنونده‌ای ندارد). نگه‌داریِ بدنهٔ پول‌برِ
     * وصل‌نشده تلهٔ دبل-بازگشتِ وجه آینده است (مسیر رسمی بازگشت وجه: refundOrder
     * در InfluencerCommandService / AdsBudgetSettlementService). حذف یا اتصال به
     * تولیدکنندهٔ واقعیِ لغو آگهی = پیشنهاد رجیستر (product decision).
     * @deprecated Dead money-path (r36 audit F-A19e-03) — unregisterable.
     */
    public function handleAdCancelledRefund(Event $event): void
    {
        try {
            $data = $event->getData();
            $adId = int_value($data['ad_id'] ?? 0);
            $userId = int_value($data['user_id'] ?? 0);
            $refund = str_value($data['refund'] ?? 0);
            $currency = str_value($data['currency'] ?? 'irt');

            if ($adId <= 0 || $userId <= 0 || !is_numeric($refund) || bccomp($refund, '0', 8) <= 0) {
                return;
            }

            $idempotencyKey = "social_ad_cancel_refund_{$adId}";
            $payload = [
                'user_id' => $userId,
                'amount' => $refund,
                'currency' => $currency,
                'metadata' => [
                    'type' => 'social_ad_refund',
                    'description' => "Refund for cancelled social ad #{$adId}",
                    'idempotency_key' => $idempotencyKey,
                    'gateway' => 'social_ad_refund',
                    'gateway_transaction_id' => 'refund_' . $adId,
                    'ref_id' => $adId,
                    'ref_type' => 'social_ad',
                ],
            ];

            if ($this->outbox) {
                $ok = $this->outbox->record('social_ad', $adId, 'wallet.deposit.requested', $payload);
                if (!$ok) {
                    throw new \RuntimeException('خطا در ثبت رکورد خروجی برای بازگشت وجه');
                }
            } else {
                $walletResult = $this->idempotencyService->executeWithTransaction(
                    'wallet.deposit',
                    $userId,
                    $payload,
                    function () use ($userId, $refund, $currency, $payload) {
                        return $this->walletService->deposit($userId, $refund, $currency, $payload['metadata']);
                    },
                    $payload['metadata']['idempotency_key']
                );
                if (empty($walletResult['success'])) {
                    throw new \RuntimeException(str_value($walletResult['message'] ?? 'خطا در بازگشت وجه'));
                }
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.SocialTaskEventListeners.handleAdCancelledRefund']);
            $this->logger->error('social_task.ad_cancelled_refund.failed', [
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }
}
