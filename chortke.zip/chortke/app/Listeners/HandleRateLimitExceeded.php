<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\RateLimitExceededEvent;
use App\Contracts\NotificationServiceInterface;
use App\Contracts\LoggerInterface;
use Core\Cache;
use Core\Database;

/**
 * HandleRateLimitExceeded
 *
 * پس از تجاوز از محدودیت نرخ:
 * ۱. Alert فوری به ادمین‌ها
 * ۲. Flag کردن کاربر / IP برای بررسی بیشتر
 * ۳. ثبت در جدول suspect_flags برای داشبورد امنیت
 */
class HandleRateLimitExceeded
{
    // حداقل فاصله زمانی بین alert‌ها برای یک key (ثانیه)، برای جلوگیری از alert storm
    private const ALERT_COOLDOWN_SECONDS = 300;

    // تعداد دفعاتی که یک IP در ۱ ساعت نرخ را رد کند تا Flag شود
    private const FLAG_THRESHOLD = 5;
    private const FLAG_WINDOW_SECONDS = 3600;

    private NotificationServiceInterface $notificationService;
    private LoggerInterface $logger;
    private Cache $cache;
    private Database $db;
    public function __construct(
        NotificationServiceInterface $notificationService,
        LoggerInterface $logger,
        Cache $cache,
        Database $db
    ) {        $this->notificationService = $notificationService;
        $this->logger = $logger;
        $this->cache = $cache;
        $this->db = $db;
}

    public function handle(\Core\Event $event): void
    {
        // FIX-EVENT-WIRING-2: RateLimiter رویداد را به شکل آرایه‌ی ساده
        // ['key' => ..., 'ip' => ...] ارسال می‌کند (GenericEvent)؛ امضای قبلی
        // تایپ‌دار (RateLimitExceededEvent $event) همیشه TypeError می‌داد و این
        // listener هرگز عملاً اجرا نمی‌شد. داده اکنون از getData() با پوشش
        // هر دو شکل کلید (ip/ipAddress) خوانده می‌شود و نبود strategy نیز
        // مجاز است (RateLimiter آن را در payload نمی‌فرستد).
        $rawData = $event->getData();
        $data = is_array($rawData) ? $rawData : [];

        $key       = str_value($data['key'] ?? 'unknown');
        $strategy  = str_value($data['strategy'] ?? 'n/a');
        $ip        = str_value($data['ip'] ?? ($data['ipAddress'] ?? 'unknown'));

        // ۱. Alert به ادمین (با cooldown برای جلوگیری از spam)
        $this->alertAdminIfNotCoolingDown($key, $strategy, $ip);

        // ۲. افزایش شمارنده IP و Flag در صورت عبور از آستانه
        $this->incrementAndMaybeFlagIp($ip, $key);
    }

    private function alertAdminIfNotCoolingDown(string $key, string $strategy, string $ip): void
    {
        $cooldownKey = 'rate_limit_alert_cooldown:' . md5($key);

        try {
            // FIX-M2M8 (گزارش ماژول ۲، M8): cooldown اتمیک SETNX — الگوی get/put
            // قبلی رقابتی بود و درخواست‌های هم‌زمان چند اعلان می‌ساختند؛
            // اولین claim برنده است و بقیه بدون ارسال برمی‌گردند.
            $claimed = $this->cache->add($cooldownKey, true, self::ALERT_COOLDOWN_SECONDS);
            if (!$claimed) {
                return; // در cooldown هستیم یا claim نشد — بدون اعلان
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleRateLimitExceeded.alertAdminIfNotCoolingDown']);
            // FIX-M2M8: در outage کش، اعلان inline نمی‌فرستیم — هم مسیر deny
            // از provider کند گیر نمی‌کند و هم رگبار اعلان‌های هم‌زمان نمی‌سازد؛
            // رویداد در Sentry ثبت شد و worker-outbox/لاگ قابل پیگیری است.
            $this->logger->warning('rate_limit.admin_alert_skipped_cache_outage', [
                'key' => $key,
                'ip'  => $ip,
            ]);
            return;
        }

        try {
            $this->notificationService->sendToAdmins(
                'rate_limit_exceeded',
                '⚠️ هشدار امنیتی: Rate Limit',
                "محدودیت نرخ برای کلید «{$key}» نقض شد.\nIP: {$ip}\nاستراتژی: {$strategy}",
                [
                    'key'      => $key,
                    'ip'       => $ip,
                    'strategy' => $strategy,
                ],
                'high'
            );
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleRateLimitExceeded.alertAdminIfNotCoolingDown']);
            $this->logger->error('rate_limit.admin_alert_failed', [
                'key'   => $key,
                'ip'    => $ip,
                'error' => $e->getMessage(),
            ]);
        }
    }

    private function incrementAndMaybeFlagIp(string $ip, string $key): void
    {
        $counterKey = 'rate_exceeded_count:' . md5($ip);

        try {
            // FIX-C8 (یافتهٔ ۵۸): increment طبق CacheInterface مقدار int|false برمی‌گرداند؛
            // cast قبلی (int) شکست مخزن را به ۰ تبدیل می‌کرد و فلگ آستانه
            // ($count === FLAG_THRESHOLD) هرگز تریپ نمی‌شد (fail-open در سوءاستفاده).
            // اکنون شکست مخزن → بدون فلگ (fail-closed برای نوشتن DB) با لاگ شفاف.
            $count = $this->cache->increment($counterKey, 1, self::FLAG_WINDOW_SECONDS);
            if (!is_int($count)) {
                $this->logger->warning('rate_limit.counter_unavailable', [
                    'key' => $counterKey,
                ]);
                return;
            }

            // 🛡️ FIX-S18-4 (Medium — S18-AUDIT): فلگ فقط در «مرزِ دقیقِ» آستانه
            // نوشته می‌شود ($count === FLAG_THRESHOLD) نه در هر تخطّیِ پس از آن.
            // قبلاً از شمارش ۵ به بعد، هر تخطّی یک INSERT می‌ساخت و جدول
            // suspect_flags کلید UNIQUE ندارد (FIX-X187) ⇒ سرریزِ عمدیِ rate-limit
            // از یک IP = INSERT بی‌کران (DoSِ نوشتن در DB). شمارنده per-IP با TTL
            // = FLAG_WINDOW_SECONDS منقضی می‌شود ⇒ حداکثر یک فلگ per IP per window؛
            // هدف فلگ (علمِ ادمین برای بررسی دستی) با همین یک ردیف برآورده است.
            if ($count !== self::FLAG_THRESHOLD) {
                return;
            }

            // Flag IP در دیتابیس برای بررسی دستی توسط ادمین
            // FIX-X187 (راند ۴۷): INSERT قبلی ستون‌های type/identifier/count/flagged_at را
            // می‌نوشت که در اسکیمای واقعی suspect_flags وجود ندارند (ستون‌ها: user_id
            // NOT NULL، flag_type، reason، created_at) و کلید UNIQUE برای
            // ON DUPLICATE KEY UPDATE هم هیچ‌وقت وجود نداشت → هر فلگ‌برداری
            // «rate_limit.flag_failed: Unknown column 'type'» می‌شد و ردیابی
            // متخلفانِ نرخ‌سنجی هرگز ذخیره نمی‌شد. اکنون INSERT با اسکیمای واقعی
            // هم‌راستاست (user_id=0 = سنتینل «فلگ IP، بدون کاربر»؛ شمارش داخل reason).
            $this->db->prepare(
                "INSERT INTO suspect_flags (user_id, flag_type, reason)
                 VALUES (0, 'ip', ?)"
            )->execute([
                "Rate limit exceeded {$count}x on key: {$key} — IP: {$ip}",
            ]);

            $this->logger->warning('rate_limit.ip_flagged', [
                'ip'    => $ip,
                'key'   => $key,
                'count' => $count,
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleRateLimitExceeded.incrementAndMaybeFlagIp']);
            $this->logger->error('rate_limit.flag_failed', [
                'ip'    => $ip,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
