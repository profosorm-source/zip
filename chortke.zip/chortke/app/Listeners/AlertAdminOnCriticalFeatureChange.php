<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\CriticalFeatureChangedEvent;
use App\Contracts\NotificationServiceInterface;
use App\Contracts\LoggerInterface;

/**
 * AlertAdminOnCriticalFeatureChange
 *
 * هنگامی که یک Feature Flag حیاتی تغییر می‌کند:
 * ۱. Alert فوری به همه ادمین‌ها با اطلاعات کامل تغییر
 * ۲. لاگ در کانال critical برای monitoring
 *
 * این Listener جداگانه از LogFeatureFlagChange است تا SRP رعایت شود.
 */
class AlertAdminOnCriticalFeatureChange
{
    private NotificationServiceInterface $notificationService;
    private LoggerInterface $logger;
    public function __construct(
        NotificationServiceInterface $notificationService,
        LoggerInterface $logger
    ) {        $this->notificationService = $notificationService;
        $this->logger = $logger;
}

    public function handle(CriticalFeatureChangedEvent $event): void
    {
        $featureName = $this->safeText($event->featureName, 120);
        $action      = $this->safeText($event->action, 60);
        $changedBy   = $event->changedBy ?? 0;
        $changedAt   = $event->changedAt
            ? $event->changedAt->format('Y-m-d H:i:s')
            : date('Y-m-d H:i:s');

        // 🛡️ FIX-S23-C5: changes خام (JSON pretty) دیگر مستقیم داخل متن اعلان ادمین
        // تزریق نمی‌شود — پاک‌سازی تگ + فشرده‌سازی فاصله + سقف طول (نگاه safeText).
        // اگر روزی مقدار فلگ شامل دادهٔ مشتق از کاربر شود، مسیر stored-content
        // ادمین‌به‌ادمین بسته است. دادهٔ ساختاریافته در آرایهٔ metadata دست‌نخورده می‌ماند.
        $changesJson = !empty($event->changes)
            ? $this->safeText(json_encode($event->changes, JSON_UNESCAPED_UNICODE), 1000)
            : '—';

        $title   = "⚠️ تغییر Feature Flag بحرانی: {$featureName}";
        $message = "فیچر «{$featureName}» با عملیات «{$action}» توسط کاربر #{$changedBy} در {$changedAt} تغییر کرد.\n\nجزئیات:\n{$changesJson}";

        try {
            $this->notificationService->sendToAdmins(
                'critical_feature_changed',
                $title,
                $message,
                [
                    'feature_name' => $featureName,
                    'action'       => $action,
                    'changed_by'   => $changedBy,
                    'changed_at'   => $changedAt,
                    'changes'      => $event->changes,
                ],
                'high'
            );
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.AlertAdminOnCriticalFeatureChange.handle']);
            $this->logger->error('critical_feature.admin_alert_failed', [
                'feature' => $featureName,
                'error'   => $e->getMessage(),
            ]);
        }

        $this->logger->critical('critical_feature.changed_alert_sent', [
            'feature'    => $featureName,
            'action'     => $action,
            'changed_by' => $changedBy,
            'changed_at' => $changedAt,
        ]);
    }

    /**
     * 🛡️ FIX-S23-C5 — پاک‌سازی متن‌های درج‌شده در پیام اعلان ادمین.
     *
     * - ورودی غیراسکالر (آرایه/شیء) به JSON امن تبدیل می‌شود؛
     * - تگ‌های HTML حذف می‌شوند (مانع stored markup ادمین‌به‌ادمین)؛
     * - فاصله‌های تکراری فشرده می‌شوند تا متن خوانا بماند؛
     * - طول با سقف $maxLen محدود می‌شود (مانع پیام‌های غول‌پیکر در کانال‌های ادمین).
     */
    private function safeText(mixed $value, int $maxLen = 1000): string
    {
        $text = is_scalar($value) ? (string)$value : (string)json_encode($value, JSON_UNESCAPED_UNICODE);
        $text = strip_tags(trim($text));
        $text = (string)(preg_replace('/\s+/u', ' ', $text) ?? '');
        if ($maxLen > 0 && mb_strlen($text) > $maxLen) {
            return mb_substr($text, 0, $maxLen) . '…';
        }
        return $text;
    }
}
