<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\ScoreUpdatedEvent;
use App\Services\Notification\NotificationService;
use App\Services\AuditTrail;
use App\Services\User\UserLevelService;
use App\Contracts\LoggerInterface;
use Core\Container;

/**
 * ScoreUpdateListener - Handles score change events
 * 
 * Decouples score updates from:
 * - Level upgrade checks
 * - Threshold alerts
 * - User notifications
 * - Audit logging
 */
/**
 * ⚠️ الگوی رسمی (A4): وابستگی‌های سنگین عمداً به‌صورت lazy از Container گرفته
 * می‌شوند (سازنده فقط Container/Logger) تا از چرخه‌ی رویدادی
 * (Event → Service → dispatch → Listener) جلوگیری شود.
 * مرجع: docs/architecture_and_standards.md §۶
 */

class ScoreUpdateListener
{
    private Container $container;
    private LoggerInterface $logger;

    public function __construct(Container $container, LoggerInterface $logger) {
        $this->container = $container;
        $this->logger = $logger;
    }

    /**
     * Handle score.updated event
     * 
     * Checks for level upgrades
     * Sends threshold alerts
     * Logs changes
     */
    public function handle(\Core\Event $event): void
    {
        // FIX-EVENT-WIRING-2: ScoreUpdatedEvent با FQCN در outbox ثبت می‌شود
        // (ScoreProjectionListener) و به‌صورت GenericEvent با payload آرایه‌ای
        // منتشر می‌شود؛ امضای تایپ‌دار قبلی TypeError می‌داد. کلید payload این
        // رویداد entity_id/source است (نام user_id/reason نیز برای سازگاری با
        // dispatch مستقیم پوشش داده شده است).
        try {
            $rawData = $event->getData();
            $data = is_array($rawData) ? $rawData : [];
            $userId = isset($data['user_id']) ? int_value($data['user_id']) : (isset($data['entity_id']) ? int_value($data['entity_id']) : null);
            $oldScore = float_value($data['old_score'] ?? 0);
            $newScore = float_value($data['new_score'] ?? 0);
            $reason = str_value($data['reason'] ?? ($data['source'] ?? ''));

            if (!$userId) {
                $this->logger->warning('score.updated event missing user_id', $data);
                return;
            }

            // Log to audit trail
            $auditTrail = $this->container->make(AuditTrail::class);
            $auditTrail->logEvent([
                'user_id' => $userId,
                'action' => 'score.updated',
                'metadata' => [
                    'old_score' => $oldScore,
                    'new_score' => $newScore,
                    'change' => $newScore - $oldScore,
                    'reason' => $reason
                ]
            ]);

            // Check for level upgrade
            $this->checkLevelUpgrade($userId, $oldScore, $newScore);

            // Check for threshold alerts (only on threshold crossing + cooldown)
            $this->checkThresholdAlerts($userId, $oldScore, $newScore);

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ScoreUpdateListener.handle']);
            $this->logger->error('score.updated listener failed', [
                'error' => $e->getMessage(),
                'event' => $event->getData()
            ]);
        }
    }

    /**
     * Check if user qualifies for level upgrade
     */
    private function checkLevelUpgrade(int $userId, float $oldScore, float $newScore): void
    {
        try {
            $levelService = $this->container->make(UserLevelService::class);
            $levelService->checkUpgrade($userId);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ScoreUpdateListener.checkLevelUpgrade']);
            $this->logger->warning('Level upgrade check failed', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Cooldown window (seconds) per user per alert type to stop repeat alerts
     * when a score oscillates around the threshold or when many queued delta
     * events are replayed in one batch (outbox drain).
     *
     * FIX (Task 7): بازه cooldown اکنون از پنل ادمین (تنظیمات → امنیت →
     * score_threshold_alert_cooldown_seconds) قابل تغییر است؛ مقدار هاردکد
     * فقط fallback رکورد حذف‌شده/ناموجود است.
     */
    private const THRESHOLD_ALERT_COOLDOWN_SECONDS = 86400; // 24h
    private const THRESHOLD_ALERT_COOLDOWN_MIN_SECONDS = 60;       // حداقل ۱ دقیقه
    private const THRESHOLD_ALERT_COOLDOWN_MAX_SECONDS = 2592000;  // حداکثر ۳۰ روز

    /**
     * Send alerts for score thresholds (e.g., high risk score).
     *
     * Two guards against notification spam (Task 6):
     * 1. Edge detection — alert only when the score CROSSES the threshold
     *    (old was outside the alert zone, new is inside). Repeated events that
     *    stay inside the same zone (e.g., every score delta of a low-trust
     *    user) no longer resend the same alert.
     * 2. Per-user per-type cooldown — oscillation around the threshold is
     *    rate-limited to one alert per 24h.
     */
    private function checkThresholdAlerts(int $userId, float $oldScore, float $newScore): void
    {
        try {
            // High risk score threshold (crossing upward into the risk zone)
            if ($newScore >= 80 && $oldScore < 80) {
                if ($this->shouldSendThresholdAlert($userId, 'high_risk')) {
                    $notificationService = $this->container->make(NotificationService::class);
                    $notificationService->send(
                        $userId,
                        'score.high_risk_alert',
                        '⚠️ هشدار ریسک بالا',
                        'نمره ریسک شما بالا است. فعالیت‌های مریب را دوباره بررسی کنید.',
                        ['score' => $newScore]
                    );
                }
            }

            // Low trust score threshold (crossing downward into the low-trust zone)
            if ($newScore <= 30 && $oldScore > 30) {
                if ($this->shouldSendThresholdAlert($userId, 'low_trust')) {
                    $notificationService = $this->container->make(NotificationService::class);
                    $notificationService->send(
                        $userId,
                        'score.low_trust_alert',
                        'نمره اعتماد پایین',
                        'نمره اعتماد شما کاهش یافته است. فعالیت‌های مثبت را انجام دهید.',
                        ['score' => $newScore]
                    );
                }
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ScoreUpdateListener.checkThresholdAlerts']);
            $this->logger->warning('Threshold alert failed', [
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Per-user per-type cooldown check for threshold alerts.
     * Returns true once per cooldown window; marks the window on success.
     */
    private function shouldSendThresholdAlert(int $userId, string $alertType): bool
    {
        try {
            $cache = $this->container->make(\Core\Cache::class);
            $key = "score:threshold_alert:{$alertType}:{$userId}";
            if ($cache->has($key)) {
                return false;
            }
            $cache->putSeconds($key, 1, $this->getThresholdAlertCooldownSeconds());
            return true;
        } catch (\Throwable $e) {
            // Cache unavailable: fail open (send the alert) — better one
            // duplicate than silently losing a risk warning.
            $this->logger->warning('threshold alert cooldown check failed', [
                'user_id' => $userId,
                'alert_type' => $alertType,
                'error' => $e->getMessage(),
            ]);
            return true;
        }
    }

    /**
     * FIX (Task 7): خواندن بازه cooldown از تنظیمات پنل ادمین
     * (system_settings → security → score_threshold_alert_cooldown_seconds)
     * با clamp ایمن بین ۱ دقیقه تا ۳۰ روز؛ رکورد ناموجود/غیرعددی = پیش‌فرض ۲۴ ساعت.
     */
    private function getThresholdAlertCooldownSeconds(): int
    {
        $cooldown = null;
        try {
            $cooldown = setting('score_threshold_alert_cooldown_seconds', null);
        } catch (\Throwable $e) {
            // settings service unavailable — fall through to the default
        }

        if (!is_numeric($cooldown)) {
            return self::THRESHOLD_ALERT_COOLDOWN_SECONDS;
        }

        return max(
            self::THRESHOLD_ALERT_COOLDOWN_MIN_SECONDS,
            min(self::THRESHOLD_ALERT_COOLDOWN_MAX_SECONDS, (int)$cooldown)
        );
    }
}
