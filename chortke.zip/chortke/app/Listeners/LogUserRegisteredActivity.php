<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\UserRegisteredEvent;
use App\Services\EmailService;
use App\Services\User\UserService;
use App\Contracts\LoggerInterface;

class LogUserRegisteredActivity
{
    private LoggerInterface $logger;
    private UserService $userService;
    private ?EmailService $emailService;
    public function __construct(
        LoggerInterface $logger,
        UserService $userService,
        ?EmailService $emailService = null
    ) {        $this->logger = $logger;
        $this->userService = $userService;
        $this->emailService = $emailService;
}

    public function handle(UserRegisteredEvent $event): void
    {
        try {
            // 1. Log structured registration activity
            $this->logger->activity('auth.register', 'ثبت‌نام کاربر', $event->userId);

            // 2. Resolve verified token and dispatch Verification Mail outside the HTTP pipeline
            $user = $this->userService->find($event->userId);
            if ($this->emailService && $user) {
                // 🛡️ FIX-S18-5 (Medium — S18-AUDIT): فقط plainTokenِ رویداد ایمیل
                // می‌شود. fallback قبلی به $user->email_verification_token «هشِ
                // HMAC ذخیره‌شده» را ایمیل می‌کرد ⇒ hash(hmac) در verifyEmail هرگز
                // با رکورد مچ نمی‌شد (لینک مرده) + افشای مقدار ستون DB. اگر
                // plainToken نبود (تولیدکنندهٔ غیراستاندارد)، ایمیل skip و
                // هشدار ثبت می‌شود — مسیر resend همیشه در دسترس کاربر است.
                $token = $event->plainToken;
                if (!empty($token)) {
                    $this->emailService->sendVerificationEmail($event->userId, $token);
                } else {
                    // FIX-S10 (fail-visible pin): کانال هشدار پین‌شده 'no_plain_token' است
                    // تا پایش/آلرت روی همین قرارداد سیم بماند.
                    $this->logger->warning('listener.user_registered.no_plain_token', [
                        'user_id' => $event->userId,
                        'reason'  => 'plainToken missing on UserRegisteredEvent — use resend flow',
                    ]);
                }
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.LogUserRegisteredActivity.handle']);
            $this->logger->error('listener.user_registered.failed', [
                'user_id' => $event->userId,
                'error' => $e->getMessage()
            ]);
        }
    }
}
