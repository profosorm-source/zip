<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\UserLoggedInEvent;
use App\Services\AuditTrail;
use App\Contracts\LoggerInterface;

class LogUserLoggedInActivity
{
    private LoggerInterface $logger;
    private AuditTrail $auditTrail;
    public function __construct(
        LoggerInterface $logger,
        AuditTrail $auditTrail
    ) {        $this->logger = $logger;
        $this->auditTrail = $auditTrail;
}

    public function handle(\Core\Event $event): void
    {
        // FIX-EVENT-WIRING-2: AuthService رویداد auth.login را از طریق outbox با
        // payload آرایه‌ای {user_id, ip, user_agent} ثبت می‌کند و OutboxPublisher
        // آن را به GenericEvent تبدیل می‌کند؛ امضای تایپ‌دار قبلی
        // (UserLoggedInEvent $event) همیشه TypeError می‌داد.
        try {
            $rawData = $event->getData();
            $data = is_array($rawData) ? $rawData : [];
            $userId = int_value($data['user_id'] ?? 0);
            $ip = str_value($data['ip'] ?? ($data['ipAddress'] ?? ''));
            $userAgent = str_value($data['user_agent'] ?? ($data['userAgent'] ?? ''));

            if ($userId <= 0) {
                return;
            }

            // Record PSR-3 dynamic structured logs via buffer (fast)
            $this->logger->activity('auth.login', 'ورود موفق کاربر', $userId);

            // Record persistent audit trails to database securely
            $this->auditTrail->record('auth.login', $userId, [
                'ip' => $ip,
                'user_agent' => $userAgent
            ]);

            // 🛡️ FIX-X144 (B2 — راند 37): شمارندهٔ روزهای فعال — پیش از این
            // UserLevelCommandService::recordDailyActivity هیچ فراخوانی نداشت و
            // active_days_count هر ۲۲ کاربر صفر مانده بود. اکنون در هر ورود ثبت می‌شود
            // (خودِ متد idempotent است — همان روز دوباره شمرده نمی‌شود).
            try {
                app(\App\Services\User\UserLevelService::class)->recordDailyActivity($userId);
            } catch (\Throwable $dailyActivityError) {
                $this->logger->warning('listener.user_logged_in.daily_activity_failed', [
                    'user_id' => $userId,
                    'error' => $dailyActivityError->getMessage()
                ]);
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.LogUserLoggedInActivity.handle']);
            $this->logger->error('listener.user_logged_in.failed', [
                'error' => $e->getMessage()
            ]);
        }
    }
}
