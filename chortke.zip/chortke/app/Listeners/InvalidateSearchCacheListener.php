<?php

declare(strict_types=1);

namespace App\Listeners;

use Core\Container;
use App\Services\Cache\CacheInvalidationService;
use App\Contracts\LoggerInterface;

/**
 * InvalidateSearchCacheListener
 * 
 * شنونده رویدادهای اصلی سیستم جهت باطل‌سازی خودکار و پویای کش جستجوی ماژول‌ها.
 *
 * 🛡️ FIX-S20-ISCL (اتصال dead-file به روش کارفرما):
 * ۱) این لیسنر از تولد یتیم بود (هرگز در AppServiceProvider ثبت نمی‌شد)؛ اکنون
 *    فقط روی رویدادهایی ثبت می‌شود که تولیدکنندهٔ واقعی دارند.
 * ۲) نقشهٔ نگاشت از ۲۴ ورودی به ۵ ورودیِ تولیدشده نازک شد — ۲۰ نامِ بقیه
 *    (ad.*، seo_ad.*، coupon.created، investment.* و…) هیچ dispatch ای در
 *    کل کدبیس ندارند و فقط نویز/رفتار فال‌بک اشتباه می‌ساختند.
 * ۳) dispatcher شنونده را با GenericEvent (بدون نامِ رویداد) صدا می‌زند؛
 *    بنابراین نام دقیق رویداد به‌صورت اختیاری به handle() تزریق می‌شود
 *    (همان الگوی bootstrap/app.php برای SearchProjectionListener).
 */
class InvalidateSearchCacheListener
{
    private CacheInvalidationService $cacheInvalidationService;
    private LoggerInterface $logger;
    public function __construct(
        CacheInvalidationService $cacheInvalidationService,
        LoggerInterface $logger
    ) {        $this->cacheInvalidationService = $cacheInvalidationService;
        $this->logger = $logger;

    }

    public function handle(mixed $event, ?string $eventName = null): void
    {
        if ($eventName === null || $eventName === '') {
            if (is_object($event)) {
                if (method_exists($event, 'getName')) {
                    $eventName = (string)$event->getName();
                } else {
                    $eventName = get_class($event);
                }
            } elseif (is_string($event)) {
                $eventName = $event;
            } else {
                $eventName = '';
            }
        }
        
        $data = [];
        if (is_object($event) && method_exists($event, 'getData')) {
            $data = (array)$event->getData();
        }

        $this->logger->info('search.cache.invalidation.event_received', [
            'event' => $eventName,
            'data' => $data
        ]);

        // نقشه نگاشت نام رویدادها به ماژول‌های جستجو — فقط رویدادهایی که
        // تولیدکنندهٔ واقعی دارند (FIX-S20-ISCL؛ بقیهٔ ۲۰ نام حذف شدند).
        // ماژول‌ها با کلیدهای registry در AdminSearchGateway هم‌نام‌اند
        // (prediction/lottery با TTL یک‌ساعته — پنجرهٔ کهنگی اصلی).
        $mapping = [
            'prediction.created' => 'prediction',
            'prediction.updated' => 'prediction',
            'lottery.created' => 'lottery',
            'ticket.created' => 'ticket',
            \App\Events\TaskCompletedEvent::class => 'custom_task',
        ];

        // استخراج ماژول از داده‌های رویداد یا از روی جدول نگاشت بالا
        $module = $data['module'] ?? $data['type'] ?? $data['task_type'] ?? null;
        if ($module === null || $module === '') {
            $module = $mapping[$eventName] ?? null;
        }

        if ($module !== null && $module !== '') {
            $this->cacheInvalidationService->invalidateModuleSearch((string)$module);
            $this->cacheInvalidationService->invalidateSearch(); // همیشه کل سرچ را برای اطمینان باطل کن
            $this->logger->info('search.cache.invalidation.completed', [
                'event' => $eventName,
                'module' => $module
            ]);
        } else {
            // در غیر این صورت کل کش مربوط به جستجوها را باطل می‌کنیم
            $this->cacheInvalidationService->invalidateSearch();
            $this->logger->info('search.cache.invalidation.fallback_completed', [
                'event' => $eventName
            ]);
        }
    }
}
