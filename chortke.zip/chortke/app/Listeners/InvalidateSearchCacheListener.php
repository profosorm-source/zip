<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\TaskCompletedEvent;
use App\Services\Cache\CacheInvalidationService;
use Core\Event;

/**
 * 🛡️ FIX-R22-B7 — شنوندهٔ باطل‌سازی کش جست‌وجو (تکمیل FIX-S20-ISCL/DEADFILE)
 *
 * زمینهٔ تاریخی: FIX-S20 تولیدکننده‌های رویدادهای search-bust را داشت ولی کلاس
 * شنونده هرگز ساخته و وصل نشد («مستند‌شده ولی اجرا‌نشده» — همان الگوی R21-B).
 * این کلاس قرارداد تست قفل‌کنندهٔ tests/Integration/Listeners/DeadFileWiringRuntimeTest
 * را پیاده می‌کند:
 *   - روی رویدادهای ماژولار، تگ‌های ماژول + search:{module} باطل می‌شود؛
 *   - در همهٔ حالت‌ها تگ کلی 'search' فلش می‌شود (رفتار تعمدی — flush کل جست‌وجو).
 *
 * نکتهٔ نام رویداد: dispatcher پیلودهای غیر-Event را در GenericEvent بی‌نام می‌پیچد؛
 * بنابراین نام دقیق رویداد مثل الگوی bootstrap ($projectionSyncEvents) توسط closure
 * ثبت‌کننده به صریح به handle() تزریق می‌شود.
 */
final class InvalidateSearchCacheListener
{
    public function __construct(
        private readonly CacheInvalidationService $cacheInvalidation,
    ) {
    }

    /** @param object|array<string, mixed> $payload */
    public function handle(string $eventName, object|array $payload = []): void
    {
        $module = match ($eventName) {
            'prediction.created', 'prediction.updated' => 'prediction',
            'lottery.created'                          => 'lottery',
            'ticket.created'                           => 'ticket',
            // تسک تکمیل‌شده فضای نام ماژول جست‌وجوی اختصاصی ندارد — فقط فلش کلی.
            TaskCompletedEvent::class                  => null,
            default                                    => null,
        };

        if ($module !== null) {
            $this->cacheInvalidation->invalidateModuleSearch($module);
        }

        $this->cacheInvalidation->invalidateSearch();
    }
}
