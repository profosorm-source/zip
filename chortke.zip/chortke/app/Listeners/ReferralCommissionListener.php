<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Contracts\LoggerInterface;
use App\Contracts\OutboxServiceInterface;
use App\Services\Shared\ReferralService;
use Core\Container;

/**
 * ReferralCommissionListener
 * 
 * Handles referral commission processing for various reward events
 * (tasks, sales, vip purchases, etc.)
 */
class ReferralCommissionListener
{
    private ReferralService $referralService;
    private LoggerInterface $logger;
    // FIX-R19-A7-1: nullable outbox — compensation publisher for lost commissions.
    private ?OutboxServiceInterface $outbox;
    /** Bounded compensation budget (FIX-S18-2 precedent: no self-replicating retry rows). */
    private const MAX_COMPENSATION_RETRIES = 3;

    public function __construct(
        ReferralService $referralService,
        LoggerInterface $logger,
        ?OutboxServiceInterface $outbox = null
    ) {
        $this->referralService = $referralService;
        $this->logger = $logger;
        $this->outbox = $outbox;
    }

    /**
     * Handle referral commission event
     * 
     * Expected payload format:
     * - referrer_id: int (ID of the referrer to credit)
     * - amount: float|string (Commission amount)
     * - currency: string (Currency code: 'usdt', 'content_approval', etc.)
     * - context: array (Additional data like action, executor_id, etc.)
     * - source_user_id: int (The user whose action triggered the commission)
     */
    public function handle(mixed $event): void
    {
        $payload = [];
        try {
            // FIX: Listener may run from HTTP request OR CLI/Job context.
            $correlationId = null;
            if (PHP_SAPI !== 'cli' && function_exists('app')) {
                try { $correlationId = app()->request->header('x-request-id'); } catch (\Throwable $e) {
                    \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ReferralCommissionListener.handle']);
            $this->logger->warning('referralcommissionlistener.operation_failed', ['error' => $e->getMessage()]);
        }
            }
            $payload = $this->extractPayload($event);
            $correlationId = $correlationId ?? ($payload['correlation_id'] ?? 'cli-' . bin2hex(random_bytes(4)));
            
            if (empty($payload['referrer_id'])) {
                $this->logger->warning('referral.commission.missing_referrer', [
                    'payload' => $payload,
                    'correlation_id' => $correlationId
                ]);
                return;
            }

            // Add correlation to context for tracing
            $rawContext = $payload['context'] ?? [];
            /** @var array<string, mixed> $context */
            $context = is_array($rawContext) ? $rawContext : [];
            $context['correlation_id'] = $correlationId;

            $result = $this->referralService->processCommission(
                int_value($payload['referrer_id'] ?? 0),
                str_value($payload['amount'] ?? ''),
                str_value($payload['currency'] ?? ''),
                $context
            );

            if (!($result['success'] ?? false)) {
                $this->logger->warning('referral.commission.process_failed', [
                    'referrer_id' => $payload['referrer_id'],
                    'amount' => $payload['amount'],
                    'result' => $result,
                    'correlation_id' => $correlationId
                ]);
                // FIX-R19-A7-1: bounded outbox compensation — the commission must not be
                // silently lost on a transient failure (same shape the listener consumes,
                // original correlation_id preserved; processCommission's internal
                // idempotency keys make the replay safe).
                $this->scheduleCompensation(
                    $payload,
                    is_string($correlationId) ? $correlationId : null,
                    (int)($context['retry_count'] ?? 0),
                    'process_commission_failed'
                );
            } else {
                $this->logger->info('referral.commission.processed', [
                    'referrer_id' => $payload['referrer_id'],
                    'amount' => $payload['amount'],
                    'currency' => $payload['currency'],
                    'source_user_id' => $payload['source_user_id'] ?? null,
                    'correlation_id' => $correlationId
                ]);
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ReferralCommissionListener.handle']);
            $this->logger->error('referral.commission.exception', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'event' => $event,
                'correlation_id' => $correlationId ?? null
            ]);
            // FIX-R19-A7-1: bounded outbox compensation for the exception path too —
            // without it a transient DB error permanently loses this commission.
            $this->scheduleCompensation(
                is_array($payload) ? $payload : [],
                is_string($correlationId ?? null) ? $correlationId : null,
                (int)(is_array($payload) ? ($payload['context']['retry_count'] ?? 0) : 0),
                'exception'
            );
        }
    }

    /**
     * FIX-R19-A7-1: record a `referral.commission.process` replacement event in the
     * outbox (the AppServiceProvider wiring at :346 dispatches it back to this listener
     * via OutboxPublisher). Bounded at MAX_COMPENSATION_RETRIES with the retry counter
     * carried inside payload['context'] — after exhaustion only Sentry + log remain
     * (no self-replicating rows, FIX-S18-2 lesson). Fail-safe: never throws.
     *
     * @param array<string, mixed> $payload
     */
    private function scheduleCompensation(array $payload, ?string $correlationId, int $retryCount, string $reason): void
    {
        if (empty($payload['referrer_id'])) {
            return; // nothing to compensate (invalid/unknown payload)
        }

        if ($retryCount >= self::MAX_COMPENSATION_RETRIES) {
            \App\Services\Sentry\SentryExceptionHandler::captureMessage(
                'referral.commission.compensation_terminal',
                'error',
                null,
                ['referrer_id' => $payload['referrer_id'] ?? null, 'correlation_id' => $correlationId, 'reason' => $reason]
            );
            $this->logger->error('referral.commission.compensation_exhausted', [
                'referrer_id' => $payload['referrer_id'],
                'retry_count' => $retryCount,
                'correlation_id' => $correlationId,
                'reason' => $reason,
            ]);
            return;
        }

        if ($this->outbox === null) {
            $this->logger->error('referral.commission.compensation_unavailable', [
                'referrer_id' => $payload['referrer_id'],
                'correlation_id' => $correlationId,
                'reason' => $reason,
            ]);
            return;
        }

        $context = is_array($payload['context'] ?? null) ? $payload['context'] : [];
        $context['retry_count'] = $retryCount + 1;
        if ($correlationId !== null && empty($context['correlation_id'])) {
            $context['correlation_id'] = $correlationId;
        }
        $payload['context'] = $context;

        try {
            $this->outbox->record(
                'referral',
                (string)int_value($payload['referrer_id']),
                'referral.commission.process',
                $payload
            );
            $this->logger->info('referral.commission.compensation_scheduled', [
                'referrer_id' => $payload['referrer_id'],
                'retry_count' => $retryCount + 1,
                'correlation_id' => $correlationId,
                'reason' => $reason,
            ]);
        } catch (\Throwable $e) {
            $this->logger->error('referral.commission.compensation_record_failed', [
                'referrer_id' => $payload['referrer_id'] ?? null,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Extract payload from various event formats
     *
     * @return array<string, mixed>
     */
    private function extractPayload(mixed $event): array
    {
        if (is_array($event)) {
            return $event;
        }

        if ($event instanceof \Core\Event) {
            return $event->getData();
        }

        if (is_object($event) && method_exists($event, 'getData')) {
            return $event->getData();
        }

        return [];
    }
}
