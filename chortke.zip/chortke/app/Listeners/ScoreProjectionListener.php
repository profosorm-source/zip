<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\ScoreDeltaAppendedEvent;
use App\Events\ScoreUpdatedEvent;
use Core\Database;
use Core\Cache;
use App\Services\Cache\CacheInvalidationService;

/**
 * ScoreProjectionListener
 * 
 * Asynchronously projects score deltas to the user_scores read model 
 * and handles cache invalidation.
 */
class ScoreProjectionListener
{
    private Database $db;
    private Cache $cache;
    private CacheInvalidationService $cacheInvalidation;
    private \App\Contracts\LoggerInterface $logger;
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;
    public function __construct(
        Database $db,
        Cache $cache,
        CacheInvalidationService $cacheInvalidation,
        \App\Contracts\LoggerInterface $logger,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {
        $this->db = $db;
        $this->cache = $cache;
        $this->cacheInvalidation = $cacheInvalidation;
        $this->logger = $logger;
        $this->outbox = $outbox;
    }

    public function handle(\App\Events\ScoreDeltaAppendedEvent|\Core\Event $event): void
    {
        // FIX-EVENT-WIRING-2: این listener قبلاً روی نام رشته‌ای 'score.delta_appended'
        // ثبت شده بود، در حالی که ScoreCommandService رویداد را با recordEvent()
        // (FQCN: App\Events\ScoreDeltaAppendedEvent) در outbox ثبت می‌کند و
        // OutboxPublisher آن را به‌صورت GenericEvent با payload آرایه‌ای ارسال
        // می‌کند. امضا و خوانش داده برای هر دو شکل (شیء تایپ‌دار و GenericEvent)
        // سازگار شد؛ کلیدهای payload از toPayload() می‌آیند.
        if ($event instanceof \App\Events\ScoreDeltaAppendedEvent) {
            $entityType = $event->entityType;
            $entityId   = $event->entityId;
            $domain     = $event->domain;
            $delta      = $event->delta;
            $source     = $event->source;
        } else {
            $rawData = $event->getData();
            $data = is_array($rawData) ? $rawData : [];
            $entityType = str_value($data['entity_type'] ?? '');
            $entityId   = int_value($data['entity_id'] ?? 0);
            $domain     = str_value($data['domain'] ?? '');
            $delta      = float_value($data['delta'] ?? 0);
            $source     = str_value($data['source'] ?? '');
        }

        if ($entityType === '' || $entityId <= 0 || $domain === '') {
            try { $this->logger->warning('score.delta_appended invalid payload', []); } catch (\Throwable $e) {}
            return;
        }
        // 1. Update Read Model (user_scores table)
        if ($entityType === 'user') {
            $stmt = $this->db->prepare("
                INSERT INTO user_scores (user_id, domain, score, updated_at) 
                VALUES (?, ?, ?, NOW()) 
                ON DUPLICATE KEY UPDATE 
                score = score + VALUES(score), updated_at = NOW()
            ");
            $stmt->execute([$entityId, $domain, $delta]);

            // Fetch new total score to dispatch standard ScoreUpdatedEvent for gamification triggers
            try {
                $stmt = $this->db->prepare("SELECT score FROM user_scores WHERE user_id = ? AND domain = ? LIMIT 1");
                $stmt->execute([$entityId, $domain]);
                $val = $stmt->fetchColumn();
                $newScore = $val !== false ? (float)$val : null;
                $oldScore = $newScore !== null ? $newScore - $delta : 0.0;
                
                if ($newScore !== null) {
                    $this->outbox?->record('score', $entityId, ScoreUpdatedEvent::class, [
                        'entity_id' => $entityId,
                        'old_score' => (float)$oldScore,
                        'new_score' => (float)$newScore,
                        'source' => $source,
                    ]);
                }
            } catch (\Throwable $e) {
                \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ScoreProjectionListener.handle']);
            $this->logger->warning('scoreprojectionlistener.operation_failed', ['error' => $e->getMessage()]);
        }
        }

        // 2. Invalidate Caches
        $this->invalidateScoreCache($entityType, $entityId, $domain);
    }

    private function invalidateScoreCache(string $entityType, int $entityId, string $domain): void
    {
        // 🛡️ M-1 Fix: Redis از Hash key استفاده می‌کند (score:user:123) نه String key (score:user:123:task)
        // پس باید HDEL روی فیلد خاص هش بزنیم، نه DEL روی کلید اشتباه
        try {
            $redis = $this->cache->redis();
            if ($redis) {
                $cacheKey = "score:{$entityType}:{$entityId}";
                // حذف فقط فیلد این domain از هش → بقیه فیلدها دست‌نخورده می‌مانند
                $redis->hDel($cacheKey, $domain);
                // ریست TTL
                $redis->expire($cacheKey, 3600);
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ScoreProjectionListener.invalidateScoreCache']);
            $this->logger->warning('scoreprojectionlistener.operation_failed', ['error' => $e->getMessage()]);
        }

        $this->cacheInvalidation->invalidateScore($entityId, $domain);
    }
}
