<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\ScoreDeltaAppendedEvent;
use App\Events\ScoreUpdatedEvent;
use Core\Database;
use Core\Cache;
use App\Services\Cache\CacheInvalidationService;

/**
 * ScoreProjectionListener
 * 
 * Asynchronously projects score deltas to the user_scores read model 
 * and handles cache invalidation.
 */
class ScoreProjectionListener
{
    private Database $db;
    private Cache $cache;
    private CacheInvalidationService $cacheInvalidation;
    private \App\Contracts\LoggerInterface $logger;
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;
    public function __construct(
        Database $db,
        Cache $cache,
        CacheInvalidationService $cacheInvalidation,
        \App\Contracts\LoggerInterface $logger,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {
        $this->db = $db;
        $this->cache = $cache;
        $this->cacheInvalidation = $cacheInvalidation;
        $this->logger = $logger;
        $this->outbox = $outbox;
    }

    public function handle(\App\Events\ScoreDeltaAppendedEvent|\Core\Event $event): void
    {
        // FIX-EVENT-WIRING-2: این listener قبلاً روی نام رشته‌ای 'score.delta_appended'
        // ثبت شده بود، در حالی که ScoreCommandService رویداد را با recordEvent()
        // (FQCN: App\Events\ScoreDeltaAppendedEvent) در outbox ثبت می‌کند و
        // OutboxPublisher آن را به‌صورت GenericEvent با payload آرایه‌ای ارسال
        // می‌کند. امضا و خوانش داده برای هر دو شکل (شیء تایپ‌دار و GenericEvent)
        // سازگار شد؛ کلیدهای payload از toPayload() می‌آیند.
        if ($event instanceof \App\Events\ScoreDeltaAppendedEvent) {
            $entityType = $event->entityType;
            $entityId   = $event->entityId;
            $domain     = $event->domain;
            $delta      = $event->delta;
            $source     = $event->source;
            $scoreEventId = (int)($event->scoreEventId ?? 0); // 🛡️ X380
        } else {
            $rawData = $event->getData();
            $data = is_array($rawData) ? $rawData : [];
            $entityType = str_value($data['entity_type'] ?? '');
            $entityId   = int_value($data['entity_id'] ?? 0);
            $domain     = str_value($data['domain'] ?? '');
            $delta      = float_value($data['delta'] ?? 0);
            $source     = str_value($data['source'] ?? '');
            $scoreEventId = int_value($data['score_event_id'] ?? 0); // 🛡️ X380
        }

        if ($entityType === '' || $entityId <= 0 || $domain === '') {
            try { $this->logger->warning('score.delta_appended invalid payload', []); } catch (\Throwable $e) {}
            return;
        }
        // 🛡️ X380 (راند ۹۹) — ناوردای «پروجکشن هرگز از لجر جلو نمی‌زند»:
        // رخداد میدانی 2026-09-12: ردیف لجر جراحی شد (پراب fraudSignalSweep) ولی
        // رخداد outboxِ همان دلتا پس از rebuild توسط worker پردازش شد و پروجکشن
        // را دوباره +۱۰ کرد (user_scores و users.fraud_score هر دو از لجر جلو
        // زدند). وقتی رویداد idِ ردیف لجر را حمل می‌کند، موجودیِ ردیف وارسی
        // می‌شود؛ ردیفِ حذف‌شده = skip (پروجکشن با rebuild هم‌راستا می‌ماند).
        // رویدادهای میراثیِ بدون id (scoreEventId=0) مثل قبل اعمال می‌شوند (fail-open).
        if ($scoreEventId > 0) {
            $rowExists = (int)$this->db->fetchColumn('SELECT COUNT(*) FROM score_events WHERE id = ?', [$scoreEventId]);
            if ($rowExists === 0) {
                try {
                    $this->logger->info('score.projection_skipped_ledger_row_missing', [
                        'score_event_id' => $scoreEventId,
                        'entity_id' => $entityId,
                        'domain' => $domain,
                        'delta' => $delta,
                    ]);
                } catch (\Throwable $e) {}
                $this->invalidateScoreCache($entityType, $entityId, $domain);
                return;
            }
        }
        // 1. Update Read Model (user_scores table)
        if ($entityType === 'user') {
            // 🛡️ FIX-X17 (بحرانی-پروداکشن): دامنهٔ fraud طبق قرارداد 0..100 است
            // (FraudDetectionService::calculateFraudScore سقف 100 دارد) ولی پروجکشن
            // دلتاها را بدون سقف جمع می‌کرد → در QA به fraud=1035 رسید و کاربر
            // برای همیشه در fraud_block_threshold گیر کرد (قفل دائمی بدون decay).
            // FIX-X70 (بحرانی): عبارت «VALUES(score)» داخل لیست VALUES خودِ INSERT
// در MariaDB مجاز نیست (SQLSTATE 42000/1064) → همهٔ رویدادهای
// ScoreDeltaAppendedEvent دامنهٔ fraud به DLQ می‌رفتند و پروجکشن
// user_scores هرگز ساخته نمی‌شد. سقف 100 اکنون در PHP محاسبه و
// مقدار نهایی bind می‌شود؛ فقط clause مربوط به ON DUPLICATE KEY
// UPDATE (که در MariaDB مجاز است) از VALUES() استفاده می‌کند.
//
// 🛡️ FIX-X356 (راند ۹۱): کف/سقفِ پروجکشن اکنون «آگاه از دامنه» است و از
// تک‌منبعِ ScoreDomainPolicy می‌آید (همان نقشه‌ای که ScoresRebuildCommand
// برای replay لجر استفاده می‌کند تا هرگز واگرا نشوند):
//   - fraud/task و دامنه‌های ناشناخته: [0, 100] — قبلاً کف نداشت و پروجکشن
//     منفی ممکن بود (باگ اصلی X356)
//   - xp_*: کف ۰ بدون سقف ۱۰۰ (موتور لول از لجر می‌خواند، نه پروجکشن)
//   - social_trust / trust_*: ‎[-100, 100]‎ — منفیِ اعتماد مجاز است
// هر دو شاخهٔ INSERT (ردیف تازه) و UPDATE (ردیف موجود) مهار می‌شوند؛
// GREATEST/LEAST داخل خود SQL است تا اتمیتی عبارت upsert حفظ شود.
[$floor, $cap] = \App\Services\Score\ScoreDomainPolicy::bounds($domain);
// FIX-X356-ب (راند ۹۱ — کشف توسط پراب round91-scores): clamp را نباید روی
// «افزایشِ» شاخهٔ UPDATE اعمال کرد. مقدار سومِ INSERT (برای ردیف تازه) باید
// مهارشده باشد، ولی در عبارت ON DUPLICATE KEY UPDATE، «VALUES(score)» همان
// مقدارِ clamp-شده را برمی‌گرداند؛ یعنی دلتای منفیِ خارج‌از-کرانه (مثل ‎-15‎ در
// fraud) به ۰ می‌چسبید و به‌جای کم‌کردن، پروجکشن را دست‌نخورده می‌گذاشت
// (واپاشی لجر-محور هم هرگز روی پروجکشن نمی‌نشست). دلتای خام جداگانه bind
// می‌شود و مهار فقط روی «حاصل‌جمع» انجام می‌گیرد.
$stmt = $this->db->prepare("
                    INSERT INTO user_scores (user_id, domain, score, updated_at)
                    VALUES (?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE
                    score = GREATEST(?, LEAST(?, score + ?)), updated_at = NOW()
                ");
$stmt->execute([
    $entityId, $domain, \App\Services\Score\ScoreDomainPolicy::clamp($domain, (float) $delta),
    $floor, $cap, (float) $delta,
]);

            // Fetch new total score to dispatch standard ScoreUpdatedEvent for gamification triggers
            try {
                $stmt = $this->db->prepare("SELECT score FROM user_scores WHERE user_id = ? AND domain = ? LIMIT 1");
                $stmt->execute([$entityId, $domain]);
                $val = $stmt->fetchColumn();
                $newScore = $val !== false ? (float)$val : null;
                $oldScore = $newScore !== null ? $newScore - $delta : 0.0;
                
                if ($newScore !== null) {
                    // 🛡️ X364 (راند ۹۲): پروجکشن سوم users.fraud_score — برای دامنهٔ
                    // fraud، همان مقداری که از user_scores بازخوانی شد (بدون کوئری
                    // اضافهٔ خواندن) به‌صورت int روی users.fraud_score هم می‌نشیند تا
                    // ستون قدیمی با لجر/پروجکشن هم‌راستا بماند (drift پیشین:
                    // user_scores تا ~۹۰ ولی users.fraud_score ۰..۵). Rebuild هم
                    // همین قرارداد را در applyPlan تکرار می‌کند. شکستِ این UPDATE
                    // (مثلاً ردیف users حذف‌شده) فقط لاگ می‌شود و مسیر اصلی
                    // پروجکشن user_scores را خراب نمی‌کند (همان try بالادست).
                    if ($domain === 'fraud') {
                        $stmtUsers = $this->db->prepare(
                            "UPDATE users SET fraud_score = ?, updated_at = NOW() WHERE id = ?"
                        );
                        $stmtUsers->execute([(int)round($newScore), $entityId]);
                    }

                    $this->outbox?->record('score', $entityId, ScoreUpdatedEvent::class, [
                        'entity_id' => $entityId,
                        'old_score' => (float)$oldScore,
                        'new_score' => (float)$newScore,
                        'source' => $source,
                    ]);
                }
            } catch (\Throwable $e) {
                \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ScoreProjectionListener.handle']);
            $this->logger->warning('scoreprojectionlistener.operation_failed', ['error' => $e->getMessage()]);
        }
        }

        // 2. Invalidate Caches
        $this->invalidateScoreCache($entityType, $entityId, $domain);
    }

    private function invalidateScoreCache(string $entityType, int $entityId, string $domain): void
    {
        // 🛡️ M-1 Fix: Redis از Hash key استفاده می‌کند (score:user:123) نه String key (score:user:123:task)
        // پس باید HDEL روی فیلد خاص هش بزنیم، نه DEL روی کلید اشتباه
        try {
            $redis = $this->cache->redis();
            if ($redis) {
                $cacheKey = "score:{$entityType}:{$entityId}";
                // حذف فقط فیلد این domain از هش → بقیه فیلدها دست‌نخورده می‌مانند
                $redis->hDel($cacheKey, $domain);
                // ریست TTL
                $redis->expire($cacheKey, 3600);
            }
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.ScoreProjectionListener.invalidateScoreCache']);
            $this->logger->warning('scoreprojectionlistener.operation_failed', ['error' => $e->getMessage()]);
        }

        $this->cacheInvalidation->invalidateScore($entityId, $domain);
    }
}
