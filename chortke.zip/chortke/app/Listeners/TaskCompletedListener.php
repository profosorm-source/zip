<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\TaskCompletedEvent;
use App\Services\Gamification\XpService;
use App\Services\Notification\NotificationService;
use App\Services\ScoreService;
use App\Services\AuditTrail;
use App\Contracts\LoggerInterface;
use App\Enums\ModuleContext;
use App\Services\OutboxService;
use Core\Container;
use Core\Event;

/**
 * TaskCompletedListener - Handles custom task completion events
 * 
 * Decouples task service from:
 * - XP award system
 * - Trust score updates
 * - User notifications
 * - Audit logging
 */
/**
 * ⚠️ الگوی رسمی (A4): وابستگی‌های سنگین عمداً به‌صورت lazy از Container گرفته
 * می‌شوند (سازنده فقط Container/Logger) تا از چرخه‌ی رویدادی
 * (Event → Service → dispatch → Listener) جلوگیری شود.
 * مرجع: docs/architecture_and_standards.md §۶
 */

class TaskCompletedListener
{
    private Container $container;
    private LoggerInterface $logger;

    public function __construct(Container $container, LoggerInterface $logger) {
        $this->container = $container;
        $this->logger = $logger;
    }

    /**
     * Handle task.completed event
     *
     * Awards XP points (admin-configurable via settings panel)
     * Updates trust score
     * Sends notification
     * Logs to audit trail
     *
     * FIX-EVENT-WIRING-2: این listener قبلاً هرگز به EventDispatcher وصل نشده بود —
     * رویداد TaskCompletedEvent هم از مسیر مستقیم (AdminCustomTaskService) و هم از
     * outbox (CustomTaskModerationService) با FQCN ارسال می‌شد ولی بی‌شنونده می‌ماند؛
     * یعنی پس از تایید تسک سفارشی، کاربر نه XP می‌گرفت، نه امتیاز اعتماد، نه اعلان
     * و نه ردیف audit. امضا از TaskCompletedEvent به \Core\Event تغییر کرد تا هم
     * رویداد تایپ‌دار (dispatch مستقیم) و هم GenericEvent ناشی از انتشار outbox
     * (آرایه‌ی payload) پذیرفته شود.
     *
     * نکته: فیلد xp رویداد در عمل «مبلغ پاداش» است نه مقدار XP؛ مقدار XP واقعی از
     * تنظیمات پنل مدیریت (setting('xp_custom_task')) خوانده می‌شود.
     */
    public function handle(Event $event): void
    {
        try {
            $rawData = $event->getData();
            $data = is_array($rawData) ? $rawData : [];
            $userId = int_value($data['user_id'] ?? 0);
            $taskId = int_value($data['task_id'] ?? 0);
            $title = str_value($data['title'] ?? 'تسک');
            // مقدار XP از تنظیمات مدیریت (قابل ویرایش در پنل → تنظیمات → امتیازها)؛
            // fallback عدد ۱۰ برای نصب‌های بدون رکورد تنظیمات.
            $xpReward = float_value(setting('xp_custom_task', 10) ?: 10);

            if (!$userId || !$taskId) {
                $this->logger->warning('task.completed event missing required data', $data);
                return;
            }

            // Award XP points
            $userIdInt = $userId;
            $xpService = $this->container->make(XpService::class);
            $xpService->award($userIdInt, ModuleContext::CUSTOM_TASKS, (float)$xpReward, "task_$taskId");

            // Update trust score
            $scoreService = $this->container->make(ScoreService::class);
            // 🛡️ FIX-R18-M16: idemKey per-task (الگوی WithdrawalListener:128) — تحویل تکراری
            // رویداد task.completed نباید trust را چندبار +3 کند.
            $scoreService->applyDelta('user', $userIdInt, 'social_trust', 3, 'task_completed', [], 'task_completed_' . $taskId);

            // Log to audit trail
            $auditTrail = $this->container->make(AuditTrail::class);
            $auditTrail->logEvent([
                'user_id' => $userId,
                'action' => 'task.completed',
                'resource_id' => $taskId,
                'metadata' => [
                    'title' => $title,
                    'xp_awarded' => $xpReward
                ]
            ]);

            // Send notification asynchronously via OutboxService
            $outboxService = $this->container->make(OutboxService::class);
            $outboxService->record(
                'notification',
                $userId . '_task_completed',
                'send_notification',
                [
                    'notification' => [
                        'method' => 'send',
                        'args' => [
                            $userId,
                            'task.completed',
                            'تسک تکمیل شد',
                            "تسک \"$title\" تکمیل شد. $xpReward XP کسب کردید!",
                            // 🛡️ FIX-R18-M11: event_id قطعی در data اعلان تا claim-dedupe
                            // دیسپچر (notif_sent:{channel}:{event_id}:{user}) فعال شود.
                            ['task_id' => $taskId, 'xp_reward' => $xpReward, 'event_id' => 'task_completed_' . $taskId]
                        ]
                    ]
                ]
            );

        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.TaskCompletedListener.handle']);
            $this->logger->error('task.completed listener failed', [
                'error' => $e->getMessage(),
                'event' => $event->getData()
            ]);
        }
    }
}
