<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\PaymentCompletedEvent;
use App\Services\Gamification\XpService;
use App\Enums\ModuleContext;
use App\Services\Shared\ReferralService;
use App\Contracts\NotificationServiceInterface;
use App\Contracts\LoggerInterface;
use Core\Database;
use Core\Event;

/**
 * HandlePaymentCompleted
 *
 * پس از تکمیل موفق پرداخت آنلاین (واریز از درگاه):
 * ۱. اعطای XP به کاربر متناسب با مبلغ پرداخت
 * ۲. پردازش کمیسیون معرف (Referral Commission)
 * ۳. ارسال notification تبریک واریز
 */
class HandlePaymentCompleted
{
    // نرخ اعطای XP: به ازای هر X تومان، ۱ امتیاز تجربی داده می‌شود
    // FIX-XP-SETTINGS: این مقادیر هاردکد نبودند قابل ویرایش نیستند؛ اکنون از
    // تنظیمات پنل مدیریت (دسته‌ی «امتیازها» — keys: xp_per_payment_unit,
    // xp_max_per_payment) خوانده می‌شوند و این ثابت‌ها فقط fallback نصب اولیه‌اند.
    private const XP_PER_UNIT = 10_000;
    private const MAX_XP_PER_PAYMENT = 500.0;

    private XpService $xpService;
    private ReferralService $referralService;
    private NotificationServiceInterface $notificationService;
    private LoggerInterface $logger;
    private Database $db;
    // FIX-R19-A7-1: nullable outbox — bounded compensation publisher for lost referral commissions.
    // Retry budget is enforced downstream by ReferralCommissionListener::scheduleCompensation.
    private ?\App\Contracts\OutboxServiceInterface $outbox;

    public function __construct(
        XpService $xpService,
        ReferralService $referralService,
        NotificationServiceInterface $notificationService,
        LoggerInterface $logger,
        Database $db,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {        $this->xpService = $xpService;
        $this->referralService = $referralService;
        $this->notificationService = $notificationService;
        $this->logger = $logger;
        $this->db = $db;
        $this->outbox = $outbox;
}

    public function handle(Event $event): void
    {
        // FIX-EVENT-WIRING-2: رویداد payment.completed فقط از طریق outbox با
        // payload آرایه‌ای ارسال می‌شود (PaymentCommandService / PaymentService)؛
        // OutboxPublisher آن را به GenericEvent تبدیل می‌کند، پس امضای قبلی
        // تایپ‌دار (PaymentCompletedEvent $event) همیشه TypeError می‌داد و
        // XP/کمیسیون رفرال/اعلان واریز هرگز اجرا نمی‌شد. داده اکنون از
        // getData() با پوشش هر دو شکل کلید (ref_id/transaction_id) خوانده می‌شود.
        $rawData = $event->getData();
        $data = is_array($rawData) ? $rawData : [];

        $userId = int_value($data['user_id'] ?? 0);
        $amount = float_value($data['amount'] ?? 0);
        $currency = str_value($data['currency'] ?? 'IRT');
        $transactionId = str_value($data['transaction_id'] ?? ($data['ref_id'] ?? ''));
        $gateway = str_value($data['gateway'] ?? '');

        if ($userId <= 0 || $amount <= 0.0) {
            // payload نامعتبر — ثبت لاگ و خروج بی‌صدا (رفتار fail-safe رویداد)
            try {
                $this->logger->warning('payment.completed.invalid_payload', $data);
            } catch (\Throwable $e) {
                // لاگر هم در دسترس نیست؛ هیچ کاری نمی‌توان کرد
            }
            return;
        }

        // 🛡️ FIX-S18-11 (Low — S18-AUDIT): event بدون هویتِ تراکنش = پردازشِ
        // غیر-idempotent. کلید XP «gateway_deposit_{tx}» و هویت کمیسیون
        // {action, executor_id, tx} هر دو با tx='' به یک مقدار ثابت فرو می‌ریزند:
        // اولین رویدادِ خالی XP/کمیسیون می‌گیرد و بقیهٔ پرداخت‌های همان کاربر
        // برای همیشه «duplicate» می‌شوند (زیانِ ساکت)، یا در replayِ
        // approveManualDepositِ تکراری با tx_id=NULL، XP دوباره اعطا می‌شد.
        // رویدادِ بی‌هویت = skip + هشدار (fail-safe) — producerهای فعلی همیشه
        // ref_id/transaction_id دارند؛ این گارد برای دادهٔ کهنه/دستی است.
        if ($transactionId === '') {
            try {
                $this->logger->warning('payment.completed.missing_transaction_identity', [
                    'user_id' => $userId,
                    'amount'  => $amount,
                    'gateway' => $gateway,
                    'reason'  => 'XP/commission/notification skipped — no idempotent identity',
                ]);
            } catch (\Throwable $e) {
                // لاگر در دسترس نیست؛ skip همان هدف را دارد
            }
            return;
        }

        // ۱. اعطای XP بر اساس مبلغ پرداختی
        $this->awardXp($userId, $amount, $transactionId);

        // ۲. پردازش کمیسیون ریفرال
        $this->processReferralCommission($userId, $amount, $currency, $transactionId);

        // ۳. ارسال اعلان تبریک
        $this->sendDepositNotification($userId, $amount, $currency, $gateway, $transactionId);
    }

    private function awardXp(int $userId, float $amount, string $transactionId): void
    {
        try {
            // FIX-XP-SETTINGS: نرخ و سقف XP از تنظیمات مدیریت (قابل ویرایش در
            // پنل → تنظیمات → امتیازها)؛ ثابت‌های کلاس فقط مقدار پیش‌فرض‌اند.
            $perUnit = float_value(setting('xp_per_payment_unit', (string)self::XP_PER_UNIT) ?: self::XP_PER_UNIT);
            $maxXp = float_value(setting('xp_max_per_payment', (string)self::MAX_XP_PER_PAYMENT) ?: self::MAX_XP_PER_PAYMENT);
            if ($perUnit <= 0) {
                return; // نرخ نامعتبر — اعطای XP غیرفعال
            }

            $xp = min(
                (float) floor($amount / $perUnit),
                $maxXp
            );

            if ($xp <= 0.0) {
                return;
            }

            $this->xpService->award(
                $userId,
                ModuleContext::GLOBAL,
                $xp,
                "gateway_deposit_{$transactionId}"
            );

            $this->logger->info('payment.xp_awarded', [
                'user_id'        => $userId,
                'xp'             => $xp,
                'amount'         => $amount,
                'transaction_id' => $transactionId,
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandlePaymentCompleted.awardXp']);
            $this->logger->error('payment.xp_award_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
        }
    }

    private function processReferralCommission(
        int $userId,
        float $amount,
        string $currency,
        string $transactionId
    ): void {
        $referrerId = 0;
        try {
            $stmt = $this->db->prepare(
                "SELECT referred_by FROM users WHERE id = ? LIMIT 1"
            );
            $stmt->execute([$userId]);
            $referrerId = $stmt->fetchColumn();

            if (!$referrerId) {
                return;
            }

            $this->referralService->processCommission(
                (int) $referrerId,
                (string) $amount,
                strtolower((string)$currency),
                [
                    'action'         => 'deposit',
                    'executor_id'    => $userId,
                    'transaction_id' => $transactionId,
                ]
            );

            $this->logger->info('payment.referral_commission_processed', [
                'user_id'     => $userId,
                'referrer_id' => $referrerId,
                'amount'      => $amount,
                'currency'    => $currency,
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandlePaymentCompleted.processReferralCommission']);
            $this->logger->error('payment.referral_commission_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
            // FIX-R19-A7-1: bounded outbox compensation — record a
            // `referral.commission.process` replacement event (already wired to
            // ReferralCommissionListener in AppServiceProvider:346) so a transient
            // DB failure does not permanently lose this deposit's commission.
            // The context keys {action, executor_id, transaction_id} are the original
            // commission identity — ReferralService's internal idempotency makes the
            // replay safe; retry counter is carried in context (bounded, FIX-S18-2).
            if ($referrerId > 0 && $this->outbox !== null) {
                try {
                    $this->outbox->record('referral', (string)$referrerId, 'referral.commission.process', [
                        'referrer_id' => $referrerId,
                        'amount'      => (string)$amount,
                        'currency'    => strtolower((string)$currency),
                        'source_user_id' => $userId,
                        'context'     => [
                            'action'         => 'deposit',
                            'executor_id'    => $userId,
                            'transaction_id' => $transactionId,
                            'retry_count'    => 1,
                            'correlation_id' => 'payment-completed-' . $transactionId,
                        ],
                    ]);
                    $this->logger->info('payment.referral_commission_compensation_scheduled', [
                        'user_id' => $userId, 'referrer_id' => $referrerId, 'transaction_id' => $transactionId,
                    ]);
                } catch (\Throwable $outboxEx) {
                    $this->logger->error('payment.referral_commission_compensation_record_failed', [
                        'user_id' => $userId, 'error' => $outboxEx->getMessage(),
                    ]);
                }
            }
        }
    }

    private function sendDepositNotification(
        int $userId,
        float $amount,
        string $currency,
        string $gateway,
        string $transactionId
    ): void {
        try {
            $formattedAmount = number_format($amount, 0, '.', ',');
            $currencyLabel   = strtoupper((string)$currency) === 'IRT' ? 'تومان' : strtoupper((string)$currency);

            $this->notificationService->send(
                $userId,
                'deposit_success',
                'واریز موفق',
                "مبلغ {$formattedAmount} {$currencyLabel} با موفقیت به کیف پول شما اضافه شد.",
                [
                    'amount'         => $amount,
                    'currency'       => $currency,
                    'gateway'        => $gateway,
                    'transaction_id' => $transactionId,
                ],
                null,
                null,
                'high'
            );
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandlePaymentCompleted.sendDepositNotification']);
            $this->logger->error('payment.deposit_notification_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
        }
    }
}
