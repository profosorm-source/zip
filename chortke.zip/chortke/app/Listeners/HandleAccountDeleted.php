<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\AccountDeletedEvent;
use App\Contracts\WalletServiceInterface;
use App\Contracts\NotificationServiceInterface;
use App\Contracts\LoggerInterface;
use Core\Database;

/**
 * HandleAccountDeleted
 *
 * پس از حذف حساب کاربری:
 * ۱. بررسی و یادداشت موجودی کیف پول باقی‌مانده
 * ۲. بستن escrowهای باز (تبلیغات، تسک‌ها)
 * ۳. اطلاع‌رسانی به ادمین در صورت وجود موجودی معوقه
 * ۴. ثبت آدیت نهایی حذف حساب
 */
class HandleAccountDeleted
{
    // آستانه موجودی‌ای که alert به ادمین ارسال می‌شود (تومان)
    private const BALANCE_ALERT_THRESHOLD = 1000.0;

    private WalletServiceInterface $walletService;
    private NotificationServiceInterface $notificationService;
    private LoggerInterface $logger;
    private Database $db;
    public function __construct(
        WalletServiceInterface $walletService,
        NotificationServiceInterface $notificationService,
        LoggerInterface $logger,
        Database $db
    ) {        $this->walletService = $walletService;
        $this->notificationService = $notificationService;
        $this->logger = $logger;
        $this->db = $db;
}

    public function handle(AccountDeletedEvent $event): void
    {
        $userId = $event->userId;
        $email  = $event->email;
        $reason = $event->reason;

        // ۱. بررسی موجودی باقی‌مانده در کیف پول‌ها (best-effort — اطلاع‌رسانی است،
        //    نه cleanup؛ شکست اعلان نباید retry کل lifecycle را برای همیشه سرخ کند)
        $this->checkAndAlertRemainingBalance($userId, $email);

        // ۲. بستن escrowهای باز مرتبط با این کاربر — S7-FIX (EVT-001): fail-loud؛
        //    شکستِ cleanup دیگر swallow نمی‌شود (job مسیر outbox/queue می‌تواند retry کند)
        $this->resolveOpenEscrows($userId);

        // ۳. ثبت آدیت نهایی — S7-FIX (EVT-001): fail-loud + idempotent
        $this->recordFinalAudit($userId, $email, $reason);
    }

    private function checkAndAlertRemainingBalance(int $userId, string $email): void
    {
        try {
            $irtBalance  = (float) $this->walletService->getBalance($userId, 'irt');
            $usdtBalance = (float) $this->walletService->getBalance($userId, 'usdt');

            if ($irtBalance < self::BALANCE_ALERT_THRESHOLD && $usdtBalance < 1.0) {
                return;
            }

            $this->notificationService->sendToAdmins(
                'deleted_account_has_balance',
                '🚨 حساب حذف‌شده با موجودی',
                "کاربر #{$userId} ({$email}) حذف شد اما موجودی دارد.\n"
                . "موجودی IRT: " . number_format($irtBalance) . " تومان\n"
                . "موجودی USDT: {$usdtBalance}",
                [
                    'user_id'      => $userId,
                    'email'        => $email,
                    'irt_balance'  => $irtBalance,
                    'usdt_balance' => $usdtBalance,
                ],
                'high'
            );

            $this->logger->critical('account_deleted.balance_remaining', [
                'user_id'      => $userId,
                'email'        => $email,
                'irt_balance'  => $irtBalance,
                'usdt_balance' => $usdtBalance,
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleAccountDeleted.checkAndAlertRemainingBalance']);
            $this->logger->error('account_deleted.balance_check_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
        }
    }

    private function resolveOpenEscrows(int $userId): void
    {
        try {
            // Soft-close تبلیغات فعال کاربر (بودجه باقی‌مانده freeze می‌شود)
            // FIX-R36-W1: ساگای حذف حساب، bookkeeping بودجهٔ کمپین‌های باز را داخل
            // تراکنش با Ads::completeAdAndClearBudget انجام می‌دهد (وضعیت گذری
            // 'completed')؛ شنونده وضعیت نهایی چرخهٔ عمر را به 'cancelled' همگرا
            // می‌کند — قرارداد پین‌شدهٔ AccountDeletionEventWiringTest:175.
            $this->db->prepare(
                "UPDATE ads
                 SET status = 'cancelled', updated_at = NOW()
                 WHERE user_id = ? AND status IN ('active', 'pending', 'completed')"
            )->execute([$userId]);

            // Soft-close سفارش‌های باز سرمایه‌گذاری (escrow)
            $this->db->prepare(
                "UPDATE investments
                 SET status = 'cancelled', updated_at = NOW()
                 WHERE user_id = ? AND status = 'pending'"
            )->execute([$userId]);

            // لغو تسک‌های شروع‌شده اما تکمیل‌نشده
            $this->db->prepare(
                "UPDATE custom_task_submissions
                 SET status = 'cancelled', updated_at = NOW()
                 WHERE worker_id = ? AND status = 'pending'"
            )->execute([$userId]);

            $this->logger->info('account_deleted.escrows_resolved', [
                'user_id' => $userId,
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleAccountDeleted.resolveOpenEscrows']);
            $this->logger->error('account_deleted.escrow_resolution_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
            // S7-FIX (EVT-001): fail-loud — شکستِ بستن escrow/سرمایه‌گذاری/ارسالی
            // دیگر بی‌صدا بلعیده نمی‌شود؛ رویداد از مسیر outbox/queue retry می‌شود
            // و در نبودِ retry هم failure حالا «قابل مشاهده» است (dispatchOrFail/job fail).
            // عملیاتها UPDATEهای شرطی‌اند — اجرای مجدد (retry) idempotent است.
            throw $e;
        }
    }

    private function recordFinalAudit(int $userId, string $email, string $reason): void
    {
        try {
            // S7-FIX (EVT-001): گاردِ idempotency — retryِ رویداد نباید ردیفِ آدیتِ
            // تکراری بسازد؛ اولین آدیتِ ثبت‌شدهٔ همان user کافی است.
            $existing = $this->db->fetchColumn(
                "SELECT id FROM audit_logs WHERE user_id = ? AND action = 'account.deleted' LIMIT 1",
                [$userId]
            );
            if ($existing !== null && $existing !== false) {
                $this->logger->info('account_deleted.audit_already_recorded', ['user_id' => $userId]);
                return;
            }

            // FIX راند ۷۷ (ستون شبح): ستون واقعی audit_logs «action» است نه «event».
            $this->db->prepare(
                "INSERT INTO audit_logs (user_id, action, details, created_at)
                 VALUES (?, 'account.deleted', ?, NOW())"
            )->execute([
                $userId,
                json_encode([
                    'email'  => $email,
                    'reason' => $reason,
                ], JSON_UNESCAPED_UNICODE),
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, ['operation' => 'app.Listeners.HandleAccountDeleted.recordFinalAudit']);
            $this->logger->error('account_deleted.audit_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
            // S7-FIX (EVT-001): fail-loud — آدیتِ نهاییِ گم‌شده دیگر «حذفِ موفقِ
            // بی‌ردپا» نمی‌سازد؛ retry رویداد تا ثبت موفق ادامه می‌یابد.
            throw $e;
        }
    }
}
