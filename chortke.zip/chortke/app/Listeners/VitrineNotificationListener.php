<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Contracts\LoggerInterface;
use Core\Container;

/**
 * VitrineNotificationListener — 🛡️ FIX-VITRINE-DEAD-EVENTS
 *
 * کشفِ ممیزی outbox (۲۰۲۶-۰۸-۲۸): ۱۴ رویداد vitrine.* به outbox ثبت می‌شدند
 * ولی هیچ listener ای روی آن‌ها ثبت نشده بود — یعنی کاربران ویترین برای هیچ‌کدام
 * از اتفاق‌های مالی/چرخه‌حیات (تایید، رد، استرداد، آزادسازی وجه، انقضا، امتیاز،
 * پذیرش درخواست، حل اختلاف) اعلان دریافت نمی‌کردند. رویدادها «م published»
 * می‌شدند (dispatch به هیچ listener ختم می‌شود) و بی‌صدا دفن می‌شدند.
 *
 * این listener آن رویدادهای موجود را به اعلان کاربر تبدیل می‌کند — بدون هیچ
 * تغییری در Jobها (payloadها از قبل داده‌های لازم را دارند).
 *
 * ⚠️ الگوی رسمی (A4): وابستگی‌های سنگین عمداً lazy از Container گرفته می‌شوند
 * (سازنده فقط Container/Logger) تا از چرخه‌ی رویدادی جلوگیری شود.
 * مرجع: docs/architecture_and_standards.md §۶ — همان الگوی NotificationRequestListener.
 *
 * نکته: هیچ mutation مالی در این listener انجام نمی‌شود — همه‌ی پرداخت‌ها
 * داخل Jobهای ویترین با saga/idempotency انجام می‌شوند؛ این کلاس فقط اعلان
 * می‌فرستد (side-effect صرفاً اطلاع‌رسانی).
 */
class VitrineNotificationListener
{
    private Container $container;
    private LoggerInterface $logger;

    public function __construct(Container $container, LoggerInterface $logger)
    {
        $this->container = $container;
        $this->logger = $logger;
    }

    // ─────────────────────────────────────────────────────────────
    // آگهی ثبت شد (فروشنده) — payload: {user_id, amount, currency, listing_id?}
    // ─────────────────────────────────────────────────────────────
    public function handleListingCreated(mixed $event): void
    {
        $d = $this->payload($event);
        $userId = int_value($d['user_id'] ?? 0);
        if ($userId <= 0) {
            return;
        }
        $listingId = int_value($d['listing_id'] ?? 0);
        $this->notify(
            $userId,
            'vitrine_listing_created',
            'آگهی شما ثبت شد ✅',
            'آگهی شما با موفقیت ثبت شد و پس از بررسی مدیریت منتشر خواهد شد.',
            ['listing_id' => $listingId],
            $listingId > 0 ? "/vitrine/{$listingId}" : '/vitrine/my-listings',
            'مشاهده آگهی'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // آگهی تایید شد (فروشنده) — payload: {listing_id, seller_id, admin_id}
    // ─────────────────────────────────────────────────────────────
    public function handleListingApproved(mixed $event): void
    {
        $d = $this->payload($event);
        $sellerId = int_value($d['seller_id'] ?? 0);
        $listingId = int_value($d['listing_id'] ?? 0);
        if ($sellerId <= 0) {
            return;
        }
        $this->notify(
            $sellerId,
            'vitrine_listing_approved',
            'آگهی شما تایید شد ✅',
            'آگهی شما تایید و منتشر شد و از این لحظه برای خریداران قابل مشاهده است.',
            ['listing_id' => $listingId],
            $listingId > 0 ? "/vitrine/{$listingId}" : '/vitrine/my-listings',
            'مشاهده آگهی'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // آگهی رد شد (فروشنده) — payload: {listing_id, seller_id, reason}
    // ─────────────────────────────────────────────────────────────
    public function handleListingRejected(mixed $event): void
    {
        $d = $this->payload($event);
        $sellerId = int_value($d['seller_id'] ?? 0);
        $listingId = int_value($d['listing_id'] ?? 0);
        if ($sellerId <= 0) {
            return;
        }
        $reason = trim(str_value($d['reason'] ?? ''));
        $message = 'متأسفانه آگهی شما توسط مدیریت رد شد.';
        if ($reason !== '') {
            $message .= " علت: {$reason}";
        }
        $this->notify(
            $sellerId,
            'vitrine_listing_rejected',
            'آگهی شما رد شد ❌',
            $message,
            ['listing_id' => $listingId, 'reason' => $reason],
            '/vitrine/my-listings',
            'آگهی‌های من'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // بازگشت وجه توسط ادمین (خریدار) — payload: {listing_id, buyer_id, amount}
    // ─────────────────────────────────────────────────────────────
    public function handleAdminRefunded(mixed $event): void
    {
        $d = $this->payload($event);
        $buyerId = int_value($d['buyer_id'] ?? 0);
        $listingId = int_value($d['listing_id'] ?? 0);
        $amount = str_value($d['amount'] ?? '0');
        if ($buyerId <= 0) {
            return;
        }
        $this->notify(
            $buyerId,
            'vitrine_admin_refunded',
            'بازگشت وجه آگهی 💰',
            "مبلغ {$amount} USDT مربوط به آگهی #{$listingId} توسط مدیریت به کیف پول شما بازگشت داده شد.",
            ['listing_id' => $listingId, 'amount' => $amount],
            '/wallet',
            'کیف پول من'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // درخواست استرداد در حل اختلاف (خریدار) — payload: {buyer_id, amount, listing_id}
    // ─────────────────────────────────────────────────────────────
    public function handleRefundRequested(mixed $event): void
    {
        $d = $this->payload($event);
        $buyerId = int_value($d['buyer_id'] ?? 0);
        $listingId = int_value($d['listing_id'] ?? 0);
        $amount = str_value($d['amount'] ?? '0');
        if ($buyerId <= 0) {
            return;
        }
        $this->notify(
            $buyerId,
            'vitrine_refund_requested',
            'بازگشت وجه در حال انجام 💰',
            "مبلغ {$amount} USDT مربوط به آگهی #{$listingId} در روند بازگشت به کیف پول شما است.",
            ['listing_id' => $listingId, 'amount' => $amount],
            '/wallet',
            'کیف پول من'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // اختلاف حل شد (فروشنده + خریدار) — payload: {admin_id, listing_id, decision}
    // فروشنده/خریدار از خودِ آگهی استخراج می‌شوند.
    // ─────────────────────────────────────────────────────────────
    public function handleDisputeResolved(mixed $event): void
    {
        $d = $this->payload($event);
        $listingId = int_value($d['listing_id'] ?? 0);
        $decision = str_value($d['decision'] ?? '');
        if ($listingId <= 0) {
            return;
        }
        $listing = $this->findListing($listingId);
        if ($listing === null) {
            return;
        }
        $decisionText = match ($decision) {
            'buyer'   => 'به نفع خریدار',
            'seller'  => 'به نفع فروشنده',
            default   => 'حل‌وفصل شد',
        };
        $sellerId = int_value($listing->seller_id ?? 0);
        $buyerId  = int_value($listing->buyer_id ?? 0);
        foreach ([$sellerId, $buyerId] as $partyId) {
            if ($partyId <= 0) {
                continue;
            }
            $this->notify(
                $partyId,
                'vitrine_dispute_resolved',
                'اختلاف آگهی حل شد ⚖️',
                "اختلاف آگهی #{$listingId} {$decisionText}. جزئیات بیشتر در صفحه آگهی قابل مشاهده است.",
                ['listing_id' => $listingId, 'decision' => $decision],
                "/vitrine/{$listingId}",
                'مشاهده آگهی'
            );
        }
    }

    // ─────────────────────────────────────────────────────────────
    // وجه امانی آزاد شد (فروشنده) — payload: {seller_id, listing_id}
    // ─────────────────────────────────────────────────────────────
    public function handleEscrowReleased(mixed $event): void
    {
        $d = $this->payload($event);
        $sellerId = int_value($d['seller_id'] ?? 0);
        $listingId = int_value($d['listing_id'] ?? 0);
        if ($sellerId <= 0) {
            return;
        }
        $this->notify(
            $sellerId,
            'vitrine_escrow_released',
            'وجه فروش آزاد شد 💰',
            "وجه فروش آگهی #{$listingId} از امانت آزاد و به کیف پول شما واریز شد.",
            ['listing_id' => $listingId],
            '/wallet',
            'کیف پول من'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // امانت منقضی شد (خریدار) — payload: {escrow_id, buyer_id, amount}
    // ─────────────────────────────────────────────────────────────
    public function handleEscrowExpired(mixed $event): void
    {
        $d = $this->payload($event);
        $buyerId = int_value($d['buyer_id'] ?? 0);
        $escrowId = int_value($d['escrow_id'] ?? 0);
        $amount = str_value($d['amount'] ?? '0');
        if ($buyerId <= 0) {
            return;
        }
        $this->notify(
            $buyerId,
            'vitrine_escrow_expired',
            'بازگشت خودکار وجه امانی ⏰',
            "به دلیل عدم تایید در مهلت مقرر، مبلغ {$amount} USDT امانت آگهی به کیف پول شما بازگشت داده شد.",
            ['escrow_id' => $escrowId, 'amount' => $amount],
            '/wallet',
            'کیف پول من'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // آگهی منقضی شد (صاحب آگهی) — payload: {id, user_id}
    // ─────────────────────────────────────────────────────────────
    public function handleListingExpired(mixed $event): void
    {
        $d = $this->payload($event);
        $userId = int_value($d['user_id'] ?? 0);
        $listingId = int_value($d['id'] ?? ($d['listing_id'] ?? 0));
        if ($userId <= 0) {
            return;
        }
        $this->notify(
            $userId,
            'vitrine_listing_expired',
            'آگهی شما منقضی شد ⏰',
            "مهلت انتشار آگهی #{$listingId} به پایان رسید و آگهی شما منقضی شد. در صورت تمایل می‌توانید آگهی جدید ثبت کنید.",
            ['listing_id' => $listingId],
            '/vitrine/my-listings',
            'آگهی‌های من'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // امتیاز جدید (فروشنده) — payload: {rating_id, rater_id, listing_id, stars}
    // فروشنده از خود آگهی استخراج می‌شود.
    // ─────────────────────────────────────────────────────────────
    public function handleListingRated(mixed $event): void
    {
        $d = $this->payload($event);
        $listingId = int_value($d['listing_id'] ?? 0);
        $stars = int_value($d['stars'] ?? 0);
        if ($listingId <= 0) {
            return;
        }
        $listing = $this->findListing($listingId);
        if ($listing === null) {
            return;
        }
        $sellerId = int_value($listing->seller_id ?? 0);
        if ($sellerId <= 0) {
            return;
        }
        $starText = $stars > 0 ? str_repeat('⭐', max(1, min(5, $stars))) : 'امتیاز جدید';
        $this->notify(
            $sellerId,
            'vitrine_listing_rated',
            'امتیاز جدید برای آگهی شما ' . $starText,
            "خریدار به آگهی #{$listingId} امتیاز داد. امتیاز شما در صفحه فروشگاه شما به‌روزرسانی شد.",
            [
                'listing_id' => $listingId,
                'stars' => $stars,
                // 🛡️ FIX-T29-24 (راند ۳ اصلاح بخش ۲۹): rating_id موجود در خود رویداد
                // (RateVitrineListingJob آن را می‌فرستد) به data می‌رسد تا aggregate
                // در notify() از rating_id بگذرد و «دومین امتیاز روی همان آگهی»
                // اعلان تازه بسازد، نه آن‌که با کلید type_user_listing برای همیشه
                // در idempotency_key یکتا بلعیده شود.
                'rating_id' => int_value($d['rating_id'] ?? 0),
            ],
            "/vitrine/{$listingId}",
            'مشاهده آگهی'
        );
    }

    // ─────────────────────────────────────────────────────────────
    // درخواست خرید پذیرفته شد (درخواست‌کننده) — payload: {listing_id, request_id, seller_id, requester_id, offer_price}
    // ─────────────────────────────────────────────────────────────
    public function handleRequestAccepted(mixed $event): void
    {
        $d = $this->payload($event);
        $requesterId = int_value($d['requester_id'] ?? 0);
        $listingId = int_value($d['listing_id'] ?? 0);
        $offerPrice = str_value($d['offer_price'] ?? '0');
        if ($requesterId <= 0) {
            return;
        }
        // آگهی «درخواست خرید»: پس از پذیرش نقش‌ها جابه‌جا می‌شوند و درخواست‌دهنده تحویل‌دهنده (فروشنده) است
        // و منتظر پرداخت مالک آگهی می‌ماند، نه پرداخت‌کننده.
        $listing = $this->findListing($listingId);
        $isDeliverer = $listing !== null && int_value($listing->seller_id ?? 0) === $requesterId;
        $priceText = $offerPrice !== '0' ? " با قیمت {$offerPrice} USDT" : '';
        $message = $isDeliverer
            ? "پیشنهاد شما برای آگهی #{$listingId}{$priceText} پذیرفته شد. منتظر پرداخت خریدار بمانید؛ پس از پرداخت، حساب را تحویل دهید."
            : "فروشنده درخواست شما برای آگهی #{$listingId}{$priceText} را پذیرفت. مهلت پرداخت/تایید را از دست ندهید.";
        $this->notify(
            $requesterId,
            'vitrine_request_accepted',
            'درخواست شما پذیرفته شد ✅',
            $message,
            ['listing_id' => $listingId, 'request_id' => int_value($d['request_id'] ?? 0)],
            "/vitrine/{$listingId}",
            'مشاهده و ادامه خرید'
        );
    }

    // ═════════════════════════════════════════════════════════════
    // درخواست خرید رد شد (درخواست‌کننده) — payload: {requester_id, listing_id}
    // FIX-R36-W3 (F-A19e-06): رویداد در VitrineService::rejectRequest تولید می‌شد
    // ولی شنونده نداشت (جا مانده از FIX-VITRINE-DEAD-EVENTS) → اکنون اعلان دارد.
    // ═════════════════════════════════════════════════════════════
    public function handleRequestRejected(mixed $event): void
    {
        $d = $this->payload($event);
        $requesterId = int_value($d['requester_id'] ?? 0);
        $listingId = int_value($d['listing_id'] ?? 0);
        if ($requesterId <= 0) {
            return;
        }
        $this->notify(
            $requesterId,
            'vitrine_request_rejected',
            'درخواست شما رد شد ❌',
            "فروشنده درخواست شما برای آگهی #{$listingId} را رد کرد. می‌توانید آگهی‌های دیگر را بررسی کنید.",
            ['listing_id' => $listingId, 'request_id' => int_value($d['request_id'] ?? 0)],
            $listingId > 0 ? "/vitrine/{$listingId}" : '/vitrine',
            'مشاهده آگهی'
        );
    }

    // ═════════════════════════════════════════════════════════════
    // ابزارهای داخلی (A4 lazy)
    // ═════════════════════════════════════════════════════════════

    /** @return array<string, mixed> */
    private function payload(mixed $event): array
    {
        if ($event instanceof \Core\Event) {
            $d = $event->getData();
            return is_array($d) ? $d : [];
        }
        if (is_array($event)) {
            return $event;
        }
        return [];
    }

    private function findListing(int $listingId): ?\stdClass
    {
        try {
            $model = $this->container->make(\App\Models\VitrineListing::class);
            $row = $model->find($listingId);
            if (is_array($row)) {
                return (object)$row;
            }
            return is_object($row) ? $row : null;
        } catch (\Throwable $e) {
            $this->logger->warning('vitrine.notification.listing_lookup_failed', [
                'listing_id' => $listingId,
                'error'      => $e->getMessage(),
            ]);
            return null;
        }
    }

    /** @param array<string, mixed> $data */
    private function notify(
        int $userId,
        string $type,
        string $title,
        string $message,
        array $data = [],
        ?string $actionUrl = null,
        ?string $actionText = null
    ): void {
        if ($userId <= 0) {
            return;
        }
        try {
            // FIX-R36-W3 (F-A19e-05): اعلان از درِ واحد notification.requested (outbox)
            // با event_id قطعی — الگوی WithdrawalListener:103 / EscrowListener:97.
            // پیش‌تر NotificationService::send مستقیم بدون هیچ dedupe صدا می‌شد؛
            // بازپخش/zombie-recovery ردیف‌های outbox ویترین، اعلان تکراری می‌ساخت.
            // event_id قطعی از (type, user, aggregate) مشتق می‌شود تا replay همان
            // رویداد dedup شود ولی رویدادهای واقعاً جدید (rating_id/request_id/
            // escrow_id متفاوت) از سر راه نیایند.
            //
            // 🛡️ FIX-T29-24 (راند ۳ اصلاح بخش ۲۹): نُه رویداد فقط-listing_id
            // (created/approved/rejected/refunded/refund_requested/dispute_resolved/
            // escrow_released/expired/rated) هیچ شناسهٔ یکتای رویداد نداشتند و کلید
            // «نوع_کاربر_listing» در ستون یکتای idempotency_key دائمی می‌شد ⇒ دومین
            // رد/تأیید بعد از ویرایش، دومین انقضا بعد از تمدید و دومین اعلان ادمینی
            // برای همیشه با ON DUPLICATE بلعیده می‌شد. درمان طبق پیشنهاد گزارش:
            // شناسهٔ خودِ رویداد در کلید — وقتی شناسهٔ یکتا هست (request_id/
            // rating_id/escrow_id) همان استفاده می‌شود؛ وقتی نیست، مُهر ساعتِ
            // رویداد (الگوی buildClaimKey دور ۲ ادمین‌ها): درون ساعت replay همان
            // رویداد همچنان dedup می‌شود (بازپخش outbox)، پس از ساعتِ تازه ثبت
            // تازه. یعنی «ویرایش و ردِ دوباره» و «تمدید و انقضای دوباره» اعلان
            // می‌سازند، طوفان بازپخش نمی‌سازند.
            $aggregate = $data['request_id'] ?? $data['rating_id'] ?? $data['escrow_id'] ?? $data['listing_id'] ?? null;
            // شناسهٔ یکتای «معتبر» — صفر یعنی موجود نیست (بازبینی مستقل دور ۳):
            // isset(0) ترو است و کلید دائمیِ type_user_0 می‌ساخت؛ گارد > 0 است.
            $uniqueId = int_value($data['request_id'] ?? 0) ?: (int_value($data['rating_id'] ?? 0) ?: int_value($data['escrow_id'] ?? 0));
            $hasUniqueEventId = $uniqueId > 0;
            // «مُهر ساعت» فقط وقتی است که شناسهٔ یکتا نباشد؛ در آن حالت aggregate
            // باید شناسهٔ موجودِ رویداد باشد (listing)، نه صفرِ شناسهٔ غایب — تا
            // دو آگهیِ متفاوتِ همان فروشنده در همان ساعت با کلید _0_ هم‌اتاق نشوند
            // (یافتهٔ ۲ نوبت دوم بازبینی: برخورد بین-آگهیِ درون‌ساعتِ legacy).
            $stampBase = $hasUniqueEventId ? $aggregate : ($data['listing_id'] ?? $aggregate);
            $eventId = $type . '_' . $userId . ($stampBase !== null ? '_' . int_value($stampBase) : '');
            if ($stampBase !== null && !$hasUniqueEventId) {
                // فقط-listing_id: مُهر ساعتِ رویداد وارد کلید می‌شود.
                $eventId .= '_' . date('YmdH');
            }
            $data['event_id'] = $eventId;
            $payload = [
                'event_id'   => $eventId,
                'user_id'    => $userId,
                'type'       => $type,
                'title'      => $title,
                'message'    => $message,
                'data'       => $data,
                'action_url' => $actionUrl,
                'action_text'=> $actionText,
            ];

            $outbox = null;
            try {
                $outbox = $this->container->make(\App\Contracts\OutboxServiceInterface::class);
            } catch (\Throwable) {
                // بدون outbox → fallback به ارسال مستقیم (رفتار قبلی)
            }
            if ($outbox !== null) {
                $ok = $outbox->record('notification', $userId, 'notification.requested', $payload);
                if (!empty($ok)) {
                    $this->logger->info('vitrine.notification.requested', [
                        'user_id' => $userId,
                        'type'    => $type,
                        'event_id'=> $eventId,
                    ]);
                    return;
                }
                $this->logger->warning('vitrine.notification.outbox_record_failed_fallback_direct', [
                    'user_id' => $userId,
                    'type'    => $type,
                ]);
            }

            /** @var \App\Services\Notification\NotificationService $notificationService */
            $notificationService = $this->container->make(\App\Services\Notification\NotificationService::class);
            $notificationService->send($userId, $type, $title, $message, $data, $actionUrl, $actionText);
            $this->logger->info('vitrine.notification.sent', [
                'user_id' => $userId,
                'type'    => $type,
            ]);
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'app.Listeners.VitrineNotificationListener.notify',
                'type'      => $type,
                'user_id'   => $userId,
            ]);
            $this->logger->error('vitrine.notification.failed', [
                'user_id' => $userId,
                'type'    => $type,
                'error'   => $e->getMessage(),
            ]);
        }
    }
}
