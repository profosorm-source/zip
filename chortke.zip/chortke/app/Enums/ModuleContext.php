<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * دامنه‌ها و ماژول‌های سیستم برای تفکیک منطقی امتیازات و تعاملات
 */
enum ModuleContext: string
{
    case YOUTUBE_TASKS = 'youtube_tasks';
    case SOCIAL_TASKS = 'social_tasks';
    case CUSTOM_TASKS = 'custom_tasks';
    case GOOGLE_SEARCH_TASKS = 'google_search_tasks';
    case INVESTMENT = 'investment';
    case CONTENT = 'content';
    case GLOBAL = 'global'; // برای امتیازات عمومی سیستم
    // FIX-POP (تصمیم ۲-A مالک): پاداش پاپ‌آپ ویدیوی جایزه‌دار «بدون هیچ پرداخت پولی» است —
    // فقط XP انگیزشی به‌تفکیک بخش (مبلغ از تنظیمات popup_xp_*) + بوست صف.
    // دامنهٔ لجر: xp_popup_boost (کرانه [0, UNBOUNDED] از ScoreDomainPolicy به‌صورت خودکار).
    case POPUP_BOOST = 'popup_boost';

    public function label(): string
    {
        return match($this) {
            self::YOUTUBE_TASKS => 'تسک‌های یوتیوب',
            self::SOCIAL_TASKS => 'تسک‌های شبکه‌های اجتماعی',
            self::CUSTOM_TASKS => 'تسک‌های سفارشی',
            self::GOOGLE_SEARCH_TASKS => 'تسک‌های جستجوی گوگل',
            self::INVESTMENT => 'سرمایه‌گذاری',
            self::CONTENT => 'محتوا',
            self::GLOBAL => 'عمومی',
            self::POPUP_BOOST => 'پاپ‌آپ پاداش‌دار',
        };
    }

    /**
     * FIX-M1M3 (گزارش ماژول ۱، M3): فهرست مقادیر مجاز enum برای
     * اعتبارسنجی ورودی (rule در:…) — ورودی ناشناخته هرگز نباید به
     * fallback صامت GLOBAL برسد.
     *
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(static fn(self $c): string => $c->value, self::cases());
    }
}
