<?php

namespace App\Enums;

class TicketPriority
{
    const LOW = 'low';
    const NORMAL = 'normal';
    // FIX-18O (P2): هم‌ترازی با enum نهایی ستون tickets.priority
    // (2026_07_16_0004_tickets_workflow_compat.sql: low,normal,medium,high,urgent,critical)
    const MEDIUM = 'medium';
    const HIGH = 'high';
    const URGENT = 'urgent';
    const CRITICAL = 'critical';
    
    /** @return list<string> */
    public static function all(): array
    {
        return [
            self::LOW,
            self::NORMAL,
            self::MEDIUM,
            self::HIGH,
            self::URGENT,
            self::CRITICAL
        ];
    }
    
    public static function label(string $priority): string
    {
        $labels = [
            self::LOW => 'پایین',
            self::NORMAL => 'عادی',
            self::MEDIUM => 'متوسط',
            self::HIGH => 'بالا',
            self::URGENT => 'فوری',
            self::CRITICAL => 'بحرانی'
        ];
        
        return $labels[$priority] ?? 'عادی';
    }
    
    public static function badgeClass(string $priority): string
    {
        $classes = [
            self::LOW => 'badge-secondary',
            self::NORMAL => 'badge-info',
            self::MEDIUM => 'badge-primary',
            self::HIGH => 'badge-warning',
            self::URGENT => 'badge-danger',
            self::CRITICAL => 'badge-danger'
        ];
        
        return $classes[$priority] ?? 'badge-info';
    }
}