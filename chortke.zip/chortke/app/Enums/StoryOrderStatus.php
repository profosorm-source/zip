<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * 🔒 FIX-STATUS-ENUM (راند بهداشت — مصوب مالک: «مهاجرت سه‌گانهٔ Ads/StoryOrder/custom_task
 * به الگوی Enum») — مهاجرت ۲ از ۳:
 * وضعیت‌های سفارش استوری اینفلوئنسر (story_orders.status — ستون VARCHAR(50)،
 * مایگریشن 2026_06_14_0011) — منبع واحد برچسب/رنگ در هر دو سمت ادمین و کاربر
 * (Admin/User InfluencerController).
 *
 * پیش از این فیکس، قرارداد فقط داخل مدل StoryOrder با دو نقشهٔ دستی
 * (statusLabels/statusClasses) تعریف می‌شد. اکنون:
 *   - cases():   کل قرارداد ذخیره‌سازی — دقیقاً ۱۷ مقدارِ نقشهٔ قبلی مدل
 *                (قرارداد بسته؛ تست پین StoryOrderModelTest::*
 *                status_labels_cover_every_domain_status و
 *                every_status_has_a_non_empty_bootstrap_class آن را قفل کرده‌اند).
 *   - label():   برچسب فارسی — عیناً همان متن‌های قبلی (بدون هیچ تغییر نمایشی).
 *   - badge():   کلاس CSS badge — عیناً همان کلاس‌های قبلی (شامل badge-orange
 *                اختصاصی peer_resolution).
 *
 * لایهٔ نمایش: StoryOrder::statusLabels()/statusClasses() عمومی و بدون تغییر
 * امضا باقی می‌مانند و به labelsMap()/badgesMap() همین enum delegate می‌کنند
 * تا مصرف‌کنندگان (InfluencerController ادمین + کاربر) بدون تغییر کار کنند.
 *
 * دامنه‌های عمداً خارج:
 *   - story_order_status_labels_map/classes_map (۵ کلیدی: pending/active/
 *     completed/cancelled/rejected) — کد مردهٔ جدا از این قرارداد؛ در راند
 *     DEADCODE-STORYORDER-HELPERS (2026-10-21) با تصویب مالک حذف شدند
 *     (مصرف‌صفر با گریپ کل‌درخت + الگوهای پویا اثبات شده بود).
 *   - وضعیت‌های submissions/اختلاف‌ها که جداول خودشان را دارند.
 */
enum StoryOrderStatus: string
{
    case PendingPayment      = 'pending_payment';
    case PendingAcceptance   = 'pending_acceptance';
    case Paid                = 'paid';
    case Accepted            = 'accepted';
    case RejectedByInfluencer = 'rejected_by_influencer';
    case Published           = 'published';
    case ProofSubmitted      = 'proof_submitted';
    case AwaitingBuyerCheck  = 'awaiting_buyer_check';
    case PeerResolution      = 'peer_resolution';
    case EscalatedToAdmin    = 'escalated_to_admin';
    case Verified            = 'verified';
    case Rejected            = 'rejected';
    case Disputed            = 'disputed';
    case Completed           = 'completed';
    case Cancelled           = 'cancelled';
    case Refunded            = 'refunded';
    case Expired             = 'expired';

    /** برچسب فارسی — منبع واحد نمایش (عین نقشهٔ قبلی مدل). */
    public function label(): string
    {
        return match ($this) {
            self::PendingPayment      => 'در انتظار پرداخت',
            self::PendingAcceptance   => 'در انتظار پاسخ اینفلوئنسر',
            self::Paid                => 'پرداخت شده',
            self::Accepted            => 'پذیرفته شده',
            self::RejectedByInfluencer => 'رد توسط اینفلوئنسر',
            self::Published           => 'منتشر شده',
            self::ProofSubmitted      => 'مدرک ارسال شده',
            self::AwaitingBuyerCheck  => 'در انتظار تأیید خریدار',
            self::PeerResolution      => 'حل اختلاف دوطرفه',
            self::EscalatedToAdmin    => 'ارجاع به مدیر',
            self::Verified            => 'تأیید مدرک',
            self::Rejected            => 'رد شده',
            self::Disputed            => 'اختلاف',
            self::Completed           => 'تکمیل‌شده',
            self::Cancelled           => 'لغو شده',
            self::Refunded            => 'بازگشت وجه',
            self::Expired             => 'منقضی',
        };
    }

    /** کلاس CSS badge (عین نقشهٔ قبلی مدل). */
    public function badge(): string
    {
        return match ($this) {
            self::PendingPayment      => 'badge-secondary',
            self::PendingAcceptance   => 'badge-warning',
            self::Paid                => 'badge-info',
            self::Accepted            => 'badge-primary',
            self::RejectedByInfluencer => 'badge-danger',
            self::Published           => 'badge-info',
            self::ProofSubmitted      => 'badge-warning',
            self::AwaitingBuyerCheck  => 'badge-warning',
            self::PeerResolution      => 'badge-orange',
            self::EscalatedToAdmin    => 'badge-danger',
            self::Verified            => 'badge-success',
            self::Rejected            => 'badge-danger',
            self::Disputed            => 'badge-danger',
            self::Completed           => 'badge-success',
            self::Cancelled           => 'badge-secondary',
            self::Refunded            => 'badge-warning',
            self::Expired             => 'badge-secondary',
        };
    }

    /**
     * نقشهٔ value => label به همان ترتیب نقشهٔ قبلی مدل (قرارداد نمایشی پایدار).
     *
     * @return array<string, string>
     */
    public static function labelsMap(): array
    {
        $out = [];
        foreach (self::cases() as $case) {
            $out[$case->value] = $case->label();
        }
        return $out;
    }

    /** @return array<string, string> نقشهٔ value => کلاس badge */
    public static function badgesMap(): array
    {
        $out = [];
        foreach (self::cases() as $case) {
            $out[$case->value] = $case->badge();
        }
        return $out;
    }

    /**
     * resolve امن از رشتهٔ خام دیتابیس (NULL/خالی/ناشناخته → null).
     * لایهٔ ویو موظف است برای null فالبک نمایشی بدهد (الگوی social_platform_label).
     */
    public static function tryFromString(?string $status): ?self
    {
        if ($status === null || $status === '') {
            return null;
        }
        return self::tryFrom(strtolower($status));
    }
}
