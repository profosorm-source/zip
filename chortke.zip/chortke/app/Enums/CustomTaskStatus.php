<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * 🔒 FIX-STATUS-ENUM (راند بهداشت — مصوب مالک: «مهاجرت سه‌گانهٔ Ads/StoryOrder/custom_task
 * به الگوی Enum») — مهاجرت ۳ از ۳:
 * وضعیت‌های وظیفهٔ سفارشی (custom_tasks.status) — منبع واحد برچسب/رنگ در پنل
 * ادمین (views/admin/custom-tasks/index.php) از راه دو هلپر نمایشی
 * custom_task_status_labels_map()/custom_task_status_classes_map().
 *
 * نکتهٔ قراردادی — مستعار تاریخی: داده‌های قدیمی و کوئری‌های تحلیلی
 * (AnalyticsService:187) هر دو املای 'pending_review' و 'review_pending' را
 * برای «در انتظار بررسی» ثبت کرده‌اند. بنابراین:
 *   - case معتبر فقط PendingReview = 'pending_review' است (املای استاندارد)؛
 *   - tryFromString() املای قدیمی 'review_pending' را به همین case نگاشت می‌کند؛
 *   - نقشه‌های نمایشیِ هلپر (labelsMapWithAlias/badgesMapWithAlias) کلید
 *     'review_pending' را هم حفظ می‌کنند تا ردیف‌های قدیمیِ جدول ادمین برچسب
 *     بگیرند و خام چاپ نشوند (دقیقاً هم‌الگوی درس R7-MINOR-1 در KYC).
 *
 * پیش از این فیکس، قرارداد فقط به‌صورت دو نقشهٔ دستی inline داخل
 * label_helpers.php بود. اکنون هلپرها لایهٔ نازک delegate دور همین enum‌اند
 * (الگوی مصوب: Enum + هلپر نمایشی نازک).
 */
enum CustomTaskStatus: string
{
    case Draft         = 'draft';
    case PendingReview = 'pending_review';
    case Active        = 'active';
    case Paused        = 'paused';
    case Completed     = 'completed';
    case Rejected      = 'rejected';
    case Expired       = 'expired';

    /** املای تاریخیِ مستعار «در انتظار بررسی» در داده‌های قدیمی. */
    public const LEGACY_ALIAS_PENDING_REVIEW = 'review_pending';

    /** برچسب فارسی — منبع واحد نمایش (عین نقشهٔ قبلی هلپر). */
    public function label(): string
    {
        return match ($this) {
            self::Draft         => 'پیشنویس',
            self::PendingReview => 'در انتظار بررسی',
            self::Active        => 'فعال',
            self::Paused        => 'متوقف',
            self::Completed     => 'تکمیل‌شده',
            self::Rejected      => 'رد شده',
            self::Expired       => 'منقضی',
        };
    }

    /** کلاس CSS badge (عین نقشهٔ قبلی هلپر). */
    public function badge(): string
    {
        return match ($this) {
            self::Draft         => 'badge-secondary',
            self::PendingReview => 'badge-warning',
            self::Active        => 'badge-success',
            self::Paused        => 'badge-info',
            self::Completed     => 'badge-primary',
            self::Rejected      => 'badge-danger',
            self::Expired       => 'badge-danger',
        };
    }

    /**
     * نقشهٔ value => label (فقط املای استاندارد، بدون مستعار).
     *
     * @return array<string, string>
     */
    public static function labelsMap(): array
    {
        $out = [];
        foreach ([self::Draft, self::PendingReview, self::Active, self::Paused, self::Completed, self::Rejected, self::Expired] as $case) {
            $out[$case->value] = $case->label();
        }
        return $out;
    }

    /** @return array<string, string> نقشهٔ value => کلاس badge */
    public static function badgesMap(): array
    {
        $out = [];
        foreach (self::cases() as $case) {
            $out[$case->value] = $case->badge();
        }
        return $out;
    }

    /**
     * نقشهٔ نمایشی با مستعار تاریخی — قرارداد بستهٔ ۸ کلیدیِ
     * custom_task_status_labels_map قبلی (ترتیب و متن‌ها عیناً حفظ شده).
     *
     * @return array<string, string>
     */
    public static function labelsMapWithAlias(): array
    {
        $canonical = self::labelsMap();
        $out = [];
        foreach ($canonical as $value => $label) {
            $out[$value] = $label;
            if ($value === self::PendingReview->value) {
                $out[self::LEGACY_ALIAS_PENDING_REVIEW] = $label;
            }
        }
        return $out;
    }

    /** @return array<string, string> نقشهٔ نمایشی کلاس‌ها با مستعار تاریخی */
    public static function badgesMapWithAlias(): array
    {
        $canonical = self::badgesMap();
        $out = [];
        foreach ($canonical as $value => $class) {
            $out[$value] = $class;
            if ($value === self::PendingReview->value) {
                $out[self::LEGACY_ALIAS_PENDING_REVIEW] = $class;
            }
        }
        return $out;
    }

    /**
     * resolve امن از رشتهٔ خام دیتابیس — املای قدیمی 'review_pending' هم به
     * PendingReview نگاشت می‌شود (NULL/خالی/ناشناخته → null).
     */
    public static function tryFromString(?string $status): ?self
    {
        if ($status === null || $status === '') {
            return null;
        }
        $normalized = strtolower($status);
        if ($normalized === self::LEGACY_ALIAS_PENDING_REVIEW) {
            return self::PendingReview;
        }
        return self::tryFrom($normalized);
    }
}
