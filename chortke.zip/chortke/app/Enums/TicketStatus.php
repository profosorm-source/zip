<?php

namespace App\Enums;

/**
 * FIX-X326 (تسک ۸۳): PENDING و REPLIED به enum اضافه شدند — هر دو در
 * enum واقعی ستون tickets (2026_07_16_0019) وجود دارند، TicketService::getStats()
 * آن‌ها را می‌شمارد و Ticket::updateLastReply هم تولیدشان می‌کند؛ ولی
 * all() آن‌ها را نداشت → پنل ادمین نمی‌توانست وضعیت را به همان مقادیری
 * که خودِ سیستم تولید می‌کند تغییر دهد (درخواست change-status رد می‌شد).
 */
class TicketStatus
{
    const OPEN = 'open';
    const PENDING = 'pending';
    const REPLIED = 'replied';
    const ANSWERED = 'answered';
    const IN_PROGRESS = 'in_progress';
    const ON_HOLD = 'on_hold';
    const CLOSED = 'closed';
    
    /** @return list<string> */
    public static function all(): array
    {
        return [
            self::OPEN,
            self::PENDING,
            self::REPLIED,
            self::ANSWERED,
            self::IN_PROGRESS,
            self::ON_HOLD,
            self::CLOSED
        ];
    }
    
    public static function label(string $status): string
    {
        $labels = [
            self::OPEN => 'باز',
            self::PENDING => 'در انتظار بررسی',
            self::REPLIED => 'پاسخ داده شد (کاربر)',
            self::ANSWERED => 'پاسخ داده شده',
            self::IN_PROGRESS => 'در حال بررسی',
            self::ON_HOLD => 'در انتظار پاسخ کاربر',
            self::CLOSED => 'بسته شده'
        ];
        
        return $labels[$status] ?? 'نامشخص';
    }
    
    public static function badgeClass(string $status): string
    {
        $classes = [
            self::OPEN => 'badge-success',
            self::PENDING => 'badge-warning',
            self::REPLIED => 'badge-info',
            self::ANSWERED => 'badge-info',
            self::IN_PROGRESS => 'badge-warning',
            self::ON_HOLD => 'badge-secondary',
            self::CLOSED => 'badge-dark'
        ];
        
        return $classes[$status] ?? 'badge-secondary';
    }
}
