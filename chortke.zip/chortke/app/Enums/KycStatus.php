<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * 🔒 FIX-KYC-ENUM (راند بهداشت — مصوب مالک: «Enum مشترک KYC (ادمین + کاربر)»):
 * وضعیت‌های احراز هویت (kyc_verifications.status) — منبع واحد برچسب/رنگ بین
 * سمت ادمین و کاربر.
 *
 * پیش از این فیکس، قرارداد «برچسب وضعیت KYC» در دست‌کم هفت نقطهٔ مستقل
 * تعریف شده بود و بینشان دریفت می‌کرد (دقیقاً همان باگ R7-MINOR-1: ویوهایی
 * که «منقضی» را نمی‌شناختند و وضعیت منقضی‌شده را خام چاپ می‌کردند):
 *   - app/Controllers/User/KYCController::status():     آرایهٔ inline (۵ وضعیت، متن متفاوت)
 *   - app/Controllers/User/KYCController::show():       آرایهٔ inline (۴ وضعیت — expired غایب!)
 *   - views/admin/kyc/index.php:                        $statusColors/$statusNames محلی
 *   - views/admin/kyc/review.php:                       $stMap/$stNames محلی
 *   - views/admin/withdrawals/review.php:               نقشهٔ inline (۴ وضعیت)
 *   - views/admin/bank-cards/review.php:                منطق دودویی (rejected هم «در انتظار» می‌شد)
 *   - views/admin/users/edit.php:                       نقشهٔ inline (۴ وضعیت)
 *
 * اکنون همهٔ این لایه‌ها به همین مرجع متصل‌اند:
 *   - cases():   کل قرارداد ذخیره‌سازی — دقیقاً همان ENUM ستون kyc_verifications.status
 *                (مایگریشن 2026_10_04_0001 که 'expired' را اضافه کرد: ۵ مقدار)؛
 *                تغییر این مجموعه = تغییر schema، نه فقط تغییر کد.
 *   - label():   برچسب فارسی — helper نمایشی (label_helpers.php) + هر دو کنترلر.
 *   - badge():   کلاس CSS badge — helper نمایشی + ویوهای صف ادمین.
 *
 * درس FIX-S20-DEADFILE (UserStatus/TransactionStatus حذف شدند چون به زنجیرهٔ
 * واقعی متصل نبودند): این enum فقط زنده است چون لایه‌های بالا واقعاً از آن
 * می‌خوانند و بلوک هلپر KYC در label_helpers.php تنها نقطهٔ ورود نمایشی است.
 *
 * دامنه‌های دیگر (عمداً خارج از این enum):
 *   - users.kyc_status (VARCHAR): پرچم سطح کاربر با مقدار اضافهٔ 'unverified'
 *     (و 'none' ورودی‌های قدیمی) — نمایشش از user_kyc_status_label() در
 *     label_helpers.php می‌گذرد که برای ۵ مقدار مشترک همین‌جا delegate می‌کند.
 *   - users.kyc_level / kyc_verified_at: مفهوم عددی/زمانی، نه وضعیت.
 */
enum KycStatus: string
{
    case Pending     = 'pending';
    case UnderReview = 'under_review';
    case Verified    = 'verified';
    case Rejected    = 'rejected';
    case Expired     = 'expired';

    /**
     * برچسب فارسی — منبع واحد نمایش (کنترلر کاربر + helper + ویوهای ادمین).
     * واژه‌ها = نسخهٔ توصیفی سمت کاربر (پیش از این، سمت ادمین «در انتظار/در بررسی»
     * و سمت کاربر «در انتظار بررسی/در حال بررسی» چاپ می‌کرد — دریفت نمایش).
     */
    public function label(): string
    {
        return match ($this) {
            self::Pending     => 'در انتظار بررسی',
            self::UnderReview => 'در حال بررسی',
            self::Verified    => 'تأیید شده',
            self::Rejected    => 'رد شده',
            self::Expired     => 'منقضی شده',
        };
    }

    /**
     * کلاس CSS badge (الگوی پیش‌فرض پروژه: badge-*). منقضی = پایان‌مسیرِ خنثی
     * (هم‌الگوی seo_execution_status_badge: expired → secondary)، نه خطا.
     */
    public function badge(): string
    {
        return match ($this) {
            self::Pending     => 'badge-warning',
            self::UnderReview => 'badge-info',
            self::Verified    => 'badge-success',
            self::Rejected    => 'badge-danger',
            self::Expired     => 'badge-secondary',
        };
    }

    /**
     * نقشهٔ value => label برای ویوهایی که حلقه می‌زنند (فیلتر دراپ‌داون و…).
     * ترتیب = ترتیب منطقیِ چرخهٔ بررسی (نه ترتیب enum).
     *
     * @return array<string, string>
     */
    public static function labelsMap(): array
    {
        $out = [];
        foreach ([self::Pending, self::UnderReview, self::Verified, self::Rejected, self::Expired] as $case) {
            $out[$case->value] = $case->label();
        }
        return $out;
    }

    /** @return array<string, string> نقشهٔ value => کلاس badge */
    public static function badgesMap(): array
    {
        $out = [];
        foreach (self::cases() as $case) {
            $out[$case->value] = $case->badge();
        }
        return $out;
    }

    /**
     * resolve امن از رشتهٔ خام دیتابیس (NULL/تاریخی/ناشناخته → null).
     * لایهٔ ویو موظف است برای null فالبک نمایشی بدهد (الگوی social_platform_label).
     */
    public static function tryFromString(?string $status): ?self
    {
        if ($status === null || $status === '') {
            return null;
        }
        return self::tryFrom(strtolower($status));
    }
}
