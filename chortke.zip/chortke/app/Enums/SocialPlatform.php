<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * 🔒 FIX-F21-02-LT (بازبینی بخش ۲۱ — پیشنهاد بلندمدت): پلتفرم‌های شبکهٔ
 * اجتماعی — منبع واحد برای رابط، validator و persistence.
 *
 * پیش از این فیکس، قرارداد «کدام پلتفرم» در شش نقطهٔ مستقل تعریف شده بود و
 * بینشان دریفت می‌کرد (دقیقاً همان باگ F21-02: رابط تیک‌تاک را ارائه می‌کرد
 * ولی allow-list والیدیتور آن را نداشت — انتخابِ معتبرِ کاربر در اعتبارسنجی
 * رد می‌شد):
 *   - SocialAccountController::index/showCreate:   آرایهٔ key=>label هاردکد (۲ نسخهٔ کپی)
 *   - StoreSocialAccountRequest::rules():          'in:instagram,telegram,youtube,tiktok,twitter'
 *   - SocialAccountService::getMinPosts/getMinFollowers: نقشه‌های سهمیه
 *   - SocialAccount::platformLabel():              نقشهٔ label
 *   - helpers/label_helpers.php::social_platform_label(): نقشهٔ label سوپرست
 *   - views/admin/social-accounts/index.php:       آپشن‌های فیلتر هاردکد
 *
 * اکنون همهٔ این لایه‌ها به همین مرجع متصل‌اند:
 *   - cases():              کل قرارداد ذخیره‌سازی — دقیقاً همان ENUM ستون
 *                           user_social_accounts.platform مایگریشن
 *                           2026_06_10_0040 (۸ مقدار)؛ تغییر این مجموعه =
 *                           تغییر schema، نه فقط تغییر کد.
 *   - registerable():       ۵ پلتفرمی که فرم ثبت حساب ارائه می‌کند و
 *                           validator می‌پذیرد (aparat مالِ دامنهٔ تسک اجتماعی
 *                           است و linkedin/other فقط سازگاری DB/label —
 *                           ثبت‌شان به‌عنوان حساب کاربر مجاز نیست).
 *   - validationRule():     رشتهٔ قاعدهٔ in: — StoreSocialAccountRequest.
 *   - forSelect():          key=>label درپ‌داون‌های UI — کنترلر کاربر.
 *   - label():              برچسب فارسی همهٔ ۸ مقدار — مدل + helper نمایش.
 *   - minPosts()/minFollowers(): سهمیه‌های کیفیت حساب — SocialAccountService.
 *
 * درس FIX-S20-DEADFILE (UserStatus/TransactionStatus حذف شدند چون به زنجیرهٔ
 * واقعی متصل نبودند): این enum فقط به این دلیل زنده است که شش لایهٔ بالا
 * واقعاً از آن می‌خوانند — تست‌های Pkg7 همین wiring را پین می‌کنند؛ اگر
 * لایه‌ای از آن جدا شود، تست fail-loud می‌شود.
 *
 * دامنه‌های دیگر (خارج از F21-02 — مجموعه‌های عامدانهً متفاوت):
 *   - CreateSocialTaskRequest: youtube,instagram,twitter,telegram,aparat
 *     (پلتفرمِ هدفِ تسک تبلیغاتی — انتخابِ تبلیغ‌دهنده)
 *   - StoreInfluencerProfileRequest: instagram,telegram
 *   - AdSocialAdapter/AdsApiController: شامل facebook/other (targeting تبلیغ)
 *   - user_devices.platform: web/android/ios (پلتفرم دستگاه — مفهوم دیگر)
 *   این‌ها به این enum وصل نشدند تا تغییر رفتار محصول ندهند؛ در صورت
 *   تمایل مالک، مهاجرت‌شان گام بعدی است.
 */
enum SocialPlatform: string
{
    case Instagram = 'instagram';
    case Telegram  = 'telegram';
    case Youtube   = 'youtube';
    case Twitter   = 'twitter';
    case Tiktok    = 'tiktok';
    case Aparat    = 'aparat';
    case Linkedin  = 'linkedin';
    case Other     = 'other';

    /**
     * پلتفرم‌های قابل ثبت به‌عنوان حساب کاربر (UI + validator).
     * ترتیب = ترتیب نمایش درپ‌داون فرم ثبت حساب (قرارداد کنترلر سابق).
     *
     * @return list<self>
     */
    public static function registerable(): array
    {
        return [
            self::Instagram,
            self::Youtube,
            self::Telegram,
            self::Tiktok,
            self::Twitter,
        ];
    }

    /** @return list<string> مقادیر رشته‌ایِ پلتفرم‌های قابل ثبت */
    public static function registerableValues(): array
    {
        return array_map(static fn(self $c): string => $c->value, self::registerable());
    }

    /** رشتهٔ قاعدهٔ in: — عیناً قابل الحاق به 'required|in:' (مصرف‌کننده: StoreSocialAccountRequest) */
    public static function validationRule(): string
    {
        return implode(',', self::registerableValues());
    }

    /**
     * آپشن‌های درپ‌داون UI ثبت حساب: value => label فارسی.
     * کلیدها دقیقاً همان registerableValues هستند — این هم‌ارزی همان
     * نامتغیری‌ای است که بازگشت F21-02 را غیرممکن می‌کند: UI هرگز
     * پلتفرمی نمی‌دهد که validator نپذیرد.
     *
     * @return array<string, string>
     */
    public static function forSelect(): array
    {
        $out = [];
        foreach (self::registerable() as $case) {
            $out[$case->value] = $case->label();
        }
        return $out;
    }

    /** آیا این پلتفرم از فرم ثبت حساب قابل انتخاب است؟ */
    public function isRegisterable(): bool
    {
        return in_array($this, self::registerable(), true);
    }

    /** برچسب فارسی — منبع واحد نمایش (مدل SocialAccount + helper + view ادمین) */
    public function label(): string
    {
        return match ($this) {
            self::Instagram => 'اینستاگرام',
            self::Youtube   => 'یوتیوب',
            self::Telegram  => 'تلگرام',
            self::Tiktok    => 'تیک‌تاک',
            self::Twitter   => 'توییتر (X)',
            self::Aparat    => 'آپارات',
            self::Linkedin  => 'لینکدین',
            self::Other     => 'سایر',
        };
    }

    /**
     * حداقل تعداد پست برای قبولی کیفیت حساب — قرارداد سابق
     * SocialAccountService::getMinPosts (مقدار پیش‌فرضِ پلتفرم ناشناخته: ۱۰).
     */
    public function minPosts(): int
    {
        return match ($this) {
            self::Instagram => 10,
            self::Youtube   => 5,
            self::Telegram  => 0,
            self::Tiktok    => 5,
            self::Twitter   => 10,
            default         => 10,
        };
    }

    /**
     * حداقل تعداد فالوور برای قبولی کیفیت حساب — قرارداد سابق
     * SocialAccountService::getMinFollowers (مقدار پیش‌فرضِ پلتفرم ناشناخته: ۵۰).
     */
    public function minFollowers(): int
    {
        return match ($this) {
            self::Instagram => 50,
            self::Youtube   => 20,
            self::Telegram  => 0,
            self::Tiktok    => 30,
            self::Twitter   => 20,
            default         => 50,
        };
    }
}
