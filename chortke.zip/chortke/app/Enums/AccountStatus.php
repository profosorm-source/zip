<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * 🔒 FIX-M8-04 (راند ۱۶ — گزارش ماژول ۸): ماشین وضعیتِ حساب کاربری — منبع واحد.
 *
 * پیش از این فیکس، چهار تعریفِ ناسازگار از وضعیت‌ها وجود داشت:
 *   - enum ستون users.status:            active/inactive/suspended/locked/locked_2fa/banned/deleted
 *   - UserUpdateRequest (فرم ادمین):      active/inactive/suspended/banned
 *   - BaseAdminController::validateStatusTransition: نقشهٔ گذارِ بدون inactive و بدون
 *     کلیدِ locked/locked_2fa (یعنی «غیرفعال‌کردن» از فرم گزینه بود ولی همیشه رد
 *     می‌شد، و کاربرِ locked_2fa هیچ مسیر رهاییِ ادمینی نداشت)
 *   - User::updateAdminManagedFields:     همهٔ ۷ مقدار (خیلی باز)
 *
 * اکنون هر چهار لایه به همین مرجع متصل‌اند:
 *   - values():            کل قرارداد ذخیره‌سازی (model whitelist)
 *   - adminSettable():     وضعیت‌هایی که ادمین از فرم ویرایش «تعیین» می‌کند
 *                          (locked/locked_2fa سیستمی‌اند — ادمین آن‌ها را «ست»
 *                          نمی‌کند، اما می‌تواند «از» آن‌ها عبور کند؛ deleted
 *                          فقط از جریان حذف حساب ساخته می‌شود)
 *   - canTransition():     ماشین گذار — گذارِ خودبه‌خودی (from===to) امن است
 *                          (قرارداد FIX-X22: ذخیرهٔ سادهٔ فرم بدون تغییر status)
 *
 * طراحی نقشهٔ گذار:
 *   - هر وضعیتِ زنده (غیر deleted) می‌تواند به سه وضعیتِ مدیریتی
 *     (active/inactive/suspended/banned) برگردد؛ deleted ترمینال است و فقط
 *     جریان حذف حساب آن را می‌سازد و هیچ خروجی از آن مجاز نیست.
 *   - →locked / →locked_2fa در نقشهٔ ادمین نیست: این دو حالت فقط توسط
 *     سیستم (سقف تلاش ورود / کانال 2FA) اعمال می‌شوند.
 */
enum AccountStatus: string
{
    case Active     = 'active';
    case Inactive   = 'inactive';
    case Suspended  = 'suspended';
    case Locked     = 'locked';
    case Locked2Fa  = 'locked_2fa';
    case Banned     = 'banned';
    case Deleted    = 'deleted';

    /** @return list<string> کل مقادیر معتبرِ ستون users.status (قرارداد مدل) */
    public static function values(): array
    {
        return array_map(static fn(self $c): string => $c->value, self::cases());
    }

    /**
     * وضعیت‌هایی که ادمین از فرم ویرایش کاربر «تعیین» می‌کند.
     * (وضعیت سیستمیِ فعلی کاربر — locked/locked_2fa — جداگانه در فرم نمایش
     * داده می‌شود تا self-transition مجاز بماند و ادمین بتواند رها کند.)
     *
     * @return list<string>
     */
    public static function adminSettable(): array
    {
        return [self::Active->value, self::Inactive->value, self::Suspended->value, self::Banned->value];
    }

    /**
     * نقشهٔ گذارهای مجاز — منبع واحد BaseAdminController::validateStatusTransition.
     *
     * @return array<string, list<string>>
     */
    public static function allowedTransitions(): array
    {
        return [
            self::Active->value    => [self::Inactive->value, self::Suspended->value, self::Banned->value],
            self::Inactive->value  => [self::Active->value, self::Suspended->value, self::Banned->value],
            self::Suspended->value => [self::Active->value, self::Inactive->value, self::Banned->value],
            self::Banned->value    => [self::Active->value, self::Inactive->value],
            // رهایی از حالت‌های سیستمیِ قفل — مسیر مدیریتی که قبلاً بسته بود
            self::Locked->value    => [self::Active->value, self::Inactive->value, self::Suspended->value, self::Banned->value],
            self::Locked2Fa->value => [self::Active->value, self::Inactive->value, self::Suspended->value, self::Banned->value],
            // ترمینال — فقط جریان حذف حساب (با tombstone/ساگا) اینجا می‌رسد
            self::Deleted->value   => [],
        ];
    }

    /** گذار مجاز؟ (گذارِ خودبه‌خودی = no-op امن، همیشه مجاز — قرارداد FIX-X22) */
    public static function canTransition(string $from, string $to): bool
    {
        if ($from === $to) {
            return true;
        }
        return in_array($to, self::allowedTransitions()[$from] ?? [], true);
    }

    /** برچسب فارسی برای UI ادمین */
    public static function labels(): array
    {
        return [
            self::Active->value    => 'فعال',
            self::Inactive->value  => 'غیرفعال',
            self::Suspended->value => 'تعلیق',
            self::Locked->value    => 'قفل‌شده (سیستمی)',
            self::Locked2Fa->value => 'قفل ۲FA (سیستمی)',
            self::Banned->value    => 'مسدود',
            self::Deleted->value   => 'حذف‌شده',
        ];
    }
}
