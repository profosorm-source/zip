<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * 🔒 FIX-STATUS-ENUM (راند بهداشت — مصوب مالک: «مهاجرت سه‌گانهٔ Ads/StoryOrder/custom_task
 * به الگوی Enum») — مهاجرت ۱ از ۳:
 * وضعیت‌های تبلیغ (ads.status) — منبع واحد برچسب/رنگ در داشبورد یکپارچه تبلیغات
 * (AdminAdsController) و وظایف تبلیغاتی (AdTaskController).
 *
 * پیش از این فیکس، قرارداد «برچسب/کلاس وضعیت ads» فقط داخل مدل Ads با دو نقشهٔ
 * دستی تعریف می‌شد (statusLabels/statusClasses) و از الگوی Enum مصوب پروژه
 * (KycStatus پس از FIX-KYC-ENUM) عقب‌تر بود. اکنون:
 *   - cases():   کل قرارداد ذخیره‌سازی — ۷ مقدارِ همان نقشهٔ قبلی مدل (قرارداد بسته؛
 *                ads.status ستون VARCHAR است، ولی این مجموعه = قرارداد کد، نه schema).
 *   - label():   برچسب فارسی — عیناً همان متن‌های قبلی (بدون هیچ تغییر نمایشی).
 *   - badge():   کلاس CSS badge — عیناً همان کلاس‌های قبلی.
 *
 * لایهٔ نمایش: Ads::statusLabels()/statusClasses() عمومی و بدون تغییر امضا
 * باقی می‌مانند و به labelsMap()/badgesMap() همین enum delegate می‌کنند تا
 * هر ۴ نقطهٔ مصرف (AdminAdsController ×۲، AdTaskController ×۲) بدون تغییر
 * کار کنند.
 *
 * دامنه‌های عمداً خارج: submissionStatusLabels()/submissionStatusClasses()
 * (وضعیت‌های مشارکت تبلیغ — قرارداد جدا) و نقشه‌های تبلیغ‌های بنری (0037).
 */
enum AdsStatus: string
{
    case Draft         = 'draft';
    case PendingReview = 'pending_review';
    case Active        = 'active';
    case Paused        = 'paused';
    case Completed     = 'completed';
    case Rejected      = 'rejected';
    case Expired       = 'expired';

    /** برچسب فارسی — منبع واحد نمایش (عین نقشهٔ قبلی مدل). */
    public function label(): string
    {
        return match ($this) {
            self::Draft         => 'پیشنویس',
            self::PendingReview => 'در انتظار بررسی',
            self::Active        => 'فعال',
            self::Paused        => 'متوقف',
            self::Completed     => 'تکمیل‌شده',
            self::Rejected      => 'رد شده',
            self::Expired       => 'منقضی',
        };
    }

    /** کلاس CSS badge (عین نقشهٔ قبلی مدل). */
    public function badge(): string
    {
        return match ($this) {
            self::Draft         => 'badge-secondary',
            self::PendingReview => 'badge-warning',
            self::Active        => 'badge-success',
            self::Paused        => 'badge-info',
            self::Completed     => 'badge-primary',
            self::Rejected      => 'badge-danger',
            self::Expired       => 'badge-danger',
        };
    }

    /**
     * نقشهٔ value => label برای ویوهایی که حلقه می‌زنند (فیلتر دراپ‌داون و…).
     * ترتیب = همان ترتیب نقشهٔ قبلی مدل (قرارداد نمایشی پایدار).
     *
     * @return array<string, string>
     */
    public static function labelsMap(): array
    {
        $out = [];
        foreach ([self::Draft, self::PendingReview, self::Active, self::Paused, self::Completed, self::Rejected, self::Expired] as $case) {
            $out[$case->value] = $case->label();
        }
        return $out;
    }

    /** @return array<string, string> نقشهٔ value => کلاس badge */
    public static function badgesMap(): array
    {
        $out = [];
        foreach (self::cases() as $case) {
            $out[$case->value] = $case->badge();
        }
        return $out;
    }

    /**
     * resolve امن از رشتهٔ خام دیتابیس (NULL/خالی/ناشناخته → null).
     * لایهٔ ویو موظف است برای null فالبک نمایشی بدهد (الگوی social_platform_label).
     */
    public static function tryFromString(?string $status): ?self
    {
        if ($status === null || $status === '') {
            return null;
        }
        return self::tryFrom(strtolower($status));
    }
}
