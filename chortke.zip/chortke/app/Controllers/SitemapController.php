<?php

namespace App\Controllers;

use App\Services\SitemapService;
use App\Controllers\BaseController;

class SitemapController extends BaseController
{
    private SitemapService $sitemapService;
    
    public function __construct(SitemapService $sitemapService, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->sitemapService = $sitemapService;
    }
    
    /**
     * نمایش Sitemap
     */
    public function index(): void
    {
        // X39: هدر باید قبل از اولین echo با header() بومی ارسال شود؛
        // ست‌کردن روی Response->header() پس از echo نادیده گرفته می‌شود (text/html پیش‌فرض)
        if (!headers_sent()) {
            header('Content-Type: application/xml; charset=utf-8');
        }
        echo $this->sitemapService->getXml();
    }
}