<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Services\Analytics\AnalyticsQueryService;
use App\Services\BannerService;
use App\Services\InfluencerService;
use App\Models\LotteryRound;

class HomeController extends BaseController
{
    public function index()
    {
        // Resolve services from container
        $analyticsService = $this->resolveFromContainer(AnalyticsQueryService::class);
        $bannerService = $this->resolveFromContainer(BannerService::class);
        $influencerService = $this->resolveFromContainer(InfluencerService::class);
        $lotteryModel = $this->resolveFromContainer(LotteryRound::class);

        // 1. Live Stats
        $summary = $analyticsService->getDashboardSummary(['users', 'task', 'financial', 'lottery']);
        
        $stats = (object)[
            'users'        => $summary['users']['total'] ?? 0,
            'tasks'        => $summary['tasks']['total_completed'] ?? 0,
            'transactions' => $summary['financials']['total_count'] ?? 0,
            'winners'      => $summary['lotteries']['total_winners'] ?? 0,
        ];

        // 2. Banners (Fetching active banners for 'home' placement)
        $bannerData = $bannerService->getActiveBanners('home');
        $banners = $bannerData['banners'] ?? [];

        // 3. Influencers (Top 10 verified influencers)
        $rawInfluencers = $influencerService->listVerifiedProfiles([], 'priority', 10);
        $influencers = array_map(function($inf) {
            return (object)[
                'id'                 => $inf->id,
                'instagram_username' => $inf->username,
                'follower_count'     => $inf->follower_count,
                'story_price'        => $inf->story_price_24h,
                'avatar'             => $inf->profile_image,
            ];
        }, $rawInfluencers);

        // 4. Lottery Winners (Last 5 winners)
        $rawWinners = $lotteryModel->getCompletedRounds(5);
        $winners = array_map(function($w) {
            return (object)[
                'id'           => $w->id,
                'full_name'    => $w->winner_name ?? 'کاربر',
                'prize_amount' => $w->prize_amount,
                'created_at'   => $w->end_date ?? date('Y-m-d'),
            ];
        }, $rawWinners);

        // 5. FAQs, Earning Cards, Why Cards (Kept as content)
        $isLoggedIn = auth() !== null;
        
        $faqs = [
            [
                'question' => 'چرتکه چیست؟',
                'answer'   => 'چرتکه یک پلتفرم حرفه‌ای کسب درآمد آنلاین است. با انجام تسک‌های شبکه‌های اجتماعی، سرمایه‌گذاری، قرعه‌کشی روزانه، تولید محتوا و معرفی دوستان درآمد واقعی کسب کنید.',
            ],
            [
                'question' => 'چگونه ثبت‌نام کنم؟',
                'answer'   => 'با کلیک روی دکمه «ثبت‌نام» و وارد کردن نام، ایمیل، شماره موبایل و رمز عبور در کمتر از ۳۰ ثانیه عضو شوید. ثبت‌نام کاملاً رایگان است.',
            ],
            [
                'question' => 'حداقل مبلغ برداشت چقدر است؟',
                'answer'   => 'حداقل مبلغ برداشت بر اساس تنظیمات فعلی سایت تعیین می‌شود. برای اطلاع دقیق از مبلغ به بخش کیف پول در پنل کاربری خود مراجعه کنید.',
            ],
            [
                'question' => 'آیا سرمایه‌گذاری ریسک دارد؟',
                'answer'   => 'بله، سرمایه‌گذاری همواره ریسک سود و ضرر دارد. لطفاً قبل از سرمایه‌گذاری هشدارهای ریسک را به دقت مطالعه کنید. سیستم هیچ تضمینی برای سود نمی‌دهد.',
            ],
            [
                'question' => 'سیستم قرعه‌کشی چگونه کار می‌کند؟',
                'answer'   => 'هر روز ۳ عدد تصادفی تولید می‌شود و شما یکی را انتخاب می‌کنید. سیستم وزن‌دهی خودکار و عادلانه برنده نهایی را انتخاب می‌کند. هیچ کاربری حذف نمی‌شود و امید همه تا آخر حفظ می‌شود.',
            ],
            [
                'question' => 'چگونه احراز هویت انجام دهم؟',
                'answer'   => 'در بخش پروفایل، تصویر کارت ملی و سلفی با دست‌نوشته آپلود کنید. پس از بررسی توسط تیم ما، حساب شما تأیید خواهد شد و دسترسی کامل خواهید داشت.',
            ],
            [
                'question' => 'آیا می‌توانم با تتر (USDT) کار کنم؟',
                'answer'   => 'بله. بخش سرمایه‌گذاری بر اساس تتر عمل می‌کند. همچنین اگر سایت در حالت تتری فعال باشد، تمام بخش‌ها با تتر کار خواهند کرد.',
            ],
        ];

        $earningCards = [
            [
                'gradient' => 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                'icon'     => 'task_alt',
                'title'    => 'انجام تسک‌ها',
                'desc'     => 'تسک‌های اجتماعی رو انجام بدید و جوایز کسب کنید',
                'features' => ['تسک‌های متنوع', 'پرداخت سریع', 'بدون محدودیت'],
                'btn'      => $isLoggedIn ? 'شروع کنید' : 'ثبت‌نام کنید',
            ],
            [
                'gradient' => 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
                'icon'     => 'trending_up',
                'title'    => 'سرمایه‌گذاری',
                'desc'     => 'درآمد پسیو کسب کنید و سرمایه خود را رشد دهید',
                'features' => ['بازده منصفانه', 'ریسک کم', 'تضمین سود'],
                'btn'      => $isLoggedIn ? 'سرمایه‌گذاری کنید' : 'ثبت‌نام کنید',
            ],
            [
                'gradient' => 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
                'icon'     => 'card_giftcard',
                'title'    => 'قرعه‌کشی روزانه',
                'desc'     => 'هر روز شانس برنده شدن جایزه عظیم دارید',
                'features' => ['برندگان متعدد', 'جوایز بزرگ', 'حق‌الزحمه نیست'],
                'btn'      => $isLoggedIn ? 'شرکت کنید' : 'ثبت‌نام کنید',
            ],
            [
                'gradient' => 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
                'icon'     => 'share',
                'title'    => 'معرفی دوستان',
                'desc'     => 'هرکی رو دعوت کنید و کمیسیون درآمد کنید',
                'features' => ['کمیسیون بالا', 'بدون سقف', 'درآمد مادام‌العمر'],
                'btn'      => $isLoggedIn ? 'دعوت کنید' : 'ثبت‌نام کنید',
            ],
        ];

        $whyCards = [
            ['icon' => 'verified_user', 'color' => '#2196f3', 'title' => 'معتبریت', 'desc' => 'سایت ثبت‌شده در دولت، مجوزهای الزامی و تایید شده'],
            ['icon' => 'security', 'color' => '#4caf50', 'title' => 'امنیت بالا', 'desc' => 'رمزنگاری SSL، احراز هویت دو‌مرحله‌ای و حفاظت داده'],
            ['icon' => 'speed', 'color' => '#ff9800', 'title' => 'سرعت بالا', 'desc' => 'سرورهای نمایندگی جهانی و CDN سریع'],
            ['icon' => 'shield', 'color' => '#f44336', 'title' => 'ضد تقلب هوشمند', 'desc' => 'تحلیل رفتاری، اثرانگشت دستگاه، نظارت چندلایه'],
            ['icon' => 'headset_mic', 'color' => '#9c27b0', 'title' => 'پشتیبانی ۲۴/۷', 'desc' => 'تیم پشتیبانی از طریق تیکت، چت و شبکه‌های اجتماعی'],
            ['icon' => 'diversity_3', 'color' => '#009688', 'title' => 'جامعه بزرگ', 'desc' => 'هزاران کاربر فعال و درآمدزا هر روز'],
        ];

        return view('welcome', [
            'stats'        => $stats,
            'banners'      => $banners,
            'influencers'  => $influencers,
            'winners'      => $winners,
            'faqs'         => $faqs,
            'earningCards' => $earningCards,
            'whyCards'     => $whyCards,
        ]);
    }
}
