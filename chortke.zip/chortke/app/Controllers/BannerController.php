<?php

namespace App\Controllers;

use App\Services\BannerService;
use App\Controllers\BaseController;

class BannerController extends BaseController
{
    private \App\Services\BannerService $bannerService;
    public function __construct(
        \App\Services\BannerService $bannerService
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->bannerService = $bannerService;
    }

    /**
     * ثبت کلیک بنر
     *
     * R32 (P0 ممیزی R30): احراز هویت الزامی شد. قبلاً مسیرهای /banner/click/{id}
     * و دوقلوهای /api/banner-click عمومی بودند و باگ نرخ‌سنجی ۳۰/دقیقه + dedupe
     * اتمیک per-(banner,ip) هنوز امکان تخلیهٔ بودجهٔ تبلیغ‌دهنده را با IPهای
     * متعدد می‌داد. اکنون کلیک فقط برای کاربر واردشده ثبت/تسویه می‌شود؛
     * مهمان: درخواست /api/* → 401 JSON (الگوی CORE-037)، مسیر GET → ریدایرکت
     * به ورود. عمداً در کنترلر گیت شده تا هر سه واریانت مسیر پوشش داده شود
     * (AuthMiddleware روی /api/* طبق CORE-037 مجاز نیست).
     */
    public function click(): mixed
    {
        if (!auth()) {
            if (str_starts_with($this->request->uri(), '/api/')) {
                return $this->jsonError('برای ثبت کلیک بنر ابتدا وارد حساب خود شوید.', [], 401);
            }
            redirect(url('/login'));
        }

        $id = $this->request->int('id');

        $service = $this->bannerService;
        $result = $service->trackClick($id);

        if ($result['success'] && !empty($result['redirect'])) {
            $url = str_value($result['redirect'] ?? '');
            
            // Extra layer of validation inside Controller
            $parsed = parse_url($url);
            $host = strtolower($parsed['host'] ?? '');
            
            $allowedDomains = ['chortke.com', 'trusted-partner.com', 'example.com'];
            $currentHost = strtolower((string)parse_url($this->urlGenerator->origin(), PHP_URL_HOST));
            if ($currentHost !== '') {
                $allowedDomains[] = $currentHost;
            }
            
            $isAllowedHost = false;
            foreach ($allowedDomains as $allowed) {
                if ($host === $allowed || str_ends_with($host, '.' . $allowed)) {
                    $isAllowedHost = true;
                    break;
                }
            }
            
            if ($isAllowedHost && filter_var($url, FILTER_VALIDATE_URL) && preg_match('/^https?:\/\//i', $url)) {
                redirect($url);
            }
        }

        redirect(url('/')); 
    }
}