<?php

namespace App\Controllers;

use App\Services\BannerService;
use App\Controllers\BaseController;

class BannerController extends BaseController
{
    private \App\Services\BannerService $bannerService;
    public function __construct(
        \App\Services\BannerService $bannerService
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->bannerService = $bannerService;
    }

    /**
     * ثبت کلیک بنر
     *
     * R32 (P0 ممیزی R30): احراز هویت الزامی شد. قبلاً مسیرهای /banner/click/{id}
     * و دوقلوهای /api/banner-click عمومی بودند و باگ نرخ‌سنجی ۳۰/دقیقه + dedupe
     * اتمیک per-(banner,ip) هنوز امکان تخلیهٔ بودجهٔ تبلیغ‌دهنده را با IPهای
     * متعدد می‌داد. اکنون کلیک فقط برای کاربر واردشده ثبت/تسویه می‌شود.
     *
     * FIX-MODULE2-H1: تنها مسیر مجاز POST /banner/click/{id} است (خارج از
     * معافیت CSRFِ /api/* — توکن X-CSRF-Token از meta/layouts توسط middleware
     * سراسری verify می‌شود) و واریانت‌های GET حذف شده‌اند (GET هرگز state مالی
     * تغییر نمی‌دهد). گیت مهمان AJAX-آگاه است: fetch با X-Requested-With
     * → 401 JSON؛ ناوبری مرورگری معمولی → ریدایرکت ورود.
     */
    public function click(): void
    {
        if (!auth()) {
            if ($this->request->isAjax()) {
                $this->jsonError('برای ثبت کلیک بنر ابتدا وارد حساب خود شوید.', [], 401);
                return;
            }
            redirect(url('/login'));
        }

        $id = $this->request->int('id');

        $service = $this->bannerService;
        $result = $service->trackClick($id);

        if ($result['success'] && !empty($result['redirect'])) {
            $url = str_value($result['redirect'] ?? '');
            
            // Extra layer of validation inside Controller
            $parsed = parse_url($url);
            $host = strtolower($parsed['host'] ?? '');
            
            $allowedDomains = ['chortke.com', 'trusted-partner.com', 'example.com'];
            $currentHost = strtolower((string)parse_url($this->urlGenerator->origin(), PHP_URL_HOST));
            if ($currentHost !== '') {
                $allowedDomains[] = $currentHost;
            }
            
            $isAllowedHost = false;
            foreach ($allowedDomains as $allowed) {
                if ($host === $allowed || str_ends_with($host, '.' . $allowed)) {
                    $isAllowedHost = true;
                    break;
                }
            }
            
            if ($isAllowedHost && filter_var($url, FILTER_VALIDATE_URL) && preg_match('/^https?:\/\//i', $url)) {
                redirect($url);
            }
        }

        redirect(url('/')); 
    }
}
