<?php

namespace App\Controllers\Api;

use App\Contracts\WalletServiceInterface;

/**
 * API\WalletController - کیف‌پول
 *
 * GET  /api/v1/wallet              → موجودی
 * GET  /api/v1/wallet/transactions → تاریخچه تراکنش‌ها
 */
class WalletController extends BaseApiController
{
    private WalletServiceInterface $walletService;
    private \App\Services\BankCardService $bankCardService;
    private \App\Services\Withdrawal\WithdrawalUserService $withdrawalUserService;
    private \App\Services\ManualDepositService $manualDepositService;
    private \App\Services\CryptoDeposit\CryptoDepositService $cryptoDepositService;
    // 🧹 DI-CLEANUP (2026-08-24): وابستگی‌هایی که قبلاً با container->make در بدنه‌ی
    // متدها گرفته می‌شدند، اکنون با تزریق سازنده (autowire توسط Router) تأمین می‌شوند.
    private \App\Services\Settings\AppSettings $appSettings;
    private \App\Services\InvestmentService $invService;
    private \App\Services\Shared\ReferralService $refService;
    private \App\Services\Lottery\LotteryService $lotteryService;

    public function __construct(
        WalletServiceInterface $walletService,
        \App\Services\BankCardService $bankCardService,
        \App\Services\Withdrawal\WithdrawalUserService $withdrawalUserService,
        \App\Services\ManualDepositService $manualDepositService,
        \App\Services\CryptoDeposit\CryptoDepositService $cryptoDepositService,
        \App\Services\Settings\AppSettings $appSettings,
        \App\Services\InvestmentService $invService,
        \App\Services\Shared\ReferralService $refService,
        \App\Services\Lottery\LotteryService $lotteryService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->walletService = $walletService;
        $this->bankCardService = $bankCardService;
        $this->withdrawalUserService = $withdrawalUserService;
        $this->manualDepositService = $manualDepositService;
        $this->cryptoDepositService = $cryptoDepositService;
        $this->appSettings = $appSettings;
        $this->invService = $invService;
        $this->refService = $refService;
        $this->lotteryService = $lotteryService;
    }

    /** موجودی کیف‌پول */
    public function balance(): void
    {
        $userId = (int)$this->userId();
        $balances = $this->walletService->getWalletBalances($userId);

        if (empty($balances)) {
            $this->error('کیف‌پول یافت نشد', 404, 'WALLET_NOT_FOUND');
        }

        $this->success($balances);
    }

    /** تاریخچه تراکنش‌ها */
    public function transactions(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);

        $filters = [];
        if ($type = $this->request->get('type')) {
            $filters['type'] = $type;
        }
        if ($status = $this->request->get('status')) {
            $filters['status'] = $status;
        }
        if ($currency = $this->request->get('currency')) {
            $filters['currency'] = $currency;
        }

        $items = $this->walletService->getUserTransactions($userId, $perPage, $offset, $filters);
        $total = $this->walletService->countUserTransactions($userId, $filters);

        // پاکسازی داده‌های حساس
        $items = array_map(fn($tx) => [
            'id'          => $tx->id,
            'type'        => $tx->type,
            'amount'      => (string)$tx->amount,
            'currency'    => $tx->currency,
            'status'      => $tx->status,
            'description' => $tx->description,
            'created_at'  => $tx->created_at,
        ], $items);

        $this->paginated($items, $total, $page, $perPage);
    }

    /** لیست کارت‌های بانکی */
    public function bankCardsList(): void
    {
        $userId = (int)$this->userId();
        // P1-2 FIX (S33 audit): API response previously carried the FULL decrypted
        // PAN. JSON consumers get the masked form (last 4 digits only).
        $cards = $this->bankCardService->listForUserMasked($userId);
        $this->success($cards);
    }

    /** افزودن کارت بانکی */
    public function bankCardsStore(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $result = $this->bankCardService->create($userId, $data);
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'خطا در ثبت کارت'), 422);
        }
        $this->success($result, 'کارت بانکی با موفقیت ثبت شد', 201);
    }

    /** حذف کارت بانکی */
    public function bankCardsDelete(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $result = $this->bankCardService->softDeleteByUser($userId, $id);
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'خطا در حذف کارت'), 400);
        }
        $this->success(null, 'کارت بانکی حذف شد');
    }

    /** انتخاب کارت اصلی */
    public function bankCardsSetPrimary(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $result = $this->bankCardService->setPrimary($userId, $id);
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'خطا در انتخاب کارت اصلی'), 400);
        }
        $this->success(null, 'کارت بانکی به عنوان کارت اصلی انتخاب شد');
    }

    /** ثبت درخواست برداشت وجه */
    public function withdrawSubmit(): void
    {
        $userId = (int)$this->userId();
        $payload = $this->request->body();
        try {
            $result = $this->withdrawalUserService->requestFromUser($userId, $payload);
            if (!empty($result['success'])) {
                $this->success($result, 'درخواست برداشت با موفقیت ثبت شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت درخواست برداشت'), 400);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (Task 18-N — P2 #21): پیام خطای دامنه (قوانین بیزینسی) کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.withdraw_submit.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** سقف و قوانین برداشت */
    public function withdrawLimits(): void
    {
        // 🛡️ FIX #8b (P2): قبلاً اعداد هاردکد بودند و با گاردِ واقعی
        // (guardCanCreateWithdrawal / calculateFee که از AppSettings می‌خوانند)
        // هم‌خوانی نداشتند — حتی fee_percentage=1.0 تبلیغ می‌شد در حالی که
        // پیش‌فرضِ واقعی کارمزد 0 است. اکنون همان منبعِ حقیقت (تنظیمات) خوانده
        // می‌شود؛ کلیدها همان کنوانسیون تنظیماتِ سقف/کارمزد برداشت‌اند.
        $s = $this->appSettings;
        $limits = [
            'min_irt'  => $s->getFloat('min_withdrawal_irt', 50000),
            'max_irt'  => $s->getFloat('withdrawal_daily_limit_irt', 50000000),
            'min_usdt' => $s->getFloat('min_withdrawal_usdt', 10),
            'max_usdt' => $s->getFloat('withdrawal_daily_limit_usdt', 5000),
            'fee_percentage_irt'  => $s->getFloat('withdrawal_fee_percent_irt', 0),
            'fee_percentage_usdt' => $s->getFloat('withdrawal_fee_percent_usdt', 0),
            'fee_fixed_irt'       => $s->getFloat('withdrawal_fee_fixed_irt', 0),
            'fee_fixed_usdt'      => $s->getFloat('withdrawal_fee_fixed_usdt', 0),
        ];
        $this->success($limits);
    }

    /** ثبت فیش واریز دستی */
    public function manualDepositStore(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        // C03-باگ۱: receipt_path هرگز از کلاینت پذیرفته نمی‌شود؛ مسیر رسید فقط
        // خروجیِ UploadService است (سرویس هم الگوی path را اعتبارسنجی می‌کند).
        unset($data['receipt_path'], $data['receipt_image']);
        $result = $this->manualDepositService->create($userId, $data, null);
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'خطا در ثبت واریز دستی'), 422);
        }
        $this->success($result, 'واریز دستی با موفقیت ثبت شد و در انتظار تایید است', 201);
    }

    /** ثبت نیت واریز رمزارز */
    public function cryptoDepositCreateIntent(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $network = str_value($data['network'] ?? 'TRC20');
        $amount = is_numeric($data['amount'] ?? null) ? (string)$data['amount'] : '0';
        $result = $this->cryptoDepositService->createIntent($userId, $network, $amount, $this->request->ip(), $this->request->userAgent());
        if (!empty($result['success'])) {
            $this->success($result, 'درخواست واریز رمزارز ایجاد شد', 201);
        }
        $this->error(str_value($result['message'] ?? 'خطا در ایجاد درخواست واریز رمزارز'), 422);
    }

    /** آدرس ولت‌های سایت */
    public function cryptoDepositWallets(): void
    {
        $appSettings = $this->appSettings;
        $wallets = [
            'BNB20' => $appSettings->get('site_usdt_bnb20_address', ''),
            'TRC20' => $appSettings->get('site_usdt_trc20_address', ''),
            'TON'   => $appSettings->get('site_usdt_ton_address', ''),
            'SOL'   => $appSettings->get('site_usdt_sol_address', ''),
        ];
        $this->success($wallets);
    }

    /** لیست آمار سرمایه‌گذاری */
    public function investmentList(): void
    {
        $userId = (int)$this->userId();
        /** @var \App\Services\Investment\InvestmentQueryService $queryService */
        $queryService = app(\App\Services\Investment\InvestmentQueryService::class);
        $result = $queryService->searchInvestments('', ['user_id' => $userId], 100, 0);
        $this->success($result);
    }

    /** ایجاد سرمایه‌گذاری جدید */
    public function investmentStore(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $invService = $this->invService;
        try {
            $result = $invService->createInvestment($userId, $data);
            if (!empty($result['success'])) {
                $this->success($result, 'سرمایه‌گذاری با موفقیت انجام شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت سرمایه‌گذاری'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.investment_store.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** درخواست برداشت سود سرمایه‌گذاری */
    public function investmentWithdraw(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $invService = $this->invService;
        try {
            $result = $invService->requestWithdrawal($userId, $data);
            if (!empty($result['success'])) {
                $this->success($result, 'درخواست برداشت سود ثبت شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در درخواست برداشت سود'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.investment_withdraw.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** آمار زیرمجموعه‌گیری (Referral) */
    public function referralStats(): void
    {
        $userId = (int)$this->userId();
        $refService = $this->refService;
        $stats = $refService->getReferrerStats($userId);
        $tier = $refService->getCurrentTier($userId);
        $this->success(['stats' => $stats, 'tier' => $tier]);
    }

    /** لیست زیرمجموعه‌ها */
    public function referralUsers(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);
        $refService = $this->refService;
        $users = $refService->getReferredUsers($userId, $perPage, $offset);
        $total = $refService->countReferredUsers($userId);
        $this->paginated($users, $total, $page, $perPage);
    }

    /** لیست دوره‌های قرعه‌کشی */
    public function lotteryList(): void
    {
        [$page, $perPage, $offset] = $this->paginationParams(20);
        $lotteryService = $this->lotteryService;
        $rounds = $lotteryService->listRounds(['status' => 'active'], $perPage, $offset);
        $this->paginated(is_array($rounds['items'] ?? null) ? $rounds['items'] : [], int_value($rounds['total'] ?? 0), $page, $perPage);
    }

    /** شرکت در قرعه‌کشی */
    public function lotteryJoin(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $roundId = int_value($data['round_id'] ?? 0);
        $lotteryService = $this->lotteryService;
        try {
            $result = $lotteryService->participate($userId, $roundId);
            if (!empty($result['success'])) {
                $this->success($result, 'ثبت‌نام در قرعه‌کشی با موفقیت انجام شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت‌نام قرعه‌کشی'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند (هم‌الگوی سه catch هم‌فایل)
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.lottery_join.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }
}
