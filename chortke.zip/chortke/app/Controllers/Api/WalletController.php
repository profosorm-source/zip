<?php

namespace App\Controllers\Api;

use App\Contracts\WalletServiceInterface;

/**
 * API\WalletController - کیف‌پول
 *
 * GET  /api/v1/wallet              → موجودی
 * GET  /api/v1/wallet/transactions → تاریخچه تراکنش‌ها
 */
class WalletController extends BaseApiController
{
    private WalletServiceInterface $walletService;
    private \App\Services\BankCardService $bankCardService;
    private \App\Services\Withdrawal\WithdrawalUserService $withdrawalUserService;
    private \App\Services\ManualDepositService $manualDepositService;
    private \App\Services\CryptoDeposit\CryptoDepositService $cryptoDepositService;
    // 🧹 DI-CLEANUP (2026-08-24): وابستگی‌هایی که قبلاً با container->make در بدنه‌ی
    // متدها گرفته می‌شدند، اکنون با تزریق سازنده (autowire توسط Router) تأمین می‌شوند.
    private \App\Services\Settings\AppSettings $appSettings;
    private \App\Services\InvestmentService $invService;
    private \App\Services\Shared\ReferralService $refService;
    private \App\Services\Lottery\LotteryService $lotteryService;

    public function __construct(
        WalletServiceInterface $walletService,
        \App\Services\BankCardService $bankCardService,
        \App\Services\Withdrawal\WithdrawalUserService $withdrawalUserService,
        \App\Services\ManualDepositService $manualDepositService,
        \App\Services\CryptoDeposit\CryptoDepositService $cryptoDepositService,
        \App\Services\Settings\AppSettings $appSettings,
        \App\Services\InvestmentService $invService,
        \App\Services\Shared\ReferralService $refService,
        \App\Services\Lottery\LotteryService $lotteryService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->walletService = $walletService;
        $this->bankCardService = $bankCardService;
        $this->withdrawalUserService = $withdrawalUserService;
        $this->manualDepositService = $manualDepositService;
        $this->cryptoDepositService = $cryptoDepositService;
        $this->appSettings = $appSettings;
        $this->invService = $invService;
        $this->refService = $refService;
        $this->lotteryService = $lotteryService;
    }

    /** موجودی کیف‌پول */
    public function balance(): void
    {
        $userId = (int)$this->userId();
        $balances = $this->walletService->getWalletBalances($userId);

        if (empty($balances)) {
            $this->error('کیف‌پول یافت نشد', 404, 'WALLET_NOT_FOUND');
        }

        $this->success($balances);
    }

    /** تاریخچه تراکنش‌ها */
    public function transactions(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);

        $filters = [];
        if ($type = $this->request->get('type')) {
            $filters['type'] = $type;
        }
        if ($status = $this->request->get('status')) {
            $filters['status'] = $status;
        }
        if ($currency = $this->request->get('currency')) {
            $filters['currency'] = $currency;
        }

        $items = $this->walletService->getUserTransactions($userId, $perPage, $offset, $filters);
        $total = $this->walletService->countUserTransactions($userId, $filters);

        // پاکسازی داده‌های حساس
        $items = array_map(fn($tx) => [
            'id'          => $tx->id,
            'type'        => $tx->type,
            'amount'      => (string)$tx->amount,
            'currency'    => $tx->currency,
            'status'      => $tx->status,
            'description' => $tx->description,
            'created_at'  => $tx->created_at,
        ], $items);

        $this->paginated($items, $total, $page, $perPage);
    }

    /** لیست کارت‌های بانکی */
    public function bankCardsList(): void
    {
        $userId = (int)$this->userId();
        // P1-2 FIX (S33 audit): API response previously carried the FULL decrypted
        // PAN. JSON consumers get the masked form (last 4 digits only).
        $cards = $this->bankCardService->listForUserMasked($userId);
        $this->success($cards);
    }

    /** افزودن کارت بانکی */
    public function bankCardsStore(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $result = $this->bankCardService->create($userId, $data);
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'خطا در ثبت کارت'), 422);
        }
        $this->success($result, 'کارت بانکی با موفقیت ثبت شد', 201);
    }

    /** حذف کارت بانکی */
    public function bankCardsDelete(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $result = $this->bankCardService->softDeleteByUser($userId, $id);
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'خطا در حذف کارت'), 400);
        }
        $this->success(null, 'کارت بانکی حذف شد');
    }

    /** انتخاب کارت اصلی */
    public function bankCardsSetPrimary(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $result = $this->bankCardService->setPrimary($userId, $id);
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'خطا در انتخاب کارت اصلی'), 400);
        }
        $this->success(null, 'کارت بانکی به عنوان کارت اصلی انتخاب شد');
    }

    /** ثبت درخواست برداشت وجه */
    public function withdrawSubmit(): void
    {
        $userId = (int)$this->userId();
        $payload = $this->request->body();
        try {
            $result = $this->withdrawalUserService->requestFromUser($userId, $payload);
            if (!empty($result['success'])) {
                $this->success($result, 'درخواست برداشت با موفقیت ثبت شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت درخواست برداشت'), 400);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (Task 18-N — P2 #21): پیام خطای دامنه (قوانین بیزینسی) کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.withdraw_submit.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** سقف و قوانین برداشت */
    public function withdrawLimits(): void
    {
        // 🛡️ FIX #8b (P2): قبلاً اعداد هاردکد بودند و با گاردِ واقعی
        // (guardCanCreateWithdrawal / calculateFee که از AppSettings می‌خوانند)
        // هم‌خوانی نداشتند — حتی fee_percentage=1.0 تبلیغ می‌شد در حالی که
        // پیش‌فرضِ واقعی کارمزد 0 است. اکنون همان منبعِ حقیقت (تنظیمات) خوانده
        // می‌شود؛ کلیدها همان کنوانسیون تنظیماتِ سقف/کارمزد برداشت‌اند.
        $s = $this->appSettings;
        // FIX-M12-08 (گزارش ماژول ۱۲): مقادیر پولی به‌صورت decimal-string قراردادی
        // برمی‌گردند — قبلاً getFloat بود و زنجیرهٔ settings→PHP float→JSON دقت را
        // می‌شکست (قرارداد wallet صراحتاً float برای مبالغ را ممنوع کرده است).
        // درصدها هم به‌عنوان رشتهٔ دهدهی جدا از مبالغ منتشر می‌شوند + متادیتای scale.
        $limits = [
            'min_irt'  => str_value($s->get('min_withdrawal_irt', '50000')),
            'max_irt'  => str_value($s->get('withdrawal_daily_limit_irt', '50000000')),
            'min_usdt' => str_value($s->get('min_withdrawal_usdt', '10')),
            'max_usdt' => str_value($s->get('withdrawal_daily_limit_usdt', '5000')),
            'fee_percentage_irt'  => str_value($s->get('withdrawal_fee_percent_irt', '0')),
            'fee_percentage_usdt' => str_value($s->get('withdrawal_fee_percent_usdt', '0')),
            'fee_fixed_irt'       => str_value($s->get('withdrawal_fee_fixed_irt', '0')),
            'fee_fixed_usdt'      => str_value($s->get('withdrawal_fee_fixed_usdt', '0')),
            'decimal_scale'       => ['irt' => 4, 'usdt' => 8],
            'value_type'          => 'decimal_string',
        ];
        $this->success($limits);
    }

    /** ثبت فیش واریز دستی */
    public function manualDepositStore(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        // C03-باگ۱: receipt_path هرگز از کلاینت پذیرفته نمی‌شود؛ مسیر رسید فقط
        // خروجیِ UploadService است (سرویس هم الگوی path را اعتبارسنجی می‌کند).
        unset($data['receipt_path'], $data['receipt_image']);
        $result = $this->manualDepositService->create($userId, $data, null);
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'خطا در ثبت واریز دستی'), 422);
        }
        $this->success($result, 'واریز دستی با موفقیت ثبت شد و در انتظار تایید است', 201);
    }

    /** ثبت نیت واریز رمزارز */
    public function cryptoDepositCreateIntent(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $network = str_value($data['network'] ?? 'TRC20');
        // FIX-M12-07 (گزارش ماژول ۱۲): گارماری کانونی دهدهی در مرز درخواست —
        // قبلاً is_numeric بود و رشته‌های علمی ("1e2") / float تا BCMath/Money
        // می‌رفتند و خطای کنترل‌نشده می‌ساختند. اکنون فقط decimal-string با scale
        // حداکثر ۸ (قرارداد USDT) از مرز عبور می‌کند؛ رد کنترل‌شدهٔ 422 بدون side-effect.
        $amountRaw = $data['amount'] ?? null;
        $amount = is_scalar($amountRaw) ? trim((string)$amountRaw) : '';
        if ($amount === '' || !preg_match('/^\d{1,20}(\.\d{1,8})?$/', $amount) || bccomp($amount, '0', 8) <= 0) {
            $this->error('مبلغ باید رشتهٔ دهدهی مثبت با حداکثر ۸ رقم اعشار باشد (نمونه: 10.00000000)', 422, 'INVALID_CRYPTO_AMOUNT');
            return;
        }
        $result = $this->cryptoDepositService->createIntent($userId, $network, $amount, $this->request->ip(), $this->request->userAgent());
        if (!empty($result['success'])) {
            $this->success($result, 'درخواست واریز رمزارز ایجاد شد', 201);
        }
        $this->error(str_value($result['message'] ?? 'خطا در ایجاد درخواست واریز رمزارز'), 422);
    }

    /** آدرس ولت‌های سایت */
    public function cryptoDepositWallets(): void
    {
        $appSettings = $this->appSettings;
        $wallets = [
            'BNB20' => $appSettings->get('site_usdt_bnb20_address', ''),
            'TRC20' => $appSettings->get('site_usdt_trc20_address', ''),
            'TON'   => $appSettings->get('site_usdt_ton_address', ''),
            'SOL'   => $appSettings->get('site_usdt_sol_address', ''),
        ];
        $this->success($wallets);
    }

    /** لیست آمار سرمایه‌گذاری */
    public function investmentList(): void
    {
        $userId = (int)$this->userId();
        /** @var \App\Services\Investment\InvestmentQueryService $queryService */
        $queryService = app(\App\Services\Investment\InvestmentQueryService::class);
        $result = $queryService->searchInvestments('', ['user_id' => $userId], 100, 0);
        $this->success($result);
    }

    /** ایجاد سرمایه‌گذاری جدید */
    public function investmentStore(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $invService = $this->invService;
        try {
            $result = $invService->createInvestment($userId, $data);
            if (!empty($result['success'])) {
                $this->success($result, 'سرمایه‌گذاری با موفقیت انجام شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت سرمایه‌گذاری'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.investment_store.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** درخواست برداشت سود سرمایه‌گذاری */
    public function investmentWithdraw(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $invService = $this->invService;
        try {
            $result = $invService->requestWithdrawal($userId, $data);
            if (!empty($result['success'])) {
                $this->success($result, 'درخواست برداشت سود ثبت شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در درخواست برداشت سود'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.investment_withdraw.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /**
     * 📱 FIX-REVGEN-REAPLY (بازکاربرد REVGEN — ۲۰۲۶-۱۱-۰۳):
     * تاریخچهٔ سود/زیان سرمایه‌گذاری — پنل وب profit-history داشت ولی API نه؛
     * کاربر اپ نمی‌توانست عملکرد سرمایه‌گذاری‌اش را ببیند.
     *
     * GET /api/v1/wallet/investments/profit-history — اسکوپ wallet.read
     * (هم‌گروه investmentList).
     */
    public function investmentProfitHistory(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);

        /** @var \App\Models\InvestmentProfit $profitModel */
        $profitModel = app(\App\Models\InvestmentProfit::class);
        $rows = $profitModel->getByUser($userId, $perPage, $offset);
        $total = $profitModel->countByUser($userId);

        $items = [];
        foreach ((array)$rows as $p) {
            if (!is_object($p)) {
                continue;
            }
            $items[] = [
                'id'               => int_value($p->id ?? 0),
                'investment_id'    => int_value($p->investment_id ?? 0),
                'investment_amount' => float_value($p->investment_amount ?? 0),
                'profit_type'      => str_value($p->profit_type ?? ''),
                'amount'           => float_value($p->amount ?? 0),
                'net_amount'       => ($p->net_amount ?? null) !== null ? float_value($p->net_amount) : null,
                'currency'         => str_value($p->currency ?? 'usdt'),
                'status'           => str_value($p->status ?? ''),
                'period_date'      => ($p->period_date ?? null) !== null ? str_value($p->period_date) : null,
                'created_at'       => str_value($p->created_at ?? ''),
            ];
        }

        $this->paginated($items, $total, $page, $perPage);
    }

    /** آمار زیرمجموعه‌گیری (Referral) */
    public function referralStats(): void
    {
        $userId = (int)$this->userId();
        $refService = $this->refService;
        $stats = $refService->getReferrerStats($userId);
        $tier = $refService->getCurrentTier($userId);
        $this->success(['stats' => $stats, 'tier' => $tier]);
    }

    /** لیست زیرمجموعه‌ها */
    public function referralUsers(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);
        $refService = $this->refService;
        $users = $refService->getReferredUsers($userId, $perPage, $offset);
        $total = $refService->countReferredUsers($userId);
        $this->paginated($users, $total, $page, $perPage);
    }

    /** لیست دوره‌های قرعه‌کشی */
    public function lotteryList(): void
    {
        [$page, $perPage, $offset] = $this->paginationParams(20);
        $lotteryService = $this->lotteryService;
        $rounds = $lotteryService->listRounds(['status' => 'active'], $perPage, $offset);
        $this->paginated(is_array($rounds['items'] ?? null) ? $rounds['items'] : [], int_value($rounds['total'] ?? 0), $page, $perPage);
    }

    /** شرکت در قرعه‌کشی */
    public function lotteryJoin(): void
    {
        $userId = (int)$this->userId();
        $data = $this->request->body();
        $roundId = int_value($data['round_id'] ?? 0);
        $lotteryService = $this->lotteryService;
        try {
            $result = $lotteryService->participate($userId, $roundId);
            if (!empty($result['success'])) {
                $this->success($result, 'ثبت‌نام در قرعه‌کشی با موفقیت انجام شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت‌نام قرعه‌کشی'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند (هم‌الگوی سه catch هم‌فایل)
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.lottery_join.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /**
     * 📱 FIX-REVGEN-REAPLY: رأی به عدد روزانهٔ قرعه‌کشی — مسیر وب vote داشت ولی
     * API نه؛ رأیِ فعال در قرعه‌کشی‌های مبتنی بر عددِ پررأی شانس کاربر را
     * بالا می‌برد (کانال درآمدی مستقیم برای کاربر).
     *
     * POST /api/v1/wallet/lottery/vote { round_id?, daily_number_id?, voted_number }
     * — اسکوپ wallet.write (هم‌گروه lotteryJoin) + همان سقف نرخ lottery_vote وب
     * + gate لاتری در سطح مسیر (RequireFeature — kill-switch هر دو کانال).
     */
    public function lotteryVote(): void
    {
        $userId = (int)$this->userId();
        $body = $this->request->body();
        $data = is_array($body) ? $body : [];

        $validator = new \App\Validators\Requests\VoteLotteryRequest($data);
        $validator->validate();
        if ($validator->fails()) {
            $this->error('اطلاعات ورودی نامعتبر است.', 422);
            return;
        }
        $safe = $validator->safeValidated();
        $roundId = int_value($safe['round_id'] ?? 0);
        $dailyNumberId = int_value($safe['daily_number_id'] ?? 0);
        $votedNumber = int_value($safe['voted_number'] ?? -1);

        if ($dailyNumberId <= 0 && $roundId > 0) {
            /** @var \App\Models\LotteryDailyNumber $dailyModel */
            $dailyModel = app(\App\Models\LotteryDailyNumber::class);
            $today = $dailyModel->getToday($roundId);
            $dailyNumberId = int_value($today->id ?? 0);
        }
        if ($dailyNumberId <= 0) {
            $this->error('عدد روزانه برای رأی‌گیری یافت نشد.', 422, 'LOTTERY_NO_DAILY_NUMBER');
            return;
        }

        // 🛡️ همان سقف نرخ مسیر وب — قبل از ثبت رأی
        \App\Policies\RateLimitPolicy::enforce('lottery_vote', $userId, true);

        try {
            /** @var \App\Services\Lottery\LotteryParticipationService $participation */
            $participation = app(\App\Services\Lottery\LotteryParticipationService::class);
            $result = $participation->vote($userId, $dailyNumberId, $votedNumber);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            $this->error($e->getMessage(), 422);
            return;
        } catch (\Throwable $e) {
            $this->logger->error('api.lottery_vote.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
            return;
        }

        if (empty($result['success'])) {
            $this->error(str_value($result['message'] ?? 'ثبت رأی ناموفق بود'), 422, 'LOTTERY_VOTE_FAILED');
            return;
        }
        $this->success($result['data'] ?? null, str_value($result['message'] ?? 'رأی ثبت شد'));
    }
}
