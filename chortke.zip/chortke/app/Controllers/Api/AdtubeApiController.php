<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Models\AdTubeExecutionModel;
use App\Models\Ads;
use App\Services\Ads\AdsBudgetSettlementService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل AdTube — کسب درآمد از تماشای ویدیو.
 * قرارداد و گاردها عین مسیر وب (AdtubeController) است؛ منبع واحد حقیقتِ
 * پاداش/ضدتقلب همان سرویس‌ها هستند:
 *   - رزرو اسلات/کول‌داون/سقف‌ها: AdTubeExecutionModel
 *   - سیاست per-video و سنجش تقلب: AdsBudgetSettlementService::computeAdTubeMetrics
 *   - تسویه: AdsBudgetSettlementService::settleAdTubeView
 *
 * تفاوت‌های عمدی با وب (هر دو مؤمن‌اند):
 *   - چالش تماشا (watch_challenge) همین‌جا mint می‌شود (کلید کش یکسان با وب؛
 *     یک کاربر می‌تواند از هر دو کانال ادامه دهد) و TTL همان ۱۲۰ دقیقه است.
 *   - کلید state سیگنال پخش (heartbeat) یکسان با وب — انباشت مشترک.
 *   - redirect_url وب وجود ندارد؛ پاسخ، execution_id + watch_challenge +
 *     metadata ویدیو (لینک، مدت لازم، سقف سرعت) را برمی‌گرداند تا پلیر اپ
 *     بدون DOM مستقل کار کند.
 *
 * مسیرها (routes/api.php — گروه adtube با اسکوپ‌های adtube.read/write):
 *   GET  /api/v1/adtube/ads                       فهرست کمپین‌های قابل تماشا + آمار
 *   POST /api/v1/adtube/ads/{id}/start            گاردها + رزرو + mint چالش
 *   POST /api/v1/adtube/executions/{id}/heartbeat سیگنال پخش (حین تماشا)
 *   POST /api/v1/adtube/executions/{id}/complete  ثبت نهایی + تسویه
 *   GET  /api/v1/adtube/history                   تاریخچه تماشا
 */
final class AdtubeApiController extends BaseApiController
{
    // آینهٔ ثابت‌های AdtubeController (وب) — منبع سیاست؛ در صورت تغییر، هر دو
    // باید هم‌زمان تغییر کنند (برچسب FIX-MOBILE-06-MIRROR).
    private const WATCH_CHALLENGE_TTL_MINUTES = 120;
    private const HEARTBEAT_STATE_TTL_SECONDS = 7200;
    private const ADTUBE_HARD_SPEED_CEILING   = 2.5;
    private const MAX_ACTIVE_WATCHES          = 3;

    private Ads $adModel;
    private AdTubeExecutionModel $executionModel;
    private AdsBudgetSettlementService $settlement;

    public function __construct(
        Ads $adModel,
        AdTubeExecutionModel $executionModel,
        AdsBudgetSettlementService $settlement,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->adModel = $adModel;
        $this->executionModel = $executionModel;
        $this->settlement = $settlement;
    }

    /** GET /api/v1/adtube/ads — کمپین‌های قابل تماشا + آمار روزانه */
    public function ads(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        $offset = ($page - 1) * $perPage;

        // هم‌منبع وب (hubData): لیست مدل از قبل مالک کمپین و بدون‌مدت را فیلتر می‌کند
        /** @var list<\stdClass> $tasks */
        $tasks = $this->adModel->getAvailableCustomTasks($userId, ['platform' => 'youtube'], $perPage, $offset, 'adtube');
        $tasks = array_map(static function (\stdClass $task): array {
            $duration = 0;
            if (is_object($task) && is_string($task->metadata ?? null) && $task->metadata !== '') {
                $decoded = json_decode((string)$task->metadata, true);
                if (is_array($decoded) && is_numeric($decoded['video_duration_seconds'] ?? null)) {
                    $duration = (int)$decoded['video_duration_seconds'];
                }
            }
            return [
                'id'                    => (int)($task->id ?? 0),
                'title'                 => str_value($task->title ?? ''),
                'link'                  => str_value($task->link ?? ''),
                'reward'                => str_value($task->price_per_task ?? '0'),
                'currency'              => str_value($task->currency ?? 'irt'),
                'remaining_slots'       => (int)($task->remaining_slots ?? 0),
                'video_duration_seconds' => $duration, // فهرست مدل fail-closed است: بدون مدت اصلاً نمی‌آید
            ];
        }, $tasks);

        $this->success([
            'ads' => $tasks,
            'stats' => [
                'total_completed_today'    => $this->executionModel->countCompletedToday($userId),
                'active_watching'          => $this->executionModel->countActiveForUser($userId),
                'earned_today_by_currency' => $this->executionModel->getEarningsTodayByCurrency($userId),
                'daily_cap'                => max(1, int_value(setting('adtube_max_watches_per_day', 5))),
            ],
        ]);
    }

    /** POST /api/v1/adtube/ads/{id}/start — گاردها + رزرو + mint چالش */
    public function start(int $adId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        if ($adId <= 0) {
            $this->validationError(['ad_id' => ['شناسه ویدیو نامعتبر است.']]);
            return;
        }

        $ad = $this->adModel->find($adId);
        if (!$ad || $ad->type !== 'adtube' || !in_array($ad->status, ['active', 'approved'], true)) {
            $this->error('آگهی ویدیویی فعال یافت نشد.', 404, 'AD_NOT_FOUND');
            return;
        }
        if ((int)($ad->user_id ?? 0) === $userId) {
            $this->error('تماشای ویدیوی کمپین خودتان مجاز نیست و پاداشی تعلق نمی‌گیرد.', 403, 'OWN_CAMPAIGN');
            return;
        }

        $cache = \Core\Cache::getInstance();
        $ipHash = substr(md5($this->request->ip() ?: '0.0.0.0'), 0, 8);

        // ① سقف start در ساعت (کاربر+IP) — ضد مزرعهٔ چندنشستی
        $rlKey = 'adtube_start_rl:' . $userId . ':' . $ipHash . ':' . (int)floor(time() / 3600);
        try {
            $starts = int_value($cache->get($rlKey, 0));
        } catch (\Throwable) {
            $starts = 0; // fail-open برای شمارندهٔ نرم؛ گاردهای سخت پایین‌تر می‌مانند
        }
        if ($starts >= max(3, int_value(setting('adtube_max_starts_per_hour', 12)))) {
            $this->error('درخواست‌های شروع تماشا بیش از حد مجاز است؛ کمی بعد دوباره تلاش کنید.', 429, 'START_RATE_LIMITED');
            return;
        }
        try { $cache->increment($rlKey, 1, 3600); } catch (\Throwable) {}

        // ② تماشای تکراری ممنوع — برای همیشه
        if ($this->executionModel->hasCompletedForAd($adId, $userId)) {
            $this->error('این ویدیو را قبلاً به‌طور کامل تماشا کرده‌اید؛ تماشای دوباره همان ویدیو مجاز نیست.', 409, 'ALREADY_COMPLETED');
            return;
        }

        // ③ کول‌داون شبه‌تصادفی ۲۴–۷۲ ساعته — بر «هر» اجرای قطعی‌شده
        foreach ($this->executionModel->fetchAllSettledForAd($adId, $userId) as $settledRow) {
            $anchor = strtotime((string)($settledRow->completed_at ?: $settledRow->updated_at));
            if ($anchor === false || $anchor <= 0) { continue; }
            $readyAt = $anchor + $this->executionModel->cooldownHours($adId, $userId, (int)$settledRow->id) * 3600;
            if ($readyAt > time()) {
                $hoursLeft = (int)ceil(($readyAt - time()) / 3600);
                $this->error("این ویدیو در بازهٔ سرد است؛ حدود {$hoursLeft} ساعت دیگر قابل تماشا خواهد بود.", 429, 'COOLDOWN');
                return;
            }
        }

        // ④ سقف روزانه
        $dailyCap = max(1, int_value(setting('adtube_max_watches_per_day', 5)));
        if ($this->executionModel->countCompletedToday($userId) >= $dailyCap) {
            $this->error("سقف روزانهٔ تماشای ویدیو ({$dailyCap} ویدیو) پر شده است؛ فردا دوباره سر بزنید.", 429, 'DAILY_CAP');
            return;
        }

        // ⑤ fail-closed مدت — کمپین بدون مدت قابل شروع نیست
        $metaDuration = 0;
        if (is_string($ad->metadata ?? null) && $ad->metadata !== '') {
            $decodedMeta = json_decode((string)$ad->metadata, true);
            if (is_array($decodedMeta) && is_numeric($decodedMeta['video_duration_seconds'] ?? null)) {
                $metaDuration = (int)$decodedMeta['video_duration_seconds'];
            }
        }
        if ($metaDuration <= 0) {
            $this->error('مدت واقعی این ویدیو ثبت نشده است؛ کمپین بدون مدت قابل تماشا نیست.', 409, 'NO_DURATION');
            return;
        }

        if ($this->executionModel->countActiveForUser($userId) >= self::MAX_ACTIVE_WATCHES) {
            $this->error('حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.', 409, 'MAX_ACTIVE');
            return;
        }

        $execution = $this->executionModel->reserveSlot($adId, $userId, [
            'ip' => $this->request->ip(),
            'user_agent' => $this->request->userAgent(),
            'client_mode' => 'mobile_app',
        ], self::MAX_ACTIVE_WATCHES);
        if (!$execution) {
            $this->error('حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.', 409, 'MAX_ACTIVE');
            return;
        }
        $this->executionModel->startWatching((int)$execution->id);

        // mint چالش — کلید یکسان با وب؛ هر دو کانال ادامه‌پذیرند
        $watchChallenge = bin2hex(random_bytes(16));
        $challengeKey = $this->watchChallengeKey((int)$execution->id, $userId);
        try {
            $cache->put($challengeKey, $watchChallenge, self::WATCH_CHALLENGE_TTL_MINUTES);
        } catch (\Throwable $e) {
            $this->logger->error('adtube.api.challenge_mint_failed', ['execution_id' => (int)$execution->id, 'error' => $e->getMessage()]);
            // fail-closed: بدون مهر قابل‌اتکا، اجازهٔ شروعِ بدون‌چالش نمی‌دهیم
            $this->error('نشست تماشا قابل ایجاد نشد؛ دوباره تلاش کنید.', 500, 'CHALLENGE_MINT_FAILED');
            return;
        }

        $this->success([
            'execution_id'      => (int)$execution->id,
            'watch_challenge'   => $watchChallenge,
            'challenge_ttl_min' => self::WATCH_CHALLENGE_TTL_MINUTES,
            'video' => [
                'link'               => str_value($ad->link ?? ''),
                'duration_required'  => $metaDuration,
                'hard_speed_ceiling' => self::ADTUBE_HARD_SPEED_CEILING,
                'reward'             => str_value($ad->price_per_task ?? '0'),
                'currency'            => str_value($ad->currency ?? 'irt'),
            ],
        ], 'ویدیو رزرو شد؛ پلیر را باز کنید و سیگنال پخش را بفرستید.');
    }

    /** POST /api/v1/adtube/executions/{id}/heartbeat — سیگنال پخش (هم‌قرارداد وب) */
    public function heartbeat(int $executionId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $body = $this->jsonBody();
        $execution = $this->executionModel->findById($executionId);
        if (!$execution || (int)$execution->executor_id !== $userId) {
            $this->error('دسترسی غیرمجاز.', 403, 'FORBIDDEN');
            return;
        }
        if ((string)$execution->status !== 'watching') {
            $this->error('وضعیت اجرا نامعتبر است.', 409, 'INVALID_STATUS');
            return;
        }
        $challenge = trim(str_value($body['watch_challenge'] ?? ''));
        if (!$this->verifyChallenge($executionId, $userId, $challenge)) {
            $this->error('نشست تماشای این ویدیو معتبر نیست یا منقضی شده است؛ دوباره start کنید.', 409, 'CHALLENGE_INVALID');
            return;
        }

        $clientPlayed = max(0, int_value($body['played_seconds'] ?? 0));
        $playing = filter_var($body['playing'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $seq = max(0, int_value($body['seq'] ?? 0));

        $cache = \Core\Cache::getInstance();
        $stateKey = $this->heartbeatStateKey($executionId, $userId);
        try {
            $state = $cache->get($stateKey);
        } catch (\Throwable) {
            $state = null;
        }
        $now = time();
        $state = AdsBudgetSettlementService::accumulateHeartbeatState(is_array($state) ? $state : null, $clientPlayed, $playing, $seq, $now);
        try {
            $cache->setSeconds($stateKey, $state, self::HEARTBEAT_STATE_TTL_SECONDS);
        } catch (\Throwable $e) {
            // fail-closed: بدون ثبت قابل‌اتکای وضعیت، سیگنال «ثبت‌شده» تلقی نمی‌شود
            $this->logger->error('adtube.api.heartbeat.persist_failed', ['execution_id' => $executionId, 'error' => $e->getMessage()]);
            $this->error('ثبت سیگنال پخش ممکن نشد؛ اتصال خود را بررسی کنید.', 500, 'HEARTBEAT_PERSIST_FAILED');
            return;
        }
        $this->success([
            'played_seconds' => AdsBudgetSettlementService::effectiveHeartbeatSeconds($state, $now),
        ]);
    }

    /** POST /api/v1/adtube/executions/{id}/complete — ثبت نهایی + تسویه */
    public function complete(int $executionId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $body = $this->jsonBody();
        $execution = $this->executionModel->findById($executionId);
        if (!$execution || (int)$execution->executor_id !== $userId) {
            $this->error('دسترسی غیرمجاز.', 403, 'FORBIDDEN');
            return;
        }
        if ((string)$execution->status !== 'watching') {
            $this->error('وضعیت اجرا نامعتبر است.', 409, 'INVALID_STATUS');
            return;
        }

        $challenge = trim(str_value($body['watch_challenge'] ?? ''));
        if (!$this->verifyChallenge($executionId, $userId, $challenge)) {
            $this->error('نشست تماشای این ویدیو معتبر نیست یا منقضی شده است؛ دوباره start کنید.', 409, 'CHALLENGE_INVALID');
            return;
        }

        $watchTime = int_value($body['watch_time'] ?? $body['watched_seconds'] ?? 0);
        $speed = float_value($body['playback_speed'] ?? 1.0);
        if ($speed <= 0) { $speed = 1.0; }

        $heartbeatPlayedSeconds = $this->readHeartbeatPlayedSeconds($executionId, $userId);
        if ($heartbeatPlayedSeconds <= 0) {
            // خطای گذرا — بدون markRejected (الگوی چالش؛ retry مجاز)
            $this->error('سیگنال پخش ویدیو به سرور نرسیده است؛ صفحه را باز نگه دارید، ویدیو را پخش کنید و پس از فعال شدن دکمه، دوباره تلاش کنید.', 409, 'NO_HEARTBEAT_SIGNAL');
            return;
        }

        $perVideoPolicy = $this->settlement->adtubePerVideoPolicy(
            (int)($execution->video_duration ?? 0) > 0 ? (int)$execution->video_duration : null,
            ''
        );
        $requiredDuration = $perVideoPolicy['required_duration'];
        if ($requiredDuration <= 0 && !empty($execution->ad_id)) {
            $adRow = $this->adModel->find((int)$execution->ad_id);
            if ($adRow !== null && is_string($adRow->metadata ?? null) && $adRow->metadata !== '') {
                $perVideoPolicy = $this->settlement->adtubePerVideoPolicy(null, (string)$adRow->metadata);
                $requiredDuration = $perVideoPolicy['required_duration'];
            }
        }
        if ($requiredDuration <= 0) {
            $this->executionModel->markRejected($executionId, 'مدت واقعی ویدیو برای این کمپین ثبت نشده است.');
            $this->error('مدت واقعی این ویدیو ثبت نشده است؛ ثبت تماشا ممکن نیست.', 409, 'NO_DURATION');
            return;
        }
        $minWatchSeconds = $perVideoPolicy['min_watch_seconds'];
        $maxSpeed = $perVideoPolicy['max_speed'];
        $playerDuration = int_value($body['player_duration'] ?? 0);
        $progress = int_value($body['progress_percent'] ?? 0);
        if ($progress <= 0 && $watchTime > 0) {
            $progress = (int)min(100, round(($watchTime / $requiredDuration) * 100));
        }

        if ($speed > self::ADTUBE_HARD_SPEED_CEILING) {
            $this->executionModel->markRejected($executionId, 'سرعت پخش غیرعادی: ' . $speed . 'x');
            $this->error('سرعت پخش غیرعادی تشخیص داده شد.', 422, 'SPEED_CEILING');
            return;
        }

        $startedAt = 0;
        if (!empty($execution->started_at)) {
            $startedAt = strtotime((string)$execution->started_at);
        } elseif (!empty($execution->created_at)) {
            $startedAt = strtotime((string)$execution->created_at);
        }
        if ($startedAt > 0) {
            $metrics = AdsBudgetSettlementService::computeAdTubeMetrics(
                (int)$startedAt, time(), $watchTime, $speed, $requiredDuration, $maxSpeed, $heartbeatPlayedSeconds
            );
            if ($metrics['fraud']) {
                $this->executionModel->markRejected($executionId, 'تقلب زمان مشاهده: ادعای کلاینت ' . $watchTime . 's، سیگنال پخش سرور ' . $heartbeatPlayedSeconds . 's، سقف فیزیکی سرور ' . $metrics['max_content_seconds'] . 's');
                $this->error('زمان تماشای واقعی با زمان سپری‌شده بر روی سرور مطابقت ندارد.', 422, 'WATCH_TIME_MISMATCH');
                return;
            }
        }

        $settlement = $this->settlement->settleAdTubeView(
            $executionId, $userId, $watchTime, $progress, $speed, $playerDuration, $heartbeatPlayedSeconds
        );

        if (!empty($settlement['success'])) {
            try {
                \Core\Cache::getInstance()->forget($this->watchChallengeKey($executionId, $userId));
            } catch (\Throwable $e) {
                $this->logger->warning('adtube.api.challenge.consume_failed', ['execution_id' => $executionId, 'error' => $e->getMessage()]);
            }
        }

        if (!empty($settlement['success'])) {
            $this->success([
                'execution_id' => $executionId,
                'settlement'   => $settlement,
            ], str_value($settlement['message'] ?? 'ویدیو با موفقیت ثبت و پاداش پرداخت شد.'));
        } else {
            $this->error(str_value($settlement['message'] ?? 'تسویه ویدیو انجام نشد.'), 422, 'SETTLEMENT_REJECTED');
        }
    }

    /** GET /api/v1/adtube/history — تاریخچه تماشا */
    public function history(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        /** @var list<\stdClass> $rows */
        $rows = $this->executionModel->getHistory($userId, $perPage, ($page - 1) * $perPage);
        $this->success([
            'history' => array_map(static fn(\stdClass $r): array => [
                'id'            => (int)$r->id,
                'ad_id'         => (int)($r->ad_id ?? 0),
                'ad_title'      => str_value($r->ad_title ?? ''),
                'video_link'    => str_value($r->video_link ?? ''),
                'status'        => str_value($r->status ?? ''),
                'reward'        => str_value($r->reward_amount ?? '0'),
                'currency'      => str_value($r->reward_currency ?? 'irt'),
                'completed_at'  => str_value($r->completed_at ?? ''),
            ], $rows),
        ]);
    }

    // ═══ helpers (کلیدها عین وب — FIX-MOBILE-06-MIRROR) ═══

    private function watchChallengeKey(int $executionId, int $userId): string
    {
        return "adtube_watch_challenge:{$executionId}:{$userId}";
    }

    private function heartbeatStateKey(int $executionId, int $userId): string
    {
        return "adtube_heartbeat:{$executionId}:{$userId}";
    }

    private function verifyChallenge(int $executionId, int $userId, string $challenge): bool
    {
        if ($executionId <= 0 || $userId <= 0 || $challenge === '') {
            return false;
        }
        try {
            $stored = \Core\Cache::getInstance()->get($this->watchChallengeKey($executionId, $userId));
        } catch (\Throwable) {
            return false; // fail-closed
        }
        return is_string($stored) && $stored !== '' && hash_equals($stored, $challenge);
    }

    private function readHeartbeatPlayedSeconds(int $executionId, int $userId): int
    {
        try {
            $state = \Core\Cache::getInstance()->get($this->heartbeatStateKey($executionId, $userId));
        } catch (\Throwable) {
            return 0;
        }
        if (!is_array($state)) {
            return 0;
        }
        return (int)AdsBudgetSettlementService::effectiveHeartbeatSeconds($state, time());
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
