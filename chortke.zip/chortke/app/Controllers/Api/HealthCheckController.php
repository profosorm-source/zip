<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Services\Health\HealthCheckService;

class HealthCheckController extends BaseApiController
{
    private HealthCheckService $healthService;

    public function __construct(HealthCheckService $healthService, ?\App\Contracts\LoggerInterface $logger = null)
    {
        parent::__construct(null, null, null, null, $logger);
        $this->healthService = $healthService;
    }

    protected function jsonResponse(array $data, int $statusCode = 200): void
    {
        $this->response->json($data, $statusCode);
    }

    /**
     * Liveness Probe: Used by orchestrators (k8s/Docker) to know if container is running.
     *
     * Routes: GET /health, GET /health/live, GET /api/health, GET /api/v1/health/live
     *
     * MUST stay fast (< 50ms) and dependency-free. A failure here means the
     * container should be restarted. A success only means "PHP is executing
     * scripts" — it does NOT mean the app can serve real traffic; that is
     * the job of /health/ready.
     */
    public function live(): void
    {
        $this->validateAccess();

        $result = $this->healthService->checkLiveness();

        $statusCode = $result['status'] === 'error' ? 503 : 200;

        // Probes are polled by infrastructure and must never be cached by
        // intermediaries (a stale "ok" would mask an outage).
        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
        $this->response->setHeader('Pragma', 'no-cache');
        $this->jsonResponse($result, $statusCode);
    }

    /**
     * Readiness Probe: Used by load balancers to decide if this node should
     * receive traffic.
     *
     * Routes: GET /health/ready, GET /api/health/ready, GET /api/v1/health/ready
     *
     * BUGFIX-HEALTH-ROUTES-2026-06 changes vs the previous behavior:
     *
     *   1. Per-process micro-cache: the full readiness check is expensive
     *      (≈3–5 seconds because it probes external gateways like Zarinpal
     *      and Kavenegar). Without a cache, an aggressive LB probing every
     *      2s would serialize ~50% of PHP-FPM worker time into health
     *      probing. We cache the snapshot for `health.ready_cache_ttl`
     *      seconds (default 5s) — long enough to dominate probe cost,
     *      short enough to react quickly to real outages.
     *
     *   2. Degraded status now returns HTTP 503 by default. Most LBs treat
     *      anything in the 2xx range as healthy, so the previous behavior
     *      kept routing traffic to nodes whose external gateways were
     *      already failing. Operators that prefer the older "degraded =
     *      still in rotation" semantics can opt out with
     *      `health.degraded_is_ready = true` in config.
     */
    public function ready(): void
    {
        $this->validateAccess();

        $ttl = (int) config('health.ready_cache_ttl', 5);
        $cacheKey = 'health:ready:snapshot';

        $result = null;
        try {
            $cache = \Core\Container::getInstance()->make(\Core\Cache::class);
            if ($ttl > 0) {
                $cached = $cache->get($cacheKey);
                if (is_array($cached) && isset($cached['_cached_at'])
                    && (time() - (int)$cached['_cached_at']) < $ttl) {
                    $result = $cached;
                    $result['_from_cache'] = true;
                }
            }
        } catch (\Throwable $cacheErr) {
            // Cache itself being down must never break the health endpoint.
            // We fall through to a fresh check and log via the standard
            // logger, which writes to file when DB/Redis are unavailable.
            if ($this->logger) {
                $this->logger->warning('health.cache_unavailable', [
                    'error' => $cacheErr->getMessage(),
                ]);
            }
        }

        if ($result === null) {
            $result = $this->healthService->checkReadiness();
            $result['_cached_at'] = time();
            $result['_from_cache'] = false;
            if (isset($cache) && $ttl > 0) {
                try { $cache->put($cacheKey, $result, max(1, (int)ceil($ttl / 60))); }
                catch (\Throwable) { /* best-effort */ }
            }
        }

        $degradedIsReady = (bool) config('health.degraded_is_ready', false);
        $isError    = $result['status'] === 'error';
        $isDegraded = $result['status'] === 'degraded';

        if ($isError || ($isDegraded && !$degradedIsReady)) {
            $statusCode = 503;
        } else {
            $statusCode = 200;
        }

        $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
        $this->response->setHeader('Pragma', 'no-cache');
        $this->jsonResponse($result, $statusCode);
    }

    private function validateAccess(): void
    {
        $allowedIps = config('health.allowed_ips', ['127.0.0.1', '::1']);
        $token = config('health.check_token', '');
        
        $clientIp = $_SERVER['REMOTE_ADDR'] ?? '';
        $requestToken = $this->request->get('token', $this->request->header('X-Health-Token', ''));
        
        $isIpAllowed = empty($allowedIps) || in_array($clientIp, $allowedIps, true);
        $isTokenValid = !empty($token) && hash_equals($token, $requestToken);
        
        if (!$isIpAllowed && !$isTokenValid) {
            $this->jsonResponse(['status' => 'error', 'message' => 'Unauthorized Access'], 403);
            exit;
        }
    }
}
