<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Middleware\ApiAuthMiddleware;
use App\Models\UserVerification;
use App\Contracts\AntiFraud\FraudGuardInterface;
use App\Services\Auth\AuthService;
use App\Services\Auth\LoginRiskService;
use App\Services\Auth\ReferralAntiFarmingGate;
use App\Services\CaptchaService;
use App\Services\EmailService;
use App\Services\Shared\PolicyService;
use App\Services\User\UserService;
use Core\RateLimiter;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * MobileAuthController — چرخهٔ کامل حساب از کانال API (بدون session).
 *
 * 📱 FIX-MOBILE-01 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲):
 * تا پیش از این، ثبت‌نام/تأیید ایمیل/بازیابی رمز فقط روی مسیرهای وبِ
 * session-دار (CSRF + flash + pending_verification_email در session) تعریف
 * شده بودند؛ اپ موبایل که با Bearer token کار می‌کند به هیچ‌کدام دسترسی
 * نداشت و عملاً بدون سایت نمی‌شد حساب ساخت. این کنترلر همان سرویس‌های
 * زیرین (AuthService / PasswordRecoveryService / UserVerification) را با
 * قرارداد stateless بازنشر می‌کند.
 *
 * قراردادهای امنیتی (هم‌سطح مسیر وب):
 *  - ضد-افشای وجود حساب (anti-enumeration): پاسخ عمومی + bcrypt/زمان‌پرکن
 *  - rate limit اختصاصی هر مسیر (هم‌پارامتر مسیر وب) + rate limit عمومی گروه /api/v1
 *  - captcha ریسک‌محور فقط از نوع recaptcha (تنها نوعی که بدون session کلاینت
 *    بومی می‌تواند حل کند — math/image/behavioral به چالش session-دار وابسته‌اند)
 *  - گیت ضدتقلب FraudGuardService + گیت ضد-فارمینگ رفرال (همان دوتای مسیر وب)
 *
 * همهٔ مسیرها عمومی‌اند (بدون ApiAuthMiddleware) و CSRF روی /api/ معاف است
 * (CSRFMiddleware L44-46) — احراز هویت این مسیرها با «رازِ خودِ request»
 * (رمز/کد یک‌بارمصرف/توکن بازیابی) است، نه cookie.
 */
class MobileAuthController extends BaseApiController
{
    private AuthService $authService;
    private UserService $userService;
    private UserVerification $userVerification;
    private EmailService $emailService;
    private LoginRiskService $loginRiskService;
    private CaptchaService $captchaService;
    // FIX-MOBILE-01: اینترفیس (نه کلاس final) — هم‌قرارداد تزریق سرویس، هم تست‌پذیر
    private FraudGuardInterface $fraudGuard;
    private RateLimiter $rateLimiter;
    private ?ReferralAntiFarmingGate $referralAntiFarmingGate;

    public function __construct(
        AuthService $authService,
        UserService $userService,
        UserVerification $userVerification,
        EmailService $emailService,
        LoginRiskService $loginRiskService,
        CaptchaService $captchaService,
        FraudGuardInterface $fraudGuard,
        RateLimiter $rateLimiter,
        ?LoggerInterface $logger = null,
        ?ReferralAntiFarmingGate $referralAntiFarmingGate = null,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?PolicyService $policyService = null
    ) {
        parent::__construct($session, $request, $response, $policyService, $logger);
        $this->authService = $authService;
        $this->userService = $userService;
        $this->userVerification = $userVerification;
        $this->emailService = $emailService;
        $this->loginRiskService = $loginRiskService;
        $this->captchaService = $captchaService;
        $this->fraudGuard = $fraudGuard;
        $this->rateLimiter = $rateLimiter;
        $this->referralAntiFarmingGate = $referralAntiFarmingGate;
    }

    /**
     * POST /api/v1/auth/register
     *
     * ثبت‌نام حساب جدید از اپ موبایل. پس از موفقیت، ایمیل تأیید (لینک + کد
     * ۶ رقمی) به‌صورت رویدادی ارسال می‌شود (UserRegisteredEvent — همان مسیر
     * وب) و کلاینت باید با /auth/email/verify-code ادامه دهد؛ صدور توکن
     * تا قبل از تأیید ایمیل بسته است (EMAIL_UNVERIFIED در TokenController).
     */
    public function register(): void
    {
        $body = $this->request->body();

        // ── ۱. سقف ثبت‌نام per-IP (۵ در ساعت) — کلید HMAC‌شده مثل issue() ──
        $ipKey = 'api_register_rl_' . hash_hmac('sha256', $this->request->ip(), str_value(config('app.key')));
        if (!$this->rateLimiter->attempt($ipKey, 5, 60, true)) {
            $this->error('تعداد درخواست‌های ثبت‌نام بیش از حد مجاز است. بعداً تلاش کنید', 429, 'RATE_LIMITED');
            return;
        }

        // ── ۲. فقط فیلدهای مجاز (همان allowlist مسیر وب — دفاع لایه دوم Mass Assignment) ──
        $data = [];
        foreach (['full_name', 'email', 'password', 'password_confirmation', 'username', 'mobile', 'referral_code'] as $field) {
            if (array_key_exists($field, $body) && is_scalar($body[$field])) {
                $data[$field] = trim(str_value($body[$field]));
            }
        }
        if (empty($data['referral_code'])) {
            unset($data['referral_code']);
        }

        // FIX-X90 هم‌ارز مسیر وب: پذیرش قوانین سمت سرور enforce می‌شود
        $terms = $body['terms'] ?? false;
        if (!is_scalar($terms) || !in_array(strtolower(trim(str_value($terms))), ['1', 'true', 'on', 'yes'], true)) {
            $this->validationError(['terms' => ['پذیرش قوانین و مقررات الزامی است']]);
            return;
        }

        // ── ۳. کپچای ریسک‌محور (فقط recaptcha — تنها نوع stateless) ──
        if ($this->captchaService->isEnabled()) {
            $captchaType = $this->loginRiskService->getCaptchaType('register', null, null);
            if ($captchaType !== null) {
                $recaptcha = trim(str_value($body['g-recaptcha-response'] ?? $body['recaptcha_response'] ?? ''));
                if ($recaptcha === '' || !$this->captchaService->verify('', '', $recaptcha)) {
                    $this->loginRiskService->recordFailure('register', null, null);
                    $this->error('کد امنیتی (reCAPTCHA) الزامی یا نامعتبر است', 422, 'CAPTCHA_REQUIRED');
                    return;
                }
            }
        }

        // ── ۴. اعتبارسنجی رسمی (RegisterRequest + PasswordPolicy + HIBP) ──
        $errors = $this->authService->validateRegister($data);
        if (!empty($errors)) {
            $this->validationError(['form' => $errors]);
            return;
        }

        // ── ۵. گیت ضدتقلب (همان مسیر وب: ربات/ایمیل یک‌بارمصرف/...) ──
        $risk = $this->fraudGuard->checkAction(0, 'auth.register', [
            'email'      => str_value($data['email'] ?? ''),
            'phone'      => str_value($data['mobile'] ?? ''),
            'ip'         => $this->request->ip(),
            'user_agent' => $this->request->userAgent(),
        ]);
        if (!is_array($risk) || empty($risk['allowed'])) {
            $this->logger->warning('mobile_api.registration_blocked_by_fraud_guard', [
                'email'  => str_value($data['email'] ?? ''),
                'reason' => is_array($risk) ? str_value($risk['reason'] ?? '') : 'unknown',
            ]);
            $this->error('امکان ثبت‌نام به دلیل تشخیص رفتارهای مشکوک مسدود گردید', 403, 'REGISTRATION_BLOCKED');
            return;
        }

        // ── ۶. گیت ضد-فارمینگ رفرال (fail-open در غیاب سرویس — همان قرارداد وب) ──
        if ($this->referralAntiFarmingGate !== null) {
            $this->referralAntiFarmingGate->apply($data, $this->request->ip(), $this->session);
        }

        // ── ۷. ثبت‌نام (wallet + رویداد ایمیل تأیید خودکار از ProcessRegistrationJob) ──
        $result = $this->authService->register($data);
        if (!is_array($result) || empty($result['success'])) {
            // FIX-R18N هم‌ارز: پاسخ عمومی بدون افشای وجود ایمیل (UNIQUE در لایهٔ DB)
            $this->error(str_value($result['message'] ?? 'ثبت‌نام با خطا مواجه شد.'), 400, 'REGISTER_FAILED');
            return;
        }

        $user = $result['user'] ?? null;
        $this->success([
            'user_id'       => is_object($user) ? int_value($user->id ?? 0) : 0,
            'email'         => str_value($data['email'] ?? ''),
            'email_verified'=> false,
            'next_step'     => 'verify_email',
            'next_endpoint' => '/api/v1/auth/email/verify-code',
        ], 'ثبت‌نام موفق! کد تأیید ایمیل برای شما ارسال شد', 201);
    }

    /**
     * POST /api/v1/auth/email/verify-code
     *
     * تأیید ایمیل با کد ۶ رقمی — stateless (ایمیل صریحاً پاس داده می‌شود؛
     * مسیر وب آن را در session pin می‌کند). امنیت: کد یک‌بارمصرف + انقضای
     * ۱ ساعت + سقف ۵ تلاش در ۱۵ دقیقه به‌ازای ایمیل و IP (هم‌پارامتر وب).
     */
    public function verifyEmailCode(): void
    {
        $body = $this->request->body();
        $email = mb_strtolower(trim(str_value($body['email'] ?? '')), 'UTF-8');
        $code = strtoupper(trim(str_value($body['code'] ?? '')));

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->validationError(['email' => ['ایمیل معتبر الزامی است']]);
            return;
        }
        if (strlen($code) !== 6 || preg_match('/^[A-Z0-9]{6}$/', $code) !== 1) {
            $this->validationError(['code' => ['کد باید ۶ کاراکتر حرف/رقم باشد']]);
            return;
        }

        // سقف تلاش per-email (همان کلید/پارامتر مسیر وب) + per-IP برای وب‌سوییپ
        $emailKey = 'verify_email_attempts:' . hash('sha256', $email);
        $ipKey = 'api_verify_email_rl_' . hash_hmac('sha256', $this->request->ip() . '|' . $email, str_value(config('app.key')));
        if (!$this->rateLimiter->attempt($emailKey, 5, 15, true)
            || !$this->rateLimiter->attempt($ipKey, 10, 15, true)) {
            $this->logger->critical('mobile_api.email_verification.bruteforce_detected', ['ip' => $this->request->ip()]);
            $this->error('تعداد تلاش‌های ناموفق بیش از حد مجاز است. ۱۵ دقیقه دیگر تلاش کنید', 429, 'RATE_LIMITED');
            return;
        }

        $user = $this->userService->findByEmail($email);
        if (!$user) {
            usleep(random_int(50000, 150000));
            $this->error('کد نامعتبر است یا منقضی شده', 422, 'INVALID_CODE');
            return;
        }

        if (!empty($user->email_verified_at)) {
            // idempotent — تأییدِ دوباره خطا نیست؛ کلاینت به لاگین هدایت می‌شود
            $this->success(['email_verified' => true, 'next_step' => 'login'], 'ایمیل از قبل تأیید شده است');
            return;
        }

        $verification = $this->userVerification->findValidCode((int)$user->id, $code, 'email');
        if (!$verification) {
            usleep(random_int(50000, 150000));
            $this->error('کد نامعتبر است یا منقضی شده', 422, 'INVALID_CODE');
            return;
        }

        // تأیید موفق — همان جفتِ عملیات مسیر وب (FIX-X45: کد تک‌مصرف + مهر verified)
        $this->userService->verifyEmail((int)$user->id);
        $this->userVerification->markVerified((int)$verification->id);

        $this->success([
            'email_verified' => true,
            'next_step'      => 'login',
            'next_endpoint'  => '/api/v1/auth/token',
        ], 'ایمیل شما با موفقیت تأیید شد');
    }

    /**
     * POST /api/v1/auth/email/resend-verification
     *
     * ارسال مجدد ایمیل تأیید (چرخش توکن — HIGH-H-08) — ضد-افشا با پاسخ عمومی.
     */
    public function resendVerification(): void
    {
        $body = $this->request->body();
        $email = mb_strtolower(trim(str_value($body['email'] ?? '')), 'UTF-8');
        $genericMsg = 'در صورت وجود حساب، ایمیل ارسال شد.';

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->validationError(['email' => ['ایمیل معتبر الزامی است']]);
            return;
        }

        // همان سقف مسیر وب: ۳ درخواست در ۲ دقیقه به‌ازای جفت email:ip
        $rateLimitKey = 'api_resend_email:' . hash('sha256', "{$email}:" . $this->request->ip());
        if (!$this->rateLimiter->attempt($rateLimitKey, 3, 120, true)) {
            $this->error('لطفاً چند دقیقه صبر کنید و سپس دوباره تلاش کنید', 429, 'RATE_LIMITED');
            return;
        }

        $user = $this->userService->findByEmail($email);

        // HIGH-H-08 هم‌ارز: چرخش توکن روی resend تا توکن لو رفته بی‌اعتبار شود
        if ($user && empty($user->email_verified_at)) {
            try {
                $newToken = bin2hex(random_bytes(32));
                $hashedToken = hash_hmac('sha256', strtoupper(substr($newToken, 0, 6)), secure_key());

                $this->userService->update((int)$user->id, ['email_verification_token' => $hashedToken]);

                $otpCode = strtoupper(substr($newToken, 0, 6));
                $expiresAt = date('Y-m-d H:i:s', (strtotime('+1 hour') ?: time()));
                $this->userVerification->upsertOtp((int)$user->id, $newToken, $otpCode, $expiresAt, 'email');

                $this->emailService->sendVerificationEmail((int)$user->id, $newToken);
            } catch (\Throwable $e) {
                // خطای زیرساخت ایمیل هرگز وجود/عدم وجود حساب را افشا نمی‌کند
                $this->logger->error('mobile_api.resend_verification_failed', ['error' => $e->getMessage()]);
            }
        }

        // همیشه پاسخ موفق (ضد-افشای وجود حساب)
        $this->success(['sent' => true], $genericMsg);
    }

    /**
     * POST /api/v1/auth/password/forgot
     *
     * درخواست لینک بازیابی رمز — ضد-افشا با پاسخ عمومی؛ سقف‌ها هم‌پارامتر
     * مسیر وب (۵/ساعت per-IP + ۳/ساعت per-email).
     */
    public function forgotPassword(): void
    {
        $body = $this->request->body();
        $email = trim(str_value($body['email'] ?? ''));
        $genericMsg = 'در صورت وجود حساب، لینک بازیابی ارسال شد.';

        $emailKey = hash('sha256', mb_strtolower($email, 'UTF-8'));
        $rateLimitIp = 'api_forgot_pwd_ip:' . hash('sha256', $this->request->ip());
        $rateLimitEmail = "api_forgot_pwd_email:{$emailKey}";

        // FIX-8a هم‌ارز: واحد decay دقیقه است — پنجرهٔ ۱ ساعته
        if (!$this->rateLimiter->attempt($rateLimitIp, 5, 60, true)
            || !$this->rateLimiter->attempt($rateLimitEmail, 3, 60, true)) {
            $this->error('تعداد درخواست‌های بازیابی بیش از حد مجاز است. بعداً تلاش کنید', 429, 'RATE_LIMITED');
            return;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->success(['sent' => true], $genericMsg);
            return;
        }

        try {
            $this->authService->requestPasswordReset($email);
        } catch (\Throwable $e) {
            $this->logger->error('mobile_api.forgot_password_failed', ['error' => $e->getMessage()]);
        }

        $this->success(['sent' => true], $genericMsg);
    }

    /**
     * POST /api/v1/auth/password/reset
     *
     * تنظیم رمز جدید با توکن بازیابی. پس از موفقیت، «همهٔ» نشست‌های وب و
     * «همهٔ» توکن‌های API کاربر باطل می‌شوند (Security Hardening #4 داخل
     * PasswordRecoveryService) — کلاینت موبایل باید دوباره لاگین کند.
     */
    public function resetPassword(): void
    {
        $body = $this->request->body();
        $token = trim(str_value($body['token'] ?? ''));
        $password = str_value($body['password'] ?? '');
        $passwordConfirm = str_value($body['password_confirm'] ?? '');

        if ($token === '') {
            $this->validationError(['token' => ['توکن بازیابی الزامی است']]);
            return;
        }

        // همان قواعد مسیر وب (CRITICAL-02): required + min:8 + same
        $minLength = int_value(config('auth.password.min_length', 12));
        $errors = [];
        if ($password === '') {
            $errors['password'] = ['رمز عبور الزامی است'];
        } elseif (strlen($password) < max(8, $minLength)) {
            $errors['password'] = ["رمز عبور باید حداقل {$minLength} کاراکتر باشد"];
        } elseif ($password !== $passwordConfirm) {
            $errors['password_confirm'] = ['تکرار رمز عبور مطابقت ندارد'];
        }
        if (!empty($errors)) {
            $this->validationError($errors);
            return;
        }

        // سقف تلاش per-IP (توکن ۶۴-hex تصادفی است؛ این صرفاً لایهٔ ضد-اسکن است)
        $ipKey = 'api_reset_pwd_rl_' . hash_hmac('sha256', $this->request->ip(), str_value(config('app.key')));
        if (!$this->rateLimiter->attempt($ipKey, 10, 15, true)) {
            $this->error('تعداد درخواست‌ها بیش از حد مجاز است. بعداً تلاش کنید', 429, 'RATE_LIMITED');
            return;
        }

        $result = $this->authService->resetPassword($token, $password, null);
        if (!is_array($result) || empty($result['success'])) {
            $this->error(str_value($result['message'] ?? 'توکن بازیابی نامعتبر یا منقضی شده است.'), 422, 'INVALID_RESET_TOKEN');
            return;
        }

        $this->success([
            'reset'       => true,
            'revoked'     => ['web_sessions' => true, 'api_tokens' => true],
            'next_step'   => 'login',
            'next_endpoint' => '/api/v1/auth/token',
        ], 'رمز عبور با موفقیت بازنشانی شد؛ همهٔ نشست‌ها و توکن‌ها باطل شدند. دوباره وارد شوید');
    }
}
