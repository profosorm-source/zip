<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Services\FeatureFlagService;
use App\Services\Settings\AppSettings;

/**
 * AppConfigController — نقطه ورود یکپارچه پیکربندی اپلیکیشن موبایل
 *
 * GET /api/v1/config
 * مدیریت وضعیت نگهداری، الزام آپدیت اجباری (Force Update) و متغیرهای کلیدی پلتفرم
 */
class AppConfigController extends BaseApiController
{
    // FIX-R36-W3 (F-A16-02): GET /api/v1/config عمداً public است (بوت‌استرپ اپ موبایل)؛
    // اما getAll() کامل نام/وضعیت «همهٔ» فلگ‌ها را می‌ریخت — از جمله فلگ‌های عملیاتی/مدیریتی
    // (beta, critical, db_query_tracking, analytics_cache_enabled, oauth_strict_ip_binding,
    // investment_v2_calculation, investment_fees) که سطح حملهٔ هدف‌گذاری را بالا می‌برد.
    // اکنون فقط فلگ‌های mobile-facing از یک allowlist (قابل override با
    // config('mobile.exposed_feature_flags')) منتشر می‌شوند؛ فلگ‌های ناشناخته/جدید
    // به‌صورت fail-closed مخفی می‌مانند تا ادمین آگاهانه expose کند.
    private const MOBILE_FACING_FLAGS = [
        'lottery', 'investment', 'tasks', 'referral', 'coupons',
        'crypto_wallet', 'crypto_deposit', 'vitrine_enabled',
    ];

    private FeatureFlagService $featureService;
    private AppSettings $appSettings;

    public function __construct(FeatureFlagService $featureService, AppSettings $appSettings, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->featureService = $featureService;
        $this->appSettings = $appSettings;
    }

    /**
     * ارائه اطلاعات یکپارچه پیکربندی اپلیکیشن موبایل
     */
    public function config(): void
    {
        // 1. بررسی هدر نسخه کلاینت موبایل
        $clientVersion = str_value($this->request->header('X-App-Version')
            ?? $this->request->get('app_version')
            ?? '1.0.0');
        // FIX-M11-R22-27: client_version بدون validation به خروجی/مقایسه نمی‌رود —
        // فقط الگوی semver ساده (major.minor.patch تا سه جزء) پذیرفته می‌شود؛
        // ورودی نامعتبر به '1.0.0' بازمی‌گردد (version_compare با ورودی دلخواه
        // رفتار غیرقابل‌پیش‌بینی دارد و ورودی خام هم در payload echo می‌شد).
        if (preg_match('/^\d{1,3}(\.\d{1,3}){0,2}$/', $clientVersion) !== 1) {
            $clientVersion = '1.0.0';
        }

        // FIX راند ۷۸ (کشف URL ×۲): پیش‌تر این سه مقدار با config('app.mobile.*')
        // خوانده می‌شدند که هیچ‌کدام در config.php وجود نداشتند (کلید شبح) →
        // مقدار هاردکد همیشه برمی‌گشت و ادمین هیچ کنترلی نداشت. اکنون از
        // SettingsCatalog (تب «اپلیکیشن موبایل») خوانده می‌شود؛ پیش‌فرض‌ها
        // عیناً همان هاردکدهای قبلی‌اند (قانون طلایی کاتالوگ).
        $minAppVersion = str_value($this->appSettings->get('mobile_min_app_version', '1.0.0'));
        $latestAppVersion = str_value($this->appSettings->get('mobile_latest_app_version', '1.2.0'));

        // محاسبه دینامیک الزام آپدیت اجباری (Force Update)
        $forceUpdate = version_compare($clientVersion, $minAppVersion, '<');

        // 2. وضعیت تعمیرات و نگهداری سیستم
        // FIX-M4-10: منبع وضعیت یکی شد — MaintenanceMiddleware ابتدا settingهای DB
        // (maintenance_mode / maintenance_message) را می‌خواند و فقط در نبودشان به
        // config فایل fallback می‌کند؛ اینجا قبلاً «فقط» config فایل را گزارش می‌داد
        // و API ممکن بود وضعیت متفاوتی از middleware اعلام کند. همان ترتیب DB-first
        // با همان کلیدها + همان رفتار fail-open در خطای خواندن رعایت شد.
        try {
            $rawMaintenanceMode = $this->appSettings->get('maintenance_mode', config('maintenance.enabled', false));
            $maintenanceEnabled = is_bool($rawMaintenanceMode)
                ? $rawMaintenanceMode
                : filter_var(str_value($rawMaintenanceMode), FILTER_VALIDATE_BOOLEAN);
            $maintenanceMessage = str_value($this->appSettings->get(
                'maintenance_message',
                config('maintenance.message', 'سیستم در حال به‌روزرسانی و تعمیرات زیرساختی است. لطفاً شکیبا باشید.')
            ));
        } catch (\Throwable) {
            $maintenanceEnabled = (bool)config('maintenance.enabled', false);
            $maintenanceMessage = str_value(config('maintenance.message', 'سیستم در حال به‌روزرسانی و تعمیرات زیرساختی است. لطفاً شکیبا باشید.'));
        }

        // 3. استخراج پرچم‌های ویژگی — فقط allowlist موبایل (FIX-R36-W3/F-A16-02)
        $featuresList = [];
        try {
            $exposedFlags = (array)config('mobile.exposed_feature_flags', self::MOBILE_FACING_FLAGS);
            $allFeatures = $this->featureService->getAll();
            foreach ($allFeatures as $f) {
                $flagName = str_value($f->name ?? '');
                if ($flagName !== '' && in_array($flagName, $exposedFlags, true)) {
                    $featuresList[$flagName] = (bool)$f->enabled;
                }
            }
        } catch (\Throwable $e) {
            $this->logger->warning('app_config.features_fetch_failed', ['error' => $e->getMessage()]);
        }

        // 4. تدوین پکیج یکپارچه پیکربندی
        $payload = [
            'app_versioning' => [
                'client_version' => $clientVersion,
                'min_app_version' => $minAppVersion,
                'latest_app_version' => $latestAppVersion,
                'force_update' => $forceUpdate,
                'update_url' => str_value($this->appSettings->get('mobile_update_url', 'https://chortke.com/app/download')),
            ],
            'maintenance' => [
                'enabled' => $maintenanceEnabled,
                'message' => $maintenanceMessage,
            ],
            'features' => $featuresList,
            'settings' => [
                'locales' => ['fa', 'en'],
                'default_locale' => 'fa',
                'currency' => 'IRT',
                // FIX-M11-R22-27: حدود واریز دیگر هاردکد نیست — از همان منبعِ
                // سرویس واریز (SettingsCatalog: payment.min_deposit) خوانده می‌شود؛
                // payment.max_deposit هم به کاتالوگ اضافه شد (سقف واحد جدید).
                'deposit_min' => max(0, (int)round((float)str_value($this->appSettings->get('payment.min_deposit', '10000')))),
                'deposit_max' => max(0, (int)round((float)str_value($this->appSettings->get('payment.max_deposit', '50000000')))),
                'auth_modes' => ['email', 'google', 'otp'],
            ],
            'security' => [
                'auth_type' => 'Bearer',
                'refresh_token_rotation' => true,
                // FIX-M11-L3 (گزارش ماژول ۱۱): rate_limit_max از payload عمومی حذف شد —
                // جزئیات دفاعی/عملیاتی است و هیچ bootstrap موبایلی به آن نیاز ندارد؛
                // کلاینت‌ها باید به هدرهای Retry-After/X-RateLimit-* تکیه کنند.
                // deposit_min/max و auth_modes به‌عنوان نیازِ کاربردیِ bootstrap حفظ شدند.
            ],
            'system_timestamp' => time(),
        ];

        $this->success($payload, 'پیکربندی اولیه اپلیکیشن موبایل با موفقیت بارگذاری شد', 200);
    }
}
