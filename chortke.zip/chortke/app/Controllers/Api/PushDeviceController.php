<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Services\Notification\FcmService;
use App\Services\Shared\PolicyService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * PushDeviceController — مدیریت دستگاه‌های Push از کانال API.
 *
 * 📱 FIX-MOBILE-03 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲):
 * ثبتِ توکن FCM تا پیش از این فقط از مسیر وبِ session-دار
 * (POST /notifications/fcm-token با CSRF) ممکن بود؛ اپ موبایل که با Bearer
 * token کار می‌کند راه stateless نداشت و پوش عملاً بلااستفاده بود (باگ
 * fan-out مسیر ارسال هم در FIX-MOBILE-02 بسته شد).
 *
 * قرارداد:
 *   GET  /api/v1/push/devices            — لیست دستگاه‌های من (توکن ماسک‌شده)
 *   POST /api/v1/push/devices            — ثبت/تازه‌سازی توکن دستگاه (idempotent)
 *   POST /api/v1/push/devices/{id}/revoke — حذف یک دستگاه (گارد مالکیت)
 *
 * اسکوپ‌ها: خواندن = user.read (هم‌قواعد sessionsList)؛ ثبت/حذف = user.write
 * (هم‌قواعد sessionsRevoke). پلتفرم‌های مجاز همان سه‌تای FcmService است
 * (web/android/ios).
 */
class PushDeviceController extends BaseApiController
{
    private FcmService $fcmService;

    public function __construct(
        FcmService $fcmService,
        ?LoggerInterface $logger = null,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?PolicyService $policyService = null
    ) {
        parent::__construct($session, $request, $response, $policyService, $logger);
        $this->fcmService = $fcmService;
    }

    /**
     * GET /api/v1/push/devices — لیست دستگاه‌های ثبت‌شدهٔ کاربر جاری.
     * توکن هرگز کامل برگردانده نمی‌شود (ماسک ۸ کاراکتری) — FIX-MOBILE-03.
     */
    public function index(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $devices = $this->fcmService->listDevices($userId);
        $this->success([
            'devices'       => $devices,
            'push_enabled'  => $this->fcmService->isConfigured(),
            'total'         => count($devices),
        ]);
    }

    /**
     * POST /api/v1/push/devices — ثبت/تازه‌سازی توکن دستگاه.
     *
     * body: token (الزامی)، platform (web|android|ios — پیش‌فرض android)،
     *       device_name (اختیاری، ≤۱۲۰ کاراکتر)
     *
     * Idempotent: ثبت دوبارهٔ همان توکن فقط last_activity را تازه می‌کند؛
     * توکنِ متعلق به دستگاهِ دیگری مالکیت ردیف را منتقل می‌کند (FIX-MOBILE-02).
     */
    public function store(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $body = $this->request->body();
        $token = trim(str_value($body['token'] ?? ''));
        $platform = strtolower(trim(str_value($body['platform'] ?? 'android')));
        $deviceName = trim(str_value($body['device_name'] ?? ''));

        if ($token === '') {
            $this->validationError(['token' => ['توکن دستگاه الزامی است']]);
            return;
        }
        if (!in_array($platform, ['web', 'android', 'ios'], true)) {
            $this->validationError(['platform' => ['پلتفرم باید web، android یا ios باشد']]);
            return;
        }
        if ($deviceName !== '' && (mb_strlen($deviceName, 'UTF-8') > 120 || preg_match('/[\x00-\x1F\x7F]/', $deviceName) === 1)) {
            $this->validationError(['device_name' => ['نام دستگاه حداکثر ۱۲۰ کاراکتر و بدون کاراکتر کنترلی باشد']]);
            return;
        }

        $saved = $this->fcmService->saveUserToken(
            $userId,
            $token,
            $platform,
            $deviceName !== '' ? $deviceName : null
        );

        if (!$saved) {
            $this->error('توکن یا پلتفرم نامعتبر است', 422, 'INVALID_DEVICE_TOKEN');
            return;
        }

        $this->success(['registered' => true, 'platform' => $platform], 'دستگاه با موفقیت ثبت شد', 201);
    }

    /**
     * POST /api/v1/push/devices/{id}/revoke — حذف یک دستگاه (فقط مالک).
     */
    public function revoke(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $deviceId = $this->request->int('id');
        if ($deviceId <= 0) {
            $this->validationError(['id' => ['شناسهٔ دستگاه نامعتبر است']]);
            return;
        }

        $removed = $this->fcmService->removeDeviceById($userId, $deviceId);
        if (!$removed) {
            $this->error('دستگاه یافت نشد', 404, 'DEVICE_NOT_FOUND');
            return;
        }

        $this->success(['revoked' => true], 'دستگاه حذف شد');
    }
}
