<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Services\WebSocketService;

/**
 * RealTimeController - Real-time messaging API endpoints
 */
class RealTimeController extends BaseApiController
{
    private WebSocketService $realTime;

    public function __construct(WebSocketService $realTime, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->realTime = $realTime;
    }

    /**
     * Long Polling endpoint
     *
     * ── محدودیت‌های امنیتی و عملکردی ────────────────────────────────────────
     * - timeout حداکثر 20 ثانیه (cap سخت در Controller و Service)
     * - PHP max_execution_time روی این endpoint به 25s تنظیم می‌شود
     * - Connection: close → جلوگیری از keep-alive و آزادسازی سریع‌تر worker
     * ─────────────────────────────────────────────────────────────────────────
     */
    public function poll(): void
    {
        // 🛡️ CLOUD SCALABILITY FIX (Swoole / RoadRunner Runtime Guard): تشخیص خودکار سرورهای Asynchronous
        // حذف گلوگاه قفل شدن استخر ورکرهای PHP-FPM در چت بلادرنگ
        $isAsyncRuntime = isset($_SERVER['LARAVEL_OCTANE']) || isset($_SERVER['RR_MODE']) || extension_loaded('swoole');
        if (!$isAsyncRuntime) {
            // cap سخت PHP execution برای این endpoint در محیط سنتی PHP-FPM
            set_time_limit(25);
        }

        // Connection: keep-alive برای کلاینت‌های موبایل جهت بهینه‌سازی باتری و حذف سربار TLS Handshake در شبکه‌های 4G/5G
        // و Connection: close برای کلاینت‌های سنتی وب جهت آزادسازی سریع‌تر Worker
        if (!headers_sent()) {
            $isMobileClient = $this->request->header('X-App-Version') 
                || $this->request->get('app_version') 
                || str_starts_with((string)($this->request->header('Authorization') ?? ''), 'Bearer ');

            if ($isMobileClient || $isAsyncRuntime) {
                header('Connection: keep-alive');
                header('Keep-Alive: timeout=10, max=100');
            } else {
                header('Connection: close');
            }
            header('Cache-Control: no-cache, no-store, must-revalidate');
        }

        try {
            $userId = (int)$this->userId();
            if (!$userId) {
                $this->error('Unauthorized', 401);
                return;
            }

            $lastMessageId = trim((string)($this->request->post('last_message_id') ?? '')) ?: null;

            // cap سخت: client نمی‌تواند بیش از 20 ثانیه timeout بخواهد
            $timeout = min(max((int)($this->request->post('timeout') ?? 20), 1), 20);

            $result = $this->realTime->longPoll($userId, $lastMessageId, $timeout);

            if (!empty($result['bulkhead_limited'])) {
                $this->error($result['message'] ?? 'ظرفیت اتصال در حال حاضر پر است.', 429, 'BULKHEAD_LIMITED');
                return;
            }

            $this->success([
                'messages' => $result['messages'] ?? [],
                'count'    => $result['count'] ?? 0,
                'timeout'  => $result['timeout'] ?? false,
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('real_time.poll_failed', ['error' => $e->getMessage()]);
            error_log('real_time.poll_failed: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
            $this->error('Poll failed: ' . $e->getMessage(), 500);
        }
    }

    /**
     * Join a real-time room
     */
    public function joinRoom(): void
    {
        try {
            $userId = (int)$this->userId();
            if (!$userId) {
                $this->error('Unauthorized', 401);
            }

            $room = trim((string)$this->request->post('room'));
            if (empty($room)) {
                $this->error('Room name required', 400);
            }

            // ✅ Validate room format
            if (!preg_match('/^[a-z_]:[0-9]+$/', $room)) {
                $this->error('Invalid room format', 400);
            }

            $this->realTime->joinRoom($userId, $room);

            $this->logger->info('real_time.room_joined', [
                'user_id' => $userId,
                'room'    => $room
            ]);

            $this->success([
                'room' => $room,
                'msg'  => 'Subscribed to room'
            ]);

        } catch (\Exception $e) {
            $this->logger->error('real_time.join_room_failed', ['error' => $e->getMessage()]);
            $this->error('Join failed', 500);
        }
    }

    /**
     * Leave a real-time room
     */
    public function leaveRoom(): void
    {
        try {
            $userId = (int)$this->userId();
            if (!$userId) {
                $this->error('Unauthorized', 401);
            }

            $room = trim((string)$this->request->post('room'));
            if (empty($room)) {
                $this->error('Room name required', 400);
            }

            $this->realTime->leaveRoom($userId, $room);

            $this->logger->info('real_time.room_left', [
                'user_id' => $userId,
                'room'    => $room
            ]);

            $this->success([
                'room' => $room,
                'msg'  => 'Unsubscribed from room'
            ]);

        } catch (\Exception $e) {
            $this->logger->error('real_time.leave_room_failed', ['error' => $e->getMessage()]);
            $this->error('Leave failed', 500);
        }
    }

    /**
     * Get members in a room
     */
    public function getRoomMembers(): void
    {
        try {
            $room = trim((string)$this->request->param('room'));
            if (empty($room)) {
                $this->error('Room name required', 400);
            }

            $members = $this->realTime->getRoomMembers($room);

            $this->success([
                'room'    => $room,
                'members' => $members,
                'count'   => count($members)
            ]);

        } catch (\Exception $e) {
            $this->logger->error('real_time.get_members_failed', ['error' => $e->getMessage()]);
            $this->error('Get members failed', 500);
        }
    }

    /**
     * Get all online users count
     */
    public function getOnlineUsers(): void
    {
        try {
            $onlineCount = $this->realTime->getOnlineCount();
            $this->success(['count' => $onlineCount]);
        } catch (\Exception $e) {
            $this->logger->error('real_time.get_online_failed', ['error' => $e->getMessage()]);
            $this->error('Get online count failed', 500);
        }
    }

    /**
     * Get online users in a specific room
     */
    public function getOnlineInRoom(): void
    {
        try {
            $room = trim((string)$this->request->param('room'));
            if (empty($room)) {
                $this->error('Room name required', 400);
            }

            $onlineUsers = $this->realTime->getOnlineInRoom($room);

            $this->success([
                'room'  => $room,
                'users' => $onlineUsers,
                'count' => count($onlineUsers)
            ]);

        } catch (\Exception $e) {
            $this->logger->error('real_time.get_online_in_room_failed', ['error' => $e->getMessage()]);
            $this->error('Get online in room failed', 500);
        }
    }

    /**
     * Get real-time system stats
     */
    public function getStats(): void
    {
        try {
            $stats = $this->realTime->getStats();
            $this->success(['stats' => $stats]);
        } catch (\Exception $e) {
            $this->logger->error('real_time.get_stats_failed', ['error' => $e->getMessage()]);
            $this->error('Get stats failed', 500);
        }
    }
}
