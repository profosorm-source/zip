<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Services\Interaction\FavoriteService;
use App\Services\Interaction\RatingService;
use App\Services\Interaction\ReportService;
use App\Enums\ModuleContext;
use Core\Validator;

/**
 * InteractionApiController - نقطه پایانی واحد برای تمامی تعاملات (لایک، امتیاز، ریپورت) به صورت پلیمورفیک
 */
class InteractionApiController extends BaseApiController
{
    private FavoriteService $favoriteService;
    private RatingService $ratingService;
    private ReportService $reportService;
    private \App\Services\VitrineService $vitrineService;

    public function __construct(
        FavoriteService $favoriteService,
        RatingService $ratingService,
        ReportService $reportService,
        \App\Services\VitrineService $vitrineService
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->favoriteService = $favoriteService;
        $this->ratingService = $ratingService;
        $this->reportService = $reportService;
        $this->vitrineService = $vitrineService;
    }

    /** لیست آگهی‌های ویترین */
    public function vitrineList(): never
    {
        [$page, $perPage, $offset] = $this->paginationParams(20);
        $filters = $this->request->get() ?: [];
        $result = $this->vitrineService->getListings($filters, $perPage, $offset);
        $this->paginated($result['listings'] ?? [], $result['total'] ?? 0, $page, $perPage);
    }

    /** نمایش جزئیات آگهی ویترین */
    public function vitrineShow(): never
    {
        $userId = $this->userId();
        $id = (int)($this->request->get('id') ?? 0);
        $details = $this->vitrineService->getListingDetails($id, $userId);
        if (!$details) {
            $this->error('آگهی یافت نشد یا دسترسی مجاز نیست', 404, 'VITRINE_NOT_FOUND');
        }
        $this->success($details);
    }

    /** ثبت درخواست معامله در ویترین */
    public function vitrineTradeRequest(): never
    {
        $userId = $this->userId();
        $id = (int)($this->request->get('id') ?? 0);
        $data = $this->request->body();
        $check = $this->vitrineService->canTrade($userId);
        if (empty($check['ok'])) {
            $this->error($check['message'] ?? 'مجاز به معامله نیستید', 403);
        }
        $requestModel = $this->container->make(\App\Models\VitrineRequest::class);
        try {
            $reqId = $requestModel->create(array_merge($data, ['listing_id' => $id, 'buyer_id' => $userId, 'status' => 'pending']));
            $this->success(['request_id' => $reqId], 'درخواست معامله با موفقیت ثبت شد', 201);
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->error('خطا در ثبت درخواست معامله: ' . $e->getMessage(), 422);
        }
    }

    /**
     * POST /api/v1/interactions/favorite/toggle
     */
    public function toggleFavorite(): void
    {
        $user = $this->currentUser();
        $body = $this->request->body();

        $validator = Validator::create($body, [
            'type' => 'required|string|max:50',
            'id'   => 'required|integer|min:1',
            'context' => 'required|string|max:50',
        ]);

        if ($validator->fails()) {
            $this->error('اطلاعات ورودی نامعتبر است.', 422, $validator->errors());
        }

        $data = $validator->data();
        $context = ModuleContext::tryFrom($data['context']) ?? ModuleContext::GLOBAL;

        $success = $this->favoriteService->toggle(
            $user->id,
            $data['type'],
            (int)$data['id'],
            $context
        );

        if ($success) {
            $hasFavorited = $this->favoriteService->hasFavorited($user->id, $data['type'], (int)$data['id']);
            $this->success([
                'message' => 'عملیات با موفقیت انجام شد.',
                'is_favorited' => $hasFavorited
            ]);
        } else {
            $this->error('خطا در ثبت علاقه‌مندی.', 500);
        }
    }

    /**
     * POST /api/v1/interactions/rate
     */
    public function rate(): void
    {
        $user = $this->currentUser();
        $body = $this->request->body();

        $validator = Validator::create($body, [
            'type' => 'required|string|max:50',
            'id'   => 'required|integer|min:1',
            'rating' => 'required|integer|min:1|max:5',
            'context' => 'required|string|max:50',
        ]);

        if ($validator->fails()) {
            $this->error('اطلاعات ورودی نامعتبر است.', 422, $validator->errors());
        }

        $data = $validator->data();
        $context = ModuleContext::tryFrom($data['context']) ?? ModuleContext::GLOBAL;

        $success = $this->ratingService->rate(
            $user->id,
            $data['type'],
            (int)$data['id'],
            $context,
            (int)$data['rating']
        );

        if ($success) {
            $average = $this->ratingService->getAverageRating($data['type'], (int)$data['id']);
            $this->success([
                'message' => 'امتیاز با موفقیت ثبت شد.',
                'average_rating' => $average
            ]);
        } else {
            $this->error('خطا در ثبت امتیاز.', 500);
        }
    }

    /**
     * POST /api/v1/interactions/report
     */
    public function report(): void
    {
        $user = $this->currentUser();
        $body = $this->request->body();

        $validator = Validator::create($body, [
            'type' => 'required|string|max:50',
            'id'   => 'required|integer|min:1',
            'reason' => 'required|string|min:3|max:100',
            'description' => 'nullable|string|max:1000',
            'context' => 'required|string|max:50',
        ]);

        if ($validator->fails()) {
            $this->error('اطلاعات ورودی نامعتبر است.', 422, $validator->errors());
        }

        $data = $validator->data();
        $context = ModuleContext::tryFrom($data['context']) ?? ModuleContext::GLOBAL;

        $success = $this->reportService->submit(
            $user->id,
            $data['type'],
            (int)$data['id'],
            $context,
            $data['reason'],
            $data['description'] ?? null
        );

        if ($success) {
            $this->success([
                'message' => 'گزارش شما با موفقیت ثبت شد و بررسی خواهد شد.'
            ]);
        } else {
            $this->error('خطا در ثبت گزارش.', 500);
        }
    }
}
