<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Services\Interaction\FavoriteService;
use App\Services\Interaction\RatingService;
use App\Services\Interaction\ReportService;
use App\Enums\ModuleContext;
use App\Validators\Requests\ToggleFavoriteRequest;
use App\Validators\Requests\RateInteractionRequest;
use App\Validators\Requests\ReportInteractionRequest;

/**
 * InteractionApiController - نقطه پایانی واحد برای تمامی تعاملات (لایک، امتیاز، ریپورت) به صورت پلیمورفیک
 */
class InteractionApiController extends BaseApiController
{
    private FavoriteService $favoriteService;
    private RatingService $ratingService;
    private ReportService $reportService;
    private \App\Services\VitrineService $vitrineService;
    private \App\Models\VitrineRequest $requestModel;

    public function __construct(
        FavoriteService $favoriteService,
        RatingService $ratingService,
        ReportService $reportService,
        \App\Services\VitrineService $vitrineService,
        // 🧹 DI-CLEANUP (2026-08-24): به‌جای container->make در بدنه‌ی متد.
        \App\Models\VitrineRequest $requestModel
        , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->favoriteService = $favoriteService;
        $this->ratingService = $ratingService;
        $this->reportService = $reportService;
        $this->vitrineService = $vitrineService;
        $this->requestModel = $requestModel;
    }

    /** لیست آگهی‌های ویترین */
    public function vitrineList(): void
    {
        [$page, $perPage, $offset] = $this->paginationParams(20);
        $rawFilters = $this->request->get();
        $filters = is_array($rawFilters) ? $rawFilters : [];
        $result = $this->vitrineService->getListings($filters, $perPage, $offset);
        $total = is_numeric($result['total'] ?? null) ? (int)$result['total'] : 0;
        $listings = is_array($result['listings'] ?? null) ? $result['listings'] : [];
        $this->paginated($listings, $total, $page, $perPage);
    }

    /** نمایش جزئیات آگهی ویترین */
    public function vitrineShow(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $details = $this->vitrineService->getListingDetails($id, $userId);
        if (!$details) {
            $this->error('آگهی یافت نشد یا دسترسی مجاز نیست', 404, 'VITRINE_NOT_FOUND');
        }
        $this->success($details);
    }

    /** ثبت درخواست معامله در ویترین */
    public function vitrineTradeRequest(): void
    {
        $userId = (int)$this->userId();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? 0);
        $data = $this->request->body();
        $check = $this->vitrineService->canTrade($userId);
        if (empty($check['ok'])) {
            $this->error($check['message'] ?? 'مجاز به معامله نیستید', 403);
        }
        if ($id <= 0) {
            $this->error('شناسه آگهی نامعتبر است', 422, 'INVALID_LISTING_ID');
        }
        // FIX-R2-09: گاردهای وجود/فعال/خودآگهی — قبلاً فقط در SendVitrineRequestJob
        // بودند و مسیر API مستقیم createRequest می‌زد؛ جدول vitrine_requests هم FK
        // به vitrine_listings ندارد. اکنون همان گاردهای جاب، اینجا هم اعمال می‌شوند.
        $listingModel = \Core\Container::getInstance()->make(\App\Models\VitrineListing::class);
        $listing = $listingModel->find($id);
        if (!$listing || (string)($listing->status ?? '') !== 'active') {
            $this->error('آگهی فعال نیست.', 404, 'VITRINE_NOT_ACTIVE');
        }
        if ((int)($listing->seller_id ?? 0) === $userId) {
            $this->error('نمی‌توانید به آگهی خود درخواست دهید.', 403, 'SELF_LISTING_REQUEST');
        }
        $requestModel = $this->requestModel;
        // FIX-R19-A4-1: بدنهٔ خام کلاینت به مدل mass-assign نمی‌شود — فقط فیلدهای مجاز
        // (offer_price/message) با اعتبارسنجی عددی/بازه‌ای آینهٔ VitrineController وب عبور می‌کنند؛
        // بقیه کلیدهای کلاینت دور ریخته می‌شوند.
        $body = is_array($data) ? $data : [];
        $offerPrice = null;
        $rawOffer = $body['offer_price'] ?? null;
        if ($rawOffer !== null && $rawOffer !== '' && is_scalar($rawOffer)
            && preg_match('/^\d+(\.\d+)?$/', (string) $rawOffer)) {
            $offerPrice = str_value((string) $rawOffer);
            $minPrice = str_value(setting('vitrine_min_price', '1'));
            $maxPrice = str_value(setting('vitrine_max_price', '100000'));
            if (bccomp($offerPrice, $minPrice, 8) < 0 || bccomp($offerPrice, $maxPrice, 8) > 0) {
                $this->error("قیمت پیشنهادی باید بین {$minPrice} و {$maxPrice} USDT باشد.", 422, 'INVALID_OFFER_PRICE');
            }
        }
        $rawMessage = $body['message'] ?? '';
        $payload = [
            'offer_price' => $offerPrice,
            'message'     => trim(str_value($rawMessage)),
        ];
        try {
            $reqId = $requestModel->createRequest(array_merge($payload, [
                'listing_id' => $id,
                'requester_id' => $userId,
                'buyer_id' => $userId,
                'status' => 'pending',
            ]));
            // FIX-R19-A4-1: null = درخواست pending تکراری (گارد رقابتی مدل) — موفقیت کاذب برنگردانیم
            if ($reqId === null) {
                $this->error('درخواست شما قبلاً ثبت شده و در انتظار پاسخ است.', 409, 'DUPLICATE_PENDING_REQUEST');
            }
            $this->success(['request_id' => $reqId], 'درخواست معامله با موفقیت ثبت شد', 201);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) {
            $this->logger->warning('api.vitrine_trade.failed', [
                'user_id' => $userId,
                'listing_id' => $id,
                'error' => $e->getMessage(),
            ]);
            $this->error('خطا در ثبت درخواست معامله', 422);
        }
    }

    /**
     * POST /api/v1/interactions/favorite/toggle
     */
    public function toggleFavorite(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $body = $this->request->body();

        $validator = new ToggleFavoriteRequest($body);
        $validator->validate();

        if ($validator->fails()) {
            $this->error('اطلاعات ورودی نامعتبر است.', 422, implode(', ', array_map(static fn($v) => is_array($v) ? implode(', ', $v) : str_value($v), $validator->errors())));
        }

        $data = $validator->safeValidated();
        // FIX-M1M3: مقدار نامعتبر دیگر صامت به GLOBAL تبدیل نمی‌شود — 422 (گارد دوم پس از rule in:)
        $context = ModuleContext::tryFrom(str_value($data['context']));
        if ($context === null) {
            $this->error('مقدار context نامعتبر است.', 422, 'INVALID_CONTEXT');
            // FIX-PSTAN: error() در عمل با HttpResponseException جریان را قطع می‌کند؛
            // این return هرگز اجرا نمی‌شود و فقط تحلیل ایستا را هم‌راستای واقعیت می‌کند.
            return;
        }

        $success = $this->favoriteService->toggle(
            $user->id,
            str_value($data['type']),
            int_value($data['id']),
            $context
        );

        if ($success) {
            $hasFavorited = $this->favoriteService->hasFavorited($user->id, str_value($data['type']), int_value($data['id']));
            $this->success([
                'message' => 'عملیات با موفقیت انجام شد.',
                'is_favorited' => $hasFavorited
            ]);
        } else {
            $this->error('خطا در ثبت علاقه‌مندی.', 500);
        }
    }

    /**
     * POST /api/v1/interactions/rate
     */
    public function rate(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $body = $this->request->body();

        $validator = new RateInteractionRequest($body);
        $validator->validate();

        if ($validator->fails()) {
            $this->error('اطلاعات ورودی نامعتبر است.', 422, implode(', ', array_map(static fn($v) => is_array($v) ? implode(', ', $v) : str_value($v), $validator->errors())));
        }

        $data = $validator->safeValidated();
        // FIX-M1M3: مقدار نامعتبر دیگر صامت به GLOBAL تبدیل نمی‌شود — 422 (گارد دوم پس از rule in:)
        $context = ModuleContext::tryFrom(str_value($data['context']));
        if ($context === null) {
            $this->error('مقدار context نامعتبر است.', 422, 'INVALID_CONTEXT');
            // FIX-PSTAN: error() در عمل با HttpResponseException جریان را قطع می‌کند؛
            // این return هرگز اجرا نمی‌شود و فقط تحلیل ایستا را هم‌راستای واقعیت می‌کند.
            return;
        }

        // 🛡️ FIX-SEO3-01 (تصمیم ۱ — هم‌ارز گارد وب برای API): امتیاز seo_task از
        // مسیر گاردشدهٔ سئو (SeoService→RateSeoTaskJob) می‌گذرد: فقط مجریِ اجرای
        // تکمیل‌شده، نه مالک کمپین، فقط آگهی type=seo. بدون این، فهرست ads که
        // حالا avg_rating نمایش می‌دهد با رأی بدون‌اجازه آلوده می‌شد.
        if (str_value($data['type']) === 'seo_task') {
            $seoResult = app(\App\Services\Seo\SeoService::class)->rateTask(
                (int)$user->id,
                int_value($data['id']),
                int_value($data['rating']),
                is_string($data['comment'] ?? null) ? str_value($data['comment']) : ''
            );
            if (empty($seoResult['success'])) {
                $this->error(str_value($seoResult['message'] ?? 'خطا در ثبت امتیاز.'), 422, 'SEO_RATE_GUARDED');
                return;
            }
            $this->success([
                'message' => 'امتیاز با موفقیت ثبت شد.',
                'average_rating' => $this->ratingService->getAverageRating('seo_task', int_value($data['id']))
            ]);
            return;
        }

        // 🛡️ FIX-SOCGUARD-01 (بستن حفرهٔ pre-existing — قرینهٔ seo_task): امتیاز
        // social_task قبلاً بی‌گارد مستقیم به RatingService می‌رفت؛ در حالی که
        // همین API عمومی تنها مسیر زندهٔ امتیازدهی سوشیال است (روت وب
        // rateExecution عمداً غیرفعال 422 و SocialTaskApiController اندپوینت
        // امتیاز/گزارش ندارد). اکنون از مسیر گاردشدهٔ SocialTaskService می‌گذرد:
        // مالک کمپین به خودش امتیاز نمی‌دهد، فقط مجریِ اجرای تأییدشدهٔ همین
        // تسک، ستاره‌ها ۱..۵ و کامنت حفظ می‌شود (FIX-R15C).
        if (str_value($data['type']) === 'social_task') {
            $socialResult = app(\App\Services\SocialTask\SocialTaskService::class)->rateTask(
                (int)$user->id,
                int_value($data['id']),
                int_value($data['rating']),
                is_string($data['comment'] ?? null) ? str_value($data['comment']) : ''
            );
            if (empty($socialResult['success'])) {
                $this->error(str_value($socialResult['message'] ?? 'خطا در ثبت امتیاز.'), 422, 'SOCIAL_RATE_GUARDED');
                return;
            }
            $this->success([
                'message' => 'امتیاز با موفقیت ثبت شد.',
                'average_rating' => $this->ratingService->getAverageRating('social_task', int_value($data['id']))
            ]);
            return;
        }

        $success = $this->ratingService->rate(
            $user->id,
            str_value($data['type']),
            int_value($data['id']),
            $context,
            int_value($data['rating'])
        );

        if ($success) {
            $average = $this->ratingService->getAverageRating(str_value($data['type']), int_value($data['id']));
            $this->success([
                'message' => 'امتیاز با موفقیت ثبت شد.',
                'average_rating' => $average
            ]);
        } else {
            $this->error('خطا در ثبت امتیاز.', 500);
        }
    }

    /**
     * POST /api/v1/interactions/report
     */
    public function report(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $body = $this->request->body();

        $validator = new ReportInteractionRequest($body);
        $validator->validate();

        if ($validator->fails()) {
            $this->error('اطلاعات ورودی نامعتبر است.', 422, implode(', ', array_map(static fn($v) => is_array($v) ? implode(', ', $v) : str_value($v), $validator->errors())));
        }

        $data = $validator->safeValidated();
        // FIX-M1M3: مقدار نامعتبر دیگر صامت به GLOBAL تبدیل نمی‌شود — 422 (گارد دوم پس از rule in:)
        $context = ModuleContext::tryFrom(str_value($data['context']));
        if ($context === null) {
            $this->error('مقدار context نامعتبر است.', 422, 'INVALID_CONTEXT');
            // FIX-PSTAN: error() در عمل با HttpResponseException جریان را قطع می‌کند؛
            // این return هرگز اجرا نمی‌شود و فقط تحلیل ایستا را هم‌راستای واقعیت می‌کند.
            return;
        }

        // 🛡️ FIX-SEO3-01 (تصمیم ۱ — هم‌ارز گارد وب برای API): گزارش seo_task از
        // مسیر گاردشدهٔ سئو (SeoService→ReportSeoTaskJob) می‌گذرد: فقط مجریِ همین
        // آگهی (started/completed)، فقط آگهی type=seo — هم‌ارز دقیق روت وب جدید.
        if (str_value($data['type']) === 'seo_task') {
            $seoResult = app(\App\Services\Seo\SeoService::class)->reportTask(
                (int)$user->id,
                int_value($data['id']),
                str_value($data['reason']),
                is_string($data['description'] ?? null) ? str_value($data['description']) : ''
            );
            if (empty($seoResult['success'])) {
                $this->error(str_value($seoResult['message'] ?? 'خطا در ثبت گزارش.'), 422, 'SEO_REPORT_GUARDED');
                return;
            }
            $this->success(['message' => 'گزارش شما با موفقیت ثبت شد و بررسی خواهد شد.']);
            return;
        }

        // 🛡️ FIX-SOCGUARD-01 (قرینهٔ seo_task — گزارش): گزارش social_task قبلاً
        // بی‌گارد مستقیم به ReportService می‌رفت (بدون حتی چک وجود آگهی). اکنون
        // از مسیر استاندارد SocialTaskService می‌گذرد: آگهی باید واقعاً موجود
        // باشد و دلیل/توضیح الزامی است؛ dedupe اتمیک ۲۴ساعته و آلارم ادمین در
        // سرویس مشترک تعاملات پابرجا است — هم‌قرارداد مسیر وب سوشیال.
        if (str_value($data['type']) === 'social_task') {
            $socialResult = app(\App\Services\SocialTask\SocialTaskService::class)->reportTask(
                (int)$user->id,
                int_value($data['id']),
                str_value($data['reason']),
                is_string($data['description'] ?? null) ? str_value($data['description']) : ''
            );
            if (empty($socialResult['success'])) {
                $this->error(str_value($socialResult['message'] ?? 'خطا در ثبت گزارش.'), 422, 'SOCIAL_REPORT_GUARDED');
                return;
            }
            $this->success(['message' => 'گزارش شما با موفقیت ثبت شد و بررسی خواهد شد.']);
            return;
        }

        $success = $this->reportService->submit(
            $user->id,
            str_value($data['type']),
            int_value($data['id']),
            $context,
            str_value($data['reason']),
            is_string($data['description'] ?? null) ? $data['description'] : null
        );

        if ($success) {
            $this->success([
                'message' => 'گزارش شما با موفقیت ثبت شد و بررسی خواهد شد.'
            ]);
        } else {
            $this->error('خطا در ثبت گزارش.', 500);
        }
    }
}
