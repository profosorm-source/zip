<?php

namespace App\Controllers\Api;

use App\Services\SocialTask\SocialTaskService;
use App\Services\SocialTask\SilentAntiFraudService;
use App\Services\SocialTask\CameraVerificationService;
use App\Services\SocialTask\BehaviorAnalysisService;
use App\Services\Gamification\TrustService;
use App\Enums\ModuleContext;
use App\Services\User\UserService;

/**
 * SocialTaskApiController - API برای سیستم وظایف اجتماعی
 *
 * Endpoints:
 * - GET /api/v1/social/accounts
 * - POST /api/v1/social/accounts
 * - PUT /api/v1/social/accounts/{id}
 * - DELETE /api/v1/social/accounts/{id}
 * - GET /api/v1/social/ads
 * - POST /api/v1/social/ads
 * - GET /api/v1/social/ads/{id}
 * - POST /api/v1/social/ads/{id}/pause
 * - POST /api/v1/social/ads/{id}/resume
 * - POST /api/v1/social/ads/{id}/cancel
 * - GET /api/v1/social/tasks
 * - POST /api/v1/social/tasks/{id}/start
 * - POST /api/v1/social/tasks/{id}/submit
 * - GET /api/v1/social/tasks/history
 * 
 * FIX-S12-1 (تصمیم کاربر، گزینهٔ الف) — مسیرهای تأیید رفتاری/دوربینی از
 * /api/social-tasks/* به پیشوند غیر-api منتقل شدند (قرارداد CORE-037:
 * سشن زیر /api/ ممنوع = 401 همیشگی؛ اثبات S11). این endpointها هم‌مبدأِ
 * مرورگرند (فراخوانی از usersocialtasksexecute.js با سشن + X-CSRF-Token):
 * - POST /social-tasks/verify/behavior          (گروه $tasksSecure — سشن+CSRF)
 * - POST /social-tasks/verify/camera-challenge  (گروه $tasksSecure — سشن+CSRF؛ 🛡️ FIX-F21-01: تحویل nonce یک‌بارمصرف)
 * - POST /social-tasks/verify/camera-verify     (گروه $tasksSecure — سشن+CSRF؛ 🛡️ FIX-F21-01: مصرف nonce + تحلیل آماری سمت‌سرور)
 * - GET  /social-tasks/verify/trust-status      (گروه $tasksAuth  — سشن)
 *
 * resolveUser(): هویتِ سشن اول، سپس Request user (Bearer — برای مهاجرت آتی).
 *
 * توجه: متدهای /api/v1/social/* فهرست‌شدهٔ قدیمی در routes ثبت نشده‌اند
 * (docblock کهنه بود — یادداشت consult ممیزی S12).
 */
class SocialTaskApiController extends BaseApiController
{
    private SocialTaskService      $service;
    private TrustService           $trust;
    private ?CameraVerificationService $cameraVerification;
    private ?BehaviorAnalysisService $behaviorAnalysis;
    private UserService $userService;
    /** @var \App\Services\Interaction\RatingService|null 🛡️ FIX-SOCRATE-DISPLAY-01: سرویس امتیاز (اختیاری — lazy از کانتینر) */
    private ?\App\Services\Interaction\RatingService $ratingService = null;

    public function __construct(
        SocialTaskService $service,
        TrustService $trust,
        UserService $userService,
        ?CameraVerificationService $cameraVerification = null,
        ?BehaviorAnalysisService $behaviorAnalysis = null,
        ?\App\Contracts\LoggerInterface $logger = null,
        ?\App\Services\Interaction\RatingService $ratingService = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->service     = $service;
        $this->trust       = $trust;
        $this->userService = $userService;
        $this->cameraVerification = $cameraVerification;
        $this->behaviorAnalysis = $behaviorAnalysis;
        // 🛡️ FIX-SOCRATE-DISPLAY-01: سرویس امتیاز برای avg_rating فهرست —
        // اختیاری (تست‌ها mock تزریق می‌کنند؛ production از کانتینر).
        $this->ratingService = $ratingService;
    }

    /** 🛡️ FIX-SOCRATE-DISPLAY-01: سرویس امتیاز به‌صورت lazy (nullable از سازنده یا کانتینر) */
    private function ratingService(): \App\Services\Interaction\RatingService
    {
        return $this->ratingService ??= app(\App\Services\Interaction\RatingService::class);
    }

    // ═════════════════════════════════════════════════════════════
    // SOCIAL ACCOUNTS
    // ═════════════════════════════════════════════════════════════

    /**
     * لیست حساب‌های اجتماعی کاربر
     * GET /api/v1/social/accounts
     */
    public function accounts(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $accounts = $this->service->getUserAccounts($user->id);
        $this->success($accounts);
    }

    /**
     * ایجاد حساب اجتماعی جدید
     * POST /api/v1/social/accounts
     */
    public function storeAccount(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $data = $this->request->body();

        $platform = trim(str_value($data['platform'] ?? ''));
        $account_handle = trim(str_value($data['account_handle'] ?? ''));
        $access_token = trim(str_value($data['access_token'] ?? ''));

        if (empty($platform) || empty($account_handle)) {
            $this->validationError(['platform' => 'الزامی', 'account_handle' => 'الزامی']);
        }

        $result = $this->service->addAccount($user->id, $platform, $account_handle, $access_token);
        $this->success($result);
    }

    /**
     * به‌روزرسانی حساب اجتماعی
     * PUT /api/v1/social/accounts/{id}
     */
    public function updateAccount(string $id): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $data = $this->request->body();
        $result = $this->service->updateUserAccount($user->id, (int)$id, $data);
        
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'یافت نشد'), 404);
            return;
        }

        $this->success($result);
    }

    /**
     * حذف حساب اجتماعی
     * DELETE /api/v1/social/accounts/{id}
     */
    public function deleteAccount(string $id): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $result = $this->service->deleteUserAccount($user->id, (int)$id);
        
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'یافت نشد'), 404);
            return;
        }

        $this->success($result);
    }

    // ═════════════════════════════════════════════════════════════
    // ADVERTISEMENTS
    // ═════════════════════════════════════════════════════════════

    /**
     * لیست تبلیغات کاربر
     * GET /api/v1/social/ads
     */
    public function myAds(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        [$page, $perPage, $offset] = $this->paginationParams();
        [$ads, $total] = $this->service->getUserAds($user->id, $perPage, $offset);

        // 🛡️ FIX-SOCRATE-MOBILE-01 (قرینهٔ tasks و پنل وب /ads/{id} — کارت
        // بازخورد مجریان): کمپین‌های خود تبلیغ‌دهنده هم میانگین رأی کاربران
        // را در همان ردیف‌ها برمی‌گردانند. یک کوئری batch برای کل صفحه؛
        // بدون رأی = صفر صادقانه (نه حذف کلید).
        $adIds = [];
        foreach ($ads as $a) {
            if (is_object($a)) {
                $adIds[] = (int)($a->id ?? 0);
            }
        }
        $ratingsSummary = $adIds === [] ? [] : $this->ratingService()->getRatingsSummary('social_task', $adIds);
        foreach ($ads as $a) {
            if (!is_object($a)) {
                continue;
            }
            $s = $ratingsSummary[(int)($a->id ?? 0)] ?? null;
            $a->avg_rating   = isset($s['avg']) ? (float)$s['avg'] : 0.0;
            $a->rating_count = isset($s['count']) ? (int)$s['count'] : 0;
        }

        $this->paginated($ads, $total, $page, $perPage);
    }

    /**
     * ایجاد تبلیغ جدید
     * POST /api/v1/social/ads
     */
    public function createAd(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $data = $this->request->body();

        $result = $this->service->createUserAd($user->id, $data);

        if (!$result['success']) {
            $this->validationError(['ad' => $result['message']]);
            return;
        }

        $this->success($result, 'تبلیغ ایجاد شد', 201);
    }

    /**
     * نمایش تبلیغ
     * GET /api/v1/social/ads/{id}
     */
    public function showAd(string $id): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $ad = $this->service->getAdById((int)$id);
        
        if (!$ad) {
            $this->error('تبلیغ پیدا نشد', 404);
            return;
        }

        $adObj = (object)(array)$ad;
        $adUserId = (int)($adObj->user_id ?? 0);
        $isAdmin = in_array($user->role ?? '', ['admin', 'super_admin'], true);

        // 🛡️ FIX-SOCRATE-MOBILE-01: ستاره‌های رأی کاربران در جزئیات تک‌کمپین —
        // دادهٔ عمومی است (همان عدد فهرست tasks؛ گارد IDOR فقط فیلدهای مالکانه
        // را حذف می‌کند). فقط نوع سوشیال تا id آگهی غیرسوشیال، رأیِ کمپین
        // سوشیالِ هم‌شماره را تصادفاً نگیرد.
        $adKey = (int)($adObj->id ?? 0) ?: (int)$id;
        $isSocialType = in_array((string)($adObj->type ?? ''), ['social', 'social_task'], true);
        $ratingSummary = $isSocialType
            ? ($this->ratingService()->getRatingsSummary('social_task', [$adKey])[$adKey] ?? null)
            : null;

        // 🛡️ IDOR Guard (Issue #5): Sanitize sensitive campaign details for non-owner users
        if ($adUserId !== (int)$user->id && !$isAdmin) {
            $adData = [
                'id' => $adObj->id ?? (int)$id,
                'type' => $adObj->type ?? 'social_task',
                'title' => $adObj->title ?? '',
                'description' => $adObj->description ?? '',
                'target_url' => $adObj->target_url ?? $adObj->link ?? '',
                'platform' => $adObj->platform ?? 'general',
                'action_type' => $adObj->action_type ?? 'view',
                'reward_amount' => $adObj->price_per_task ?? $adObj->reward_amount ?? 0,
                'status' => $adObj->status ?? 'active',
            ];
            // 🛡️ FIX-SOCRATE-MOBILE-01: ستاره‌های عمومی + رأی فعلی کاربر —
            // my_rating قرینهٔ «امتیاز فعلی شما» صفحهٔ اجرای وب است (null =
            // هنوز رأی نداده) تا اپ فرم ستاره را هیدراته کند (رأی مجدد =
            // به‌روزرسانی همان ردیف).
            if ($isSocialType) {
                $adData['avg_rating']   = isset($ratingSummary['avg']) ? (float)$ratingSummary['avg'] : 0.0;
                $adData['rating_count'] = isset($ratingSummary['count']) ? (int)$ratingSummary['count'] : 0;
                $adData['my_rating']    = $this->ratingService()->getUserRating((int)$user->id, 'social_task', $adKey);
            }
            $this->success($adData);
            return;
        }

        // 🛡️ FIX-SOCRATE-MOBILE-01: مالک هم قرینهٔ پنل وب (/ads/{id} — کارت
        // بازخورد مجریان) میانگین و تعداد را در پاسخ کامل می‌بیند (بدون
        // my_rating — مالک به کمپین خودش رأی نمی‌دهد: گارد تضاد منافع).
        // گارد stdClass: getAdById آبجکت خام DB برمی‌گرداند — نوشتن فیلد
        // ستاره فقط روی همان نوع مجاز است (قرارداد PHPStan این سطح).
        if ($isSocialType && $ad instanceof \stdClass) {
            $ad->avg_rating   = isset($ratingSummary['avg']) ? (float)$ratingSummary['avg'] : 0.0;
            $ad->rating_count = isset($ratingSummary['count']) ? (int)$ratingSummary['count'] : 0;
        }

        $this->success($ad);
    }

    /**
     * توقف موقت تبلیغ
     * POST /api/v1/social/ads/{id}/pause
     */
    public function pauseAd(string $id): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $result = $this->service->pauseUserAd($user->id, (int)$id);
        
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'یافت نشد'), 404);
            return;
        }

        $this->success($result);
    }

    /**
     * از سر گیری تبلیغ
     * POST /api/v1/social/ads/{id}/resume
     */
    public function resumeAd(string $id): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $result = $this->service->resumeUserAd($user->id, (int)$id);
        
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'یافت نشد'), 404);
            return;
        }

        $this->success($result);
    }

    /**
     * لغو تبلیغ
     * POST /api/v1/social/ads/{id}/cancel
     */
    public function cancelAd(string $id): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $result = $this->service->cancelUserAd($user->id, (int)$id);
        
        if (!$result['success']) {
            $this->error(str_value($result['message'] ?? 'یافت نشد'), 404);
            return;
        }

        $this->success($result);
    }

    // ═════════════════════════════════════════════════════════════
    // TASKS
    // ═════════════════════════════════════════════════════════════

    /**
     * لیست وظایف موجود برای کاربر
     * GET /api/v1/social/tasks
     */
    public function tasks(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        [$page, $perPage, $offset] = $this->paginationParams();
        // FIX-R36-W3 (F-A19b-05): شناسهٔ کاربر برای گارد ضدتکرار (tasks با اجرای
        // pending/completed همان کاربر در فهرست نمی‌آیند — هم‌راستا با getActiveAds).
        [$tasks, $total] = $this->service->getAvailableTasksForExecutor($perPage, $offset, (int)$user->id);

        // 🛡️ FIX-SOCRATE-DISPLAY-01 (قرینهٔ FIX-SEO3-01 در SeoTaskApiController):
        // میانگین رأی کاربران به کمپین سوشیال در همان ردیف‌های فهرست — یک
        // کوئری batch برای کل صفحه؛ بدون رأی = صفر صادقانه (نه حذف کلید).
        // رأی‌ها فقط از مجریِ اجرای تأییدشده ثبت می‌شوند (گاردِ سرویس سوشیال) پس
        // این عدد قابل‌اعتماد است.
        $adIds = [];
        foreach ($tasks as $t) {
            if (is_object($t)) {
                $adIds[] = (int)($t->id ?? 0);
            }
        }
        $ratingsSummary = $adIds === [] ? [] : $this->ratingService()->getRatingsSummary('social_task', $adIds);
        foreach ($tasks as $t) {
            if (!is_object($t)) {
                continue;
            }
            $s = $ratingsSummary[(int)($t->id ?? 0)] ?? null;
            $t->avg_rating   = isset($s['avg']) ? (float)$s['avg'] : 0.0;
            $t->rating_count = isset($s['count']) ? (int)$s['count'] : 0;
        }

        $this->paginated($tasks, $total, $page, $perPage);
    }

    /**
     * شروع اجرای وظیفه
     * POST /api/v1/social/tasks/{id}/start
     */
    public function startTask(string $id): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $result = $this->service->startTask($user->id, (int)$id);
        $this->success($result);
    }

    /**
     * ارسال نتیجه وظیفه
     * POST /api/v1/social/tasks/{id}/submit
     */
    public function submitTask(string $id): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $data = $this->request->body();

        $result = $this->service->submitTask($user->id, (int)$id, $data);
        $this->success($result);
    }

    /**
     * تاریخچه وظایف کاربر
     * GET /api/v1/social/tasks/history
     */
    public function history(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        [$page, $perPage, $offset] = $this->paginationParams();
        [$history, $total] = $this->service->getUserExecutionHistory($user->id, $perPage, $offset);
        $this->paginated($history, $total, $page, $perPage);
    }

    // ═════════════════════════════════════════════════════════════
    // LEGACY ENDPOINTS (برای سازگاری عقب‌رو)
    // ═════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────
    // ثبت behavior signals (موبایل در حین انجام)
    // ─────────────────────────────────────────────────────────────

    /**
     * POST /social-tasks/verify/behavior
     * Body: {
     *   execution_id: int,
     *   signals: {
     *     tap_count, swipe_count, scroll_count, touch_pauses,
     *     touch_timing_variance, scroll_speed_variance, scroll_pauses,
     *     session_duration, active_time, reconnect_count,
     *     app_blur_count, max_blur_duration,
     *     hesitation_count, avg_action_delay_ms, natural_delay_count
     *   }
     * }
     */
    public function recordBehavior(): void
    {
        $user = $this->resolveUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $body = $this->request->body();
        $executionId = int_value($body['execution_id'] ?? 0);
        $signals = (array)($body['signals'] ?? []);

        if (!$executionId) {
            $this->error('execution_id الزامی است', 400);
        }

        // فقط فیلدهای مجاز. توجه: camera فقط برای فلو مشکوک موبایل فعال می‌شود، نه برای همه تسک‌ها.
        $allowedSignals = [
            'tap_count', 'swipe_count', 'scroll_count', 'touch_pauses',
            'touch_timing_variance', 'scroll_speed_variance', 'scroll_pauses',
            'session_duration', 'active_time', 'expected_time', 'reconnect_count',
            'app_blur_count', 'max_blur_duration', 'is_mobile', 'client_mode', 'client_version',
            'hesitation_count', 'avg_action_delay_ms', 'natural_delay_count',
        ];
        $filtered = array_intersect_key($signals, array_flip($allowedSignals));

        $success = $this->service->recordBehaviorSignals($executionId, (int)$user->id, $filtered);

        $analysis = $this->behaviorAnalysis ? $this->behaviorAnalysis->analyze($filtered) : [];
        $behaviorScore = float_value($analysis['behavior_score'] ?? 100);
        $isMobile = !empty($filtered['is_mobile']) || (bool)preg_match('/Android|iPhone|iPad|Mobile/i', $this->request->userAgent());

        $cameraRequired = false;
        $cameraRequestId = null;
        if ($success && $isMobile && $this->cameraVerification) {
            try {
                if ($this->cameraVerification->isRequired($executionId, $behaviorScore, $filtered)) {
                    $cameraRequired = true;
                    $cameraRequestId = $this->cameraVerification->createRequest($executionId, (int)$user->id, 'mobile_camera', [
                        'client_mode' => $filtered['client_mode'] ?? 'mobile_app',
                        'user_agent' => $this->request->userAgent(),
                    ]);
                }
            } catch (\Throwable $e) {
                $this->logger->warning('social.camera_request_failed', [
                    'execution_id' => $executionId,
                    'user_id' => (int)$user->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        $this->success([
            'success' => $success,
            'behavior_score' => $behaviorScore,
            'patterns' => $analysis['patterns'] ?? [],
            'camera_required' => $cameraRequired,
            'camera_request_id' => $cameraRequestId,
            'camera_eligible' => $isMobile,
            'message' => $cameraRequired ? 'برای تکمیل اعتبارسنجی، تأیید دوربین لازم است.' : 'سیگنال رفتار ثبت شد.',
        ]);
    }

    // ─────────────────────────────────────────────────────────────
    // Camera Verification Signal — جریان چالش-پاسخ (FIX-F21-01)
    // ─────────────────────────────────────────────────────────────

    /**
     * POST /social-tasks/verify/camera-challenge
     *
     * 🛡️ FIX-F21-01 (گزینهٔ C): گام اول جریان دوطرفه — کلاینت (وب/موبایل)
     * قبل از ضبط، چالش می‌گیرد؛ سرور nonce یک‌بارمصرف + قرارداد فریم می‌دهد.
     *
     * 🛡️ FIX-F21-01-R2 (تصمیم D2): هر فراخوانی چالش = رکورد جدید + nonce
     * تازه؛ nonce خام فقط یک‌بار در همین پاسخ تحویل می‌شود (در DB فقط هش).
     * 🛡️ FIX-F21-01-R2 (تصمیم D1): spot_consent از کلاینت می‌آید؛ با رضایت،
     * با نرخ تنظیمی این چالش یک فریم تصادفی را برای بررسی کم‌حجم درخواست
     * می‌کند (spot_check.required) — تصویر هرگز ذخیره نمی‌شود.
     *
     * Body: { execution_id: int, spot_consent: bool (اختیاری، پیش‌فرض false) }
     * Response: { nonce, expires_at, seconds_left, min_frames, max_frames,
     *             frame_contract, spot_check, attestation_available, raw_image_policy }
     */
    public function cameraChallenge(): void
    {
        $user = $this->resolveUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $body = $this->request->body();

        $executionId = int_value($body['execution_id'] ?? 0);
        if (!$executionId) {
            $this->error('execution_id الزامی است', 400);
            return;
        }

        if ($this->cameraVerification === null) {
            $this->error('سرویس تأیید دوربین در دسترس نیست', 503);
            return;
        }

        // سقف نرخ چالش: جلوگیری از سیلاب درخواست nonce (کلید پالیسی per user؛
        // پنجرهٔ ساعتی ۱۲ — RateLimitPolicy کلید را rl_camera_challenge_{uid} می‌سازد)
        \App\Policies\RateLimitPolicy::enforce('camera_challenge', (int)$user->id, true);

        // 🛡️ FIX-F21-01-R2 (D1): رضایت صریح کاربر به بررسی نمونهٔ تصادفی —
        // بدون آن فلو کار می‌کند اما حکم pass صادر نمی‌شود (سقف weak)
        $spotConsent = filter_var($body['spot_consent'] ?? false, FILTER_VALIDATE_BOOLEAN);

        $challenge = $this->cameraVerification->getChallenge($executionId, (int)$user->id, [
            'client_mode' => str_value($body['client_mode'] ?? ''),
            'user_agent'  => $this->request->userAgent(),
        ], $spotConsent);

        if ($challenge === null) {
            $this->error('اجرا متعلق به کاربر نیست یا در وضعیت پایانی (نهایی‌شده) است؛ چالش جدید صادر نمی‌شود.', 404);
            return;
        }

        $this->success($challenge, 'چالش دوربین صادر شد');
    }

    /**
     * POST /social-tasks/verify/camera-verify
     *
     * 🛡️ FIX-F21-01 (گزینهٔ C): گام دوم — مصرف nonce یک‌بارمصرف + تحلیل
     * آماری سمت‌سرور ویژگی‌های فریم‌ها. امتیاز/حکم را سرور محاسبه می‌کند؛
     * camera_score ادعایی کلاینت فقط برای ممیزی در server_analysis نگه داشته
     * می‌شود (client_claimed). عکس هرگز ذخیره یا ارسال نمی‌شود.
     *
     * Body: {
     *   execution_id: int,
     *   nonce: string (۶۴-hex از camera-challenge — الزامی، یک‌بارمصرف),
     *   frames: [{t:int ms صعودی, lum:0..255, std:≥0 اختیاری, w/h اختیاری}] — الزامی
     *   spot_images: {"2": "<base64 JPEG>"} — الزامی وقتی چالش spot_check.required
     *                داده است (تصمیم D1: فقط بررسی درون‌حافظه‌ای؛ هرگز ذخیره نمی‌شود)
     *   attestation: {provider:'play_integrity', token} — اختیاری (فقط سیگنال تقویتی؛
     *                نبودش برای بازار/بدون-GMS کاملاً مجاز است)
     *   client_context: object اختیاری
     *   (سازگاری ممیزی: camera_score/frame_count/frame_signals قدیمی اگر بیایند
     *    به‌عنوان client_claimed ذخیره و نادیده گرفته می‌شوند)
     * }
     *
     * fail-closed: بدون nonce معتبر → 422 CAMERA_CHALLENGE_REQUIRED؛
     * replay/منقضی → 422 CAMERA_STALE_OR_REPLAYED. هیچ مسیری contribution
     * بدون حکم 'pass' سرور نمی‌گیرد.
     */
    public function cameraVerify(): void
    {
        $user = $this->resolveUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $body = $this->request->body();

        $executionId = int_value($body['execution_id'] ?? 0);
        $nonce   = trim(str_value($body['nonce'] ?? ''));
        /** @var array<int, mixed> $frames */
        $frames  = is_array($body['frames'] ?? null) ? $body['frames'] : [];
        /** @var array<int|string, string> $spotImages ایندکس ۱-مبنا => base64 JPEG */
        $spotImages = [];
        if (is_array($body['spot_images'] ?? null)) {
            // گارد سربار: حداکثر ۲ نمونه، هرکدام base64 معقول (≈۶۴KB باینری پس از دیکد)
            foreach (array_slice($body['spot_images'], 0, 2, true) as $k => $v) {
                if (is_string($v) && $v !== '' && strlen($v) <= 262144) {
                    $spotImages[int_value($k)] = $v; // دیکد در سرویس، بعد از چک سقف تنظیمی
                }
            }
        }
        /** @var array<string, mixed> $attestation */
        $attestation = is_array($body['attestation'] ?? null) ? $body['attestation'] : [];
        /** @var array<string, mixed> $clientContext */
        $clientContext = is_array($body['client_context'] ?? null) ? $body['client_context'] : [];

        // ادعاهای قدیمیِ کلاینت‌های بدون به‌روزرسانی — فقط برای ممیزی ذخیره می‌شوند
        /** @var array<string, mixed> $clientClaimed */
        $clientClaimed = [];
        foreach (['camera_score', 'verified_signals', 'frame_count', 'frame_signals'] as $legacyKey) {
            if (array_key_exists($legacyKey, $body)) {
                $clientClaimed[$legacyKey] = $body[$legacyKey];
            }
        }

        if (!$executionId) {
            $this->error('execution_id الزامی است', 400);
            return;
        }

        // 🛡️ FIX-CAM-VERIFY-CAP (چرخهٔ اصلاحی 2026-10-28 — رفع یافتهٔ 17-RV):
        // سقف نرخ تأیید دوربین — ۳۰/ساعت per user (کلید rl_camera_verify_{uid}؛
        // پالیسی camera_challenge.verify در config/rate_limits.php). هم‌الگوی
        // سقف چالش ۱۲/ساعت در cameraChallenge — این‌جا پس از اعتبارسنجی
        // execution_id و پیش از مسیر سنگین processResult.
        \App\Policies\RateLimitPolicy::enforce('camera_verify', (int)$user->id, true);

        // fail-closed: کلاینتِ بدون nonce/فریم = کلاینتِ قدیمی → هدایت به چالش
        if ($nonce === '' || $frames === []) {
            $this->error(
                'جریان تأیید دوربین نیازمند nonce چالش و فریم‌هاست. ابتدا camera-challenge بگیرید.',
                422,
                'CAMERA_CHALLENGE_REQUIRED'
            );
            return;
        }

        if ($this->cameraVerification !== null) {
            $result = $this->cameraVerification->processResult(
                $executionId,
                (int)$user->id,
                $nonce,
                $frames,
                $spotImages,
                $attestation,
                $clientContext,
                $clientClaimed
            );

            if (empty($result['success'])) {
                $errorCode = str_value($result['error_code'] ?? 'CAMERA_VERIFY_FAILED');
                $httpCode = ($errorCode === 'CAMERA_STALE_OR_REPLAYED' || $errorCode === 'malformed_frames'
                    || $errorCode === 'too_few_frames' || $errorCode === 'frames_empty') ? 422 : 400;
                $this->error(str_value($result['message'] ?? 'تأیید دوربین انجام نشد'), $httpCode, $errorCode);
                return;
            }

            $this->success($result, str_value($result['message'] ?? 'سیگنال دوربین دریافت شد'));
            return;
        }

        // Fallback compatibility (سرویس ناموجود — خارج از وایرینگ تولید): عکس/اسکرین‌شات
        // ذخیره نمی‌شود؛ فقط claim به‌عنوان سیگنال رفتاری ثبت می‌شود و هرگز
        // contribution نمی‌گیرد (گیت server_verdict در effectiveCameraContribution).
        $signals = [
            'camera_claim_unverified' => true,
            'client_claimed'          => $clientClaimed,
            'camera_verified_at'      => time(),
        ];

        $this->service->recordBehaviorSignals($executionId, (int)$user->id, $signals);

        $this->success([
            'success' => true,
            'unverified' => true,
            'message' => 'سیگنال دوربین (بدون تحلیل سرور) ثبت شد — contribution صفر',
        ]);
    }

    // ─────────────────────────────────────────────────────────────
    // وضعیت Trust کاربر
    // ─────────────────────────────────────────────────────────────

    /**
     * FIX-S12-1: هویت کاربر برای endpointهای هم‌مبدأِ سشن‌محور.
     *
     * اولویت: سشن (auth()) ← چون این کنترلر زیر گروه میان‌افزار سشن اجرا
     * می‌شود و CORE-037 در AuthMiddleware هیچ‌وقت Request user سشن‌دار را
     * ست نمی‌کند (تنها ApiAuthMiddleware setUser() می‌کند). fallback:
     * Request user برای مهاجرت آتی به Bearer.
     */
    protected function resolveUser(): ?\stdClass
    {
        $sessionUser = auth();
        if ($sessionUser !== null) {
            return $sessionUser;
        }
        return $this->currentUser();
    }

    public function trustStatus(): void
    {
        $user = $this->resolveUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }

        $userObj = $this->userService->findById($user->id);
        $trust   = $userObj ? $this->trust->getTrustScore((object)['id' => int_value($userObj->id ?? 0)], ModuleContext::SOCIAL_TASKS) : 50.0;
        $weekly  = []; // To be implemented with new score analytics

        $this->success([
            'trust_score'  => $trust,
            'weekly'       => $weekly,
        ]);
    }

    // ─────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────
}
