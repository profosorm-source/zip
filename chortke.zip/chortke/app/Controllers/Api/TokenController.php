<?php

namespace App\Controllers\Api;

use App\Models\ApiToken;
use App\Services\ApiTokenService;
use App\Validators\Requests\IssueTokenRequest;
use Core\RateLimiter;

/**
 * API\TokenController - مدیریت API Token
 *
 * POST /api/v1/auth/token    → دریافت token با credentials
 * POST /api/v1/auth/revoke   → باطل کردن token
 * GET  /api/v1/auth/tokens   → لیست tokenهای فعال (نیاز به auth)
 */
class TokenController extends BaseApiController
{
    private ApiTokenService $service;
    private \Core\RateLimiter $rateLimiter;

    public function __construct(ApiTokenService $service, \Core\RateLimiter $rateLimiter, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->service = $service;
        $this->rateLimiter = $rateLimiter;
    }

    /**
     * دریافت API Token با email/password
     * این endpoint نیاز به middleware auth ندارد
     */
    public function issue(): void
    {
        $data = $this->request->body();

        $formRequest = new IssueTokenRequest($data);
        if (!$formRequest->validate()) {
            $this->validationError($formRequest->errors());
            // unreachable — validationError throws, but for static analysis:
            return;
        }
        $validated = $formRequest->safeValidated();
        $email    = strtolower(trim(str_value($validated['email'] ?? '')));
        $password = str_value($validated['password'] ?? '');

        $key = $this->issueRateLimitKey($email);
        if (!$this->rateLimiter->attempt($key, 8, 10, true)) {
            $this->error('تعداد تلاش بیش از حد مجاز است. چند دقیقه دیگر تلاش کنید', 429, 'RATE_LIMITED');
            return;
        }

        $result = $this->service->issueToken(
            $email,
            $password,
            trim(str_value($data['token_name'] ?? '')),
            // FIX-M11-SF-008 (گزارش دوم): default سراسریِ «read» حذف شد — omission
            // را سرویس با DEFAULT_SCOPE (user.read) و ورودیِ نامعتبر را با 422
            // INVALID_SCOPES جواب می‌دهد؛ کنترلر دیگر امتیاز پیش‌فرض نمی‌سازد.
            trim(str_value($data['scopes'] ?? '')),
            trim(str_value($data['otp'] ?? ''))
        );

        if (!$result['success']) {

            if (!empty($result['validation'])) {
                $this->validationError(is_array($result['validation']) ? $result['validation'] : []);
                return;
            }

            $this->error(str_value($result['message']), int_value($result['status'] ?? 400), str_value($result['code'] ?? 'TOKEN_ERROR'));
            return;
        }

        $this->clearIssueRateLimit($email);
        // FIX-M11-R22-17: پاسخِ حاوی توکن (RFC 6749 §5.1) — no-store تا ذخیرهٔ مشترک
        // (proxy/back-forward cache) توکن را نگه ندارد.
        $this->response->setHeader('Cache-Control', 'no-store');
        $this->response->setHeader('Pragma', 'no-cache');
        $this->success($result['payload'], 'توکن با موفقیت صادر شد', 201);
    }

    /**
     * FIX-M23-R1 (یادآوری ① تغییر breaking): کاتالوگ ماشینی‌خوانِ اسکوپ‌ها —
     * GET /api/v1/auth/scopes
     *
     * چرا عمومی؟ کلاینتِ موبایل پیش از صدور توکن باید بداند چه اسکوپ‌هایی وجود
     * دارد، کدام‌ها exact-only هستند (هیچ write/read عمومی‌ای آن‌ها را نمی‌پوشاند)
     * و کدام‌ها پرریسک‌اند — وگرنه در زمانِ فراخوانیِ عملیات با 403
     * INSUFFICIENT_SCOPE غافلگیر می‌شود. دادهٔ ایستا و غیرحساس است؛
     * RateLimit عمومیِ گروه + ApiRequestMiddleware روی آن فعال‌اند.
     */
    public function scopes(): void
    {
        $this->success([
            'scopes' => ApiToken::scopeCatalog(),
            'contract' => [
                'omission_default' => ApiTokenService::DEFAULT_SCOPE,
                'exact_only_meaning' => 'فقط تطبیقِ دقیق (یا «*» برای ادمین) اعطا می‌کند؛ هیچ سلسله‌مراتبی این اسکوپ را نمی‌پوشاند.',
                'insufficient_scope_error' => 'INSUFFICIENT_SCOPE (403)',
                'invalid_scope_error' => 'INVALID_SCOPES (422)',
            ],
        ]);
    }

    /**
     * نوسازی توکن API (Refresh Token Rotation)
     * این endpoint نیاز به middleware auth ندارد
     */
    public function refresh(): void
    {
        $data = $this->request->body();
        $refreshToken = trim(str_value($data['refresh_token'] ?? ''));

        if ($refreshToken === '') {
            $this->error('توکن نوسازی الزامی است', 400, 'MISSING_REFRESH_TOKEN');
            return;
        }

        // FIX-R36-W3 (F-A7-07): سقف تلاش برای refresh — قبلاً بدون rate limit بود و
        // به‌طور نامحدود findByRefreshToken (پیمایش secret_versionها) را به DB تحمیل
        // می‌کرد. ۳۰ تلاش در دقیقه به‌ازای هر IP، fail-closed (هم‌خانوادهٔ issue()).
        $refreshRlKey = 'api_token_refresh_rl_' . hash_hmac('sha256', $this->request->ip(), str_value(config('app.key')));
        if (!$this->rateLimiter->attempt($refreshRlKey, 30, 1, true)) {
            $this->error('تعداد درخواست نوسازی بیش از حد مجاز است. کمی بعد تلاش کنید', 429, 'RATE_LIMITED');
            return;
        }

        $result = $this->service->refreshToken($refreshToken);

        if (!$result['success']) {
            $this->error(str_value($result['message']), int_value($result['status'] ?? 401), str_value($result['code'] ?? 'INVALID_REFRESH_TOKEN'));
            return;
        }

        // FIX-M11-R22-17: refresh هم token صادر می‌کند — همان قرارداد no-store
        $this->response->setHeader('Cache-Control', 'no-store');
        $this->response->setHeader('Pragma', 'no-cache');
        $this->success($result['payload'], 'توکن با موفقیت نوسازی شد', 200);
    }

    /**
     * باطل کردن token جاری
     */
    public function revoke(): void
    {
        $userId = (int)$this->userId();
        if (!$userId) {
            $this->error('احراز هویت نشده', 401);
            return;
        }

        // FIX-M11-R22-24: توکنِ استخراج‌شده در middleware روی Request است —
        // پارسِ مجددِ هدر (که «bearer» با حرف کوچک را رد می‌کرد، برخلاف
        // middleware که /Bearer\s+(.+)/i می‌پذیرفت) حذف شد. Fallback پارسِ
        // case-insensitive برای فراخوانی بدون middleware حفظ شده است.
        $token = str_value($this->request->getAttribute('api_bearer_token') ?? '');
        if ($token === '') {
            $authHeader = str_value($this->request->header('Authorization') ?? '');
            if (preg_match('/Bearer\s+(.+)/i', $authHeader, $m)) {
                $token = trim($m[1]);
            }
        }

        if (!$token) {
            $this->error('توکن یافت نشد', 400);
            return;
        }

        $result = $this->service->revokeTokenByHashForUser($token, $userId);

        if (!$result['success']) {
            $this->error(str_value($result['message']), int_value($result['status'] ?? 404), str_value($result['code'] ?? 'TOKEN_NOT_FOUND'));
            return;
        }

        $this->success(null, 'توکن با موفقیت باطل شد');
    }

    /**
     * لیست tokenهای فعال کاربر
     */
    public function list(): void
    {
        $tokens = $this->service->listTokensForUser((int)$this->userId());
        $this->success($tokens);
    }

    /**
     * باطل کردن یک token خاص
     */
    public function revokeById(): void
    {
        $userId = (int)$this->userId();
        $tokenId = $this->request->int('id');

        if (!$tokenId) {
            $this->error('ID توکن الزامی است', 400);
        }

        $result = $this->service->revokeTokenById($userId, $tokenId);

        if (!$result['success']) {
            $this->error(str_value($result['message']), int_value($result['status'] ?? 404), str_value($result['code'] ?? 'TOKEN_NOT_FOUND'));
            return;
        }

        $this->success(null, 'توکن باطل شد');
    }
        
    private function issueRateLimitKey(string $email): string
    {
        $ip = $this->request->ip();
        return 'api_token_issue_rl_' . hash_hmac('sha256', $ip . '|' . mb_strtolower(str_value($email)), str_value(config('app.key')));
    }

    private function clearIssueRateLimit(string $email): void
    {
        $this->rateLimiter->clear($this->issueRateLimitKey($email));
    }

}
