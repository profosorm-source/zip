<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Services\AntiFraud\BrowserFingerprintService;

/**
 * FingerprintController
 * 
 * دریافت و پردازش browser fingerprint
 */
class FingerprintController extends BaseApiController
{
    private BrowserFingerprintService $fingerprintService;
    
    public function __construct(BrowserFingerprintService $fingerprintService, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->fingerprintService = $fingerprintService;
    }
    
    /**
     * دریافت و ذخیره fingerprint
     */
    public function store(): void
    {
        // در APIهای عمومی، اگر کاربر لاگین بود آیدی‌اش را برمی‌داریم، در غیر این صورت ۰ یا نال
        $userId = (int)$this->userId();

        // 🛡️ FIX-R67-03 (T28-19): مهمان‌ها (userId=۰) پذیرفته نمی‌شوند — قبلاً
        // پاسخ موفق می‌گرفتند (بدون ذخیره) که هم endpoint را برای پویش/هارنس
        // باز نگه می‌داشت و هم تحلیل بی‌کاربر انجام می‌داد.
        if ($userId <= 0) {
            $this->error('برای ثبت اثرانگشت باید وارد حساب خود شوید', 401);
        }

        // 🛡️ FIX-R67-03 (T28-19): سقف اندازهٔ components — بدون سقف، بدنه‌های
        // چند-مگابایتی به generate/serialize می‌رسیدند (حملهٔ منابع).
        $payload = (array)$this->request->body();
        $components = $payload['components'] ?? null;
        $clientHash = str_value($payload['hash'] ?? '');

        if (empty($clientHash)) {
            $this->error('Hash fingerprint الزامی است', 400);
        }

        $componentsArr = is_array($components) ? $components : [];
        if (empty($componentsArr)) {
            $this->error('داده‌های فینگرپرینت خالی است', 400);
        }
        if (strlen(json_encode($componentsArr) ?: '') > 32768) {
            $this->error('داده‌های فینگرپرینت بیش از حد بزرگ است', 413);
        }

        // 🛡️ FIX-R67-03 (T28-19): rate limit — ۲۰ ثبت در ساعت به ازای کاربر؛
        // ثبت طبیعی چندبار در نشست است، چرخش برنامه‌نویسی‌شدهٔ اثرانگشت نیست.
        $rlKey = 'fp_store_rl:' . $userId . ':' . (int)floor(time() / 3600);
        $cache = \Core\Cache::getInstance();
        if (int_value($cache->get($rlKey, 0)) >= 20) {
            $this->error('درخواست‌های ثبت اثرانگشت بیش از حد مجاز است', 429);
        }
        $cache->increment($rlKey, 1, 3600);

        // تولید مجدد در سرور برای جلوگیری از جعل (Issue 2)
        $fingerprint = $this->fingerprintService->generate($componentsArr);

        if (!hash_equals($fingerprint, $clientHash)) {
            $this->logger->warning('fingerprint.spoof_detected', ['user_id' => $userId]);
            $this->error('اعتبارسنجی فینگرپرینت شکست خورد', 403);
        }
        
        // ذخیره (اگر کاربر لاگین بود)
        if ($userId > 0) {
            $this->fingerprintService->store($userId, $fingerprint, $componentsArr);
            
            // تحلیل
            $analysis = $this->fingerprintService->analyze($userId, $fingerprint);
            
            // لاگ کردن در صورت مشکوک بودن
            if ($analysis['suspicious'] ?? false) {
                $this->fingerprintService->logAnalysis($userId, $fingerprint, $analysis);
            }

            $this->success([
                'fingerprint' => substr($fingerprint, 0, 16) . '...',
                'suspicious' => $analysis['suspicious'] ?? false
            ]);
            return;  // ← Critical: Exit after response to prevent double response
        }

        // برای کاربران مهمان فقط تولید و بازگشت می‌دهیم (بدون ذخیره دیتابیسی سنگین یا با منطق متفاوت)
        $this->success([
            'fingerprint' => substr($fingerprint, 0, 16) . '...',
            'message' => 'Guest fingerprint processed'
        ]);
    }
}
