<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Models\Ads;
use App\Models\SeoExecution;
use App\Services\Seo\SeoService;
use App\Services\SeoLandingProofService;
use App\Services\Shared\PolicyService;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\UrlGenerator;

/**
 * SeoTaskApiController — انجام تسک‌های سئو از کانال API (اپ موبایل).
 *
 * 📱 FIX-MOBILE-04 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲):
 * تسک سئو یکی از دو موتور درآمدی کاربران است ولی فقط مسیر وب داشت؛
 * این کنترلر همان سرویس‌های زیرین (SeoService → همان Jobهای وب) را با
 * قرارداد JSON بازنشر می‌کند تا اپ موبایل بدون WebView هم بتواند تسک
 * را شروع/پیش ببرد/تکمیل کند.
 *
 * جریان موبایل (هم‌ارز دقیق وبِ FIX-SEO-23-01):
 *   ۱. GET  /seo/ads                  → فهرست آگهی‌های فعال + آمار کاربر
 *   ۲. POST /seo/ads/{id}/start       → execution_id + go_url (مطلق)
 *   ۳. باز کردن go_url در مرورگر سیستمی — لینک بدون session کار می‌کند
 *      (رفع وابستگی session در SeoController::go — همان بچ) و کلیک را
 *      در سمت سرور مهر می‌زند؛ اگر آگهی کانال اثبات فرود فعال دارد،
 *      توکن ckp خودکار به URL هدف الصاق می‌شود (پیکسل/پست‌بک).
 *   ۴. GET  /seo/executions/{id}      → وضعیت اجرا (کلیک/فرود/پلهٔ پاداش)
 *   ۵. POST /seo/executions/{id}/complete → ثبت engagement و ورود به
 *      صف پرداخت (ProcessSeoTaskAsyncJob همان clampهای سروری وب: duration
 *      به زمان سرور بازنویسی می‌شود — ادعای خام کلاینت پاداش نمی‌سازد)
 *
 * اسکوپ‌ها: seo.read / seo.write (پوشش‌پذیر با read/write سراسری —
 * FIX-MOBILE-04 در ApiToken). client_mode در مسیر API فقط mobile_app یا
 * mobile_web پذیرفته می‌شود (ادعای «web» از کانال API نامعتبر است).
 */
class SeoTaskApiController extends BaseApiController
{
    private Ads $adModel;
    private SeoExecution $executionModel;
    private SeoService $seoService;
    private SeoLandingProofService $landingProof;
    // urlGenerator از BaseController به ارث می‌رسد (protected) — تعریف تکراری ممنوع

    public function __construct(
        Ads $adModel,
        SeoExecution $executionModel,
        SeoService $seoService,
        UrlGenerator $urlGenerator,
        ?LoggerInterface $logger = null,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?PolicyService $policyService = null
    ) {
        // BaseApiController سازندهٔ ۵-پارامتری دارد؛ urlGenerator پراپرتی protected
        // والد (BaseController) است و همین‌جا مقداردهی می‌شود
        parent::__construct($session, $request, $response, $policyService, $logger);
        $this->urlGenerator = $urlGenerator;
        $this->adModel = $adModel;
        $this->executionModel = $executionModel;
        $this->seoService = $seoService;
        // هم‌الگوی SeoController وب — سرویس سبک؛ در مسیرهای بدون فرود صدا نمی‌شود
        $this->landingProof = new SeoLandingProofService(
            $executionModel,
            new \App\Models\SeoLandingProofTest(db()),
            $adModel,
            db(),
            logger()
        );
    }

    /**
     * GET /api/v1/seo/ads — فهرست آگهی‌های سئوی فعال + آمار کاربر.
     */
    public function ads(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $search = trim(str_value($this->request->query('search', '')));
        [$page, $perPage, $offset] = $this->paginationParams(20);

        $result = $this->adModel->searchAdminTasks($search, ['type' => 'seo', 'status' => 'active'], $perPage, $offset);
        $items = is_array($result['items'] ?? null) ? $result['items'] : [];
        $total = int_value($result['total'] ?? 0);

        // شکل‌دهی امن ردیف‌ها برای کلاینت (فقط فیلدهای عمومی آگهی)
        $rows = [];
        foreach ($items as $ad) {
            if (!is_object($ad) && !is_array($ad)) {
                continue;
            }
            $a = is_array($ad) ? (object)$ad : $ad;
            $rows[] = [
                'id'              => int_value($a->id ?? 0),
                'title'           => str_value($a->title ?? ''),
                'keyword'         => str_value($a->keyword ?? ''),
                'description'     => str_value($a->description ?? ''),
                'price_per_click' => float_value($a->price_per_click ?? 0),
                'currency'        => str_value($a->currency ?? 'irt'),
                'estimated_time'  => int_value($a->estimated_time ?? 0),
                'proof_mode'      => $this->proofModeForAd($a),
            ];
        }

        $stats = $this->executionModel->getUserStats($userId);
        $this->paginated($rows, $total, $page, $perPage);
    }

    /**
     * POST /api/v1/seo/ads/{id}/start — شروع اجرا + لینک شمارندهٔ کلیک.
     *
     * go_url مطلق است و در مرورگر سیستمی/InApp بدون session کار می‌کند؛
     * nonce یک‌بارمصرف تا ۱۵ دقیقه (CLICK_TOKEN_TTL_SECONDS) اعتبار دارد و
     * تا قبل از مصرف، صدای مجدد همان توکن زنده را برمی‌گرداند.
     */
    public function start(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $adId = $this->request->int('id');
        if ($adId <= 0) {
            $this->validationError(['id' => ['شناسهٔ آگهی نامعتبر است']]);
            return;
        }

        $result = $this->seoService->startTask($adId, $userId);
        if (!is_array($result) || empty($result['success'])) {
            $this->error(str_value($result['message'] ?? 'شروع تسک ممکن نشد'), 422, 'SEO_START_FAILED');
            return;
        }

        $executionId = int_value($result['execution_id'] ?? 0);
        $this->success([
            'execution_id' => $executionId,
            'go_url'       => $this->buildGoUrl($executionId),
            'proof_mode'   => $this->proofModeForAdId($adId),
            'next_step'    => 'open_go_url_then_complete',
        ], str_value($result['message'] ?? 'تسک سئو شروع شد'), 201);
    }

    /**
     * GET /api/v1/seo/executions/{id} — وضعیت اجرا برای نمایش صادقانه
     * (نشان سه‌حالتهٔ اثباتِ فاز ۲ سئو — هم‌ارز ویوی execute وب).
     */
    public function execution(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $executionId = $this->request->int('id');
        $execution = $executionId > 0 ? $this->executionModel->findByUser($executionId, $userId) : null;
        if ($execution === null) {
            $this->error('اجرا یافت نشد', 404, 'EXECUTION_NOT_FOUND');
            return;
        }

        $ad = $this->adModel->find((int)$execution->ad_id);
        $clickCounted = $execution->click_counted_at !== null;
        $landingVerified = $execution->landing_verified_at !== null;

        $this->success([
            'execution_id'            => $executionId,
            'status'                  => str_value($execution->status ?? ''),
            'click_counted'           => $clickCounted,
            'click_counted_at'        => $execution->click_counted_at !== null ? str_value($execution->click_counted_at) : null,
            'landing_verified'        => $landingVerified,
            'landing_verified_at'     => $landingVerified ? str_value($execution->landing_verified_at) : null,
            'landing_proof_channel'   => ($execution->landing_proof_channel ?? null) !== null ? str_value($execution->landing_proof_channel) : null,
            'proof_mode'              => $ad !== null ? $this->proofModeForAd($ad) : 'off',
            // توکن زنده تا قبل از مصرف کلیک؛ بعد از آن null (بازکردن مجدد لازم نیست)
            'go_url'                  => $clickCounted ? null : $this->buildGoUrl($executionId),
            'payout_amount'           => float_value($execution->payout_amount ?? 0),
            'final_score'             => ($execution->final_score ?? null) !== null ? float_value($execution->final_score) : null,
            'started_at'              => str_value($execution->started_at ?? ''),
            'completed_at'            => ($execution->completed_at ?? null) !== null ? str_value($execution->completed_at) : null,
        ]);
    }

    /**
     * POST /api/v1/seo/executions/{id}/complete — ثبت engagement و ورود به پردازش پرداخت.
     *
     * بدنهٔ هم‌قرارداد وب: duration، scroll_depth، interactions (عددی الزامی)،
     * active_time/focus_blur_count/pause_count/scroll_speed/mouse_pattern/
     * interaction_types (اختیاری). client_mode در کانال API فقط «mobile_app»
     * یا «mobile_web» پذیرفته می‌شود (ادعای web از کانال API رد می‌شود).
     */
    public function complete(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $executionId = $this->request->int('id');
        if ($executionId <= 0) {
            $this->validationError(['id' => ['شناسهٔ اجرا نامعتبر است']]);
            return;
        }

        $body = $this->request->body();
        foreach (['duration', 'scroll_depth', 'interactions'] as $field) {
            if (!array_key_exists($field, $body) || !is_numeric($body[$field])) {
                $this->validationError([$field => ["فیلد {$field} باید عددی باشد"]]);
                return;
            }
        }

        $interactionTypes = $body['interaction_types'] ?? [];
        if (!is_array($interactionTypes) || array_filter($interactionTypes, 'is_string') !== $interactionTypes) {
            $this->validationError(['interaction_types' => ['ساختار interaction_types نامعتبر است']]);
            return;
        }

        // 📱 FIX-MOBILE-04: کانال API فقط خودش را می‌تواند ادعا کند
        $clientMode = strtolower(trim(str_value($body['client_mode'] ?? 'mobile_app')));
        if (!in_array($clientMode, ['mobile_app', 'mobile_web'], true)) {
            $this->validationError(['client_mode' => ['در کانال API فقط mobile_app یا mobile_web مجاز است']]);
            return;
        }

        $engagementData = [
            'duration'         => int_value($body['duration'] ?? 0),
            'active_time'      => int_value($body['active_time'] ?? $body['duration'] ?? 0),
            'scroll_depth'     => float_value($body['scroll_depth'] ?? 0),
            'interactions'     => int_value($body['interactions'] ?? 0),
            'target_opened'    => !empty($body['target_opened']) ? 1 : 0,
            'focus_blur_count' => int_value($body['focus_blur_count'] ?? 0),
            'client_mode'      => $clientMode,
            'interaction_types' => array_values($interactionTypes),
            'behavior'         => [
                'scroll_speed'      => float_value($body['scroll_speed'] ?? 0),
                'mouse_pattern'     => str_value($body['mouse_pattern'] ?? 'normal'),
                'pause_count'       => int_value($body['pause_count'] ?? 0),
                'interaction_types' => array_values($interactionTypes),
                'target_opened'     => !empty($body['target_opened']) ? 1 : 0,
                'focus_blur_count'  => int_value($body['focus_blur_count'] ?? 0),
                'client_mode'       => $clientMode,
            ],
        ];

        $result = $this->seoService->completeTask($executionId, $userId, $engagementData);
        if (!is_array($result) || empty($result['success'])) {
            $this->error(str_value($result['message'] ?? 'تکمیل تسک ممکن نشد'), 422, 'SEO_COMPLETE_FAILED');
            return;
        }

        $this->success($result, str_value($result['message'] ?? 'تسک تکمیل شد'));
    }

    /**
     * POST /api/v1/seo/executions/{id}/cancel — لغو اجرا (هم‌قرارداد وب).
     */
    public function cancel(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $executionId = $this->request->int('id');
        if ($executionId <= 0) {
            $this->validationError(['id' => ['شناسهٔ اجرا نامعتبر است']]);
            return;
        }

        $result = $this->seoService->cancelTask($executionId, $userId);
        if (!is_array($result) || empty($result['success'])) {
            $this->error(str_value($result['message'] ?? 'لغو تسک ممکن نشد'), 422, 'SEO_CANCEL_FAILED');
            return;
        }

        $this->success(null, str_value($result['message'] ?? 'تسک لغو شد'));
    }

    /**
     * GET /api/v1/seo/history — تاریخچهٔ اجراهای کاربر (صفحه‌بندی‌شده).
     */
    public function history(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        [$page, $perPage, $offset] = $this->paginationParams(20);

        $executions = $this->executionModel->getByUser($userId, $perPage, $offset);
        $total = $this->executionModel->countByUser($userId);

        $rows = [];
        foreach ((array)$executions as $e) {
            if (!is_object($e)) {
                continue;
            }
            $rows[] = [
                'id'             => int_value($e->id ?? 0),
                'ad_id'          => int_value($e->ad_id ?? 0),
                'ad_title'       => str_value($e->ad_title ?? ''),
                'keyword'        => str_value($e->keyword ?? ''),
                'status'         => str_value($e->status ?? ''),
                'payout_amount'  => float_value($e->payout_amount ?? 0),
                'final_score'    => ($e->final_score ?? null) !== null ? float_value($e->final_score) : null,
                'landing_verified' => ($e->landing_verified_at ?? null) !== null,
                'created_at'     => str_value($e->created_at ?? ''),
                'completed_at'   => ($e->completed_at ?? null) !== null ? str_value($e->completed_at) : null,
            ];
        }

        $this->paginated($rows, $total, $page, $perPage);
    }

    /**
     * ساخت go_url مطلق برای یک اجرا — همان الگوی SeoController::execute وب؛
     * توکن زندهٔ موجود دوباره برگردانده می‌شود (issueClickToken idempotent).
     */
    private function buildGoUrl(int $executionId): ?string
    {
        $clickToken = $this->executionModel->issueClickToken($executionId);
        if ($clickToken === null) {
            return null;
        }
        return $this->urlGenerator->to('/seo/' . $executionId . '/go/' . rawurlencode($clickToken));
    }

    /** حالت اثبات فرودِ آگهی (off|pixel|postback) — NULL-safe */
    private function proofModeForAd(\stdClass $ad): string
    {
        try {
            return str_value($this->landingProof->modeForAd($ad));
        } catch (\Throwable $e) {
            return 'off';
        }
    }

    private function proofModeForAdId(int $adId): string
    {
        $ad = $adId > 0 ? $this->adModel->find($adId) : null;
        return ($ad instanceof \stdClass) ? $this->proofModeForAd($ad) : 'off';
    }
}
