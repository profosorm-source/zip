<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Models\Ads;
use App\Models\CustomTaskSubmissionModel;
use App\Services\CustomTask\CustomTaskExecutorService;
use App\Services\CustomTask\CustomTaskProofFileService;
use App\Services\CustomTask\CustomTaskProofSchema;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل تسک‌های سفارشی (با ارسال مدرک). منبع واحد حقیقت
 * CustomTaskExecutorService است — همان fraud-guard و همان جاب‌های وب:
 *   - startTask: گارد ضدتقلب + قفل ظرفیت
 *   - submitProof: مدرک انجام کار + وضعیت‌گذاری
 *
 * 📱 FIX-MOBCTR-05 (بچ قرارداد API موبایل — ۲۰۲۶-۱۱-۰۷؛ یافته‌های A3-N3 +
 * A1-N15 + A1-N8 + A3-N7): موبایل شهروند کاملِ جریان تسک سفارشی شد —
 *   ۱) proof_type (+proof_description) در tasks/start/detail/mySubmissions —
 *      اپ قبل از start می‌داند چه کانال مدرکی لازم است (قبلاً بن‌بست برای
 *      code/screenshot/file/video).
 *   ۲) submitProof همهٔ کانال‌ها را می‌پذیرد (نه فقط URL):
 *      text=note≥10 (بدون URL اجباری) · code · url · screenshot/file/video=
 *      multipart proof_file — نوع مدرک همیشه از ردیف submission سرور-محاسبه
 *      می‌شود (هرگز از کلاینت؛ هم‌قرارداد کنترلر وب + جاب).
 *   ۳) فایل فقط از نتیجهٔ آپلود سرور (CustomTaskProofFileService — الگوی
 *      S17-2/T22-18)؛ رشته‌های proof_file/proof_file_hash در JSON نادیده
 *      گرفته می‌شوند.
 *   ۴) هر دو لیست meta صفحه‌بندی دارند (تشخیص پایان لیست با last_page/total)
 *      و data پاسخ submit کلیدهای واقعی جاب را برمی‌گرداند (auto_approve_info
 *      دیگر دور ریخته نمی‌شود).
 *
 * مسیرها (گروه custom-tasks با اسکوپ‌های customtask.read/write):
 *   GET  /api/v1/custom-tasks/tasks                  تسک‌های در دسترس
 *   GET  /api/v1/custom-tasks/my/submissions         اجراهای من
 *   GET  /api/v1/custom-tasks/submissions/{id}       جزئیات یک اجرا (مالکیت الزامی)
 *   POST /api/v1/custom-tasks/tasks/{id}/start       شروع تسک
 *   POST /api/v1/custom-tasks/submissions/{id}/proof ارسال مدرک (JSON یا multipart)
 */
final class CustomTaskApiController extends BaseApiController
{
    private Ads $adModel;
    private CustomTaskSubmissionModel $submissionModel;
    private CustomTaskExecutorService $executorService;
    /** 📱 FIX-MOBCTR-01: تک‌منبع ذخیرهٔ فایل مدرک (مشترک با کنترلر وب). */
    private CustomTaskProofFileService $proofFileService;

    public function __construct(
        Ads $adModel,
        CustomTaskSubmissionModel $submissionModel,
        CustomTaskExecutorService $executorService,
        CustomTaskProofFileService $proofFileService,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->adModel = $adModel;
        $this->submissionModel = $submissionModel;
        $this->executorService = $executorService;
        $this->proofFileService = $proofFileService;
    }

    /** GET /api/v1/custom-tasks/tasks */
    public function tasks(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        // هم‌منبع وب: لیست مدل مالک کمپین/ظرفیت‌پر/ممنوعِ تکرار را فیلتر می‌کند
        /** @var list<\stdClass> $tasks */
        $tasks = $this->adModel->getAvailableCustomTasks($userId, [], $perPage, ($page - 1) * $perPage, 'custom_task');
        // 📱 FIX-MOBCTR-05 (A3-N3): proof_type نرمال‌شده + دستورالعمل کارفرما در هر
        // ردیف — اپ قبل از start می‌داند چه مدرکی آماده کند. سقف ۲۰۰۰ = همان سقف
        // نوشتنِ آداپتر (FIX-BEHAV1-04).
        $rows = array_map(static fn(\stdClass $t): array => [
            'id'                => (int)$t->id,
            'title'             => str_value($t->title ?? ''),
            'description'       => str_value($t->description ?? ''),
            'reward'            => str_value($t->price_per_task ?? '0'),
            'currency'          => str_value($t->currency ?? 'irt'),
            'remaining_slots'   => (int)($t->remaining_slots ?? 0),
            'proof_type'        => CustomTaskProofSchema::normalizeType(str_value($t->proof_type ?? 'text')),
            'proof_description' => mb_substr(str_value($t->proof_description ?? ''), 0, 2000),
        ], $tasks);
        // 📱 FIX-MOBCTR-05 (A3-N7): meta صفحه‌بندی با شمارندهٔ هم‌شرطِ لیست —
        // شکل data.tasks حفظ شد (سازگاری کلاینت‌های فعلی).
        $this->response->json([
            'success' => true,
            'message' => '',
            'data'    => ['tasks' => $rows],
            'meta'    => $this->paginationMeta($this->adModel->countStartableCustomTasks($userId), $page, $perPage),
        ]);
    }

    /** GET /api/v1/custom-tasks/my/submissions */
    public function mySubmissions(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        /** @var list<\stdClass> $rows */
        $rows = $this->submissionModel->submission_getByWorkerWithTask($userId, $perPage, ($page - 1) * $perPage);
        $this->response->json([
            'success' => true,
            'message' => '',
            'data'    => ['submissions' => array_map(static fn(\stdClass $s): array => [
                'id'          => (int)$s->id,
                'task_id'     => (int)($s->task_id ?? 0),
                'task_title'  => str_value($s->task_title ?? ''),
                'status'      => str_value($s->status ?? ''),
                'reward'      => str_value($s->reward_amount ?? '0'),
                'currency'    => str_value($s->reward_currency ?? 'irt'),
                // 📱 FIX-MOBCTR-05 (A3-N3): نوع مدرک تسک (نرمال‌شده) در هر ردیف
                'proof_type'  => CustomTaskProofSchema::normalizeType(str_value($s->task_proof_type ?? 'text')),
                'updated_at'  => str_value($s->updated_at ?? ''),
            ], $rows)],
            // 📱 FIX-MOBCTR-05 (A3-N7): شمارندهٔ T22-20/F3 — هم‌منبع لیست
            'meta'    => $this->paginationMeta($this->submissionModel->submission_countByWorkerWithTask($userId), $page, $perPage),
        ]);
    }

    /** GET /api/v1/custom-tasks/submissions/{id} */
    public function showSubmission(int $submissionId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        /** @var \stdClass|null $submission */
        $submission = $this->submissionModel->submission_findById($submissionId);
        if (!$submission || (int)$submission->worker_id !== $userId) {
            $this->error('اجرا یافت نشد یا متعلق به شما نیست.', 404, 'SUBMISSION_NOT_FOUND');
            return;
        }
        $this->success([
            'submission' => [
                'id'         => (int)$submission->id,
                'task_id'    => (int)($submission->task_id ?? 0),
                'status'     => str_value($submission->status ?? ''),
                'proof'      => str_value($submission->proof_url ?? ''),
                // 📱 FIX-MOBCTR-05 (A3-N3): کد/شناسهٔ ارسال‌شده هم echo می‌شود
                // (شاخهٔ کانال کد، قرینهٔ proof برای URL).
                'proof_code' => str_value($submission->proof_code ?? ''),
                'admin_note' => str_value($submission->admin_note ?? ''),
                // FIX-M22-MED (N1): ستون واقعی reward_amount است — worker_reward
                // هرگز وجود نداشت ⇒ پاداش همیشه '0' برمی‌گشت.
                'reward'     => str_value($submission->reward_amount ?? '0'),
                'currency'   => str_value($submission->reward_currency ?? 'irt'),
                // 📱 FIX-MOBCTR-05 (A3-N3): نوع مدرک نرمال‌شده + دستورالعمل کارفرما
                'proof_type'        => CustomTaskProofSchema::normalizeType(str_value($submission->proof_type ?? 'text')),
                'proof_description' => mb_substr(str_value($submission->proof_description ?? ''), 0, 2000),
                'updated_at' => str_value($submission->updated_at ?? ''),
            ],
        ]);
    }

    /** POST /api/v1/custom-tasks/tasks/{id}/start */
    public function start(int $taskId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        if ($taskId <= 0) {
            $this->validationError(['task_id' => ['شناسه تسک نامعتبر است.']]);
            return;
        }
        $result = $this->executorService->startTask($taskId, $userId);
        if (!empty($result['success'])) {
            // FIX-M22-MED (N1): startTask هرگز کلید data برنمی‌گرداند (خروجی واقعی:
            // success/submission_id/deadline) ⇒ قبلاً کلاینت همیشه data:[] می‌گرفت.
            // اکنون کلیدهای واقعی نتیجه به‌عنوان data می‌رسند.
            $data = array_diff_key($result, ['success' => 1]);
            // 📱 FIX-MOBCTR-05 (A3-N3): نوع مدرک + دستورالعمل در همان پاسخ start —
            // اپ بلافاصله بعد از شروع می‌داند چه کانالی را باز کند (بدون round-trip).
            $task = $this->adModel->find($taskId);
            if ($task) {
                $data['proof_type'] = CustomTaskProofSchema::normalizeType(str_value($task->proof_type ?? 'text'));
                $data['proof_description'] = mb_substr(str_value($task->proof_description ?? ''), 0, 2000);
            }
            $this->success($data, str_value($result['message'] ?? 'تسک شروع شد.'));
        } else {
            $this->error(str_value($result['message'] ?? 'امکان شروع تسک وجود ندارد.'), 422, str_value($result['error_code'] ?? '') ?: null);
        }
    }

    /** POST /api/v1/custom-tasks/submissions/{id}/proof */
    public function submitProof(int $submissionId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }

        // 📱 FIX-MOBCTR-05: ردیف اجرا و نوع مدرک، سرور-محاسبه — همان منبع وب
        // (submission_findForProof مالکیت را در خودِ کوئری قفل می‌کند). مقدار
        // کلاینت (حتی اگر در body باشد) هرگز ملاک نیست؛ جاب هم دوباره محاسبه
        // و overwrite می‌کند (FIX-M22-CLOSE D2-edge).
        try {
            $submission = $this->submissionModel->submission_findForProof($submissionId, $userId);
        } catch (\Throwable $e) {
            $this->logger?->warning('custom_tasks.api.proof_unavailable', [
                'submission_id' => $submissionId,
                'user_id'       => $userId,
                'error'         => $e->getMessage(),
            ]);
            $submission = null;
        }
        if (!$submission) {
            $this->error('اجرا یافت نشد یا متعلق به شما نیست.', 404, 'SUBMISSION_NOT_FOUND');
            return;
        }
        if ((string)$submission->status !== 'in_progress') {
            $this->error('این اجرا در وضعیت قابل ارسال مدرک نیست.', 422, 'INVALID_STATE');
            return;
        }
        if (!empty($submission->deadline_at) && strtotime((string)$submission->deadline_at) < time()) {
            $this->error('مهلت ارسال مدرک پایان یافته.', 422, 'DEADLINE_PASSED');
            return;
        }

        $proofType = CustomTaskProofSchema::normalizeType(str_value($submission->proof_type ?? 'text'));

        $body = $this->jsonBody();
        // 📱 FIX-MOBCTR-05 (A1-N15): نام‌های موبایل (proof_link/note/code) و
        // نام‌های قرارداد مشترک (proof_url/proof_text/proof_code) هر دو پذیرفته
        // می‌شوند — کانال‌ها بر اساس نوع مدرک «اختیاری»‌اند، نه اجباری-همیشه:
        // برای تسک متنی فقط note≥10 کافی است (قبلاً URL اجباری + note کوتاه =
        // بن‌بست قراردادی). رشته‌های فایل (proof_file/proof_file_hash) عمداً از
        // body خوانده نمی‌شوند — کانال فایل فقط از آپلود multipart سرور می‌آید
        // (هم‌قرارداد S17-2/T22-18 کنترلر وب).
        $proofLink = trim(str_value($body['proof_url'] ?? $body['proof_link'] ?? ''));
        $proofNote = trim(str_value($body['proof_text'] ?? $body['note'] ?? ''));
        $proofCode = trim(str_value($body['proof_code'] ?? $body['code'] ?? ''));
        $proofFile = $this->request->file('proof_file');

        $fileRequired = in_array($proofType, ['screenshot', 'file'], true);
        $hasFile = is_array($proofFile) && !empty($proofFile['name']);
        if ($fileRequired && !$hasFile) {
            $this->validationError(['proof_file' => [$proofType === 'screenshot'
                ? 'برای این تسک، اسکرین‌شات الزامی است.'
                : 'برای این تسک، فایل مدرک الزامی است.']]);
            return;
        }

        // URL: اگر ارسال شده باشد باید معتبر + میزبان غیرلوکال باشد (رفتار موجود).
        // برای نوع url الزامی است (پیش‌گارد پیام فیلد؛ اسکمای جاب هم دوباره می‌سنجد).
        if ($proofLink !== '') {
            if (!filter_var($proofLink, FILTER_VALIDATE_URL)) {
                $this->validationError(['proof_link' => ['لینک مدرک الزامی و باید URL معتبر باشد (https).']]);
                return;
            }
            $host = strtolower((string)(parse_url($proofLink, PHP_URL_HOST) ?: ''));
            if (in_array($host, ['localhost', '127.0.0.1', '0.0.0.0', '::1'], true) || $host === '') {
                $this->validationError(['proof_link' => ['میزبان لینک مدرک معتبر نیست.']]);
                return;
            }
        } elseif ($proofType === 'url') {
            $this->validationError(['proof_link' => ['لینک مدرک الزامی و باید URL معتبر باشد (https).']]);
            return;
        }

        // کانال فایل — فقط از آپلود multipart (نتیجهٔ سرور: مسیر الگوی امن +
        // هش sha256 سمت سرور). شکست آپلود = ۴۲۲ بدون هیچ فایل orphan.
        $uploadedPath = null;
        $proofFileHash = null;
        if ($hasFile) {
            try {
                $uploadResult = $this->proofFileService->store($proofFile, $proofType);
                $uploadedPath = str_value($uploadResult['path']);
                $proofFileHash = $uploadResult['hash'];
            } catch (\Core\Exceptions\BusinessException|\RuntimeException $e) {
                // پیام‌های کاربرپسند/امن سرویس (همان کانال وب) — فایل هرگز ثبت نشده.
                $this->error($e->getMessage(), 422, 'PROOF_FILE_REJECTED');
                return;
            }
        }

        // پیش‌گارد اسکیما (آینهٔ کنترلر وب): پیام دقیقِ همان نوع + پاک‌سازی فایل
        // در شکست (جاب هم همین را می‌سنجد — دفاع دوم).
        $schemaError = CustomTaskProofSchema::validateSchema($proofType, [
            'proof_text' => $proofNote,
            'proof_url'  => $proofLink,
            'proof_code' => $proofCode,
            'proof_file' => $uploadedPath ?? '',
        ]);
        if ($schemaError !== null) {
            if ($uploadedPath !== null) {
                $this->proofFileService->delete($uploadedPath);
            }
            $this->error($schemaError, 422, 'PROOF_SCHEMA');
            return;
        }

        // 📱 FIX-MOBCTR-05: blob ثبت رویداد — همان ساختار وب (FIX-M22-CLOSE/
        // BEHAV1-04): نوع نرمال + اسکمای آگهی (توضیح ≤۱۰۰۰) + کانال‌های پرشده.
        $embeddedSchema = [];
        $rawSchema = str_value($submission->proof_schema ?? '');
        if ($rawSchema !== '') {
            $decoded = json_decode($rawSchema, true);
            if (is_array($decoded)) {
                $embeddedSchema = $decoded;
            }
        }
        if (array_key_exists('description', $embeddedSchema)) {
            $embeddedSchema['description'] = mb_substr(str_value($embeddedSchema['description']), 0, 1000);
        }
        $proofDataJson = json_encode([
            'proof_type'       => $proofType,
            'proof_schema'     => $embeddedSchema,
            'submitted_fields' => [
                'proof_text' => $proofNote !== '',
                'proof_url'  => $proofLink !== '',
                'proof_code' => $proofCode !== '',
                'proof_file' => $uploadedPath !== null,
            ],
        ], JSON_UNESCAPED_UNICODE);

        // FIX-M22-MED (N1): نگاشت فیلدهای موبایل روی قرارداد مشترک جاب.
        // کانال خالی = null (هم‌قرارداد وب؛ ستون‌ها nullable اند). سقف‌ها همان
        // سقف‌های ولیدیتور: url≤1000 · text≤2000 · code≤255.
        $payload = [
            'task_execution_id' => $submissionId,
            'proof_type'        => $proofType,
            'proof_url'         => $proofLink !== '' ? mb_substr($proofLink, 0, 1000) : null,
            'proof_text'        => $proofNote !== '' ? mb_substr($proofNote, 0, 2000) : null,
            'proof_code'        => $proofCode !== '' ? mb_substr($proofCode, 0, 255) : null,
            'proof_data'        => $proofDataJson === false ? null : $proofDataJson,
        ];
        if ($uploadedPath !== null) {
            $payload['proof_file'] = $uploadedPath;
            $payload['proof_file_hash'] = $proofFileHash;
        }

        $result = $this->executorService->submitProof($submissionId, $userId, $payload);
        if (!empty($result['success'])) {
            // 📱 FIX-MOBCTR-05 (A1-N8): data قبلاً $result['data'] می‌خواند که جاب
            // هرگز برنمی‌گرداند ⇒ همیشه [] و «تا X ساعت خودکار تأیید می‌شود» گم.
            // اکنون کلیدهای واقعی + حقایق سرور-دانسته (CAS موفق = status submitted).
            $this->success([
                'submission_id'     => $submissionId,
                'status'            => 'submitted',
                'submitted_at'      => date('Y-m-d H:i:s'),
                'auto_approve_info' => str_value($result['auto_approve_info'] ?? ''),
            ], str_value($result['message'] ?? 'مدرک ثبت شد.'));
        } else {
            $this->error(str_value($result['message'] ?? 'ثبت مدرک ممکن نشد.'), 422, str_value($result['error_code'] ?? '') ?: null);
        }
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
