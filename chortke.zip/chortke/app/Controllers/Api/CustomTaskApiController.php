<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Models\Ads;
use App\Models\CustomTaskSubmissionModel;
use App\Services\CustomTask\CustomTaskExecutorService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل تسک‌های سفارشی (با ارسال مدرک). منبع واحد حقیقت
 * CustomTaskExecutorService است — همان fraud-guard و همان جاب‌های وب:
 *   - startTask: گارد ضدتقلب + قفل ظرفیت
 *   - submitProof: مدرک انجام کار (لینک/متن) + وضعیت‌گذاری
 *
 * مسیرها (گروه custom-tasks با اسکوپ‌های customtask.read/write):
 *   GET  /api/v1/custom-tasks/tasks                  تسک‌های در دسترس
 *   GET  /api/v1/custom-tasks/my/submissions         اجراهای من
 *   GET  /api/v1/custom-tasks/submissions/{id}       جزئیات یک اجرا (مالکیت الزامی)
 *   POST /api/v1/custom-tasks/tasks/{id}/start       شروع تسک
 *   POST /api/v1/custom-tasks/submissions/{id}/proof ارسال مدرک
 */
final class CustomTaskApiController extends BaseApiController
{
    private Ads $adModel;
    private CustomTaskSubmissionModel $submissionModel;
    private CustomTaskExecutorService $executorService;

    public function __construct(
        Ads $adModel,
        CustomTaskSubmissionModel $submissionModel,
        CustomTaskExecutorService $executorService,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->adModel = $adModel;
        $this->submissionModel = $submissionModel;
        $this->executorService = $executorService;
    }

    /** GET /api/v1/custom-tasks/tasks */
    public function tasks(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        // هم‌منبع وب: لیست مدل مالک کمپین/ظرفیت‌پر/ممنوعِ تکرار را فیلتر می‌کند
        /** @var list<\stdClass> $tasks */
        $tasks = $this->adModel->getAvailableCustomTasks($userId, [], $perPage, ($page - 1) * $perPage, 'custom_task');
        $this->success([
            'tasks' => array_map(static fn(\stdClass $t): array => [
                'id'              => (int)$t->id,
                'title'           => str_value($t->title ?? ''),
                'description'     => str_value($t->description ?? ''),
                'reward'          => str_value($t->price_per_task ?? '0'),
                'currency'        => str_value($t->currency ?? 'irt'),
                'remaining_slots' => (int)($t->remaining_slots ?? 0),
            ], $tasks),
        ]);
    }

    /** GET /api/v1/custom-tasks/my/submissions */
    public function mySubmissions(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        /** @var list<\stdClass> $rows */
        $rows = $this->submissionModel->submission_getByWorkerWithTask($userId, $perPage, ($page - 1) * $perPage);
        $this->success([
            'submissions' => array_map(static fn(\stdClass $s): array => [
                'id'          => (int)$s->id,
                'task_id'     => (int)($s->task_id ?? 0),
                'task_title'  => str_value($s->task_title ?? ''),
                'status'      => str_value($s->status ?? ''),
                'reward'      => str_value($s->reward_amount ?? '0'),
                'currency'    => str_value($s->reward_currency ?? 'irt'),
                'updated_at'  => str_value($s->updated_at ?? ''),
            ], $rows),
        ]);
    }

    /** GET /api/v1/custom-tasks/submissions/{id} */
    public function showSubmission(int $submissionId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        /** @var \stdClass|null $submission */
        $submission = $this->submissionModel->submission_findById($submissionId);
        if (!$submission || (int)$submission->worker_id !== $userId) {
            $this->error('اجرا یافت نشد یا متعلق به شما نیست.', 404, 'SUBMISSION_NOT_FOUND');
            return;
        }
        $this->success([
            'submission' => [
                'id'         => (int)$submission->id,
                'task_id'    => (int)($submission->task_id ?? 0),
                'status'     => str_value($submission->status ?? ''),
                'proof'      => str_value($submission->proof_url ?? ''),
                'admin_note' => str_value($submission->admin_note ?? ''),
                // FIX-M22-MED (N1): ستون واقعی reward_amount است — worker_reward
                // هرگز وجود نداشت ⇒ پاداش همیشه '0' برمی‌گشت.
                'reward'     => str_value($submission->reward_amount ?? '0'),
                'currency'   => str_value($submission->reward_currency ?? 'irt'),
                'updated_at' => str_value($submission->updated_at ?? ''),
            ],
        ]);
    }

    /** POST /api/v1/custom-tasks/tasks/{id}/start */
    public function start(int $taskId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        if ($taskId <= 0) {
            $this->validationError(['task_id' => ['شناسه تسک نامعتبر است.']]);
            return;
        }
        $result = $this->executorService->startTask($taskId, $userId);
        if (!empty($result['success'])) {
            // FIX-M22-MED (N1): startTask هرگز کلید data برنمی‌گرداند (خروجی واقعی:
            // success/submission_id/deadline) ⇒ قبلاً کلاینت همیشه data:[] می‌گرفت.
            // اکنون کلیدهای واقعی نتیجه به‌عنوان data می‌رسند.
            $this->success(array_diff_key($result, ['success' => 1]), str_value($result['message'] ?? 'تسک شروع شد.'));
        } else {
            $this->error(str_value($result['message'] ?? 'امکان شروع تسک وجود ندارد.'), 422, str_value($result['error_code'] ?? '') ?: null);
        }
    }

    /** POST /api/v1/custom-tasks/submissions/{id}/proof */
    public function submitProof(int $submissionId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $body = $this->jsonBody();
        $proofLink = trim(str_value($body['proof_link'] ?? $body['proof'] ?? ''));
        $proofNote = trim(str_value($body['note'] ?? ''));
        if ($proofLink === '' || !filter_var($proofLink, FILTER_VALIDATE_URL)) {
            $this->validationError(['proof_link' => ['لینک مدرک الزامی و باید URL معتبر باشد (https).']]);
            return;
        }
        $host = strtolower((string)(parse_url($proofLink, PHP_URL_HOST) ?: ''));
        if (in_array($host, ['localhost', '127.0.0.1', '0.0.0.0', '::1'], true) || $host === '') {
            $this->validationError(['proof_link' => ['میزبان لینک مدرک معتبر نیست.']]);
            return;
        }

        // FIX-M22-MED (N1): نگاشت فیلدهای موبایل روی قرارداد مشترک جاب — قبلاً
        // proof_link/note به جاب می‌رفت که هیچ‌کدام را نمی‌خواند (جاب proof_url/
        // proof_text می‌خواند) ⇒ مدرک API همیشه 422 می‌شد.
        $result = $this->executorService->submitProof($submissionId, $userId, [
            'proof_url'  => mb_substr($proofLink, 0, 1000),
            'proof_text' => mb_substr($proofNote, 0, 2000),
        ]);
        if (!empty($result['success'])) {
            $this->success(is_array($result['data'] ?? null) ? $result['data'] : [], str_value($result['message'] ?? 'مدرک ثبت شد.'));
        } else {
            $this->error(str_value($result['message'] ?? 'ثبت مدرک ممکن نشد.'), 422, str_value($result['error_code'] ?? '') ?: null);
        }
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
