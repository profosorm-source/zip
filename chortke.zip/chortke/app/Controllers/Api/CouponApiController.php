<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Services\Shared\CouponService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 * 🛡️ FIX-REVGEN-ALIGN (هم‌ترازی زیپ revgen-q4 با درخت REAPPLY — ۲۰۲۶-۱۱-۰۵):
 * خروجی موفق «پاس‌ترو کامل» نتیجهٔ سرویس است (هم‌قرارداد وب — کد/مبلغ‌ها/
 * validation_token). نسخهٔ قبلی کلیدهای discount/coupon را می‌خواند که سرویس
 * هرگز تولید نمی‌کند ⇒ اپ همیشه آرایهٔ خالی می‌دید (باگ واقعی). خطای
 * زیرساخت هم به ۴۲۲ COUPON_VALIDATE_FAILED بدون نشت جزئیات نگاشته می‌شود.
 *
 * مسیرهای API موبایل کد تخفیف. «اعتبارسنجی» خواندنی است و مصرفِ واقعی
 * (redeem) فقط در جریان پرداخت سمت سرور اتفاق می‌افتد (هم‌قرارداد وب —
 * CouponService::validateAndCalculate بدون side-effect است).
 *
 * مسیرها (گروه coupons با اسکوپ coupon.read):
 *   POST /api/v1/coupons/validate   بررسی اعتبار + محاسبهٔ تخفیف
 */
final class CouponApiController extends BaseApiController
{
    private CouponService $couponService;

    public function __construct(
        CouponService $couponService,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->couponService = $couponService;
    }

    /** POST /api/v1/coupons/validate */
    public function validate(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $body = $this->jsonBody();
        $code = strtoupper(trim(str_value($body['code'] ?? '')));
        $amount = str_value($body['amount'] ?? '');
        $currency = strtolower(trim(str_value($body['currency'] ?? 'irt')));
        $applicableTo = strtolower(trim(str_value($body['applicable_to'] ?? 'all')));

        $errors = [];
        if ($code === '') { $errors['code'] = ['کد تخفیف الزامی است.']; }
        if ($amount === '' || !is_numeric($amount) || (float)$amount <= 0) { $errors['amount'] = ['مبلغ باید عددی مثبت باشد.']; }
        if (!in_array($currency, ['irt', 'usdt'], true)) { $errors['currency'] = ['ارز فقط irt یا usdt است.']; }
        if (!in_array($applicableTo, ['all', 'social_task', 'influencer', 'custom_task'], true)) {
            $errors['applicable_to'] = ['دامنه باید all، social_task، influencer یا custom_task باشد.'];
        }
        if ($errors !== []) {
            $this->validationError($errors);
            return;
        }

        // 🛡️ FIX-REVGEN-ALIGN: پاس‌ترو کامل نتیجهٔ سرویس — همان خروجی وب
        // (valid/coupon_code/original_amount/discount_amount/final_amount/
        // currency/validation_token). آرایه‌های discount/coupon نسخهٔ قبل
        // همیشه خالی بودند چون سرویس چنین کلیدهایی برنمی‌گرداند.
        try {
            $result = $this->couponService->validateAndCalculate($code, $amount, $currency, $userId, $applicableTo);
        } catch (\Throwable $e) {
            // خطای زیرساخت خطای کاربر نیست؛ جزئیات داخلی لو نمی‌رود.
            $this->logger->error('api.coupon_validate.failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage(),
            ]);
            $this->error('اعتبارسنجی کد تخفیف در حال حاضر ممکن نیست؛ لطفاً بعداً تلاش کنید.', 422, 'COUPON_VALIDATE_FAILED');
            return;
        }

        if (!empty($result['valid'])) {
            $this->success($result, $result['message'] ?? 'کد تخفیف معتبر است.');
        } else {
            // کد نامعتبر خطای کاربر است (۴۲۲)، نه خطای سیستم — بدون لو دادن
            // جزئیات داخلی؛ فقط همان پیام عمومی سرویس.
            $this->error($result['error'] ?? 'کد تخفیف معتبر نیست.', 422, 'COUPON_INVALID');
        }
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
