<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Services\Shared\CouponService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل کد تخفیف. «اعتبارسنجی» خواندنی است و مصرفِ واقعی
 * (redeem) فقط در جریان پرداخت سمت سرور اتفاق می‌افتد (هم‌قرارداد وب —
 * CouponService::validateAndCalculate بدون side-effect است).
 *
 * مسیرها (گروه coupons با اسکوپ coupon.read):
 *   POST /api/v1/coupons/validate   بررسی اعتبار + محاسبهٔ تخفیف
 */
final class CouponApiController extends BaseApiController
{
    private CouponService $couponService;

    public function __construct(
        CouponService $couponService,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->couponService = $couponService;
    }

    /** POST /api/v1/coupons/validate */
    public function validate(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $body = $this->jsonBody();
        $code = strtoupper(trim(str_value($body['code'] ?? '')));
        $amount = str_value($body['amount'] ?? '');
        $currency = strtolower(trim(str_value($body['currency'] ?? 'irt')));
        $applicableTo = strtolower(trim(str_value($body['applicable_to'] ?? 'all')));

        $errors = [];
        if ($code === '') { $errors['code'] = ['کد تخفیف الزامی است.']; }
        if ($amount === '' || !is_numeric($amount) || (float)$amount <= 0) { $errors['amount'] = ['مبلغ باید عددی مثبت باشد.']; }
        if (!in_array($currency, ['irt', 'usdt'], true)) { $errors['currency'] = ['ارز فقط irt یا usdt است.']; }
        if (!in_array($applicableTo, ['all', 'social_task', 'influencer', 'custom_task'], true)) {
            $errors['applicable_to'] = ['دامنه باید all، social_task، influencer یا custom_task باشد.'];
        }
        if ($errors !== []) {
            $this->validationError($errors);
            return;
        }

        $result = $this->couponService->validateAndCalculate($code, $amount, $currency, $userId, $applicableTo);
        if (!empty($result['valid'])) {
            $this->success([
                'valid'       => true,
                'discount'    => $result['discount'] ?? [],
                'coupon'      => $result['coupon'] ?? [],
            ], $result['message'] ?? 'کد تخفیف معتبر است.');
        } else {
            // کد نامعتبر خطای کاربر است (۴۲۲)، نه خطای سیستم — بدون لو دادن
            // جزئیات داخلی؛ فقط همان پیام عمومی سرویس.
            $this->error($result['error'] ?? 'کد تخفیف معتبر نیست.', 422, 'COUPON_INVALID');
        }
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
