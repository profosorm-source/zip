<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use Core\Request;
use Core\Response;

/**
 * SecurityController — Handling security related callbacks (CSP reports, etc.)
 */
class SecurityController extends BaseController
{
    public function __construct(?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * Handle Content Security Policy violation reports
     *
     * FIX-M11-02 (گزارش دوم ماژول ۱۱): نرمال‌ساز صریح دو قرارداد رسمی —
     * (۱) legacy object (application/csp-report یا JSON object با کلید csp-report)
     * (۲) Reporting API v1 (application/reports+json): آرایهٔ envelope با کلیدهای
     * type/age/url/user_agent/body که فیلدهای CSP داخل body هستند.
     * قبلاً فقط object legacy پشتیبانی می‌شد و envelope آرایه‌ای log تهی/ناقص
     * می‌ساخت؛ body ناقص هم بی‌صدا 204 موفقِ کاذب می‌گرفت. اکنون گزارشِ
     * غیرقابل‌نرمال‌سازی → 400 صریح (سیاست reject، نه 204 پنهان‌کننده).
     */
    public function cspReport(): void
    {
        // FIX-M11-R22-12: سقف اختصاصی ۳۰/min-per-IP (گزارش‌دهی مرورگر خطا هم می‌تواند
        // رگباری باشد؛ سقف عمومی 100/min لایهٔ دفاعِ کافی نیست).
        if (!$this->dedicatedRateLimit('csp_report')) {
            return;
        }
        $rawReport = $this->request->json();

        if (!is_array($rawReport) || $rawReport === []) {
            // malformed/empty body → رد صریح (مرورگر پاسخ را نمی‌خواند؛
            // این قرارداد فقط جلوی 204 موفقِ کاذب را می‌گیرد)
            $this->response->setStatusCode(400);
            $this->response->json(['success' => false, 'error' => ['code' => 'MALFORMED_REPORT', 'message' => 'Report body is empty or malformed.']]);
            return;
        }

        // Reporting API v1: آرایهٔ envelope (کلیدهای عددی)
        $isEnvelopeList = array_is_list($rawReport) && isset($rawReport[0])
            && is_array($rawReport[0])
            && (array_key_exists('body', $rawReport[0]) || array_key_exists('type', $rawReport[0]));

        $reports = $isEnvelopeList ? $rawReport : [$rawReport];

        // FIX-M11-R22-12: سقفِ آیتم — envelope با هزاران آیتم دیگر هزاران خط
        // warning نمی‌سازد (log amplification)؛ مازاد دور ریخته و شمرده می‌شود.
        $totalEnvelopeItems = count($reports);
        $droppedItems = max(0, $totalEnvelopeItems - self::MAX_REPORT_ITEMS);
        if ($droppedItems > 0) {
            $reports = array_slice($reports, 0, self::MAX_REPORT_ITEMS);
            $this->logger->warning('security.csp_report.items_dropped', [
                'total' => $totalEnvelopeItems,
                'kept' => self::MAX_REPORT_ITEMS,
                'dropped' => $droppedItems,
                'ip' => $this->request->ip(),
            ]);
        }

        $loggedAny = false;
        foreach ($reports as $report) {
            if (!is_array($report)) {
                continue;
            }

            if ($isEnvelopeList) {
                // body می‌تواند object یا رشتهٔ JSON باشد (Media Type: application/reports+json)
                $body = $report['body'] ?? null;
                if (is_string($body)) {
                    $decoded = json_decode($body, true);
                    $body = is_array($decoded) ? $decoded : [];
                }
                if (!is_array($body)) {
                    continue;
                }
                $envelopeMeta = [
                    'report_type' => mb_substr(str_value($report['type'] ?? ''), 0, 64),
                    'envelope_url' => mb_substr(str_value($report['url'] ?? ''), 0, 255),
                ];
            } else {
                $body = $report;
                $envelopeMeta = [];
            }

            // legacy csp-report key یا مستقیم فیلدها (EffectiveDirective و…)
            $cspData = $body['csp-report'] ?? $body;
            if (!is_array($cspData) || $cspData === []) {
                continue;
            }

            // FIX-M11-R22-11: نرمال‌سازیِ کاملِ دو قرارداد — Reporting API v1
            // کلیدهای body را camelCase می‌فرستد (Chrome/Edge با report-to):
            // documentURL/blockedURL/effectiveDirective/originalPolicy/statusCode/…؛
            // allowlist قبلی فقط فرمت legacy خط‌تیره داشت ⇒ گزارشِ مرورگرهای مدرن
            // همیشه UNRECONIZED 400 می‌شد و هیچ چیزی لاگ نمی‌شد.
            $cspData = $this->normalizeReportingApiV1($cspData);

            $cleanReport = [];
            $allowedKeys = ['document-uri', 'referrer', 'violated-directive', 'effective-directive', 'original-policy', 'disposition', 'blocked-uri', 'status-code', 'script-sample', 'source-file', 'line-number', 'column-number'];

            foreach ($allowedKeys as $key) {
                if (isset($cspData[$key])) {
                    $val = str_value($cspData[$key]);
                    // Strip query string from URIs to prevent leaking sensitive parameters in logs
                    if (in_array($key, ['document-uri', 'blocked-uri', 'referrer', 'source-file'], true)) {
                        $val = (string)preg_replace('/\?.*$/', '', $val);
                    }
                    $cleanReport[$key] = mb_substr($val, 0, 255);
                }
            }

            if ($cleanReport === []) {
                continue;
            }

            $this->logger->warning('security.csp_violation', array_merge([
                'report' => $cleanReport,
                'ip' => $this->request->ip(),
                'user_agent' => mb_substr((string)$this->request->userAgent(), 0, 255),
            ], $envelopeMeta));

            $loggedAny = true;
        }

        if (!$loggedAny) {
            $this->response->setStatusCode(400);
            $this->response->json(['success' => false, 'error' => ['code' => 'UNRECOGNIZED_REPORT', 'message' => 'No recognizable CSP report found in body.']]);
            return;
        }

        $this->response->setStatusCode(204); // No Content
        $this->response->send();
    }

    /** FIX-M11-R22-12: سقف آیتمِ پردازش‌شده در هر گزارش envelope */
    private const MAX_REPORT_ITEMS = 20;

    /**
     * FIX-M11-R22-11: نگاشتِ Reporting API v1 (camelCase) به فرمت legacy (خط‌تیره).
     * sourceFile/lineNumber/columnNumber هم (فیلدهای واقعی v1) پوشش داده شدند.
     */
    private function normalizeReportingApiV1(array $cspData): array
    {
        static $map = [
            'document-url' => 'document-uri',
            'documentURI' => 'document-uri',
            'blocked-url' => 'blocked-uri',
            'blockedURI' => 'blocked-uri',
            'violated-directive' => 'violated-directive',
            'violatedDirective' => 'violated-directive',
            'effective-directive' => 'effective-directive',
            'effectiveDirective' => 'effective-directive',
            'original-policy' => 'original-policy',
            'originalPolicy' => 'original-policy',
            'status-code' => 'status-code',
            'statusCode' => 'status-code',
            'script-sample' => 'script-sample',
            'sample' => 'script-sample',
            'source-file' => 'source-file',
            'sourceFile' => 'source-file',
            'line-number' => 'line-number',
            'lineNumber' => 'line-number',
            'column-number' => 'column-number',
            'columnNumber' => 'column-number',
            'referrer' => 'referrer',
            'disposition' => 'disposition',
        ];
        $normalized = $cspData;
        foreach ($map as $incoming => $canonical) {
            if (isset($cspData[$incoming]) && !isset($normalized[$canonical])) {
                $normalized[$canonical] = $cspData[$incoming];
            }
        }
        return $normalized;
    }

    /**
     * FIX-M11-R22-12: limiter اختصاصیِ endpointهای عمومی security —
     * ۳۰ درخواست در دقیقه برای هر IP، کلیدِ مستقل از سقف عمومیِ /api/v1.
     * fail-open در خرابی کش (همان الگوی degrade بقیهٔ مسیرها).
     */
    private function dedicatedRateLimit(string $bucket): bool
    {
        try {
            $limiter = app(\Core\RateLimiter::class);
            $key = 'security_public:' . $bucket . ':' . $this->request->ip();
            return $limiter->attempt($key, 30, 1);
        } catch (\Throwable $e) {
            if ($this->logger) {
                $this->logger->warning('security.public_limiter_unavailable', ['bucket' => $bucket, 'error' => $e->getMessage()]);
            }
            return true;
        }
    }

    /**
     * Log security events sent from frontend
     */
    public function logEvent(): void
    {
        // FIX-R19-A4-6: قرارداد همان cspReport — کلیدهای سفید + سقف طول mb_substr؛
        // بدنهٔ کامل کلاینت (هر کلید دلخواه/بدون سقف) دیگر لاگ نمی‌شود (ضد log-spam/PILFer).
        // FIX-M11-R22-12: کامنتِ قدیمی («سقف 30/60 در routes») دیگر درست نبود —
        // FIX-M11-01 آن middleware اختصاصی را حذف کرده بود و فقط سقف عمومی 100/min
        // باقی مانده بود. اکنون هر دو endpoint سقف اختصاصیِ 30/min-per-IP دارند
        // (با کلیدِ مستقل از سقف عمومی) + رویدادِ کلاینت با برچسبِ «untrusted» ثبت می‌شود.
        if (!$this->dedicatedRateLimit('security_event')) {
            return;
        }
        $payload = $this->request->json() ?? $this->request->body();

        if (!is_array($payload) || empty($payload)) {
            $this->response->json(['success' => true]);
            return;
        }

        // کلیدهای واقعی سمت فرانت (public/assets/js/security.js::sendSecurityEvent)
        $allowedKeys = ['event_type', 'device_fingerprint', 'timestamp', 'data'];
        $cleanPayload = [];
        foreach ($allowedKeys as $key) {
            if (!isset($payload[$key])) {
                continue;
            }
            $val = $payload[$key];
            if (is_array($val) || is_object($val)) {
                $val = json_encode($val, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
            } else {
                $val = is_scalar($val) ? str_value($val) : '';
            }
            $cleanPayload[$key] = mb_substr($val, 0, 255);
        }

        // FIX-M11-R22-12: برچسبِ «untrusted client-reported» — رویدادِ بدون احراز
        // هویت قابلِ جعل است؛ کانالِ جدا با برچسبِ صریح، incident response را گمراه نمی‌کند.
        $this->logger->info('security.frontend_event', [
            'payload' => $cleanPayload,
            'ip' => $this->request->ip(),
            'user_agent' => mb_substr((string)$this->request->userAgent(), 0, 255),
            'trust' => 'untrusted client-reported',
        ]);
        $this->response->json(['success' => true]);
    }
}
