<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Models\ContentRevenue;
use App\Models\ContentSubmission;
use App\Services\ContentService;
use App\Services\KYC\KycEligibilityService;
use App\Services\User\UserService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل درآمد تولید محتوا. دو گیتِ عین وب:
 *   ۱) KYC verified (همان گیت وب) + ۲) صلاحیت معتبر (KycEligibilityService).
 * ثبت محتوا از ContentService::submitContent می‌گذرد — یعنی سقف روزانه،
 * سهمیهٔ صف (pending+under_review)، url_hash نرمال‌شده و قرارداد URL
 * دقیقاً همان مسیر وب است (FIX-Q4-MOD24 در این بچ اعمال شده).
 *
 * مسیرها (گروه content با اسکوپ‌های content.read/write):
 *   GET  /api/v1/content/submissions        محتواهای من + آمار وضعیت‌ها
 *   GET  /api/v1/content/submissions/{id}    جزئیات (مالکیت الزامی)
 *   POST /api/v1/content/submissions         ارسال محتوای جدید
 *   POST /api/v1/content/submissions/{id}    ویرایش/بازارسال (FIX-REVGEN-REAPLY)
 *   GET  /api/v1/content/revenues            درآمدهای من (per-currency از مدل)
 *   GET  /api/v1/content/revenues/summary    خلاصهٔ مالی بدون صفحه‌بندی (FIX-REVGEN-REAPLY)
 *   GET  /api/v1/content/share-preview       پیش‌نمایش سهم (MOD24-12)
 *   GET  /api/v1/content/agreement           متن تعهدنامه + تنظیمات (FIX-REVGEN-REAPLY)
 */
final class ContentApiController extends BaseApiController
{
    private ContentSubmission $submissionModel;
    private ContentRevenue $revenueModel;
    private ContentService $contentService;
    private KycEligibilityService $kycEligibility;
    private UserService $userService;

    public function __construct(
        ContentSubmission $submissionModel,
        ContentRevenue $revenueModel,
        ContentService $contentService,
        KycEligibilityService $kycEligibility,
        UserService $userService,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->submissionModel = $submissionModel;
        $this->revenueModel = $revenueModel;
        $this->contentService = $contentService;
        $this->kycEligibility = $kycEligibility;
        $this->userService = $userService;
    }

    /** گیت مشترک وب: KYC verified + صلاحیت معتبر — fail-closed */
    private function requireContentEligible(int $userId): bool
    {
        $user = $this->userService->find($userId);
        if (!$user || ($user->kyc_status ?? '') !== 'verified') {
            $this->error('جهت فعالیت در سیستم تولید محتوا، احراز هویت حساب شما باید تکمیل و تایید شده باشد.', 403, 'KYC_REQUIRED');
            return false;
        }
        if (!$this->kycEligibility->isEligible($userId)) {
            $this->error('احراز هویت شما معتبر نیست یا منقضی شده است؛ لطفاً مجدداً اقدام کنید.', 403, 'KYC_EXPIRED');
            return false;
        }
        return true;
    }

    /** GET /api/v1/content/submissions */
    public function submissions(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        if (!$this->requireContentEligible($userId)) {
            return;
        }
        [$page, $perPage] = $this->paginationParams(10);
        $status = strtolower(trim(str_value($this->request->param('status', ''))));
        $allowed = ['pending', 'under_review', 'approved', 'published', 'rejected', 'suspended', ''];
        if (!in_array($status, $allowed, true)) {
            $status = '';
        }
        $data = $this->submissionModel->getUserContentData($userId, $status !== '' ? $status : null, $perPage, ($page - 1) * $perPage);
        /** @var list<\stdClass> $submissionRows */
        $submissionRows = $data['submissions'] ?? [];
        $submissions = array_map(static fn(\stdClass $s): array => [
            'id'          => (int)$s->id,
            'platform'    => str_value($s->platform ?? ''),
            'title'       => str_value($s->title ?? ''),
            'video_url'   => str_value($s->video_url ?? ''),
            'status'      => str_value($s->status ?? ''),
            'created_at'  => str_value($s->created_at ?? ''),
        ], $submissionRows);

        $this->success([
            'submissions' => $submissions,
            'stats'        => $data['stats'] ?? [],
        ]);
    }

    /** GET /api/v1/content/submissions/{id} */
    public function showSubmission(int $submissionId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        if (!$this->requireContentEligible($userId)) {
            return;
        }
        /** @var \stdClass|null $submission */
        $submission = $this->submissionModel->find($submissionId);
        if (!$submission || (int)$submission->user_id !== $userId) {
            $this->error('محتوا یافت نشد یا متعلق به شما نیست.', 404, 'SUBMISSION_NOT_FOUND');
            return;
        }
        $this->success([
            'submission' => [
                'id'              => (int)$submission->id,
                'platform'        => str_value($submission->platform ?? ''),
                'title'           => str_value($submission->title ?? ''),
                'video_url'       => str_value($submission->video_url ?? ''),
                'status'          => str_value($submission->status ?? ''),
                'rejection_reason'=> str_value($submission->rejection_reason ?? ''),
                'published_url'   => str_value($submission->published_url ?? ''),
                'created_at'      => str_value($submission->created_at ?? ''),
            ],
        ]);
    }

    /** POST /api/v1/content/submissions */
    public function store(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        if (!$this->requireContentEligible($userId)) {
            return;
        }
        $body = $this->jsonBody();

        $platform = strtolower(trim(str_value($body['platform'] ?? '')));
        $title = trim(str_value($body['title'] ?? ''));
        $videoUrl = trim(str_value($body['video_url'] ?? ''));
        $agreementAccepted = int_value($body['agreement_accepted'] ?? 0) === 1;
        $description = trim(str_value($body['description'] ?? ''));
        $category = trim(str_value($body['category'] ?? ''));

        $errors = [];
        if ($platform === '') { $errors['platform'] = ['پلتفرم الزامی است.']; }
        if ($title === '') { $errors['title'] = ['عنوان الزامی است.']; }
        if ($videoUrl === '') { $errors['video_url'] = ['لینک ویدیو الزامی است.']; }
        if (!$agreementAccepted) { $errors['agreement_accepted'] = ['تعهدنامه باید پذیرفته شود.']; }
        if ($errors !== []) {
            $this->validationError($errors);
            return;
        }

        $result = $this->contentService->submitContent($userId, [
            'platform'           => $platform,
            'title'              => $title,
            'video_url'          => $videoUrl,
            'description'        => $description,
            'category'           => $category,
            'agreement_accepted' => 1,
        ]);

        if (!empty($result['success'])) {
            $this->success($result['data'] ?? [], str_value($result['message'] ?? 'محتوا ثبت شد.'));
        } else {
            $this->error(str_value($result['message'] ?? 'ثبت محتوا ممکن نشد.'), 422, null);
        }
    }

    /** GET /api/v1/content/revenues */
    public function revenues(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        /** @var list<\stdClass> $rows */
        $rows = $this->revenueModel->getByUser($userId, $perPage, ($page - 1) * $perPage);
        $this->success([
            'revenues' => array_map(static fn(\stdClass $r): array => [
                'id'            => (int)$r->id,
                'submission_id' => (int)($r->submission_id ?? 0),
                'period'        => str_value($r->period ?? ''),
                'total_revenue' => str_value($r->total_revenue ?? '0'),
                'net_user_amount' => str_value($r->net_user_amount ?? '0'),
                'currency'      => str_value($r->currency ?? 'irt'),
                'status'        => str_value($r->status ?? ''),
                'created_at'    => str_value($r->created_at ?? ''),
            ], $rows),
        ]);
    }

    /** GET /api/v1/content/share-preview */
    public function sharePreview(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        // پیش‌نمایش سهم نیازی به KYC ندارد (فقط محاسبه است، نه ثبت)
        $preview = $this->contentService->getUserSharePreview($userId);
        $this->success(['preview' => $preview]);
    }

    /**
     * 📱 FIX-REVGEN-REAPLY (بازکاربرد REVGEN — ۲۰۲۶-۱۱-۰۳):
     * GET /api/v1/content/agreement — متن تعهدنامه + تنظیمات عمومی.
     *
     * کلاینت موبایل قبل از اولین ارسال باید تعهدنامه را نمایش دهد؛ متن از
     * همان منبع واحد سرویس می‌آید (هم‌متنِ وب). KYC لازم نیست — فقط خواندن.
     */
    public function agreement(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }

        $settings = $this->contentService->getSettings();
        $preview = $this->contentService->getUserSharePreview($userId);

        $this->success([
            'agreement_text'    => $this->contentService->getAgreementText(),
            'allowed_platforms' => $settings['allowed_platforms'] ?? [],
            'site_share_percent' => $settings['site_share_percent'] ?? 40,
            'tax_percent'       => $settings['tax_percent'] ?? 9,
            'min_months'        => $settings['min_months'] ?? 2,
            'share_preview'     => $preview,
        ]);
    }

    /**
     * 📱 FIX-REVGEN-REAPLY: GET /api/v1/content/revenues/summary —
     * خلاصهٔ مالی درآمد من (بدون صفحه‌بندی؛ قرارداد paginated در /revenues حفظ شد).
     */
    public function revenuesSummary(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }

        $this->success([
            'summary' => [
                'total_net'   => $this->revenueModel->getTotalUserRevenue($userId),
                'paid_net'    => $this->revenueModel->getTotalUserRevenue($userId, 'paid'),
                'pending_net' => $this->revenueModel->getTotalUserRevenue($userId, 'pending'),
            ],
        ]);
    }

    /**
     * 📱 FIX-REVGEN-REAPLY: POST /api/v1/content/submissions/{id} — ویرایش/بازارسال.
     *
     * بدنه هم‌قرارداد فرم وب: platform, video_url, title, description?, category?.
     * ردیف rejected با بازارسال به صف بررسی برمی‌گردد و url_hash دوباره قفل
     * می‌شود (FIX-Q4-MOD24-05/06 در سرویس). همان گیت KYC وب/ارسال جدید.
     */
    public function update(int $submissionId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        if (!$this->requireContentEligible($userId)) {
            return;
        }

        $body = $this->jsonBody();
        $errors = [];
        foreach (['platform', 'video_url', 'title'] as $field) {
            if (!isset($body[$field]) || trim(str_value($body[$field])) === '') {
                $errors[$field] = ["فیلد {$field} الزامی است"];
            }
        }
        if ($errors !== []) {
            $this->validationError($errors);
            return;
        }

        try {
            $result = $this->contentService->updateSubmission($userId, $submissionId, [
                'platform'    => strtolower(trim(str_value($body['platform']))),
                'video_url'   => trim(str_value($body['video_url'])),
                'title'       => trim(str_value($body['title'])),
                'description' => trim(str_value($body['description'] ?? '')),
                'category'    => trim(str_value($body['category'] ?? '')),
            ]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            $this->error($e->getMessage(), 422, 'CONTENT_UPDATE_FAILED');
            return;
        } catch (\Throwable $e) {
            $this->logger->error('api.content_update.failed', ['user_id' => $userId, 'id' => $submissionId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در به‌روزرسانی محتوا.', 422, 'CONTENT_UPDATE_FAILED');
            return;
        }

        if (empty($result['success'])) {
            $this->error(str_value($result['message'] ?? 'به‌روزرسانی محتوا ناموفق بود'), 422, 'CONTENT_UPDATE_FAILED');
            return;
        }
        $this->success($result['data'] ?? [], str_value($result['message'] ?? 'محتوا به‌روزرسانی شد'));
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
