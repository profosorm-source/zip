<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Controllers\BaseController;

/**
 * BaseApiController - کنترلر پایه API
 *
 * همه API controllers باید از این کلاس extend کنند.
 * متدهای کمکی برای پاسخ‌های استاندارد JSON.
 */
abstract class BaseApiController extends BaseController
{
    #[\Core\Attributes\Inject]
    protected \Core\Container $container;
    public function __construct(
        ?\Core\Session $session = null,
        ?\Core\Request $request = null,
        ?\Core\Response $response = null,
        ?\App\Services\Shared\PolicyService $policyService = null,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, $policyService, $logger);
        // اطمینان از هدر صحیح برای پاسخ‌های API
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
        }
    }

    /** پاسخ موفق */
    protected function success(mixed $data = null, string $message = '', int $code = 200): void
    {
        $this->response->json([
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ], $code);
    }

    /** پاسخ با pagination */
    /** @param list<mixed> $items */
    protected function paginated(array $items, int $total, int $page, int $perPage): void
    {
        $this->response->json([
            'success' => true,
            'data'    => $items,
            'meta'    => $this->paginationMeta($total, $page, $perPage),
        ], 200);
    }

    /**
     * 📱 FIX-MOBCTR-04 (A3-N7 — بچ قرارداد API موبایل ۲۰۲۶-۱۱-۰۷): شکلِ
     * استاندارد meta صفحه‌بندی به‌صورت متد مشترک — endpoint هایی که آرایهٔ
     * خود را زیر کلید نام‌دار برمی‌گردانند (مثل data.tasks) می‌توانند همان
     * meta را بدون تغییر شکل data موجودشان اضافه کنند (سازگاری با کلاینت‌های
     * فعلی + تشخیص پایان لیست با last_page/total).
     *
     * @return array{total: int, per_page: int, current_page: int, last_page: int, from: int, to: int}
     */
    protected function paginationMeta(int $total, int $page, int $perPage): array
    {
        return [
            'total'        => $total,
            'per_page'     => $perPage,
            'current_page' => $page,
            'last_page'    => (int)ceil($total / $perPage),
            'from'         => ($page - 1) * $perPage + 1,
            'to'           => min($page * $perPage, $total),
        ];
    }

    /** پاسخ خطا — FIX-M11-R22-16: قرارداد واحد ErrorContract همهٔ لایه‌های API.
     *  {success:false, message, error_code, error:{code,message}, data:{error_code}}
     *  فیلدهای قدیمی (message/error_code/data.error_code) برای سازگاری موقت حفظ شدند
     *  و کلاینت‌ها به error.code مهاجرت می‌کنند.
     * @throws \Core\Exceptions\HttpResponseException (FIX-PSTAN: json/send = abort؛ فراخوانی‌کننده هرگز ادامه نمی‌یابد)
     */
    /** @param array<string, mixed> $extra فیلدهای اضافی سطح‌بالای پاسخ خطا (FIX-R64-B) */
    protected function error(string $message, int $code = 400, ?string $errorCode = null, array $extra = []): void
    {
        // FIX-R64-B: $extra فیلدهای اضافی سطح‌بالای پاسخ خطا را merge می‌کند
        // (مثلاً fraud_detected برای مسیر complete سئو) بدون شکستن قرارداد فعلی.
        $this->response->json(array_merge([
            'success' => false,
            'message' => $message,
            'error'   => ['code' => $errorCode ?? 'ERROR', 'message' => $message],
            'error_code' => $errorCode,
            'data'    => ['error_code' => $errorCode],
        ], $extra), $code);
    }

    /** خطای اعتبارسنجی — FIX-M11-R22-16: هم‌قراردادِ ErrorContract */
    /** @param array<string, mixed> $errors */
    protected function validationError(array $errors): void
    {
        $this->response->json([
            'success' => false,
            'message' => 'خطای اعتبارسنجی',
            'error'   => ['code' => 'VALIDATION_ERROR', 'message' => 'خطای اعتبارسنجی'],
            'error_code' => 'VALIDATION_ERROR',
            'data'    => ['errors' => $errors],
        ], 422);
    }

    /** کاربر جاری (از middleware inject شده) */
    protected function currentUser(): ?\stdClass
    {
        return $this->request->getUser();
    }

    /** ID کاربر جاری */
    protected function userId(): int
    {
        return (int)($this->currentUser()->id ?? 0);
    }

    /** دریافت pagination params */
    /** @return array{0: int, 1: int, 2: int} */
    protected function paginationParams(int $defaultPerPage = 20): array
    {
        $page    = max(1, $this->request->int('page', 1));
        $perPage = min(100, max(1, $this->request->int('per_page', $defaultPerPage)));
        $offset  = ($page - 1) * $perPage;
        return [$page, $perPage, $offset];
    }
}
