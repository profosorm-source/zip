<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Contracts\WalletServiceInterface;
use App\Models\Transaction;
use App\Services\User\UserService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل انتقال پول بین‌کاربری. منبع واحد حقیقتِ انتقال
 * WalletService::transfer است — همان قفل‌ها، idempotency و گارد تقلب وب.
 * مرزهای عمدی API (سخت‌گیرتر از وبِ فرم‌محور):
 *   - Idempotency-Key الزامی است (وب آن را در فرم hidden می‌سازد؛ در API
 *     کلاینت مسئول است) — بدون آن ۴۲۲ بدون side-effect.
 *   - سقف/کف مبلغ همان CreateTransferRequest وب (۱۰۰۰..۹۹۹,۹۹۹,۹۹۹ تومان).
 *   - گیرنده با شناسهٔ عمومی (username/email) جستجو می‌شود ولی پاسخ فقط
 *     نام نمایشی می‌دهد (ضد enum کاربران).
 *
 * مسیرها (گروه transfers با اسکوپ transfer.read / transfer.write(exact-only)):
 *   GET  /api/v1/transfers        تاریخچهٔ انتقال‌های من
 *   POST /api/v1/transfers        انتقال جدید
 */
final class TransferApiController extends BaseApiController
{
    private WalletServiceInterface $walletService;
    private UserService $userService;
    private Transaction $transactionModel;

    public function __construct(
        WalletServiceInterface $walletService,
        UserService $userService,
        Transaction $transactionModel,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->walletService = $walletService;
        $this->userService = $userService;
        $this->transactionModel = $transactionModel;
    }

    /** GET /api/v1/transfers */
    public function index(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        /** @var list<\stdClass> $rows */
        $rows = $this->transactionModel->getUserTransactions($userId, 'transfer', null, $perPage, ($page - 1) * $perPage);
        $this->success([
            'transfers' => array_map(static fn(\stdClass $t): array => [
                'id'            => (int)$t->id,
                'amount'        => str_value($t->amount ?? '0'),
                'currency'      => str_value($t->currency ?? 'irt'),
                // جهت: منفی = خروجی از من؛ مثبت = ورودی به من
                'direction'     => ((float)$t->amount < 0) ? 'outgoing' : 'incoming',
                'status'        => str_value($t->status ?? ''),
                'description'   => str_value($t->description ?? ''),
                'created_at'    => str_value($t->created_at ?? ''),
            ], $rows),
        ]);
    }

    /** POST /api/v1/transfers */
    public function store(): void
    {
        $senderId = (int)$this->userId();
        if ($senderId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $body = $this->jsonBody();

        $recipient = trim(str_value($body['recipient'] ?? ''));
        $amount = str_value($body['amount'] ?? '');
        $description = mb_substr(trim(str_value($body['description'] ?? '')), 0, 500);
        $currency = 'irt';

        $errors = [];
        if (mb_strlen($recipient) < 3 || mb_strlen($recipient) > 255) {
            $errors['recipient'] = ['شناسهٔ گیرنده (نام کاربری یا ایمیل) بین ۳ تا ۲۵۵ کاراکتر است.'];
        }
        if ($amount === '' || !preg_match('/^\d{1,9}$/', $amount)
            || (int)$amount < 1000 || (int)$amount > 999999999) {
            $errors['amount'] = ['مبلغ باید عدد صحیح بین ۱,۰۰۰ تا ۹۹۹,۹۹۹,۹۹۹ تومان باشد.'];
        }
        if ($errors !== []) {
            $this->validationError($errors);
            return;
        }

        // Idempotency-Key الزامی — بدون آن هیچ side-effect ای رخ نمی‌دهد
        $clientKey = trim(str_value($this->request->header('Idempotency-Key', '')));
        if ($clientKey === '' || strlen($clientKey) < 8 || strlen($clientKey) > 128
            || !preg_match('/^[A-Za-z0-9_.:-]+$/', $clientKey)) {
            $this->validationError(['idempotency_key' => ['هدر Idempotency-Key الزامی است: رشتهٔ ۸ تا ۱۲۸ کاراکتری alphanumeric.']]);
            return;
        }

        $recipientRow = $this->userService->findByCredentials($recipient);
        if (!$recipientRow) {
            $this->error('کاربر گیرنده یافت نشد.', 404, 'RECIPIENT_NOT_FOUND');
            return;
        }
        $recipientId = (int)$recipientRow->id;
        if ($recipientId === $senderId) {
            $this->error('امکان انتقال اعتبار به خودتان وجود ندارد.', 422, 'SELF_TRANSFER_FORBIDDEN');
            return;
        }

        $result = $this->walletService->transfer(
            $senderId,
            $recipientId,
            $amount,
            $currency,
            $description,
            $clientKey
        );

        if (!empty($result['success'])) {
            $this->success(is_array($result['data'] ?? null) ? $result['data'] : [], str_value($result['message'] ?? 'انتقال انجام شد.'));
        } else {
            $code = 422;
            $errorCode = str_value($result['error_code'] ?? '') ?: null;
            if (($errorCode === 'IDEMPOTENCY_REPLAY') || str_contains(str_value($result['message'] ?? ''), 'تکراری')) { $code = 200; }
            if ($errorCode === 'RATE_LIMITED') { $code = 429; }
            $this->error(str_value($result['message'] ?? 'انتقال ممکن نشد.'), $code, $errorCode);
        }
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
