<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Services\Shared\ReferralService;
use Core\Request;
use Core\Response;
use Core\Session;
use App\Services\Shared\PolicyService;

/**
 * ReferralApiController — دستاوردها و ادعای پاداش‌های رفرال از کانال API.
 *
 * 📱 FIX-REVGEN-REAPLY (بازکاربرد REVGEN روی درخت FIX-MOBILE-06 — ۲۰۲۶-۱۱-۰۳):
 * آمارِ رفرال از قبل در API بود (/user/referral/stats، /wallet/referrals/*)
 * ولی «ادعای پاداش میلستون‌ها» فقط دکمهٔ وب داشت — کاربر اپ موبایل
 * میلستون‌های SILVER/GOLD/PLATINUM رسیده ولی پاداشش را نمی‌توانست بگیرد.
 *
 *   GET  /referrals/milestones     → نمای کامل میلستون‌ها (دست‌یافته + در دسترس)
 *   POST /referrals/rewards/claim  → همان checkAndAwardMilestones وب (idempotent)
 *
 * اسکوپ‌ها: referral.read / referral.write (پوشش‌پذیر با read/write سراسری —
 * هم‌الگوی content و seo). claim پاداش می‌دهد ⇒ write.
 */
final class ReferralApiController extends BaseApiController
{
    private ReferralService $referralService;

    public function __construct(
        ReferralService $referralService,
        ?LoggerInterface $logger = null,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?PolicyService $policyService = null
    ) {
        parent::__construct($session, $request, $response, $policyService, $logger);
        $this->referralService = $referralService;
    }

    /**
     * GET /api/v1/referrals/milestones — نمای میلستون‌ها + شمار مرجع‌های تأییدشده.
     */
    public function milestones(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        $overview = $this->referralService->getMilestoneOverview($userId);
        $this->success([
            'referral_count' => int_value($overview['referral_count'] ?? 0),
            'achieved'       => $overview['achieved'] ?? [],
            'available'      => $overview['available'] ?? [],
        ]);
    }

    /**
     * POST /api/v1/referrals/rewards/claim — اعطای میلستون‌های رسیده (idempotent).
     *
     * همان موتور وب: checkAndAwardMilestones — میلستونِ قبلاً اعطاشده دوباره
     * پاداش نمی‌دهد (رکورد referral_user_milestones) و kill-switch کمیسیون
     * رفرال این مسیر را هم می‌بندد.
     */
    public function claimRewards(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت نشده', 401, 'UNAUTHENTICATED');
            return;
        }

        try {
            $result = $this->referralService->checkAndAwardMilestones($userId);
        } catch (\Throwable $e) {
            $this->logger->error('api.referral_claim.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در ادعای پاداش‌ها.', 422, 'REFERRAL_CLAIM_FAILED');
            return;
        }

        $this->success($result, 'بررسی میلستون‌ها انجام شد');
    }
}
