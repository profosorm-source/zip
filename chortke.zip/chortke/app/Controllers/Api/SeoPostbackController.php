<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Models\Ads;
use App\Models\SeoExecution;
use App\Models\SeoLandingProofTest;
use App\Services\SeoLandingProofService;

/**
 * 🛡️ FIX-SEO-23-01 (فاز ۲) — کنترلر پست‌بک اثبات فرود سئو.
 *
 * مسیر عمومی (بدون احراز هویت — سرور تبلیغ‌دهنده صدا می‌زند):
 *   GET|POST /api/v1/seo/postback?token=…&ts=…&sig=…
 *   sig = HMAC-SHA256(ads.seo_postback_secret, "{token}|{ts}")  (hex کوچک)
 *
 * اثبات از جنسِ «راز مشترک سرور-به-سرور» است: توکن فرود را کاربر در آدرس
 * می‌بیند، اما ساختِ امضای معتبر بدون رازِ سرور تبلیغ‌دهنده ناممکن است —
 * پلهٔ پاداش فرود (۱۰۰٪) عملاً به همکاری سرورِ تبلیغ‌دهنده گره می‌خورد.
 * این همان «پست‌بک جایگزین» برای سایت‌هایی است که تصویر ردیاب نمی‌توانند
 * بگذارند (خارج از کنترل محتوا، CDN، ایمیل/پیام‌محور و...).
 *
 * پاسخ‌ها JSON و صریح‌اند تا ادغام‌دهندهٔ تبلیغ‌دهنده دیباگ راحت باشد؛
 * وضعیت‌های موفق: verified | test_received | already_verified.
 */
class SeoPostbackController extends BaseApiController
{
    private SeoLandingProofService $proof;

    public function __construct(?\App\Contracts\LoggerInterface $logger = null)
    {
        parent::__construct(null, null, null, null, $logger);
        $this->proof = new SeoLandingProofService(
            new SeoExecution(db()),
            new SeoLandingProofTest(db()),
            new Ads(db()),
            db(),
            logger()
        );
    }

    public function handle(): void
    {
        // GET و POST هر دو پذیرفته می‌شوند (ادغام‌دهنده‌ها سلیقهٔ متفاوت دارند):
        // بدنهٔ JSON/فرم اولویت دارد؛ پارامتر query string به‌عنوان fallback.
        $token = str_value($this->request->body('token') ?? $this->request->get('token') ?? '');
        $ts    = str_value($this->request->body('ts') ?? $this->request->get('ts') ?? '');
        $sig   = str_value($this->request->body('sig') ?? $this->request->get('sig') ?? '');
        $ip    = str_value($_SERVER['REMOTE_ADDR'] ?? '');

        $result = $this->proof->handlePostback($token, $ts, $sig, $ip);

        $okStatuses = ['verified', 'test_received', 'already_verified'];
        $http = in_array($result['status'], $okStatuses, true) ? 200 : 422;
        $this->response->json([
            'success' => in_array($result['status'], $okStatuses, true),
            'status'  => $result['status'],
            'channel' => $result['channel'],
            'detail'  => $result['detail'],
        ], $http);
    }
}
