<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Models\PredictionBet;
use App\Models\PredictionGame;
use App\Services\PredictionService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل بازی‌های پیش‌بینی. منبع واحد حقیقتِ ثبت شرط
 * PredictionService::placeBet است (هم‌الگوی وب) — سرویس خودش
 * idempotency/قفل/اعتبارسنجی مبلغ و گزینه را دارد.
 *
 * مسیرها (گروه prediction با اسکوپ‌های prediction.read/write):
 *   GET  /api/v1/prediction/games          بازی‌های باز + نتایج اخیر عمومی
 *   GET  /api/v1/prediction/games/{id}     جزئیات یک بازی + شرط من روی آن
 *   GET  /api/v1/prediction/my/bets        شرط‌های من + خلاصه
 *   POST /api/v1/prediction/bets           ثبت شرط (Idempotency-Key الزامی)
 */
final class PredictionApiController extends BaseApiController
{
    private PredictionGame $gameModel;
    private PredictionBet $betModel;
    private PredictionService $predictionService;

    public function __construct(
        PredictionGame $gameModel,
        PredictionBet $betModel,
        PredictionService $predictionService,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->gameModel = $gameModel;
        $this->betModel = $betModel;
        $this->predictionService = $predictionService;
    }

    /** GET /api/v1/prediction/games */
    public function games(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        /** @var list<\stdClass> $open */
        $open = $this->gameModel->getOpen($perPage, ($page - 1) * $perPage);
        /** @var list<\stdClass> $recent */
        $recent = $this->gameModel->getPublicRecent([PredictionGame::STATUS_FINISHED, PredictionGame::STATUS_CANCELLED], 6, 0);
        $this->success([
            'open_games'   => array_map([$this, 'presentGame'], $open),
            'recent_finished' => array_map([$this, 'presentGame'], $recent),
        ]);
    }

    /** GET /api/v1/prediction/games/{id} */
    public function show(int $gameId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $game = $this->gameModel->find($gameId);
        if (!$game) {
            $this->error('بازی یافت نشد.', 404, 'GAME_NOT_FOUND');
            return;
        }
        $myBet = null;
        if ((string)$game->status === PredictionGame::STATUS_OPEN) {
            $betRow = $this->betModel->getByUserAndGame($userId, $gameId);
            if ($betRow) {
                $myBet = [
                    'id' => (int)$betRow->id,
                    'prediction' => str_value($betRow->prediction ?? ''),
                    'amount' => str_value($betRow->amount ?? '0'),
                    'amount_usdt' => str_value($betRow->amount_usdt ?? '0'),
                    'status' => str_value($betRow->status ?? ''),
                ];
            }
        }
        $this->success(['game' => $this->presentGame($game), 'my_bet' => $myBet]);
    }

    /** GET /api/v1/prediction/my/bets */
    public function myBets(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        /** @var list<\stdClass> $bets */
        $bets = $this->betModel->getByUser($userId, $perPage, ($page - 1) * $perPage);
        $total = $this->betModel->countByUser($userId);
        $this->paginated(array_map(static fn(\stdClass $b): array => [
            'id'         => (int)$b->id,
            'game_id'    => (int)($b->game_id ?? 0),
            'game_title' => str_value($b->game_title ?? ''),
            'team_home'  => str_value($b->team_home ?? ''),
            'team_away'  => str_value($b->team_away ?? ''),
            'game_result'=> str_value($b->game_result ?? ''),
            'game_status'=> str_value($b->game_status ?? ''),
            'prediction' => str_value($b->prediction ?? ''),
            'amount'     => str_value($b->amount ?? '0'),
            'amount_usdt'=> str_value($b->amount_usdt ?? '0'),
            'currency'   => str_value($b->currency ?? 'irt'),
            'status'     => str_value($b->status ?? ''),
            'payout_amount'   => str_value($b->payout_amount ?? '0'),
            'payout_usdt'     => str_value($b->payout_usdt ?? '0'),
            'created_at' => str_value($b->created_at ?? ''),
        ], $bets), $total, $page, $perPage);
    }

    /** POST /api/v1/prediction/bets — ثبت شرط */
    public function placeBet(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $body = $this->jsonBody();
        $gameId = int_value($body['game_id'] ?? 0);
        $prediction = strtolower(trim(str_value($body['prediction'] ?? '')));
        $amount = str_value($body['amount'] ?? '');

        $errors = [];
        if ($gameId <= 0) { $errors['game_id'] = ['شناسه بازی الزامی است.']; }
        if (!in_array($prediction, ['home', 'away', 'draw'], true)) { $errors['prediction'] = ['پیش‌بینی باید home، away یا draw باشد.']; }
        if ($amount === '' || !is_numeric($amount) || (float)$amount <= 0) { $errors['amount'] = ['مبلغ باید عددی مثبت باشد.']; }
        if ($errors !== []) {
            $this->validationError($errors);
            return;
        }

        $idempotencyKey = trim(str_value($this->request->header('Idempotency-Key', '')));
        if ($idempotencyKey === '' || strlen($idempotencyKey) < 8 || strlen($idempotencyKey) > 128
            || !preg_match('/^[A-Za-z0-9_.:-]+$/', $idempotencyKey)) {
            $this->validationError(['idempotency_key' => ['هدر Idempotency-Key الزامی است: رشتهٔ ۸ تا ۱۲۸ کاراکتری alphanumeric.']]);
            return;
        }

        $result = $this->predictionService->placeBet($userId, $gameId, $prediction, $amount, $idempotencyKey);
        if (!empty($result['success'])) {
            $this->success(is_array($result['data'] ?? null) ? $result['data'] : [], str_value($result['message'] ?? 'شرط ثبت شد.'));
        } else {
            $code = 422;
            if (($result['error_code'] ?? '') === 'RATE_LIMITED') { $code = 429; }
            $this->error(str_value($result['message'] ?? 'ثبت شرط ممکن نشد.'), $code, str_value($result['error_code'] ?? '') ?: null);
        }
    }

    /**
     * @param \stdClass $game
     * @return array<string, mixed>
     */
    private function presentGame(\stdClass $game): array
    {
        return [
            'id'            => (int)$game->id,
            'title'         => str_value($game->title ?? ''),
            'sport_type'    => str_value($game->sport_type ?? ''),
            'team_home'     => str_value($game->team_home ?? ''),
            'team_away'     => str_value($game->team_away ?? ''),
            'status'        => str_value($game->status ?? ''),
            'min_bet_usdt'  => str_value($game->min_bet_usdt ?? '0'),
            'max_bet_usdt'  => str_value($game->max_bet_usdt ?? '0'),
            'total_pool_usdt'    => str_value($game->total_pool ?? '0'),
            'pool_home_usdt'     => str_value($game->pool_home ?? '0'),
            'pool_away_usdt'     => str_value($game->pool_away ?? '0'),
            'pool_draw_usdt'     => str_value($game->pool_draw ?? '0'),
            'bet_deadline'  => str_value($game->bet_deadline ?? ''),
            'match_date'    => str_value($game->match_date ?? ''),
            'result'        => str_value($game->result ?? ''),
        ];
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
