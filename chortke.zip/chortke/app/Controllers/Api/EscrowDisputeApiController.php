<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Services\EscrowService;
use App\Services\Shared\DisputeService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل Escrow/Dispute عمومی (نه فقط اینفلوئنسر — آن مسیر
 * از قبل /api/v1/influencer/* را دارد). منابع واحد حقیقت همان سرویس‌های وب:
 *   - DisputeService::getUserDisputes / findDetailWithSubmission /
 *     addMessageWithContext (با نقش و مالکیتِ خودش)
 *   - EscrowService::getByOrder (وضعیت وجوه در escrow یک سفارش)
 *
 * مسیرها (گروه‌های escrow/disputes با اسکوپ‌های escrow.read، dispute.read/write):
 *   GET  /api/v1/escrows/by-order/{type}/{orderId}   وضعیت escrow یک سفارش (مالکیت الزامی)
 *   GET  /api/v1/disputes                            پرونده‌های اختلاف من
 *   GET  /api/v1/disputes/{id}                       جزئیات + پیام‌ها (مالکیت الزامی)
 *   POST /api/v1/disputes/{id}/reply                 پیام جدید در پرونده
 */
final class EscrowDisputeApiController extends BaseApiController
{
    private DisputeService $disputeService;
    private EscrowService $escrowService;

    public function __construct(
        DisputeService $disputeService,
        EscrowService $escrowService,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->disputeService = $disputeService;
        $this->escrowService = $escrowService;
    }

    /** GET /api/v1/escrows/by-order/{type}/{orderId} */
    public function escrowByOrder(string $orderType, int $orderId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        // سفید-لیست نوع سفارش — بدون آن، escrow هر جدولی قابل جستجو می‌شد
        $orderType = strtolower(trim($orderType));
        if (!in_array($orderType, ['custom_task_budget', 'influencer_order', 'vitrine_trade'], true)) {
            $this->validationError(['order_type' => ['نوع سفارش باید custom_task_budget، influencer_order یا vitrine_trade باشد.']]);
            return;
        }
        if ($orderId <= 0) {
            $this->validationError(['order_id' => ['شناسهٔ سفارش نامعتبر است.']]);
            return;
        }

        /** @var \stdClass|null $escrow */
        $escrow = $this->escrowService->getByOrder($orderId, $orderType);
        if (!$escrow) {
            $this->error('escrow برای این سفارش یافت نشد.', 404, 'ESCROW_NOT_FOUND');
            return;
        }
        // مالکیت: فقط خریدار یا فروشندهٔ همان escrow
        $buyerId = (int)($escrow->buyer_id ?? 0);
        $sellerId = (int)($escrow->seller_id ?? 0);
        if ($userId !== $buyerId && $userId !== $sellerId) {
            $this->error('این escrow متعلق به شما نیست.', 403, 'FORBIDDEN');
            return;
        }

        $this->success([
            'escrow' => [
                'id'            => (int)$escrow->id,
                'order_type'    => $orderType,
                'order_id'      => $orderId,
                'buyer_id'      => $buyerId,
                'seller_id'     => $sellerId,
                'amount'        => str_value($escrow->amount ?? '0'),
                'currency'      => str_value($escrow->currency ?? 'irt'),
                'status'        => str_value($escrow->status ?? ''),
                'released_at'   => str_value($escrow->released_at ?? ''),
                'created_at'    => str_value($escrow->created_at ?? ''),
            ],
        ]);
    }

    /** GET /api/v1/disputes */
    public function disputes(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(20);
        /** @var list<\stdClass> $rows */
        $rows = $this->disputeService->getUserDisputes($userId, $perPage, ($page - 1) * $perPage);
        $total = $this->disputeService->countUserDisputes($userId);
        $this->paginated(array_map(static fn(\stdClass $d): array => [
            'id'         => (int)$d->id,
            'ref_type'   => str_value($d->ref_type ?? ''),
            'ref_id'     => (int)($d->ref_id ?? 0),
            'status'     => str_value($d->status ?? ''),
            'reason'     => str_value($d->reason ?? ''),
            'created_at' => str_value($d->created_at ?? ''),
        ], $rows), $total, $page, $perPage);
    }

    /** GET /api/v1/disputes/{id} */
    public function showDispute(int $disputeId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        // findDetailWithSubmission با userId مالکیت را خودش چک می‌کند
        /** @var \stdClass|null $detail */
        $detail = $this->disputeService->findDetailWithSubmission($disputeId, $userId);
        if (!$detail) {
            $this->error('پرونده یافت نشد یا متعلق به شما نیست.', 404, 'DISPUTE_NOT_FOUND');
            return;
        }
        /** @var list<\stdClass> $messages */
        $messages = $this->disputeService->getMessages($disputeId);
        $this->success([
            'dispute' => [
                'id'       => (int)$detail->id,
                'ref_type' => str_value($detail->ref_type ?? ''),
                'ref_id'   => (int)($detail->ref_id ?? 0),
                'status'   => str_value($detail->status ?? ''),
                'reason'   => str_value($detail->reason ?? ''),
            ],
            'messages' => array_map(static fn(\stdClass $m): array => [
                'id'         => (int)$m->id,
                'sender_id'  => (int)($m->sender_id ?? 0),
                'role'       => str_value($m->role ?? ''),
                'message'    => str_value($m->message ?? ''),
                'created_at' => str_value($m->created_at ?? ''),
            ], $messages),
        ]);
    }

    /** POST /api/v1/disputes/{id}/reply */
    public function replyDispute(int $disputeId): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $body = $this->jsonBody();
        $text = trim(str_value($body['message'] ?? ''));
        if ($text === '' || mb_strlen($text) > 4000) {
            $this->validationError(['message' => ['متن پیام الزامی و حداکثر ۴۰۰۰ کاراکتر است.']]);
            return;
        }

        // مالکیت قبل از ارسال: کاربر باید طرفِ همین پرونده باشد
        /** @var \stdClass|null $detail */
        $detail = $this->disputeService->findDetailWithSubmission($disputeId, $userId);
        if (!$detail) {
            $this->error('پرونده یافت نشد یا متعلق به شما نیست.', 404, 'DISPUTE_NOT_FOUND');
            return;
        }

        $result = $this->disputeService->addMessageWithContext($disputeId, $userId, $text);
        if (!empty($result['success'])) {
            $this->success(is_array($result['data'] ?? null) ? $result['data'] : [], str_value($result['message'] ?? 'پیام ثبت شد.'));
        } else {
            $this->error(str_value($result['message'] ?? 'ثبت پیام ممکن نشد.'), 422, str_value($result['error_code'] ?? '') ?: null);
        }
    }

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $raw = $this->request->body();
        return is_array($raw) ? $raw : [];
    }
}
