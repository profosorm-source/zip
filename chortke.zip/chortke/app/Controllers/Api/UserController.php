<?php

namespace App\Controllers\Api;

use App\Models\Notification;

/**
 * API\UserController - پروفایل و اطلاعات کاربر
 *
 * GET  /api/v1/user/profile          → اطلاعات پروفایل
 * GET  /api/v1/user/notifications    → اعلان‌ها
 * POST /api/v1/user/notifications/read → خواندن اعلان
 */
class UserController extends BaseApiController
{
    private Notification $notifModel;
    private \App\Services\TicketService $ticketService;
    private \App\Services\Auth\TwoFactorService $twoFactorService;
    private \App\Services\Auth\SessionService $sessionService;
    // 🧹 DI-CLEANUP (2026-08-24): وابستگی‌هایی که قبلاً با container->make در بدنه‌ی
    // متدها گرفته می‌شدند، اکنون با تزریق سازنده (autowire توسط Router) تأمین می‌شوند.
    private \App\Models\Ticket $ticketModel;
    private \App\Models\TicketMessage $messageModel;
    private \App\Services\Auth\PasswordRecoveryService $pwService;
    private \App\Models\User $userModel;
    private \App\Services\User\UserSettingsService $settingsService;
    private \App\Services\User\AccountDeletionService $deletionService;
    private \App\Services\KYCService $kycService;
    private \App\Services\DirectMessageService $dmService;
    private ?\App\Policies\RateLimitPolicy $rateLimitPolicy;

    public function __construct(
        \App\Models\Notification $notifModel,
        \App\Services\TicketService $ticketService,
        \App\Services\Auth\TwoFactorService $twoFactorService,
        \App\Services\Auth\SessionService $sessionService,
        \App\Models\Ticket $ticketModel,
        \App\Models\TicketMessage $messageModel,
        \App\Services\Auth\PasswordRecoveryService $pwService,
        \App\Models\User $userModel,
        \App\Services\User\UserSettingsService $settingsService,
        \App\Services\User\AccountDeletionService $deletionService,
        \App\Services\KYCService $kycService,
        \App\Services\DirectMessageService $dmService,
        ?\App\Policies\RateLimitPolicy $rateLimitPolicy = null,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->notifModel = $notifModel;
        $this->ticketService = $ticketService;
        $this->twoFactorService = $twoFactorService;
        $this->sessionService = $sessionService;
        $this->ticketModel = $ticketModel;
        $this->messageModel = $messageModel;
        $this->pwService = $pwService;
        $this->userModel = $userModel;
        $this->settingsService = $settingsService;
        $this->deletionService = $deletionService;
        $this->kycService = $kycService;
        $this->dmService = $dmService;
        // 🛡️ FIX-M10-M3 (گزارش جامع M10): سیاستِ rate-limitِ مشترک برای مسیر API —
        // قبلاً فقط مسیرِ وب سهمیهٔ user+IP+device داشت و API مسیرِ abuseِ آزاد بود.
        $this->rateLimitPolicy = $rateLimitPolicy ?? app(\App\Policies\RateLimitPolicy::class);
    }

    /** پروفایل کاربر */
    public function profile(): void
    {
        $user = $this->currentUser();

        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }

        $avatar = $user->avatar ?? null;
        $avatarThumb = $avatar ? (str_contains($avatar, 'http') ? $avatar : url('uploads/avatars/thumb_' . basename($avatar))) : null;
        $avatarFull = $avatar ? (str_contains($avatar, 'http') ? $avatar : url('uploads/avatars/' . basename($avatar))) : null;

        // اصلاح کلیدی معماری موبایل (Mobile Texture OOM & Image Optimization Guard):
        // ارسال هم‌زمان نسخه بهینه‌شده (Thumbnail) و اصلی آواتار جهت جلوگیری از کرش مموری کارت گرافیک در گوشی‌های موبایل (Flutter/React Native)
        $this->success([
            'id'            => $user->id,
            'full_name'     => $user->full_name,
            'email'         => $user->email,
            'mobile'        => $user->mobile,
            'referral_code' => $user->referral_code,
            'kyc_status'    => $user->kyc_status ?? 'none',
            'level_slug'    => $user->level_slug ?? 'silver',
            'is_verified'   => (bool)($user->email_verified_at ?? false),
            'avatar'        => $avatarFull,
            'avatar_thumb'  => $avatarThumb,
            'created_at'    => $user->created_at,
        ]);
    }

    /** لیست اعلان‌ها */
    public function notifications(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);

        $onlyUnread = (bool)($this->request->get('unread') ?? false);

        $items = $this->notifModel->getUserNotifications($userId, $onlyUnread, $perPage, $offset);
        $total = $this->notifModel->countUserNotifications($userId, $onlyUnread);

        $items = array_map(fn($n) => [
            'id'         => $n->id,
            'title'      => $n->title,
            'message'    => $n->message,
            'type'       => $n->type,
            'is_read'    => (bool)$n->is_read,
            'created_at' => $n->created_at,
        ], $items);

        $this->paginated($items, $total, $page, $perPage);
    }

    /** خواندن اعلان */
    public function markRead(): void
    {
        $userId = (int)$this->userId();
        $id     = $this->request->int('id');

        if (!$id) {
            // خواندن همه
            $this->notifModel->markAllAsRead($userId);
            $this->success(null, 'همه اعلان‌ها خوانده شدند');
        }

        $this->notifModel->markAsRead($id, $userId);
        $this->success(null, 'اعلان خوانده شد');
    }

    /** لیست تیکت‌ها */
    public function ticketsList(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage] = $this->paginationParams(20);
        $status = $this->request->str('status') !== '' ? $this->request->str('status') : null;
        $result = $this->ticketService->listUserTickets($userId, $status, $page, $perPage);
        $this->paginated($result['tickets'] ?? [], $result['total'] ?? 0, $page, $perPage);
    }

    /** ایجاد تیکت جدید */
    public function ticketsStore(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        try {
            $result = $this->ticketService->create($userId, $data);
            if (!empty($result['success'])) {
                $this->success($result, 'تیکت با موفقیت ایجاد شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ایجاد تیکت'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (Task 18-N — P2 #21): پیام خطای دامنه (قوانین بیزینسی) کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.tickets_store.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** نمایش جزئیات تیکت */
    public function ticketsShow(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $ticketModel = $this->ticketModel;
        $messageModel = $this->messageModel;
        $ticket = $ticketModel->findForUser($id, $userId);
        if (!$ticket) {
            $this->error('تیکت یافت نشد', 404, 'TICKET_NOT_FOUND');
        }
        $messages = $messageModel->getByTicketId($id);
        $this->success(['ticket' => $ticket, 'messages' => $messages]);
    }

    /** ارسال پاسخ به تیکت */
    public function ticketsReply(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $data = (array)$this->request->body();
        $message = trim(str_value($data['message'] ?? ''));
        $attachments = is_array($data['attachments'] ?? null) ? $data['attachments'] : [];
        try {
            $result = $this->ticketService->reply($id, $userId, $message, false, $attachments);
            if (!empty($result['success'])) {
                $this->success($result, 'پاسخ با موفقیت ارسال شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ارسال پاسخ'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.tickets_reply.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** بستن تیکت */
    public function ticketsClose(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        try {
            $result = $this->ticketService->close($id, $userId, false);
            if (!empty($result['success'])) {
                $this->success(null, 'تیکت بسته شد');
            }
            $this->error(str_value($result['message'] ?? 'خطا در بستن تیکت'), 400);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.tickets_close.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** دسته‌بندی‌های تیکت */
    public function ticketsCategories(): void
    {
        $categories = $this->ticketService->getCategories();
        $this->success($categories);
    }

    /** وضعیت 2FA */
    public function twoFactorStatus(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $isEnabled = ($user->two_factor_enabled ?? 0) == 1;
        // 🛡️ Security Fix (Issue #6): Never expose TOTP secret / QR code in read-only status
        $this->success([
            'is_enabled' => $isEnabled,
            'has_secret' => !empty($user->two_factor_secret),
        ]);
    }

    /**
     * L-23 Fix: تولید/بازگرداندن secret در یک مسیر نوشتن (POST, scope user.write).
     * نیاز به تایید رمز عبور فعلی جهت جلوگیری از سوءاستفاده از توکن‌های API دارد.
     */
    public function twoFactorSetup(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        if (($user->two_factor_enabled ?? 0) == 1) {
            $this->error('احراز هویت دو مرحله‌ای قبلاً فعال شده است', 422); return;
        }

        $data = (array)$this->request->body();
        $password = trim(str_value($data['password'] ?? $data['current_password'] ?? ''));
        if ($password === '') {
            $this->error('جهت راه‌اندازی ۲FA، وارد کردن رمز عبور فعلی الزامی است.', 422);
            return;
        }

        $pwService = $this->pwService;
        if (!$pwService->verifyPassword($password, $user->password ?? '', (int)$user->id)) {
            $this->error('رمز عبور فعلی نادرست است.', 422);
            return;
        }

        if (empty($user->two_factor_secret)) {
            $secret = $this->twoFactorService->generateSecret();
            $encryptedSecret = $this->twoFactorService->encryptSecret($secret);
            $userModel = $this->userModel;
            // FIX-18O (P0): explicit-column writer (two_factor_secret no longer fillable)
            $userModel->updateTwoFactorSettings((int)$user->id, ['two_factor_secret' => $encryptedSecret]);
            $user->two_factor_secret = $encryptedSecret;
        }
        $this->success([
            'qr_code_url' => $this->twoFactorService->getQRCodeUrl($user->username ?? $user->email, $user->two_factor_secret),
        ]);
    }

    /** فعال‌سازی 2FA */
    public function twoFactorEnable(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $userId = (int)$user->id;
        $data = (array)$this->request->body();
        $code = trim(str_value($data['code'] ?? ''));
        $password = trim(str_value($data['password'] ?? $data['current_password'] ?? ''));

        if ($password === '') {
            $this->error('جهت فعال‌سازی ۲FA، وارد کردن رمز عبور فعلی الزامی است.', 422);
            return;
        }

        $pwService = $this->pwService;
        if (!$pwService->verifyPassword($password, $user->password ?? '', $userId)) {
            $this->error('رمز عبور فعلی نادرست است.', 422);
            return;
        }

        $result = $this->twoFactorService->enable($userId, $code);
        if (!empty($result['success'])) {
            $this->success($result, 'احراز هویت دو مرحله‌ای فعال شد');
            return;
        }
        $this->error(str_value($result['message'] ?? 'خطا در فعال‌سازی'), 422);
    }

    /** غیرفعال‌سازی 2FA */
    public function twoFactorDisable(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        $password = str_value($data['password'] ?? '');
        $result = $this->twoFactorService->disable($userId, $password);
        if (!empty($result['success'])) {
            $this->success($result, 'احراز هویت دو مرحله‌ای غیرفعال شد');
        }
            $this->error(str_value($result['message'] ?? 'خطا در غیرفعال‌سازی'), 422);
    }

    /** لیست نشست‌های فعال */
    public function sessionsList(): void
    {
        $userId = (int)$this->userId();
        $sessions = $this->sessionService->getActiveSessions($userId);
        $this->success($sessions);
    }

    /** حذف نشست فعال */
    public function sessionsRevoke(): void
    {
        $userId = (int)$this->userId();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? 0);
        $result = $this->sessionService->terminateSession($id, $userId);
        if (!empty($result['success'])) {
            $this->success(null, 'نشست با موفقیت حذف شد');
        }
            $this->error(str_value($result['message'] ?? 'خطا در حذف نشست'), 400);
    }

    /** دریافت تنظیمات عمومی و حریم خصوصی */
    public function settingsGet(): void
    {
        $userId = (int)$this->userId();
        $settingsService = $this->settingsService;
        $general = $settingsService->getSettings($userId, 'general');
        $privacy = $settingsService->getSettings($userId, 'privacy');
        $this->success(['general' => $general, 'privacy' => $privacy]);
    }

    /** بروزرسانی تنظیمات عمومی */
    public function settingsGeneralUpdate(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        $settingsService = $this->settingsService;
        foreach ((array)$data as $key => $val) {
            $settingsService->set($userId, (string)$key, $val);
        }
        $this->success(null, 'تنظیمات عمومی بروزرسانی شد');
    }

    /** بروزرسانی تنظیمات حریم خصوصی */
    public function settingsPrivacyUpdate(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        $settingsService = $this->settingsService;
        foreach ((array)$data as $key => $val) {
            $settingsService->set($userId, (string)$key, $val);
        }
        $this->success(null, 'تنظیمات حریم خصوصی بروزرسانی شد');
    }

    /** درخواست حذف حساب کاربری */
    public function accountDeletionRequest(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();

        // FIX-R18N (Task 18-N — P1 REVIEW_ROUND18 #19): تأیید مجدد رمز عبور —
        // قبلاً Bearer دزدیده‌شده بدون هیچ re-authentication حساب را تا حذف کامل
        // می‌برد. همان verify مسیر وب (UserSettingsService::requestAccountDeletion
        // → verify_user_password) اعمال می‌شود؛ خطای شکل API-سازگار.
        $password = str_value($data['password'] ?? '');
        if ($password === '') {
            $this->error('برای درخواست حذف حساب، وارد کردن رمز عبور فعلی الزامی است.', 422, 'PASSWORD_REQUIRED');
            return;
        }
        $user = $this->currentUser();
        if ($user === null) {
            $this->error('احراز هویت لازم است', 401, 'UNAUTHENTICATED');
            return;
        }
        if (!verify_user_password($password, $user->password ?? '', $userId)) {
            $this->error('رمز عبور فعلی نادرست است.', 403, 'PASSWORD_MISMATCH');
            return;
        }

        $reason = trim(str_value($data['reason'] ?? ''));
        $deletionService = $this->deletionService;
        $result = $deletionService->requestDeletion($userId, $reason);
        if (!empty($result['success'])) {
            $this->success($result, 'درخواست حذف اکانت ثبت شد و پس از ۳۰ روز انجام می‌شود');
        }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت درخواست حذف اکانت'), 422);
    }

    /** وضعیت احراز هویت (KYC) */
    public function kycStatus(): void
    {
        $userId = (int)$this->userId();
        $kycService = $this->kycService;
        $status = [
            'is_approved' => $kycService->isApproved($userId),
            'can_submit'  => $kycService->canSubmitKYC($userId),
        ];
        $this->success($status);
    }

    /** ارسال مدارک احراز هویت (KYC) */
    public function kycSubmit(): void
    {
        $userId = (int)$this->userId();
        // 🛡️ FIX-M10-M3: هم‌قرارداد با مسیرِ وب — سهمیهٔ user/IP/device پیش از هر
        // پردازشی سنجیده می‌شود (سهمیهٔ user در سرویسِ KYC هست؛ اینجا IP+device).
        if (!$this->rateLimitPolicy->check('kyc_submit', get_client_ip())) {
            $this->rateLimitPolicy->tooManyResponse('kyc_submit', get_client_ip(), true);
        }
        if (!$this->rateLimitPolicy->check('kyc_submit', (string)(generate_device_fingerprint() ?: 'api-no-fp'))) {
            $this->rateLimitPolicy->tooManyResponse('kyc_submit', 'device', true);
        }
        $data  = $this->request->body();
        $files = $_FILES;
        $kycService = $this->kycService;
        try {
            $result = $kycService->submitKYC($userId, $data, $files);
            if (!empty($result['success'])) {
                $this->success($result, 'مدارک احراز هویت با موفقیت ارسال شد و در انتظار بررسی است', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ارسال مدارک'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.kyc_submit.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** لیست پیام‌های خصوصی */
    public function directMessagesList(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);
        $dmService = $this->dmService;
        $result = $dmService->getUserConversations($userId, $perPage, $offset);
        $this->paginated(is_array($result['conversations'] ?? null) ? $result['conversations'] : [], int_value($result['total'] ?? 0), $page, $perPage);
    }

    /** ارسال پیام خصوصی */
    public function directMessageSend(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        $recipientId = int_value($data['recipient_id'] ?? 0);
        $content = trim(str_value($data['content'] ?? ''));
        $dmService = $this->dmService;
        try {
            $result = $dmService->sendMessage($userId, $recipientId, $content);
            if (!empty($result['success'])) {
                $this->success($result, 'پیام با موفقیت ارسال شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ارسال پیام'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.dm_send.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }

    /** ثبت گزارش باگ */
    public function bugReportStore(): void
    {
        $userId = (int)$this->userId();
        $data  = $this->request->body();

        // 🛡️ FIX-H18: فیلد screenshot از مسیر API بدون هیچ اعتبارسنجی به DB می‌رفت و
        // ویوی ادمین آن را در href/src چاپ می‌کرد → Stored XSS در پنل ادمین.
        // فقط مسیرِ امنِ تولیدشده توسط فلوی آپلود سرور پذیرفته می‌شود؛ مقدار
        // نامعتبر → 422. گزارشِ بدون اسکرین‌شات (کلیدِ غایب/خالی) همچنان پذیرفته است.
        if (is_array($data) && array_key_exists('screenshot', $data)) {
            $rawShot = $data['screenshot'];
            if (!is_scalar($rawShot) || trim(str_value($rawShot)) === '') {
                $data['screenshot'] = null;
            } else {
                $shot = \App\Services\TicketService::validateScreenshotPath(str_value($rawShot));
                if ($shot === null) {
                    $this->error('مسیر اسکرین‌شات نامعتبر است.', 422);
                    return;
                }
                $data['screenshot'] = $shot;
            }
        }

        try {
            $result = $this->ticketService->submitBugReport($userId, $data);
            if (!empty($result['success'])) {
                $this->success(['bug_id' => $result['id'] ?? null], str_value($result['message'] ?? 'گزارش باگ با موفقیت ثبت شد'), 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت گزارش'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\Throwable $e) {
            // FIX-R18N (#21): جزئیات استثنا فقط در لاگ — به کلاینت پیام عمومی
            $this->logger->error('api.bug_report_store.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 422);
        }
    }
}
