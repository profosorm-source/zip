<?php

namespace App\Controllers\Api;

use App\Models\Notification;

/**
 * API\UserController - پروفایل و اطلاعات کاربر
 *
 * GET  /api/v1/user/profile          → اطلاعات پروفایل
 * GET  /api/v1/user/notifications    → اعلان‌ها
 * POST /api/v1/user/notifications/read → خواندن اعلان
 */
class UserController extends BaseApiController
{
    private Notification $notifModel;
    private \App\Services\TicketService $ticketService;
    private \App\Services\Auth\TwoFactorService $twoFactorService;
    private \App\Services\Auth\SessionService $sessionService;
    // 🧹 DI-CLEANUP (2026-08-24): وابستگی‌هایی که قبلاً با container->make در بدنه‌ی
    // متدها گرفته می‌شدند، اکنون با تزریق سازنده (autowire توسط Router) تأمین می‌شوند.
    private \App\Models\Ticket $ticketModel;
    private \App\Models\TicketMessage $messageModel;
    private \App\Services\Auth\PasswordRecoveryService $pwService;
    private \App\Models\User $userModel;
    private \App\Services\User\UserSettingsService $settingsService;
    private \App\Services\User\AccountDeletionService $deletionService;
    private \App\Services\KYCService $kycService;
    private \App\Services\DirectMessageService $dmService;
    private ?\App\Policies\RateLimitPolicy $rateLimitPolicy;
    private ?\Core\RateLimiter $rateLimiter;

    public function __construct(
        \App\Models\Notification $notifModel,
        \App\Services\TicketService $ticketService,
        \App\Services\Auth\TwoFactorService $twoFactorService,
        \App\Services\Auth\SessionService $sessionService,
        \App\Models\Ticket $ticketModel,
        \App\Models\TicketMessage $messageModel,
        \App\Services\Auth\PasswordRecoveryService $pwService,
        \App\Models\User $userModel,
        \App\Services\User\UserSettingsService $settingsService,
        \App\Services\User\AccountDeletionService $deletionService,
        \App\Services\KYCService $kycService,
        \App\Services\DirectMessageService $dmService,
        ?\App\Policies\RateLimitPolicy $rateLimitPolicy = null,
        ?\Core\RateLimiter $rateLimiter = null,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->notifModel = $notifModel;
        $this->ticketService = $ticketService;
        $this->twoFactorService = $twoFactorService;
        $this->sessionService = $sessionService;
        $this->ticketModel = $ticketModel;
        $this->messageModel = $messageModel;
        $this->pwService = $pwService;
        $this->userModel = $userModel;
        $this->settingsService = $settingsService;
        $this->deletionService = $deletionService;
        $this->kycService = $kycService;
        $this->dmService = $dmService;
        // 🛡️ FIX-M10-M3 (گزارش جامع M10): سیاستِ rate-limitِ مشترک برای مسیر API —
        // قبلاً فقط مسیرِ وب سهمیهٔ user+IP+device داشت و API مسیرِ abuseِ آزاد بود.
        $this->rateLimitPolicy = $rateLimitPolicy ?? app(\App\Policies\RateLimitPolicy::class);
        $this->rateLimiter = $rateLimiter ?? app(\Core\RateLimiter::class);
    }

    /** پروفایل کاربر */
    public function profile(): void
    {
        $user = $this->currentUser();

        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }

        $avatar = $user->avatar ?? null;
        $avatarThumb = $avatar ? (str_contains($avatar, 'http') ? $avatar : url('uploads/avatars/thumb_' . basename($avatar))) : null;
        $avatarFull = $avatar ? (str_contains($avatar, 'http') ? $avatar : url('uploads/avatars/' . basename($avatar))) : null;

        // اصلاح کلیدی معماری موبایل (Mobile Texture OOM & Image Optimization Guard):
        // ارسال هم‌زمان نسخه بهینه‌شده (Thumbnail) و اصلی آواتار جهت جلوگیری از کرش مموری کارت گرافیک در گوشی‌های موبایل (Flutter/React Native)
        $this->success([
            'id'            => $user->id,
            'full_name'     => $user->full_name,
            'email'         => $user->email,
            'mobile'        => $user->mobile,
            'referral_code' => $user->referral_code,
            'kyc_status'    => $user->kyc_status ?? 'none',
            'level_slug'    => $user->level_slug ?? 'silver',
            'is_verified'   => (bool)($user->email_verified_at ?? false),
            'avatar'        => $avatarFull,
            'avatar_thumb'  => $avatarThumb,
            'created_at'    => $user->created_at,
        ]);
    }

    /** لیست اعلان‌ها */
    public function notifications(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);

        // FIX-M11-SF-005 (گزارش دوم ماژول ۱۱): پارس صریح bool — قبلاً (bool) cast
        // رشتهٔ «false» را true می‌کرد (هر رشتهٔ غیرخالی در PHP truthy است) و
        // ?unread=false قراردادی فقط unread برمی‌گرداند. مقادیر ناشناخته → 422.
        $unreadRaw = $this->request->get('unread');
        if ($unreadRaw === null || $unreadRaw === '') {
            $onlyUnread = false;
        } else {
            $unreadNorm = strtolower(trim((string)$unreadRaw));
            if (in_array($unreadNorm, ['true', '1', 'yes', 'on'], true)) {
                $onlyUnread = true;
            } elseif (in_array($unreadNorm, ['false', '0', 'no', 'off'], true)) {
                $onlyUnread = false;
            } else {
                $this->error('مقدار پارامتر unread نامعتبر است (مقادیر مجاز: true/false/1/0)', 422, 'INVALID_FILTER');
                return;
            }
        }

        $items = $this->notifModel->getUserNotifications($userId, $onlyUnread, $perPage, $offset);
        $total = $this->notifModel->countUserNotifications($userId, $onlyUnread);

        $items = array_map(fn($n) => [
            'id'         => $n->id,
            'title'      => $n->title,
            'message'    => $n->message,
            'type'       => $n->type,
            'is_read'    => (bool)$n->is_read,
            'created_at' => $n->created_at,
        ], $items);

        $this->paginated($items, $total, $page, $perPage);
    }

    /** خواندن اعلان */
    public function markRead(): void
    {
        $userId = (int)$this->userId();
        $id     = $this->request->int('id');

        if (!$id) {
            // خواندن همه
            $this->notifModel->markAllAsRead($userId);
            $this->success(null, 'همه اعلان‌ها خوانده شدند');
            return; // FIX-M11-R22-14: return صریح پس از success (الگوی شکنندهٔ بدون return)
        }

        $this->notifModel->markAsRead($id, $userId);
        $this->success(null, 'اعلان خوانده شد');
    }

    /** لیست تیکت‌ها */
    public function ticketsList(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage] = $this->paginationParams(20);
        $status = $this->request->str('status') !== '' ? $this->request->str('status') : null;
        $result = $this->ticketService->listUserTickets($userId, $status, $page, $perPage);
        $this->paginated($result['tickets'] ?? [], $result['total'] ?? 0, $page, $perPage);
    }

    /** ایجاد تیکت جدید */
    public function ticketsStore(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        try {
            $result = $this->ticketService->create($userId, $data);
            if (!empty($result['success'])) {
                $this->success($result, 'تیکت با موفقیت ایجاد شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ایجاد تیکت'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (Task 18-N — P2 #21): پیام خطای دامنه (قوانین بیزینسی) کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\PDOException | \Core\Exceptions\DatabaseException $e) {
            // FIX-M11-SF-004 (گزارش دوم): outage وابستگی → 503 (قابل retry)، نه 422
            $this->logger->error('api.tickets_store.dependency', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('سرویس در دسترس نیست؛ لطفاً بعداً تلاش کنید.', 503, 'DEPENDENCY_UNAVAILABLE');
        } catch (\Throwable $e) {
            // FIX-R18N (#21) + FIX-M11-SF-004: جزئیات استثنا فقط در لاگ؛
            // خطای زیرساخت ناشناخته → 500 (قبلاً 422 و کلاینت transient را validation
            // می‌پنداشت و retry/backoff/monitoring گمراه می‌شد)
            $this->logger->error('api.tickets_store.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 500, 'INTERNAL_ERROR');
        }
    }

    /**
     * نمایش جزئیات تیکت — FIX-M11-R22-14: DTO whitelist.
     *  - پیام‌های پشتیبانی (is_admin=1) دیگر ایمیلِ واقعیِ کارمند را نمی‌برند —
     *    برچسب نمایشی «پشتیبانی چرتکه»؛ پیام کاربر هم بدون ایمیل (owner خود کاربر است).
     *  - ردیف تیکت هم DTO ستون‌محور شد (SELECT خام دیگر به خروجی نمی‌رود).
     *  - return صریح پس از error().
     */
    public function ticketsShow(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $ticketModel = $this->ticketModel;
        $messageModel = $this->messageModel;
        $ticket = $ticketModel->findForUser($id, $userId);
        if (!$ticket) {
            $this->error('تیکت یافت نشد', 404, 'TICKET_NOT_FOUND');
            return; // FIX-M11-R22-14: return صریح (error() throw می‌کند ولی الگوی صریح مستحکم‌تر است)
        }
        $messages = $messageModel->getByTicketId($id);

        $ticketDto = [
            'id'         => (int)($ticket->id ?? 0),
            'subject'    => $ticket->subject ?? '',
            'status'     => $ticket->status ?? '',
            'priority'   => $ticket->priority ?? 'normal',
            'category'   => $ticket->category_id ?? ($ticket->category ?? null),
            'created_at' => $ticket->created_at ?? null,
            'updated_at' => $ticket->updated_at ?? null,
            'closed_at'  => $ticket->closed_at ?? null,
        ];

        $messageDtos = array_map(static fn($m) => [
            'id'          => (int)($m->id ?? 0),
            'message'     => $m->message ?? '',
            'is_admin'    => (bool)($m->is_admin ?? false),
            // FIX-M11-R22-14: نشتِ ایمیلِ کارمند پشتیبانی بسته شد —
            // sender_name فقط برچسب نمایشی است؛ email/full_name خام بیرون نمی‌رود.
            'sender_name' => !empty($m->is_admin) ? 'پشتیبانی چرتکه' : (string)($m->full_name ?? 'شما'),
            'attachments' => $m->attachments ?? null,
            'created_at'  => $m->created_at ?? null,
        ], is_array($messages) ? $messages : []);

        $this->success(['ticket' => $ticketDto, 'messages' => $messageDtos]);
    }

    /** ارسال پاسخ به تیکت */
    public function ticketsReply(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        $data = (array)$this->request->body();
        $message = trim(str_value($data['message'] ?? ''));
        $attachments = is_array($data['attachments'] ?? null) ? $data['attachments'] : [];
        try {
            $result = $this->ticketService->reply($id, $userId, $message, false, $attachments);
            if (!empty($result['success'])) {
                $this->success($result, 'پاسخ با موفقیت ارسال شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ارسال پاسخ'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\PDOException | \Core\Exceptions\DatabaseException $e) {
            // FIX-M11-SF-004: outage وابستگی → 503
            $this->logger->error('api.tickets_reply.dependency', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('سرویس در دسترس نیست؛ لطفاً بعداً تلاش کنید.', 503, 'DEPENDENCY_UNAVAILABLE');
        } catch (\Throwable $e) {
            // FIX-R18N (#21) + FIX-M11-SF-004: جزئیات فقط در لاگ؛ ناشناخته → 500
            $this->logger->error('api.tickets_reply.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 500, 'INTERNAL_ERROR');
        }
    }

    /** بستن تیکت */
    public function ticketsClose(): void
    {
        $userId = (int)$this->userId();
        $id = $this->request->int('id');
        try {
            $result = $this->ticketService->close($id, $userId, false);
            if (!empty($result['success'])) {
                $this->success(null, 'تیکت بسته شد');
            }
            $this->error(str_value($result['message'] ?? 'خطا در بستن تیکت'), 400);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\PDOException | \Core\Exceptions\DatabaseException $e) {
            // FIX-M11-SF-004: outage وابستگی → 503
            $this->logger->error('api.tickets_close.dependency', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('سرویس در دسترس نیست؛ لطفاً بعداً تلاش کنید.', 503, 'DEPENDENCY_UNAVAILABLE');
        } catch (\Throwable $e) {
            // FIX-R18N (#21) + FIX-M11-SF-004: جزئیات فقط در لاگ؛ ناشناخته → 500
            $this->logger->error('api.tickets_close.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 500, 'INTERNAL_ERROR');
        }
    }

    /** دسته‌بندی‌های تیکت */
    public function ticketsCategories(): void
    {
        $categories = $this->ticketService->getCategories();
        $this->success($categories);
    }

    /** وضعیت 2FA */
    public function twoFactorStatus(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $isEnabled = ($user->two_factor_enabled ?? 0) == 1;
        // 🛡️ Security Fix (Issue #6): Never expose TOTP secret / QR code in read-only status
        $this->success([
            'is_enabled' => $isEnabled,
            'has_secret' => !empty($user->two_factor_secret),
        ]);
    }

    /**
     * L-23 Fix: تولید/بازگرداندن secret در یک مسیر نوشتن (POST, scope user.write).
     * نیاز به تایید رمز عبور فعلی جهت جلوگیری از سوءاستفاده از توکن‌های API دارد.
     */
    public function twoFactorSetup(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        if (($user->two_factor_enabled ?? 0) == 1) {
            $this->error('احراز هویت دو مرحله‌ای قبلاً فعال شده است', 422); return;
        }
        // FIX-M11-R22-4: limiterِ re-auth مشترک — ۵ تلاش در ۱۵ دقیقه، fail-closed
        // (قبلاً فقط سقف عمومی 200/min بود ⇒ اوراکل brute-force رمز).
        if (!$this->reAuthLimiter((int)$user->id)) { return; }

        $data = (array)$this->request->body();
        // FIX-M11-R22-4: بدون trim — هم‌قرارداد با disable/deletion (رمزی که فاصلهٔ
        // ابتدا/انتها دارد در همهٔ مسیرها یکسان رد/قبول می‌شود؛ ناسازگاری داخلی رفع شد).
        $password = str_value($data['password'] ?? $data['current_password'] ?? '');
        if ($password === '') {
            $this->error('جهت راه‌اندازی ۲FA، وارد کردن رمز عبور فعلی الزامی است.', 422);
            return;
        }

        $pwService = $this->pwService;
        // FIX-R60-D1 (P1): آبجکتِ currentUser در API حداقلی است (FIX-M11-R22-9 عمداً
        // هش رمز را روی Request نمی‌گذارد) ⇒ $user->password همیشه NULL و verifyPassword
        // با رمزِ صحیح هم fail می‌شد — 2FA setup/enable و حذف حساب در API مرده بودند.
        // الگوی درون‌مخزنی (همان TwoFactorService::disable): خواندنِ اختصاصیِ ردیف کامل.
        $fullUser = $this->userModel->find((int)$user->id);
        if (!$pwService->verifyPassword($password, (string)($fullUser->password ?? ''), (int)$user->id)) {
            $this->error('رمز عبور فعلی نادرست است.', 422);
            return;
        }

        if (empty($user->two_factor_secret)) {
            $secret = $this->twoFactorService->generateSecret();
            $encryptedSecret = $this->twoFactorService->encryptSecret($secret);
            $userModel = $this->userModel;
            // FIX-18O (P0): explicit-column writer (two_factor_secret no longer fillable)
            $userModel->updateTwoFactorSettings((int)$user->id, ['two_factor_secret' => $encryptedSecret]);
            // FIX-R60-D2: QR همیشه از پاکت رمزنگاری‌شده ساخته می‌شود (نه plaintext)
            $secretForQr = $encryptedSecret;
        } else {
            // FIX-M11-R22-9: secret دیگر در SELECT حداقلی نیست — خواندنِ اختصاصیِ ستون‌محور
            $secretForQr = $this->userModel->getTwoFactorSecret((int)$user->id);
        }
        $this->success([
            // FIX-R60-D2 (P2): getQRCodeUrl قراردادش پاکت رمزنگاری‌شده است (درونش
            // decryptSecret می‌خواند) — شاخهٔ «سِکرِت تازه» مقدار plaintext می‌داد و با
            // سیاست ENCRYPTION_ALLOW_V1_READ=false همیشه RuntimeException/500 می‌ساخت
            // (setup ۲FA در API بار اول همیشه مرده بود). الگوی درست = همان مسیر وب
            // (TwoFactorController::L396): عبور پاکت رمزنگاری‌شده.
            'qr_code_url' => $this->twoFactorService->getQRCodeUrl($user->username ?? $user->email, (string)$secretForQr),
        ]);
    }

    /** فعال‌سازی 2FA */
    public function twoFactorEnable(): void
    {
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        $userId = (int)$user->id;
        // FIX-M11-R22-4: limiterِ re-auth مشترک
        if (!$this->reAuthLimiter($userId)) { return; }

        $data = (array)$this->request->body();
        $code = str_value($data['code'] ?? '');
        // FIX-M11-R22-4: بدون trim — هم‌قرارداد با سایر مسیرهای re-auth
        $password = str_value($data['password'] ?? $data['current_password'] ?? '');

        if ($password === '') {
            $this->error('جهت فعال‌سازی ۲FA، وارد کردن رمز عبور فعلی الزامی است.', 422);
            return;
        }

        $pwService = $this->pwService;
        // FIX-R60-D1: همان ریشهٔ setup — هش از آبجکت حداقلی نمی‌آید؛ خواندنِ اختصاصی
        $fullUser = $this->userModel->find($userId);
        if (!$pwService->verifyPassword($password, (string)($fullUser->password ?? ''), $userId)) {
            $this->error('رمز عبور فعلی نادرست است.', 422);
            return;
        }

        $result = $this->twoFactorService->enable($userId, $code);
        if (!empty($result['success'])) {
            $this->success($result, 'احراز هویت دو مرحله‌ای فعال شد');
            return;
        }
        $this->error(str_value($result['message'] ?? 'خطا در فعال‌سازی'), 422);
    }

    /**
     * غیرفعال‌سازی 2FA — FIX-M11-R22-4: پرمخاطب‌ترین عملیاتِ امنیتی، قبلاً فقط رمز
     * می‌خواست و هیچ limiter اختصاصی نداشت (زنجیرهٔ گزارش: توکن write لو رفته +
     * ~12k حدس/ساعت ⇒ خاموش‌کردن 2FA ⇒ برداشت). اکنون:
     *  ۱) limiter re-auth مشترک (۵/۱۵دقیقه، fail-closed)
     *  ۲) علاوه بر رمز، کد OTP معتبر الزامی است (همان قرارداد فعال‌سازی)
     *  ۳) غیرفعال‌سازی موفق خودش توکن‌های API را باطل می‌کند (FIX-M11-R22-3)
     */
    public function twoFactorDisable(): void
    {
        $userId = (int)$this->userId();
        $user = $this->currentUser();
        if ($user === null) { $this->error('احراز هویت لازم است', 401); return; }
        if (!$this->reAuthLimiter($userId)) { return; }

        $data = (array)$this->request->body();
        $password = str_value($data['password'] ?? '');
        $code = str_value($data['code'] ?? $data['otp'] ?? '');

        $secret = $this->userModel->getTwoFactorSecret($userId);
        if ($secret !== null && $secret !== '') {
            if ($code === '') {
                $this->error('برای غیرفعال‌سازی ۲FA، کد اپلیکیشن احراز هویت الزامی است.', 422, 'REQUIRES_2FA_CODE');
                return;
            }
            if (!$this->twoFactorService->verifyTOTPCode($secret, $code, $userId)) {
                $this->error('کد احراز هویت دو مرحله‌ای نامعتبر است.', 403, 'INVALID_2FA');
                return;
            }
        }

        $result = $this->twoFactorService->disable($userId, $password);
        if (!empty($result['success'])) {
            $this->success($result, 'احراز هویت دو مرحله‌ای غیرفعال شد و توکن‌های API باطل شدند');
            return; // FIX-M11-R22-4: return صریح
        }
        $this->error(str_value($result['message'] ?? 'خطا در غیرفعال‌سازی'), 422);
    }

    /**
     * FIX-M11-R22-4: limiterِ مشترکِ re-auth برای عملیات‌های حساسِ API —
     * ۵ تلاش در ۱۵ دقیقه به‌ازای هر کاربر، fail-closed (کلید مشترک با
     * «شمارندهٔ قفل حساب» همان الگوی login؛ backend سالم ⇒ همان سیاست).
     */
    private function reAuthLimiter(int $userId): bool
    {
        $key = 'api_reauth:' . $userId;
        if (!$this->rateLimiter->attempt($key, 5, 15)) {
            $this->error('تعداد تلاش‌های بیش از حد مجاز است؛ لطفاً ۱۵ دقیقه بعد تلاش کنید.', 429, 'REAUTH_LIMITED');
            return false;
        }
        return true;
    }

    /** لیست نشست‌های فعال — FIX-M11-R22-1: فقط DTO whitelist (بدون session_id/فینگرپرینت/مختصات؛ IP ماسک) */
    public function sessionsList(): void
    {
        $userId = (int)$this->userId();
        $sessions = $this->sessionService->getSessionDTOs($userId, 'api');
        $this->success($sessions);
    }

    /** حذف نشست فعال */
    public function sessionsRevoke(): void
    {
        $userId = (int)$this->userId();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? 0);
        $result = $this->sessionService->terminateSession($id, $userId);
        if (!empty($result['success'])) {
            $this->success(null, 'نشست با موفقیت حذف شد');
            return; // FIX-M11-R22-14: return صریح
        }
        $this->error(str_value($result['message'] ?? 'خطا در حذف نشست'), 400);
    }

    /** دریافت تنظیمات عمومی و حریم خصوصی */
    public function settingsGet(): void
    {
        $userId = (int)$this->userId();
        $settingsService = $this->settingsService;
        $general = $settingsService->getSettings($userId, 'general');
        $privacy = $settingsService->getSettings($userId, 'privacy');
        $this->success(['general' => $general, 'privacy' => $privacy]);
    }

    /** بروزرسانی تنظیمات عمومی */
    public function settingsGeneralUpdate(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        // FIX-M11-SF-001 (گزارش دوم): پاسخِ موفق فقط پس از persistence واقعی —
        // قرارداد writeBatch: کلید/نوع نامعتبر → 422؛ سهمیهٔ نوشتن → 429؛
        // خطای DB → 503 (اتمیک: هیچ تغییر جزئیِ گزارش‌نشده‌ای نمی‌ماند).
        $this->persistSettingsBatch($userId, $data, 'تنظیمات عمومی');
    }

    /** بروزرسانی تنظیمات حریم خصوصی */
    public function settingsPrivacyUpdate(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        // FIX-M11-SF-001: همان قرارداد حقیقت‌گوی settingsGeneralUpdate
        $this->persistSettingsBatch($userId, $data, 'تنظیمات حریم خصوصی');
    }

    /**
     * FIX-M11-SF-001: مسیر مشترکِ نگارش تنظیمات با قرارداد خطای درست HTTP.
     * قبلاً نتیجهٔ set() دور ریخته می‌شد و حتی شکست کامل، پاسخ success می‌گرفت؛
     * کلاینت/اپ موبایل وضعیت قدیمی را «جدید» cache می‌کرد.
     */
    private function persistSettingsBatch(int $userId, array $data, string $label): void
    {
        $result = $this->settingsService->writeBatch($userId, $data);
        if (($result['success'] ?? false) === true) {
            $this->success(null, $label . ' بروزرسانی شد');
            return;
        }

        match (str_value($result['reason'] ?? 'db')) {
            'empty', 'invalid' => $this->error(
                'تنظیمات نامعتبر: ' . implode(', ', (array)($result['invalid_keys'] ?? [])),
                422,
                'INVALID_SETTINGS'
            ),
            'quota' => $this->error('تعداد تغییرات تنظیمات بیش از حد مجاز است؛ کمی بعد تلاش کنید.', 429, 'RATE_LIMITED'),
            default => $this->error('ذخیرهٔ تنظیمات با خطا مواجه شد؛ تغییری اعمال نشد.', 503, 'SETTINGS_PERSIST_FAILED'),
        };
    }

    /** درخواست حذف حساب کاربری — FIX-M11-R22-4: limiterِ re-auth مشترک + return صریح */
    public function accountDeletionRequest(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();

        // FIX-R18N (Task 18-N — P1 REVIEW_ROUND18 #19): تأیید مجدد رمز عبور —
        // قبلاً Bearer دزدیده‌شده بدون هیچ re-authentication حساب را تا حذف کامل
        // می‌برد. همان verify مسیر وب (UserSettingsService::requestAccountDeletion
        // → verify_user_password) اعمال می‌شود؛ خطای شکل API-سازگار.
        // FIX-M11-R22-4: پوشش با limiterِ re-auth مشترک (۵/۱۵دقیقه، fail-closed).
        if (!$this->reAuthLimiter($userId)) { return; }

        $password = str_value($data['password'] ?? '');
        if ($password === '') {
            $this->error('برای درخواست حذف حساب، وارد کردن رمز عبور فعلی الزامی است.', 422, 'PASSWORD_REQUIRED');
            return;
        }
        $user = $this->currentUser();
        if ($user === null) {
            $this->error('احراز هویت لازم است', 401, 'UNAUTHENTICATED');
            return;
        }
        // FIX-R60-D1: همان ریشهٔ setup — verify_user_password با هشِ خالیِ آبجکت
        // حداقلی همیشه PASSWORD_MISMATCH می‌داد؛ خواندنِ اختصاصیِ ردیف کامل
        $fullUser = $this->userModel->find($userId);
        if (!verify_user_password($password, (string)($fullUser->password ?? ''), $userId)) {
            $this->error('رمز عبور فعلی نادرست است.', 403, 'PASSWORD_MISMATCH');
            return;
        }

        $reason = trim(str_value($data['reason'] ?? ''));
        $deletionService = $this->deletionService;
        $result = $deletionService->requestDeletion($userId, $reason);
        if (!empty($result['success'])) {
            $this->success($result, 'درخواست حذف اکانت ثبت شد و پس از ۳۰ روز انجام می‌شود');
        }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت درخواست حذف اکانت'), 422);
    }

    /** وضعیت احراز هویت (KYC) */
    public function kycStatus(): void
    {
        $userId = (int)$this->userId();
        $kycService = $this->kycService;
        $status = [
            'is_approved' => $kycService->isApproved($userId),
            'can_submit'  => $kycService->canSubmitKYC($userId),
        ];
        $this->success($status);
    }

    /** ارسال مدارک احراز هویت (KYC) */
    public function kycSubmit(): void
    {
        $userId = (int)$this->userId();
        // 🛡️ FIX-M10-M3: هم‌قرارداد با مسیرِ وب — سهمیهٔ user/IP/device پیش از هر
        // پردازشی سنجیده می‌شود (سهمیهٔ user در سرویسِ KYC هست؛ اینجا IP+device).
        if (!$this->rateLimitPolicy->check('kyc_submit', get_client_ip())) {
            $this->rateLimitPolicy->tooManyResponse('kyc_submit', get_client_ip(), true);
        }
        if (!$this->rateLimitPolicy->check('kyc_submit', (string)(generate_device_fingerprint() ?: 'api-no-fp'))) {
            $this->rateLimitPolicy->tooManyResponse('kyc_submit', 'device', true);
        }
        $data  = $this->request->body();
        $files = $_FILES;
        $kycService = $this->kycService;
        try {
            $result = $kycService->submitKYC($userId, $data, $files);
            if (!empty($result['success'])) {
                $this->success($result, 'مدارک احراز هویت با موفقیت ارسال شد و در انتظار بررسی است', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ارسال مدارک'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\PDOException | \Core\Exceptions\DatabaseException $e) {
            // FIX-M11-SF-004: outage وابستگی → 503
            $this->logger->error('api.kyc_submit.dependency', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('سرویس در دسترس نیست؛ لطفاً بعداً تلاش کنید.', 503, 'DEPENDENCY_UNAVAILABLE');
        } catch (\Throwable $e) {
            // FIX-R18N (#21) + FIX-M11-SF-004: جزئیات فقط در لاگ؛ ناشناخته → 500
            $this->logger->error('api.kyc_submit.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 500, 'INTERNAL_ERROR');
        }
    }

    /** لیست پیام‌های خصوصی */
    public function directMessagesList(): void
    {
        $userId = (int)$this->userId();
        [$page, $perPage, $offset] = $this->paginationParams(20);
        $dmService = $this->dmService;
        $result = $dmService->getUserConversations($userId, $perPage, $offset);
        $this->paginated(is_array($result['conversations'] ?? null) ? $result['conversations'] : [], int_value($result['total'] ?? 0), $page, $perPage);
    }

    /** ارسال پیام خصوصی */
    public function directMessageSend(): void
    {
        $userId = (int)$this->userId();
        $data = (array)$this->request->body();
        $recipientId = int_value($data['recipient_id'] ?? 0);
        $content = trim(str_value($data['content'] ?? ''));
        $dmService = $this->dmService;
        try {
            $result = $dmService->sendMessage($userId, $recipientId, $content);
            if (!empty($result['success'])) {
                $this->success($result, 'پیام با موفقیت ارسال شد', 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ارسال پیام'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\PDOException | \Core\Exceptions\DatabaseException $e) {
            // FIX-M11-SF-004: outage وابستگی → 503
            $this->logger->error('api.dm_send.dependency', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('سرویس در دسترس نیست؛ لطفاً بعداً تلاش کنید.', 503, 'DEPENDENCY_UNAVAILABLE');
        } catch (\Throwable $e) {
            // FIX-R18N (#21) + FIX-M11-SF-004: جزئیات فقط در لاگ؛ ناشناخته → 500
            $this->logger->error('api.dm_send.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 500, 'INTERNAL_ERROR');
        }
    }

    /** ثبت گزارش باگ */
    public function bugReportStore(): void
    {
        $userId = (int)$this->userId();
        $data  = $this->request->body();

        // 🛡️ FIX-H18: فیلد screenshot از مسیر API بدون هیچ اعتبارسنجی به DB می‌رفت و
        // ویوی ادمین آن را در href/src چاپ می‌کرد → Stored XSS در پنل ادمین.
        // فقط مسیرِ امنِ تولیدشده توسط فلوی آپلود سرور پذیرفته می‌شود؛ مقدار
        // نامعتبر → 422. گزارشِ بدون اسکرین‌شات (کلیدِ غایب/خالی) همچنان پذیرفته است.
        if (is_array($data) && array_key_exists('screenshot', $data)) {
            $rawShot = $data['screenshot'];
            if (!is_scalar($rawShot) || trim(str_value($rawShot)) === '') {
                $data['screenshot'] = null;
            } else {
                $shot = \App\Services\TicketService::validateScreenshotPath(str_value($rawShot));
                if ($shot === null) {
                    $this->error('مسیر اسکرین‌شات نامعتبر است.', 422);
                    return;
                }
                $data['screenshot'] = $shot;
            }
        }

        try {
            $result = $this->ticketService->submitBugReport($userId, $data);
            if (!empty($result['success'])) {
                $this->success(['bug_id' => $result['id'] ?? null], str_value($result['message'] ?? 'گزارش باگ با موفقیت ثبت شد'), 201);
            }
            $this->error(str_value($result['message'] ?? 'خطا در ثبت گزارش'), 422);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Core\Exceptions\BusinessException $e) {
            // FIX-R18N (#21): پیام خطای دامنه کاربر-رو می‌ماند
            $this->error($e->getMessage(), 422);
        } catch (\PDOException | \Core\Exceptions\DatabaseException $e) {
            // FIX-M11-SF-004: outage وابستگی → 503
            $this->logger->error('api.bug_report_store.dependency', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('سرویس در دسترس نیست؛ لطفاً بعداً تلاش کنید.', 503, 'DEPENDENCY_UNAVAILABLE');
        } catch (\Throwable $e) {
            // FIX-R18N (#21) + FIX-M11-SF-004: جزئیات فقط در لاگ؛ ناشناخته → 500
            $this->logger->error('api.bug_report_store.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            $this->error('خطای غیرمنتظره در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.', 500, 'INTERNAL_ERROR');
        }
    }
}
