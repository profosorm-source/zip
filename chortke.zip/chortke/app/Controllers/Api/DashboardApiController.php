<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Contracts\LoggerInterface;
use App\Services\User\UserDashboardService;
use App\Services\User\UserLevelService;
use Core\Request;
use Core\Response;
use Core\Session;

/**
 * 📱 FIX-MOBILE-06 (کانال‌های درآمدی فقط-وب — ۲۰۲۶-۱۱-۰۳)
 *
 * مسیرهای API موبایل داشبورد و سطح کاربر — همان سرویس‌های وب
 * (UserDashboardService/UserLevelService) به‌عنوان منبع واحد حقیقت.
 *
 * مسیرها (گروه dashboard با اسکوپ user.read — اسکوپ جدیدی لازم نیست؛
 * داشبورد خلاصهٔ حسابِ کاربر است، نه یک دامنهٔ مستقل):
 *   GET /api/v1/dashboard/summary          خلاصهٔ کامل داشبورد
 *   GET /api/v1/dashboard/recent-executions اجراهای اخیر تسک‌ها
 *   GET /api/v1/level/progress             وضعیت سطح + پاداش‌ها
 */
final class DashboardApiController extends BaseApiController
{
    private UserDashboardService $dashboardService;
    private UserLevelService $levelService;

    public function __construct(
        UserDashboardService $dashboardService,
        UserLevelService $levelService,
        ?Session $session = null,
        ?Request $request = null,
        ?Response $response = null,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->dashboardService = $dashboardService;
        $this->levelService = $levelService;
    }

    /** GET /api/v1/dashboard/summary */
    public function summary(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        $stats = $this->dashboardService->getStats($userId);
        $openTickets = $this->dashboardService->getOpenTicketCount($userId);
        $this->success([
            'stats' => $stats,
            'open_tickets' => $openTickets,
        ]);
    }

    /** GET /api/v1/dashboard/recent-executions */
    public function recentExecutions(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        [$page, $perPage] = $this->paginationParams(5);
        $rows = $this->dashboardService->getRecentTaskExecutions($userId, $perPage, ($page - 1) * $perPage);
        $this->success(['recent_executions' => $rows]);
    }

    /** GET /api/v1/level/progress */
    public function level(): void
    {
        $userId = (int)$this->userId();
        if ($userId <= 0) {
            $this->error('احراز هویت لازم است.', 401, 'AUTH_REQUIRED');
            return;
        }
        if (!$this->levelService->isEnabled()) {
            $this->success([
                'enabled' => false,
                'progress' => null,
                'bonuses' => null,
            ], 'سطح‌بندی غیرفعال است.');
            return;
        }
        $this->success([
            'enabled'  => true,
            'progress' => $this->levelService->getProgress($userId),
            'bonuses'  => $this->levelService->getUserBonuses($userId),
        ]);
    }
}
