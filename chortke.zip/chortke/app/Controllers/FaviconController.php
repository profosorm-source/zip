<?php

namespace App\Controllers;

use App\Services\UploadService;

class FaviconController extends BaseController
{
    public function __construct(private UploadService $uploadService)
    {
        parent::__construct();
    }
    /**
     * نمایش favicon داینامیک SVG
     * اگر favicon در تنظیمات آپلود نشده باشد،
     * یک آیکون SVG با حرف اول اسم سایت نمایش می‌دهد
     */
    public function index(): void
    {
        // اگر favicon آپلود شده redirect کن
        $faviconPath = setting('site_favicon');
        if (is_string($faviconPath) && $faviconPath !== '') {
            $fullPath = $this->uploadService->getPath($faviconPath);
            if ($fullPath !== null && is_file($fullPath)) {
                $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
                $mime = match($ext) {
                    'ico'  => 'image/x-icon',
                    'svg'  => 'image/svg+xml',
                    'webp' => 'image/webp',
                    default => 'image/png',
                };
                header('Content-Type: ' . $mime);
                header('Cache-Control: public, max-age=86400');
                // 🛡️ FIX-S15-8: SVG سند اکتیو است (اسکریپت اجرا می‌کند)؛ سرو در ریشهٔ
                // origin با image/svg+xml بدون nosniff/CSP = XSS ذخیره‌شده از طریق
                // تنظیم ادمین (دفاع در عمق در برابر آلودگی تنظیمات). ICO/WebP نیازی
                // به CSP ندارند ولی nosniff برای همه بی‌ضرر است.
                header('X-Content-Type-Options: nosniff');
                if ($ext === 'svg') {
                    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; sandbox");
                }
                readfile($fullPath);
                exit;
            }
        }

        // Fallback: SVG داینامیک با حرف اول اسم سایت
        $rawSiteName = setting('site_name', 'چ');
        $siteName = is_string($rawSiteName) && $rawSiteName !== '' ? $rawSiteName : 'چ';
        $rawColor = setting('site_primary_color', '#1565c0');
        $color = is_string($rawColor) && preg_match('/^#[0-9a-fA-F]{6}$/', $rawColor) === 1
            ? $rawColor
            : '#1565c0';

        header('Content-Type: image/svg+xml');
        header('Cache-Control: public, max-age=3600');
        // 🛡️ FIX-S15-8: همان قرارداد SVG سرو‌شده از تنظیمات — دفاع در عمق.
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; sandbox");

        // FIX-S15-2: escape حرف اول پیش از ورود به markup (same-origin SVG = سند فعال)
        echo self::renderFallbackSvg($siteName, $color);
        exit;
    }

    /**
     * FIX-S15-2: تولید SVG جایگزین فاویکون با escape امنیتی.
     *
     * site_name مقداری ادمین‌محور است ولی اینجا آخرین خط دفاعی است: SVG سند
     * active (same-origin) است و markup خام (مثلاً <img onerror=…>) از مسیر
     * تنظیمات آلوده می‌تواند XSS ذخیره‌شده بسازد. فقط «حرف اول» رندر می‌شود و
     * پیش از ورود به markup با htmlspecialchars escape می‌گردد؛ رنگ خارج از
     * الگوی #RRGGBB به پیش‌فرض امن برمی‌گردد.
     */
    public static function renderFallbackSvg(string $siteName, string $color): string
    {
        $letter = mb_substr($siteName, 0, 1, 'UTF-8');
        $safeLetter = htmlspecialchars($letter, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $safeColor = preg_match('/^#[0-9a-fA-F]{6}$/', $color) === 1 ? $color : '#1565c0';

        return <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="32" height="32">
  <rect width="32" height="32" rx="6" fill="{$safeColor}"/>
  <text x="16" y="23" font-family="Vazirmatn, Tahoma, Arial" font-size="18"
        font-weight="bold" fill="white" text-anchor="middle">{$safeLetter}</text>
</svg>
SVG;
    }
}
