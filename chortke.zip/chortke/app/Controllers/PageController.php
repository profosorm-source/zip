<?php
namespace App\Controllers;

use App\Models\Page;
use App\Controllers\BaseController;
use Core\Response;
/**
 * Page Controller
 * 
 * مدیریت صفحات استاتیک
 */
class PageController extends BaseController
{
   
         
        private Page $pageModel;

    public function __construct(\App\Models\Page $pageModel, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->pageModel = $pageModel;
    }

        /**
     * نمایش صفحه
     */
    public function show(string $slug): mixed
    {
        // X40: slug نامعتبر یا یافت‌نشده باید HTTP 404 واقعی برگرداند نه 200 با قالب 404
        if (!preg_match('/^[a-z0-9\-]+$/i', $slug)) {
            return $this->response->status(404)->view('errors/404');
        }

        $page = $this->pageModel->findBySlug($slug);

        if (!$page) {
            return $this->response->status(404)->view('errors/404');
        }
        
        return view('pages/show', [
            'page' => $page
        ]);
    }

    /**
     * درباره ما
     *
     * 28-d: آمار «کاربر فعال» دیگر هاردکد نیست — شمارش واقعی از
     * DashboardStatsService::getGlobalStats() (کش ۱ ساعته، همان منبع
     * MetricsController/SeoController) به ویو پاس می‌شود؛ در خطای DB صفرِ
     * صادقانه (ویو خودش fallback نمایشی هاردکد قبلی را نگه می‌دارد).
     */
    public function about(): Response
    {
        $activeUsersCount = 0;
        try {
            $activeUsersCount = (int)(app(\App\Services\Shared\DashboardStatsService::class)->getGlobalStats()['users_count'] ?? 0);
        } catch (\Throwable $e) {
            $activeUsersCount = 0; // آمار در دسترس نیست — ویو fallback را نشان می‌دهد
        }

        return $this->response->view('pages.about', [
            'title' => 'درباره ما',
            'activeUsersCount' => $activeUsersCount,
        ]);
    }

    /**
     * تماس با ما
     */
    public function contact(): Response
    {
        return $this->response->view('pages.contact', [
            'title' => 'تماس با ما'
        ]);
    }

    /**
     * قوانین و مقررات
     */
    public function terms(): Response
    {
        return $this->response->view('pages.terms', [
            'title' => 'قوانین و مقررات'
        ]);
    }

    /**
     * حریم خصوصی
     */
    public function privacy(): Response
    {
        return $this->response->view('pages.privacy', [
            'title' => 'سیاست حفظ حریم خصوصی'
        ]);
    }

    /**
     * راهنما
     */
    public function help(): Response
    {
        return $this->response->view('pages.help', [
            'title' => 'راهنمای استفاده'
        ]);
    }
}