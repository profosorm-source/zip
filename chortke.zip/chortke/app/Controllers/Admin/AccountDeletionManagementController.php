<?php

namespace App\Controllers\Admin;

use Core\Response;

use App\Services\User\UserService;
use App\Models\AccountDeletionLog;
use App\Services\User\AccountDeletionService;
use Core\Logger;
use App\Controllers\Admin\BaseAdminController;

/**
 * Controller: AccountDeletionManagementController
 * صفحه مدیریت درخواست‌های حذف حساب از طرف Admin
 */
class AccountDeletionManagementController extends BaseAdminController
{
    private UserService $userService;
    private AccountDeletionLog $deletionLogModel;
    private AccountDeletionService $deletionService;
    // $logger inherited from parent

    public function __construct(
        UserService $userService,
        AccountDeletionLog $deletionLogModel,
        AccountDeletionService $deletionService,
        Logger $logger
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->userService = $userService;
        $this->deletionLogModel = $deletionLogModel;
        $this->deletionService = $deletionService;
        $this->logger = $logger;
    }

    /**
     * نمایش درخواست‌های حذف معلق
     */
    public function pending(): void
    {
        try {
            // FIX-CMD169: صفحه‌بندی clamp‌شده + شمارش دقیق برای total_count
            $limit = max(1, min(500, (int)($this->request->int('limit') ?: 200)));
            $page = max(1, (int)($this->request->int('page') ?: 1));
            $offset = ($page - 1) * $limit;

            // گرفتن درخواست‌های معلق (صفحه‌بندی‌شده)
            $pendingDeletions = $this->deletionLogModel->getPendingDeletions($limit, $offset);

            // تحریک تازه‌سازی صفحه
            // S7-FIX (UI-DEL-001): page/limit/total برای لینک‌های صفحه‌بندی به view داده می‌شود
            $data = [
                'pending_deletions' => $pendingDeletions,
                'total_count' => $this->deletionLogModel->countPendingDeletions(),
                'page' => $page,
                'limit' => $limit,
                'base_path' => '/admin/account-deletion/pending',
            ];

            view('admin/account-deletion/pending', $data);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            // FIX-18Q: view()/redirect() خودشان HttpResponseException می‌پرانند (send→throw) —
            // بدون این گارد، رندر موفق صفحه در catch عمومی بلعیده و فلش خطا + ریدایرکت دوم می‌گرفت.
            // الگوی صحیح همین فایل در getUserDetails/getStats.
            throw $e;
        } catch (\Throwable $e) { // FIX-P3-CMD-174: \Throwable تا TypeError/Error هم به مسیر فلشِ generic برود نه هندلر سراسری
            $this->logger->error('admin.account_deletion.pending.failed', [
                'exception_type' => get_class($e), 'error_detail' => $e->getMessage()
            ]);
            $this->session->setFlash('error', 'خطا: دریافت درخواست‌های معلق ناموفق بود');
            redirect('/admin/dashboard');
        }
    }

    /**
     * نمایش تاریخچه حذف‌شده‌ها
     */
    public function history(): void
    {
        try {
            // FIX-CMD169: صفحه‌بندی clamp‌شده (قبلاً کل تاریخچه یک‌جا فچ می‌شد)
            $limit = max(1, min(250, (int)($this->request->int('limit') ?: 100)));
            $page = max(1, (int)($this->request->int('page') ?: 1));
            $offset = ($page - 1) * $limit;

            // گرفتن تاریخچه حذف‌شده‌ها (صفحه‌بندی‌شده)
            $deletedAccounts = $this->deletionLogModel->getDeletedAccounts($limit, $offset);

            $data = [
                'deleted_accounts' => $deletedAccounts,
                // 🛡️ S7-FIX (UI-DEL-001): total_count = COUNT(*) مستقل — قبلاً count()
                // «همان صفحه» بود و اپراتور جمعیتِ بالای صفحهٔ اول را نمی‌دید.
                'total_count' => $this->deletionLogModel->countDeletedAccounts(),
                'page' => $page,
                'limit' => $limit,
                'base_path' => '/admin/account-deletion/history',
            ];

            view('admin/account-deletion/history', $data);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            // FIX-18Q: همان گارد pending — view() موفق HttpResponseException می‌پرانند.
            throw $e;
        } catch (\Throwable $e) { // FIX-P3-CMD-174: \Throwable (هم‌تراز pending)
            $this->logger->error('admin.account_deletion.history.failed', [
                'exception_type' => get_class($e), 'error_detail' => $e->getMessage()
            ]);
            $this->session->setFlash('error', 'خطا: دریافت تاریخچه ناموفق بود');
            redirect('/admin/dashboard');
        }
    }

    public function stats(): void
    {
        try {
            // 🛡️ S7-FIX (UI-DEL-002): شمارش‌های دقیق COUNT(*) — قبلاً count() نمونهٔ
            // سقف‌دارِ ۵۰۰ ردیفی گزارش می‌شد و آمار/حجم/expiring_soon ناقص بود.
            $pendingCount = $this->deletionLogModel->countPendingDeletions();
            $deletedCount = $this->deletionLogModel->countDeletedAccounts();
            $expiringSoon = $this->deletionLogModel->countExpiringSoon();

            // FIX-CMD171 (یافتهٔ ۱۷۱): تخمین حجم — قبلاً فقط × ۱ مگابایت برای pending
            // بود و بدون برچسبِ صریح «تخمین» نمایش داده می‌شد؛ اکنون هر دو گروه
            // (pending + deleted) با شمارشِ دقیق شمرده می‌شوند و ثابتِ تخمین مستند است.
            $estimatedBytesPerUser = 1024 * 1024; // ~۱ مگابایت به‌ازای هر کاربر (تخمین coarse)
            $totalDataSize = $estimatedBytesPerUser * ($pendingCount + $deletedCount);

            view('admin/account-deletion/stats', [
                'stats' => [
                    'pending_count' => $pendingCount,
                    'deleted_count' => $deletedCount,
                    'total_data_size' => $this->formatBytes($totalDataSize),
                    'expiring_soon' => $expiringSoon,
                ]
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            // FIX-18Q: همان گارد pending — view() موفق HttpResponseException می‌پرانند.
            throw $e;
        } catch (\Throwable $e) { // FIX-P3-CMD-174: \Throwable (هم‌تراز pending)
            $this->logger->error('admin.account_deletion.stats.failed', ['exception_type' => get_class($e), 'error_detail' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: دریافت آمار ناموفق بود');
            redirect('/admin/dashboard');
        }
    }

    private function formatBytes(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $pow = $bytes > 0 ? floor(log($bytes, 1024)) : 0;
        $pow = min($pow, count($units) - 1);
        return round($bytes / (1024 ** $pow), 2) . ' ' . $units[$pow];
    }

    /**
     * حذف فوری (بدون انتظار ۷ روز)
     */
    public function forceDelete(): void
    {
        try {
            $userId = $this->request->int('user_id');

            if (!$userId) {
                $this->session->setFlash('error', 'شناسه کاربر الزامی است');
                redirect('/admin/account-deletion/pending');
            }

            $adminId = $this->requireAdminId();

            // FIX-S16-2: حذف فوریِ حسابِ خودِ ادمین از پنل ممنوع (fail-closed — هم‌تراز الگوی C03-باگ۷)
            if ($userId === $adminId) {
                $this->session->setFlash('error', 'حذف حساب خودتان از پنل مدیریت مجاز نیست');
                redirect('/admin/account-deletion/pending');
            }

            // بررسی وجود درخواست
            $deletion = $this->deletionLogModel->getUserDeletionRequest($userId);
            if (!$deletion) {
                $this->session->setFlash('error', 'درخواست حذف برای این کاربر یافت نشد');
                redirect('/admin/account-deletion/pending');
            }

            // FIX-S16-2: فقط درخواستِ در وضعیت «requested» قابل حذف فوری است؛ «cancelled» یعنی
            // کاربر از حذف منصرف شده و پاک‌سازی او دورزدن تصمیم کاربر است.
            if ((string)($deletion->status ?? '') !== 'requested') {
                $this->session->setFlash('error', 'این درخواست در وضعیت فعال (requested) نیست و قابل حذف فوری نیست');
                redirect('/admin/account-deletion/pending');
            }

            // FIX-S16-2: نتیجهٔ واقعی ساگا بررسی می‌شود (قبلاً مقدار بازگشتی نادیده گرفته می‌شد
            // و شکستِ ساگا هم فلش «موفق» می‌گرفت) + deletedBy/reason برای ردِ حسابرسی
            // (recordDeletion قبلاً با NULL/NULL صدا زده می‌شد) + auditLog.
            $deleted = $this->deletionService->deleteUserAccount($userId, 'admin_force_delete', $adminId);

            if (!$deleted) {
                $this->logger->warning('admin.account_deletion.force_delete.rejected', [
                    'user_id' => $userId,
                    'admin_id' => $adminId,
                ]);
                $this->session->setFlash('error', 'حذف ناموفق بود — درخواست معتبر نیست یا شرایط حذف برقرار نیست');
                redirect('/admin/account-deletion/pending');
            }

            $this->auditLog('account_deletion.force_deleted', 'user', $userId,
                ['deletion_status' => (string)($deletion->status ?? '')],
                ['deleted' => true, 'reason' => 'admin_force_delete', 'deleted_by' => $adminId]);

            $this->logger->info('admin.account_deletion.force_deleted', [
                'user_id' => $userId,
                'admin_id' => $adminId
            ]);

            $this->session->setFlash('success', 'حساب کاربری با موفقیت حذف شد');
            redirect('/admin/account-deletion/history');

        } catch (\Core\Exceptions\HttpResponseException $e) {
            // FIX-18Q (P1-22): redirect() موفقِ حذفِ فوری خودش HttpResponseException می‌پرانند؛
            // catch عمومی پایین آن را می‌گرفت و فلش موفقیت با «خطا: حذف ناموفق بود» بازنویسی
            // می‌شد — حذفِ قطعیِ انجام‌شده در UI ادمین شکست نشان داده می‌شد. الگوی getUserDetails.
            throw $e;
        } catch (\Throwable $e) { // FIX-P3-CMD-174: \Throwable — خطای ساگا/TypeError به فلش generic می‌رود
            $this->logger->error('admin.account_deletion.force_delete.failed', [
                'exception_type' => get_class($e), 'error_detail' => $e->getMessage(),
                'user_id' => $this->request->int('user_id')
            ]);
            $this->session->setFlash('error', 'خطا: حذف ناموفق بود');
            redirect('/admin/account-deletion/pending');
        }
    }

    /**
     * لغو درخواست حذف
     */
    public function cancelDeletion(): void
    {
        try {
            $userId = $this->request->int('user_id');

            if (!$userId) {
                $this->session->setFlash('error', 'شناسه کاربر الزامی است');
                redirect('/admin/account-deletion/pending');
            }

            // FIX-R36-W3 (F-A15-08): وضعیتِ درخواست پیش از لغو برای حسابرسی ثبت می‌شود.
            $deletion = $this->deletionLogModel->getUserDeletionRequest($userId);

            // لغو درخواست
            $cancelled = $this->deletionService->cancelDeletion($userId);

            // FIX-CMD168 (یافتهٔ ۱۶۸): شکست لغو دیگر با پیام موفقیت پوشانده نمی‌شود —
            // قبلاً حتی وقتی cancelDeletion(false) برمی‌گرداند (درخواست فعال نبود)،
            // فلش «موفقیت» می‌گرفت و ادمین فکر می‌کرد لغو انجام شده.
            if (!$cancelled) {
                $this->logger->warning('admin.account_deletion.cancel.rejected', [
                    'user_id' => $userId,
                    'admin_id' => user_id(),
                ]);
                $this->session->setFlash('error', 'لغو انجام نشد — درخواست حذف فعال برای این کاربر یافت نشد');
                redirect('/admin/account-deletion/pending');
            }

            // FIX-R36-W3 (F-A15-08): cancelDeletion مثل forceDelete باید در
            // AdminAuditTrail ثبت شود — تصمیم ادمین دربارهٔ رضایت/نصرفِ کاربر
            // از حذف حساب، تصمیم حساسِ privacy/consent است (قرارداد متقارن با
            // auditLog مسیر force_delete در همین کنترلر).
            $this->auditLog('account_deletion.cancelled', 'user', $userId,
                ['deletion_status' => (string)($deletion->status ?? 'unknown')],
                ['cancelled' => true, 'cancelled_by' => (int)user_id()]);

            $this->logger->info('admin.account_deletion.cancelled', [
                'user_id' => $userId,
                'admin_id' => user_id()
            ]);

            $this->session->setFlash('success', 'درخواست حذف با موفقیت لغو شد');
            redirect('/admin/account-deletion/pending');

        } catch (\Core\Exceptions\HttpResponseException $e) {
            // FIX-18Q (P2-15): لغوِ موفق هم فلش خطا می‌گرفت — همان گارد forceDelete.
            throw $e;
        } catch (\Throwable $e) { // FIX-P3-CMD-174: \Throwable (هم‌تراز forceDelete)
            $this->logger->error('admin.account_deletion.cancel.failed', [
                'exception_type' => get_class($e), 'error_detail' => $e->getMessage()
            ]);
            $this->session->setFlash('error', 'خطا: لغو ناموفق بود');
            redirect('/admin/account-deletion/pending');
        }
    }

    /**
     * دریافت جزئیات کاربر برای حذف
     */
    public function getUserDetails(): void
    {
        // 🧭 FIX-X205 (راند ۵۵ — تعمیم کلاسِ باگ X202 به پنل ادمین): مرورگر → صف حذف حساب؛ AJAX → JSON
        if (!is_ajax()) {
            redirect(url('/admin/account-deletion/pending'));
        }

        try {
            $userId = $this->request->int('user_id');

            if (!$userId) {
                $this->response->json(['success' => false, 'error' => 'شناسه کاربر الزامی است'], 400);
                return;
            }

            $user = $this->userService->find($userId);
            if (!$user) {
                $this->response->json(['success' => false, 'error' => 'کاربر یافت نشد'], 404);
                return;
            }

            // ✅ Audit Log for admin accessing user PII
            $this->logger->warning('admin.pii.accessed', [
                'admin_id' => user_id(),
                'target_user_id' => $userId,
                'action' => 'get_user_details_for_deletion'
            ]);

            $deletion = $this->deletionLogModel->getUserDeletionRequest($userId);

            $uEmail = is_string($user->email ?? null) ? $user->email : '';
            $uMobile = is_string($user->mobile ?? null) ? $user->mobile : '';
            $uNationalId = is_string($user->national_id ?? null) ? $user->national_id : '';
            $uFullName = is_string($user->full_name ?? null) ? $user->full_name : '';
            $uUsername = is_string($user->username ?? null) ? $user->username : '';
            // FIX-P3-CMD-172: سقف طول فیلدهای متنیِ خروجی — دیتای خراب/طولانی نباید JSON چندصدهیلبایتی بسازد
            $uUsername = mb_substr($uUsername, 0, 100);
            $uFullName = mb_substr($uFullName, 0, 100);
            $uId = isset($user->id) && is_numeric($user->id) ? (int)$user->id : 0;
            $uCreatedAt = is_string($user->created_at ?? null) ? $user->created_at : '';
            $uLastActivity = is_string($user->last_activity_at ?? null) ? $user->last_activity_at : '';

            // ✅ Mask Email PII
            $maskedEmail = $uEmail;
            if (strpos($uEmail, '@') !== false) {
                [$name, $domain] = explode('@', $uEmail);
                $maskedEmail = substr($name, 0, 1) . '***@' . $domain;
            } else {
                $maskedEmail = '***';
            }

            // ✅ Mask Mobile PII
            $maskedMobile = !empty($uMobile) 
                ? substr($uMobile, 0, 4) . '***' . substr($uMobile, -2)
                : null;

            // ✅ Mask National ID PII
            $maskedNationalId = !empty($uNationalId)
                ? substr($uNationalId, 0, 3) . '****' . substr($uNationalId, -1)
                : null;

            // ✅ Mask Full Name PII (FIX-P3-CMD-172): هم‌سبک ماسک email — حرف اول + ***
            $maskedFullName = $uFullName !== '' ? mb_substr($uFullName, 0, 1) . '***' : null;

            // ✅ Access Control for Deletion Reason + Full Name (PII)
            // FIX-P3-CMD-172: قبلاً فقط reason محدود به super_admin بود و full_name خام به هر
            // callerِ دارای نقش ادمین برمی‌گشت. اکنون full_name هم برای غیر-super_admin ماسک می‌شود
            // (هم‌تراز سیاست حداقل‌دسترسی reason؛ یافتهٔ CMD-172 —fa=MODIFY). username
            // شناسهٔ عمومی حساب است و مطابق یافته خام می‌ماند (فقط سقف طول می‌گیرد).
            $currentUser = user();
            $isSuperAdmin = $currentUser !== null && isset($currentUser->role) && $currentUser->role === 'super_admin';
            $showReason = $isSuperAdmin;

            $this->response->json([
                'success' => true,
                'user' => [
                    'id' => $uId,
                    'username' => $uUsername !== '' ? $uUsername : $maskedEmail,
                    'email' => $maskedEmail,
                    'mobile' => $maskedMobile,
                    'national_id' => $maskedNationalId,
                    'full_name' => $isSuperAdmin ? ($uFullName !== '' ? $uFullName : null) : $maskedFullName,
                    'created_at' => $uCreatedAt,
                    'last_activity' => $uLastActivity !== '' ? $uLastActivity : 'N/A'
                ],
                'deletion' => $deletion ? [
                    'requested_at' => $deletion->requested_at,
                    'expires_at' => $deletion->expires_at,
                    'status' => $deletion->status,
                    'reason' => $showReason ? ($deletion->reason ?? '') : 'HIDDEN'
                ] : null
            ]);
            return;

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) { // FIX-P3-CMD-174: \Throwable — پاسخ JSON با پیام generic، بدون نشت متن exception
            $this->logger->error('admin.account_deletion.get_details.failed', [
                'exception_type' => get_class($e), 'error_detail' => $e->getMessage()
            ]);
            $this->response->json(['success' => false, 'error' => 'خطا: دریافت اطلاعات ناموفق'], 500);
            return;
        }
    }

    /**
     * دریافت آمار حذف
     */
    public function getStats(): void
    {
        // 🧭 FIX-X205: مرورگر → صف حذف حساب؛ AJAX → JSON (قرارداد status())
        if (!is_ajax()) {
            redirect(url('/admin/account-deletion/pending'));
        }

        try {
            // 🛡️ S7-FIX (UI-DEL-002): همان قرارداد stats() — شمارش‌های دقیق COUNT(*)
            $pendingCount = $this->deletionLogModel->countPendingDeletions();
            $deletedCount = $this->deletionLogModel->countDeletedAccounts();
            $expiringSoon = $this->deletionLogModel->countExpiringSoon();

            // FIX-CMD171: همان قرارداد stats() — تخمین مستند برای هر دو گروه
            $estimatedBytesPerUser = 1024 * 1024; // ~۱ مگابایت به‌ازای هر کاربر (تخمین coarse)
            $totalDataSize = $estimatedBytesPerUser * ($pendingCount + $deletedCount);

            $this->response->json([
                'success' => true,
                'stats' => [
                    'pending_count' => $pendingCount,
                    'deleted_count' => $deletedCount,
                    'total_data_size' => $this->formatBytes($totalDataSize),
                    'expiring_soon' => $expiringSoon,
                ]
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) { // FIX-P3-CMD-174: \Throwable (هم‌تراز getUserDetails)
            $this->logger->error('admin.account_deletion.get_stats.failed', [
                'exception_type' => get_class($e), 'error_detail' => $e->getMessage()
            ]);
            $this->response->json(['success' => false, 'error' => 'خطا: دریافت آمار ناموفق'], 500);
        }
    }


}
