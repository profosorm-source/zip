<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\LogService;
use App\Models\SentryModel;
use App\Controllers\Admin\BaseAdminController;
use Core\Database;
use Core\Queue;
use App\Contracts\LoggerInterface;
use App\Services\Settings\AppSettings;

/**
 * LogController — فقط نمایش و فیلتر گزارش‌ها
 * 
 * همه منطق در LogService است
 * این کنترلر فقط query param ها را می‌گیرد و نتیجه را نمایش می‌دهد
 */
class LogController extends BaseAdminController
{
    private LogService $logService;
    private SentryModel $sentryModel;

    public function __construct(
        LogService $logService,
        // 🧹 DI-CLEANUP (2026-08-24): SentryModel با تزریق سازنده (autowire توسط
        // Router) تأمین می‌شود — ساخت دستیِ `new SentryModel(app(...)...)` حذف شد.
        SentryModel $sentryModel,
        ?LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->logService  = $logService;
        $this->sentryModel = $sentryModel;
    }

    /**
     * داشبورد لاگ‌ها (نمای کلی)
     */
    public function index(): void
    {
        $type = $this->request->str('type', LogService::TYPE_ACTIVITY);
        $page = max(1, $this->request->int('page', 1));
        $perPage = 50;

        // FIX-R15C (M#5): قبلاً هیچ ردیفی پاس داده نمی‌شد و view('admin/logs/index')
        // که از $logs می‌خواند همیشه «هیچ لاگی ثبت نشده است» نشان می‌داد.
        // ردیف‌های واقعی و صفحه‌بندی‌شده از LogService (activity_logs) پاس می‌شود —
        // همان الگوی activity().
        $result = $this->logService->query(['type' => LogService::TYPE_ACTIVITY], $page, $perPage);

        view('admin/logs/index', [
            'title' => 'مدیریت لاگ‌ها',
            'activeType' => $type,
            'types' => $this->getLogTypes(),
            'logs' => $result['rows'],
            'total' => $result['total'],
            'page' => $result['page'],
            'perPage' => $result['perPage'],
            'totalPages' => $result['totalPages'],
        ]);
    }

    /**
     * لاگ‌های فعالیت کاربران
     */
    public function activity(): void
    {
        $filters = [
            'type' => null, // audit از AuditTrailController می‌آید
            'user_id'   => $this->request->int('user_id') ?: null,
            'action'    => $this->request->get('action'),
            'search'    => $this->request->get('search'),
            'date_from' => $this->request->get('date_from'),
            'date_to'   => $this->request->get('date_to'),
        ];

        $page = max(1, $this->request->int('page', 1));
        $perPage = 50;

        $result = $this->logService->query($filters, $page, $perPage);

        view('admin/logs/activity', [
            'title' => 'لاگ‌های فعالیت',
            'logs' => $result['rows'],
            'total' => $result['total'],
            'page' => $result['page'],
            'perPage' => $result['perPage'],
            'totalPages' => $result['totalPages'],
            'filters' => $filters,
        ]);
    }

    /**
     * لاگ‌های Audit Trail
     */
    public function audit(): void
    {
        $filters = [
            'event'     => $this->request->get('event'),
            'user_id'   => $this->request->int('user_id') ?: null,
            'search'    => $this->request->get('search'),
            'date_from' => $this->request->get('date_from'),
            'date_to'   => $this->request->get('date_to'),
        ];

        $page = max(1, $this->request->int('page', 1));
        $perPage = 50;

        // FIX-X214: قبلاً type=null به LogService::query می‌رسید و بی‌سروصدا activity_logs را
        // می‌خواند (تب «بررسی» هرگز audit_trail را نشان نمی‌داد). حالا مستقیم از مدل ممیزی:
        $result = (new \App\Models\AuditTrail(db()))->getAll(
            $page,
            $perPage,
            str_value($filters['event'] ?? ''),      // 🛡️ FIX-PS-C2: buildAuditFilters '' را مثل null می‌گیرد
            $filters['user_id'],
            str_value($filters['search'] ?? ''),
            str_value($filters['date_from'] ?? ''),
            str_value($filters['date_to'] ?? '')
        );

        view('admin/logs/audit', [
            'title' => 'Audit Trail',
            'logs' => $result['rows'],
            'total' => $result['total'],
            'page' => $result['page'],
            'perPage' => $perPage,
            'totalPages' => $result['totalPages'],
            'filters' => $filters,
        ]);
    }

    /**
     * لاگ‌های امنیتی
     */
    public function security(): void
    {
        $filters = [
            'type'      => LogService::TYPE_SECURITY,
            'level'     => $this->request->get('level'),
            'user_id'   => $this->request->int('user_id') ?: null,
            'search'    => $this->request->get('search'),
            'date_from' => $this->request->get('date_from'),
            'date_to'   => $this->request->get('date_to'),
        ];

        $page = max(1, $this->request->int('page', 1));
        $perPage = 50;

        $result = $this->logService->query($filters, $page, $perPage);

        view('admin/logs/security', [
            'title' => 'لاگ‌های امنیتی',
            'logs' => $result['rows'],
            'total' => $result['total'],
            'page' => $result['page'],
            'perPage' => $result['perPage'],
            'totalPages' => $result['totalPages'],
            'filters' => $filters,
        ]);
    }

    /**
     * لاگ‌های سیستمی
     */
    public function system(): void
    {
        $filters = [
            'type'      => LogService::TYPE_SYSTEM,
            'level'     => $this->request->get('level'),
            'search'    => $this->request->get('search'),
            'date_from' => $this->request->get('date_from'),
            'date_to'   => $this->request->get('date_to'),
        ];

        $page = max(1, $this->request->int('page', 1));
        $perPage = 50;

        $result = $this->logService->query($filters, $page, $perPage);

        view('admin/logs/system', [
            'title' => 'لاگ‌های سیستمی',
            'logs' => $result['rows'],
            'total' => $result['total'],
            'page' => $result['page'],
            'perPage' => $result['perPage'],
            'totalPages' => $result['totalPages'],
            'filters' => $filters,
        ]);
    }

    /**
     * مشاهده جزئیات یک لاگ
     */
    public function show(): void
    {
        $type = $this->request->str('type', LogService::TYPE_ACTIVITY);
        $id = $this->request->int('id');

        if ($id <= 0) {
            $this->session->setFlash('error', 'شناسه لاگ نامعتبر است.');
            redirect('/admin/logs/' . $type);
        }

        $log = $this->logService->findById($id, $type);
        if (!$log) {
            $this->session->setFlash('error', 'لاگ مورد نظر یافت نشد.');
            redirect('/admin/logs/' . $type);
        }

        view('admin/logs/show', [
            'title' => 'جزئیات لاگ',
            'type' => $type,
            'log' => $log,
        ]);
    }

    /**
     * پاک‌سازی لاگ‌های قدیمی
     */
    public function cleanup(): void
    {
        if ($this->request->getMethod() !== 'POST') {
            redirect('/admin/logs');
        }

        $days = $this->request->int('days', 90);

        if ($days < 30) {
            $this->session->setFlash('error', 'حداقل 30 روز باید باقی بماند.');
            redirect('/admin/logs');
        }

        $results = $this->logService->cleanup($days);

        // FIX-X211: گزارش صادقانهٔ همهٔ جدول‌ها با تعداد واقعی (قبلاً فقط «۱ فعالیت» فلگ دروغین بود)
        $message = sprintf(
            'پاک‌سازی انجام شد: %d فعالیت، %d امنیتی، %d سیستمی، %d کارایی',
            int_value($results['activity_logs'] ?? 0),
            int_value($results['security_logs'] ?? 0),
            int_value($results['system_logs'] ?? 0),
            int_value($results['performance_logs'] ?? 0)
        );

        $this->session->setFlash('success', $message);
        redirect('/admin/logs');
    }

    /**
     * Export لاگ‌ها
     */
    public function export(): void
    {
        $type = $this->request->str('type', LogService::TYPE_ACTIVITY);
        $format = $this->request->get('format', 'csv'); // csv, json, xlsx

        $filters = [
            'type' => $type,
            'date_from' => $this->request->get('date_from'),
            'date_to' => $this->request->get('date_to'),
        ];

        $result = $this->logService->query($filters, 1, 10000); // Max 10k rows

        if ($format === 'json') {
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="logs_' . date('Y-m-d') . '.json"');
            echo json_encode($result['rows'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        if ($format === 'csv') {
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="logs_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            if ($output === false) {
                return;
            }
            fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM
            
            // Headers
            $rows = is_array($result['rows'] ?? null) ? $result['rows'] : [];
            if (!empty($rows)) {
                $firstRow = (array)$rows[0];
                fputcsv($output, array_keys($firstRow));
                foreach ($rows as $row) {
                    $rowArr = (array)$row;
                    fputcsv($output, array_map('strval', $rowArr));
                }
            }
            
            fclose($output);
            exit;
        }

        $this->session->setFlash('error', 'فرمت نامعتبر است.');
        redirect('/admin/logs');
    }

    /**
     * رفع وضعیت خطای سیستمی
     * 🛡️ Fix: Explicitly call validateCsrf and handle exception to prevent bypass (MEDIUM-04)
     */
    public function resolveError(): void
    {
        $this->validateCsrf();
        
        $id = $this->request->int('id', 0);
        if ($id <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه لاگ نامعتبر است.'], 400);
            return;
        }

        // FIX-X208: قبلاً no-op بود ولی پیام موفقیت می‌داد (درغ). حالا واقعاً issue را در sentry_issues
        // با همان موتور سنتری حل‌شده علامت می‌زند (resolveSentryIssue).
        $adminId = (int)$this->userId();
        if ($this->sentryModel->resolveSentryIssue($id, $adminId)) {
            $this->logger->activity('system_log_resolved', "خطای #{$id} توسط ادمین حل‌شده علامت خورد", $adminId, ['issue_id' => $id]);
            $this->response->json(['success' => true, 'message' => 'خطا حل‌شده علامت خورد.']);
        } else {
            $this->response->json(['success' => false, 'message' => 'به‌روزرسانی وضعیت خطا ناموفق بود.'], 422);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE HELPERS
    // ─────────────────────────────────────────────────────────────────────────



    public function dashboard(): void
    {
        $period = $this->request->str('period', 'today');
        if (!in_array($period, ['today','yesterday','week','month'], true)) $period = 'today';
        $todayStats = [
            // FIX-X207: KPI از جدول مردهٔ error_logs (همیشه صفر دروغین) به دادهٔ زندهٔ سنتری وصل شد
            'total_errors' => $this->sentryModel->countTableRows('sentry_issues'),
            'critical_errors' => $this->countRows('sentry_issues', "level IN ('critical','fatal')"),
            // FIX-X207: اسکیمای دوگانهٔ performance_logs — دادهٔ کندی در value (metric=request_duration_ms)
            // است نه duration_ms که همیشه NULL/صفر است. کندیِ واقعی ۲۴ ساعت اخیر.
            'slow_requests' => $this->countRows('performance_logs', "metric = 'request_duration_ms' AND CAST(value AS DECIMAL(14,3)) > 1000 AND created_at >= NOW() - INTERVAL 1 DAY"),
            'active_alerts' => $this->sentryModel->countTableRows('system_alerts', 'is_active = 1'),
        ];
        $performanceStats = ['avg_time' => $this->sentryModel->avgMetricValue('request_duration_ms')];
        $errorStats = ['top_errors' => $this->topErrors()];
        $activeAlerts = $this->activeAlerts();
        $comparison = ['errors_change' => ['direction' => 'down', 'percent' => 0]];
        $predictions = [];
        view('admin/logs/dashboard', compact('period','todayStats','performanceStats','errorStats','activeAlerts','comparison','predictions'));
    }

    public function errors(): void
    {
        // FIX-X208: فهرست خطاها از جدول مردهٔ error_logs (همیشه صفر) می‌آمد. قرارداد دوگانهٔ مستندِ status():
        // مرورگر → صفحهٔ زندهٔ سنتری (Issues) | AJAX/API → JSON فهرست issues
        if (!is_ajax()) {
            redirect(url('/admin/sentry/issues'));
        }
        $page = max(1, $this->request->int('page', 1));
        $perPage = 50;
        $offset = ($page - 1) * $perPage;
        $errors = $this->sentryModel->getErrorLogs($perPage, $offset);
        $total = $this->sentryModel->countTableRows('sentry_issues');
        $this->response->json([
            'success' => true,
            'data' => $errors,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => (int)ceil($total / $perPage),
        ]);
    }

    public function errorDetails(): void
    {
        $id = $this->request->int('id', 0);
        $error = $this->errorById($id) ?: (object)[
            'id' => $id, 'message' => 'خطا یافت نشد', 'level' => 'ERROR', 'trace' => null, 'context' => null,
            'is_resolved' => true, 'occurrence_count' => 0, 'first_occurred_at' => date('Y-m-d H:i:s'),
            'last_occurred_at' => date('Y-m-d H:i:s'), 'file_path' => null, 'line_number' => null,
            'exception_type' => null, 'url' => null, 'method' => null, 'user_id' => null, 'ip_address' => null,
            'user_agent' => null, 'resolved_by' => null, 'resolved_at' => null, 'resolution_note' => null,
        ];
        $suggestions = [];
        $similarErrors = $id > 0 ? $this->sentryModel->getSimilarErrors($error->message) : [];
        view('admin/logs/error-details', compact('error','suggestions','similarErrors'));
    }

    public function notificationSettings(): void
    {
        $channels = $this->sentryModel->getNotificationChannelsForSettings();
        $rules = $this->sentryModel->getAlertRulesForSettings();
        view('admin/logs/notification-settings', compact('channels','rules'));
    }

    public function saveChannel(): void
    {
        $this->response->json(['success' => true, 'message' => 'ذخیره تنظیمات کانال در این نسخه به‌صورت امن غیرفعال است.']);
    }

    public function testChannel(): void
    {
        $this->response->json(['success' => true, 'message' => 'تست کانال با موفقیت شبیه‌سازی شد.']);
    }

    public function toggleRule(): void
    {
        $body = $this->request->body();
        $ruleId = int_value($body['id'] ?? $body['rule_id'] ?? 0);
        $enabled = (bool)int_value($body['is_active'] ?? $body['enabled'] ?? 1);

        // FIX-X89: از no-op صرفاً لاگی به toggle واقعی در DB (alert_rules.is_active)
        $ok = $this->sentryModel->toggleAlertRule($ruleId, $enabled);
        if (!$ok) {
            $this->logger->warning('admin.log_rule_toggle.failed', ['rule_id' => $ruleId, 'admin_id' => (int)$this->userId()]);
            $this->response->json(['success' => false, 'message' => 'تغییر وضعیت قاعدهٔ هشدار ناموفق بود.'], 422);
            return;
        }
        $this->logger->info('admin.log_rule_toggled', ['rule_id' => $ruleId, 'enabled' => $enabled, 'admin_id' => (int)$this->userId()]);
        $this->response->json(['success' => true, 'message' => 'قاعده هشدارهای لاگ به‌روزرسانی شد.']);
    }

    public function apiStats(): void
    {
        // 🧭 FIX-X205 (راند ۵۵ — تعمیم کلاسِ باگ X202 به پنل ادمین): مرورگر به‌جای JSON خام → داشبورد لاگ‌ها؛ کلاینت AJAX/API → قرارداد JSON دست‌نخورده
        if (!is_ajax()) {
            redirect(url('/admin/logs/dashboard'));
        }

        // 🧭 FIX-X206 (راند ۵۵): قرارداد واقعی logsdashboard.js — بدنه باید «آرایهٔ خام» نمودار باشد
        // (Array.isArray(data) در JS) و پارامترهای type/period که دو فراخوان زنده می‌فرستند باید محترم باشند.
        // قبلاً: آبجکت ثابتِ شمارنده با type/period نادیده‌گرفته‌شده → هر دو نمودار داشبورد هیچ‌وقت رندر نمی‌شدند.
        $type = $this->request->str('type', 'errors');
        $days = max(1, min(90, $this->request->int('period', 7)));

        $rows = match ($type) {
            'errors' => $this->sentryModel->getDailyCountSeries('error_logs', $days),
            // FIX-X206: دادهٔ واقعی مدت‌زمان در value با metric='request_duration_ms' است (duration_ms همیشه NULL)
            'performance' => $this->sentryModel->getDailyAvgSeries('performance_logs', 'value', $days, 'request_duration_ms'),
            default => [],
        };

        $this->response->json($rows);
    }

    public function activityLogs(): void
    {
        $this->activity();
    }

    private function errorById(int $id): ?\stdClass
    {
        return $this->sentryModel->findErrorById($id);
    }

    /** @return list<\stdClass> */
    private function topErrors(): array
    {
        return $this->sentryModel->getTopErrorLogs();
    }

    /** @return list<\stdClass> */
    private function activeAlerts(): array
    {
        return $this->sentryModel->getActiveAlertsForDashboard();
    }

    private function countRows(string $table, string $where = '1=1'): int
    {
        return $this->sentryModel->countTableRows($table, $where);
    }

    /**
     * دریافت لیست انواع لاگ
     */
    /** @return array<string, mixed> */
    private function getLogTypes(): array
    {
        return [
            LogService::TYPE_SYSTEM => 'لاگ‌های سیستم',
            LogService::TYPE_ACTIVITY => 'لاگ‌های فعالیت',
            LogService::TYPE_SECURITY => 'لاگ‌های امنیتی',
            LogService::TYPE_PERFORMANCE => 'لاگ‌های عملکرد',
        ];
    }

    // =========================================================================
    // FEAT-R11 — صندوق ایمیل محیطی (Dev Mailbox)
    // -------------------------------------------------------------------------
    // در سندباکس/محیط‌های بدون SMTP (MAIL_DRIVER=log) ایمیل‌های «ارسال‌شده» به‌صورت
    // خطوط JSON در storage/logs/mail.log نوشته می‌شوند (EmailService::sendViaLog).
    // این صفحه همان لاگ را به‌صورت صندوق ورودی قابل‌مرور به ادمین می‌دهد تا جریان
    // ایمیل (تأیید حساب، بازیابی رمز، ...) بدون SMTP قابل QA باشد.
    // فقط-خواندنی، مسیر قفل‌شده به mail.log، بدون هیچ عملیات نوشتن/حذف.
    // =========================================================================

    private const MAILBOX_LIMIT = 100;

    /**
     * خواندن و پارس ایمن mail.log — جدیدترین اول.
     * خط خراب/ناقص نادیده گرفته می‌شود (لاگ همیشه append-only است).
     *
     * @return list<array<string, mixed>>
     */
    private function readMailLog(int $limit = self::MAILBOX_LIMIT): array
    {
        $file = storage_path('logs/mail.log');
        if (!is_file($file) || !is_readable($file)) {
            return [];
        }

        $raw = (string)@file_get_contents($file);
        if ($raw === '') {
            return [];
        }

        $lines = preg_split('/\r?\n/', $raw) ?: [];
        $out = [];
        for ($i = count($lines) - 1; $i >= 0 && count($out) < $limit; $i--) {
            $line = trim($lines[$i]);
            if ($line === '') {
                continue;
            }
            $rec = json_decode($line, true);
            if (!is_array($rec) || !isset($rec['to'], $rec['subject'])) {
                continue; // خط ناقص/خراب — صرف‌نظر
            }
            $out[] = [
                'idx'     => $i, // شمارهٔ خط واقعی در فایل — همان قرارداد در mailboxShow
                'ts'      => str_value($rec['ts'] ?? ''),
                'to'      => str_value($rec['to']),
                'to_name' => str_value($rec['to_name'] ?? ''),
                'subject' => str_value($rec['subject']),
                'from'    => str_value($rec['from'] ?? ''),
            ];
        }
        return $out;
    }

    /**
     * لیست صندوق ایمیل — GET /admin/logs/mailbox
     */
    public function mailbox(): void
    {
        view('admin/logs/mailbox', [
            'title'  => 'صندوق ایمیل محیطی',
            'emails' => $this->readMailLog(),
            'limit'  => self::MAILBOX_LIMIT,
        ]);
    }

    /**
     * بدنهٔ یک ایمیل برای iframe — GET /admin/logs/mailbox/{idx}
     * فقط-خواندنی؛ ایندکس عددی از ابتدای فایل، با گارد بازه.
     */
    public function mailboxShow(int $idx): void
    {
        $file = storage_path('logs/mail.log');
        if ($idx < 0 || !is_file($file) || !is_readable($file)) {
            http_response_code(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'email not found';
            exit;
        }

        $lines = preg_split('/\r?\n/', (string)@file_get_contents($file)) ?: [];
        if ($idx >= count($lines)) {
            http_response_code(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'email not found';
            exit;
        }

        $rec = json_decode(trim($lines[$idx]), true);
        if (!is_array($rec) || !isset($rec['body_html'])) {
            http_response_code(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'email not found';
            exit;
        }

        header('Content-Type: text/html; charset=utf-8');
        // 🛡️ دفاع در عمق: بدنهٔ ایمیل در iframe سندباکس‌شده (sandbox="") رندر می‌شود —
        // بدون script/فرم/ناوبری؛ اینجا هم تگ اسکریپت‌ها حذف می‌شوند.
        $body = str_value($rec['body_html']);
        $body = preg_replace('/<script\b[^>]*>.*?<\/script>/ius', '', $body) ?? $body;
        $body = preg_replace('/\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/ius', '', $body) ?? $body;
        echo $body;
        exit;
    }
}

