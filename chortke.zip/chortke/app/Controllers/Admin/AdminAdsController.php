<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Models\Ads;
use App\Services\Search\SearchOrchestrator;
use App\Services\Analytics\AnalyticsService;

/**
 * AdminAdsController — Unified Advertising Dashboard for Administrators.
 *
 * Provides a single-pane view of ALL advertisements across all types:
 * social_task, custom_task, seo, adtube, banner, notification.
 *
 * Detail views and type-specific operations are DELEGATED to dedicated
 * sub-controllers (AdminSocialTaskController, AdminAdTaskController, etc.)
 * to avoid God Class anti-pattern.
 */
class AdminAdsController extends BaseAdminController
{
    private Ads $adsModel;
    private SearchOrchestrator $searchService;
    private AnalyticsService $analyticsService;

    public function __construct(
        Ads $adsModel,
        SearchOrchestrator $searchService,
        AnalyticsService $analyticsService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->adsModel = $adsModel;
        $this->searchService = $searchService;
        $this->analyticsService = $analyticsService;
    }

    /**
     * Unified listing: /admin/ads
     * Filters: ?type= | ?status= | ?search= | ?user_id= | ?date_from= | ?date_to=
     */
    public function index(): void
    {
        $page   = max(1, (int)($this->request->get('page') ?? 1));
        $limit  = 30;
        $offset = ($page - 1) * $limit;

        $filters = [
            'type'      => $this->request->get('type') ?? '',
            'status'    => $this->request->get('status') ?? '',
            'search'    => trim($this->request->get('search') ?? ''),
            'user_id'   => $this->request->get('user_id') ?? '',
            'date_from' => $this->request->get('date_from') ?? '',
            'date_to'   => $this->request->get('date_to') ?? '',
        ];

        // Unified count & list from canonical ads table
        $total = $this->adsModel->adminCount($filters['type'], $filters['status']);
        $items = $this->adsModel->adminList(
            $filters['type'],
            $filters['status'],
            $limit,
            $offset
        );

        // Enrich with user names if needed (could be optimized with JOIN)
        // TODO: add JOIN to adminList for user_name if performance degrades

        // Overview stats across all types
        $overview = $this->buildOverviewStats();

        view('admin.ads.index', [
            'title'      => 'مدیریت یکپارچه تبلیغات',
            'items'      => $items,
            'total'      => $total,
            'page'       => $page,
            'totalPages' => (int)ceil($total / $limit),
            'filters'    => $filters,
            'overview'   => $overview,
            'statusLabels'  => $this->adsModel->statusLabels(),
            'statusClasses' => $this->adsModel->statusClasses(),
            'typeLabels'    => $this->typeLabels(),
        ]);
    }

    /**
     * Show any ad regardless of type.
     * Delegates to type-specific controller for detail operations if needed.
     */
    public function show(): void
    {
        $id = (int)$this->request->param('id');
        $ad = $this->adsModel->find($id);

        if (!$ad) {
            $this->session->setFlash('error', 'آگهی یافت نشد.');
            redirect(url('/admin/ads'));
            return;
        }

        // Gather execution counts per type (if applicable)
        $executionCount = 0;
        $executionStats = [];

        // Redirect to type-specific admin controller for deep operations
        $typeDetailUrl = match ($ad->type) {
            'custom_task' => url('/admin/custom-tasks/' . $id),
            'social_task' => url('/admin/social-tasks/' . $id),
            'seo'         => url('/admin/seo-keywords/' . $id), // or admin/seo-ads
            'banner'      => url('/admin/banners/' . $id),
            default       => null,
        };

        view('admin.ads.show', [
            'title'          => 'جزئیات آگهی #' . $id,
            'ad'             => $ad,
            'typeDetailUrl'  => $typeDetailUrl,
            'executionCount' => $executionCount,
            'executionStats' => $executionStats,
            'statusLabels'   => $this->adsModel->statusLabels(),
            'typeLabels'     => $this->typeLabels(),
        ]);
    }

    /**
     * Bulk status change (approve / reject / pause / resume / delete).
     * Only generic operations; type-specific logic (e.g., payout on approval)
     * should be handled by the respective sub-controller.
     */
    public function bulkAction(): void
    {
        header('Content-Type: application/json');

        $ids    = $this->request->post('ids') ?? [];
        $action = $this->request->post('action') ?? '';

        if (empty($ids) || !is_array($ids) || !in_array($action, ['approve','reject','pause','resume','delete'], true)) {
            echo json_encode(['success' => false, 'message' => 'درخواست نامعتبر.']);
            return;
        }

        $allowed = ['approve'=>'active','reject'=>'rejected','pause'=>'paused','resume'=>'active'];
        $status  = $allowed[$action] ?? null;

        $updated = 0;
        foreach ($ids as $id) {
            $id = (int)$id;
            if ($action === 'delete') {
                $this->adsModel->update($id, ['deleted_at' => date('Y-m-d H:i:s')]);
            } elseif ($status) {
                $this->adsModel->update($id, ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')]);
            }
            $updated++;
        }

        $this->logger->activity('admin.ads.bulk', 'عملیات گروهی روی آگهی‌ها', user_id(), [
            'action' => $action, 'count' => $updated
        ]);

        echo json_encode(['success' => true, 'updated' => $updated]);
    }

    /**
     * AJAX: Unified ad statistics for dashboard charts.
     */
    public function stats(): void
    {
        header('Content-Type: application/json');

        $days = min(90, max(7, (int)($this->request->get('days') ?? 30)));

        $stats = [
            'by_type'   => $this->analyticsService->getAdsByTypeStats($days),
            'by_status' => $this->analyticsService->getAdsByStatusStats(),
            'budget'    => $this->analyticsService->getAdsBudgetStats($days),
        ];

        echo json_encode(['success' => true, 'stats' => $stats]);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private function buildOverviewStats(): array
    {
        $total     = $this->adsModel->adminCount('', '');
        $active    = $this->adsModel->adminCount('', 'active');
        $pending   = $this->adsModel->adminCount('', 'pending');
        $completed = $this->adsModel->adminCount('', 'completed');

        return [
            'total'     => $total,
            'active'    => $active,
            'pending'   => $pending,
            'completed' => $completed,
        ];
    }

    private function typeLabels(): array
    {
        return [
            'social_task'  => 'شبکه‌های اجتماعی',
            'custom_task'  => 'تسک سفارشی',
            'seo'          => 'سئو و کلیک',
            'adtube'       => 'AdTube',
            'banner'       => 'بنر',
            'notification' => 'نوتیفیکیشن',
        ];
    }
}
