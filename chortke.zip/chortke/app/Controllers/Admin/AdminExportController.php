<?php

namespace App\Controllers\Admin;

use App\Services\ExportService;
use Core\Logger;
use App\Services\AuditTrail;
use App\Controllers\Admin\BaseAdminController;

/**
 * AdminExportController - مرکز خروجی‌گیری ادمین
 */
class AdminExportController extends BaseAdminController
{
    private ExportService $exportService;
    // 🧹 DI-CLEANUP (2026-08-24): پراپرتی $auditTrail ارثبرده از BaseAdminController (با #[Inject]) است.
    

   public function __construct(ExportService $exportService, AuditTrail $auditTrail, ?\App\Contracts\LoggerInterface $logger = null) {
    parent::__construct(null, null, null, null, $logger);
    $this->exportService = $exportService;
    $this->auditTrail = $auditTrail;
}

    /** صفحه اصلی Export */
    public function index(): void
    {
        view('admin.export.index', ['title' => 'خروجی‌گیری داده']);
    }

    /** خروجی کاربران */
    public function users(): void
{
    $filters = $this->filters();

    $this->auditTrail->record(
    'admin.export',
    null,
    ['type' => 'users', 'filters' => $filters],
    user_id()
);

    $this->exportService->exportUsers($filters);
}

public function transactions(): void
{
    $filters = $this->filters();

    $this->auditTrail->record(
    'admin.export',
    null,
    ['type' => 'transactions', 'filters' => $filters],
    user_id()
);

    $this->exportService->exportTransactionsStream($filters);
}

public function withdrawals(): void
{
    $filters = $this->filters();

    $this->auditTrail->record(
    'admin.export',
    null,
    ['type' => 'withdrawals', 'filters' => $filters],
    user_id()
);

    $this->exportService->exportWithdrawalsStream($filters);
}

public function auditTrail(): void
{
    $filters = $this->filters();

    $this->auditTrail->record(
    'admin.export',
    null,
    ['type' => 'audit_trail', 'filters' => $filters],
    user_id()
);

    $this->exportService->exportAuditTrail($filters);
}

    /** @return array<string, mixed> */
    private function filters(): array
    {
        // FIX-R19-A5-6: فیلترهای GET نرمال‌سازی می‌شوند — user_id عددی، status سفید‌لیست
        // (ساختار DB: withdrawals ENUM + وضعیت‌های transactions)، type الگوی شناسه امن
        // (ستون transactions.type VARCHAR باز است؛ سفید‌لیست بسته مقادیر واقعی را
        // بی‌صدا می‌انداخت)، و تاریخ‌ها فقط در قالب معتبر عبور می‌کنند.
        $raw = $this->request->get();
        $raw = is_array($raw) ? $raw : [];

        $status = str_value($raw['status'] ?? '');
        if (!in_array($status, ['pending', 'processing', 'completed', 'failed', 'rejected', 'cancelled', 'reversed'], true)) {
            $status = '';
        }

        $type = str_value($raw['type'] ?? '');
        if (!preg_match('/^[a-z0-9_]{1,50}$/', $type)) {
            $type = '';
        }

        $userId = int_value($raw['user_id'] ?? 0);

        return array_filter([
            'from' => $this->normalizeExportDate(str_value($raw['from'] ?? '')),
            'to' => $this->normalizeExportDate(str_value($raw['to'] ?? '')),
            'status' => $status,
            'user_id' => $userId > 0 ? $userId : '',
            'type' => $type,
        ]);
    }

    /** FIX-R19-A5-6: فقط تاریخ معتبر؛ خروجی همیشه Y-m-d یا رشتهٔ خالی */
    private function normalizeExportDate(string $value): string
    {
        if ($value === '' || mb_strlen($value) > 10) {
            return '';
        }
        $ts = strtotime($value);
        if ($ts === false) {
            return '';
        }
        return date('Y-m-d', $ts);
    }
}
