<?php

namespace App\Controllers\Admin;

use App\Services\Analytics\AnalyticsService;
use App\Services\ExportService;
use App\Controllers\Admin\BaseAdminController;

class KpiController extends BaseAdminController
{
    private ExportService $exportService;

    private AnalyticsService $analyticsService;

    /** X374 (راند ۹۳) — لجر KPI وب‌هوک S2S (اختیاری؛ lazy-resolve در سروِ تب) */
    private ?\App\Models\S2sHookEvent $s2sHookEvents;

    public function __construct(
        \App\Services\ExportService $exportService,
        AnalyticsService $analyticsService, ?\App\Contracts\LoggerInterface $logger = null,
        // X374 (راند ۹۳): دامنهٔ KPI برای S2S — اختیاری تا سازنده‌های موجود نشکنند
        ?\App\Models\S2sHookEvent $s2sHookEvents = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->exportService = $exportService;
        $this->analyticsService = $analyticsService;
        $this->s2sHookEvents = $s2sHookEvents;
    }

    /**
     * داشبورد KPI اصلی
     */
    public function index(): string
    {
        // X374 (راند ۹۳): صفحهٔ KPI شبکه‌های تبلیغاتی (S2S) به‌صورت تبِ ?tab=s2s
        // زیر همین روت موجود /admin/kpi سوار می‌شود — بدون هیچ تغییری در فایل‌های
        // روت (مالکیت مجری 93-b)؛ الگوی قبلی مالی/کاربران (روت‌های صریح) جایی
        // برای /admin/kpi/s2s ندارد و افزودن روت از حیطهٔ مالکیت این راند بیرون است.
        if (str_value($this->request->get('tab', '')) === 's2s') {
            return $this->s2sTab();
        }

        $userStats = $this->analyticsService->getUserMetrics();
        $financialStats = $this->analyticsService->getTransactionMetrics();
        $taskStats = $this->analyticsService->getTaskMetrics();
        $ticketStats = $this->analyticsService->getTicketStats();
        $fraudStats = $this->analyticsService->getFraudStats();
        $churnRate = $this->analyticsService->getChurnRate();
        $conversionRate = $this->analyticsService->getConversionRate();

        return view('admin.kpi.index', [
            'userStats' => $userStats,
            'financialStats' => $financialStats,
            'taskStats' => $taskStats,
            'ticketStats' => $ticketStats,
            'fraudStats' => $fraudStats,
            'churnRate' => $churnRate,
            'conversionRate' => $conversionRate,
        ]);
    }

    /**
     * X374 (راند ۹۳) — تب «شبکه‌های تبلیغاتی (S2S)» زیر /admin/kpi?tab=s2s.
     * داده‌ها از لجر s2s_hook_events می‌آید؛ شکستِ خواندن (مثلاً پیش از اجرای
     * مایگریشن) صفحه را با حالت خالی رندر می‌کند، نه ۵۰۰.
     */
    private function s2sTab(): string
    {
        $days = max(1, min(365, $this->request->int('days', 30)));

        try {
            $model = $this->s2sHookEvents ?? \Core\Container::getInstance()->make(\App\Models\S2sHookEvent::class);
            $data = [
                'days'    => $days,
                'overall' => $model->overallStats($days),
                'networks' => $model->networkStats($days),
                'recent'  => $model->recent(50),
            ];
        } catch (\Throwable $e) {
            $this->logger->error('kpi.s2s_tab.failed', ['error' => $e->getMessage()]);
            $data = [
                'days'    => $days,
                'overall' => [
                    'attempts' => 0, 'credited' => 0, 'replays' => 0, 'rejected' => 0,
                    'acceptance_rate' => 0.0, 'top_reject_reason' => null, 'payouts' => [],
                ],
                'networks' => [],
                'recent'  => [],
            ];
        }

        return view('admin.kpi.s2s', $data);
    }

    /**
     * داده‌های نمودار (AJAX)
     */
    public function chartData(): void
    {
        // 🧭 FIX-X205 (راند ۵۵ — تعمیم کلاسِ باگ X202 به پنل ادمین): مرورگر به‌جای JSON خام → داشبورد KPI؛ کلاینت AJAX/API → قرارداد JSON دست‌نخورده
        if (!is_ajax()) {
            redirect(url('/admin/kpi'));
            return;
        }
        $type = $this->request->get('type') ?: 'revenue';
        $days = $this->request->int('days', 30);
        $days = \min($days, 365);

        $data = match ($type) {
            'revenue' => $this->analyticsService->getDailyRevenue($days),
            'registrations' => $this->analyticsService->getDailyRegistrations($days),
            'tasks' => $this->analyticsService->getDailyCompletedTasks($days),
            'deposits_withdrawals' => $this->analyticsService->getDailyDepositsWithdrawals($days),
            'platforms' => $this->analyticsService->getTasksByPlatform(),
            'hourly' => $this->analyticsService->getHourlyActivity(\min($days, 30)),
            default => [],
        };

        $this->response->json(['success' => true, 'type' => $type, 'data' => $data]);
    }

    /**
     * جزئیات مالی
     */
    public function financial(): string
    {
        $financialStats = $this->analyticsService->getTransactionMetrics();
        $dailyRevenue = $this->analyticsService->getDailyRevenue(30);
        $dailyDW = $this->analyticsService->getDailyDepositsWithdrawals(30);
        $investmentStats = $this->analyticsService->getInvestmentStats();
        $referralStats = $this->analyticsService->getReferralStats();

        return view('admin.kpi.financial', [
            'financialStats' => $financialStats,
            'dailyRevenue' => $dailyRevenue,
            'dailyDW' => $dailyDW,
            'investmentStats' => $investmentStats,
            'referralStats' => $referralStats,
        ]);
    }

    /**
     * جزئیات کاربران
     */
    public function users(): string
    {
        $userStats = $this->analyticsService->getUserMetrics();
        $dailyReg = $this->analyticsService->getDailyRegistrations(30);
        $topUsers = $this->analyticsService->getTopUsers(20);
        $lotteryStats = $this->analyticsService->getLotteryStats();

        return view('admin.kpi.users', [
            'userStats' => $userStats,
            'dailyReg' => $dailyReg,
            'topUsers' => $topUsers,
            'lotteryStats' => $lotteryStats,
        ]);
    }

    /**
     * خروجی CSV کاربران
     */
    public function exportUsers(): void
    {
                $filters = [
            'date_from' => $this->request->get('date_from'),
            'date_to' => $this->request->get('date_to'),
        ];

        $data = $this->exportService->prepareUsersExport($filters);
        $this->exportService->exportCsv($data['headers'], $data['rows'], 'users_export');
    }

    /**
     * خروجی CSV تراکنش‌ها
     */
    public function exportTransactions(): void
    {
                $filters = [
            'date_from' => $this->request->get('date_from'),
            'date_to' => $this->request->get('date_to'),
            'type' => $this->request->get('type'),
            'status' => $this->request->get('status'),
        ];

        $data = $this->exportService->prepareTransactionsExport($filters);
        $this->exportService->exportCsv($data['headers'], $data['rows'], 'transactions_export');
    }

    /**
     * خروجی JSON خلاصه
     */
    public function exportSummary(): void
    {
        $summary = $this->analyticsService->getDashboardSummary();

        $this->exportService->exportJson($summary, 'kpi_summary');
    }
}