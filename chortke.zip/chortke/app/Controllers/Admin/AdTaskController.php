<?php

namespace App\Controllers\Admin;

use App\Models\Ads;
use App\Services\CustomTask\AdminCustomTaskService;
use App\Services\Analytics\AnalyticsService;
use App\Contracts\WalletServiceInterface;
use App\Services\Search\SearchOrchestrator;
use App\Controllers\Admin\BaseAdminController;

class AdTaskController extends BaseAdminController
{
    private AdminCustomTaskService $customTaskService;
    private AnalyticsService $analyticsService;
    private Ads $adsModel;

    public function __construct(
        AdminCustomTaskService $customTaskService,
        AnalyticsService $analyticsService,
        Ads $adsModel,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->customTaskService = $customTaskService;
        $this->analyticsService = $analyticsService;
        $this->adsModel = $adsModel;
    }

    /**
     * لیست وظایف
     */
    public function index(): string
    {
        $filters = [
            'status' => $this->request->str('status', ''),
            'task_type' => $this->request->str('task_type', ''),
        ];

        $search = trim($this->request->str('search', ''));
        $page = \max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;

        // استفاده از SearchOrchestrator برای جستجو
        if (!empty($search)) {
            $result = $this->adsModel->searchAdminTasks($search, $filters, $limit, $offset);
            $tasks = $result['items'] ?? [];
            $total = $result['total'] ?? 0;
        } else {
            $tasks = $this->adsModel->adminList('custom_task', $filters['status'], $limit, $offset);
            $total = $this->adsModel->adminCount('custom_task', $filters['status']);
        }

        return view('admin.custom-tasks.index', [
            'tasks' => $tasks,
            'total' => $total,
            'page' => $page,
            'pages' => \ceil($total / $limit),
            'filters' => $filters,
            'search' => $search,
            'statusLabels' => $this->adsModel->statusLabels(),
            'statusClasses' => $this->adsModel->statusClasses(),
            'taskTypes' => $this->adsModel->taskTypes(),
        ]);
    }

    /**
     * جزئیات وظیفه
     */
    public function show(): string
    {
        $taskId = (int) $this->request->param('id');
        $details = $this->customTaskService->getTaskDetailsForAdmin($taskId);

        if (!$details) {
            \http_response_code(404);
            include __DIR__ . '/../../../views/errors/404.php';
            exit;
        }

        return view('admin.custom-tasks.show', [
            'task' => $details['task'],
            'submissions' => $details['submissions'],
            'statusLabels' => $this->adsModel->statusLabels(),
            'submissionStatusLabels' => $this->adsModel->submissionStatusLabels(),
        ]);
    }

    /**
     * تأیید/رد وظیفه (Ajax)
     */
    public function approve(): void
    {
        $decodedBody = json_decode((file_get_contents('php://input') ?: ''), true);
        $body = is_array($decodedBody) ? $decodedBody : [];

        // 📜 قرارداد واحد ورودی (RULES §۱۸)
        $request = new \App\Validators\Requests\ModerateCustomTaskRequest($body);
        if (!$request->validate()) {
            $errors = $request->errors();
            $firstValue = reset($errors);
            $firstError = is_array($firstValue) ? reset($firstValue) : $firstValue;
            $this->response->json(['success' => false, 'message' => is_string($firstError) && $firstError !== '' ? $firstError : 'تصمیم نامعتبر.', 'errors' => $errors], 422);
            return;
        }
        $validated = $request->safeValidated();
        $taskId = int_value($validated['task_id'] ?? 0);
        $decision = str_value($validated['decision'] ?? '');
        $reason = is_string($validated['reason'] ?? null) ? $validated['reason'] : null;

        if ($decision === 'approve') {
            $result = $this->customTaskService->approveTask($taskId, (int)$this->userId());

            $this->logger->activity('custom_task.approve', 'تأیید وظیفه', user_id(), ['task_id' => $taskId]);
            $this->response->json($result, $result['success'] ? 200 : 422);

        } else {
            $reasonStr = $reason !== null ? str_value($reason) : null;
            $result = $this->customTaskService->rejectTask($taskId, (int)$this->userId(), $reasonStr);

            $this->logger->activity('custom_task.reject', 'رد وظیفه', user_id(), ['task_id' => $taskId, 'reason' => $reason]);
            $this->response->json($result, $result['success'] ? 200 : 422);
        }
    }

    /**
     * آمار و گزارش
     */
    public function stats(): void
    {
        // 🧭 FIX-X205 (راند ۵۵ — تعمیم کلاسِ باگ X202 به پنل ادمین): مرورگر → لیست تسک‌های سفارشی؛ AJAX → JSON
        if (!is_ajax()) {
            redirect(url('/admin/custom-tasks'));
        }

        $result = $this->customTaskService->getAdminStats();
        $this->response->json($result);
    }

    /**
     * داشبورد آمار کلی
     */
    public function analytics(): string
    {
        $analyticsData = $this->customTaskService->getAdminAnalytics();

        // تسک‌های پرطرفدار
        $trending = $this->analyticsService->getTrendingTasks(10);

        return view('admin.custom-tasks.analytics', [
            'taskStats' => $analyticsData['taskStats'],
            'submissionStats' => $analyticsData['submissionStats'],
            'trending' => $trending,
        ]);
    }
}
