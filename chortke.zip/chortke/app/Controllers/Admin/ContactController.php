<?php

namespace App\Controllers\Admin;

use App\Services\ContactService;
use App\Controllers\Admin\BaseAdminController;

/**
 * 🛡️ FIX-S30-10 (R75): صندوق ادمین پیام‌های «تماس با ما» — تاکنون متن پیام
 * مشتری فقط با دسترسی مستقیم DB قابل خواندن بود (route/controller/view ادمین
 * وجود نداشت و getPendingMessages/markAsProcessed بی‌مصرف بودند).
 * گیت: contact_messages.view (RBAC — deny-by-default، الگوی BugReportController).
 */
class ContactController extends BaseAdminController
{
    // L-04: نقش support هم مجاز است؛ عملیات با authorizeById('contact_messages.view') ریزدانه محدود می‌شود.
    protected function enforceAdminAccess(): void
    {
        $this->requireAdminArea();
    }

    private ContactService $contactService;

    public function __construct(
        ContactService $contactService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->contactService = $contactService;
    }

    /**
     * صندوق پیام‌ها (لیست + فیلتر خوانده‌شده/نشده + صفحه‌بندی)
     */
    public function index(): string
    {
        $adminId = $this->requireAdminId();

        // 🛡️ CRIT-02: بررسی دسترسی مشاهده صندوق تماس
        if (!$this->policyService->authorizeById('contact_messages.view', $adminId)) {
            $this->session->setFlash('error', 'دسترسی غیرمجاز.');
            return redirect(url('/admin/dashboard'));
        }

        $page = max(1, $this->request->int('page', 1));
        $perPage = 20;

        $isRead = $this->request->get('is_read');
        $filter = null;
        if ($isRead === '0' || $isRead === '1') {
            $filter = ($isRead === '1');
        }

        $inbox = $this->contactService->getInbox($page, $perPage, $filter);
        $messages = $inbox['messages'];
        $total = $inbox['total'];
        $totalPages = (int)\ceil($total / $perPage);

        return view('admin.contact-messages.index', [
            'messages'   => $messages,
            'total'      => $total,
            'page'       => $page,
            'totalPages' => $totalPages,
            'is_read'    => $isRead,
        ]);
    }

    /**
     * مشاهدهٔ پیام (باز کردن = خوانده‌شده — پرچم is_read)
     */
    public function show(): string
    {
        $adminId = $this->requireAdminId();

        if (!$this->policyService->authorizeById('contact_messages.view', $adminId)) {
            $this->session->setFlash('error', 'دسترسی غیرمجاز.');
            return redirect(url('/admin/dashboard'));
        }

        $id = $this->request->int('id');

        $message = $this->contactService->getMessage($id);
        if (!$message) {
            $this->session->setFlash('error', 'پیام یافت نشد.');
            return redirect(url('/admin/contact-messages'));
        }

        // باز کردن پیام = علامت خوانده‌شده (markAsProcessed مدل — معادل schema واقعی)
        $this->contactService->markProcessed($id);

        return view('admin.contact-messages.show', [
            'message' => $message,
        ]);
    }
}
