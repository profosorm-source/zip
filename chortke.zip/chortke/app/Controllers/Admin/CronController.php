<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use Core\Scheduler;

/**
 * CronController — مدیریت Cron Jobs
 */
class CronController extends BaseAdminController
{
    private Scheduler $scheduler;

    public function __construct(Scheduler $scheduler, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->scheduler = $scheduler;
    }

    public function index(): void
    {
        $this->requirePermission('admin.view_cron_jobs');

        // R27-a: منطق اپ از ویو (views/admin/cron/index.php) به کنترلر منتقل شد —
        // ویو فقط رندر می‌کند و دادهٔ آمادهٔ نمایش ($jobs) دریافت می‌کند.

        // X130-fix (راند ۳۶): جدول قبلی لیست هاردکدِ کهنه بود — نام expire_ads اصلاً در Kernel
        // وجود نداشت و ستون «آخرین اجرا» از فایل‌های لاک قدیمی می‌خواند که هرگز ساخته نمی‌شوند
        // (همیشه «اجرا نشده» نمایش داده می‌شد). اکنون رجیستری واقعی Scheduler خوانده می‌شود
        // (فقط ثبت جاب‌ها؛ هیچ جابی اجرا نمی‌شود) و «آخرین اجرا» از منبع واقعی cron_last_run
        // می‌آید — دیگر با Kernel کدریفت نمی‌کند.
        // (همان الگوی Kernel::schedule که run() هم استفاده می‌کند؛ ثبت idempotent است.)
        \App\Console\Kernel::schedule($this->scheduler);
        $registryJobs = $this->scheduler->registeredJobs();
        $cacheForCron = \Core\Cache::getInstance();

        $intervalLabel = static function (int $sec): string {
            if ($sec < 60) { return 'هر ' . fa_number((string)$sec) . ' ثانیه'; }
            if ($sec === 60) { return 'هر دقیقه'; }
            if ($sec < 3600) { return 'هر ' . fa_number((string)intdiv($sec, 60)) . ' دقیقه'; }
            if ($sec === 3600) { return 'ساعتی'; }
            if ($sec < 86400) { return 'هر ' . fa_number((string)intdiv($sec, 3600)) . ' ساعت'; }
            if ($sec === 86400) { return 'روزانه'; }
            if ($sec === 604800) { return 'هفتگی'; }
            return 'دوره‌ای';
        };

        $jobDesc = [
            'email_queue' => 'پردازش صف ایمیل‌ها',
            'email_fallback_recovery' => 'بازیابی ارسال‌های fallback ایمیل',
            'system_queue_processor' => 'پردازش صف عمومی سیستم',
            'poison_message_smart_retry' => 'بازپخش هوشمند پیام‌های سمی',
            'crypto_verify' => 'تأیید خودکار واریز کریپتو',
            'payment_pending_verification_retry' => 'تأیید مجدد پرداخت‌های معلق درگاه',
            'alert_rule_engine' => 'پردازش قوانین هشدار (Sentry)',
            'system_monitoring_alert' => 'مانیتورینگ دیسک و حافظه',
            'cache_cleanup' => 'پاک‌سازی کش منقضی',
            'ad_notification_push' => 'اعلان‌های کمپین‌های فعال',
            'flush_banner_impressions' => 'تخلیه بافر بازدید بنرها',
            'ads_lifecycle_reconcile' => 'تسویه چرخهٔ عمر تبلیغات',
            'expire_banners' => 'انقضای بنرهای منقضی',
            'session_file_gc' => 'زباله‌روبی نشست فایلی',
            'expired_feature_flag_cleanup' => 'انقضای فیچر فلگ‌ها',
            'stale_search_cache_cleanup' => 'پاک‌سازی کش جستجو',
            'hourly_reconciliation_audit' => 'ممیزی ساعتی دفاتر مالی',
            'cleanup_sessions' => 'حذف نشست‌های قدیمی (۳۰ روز)',
            'cleanup_password_resets' => 'حذف توکن‌های بازیابی منقضی',
            'rotate_logs' => 'چرخش لاگ‌های اپلیکیشن',
            'websocket_cleanup' => 'پاک‌سازی پیام‌های realtime',
            'user_levels' => 'بررسی سطح کاربران',
            'cleanup_logs' => 'پاک‌سازی هفتگی لاگ‌ها (یکشنبه‌ها)',
            'financial_export_backup' => 'خروجی CSV مالی روزانه',
            'archive_audit_trail' => 'آرشیو ۳۰روزهٔ audit trail',
            'cleanup_sentry' => 'نگهداری هفتگی جدول‌های sentry',
            'log_growth_guard' => 'نگهبان رشد غیرعادی لاگ',
            'cleanup_email_queue' => 'حذف ایمیل‌های ارسال‌شدهٔ قدیمی',
            'cleanup_dead_letters' => 'پاک‌سازی صف‌های مرده',
            'scheduled_payments' => 'پرداخت‌های زمان‌بندی‌شدهٔ سررسیده',
            'cleanup_kyc_files' => 'حذف فایل‌های KYC رد شده (۶۰ روز)',
            'idempotency_cleanup' => 'حذف کلیدهای idempotency منقضی',
            'monthly_level_reset' => 'ریست ماهانهٔ آمار سطح (اول ماه)',
            'weekly_kpi_report' => 'گزارش هفتگی KPI به داشبورد ادمین',
            'investment_profit_distribution' => 'توزیع سود/ضرر سرمایه‌گذاری (هفتگی)',
            'social_task_trust_recovery' => 'بازیابی هفتگی امتیاز اعتماد تسک‌ها',
            'social_task_approval_reminder' => 'یادآوری روزانهٔ بررسی تسک‌ها',
            'social_task_expire_pending' => 'انقضای اجراهای معلق تسک اجتماعی',
            'influencer_buyer_check_timeout' => 'تأیید خودکار buyer-check منقضی',
            'influencer_expire_pending_acceptance' => 'رد خودکار سفارش‌های بی‌پاسخ',
            'influencer_escalate_peer_resolution' => 'ارجاع اختلاف‌های timeout شده',
            'influencer_cleanup_proof_files' => 'پاک‌سازی فایل‌های مدرک قدیمی',
            'process_scheduled_tasks' => 'حذف حساب منقضی + خروجی‌های تاریخ‌مصرف‌گذشته',
            'escrow_timeout_release' => 'آزادسازی اسکروهای منقضی',
            'withdrawal_stuck_timeout' => 'اسکن برداشت‌های گیر کرده',
            'kyc_timeout_reject' => 'رد خودکار KYCهای منقضی',
            'notification_cleanup' => 'پاک‌سازی اعلان‌های قدیمی',
            'vitrine_listing_expiry' => 'انقضای لیست‌های ویترین',
            'inactivity_score_decay' => 'ریزش امتیاز کاربران غایب',
            'prediction_game_settlement' => 'تسویه خودکار بازی‌های پیش‌بینی',
            'update_tor_exit_nodes' => 'به‌روزرسانی لیست Tor Exit Nodes',
            'notification_scheduled' => 'ارسال اعلان‌های زمان‌بندی‌شده',
            'notification_expire' => 'آرشیو اعلان‌های منقضی',
            'notification_analytics' => 'تجمیع آمار اعلان‌ها',
            'outbox_publisher' => 'انتشار رویدادهای Outbox',
            'database_maintenance' => 'نگهداری روزانهٔ دیتابیس',
            'dashboard_mv_refresh' => 'تازه‌سازی نماهای داشبورد',
            'queue_depth_monitor' => 'مانیتورینگ عمق صف‌ها',
        ];

        // ساخت دادهٔ آمادهٔ رندر برای هر جاب (برچسب دوره، توضیح، آخرین اجرا، وضعیت)
        $jobs = [];
        foreach ($registryJobs as $job) {
            $lastRun    = $cacheForCron->get('cron_last_run:' . md5($job['key']));
            $lastRunInt = $lastRun ? (int) $lastRun : 0;
            $lastRunStr = $lastRunInt > 0 ? to_jalali(date('Y-m-d H:i:s', $lastRunInt)) : 'هرگز';
            $isRecent   = $lastRunInt > 0 && (time() - $lastRunInt) < max(3600, $job['interval'] * 3);

            $jobs[] = [
                'name'          => (string) $job['name'],
                'intervalLabel' => $intervalLabel((int) $job['interval']),
                'description'   => (string) ($jobDesc[$job['name']] ?? ''),
                'lastRun'       => $lastRunStr,
                'status'        => $lastRunInt === 0 ? 'never' : ($isRecent ? 'recent' : 'stale'),
            ];
        }

        $this->view('admin/cron/index', [
            'title' => 'مدیریت Cron Jobs',
            'jobs'  => $jobs,
        ]);
    }

    /**
     * اجرای دستی جاب‌ها
     * ⚠️ توجه: این متد باید فقط تحت شرایط خاص و با مجوز بالا اجرا شود.
     */
    public function run(): void
    {
        $this->requirePermission('admin.execute_cron_jobs');

        if (!$this->request->isPost()) {
            $this->jsonError('متد نامعتبر است', [], 405);
        }

        try {
            $this->logger->info('admin.cron_manual_trigger', [
                'admin_id' => (int)$this->userId(),
                'ip' => $this->request->ip()
            ]);

            // پشتیبانی از اجرای یک جاب خاص اگر ارسال شده باشد
            // 🛡️ FIX-X132 (راند 37): قبلاً فقط request->get('job') خوانده می‌شد که
            // فقط query string را می‌بیند — ولی دکمهٔ «اجرای تکی» پنل مقدار را در
            // بدنهٔ JSON می‌فرستد → نام جاب همیشه خالی بود و «همهٔ جاب‌ها» اجرا می‌شد.
            // اکنون بدنه (JSON/Form) و سپس query خوانده می‌شود.
            $jobName = $this->request->post('job') ?: $this->request->get('job');

            // 🛡️ FIX-X132b (راند 37 — ریشهٔ عمیق‌تر): اینستنس Scheduler تزریق‌شده به
            // کنترلر وب خالی است — جاب‌ها در بوت CLI (cron.php) رجیستر می‌شوند.
            // ویوی پنل از همین الگوی Kernel::schedule برای نمایش رجیستری زنده استفاده
            // می‌کند؛ اجرای تکی/همه نیز باید از رجیستری واقعی پر شود وگرنه
            // «Cron job not found» (۵۰۰) می‌دهد. رجیستر اینجا idempotent است
            // (درخواست تازه = اینستنس تازه) و با FIX-X147 جاب‌های daily/weekly
            // نیز همیشه رجیستر شده و قابل اجرای دستی‌اند.
            \App\Console\Kernel::schedule($this->scheduler);

            // استفاده از Scheduler برای اجرای جاب‌ها به صورت امن
            $results = [];
            if ($jobName) {
                // اجرای یک جاب خاص
                $jobResult = $this->scheduler->executeJobByName(str_value($jobName));
                // 🛡️ FIX-X164b (راند 40): شکل پاسخِ اجرای تکی با «اجرای همه» یکسان شد —
                // executeJobByName خروجی خام جاب را برمی‌گرداند ({downgraded:…}) بدون
                // پوشهٔ {status,output}؛ پنل خروجیِ status-less را «undefined» نشان می‌داد.
                $results[$jobName] = (is_array($jobResult) && isset($jobResult['status']))
                    ? $jobResult
                    : ['status' => 'ok', 'output' => $jobResult];
            } else {
                // اجرای تمام جاب‌های در انتظار
                $results = $this->scheduler->run();
            }

            // هندل کردن وضعیت skipped یا خطا
            if (empty($results)) {
                 $results = ['system' => ['status' => 'skipped', 'reason' => 'no_jobs_to_execute']];
            }
            
            $this->jsonSuccess('Cron jobs executed successfully', [
                'results' => $results,
                'executed_at' => date('Y-m-d H:i:s')
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) {
            // FIX-R36-W3 (F-A15-06): پیام خام استثنا (PDO/stack-ish) به JSON ادمین
            // درز می‌کرد (خانوادهٔ F-A3-07). پیام کامل سمت سرور لاگ می‌شود + شناسهٔ
            // همبستگی تا ادمین بتواند خطا را به رکورد لاگ ربط دهد؛ پاسخ = پیام عمومی.
            $correlationId = 'cron_' . bin2hex(random_bytes(4));
            $this->logger->error('admin.cron_execution_failed', [
                'correlation_id' => $correlationId,
                'error' => $e->getMessage(),
                'exception' => get_class($e),
                'admin_id' => (int)$this->userId()
            ]);
            $this->jsonError('خطا در اجرای جاب‌ها. شناسهٔ رخداد برای پیگیری: ' . $correlationId, [], 500);
        }
    }
}