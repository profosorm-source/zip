<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use Core\Scheduler;

/**
 * CronController — مدیریت Cron Jobs
 */
class CronController extends BaseAdminController
{
    private Scheduler $scheduler;

    public function __construct(Scheduler $scheduler, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->scheduler = $scheduler;
    }

    public function index(): void
    {
        $this->requirePermission('admin.view_cron_jobs');
        $this->view('admin/cron/index', ['title' => 'مدیریت Cron Jobs']);
    }

    /**
     * اجرای دستی جاب‌ها
     * ⚠️ توجه: این متد باید فقط تحت شرایط خاص و با مجوز بالا اجرا شود.
     */
    public function run(): void
    {
        $this->requirePermission('admin.execute_cron_jobs');

        if (!$this->request->isPost()) {
            $this->jsonError('متد نامعتبر است', [], 405);
        }

        try {
            $this->logger->info('admin.cron_manual_trigger', [
                'admin_id' => (int)$this->userId(),
                'ip' => $this->request->ip()
            ]);

            // پشتیبانی از اجرای یک جاب خاص اگر ارسال شده باشد
            // 🛡️ FIX-X132 (راند 37): قبلاً فقط request->get('job') خوانده می‌شد که
            // فقط query string را می‌بیند — ولی دکمهٔ «اجرای تکی» پنل مقدار را در
            // بدنهٔ JSON می‌فرستد → نام جاب همیشه خالی بود و «همهٔ جاب‌ها» اجرا می‌شد.
            // اکنون بدنه (JSON/Form) و سپس query خوانده می‌شود.
            $jobName = $this->request->post('job') ?: $this->request->get('job');

            // 🛡️ FIX-X132b (راند 37 — ریشهٔ عمیق‌تر): اینستنس Scheduler تزریق‌شده به
            // کنترلر وب خالی است — جاب‌ها در بوت CLI (cron.php) رجیستر می‌شوند.
            // ویوی پنل از همین الگوی Kernel::schedule برای نمایش رجیستری زنده استفاده
            // می‌کند؛ اجرای تکی/همه نیز باید از رجیستری واقعی پر شود وگرنه
            // «Cron job not found» (۵۰۰) می‌دهد. رجیستر اینجا idempotent است
            // (درخواست تازه = اینستنس تازه) و با FIX-X147 جاب‌های daily/weekly
            // نیز همیشه رجیستر شده و قابل اجرای دستی‌اند.
            \App\Console\Kernel::schedule($this->scheduler);

            // استفاده از Scheduler برای اجرای جاب‌ها به صورت امن
            $results = [];
            if ($jobName) {
                // اجرای یک جاب خاص
                $jobResult = $this->scheduler->executeJobByName(str_value($jobName));
                // 🛡️ FIX-X164b (راند 40): شکل پاسخِ اجرای تکی با «اجرای همه» یکسان شد —
                // executeJobByName خروجی خام جاب را برمی‌گرداند ({downgraded:…}) بدون
                // پوشهٔ {status,output}؛ پنل خروجیِ status-less را «undefined» نشان می‌داد.
                $results[$jobName] = (is_array($jobResult) && isset($jobResult['status']))
                    ? $jobResult
                    : ['status' => 'ok', 'output' => $jobResult];
            } else {
                // اجرای تمام جاب‌های در انتظار
                $results = $this->scheduler->run();
            }

            // هندل کردن وضعیت skipped یا خطا
            if (empty($results)) {
                 $results = ['system' => ['status' => 'skipped', 'reason' => 'no_jobs_to_execute']];
            }
            
            $this->jsonSuccess('Cron jobs executed successfully', [
                'results' => $results,
                'executed_at' => date('Y-m-d H:i:s')
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) {
            $this->logger->error('admin.cron_execution_failed', [
                'error' => $e->getMessage(),
                'admin_id' => (int)$this->userId()
            ]);
            $this->jsonError('خطا در اجرای جاب‌ها: ' . $e->getMessage(), [], 500);
        }
    }
}