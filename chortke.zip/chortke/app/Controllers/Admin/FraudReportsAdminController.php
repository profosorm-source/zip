<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Models\FraudReport;

/**
 * FraudReportsAdminController — صف بررسی گزارش‌های تخلف (X372، راند ۹۳)
 *
 * ─── مسیرها (routes/admin.php، گروه $admin مثل همسایه‌های fraud) ──
 *   GET  /admin/fraud/reports              → index
 *   POST /admin/fraud/reports/{id}/review  → review
 *   POST /admin/fraud/reports/{id}/dismiss → dismiss
 *
 * سبک خانه: همسایه‌ها (FraudManagementController) چکِ مجوزِ درون‌کنترلری ندارند و
 * روی AdminPermissionGuard تکیه می‌کنند؛ اینجا علاوه بر گارد میان‌افزار،
 * requirePermission ریزدانه (fraud.view / fraud.manage — همان کلیدهای همسایه)
 * به‌عنوان دفاع در عمق چک می‌شود. توجه: نگاشت Controller→permission در
 * config/admin_permissions.php خارج از مالکیت راند ۹۳-ب است؛ تا افزودن نگاشت،
 * گاردِ deny-by-default فقط super_admin را عبور می‌دهد (fail-closed).
 */
class FraudReportsAdminController extends BaseAdminController
{
    private FraudReport $fraudReport;

    /** 🛡️ X376 (راند ۹۸): تزریق اختیاری (الگوی خانه r88/r90) — منبع سیگنال حکم ادمین */
    private ?\App\Services\User\UserService $userService;

    public function __construct(
        FraudReport $fraudReport,
        ?\App\Services\User\UserService $userService = null,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->fraudReport = $fraudReport;
        $this->userService = $userService;
    }

    public function index(): string
    {
        $this->requirePermission('fraud.view');

        $page    = max(1, $this->request->int('page', 1));
        $perPage = 20;
        $status  = (string)$this->request->str('status', FraudReport::STATUS_PENDING);

        // فیلتر وضعیت فقط از لیست مجاز (+ all)
        $allowedStatuses = [
            FraudReport::STATUS_PENDING,
            FraudReport::STATUS_REVIEWED,
            FraudReport::STATUS_DISMISSED,
            'all',
        ];
        if (!in_array($status, $allowedStatuses, true)) {
            $status = FraudReport::STATUS_PENDING;
        }

        $result = $this->fraudReport->paginateReports(
            $page,
            $perPage,
            $status === 'all' ? null : $status
        );

        return view('admin/fraud/reports', [
            'reports'   => $result['items'],
            'total'     => $result['total'],
            'page'      => $result['page'],
            'perPage'   => $result['per_page'],
            'totalPages' => $result['last_page'],
            'status'    => $status,
            'counts'    => $this->fraudReport->monthlyStats(),
            'reasons'   => FraudReport::REASONS,
        ]);
    }

    public function review(int $id): void
    {
        $this->resolve($id, FraudReport::STATUS_REVIEWED);
    }

    public function dismiss(int $id): void
    {
        $this->resolve($id, FraudReport::STATUS_DISMISSED);
    }

    /**
     * هستهٔ مشترک گذار وضعیت: CSRF/مجوز → گذار → حسابرسی → فلش → بازگشت به صف.
     */
    private function resolve(int $id, string $status): void
    {
        $this->requirePermission('fraud.manage');

        if ($id <= 0) {
            $this->session->setFlash('error', 'شناسهٔ گزارش نامعتبر است.');
            $this->response->redirect(url('/admin/fraud/reports'));
            return;
        }

        // یادداشت اختیاری ادمین (VARCHAR(1000) — برشِ محافظتی)
        $noteRaw = trim(str_value($this->request->input('admin_note', '')));
        $note    = $noteRaw !== '' ? mb_substr($noteRaw, 0, 1000) : null;

        $adminId = $this->requireAdminId();

        $ok = $status === FraudReport::STATUS_REVIEWED
            ? $this->fraudReport->review($id, $adminId, $note)
            : $this->fraudReport->dismiss($id, $adminId, $note);

        if ($ok) {
            // 🛡️ X376 (راند ۹۸): تأییدِ گزارش (pending→reviewed) = حکم ادمین؛
            // رویداد لجر fraud_report_confirmed برای کاربرِ گزارش‌شده شلیک می‌شود
            // (موتور ضد-فارمینگ — RiskDecisionService از پروجکشن می‌خواند).
            // dismiss هیچ دلتایی نمی‌گیرد (تصمیم مستند در UserService).
            // شکست سیگنال جریان ادمین را نمی‌شکند اما بلند لاگ + سنت‌ری + فلش صادق.
            $signalOutcome = 'skipped';
            if ($status === FraudReport::STATUS_REVIEWED) {
                $signalOutcome = $this->fireFraudReportSignal($id, $adminId);
            }

            // 🛡️ X381 (راند ۱۰۱): بستن حلقهٔ بازخورد به گزارش‌دهنده — هر دو حکم
            // (تأیید/رد) اعلان درون‌اپ می‌گیرد؛ غیرمسدودکننده (شکست اعلان حکم
            // را نمی‌شکند) و هرگز به گزارش‌دهنده هویت/یادداشت ادمین افشا نمی‌شود.
            $notifyOutcome = $this->notifyReporter($id, $status);

            $this->auditLog(
                $status === FraudReport::STATUS_REVIEWED ? 'fraud_report_reviewed' : 'fraud_report_dismissed',
                'fraud_report',
                $id,
                ['status' => FraudReport::STATUS_PENDING],
                ['status' => $status, 'admin_note' => $note, 'fraud_signal' => $signalOutcome, 'reporter_notified' => $notifyOutcome]
            );
            $this->session->setFlash(
                $signalOutcome === 'failed' ? 'error' : 'success',
                $status === FraudReport::STATUS_REVIEWED
                    ? ($signalOutcome === 'failed'
                        ? 'گزارش بررسی شد اما ثبت سیگنال ضد-فارمینگ ناموفق بود — لاگ ادمین را ببینید.'
                        : 'گزارش بررسی شد.')
                    : 'گزارش رد شد.'
            );
            $this->logger->info('fraud_report.resolved', [
                'report_id'    => $id,
                'admin_id'     => $adminId,
                'status'       => $status,
                'fraud_signal' => $signalOutcome,
                'reporter_notified' => $notifyOutcome,
            ]);
        } else {
            // با گارد X376 این شاخه هم «یافت نشد» و هم «قبلاً حل‌شده» را پوشش می‌دهد
            // (گذار مجدد روی ردیف حل‌شده دیگر true دروغین برنمی‌گرداند).
            $this->session->setFlash('error', 'گزارش یافت نشد یا قبلاً بررسی شده است.');
        }

        $this->response->redirect(url('/admin/fraud/reports'));
    }

    /**
     * 🛡️ X376: شلیک سیگنال لجری حکم ادمین — پس از گذار موفقِ review.
     * خروجی: applied | skipped (سیگنال/مدل در دسترس نیست) | failed (استثنا).
     */
    private function fireFraudReportSignal(int $id, int $adminId): string
    {
        try {
            $report = $this->fraudReport->findById($id);
            if ($report === null) {
                return 'failed';
            }
            $svc = $this->userService ?? app(\App\Services\User\UserService::class);
            return $svc->confirmFraudReportScore(
                int_value($report->reported_user_id),
                $id,
                $adminId,
                str_value($report->reason)
            ) ? 'applied' : 'failed';
        } catch (\Throwable $e) {
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'admin.fraud_report.fraud_signal',
                'report_id' => $id,
                'admin_id'  => $adminId,
            ]);
            $this->logger->error('fraud_report.signal_failed', [
                'report_id' => $id,
                'admin_id'  => $adminId,
                'error'     => $e->getMessage(),
            ]);
            return 'failed';
        }
    }

    /**
     * 🛡️ X381 (راند ۱۰۱): بستن حلقهٔ بازخورد — گزارش‌دهنده نتیجهٔ حکم را می‌شنود.
     *
     * چرا؟ تا راند ۱۰۰ گزارندهٔ گزارش هیچ سیگنالی از سرنوشت گزارشش نمی‌گرفت
     * (فلاش فقط برای ادمین بود) → یا بدبینی («گزارش‌ها می‌روند توی هوا») یا
     * اسپم مجدد برای همان مورد. اکنون هر دو حکم اعلان درون‌اپ می‌سازد.
     *
     * قراردادها:
     *  - غیرمسدودکننده: هر شکست فقط لاگ است؛ جریان حکم ادمین هرگز نمی‌شکند.
     *  - بدون افشا: متن اعلان هرگز نام کاربرِ گزارش‌شده، یادداشت ادمین یا
     *    وزن دلتا را حمل نمی‌کند (حریم افراد ثالث + جلوگیری از دستورالعملِ
     *    «چقدر مانده تا بلوک» برای بازیگر بد).
     *  - نوع اعلان referral (خانوادهٔ هاب رفرال — محل ثبت گزارش).
     *
     * @return string 'sent' | 'failed' | 'skipped' (گزارش یافت نشد)
     */
    private function notifyReporter(int $reportId, string $status): string
    {
        try {
            $report = $this->fraudReport->findById($reportId);
            if ($report === null || int_value($report->reporter_id ?? 0) <= 0) { // 🛡️ FIX-PS-C2
                return 'skipped';
            }

            $reviewed = $status === FraudReport::STATUS_REVIEWED;
            $title    = 'گزارش شما بررسی شد';
            $message  = $reviewed
                ? 'گزارش تخلف شما تأیید شد و اقدام لازم انجام می‌شود. از دقت شما سپاسگزاریم.'
                : 'گزارش شما بررسی شد؛ مطابق ارزیابی تیم پشتیبانی تخلفی احراز نشد. گزارش‌های بعدی شما همچنان ارزشمند است.';

            $svc = app(\App\Services\Notification\NotificationService::class);
            $svc->send(
                int_value($report->reporter_id), // 🛡️ FIX-PS-C2
                \App\Models\Notification::TYPE_REFERRAL,
                $title,
                $message,
                ['report_id' => $reportId, 'outcome' => $reviewed ? 'confirmed' : 'dismissed'],
                url('/referral')
            );
            return 'sent';
        } catch (\Throwable $e) {
            // بازخورد، حکم نیست — شکستش فقط لاگ؛ بدون سنت‌ری (نویز گیت X378)
            $this->logger->error('fraud_report.reporter_notify_failed', [
                'report_id' => $reportId,
                'status'    => $status,
                'error'     => $e->getMessage(),
            ]);
            return 'failed';
        }
    }
}
