<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Models\Dispute;
use App\Models\InfluencerModel;
use App\Models\StoryOrder;
use App\Services\AuditTrail;
use App\Services\InfluencerService;
use App\Services\Search\SearchOrchestrator;
use App\Services\Shared\DisputeService;
use App\Services\VerificationService;

class InfluencerController extends BaseAdminController
{
    private InfluencerModel $profileModel;
    private StoryOrder $orderModel;
    private Dispute $disputeModel;
    private DisputeService $disputeService;
    private VerificationService $verificationService;
    // 🧹 DI-CLEANUP (2026-08-24): پراپرتی $auditTrail ارثبرده از BaseAdminController (با #[Inject]) است.

    public function __construct(
        InfluencerModel $profileModel,
        StoryOrder $orderModel,
        Dispute $disputeModel,
        DisputeService $disputeService,
        VerificationService $verificationService,
        AuditTrail $auditTrail,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->profileModel = $profileModel;
        $this->orderModel = $orderModel;
        $this->disputeModel = $disputeModel;
        $this->disputeService = $disputeService;
        $this->verificationService = $verificationService;
        $this->auditTrail = $auditTrail;
    }

    public function orders(): void
    {
        $search = trim($this->request->str('search'));
        $filters = [
            'status' => $this->request->get('status'),
            'order_type' => $this->request->get('order_type'),
            'search' => $search,
        ];
        $page = max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;
        $orders = $this->orderModel->adminList($filters, $limit, $offset);
        $total = $this->orderModel->adminCount($filters);
        $stats = $this->orderModel->globalStats();

        view('admin.influencer.orders', [
            'orders' => $orders,
            'total' => $total,
            'page' => $page,
            'pages' => (int)ceil($total / $limit),
            'filters' => $filters,
            'search' => $search,
            'stats' => $stats,
            'statusLabels' => $this->orderModel->statusLabels(),
            'statusClasses' => $this->orderModel->statusClasses(),
        ]);
    }

    public function profiles(): void
    {
        $search = trim($this->request->str('search'));
        $filters = [
            'status' => $this->request->get('status'),
            'search' => $search,
        ];
        $page = max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;
        $profiles = $this->profileModel->adminListProfiles($filters, $limit, $offset);
        $total = $this->profileModel->adminCountProfiles($filters);

        view('admin.influencer.profiles', [
            'profiles' => $profiles,
            'total' => $total,
            'page' => $page,
            'pages' => (int)ceil($total / $limit),
            'filters' => $filters,
            'search' => $search,
            'statusLabels' => $this->profileModel->profileStatusLabels(),
        ]);
    }

    public function approveProfile(): void
    {
        $decodedBody = json_decode((file_get_contents('php://input') ?: ''), true);
        $body = is_array($decodedBody) ? $decodedBody : [];

        // 📜 قرارداد واحد ورودی: FormRequest به‌جای بررسی‌های دستی پراکنده.
        $request = new \App\Validators\Requests\ApproveInfluencerProfileRequest($body);
        if (!$request->validate()) {
            $this->response->json([
                'success' => false,
                'message' => $this->firstValidationError($request->errors()),
                'errors' => $request->errors(),
            ], 422);
            return;
        }
        $validated = $request->validated();
        $profileId = int_value($validated['profile_id'] ?? 0);
        $decision = str_value($validated['decision'] ?? '');
        $reason = trim(str_value($validated['reason'] ?? ''));

        $profile = $this->profileModel->find($profileId);
        if (!$profile) {
            $this->response->json(['success' => false, 'message' => 'پروفایل یافت نشد.'], 404);
            return;
        }

        $adminId = (int)$this->userId();
        $verification = ($profile->status === 'pending_admin_review')
            ? $this->verificationService->getPendingVerificationByProfile($profileId)
            : null;

        if ($decision === 'approve') {
            if ($verification) {
                $result = $this->verificationService->approveVerification((int)$verification->id, $adminId);
                $this->response->json(['success' => !empty($result['ok']), 'message' => $result['message'] ?? ($result['error'] ?? '')], !empty($result['ok']) ? 200 : 422);
                return;
            }
            $this->profileModel->update($profileId, ['status' => 'verified', 'verified_by' => $adminId, 'verified_at' => date('Y-m-d H:i:s'), 'is_active' => 1]);
            $this->auditTrail->record('influencer.profile.approved', (int)$profile->user_id, ['channel' => 'influencer', 'profile_id' => $profileId, 'username' => $profile->username], $adminId);
            $this->response->json(['success' => true, 'message' => 'پیج تأیید شد.']);
            return;
        }

        if ($decision === 'reject') {
            if ($verification) {
                $result = $this->verificationService->rejectVerification((int)$verification->id, $adminId, e($reason, ENT_QUOTES, 'UTF-8'));
                $this->response->json(['success' => !empty($result['ok']), 'message' => $result['message'] ?? ($result['error'] ?? '')], !empty($result['ok']) ? 200 : 422);
                return;
            }
            $this->profileModel->update($profileId, ['status' => 'rejected', 'rejection_reason' => e($reason, ENT_QUOTES, 'UTF-8')]);
            $this->auditTrail->record('influencer.profile.rejected', (int)$profile->user_id, ['channel' => 'influencer', 'profile_id' => $profileId, 'username' => $profile->username, 'reason' => $reason], $adminId);
            $this->response->json(['success' => true, 'message' => 'پیج رد شد.']);
            return;
        }

        $this->profileModel->update($profileId, ['status' => 'suspended', 'is_active' => 0, 'suspended_at' => date('Y-m-d H:i:s'), 'suspended_reason' => e($reason, ENT_QUOTES, 'UTF-8')]);
        $this->auditTrail->record('influencer.profile.suspended', (int)$profile->user_id, ['channel' => 'influencer', 'profile_id' => $profileId, 'username' => $profile->username, 'reason' => $reason], $adminId);
        $this->response->json(['success' => true, 'message' => 'پیج تعلیق شد.']);
    }

    public function disputes(): void
    {
        $filters = [
            'status' => $this->request->get('status'),
            'search' => $this->request->get('search'),
            'ref_type' => ['influencer_order', 'story_order', 'order', 'influencer'],
        ];
        $page = max(1, $this->request->int('page', 1));
        $limit = min(100, max(1, $this->request->int('limit', 30)));
        $offset = ($page - 1) * $limit;

        $disputes = $this->disputeModel->adminList($filters, $limit, $offset);
        $total = $this->disputeModel->adminCount($filters);

        view('admin.influencer.disputes', [
            'disputes' => $disputes,
            'total' => $total,
            'page' => $page,
            'pages' => max(1, (int)ceil($total / $limit)),
            'filters' => $filters,
            'statusLabels' => [
                'open' => 'باز',
                'open_peer' => 'گفت‌وگوی طرفین',
                'escalated' => 'ارجاع به مدیر',
                'resolved_peer' => 'حل دوستانه',
                'resolved_admin' => 'حل توسط مدیر',
                'closed' => 'بسته',
            ],
        ]);
    }

    public function disputeDetail(): void
    {
        $disputeId = (int)$this->request->param('id');
        $dispute = $this->disputeModel->find($disputeId);
        if (!$dispute) {
            $this->session->setFlash('error', 'اختلاف یافت نشد.');
            redirect(url('/admin/influencer/disputes'));
        }
        $messages = $this->disputeModel->getMessages($disputeId);
        $order = $this->orderModel->find((int)($dispute->ref_id ?? $dispute->order_id ?? 0));

        view('admin.influencer.dispute-detail', ['dispute' => $dispute, 'messages' => $messages, 'order' => $order]);
    }

    public function resolveDispute(): void
    {
        $decodedBody = json_decode((file_get_contents('php://input') ?: ''), true);
        $body = is_array($decodedBody) ? $decodedBody : [];
        // fallback به پارامتر مسیر (رفتار قبلی حفظ شده)
        if (empty($body['dispute_id'])) {
            $body['dispute_id'] = $this->request->param('id') ?? 0;
        }

        $request = new \App\Validators\Requests\ResolveInfluencerDisputeRequest($body);
        if (!$request->validate()) {
            $this->response->json([
                'success' => false,
                'message' => $this->firstValidationError($request->errors()),
                'errors' => $request->errors(),
            ], 422);
            return;
        }
        $validated = $request->validated();
        $disputeId = int_value($validated['dispute_id'] ?? 0);
        $verdict = str_value($validated['verdict'] ?? '');
        $note = trim(str_value($validated['note'] ?? ''));
        $refundPercent = is_scalar($validated['refund_percent'] ?? null) ? str_value($validated['refund_percent']) : '0';
        if ($refundPercent === '' || !is_numeric($refundPercent)) {
            $refundPercent = '0';
        }

        $result = $this->disputeService->adminResolve($disputeId, (int)$this->userId(), $verdict, e($note, ENT_QUOTES, 'UTF-8'), $refundPercent);
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    public function verificationRequests(): void
    {
        $page = max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;
        $requests = $this->verificationService->getVerificationRequests($limit, $offset);
        $total = $this->verificationService->countVerificationRequests();
        view('admin.influencer.verifications', ['requests' => $requests, 'page' => $page, 'pages' => (int)ceil($total / $limit), 'total' => $total]);
    }

    public function approveVerification(): void
    {
        $decodedBody = json_decode((file_get_contents('php://input') ?: ''), true);
        $body = is_array($decodedBody) ? $decodedBody : [];

        $request = new \App\Validators\Requests\ApproveInfluencerVerificationRequest($body);
        if (!$request->validate()) {
            $this->response->json([
                'success' => false,
                'message' => $this->firstValidationError($request->errors()),
                'errors' => $request->errors(),
            ], 422);
            return;
        }
        $verificationId = int_value($request->validated()['verification_id'] ?? 0);
        $result = $this->verificationService->approveVerification($verificationId, (int)$this->userId());
        $this->response->json(['success' => !empty($result['ok']), 'message' => $result['message'] ?? ($result['error'] ?? '')], !empty($result['ok']) ? 200 : 422);
    }

    public function rejectVerification(): void
    {
        $decodedBody = json_decode((file_get_contents('php://input') ?: ''), true);
        $body = is_array($decodedBody) ? $decodedBody : [];

        $request = new \App\Validators\Requests\RejectInfluencerVerificationRequest($body);
        if (!$request->validate()) {
            $this->response->json([
                'success' => false,
                'message' => $this->firstValidationError($request->errors()),
                'errors' => $request->errors(),
            ], 422);
            return;
        }
        $validated = $request->validated();
        $verificationId = int_value($validated['verification_id'] ?? 0);
        $reason = trim(str_value($validated['reason'] ?? ''));
        $result = $this->verificationService->rejectVerification($verificationId, (int)$this->userId(), e($reason, ENT_QUOTES, 'UTF-8'));
        $this->response->json(['success' => !empty($result['ok']), 'message' => $result['message'] ?? ($result['error'] ?? '')], !empty($result['ok']) ? 200 : 422);
    }

    /**
     * اولین پیام خطای اعتبارسنجی برای فیلد message پاسخ.
     * @param array<string, mixed> $errors
     */
    private function firstValidationError(array $errors): string
    {
        $firstValue = reset($errors);
        $firstError = is_array($firstValue) ? reset($firstValue) : $firstValue;
        return is_string($firstError) && $firstError !== '' ? $firstError : 'اطلاعات ورودی نامعتبر است';
    }
}
