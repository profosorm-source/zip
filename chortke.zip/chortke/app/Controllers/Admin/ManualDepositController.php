<?php

namespace App\Controllers\Admin;
use App\Models\BankCard;
use App\Services\User\UserService;

use App\Models\ManualDeposit;
use App\Contracts\WalletServiceInterface;
use App\Controllers\Admin\BaseAdminController;
use App\Services\ManualDepositService;
use Core\Logger;

class ManualDepositController extends BaseAdminController
{
    protected UserService $userService;
    // $userService inherited from parent
        private ManualDepositService $manualDepositService;

    public function __construct(
    UserService $userService,
    ManualDepositService $manualDepositService,
    Logger $logger
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->userService = $userService;
        $this->manualDepositService = $manualDepositService;
}

    /**
     * لیست واریزهای دستی در انتظار
     */
    public function index(): void
    {
                
        $page = max(1, $this->request->int('page', 1));
        $status = $this->request->str('status', '');
        $limit = 20;
        $offset = ($page - 1) * $limit;

        try {
            if ($status) {
                $result = $this->manualDepositService->listByStatus($status, $limit, $offset);
            } else {
                $result = $this->manualDepositService->listPending($limit, $offset);
            }
            // FIX(bug#10): سرویس فهرست سادهٔ رکوردها برمی‌گرداند (list<stdClass>)؛
            // کلیدهای 'deposits' و 'total' هرگز وجود نداشتند. 🛡️ FIX-PS-C2: مستقیم از
            // خودِ لیست — بدون شاخهٔ مردهٔ isset تا تایپ ردیف‌ها حفظ شود.
            $deposits = is_array($result) ? $result : [];
            $total = count($deposits);

            // FIX-X117: مصرف بوست واریز دستی — واریزی‌های «بوست‌دارِ در انتظار» به صدر صف
            [$deposits, $boostedUserIds] = boost_queue_order($deposits, 'deposit', 'user_id', 'status', ['pending', 'under_review']);

            // FIX-X183 (راند ۴۷): وعدهٔ SLA هر ردیف (الگوی KYCController/X165) + شمارندهٔ صف.
            // pending → ⏳ باقی‌ماندهٔ وعده | approved/rejected → زمان واقعی پاسخ
            // (COALESCE(reviewed_at, approved_at) − sla_promised_at).
            $nowTs = time();
            foreach ($deposits as $row) {
                $pm = (int)($row->sla_promised_minutes ?? 0);
                $row->sla_remaining_minutes = null;
                $row->sla_breached = false;
                $row->sla_response_minutes = null;
                if ($pm > 0 && !empty($row->sla_promised_at)) {
                    $st = (string)($row->status ?? '');
                    if ($st === 'pending') {
                        $remain = (int)\ceil((\strtotime($row->sla_promised_at) + $pm * 60 - $nowTs) / 60);
                        $row->sla_remaining_minutes = $remain;
                        $row->sla_breached = $remain < 0;
                    } elseif (in_array($st, ['approved', 'rejected'], true)) {
                        $resolvedAt = !empty($row->reviewed_at) ? $row->reviewed_at : ($row->approved_at ?? null);
                        if (!empty($resolvedAt)) {
                            $row->sla_response_minutes = (int)\ceil((\strtotime($resolvedAt) - \strtotime($row->sla_promised_at)) / 60);
                        }
                    }
                }
            }

            try {
                $slaCounters = $this->manualDepositService->getSlaCounters();
            } catch (\Throwable $e) {
                $this->logger->warning('admin.manual_deposits.sla_counters.failed', ['error' => $e->getMessage()]);
                $slaCounters = ['promised' => 0, 'breached' => 0];
            }

            $totalPages = (int)\ceil($total / $limit);

            view('admin.manual-deposits.index', [
                'deposits' => $deposits,
                'currentPage' => $page,
                'totalPages' => $totalPages,
                'total' => $total,
                'status' => $status,
                'boostedUserIds' => $boostedUserIds, // FIX-X117
                'slaCounters' => $slaCounters, // FIX-X183
                'pageTitle' => 'واریزهای دستی'
            ]);

        } catch (\Exception $e) {
    $this->logger->error('admin.manual_deposits.index.failed', [
        'channel' => 'admin',
        'error' => $e->getMessage(),
        'exception' => get_class($e),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
    ]);

            $this->session->setFlash('error', 'خطا در دریافت لیست');
            redirect('/admin/dashboard');
        }
    }

    /**
     * صفحه بررسی واریز دستی
     */
    public function review(): void
    {
                $depositId = $this->request->int('id');

        try {
            $deposit = $this->manualDepositService->getDeposit($depositId);

            if (!$deposit) {
                $this->session->setFlash('error', 'واریز یافت نشد');
                redirect('/admin/manual-deposits');
            }

            // دریافت اطلاعات کاربر
            $user = $this->userService->find($deposit->user_id);

            // دریافت اطلاعات کارت
            $card = $this->manualDepositService->getCard($deposit->card_id);
            if ($card && !empty($card->card_number)) {
                // ماسک امن به‌جای مقدار رمزنگاری‌شدهٔ خام
                $card->card_number_masked = $this->manualDepositService->maskCardNumber(
                    (string)$card->card_number,
                    (int)$deposit->id
                );
            }

            view('admin.manual-deposits.review', [
                'deposit' => $deposit,
                'user' => $user,
                'card' => $card,
                'pageTitle' => 'بررسی واریز دستی'
            ]);

        } catch (\Exception $e) {
    $this->logger->error('admin.manual_deposit.review.failed', [
        'channel' => 'admin',
        'deposit_id' => $depositId,
        'error' => $e->getMessage(),
        'exception' => get_class($e),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
    ]);

            $this->session->setFlash('error', 'خطا در دریافت اطلاعات');
            redirect('/admin/manual-deposits');
        }
    }

   /**
 * تأیید واریز دستی
 */
public function verify(): void
{
    $depositId = 0;
    try {
        $adminId = (int) user_id();

        $depositId = $this->request->int('deposit_id');
        if ($depositId <= 0) {
            $this->response->json([
                'success' => false,
                'message' => 'شناسه واریز نامعتبر است'
            ], 422);
            return;
        }

        $note = $this->request->str('admin_note');

        $result = $this->manualDepositService->approve($adminId, $depositId, $note);

        $this->response->json([
            'success' => (bool)$result,
            'message' => $result ? 'واریز با موفقیت تایید شد' : 'خطا در تایید واریز'
        ], $result ? 200 : 422);
        return;
    } catch (\Core\Exceptions\HttpResponseException $e) {
        throw $e;
    } catch (\Throwable $e) {
        $this->logger->error('admin.manual_deposit.verify.failed', [
            'channel' => 'admin',
            'admin_id' => user_id(),
            'deposit_id' => $depositId,
            'error' => $e->getMessage(),
            'exception' => get_class($e),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);

        $this->response->json([
            'success' => false,
            'message' => 'خطای سرور در تایید واریز'
        ], 500);
    }
}

    /**
     * رد واریز دستی
     */
   public function reject(): void
{
    $depositId = 0;
    try {
        $adminId = (int) user_id();

        $depositId = $this->request->int('deposit_id');
        $reason = trim($this->request->str('rejection_reason'));

        if ($depositId <= 0) {
            $this->response->json([
                'success' => false,
                'message' => 'شناسه واریز نامعتبر است'
            ], 422);
            return;
        }

        if ($reason === '') {
            $this->response->json([
                'success' => false,
                'message' => 'دلیل رد الزامی است'
            ], 422);
            return;
        }

        $result = $this->manualDepositService->reject($adminId, $depositId, $reason);

        $this->response->json([
            'success' => (bool)$result,
            'message' => $result ? 'درخواست واریز رد شد' : 'خطا در رد درخواست'
        ], $result ? 200 : 422);
        return;
    } catch (\Core\Exceptions\HttpResponseException $e) {
        throw $e;
    } catch (\Throwable $e) {
        $this->logger->error('admin.manual_deposit.reject.failed', [
            'channel' => 'admin',
            'admin_id' => user_id(),
            'deposit_id' => $depositId,
            'error' => $e->getMessage(),
            'exception' => get_class($e),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);

        $this->response->json([
            'success' => false,
            'message' => 'خطای سرور در رد واریز'
        ], 500);
    }
}
}
