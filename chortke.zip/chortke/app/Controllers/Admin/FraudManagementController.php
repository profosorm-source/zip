<?php

namespace App\Controllers\Admin;

use App\Services\AntiFraud\FraudManagementService;
use App\Services\ScoreService;
use App\Services\Auth\LoginRiskService;
use InvalidArgumentException;

class FraudManagementController extends BaseAdminController
{
    private FraudManagementService $fraudManagementService;
    private ScoreService $scoreService;
    private LoginRiskService $loginRiskService;

    public function __construct(
        FraudManagementService $fraudManagementService,
        ScoreService $scoreService,
        LoginRiskService $loginRiskService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->fraudManagementService = $fraudManagementService;
        $this->scoreService = $scoreService;
        $this->loginRiskService = $loginRiskService;
    }

    public function ipBlacklist()
    {
        $ips = $this->fraudManagementService->getIpBlacklist();
        return view('admin/fraud/ip-blacklist', ['ips' => $ips]);
    }

    public function blockIP()
    {
        $ip = (string) $this->request->input('ip');
        $reason = (string) $this->request->input('reason', 'مسدود شده توسط ادمین');
        $duration = $this->request->input('duration');
        $adminId = (int) $this->session->get('user_id');

        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            $this->session->setFlash('error', 'IP نامعتبر است');
            return $this->response->redirect(url('/admin/fraud/ip-blacklist'));
        }

        $this->fraudManagementService->blockIp(
            $ip,
            $reason,
            $duration !== null ? (int) $duration : null
        );

        $this->auditLog(
            'ip_blocked',
            'ip_block',
            0,
            null,
            ['ip' => $ip, 'reason' => $reason]
        );
        $this->session->setFlash('success', 'IP با موفقیت مسدود شد');
        return $this->response->redirect(url('/admin/fraud/ip-blacklist'));
    }

    public function unblockIP()
    {
        $id = (int) $this->request->input('id');

        $this->fraudManagementService->deleteIpBlacklistEntry($id);

        $adminId = (int) $this->session->get('user_id');
        $this->auditLog(
            'ip_unblocked',
            'ip_block',
            0,
            ['id' => $id],
            ['unblocked' => true]
        );
        $this->session->setFlash('success', 'مسدودیت IP برداشته شد');
        return $this->response->redirect(url('/admin/fraud/ip-blacklist'));
    }

    public function deviceBlacklist()
    {
        $devices = $this->fraudManagementService->getDeviceBlacklist();
        return view('admin/fraud/device-blacklist', ['devices' => $devices]);
    }

    public function blockDevice()
    {
        $fingerprint = (string) $this->request->input('fingerprint');
        $reason = (string) $this->request->input('reason', 'مسدود شده توسط ادمین');
        $adminId = (int) $this->session->get('user_id');

        $this->fraudManagementService->blockDevice($fingerprint, $reason, null);

        $this->auditLog(
            'device_blocked',
            'device_block',
            0,
            null,
            ['fingerprint' => $fingerprint, 'reason' => $reason]
        );
        $this->session->setFlash('success', 'دستگاه با موفقیت مسدود شد');
        return $this->response->redirect(url('/admin/fraud/device-blacklist'));
    }

    public function unblockDevice()
    {
        $id = (int) $this->request->input('id');

        $this->fraudManagementService->deleteDeviceBlacklistEntry($id);

        $adminId = (int) $this->session->get('user_id');
        $this->auditLog(
            'device_unblocked',
            'device_block',
            0,
            ['id' => $id],
            ['unblocked' => true]
        );
        $this->session->setFlash('success', 'مسدودیت دستگاه برداشته شد');
        return $this->response->redirect(url('/admin/fraud/device-blacklist'));
    }

    public function fraudLogs()
    {
        $page = (int) $this->request->get('page', 1);
        $perPage = 50;

        $result = $this->fraudManagementService->getFraudLogs($page, $perPage);

        return view('admin/fraud/logs', [
            'logs' => $result['logs'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
        ]);
    }



    /**
     * ریست کامل ریسک کاربر برای مواقع false-positive.
     */
    public function resetUserRisk()
    {
        $adminId = (int) $this->session->get('user_id');
        $identifier = trim((string)($this->request->input('identifier') ?: $this->request->input('user_id')));
        $reason = trim((string)$this->request->input('reason', 'ریست ریسک توسط ادمین'));

        if ($identifier === '') {
            $this->session->setFlash('error', 'شناسه، ایمیل، موبایل یا نام کاربری را وارد کنید.');
            return $this->response->back();
        }

        $user = $this->fraudManagementService->findUserForRiskReset($identifier);
        if (!$user) {
            $this->session->setFlash('error', 'کاربر مورد نظر پیدا نشد.');
            return $this->response->back();
        }

        $result = $this->fraudManagementService->resetUserRisk((int)$user->id, $adminId ?: null, $reason);

        if (!empty($result['success'])) {
            // Clear login-risk counters for both identifier and common normalized variants.
            foreach (array_filter([(string)($user->email ?? ''), (string)($user->mobile ?? ''), (string)($user->username ?? '')]) as $id) {
                $this->loginRiskService->clearFailures('login', null, $id);
            }

            $this->auditLog(
                'user_risk_reset',
                'fraud_risk',
                (int)$user->id,
                ['old_status' => $user->status ?? null, 'old_fraud_score' => $user->fraud_score ?? null],
                ['reason' => $reason, 'changes' => $result['changes'] ?? []]
            );

            $this->session->setFlash('success', 'ریسک کاربر #' . (int)$user->id . ' صفر شد و محدودیت‌های مرتبط پاک شد.');
        } else {
            $this->session->setFlash('error', (string)($result['message'] ?? 'ریست ریسک ناموفق بود.'));
        }

        return $this->response->back();
    }

    /**
     * Instead of hard reset, create auditable set adjustment.
     */
    public function resetFraudScore()
    {
        $adminId = (int) $this->session->get('user_id');
        $userId = (int) $this->request->input('user_id');
        $reason = (string) $this->request->input('reason', 'Reset by admin');

        try {
            $result = $this->scoreService->createAdjustment(
                $userId,
                'fraud',
                'set',
                0,
                $reason,
                null,
                $adminId
            );

            $ok = (bool)($result['success'] ?? false);

            if ($ok) {
                $this->auditLog(
                    'fraud_score_reset',
                    'user_fraud_score',
                    $userId,
                    ['old_score' => 'unknown'],
                    ['new_score' => 0, 'reason' => $reason]
                );
                $this->session->setFlash('success', 'Fraud score با adjustment ریست شد.');
            } else {
                $this->session->setFlash('error', 'ریست Fraud score ناموفق بود.');
            }
        } catch (InvalidArgumentException $e) {
            $this->session->setFlash('error', $e->getMessage());
        }

        return $this->response->back();
    }
}