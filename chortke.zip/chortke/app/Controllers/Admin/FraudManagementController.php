<?php

namespace App\Controllers\Admin;

use Core\Response;

use App\Services\AntiFraud\FraudManagementService;
use App\Services\ScoreService;
use InvalidArgumentException;

class FraudManagementController extends BaseAdminController
{
    private FraudManagementService $fraudManagementService;
    private ScoreService $scoreService;

    public function __construct(
        FraudManagementService $fraudManagementService,
        ScoreService $scoreService
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->fraudManagementService = $fraudManagementService;
        $this->scoreService = $scoreService;
    }

    public function ipBlacklist(): string
    {
        $ips = $this->fraudManagementService->getIpBlacklist();
        return view('admin/fraud/ip-blacklist', ['ips' => $ips]);
    }

    public function blockIP(): void
    {
        $ip = $this->request->str('ip');
        $reason = $this->request->str('reason', 'مسدود شده توسط ادمین');
        $duration = $this->request->input('duration');
        $adminId = int_value($this->session->get('user_id'));

        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            $this->session->setFlash('error', 'IP نامعتبر است');
            $this->response->redirect(url('/admin/fraud/ip-blacklist'));
            return;
        }

        // FIX-M28-10 (T28-20): رد IPهای حلقه‌ای/خصوصی/رزرو‌شده و IP فعلی خودِ ادمین —
        // قبلاً هر IP «معتبر» پذیرفته می‌شد؛ بلاک 127.0.0.1 یا رنج خصوصی یا IP خود
        // ادمین (و در استقرار پشت پروکسی معکوس/CGNAT که همه یک client-IP دیده
        // می‌شوند) یعنی قفل سراسری سایت با پیام موفقیت.
        if (
            filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false
            || $ip === get_client_ip()
        ) {
            $this->session->setFlash('error', 'این آدرس (خصوصی/حلقه‌ای یا IP فعلی خودتان) قابل مسدودسازی نیست.');
            $this->response->redirect(url('/admin/fraud/ip-blacklist'));
            return;
        }

        // FIX-M28-10 (T28-20): بازهٔ sane برای مدت مسدودسازی (ثانیه، ۱ دقیقه تا ۱ سال).
        $durationSeconds = $duration !== null ? int_value($duration) : null;
        if ($durationSeconds !== null && ($durationSeconds < 60 || $durationSeconds > 365 * 86400)) {
            $this->session->setFlash('error', 'مدت مسدودسازی باید بین ۱ دقیقه و ۱ سال (بر حسب ثانیه) باشد.');
            $this->response->redirect(url('/admin/fraud/ip-blacklist'));
            return;
        }

        // FIX-R60-A5-6: مسیر دستی — شناسهٔ ادمین ثبت می‌شود (auto_blocked=0)
        $this->fraudManagementService->blockIp(
            $ip,
            $reason,
            $durationSeconds,
            $adminId
        );

        // FIX-R36-W3 (F-A15-12): شناسهٔ ردیف بلک‌لیست واکشی می‌شود تا رویداد حسابرسی
        // به موجودیت واقعی لینک شود — قبلاً entity_id همیشه ۰ بود (بدون بازیابی
        // موجودیت، بدون تاریخچهٔ per-entity).
        $blacklistId = $this->findIpBlacklistId($ip);

        $this->auditLog(
            'ip_blocked',
            'ip_block',
            $blacklistId,
            null,
            ['ip' => $ip, 'reason' => $reason]
        );
        $this->session->setFlash('success', 'IP با موفقیت مسدود شد');
        $this->response->redirect(url('/admin/fraud/ip-blacklist'));
    }

    public function unblockIP(): void
    {
        $id = $this->request->int('id');

        // FIX-R36-W3 (F-A15-12): مقادیر ردیف پیش از حذف + id واقعی به‌جای entity_id=0.
        $oldRow = $id > 0 ? $this->fetchIpBlacklistRow($id) : null;

        // FIX-M28-10 (T28-20): شکست حذف دیگر با فلش موفقیت پنهان نمی‌شود.
        if (!$this->fraudManagementService->deleteIpBlacklistEntry($id)) {
            $this->session->setFlash('error', 'برداشتن مسدودیت IP ناموفق بود؛ لطفاً دوباره تلاش کنید.');
            $this->response->redirect(url('/admin/fraud/ip-blacklist'));
            return;
        }

        $adminId = int_value($this->session->get('user_id'));
        $this->auditLog(
            'ip_unblocked',
            'ip_block',
            $id,
            $oldRow ? ['id' => $id, 'ip' => str_value($oldRow->ip_address ?? '')] : ['id' => $id],
            ['unblocked' => true]
        );
        $this->session->setFlash('success', 'مسدودیت IP برداشته شد');
        $this->response->redirect(url('/admin/fraud/ip-blacklist'));
    }

    public function deviceBlacklist(): string
    {
        $devices = $this->fraudManagementService->getDeviceBlacklist();
        return view('admin/fraud/device-blacklist', ['devices' => $devices]);
    }

    public function blockDevice(): void
    {
        $fingerprint = $this->request->str('fingerprint');
        $reason = $this->request->str('reason', 'مسدود شده توسط ادمین');
        $adminId = int_value($this->session->get('user_id'));

        // FIX-R19-A5-5: اعتبارسنجی fingerprint قبل از درج در بلک‌لیست (آینهٔ blockIP) —
        // خالی/بیش از حد بلند (۱۲۸) پذیرفته نمی‌شود.
        $fingerprint = trim($fingerprint);
        if ($fingerprint === '' || mb_strlen($fingerprint) > 128) {
            $this->session->setFlash('error', 'اثر انگشت دستگاه نامعتبر است');
            $this->response->redirect(url('/admin/fraud/device-blacklist'));
            return;
        }

        // FIX-R60-A5-6: مسیر دستی — شناسهٔ ادمین ثبت می‌شود (auto_blocked=0)
        $this->fraudManagementService->blockDevice($fingerprint, $reason, null, $adminId);

        // FIX-R36-W3 (F-A15-12): شناسهٔ ردیف بلک‌لیست دستگاه (لینک رویداد حسابرسی به موجودیت).
        $blacklistId = $this->findDeviceBlacklistId($fingerprint);

        $this->auditLog(
            'device_blocked',
            'device_block',
            $blacklistId,
            null,
            ['fingerprint' => $fingerprint, 'reason' => $reason]
        );
        $this->session->setFlash('success', 'دستگاه با موفقیت مسدود شد');
        $this->response->redirect(url('/admin/fraud/device-blacklist'));
    }

    public function unblockDevice(): void
    {
        $id = $this->request->int('id');

        // FIX-R36-W3 (F-A15-12): مقادیر ردیف پیش از حذف + id واقعی به‌جای entity_id=0.
        $oldRow = $id > 0 ? $this->fetchDeviceBlacklistRow($id) : null;

        // FIX-M28-10 (T28-20): شکست حذف دیگر با فلش موفقیت پنهان نمی‌شود.
        if (!$this->fraudManagementService->deleteDeviceBlacklistEntry($id)) {
            $this->session->setFlash('error', 'برداشتن مسدودیت دستگاه ناموفق بود؛ لطفاً دوباره تلاش کنید.');
            $this->response->redirect(url('/admin/fraud/device-blacklist'));
            return;
        }

        $adminId = int_value($this->session->get('user_id'));
        $this->auditLog(
            'device_unblocked',
            'device_block',
            $id,
            $oldRow ? ['id' => $id, 'fingerprint' => str_value($oldRow->fingerprint ?? '')] : ['id' => $id],
            ['unblocked' => true]
        );
        $this->session->setFlash('success', 'مسدودیت دستگاه برداشته شد');
        $this->response->redirect(url('/admin/fraud/device-blacklist'));
    }

    /**
     * FIX-R62-D6 (وجه D6الف/D6ب قانون v2): پنل لیست سیاه سئو — تا این رفع،
     * user_blacklist فقط نوشته می‌شد (ProcessSeoTaskAsyncJob) و خوانده می‌شد
     * (گیت StartSeoTaskJob)؛ هیچ رابط مدیریتی نداشت: ادمین نمی‌دید چه کسی
     * سیاه شده و پس از بازبینی نمی‌توانست رفع کند. هم‌الگوی deviceBlacklist.
     */
    public function userBlacklist(): string
    {
        $users = $this->fraudManagementService->getUserBlacklist();
        return view('admin/fraud/user-blacklist', ['users' => $users]);
    }

    /** FIX-R62-D6: رفع لیست سیاه سئو — هم‌الگوی unblockDevice (کامل با audit trail). */
    public function userUnblock(): void
    {
        $id = $this->request->int('id');

        // مقادیر ردیف پیش از حذف + id واقعی برای رویداد حسابرسی (هم‌الگوی F-A15-12).
        $oldRow = $id > 0 ? $this->fetchUserBlacklistRow($id) : null;

        // شکست حذف دیگر با فلش موفقیت پنهان نمی‌شود (هم‌قرارداد T28-20).
        if ($id <= 0 || !$this->fraudManagementService->deleteUserBlacklistEntry($id)) {
            $this->session->setFlash('error', 'برداشتن کاربر از لیست سیاه سئو ناموفق بود؛ لطفاً دوباره تلاش کنید.');
            $this->response->redirect(url('/admin/fraud/user-blacklist'));
            return;
        }

        $this->auditLog(
            'seo_user_unblacklisted',
            'user_seo_blacklist',
            $id,
            $oldRow ? ['id' => $id, 'user_id' => (int)($oldRow->user_id ?? 0)] : ['id' => $id],
            ['unblacklisted' => true, 'reason' => str_value($oldRow->reason ?? '')]
        );
        $this->session->setFlash('success', 'کاربر از لیست سیاه سئو برداشته شد');
        $this->response->redirect(url('/admin/fraud/user-blacklist'));
    }

    public function fraudLogs(): string
    {
        $page = max(1, $this->request->int('page', 1));
        $perPage = 50;

        $result = $this->fraudManagementService->getFraudLogs($page, $perPage);

        return view('admin/fraud/logs', [
            'logs' => $result['logs'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
        ]);
    }

    /**
     * Instead of hard reset, create auditable set adjustment.
     */
    public function resetFraudScore(): void
    {
        $adminId = int_value($this->session->get('user_id'));
        $userId = $this->request->int('user_id');
        $reason = $this->request->str('reason', 'Reset by admin');

        // FIX-M28-10 (T28-20): گاردهای هم‌خانوادهٔ FraudController::suspendUser —
        // قبلاً هیچ منع خود/سلسله‌مراتب نداشت (ادمین fraud.manage می‌توانست امتیاز
        // مدیر بالادستی یا خودش را صفر کند) و old_score همیشه 'unknown' ثبت می‌شد
        // در حالی که مقدار واقعی قبل از adjustment در دسترس است. نکتهٔ fail-mode:
        // اگر واکشی گاردها به خطای DB بخورد فقط لاگ می‌شود (ریست با adjustment
        // قابل بازگشت است) ولی old_score همان unknown می‌ماند.
        if ($userId <= 0) {
            $this->session->setFlash('error', 'شناسه کاربر الزامی است.');
            $this->response->back();
            return;
        }
        if ($userId === $adminId) {
            $this->session->setFlash('error', 'شما نمی‌توانید امتیاز تقلب خودتان را ریست کنید.');
            $this->response->back();
            return;
        }
        $oldScore = 'unknown';
        try {
            $target = db()->table('users')->where('id', '=', $userId)->first();
            if ($target === null) {
                $this->session->setFlash('error', 'کاربر یافت نشد.');
                $this->response->back();
                return;
            }
            $oldScore = (int)($target->fraud_score ?? 0);
            if (\App\Policies\RolePolicy::roleLevel(str_value($target->role ?? 'user')) >= 1) {
                $admin = db()->table('users')->where('id', '=', $adminId)->first();
                if (\App\Policies\RolePolicy::roleLevel(str_value($admin->role ?? 'user')) < 2) {
                    $this->session->setFlash('error', 'شما مجاز به ریست امتیاز تقلب سایر مدیران نیستید.');
                    $this->response->back();
                    return;
                }
            }
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.reset_guard_failed', ['error' => $e->getMessage()]);
            }
        }

        try {
            $result = $this->scoreService->createAdjustment(
                $userId,
                'fraud',
                'set',
                0,
                $reason,
                null,
                $adminId
            );

            $ok = (bool)($result['success'] ?? false);

            if ($ok) {
                $this->auditLog(
                    'fraud_score_reset',
                    'user_fraud_score',
                    $userId,
                    ['old_score' => $oldScore],
                    ['new_score' => 0, 'reason' => $reason]
                );
                $this->session->setFlash('success', 'Fraud score با adjustment ریست شد.');
            } else {
                $this->session->setFlash('error', 'ریست Fraud score ناموفق بود.');
            }
        } catch (InvalidArgumentException $e) {
            $this->session->setFlash('error', $e->getMessage());
        }

        $this->response->back();
    }

    /** FIX-R36-W3 (F-A15-12): واکشی id ردیف بلک‌لیست IP پس از بلاک (0 = یافت نشد) —
     *  دسترسی DB با QueryBuilder، هم‌قرارداد «مدل‌ها مالکِ SQL خام» */
    private function findIpBlacklistId(string $ip): int
    {
        try {
            $row = db()->table('ip_blacklist')->where('ip_address', '=', $ip)->orderBy('id', 'DESC')->first();
            return $row ? (int)$row->id : 0;
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_id_fetch_failed', ['entity' => 'ip_blacklist', 'error' => $e->getMessage()]);
            }
            return 0;
        }
    }

    /** FIX-R36-W3 (F-A15-12): واکشی ردیف بلک‌لیست IP پیش از حذف (برای old_values) */
    private function fetchIpBlacklistRow(int $id): ?object
    {
        try {
            return db()->table('ip_blacklist')->where('id', '=', $id)->first();
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_row_fetch_failed', ['entity' => 'ip_blacklist', 'error' => $e->getMessage()]);
            }
            return null;
        }
    }

    /** FIX-R36-W3 (F-A15-12): واکشی id ردیف بلک‌لیست دستگاه پس از بلاک (0 = یافت نشد) */
    private function findDeviceBlacklistId(string $fingerprint): int
    {
        try {
            $row = db()->table('device_blacklist')->where('fingerprint', '=', $fingerprint)->orderBy('id', 'DESC')->first();
            return $row ? (int)$row->id : 0;
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_id_fetch_failed', ['entity' => 'device_blacklist', 'error' => $e->getMessage()]);
            }
            return 0;
        }
    }

    /** FIX-R36-W3 (F-A15-12): واکشی ردیف بلک‌لیست دستگاه پیش از حذف (برای old_values) */
    private function fetchDeviceBlacklistRow(int $id): ?object
    {
        try {
            return db()->table('device_blacklist')->where('id', '=', $id)->first();
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_row_fetch_failed', ['entity' => 'device_blacklist', 'error' => $e->getMessage()]);
            }
            return null;
        }
    }

    /** FIX-R62-D6: واکشی ردیف لیست سیاه سئو پیش از حذف (برای old_values) — هم‌الگوی بالا */
    private function fetchUserBlacklistRow(int $id): ?object
    {
        try {
            return db()->table('user_blacklist')->where('id', '=', $id)->first();
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_row_fetch_failed', ['entity' => 'user_blacklist', 'error' => $e->getMessage()]);
            }
            return null;
        }
    }
}