<?php

namespace App\Controllers\Admin;

use Core\Response;

use App\Services\AntiFraud\FraudManagementService;
use App\Services\ScoreService;
use InvalidArgumentException;

class FraudManagementController extends BaseAdminController
{
    private FraudManagementService $fraudManagementService;
    private ScoreService $scoreService;

    public function __construct(
        FraudManagementService $fraudManagementService,
        ScoreService $scoreService
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->fraudManagementService = $fraudManagementService;
        $this->scoreService = $scoreService;
    }

    public function ipBlacklist(): string
    {
        $ips = $this->fraudManagementService->getIpBlacklist();
        return view('admin/fraud/ip-blacklist', ['ips' => $ips]);
    }

    public function blockIP(): void
    {
        $ip = $this->request->str('ip');
        $reason = $this->request->str('reason', 'مسدود شده توسط ادمین');
        $duration = $this->request->input('duration');
        $adminId = int_value($this->session->get('user_id'));

        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            $this->session->setFlash('error', 'IP نامعتبر است');
            $this->response->redirect(url('/admin/fraud/ip-blacklist'));
        }

        $this->fraudManagementService->blockIp(
            $ip,
            $reason,
            $duration !== null ? int_value($duration) : null
        );

        // FIX-R36-W3 (F-A15-12): شناسهٔ ردیف بلک‌لیست واکشی می‌شود تا رویداد حسابرسی
        // به موجودیت واقعی لینک شود — قبلاً entity_id همیشه ۰ بود (بدون بازیابی
        // موجودیت، بدون تاریخچهٔ per-entity).
        $blacklistId = $this->findIpBlacklistId($ip);

        $this->auditLog(
            'ip_blocked',
            'ip_block',
            $blacklistId,
            null,
            ['ip' => $ip, 'reason' => $reason]
        );
        $this->session->setFlash('success', 'IP با موفقیت مسدود شد');
        $this->response->redirect(url('/admin/fraud/ip-blacklist'));
    }

    public function unblockIP(): void
    {
        $id = $this->request->int('id');

        // FIX-R36-W3 (F-A15-12): مقادیر ردیف پیش از حذف + id واقعی به‌جای entity_id=0.
        $oldRow = $id > 0 ? $this->fetchIpBlacklistRow($id) : null;

        $this->fraudManagementService->deleteIpBlacklistEntry($id);

        $adminId = int_value($this->session->get('user_id'));
        $this->auditLog(
            'ip_unblocked',
            'ip_block',
            $id,
            $oldRow ? ['id' => $id, 'ip' => str_value($oldRow->ip_address ?? '')] : ['id' => $id],
            ['unblocked' => true]
        );
        $this->session->setFlash('success', 'مسدودیت IP برداشته شد');
        $this->response->redirect(url('/admin/fraud/ip-blacklist'));
    }

    public function deviceBlacklist(): string
    {
        $devices = $this->fraudManagementService->getDeviceBlacklist();
        return view('admin/fraud/device-blacklist', ['devices' => $devices]);
    }

    public function blockDevice(): void
    {
        $fingerprint = $this->request->str('fingerprint');
        $reason = $this->request->str('reason', 'مسدود شده توسط ادمین');
        $adminId = int_value($this->session->get('user_id'));

        // FIX-R19-A5-5: اعتبارسنجی fingerprint قبل از درج در بلک‌لیست (آینهٔ blockIP) —
        // خالی/بیش از حد بلند (۱۲۸) پذیرفته نمی‌شود.
        $fingerprint = trim($fingerprint);
        if ($fingerprint === '' || mb_strlen($fingerprint) > 128) {
            $this->session->setFlash('error', 'اثر انگشت دستگاه نامعتبر است');
            $this->response->redirect(url('/admin/fraud/device-blacklist'));
            return;
        }

        $this->fraudManagementService->blockDevice($fingerprint, $reason, null);

        // FIX-R36-W3 (F-A15-12): شناسهٔ ردیف بلک‌لیست دستگاه (لینک رویداد حسابرسی به موجودیت).
        $blacklistId = $this->findDeviceBlacklistId($fingerprint);

        $this->auditLog(
            'device_blocked',
            'device_block',
            $blacklistId,
            null,
            ['fingerprint' => $fingerprint, 'reason' => $reason]
        );
        $this->session->setFlash('success', 'دستگاه با موفقیت مسدود شد');
        $this->response->redirect(url('/admin/fraud/device-blacklist'));
    }

    public function unblockDevice(): void
    {
        $id = $this->request->int('id');

        // FIX-R36-W3 (F-A15-12): مقادیر ردیف پیش از حذف + id واقعی به‌جای entity_id=0.
        $oldRow = $id > 0 ? $this->fetchDeviceBlacklistRow($id) : null;

        $this->fraudManagementService->deleteDeviceBlacklistEntry($id);

        $adminId = int_value($this->session->get('user_id'));
        $this->auditLog(
            'device_unblocked',
            'device_block',
            $id,
            $oldRow ? ['id' => $id, 'fingerprint' => str_value($oldRow->fingerprint ?? '')] : ['id' => $id],
            ['unblocked' => true]
        );
        $this->session->setFlash('success', 'مسدودیت دستگاه برداشته شد');
        $this->response->redirect(url('/admin/fraud/device-blacklist'));
    }

    public function fraudLogs(): string
    {
        $page = max(1, $this->request->int('page', 1));
        $perPage = 50;

        $result = $this->fraudManagementService->getFraudLogs($page, $perPage);

        return view('admin/fraud/logs', [
            'logs' => $result['logs'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
        ]);
    }

    /**
     * Instead of hard reset, create auditable set adjustment.
     */
    public function resetFraudScore(): void
    {
        $adminId = int_value($this->session->get('user_id'));
        $userId = $this->request->int('user_id');
        $reason = $this->request->str('reason', 'Reset by admin');

        try {
            $result = $this->scoreService->createAdjustment(
                $userId,
                'fraud',
                'set',
                0,
                $reason,
                null,
                $adminId
            );

            $ok = (bool)($result['success'] ?? false);

            if ($ok) {
                $this->auditLog(
                    'fraud_score_reset',
                    'user_fraud_score',
                    $userId,
                    ['old_score' => 'unknown'],
                    ['new_score' => 0, 'reason' => $reason]
                );
                $this->session->setFlash('success', 'Fraud score با adjustment ریست شد.');
            } else {
                $this->session->setFlash('error', 'ریست Fraud score ناموفق بود.');
            }
        } catch (InvalidArgumentException $e) {
            $this->session->setFlash('error', $e->getMessage());
        }

        $this->response->back();
    }

    /** FIX-R36-W3 (F-A15-12): واکشی id ردیف بلک‌لیست IP پس از بلاک (0 = یافت نشد) —
     *  دسترسی DB با QueryBuilder، هم‌قرارداد «مدل‌ها مالکِ SQL خام» */
    private function findIpBlacklistId(string $ip): int
    {
        try {
            $row = db()->table('ip_blacklist')->where('ip_address', '=', $ip)->orderBy('id', 'DESC')->first();
            return $row ? (int)$row->id : 0;
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_id_fetch_failed', ['entity' => 'ip_blacklist', 'error' => $e->getMessage()]);
            }
            return 0;
        }
    }

    /** FIX-R36-W3 (F-A15-12): واکشی ردیف بلک‌لیست IP پیش از حذف (برای old_values) */
    private function fetchIpBlacklistRow(int $id): ?object
    {
        try {
            return db()->table('ip_blacklist')->where('id', '=', $id)->first();
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_row_fetch_failed', ['entity' => 'ip_blacklist', 'error' => $e->getMessage()]);
            }
            return null;
        }
    }

    /** FIX-R36-W3 (F-A15-12): واکشی id ردیف بلک‌لیست دستگاه پس از بلاک (0 = یافت نشد) */
    private function findDeviceBlacklistId(string $fingerprint): int
    {
        try {
            $row = db()->table('device_blacklist')->where('fingerprint', '=', $fingerprint)->orderBy('id', 'DESC')->first();
            return $row ? (int)$row->id : 0;
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_id_fetch_failed', ['entity' => 'device_blacklist', 'error' => $e->getMessage()]);
            }
            return 0;
        }
    }

    /** FIX-R36-W3 (F-A15-12): واکشی ردیف بلک‌لیست دستگاه پیش از حذف (برای old_values) */
    private function fetchDeviceBlacklistRow(int $id): ?object
    {
        try {
            return db()->table('device_blacklist')->where('id', '=', $id)->first();
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.fraud.audit_row_fetch_failed', ['entity' => 'device_blacklist', 'error' => $e->getMessage()]);
            }
            return null;
        }
    }
}