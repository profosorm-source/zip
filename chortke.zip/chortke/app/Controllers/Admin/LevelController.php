<?php

namespace App\Controllers\Admin;

use App\Models\UserLevel;
use App\Models\UserLevelHistory;
use App\Services\User\UserLevelService;
use App\Controllers\Admin\BaseAdminController;
use App\Contracts\WalletServiceInterface;

class LevelController extends BaseAdminController
{
    private \App\Services\User\UserLevelService $userLevelService;
    private \App\Models\UserLevelHistory $userLevelHistoryModel;
    private \App\Models\UserLevel $userLevelModel;
    private \App\Services\User\UserService $userService;

    public function __construct(
        \App\Models\UserLevel $userLevelModel,
        \App\Models\UserLevelHistory $userLevelHistoryModel,
        \App\Services\User\UserLevelService $userLevelService,
        \App\Services\User\UserService $userService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->userLevelModel = $userLevelModel;
        $this->userLevelHistoryModel = $userLevelHistoryModel;
        $this->userLevelService = $userLevelService;
        $this->userService = $userService;
    }

    /**
     * لیست سطوح + آمار
     */
    public function index(): void
    {

        $levelModel = $this->userLevelModel;
        $levels = $levelModel->all([]);
        $userCounts = $levelModel->getUserCountPerLevel();

        $this->logger->activity('levels.view', 'مشاهده لیست سطوح', user_id(), []);

        view('admin.levels.index', [
            'levels' => $levels,
            'userCounts' => $userCounts,
        ]);
    }

    /**
     * فرم ویرایش سطح
     */
    public function edit(): void
    {

                $id = $this->request->int('id');

        $levelModel = $this->userLevelModel;
        $level = $levelModel->find($id);

        if (!$level) {
            \http_response_code(404);
            include __DIR__ . '/../../../views/errors/404.php';
            exit;
        }

        view('admin.levels.edit', ['level' => $level]);
    }

    /**
     * ذخیره ویرایش
     */
    public function update(): void
    {

                        
        $id = $this->request->int('id');



        $validator = $this->validatorFactory()->make($this->request->all(), [
            'name' => 'required|min:2|max:50',
            'min_active_days' => 'required|numeric',
            'min_completed_tasks' => 'required|numeric',
            'min_total_earning' => 'required|numeric',
            'purchase_price_irt' => 'required|numeric',
            'earning_bonus_percent' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/levels/' . $id . '/edit'));
        }

        // FIX-18Q (P2-17): کران‌های فیلدهای مالی — قبل از نوشتن در DB.
        $this->rejectOutOfRangeLevelFields(url('/admin/levels/' . $id . '/edit'));

        $data = $validator->validated(); // FIX-M1M2: allowlist
        $levelModel = $this->userLevelModel;

        $payload = [
            'name' => $data['name'],
            'icon' => $this->request->post('icon') ?? 'workspace_premium',
            'color' => $this->request->post('color') ?? '#c0c0c0',
            'min_active_days' => $validator->int('min_active_days'),
            'min_completed_tasks' => $validator->int('min_completed_tasks'),
            'min_total_earning' => $validator->float('min_total_earning'),
            'min_total_earning_usdt' => $this->request->float('min_total_earning_usdt'),
            'purchase_price_irt' => $validator->float('purchase_price_irt'),
            'purchase_price_usdt' => $this->request->float('purchase_price_usdt'),
            'purchase_duration_days' => $this->request->int('purchase_duration_days', 30),
            'earning_bonus_percent' => $validator->float('earning_bonus_percent'),
            'referral_bonus_percent' => $this->request->float('referral_bonus_percent'),
            'daily_task_limit_bonus' => $this->request->int('daily_task_limit_bonus'),
            'withdrawal_limit_bonus' => $this->request->float('withdrawal_limit_bonus'),
            'priority_support' => $this->request->post('priority_support') ? 1 : 0,
            'special_badge' => $this->request->post('special_badge') ? 1 : 0,
            'is_active' => $this->request->post('is_active') ? 1 : 0,
        ];

        // FIX-18Q (P2-17): مقادیر قدیمی برای ردِ حسابرسی (قبلاً به‌کلی auditLog نداشت).
        $oldLevel = $levelModel->find($id);
        $oldValues = null;
        if ($oldLevel) {
            $oldValues = [];
            foreach (array_keys($payload) as $k) {
                $oldValues[$k] = $oldLevel->{$k} ?? null;
            }
        }

        $levelModel->update($id, $payload);

        // FIX-18Q (P2-17): ردپای حسابرسی تغییر سطح — الگوی auditLog پایه.
        $this->auditLog('level.updated', 'level', $id, $oldValues, $payload);

        $this->logger->activity('levels.update', 'ویرایش سطح', user_id(), ['level_id' => $id, 'name' => $data['name']]);

        $this->session->setFlash('success', 'سطح «' . e($data['name']) . '» بروزرسانی شد.');
        redirect(url('/admin/levels'));
    }

    /**
     * تغییر سطح کاربر توسط ادمین (Ajax)
     */
    public function changeUserLevel(): void
    {
        $decodedBody = json_decode((file_get_contents('php://input') ?: ''), true);
        $body = is_array($decodedBody) ? $decodedBody : [];

        // 📜 قرارداد واحد ورودی: FormRequest به‌جای بررسی دستی (RULES §۱۸).
        $request = new \App\Validators\Requests\ChangeUserLevelRequest($body);
        if (!$request->validate()) {
            $errors = $request->errors();
            $firstValue = reset($errors);
            $firstError = is_array($firstValue) ? reset($firstValue) : $firstValue;
            $this->response->json(['success' => false, 'message' => is_string($firstError) && $firstError !== '' ? $firstError : 'اطلاعات ناقص', 'errors' => $errors], 422);
            return;
        }
        $validated = $request->safeValidated();
        $userId = int_value($validated['user_id'] ?? 0);
        $newLevel = str_value($validated['level'] ?? '');
        $reason = str_value($validated['reason'] ?? '') ?: 'تغییر توسط مدیر';

        $currentAdminId = (int)$this->userId();

        // Prevent self-modification
        if ($userId === $currentAdminId) {
            $this->response->json(['success' => false, 'message' => 'نمیتوانید سطح خودتان را تغییر دهید'], 403);
            return;
        }

        // Prevent modifying other admins (unless super admin / permitted)
        $targetUser = $this->userService->find($userId);
        if ($targetUser && in_array($targetUser->role, ['admin', 'super_admin'])) {
            $currentAdminUser = $this->userService->find($currentAdminId);
            if (!$currentAdminUser || !$this->policyService->can('admin.level.change_admin_level', $currentAdminUser)) {
                $this->response->json(['success' => false, 'message' => 'شما اجازه تغییر سطح ادمینها را ندارید'], 403);
                return;
            }
        }

        $levelService = $this->userLevelService;
        $changed = $levelService->adminChangeLevel($userId, $newLevel, $reason);

        if (!$changed) {
            $this->response->json(['success' => false, 'message' => 'خطا در تغییر سطح'], 500);
            return;
        }

        $this->logger->activity('levels.admin_change', 'تغییر سطح کاربر', user_id(), [
            'user_id' => $userId,
            'new_level' => $newLevel,
            'reason' => $reason,
        ]);

        $this->response->json([
            'success' => true,
            'message' => 'سطح کاربر با موفقیت تغییر یافت.',
        ]);
    }

    /**
     * لیست تاریخچه تغییرات سطح
     */
    public function history(): void
    {

                $historyModel = $this->userLevelHistoryModel;
        $levelModel = $this->userLevelModel;

        $filters = [
            'change_type' => $this->request->get('change_type'),
            'to_level' => $this->request->get('to_level'),
            'user_id' => $this->request->get('user_id'),
        ];

        $page = \max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $items = $historyModel->adminList($filters, $limit, $offset);
        $total = $historyModel->adminCount($filters);
        $levels = $levelModel->all([]);

        view('admin.levels.user-levels', [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'pages' => \ceil($total / $limit),
            'filters' => $filters,
            'levels' => $levels,
        ]);
    }

    /**
     * FIX-18Q (P2-17): اعتبارسنجی کران‌دارِ فیلدهای مالی سطح.
     * قبلاً earning/referral_bonus_percent و قیمت‌های خرید و مدت خرید بدون هیچ
     * سقف/کف از ورودی خام ادمین به DB (و مسیرهای پولیِ درآمد/خرید سطح) می‌رفتند.
     * - earning_bonus_percent / referral_bonus_percent: عددی ۰..۱۰۰
     * - purchase_price_irt / purchase_price_usdt: عددی >= 0
     * - min_total_earning_usdt: >= 0
     * - purchase_duration_days: صحیح ۱..۳۶۵۰
     * ردِ خارج از محدوده با همان استایل خطای اعتبارسنجی موجود کنترلر (flash + redirect).
     */
    private function rejectOutOfRangeLevelFields(string $errorBackUrl): void
    {
        $errors = [];

        $earningBonus = $this->request->float('earning_bonus_percent');
        $referralBonus = $this->request->float('referral_bonus_percent');
        if (!is_finite($earningBonus) || $earningBonus < 0 || $earningBonus > 100) {
            $errors[] = 'درصد بونوس درآمد باید عددی بین ۰ تا ۱۰۰ باشد.';
        }
        if (!is_finite($referralBonus) || $referralBonus < 0 || $referralBonus > 100) {
            $errors[] = 'درصد بونوس زیرمجموعه باید عددی بین ۰ تا ۱۰۰ باشد.';
        }

        foreach (['purchase_price_irt' => 'قیمت خرید (تومان)', 'purchase_price_usdt' => 'قیمت خرید (تتر)'] as $field => $label) {
            $price = $this->request->float($field);
            if (!is_finite($price) || $price < 0) {
                $errors[] = $label . ' باید عددی بزرگ‌تر یا مساوی صفر باشد.';
            }
        }

        $minEarningUsdt = $this->request->float('min_total_earning_usdt');
        if (!is_finite($minEarningUsdt) || $minEarningUsdt < 0) {
            $errors[] = 'حداقل درآمد کل (تتر) باید بزرگ‌تر یا مساوی صفر باشد.';
        }

        $duration = $this->request->int('purchase_duration_days', 30);
        if ($duration < 1 || $duration > 3650) {
            $errors[] = 'مدت اعتبار خرید باید عددی بین ۱ تا ۳۶۵۰ روز باشد.';
        }

        if ($errors !== []) {
            $this->session->setFlash('error', $errors[0]);
            $this->session->setFlash('old', $this->request->all());
            redirect($errorBackUrl);
        }
    }

    /**
     * فرم ایجاد سطح جدید
     */
    public function create(): void
    {

        view('admin.levels.create', []);
    }

    /**
     * ذخیره سطح جدید
     */
    public function store(): void
    {



        $validator = $this->validatorFactory()->make($this->request->all(), [
            'name'                  => 'required|min:2|max:50',
            'slug'                  => 'required|min:2|max:50',
            'min_active_days'       => 'required|numeric',
            'min_completed_tasks'   => 'required|numeric',
            'min_total_earning'     => 'required|numeric',
            'purchase_price_irt'    => 'required|numeric',
            'earning_bonus_percent' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا در اعتبارسنجی');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/levels/create'));
        }

        // FIX-18Q (P2-17): کران‌های فیلدهای مالی — قبل از نوشتن در DB.
        $this->rejectOutOfRangeLevelFields(url('/admin/levels/create'));

        $data = $validator->validated(); // FIX-M1M2: allowlist
        $levelModel = $this->userLevelModel;

        // slug را sanitize کنیم
        $slug = preg_replace('/[^a-z0-9_-]/', '', strtolower(str_value($data['slug'] ?? '')));
        if (empty($slug)) {
            $this->session->setFlash('error', 'slug نامعتبر است. فقط حروف انگلیسی کوچک، عدد، خط تیره و زیرخط مجاز است.');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/levels/create'));
        }

        // بررسی تکراری نبودن slug
        if ($levelModel->slugExists($slug)) {
            $this->session->setFlash('error', 'این slug قبلاً استفاده شده است.');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/levels/create'));
        }

        $sortOrder = $this->request->int('sort_order') ?: ($levelModel->getMaxSortOrder() + 10);

        $level = $levelModel->createLevel([
            'name'                    => $data['name'],
            'slug'                    => $slug,
            'icon'                    => $this->request->post('icon') ?? 'workspace_premium',
            'color'                   => $this->request->post('color') ?? '#c0c0c0',
            'sort_order'              => $sortOrder,
            'min_active_days'         => $validator->int('min_active_days'),
            'min_completed_tasks'     => $validator->int('min_completed_tasks'),
            'min_total_earning'       => $validator->float('min_total_earning'),
            'min_total_earning_usdt'  => $this->request->float('min_total_earning_usdt'),
            'purchase_price_irt'      => $validator->float('purchase_price_irt'),
            'purchase_price_usdt'     => $this->request->float('purchase_price_usdt'),
            'purchase_duration_days'  => $this->request->int('purchase_duration_days', 30),
            'earning_bonus_percent'   => $validator->float('earning_bonus_percent'),
            'referral_bonus_percent'  => $this->request->float('referral_bonus_percent'),
            'daily_task_limit_bonus'  => $this->request->int('daily_task_limit_bonus'),
            'withdrawal_limit_bonus'  => $this->request->float('withdrawal_limit_bonus'),
            'priority_support'        => $this->request->post('priority_support') ? 1 : 0,
            'special_badge'           => $this->request->post('special_badge') ? 1 : 0,
            'is_active'               => $this->request->post('is_active') ? 1 : 0,
        ]);

        if (!$level) {
            $this->session->setFlash('error', 'خطا در ایجاد سطح جدید.');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/levels/create'));
        }

        $this->logger->activity('levels.create', 'ایجاد سطح جدید', user_id(), ['level_id' => $level->id, 'name' => $data['name'], 'slug' => $slug]);

        // FIX-18Q (P2-17): ردپای حسابرسی ایجاد سطح — الگوی auditLog پایه.
        $this->auditLog('level.created', 'level', (int)$level->id, null, [
            'name' => $data['name'],
            'slug' => $slug,
            'purchase_price_irt' => $this->request->float('purchase_price_irt'),
            'purchase_price_usdt' => $this->request->float('purchase_price_usdt'),
            'purchase_duration_days' => $this->request->int('purchase_duration_days', 30),
            'earning_bonus_percent' => $validator->float('earning_bonus_percent'),
            'referral_bonus_percent' => $this->request->float('referral_bonus_percent'),
        ]);

        $this->session->setFlash('success', 'سطح «' . e($data['name']) . '» با موفقیت ایجاد شد.');
        redirect(url('/admin/levels'));
    }

    /**
     * حذف سطح (Ajax)
     */
    public function destroy(): void
    {

        $id = $this->request->int('id');
        $levelModel = $this->userLevelModel;
        $level = $levelModel->find($id);

        if (!$level) {
            $this->response->json(['success' => false, 'message' => 'سطح یافت نشد.'], 404);
            return;
        }

        // سطح پیش‌فرض (برنز) قابل حذف نیست
        if ($level->slug === 'bronze') {
            $this->response->json(['success' => false, 'message' => 'سطح پیش‌فرض (برنز) قابل حذف نیست.'], 403);
            return;
        }

        // اگر کاربری در این سطح هست، اجازه حذف نداریم
        $userCounts = $levelModel->getUserCountPerLevel();
        if (($userCounts[$level->slug] ?? 0) > 0) {
            $this->response->json([
                'success' => false,
                'message' => 'این سطح دارای ' . ($userCounts[$level->slug]) . ' کاربر فعال است و قابل حذف نیست.',
            ], 409);
            return;
        }

        $deleted = $levelModel->delete($id);

        if (!$deleted) {
            $this->response->json(['success' => false, 'message' => 'خطا در حذف سطح.'], 500);
            return;
        }

        $this->logger->activity('levels.delete', 'حذف سطح', user_id(), ['level_id' => $id, 'name' => $level->name, 'slug' => $level->slug]);

        $this->response->json(['success' => true, 'message' => 'سطح «' . $level->name . '» حذف شد.']);
    }

}