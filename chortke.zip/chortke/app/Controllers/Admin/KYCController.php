<?php

namespace App\Controllers\Admin;
use App\Services\User\UserService;
use App\Contracts\ValidatorFactoryInterface;

use App\Services\KYCService;
use App\Controllers\Admin\BaseAdminController;

class KYCController extends BaseAdminController
{
    protected UserService $userService;
    private KYCService $kycService;
    private ValidatorFactoryInterface $validatorFactory;

    public function __construct(
        UserService $userService,
        KYCService $kycService,
        ValidatorFactoryInterface $validatorFactory, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->userService = $userService;
        $this->kycService = $kycService;
        $this->validatorFactory = $validatorFactory;
    }

    public function index(): void
    {
        $status = $this->request->get('status', '');
        $search = $this->request->get('search', '');
        $page = max(1, $this->request->int('page', 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;

        $filters = [];
        if ($status !== '') $filters['status'] = $status;
        if ($search !== '') $filters['search'] = $search;

        try {
            $kycs = $this->kycService->getAll($filters, $perPage, $offset, true);
            // 🛡️ FIX-PS-C2: این کنترلر فقط مسیر آرایه‌ای را صدا می‌زند (همیشه list<\stdClass>)؛
            // حصارِ صادق برای اتحاد بازگشتِ فاساد (SearchResult مسیر این نقطه نیست).
            if (!is_array($kycs)) { $kycs = []; }
        } catch (\Throwable $e) {
            $this->logger->error('admin.kyc.get_all.failed', [
                'status' => $status,
                'search' => $search,
                'error' => $e->getMessage()
            ]);
            $kycs = [];
        }

        $total = $this->kycService->count($filters);
        $totalPages = (int)\ceil($total / $perPage);

        // FIX-X117: مصرف بوست KYC — درخواست‌های «بوست‌دارِ در انتظار بررسی» به صدر صف
        [$kycs, $boostedUserIds] = boost_queue_order($kycs, 'kyc', 'user_id', 'status', ['pending', 'under_review']);

        // FIX-X165/X167: وعدهٔ SLA هر ردیف (الگوی TicketController/X125) + شمارندهٔ صف
        $nowTs = time();
        foreach ($kycs as $row) {
            $pm = (int)($row->sla_promised_minutes ?? 0);
            $row->sla_remaining_minutes = null;
            $row->sla_breached = false;
            $row->sla_response_minutes = null;
            if ($pm > 0 && !empty($row->sla_promised_at)) {
                if (in_array($row->status, ['pending', 'under_review'], true)) {
                    $remain = (int)\ceil((\strtotime($row->sla_promised_at) + $pm * 60 - $nowTs) / 60);
                    $row->sla_remaining_minutes = $remain;
                    $row->sla_breached = $remain < 0;
                } elseif (!empty($row->reviewed_at)) {
                    $row->sla_response_minutes = (int)\ceil((\strtotime($row->reviewed_at) - \strtotime($row->sla_promised_at)) / 60);
                }
            }
        }

        try {
            $slaCounters = $this->kycService->getSlaCounters();
        } catch (\Throwable $e) {
            $this->logger->warning('admin.kyc.sla_counters.failed', ['error' => $e->getMessage()]);
            $slaCounters = ['promised' => 0, 'breached' => 0];
        }

        // ✅ استفاده از یک کوئری جامع با GROUP BY به جای 4 کوئری جداگانه
        $stats = $this->kycService->getStatsByStatus();

        echo view('admin.kyc.index', [
            'kycs' => $kycs,
            'total' => $total,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'statusFilter' => $status,
            'search' => $search,
            'stats' => $stats,
            'boostedUserIds' => $boostedUserIds, // FIX-X117
            'slaCounters' => $slaCounters, // FIX-X167
        ]);
    }

    public function review(int $id): void
    {
        try {
            $kyc = $this->kycService->find($id, false);
        } catch (\Throwable $e) {
            $this->logger->error('admin.kyc.find.failed', [
                'id' => $id,
                'error' => $e->getMessage()
            ]);
            $this->session->setFlash('error', 'خطا در بازیابی اطلاعات احراز هویت');
            redirect('/admin/kyc');
        }

        if (!$kyc) {
            $this->session->setFlash('error', 'درخواست KYC یافت نشد');
            redirect('/admin/kyc');
        }

        // 🛡️ FIX-M10-05 (گزارش ماژول ۱۰): GET دیگر قفلِ نوشتنی نمی‌گیرد — عملِ write
        // فقط از POST markAsReviewing (kyc.manage) انجام می‌شود. قبلاً باز کردنِ صفحه با
        // مجوزِ view-only (support) قفلِ ۳۰ دقیقه‌ای می‌گرفت و reviewerِ مجاز را از
        // تصمیم‌گیری بازداشت می‌کرد (GET با side effect).
        // Refetch record with updated lock columns
        try {
            $kyc = $this->kycService->find($id, false);
        } catch (\Throwable $e) {
            $this->session->setFlash('error', 'خطا در بازیابی اطلاعات احراز هویت');
            redirect('/admin/kyc');
        }

        if ($kyc === null) {
            $this->session->setFlash('error', 'رکورد احراز هویت یافت نشد');
            redirect('/admin/kyc');
        }
        $user = $this->userService->find(int_value($kyc->user_id ?? 0));
        // وضعیتِ قفلِ فعلی برای نمایش در ویو (فقط خواندنی)
        $lockInfo = [
            'locked' => !empty($kyc->under_review_by),
            'by_me'  => !empty($kyc->under_review_by) && (int)$kyc->under_review_by === $this->requireAdminId(),
            'owner'  => $kyc->under_review_by ? (int)$kyc->under_review_by : null,
            'stale'  => !empty($kyc->review_started_at) && (strtotime((string)$kyc->review_started_at) < time() - 30 * 60),
            'started_at' => $kyc->review_started_at ?? null,
        ];

        // Photoshop check (اگر فایل موجود باشد)
        $photoshopCheck = ['suspicious' => false, 'reasons' => []];
        if (!empty($kyc->verification_image) && $kyc->verification_image !== '[DELETED]') {
            // Whitelist approach
            $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '', basename($kyc->verification_image));
            $uploadPath = base_path('storage/uploads/kyc/' . $filename);

            // Verify it's inside the intended directory (Issue #25 Fix)
            $realPath = realpath($uploadPath);
            $allowedDir = realpath(base_path('storage/uploads/kyc/'));

            if ($realPath !== false && $allowedDir !== false) {
                $allowedDirFormatted = rtrim($allowedDir, '/\\') . DIRECTORY_SEPARATOR;
                if ((str_starts_with($realPath, $allowedDirFormatted) || $realPath === rtrim($allowedDir, '/\\')) && file_exists($realPath) && is_file($realPath)) {
                    $photoshopCheck = $this->kycService->detectPhotoshop($realPath);
                }
            }
        }

        echo view('admin.kyc.review', [
            'kyc' => $kyc,
            'user' => $user,
            'photoshopCheck' => $photoshopCheck,
            'lockInfo' => $lockInfo,
            // 🛡️ FIX-M10-H12: ردیف‌های واقعیِ مدرک برای نمایشِ نوعِ مدرک در review
            'kycDocs' => $this->kycService->getDocuments((int)$kyc->id),
        ]);
    }

    // ✅ Verify: Form-based → Redirect + Flash
public function verify(int $id): void
{
    // لاگ اجرای متد
    $this->logger->info('admin.kyc.verify.hit', [
        'channel' => 'admin_kyc',
        'kyc_id' => $id,
        'admin_id' => $this->requireAdminId(),
    ]);

    $result = $this->kycService->verifyKYC($id, $this->requireAdminId());

    $this->response->json([
        'success' => (bool)($result['success'] ?? false),
        'message' => $result['message'] ?? 'نتیجه بررسی',
        'redirect' => url('/admin/kyc')
    ], ($result['success'] ?? false) ? 200 : 400);
}

    // ✅ Reject: Ajax JSON
    public function reject(int $id): void
    {
        $data = $this->request->json();
        if (!$data) {
            $data = $this->request->body();
        }
        if (!$data) {
            $this->response->json(['success' => false, 'message' => 'داده نامعتبر'], 400);
            return;
        }

        $validator = $this->validatorFactory->make($data, [
            'reason' => 'required|min:10'
        ]);

        if ($validator->fails()) {
            $this->response->json(['success' => false, 'errors' => $validator->errors()], 422);
            return;
        }

        $result = $this->kycService->rejectKYC(
            $id,
            $this->requireAdminId(),
            trim(str_value($data['reason'] ?? ''))
        );

        $this->response->json([
            'success' => (bool)($result['success'] ?? false),
            'message' => $result['message'] ?? 'خطا',
            'redirect' => url('/admin/kyc')
        ], ($result['success'] ?? false) ? 200 : 400);
    }

    public function deleteImage(int $id): void
    {
        $kyc = $this->kycService->find($id, false);
        if (!$kyc) {
            $this->response->json(['success' => false, 'message' => 'درخواست KYC یافت نشد'], 404);
            return;
        }

        $deletedFile = false;
        $fileFound = false;
        $unlinkFailed = false;
        $image = (string)($kyc->verification_image ?? '');
        if ($image !== '' && $image !== '[DELETED]') {
            $filename = basename($image);
            $candidates = [
                base_path('storage/uploads/kyc/' . $filename),
                base_path('storage/uploads/kyc-verification/' . $filename),
                base_path('storage/uploads/' . ltrim($image, '/')),
            ];
            foreach ($candidates as $path) {
                $real = realpath($path);
                $uploads = realpath(base_path('storage/uploads'));
                if ($real && $uploads && str_starts_with($real, $uploads . DIRECTORY_SEPARATOR) && is_file($real)) {
                    $fileFound = true;
                    // 🛡️ FIX-M10-07 (گزارش ماژول ۱۰): نتیجهٔ unlink واقعاً سنجیده می‌شود —
                    // قبلاً @unlink بی‌سنجش بود و بلافاصله deletedFile=true می‌گذاشت؛ شکستِ
                    // permission/IO فایلِ مدرک را یتیم می‌گذاشت و پاسخِ موفقیتِ جعلی می‌داد.
                    if (@unlink($real)) {
                        $deletedFile = true;
                    } else {
                        $unlinkFailed = true;
                        $this->logger->error('admin.kyc.unlink_failed', [
                            'kyc_id' => $id,
                            'path'   => $real,
                            'error'  => error_get_last()['message'] ?? 'unlink returned false',
                        ]);
                    }
                }
            }
        }

        // 🛡️ FIX-M10-07: اگر فایل وجود داشت ولی حذف نشد، ستونِ DB [DELETED] نمی‌شود —
        // مسیر حفظ می‌ماند تا retry/re-scan ممکن باشد؛ پاسخ هم شکستِ واقعی می‌گوید.
        if ($unlinkFailed) {
            $this->response->json([
                'success' => false,
                'message' => 'حذف فایل مدرک از دیسک ناموفق بود؛ رکورد دست‌نخورده ماند تا مجدداً تلاش شود.',
                'file_deleted' => false,
            ], 500);
            return;
        }

        $ok = $this->kycService->deleteVerificationImage($id);
        // BUGFIX-CTRL-RAW-SQL-2026-06: kyc_documents cleanup encapsulated in model.
        $this->kycService->deleteDocuments($id);

        $this->response->json([
            'success' => (bool)$ok,
            'message' => $ok ? 'تصویر KYC حذف شد' : 'خطا در حذف تصویر',
            'file_deleted' => $deletedFile,
        ], $ok ? 200 : 500);
    }

    public function markAsReviewing(int $id): void
    {
        $adminId = (int)$this->requireAdminId();
        $ok = $this->kycService->lockForReview($id, $adminId, 30);
        // 🛡️ FIX-M10-UX (راند ۱۸): فرمِ غیر-AJAX به‌جای JSON خام، ریدایرکت با پیام
        // flash می‌گیرد؛ فراخوانیِ fetch (AJAX) همچنان JSON دریافت می‌کند.
        if (!is_ajax()) {
            $this->session->setFlash(
                $ok ? 'success' : 'error',
                $ok ? 'درخواست در وضعیت بررسی قرار گرفت' : 'این درخواست در حال بررسی توسط ادمین دیگری است'
            );
            redirect('/admin/kyc/review/' . $id);
        }
        $this->response->json([
            'success' => (bool)$ok,
            'message' => $ok ? 'درخواست در وضعیت بررسی قرار گرفت' : 'این درخواست در حال بررسی توسط ادمین دیگری است',
            'redirect' => url('/admin/kyc/review/' . $id),
        ], $ok ? 200 : 409);
    }

}

