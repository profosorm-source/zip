<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\DatabaseAnalyzerService;

class DatabaseHealthController extends BaseAdminController
{
    private DatabaseAnalyzerService $dbAnalyzer;

    public function __construct(
        DatabaseAnalyzerService $dbAnalyzer,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->dbAnalyzer = $dbAnalyzer;
    }

    public function index(): void
    {
        $slowQueries  = [];
        $deadlocks    = [];
        $tableStats   = [];
        $healthChecks = [];
        $indexRecs    = [];
        $connStats    = [];
        $error        = null;

        try {
            $slowQueries  = $this->dbAnalyzer->getSlowQueries(30);
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $error = 'خطا در واکشی کوئری‌های کند: ' . $e->getMessage();
        }

        try {
            $deadlocks = $this->dbAnalyzer->getDeadlockInfo();
        } catch (\Throwable) {}

        try {
            $tableStats = $this->dbAnalyzer->getTableStats();
        } catch (\Throwable) {}

        try {
            $healthChecks = $this->dbAnalyzer->healthCheck();
        } catch (\Throwable) {}

        try {
            $connStats = $this->dbAnalyzer->getConnectionStats();
        } catch (\Throwable) {}

        // Get index recommendations for top tables (largest first)
        $topTables = array_slice($tableStats, 0, 5);
        try {
            foreach ($topTables as $tbl) {
                $tblName = $tbl->table_name ?? $tbl->TABLE_NAME ?? '';
                if ($tblName) {
                    $recs = $this->dbAnalyzer->getIndexRecommendations($tblName);
                    if (!empty($recs)) {
                        $indexRecs[$tblName] = $recs;
                    }
                }
            }
        } catch (\Throwable) {}

        $this->view('admin/database-health', [
            'title'         => 'سلامت دیتابیس',
            'slowQueries'   => $slowQueries,
            'deadlocks'     => $deadlocks,
            'tableStats'    => $tableStats,
            'healthChecks'  => $healthChecks,
            'indexRecs'     => $indexRecs,
            'connStats'     => $connStats,
            'error'         => $error,
        ]);
    }
}
