<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\DatabaseAnalyzerService;

class DatabaseHealthController extends BaseAdminController
{
    private DatabaseAnalyzerService $dbAnalyzer;

    public function __construct(
        DatabaseAnalyzerService $dbAnalyzer,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->dbAnalyzer = $dbAnalyzer;
    }

    public function index(): void
    {
        $slowQueries  = [];
        $deadlocks    = [];
        $tableStats   = [];
        $healthChecks = [];
        $indexRecs    = [];
        $connStats    = [];
        $error        = null;

        try {
            $slowQueries  = $this->dbAnalyzer->getSlowQueries(30);
        } catch (\Throwable $e) {
            // FIX-R36-W3 (F-A15-11): پیام خام PDO/استثنا (host/SQL/کدِ درایور) به صفحهٔ
            // ادمین درز می‌کرد (خانوادهٔ F-A3-07). پیام کامل در لاگ + شناسهٔ همبستگی؛
            // صفحه فقط پیام عمومی + شناسه را نشان می‌دهد.
            $correlationId = 'dbhealth_' . bin2hex(random_bytes(4));
            logger()->error('db_health.slow_queries_failed', [
                'correlation_id' => $correlationId,
                'error' => $e->getMessage(),
                'exception' => get_class($e),
            ]);
            $error = 'خطا در واکشی کوئری‌های کند. شناسهٔ رخداد برای پیگیری: ' . $correlationId;
        }

        try {
            $deadlocks = $this->dbAnalyzer->getDeadlockInfo();
        } catch (\Throwable $e) {
            logger()->warning('db_health.deadlocks_failed', ['error' => $e->getMessage()]);
        }

        try {
            $tableStats = $this->dbAnalyzer->getTableStats();
        } catch (\Throwable $e) {
            logger()->warning('db_health.table_stats_failed', ['error' => $e->getMessage()]);
        }

        try {
            $healthChecks = $this->dbAnalyzer->healthCheck();
        } catch (\Throwable $e) {
            logger()->warning('db_health.health_check_failed', ['error' => $e->getMessage()]);
        }

        try {
            $connStats = $this->dbAnalyzer->getConnectionStats();
        } catch (\Throwable $e) {
            logger()->warning('db_health.conn_stats_failed', ['error' => $e->getMessage()]);
        }

        // Get index recommendations for top tables (largest first)
        $topTables = array_slice($tableStats, 0, 5);
        try {
        foreach ($topTables as $tbl) {
            $tblObj = (object)$tbl;
            $tblName = (string)($tblObj->table_name ?? $tblObj->TABLE_NAME ?? '');
            if ($tblName) {
                $recs = $this->dbAnalyzer->getIndexRecommendations($tblName);
                if (!empty($recs)) {
                    $indexRecs[$tblName] = $recs;
                }
            }
        }
        } catch (\Throwable $e) {
            logger()->warning('db_health.index_recs_failed', ['error' => $e->getMessage()]);
        }

        $this->view('admin/database-health', [
            'title'         => 'سلامت دیتابیس',
            'slowQueries'   => $slowQueries,
            'deadlocks'     => $deadlocks,
            'tableStats'    => $tableStats,
            'healthChecks'  => $healthChecks,
            'indexRecs'     => $indexRecs,
            'connStats'     => $connStats,
            'error'         => $error,
        ]);
    }
}
