<?php
namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseAdminController;
use App\Services\Settings\AppSettings;

/**
 * Maintenance Mode Controller
 * 
 * مدیریت حالت تعمیر
 */
class MaintenanceController extends BaseAdminController
{
    private AppSettings $appSettings;

    public function __construct(
        AppSettings $appSettings,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->appSettings = $appSettings;
    }

    /**
     * فعالسازی Maintenance Mode
     */
    public function enable(Request $request, Response $response): Response
    {
        $this->appSettings->set('maintenance_mode', 'true');
        $this->appSettings->clearCache();

        $this->logger->info('Maintenance mode enabled', [
            'by_user' => $this->userId()
        ]);
        
        if (is_ajax()) {
            return $this->response->success('حالت تعمیر فعال شد.');
        }
        
        $this->session->setFlash('حالت تعمیر فعال شد.', 'success');
        return $this->response->back();
    }

    /**
     * غیرفعالسازی Maintenance Mode
     */
    public function disable(Request $request, Response $response): Response
    {
        $this->appSettings->set('maintenance_mode', 'false');
        $this->appSettings->clearCache();

        $this->logger->info('Maintenance mode disabled', [
            'by_user' => $this->userId()
        ]);
        
        if (is_ajax()) {
            return $this->response->success('حالت تعمیر غیرفعال شد.');
        }
        
        $this->session->setFlash('حالت تعمیر غیرفعال شد.', 'success');
        return $this->response->back();
    }


    /**
     * وضعیت فعلی
     */
    public function status(Request $request, Response $response): Response
    {
        $isEnabled = $this->appSettings->get('maintenance_mode', 'false') === 'true';
        
        return $this->response->json([
            'success' => true,
            'maintenance_mode' => $isEnabled
        ]);
    }
}