<?php
namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseAdminController;
use App\Services\Settings\AppSettings;
use App\Services\Settings\SettingsManager;

/**
 * Maintenance Mode Controller
 * 
 * مدیریت حالت تعمیر
 */
class MaintenanceController extends BaseAdminController
{
    private AppSettings $appSettings;
    private SettingsManager $settingsManager;

    public function __construct(
        AppSettings $appSettings,
        SettingsManager $settingsManager,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->appSettings = $appSettings;
        $this->settingsManager = $settingsManager;
    }

    /** فعالسازی Maintenance Mode */
    public function enable(): void
    {
        $adminId = $this->requireAdminId();

        // FIX راند ۷۸ (X308): AppSettings::set فقط runtime-cache می‌نویسد و persist
        // نمی‌کند؛ با clearCache() بلافاصله هم بی‌اثر می‌شد (درخواست بعدی از DB
        // می‌خواند) → toggle تعمیر بین پروسه‌ها هرگز ذخیره نمی‌شد. اکنون از
        // SettingsManager::set (تراکنش + رویداد + upsert واقعی) با قرارداد پنل
        // ('1'/'0' هم‌سان با type=boolean کاتالوگ) استفاده می‌شود.
        if (!$this->settingsManager->set('maintenance_mode', '1')) {
            $this->logger->error('Maintenance mode persist failed', ['by_user' => $adminId]);
            if (function_exists('is_ajax') && is_ajax()) {
                $this->response->json(['success' => false, 'message' => 'ذخیرهٔ حالت تعمیر ناموفق بود.'], 500);
                return;
            }
            $this->session->setFlash('ذخیرهٔ حالت تعمیر ناموفق بود.', 'error');
            $this->response->back();
            return;
        }
        $this->appSettings->clearCache();

        $this->logger->info('Maintenance mode enabled', [
            'by_user' => $adminId
        ]);
        
        if (function_exists('is_ajax') && is_ajax()) {
            $this->response->json(['success' => true, 'message' => 'حالت تعمیر فعال شد.']);
            return;
        }
        
        $this->session->setFlash('حالت تعمیر فعال شد.', 'success');
        $this->response->back();
    }

    /** غیرفعالسازی Maintenance Mode */
    public function disable(): void
    {
        $adminId = $this->requireAdminId();

        // FIX راند ۷۸ (X308): همان اصلاح enable — persist واقعی با SettingsManager.
        if (!$this->settingsManager->set('maintenance_mode', '0')) {
            $this->logger->error('Maintenance mode persist failed', ['by_user' => $adminId]);
            if (function_exists('is_ajax') && is_ajax()) {
                $this->response->json(['success' => false, 'message' => 'ذخیرهٔ حالت تعمیر ناموفق بود.'], 500);
                return;
            }
            $this->session->setFlash('ذخیرهٔ حالت تعمیر ناموفق بود.', 'error');
            $this->response->back();
            return;
        }
        $this->appSettings->clearCache();

        $this->logger->info('Maintenance mode disabled', [
            'by_user' => $adminId
        ]);
        
        if (function_exists('is_ajax') && is_ajax()) {
            $this->response->json(['success' => true, 'message' => 'حالت تعمیر غیرفعال شد.']);
            return;
        }
        
        $this->session->setFlash('حالت تعمیر غیرفعال شد.', 'success');
        $this->response->back();
    }

    /** وضعیت فعلی */
    public function status(): void
    {
        // 🛡️ X306: get() مقدار cast‌شده (bool برای رکوردهای type=boolean) برمی‌گرداند؛
        // مقایسهٔ === 'true' همیشه false بود و وضعیت‌سنجی دروغ می‌گفت.
        // filter_var هر دو قرارداد ('true'/'false' کنترلر و '1'/'0' پنل) را می‌فهمد.
        $raw = $this->appSettings->get('maintenance_mode', false);
        $isEnabled = is_bool($raw)
            ? $raw
            : filter_var(str_value($raw), FILTER_VALIDATE_BOOLEAN);

        $this->response->json([
            'success' => true,
            'maintenance_mode' => $isEnabled
        ]);
    }
}
