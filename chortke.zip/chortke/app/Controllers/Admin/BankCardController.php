<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseAdminController;
use App\Services\AuditTrail;
use App\Services\BankCardService;
use Core\Logger;

class BankCardController extends BaseAdminController
{
    // $logger inherited from parent
    private BankCardService $bankCardService;
    /** 🧹 DI-CLEANUP (2026-08-24): به‌جای app(UserService::class) در بدنه‌ی متد. */
    private \App\Services\User\UserService $userService;

    public function __construct(
        Logger $logger,
        AuditTrail $auditTrail,
        BankCardService $bankCardService,
        \App\Services\User\UserService $userService
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->logger = $logger;
        // $auditTrail به پراپرتی protected کلاس پایه (BaseAdminController با #[Inject]) تخصیص می‌یابد.
        $this->auditTrail = $auditTrail;
        $this->bankCardService = $bankCardService;
        $this->userService = $userService;
    }

    public function index(): string
    {
        try {
            // اگر متد خاص در مدل شما فرق دارد همینجا اسمش را عوض کن
            $cards = $this->bankCardService->getPendingCards(100, 0);

            return view('admin.bank-cards.index', [
                'cards' => $cards
            ]);
        } catch (\Throwable $e) {
            $this->logger->error('admin.bank_cards.index.failed', [
                'channel' => 'admin',
                'error' => $e->getMessage(),
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
            return view('errors.500');
        }
    }

    public function verify(): void
    {
        $id = int_value($this->request->input('id') ?? $this->request->input('card_id') ?? $this->request->get('id') ?? $this->request->param('id') ?? 0);

        try {
            if ($id <= 0) {
                $this->session->setFlash('error', 'شناسه کارت نامعتبر است');
                redirect('/admin/bank-cards');
            }

            $adminId = (int)user_id();
            $result = $this->bankCardService->adminVerify($adminId, $id, true, null);

            if (!empty($result['success'])) {
                $card = $this->bankCardService->findById($id);
                
                $this->auditTrail->record(
                    'bank_card.verified',
                    $card->user_id ?? null,
                    [
                        'channel' => 'wallet',
                        'card_id' => $id,
                        'admin_id' => $adminId,
                    ],
                    $adminId
                );

                $this->logger->activity(
                    'bank_card.verified',
                    "تایید کارت بانکی #{$id}",
                    $adminId,
                    ['channel' => 'admin']
                );

                $this->response->json([
                    'success' => true,
                    'message' => $result['message'] ?? 'کارت با موفقیت تایید شد',
                    'redirect' => url('/admin/bank-cards')
                ]);
            } else {
                $this->response->json([
                    'success' => false,
                    'message' => $result['message'] ?? 'خطا در تایید کارت'
                ], 400);
            }
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) {
            $this->logger->error('admin.bank_card.verify.failed', [
                'channel' => 'admin',
                'card_id' => $id,
                'error' => $e->getMessage(),
            ]);

            $this->response->json([
                'success' => false,
                'message' => 'بروز خطای سیستمی در تایید کارت'
            ], 500);
        }
    }

    public function reject(): void
    {
        // FIX-S34-B14-F04 (گزارش بخش ۱۴): هر دو فرم استاندارد ادمین (index و review)
        // فیلد را با name="rejection_reason" می‌فرستند و JS همان FormData را بدون
        // نگاشت ارسال می‌کند؛ کنترلر فقط «reason» می‌خواند — دلیلِ پرشدهٔ ادمین خالی
        // دیده می‌شد، کارت رد نمی‌شد و پاسخ redirect/HTML به r.json() در JS می‌شکست.
        // اکنون هر دو نام خوانده می‌شوند و خطاهای ورودی هم با قرارداد JSON کلاینت
        // برمی‌گردند (تنها کلاینتِ واقعی این endpoint، همان fetch مبتنی بر JSON است).
        $id = int_value($this->request->input('id') ?? $this->request->input('card_id') ?? $this->request->get('id') ?? $this->request->param('id') ?? 0);
        $reason = trim(str_value(
            $this->request->input('rejection_reason')
            ?? $this->request->post('rejection_reason')
            ?? $this->request->input('reason')
            ?? $this->request->post('reason')
            ?? ''
        ));

        try {
            if ($id <= 0) {
                $this->response->json([
                    'success' => false,
                    'message' => 'شناسه کارت نامعتبر است'
                ], 400);
                return;
            }

            if ($reason === '') {
                $this->response->json([
                    'success' => false,
                    'message' => 'دلیل رد الزامی است'
                ], 422);
                return;
            }

            $adminId = (int)user_id();
            $result = $this->bankCardService->adminVerify($adminId, $id, false, $reason);

            if (!empty($result['success'])) {
                $card = $this->bankCardService->findById($id);

                $this->auditTrail->record(
                    'bank_card.rejected',
                    $card->user_id ?? null,
                    [
                        'channel' => 'wallet',
                        'card_id' => $id,
                        'admin_id' => $adminId,
                        'reason' => $reason,
                    ],
                    $adminId
                );

                $this->logger->activity(
                    'bank_card.rejected',
                    "رد کارت بانکی #{$id}",
                    $adminId,
                    ['channel' => 'admin', 'reason' => $reason]
                );

                $this->response->json([
                    'success' => true,
                    'message' => $result['message'] ?? 'کارت با موفقیت رد شد',
                    'redirect' => url('/admin/bank-cards')
                ]);
            } else {
                $this->response->json([
                    'success' => false,
                    'message' => $result['message'] ?? 'خطا در رد کردن کارت'
                ], 400);
            }
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) {
            $this->logger->error('admin.bank_card.reject.failed', [
                'channel' => 'admin',
                'card_id' => $id,
                'error' => $e->getMessage(),
            ]);

            $this->response->json([
                'success' => false,
                'message' => 'بروز خطای سیستمی در پردازش کارت'
            ], 500);
        }
    }

    public function review(): void
    {
        $id = int_value($this->request->get('id') ?? $this->request->param('id') ?? 0);
        if ($id <= 0) { redirect('/admin/bank-cards'); }
        $card = $this->bankCardService->findById($id);
        if (!$card) { $this->session->setFlash('error', 'کارت بانکی یافت نشد'); redirect('/admin/bank-cards'); }
        $user = null;
        try { $user = $this->userService->find((int)($card->user_id ?? 0)); } catch (\Throwable) {}
        view('admin.bank-cards.review', ['card' => $card, 'user' => $user, 'cardId' => $id]);
    }

}
