<?php

namespace App\Controllers\Admin;
use Core\Database;
use App\Services\User\UserService;

use App\Models\ReferralCommission;
use App\Services\Shared\ReferralService;
use App\Controllers\Admin\BaseAdminController;
use App\Contracts\WalletServiceInterface;

class ReferralController extends BaseAdminController
{
    private ReferralService $referralService;
    private UserService $userService;

    /**
     * R90 فاز N-4 — فهرست مجاز کلیدهای فرم تنظیمات (allowlist).
     * const عمومی‌سازی شد تا پراب با reflection بتواند شمارش/محتوا را گارد کند.
     * پرانِ ۷ کلیدِ بی‌مصرف (صفر مصرف‌کننده): referral_commission_task_percent،
     * referral_commission_investment_percent، referral_commission_vip_percent،
     * referral_commission_story_percent، referral_commission_min_payout،
     * referral_commission_min_payout_usdt، referral_commission_auto_pay —
     * فرم/کنترلر می‌نوشتند ولی هیچ خواننده‌ای در موتور (processCommission) نداشتند.
     */
    private const SETTINGS_KEYS = [
        'referral_commission_enabled',
        'referral_max_daily_signups',
        'referral_farming_threshold',
        'referral_farming_action',
        'referral_signup_bonus',
        'referral_signup_bonus_usdt',
        // R9 راند ۸۸ — موتور چندسطحی (opt-in) + نرخ هر سطح
        'referral_multitier_enabled',
        'referral_multitier_l1_percent',
        'referral_multitier_l2_percent',
        'referral_multitier_l3_percent',
        // R90 فاز N-4 — پاداش ماهانهٔ صدرنشین (opt-in؛ مصرف‌کننده: ReferralService::distributeMonthlyRewards)
        'referral_monthly_bonus_enabled',
    ];

    public function __construct(
        UserService $userService,
        ReferralService $referralService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->userService = $userService;
        $this->referralService = $referralService;
    }

    /**
     * لیست کمیسیون‌ها
     */
    public function index(): string
    {
        $filters = [
            'status'      => $this->request->get('status'),
            'source_type' => $this->request->get('source_type'),
            'currency'    => $this->request->get('currency'),
            'search'      => $this->request->get('search'),
        ];

        $page = \max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $commissions = $this->referralService->adminList($filters, $limit, $offset);
        $total = $this->referralService->adminCount($filters);
        
        $stats = $this->referralService->globalStats();
        $topReferrers = $this->referralService->topReferrers('irt', 5);

        // X366 — صدرنشین ماه قبل (دلیگیت سرویس به مدل؛ بدون SQL خام در کنترلر)
        $prevTopReferrer = $this->referralService->previousMonthLeader();

        $this->logger->activity('referrals.view', 'مشاهده لیست کمیسیون‌ها', $this->requireAdminId(), []);

        return view('admin.referral.index', [
            'commissions'   => $commissions,
            'total'         => $total,
            'page'          => $page,
            'pages'         => \ceil($total / $limit),
            'filters'       => $filters,
            'stats'         => $stats,
            'topReferrers'  => $topReferrers,
            'prevTopReferrer' => $prevTopReferrer,
            'sourceTypes'   => $this->referralService->getSourceTypes(),
        ]);
    }

    /**
     * تنظیمات کمیسیون
     */
    public function settings(): string
    {

        return view('admin.referral.settings', [
            'sourceTypes' => $this->referralService->getSourceTypes(),
        ]);
    }

    /**
     * ذخیره تنظیمات کمیسیون
     *
     * FIX-18Q (P2-18): تا پیش از این ۱۱ کلید بدون هیچ اعتبارسنجیِ عددی/دامنه‌ای
     * در DB ذخیره می‌شدند (مثلاً درصد چندسطحی ۵۰۰٪ یا اکشن نامعتبر) و همان مقدار
     * خراب مستقیم به موتور کمیسیون/ReferralAntiFarmingGate می‌رفت. کاتالوگ دامنه‌ها
     * از پیش‌فرض‌های سرویس/گیت (ReferralAntiFarmingGate: cap=5, threshold=10,
     * action∈{warn,block,ban}) گرفته شده است.
     */
    public function saveSettings(): void
    {
        // R90 فاز N-4 — حلقه از self::SETTINGS_KEYS می‌خواند؛ هر کلیدی خارج از این
        // فهرست (از جمله ۷ کلید پران‌شده) در payload حتی اگر ارسال شود نادیده گرفته می‌شود.
        $updated = [];
        $settings = [];

        // FIX-18Q (P2-18): کاتالوگ دامنهٔ مجاز هر کلید.
        $boolKeys = ['referral_commission_enabled', 'referral_multitier_enabled', 'referral_monthly_bonus_enabled'];
        $percentKeys = ['referral_multitier_l1_percent', 'referral_multitier_l2_percent', 'referral_multitier_l3_percent'];
        $positiveIntKeys = ['referral_max_daily_signups', 'referral_farming_threshold'];
        $amountKeys = ['referral_signup_bonus', 'referral_signup_bonus_usdt'];

        foreach (self::SETTINGS_KEYS as $key) {
            $value = $this->request->post($key);
            if ($value === null) {
                continue;
            }

            // FIX-18Q (P2-18): اعتبارسنجی بر اساس دستهٔ کلید.
            if (in_array($key, $boolKeys, true)) {
                if (!in_array(str_value($value), ['0', '1'], true)) {
                    $this->session->setFlash('error', 'مقدار کلید «' . $key . '» باید فعال (۱) یا غیرفعال (۰) باشد.');
                    redirect(url('/admin/referral/settings'));
                }
            } elseif (in_array($key, $percentKeys, true)) {
                $num = $this->normalizedNumeric($value);
                if ($num === null || $num < 0 || $num > 100) {
                    $this->session->setFlash('error', 'درصد کمیسیون «' . $key . '» باید عددی بین ۰ تا ۱۰۰ باشد.');
                    redirect(url('/admin/referral/settings'));
                }
            } elseif (in_array($key, $positiveIntKeys, true)) {
                $num = filter_var(str_value($value), FILTER_VALIDATE_INT);
                if ($num === false || $num < 1 || $num > 100000) {
                    $this->session->setFlash('error', 'مقدار «' . $key . '» باید عدد صحیح مثبت باشد (بین ۱ تا ۱۰۰۰۰۰).');
                    redirect(url('/admin/referral/settings'));
                }
            } elseif (in_array($key, $amountKeys, true)) {
                $num = $this->normalizedNumeric($value);
                if ($num === null || $num < 0 || $num > 1e9) {
                    $this->session->setFlash('error', 'مبلغ «' . $key . '» باید عددی بزرگ‌تر یا مساوی صفر باشد.');
                    redirect(url('/admin/referral/settings'));
                }
            } elseif ($key === 'referral_farming_action') {
                if (!in_array(str_value($value), ['warn', 'block', 'ban'], true)) {
                    $this->session->setFlash('error', 'اقدام فارمینگ باید یکی از مقادیر warn، block یا ban باشد.');
                    redirect(url('/admin/referral/settings'));
                }
            }

            $updated[$key] = $value;
            $settings[$key] = str_value($value);
        }

        $this->referralService->saveSettings($settings);
        $adminId = $this->requireAdminId();
        $this->logger->activity('referrals.settings_updated', 'بروزرسانی تنظیمات کمیسیون', $adminId, $updated);

        $this->session->setFlash('success', 'تنظیمات کمیسیون با موفقیت ذخیره شد.');
        redirect(url('/admin/referral/settings'));
    }

    /**
     * FIX-18Q (P2-18): نرمال‌سازی عددی با پذیرش فرمت‌های رایج فارسی/لاتین و
     * بازگشت float معتبر یا null (برای ردِ مقادیر غیرعددی مثل "abc").
     */
    private function normalizedNumeric(mixed $value): ?float
    {
        $raw = trim(str_value($value));
        if ($raw === '') {
            return null;
        }
        // ارقام فارسی/عربی → لاتین
        $raw = strtr($raw, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
            '٫' => '.', '،' => '', ',' => '',
        ]);
        if (!is_numeric($raw)) {
            return null;
        }
        $num = (float)$raw;
        return is_finite($num) ? $num : null;
    }

    /**
     * جزئیات کمیسیون‌های یک کاربر
     */
    public function userDetail(): string
    {
        $userId = $this->request->int('id');

        $user = $this->userService->find($userId);

        if (!$user) {
            \http_response_code(404);
            include __DIR__ . '/../../../views/errors/404.php';
            exit;
        }

        $stats = $this->referralService->getReferrerStats($userId);
        $referredUsers = $this->referralService->getReferredUsers($userId, 50, 0);
        $commissions = $this->referralService->getByReferrer($userId, [], 50, 0);
        $referredCount = $this->referralService->countReferredUsers($userId);

        return view('admin.referral.user-detail', [
            'user'          => $user,
            'stats'         => $stats,
            'referredUsers' => $referredUsers,
            'commissions'   => $commissions,
            'referredCount' => $referredCount,
        ]);
    }

    /**
     * لغو کمیسیون (Ajax)
     */
    public function cancel(): void
    {

                
        $id = $this->request->int('id');
        $decodedBody = json_decode((file_get_contents('php://input') ?: ''), true);
        $body = is_array($decodedBody) ? $decodedBody : [];

        // 📜 قرارداد واحد ورودی (RULES §۱۸)
        $reasonRequest = new \App\Validators\Requests\AdminActionReasonRequest($body);
        if (!$reasonRequest->validate()) {
            $this->response->json(['success' => false, 'message' => 'اطلاعات ورودی نامعتبر است', 'errors' => $reasonRequest->errors()], 422);
            return;
        }
        $reason = str_value($reasonRequest->safeValidated()['reason'] ?? '') ?: 'لغو توسط مدیر';

        $service = $this->referralService;
        $cancelled = $service->cancelCommission($id, $reason);

        if (!$cancelled) {
            $this->response->json([
                'success' => false,
                'message' => 'امکان لغو این کمیسیون وجود ندارد. فقط کمیسیون‌های در انتظار قابل لغو هستند.',
            ], 422);
            return;
        }

        $this->logger->activity('referrals.commission_cancelled', 'لغو کمیسیون', $this->requireAdminId(), [
            'commission_id' => $id,
            'reason'        => $reason,
        ]);

        $this->response->json([
            'success' => true,
            'message' => 'کمیسیون با موفقیت لغو شد.',
        ]);
    }

    /**
     * پرداخت دسته‌ای (Ajax)
     */
    public function batchPay(): void
    {
        $decodedBody = json_decode((file_get_contents('php://input') ?: ''), true);
        $body = is_array($decodedBody) ? $decodedBody : [];

        // 📜 قرارداد واحد ورودی + الفبای ارز (RULES §۱۸)
        $currencyRequest = new \App\Validators\Requests\CurrencySelectionRequest($body);
        if (!$currencyRequest->validate()) {
            $this->response->json(['success' => false, 'message' => 'ارز نامعتبر', 'errors' => $currencyRequest->errors()], 422);
            return;
        }
        $currency = str_value($currencyRequest->safeValidated()['currency'] ?? '') ?: 'irt';

        $service = $this->referralService;
        $results = $service->batchPay($currency);

        if (!empty($results['locked'])) {
            $this->response->json([
                'success' => false,
                'message' => 'پرداخت دسته‌ای برای این ارز در حال حاضر در حال اجراست. لطفا چند لحظه دیگر دوباره تلاش کنید.'
            ], 409);
            return;
        }

        $adminId = $this->requireAdminId();
        $this->logger->activity('referrals.batch_pay', 'پرداخت دسته‌ای کمیسیون', $adminId, $results);

        $this->response->json([
            'success' => true,
            'message' => "پرداخت دسته‌ای انجام شد: " . int_value($results['success'] ?? 0) . " موفق، " . int_value($results['failed'] ?? 0) . " ناموفق، " . int_value($results['skipped'] ?? 0) . " رد شده",
            'results' => $results,
        ]);
    }
}