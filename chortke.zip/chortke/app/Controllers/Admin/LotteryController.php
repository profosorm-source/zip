<?php
// app/Controllers/Admin/LotteryController.php

namespace App\Controllers\Admin;

use Core\Response;

use App\Models\LotteryRound;
use App\Models\LotteryParticipation;
use App\Models\LotteryDailyNumber;
use App\Models\LotteryChanceLog;
use App\Services\Lottery\LotteryService;
use App\Validators\Requests\LotteryRoundRequest;
use App\Controllers\Admin\BaseAdminController;

class LotteryController extends BaseAdminController
{
    private \App\Models\LotteryRound $lotteryRoundModel;
    private \App\Models\LotteryParticipation $lotteryParticipationModel;
    private \App\Models\LotteryDailyNumber $lotteryDailyNumberModel;
    private LotteryService $lotteryService;
    private \App\Models\User $userModel;

    public function __construct(
        \App\Models\LotteryDailyNumber $lotteryDailyNumberModel,
        \App\Models\LotteryParticipation $lotteryParticipationModel,
        \App\Models\LotteryRound $lotteryRoundModel,
        \App\Services\Lottery\LotteryService $lotteryService,
        \App\Models\User $userModel,
        ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->lotteryService = $lotteryService;
        $this->lotteryDailyNumberModel = $lotteryDailyNumberModel;
        $this->lotteryParticipationModel = $lotteryParticipationModel;
        $this->lotteryRoundModel = $lotteryRoundModel;
        $this->userModel = $userModel;
    }

    public function index(): string
    {
        $filters = ['status' => $this->request->get('status')];
        $page = \max(1, $this->request->int('page', 1));
        $perPage = 15;
        $offset = ($page - 1) * $perPage;

        $result = $this->lotteryService->listRounds($filters, $perPage, $offset);
        // FIX-X26: سرویس listRounds آرایهٔ {items, total} برمی‌گرداند؛ کنترلر کلید
        // 'rounds' را می‌خواند → جدول همیشه «دوره‌ای یافت نشد» با KPI غیرصفر بود.
        $rounds = $result['items'] ?? $result['rounds'] ?? [];
        $total = $result['total'] ?? 0;
        $totalPages = \ceil($total / $perPage);
        $stats = $this->lotteryService->getStats();

        $roundIds = \array_map(fn($r) => (int)($r->id ?? 0), $rounds);
        $participationCounts = [];
        if (count($roundIds) > 0) {
            $participationCounts = $this->lotteryService->getParticipationCounts($roundIds);
            foreach ($roundIds as $rid) {
                if (!isset($participationCounts[$rid])) {
                    $participationCounts[$rid] = 0;
                }
            }
        }

        return view('admin.lottery.index', [
            'user' => user(),
            'rounds' => $rounds,
            'stats' => $stats,
            'total' => $total,
            'totalPages' => $totalPages,
            'currentPage' => $page,
            'filters' => $filters,
            'participationCounts' => $participationCounts,
        ]);
    }

    public function create(): string
    {
        return view('admin.lottery.create', ['user' => user()]);
    }

    public function store(): void
    {
        $input = is_array($this->request->input()) ? $this->request->input() : [];

        $request = new LotteryRoundRequest($input);
        if (!$request->validate()) {
            $this->response->json(['success' => false, 'errors' => $request->errors()], 422);
        }

        // FIX-X11 (بحرانی): Validator::data() کل ورودی خام را برمی‌گرداند — شامل
        // _csrf_token و prize_description — و createRound آن را مستقیم INSERT می‌کرد
        // → «Unknown column '_csrf_token' in 'INSERT INTO'» → ساخت دوره از فرم ادمین
        // کاملاً شکسته بود. فیلدها صراحتاً whitelist می‌شوند.
        // FIX-X14: ستون‌های type/duration_days/prize_description با مایگریشن
        // 2026_08_30_0003 اضافه شدند و اکنون جزو whitelist مجازند (قبلاً فیلدهای
        // بی‌مصرف UI بودند و ذخیره نمی‌شدند — X9-باقی‌مانده).
        // FIX-X16: safeValidated به‌عنوان لایهٔ دوم دفاع؛ whitelist صریح زیر هم باقی است.
        $data = $request->safeValidated();
        $data = array_intersect_key($data, array_flip([
            'title','type','duration_days','prize_description',
            'prize_pool','prize_amount','ticket_price','max_capacity','currency',
            'entry_fee','start_date','end_date','status','draw_at',
        ]));
        if (isset($data['entry_fee']) && !isset($data['ticket_price'])) {
            $data['ticket_price'] = $data['entry_fee'];
        }
        $result = $this->lotteryService->createRound($this->requireAdminId(), $data);

        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    public function generateNumbers(int $id): void
    {
        $result = $this->lotteryService->generateDailyNumbers($id);

        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    public function finalizeDaily(int $did): void
    {
        $result = $this->lotteryService->finalizeDailyNumber($did);

        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    public function selectWinner(int $id): void
    {
        $result = $this->lotteryService->selectWinner($id, $this->requireAdminId());

        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    public function cancel(int $id): void
    {
        $result = $this->lotteryService->cancelRound($id, $this->requireAdminId());
        
        if (!$result['success']) {
            $this->response->json(['success' => false, 'message' => $result['message'] ?? 'دوره قابل لغو نیست.'], 422);
        }

        $this->logger->info('lottery_cancelled', ['message' => "Admin " . $this->requireAdminId() . " cancelled round #{$id}"]);

        $this->response->json(['success' => true, 'message' => 'دوره لغو شد.']);
    }

    public function show(int $id): string
    {
        $round = $this->lotteryRoundModel->find($id);
        if (!$round) { $this->session->setFlash('error', 'دوره قرعه‌کشی یافت نشد'); return redirect('/admin/lottery'); }
        // 🛡️ FIX-X224 (راند 59): جدول lottery_rounds فقط winner_user_id دارد و ستون
        // winner_name وجود ندارد — ویو بدون گارد می‌خواند و روی هر بازدید هشدار ثبت
        // می‌شد (ایسوی #3). نام واقعی برنده از جدول کاربران پیوست می‌شود.
        $round->winner_name = null;
        if (!empty($round->winner_user_id)) {
            try {
                $winner = $this->userModel->find((int) $round->winner_user_id);
                $round->winner_name = $winner->name ?? $winner->username ?? null;
            } catch (\Throwable) {}
        }
        $participantCount = 0;
        try { $participantCount = $this->lotteryParticipationModel->countByRound($id); } catch (\Throwable) {}
        $dailyNumbers = [];
        try { $dailyNumbers = $this->lotteryDailyNumberModel->getByRound($id); } catch (\Throwable) {}
        // FIX-X9: جدول شرکت‌کنندگان در ویو همیشه خالی بود — متغیر $participants هرگز
        // به ویو پاس داده نمی‌شد؛ اکنون با join نام کاربر خوانده می‌شود.
        $participants = [];
        try { $participants = $this->lotteryParticipationModel->getByRound($id); } catch (\Throwable) {}
        $distribution = ['high' => 0, 'medium' => 0, 'low' => 0];
        try {
            $dist = $this->lotteryParticipationModel->getChanceDistribution($id);
            $distribution = ['high' => $dist['high'], 'medium' => $dist['medium'], 'low' => $dist['low']];
        } catch (\Throwable) {}
        return view('admin.lottery.show', compact('round','participantCount','dailyNumbers','participants','distribution'));
    }

}
