<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\AntiFraud\FraudDetectionService;

/**
 * FraudController - مدیریت سیستم تشخیص تقلب
 */
class FraudController extends BaseAdminController
{
    private FraudDetectionService $fraudService;

    public function __construct(FraudDetectionService $fraudService, ?\App\Contracts\LoggerInterface $logger = null)
    {
        parent::__construct(null, null, null, null, $logger);
        $this->fraudService = $fraudService;
    }

    /**
     * گرفتن گزارش ریسک کاربر
     */
    public function getRiskReport(): void
    {
        $userId = (int) $this->request->get('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'User ID is required'
            ], 400);
        }

        try {
            $report = $this->fraudService->getRiskReport($userId);

            $this->response->json([
                'success' => true,
                'data' => $report
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->response->json([
                'success' => false,
                'message' => 'Failed to generate risk report: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * محاسبه مجدد امتیاز تقلب کاربر
     */
    public function recalculateScore(): void
    {
        $userId = (int) $this->request->post('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'User ID is required'
            ], 400);
        }

        try {
            $score = $this->fraudService->calculateFraudScore($userId);

            $this->response->json([
                'success' => true,
                'data' => [
                    'user_id' => $userId,
                    'fraud_score' => $score
                ]
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->response->json([
                'success' => false,
                'message' => 'Failed to recalculate fraud score: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * اجرای اقدامات خودکار بر اساس امتیاز
     */
    public function executeActions(): void
    {
        $userId = (int) $this->request->post('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'User ID is required'
            ], 400);
        }

        try {
            $actions = $this->fraudService->executeAutomatedActions($userId);

            $this->response->json([
                'success' => true,
                'data' => [
                    'user_id' => $userId,
                    'executed_actions' => $actions
                ]
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->response->json([
                'success' => false,
                'message' => 'Failed to execute automated actions: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * گرفتن لیست کاربران پر ریسک
     */
    public function getHighRiskUsers(): void
    {
        $minScore = (int) ($this->request->get('min_score') ?? 50);
        $limit = (int) ($this->request->get('limit') ?? 50);

        try {
            $users = $this->fraudService->getHighRiskUsers($minScore, $limit);

            $this->response->json([
                'success' => true,
                'data' => [
                    'users' => $users,
                    'count' => count($users),
                    'min_score' => $minScore
                ]
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->response->json([
                'success' => false,
                'message' => 'Failed to fetch high risk users: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * گرفتن لاگ‌های تقلب
     */
    public function getFraudLogs(): void
    {
        $userId = $this->request->get('user_id') ? (int) $this->request->get('user_id') : null;
        $fraudType = $this->request->get('fraud_type');
        $limit = (int) ($this->request->get('limit') ?? 100);

        try {
            $logs = $this->fraudService->getFraudLogs($userId, $fraudType, $limit);

            $this->response->json([
                'success' => true,
                'data' => [
                    'logs' => $logs,
                    'count' => count($logs)
                ]
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->response->json([
                'success' => false,
                'message' => 'Failed to fetch fraud logs: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * پاک کردن پرچم‌های بررسی
     */
    public function clearFlags(): void
    {
        $userId = (int) $this->request->post('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'User ID is required'
            ], 400);
        }

        try {
            $this->fraudService->clearUserFlags($userId);

            $this->response->json([
                'success' => true,
                'message' => 'Fraud flags cleared successfully'
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->response->json([
                'success' => false,
                'message' => 'Failed to clear flags: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * تعلیق دستی حساب
     */
    public function suspendUser(): void
    {
        $userId = (int) $this->request->post('user_id');
        $reason = trim($this->request->post('reason') ?? '');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'User ID is required'
            ], 400);
        }

        if (!$reason) {
            $this->response->json([
                'success' => false,
                'message' => 'Suspension reason is required'
            ], 400);
        }

        try {
            $this->fraudService->suspendUser($userId, $reason);

            $this->response->json([
                'success' => true,
                'message' => 'User suspended successfully'
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->response->json([
                'success' => false,
                'message' => 'Failed to suspend user: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * رفع تعلیق حساب
     */
    public function unsuspendUser(): void
    {
        $userId = (int) $this->request->post('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'User ID is required'
            ], 400);
        }

        try {
            $this->fraudService->unsuspendUser($userId);

            $this->response->json([
                'success' => true,
                'message' => 'User unsuspended successfully'
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->response->json([
                'success' => false,
                'message' => 'Failed to unsuspend user: ' . $e->getMessage()
            ], 500);
        }
    }
}