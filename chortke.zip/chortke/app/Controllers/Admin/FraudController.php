<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\AntiFraud\FraudDetectionService;

/**
 * FraudController - مدیریت سیستم تشخیص تقلب
 *
 * توجه: این کنترلر دیگر try/catch محلی برای خطاهای غیرمنتظره ندارد.
 * هرگونه Throwable که از سرویس‌ها بیرون بزند، به GlobalExceptionMiddleware
 * می‌رسد که پاسخ JSON استاندارد و امن (بدون نشت پیام داخلی/انگلیسی) تولید
 * و به‌درستی لاگ می‌کند.
 */
class FraudController extends BaseAdminController
{
    private FraudDetectionService $fraudService;

    /**
     * FIX-18Q (P2-16): مدل کاربر برای گارد سلسله‌مراتب نقش‌ها (suspend/unsuspend).
     * الگوی تزریق همان BaseAdminController (#[Inject] → Container::injectProperties).
     */
    #[\Core\Attributes\Inject]
    protected \App\Models\User $userModel;

    public function __construct(FraudDetectionService $fraudService, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->fraudService = $fraudService;
    }

    /**
     * گرفتن گزارش ریسک کاربر
     */
    public function getRiskReport(): void
    {
        // 🧭 FIX-X205 (راند ۵۵ — تعمیم کلاسِ باگ X202 به پنل ادمین): مرورگر → داشبورد تقلب؛ AJAX → JSON
        if (!is_ajax()) {
            redirect(url('/admin/fraud/dashboard'));
        }

        $userId = $this->request->int('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'شناسه کاربر الزامی است.'
            ], 400);
            return;
        }

        $report = $this->fraudService->getRiskReport($userId);

        $this->response->json([
            'success' => true,
            'data' => $report
        ]);
    }

    /**
     * محاسبه مجدد امتیاز تقلب کاربر
     */
    public function recalculateScore(): void
    {
        $userId = $this->request->int('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'شناسه کاربر الزامی است.'
            ], 400);
            return;
        }

        $score = $this->fraudService->calculateFraudScore($userId);

        // FIX-18Q (P2-16): عملیات حساسِ ضدتقلب بدون ردپای حسابرسی بود — الگوی auditLog پایه.
        $this->auditLog('fraud.score.recalculated', 'user', $userId, null, ['fraud_score' => $score]);

        $this->response->json([
            'success' => true,
            'data' => [
                'user_id' => $userId,
                'fraud_score' => $score
            ]
        ]);
    }

    /**
     * اجرای اقدامات خودکار بر اساس امتیاز
     */
    public function executeActions(): void
    {
        $userId = $this->request->int('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'شناسه کاربر الزامی است.'
            ], 400);
            return;
        }

        // FIX-R36-W2-F (F-A15-02): مسیر اقدامات خودکار هم مثل suspendUser دستی باید
        // از گارد سلسله‌مراتب FIX-18Q عبور کند — executeAutomatedActions در آستانهٔ
        // امتیازِ بالا suspendAccount را داخلاً اجرا می‌کند و بدون این گارد، ادمینِ
        // fraud.manage می‌توانست مدیر/سوپرادمین/خودش را از این مسیر معلق کند.
        // الگو: عین جفت گاردِ suspendUser (ممنوعیت خود + سلسله‌مراتب نقش‌ها).
        $adminId = $this->requireAdminId();
        if ($userId === $adminId) {
            $this->response->json(['success' => false, 'message' => 'شما نمی‌توانید اقدامات خودکار را روی حساب خودتان اجرا کنید'], 403);
            return;
        }
        if ($this->authorizeTargetForStatusChange($userId, 'اجرای اقدامات خودکار روی') === null) {
            return;
        }

        $actions = $this->fraudService->executeAutomatedActions($userId);

        // FIX-18Q (P2-16): اقدامات خودکارِ اعمال‌شده (تعلیق/محدودسازی/...) باید ردپای حسابرسی داشته باشند.
        $this->auditLog('fraud.actions.executed', 'user', $userId, null, ['executed_actions' => $actions]);

        $this->response->json([
            'success' => true,
            'data' => [
                'user_id' => $userId,
                'executed_actions' => $actions
            ]
        ]);
    }

    /**
     * گرفتن لیست کاربران پر ریسک
     */
    public function getHighRiskUsers(): void
    {
        // 🧭 FIX-X205: مرورگر → داشبورد تقلب؛ AJAX → JSON (قرارداد status())
        if (!is_ajax()) {
            redirect(url('/admin/fraud/dashboard'));
        }

        $minScore = $this->request->int('min_score', 50);
        $limit = min(100, max(1, $this->request->int('limit', 50)));

        $users = $this->fraudService->getHighRiskUsers($minScore, $limit);

        $this->response->json([
            'success' => true,
            'data' => [
                'users' => $users,
                'count' => count($users),
                'min_score' => $minScore
            ]
        ]);
    }

    /**
     * گرفتن لاگ‌های تقلب
     */
    public function getFraudLogs(): void
    {
        $userId = $this->request->int('user_id') ?: null;
        $fraudTypeRaw = $this->request->get('fraud_type');
        $fraudType = $fraudTypeRaw !== null ? str_value($fraudTypeRaw) : null;
        $limit = min(100, max(1, $this->request->int('limit', 100)));

        $logs = $this->fraudService->getFraudLogs($userId, $fraudType, $limit);

        $this->response->json([
            'success' => true,
            'data' => [
                'logs' => $logs,
                'count' => count($logs)
            ]
        ]);
    }

    /**
     * پاک کردن پرچم‌های بررسی
     */
    public function clearFlags(): void
    {
        $userId = $this->request->int('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'شناسه کاربر الزامی است.'
            ], 400);
            return;
        }

        $this->fraudService->clearUserFlags($userId);

        // FIX-18Q (P2-16): پاک‌کردن پرچم‌های تقلب یعنی بازنشانی سابقهٔ ریسک — باید حسابرسی شود.
        $this->auditLog('fraud.flags.cleared', 'user', $userId, null, ['flags_cleared' => true]);

        $this->response->json([
            'success' => true,
            'message' => 'پرچم‌های تقلب با موفقیت پاک شدند.'
        ]);
    }

    /**
     * FIX-18Q (P2-16): گارد سلسله‌مراتب نقش‌ها — الگوی دقیق UserController::suspend/ban.
     * ادمینِ غیر super_admin (سطح < 2) مجاز به تغییر وضعیتِ هیچ مدیری (سطح >= 1،
     * شامل super_admin) نیست؛ fraud.manage نباید بتواند super_admin را معلق کند.
     * هدف باید موجود و غیرحذف‌شده هم باشد؛ در غیر این صورت 404.
     *
     * @return \stdClass|null آبجکت هدف در صورت مجاز بودن؛ وگرنه پاسخ خطا صادر و null برگشت داده می‌شود.
     */
    private function authorizeTargetForStatusChange(int $targetUserId, string $actionFa): ?\stdClass
    {
        $target = $this->userModel->findById($targetUserId);
        if ($target === null || !isset($target->id)) {
            $this->response->json(['success' => false, 'message' => 'کاربر یافت نشد'], 404);
            return null;
        }

        $currentAdmin = $this->userModel->findById($this->requireAdminId());
        $hierarchy = ['user' => 0, 'admin' => 1, 'super_admin' => 2];
        $adminRoleLevel = $hierarchy[$currentAdmin->role ?? 'user'] ?? 0;
        $targetUserRoleLevel = $hierarchy[$target->role ?? 'user'] ?? 0;

        if ($adminRoleLevel < 2 && $targetUserRoleLevel >= 1) {
            $this->response->json(['success' => false, "message" => "شما مجاز به {$actionFa} سایر مدیران نیستید."], 403);
            return null;
        }

        return $target;
    }

    /**
     * تعلیق دستی حساب
     */
    public function suspendUser(): void
    {
        $userId = $this->request->int('user_id');
        $reason = trim(str_value($this->request->post('reason') ?? ''));

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'شناسه کاربر الزامی است.'
            ], 400);
            return;
        }

        if (!$reason) {
            $this->response->json([
                'success' => false,
                'message' => 'ذکر دلیل تعلیق الزامی است.'
            ], 400);
            return;
        }

        // FIX-18Q (P2-16): گارد سلسله‌مراتب + ممنوعیت تعلیق خود (الگوی UserController::suspend).
        $adminId = $this->requireAdminId();
        if ($userId === $adminId) {
            $this->response->json(['success' => false, 'message' => 'شما نمی‌توانید خودتان را تعلیق کنید'], 403);
            return;
        }
        $target = $this->authorizeTargetForStatusChange($userId, 'تعلیق');
        if ($target === null) {
            return;
        }

        $this->fraudService->suspendUser($userId, $reason);

        // FIX-18Q (P2-16): تعلیق دستی بدون ردپای حسابرسی بود — الگوی UserController::suspend.
        $this->auditLog(
            'fraud.user.suspended',
            'user',
            $userId,
            ['status' => (string)($target->status ?? '')],
            ['status' => 'suspended', 'reason' => $reason]
        );

        $this->response->json([
            'success' => true,
            'message' => 'کاربر با موفقیت تعلیق شد.'
        ]);
    }

    /**
     * رفع تعلیق حساب
     */
    public function unsuspendUser(): void
    {
        $userId = $this->request->int('user_id');

        if (!$userId) {
            $this->response->json([
                'success' => false,
                'message' => 'شناسه کاربر الزامی است.'
            ], 400);
            return;
        }

        // FIX-18Q (P2-16): گارد سلسله‌مراتب — رفع تعلیقِ مدیران فقط از دست super_admin.
        $target = $this->authorizeTargetForStatusChange($userId, 'تغییر وضعیت');
        if ($target === null) {
            return;
        }

        $this->fraudService->unsuspendUser($userId);

        // FIX-18Q (P2-16): رفع تعلیق بدون ردپای حسابرسی بود.
        $this->auditLog(
            'fraud.user.unsuspended',
            'user',
            $userId,
            ['status' => 'suspended'],
            ['status' => 'active']
        );

        $this->response->json([
            'success' => true,
            'message' => 'تعلیق کاربر با موفقیت رفع شد.'
        ]);
    }
}
