<?php

namespace App\Controllers\Admin;

use App\Models\BannerPlacement;
use App\Controllers\Admin\BaseAdminController;

class PlacementController extends BaseAdminController
{
    private BannerPlacement $placement;

    public function __construct(BannerPlacement $placement, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->placement = $placement;
    }

    public function index()
    {
        $placements = $this->placement->allWithBannerCount();
        return view('admin.banners.placements', compact('placements'));
    }

    public function toggle()
    {
        $id = (int)($this->request->input('id', 0));
        $placement = $this->placement->find($id);

        if ($placement) {
            $this->placement->update($id, ['is_active' => !$placement->is_active]);
            $this->session->setFlash('success', 'وضعیت تغییر کرد');
        }

        return redirect('/admin/banners/placements');
    }

    public function update()
    {
        $id = (int)($this->request->input('id', 0));

        $data = [
            'max_banners' => (int)($this->request->input('max_banners', 5)),
            'rotation_speed' => (int)($this->request->input('rotation_speed', 5000)),
            'show_on_mobile' => (int)($this->request->input('show_on_mobile', 1)),
            'show_on_desktop' => (int)($this->request->input('show_on_desktop', 1)),
            'display_style' => $this->request->input('display_style', 'carousel'),
            'auto_rotate' => (int)($this->request->input('auto_rotate', 1)),
        ];

        $this->placement->update($id, $data);
        $this->session->setFlash('success', 'تنظیمات بروزرسانی شد');
        return redirect('/admin/banners/placements');
    }
}
