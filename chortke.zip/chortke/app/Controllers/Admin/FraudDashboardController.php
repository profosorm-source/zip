<?php

namespace App\Controllers\Admin;

use App\Services\AntiFraud\FraudDashboardService;
use App\Controllers\Admin\BaseAdminController;

class FraudDashboardController extends BaseAdminController
{
    private FraudDashboardService $dashboardService;

    public function __construct(FraudDashboardService $dashboardService, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->dashboardService = $dashboardService;
    }
    
    /**
     * داشبورد ضد تقلب
     */
    public function index(): string
    {
        // FIX-R60-A5-5: قبلاً getCompleteDashboard همهٔ ۱۱ مجموع‌داده (از جمله
        // JOIN دوتاییِ تهدیدهای جغرافیایی و rate-limit روی جدولِ بدون نویسنده)
        // را در هر بازدید ادمین می‌ساخت، در حالی که ویو فقط همین ۴ متغیر را
        // مصرف می‌کند (تأیید با grep روی dashboard.php). اکنون فقط همان‌ها.
        return view('admin/fraud/dashboard', [
            'stats' => $this->dashboardService->getOverview(24),
            'recentSuspicious' => $this->dashboardService->getRecentAlerts(10),
            'suspiciousIPs' => $this->dashboardService->getTopSuspiciousIPs(10),
            'duplicateFingerprints' => $this->dashboardService->getTopSuspiciousUsers(10),
        ]);
    }

    
    
    
}
