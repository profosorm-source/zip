<?php
namespace App\Controllers\Admin;
use App\Models\Ads;
use App\Services\Shared\DashboardStatsService;
use App\Services\Ads\AdsBudgetSettlementService;

/**
 * Admin — مدیریت آگهی‌های SEO
 */
class SeoAdController extends BaseAdminController
{
    private Ads $model;
    private DashboardStatsService $analytics;
    private AdsBudgetSettlementService $adsBudgetSettlement;

    public function __construct(
        Ads $m,
        DashboardStatsService $a,
        AdsBudgetSettlementService $adsBudgetSettlement,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->model = $m;
        $this->analytics = $a;
        $this->adsBudgetSettlement = $adsBudgetSettlement;
    }

    public function index(): void
    {
        $status = $this->request->str('status', '');
        // 🛡️ FIX-Q4-SEO23-06: صفحه‌بندی — قبلاً همیشه ۳۰ ردیف اول (offset=0)
        // خوانده می‌شد و کمپین‌های قدیمی‌تر از دید ادمین خارج می‌شدند.
        $perPage = 30;
        $page = max(1, $this->request->int('page', 1));
        $offset = ($page - 1) * $perPage;
        // استفاده از فیلتر نوع seo در متد جدید adminList
        $items = $this->model->adminList('seo', $status, $perPage, $offset);
        $total = $this->model->adminCount('seo', $status);
        $totalPages = (int)ceil($total / max(1, $perPage));

        // آمار کلی با Shared Analytics از جدول یکپارچه ads
        $overview = $this->analytics->getTrend('seo_executions', 'created_at', 30);
        // 🛡️ FIX-M23R-09 (T23-09 — خلاصهٔ روند محاسبه می‌شود): getTrend فقط کلید
        // data را برمی‌گرداند؛ ویو $stats['trend']['summary'] را می‌خواند که
        // وجود نداشت ⇒ کارت‌های «اجراها (۳۰ روز)» و «میانگین روزانه» همیشه ۰
        // بودند. خلاصه از خود data ساخته می‌شود: مجموع ۳۰ روز + میانگین بر
        // بازهٔ ۳۰روزه (روزهای بدون اجرا هم در مخرج‌اند تا «میانگین روزانه»
        // معنای واقعی داشته باشد).
        $trendRows = is_array($overview['data'] ?? null) ? $overview['data'] : [];
        $trendTotal = 0;
        foreach ($trendRows as $trendRow) {
            $trendTotal += (int)(is_array($trendRow) ? ($trendRow['total'] ?? 0) : ($trendRow->total ?? 0));
        }
        $overview['summary'] = [
            'total'   => $trendTotal,
            'average' => $trendTotal > 0 ? round($trendTotal / 30, 1) : 0,
        ];
        $totalAds = $this->analytics->getCount('ads', ['type' => 'seo']);
        $activeAds = $this->analytics->getCount('ads', ['type' => 'seo', 'status' => 'active']);
        
        view('admin.seo-ad.index', [
            'title' => 'مدیریت آگهی‌های SEO',
            'items' => $items,
            'status' => $status,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'stats' => [
                'total_ads' => $totalAds,
                'active_ads' => $activeAds,
                'trend' => $overview
            ],
        ]);
    }

    public function approve(): void
    {
        // PRIMARY: SEO admin approval delegates to unified Ads action.
        $id = $this->request->int('id');
        $result = $this->adsBudgetSettlement->applyAdminAction($id, 'approve', (int)user_id(), 'تأیید از پنل تخصصی SEO');
        if (is_ajax()) { $this->response->json($result); return; }
        $this->session->setFlash(!empty($result['success']) ? 'success' : 'error', $result['message'] ?? 'عملیات انجام نشد.');
        redirect(url('/admin/seo-ad'));
    }

    public function reject(): void
    {
        // PRIMARY: reject must refund through unified Ads budget settlement.
        $id = $this->request->int('id');
        $reason = trim($this->request->str('reason', 'رد از پنل تخصصی SEO'));
        $result = $this->adsBudgetSettlement->applyAdminAction($id, 'reject', (int)user_id(), $reason !== '' ? $reason : 'رد از پنل تخصصی SEO');
        if (is_ajax()) { $this->response->json($result); return; }
        $this->session->setFlash(!empty($result['success']) ? 'success' : 'error', $result['message'] ?? 'رد کمپین انجام نشد.');
        redirect(url('/admin/seo-ad'));
    }

    public function pause(): void
    {
        // PRIMARY: pause delegates to unified Ads action so status/is_active stay consistent.
        $id = $this->request->int('id');
        $result = $this->adsBudgetSettlement->applyAdminAction($id, 'pause', (int)user_id(), 'توقف از پنل تخصصی SEO');
        if (is_ajax()) { $this->response->json($result); return; }
        $this->session->setFlash(!empty($result['success']) ? 'success' : 'error', $result['message'] ?? 'توقف کمپین انجام نشد.');
        redirect(url('/admin/seo-ad'));
    }
}
