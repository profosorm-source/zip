<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

/**
 * BaseAdminController — پایه تمام کنترلرهای پنل مدیریت
 *
 * ─── جریان صحیح ────────────────────────────────────────────────
 *
 *   Container::make(AdminUserController)
 *       └─→ AdminUserController::__construct()     ← بدون پارامتر
 *               └─→ BaseAdminController::__construct()
 *                       └─→ BaseController::__construct()
 *                               └─→ Container: Request, Response, Session
 *                       └─→ requireAuth() + requireAdmin()
 *
 * ─── تذکر ──────────────────────────────────────────────────────
 *   Auth در دو سطح بررسی می‌شود:
 *     ۱. AdminMiddleware  (در Route) — قبل از رسیدن به Controller
 *     ۲. requireAuth/requireAdmin  (اینجا) — لایه دوم اطمینان
 */
abstract class BaseAdminController extends BaseController
{
    /** 🧹 DI-CLEANUP (2026-08-24): تزریق رسمی #[Inject] (پشتیبانی‌شده در
     *  core/Container::injectProperties) — به‌جای Service Locator در متد logAdminAction. */
    #[\Core\Attributes\Inject]
    protected \App\Services\AuditTrail $auditTrail;

    /**
     * وابستگی‌ها را پذیرفته و به سازنده والد ارسال می‌کند.
     */
    public function __construct(
        ?\Core\Session $session = null,
        ?\Core\Request $request = null,
        ?\Core\Response $response = null,
        ?\App\Services\Shared\PolicyService $policyService = null,
        ?\App\Contracts\LoggerInterface $logger = null,
        ?\Core\CSRF $csrf = null
    ) {
        parent::__construct($session, $request, $response, $policyService, $logger, $csrf);

        // 🔐 M-11 FIX: single source of truth for the admin gate. The previous session-role
        // check (SessionKeys::USER_ROLE) was a second, *stale* authority — a role revoked in
        // the DB stayed "admin" in the session until it expired, diverging from
        // PermissionMiddleware and from requireAdmin(). requireAuth()+requireAdmin() below
        // already resolve the role from the DB via PolicyService::isAdminById(), so the
        // session pre-check is removed to keep one DB-authoritative decision and honor
        // immediate revocation.
        $this->requireAuth();
        // L-04: گیت پیش‌فرض = ادمین کامل. کنترلرهای مجاز به support این متد را override می‌کنند.
        $this->enforceAdminAccess();
    }

    /**
     * L-04: گیتِ دسترسیِ قابل‌override. پیش‌فرض فقط admin/super_admin است.
     * کنترلرهای پشتیبانی (تیکت/مدیریت‌پیام/گزارش‌باگ) آن را به requireAdminArea() تغییر می‌دهند
     * تا support بتواند وارد شود و سپس با authorizeById ریزدانه محدود گردد.
     */
    protected function enforceAdminAccess(): void
    {
        // L-04 (بازطراحی): گیتِ ورود = «ناحیهٔ ادمین» تا support در کل پنل بگردد و
        // همهٔ صفحات را ببیند. کنترلِ ریزدانهٔ هر عمل در لحظهٔ درخواست توسط
        // AdminPermissionGuard + PermissionMiddleware انجام می‌شود، نه در این گیت.
        $this->requireAdminArea();
    }

    /**
     * بررسی معتبر بودن تغییر وضعیت بر اساس ماشین وضعیت (CRIT-08)
     *
     * FIX-X22 (راند ۱۵): گذار «خودبه‌خودی» (from === to) اکنون مجاز است. فرم
     * ویرایش کاربر ادمین همیشه فیلد status را با مقدار فعلی ارسال می‌کند؛
     * قبلاً ذخیرهٔ سادهٔ فرم (بدون تغییر وضعیت) با خطای ۴۰۰ «تغییر وضعیت
     * غیرمجاز است» رد می‌شد و عملاً ویرایش بدون دست‌کاری status غیرممکن بود.
     * گذار خودبه‌خودی هیچ ارتقاء سطحی ایجاد نمی‌کند (no-op امن).
     */
    protected function validateStatusTransition(string $from, string $to): bool
    {
        // 🔒 FIX-M8-04 (راند ۱۶): ماشین وضعیت به منبع واحد \App\Enums\AccountStatus
        // منتقل شد — نقشهٔ محلیِ قبلی با فرم/validator/مدل ناسازگار بود:
        // (۱) گزینهٔ inactive در فرم بود ولی هیچ گذار →inactive مجاز نبود؛
        // (۲) locked/locked_2fa کلیدِ نقشه نبودند ⇒ کاربرِ قفل‌شده هیچ مسیر
        // رهاییِ ادمینی نداشت. گذارِ خودبه‌خودی (FIX-X22) در enum حفظ شد.
        return \App\Enums\AccountStatus::canTransition($from, $to);
    }

    /**
     * 🛡️ NEW-17 & NEW-12: ثبت ردپای حسابرسی تغییرات و عملیات حساس ادمین‌ها در دیتابیس
     */
    /**
     * @param array<string, mixed>|null $oldValues
     * @param array<string, mixed>|null $newValues
     */
    protected function auditLog(
        string $action, 
        string $entityType, 
        int $entityId, 
        ?array $oldValues, 
        ?array $newValues
    ): void {
        try {
            $oldValues = $this->redactPII($oldValues);
            $newValues = $this->redactPII($newValues);

            // 🧹 DI-CLEANUP (2026-08-24): به‌جای Service Locator از تزریق
            // رسمی #[Inject] استفاده می‌شود؛ نیت lazy بودن حفظ شده (فقط هنگام
            // وقوع عملیات ادمین استفاده می‌شود) ولی بدون دور زدن کانتینر.
            $auditTrailService = $this->auditTrail;
            $auditTrailService->logAdminAction(
                (int)user_id(),
                $action,
                $entityType,
                $entityId,
                $oldValues,
                $newValues,
                $this->request->ip(),
                $this->request->userAgent() ?: 'unknown',
                session_id() ?: ''
            );
        } catch (\Exception $e) {
            if (isset($this->logger)) {
                $this->logger->error('admin.audit_log.failed', ['error' => $e->getMessage()]);
            }
        }
    }

    /**
     * 🛡️ Redact sensitive PII/credential fields from log payload
     */
    /**
     * @param array<string, mixed>|null $data
     * @return array<string, mixed>|null
     */
    private function redactPII(?array $data): ?array
    {
        if ($data === null) {
            return null;
        }

        // 🛡️ FIX-M9-08 (گزارش ماژول ۹): فهرست PII تکمیل شد — قبلاً email, full_name,
        // address, birth_date/national_id پوشش نداشتند و هر کنترلر ادمینی که با این
        // کلیدها به auditLog می‌فرستاد، PII را ماسک‌نشده در trail ذخیره می‌کرد.
        // (national_code/phone/mobile از قبل بودند — حفظ شد.)
        $piiKeys = [
            'password', 'passwd', 'password_confirmation', 'new_password', 'old_password',
            'token', 'access_token', 'refresh_token', 'csrf_token', 'csrf',
            'card', 'card_number', 'card_num', 'cvv', 'cvv2',
            'pin', 'otp', 'secret', 'key', 'private_key', 'encryption_key',
            'national_code', 'national_id', 'nationalcode', 'ssn',
            'phone', 'mobile', 'telephone', 'tel',
            'email', 'e_mail', 'mail',
            'full_name', 'fullname', 'first_name', 'last_name',
            'address', 'address_line', 'postal_address', 'postal_code',
            'birth_date', 'birthdate', 'date_of_birth', 'dob',
        ];

        $redacted = [];
        foreach ((array)$data as $key => $value) {
            if (is_array($value)) {
                $redacted[$key] = $this->redactPII($value);
            } elseif (in_array(strtolower((string)$key), $piiKeys, true)) {
                $redacted[$key] = '[REDACTED_PII]';
            } else {
                $redacted[$key] = $value;
            }
        }
        return $redacted;
    }

    /**
     * 🛡️ FIX-M9-04/M9-05 (گزارش ماژول ۹): دسترسیِ کنترلر به اتصالِ مشترکِ DB
     * برای تراکنش‌های اتمیکِ خودِ کنترلر (مثل create/update نقش + sync مجوزها).
     * همان singleton ای است که Modelها مصرف می‌کنند — پس تراکنشِ کنترلر
     * عملیاتِ مدل‌ها را هم می‌پوشاند.
     */
    protected function db(): \Core\Database
    {
        return \Core\Database::getInstance();
    }

    /**
     * تضمین دریافت ID ادمین (غیر-null)
     * الگوی استاندارد پروژه برای جلوگیری از ارسال int|null به Serviceها.
     */
    protected function requireAdminId(): int
    {
        $id = user_id();
        if ($id === null) {
            throw new \Core\Exceptions\BusinessException('احراز هویت ادمین الزامی است.');
        }
        return $id;
    }
}

