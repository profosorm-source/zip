<?php

namespace App\Controllers\Admin;

use App\Models\CustomTaskSubmissionModel;
use App\Models\InteractionModel;
use App\Services\CustomTask\AdminCustomTaskService;
use App\Services\Shared\DisputeService;
use App\Controllers\Admin\BaseAdminController;

class ExecutorTaskController extends BaseAdminController
{
    private AdminCustomTaskService $customTaskService;
    private CustomTaskSubmissionModel $submissionModel;
    private DisputeService $disputeService;
    private InteractionModel $interactionModel;

    public function __construct(
        AdminCustomTaskService $customTaskService,
        CustomTaskSubmissionModel $submissionModel,
        DisputeService $disputeService,
        InteractionModel $interactionModel,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->customTaskService = $customTaskService;
        $this->submissionModel = $submissionModel;
        $this->disputeService = $disputeService;
        $this->interactionModel = $interactionModel;
    }

    /**
     * تایید اجباری submission توسط ادمین
     */
    public function forceApproveSubmission(): void
    {
        // 📜 قرارداد واحد ورودی (RULES §۱۸)
        $request = new \App\Validators\Requests\ForceModerateSubmissionRequest($this->jsonBody());
        if (!$request->validate()) {
            $this->response->json(['ok' => false, 'success' => false, 'message' => $this->firstValidationError($request->errors()), 'errors' => $request->errors()], 422);
            return;
        }
        $submissionId = int_value($request->safeValidated()['submission_id'] ?? 0);

        $submission = $this->submissionModel->submission_find($submissionId);
        if (!$submission) {
            $this->response->json(['ok' => false, 'message' => 'یافت نشد.'], 404);
            return;
        }

        $result = $this->customTaskService->forceApproveSubmissionByAdmin(
            $submissionId,
            (int)$this->userId()
        );

        // 🛡️ FIX-M22-MED (D2-N12): لاگ فقط پس از موفقیت — شکست سرویس هم ردیف audit
        // «تأیید اجباری» می‌ساخت.
        if (!empty($result['ok'])) {
            $this->logger->activity('custom_task.force_approve', 'تایید اجباری submission', user_id(), [
                'submission_id' => $submissionId,
                'admin_id' => (int)$this->userId(),
            ]);
        }

        $result['success'] = (bool)($result['ok'] ?? false);
        $this->response->json($result, $result['ok'] ? 200 : 422);
    }

    /**
     * رد اجباری submission توسط ادمین
     */
    public function forceRejectSubmission(): void
    {
        // 📜 قرارداد واحد ورودی (RULES §۱۸)
        $request = new \App\Validators\Requests\ForceModerateSubmissionRequest($this->jsonBody());
        if (!$request->validate()) {
            $this->response->json(['ok' => false, 'success' => false, 'message' => $this->firstValidationError($request->errors()), 'errors' => $request->errors()], 422);
            return;
        }
        $validated = $request->safeValidated();
        $submissionId = int_value($validated['submission_id'] ?? 0);
        $reason = isset($validated['reason']) && $validated['reason'] !== null && $validated['reason'] !== ''
            ? str_value($validated['reason'])
            : 'رد توسط ادمین';

        $submission = $this->submissionModel->submission_find($submissionId);
        if (!$submission) {
            $this->response->json(['ok' => false, 'message' => 'یافت نشد.'], 404);
            return;
        }

        $result = $this->customTaskService->forceRejectSubmissionByAdmin(
            $submissionId,
            (int)$this->userId(),
            $reason
        );

        if (!empty($result['ok'])) { // 🛡️ FIX-M22-MED (D2-N12): لاگ فقط پس از موفقیت
            $this->logger->activity('custom_task.force_reject', 'رد اجباری submission', user_id(), [
                'submission_id' => $submissionId,
                'admin_id' => (int)$this->userId(),
                'reason' => $reason,
            ]);
        }

        $result['success'] = (bool)($result['ok'] ?? false);
        $this->response->json($result, $result['ok'] ? 200 : 422);
    }

    /**
     * 🛡️ FIX-N22-02 (بازبینی ۲۲ — دید ادمین): فهرست سراسری ارسال‌های پارک‌شدهٔ
     * sweep تأیید خودکار (submitted با auto_approve_attempts ≥ آستانه) — تا این
     * بچ این ردیف‌ها از کوئری sweep حذف می‌شدند و هیچ UIای آن‌ها را نشان نمی‌داد.
     */
    public function parkedSubmissions(): string
    {
        $page = \max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $parked = $this->submissionModel->submission_getParkedForAutoApprove($limit, $offset);
        $total = $this->submissionModel->submission_countParkedForAutoApprove();

        return view('admin.custom-tasks.parked', [
            'parked' => $parked,
            'total' => $total,
            'page' => $page,
            'pages' => (int)\ceil($total / $limit),
            'parkThreshold' => CustomTaskSubmissionModel::AUTO_APPROVE_PARK_THRESHOLD,
        ]);
    }

    /**
     * 🛡️ FIX-N22-02 (بازبینی ۲۲ — راه بازگشت): بازگردانی یک ردیف پارک‌شده به صف
     * sweep با صفرکردن CAS شمارندهٔ شکست‌ها (فقط ردیفِ واقعاً پارک‌شده). داوری
     * مستقیم هم از همان صفحه با دکمه‌های تأیید/رد اجباری ممکن است.
     */
    public function resetParkedSubmission(): void
    {
        // 📜 قرارداد واحد ورودی (RULES §۱۸) — همان ولیدیتور force (submission_id)
        $request = new \App\Validators\Requests\ForceModerateSubmissionRequest($this->jsonBody());
        if (!$request->validate()) {
            $this->response->json(['ok' => false, 'success' => false, 'message' => $this->firstValidationError($request->errors()), 'errors' => $request->errors()], 422);
            return;
        }
        $submissionId = int_value($request->safeValidated()['submission_id'] ?? 0);

        $submission = $this->submissionModel->submission_find($submissionId);
        if (!$submission) {
            $this->response->json(['ok' => false, 'success' => false, 'message' => 'یافت نشد.'], 404);
            return;
        }

        // گارد صریح پارک‌بودن قبل از CAS — پیام روشن به‌جای شکست بی‌صدا
        $isParked = ((string)($submission->status ?? '') === 'submitted'
            && (int)($submission->auto_approve_attempts ?? 0) >= CustomTaskSubmissionModel::AUTO_APPROVE_PARK_THRESHOLD);
        if (!$isParked) {
            $this->response->json(['ok' => false, 'success' => false, 'message' => 'این ارسال پارک نشده است (شمارندهٔ شکست زیر آستانه یا وضعیت تغییر کرده).'], 422);
            return;
        }

        $reset = $this->submissionModel->submission_resetAutoApproveAttempts($submissionId);
        if (!$reset) {
            // CAS صفر شد — هم‌زمانی یا تغییر وضعیت همان لحظه
            $this->response->json(['ok' => false, 'success' => false, 'message' => 'بازگردانی انجام نشد؛ ردیف همین حالا تغییر کرده است. صفحه را تازه کنید.'], 409);
            return;
        }

        // لاگ حسابرسی فقط پس از موفقیت (هم‌الگوی D2-N12)
        $this->logger->activity('custom_task.parked_reset', 'بازگردانی ردیف پارک‌شده به صف تأیید خودکار', user_id(), [
            'submission_id' => $submissionId,
            'task_id' => (int)($submission->task_id ?? 0),
            'admin_id' => (int)$this->userId(),
            'previous_attempts' => (int)($submission->auto_approve_attempts ?? 0),
        ]);

        $this->response->json([
            'ok' => true,
            'success' => true,
            'message' => 'ردیف به صف تأیید خودکار بازگشت؛ دور بعدی sweep دوباره تلاش می‌کند.',
        ], 200);
    }

    /**
     * لیست اختلافات
     */
    public function disputes(): string
    {
        $rawRefType = $this->request->get('ref_type');
        $filters = [
            'status'   => $this->request->get('status'),
            'ref_type' => is_string($rawRefType) ? $rawRefType : '',
        ];

        $page = \max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $disputeResult = $this->disputeService->listForAdmin($filters, $limit, $offset);
        $disputes = $disputeResult['items'];
        $total = $disputeResult['total'];

        // FIX-X117: مصرف بوست اختلاف — اختلاف‌های «بوست‌دارِ باز» به صدر صف داوری
        [$disputes, $boostedUserIds] = boost_queue_order($disputes, 'dispute', 'user_id', 'status', ['open', 'open_peer', 'under_review', 'escalated']);

        return view('admin.custom-tasks.disputes', [
            'disputes' => $disputes,
            'total' => $total,
            'page' => $page,
            'pages' => \ceil($total / $limit),
            'filters' => $filters,
            'boostedUserIds' => $boostedUserIds, // FIX-X117
        ]);
    }

    /**
     * جزئیات اختلاف + پیام‌های دوطرفه
     */
    public function disputeDetail(): string
    {
        $disputeId = (int)$this->request->param('id');
        // Raw SQL حذف شد — از Dispute model استفاده می‌شود
        $dispute = $this->disputeService->findDetailWithSubmission($disputeId);
        if (!$dispute) {
            $this->session->setFlash('error', 'پرونده اختلاف یافت نشد.');
            return redirect(url('/admin/custom-tasks/disputes'));
        }
        $messages = $this->disputeService->getMessages($disputeId);
        return view('admin.custom-tasks.dispute-detail', [
            'dispute'  => $dispute,
            'messages' => $messages,
        ]);
    }

    public function replyDispute(): void
    {
        $disputeId = (int)$this->request->param('id');
        $message   = trim($this->request->str('message'));
        if (mb_strlen((string)$message) < 2) {
            $this->session->setFlash('error', 'متن پیام الزامی است.');
            $this->response->redirect(url('/admin/custom-tasks/disputes/' . $disputeId));
            return;
        }
        // delegate به DisputeCommandService — Raw SQL + bug ($db بجای $this->db) حذف شد
        // 🛡️ FIX-S36-B15-S10: asManager=true — هویت مدیر در سرویس از DB راستی‌آزمایی
        // می‌شود (admin/super_admin)؛ پاسخ مدیریتی مدیرِ غیرطرف دیگر رد نمی‌شود.
        $result = $this->disputeService->sendMessage($disputeId, (int)$this->userId(), 'admin', $message, null, true);
        if (!($result['success'] ?? false)) {
            $this->session->setFlash('error', $result['message'] ?? 'امکان ارسال پیام برای این پرونده وجود ندارد.');
            $this->response->redirect(url('/admin/custom-tasks/disputes'));
            return;
        }
        $this->session->setFlash('success', 'پیام ادمین ثبت شد.');
        $this->response->redirect(url('/admin/custom-tasks/disputes/' . $disputeId));
    }

    /**
     * حل اختلاف
     */
    public function resolveDispute(): void
    {
        $body = $this->jsonBody();

        // نرمال‌سازی مترادف‌ها پیش از اعتبارسنجی (رفتار تاریخی حفظ شده است)
        $body['decision'] = match ($body['decision'] ?? '') {
            'worker_wins', 'worker', 'executor_wins' => 'executor',
            'advertiser_wins', 'advertiser' => 'advertiser',
            'split', 'partial' => 'split',
            default => $body['decision'] ?? '',
        };
        if (!isset($body['executor_percent']) && isset($body['worker_percent'])) {
            $body['executor_percent'] = $body['worker_percent'];
        }
        if (isset($body['executor_percent']) && !is_scalar($body['executor_percent'])) {
            unset($body['executor_percent']);
        }

        // 📜 قرارداد واحد ورودی (RULES §۱۸)
        $request = new \App\Validators\Requests\ResolveExecutorDisputeRequest($body);
        if (!$request->validate()) {
            $this->response->json(['ok' => false, 'success' => false, 'message' => $this->firstValidationError($request->errors()), 'errors' => $request->errors()], 422);
            return;
        }
        $validated = $request->safeValidated();
        $disputeId = int_value($validated['dispute_id'] ?? 0);
        $decision = str_value($validated['decision'] ?? '');
        $adminNote = $validated['admin_note'] ?? '';
        $executorPercent = isset($validated['executor_percent']) && is_scalar($validated['executor_percent'])
            ? str_value($validated['executor_percent'])
            : '0';

        $result = $this->disputeService->resolveForAdmin(
            (int)$this->userId(),
            $disputeId,
            [
                'decision' => $decision,
                'admin_note' => $adminNote,
                'executor_percent' => $executorPercent,
            ]
        );

        $this->logger->activity('custom_task.resolve_dispute', 'حل اختلاف', user_id(), [
            'dispute_id' => $disputeId,
            'decision' => $decision,
            'executor_percent' => $executorPercent,
        ]);

        $result['success'] = (bool)($result['ok'] ?? false);
        $this->response->json($result, $result['ok'] ? 200 : 422);
    }

    /**
     * لیست گزارشات تسک‌ها
     */
    public function reports(): string
    {
        $filters = [
            'status' => $this->request->get('status'),
            'reason' => $this->request->get('reason'),
        ];

        $page = max(1, $this->request->int('page', 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;

        $reports = $this->interactionModel->adminListTaskReports($filters, $limit, $offset);
        $total = $this->interactionModel->adminCountTaskReports($filters);

        return view('admin.custom-tasks.reports', [
            'reports' => $reports,
            'total' => $total,
            'page' => $page,
            'pages' => ceil($total / $limit),
            'filters' => $filters,
            'statusCounts' => $this->interactionModel->adminTaskReportStatusCounts(),
            'statusLabels' => $this->interactionModel->taskReportStatusLabels(),
            'reasonLabels' => $this->interactionModel->taskReportReasonLabels(),
        ]);
    }

    /**
     * بررسی گزارش
     */
    public function reviewReport(): void
    {
        // 📜 قرارداد واحد ورودی (RULES §۱۸)
        $request = new \App\Validators\Requests\ReviewTaskReportRequest($this->jsonBody());
        if (!$request->validate()) {
            $this->response->json(['success' => false, 'message' => $this->firstValidationError($request->errors()), 'errors' => $request->errors()], 422);
            return;
        }
        $validated = $request->safeValidated();
        $reportId = int_value($validated['report_id'] ?? 0);
        $status = str_value($validated['status'] ?? '');
        $adminNote = $validated['admin_note'] ?? '';

        $report = $this->interactionModel->findTaskReport($reportId);

        if (!$report) {
            $this->response->json(['success' => false, 'message' => 'گزارش یافت نشد.'], 404);
            return;
        }

        // 🛡️ FIX-V22-01 (باقیماندهٔ بازبینی ۲۲): قبلاً گزارش ابتدا resolved ثبت و
        // commit می‌شد و بعد rejectTask صدا زده می‌شد؛ اگر رد تسک مشروعاً شکست
        // می‌خورد (اختلاف باز روی تسک، escrow در disputed، کمپین legacy بدون
        // escrow) گزارشِ «حل‌شده» می‌ماند در حالی‌که تسکِ متقلب فعال می‌ماند و
        // راه ساده‌ای برای بازگشت نبود (task_rejected=false فقط در JSON بود و
        // ویو آن را نمی‌خواند). اکنون ترتیب برعکس شد — «ابتدا رد، بعد بستن گزارش»:
        //   * شکستِ قابل‌اقدام رد تسک → پاسخ ۴۰۹ با همان پیام سرویس؛ گزارش در
        //     وضعیت قبلی (pending/reviewed) می‌ماند تا داور موانع را رفع و دوباره
        //     تلاش کند.
        //   * تسکِ از-قبل-rejected → idempotent: بدون فراخوانی مجدد، رد می‌ماند.
        //   * وضعیت پایانیِ غیرقابل‌رد (completed/cancelled/expired) → چیزی برای
        //     رد نیست؛ گزارش با task_rejected=false و یادداشت بسته می‌شود.
        //   * گارد CAS (FIX-R36-W3) خودِ گذار را از وضعیت‌های غیرپایانی محدود
        //     می‌کند، پس این بازترتیب نمی‌تواند گزارشِ پایانی را دوباره باز کند.
        $wantsTaskRejection = ($status === 'resolved'
            && $report->reason === 'fraud'
            && (string)($report->task_type ?? 'custom_task') === 'custom_task');
        $taskRejected = false;
        $taskRejectNote = null;
        // 🛡️ FIX-N22-01: تعداد ارسال‌هایی که فیلتر کیفی مسیر تقلب تسویه نکرد
        $taskFraudFiltered = 0;

        if ($wantsTaskRejection) {
            $taskRow = db()->table('ads')->select('status', 'type')->where('id', '=', (int)$report->task_id)->first();
            $taskStatus = is_object($taskRow) ? (string)($taskRow->status ?? '') : '';

            if ($taskStatus === 'rejected') {
                // از قبل رد شده — ردِ مجددِ بی‌اثر لازم نیست (idempotency).
                $taskRejected = true;
            } elseif (!in_array($taskStatus, ['completed', 'cancelled', 'expired'], true)) {
                // 🛡️ FIX-N22-01: پارامتر چهارم fraudReported=true — مسیر «گزارش تقلب»
                // با فیلتر کیفی تسویهٔ جبرانی همراه است (ردِ مستقیم ادمین از
                // AdTaskController بدون فیلتر می‌ماند — گزینهٔ A بچ V22B).
                $rejectResult = $this->customTaskService->rejectTask((int)$report->task_id, (int)$this->userId(), 'گزارش شده به دلیل تقلب', true);
                if (empty($rejectResult['success'])) {
                    // مانع قابل‌اقدام — گزارش باز می‌ماند؛ داور پیام واقعی را می‌بیند.
                    $this->response->json([
                        'success' => false,
                        'message' => is_string($rejectResult['message'] ?? null) && $rejectResult['message'] !== ''
                            ? 'رد تسک ناموفق بود؛ گزارش باز ماند: ' . $rejectResult['message']
                            : 'رد تسک ناموفق بود؛ گزارش باز ماند.',
                        'task_rejected' => false,
                    ], 409);
                    return;
                }
                $taskRejected = true;
                // 🛡️ FIX-N22-01: تعداد نگه‌داشته‌شده‌های فیلتر کیفی برای شفافیت داور
                $taskFraudFiltered = int_value($rejectResult['fraud_filtered_submissions'] ?? 0);
            } else {
                $taskRejectNote = 'تسک در وضعیت پایانی (' . $taskStatus . ') بود و رد نشد؛ فقط گزارش بسته شد.';
            }
        }

        // FIX-R36-W3 (F-A15-03): CAS گذار وضعیت (الگوی X376 در FraudReportsAdminController) —
        // قبلاً UPDATE بی‌شرط بود و گزارشِ resolved/rejected می‌توانست دوباره داوری شود:
        // admin_id/resolved_at بازنویسی (ابهام حسابرسی last-writer-wins) و عوارضِ جانبیِ
        // دوباره آتش می‌شدند. گذار فقط از وضعیت‌های غیرپایانی (pending/reviewed) مجاز است؛
        // rowCount=0 → گزارش قبلاً پایانی بوده (قرارداد «مدل‌ها مالکِ دسترسی DB» —
        // از QueryBuilder استفاده می‌شود نه SQL خام؛ updated_at را خودِ DB کلید می‌زند).
        $affected = db()->table('task_reports')
            ->where('id', '=', $reportId)
            ->whereIn('status', ['pending', 'reviewed'])
            ->update([
                'status'      => $status,
                'admin_id'    => (int)$this->userId(),
                'admin_note'  => $adminNote,
                'resolved_at' => ($status === 'resolved') ? date('Y-m-d H:i:s') : null,
            ]);
        $updated = is_int($affected) ? $affected > 0 : (bool)$affected;

        if ($updated) {
            $this->logger->activity('custom_task.review_report', 'بررسی گزارش', user_id(), [
                'report_id' => $reportId,
                'status' => $status,
                'task_type' => (string)($report->task_type ?? 'custom_task'),
                'task_rejected' => $taskRejected,
                // 🛡️ FIX-N22-01: ردپای حسابرسی فیلتر کیفی مسیر تقلب
                'fraud_filtered_submissions' => $taskFraudFiltered,
            ]);

            $payload = [
                'success' => true,
                'message' => 'گزارش با موفقیت بررسی شد.',
                'task_rejected' => $taskRejected,
                // 🛡️ FIX-N22-01: شفافیت فیلتر کیفی در پاسخ داور
                'fraud_filtered_submissions' => $taskFraudFiltered,
            ];
            if ($taskRejectNote !== null) {
                $payload['task_reject_note'] = $taskRejectNote;
            }
            $this->response->json($payload, 200);
        } else {
            // CAS rowCount=0 → گزارش هم‌اکنون توسط داوری دیگر تعیین تکلیف شده است.
            $this->response->json(['success' => false, 'message' => 'گزارش پیش‌تر تعیین تکلیف شده است.'], 409);
        }
    }

    /* FIX-X86: متد مردهٔ batchAction() حذف شد — هیچ UI چندانتخابی وجود نداشت،
       مسیرهای تکی force-approve/force-reject/pause/delete موجودند و فراخوانی
       متدهای Submission با task_id ابهام معنایی داشت (تلهٔ دو-منبع-حقیقت). */

    /** @return array<string, mixed> */
    private function jsonBody(): array
    {
        $decoded = json_decode((string)file_get_contents('php://input'), true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * استخراج اولین پیام خطای اعتبارسنجی برای فیلد message پاسخ.
     *
     * @param array<string, mixed> $errors
     */
    private function firstValidationError(array $errors): string
    {
        $firstValue = reset($errors);
        $firstError = is_array($firstValue) ? reset($firstValue) : $firstValue;

        return is_string($firstError) && $firstError !== '' ? $firstError : 'اطلاعات ارسالی نامعتبر است.';
    }

}
