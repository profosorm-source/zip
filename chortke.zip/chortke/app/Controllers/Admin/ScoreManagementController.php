<?php

namespace App\Controllers\Admin;

use App\Services\ScoreService;

class ScoreManagementController extends BaseAdminController
{
    private ScoreService $scoreService;

    public function __construct(
        ScoreService $scoreService,
        ?\Core\Session $session = null,
        ?\Core\Request $request = null,
        ?\Core\Response $response = null,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->scoreService = $scoreService;
    }

    public function showUserScores(int $id): void
    {
        $this->requireAdmin();
        $userId = (int)$id;

        $user = $this->scoreService->getUserForScoreManagement($userId);
        if (!$user) {
            $this->response->setStatusCode(404);
            $this->response->setContent('کاربر یافت نشد');
            return;
        }

        // FIX-X68: منبع نمایش ادمین = منبع موتور تصمیم (پروجکشن/لجر)،
        // نه users.fraud_score که با لجر همگام نبود و ریست را no-op می‌کرد.
        $fraudRaw = $this->scoreService->getScore('user', $userId, 'fraud');
        $fraudEffective = $this->scoreService->getEffectiveScore($userId, 'fraud', $fraudRaw);

        $taskRaw = $this->scoreService->getTaskRawRisk($userId);
        $taskEffective = $this->scoreService->getEffectiveScore($userId, 'task', $taskRaw);

        $fraudAdjustments = $this->scoreService->getActiveAdjustments($userId, 'fraud');
        $taskAdjustments = $this->scoreService->getActiveAdjustments($userId, 'task');

        $recentEvents = $this->scoreService->getRecentScoreEvents($userId, 50);

        $this->view('admin/fraud/user-scores', [
            'user' => $user,
            'fraud_raw' => $fraudRaw,
            'fraud_effective' => $fraudEffective,
            'task_raw' => $taskRaw,
            'task_effective' => $taskEffective,
            'fraud_adjustments' => $fraudAdjustments,
            'task_adjustments' => $taskAdjustments,
            'events' => $recentEvents,
        ]);
    }

    public function adjustScore(int $id): void
    {
        $this->requireAdmin();

        if (strtoupper($this->request->method()) !== 'POST') {
            $this->response->redirect('/admin/users/' . (int)$id . '/scores');
        }

        $userId = (int)$id;
        $domain = trim($this->request->str('domain', 'fraud'));
        $operation = strtolower(trim($this->request->str('operation', 'add')));
        $value = $this->request->float('value');
        $reason = trim($this->request->str('reason'));
        $expiresAt = trim($this->request->str('expires_at'));

        if (!in_array($domain, ['fraud', 'task'], true)) {
            $this->flash('error', 'دامنه امتیاز نامعتبر است.');
            $this->response->redirect('/admin/users/' . $userId . '/scores');
        }

        if (!in_array($operation, ['set', 'add', 'subtract'], true)) {
            $this->flash('error', 'عملیات نامعتبر است.');
            $this->response->redirect('/admin/users/' . $userId . '/scores');
        }

        if ($reason === '') {
            $this->flash('error', 'ثبت دلیل برای اصلاح امتیاز الزامی است.');
            $this->response->redirect('/admin/users/' . $userId . '/scores');
        }

        // FIX-R19-A5-7: requireAdminId() از BaseAdminController — هیچ‌وقت null به createAdjustment نمی‌رود
        $adminId = $this->requireAdminId();

        // FIX-S16-8: expires_at اعتبارسنجی و نرمال‌سازی می‌شود — قبلاً رشتهٔ خامِ ورودی بدون
        // هیچ چکی به ستون datetime می‌رفت (رشتهٔ نامعتبر ⇒ خطای DB/500؛ تاریخِ گذشته ⇒
        // رکورد بی‌معنی). فرمت کانونی: Y-m-d H:i:s.
        $expiresAtNormalized = null;
        if ($expiresAt !== '') {
            $ts = strtotime($expiresAt);
            if ($ts === false || $ts <= time()) {
                $this->flash('error', 'تاریخ انقضا باید یک زمانِ معتبر در آینده باشد.');
                $this->response->redirect('/admin/users/' . $userId . '/scores');
                return;
            }
            $expiresAtNormalized = date('Y-m-d H:i:s', $ts);
        }

        $result = $this->scoreService->createAdjustment(
            $userId,
            $domain,
            $operation,
            $value,
            $reason,
            $expiresAtNormalized,
            $adminId
        );

        if ($result['success']) {
            $this->flash('success', str_value($result['message'] ?? 'اصلاح امتیاز ثبت شد.'));
        } else {
            $this->flash('error', str_value($result['message'] ?? 'ثبت اصلاح امتیاز ناموفق بود.'));
        }

        $this->response->redirect('/admin/users/' . $userId . '/scores');
    }

    public function revokeAdjustment(int $id): void
    {
        $this->requireAdmin();

        if (strtoupper($this->request->method()) !== 'POST') {
            $this->response->redirect('/admin/dashboard');
        }

        $adjustmentId = (int)$id;
        $reason = trim($this->request->str('reason', 'revoke_by_admin'));
        // FIX-R19-A5-7: requireAdminId() از BaseAdminController — گارانتی non-null
        $adminId = $this->requireAdminId();

        // FIX-S16-7: رکورد قبل از ابطال واکشی می‌شود تا ریدایرکت به صفحهٔ کاربرِ صاحبِ رکورد
        // برود — قبلاً شناسهٔ «رکوردِ اصلاح» به‌جای شناسهٔ «کاربر» در مسیر ریدایرکت می‌نشست
        // (⇒ صفحهٔ کاربر اشتباه/404).
        $adjustment = $this->scoreService->findAdjustmentById($adjustmentId);
        if (!$adjustment) {
            $this->flash('error', 'رکورد اصلاح امتیاز یافت نشد.');
            $this->response->redirect('/admin/dashboard');
        }
        $targetUserId = (int)($adjustment->user_id ?? 0);

        $success = $this->scoreService->revokeScoreAdjustment($adjustmentId, $adminId, $reason);

        if ($success) {
            $this->flash('success', 'اصلاح امتیاز غیرفعال شد.');
            $this->response->redirect('/admin/users/' . max(1, $targetUserId) . '/scores');
        } else {
            $this->flash('error', 'رکورد اصلاح امتیاز یافت نشد.');
            $this->response->redirect('/admin/dashboard');
        }
    }

    public function history(int $id): void
    {
        $this->requireAdmin();
        $userId = (int)$id;

        $user = $this->scoreService->getUserForScoreManagement($userId);
        if (!$user) {
            $this->response->setStatusCode(404);
            $this->response->setContent('کاربر یافت نشد');
            return;
        }

        $events = $this->scoreService->getRecentScoreEvents($userId, 200);

        // اگر ویوی تاریخچه جدا نداری، همین view اصلی را با events بیشتر باز کن
        // FIX-X68: نمایش هم‌منبع با موتور تصمیم
        $fraudRawEngine = $this->scoreService->getScore('user', $userId, 'fraud');
        $this->view('admin/fraud/user-scores', [
            'user' => $user,
            'fraud_raw' => $fraudRawEngine,
            'fraud_effective' => $this->scoreService->getEffectiveScore($userId, 'fraud', $fraudRawEngine),
            'task_raw' => $this->scoreService->getTaskRawRisk($userId),
            'task_effective' => $this->scoreService->getEffectiveScore($userId, 'task', $this->scoreService->getTaskRawRisk($userId)),
            'fraud_adjustments' => $this->scoreService->getActiveAdjustments($userId, 'fraud'),
            'task_adjustments' => $this->scoreService->getActiveAdjustments($userId, 'task'),
            'events' => $events,
        ]);
    }


    // FIX-R19-A5-7: currentAdminId() حذف شد — جایگزین: BaseAdminController::requireAdminId() (non-null گارانتی)

    private function flash(string $type, string $message): void
    {
        $this->session->set('flash.' . $type, $message);
    }
}