<?php

namespace App\Controllers\Admin;

use App\Services\ScoreService;

class ScoreManagementController extends BaseAdminController
{
    private ScoreService $scoreService;

    public function __construct(
        ScoreService $scoreService,
        ?\Core\Session $session = null,
        ?\Core\Request $request = null,
        ?\Core\Response $response = null,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct($session, $request, $response, null, $logger);
        $this->scoreService = $scoreService;
    }

    public function showUserScores(int $id): void
    {
        $this->requireAdmin();
        $userId = (int)$id;

        $user = $this->scoreService->getUserForScoreManagement($userId);
        if (!$user) {
            $this->response->setStatusCode(404);
            $this->response->setContent('کاربر یافت نشد');
            return;
        }

        $fraudRaw = (float)($user->fraud_score ?? 0);
        $fraudEffective = $this->scoreService->getEffectiveScore($userId, 'fraud', $fraudRaw);

        $taskRaw = $this->scoreService->getTaskRawRisk($userId);
        $taskEffective = $this->scoreService->getEffectiveScore($userId, 'task', $taskRaw);

        $fraudAdjustments = $this->scoreService->getActiveAdjustments($userId, 'fraud');
        $taskAdjustments = $this->scoreService->getActiveAdjustments($userId, 'task');

        $recentEvents = $this->scoreService->getRecentScoreEvents($userId, 50);

        $this->view('admin/fraud/user-scores', [
            'user' => (array)$user,
            'fraud_raw' => $fraudRaw,
            'fraud_effective' => $fraudEffective,
            'task_raw' => $taskRaw,
            'task_effective' => $taskEffective,
            'fraud_adjustments' => $fraudAdjustments,
            'task_adjustments' => $taskAdjustments,
            'events' => $recentEvents,
        ]);
    }

    public function adjustScore(int $id): void
    {
        $this->requireAdmin();

        if (strtoupper($this->request->method()) !== 'POST') {
            $this->response->redirect('/admin/users/' . (int)$id . '/scores');
        }

        $userId = (int)$id;
        $domain = trim((string)($this->request->input('domain', 'fraud')));
        $operation = strtolower(trim((string)($this->request->input('operation', 'add'))));
        $value = (float)($this->request->input('value', 0));
        $reason = trim((string)($this->request->input('reason', '')));
        $expiresAt = trim((string)($this->request->input('expires_at', '')));

        if (!in_array($domain, ['fraud', 'task'], true)) {
            $this->flash('error', 'دامنه امتیاز نامعتبر است.');
            $this->response->redirect('/admin/users/' . $userId . '/scores');
        }

        if (!in_array($operation, ['set', 'add', 'subtract'], true)) {
            $this->flash('error', 'عملیات نامعتبر است.');
            $this->response->redirect('/admin/users/' . $userId . '/scores');
        }

        if ($reason === '') {
            $this->flash('error', 'ثبت دلیل برای اصلاح امتیاز الزامی است.');
            $this->response->redirect('/admin/users/' . $userId . '/scores');
        }

        $adminId = $this->currentAdminId();

        $result = $this->scoreService->createAdjustment(
            $userId,
            $domain,
            $operation,
            $value,
            $reason,
            ($expiresAt !== '' ? $expiresAt : null),
            $adminId
        );

        if ($result['success']) {
            $this->flash('success', $result['message']);
        } else {
            $this->flash('error', $result['message']);
        }

        $this->response->redirect('/admin/users/' . $userId . '/scores');
    }

    public function revokeAdjustment(int $id): void
    {
        $this->requireAdmin();

        if (strtoupper($this->request->method()) !== 'POST') {
            $this->response->redirect('/admin/dashboard');
        }

        $adjustmentId = (int)$id;
        $reason = trim((string)($this->request->input('reason', 'revoke_by_admin')));
        $adminId = $this->currentAdminId();

        $success = $this->scoreService->revokeScoreAdjustment($adjustmentId, $adminId, $reason);

        if ($success) {
            $this->flash('success', 'اصلاح امتیاز غیرفعال شد.');
            $this->response->redirect('/admin/users/' . $adjustmentId . '/scores');
        } else {
            $this->flash('error', 'رکورد اصلاح امتیاز یافت نشد.');
            $this->response->redirect('/admin/dashboard');
        }
    }

    public function history(int $id): void
    {
        $this->requireAdmin();
        $userId = (int)$id;

        $user = $this->scoreService->getUserForScoreManagement($userId);
        if (!$user) {
            $this->response->setStatusCode(404);
            $this->response->setContent('کاربر یافت نشد');
            return;
        }

        $events = $this->scoreService->getRecentScoreEvents($userId, 200);

        // اگر ویوی تاریخچه جدا نداری، همین view اصلی را با events بیشتر باز کن
        $this->view('admin/fraud/user-scores', [
            'user' => (array)$user,
            'fraud_raw' => (float)($user->fraud_score ?? 0),
            'fraud_effective' => $this->scoreService->getEffectiveScore($userId, 'fraud', (float)($user->fraud_score ?? 0)),
            'task_raw' => $this->scoreService->getTaskRawRisk($userId),
            'task_effective' => $this->scoreService->getEffectiveScore($userId, 'task', $this->scoreService->getTaskRawRisk($userId)),
            'fraud_adjustments' => $this->scoreService->getActiveAdjustments($userId, 'fraud'),
            'task_adjustments' => $this->scoreService->getActiveAdjustments($userId, 'task'),
            'events' => $events,
        ]);
    }


    private function ensureAdmin(): void
    {
        if (method_exists($this, 'requireAdmin')) {
            $this->requireAdmin();
            return;
        }

        $role = $this->session->get('role') ?? $this->session->get('user_role');
        if (!in_array($role, ['admin', 'super_admin', 'support'], true)) {
            $this->response->setStatusCode(403);
            $this->response->setContent('Forbidden');
            throw new \Core\Exceptions\HttpResponseException($this->response);
        }
    }

    private function currentAdminId(): ?int
    {
        $id = $this->session->get('user_id') ?? $this->session->get('admin_id');
        return $id ? (int)$id : null;
    }

    /** @param array<string, mixed> $data */
    private function render(string $viewPath, array $data = []): void
    {
        if (function_exists('view')) {
            echo view($viewPath, $data);
            return;
        }

        extract($data, EXTR_SKIP);
        $full = dirname(__DIR__, 3) . '/views/' . $viewPath . '.php';
        if (is_file($full)) {
            include $full;
            return;
        }

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    }

    private function redirect(string $url): void
    {
        if (function_exists('redirect')) {
            redirect($url);
            return;
        }
        header('Location: ' . $url);
        exit;
    }

    private function flash(string $type, string $message): void
    {
        $this->session->set('flash.' . $type, $message);
    }
}