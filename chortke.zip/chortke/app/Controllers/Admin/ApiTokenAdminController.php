<?php

namespace App\Controllers\Admin;

use Core\Response;
use App\Services\ApiTokenService;

class ApiTokenAdminController extends BaseAdminController
{
    // 🧹 DI-CLEANUP (2026-08-24): پراپرتی $auditTrail ارثبرده از BaseAdminController (با #[Inject]) است.
    // FIX-M11-H2 (گزارش ماژول ۱۱): وابستگی SearchOrchestrator حذف شد — مسیر قبلی
    // به AdminSearchGateway::searchTokens می‌رسید که برای api_tokens «placeholderِ
    // خالی» برمی‌گرداند (warning: crypto_tokens...) ⇒ جستجوی ادمین همیشه بی‌صدا
    // خالی بود. اکنون همیشه مسیر کانونی getTokensForAdmin (مدل با predicateهای
    // مشتق وضعیت) استفاده می‌شود.
    private ApiTokenService $apiTokenService;

    public function __construct(
        ApiTokenService $apiTokenService,
        \App\Services\AuditTrail $auditTrail
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->apiTokenService = $apiTokenService;
        $this->auditTrail = $auditTrail;
    }

    public function index(): void
    {
        $page = max(1, $this->request->int('page', 1));
        $search = trim($this->request->str('search', ''));
        $statusFilter = $this->request->str('status') !== '' ? $this->request->str('status') : null;
        $perPage = 30;
        $offset = ($page - 1) * $perPage;

        // FIX-M11-H2/M2: مسیر واحد کانونی — جستجو + فیلتر وضعیت همیشه از همان
        // قرارداد مدل عبور می‌کند (بدون ستون ناموجود status و بدون مسیر silent-empty).
        $result = $this->apiTokenService->getTokensForAdmin($page, $perPage, $search !== '' ? $search : null, $statusFilter);
        $tokens = $result['tokens'];
        $total = $result['total'];

        view('admin/api-tokens/index', [
            'title' => 'توکن‌های API',
            'tokens' => $tokens,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'stats' => $result['stats'] ?? [],
            'statusFilter' => $statusFilter,
            'search' => $search,
            // FIX-M11-R22-18: totalPages برای صفحه‌بندیِ view (سرویس محاسبه می‌کند)
            'totalPages' => int_value($result['totalPages'] ?? 1),
        ]);
    }

    public function revoke(): void
    {
        $this->validateCsrf();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? $this->request->input('id') ?? 0);
        if ($id <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه توکن نامعتبر است'], 422);
            return;
        }

        // FIX-M11-H5 (گزارش ماژول ۱۱): قرارداد حالت — سرویس تمایزِ revoked /
        // already_revoked / not_found را برمی‌گرداند؛ audit فقط پس از تغییرِ
        // واقعی ثبت می‌شود و پاسخ‌های خطا از هم تفکیک‌شده‌اند.
        $result = $this->apiTokenService->revokeToken($id);
        $ok = is_array($result) ? (bool)($result['success'] ?? false) : (bool)$result;
        $state = is_array($result) ? str_value($result['state'] ?? '') : 'revoked';

        if ($ok) {
            $this->auditTrail->record(
                'admin.api_token.revoke',
                (int)user_id(),
                ['token_id' => $id, 'action' => 'revoke', 'ip' => get_client_ip()],
                (int)user_id()
            );
        }

        // FIX-M11-SF-002 (گزارش دوم): propagate وضعیت سرویس — not_found=404،
        // already_revoked=409 (قبلاً هر دو با HTTP 200 برمی‌گشتند و retry/monitoring
        // خطا را موفق می‌دیدند). کد پایدار در payload حفظ می‌شود.
        $message = match (true) {
            $ok => 'باطل شد',
            $state === 'already_revoked' => 'این توکن قبلاً باطل شده است',
            $state === 'not_found' => 'توکن یافت نشد',
            default => is_array($result) ? str_value($result['message'] ?? 'یافت نشد') : 'یافت نشد',
        };

        $httpStatus = match ($state) {
            'not_found' => 404,
            'already_revoked' => 409,
            default => $ok ? 200 : 422,
        };

        $this->response->json(['success' => $ok, 'message' => $message, 'state' => $state], $httpStatus);
    }

    /**
     * W4-E (تصمیم مشتری #1): تمدید ۹۰ روزهٔ توکن از پنل ادمین.
     * دقیقاً الگوی revoke() بالا: CSRF با validateCsrf (middleware فریم‌ورک)،
     * اعتبارسنجی id، فراخوان سرویس، رکورد AuditTrail و پاسخ JSON.
     * مجوز ادمین توسط گارد $admin مسیر در routes/system.php اعمال می‌شود.
     */
    public function renew(): void
    {
        $this->validateCsrf();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? $this->request->input('id') ?? 0);
        if ($id <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه توکن نامعتبر است'], 422);
            return;
        }

        $result = $this->apiTokenService->renewToken($id);
        $ok = (bool)($result['success'] ?? false);
        $payload = is_array($result['payload'] ?? null) ? $result['payload'] : [];

        if ($ok) {
            $this->auditTrail->record(
                'admin.api_token.renew',
                (int)user_id(),
                [
                    'token_id' => $id,
                    'action' => 'renew',
                    'expires_at' => $payload['expires_at'] ?? null,
                    'ip' => get_client_ip(),
                ],
                (int)user_id()
            );
        }

        // FIX-M11-SF-002 (گزارش دوم): وضعیت سرویس (404/409) propagate شد —
        // قبلاً خطای دامنه هم با HTTP 200 برگردانده می‌شد.
        $this->response->json([
            'success' => $ok,
            'message' => $ok
                ? 'توکن تا ۹۰ روز دیگر تمدید شد'
                : str_value($result['message'] ?? 'یافت نشد'),
        ], $ok ? 200 : int_value($result['status'] ?? 422));
    }

    public function revokeExpired(): void
    {
        $this->validateCsrf();
        $count = $this->apiTokenService->revokeAllExpiredTokens();

        // FIX-M11-SF-003 (گزارش دوم): عملیاتِ destructive سراسری بدون audit بود —
        // incident response نمی‌توانست بفهمد چه کسی cleanup را اجرا کرده است.
        // سیاست مستند: «هر اجرای موفق» (شامل count=0) دقیقاً یک رکورد با
        // actor/action/count/IP ثبت می‌کند؛ اجرای ردشده (CSRF/RBAC) رکورد
        // موفقیت نمی‌سازد چون هرگز به این نقطه نمی‌رسد.
        $this->auditTrail->record(
            'admin.api_token.revoke_expired',
            (int)user_id(),
            [
                'action' => 'revoke_expired',
                'count' => $count,
                'ip' => get_client_ip(),
            ],
            (int)user_id()
        );

        $this->response->json(['success' => true, 'count' => $count]);
    }
}
