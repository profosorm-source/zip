<?php

namespace App\Controllers\Admin;

use Core\Response;
use App\Services\ApiTokenService;

class ApiTokenAdminController extends BaseAdminController
{
    // 🧹 DI-CLEANUP (2026-08-24): پراپرتی $auditTrail ارثبرده از BaseAdminController (با #[Inject]) است.
    // FIX-M11-H2 (گزارش ماژول ۱۱): وابستگی SearchOrchestrator حذف شد — مسیر قبلی
    // به AdminSearchGateway::searchTokens می‌رسید که برای api_tokens «placeholderِ
    // خالی» برمی‌گرداند (warning: crypto_tokens...) ⇒ جستجوی ادمین همیشه بی‌صدا
    // خالی بود. اکنون همیشه مسیر کانونی getTokensForAdmin (مدل با predicateهای
    // مشتق وضعیت) استفاده می‌شود.
    private ApiTokenService $apiTokenService;

    public function __construct(
        ApiTokenService $apiTokenService,
        \App\Services\AuditTrail $auditTrail
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->apiTokenService = $apiTokenService;
        $this->auditTrail = $auditTrail;
    }

    public function index(): void
    {
        $page = max(1, $this->request->int('page', 1));
        $search = trim($this->request->str('search', ''));
        $statusFilter = $this->request->str('status') !== '' ? $this->request->str('status') : null;
        $perPage = 30;
        $offset = ($page - 1) * $perPage;

        // FIX-M11-H2/M2: مسیر واحد کانونی — جستجو + فیلتر وضعیت همیشه از همان
        // قرارداد مدل عبور می‌کند (بدون ستون ناموجود status و بدون مسیر silent-empty).
        $result = $this->apiTokenService->getTokensForAdmin($page, $perPage, $search !== '' ? $search : null, $statusFilter);
        $tokens = $result['tokens'];
        $total = $result['total'];

        view('admin/api-tokens/index', [
            'title' => 'توکن‌های API',
            'tokens' => $tokens,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'stats' => $result['stats'] ?? [],
            'statusFilter' => $statusFilter,
            'search' => $search,
        ]);
    }

    public function revoke(): void
    {
        $this->validateCsrf();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? $this->request->input('id') ?? 0);
        if ($id <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه توکن نامعتبر است'], 422);
            return;
        }

        // FIX-M11-H5 (گزارش ماژول ۱۱): قرارداد حالت — سرویس تمایزِ revoked /
        // already_revoked / not_found را برمی‌گرداند؛ audit فقط پس از تغییرِ
        // واقعی ثبت می‌شود و پاسخ‌های خطا از هم تفکیک‌شده‌اند.
        $result = $this->apiTokenService->revokeToken($id);
        $ok = is_array($result) ? (bool)($result['success'] ?? false) : (bool)$result;
        $state = is_array($result) ? str_value($result['state'] ?? '') : 'revoked';

        if ($ok) {
            $this->auditTrail->record(
                'admin.api_token.revoke',
                (int)user_id(),
                ['token_id' => $id, 'action' => 'revoke', 'ip' => get_client_ip()],
                (int)user_id()
            );
        }

        $message = match (true) {
            $ok => 'باطل شد',
            $state === 'already_revoked' => 'این توکن قبلاً باطل شده است',
            $state === 'not_found' => 'توکن یافت نشد',
            default => is_array($result) ? str_value($result['message'] ?? 'یافت نشد') : 'یافت نشد',
        };

        $this->response->json(['success' => $ok, 'message' => $message, 'state' => $state]);
    }

    /**
     * W4-E (تصمیم مشتری #1): تمدید ۹۰ روزهٔ توکن از پنل ادمین.
     * دقیقاً الگوی revoke() بالا: CSRF با validateCsrf (middleware فریم‌ورک)،
     * اعتبارسنجی id، فراخوان سرویس، رکورد AuditTrail و پاسخ JSON.
     * مجوز ادمین توسط گارد $admin مسیر در routes/system.php اعمال می‌شود.
     */
    public function renew(): void
    {
        $this->validateCsrf();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? $this->request->input('id') ?? 0);
        if ($id <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه توکن نامعتبر است'], 422);
            return;
        }

        $result = $this->apiTokenService->renewToken($id);
        $ok = (bool)($result['success'] ?? false);
        $payload = is_array($result['payload'] ?? null) ? $result['payload'] : [];

        if ($ok) {
            $this->auditTrail->record(
                'admin.api_token.renew',
                (int)user_id(),
                [
                    'token_id' => $id,
                    'action' => 'renew',
                    'expires_at' => $payload['expires_at'] ?? null,
                    'ip' => get_client_ip(),
                ],
                (int)user_id()
            );
        }

        $this->response->json([
            'success' => $ok,
            'message' => $ok
                ? 'توکن تا ۹۰ روز دیگر تمدید شد'
                : str_value($result['message'] ?? 'یافت نشد'),
        ]);
    }

    public function revokeExpired(): void
    {
        $this->validateCsrf();
        $count = $this->apiTokenService->revokeAllExpiredTokens();
        $this->response->json(['success' => true, 'count' => $count]);
    }
}
