<?php

namespace App\Controllers\Admin;

use Core\Response;
use App\Services\ApiTokenService;
use App\Services\Search\SearchOrchestrator;

class ApiTokenAdminController extends BaseAdminController
{
    // 🧹 DI-CLEANUP (2026-08-24): پراپرتی $auditTrail ارثبرده از BaseAdminController (با #[Inject]) است.
    private ApiTokenService $apiTokenService;
    private SearchOrchestrator $searchService;

    public function __construct(
        ApiTokenService $apiTokenService,
        SearchOrchestrator $searchService,
        \App\Services\AuditTrail $auditTrail
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->apiTokenService = $apiTokenService;
        $this->searchService = $searchService;
        $this->auditTrail = $auditTrail;
    }

    public function index(): void
    {
        $page = max(1, $this->request->int('page', 1));
        $search = trim($this->request->str('search', ''));
        $statusFilter = $this->request->str('status') !== '' ? $this->request->str('status') : null;
        $perPage = 30;
        $offset = ($page - 1) * $perPage;

        $filters = [];
        if (!empty($statusFilter)) {
            $filters['status'] = $statusFilter;
        }

        // استفاده از SearchOrchestrator برای جستجو
        if (!empty($search)) {
            $result = $this->searchService->searchTokens($search, $filters, $perPage, $offset);
            $tokens = $result['items'] ?? [];
            $total = $result['total'] ?? 0;
        } else {
            $result = $this->apiTokenService->getTokensForAdmin($page, $perPage, $search, $statusFilter);
            $tokens = $result['tokens'];
            $total = $result['total'];
        }

        view('admin/api-tokens/index', [
            'title' => 'توکن‌های API',
            'tokens' => $tokens,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'stats' => $result['stats'] ?? [],
            'statusFilter' => $statusFilter,
            'search' => $search,
        ]);
    }

    public function revoke(): void
    {
        $this->validateCsrf();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? $this->request->input('id') ?? 0);
        if ($id <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه توکن نامعتبر است'], 422);
            return;
        }

        $ok = $this->apiTokenService->revokeToken($id);
        
        if ($ok) {
            $this->auditTrail->record(
                'admin.api_token.revoke',
                (int)user_id(),
                ['token_id' => $id, 'action' => 'revoke', 'ip' => get_client_ip()],
                (int)user_id()
            );
        }

        $this->response->json(['success' => $ok, 'message' => $ok ? 'باطل شد' : 'یافت نشد']);
    }

    /**
     * W4-E (تصمیم مشتری #1): تمدید ۹۰ روزهٔ توکن از پنل ادمین.
     * دقیقاً الگوی revoke() بالا: CSRF با validateCsrf (middleware فریم‌ورک)،
     * اعتبارسنجی id، فراخوان سرویس، رکورد AuditTrail و پاسخ JSON.
     * مجوز ادمین توسط گارد $admin مسیر در routes/system.php اعمال می‌شود.
     */
    public function renew(): void
    {
        $this->validateCsrf();
        $id = int_value($this->request->param('id') ?? $this->request->get('id') ?? $this->request->input('id') ?? 0);
        if ($id <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه توکن نامعتبر است'], 422);
            return;
        }

        $result = $this->apiTokenService->renewToken($id);
        $ok = (bool)($result['success'] ?? false);

        if ($ok) {
            $this->auditTrail->record(
                'admin.api_token.renew',
                (int)user_id(),
                [
                    'token_id' => $id,
                    'action' => 'renew',
                    'expires_at' => $result['payload']['expires_at'] ?? null,
                    'ip' => get_client_ip(),
                ],
                (int)user_id()
            );
        }

        $this->response->json([
            'success' => $ok,
            'message' => $ok
                ? 'توکن تا ۹۰ روز دیگر تمدید شد'
                : strval($result['message'] ?? 'یافت نشد'),
        ]);
    }

    public function revokeExpired(): void
    {
        $this->validateCsrf();
        $count = $this->apiTokenService->revokeAllExpiredTokens();
        $this->response->json(['success' => true, 'count' => $count]);
    }
}