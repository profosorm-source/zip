<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseAdminController;
use App\Services\AntiFraud\RiskPolicyService;

class RiskPolicyController extends BaseAdminController
{
    private RiskPolicyService $riskPolicyService;

    public function __construct(RiskPolicyService $policyService, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->riskPolicyService = $policyService;
    }

    public function index(): void
    {
        $this->view('admin.risk-policies.index', [
            'policies' => $this->riskPolicyService->getPoliciesWithDefaults(),
        ]);
    }

    public function update(): void
    {
        if (!$this->request->isPost()) {
            redirect('/admin/risk-policies');
        }

        $domain = trim($this->request->str('domain'));
        $keyName = trim($this->request->str('key_name'));
        $value = $this->request->post('value', '');
        $valueType = trim($this->request->str('value_type', 'string'));
        $description = trim($this->request->str('description'));

        if ($domain === '' || $keyName === '') {
            $this->session->setFlash('error', 'دامنه و کلید الزامی است.');
            redirect('/admin/risk-policies');
        }

        $adminId = $this->session->get('user_id');

        // FIX-R36-W3 (F-A15-07): پیش از upsert، ردیفِ قبلی (id/مقادیر) خوانده می‌شود
        // تا تغییر سیاست ریسک در AdminAuditTrail با capture مقادیر قدیم ثبت شود —
        // قبلاً فقط risk_policies.updated_by نوشته می‌شد و who-changed-what هیچ‌جا
        // قابل مشاهده نبود. خواندنِ حسابرسی هرگز مسیرِ update را بلاک نمی‌کند
        // (دسترسی DB از راه QueryBuilder، هم‌قرارداد «مدل‌ها مالکِ SQL خام»).
        $oldRow = null;
        try {
            $oldRow = db()->table('risk_policies')
                ->where('domain', '=', $domain)
                ->where('key_name', '=', $keyName)
                ->first();
        } catch (\Throwable $auditFetchError) {
            if (isset($this->logger)) {
                $this->logger->warning('admin.risk_policy.audit_prefetch_failed', ['error' => $auditFetchError->getMessage()]);
            }
        }

        $ok = $this->riskPolicyService->set(
            $domain,
            $keyName,
            $value,
            $valueType,
            $adminId ? int_value($adminId) : null,
            $description
        );

        if ($ok) {
            // FIX-R36-W3 (F-A15-07): رکورد حسابرسی با old/new values — idِ ردیف بعد
            // از upsert (برای رکورد تازه، id جدید خوانده می‌شود؛ صفر فقط وقتی هیچ
            // ردیفی خواندنی نبود که خودش یعنی set شکست خورده).
            $entityId = 0;
            try {
                $idRow = db()->table('risk_policies')
                    ->where('domain', '=', $domain)
                    ->where('key_name', '=', $keyName)
                    ->first();
                $entityId = $idRow ? (int)$idRow->id : 0;
            } catch (\Throwable $auditIdError) {
                if (isset($this->logger)) {
                    $this->logger->warning('admin.risk_policy.audit_id_fetch_failed', ['error' => $auditIdError->getMessage()]);
                }
            }

            $oldValues = $oldRow ? [
                'value'       => str_value($oldRow->value ?? ''),
                'value_type'  => str_value($oldRow->value_type ?? ''),
                'description' => str_value($oldRow->description ?? ''),
            ] : null;
            $newValues = [
                'value'       => str_value($value),
                'value_type'  => $valueType,
                'description' => $description,
            ];
            $this->auditLog('risk_policy.updated', 'risk_policy', $entityId, $oldValues, $newValues);

            $this->session->setFlash('success', 'تنظیمات با موفقیت ذخیره شد.');
            redirect('/admin/risk-policies');
        }

        $this->session->setFlash('error', 'خطا در ذخیره تنظیمات.');
        redirect('/admin/risk-policies');
    }
}