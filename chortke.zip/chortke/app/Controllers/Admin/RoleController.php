<?php

namespace App\Controllers\Admin;

use App\Models\Role;
use App\Models\Permission;
use App\Middleware\PermissionMiddleware;
use App\Controllers\Admin\BaseAdminController;

class RoleController extends BaseAdminController
{
    private \App\Models\Role $roleModel;
    private \App\Models\Permission $permissionModel;

    /**
     * FIX-18Q (P2-19): مجموعه مجوزهای «سطح super_admin» — از نقشهٔ config/admin_permissions.php.
     * طبق همان کاتالوگ، super_admin از گارد bypass می‌شود؛ پس هر نقشی که این مجوزها را
     * بگیرد عملاً به سطح super_admin دست می‌یابد (RBAC خودش، تنظیمات سیستم، فیچرفلگ‌ها،
     * حسابرسی، حذف حساب). تخصیصِ هرکدام از این‌ها فقط توسط super_admin مجاز است؛
     * ویرایش غیرممتاز نقش‌ها (نام/توضیح/وضعیت/مجوزهای عادی) دست‌نخورده کار می‌کند.
     */
    private const SUPER_ADMIN_LEVEL_PERMISSIONS = [
        'roles.view', 'roles.manage',
        'admin.view_settings', 'admin.edit_settings',
        'features.view', 'features.manage',
        'audit.view', 'audit.export',
        'account_deletion.view', 'account_deletion.manage',
    ];

    // BUGFIX-CTRL-RAW-SQL-2026-06: lookup of affected users on role change
    // moved out of inline SQL into User::findIdsByRoleId().
    private \App\Models\User $userModel;
    public function __construct(
        \App\Models\Permission $permissionModel,
        \App\Models\Role $roleModel,
        \App\Models\User $userModel,
        ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->permissionModel = $permissionModel;
        $this->roleModel = $roleModel;
        $this->userModel = $userModel;
    }

    /**
     * لیست نقش‌ها
     */
    public function index(): void
    {
        $roles = $this->roleModel->allRoles(false); // شامل غیرفعال‌ها و لود خودکار user_count
        
        $this->logger->activity('roles.view', 'مشاهده لیست نقش‌ها', user_id(), []);
        
        view('admin.roles.index', [
            'roles' => $roles,
        ]);
    }
    
    /**
     * فرم ایجاد نقش
     */
    public function create(): void
    {
        $permModel = $this->permissionModel;
        $groupedPermissions = $permModel->allGrouped();
        $groupLabels = $permModel->groupLabels();
        
        view('admin.roles.create', [
            'groupedPermissions' => $groupedPermissions,
            'groupLabels' => $groupLabels,
        ]);
    }
    
    /**
     * ذخیره نقش جدید
     */
    public function store(): void
    {

        
        $validator = $this->validatorFactory()->make($this->request->all(), [
            'name'        => 'required|min:2|max:50',
            'slug'        => 'required|min:2|max:50|alpha_dash',
            'description' => 'max:255',
        ]);
        
        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا در اعتبارسنجی');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/create'));
        }
        
        $data = $validator->data();
        $roleModel = $this->roleModel;
        
        // بررسی تکراری نبودن slug
        if ($roleModel->slugExists(str_value($data['slug'] ?? ''))) {
            $this->session->setFlash('error', 'این شناسه (slug) قبلاً استفاده شده است.');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/create'));
        }

        $role = $roleModel->create([
            'name'        => $data['name'],
            'slug'        => $data['slug'],
            'description' => $data['description'] ?? null,
            'is_system'   => 0,
            'is_active'   => 1,
        ]);
        
        if (!$role) {
            $this->session->setFlash('error', 'خطا در ایجاد نقش. لطفاً دوباره تلاش کنید.');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/create'));
        }
        
        // همگام‌سازی دسترسی‌ها
        $permissionIds = array_map(fn($v) => int_value($v), (array)($this->request->post('permissions') ?? []));

        // FIX-18Q (P2-19): گیت اعطای مجوزهای سطح super_admin (فقط super_admin).
        $this->rejectSuperAdminPermissionGrant($permissionIds, url('/admin/roles/create'));

        $roleObj = is_object($role) ? $role : (object)['id' => (int)$role, 'name' => '', 'slug' => ''];
        $roleId = (int)($roleObj->id ?? 0);
        $roleName = (string)($roleObj->name ?? '');
        $roleSlug = (string)($roleObj->slug ?? '');
        if (!empty($permissionIds) && $roleId > 0) {
            $roleModel->syncPermissions($roleId, $permissionIds);
        }
        
        $this->logger->activity('roles.create', 'ایجاد نقش جدید', user_id(), [
            'role_id'   => $roleId,
            'role_name' => $roleName,
            'role_slug' => $roleSlug,
        ]);
        
        $this->session->setFlash('success', 'نقش «' . e($roleName) . '» با موفقیت ایجاد شد.');
        redirect(url('/admin/roles'));
    }
    
    /**
     * FIX-18Q (P2-19): ردِ اعطای مجوزهای سطح super_admin توسط ادمینِ غیر super_admin.
     * الگوی رد: همان استایل forbidden کنترلر (flash + redirect) با ثبت لاگ هشدار.
     * fail-closed: اگر actor id نامعتبر باشد، super_admin فرض نمی‌شود.
     */
     /** @param list<int> $permissionIds */
     private function rejectSuperAdminPermissionGrant(array $permissionIds, string $errorBackUrl): void
    {
        $permissionIds = array_values(array_filter(array_map('intval', $permissionIds)));
        if ($permissionIds === []) {
            return;
        }

        if ($this->permissionModel->isSuperAdmin((int)(user_id() ?? 0))) {
            return; // super_admin: گیت فقط برای غیرسوپر است.
        }

        $privilegedIds = [];
        foreach ($this->permissionModel->all() as $perm) {
            if (in_array((string)($perm->slug ?? ''), self::SUPER_ADMIN_LEVEL_PERMISSIONS, true)) {
                $privilegedIds[] = (int)($perm->id ?? 0);
            }
        }

        $hit = array_values(array_intersect($permissionIds, array_filter($privilegedIds)));
        if ($hit !== []) {
            $this->logger->warning('roles.super_admin_grant.denied', [
                'admin_id'                   => user_id(),
                'attempted_permission_ids'   => $hit,
            ]);
            $this->session->setFlash('error', 'تخصیص مجوزهای سطح super_admin (نقش‌ها، تنظیمات سیستم، فیچرفلگ‌ها، حسابرسی، حذف حساب) فقط توسط super_admin مجاز است.');
            $this->session->setFlash('old', $this->request->all());
            redirect($errorBackUrl);
        }
    }

    /**
     * فرم ویرایش نقش
     */
    public function edit(): void
    {
                $id = $this->request->int('id');
        
        $roleModel = $this->roleModel;
        $role = $roleModel->find($id);
        
        if (!$role) {
            \http_response_code(404);
            include __DIR__ . '/../../../views/errors/404.php';
            exit;
        }
        
        $permModel = $this->permissionModel;
        $groupedPermissions = $permModel->allGrouped();
        $groupLabels = $permModel->groupLabels();
        $rolePermissionIds = \array_map(function ($p) {
            return $p->id;
        }, $roleModel->getPermissions($id));
        
        view('admin.roles.edit', [
            'role'                => $role,
            'groupedPermissions'  => $groupedPermissions,
            'groupLabels'         => $groupLabels,
            'rolePermissionIds'   => $rolePermissionIds,
        ]);
    }
    
    /**
     * بروزرسانی نقش
     */
    public function update(): void
    {
        $id = $this->request->int('id');
        $roleModel = $this->roleModel;
        $role = $roleModel->find($id);
        
        if (!$role) {
            $this->session->setFlash('error', 'نقش مورد نظر یافت نشد.');
            redirect(url('/admin/roles'));
        }
        

        
        $validator = $this->validatorFactory()->make($this->request->all(), [
            'name'        => 'required|min:2|max:50',
            'description' => 'max:255',
        ]);
        
        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا در اعتبارسنجی');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/' . $id . '/edit'));
        }
        
        $data = $validator->data();

        // 🛡️ FIX-S14-4: قرارداد خواهران (delete/toggle) — نقش سیستمی تغییرناپذیر است.
        // شکل قبلی برای نقش‌های سیستمی هم rename و syncPermissions اجرا می‌کرد؛
        // چون ویوی edit ستون‌های permissions[] را برای نقش سیستمی هم رندر می‌کند،
        // یک ذخیرهٔ ساده می‌توانست کل ست مجوز نقش سیستمی (مثل super_admin) را
        // پاک/بازنویسی کند. اکنون: برای is_system فقط توضیحات؛ نام تغییرناپذیر
        // (fail-loud) و syncPermissions هرگز برای نقش سیستمی اجرا نمی‌شود.
        $submittedName = trim(str_value($data['name'] ?? ''));
        if ($role->is_system) {
            if ($submittedName !== (string)$role->name) {
                $this->session->setFlash('error', 'نقش‌های سیستمی قابل تغییر نام نیستند.');
                redirect(url('/admin/roles/' . $id . '/edit'));
            }

            $roleModel->update($id, [
                'name'        => $role->name,
                'description' => $data['description'] ?? null,
            ]);

            foreach ($this->userModel->findIdsByRoleId($id) as $uid) {
                PermissionMiddleware::clearCache($uid);
            }

            $this->logger->activity('roles.update_system', 'ویرایش توضیحات نقش سیستمی', user_id(), [
                'role_id'   => $id,
                'role_name' => $role->name,
                'permissions_change_attempted' => !empty((array)($this->request->post('permissions') ?? [])),
            ]);

            $this->session->setFlash('success', 'نقش سیستمی «' . e($role->name) . '» بروزرسانی شد (فقط توضیحات؛ مجوزها و نام نقش‌های سیستمی تغییرناپذیرند).');
            redirect(url('/admin/roles'));
        }

        $updateData = [
            'name'        => $data['name'],
            'description' => $data['description'] ?? null,
        ];
        
        // فقط غیر سیستمی‌ها قابل غیرفعال‌سازی — مسیر is_system بالا زودتر
        // خروج/ری‌دایرکت شده است، پس اینجا همیشه غیرسیستمی است:
        $updateData['is_active'] = $this->request->post('is_active') ? 1 : 0;
        
        $roleModel->update($id, $updateData);
        
        // همگام‌سازی دسترسی‌ها
        $permissionIds = array_map(fn($v) => int_value($v), (array)($this->request->post('permissions') ?? []));

        // FIX-18Q (P2-19): گیت اعطای مجوزهای سطح super_admin (فقط super_admin).
        $this->rejectSuperAdminPermissionGrant($permissionIds, url('/admin/roles/' . $id . '/edit'));

        $roleModel->syncPermissions($id, $permissionIds);
        
        // BUGFIX-CTRL-RAW-SQL-2026-06: user-id lookup moved to User model.
        foreach ($this->userModel->findIdsByRoleId($id) as $uid) {
            PermissionMiddleware::clearCache($uid);
        }
        
        $this->logger->activity('roles.update', 'ویرایش نقش', user_id(), [
            'role_id'   => $id,
            'role_name' => $data['name'],
        ]);

        $this->session->setFlash('success', 'نقش «' . e($data['name']) . '» با موفقیت بروزرسانی شد.');
        redirect(url('/admin/roles'));
    }
    
    /**
     * حذف نقش (Ajax)
     */
    public function delete(): void
    {


        $id = $this->request->int('id');
        $roleModel = $this->roleModel;
        $role = $roleModel->find($id);
        
        if (!$role) {
            $this->response->json([
                'success' => false,
                'message' => 'نقش مورد نظر یافت نشد.'
            ], 404);
            return;
        }
        
        if ($role->is_system) {
            $this->response->json([
                'success' => false,
                'message' => 'نقش‌های سیستمی قابل حذف نیستند.'
            ], 403);
            return;
        }
        
        // بررسی عدم وجود کاربر با این نقش
        $userCount = $roleModel->getUserCount($id);
        if ($userCount > 0) {
            $this->response->json([
                'success' => false,
                'message' => "این نقش {$userCount} کاربر دارد. ابتدا نقش کاربران را تغییر دهید."
            ], 422);
            return;
        }
        
        $deleted = $roleModel->delete($id);
        
        if (!$deleted) {
            $this->response->json([
                'success' => false,
                'message' => 'خطا در حذف نقش.'
            ], 500);
            return;
        }
        
        $this->logger->activity('roles.delete', 'حذف نقش', user_id(), [
            'role_id'   => $id,
            'role_name' => $role->name,
            'role_slug' => $role->slug,
        ]);
        
        $this->response->json([
            'success' => true,
            'message' => 'نقش «' . $role->name . '» با موفقیت حذف شد.'
        ]);
    }
    
    /**
     * تغییر وضعیت فعال/غیرفعال (Ajax)
     */
    public function toggle(): void
    {
        $id = $this->request->int('id');
        $roleModel = $this->roleModel;
        $role = $roleModel->find($id);
        
        if (!$role) {
            $this->response->json([
                'success' => false,
                'message' => 'نقش مورد نظر یافت نشد.'
            ], 404);
            return;
        }
        
        if ($role->is_system) {
            $this->response->json([
                'success' => false,
                'message' => 'وضعیت نقش‌های سیستمی قابل تغییر نیست.'
            ], 403);
            return;
        }
        
        $newStatus = $role->is_active ? 0 : 1;
        $roleModel->update($id, ['is_active' => $newStatus]);
        
        // BUGFIX-CTRL-RAW-SQL-2026-06: user-id lookup moved to User model.
        foreach ($this->userModel->findIdsByRoleId($id) as $uid) {
            PermissionMiddleware::clearCache($uid);
        }
        
        $statusText = $newStatus ? 'فعال' : 'غیرفعال';
        
        $this->logger->activity('roles.toggle', "تغییر وضعیت نقش به {$statusText}", user_id(), [
            'role_id' => $id,
            'new_status' => $newStatus,
        ]);
        
        $this->response->json([
            'success' => true,
            'message' => "نقش «{$role->name}» {$statusText} شد.",
            'new_status' => $newStatus,
        ]);
    }
}
