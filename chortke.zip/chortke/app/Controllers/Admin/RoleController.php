<?php

namespace App\Controllers\Admin;

use App\Models\Role;
use App\Models\Permission;
use App\Middleware\PermissionMiddleware;
use App\Controllers\Admin\BaseAdminController;

class RoleController extends BaseAdminController
{
    private \App\Models\Role $roleModel;
    private \App\Models\Permission $permissionModel;

    /**
     * FIX-18Q (P2-19) + 🛡️ FIX-M9-10 (گزارش ماژول ۹): مجموعهٔ مجوزهای «سطح super_admin».
     * طبق گزارش قبلی، این allowlist ناقص بود: مجوزهای پرریسکِ مجاز در کاتالوگ مثل
     * admin.export.users / admin.export.transactions / finance.withdrawal.approve
     * شامل نبودند و مدیرِ دارایِ roles.manage می‌توانست آنها را به نقشِ سفارشی اعطا کند
     * (escalation شرطی روی دارندگانِ user_roles). اکنون طبقه‌بندیِ least-privilege کامل شد:
     * خروجیِ PII، عملیاتِ مالی، زیرساخت/امنیت، نقش‌ها، تنظیمات، حسابرسی، حذف حساب،
     * cron و دسترسیِ PII مقیِ KYC (kyc.pii — FIX-M10-04) فقط با super_admin قابلِ تفویض‌اند.
     */
    private const SUPER_ADMIN_LEVEL_PERMISSIONS = [
        'roles.view', 'roles.manage',
        'admin.view_settings', 'admin.edit_settings', 'admin.execute_cron_jobs',
        'features.view', 'features.manage',
        'audit.view', 'audit.export',
        'account_deletion.view', 'account_deletion.manage',
        // خروجی‌های حساس (PII/مالی) — جدید (M9-10)
        'admin.export.users', 'admin.export.transactions',
        'admin.export.withdrawals', 'admin.export.audit',
        // عملیاتِ مالی — جدید (M9-10)
        'finance.withdrawal.approve', 'finance.deposit.approve',
        'finance.card.approve', 'finance.crypto.approve', 'finance.transaction.approve',
        'vitrine.finance',
        // زیرساخت/امنیت — جدید (M9-10)
        'backups.manage', 'database.view', 'sentry.manage',
        // دسترسیِ PII مقیِ KYC — جدید (M9-10/M10-04)
        'kyc.pii',
    ];

    // BUGFIX-CTRL-RAW-SQL-2026-06: lookup of affected users on role change
    // moved out of inline SQL into User::findIdsByRoleId().
    private \App\Models\User $userModel;
    public function __construct(
        \App\Models\Permission $permissionModel,
        \App\Models\Role $roleModel,
        \App\Models\User $userModel,
        ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->permissionModel = $permissionModel;
        $this->roleModel = $roleModel;
        $this->userModel = $userModel;
    }

    /**
     * لیست نقش‌ها
     */
    public function index(): void
    {
        $roles = $this->roleModel->allRoles(false); // شامل غیرفعال‌ها و لود خودکار user_count
        
        $this->logger->activity('roles.view', 'مشاهده لیست نقش‌ها', user_id(), []);
        
        view('admin.roles.index', [
            'roles' => $roles,
        ]);
    }
    
    /**
     * فرم ایجاد نقش
     */
    public function create(): void
    {
        $permModel = $this->permissionModel;
        $groupedPermissions = $permModel->allGrouped();
        $groupLabels = $permModel->groupLabels();
        
        view('admin.roles.create', [
            'groupedPermissions' => $groupedPermissions,
            'groupLabels' => $groupLabels,
        ]);
    }
    
    /**
     * ذخیره نقش جدید
     */
    public function store(): void
    {

        
        $validator = $this->validatorFactory()->make($this->request->all(), [
            'name'        => 'required|min:2|max:50',
            'slug'        => 'required|min:2|max:50|alpha_dash',
            'description' => 'max:255',
        ]);
        
        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا در اعتبارسنجی');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/create'));
        }
        
        $data = $validator->validated(); // FIX-M1M2: allowlist
        $roleModel = $this->roleModel;
        
        // بررسی تکراری نبودن slug
        if ($roleModel->slugExists(str_value($data['slug'] ?? ''))) {
            $this->session->setFlash('error', 'این شناسه (slug) قبلاً استفاده شده است.');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/create'));
        }

        $role = null;

        // 🛡️ FIX-M9-04 (گزارش ماژول ۹): گیتِ مجوزهای ممتاز باید «قبل از اولین write»
        // اجرا شود؛ شکل قبلی اول createRole می‌کرد و بعد رد می‌کرد — نتیجه: نقشِ
        // خالی/یتیم روی درخواستِ ردشده باقی می‌ماند.
        $permissionIds = array_map(fn($v) => int_value($v), (array)($this->request->post('permissions') ?? []));
        $this->rejectUnauthorizedPermissionGrant($permissionIds, url('/admin/roles/create'));

        // 🛡️ FIX-M9-04/M9-05: ایجاد نقش + sync مجوزها در «یک تراکنش اتمیک» —
        // شکستِ sync (مثلاً permission ID نامعتبر) کلِ ایجاد را rollback می‌کند و
        // پاسخِ خطا با واقعیتِ DB سازگار است (قبلاً sync false بی‌پاسخ می‌ماند و
        // پیام موفقیت نمایش داده می‌شد).
        try {
            $this->db()->beginTransaction();

            $role = $roleModel->create([
                'name'        => $data['name'],
                'slug'        => $data['slug'],
                'description' => $data['description'] ?? null,
                'is_system'   => 0,
                'is_active'   => 1,
            ]);

            if (!$role) {
                throw new \RuntimeException('role_create_failed');
            }

            $roleObj = is_object($role) ? $role : (object)['id' => (int)$role, 'name' => '', 'slug' => ''];
            $roleId = (int)($roleObj->id ?? 0);
            if ($roleId <= 0) {
                throw new \RuntimeException('role_id_missing');
            }

            $roleModel->syncPermissionsInTx($roleId, $permissionIds);

            $this->db()->commit();
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) {
            if ($this->db()->inTransaction()) {
                $this->db()->rollback();
            }
            $this->logger->error('roles.store.transaction_failed', [
                'error' => $e->getMessage(),
                'exception' => get_class($e),
            ]);
            $this->session->setFlash('error', 'خطا در ایجاد نقش. هیچ تغییری ثبت نشد؛ لطفاً دوباره تلاش کنید.');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/create'));
        }

        $roleObj = is_object($role) ? $role : (object)['id' => 0, 'name' => '', 'slug' => ''];
        $roleId = (int)($roleObj->id ?? 0);
        $roleName = (string)($roleObj->name ?? '');
        $roleSlug = (string)($roleObj->slug ?? '');

        $this->logger->activity('roles.create', 'ایجاد نقش جدید', user_id(), [
            'role_id'   => $roleId,
            'role_name' => $roleName,
            'role_slug' => $roleSlug,
            'permission_count' => count(array_filter($permissionIds)),
        ]);

        $this->session->setFlash('success', 'نقش «' . e($roleName) . '» با موفقیت ایجاد شد.');
        redirect(url('/admin/roles'));
    }
    
    /**
     * FIX-18Q (P2-19) + 🛡️ FIX-M9-10 (گزارش ماژول ۹): گیتِ تفویضِ مجوز — قبل از هر write.
     * دو لایهٔ دفاعی برای ادمینِ غیر super_admin:
     *   ① هیچ مجوزِ «سطح super_admin» (فهرست بالا) قابلِ تفویض نیست.
     *   ② قاعدهٔ زیرمجموعه: actor فقط می‌تواند مجوزی را تفویض کند که «خودش دارد»
     *      (از Permission::getUserPermissions — پس از FIX-M9-01 فقط نقش‌های فعال معتبرند).
     * super_admin از هر دو لایه مستثناست؛ fail-closed روی actor id نامعتبر.
     */
     /** @param list<int> $permissionIds */
     private function rejectUnauthorizedPermissionGrant(array $permissionIds, string $errorBackUrl): void
    {
        $permissionIds = array_values(array_filter(array_map('intval', $permissionIds)));
        if ($permissionIds === []) {
            return;
        }

        $actorId = (int)(user_id() ?? 0);
        if ($actorId > 0 && $this->permissionModel->isSuperAdmin($actorId)) {
            return; // super_admin: گیت فقط برای غیرسوپر است.
        }

        $allPerms = $this->permissionModel->all();
        $slugById = [];
        foreach ($allPerms as $perm) {
            $slugById[(int)($perm->id ?? 0)] = (string)($perm->slug ?? '');
        }

        $privilegedIds = [];
        foreach ($slugById as $pid => $slug) {
            if (in_array($slug, self::SUPER_ADMIN_LEVEL_PERMISSIONS, true)) {
                $privilegedIds[] = $pid;
            }
        }

        $hit = array_values(array_intersect($permissionIds, array_filter($privilegedIds)));
        if ($hit !== []) {
            $this->logger->warning('roles.super_admin_grant.denied', [
                'admin_id'                   => $actorId,
                'attempted_permission_ids'   => $hit,
            ]);
            $this->session->setFlash('error', 'تخصیص مجوزهای سطح super_admin (نقش‌ها، تنظیمات سیستم، فیچرفلگ‌ها، حسابرسی، خروجی‌های PII، عملیات مالی، زیرساخت، حذف حساب) فقط توسط super_admin مجاز است.');
            $this->session->setFlash('old', $this->request->all());
            redirect($errorBackUrl);
        }

        // ② قاعدهٔ زیرمجموعهٔ تفویض — fail-closed روی actor نامعتبر
        $actorSlugs = $actorId > 0 ? (array)$this->permissionModel->getUserPermissions($actorId) : [];
        $notHeld = [];
        foreach ($permissionIds as $pid) {
            $slug = $slugById[$pid] ?? null;
            if ($slug === null || !in_array($slug, $actorSlugs, true)) {
                $notHeld[] = $pid;
            }
        }
        if ($notHeld !== []) {
            $this->logger->warning('roles.delegation_subset.denied', [
                'admin_id'                  => $actorId,
                'not_held_permission_ids'   => $notHeld,
            ]);
            $this->session->setFlash('error', 'شما فقط می‌توانید مجوزهایی را تفویض کنید که خودتان دارید. برخی مجوزهای انتخاب‌شده در اختیار شما نیست.');
            $this->session->setFlash('old', $this->request->all());
            redirect($errorBackUrl);
        }
    }

    /**
     * فرم ویرایش نقش
     */
    public function edit(): void
    {
                $id = $this->request->int('id');
        
        $roleModel = $this->roleModel;
        $role = $roleModel->find($id);
        
        if (!$role) {
            \http_response_code(404);
            include __DIR__ . '/../../../views/errors/404.php';
            exit;
        }
        
        $permModel = $this->permissionModel;
        $groupedPermissions = $permModel->allGrouped();
        $groupLabels = $permModel->groupLabels();
        $rolePermissionIds = \array_map(function ($p) {
            return $p->id;
        }, $roleModel->getPermissions($id));
        
        view('admin.roles.edit', [
            'role'                => $role,
            'groupedPermissions'  => $groupedPermissions,
            'groupLabels'         => $groupLabels,
            'rolePermissionIds'   => $rolePermissionIds,
        ]);
    }
    
    /**
     * بروزرسانی نقش
     */
    public function update(): void
    {
        $id = $this->request->int('id');
        $roleModel = $this->roleModel;
        $role = $roleModel->find($id);
        
        if (!$role) {
            $this->session->setFlash('error', 'نقش مورد نظر یافت نشد.');
            redirect(url('/admin/roles'));
        }
        

        
        $validator = $this->validatorFactory()->make($this->request->all(), [
            'name'        => 'required|min:2|max:50',
            'description' => 'max:255',
        ]);
        
        if ($validator->fails()) {
            $this->session->setFlash('error', $validator->errors()[0] ?? 'خطا در اعتبارسنجی');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/' . $id . '/edit'));
        }
        
        $data = $validator->validated(); // FIX-M1M2: allowlist

        // 🛡️ FIX-S14-4: قرارداد خواهران (delete/toggle) — نقش سیستمی تغییرناپذیر است.
        // شکل قبلی برای نقش‌های سیستمی هم rename و syncPermissions اجرا می‌کرد؛
        // چون ویوی edit ستون‌های permissions[] را برای نقش سیستمی هم رندر می‌کند،
        // یک ذخیرهٔ ساده می‌توانست کل ست مجوز نقش سیستمی (مثل super_admin) را
        // پاک/بازنویسی کند. اکنون: برای is_system فقط توضیحات؛ نام تغییرناپذیر
        // (fail-loud) و syncPermissions هرگز برای نقش سیستمی اجرا نمی‌شود.
        $submittedName = trim(str_value($data['name'] ?? ''));
        if ($role->is_system) {
            if ($submittedName !== (string)$role->name) {
                $this->session->setFlash('error', 'نقش‌های سیستمی قابل تغییر نام نیستند.');
                redirect(url('/admin/roles/' . $id . '/edit'));
            }

            $roleModel->update($id, [
                'name'        => $role->name,
                'description' => $data['description'] ?? null,
            ]);

            foreach ($this->userModel->findIdsByRoleId($id) as $uid) {
                PermissionMiddleware::clearCache($uid);
            }

            $this->logger->activity('roles.update_system', 'ویرایش توضیحات نقش سیستمی', user_id(), [
                'role_id'   => $id,
                'role_name' => $role->name,
                'permissions_change_attempted' => !empty((array)($this->request->post('permissions') ?? [])),
            ]);

            $this->session->setFlash('success', 'نقش سیستمی «' . e($role->name) . '» بروزرسانی شد (فقط توضیحات؛ مجوزها و نام نقش‌های سیستمی تغییرناپذیرند).');
            redirect(url('/admin/roles'));
        }

        $updateData = [
            'name'        => $data['name'],
            'description' => $data['description'] ?? null,
        ];
        
        // فقط غیر سیستمی‌ها قابل غیرفعال‌سازی — مسیر is_system بالا زودتر
        // خروج/ری‌دایرکت شده است، پس اینجا همیشه غیرسیستمی است:
        $updateData['is_active'] = $this->request->post('is_active') ? 1 : 0;

        // همگام‌سازی دسترسی‌ها
        $permissionIds = array_map(fn($v) => int_value($v), (array)($this->request->post('permissions') ?? []));

        // 🛡️ FIX-M9-04: گیتِ تفویض «قبل از هر write» — شکل قبلی اول name/description/
        // is_active را ذخیره می‌کرد و بعد رد می‌کرد؛ درخواستِ ردشده تغییراتِ پایه را
        // پایدار باقی می‌گذاشت (پاسخِ رد به‌معنای عدمِ تغییر نبود).
        $this->rejectUnauthorizedPermissionGrant($permissionIds, url('/admin/roles/' . $id . '/edit'));

        // 🛡️ FIX-M9-05: update پایه + sync مجوزها در یک تراکنش اتمیک — شکستِ sync
        // کلِ تغییر را rollback می‌کند (قبلاً return value نادیده و پیام موفقیت می‌آمد
        // حتی اگر مجوزها sync نشده بودند).
        try {
            $this->db()->beginTransaction();

            if (!$this->roleModel->update($id, $updateData)) {
                throw new \RuntimeException('role_update_failed');
            }

            $this->roleModel->syncPermissionsInTx($id, $permissionIds);

            $this->db()->commit();
        } catch (\Throwable $e) {
            if ($this->db()->inTransaction()) {
                $this->db()->rollback();
            }
            $this->logger->error('roles.update.transaction_failed', [
                'role_id' => $id,
                'error' => $e->getMessage(),
                'exception' => get_class($e),
            ]);
            $this->session->setFlash('error', 'خطا در بروزرسانی نقش. هیچ تغییری ثبت نشد؛ لطفاً دوباره تلاش کنید.');
            $this->session->setFlash('old', $this->request->all());
            redirect(url('/admin/roles/' . $id . '/edit'));
        }
        
        // BUGFIX-CTRL-RAW-SQL-2026-06: user-id lookup moved to User model.
        // FIX-M9-07: اعضای نقشِ ثانویه (user_roles) هم اکنون پوشش داده می‌شوند.
        foreach ($this->userModel->findIdsByRoleId($id) as $uid) {
            PermissionMiddleware::clearCache($uid);
        }
        
        $this->logger->activity('roles.update', 'ویرایش نقش', user_id(), [
            'role_id'   => $id,
            'role_name' => $data['name'],
        ]);

        $this->session->setFlash('success', 'نقش «' . e($data['name']) . '» با موفقیت بروزرسانی شد.');
        redirect(url('/admin/roles'));
    }
    
    /**
     * حذف نقش (Ajax)
     */
    public function delete(): void
    {


        $id = $this->request->int('id');
        $roleModel = $this->roleModel;
        $role = $roleModel->find($id);
        
        if (!$role) {
            $this->response->json([
                'success' => false,
                'message' => 'نقش مورد نظر یافت نشد.'
            ], 404);
            return;
        }
        
        if ($role->is_system) {
            $this->response->json([
                'success' => false,
                'message' => 'نقش‌های سیستمی قابل حذف نیستند.'
            ], 403);
            return;
        }
        
        // بررسی عدم وجود کاربر با این نقش
        $userCount = $roleModel->getUserCount($id);
        if ($userCount > 0) {
            $this->response->json([
                'success' => false,
                'message' => "این نقش {$userCount} کاربر دارد. ابتدا نقش کاربران را تغییر دهید."
            ], 422);
            return;
        }
        
        $deleted = $roleModel->delete($id);
        
        if (!$deleted) {
            $this->response->json([
                'success' => false,
                'message' => 'خطا در حذف نقش.'
            ], 500);
            return;
        }
        
        $this->logger->activity('roles.delete', 'حذف نقش', user_id(), [
            'role_id'   => $id,
            'role_name' => $role->name,
            'role_slug' => $role->slug,
        ]);
        
        $this->response->json([
            'success' => true,
            'message' => 'نقش «' . $role->name . '» با موفقیت حذف شد.'
        ]);
    }
    
    /**
     * تغییر وضعیت فعال/غیرفعال (Ajax)
     */
    public function toggle(): void
    {
        $id = $this->request->int('id');
        $roleModel = $this->roleModel;
        $role = $roleModel->find($id);
        
        if (!$role) {
            $this->response->json([
                'success' => false,
                'message' => 'نقش مورد نظر یافت نشد.'
            ], 404);
            return;
        }
        
        if ($role->is_system) {
            $this->response->json([
                'success' => false,
                'message' => 'وضعیت نقش‌های سیستمی قابل تغییر نیست.'
            ], 403);
            return;
        }
        
        $newStatus = $role->is_active ? 0 : 1;
        $roleModel->update($id, ['is_active' => $newStatus]);
        
        // BUGFIX-CTRL-RAW-SQL-2026-06: user-id lookup moved to User model.
        foreach ($this->userModel->findIdsByRoleId($id) as $uid) {
            PermissionMiddleware::clearCache($uid);
        }
        
        $statusText = $newStatus ? 'فعال' : 'غیرفعال';
        
        $this->logger->activity('roles.toggle', "تغییر وضعیت نقش به {$statusText}", user_id(), [
            'role_id' => $id,
            'new_status' => $newStatus,
        ]);
        
        $this->response->json([
            'success' => true,
            'message' => "نقش «{$role->name}» {$statusText} شد.",
            'new_status' => $newStatus,
        ]);
    }
}
