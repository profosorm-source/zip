<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use Core\Controller;
use App\Services\MessageModerationService;

/**
 * MessageModerationController
 * مدیریت و مدرسیون پیام‌های کاربران
 */
class MessageModerationController extends BaseAdminController
{
    // L-04: این کنترلر به نقش support مجاز است؛ گیت ورود = ناحیهٔ ادمین، و عملیات با authorizeById('messages.moderate') ریزدانه محدود می‌شود.
    protected function enforceAdminAccess(): void
    {
        $this->requireAdminArea();
    }

    protected MessageModerationService $moderationService;

    public function __construct(MessageModerationService $moderationService, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->moderationService = $moderationService;
    }

    /**
     * لیست گزارش‌های پیام
     * @return void
     */
    public function reports(): void
    {
        $this->requireAuth();
        $this->requireAdminArea();
        if (!$this->policyService->authorizeById('messages.moderate', $this->requireAdminId())) {
            $this->session->setFlash('error', 'دسترسی غیرمجاز.');
            $this->response->redirect(url('admin/dashboard'));
            return;
        }

        $status = $this->request->input('status', 'pending');
        // FIX-X35: هم‌ترازی whitelist با گزینه‌های واقعی ویو/دامنه (pending→resolved|dismissed)
        if (!in_array($status, ['all', 'pending', 'resolved', 'dismissed'], true)) {
            $status = 'pending';
        }
        $page   = $this->request->int('page', 1);
        $limit  = 20;
        $offset = ($page - 1) * $limit;

        // Use service to get reports
        $result = $this->moderationService->getReports($status, $limit, $offset);
        $reports = $result['reports'] ?? [];
        $total = $result['total'] ?? 0;

        $this->view('admin/messages/reports', [
            'reports'      => $reports,
            'status'       => $status,
            'page'         => $page,
            'total'        => $total,
            'per_page'     => $limit,
            'total_pages'  => ceil($total / max(1, $limit)),
            // FIX-X34: اعداد واقعی KPI به‌جای مقادیر هاردکد ویو
            'status_counts' => $this->moderationService->getReportStatusCounts(),
        ]);
    }

    /**
     * نمایش جزئیات گزارش
     * @return void
     */
    public function show(): void
    {
        $this->requireAuth();
        $this->requireAdminArea();
        if (!$this->policyService->authorizeById('messages.moderate', $this->requireAdminId())) {
            $this->session->setFlash('error', 'دسترسی غیرمجاز.');
            $this->response->redirect(url('admin/dashboard'));
            return;
        }

        $id = $this->request->int('id');

        $report = $this->moderationService->getReportDetail($id);

        if (!$report) {
            // 🧭 FIX-X205 (راند ۵۵ — تعمیم کلاسِ باگ X202 به پنل ادمین): مرورگر → فلش + لیست گزارش‌ها؛ AJAX → JSON ۴۰۴
            if (!is_ajax()) {
                $this->session->setFlash('error', 'گزارش یافت نشد.');
                $this->response->redirect(url('/admin/messages/reports'));
                return;
            }
            $this->response->json(['error' => 'گزارش یافت نشد'], 404);
            return;
        }

        // 🛡️ HIGH-05: کنترل دقیق limit برای مشاهده تاریخچه پیام به منظور جلوگیری از نشت اطلاعات (حداکثر ۱۰ پیام)
        $limit = min(max($this->request->int('limit', 5), 5), 10);
        $user_messages = $this->moderationService->getReportedMessageThread(
            int_value($report['sender_id']),
            int_value($report['recipient_id']),
            $limit,
            // 🛡️ FIX-CH30: پیامِ گزارشِ انتخاب‌شده مبنای پنجرهٔ context است؛
            // قبلاً service جدیدترین گزارشِ مکالمه را انتخاب می‌کرد و ادمین
            // ممکن بود context گزارش دیگری را ببیند.
            int_value($report['message_id'] ?? 0)
        );

        $this->view('admin/messages/report-detail', [
            'report'          => $report,
            'user_messages'   => $user_messages
        ]);
    }

    /**
     * تایید گزارش و اقدام
     * @return void
     */
    public function approve(): void
    {
        $this->requireAuth();
        $this->requireAdminArea();
        if (!$this->policyService->authorizeById('messages.moderate', $this->requireAdminId())) {
            $this->response->json(['error' => 'دسترسی غیرمجاز برای تعدیل پیام‌ها.'], 403);
            return;
        }

        // CORE-036: CSRF Protection
        $this->validateCsrf();

        if (!$this->request->isPost()) {
            $this->response->json(['error' => 'Method not allowed'], 405);
            return;
        }

        $id     = $this->request->int('report_id');
        
        // 🛡️ CRITICAL-08: Validate existence of the report before proceeding
        if ($id <= 0 || !$this->moderationService->getReportDetail($id)) {
            $this->response->json(['error' => 'گزارش یافت نشد'], 404);
            return;
        }

        $action = $this->request->input('action', 'warn');

        $allowedActions = ['warn', 'delete', 'ban'];
        if (!in_array($action, $allowedActions, true)) {
            $this->response->json(['error' => 'اقدام نامعتبر است'], 422);
            return;
        }

        $result = $this->moderationService->approveReport($id, $action, $this->requireAdminId());

        if ($result['success']) {
            $this->auditLog('message_report_approved', 'message_report', $id, null, [
                'action' => $action
            ]);
            // FIX-R15B (Low-28): فرم معمولی HTML در report-detail بدون fetch ارسال می‌شد و
            // مرورگر یک بدنهٔ JSON خام می‌دید (الگوی FIX-X205: مرورگر → فلش+ریدایرکت؛ AJAX → JSON).
            if (!is_ajax()) {
                $this->session->setFlash('success', $result['message']);
                $this->response->redirect(url('/admin/messages/reports/' . $id));
                return;
            }
            $this->response->json(['success' => true, 'message' => $result['message']]);
        } else {
            if (!is_ajax()) {
                $this->session->setFlash('error', $result['message']);
                $this->response->redirect(url('/admin/messages/reports/' . $id));
                return;
            }
            $this->response->json(['error' => $result['message']], 500);
        }
    }

    /**
     * رد کردن گزارش
     * @return void
     */
    public function dismiss(): void
    {
        $this->requireAuth();
        $this->requireAdminArea();
        if (!$this->policyService->authorizeById('messages.moderate', $this->requireAdminId())) {
            $this->response->json(['error' => 'دسترسی غیرمجاز برای تعدیل پیام‌ها.'], 403);
            return;
        }

        // CORE-036: CSRF Protection
        $this->validateCsrf();

        if (!$this->request->isPost()) {
            $this->response->json(['error' => 'Method not allowed'], 405);
            return;
        }

        $id = $this->request->int('report_id');
        
        // 🛡️ CRITICAL-08: Validate existence of the report before proceeding
        if ($id <= 0 || !$this->moderationService->getReportDetail($id)) {
            $this->response->json(['error' => 'گزارش یافت نشد'], 404);
            return;
        }

        $ok = $this->moderationService->dismissReport($id, $this->requireAdminId());

        if ($ok) {
            $this->auditLog('message_report_dismissed', 'message_report', $id, ['status' => 'pending'], ['status' => 'dismissed']);
            // 🛡️ MEDIUM-07: Log success inside the success condition
            $this->logger->info('Message report dismissed', [
                'report_id' => $id,
                'admin_id' => $this->requireAdminId()
            ]);
        }

        // FIX-R15B (Low-28): مرورگر (فرم HTML) → فلش + بازگشت به جزئیات گزارش؛ AJAX → JSON
        if (!is_ajax()) {
            $this->session->setFlash($ok ? 'success' : 'error', $ok ? 'گزارش رد شد' : 'خطا در رد گزارش');
            $this->response->redirect(url('/admin/messages/reports/' . $id));
            return;
        }
        $this->response->json(['success' => $ok, 'message' => $ok ? 'گزارش رد شد' : 'خطا در رد گزارش']);
    }


    /**
     * لیست کاربران مسدود
     * @return void
     */
    public function blockedUsers(): void
    {
        $this->requireAuth();
        $this->requireAdminArea();
        if (!$this->policyService->authorizeById('messages.moderate', $this->requireAdminId())) {
            $this->session->setFlash('error', 'دسترسی غیرمجاز.');
            $this->response->redirect(url('admin/dashboard'));
            return;
        }

        $page   = $this->request->int('page', 1);
        $limit  = 20;
        $offset = ($page - 1) * $limit;

        $blocked = $this->moderationService->getBlockedUsers($limit, $offset);
        $total = $this->moderationService->getBlockedUsersCount();

        $this->view('admin/messages/blocked-users', [
            'blocked'      => $blocked,
            'page'         => $page,
            'total'        => $total,
            'per_page'     => $limit,
            'total_pages'  => ceil($total / max(1, $limit))
        ]);
    }

    /**
     * آمار پیام‌های سیستم
     * @return void
     */
    public function stats(): void
    {
        $this->requireAuth();
        $this->requireAdminArea();
        if (!$this->policyService->authorizeById('messages.moderate', $this->requireAdminId())) {
            $this->session->setFlash('error', 'دسترسی غیرمجاز.');
            $this->response->redirect(url('admin/dashboard'));
            return;
        }

        $result = $this->moderationService->getStats();
        $stats = $result['stats'] ?? [];
        $top_reporters = $result['top_reporters'] ?? [];

        $this->view('admin/messages/stats', [
            'stats'        => $stats,
            'top_reporters' => $top_reporters
        ]);
    }
}
