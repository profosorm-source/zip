<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\Analytics\AnalyticsService;
use Core\Logger;

/**
 * AdminAnalyticsController
 * داشبورد تحلیلات برای مدیران
 */
class AdminAnalyticsController extends BaseAdminController
{
    private AnalyticsService $analyticsService;
    // $logger inherited from parent

    public function __construct(AnalyticsService $analyticsService, Logger $logger) {
        parent::__construct(null, null, null, null, $logger);
        $this->analyticsService = $analyticsService;
        $this->logger          = $logger;
    }

    /**
     * Dashboard اصلی - نمای کلی سیستم
     */
    public function dashboard(): void
    {
        try {
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';

            $data = $this->analyticsService->getComprehensiveDashboard($period);

            view('admin.analytics.dashboard', [
                'title'  => 'داشبورد تحلیلات',
                'period' => $period,
                'data'   => $data,
            ]);

        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.dashboard.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بارگذاری داشبورد');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * تحلیلات کاربران
     */
    public function users(): void
    {
        try {
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';
            
            $userMetrics = $this->analyticsService->getUserMetrics($period);
            $growthChart = $this->analyticsService->getUserGrowthChart(30);

            view('admin.analytics.users', [
                'title'       => 'تحلیلات کاربران',
                'period'      => $period,
                'metrics'     => $userMetrics,
                'growth_data' => json_encode($growthChart),
            ]);

        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.users.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بارگذاری تحلیلات');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * تحلیلات تراکنش‌ها
     */
    public function transactions(): void
    {
        try {
            // FIX-M12-13 (گزارش ماژول ۱۲): period whitelist + propagate واقعی —
            // metrics دوره‌ای + نمودار با بازهٔ دوره + برچسب صحیح heading.
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';
            $chartDays = match ($period) {
                'day' => 1,
                'week' => 7,
                'year' => 365,
                default => 30,
            };
            $periodLabels = ['day' => 'امروز', 'week' => '۷ روز گذشته', 'month' => '۳۰ روز گذشته', 'year' => '۳۶۵ روز گذشته'];

            $transactionMetrics = $this->analyticsService->getPeriodTransactionMetrics($period);
            $volumeChart = $this->analyticsService->getNormalizedTransactionVolumeChart($chartDays);

            view('admin.analytics.transactions', [
                'title'        => 'تحلیلات تراکنش‌ها',
                'period'       => $period,
                'chartDays'    => $chartDays,
                'chartLabel'   => $periodLabels[$period], // FIX-PSTAN: period اعتبارسنجی‌شده است؛ ?? مرده بود
                'metrics'      => $transactionMetrics,
                'volume_data'  => json_encode($volumeChart),
            ]);

        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.transactions.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بارگذاری تحلیلات');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * تحلیلات وظایف اجتماعی
     */
    public function socialTasks(): void
    {
        try {
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';
            
            $socialMetrics = $this->analyticsService->getSocialTaskMetrics($period);

            view('admin.analytics.social-tasks', [
                'title'   => 'تحلیلات وظایف اجتماعی',
                'period'  => $period,
                'metrics' => $socialMetrics,
            ]);

        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.social_tasks.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بارگذاری تحلیلات');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * تحلیلات وظایف سفارشی
     */
    public function customTasks(): void
    {
        try {
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';
            
            $customMetrics = $this->analyticsService->getCustomTaskMetrics($period);

            view('admin.analytics.custom-tasks', [
                'title'   => 'تحلیلات وظایف سفارشی',
                'period'  => $period,
                'metrics' => $customMetrics,
            ]);

        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.custom_tasks.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بارگذاری تحلیلات');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * تحلیلات امتیازات و نظرات
     */
    public function ratings(): void
    {
        try {
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';
            
            $ratingMetrics = $this->analyticsService->getRatingMetrics($period);

            view('admin.analytics.ratings', [
                'title'   => 'تحلیلات امتیازات',
                'period'  => $period,
                'metrics' => $ratingMetrics,
            ]);

        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.ratings.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بارگذاری تحلیلات');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * تحلیلات درآمد
     */
    public function revenue(): void
    {
        try {
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';
            
            $revenueData = $this->analyticsService->getRevenueBreakdown($period);

            view('admin.analytics.revenue', [
                'title'   => 'تحلیلات درآمد',
                'period'  => $period,
                'metrics' => $revenueData,
                'data'    => $revenueData,
            ]);

        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.revenue.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بارگذاری تحلیلات');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * سلامت سیستم
     */
    public function systemHealth(): void
    {
        try {
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';
            $health = $this->analyticsService->getSystemHealth();

            view('admin.analytics.system-health', [
                'title'   => 'سلامت سیستم',
                'period'  => $period,
                'metrics' => $health,
            ]);

        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.system_health.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بارگذاری اطلاعات');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * API برای بارگذاری داده‌های نمودار
     */
    public function getChartData(): void
    {
        // 🧭 FIX-X205 (راند ۵۵ — تعمیم کلاسِ باگ X202 به پنل ادمین): مرورگر → داشبورد آنالیتیکس؛ AJAX → JSON
        if (!is_ajax()) {
            redirect(url('/admin/analytics'));
        }

        try {
            $type   = $this->request->get('type');
            $period = $this->request->str('period', 'month');
            // 🧹 FIX-COSMET-20 (A3-N11/کم): whitelist کنترلری period — هم‌الگوی
            // dashboard():33 و transactions():86 (مدل خودش هم sanitize می‌کند ولی
            // قرارداد لایهٔ کنترلر یکسان نبود).
            $period = in_array($period, ['day', 'week', 'month', 'year'], true) ? $period : 'month';
            // FIX-M12-13: بازهٔ نمودار از دورهٔ انتخابی می‌آید (سقف ۳۶۵ روز)
            $days = match ($period) {
                'day' => 1,
                'week' => 7,
                'year' => 365,
                default => 30,
            };

            // Validate chart type
            $allowedTypes = ['user_growth', 'transactions'];
            if (!$type || !in_array($type, $allowedTypes, true)) {
                $this->response->json([
                    'success' => false,
                    'error'   => 'نوع نمودار نامعتبر است',
                    'allowed' => $allowedTypes
                ], 400);
                return;
            }

            // FIX-M12-12: خروجی transactions به شکل کانونی [{date,deposits,withdrawals}]
            // نرمال می‌شود تا قرارداد JS و API یکسان باشد.
            $data = match($type) {
                'user_growth'      => $this->analyticsService->getUserGrowthChart($days),
                'transactions'     => $this->analyticsService->getNormalizedTransactionVolumeChart($days),
            };

            $this->response->json(['success' => true, 'data' => $data]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) /* 🧹 FIX-COSMET-20 (A3-N11/کم): Throwable به‌جای Exception — خطاهای TypeError/Error هم مهار و flash می‌شوند */ {
            $this->logger->error('analytics.chart_data.failed', ['error' => $e->getMessage()]);
            $this->response->json(['success' => false, 'error' => 'خطا در بارگذاری داده'], 500);
        }
    }

    /**
     * صادر کردن گزارش
     */
    public function exportReport(): void
    {
        $format = $this->request->post('format') ?? 'pdf';
        $period = str_value($this->request->post('period') ?? 'month');

        // FIX-R36-W3 (F-A15-13): period دیگر نادیده گرفته نمی‌شود — سفارش قبلی
        // generate*/بدون آرگومان صدا می‌شد و prepareReportData همیشه آمار ماهِ
        // پیش‌فرض می‌ساخت؛ ادمین period انتخابی را در خروجی نمی‌دید. حالا دادهٔ
        // گزارش با همان period (whitelist هم‌عرض UI داشبورد: day/week/month/year)
        // ساخته و به generate* پاس می‌شود. قرارداد getUserMetrics: day/week صریح،
        // بقیه = معناشناسی ماه (لایهٔ سرویس خودش map می‌کند).
        if (!in_array($period, ['day', 'week', 'month', 'year'], true)) {
            $period = 'month';
        }
        $periodData = [
            'users'        => $this->analyticsService->getUserMetrics($period),
            'transactions' => $this->analyticsService->getTransactionMetrics(),
            'tasks'        => $this->analyticsService->getTaskMetrics(),
        ];

        // Generate report based on format
        // در صورت شکست، Exception به GlobalExceptionMiddleware می‌رسد و
        // پاسخ استاندارد JSON/HTML خطا را تولید می‌کند (بدون نشت پیام خام).
        match($format) {
            'csv'   => $this->analyticsService->generateCSV($periodData),
            'excel' => $this->analyticsService->generateExcel($periodData),
            'pdf'   => $this->analyticsService->generatePDF($periodData),
            default => throw new \InvalidArgumentException('فرمت نامعتبر'),
        };

        $this->logger->info('analytics.report_exported', [
            'format' => $format,
            'period' => $period,
            'admin_id' => (int) (int)$this->userId(),
        ]);
    }
}
