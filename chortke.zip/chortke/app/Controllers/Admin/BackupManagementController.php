<?php

namespace App\Controllers\Admin;

use App\Services\BackupService;
use App\Services\OffsiteBackupService;
use App\Contracts\LoggerInterface;

/**
 * Controller: BackupManagementController
 * مدیریت پشتیبان‌گیری و بازیابی دیتابیس (رمزنگاری‌شده با BackupService)
 */
class BackupManagementController extends BaseAdminController
{
    private BackupService $backupService;

    /** [FIX-R91-B] سرویس آپلود آف‌سایت — تزریق اختیاری (الگوی خانه r88/r90) تا ساخت‌های دستی نشکنند */
    private ?OffsiteBackupService $offsiteService;

    public function __construct(BackupService $backupService, LoggerInterface $logger, ?OffsiteBackupService $offsiteService = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->backupService = $backupService;
        $this->offsiteService = $offsiteService;
    }

    /**
     * نمایش لیست پشتیبان‌ها
     */
    public function index(): string
    {
        try {
            // [X382 راند ۱۰۲] فیلتر وضعیت از GET — لیست سفید (completed|failed)؛ ورودی دیگر = همه
            $statusRaw = trim((string)$this->request->str('status', ''));
            $statusFilter = in_array($statusRaw, ['completed', 'failed'], true) ? $statusRaw : null;

            $backups = $this->backupService->getBackups(50, 0, $statusFilter); 
            $stats = $this->backupService->getBackupStats();

            return (string)view('admin/backups/index', [
                'backups' => $backups['backups'] ?? [],
                'stats' => $stats,
                'success' => $backups['success'] ?? false,
                'statusFilter' => $statusFilter,
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backups.index.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: دریافت لیست پشتیبان‌ها ناموفق بود');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * ایجاد پشتیبان جدید
     */
    public function createBackup(): void
    {
        try {
            $description = $this->request->str('description') !== '' ? $this->request->str('description') : null;

            $result = $this->backupService->createBackup($description);

            if (($result['success'] ?? false) === true) {
                $filename = is_string($result['filename'] ?? null) ? $result['filename'] : 'unknown';
                $this->logger->info('admin.backup.created', [
                    'filename' => $filename,
                    'size' => $result['size'] ?? null
                ]);
                $this->session->setFlash('success', "پشتیبان رمزنگاری‌شده با موفقیت ایجاد شد: {$filename}");
            } else {
                $error = is_string($result['error'] ?? null) ? $result['error'] : 'خطای نامشخص';
                $this->session->setFlash('error', "خطا: {$error}");
            }

            redirect(url('/admin/backups'));

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.create.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: ایجاد پشتیبان ناموفق بود');
            redirect(url('/admin/backups'));
        }
    }

    /**
     * بازیابی از پشتیبان (محدود به ادمین‌های ارشد فقط)
     *
     * [FIX-R89-DR] بازیابی انتخابی با پایگاه دادهٔ مقصد (تمرین DR):
     *   - target_db (اختیاری): خالی = پایگاه دادهٔ زندهٔ فعلی (رفتار امروز).
     *   - confirm_name (اجباری): باید دقیقاً برابر «مقصد حل‌شده» (target_db یا نام زنده) باشد —
     *     تأیید سمت-سرورِ دوبل برای عملیات مخرب‌ترین ادمین؛ عدم تطابق → بازگشت با خطای فارسی.
     */
    public function restoreBackup(): void
    {
        $this->requirePermission('super_admin');
        try {
            // [FIX-R89-DR] شناسه از پارامتر مسیر {id} می‌آید؛ فیلد backup_id برای سازگاری رو به عقب
            $backupId = $this->request->param('id') ?? $this->request->post('backup_id');

            if (!$backupId) {
                $this->session->setFlash('error', 'شناسه پشتیبان الزامی است');
                redirect(url('/admin/backups'));
            }

            $backup = $this->backupService->getBackupById(int_value($backupId));
            $filename = is_array($backup) ? ($backup['file_path'] ?? '') : '';
            if (!is_string($filename) || $filename === '') {
                $this->session->setFlash('error', 'پشتیبان یافت نشد');
                redirect(url('/admin/backups'));
            }

            // [FIX-R89-DR] ورودی‌های مقصد بازیابی — trim و حالت خالی = زنده
            $targetInput = trim($this->request->str('target_db'));
            $confirmName = trim($this->request->str('confirm_name'));

            // مقصدِ حل‌شده برای مقایسهٔ تأیید: target_db وارد شده یا نام پایگاه دادهٔ زندهٔ فعلی
            $dbConf = config('database');
            $liveName = is_array($dbConf) && is_string($dbConf['name'] ?? null) ? $dbConf['name'] : '';
            $resolvedTarget = $targetInput !== '' ? $targetInput : $liveName;

            if ($confirmName === '' || $confirmName !== $resolvedTarget) {
                // تأییدِ ناهم‌خوان → هیچ بازیابی‌ای اجرا نمی‌شود (سرور-ساید، بدون JS)
                $this->logger->warning('admin.backup.restore.confirm_mismatch', [
                    'backup_id' => $backupId,
                    'expected' => $resolvedTarget,
                ]);
                $this->session->setFlash(
                    'error',
                    "تأیید بازیابی ناقص است: مقدار فیلد تأیید باید دقیقاً «{$resolvedTarget}» باشد."
                );
                redirect(url('/admin/backups'));
            }

            $result = $this->backupService->restoreBackup($filename, false, $targetInput !== '' ? $targetInput : null);

            if (($result['success'] ?? false) === true) {
                $this->logger->info('admin.backup.restore.success', [
                    'backup_id' => $backupId,
                    'target_db' => $result['target_db'] ?? $liveName, // [FIX-R89-DR]
                ]);
                // [FIX-R89-DR] پیام موفقیت مقصد را نام می‌برد تا ابهامی بین تمرین DR و بازیابی واقعی نماند
                $targetEcho = is_string($result['target_db'] ?? null) ? $result['target_db'] : $liveName;
                $this->session->setFlash(
                    'success',
                    $targetInput !== ''
                        ? "بازیابی در پایگاه دادهٔ مقصد «{$targetEcho}» با موفقیت انجام شد."
                        : 'بازیابی پشتیبان رمزنگاری‌شده با موفقیت انجام شد'
                );
            } else {
                $this->logger->error('admin.backup.restore.failed', [
                    'backup_id' => $backupId,
                    'error' => $result['error'] ?? 'خطای نامشخص'
                ]);
                $this->session->setFlash('error', 'خطا در بازیابی: ' . ($result['error'] ?? 'خطای نامشخص'));
            }

            redirect(url('/admin/backups'));

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.restore.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: بازیابی ناموفق بود');
            redirect(url('/admin/backups'));
        }
    }

    /**
     * بررسی صحت (Verify) فایل پشتیبان
     */
    public function verifyBackup(): void
    {
        try {
            // [X382 راند ۱۰۲] شناسه از پارامتر مسیر {id} می‌آید (هم‌تراز الگوی FIX-R89-DR
            // بازیابی)؛ فیلد backup_id برای سازگاری رو به عقب — قبلاً روت {id}/verify
            // وجود داشت ولی کنترلر فقط backup_id می‌خواند (سیم‌کشی ناقص).
            $backupId = $this->request->param('id') ?? $this->request->post('backup_id');

            if (!$backupId) {
                $this->session->setFlash('error', 'شناسه پشتیبان الزامی است');
                redirect(url('/admin/backups'));
            }

            $backup = $this->backupService->getBackupById(int_value($backupId));
            $filename = is_array($backup) ? ($backup['file_path'] ?? '') : '';
            if (!is_string($filename) || $filename === '') {
                $this->session->setFlash('error', 'پشتیبان یافت نشد');
                redirect(url('/admin/backups'));
            }

            $checksum = $backup['checksum'] ?? null;
            if (is_string($checksum) && $this->backupService->verifyStoredBackup($filename, $checksum)) {
                $this->logger->info('admin.backup.verify.success', ['backup_id' => $backupId]);
                $this->session->setFlash('success', 'چک‌سام SHA-256 و ساختار رمزنگاری فایل پشتیبان با موفقیت تایید شد.');
            } else {
                $this->session->setFlash('error', 'خطا: فایل پشتیبان یافت نشد یا چک‌سام آن معتبر نیست.');
            }

            redirect(url('/admin/backups'));

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.verify.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بررسی صحت پشتیبان');
            redirect(url('/admin/backups'));
        }
    }

    /**
     * نمایش آمار پشتیبان‌ها
     */
    public function stats(): string
    {
        try {
            $stats = $this->backupService->getBackupStats();

            return (string) view('admin/backups/stats', ['stats' => $stats]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backups.stats.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: دریافت آمار ناموفق بود');
            redirect(url('/admin/dashboard'));
        }
    }

    /**
     * [FIX-R91-B] همگام‌سازی دستی آپلود آف‌سایت (همان مسیر جاروب شبانه با limit=10)
     */
    public function offsiteSync(): void
    {
        $this->requirePermission('backups.manage');
        try {
            if ($this->offsiteService === null) {
                $this->session->setFlash('error', 'سرویس آپلود آف‌سایت در دسترس نیست');
                redirect(url('/admin/backups'));
            }
            $result = $this->offsiteService->syncPending(10);

            if (($result['skipped'] ?? null) === 'disabled') {
                $this->session->setFlash('error', 'آپلود آف‌سایت غیرفعال است — ابتدا از تب «بکاپ آف‌سایت» پنل تنظیمات فعالش کنید.');
            } elseif (($result['success'] ?? false) === true) {
                $pushed = int_value($result['pushed'] ?? 0);
                $failed = int_value($result['failed'] ?? 0);
                $this->logger->info('admin.backup.offsite_sync', ['pushed' => $pushed, 'failed' => $failed]);
                $this->session->setFlash(
                    'success',
                    "همگام‌سازی آف‌سایت انجام شد: {$pushed} آپلود موفق، {$failed} ناموفق."
                );
            } else {
                $error = is_string($result['error'] ?? null) ? $result['error'] : 'خطای نامشخص';
                $this->session->setFlash('error', "خطا در همگام‌سازی آف‌سایت: {$error}");
            }

            redirect(url('/admin/backups'));

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.offsite_sync.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: همگام‌سازی آف‌سایت ناموفق بود');
            redirect(url('/admin/backups'));
        }
    }

    /**
     * [FIX-R91-B] تست اتصال به مقصد آف‌سایت (پروب کوچک PUT/DELETE یا آپلود/حذف FTP)
     */
    public function offsiteTest(): void
    {
        $this->requirePermission('backups.manage');
        try {
            if ($this->offsiteService === null) {
                $this->session->setFlash('error', 'سرویس آپلود آف‌سایت در دسترس نیست');
                redirect(url('/admin/backups'));
            }
            $result = $this->offsiteService->testConnection();

            $message = is_string($result['message'] ?? null) ? $result['message'] : 'نتیجهٔ نامشخص';
            if (($result['success'] ?? false) === true) {
                $this->logger->info('admin.backup.offsite_test', ['ok' => true]);
                $this->session->setFlash('success', $message);
            } else {
                $this->logger->warning('admin.backup.offsite_test', ['ok' => false]);
                $this->session->setFlash('error', $message);
            }

            redirect(url('/admin/backups'));

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.offsite_test.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: تست اتصال آف‌سایت ناموفق بود');
            redirect(url('/admin/backups'));
        }
    }

    /**
     * پاک‌سازی پشتیبان‌های قدیمی
     */
    public function cleanup(): void
    {
        try {
            $daysToKeep = $this->request->int('days_to_keep', 30);
            if ($daysToKeep < 1 || $daysToKeep > 3650) {
                $daysToKeep = 30;
            }

            $result = $this->backupService->cleanupOldBackups($daysToKeep);

            if (($result['success'] ?? false) === true) {
                $deleted = int_value($result['deleted'] ?? 0);
                $this->logger->info('admin.backup.cleanup', [
                    'deleted' => $deleted,
                    'days_to_keep' => $daysToKeep
                ]);
                $this->session->setFlash('success', "پاک‌سازی انجام شد: {$deleted} پشتیبان حذف شد");
            } else {
                $error = is_string($result['error'] ?? null) ? $result['error'] : 'خطای نامشخص';
                $this->session->setFlash('error', "خطا: {$error}");
            }

            redirect(url('/admin/backups'));

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.cleanup.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: پاک‌سازی ناموفق بود');
            redirect(url('/admin/backups'));
        }
    }
}
