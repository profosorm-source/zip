<?php

namespace App\Controllers\Admin;

use App\Services\DatabaseService;
use Core\Logger;

/**
 * Controller: BackupManagementController
 * مدیریت پشتیبان‌گیری و بازیابی دیتابیس
 */
class BackupManagementController extends BaseAdminController
{
    private DatabaseService $databaseService;
    // $logger inherited from parent

    public function __construct(DatabaseService $databaseService, Logger $logger) {
        parent::__construct(null, null, null, null, $logger);
        $this->databaseService = $databaseService;
        $this->logger = $logger;
    }

    /**
     * نمایش لیست پشتیبان‌ها
     */
    public function index()
    {
        try {
            $backups = $this->databaseService->getBackups(50, 0); 
            $stats = $this->databaseService->getBackupStats();

            return view('admin/backups/index', [
                'backups' => $backups['backups'] ?? [],
                'stats' => $stats,
                'success' => $backups['success'] ?? false
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backups.index.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: دریافت لیست پشتیبان‌ها ناموفق بود');
            redirect('/admin/dashboard');
        }
    }

    /**
     * ایجاد پشتیبان جدید
     */
    public function createBackup(): void
    {
        try {
            $description = $this->request->str('description') !== '' ? $this->request->str('description') : null;

            $result = $this->databaseService->createBackup($description);

            if ($result['success']) {
                $this->logger->info('admin.backup.created', [
                    'filename' => $result['filename'],
                    'size' => $result['size']
                ]);
                $this->session->setFlash('success', "پشتیبان با موفقیت ایجاد شد: {$result['filename']}");
            } else {
                $this->session->setFlash('error', "خطا: {$result['error']}");
            }

            redirect('/admin/backups');

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.create.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: ایجاد پشتیبان ناموفق بود');
            redirect('/admin/backups');
        }
    }

    /**
     * بازیابی از پشتیبان (محدود به ادمین‌های ارشد فقط)
     */
    public function restoreBackup(): void
    {
        $this->requirePermission('super_admin');
        try {
            $backupId = $this->request->post('backup_id');

            if (!$backupId) {
                $this->session->setFlash('error', 'شناسه پشتیبان الزامی است');
                redirect('/admin/backups');
                return;
            }

            $backup = $this->databaseService->getBackupById(int_value($backupId));
            if (!$backup || empty($backup['filename'])) {
                $this->session->setFlash('error', 'پشتیبان یافت نشد');
                redirect('/admin/backups');
                return;
            }

            $result = $this->databaseService->restoreBackup($backup['filename']);

            if ($result['success']) {
                $this->logger->info('admin.backup.restore.success', ['backup_id' => $backupId]);
                $this->session->setFlash('success', 'بازیابی پشتیبان با موفقیت انجام شد');
            } else {
                $this->logger->error('admin.backup.restore.failed', [
                    'backup_id' => $backupId,
                    'error' => $result['error']
                ]);
                $this->session->setFlash('error', 'خطا در بازیابی: ' . $result['error']);
            }

            redirect('/admin/backups');

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.restore.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: بازیابی ناموفق بود');
            redirect('/admin/backups');
        }
    }

    /**
     * بررسی صحت (Verify) فایل پشتیبان
     */
    public function verifyBackup(): void
    {
        try {
            $backupId = $this->request->post('backup_id');

            if (!$backupId) {
                $this->session->setFlash('error', 'شناسه پشتیبان الزامی است');
                redirect('/admin/backups');
                return;
            }

            $backup = $this->databaseService->getBackupById(int_value($backupId));
            if (!$backup || empty($backup['filename'])) {
                $this->session->setFlash('error', 'پشتیبان یافت نشد');
                redirect('/admin/backups');
                return;
            }

            $result = $this->databaseService->verifyBackupIntegrity($backup['filename']);

            if ($result['success']) {
                $this->logger->info('admin.backup.verify.success', ['backup_id' => $backupId]);
                $this->session->setFlash('success', $result['message']);
            } else {
                $this->logger->warning('admin.backup.verify.failed', [
                    'backup_id' => $backupId,
                    'error' => $result['error']
                ]);
                $this->session->setFlash('error', 'خطا: ' . $result['error']);
            }

            redirect('/admin/backups');

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.verify.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا در بررسی صحت پشتیبان');
            redirect('/admin/backups');
        }
    }

    /**
     * نمایش آمار پشتیبان‌ها
     */
    public function stats(): string
    {
        try {
            $stats = $this->databaseService->getBackupStats();

            return (string) view('admin/backups/stats', ['stats' => $stats]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backups.stats.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: دریافت آمار ناموفق بود');
            redirect('/admin/dashboard');
            return '';
        }
    }

    /**
     * پاک‌سازی پشتیبان‌های قدیمی
     */
    public function cleanup(): void
    {
        try {
            $daysToKeep = $this->request->int('days_to_keep', 30);
            if ($daysToKeep < 1 || $daysToKeep > 3650) {
                $daysToKeep = 30;
            }

            $result = $this->databaseService->cleanupOldBackups($daysToKeep);

            if ($result['success']) {
                $this->logger->info('admin.backup.cleanup', [
                    'deleted' => $result['deleted'],
                    'days_to_keep' => $daysToKeep
                ]);
                $this->session->setFlash('success', "پاک‌سازی انجام شد: {$result['deleted']} پشتیبان حذف شد");
            } else {
                $this->session->setFlash('error', "خطا: {$result['error']}");
            }

            redirect('/admin/backups');

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('admin.backup.cleanup.failed', ['error' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطا: پاک‌سازی ناموفق بود');
            redirect('/admin/backups');
        }
    }
}
