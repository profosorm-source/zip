<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Services\Settings\AppSettings;
use App\Services\Settings\SettingsCatalog;
use App\Services\Settings\SettingsManager;
use App\Services\UploadService;

class SystemSettingController extends BaseAdminController
{
    private AppSettings $appSettings;
    private SettingsManager $settingsManager;
    private UploadService $uploadService;
    
    public function __construct(
        AppSettings $appSettings,
        SettingsManager $settingsManager,
        UploadService $uploadService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->appSettings = $appSettings;
        $this->settingsManager = $settingsManager;
        $this->uploadService = $uploadService;
    }
    
    /**
     * FIX-X112: ریدایرکت /admin/captcha/settings → تب کپچا (مهاجرت از closure در
     * routes/missing.php). مجوز از default نقشه = admin.view_settings — هم‌راستا
     * با صفحهٔ مقصد (خودِ /admin/settings هم admin.view_settings می‌خواهد).
     */
    public function captchaSettings(): void
    {
        $this->response->redirect(url('/admin/settings?category=captcha'));
    }

    /**
     * نمایش تنظیمات
     */
    public function index(): void
    {
        $category = $this->request->str('category', 'general');
        $settings = $this->appSettings->getByCategory($category);

        // 🛡️ SETTINGS-CATALOG (X306): فهرست تب‌ها از SettingsCatalog می‌آید —
        // ۲۰ تب که «همهٔ» ماژول‌های پروژه را پوشش می‌دهد (عمومی/برند، بانکی،
        // رمزارز، کیف پول، تسک‌ها، اینفلوئنسر، ویترین، سرمایه‌گذاری،
        // زیرمجموعه، پیش‌بینی، تبلیغات، ویدیو جایزه‌دار، اعلان، سئو، امنیت،
        // ضدتقلب، کپچا، XP، تماس، تصاویر). seed خودکار کلیدهای هر تب در
        // AppSettings::getByCategory انجام می‌شود؛ دیگر تب خالی وجود ندارد.
        $categories = SettingsCatalog::categories();

        $this->view('admin/settings/index', [
            'settings' => $settings,
            'categories' => $categories,
            'currentCategory' => $category,
            'title' => 'تنظیمات سیستم'
        ]);
    }
    
    /**
     * بروزرسانی تنظیم
     */
    public function update(): void
    {
        $data = $this->request->body();
        $id    = int_value($data['id'] ?? 0);
        $key   = trim(str_value($data['key'] ?? ''));
        $value = str_value($data['value'] ?? '');

        if ($id <= 0 || $key === '') {
            $this->jsonError('درخواست نامعتبر است');
        }

        $oldSetting = $this->appSettings->find($id);
        $oldValue = $oldSetting->value ?? null;

        $ok = $this->settingsManager->updateById($id, $key, $value);

        if (!$ok) {
            $this->jsonError('تنظیمات یافت نشد یا کلید معتبر نیست');
        }

        // Log the change using robust Audit Trail
        $this->auditLog(
            'setting.updated',
            'setting',
            $id,
            ['key' => $key, 'value' => $oldValue],
            ['key' => $key, 'value' => $value]
        );

        $this->appSettings->clearCache();

        if (function_exists('settings')) {
            settings(true);
        }

        $this->jsonSuccess('تنظیمات ذخیره شد');
    }

    /**
     * آپلود تصویر برای تنظیمات
     */
    public function uploadImage(): void
    {
        if (!$this->request->hasFile('image')) {
            // 🛡️ X304: تشخیص دقیق خطای PHP-level آپلود — مثلاً وقتی فایل از
            // upload_max_filesize فایل‌پیکربندی بزرگ‌تر است (پیش‌فرض XAMPP: ۲M)،
            // قبلاً پیام کلی «فایلی آپلود نشده است» می‌آمد و ادمین نمی‌فهمد چرا.
            $raw = $_FILES['image'] ?? null;
            $err = is_array($raw) ? ($raw['error'] ?? null) : null;
            if (is_array($err)) { $err = $err[0] ?? null; } // ورودی ستونی
            $hint = match ((int)$err) {
                UPLOAD_ERR_INI_SIZE => 'حجم فایل از سقف upload_max_filesize فایل‌پیکربندی PHP بیشتر است (پیش‌فرض XAMPP: ۲ مگابایت — در php.ini افزایش دهید).',
                UPLOAD_ERR_FORM_SIZE => 'حجم فایل از سقف فرم بیشتر است.',
                UPLOAD_ERR_PARTIAL => 'فایل ناقص آپلود شد — اتصال قطع شد، دوباره تلاش کنید.',
                UPLOAD_ERR_NO_FILE => 'فایلی انتخاب نشده بود.',
                UPLOAD_ERR_NO_TMP_DIR => 'پوشهٔ موقت PHP موجود نیست — XAMPP را بررسی کنید.',
                UPLOAD_ERR_CANT_WRITE => 'PHP اجازهٔ نوشتن روی دیسک را ندارد — دسترسی پوشهٔ tmp را بررسی کنید.',
                UPLOAD_ERR_EXTENSION => 'یک افزونهٔ PHP آپلود را متوقف کرد.',
                default => null,
            };
            $this->jsonError($hint !== null
                ? 'آپلود ناموفق: ' . $hint
                : 'فایلی آپلود نشده است');
        }
        
        $settingId = $this->request->int('setting_id');
        $setting = $this->appSettings->find($settingId);
        
        if (!$setting || (($setting->group ?? '') !== 'images' && $setting->type !== 'image')) {
            $this->jsonError('تنظیم یافت نشد یا نوع آن تصویر نیست', [], 404);
        }
        
        $file = $this->request->file('image');
        if (!is_array($file)) {
            $this->jsonError('ساختار فایل آپلودشده نامعتبر است', [], 422);
            return;
        }

        $oldImagePath = isset($setting->value) && is_string($setting->value)
            ? $setting->value
            : null;
        $newImagePath = null;
        $settingUpdated = false;

        try {
            // UploadService آرگومان سوم را به‌صورت list<MIME> و محدودیت حجم را
            // در آرگومان چهارم دریافت می‌کند. SVG و ICO عمداً توسط سرویس امن
            // تصاویر پشتیبانی نمی‌شوند.
            $result = $this->uploadService->upload(
                $file,
                'site-images',
                ['image/jpeg', 'image/png', 'image/gif'],
                2 * 1024 * 1024
            );

            // 🛡️ X169d: برای پوشه‌های عمومی url = «uploads/site-images/...» است که
            // با url() در ویوها به مسیر استاتیک سرو‌شده می‌رسد؛ path خام («site-images/...»)
            // فقط برای ریشهٔ خصوصی معنا دارد و در سایت ۴۰۴ می‌داد.
            $newImagePath = (is_string($result['url'] ?? null) && $result['url'] !== '')
                ? $result['url']
                : $result['path'];

            // ابتدا reference دیتابیس به فایل جدید به‌روزرسانی می‌شود. فایل قبلی
            // فقط بعد از موفقیت update حذف می‌گردد تا شکست upload باعث data loss نشود.
            $updated = $this->settingsManager->updateValueById($settingId, $newImagePath);
            if (!$updated) {
                throw new \Core\Exceptions\ApplicationException('خطا در ذخیره اطلاعات در دیتابیس');
            }
            $settingUpdated = true;

            // 🛡️ X175: بعد از تعویض لوگوی اصلی، مشتقات (شفاف/آیکون/فاوآیکون/
            // اپل‌تاچ) از روی فایل خام جدید بازتولید می‌شوند تا ناوبار، سایدبارها
            // و فوتر — که «نشان مربعی» را نشان می‌دهند — هم‌زمان به‌روز بمانند.
            if (($setting->key ?? '') === 'site_logo') {
                $this->deriveLogoSet(public_path($newImagePath));
            }

            if ($oldImagePath !== null && $oldImagePath !== '' && $oldImagePath !== $newImagePath) {
                $this->uploadService->delete($oldImagePath);
            }

            // Log the change using robust Audit Trail
            $this->auditLog(
                'setting.image_uploaded',
                'setting',
                $settingId,
                ['key' => $setting->key ?? null, 'value' => $oldImagePath],
                ['key' => $setting->key ?? null, 'value' => $newImagePath]
            );

            $this->appSettings->clearCache();

            // 🛡️ X304: کش‌باست پیش‌نمایش — بدون ؟v= مرورگر نسخهٔ کش‌شدهٔ قبلی
            // هم‌نام فایل را نشان می‌داد و به‌نظر می‌رسید آپلود/تعویض اعمال نشده.
            $absPath = public_path($newImagePath);
            $bustedUrl = url($newImagePath) . (is_file($absPath) ? '?v=' . filemtime($absPath) : '');

            $this->jsonSuccess('تصویر با موفقیت آپلود شد', [
                'url' => $bustedUrl,
                'path' => $newImagePath,
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            // 🛡️ X169c: jsonSuccess/jsonError از همین try پاسخ JSON چارچوب را با
            // HttpResponseException (کنترل جریان H10) صادر می‌کنند؛ این استثنا
            // «خطا» نیست و باید به روتر برسد وگرنه آپلودِ موفق به ۵۰۰ دروغین
            // تبدیل می‌شود (همان درس X163: catch فقط برای خرابی واقعی).
            throw $e;
        } catch (\Throwable $e) {
            // اگر upload موفق ولی update دیتابیس ناموفق بود، فایل orphan جدید پاک شود.
            if (!$settingUpdated && $newImagePath !== null) {
                $this->uploadService->delete($newImagePath);
            }
            $this->logger->error('admin.settings.upload_failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا در آپلود تصویر: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * حذف تصویر
     */
    public function removeImage(): void
    {
        $data = $this->request->body();
        $settingId = int_value($data['setting_id'] ?? 0);
        
        $setting = $this->appSettings->find($settingId);
        if (!$setting) {
            $this->jsonError('تنظیم یافت نشد', [], 404);
        }
        
        try {
            $storedImagePath = $setting->value ?? null;
            if (is_string($storedImagePath) && $storedImagePath !== '') {
                // 🛡️ X304: فقط فایل‌های «آپلودی واقعی» (زیر uploads/) حذف فیزیکی
                // می‌شوند. مسیرهای پیش‌فرض برند (assets/images/logo.png و مشابه)
                // دارایی‌های اصلی پروژه‌اند؛ قبلاً delete() آنها را از publicRoot
                // unlink می‌کرد و فایل پیش‌فرض برند برای همیشه نابود می‌شد —
                // بعدش هر کاربر تازه‌نصبی که لوگو را حذف می‌کرد، برند سایت را
                // از دست می‌داد. حذفِ مقدار از DB به‌تنهایی کافی است (بازگشت
                // به پیش‌فرض نمایشی).
                $normalized = ltrim(str_replace('\\', '/', $storedImagePath), '/');
                if (str_starts_with($normalized, 'uploads/')) {
                    $this->uploadService->delete($storedImagePath);
                }
            }

            $this->settingsManager->updateValueById($settingId, '');

            // Log the change using robust Audit Trail
            $this->auditLog(
                'setting.image_removed',
                'setting',
                $settingId,
                ['key' => $setting->key ?? null, 'value' => $setting->value ?? null],
                ['key' => $setting->key ?? null, 'value' => '']
            );

            $this->appSettings->clearCache();
            
            $this->jsonSuccess('تصویر با موفقیت حذف شد');
            
        } catch (\Core\Exceptions\HttpResponseException $e) {
            // 🛡️ X169c: پاسخ JSON موفق حذف، استثنای کنترل جریان است — عبور، نه خطا.
            throw $e;
        } catch (\Exception $e) {
            $this->jsonError('خطا در حذف تصویر: ' . $e->getMessage(), [], 500);
        }
    }

    /**
     * 🛡️ X175 — بازتولید «مجموعهٔ مشتق لوگو» از فایل خام تازه‌آپلودشده.
     *
     * چرا؟ جاهای کوچک سایت (ناوبار، سایدبار کاربر/ادمین، فوتر، فاوآیکون)
     * نسخهٔ «نشان مربعی» را نشان می‌دهند؛ اگر این مشتقات فقط یک‌بار به‌صورت
     * دستی ساخته شده باشند، اولین تعویض لوگو از پنل همه‌جا را ناهماهنگ می‌کند.
     *
     * خروجی‌ها (مسیرهای ثابتِ همان تنظیم‌های seed شدهٔ images):
     *   assets/images/logo.png          — بنر کامل با پس‌زمینهٔ شفاف
     *   assets/images/logo-icon.png     — برش مربعیِ نشان (۹۶px)
     *   assets/images/favicon.png       — ۶۴×۶۴
     *   assets/images/logo-icon-180.png — اپل‌تاچ ۱۸۰×۱۸۰
     *
     * فرض برش آیکون: نشان در «سمت شروع» تصویر افقی است (برای طرح فعلی
     * درست است)؛ برای طرح‌های متفاوت ادمین با پیش‌نمایش تب «تصاویر و
     * لوگو» کنترل می‌کند.
     */
    private function deriveLogoSet(string $rawAbsPath): void
    {
        try {
            if (!is_file($rawAbsPath) || !function_exists('imagecreatefrompng')) {
                return; // GD نیست یا فایل خام غایب — بی‌صدا از passing می‌زنیم
            }
            $raw = @imagecreatefrompng($rawAbsPath);
            if (!$raw instanceof \GdImage) {
                $this->logger->warning('admin.settings.logo_derive_source_failed', ['path' => $rawAbsPath]);
                return;
            }
            $outDir = public_path('assets/images');
            if (!is_dir($outDir) && !mkdir($outDir, 0775, true)) {
                return;
            }

            // ── ۱) حذف پس‌زمینهٔ سفید مات (PNG آپلودی معمولاً آلفا ندارد) ──
            $w = imagesx($raw); $h = imagesy($raw);
            imagealphablending($raw, false); imagesavealpha($raw, true);
            for ($y = 0; $y < $h; $y++) {
                for ($x = 0; $x < $w; $x++) {
                    $c = imagecolorat($raw, $x, $y);
                    if ((($c >> 24) & 0x7F) >= 120) continue; // از قبل شفاف
                    $r = ($c >> 16) & 0xFF; $g = ($c >> 8) & 0xFF; $b = $c & 0xFF;
                    $min = min($r, $g, $b); $max = max($r, $g, $b);
                    if ($min >= 242) {
                        imagesetpixel($raw, $x, $y, imagecolorallocatealpha($raw, $r, $g, $b, 127));
                    } elseif ($min >= 205 && ($max - $min) < 26) {
                        // لبه‌های آنتی‌الیاس خاکستری → شفافیت نسبی
                        imagesetpixel($raw, $x, $y, imagecolorallocatealpha($raw, $r, $g, $b, (int)(127 * (242 - $min) / 37)));
                    }
                }
            }
            imagepng($raw, $outDir . '/logo.png');

            // ── ۲) برش مربعیِ نشان + مقیاس‌ها ──
            $side = min($w, $h);
            $icon = imagecreatetruecolor($side, $side);
            imagealphablending($icon, false); imagesavealpha($icon, true);
            imagefill($icon, 0, 0, imagecolorallocatealpha($icon, 0, 0, 0, 127));
            imagecopy($icon, $raw, 0, 0, 0, 0, $side, $side);
            imagepng($icon, $outDir . '/logo-icon.png');

            foreach ([['favicon.png', 64], ['logo-icon-180.png', 180]] as [$name, $size]) {
                $dst = imagecreatetruecolor($size, $size);
                imagealphablending($dst, false); imagesavealpha($dst, true);
                imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
                imagecopyresampled($dst, $icon, 0, 0, 0, 0, $size, $size, $side, $side);
                imagepng($dst, $outDir . '/' . $name);
                imagedestroy($dst);
            }

            imagedestroy($icon); imagedestroy($raw);
            $this->logger->info('admin.settings.logo_derived', ['source' => $rawAbsPath]);
        } catch (\Throwable $e) {
            // مشتق‌سازی شکست خورد؟ آپلود اصلی سالم مانده — فقط لاگ، نه خطای کاربر.
            $this->logger->warning('admin.settings.logo_derive_failed', ['error' => $e->getMessage()]);
        }
    }
}