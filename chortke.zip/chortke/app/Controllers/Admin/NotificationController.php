<?php

namespace App\Controllers\Admin;

use App\Models\Notification;
use App\Services\Notification\NotificationService;
use App\Services\Notification\NotificationAnalyticsService;
use App\Controllers\Admin\BaseAdminController;
use App\Validators\Requests\SendNotificationRequest;
use App\Validators\Requests\SaveNotificationTemplateRequest;
use App\Validators\Requests\DeleteNotificationTemplateRequest;

class NotificationController extends BaseAdminController
{
    private Notification         $model;
    private NotificationService  $notificationService;
    private NotificationAnalyticsService $analyticsService;

    public function __construct(
        Notification        $model,
        NotificationService $notificationService,
        NotificationAnalyticsService $analyticsService
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->model              = $model;
        $this->notificationService = $notificationService;
        $this->analyticsService   = $analyticsService;
    }

    // =========================================================================
    // صفحات اصلی
    // =========================================================================

    /**
     * لیست اعلان‌های ادمین
     */
    public function index(): void
    {
        $adminId       = $this->requireAdminId();
        $notifications = $this->notificationService->latest($adminId, 50);
        $unreadCount   = $this->notificationService->getUnreadCount($adminId);

        view('admin/notifications/index', [
            'title'         => 'اعلان‌ها',
            'notifications' => $notifications,
            'unread_count'  => $unreadCount,
        ]);
    }

    /**
     * صفحه ارسال اعلان — با segment و زمان‌بندی
     */
    public function showSend(): void
    {
        view('admin/notifications/send', [
            'title'            => 'ارسال اعلان به کاربران',
            'segments'         => $this->notificationService->getAvailableSegments(),
            'notification_types' => [
                Notification::TYPE_SYSTEM     => 'سیستمی',
                Notification::TYPE_INFO       => 'اطلاعیه',
                Notification::TYPE_MARKETING  => 'تبلیغاتی',
                Notification::TYPE_TASK       => 'تسک',
                Notification::TYPE_SECURITY   => 'امنیتی',
            ],
        ]);
    }

    /**
     * پردازش ارسال اعلان دستی
     */
    public function send(): void
    {
        $target      = trim($this->request->str('target', 'all'));
        $segment     = trim($this->request->str('segment', 'all'));
        $type        = trim($this->request->str('type', 'info'));
        $title       = trim($this->request->str('title', ''));
        $message     = trim($this->request->str('message', ''));
        $userId      = $this->request->int('user_id');
        $priority    = trim($this->request->str('priority', 'normal'));
        $scheduledAt = trim($this->request->str('scheduled_at', ''));
        $actionUrl   = trim($this->request->str('action_url', ''));
        $actionText  = trim($this->request->str('action_text', ''));

        // FIX-R36-W2-F1 (F-A18-01): فیلترهای سگمنت سفارشی فرم ادمین (filters[status] /
        // filters[kyc_status] / filters[level] / filters[registered_after]) قبلاً همین‌جا
        // دور ریخته می‌شدند و هرگز به جاب نمی‌رسیدند — ارسال «سفارشی» همیشه مسدود
        // («۰ کاربر» گمراه‌کننده) بود. آرایهٔ خام با trim عبوری؛ جاب خودش فقط
        // کلیدهای وایت‌لیست هم‌تراز اسکیمای واقعی را می‌پذیرد (fail-closed).
        $rawFilters = $this->request->input('filters', []);
        $filters = [];
        if (is_array($rawFilters)) {
            foreach ($rawFilters as $filterKey => $filterValue) {
                if (!is_string($filterKey) || $filterKey === '') {
                    continue;
                }
                if (is_string($filterValue)) {
                    $filters[$filterKey] = trim($filterValue);
                } elseif (is_scalar($filterValue)) {
                    $filters[$filterKey] = $filterValue;
                }
            }
        }

        $formRequest = new SendNotificationRequest([
            'target'       => $target,
            'segment'      => $segment,
            'type'         => $type,
            'title'        => $title,
            'message'      => $message,
            // FIX-R71-D1 (O-R71-1): تولیدکننده نباید برای target=all/segment شناسهٔ
            // کاربر ساختگی ۰ بسازد — فرم ادمین فیلد user_id را همیشه submit می‌کند
            // (خالی → request->int → 0) و ولیدیتورِ مرجع (nullable|integer|min:1)
            // صفر را رد می‌کرد ⇒ ارسال همگانی/سگمنتی از پنل ادمین همیشه ردّ
            // اعتبارسنجی می‌شد (فیچر مرده). قرارداد مرجع: user_id فقط برای
            // target=user معنا دارد؛ گیت «شناسه کاربر الزامی است» همان‌جاست.
            'user_id'      => $userId > 0 ? $userId : null,
            'priority'     => $priority,
            'scheduled_at' => $scheduledAt,
            'action_url'   => $actionUrl,
            'action_text'  => $actionText,
        ]);
        if (!$formRequest->validate()) {
            $errors = $formRequest->errors();
            $firstError = is_array($errors) && $errors !== [] ? reset($errors) : '';
            if (is_array($firstError)) {
                $firstError = reset($firstError);
            }
            $firstError = str_value($firstError);
            $this->session->setFlash('error', $firstError ?: 'اطلاعات ورودی نامعتبر است.');
            redirect('/admin/notifications/send');
        }
        $validated = $formRequest->safeValidated(); // FIX-X16
        $target      = str_value($validated['target'] ?? $target);
        $segment     = str_value($validated['segment'] ?? $segment);
        $type        = str_value($validated['type'] ?? $type);
        $title       = str_value($validated['title'] ?? $title);
        $message     = str_value($validated['message'] ?? $message);
        $userId      = int_value($validated['user_id'] ?? $userId);
        $priority    = str_value($validated['priority'] ?? $priority);
        $scheduledAt = str_value($validated['scheduled_at'] ?? $scheduledAt);
        $actionUrl   = str_value($validated['action_url'] ?? $actionUrl);
        $actionText  = str_value($validated['action_text'] ?? $actionText);

        $scheduledAt = !empty($scheduledAt) ? $scheduledAt : null;
        $actionUrl   = !empty($actionUrl)   ? $actionUrl   : null;
        $actionText  = !empty($actionText)  ? $actionText  : null;

        // FIX-R19-A5-2: گیت scheme برای action_url — فقط http/https (مسیرهای داخلی مجاز؛
        // FILTER_VALIDATE_URL مقدارهایی مثل javascript: را می‌پذیرد و این فیلد به کاربران
        // نهایی (in-app + FCM) می‌رسد). مسیرهای نسبی داخلی و رشتهٔ بدون scheme مجازند.
        if ($actionUrl !== null) {
            $isProtocolRelative = preg_match('#^//#', $actionUrl) === 1;
            $scheme = strtolower((string)parse_url($actionUrl, PHP_URL_SCHEME));
            if ($isProtocolRelative || ($scheme !== '' && !in_array($scheme, ['http', 'https'], true))) {
                $this->session->setFlash('error', 'آدرس اکشن باید مسیر داخلی یا لینک معتبر http/https باشد.');
                redirect('/admin/notifications/send');
            }
        }

        $sent = 0;
        $blastTotalSent = null;
        $blastDeduped = false;
        $blastResumed = false;

        if ($target === 'all' || $target === 'segment') {
            $seg    = ($target === 'all') ? 'all' : $segment;
            $result = $this->notificationService->sendToSegment(
                $seg, $title, $message, $type,
                $actionUrl, $actionText, $priority, null, $scheduledAt, $filters
            );
            // FIX-A6-F4 (Audit Task 6-a): نتیجهٔ blast اکنون شامل cursor/resume است —
            //   sent        = ردیف‌های جدید همین اجرا
            //   total_sent  = مجموع پایدار کل blast (پس از resume معنادار است)
            //   deduped     = blast با همین payload قبلاً کامل شده (دور زدن ارسال مضاعف)
            // گزارش ادمین دیگر «به ۰ کاربر ارسال شد» گمراه‌کننده نیست.
            $sent           = int_value($result['sent'] ?? 0);
            $blastTotalSent = int_value($result['total_sent'] ?? 0);
            $blastDeduped   = (bool)($result['deduped'] ?? false);
            $blastResumed   = (bool)($result['resumed'] ?? false);

        } elseif ($target === 'user' && $userId > 0) {
            $notifId = $this->notificationService->send(
                $userId, $type, $title, $message,
                null, $actionUrl, $actionText, $priority,
                null, null, null, $scheduledAt
            );
            $sent = $notifId ? 1 : 0;

        } else {
            $this->session->setFlash('error', 'هدف ارسال نامعتبر است.');
            redirect('/admin/notifications/send');
        }

        $sent = int_value($sent);

        // FIX-A6-F4: پیام صادقانه بر اساس وضعیت واقعی blast
        if ($blastDeduped) {
            $msg = $blastTotalSent > 0
                ? "این اعلان قبلاً با موفقیت به {$blastTotalSent} کاربر ارسال شده است؛ ارسال تکراری نادیده گرفته شد."
                : 'این اعلان قبلاً ارسال شده است؛ ارسال تکراری نادیده گرفته شد.';
        } elseif ($blastResumed && $scheduledAt === null && ($target === 'all' || $target === 'segment')) {
            $msg = "ادامهٔ ارسال اعلان از آخرین نقطه؛ {$sent} کاربر جدید دریافت کرد (مجموع: {$blastTotalSent}).";
        } else {
            $msg = $scheduledAt
                ? "اعلان برای {$sent} کاربر زمان‌بندی شد."
                : "اعلان با موفقیت به {$sent} کاربر ارسال شد.";
        }

       $this->logger->activity('admin_notification_sent', $msg, user_id(), []);
        $this->session->setFlash($blastDeduped ? 'info' : 'success', $msg);
        redirect('/admin/notifications');
    }

    // =========================================================================
    // Analytics
    // =========================================================================

    /**
     * داشبورد آمار کامل
     */
    public function stats(): void
    {
        $days      = max(7, min(90, $this->request->int('days', 30)));
        // 🛡️ FIX-KYC-ENUM: داشبورد کامل (۸ کلید) به‌جای overview خالص — قبلاً قیف،
        // جدول نوع/کانال، روند روزانه، سگمنت و فهرست تعامل همیشه خالی رندر می‌شدند.
        $dashboard = $this->analyticsService->getAnalyticsDashboard($days);

        view('admin/notifications/stats', [
            'title'     => 'آمار اعلان‌ها',
            'dashboard' => $dashboard,
            'days'      => $days,
        ]);
    }

    /**
     * Ajax — داشبورد JSON
     */
    public function statsFetch(): void
    {
        // 🧭 FIX-X205 (راند ۵۵ — تعمیم کلاسِ باگ X202 به پنل ادمین): مرورگر → صفحهٔ اعلان‌ها؛ AJAX → JSON
        if (!is_ajax()) {
            redirect(url('/admin/notifications'));
        }

        $days = max(7, min(90, $this->request->int('days', 30)));

        $this->response->json([
            'success'   => true,
            'dashboard' => $this->analyticsService->getAnalyticsDashboard($days),
        ]);
    }

    // =========================================================================
    // Template Management
    // =========================================================================

    /**
     * لیست template‌ها
     */
    public function templates(): void
    {
        view('admin/notifications/templates', [
            'title'     => 'قالب‌های نوتیفیکیشن',
            'templates' => $this->notificationService->getAllTemplatesWithVariables(),
        ]);
    }

    /**
     * ذخیره override template
     */
    public function saveTemplate(): void
    {
        $formRequest = new SaveNotificationTemplateRequest([
            'template_key' => trim($this->request->str('template_key', '')),
            'title'        => trim($this->request->str('title', '')),
            'message'      => trim($this->request->str('message', '')),
        ]);
        if (!$formRequest->validate()) {
            $errors = $formRequest->errors();
            $firstError = is_array($errors) && $errors !== [] ? reset($errors) : '';
            if (is_array($firstError)) {
                $firstError = reset($firstError);
            }
            $firstError = str_value($firstError);
            $this->response->json(['success' => false, 'error' => $firstError ?: 'اطلاعات ورودی نامعتبر است'], 400);
            return;
        }
        $validated = $formRequest->safeValidated(); // FIX-X16
        $key     = str_value($validated['template_key'] ?? '');
        $title   = str_value($validated['title'] ?? '');
        $message = str_value($validated['message'] ?? '');

        $result = $this->notificationService->saveTemplateOverride($key, $title, $message);

        if ($result) {
            $this->logger->activity('notif_template_saved', "ذخیره template: {$key}", user_id(), []);
        }

        $this->response->json(['success' => $result], $result ? 200 : 422);
    }

    /**
     * حذف override (بازگشت به default)
     */
    public function deleteTemplate(): void
    {
        $formRequest = new DeleteNotificationTemplateRequest([
            'template_key' => trim($this->request->str('template_key', '')),
        ]);
        if (!$formRequest->validate()) {
            $errors = $formRequest->errors();
            $firstError = is_array($errors) && $errors !== [] ? reset($errors) : '';
            if (is_array($firstError)) {
                $firstError = reset($firstError);
            }
            $firstError = str_value($firstError);
            $this->response->json(['success' => false, 'error' => $firstError ?: 'اطلاعات ورودی نامعتبر است'], 400);
            return;
        }
        $validated = $formRequest->safeValidated(); // FIX-X16
        $key = str_value($validated['template_key'] ?? '');

        $this->notificationService->deleteTemplateOverride($key);
       $this->logger->activity('notif_template_deleted', "حذف override template: {$key}", user_id(), []);

        $this->response->json(['success' => true, 'message' => 'بازگشت به template پیش‌فرض']);
    }

    // =========================================================================
    // Ajax — کنترل نوتیف ادمین
    // =========================================================================

    public function fetch(): void
    {
        // 🧭 FIX-X205: مرورگر → صفحهٔ اعلان‌ها؛ AJAX → JSON (قرارداد status())
        if (!is_ajax()) {
            redirect(url('/admin/notifications'));
        }

        $adminId = $this->requireAdminId();
        $items  = $this->notificationService->latest($adminId, 10);
        $unread = $this->notificationService->getUnreadCount($adminId);

        $this->response->json([
            'success'       => true,
            'notifications' => $items,
            'unread_count'  => $unread,
        ]);
    }

    public function unreadCount(): void
    {
        // 🧭 FIX-X205: مرورگر → صفحهٔ اعلان‌ها؛ AJAX → JSON (قرارداد status())
        if (!is_ajax()) {
            redirect(url('/admin/notifications'));
        }

        $adminId = $this->requireAdminId();
        $this->response->json([
            'success' => true,
            'count'   => $this->notificationService->getUnreadCount($adminId),
        ]);
    }

    public function markAsRead(int $id): void
    {
        $adminId = $this->requireAdminId();
        $ok = $this->model->markAsRead($id, $adminId);

        if ($ok) {
            $this->notificationService->invalidateUnreadCache($adminId);
        }

        $this->response->json([
            'success' => $ok,
            'message' => $ok ? 'خوانده شد' : 'عملیات ناموفق بود',
        ], $ok ? 200 : 400);
    }

    public function markAllAsRead(): void
    {
        $adminId = $this->requireAdminId();
        $ok = $this->model->markAllAsRead($adminId);

        if ($ok) {
            $this->notificationService->invalidateUnreadCache($adminId);
        }

        $this->response->json([
            'success' => $ok,
            'message' => $ok ? 'همه خوانده شدند' : 'عملیات ناموفق بود',
        ], $ok ? 200 : 400);
    }
}
