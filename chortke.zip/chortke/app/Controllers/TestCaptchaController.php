<?php

namespace App\Controllers;

use App\Services\CaptchaService;
use App\Controllers\BaseController;

class TestCaptchaController extends BaseController
{
    
    public function __construct(
        ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * 🛡️ FIX-S20-CAPTCHA (محدودیت دسترسی — فایل/صفحه حفظ می‌شود، فقط گیت می‌گیرد):
     * مسیر /test-captcha در routes/public.php فقط برای env های غیر production رجیستر
     * می‌شود؛ این گاردِ دفاع-در-عمق داخل کنترلر تضمین می‌کند حتی اگر مسیر اشتباهاً در
     * production هم رجیستر شد (یا فایل در آینده از جای دیگر include شد)، صفحهٔ تست
     * اجرا نشود. اپراتورِ در حال تست می‌تواند با TEST_TOOLS_ENABLED=1 صراحتاً مجوز دهد.
     */
    private function assertTestToolsAllowed(): void
    {
        $env = strtolower(str_value(config('app.env', 'production')));
        $nonProd = in_array($env, ['local', 'testing', 'development', 'dev', 'test'], true);
        $explicitOptIn = filter_var(getenv('TEST_TOOLS_ENABLED') ?: ($_ENV['TEST_TOOLS_ENABLED'] ?? ''), FILTER_VALIDATE_BOOLEAN);
        if (!$nonProd && !$explicitOptIn) {
            $this->logger->warning('test_tools.blocked_outside_non_prod', [
                'controller' => static::class,
                'env'        => $env,
            ]);
            abort(404); // الگوی کانونی پروژه — رندر errors/404.php
        }
    }

    /**
     * صفحه تست
     */
    public function index(): mixed
    {
        $this->assertTestToolsAllowed();
        return view('test-captcha');
    }
    
    /**
     * بررسی CAPTCHA
     */
    public function verify(): void
{
    $this->assertTestToolsAllowed();
    if (verify_captcha()) {
        $this->session->setFlash('success', '✅ CAPTCHA به درستی حل شد!');
    } else {
        $this->session->setFlash('error', '❌ CAPTCHA اشتباه است!');
    }

    redirect('test-captcha');
}
}