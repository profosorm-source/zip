<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Services\Health\HealthCheckService;

/**
 * StatusController
 *
 * صفحهٔ عمومی «وضعیت سیستم» (/status)
 * - نتیجهٔ readiness probes (دیتابیس/ردیس/صف/دیسک/ Circuit Breaker/درگاه‌ها) را
 *   با کش ۳۰ ثانیه‌ای نمایش می‌دهد تا هم محافظت‌شده باشد و هم بدون فشار روی سرویس‌ها.
 * - اطلاعات حساس (نام هاست، پیام‌های خطای خام و …) از خروجی عمومی حذف می‌شود؛
 *   فقط وضعیت/تأخیر/شمارنده‌های بی‌خطر نمایش داده می‌شوند.
 */
class StatusController extends BaseController
{
    private HealthCheckService $healthService;

    /** مدت کش نتیجهٔ پروب‌ها (ثانیه) */
    private const CACHE_TTL = 30;

    public function __construct(HealthCheckService $healthService, ?\App\Contracts\LoggerInterface $logger = null)
    {
        parent::__construct(null, null, null, null, $logger);
        $this->healthService = $healthService;
    }

    public function index(): \Core\Response
    {
        $snapshot = $this->getSnapshot();

        return $this->response->view('pages/status', [
            'title'       => 'وضعیت سیستم | چرتکه',
            'overall'     => $snapshot['overall'],
            'components'  => $snapshot['components'],
            'generatedAt' => $snapshot['generated_at'],
            'uptimeDays'  => $snapshot['uptime_days'],
        ]);
    }

    /**
     * API عمومی JSON وضعیت سیستم (/status/api)
     *
     * همان اسنپ‌شات پاک‌سازی‌شدهٔ صفحهٔ /status را به‌صورت JSON برمی‌گرداند تا
     * مانیتورینگ خارجی/داشبورد/به‌روزرسانی زندهٔ صفحه بتواند مصرفش کند.
     * - کش ۳۰ ثانیه‌ای مشترک با صفحهٔ HTML (بدون فشار اضافه به سرویس‌ها)
     * - هدرهای Cache-Control مناسب + بدون اطلاعات حساس
     */
    public function api(): \Core\Response
    {
        $snapshot = $this->getSnapshot();

        $okCount    = count(array_filter($snapshot['components'], fn ($c) => ($c['status'] ?? '') === 'ok'));
        $totalCount = count($snapshot['components']);

        // کش سمت کلایند/پراکسی — هم‌تراز با کش ۳۰ ثانیه‌ای سمت سرور
        $this->response->setHeader('Cache-Control', 'public, max-age=30, stale-while-revalidate=60');

        return $this->response->json([
            'success'        => true,
            'overall'        => $snapshot['overall'],
            'ok_count'       => $okCount,
            'total_count'    => $totalCount,
            'uptime_days'    => $snapshot['uptime_days'],
            'generated_at'   => $snapshot['generated_at'],
            'components'     => $snapshot['components'],
        ]);
    }

    /**
     * اسنپ‌شات عمومی و «پاک‌سازی‌شده» از وضعیت سرویس‌ها (کش ۳۰ ثانیه)
     *
     * @return array{overall:string, components:list<array{key:string,label:string,icon:string,status:string,details:array<int,array{label:string,value:string}>}>, generated_at:string, uptime_days:int}
     */
    private function getSnapshot(): array
    {
        try {
            $cached = cache()->get('public_status_snapshot');
            if (is_array($cached) && isset($cached['overall'], $cached['components'])) {
                return $cached;
            }
        } catch (\Throwable) {
            // کش در دسترس نیست — مستقیم پروب می‌زنیم
        }

        $snapshot = $this->buildSnapshot();

        try {
            cache()->putSeconds('public_status_snapshot', $snapshot, self::CACHE_TTL);
        } catch (\Throwable) {
            // بی‌خطر — فقط کش
        }

        return $snapshot;
    }

    /** @return array{overall:string, components:list<array{key:string,label:string,icon:string,status:string,details:array<int,array{label:string,value:string}>}>, generated_at:string, uptime_days:int} */
    private function buildSnapshot(): array
    {
        $checks = [];
        $status = 'ok';

        try {
            $ready = $this->healthService->checkReadiness();
            $checks = is_array($ready['checks'] ?? null) ? $ready['checks'] : [];
            $status = is_string($ready['status'] ?? null) ? $ready['status'] : 'ok';
        } catch (\Throwable) {
            $status = 'degraded';
        }

        $components = [];

        // ── دیتابیس ──
        $db = $checks['database'] ?? [];
        $components[] = $this->component('database', 'دیتابیس', 'storage', $db['status'] ?? 'unknown', [
            ['label' => 'زمان پاسخ', 'value' => isset($db['latency_ms']) ? fa_number((string)$db['latency_ms']) . ' ms' : '—'],
            ['label' => 'کوئری‌های کند', 'value' => isset($db['slow_query_count']) ? fa_number((string)$db['slow_query_count']) : '۰'],
        ]);

        // ── ردیس (کش) ──
        $redis = $checks['redis'] ?? [];
        $components[] = $this->component('redis', 'سیستم کش (Redis)', 'bolt', $redis['status'] ?? 'unknown', [
            ['label' => 'درایور', 'value' => ($redis['driver'] ?? 'redis') === 'file' ? 'فایل' : 'Redis'],
        ]);

        // ── صف کارها ──
        $queue = $checks['queue'] ?? [];
        $components[] = $this->component('queue', 'صف پردازش', 'low_priority', $queue['status'] ?? 'unknown', [
            ['label' => 'کارهای در انتظار', 'value' => fa_number((string)($queue['pending_jobs'] ?? 0))],
        ]);

        // ── دیسک ──
        $disk = $checks['disk'] ?? [];
        $diskDetails = [];
        if (isset($disk['used_percent']) && is_numeric($disk['used_percent'])) {
            $diskDetails[] = ['label' => 'مصرف دیسک', 'value' => fa_number((string)round((float)$disk['used_percent'], 1)) . '٪'];
        }
        $components[] = $this->component('disk', 'فضای ذخیره‌سازی', 'database_upload', $disk['status'] ?? 'unknown', $diskDetails);

        // ── درگاه‌های پرداخت ──
        $gw = $checks['external_gateways'] ?? [];
        $components[] = $this->component('gateways', 'درگاه‌های پرداخت', 'payment', $gw['status'] ?? 'unknown', [
            ['label' => 'سرویس‌های باز', 'value' => fa_number((string)($gw['open_count'] ?? 0))],
        ]);

        // ── سرویس ایمیل ──
        $components[] = $this->component('email', 'صف ارسال ایمیل', 'mail', $this->emailQueueStatus(), [
            ['label' => 'ایمیل در انتظار', 'value' => fa_number((string)($this->emailQueuePending() ?? 0))],
        ]);

        // ── صف رویدادها (Outbox) — این پروب در overall readiness لحاظ می‌شود
        //    و باید روی صفحه هم دیده شود (قبلاً نامرئی بود → ناسازگاری overall/کارت‌ها) ──
        $outbox = $checks['outbox'] ?? [];
        $outboxStatus = is_array($outbox) ? ($outbox['status'] ?? 'unknown') : 'unknown';
        $outboxDetails = [];
        if (is_array($outbox)) {
            if (isset($outbox['pending'])) {
                $outboxDetails[] = ['label' => 'رویداد در انتظار انتشار', 'value' => fa_number((string)(int)$outbox['pending'])];
            }
            if (isset($outbox['failed_or_dlq'])) {
                $outboxDetails[] = ['label' => 'شکست/DLQ', 'value' => fa_number((string)(int)$outbox['failed_or_dlq'])];
            }
        }
        $components[] = $this->component('outbox', 'صف رویدادها (Outbox)', 'outbox', $outboxStatus, $outboxDetails);

        // ── پردازش توزیع‌شده (Saga / DLQ) ──
        $saga = $checks['saga'] ?? [];
        $dlq  = $checks['dlq'] ?? [];
        $sagaStatus = is_array($saga) ? ($saga['status'] ?? 'unknown') : 'unknown';
        $dlqStatus  = is_array($dlq) ? ($dlq['status'] ?? 'unknown') : 'unknown';
        $distStatus = $this->worstStatus($sagaStatus, $dlqStatus);
        $distDetails = [];
        if (is_array($saga) && isset($saga['running'])) {
            $distDetails[] = ['label' => 'Saga در حال اجرا', 'value' => fa_number((string)(int)$saga['running'])];
        }
        if (is_array($dlq) && isset($dlq['total_failed_jobs'])) {
            $distDetails[] = ['label' => 'کارهای شکست‌خورده', 'value' => fa_number((string)(int)$dlq['total_failed_jobs'])];
        }
        $components[] = $this->component('distributed', 'پردازش توزیع‌شده (Saga/DLQ)', 'hub', $distStatus, $distDetails);

        // اگر هر جزئی error بود ولی overall ok بود، سخت‌گیرانه‌تر برو
        foreach ($components as $c) {
            if ($c['status'] === 'error' && $status === 'ok') {
                $status = 'degraded';
            }
        }

        return [
            'overall'      => $status,
            'components'   => $components,
            'generated_at' => date('Y-m-d H:i:s'),
            'uptime_days'  => $this->uptimeDays(),
        ];
    }

    /**
     * @param array<int, array{label:string,value:string}> $details
     * @return array{key:string,label:string,icon:string,status:string,details:array<int,array{label:string,value:string}>}
     */
    private function component(string $key, string $label, string $icon, string $status, array $details): array
    {
        return [
            'key'     => $key,
            'label'   => $label,
            'icon'    => $icon,
            'status'  => $this->normalizeStatus($status),
            'details' => $details,
        ];
    }

    private function normalizeStatus(string $status): string
    {
        return match ($status) {
            'ok', 'healthy', 'operational' => 'ok',
            'degraded', 'warning'          => 'degraded',
            'error', 'down', 'critical'    => 'error',
            'disabled'                     => 'disabled',
            default                        => 'unknown',
        };
    }

    /**
     * بدترین وضعیت بین دو پروب (برای ترکیب Saga/DLQ در یک کارت)
     * ترتیب شدت: error > degraded > disabled > unknown > ok
     */
    private function worstStatus(string $a, string $b): string
    {
        $severity = ['ok' => 0, 'unknown' => 1, 'disabled' => 2, 'degraded' => 3, 'error' => 4];
        $sa = $severity[$a] ?? 1;
        $sb = $severity[$b] ?? 1;
        return $sa >= $sb ? $a : $b;
    }

    /** وضعیت صف ایمیل — بی‌خطر برای نمایش عمومی */
    private function emailQueueStatus(): string
    {
        $pending = $this->emailQueuePending();
        if ($pending === null) {
            return 'unknown';
        }
        // بیش از ۵۰۰ ایمیل در انتظار = صف عقب‌افتاده
        return $pending > 500 ? 'degraded' : 'ok';
    }

    private function emailQueuePending(): ?int
    {
        static $memo = null;
        if ($memo !== null) {
            return $memo;
        }
        try {
            // FIX-RAW-SQL: مالکیت SQL با مدل — کنترلر فقط delegate می‌کند
            $memo = (new \App\Models\EmailQueue(db()))->countPendingOrSending();
        } catch (\Throwable) {
            // خطا را کش نمی‌کنیم تا تلاش بعدی شانس داشته باشد
            return null;
        }
        return $memo;
    }

    private function uptimeDays(): int
    {
        try {
            // FIX-RAW-SQL: مالکیت SQL با مدل — کنترلر فقط delegate می‌کند
            $first = (new \App\Models\User(db()))->findEarliestCreatedAt();
            if (is_string($first) && $first !== '') {
                $days = (int)floor((time() - strtotime($first)) / 86400);
                return max(1, $days);
            }
        } catch (\Throwable) {
        }
        return 1;
    }
}
