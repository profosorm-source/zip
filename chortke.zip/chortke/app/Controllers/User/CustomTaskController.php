<?php

namespace App\Controllers\User;

use App\Services\CustomTask\CustomTaskExecutorService;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\Analytics\AnalyticsService;
use App\Services\UploadService;
use App\Validators\Requests\SubmitCustomTaskProofRequest;
use App\Controllers\User\BaseUserController;
use Core\Logger;

/**
 * CustomTaskController — Executor-only controller.
 *
 * NOTE: Advertiser management (create, pause, stats, list) is unified under /ads (AdsController).
 * This controller only handles the worker side: submission, rating, and proof upload.
 */
class CustomTaskController extends BaseUserController
{
    private CustomTaskExecutorService $executorService;
    private CustomTaskModerationService $moderationService;
    private AnalyticsService $analyticsService;
    private UploadService $uploadService;

    public function __construct(
        CustomTaskExecutorService $executorService,
        CustomTaskModerationService $moderationService,
        AnalyticsService $analyticsService,
        UploadService $uploadService,
        Logger $logger
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->executorService = $executorService;
        $this->moderationService = $moderationService;
        $this->analyticsService = $analyticsService;
        $this->uploadService = $uploadService;
    }

    /**
     * ارسال مدرک - با Request Validation
     */
    public function submitProof()
    {
        $userId = $this->userId();
        $subId = (int) $this->request->param('id');

        $request = new SubmitCustomTaskProofRequest($this->request->all());
        if (!$request->validate()) {
            $this->response->json([
                'success' => false,
                'message' => 'خطای اعتبارسنجی',
                'errors' => $request->errors()
            ], 422);
            return;
        }

        $proofData = $request->validated();

        // مدیریت آپلود فایل
        if (!empty($_FILES['proof_file']['name'])) {
            $uploadResult = $this->uploadService->upload($_FILES['proof_file'], 'task-proofs', ['jpg','png','webp','pdf'], 5*1024*1024);
            if ($uploadResult['success']) {
                $proofData['proof_file'] = $uploadResult['path'];
                $proofData['proof_file_hash'] = md5_file(__DIR__ . '/../../../' . $uploadResult['path']) ?? null;
            }
        }

        $result = $this->executorService->submitProof($subId, $userId, $proofData);
        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    /**
     * امتیازدهی - با Request Validation
     */
    public function rateSubmission()
    {
        $userId = $this->userId();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];

        $validator = \Core\Validator::create($body, [
            'submission_id' => 'required|integer|min:1',
            'rating'        => 'required|integer|min:1|max:5',
            'feedback'      => 'nullable|string|min:5|max:1000',
        ]);

        if ($validator->fails()) {
            $this->response->json([
                'success' => false,
                'message' => 'خطای اعتبارسنجی',
                'errors' => $validator->errors()
            ], 422);
            return;
        }

        $result = $this->moderationService->rateSubmission(
            (int)$body['submission_id'],
            $userId,
            $validator->data()
        );

        $this->response->json($result, $result['success'] ? 200 : 422);
    }
}
