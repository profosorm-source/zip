<?php

namespace App\Controllers\User;

use App\Services\CustomTask\CustomTaskExecutorService;
use App\Services\CustomTask\CustomTaskModerationService;
// FIX-M22-MED (T22-18): قرارداد مشترک normalize/validate مدرک — حذف کپیِ تکراری
use App\Services\CustomTask\CustomTaskProofSchema;
// 📱 FIX-MOBCTR-01: تک‌منبع ذخیرهٔ فایل مدرک (استخراج از همین کنترلر؛ هم‌الگوی T22-18)
use App\Services\CustomTask\CustomTaskProofFileService;
use App\Services\Shared\DisputeService;
use App\Services\Analytics\AnalyticsService;
use App\Services\UploadService;
use App\Validators\Requests\SubmitCustomTaskProofRequest;
use App\Validators\Requests\CreateCustomTaskReportRequest;
use App\Controllers\User\BaseUserController;
use Core\Logger;

/**
 * CustomTaskController — Executor-only controller.
 *
 * NOTE: Advertiser management (create, pause, stats, list) is unified under /ads (AdsController).
 * This controller only handles the worker side: submission, rating, and proof upload.
 */
class CustomTaskController extends BaseUserController
{
    private CustomTaskExecutorService $executorService;
    private CustomTaskModerationService $moderationService;
    // 📱 FIX-MOBCTR-01: کانال فایل مدرک (تصویر/PDF/ویدیو) از این سرویس — قبلاً
    // متدهای خصوصی همین کنترلر بودند و کنترلر API موبایل باید همان قواعد را کپی می‌کرد.
    private CustomTaskProofFileService $proofFileService;
    private \App\Models\Ads $adsModel;
    private DisputeService $disputeService;
    private \App\Models\CustomTaskSubmissionModel $submissionModel;
    // FIX-M22-MED (T22-20): منبعِ totalDone برای _earn-nav (شمارشِ approved این مجری)
    private \App\Models\CustomTaskAnalyticsModel $analyticsModel;

    public function __construct(
        CustomTaskExecutorService $executorService,
        CustomTaskModerationService $moderationService,
        UploadService $uploadService,
        \App\Models\Ads $adsModel,
        DisputeService $disputeService,
        \App\Models\CustomTaskSubmissionModel $submissionModel,
        \App\Models\CustomTaskAnalyticsModel $analyticsModel,
        Logger $logger
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->executorService = $executorService;
        $this->moderationService = $moderationService;
        $this->proofFileService = new CustomTaskProofFileService($uploadService);
        $this->adsModel = $adsModel;
        $this->disputeService = $disputeService;
        $this->submissionModel = $submissionModel;
        $this->analyticsModel = $analyticsModel;
    }

    public function index(): void
    {
        $this->available();
    }

    /**
     * 🧾 FIX-M22-CLOSE (D2-N8): ثبت گزارش تخلف تسک سفارشی (فرم وب و JSON؛ CSRF‌دار).
     *
     * 🧹 FIX-COSMET-12 (A2-N1/متوسط): فرم وب ساده (POST بدون XHR در show.php) حالا
     * پاسخ redirect+flash می‌گیرد — قبلاً همیشه JSON خام رندر می‌شد و کاربر صفحهٔ
     * JSON می‌دید (الگوی wantsJson/finishDisputeResponse همین کنترلر؛ تعهد اولیهٔ
     * کامنت D2-N8 «پاسخ سرویس پیام flash-مانند نمایش می‌دهد» اکنون برقرار است).
     */
    public function report(): void
    {
        $userId = (int)$this->userId();
        $taskId = (int)$this->request->param('id');
        $wantsJson = $this->wantsJson();

        // body() هر دو نوع فرم وب و JSON را پارس می‌کند (core/Request.php CORE-022).
        /** @var array<string, mixed> $body */
        $body = is_array($this->request->body()) ? $this->request->body() : [];

        $request = new CreateCustomTaskReportRequest($body);
        if (!$request->validate()) {
            $firstError = $this->firstValidationError($request->errors());
            if ($wantsJson) {
                $this->response->json(['success' => false, 'message' => $firstError, 'errors' => $request->errors()], 422);
                return;
            }
            $this->session->setFlash('error', $firstError);
            $this->response->redirect(url('/custom-tasks/' . $taskId));
            return;
        }
        $validated = $request->safeValidated();

        $result = $this->executorService->reportTask(
            $userId,
            $taskId,
            str_value($validated['reason'] ?? ''),
            trim(str_value($validated['description'] ?? ''))
        );
        if ($wantsJson) {
            $this->response->json($result, !empty($result['success']) ? 200 : 422);
            return;
        }
        $this->session->setFlash(!empty($result['success']) ? 'success' : 'error', str_value($result['message'] ?? 'ثبت گزارش انجام نشد.'));
        $this->response->redirect(url('/custom-tasks/' . $taskId));
    }

    public function available(): void
    {
        // Worker-side custom tasks are now part of the unified task marketplace.
        $this->response->redirect(url('/tasks?type=custom_task'));
    }

    public function mySubmissions(): void
    {
        $userId = (int)$this->userId();
        // FIX-M22-MED (T22-20): صفحه‌بندی واقعی — قبلاً page نادیده گرفته می‌شد و
        // مدل با limit=100/offset=0 ثابت صدا می‌شد. اکنون: perPage=20 (هم‌اندازهٔ
        // مارک‌آپ ویو)، count واقعی و totalPages برای ویو.
        $perPage = 20;
        $page = min(500, max(1, $this->request->int('page', 1)));
        $offset = ($page - 1) * $perPage;

        $submissions = [];
        $total = 0;
        try {
            $total = (int)$this->submissionModel->submission_countByWorkerWithTask($userId);
            $submissions = $this->submissionModel->submission_getByWorkerWithTask($userId, $perPage, $offset);
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.my_submissions_unavailable', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }
        $totalPages = max(1, (int)ceil($total / $perPage));

        $this->view('user/custom-tasks/executor/my-submissions', [
            'submissions' => $submissions,
            'page' => $page,
            'totalPages' => $totalPages,
            'title' => 'اجراهای تسک سفارشی من',
        ]);
    }

    public function show(): void
    {
        $taskId = (int)$this->request->param('id');
        $userId = (int)$this->userId();
        $task = null;
        try {
            $task = $this->adsModel->find($taskId);
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.show_unavailable', ['task_id' => $taskId, 'error' => $e->getMessage()]);
        }

        if (!$task) {
            $this->session->setFlash('error', 'تسک مورد نظر یافت نشد.');
            $this->response->redirect(url('/tasks?type=custom_task'));
            return;
        }

        // 🛡️ FIX-M22-02: show قبلاً با find(id) هر ردیف ads (حتی paused/draft/
        // pending_reviewِ دیگران) را رندر می‌کرد. صفحهٔ اجرا فقط برای تسک‌های
        // سفارشیِ فعال معنا دارد؛ مدیریت آگهی توسط خود کارفرما از پنل /ads
        // انجام می‌شود و رکوردهای در انتظار بررسی نباید پیش از انتشار دیده شوند.
        if (($task->type ?? '') !== 'custom_task' || ($task->status ?? '') !== 'active') {
            $this->session->setFlash('error', 'این تسک در دسترس اجرا نیست.');
            $this->response->redirect(url('/tasks?type=custom_task'));
            return;
        }

        // 🧾 FIX-M22-CLOSE (D2-N8): دکمهٔ «گزارش تخلف» فقط برای غیر-owner — owner
        // خودش مدیری که گزارش‌ها را در /admin/custom-tasks/reports بررسی می‌کند نیست،
        // ولی گزارش‌دادن تسک خودش بی‌معنا و آسیب‌پذیر به سوءاستفاده است.
        $canReport = ((int)($task->user_id ?? 0) !== $userId)
            && (!isset($task->creator_id) || (int)$task->creator_id !== $userId);

        $this->view('user/custom-tasks/show', array_merge($this->earnNavStats($userId), [
            'task' => $task,
            'title' => $task->title ?? 'جزئیات تسک سفارشی',
            'canReport' => $canReport,
        ]));
    }

    public function start(): void
    {
        $taskId = int_value($this->request->param('id') ?: ($this->request->input('task_id') ?? $this->request->input('id') ?? 0));
        $userId = (int)$this->userId();
        if ($taskId <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه تسک نامعتبر است.'], 422);
            return;
        }
        $result = $this->executorService->startTask($taskId, $userId);
        if (!empty($result['success']) && !empty($result['submission_id'])) {
            $result['redirect_url'] = url('/custom-tasks/submissions/' . int_value($result['submission_id']) . '/proof');
            $result['message'] = $result['message'] ?? 'تسک شروع شد؛ اکنون مدرک انجام را ارسال کنید.';
        }
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    public function proofForm(): void
    {
        $submissionId = (int)$this->request->param('id');
        $userId = (int)$this->userId();
        $submission = $this->findSubmissionForProof($submissionId, $userId);

        if (!$submission) {
            $this->session->setFlash('error', 'اجرای تسک سفارشی یافت نشد.');
            $this->response->redirect(url('/custom-tasks/my-submissions'));
            return;
        }

        $this->view('user/custom-tasks/proof', array_merge($this->earnNavStats($userId), [
            'submission' => $submission,
            'title' => 'ارسال مدرک تسک سفارشی',
        ]));
    }

    public function disputes(): void
    {
        $userId = (int)$this->userId();
        // 🧹 FIX-COSMET-16 (A2-N12/پایین): صفحه‌بندی واقعی — قبلاً limit ۱۰۰ ثابت
        // بدون pager (DisputeQueryService:64) و ردیف ۱۰۱+ از هیچ UIای قابل‌دسترس
        // نبود؛ الگوی mySubmissions (perPage=20 + شمارش واقعی + partial مشترک).
        $perPage = 20;
        $page = min(500, max(1, $this->request->int('page', 1)));
        $offset = ($page - 1) * $perPage;

        $items = [];
        $total = 0;
        try {
            $total = (int)$this->disputeService->countCustomTaskDisputesByUser($userId);
            $items = $this->disputeService->getCustomTaskDisputesByUser($userId, $perPage, $offset);
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.disputes_unavailable', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }
        $totalPages = max(1, (int)ceil($total / $perPage));

        $this->view('user/custom-tasks/executor/disputes', [
            'items' => $items,
            'disputes' => $items,
            'page' => $page,
            'totalPages' => $totalPages,
            'title' => 'اختلافات تسک‌های سفارشی',
        ]);
    }

    public function storeDispute(): void
    {
        $userId = (int)$this->userId();
        $submissionId = int_value($this->request->param('id'));
        $reason = trim(str_value($this->request->input('reason') ?? $this->request->input('message') ?? ''));
        $wantsJson = $this->wantsJson();
        if ($submissionId <= 0 || mb_strlen($reason) < 10) {
            $this->finishDisputeResponse(false, 'دلیل اختلاف باید حداقل ۱۰ کاراکتر باشد.', null, 422, $wantsJson);
            return;
        }

        try {
            // بارگذاری submission از طریق Model — Raw SQL حذف شد
            $submission = $this->findSubmissionForProof($submissionId, $userId);
            if (!$submission) {
                $this->finishDisputeResponse(false, 'ارسال/اجرای تسک یافت نشد.', null, 404, $wantsJson);
                return;
            }
            if (!in_array((string)$submission->status, ['rejected'], true)) {
                $this->finishDisputeResponse(false, 'اختلاف فقط پس از رد شدن مدرک قابل ثبت است.', null, 422, $wantsJson);
                return;
            }

            // delegate به DisputeService — همه Raw SQL حذف شد
            $result = $this->disputeService->openCustomTaskDispute(
                $submissionId,
                $userId,
                (int)$submission->advertiser_id,
                $reason
            );

            $this->finishDisputeResponse(
                (bool)($result['success'] ?? false),
                str_value($result['message'] ?? 'اختلاف ثبت شد.'),
                isset($result['dispute_id']) ? int_value($result['dispute_id']) : null,
                ($result['success'] ?? false) ? 200 : 422,
                $wantsJson
            );
        } catch (\Core\Exceptions\HttpResponseException $response) {
            throw $response;
        } catch (\Throwable $e) {
            $this->logger->error('custom_tasks.dispute_create_failed', ['submission_id' => $submissionId, 'user_id' => $userId, 'error' => $e->getMessage()]);
            $this->finishDisputeResponse(false, 'ثبت اختلاف انجام نشد.', null, 500, $wantsJson);
        }
    }

    public function disputeDetail(): void
    {
        $disputeId = (int)$this->request->param('id');
        $userId = (int)$this->userId();
        // Raw SQL حذف شد — از DisputeService استفاده می‌شود
        $dispute = $this->disputeService->findDetailWithSubmission($disputeId, $userId);
        if (!$dispute) {
            $this->session->setFlash('error', 'پرونده اختلاف یافت نشد یا دسترسی ندارید.');
            $this->response->redirect(url('/custom-tasks/disputes-list'));
            return;
        }
        $messages = $this->disputeService->getMessages($disputeId);
        // 🛡️ FIX-M22-MED (T22-20/E2-review): صفحهٔ اختلاف هم _earn-nav را include می‌کند؛
        // بدون این کلیدها همان صفرهای قبلی را نشان می‌داد (دامنهٔ اولیه فقط show/proof بود).
        $earnNav = $this->earnNavStats($userId);
        $this->view('user/custom-tasks/executor/dispute-detail', [
            'dispute' => $dispute,
            'messages' => $messages,
            'title' => 'جزئیات اختلاف تسک سفارشی',
        
            'totalTasks' => $earnNav['totalTasks'],
            'totalDone' => $earnNav['totalDone'],
        ]);
    }

    public function replyDispute(): void
    {
        $disputeId = int_value($this->request->param('id'));
        $userId = (int)$this->userId();
        $message = trim($this->request->str('message'));
        if (mb_strlen($message) < 2) {
            $this->session->setFlash('error', 'متن پیام الزامی است.');
            $this->response->redirect(url('/custom-tasks/disputes/' . $disputeId));
            return;
        }
        // Raw SQL حذف شد — از DisputeService.sendMessage() استفاده می‌شود
        // 🧹 FIX-COSMET-17 (A3-N6/کم): نقش فرستندهٔ وب از عضویت واقعی در پرونده محاسبه
        // می‌شود (واژگان مشترک ماژول: worker/advertiser — هم‌راستا با raised_by_role
        // لیست ادمین)؛ قبلاً 'auto' خام در dispute_messages.role ذخیره/بازتاب می‌شد.
        $role = 'advertiser';
        $disputeRow = $this->disputeService->find($disputeId);
        if ($disputeRow && (string)($disputeRow->ref_type ?? '') === 'custom_task_submission') {
            $submissionRow = $this->submissionModel->submission_findById((int)$disputeRow->ref_id);
            if ($submissionRow && (int)($submissionRow->worker_id ?? 0) === $userId) {
                $role = 'worker';
            }
        }
        $result = $this->disputeService->sendMessage($disputeId, $userId, $role, $message);
        if (!($result['success'] ?? false)) {
            $this->session->setFlash('error', $result['message'] ?? 'امکان ارسال پیام برای این پرونده وجود ندارد.');
            $this->response->redirect(url('/custom-tasks/disputes-list'));
            return;
        }
        $this->session->setFlash('success', 'پیام شما ثبت شد.');
        $this->response->redirect(url('/custom-tasks/disputes/' . $disputeId));
    }

    // FIX-M22-MED (T22-21): review() حذف شد — استاب ۴۲۲ مرده؛ بررسی ارسال‌ها
    // از پنل تبلیغ‌دهنده انجام می‌شود (حذف route: user.php:248 با هماهنگ‌کننده).

    /**
     * ارسال مدرک - schema-based validation per proof_type.
     */
    public function submitProof(): void
    {
        $userId = (int)$this->userId();
        $subId = (int)$this->request->param('id');
        $submission = $this->findSubmissionForProof($subId, $userId);

        if (!$submission) {
            $this->response->json(['success' => false, 'message' => 'اجرای تسک سفارشی یافت نشد.'], 404);
            return;
        }
        if ((string)$submission->status !== 'in_progress') {
            $this->response->json(['success' => false, 'message' => 'این اجرا در وضعیت قابل ارسال مدرک نیست.'], 422);
            return;
        }

        // FIX-M22-MED (T22-18): کانال فایل فقط از نتیجهٔ آپلودِ سرور ساخته می‌شود.
        // proof_file/proof_file_hash/idempotency_key هرگز از ورودی کلاینت خوانده
        // نمی‌شوند (قبلاً رشتهٔ خام کلاینت به‌عنوان کلید دِداپ جعل‌پذیر جاب می‌رفت).
        $payload = $this->request->all();
        unset($payload['proof_file'], $payload['proof_file_hash'], $payload['idempotency_key']);
        $payload['task_execution_id'] = $subId;

        $proofType = CustomTaskProofSchema::normalizeType((string)($submission->proof_type ?? 'text'));
        // 🧾 FIX-M22-CLOSE (D2-edge): نوع مدرکِ محاسبه‌شدهٔ سرور برای قاعدهٔ
        // مشروط proof_text در SubmitCustomTaskProofRequest (مقدار کلاینت overwrite
        // می‌شود — غیرقابل جعل).
        $payload['proof_type'] = $proofType;
        $fileRequired = in_array($proofType, ['screenshot', 'file'], true);
        $hasProofFile = !empty($_FILES['proof_file']['name']);

        if ($fileRequired && !$hasProofFile) {
            $this->response->json(['success' => false, 'message' => $proofType === 'screenshot' ? 'برای این تسک، اسکرین‌شات الزامی است.' : 'برای این تسک، فایل مدرک الزامی است.'], 422);
            return;
        }

        $uploadedPath = null;
        if ($hasProofFile) {
            try {
                // 📱 FIX-MOBCTR-01: همان منطق تک‌منبع، حالا در سرویس مشترک وب/موبایل
                $uploadResult = $this->proofFileService->store($_FILES['proof_file'], $proofType);
                $payload['proof_file'] = $uploadResult['path'];
                $payload['proof_file_hash'] = $uploadResult['hash'];
                $uploadedPath = $uploadResult['path'];
            } catch (\Core\Exceptions\BusinessException|\RuntimeException $e) {
                // این دو نوع Exception پیام‌های کاربرپسند و امن (فارسی) تولید می‌کنند.
                // سایر خطاهای غیرمنتظره به GlobalExceptionMiddleware واگذار می‌شوند.
                $this->response->json(['success' => false, 'message' => $e->getMessage()], 422);
                return;
            }
        }

        $schemaError = CustomTaskProofSchema::validateSchema($proofType, $payload);
        if ($schemaError !== null) {
            // FIX-M22-MED (D2-N13): فایل آپلودشده در خطای اعتبارسنجیِ پس از آپلود
            // دیگر orphan روی دیسک نمی‌ماند.
            if (is_string($uploadedPath)) {
                $this->proofFileService->delete($uploadedPath);
            }
            $this->response->json(['success' => false, 'message' => $schemaError], 422);
            return;
        }

        // 🛡️ FIX-BEHAV1-04 (A1-N4): آگهی‌های موجودِ (پیش از سقفِ آداپتر) با
        // دستورالعمل ≥۴KB، ارسال مدرکِ وب را برای همیشه ۴۲۲ می‌کردند: blobِ
        // proof_data اسکمای آگهی را echo می‌کند و ولیدیتور روی کل blob
        // max:4000 می‌گذارد. کلیدهای این blob (proof_schema/submitted_fields)
        // هیچ خواننده‌ای ندارند (رکورد رویدادند؛ مایگریشن M22-CLOSE)؛ نسخهٔ
        // کامل در ads.proof_schema هست. توضیحِ داخل blob به ۱۰۰۰ حرف محدود
        // می‌شود تا blob برای آگهی‌های قدیمی هم همیشه زیر سقف بماند.
        $embeddedSchema = $this->decodeJsonObject($submission->proof_schema ?? null);
        if (is_array($embeddedSchema) && array_key_exists('description', $embeddedSchema)) {
            $embeddedSchema['description'] = mb_substr(str_value($embeddedSchema['description']), 0, 1000);
        }
        $payload['proof_data'] = json_encode([
            'proof_type' => $proofType,
            'proof_schema' => $embeddedSchema,
            'submitted_fields' => [
                'proof_text' => trim(str_value($payload['proof_text'] ?? '')) !== '',
                'proof_url' => trim(str_value($payload['proof_url'] ?? '')) !== '',
                'proof_code' => trim(str_value($payload['proof_code'] ?? '')) !== '',
                'proof_file' => !empty($payload['proof_file']),
            ],
        ], JSON_UNESCAPED_UNICODE);

        $request = new SubmitCustomTaskProofRequest($payload);
        if (!$request->validate()) {
            // FIX-M22-MED (D2-N13): همان پاک‌سازی فایل orphan در شاخهٔ خطای فرم.
            if (is_string($uploadedPath)) {
                $this->proofFileService->delete($uploadedPath);
            }
            $this->response->json([
                'success' => false,
                'message' => 'خطای اعتبارسنجی',
                'errors' => $request->errors(),
            ], 422);
            return;
        }

        $proofData = array_merge($payload, $request->safeValidated());
        $result = $this->executorService->submitProof($subId, $userId, $proofData);
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }


    private function wantsJson(): bool
    {
        $accept = strtolower(str_value($this->request->header('accept')));
        $xhr = $this->request->isAjax();
        return str_contains($accept, 'application/json') || $xhr;
    }

    private function finishDisputeResponse(bool $success, string $message, ?int $disputeId, int $status, bool $json): void
    {
        if ($json) {
            $this->response->json(['success' => $success, 'message' => $message, 'dispute_id' => $disputeId], $status);
            return;
        }
        $this->session->setFlash($success ? 'success' : 'error', $message);
        $this->response->redirect($success && $disputeId ? url('/custom-tasks/disputes/' . $disputeId) : url('/custom-tasks/my-submissions'));
    }

    /**
     * امتیازدهی - با Request Validation
     */
    public function rateSubmission(): void
    {
        $userId = (int)$this->userId();
        $decodedBody = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($decodedBody)) {
            $this->response->json([
                'success' => false,
                'message' => 'بدنه درخواست باید یک JSON object معتبر باشد',
            ], 422);
            return;
        }
        $body = $decodedBody;

        // 📜 مهاجرت به قرارداد واحد ورودی: FormRequest به‌جای Validator::create
        // (تنها مورد باقی‌ماندهٔ ممنوعهٔ RULES §۱۸ در کل پروژه بود).
        $request = new \App\Validators\Requests\RateSubmissionRequest($body);
        if (!$request->validate()) {
            $this->response->json([
                'success' => false,
                'message' => 'خطای اعتبارسنجی',
                'errors' => $request->errors(),
            ], 422);
            return;
        }

        $result = $this->moderationService->rateSubmission(
            (int)$body['submission_id'],
            $userId,
            $request->safeValidated()
        );

        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    private function findSubmissionForProof(int $submissionId, int $userId): ?\stdClass
    {
        try {
            return $this->submissionModel->submission_findForProof($submissionId, $userId);
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.proof_submission_unavailable', [
                'submission_id' => $submissionId,
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
            return null;
        }
    }

    /**
     * FIX-M22-MED (T22-20): آمار نوار _earn-nav برای صفحات show/proofForm —
     * قبلاً totalTasks/totalDone هرگز به ویو پاس نمی‌شد و پارشال صفر نشان می‌داد.
     * منابع: totalTasks = Ads::countAvailableCustomTasks (تسک‌های فعالِ در دسترس)،
     * totalDone = CustomTaskAnalyticsModel::analytics_getWorkerDashboard()['submissions']['approved'].
     * @return array{totalTasks: int, totalDone: int}
     */
    private function earnNavStats(int $userId): array
    {
        $totalTasks = 0;
        $totalDone = 0;
        try {
            $totalTasks = $this->adsModel->countAvailableCustomTasks($userId);
            $workerDashboard = $this->analyticsModel->analytics_getWorkerDashboard($userId);
            $subs = is_array($workerDashboard['submissions'] ?? null) ? $workerDashboard['submissions'] : [];
            $totalDone = int_value($subs['approved'] ?? 0);
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.earn_nav_stats_unavailable', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }
        return ['totalTasks' => $totalTasks, 'totalDone' => $totalDone];
    }

    // 📱 FIX-MOBCTR-01 (۲۰۲۶-۱۱-۰۷): storeProofFile / storePrivatePdfProof /
    // storePrivateVideoProof به CustomTaskProofFileService منتقل شدند (تک‌منبع
    // مشترک با کانال API موبایل — هم‌الگوی consolidation تی‌۲۲-۱۸). رفتار عیناً
    // حفظ شده؛ پوشش قبلی M22MedProofChainTest حالا سرویس را مستقیم می‌سنجد.

    /** @return array<string, mixed> */
    private function decodeJsonObject(?string $json): array
    {
        if (!$json) return [];
        $decoded = (array)(json_decode($json, true) ?? []);
        return is_array($decoded) ? $decoded : [];
    }

    // 🧾 FIX-M22-CLOSE (D2-N8): همان هلپر قرارداد FormRequest (RULES §۱۸).

    /**
     * @param array<string, mixed> $errors
     */
    private function firstValidationError(array $errors): string
    {
        $firstValue = reset($errors);
        $firstError = is_array($firstValue) ? reset($firstValue) : $firstValue;

        return is_string($firstError) && $firstError !== '' ? $firstError : 'اطلاعات ارسالی نامعتبر است.';
    }
}
