<?php

namespace App\Controllers\User;

use App\Services\CustomTask\CustomTaskService as CustomTaskCoreService;
use App\Services\CustomTask\CustomTaskExecutorService;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\Analytics\AnalyticsService;
use App\Services\UploadService;
use App\Validators\Requests\CreateCustomTaskRequest;
use App\Validators\Requests\SubmitCustomTaskProofRequest;
use App\Controllers\User\BaseUserController;
use App\Models\Ads;
use App\Services\Settings\AppSettings;
use Core\Logger;

class CustomTaskController extends BaseUserController
{
    private CustomTaskCoreService $coreService;
    private CustomTaskExecutorService $executorService;
    private CustomTaskModerationService $moderationService;
    private AnalyticsService $analyticsService;
    private UploadService $uploadService;
    private Ads $adsModel;
    private AppSettings $appSettings;
    // $logger inherited from parent

    public function __construct(
        CustomTaskCoreService $coreService,
        CustomTaskExecutorService $executorService,
        CustomTaskModerationService $moderationService,
        AnalyticsService $analyticsService,
        UploadService $uploadService,
        Ads $adsModel,
        Logger $logger,
        AppSettings $appSettings
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->coreService = $coreService;
        $this->executorService = $executorService;
        $this->moderationService = $moderationService;
        $this->analyticsService = $analyticsService;
        $this->uploadService = $uploadService;
        $this->adsModel = $adsModel;
        $this->logger = $logger;
        $this->appSettings = $appSettings;
    }

    public function create()
    {
        return view('user.custom-tasks.ad.create', [
            'taskTypes' => $this->adsModel->taskTypes(),
            'proofTypes' => $this->adsModel->proofTypes(),
        ]);
    }

    /**
     * ذخیره تسک جدید - با Request Validation
     */
    public function store()
    {
        $userId = $this->userId();

        $request = new CreateCustomTaskRequest($this->request->all());
        $request->setAppSettings($this->appSettings);

        if (!$request->validate()) {
            $this->session->setFlash('error', 'خطای اعتبارسنجی');
            $this->session->setFlash('errors', $request->errors());
            $this->session->setFlash('old', $this->request->all());
            return redirect(url('/custom-tasks/ad/create'));
        }

        $data = $request->validated();

        $result = $this->coreService->createTask($userId, $data);

        if (!$result['success']) {
            $this->session->setFlash('error', $result['message']);
            $this->session->setFlash('old', $this->request->all());
            return redirect(url('/custom-tasks/ad/create'));
        }

        $this->logger->activity('custom_task.create', 'ثبت وظیفه جدید', $userId, ['task_id' => $result['task']->id ?? null]);
        $this->session->setFlash('success', $result['message']);
        return redirect(url('/custom-tasks'));
    }

    /**
     * ارسال مدرک - با Request Validation
     */
    public function submitProof()
    {
        $userId = $this->userId();
        $subId = (int) $this->request->param('id');

        $request = new SubmitCustomTaskProofRequest($this->request->all());
        if (!$request->validate()) {
            $this->response->json([
                'success' => false,
                'message' => 'خطای اعتبارسنجی',
                'errors' => $request->errors()
            ], 422);
            return;
        }

        $proofData = $request->validated();

        // مدیریت آپلود فایل
        if (!empty($_FILES['proof_file']['name'])) {
            $uploadResult = $this->uploadService->upload($_FILES['proof_file'], 'task-proofs', ['jpg','png','webp','pdf'], 5*1024*1024);
            if ($uploadResult['success']) {
                $proofData['proof_file'] = $uploadResult['path'];
                $proofData['proof_file_hash'] = md5_file(__DIR__ . '/../../../' . $uploadResult['path']) ?? null;
            }
        }

        $result = $this->executorService->submitProof($subId, $userId, $proofData);
        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    /**
     * امتیازدهی - با Request Validation
     */
    public function rateSubmission()
    {
        $userId = $this->userId();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];

        $validator = \Core\Validator::create($body, [
            'submission_id' => 'required|integer|min:1',
            'rating'        => 'required|integer|min:1|max:5',
            'feedback'      => 'nullable|string|min:5|max:1000',
        ]);

        if ($validator->fails()) {
            $this->response->json([
                'success' => false,
                'message' => 'خطای اعتبارسنجی',
                'errors' => $validator->errors()
            ], 422);
            return;
        }

        $result = $this->moderationService->rateSubmission(
            (int)$body['submission_id'],
            $userId,
            $validator->data()
        );

        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    /**
     * Master E2E Functional Verification Specifically for Section 11 Custom Task Bounded Domain Operations 🆕 (CT-01 to CT-07)
     */
    public function verifyCustomTaskSection11(): void
    {
        $db = \Core\Database::getInstance();
        $results = [];
        $salt = random_int(10000, 99999);

        // Helper to setup a test wallet & user
        $setupUser = function(int $userId, float $balanceIrt = 0.0, float $balanceUsdt = 0.0, string $kycStatus = 'verified') use ($db) {
            $db->query("INSERT IGNORE INTO users (id, email, full_name, role, status, kyc_status, created_at) VALUES (?, ?, ?, 'user', 'active', ?, NOW())", [$userId, "user_ct_{$userId}@chortke.ir", "CT User {$userId}", $kycStatus]);
            $db->query("INSERT IGNORE INTO wallets (user_id, balance_irt, balance_usdt) VALUES (?, ?, ?)", [$userId, $balanceIrt, $balanceUsdt]);
            $db->query("UPDATE wallets SET balance_irt = ?, balance_usdt = ? WHERE user_id = ?", [$balanceIrt, $balanceUsdt, $userId]);
        };

        // ─── 1. CT-01 🆕: Create Custom Task -> Ads registered, Escrow hold for amount ───
        $taskObj = null;
        try {
            $u01 = 1101 + $salt;
            $setupUser($u01, 500000.0);

            $res01 = $this->coreService->createTask($u01, [
                'title' => "Special App Signup Task {$salt}",
                'description' => 'Download our application, register and upload your profile screenshot.',
                'link' => 'https://example.com/app',
                'task_type' => 'signup',
                'proof_type' => 'screenshot',
                'price_per_task' => 10000.0,
                'total_quantity' => 10,
                'currency' => 'irt',
                'deadline_hours' => 24,
            ]);

            $taskObj = $res01['task'] ?? null;
            
            // Check escrow transaction
            $escrowObj = $taskObj ? $db->fetch("SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'custom_task_budget' ORDER BY id DESC LIMIT 1", [$taskObj->id]) : false;
            $balAfter01 = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u01])->balance_irt;

            // 10 * 10000 = 100,000 budget + 10% fee (10,000) = 110,000. Initial bal 500,000 -> 390,000
            $passed = (!empty($res01['success'])) && ($taskObj !== null) && ($escrowObj !== false) && ($balAfter01 === 390000.0);
            $results['CT-01'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CT-01 🆕: ایجاد تسک سفارشی (Custom Task Creation & Escrow Hold)',
                'details' => "کارفرما: <code>کاربر #{$u01} (موجودی اولیه: 500,000 IRT)</code><br>عنوان تسک: <code>" . ($taskObj ? $taskObj->title : '') . "</code><br>بودجه کل با کارمزد سایت (۱۰٪): <code>110,000 IRT</code><br>وضعیت در جدول ads: <code>" . ($taskObj ? "ثبت موفق با شناسه #{$taskObj->id} و وضعیت {$taskObj->status}" : 'ناموفق') . "</code><br>موجودی کارفرما پس از کسر و قفل در صندوق امانی: <code>" . number_format($balAfter01) . " IRT</code><br>صندوق امانی (Escrow): <code>" . ($escrowObj ? "قفل موفق مبلغ {$escrowObj->amount} با وضعیت {$escrowObj->status}" : 'یافت نشد') . "</code>",
                'message' => $passed ? 'موفق: تسک سفارشی در جدول ads ثبت و کل مبلغ بودجه و کارمزد در صندوق امانی (Escrow) قفل شد.' : 'خطا در ثبت تسک یا قفل Escrow.'
            ];
        } catch (\Throwable $e) {
            $results['CT-01'] = ['status' => 'FAILED', 'title' => 'CT-01 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 2. CT-02 🆕: Worker sends submission -> CustomTaskSubmission stored ───
        try {
            $u02_Worker = 1102 + $salt;
            $setupUser($u02_Worker);

            $res02_Start = $this->executorService->startTask((int)($taskObj ? $taskObj->id : 1), $u02_Worker);
            $subId02 = (int)($res02_Start['submission_id'] ?? 0);

            // Execute submitProof
            $res02_Submit = $this->executorService->submitProof($subId02, $u02_Worker, [
                'proof_text' => 'Done exactly as requested!',
                'proof_file' => 'uploads/ct_proof.png',
                'idempotency_key' => 'ct_proof_' . uniqid(),
            ]);

            $subObj02 = $db->fetch("SELECT * FROM custom_task_submissions WHERE id = ? LIMIT 1", [$subId02]);

            $passed = (!empty($res02_Submit['success'])) && ($subObj02 !== false) && ($subObj02->status === 'submitted');
            $results['CT-02'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CT-02 🆕: ارسال نتیجه تسک توسط مجری (Custom Task Submission)',
                'details' => "مجری (Worker): <code>کاربر #{$u02_Worker}</code><br>شناسه درخواست (Submission ID): <code>#{$subId02}</code><br>متن مدرک: <code>" . ($subObj02 ? $subObj02->proof_text : '') . "</code><br>وضعیت رکورد در جدول custom_task_submissions: <code>" . ($subObj02 ? "ثبت موفق با شناسه #{$subObj02->id} و وضعیت {$subObj02->status}" : 'یافت نشد') . "</code>",
                'message' => $passed ? 'موفق: نتیجهٔ تسک (Submission) به طور کامل و صحیح در جدول custom_task_submissions ذخیره شد.' : 'خطا در ثبت Submission.'
            ];
        } catch (\Throwable $e) {
            $results['CT-02'] = ['status' => 'FAILED', 'title' => 'CT-02 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 3. CT-03 🆕: Employer approves submission -> Escrow payout, RatingService active ───
        try {
            $u03_Employer = 1103 + $salt;
            $u03_Worker = 1104 + $salt;
            $setupUser($u03_Employer, 500000.0);
            $setupUser($u03_Worker, 1000.0);

            // Create task
            $res03_Task = $this->coreService->createTask($u03_Employer, [
                'title' => "Task For Payout Audit {$salt}",
                'description' => 'A rigorous task for verifying escrow rewards release.',
                'price_per_task' => 20000.0,
                'total_quantity' => 1,
                'currency' => 'irt',
            ]);
            $t03Obj = $res03_Task['task'] ?? null;
            $escrow03Obj = $t03Obj ? $db->fetch("SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'custom_task_budget' LIMIT 1", [$t03Obj->id]) : false;

            // Start & Submit
            $res03_Start = $this->executorService->startTask((int)($t03Obj ? $t03Obj->id : 1), $u03_Worker);
            $subId03 = (int)($res03_Start['submission_id'] ?? 0);
            $this->executorService->submitProof($subId03, $u03_Worker, [
                'proof_text' => 'Execution proof complete audit.',
                'idempotency_key' => 'ct_proof_' . time(),
            ]);

            // Approve Submission
            $res03_Approve = $this->moderationService->reviewSubmission($subId03, $u03_Employer, 'approve');

            // Rate Submission
            $res03_Rate = $this->moderationService->rateSubmission($subId03, $u03_Employer, [
                'rating' => 5,
                'review_text' => 'Outstanding execution and lightning fast delivery!',
            ]);

            $balWorkerFinal = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u03_Worker])->balance_irt;
            $subFinal03 = $db->fetch("SELECT * FROM custom_task_submissions WHERE id = ? LIMIT 1", [$subId03]);

            // 1000 initial + 20000 reward = 21000
            $passed = (!empty($res03_Approve['success'])) && (!empty($res03_Rate['success'])) && ($balWorkerFinal === 21000.0) && ($subFinal03->status === 'approved');
            $results['CT-03'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CT-03 🆕: تأیید نتیجه تسک توسط آگهی‌دهنده (Submission Approval & Escrow Payout)',
                'details' => "شناسه تسک: <code>" . ($t03Obj ? "#{$t03Obj->id}" : '') . "</code> | شناسه ارسال (Submission ID): <code>#{$subId03}</code><br>پاداش مجری: <code>20,000 IRT</code><br>نتیجه تسویه صندوق امانی (Escrow Center): <code>کسر دقیق وجه پاداش از بافر Escrow</code><br>وضعیت بروزشده Submission در دیتابیس: <code>" . ($subFinal03 ? "{$subFinal03->status} (تأیید شده)" : '') . "</code><br>موجودی نهایی کیف پول مجری: <code>" . number_format($balWorkerFinal) . " IRT (واریز دقیق پاداش از Escrow)</code><br>وضعیت سیستم امتیازدهی (Rating Service): <code>فعال و ثبت موفق ۵ ستاره</code>",
                'message' => $passed ? 'موفق: با تأیید کارفرما، مبلغ پاداش از صندوق امانی (Escrow) آزاد و به مجری پرداخت شد و RatingService به طور کامل فعال گردید.' : 'خطا در تسویه Escrow یا RatingService.'
            ];
        } catch (\Throwable $e) {
            $results['CT-03'] = ['status' => 'FAILED', 'title' => 'CT-03 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 4. CT-04 🆕: Reject submission -> Escrow funds remain unchanged ───
        try {
            $u04_Employer = 1105 + $salt;
            $u04_Worker = 1106 + $salt;
            $setupUser($u04_Employer, 500000.0);
            $setupUser($u04_Worker, 1000.0);

            // Create task
            $res04_Task = $this->coreService->createTask($u04_Employer, [
                'title' => "Task For Rejection Audit {$salt}",
                'description' => 'A strict task for verifying escrow hold freeze upon rejection.',
                'price_per_task' => 25000.0,
                'total_quantity' => 1,
                'currency' => 'irt',
            ]);
            $t04Obj = $res04_Task['task'] ?? null;
            $escrow04Obj = $t04Obj ? $db->fetch("SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'custom_task_budget' LIMIT 1", [$t04Obj->id]) : false;
            $escrowAmountBefore04 = $escrow04Obj ? (float)$escrow04Obj->amount : 0.0;

            // Start & Submit
            $res04_Start = $this->executorService->startTask((int)($t04Obj ? $t04Obj->id : 1), $u04_Worker);
            $subId04 = (int)($res04_Start['submission_id'] ?? 0);
            $this->executorService->submitProof($subId04, $u04_Worker, [
                'proof_text' => 'Execution proof flawed audit.',
                'idempotency_key' => 'ct_proof_' . time(),
            ]);

            // Reject Submission
            $res04_Reject = $this->moderationService->reviewSubmission($subId04, $u04_Employer, 'reject', 'کیفیت اسکرین‌شات ارسالی بسیار پایین است');

            $balWorkerFinal04 = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u04_Worker])->balance_irt;
            $escrowFinal04 = $escrow04Obj ? $db->fetch("SELECT * FROM escrow_transactions WHERE id = ? LIMIT 1", [$escrow04Obj->id]) : false;
            $subFinal04 = $db->fetch("SELECT * FROM custom_task_submissions WHERE id = ? LIMIT 1", [$subId04]);

            $passed = (!empty($res04_Reject['success'])) && ($balWorkerFinal04 === 1000.0) && ($escrowFinal04 && (float)$escrowFinal04->amount === $escrowAmountBefore04) && ($subFinal04 && $subFinal04->status === 'rejected');
            $results['CT-04'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CT-04 🆕: رد نتیجه تسک توسط آگهی‌دهنده (Submission Rejection & Hold Freeze)',
                'details' => "شناسه تسک: <code>" . ($t04Obj ? "#{$t04Obj->id}" : '') . "</code> | شناسه ارسال (Submission ID): <code>#{$subId04}</code><br>دلیل رد کارفرما: <code>" . ($subFinal04 ? $subFinal04->rejection_reason : '') . "</code><br>وضعیت بروزشده Submission در دیتابیس: <code>" . ($subFinal04 ? "{$subFinal04->status} (رد شده)" : '') . "</code><br>موجودی صندوق امانی (Escrow Center): <code>" . ($escrowFinal04 ? number_format((float)$escrowFinal04->amount) : '') . " IRT (کاملاً ثابت و بدون کسر)</code><br>موجودی کیف پول مجری: <code>" . number_format($balWorkerFinal04) . " IRT (بدون تغییر)</code>",
                'message' => $passed ? 'موفق: با رد نتیجهٔ تسک توسط کارفرما، موجودی صندوق امانی (Escrow Center) دقیقاً ثابت باقی ماند و وجهی کسر نشد.' : 'خطا در ثبات وجه Escrow.'
            ];
        } catch (\Throwable $e) {
            $results['CT-04'] = ['status' => 'FAILED', 'title' => 'CT-04 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 5. CT-05 🆕: CustomTaskModerationService moderation -> Inappropriate content rejected ───
        try {
            $res05_Scam = $this->moderationService->moderateContent('این یک تسک سرمایه‌گذاری با سود قطعی و اسکم است.');
            $res05_Clean = $this->moderationService->moderateContent('تسک عضویت در خبرنامه رسمی و معتبر ما.');

            $passed = (empty($res05_Scam['allowed'])) && (!empty($res05_Clean['allowed'])) && str_contains($res05_Scam['reason'] ?? '', 'نامناسب');
            $results['CT-05'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CT-05 🆕: نظارت خودکار بر محتوای تسک‌ها (CustomTaskModerationService Moderation)',
                'details' => "متن ورودی مشکوک: <code>این یک تسک سرمایه‌گذاری با سود قطعی و اسکم است.</code><br>خروجی هوش مصنوعی ممیزی: <code>" . ($res05_Scam['reason'] ?? 'تأیید') . "</code><br>متن ورودی سالم: <code>تسک عضویت در خبرنامه رسمی و معتبر ما.</code> | خروجی ممیزی: <code>" . (!empty($res05_Clean['allowed']) ? 'مجاز و تأیید (Allowed)' : 'مسدود') . "</code>",
                'message' => $passed ? 'موفق: سرویس خودکار ممیزی (CustomTaskModerationService) محتوای نامناسب و ممنوعه را فوراً شناسایی و مسدود کرد.' : 'خطا در فیلترینگ محتوا.'
            ];
        } catch (\Throwable $e) {
            $results['CT-05'] = ['status' => 'FAILED', 'title' => 'CT-05 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 6. CT-06 🆕: Create task by unverified user -> If KYC required, rejected ───
        try {
            $u06_Unverified = 1108 + $salt;
            $setupUser($u06_Unverified, 500000.0, 0.0, 'unverified');

            $this->appSettings->set('custom_task_kyc_required', 1);

            $res06 = $this->coreService->createTask($u06_Unverified, [
                'title' => 'Unverified User Task Audit',
                'description' => 'A task created by a user who has not submitted KYC verification documents.',
                'price_per_task' => 10000.0,
                'total_quantity' => 5,
            ]);

            $passed = (empty($res06['success'])) && str_contains($res06['message'] ?? '', 'KYC');
            $results['CT-06'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CT-06 🆕: ممانعت از ایجاد تسک توسط کاربران احراز هویت‌نشده (KYC Guard)',
                'details' => "شناسه کاربر: <code>کاربر #{$u06_Unverified}</code><br>وضعیت احراز هویت (KYC Status): <code>تأیید نشده (Unverified)</code><br>پاسخ گیت امنیتی لایه تسک‌ها: <code>" . ($res06['message'] ?? 'مجاز') . "</code>",
                'message' => $passed ? 'موفق: سیستم بر اساس الزامات KYC، درخواست ایجاد تسک توسط کاربر احراز هویت‌نشده را مسدود کرد.' : 'خطا در مهار KYC.'
            ];
        } catch (\Throwable $e) {
            $results['CT-06'] = ['status' => 'FAILED', 'title' => 'CT-06 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 7. CT-07 🆕: Search integration -> Backfill & SearchProjection work correctly ───
        try {
            // First run backfill job helper specifically for ads
            $backfillJob = \Core\Container::getInstance()->make(\App\Jobs\BackfillSearchProjectionJob::class);
            $backfillJob->handle(['source' => 'ads', 'batch_size' => 50]);

            // Execute search
            $searchRes = $this->coreService->quickSearchAds($taskObj ? $taskObj->title : '');

            $projRecord = $taskObj ? $db->fetch("SELECT * FROM search_projections WHERE entity_type = 'ad' AND entity_id = ? LIMIT 1", [$taskObj->id]) : false;

            $passed = (!empty($searchRes)) && ($projRecord !== false) && ($projRecord->title === ($taskObj ? $taskObj->title : ''));
            $results['CT-07'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CT-07 🆕: یکپارچه‌سازی و پرکردن پایگاه داده جستجو (Search Integration & Backfill)',
                'details' => "شناسه تسک مرجع: <code>" . ($taskObj ? "#{$taskObj->id} («{$taskObj->title}»)" : 'نامعلوم') . "</code><br>عملیات موتور BackfillSearchProjectionJob: <code>انتقال و ساخت موفق رکوردهای Read-Model در جدول search_projections</code><br>رکورد Projection ساخته شده: <code>" . ($projRecord ? "شناسه #{$projRecord->id} با عنوان {$projRecord->title}" : 'یافت نشد') . "</code><br>نتیجه جستجوی بلادرنگ (Search Orchestrator): <code>" . (!empty($searchRes) ? "پیدا شدن موفق تسک با تطابق کامل" : 'ناموفق') . "</code>",
                'message' => $passed ? 'موفق: مکانیزم Backfill و SearchProjection عملکردی کاملاً هماهنگ داشته و تسک سفارشی با موفقیت در موتور جستجو ایندکس و پیدا شد.' : 'خطا در موتور جستجو یا Backfill.'
            ];
        } catch (\Throwable $e) {
            $results['CT-07'] = ['status' => 'FAILED', 'title' => 'CT-07 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── Render View ───
        $this->view('user/custom-tasks/index', [
            'title'   => 'ارزیابی حرفه‌ای و مرورگرمحور لایه وظایف سفارشی (Section 11 Custom Task Master Verification 🆕 ⭐)',
            'results' => $results,
        ]);
    }
}
