<?php

namespace App\Controllers\User;

use App\Services\CustomTask\CustomTaskExecutorService;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\Analytics\AnalyticsService;
use App\Services\UploadService;
use App\Validators\Requests\SubmitCustomTaskProofRequest;
use App\Controllers\User\BaseUserController;
use Core\Logger;

/**
 * CustomTaskController — Executor-only controller.
 *
 * NOTE: Advertiser management (create, pause, stats, list) is unified under /ads (AdsController).
 * This controller only handles the worker side: submission, rating, and proof upload.
 */
class CustomTaskController extends BaseUserController
{
    private CustomTaskExecutorService $executorService;
    private CustomTaskModerationService $moderationService;
    private AnalyticsService $analyticsService;
    private UploadService $uploadService;

    public function __construct(
        CustomTaskExecutorService $executorService,
        CustomTaskModerationService $moderationService,
        AnalyticsService $analyticsService,
        UploadService $uploadService,
        Logger $logger
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->executorService = $executorService;
        $this->moderationService = $moderationService;
        $this->analyticsService = $analyticsService;
        $this->uploadService = $uploadService;
    }

    public function index(): void
    {
        $this->available();
    }

    public function available(): void
    {
        // Worker-side custom tasks are now part of the unified task marketplace.
        $this->response->redirect(url('/tasks?type=custom_task'));
    }

    public function mySubmissions(): void
    {
        $userId = (int)$this->userId();
        $submissions = [];
        try {
            $db = \Core\Container::getInstance()->make(\Core\Database::class);
            $submissions = $db->fetchAll(
                "SELECT s.*, a.title AS task_title, a.description AS task_description
                 FROM custom_task_submissions s
                 LEFT JOIN ads a ON a.id = s.task_id
                 WHERE s.worker_id = ?
                 ORDER BY s.created_at DESC
                 LIMIT 100",
                [$userId]
            ) ?: [];
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.my_submissions_unavailable', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        $this->view('user/custom-tasks/executor/my-submissions', [
            'submissions' => $submissions,
            'title' => 'اجراهای تسک سفارشی من',
        ]);
    }

    public function show(): void
    {
        $taskId = (int)$this->request->param('id');
        $task = null;
        try {
            $task = \Core\Container::getInstance()->make(\App\Models\Ads::class)->find($taskId);
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.show_unavailable', ['task_id' => $taskId, 'error' => $e->getMessage()]);
        }

        if (!$task) {
            $this->session->setFlash('error', 'تسک مورد نظر یافت نشد.');
            $this->response->redirect(url('/tasks?type=custom_task'));
            return;
        }

        $this->view('user/custom-tasks/show', [
            'task' => $task,
            'title' => $task->title ?? 'جزئیات تسک سفارشی',
        ]);
    }

    public function start(): void
    {
        $taskId = (int)($this->request->param('id') ?: ($this->request->input('task_id') ?? $this->request->input('id') ?? 0));
        $userId = (int)$this->userId();
        if ($taskId <= 0) {
            $this->response->json(['success' => false, 'message' => 'شناسه تسک نامعتبر است.'], 422);
            return;
        }
        $result = $this->executorService->startTask($taskId, $userId);
        if (!empty($result['success']) && !empty($result['submission_id'])) {
            $result['redirect_url'] = url('/custom-tasks/submissions/' . (int)$result['submission_id'] . '/proof');
            $result['message'] = $result['message'] ?? 'تسک شروع شد؛ اکنون مدرک انجام را ارسال کنید.';
        }
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    public function proofForm(): void
    {
        $submissionId = (int)$this->request->param('id');
        $userId = (int)$this->userId();
        $submission = $this->findSubmissionForProof($submissionId, $userId);

        if (!$submission) {
            $this->session->setFlash('error', 'اجرای تسک سفارشی یافت نشد.');
            $this->response->redirect(url('/custom-tasks/my-submissions'));
            return;
        }

        $this->view('user/custom-tasks/proof', [
            'submission' => $submission,
            'title' => 'ارسال مدرک تسک سفارشی',
        ]);
    }

    public function disputes(): void
    {
        $userId = (int)$this->userId();
        $items = [];
        try {
            $db = \Core\Container::getInstance()->make(\Core\Database::class);
            $items = $db->fetchAll(
                "SELECT d.*, a.title AS task_title, s.status AS submission_status, u.full_name AS other_party_name
                 FROM disputes d
                 INNER JOIN custom_task_submissions s ON s.id = d.ref_id AND d.ref_type = 'custom_task_submission'
                 LEFT JOIN ads a ON a.id = s.task_id
                 LEFT JOIN users u ON u.id = d.target_user_id
                 WHERE d.user_id = ? OR d.target_user_id = ?
                 ORDER BY d.created_at DESC
                 LIMIT 100",
                [$userId, $userId]
            ) ?: [];
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.disputes_unavailable', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        $this->view('user/custom-tasks/executor/disputes', [
            'items' => $items,
            'disputes' => $items,
            'title' => 'اختلافات تسک‌های سفارشی',
        ]);
    }

    public function storeDispute(): void
    {
        $userId = (int)$this->userId();
        $submissionId = (int)$this->request->param('id');
        $reason = trim((string)($this->request->input('reason') ?? $this->request->input('message') ?? ''));
        $wantsJson = $this->wantsJson();
        if ($submissionId <= 0 || mb_strlen($reason) < 10) {
            $this->finishDisputeResponse(false, 'دلیل اختلاف باید حداقل ۱۰ کاراکتر باشد.', null, 422, $wantsJson);
            return;
        }

        try {
            $db = \Core\Container::getInstance()->make(\Core\Database::class);
            $submission = $db->fetch(
                "SELECT s.*, a.user_id AS advertiser_id, a.title AS task_title
                 FROM custom_task_submissions s
                 LEFT JOIN ads a ON a.id = s.task_id
                 WHERE s.id = ? AND s.worker_id = ?
                 LIMIT 1",
                [$submissionId, $userId]
            );
            if (!$submission) {
                $this->finishDisputeResponse(false, 'ارسال/اجرای تسک یافت نشد.', null, 404, $wantsJson);
                return;
            }
            if (!in_array((string)$submission->status, ['rejected'], true)) {
                $this->finishDisputeResponse(false, 'اختلاف فقط پس از رد شدن مدرک قابل ثبت است.', null, 422, $wantsJson);
                return;
            }
            $existing = $db->fetch(
                "SELECT id FROM disputes WHERE ref_type = 'custom_task_submission' AND ref_id = ? AND status IN ('open','open_peer','under_review','escalated') LIMIT 1",
                [$submissionId]
            );
            if ($existing) {
                $this->finishDisputeResponse(false, 'برای این ارسال، اختلاف باز وجود دارد.', (int)$existing->id, 422, $wantsJson);
                return;
            }

            $db->beginTransaction();
            $disputeId = (int)$db->insert(
                "INSERT INTO disputes (ref_type, ref_id, user_id, target_user_id, status, reason, role, peer_deadline, created_at, updated_at)
                 VALUES ('custom_task_submission', ?, ?, ?, 'open', ?, 'worker', DATE_ADD(NOW(), INTERVAL 48 HOUR), NOW(), NOW())",
                [$submissionId, $userId, (int)$submission->advertiser_id, $reason]
            );
            $db->query(
                "INSERT INTO dispute_messages (dispute_id, user_id, role, message, created_at) VALUES (?, ?, 'worker', ?, NOW())",
                [$disputeId, $userId, $reason]
            );
            $db->query(
                "UPDATE custom_task_submissions SET status = 'disputed', dispute_id = ?, updated_at = NOW() WHERE id = ?",
                [$disputeId, $submissionId]
            );
            $db->commit();

            $this->finishDisputeResponse(true, 'اختلاف ثبت شد و برای بررسی ارسال شد.', $disputeId, 200, $wantsJson);
        } catch (\Throwable $e) {
            try { if (isset($db) && $db->inTransaction()) $db->rollBack(); } catch (\Throwable) {}
            $this->logger->error('custom_tasks.dispute_create_failed', ['submission_id' => $submissionId, 'user_id' => $userId, 'error' => $e->getMessage()]);
            $this->finishDisputeResponse(false, 'ثبت اختلاف انجام نشد.', null, 500, $wantsJson);
        }
    }

    public function disputeDetail(): void
    {
        $disputeId = (int)$this->request->param('id');
        $userId = (int)$this->userId();
        $db = \Core\Container::getInstance()->make(\Core\Database::class);
        $dispute = $db->fetch(
            "SELECT d.*, s.id AS submission_id, s.status AS submission_status, s.reward_amount, s.reward_currency,
                    s.proof_text, s.proof_url, s.proof_code, s.proof_file, s.rejection_reason,
                    a.title AS task_title, a.description AS task_description, a.user_id AS advertiser_id,
                    w.full_name AS worker_name, adv.full_name AS advertiser_name
             FROM disputes d
             INNER JOIN custom_task_submissions s ON s.id = d.ref_id AND d.ref_type = 'custom_task_submission'
             LEFT JOIN ads a ON a.id = s.task_id
             LEFT JOIN users w ON w.id = s.worker_id
             LEFT JOIN users adv ON adv.id = a.user_id
             WHERE d.id = ? AND (d.user_id = ? OR d.target_user_id = ?)
             LIMIT 1",
            [$disputeId, $userId, $userId]
        );
        if (!$dispute) {
            $this->session->setFlash('error', 'پرونده اختلاف یافت نشد یا دسترسی ندارید.');
            $this->response->redirect(url('/custom-tasks/disputes-list'));
            return;
        }
        $messages = $db->fetchAll(
            "SELECT m.*, u.full_name AS sender_name
             FROM dispute_messages m
             LEFT JOIN users u ON u.id = m.user_id
             WHERE m.dispute_id = ? ORDER BY m.created_at ASC",
            [$disputeId]
        ) ?: [];
        $this->view('user/custom-tasks/executor/dispute-detail', [
            'dispute' => $dispute,
            'messages' => $messages,
            'title' => 'جزئیات اختلاف تسک سفارشی',
        ]);
    }

    public function replyDispute(): void
    {
        $disputeId = (int)$this->request->param('id');
        $userId = (int)$this->userId();
        $message = trim((string)$this->request->input('message', ''));
        if (mb_strlen($message) < 2) {
            $this->session->setFlash('error', 'متن پیام الزامی است.');
            $this->response->redirect(url('/custom-tasks/disputes/' . $disputeId));
            return;
        }
        $db = \Core\Container::getInstance()->make(\Core\Database::class);
        $dispute = $db->fetch(
            "SELECT d.*, s.worker_id, a.user_id AS advertiser_id
             FROM disputes d
             INNER JOIN custom_task_submissions s ON s.id = d.ref_id AND d.ref_type = 'custom_task_submission'
             LEFT JOIN ads a ON a.id = s.task_id
             WHERE d.id = ? AND (d.user_id = ? OR d.target_user_id = ?)
             LIMIT 1",
            [$disputeId, $userId, $userId]
        );
        if (!$dispute || in_array((string)$dispute->status, ['resolved_for_executor','resolved_for_advertiser','resolved_admin','closed'], true)) {
            $this->session->setFlash('error', 'امکان ارسال پیام برای این پرونده وجود ندارد.');
            $this->response->redirect(url('/custom-tasks/disputes-list'));
            return;
        }
        $role = ((int)$dispute->worker_id === $userId) ? 'worker' : 'advertiser';
        $db->query(
            "INSERT INTO dispute_messages (dispute_id, user_id, role, message, created_at) VALUES (?, ?, ?, ?, NOW())",
            [$disputeId, $userId, $role, $message]
        );
        $db->query("UPDATE disputes SET status = CASE WHEN status = 'open' THEN 'under_review' ELSE status END, updated_at = NOW() WHERE id = ?", [$disputeId]);
        $this->session->setFlash('success', 'پیام شما ثبت شد.');
        $this->response->redirect(url('/custom-tasks/disputes/' . $disputeId));
    }

    public function review(): void
    {
        $this->response->json(['success' => false, 'message' => 'بررسی ارسال‌ها از پنل تبلیغ‌دهنده انجام می‌شود.'], 422);
    }

    /**
     * ارسال مدرک - schema-based validation per proof_type.
     */
    public function submitProof(): void
    {
        $userId = (int)$this->userId();
        $subId = (int)$this->request->param('id');
        $submission = $this->findSubmissionForProof($subId, $userId);

        if (!$submission) {
            $this->response->json(['success' => false, 'message' => 'اجرای تسک سفارشی یافت نشد.'], 404);
            return;
        }
        if ((string)$submission->status !== 'in_progress') {
            $this->response->json(['success' => false, 'message' => 'این اجرا در وضعیت قابل ارسال مدرک نیست.'], 422);
            return;
        }

        $payload = $this->request->all();
        $payload['task_execution_id'] = $subId;
        if (empty($payload['idempotency_key'])) {
            $payload['idempotency_key'] = 'CUSTOM_' . $userId . '_' . $subId . '_' . bin2hex(random_bytes(8));
        }

        $proofType = $this->normalizeProofType((string)($submission->proof_type ?? 'text'));
        $fileRequired = in_array($proofType, ['screenshot', 'file'], true);
        $hasProofFile = !empty($_FILES['proof_file']['name']);

        if ($fileRequired && !$hasProofFile) {
            $this->response->json(['success' => false, 'message' => $proofType === 'screenshot' ? 'برای این تسک، اسکرین‌شات الزامی است.' : 'برای این تسک، فایل مدرک الزامی است.'], 422);
            return;
        }

        if ($hasProofFile) {
            try {
                $uploadResult = $this->storeProofFile($_FILES['proof_file'], $proofType);
                $payload['proof_file'] = $uploadResult['path'];
                $payload['proof_file_hash'] = $uploadResult['hash'];
            } catch (\Throwable $e) {
                $this->response->json(['success' => false, 'message' => $e->getMessage()], 422);
                return;
            }
        }

        $schemaError = $this->validateProofSchema($proofType, $payload);
        if ($schemaError !== null) {
            $this->response->json(['success' => false, 'message' => $schemaError], 422);
            return;
        }

        $payload['proof_data'] = json_encode([
            'proof_type' => $proofType,
            'proof_schema' => $this->decodeJsonObject($submission->proof_schema ?? null),
            'submitted_fields' => [
                'proof_text' => trim((string)($payload['proof_text'] ?? '')) !== '',
                'proof_url' => trim((string)($payload['proof_url'] ?? '')) !== '',
                'proof_code' => trim((string)($payload['proof_code'] ?? '')) !== '',
                'proof_file' => !empty($payload['proof_file']),
            ],
        ], JSON_UNESCAPED_UNICODE);

        $request = new SubmitCustomTaskProofRequest($payload);
        if (!$request->validate()) {
            $this->response->json([
                'success' => false,
                'message' => 'خطای اعتبارسنجی',
                'errors' => $request->errors(),
            ], 422);
            return;
        }

        $proofData = array_merge($payload, $request->validated());
        $result = $this->executorService->submitProof($subId, $userId, $proofData);
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }


    private function wantsJson(): bool
    {
        $accept = strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? ''));
        $xhr = strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''));
        return str_contains($accept, 'application/json') || $xhr === 'xmlhttprequest';
    }

    private function finishDisputeResponse(bool $success, string $message, ?int $disputeId, int $status, bool $json): void
    {
        if ($json) {
            $this->response->json(['success' => $success, 'message' => $message, 'dispute_id' => $disputeId], $status);
            return;
        }
        $this->session->setFlash($success ? 'success' : 'error', $message);
        $this->response->redirect($success && $disputeId ? url('/custom-tasks/disputes/' . $disputeId) : url('/custom-tasks/my-submissions'));
    }

    /**
     * امتیازدهی - با Request Validation
     */
    public function rateSubmission(): void
    {
        $userId = $this->userId();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];

        $validator = \Core\Validator::create($body, [
            'submission_id' => 'required|integer|min:1',
            'rating'        => 'required|integer|min:1|max:5',
            'feedback'      => 'nullable|string|min:5|max:1000',
        ]);

        if ($validator->fails()) {
            $this->response->json([
                'success' => false,
                'message' => 'خطای اعتبارسنجی',
                'errors' => $validator->errors(),
            ], 422);
            return;
        }

        $result = $this->moderationService->rateSubmission(
            (int)$body['submission_id'],
            $userId,
            $validator->data()
        );

        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    private function findSubmissionForProof(int $submissionId, int $userId): ?object
    {
        try {
            $db = \Core\Container::getInstance()->make(\Core\Database::class);
            return $db->fetch(
                "SELECT s.*, a.title AS task_title, a.description AS task_description,
                        a.proof_type, a.proof_description, a.proof_schema, a.price_per_task,
                        a.currency, a.user_id AS advertiser_id
                 FROM custom_task_submissions s
                 LEFT JOIN ads a ON a.id = s.task_id
                 WHERE s.id = ? AND s.worker_id = ?
                 LIMIT 1",
                [$submissionId, $userId]
            ) ?: null;
        } catch (\Throwable $e) {
            $this->logger->warning('custom_tasks.proof_submission_unavailable', [
                'submission_id' => $submissionId,
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
            return null;
        }
    }

    private function normalizeProofType(string $type): string
    {
        $type = strtolower(trim($type));
        return match ($type) {
            'link' => 'url',
            'image' => 'screenshot',
            default => in_array($type, ['text', 'code', 'url', 'screenshot', 'file', 'video'], true) ? $type : 'text',
        };
    }

    private function validateProofSchema(string $proofType, array $payload): ?string
    {
        $text = trim((string)($payload['proof_text'] ?? ''));
        $url = trim((string)($payload['proof_url'] ?? ''));
        $code = trim((string)($payload['proof_code'] ?? ''));
        $file = trim((string)($payload['proof_file'] ?? ''));

        return match ($proofType) {
            'text' => mb_strlen($text) >= 10 ? null : 'برای این تسک، توضیح متنی حداقل ۱۰ کاراکتر الزامی است.',
            'code' => mb_strlen($code) >= 2 ? null : 'برای این تسک، کد یا شناسه مدرک الزامی است.',
            'url' => filter_var($url, FILTER_VALIDATE_URL) ? null : 'برای این تسک، لینک مدرک معتبر الزامی است.',
            'screenshot' => $file !== '' ? null : 'برای این تسک، اسکرین‌شات الزامی است.',
            'file' => $file !== '' ? null : 'برای این تسک، فایل مدرک الزامی است.',
            'video' => (filter_var($url, FILTER_VALIDATE_URL) || $file !== '') ? null : 'برای مدرک ویدیویی، لینک معتبر یا فایل ویدیو الزامی است.',
            default => ($text !== '' || $url !== '' || $code !== '' || $file !== '') ? null : 'مدرک انجام تسک الزامی است.',
        };
    }

    private function storeProofFile(array $file, string $proofType): array
    {
        $original = (string)($file['name'] ?? 'proof');
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $isPdf = $ext === 'pdf';

        if ($proofType === 'video') {
            return $this->storePrivateVideoProof($file);
        }

        if ($proofType === 'screenshot' && $isPdf) {
            throw new \RuntimeException('برای اسکرین‌شات فقط تصویر مجاز است.');
        }

        if ($isPdf) {
            return $this->storePrivatePdfProof($file);
        }

        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $uploadResult = $this->uploadService->upload($file, 'task-proofs', $allowed, 5 * 1024 * 1024);
        $path = (string)$uploadResult['path'];
        $realPath = $this->uploadService->getPath($path);
        return [
            'path' => $path,
            'hash' => $realPath && is_file($realPath) ? hash_file('sha256', $realPath) : null,
        ];
    }

    private function storePrivatePdfProof(array $file): array
    {
        $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err !== UPLOAD_ERR_OK) {
            throw new \RuntimeException('خطا در آپلود فایل مدرک.');
        }
        $tmp = (string)($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            throw new \RuntimeException('فایل موقت مدرک نامعتبر است.');
        }
        $size = max((int)($file['size'] ?? 0), (int)@filesize($tmp));
        if ($size <= 0 || $size > 5 * 1024 * 1024) {
            throw new \RuntimeException('حجم فایل PDF باید کمتر از ۵ مگابایت باشد.');
        }
        $header = (string)@file_get_contents($tmp, false, null, 0, 5);
        if (!str_starts_with($header, '%PDF-')) {
            throw new \RuntimeException('فایل PDF معتبر نیست.');
        }
        $root = realpath(__DIR__ . '/../../../') ?: (__DIR__ . '/../../../');
        $dir = rtrim($root, '/\\') . '/storage/uploads/task-proofs/';
        if (!is_dir($dir) && !mkdir($dir, 0750, true)) {
            throw new \RuntimeException('خطا در ایجاد پوشه مدرک.');
        }
        $filename = bin2hex(random_bytes(12)) . '.pdf';
        $dest = $dir . $filename;
        if (!move_uploaded_file($tmp, $dest)) {
            throw new \RuntimeException('خطا در ذخیره PDF مدرک.');
        }
        chmod($dest, 0640);
        return [
            'path' => 'task-proofs/' . $filename,
            'hash' => hash_file('sha256', $dest),
        ];
    }


    private function storePrivateVideoProof(array $file): array
    {
        $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err !== UPLOAD_ERR_OK) {
            throw new \RuntimeException('خطا در آپلود ویدیو مدرک.');
        }
        $tmp = (string)($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            throw new \RuntimeException('فایل موقت ویدیو نامعتبر است.');
        }
        $size = max((int)($file['size'] ?? 0), (int)@filesize($tmp));
        $max = 30 * 1024 * 1024;
        if ($size <= 0 || $size > $max) {
            throw new \RuntimeException('حجم ویدیو باید کمتر از ۳۰ مگابایت باشد.');
        }
        $original = strtolower((string)($file['name'] ?? 'video'));
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $allowedExt = ['mp4', 'webm', 'mov'];
        if (!in_array($ext, $allowedExt, true)) {
            throw new \RuntimeException('فرمت ویدیو باید mp4، webm یا mov باشد.');
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = (string)finfo_file($finfo, $tmp);
        finfo_close($finfo);
        $allowedMime = ['video/mp4', 'video/webm', 'video/quicktime', 'application/octet-stream'];
        if (!in_array($mime, $allowedMime, true)) {
            throw new \RuntimeException('نوع فایل ویدیو معتبر نیست.');
        }
        $root = realpath(__DIR__ . '/../../../') ?: (__DIR__ . '/../../../');
        $dir = rtrim($root, '/\\') . '/storage/uploads/task-proofs/';
        if (!is_dir($dir) && !mkdir($dir, 0750, true)) {
            throw new \RuntimeException('خطا در ایجاد پوشه ویدیو مدرک.');
        }
        $filename = bin2hex(random_bytes(12)) . '.' . $ext;
        $dest = $dir . $filename;
        if (!move_uploaded_file($tmp, $dest)) {
            throw new \RuntimeException('خطا در ذخیره ویدیو مدرک.');
        }
        chmod($dest, 0640);
        return [
            'path' => 'task-proofs/' . $filename,
            'hash' => hash_file('sha256', $dest),
        ];
    }

    private function decodeJsonObject(?string $json): array
    {
        if (!$json) return [];
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : [];
    }
}
