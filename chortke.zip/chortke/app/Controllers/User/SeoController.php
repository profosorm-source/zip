<?php

namespace App\Controllers\User;

use App\Models\Ads;
use App\Models\SeoExecution;
use App\Services\Search\SearchOrchestrator;
use App\Services\Seo\SeoService;
use App\Services\SeoLandingProofService;
use App\Services\Shared\DashboardStatsService;
use App\Services\Interaction\RatingService;
use App\Services\Interaction\ReportService;

/**
 * SeoController — انجام تسک‌های SEO توسط کاربران (Workers)
 */
class SeoController extends BaseUserController
{
    private Ads $adModel;
    private SeoExecution $executionModel;
    private SeoService $seoService;
    private SeoLandingProofService $landingProof;
    private ?RatingService $ratingService = null;
    private ?ReportService $reportService = null;

    public function __construct(
        Ads $adModel,
        SeoExecution $executionModel,
        SeoService $seoService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->adModel = $adModel;
        $this->executionModel = $executionModel;
        $this->seoService = $seoService;
        // فاز ۲ سئو (FIX-SEO-23-01): کانال اثبات فرود پیکسل/پست‌بک — سرویس
        // سبک است و در مسیرهای بدون فرود (index/start) هرگز فراخوانی نمی‌شود.
        $this->landingProof = new SeoLandingProofService(
            $executionModel,
            new \App\Models\SeoLandingProofTest(db()),
            $adModel,
            db(),
            logger()
        );
    }

    /**
     * 🛡️ FIX-SEO3-01: سرویس‌های امتیاز/گزارش به‌صورت lazy از کانتینر —
     * فقط مسیرهای فهرست/جزئیات/report/rate آن‌ها را می‌خواهند (سازندهٔ
     * کنترلر بدون تغییر ماند تا تست‌های reflection-based go() دست‌نخورده بمانند).
     */
    private function ratingService(): RatingService
    {
        return $this->ratingService ??= app(RatingService::class);
    }

    private function reportService(): ReportService
    {
        return $this->reportService ??= app(ReportService::class);
    }

    /** لیست آگهی‌های فعال */
    public function index(): void
    {
        $userId = (int)user_id();
        $search = trim($this->request->str('search'));
        $page = max(1, $this->request->int('page', 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;

        // 🛡️ FIX-T23-03 (بازگردانی SEO-23-06): فهرست کاربر-محور — قبلاً (بعد از
        // آشتی‌بندی نوامبر) این صفحه به کوئری ادمین برگشته بود و آگهی خود
        // کاربر + کمپین‌های مرده (بودجه < حداقل پاداش، is_active=0، مهلت
        // گذشته) را هم نشان می‌داد.
        $result = $this->adModel->searchActiveSeoTasksForUser($userId, $search, $perPage, $offset);
        $ads = $result['items'] ?? [];
        $total = $result['total'] ?? 0;

        // 🛡️ FIX-SEO3-01 (تصمیم ۱): میانگین رأی مجریان برای هر کارت — یک
        // کوئری batch برای کل صفحه (نه per-ad)؛ فقط کارت‌های دارای رأی نمایش می‌دهند.
        $adIds = [];
        foreach ($ads as $ad) {
            if (is_object($ad) || is_array($ad)) {
                $adIds[] = (int)(is_array($ad) ? ($ad['id'] ?? 0) : ($ad->id ?? 0));
            }
        }
        $ratings = $this->ratingService()->getRatingsSummary('seo_task', $adIds);

        // آمار کاربر
        $stats = $this->executionModel->getUserStats($userId);
        $todayCount = $this->executionModel->countByUserToday($userId);

        view('user.seo.index', [
            'title' => 'تسک‌های SEO',
            'ads' => $ads,
            'ratings' => $ratings,
            'stats' => [
                'total' => $stats,
                'today' => $todayCount
            ],
            'search' => $search,
            'page' => $page,
            'totalPages' => (int)ceil($total / $perPage),
            'total' => $total,
        ]);
    }

    /** شروع تسک (AJAX) */
    public function start(): void
    {
        $body = $this->request->body();
        $adId = int_value($body['ad_id'] ?? 0);
        $userId = (int)user_id();

        if ($adId <= 0) {
            $this->response->json(['success' => false, 'message' => 'آگهی نامعتبر']);
            return;
        }

        $result = $this->seoService->startTask($adId, $userId);
        if (!empty($result['success']) && !empty($result['execution_id'])) {
            $result['redirect_url'] = url('/seo/' . int_value($result['execution_id']) . '/execute');
        }
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    /** صفحه اجرای تسک (WebView) */
    public function execute(): void
    {
        $executionId = (int)$this->request->param('id');
        $userId = (int)user_id();

        $execution = $this->executionModel->findByUser($executionId, $userId);

        if (!$execution) {
            $this->session->setFlash('error', 'تسک یافت نشد');
            redirect(url('/seo'));
        }

        if ($execution->status !== 'started') {
            $this->session->setFlash('error', 'این تسک قابل انجام نیست');
            redirect(url('/seo'));
        }

        $ad = $this->adModel->find($execution->ad_id);

        if (!$ad) {
            $this->session->setFlash('error', 'آگهی یافت نشد');
            redirect(url('/seo'));
        }

        // 🛡️ FIX-SEO-23-01 (فاز ۱ — ریدایرکت شمارنده): دکمهٔ «باز کردن سایت
        // هدف» دیگر لینک مستقیم به سایت تبلیغ‌دهنده نیست؛ از مسیر سرور
        // ‎/seo/{id}/go/{token}‎ با nonce یک‌بارمصرف عبور می‌کند تا کلیک در سمت
        // سرور مهر شود (kill «هرگز باز نشده ولی پاداش»). اگر کلیک قبلاً مهر
        // شده (مثلاً رفرش صفحه بعد از کلیک)، توکن null برمی‌گردد و لینک مستقیم
        // می‌شود — شمارش تکراری وجود ندارد و UX هم نمی‌شکند.
        $clickToken = $this->executionModel->issueClickToken((int)$execution->id);
        $targetUrl = (string)($ad->site_url ?? $ad->target_url ?? $ad->link ?? '');
        $openUrl = ($execution->click_counted_at !== null || $clickToken === null || $targetUrl === '')
            ? $targetUrl
            : url('/seo/' . (int)$execution->id . '/go/' . urlencode($clickToken));

        // 🛡️ FIX-SEO-23-01 (فاز ۲ — وضعیت سه‌حالته اثبات): نشانِ صادقانهٔ وضعیت
        // برای کاربر: 🔴 بدون اثبات (سقف ۶۰٪) / 🟡 کلیک اثبات‌شده / 🟢 فرود
        // اثبات‌شده (پیکسل/پست‌بک — سقف کامل). وعدهٔ صادقانه: این‌جا چیزی «رد»
        // نمی‌شود؛ فقط پاداش پله‌ای است — تقلب گران می‌شود، نه صفر.
        $proofMode = $this->landingProof->modeForAd($ad);
        $proofState = 'none';
        if ($execution->click_counted_at !== null) {
            $proofState = ($execution->landing_verified_at !== null) ? 'landing' : 'click';
        }

        view('user.seo.execute', [
            'title' => 'اجرای تسک',
            'execution' => $execution,
            'ad' => $ad,
            'openUrl' => $openUrl,
            'proofMode' => $proofMode,
            'proofState' => $proofState,
        ]);
    }

    /**
     * 🛡️ FIX-SEO-23-01 (فاز ۱) — ریدایرکت شمارندهٔ کلیک سئو.
     *
     * دکمهٔ «باز کردن سایت هدف» به این مسیر اشاره می‌کند؛ سرور با یک UPDATE
     * اتمیک (گارد: مالکیت + وضعیت started + تطابق توکن + مصرف‌نشده +
     * منقضی‌نشده) کلیک را مهر می‌زند و بعد ۳۰۲ به سایت هدف می‌فرستد.
     * بازپخش/اشتراک‌گذاری لینک بی‌اثر است (توکن مصرف‌شده یا مالکِ دیگر).
     * اگر کلیک قبلاً مهر شده باشد، عبور idempotent است: بدون شمارش مجدد،
     * فقط هدایت به هدف.
     */
    public function go(): void
    {
        $executionId = (int)$this->request->param('id');
        $token = (string)$this->request->param('token');
        $userId = (int)user_id();

        // 📱 FIX-MOBILE-05 (بچ آماده‌سازی اپ موبایل — ۲۰۲۶-۱۱-۰۲): مسیر مهمان.
        // اپ موبایل go_url را در مرورگر سیستمی/InApp باز می‌کند — آنجا session
        // وب وجود ندارد. همان nonce یک‌بارمصرف، «اثبات مالکیت» است (capability
        // URL): findByClickToken تطبیقِ ایندکس‌دارِ توکن را می‌سنجد و مالکِ
        // واقعی اجرا از همان ردیف خوانده می‌شود؛ consumeClickToken با گاردهای
        // کامل (وضعیت started + انقضای توکن + مصرف‌نشده) همچنان مهر می‌زند.
        // مسیر وب (با session) بیت‌به‌بیت دست‌نخورده ماند.
        if ($userId <= 0) {
            $byToken = ($token !== '') ? $this->executionModel->findByClickToken($token) : null;
            if ($byToken === null || (int)($byToken['id'] ?? 0) !== $executionId) {
                // بدون افشای دلیل — همان پاسخ عمومی مسیر وب
                $this->session->setFlash('error', 'تسک یافت نشد');
                redirect(url('/seo'));
            }
            $userId = (int)($byToken['user_id'] ?? 0);
        }

        $execution = $executionId > 0 ? $this->executionModel->find($executionId) : null;

        if (!$execution || (int)$execution->user_id !== $userId) {
            $this->session->setFlash('error', 'تسک یافت نشد');
            redirect(url('/seo'));
        }

        if ((string)$execution->status !== 'started') {
            $this->session->setFlash('error', 'این تسک قابل انجام نیست');
            redirect(url('/seo'));
        }

        $ad = $this->adModel->find($execution->ad_id);
        $targetUrl = (string)($ad->site_url ?? $ad->target_url ?? $ad->link ?? '');
        if (!$ad || $targetUrl === '' || !filter_var($targetUrl, FILTER_VALIDATE_URL)
            || !in_array(strtolower((string)(parse_url($targetUrl, PHP_URL_SCHEME) ?? '')), ['http', 'https'], true)) {
            $this->session->setFlash('error', 'آگهی یا آدرس سایت هدف نامعتبر است');
            redirect(url('/seo'));
        }

        // 🛡️ FIX-T23-01 (بخش ۲۳ — الصاق ckp در کلیک اول): وضعیت مهر کلیک
        // باید «پس از» مصرف توکن دیده شود. قبلاً شرط الصاق ckp روی شیءِ
        // $execution که «قبل از» consumeClickToken خوانده شده بود نگاه می‌کرد؛
        // در اولین کلیک (مسیر عادی!) click_counted_atِ حافظه هنوز null بود و
        // پارامتر ckp هرگز به آدرس هدف الصاق نمی‌شد — کانال اثبات فرودِ فاز ۲
        // عملاً فقط در عبور idempotent دوم کار می‌کرد که UI آن را تولید
        // نمی‌کند (پس از کلیک اول، دکمه لینک مستقیم می‌شود). حالا پرچم محلی
        // پس از مصرف موفقِ nonce ست می‌شود و همان کلیک اول توکن فرود را
        // می‌برد — هم برای مسیر وب و هم go_url اپ موبایل.
        $clickStamped = $execution->click_counted_at !== null;
        if (!$clickStamped) {
            // 🛡️ FIX-T23H-01: شواهد لحظهٔ کلیک (IP + UA همین درخواست go) در
            // همان تک UPDATE اتمیک مهر می‌شوند — مرجع گیت‌های سخت‌سازی پیکسل
            // در SeoLandingProofService::handlePixel. UA خالی به‌صورت رشتهٔ خالی
            // ذخیره می‌شود (= کلیک بدون مرورگر؛ اثبات فرودِ پیکسل برای چنین
            // اجرایی ممکن نیست).
            $clickUserAgent = array_key_exists('HTTP_USER_AGENT', $_SERVER) ? (string)$_SERVER['HTTP_USER_AGENT'] : '';
            if (!$this->executionModel->consumeClickToken($executionId, $userId, $token, get_client_ip(), $clickUserAgent)) {
                // توکن نامعتبر/منقضی — صفحهٔ اجرا در رندر مجدد توکن تازه صادر می‌کند
                $this->session->setFlash('error', 'کد کلیک نامعتبر یا منقضی است؛ لطفاً صفحه را بارگذاری مجدد کنید.');
                redirect(url('/seo/' . $executionId . '/execute'));
            }
            $clickStamped = true; // مصرف موفق nonce = کلیک همین حالا در DB مهر خورد
        }
        // clickStamped ⇒ عبور idempotent بدون شمارش مجدد. در این نقطه کلیک
        // همیشه مهرشده است (مسیر خطا با redirectِ never خارج شده) — پس شرط
        // الصاق فقط به حالت آگهی و حضور توکن وابسته است.

        // 🛡️ FIX-SEO-23-01 (فاز ۲ — الصاق توکن فرود): اگر آگهی کانال اثبات فرود
        // فعال دارد (pixel/postback)، همان nonce به‌صورت پارامتر ckp به آدرس
        // هدف الصاق می‌شود تا سایت تبلیغ‌دهنده با پیکسل/پست‌بک بازگرداندش. برای
        // آگهی‌های off آدرس دست‌نخورده می‌ماند (تمیزی لینک + سازگاری کامل فاز ۱).
        // (🛡️ FIX-T23-01: از همین کلیک اول — نه فقط عبور دوم.)
        if ($this->landingProof->isEnabledForAd($ad) && $token !== '') {
            $targetUrl = $this->landingProof->appendTokenToTargetUrl($targetUrl, $ad, $token);
        }

        $this->response->redirectExternal($targetUrl);
    }

    /**
     * 🛡️ FIX-SEO-23-01 (فاز ۲) — پیکسل اثبات فرود (عمومی، بدون لاگین).
     *
     * تصویر ۱×1 که تبلیغ‌دهنده روی صفحهٔ فرود می‌گذارد؛ مرورگر کاربر آن را
     * بارگذاری می‌کند و سرور فرود را مهر می‌زند. بدون احراز هویت است — کوکیِ
     * third-party در مرورگرهای مدرن ارسال نمی‌شود و اثبات، خودِ توکن است.
     * همیشه GIF شفاف ۱×1 برمی‌گرداند (حتی در خطا — پیکسل هرگز نباید خطای
     * قابل‌مشاهده برای بازدیدکنندهٔ سایت تبلیغ‌دهنده تولید کند).
     */
    public function pixel(): void
    {
        $token = (string)$this->request->param('token');
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        // 🛡️ FIX-T23-02: Referer درخواست برای گیتِ «درخواست مرورگری هم‌مقصد»
        // به سرویس پاس داده می‌شود — پیکسل باید از صفحهٔ فرودِ همین آگهی
        // بارگذاری شده باشد، نه فراخوانی مستقیم با توکنِ قابل‌مشاهده.
        $referer = isset($_SERVER['HTTP_REFERER']) ? (string)$_SERVER['HTTP_REFERER'] : null;
        // 🛡️ FIX-T23H-02: UA درخواست برای گیت مرورگری + تطبیق با UA لحظهٔ کلیک
        // (click_user_agent مهرشده در مسیر go) به سرویس پاس داده می‌شود.
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? (string)$_SERVER['HTTP_USER_AGENT'] : null;

        $this->landingProof->handlePixel($token, $ip, $referer, $userAgent);

        // GIF شفاف ۱×1 (42 بایت) — بدون کش؛ Content-Length دقیق با بدنهٔ واقعی
        header('Content-Type: image/gif');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Content-Length: 42');
        echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
        exit;
    }

    /**
     * تکمیل تسک (AJAX)
     *
     * FIX-R36-W3 (F-A16-06) — مستند مرز اعتماد (describe-only؛ مسیر ثبت‌شدهٔ رجیستر):
     * duration/active_time/scroll_depth/interactions و سیگنال‌های رفتاری این‌جا
     * «ادعای خام کلاینت» هستند و به مسیر پرداخت می‌روند. سمت سرور دو کمپاند موجود:
     * (1) SeoService::validateEngagementData بازه‌ها را clamp می‌کند؛
     * (2) ProcessSeoTaskAsyncJob (فیکس H-10) duration/active_time را به زمان
     * سپری‌شدهٔ سرور می‌بَرد → پاداش قابل‌تورم از duration نیست.
     * باقی‌مانده (scroll_depth/interactions/signals رفتاری = نمرهٔ engagement) و
     * fail-open بودن SeoFraudDetector برای IP خصوصی، همان آیتم ثبت‌شدهٔ F-A10-03 است —
     * اعتبارسنجی سمت سرور از این اندپوینت فقط با تعویض به معیارهای سرورمحور ممکن است.
     */
    public function complete(): void
    {
        $executionId = (int)$this->request->param('id');
        $userId = (int)user_id();
        $body = $this->request->body();

        foreach (['duration', 'scroll_depth', 'interactions'] as $field) {
            if (!array_key_exists($field, $body) || !is_numeric($body[$field])) {
                $this->response->json(['success' => false, 'message' => "فیلد {$field} باید عددی باشد."], 422);
                return;
            }
        }
        $interactionTypes = $body['interaction_types'] ?? [];
        if (!is_array($interactionTypes) || array_filter($interactionTypes, 'is_string') !== $interactionTypes) {
            $this->response->json(['success' => false, 'message' => 'ساختار interaction_types نامعتبر است.'], 422);
            return;
        }
        $clientMode = $body['client_mode'] ?? 'web';
        if (!is_string($clientMode) || !in_array($clientMode, ['web', 'mobile_web', 'mobile_app'], true)) {
            $this->response->json(['success' => false, 'message' => 'client_mode نامعتبر است.'], 422);
            return;
        }

        $engagementData = [
            'duration' => int_value($body['duration'] ?? 0),
            'active_time' => int_value($body['active_time'] ?? $body['duration'] ?? 0),
            'scroll_depth' => float_value($body['scroll_depth'] ?? $body['scrollDepth'] ?? 0),
            'interactions' => int_value($body['interactions'] ?? 0),
            'target_opened' => !empty($body['target_opened']) ? 1 : 0,
            'focus_blur_count' => int_value($body['focus_blur_count'] ?? 0),
            'client_mode' => $clientMode,
            'interaction_types' => array_values($interactionTypes),
            'behavior' => [
                'scroll_speed' => float_value($body['scroll_speed'] ?? 0),
                'mouse_pattern' => str_value($body['mouse_pattern'] ?? 'normal'),
                'pause_count' => int_value($body['pause_count'] ?? 0),
                'interaction_types' => array_values($interactionTypes),
                'target_opened' => !empty($body['target_opened']) ? 1 : 0,
                'focus_blur_count' => int_value($body['focus_blur_count'] ?? 0),
                'client_mode' => $clientMode,
            ],
        ];

        $result = $this->seoService->completeTask($executionId, $userId, $engagementData);
        $this->response->json($result);
    }

    /** لغو تسک (AJAX) */
    public function cancel(): void
    {
        $executionId = (int)$this->request->param('id');
        $userId = (int)user_id();

        $result = $this->seoService->cancelTask($executionId, $userId);
        $this->response->json($result);
    }

    /** تاریخچه تسک‌ها */
    public function history(): void
    {
        $userId = (int)user_id();
        $page = max(1, $this->request->int('page', 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $executions = $this->executionModel->getByUser($userId, $limit, $offset);
        $total = $this->executionModel->countByUser($userId);
        $totalPages = ceil($total / $limit);

        view('user.seo.history', [
            'title' => 'تاریخچه تسک‌ها',
            'executions' => $executions,
            'page' => $page,
            'totalPages' => $totalPages,
            'total' => $total,
        ]);
    }

    /** جزئیات یک تسک انجام شده */
    public function showExecution(): void
    {
        $executionId = (int)$this->request->param('id');
        $userId = (int)user_id();

        $execution = $this->executionModel->findByUser($executionId, $userId);

        if (!$execution) {
            redirect(url('/seo/history'));
        }

        $ad = $this->adModel->find($execution->ad_id);

        // 🛡️ FIX-SEO3-01 (تصمیم ۱): داده‌های بازخورد برای بخش «گزارش و امتیاز» —
        // وضعیت فعلی کاربر (امتیاز/گزارش ثبت‌شده) + میانگین رأی دیگران برای
        // همین آگهی؛ نمایش/فرم‌ها در ویو بر اساس وضعیت اجرا (started/completed)
        // و همین مقادیر تصمیم می‌گیرند.
        $adId = (int)$execution->ad_id;
        $summary = $this->ratingService()->getRatingsSummary('seo_task', [$adId]);
        view('user.seo.show-execution', [
            'title' => 'جزئیات تسک',
            'execution' => $execution,
            'ad' => $ad,
            'feedback' => [
                'my_rating' => $this->ratingService()->getUserRating($userId, 'seo_task', $adId),
                'reported'  => $this->reportService()->hasReported($userId, 'seo_task', $adId),
                'avg'       => $summary[$adId]['avg'] ?? 0.0,
                'count'     => $summary[$adId]['count'] ?? 0,
            ],
        ]);
    }

    /**
     * 🛡️ FIX-SEO3-03 (تصمیم ۳) — وضعیت اثبات اجرا برای poll سبک نشان سه‌حالته.
     *
     * GET /seo/execution/{id}/proof-status (JSON؛ $auth)
     *
     * نشان صفحهٔ اجرا (FIX-SEO-23-01 فاز ۲) فقط در رندر اولیه از سرور خوانده
     * می‌شد و هنگام بازگشت کاربر از سایت هدف کهنه می‌ماند (پاداش سمت سرور از
     * مهرهای واقعی محاسبه می‌شد — مشکل فقط اعتماد/UX بود). این اندپوینت سبک
     * (یک SELECT ایندکس‌دار) برای تازه‌کردن نشان به‌کار می‌رود: JS فقط در دو
     * لحظهٔ معنادار (بازگشت به تب/فوکوس + یک‌بار قبل از ارسال تکمیل) صدا می‌زند
     * — نه timer مداوم. نقشهٔ نشان (cls/icon/text) همین‌جا ساخته می‌شود تا
     * منبع واحد حقیقت با رندر اولیهٔ ویو (SeoLandingProofService::badgeFor) یکی باشد.
     */
    public function proofStatus(): void
    {
        $executionId = (int)$this->request->param('id');
        $userId = (int)user_id();

        $execution = $this->executionModel->findByUser($executionId, $userId);
        if (!$execution) {
            $this->response->json(['success' => false, 'message' => 'تسک یافت نشد'], 404);
            return;
        }

        $ad = $this->adModel->find($execution->ad_id);
        $mode = $ad !== null ? $this->landingProof->modeForAd($ad) : 'off';

        // همان استنتاج رندر اولیهٔ execute() — none/click/landing
        $state = 'none';
        if ($execution->click_counted_at !== null) {
            $state = ($execution->landing_verified_at !== null) ? 'landing' : 'click';
        }

        $this->response->json([
            'success'      => true,
            'execution_id' => $executionId,
            'status'       => (string)($execution->status ?? ''),
            'proof_mode'   => $mode,
            'proof_state'  => $state,
            'badge'        => SeoLandingProofService::badgeFor($state, $mode),
        ]);
    }

    /**
     * ثبت گزارش برای تسک سئو (AJAX) — 🛡️ FIX-SEO3-01 (تصمیم ۱: فعال‌سازی).
     *
     * گارد وضعیت در کنترلر (SEO-23-12): فقط اجرای started/completed قابل
     * گزارش است؛ گاردهای مستقل (type=seo + مجری بودن) داخل ReportSeoTaskJob.
     */
    public function report(): void
    {
        $executionId = (int)$this->request->param('id');
        $userId = (int)user_id();
        $body = $this->request->body();
        $reason = trim(str_value($body['reason'] ?? ''));
        $description = trim(str_value($body['description'] ?? ''));

        if (empty($reason)) {
            $this->response->json(['success' => false, 'message' => 'دلیل گزارش الزامی است']);
            return;
        }

        $execution = $this->executionModel->findByUser($executionId, $userId);
        if (!$execution) {
            $this->response->json(['success' => false, 'message' => 'تسک یافت نشد']);
            return;
        }

        // 🛡️ FIX-SEO3-01: گزارش فقط برای اجرای در جریان/تکمیل‌شده معنا دارد
        // (اجرای لغوشده/ردشده کانال خودش — dispute/دلیل رد — را دارد).
        if (!in_array((string)$execution->status, ['started', 'completed'], true)) {
            $this->response->json(['success' => false, 'message' => 'گزارش فقط برای تسک در حال انجام یا تکمیل‌شده امکان‌پذیر است'], 422);
            return;
        }

        $result = $this->seoService->reportTask($userId, (int)$execution->ad_id, $reason, $description);
        $this->response->json($result);
    }

    /**
     * ثبت امتیاز برای تسک سئو (AJAX) — 🛡️ FIX-SEO3-01 (تصمیم ۱: فعال‌سازی).
     *
     * گارد وضعیت در کنترلر (SEO-23-12): فقط اجرای completed قابل امتیازدهی؛
     * گاردهای مستقل (type=seo + نه مالک کمپین + مجریِ تکمیل‌شده) داخل RateSeoTaskJob.
     */
    public function rate(): void
    {
        $executionId = (int)$this->request->param('id');
        $userId = (int)user_id();
        $body = $this->request->body();
        $stars = int_value($body['stars'] ?? 0);
        $comment = trim(str_value($body['comment'] ?? ''));

        if ($stars < 1 || $stars > 5) {
            $this->response->json(['success' => false, 'message' => 'امتیاز نامعتبر است']);
            return;
        }

        $execution = $this->executionModel->findByUser($executionId, $userId);
        if (!$execution) {
            $this->response->json(['success' => false, 'message' => 'تسک یافت نشد']);
            return;
        }

        // 🛡️ FIX-SEO3-01: امتیاز پس از تجربهٔ کامل — فقط اجرای تکمیل‌شده.
        if ((string)$execution->status !== 'completed') {
            $this->response->json(['success' => false, 'message' => 'امتیازدهی فقط پس از تکمیل تسک امکان‌پذیر است'], 422);
            return;
        }

        $result = $this->seoService->rateTask($userId, (int)$execution->ad_id, $stars, $comment);
        $this->response->json($result);
    }
}
