<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\VitrineListing;
use App\Models\VitrineRequest;
use App\Services\VitrineService;
use App\Services\FeatureFlagService;

/**
 * VitrineController — پنل کاربری سرویس ویترین
 *
 * تمام آگهی‌ها متن‌محور هستند — هیچ تصویری پذیرفته نمی‌شود
 */
class VitrineController extends BaseUserController
{
    private VitrineService  $service;
    private FeatureFlagService $flags;

    private \App\Models\VitrineListing $listing;

    public function __construct(
        VitrineService     $service,
        FeatureFlagService $flags,
        \App\Models\VitrineListing $listing
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->service      = $service;
        $this->flags        = $flags;
        $this->listing      = $listing;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // لیست آگهی‌های فروش
    // ─────────────────────────────────────────────────────────────────────────

    public function index(): void
    {
        $filters = [
            'category'   => $this->request->get('category')   ?? '',
            'platform'   => $this->request->get('platform')   ?? '',
            'search'     => $this->request->get('search')      ?? '',
            'min_price'  => $this->request->get('min_price')   ?? '',
            'max_price'  => $this->request->get('max_price')   ?? '',
            'min_members'=> $this->request->get('min_members') ?? '',
            'sort'       => $this->request->get('sort')        ?? 'newest',
        ];

        $page     = max(1, (int) ($this->request->get('page') ?? 1));
        $perPage  = 20;
        
        $data = $this->service->getListings($filters, $perPage, ($page - 1) * $perPage);

        $this->view('user/vitrine/index', array_merge($data, [
            'title'      => 'ویترین — بازار دیجیتال',
            'filters'    => $filters,
            'page'       => $page,
            'pages'      => (int) ceil($data['total'] / $perPage)
        ]));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // لیست درخواست‌های خریداران
    // ─────────────────────────────────────────────────────────────────────────

    public function wantedIndex(): void
    {
        $filters = [
            'category' => $this->request->get('category') ?? '',
            'platform' => $this->request->get('platform') ?? '',
            'search'   => $this->request->get('search')   ?? '',
        ];

        $page     = max(1, (int) ($this->request->get('page') ?? 1));
        $perPage  = 20;
        
        $data = $this->service->getWantedListings($filters, $perPage, ($page - 1) * $perPage);

        $this->view('user/vitrine/wanted', array_merge($data, [
            'title'      => 'ویترین — خریداران (متقاضیان)',
            'filters'    => $filters,
            'page'       => $page
        ]));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // فرم ثبت آگهی
    // ─────────────────────────────────────────────────────────────────────────

    public function create(): void
    {
        $userId = (int) user_id();
        $check  = $this->service->canTrade($userId);
        if (!$check['ok']) {
            $this->session->setFlash('error', $check['message']);
            redirect(url('/vitrine'));
            exit;
        }

        $this->view('user/vitrine/create', [
            'title'       => 'ثبت آگهی فروش در ویترین',
            'listingType' => 'sell',
            'categories'  => $this->listing->categories(),
            'platforms'   => $this->listing->platforms(),
        ]);
    }

    public function createWanted(): void
    {
        $userId = (int) user_id();
        $check  = $this->service->canTrade($userId);
        if (!$check['ok']) {
            $this->session->setFlash('error', $check['message']);
            redirect(url('/vitrine'));
            exit;
        }

        $this->view('user/vitrine/create', [
            'title'       => 'ثبت درخواست خرید در ویترین',
            'listingType' => 'buy',
            'categories'  => $this->listing->categories(),
            'platforms'   => $this->listing->platforms(),
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ذخیره آگهی جدید
    // ─────────────────────────────────────────────────────────────────────────

    public function store(): void
    {
        $userId = (int) user_id();
        $data   = $this->request->body();

        $request = new \App\Validators\Requests\CreateVitrineListingRequest($data);

        if (!$request->validate()) {
            $errors = $request->errors();
            $firstError = reset($errors);
            $msg = is_array($firstError) ? reset($firstError) : $firstError;
            $this->session->setFlash('error', $msg ?: 'اطلاعات ورودی نامعتبر است.');
            redirect(url('/vitrine/' . (($data['listing_type'] ?? '') === 'buy' ? 'wanted/create' : 'sell/create')));
            return;
        }

        $validatedData = $request->validated();
        $price = (float)($validatedData['price_usdt'] ?? 0);
        $minPrice = (float)setting('vitrine_min_price', 1);
        $maxPrice = (float)setting('vitrine_max_price', 100000);

        if ($price < $minPrice || $price > $maxPrice) {
            $this->session->setFlash('error', "قیمت باید بین {$minPrice} و {$maxPrice} USDT باشد.");
            redirect(url('/vitrine/' . (($validatedData['listing_type'] ?? '') === 'buy' ? 'wanted/create' : 'sell/create')));
            return;
        }

        // ✅ Store raw data (Escaping should be done in the View layer)
        $result = $this->service->createListing($userId, [
            'listing_type'   => in_array($validatedData['listing_type'] ?? 'sell', ['sell', 'buy'], true) ? $validatedData['listing_type'] : 'sell',
            'category'       => $validatedData['category'] ?? '',
            'platform'       => $validatedData['platform'] ?? '',
            'title'          => trim($validatedData['title']),
            'description'    => trim($validatedData['description']),
            'specs'          => !empty($data['specs']) ? trim($data['specs']) : null,
            'username'       => !empty($data['username']) ? trim($data['username']) : null,
            'member_count'   => max(0, (int)($data['member_count'] ?? 0)),
            'creation_date'  => !empty($data['creation_date']) ? $data['creation_date'] : null,
            'price_usdt'     => $price,
            'min_price_usdt' => !empty($data['min_price_usdt']) ? max(0, (float)$data['min_price_usdt']) : null,
        ]);

        if ($result['success']) {
            $this->session->setFlash('success', 'آگهی شما ثبت شد و پس از بررسی توسط تیم ویترین منتشر می‌شود.');
            redirect(url('/vitrine/my-listings'));
        } else {
            $this->session->setFlash('error', $result['message'] ?? 'خطا در ثبت آگهی.');
            redirect(url('/vitrine/' . (($validatedData['listing_type'] ?? '') === 'buy' ? 'wanted/create' : 'sell/create')));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // صفحه آگهی
    // ─────────────────────────────────────────────────────────────────────────

    public function show(): void
    {
        $id      = (int) $this->request->param('id');
        $userId  = (int) user_id();
        
        $data = $this->service->getListingDetails($id, $userId);

        if (!$data || in_array($data['listing']->status, [
            VitrineListing::STATUS_REJECTED,
            VitrineListing::STATUS_CANCELLED,
        ])) {
            $this->session->setFlash('error', 'آگهی یافت نشد.');
            redirect(url('/vitrine'));
            exit;
        }

        $this->view('user/vitrine/show', array_merge($data, [
            'title' => $data['listing']->title . ' — ویترین'
        ]));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // آگهی‌های من
    // ─────────────────────────────────────────────────────────────────────────

    public function myListings(): void
    {
        $userId = (int) user_id();
        $data   = $this->service->getUserDashboard($userId);

        $this->view('user/vitrine/my-listings', array_merge($data, [
            'title' => 'آگهی‌های من — ویترین'
        ]));
    }

    public function myPurchases(): void
    {
        $userId = (int) user_id();
        $data   = $this->service->getUserPurchases($userId);

        $this->view('user/vitrine/my-purchases', array_merge($data, [
            'title' => 'خریدهای من — ویترین'
        ]));
    }

    public function myRequests(): void
    {
        $userId   = (int) user_id();
        $requests = $this->requestModel->getByRequester($userId);

        $this->view('user/vitrine/my-requests', [
            'title'    => 'درخواست‌های من — ویترین',
            'requests' => $requests,
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // اقدامات AJAX
    // ─────────────────────────────────────────────────────────────────────────

    /** ثبت درخواست خرید با قیمت پیشنهادی */
    public function sendRequest(): void
    {
        $userId    = (int) user_id();
        $listingId = (int) $this->request->param('id');
        $data      = $this->request->body();

        $result = $this->service->sendRequest($userId, $listingId, [
            'offer_price' => !empty($data['offer_price']) ? (float) $data['offer_price'] : null,
            'message'     => trim($data['message'] ?? ''),
        ]);

        $this->response->json($result);
    }

    /** پذیرش درخواست توسط فروشنده */
    public function acceptRequest(): void
    {
        $userId    = (int) user_id();
        $requestId = (int) $this->request->param('rid');
        $result    = $this->service->acceptRequest($userId, $requestId);
        $this->response->json($result);
    }

    /** رد درخواست توسط فروشنده */
    public function rejectRequest(): void
    {
        $userId    = (int) user_id();
        $requestId = (int) $this->request->param('rid');
        $result    = $this->service->rejectRequest($userId, $requestId);
        $this->response->json($result);
    }

    /** قفل اسکرو — خریدار پرداخت می‌کند */
    public function buy(): void
    {
        $userId    = (int) user_id();
        $listingId = (int) $this->request->param('id');
        $result    = $this->service->lockEscrow($userId, $listingId);
        $this->response->json($result);
    }

    /** تایید دریافت توسط خریدار */
    public function confirmDelivery(): void
    {
        $userId    = (int) user_id();
        $listingId = (int) $this->request->param('id');
        $result    = $this->service->confirmDelivery($userId, $listingId);
        $this->response->json($result);
    }

    /** ثبت اختلاف */
    public function dispute(): void
    {
        $userId    = (int) user_id();
        $listingId = (int) $this->request->param('id');
        $reason    = trim($this->request->post('reason') ?? '');

        if (mb_strlen($reason) < 10) {
            $this->response->json(['success' => false, 'message' => 'لطفاً دلیل اختلاف را با جزئیات بنویسید (حداقل ۱۰ کاراکتر).']);
            return;
        }

        $result = $this->service->openDispute($userId, $listingId, $reason);
        $this->response->json($result);
    }

    /** لغو آگهی توسط فروشنده */
    public function cancel(): void
    {
        $userId    = (int) user_id();
        $listingId = (int) $this->request->param('id');
        $result    = $this->service->cancelListing($userId, $listingId);
        $this->response->json($result);
    }

    /** علاقه‌مندی / نشانه‌گذاری */
    public function watch(): void
    {
        $userId    = (int) user_id();
        $listingId = (int) $this->request->param('id');
        
        $result = $this->service->toggleWatch($userId, $listingId);
        $this->response->json($result);
    }

    /**
     * Master E2E Functional Verification Specifically for Section 12 Vitrine Bounded Domain Operations 🆕 (VT-01 to VT-09) Trapped sequence
     */
    public function verifyVitrineSection12(): void
    {
        $db = \Core\Database::getInstance();
        $db->query("INSERT IGNORE INTO feature_flags (name, description, enabled, created_at) VALUES ('vitrine_enabled', 'بازار دیجیتال ویترین', 1, NOW()), ('vitrine_kyc_required', 'الزام احراز هویت برای ویترین', 1, NOW())");
        $results = [];
        $salt = random_int(10000, 99999);

        // Helper to setup a test wallet & user
        $setupUser = function(int $userId, float $balanceIrt = 0.0, float $balanceUsdt = 0.0, string $kycStatus = 'verified') use ($db) {
            $db->query("INSERT IGNORE INTO users (id, email, full_name, role, status, kyc_status, created_at) VALUES (?, ?, ?, 'user', 'active', ?, NOW())", [$userId, "user_vt_{$userId}@chortke.ir", "VT User {$userId}", $kycStatus]);
            $db->query("INSERT IGNORE INTO wallets (user_id, balance_irt, balance_usdt) VALUES (?, ?, ?)", [$userId, $balanceIrt, $balanceUsdt]);
            $db->query("UPDATE wallets SET balance_irt = ?, balance_usdt = ? WHERE user_id = ?", [$balanceIrt, $balanceUsdt, $userId]);
        };

        // ─── 1. VT-01 🆕: Create Vitrine Listing -> CreateVitrineListingJob executed, listing stored ───
        $listingObj01 = null;
        try {
            $u01 = 1201 + $salt;
            $setupUser($u01);

            $res01 = $this->service->createListing($u01, [
                'title' => "Master Premium Telegram Channel {$salt}",
                'description' => 'A rigorous high-income crypto analytics channel.',
                'category' => 'channel',
                'platform' => 'telegram',
                'price_usdt' => 250.0,
                'member_count' => 125000,
                'username' => "crypto_master_{$salt}",
            ]);

            $listingObj01 = $res01['listing'] ?? null;
            if ($listingObj01) {
                $this->listing->updateStatus((int)$listingObj01->id, 'active');
                $listingObj01 = $this->listing->find((int)$listingObj01->id);
            }

            $passed = (!empty($res01['success'])) && ($listingObj01 !== null) && ($listingObj01->status === 'active');
            $results['VT-01'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-01 🆕: ایجاد Listing در ویترین (Vitrine Listing Creation)',
                'details' => "فروشنده: <code>کاربر #{$u01}</code><br>عنوان آگهی: <code>" . ($listingObj01 ? $listingObj01->title : '') . "</code><br>بهای آگهی: <code>250.0 USDT</code><br>وضعیت در جدول vitrine_listings: <code>" . ($listingObj01 ? "ثبت موفق با شناسه #{$listingObj01->id} و وضعیت {$listingObj01->status}" : 'ناموفق') . "</code>",
                'message' => $passed ? 'موفق: آگهی ویترین با موفقیت در دیتابیس ثبت گردید و شناسه معتبر تخصیص یافت.' : 'خطا در ثبت Listing.'
            ];
        } catch (\Throwable $e) {
            $results['VT-01'] = ['status' => 'FAILED', 'title' => 'VT-01 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 2. VT-02 🆕: Create Listing without KYC -> Cleanly rejected ───
        try {
            $u02 = 1202 + $salt;
            $setupUser($u02, 0.0, 0.0, 'unverified');

            $res02 = $this->service->createListing($u02, [
                'title' => 'Unverified User Item',
                'description' => 'Should be blocked.',
                'category' => 'page',
                'price_usdt' => 100.0,
            ]);

            $passed = (empty($res02['success'])) && str_contains($res02['message'] ?? '', 'KYC');
            $results['VT-02'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-02 🆕: ایجاد Listing بدون احراز هویت (KYC Guard)',
                'details' => "فروشنده: <code>کاربر #{$u02}</code><br>وضعیت احراز هویت (KYC Status): <code>تأیید نشده (Unverified)</code><br>پاسخ گیت احراز هویت ویترین: <code>" . ($res02['message'] ?? 'مجاز') . "</code>",
                'message' => $passed ? 'موفق: سیستم فوراً درخواست ایجاد آگهی توسط کاربر بدون KYC را مسدود کرد.' : 'خطا در مهار KYC.'
            ];
        } catch (\Throwable $e) {
            $results['VT-02'] = ['status' => 'FAILED', 'title' => 'VT-02 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 3. VT-03 🆕: Access Vitrine while vitrine_enabled is disabled -> 503 or redirect ───
        try {
            $u03 = 1203 + $salt;
            $setupUser($u03);

            // Mock FeatureFlagService to return disabled
            $flagsMock = new \App\Services\FeatureFlagService(app(\Core\EventDispatcher::class), $db, $this->logger, app(\Core\Cache::class), app(\App\Models\FeatureFlag::class), app(\App\Models\User::class), app(\App\Models\KYCVerification::class));
            $flagsMock->disable('vitrine_enabled');

            $vitrineMock = new VitrineService(app(\Core\EventDispatcher::class), $this->listing, app(\App\Models\VitrineRequest::class), $flagsMock, app(\App\Services\Settings\AppSettings::class), app(\App\Services\User\UserService::class));
            $res03 = $vitrineMock->canTrade($u03);

            // restore flag
            $flagsMock->enable('vitrine_enabled');

            $passed = (empty($res03['ok'])) && str_contains($res03['message'] ?? '', 'غیرفعال');
            $results['VT-03'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-03 🆕: دسترسی هنگام غیرفعال بودن قابلیت ویترین (vitrine_enabled Feature Flag)',
                'details' => "وضعیت Feature Flag: <code>غیرفعال (0)</code><br>نتیجه فراخوانی سرویس معامله: <code>" . ($res03['message'] ?? 'مجاز') . "</code>",
                'message' => $passed ? 'موفق: سیستم در زمان غیرفعال بودن Feature Flag، فوراً با خطای مناسب عملیات را متوقف کرد.' : 'خطا در مسدودسازی.'
            ];
        } catch (\Throwable $e) {
            $results['VT-03'] = ['status' => 'FAILED', 'title' => 'VT-03 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 4. VT-04 🆕 ⭐: Buy request & lock Escrow (LockVitrineEscrowJob) -> Amount locked ───
        try {
            $u04_Buyer = 1204 + $salt;
            $setupUser($u04_Buyer, 0.0, 1000.0); // 1000 USDT balance

            $res04 = $this->service->lockEscrow($u04_Buyer, (int)($listingObj01 ? $listingObj01->id : 1));
            
            $balBuyerAfter04 = (float)$db->fetch("SELECT balance_usdt FROM wallets WHERE user_id = ?", [$u04_Buyer])->balance_usdt;
            $escrowRecord04 = $db->fetch("SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'vitrine_purchase' ORDER BY id DESC LIMIT 1", [$listingObj01 ? $listingObj01->id : 1]);

            // Price is 250 USDT. Initial bal 1000 -> 750
            $passed = (!empty($res04['success'])) && ($escrowRecord04 !== false) && ($balBuyerAfter04 === 750.0);
            $results['VT-04'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-04 🆕 ⭐: ارسال درخواست خرید و قفل Escrow (LockVitrineEscrowJob)',
                'details' => "خریدار: <code>کاربر #{$u04_Buyer} (موجودی اولیه: 1,000 USDT)</code><br>شناسه آگهی مرجع: <code>" . ($listingObj01 ? "#{$listingObj01->id}" : '') . "</code><br>بهای انتقال (USDT): <code>250.0 USDT</code><br>خروجی صندوق امانی (Escrow Center): <code>" . ($escrowRecord04 ? "تراکنش #{$escrowRecord04->id} با مبلغ {$escrowRecord04->amount} و وضعیت {$escrowRecord04->status}" : 'یافت نشد') . "</code><br>موجودی نهایی خریدار پس از کسر و قفل کامل وجه در Escrow: <code>" . number_format($balBuyerAfter04, 2) . " USDT</code>",
                'message' => $passed ? 'موفق: تراکنش خرید با موفقیت ایجاد گردید، موجودی خریدار کسر و در صندوق امانی (Escrow) قفل شد.' : 'خطا در قفل وجه Escrow.'
            ];
        } catch (\Throwable $e) {
            $results['VT-04'] = ['status' => 'FAILED', 'title' => 'VT-04 🆕 ⭐', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 5. VT-05 🆕 ⭐: Confirm delivery (ConfirmVitrineDeliveryJob) -> Payout to Seller ───
        try {
            $u05_Buyer = 1206 + $salt;
            $u05_Seller = 1207 + $salt;
            $setupUser($u05_Buyer, 0.0, 1000.0);
            $setupUser($u05_Seller, 0.0, 50.0); // 50 USDT balance

            // Create new listing
            $res05_Listing = $this->service->createListing($u05_Seller, [
                'title' => 'Exclusive Domain Trade',
                'description' => 'A Whitelisted premium domain name.',
                'category' => 'website',
                'price_usdt' => 400.0,
            ]);
            $l05_Id = (int)$res05_Listing['listing']->id;
            $this->listing->updateStatus($l05_Id, 'active');

            // Lock Escrow
            $this->service->lockEscrow($u05_Buyer, $l05_Id);

            // Confirm Delivery
            $res05_Confirm = $this->service->confirmDelivery($u05_Buyer, $l05_Id);

            $balSellerAfter05 = (float)$db->fetch("SELECT balance_usdt FROM wallets WHERE user_id = ?", [$u05_Seller])->balance_usdt;
            $l05Final = $this->listing->find($l05_Id);

            // Price 400 USDT - 5% commission (20 USDT) = 380 net + 50 initial = 430 USDT
            $passed = (!empty($res05_Confirm['success'])) && ($l05Final->status === 'sold') && ($balSellerAfter05 === 430.0);
            $results['VT-05'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-05 🆕 ⭐: تأیید تحویل آگهی و تسویه وجه (ConfirmVitrineDeliveryJob)',
                'details' => "شناسه معامله: <code>#{$l05_Id}</code> | بهای کل: <code>400.0 USDT</code><br>کارمزد سیستم (۵٪): <code>20.0 USDT</code> | سهم خالص فروشنده: <code>380.0 USDT</code><br>وضعیت نهایی آگهی در دیتابیس: <code>{$l05Final->status} (فروخته شده)</code><br>موجودی نهایی کیف پول USDT فروشنده: <code>" . number_format($balSellerAfter05, 2) . " USDT (واریز دقیق سهم از بافر Escrow)</code>",
                'message' => $passed ? 'موفق: با تأیید تحویل توسط خریدار، قفل Escrow آزاد و سهم خالص ارزیِ فروشنده فوراً واریز شد.' : 'خطا در تسویه نهایی.'
            ];
        } catch (\Throwable $e) {
            $results['VT-05'] = ['status' => 'FAILED', 'title' => 'VT-05 🆕 ⭐', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 6. VT-06 🆕: Open Vitrine Dispute & Resolve -> Dispute with locked funds ───
        try {
            $u06_Buyer = 1209 + $salt;
            $u06_Seller = 1210 + $salt;
            $setupUser($u06_Buyer, 0.0, 1000.0);
            $setupUser($u06_Seller);

            $res06_Listing = $this->service->createListing($u06_Seller, [
                'title' => 'Disputed Instagram Page',
                'description' => 'A page with mismatched follower counts.',
                'category' => 'page',
                'price_usdt' => 300.0,
            ]);
            $l06_Id = (int)$res06_Listing['listing']->id;
            $this->listing->updateStatus($l06_Id, 'active');

            // Buy & Escrow
            $this->service->lockEscrow($u06_Buyer, $l06_Id);

            // Open Dispute
            $res06_Dispute = $this->service->openDispute($u06_Buyer, $l06_Id, 'مالکیت پیج منتقل نشده و پاسخگو نیستند');

            $l06_Disputed = $this->listing->find($l06_Id);
            $escrow06_Record = $db->fetch("SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'vitrine_purchase' LIMIT 1", [$l06_Id]);
            $balSeller06 = (float)$db->fetch("SELECT balance_usdt FROM wallets WHERE user_id = ?", [$u06_Seller])->balance_usdt;

            // Resolve Dispute in favor of buyer via ResolveVitrineDisputeJob helper
            $resolveJob = app(\App\Jobs\Vitrine\ResolveVitrineDisputeJob::class);
            $res06_Resolve = $resolveJob->handle($l06_Id, 'buyer', 888);
            
            $balBuyerFinal06 = (float)$db->fetch("SELECT balance_usdt FROM wallets WHERE user_id = ?", [$u06_Buyer])->balance_usdt;
            $l06_Final = $this->listing->find($l06_Id);

            // 1000 initial - 300 held = 700 + 300 refunded = 1000 USDT
            $passed = (!empty($res06_Dispute['success'])) && (!empty($res06_Resolve['success'])) && ($l06_Disputed->status === 'disputed') && ($escrow06_Record->status === 'disputed') && ($balSeller06 === 0.0) && ($balBuyerFinal06 === 1000.0) && ($l06_Final->status === 'cancelled');
            $results['VT-06'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-06 🆕: باز کردن پرونده اختلاف ویترین و داوری (Open Dispute & Arbitrament)',
                'details' => "شناسه آگهی: <code>#{$l06_Id}</code> | دلیل اعتراض: <code>" . ($l06_Disputed ? $l06_Disputed->rejection_reason : '') . "</code><br>وضعیت آگهی در حین اختلاف: <code>" . ($l06_Disputed ? $l06_Disputed->status : '') . "</code> | خروجی صندوق امانی: <code>" . ($escrow06_Record ? "قفل موفق مبلغ {$escrow06_Record->amount} با وضعیت {$escrow06_Record->status}" : '') . "</code><br>نتیجه مداخله رسمی داور ادمین (ResolveVitrineDisputeJob): <code>صدور رأی به نفع خریدار (Buyer) و لغو آگهی</code><br>موجودی نهایی کیف پول خریدار: <code>" . number_format($balBuyerFinal06, 2) . " USDT (بازگشت اتوماتیک ۱۰۰٪ وجه)</code>",
                'message' => $passed ? 'موفق: اختلاف با وجه قفل‌شده در Escrow ثبت شد و با مداخله داوری ادمین، وجه به طور کامل به خریدار برگشت داده شد.' : 'خطا در ثبت اختلاف یا داوری.'
            ];
        } catch (\Throwable $e) {
            $results['VT-06'] = ['status' => 'FAILED', 'title' => 'VT-06 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 7. VT-07 🆕: Listing Expiry (VitrineListingExpiryJob) -> Listing expired, user receives notification ───
        try {
            $u07_Seller = 1212 + $salt;
            $setupUser($u07_Seller);

            $res07_Listing = $this->service->createListing($u07_Seller, [
                'title' => 'Expiring TikTok Page',
                'description' => 'Should be automatically swept and expired.',
                'category' => 'page',
                'price_usdt' => 150.0,
            ]);
            $l07_Id = (int)$res07_Listing['listing']->id;
            
            // Force status to active and expires_at to strictly past
            $db->query("UPDATE vitrine_listings SET status = 'active', expires_at = DATE_SUB(NOW(), INTERVAL 1 HOUR), hold_amount = 5.0, hold_released = 0 WHERE id = ?", [$l07_Id]);

            // Execute sweeper Job helper
            $expiryJob = app(\App\Jobs\VitrineListingExpiryJob::class);
            $expiryJob->handle();

            $l07_Final = $this->listing->find($l07_Id);
            $balSeller07Final = (float)$db->fetch("SELECT balance_usdt FROM wallets WHERE user_id = ?", [$u07_Seller])->balance_usdt;
            
            // Check outbox or notif trace
            $notifTrace07 = $db->fetch("SELECT * FROM outbox_events WHERE event_type = 'vitrine.listing_expired' AND aggregate_id = ? LIMIT 1", [(string)$l07_Id]);

            $passed = ($l07_Final->status === 'expired') && ($balSeller07Final === 5.0) && ($notifTrace07 !== false);
            $results['VT-07'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-07 🆕: انقضای آگهی‌های بی‌پاسخ (VitrineListingExpiryJob)',
                'details' => "شناسه آگهی مرجع: <code>#{$l07_Id}</code><br>عملیات موتور رفتوب (Sweeper CronJob): <code>شناسایی آگهی منقضی‌شده و تغییر وضعیت به Expired</code><br>آزادسازی وجه تضمین (Sticky Hold): <code>واریز اتوماتیک 5.0 IRT به حساب فروشنده</code><br>سیستم نوتیفیکیشن: <code>ثبت موفق رویداد vitrine.listing_expired جهت ارسال Notification به کاربر</code>",
                'message' => $passed ? 'موفق: آگهی به درستی منقضی (Expired) شد، وجه تضمین برگشت داده شد و نوتیفیکیشن انقضا صادر گردید.' : 'خطا در انقضای آگهی.'
            ];
        } catch (\Throwable $e) {
            $results['VT-07'] = ['status' => 'FAILED', 'title' => 'VT-07 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 8. VT-08 🆕: IDOR access another user listing -> 403 Forbidden ───
        try {
            $u08_Unrelated = 1215 + $salt;
            $setupUser($u08_Unrelated);

            $l08_Id = (int)($listingObj01 ? $listingObj01->id : 1);

            // Unrelated user attempts to cancel / modify someone else listing
            $res08 = $this->service->cancelListing($u08_Unrelated, $l08_Id);

            $passed = (!empty($res08['status']) && $res08['status'] === 403) || str_contains(strtolower($res08['message'] ?? ''), 'مالک') || str_contains($res08['message'] ?? '', 'دسترسی');
            $results['VT-08'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-08 🆕: حفاظت IDOR در دسترسی به آگهی دیگران (403 Forbidden)',
                'details' => "تلاش کاربر نامرتبط #{$u08_Unrelated} برای لغو یا دستکاری آگهی #{$l08_Id} متعلق به کاربر #{$u01}.<br>پاسخ گیت کنترل دسترسی IDOR: <code>" . ($res08['message'] ?? 'مسدود') . "</code>",
                'message' => $passed ? 'موفق: سیستم با خطای 403 Forbidden و دسترسی غیرمجاز، تلاش برای دستکاری آگهی دیگران را به طور کامل مهار کرد.' : 'خطای نشت دسترسی IDOR.'
            ];
        } catch (\Throwable $e) {
            $results['VT-08'] = ['status' => 'FAILED', 'title' => 'VT-08 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 9. VT-09 🆕: canTrade -> Proves KYC and account status check ───
        try {
            $u09_Banned = 1218 + $salt;
            $setupUser($u09_Banned, 0.0, 0.0, 'verified');
            $db->query("UPDATE users SET is_blacklisted = 1 WHERE id = ?", [$u09_Banned]);

            $res09_KYC = $this->service->canTrade($u02); // User 02 from VT-02 is unverified
            $res09_Banned = $this->service->canTrade($u09_Banned);
            $res09_Allowed = $this->service->canTrade($u01); // User 01 from VT-01 is fully verified and active

            $passed = (empty($res09_KYC['ok'])) && (empty($res09_Banned['ok'])) && (!empty($res09_Allowed['ok']));
            $results['VT-09'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی VT-09 🆕: بررسی توانایی و اهلیت معامله (canTrade Verification)',
                'details' => "کاربر بدون KYC: <code>" . ($res09_KYC['message'] ?? 'مسدود') . "</code><br>کاربر لیست سیاه (Blacklisted): <code>" . ($res09_Banned['message'] ?? 'مسدود') . "</code><br>کاربر تأیید شده و فعال: <code>تأیید و اهلیت معامله (Allowed)</code>",
                'message' => $passed ? 'موفق: متد canTrade به طور دقیق شروط KYC، لیست سیاه هویتی و وضعیت حساب کاربران را ممیزی کرد.' : 'خطا در اهلیت معامله.'
            ];
        } catch (\Throwable $e) {
            $results['VT-09'] = ['status' => 'FAILED', 'title' => 'VT-09 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── Render View ───
        $this->view('user/vitrine/my-listings', [
            'title'   => 'ارزیابی حرفه‌ای و مرورگرمحور بازار دیجیتال ویترین (Section 12 Vitrine Master Verification 🆕 ⭐)',
            'results' => $results,
        ]);
    }

}
