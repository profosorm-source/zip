<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Policies\RateLimitPolicy;
use App\Controllers\User\BaseUserController;
use App\Services\DirectMessageService;
use App\Services\MessageModerationService;
use App\Validators\Requests\SendMessageRequest;

/**
 * MessageController - مدیریت پیام‌های مستقیم کاربران
 */
class MessageController extends BaseUserController
{
    private DirectMessageService $messageService;
    private \App\Services\UploadService $uploadService;
    /** 🧹 DI-CLEANUP (2026-08-24): به‌جای app(RateLimiter::class) — TODO قدیمی حذف شد. */
    private \Core\RateLimiter $rateLimiter;
    /** فاز G (تسک ۸۳): سرویس گزارش تخلف پیام */
    private MessageModerationService $moderationService;

    public function __construct(
        DirectMessageService $messageService,
        \App\Services\UploadService $uploadService,
        \Core\Session $session,
        \Core\Request $request,
        \Core\Response $response,
        \App\Services\Shared\PolicyService $policyService,
        \App\Contracts\LoggerInterface $logger,
        \App\Services\Auth\AuthService $authService,
        \App\Services\User\UserService $userService,
        \App\Services\CaptchaService $captchaService,
        \Core\RateLimiter $rateLimiter,
        ?MessageModerationService $moderationService = null
    ) {
        parent::__construct($session, $request, $response, $policyService, $logger, $authService, $userService, $captchaService);
        $this->messageService = $messageService;
        $this->uploadService = $uploadService;
        $this->rateLimiter = $rateLimiter;
        $this->moderationService = $moderationService ?? app(MessageModerationService::class);
    }

    /**
     * لیست conversations
     */
    public function index(): void
    {
        $this->requireAuth();

        try {
            $userId = (int)$this->userId();
            $page = int_value($this->request->query('page') ?? 1);
            $limit = 20;
            $offset = ($page - 1) * $limit;

            $conversations = $this->messageService->getConversations($userId, $limit, $offset);
            $unreadTotal = $this->messageService->getUnreadCount($userId);

            $this->view('user/messages/index', [
                'conversations' => $conversations,
                'unread_total' => $unreadTotal,
                'page' => $page
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('messages.index.failed', ['error' => $e->getMessage()]);
            $this->response->error('خطا در بارگذاری پیام‌ها');
        }
    }

    /**
     * نمایش conversation
     */
    public function show(): void
    {
        $this->requireAuth();

        try {
            $userId = (int)$this->userId();
            $otherUserId = (int)$this->request->param('id');
            $page = int_value($this->request->query('page') ?? 1);
            $limit = 50;
            $offset = ($page - 1) * $limit;

            if ($userId === $otherUserId) {
                $this->response->error('نمی‌توانید برای خودتان پیام بفرستید');
                return;
            }

            $otherUser = $this->messageService->getUserInfo($otherUserId, $userId);

            if (!$otherUser) {
                $this->response->error('مکالمه‌ای با کاربر مورد نظر یافت نشد.', [], 404);
                return;
            }

            // 🛡️ HIGH-06: جلوگیری از نمایش مکالمه‌های خالی یا ثبت سوابق نامطلوب بدون تاریخچه معتبر بین طرفین
            if (!$this->messageService->hasConversation($userId, $otherUserId)) {
                $this->response->error('مکالمه‌ای با کاربر مورد نظر یافت نشد.', [], 404);
                return;
            }

            $messages = $this->messageService->getConversation(
                $userId,
                $otherUserId,
                $limit,
                $offset
            );

            // 🛡️ FIX-R77-O1 (R78): پیوست‌های همین صفحهٔ مکالمه — گروه‌بندی بر اساس message_id
            $attachmentsByMessage = [];
            $messageIds = array_map(static function ($m) { return int_value($m['id'] ?? 0); }, is_array($messages) ? $messages : []);
            $messageIds = array_values(array_filter($messageIds, static function ($id) { return $id > 0; }));
            if ($messageIds !== []) {
                foreach ($this->messageService->getAttachmentsForMessages($messageIds) as $att) {
                    $attachmentsByMessage[(int)$att->message_id][] = $att;
                }
            }

            // Opening a conversation is the authoritative read boundary.
            // Persist both is_read/read_at and clear its Redis unread counter.
            $this->messageService->markAsRead($userId, $otherUserId);

            $this->view('user/messages/show', [
                'messages' => $messages,
                'attachments_by_message' => $attachmentsByMessage,
                'other_user' => $otherUser,
                // 🛡️ FIX-S30-09 (R75): وضعیت مسدودی برای دکمهٔ هدر چت
                'blocked_by_me' => $this->messageService->isBlockedBy($userId, $otherUserId),
                'page' => $page
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('messages.show.failed', ['error' => $e->getMessage()]);
            $this->response->error('خطا در بارگذاری conversation');
        }
    }

    /**
     * ارسال پیام
     */
    public function send(): void
    {
        $this->requireAuth();

        try {
            $userId = (int)$this->userId();

            // 🛡️ Rate Limit: حداکثر ۳۰ پیام در دقیقه برای هر کاربر
            $rateLimiter = $this->rateLimiter;
            if (!$rateLimiter->attempt("dm_send:{$userId}", 30, 60, true)) {
                $this->jsonError('تعداد پیام‌های ارسالی بیش از حد مجاز است. لطفاً کمی صبر کنید.', [], 429);
                return;
            }

            $recipientId = $this->request->int('recipient_id');
            if ($recipientId <= 0) {
                $recStr = str_value($this->request->input('recipient') ?? $this->request->input('recipient_id'));
                if ($recStr !== '') {
                    $recUser = $this->userService->findByCredentials($recStr);
                    if ($recUser) {
                        $recipientId = (int)$recUser->id;
                    }
                }
            }
            $message = trim($this->request->str('message'));
            $isEncrypted = (bool)$this->request->input('is_encrypted', false);

            // اعتبارسنجی
            $formRequest = new SendMessageRequest([
                'recipient_id' => $recipientId,
                'message'      => $message,
                'is_encrypted' => $isEncrypted ? 1 : 0,
            ]);
            if (!$formRequest->validate()) {
                $errors = $formRequest->errors();
                $firstValue = reset($errors);
                $firstError = is_array($firstValue) ? reset($firstValue) : $firstValue;
                $this->jsonError($firstError ?: 'اطلاعات ورودی نامعتبر است', $errors, 422);
                return;
            }
            $validated = $formRequest->safeValidated();
            $recipientId = int_value($validated['recipient_id'] ?? $recipientId);
            $message     = str_value($validated['message'] ?? $message);

            // Attachments
            $attachments = [];
            if ($this->request->hasFiles()) {
                // FIX-R36-W3 (F-A16-04): گارد سقف ۵ پیوست قبل از هر آپلود.
                // پیش‌تر همهٔ فایل‌ها روی دیسک نوشته می‌شد و سپس
                // DirectMessageCommandService::MAX_ATTACHMENTS_PER_MESSAGE کل پیام را
                // رد می‌کرد → فایل‌های یتیم بدون cleanup روی دیسک می‌ماندند.
                // (هم‌خانوادهٔ F-A13 orphan-KYC). همین پیام/کد سرویس، بدون آپلود.
                $incoming = $this->request->files();
                if ($this->countIncomingFiles($incoming) > 5) {
                    $this->jsonError('حداکثر ۵ پیوست مجاز است', [], 422);
                    return;
                }
                $attachments = $this->handleAttachments($incoming);
            }

            // ارسال پیام
            $result = $this->messageService->sendMessage(
                $userId,
                $recipientId,
                $message,
                $attachments,
                $isEncrypted
            );

            if (isset($result['error'])) {
                // 🛡️ FIX-S30-03 (R74): سرویس پیام را بعد از آپلود رد می‌کند (محتوای
                // ممنوع، بلاک، ریت‌لیمیت، idempotent replay) — تا ۵×۱۰MB در هر
                // درخواست یتیم می‌شد. پاکسازی همان‌جا.
                $this->cleanupOrphanUploads(array_column($attachments, 'path'), 'dm.send');
                $this->jsonError(str_value($result['error']), [], 422);
                return;
            }

            $this->logger->info('message.sent_by_user', [
                'user_id' => $userId,
                'recipient_id' => $recipientId,
                'message_id' => $result['message_id']
            ]);

            $this->jsonSuccess('', $result);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('message.send.failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا در ارسال پیام', [], 500);
        }
    }

    /**
     * مسدود کردن کاربر (🛡️ FIX-S30-09 — R75)
     */
    public function block(): void
    {
        $this->requireAuth();
        $this->validateCsrf();
        $userId = (int)$this->userId();
        $targetId = $this->request->int('user_id');

        $result = $targetId > 0
            ? $this->messageService->blockUser($userId, $targetId)
            : ['success' => false, 'message' => 'شناسه کاربر نامعتبر است.'];

        session()->setFlash($result['success'] ? 'success' : 'error', str_value($result['message'] ?? ''));
        redirect('/messages/' . max(1, $targetId));
    }

    /**
     * رفع مسدودی کاربر (🛡️ FIX-S30-09 — R75)
     */
    public function unblock(): void
    {
        $this->requireAuth();
        $this->validateCsrf();
        $userId = (int)$this->userId();
        $targetId = $this->request->int('user_id');

        $result = $targetId > 0
            ? $this->messageService->unblockUser($userId, $targetId)
            : ['success' => false, 'message' => 'شناسه کاربر نامعتبر است.'];

        session()->setFlash($result['success'] ? 'success' : 'error', str_value($result['message'] ?? ''));
        redirect('/messages/' . max(1, $targetId));
    }

    /**
     * typing indicator
     */
    public function setTyping(): void
    {
        $this->requireAuth();
        $this->validateCsrf();

        try {
            $userId = (int)$this->userId();
            $recipientId = $this->request->int('recipient_id');
            $isTyping = (bool)$this->request->input('is_typing', true);

            // 🛡️ NEW-15: اعمال محدودیت نرخ بروزرسانی وضعیت تایپ (محدودیت ۲۰ درخواست در دقیقه جهت جلوگیری از فالس پوزیتیو)
            $rateLimiter = $this->rateLimiter;
            $rateLimitId = "typing_limit:" . $userId;
            if (!$rateLimiter->attempt($rateLimitId, 20, 60, true)) {
                $this->jsonError('تعداد درخواست‌های تایپ بیش از حد مجاز است.', [], 429);
                return;
            }

            $this->messageService->setTyping($userId, $recipientId, $isTyping);

            $this->jsonSuccess('', ['ok' => true]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('typing.set.failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا', [], 500);
        }
    }

    /**
     * دریافت typing users
     */
    public function getTypingUsers(): void
    {
        $this->requireAuth();

        try {
            $userId = (int)$this->userId();

            // 🛡️ FIX-S30-24 (R77): پارامتر اختیاری from — کلید مستقیم به‌جای SCAN
            $fromUserId = $this->request->int('recipient_id');
            $typingUsers = $this->messageService->getTypingUsers(
                $userId,
                $fromUserId > 0 ? $fromUserId : null
            );

            $this->jsonSuccess('', [
                'typing_users' => $typingUsers,
                'count' => count($typingUsers)
            ]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('typing.get.failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا', [], 500);
        }
    }

    /**
     * حذف پیام
     */
    public function delete(): void
    {
        $this->requireAuth();

        try {
            // CORE-036: CSRF Protection
            $this->validateCsrf();

            $userId = (int)$this->userId();
            $messageId = (int)$this->request->param('id');

            $success = $this->messageService->deleteMessage($messageId, $userId);

            if (!$success) {
                $this->jsonError('پیام یافت نشد', [], 404);
                return;
            }

            $this->jsonSuccess('پیام با موفقیت حذف شد', ['ok' => true]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('message.delete.failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا در حذف پیام', [], 500);
        }
    }

    /**
     * اضافه کردن reaction
     */
    public function addReaction(): void
    {
        $this->requireAuth();
        $this->validateCsrf();

        try {
            // 🛡️ FIX-N15 (R78): سقف واکنش‌ها — قبلاً بی‌سقف بود (۳۰ در دقیقه).
            \App\Policies\RateLimitPolicy::enforce('dm_message_reaction', (int)$this->userId(), true);
            $userId = (int)$this->userId();
            $messageId = (int)$this->request->param('id');
            $emoji = trim($this->request->str('emoji'));

            // 🛡️ NEW-14: اعتبارسنجی ورودی واکنش‌ها بر اساس لیست سفید اموجی‌های مجاز
            $allowedEmojis = ['👍', '❤️', '😂', '😮', '😢', '🙏', '👏', '🎉'];
            if (!in_array($emoji, $allowedEmojis, true)) {
                $this->jsonError('واکنش نامعتبر است.', [], 422);
                return;
            }

            $success = $this->messageService->addReaction($messageId, $userId, $emoji);

            if (!$success) {
                $this->jsonError('خطا در اضافه کردن reaction', [], 422);
                return;
            }

            $this->jsonSuccess('واکنش با موفقیت ثبت شد', ['ok' => true]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('reaction.add.failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا', [], 500);
        }
    }

    /**
     * FIX-R36-W3 (F-A16-04): شمارش فایل‌های ورودی بدون آپلود — همان نرمال‌سازی
     * handleAttachments (تک‌فایل در برابر multi-upload `field[]`) فقط برای count.
     * @param array<string, mixed> $files
     */
    private function countIncomingFiles(array $files): int
    {
        $count = 0;
        foreach ($files as $file) {
            if (!is_array($file) || !isset($file['name'])) {
                continue;
            }
            if (is_array($file['name'])) {
                $count += count($file['name']);
            } else {
                $count++;
            }
        }
        return $count;
    }

    /**
     * مدیریت پیوست‌ها با استفاده از UploadService
     * @param array<string, mixed> $files
     * @return list<array<string, mixed>>
     */
    private function handleAttachments(array $files): array
    {
        $attachments = [];
        
        // اگر چند فایل باشد
        if (isset($files['name']) && !is_array($files['name'])) {
            $files = [$files];
        }

        foreach ($files as $file) {
            if (!is_array($file)) {
                continue;
            }
            $result = $this->uploadService->upload(
                $file, 
                'messages', 
                // PDF FIX: allow images + PDF only. ZIP is intentionally NOT permitted.
                ['jpg', 'png', 'jpeg', 'pdf'], 
                10 * 1024 * 1024 // 10MB
            );

            if ($result['success']) {
                // FIX-S26-P1-2 (قرارداد کانونی پیوست DM): قرارداد اعتبارسنجی
                // DirectMessageCommandService کلیدهای name/path/size را می‌خواهد؛
                // کلیدهای قبلی (filename/file_path/file_size/mime_type) باعث ۴۲۲
                // همیشگی برای هر پیام وبِ پیوست‌دار می‌شد. مقادیر از خروجی
                // UploadService (متادیتای سرورمحور: نام ذخیره‌شده/مسیر نسبی/اندازه/
                // mime واقعی finfo) خوانده می‌شود، نه ورودی خام کلاینت.
                $attachments[] = [
                    'name'      => str_value($result['filename'] ?? ''),
                    'path'      => str_value($result['path'] ?? ''),
                    'size'      => int_value($result['size'] ?? 0),
                    'mime_type' => str_value($result['mime'] ?? ''),
                ];
            }
        }

        return $attachments;
    }

    /** 🛡️ FIX-S30-03 (R74): پاکسازی فایل‌های یتیمِ آپلودشده وقتی سرویس
     *  بعد از آپلود، درخواست را رد می‌کند.
     *  @param array<int, mixed> $paths */
    private function cleanupOrphanUploads(array $paths, string $context): void
    {
        foreach ($paths as $path) {
            if (!is_string($path) || $path === '') {
                continue;
            }
            $real = $this->uploadService->getPath($path);
            if ($real !== null && is_file($real)) {
                @unlink($real);
                $this->logger->info('upload.orphan_cleaned', ['context' => $context, 'path' => $path]);
            }
        }
    }

    /**
     * دریافت تعداد پیام‌های خوانده نشده
     */
    /**
     * 🛡️ FIX-R77-O1 (R78): دانلود پیوست پیام مستقیم — فقط فرستنده/گیرنده.
     * مسیر از DB خوانده و با UploadService (containment) رزول می‌شود؛
     * هیچ مسیری از کلاینت قبول نمی‌شود و filename در هدر sanitize می‌شود.
     */
    public function downloadAttachment(int $attachmentId): void
    {
        $this->requireAuth();
        $userId = (int)$this->userId();

        try {
            $row = $this->messageService->getAttachmentWithMessage($attachmentId);

            if (!$row || ((int)$row->sender_id !== $userId && (int)$row->recipient_id !== $userId)) {
                $this->jsonError('پیوست یافت نشد.', [], 404);
                return;
            }

            $real = $this->uploadService->getPath(str_value($row->file_path ?? ''));
            if ($real === null || !is_file($real)) {
                $this->jsonError('فایل پیوست در سرور یافت نشد.', [], 404);
                return;
            }

            $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', str_value($row->filename ?? 'attachment')) ?: 'attachment';
            $this->response->header('Content-Type', str_value($row->mime_type ?: 'application/octet-stream'));
            $this->response->header('Content-Length', (string)filesize($real));
            $this->response->header('Content-Disposition', 'attachment; filename="' . $safeName . '"');
            $this->response->header('X-Content-Type-Options', 'nosniff');
            readfile($real);
            exit;
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('dm.attachment.download_failed', ['id' => $attachmentId, 'error' => $e->getMessage()]);
            $this->jsonError('خطا در دریافت پیوست.', [], 500);
        }
    }

    public function getUnreadCount(): void
    {
        $this->requireAuth();

        try {
            $userId = (int)$this->userId();
            $count = $this->messageService->getUnreadCount($userId);

            $this->jsonSuccess('', ['count' => $count]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('unread.count.failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا', [], 500);
        }
    }

    /**
     * علامت‌گذاری پیام‌ها به عنوان خوانده شده (HIGH-03)
     */
    public function markRead(): void
    {
        $this->requireAuth();
        $this->validateCsrf();

        try {
            $otherUserId = $this->request->int('user_id');
            if ($otherUserId <= 0) {
                $this->jsonError('شناسه کاربر نامعتبر است', [], 400);
                return;
            }

            $this->messageService->markAsRead((int)$this->userId(), $otherUserId);
            $this->jsonSuccess('پیام‌ها به عنوان خوانده شده علامت‌گذاری شدند');
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('mark.read.failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا در علامت‌گذاری پیام‌ها', [], 500);
        }
    }

    /**
     * فاز G (تسک ۸۳): گزارش تخلف پیام — POST /messages/{id}/report
     * صف بررسی ادمین (/admin/messages/reports) تاکنون بدون منبع ثبت بود.
     */
    public function report(int $id): void
    {
        $this->requireAuth();
        $this->validateCsrf();

        try {
            $userId = (int)$this->userId();

            // 🛡️ FIX-N15 (R78): سقف گزارش تخلف — قبلاً بی‌سقف بود و می‌شد صف
            // بررسی ادمین را غرق کرد (۱۰ گزارش در دقیقه به‌ازای کاربر).
            \App\Policies\RateLimitPolicy::enforce('dm_message_report', $userId, true);
            $input = is_array($this->request->input()) ? $this->request->input() : [];
            $reason = trim(str_value($input['reason'] ?? ''));

            if ($id <= 0) {
                $this->jsonError('شناسه پیام نامعتبر است', [], 422);
                return;
            }
            if (mb_strlen($reason) < 3 || mb_strlen($reason) > 255) {
                $this->jsonError('دلیل گزارش باید بین ۳ تا ۲۵۵ کاراکتر باشد', [], 422);
                return;
            }

            // 🛡️ FIX-R78/PHPStan: castهای ایمن (این خطوط قبلاً در baseline بودند؛
            // شیفت خطوطِ متدهای جدید R78 آن‌ها را بیرون انداخت — حالا تمیزِ واقعی).
            $result = $this->moderationService->submitReport($userId, int_value($id), $reason);

            if (!empty($result['success'])) {
                $this->jsonSuccess(str_value($result['message'] ?? 'گزارش ثبت شد.'), ['report_id' => int_value($result['report_id'] ?? 0)]);
            } else {
                $this->jsonError(str_value($result['message'] ?? 'خطا در ثبت گزارش.'), [], 422);
            }
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('messages.report.failed', ['error' => $e->getMessage()]);
            $this->jsonError('خطا در ثبت گزارش.', [], 500);
        }
    }

}