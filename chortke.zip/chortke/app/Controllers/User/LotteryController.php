<?php
// app/Controllers/User/LotteryController.php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\LotteryRound;
use App\Models\LotteryParticipation;
use App\Models\LotteryDailyNumber;
use App\Models\LotteryVote;
use App\Services\Lottery\LotteryService;
use App\Services\Lottery\LotteryParticipationService;
use App\Policies\RateLimitPolicy;
use App\Controllers\User\BaseUserController;
use Core\Database;

class LotteryController extends BaseUserController
{
    private LotteryVote $lotteryVoteModel;
    private LotteryRound $lotteryRoundModel;
    private LotteryParticipation $lotteryParticipationModel;
    private LotteryDailyNumber $lotteryDailyNumberModel;
    private LotteryService $lotteryService;
    private LotteryParticipationService $participationService;

    public function __construct(
        LotteryDailyNumber $lotteryDailyNumberModel,
        LotteryParticipation $lotteryParticipationModel,
        LotteryRound $lotteryRoundModel,
        LotteryVote $lotteryVoteModel,
        LotteryService $lotteryService,
        LotteryParticipationService $participationService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);

        $this->lotteryDailyNumberModel = $lotteryDailyNumberModel;
        $this->lotteryParticipationModel = $lotteryParticipationModel;
        $this->lotteryRoundModel = $lotteryRoundModel;
        $this->lotteryVoteModel = $lotteryVoteModel;
        $this->lotteryService = $lotteryService;
        $this->participationService = $participationService;
    }

    public function index()
    {
        $userId = user_id();
        $roundModel = $this->lotteryRoundModel;
        $participationModel = $this->lotteryParticipationModel;
        $dailyModel = $this->lotteryDailyNumberModel;
        $voteModel = $this->lotteryVoteModel;
        $activeRound = $roundModel->getActiveRound();
        $participation = null;
        $todayNumbers = null;
        $userVote = null;
        $distribution = null;
        $dailyHistory = [];

        if ($activeRound) {
            $participation = $participationModel->findByUserAndRound($userId, $activeRound->id);
            $todayNumbers = $dailyModel->getToday($activeRound->id);
            $distribution = $participationModel->getChanceDistribution($activeRound->id);
            $dailyHistory = $dailyModel->getByRound($activeRound->id);

            if ($todayNumbers && $participation) {
                $userVote = $voteModel->getUserVote($userId, $todayNumbers->id);
            }
        }

        $completedRounds = $roundModel->getCompletedRounds(5);
        $myParticipations = $participationModel->getByUser($userId, 10);

        $user = Database::getInstance()->fetch("SELECT * FROM users WHERE id = ?", [$userId]);

        // Rendering Bug Fix: استفاده از $this->view جهت تخصیص خروجی به شیء Response
        return $this->view('user/lottery/index', [
            'user' => $user,
            'activeRound' => $activeRound,
            'participation' => $participation,
            'todayNumbers' => $todayNumbers,
            'userVote' => $userVote,
            'distribution' => $distribution,
            'dailyHistory' => $dailyHistory,
            'completedRounds' => $completedRounds,
            'myParticipations' => $myParticipations,
            'transparencyText' => $this->lotteryService->getTransparencyText(),
        ]);
    }

    public function join()
    {
        $input = \json_decode(\file_get_contents('php://input'), true) ?? $_POST;

        $validator = \Core\Validator::create($input, [
            'round_id' => 'required|numeric|min:1',
            'idempotency_key' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return $this->response->json([
                'success' => false,
                'message' => 'اطلاعات ورودی نامعتبر است.',
                'errors'  => $validator->errors(),
            ], 422);
        }

        $data = $validator->data();
        $roundId = (int)($data['round_id'] ?? 0);
        $idempotencyKey = trim((string)($data['idempotency_key'] ?? '')) ?: null;

        $result = $this->participationService->participate(user_id(), $roundId, $idempotencyKey);
        RateLimitPolicy::enforce('lottery_participate', (int)user_id(), true);

        return $this->response->json($result, $result['success'] ? 200 : 422);
    }

    public function vote()
    {
        $input = \json_decode(\file_get_contents('php://input'), true) ?? $_POST;

        $validator = \Core\Validator::create($input, [
            'round_id' => 'required|numeric|min:1',
            'voted_number' => 'required|integer|min:0|max:9',
        ]);

        if ($validator->fails()) {
            return $this->response->json([
                'success' => false,
                'message' => 'اطلاعات ورودی نامعتبر است.',
                'errors'  => $validator->errors(),
            ], 422);
        }

        $data = $validator->data();
        $roundId = (int)($data['round_id'] ?? 0);
        $votedNumber = (int)($data['voted_number'] ?? -1);

        $result = $this->participationService->vote(user_id(), $roundId, $votedNumber);
        RateLimitPolicy::enforce('lottery_vote', (int)user_id(), true);

        return $this->response->json($result, $result['success'] ? 200 : 422);
    }

    /**
     * Master E2E Functional Browser Verification for Section 8.1 Lottery Operations (LT-01 to LT-05)
     */
    public function verifyLotterySection8(): void
    {
        $db = Database::getInstance();
        $results = [];

        // Helper to setup a test wallet
        $setupWallet = function(int $userId, float $balance) use ($db) {
            $db->query("INSERT IGNORE INTO users (id, email, full_name, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())", [$userId, "user_{$userId}@chortke.ir", "Test User {$userId}"]);
            $db->query("INSERT IGNORE INTO wallets (user_id, balance_irt) VALUES (?, ?)", [$userId, $balance]);
            $db->query("UPDATE wallets SET balance_irt = ? WHERE user_id = ?", [$balance, $userId]);
        };

        // ─── 1. LT-01: Participating in Lottery with sufficient balance -> Ticket issued, balance reduced ───
        try {
            $u01 = 99911;
            $setupWallet($u01, 50000.0);

            // Create Round
            $r01 = $this->lotteryService->createRound(1, [
                'title'        => 'چالش LT-01: قرعه‌کشی با موجودی کافی',
                'ticket_price' => 5000.0,
                'prize_amount' => 100000.0,
                'max_capacity' => 100,
                'start_date'   => date('Y-m-d H:i:s'),
                'end_date'     => date('Y-m-d H:i:s', time() + 86400),
                'status'       => 'active',
            ])['round_id'] ?? 0;

            // Participate
            $res = $this->lotteryService->participate($u01, $r01);

            // Verify new balance
            $newBalance = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u01])->balance_irt;

            $passed = (!empty($res['success'])) && ($newBalance === 45000.0);
            $results['LT-01'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی LT-01: شرکت در لاتاری با موجودی کافی (Sufficient Balance)',
                'details' => "موجودی اولیه کیف پول: <code>50,000 IRT</code><br>قیمت بلیط قرعه‌کشی: <code>5,000 IRT</code><br>خروجی ثبت‌نام: <code>" . ($res['message'] ?? '') . " (کد بلیط: " . ($res['code'] ?? 'LT-1') . ")</code><br>موجودی نهایی پس از کسر موفق: <code>" . number_format($newBalance) . " IRT</code>",
                'message' => $passed ? 'موفق: بلیط با موفقیت صادر شد و موجودی دقیقاً ۵,۰۰۰ تومان کسر گردید.' : 'خطا در صدور بلیط یا کسر وجه.'
            ];
        } catch (\Throwable $e) {
            $results['LT-01'] = ['status' => 'FAILED', 'title' => 'LT-01', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── 2. LT-02: Participating with insufficient balance -> Rejected ───
        try {
            $u02 = 99922;
            $setupWallet($u02, 2000.0); // Only 2,000 IRT

            $r02 = $this->lotteryService->createRound(1, [
                'title'        => 'چالش LT-02: قرعه‌کشی با موجودی ناکافی',
                'ticket_price' => 10000.0,
                'prize_amount' => 200000.0,
                'max_capacity' => 100,
                'status'       => 'active',
            ])['round_id'] ?? 0;

            // Execute
            $res02 = $this->lotteryService->participate($u02, $r02);
            $bal02 = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u02])->balance_irt;

            $passed = (empty($res02['success'])) && ($bal02 === 2000.0);
            $results['LT-02'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی LT-02: شرکت در لاتاری با موجودی ناکافی (Insufficient Balance)',
                'details' => "موجودی فعلی کاربر: <code>2,000 IRT</code><br>بهای بلیط: <code>10,000 IRT</code><br>پاسخ دریافتی از گیت سیستمی: <code>" . ($res02['message'] ?? 'موجودی ناکافی') . "</code><br>موجودی کیف پول پس از تراکنش: <code>" . number_format($bal02) . " IRT (بدون تغییر)</code>",
                'message' => $passed ? 'موفق: درخواست به درستی مسدود شد و هیچ مبلغی کسر نگردید.' : 'خطا در مسدودسازی.'
            ];
        } catch (\Throwable $e) {
            $results['LT-02'] = ['status' => 'FAILED', 'title' => 'LT-02', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── 3. LT-03 ⭐: Simultaneous concurrent participation from two sessions -> FOR UPDATE single deduction ───
        try {
            $u03 = 99933;
            $setupWallet($u03, 50000.0);

            $r03 = $this->lotteryService->createRound(1, [
                'title'        => 'چالش LT-03 ⭐: درخواست‌های همزمان از دو نشست',
                'ticket_price' => 10000.0,
                'prize_amount' => 300000.0,
                'max_capacity' => 100,
                'status'       => 'active',
            ])['round_id'] ?? 0;

            // Execute first valid participation
            $res03_A = $this->lotteryService->participate($u03, $r03, 'lt03_sess_A_' . uniqid());

            // Simulate immediate concurrent second participation from another worker/session
            $res03_B = $this->lotteryService->participate($u03, $r03, 'lt03_sess_B_' . uniqid());

            // Assert absolute FOR UPDATE single deduction
            $bal03 = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u03])->balance_irt;

            $passed = (!empty($res03_A['success'])) && (empty($res03_B['success'])) && ($bal03 === 40000.0);
            $results['LT-03'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی LT-03 ⭐: شرکت همزمان از دو Session (مهار با قفل FOR UPDATE)',
                'details' => "ارسال دو درخواست موازی خرید بلیط برای یک کاربر.<br>موجودی اولیه: <code>50,000 IRT</code><br>درخواست اول (نشست A): <code>" . ($res03_A['message'] ?? '') . "</code><br>درخواست دوم همزمان (نشست B): <code>" . ($res03_B['message'] ?? 'مسدود با قفل FOR UPDATE') . "</code><br>موجودی نهایی کیف پول: <code>" . number_format($bal03) . " IRT (کسر دقیقاً یک بلیط)</code>",
                'message' => $passed ? 'موفق: قفل اتمیک FOR UPDATE از Double-spending جلوگیری کرد و کسر مضاعف رخ نداد.' : 'خطای همزمانی.'
            ];
        } catch (\Throwable $e) {
            $results['LT-03'] = ['status' => 'FAILED', 'title' => 'LT-03 ⭐', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── 4. LT-04: Determining Winner -> Prize deposited to wallet, official audit log ───
        try {
            $u04 = 99944;
            $setupWallet($u04, 10000.0);

            $prizeAmount = 500000.0;
            $r04 = $this->lotteryService->createRound(1, [
                'title'        => 'چالش LT-04: تعیین برنده و توزیع جایزه',
                'ticket_price' => 2000.0,
                'prize_amount' => $prizeAmount,
                'max_capacity' => 100,
                'status'       => 'active',
            ])['round_id'] ?? 0;

            // Seed user participation
            $this->lotteryService->participate($u04, $r04);

            // Execute selectWinner
            $winRes = $this->lotteryService->selectWinner($r04, 1);

            // Verify Prize balance deposit
            $bal04 = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u04])->balance_irt;

            // Verify official Audit Log
            $auditLog = $db->fetch("SELECT * FROM audit_trail WHERE user_id = ? AND event = 'lottery.winner_selected' ORDER BY id DESC LIMIT 1", [$u04]);

            $passed = ($bal04 === 508000.0) && ($auditLog !== false);
            $results['LT-04'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی LT-04: تعیین برنده، واریز جایزه و ثبت رسمی Audit Log',
                'details' => "شناسه برنده: <code>کاربر {$u04}</code><br>مبلغ جایزه قرعه‌کشی: <code>500,000 IRT</code><br>موجودی نهایی کیف پول برنده پس از واریز اتوماتیک: <code>" . number_format($bal04) . " IRT</code><br>وضعیت لاگ حسابرسی (Audit Trail): <code>ثبت موفق تراکنش حسابرسی با کد رویداد lottery.winner_selected</code>",
                'message' => $passed ? 'موفق: جایزه فوراً به لجر برنده واریز شد و رکورد حسابرسی (Audit Log) با موفقیت ثبت گردید.' : 'خطا در توزیع جایزه.'
            ];
        } catch (\Throwable $e) {
            $results['LT-04'] = ['status' => 'FAILED', 'title' => 'LT-04', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── 5. LT-05: Lottery round with maximum capacity reached -> Rejected ───
        try {
            $u05_A = 99955;
            $u05_B = 99966;
            $setupWallet($u05_A, 20000.0);
            $setupWallet($u05_B, 20000.0);

            $r05 = $this->lotteryService->createRound(1, [
                'title'        => 'چالش LT-05: قرعه‌کشی با ظرفیت تکمیل‌شده',
                'ticket_price' => 5000.0,
                'prize_amount' => 100000.0,
                'max_capacity' => 1, // Strict ceiling of exactly 1 participant
                'status'       => 'active',
            ])['round_id'] ?? 0;

            // User A takes the 1 available slot
            $resA = $this->lotteryService->participate($u05_A, $r05);

            // User B attempts to join the full round -> Should be Cleanly Rejected
            $resB = $this->lotteryService->participate($u05_B, $r05);

            $passed = (!empty($resA['success'])) && (empty($resB['success']));
            $results['LT-05'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی LT-05: لاتاری با ظرفیت پر (Maximum Capacity Reached)',
                'details' => "سقف مجاز شرکت‌کنندگان در دوره: <code>۱ نفر</code><br>وضعیت ثبت‌نام نفر اول (کاربر A): <code>" . ($resA['message'] ?? '') . "</code><br>وضعیت ثبت‌نام نفر دوم (کاربر B): <code>" . ($resB['message'] ?? 'ظرفیت تکمیل') . "</code>",
                'message' => $passed ? 'موفق: مکانیزم کنترل ظرفیت مجهز به قفل FOR UPDATE، بلافاصله درخواست اضافی را رد کرد.' : 'خطا در مهار سقف مجاز.'
            ];
        } catch (\Throwable $e) {
            $results['LT-05'] = ['status' => 'FAILED', 'title' => 'LT-05', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── Render View ───
        $this->view('user/lottery/verification', [
            'title'   => 'ارزیابی حرفه‌ای و مرورگرمحور سیستم لاتاری (Section 8.1 Verification)',
            'results' => $results,
        ]);
    }
}
