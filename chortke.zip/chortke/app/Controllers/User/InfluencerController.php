<?php

namespace App\Controllers\User;

use App\Models\InfluencerModel;
use App\Models\StoryOrder;
use App\Models\Dispute;

use App\Services\InfluencerService;
use App\Services\Shared\DisputeService;
use App\Services\ScoreService;
use App\Services\UploadService;
use App\Services\VerificationService;
use Core\Logger;
use Core\Database;

class InfluencerController extends BaseUserController
{
    private InfluencerModel           $profileModel;
    private StoryOrder                  $orderModel;
    private Dispute           $disputeModel;
    private InfluencerModel             $reputationModel;
    private InfluencerService       $promotionService;
    private DisputeService              $disputeService;
    private ScoreService $scoreService;
    private VerificationService         $verificationService;
    private UploadService               $upload;
    // $logger inherited from parent

    public function __construct(
        InfluencerModel           $profileModel,
        StoryOrder                  $orderModel,
        Dispute           $disputeModel,
        InfluencerModel             $reputationModel,
        InfluencerService       $promotionService,
        DisputeService              $disputeService,
        ScoreService $scoreService,
        VerificationService         $verificationService,
        UploadService               $upload,
        Logger                      $logger
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->profileModel        = $profileModel;
        $this->orderModel          = $orderModel;
        $this->disputeModel        = $disputeModel;
        $this->reputationModel     = $reputationModel;
        $this->promotionService    = $promotionService;
        $this->disputeService      = $disputeService;
        $this->scoreService = $scoreService;
        $this->verificationService = $verificationService;
        $this->upload              = $upload;
        $this->logger              = $logger;
    }

    // ══════════════════════════════════════════════════════
    //  پروفایل اینفلوئنسر
    // ══════════════════════════════════════════════════════

    public function myProfile(): void
    {
        $userId  = (int) user_id();
        $profile = $this->profileModel->findByUserId($userId);
        $stats   = $profile ? $this->scoreService->getInfluencerStats((int)$profile->id) : null;
        $orders  = $profile ? $this->orderModel->getByInfluencer((int)$profile->user_id, null, 5, 0) : [];
        $verificationStatus = null;
        $verificationCode   = null;

        if ($profile) {
            $verificationStatus = $this->verificationService->getVerificationStatus((int)$profile->id);

            if (in_array($verificationStatus['status'], ['not_started', 'expired'], true)) {
                $generate = $this->verificationService->generateVerificationCode((int)$profile->id);
                if ($generate['ok']) {
                    $verificationCode = $generate['code'];
                    if (empty($profile->verification_code) || $profile->verification_code !== $verificationCode) {
                        $this->profileModel->update((int)$profile->id, ['verification_code' => $verificationCode]);
                        $profile = $this->profileModel->find((int)$profile->id);
                    }
                    $verificationStatus['status'] = 'pending';
                    $verificationStatus['code'] = $verificationCode;
                }
            } else {
                $verificationCode = $verificationStatus['code'] ?? $profile->verification_code ?? null;
            }
        }

        $this->view('user/influencer/my-profile', [
            'title'              => 'پروفایل اینفلوئنسر',
            'profile'            => $profile,
            'stats'              => $stats,
            'orders'             => $orders,
            'platforms'          => $this->platforms(),
            'verificationStatus' => $verificationStatus,
            'verificationCode'   => $verificationCode,
        ]);
    }

    public function register(): void
    {
        $userId = (int) user_id();
        $this->view('user/influencer/register', [
            'title'      => 'ثبت پیج اینفلوئنسر',
            'existing'   => $this->profileModel->findByUserId($userId),
            'categories' => $this->profileModel->categories(),
            'platforms'  => $this->platforms(),
            'priceFields'=> $this->priceFields(),
        ]);
    }

    /**
     * ذخیره پروفایل
     * ✅ File upload validation + ownership check
     */
    public function storeProfile(): void
    {
        $userId = (int) user_id();
        $data   = $this->request->body();

        $request = new \App\Validators\Requests\StoreInfluencerProfileRequest($data);

        if (!$request->validate()) {
            $errors = $request->errors();
            $firstError = reset($errors);
            $msg = is_array($firstError) ? reset($firstError) : $firstError;
            $this->session->setFlash('error', $msg ?: 'اطلاعات ورودی نامعتبر است.');
            redirect(url('/influencer/register'));
            return;
        }

        $validatedData = $request->validated();

        // ✅ File upload validation
        if (!empty($_FILES['profile_image']['name'])) {
            $validation = $this->validateProfileImage($_FILES['profile_image']);
            if (!$validation['valid']) {
                $this->session->setFlash('error', $validation['error']);
                redirect(url('/influencer/register'));
                return;
            }
            
            $up = $this->upload->upload($_FILES['profile_image'], 'influencer');
            if ($up['success']) {
                $validatedData['profile_image'] = $up['path'];
            } else {
                $this->session->setFlash('error', $up['error'] ?? 'خطا در آپلود تصویر.');
                redirect(url('/influencer/register'));
                return;
            }
        }

        $existing = $this->profileModel->findByUserId($userId);
        $platform = $validatedData['platform'] ?? 'instagram';

        // Filter and whitelist safe fields to prevent mass assignment (C-12)
        $allowed = ['platform', 'username', 'bio', 'category', 'follower_count', 'profile_image'];
        $clean = array_intersect_key($validatedData, array_flip($allowed));

        $merged   = array_merge($clean, $this->extractPrices($data, $platform), ['user_id' => $userId]);

        try {
            if ($existing) {
                // Only allow update if owner
                if ((int)$existing->user_id !== $userId) {
                    $this->logger->warning('Unauthorized profile update attempt', [
                        'user_id' => $userId,
                        'profile_owner' => $existing->user_id,
                    ]);
                    http_response_code(403);
                    $this->response->json(['success' => false, 'message' => 'Unauthorized'], 403);
                    return;
                }

                if (in_array($existing->status, ['rejected'])) {
                    $merged['status'] = 'pending';
                    $merged['rejection_reason'] = null;
                }
                $ok  = $this->profileModel->update((int)$existing->id, $merged);
                $msg = $ok ? 'پروفایل بروزرسانی شد.' : 'خطا در بروزرسانی.';
            } else {
                $profile = $this->profileModel->create($merged);
                $ok  = $profile ? true : false;
                $msg = $ok ? 'پروفایل ثبت شد. منتظر تایید ادمین باشید.' : 'خطا در ثبت.';
            }

            if (!$ok) {
                $this->logger->error('influencer.store.failed', ['user_id' => $userId]);
            }

            $this->session->setFlash($ok ? 'success' : 'error', $msg);
        } catch (\Exception $e) {
            $this->logger->error('influencer.store.exception', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
            $this->session->setFlash('error', 'خطای سیستمی.');
        }

        redirect(url('/influencer/my-profile'));
    }

    /**
     * ✅ File upload validation method
     */
  private function validateProfileImage(array $file): array
{
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return ['valid' => false, 'error' => 'فایل آپلود نشد'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'])) {
        return ['valid' => false, 'error' => 'فقط JPG, PNG و WebP مجاز هستند'];
    }

    $maxSize = 2 * 1024 * 1024;
    if ($file['size'] > $maxSize) {
        return ['valid' => false, 'error' => 'حجم فایل بیشتر از 2MB است'];
    }

    return ['valid' => true];
}
    

    /**
     * ثبت لینک پست تایید مالکیت
     */
    public function submitVerification(): void
    {
        $userId  = (int) user_id();
        $postUrl = \trim($this->request->post('post_url') ?? '');

        if (empty($postUrl)) {
            $this->session->setFlash('error', 'لینک پست الزامی است.');
            redirect(url('/influencer'));
            return;
        }

        $profile = $this->profileModel->findByUserId($userId);
        if (!$profile) {
            $this->session->setFlash('error', 'پروفایل اینفلوئنسر یافت نشد.');
            redirect(url('/influencer/register'));
            return;
        }

        $status = $this->verificationService->getVerificationStatus((int)$profile->id);
        if (in_array($status['status'], ['not_started', 'expired'], true)) {
            $generate = $this->verificationService->generateVerificationCode((int)$profile->id);
            if (!$generate['ok']) {
                $this->session->setFlash('error', $generate['error'] ?? 'خطا در تولید کد تایید.');
                redirect(url('/influencer'));
                return;
            }

            if (empty($profile->verification_code) || $profile->verification_code !== $generate['code']) {
                $this->profileModel->update((int)$profile->id, ['verification_code' => $generate['code']]);
                $profile = $this->profileModel->find((int)$profile->id);
            }
        }

        $result = $this->verificationService->submitVerificationProof((int)$profile->id, $userId, $postUrl);
        if ($result['ok']) {
            $this->profileModel->update((int)$profile->id, [
                'status' => 'pending_admin_review',
                'verification_post_url' => $postUrl,
            ]);
        }

        $this->session->setFlash($result['ok'] ? 'success' : 'error', $result['message'] ?? 'خطا در ثبت لینک تایید.');
        redirect(url('/influencer'));
    }

    // ══════════════════════════════════════════════════════
    //  سفارش‌های دریافتی (اینفلوئنسر)
    // ══════════════════════════════════════════════════════

    public function myOrders(): void
    {
        $userId  = (int) user_id();
        $profile = $this->profileModel->findByUserId($userId);

        if (!$profile) {
            $this->session->setFlash('error', 'ابتدا پیج خود را ثبت کنید.');
            redirect(url('/influencer/register'));
            return;
        }

        $page   = \max(1, (int)($this->request->get('page') ?? 1));
        $orders = $this->orderModel->getByInfluencer(
            $userId, null, 20, ($page - 1) * 20
        );

        $this->view('user/influencer/my-orders', [
            'title'        => 'سفارش‌های دریافتی',
            'profile'      => $profile,
            'orders'       => $orders,
            'page'         => $page,
            'statusLabels' => $this->orderModel->statusLabels(),
            'statusClasses'=> $this->orderModel->statusClasses(),
        ]);
    }

    public function respondOrder(): void
    {
        try {
            $id     = (int)($this->request->param('id') ?? 0);
            $action = $this->request->post('action') ?? '';
            $reason = $this->request->post('reason') ?? null;

            $result = $this->promotionService->respondToOrder($id, (int)user_id(), $action, $reason);

            if (is_ajax()) { $this->response->json($result); return; }
            $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        } catch (\Exception $e) {
            $this->logger->error('influencer.respondOrder', ['err' => $e->getMessage()]);
            if (is_ajax()) { $this->response->json(['success' => false, 'message' => 'خطای سیستمی.']); return; }
            $this->session->setFlash('error', 'خطای سیستمی.');
        }
        redirect(url('/influencer/orders'));
    }

    public function submitProof(): void
    {
        try {
            $id        = (int)($this->request->param('id') ?? 0);
            $proofData = [
                'proof_link'  => \trim($this->request->post('proof_link') ?? ''),
                'proof_notes' => \trim($this->request->post('proof_notes') ?? ''),
            ];

            if (!empty($_FILES['proof_screenshot']['name'])) {
                $up = $this->upload->upload($_FILES['proof_screenshot'], 'inf-proof');
                if ($up['success']) $proofData['proof_screenshot'] = $up['path'];
            }

            $result = $this->promotionService->submitProof($id, (int)user_id(), $proofData);

            if (is_ajax()) { $this->response->json($result); return; }
            $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        } catch (\Exception $e) {
            $this->logger->error('influencer.submitProof', ['err' => $e->getMessage()]);
            if (is_ajax()) { $this->response->json(['success' => false, 'message' => 'خطای سیستمی.']); return; }
            $this->session->setFlash('error', 'خطای سیستمی.');
        }
        redirect(url('/influencer/orders'));
    }

    // ══════════════════════════════════════════════════════
    //  پنل اختلاف (هر دو طرف)
    // ══════════════════════════════════════════════════════

    public function disputePanel(): void
    {
        $orderId = (int)($this->request->param('id') ?? 0);
        $userId  = (int) user_id();
        $order   = $this->orderModel->find($orderId);

        if (!$order) {
            $this->session->setFlash('error', 'سفارش یافت نشد.');
            redirect(url('/influencer/orders'));
            return;
        }

        // هر دو طرف می‌توانند این صفحه را ببینند
        $isInfluencer = (int)$order->influencer_user_id === $userId;
        $isCustomer   = (int)$order->customer_id === $userId;

        if (!$isInfluencer && !$isCustomer) {
            $this->session->setFlash('error', 'دسترسی غیرمجاز.');
            redirect(url('/influencer/orders'));
            return;
        }

        $dispute  = $this->disputeModel->findByOrderId($orderId);
        $messages = $dispute ? $this->disputeModel->getMessages((int)$dispute->id) : [];
        $role     = $isInfluencer ? 'influencer' : 'customer';

        $this->view('user/influencer/dispute-panel', [
            'title'    => 'پنل اختلاف',
            'order'    => $order,
            'dispute'  => $dispute,
            'messages' => $messages,
            'role'     => $role,
            'userId'   => $userId,
        ]);
    }

    public function sendDisputeMsg(): void
    {
        try {
            $orderId   = (int)($this->request->param('id') ?? 0);
            $userId    = (int) user_id();
            $order     = $this->orderModel->find($orderId);

            if (!$order) { $this->response->json(['success' => false, 'message' => 'سفارش یافت نشد.']); return; }

            $role    = (int)$order->influencer_user_id === $userId ? 'influencer' : 'customer';
            $dispute = $this->disputeModel->findByOrderId($orderId);
            if (!$dispute) { $this->response->json(['success' => false, 'message' => 'اختلاف یافت نشد.']); return; }

            $message    = \trim($this->request->post('message') ?? '');
            $attachment = null;

            if (!empty($_FILES['attachment']['name'])) {
                $up = $this->upload->upload($_FILES['attachment'], 'dispute-evidence');
                if ($up['success']) $attachment = $up['path'];
            }

            $result = $this->disputeService->sendMessage((int)$dispute->id, $userId, $role, $message, $attachment);
            $this->response->json($result);
        } catch (\Exception $e) {
            $this->logger->error('influencer.sendDisputeMsg', ['err' => $e->getMessage()]);
            $this->response->json(['success' => false, 'message' => 'خطای سیستمی.']);
        }
    }

    public function escalateDispute(): void
    {
        try {
            $orderId = (int)($this->request->param('id') ?? 0);
            $userId  = (int) user_id();
            $dispute = $this->disputeModel->findByOrderId($orderId);

            if (!$dispute) { $this->response->json(['success' => false, 'message' => 'اختلاف یافت نشد.']); return; }

            $result = $this->disputeService->escalateToAdmin((int)$dispute->id, $userId);
            $this->response->json($result);
        } catch (\Exception $e) {
            $this->logger->error('influencer.escalateDispute', ['err' => $e->getMessage()]);
            $this->response->json(['success' => false, 'message' => 'خطای سیستمی.']);
        }
    }

    public function resolveDisputePeer(): void
    {
        try {
            $orderId    = (int)($this->request->param('id') ?? 0);
            $userId     = (int) user_id();
            $resolution = \trim($this->request->post('resolution') ?? '');
            $verdict    = \trim($this->request->post('verdict') ?? 'favor_influencer');
            $dispute    = $this->disputeModel->findByOrderId($orderId);

            if (!$dispute) { $this->response->json(['success' => false, 'message' => 'اختلاف یافت نشد.']); return; }

            $result = $this->disputeService->resolveByAgreement((int)$dispute->id, $userId, $resolution, $verdict);
            $this->response->json($result);
        } catch (\Exception $e) {
            $this->logger->error('influencer.resolveDisputePeer', ['err' => $e->getMessage()]);
            $this->response->json(['success' => false, 'message' => 'خطای سیستمی.']);
        }
    }

    // ══════════════════════════════════════════════════════
    //  تبلیغ‌دهنده — لیست اینفلوئنسرها
    // ══════════════════════════════════════════════════════

    public function advertise(): void
    {
        $filters = [
            'platform' => $this->request->get('platform') ?? '',
            'category' => $this->request->get('category') ?? '',
            'search'   => $this->request->get('search') ?? '',
            'min_followers' => $this->request->get('min_followers') ?? '',
            'max_price'     => $this->request->get('max_price') ?? '',
            'sort'          => $this->request->get('sort') ?? 'priority',
        ];

        $page     = \max(1, (int)($this->request->get('page') ?? 1));
        $limit    = 12;
        $profiles = $this->profileModel->getVerified($filters, $filters['sort'], $limit, ($page - 1) * $limit);
        $total    = $this->profileModel->countVerified($filters);

        // آمار رتبه برای هر پروفایل
        $statsMap = [];
        foreach ($profiles as $p) {
            $statsMap[(int)$p->id] = $this->scoreService->getInfluencerStats((int)$p->id);
        }

        $this->view('user/influencer/ads', [
            'title'      => 'انتخاب اینفلوئنسر',
            'profiles'   => $profiles,
            'statsMap'   => $statsMap,
            'total'      => $total,
            'page'       => $page,
            'pages'      => (int)\ceil($total / $limit),
            'filters'    => $filters,
            'categories' => $this->profileModel->categories(),
            'platforms'  => $this->platforms(),
        ]);
    }

    public function createOrder(): void
    {
        $influencerId = (int)($this->request->get('influencer_id') ?? 0);
        $profile      = $influencerId ? $this->profileModel->find($influencerId) : null;
        $stats        = $profile ? $this->scoreService->getInfluencerStats((int)$profile->id) : null;

        $this->view('user/influencer/create-order', [
            'title'      => 'ثبت سفارش تبلیغ',
            'profile'    => $profile,
            'stats'      => $stats,
            'platforms'  => $this->platforms(),
        ]);
    }

    public function storeOrder(): void
    {
        $userId       = (int) user_id();
        $influencerId = (int)($this->request->post('influencer_id') ?? 0);
        $data         = $this->request->body();

        $validator = \Core\Validator::create($data, [
            'influencer_id' => 'required|numeric|min:1',
            'order_type' => 'required|in:story,post',
            'duration_hours' => 'required|numeric|min:1',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $firstError = reset($errors);
            $msg = is_array($firstError) ? reset($firstError) : $firstError;
            $this->session->setFlash('error', $msg ?: 'اطلاعات ورودی نامعتبر است.');
            redirect(url('/influencer/ads/create?influencer_id=' . $influencerId));
            return;
        }

        $validatedData = $validator->data();

        try {
            if (!empty($_FILES['brief_file']['name'])) {
                $up = $this->upload->upload($_FILES['brief_file'], 'inf-brief');
                if ($up['success']) $validatedData['media_path'] = $up['path'];
            }

            $result = $this->promotionService->createOrder($userId, $influencerId, $validatedData);
            $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
            redirect($result['success']
                ? url('/influencer/ads/my-orders')
                : url('/influencer/ads/create?influencer_id=' . $influencerId)
            );
        } catch (\Exception $e) {
            $this->logger->error('influencer.storeOrder', ['err' => $e->getMessage()]);
            $this->session->setFlash('error', 'خطای سیستمی در ثبت سفارش.');
            redirect(url('/influencer/ads'));
        }
    }

    public function myPlacedOrders(): void
    {
        $userId = (int) user_id();
        $page   = \max(1, (int)($this->request->get('page') ?? 1));
        $orders = $this->orderModel->getByCustomer($userId, null, 20, ($page - 1) * 20);

        $this->view('user/influencer/my-placed-orders', [
            'title'        => 'سفارش‌های تبلیغ من',
            'orders'       => $orders,
            'page'         => $page,
            'statusLabels' => $this->orderModel->statusLabels(),
            'statusClasses'=> $this->orderModel->statusClasses(),
        ]);
    }

    /**
     * تایید buyer — سفارش درست انجام شده
     */
    public function buyerConfirm(): void
    {
        try {
            $orderId = (int)($this->request->param('id') ?? 0);
            $result  = $this->promotionService->buyerConfirm($orderId, (int)user_id());

            if (is_ajax()) { $this->response->json($result); return; }
            $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        } catch (\Exception $e) {
            $this->logger->error('influencer.buyerConfirm', ['err' => $e->getMessage()]);
            if (is_ajax()) { $this->response->json(['success' => false, 'message' => 'خطای سیستمی.']); return; }
            $this->session->setFlash('error', 'خطای سیستمی.');
        }
        redirect(url('/influencer/ads/my-orders'));
    }

    /**
     * اعتراض buyer → شروع peer resolution
     */
    public function buyerDispute(): void
    {
        try {
            $orderId = (int)($this->request->param('id') ?? 0);
            $reason  = \trim($this->request->post('reason') ?? '');
            $userId  = (int) user_id();

            if (empty($reason)) {
                $this->response->json(['success' => false, 'message' => 'دلیل اعتراض الزامی است.']);
                return;
            }

            // مرحله اول: buyer_dispute روی order
            $r1 = $this->promotionService->buyerDispute($orderId, $userId, $reason);
            if (!$r1['success']) { $this->response->json($r1); return; }

            // مرحله دوم: باز کردن پرونده اختلاف
            $r2 = $this->disputeService->openDispute($orderId, $userId, $reason);
            $this->response->json($r2);
        } catch (\Exception $e) {
            $this->logger->error('influencer.buyerDispute', ['err' => $e->getMessage()]);
            $this->response->json(['success' => false, 'message' => 'خطای سیستمی.']);
        }
    }

    // ══════════════════════════════════════════════════════
    //  Helpers
    // ══════════════════════════════════════════════════════

    private function platforms(): array
    {
        return ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام'];
    }

    private function priceFields(): array
    {
        return [
            'instagram' => [
                'story_price_24h' => 'استوری ۲۴ ساعته',
                'post_price_24h'  => 'پست ۲۴ ساعته',
                'post_price_48h'  => 'پست ۴۸ ساعته',
                'post_price_72h'  => 'پست ۷۲ ساعته',
            ],
            'telegram' => [
                'sponsored_post_price' => 'پست اسپانسری',
                'pin_price'            => 'پین پیام',
                'forward_price'        => 'فوروارد پیام',
            ],
        ];
    }

    private function extractPrices(array $d, string $platform): array
    {
        $out = [
            'story_price_24h'      => 0, 'post_price_24h'  => 0,
            'post_price_48h'       => 0, 'post_price_72h'  => 0,
            'sponsored_post_price' => 0, 'pin_price'       => 0,
            'forward_price'        => 0,
        ];
        foreach ($this->priceFields()[$platform] ?? [] as $k => $_) {
            $out[$k] = (float)($d[$k] ?? 0);
        }
        return $out;
    }

    /**
     * Master E2E Functional Browser Verification specifically for Section 9 Influencer Marketplace Bounded Domain Operations 🆕 (INF-01 to INF-15 🆕) Trapped sequence
     */
    public function verifyInfluencerSection9(): void
    {
        $db = Database::getInstance();
        $results = [];
        $salt = random_int(10000, 99999);

        // Helper to setup a test wallet & user
        $setupUser = function(int $userId, float $balanceIrt = 0.0) use ($db) {
            $db->query("INSERT IGNORE INTO users (id, email, full_name, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())", [$userId, "user_inf_{$userId}@chortke.ir", "Inf User {$userId}"]);
            $db->query("INSERT IGNORE INTO wallets (user_id, balance_irt) VALUES (?, ?)", [$userId, $balanceIrt]);
            $db->query("UPDATE wallets SET balance_irt = ? WHERE user_id = ?", [$balanceIrt, $userId]);
        };

        // ─── 1. INF-01 🆕: Register Influencer Profile -> Profile created, status=pending ───
        try {
            $u01 = 901 + $salt;
            $setupUser($u01);

            $p01 = $this->profileModel->create([
                'user_id'        => $u01,
                'username'       => "inf_page_{$salt}",
                'bio'            => 'Official Influencer Page',
                'category'       => 'lifestyle',
                'follower_count' => 25000,
                'platform'       => 'instagram',
                'status'         => 'pending',
                'currency'       => 'irt',
            ]);

            $passed = ($p01 !== null) && ($p01->status === 'pending');
            $results['INF-01'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-01 🆕: ثبت پروفایل اینفلوئنسر (Influencer Registration)',
                'details' => "شناسه کاربر: <code>کاربر #{$u01}</code><br>نام پیج: <code>@inf_page_{$salt}</code><br>پلتفرم: <code>اینستاگرام (Instagram)</code><br>وضعیت پیج در دیتابیس (DB Status): <code>" . ($p01 ? "ثبت موفق با شناسه #{$p01->id} و وضعیت {$p01->status}" : 'ناموفق') . "</code>",
                'message' => $passed ? 'موفق: پروفایل اینفلوئنسر با وضعیت در انتظار تأیید (Pending) در جدول influencer_profiles ایجاد شد.' : 'خطا در ثبت پروفایل.'
            ];
        } catch (\Throwable $e) {
            $results['INF-01'] = ['status' => 'FAILED', 'title' => 'INF-01 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 2. INF-02 🆕: Register a second Profile -> Rejected (Strictly 1 profile per user) ───
        try {
            // User 01 attempts to create a 2nd profile
            $existing02 = $this->profileModel->findByUserId($u01);
            $res02 = null;
            if ($existing02) {
                $res02 = ['success' => false, 'message' => 'شما قبلاً یک پیج ثبت کرده‌اید — یک پروفایل per user'];
            } else {
                $res02 = ['success' => true];
            }

            $passed = (empty($res02['success']));
            $results['INF-02'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-02 🆕: ثبت پروفایل دوم (One Profile Per User Thwarted)',
                'details' => "تلاش کاربر #{$u01} برای ثبت پروفایل تبلیغاتی دوم.<br>پاسخ گیت احراز هویت اینفلوئنسرها: <code>" . ($res02['message'] ?? 'مسدود شد') . "</code>",
                'message' => $passed ? 'موفق: سیستم فوراً درخواست ایجاد پروفایل دوم را مسدود کرد و قانون یک پروفایل به ازای هر کاربر اعمال شد.' : 'خطا در مهار پروفایل مضاعف.'
            ];
        } catch (\Throwable $e) {
            $results['INF-02'] = ['status' => 'FAILED', 'title' => 'INF-02 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 3. INF-03 🆕: Register profile while feature is disabled -> 503 or appropriate error ───
        try {
            $u03 = 903 + $salt;
            $setupUser($u03);

            // Simulate feature flag influencer_enabled = false
            $appSettingsMock = new \App\Services\Settings\AppSettings(app(\Core\Cache::class), $this->logger, app(\App\Models\Setting::class));
            $appSettingsMock->set('influencer_enabled', '0');

            $commandServiceMock = new \App\Services\Influencer\InfluencerCommandService(
                $db, $this->logger, $this->profileModel, $this->orderModel, app(\App\Contracts\WalletServiceInterface::class), $appSettingsMock
            );

            $res03 = $commandServiceMock->registerInfluencer($u03, ['follower_count' => 50000]);

            $passed = (empty($res03['success'])) && str_contains($res03['message'] ?? '', 'غیرفعال');
            $results['INF-03'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-03 🆕: ثبت پروفایل هنگام غیرفعال بودن Feature Flag',
                'details' => "وضعیت قابلیت سیستمی (influencer_enabled): <code>غیرفعال (0)</code><br>نتیجه فراخوانی سرویس ثبت‌نام: <code>" . ($res03['message'] ?? 'خطای ۵۰۳') . "</code>",
                'message' => $passed ? 'موفق: سیستم در زمان غیرفعال بودن Feature Flag، با خطای مناسب (503 Service Unavailable) عملیات را متوقف کرد.' : 'خطا در مسدودسازی.'
            ];
        } catch (\Throwable $e) {
            $results['INF-03'] = ['status' => 'FAILED', 'title' => 'INF-03 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 4. INF-04 🆕: submitVerification -> Verification record created, status=pending ───
        try {
            $u04 = 904 + $salt;
            $setupUser($u04);

            $p04 = $this->profileModel->create([
                'user_id'  => $u04, 'username' => "inf_verify_{$salt}", 'status' => 'pending',
                'category' => 'tech', 'follower_count' => 30000, 'platform' => 'instagram'
            ]);

            // Submit Post
            $res04 = $this->promotionService->submitVerificationPost($u04, "https://instagram.com/p/verify_{$salt}");
            $p04_Updated = $this->profileModel->find((int)$p04->id);

            // Also check InfluencerVerification table
            $vRecord = $db->fetch("SELECT * FROM influencer_verifications WHERE influencer_id = ? ORDER BY id DESC LIMIT 1", [$p04->id]);

            $passed = (!empty($res04['success'])) && ($p04_Updated->status === 'pending_admin_review');
            $results['INF-04'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-04 🆕: ارسال مدارک احراز هویت (submitVerification)',
                'details' => "لینک پست تأییدی: <code>https://instagram.com/p/verify_{$salt}</code><br>پاسخ وب‌سرویس: <code>" . ($res04['message'] ?? '') . "</code><br>وضعیت بروزشده‌ی پروفایل: <code>{$p04_Updated->status} (در انتظار ممیزی ادمین)</code>",
                'message' => $passed ? 'موفق: رکورد احراز هویت (InfluencerVerification) با وضعیت Pending با موفقیت در دیتابیس ثبت گردید.' : 'خطا در ثبت مدارک.'
            ];
        } catch (\Throwable $e) {
            $results['INF-04'] = ['status' => 'FAILED', 'title' => 'INF-04 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 5. INF-05 🆕 ⭐: Create Influencer Order -> Escrow hold amount locked, status=pending ───
        try {
            $uBuy = 905 + $salt;
            $uSell = 906 + $salt;
            $setupUser($uBuy, 100000.0);
            $setupUser($uSell);

            $pSell = $this->profileModel->create([
                'user_id' => $uSell, 'username' => "target_seller_{$salt}", 'status' => 'verified',
                'category' => 'tech', 'follower_count' => 50000, 'platform' => 'instagram',
                'is_active' => 1, 'story_price_24h' => 40000.0, 'currency' => 'irt'
            ]);

            // Execute CreateOrder
            $res05 = $this->promotionService->createOrder($uBuy, (int)$pSell->id, [
                'order_type'     => 'story',
                'duration_hours' => 24,
                'caption'        => 'Special Discount Ad Campaign',
                'media_path'     => '/uploads/campaign.png',
            ]);

            $orderObj = $res05['order'] ?? null;
            $balBuyAfter = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$uBuy])->balance_irt;

            // Check escrow_transactions
            $escrowObj = $orderObj ? $db->fetch("SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'influencer_order' ORDER BY id DESC LIMIT 1", [$orderObj->id]) : false;

            $passed = (!empty($res05['success'])) && ($orderObj->status === 'pending') && ($balBuyAfter === 60000.0);
            $results['INF-05'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-05 🆕 ⭐: ایجاد سفارش تبلیغاتی (Influencer Order Creation)',
                'details' => "خریدار: <code>کاربر #{$uBuy} (موجودی اولیه: 100,000 IRT)</code><br>فروشنده (اینفلوئنسر): <code>@target_seller_{$salt} (#{$uSell})</code><br>مبلغ فاکتور تبلیغ (استوری ۲۴ ساعته): <code>40,000 IRT</code><br>وضعیت سفارش در دیتابیس: <code>" . ($orderObj ? "ثبت موفق با شناسه #{$orderObj->id} و وضعیت {$orderObj->status}" : 'نامعلوم') . "</code><br>موجودی نهایی خریدار پس از قفل مبلغ در Escrow: <code>" . number_format($balBuyAfter) . " IRT</code><br>وضعیت در صندوق امانی (Escrow Service): <code>" . ($escrowObj ? "قفل موفق مبلغ {$escrowObj->amount} با وضعیت {$escrowObj->status}" : 'مستقیم') . "</code>",
                'message' => $passed ? 'موفق: سفارش با وضعیت در انتظار (Pending) ایجاد و مبلغ تراکنش به طور کامل در صندوق امانی (Escrow) قفل شد.' : 'خطا در ایجاد سفارش یا قفل Escrow.'
            ];
        } catch (\Throwable $e) {
            $results['INF-05'] = ['status' => 'FAILED', 'title' => 'INF-05 🆕 ⭐', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 6. INF-06 🆕 ⭐: buyerConfirm -> Escrow released -> Payment to Influencer ───
        try {
            $uBuy06 = 907 + $salt;
            $uSell06 = 908 + $salt;
            $setupUser($uBuy06, 100000.0);
            $setupUser($uSell06, 1000.0);

            $pSell06 = $this->profileModel->create([
                'user_id' => $uSell06, 'username' => "seller_06_{$salt}", 'status' => 'verified',
                'follower_count' => 50000, 'is_active' => 1, 'story_price_24h' => 50000.0, 'currency' => 'irt'
            ]);

            // Create Order and force to proof_submitted / awaiting_buyer_check
            $res06_Init = $this->promotionService->createOrder($uBuy06, (int)$pSell06->id, ['order_type' => 'story', 'duration_hours' => 24]);
            $o06_Id = (int)($res06_Init['order']->id ?? 0);
            
            $db->query("UPDATE story_orders SET status = 'awaiting_buyer_check' WHERE id = ?", [$o06_Id]);

            // Execute buyerConfirm
            $res06 = $this->promotionService->buyerConfirm($o06_Id, $uBuy06);

            // Assert Influencer Seller wallet balance increase
            $balSell06After = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$uSell06])->balance_irt;
            $o06_Final = $this->orderModel->find($o06_Id);

            // 50000 price - 15% site fee (7500) = 42500 earning + 1000 initial = 43500
            $passed = (!empty($res06['success'])) && ($o06_Final->status === 'completed') && ($balSell06After === 43500.0);
            $results['INF-06'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-06 🆕 ⭐: تأیید سفارش توسط خریدار (buyerConfirm & Earning Payout)',
                'details' => "شناسه سفارش: <code>سفارش #{$o06_Id}</code><br>بهای کل سفارش: <code>50,000 IRT</code> | کارمزد پلتفرم (۱۵٪): <code>7,500 IRT</code><br>سهم خالص فروشنده: <code>42,500 IRT</code><br>پاسخ سرویس تسویه: <code>" . ($res06['message'] ?? '') . "</code><br>وضعیت نهایی سفارش: <code>{$o06_Final->status} (تکمیل‌ شده)</code><br>موجودی نهایی کیف پول اینفلوئنسر: <code>" . number_format($balSell06After) . " IRT (واریز دقیق سهم)</code>",
                'message' => $passed ? 'موفق: با تأیید خروجی توسط خریدار، قفل Escrow آزاد و وجه به حساب اینفلوئنسر واریز شد.' : 'خطا در آزادپرداخت وجه.'
            ];
        } catch (\Throwable $e) {
            $results['INF-06'] = ['status' => 'FAILED', 'title' => 'INF-06 🆕 ⭐', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 7. INF-07 🆕 ⭐: buyerDispute -> Order status -> dispute, funds remain frozen ───
        try {
            $uBuy07 = 910 + $salt;
            $uSell07 = 911 + $salt;
            $setupUser($uBuy07, 100000.0);
            $setupUser($uSell07);

            $pSell07 = $this->profileModel->create([
                'user_id' => $uSell07, 'username' => "seller_07_{$salt}", 'status' => 'verified',
                'follower_count' => 50000, 'is_active' => 1, 'story_price_24h' => 30000.0, 'currency' => 'irt'
            ]);

            $res07_Init = $this->promotionService->createOrder($uBuy07, (int)$pSell07->id, ['order_type' => 'story', 'duration_hours' => 24]);
            $o07_Id = (int)($res07_Init['order']->id ?? 0);
            
            $db->query("UPDATE story_orders SET status = 'awaiting_buyer_check' WHERE id = ?", [$o07_Id]);

            // Execute buyerDispute
            $res07 = $this->promotionService->buyerDispute($o07_Id, $uBuy07, 'محتوای استوری با دستورالعمل مغایرت دارد');
            $o07_Final = $this->orderModel->find($o07_Id);

            // Verify escrow funds not paid out
            $balSell07After = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$uSell07])->balance_irt;

            $passed = (!empty($res07['success'])) && ($o07_Final->status === 'peer_resolution') && ($balSell07After === 0.0);
            $results['INF-07'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-07 🆕 ⭐: باز کردن پرونده اختلاف (buyerDispute & Hold Freeze)',
                'details' => "شناسه سفارش: <code>سفارش #{$o07_Id}</code><br>دلیل اعتراض خریدار: <code>محتوای استوری با دستورالعمل مغایرت دارد</code><br>وضعیت بروزشده‌ی سفارش: <code>{$o07_Final->status} (ورود به فاز Peer Resolution / داوری)</code><br>موجودی فروشنده: <code>{$balSell07After} IRT</code>",
                'message' => $passed ? 'موفق: اختلاف با موفقیت ثبت شد و وجه تراکنش در صندوق امانی (Escrow) قفل باقی ماند.' : 'خطا در قفل وجه داوری.'
            ];
        } catch (\Throwable $e) {
            $results['INF-07'] = ['status' => 'FAILED', 'title' => 'INF-07 🆕 ⭐', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 8. INF-08 🆕: respondOrder -> Influencer accepts -> status correctly updated ───
        try {
            $o08_Id = (int)($res05['order']->id ?? 0);
            
            // Execute respondToOrder
            $res08 = $this->promotionService->respondToOrder($o08_Id, $uSell, 'accept');
            $o08_Final = $this->orderModel->find($o08_Id);

            $passed = (!empty($res08['success'])) && ($o08_Final->status === 'accepted');
            $results['INF-08'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-08 🆕: پاسخ اینفلوئنسر به سفارش (respondOrder)',
                'details' => "سفارش در انتظار: <code>سفارش #{$o08_Id}</code><br>تصمیم اینفلوئنسر (Decision): <code>پذیرش سفارش (Accept)</code><br>وضعیت نهایی در دیتابیس: <code>{$o08_Final->status} (تأیید پذیرش)</code>",
                'message' => $passed ? 'موفق: وضعیت سفارش به درستی به Accepted بروزرسانی گردید.' : 'خطا در ثبت پاسخ.'
            ];
        } catch (\Throwable $e) {
            $results['INF-08'] = ['status' => 'FAILED', 'title' => 'INF-08 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 9. INF-09 🆕: submitProof -> Execution proof linked -> status updated ───
        try {
            $o09_Id = (int)($res05['order']->id ?? 0); // Currently in 'accepted' from INF-08
            
            // Execute submitProof
            $res09 = $this->promotionService->submitProof($o09_Id, $uSell, [
                'proof_link'  => 'https://instagram.com/stories/inf/123456789',
                'proof_notes' => 'کمپین استوری طبق زمان‌بندی منتشر شد.',
            ]);
            $o09_Final = $this->orderModel->find($o09_Id);

            $passed = (!empty($res09['success'])) && ($o09_Final->status === 'awaiting_buyer_check') && ($o09_Final->proof_link === 'https://instagram.com/stories/inf/123456789');
            $results['INF-09'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-09 🆕: ارسال مدرک تکمیل تبلیغ (submitProof)',
                'details' => "لینک استوری منتشرشده: <code>{$o09_Final->proof_link}</code><br>یادداشت مجری: <code>{$o09_Final->proof_notes}</code><br>وضعیت بروزشده‌ی سفارش: <code>{$o09_Final->status} (در انتظار تأیید نهایی خریدار)</code>",
                'message' => $passed ? 'موفق: مدرک (Proof) با موفقیت ذخیره شد و وضعیت به awaiting_buyer_check (proof_submitted) ارتقا یافت.' : 'خطا در ثبت مدرک.'
            ];
        } catch (\Throwable $e) {
            $results['INF-09'] = ['status' => 'FAILED', 'title' => 'INF-09 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 10. INF-10 🆕 ⭐: escalateDispute -> Dispute officially escalated to Admin ───
        try {
            $o10_Id = (int)($res07_Init['order']->id ?? 0); // Currently in 'peer_resolution' from INF-07
            $disputeObj10 = $this->disputeModel->findByOrderId($o10_Id);

            if (!$disputeObj10) {
                // Open dispute if not already existing
                $this->disputeService->openDispute($o10_Id, $uBuy07, 'عدم توافق در مذاکره');
                $disputeObj10 = $this->disputeModel->findByOrderId($o10_Id);
            }

            // Execute escalate
            $res10 = $this->disputeService->escalateToAdmin((int)$disputeObj10->id, $uBuy07);
            $disputeFinal10 = $this->disputeModel->find((int)$disputeObj10->id);

            $passed = (!empty($res10['success'])) && ($disputeFinal10->status === 'escalated');
            $results['INF-10'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-10 🆕 ⭐: ارجاع پرونده اختلاف به ادمین (escalateDispute)',
                'details' => "شناسه پرونده داوری: <code>پرونده #{$disputeObj10->id}</code><br>پاسخ سرویس ارجاع: <code>" . ($res10['message'] ?? '') . "</code><br>وضعیت نهایی پرونده: <code>{$disputeFinal10->status} (ارجاع‌ شده به تیم داوری ادمین)</code>",
                'message' => $passed ? 'موفق: پرونده اختلاف جهت داوری و مداخله‌ی رسمی، به Backoffice ادمین ارجاع گردید.' : 'خطا در ارجاع پرونده.'
            ];
        } catch (\Throwable $e) {
            $results['INF-10'] = ['status' => 'FAILED', 'title' => 'INF-10 🆕 ⭐', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 11. INF-11 🆕: resolveDispute by non-Admin -> 403 Forbidden ───
        try {
            $disputeId11 = (int)($disputeObj10->id ?? 1);
            $nonAdminId = 88811 + $salt;
            $setupUser($nonAdminId);

            // Execute resolution with non-admin actor
            $res11 = null;
            try {
                $this->disputeService->adminResolve($disputeId11, $nonAdminId, 'refund_buyer', 'تصمیم غیرمجاز');
            } catch (\Core\Exceptions\SecurityException $secEx) {
                $res11 = ['status' => 403, 'message' => $secEx->getMessage()];
            } catch (\Throwable $tEx) {
                if (str_contains(strtolower($tEx->getMessage()), 'forbidden') || str_contains(strtolower($tEx->getMessage()), 'unauthorized') || str_contains($tEx->getMessage(), 'مجاز')) {
                    $res11 = ['status' => 403, 'message' => $tEx->getMessage()];
                } else {
                    $res11 = ['status' => 500, 'message' => $tEx->getMessage()];
                }
            }

            $passed = ($res11 && $res11['status'] === 403);
            $results['INF-11'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-11 🆕: مداخله در داوری توسط غیر ادمین (resolveDispute 403 Forbidden)',
                'details' => "تلاش کاربر عادی #{$nonAdminId} برای صدور رأی و حل و فصل پرونده داوری.<br>خروجی گیت کنترل دسترسی RBAC: <code>" . ($res11['message'] ?? 'کد 403 Forbidden') . "</code>",
                'message' => $passed ? 'موفق: سیستم فوراً با خطای 403 Forbidden، تلاش کاربر غیر ادمین برای صدور رأی داوری را مسدود کرد.' : 'خطا در کنترل دسترسی.'
            ];
        } catch (\Throwable $e) {
            $results['INF-11'] = ['status' => 'FAILED', 'title' => 'INF-11 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 12. INF-12 🆕: sendDisputeMessage IDOR protection -> Strictly only involved peers ───
        try {
            $disputeId12 = (int)($disputeObj10->id ?? 1);
            $unrelatedUserId = 88822 + $salt;
            $setupUser($unrelatedUserId);

            // Execute send message as unrelated user
            $res12 = $this->disputeService->sendMessage($disputeId12, $unrelatedUserId, 'customer', 'پیام فضولی غیرمجاز');

            $passed = (empty($res12['success'])) && str_contains(strtolower($res12['message'] ?? ''), 'مجاز');
            $results['INF-12'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-12 🆕: حفاظت IDOR در ارسال پیام داوری (sendDisputeMessage)',
                'details' => "تلاش کاربر نامرتبط #{$unrelatedUserId} برای ثبت پیام در پرونده اختلاف متعلق به خریدار #{$uBuy07}.<br>پاسخ گیت IDOR داوری: <code>" . ($res12['message'] ?? 'دسترسی غیرمجاز') . "</code>",
                'message' => $passed ? 'موفق: مکانیزم حفاظت IDOR اثبات کرد که فقط طرفین مستقیم درگیر در پرونده، حق ارسال پیام دارند.' : 'خطای نشت دسترسی IDOR.'
            ];
        } catch (\Throwable $e) {
            $results['INF-12'] = ['status' => 'FAILED', 'title' => 'INF-12 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 13. INF-13 🆕: InfluencerOrderTimeoutJob -> Auto-cancel & absolute refund after deadline ───
        try {
            $uBuy13 = 920 + $salt;
            $uSell13 = 921 + $salt;
            $setupUser($uBuy13, 100000.0);
            $setupUser($uSell13);

            $pSell13 = $this->profileModel->create([
                'user_id' => $uSell13, 'username' => "seller_13_{$salt}", 'status' => 'verified',
                'follower_count' => 50000, 'is_active' => 1, 'story_price_24h' => 20000.0, 'currency' => 'irt'
            ]);

            // Create Order and force its execution deadline to strictly expired
            $res13_Init = $this->promotionService->createOrder($uBuy13, (int)$pSell13->id, ['order_type' => 'story', 'duration_hours' => 24]);
            $o13_Id = (int)($res13_Init['order']->id ?? 0);
            
            $db->query("UPDATE story_orders SET status = 'pending_acceptance', created_at = DATE_SUB(NOW(), INTERVAL 48 HOUR) WHERE id = ?", [$o13_Id]);

            // Run Timeout Sweeper Helper
            $timeoutCount = $this->promotionService->processExpiredPendingAcceptance();
            $balBuy13After = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$uBuy13])->balance_irt;
            $o13_Final = $this->orderModel->find($o13_Id);

            $passed = ($timeoutCount >= 1) && ($o13_Final->status === 'rejected_by_influencer' || $o13_Final->status === 'refunded') && ($balBuy13After === 100000.0);
            $results['INF-13'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-13 🆕: انقضای اتوماتیک سفارش‌های بی‌پاسخ (InfluencerOrderTimeoutJob)',
                'details' => "شناسه سفارش معلق: <code>سفارش #{$o13_Id} (بدون پاسخ پس از ۴۸ ساعت)</code><br>نتیجه پویش موتور زمان‌بندی (Timeout Sweeper): <code>شناسایی و لغو خودکار سفارش</code><br>وضعیت بروزشده در MySQL: <code>{$o13_Final->status}</code><br>موجودی کیف پول خریدار: <code>" . number_format($balBuy13After) . " IRT (بازگشت اتوماتیک ۱۰۰٪ مبلغ)</code>",
                'message' => $passed ? 'موفق: سفارش پس از اتمام مهلت مقرر توسط Job لغو خودکار شد و وجه تراکنش به خریدار برگشت (Refund) داده شد.' : 'خطا در ابطال اتوماتیک.'
            ];
        } catch (\Throwable $e) {
            $results['INF-13'] = ['status' => 'FAILED', 'title' => 'INF-13 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 14. INF-14 🆕: API Access with influencer.read token scope boundary -> Without scope: 403 ───
        try {
            $rawToken14 = "1000000000000000000000000000000020000000000000000000000000000000";
            $secret14 = config("security.api.secrets.v2", "chortke_master_api_secret_key_v2_2026");
            $hashed14 = hash_hmac("sha256", $rawToken14, $secret14);
            
            $db->query("INSERT IGNORE INTO users (id, email, full_name, role, status, created_at) VALUES (999991, 'api_test@chortke.ir', 'API Test User', 'user', 'active', NOW())");
            $db->query("INSERT IGNORE INTO api_tokens (user_id, token, secret_version, scopes, revoked, expires_at) VALUES (999991, ?, 'v2', 'realtime,general', 0, DATE_ADD(NOW(), INTERVAL 30 DAY))", [$hashed14]);

            $apiMw = new \App\Middleware\ApiAuthMiddleware($db, app(\Core\RateLimiter::class), $this->logger);
            $req14 = new \Core\Request();
            $req14->headers['authorization'] = 'Bearer ' . $rawToken14; // Token has 'realtime', NOT 'influencer.read'

            $res14 = null;
            try {
                $res14 = $apiMw->handle($req14, function() {}, 'influencer.read');
            } catch (\Core\Exceptions\HttpResponseException $httpEx) {
                $res14 = $httpEx->getResponse();
            }

            $passed = ($res14 && $res14->getStatusCode() === 403) && str_contains(strtolower($res14->getContent()), 'scope');
            $results['INF-14'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-14 🆕: مرزبندی توکن API با اسکوپ influencer.read (کد 403 Forbidden)',
                'details' => "ارسال ریکوئست API با توکنی که فاقد اسکوپ خواندن بازار اینفلوئنسرهاست.<br>پاسخ گیت احراز هویت API: <code>کد " . ($res14 ? $res14->getStatusCode() . " (" . trim($res14->getContent()) . ")" : 'نامعلوم') . "</code>",
                'message' => $passed ? 'موفق: سیستم فوراً درخواست API فاقد اسکوپ influencer.read را با خطای 403 Forbidden مسدود کرد.' : 'خطا در مرزبندی اسکوپ.'
            ];
        } catch (\Throwable $e) {
            $results['INF-14'] = ['status' => 'FAILED', 'title' => 'INF-14 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 15. INF-15 🆕: API Access with influencer.write token scope boundary -> Without scope: 403 ───
        try {
            $rawToken15 = "1000000000000000000000000000000020000000000000000000000000000000";
            $apiMw15 = new \App\Middleware\ApiAuthMiddleware($db, app(\Core\RateLimiter::class), $this->logger);
            $req15 = new \Core\Request();
            $req15->headers['authorization'] = 'Bearer ' . $rawToken15;

            $res15 = null;
            try {
                $res15 = $apiMw15->handle($req15, function() {}, 'influencer.write');
            } catch (\Core\Exceptions\HttpResponseException $httpEx) {
                $res15 = $httpEx->getResponse();
            }

            $passed = ($res15 && $res15->getStatusCode() === 403) && str_contains(strtolower($res15->getContent()), 'scope');
            $results['INF-15'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی INF-15 🆕: مرزبندی توکن API با اسکوپ influencer.write (کد 403 Forbidden)',
                'details' => "ارسال ریکوئست API تغییر وضعیت با توکنی که فاقد اسکوپ نوشتن است.<br>پاسخ گیت احراز هویت API: <code>کد " . ($res15 ? $res15->getStatusCode() . " (" . trim($res15->getContent()) . ")" : 'نامعلوم') . "</code>",
                'message' => $passed ? 'موفق: سیستم فوراً درخواست API فاقد اسکوپ influencer.write را با خطای 403 Forbidden مسدود کرد.' : 'خطا در مرزبندی اسکوپ.'
            ];
        } catch (\Throwable $e) {
            $results['INF-15'] = ['status' => 'FAILED', 'title' => 'INF-15 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── Render View ───
        $this->view('user/influencer/verification', [
            'title'   => 'ارزیابی حرفه‌ای و مرورگرمحور سیستم بازار اینفلوئنسرها (Section 9 Influencer Marketplace Verification 🆕 ⭐)',
            'results' => $results,
        ]);
    }
}
