<?php

namespace App\Controllers\User;

use App\Services\BankCardService;
use App\Services\User\UserService;
use App\Controllers\User\BaseUserController;
use App\Validators\Requests\CreateBankCardRequest;

class BankCardController extends BaseUserController
{
    private BankCardService $bankCardService;

    public function __construct(BankCardService $bankCardService, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->bankCardService = $bankCardService;
    }

    /**
     * لیست کارت‌های بانکی کاربر
     */
    public function index(): void
    {
        $userId = (int)$this->userId();
        
        try {
            $cards = $this->bankCardService->getUserCards($userId);
            $cardCount = count($cards); // Helper or proxy
            
            view('user.bank-cards.index', [
                'cards' => $cards,
                'cardCount' => $cardCount,
                'maxCards' => 4,
                'pageTitle' => 'کارت‌های بانکی من'
            ]);

        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error('bank_card.index.failed', [
                'channel' => 'banking',
                'user_id' => $userId,
                'error' => $e->getMessage()
            ]);
            
            $this->session->setFlash('error', 'خطا در دریافت لیست کارت‌ها');
            $this->response->redirect(url('wallet'));
        }
    }

    /**
     * فرم افزودن کارت بانکی
     */
    public function create(): void
    {
        $userId = (int)$this->userId();
        $cards = $this->bankCardService->getUserCards($userId);
        
        if (count($cards) >= 4) {
            $this->session->setFlash('error', 'حداکثر 4 کارت بانکی می‌توانید ثبت کنید');
            $this->response->redirect(url('bank-cards'));
            return;
        }

        view('user.bank-cards.index', [
            'cards' => $cards,
            'cardCount' => count($cards),
            'maxCards' => 4,
            'pageTitle' => 'هاب مدیریت و افزودن کارت بانکی (Binance Style)'
        ]);
    }

    /**
     * FIX-R19-A4-3: ورودی old فلاش‌شده هرگز شامل card_number/sheba خام نیست —
     * فقط نام بانک/نام دارنده + ۴ رقم آخر کارت (به‌صورت کلید مجزای card_tail).
     *
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    private function oldFlashForCard(array $input): array
    {
        $digits = str_value($input['card_number'] ?? '');
        return [
            'bank_name'        => str_value($input['bank_name'] ?? ''),
            'cardholder_name'  => str_value($input['cardholder_name'] ?? ''),
            'card_tail'        => $digits !== '' ? mb_substr($digits, -4) : '',
        ];
    }

    /**
     * ذخیره کارت بانکی جدید
     */
    public function store(): void
    {
        $userId = (int)$this->userId();
        $input = $this->request->all();

        // FIX-BANKCARD-FORMAT: فرم شماره کارت را با خط‌تیر (6219-8610-...) می‌فرستد
        // (JS در حین تایپ فرمت می‌کند) ولی قانون اعتبارسنجی دقیقاً 16 کاراکتر
        // می‌خواست → همه ثبت‌های واقعی کاربران رد می‌شد. نرمال‌سازی قبل از اعتبارسنجی:
        if (isset($input['card_number']) && is_string($input['card_number'])) {
            $input['card_number'] = preg_replace('/\D/', '', $input['card_number']);
        }
        if (isset($input['sheba']) && is_string($input['sheba'])) {
            $input['sheba'] = preg_replace('/\D/', '', $input['sheba']);
        }

        $validator = new CreateBankCardRequest($input);
        $validator->validate();

        if ($validator->fails()) {
            $errors = $validator->errors();
            $firstError = reset($errors);
            $msg = is_array($firstError) ? reset($firstError) : $firstError;
            $this->session->setFlash('error', $msg ?: 'اطلاعات ورودی نامعتبر است.');
            // FIX-R19-A4-3: card_number/sheba خام به old فلاش نمی‌شود
            $this->session->setFlash('old', $this->oldFlashForCard($input));
            $this->response->redirect(url('bank-cards/create'));
            return;
        }

        // FIX-X16: safeValidated — bank_name اکنون در rules است (FIX-T2 سالم می‌ماند)
        $validatedData = $validator->safeValidated();
        
        // Convert request format to service expected payload
        $payload = [
            'card_number' => $validatedData['card_number'] ?? '',
            'card_holder' => $validatedData['cardholder_name'] ?? '',
            'iban' => $validatedData['sheba'] ?? '',
            // FIX-T2/باگ U: bank_name قبلاً در payload دور ریخته می‌شد و سرویس
            // هرگز آن را نمی‌دید → fallback انتخاب دستی کاربر برای BINهای
            // ناشناخته بی‌اثر بود و همیشه «نامشخص» ذخیره می‌شد.
            'bank_name' => str_value($validatedData['bank_name'] ?? ''),
        ];

        $result = $this->bankCardService->create($userId, $payload);

        if (!empty($result['success'])) {
            $this->session->setFlash('success', $result['message'] ?? 'عملیات موفق');
            $this->response->redirect(url('bank-cards'));
        } else {
            $this->session->setFlash('error', $result['message'] ?? 'خطا در ثبت');
            // FIX-R19-A4-3: card_number/sheba خام به old فلاش نمی‌شود
            $this->session->setFlash('old', $this->oldFlashForCard($input));
            $this->response->redirect(url('bank-cards/create'));
        }
    }

    /**
     * تنظیم کارت پیش‌فرض
     */
    public function setDefault(string $id): void
    {
        $userId = (int)$this->userId();
        $result = $this->bankCardService->setPrimary($userId, (int)$id);
        $this->response->json($result);
    }

    /**
     * حذف کارت بانکی
     */
    public function delete(string $id): void
    {
        $userId = (int)$this->userId();
        $result = $this->bankCardService->softDeleteByUser($userId, (int)$id);
        $this->response->json($result);
    }
}
