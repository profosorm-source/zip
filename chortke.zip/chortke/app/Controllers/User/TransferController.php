<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Contracts\WalletServiceInterface;
use App\Services\User\UserService;
use App\Controllers\User\BaseUserController;
use App\Validators\Requests\CreateTransferRequest;

class TransferController extends BaseUserController
{
    private WalletServiceInterface $walletService;
    // $userService inherited from parent
    // $logger inherited from BaseController

    public function __construct(
        WalletServiceInterface $walletService,
        UserService $userService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->walletService = $walletService;
        $this->userService   = $userService;
    }

    /**
     * 🛡️ FIX-FINANCE-HUB-COMPLETION: متد create() (رندر فرم) حذف شد — فرم انتقال
     * اکنون پنل transfer هاب مالی است و GET /wallet/transfer توسط
     * WalletController::transferIndex رندر می‌شود. این کنترلر فقط عملیات
     * عملیاتی store (JSON) را نگه می‌دارد.
     */
    public function store(): void
    {
        // FIX-R36-W3 (F-A6a-10): explicit in-handler CSRF backstop — the sibling money POST
        // endpoints (EscrowController::store/release) call validateCsrf() explicitly; the
        // global CSRFMiddleware covers this route too, but the in-handler check keeps the
        // money endpoint safe even if the middleware layer is ever reordered/weakened.
        $this->validateCsrf();
        $senderId = (int)$this->userId();

        $request = new CreateTransferRequest($this->request->all());
        if (!$request->validate()) {
            $errors = $request->errors();
            $firstValue = reset($errors);
            $firstError = is_array($firstValue) ? reset($firstValue) : $firstValue;
            // FIX-M12-09 (گزارش ماژول ۱۲): وضعیت HTTP قراردادی — validation → 422
            // (قبلاً بدون status → 200 بود و client خطای business را موفق تلقی می‌کرد).
            $this->response->json(['success' => false, 'message' => $firstError ?: 'اطلاعات ورودی نامعتبر است', 'errors' => $errors], 422);
            return;
        }
        $validated = $request->safeValidated(); // FIX-X16
        $recipientIdentifier = str_value($validated['recipient'] ?? '');
        $amountStr = str_value($validated['amount'] ?? '');

        $recipient = $this->userService->findByCredentials($recipientIdentifier);
        if (!$recipient) {
            // FIX-M12-09: گیرنده ناموجود → 404
            $this->response->json(['success' => false, 'message' => 'کاربر گیرنده یافت نشد.', 'error_code' => 'RECIPIENT_NOT_FOUND'], 404);
            return;
        }

        $recipientId = (int)$recipient->id;
        if ($recipientId === $senderId) {
            // FIX-M12-09: انتقال به خود → 422
            $this->response->json(['success' => false, 'message' => 'امکان انتقال اعتبار به خودتان وجود ندارد.', 'error_code' => 'SELF_TRANSFER_FORBIDDEN'], 422);
            return;
        }

        try {
            // P0-23: کلید idempotency کلاینت — از هدر استاندارد Idempotency-Key
            // یا فیلد فرم. فرم وب در هر render یک کلید یکتا تولید می‌کند؛
            // double-submit همان فرم = همان کلید = یک انتقال.
            $clientKey = str_value($this->request->header('Idempotency-Key', ''))
                ?: str_value($this->request->input('idempotency_key', ''));

            // FIX-M12-15 (گزارش ماژول ۱۲): کلید mutation مالی اجباری و bounded است —
            // fallback تصادفی «p2p_+random» هر تلاش را intent جدید جلوه می‌داد؛
            // پاسخ گم‌شده پس از reload/direct POST دیگر قابل‌تشخیص نبود و duplicate
            // debit/credit ممکن می‌شد. نبود/طول غیرمجاز کلید → رد 422 بدون side-effect.
            if ($clientKey === '' || strlen($clientKey) < 8 || strlen($clientKey) > 128
                || !preg_match('/^[A-Za-z0-9_.:-]+$/', $clientKey)) {
                $this->response->json([
                    'success' => false,
                    'message' => 'کلید تکرارنشدن (Idempotency-Key) الزامی است: رشتهٔ ۸ تا ۱۲۸ کاراکتری alphanumeric',
                    'error_code' => 'IDEMPOTENCY_KEY_REQUIRED',
                ], 422);
                return;
            }
            $serviceKey = $clientKey;

            $result = $this->walletService->transfer(
                $senderId,
                $recipientId,
                $amountStr,
                'irt',
                'انتقال اعتبار P2P',
                $serviceKey
            );

            // FIX-C88: خروجی اکنون پاکت آرایه‌ای است (نه ?object) — موفقیت با
            // کلید success پاکت سنجیده می‌شود.
            if (!is_array($result) || empty($result['success'])) {
                $msg = is_array($result) && isset($result['message']) && is_string($result['message']) && $result['message'] !== ''
                    ? $result['message']
                    : 'خطا در انجام انتقال';
                // FIX-M12-09: شکست سرویس → 422 قراردادی (قبلاً 200)
                $this->response->json(['success' => false, 'message' => $msg, 'error_code' => 'TRANSFER_FAILED'], 422);
                return;
            }

            $this->response->json(['success' => true, 'message' => 'انتقال با موفقیت انجام شد', 'data' => $result]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\InvalidArgumentException $e) {
            $this->response->json(['success' => false, 'message' => $e->getMessage()], 422);
        } catch (\Core\Exceptions\InsufficientBalanceException $e) {
            $this->response->json(['success' => false, 'message' => $e->getMessage()], 422);
        } catch (\Core\Exceptions\InvalidStateException $e) {
            $this->response->json(['success' => false, 'message' => $e->getMessage()], 422);
        } catch (\RuntimeException $e) {
            // FIX-M12-25 (گزارش ماژول ۱۲): قرارداد استثنا→خطای کاربر — RuntimeException
            // کلاس پایهٔ ApplicationException است؛ پیام خام زیرساخت (stale-lock fence،
            // adapter و…) نباید به پاسخ برسد. دو شاخهٔ قراردادی exception keep می‌شوند:
            // (۱) collision بازپخش (code=409 از FIX-M12-02)؛ (۲) allowlist پیام‌های
            // دامنهٔ شناخته‌شدهٔ user-safe. سایر RuntimeException → پیام عمومی + correlation
            // id؛ جزئیات فقط در لاگ.
            if ((int)$e->getCode() === 409) {
                $this->response->json(['success' => false, 'message' => $e->getMessage(), 'error_code' => 'IDEMPOTENCY_PAYLOAD_MISMATCH'], 409);
                return;
            }
            $msg = (string)$e->getMessage();
            $domainSafe = [
                'انتقال وجه به دلیل محدودیت‌های امنیتی مجاز نیست', // گارد fraud
            ];
            if (in_array($msg, $domainSafe, true) || str_starts_with($msg, 'ارز ') || str_starts_with($msg, 'مبلغ باید')) {
                $this->response->json(['success' => false, 'message' => $msg], 422);
                return;
            }
            $correlation = function_exists('get_request_id') ? get_request_id() : bin2hex(random_bytes(8));
            if (isset($this->logger)) {
                $this->logger->error('transfer.runtime_error', ['user_id' => $senderId, 'correlation' => $correlation, 'error' => $msg]);
            }
            $this->response->json([
                'success' => false,
                'message' => 'انتقال با خطا مواجه شد؛ لطفاً دوباره تلاش کنید',
                'error_code' => 'TRANSFER_RUNTIME_ERROR',
                'correlation_id' => $correlation,
            ], 503);
        } catch (\Throwable $e) {
            if (isset($this->logger)) {
                $this->logger->error('transfer.failed', ['user_id' => $senderId, 'error' => $e->getMessage()]);
            }
            $this->response->json(['success' => false, 'message' => 'خطای سیستمی در انتقال'], 500);
        }
    }
}
