<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Contracts\WalletServiceInterface;
use App\Services\User\UserService;
use App\Controllers\User\BaseUserController;
use App\Validators\Requests\CreateTransferRequest;

class TransferController extends BaseUserController
{
    private WalletServiceInterface $walletService;
    // $userService inherited from parent
    // $logger inherited from BaseController

    public function __construct(
        WalletServiceInterface $walletService,
        UserService $userService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->walletService = $walletService;
        $this->userService   = $userService;
    }

    public function create(): void
    {
        $userId = $this->userId();
        // SEC-2 fix (BUGFIX-FALLBACK-USER-2026-06)
        $userObj = $this->loadCurrentUserOrRedirect();
        $userId  = (int) $userObj->id;

        $this->view('user/wallet/transfer', [
            'title' => 'انتقال اعتبار بین کاربران',
            'user'  => $userObj
        ]);
    }

    public function store(): void
    {
        $this->validateCsrf();
        $senderId = $this->userId();

        $request = new CreateTransferRequest($this->request->all());
        if (!$request->validate()) {
            $errors = $request->errors();
            $firstError = is_array(reset($errors)) ? reset(reset($errors)) : reset($errors);
            $this->response->json(['success' => false, 'message' => $firstError ?: 'اطلاعات ورودی نامعتبر است', 'errors' => $errors]);
            return;
        }
        $validated = $request->validated();
        $recipientIdentifier = (string)($validated['recipient'] ?? '');
        $amountStr = (string)($validated['amount'] ?? '');

        $recipient = $this->userService->findByCredentials($recipientIdentifier);
        if (!$recipient) {
            $this->response->json(['success' => false, 'message' => 'کاربر گیرنده یافت نشد.']);
            return;
        }

        $recipientId = (int)$recipient->id;
        if ($recipientId === $senderId) {
            $this->response->json(['success' => false, 'message' => 'امکان انتقال اعتبار به خودتان وجود ندارد.']);
            return;
        }

        // Execute Double-Entry ACID Atomic peer-to-peer transfer
        // در صورت بروز خطا (موجودی ناکافی، کیف پول مسدود و ...)، WalletService/
        // WalletMutationService یک Exception typed با پیام فارسی امن پرتاب می‌کند
        // که به GlobalExceptionMiddleware واگذار می‌شود.
        $result = $this->walletService->transfer(
            $senderId,
            $recipientId,
            $amountStr,
            'irt',
            'انتقال اعتبار P2P'
        );

        $this->response->json((array)$result);
    }
}
