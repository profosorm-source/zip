<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Contracts\WalletServiceInterface;
use App\Services\User\UserService;
use App\Controllers\User\BaseUserController;

class TransferController extends BaseUserController
{
    private WalletServiceInterface $walletService;
    // $userService inherited from parent
    // $logger inherited from BaseController

    public function __construct(
        WalletServiceInterface $walletService,
        UserService $userService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->walletService = $walletService;
        $this->userService   = $userService;
    }

    public function create(): void
    {
        $userId = $this->userId();
        $userObj = $this->userService->find($userId);
        if (!$userObj) $userObj = (object)['id' => 1, 'full_name' => 'معمار چرتکه', 'email' => 'architect@chortke.ir'];

        $this->view('user/wallet/transfer', [
            'title' => 'انتقال اعتبار بین کاربران',
            'user'  => $userObj
        ]);
    }

    public function store(): void
    {
        $this->validateCsrf();
        $senderId = $this->userId();
        $recipientIdentifier = trim((string)$this->request->post('recipient'));
        $amountStr = trim((string)$this->request->post('amount'));

        if ($recipientIdentifier === '' || !is_numeric($amountStr) || bccomp($amountStr, '0', 4) <= 0) {
            $this->response->json(['success' => false, 'message' => 'مبلغ و گیرنده معتبر نیست.']);
            return;
        }

        try {
            $recipient = $this->userService->findByCredentials($recipientIdentifier);
            if (!$recipient) {
                $this->response->json(['success' => false, 'message' => 'کاربر گیرنده یافت نشد.']);
                return;
            }

            $recipientId = (int)$recipient->id;
            if ($recipientId === $senderId) {
                $this->response->json(['success' => false, 'message' => 'امکان انتقال اعتبار به خودتان وجود ندارد.']);
                return;
            }

            // Execute Double-Entry ACID Atomic peer-to-peer transfer
            $result = $this->walletService->transfer($senderId, $recipientId, $amountStr, 'irt', [
                'ip' => $this->request->ip(),
                'user_agent' => $this->request->userAgent()
            ]);

            $this->response->json($result);
        } catch (\Throwable $e) {
            $this->response->json(['success' => false, 'message' => 'خطا در انتقال اعتبار: ' . $e->getMessage()]);
        }
    }
}
