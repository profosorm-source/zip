<?php

namespace App\Controllers\User;

use App\Controllers\User\BaseUserController;
use App\Services\ApiTokenService;

class ApiTokenController extends BaseUserController
{
    private ApiTokenService $apiTokenService;

    public function __construct(
        ApiTokenService $apiTokenService,
        \Core\Session $session,
        \Core\Request $request,
        \Core\Response $response,
        \App\Services\Shared\PolicyService $policyService,
        \App\Contracts\LoggerInterface $logger,
        \App\Services\Auth\AuthService $authService,
        \App\Services\User\UserService $userService,
        \App\Services\CaptchaService $captchaService
    ) {
        parent::__construct($session, $request, $response, $policyService, $logger, $authService, $userService, $captchaService);
        $this->apiTokenService = $apiTokenService;
    }

    /** لیست توکن‌های کاربر */
    public function index(): void
    {
        $this->requireAuth();

        $userId = (int)$this->userId();
        $tokens = $this->apiTokenService->listTokensForUser($userId);
        // FIX-M11-TOK-04 (گزارش دوم ماژول ۱۱): شمارش «فعال» با predicate کانونی
        // (revoked=0 + expires_at>NOW()) — قبلاً count($tokens) توکن‌های منقضیِ
        // revokeنشده را هم «فعال» می‌شمرد و با سقف/ظرفیت ناسازگار بود.
        $activeCount = $this->apiTokenService->getActiveTokenCountForUser($userId);
        $newToken = $this->session->getFlash('new_api_token');

        // FIX-M11-R22-17: صفحهٔ حاوی توکن تازه (flash در value ورودی) —
        // no-store تا back/forward cache توکن را نگه ندارد (RFC 6749 §5.1 هم‌قرارداد).
        if (!empty($newToken) && !headers_sent()) {
            header('Cache-Control: no-store');
            header('Pragma: no-cache');
        }

        $this->view('user.api-tokens.index', [
            'title'    => 'توکن‌های API',
            'tokens'   => $tokens,
            'activeCount' => $activeCount,
            'newToken' => $newToken,
        ]);
    }

    /**
     * ساخت توکن جدید — FIX-M11-R22-23:
     *  ۱) step-up: رمزِ فعلی الزامی است (سشن ربوده‌شده بدون رمز دیگر توکنِ
     *     ۹۰/۳۶۵روزهٔ پایدار نمی‌سازد — الگوی L-23 همان مسیر API 2FA setup)
     *  ۲) گیتِ ایمیل تأییدشده — قبلاً توکن ساخته می‌شد ولی middleware آن را
     *     رد می‌کرد و یکی از ۱۰ ظرفیت بی‌دلیل اشغال می‌شد
     *  ۳) چکِ سقف ۱۰ تکراری حذف شد — سرویس اتمیک چک می‌کند (insertWithinActiveCap)؛
     *     پیام‌ها هم تک‌منبع شدند.
     */
    public function create(): void
    {
        $this->requireAuth();
        $this->validateCsrf();

        $userId = (int)$this->userId();
        $name      = trim(str_value($this->request->post('name') ?? ''));
        // W4-E: پیش‌فرض canonical ۹۰ روز (تصمیم مشتری #1) — وقتی فرم مقدار عمدی
        // expires_in نمی‌فرستد؛ سرویس همان را به [1,365] کلمپ می‌کند.
        $expiresIn = $this->request->int('expires_in', ApiTokenService::DEFAULT_TTL_DAYS);
        // FIX-M11-R22-23: step-up رمز فعلی
        $currentPassword = str_value($this->request->post('current_password') ?? '');

        if ($name === '') {
            $this->redirectWithError('نام توکن الزامی است', '/api-tokens');
            return;
        }

        if ($currentPassword === '') {
            $this->redirectWithError('برای ساخت توکن، وارد کردن رمز عبور فعلی الزامی است.', '/api-tokens');
            return;
        }

        // FIX-M11-R22-23: گیتِ ایمیل تأییدشده — هم‌قرارداد با صدور API (MED-07) و
        // گیتِ Bearer middleware؛ توکنِ غیرقابل‌استفاده دیگر ساخته نمی‌شود.
        $user = $this->userService->findById($userId);
        if (!$user || empty($user->email_verified_at)) {
            $this->redirectWithError('ابتدا ایمیل خود را تایید کنید؛ ساخت توکن برای حساب تأییدنشده مجاز نیست.', '/api-tokens');
            return;
        }

        if (!verify_user_password($currentPassword, $user->password ?? '', $userId)) {
            $this->redirectWithError('رمز عبور فعلی نادرست است.', '/api-tokens');
            return;
        }

        // FIX-M11-SF-008 (گزارش دوم): omission دیگر به read سراسری نمی‌افتد —
        // پیش‌فرض کانونی DEFAULT_SCOPE (user.read)؛ سرویس هم ورودیِ نامعتبر را رد می‌کند.
        // FIX-M11-R22-23: چکِ سقفِ تکراریِ غیراتمیکِ کنترلر حذف شد — سرویس با
        // insertWithinActiveCap اتمیک سنجیده و پیامِ واحدِ TOKEN_LIMIT_REACHED می‌دهد.
        $scope = trim(str_value($this->request->post('scope') ?? ApiTokenService::DEFAULT_SCOPE));
        $result = $this->apiTokenService->createTokenForUser($userId, $name, $expiresIn, $scope);
        if (!$result['success']) {
            $this->redirectWithError(str_value($result['message'] ?? 'خطا در ایجاد توکن'), '/api-tokens');
            return;
        }

        $payload = is_array($result['payload'] ?? null) ? $result['payload'] : [];
        $this->session->setFlash('new_api_token', str_value($payload['token'] ?? '')); 
        $this->redirectWithSuccess('توکن با موفقیت ساخته شد', '/api-tokens');
    }

    /** باطل کردن توکن */
    public function revoke(): void
    {
        $this->requireAuth();
        $this->validateCsrf();

        $userId = (int)$this->userId();
        $id = int_value($this->request->param('id') ?? $this->request->get('id')); 

        $result = $this->apiTokenService->revokeTokenById($userId, $id);
        if ($result['success']) {
            $this->jsonSuccess('توکن باطل شد');
            return;
        }

        $this->jsonError(str_value($result['message'] ?? 'توکن یافت نشد'), [], int_value($result['status'] ?? 404));
    }
}
