<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Services\Shared\CouponService;
use App\Models\Coupon;
use App\Models\CouponRedemption;
use App\Controllers\User\BaseUserController;
use Core\Database;

class CouponController extends BaseUserController
{
    private CouponService $couponService;
    private CouponRedemption $redemptionModel;

    public function __construct(
        Coupon $couponModel,
        CouponRedemption $redemptionModel,
        CouponService $couponService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->couponService = $couponService;
        $this->redemptionModel = $redemptionModel;
    }

    /**
     * اعتبارسنجی کوپن (AJAX)
     * POST /user/coupons/validate
     */
    public function validate(): void
    {
        $data = json_decode(file_get_contents('php://input'), true);

        $code = trim($data['code'] ?? '');
        $amount = (float)($data['amount'] ?? 0);
        $currency = $data['currency'] ?? 'irt';
        $applicableTo = $data['applicable_to'] ?? 'all';
        $userId = user_id();

        if (empty($code) || $amount <= 0) {
            $this->response->json([
                'success' => false,
                'message' => 'اطلاعات ارسالی ناقص است'
            ]);
            return;
        }

        $result = $this->couponService->validateAndCalculate(
            $code,
            $amount,
            $currency,
            $userId,
            $applicableTo
        );

        if ($result['valid']) {
            $this->response->json([
                'success' => true,
                'data' => [
                    'coupon_id' => $result['coupon_id'],
                    'coupon_code' => $result['coupon_code'],
                    'original_amount' => $result['original_amount'],
                    'discount_amount' => $result['discount_amount'],
                    'final_amount' => $result['final_amount'],
                    'validation_token' => $result['validation_token']
                ],
                'message' => sprintf('کد تخفیف با موفقیت اعمال شد. تخفیف: %s', number_format($result['discount_amount']))
            ]);
        } else {
            $this->response->json([
                'success' => false,
                'message' => $result['error']
            ]);
        }
    }

    /**
     * تاریخچه استفاده از کوپن‌ها
     * GET /user/coupons/history
     */
    public function history(): void
    {
        $userId = user_id();
        $history = $this->redemptionModel->getUserHistory($userId);

        // CSP Rendering Bug Fix: استفاده از $this->view جهت انتساب صحیح خروجی به شیء Response
        $this->view('user/coupons/history', [
            'history' => $history,
            'user' => auth()
        ]);
    }

    /**
     * Master E2E Functional Browser Verification for Section 8.3 Coupon Bounded Domain Operations (CP-01 to CP-06)
     */
    public function verifyCouponSection83(): void
    {
        $db = Database::getInstance();
        $results = [];
        $salt = random_int(10000, 99999);

        $setupUser = function(int $userId) use ($db) {
            $db->query("INSERT IGNORE INTO users (id, email, full_name, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())", [$userId, "user_cp_{$userId}@chortke.ir", "Coupon User {$userId}"]);
        };

        $setupCoupon = function(string $code, float $value, int $usageLimit, int $usageCount, string $endDate = 'NOW() + INTERVAL 10 DAY') use ($db) {
            $db->query("INSERT IGNORE INTO coupons (code, type, value, usage_limit, usage_count, start_date, end_date, active, created_at) VALUES (?, 'percent', ?, ?, ?, NOW() - INTERVAL 1 DAY, {$endDate}, 1, NOW())", [$code, $value, $usageLimit, $usageCount]);
            $db->query("UPDATE coupons SET usage_limit = ?, usage_count = ?, end_date = {$endDate}, active = 1, deleted_at = NULL WHERE code = ?", [$usageLimit, $usageCount, $code]);
        };

        // ─── 1. CP-01: Applying valid Coupon -> Discount applied, coupon usage recorded ───
        try {
            $u01 = 801 + $salt;
            $c01 = "CP01_{$salt}";
            $setupUser($u01);
            $setupCoupon($c01, 10.0, 100, 0); // 10% off, 0 uses

            // Execute
            $res01 = $this->couponService->validateAndRedeem($u01, $c01, 500.0, 'irt', 'payment', 101);

            // Assert exact usage increase
            $rowC01 = $db->fetch("SELECT id, usage_count FROM coupons WHERE code = ?", [$c01]);

            $passed = (!empty($res01['success'])) && ($res01['discount_amount'] === 50.0) && ($res01['final_amount'] === 450.0) && ((int)$rowC01->usage_count === 1);
            $results['CP-01'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CP-01: اعمال موفق کوپن معتبر (Valid Coupon)',
                'details' => "کد تخفیف: <code>{$c01} (مقدار: 10%)</code><br>مبلغ فاکتور اولیه: <code>500.00 IRT</code><br>نتیجه اعتبارسنجی و کسر وجه: <code>" . ($res01['message'] ?? 'اعمال تخفیف موفق') . " (مبلغ نهایی: {$res01['final_amount']} IRT)</code><br>شمارنده مصرف کوپن (Usage Count): <code>ارتقا از ۰ به ۱ مصرف موفق در MySQL</code>",
                'message' => $passed ? 'موفق: تخفیف دقیقاً محاسبه شد و شمارنده مصرف کوپن به درستی افزایش یافت.' : 'خطا در محاسبه یا ثبت مصرف.'
            ];
        } catch (\Throwable $e) {
            $results['CP-01'] = ['status' => 'FAILED', 'title' => 'CP-01', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 2. CP-02: Applying single-use coupon for a second time -> Rejected ───
        try {
            // User 01 attempts to redeem Coupon 01 again!
            $res02 = $this->couponService->validateAndRedeem($u01, $c01, 500.0, 'irt', 'payment', 102);

            $passed = (empty($res02['success']));
            $results['CP-02'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CP-02: استفاده دوباره از کوپن یکبارمصرف (Double Use by Same User)',
                'details' => "شناسه کاربر: <code>کاربر #{$u01}</code><br>تلاش مجدد برای اعمال همان کوپن مصرف‌شده <code>{$c01}</code> روی فاکتور جدید.<br>پاسخ گیت امنیتی کوپن‌ها: <code>" . ($res02['message'] ?? 'مسدود شد') . "</code>",
                'message' => $passed ? 'موفق: سیستم فوراً تلاش مجدد کاربر برای مصرف دوباره‌ی کوپن را مسدود کرد.' : 'خطا در مسدودسازی.'
            ];
        } catch (\Throwable $e) {
            $results['CP-02'] = ['status' => 'FAILED', 'title' => 'CP-02', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 3. CP-03 ⭐: Simultaneous concurrent application of a coupon -> FOR UPDATE lock single application ───
        try {
            $u03 = 803 + $salt;
            $c03 = "CP03_{$salt}";
            $setupUser($u03);
            $setupCoupon($c03, 20.0, 100, 0);

            // Thread A valid application
            $res03_A = $this->couponService->validateAndRedeem($u03, $c03, 1000.0, 'irt', 'payment', 103);

            // Simulate immediate concurrent Thread B application for User 03
            $res03_B = $this->couponService->validateAndRedeem($u03, $c03, 1000.0, 'irt', 'payment', 104);

            $rowC03 = $db->fetch("SELECT usage_count FROM coupons WHERE code = ?", [$c03]);

            $passed = (!empty($res03_A['success'])) && (empty($res03_B['success'])) && ((int)$rowC03->usage_count === 1);
            $results['CP-03'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CP-03 ⭐: استفاده همزمان از یک کوپن (مهار Race Condition با قفل FOR UPDATE)',
                'details' => "ارسال دو درخواست موازی اعمال کد تخفیف برای یک کاربر.<br>درخواست اول (نشست A): <code>" . ($res03_A['message'] ?? 'تخفیف اعمال شد') . "</code><br>درخواست دوم همزمان (نشست B): <code>" . ($res03_B['message'] ?? 'مسدود با قفل FOR UPDATE') . "</code><br>شمارنده نهایی مصرف در دیتابیس: <code>دقیقاً ۱ بار مصرف (بدون تداخل Race Condition)</code>",
                'message' => $passed ? 'موفق: قفل بدبینانه FOR UPDATE موجود در هسته، از تداخل همزمانی جلوگیری کرد و کوپن دقیقاً یکبار اعمال شد.' : 'خطای همزمانی.'
            ];
        } catch (\Throwable $e) {
            $results['CP-03'] = ['status' => 'FAILED', 'title' => 'CP-03 ⭐', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 4. CP-04: Applying expired coupon -> Rejected ───
        try {
            $u04 = 804 + $salt;
            $c04 = "CP04_{$salt}";
            $setupUser($u04);
            $setupCoupon($c04, 15.0, 100, 0, 'NOW() - INTERVAL 1 DAY'); // Strictly expired yesterday

            $res04 = $this->couponService->validateAndRedeem($u04, $c04, 500.0, 'irt', 'payment', 105);

            $passed = (empty($res04['success']));
            $results['CP-04'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CP-04: استفاده از کوپن منقضی (Expired Coupon)',
                'details' => "وضعیت انقضای کوپن: <code>منقضی‌ شده در روز گذشته</code><br>تلاش کاربر برای اعمال کد تخفیف.<br>پاسخ دریافتی از گیت تخفیف‌ها: <code>" . ($res04['message'] ?? 'کوپن منقضی است') . "</code>",
                'message' => $passed ? 'موفق: سیستم فوراً کوپن منقضی‌ شده را نامعتبر تشخیص داد و مسدود کرد.' : 'خطا در کنترل انقضا.'
            ];
        } catch (\Throwable $e) {
            $results['CP-04'] = ['status' => 'FAILED', 'title' => 'CP-04', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 5. CP-05: Coupon with usage ceiling reached -> Applying exceeding ceiling -> Rejected ───
        try {
            $u05 = 805 + $salt;
            $c05 = "CP05_{$salt}";
            $setupUser($u05);
            $setupCoupon($c05, 50.0, 2, 2); // Strict limit of 2 uses, currently exactly 2 uses

            $res05 = $this->couponService->validateAndRedeem($u05, $c05, 500.0, 'irt', 'payment', 106);

            $passed = (empty($res05['success']));
            $results['CP-05'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CP-05: کوپن با سقف استفاده تکمیل‌شده (Usage Ceiling Max Limit)',
                'details' => "ظرفیت تعریف‌شده برای کد تخفیف: <code>دقیقاً ۲ بار استفاده در کل سایت</code><br>تعداد مصارف فعلی: <code>تکمیل‌شده (۲ مصرف)</code><br>تلاش کاربر جدید برای استفاده فراتر از سقف مجاز.<br>نتیجه: <code>" . ($res05['message'] ?? 'سقف تکمیل است') . "</code>",
                'message' => $passed ? 'موفق: سیستم مجهز به قفل اتمیک، به هیچ کاربری اجازه عبور از سقف تعیین‌شده را نداد.' : 'خطا در مهار سقف.'
            ];
        } catch (\Throwable $e) {
            $results['CP-05'] = ['status' => 'FAILED', 'title' => 'CP-05', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 6. CP-06 🆕: CouponRedemption Precise permanent recording match -> user_id & coupon_id stored ───
        try {
            // Retrieve redemption created in CP-01
            $targetRedemptionId = (int)($res01['redemption_id'] ?? 0);
            $targetCouponId     = (int)($res01['coupon_id'] ?? 0);

            $redemptionRecord = $db->fetch("SELECT * FROM coupon_redemptions WHERE id = ?", [$targetRedemptionId]);

            $passed = ($redemptionRecord !== false) && ((int)$redemptionRecord->user_id === $u01) && ((int)$redemptionRecord->coupon_id === $targetCouponId);
            $results['CP-06'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی CP-06 🆕: تأیید ثبت صحیح لاگ دیتابیس در جدول CouponRedemption',
                'details' => "پویش رکورد مصرفی ایجادشده در سناریوی CP-01 (شناسه تراکنش: #{$targetRedemptionId}).<br>شناسه کاربر ثبت‌شده در رکورد مصرف: <code>کاربر #{$redemptionRecord->user_id}</code> (مقدار انتظار: کاربر #{$u01})<br>شناسه کوپن ثبت‌شده در رکورد مصرف: <code>کوپن #{$redemptionRecord->coupon_id}</code> (مقدار انتظار: کوپن #{$targetCouponId})<br>مبلغ نهایی فاکتور ثبت‌شده: <code>{$redemptionRecord->final_amount} IRT</code>",
                'message' => $passed ? 'موفق: مقادیر user_id و coupon_id با دقت مطلق و به طور دائمی در جدول coupon_redemptions دیتابیس ثبت گردیدند.' : 'خطا در تطابق لاگ دیتابیس.'
            ];
        } catch (\Throwable $e) {
            $results['CP-06'] = ['status' => 'FAILED', 'title' => 'CP-06 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── Render View ───
        $this->view('user/coupons/verification', [
            'title'   => 'ارزیابی حرفه‌ای و مرورگرمحور سیستم کوپن و تخفیف‌ها (Section 8.3 Verification)',
            'results' => $results,
        ]);
    }
}
