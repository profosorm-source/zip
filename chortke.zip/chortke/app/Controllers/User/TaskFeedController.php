<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Services\UnifiedTaskService;
use App\Services\Interaction\RatingService;

/**
 * TaskFeedController - The Master Dashboard for Workers to Find and Filter Earning Tasks.
 */
class TaskFeedController extends BaseController
{
    private UnifiedTaskService $taskService;
    /** @var RatingService|null 🛡️ FIX-SOCRATE-DISPLAY-01: سرویس امتیاز (اختیاری — lazy از کانتینر) */
    private ?RatingService $ratingService = null;

    public function __construct(
        UnifiedTaskService $taskService,
        ?\App\Contracts\LoggerInterface $logger = null,
        ?RatingService $ratingService = null
    ) {
        $this->taskService = $taskService;
        $this->ratingService = $ratingService;
        parent::__construct(null, null, null, null, $logger);
    }

    /** 🛡️ FIX-SOCRATE-DISPLAY-01: سرویس امتیاز به‌صورت lazy (nullable از سازنده یا کانتینر) */
    private function ratingService(): RatingService
    {
        return $this->ratingService ??= app(RatingService::class);
    }

    /**
     * Display the Unified Dynamic Task Feed / Earning Hub.
     */
    public function index(): void
    {
        $userId = (int)user_id();
        $filters = [
            'type'      => $this->request->query('type'),
            'platform'  => $this->request->query('platform'),
            'min_price' => $this->request->query('min_price'),
            'max_price' => $this->request->query('max_price'),
            // 🛡️ FIX-BEHAV1-06 (A2-N4): ارزِ قید/مرتب‌سازی قیمت (پیش‌فرض irt در
            // سرویس — مقیاس quick-tabهای UI)؛ قابل تغییر با ?currency=usdt.
            'currency'  => $this->request->query('currency'),
            'q'         => $this->request->query('q'),
            'sort'      => $this->request->query('sort', 'newest'),
        ];

        $page   = max(1, $this->request->int('page', 1));
        $limit  = 20;
        $offset = ($page - 1) * $limit;

        $tasks = [];
        $totalTasks = 0;
        $totalPages = 1;
        $platforms = [];
        $userStats = (object)['total_completed' => 0, 'total_earned' => 0, 'pending' => 0];

        try {
            $tasks      = $this->taskService->getTasksForExecutor($userId, $filters, $limit, $offset);
            $totalTasks = (int)$this->taskService->countTasksForExecutor($userId, $filters);
            $totalPages = max(1, (int)ceil($totalTasks / $limit));
            $platforms  = $this->taskService->getAvailablePlatforms();
            $userStats  = (object)$this->taskService->getExecutorStats($userId);
        } catch (\Throwable $e) {
            $this->logger->warning('earn_hub.feed_unavailable', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
        }

        // 🛡️ FIX-SOCRATE-DISPLAY-01 (قرینهٔ FIX-SEO3-01 برای سوشیال): میانگین
        // رأی کاربران به کمپین سوشیال برای کارت‌های همین فید — بازار یکپارچهٔ
        // تسک‌ها تنها فهرست وبِ تسک‌های سوشیال است (صفحهٔ اختصاصی سوشیال به
        // همین بازار ارجاع می‌دهد؛ سئو ستاره‌هایش را از صفحهٔ اختصاصی خودش
        // می‌گیرد). یک کوئری batch برای کل صفحه (نه per-card)؛ رأی‌ها فقط از
        // مجریِ اجرای تأییدشده ثبت می‌شوند (گارد SocialTaskService::rateTask)
        // پس این عدد قابل‌اعتماد است.
        $socialAdIds = [];
        foreach ($tasks as $task) {
            if (is_object($task) && in_array((string)($task->type ?? ''), ['social', 'social_task'], true)) {
                $socialAdIds[] = (int)($task->id ?? 0);
            }
        }
        $socialRatings = $socialAdIds === []
            ? []
            : $this->ratingService()->getRatingsSummary('social_task', $socialAdIds);

        view('user.tasks.feed', [
            'tasks'       => $tasks,
            'totalTasks'  => $totalTasks,
            'totalPages'  => $totalPages,
            'currentPage' => $page,
            'filters'     => $filters,
            'platforms'   => $platforms,
            'userStats'   => $userStats,
            'totalDone'   => $userStats->total_completed ?? 0,
            'socialRatings' => $socialRatings,
        ]);
    }
}
