<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\FraudReport;

/**
 * FraudReportController — ثبت گزارش تخلف توسط کاربر (X372، راند ۹۳)
 *
 * POST /referral/report-fraud (گروه $referralAuth: Auth + CSRF + RequireFeature:referral)
 * فرم «گزارش تخلف» هاب رفرال را دریافت و در جدول یتیمِ fraud_reports می‌نویسد —
 * سبک خانه: آینهٔ MessageModerationService::submitReport (گارد → ضد تکرار → ثبت → لاگ).
 * پاسخ: فرم کلاسیک است → flash + redirect به /referral؛ کلاینت AJAX → JSON.
 */
class FraudReportController extends BaseUserController
{
    private FraudReport $fraudReport;

    public function __construct(
        FraudReport $fraudReport,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->fraudReport = $fraudReport;
    }

    public function store(): void
    {
        $this->requireAuth();
        // دفاع در عمق: CSRFMiddleware روی مسیر هم فعال است؛ چک دوم بی‌ضرر است
        // (توکن نشست مصرف‌شدنی نیست — Core\CSRF::validate فقط صحت را می‌سنجد).
        $this->validateCsrf();

        $reporterId = (int)$this->userId();

        try {
            $reportedUserId = (int)$this->request->input('reported_user_id', 0);
            $reasonKey      = trim(str_value($this->request->input('reason', '')));
            $evidenceText   = trim(str_value($this->request->input('evidence', '')));

            // ① گزارش‌شده باید کاربرِ موجود و غیرِ خودِ گزارش‌دهنده باشد
            if ($reportedUserId <= 0) {
                $this->fail('شناسهٔ کاربر گزارش‌شده نامعتبر است.');
                return;
            }
            if ($reportedUserId === $reporterId) {
                $this->fail('نمی‌توانید خودتان را گزارش کنید.');
                return;
            }
            $reported = $this->userService->find($reportedUserId);
            if (!$reported) {
                $this->fail('کاربرِ گزارش‌شده یافت نشد.');
                return;
            }

            // ② دلیل باید از واژه‌نامهٔ کنترل‌شدهٔ مدل باشد (reason در DB آزاد/TEXT است؛
            //    محدودسازی در لایهٔ کنترلر — تصمیم راند ۹۳)
            if (!array_key_exists($reasonKey, FraudReport::REASONS)) {
                $this->fail('دلیل گزارش انتخاب‌شده معتبر نیست.');
                return;
            }

            // ③ شواهد متنی اختیاری، حداکثر ۱۰۰۰ کاراکتر
            if (mb_strlen($evidenceText) > FraudReport::MAX_EVIDENCE_LENGTH) {
                $this->fail('متن شواهد حداکثر می‌تواند ۱۰۰۰ کاراکتر باشد.');
                return;
            }

            // ④ ضد تکرار: هر جفت (گزارش‌دهنده، گزارش‌شده) فقط یک گزارشِ pending باز
            if ($this->fraudReport->hasPendingReport($reporterId, $reportedUserId)) {
                $this->fail('شما یک گزارشِ در انتظارِ بررسی برای همین کاربر دارید؛ لطفاً منتظر بررسی ادمین بمانید.');
                return;
            }

            // ⑤ سقف نرخ: حداکثر ۳ گزارش pending در ۲۴ ساعت به‌ازای هر گزارش‌دهنده
            if ($this->fraudReport->pendingCountForReporter($reporterId) >= FraudReport::MAX_PENDING_PER_24H) {
                $this->fail('تعداد گزارش‌های باز شما بیش از حد مجاز است؛ لطفاً پس از ۲۴ ساعت دوباره تلاش کنید.');
                return;
            }

            $reportId = $this->fraudReport->createReport($reporterId, $reportedUserId, $reasonKey, [
                'text'   => $evidenceText !== '' ? $evidenceText : null,
                'source' => 'referral_hub',
            ]);

            // آینهٔ خانه: فقط لاگ ساخت‌یافته — هیچ رویداد outbox/نوتیفیکیشن تازه‌ای در این مسیر تعریف نمی‌شود
            $this->logger->info('fraud_report.submitted', [
                'report_id'        => $reportId,
                'reporter_id'      => $reporterId,
                'reported_user_id' => $reportedUserId,
                'reason'           => $reasonKey,
                'source'           => 'referral_hub',
            ]);

            if (is_ajax()) {
                $this->response->json([
                    'success'   => true,
                    'message'   => 'گزارش شما ثبت شد و پس از بررسی ادمین اقدام می‌شود.',
                    'report_id' => $reportId,
                ]);
                return;
            }

            $this->session->setFlash('success', 'گزارش شما ثبت شد و پس از بررسی ادمین اقدام می‌شود.');
            $this->response->redirect(url('/referral'));
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) {
            $this->logger->error('fraud_report.submit_failed', [
                'reporter_id' => $reporterId,
                'error'       => $e->getMessage(),
            ]);
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, $reporterId, [
                'operation' => 'fraud_report.submit',
            ]);
            $this->fail('خطا در ثبت گزارش؛ لطفاً دوباره تلاش کنید.');
        }
    }

    /**
     * پاسخ خطا: فرم کلاسیک → فلش + بازگشت به هاب رفرال؛ AJAX → JSON ۴۲۲.
     */
    private function fail(string $message): void
    {
        if (is_ajax()) {
            $this->response->json(['success' => false, 'message' => $message], 422);
            return;
        }
        $this->session->setFlash('error', $message);
        $this->response->redirect(url('/referral'));
    }
}
