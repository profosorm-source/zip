<?php

namespace App\Controllers\User;

use App\Models\KYCVerification;
use App\Services\KYCService;
use App\Services\UploadService;
use App\Policies\RateLimitPolicy;
use App\Controllers\User\BaseUserController;

class KYCController extends BaseUserController
{
    private KYCService      $kycService;
    private KYCVerification $kycModel;
    private RateLimitPolicy $rateLimitPolicy;

    public function __construct(
        KYCVerification $kycModel,
        KYCService $kycService,
        RateLimitPolicy $rateLimitPolicy,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->kycModel   = $kycModel;
        $this->kycService = $kycService;
        $this->rateLimitPolicy = $rateLimitPolicy;
    }

    /**
     * صفحه اصلی احراز هویت (داشبورد + وضعیت)
     */
    public function index(): void
    {
        $userId = (int)$this->userId();
        $kyc = null;
        $canSubmit = ['can' => true, 'reason' => ''];

        try {
            // FIX-X168: رکورد کاربر با رمزگشایی + ماسک PII — قبلاً مدل خام می‌آمد و
            // در ویو فرگمنت ciphertext به‌جای کد ملی ماسک‌شده نمایش داده می‌شد
            $kyc = $this->kycService->findForUser($userId);
        } catch (\Throwable $e) {
            $this->logger->warning('kyc.index.lookup_failed', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
        }

        try {
            $canSubmit = $this->kycService->canSubmitKYC($userId);
        } catch (\Throwable $e) {
            $this->logger->warning('kyc.index.can_submit_failed', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
            $canSubmit = [
                'can' => false,
                'reason' => 'در حال حاضر امکان بررسی وضعیت احراز هویت وجود ندارد. لطفاً کمی بعد دوباره تلاش کنید.',
            ];
        }

        $this->view('user/kyc/index', [
            'title'      => 'احراز هویت',
            'kyc'        => $kyc,
            'canSubmit'  => $canSubmit,
            'appName'    => config('app.name', 'سایت'),
            'todayJalali'=> to_jalali(date('Y-m-d')),
        ]);
    }

    /**
     * صفحه آپلود مدارک
     */
    public function upload(): void
    {
        $userId = (int)$this->userId();
        $canSubmit = ['can' => true, 'reason' => ''];

        try {
            $canSubmit = $this->kycService->canSubmitKYC($userId);
        } catch (\Throwable $e) {
            $this->logger->warning('kyc.upload.can_submit_failed', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
            ]);
            $canSubmit = [
                'can' => false,
                'reason' => 'در حال حاضر امکان ثبت درخواست احراز هویت وجود ندارد. لطفاً کمی بعد دوباره تلاش کنید.',
            ];
        }

        $this->view('user/kyc/upload', [
            'title'      => 'آپلود مدارک احراز هویت',
            'canSubmit'  => (bool)($canSubmit['can'] ?? false),
            'error'      => $canSubmit['reason'] ?? null,
            'errors'     => session()->getFlash('errors') ?? [],
            'appName'    => config('app.name', 'سایت'),
            'todayJalali'=> to_jalali(date('Y-m-d')),
        ]);
    }

    /**
     * ثبت درخواست احراز هویت
     */
    public function submit(): mixed
    {
        $userId = (int)$this->userId();
        $deviceFingerprint = generate_device_fingerprint();

        if (!$this->rateLimitPolicy->check('kyc_submit', $userId)) {
            $this->rateLimitPolicy->tooManyResponse('kyc_submit', $userId, is_ajax());
        }
        if (!$this->rateLimitPolicy->check('kyc_submit', get_client_ip())) {
            $this->rateLimitPolicy->tooManyResponse('kyc_submit', get_client_ip(), is_ajax());
        }
        if (!$this->rateLimitPolicy->check('kyc_submit', $deviceFingerprint)) {
            $this->rateLimitPolicy->tooManyResponse('kyc_submit', $deviceFingerprint, is_ajax());
        }

        $data = $this->request->all();

        $validator = $this->validatorFactory()->make($data, [
            'national_code' => 'required|digits:10',
            'birth_date'    => 'required',
        ]);

        if ($validator->fails()) {
            session()->setFlash('errors', $validator->errors());
            return redirect('/kyc/upload');
        }

        if (empty($_FILES['verification_image'])) {
            session()->setFlash('errors', [
                'verification_image' => ['تصویر احراز هویت الزامی است'],
            ]);
            return redirect('/kyc/upload');
        }

        if (($_FILES['verification_image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $uploadError = (int)($_FILES['verification_image']['error'] ?? UPLOAD_ERR_NO_FILE);
            $message = match ($uploadError) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'حجم فایل انتخاب‌شده بیش از حد مجاز است. لطفاً تصویری کمتر از ۵ مگابایت بارگذاری کنید.',
                UPLOAD_ERR_NO_FILE => 'تصویر احراز هویت الزامی است',
                default => 'خطا در بارگذاری فایل. لطفاً دوباره تلاش کنید.',
            };
            session()->setFlash('errors', [
                'verification_image' => [$message],
            ]);
            return redirect('/kyc/upload');
        }

        try {
            $result = $this->kycService->submitKYC(
                $userId,
                [
                    'national_code' => trim(str_value($data['national_code'] ?? '')),
                    'birth_date'    => $data['birth_date'],
                ],
                ['verification_image' => $_FILES['verification_image']]
            );
        } catch (\Core\Exceptions\BusinessException $e) {
            session()->setFlash('errors', [
                'verification_image' => [$e->getMessage()],
            ]);
            return redirect('/kyc/upload');
        }

        if ($result['success']) {
            // 🛡️ FIX-S10-22: اعلانِ ادمین به سرویس منتقل شد (KYCCommandService) —
            // تا مسیرِ API هم اعلان بگیرد و از اعلانِ دوباره جلوگیری شود.
            session()->setFlash('success', $result['message']);
            return redirect('/kyc');
        }

        session()->setFlash('errors', [
            'verification_image' => [$result['message'] ?? 'خطا در ثبت احراز هویت'],
        ]);
        return redirect('/kyc/upload');
    }

    /**
     * وضعیت KYC (AJAX یا redirect به index)
     */
    public function status(): mixed
    {
        $userId = (int)$this->userId();
        $kyc    = $this->kycModel->findByUserId($userId);

        if (!$kyc) {
            if (is_ajax()) {
                $this->response->json(['success' => false, 'message' => 'درخواستی یافت نشد'], 404);
                return null;
            }
            return redirect(url('/kyc'));
        }

        // 🔒 FIX-KYC-ENUM: نقشهٔ inline حذف شد — منبع واحد KycStatus (هلپر نمایشی؛
        // قبلاً این نسخه ۵ وضعیت با متن متفاوت داشت و نسخهٔ show() در همان کلاس
        // ۴ وضعیت — expired را گم می‌کرد و status خام چاپ می‌شد).
        if (is_ajax()) {
            $this->response->json([
                'success' => true,
                'kyc'     => [
                    'status'           => $kyc->status,
                    'status_label'     => kyc_status_label($kyc->status ?? null),
                    'submitted_at'     => $kyc->submitted_at,
                    'verified_at'      => $kyc->verified_at,
                    'rejection_reason' => $kyc->rejection_reason,
                ],
            ]);
            return null;
        }

        // درخواست معمولی → به index برگردان (اطلاعات در index نمایش داده می‌شود)
        return redirect(url('/kyc'));
    }
    public function show(int $id): void
    {
        // 🧭 FIX-X202 (راند ۵۳ — گزارش بصری کاربر از راند ۵۰): این مسیر برای «مرورگر»
        // صفحهٔ HTML نداشت و JSON خام با نمایشگر مرورگر نشان داده می‌شد (اسکرین‌شات
        // screenshots/round50/01-kyc-show-masked-json.png). قرارداد تازه = همان قرارداد
        // مستندِ status(): مرورگر → صفحهٔ واقعی (کاربر → /kyc خودش، ادمین → بررسی ادمین؛
        // ۴۰۴/IDOR → فلش+ردایرکت)، اما AJAX/API → همان JSON سفیدلیستِ X193 دست‌نخورده
        // (is_ajax() هم X-Requested-With و هم Accept: application/json را می‌سنجد؛
        // RuntimeHttpBehaviorTest با Accept: application/json قرارداد JSON را حفظ می‌کند).
        if (!is_ajax()) {
            $kyc = $this->kycService->find($id, true);

            if (!$kyc) {
                session()->setFlash('error', 'درخواست احراز هویتی یافت نشد');
                redirect(url('/kyc')); // 🛡️ FIX-PS-C3
            }

            $isOwner = (int)$kyc->user_id === (int)$this->userId();
            $isAdmin = $this->policyService->isAdminById((int)$this->userId());

            if (!$isOwner && !$isAdmin) {
                $this->logger->warning('kyc.idor_attempt_blocked', ['kyc_id' => $id, 'user_id' => (int)$this->userId(), 'ip' => $this->request->ip()]);
                session()->setFlash('error', 'دسترسی غیرمجاز');
                redirect(url('/kyc')); // 🛡️ FIX-PS-C3
            }

            // ادمینِ غریبه → صفحهٔ بررسی ادمین؛ مالک → صفحهٔ وضعیت خودش
            // 🛡️ FIX-PS-C3: redirect() never است — در void بدون return
            if (!$isOwner && $isAdmin) {
                redirect(url('/admin/kyc/review/' . $id));
            }
            redirect(url('/kyc'));
        }

        // ── قرارداد AJAX/API (X193 دست‌نخورده) ──
        // 🛡️ میراث X193 (راند ۵۰): پاسخ JSON «سفیدلیست fail-closed» است — رمزگشایی +
        // ماسک PII از سرویس X168؛ هر ستون حساس/فنیِ آینده خودبه‌خود بیرون پاسخ می‌ماند.
        $kyc = $this->kycService->find($id, true);

        if (!$kyc) {
            $this->response->status(404)->json(['success' => false, 'message' => 'یافت نشد']);
            return; // 🛡️ FIX-PS-C3: پس از json() (never) مرده است
        }

        // K-08 ⭐ Insecure Direct Object Reference (IDOR) Protection
        if ((int)$kyc->user_id !== (int)$this->userId() && !$this->policyService->isAdminById((int)$this->userId())) {
            $this->logger->warning('kyc.idor_attempt_blocked', ['kyc_id' => $id, 'user_id' => (int)$this->userId(), 'ip' => $this->request->ip()]);
            $this->response->json(['success' => false, 'message' => 'دسترسی غیرمجاز (IDOR)'], 403);
            return; // 🛡️ FIX-PS-C3: پس از json() (never) مرده است
        }

        // 🔒 FIX-KYC-ENUM: نقشهٔ inline ۴وضعیتی حذف شد — expired از این پاسخ JSON
        // غایب بود و رکورد منقضی status خام انگلیسی چاپ می‌شد؛ اکنون از منبع واحد
        // KycStatus می‌خواند (هم‌تراز status() در همین کلاس).
        $this->response->json(['success' => true, 'kyc' => [
            'id'               => (int)$kyc->id,
            'user_id'          => (int)$kyc->user_id,
            'status'           => $kyc->status,
            'status_label'     => kyc_status_label($kyc->status ?? null),
            'first_name'       => $kyc->first_name ?? null,
            'last_name'        => $kyc->last_name ?? null,
            // masked (۳ رقم اول + **** + ۲ رقم آخر) یا [CORRUPTED] — از سرویس X168
            'national_code'    => $kyc->national_code ?? null,
            'birth_date'       => $kyc->birth_date ?? null,
            'rejection_reason' => $kyc->rejection_reason ?? null,
            'submitted_at'     => $kyc->submitted_at ?? null,
            'reviewed_at'      => $kyc->reviewed_at ?? null,
            'verified_at'      => $kyc->verified_at ?? null,
            'expires_at'       => $kyc->expires_at ?? null,
            'documents_deleted'=> (int)($kyc->documents_deleted ?? 0),
        ]]);
    }
}
