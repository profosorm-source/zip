<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Services\AdSystemManager;
use App\Models\Ads;
use App\Models\BannerPlacement;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\UploadService;
use App\Services\Ads\AdsBudgetSettlementService;

/**
 * AdsController - The ultimate command center for Unified Modern Advertising (Unified UI).
 */
class AdsController extends BaseController
{
    /**
     * 🛡️ FIX-R3-F1 (P1 — R3 Ads/AdTube): فیلدهای «داخلیِ» چرخهٔ مالی که هرگز
     * نباید از ورودی کاربر پذیرفته شوند. کلید coupon_charge_total مبلغ
     * برداشت/اسکرو را در مرحلهٔ calculate_and_hold_funds ساگا override می‌کرد؛
     * با پاس‌دادن آن (بدون کوپنِ معتبر) کاربر می‌توانست مبلغ قفل‌شده را از
     * بودجهٔ واقعی کمپین جدا کند → کمپینِ زیرِ سرمایه. اکنون در مرز کنترلر
     * حذف می‌شوند و فقط پس از اعتبارسنجی سمتِ سرورِ کوپن در AdSystemManager::create
     * دوباره ست می‌شوند (دفاع در عمق: خود سرویس هم unset می‌کند).
     */
    private const INTERNAL_PAYLOAD_FIELDS = ['coupon_charge_total', 'coupon_site_commission_percent'];

    private AdSystemManager $adManager;
    private Ads $adModel;
    private BannerPlacement $placementModel;
    private CustomTaskModerationService $moderationService;
    private UploadService $uploadService;
    private AdsBudgetSettlementService $adsBudgetSettlement;
    /** 🧹 DI-CLEANUP (2026-08-24): به‌جای app(Notification::class) در بدنه‌ی متدها. */
    private \App\Models\Notification $notifModel;

    public function __construct(
        AdSystemManager $adManager,
        Ads $adModel,
        BannerPlacement $placementModel,
        CustomTaskModerationService $moderationService,
        UploadService $uploadService,
        AdsBudgetSettlementService $adsBudgetSettlement,
        \App\Models\Notification $notifModel,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        $this->adManager = $adManager;
        $this->adModel = $adModel;
        $this->placementModel = $placementModel;
        $this->moderationService = $moderationService;
        $this->uploadService = $uploadService;
        $this->adsBudgetSettlement = $adsBudgetSettlement;
        $this->notifModel = $notifModel;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * Unified Dashboard / "My Ads" Listing.
     */
    public function index(): void
    {
        $userId = (int)user_id();
        
        $ads = $this->adManager->getUserAds($userId);
        $summaryData = $this->adManager->getAdSummary($userId);

        view('user.ads.index', compact('ads', 'summaryData'));
    }

    /**
     * The AJAX Ad Wizard - Single Entry Point.
     */
    public function create(): void
    {
        // دریافت Placements از Model
        $placements = $this->placementModel->where('is_active', '=', 1)->get();
        
        view('user.ads.create', compact('placements'));
    }

    /**
     * High-speed AJAX storage directly forwarding payload to mapped Adapter strategies.
     */
    public function store(): void
    {
        header('Content-Type: application/json');
        $data = is_array($this->request->input()) ? $this->request->input() : [];
        // 🛡️ FIX-R3-F1 (P1): فیلدهای مالی داخلی (coupon_charge_total و …) پیش از
        // هر استفاده از پیلودِ خام حذف می‌شوند؛ مبلغ برداشت فقط از quoteِ سرور می‌آید.
        foreach (self::INTERNAL_PAYLOAD_FIELDS as $internalField) {
            unset($data[$internalField]);
        }
        $userId = (int)user_id();

        $type = $data['ad_type'] ?? null;

        if (!$type) {
            echo json_encode(['success' => false, 'message' => 'نوع تبلیغ نامعتبر است.']);
            return;
        }

        $data = $this->normalizeAdPayload((string)$type, $data);

        // R15 راند ۸۸ — pass-through توکن اعتبارسنجی کوپن: توکنِ مینت‌شده در
        // /api/ads/preview-cost (کلاینت آن را در coupon_token بازمی‌فرستد) به‌صورت
        // صریح به AdSystemManager::create پاس داده می‌شود تا در مرحله‌ی apply_coupon
        // مصرف شود. مقدار خالی/غیرواکنش‌گر (غیر hex-۳۲) → خالی؛ سرویس در آن صورت
        // از توکن تازه‌ی validateAndCalculate خودِ جریانِ ساخت استفاده می‌کند.
        $couponToken = trim(str_value($data['coupon_token'] ?? ''));
        $data['coupon_token'] = preg_match('/^[a-f0-9]{32}$/i', $couponToken) ? strtolower($couponToken) : '';

        if ((string)$type === 'banner' && !empty($_FILES['image']['name'])) {
            try {
                $upload = $this->uploadService->upload($_FILES['image'], 'banners', ['jpg', 'jpeg', 'png', 'webp'], 5 * 1024 * 1024);
                $data['image_path'] = $upload['path'];
            } catch (\Throwable $e) {
                echo json_encode(['success' => false, 'message' => 'آپلود تصویر بنر انجام نشد: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
                return;
            }
        }

        try {
            // Unified ad creation via AdSystemManager (Saga + Escrow)
            $data['user_id'] = $userId;
            // C06-باگ۴: کلید idempotency کلاینت (هدر X-Idempotency-Key یا فیلد بدنه)
            // تا دابل‌کلیک/retry ساخت دو آگهی و دو hold نسازد.
            $headerKey = $this->request->header('x-idempotency-key');
            $bodyKey = $data['idempotency_key'] ?? null;
            $idempotencyKey = (is_string($headerKey) ? $headerKey : '') ?: (is_string($bodyKey) ? $bodyKey : '');
            $idempotencyKey = trim($idempotencyKey) !== '' ? trim($idempotencyKey) : null;
            $result = $this->adManager->create((string)$type, $userId, $data, $idempotencyKey);

            echo json_encode([
                'success' => true,
                'message' => 'تبلیغ با موفقیت و امنیت کامل ثبت شد.',
                'ad_id' => $result['ad_id'] ?? null,
                'idempotency_key' => $idempotencyKey,
            ]);
        } catch (\Exception $e) {
            $this->logger->error('ads.store.failed', ['error' => $e->getMessage(), 'user_id' => $userId]);
            $isDomainError = $e instanceof \Core\Exceptions\BusinessException || $e instanceof \InvalidArgumentException || $e instanceof \Core\Exceptions\ValidationException;
            $userMsg = $isDomainError ? $e->getMessage() : 'بروز خطا در ثبت آگهی. لطفاً ورودی‌ها را بررسی کرده و مجدداً تلاش کنید.';
            echo json_encode([
                'success' => false, 
                'message' => $userMsg
            ], JSON_UNESCAPED_UNICODE);
        }
    }

    /**
     * Pause/Resume interaction directly from the list view.
     */
    public function toggleStatus(): void
    {
        header('Content-Type: application/json');
        $adId = $this->request->int('ad_id');
        $userId = (int)user_id();

        $result = $this->adManager->toggleAdStatus($adId, $userId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
    }

    public function cancel(): void
    {
        header('Content-Type: application/json');
        $adId = int_value($this->request->param('id'));
        $userId = (int)user_id();
        $reason = trim($this->request->str('reason', 'لغو توسط تبلیغ‌دهنده'));
        $result = $this->adManager->cancelAd($adId, $userId, $reason !== '' ? $reason : 'لغو توسط تبلیغ‌دهنده');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Ultimate Unified Analytics & Execution Log.
     */
    public function show(): void
    {
        $adId = (int)$this->request->param('id');
        $userId = (int)user_id();

        $ad = $this->adModel->where('id', '=', $adId)
            ->where('user_id', '=', $userId)
            ->whereNull('deleted_at')
            ->first();
        
        if (!$ad) {
            $this->session->setFlash('error', 'آگهی یافت نشد.');
            redirect(url('/ads'));
        }

        $executions = $this->adManager->getAdExecutions($adId, $ad->type);
        $stats = []; // Detailed stats logic should be in a service if needed
        $finance = $this->adsBudgetSettlement->financeSnapshot($adId, (string)$ad->type);

        // آمار engagement نوتیفیکیشن برای تبلیغ‌های type=notification
        $adStats = [];
        if (($ad->type ?? '') === 'notification') {
            $notifModel = $this->notifModel;
            $adStats = $notifModel->getAdAnalytics($adId, 30) ?: [];
        }

        view('user.ads.show', compact('ad', 'executions', 'stats', 'finance', 'adStats'));
    }


    /**
     * آمار engagement نوتیفیکیشنِ یک تبلیغِ تبلیغ‌دهنده (JSON برای فرانت/موبایل)
     * GET /ads/{id}/notification-stats
     */
    public function notificationStats(): void
    {
        // 🧭 FIX-X204 (راند ۵۴ — کلاسِ باگ X202): مرورگر → صفحهٔ خودِ آگهی؛ کلاینت AJAX/موبایل → قرارداد JSON دست‌نخورده
        $adId = (int)($this->request->param('id') ?? 0);
        if (!is_ajax()) {
            redirect(url('/ads/' . $adId)); // 🛡️ FIX-PS-C3
        }

        $userId = (int)user_id();

        $ad = $this->adModel->where('id', '=', $adId)
            ->where('user_id', '=', $userId)
            ->whereNull('deleted_at')
            ->first();

        if (!$ad) {
            $this->response->json(['success' => false, 'message' => 'آگهی یافت نشد.'], 404);
            return; // 🛡️ FIX-PS-C3
        }
        if (($ad->type ?? '') !== 'notification') {
            $this->response->json(['success' => false, 'message' => 'این آگهی از نوع نوتیفیکیشن نیست.'], 422);
            return; // 🛡️ FIX-PS-C3
        }

        $days      = max(1, min(365, $this->request->int('days', 30)));
        $notifModel = $this->notifModel;

        $this->response->json([
            'success' => true,
            'ad_id'   => $adId,
            'days'    => $days,
            'stats'   => $notifModel->getAdAnalytics($adId, $days) ?: [],
        ]);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeAdPayload(string $type, array $data): array
    {
        // ─── قرارداد کانونی واحد پول (W4-D، مصوبهٔ کلاینت) ───
        // مبالغ در داخل سایت «همیشه» تومان (IRT) هستند؛ مقیاس‌کردن (×۱۰/÷۱۰) فقط
        // و فقط در مرز آداپتورهای درگاه بانکی انجام می‌شود. کلاینتی که
        // currency=irr می‌فرستد فقط «برچسبِ» خودش را اعلام کرده، نه واحدِ مبلغ را —
        // پس برچسب به irt نرمال می‌شود و مبلغِ عددی دست‌نخورده (تومان) باقی می‌ماند.
        if (isset($data['currency'])) {
            $data['currency'] = strtolower(str_value($data['currency']));
            if (in_array($data['currency'], ['irr', 'rial'], true)) {
                $data['currency'] = 'irt';
                // FIX-R36-W3 (F-A19d-10 تکمیل ارکستراتور): همان هشدار ساختاریافتهٔ ۵ آداپتر —
                // ریلِیبل بی‌صدای irr→irt در سطح کنترلر هم قابل-مشاهده می‌شود.
                try {
                    logger()->warning('ads.currency.irr_relabelled_irt', [
                        'type' => $type,
                        'source_currency' => 'irr/rial',
                    ]);
                } catch (\Throwable $e) {
                    // هشدار هرگز جریان ایجاد آگهی را نمی‌شکند (best-effort، الگوی خانه)
                }
            }
        } else {
            $data['currency'] = 'irt';
        }

        if (!empty($data['target_link']) && empty($data['link'])) {
            $data['link'] = $data['target_link'];
        }
        if (!empty($data['link']) && empty($data['target_url'])) {
            $data['target_url'] = $data['link'];
        }

        if ($type === 'custom_task') {
            $count = int_value($data['total_count'] ?? $data['total_quantity'] ?? $data['quantity'] ?? 1);
            $price = str_value($data['price_per_task'] ?? 0);
            $data['total_count'] = max(1, $count);
            $data['total_quantity'] = $data['total_count'];
            if (empty($data['total_budget']) && is_numeric($price) && bccomp($price, '0', 8) > 0) {
                $data['total_budget'] = bcmul($price, (string)$data['total_count'], 8);
            }
            $data['proof_type'] = str_value($data['proof_type'] ?? 'text');
            $data['proof_description'] = str_value($data['proof_description'] ?? 'مدرک انجام تسک را طبق توضیح تسک ارسال کنید.');
            $data['deadline_hours'] = int_value($data['deadline_hours'] ?? 24);
        }

        if ($type === 'seo') {
            if (!empty($data['target_link']) && empty($data['site_url'])) {
                $data['site_url'] = $data['target_link'];
            }
            if (!empty($data['site_url']) && empty($data['target_url'])) {
                $data['target_url'] = $data['site_url'];
            }
            $data['budget'] = str_value($data['budget'] ?? $data['total_budget'] ?? 0);
            $data['total_budget'] = $data['budget'];
            $data['min_payout'] = str_value($data['min_payout'] ?? $data['price_per_click'] ?? 0);
            $seoPricePerClick = str_value($data['price_per_click'] ?? 0);
            $seoMaxDefault = (is_numeric($data['min_payout']) && is_numeric($seoPricePerClick) && bccomp($data['min_payout'], $seoPricePerClick, 8) >= 0) ? $data['min_payout'] : $seoPricePerClick;
            $data['max_payout'] = str_value($data['max_payout'] ?? $seoMaxDefault);
            $data['target_duration'] = int_value($data['target_duration'] ?? 60);
            $data['min_score'] = int_value($data['min_score'] ?? 40);
            $data['max_per_day'] = int_value($data['max_per_day'] ?? 10);
        }

        if (in_array($type, ['social_task', 'adtube'], true)) {
            $count = int_value($data['total_count'] ?? $data['quantity'] ?? 1);
            $price = str_value($data['price_per_task'] ?? 0);
            $data['total_count'] = max(1, $count);
            $data['total_budget'] = is_numeric($price) ? bcmul($price, (string)$data['total_count'], 8) : '0';
        }

        if (in_array($type, ['banner', 'notification'], true)) {
            $data['budget'] = str_value($data['budget'] ?? $data['total_budget'] ?? 0);
            $data['total_budget'] = $data['budget'];
        }

        return $data;
    }

    /**
     * تأیید submission یک تسک سفارشی (Unified — از CustomTaskAdController منتقل شد)
     */
    public function approveSubmission(): string
    {
        $userId = (int)user_id();
        $submissionId = int_value($this->request->param('id') ?? $this->request->post('submission_id') ?? 0);
        $note = trim($this->request->str('note'));

        if ($submissionId <= 0) {
            $this->session->setFlash('error', 'شناسه submission نامعتبر است.');
            return back();
        }

        $result = $this->moderationService->reviewSubmission($submissionId, $userId, 'approve', $note);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return back();
    }

    /**
     * رد submission یک تسک سفارشی (Unified — از CustomTaskAdController منتقل شد)
     */
    public function rejectSubmission(): string
    {
        $userId = (int)user_id();
        $submissionId = int_value($this->request->param('id') ?? $this->request->post('submission_id') ?? 0);
        $reason = trim($this->request->str('reason'));

        if ($submissionId <= 0) {
            $this->session->setFlash('error', 'شناسه submission نامعتبر است.');
            return back();
        }

        if (empty($reason)) {
            $this->session->setFlash('error', 'دلیل رد الزامی است.');
            return back();
        }

        $result = $this->moderationService->reviewSubmission($submissionId, $userId, 'reject', $reason);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return back();
    }
}

