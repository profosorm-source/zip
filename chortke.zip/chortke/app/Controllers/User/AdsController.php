<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Services\AdSystemManager;
use App\Models\Ads;
use App\Models\BannerPlacement;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\UploadService;
use App\Services\Ads\AdsBudgetSettlementService;
use App\Services\SeoLandingProofService;

/**
 * AdsController - The ultimate command center for Unified Modern Advertising (Unified UI).
 */
class AdsController extends BaseController
{
    /**
     * 🛡️ FIX-R3-F1 (P1 — R3 Ads/AdTube): فیلدهای «داخلیِ» چرخهٔ مالی که هرگز
     * نباید از ورودی کاربر پذیرفته شوند. کلید coupon_charge_total مبلغ
     * برداشت/اسکرو را در مرحلهٔ calculate_and_hold_funds ساگا override می‌کرد؛
     * با پاس‌دادن آن (بدون کوپنِ معتبر) کاربر می‌توانست مبلغ قفل‌شده را از
     * بودجهٔ واقعی کمپین جدا کند → کمپینِ زیرِ سرمایه. اکنون در مرز کنترلر
     * حذف می‌شوند و فقط پس از اعتبارسنجی سمتِ سرورِ کوپن در AdSystemManager::create
     * دوباره ست می‌شوند (دفاع در عمق: خود سرویس هم unset می‌کند).
     */
    private const INTERNAL_PAYLOAD_FIELDS = ['coupon_charge_total', 'coupon_site_commission_percent'];

    private AdSystemManager $adManager;
    private Ads $adModel;
    private BannerPlacement $placementModel;
    private CustomTaskModerationService $moderationService;
    private UploadService $uploadService;
    private AdsBudgetSettlementService $adsBudgetSettlement;
    /** 🧹 DI-CLEANUP (2026-08-24): به‌جای app(Notification::class) در بدنه‌ی متدها. */
    private \App\Models\Notification $notifModel;

    public function __construct(
        AdSystemManager $adManager,
        Ads $adModel,
        BannerPlacement $placementModel,
        CustomTaskModerationService $moderationService,
        UploadService $uploadService,
        AdsBudgetSettlementService $adsBudgetSettlement,
        \App\Models\Notification $notifModel,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        $this->adManager = $adManager;
        $this->adModel = $adModel;
        $this->placementModel = $placementModel;
        $this->moderationService = $moderationService;
        $this->uploadService = $uploadService;
        $this->adsBudgetSettlement = $adsBudgetSettlement;
        $this->notifModel = $notifModel;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * Unified Dashboard / "My Ads" Listing.
     */
    public function index(): void
    {
        $userId = (int)user_id();
        
        $ads = $this->adManager->getUserAds($userId);
        $summaryData = $this->adManager->getAdSummary($userId);

        view('user.ads.index', compact('ads', 'summaryData'));
    }

    /**
     * The AJAX Ad Wizard - Single Entry Point.
     */
    public function create(): void
    {
        // دریافت Placements از Model
        $placements = $this->placementModel->where('is_active', '=', 1)->get();
        
        view('user.ads.create', compact('placements'));
    }

    /**
     * High-speed AJAX storage directly forwarding payload to mapped Adapter strategies.
     */
    public function store(): void
    {
        header('Content-Type: application/json');
        $data = is_array($this->request->input()) ? $this->request->input() : [];
        // 🛡️ FIX-R3-F1 (P1): فیلدهای مالی داخلی (coupon_charge_total و …) پیش از
        // هر استفاده از پیلودِ خام حذف می‌شوند؛ مبلغ برداشت فقط از quoteِ سرور می‌آید.
        foreach (self::INTERNAL_PAYLOAD_FIELDS as $internalField) {
            unset($data[$internalField]);
        }
        $userId = (int)user_id();

        $type = $data['ad_type'] ?? null;

        if (!$type) {
            echo json_encode(['success' => false, 'message' => 'نوع تبلیغ نامعتبر است.']);
            return;
        }

        // 🛡️ FIX-M10-R2 (گزارش ماژول ۱۰ — بقایای KYC): گیتِ صلاحیتِ واحدِ KYC برای ساخت تسک سفارشی.
        // ریشه: گیت KYC فقط در جابِ یتیمِ ایجاد تسک سفارشی (حذف‌شده در T22-19؛ بدون
        // allowlist صف) وجود داشت و مسیرِ زندهٔ واقعی AdsController::store →
        // AdSystemManager::create → CustomTaskAdapter هیچ گیتِ KYC نداشت — کاربرِ
        // احراز-هویت-نشده یا verified-منقضی می‌توانست کمپین بسازد. ضمناً whitelist قدیمی
        // ['verified','approved'] خارج از قراردادِ واحدِ FIX-M10-13 بود و 'approved' در
        // enum فعلی وجود ندارد. گیت اینجا (تک‌ورودیِ زندهٔ custom_task) با
        // KycEligibilityService (verified + expires_at > NOW، fail-closed) اعمال می‌شود و
        // فقط وقتی تنظیم محصول الزام را روشن کرده باشد. (نقطهٔ گیت عمداً کنترلر است؛
        // قرار دادن آن در AdSystemManager/Adapter ساگای تست‌شدهٔ SagaSystemTest را هم می‌شکند.)
        if ((string)$type === 'custom_task'
            && filter_var(setting('custom_task_kyc_required', true), FILTER_VALIDATE_BOOLEAN)
            && !app(\App\Services\KYC\KycEligibilityService::class)->isEligible($userId)
        ) {
            echo json_encode([
                'success' => false,
                'message' => 'برای ایجاد تسک سفارشی، احراز هویت (KYC) معتبر الزامی است.',
            ], JSON_UNESCAPED_UNICODE);
            return;
        }

        $data = $this->normalizeAdPayload((string)$type, $data);

        // R15 راند ۸۸ — pass-through توکن اعتبارسنجی کوپن: توکنِ مینت‌شده در
        // /api/ads/preview-cost (کلاینت آن را در coupon_token بازمی‌فرستد) به‌صورت
        // صریح به AdSystemManager::create پاس داده می‌شود تا در مرحله‌ی apply_coupon
        // مصرف شود. مقدار خالی/غیرواکنش‌گر (غیر hex-۳۲) → خالی؛ سرویس در آن صورت
        // از توکن تازه‌ی validateAndCalculate خودِ جریانِ ساخت استفاده می‌کند.
        $couponToken = trim(str_value($data['coupon_token'] ?? ''));
        $data['coupon_token'] = preg_match('/^[a-f0-9]{32}$/i', $couponToken) ? strtolower($couponToken) : '';

        if ((string)$type === 'banner' && !empty($_FILES['image']['name'])) {
            try {
                $upload = $this->uploadService->upload($_FILES['image'], 'banners', ['jpg', 'jpeg', 'png', 'webp'], 5 * 1024 * 1024);
                $data['image_path'] = $upload['path'];
            } catch (\Throwable $e) {
                echo json_encode(['success' => false, 'message' => 'آپلود تصویر بنر انجام نشد: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
                return;
            }
        }

        try {
            // Unified ad creation via AdSystemManager (Saga + Escrow)
            $data['user_id'] = $userId;
            // C06-باگ۴: کلید idempotency کلاینت (هدر X-Idempotency-Key یا فیلد بدنه)
            // تا دابل‌کلیک/retry ساخت دو آگهی و دو hold نسازد.
            $headerKey = $this->request->header('x-idempotency-key');
            $bodyKey = $data['idempotency_key'] ?? null;
            $idempotencyKey = (is_string($headerKey) ? $headerKey : '') ?: (is_string($bodyKey) ? $bodyKey : '');
            $idempotencyKey = trim($idempotencyKey) !== '' ? trim($idempotencyKey) : null;

            // ═══ 🛡️ FIX-S20-CLOSE-F3 (پایان‌کار بازبینی S20 — یافتهٔ ۲ — شکاف الف) ═══
            // کلید idempotency سمت سرور «الزامی» است. قبلاً POST مستقیم به API بدون
            // کلید، بی‌هیچ گاردی از کنترلر رد می‌شد و دو درخواست موازی = دو کمپین +
            // دو hold مالی. ویزارد از قبل کلید می‌فرستد (S20)؛ فقط مسیر دورزنندهٔ
            // مستقیم بسته می‌شود — نه کلاینت صادق.
            if ($idempotencyKey === null) {
                echo json_encode([
                    'success' => false,
                    'message' => 'کلید تکرارنشدن (Idempotency-Key) الزامی است — هدر X-Idempotency-Key یا فیلد idempotency_key را در هر «قصد ثبت» یکسان و برای هر قصد جدید، تازه بفرستید.',
                ], JSON_UNESCAPED_UNICODE);
                return;
            }
            if (strlen($idempotencyKey) < 8 || strlen($idempotencyKey) > 128
                || !preg_match('/^[A-Za-z0-9_\-]+$/', $idempotencyKey)
            ) {
                echo json_encode([
                    'success' => false,
                    'message' => 'قالب کلید تکرارنشدن (Idempotency-Key) نامعتبر است — رشتهٔ ۸ تا ۱۲۸ کاراکتری از حروف/رقم/خط تیره.',
                ], JSON_UNESCAPED_UNICODE);
                return;
            }

            // ═══ 🛡️ FIX-S20-CLOSE-F3 (یافتهٔ ۲ — شکاف ب): اثر انگشت payload سمت سرور ═══
            // قبلاً کلید صریح با «پیلود خالی» در idempotency ثبت می‌شد؛ یعنی همان
            // کلید با پیلود متفاوت، بی‌صدا نتیجهٔ قدیمی را replay می‌کرد (به‌جای
            // برخورد ۴۰۹). اکنون اثر انگشتِ محتوای کسب‌وکاری پیلاد (بدون فیلدهای
            // فرّار سرور) همراه کلید ثبت می‌شود — مغایرت = برخورد قطعی در لایهٔ
            // Idempotency (CORE-049 data_hash) و پیام صادقانهٔ ۴۰۹ به کلاینت.
            $payloadFingerprint = self::buildAdPayloadFingerprint($data);

            $result = $this->adManager->create((string)$type, $userId, $data, $idempotencyKey, $payloadFingerprint);

            echo json_encode([
                'success' => true,
                'message' => 'تبلیغ با موفقیت و امنیت کامل ثبت شد.',
                'ad_id' => $result['ad_id'] ?? null,
                'idempotency_key' => $idempotencyKey,
            ]);
        } catch (\Exception $e) {
            $this->logger->error('ads.store.failed', ['error' => $e->getMessage(), 'user_id' => $userId]);
            // 🛡️ FIX-S20-CLOSE-F3: برخورد idempotency (۴۰۹) پیام صادقانهٔ خودش را دارد —
            // نه پیام عمومی «بروز خطا» که retry بعدی را گمراه می‌کند.
            if ($e->getCode() === 409) {
                echo json_encode([
                    'success' => false,
                    'message' => 'همین کلید تکرارنشدن قبلاً با محتوای دیگری ثبت شده است؛ برای ثبت کمپین جدید کلید تازه بفرستید.',
                ], JSON_UNESCAPED_UNICODE);
                return;
            }
            $isDomainError = $e instanceof \Core\Exceptions\BusinessException || $e instanceof \InvalidArgumentException || $e instanceof \Core\Exceptions\ValidationException;
            $userMsg = $isDomainError ? $e->getMessage() : 'بروز خطا در ثبت آگهی. لطفاً ورودی‌ها را بررسی کرده و مجدداً تلاش کنید.';
            echo json_encode([
                'success' => false, 
                'message' => $userMsg
            ], JSON_UNESCAPED_UNICODE);
        }
    }

    /**
     * Pause/Resume interaction directly from the list view.
     */
    public function toggleStatus(): void
    {
        header('Content-Type: application/json');
        $adId = $this->request->int('ad_id');
        $userId = (int)user_id();

        $result = $this->adManager->toggleAdStatus($adId, $userId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
    }

    public function cancel(): void
    {
        header('Content-Type: application/json');
        $adId = int_value($this->request->param('id'));
        $userId = (int)user_id();
        $reason = trim($this->request->str('reason', 'لغو توسط تبلیغ‌دهنده'));
        $result = $this->adManager->cancelAd($adId, $userId, $reason !== '' ? $reason : 'لغو توسط تبلیغ‌دهنده');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Ultimate Unified Analytics & Execution Log.
     */
    public function show(): void
    {
        $adId = (int)$this->request->param('id');
        $userId = (int)user_id();

        $ad = $this->adModel->where('id', '=', $adId)
            ->where('user_id', '=', $userId)
            ->whereNull('deleted_at')
            ->first();
        
        if (!$ad) {
            $this->session->setFlash('error', 'آگهی یافت نشد.');
            redirect(url('/ads'));
        }

        $executions = $this->adManager->getAdExecutions($adId, $ad->type);
        $stats = []; // Detailed stats logic should be in a service if needed
        $finance = $this->adsBudgetSettlement->financeSnapshot($adId, (string)$ad->type);

        // آمار engagement نوتیفیکیشن برای تبلیغ‌های type=notification
        $adStats = [];
        if (($ad->type ?? '') === 'notification') {
            $notifModel = $this->notifModel;
            $adStats = $notifModel->getAdAnalytics($adId, 30) ?: [];
        }

        view('user.ads.show', compact('ad', 'executions', 'stats', 'finance', 'adStats'));
    }


    /**
     * آمار engagement نوتیفیکیشنِ یک تبلیغِ تبلیغ‌دهنده (JSON برای فرانت/موبایل)
     * GET /ads/{id}/notification-stats
     */
    public function notificationStats(): void
    {
        // 🧭 FIX-X204 (راند ۵۴ — کلاسِ باگ X202): مرورگر → صفحهٔ خودِ آگهی؛ کلاینت AJAX/موبایل → قرارداد JSON دست‌نخورده
        $adId = (int)($this->request->param('id') ?? 0);
        if (!is_ajax()) {
            redirect(url('/ads/' . $adId)); // 🛡️ FIX-PS-C3
        }

        $userId = (int)user_id();

        $ad = $this->adModel->where('id', '=', $adId)
            ->where('user_id', '=', $userId)
            ->whereNull('deleted_at')
            ->first();

        if (!$ad) {
            $this->response->json(['success' => false, 'message' => 'آگهی یافت نشد.'], 404);
            return; // 🛡️ FIX-PS-C3
        }
        if (($ad->type ?? '') !== 'notification') {
            $this->response->json(['success' => false, 'message' => 'این آگهی از نوع نوتیفیکیشن نیست.'], 422);
            return; // 🛡️ FIX-PS-C3
        }

        $days      = max(1, min(365, $this->request->int('days', 30)));
        $notifModel = $this->notifModel;

        $this->response->json([
            'success' => true,
            'ad_id'   => $adId,
            'days'    => $days,
            'stats'   => $notifModel->getAdAnalytics($adId, $days) ?: [],
        ]);
    }

    /**
     * 🛡️ FIX-S20-CLOSE-F3 (پایان‌کار بازبینی S20 — یافتهٔ ۲ — شکاف ب): اثر انگشتِ
     * payload کمپین برای ثبت در لایهٔ idempotency (pure static — تست‌پذیر).
     *
     * قرارداد:
     *  - فقط محتوای کسب‌وکاریِ «پیلاد نرمال‌شده» (خروجی normalizeAdPayload — قطعی)
     *    + اثر فایل آپلودی (نام|حجم) هش می‌شود.
     *  - فیلدهای فرّارِ سرور (image_path پس از آپلود مجدد، user_id، خودِ کلید)
     *    مستثنی‌اند تا retry صادقانهٔ همان فرمان، همان اثر انگشت را بدهد؛
     *  - هر تغییر واقعی محتوا (عنوان/بودجه/کوپن/فایل دیگر) = اثر انگشت متفاوت =
     *    با همان کلید قبلی → برخورد ۴۰۹ (نه replay بی‌صدای نتیجهٔ قدیمی).
     *
     * @param array<string, mixed> $data پیلاد نرمال‌شده (پس از normalizeAdPayload)
     * @return string هش sha256 (hex ۶۴ کاراکتری)
     */
    public static function buildAdPayloadFingerprint(array $data): string
    {
        $source = $data;
        // فیلدهای فرّار/غیرمرتبط با «هویت فرمان» — نباید اثر انگشت را تکان بدهند
        unset(
            $source['image_path'],       // سرور پس از هر آپلود مقدار تازه می‌سازد
            $source['user_id'],          // بخشی از actor است نه محتوا
            $source['idempotency_key'],  // خودِ کلید — در scope کلید ثبت می‌شود
            $source['csrf_token'],
            $source['_token']
        );
        // اثر فایل آپلودی: نام|حجم (فایل دیگر = فرمان دیگر)
        if (isset($_FILES['image']) && is_array($_FILES['image']) && !empty($_FILES['image']['name'])) {
            $source['__file_image_fp'] = (string)$_FILES['image']['name'] . '|' . (int)($_FILES['image']['size'] ?? 0);
        }
        ksort($source); // ترتیب کلیدها قطعی — مستقل از ترتیب فرم
        $json = json_encode($source, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return hash('sha256', is_string($json) ? $json : serialize($source));
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeAdPayload(string $type, array $data): array
    {
        // ─── قرارداد کانونی واحد پول (W4-D، مصوبهٔ کلاینت) ───
        // مبالغ در داخل سایت «همیشه» تومان (IRT) هستند؛ مقیاس‌کردن (×۱۰/÷۱۰) فقط
        // و فقط در مرز آداپتورهای درگاه بانکی انجام می‌شود. کلاینتی که
        // currency=irr می‌فرستد فقط «برچسبِ» خودش را اعلام کرده، نه واحدِ مبلغ را —
        // پس برچسب به irt نرمال می‌شود و مبلغِ عددی دست‌نخورده (تومان) باقی می‌ماند.
        if (isset($data['currency'])) {
            $data['currency'] = strtolower(str_value($data['currency']));
            if (in_array($data['currency'], ['irr', 'rial'], true)) {
                $data['currency'] = 'irt';
                // FIX-R36-W3 (F-A19d-10 تکمیل ارکستراتور): همان هشدار ساختاریافتهٔ ۵ آداپتر —
                // ریلِیبل بی‌صدای irr→irt در سطح کنترلر هم قابل-مشاهده می‌شود.
                try {
                    logger()->warning('ads.currency.irr_relabelled_irt', [
                        'type' => $type,
                        'source_currency' => 'irr/rial',
                    ]);
                } catch (\Throwable $e) {
                    // هشدار هرگز جریان ایجاد آگهی را نمی‌شکند (best-effort، الگوی خانه)
                }
            }
            // FIX-CY3-A6 (یافتهٔ ۶ بچ CY3): الفبای بستهٔ ارز — مقدار نامعتبر به‌جای
            // نشت به لایهٔ پایین، به ارز فعال پلتفرم برمی‌گردد (fail-open تومان).
            if ($data['currency'] !== 'irt' && $data['currency'] !== 'usdt') {
                $activeCur = function_exists('currency_active') ? currency_active() : 'irt';
                if ($activeCur !== 'usdt') $activeCur = 'irt';
                try {
                    logger()->warning('ads.currency.invalid_fallback_active', [
                        'type' => $type,
                        'source_currency' => $data['currency'],
                        'fallback' => $activeCur,
                    ]);
                } catch (\Throwable $e) {
                    // best-effort
                }
                $data['currency'] = $activeCur;
            }
        } else {
            // FIX-CY3-A6: دیفالتِ غایب‌بودن فیلد = ارز فعال پلتفرم (قبلاً 'irt'
            // هاردکد بود) — سناریوی «کل پروژه تتر» بدون تغییر کد جواب می‌دهد.
            $activeCur = function_exists('currency_active') ? currency_active() : 'irt';
            if ($activeCur !== 'usdt') $activeCur = 'irt';
            $data['currency'] = $activeCur;
        }

        if (!empty($data['target_link']) && empty($data['link'])) {
            $data['link'] = $data['target_link'];
        }
        if (!empty($data['link']) && empty($data['target_url'])) {
            $data['target_url'] = $data['link'];
        }

        if ($type === 'custom_task') {
            $count = int_value($data['total_count'] ?? $data['total_quantity'] ?? $data['quantity'] ?? 1);
            $price = str_value($data['price_per_task'] ?? 0);
            $data['total_count'] = max(1, $count);
            $data['total_quantity'] = $data['total_count'];
            if (empty($data['total_budget']) && is_numeric($price) && bccomp($price, '0', 8) > 0) {
                $data['total_budget'] = bcmul($price, (string)$data['total_count'], 8);
            }
            $data['proof_type'] = str_value($data['proof_type'] ?? 'text');
            $data['proof_description'] = str_value($data['proof_description'] ?? 'مدرک انجام تسک را طبق توضیح تسک ارسال کنید.');
            $data['deadline_hours'] = int_value($data['deadline_hours'] ?? 24);
        }

        if ($type === 'seo') {
            if (!empty($data['target_link']) && empty($data['site_url'])) {
                $data['site_url'] = $data['target_link'];
            }
            if (!empty($data['site_url']) && empty($data['target_url'])) {
                $data['target_url'] = $data['site_url'];
            }
            $data['budget'] = str_value($data['budget'] ?? $data['total_budget'] ?? 0);
            $data['total_budget'] = $data['budget'];
            $data['min_payout'] = str_value($data['min_payout'] ?? $data['price_per_click'] ?? 0);
            $seoPricePerClick = str_value($data['price_per_click'] ?? 0);
            $seoMaxDefault = (is_numeric($data['min_payout']) && is_numeric($seoPricePerClick) && bccomp($data['min_payout'], $seoPricePerClick, 8) >= 0) ? $data['min_payout'] : $seoPricePerClick;
            $data['max_payout'] = str_value($data['max_payout'] ?? $seoMaxDefault);
            $data['target_duration'] = int_value($data['target_duration'] ?? 60);
            $data['min_score'] = int_value($data['min_score'] ?? 40);
            $data['max_per_day'] = int_value($data['max_per_day'] ?? 10);

            // 🛡️ FIX-SEO-23-01 (فاز ۲ — وضعیت سه‌حالته): کانال اثبات فرود این آگهی.
            // فقط مقادیر مجاز؛ ناشناخته = off (fail-closed). حالت فعال بدون راز،
            // خودش راز تازه می‌سازد (پست‌بک امضاشده از همان لحظه کار می‌کند؛
            // نمایش/چرخش بعدی راز از صفحهٔ جزئیات آگهی).
            $proofMode = SeoLandingProofService::normalizeMode($data['seo_landing_proof_mode'] ?? 'off');
            $data['seo_landing_proof_mode'] = $proofMode;
            if ($proofMode !== 'off' && empty($data['seo_postback_secret'])) {
                $data['seo_postback_secret'] = bin2hex(random_bytes(32));
            }
            if ($proofMode === 'off') {
                // آگهی off راز نمی‌خواهد — ستون خالی می‌ماند تا اشتباهی مصرف نشود
                $data['seo_postback_secret'] = null;
            }
        }

        if (in_array($type, ['social_task', 'adtube'], true)) {
            $count = int_value($data['total_count'] ?? $data['quantity'] ?? 1);
            $price = str_value($data['price_per_task'] ?? 0);
            $data['total_count'] = max(1, $count);
            $data['total_budget'] = is_numeric($price) ? bcmul($price, (string)$data['total_count'], 8) : '0';
        }

        if (in_array($type, ['banner', 'notification'], true)) {
            $data['budget'] = str_value($data['budget'] ?? $data['total_budget'] ?? 0);
            $data['total_budget'] = $data['budget'];
        }

        return $data;
    }

    /**
     * تأیید submission یک تسک سفارشی (Unified — از CustomTaskAdController منتقل شد)
     */
    public function approveSubmission(): string
    {
        $userId = (int)user_id();
        $submissionId = int_value($this->request->param('id') ?? $this->request->post('submission_id') ?? 0);
        $note = trim($this->request->str('note'));

        if ($submissionId <= 0) {
            $this->session->setFlash('error', 'شناسه submission نامعتبر است.');
            return back();
        }

        $result = $this->moderationService->reviewSubmission($submissionId, $userId, 'approve', $note);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return back();
    }

    /**
     * رد submission یک تسک سفارشی (Unified — از CustomTaskAdController منتقل شد)
     */
    public function rejectSubmission(): string
    {
        $userId = (int)user_id();
        $submissionId = int_value($this->request->param('id') ?? $this->request->post('submission_id') ?? 0);
        $reason = trim($this->request->str('reason'));

        if ($submissionId <= 0) {
            $this->session->setFlash('error', 'شناسه submission نامعتبر است.');
            return back();
        }

        if (empty($reason)) {
            $this->session->setFlash('error', 'دلیل رد الزامی است.');
            return back();
        }

        $result = $this->moderationService->reviewSubmission($submissionId, $userId, 'reject', $reason);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return back();
    }
}

