<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Services\AdSystemManager;
use App\Models\Ads;
use App\Models\BannerPlacement;
use App\Services\CustomTask\CustomTaskModerationService;

/**
 * AdsController - The ultimate command center for Unified Modern Advertising (Unified UI).
 */
class AdsController extends BaseController
{
    private AdSystemManager $adManager;
    private Ads $adModel;
    private BannerPlacement $placementModel;
    private \App\Services\Ads\AdRegistrationService $registrationService;
    private CustomTaskModerationService $moderationService;

    public function __construct(
        AdSystemManager $adManager,
        Ads $adModel,
        BannerPlacement $placementModel,
        \App\Services\Ads\AdRegistrationService $registrationService,
        CustomTaskModerationService $moderationService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        $this->adManager = $adManager;
        $this->adModel = $adModel;
        $this->placementModel = $placementModel;
        $this->registrationService = $registrationService;
        $this->moderationService = $moderationService;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * Unified Dashboard / "My Ads" Listing.
     */
    public function index(): string
    {
        $userId = (int)user_id();
        
        $ads = $this->adManager->getUserAds($userId);
        $summaryData = $this->adManager->getAdSummary($userId);

        return view('user.ads.index', compact('ads', 'summaryData'));
    }

    /**
     * The AJAX Ad Wizard - Single Entry Point.
     */
    public function create(): string
    {
        // دریافت Placements از Model
        $placements = $this->placementModel->where('is_active', '=', 1)->get();
        
        return view('user.ads.create', compact('placements'));
    }

    /**
     * High-speed AJAX storage directly forwarding payload to mapped Adapter strategies.
     */
    public function store(): void
    {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        $userId = (int)user_id();

        $type = $data['ad_type'] ?? null;

        if (!$type) {
            echo json_encode(['success' => false, 'message' => 'نوع تبلیغ نامعتبر است.']);
            return;
        }

        try {
            // Unified ad creation via AdSystemManager (Saga + Escrow)
            $data['user_id'] = $userId;
            $result = $this->adManager->create($type, $userId, $data);

            echo json_encode([
                'success' => true,
                'message' => 'تبلیغ با موفقیت و امنیت کامل ثبت شد.',
                'ad_id' => $result['ad_id'] ?? null
            ]);
        } catch (\Exception $e) {
            $this->logger->error('ads.store.failed', ['error' => $e->getMessage(), 'user_id' => $userId]);
            echo json_encode([
                'success' => false, 
                'message' => 'بروز خطا در حین ثبت: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Pause/Resume interaction directly from the list view.
     */
    public function toggleStatus(): void
    {
        header('Content-Type: application/json');
        $adId = (int) ($this->request->post('ad_id') ?? 0);
        $userId = (int)user_id();

        $result = $this->adManager->toggleAdStatus($adId, $userId);
        echo json_encode($result);
    }

    /**
     * Ultimate Unified Analytics & Execution Log.
     */
    public function show(): string
    {
        $adId = (int)$this->request->param('id');
        $userId = (int)user_id();

        $ad = $this->adModel->where('id', '=', $adId)
            ->where('user_id', '=', $userId)
            ->whereNull('deleted_at')
            ->first();
        
        if (!$ad) {
            $this->session->setFlash('error', 'آگهی یافت نشد.');
            return redirect(url('/ads'));
        }

        $executions = $this->adManager->getAdExecutions($adId, $ad->type);
        $stats = []; // Detailed stats logic should be in a service if needed

        return view('user.ads.show', compact('ad', 'executions', 'stats'));
    }

    /**
     * تأیید submission یک تسک سفارشی (Unified — از CustomTaskAdController منتقل شد)
     */
    public function approveSubmission(): string
    {
        $userId = (int)user_id();
        $submissionId = (int) ($this->request->post('submission_id') ?? 0);
        $note = trim((string) ($this->request->post('note') ?? ''));

        $result = $this->moderationService->reviewSubmission($submissionId, $userId, 'approve', $note);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return redirect_back();
    }

    /**
     * رد submission یک تسک سفارشی (Unified — از CustomTaskAdController منتقل شد)
     */
    public function rejectSubmission(): string
    {
        $userId = (int)user_id();
        $submissionId = (int) ($this->request->post('submission_id') ?? 0);
        $reason = trim((string) ($this->request->post('reason') ?? ''));

        if (empty($reason)) {
            $this->session->setFlash('error', 'دلیل رد الزامی است.');
            return redirect_back();
        }

        $result = $this->moderationService->reviewSubmission($submissionId, $userId, 'reject', $reason);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return redirect_back();
    }
}
