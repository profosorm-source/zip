<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Services\AdSystemManager;
use App\Models\Ads;
use App\Models\BannerPlacement;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\UploadService;
use App\Services\Ads\AdsBudgetSettlementService;

/**
 * AdsController - The ultimate command center for Unified Modern Advertising (Unified UI).
 */
class AdsController extends BaseController
{
    private AdSystemManager $adManager;
    private Ads $adModel;
    private BannerPlacement $placementModel;
    private CustomTaskModerationService $moderationService;
    private UploadService $uploadService;
    private AdsBudgetSettlementService $adsBudgetSettlement;

    public function __construct(
        AdSystemManager $adManager,
        Ads $adModel,
        BannerPlacement $placementModel,
        CustomTaskModerationService $moderationService,
        UploadService $uploadService,
        AdsBudgetSettlementService $adsBudgetSettlement,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        $this->adManager = $adManager;
        $this->adModel = $adModel;
        $this->placementModel = $placementModel;
        $this->moderationService = $moderationService;
        $this->uploadService = $uploadService;
        $this->adsBudgetSettlement = $adsBudgetSettlement;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * Unified Dashboard / "My Ads" Listing.
     */
    public function index(): void
    {
        $userId = (int)user_id();
        
        $ads = $this->adManager->getUserAds($userId);
        $summaryData = $this->adManager->getAdSummary($userId);

        view('user.ads.index', compact('ads', 'summaryData'));
    }

    /**
     * The AJAX Ad Wizard - Single Entry Point.
     */
    public function create()
    {
        // دریافت Placements از Model
        $placements = $this->placementModel->where('is_active', '=', 1)->get();
        
        view('user.ads.create', compact('placements'));
    }

    /**
     * High-speed AJAX storage directly forwarding payload to mapped Adapter strategies.
     */
    public function store()
    {
        header('Content-Type: application/json');
        $data = is_array($this->request->input()) ? $this->request->input() : [];
        $userId = (int)user_id();

        $type = $data['ad_type'] ?? null;

        if (!$type) {
            echo json_encode(['success' => false, 'message' => 'نوع تبلیغ نامعتبر است.']);
            return;
        }

        $data = $this->normalizeAdPayload((string)$type, $data);
        if ((string)$type === 'banner' && !empty($_FILES['image']['name'])) {
            try {
                $upload = $this->uploadService->upload($_FILES['image'], 'banners', ['jpg', 'jpeg', 'png', 'webp'], 5 * 1024 * 1024);
                $data['image_path'] = $upload['path'];
            } catch (\Throwable $e) {
                echo json_encode(['success' => false, 'message' => 'آپلود تصویر بنر انجام نشد: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
                return;
            }
        }

        try {
            // Unified ad creation via AdSystemManager (Saga + Escrow)
            $data['user_id'] = $userId;
            $result = $this->adManager->create((string)$type, $userId, $data);

            echo json_encode([
                'success' => true,
                'message' => 'تبلیغ با موفقیت و امنیت کامل ثبت شد.',
                'ad_id' => $result['ad_id'] ?? null
            ]);
        } catch (\Exception $e) {
            $this->logger->error('ads.store.failed', ['error' => $e->getMessage(), 'user_id' => $userId]);
            echo json_encode([
                'success' => false, 
                'message' => 'بروز خطا در حین ثبت: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Pause/Resume interaction directly from the list view.
     */
    public function toggleStatus(): void
    {
        header('Content-Type: application/json');
        $adId = (int) ($this->request->post('ad_id') ?? 0);
        $userId = (int)user_id();

        $result = $this->adManager->toggleAdStatus($adId, $userId);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
    }

    public function cancel(): void
    {
        header('Content-Type: application/json');
        $adId = (int)$this->request->param('id');
        $userId = (int)user_id();
        $reason = trim((string)($this->request->post('reason') ?? 'لغو توسط تبلیغ‌دهنده'));
        $result = $this->adManager->cancelAd($adId, $userId, $reason !== '' ? $reason : 'لغو توسط تبلیغ‌دهنده');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Ultimate Unified Analytics & Execution Log.
     */
    public function show(): void
    {
        $adId = (int)$this->request->param('id');
        $userId = (int)user_id();

        $ad = $this->adModel->where('id', '=', $adId)
            ->where('user_id', '=', $userId)
            ->whereNull('deleted_at')
            ->first();
        
        if (!$ad) {
            $this->session->setFlash('error', 'آگهی یافت نشد.');
            redirect(url('/ads'));
            return;
        }

        $executions = $this->adManager->getAdExecutions($adId, $ad->type);
        $stats = []; // Detailed stats logic should be in a service if needed
        $finance = $this->adsBudgetSettlement->financeSnapshot($adId, (string)$ad->type);

        view('user.ads.show', compact('ad', 'executions', 'stats', 'finance'));
    }


    private function normalizeAdPayload(string $type, array $data): array
    {
        if (isset($data['currency'])) {
            $data['currency'] = strtolower((string)$data['currency']);
            if (in_array($data['currency'], ['irr', 'rial'], true)) {
                $data['currency'] = 'irt';
            }
        } else {
            $data['currency'] = 'irt';
        }

        if (!empty($data['target_link']) && empty($data['link'])) {
            $data['link'] = $data['target_link'];
        }
        if (!empty($data['link']) && empty($data['target_url'])) {
            $data['target_url'] = $data['link'];
        }

        if ($type === 'custom_task') {
            $count = (int)($data['total_count'] ?? $data['total_quantity'] ?? $data['quantity'] ?? 1);
            $price = (float)($data['price_per_task'] ?? 0);
            $data['total_count'] = max(1, $count);
            $data['total_quantity'] = $data['total_count'];
            if (empty($data['total_budget']) && $price > 0) {
                $data['total_budget'] = $price * $data['total_count'];
            }
            $data['proof_type'] = $data['proof_type'] ?? 'text';
            $data['proof_description'] = $data['proof_description'] ?? 'مدرک انجام تسک را طبق توضیح تسک ارسال کنید.';
            $data['deadline_hours'] = (int)($data['deadline_hours'] ?? 24);
        }

        if ($type === 'seo') {
            if (!empty($data['target_link']) && empty($data['site_url'])) {
                $data['site_url'] = $data['target_link'];
            }
            if (!empty($data['site_url']) && empty($data['target_url'])) {
                $data['target_url'] = $data['site_url'];
            }
            $data['budget'] = (float)($data['budget'] ?? $data['total_budget'] ?? 0);
            $data['total_budget'] = $data['budget'];
            $data['min_payout'] = (float)($data['min_payout'] ?? $data['price_per_click'] ?? 0);
            $data['max_payout'] = (float)($data['max_payout'] ?? max($data['min_payout'], (float)($data['price_per_click'] ?? 0)));
            $data['target_duration'] = (int)($data['target_duration'] ?? 60);
            $data['min_score'] = (int)($data['min_score'] ?? 40);
            $data['max_per_day'] = (int)($data['max_per_day'] ?? 10);
        }

        if (in_array($type, ['social_task', 'adtube'], true)) {
            $count = (int)($data['total_count'] ?? $data['quantity'] ?? 1);
            $price = (float)($data['price_per_task'] ?? 0);
            $data['total_count'] = max(1, $count);
            $data['total_budget'] = $price * $data['total_count'];
        }

        if (in_array($type, ['banner', 'notification'], true)) {
            $data['budget'] = (float)($data['budget'] ?? $data['total_budget'] ?? 0);
            $data['total_budget'] = $data['budget'];
        }

        return $data;
    }

    /**
     * تأیید submission یک تسک سفارشی (Unified — از CustomTaskAdController منتقل شد)
     */
    public function approveSubmission(): string
    {
        $userId = (int)user_id();
        $submissionId = (int) ($this->request->param('id') ?? $this->request->post('submission_id') ?? 0);
        $note = trim((string) ($this->request->post('note') ?? ''));

        if ($submissionId <= 0) {
            $this->session->setFlash('error', 'شناسه submission نامعتبر است.');
            return back();
        }

        $result = $this->moderationService->reviewSubmission($submissionId, $userId, 'approve', $note);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return back();
    }

    /**
     * رد submission یک تسک سفارشی (Unified — از CustomTaskAdController منتقل شد)
     */
    public function rejectSubmission(): string
    {
        $userId = (int)user_id();
        $submissionId = (int) ($this->request->param('id') ?? $this->request->post('submission_id') ?? 0);
        $reason = trim((string) ($this->request->post('reason') ?? ''));

        if ($submissionId <= 0) {
            $this->session->setFlash('error', 'شناسه submission نامعتبر است.');
            return back();
        }

        if (empty($reason)) {
            $this->session->setFlash('error', 'دلیل رد الزامی است.');
            return back();
        }

        $result = $this->moderationService->reviewSubmission($submissionId, $userId, 'reject', $reason);

        $this->session->setFlash($result['success'] ? 'success' : 'error', $result['message']);
        return back();
    }
}

