<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\Ads;
use App\Models\AdTubeExecutionModel;
use App\Services\AdSystemManager;

/**
 * AdtubeController — Executor-only controller for AdTube (video watch) ads.
 *
 * NOTE: Advertiser management (create, pause, stats, list) is unified under /ads (AdsController).
 * This controller only handles the worker/executor side: discovering videos, watching, and submission.
 */
class AdtubeController extends BaseUserController
{
    private Ads $adModel;
    private AdTubeExecutionModel $executionModel;
    private AdSystemManager $adManager;

    public function __construct(
        Ads $adModel,
        AdTubeExecutionModel $executionModel,
        AdSystemManager $adManager,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        $this->adModel = $adModel;
        $this->executionModel = $executionModel;
        $this->adManager = $adManager;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * داشبورد انجام‌دهنده — لیست ویدیوهای فعال AdTube
     */
    public function index(): void
    {
        $userId = (int)user_id();

        // Active ads of type 'adtube' with remaining budget and slots
        $tasks = $this->adModel->getAvailableCustomTasks(
            $userId,
            ['platform' => 'youtube'],
            20, 0, 'adtube'
        );

        $stats = [
            'total_completed_today' => $this->executionModel->countCompletedToday($userId),
            'active_watching' => $this->executionModel->countActiveForUser($userId),
            'total_earned_today' => 0, // Calculated below if needed
        ];

        $this->view('user/adtube/index', [
            'title' => 'AdTube — کسب درآمد از یوتیوب',
            'tasks' => $tasks,
            'stats' => $stats,
            'trust_score' => 50, // Placeholder; could be fetched from ScoreService if needed
        ]);
    }

    public function income(): void
    {
        $this->index();
    }

    /**
     * شروع فرآیند اجرای یک ویدیو (AJAX)
     */
    public function start(): void
    {
        header('Content-Type: application/json');
        try {
            $body = $this->request->body();
            $adId = (int)($body['ad_id'] ?? $this->request->param('id'));
            $userId = (int)user_id();

            if (!$adId) {
                echo json_encode(['success' => false, 'message' => 'شناسه ویدیو نامعتبر است.']);
                return;
            }

            // Verify ad exists and is active
            $ad = $this->adModel->find($adId);
            if (!$ad || $ad->type !== 'adtube' || !in_array($ad->status, ['active', 'approved'], true)) {
                echo json_encode(['success' => false, 'message' => 'آگهی ویدیویی فعال یافت نشد.']);
                return;
            }

            // Check if user has too many active watches
            if ($this->executionModel->countActiveForUser($userId) >= 3) {
                echo json_encode(['success' => false, 'message' => 'حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.']);
                return;
            }

            $context = [
                'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            ];

            $execution = $this->executionModel->findOrCreate($adId, $userId, $context);

            if (!$execution) {
                echo json_encode(['success' => false, 'message' => 'خطا در ایجاد رکورد اجرا.']);
                return;
            }

            // Transition to watching
            $this->executionModel->startWatching((int)$execution->id);

            echo json_encode([
                'success' => true,
                'execution_id' => $execution->id,
                'redirect_url' => url('/adtube/' . $execution->id . '/execute'),
            ]);
        } catch (\Exception $e) {
            $this->logger?->error('adtube.start.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطا در شروع تماشای ویدیو.']);
        }
    }

    /**
     * صفحه پخش ویدیو و ثبت اثبات
     */
    public function showExecute(): void
    {
        $userId = (int)user_id();
        $execId = (int)$this->request->param('id');

        $execution = $this->executionModel->findByIdWithAd($execId, $userId);

        if (!$execution) {
            $this->session->setFlash('error', 'اجرای مورد نظر یافت نشد.');
            redirect(url('/adtube'));
            return;
        }

        // Only allow if status is pending or watching
        if (!in_array($execution->status, ['pending', 'watching'], true)) {
            $this->session->setFlash('warning', 'این ویدیو قبلاً ثبت شده است.');
            redirect(url('/adtube'));
            return;
        }

        $this->view('user/adtube/execute', [
            'title' => 'تماشای ویدیو و کسب درآمد',
            'execution' => $execution,
            'task' => $execution,
        ]);
    }

    /**
     * ثبت و ارسال نهایی نتایج (AJAX)
     */
    public function submit(): void
    {
        header('Content-Type: application/json');
        try {
            $execId = (int)$this->request->param('id');
            $userId = (int)user_id();
            $body = $this->request->body();

            $execution = $this->executionModel->findById($execId);
            if (!$execution || (int)$execution->executor_id !== $userId) {
                echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز.']);
                return;
            }

            if ($execution->status !== 'watching') {
                echo json_encode(['success' => false, 'message' => 'وضعیت اجرا نامعتبر است.']);
                return;
            }

            $watchTime = (int)($body['watch_time'] ?? 0);
            $progress = (int)($body['progress_percent'] ?? 0);
            $speed = (float)($body['playback_speed'] ?? 1.0);

            // Minimum validation: at least 80% watched and reasonable speed
            if ($progress < 80) {
                $this->executionModel->markRejected($execId, 'تماشای ناقص: ' . $progress . '%');
                echo json_encode(['success' => false, 'message' => 'ویدیو باید حداقل ۸۰٪ تماشا شود (' . $progress . '٪).']);
                return;
            }

            if ($speed > 2.5) {
                $this->executionModel->markRejected($execId, 'سرعت پخش غیرعادی: ' . $speed . 'x');
                echo json_encode(['success' => false, 'message' => 'سرعت پخش غیرعادی تشخیص داده شد.']);
                return;
            }

            $finance = \Core\Container::getInstance()->make(\App\Services\Ads\AdsBudgetSettlementService::class);
            $settlement = $finance->settleAdTubeView($execId, $userId, $watchTime, $progress, $speed);

            echo json_encode([
                'success' => !empty($settlement['success']),
                'message' => $settlement['message'] ?? (!empty($settlement['success']) ? 'ویدیو با موفقیت ثبت و پاداش پرداخت شد.' : 'تسویه ویدیو انجام نشد.'),
                'execution_id' => $execId,
                'settlement' => $settlement,
            ], JSON_UNESCAPED_UNICODE);
        } catch (\Exception $e) {
            $this->logger?->error('adtube.submit.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطای سیستمی در ثبت نهایی.']);
        }
    }

    /**
     * تاریخچه فعالیت کاربر در AdTube
     */
    public function history(): void
    {
        $userId = (int)user_id();
        $page = max(1, (int)($this->request->get('page') ?? 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $history = $this->executionModel->getHistory($userId, $limit, $offset);

        $this->view('user/adtube/history', [
            'title' => 'تاریخچه کسب درآمد AdTube',
            'history' => $history,
            'page' => $page,
        ]);
    }
}
