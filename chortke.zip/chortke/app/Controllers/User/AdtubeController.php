<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\Ads;
use App\Models\AdTubeExecutionModel;
use App\Services\Ads\AdsBudgetSettlementService;
use App\Services\AdSystemManager;
use Core\Response;

/**
 * AdtubeController — Executor-only controller for AdTube (video watch) ads.
 *
 * NOTE: Advertiser management (create, pause, stats, list) is unified under /ads (AdsController).
 * This controller only handles the worker/executor side: discovering videos, watching, and submission.
 */
class AdtubeController extends BaseUserController
{
    private Ads $adModel;
    private AdTubeExecutionModel $executionModel;
    private \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlement;
    private \App\Adapters\AdVideoRewardManager $rewardManager;
    private \App\Contracts\WalletServiceInterface $walletService;
    /** X374 (راند ۹۳) — لجر KPI وب‌هوک S2S (best-effort؛ اختیاری برای سازگاری سازنده) */
    private ?\App\Models\S2sHookEvent $s2sHookEvents;
    /** X374 — برای طبقه‌بندی replay پیش از واریز (فقط خواندن کلید idempotency) */
    private ?\App\Models\Transaction $transactionModel;

    public function __construct(
        Ads $adModel,
        AdTubeExecutionModel $executionModel,
        \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlement,
        \App\Adapters\AdVideoRewardManager $rewardManager,
        // 🧹 DI-CLEANUP (2026-08-24): به‌جای container->make در بدنه‌ی متد.
        \App\Contracts\WalletServiceInterface $walletService,
        ?\App\Contracts\LoggerInterface $logger = null,
        // X374 (راند ۹۳): دامنهٔ KPI برای S2S — هر دو اختیاری و nullable هستند
        // تا فراخوانی‌های موجود سازنده (tests/پروب‌ها) بدون تغییر سالم بمانند.
        ?\App\Models\S2sHookEvent $s2sHookEvents = null,
        ?\App\Models\Transaction $transactionModel = null
    ) {
        $this->adModel = $adModel;
        $this->executionModel = $executionModel;
        $this->adsBudgetSettlement = $adsBudgetSettlement;
        $this->rewardManager = $rewardManager;
        $this->walletService = $walletService;
        $this->s2sHookEvents = $s2sHookEvents;
        $this->transactionModel = $transactionModel;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * لودر مشترک داده‌های هاب تک‌صفحه‌ای AdTube.
     * 🛡️ تکمیل معماری هاب: تاریخچه تماشا به‌عنوان پنل سوم همان هاب سرو می‌شود
     * (الگوی هاب‌های تبلیغات/رفرال)؛ روت قدیمی /adtube/history فقط alias است.
     *
     * @return array<string, mixed>
     */
    private function hubData(int $userId, int $historyPage = 1): array
    {
        // Active ads of type 'adtube' with remaining budget and slots
        $tasks = $this->adModel->getAvailableCustomTasks(
            $userId,
            ['platform' => 'youtube'],
            20, 0, 'adtube'
        );

        $stats = [
            'total_completed_today' => $this->executionModel->countCompletedToday($userId),
            'active_watching' => $this->executionModel->countActiveForUser($userId),
            'total_earned_today' => 0, // Calculated below if needed
        ];

        $rewardAds = $this->rewardManager->getAvailableRewardAds();

        // پنل «تاریخچه تماشا»
        $limit = 20;
        $history = $this->executionModel->getHistory($userId, $limit, (max(1, $historyPage) - 1) * $limit);

        return [
            'tasks' => $tasks,
            'stats' => $stats,
            'rewardAds' => $rewardAds,
            'trust_score' => 50, // Placeholder; could be fetched from ScoreService if needed
            'history' => $history,
            'historyPage' => max(1, $historyPage),
        ];
    }

    /**
     * داشبورد انجام‌دهنده — لیست ویدیوهای فعال AdTube
     */
    public function index(): void
    {
        $userId = (int)user_id();

        $this->view('user/adtube/index', array_merge($this->hubData($userId, $this->request->int('page', 1)), [
            'title' => 'AdTube — کسب درآمد از یوتیوب و تبلیغات جایزه‌دار',
        ]));
    }

    /**
     * شروع فرآیند اجرای یک ویدیو (AJAX)
     */
    public function start(): void
    {
        header('Content-Type: application/json');
        try {
            $body = $this->request->body();
            $adId = int_value($body['ad_id'] ?? $this->request->param('id'));
            $userId = (int)user_id();

            if (!$adId) {
                echo json_encode(['success' => false, 'message' => 'شناسه ویدیو نامعتبر است.']);
                return;
            }

            // Verify ad exists and is active
            $ad = $this->adModel->find($adId);
            if (!$ad || $ad->type !== 'adtube' || !in_array($ad->status, ['active', 'approved'], true)) {
                echo json_encode(['success' => false, 'message' => 'آگهی ویدیویی فعال یافت نشد.']);
                return;
            }

            // 🛡️ FIX-R3-F4 (P2): تماشای آگهیِ خودِ تبلیغ‌دهنده ممنوع — لیست عمومی
            // (فیلتر user_id != worker) تنها مرز دسترسی نیست؛ نقطهٔ شروع هم مالکیت را
            // برسی می‌کند تا اجرای ساختگی/تاریخچهٔ جعلی برای کمپینِ خود ساخته نشود.
            if ((int)($ad->user_id ?? 0) === $userId) {
                echo json_encode(['success' => false, 'message' => 'تماشای ویدیوی کمپین خودتان مجاز نیست و پاداشی تعلق نمی‌گیرد.']);
                return;
            }

            // Check if user has too many active watches (fast-path؛ داوری نهایی داخل reserveSlot و زیر قفل است)
            if ($this->executionModel->countActiveForUser($userId) >= 3) {
                echo json_encode(['success' => false, 'message' => 'حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.']);
                return;
            }

            $context = [
                'ip' => $this->request->ip(),
                'user_agent' => $this->request->userAgent(),
            ];

            // 🛡️ FIX-R3-F6 (P2): رزرو اسلات داخل تراکنشِ قفل‌دار (قفل ردیف users + شمارش
            // داخل همان قفل) — بستن TOCTOU سقف ۳ تماشای همزمان. null یعنی ظرفیت پر است.
            $execution = $this->executionModel->reserveSlot($adId, $userId, $context, 3);

            if (!$execution) {
                echo json_encode(['success' => false, 'message' => 'حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.']);
                return;
            }

            // Transition to watching
            $this->executionModel->startWatching((int)$execution->id);

            echo json_encode([
                'success' => true,
                'execution_id' => $execution->id,
                'redirect_url' => url('/adtube/' . $execution->id . '/execute'),
            ]);
        } catch (\Exception $e) {
            $this->logger->error('adtube.start.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطا در شروع تماشای ویدیو.']);
        }
    }

    /**
     * صفحه پخش ویدیو و ثبت اثبات
     */
    public function showExecute(): void
    {
        $userId = (int)user_id();
        $execId = (int)$this->request->param('id');

        $execution = $this->executionModel->findByIdWithAd($execId, $userId);

        if (!$execution) {
            $this->session->setFlash('error', 'اجرای مورد نظر یافت نشد.');
            redirect(url('/adtube'));
        }

        // Only allow if status is pending or watching
        if (!in_array($execution->status, ['pending', 'watching'], true)) {
            $this->session->setFlash('warning', 'این ویدیو قبلاً ثبت شده است.');
            redirect(url('/adtube'));
        }

        // 🛡️ FIX-R3-F2 (P1): مهر چالشِ سمت‌سرور برای این صفحهٔ تماشا — فرم بدون
        // این توکنِ تک‌مصرفِ اتصال‌یافته به همین execution قابل تسویه نیست (submit
        // آن را با hash_equals می‌سنجد). تایمرِ جاوااسکریپت فقط UX است؛ حقیقت،
        // started_at و ساعتِ سرور است.
        $watchChallenge = bin2hex(random_bytes(16));
        try {
            \Core\Cache::getInstance()->put($this->watchChallengeKey((int)$execution->id, $userId), $watchChallenge, self::WATCH_CHALLENGE_TTL_MINUTES);
        } catch (\Throwable $e) {
            // شکست کش → مهر ثبت نمی‌شود و submit همان مسیر fail-closed قبلی را می‌رود
            $this->logger->error('adtube.watch_challenge.mint_failed', ['execution_id' => (int)$execution->id, 'error' => $e->getMessage()]);
            $watchChallenge = '';
        }

        $this->view('user/adtube/execute', [
            'title' => 'تماشای ویدیو و کسب درآمد',
            'execution' => $execution,
            'task' => $execution,
            'watchChallenge' => $watchChallenge,
        ]);
    }

    /**
     * ثبت و ارسال نهایی نتایج (AJAX)
     */
    public function submit(): void
    {
        header('Content-Type: application/json');
        try {
            $execId = (int)$this->request->param('id');
            $userId = (int)user_id();
            $body = $this->request->body();

            $execution = $this->executionModel->findById($execId);
            if (!$execution || (int)$execution->executor_id !== $userId) {
                echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز.']);
                return;
            }

            if ($execution->status !== 'watching') {
                echo json_encode(['success' => false, 'message' => 'وضعیت اجرا نامعتبر است.']);
                return;
            }

            // 🛡️ FIX-R3-F2 (بخش الف): چالش تک‌مصرفِ صفحهٔ تماشا — تسویه فقط با
            // مَهری که سرور هنگام رندر صفحهٔ execute مینت کرده و به همین execution
            // بسته است (پیوند اجرا ↔ سیگنال قابل‌راستی‌آزمایی). شکستِ چالش = خطای
            // عادی (بدون markRejected) تا رفرشِ صفحه برای کاربر مشروع مسیر نجات بماند.
            $challenge = trim(str_value($body['watch_challenge'] ?? ''));
            if (!$this->verifyWatchChallenge($execId, $userId, $challenge)) {
                echo json_encode(['success' => false, 'message' => 'نشست تماشای این ویدیو معتبر نیست یا منقضی شده است؛ صفحه را دوباره باز کنید.']);
                return;
            }

            // Normalization: handle both watched_seconds and watch_time
            $watchTime = int_value($body['watch_time'] ?? $body['watched_seconds'] ?? 0);
            $speed = float_value($body['playback_speed'] ?? 1.0);
            if ($speed <= 0) { $speed = 1.0; }

            $requiredDuration = int_value($execution->watch_duration_seconds ?? $execution->required_duration ?? 30);
            if ($requiredDuration <= 0) { $requiredDuration = 30; }

            $progress = int_value($body['progress_percent'] ?? 0);
            if ($progress <= 0 && $watchTime > 0) {
                $progress = (int)min(100, round(($watchTime / $requiredDuration) * 100));
            }

            $policy = $this->adsBudgetSettlement->adtubeWatchPolicy();

            // 🛡️ FIX-R3-F2 (بخش ب): سیاست سرعت — سقف فقط از پلیسیِ سرور خوانده می‌شود
            if ($speed > $policy['max_speed']) {
                $this->executionModel->markRejected($execId, 'سرعت پخش غیرعادی: ' . $speed . 'x');
                echo json_encode(['success' => false, 'message' => 'سرعت پخش غیرعادی تشخیص داده شد.']);
                return;
            }

            // 🛡️ FIX-R3-F2 (بخش ج): گارد ضدتقلب زمانی بر ساعتِ سرور — ادعای تماشای
            // بیشتر از سقف فیزیکی (elapsed × سرعتِ سقف‌دار + تلورانس) رد می‌شود.
            // توجه: محاسبهٔ نهایی progress/مدت در settleAdTubeView و زیر قفل ردیفی
            // انجام می‌شود؛ این فقط گاردِ زودهنگامِ همان قانون است.
            $startedAt = 0;
            if (!empty($execution->started_at)) {
                $startedAt = strtotime((string)$execution->started_at);
            } elseif (!empty($execution->created_at)) {
                $startedAt = strtotime((string)$execution->created_at);
            }

            if ($startedAt > 0) {
                $metrics = \App\Services\Ads\AdsBudgetSettlementService::computeAdTubeMetrics(
                    (int)$startedAt,
                    time(),
                    $watchTime,
                    $speed,
                    $policy['required_duration'],
                    $policy['max_speed']
                );
                if ($metrics['fraud']) {
                    $this->executionModel->markRejected($execId, 'تقلب زمان مشاهده: ادعای کلاینت ' . $watchTime . 's، سقف فیزیکی سرور ' . $metrics['max_content_seconds'] . 's');
                    echo json_encode(['success' => false, 'message' => 'زمان تماشای واقعی با زمان سپری‌شده بر روی سرور مطابقت ندارد.']);
                    return;
                }
            }

            // توجه: حداقلِ «۸۰٪ تماشا» دیگر روی progress ادعاییِ کلاینت سنجیده نمی‌شود؛
            // پیشرفتِ واقعی فقط از started_at تا اکنون در settleAdTubeView محاسبه و
            // در صورت کفایت، پاداش پرداخت می‌شود (FIX-R3-F2).

            $finance = $this->adsBudgetSettlement;
            $settlement = $finance->settleAdTubeView($execId, $userId, $watchTime, $progress, $speed);

            if (!empty($settlement['success'])) {
                // مصرف چالش (تک‌مصرف) فقط پس از تسویهٔ موفق — خطای گذرا اجازهٔ retry می‌دهد
                try {
                    \Core\Cache::getInstance()->forget($this->watchChallengeKey($execId, $userId));
                } catch (\Throwable $e) {
                    $this->logger->warning('adtube.watch_challenge.consume_failed', ['execution_id' => $execId, 'error' => $e->getMessage()]);
                }
            }

            echo json_encode([
                'success' => !empty($settlement['success']),
                'message' => $settlement['message'] ?? (!empty($settlement['success']) ? 'ویدیو با موفقیت ثبت و پاداش پرداخت شد.' : 'تسویه ویدیو انجام نشد.'),
                'execution_id' => $execId,
                'settlement' => $settlement,
            ], JSON_UNESCAPED_UNICODE);
        } catch (\Exception $e) {
            $this->logger->error('adtube.submit.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطای سیستمی در ثبت نهایی.']);
        }
    }

    /**
     * تاریخچه فعالیت کاربر در AdTube
     */
    public function history(): void
    {
        // 🛡️ هاب تک‌صفحه‌ای: alias همان هاب — پنل تاریخچه باز می‌شود
        $userId = (int)user_id();
        $page = max(1, $this->request->int('page', 1));

        $this->view('user/adtube/history', array_merge($this->hubData($userId, $page), [
            'title' => 'تاریخچه کسب درآمد AdTube',
        ]));
    }

    /**
     * 🛡️ وب‌هوک امن سرور به سرور (S2S Callback Verification)
     * دریافت تاییدیه تماشای ویدیو از سرورهای تپسل و ادموب و واریز پاداش
     */
    public function s2sWebhook(): void
    {
        // FIX-X342 (راند ۸۴): همهٔ پاسخ‌ها باید از مسیر Response::json() بروند —
        // الگوی قبلی «http_response_code(X) + echo» توسط toResponse()ی میدل‌ور
        // بیرونی در Response تازه با ۲۰۰ پیچیده می‌شد و وضعیت واقعی (۴۰۰/۴۰۱/۴۰۴/۵۰۰)
        // هرگز به شبکهٔ تبلیغاتی نمی‌رسید → منطق retry شبکه‌ها کاملاً کور می‌شد.
        // Response::json → send() → HttpResponseException → روتر با وضعیت صحیح می‌فرستد.
        $network = (string)$this->request->param('network');
        $payload = $this->request->body();
        // FIX-X352 راند ۸۷ — امضای HMAC باید روی بایت‌های خام دریافتی محاسبه شود
        // نه بازسازی json_encode آرایهٔ پارس‌شده (اسنپ‌شات کش‌شدهٔ constructor).
        $rawBody = $this->request->rawBody();
        // Finding #7 Fix: Enforce Webhook signature strictly from HTTP headers (never Query String)
        $receivedSignature = str_value($this->request->header('X-Webhook-Signature', $this->request->header('X-AdTube-Signature', '')));
        $timestamp = int_value($this->request->header('X-Webhook-Timestamp', $this->request->header('X-AdTube-Timestamp', 0)));

        // FIX-X332 راند ۸۴: بررسی تازگی حالا fail-closed است — شرط قبلی ($timestamp > 0 && …)
        // غیبت/خرابی هدر Timestamp را از چک replay معاف می‌کرد؛ اکنون هدر مفقود/ناخوانا هم رد می‌شود.
        if ($timestamp <= 0) {
            // X374 (راند ۹۳): لجر KPI — هر خروجی نهایی یک ردیف best-effort دارد
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_TIMESTAMP, 400, $payload);
            (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'هدر زمان‌بندی وب‌هوک مفقود یا نامعتبر است (Timestamp Required)']);
            return;
        }
        // Finding #6 Fix: Freshness verification (max 300s window)
        if (abs(time() - $timestamp) > 300) {
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_TIMESTAMP, 400, $payload);
            (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'درخواست وب‌هوک منقضی شده است (Timestamp Expired)']);
            return;
        }

        try {
            $adapter = $this->rewardManager->getAdapter($network);
            if (!$adapter->verifyS2SHmac($rawBody, $receivedSignature)) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_SIGNATURE, 401, $payload);
                (new Response())->setStatusCode(401)->json(['success' => false, 'message' => 'امضای وب‌هوک نامعتبر است (HMAC Mismatch)']);
                return;
            }

            $userId = int_value($payload['user_id'] ?? $payload['sub_id'] ?? 0);
            if ($userId <= 0) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_INVALID_USER, 400, $payload);
                (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'شناسه کاربری نامعتبر است']);
                return;
            }

            $payoutMoney = $adapter->calculateUserPayout();
            $walletService = $this->walletService;

            // FIX-X333 راند ۸۴: کلید idempotency باید بر پایهٔ شناسهٔ تراکنشِ خودِ شبکه باشد نه هشِ کل payload؛
            // هشِ کل payload با هر فیلد متغیر (شمارندهٔ تلاش، sent_at، nonce) در retry عوض می‌شد → کلید جدید
            // → اعتبارِ دوباره (double credit). اولویت: transaction_id ← txid ← event_id (غیرخالی، ≤ ۲۵۶ کاراکتر).
            // بدون هیچ‌کدام: fallback به همان هشِ payload (رفتار قبلی) — طول کلید حداکثر ~۷۹ و داخل varchar(128).
            $txid = '';
            foreach (['transaction_id', 'txid', 'event_id'] as $txField) {
                $candidate = trim(str_value($payload[$txField] ?? ''));
                if ($candidate !== '' && strlen($candidate) <= 256) {
                    $txid = $candidate;
                    break;
                }
            }
            $idempotencyKey = $txid !== ''
                ? 's2s_' . $network . '_' . hash('sha256', $network . '|' . $txid)
                : "s2s_{$network}_" . hash('sha256', (string)json_encode($payload));

            // X374 (راند ۹۳): طبقه‌بندی replay پیش از واریز — فقط برای مشاهده‌پذیری KPI.
            // اگر تراکنشی با همین کلید idempotency از قبل باشد، این فراخوانی واریزِ تازه نیست
            // و ردیف لجر باید «replay» ثبت شود تا نرخ پذیرش آلوده نشود. شکستِ این پروب
            // هرگز جریان وب‌هوک را عوض نمی‌کند (رفتار پیش‌فرض: credited).
            $isReplay = false;
            try {
                $isReplay = $this->transactionModel !== null
                    && $this->transactionModel->findByIdempotencyKey($idempotencyKey, $userId) !== null;
            } catch (\Throwable $probeEx) {
                $this->logger->warning('s2s_hook_event.replay_probe_failed', ['network' => $network, 'error' => $probeEx->getMessage()]);
            }

            // واریز اتمیک تحت قفل FOR UPDATE
            $walletService->depositInTransaction($userId, $payoutMoney->getAmount(), strtolower($payoutMoney->getCurrency()), [
                'type' => 'rewarded_video_ad',
                'network' => $network,
                'description' => "پاداش تماشای ویدیوی تبلیغاتی {$network}",
                'idempotency_key' => $idempotencyKey
            ]);

            // X374: ردیف لجر KPI — txid_hash همان بخشِ هشِ کلید idempotency است (بدون txid خام)
            $this->recordS2sHookEvent(
                $network,
                $isReplay ? \App\Models\S2sHookEvent::OUTCOME_REPLAY : \App\Models\S2sHookEvent::OUTCOME_CREDITED,
                null,
                200,
                $payload,
                [
                    'user_id' => $userId,
                    'txid_hash' => substr($idempotencyKey, strlen('s2s_' . $network . '_')),
                    // پاداش فقط روی ردیف‌های credited ثبت می‌شود تا جمعِ KPI دوبار‌شماری نکند
                    'payout_amount' => $isReplay ? null : (string)$payoutMoney->getAmount(),
                    'currency' => strtolower($payoutMoney->getCurrency()),
                ]
            );

            $this->logger->info('s2s_webhook.reward_processed', ['user_id' => $userId, 'network' => $network, 'payout' => $payoutMoney->getAmount()]);
            (new Response())->json(['success' => true, 'message' => 'پاداش با موفقیت تایید و واریز شد']);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            // FIX-X342 راند ۸۴: HttpResponseException جریانِ کنترل فریم‌ورک است (Response::json
            // با send() آن را پرتاب می‌کند) — نباید توسط catchهای پایین بلعیده و ۵۰۰ شود.
            throw $e;
        } catch (\InvalidArgumentException $e) {
            // FIX-X336 راند ۸۴: شبکهٔ ناشناخته (تایپو/اسم غلط مثل adtube) ۴۰۴ است نه ۵۰۰ —
            // قبلاً InvalidArgumentExceptionِ AdVideoRewardManager::getAdapter در catch(\Throwable)
            // می‌افتاد و «خطای سرور» + لاگ error-لول تولید می‌کرد؛ اکنون پاسخ ۴۰۴ با لاگ warning.
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_UNKNOWN_NETWORK, 404, $payload);
            $this->logger->warning('s2s_webhook.unknown_network', ['network' => $network, 'error' => $e->getMessage()]);
            (new Response())->setStatusCode(404)->json(['success' => false, 'message' => 'شبکهٔ تبلیغاتی شناخته نشده است']);
        } catch (\Throwable $e) {
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_SERVER_ERROR, 500, $payload);
            $this->logger->error('s2s_webhook.failed', ['network' => $network, 'error' => $e->getMessage()]);
            (new Response())->setStatusCode(500)->json(['success' => false, 'message' => 'خطای سرور در پردازش وب‌هوک']);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // X374 (راند ۹۳) — لجر KPI وب‌هوک S2S
    // هر خروجی نهایی (۲۰۰/۴۰۰/۴۰۱/۴۰۴/۵۰۰) یک ردیف best-effort در
    // s2s_hook_events می‌گیرد؛ این متد «هرگز» استثنا نمی‌دهد و هرگز
    // وضعیت/بدنهٔ وب‌هوک را عوض نمی‌کند — شکست فقط logger->error است.
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * ثبت یک رویداد KPI برای وب‌هوک S2S (best-effort).
     *
     * @param array<string, mixed> $payload بدنهٔ خام درخواست (برای ادعای user_id در ردیف‌های rejected)
     * 🛡️ FIX-PS-C2: payout_amount در مسیر replay واقعاً null است.
     * @param array{user_id?: int, txid_hash?: string, payout_amount?: string|null, currency?: string} $extra داده‌های مسیرِ موفق
     */
    private function recordS2sHookEvent(string $network, string $outcome, ?string $rejectReason, int $httpStatus, array $payload, array $extra = []): void
    {
        try {
            if ($this->s2sHookEvents === null) {
                // سازنده اختیاری است؛ در فراخوانی‌های قدیمی (بدون تزریق) خودمان resolve می‌کنیم
                $this->s2sHookEvents = \Core\Container::getInstance()->make(\App\Models\S2sHookEvent::class);
            }

            $claimedUserId = int_value($payload['user_id'] ?? $payload['sub_id'] ?? 0);

            $this->s2sHookEvents->record([
                'network' => $network,
                'outcome' => $outcome,
                'reject_reason' => $rejectReason,
                'user_id' => $extra['user_id'] ?? ($claimedUserId > 0 ? $claimedUserId : null),
                'txid_hash' => $extra['txid_hash'] ?? null,
                'payout_amount' => $extra['payout_amount'] ?? null,
                'currency' => $extra['currency'] ?? null,
                'http_status' => $httpStatus,
                'ip' => $this->request->ip(),
            ]);
        } catch (\Throwable $e) {
            // best-effort: شکستِ مشاهده‌پذیری نباید هیچ‌گاه پاسخ وب‌هوک را تغییر دهد
            $this->logger->error('s2s_hook_event.write_failed', ['network' => $network, 'outcome' => $outcome, 'error' => $e->getMessage()]);
        }
    }

    /**
     * فعال‌سازی شتاب‌دهنده رشد سطح (XP Boost) پس از تماشای ویدیوی تبلیغاتی در داشبورد
     */
    public function claimBoost(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $userId = (int)$this->userId();
        if (!$userId) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'برای دریافت پاداش ابتدا وارد شوید.']);
            return;
        }

        try {
            // 🛡️ Fraud Guard: Verify user has completed at least one AdTube watch execution today
            $completedCount = $this->executionModel->countCompletedToday($userId);
            if ($completedCount <= 0) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'برای فعال‌سازی شتاب‌دهنده، ابتدا باید حداقل ۱ ویدیوی تبلیغاتی AdTube را به طور کامل تماشا کنید.']);
                return;
            }

            $cache = \Core\Cache::getInstance();
            $cooldownKey = "xp_boost_claimed:{$userId}";
            // 🛡️ FIX-R18N (Task 18-N — P2 REVIEW_ROUND18 #22): TOCTOU بسته شد —
            // الگوی قبلی get-then-set بود؛ دو درخواست هم‌زمان هر دو از get رد می‌شدند
            // و هر دو set می‌کردند (دوبار پاداش). claim اتمیک Core\Cache::add
            // (NX/TTL — هم درایور Redis و هم فایل اتمیک‌اند) جایگزین شد: فقط اولین
            // درخواست claim می‌کند؛ بقیه ۴۲۹ می‌گیرند. پیام/کد پاسخ دست‌نخورده.
            if (!$cache->add($cooldownKey, true, 86400)) { // 24h cooldown — claim اتمیک
                http_response_code(429);
                echo json_encode(['success' => false, 'message' => 'شما قبلاً امروز پاداش ویدیوی شتاب‌دهنده را دریافت کرده‌اید. هر ۲۴ ساعت یکبار امکان فعال‌سازی وجود دارد.']);
                return;
            }

            $activeKey = "xp_boost_active:{$userId}";
            $cache->set($activeKey, true, 86400);   // 24h active boost

            $xpGrowthRate = int_value(config('video_rewards.xp_growth_rate', setting('xp_growth_rate', 50)));
            $this->logger->info('user.xp_boost_activated', ['user_id' => $userId, 'rate' => $xpGrowthRate]);

            echo json_encode([
                'success' => true,
                'message' => "شتاب‌دهنده {$xpGrowthRate}٪ رشد سطح کاربری با موفقیت تا ۲۴ ساعت آینده برای حساب شما فعال شد."
            ]);
        } catch (\Throwable $e) {
            $this->logger->error('adtube.claim_boost.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'خطا در فعال‌سازی شتاب‌دهنده.']);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // FIX-X109: پاپ‌آپ‌های بوست هدیه (تماشای ویدیو → ثبتِ واقعی سرور)
    // الگوی claimBoost بالا: کلید Cache با TTL — صفر تغییر اسکیما.
    // پیش از X109 متن مودال‌ها ادعای «بررسی S2S» داشتند بدون هیچ POST واقعی؛
    // اکنون accept/dismiss واقعاً ثبت می‌شوند و state سرور تعیین‌کنندهٔ نمایش است.
    // ═════════════════════════════════════════════════════════════════════════

    // FIX-X117: فهرست ناحیه‌ها به helpers/functions.php منتقل شد (boost_areas()) تا
    // مصرف‌کننده‌های بوست (تیکت/صف‌های ادمین) و این کنترلر از یک منبع واحد بخوانند.

    /** مدت اعتبار بوستِ پذیرفته‌شده به تفکیک ناحیه (ثانیه) */
    private const BOOST_TTL = [
        'social'   => 86400,  // ۲۴ ساعت
        'kyc'      => 172800, // ۴۸ ساعت
        'ticket'   => 86400,
        'withdraw' => 86400,
        'dispute'  => 86400,
        'deposit'  => 86400,
        'vitrine'  => 86400,
    ];

    /** آرامش پس از انصراف صریح (۷ روز) */
    private const BOOST_DISMISS_TTL = 604800;

    /** 🛡️ FIX-R3-F3: عمر claim تک‌مصرفِ «اثبات تماشا» — باید از طولانی‌ترین TTL بوست (۴۸h) و آرامشِ انصراف (۷ روز) بلندتر باشد */
    private const BOOST_CLAIM_TTL_SECONDS = 604800;

    /** 🛡️ FIX-R3-F2: عمر چالشِ تک‌مصرفِ صفحهٔ تماشا (دقیقه) — پنجرهٔ معقول برای یک جلسهٔ تماشا */
    private const WATCH_CHALLENGE_TTL_MINUTES = 120;

    /** خواندن و اعتبارسنجی ناحیهٔ بوست از بدنهٔ POST یا کوئری GET */
    private function boostAreaFromRequest(): string
    {
        $raw = trim(str_value($this->request->body('area') ?? $this->request->get('area') ?? ''));
        return in_array($raw, boost_areas(), true) ? $raw : ''; // FIX-X117: منبع واحد
    }

    private function boostStateKey(string $area, int $userId): string
    {
        return boost_state_key($area, $userId); // FIX-X117: منبع واحد
    }

    // ═════════════════════════════════════════════════════════════════════════
    // 🛡️ FIX-R3-F2/F3 — کلید چالش تماشا + اثبات تماشا برای پاپ‌آپ بوست
    // ═════════════════════════════════════════════════════════════════════════

    /** کلید چالش تک‌مصرفِ صفحهٔ تماشا — اتصال‌یافته به (execution, user) */
    private function watchChallengeKey(int $executionId, int $userId): string
    {
        return "adtube_watch_challenge:{$executionId}:{$userId}";
    }

    /** راستی‌آزمایی چالش صفحهٔ تماشا (timing-safe) — ورودی خالی/مفقود/نامنطبق = رد */
    private function verifyWatchChallenge(int $executionId, int $userId, string $challenge): bool
    {
        if ($executionId <= 0 || $userId <= 0 || $challenge === '') {
            return false;
        }
        try {
            $stored = \Core\Cache::getInstance()->get($this->watchChallengeKey($executionId, $userId));
        } catch (\Throwable $e) {
            $this->logger->error('adtube.watch_challenge.read_failed', ['execution_id' => $executionId, 'error' => $e->getMessage()]);
            return false; // fail-closed: بدون مهرِ قابل‌خواندن، تسویه ممنوع
        }
        return is_string($stored)
            && $stored !== ''
            && hash_equals($stored, $challenge);
    }

    /**
     * 🛡️ FIX-R3-F3: یافتن «اثبات تماشا» برای پذیرش پاپ‌آپ بوست هدیه.
     * جدیدترین تماشای تکمیل‌شدهٔ ۲۴ ساعت اخیر که (۱) واقعاً تسویه و پاداشش
     * پرداخت شده (reward_paid=1)، (۲) مالکش همین کاربر است (کوئری executor_id)،
     * و (۳) مدت واقعی آن (completed_at − started_at) از حداقلِ متناسب با مدت
     * ویدیو در پلیسِ سرور گذشته باشد. خروجی=null یعنی هیچ اثبات قابل‌قبولی نیست.
     */
    private function findBoostProofExecution(int $userId): ?\stdClass
    {
        try {
            $candidates = $this->executionModel->getRecentCompletedForBoost($userId, 5);
        } catch (\Throwable $e) {
            $this->logger->error('rewards.boost_proof.query_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            return null; // fail-closed: بدون اثبات، پذیرش ممنوع
        }
        $policy = $this->adsBudgetSettlement->adtubeWatchPolicy();
        foreach ($candidates as $candidate) {
            if (!is_object($candidate) || (int)($candidate->id ?? 0) <= 0) {
                continue;
            }
            $startedAt = strtotime(str_value($candidate->started_at ?? ''));
            $completedAt = strtotime(str_value($candidate->completed_at ?? ''));
            if ($startedAt <= 0 || $completedAt <= 0 || $completedAt <= $startedAt) {
                continue;
            }
            // همان موتور سنجش تسویه (FIX-R3-F2) — با بیشینهٔ سرعت مجاز تا هیچ
            // تماشایی که خودِ تسویه پذیرفته، اینجا رد نشود.
            $metrics = \App\Services\Ads\AdsBudgetSettlementService::computeAdTubeMetrics(
                (int)$startedAt,
                (int)$completedAt,
                0,
                $policy['max_speed'],
                $policy['required_duration'],
                $policy['max_speed']
            );
            if ($metrics['elapsed_seconds'] >= $policy['min_watch_seconds'] && $metrics['progress_percent'] >= 80) {
                return $candidate;
            }
        }
        return null;
    }

    /** GET /rewards/boost-popup/state — آیا پاپ‌آپ مجاز به نمایش است؟ */
    public function boostPopupState(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        $cache = \Core\Cache::getInstance();
        $state = $cache->get($this->boostStateKey($area, $userId));
        $this->jsonSuccess('', [
            'area'     => $area,
            'state'    => is_string($state) ? $state : '',
            'can_show' => !in_array($state, ['accepted', 'dismissed'], true),
        ]);
    }

    /** POST /rewards/boost-popup/accept — ثبت فعال‌سازی بوست پس از پایان تماشای ویدیو */
    public function acceptBoostPopup(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('برای دریافت پاداش ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        try {
            // ═══ 🛡️ FIX-R3-F3 (P1 — R3 Ads/AdTube) ═══
            // CSRF/احراز هویت «اثباتِ درآمد» نیست؛ قبلاً هر کاربر لاگین‌شده با یک POST
            // در ۷ ناحیهٔ حساس (برداشت/KYC/واریز/اختلاف/تیکت/…) state=accepted می‌نوشت و
            // صف‌های ادمین را جلو می‌پرید. اکنون accept فقط با «اثباتِ تک‌مصرفِ یک
            // تماشای واقعی» پذیرفته می‌شود:
            //  ① تکمیل: رکورد completed با reward_paid=1 (فقط خروجی تسویهٔ سرور)؛
            //  ۲ مالکیت: کوئری روی executor_id = کاربرِ جاری؛
            //  ۳ مدت واقعی: completed_at − started_at ≥ حداقلِ پلیسِ سنجش سرور؛
            //  ۴ ضد-replay: claim اتمیک Cache::add روی خودِ execution — هر اجرا
            //    حداکثر یک‌بار حق پذیرش بوست دارد (هم‌زمان‌ها ۴۰۹ می‌گیرند).
            $proof = $this->findBoostProofExecution($userId);
            if ($proof === null) {
                $this->jsonError('برای فعال‌سازی بوست باید در ۲۴ ساعت گذشته یک ویدیوی AdTube را به‌طور کامل تماشا و پاداش آن را دریافت کرده باشید.', [], 403);
                return;
            }
            $cache = \Core\Cache::getInstance();
            $claimKey = "boost_popup_exec_claim:" . (int)$proof->id;
            if (!$cache->add($claimKey, $userId, self::BOOST_CLAIM_TTL_SECONDS)) {
                $this->jsonError('این پاداش تماشا قبلاً برای فعال‌سازی بوست مصرف شده است. برای بوست جدید یک ویدیوی دیگر را کامل تماشا کنید.', [], 409);
                return;
            }
            $ttl = self::BOOST_TTL[$area] ?? 86400;
            $cache->set($this->boostStateKey($area, $userId), 'accepted', $ttl);
            $this->logger->info('rewards.boost_popup_accepted', [
                'user_id' => $userId,
                'area' => $area,
                'ttl' => $ttl,
                'proof_execution_id' => (int)$proof->id, // 🛡️ FIX-R3-F3: اثباتِ مصرف‌شده در لجر لاگ
            ]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e; // FIX-X109: پاسخ jsonSuccess/jsonError را نبلع (الگوی VitrineController::buy)
        } catch (\Throwable $e) {
            $this->logger->error('rewards.boost_popup_accept.failed', ['user_id' => $userId, 'area' => $area, 'error' => $e->getMessage()]);
            $this->jsonError('خطا در ثبت بوست. لطفاً دوباره تلاش کنید.', [], 500);
        }
        $this->jsonSuccess('بوست شما با موفقیت ثبت شد.', ['area' => $area, 'state' => 'accepted']);
    }

    /** POST /rewards/boost-popup/dismiss — ثبت انصراف صریح (۷ روز آرامش) */
    public function dismissBoostPopup(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        try {
            \Core\Cache::getInstance()->set($this->boostStateKey($area, $userId), 'dismissed', self::BOOST_DISMISS_TTL);
            $this->logger->info('rewards.boost_popup_dismissed', ['user_id' => $userId, 'area' => $area]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e; // FIX-X109: پاسخ jsonSuccess را نبلع (الگوی VitrineController::buy)
        } catch (\Throwable $e) {
            $this->logger->error('rewards.boost_popup_dismiss.failed', ['user_id' => $userId, 'area' => $area, 'error' => $e->getMessage()]);
            $this->jsonError('خطا در ثبت انصراف.', [], 500);
        }
        $this->jsonSuccess('انصراف شما ثبت شد.', ['area' => $area, 'state' => 'dismissed']);
    }
}
