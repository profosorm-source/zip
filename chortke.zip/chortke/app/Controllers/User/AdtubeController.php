<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\Ads;
use App\Models\AdTubeExecutionModel;
use App\Services\Ads\AdsBudgetSettlementService;
use App\Services\AdSystemManager;
use Core\Response;

/**
 * AdtubeController — Executor-only controller for AdTube (video watch) ads.
 *
 * NOTE: Advertiser management (create, pause, stats, list) is unified under /ads (AdsController).
 * This controller only handles the worker/executor side: discovering videos, watching, and submission.
 */
class AdtubeController extends BaseUserController
{
    private Ads $adModel;
    private AdTubeExecutionModel $executionModel;
    private \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlement;
    private \App\Adapters\AdVideoRewardManager $rewardManager;
    /** FIX-POP — تزریق DI برای سازگاری فراخوانی‌های موجود سازنده؛ پاداش پاپ‌آپ پولی نیست (تصمیم ۲-A) و مسیر واریز وب‌هوک حذف شده است */
    private \App\Contracts\WalletServiceInterface $walletService;
    /** X374 (راند ۹۳) — لجر KPI وب‌هوک S2S (best-effort؛ اختیاری برای سازگاری سازنده) */
    private ?\App\Models\S2sHookEvent $s2sHookEvents;
    /** X374 — تزریق DI برای سازگاری فراخوانی‌های موجود سازنده؛ پس از FIX-POP پروب replay تراکنش دیگر مصرف نمی‌شود */
    private ?\App\Models\Transaction $transactionModel;

    public function __construct(
        Ads $adModel,
        AdTubeExecutionModel $executionModel,
        \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlement,
        \App\Adapters\AdVideoRewardManager $rewardManager,
        // 🧹 DI-CLEANUP (2026-08-24): به‌جای container->make در بدنه‌ی متد.
        \App\Contracts\WalletServiceInterface $walletService,
        ?\App\Contracts\LoggerInterface $logger = null,
        // X374 (راند ۹۳): دامنهٔ KPI برای S2S — هر دو اختیاری و nullable هستند
        // تا فراخوانی‌های موجود سازنده (tests/پروب‌ها) بدون تغییر سالم بمانند.
        ?\App\Models\S2sHookEvent $s2sHookEvents = null,
        ?\App\Models\Transaction $transactionModel = null
    ) {
        $this->adModel = $adModel;
        $this->executionModel = $executionModel;
        $this->adsBudgetSettlement = $adsBudgetSettlement;
        $this->rewardManager = $rewardManager;
        $this->walletService = $walletService;
        $this->s2sHookEvents = $s2sHookEvents;
        $this->transactionModel = $transactionModel;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * لودر مشترک داده‌های هاب تک‌صفحه‌ای AdTube.
     * 🛡️ تکمیل معماری هاب: تاریخچه تماشا به‌عنوان پنل سوم همان هاب سرو می‌شود
     * (الگوی هاب‌های تبلیغات/رفرال)؛ روت قدیمی /adtube/history فقط alias است.
     *
     * @return array<string, mixed>
     */
    private function hubData(int $userId, int $historyPage = 1): array
    {
        // Active ads of type 'adtube' with remaining budget and slots
        $tasks = $this->adModel->getAvailableCustomTasks(
            $userId,
            ['platform' => 'youtube'],
            20, 0, 'adtube'
        );

        $stats = [
            'total_completed_today' => $this->executionModel->countCompletedToday($userId),
            'active_watching' => $this->executionModel->countActiveForUser($userId),
            // FIX-S20-F3 (بازبینی بخش ۲۰): قبلاً placeholder ثابت ۰ بود (هیچ‌جا
            // محاسبه نمی‌شد) و در UI با label ثابت «تومان» چاپ می‌شد — درآمد واقعی
            // امروز به تفکیک ارز پاداش، هم‌قرارداد countCompletedToday.
            'earned_today_by_currency' => $this->executionModel->getEarningsTodayByCurrency($userId),
        ];

        // 🛡️ FIX-YT-7: مدت واقعی هر ویدیو از metadata کمپین — بدون هیچ fallback ثابت؛
        // کمپین بدون مدت از همان لیست مدل حذف شده (fail-closed).
        $tasks = array_map(static function ($task) {
            $duration = 0;
            if (is_object($task) && is_string($task->metadata ?? null) && $task->metadata !== '') {
                $decoded = json_decode((string)$task->metadata, true);
                if (is_array($decoded) && is_numeric($decoded['video_duration_seconds'] ?? null)) {
                    $duration = (int)$decoded['video_duration_seconds'];
                }
            }
            if (is_object($task)) {
                $task->video_duration_seconds = $duration;
                // FIX-YT-4: پاداش per-video از همان ردیف DB (price_per_task) — منبع واحد
                $task->reward_amount = $task->price_per_task;
            }
            return $task;
        }, $tasks);

        $rewardAds = $this->rewardManager->getAvailableRewardAds();

        // پنل «تاریخچه تماشا»
        $limit = 20;
        $history = $this->executionModel->getHistory($userId, $limit, (max(1, $historyPage) - 1) * $limit);

        return [
            'tasks' => $tasks,
            'stats' => $stats,
            'rewardAds' => $rewardAds,
            'trust_score' => 50, // Placeholder; could be fetched from ScoreService if needed
            'history' => $history,
            'historyPage' => max(1, $historyPage),
        ];
    }

    /**
     * داشبورد انجام‌دهنده — لیست ویدیوهای فعال AdTube
     */
    public function index(): void
    {
        $userId = (int)user_id();

        $this->view('user/adtube/index', array_merge($this->hubData($userId, $this->request->int('page', 1)), [
            'title' => 'AdTube — کسب درآمد از یوتیوب و تبلیغات جایزه‌دار',
        ]));
    }

    /**
     * شروع فرآیند اجرای یک ویدیو (AJAX)
     */
    public function start(): void
    {
        header('Content-Type: application/json');
        try {
            $body = $this->request->body();
            $adId = int_value($body['ad_id'] ?? $this->request->param('id'));
            $userId = (int)user_id();

            if (!$adId) {
                echo json_encode(['success' => false, 'message' => 'شناسه ویدیو نامعتبر است.']);
                return;
            }

            // Verify ad exists and is active
            $ad = $this->adModel->find($adId);
            if (!$ad || $ad->type !== 'adtube' || !in_array($ad->status, ['active', 'approved'], true)) {
                echo json_encode(['success' => false, 'message' => 'آگهی ویدیویی فعال یافت نشد.']);
                return;
            }

            // 🛡️ FIX-R3-F4 (P2): تماشای آگهیِ خودِ تبلیغ‌دهنده ممنوع — لیست عمومی
            // (فیلتر user_id != worker) تنها مرز دسترسی نیست؛ نقطهٔ شروع هم مالکیت را
            // برسی می‌کند تا اجرای ساختگی/تاریخچهٔ جعلی برای کمپینِ خود ساخته نشود.
            if ((int)($ad->user_id ?? 0) === $userId) {
                echo json_encode(['success' => false, 'message' => 'تماشای ویدیوی کمپین خودتان مجاز نیست و پاداشی تعلق نمی‌گیرد.']);
                return;
            }

            // ═══ 🛡️ FIX-YT-2 (تصمیم ۱-گزینه A) — گاردهای سقف/تکرار/کول‌داون در نقطهٔ شروع ═══
            // لیست عمومی فقط UI است؛ این گاردها مرز واقعی در برابر start مستقیم‌اند.

            // ① شمارندهٔ داعش (FIX-YT-1 + FIX-R1-7): سقف start در ساعت برای هر کاربر+IP
            //    (کلید شامل هش IP — ضد مزرعهٔ چند‌نشست روی یک حساب) قابل تنظیم از پنل.
            $cache = \Core\Cache::getInstance();
            $rlKey = 'adtube_start_rl:' . $userId . ':' . substr(md5($this->request->ip() ?: '0.0.0.0'), 0, 8) . ':' . (int)floor(time() / 3600);
            $starts = (int)$cache->get($rlKey, 0);
            $rlMax = max(3, int_value(setting('adtube_max_starts_per_hour', 12)));
            if ($starts >= $rlMax) {
                echo json_encode(['success' => false, 'message' => 'درخواست‌های شروع تماشا بیش از حد مجاز است؛ کمی بعد دوباره تلاش کنید.']);
                return;
            }
            $cache->increment($rlKey, 1, 3600);

            // ② ممنوعیت مطلق تماشای تکراری: هر کمپینی که کاربر کامل تماشا کرده و پاداشش
            //    پرداخت شده، برای همیشه قابل شروع مجدد نیست.
            if ($this->executionModel->hasCompletedForAd($adId, $userId)) {
                echo json_encode(['success' => false, 'message' => 'این ویدیو را قبلاً به‌طور کامل تماشا کرده‌اید؛ تماشای دوباره همان ویدیو مجاز نیست.']);
                return;
            }

            // ③ کول‌داون شبه‌تصادفی ۲۴–۷۲ ساعته (هر کمپین برای هر کاربر) — FIX-R1-5:
            //    برخلاف «آخرین» اجرا، «هر» اجرای قطعی‌شده (تکمیل/رد) برای همان کمپین بررسی
            //    می‌شود تا هم‌قرارداد فیلتر لیست (Ads::getAvailableCustomTasks) باشد؛
            //    در غیر این صورت start مستقیم می‌توانست کول‌داون ردیف‌های قدیمی‌تر را دور بزند.
            $settledRows = $this->executionModel->fetchAllSettledForAd($adId, $userId);
            foreach ($settledRows as $settledRow) {
                $anchor = strtotime((string)($settledRow->completed_at ?: $settledRow->updated_at));
                if ($anchor === false || $anchor <= 0) { continue; }
                $cooldownH = $this->executionModel->cooldownHours($adId, $userId, (int)$settledRow->id);
                $readyAt = $anchor + $cooldownH * 3600;
                if ($readyAt > time()) {
                    $hoursLeft = (int)ceil(($readyAt - time()) / 3600);
                    echo json_encode(['success' => false, 'message' => "این ویدیو در بازهٔ سرد است؛ حدود {$hoursLeft} ساعت دیگر قابل تماشا خواهد بود."]);
                    return;
                }
            }

            // ④ سقف روزانهٔ تماشا (قابل تنظیم از پنل ادمین، پیش‌فرض ۵):
            //    هیچ کاربری بیش از سقف، در یک شبانه‌روز پاداش تماشا نمی‌گیرد.
            $dailyCap = max(1, int_value(setting('adtube_max_watches_per_day', 5)));
            if ($this->executionModel->countCompletedToday($userId) >= $dailyCap) {
                echo json_encode(['success' => false, 'message' => "سقف روزانهٔ تماشای ویدیو ({$dailyCap} ویدیو) پر شده است؛ فردا دوباره سر بزنید."]);
                return;
            }

            // ⑤ fail-closed مدت (FIX-YT-7): کمپین بدون مدت واقعی ثبت‌شده اصلاً قابل شروع نیست.
            $adMetaDuration = 0;
            if (is_string($ad->metadata ?? null) && $ad->metadata !== '') {
                $decodedMeta = json_decode((string)$ad->metadata, true);
                if (is_array($decodedMeta) && is_numeric($decodedMeta['video_duration_seconds'] ?? null)) {
                    $adMetaDuration = (int)$decodedMeta['video_duration_seconds'];
                }
            }
            if ($adMetaDuration <= 0) {
                echo json_encode(['success' => false, 'message' => 'مدت واقعی این ویدیو ثبت نشده است؛ کمپین بدون مدت قابل تماشا نیست.']);
                return;
            }

            // Check if user has too many active watches (fast-path؛ داوری نهایی داخل reserveSlot و زیر قفل است)
            if ($this->executionModel->countActiveForUser($userId) >= 3) {
                echo json_encode(['success' => false, 'message' => 'حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.']);
                return;
            }

            $context = [
                'ip' => $this->request->ip(),
                'user_agent' => $this->request->userAgent(),
            ];

            // 🛡️ FIX-R3-F6 (P2): رزرو اسلات داخل تراکنشِ قفل‌دار (قفل ردیف users + شمارش
            // داخل همان قفل) — بستن TOCTOU سقف ۳ تماشای همزمان. null یعنی ظرفیت پر است.
            $execution = $this->executionModel->reserveSlot($adId, $userId, $context, 3);

            if (!$execution) {
                echo json_encode(['success' => false, 'message' => 'حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.']);
                return;
            }

            // Transition to watching
            $this->executionModel->startWatching((int)$execution->id);

            echo json_encode([
                'success' => true,
                'execution_id' => $execution->id,
                'redirect_url' => url('/adtube/' . $execution->id . '/execute'),
            ]);
        } catch (\Exception $e) {
            $this->logger->error('adtube.start.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطا در شروع تماشای ویدیو.']);
        }
    }

    /**
     * صفحه پخش ویدیو و ثبت اثبات
     */
    public function showExecute(): void
    {
        $userId = (int)user_id();
        $execId = (int)$this->request->param('id');

        $execution = $this->executionModel->findByIdWithAd($execId, $userId);

        if (!$execution) {
            $this->session->setFlash('error', 'اجرای مورد نظر یافت نشد.');
            redirect(url('/adtube'));
        }

        // Only allow if status is pending or watching
        if (!in_array($execution->status, ['pending', 'watching'], true)) {
            $this->session->setFlash('warning', 'این ویدیو قبلاً ثبت شده است.');
            redirect(url('/adtube'));
        }

        // 🛡️ FIX-R3-F2 (P1): مهر چالشِ سمت‌سرور برای این صفحهٔ تماشا — فرم بدون
        // این توکنِ تک‌مصرفِ اتصال‌یافته به همین execution قابل تسویه نیست (submit
        // آن را با hash_equals می‌سنجد). تایمرِ جاوااسکریپت فقط UX است؛ حقیقت،
        // started_at و ساعتِ سرور است.
        $watchChallenge = bin2hex(random_bytes(16));
        try {
            \Core\Cache::getInstance()->put($this->watchChallengeKey((int)$execution->id, $userId), $watchChallenge, self::WATCH_CHALLENGE_TTL_MINUTES);
        } catch (\Throwable $e) {
            // شکست کش → مهر ثبت نمی‌شود و submit همان مسیر fail-closed قبلی را می‌رود
            $this->logger->error('adtube.watch_challenge.mint_failed', ['execution_id' => (int)$execution->id, 'error' => $e->getMessage()]);
            $watchChallenge = '';
        }

        // 🛡️ FIX-R1-2: قرارداد واحد UI/سرور — تایمر صفحه همان «مدت سنجش سرور»
        // (بیشینهٔ مدت ویدیو و کف سراسری) است نه مدت خام؛ تا دکمه دقیقاً وقتی فعال شود
        // که سرور progress ≥۸۰٪ را تأیید می‌کند.
        $execVideoDuration = (int)($execution->video_duration ?? 0);
        $adRowMeta = '';
        try {
            $adRowForMeta = $this->adModel->find((int)$execution->ad_id);
            if ($adRowForMeta !== null && is_string($adRowForMeta->metadata ?? null)) {
                $adRowMeta = (string)$adRowForMeta->metadata;
            }
        } catch (\Throwable $e) {
            $this->logger->warning('adtube.execute.metadata_read_failed', ['execution_id' => (int)$execution->id, 'error' => $e->getMessage()]);
        }
        $watchPolicy = $this->adsBudgetSettlement->adtubePerVideoPolicy(
            $execVideoDuration > 0 ? $execVideoDuration : null,
            $adRowMeta
        );
        $requiredWatchSeconds = (int)($watchPolicy['required_duration'] ?? 0);

        $this->view('user/adtube/execute', [
            'title' => 'تماشای ویدیو و کسب درآمد',
            'execution' => $execution,
            'task' => $execution,
            'watchChallenge' => $watchChallenge,
            'requiredWatchSeconds' => $requiredWatchSeconds, // FIX-R1-2: قرارداد واحد
        ]);
    }

    /**
     * ثبت و ارسال نهایی نتایج (AJAX)
     */
    public function submit(): void
    {
        header('Content-Type: application/json');
        try {
            $execId = (int)$this->request->param('id');
            $userId = (int)user_id();
            $body = $this->request->body();

            $execution = $this->executionModel->findById($execId);
            if (!$execution || (int)$execution->executor_id !== $userId) {
                echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز.']);
                return;
            }

            if ($execution->status !== 'watching') {
                echo json_encode(['success' => false, 'message' => 'وضعیت اجرا نامعتبر است.']);
                return;
            }

            // 🛡️ FIX-R3-F2 (بخش الف): چالش تک‌مصرفِ صفحهٔ تماشا — تسویه فقط با
            // مَهری که سرور هنگام رندر صفحهٔ execute مینت کرده و به همین execution
            // بسته است (پیوند اجرا ↔ سیگنال قابل‌راستی‌آزمایی). شکستِ چالش = خطای
            // عادی (بدون markRejected) تا رفرشِ صفحه برای کاربر مشروع مسیر نجات بماند.
            $challenge = trim(str_value($body['watch_challenge'] ?? ''));
            if (!$this->verifyWatchChallenge($execId, $userId, $challenge)) {
                echo json_encode(['success' => false, 'message' => 'نشست تماشای این ویدیو معتبر نیست یا منقضی شده است؛ صفحه را دوباره باز کنید.']);
                return;
            }

            // Normalization: handle both watched_seconds and watch_time
            $watchTime = int_value($body['watch_time'] ?? $body['watched_seconds'] ?? 0);
            // 🛡️ FIX-S20-CLOSE-F1: سرعت ادعایی دیگر «حقیقت» نیست — فقط جهت ردِ مقدار
            // غیرممکن (>۲.۵x) خوانده می‌شود؛ در محاسبهٔ پاداش به ۱.۰ کلمپ می‌شود
            // (سیاست max_speed=1.0 در computeAdTubeMetrics). فیلد مخفی فرم هم حذف شد.
            $speed = float_value($body['playback_speed'] ?? 1.0);
            if ($speed <= 0) { $speed = 1.0; }

            // 🛡️ FIX-S20-CLOSE-F1: سیگنال پخش واقعی — انباشتهٔ سمت سرور از جریان
            // heartbeat های «حین پخش» (کلمپ ۱× بر ساعت سرور). بدون آن، تسویه
            // fail-closed است؛ اینجا هم الزامِ زودهنگام با پیام دوستانه (بدون
            // markRejected — الگوی چالش؛ خطای گذرا اجازهٔ retry می‌دهد).
            $heartbeatPlayedSeconds = $this->readHeartbeatPlayedSeconds($execId, $userId);
            if ($heartbeatPlayedSeconds <= 0) {
                echo json_encode(['success' => false, 'message' => 'سیگنال پخش ویدیو به سرور نرسیده است؛ صفحه را باز نگه دارید، ویدیو را پخش کنید و پس از فعال شدن دکمه، دوباره تلاش کنید.']);
                return;
            }

            // 🛡️ FIX-YT-3/7: مدت سنجش per-video از رکورد اجرا (ستون video_duration که در
            // reserveSlot از metadata کمپین درج شد) یا metadata کمپین — بدون هیچ پیش‌فرض.
            // اجرای بدون مدت = fail-closed.
            $perVideoPolicy = $this->adsBudgetSettlement->adtubePerVideoPolicy(
                (int)($execution->video_duration ?? 0) > 0 ? (int)$execution->video_duration : null,
                ''
            );
            $requiredDuration = $perVideoPolicy['required_duration'];
            if ($requiredDuration <= 0 && !empty($execution->ad_id)) {
                $adRow = $this->adModel->find((int)$execution->ad_id);
                if ($adRow !== null && is_string($adRow->metadata ?? null) && $adRow->metadata !== '') {
                    $perVideoPolicy = $this->adsBudgetSettlement->adtubePerVideoPolicy(null, (string)$adRow->metadata);
                    $requiredDuration = $perVideoPolicy['required_duration'];
                }
            }
            if ($requiredDuration <= 0) {
                $this->executionModel->markRejected($execId, 'مدت واقعی ویدیو برای این کمپین ثبت نشده است.');
                echo json_encode(['success' => false, 'message' => 'مدت واقعی این ویدیو ثبت نشده است؛ ثبت تماشا ممکن نیست.']);
                return;
            }
            $minWatchSeconds = $perVideoPolicy['min_watch_seconds'];
            $maxSpeed = $perVideoPolicy['max_speed'];

            // 🛡️ FIX-YT-7 (بخش ۲ تصمیم ۲): مدت پلیر واقعی (گزارش IFrame API) برای
            // راستی‌آزمایی mismatch — فقط ادعای کلاینت؛ سنجش نهایی زیر قفل در تسویه است.
            $playerDuration = int_value($body['player_duration'] ?? 0);

            $progress = int_value($body['progress_percent'] ?? 0);
            if ($progress <= 0 && $watchTime > 0) {
                $progress = (int)min(100, round(($watchTime / $requiredDuration) * 100));
            }

            $policy = ['required_duration' => $requiredDuration, 'max_speed' => $maxSpeed, 'min_watch_seconds' => $minWatchSeconds];

            // 🛡️ FIX-S20-CLOSE-F1: گارد سرعت فقط «مقدار غیرممکن» را رد می‌کند (>۲.۵x از
            // هیچ پلیر واقعی نمی‌آید = دستکاری). مقادیر ۱..۲.۵x (پلیر واقعی یوتیوب)
            // رد نمی‌شوند ولی در پاداش به ۱× کلمپ می‌شوند — سرعت، پاداش را کوتاه نمی‌کند.
            if ($speed > self::ADTUBE_HARD_SPEED_CEILING) {
                $this->executionModel->markRejected($execId, 'سرعت پخش غیرعادی: ' . $speed . 'x');
                echo json_encode(['success' => false, 'message' => 'سرعت پخش غیرعادی تشخیص داده شد.']);
                return;
            }

            // 🛡️ FIX-R3-F2 (بخش ج): گارد ضدتقلب زمانی بر ساعتِ سرور — ادعای تماشای
            // بیشتر از سقف فیزیکی (elapsed × سرعتِ سقف‌دار + تلورانس) رد می‌شود.
            // توجه: محاسبهٔ نهایی progress/مدت در settleAdTubeView و زیر قفل ردیفی
            // انجام می‌شود؛ این فقط گاردِ زودهنگامِ همان قانون است.
            $startedAt = 0;
            if (!empty($execution->started_at)) {
                $startedAt = strtotime((string)$execution->started_at);
            } elseif (!empty($execution->created_at)) {
                $startedAt = strtotime((string)$execution->created_at);
            }

            if ($startedAt > 0) {
                $metrics = \App\Services\Ads\AdsBudgetSettlementService::computeAdTubeMetrics(
                    (int)$startedAt,
                    time(),
                    $watchTime,
                    $speed,
                    $requiredDuration,
                    $maxSpeed,
                    $heartbeatPlayedSeconds
                );
                if ($metrics['fraud']) {
                    $this->executionModel->markRejected($execId, 'تقلب زمان مشاهده: ادعای کلاینت ' . $watchTime . 's، سیگنال پخش سرور ' . $heartbeatPlayedSeconds . 's، سقف فیزیکی سرور ' . $metrics['max_content_seconds'] . 's');
                    echo json_encode(['success' => false, 'message' => 'زمان تماشای واقعی با زمان سپری‌شده بر روی سرور مطابقت ندارد.']);
                    return;
                }
            }

            // توجه: حداقلِ «۸۰٪ تماشا» دیگر روی progress ادعاییِ کلاینت سنجیده نمی‌شود؛
            // پیشرفتِ واقعی فقط از started_at تا اکنون در settleAdTubeView محاسبه و
            // در صورت کفایت، پاداش پرداخت می‌شود (FIX-R3-F2).

            $finance = $this->adsBudgetSettlement;
            $settlement = $finance->settleAdTubeView($execId, $userId, $watchTime, $progress, $speed, $playerDuration, $heartbeatPlayedSeconds);

            if (!empty($settlement['success'])) {
                // مصرف چالش (تک‌مصرف) فقط پس از تسویهٔ موفق — خطای گذرا اجازهٔ retry می‌دهد
                try {
                    \Core\Cache::getInstance()->forget($this->watchChallengeKey($execId, $userId));
                } catch (\Throwable $e) {
                    $this->logger->warning('adtube.watch_challenge.consume_failed', ['execution_id' => $execId, 'error' => $e->getMessage()]);
                }
            }

            echo json_encode([
                'success' => !empty($settlement['success']),
                'message' => $settlement['message'] ?? (!empty($settlement['success']) ? 'ویدیو با موفقیت ثبت و پاداش پرداخت شد.' : 'تسویه ویدیو انجام نشد.'),
                'execution_id' => $execId,
                'settlement' => $settlement,
            ], JSON_UNESCAPED_UNICODE);
        } catch (\Exception $e) {
            $this->logger->error('adtube.submit.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطای سیستمی در ثبت نهایی.']);
        }
    }

    /**
     * 🛡️ FIX-S20-CLOSE-F1 (پایان‌کار بازبینی S20 — یافتهٔ ۱، P1): ثبت سیگنال پخش واقعی.
     *
     * POST /adtube/{id}/heartbeat — پلیر صفحهٔ تماشا (IFrame API یوتیوب) هر چند
     * ثانیه یک‌بار، «فقط حین پخش»، شمارندهٔ تجمعی ثانیه‌های پخش را می‌فرستد؛ سرور
     * با ساعت خودش افزایش را کلمپ می‌کند (حداکثر ۱× + ۱ث تلورانس) و انباشتهٔ
     * معتبر را در کش نگه می‌دارد. تسویه (submit → settleAdTubeView) بدون این
     * سیگنال fail-closed رد می‌شود — تایمر صفحه/ادعای watch_time به‌تنهایی
     * پاداش نمی‌سازند.
     *
     * مرزهای ضدتقلب (همه سمت سرور):
     *  - افزایش انباشته ≤ فاصلهٔ دیواری از آخرین heartbeat + ۱ث (قفل ۱×).
     *  - پایهٔ شمارندهٔ کلاینت هرگز پایین نمی‌رود (ضدِ ریست و ادعای دوباره).
     *  - سقف مطلق خوانده‌شده = زمان دیواری از اولین heartbeat (ضد تورمِ هم‌زمانی).
     *  - heartbeat متراکم‌تر از ۱ث فقط مبنا را همگام می‌کند (بدون انباشت).
     *  - چالش صفحهٔ تماشا الزامی است (پیوند جریان به رندر واقعی صفحه) ولی مصرف
     *    نمی‌شود — مصرف تک‌مصرفیش فقط در submit موفق است.
     */
    public function heartbeat(): void
    {
        header('Content-Type: application/json');
        try {
            $execId = (int)$this->request->param('id');
            $userId = (int)user_id();
            $body = $this->request->body();

            $execution = $this->executionModel->findById($execId);
            if (!$execution || (int)$execution->executor_id !== $userId) {
                echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز.']);
                return;
            }
            if ($execution->status !== 'watching') {
                echo json_encode(['success' => false, 'message' => 'وضعیت اجرا نامعتبر است.']);
                return;
            }

            // پیوند به رندر واقعی صفحهٔ تماشا — همان چالشِ submit (تک‌مصرف نیست اینجا)
            $challenge = trim(str_value($body['watch_challenge'] ?? ''));
            if (!$this->verifyWatchChallenge($execId, $userId, $challenge)) {
                echo json_encode(['success' => false, 'message' => 'نشست تماشای این ویدیو معتبر نیست یا منقضی شده است؛ صفحه را دوباره باز کنید.']);
                return;
            }

            $clientPlayed = max(0, int_value($body['played_seconds'] ?? 0));
            $playing = filter_var($body['playing'] ?? false, FILTER_VALIDATE_BOOLEAN);
            $seq = max(0, int_value($body['seq'] ?? 0));

            $cache = \Core\Cache::getInstance();
            $stateKey = $this->heartbeatStateKey($execId, $userId);
            try {
                $state = $cache->get($stateKey);
            } catch (\Throwable $e) {
                $state = null;
            }
            $now = time();
            $state = AdsBudgetSettlementService::accumulateHeartbeatState(is_array($state) ? $state : null, $clientPlayed, $playing, $seq, $now);
            try {
                $cache->setSeconds($stateKey, $state, self::HEARTBEAT_STATE_TTL_SECONDS);
            } catch (\Throwable $e) {
                // fail-closed: بدون ثبت قابل‌اتکای وضعیت، سیگنال «ثبت‌شده» تلقی نمی‌شود
                $this->logger->error('adtube.heartbeat.persist_failed', ['execution_id' => $execId, 'user_id' => $userId, 'error' => $e->getMessage()]);
                echo json_encode(['success' => false, 'message' => 'ثبت سیگنال پخش ممکن نشد؛ اتصال خود را بررسی کنید.']);
                return;
            }
            echo json_encode([
                'success' => true,
                'data' => [
                    'played_seconds' => AdsBudgetSettlementService::effectiveHeartbeatSeconds($state, $now),
                ],
            ]);
        } catch (\Exception $e) {
            $this->logger->error('adtube.heartbeat.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطا در ثبت سیگنال پخش.']);
        }
    }

    /**
     * تاریخچه فعالیت کاربر در AdTube
     */
    public function history(): void
    {
        // 🛡️ هاب تک‌صفحه‌ای: alias همان هاب — پنل تاریخچه باز می‌شود
        $userId = (int)user_id();
        $page = max(1, $this->request->int('page', 1));

        $this->view('user/adtube/history', array_merge($this->hubData($userId, $page), [
            'title' => 'تاریخچه کسب درآمد AdTube',
        ]));
    }

    /**
     * 🛡️ وب‌هوک امن سرور به سرور (S2S Callback Verification)
     * دریافت تاییدیه تماشای ویدیو از سرورهای تپسل و ادموب و واریز پاداش
     */
    public function s2sWebhook(): void
    {
        // FIX-X342 (راند ۸۴): همهٔ پاسخ‌ها باید از مسیر Response::json() بروند —
        // الگوی قبلی «http_response_code(X) + echo» توسط toResponse()ی میدل‌ور
        // بیرونی در Response تازه با ۲۰۰ پیچیده می‌شد و وضعیت واقعی (۴۰۰/۴۰۱/۴۰۴/۵۰۰)
        // هرگز به شبکهٔ تبلیغاتی نمی‌رسید → منطق retry شبکه‌ها کاملاً کور می‌شد.
        // Response::json → send() → HttpResponseException → روتر با وضعیت صحیح می‌فرستد.
        $network = (string)$this->request->param('network');
        $payload = $this->request->body();
        // FIX-X352 راند ۸۷ — امضای HMAC باید روی بایت‌های خام دریافتی محاسبه شود
        // نه بازسازی json_encode آرایهٔ پارس‌شده (اسنپ‌شات کش‌شدهٔ constructor).
        $rawBody = $this->request->rawBody();
        // Finding #7 Fix: Enforce Webhook signature strictly from HTTP headers (never Query String)
        $receivedSignature = str_value($this->request->header('X-Webhook-Signature', $this->request->header('X-AdTube-Signature', '')));
        $timestamp = int_value($this->request->header('X-Webhook-Timestamp', $this->request->header('X-AdTube-Timestamp', 0)));

        // FIX-X332 راند ۸۴: بررسی تازگی حالا fail-closed است — شرط قبلی ($timestamp > 0 && …)
        // غیبت/خرابی هدر Timestamp را از چک replay معاف می‌کرد؛ اکنون هدر مفقود/ناخوانا هم رد می‌شود.
        if ($timestamp <= 0) {
            // X374 (راند ۹۳): لجر KPI — هر خروجی نهایی یک ردیف best-effort دارد
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_TIMESTAMP, 400, $payload);
            (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'هدر زمان‌بندی وب‌هوک مفقود یا نامعتبر است (Timestamp Required)']);
            return;
        }
        // Finding #6 Fix: Freshness verification (max 300s window)
        if (abs(time() - $timestamp) > 300) {
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_TIMESTAMP, 400, $payload);
            (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'درخواست وب‌هوک منقضی شده است (Timestamp Expired)']);
            return;
        }

        try {
            $adapter = $this->rewardManager->getAdapter($network);
            if (!$adapter->verifyS2SHmac($rawBody, $receivedSignature)) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_SIGNATURE, 401, $payload);
                (new Response())->setStatusCode(401)->json(['success' => false, 'message' => 'امضای وب‌هوک نامعتبر است (HMAC Mismatch)']);
                return;
            }

            // ═══ 🛡️ FIX-POP (تصمیم ۱-A مالک — معماری «برگه/تمبر») ═══
            // پاداش فقط به postback‌ای تعلق می‌گیرد که به «جلسهٔ تماشای pending» واقعی
            // متصل باشد (توکن جلسه هنگام start صادر و در مرجع شبکه/شبیه‌ساز ارجاع شده).
            // user_id خامِ payload دیگر هرگز مستقیماً اعتبار نمی‌گیرد (قبلاً هر postback
            // امضاشده‌ای می‌توانست برای هر user_id واریز کند — بدون هیچ جلسهٔ تماشایی).
            // FIX-X333 (idempotency txid) در سطح کنترلر نگه داشته می‌شود؛ لایهٔ تک‌مصرفِ
            // جلسه (claim اتمیک) روی خودِ جلسه اعمال می‌شود.
            $sessionToken = trim(str_value($payload['session_id'] ?? $payload['sub_id'] ?? ''));
            if ($sessionToken === '') {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_NO_SESSION, 400, $payload);
                (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'شناسهٔ جلسهٔ تماشا (session_id) مفقود است — postback بدون برگهٔ تماشا پذیرفته نمی‌شود']);
                return;
            }

            try {
                $cache = \Core\Cache::getInstance();
                $session = $cache->get($this->popupSessionKey($sessionToken));
            } catch (\Throwable $cacheEx) {
                $session = null;
            }
            // 🛡️ FIX-POP: تفکیک «مصرف‌شده» (۴۰۹) از «ناموجود/منقضی» (۴۰۰) —
            // قرارداد S2S: 409 به شبکه می‌گوید «همین session قبلاً پاداش گرفته؛ retry نکن»
            // و 400 یعنی «برگهٔ نامعتبر». قبلاً هر دو یک پاسخ 400 می‌گرفتند و شبکهٔ
            // مقصد نمی‌توانست retry سالم را از replay تشخیص دهد.
            // ① رکورد جلسه هست و وضعیتش credited است؛ یا
            // ② رکورد جلسه منقضی شده ولی مُهر claim اتمیک هنوز زنده است
            //    (TTL claim 1h ممکن است از TTL جلسه کوتاه‌تر/بلندتر باشد — هر دو جهت پوشش داده شود).
            $sessionClaimKey = 'popup_session_claim:' . $sessionToken;
            $claimedBefore = false;
            try {
                $claimedBefore = \Core\Cache::getInstance()->get($sessionClaimKey) !== null;
            } catch (\Throwable $claimProbeEx) {
                $claimedBefore = false; // بی‌اثر — فقط ارتقای پاسخ 400→409
            }
            $sessionStatus = is_array($session) ? (string)($session['status'] ?? '') : '';
            if ($sessionStatus === 'credited' || (!is_array($session) && $claimedBefore)) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_SESSION_CONSUMED, 409, $payload);
                (new Response())->setStatusCode(409)->json(['success' => false, 'message' => 'این جلسهٔ تماشا قبلاً مصرف شده است (Session Already Consumed)']);
                return;
            }
            if (!is_array($session) || $sessionStatus !== 'pending') {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_NO_SESSION, 400, $payload);
                (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'جلسهٔ تماشا یافت نشد یا منقضی شده است (Unknown/Expired Session)']);
                return;
            }

            // تطابق شبکه: برگهٔ صادره برای شبکهٔ دیگری است؟ (خطای پیکربندی شبکه مقصد)
            if ((string)($session['network'] ?? '') !== strtolower(trim($network))) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_NO_SESSION, 400, $payload);
                (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'این جلسهٔ تماشا متعلق به شبکهٔ دیگری است']);
                return;
            }

            // تطابق کاربر: اگر شبکه user_id فرستاده باشد باید با صاحبِ برگه یکی باشد؛
            // در نبود آن، صاحبِ جلسه ملاک است (هویت از برگه، نه از payload).
            $claimedUserId = int_value($payload['user_id'] ?? 0);
            $sessionUserId = (int)($session['user_id'] ?? 0);
            if ($claimedUserId > 0 && $claimedUserId !== $sessionUserId) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_INVALID_USER, 400, $payload);
                (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'شناسه کاربری با صاحب جلسهٔ تماشا منطبق نیست']);
                return;
            }
            $userId = $sessionUserId;

            // 🛡️ گارد مدت سرور: فاصلهٔ start→postback حداقلِ مدت ویدیو.
            // FIX-R2-SKEW (بازبین R2): گرِیس ۱ ثانیه‌ای برای تأخیر انتقال شبکه‌ای (فقط خواندنی
            // و مستند) — قبلاً ۲ ثانیه بود که «حداقل مدت» را شل می‌کرد؛ شبکه‌ای که دقیقاً
            // بعد از مدت postback کند با تأخیر انتقال در مرز ±۱ث می‌ماند و retry سالم دارد.
            $duration = max(1, (int)($session['duration_seconds'] ?? 0));
            $startedAt = (int)($session['started_at'] ?? 0);
            if ($startedAt <= 0 || (time() - $startedAt) < ($duration - 1)) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_TOO_EARLY, 400, $payload);
                (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'تأییدیهٔ تماشا زودتر از مدت ویدیو رسیده است (Too Early)']);
                return;
            }

            // 🛡️ مصرفِ تک‌بارة جلسه (claim اتمیک — هم‌زمان‌ها/تلاش‌های بعدی ۴۰۹ می‌گیرند)
            try {
                $claimed = \Core\Cache::getInstance()->add('popup_session_claim:' . $sessionToken, 1, 3600);
            } catch (\Throwable $claimEx) {
                $claimed = false; // fail-closed: بدون مهر قابل‌اعتماد، پاداش ممنوع
            }
            if (!$claimed) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_SESSION_CONSUMED, 409, $payload);
                (new Response())->setStatusCode(409)->json(['success' => false, 'message' => 'این جلسهٔ تماشا قبلاً مصرف شده است']);
                return;
            }

            // ثبت postback در وضعیت جلسه (قابل‌مشاهده برای اشکال‌زدایی)
            try {
                $session['status'] = 'credited';
                // FIX-R2-TTL (بازبین R2): Cache::set بر حسب «دقیقه» است — 3600 یعنی ۶۰ ساعت!
                // مُهر credited باید ۱ ساعت بماند → setSeconds (ثانیه).
                \Core\Cache::getInstance()->setSeconds($this->popupSessionKey($sessionToken), $session, 3600);
            } catch (\Throwable $markEx) {
                // غیرمسدودکننده — claim اتمیک مرزِ تک‌مصرف است
            }

            // 🛡️ اعطای پاداش «بدون هیچ پرداخت پولی» (تصمیم ۲-A مالک):
            //  ① بوست صف همان ناحیه (برداشت/KYC/تیکت/… → صدرنشینی رکورد در پنل ادمین)
            //  ۲ XP انگیزشی per-section (دامنهٔ لجر xp_popup_boost، سقف روزانه per-section)
            //  ۳ ناحیهٔ lottery: بوستِ فعال در اجرای روزانهٔ ۰۳:۲۰ شانس با lottery_chance_boost اعمال می‌شود
            $area = str_value($session['area'] ?? '');
            $rewardDetail = $this->grantPopupSessionReward($userId, $area, $sessionToken);

            // X374: ردیف لجر KPI — txid_hash همان هشِ txid شبکه (یا توکن جلسه) است؛
            // پاداش این چرخه پول نیست → payout_amount/currency ثبت نمی‌شود تا KPI مالی آلوده نشود.
            $txid = '';
            foreach (['transaction_id', 'txid', 'event_id'] as $txField) {
                $candidate = trim(str_value($payload[$txField] ?? ''));
                if ($candidate !== '' && strlen($candidate) <= 256) {
                    $txid = $candidate;
                    break;
                }
            }
            $txidHash = hash('sha256', $network . '|' . ($txid !== '' ? $txid : 'session:' . $sessionToken));

            $this->recordS2sHookEvent(
                $network,
                \App\Models\S2sHookEvent::OUTCOME_CREDITED,
                null,
                200,
                $payload,
                [
                    'user_id' => $userId,
                    'txid_hash' => $txidHash,
                ]
            );

            $this->logger->info('s2s_webhook.popup_session_credited', ['user_id' => $userId, 'network' => $network, 'area' => $area, 'reward' => $rewardDetail]);
            (new Response())->json(['success' => true, 'message' => 'تأییدیهٔ تماشا پذیرش شد؛ پاداش بوست (XP + اولویت صف) ثبت گردید']);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            // FIX-X342 راند ۸۴: HttpResponseException جریانِ کنترل فریم‌ورک است (Response::json
            // با send() آن را پرتاب می‌کند) — نباید توسط catchهای پایین بلعیده و ۵۰۰ شود.
            throw $e;
        } catch (\InvalidArgumentException $e) {
            // FIX-X336 راند ۸۴: شبکهٔ ناشناخته (تایپو/اسم غلط مثل adtube) ۴۰۴ است نه ۵۰۰ —
            // قبلاً InvalidArgumentExceptionِ AdVideoRewardManager::getAdapter در catch(\Throwable)
            // می‌افتاد و «خطای سرور» + لاگ error-لول تولید می‌کرد؛ اکنون پاسخ ۴۰۴ با لاگ warning.
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_UNKNOWN_NETWORK, 404, $payload);
            $this->logger->warning('s2s_webhook.unknown_network', ['network' => $network, 'error' => $e->getMessage()]);
            (new Response())->setStatusCode(404)->json(['success' => false, 'message' => 'شبکهٔ تبلیغاتی شناخته نشده است']);
        } catch (\Throwable $e) {
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_SERVER_ERROR, 500, $payload);
            $this->logger->error('s2s_webhook.failed', ['network' => $network, 'error' => $e->getMessage()]);
            (new Response())->setStatusCode(500)->json(['success' => false, 'message' => 'خطای سرور در پردازش وب‌هوک']);
        }
    }

    /**
     * 🛡️ FIX-YT-6 (راند YT) — ویدیوی واقعی برای مودال «شبیه‌ساز S2S» داشبورد.
     * پیش از این، مودال فقط یک شمارش معکوس ۱۵ ثانیه‌ای کلاینت‌ساید بدون هیچ ویدیویی بود.
     * اکنون:
     *  ۱) یک ویدیوی واقعیِ کمپین فعال AdTube (یوتیوب) با مدت ثبت‌شدهٔ خودش برمی‌گردد؛
     *  ۲) شبکه‌های ویدیویی جایزه‌دار با وضعیت پیکربندی واقعی (فعال‌سازی کد مردهٔ
     *     getAvailableRewardAds پس از حذف X338) — صادقانه: با flag فعال/غیرفعالِ مشتق از secret وب‌هوک؛
     *  ۳) هیچ واریز/پاداشی از این مسیر انجام نمی‌شود؛ پاداش واقعی فقط از تسویهٔ سرور
     *     (/adtube/{id}/submit) و اثبات تماشای تکمیل‌شده برای claim-boost معتبر است.
     */
    public function dashVideo(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $userId = (int)user_id();
        if (!$userId) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'برای نمایش ویدیو ابتدا وارد شوید.']);
            return;
        }

        try {
            $tasks = $this->adModel->getAvailableCustomTasks(
                $userId,
                ['platform' => 'youtube'],
                5,
                0,
                'adtube'
            );

            $video = null;
            foreach ($tasks as $task) {
                $duration = 0;
                if (is_string($task->metadata ?? null) && $task->metadata !== '') {
                    $decoded = json_decode((string)$task->metadata, true);
                    if (is_array($decoded) && is_numeric($decoded['video_duration_seconds'] ?? null)) {
                        $duration = (int)$decoded['video_duration_seconds'];
                    }
                }
                $videoId = youtube_video_id((string)($task->link ?? ''));
                if ($duration > 0 && $videoId !== null) {
                    $video = [
                        'ad_id'                   => (int)$task->id,
                        'title'                   => (string)$task->title,
                        'youtube_video_id'        => $videoId,
                        'video_duration_seconds'  => $duration,
                        'reward_amount'           => (string)($task->price_per_task ?? '0'),
                        'currency'                => (string)($task->currency ?? 'irt'),
                    ];
                    break;
                }
            }

            // فعال‌سازی کد مردهٔ FIX-YT-9: شبکه‌ها با وضعیت پیکربندی واقعی برای مودال
            $networks = [];
            foreach ($this->rewardManager->getAvailableRewardAds() as $network => $ad) {
                if (!is_array($ad)) { continue; }
                $networks[] = [
                    'network'            => (string)($ad['network'] ?? $network),
                    'title'              => (string)($ad['title'] ?? $network),
                    'currency'           => (string)($ad['currency'] ?? 'irt'),
                    'payout_amount'      => (string)($ad['payout_amount'] ?? '0'),
                    'is_active'          => (bool)($ad['is_active'] ?? false),
                ];
            }

            echo json_encode([
                'success'          => true,
                'video'            => $video,
                'reward_networks'  => $networks,
                'xp_growth_rate'   => int_value(config('video_rewards.xp_growth_rate', setting('xp_growth_rate', 50))),
                // FIX-POP: مبلغ واقعی پاداش XP روزانهٔ claim-boost برای کپی صادقانهٔ مودال
                'xp_daily'         => float_value(setting('xp_boost_daily_amount', 50)),
            ], JSON_UNESCAPED_UNICODE);
        } catch (\Throwable $e) {
            $this->logger->error('adtube.dash_video.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'خطا در آماده‌سازی ویدیوی داشبورد.']);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // X374 (راند ۹۳) — لجر KPI وب‌هوک S2S
    // هر خروجی نهایی (۲۰۰/۴۰۰/۴۰۱/۴۰۴/۵۰۰) یک ردیف best-effort در
    // s2s_hook_events می‌گیرد؛ این متد «هرگز» استثنا نمی‌دهد و هرگز
    // وضعیت/بدنهٔ وب‌هوک را عوض نمی‌کند — شکست فقط logger->error است.
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * ثبت یک رویداد KPI برای وب‌هوک S2S (best-effort).
     *
     * @param array<string, mixed> $payload بدنهٔ خام درخواست (برای ادعای user_id در ردیف‌های rejected)
     * 🛡️ FIX-PS-C2: payout_amount در مسیر replay واقعاً null است.
     * @param array{user_id?: int, txid_hash?: string, payout_amount?: string|null, currency?: string} $extra داده‌های مسیرِ موفق
     */
    private function recordS2sHookEvent(string $network, string $outcome, ?string $rejectReason, int $httpStatus, array $payload, array $extra = []): void
    {
        try {
            if ($this->s2sHookEvents === null) {
                // سازنده اختیاری است؛ در فراخوانی‌های قدیمی (بدون تزریق) خودمان resolve می‌کنیم
                $this->s2sHookEvents = \Core\Container::getInstance()->make(\App\Models\S2sHookEvent::class);
            }

            $claimedUserId = int_value($payload['user_id'] ?? $payload['sub_id'] ?? 0);

            $this->s2sHookEvents->record([
                'network' => $network,
                'outcome' => $outcome,
                'reject_reason' => $rejectReason,
                'user_id' => $extra['user_id'] ?? ($claimedUserId > 0 ? $claimedUserId : null),
                'txid_hash' => $extra['txid_hash'] ?? null,
                'payout_amount' => $extra['payout_amount'] ?? null,
                'currency' => $extra['currency'] ?? null,
                'http_status' => $httpStatus,
                'ip' => $this->request->ip(),
            ]);
        } catch (\Throwable $e) {
            // best-effort: شکستِ مشاهده‌پذیری نباید هیچ‌گاه پاسخ وب‌هوک را تغییر دهد
            $this->logger->error('s2s_hook_event.write_failed', ['network' => $network, 'outcome' => $outcome, 'error' => $e->getMessage()]);
        }
    }

    /**
     * پاداش XP روزانهٔ «تماشای ویدیو» داشبورد — FIX-POP (تصمیم ۲-A مالک).
     * 🛡️ ریشه‌ای: قبلاً کلید xp_boost_active:{uid} ست می‌شد اما «هیچ خواننده‌ای» در کل
     * کد نداشت (تست S5 هم خواندنش در UserLevelQueryService را صریحاً می‌بندد) — یعنی
     * پیام «شتاب‌دهنده ۵۰٪ فعال شد» وعده‌ای بی‌اثر بود (نقض قانون ۶). اکنون XP «واقعی»
     * به لجر (دامنه xp_popup_boost + دلتای xp_global) با claim اتمیک روزانه تعلق می‌گیرد.
     */
    public function claimBoost(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $userId = (int)$this->userId();
        if (!$userId) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'برای دریافت پاداش ابتدا وارد شوید.']);
            return;
        }

        try {
            // 🛡️ Fraud Guard: Verify user has completed at least one AdTube watch execution today
            $completedCount = $this->executionModel->countCompletedToday($userId);
            if ($completedCount <= 0) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'برای دریافت پاداش، ابتدا باید حداقل ۱ ویدیوی تبلیغاتی AdTube را به طور کامل تماشا کنید.']);
                return;
            }

            $cache = \Core\Cache::getInstance();
            $cooldownKey = "xp_boost_claimed:{$userId}";
            // 🛡️ FIX-R18N (Task 18-N — P2 REVIEW_ROUND18 #22): TOCTOU بسته شد —
            // الگوی قبلی get-then-set بود؛ دو درخواست هم‌زمان هر دو از get رد می‌شدند
            // و هر دو set می‌کردند (دوبار پاداش). claim اتمیک Core\Cache::add
            // (NX/TTL — هم درایور Redis و هم فایل اتمیک‌اند) جایگزین شد: فقط اولین
            // درخواست claim می‌کند؛ بقیه ۴۲۹ می‌گیرند. پیام/کد پاسخ دست‌نخورده.
            if (!$cache->add($cooldownKey, true, 86400)) { // 24h cooldown — claim اتمیک
                http_response_code(429);
                echo json_encode(['success' => false, 'message' => 'شما قبلاً امروز پاداش ویدیو را دریافت کرده‌اید. هر ۲۴ ساعت یکبار امکان دریافت مجدد وجود دارد.']);
                return;
            }

            // 🛡️ FIX-POP: اعطای XP «واقعی» به لجر (بدون هیچ پرداخت پولی)؛ شکست لجر =
            // آزادسازی claim تا کاربر فردا/بعداً دوباره بتواند دریافت کند (پاداش از دست نرود).
            $xpAmount = float_value(setting('xp_boost_daily_amount', 50));
            if ($xpAmount <= 0) {
                $cache->forget($cooldownKey);
                http_response_code(503);
                echo json_encode(['success' => false, 'message' => 'پاداش XP در حال حاضر غیرفعال است (مبلغ تنظیم‌شده صفر است).']);
                return;
            }
            try {
                $xp = \Core\Container::getInstance()->make(\App\Services\Gamification\XpService::class);
                $idem = 'xp_boost_dashboard:' . $userId . ':' . date('Y-m-d');
                $ok = $xp->award($userId, \App\Enums\ModuleContext::POPUP_BOOST, $xpAmount, $idem);
            } catch (\Throwable $xpEx) {
                $this->logger->error('adtube.claim_boost.xp_failed', ['user_id' => $userId, 'error' => $xpEx->getMessage()]);
                $ok = false;
            }
            if (!$ok) {
                try { $cache->forget($cooldownKey); } catch (\Throwable $delEx) {}
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'ثبت XP انجام نشد؛ لطفاً کمی بعد دوباره تلاش کنید.']);
                return;
            }

            $this->logger->info('user.xp_boost_credited', ['user_id' => $userId, 'xp' => $xpAmount]);

            echo json_encode([
                'success' => true,
                'message' => "{$xpAmount} امتیاز XP به حساب شما اضافه شد (پاداش روزانهٔ تماشای ویدیو؛ ۲۴ ساعت دیگر دوباره می‌توانید دریافت کنید)."
            ]);
        } catch (\Throwable $e) {
            $this->logger->error('adtube.claim_boost.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'خطا در ثبت پاداش.']);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // FIX-POP: پاپ‌آپ‌های بوست هدیه — معماری «برگه/تمبر» (تصمیم ۱-A مالک)
    // start جلسهٔ pending می‌سازد (Cache، بدون جدول جدید)؛ پاداش فقط با postback
    // امضاشدهٔ S2S همان جلسه در s2sWebhook ثبت می‌شود (XP per-section + بوست صف؛
    // بدون هیچ پول). مسیر قدیمی «accept مبتنی بر اثبات AdTube» حذف شد — وابستگی
    // چرخه‌ای و تعارضش با ممنوعیت تکرار مطلق FIX-YT-2 از بین رفت.
    // ═════════════════════════════════════════════════════════════════════════

    // FIX-X117: فهرست ناحیه‌ها به helpers/functions.php منتقل شد (boost_areas()) تا
    // مصرف‌کننده‌های بوست (تیکت/صف‌های ادمین) و این کنترلر از یک منبع واحد بخوانند.

    /** مدت اعتبار بوستِ پذیرفته‌شده به تفکیک ناحیه (ثانیه) */
    private const BOOST_TTL = [
        'social'   => 86400,  // ۲۴ ساعت
        'kyc'      => 172800, // ۴۸ ساعت
        'ticket'   => 86400,
        'withdraw' => 86400,
        'dispute'  => 86400,
        'deposit'  => 86400,
        'vitrine'  => 86400,
        // FIX-POP (تصمیم ۳-A مالک): بوست شانس قرعه‌کشی تا دومین اجرای روزانهٔ ۰۳:۲۰
        // شانس (UpdateLotteryChanceScoresJob) فعال می‌ماند تا هر وقت کاربر ویدیو را
        // تماشا کند، بازهٔ بعدیِ بازوزنِ شانس را پوشش دهد.
        'lottery'  => 172800,
    ];

    /** آرامش پس از انصراف صریح (۷ روز) */
    private const BOOST_DISMISS_TTL = 604800;

    /** 🛡️ FIX-R3-F2: عمر چالشِ تک‌مصرفِ صفحهٔ تماشا (دقیقه) — پنجرهٔ معقول برای یک جلسهٔ تماشا */
    private const WATCH_CHALLENGE_TTL_MINUTES = 120;

    /**
     * 🛡️ FIX-S20-CLOSE-F1: سقف سخت سرعتِ ادعایی کلاینت — مقدار بالاتر از این از هیچ
     * پلیر واقعی نمی‌آید (= دستکاری) و رد می‌شود. مقادیر داخل سقف، در محاسبهٔ
     * پاداش به ۱.۰ کلمپ می‌شوند (سیاست max_speed=1.0) — یعنی سرعتِ ادعایی
     * «هرگز» پاداش را کوتاه‌تر نمی‌کند؛ فقط ادعای غیرممکن است که رد می‌شود.
     */
    private const ADTUBE_HARD_SPEED_CEILING = 2.5;

    /** 🛡️ FIX-S20-CLOSE-F1: عمر وضعیت انباشتهٔ heartbeat در کش — هم‌عمر چالش صفحهٔ تماشا (۱۲۰ دقیقه) */
    private const HEARTBEAT_STATE_TTL_SECONDS = 7200;

    /** خواندن و اعتبارسنجی ناحیهٔ بوست از بدنهٔ POST یا کوئری GET */
    private function boostAreaFromRequest(): string
    {
        $raw = trim(str_value($this->request->body('area') ?? $this->request->get('area') ?? ''));
        return in_array($raw, boost_areas(), true) ? $raw : ''; // FIX-X117: منبع واحد
    }

    private function boostStateKey(string $area, int $userId): string
    {
        return boost_state_key($area, $userId); // FIX-X117: منبع واحد
    }

    // ═════════════════════════════════════════════════════════════════════════
    // 🛡️ FIX-R3-F2 — کلید چالش تماشا (مسیر AdTube/یوتیوب)
    // (FIX-POP: مسیر قدیمی «اثبات AdTube برای پاپ‌آپ» حذف شد — پاپ‌آپ اکنون
    //  جلسهٔ تماشای خودش را با تأییدیهٔ S2S شبکه دارد؛ وابستگی چرخه‌ای و تعارض
    //  با ممنوعیت تکرار مطلق FIX-YT-2 از بین رفت.)
    // ═════════════════════════════════════════════════════════════════════════

    /** کلید چالش تک‌مصرفِ صفحهٔ تماشا — اتصال‌یافته به (execution, user) */
    private function watchChallengeKey(int $executionId, int $userId): string
    {
        return "adtube_watch_challenge:{$executionId}:{$userId}";
    }

    /** 🛡️ FIX-S20-CLOSE-F1: کلید وضعیت انباشتهٔ سیگنال پخش — اتصال‌یافته به (execution, user) */
    private function heartbeatStateKey(int $executionId, int $userId): string
    {
        return "adtube_heartbeat:{$executionId}:{$userId}";
    }

    /**
     * 🛡️ FIX-S20-CLOSE-F1: انباشتهٔ معتبرِ سیگنال پخش برای این اجرا — سقف مطلق دیواری
     * (زمان از اولین heartbeat) هم‌زمان با خواندن اعمال می‌شود؛ نبود/خرابی کش = ۰
     * (fail-closed: بدون سیگنال قابل‌اتکا، پاداشی نیست).
     */
    private function readHeartbeatPlayedSeconds(int $executionId, int $userId): int
    {
        try {
            $state = \Core\Cache::getInstance()->get($this->heartbeatStateKey($executionId, $userId));
        } catch (\Throwable $e) {
            $this->logger->error('adtube.heartbeat.read_failed', ['execution_id' => $executionId, 'user_id' => $userId, 'error' => $e->getMessage()]);
            return 0;
        }
        if (!is_array($state)) {
            return 0;
        }
        return AdsBudgetSettlementService::effectiveHeartbeatSeconds($state, time());
    }

    /** راستی‌آزمایی چالش صفحهٔ تماشا (timing-safe) — ورودی خالی/مفقود/نامنطبق = رد */
    private function verifyWatchChallenge(int $executionId, int $userId, string $challenge): bool
    {
        if ($executionId <= 0 || $userId <= 0 || $challenge === '') {
            return false;
        }
        try {
            $stored = \Core\Cache::getInstance()->get($this->watchChallengeKey($executionId, $userId));
        } catch (\Throwable $e) {
            $this->logger->error('adtube.watch_challenge.read_failed', ['execution_id' => $executionId, 'error' => $e->getMessage()]);
            return false; // fail-closed: بدون مهرِ قابل‌خواندن، تسویه ممنوع
        }
        return is_string($stored)
            && $stored !== ''
            && hash_equals($stored, $challenge);
    }

    /**
     * FIX-POP (تصمیم ۱-A مالک — معماری «برگه/تمبر»): کلید جلسهٔ تماشای پاپ‌آپ.
     * جلسه در Cache (بدون جدول جدید) با TTL تنظیم‌شدنی نگه‌داری می‌شود؛ مُهرِ پاداش فقط
     * توسط postback امضاشدهٔ S2S شبکه (ساب‌آیدی = توکن جلسه) زده می‌شود.
     */
    private function popupSessionKey(string $token): string
    {
        return 'popup_watch_session:' . $token;
    }

    /**
     * FIX-POP: انتخاب شبکهٔ قابل‌استفاده برای جلسهٔ تماشا — اولین شبکهٔ
     * «پیکربندی‌شده» (secret وب‌هوک دارد) که یا تگ وبِ ارائه‌شده دارد یا
     * حالت آزمایشی روشن است (شبیه‌سازِ برچسب‌دار). هیچ‌کدام؟ null = صادقانه رد.
     * @return array{network: string, mode: string}|null
     */
    private function pickUsableNetwork(): ?array
    {
        foreach ($this->rewardManager->getAvailableRewardAds() as $network => $ad) {
            if (!is_array($ad) || empty($ad['is_active'])) {
                continue;
            }
            if (!empty($ad['has_web_tag'])) {
                return ['network' => (string)$network, 'mode' => 'tag'];
            }
            if (!empty($ad['test_mode'])) {
                return ['network' => (string)$network, 'mode' => 'simulator'];
            }
        }
        return null;
    }

    /** GET /rewards/boost-popup/state — آیا پاپ‌آپ مجاز به نمایش است؟ */
    public function boostPopupState(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        $cache = \Core\Cache::getInstance();
        $state = $cache->get($this->boostStateKey($area, $userId));
        // FIX-POP: صداقت نمایش — وقتی هیچ شبکهٔ قابل‌استفاده‌ای نیست (نه تگ وب دارد،
        // نه حالت آزمایشی روشن است) پاپ‌آپ اصلاً باز نمی‌شود؛ وعدهٔ بی‌پشتوانه ممنوع.
        $canShow = !in_array($state, ['accepted', 'dismissed'], true) && $this->pickUsableNetwork() !== null;
        $this->jsonSuccess('', [
            'area'     => $area,
            'state'    => is_string($state) ? $state : '',
            'can_show' => $canShow,
        ]);
    }

    /**
     * POST /rewards/boost-popup/start — صدور «برگهٔ تماشا» (جلسهٔ pending).
     * FIX-POP (تصمیم ۱-A): خروجی فقط توکن/شبکه/مدت/حالت است؛ هیچ پاداشی این‌جا
     * صادر نمی‌شود. پاداش فقط با postback امضاشدهٔ S2S (وب‌هوک) ثبت می‌شود.
     */
    public function boostPopupStart(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('برای شروع تماشا ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        try {
            $picked = $this->pickUsableNetwork();
            if ($picked === null) {
                $this->jsonError('در حال حاضر هیچ شبکهٔ تبلیغاتی پیکربندی‌شده‌ای وجود ندارد؛ پاپ‌آپ پاداش‌دار موقتاً غیرفعال است.', [], 503);
                return;
            }

            // 🛡️ ضدتقلب: سقف شروع جلسه در ساعت برای هر کاربر+IP (الگوی FIX-YT-1 + FIX-R1-7)
            $cache = \Core\Cache::getInstance();
            $rlKey = 'popup_start_rl:' . $userId . ':' . substr(md5($this->request->ip() ?: '0.0.0.0'), 0, 8) . ':' . (int)floor(time() / 3600);
            $rlMax = max(3, int_value(setting('popup_max_starts_per_hour', 10)));
            // FIX-R2-ATOMIC (بازبین R2): increment اتمیک اول — الگوی قدیمی check-then-increment
            // دو درخواست هم‌زمان را هر دو از get رد می‌کرد و سقف را می‌شکست؛ اکنون شمارنده
            // همان claim است (increment مقدار پس از افزایش را برمی‌گرداند؛ درخواست n-اُم = n).
            $starts = (int)$cache->increment($rlKey, 1, 3600);
            if ($starts > $rlMax) {
                $this->jsonError('درخواست‌های شروع تماشا بیش از حد مجاز است؛ کمی بعد دوباره تلاش کنید.', [], 429);
                return;
            }

            $duration = max(5, min(120, int_value(setting('popup_ad_duration_seconds', 15))));
            $ttlMinutes = max(5, min(120, int_value(setting('popup_session_ttl_minutes', 30))));
            $token = bin2hex(random_bytes(20)); // ۴۰ کاراکتر hex — غیرقابل حدس
            $session = [
                'user_id'          => $userId,
                'area'             => $area,
                'network'          => $picked['network'],
                'mode'             => $picked['mode'],
                'started_at'       => time(),
                'duration_seconds' => $duration,
                'status'           => 'pending',
            ];
            // FIX-R2-TTL (بازبین R2): setSeconds — TTL جلسه ثانیه است؛ با set() دقیقه‌ای
            // ۳۰ دقیقه → ۳۰ ساعت می‌شد و برگه تا فردا قابل‌claim می‌ماند.
            $cache->setSeconds($this->popupSessionKey($token), $session, $ttlMinutes * 60);

            $this->logger->info('rewards.popup_session_started', [
                'user_id' => $userId, 'area' => $area, 'network' => $picked['network'],
                'mode' => $picked['mode'], 'duration' => $duration,
            ]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e; // پاسخ jsonSuccess/jsonError را نبلع (الگوی VitrineController::buy)
        } catch (\Throwable $e) {
            $this->logger->error('rewards.popup_session_start.failed', ['user_id' => $userId, 'area' => $area, 'error' => $e->getMessage()]);
            $this->jsonError('خطا در شروع جلسهٔ تماشا. لطفاً دوباره تلاش کنید.', [], 500);
            return;
        }
        $this->jsonSuccess('', [
            'area'             => $area,
            'session_token'    => $token,
            'network'          => $picked['network'],
            'mode'             => $picked['mode'],
            'duration_seconds' => $duration,
            // 🛡️ FIX-POP (تصمیم ۱-A — آماده‌سازی فعال‌سازی): در حالت tag، مارک‌آپ تگ وبِ
            // پیکربندی‌شدهٔ ادمین (تنظیم {network}_web_ad_tag) همراه پاسخ می‌رود تا پارشیال
            // آن را با جایگزینی __RV_SUB_ID__ → توکن جلسه تزریق کند؛ شبکه همان sub_id را
            // در postback S2S برمی‌گرداند و حلقهٔ «برگه → تأیید» بسته می‌شود.
            // محتوای ادمین-تأمین است (سطح اعتماد پیکربندی پنل) و فقط در mode=tag ارسال می‌شود.
            'tag_html'         => $picked['mode'] === 'tag'
                ? (string)setting($picked['network'] . '_web_ad_tag', '')
                : '',
        ]);
    }

    /**
     * 🛡️ FIX-POP — اعطای پاداش جلسهٔ تماشای پاپ‌آپ (بدون هیچ پرداخت پولی — تصمیم ۲-A).
     *  ① بوست صف همان ناحیه (صدرنشینی رکورد در صف بررسی ادمین همان بخش)
     *  ② XP انگیزشی per-section با کلید ایدمپوتنسی روزانه per-section (سقف ضدفرصت‌طلبی)
     * خروجی: خلاصهٔ متنی پاداش برای لاگ.
     */
    private function grantPopupSessionReward(int $userId, string $area, string $sessionToken): string
    {
        $cache = \Core\Cache::getInstance();
        $ttl = self::BOOST_TTL[$area] ?? 86400;
        // FIX-R2-TTL (بازبین R2): BOOST_TTL ثانیه است (86400=۲۴h) — با set() دقیقه‌ای
        // بوست صف ۶۰ روز و بوست لاتاری ۱۲۰ روز می‌شد (نابرابری شانس مزمن).
        $cache->setSeconds($this->boostStateKey($area, $userId), 'accepted', $ttl);

        $parts = ['boost=' . $area . ':' . $ttl . 's'];

        $xpAmount = float_value(setting('popup_xp_' . $area, 0));
        if ($xpAmount > 0) {
            try {
                $xp = \Core\Container::getInstance()->make(\App\Services\Gamification\XpService::class);
                $idem = 'popup_boost:' . $userId . ':' . $area . ':' . date('Y-m-d');
                $ok = $xp->award($userId, \App\Enums\ModuleContext::POPUP_BOOST, $xpAmount, $idem);
                $parts[] = $ok ? 'xp=' . $xpAmount : 'xp=skipped(daily_idempotency)';
            } catch (\Throwable $xpEx) {
                // XP انگیزشی است؛ شکستش هرگز نتیجهٔ postback معتبر را عوض نمی‌کند
                $this->logger->error('rewards.popup_session_xp_failed', ['user_id' => $userId, 'area' => $area, 'error' => $xpEx->getMessage()]);
                $parts[] = 'xp=failed';
            }
        } else {
            $parts[] = 'xp=0(setting)';
        }

        $this->logger->info('rewards.popup_session_reward_granted', [
            'user_id' => $userId, 'area' => $area, 'session' => substr($sessionToken, 0, 8) . '…',
        ]);
        return implode(', ', $parts);
    }

    /** POST /rewards/boost-popup/dismiss — ثبت انصراف صریح (۷ روز آرامش) */
    public function dismissBoostPopup(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        try {
            // FIX-R2-TTL (بازبین R2): 604800 ثانیه = ۷ روز؛ با set() دقیقه‌ای ۴۲۰ روز می‌شد.
            \Core\Cache::getInstance()->setSeconds($this->boostStateKey($area, $userId), 'dismissed', self::BOOST_DISMISS_TTL);
            $this->logger->info('rewards.boost_popup_dismissed', ['user_id' => $userId, 'area' => $area]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e; // FIX-X109: پاسخ jsonSuccess را نبلع (الگوی VitrineController::buy)
        } catch (\Throwable $e) {
            $this->logger->error('rewards.boost_popup_dismiss.failed', ['user_id' => $userId, 'area' => $area, 'error' => $e->getMessage()]);
            $this->jsonError('خطا در ثبت انصراف.', [], 500);
        }
        $this->jsonSuccess('انصراف شما ثبت شد.', ['area' => $area, 'state' => 'dismissed']);
    }
}
