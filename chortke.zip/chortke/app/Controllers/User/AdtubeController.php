<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\Ads;
use App\Models\AdTubeExecutionModel;
use App\Services\Ads\AdsBudgetSettlementService;
use App\Services\AdSystemManager;
use Core\Response;

/**
 * AdtubeController — Executor-only controller for AdTube (video watch) ads.
 *
 * NOTE: Advertiser management (create, pause, stats, list) is unified under /ads (AdsController).
 * This controller only handles the worker/executor side: discovering videos, watching, and submission.
 */
class AdtubeController extends BaseUserController
{
    private Ads $adModel;
    private AdTubeExecutionModel $executionModel;
    private \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlement;
    private \App\Adapters\AdVideoRewardManager $rewardManager;
    private \App\Contracts\WalletServiceInterface $walletService;
    /** X374 (راند ۹۳) — لجر KPI وب‌هوک S2S (best-effort؛ اختیاری برای سازگاری سازنده) */
    private ?\App\Models\S2sHookEvent $s2sHookEvents;
    /** X374 — برای طبقه‌بندی replay پیش از واریز (فقط خواندن کلید idempotency) */
    private ?\App\Models\Transaction $transactionModel;

    public function __construct(
        Ads $adModel,
        AdTubeExecutionModel $executionModel,
        \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlement,
        \App\Adapters\AdVideoRewardManager $rewardManager,
        // 🧹 DI-CLEANUP (2026-08-24): به‌جای container->make در بدنه‌ی متد.
        \App\Contracts\WalletServiceInterface $walletService,
        ?\App\Contracts\LoggerInterface $logger = null,
        // X374 (راند ۹۳): دامنهٔ KPI برای S2S — هر دو اختیاری و nullable هستند
        // تا فراخوانی‌های موجود سازنده (tests/پروب‌ها) بدون تغییر سالم بمانند.
        ?\App\Models\S2sHookEvent $s2sHookEvents = null,
        ?\App\Models\Transaction $transactionModel = null
    ) {
        $this->adModel = $adModel;
        $this->executionModel = $executionModel;
        $this->adsBudgetSettlement = $adsBudgetSettlement;
        $this->rewardManager = $rewardManager;
        $this->walletService = $walletService;
        $this->s2sHookEvents = $s2sHookEvents;
        $this->transactionModel = $transactionModel;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * لودر مشترک داده‌های هاب تک‌صفحه‌ای AdTube.
     * 🛡️ تکمیل معماری هاب: تاریخچه تماشا به‌عنوان پنل سوم همان هاب سرو می‌شود
     * (الگوی هاب‌های تبلیغات/رفرال)؛ روت قدیمی /adtube/history فقط alias است.
     *
     * @return array<string, mixed>
     */
    private function hubData(int $userId, int $historyPage = 1): array
    {
        // Active ads of type 'adtube' with remaining budget and slots
        $tasks = $this->adModel->getAvailableCustomTasks(
            $userId,
            ['platform' => 'youtube'],
            20, 0, 'adtube'
        );

        $stats = [
            'total_completed_today' => $this->executionModel->countCompletedToday($userId),
            'active_watching' => $this->executionModel->countActiveForUser($userId),
            'total_earned_today' => 0, // Calculated below if needed
        ];

        $rewardAds = $this->rewardManager->getAvailableRewardAds();

        // پنل «تاریخچه تماشا»
        $limit = 20;
        $history = $this->executionModel->getHistory($userId, $limit, (max(1, $historyPage) - 1) * $limit);

        return [
            'tasks' => $tasks,
            'stats' => $stats,
            'rewardAds' => $rewardAds,
            'trust_score' => 50, // Placeholder; could be fetched from ScoreService if needed
            'history' => $history,
            'historyPage' => max(1, $historyPage),
        ];
    }

    /**
     * داشبورد انجام‌دهنده — لیست ویدیوهای فعال AdTube
     */
    public function index(): void
    {
        $userId = (int)user_id();

        $this->view('user/adtube/index', array_merge($this->hubData($userId, $this->request->int('page', 1)), [
            'title' => 'AdTube — کسب درآمد از یوتیوب و تبلیغات جایزه‌دار',
        ]));
    }

    /**
     * شروع فرآیند اجرای یک ویدیو (AJAX)
     */
    public function start(): void
    {
        header('Content-Type: application/json');
        try {
            $body = $this->request->body();
            $adId = int_value($body['ad_id'] ?? $this->request->param('id'));
            $userId = (int)user_id();

            if (!$adId) {
                echo json_encode(['success' => false, 'message' => 'شناسه ویدیو نامعتبر است.']);
                return;
            }

            // Verify ad exists and is active
            $ad = $this->adModel->find($adId);
            if (!$ad || $ad->type !== 'adtube' || !in_array($ad->status, ['active', 'approved'], true)) {
                echo json_encode(['success' => false, 'message' => 'آگهی ویدیویی فعال یافت نشد.']);
                return;
            }

            // Check if user has too many active watches
            if ($this->executionModel->countActiveForUser($userId) >= 3) {
                echo json_encode(['success' => false, 'message' => 'حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.']);
                return;
            }

            $context = [
                'ip' => $this->request->ip(),
                'user_agent' => $this->request->userAgent(),
            ];

            $execution = $this->executionModel->findOrCreate($adId, $userId, $context);

            if (!$execution) {
                echo json_encode(['success' => false, 'message' => 'خطا در ایجاد رکورد اجرا.']);
                return;
            }

            // Transition to watching
            $this->executionModel->startWatching((int)$execution->id);

            echo json_encode([
                'success' => true,
                'execution_id' => $execution->id,
                'redirect_url' => url('/adtube/' . $execution->id . '/execute'),
            ]);
        } catch (\Exception $e) {
            $this->logger->error('adtube.start.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطا در شروع تماشای ویدیو.']);
        }
    }

    /**
     * صفحه پخش ویدیو و ثبت اثبات
     */
    public function showExecute(): void
    {
        $userId = (int)user_id();
        $execId = (int)$this->request->param('id');

        $execution = $this->executionModel->findByIdWithAd($execId, $userId);

        if (!$execution) {
            $this->session->setFlash('error', 'اجرای مورد نظر یافت نشد.');
            redirect(url('/adtube'));
        }

        // Only allow if status is pending or watching
        if (!in_array($execution->status, ['pending', 'watching'], true)) {
            $this->session->setFlash('warning', 'این ویدیو قبلاً ثبت شده است.');
            redirect(url('/adtube'));
        }

        $this->view('user/adtube/execute', [
            'title' => 'تماشای ویدیو و کسب درآمد',
            'execution' => $execution,
            'task' => $execution,
        ]);
    }

    /**
     * ثبت و ارسال نهایی نتایج (AJAX)
     */
    public function submit(): void
    {
        header('Content-Type: application/json');
        try {
            $execId = (int)$this->request->param('id');
            $userId = (int)user_id();
            $body = $this->request->body();

            $execution = $this->executionModel->findById($execId);
            if (!$execution || (int)$execution->executor_id !== $userId) {
                echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز.']);
                return;
            }

            if ($execution->status !== 'watching') {
                echo json_encode(['success' => false, 'message' => 'وضعیت اجرا نامعتبر است.']);
                return;
            }

            // Normalization: handle both watched_seconds and watch_time
            $watchTime = int_value($body['watch_time'] ?? $body['watched_seconds'] ?? 0);
            $speed = float_value($body['playback_speed'] ?? 1.0);
            if ($speed <= 0) { $speed = 1.0; }

            $requiredDuration = int_value($execution->watch_duration_seconds ?? $execution->required_duration ?? 30);
            if ($requiredDuration <= 0) { $requiredDuration = 30; }

            $progress = int_value($body['progress_percent'] ?? 0);
            if ($progress <= 0 && $watchTime > 0) {
                $progress = (int)min(100, round(($watchTime / $requiredDuration) * 100));
            }

            // 🛡️ Fraud Guard 1: Server-side elapsed time verification
            $startedAt = 0;
            if (!empty($execution->created_at)) {
                $startedAt = strtotime((string)$execution->created_at);
            } elseif (!empty($execution->updated_at)) {
                $startedAt = strtotime((string)$execution->updated_at);
            }

            if ($startedAt > 0) {
                $elapsedSeconds = time() - $startedAt;
                // Minimum time expected to watch: (watchTime / speed) - 2s tolerance for latency
                $minExpectedTime = max(2, (int)floor(($watchTime / max(1.0, $speed)) - 2));
                if ($elapsedSeconds < $minExpectedTime) {
                    $this->executionModel->markRejected($execId, "تقلب زمان مشاهده: زمان سپری‌شده سرور {$elapsedSeconds}s، ادعا {$watchTime}s");
                    echo json_encode(['success' => false, 'message' => 'زمان تماشای واقعی با زمان سپری‌شده بر روی سرور مطابقت ندارد.']);
                    return;
                }
            }

            // Minimum validation: at least 80% watched and reasonable speed
            if ($progress < 80) {
                $this->executionModel->markRejected($execId, 'تماشای ناقص: ' . $progress . '%');
                echo json_encode(['success' => false, 'message' => 'ویدیو باید حداقل ۸۰٪ تماشا شود (' . $progress . '٪).']);
                return;
            }

            if ($speed > 2.5) {
                $this->executionModel->markRejected($execId, 'سرعت پخش غیرعادی: ' . $speed . 'x');
                echo json_encode(['success' => false, 'message' => 'سرعت پخش غیرعادی تشخیص داده شد.']);
                return;
            }

            $finance = $this->adsBudgetSettlement;
            $settlement = $finance->settleAdTubeView($execId, $userId, $watchTime, $progress, $speed);

            echo json_encode([
                'success' => !empty($settlement['success']),
                'message' => $settlement['message'] ?? (!empty($settlement['success']) ? 'ویدیو با موفقیت ثبت و پاداش پرداخت شد.' : 'تسویه ویدیو انجام نشد.'),
                'execution_id' => $execId,
                'settlement' => $settlement,
            ], JSON_UNESCAPED_UNICODE);
        } catch (\Exception $e) {
            $this->logger->error('adtube.submit.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطای سیستمی در ثبت نهایی.']);
        }
    }

    /**
     * تاریخچه فعالیت کاربر در AdTube
     */
    public function history(): void
    {
        // 🛡️ هاب تک‌صفحه‌ای: alias همان هاب — پنل تاریخچه باز می‌شود
        $userId = (int)user_id();
        $page = max(1, $this->request->int('page', 1));

        $this->view('user/adtube/history', array_merge($this->hubData($userId, $page), [
            'title' => 'تاریخچه کسب درآمد AdTube',
        ]));
    }

    /**
     * 🛡️ وب‌هوک امن سرور به سرور (S2S Callback Verification)
     * دریافت تاییدیه تماشای ویدیو از سرورهای تپسل و ادموب و واریز پاداش
     */
    public function s2sWebhook(): void
    {
        // FIX-X342 (راند ۸۴): همهٔ پاسخ‌ها باید از مسیر Response::json() بروند —
        // الگوی قبلی «http_response_code(X) + echo» توسط toResponse()ی میدل‌ور
        // بیرونی در Response تازه با ۲۰۰ پیچیده می‌شد و وضعیت واقعی (۴۰۰/۴۰۱/۴۰۴/۵۰۰)
        // هرگز به شبکهٔ تبلیغاتی نمی‌رسید → منطق retry شبکه‌ها کاملاً کور می‌شد.
        // Response::json → send() → HttpResponseException → روتر با وضعیت صحیح می‌فرستد.
        $network = (string)$this->request->param('network');
        $payload = $this->request->body();
        // FIX-X352 راند ۸۷ — امضای HMAC باید روی بایت‌های خام دریافتی محاسبه شود
        // نه بازسازی json_encode آرایهٔ پارس‌شده (اسنپ‌شات کش‌شدهٔ constructor).
        $rawBody = $this->request->rawBody();
        // Finding #7 Fix: Enforce Webhook signature strictly from HTTP headers (never Query String)
        $receivedSignature = str_value($this->request->header('X-Webhook-Signature', $this->request->header('X-AdTube-Signature', '')));
        $timestamp = int_value($this->request->header('X-Webhook-Timestamp', $this->request->header('X-AdTube-Timestamp', 0)));

        // FIX-X332 راند ۸۴: بررسی تازگی حالا fail-closed است — شرط قبلی ($timestamp > 0 && …)
        // غیبت/خرابی هدر Timestamp را از چک replay معاف می‌کرد؛ اکنون هدر مفقود/ناخوانا هم رد می‌شود.
        if ($timestamp <= 0) {
            // X374 (راند ۹۳): لجر KPI — هر خروجی نهایی یک ردیف best-effort دارد
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_TIMESTAMP, 400, $payload);
            (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'هدر زمان‌بندی وب‌هوک مفقود یا نامعتبر است (Timestamp Required)']);
            return;
        }
        // Finding #6 Fix: Freshness verification (max 300s window)
        if (abs(time() - $timestamp) > 300) {
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_TIMESTAMP, 400, $payload);
            (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'درخواست وب‌هوک منقضی شده است (Timestamp Expired)']);
            return;
        }

        try {
            $adapter = $this->rewardManager->getAdapter($network);
            if (!$adapter->verifyS2SHmac($rawBody, $receivedSignature)) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_BAD_SIGNATURE, 401, $payload);
                (new Response())->setStatusCode(401)->json(['success' => false, 'message' => 'امضای وب‌هوک نامعتبر است (HMAC Mismatch)']);
                return;
            }

            $userId = int_value($payload['user_id'] ?? $payload['sub_id'] ?? 0);
            if ($userId <= 0) {
                $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_INVALID_USER, 400, $payload);
                (new Response())->setStatusCode(400)->json(['success' => false, 'message' => 'شناسه کاربری نامعتبر است']);
                return;
            }

            $payoutMoney = $adapter->calculateUserPayout();
            $walletService = $this->walletService;

            // FIX-X333 راند ۸۴: کلید idempotency باید بر پایهٔ شناسهٔ تراکنشِ خودِ شبکه باشد نه هشِ کل payload؛
            // هشِ کل payload با هر فیلد متغیر (شمارندهٔ تلاش، sent_at، nonce) در retry عوض می‌شد → کلید جدید
            // → اعتبارِ دوباره (double credit). اولویت: transaction_id ← txid ← event_id (غیرخالی، ≤ ۲۵۶ کاراکتر).
            // بدون هیچ‌کدام: fallback به همان هشِ payload (رفتار قبلی) — طول کلید حداکثر ~۷۹ و داخل varchar(128).
            $txid = '';
            foreach (['transaction_id', 'txid', 'event_id'] as $txField) {
                $candidate = trim(str_value($payload[$txField] ?? ''));
                if ($candidate !== '' && strlen($candidate) <= 256) {
                    $txid = $candidate;
                    break;
                }
            }
            $idempotencyKey = $txid !== ''
                ? 's2s_' . $network . '_' . hash('sha256', $network . '|' . $txid)
                : "s2s_{$network}_" . hash('sha256', (string)json_encode($payload));

            // X374 (راند ۹۳): طبقه‌بندی replay پیش از واریز — فقط برای مشاهده‌پذیری KPI.
            // اگر تراکنشی با همین کلید idempotency از قبل باشد، این فراخوانی واریزِ تازه نیست
            // و ردیف لجر باید «replay» ثبت شود تا نرخ پذیرش آلوده نشود. شکستِ این پروب
            // هرگز جریان وب‌هوک را عوض نمی‌کند (رفتار پیش‌فرض: credited).
            $isReplay = false;
            try {
                $isReplay = $this->transactionModel !== null
                    && $this->transactionModel->findByIdempotencyKey($idempotencyKey, $userId) !== null;
            } catch (\Throwable $probeEx) {
                $this->logger->warning('s2s_hook_event.replay_probe_failed', ['network' => $network, 'error' => $probeEx->getMessage()]);
            }

            // واریز اتمیک تحت قفل FOR UPDATE
            $walletService->depositInTransaction($userId, $payoutMoney->getAmount(), strtolower($payoutMoney->getCurrency()), [
                'type' => 'rewarded_video_ad',
                'network' => $network,
                'description' => "پاداش تماشای ویدیوی تبلیغاتی {$network}",
                'idempotency_key' => $idempotencyKey
            ]);

            // X374: ردیف لجر KPI — txid_hash همان بخشِ هشِ کلید idempotency است (بدون txid خام)
            $this->recordS2sHookEvent(
                $network,
                $isReplay ? \App\Models\S2sHookEvent::OUTCOME_REPLAY : \App\Models\S2sHookEvent::OUTCOME_CREDITED,
                null,
                200,
                $payload,
                [
                    'user_id' => $userId,
                    'txid_hash' => substr($idempotencyKey, strlen('s2s_' . $network . '_')),
                    // پاداش فقط روی ردیف‌های credited ثبت می‌شود تا جمعِ KPI دوبار‌شماری نکند
                    'payout_amount' => $isReplay ? null : (string)$payoutMoney->getAmount(),
                    'currency' => strtolower($payoutMoney->getCurrency()),
                ]
            );

            $this->logger->info('s2s_webhook.reward_processed', ['user_id' => $userId, 'network' => $network, 'payout' => $payoutMoney->getAmount()]);
            (new Response())->json(['success' => true, 'message' => 'پاداش با موفقیت تایید و واریز شد']);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            // FIX-X342 راند ۸۴: HttpResponseException جریانِ کنترل فریم‌ورک است (Response::json
            // با send() آن را پرتاب می‌کند) — نباید توسط catchهای پایین بلعیده و ۵۰۰ شود.
            throw $e;
        } catch (\InvalidArgumentException $e) {
            // FIX-X336 راند ۸۴: شبکهٔ ناشناخته (تایپو/اسم غلط مثل adtube) ۴۰۴ است نه ۵۰۰ —
            // قبلاً InvalidArgumentExceptionِ AdVideoRewardManager::getAdapter در catch(\Throwable)
            // می‌افتاد و «خطای سرور» + لاگ error-لول تولید می‌کرد؛ اکنون پاسخ ۴۰۴ با لاگ warning.
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_UNKNOWN_NETWORK, 404, $payload);
            $this->logger->warning('s2s_webhook.unknown_network', ['network' => $network, 'error' => $e->getMessage()]);
            (new Response())->setStatusCode(404)->json(['success' => false, 'message' => 'شبکهٔ تبلیغاتی شناخته نشده است']);
        } catch (\Throwable $e) {
            $this->recordS2sHookEvent($network, \App\Models\S2sHookEvent::OUTCOME_REJECTED, \App\Models\S2sHookEvent::REJECT_SERVER_ERROR, 500, $payload);
            $this->logger->error('s2s_webhook.failed', ['network' => $network, 'error' => $e->getMessage()]);
            (new Response())->setStatusCode(500)->json(['success' => false, 'message' => 'خطای سرور در پردازش وب‌هوک']);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // X374 (راند ۹۳) — لجر KPI وب‌هوک S2S
    // هر خروجی نهایی (۲۰۰/۴۰۰/۴۰۱/۴۰۴/۵۰۰) یک ردیف best-effort در
    // s2s_hook_events می‌گیرد؛ این متد «هرگز» استثنا نمی‌دهد و هرگز
    // وضعیت/بدنهٔ وب‌هوک را عوض نمی‌کند — شکست فقط logger->error است.
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * ثبت یک رویداد KPI برای وب‌هوک S2S (best-effort).
     *
     * @param array<string, mixed> $payload بدنهٔ خام درخواست (برای ادعای user_id در ردیف‌های rejected)
     * 🛡️ FIX-PS-C2: payout_amount در مسیر replay واقعاً null است.
     * @param array{user_id?: int, txid_hash?: string, payout_amount?: string|null, currency?: string} $extra داده‌های مسیرِ موفق
     */
    private function recordS2sHookEvent(string $network, string $outcome, ?string $rejectReason, int $httpStatus, array $payload, array $extra = []): void
    {
        try {
            if ($this->s2sHookEvents === null) {
                // سازنده اختیاری است؛ در فراخوانی‌های قدیمی (بدون تزریق) خودمان resolve می‌کنیم
                $this->s2sHookEvents = \Core\Container::getInstance()->make(\App\Models\S2sHookEvent::class);
            }

            $claimedUserId = int_value($payload['user_id'] ?? $payload['sub_id'] ?? 0);

            $this->s2sHookEvents->record([
                'network' => $network,
                'outcome' => $outcome,
                'reject_reason' => $rejectReason,
                'user_id' => $extra['user_id'] ?? ($claimedUserId > 0 ? $claimedUserId : null),
                'txid_hash' => $extra['txid_hash'] ?? null,
                'payout_amount' => $extra['payout_amount'] ?? null,
                'currency' => $extra['currency'] ?? null,
                'http_status' => $httpStatus,
                'ip' => $this->request->ip(),
            ]);
        } catch (\Throwable $e) {
            // best-effort: شکستِ مشاهده‌پذیری نباید هیچ‌گاه پاسخ وب‌هوک را تغییر دهد
            $this->logger->error('s2s_hook_event.write_failed', ['network' => $network, 'outcome' => $outcome, 'error' => $e->getMessage()]);
        }
    }

    /**
     * فعال‌سازی شتاب‌دهنده رشد سطح (XP Boost) پس از تماشای ویدیوی تبلیغاتی در داشبورد
     */
    public function claimBoost(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $userId = (int)$this->userId();
        if (!$userId) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'برای دریافت پاداش ابتدا وارد شوید.']);
            return;
        }

        try {
            // 🛡️ Fraud Guard: Verify user has completed at least one AdTube watch execution today
            $completedCount = $this->executionModel->countCompletedToday($userId);
            if ($completedCount <= 0) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'برای فعال‌سازی شتاب‌دهنده، ابتدا باید حداقل ۱ ویدیوی تبلیغاتی AdTube را به طور کامل تماشا کنید.']);
                return;
            }

            $cache = \Core\Cache::getInstance();
            $cooldownKey = "xp_boost_claimed:{$userId}";
            if ($cache->get($cooldownKey)) {
                http_response_code(429);
                echo json_encode(['success' => false, 'message' => 'شما قبلاً امروز پاداش ویدیوی شتاب‌دهنده را دریافت کرده‌اید. هر ۲۴ ساعت یکبار امکان فعال‌سازی وجود دارد.']);
                return;
            }

            $activeKey = "xp_boost_active:{$userId}";
            $cache->set($cooldownKey, true, 86400); // 24h cooldown
            $cache->set($activeKey, true, 86400);   // 24h active boost

            $xpGrowthRate = int_value(config('video_rewards.xp_growth_rate', setting('xp_growth_rate', 50)));
            $this->logger->info('user.xp_boost_activated', ['user_id' => $userId, 'rate' => $xpGrowthRate]);

            echo json_encode([
                'success' => true,
                'message' => "شتاب‌دهنده {$xpGrowthRate}٪ رشد سطح کاربری با موفقیت تا ۲۴ ساعت آینده برای حساب شما فعال شد."
            ]);
        } catch (\Throwable $e) {
            $this->logger->error('adtube.claim_boost.failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'خطا در فعال‌سازی شتاب‌دهنده.']);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // FIX-X109: پاپ‌آپ‌های بوست هدیه (تماشای ویدیو → ثبتِ واقعی سرور)
    // الگوی claimBoost بالا: کلید Cache با TTL — صفر تغییر اسکیما.
    // پیش از X109 متن مودال‌ها ادعای «بررسی S2S» داشتند بدون هیچ POST واقعی؛
    // اکنون accept/dismiss واقعاً ثبت می‌شوند و state سرور تعیین‌کنندهٔ نمایش است.
    // ═════════════════════════════════════════════════════════════════════════

    // FIX-X117: فهرست ناحیه‌ها به helpers/functions.php منتقل شد (boost_areas()) تا
    // مصرف‌کننده‌های بوست (تیکت/صف‌های ادمین) و این کنترلر از یک منبع واحد بخوانند.

    /** مدت اعتبار بوستِ پذیرفته‌شده به تفکیک ناحیه (ثانیه) */
    private const BOOST_TTL = [
        'social'   => 86400,  // ۲۴ ساعت
        'kyc'      => 172800, // ۴۸ ساعت
        'ticket'   => 86400,
        'withdraw' => 86400,
        'dispute'  => 86400,
        'deposit'  => 86400,
        'vitrine'  => 86400,
    ];

    /** آرامش پس از انصراف صریح (۷ روز) */
    private const BOOST_DISMISS_TTL = 604800;

    /** خواندن و اعتبارسنجی ناحیهٔ بوست از بدنهٔ POST یا کوئری GET */
    private function boostAreaFromRequest(): string
    {
        $raw = trim(str_value($this->request->body('area') ?? $this->request->get('area') ?? ''));
        return in_array($raw, boost_areas(), true) ? $raw : ''; // FIX-X117: منبع واحد
    }

    private function boostStateKey(string $area, int $userId): string
    {
        return boost_state_key($area, $userId); // FIX-X117: منبع واحد
    }

    /** GET /rewards/boost-popup/state — آیا پاپ‌آپ مجاز به نمایش است؟ */
    public function boostPopupState(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        $cache = \Core\Cache::getInstance();
        $state = $cache->get($this->boostStateKey($area, $userId));
        $this->jsonSuccess('', [
            'area'     => $area,
            'state'    => is_string($state) ? $state : '',
            'can_show' => !in_array($state, ['accepted', 'dismissed'], true),
        ]);
    }

    /** POST /rewards/boost-popup/accept — ثبت فعال‌سازی بوست پس از پایان تماشای ویدیو */
    public function acceptBoostPopup(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('برای دریافت پاداش ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        try {
            $cache = \Core\Cache::getInstance();
            $ttl = self::BOOST_TTL[$area] ?? 86400;
            $cache->set($this->boostStateKey($area, $userId), 'accepted', $ttl);
            $this->logger->info('rewards.boost_popup_accepted', ['user_id' => $userId, 'area' => $area, 'ttl' => $ttl]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e; // FIX-X109: پاسخ jsonSuccess را نبلع (الگوی VitrineController::buy)
        } catch (\Throwable $e) {
            $this->logger->error('rewards.boost_popup_accept.failed', ['user_id' => $userId, 'area' => $area, 'error' => $e->getMessage()]);
            $this->jsonError('خطا در ثبت بوست. لطفاً دوباره تلاش کنید.', [], 500);
        }
        $this->jsonSuccess('بوست شما با موفقیت ثبت شد.', ['area' => $area, 'state' => 'accepted']);
    }

    /** POST /rewards/boost-popup/dismiss — ثبت انصراف صریح (۷ روز آرامش) */
    public function dismissBoostPopup(): void
    {
        $userId = (int) $this->userId();
        if (!$userId) {
            $this->jsonError('ابتدا وارد شوید.', [], 401);
            return;
        }
        $area = $this->boostAreaFromRequest();
        if ($area === '') {
            $this->jsonError('ناحیهٔ نامعتبر است.', [], 422);
            return;
        }
        try {
            \Core\Cache::getInstance()->set($this->boostStateKey($area, $userId), 'dismissed', self::BOOST_DISMISS_TTL);
            $this->logger->info('rewards.boost_popup_dismissed', ['user_id' => $userId, 'area' => $area]);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e; // FIX-X109: پاسخ jsonSuccess را نبلع (الگوی VitrineController::buy)
        } catch (\Throwable $e) {
            $this->logger->error('rewards.boost_popup_dismiss.failed', ['user_id' => $userId, 'area' => $area, 'error' => $e->getMessage()]);
            $this->jsonError('خطا در ثبت انصراف.', [], 500);
        }
        $this->jsonSuccess('انصراف شما ثبت شد.', ['area' => $area, 'state' => 'dismissed']);
    }
}
