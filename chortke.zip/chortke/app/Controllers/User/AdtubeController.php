<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\Ads;
use App\Models\AdTubeExecutionModel;
use App\Services\Ads\AdsBudgetSettlementService;
use App\Services\AdSystemManager;

/**
 * AdtubeController — Executor-only controller for AdTube (video watch) ads.
 *
 * NOTE: Advertiser management (create, pause, stats, list) is unified under /ads (AdsController).
 * This controller only handles the worker/executor side: discovering videos, watching, and submission.
 */
class AdtubeController extends BaseUserController
{
    private Ads $adModel;
    private AdTubeExecutionModel $executionModel;
    private AdSystemManager $adManager;
    private \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlement;
    private \App\Adapters\AdVideoRewardManager $rewardManager;

    public function __construct(
        Ads $adModel,
        AdTubeExecutionModel $executionModel,
        AdSystemManager $adManager,
        \App\Services\Ads\AdsBudgetSettlementService $adsBudgetSettlement,
        \App\Adapters\AdVideoRewardManager $rewardManager,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        $this->adModel = $adModel;
        $this->executionModel = $executionModel;
        $this->adManager = $adManager;
        $this->adsBudgetSettlement = $adsBudgetSettlement;
        $this->rewardManager = $rewardManager;
        parent::__construct(null, null, null, null, $logger);
    }

    /**
     * داشبورد انجام‌دهنده — لیست ویدیوهای فعال AdTube
     */
    public function index(): void
    {
        $userId = (int)user_id();

        // Active ads of type 'adtube' with remaining budget and slots
        $tasks = $this->adModel->getAvailableCustomTasks(
            $userId,
            ['platform' => 'youtube'],
            20, 0, 'adtube'
        );

        $stats = [
            'total_completed_today' => $this->executionModel->countCompletedToday($userId),
            'active_watching' => $this->executionModel->countActiveForUser($userId),
            'total_earned_today' => 0, // Calculated below if needed
        ];

        $rewardAds = $this->rewardManager->getAvailableRewardAds();

        $this->view('user/adtube/index', [
            'title' => 'AdTube — کسب درآمد از یوتیوب و تبلیغات جایزه‌دار',
            'tasks' => $tasks,
            'stats' => $stats,
            'rewardAds' => $rewardAds,
            'trust_score' => 50, // Placeholder; could be fetched from ScoreService if needed
        ]);
    }

    public function income(): void
    {
        $this->index();
    }

    /**
     * شروع فرآیند اجرای یک ویدیو (AJAX)
     */
    public function start(): void
    {
        header('Content-Type: application/json');
        try {
            $body = $this->request->body();
            $adId = (int)($body['ad_id'] ?? $this->request->param('id'));
            $userId = (int)user_id();

            if (!$adId) {
                echo json_encode(['success' => false, 'message' => 'شناسه ویدیو نامعتبر است.']);
                return;
            }

            // Verify ad exists and is active
            $ad = $this->adModel->find($adId);
            if (!$ad || $ad->type !== 'adtube' || !in_array($ad->status, ['active', 'approved'], true)) {
                echo json_encode(['success' => false, 'message' => 'آگهی ویدیویی فعال یافت نشد.']);
                return;
            }

            // Check if user has too many active watches
            if ($this->executionModel->countActiveForUser($userId) >= 3) {
                echo json_encode(['success' => false, 'message' => 'حداکثر ۳ ویدیو همزمان می‌توانید تماشا کنید.']);
                return;
            }

            $context = [
                'ip' => $this->request->ip(),
                'user_agent' => $this->request->userAgent(),
            ];

            $execution = $this->executionModel->findOrCreate($adId, $userId, $context);

            if (!$execution) {
                echo json_encode(['success' => false, 'message' => 'خطا در ایجاد رکورد اجرا.']);
                return;
            }

            // Transition to watching
            $this->executionModel->startWatching((int)$execution->id);

            echo json_encode([
                'success' => true,
                'execution_id' => $execution->id,
                'redirect_url' => url('/adtube/' . $execution->id . '/execute'),
            ]);
        } catch (\Exception $e) {
            $this->logger?->error('adtube.start.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطا در شروع تماشای ویدیو.']);
        }
    }

    /**
     * صفحه پخش ویدیو و ثبت اثبات
     */
    public function showExecute(): void
    {
        $userId = (int)user_id();
        $execId = (int)$this->request->param('id');

        $execution = $this->executionModel->findByIdWithAd($execId, $userId);

        if (!$execution) {
            $this->session->setFlash('error', 'اجرای مورد نظر یافت نشد.');
            redirect(url('/adtube'));
            return;
        }

        // Only allow if status is pending or watching
        if (!in_array($execution->status, ['pending', 'watching'], true)) {
            $this->session->setFlash('warning', 'این ویدیو قبلاً ثبت شده است.');
            redirect(url('/adtube'));
            return;
        }

        $this->view('user/adtube/execute', [
            'title' => 'تماشای ویدیو و کسب درآمد',
            'execution' => $execution,
            'task' => $execution,
        ]);
    }

    /**
     * ثبت و ارسال نهایی نتایج (AJAX)
     */
    public function submit(): void
    {
        header('Content-Type: application/json');
        try {
            $execId = (int)$this->request->param('id');
            $userId = (int)user_id();
            $body = $this->request->body();

            $execution = $this->executionModel->findById($execId);
            if (!$execution || (int)$execution->executor_id !== $userId) {
                echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز.']);
                return;
            }

            if ($execution->status !== 'watching') {
                echo json_encode(['success' => false, 'message' => 'وضعیت اجرا نامعتبر است.']);
                return;
            }

            $watchTime = (int)($body['watch_time'] ?? 0);
            $progress = (int)($body['progress_percent'] ?? 0);
            $speed = (float)($body['playback_speed'] ?? 1.0);

            // Minimum validation: at least 80% watched and reasonable speed
            if ($progress < 80) {
                $this->executionModel->markRejected($execId, 'تماشای ناقص: ' . $progress . '%');
                echo json_encode(['success' => false, 'message' => 'ویدیو باید حداقل ۸۰٪ تماشا شود (' . $progress . '٪).']);
                return;
            }

            if ($speed > 2.5) {
                $this->executionModel->markRejected($execId, 'سرعت پخش غیرعادی: ' . $speed . 'x');
                echo json_encode(['success' => false, 'message' => 'سرعت پخش غیرعادی تشخیص داده شد.']);
                return;
            }

            $finance = $this->adsBudgetSettlement;
            $settlement = $finance->settleAdTubeView($execId, $userId, $watchTime, $progress, $speed);

            echo json_encode([
                'success' => !empty($settlement['success']),
                'message' => $settlement['message'] ?? (!empty($settlement['success']) ? 'ویدیو با موفقیت ثبت و پاداش پرداخت شد.' : 'تسویه ویدیو انجام نشد.'),
                'execution_id' => $execId,
                'settlement' => $settlement,
            ], JSON_UNESCAPED_UNICODE);
        } catch (\Exception $e) {
            $this->logger?->error('adtube.submit.failed', ['err' => $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'خطای سیستمی در ثبت نهایی.']);
        }
    }

    /**
     * تاریخچه فعالیت کاربر در AdTube
     */
    public function history(): void
    {
        $userId = (int)user_id();
        $page = max(1, (int)($this->request->get('page') ?? 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $history = $this->executionModel->getHistory($userId, $limit, $offset);

        $this->view('user/adtube/history', [
            'title' => 'تاریخچه کسب درآمد AdTube',
            'history' => $history,
            'page' => $page,
        ]);
    }

    /**
     * 🛡️ وب‌هوک امن سرور به سرور (S2S Callback Verification)
     * دریافت تاییدیه تماشای ویدیو از سرورهای تپسل و ادموب و واریز پاداش
     */
    public function s2sWebhook(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $network = (string)$this->request->param('network');
        $payload = $this->request->body();
        $receivedSignature = (string)$this->request->header('X-Webhook-Signature', $this->request->get('sig', ''));

        try {
            $adapter = $this->rewardManager->getAdapter($network);
            if (!$adapter->verifyS2SHmac($payload, $receivedSignature)) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'امضای وب‌هوک نامعتبر است (HMAC Mismatch)']);
                return;
            }

            $userId = (int)($payload['user_id'] ?? $payload['sub_id'] ?? 0);
            if ($userId <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'شناسه کاربری نامعتبر است']);
                return;
            }

            $payoutMoney = $adapter->calculateUserPayout();
            $walletService = $this->container->make(\App\Contracts\WalletServiceInterface::class);

            // واریز اتمیک تحت قفل FOR UPDATE
            $walletService->depositInTransaction($userId, $payoutMoney->getAmount(), strtolower($payoutMoney->getCurrency()), [
                'type' => 'rewarded_video_ad',
                'network' => $network,
                'description' => "پاداش تماشای ویدیوی تبلیغاتی {$network}",
                'idempotency_key' => "s2s_{$network}_" . hash('sha256', json_encode($payload))
            ]);

            $this->logger?->info('s2s_webhook.reward_processed', ['user_id' => $userId, 'network' => $network, 'payout' => $payoutMoney->getAmount()]);
            echo json_encode(['success' => true, 'message' => 'پاداش با موفقیت تایید و واریز شد']);
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->logger?->error('s2s_webhook.failed', ['network' => $network, 'error' => $e->getMessage()]);
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'خطای سرور در پردازش وب‌هوک']);
        }
    }
}
