<?php

namespace App\Controllers\User;

use App\Services\SocialTask\SocialTaskService;
use App\Services\Interaction\RatingService;
use App\Validators\Requests\CreateSocialTaskRequest;
use App\Validators\Requests\ExecuteSocialTaskRequest;
use App\Controllers\User\BaseUserController;

class SocialTaskController extends BaseUserController
{
    private SocialTaskService $socialTaskService;

    /** 🛡️ FIX-SOCRATE-VOTE-EXEC-01: سرویس امتیاز برای فرم رأی داخل صفحهٔ اجرا (lazy از Container — الگوی SeoController) */
    private ?RatingService $ratingService = null;

    public function __construct(SocialTaskService $socialTaskService, ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->socialTaskService = $socialTaskService;
    }

    private function ratingService(): RatingService
    {
        return $this->ratingService ??= app(RatingService::class);
    }

    /** @return array<string, string> */
    private function platforms(): array
    {
        return ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'twitter' => 'توییتر'];
    }

    /** @return array<string, string> */
    private function taskTypes(): array
    {
        return ['follow' => 'فالو', 'like' => 'لایک', 'comment' => 'کامنت', 'share' => 'اشتراک‌گذاری'];
    }

    public function index(): void
    {
        $filters = [
            'platform' => $this->request->str('platform'),
            'task_type' => $this->request->str('task_type'),
            'sort' => $this->request->str('sort', 'newest'),
            'search' => str_value($this->request->get('q') ?: $this->request->get('search', '')),
            'is_mobile' => $this->request->get('mobile') ? 1 : 0,
        ];
        $result = $this->socialTaskService->getTasksForExecutor((int)$this->userId(), $filters, 24);
        $this->view('user/social-tasks/index', [
            'title' => 'تسک‌های اجتماعی',
            'tasks' => $result['tasks'] ?? [],
            'trust_score' => $result['trust_score'] ?? 50,
            'filters' => $filters,
            'platforms' => $this->platforms(),
            'task_types' => $this->taskTypes(),
        ]);
    }

    public function executorDashboard(): void
    {
        $this->view('user/social-tasks/dashboard', [
            'title' => 'داشبورد تسک‌های اجتماعی',
            'stats' => $this->socialTaskService->getExecutorStats((int)$this->userId()),
            'trust_score' => 50,
        ]);
    }

    public function history(): void
    {
        $perPage = 20;
        $page = max(1, $this->request->int('page', 1));
        // R25-C: total واقعی از COUNT (قبلاً ویو با هیوریستیک count===20 «بعدی» را حدس می‌زد)
        $total      = $this->socialTaskService->countExecutorHistory((int)$this->userId());
        $totalPages = max(1, (int)ceil($total / $perPage));
        $history = $this->socialTaskService->getExecutorHistory((int)$this->userId(), $perPage, ($page - 1) * $perPage);
        $this->view('user/social-tasks/history', [
            'title' => 'تاریخچه تسک‌ها',
            'history' => $history,
            'stats' => $this->socialTaskService->getExecutorStats((int)$this->userId()),
            'trust_score' => 50,
            'page' => $page,
            'total' => $total,
            'totalPages' => $totalPages,
        ]);
    }

    public function create(): void
    {
        $request = new CreateSocialTaskRequest($this->request->all());
        if (!$request->validate()) {
            $this->response->json(['success' => false, 'errors' => $request->errors()], 422);
            return;
        }
        $result = $this->socialTaskService->createTask((int)$this->userId(), $request->safeValidated()); // FIX-X16
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    public function start(): void
    {
        $adId = int_value(
            $this->request->param('id')
            ?? $this->request->input('ad_id')
            ?? $this->request->input('task_id')
            ?? 0
        );
        $result = $this->socialTaskService->startExecution((int)$this->userId(), $adId, [
            'ip' => $this->request->ip(),
            'user_agent' => $this->request->userAgent(),
        ]);
        if (!empty($result['success']) && !empty($result['execution_id'])) {
            $result['redirect_url'] = url('/social-tasks/' . (int)$result['execution_id'] . '/execute');
            $result['message'] = $result['message'] ?? 'تسک اجتماعی شروع شد.';
        }
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    public function showExecute(): void
    {
        $executionId = (int)$this->request->param('id');
        $execution = $this->socialTaskService->getExecutionWithAd($executionId, (int)$this->userId());
        if (!$execution || (int)$execution->executor_id !== (int)$this->userId()) {
            $this->session->setFlash('error', 'اجرای تسک یافت نشد.');
            $this->response->redirect(url('/social-tasks'));
            return;
        }

        // 🛡️ FIX-SOCRATE-VOTE-EXEC-01 (قرینهٔ SeoController::showExecution):
        // وضعیت بازخورد مجری برای فرم رأی داخل خود صفحهٔ اجرا — رأی ثبت‌شدهٔ
        // خودش + خلاصهٔ رأی مجریانِ همین کمپین (یک batch). فرم در ویو فقط برای
        // اجرای approved رندر می‌شود؛ ثبت از همان مسیر گاردشدهٔ سرویس است.
        $adId = (int)$execution->ad_id;
        $summary = $this->ratingService()->getRatingsSummary('social_task', [$adId]);
        $this->view('user/social-tasks/execute', [
            'title' => 'انجام تسک',
            'execution' => $execution,
            'task' => $execution,
            'feedback' => [
                'my_rating' => $this->ratingService()->getUserRating((int)$this->userId(), 'social_task', $adId),
                'avg'       => $summary[$adId]['avg'] ?? 0.0,
                'count'     => $summary[$adId]['count'] ?? 0,
            ],
        ]);
    }

    public function submit(): void
    {
        $executionId = (int)$this->request->param('id');
        // 🛡️ FIX-10a-F1 (R10 audit P1): payload خام فقط برای «سیگنال کمکی» پاس داده
        // می‌شود؛ تلومتری خوداظهاری کلاینت (behavior_signals و مشابه) هرگز منبعِ
        // حقیقتِ پرداخت نیست — تصمیمِ آزادسازی خودکار در SubmitSocialTaskExecutionJob
        // به اثباتِ قابل‌راستی‌آزماییِ سمت‌سرور (تأیید دوربین) گیت شده و پیش‌فرضِ
        // مسیرهای بی‌اثبات، بررسیِ دستی است.
        $payload = $this->request->all();
        $result = $this->socialTaskService->submitExecution((int)$this->userId(), $executionId, $payload);
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    public function execute(): void
    {
        $request = new ExecuteSocialTaskRequest($this->request->all());
        if (!$request->validate()) {
            $this->response->json(['success' => false, 'errors' => $request->errors()], 422);
            return;
        }
        $result = $this->socialTaskService->executeTask((int)$this->userId(), $request->safeValidated()); // FIX-X16
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    public function executionDetail(): void
    {
        // Compatibility route from older /social-ads URLs.
        $this->showExecute();
    }

    public function approveExecution(): void
    {
        $this->response->json([
            'success' => false,
            'message' => 'تأیید اجرای تسک از مسیر تبلیغ‌دهنده/مدیریت انجام می‌شود.'
        ], 422);
    }

    public function rejectExecution(): void
    {
        $this->response->json([
            'success' => false,
            'message' => 'رد اجرای تسک از مسیر تبلیغ‌دهنده/مدیریت انجام می‌شود.'
        ], 422);
    }

    public function rateExecutionForm(): void
    {
        // 🛡️ FIX-SOCRATE-VOTE-EXEC-01: فرم امتیاز اکنون داخل خود صفحهٔ اجراست؛
        // این GET (deep-link/لینک قدیمی) به همان صفحه هدایت می‌شود.
        $this->response->redirect(url('/social-tasks/' . (int)$this->request->param('id') . '/execute'));
    }

    /**
     * 🛡️ FIX-SOCRATE-VOTE-EXEC-01 (تصمیم کارفرما ۲۰۲۶-۱۱-۱۰ —
     * قرینهٔ SeoController::rate): ثبت امتیاز به کمپین سوشیال از داخل خود
     * صفحهٔ اجرا (AJAX). {id} شناسهٔ «اجرا» است (هم‌قرارداد /execute و /submit).
     *
     * گارد وضعیت در کنترلر: فقط اجرای approved (معادل completed سئو)؛ گارد
     * واقعی (نه مالک + مجریِ اجرای تأییدشدهٔ همین آگهی + کلمپ ۱..۵) داخل
     * SocialTaskService::rateTask — همان مسیر گاردشدهٔ API اپ؛ قابل دورزدن نیست.
     */
    public function rateExecution(): void
    {
        $executionId = (int)$this->request->param('id');
        $userId = (int)$this->userId();
        $body = $this->request->body();
        $stars = int_value($body['stars'] ?? 0);
        $comment = trim(str_value($body['comment'] ?? ''));

        if ($stars < 1 || $stars > 5) {
            $this->response->json(['success' => false, 'message' => 'امتیاز نامعتبر است'], 422);
            return;
        }

        $execution = $this->socialTaskService->getExecutionWithAd($executionId, $userId);
        if (!$execution) {
            $this->response->json(['success' => false, 'message' => 'اجرای تسک یافت نشد'], 404);
            return;
        }

        // 🛡️ FIX-SOCRATE-VOTE-EXEC-01: امتیاز پس از تجربهٔ کامل — فقط اجرای
        // تأییدشده (قرینهٔ completed سئو؛ مجریِ ردشده کانال گزارش دارد، نه رأی).
        if ((string)$execution->status !== 'approved') {
            $this->response->json(['success' => false, 'message' => 'امتیازدهی فقط پس از تأیید این تسک امکان‌پذیر است'], 422);
            return;
        }

        $result = $this->socialTaskService->rateTask($userId, (int)$execution->ad_id, $stars, $comment);
        $this->response->json($result, !empty($result['success']) ? 200 : 422);
    }

    public function ratingHistory(): void
    {
        $this->history();
    }
}
