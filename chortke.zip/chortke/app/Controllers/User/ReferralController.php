<?php

namespace App\Controllers\User;

use App\Models\ReferralCommission;
use App\Services\Shared\ReferralService;
use App\Controllers\User\BaseUserController;

/**
 * ReferralController - Consolidated Referral System
 * 
 * استفاده از نئی ReferralService (Sprint 4 - Consolidation)
 * تمام referral functionality اب ایک service میں ہے
 */
class ReferralController extends BaseUserController
{
    private ReferralCommission $referralCommissionModel;
    private ReferralService    $referralService;

    public function __construct(
        ReferralCommission $referralCommissionModel,
        ReferralService    $referralService
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->referralCommissionModel = $referralCommissionModel;
        $this->referralService = $referralService;
    }

    /**
     * لودر مشترک داده‌های هاب تک‌صفحه‌ای رفرال.
     * 🛡️ تکمیل معماری هاب (الگوی هاب تبلیغات): همه اکشن‌های نمای این ماژول همان
     * ویو هاب را رندر می‌کنند؛ داده همه پنل‌ها از یک لودر واحد تأمین می‌شود.
     *
     * @return array<string, mixed>
     */
    private function hubData(int $userId): array
    {
        $user = $this->userService->find($userId);

        // آمار کلی کمیسیون‌ها - نئی ReferralService سے
        $stats = $this->referralService->getReferrerStats($userId);

        // تعداد و لیست زیرمجموعه‌ها
        $referredCount = $this->referralService->countReferredUsers($userId);
        $referredUsers = $this->referralService->getReferredUsers($userId, 10, 0);

        // آخرین ۱۰ کمیسیون
        $recentCommissions = $this->referralService->getByReferrer($userId, [], 10, 0);

        // برچسب‌گذاری کمیسیون‌ها
        foreach ($recentCommissions as $c) {
            $c->source_label = $c->source_type ?? 'ناشناخته';
            $c->status_label = self::statusLabel($c->status);
            $c->status_class = self::statusClass($c->status);
        }

        // لینک و درصدهای فعال
        $referralLink = url('/register?ref=' . ($user->referral_code ?? ''));

        // FIX-R90 (پران): آرایهٔ $percents (درصدهای به‌ازای-منبع) حذف شد —
        // موتور کمیسیون فقط درصد تخت referral_commission_percent را می‌خواند،
        // کلیدهای task/investment/vip/story در راند ۹۰ از فرم ادمین و کاتالوگ
        // پران شدند و هیچ ویویی مصرفش نمی‌کرد (پران هم‌راندگی 90-b).

        // داده پنل‌های میلستون و تحلیل (اسکیمای واقعی جداول)
        $milestoneOverview = $this->referralService->getMilestoneOverview($userId);
        $analyticsData     = $this->referralService->getUserAnalytics($userId, 30);

        // X366 — صدرنشین ماه قبل (از مسیر مدل/سرویس رفرال؛ بدون SQL خام):
        // username + مجموع کمیسیون ماه گذشته؛ null = هنوز صدرنشینی ثبت نشده.
        $prevTopReferrer = $this->referralCommissionModel->getTopMonthlyReferrer();

        return [
            'user'              => $user,
            'stats'             => $stats,
            'referredCount'     => $referredCount,
            'referredUsers'     => $referredUsers,
            'recentCommissions' => $recentCommissions,
            'referralLink'      => $referralLink,
            'sourceTypes'       => [],
            'achieved'          => $milestoneOverview['achieved'],
            'available'         => $milestoneOverview['available'],
            'analytics'         => $analyticsData,
            'prevTopReferrer'   => $prevTopReferrer,
        ];
    }

    /**
     * صفحه اصلی زیرمجموعه‌گیری (هاب تک‌صفحه‌ای: overview / milestones / analytics)
     */
    public function index(): string
    {
        $userId = (int)$this->userId();
        return $this->view('user/referral/index', $this->hubData($userId));
    }

    /**
     * لیست کمیسیون‌ها (AJAX/JSON — مرورگر → ردایرکت به هاب رفرال: FIX-X204 راند ۵۴)
     */
    public function commissions(): void
    {
        $userId = (int)$this->userId();

        // 🧭 FIX-X204 (کلاس باگ X202): مرورگر به‌جای JSON خام → هاب رفرال (صاحب این تب‌ها)؛ کلاینت AJAX → قرارداد JSON دست‌نخورده
        if (!is_ajax()) {
            redirect(url('/referral')); // 🛡️ FIX-PS-C3
        }

        $filters = array_filter([
            'status'      => $this->request->get('status'),
            'source_type' => $this->request->get('source_type'),
            'currency'    => $this->request->get('currency'),
        ]);

        $page   = max(1, $this->request->int('page', 1));
        $limit  = 15;
        $offset = ($page - 1) * $limit;

        $commissions = $this->referralService->getByReferrer($userId, $filters, $limit, $offset);
        $total       = $this->referralService->countByReferrer($userId, $filters);

        foreach ($commissions as $c) {
            $c->created_at_jalali = to_jalali($c->created_at ?? '');
            $c->paid_at_jalali    = $c->paid_at ? to_jalali($c->paid_at) : null;
            $c->source_label      = $c->source_type ?? 'ناشناخته';
            $c->status_label      = self::statusLabel($c->status);
            $c->status_class      = self::statusClass($c->status);
        }

        $this->response->json([
            'success'     => true,
            'commissions' => $commissions,
            'total'       => $total,
            'page'        => $page,
            'pages'       => (int) ceil($total / $limit),
        ]);
    }

    /**
     * لیست زیرمجموعه‌ها (AJAX/JSON — مرورگر → ردایرکت به هاب رفرال: FIX-X204 راند ۵۴)
     */
    public function referredUsers(): void
    {
        $userId = (int)$this->userId();

        // 🧭 FIX-X204: مرورگر → هاب رفرال؛ AJAX → JSON
        if (!is_ajax()) {
            redirect(url('/referral')); // 🛡️ FIX-PS-C3
        }

        $page   = max(1, $this->request->int('page', 1));
        $limit  = 15;
        $offset = ($page - 1) * $limit;

        $users = $this->referralService->getReferredUsers($userId, $limit, $offset);
        $total = $this->referralService->countReferredUsers($userId);

        foreach ($users as $u) {
            $u->joined_at_jalali = to_jalali($u->joined_at ?? '');
        }

        $this->response->json([
            'success' => true,
            'users'   => $users,
            'total'   => $total,
            'page'    => $page,
            'pages'   => (int) ceil($total / $limit),
        ]);
    }

    // ── Helpers ────────────────────────────────────────────────

    private static function statusLabel(string $status): string
    {
        return [
            'pending'   => 'در انتظار',
            'paid'      => 'پرداخت شده',
            'cancelled' => 'لغو شده',
            'failed'    => 'ناموفق',
        ][$status] ?? $status;
    }

    private static function statusClass(string $status): string
    {
        return [
            'pending'   => 'ref-badge--pending',
            'paid'      => 'ref-badge--paid',
            'cancelled' => 'ref-badge--danger',
            'failed'    => 'ref-badge--danger',
        ][$status] ?? 'ref-badge--muted';
    }

    // ── New Features ───────────────────────────────────────────

    /**
     * 🛡️ تکمیل معماری هاب تک‌صفحه‌ای رفرال:
     * صفحه dashboard قدیمی هیچ روتی نداشت و به داده‌هایی اشاره می‌کرد که هرگز
     * وجود نداشتند (processMultiTierCommissions با مبلغ صفر، ایندکس‌های بدون کوتیشن
     * در ویو و لینک‌های مرده /user/referral/...). این اکشن حالت مثل index عمل می‌کند
     * و ویو dashboard.php فقط یک alias روی پنل overview هاب است.
     */
    public function dashboard(): string
    {
        $userId = (int)$this->userId();
        return $this->view('user/referral/dashboard', $this->hubData($userId));
    }

    /**
     * پنل تحلیل و نمودارها — از طریق هاب تک‌صفحه‌ای (section=analytics) رندر می‌شود.
     */
    public function analytics(): string
    {
        $userId = (int)$this->userId();
        return $this->view('user/referral/analytics', $this->hubData($userId));
    }

    /**
     * پنل دستاوردها و میلستون‌ها — از طریق هاب تک‌صفحه‌ای (section=milestones) رندر می‌شود.
     */
    public function milestones(): string
    {
        $userId = (int)$this->userId();
        return $this->view('user/referral/milestones', $this->hubData($userId));
    }

    /**
     * صفحه شبکه (Network) - Multi-tier - نئی ReferralService
     */
    

    /**
     * API: دریافت آمار لحظه‌ای - نئی ReferralService
     */
    public function apiStats(): void
    {
        $userId = (int)$this->userId();

        $this->response->json([
            'success' => true,
            'data' => [
                'tier' => $this->referralService->getCurrentTier($userId),
                'quality_score' => $this->referralService->getScore($userId),
                'conversion_rate' => $this->referralService->getConversionRate($userId, 7),
            ]
        ]);
    }

    public function generateCode(): void
    {
        $userId = (int)$this->userId();
        $user = $this->userService->find($userId);
        if (!$user) {
            // FIX-R14: فرم کلاسیک → flash + redirect به هاب رفرال (هم‌الگوی
            // FraudReportController::store)؛ کلاینت AJAX → JSON (رفتار قبلی).
            if (is_ajax()) {
                $this->response->json(['success' => false, 'message' => 'کاربر یافت نشد.'], 404);
            } else {
                $this->session->setFlash('error', 'کاربر یافت نشد.');
                $this->response->redirect(url('/referral'));
            }
            return;
        }
        // BUGFIX: کد تولیدشده باید ذخیره شود. پیش از این کد فقط در حافظه ساخته
        // و در پاسخ برگردانده می‌شد اما هرگز در users.referral_code نوشته
        // نمی‌شد؛ در نتیجه هر فراخوان کد متفاوتی می‌داد و لینک معرفی
        // بازگشتی (/register?ref=…) هرگز به کاربری نگاشت نمی‌شد، چون
        // findByReferralCode() کد را از دیتابیس می‌خواند.
        $code = $user->referral_code ?? null;
        if ($code === null || $code === '') {
            // تولید کد یکتا با تعداد تلاش محدود تا با قید یکتایی ستون
            // users.referral_code برخورد نکند.
            for ($attempt = 0; $attempt < 5; $attempt++) {
                $candidate = 'REF_' . $userId . '_' . bin2hex(random_bytes(3));
                if ($this->userService->findByReferralCode($candidate) === null) {
                    $code = $candidate;
                    break;
                }
            }
            if ($code === null || $code === '') {
                if (is_ajax()) {
                    $this->response->json(['success' => false, 'message' => 'تولید کد معرف ناموفق بود. لطفاً دوباره تلاش کنید.'], 500);
                } else {
                    $this->session->setFlash('error', 'تولید کد معرف ناموفق بود. لطفاً دوباره تلاش کنید.');
                    $this->response->redirect(url('/referral'));
                }
                return;
            }
            $this->userService->update($userId, ['referral_code' => $code]);
        }
        // FIX-R14 (آیتم ۱ دور ۱۴ — دکمهٔ تولید کد برای کاربران legacy):
        // ارسال فرم کلاسیک (بدون JS) → پیام موفقیت + بازگشت به هاب رفرال؛
        // CSRF از میدل‌ور گروه مسیر ($referralAuth = Auth + CSRF + Feature).
        if (is_ajax()) {
            $this->response->json(['success' => true, 'referral_code' => $code, 'referral_link' => url('/register?ref=' . $code)]);
            return;
        }
        $this->session->setFlash('success', 'کد دعوت اختصاصی شما ساخته شد و لینک دعوت فعال است.');
        $this->response->redirect(url('/referral'));
    }

    public function setReferrer(): void
    {
        try {
            $userId = (int)$this->userId();
            $refCode = trim(str_value($this->request->input('referral_code') ?? $this->request->input('code') ?? ''));
            if ($refCode === '' || mb_strlen($refCode) > 100) {
                $this->response->json(['success' => false, 'message' => 'کد معرف الزامی است.'], 422);
                return;
            }
            $user = $this->userService->find($userId);
            if ($user && !empty($user->referred_by)) {
                $this->response->json(['success' => false, 'message' => 'شما قبلاً معرف خود را ثبت کرده‌اید و امکان تغییر آن وجود ندارد.'], 422);
                return;
            }
            $referrer = null;
            try {
                $referrer = $this->userService->findByCredentials($refCode);
            } catch (\Throwable $e) {
                $referrer = null;
            }
            if (!$referrer) {
                $referrer = $this->userService->findByReferralCode($refCode);
            }
            if (!$referrer) {
                $this->response->json(['success' => false, 'message' => 'کد معرف معتبر نیست.'], 422);
                return;
            }
            if ((int)$referrer->id === $userId) {
                $this->response->json(['success' => false, 'message' => 'امکان ثبت خود به عنوان معرف وجود ندارد.'], 422);
                return;
            }
            // S5-M6 FIX: the generic updateUser whitelist silently dropped
            // referred_by while reporting success. The dedicated write fails
            // honestly (e.g. a referrer is already attached).
            $stored = $this->userService->updateReferredBy($userId, (int)$referrer->id);
            if (!$stored) {
                $this->response->json(['success' => false, 'message' => 'ثبت معرف ممکن نشد؛ احتمالاً قبلاً معرف برای حساب شما ثبت شده است.'], 422);
                return;
            }
            $this->response->json(['success' => true, 'message' => 'معرف با موفقیت ثبت شد.']);
        } catch (\Core\Exceptions\HttpResponseException $e) {
            throw $e;
        } catch (\Throwable $e) {
            $this->response->json(['success' => false, 'message' => 'کد معرف معتبر نیست.'], 422);
        }
    }

    public function claimRewards(): void
    {
        $userId = (int)$this->userId();
        $result = $this->referralService->checkAndAwardMilestones($userId);
        $this->response->json(['success' => true, 'result' => $result]);
    }

    /**
     * Master E2E Functional Browser Verification for Section 8.4 Referral Bounded Domain Operations (RF-01 to RF-05)
     */
}

