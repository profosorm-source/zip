<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\Ads;
use App\Models\SeoExecution;
use App\Models\SeoLandingProofTest;
use App\Services\SeoLandingProofService;

/**
 * 🛡️ FIX-SEO-23-01 (فاز ۲) — پنل اثبات فرودِ تبلیغ‌دهنده (دکمهٔ تست + راز پست‌بک).
 *
 * سه مسیر، همگی مالکیت‌دار (فقط مالک آگهی) و محافظت‌شده با CSRF:
 *   POST /ads/seo-proof/test             — صدور توکن تست + مستندات کد
 *   GET  /ads/seo-proof/test-status      — poll وضعیت رسیدن تست (پنل/JS)
 *   POST /ads/seo-proof/regenerate-secret — چرخش راز پست‌بک
 */
class SeoProofController extends BaseUserController
{
    private SeoLandingProofService $proof;

    public function __construct(?\App\Contracts\LoggerInterface $logger = null)
    {
        parent::__construct(null, null, null, null, $logger);
        $this->proof = new SeoLandingProofService(
            new SeoExecution(db()),
            new SeoLandingProofTest(db()),
            new Ads(db()),
            db(),
            logger()
        );
    }

    /** POST /ads/seo-proof/test — ad_id */
    public function startTest(): void
    {
        $body = $this->request->body();
        $adId = int_value($body['ad_id'] ?? $this->request->get('ad_id') ?? 0);
        $result = $this->proof->startIntegrationTest($adId, (int)user_id());
        $this->response->json($result, !empty($result['ok']) ? 200 : 422);
    }

    /** GET /ads/seo-proof/test-status — ad_id + token */
    public function testStatus(): void
    {
        $adId = int_value($this->request->get('ad_id') ?? 0);
        $token = str_value($this->request->get('token') ?? '');
        $result = $this->proof->integrationTestStatus($adId, (int)user_id(), $token);
        $this->response->json($result, !empty($result['ok']) ? 200 : 422);
    }

    /** POST /ads/seo-proof/regenerate-secret — ad_id */
    public function regenerateSecret(): void
    {
        $body = $this->request->body();
        $adId = int_value($body['ad_id'] ?? $this->request->get('ad_id') ?? 0);
        $result = $this->proof->regeneratePostbackSecret($adId, (int)user_id());
        $this->response->json($result, !empty($result['ok']) ? 200 : 422);
    }
}
