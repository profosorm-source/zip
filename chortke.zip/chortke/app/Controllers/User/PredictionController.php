<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Models\PredictionGame;
use App\Models\PredictionBet;
use App\Services\PredictionService;

class PredictionController extends BaseUserController
{
    private PredictionGame $gameModel;
    private PredictionBet $betModel;
    private PredictionService $predictionService;
    public function __construct(
        PredictionGame $gameModel,
        PredictionBet $betModel,
        PredictionService $predictionService
    , ?\App\Contracts\LoggerInterface $logger = null) {        $this->gameModel = $gameModel;
        $this->betModel = $betModel;
        $this->predictionService = $predictionService;

        parent::__construct(null, null, null, null, $logger);
    }

    // ─── لیست بازی‌های باز ────────────────────────────────────────────
    public function index(): void
    {
        $userId = (int)user_id();
        $games  = $this->gameModel->getOpen(20, 0);

        // وضعیت شرط کاربر برای هر بازی
        $userBets = [];
        foreach ($games as $g) {
            $userBets[(int)$g->id] = $this->betModel->userHasBet($userId, (int)$g->id);
        }

        $this->view('user/prediction/index', [
            'title'    => 'پیش‌بینی بازی‌های ورزشی',
            'games'    => $games,
            'userBets' => $userBets,
        ]);
    }

    // ─── صفحه جزئیات بازی + فرم شرط‌بندی ────────────────────────────
    public function show(): void
    {
        $id   = (int)$this->request->param('id');
        $game = $this->gameModel->find($id);

        if (!$game || $game->deleted_at) {
            $this->session->setFlash('error', 'بازی یافت نشد.');
            redirect(url('/prediction'));
            return;
        }

        $userId = (int)user_id();
        $hasBet = $this->betModel->userHasBet($userId, $id);
        $myBet  = null;

        if ($hasBet) {
            $myBets = $this->betModel->getByUser($userId, 1, 0);
            foreach ($myBets as $b) {
                if ((int)$b->game_id === $id) {
                    $myBet = $b;
                    break;
                }
            }
        }

        $this->view('user/prediction/show', [
            'title'  => 'پیش‌بینی: ' . e($game->title),
            'game'   => $game,
            'hasBet' => $hasBet,
            'myBet'  => $myBet,
        ]);
    }

    // ─── ثبت شرط ──────────────────────────────────────────────────────
    public function placeBet(): void
    {
        $userId = (int)user_id();
        $gameId = (int)$this->request->param('id');
        $input = $this->request->all();

        $validator = \Core\Validator::create($input, [
            'prediction' => 'required|in:home,away,draw',
            'amount_usdt' => 'required|numeric|min:0.01',
            'idempotency_key' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            $this->response->json([
                'success' => false,
                'message' => 'اطلاعات ورودی نامعتبر است.',
                'errors'  => $validator->errors(),
            ], 422);
            return;
        }

        $data = $validator->data();
        $prediction = trim((string)($data['prediction'] ?? ''));
        $amount     = (float)($data['amount_usdt'] ?? 0);
        $idempotencyKey = trim((string)($data['idempotency_key'] ?? '')) ?: null;

        try {
            $result = $this->predictionService->placeBet($userId, $gameId, $prediction, $amount, $idempotencyKey);
            $this->response->json($result);

        } catch (\InvalidArgumentException $e) {
            $this->response->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\RuntimeException $e) {
            $this->response->json(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            $this->logger->error('prediction.placeBet.failed', [
                'user_id' => $userId,
                'game_id' => $gameId,
                'error'   => $e->getMessage(),
            ]);
            $this->response->json(['success' => false, 'message' => 'خطای سیستمی. لطفاً دوباره تلاش کنید.']);
        }
    }

    // ─── تاریخچه شرط‌های کاربر ────────────────────────────────────────
    public function myBets(): void
    {
        $userId  = (int)user_id();
        $page    = max(1, (int)$this->request->get('page', 1));
        $perPage = 20;
        $offset  = ($page - 1) * $perPage;

        $bets  = $this->betModel->getByUser($userId, $perPage, $offset);
        $total = $this->betModel->countByUser($userId);

        $this->view('user/prediction/my-bets', [
            'title'      => 'پیش‌بینی‌های من',
            'bets'       => $bets,
            'page'       => $page,
            'perPage'    => $perPage,
            'total'      => $total,
            'totalPages' => max(1, (int)ceil($total / $perPage)),
        ]);
    }

    /**
     * Master E2E Functional Browser Verification for Section 8.2 Prediction Bounded Domain Operations (PT-01 to PT-04)
     */
    public function verifyPredictionSection82(): void
    {
        $db = \Core\Database::getInstance();
        $results = [];
        $salt = random_int(10000, 99999);

        // Helper to setup a test wallet
        $setupWallet = function(int $userId, float $balanceUsdt) use ($db) {
            $db->query("INSERT IGNORE INTO users (id, email, full_name, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())", [$userId, "user_pred_{$userId}@chortke.ir", "Pred User {$userId}"]);
            $db->query("INSERT IGNORE INTO wallets (user_id, balance_irt, balance_usdt) VALUES (?, 0, ?)", [$userId, $balanceUsdt]);
            $db->query("UPDATE wallets SET balance_usdt = ? WHERE user_id = ?", [$balanceUsdt, $userId]);
        };

        $getBalanceUsdt = function(int $userId) use ($db) {
            $row = $db->fetch("SELECT balance_usdt FROM wallets WHERE user_id = ?", [$userId]);
            return $row !== false && $row !== null ? (float)$row->balance_usdt : 0.0;
        };

        // Helper to setup a test game
        $createGame = function(int $gameId, string $title, string $status = 'open') use ($db) {
            $db->query("INSERT IGNORE INTO prediction_games (id, title, status, min_bet_usdt, max_bet_usdt, bet_deadline, match_date, created_at) VALUES (?, ?, ?, 1.00, 1000.00, NOW() + INTERVAL 2 DAY, NOW() + INTERVAL 2 DAY, NOW())", [$gameId, $title, $status]);
            $db->query("UPDATE prediction_games SET status = ?, commission_percent = 0, bet_deadline = NOW() + INTERVAL 2 DAY, match_date = NOW() + INTERVAL 2 DAY, deleted_at = NULL WHERE id = ?", [$status, $gameId]);
        };

        // ─── 1. PT-01 ⭐: Place Bet: PlaceBetJob is present -> Job executes, balance deducted ───
        try {
            $u01 = 80000 + $salt;
            $g01 = 800 + $salt;
            $setupWallet($u01, 50.0);
            $createGame($g01, 'بازی #۱: استقلال vs پرسپولیس (PT-01 ⭐)');

            // Execute PlaceBet
            $res01 = $this->predictionService->placeBet($u01, $g01, 'home', 10.0, "pt01_key_{$salt}");

            // Verify new balance
            $bal01 = $getBalanceUsdt($u01);

            $passed = (!empty($res01['success'])) && ($bal01 === 40.0);
            $results['PT-01'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی PT-01 ⭐: ثبت شرط ورزشی و تأیید عملکرد PlaceBetJob',
                'details' => "موجودی اولیه کیف پول تتری: <code>50.00 USDT</code><br>مبلغ شرط ثبت‌شده: <code>10.00 USDT</code> روی گزینه <code>میزبان (Home)</code><br>خروجی لایه سرویس (PlaceBetJob): <code>" . ($res01['message'] ?? '') . " (شناسه شرط: #" . ($res01['bet_id'] ?? 1) . ")</code><br>موجودی نهایی کیف پول تتری: <code>" . number_format($bal01, 2) . " USDT</code>",
                'message' => $passed ? 'موفق: سیستم مفقودیت Job را برطرف نموده و شرط با موفقیت اتمیک ثبت گردید.' : 'خطا در اجرای Job یا کسر وجه.'
            ];
        } catch (\Throwable $e) {
            $results['PT-01'] = ['status' => 'FAILED', 'title' => 'PT-01 ⭐', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── 2. PT-02: Place Bet exceeding wallet balance -> Rejected ───
        try {
            $u02 = 81000 + $salt;
            $g02 = 810 + $salt;
            $setupWallet($u02, 5.0); // Only 5 USDT
            $createGame($g02, 'بازی #۲: سپاهان vs تراکتور (PT-02)');

            // Execute
            $res02 = $this->predictionService->placeBet($u02, $g02, 'away', 20.0, "pt02_key_{$salt}");
            $bal02 = $getBalanceUsdt($u02);

            $passed = (empty($res02['success'])) && ($bal02 === 5.0);
            $results['PT-02'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی PT-02: شرط‌بندی با مبلغ بیش از موجودی (Exceeding Balance)',
                'details' => "موجودی فعلی کاربر: <code>5.00 USDT</code><br>مبلغ درخواستی برای شرط‌بندی: <code>20.00 USDT</code><br>پاسخ گیت مالی سیستمی: <code>" . ($res02['message'] ?? 'موجودی ناکافی') . "</code><br>موجودی نهایی کیف پول: <code>" . number_format($bal02, 2) . " USDT (بدون تغییر)</code>",
                'message' => $passed ? 'موفق: سیستم فوراً درخواست شرط با موجودی ناکافی را رد کرد.' : 'خطا در مسدودسازی.'
            ];
        } catch (\Throwable $e) {
            $results['PT-02'] = ['status' => 'FAILED', 'title' => 'PT-02', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── 3. PT-03: Settle Game: SettleGameJob -> Winners receive payouts, losers lose ───
        try {
            $uWin = 82000 + $salt;
            $uLose = 83000 + $salt;
            $g03 = 820 + $salt;

            $setupWallet($uWin, 10.0);
            $setupWallet($uLose, 10.0);
            $createGame($g03, 'بازی #۳: رئال مادرید vs بارسلونا (PT-03)');

            // Place bets
            $this->predictionService->placeBet($uWin, $g03, 'home', 10.0, "pt03_win_" . uniqid());
            $this->predictionService->placeBet($uLose, $g03, 'away', 10.0, "pt03_lose_" . uniqid());

            // Verify balances before settlement (both exactly 0 USDT)
            $balWinBefore = $getBalanceUsdt($uWin);
            $balLoseBefore = $getBalanceUsdt($uLose);

            // Execute SettleGameJob
            $setRes = $this->predictionService->settleGame($g03, 'home', 1);

            // Verify final balances
            $balWinAfter = $getBalanceUsdt($uWin);
            $balLoseAfter = $getBalanceUsdt($uLose);

            $gameObj = $this->gameModel->find($g03);

            $passed = (!empty($setRes['success'])) && ($balWinAfter === 20.0) && ($balLoseAfter === 0.0) && ($gameObj->status === 'finished');
            $results['PT-03'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی PT-03: تسویه کامل بازی ورزشی (SettleGameJob)',
                'details' => "نتیجه نهایی اعلام‌شده: <code>برد میزبان (Home)</code> (پاسخ تسویه: " . ($setRes['message'] ?? 'موفق') . ")<br>تراکنش برنده (کاربر {$uWin}): واریز اصل شرط + جایزه تتری (موجودی نهایی: <code>" . number_format($balWinAfter, 2) . " USDT</code>)<br>تراکنش بازنده (کاربر {$uLose}): کسر قطعی مبلغ شرط (موجودی نهایی: <code>" . number_format($balLoseAfter, 2) . " USDT</code>)<br>وضعیت نهایی بازی ورزشی: <code>" . ($gameObj->status ?? '') . "</code>",
                'message' => $passed ? 'موفق: استخر جوایز تتری دقیقاً بر اساس BCMath توزیع شد و سود و زیان تسویه گردید.' : 'خطا در تسویه بازی.'
            ];
        } catch (\Throwable $e) {
            $results['PT-03'] = ['status' => 'FAILED', 'title' => 'PT-03', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── 4. PT-04: Cancel Game: CancelGameJob -> All active bets fully refunded ───
        try {
            $uCan = 84000 + $salt;
            $g04 = 840 + $salt;

            $setupWallet($uCan, 50.0);
            $createGame($g04, 'بازی #۴: بایرن مونیخ vs یوونتوس (PT-04)');

            // Place bet
            $this->predictionService->placeBet($uCan, $g04, 'draw', 15.0, "pt04_can_" . uniqid());
            $balCanMid = $getBalanceUsdt($uCan);

            // Execute CancelGameJob
            $canRes = $this->predictionService->cancelGame($g04, 1);
            $balCanFinal = $getBalanceUsdt($uCan);

            $gameCanObj = $this->gameModel->find($g04);

            $passed = (!empty($canRes['success'])) && ($balCanMid === 35.0) && ($balCanFinal === 50.0) && ($gameCanObj->status === 'cancelled');
            $results['PT-04'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی PT-04: لغو رسمی بازی ورزشی (CancelGameJob)',
                'details' => "موجودی اولیه کاربر: <code>50.00 USDT</code><br>موجودی پس از ثبت شرط ۱۵ دلاری: <code>" . number_format($balCanMid, 2) . " USDT</code><br>نتیجه اجرای CancelGameJob: <code>" . ($canRes['message'] ?? '') . "</code><br>موجودی نهایی کیف پول پس از برگشت موفق (Refund): <code>" . number_format($balCanFinal, 2) . " USDT</code>",
                'message' => $passed ? 'موفق: بازی لغو شد و تمامی مبالغ شرط‌بندی به موجودی کیف پول کاربران برگشت داده شد.' : 'خطا در برگشت وجه.'
            ];
        } catch (\Throwable $e) {
            $results['PT-04'] = ['status' => 'FAILED', 'title' => 'PT-04', 'details' => $e->getMessage(), 'message' => 'خطای سیستمی'];
        }

        // ─── Render View ───
        $this->view('user/prediction/verification', [
            'title'   => 'ارزیابی حرفه‌ای و مرورگرمحور سیستم پیش‌بینی ورزشی (Section 8.2 Verification)',
            'results' => $results,
        ]);
    }
}

