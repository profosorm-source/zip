<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Services\EscrowService;
use App\Services\User\UserService;
use App\Controllers\User\BaseUserController;
use App\Services\AuditTrail;
use App\Domain\Financial\Services\FinancialEscrowService;

class EscrowController extends BaseUserController
{
    // $userService inherited from parent
    // $logger inherited from BaseController

    private AuditTrail $auditTrail;
    private FinancialEscrowService $financialEscrow;

    public function __construct(
        UserService $userService,
        AuditTrail $auditTrail,
        FinancialEscrowService $financialEscrow,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        // 🛡️ FIX-PS-C2: $escrowModel هرگز خوانده نمی‌شد (dead) — حذف شد
        parent::__construct(null, null, null, null, $logger);
        $this->userService   = $userService;
        $this->auditTrail    = $auditTrail;
        $this->financialEscrow = $financialEscrow;
    }

    /**
     * 🛡️ FIX-FINANCE-HUB-COMPLETION: متدهای index()/create() (رندر صفحات) حذف
     * شدند — لیست و فرم صندوق امانات اکنون پنل‌های escrows/escrow-create هاب
     * مالی هستند و GET های /wallet/escrows و /wallet/escrow/create توسط
     * WalletController رندر می‌شوند. این کنترلر فقط عملیات عملیاتی
     * store/release (JSON/redirect) را نگه می‌دارد.
     */
    public function store(): void
    {
        $this->validateCsrf();
        $buyerId = (int)$this->userId();
        $sellerIdentifier = trim($this->request->str('seller')) ?: trim($this->request->str('recipient'));
        $amountStr = trim($this->request->str('amount'));
        $orderTitle = trim($this->request->str('title', 'معامله امن اختصاصی'));

        if ($sellerIdentifier === '' || !is_numeric($amountStr) || bccomp($amountStr, '0', 4) <= 0) {
            $this->response->json(['success' => false, 'message' => 'اطلاعات فروشنده یا مبلغ معتبر نیست.']);
            return;
        }

        $seller = $this->userService->findByCredentials($sellerIdentifier);
        if (!$seller) {
            $this->response->json(['success' => false, 'message' => 'طرف معامله (فروشنده) یافت نشد.']);
            return;
        }

        $sellerId = (int)$seller->id;
        if ($sellerId === $buyerId) {
            $this->response->json(['success' => false, 'message' => 'امکان ایجاد معامله امن با خودتان وجود ندارد.']);
            return;
        }

        $orderId = random_int(100000, 999999);
        // Generic escrow must create the wallet hold and the escrow row in the
        // same transaction. Creating only the row would make a later payout
        // create money without reserving buyer funds.
        $res = $this->financialEscrow->holdCustomDealFunds(
            $orderId,
            $buyerId,
            $sellerId,
            $amountStr,
            'custom_deal_hold:' . $buyerId . ':' . $orderId
        );

        if (!empty($res['ok'])) {
            $this->auditTrail->record('escrow_created', $buyerId, [
                'escrow_id' => int_value($res['escrow_id'] ?? 0),
                'amount'    => $amountStr,
                'seller_id' => $sellerId,
            ], $buyerId);
            $this->response->json(['success' => true, 'message' => 'وجه در صندوق امانات قفل شد.', 'escrow_id' => $res['escrow_id'] ?? 0]);
        } else {
            $this->response->json(['success' => false, 'message' => $res['error'] ?? 'خطا در قفل‌گذاری وجه']);
        }
    }

    public function release(): void
    {
        $this->validateCsrf();
        $userId = (int)$this->userId();
        $escrowId = $this->request->int('escrow_id');

        $res = $this->financialEscrow->releaseCustomDealFunds(
            $escrowId,
            $userId,
            'custom_deal_release:' . $userId . ':' . $escrowId
        );
        if (!empty($res['ok'])) {
            $this->response->json(['success' => true, 'message' => 'وجه امانی با موفقیت آزاد و به فروشنده منتقل شد.']);
        } else {
            $this->response->json(['success' => false, 'message' => $res['error'] ?? 'خطا در آزادسازی']);
        }
    }
}
