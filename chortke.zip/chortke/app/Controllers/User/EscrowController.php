<?php

declare(strict_types=1);

namespace App\Controllers\User;

use App\Services\EscrowService;
use App\Services\User\UserService;
use App\Controllers\User\BaseUserController;

class EscrowController extends BaseUserController
{
    private EscrowService $escrowService;
    // $userService inherited from parent
    // $logger inherited from BaseController

    public function __construct(
        EscrowService $escrowService,
        UserService $userService,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->escrowService = $escrowService;
        $this->userService   = $userService;
    }

    public function index(): void
    {
        $userId = $this->userId();
        $db = db();
        
        // Fetch user escrows
        $escrows = $db->fetchAll(
            "SELECT et.*, 
                    b.full_name as buyer_name, b.email as buyer_email,
                    s.full_name as seller_name, s.email as seller_email
             FROM escrow_transactions et
             LEFT JOIN users b ON b.id = et.buyer_id
             LEFT JOIN users s ON s.id = et.seller_id
             WHERE et.buyer_id = ? OR et.seller_id = ?
             ORDER BY et.created_at DESC LIMIT 50",
            [$userId, $userId]
        ) ?: [];

        $userObj = $this->userService->find($userId);
        if (!$userObj) $userObj = (object)['id' => 1, 'full_name' => 'معمار چرتکه', 'email' => 'architect@chortke.ir'];

        $this->view('user/wallet/escrows', [
            'title'   => 'صندوق امانات مالی (اسکرو)',
            'escrows' => $escrows,
            'user'    => $userObj
        ]);
    }

    public function create(): void
    {
        $userId = $this->userId();
        $userObj = $this->userService->find($userId);
        if (!$userObj) $userObj = (object)['id' => 1, 'full_name' => 'معمار چرتکه', 'email' => 'architect@chortke.ir'];

        $this->view('user/wallet/escrow-create', [
            'title' => 'ایجاد معامله امن (Escrow)',
            'user'  => $userObj
        ]);
    }

    public function store(): void
    {
        $this->validateCsrf();
        $buyerId = $this->userId();
        $sellerIdentifier = trim((string)$this->request->post('seller'));
        $amountStr = trim((string)$this->request->post('amount'));
        $orderTitle = trim((string)$this->request->post('title', 'معامله امن اختصاصی'));

        if ($sellerIdentifier === '' || !is_numeric($amountStr) || bccomp($amountStr, '0', 4) <= 0) {
            $this->response->json(['success' => false, 'message' => 'اطلاعات فروشنده یا مبلغ معتبر نیست.']);
            return;
        }

        try {
            $seller = $this->userService->findByCredentials($sellerIdentifier);
            if (!$seller) {
                $this->response->json(['success' => false, 'message' => 'طرف معامله (فروشنده) یافت نشد.']);
                return;
            }

            $sellerId = (int)$seller->id;
            if ($sellerId === $buyerId) {
                $this->response->json(['success' => false, 'message' => 'امکان ایجاد معامله امن با خودتان وجود ندارد.']);
                return;
            }

            $orderId = (string)random_int(100000, 999999);
            $res = $this->escrowService->holdFunds($orderId, 'custom_deal', $buyerId, $sellerId, $amountStr, 'IRT', "ESC_KEY_" . md5($orderId . time()));

            if (!empty($res['ok'])) {
                $this->auditLog('escrow_created', 'escrow', (int)($res['escrow_id'] ?? 0), null, ['amount' => $amountStr, 'seller_id' => $sellerId]);
                $this->response->json(['success' => true, 'message' => 'وجه در صندوق امانات قفل شد.', 'escrow_id' => $res['escrow_id'] ?? 0]);
            } else {
                $this->response->json(['success' => false, 'message' => $res['error'] ?? 'خطا در قفل‌گذاری وجه']);
            }
        } catch (\Throwable $e) {
            $this->response->json(['success' => false, 'message' => 'خطای سرور: ' . $e->getMessage()]);
        }
    }

    public function release(): void
    {
        $this->validateCsrf();
        $userId = $this->userId();
        $escrowId = (int)$this->request->post('escrow_id');

        try {
            $res = $this->escrowService->releaseFunds($escrowId, $userId, 'buyer_' . $userId, "REL_KEY_" . md5((string)$escrowId . time()));
            if (!empty($res['ok'])) {
                $this->response->json(['success' => true, 'message' => 'وجه امانی با موفقیت آزاد و به فروشنده منتقل شد.']);
            } else {
                $this->response->json(['success' => false, 'message' => $res['error'] ?? 'خطا در آزادسازی']);
            }
        } catch (\Throwable $e) {
            $this->response->json(['success' => false, 'message' => 'خطای سیستمی: ' . $e->getMessage()]);
        }
    }
}
