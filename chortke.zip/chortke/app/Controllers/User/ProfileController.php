<?php

namespace App\Controllers\User;

use App\Constants\SessionKeys;
use App\Services\User\UserService;
use App\Services\UploadService;
use App\Controllers\User\BaseUserController;

class ProfileController extends BaseUserController
{
    private UploadService $uploadService;
    // $userService inherited from parent
    private \App\Services\User\ProfileService $profileService;
    private \App\Services\Auth\SessionService $sessionService;

    public function __construct(
        UserService $userService,
        \App\Services\UploadService $uploadService,
        \App\Services\User\ProfileService $profileService,
        \App\Services\Auth\SessionService $sessionService
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->userService = $userService;
        $this->uploadService = $uploadService;
        $this->profileService = $profileService;
        $this->sessionService = $sessionService;
    }

    public function index(): void
    {
        // SEC-2 fix (BUGFIX-FALLBACK-USER-2026-06): no more hardcoded demo
        // user — if the session is stale or the DB lookup fails, redirect to
        // login instead of leaking PII of user #1.
        $userObj = $this->loadCurrentUserOrRedirect();
        $userId  = (int) $userObj->id;
        // Defensive: views expect these optional fields to exist as keys
        // even when not yet set in the DB. Fill in null defaults rather
        // than re-introducing fake values.
        foreach (['avatar', 'mobile', 'national_id', 'birth_date', 'gender', 'address', 'bio'] as $field) {
            if (!isset($userObj->{$field})) {
                $userObj->{$field} = null;
            }
        }
        
        $this->view('user/profile', ['user' => $userObj]);
    }

    public function update(): void
    {
        $userId = (int)user_id();

        // Rate Limiting
        try {
            rate_limit('content', 'update', "user_{$userId}");
        } catch (\Core\Exceptions\RateLimitExceededException $e) {
            $this->session->setFlash('error', $e->getMessage());
            redirect('profile');
        }

        // Get data from request
        // FIX-R36-W2-F1 (F-A16-01): current_password اینک از فرم گرفته و به سرویس
        // فوروارد می‌شود — قرارداد Round-18 P1 سمت سرویس (ProfileService) فقط با همین
        // کلید کامل می‌شود؛ بدون آن تغییر mobile/national_id از وب همیشه با خطای
        // عمومی شکست می‌خورد. سرویس آن را فقط وقتی mobile/national_id واقعاً تغییر
        // کرده باشد الزامی می‌داند و هیچ‌وقت به سمت DB نمی‌نویسد (خارج از allowedFields).
        $data = [
            'full_name'        => $this->request->input('full_name'),
            'mobile'           => $this->request->input('mobile'),
            'national_id'      => $this->request->input('national_id'),
            'birth_date'       => $this->request->input('birth_date'),
            'gender'           => $this->request->input('gender'),
            'address'          => $this->request->input('address'),
            'bio'              => $this->request->input('bio'),
            // FIX-M8-09 (راند ۱۶): website/location در validator و سرویس پذیرفته
            // می‌شوند ولی کنترلر هرگز فوروارد نمی‌کرد — ورودی فرم بی‌اثر بود.
            'website'          => $this->request->input('website'),
            'location'         => $this->request->input('location'),
            'current_password' => $this->request->input('current_password'),
        ];

        // Use service for validation and update
        $result = $this->profileService->updateProfileWithValidation($userId, $data);

        if ($result['success']) {
            $this->session->setFlash('success', $result['message']);
        } else {
            $errors = $result['errors'] ?? [];
            $errorMessage = is_array($errors) 
                ? implode('<br>', $errors)
                : $errors;
            $this->session->setFlash('error', $errorMessage);
        }

        redirect('profile');
    }

   public function uploadAvatar(): void
{
        $userId = (int)user_id();

        // Rate Limiting - محدودیت آپلود آواتار
        try {
            rate_limit('upload', 'avatar', "user_{$userId}");
        } catch (\Core\Exceptions\RateLimitExceededException $e) {
            $this->response->json(['success' => false, 'message' => $e->getMessage()], 429);
            return;
        }

    if (!isset($_FILES['avatar']) || ($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $this->response->json(['success' => false, 'message' => 'لطفاً یک تصویر انتخاب کنید'], 400);
        return;
    }

    $uploadService = $this->uploadService;
    $filename = '';
    $oldAvatar = null;

    try {
        $upload = $uploadService->upload(
            $_FILES['avatar'],
            'avatars',
            ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/webp'],
            2097152
        );

        if (!is_array($upload) || empty($upload['success']) || empty($upload['filename']) || empty($upload['path'])) {
            $this->response->json(['success' => false, 'message' => 'خطا در آپلود تصویر'], 400);
            return;
        }

        $filename = (string) $upload['filename'];
        $oldUser = $this->userService->findById((int)$userId);
        if ($oldUser && !empty($oldUser->avatar) && $oldUser->avatar !== 'default-avatar.png') {
            $oldAvatar = $oldUser->avatar;
        }

        $result = $this->profileService->updateProfile($userId, [
            'avatar' => $filename,
        ]);

        if (!$result) {
            if (method_exists($uploadService, 'delete')) {
                $uploadService->delete('avatars/' . $filename);
            }
            $this->logger->info('Avatar update failed', ['user_id' => $userId, 'filename' => $filename]);
            $this->response->json(['success' => false, 'message' => 'خطا در ذخیره‌سازی آواتار در دیتابیس'], 500);
            return;
        }

        if ($oldAvatar && method_exists($uploadService, 'delete')) {
            $uploadService->delete('avatars/' . $oldAvatar);
        }

        $this->logger->info('Avatar uploaded', ['user_id' => $userId]);

        $this->response->json([
            'success' => true,
            'message' => 'تصویر پروفایل با موفقیت بروزرسانی شد',
            'avatar_url' => asset('uploads/' . ltrim((string)$upload['path'], '/'))
        ]);
        return;
    } catch (\Core\Exceptions\HttpResponseException $response) {
        throw $response;
    } catch (\Core\Exceptions\BusinessException $validationError) {
        if ($filename !== '' && method_exists($uploadService, 'delete')) {
            $uploadService->delete('avatars/' . $filename);
        }
        $this->logger->warning('Avatar upload rejected', [
            'user_id' => $userId,
            'reason' => $validationError->getMessage(),
        ]);
        $this->response->json(['success' => false, 'message' => $validationError->getMessage()], 422);
        return;
    } catch (\Throwable $e) {
        if ($filename !== '' && method_exists($uploadService, 'delete')) {
            $uploadService->delete('avatars/' . $filename);
        }
        $this->logger->error('Avatar upload failed', ['error' => $e->getMessage()]);
        $this->response->json(['success' => false, 'message' => 'خطای سرور در آپلود آواتار'], 500);
        return;
    }
}

    public function deleteAvatar(): void
    {
        $userId = (int)user_id();

        $user = $this->userService->findById((int)$userId);

        if (!$user) {
            $this->response->json(['success' => false, 'message' => 'کاربر یافت نشد'], 404);
            return;
        }

        if (empty($user->avatar) || $user->avatar === 'default-avatar.png') {
            $this->response->json(['success' => false, 'message' => 'تصویر پیش‌فرض قابل حذف نیست'], 400);
            return;
        }

        $uploadService = $this->uploadService;

        // 🔒 FIX-M8-03 (راند ۱۶): ترتیبِ حذف — ابتدا DB، سپس فایل.
        // قبلاً فایلِ قبلی پیش از به‌روزرسانی DB حذف می‌شد؛ شکستِ DB رکورد کاربر
        // را به فایلی حذف‌شده اشاره می‌داد (آواتار شکسته). اکنون DB منبعِ حقیقت
        // است: فقط پس از موفقیتِ نوشتن، فایل قدیمی پاک می‌شود؛ شکستِ پاک‌سازی
        // فایل (حالت نادر) فقط ردیف یتیمِ بی‌ضرر در storage می‌گذارد و برای
        // پاک‌سازی دوره‌ای لاگ می‌شود — اثر کاربری صفر.
        $result = $this->profileService->updateProfile($userId, [
            'avatar' => 'default-avatar.png',
        ]);

        if (!$result) {
            $this->response->json(['success' => false, 'message' => 'خطا در بروزرسانی دیتابیس'], 500);
            return;
        }

        $oldAvatarFile = (string)($user->avatar ?? '');
        if ($oldAvatarFile !== '' && $oldAvatarFile !== 'default-avatar.png' && method_exists($uploadService, 'delete')) {
            try {
                $uploadService->delete('avatars/' . $oldAvatarFile);
            } catch (\Throwable $cleanupEx) {
                $this->logger->warning('user.avatar.file_cleanup_failed', [
                    'user_id' => $userId,
                    'file'    => $oldAvatarFile,
                    'error'   => $cleanupEx->getMessage(),
                ]);
            }
        }

        $this->logger->info('Avatar deleted', ['user_id' => $userId]);

        $this->response->json([
            'success'    => true,
            'message'    => 'تصویر پروفایل حذف شد',
            'avatar_url' => asset('uploads/avatars/default-avatar.png')
        ]);
    }

    public function changePassword(): void
    {
        $this->validateCsrf();
        
        $lastAuthTime = $this->session->get(SessionKeys::LAST_AUTH_TIME);
        if (!$lastAuthTime || (\time() - $lastAuthTime > 300)) {
            $this->session->setFlash('error', 'جهت حفظ امنیت حساب کاربری خود، برای تغییر رمز عبور باید در ۵ دقیقه گذشته وارد سیستم شده باشید. لطفاً مجدداً وارد شوید.');
            \redirect('login');
        }

        $userId = user_id();
        
        $currentPassword = str_value($this->request->input('current_password'));
        $newPassword = str_value($this->request->input('new_password'));
        $confirmPassword = str_value($this->request->input('new_password_confirmation'));
        
        if (!$currentPassword || !$newPassword || !$confirmPassword) {
            $this->session->setFlash('error', 'لطفاً تمام فیلدها را پر کنید');
            redirect('profile');
        }
        
        if ($newPassword !== $confirmPassword) {
            $this->session->setFlash('error', 'رمز عبور جدید و تکرار آن یکسان نیستند');
            redirect('profile');
        }
        
        $user = $this->userService->findById((int)$userId);
        if (!$user || !isset($user->password) || !verify_password($currentPassword, $user->password)) {
            $this->session->setFlash('error', 'رمز عبور فعلی اشتباه است');
            redirect('profile');
        }
        
        // FIX-R36-W2-F1 (F-A19c-01): گیتِ {8,} با MED-05 قدیمی (فقط ۸ کاراکتر + کلاس
        // نماد محدود) عبور از PasswordPolicy رسمی پلتفرم بود. ثبت‌نام و ریستِ رمز
        // هر دو از PasswordPolicy (۱۲ کاراکتر + رمزهای رایج + HIBP + شباهت با اطلاعات
        // کاربر) می‌گذرند — مسیر تغییر رمزِ لاگین‌شده (دقیقاً مسیری که بعد از سوءظن
        // به نفوذ استفاده می‌شود) باید همان سیاست را اعمال کند. پیام‌ها همان
        // پیام‌های فارسیِ خود سیاست‌اند (هم‌سنگ ثبت‌نام).
        $policyErrors = \App\Validators\PasswordPolicy::validate($newPassword, array_filter([
            'username'  => isset($user->username) ? (string)$user->username : null,
            'email'     => isset($user->email) ? (string)$user->email : null,
            'full_name' => isset($user->full_name) ? (string)$user->full_name : null,
        ], static fn($v): bool => is_string($v) && $v !== ''));
        if ($policyErrors !== []) {
            $this->session->setFlash('error', implode('<br>', $policyErrors));
            redirect('profile');
        }
        
        // 🛡️ FIX-PASSWORD-REMEMBER-REVOKE (H-03 consistency): قبلاً مستقیماً
        // userService->update() صدا زده می‌شد که remember_token و
        // remember_expires_at را باطل نمی‌کند؛ یعنی کوکی «مرا به خاطر بسپار»
        // روی دستگاه دیگرِ کاربر حتی بعد از تغییر رمز معتبر می‌ماند.
        // UserService::changePassword() همان هش + ابطال توکن remember را
        // به‌صورت اتمیک انجام می‌دهد (همان متدی که PasswordRecoveryService
        // و auth_helper استفاده می‌کنند).
        $result = $this->userService->changePassword((int)$userId, $newPassword);
        
        if ($result) {
            // ✅ اصلاح logger
            $this->logger->info('Password changed', ['user_id' => $userId]);
            
            // ✅ Invalidate other sessions after password change
            $sessionId = session_id();
            $this->sessionService->invalidateAllUserSessions((int)$userId, is_string($sessionId) ? $sessionId : null);

            // 🛡️ FIX-M11-R22-3: تغییرِ آگاهانهٔ رمز → ابطالِ توکن‌های API —
            // توکنِ دزدیده‌شده تا ۹۰ روز زنده نمی‌ماند (هم‌سو با ریستِ ایمیلی).
            try {
                $this->userService->revokeApiTokensForPasswordChange((int)$userId);
            } catch (\Throwable $tokenEx) {
                $this->logger->error('password_change.token_revoke_failed', ['user_id' => $userId, 'error' => $tokenEx->getMessage()]);
            }

            // 🔒 FIX-M8-02 (راند ۱۶): چرخش از «مسیر مرکزی» Core::Session —
            // قبلاً session_regenerate_id خام ردیف user_sessions نشستِ جاری را با
            // شناسهٔ قدیمی جا می‌گذاشت؛ بررسی دوره‌ای (هر ۱۲۰ ثانیه) با شناسهٔ جدید
            // ردیفی نمی‌یافت و کاربر تا ۲ دقیقه بعد بیرون پرت می‌شد. regenerate
            // مرکزی ردیف را به شناسهٔ جدید تغییرنشان می‌دهد (syncUserSessionRowAfterRotation).
            $this->session->regenerate(true);

            // ✅ Regenerate CSRF after sensitive action
            $this->csrf->regenerate();

            $this->session->setFlash('success', 'رمز عبور با موفقیت تغییر یافت');
        } else {
            $this->session->setFlash('error', 'خطا در تغییر رمز عبور');
        }
        
        redirect('profile');
    }
}
