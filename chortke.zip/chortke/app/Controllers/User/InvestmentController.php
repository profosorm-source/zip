<?php
// app/Controllers/User/InvestmentController.php

namespace App\Controllers\User;

use App\Models\Investment;
use App\Models\TradingRecord;
use App\Models\InvestmentProfit;
use App\Models\InvestmentWithdrawal;
use App\Services\InvestmentService;
use App\Policies\RateLimitPolicy;
use App\Controllers\User\BaseUserController;
use App\Contracts\WalletServiceInterface;
use App\Validators\Requests\CreateInvestmentRequest;
use App\Validators\Requests\WithdrawInvestmentRequest;

class InvestmentController extends BaseUserController
{
    private \App\Models\TradingRecord $tradingRecordModel;
    private \App\Models\InvestmentWithdrawal $investmentWithdrawalModel;
    private \App\Models\InvestmentProfit $investmentProfitModel;
    private \App\Models\Investment $investmentModel;
    private InvestmentService $investmentService;
    /** 🧹 DI-CLEANUP (2026-08-24): به‌جای app(Redis::class) در بدنه‌ی متد. */
    private \Core\Redis $redis;

    public function __construct(
        \App\Models\Investment $investmentModel,
        \App\Models\InvestmentProfit $investmentProfitModel,
        \App\Models\InvestmentWithdrawal $investmentWithdrawalModel,
        \App\Models\TradingRecord $tradingRecordModel,
        \App\Services\InvestmentService $investmentService,
        \Core\Redis $redis,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->investmentService = $investmentService;
        $this->redis = $redis;
        $this->investmentModel = $investmentModel;
        $this->investmentProfitModel = $investmentProfitModel;
        $this->investmentWithdrawalModel = $investmentWithdrawalModel;
        $this->tradingRecordModel = $tradingRecordModel;
    }

    /**
     * لودر مشترک داده‌های هاب تک‌صفحه‌ای سرمایه‌گذاری.
     * 🛡️ تکمیل معماری هاب: همه اکشن‌های نمای این ماژول همان ویو هاب را رندر
     * می‌کنند؛ بنابراین داده‌ی همه پنل‌ها (نمای کلی، ویزارد ثبت، تاریخچه کامل،
     * برداشت‌ها و بازار) باید از یک لودر واحد تأمین شود تا هیچ تب خالی نباشد.
     *
     * @return array<string, mixed>
     */
    private function hubData(int $userId, int $profitPage = 1): array
    {
        $activeInvestment = $this->investmentModel->getActiveByUser($userId);

        // canWithdraw — نیاز به سرمایه‌گذاری فعال دارد
        $canWithdraw = $activeInvestment
            ? $this->investmentModel->canWithdraw($userId)
            : ['allowed' => false, 'reason' => ''];

        // آخرین ۵ رکورد سود/ضرر (پنل نمای کلی)
        $profitHistory = $this->investmentProfitModel->getByUser($userId, 5, 0);

        // تاریخچه کامل سود/زیان با صفحه‌بندی (پنل تاریخچه)
        $perPage = 20;
        $offset  = (max(1, $profitPage) - 1) * $perPage;
        $profits    = $this->investmentProfitModel->getByUser($userId, $perPage, $offset);
        $totalProfits = $this->investmentProfitModel->countByUser($userId);

        // آخرین ۱۰ ترید بسته‌شده (عمومی برای همه کاربران)
        $recentTrades = $this->tradingRecordModel->getRecentClosed(10);

        // درخواست‌های برداشت کاربر
        $withdrawals = $this->investmentWithdrawalModel->getByUser($userId, 5, 0);

        $userObj = $this->loadCurrentUserOrRedirect();

        return [
            'user'             => $userObj,
            'activeInvestment' => $activeInvestment,
            'canWithdraw'      => $canWithdraw,
            'profitHistory'    => $profitHistory,
            'recentTrades'     => $recentTrades,
            'withdrawals'      => $withdrawals,
            'settings'         => $this->investmentService->getSettings(),
            'isDepositLocked'  => $this->investmentModel->isDepositLocked($userId),
            'profits'          => $profits,
            'total'            => $totalProfits,
            'totalPages'       => (int) ceil($totalProfits / $perPage),
            'currentPage'      => max(1, $profitPage),
        ];
    }

    /**
     * صفحه اصلی سرمایه‌گذاری (هاب تک‌صفحه‌ای: overview / create / profit / withdrawals / market)
     */
    public function index(): void
    {
        $userId = int_value(session()->get(\App\Constants\SessionKeys::USER_ID) ?: 1);
        $this->view('user/investment/index', $this->hubData($userId));
    }

    /**
     * صفحه ثبت سرمایه‌گذاری — پنل create همان هاب؛ ریدایرکت‌های محافظ فقط برای
     * دسترسی مستقیم به این URL معتبرند (فرم واقعی در store() اعتبارسنجی می‌شود).
     */
    public function create(): void
    {
        $userId = (int) user_id();

        if ($this->investmentModel->hasActiveInvestment($userId)) {
            session()->setFlash('error', 'شما یک پلن فعال دارید. امکان ایجاد پلن جدید نیست.');
            redirect(url('/investment'));
        }

        if ($this->investmentModel->isDepositLocked($userId)) {
            session()->setFlash('error', 'به دلیل برداشت اخیر، فعلاً امکان سرمایه‌گذاری جدید ندارید.');
            redirect(url('/investment'));
        }

        $this->view('user/investment/create', $this->hubData($userId));
    }

    /**
     * ثبت سرمایه‌گذاری (POST - AJAX)
     */
    public function store(): void
    {
        $userIdForLock = (int)user_id();
        $lockKey = null;
        $lockAcquired = false;
        $lockClient = null;
        if ($userIdForLock > 0) {
            try {
                $redis = $this->redis;
                if ($redis->isAvailable()) {
                    $lockKey = 'lock:user:' . $userIdForLock . ':' . md5('/investment/store');
                    $routeLockKey = 'lock:route:' . md5('/investment/store');
                    $client = $redis->getClient();
                    if (!$client instanceof \Redis) {
                        throw new \RuntimeException('Redis lock client is unavailable.');
                    }
                    $lockClient = $client;
                    if ($client->exists($lockKey) || $client->exists($routeLockKey)) {
                        $this->response->json([
                            'success' => false,
                            'message' => 'درخواست قبلی شما در حال پردازش است. لطفا چند لحظه صبر کنید.'
                        ], 429);
                        return;
                    }
                    $lockAcquired = (bool)$client->set($lockKey, '1', ['NX', 'EX' => 3]);
                }
            } catch (\Throwable $e) {
                $lockKey = null;
            }
        }

        try {
        $input = !empty($this->request->json()) ? $this->request->json() : $this->request->all();

        $validator = new CreateInvestmentRequest($input);
        $validator->validate();

        if ($validator->fails()) {
            $this->response->json([
                'success' => false,
                'message' => 'اطلاعات ورودی نامعتبر است.',
                'errors'  => $validator->errors(),
            ], 422);
        }

        $data = $validator->safeValidated(); // FIX-X16

        RateLimitPolicy::enforce('investment_create', (int) user_id(), is_ajax());

        $result = $this->investmentService->createInvestment((int) user_id(), [
            'amount'        => str_value($data['amount'] ?? 0),
            'risk_accepted' => int_value($data['risk_accepted'] ?? 0),
            'idempotency_key' => $data['idempotency_key'] ?? null,
        ]);

        $this->response->json($result, $result['success'] ? 200 : 422);
        } finally {
            if ($lockAcquired && $lockKey) {
                try {
                    $lockClient?->del($lockKey);
                } catch (\Throwable $e) {}
            }
        }
    }
    /**
     * درخواست برداشت (POST - AJAX)
     */
    public function withdraw(): void
    {
        $json = $this->request->json();
        $input = !empty($json) ? $json : $this->request->all();

        $validator = new WithdrawInvestmentRequest($input);
        $validator->validate();

        if ($validator->fails()) {
            $this->response->json([
                'success' => false,
                'message' => 'نوع برداشت را انتخاب کنید.',
                'errors'  => $validator->errors(),
            ], 422);
        }

        $data = $validator->safeValidated(); // FIX-X16

        $result = $this->investmentService->requestWithdrawal((int) user_id(), [
            'withdrawal_type' => $data['withdrawal_type'],
        ]);

        $this->response->json($result, $result['success'] ? 200 : 422);
    }

    /**
     * تاریخچه سود/ضرر — پنل profit همان هاب تک‌صفحه‌ای
     */
    public function profitHistory(): void
    {
        $userId = (int) user_id();
        $page   = max(1, $this->request->int('page', 1));

        $this->view('user/investment/profit-history', $this->hubData($userId, $page));
    }
}