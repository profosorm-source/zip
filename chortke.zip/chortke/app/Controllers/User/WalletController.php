<?php

namespace App\Controllers\User;

use App\Contracts\WalletServiceInterface;
use App\Controllers\User\BaseUserController;

class WalletController extends BaseUserController
{
    private WalletServiceInterface $walletService;
    private \App\Models\Escrow $escrowModel;

    public function __construct(
        WalletServiceInterface $walletService,
        ?\App\Models\Escrow $escrowModel = null,
        ?\App\Contracts\LoggerInterface $logger = null
    ) {
        parent::__construct(null, null, null, null, $logger);
        $this->walletService = $walletService;
        // 🛡️ FIX-FINANCE-HUB-COMPLETION: صندوق امانات هم دادهٔ همان هاب مالی را می‌دهد
        // (Container خودکار resolve می‌کند؛ پارامتر nullable برای سازگاری تست‌های موجود).
        $this->escrowModel = $escrowModel ?? $this->resolveFromContainer(\App\Models\Escrow::class);
    }

    /**
     * لودر مشترک داده‌های هاب تک‌صفحه‌ای مالی.
     * 🛡️ تکمیل معماری هاب: نمای کلی، انتخاب روش واریز، انتقال اعتبار، صندوق امانات،
     * ایجاد معامله امن و تاریخچه تراکنش‌ها، همه پنل همین صفحه هستند و دادهٔ همهٔ
     * پنل‌ها از یک لودر واحد تأمین می‌شود.
     *
     * @return array<string, mixed>
     */
    private function hubData(int $userId): array
    {
        $summary = $this->walletService->getWalletSummary($userId);
        $siteCurrency = config('site_currency', 'irt');

        // داده‌های پنل تاریخچه (فیلتر + صفحه‌بندی از همان ریکوئست)
        $page = max(1, $this->request->int('page', 1));
        $type = $this->request->get('type');
        $currency = $this->request->get('currency');
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $filters = ['type' => $type, 'currency' => $currency];

        $transactions = $this->walletService->getUserTransactions(
            $userId,
            $limit,
            $offset,
            $filters
        );

        $total = $this->walletService->countUserTransactions($userId, $filters);
        $totalPages = (int)\ceil($total / $limit);

        // داده‌های پنل صندوق امانات (جدول + طرف‌های معامله)
        // BUGFIX-CTRL-RAW-SQL-2026-06: JOIN encapsulated in Escrow::getUserEscrowsWithParties().
        $escrows = $this->escrowModel->getUserEscrowsWithParties((int)$userId, 50);

        return [
            'summary'      => $summary,
            'siteCurrency' => $siteCurrency,
            'transactions' => $transactions,
            'currentPage'  => $page,
            'totalPages'   => $totalPages,
            'type'         => $type,
            'currency'     => $currency,
            'escrows'      => $escrows,
        ];
    }

    /**
     * صفحه اصلی کیف پول (هاب تک‌صفحه‌ای: overview / deposit / transfer / escrows / escrow-create / history)
     */
    public function index(): void
    {
        $userId = (int)$this->userId();
        view('user.wallet.index', $this->hubData($userId));
    }

    /**
     * صفحه انتخاب روش افزایش موجودی — پنل deposit همان هاب
     */
    public function depositIndex(): void
    {
        $userId = (int)$this->userId();
        view('user.wallet.deposit-select', $this->hubData($userId));
    }

    /**
     * تاریخچه تراکنش‌ها — پنل history همان هاب
     */
    public function history(): void
    {
        $userId = (int)$this->userId();
        view('user.wallet.history', $this->hubData($userId));
    }

    /**
     * فرم انتقال اعتبار P2P — پنل transfer همان هاب
     * 🛡️ FIX-FINANCE-HUB-COMPLETION: قبلاً صفحهٔ جدول بیرون از هاب بود و از هیچ
     * کجای مرکز مالی لینک نمی‌شد (صفحهٔ ته‌افتاده). اکنون پنل هاب است؛
     * submit همچنان به TransferController::store می‌رود.
     */
    public function transferIndex(): void
    {
        $userId = (int)$this->userId();
        view('user.wallet.transfer', $this->hubData($userId));
    }

    /**
     * صندوق امانات (لیست معاملات) — پنل escrows همان هاب
     */
    public function escrowsIndex(): void
    {
        $userId = (int)$this->userId();
        view('user.wallet.escrows', $this->hubData($userId));
    }

    /**
     * فرم ایجاد معامله امن — پنل escrow-create همان هاب
     */
    public function escrowCreateIndex(): void
    {
        $userId = (int)$this->userId();
        view('user.wallet.escrow-create', $this->hubData($userId));
    }
}
