<?php

namespace App\Controllers;

use App\Services\Payment\PaymentService;
use App\Contracts\WalletServiceInterface;
use App\Services\ReconciliationService;
use App\Controllers\BaseController;
use Core\Exceptions\ValidationException;
use Core\Exceptions\NotFoundException;
use Core\Exceptions\BusinessException;

class PaymentController extends BaseController
{
    private WalletServiceInterface $walletService;
    private PaymentService $paymentService;
    private ReconciliationService $reconciliationService;
    private \Core\Cache $cache;

    public function __construct(
        WalletServiceInterface $walletService,
        PaymentService $paymentService,
        ReconciliationService $reconciliationService,
        \Core\Cache $cache
    , ?\App\Contracts\LoggerInterface $logger = null) {
        parent::__construct(null, null, null, null, $logger);
        $this->walletService = $walletService;
        $this->paymentService = $paymentService;
        $this->reconciliationService = $reconciliationService;
        $this->cache = $cache;
    }

    /**
     * درخواست پرداخت آنلاین
     */
    public function request(): void
    {
        if (!$this->userId()) {
            $this->session->setFlash('error', 'ابتدا وارد شوید');
            $this->response->redirect(url('login'));
            return;
        }

        $userId = $this->userId();

        // دریافت داده‌ها
        $data = [
            'gateway' => $this->request->input('gateway'),
            'amount' => $this->request->input('amount'),
            'idempotency_key' => $this->request->input('idempotency_key'),
        ];

        // اعتبارسنجی با Core\Validator
        $validator = \Core\Validator::create($data, [
            'gateway' => 'required|string|in:zarinpal,idpay,nextpay',
            'amount' => 'required|numeric|min:1000',
            'idempotency_key' => 'required|string|min:10|max:128',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $firstError = reset($errors);
            $msg = is_array($firstError) ? reset($firstError) : $firstError;
            $this->session->setFlash('error', $msg ?: 'داده‌های ورودی نامعتبر است');
            $this->response->redirect(url('wallet/deposit'));
            return;
        }

        $validated = $validator->data();

        try {
            $amount = (float)$validated['amount'];
            $bankCardId = (int)($this->request->input('bank_card_id') ?? 0);
            $idempotencyKey = (string)$validated['idempotency_key'];

        $clientIp = function_exists('get_client_ip') ? get_client_ip() : (string)($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
        $userAgent = function_exists('get_user_agent') ? get_user_agent() : (string)($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown');

        $result = $this->paymentService->create(
            $userId,
            (string)$data['gateway'],
            $amount,
            $bankCardId,
            $idempotencyKey,
            $clientIp,
            $userAgent
        );

    $this->response->redirect($result['payment_url']);
} catch (ValidationException $e) {
    $this->session->setFlash('error', 'داده‌های ورودی نامعتبر: ' . implode(', ', $e->getErrors()));
    $this->response->redirect(url('wallet/deposit'));
} catch (NotFoundException $e) {
    $this->session->setFlash('error', $e->getMessage());
    $this->response->redirect(url('wallet/deposit'));
} catch (BusinessException $e) {
    $this->session->setFlash('error', $e->getMessage());
    $this->response->redirect(url('wallet/deposit'));
} catch (\Throwable $e) {
    $this->logger->error('payment.request.failed', [
        'channel' => 'payment',
        'user_id' => $userId,
        'error' => $e->getMessage(),
        'exception' => get_class($e),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
    ]);

    $this->session->setFlash('error', 'خطا در اتصال به درگاه پرداخت');
    $this->response->redirect(url('wallet/deposit'));
}
    }

    /**
     * بازگشت از درگاه پرداخت
     */
    public function callback(): void
    {
        $gateway = (string)(
            $this->request->get('gateway')
            ?? $this->request->param('gateway')
            ?? ''
        );

        if ($gateway === '') {
            $this->session->setFlash('error', 'درگاه نامعتبر است');
            $this->response->redirect(url('wallet'));
            return;
        }

        if (!$this->request->isPost()) {
            $this->logger->warning('payment.callback.invalid_method', [
                'gateway' => $gateway,
                'method' => $this->request->method(),
                'ip' => get_client_ip()
            ]);

            $this->response->status(405)->json([
                'success' => false,
                'message' => 'Callback must be delivered via POST request'
            ]);
            return;
        }

        try {
            $clientIp = function_exists('get_client_ip') ? get_client_ip() : (string)($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
            $userAgent = function_exists('get_user_agent') ? get_user_agent() : (string)($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown');

            $result = $this->paymentService->callback(
                $gateway,
                $this->request->all(),
                $this->userId(),
                $clientIp,
                $userAgent
            );

            if (!empty($result['success'])) {
                $this->session->setFlash('success', $result['message'] ?? 'پرداخت با موفقیت انجام شد');
            } else {
                $this->session->setFlash('error', $result['message'] ?? 'پرداخت ناموفق بود');
            }
        } catch (\Throwable $e) {
            $this->logger->error('payment.callback.failed', [
                'channel' => 'payment',
                'gateway' => $gateway,
                'error' => $e->getMessage(),
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            $this->session->setFlash('error', 'پرداخت ناموفق بود');
        }

        $this->response->redirect(url('wallet'));
    }

    public function callbackGet(): void
    {
        $gateway = (string)(
            $this->request->param('gateway')
            ?? $this->request->get('gateway')
            ?? 'unknown'
        );

        // Log suspicious activity
        $this->logger->warning('payment.callback.get_attempt_blocked', [
            'gateway' => $gateway,
            'ip' => get_client_ip(),
            'user_agent' => get_user_agent(),
            'referer' => $_SERVER['HTTP_REFERER'] ?? 'none',
        ]);

        // Block IP after 3 attempts in 1 hour (3600 seconds)
        $ipKey = "callback_get_abuse:" . get_client_ip();
        $attempts = (int)$this->cache->get($ipKey, 0);
        $this->cache->setSeconds($ipKey, $attempts + 1, 3600);

        if ($attempts >= 3) {
            $this->logger->critical('payment.callback.get_abuse_detected', [
                'ip' => get_client_ip(),
                'attempts' => $attempts + 1
            ]);

            $this->response->status(403)->json([
                'success' => false,
                'message' => 'Access forbidden due to suspicious activity'
            ]);
            return;
        }

        $this->response->status(405)->json([
            'success' => false,
            'message' => 'Method not allowed. Callbacks must use POST.'
        ]);
    }

    /**
     * Master E2E Functional Browser Verification specifically for Section 8.5 Scheduled Payment Operations (SP-01 to SP-04 🆕) Trapped context
     */
    public function verifyScheduledPaymentSection85(): void
    {
        $db = \Core\Database::getInstance();
        $results = [];
        $salt = random_int(10000, 99999);

        // Helper to setup a test wallet
        $setupWallet = function(int $userId, float $balanceIrt) use ($db) {
            $db->query("INSERT IGNORE INTO users (id, email, full_name, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())", [$userId, "user_sp_{$userId}@chortke.ir", "Scheduled User {$userId}"]);
            $db->query("INSERT IGNORE INTO wallets (user_id, balance_irt) VALUES (?, ?)", [$userId, $balanceIrt]);
            $db->query("UPDATE wallets SET balance_irt = ? WHERE user_id = ?", [$balanceIrt, $userId]);
        };

        $scheduledPaymentService = app(\App\Services\ScheduledPaymentService::class);

        // ─── 1. SP-01 🆕: Create Scheduled Payment -> Schedule recorded in DB table ───
        try {
            $u01 = 8501 + $salt;
            $setupWallet($u01, 50000.0);

            $res01 = $scheduledPaymentService->createSchedule([
                'user_id' => $u01,
                'amount' => '10000',
                'currency' => 'irt',
                'frequency' => 'weekly',
                'next_run_at' => date('Y-m-d H:i:s', time() + 3600),
                'description' => 'شارژ زمان‌بندی‌شده هفته‌گی',
                'idempotency_key' => "sp01_{$salt}_" . uniqid(),
            ]);

            $passed = ($res01 !== null) && ($res01->status === 'active');
            $results['SP-01'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی SP-01 🆕: ایجاد پرداخت زمان‌بندی‌شده (Create Schedule)',
                'details' => "شناسه کاربر: <code>کاربر #{$u01}</code><br>تناوب (Frequency): <code>هفته‌گی (weekly)</code><br>بهای تراکنش: <code>10,000 IRT</code><br>وضعیت در دیتابیس (DB Table): <code>" . ($res01 ? "ثبت موفق با شناسه #{$res01->id} و وضعیت {$res01->status}" : 'ناموفق') . "</code>",
                'message' => $passed ? 'موفق: جدول زمان‌بندی دیتابیس (scheduled_payments) با موفقیت و به طور Idempotent مقداردهی گردید.' : 'خطا در ثبت Schedule.'
            ];
        } catch (\Throwable $e) {
            $results['SP-01'] = ['status' => 'FAILED', 'title' => 'SP-01 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 2. SP-02 🆕: Execute Due Scheduled Payment -> Due payment executes, balance reduced ───
        try {
            $u02 = 8502 + $salt;
            $setupWallet($u02, 50000.0);

            // Insert active due Scheduled Payment
            $dueSchedId = (int)$db->insert(
                "INSERT INTO scheduled_payments (user_id, amount, currency, frequency, next_run_at, status, description, created_at, updated_at) VALUES (?, '15000', 'irt', 'monthly', NOW() - INTERVAL 1 HOUR, 'active', 'پرداخت قسط', NOW(), NOW())",
                [$u02]
            );

            // Execute Due Payments
            $runRes = $scheduledPaymentService->processDuePayments(10);

            // Check final balance
            $bal02 = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u02])->balance_irt;

            $passed = ($runRes['processed'] >= 1) && ($bal02 === 35000.0);
            $results['SP-02'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی SP-02 🆕: اجرای زمان‌بندی رسیده (Execute Due Schedule)',
                'details' => "موجودی اولیه کیف پول: <code>50,000 IRT</code><br>مبلغ زمان‌بندی رسیده: <code>15,000 IRT</code><br>نتیجه موتور زمان‌بندی: <code>پرداخت اتوماتیک اجرا شد (شناسه #{$dueSchedId})</code><br>موجودی نهایی پس از کسر موفق: <code>" . number_format($bal02) . " IRT</code>",
                'message' => $passed ? 'موفق: سیستم زمان‌بندی‌های فرارسیده را شناسایی و مبالغ را با موفقیت از کیف پول کاربران کسر کرد.' : 'خطا در اجرای Schedule یا کسر وجه.'
            ];
        } catch (\Throwable $e) {
            $results['SP-02'] = ['status' => 'FAILED', 'title' => 'SP-02 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 3. SP-03 🆕: Execute due payment with insufficient balance -> Failure recorded in DB, notif sent ───
        try {
            $u03 = 8503 + $salt;
            $setupWallet($u03, 2000.0); // Only 2,000 IRT

            // Insert due Scheduled Payment for User 03 requiring 20,000 IRT
            $failSchedId = (int)$db->insert(
                "INSERT INTO scheduled_payments (user_id, amount, currency, frequency, next_run_at, status, description, created_at, updated_at) VALUES (?, '20000', 'irt', 'monthly', NOW() - INTERVAL 1 HOUR, 'active', 'پرداخت وام', NOW(), NOW())",
                [$u03]
            );

            // Execute
            $runRes03 = $scheduledPaymentService->processDuePayments(10);

            // Verify balance untouched
            $bal03 = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u03])->balance_irt;

            // Verify Schedule status became 'failed' in MySQL
            $schedObj03 = $db->fetch("SELECT status FROM scheduled_payments WHERE id = ?", [$failSchedId]);

            // Verify official Failure Notification recorded
            $notifObj = $db->fetch("SELECT * FROM notifications WHERE user_id = ? AND type = 'scheduled_payment_failed' ORDER BY id DESC LIMIT 1", [$u03]);

            $passed = ($bal03 === 2000.0) && ($schedObj03 && $schedObj03->status === 'failed') && ($notifObj !== false);
            $results['SP-03'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی SP-03 🆕: اجرا با موجودی ناکافی (Insufficient Balance Execution Trapped)',
                'details' => "موجودی فعلی کاربر: <code>2,000 IRT</code><br>بهای زمان‌بندی رسیده: <code>20,000 IRT</code><br>وضعیت بروزشده در دیتابیس: <code>" . ($schedObj03 ? "ثبت وضعیت {$schedObj03->status}" : 'نامعلوم') . "</code><br>وضعیت اعلان (Notification): <code>" . ($notifObj ? "ارسال موفق نوتیفیکیشن با عنوان «{$notifObj->title}»" : 'ناموفق') . "</code>",
                'message' => $passed ? 'موفق: زمان‌بندی به دلیل موجودی ناکافی مسدود و وضعیت شکست (Failed) همراه با ارسال Notif ثبت شد.' : 'خطا در مسدودسازی یا ارسال Notif.'
            ];
        } catch (\Throwable $e) {
            $results['SP-03'] = ['status' => 'FAILED', 'title' => 'SP-03 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── 4. SP-04 🆕: Repeat execution / Concurrency Patchwork -> Absolute Idempotency Single execution ───
        try {
            $u04 = 8504 + $salt;
            $setupWallet($u04, 100000.0);

            // Insert due one_time Scheduled Payment
            $idemSchedId = (int)$db->insert(
                "INSERT INTO scheduled_payments (user_id, amount, currency, frequency, next_run_at, status, description, created_at, updated_at) VALUES (?, '25000', 'irt', 'one_time', NOW() - INTERVAL 1 HOUR, 'active', 'پرداخت تکی ادمین', NOW(), NOW())",
                [$u04]
            );

            // Run 1st time
            $scheduledPaymentService->processDuePayments(10);
            $bal04_Mid = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u04])->balance_irt;

            // Run 2nd time to prove network patchwork repetition is trapped by our atomic Idempotency locks
            $scheduledPaymentService->processDuePayments(10);
            $bal04_Final = (float)$db->fetch("SELECT balance_irt FROM wallets WHERE user_id = ?", [$u04])->balance_irt;

            $passed = ($bal04_Mid === 75000.0) && ($bal04_Final === 75000.0);
            $results['SP-04'] = [
                'status'  => $passed ? 'PASSED' : 'FAILED',
                'title'   => 'سناریوی SP-04 🆕: تکرار Patchwork و تضمین مطلق اجرای یکباره (Idempotency SINGLE Guarantee)',
                'details' => "موجودی اولیه کاربر: <code>100,000 IRT</code><br>بهای زمان‌بندی: <code>25,000 IRT</code><br>موجودی پس از اولین اجرا: <code>" . number_format($bal04_Mid) . " IRT</code><br>موجودی پس از اجرای مجدد (Patchwork Double Execution Loop): <code>" . number_format($bal04_Final) . " IRT</code>",
                'message' => $passed ? 'موفق: مکانیزم ایدِمپوتنسی (Idempotency) سیستمی، از تکرار اجرا در صورت خطا یا ریکوئست تکراری جلوگیری کرد و پرداخت دقیقاً یکبار اجرا شد.' : 'خطای تکرار اجرا.'
            ];
        } catch (\Throwable $e) {
            $results['SP-04'] = ['status' => 'FAILED', 'title' => 'SP-04 🆕', 'details' => $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(), 'message' => 'خطای سیستمی'];
        }

        // ─── Render View ───
        $this->view('system/scheduled_payments/verification', [
            'title'   => 'ارزیابی حرفه‌ای و مرورگرمحور سیستم پرداخت زمان‌بندی‌شده (Section 8.5 Scheduled Payment Verification 🆕)',
            'results' => $results,
        ]);
    }
}
