<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use Core\Cache;
use App\Contracts\LoggerInterface;
use App\Services\Wallet\WalletMutationService;

/**
 * WithdrawalTimeoutJob
 * 
 * اسکن خودکار برداشت‌های گیر کرده (stuck) که بیش از X ساعت در وضعیت
 * 'pending' مانده‌اند؛ لغو و بازگشت وجه + ثبت گزارش بررسی ادمین.
 * 
 * در Cron: هر ۱۰ دقیقه اجرا می‌شود
 * 
 * ── سیاست‌های محصول (FIX-S35-B14-P1/P2 — تأیید مالک محصول) ──────────
 * P1) وضعیت 'processing' یعنی «انتقال بیرونی آغاز شده، نتیجهٔ نامعلوم»:
 *     هرگز خودکار لغو/بازگشت نمی‌شود (لغو بر پایهٔ سنِ created_at می‌تواند
 *     پرداخت دوگانه بسازد: وجه هم به کیف برگردد هم حواله برسد). برداشت
 *     stuckِ processing فقط پروندهٔ ادمین می‌سازد/ارجاع می‌دهد (escalated).
 *     لغو processing تنها با تصمیم انسانی ادمین یا webhook نتیجه‌محور
 *     (ReconciliationService::processFailedPayment) مجاز است. مسیر
 *     CLI auto-fix (autoResolveStuck) از قبل فقط pending را لمس می‌کند.
 * P2) کیف پول منجمد = هرگز بازگشت خودکار: چک انجماد علاوه بر precheck
 *     بیرونی، «داخل» تراکنش بازگشت با SELECT … FOR UPDATE تکرار می‌شود
 *     تا پنجرهٔ TOCTOU (انجماد بین چک و refund) بسته شود؛ در این حالت
 *     پرونده escalated می‌شود و تصمیم با ادمین است.
 */
class WithdrawalTimeoutJob
{
    /**
     * FIX-R18-M9: بدترین زمان اجرای موردانتظار (اسکن کل withdrawals + لغو/بازگشت وجه).
     * QueueWorker از این مقدار برای گسترش visibility (timeoutSeconds*2) استفاده می‌کند.
     */
    public int $timeoutSeconds = 600;

    private Database $db;
    private LoggerInterface $logger;
    private WalletMutationService $walletMutationService;
    private ?\App\Services\Settings\AppSettings $appSettings = null;

    /** ساعت‌هایی بعد از آن برداشت stuck محسوب می‌شود */
    private const STUCK_HOURS = 2;
    
    /** حداکثر تعداد برداشتی که در هر اجرا اسکن می‌شود */
    private const MAX_SCAN = 200;

    public function __construct(
        Database $db,
        LoggerInterface $logger,
        WalletMutationService $walletMutationService,
        ?\App\Services\Settings\AppSettings $appSettings = null
    ) {
        $this->db = $db;
        $this->logger = $logger;
        $this->walletMutationService = $walletMutationService;
        // 🛡️ FIX #3 (P2): آستانهٔ timeout از تنظیمات پنل ادمین خوانده می‌شود
        // (withdrawal_stuck_timeout_hours) تا SLA عملیاتی بدون تغییر کد قابل
        // تنظیم باشد؛ پیش‌فرض همان ۲ ساعت قبلی است.
        $this->appSettings = $appSettings;
    }

/**
 * @param array<string, mixed> $data
 * @return array{scanned:int, cancelled:int, escalated:int, processing_flagged:int, message:string}
 */
public function handle(array $data = []): array
    {
        $configuredHours = $this->appSettings !== null
            ? int_value($this->appSettings->get('withdrawal_stuck_timeout_hours', self::STUCK_HOURS))
            : self::STUCK_HOURS;
        if ($configuredHours < 1) {
            $configuredHours = self::STUCK_HOURS;
        }
        $hours = max(1, min(168, int_value($data['stuck_hours'] ?? $configuredHours)));
        $limit = max(1, min(self::MAX_SCAN, int_value($data['limit'] ?? self::MAX_SCAN)));

        try {
            // پیدا کردن برداشت‌هایی که بیش از X ساعت در وضعیت pending/processing مانده‌اند
            $stuckWithdrawals = $this->db->query("
                SELECT id, user_id, amount, currency, status, transaction_id, created_at,
                       TIMESTAMPDIFF(HOUR, created_at, NOW()) AS stuck_hours
                FROM withdrawals
                WHERE status IN ('pending', 'processing')
                  AND created_at < DATE_SUB(NOW(), INTERVAL ? HOUR)
                ORDER BY created_at ASC
                LIMIT ?
            ", [$hours, $limit])->fetchAll(\PDO::FETCH_OBJ);

            if (empty($stuckWithdrawals)) {
                // FIX-PSTAN: بازگشت زودهنگام همهٔ کلیدهای قرارداد را دارد (قبلاً escalated/processing_flagged غایب بودند)
                return ['scanned' => 0, 'cancelled' => 0, 'escalated' => 0, 'processing_flagged' => 0, 'message' => 'بدون برداشت گیر کرده'];
            }

            // ✅ N+1 FIX: یک query برای پیدا کردن همه withdrawal_ids که قبلاً flag شدند
            $allIds         = array_map(fn($w) => (int)$w->id, $stuckWithdrawals);
            $placeholders   = implode(',', array_fill(0, count($allIds), '?'));
            $alreadyFlagged = $this->db->fetchAll(
                "SELECT withdrawal_id FROM withdrawal_reviews WHERE withdrawal_id IN ({$placeholders})",
                $allIds
            ) ?: [];
            $flaggedSet = array_flip(array_column($alreadyFlagged, 'withdrawal_id'));
            // ────────────────────────────────────────────────────────────

            $cancelledCount = 0;
            $escalatedCount = 0;
            $processingFlagged = 0; // FIX-S35-B14-P1: برداشت processing پرچم‌شده (هرگز لغو خودکار)
            foreach ($stuckWithdrawals as $w) {
                // ۱. ثبت گزارش برای ادمین — بدون SELECT اضافه
                if (!isset($flaggedSet[(int)$w->id])) {
                    // FIX-R19-A6-9: درجِ گزارش ادمین اکنون اتمیک است
                    // (INSERT…SELECT…WHERE NOT EXISTS — الگوی ReportVitrineListingJob:85-100).
                    // پیش از این flaggedSet فقط یک‌بار پیش از حلقه خوانده می‌شد (check-then-insert) و
                    // دو کرنِ هم‌پوشان هر دو عبور می‌کردند و ردیف گزارشِ تکراری می‌نوشتند
                    // (withdrawal_reviews فقط PRIMARY دارد، UNIQUE(withdrawal_id) وجود ندارد).
                    // rowCount=0 یعنی کرن هم‌زمان همان لحظه ثبتش کرده — درج مجدد انجام نمی‌شود.
                    $this->db->query(
                        // FIX-S34-B14-F22 (گزارش بخش ۱۴): واژگان مشترک با ReconciliationService —
                        // قبلاً job با status='pending' درج می‌کرد در حالی که list/resolve/dismiss
                        // فقط open/in_progress را می‌پذیرفتند؛ پروندهٔ رسیدگی در ابزار بازیابی
                        // نامرئی/حل‌ناشدنی می‌ماند. اکنون درج با 'open' (همان واژگان CLI) است.
                        "INSERT INTO withdrawal_reviews
                         (withdrawal_id, user_id, amount, currency, status,
                          stuck_hours, detected_at, created_at)
                        SELECT ?, ?, ?, ?, 'open', ?, NOW(), NOW()
                        FROM DUAL
                        WHERE NOT EXISTS (
                            SELECT 1 FROM withdrawal_reviews WHERE withdrawal_id = ?
                        )",
                        [
                            (int)$w->id,
                            (int)$w->user_id,
                            (string)$w->amount,
                            (string)$w->currency,
                            (int)$w->stuck_hours,
                            (int)$w->id,
                        ]
                    );
                }

                // ── FIX-S35-B14-P1 (سیاست محصول processing) ────────────────
                // «processing» = «انتقال بیرونی آغاز شده، نتیجهٔ نامعلوم». لغو
                // خودکار بر پایهٔ سنِ created_at در این وضعیت unsafe است (خطر
                // پرداخت دوگانه). سیاست: processing هرگز خودکار لغو نمی‌شود؛
                // فقط ارجاع/پرچم برای تصمیم ادمین.
                if (strtolower((string)$w->status) === 'processing') {
                    // FIX-S34-B14-F22: escalation فقط از حالت‌های فعالِ غیرterminal
                    $escProc = $this->db->query(
                        "UPDATE withdrawal_reviews SET status = 'escalated', detected_at = NOW()
                         WHERE withdrawal_id = ? AND status IN ('open','pending')",
                        [(int)$w->id]
                    );
                    if ($escProc->rowCount() > 0) {
                        $processingFlagged++;
                        $this->logger->warning('withdrawal.timeout.processing_flagged', [
                            'withdrawal_id' => $w->id,
                            'user_id'       => $w->user_id,
                            'stuck_hours'   => $w->stuck_hours,
                            'hint'          => 'processing = external payout may be in flight; never auto-refund by age — needs admin decision',
                        ]);
                    }
                    continue;
                }

                // 🛡️ FIX #3 (P2): کیف منجمد ⇒ unlockBalance ردیف منجمد را لمس
                // نمی‌کند و لغو همیشه fail می‌شد؛ هر ۱۰ دقیقه retry بی‌پایان + نویز.
                // اکنون یک‌بار escalate می‌شود (status='escalated' در گزارش ادمین)
                // و از حلقهٔ لغو خارج می‌ماند تا ادمین پس از رفع freeze تصمیم بگیرد.
                $isFrozen = (int)$this->db->fetchColumn(
                    'SELECT COALESCE(is_frozen, 0) FROM wallets WHERE user_id = ?',
                    [(int)$w->user_id]
                ) === 1;
                if ($isFrozen) {
                    // RE-REVIEW FIX: فقط هنگام گذارِ واقعی به escalated شمارش/لاگ شود،
                    // نه در هر اجرای ۱۰ دقیقه‌ای برای همان ردیف (نویز لاگ/آمار).
                    // FIX-S34-B14-F22: escalation فقط از حالت‌های فعالِ غیرterminal —
                    // شرط قبلی (status <> 'escalated') پروندهٔ تاریخی dismissed/admin_resolved
                    // را هم دوباره escalated می‌کرد و ترمینال بودن تصمیم ادمین را می‌شکست.
                    $esc = $this->db->query(
                        "UPDATE withdrawal_reviews SET status = 'escalated', detected_at = NOW()
                         WHERE withdrawal_id = ? AND status IN ('open','pending')",
                        [(int)$w->id]
                    );
                    if ($esc->rowCount() > 0) {
                        $escalatedCount++;
                        $this->logger->warning('withdrawal.timeout.frozen_escalated', [
                            'withdrawal_id' => $w->id,
                            'user_id'       => $w->user_id,
                            'stuck_hours'   => $w->stuck_hours,
                            'hint'          => 'wallet frozen — refund blocked by design; needs admin decision',
                        ]);
                    }
                    continue;
                }

                // ۲. لغو خودکار برداشت و بازگشت موجودی (Auto-Cancellation)
                // FIX-S35-B14-P2: منطق تلاشِ لغو به attemptAutoCancel منتقل شد —
                // گارد انجماد داخل تراکنش بازگشت (بستن پنجرهٔ TOCTOU بین چک
                // بیرونی و refund) + گارد وضعیت pending در UPDATE ردیف.
                $outcome = $this->attemptAutoCancel($w);
                if ($outcome === 'cancelled') {
                    $cancelledCount++;
                    // FIX-S34-B14-F22: بستن پروندهٔ رسیدگی پس از لغو موفق — قبلاً review
                    // مربوط به همین برداشت در حالت باز (open/pending) می‌ماند و صف ادمین
                    // از پرونده‌ای پر می‌شد که خودکار حل شده بود.
                    $this->db->query(
                        "UPDATE withdrawal_reviews
                         SET status = 'dismissed',
                             resolution_note = COALESCE(NULLIF(resolution_note, ''), 'لغو خودکار timeout — وجه به موجودی بازگشت'),
                             resolved_at = NOW(), updated_at = NOW()
                         WHERE withdrawal_id = ? AND status IN ('open','pending','in_progress','escalated')",
                        [(int)$w->id]
                    );
                    $this->logger->info('withdrawal.timeout.cancelled', [
                        'withdrawal_id' => $w->id,
                        'user_id' => $w->user_id,
                        'amount' => $w->amount
                    ]);
                } elseif ($outcome === 'frozen_in_tx') {
                    // FIX-S35-B14-P2: انجماد بین چک بیرونی و تراکنش رخ داده — همان
                    // قرارداد مسیر frozen: بدون بازگشت وجه، ارجاع به ادمین.
                    $esc = $this->db->query(
                        "UPDATE withdrawal_reviews SET status = 'escalated', detected_at = NOW()
                         WHERE withdrawal_id = ? AND status IN ('open','pending')",
                        [(int)$w->id]
                    );
                    if ($esc->rowCount() > 0) {
                        $escalatedCount++;
                        $this->logger->warning('withdrawal.timeout.frozen_escalated', [
                            'withdrawal_id' => $w->id,
                            'user_id'       => $w->user_id,
                            'stuck_hours'   => $w->stuck_hours,
                            'hint'          => 'wallet frozen between precheck and refund (in-tx FOR UPDATE guard) — refund aborted, needs admin decision',
                        ]);
                    }
                }
                // 'skipped'/'failed': بی‌صدا برای اجرای بعدی (رفتار قبلی حفظ شده؛
                // failed داخل attemptAutoCancel لاگ/Sentry شده است.)
            }

            $this->logger->info('withdrawal.stuck_processed', [
                'scanned' => count($stuckWithdrawals),
                'cancelled' => $cancelledCount,
                'escalated' => $escalatedCount,
                'processing_flagged' => $processingFlagged, // FIX-S35-B14-P1
                'hours_threshold' => $hours,
            ]);

            return [
                'scanned' => count($stuckWithdrawals),
                'cancelled' => $cancelledCount,
                'escalated' => $escalatedCount,
                'processing_flagged' => $processingFlagged, // FIX-S35-B14-P1
                'message' => "{$cancelledCount} برداشت گیر کرده لغو و بازگردانده شد"
                    . ($escalatedCount > 0 ? "؛ {$escalatedCount} مورد به دلیل مسدودی کیف پول به ادمین ارجاع شد" : '')
                    . ($processingFlagged > 0 ? "؛ {$processingFlagged} برداشت processing فقط به ادمین ارجاع شد (سیاست: هرگز لغو خودکار)" : ''),
            ];

        } catch (\Throwable $e) {
            $this->logger->error('withdrawal.stuck_scan_failed', ['error' => $e->getMessage()]);
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'withdrawal.stuck_scan',
            ]);
            throw $e;
        }
    }

    /**
     * FIX-S35-B14-P2: تلاشِ لغو خودکار + بازگشت وجه قفل‌شده برای یک برداشت.
     *
     * گارد انجماد «داخل» تراکنش با قفل ردیف کیف (SELECT … FOR UPDATE) تکرار
     * می‌شود: چک بیرونی precheck به‌تنهایی پنجرهٔ TOCTOU را نمی‌بندد (ادمین
     * می‌تواند بین چک و refund کیف را منجمد کند). اگر داخل تراکنش منجمد
     * دید، بدون هیچ نوشتنی خارج می‌شود تا بازگشت خودکار وجه روی کیفِ تحت
     * بررسی تقلب هرگز رخ ندهد (سیاست: frozen = تصمیم ادمین).
     *
     * گارد دوم (P1): UPDATE ردیف withdrawals فقط از 'pending' عبور می‌کند —
     * اگر ردیف بین اسکن و لغو به processing رفته باشد (آغاز payout بیرونی
     * توسط ادمین)، صفر ردیف = شکست کل تراکنش = پولی بازنمی‌گردد.
     *
     * @param \stdClass $w ردیف برداشت از اسکن (id, user_id, amount, transaction_id, stuck_hours, ...)
     * @return string 'cancelled' | 'frozen_in_tx' | 'skipped' | 'failed'
     */
    private function attemptAutoCancel(\stdClass $w): string
    {
        $frozenInTx = false;
        try {
            $success = $this->db->transactional(function () use ($w, &$frozenInTx): bool {
                // ── FIX-S35-B14-P2: گارد انجماد داخل تراکنش (قفل ردیف کیف) ──
                $isFrozen = (int)$this->db->fetchColumn(
                    'SELECT COALESCE(is_frozen, 0) FROM wallets WHERE user_id = ? FOR UPDATE',
                    [(int)$w->user_id]
                ) === 1;
                if ($isFrozen) {
                    $frozenInTx = true;
                    return false; // فقط خوانده شد؛ هیچ نوشتنی انجام نشده
                }

                // ── P1 FIX (پنجره‌ی ناسازگاری) ──────────────────────────────
                // قبلاً cancelWithdrawal (بازگشت وجه + cancel تراکنش) در تراکنش
                // خودش commit می‌شد و UPDATE ردیف withdrawals جداگانه اجرا می‌شد؛
                // اگر بین این دو کرش/خطا رخ می‌داد، پول برگشته بود ولی درخواست
                // pending می‌ماند و ادمین می‌توانست همان برداشت را approve کند.
                // اکنون هر دو در یک تراکنش واحدند (cancelWithdrawal با بررسی
                // inTransaction به تراکنش بیرونی می‌پیوندد — همان الگوی
                // adminReject در WithdrawalAdminService).
                $ok = $this->walletMutationService->cancelWithdrawal(
                    (string)$w->transaction_id,
                    (int)$w->user_id
                );
                if (!$ok) {
                    return false;
                }

                // ── S4-M5 FIX: نتیجهٔ UPDATE ردیف withdrawals باید چک شود ──
                // cancelWithdrawal پول قفل‌شده را در transactions
                // بازمی‌گرداند؛ اگر ردیف withdrawals هم‌زمان (مثلاً با
                // approve ادمین یا آغاز payout) از pending خارج شده باشد،
                // UPDATE صفر ردیف تغییر می‌دهد و ادامه دادن یعنی
                // «refund بدون ردیف» = پول از هیچ و آزاد شدن درخواست
                // تأییدشده. اکنون صفر ردیف = شکست کل تراکنش.
                // FIX-S35-B14-P1: قبلاً IN ('pending','processing') بود؛ با
                // سیاست processing فقط 'pending' مجاز است (بستن رقابتِ
                // گذار pending→processing بین اسکن و لغو).
                $updated = $this->db->query(
                    "UPDATE withdrawals
                     SET status = 'cancelled', rejection_reason = COALESCE(rejection_reason, 'لغو خودکار به دلیل timeout'), updated_at = NOW()
                     WHERE id = ? AND status = 'pending'",
                    [(int)$w->id]
                );
                if ($updated->rowCount() === 0) {
                    throw new \Core\Exceptions\ApplicationException(
                        'ردیف برداشت هم‌زمان تغییر کرد؛ لغو خودکار برای جلوگیری از refund بدون ردیف لغو شد'
                    );
                }
                return true;
            });

            if ($success) {
                return 'cancelled';
            }
            return $frozenInTx ? 'frozen_in_tx' : 'skipped';
        } catch (\Throwable $e) {
            $this->logger->error('withdrawal.timeout.cancel_failed', [
                'withdrawal_id' => $w->id,
                'error' => $e->getMessage()
            ]);
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, (int)$w->user_id, [
                'operation'     => 'withdrawal.timeout.cancel',
                'withdrawal_id' => $w->id,
                'amount'        => $w->amount,
                'stuck_hours'   => $w->stuck_hours,
            ]);
            return 'failed';
        }
    }
}
