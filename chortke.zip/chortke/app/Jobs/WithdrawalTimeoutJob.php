<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use Core\Cache;
use App\Contracts\LoggerInterface;
use App\Services\Wallet\WalletMutationService;

/**
 * WithdrawalTimeoutJob
 * 
 * اسکن خودکار برداشت‌های گیر کرده (stuck) که بیش از X ساعت در وضعیت
 * 'pending' یا 'processing' مانده‌اند و آن‌ها را لغو کرده و مبلغ را باز می‌گرداند.
 * همچنین گزارشی برای بررسی ادمین ثبت می‌کند.
 * 
 * در Cron: هر ۱۰ دقیقه اجرا می‌شود
 */
class WithdrawalTimeoutJob
{
    /**
     * FIX-R18-M9: بدترین زمان اجرای موردانتظار (اسکن کل withdrawals + لغو/بازگشت وجه).
     * QueueWorker از این مقدار برای گسترش visibility (timeoutSeconds*2) استفاده می‌کند.
     */
    public int $timeoutSeconds = 600;

    private Database $db;
    private LoggerInterface $logger;
    private WalletMutationService $walletMutationService;
    private ?\App\Services\Settings\AppSettings $appSettings = null;

    /** ساعت‌هایی بعد از آن برداشت stuck محسوب می‌شود */
    private const STUCK_HOURS = 2;
    
    /** حداکثر تعداد برداشتی که در هر اجرا اسکن می‌شود */
    private const MAX_SCAN = 200;

    public function __construct(
        Database $db,
        LoggerInterface $logger,
        WalletMutationService $walletMutationService,
        ?\App\Services\Settings\AppSettings $appSettings = null
    ) {
        $this->db = $db;
        $this->logger = $logger;
        $this->walletMutationService = $walletMutationService;
        // 🛡️ FIX #3 (P2): آستانهٔ timeout از تنظیمات پنل ادمین خوانده می‌شود
        // (withdrawal_stuck_timeout_hours) تا SLA عملیاتی بدون تغییر کد قابل
        // تنظیم باشد؛ پیش‌فرض همان ۲ ساعت قبلی است.
        $this->appSettings = $appSettings;
    }

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
public function handle(array $data = []): array
    {
        $configuredHours = $this->appSettings !== null
            ? int_value($this->appSettings->get('withdrawal_stuck_timeout_hours', self::STUCK_HOURS))
            : self::STUCK_HOURS;
        if ($configuredHours < 1) {
            $configuredHours = self::STUCK_HOURS;
        }
        $hours = int_value($data['stuck_hours'] ?? $configuredHours);
        $limit = int_value($data['limit'] ?? self::MAX_SCAN);

        try {
            // پیدا کردن برداشت‌هایی که بیش از X ساعت در وضعیت pending/processing مانده‌اند
            $stuckWithdrawals = $this->db->query("
                SELECT id, user_id, amount, currency, status, transaction_id, created_at,
                       TIMESTAMPDIFF(HOUR, created_at, NOW()) AS stuck_hours
                FROM withdrawals
                WHERE status IN ('pending', 'processing')
                  AND created_at < DATE_SUB(NOW(), INTERVAL ? HOUR)
                ORDER BY created_at ASC
                LIMIT ?
            ", [$hours, $limit])->fetchAll(\PDO::FETCH_OBJ);

            if (empty($stuckWithdrawals)) {
                return ['scanned' => 0, 'cancelled' => 0, 'message' => 'بدون برداشت گیر کرده'];
            }

            // ✅ N+1 FIX: یک query برای پیدا کردن همه withdrawal_ids که قبلاً flag شدند
            $allIds         = array_map(fn($w) => (int)$w->id, $stuckWithdrawals);
            $placeholders   = implode(',', array_fill(0, count($allIds), '?'));
            $alreadyFlagged = $this->db->fetchAll(
                "SELECT withdrawal_id FROM withdrawal_reviews WHERE withdrawal_id IN ({$placeholders})",
                $allIds
            ) ?: [];
            $flaggedSet = array_flip(array_column($alreadyFlagged, 'withdrawal_id'));
            // ────────────────────────────────────────────────────────────

            $cancelledCount = 0;
            $escalatedCount = 0;
            foreach ($stuckWithdrawals as $w) {
                // ۱. ثبت گزارش برای ادمین — بدون SELECT اضافه
                if (!isset($flaggedSet[(int)$w->id])) {
                    // FIX-R19-A6-9: درجِ گزارش ادمین اکنون اتمیک است
                    // (INSERT…SELECT…WHERE NOT EXISTS — الگوی ReportVitrineListingJob:85-100).
                    // پیش از این flaggedSet فقط یک‌بار پیش از حلقه خوانده می‌شد (check-then-insert) و
                    // دو کرنِ هم‌پوشان هر دو عبور می‌کردند و ردیف گزارشِ تکراری می‌نوشتند
                    // (withdrawal_reviews فقط PRIMARY دارد، UNIQUE(withdrawal_id) وجود ندارد).
                    // rowCount=0 یعنی کرن هم‌زمان همان لحظه ثبتش کرده — درج مجدد انجام نمی‌شود.
                    $this->db->query(
                        "INSERT INTO withdrawal_reviews
                         (withdrawal_id, user_id, amount, currency, status,
                          stuck_hours, detected_at, created_at)
                        SELECT ?, ?, ?, ?, 'pending', ?, NOW(), NOW()
                        FROM DUAL
                        WHERE NOT EXISTS (
                            SELECT 1 FROM withdrawal_reviews WHERE withdrawal_id = ?
                        )",
                        [
                            (int)$w->id,
                            (int)$w->user_id,
                            (string)$w->amount,
                            (string)$w->currency,
                            (int)$w->stuck_hours,
                            (int)$w->id,
                        ]
                    );
                }

                // 🛡️ FIX #3 (P2): کیف منجمد ⇒ unlockBalance ردیف منجمد را لمس
                // نمی‌کند و لغو همیشه fail می‌شد؛ هر ۱۰ دقیقه retry بی‌پایان + نویز.
                // اکنون یک‌بار escalate می‌شود (status='escalated' در گزارش ادمین)
                // و از حلقهٔ لغو خارج می‌ماند تا ادمین پس از رفع freeze تصمیم بگیرد.
                $isFrozen = (int)$this->db->fetchColumn(
                    'SELECT COALESCE(is_frozen, 0) FROM wallets WHERE user_id = ?',
                    [(int)$w->user_id]
                ) === 1;
                if ($isFrozen) {
                    // RE-REVIEW FIX: فقط هنگام گذارِ واقعی به escalated شمارش/لاگ شود،
                    // نه در هر اجرای ۱۰ دقیقه‌ای برای همان ردیف (نویز لاگ/آمار).
                    $esc = $this->db->query(
                        "UPDATE withdrawal_reviews SET status = 'escalated', detected_at = NOW()
                         WHERE withdrawal_id = ? AND status <> 'escalated'",
                        [(int)$w->id]
                    );
                    if ($esc->rowCount() > 0) {
                        $escalatedCount++;
                        $this->logger->warning('withdrawal.timeout.frozen_escalated', [
                            'withdrawal_id' => $w->id,
                            'user_id'       => $w->user_id,
                            'stuck_hours'   => $w->stuck_hours,
                            'hint'          => 'wallet frozen — refund blocked by design; needs admin decision',
                        ]);
                    }
                    continue;
                }

                // ۲. لغو خودکار برداشت و بازگشت موجودی (Auto-Cancellation)
                try {
                    // ── P1 FIX (پنجره‌ی ناسازگاری) ──────────────────────────────
                    // قبلاً cancelWithdrawal (بازگشت وجه + cancel تراکنش) در تراکنش
                    // خودش commit می‌شد و UPDATE ردیف withdrawals جداگانه اجرا می‌شد؛
                    // اگر بین این دو کرش/خطا رخ می‌داد، پول برگشته بود ولی درخواست
                    // pending می‌ماند و ادمین می‌توانست همان برداشت را approve کند.
                    // اکنون هر دو در یک تراکنش واحدند (cancelWithdrawal با بررسی
                    // inTransaction به تراکنش بیرونی می‌پیوندد — همان الگوی
                    // adminReject در WithdrawalAdminService).
                    $success = $this->db->transactional(function () use ($w): bool {
                        $ok = $this->walletMutationService->cancelWithdrawal(
                            (string)$w->transaction_id,
                            (int)$w->user_id
                        );
                        if (!$ok) {
                            return false;
                        }

                        // ── S4-M5 FIX: نتیجهٔ UPDATE ردیف withdrawals باید چک شود ──
                        // cancelWithdrawal پول قفل‌شده را در wallet_transactions
                        // بازمی‌گرداند؛ اگر ردیف withdrawals هم‌زمان (مثلاً با
                        // approve ادمین) از pending/processing خارج شده باشد،
                        // UPDATE صفر ردیف تغییر می‌دهد و ادامه دادن یعنی
                        // «refund بدون ردیف» = پول از هیچ و آزاد شدن درخواست
                        // تأییدشده. اکنون صفر ردیف = شکست کل تراکنش.
                        $updated = $this->db->query(
                            "UPDATE withdrawals
                             SET status = 'cancelled', rejection_reason = COALESCE(rejection_reason, 'لغو خودکار به دلیل timeout'), updated_at = NOW()
                             WHERE id = ? AND status IN ('pending', 'processing')",
                            [(int)$w->id]
                        );
                        if ($updated->rowCount() === 0) {
                            throw new \Core\Exceptions\ApplicationException(
                                'ردیف برداشت هم‌زمان تغییر کرد؛ لغو خودکار برای جلوگیری از refund بدون ردیف لغو شد'
                            );
                        }
                        return true;
                    });

                    if ($success) {
                        $cancelledCount++;
                        $this->logger->info('withdrawal.timeout.cancelled', [
                            'withdrawal_id' => $w->id,
                            'user_id' => $w->user_id,
                            'amount' => $w->amount
                        ]);
                    }
                } catch (\Throwable $e) {
                    $this->logger->error('withdrawal.timeout.cancel_failed', [
                        'withdrawal_id' => $w->id,
                        'error' => $e->getMessage()
                    ]);
                    \App\Services\Sentry\SentryExceptionHandler::captureException($e, (int)$w->user_id, [
                        'operation'     => 'withdrawal.timeout.cancel',
                        'withdrawal_id' => $w->id,
                        'amount'        => $w->amount,
                        'stuck_hours'   => $w->stuck_hours,
                    ]);
                }
            }

            $this->logger->info('withdrawal.stuck_processed', [
                'scanned' => count($stuckWithdrawals),
                'cancelled' => $cancelledCount,
                'hours_threshold' => $hours,
            ]);

            return [
                'scanned' => count($stuckWithdrawals),
                'cancelled' => $cancelledCount,
                'escalated' => $escalatedCount,
                'message' => "{$cancelledCount} برداشت گیر کرده لغو و بازگردانده شد"
                    . ($escalatedCount > 0 ? "؛ {$escalatedCount} مورد به دلیل مسدودی کیف پول به ادمین ارجاع شد" : ''),
            ];

        } catch (\Throwable $e) {
            $this->logger->error('withdrawal.stuck_scan_failed', ['error' => $e->getMessage()]);
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'withdrawal.stuck_scan',
            ]);
            return ['scanned' => 0, 'cancelled' => 0, 'error' => $e->getMessage()];
        }
    }
}
