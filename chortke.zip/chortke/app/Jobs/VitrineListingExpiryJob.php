<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Contracts\WalletServiceInterface;
use App\Contracts\LoggerInterface;
use Core\Cache;
use Core\Database;
use Core\EventDispatcher;

class VitrineListingExpiryJob
{
    private Database $db;
    private WalletServiceInterface $walletService;
    private LoggerInterface $logger;
    private EventDispatcher $eventDispatcher;
    private ?\App\Services\OutboxService $outbox;
    private Cache $cache;

    public function __construct(
        Database $db,
        WalletServiceInterface $walletService,
        LoggerInterface $logger,
        EventDispatcher $eventDispatcher,
        Cache $cache,
        ?\App\Services\OutboxService $outbox = null
    ) {
        $this->eventDispatcher = $eventDispatcher;
        $this->db = $db;
        $this->walletService = $walletService;
        $this->logger = $logger;
        $this->cache = $cache;
        $this->outbox = $outbox;
    }

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data = []): void
    {
        $this->expireListings();
        $this->releaseHoldsForExpired();
    }

    private function expireListings(): void
    {
        try {
            $expiredListings = $this->db->fetchAll(
                "SELECT id, user_id FROM vitrine_listings WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at < NOW() LIMIT 500"
            );
            if (empty($expiredListings)) return;

            // 🛡️ FIX-R36-W2 (F-A17-01): تا پیش از این فیکس گارد status='active' فقط در
            // SELECT بود و UPDATE کورکورانه id را به expired می‌زد — بین SELECT و UPDATE،
            // AcceptVitrineRequestJob (M-03: CAS دوگانهٔ درخواست+لیستینگ در یک tx) می‌توانست
            // ردیف را active→in_escrow کند و فروشِ پرداخت‌شدهٔ در-اسکرو به expired بدل می‌شد
            // (پول خریدار نهایتاً با ProcessExpiredVitrineEscrowsJob برمی‌گشت ولی state فروش
            // خراب می‌شد). اکنون هر ردیف با CAS اتمیک منفرد (هم‌الگوی claim در
            // releaseHoldsForExpired همین فایل) منقضی می‌شود؛ فقط ردیف‌هایی که واقعاً
            // expired شدند رویداد outbox می‌گیرند و رقابتِ باخته بدون اثر جانبی رد می‌شود.
            $expired = 0;
            foreach ($expiredListings as $listing) {
                $affected = (int) $this->db->execute(
                    "UPDATE vitrine_listings SET status = 'expired', updated_at = NOW() WHERE id = ? AND status = 'active'",
                    [(int)$listing->id]
                );
                if ($affected === 0) {
                    // CAS باخت: لیستین هم‌زمان accept/تغییر وضعیت شده — دست نمی‌زنیم.
                    continue;
                }
                $expired++;
                try {
                    if ($this->outbox) {
                        $this->outbox->record('vitrine', (int)$listing->id, 'vitrine.listing_expired', ['id' => (int)$listing->id, 'user_id' => (int)$listing->user_id]);
                    }
                } catch (\Throwable $e) {
                    $this->logger->warning('vitrinelistingexpiryjob.operation_failed', ['error' => $e->getMessage()]);
                }
            }
            if ($expired > 0) {
                $this->logger->info('vitrine.listings_expired', ['count' => $expired]);
                try {
                    $this->cache->forget('vitrine:active_listings');
                    $this->eventDispatcher->dispatch('cache.invalidate', ['key' => 'vitrine']);
                } catch (\Throwable $e) {
                    $this->logger->warning('vitrinelistingexpiryjob.operation_failed', ['error' => $e->getMessage()]);
                }
            }
        } catch (\Throwable $e) {
            $this->logger->error('vitrine.expire_listings_failed', ['error' => $e->getMessage()]);
        }
    }

    private function releaseHoldsForExpired(): void
    {
        try {
            // 🛡️ FIX-S17-1 (Medium — TOCTOU/دوبار-شارژ): SELECT ... FOR UPDATE بیرون از
            // تراکنش در autocommit قفلش بلافاصله آزاد می‌شود (بی‌اثر) و کلید ضمنی ولت
            // (user|action|amount|currency|ip) فاقد شناسهٔ لیستین بود ⇒ دو لیستینِ
            // منقضیِ هم‌مبلغِ یک کاربر = واریز دوم به‌عنوان replay حذف و hold_released=1
            // ثبت می‌شد (ضرر مالی کاربر). الگوی M-01: claim اتمیک CAS داخل تراکنش +
            // کلید idempotency صریح per-listing + ref_id.
            $listings = $this->db->fetchAll("SELECT vl.id, vl.user_id, vl.hold_amount, vl.currency FROM vitrine_listings vl WHERE vl.status = 'expired' AND vl.hold_released = 0 AND vl.hold_amount > 0 LIMIT 200");
            $released = 0;
            foreach ($listings as $listing) {
                try {
                    $this->db->beginTransaction();
                    // claim اتمیک داخل تراکنش — ورکر موازی affected=0 می‌گیرد و رد می‌شود؛
                    // گارد status='expired' نیز تغییر وضعیت بین SELECT و claim را مسدود می‌کند
                    $claimed = (int) $this->db->execute(
                        "UPDATE vitrine_listings SET hold_released = 1, hold_released_at = NOW() WHERE id = ? AND hold_released = 0 AND status = 'expired'",
                        [(int)$listing->id]
                    );
                    if ($claimed === 0) {
                        $this->db->commit();
                        continue;
                    }
                    $this->walletService->deposit((int)$listing->user_id, (string)$listing->hold_amount, (string)($listing->currency ?: 'irt'), [
                        'type' => 'vitrine_hold_release',
                        'listing_id' => $listing->id,
                        'description' => 'آزادسازی Hold آگهی ویترین منقضی‌شده',
                        // کلید idempotency صریح per-listing — کلید ضمنی ولت از listing_id بی‌خبر است
                        'idempotency_key' => 'vitrine_hold_release_' . (int)$listing->id,
                        'ref_id' => 'vitrine_listing_' . (int)$listing->id,
                    ]);
                    $this->db->commit();
                    $released++;
                    // 🛡️ FIX-DEAD-EVENT-HOLD-NOTIFY (P1 — pre-existing): رویداد
                    // vitrine.hold_released هیچ listener ای ندارد → مالک آگهی از
                    // آزادسازی وجه hold بی‌خبر می‌ماند. اصلاح با الگوی استاندارد
                    // notification.requested (رویداد بی‌اثر حذف شد).
                    try { $this->outbox?->record('notification', (int)$listing->user_id, 'notification.requested', [
                        'user_id'    => (int)$listing->user_id,
                        'type'       => 'vitrine_hold_released',
                        'title'      => 'وجه hold آگهی آزاد شد 💰',
                        'message'    => 'مبلغ hold آگهی منقضی‌شده #' . (int)$listing->id . ' به کیف پول شما بازگشت داده شد.',
                        'data'       => [
                            'listing_id' => (int)$listing->id,
                            'amount'     => (is_numeric($listing->hold_amount ?? null) ? (string)$listing->hold_amount : '0'),
                        ],
                        'action_url' => '/wallet',
                    ]); } catch (\Throwable $e) {
                        $this->logger->warning('vitrine.hold_release_notify_failed', ['listing_id' => $listing->id, 'error' => $e->getMessage()]);
                    }
                } catch (\Throwable $e) { if ($this->db->inTransaction()) $this->db->rollback(); $this->logger->error('vitrine.hold_release_failed', ['listing_id' => $listing->id, 'error' => $e->getMessage()]); }
            }
            if ($released > 0) $this->logger->info('vitrine.holds_released', ['count' => $released]);
        } catch (\Throwable $e) { $this->logger->error('vitrine.release_holds_job_failed', ['error' => $e->getMessage()]); }
    }
}
