<?php

declare(strict_types=1);

namespace App\Jobs\Dispute;

use App\Services\Dispute\DisputeCommandService;

class ProcessExpiredDisputesJob
{
    public function handle(DisputeCommandService $service): int
    {
        return $service->processExpiredPeerResolutions();
    }
}
