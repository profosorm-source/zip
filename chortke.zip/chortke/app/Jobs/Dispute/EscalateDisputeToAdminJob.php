<?php

declare(strict_types=1);

namespace App\Jobs\Dispute;

use App\Services\Dispute\DisputeCommandService;

class EscalateDisputeToAdminJob
{
    /** @return array<string, mixed> */
public function handle(int $disputeId, int $requesterId, DisputeCommandService $service): array
    {
        return $service->escalateToAdmin($disputeId, $requesterId);
    }
}
