<?php

declare(strict_types=1);

namespace App\Jobs\Dispute;

use App\Services\Dispute\DisputeCommandService;

class ResolveDisputeByAgreementJob
{
    public function handle(int $disputeId, int $initiatorId, string $resolution, string $verdict, DisputeCommandService $service): array
    {
        return $service->resolveByAgreement($disputeId, $initiatorId, $resolution, $verdict);
    }
}
