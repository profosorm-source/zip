<?php

declare(strict_types=1);

namespace App\Jobs\Dispute;

use App\Services\Dispute\DisputeCommandService;

class AdminResolveDisputeJob
{
    public function handle(int $disputeId, int $adminId, string $verdict, string $note, float $refundPercent, DisputeCommandService $service): array
    {
        return $service->adminResolve($disputeId, $adminId, $verdict, $note, $refundPercent);
    }
}
