<?php

declare(strict_types=1);

namespace App\Jobs\Investment;

use App\Services\InvestmentService;

class ApproveWithdrawalJob
{
    public function __construct(
        private InvestmentService $investmentService
    ) {}

    /** @return array<string, mixed> */
public function handle(int $withdrawalId, int $adminId): array
    {
        return $this->investmentService->approveWithdrawal($withdrawalId, $adminId);
    }
}
