<?php

declare(strict_types=1);

namespace App\Jobs\Investment;

use App\Validators\Requests\CloseTradeRequest;
use App\Models\TradingRecord;

class CloseTradeJob
{
    private \App\Models\TradingRecord $tradingModel;
    private \App\Contracts\LoggerInterface $logger;
    public function __construct(
        \App\Models\TradingRecord $tradingModel,
        \App\Contracts\LoggerInterface $logger
    ) {        $this->tradingModel = $tradingModel;
        $this->logger = $logger;
}

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
public function handle(int $tradeId, int $adminId, array $data): array
    {
        $request = new CloseTradeRequest($data);
        $validated = $request->validateOrFail();

        $trade = $this->tradingModel->find($tradeId);
        if (!$trade) {
            return ['success' => false, 'message' => 'ترید یافت نشد.'];
        }
        if ($trade->status !== TradingRecord::STATUS_OPEN) {
            return ['success' => false, 'message' => 'فقط تریدهای باز قابل بستن هستند.'];
        }

        // FIX-X80 (ثبت درصد در بستن ترید): ستون profit_loss_percent هنگام بستن
        // ترید هرگز پر نمی‌شد (مودال فقط مبلغ USDT می‌فرستد و Job هم درصد را
        // persist نمی‌کرد) → تب «بازار» کاربر برای همهٔ تریدها «+0%» نشان می‌داد.
        // تصمیم محصول: درصد از قیمت باز/بسته با احتساب جهت (buy/sell) محاسبه می‌شود.
        $percent = $this->resolveProfitLossPercent(
            $trade,
            str_value($validated['close_price']),
            str_value($validated['profit_loss_amount']),
            isset($data['profit_loss_percent']) && is_scalar($data['profit_loss_percent']) ? (string)$data['profit_loss_percent'] : null
        );

        $updatePayload = [
            'close_price'         => $validated['close_price'],
            'closed_at'           => $validated['close_time'] ?? date('Y-m-d H:i:s'),
            'profit_loss_amount'  => $validated['profit_loss_amount'],
            'status'              => $validated['status'] ?? TradingRecord::STATUS_CLOSED,
            'reason'              => $validated['notes'] ?? $trade->reason,
        ];
        if ($percent !== null) {
            $updatePayload['profit_loss_percent'] = $percent;
        }

        $this->tradingModel->update($tradeId, $updatePayload);

        $this->logger->info('trade_closed', [
            'message' => "Admin {$adminId} closed trade #{$tradeId}",
            'profit_loss_percent' => $percent,
        ]);

        return ['success' => true, 'message' => 'ترید بسته شد.', 'profit_loss_percent' => $percent];
    }

    /**
     * FIX-X80 — منبع واحد حقیقت برای درصد سود/زیان:
     *  1) مرجع: قیمت باز/بسته با احتساب جهت (buy: (close-open)/open، sell: (open-close)/open)
     *  2) fallback: مبلغ سود/ضرر نسبت به حجم اسمی (open_price × amount)
     *  3) آخرین fallback: درصد ارسالی کلاینت اگر عددی معتبر باشد
     * خروجی همیشه round 4 اعشار و clamp در بازهٔ مجاز ستون decimal(10,4).
     */
    private function resolveProfitLossPercent(\stdClass $trade, string $closePrice, string $pnlAmount, ?string $clientPercent): ?string
    {
        $open  = (float)($trade->open_price ?? 0);
        $close = (float)$closePrice;
        $dir   = strtolower((string)($trade->direction ?? $trade->type ?? 'buy'));

        if ($open > 0 && $close > 0) {
            $pct = $dir === 'sell' ? (($open - $close) / $open) * 100 : (($close - $open) / $open) * 100;
            return $this->clampPercent($pct);
        }

        // fallback حجم اسمی — وقتی قیمت باز/بسته کامل نیست
        $volume = (float)($trade->amount ?? 0);
        $entryRef = $open > 0 ? $open : (float)($trade->price ?? 0);
        $notional = $volume * $entryRef;
        if ($notional > 0 && is_numeric($pnlAmount)) {
            return $this->clampPercent(((float)$pnlAmount / $notional) * 100);
        }

        if ($clientPercent !== null && $clientPercent !== '' && is_numeric($clientPercent)) {
            return $this->clampPercent((float)$clientPercent);
        }

        return null;
    }

    /** سقف/کف ستون decimal(10,4) → 999999.9999 */
    private function clampPercent(float $pct): string
    {
        $pct = max(-999999.9999, min(999999.9999, $pct));
        return number_format($pct, 4, '.', '');
    }
}
