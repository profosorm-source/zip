<?php

declare(strict_types=1);

namespace App\Jobs\Investment;

use App\Validators\Requests\CreateTradeRequest;
use App\Services\AuditTrail;
use App\Models\TradingRecord;

class CreateTradeJob
{
    private \App\Models\TradingRecord $tradingModel;
    private \App\Contracts\LoggerInterface $logger;
    private AuditTrail $auditTrail;
    public function __construct(
        \App\Models\TradingRecord $tradingModel,
        \App\Contracts\LoggerInterface $logger,
        AuditTrail $auditTrail
    ) {
        $this->tradingModel = $tradingModel;
        $this->logger = $logger;
        $this->auditTrail = $auditTrail;
    }

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
public function handle(int $adminId, array $data): array
    {
        $request = new CreateTradeRequest($data);
        $validated = $request->validateOrFail();

        $direction = $validated['direction'];
        $openPrice = str_value($validated['open_price']);
        $pair      = trim(str_value($validated['pair']));

        // FIX-S17-1 (CWE-798): کلید HMAC هاردکد (رشتهٔ trade-hash سال ۲۰۲۶)
        // و «امضای اثبات» بی‌وریفایر حذف شد — هیچ وریفایری در کل کدبیس امضا را
        // بررسی نمی‌کرد (security theater) و کلید هاردکد در سورس + reason ذخیره‌شده
        // در DB نشت می‌کرد. reason اکنون فقط notes + هویت ادمین ثبت‌کننده است.
        $reasonPayload = json_encode([
            'notes'               => $data['notes'] ?? null,
            'created_by_admin_id' => $adminId,
        ], JSON_UNESCAPED_UNICODE);

        // FIX-X12 (بحرانی): فرم ترید فیلدهای عددی اختیاری را به‌صورت رشتهٔ خالی '' می‌فرستد؛
        // `?? null` برای '' فعال نمی‌شد → «Incorrect decimal value: '' for column
        // close_price» → ثبت ترید از فرم ادمین همیشه 500 می‌شد. مقادیر خالی → NULL واقعی.
        $nullableDecimal = static function (mixed $value): ?string {
            if (!is_scalar($value)) return null;
            $v = trim((string)$value);
            return ($v === '' || !is_numeric($v)) ? null : $v;
        };

        $tradeId = $this->tradingModel->create([
            'admin_id'            => $adminId,
            'direction'           => $direction,
            'pair'                => $pair,
            'amount'              => $nullableDecimal($data['lot_size'] ?? null) ?? '0',
            'open_price'          => $openPrice,
            'close_price'         => $nullableDecimal($data['close_price'] ?? null),
            'stop_loss'           => $nullableDecimal($data['stop_loss'] ?? null),
            'take_profit'         => $nullableDecimal($data['take_profit'] ?? null),
            'profit_loss_amount'  => $nullableDecimal($data['profit_loss_amount'] ?? null) ?? '0',
            'currency'            => 'usdt',
            'status'              => !empty($data['close_time']) ? TradingRecord::STATUS_CLOSED : TradingRecord::STATUS_OPEN,
            'reason'              => $reasonPayload,
            // FIX-X12 ادامه: ستون user_id در DB NOT NULL است؛ برای ترید بدون کاربرِ
            // مشخص (ترید عمومی بازار) user_id باید به admin بازگردد نه NULL.
            'user_id'             => !empty($data['user_id']) ? int_value($data['user_id']) : $adminId,
            'investment_id'       => $data['investment_id'] ?? null,
        ]);

        if (!$tradeId) {
            return ['success' => false, 'message' => 'خطا در ثبت ترید.'];
        }

        // FIX-S16-9: برچسب حسابرسی قبلی گمراه‌کننده بود (رویدادِ تنظیمات‌نما) و به برچسب
        // دقیقِ رویدادِ واقعی — ایجاد ترید سرمایه‌گذاری توسط ادمین — تغییر یافت.
        $this->auditTrail->record('admin.investment.trade_created', null, [
            'action'   => 'trade_created',
            'trade_id' => $tradeId,
            'admin_id' => $adminId,
        ], $adminId);

        $this->logger->info('trade_created', ['message' => "Admin {$adminId} created trade #{$tradeId}"]);

        return ['success' => true, 'message' => 'ترید با موفقیت ثبت شد.', 'trade_id' => $tradeId];
    }
}
