<?php

declare(strict_types=1);

namespace App\Jobs\Investment;

use App\Models\Investment;

class ApplyWeeklyProfitLossJob
{
    private \App\Models\TradingRecord $tradingModel;
    private \App\Models\Investment $investmentModel;
    private \App\Services\Settings\AppSettings $appSettings;
    private \App\Contracts\LoggerInterface $logger;
    private \Core\Queue $queue;
    private ?\App\Contracts\OutboxServiceInterface $outbox;
    public function __construct(
        \App\Models\TradingRecord $tradingModel,
        \App\Models\Investment $investmentModel,
        \App\Services\Settings\AppSettings $appSettings,
        \App\Contracts\LoggerInterface $logger,
        \Core\Queue $queue,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {        $this->tradingModel = $tradingModel;
        $this->investmentModel = $investmentModel;
        $this->appSettings = $appSettings;
        $this->logger = $logger;
        $this->queue = $queue;
        $this->outbox = $outbox;
}

    /** @return array<string, mixed> */
    public function handle(int $adminId, int $tradingRecordId, string $profitLossPercent, string $period): array
    {
        $trade = $this->tradingModel->find($tradingRecordId);
        if (!$trade) {
            return ['success' => false, 'message' => 'رکورد ترید یافت نشد.'];
        }

        // FIX-R36-W3 (F-A17-10): fetch قبلی با سقف خاموش ۱۰,۰۰۰ بود — سرمایه‌گذاری‌های
        // فعالِ فراتر از سقف بی‌صدا از تسویهٔ هفتگی حذف می‌شدند (under-application).
        // اکنون صفحه‌به‌صفحه تا اتمام جمع می‌شود؛ idهای تکراری بین صفحات dedup و
        // خودِ بچ‌جاب‌ها replay-safe هستند (uq_investment_profit_trade_investment)،
        // پس جابه‌جایی ردیف در حین جمع‌آوری دوباره‌اعمالی نمی‌سازد. سقف ایمنی
        // ۱,۰۰۰,۰۰۰ فقط شکست صریح است، نه حذف خاموش.
        $investmentIds = [];
        $pageSize = 5000;
        $offset = 0;
        $safetyCap = 1000000;
        while ($offset < $safetyCap) {
            $page = $this->investmentModel->getAll(['status' => Investment::STATUS_ACTIVE], $pageSize, $offset);
            if (empty($page)) break;
            foreach ($page as $inv) {
                $investmentIds[(int)$inv->id] = true;
            }
            if (count($page) < $pageSize) break;
            $offset += $pageSize;
        }
        $investmentIds = array_keys($investmentIds);

        if (count($investmentIds) >= $safetyCap) {
            $this->logger->error('investment_weekly_apply_id_cap_reached', ['cap' => $safetyCap]);
            return ['success' => false, 'message' => 'تعداد سرمایه‌گذاری‌های فعال از سقف ایمن فراتر است؛ عملیات متوقف شد (نیازمند بررسی).'];
        }

        if (empty($investmentIds)) {
            return ['success' => false, 'message' => 'سرمایه‌گذاری فعالی یافت نشد.'];
        }

        // شکستن شناسه‌ها به بچ‌های ۱۰۰ تایی
        $configuredBatchSize = $this->appSettings->get('investment_batch_size', 100);
        $batchSize = max(10, min(500, is_scalar($configuredBatchSize) && is_numeric((string)$configuredBatchSize) ? (int)$configuredBatchSize : 100));
        $chunks = array_chunk($investmentIds, $batchSize);

        $queuedJobs = 0;

        foreach ($chunks as $chunk) {
            $jobPayload = [
                'investment_ids'      => $chunk,
                'trading_record_id'   => $tradingRecordId,
                'profit_loss_percent' => $profitLossPercent,
                'period'              => $period,
                'admin_id'            => $adminId,
            ];

            if ($this->outbox) {
                // 🛡️ FIX-OUTBOX-JOB-CONTRACT (P0 — pre-existing): دادهٔ جاب زیر کلید «data»
                // (قرارداد شاخهٔ job در OutboxPublisher)؛ قبلاً زیر «notification» بود →
                // send() بدون آرگومان → TypeError → DLQ؛ بچ‌های سود/ضرر هفتگی هرگز
                // در صف قرار نمی‌گرفتند (App\Jobs\ApplyWeeklyProfitLossJob صف‌ساز است).
                $this->outbox->record('investment', 0, 'investment.weekly_profit_batch', [
                    'job' => \App\Jobs\ApplyWeeklyProfitLossJob::class,
                    'data' => $jobPayload,
                ]);
            } else {
                $this->queue->push(\App\Jobs\ApplyWeeklyProfitLossJob::class, $jobPayload);
            }
            $queuedJobs++;
        }

        $this->logger->info('investment_weekly_apply_queued', [
            'message' => "Admin {$adminId} queued {$profitLossPercent}% profit/loss for {$period} in {$queuedJobs} batch jobs, affecting " . count($investmentIds) . " investments."
        ]);

        return [
            'success' => true,
            'message' => "عملیات اعمال سود/ضرر هفتگی به صورت پس‌زمینه برای " . count($investmentIds) . " سرمایه‌گذاری در قالب {$queuedJobs} تسک صف‌بندی شد."
        ];
    }
}
