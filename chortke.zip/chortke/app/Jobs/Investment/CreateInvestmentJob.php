<?php

declare(strict_types=1);

namespace App\Jobs\Investment;

use App\Services\InvestmentService;

class CreateInvestmentJob
{
    public function __construct(
        private InvestmentService $investmentService
    ) {}

    public function handle(int $userId, array $data): array
    {
        try {
            $result = $this->investmentService->create($userId, (string)$data['amount']);
            return ['success' => true, 'message' => 'سرمایه‌گذاری با موفقیت انجام شد', 'id' => $result['investment_id']];
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
