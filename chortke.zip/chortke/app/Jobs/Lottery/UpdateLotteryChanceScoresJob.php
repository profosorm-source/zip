<?php

declare(strict_types=1);

namespace App\Jobs\Lottery;

use Core\Database;
use Core\EventDispatcher;
use App\Models\LotteryDailyNumber;
use App\Models\LotteryParticipation;
use App\Models\LotteryRound;
use App\Models\LotteryVote;
use App\Models\LotteryChanceLog;
use App\Services\ScoreService;
use App\Contracts\LoggerInterface;

/**
 * UpdateLotteryChanceScoresJob
 * 
 * به‌روزرسانی امتیازات شانس (lottery_chance) کاربران شرکت‌کننده در قرعه‌کشی
 * بر اساس تطابق رأی آن‌ها با اعداد روزانه.
 * 
 * این Job توسط Cron فراخوانی می‌شود و نیازی به dispatch دستی ایونت ندارد
 * زیرا ScoreService.applyDelta خودش event sourcing را انجام می‌دهد.
 */
class UpdateLotteryChanceScoresJob
{
    private Database $db;
    private ScoreService $scoreService;
    private LoggerInterface $logger;
    private EventDispatcher $eventDispatcher;
    private LotteryDailyNumber $dailyNumberModel;
    private LotteryParticipation $participationModel;
    private LotteryVote $voteModel;
    private LotteryChanceLog $chanceLogModel;
    private LotteryRound $roundModel;

    /**
     * Thresholds for chance score adjustments
     *
     * FIX-F-07: MIN_CHANCE اینجا (0.0) با LotteryParticipation::MIN_CHANCE (5.0)
     * در تناقض بود؛ منبع حقیقت واحد = ثابتِ مدل.
     */
    private const BASE_REWARD = 2.0;
    private const BASE_PENALTY = 1.0;
    private const MIN_CHANCE = LotteryParticipation::MIN_CHANCE;
    private const NO_VOTE_DECAY = -0.5;

    public function __construct(
        Database $db,
        ScoreService $scoreService,
        LoggerInterface $logger,
        EventDispatcher $eventDispatcher,
        LotteryDailyNumber $dailyNumberModel,
        LotteryParticipation $participationModel,
        LotteryVote $voteModel,
        LotteryChanceLog $chanceLogModel,
        LotteryRound $roundModel
    ) {
        $this->eventDispatcher = $eventDispatcher;
        $this->db = $db;
        $this->scoreService = $scoreService;
        $this->logger = $logger;
        $this->dailyNumberModel = $dailyNumberModel;
        $this->participationModel = $participationModel;
        $this->voteModel = $voteModel;
        $this->chanceLogModel = $chanceLogModel;
        $this->roundModel = $roundModel;
    }

    /** @return array<string, mixed> */
public function handle(int $roundId, string $date): array
    {
        $dailyNumber = $this->dailyNumberModel->getByRoundAndDate($roundId, $date);

        if (!$dailyNumber) {
            return ['success' => false, 'message' => 'عدد روزانه برای این تاریخ یافت نشد.'];
        }

        $round = $this->roundModel->find($roundId);
        if (!$round) {
            return ['success' => false, 'message' => 'دوره قرعه‌کشی یافت نشد.'];
        }

        $participants = $this->participationModel->getAllActiveByRound($roundId);

        if (empty($participants)) {
            return ['success' => false, 'message' => 'شرکت‌کننده‌ای یافت نشد.'];
        }

        $updatedCount = 0;
        $totalReward = 0;
        $totalPenalty = 0;
        $skippedCount = 0;

        $this->db->beginTransaction();

        try {
            foreach ($participants as $p) {
                // FIX-R36-W3 (F-A6b-05) + FIX-F-06: idempotency اتمیک — marker قبلاً
                // یک SELECT ساده بود و دو اجرای هم‌پوشان هر دو رد می‌شدند. اکنون
                // «اول claim» (INSERT ردیف لاگ با UNIQUE(participation_id,date))؛
                // 1062 = قبلاً پردازش شده → skip. claim داخل همین تراکنش است، پس
                // شکست مراحل بعدی آن را هم rollback می‌کند (retry آزاد می‌ماند).

                $userVote = $this->voteModel->getUserVote($p->user_id, $dailyNumber->id);

                $scoreBefore = (float)($p->chance_score ?? 0);

                if (!$userVote) {
                    // کاربر رأی نداده → کاهش امتیاز (No-Vote Decay)
                    $change = self::NO_VOTE_DECAY;
                    $reason = 'no_vote';
                    $details = 'User did not vote for daily numbers';
                    $scoreAfter = $this->floorChanceScore($scoreBefore, $change);
                } else {
                    $selectedNumber = (int)$userVote->voted_number;
                    $matched = $this->checkMatch($p->ticket_number ?? $p->code, $selectedNumber);

                    if ($matched) {
                        $change = self::BASE_REWARD;
                        $reason = 'match_success';
                        $totalReward += $change;
                    } else {
                        $change = -self::BASE_PENALTY;
                        $reason = 'match_fail';
                        $totalPenalty += abs($change);
                    }
                    $details = "selected:{$selectedNumber}, matched:" . ($matched ? 'yes' : 'no');
                    $scoreAfter = $this->floorChanceScore($scoreBefore, $change);
                }

                // FIX-F-06: claim اول — تنها دارندهٔ UNIQUE(P,D) ادامه می‌دهد
                $claimId = $this->chanceLogModel->claimForParticipationDate([
                    'participation_id' => (int)$p->id,
                    'user_id' => (int)$p->user_id,
                    'round_id' => $roundId,
                    'date' => $date,
                    'score_before' => $scoreBefore,
                    'score_change' => $change,
                    'score_after' => $scoreAfter,
                    'reason' => $reason,
                    'details' => $details,
                ]);
                if ($claimId === null) {
                    $skippedCount++;
                    continue;
                }

                // FIX-F-07: ledger gate — applyDelta روی rate-limit/fraud/velocity/alt
                // false برمی‌گرداند؛ قبلاً مقدار بازگشتی نادیده گرفته می‌شد و
                // participation.chance_score + ردیف لاگ از لجر امتیاز واگرا می‌شدند.
                // اکنون ردِ لجر = rollback کامل این تراکنش (claim + update هرگز
                // بی‌همتای لجر commit نمی‌شوند).
                $ledgerApplied = $this->scoreService->applyDelta(
                    'user',
                    (int)$p->user_id,
                    'lottery_chance',
                    $change,
                    !$userVote ? 'lottery_no_vote' : 'lottery_daily_vote',
                    !$userVote
                        ? ['round_id' => $roundId, 'date' => $date]
                        : ['round_id' => $roundId, 'daily_id' => (int)$dailyNumber->id, 'date' => $date],
                    !$userVote
                        ? "lottery:novote:{$roundId}:{$p->user_id}:{$date}"
                        : "lottery:vote:{$roundId}:{$p->user_id}:{$date}"
                );
                if ($ledgerApplied !== true) {
                    throw new \RuntimeException(
                        "lottery chance score ledger rejected the delta (participation_id={$p->id}, change={$change}); transaction rolled back to keep participation/chance-log consistent with the score ledger."
                    );
                }

                // Update participation record (فقط پس از accept شدن لجر)
                $this->participationModel->update((int)$p->id, ['chance_score' => $scoreAfter]);

                $updatedCount++;
            }

            $this->db->commit();

            // cache.invalidate — internal in-process event، نیازی به Outbox ندارد
            // ScoreService.applyDelta خودش event sourcing را انجام می‌دهد
            try {
                $this->eventDispatcher->dispatch('cache.invalidate', ['key' => "participants_{$roundId}"]);
            } catch (\Throwable $e) {
                // Non-blocking
            }

            $this->logger->info('lottery_chance_updated', [
                'message' => "Round {$roundId}, updated {$updatedCount} participants ({$skippedCount} already processed)",
                'stats' => ['total_reward' => round($totalReward, 2), 'total_penalty' => round($totalPenalty, 2)],
            ]);

            return [
                'success' => true,
                'message' => 'امتیازات شانس با موفقیت به‌روزرسانی شدند.',
                'updated_count' => $updatedCount,
                'skipped_count' => $skippedCount,
                'stats' => ['total_reward' => round($totalReward, 2), 'total_penalty' => round($totalPenalty, 2)],
            ];

        } catch (\Throwable $e) {
            // FIX-R19-A6-11: rollback بدون گارد درTransaction در صورت شکستِ خودِ commit
            // ("no active transaction") خطای واقعی را ماسک می‌کند. (تغییرِ ساختارِ
            // تراکنش‌بندی عمداً انجام نشد — خارج از دامنهٔ این فیکس.)
            if ($this->db->inTransaction()) $this->db->rollback();
            $this->logger->error('lottery_chance_error', ['message' => $e->getMessage()]);
            return ['success' => false, 'message' => 'خطا در به‌روزرسانی امتیازات شانس.'];
        }
    }

    /**
     * بررسی تطابق شماره انتخاب شده کاربر با اعداد روزانه
     */
    private function checkMatch(string $ticketNumber, int $selectedNumber): bool
    {
        // Logic: اگر selectedNumber در بین اعداد بلیط کاربر باشد → تطابق
        $numbers = explode(',', $ticketNumber);
        return in_array($selectedNumber, array_map('intval', $numbers), true);
    }

    /**
     * FIX-F-07: کف امتیاز شانس — از ثابت مدل (MIN_CHANCE=5.0) استفاده می‌کند و
     * رفتار «بالا بردنِ» مقادیر legacy زیر کف را هم درست می‌کند: اگر اسکور فعلی
     * زیر کف است، فقط از منفی‌شدن جلوگیری می‌شود؛ اگر بالای/مساوی کف است، جریمه
     * از کف عبور نمی‌کند.
     */
    private function floorChanceScore(float $scoreBefore, float $change): float
    {
        $scoreAfter = round($scoreBefore + $change, 4);
        if ($scoreBefore >= self::MIN_CHANCE) {
            return max($scoreAfter, self::MIN_CHANCE);
        }
        return max($scoreAfter, 0.0);
    }
}