<?php

declare(strict_types=1);

namespace App\Jobs\AntiFraud;

use App\Services\AntiFraud\IPQualityService;
use App\Services\AntiFraud\SessionAnomalyService;
use App\Services\AntiFraud\VelocityCheckService;
use App\Services\AntiFraud\BehavioralBiometricsService;
use App\Services\AntiFraud\SeoFraudDetector;
use App\Services\FeatureFlagService;
use App\Services\SocialTask\SilentAntiFraudService;

class CheckTaskFraudJob
{
    public function __construct(
        private IPQualityService $ipQuality,
        private SessionAnomalyService $sessionAnomaly,
        private VelocityCheckService $velocity,
        private BehavioralBiometricsService $biometrics,
        private SeoFraudDetector $seoDetector,
        private SilentAntiFraudService $silentAntiFraud,
        private FeatureFlagService $featureFlag
    ) {}

    public function handle(int $userId, string $action, array $context): array
    {
        $results = [];
        $ip = $context['ip'] ?? $this->clientIp();
        $sessionId = $context['session_id'] ?? session_id();

        switch ($action) {
            case 'task.custom':
                $results['ip_quality'] = $this->ipQuality->check($ip);
                if ($sessionId) {
                    try { $results['session'] = $this->sessionAnomaly->analyze($userId, $sessionId); } catch (\Throwable $e) {}
                }
                $results['velocity'] = $this->velocity->check($userId, 'task_execution', $context);
                if (!$this->skipHeavyChecks($userId) && !empty($context['biometric_data'])) {
                    $results['biometrics'] = $this->biometrics->analyzePatterns($userId, $context['biometric_data']);
                }
                if (!empty($context['suspicious_signature'])) {
                    $results['signature'] = ['allowed' => false, 'reason' => 'suspicious_signature'];
                }
                break;

            case 'task.social':
                $results['silent_fraud'] = $this->silentAntiFraud->calculateRiskScore($userId, $context);
                if (($results['silent_fraud']['risk_score'] ?? 0) >= 80) {
                    $results['decision'] = ['allowed' => false, 'reason' => 'high_silent_fraud_risk'];
                }
                if (!empty($context['suspicious_signature'])) {
                    $results['signature'] = ['allowed' => false, 'reason' => 'suspicious_signature'];
                }
                break;

            case 'task.seo':
                $adId = (int)($context['ad_id'] ?? 0);
                $results['seo_fraud'] = $this->seoDetector->detect($userId, $adId, $context['engagement_data'] ?? []);
                if ($sessionId) {
                    try { $results['session'] = $this->sessionAnomaly->analyze($userId, $sessionId); } catch (\Throwable $e) {}
                }
                break;
        }

        return $results;
    }

    private function skipHeavyChecks(?int $userId): bool
    {
        try {
            return (bool)$this->featureFlag->isEnabled('anti_fraud.heavy_checks_disabled', $userId);
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function clientIp(): string
    {
        return get_client_ip();
    }
}
