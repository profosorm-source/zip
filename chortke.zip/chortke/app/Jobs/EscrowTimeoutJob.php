<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Contracts\LoggerInterface;
use App\Domain\Financial\Services\FinancialEscrowService;
use Core\EventDispatcher;

class EscrowTimeoutJob
{
    private FinancialEscrowService $escrowService;
    private LoggerInterface $logger;
    private EventDispatcher $eventDispatcher;

    public function __construct(
        FinancialEscrowService $escrowService,
        LoggerInterface $logger,
        EventDispatcher $eventDispatcher
    ) {
        $this->eventDispatcher = $eventDispatcher;
        $this->escrowService = $escrowService;
        $this->logger = $logger;
    }

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data = []): void
    {
        try {
            $released = $this->escrowService->releaseExpiredHolds();
            if ($released > 0) {
                $this->logger->info('escrow.timeout_released', ['released' => $released]);
                // 🛡️ FIX-DEAD-EVENT (pre-existing): رویداد تجمعی escrow.auto_released هیچ
                // listener ای نداشت (publisher بی‌صدا no-op می‌کرد)؛ اثر واقعی — یعنی
                // نوتیفیکیشن بازگشت وجه به هر خریدار — از داخل FinancialEscrowService::
                // releaseExpiredHolds به‌صورت per-buyer ثبت می‌شود. رکورد بی‌اثر حذف شد.
                // cache.invalidate — internal، مستقیم dispatch کافی است
                try { $this->eventDispatcher->dispatch('cache.invalidate', ['key' => 'escrow']); } catch (\Throwable $e) {}
            } else {
                $this->logger->info('escrow.timeout_nothing_to_release', []);
            }
        } catch (\Throwable $e) {
            $this->logger->error('escrow.timeout_failed', ['error' => $e->getMessage()]);
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'escrow.timeout_job',
            ]);
        }
    }
}
