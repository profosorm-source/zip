<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Contracts\LoggerInterface;
use App\Domain\Financial\Services\FinancialEscrowService;
use Core\EventDispatcher;

class EscrowTimeoutJob
{
    private FinancialEscrowService $escrowService;
    private LoggerInterface $logger;
    private EventDispatcher $eventDispatcher;

    public function __construct(
        FinancialEscrowService $escrowService,
        LoggerInterface $logger,
        EventDispatcher $eventDispatcher
    ) {
        $this->escrowService = $escrowService;
        $this->logger = $logger;
        $this->eventDispatcher = $eventDispatcher;
    }

    public function handle(array $data = []): void
    {
        try {
            $released = $this->escrowService->releaseExpiredHolds();
            if ($released > 0) {
                $this->logger->info('escrow.timeout_released', ['released' => $released]);
                try { $this->eventDispatcher->dispatch('escrow.auto_released', ['count' => $released, 'timestamp' => date('Y-m-d H:i:s')]); } catch (\Throwable $e) {}
                try { $this->eventDispatcher->dispatch('cache.invalidate', ['key' => 'escrow']); } catch (\Throwable $e) {}
            } else {
                $this->logger->info('escrow.timeout_nothing_to_release', []);
            }
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->logger->error('escrow.timeout_failed', ['error' => $e->getMessage()]);
        }
    }
}
