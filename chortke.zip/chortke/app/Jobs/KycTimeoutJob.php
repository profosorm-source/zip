<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use App\Contracts\LoggerInterface;

/**
 * KycTimeoutJob
 * 
 * رد خودکار درخواست‌های KYC که بیش از X روز در وضعیت 'pending' یا 'under_review'
 * مانده‌اند و ادمین به آن‌ها رسیدگی نکرده است.
 * 
 * در Cron: هر ساعت اجرا می‌شود
 * 
 * 🛡️ Bug Fix: قبلاً هیچ cron ای برای timeout KYC وجود نداشت
 * و درخواست‌های KYC تا ابد pending می‌ماندند.
 */
class KycTimeoutJob
{
    /**
     * FIX-R18-M9: بدترین زمان اجرای موردانتظار (اسکن KYCهای معوق + اعلان‌ها).
     * QueueWorker از این مقدار برای گسترش visibility (timeoutSeconds*2) استفاده می‌کند.
     */
    public int $timeoutSeconds = 600;

    #[ \Core\Attributes\Inject ]
    private Database $db;

    #[ \Core\Attributes\Inject ]
    private LoggerInterface $logger;

    // 🛡️ FIX-DEAD-EVENT: وابستگی outbox حذف شده بود — اکنون در S18.6 دوباره اضافه
    // می‌شود این بار برای «درِ واحد اعلان» (notification.requested).
    // X130-fix: اتریبیوت #[Inject] یتیمِ روی این کامنت، به پراپرتی بعدی می‌چسبید و
    // «Attribute must not be repeated» می‌داد → جاب kyc_timeout_reject هرگز اجرا نمی‌شد.

    #[ \Core\Attributes\Inject ]
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;

    private const EXPIRY_DAYS = 7;
    private const MAX_PROCESS = 50;
    private const REVIEW_HOURS = 72;

    public function __construct(
        Database $db,
        LoggerInterface $logger,
        // 🛡️ FIX-S18-6I (S18.6): اعلان ردِ timeout از درِ واحد notification.requested.
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {
        $this->db = $db;
        $this->logger = $logger;
        if ($outbox !== null) {
            $this->outbox = $outbox;
        }
    }

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
public function handle(array $data = []): array
    {
        $expiryDays = int_value($data['expiry_days'] ?? self::EXPIRY_DAYS);
        $reviewHours = int_value($data['review_hours'] ?? self::REVIEW_HOURS);
        $limit = int_value($data['limit'] ?? self::MAX_PROCESS);

        $autoRejected  = 0;
        $scanned       = 0;
        $pendingCursor = 0;
        $reviewCursor  = 0;
        $guard         = 0;
        try {
            // cursor: تا خالی‌شدنِ کاملِ صفِ KYCهای منقضی ادامه می‌دهیم تا backlog نماند.
            // هر batch همچنان محدود به $limit است (سقفِ حافظه)؛ cursorِ id تضمین می‌کند هیچ ردیفی
            // دوباره پردازش نشود. FOR UPDATE از SELECTِ کشف حذف شد چون تحتِ autocommit اثری نداشت؛
            // گاردِ واقعیِ همزمانی همان UPDATE شرطیِ «AND status = ?» در هر ردیف است.
            do {
                if (++$guard > 100000) {
                    $this->logger->warning('kyc.timeout.guard_tripped', ['pending_cursor' => $pendingCursor, 'review_cursor' => $reviewCursor]);
                    break;
                }

                // 1. KYCهایی که بیش از X روز در وضعیت pending مانده‌اند (کاربر هنوز مدارک کامل نفرستاده)
                $expiredPending = $this->db->query("
                    SELECT id, user_id, status, created_at
                    FROM kyc_verifications
                    WHERE status = 'pending'
                      AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                      AND id > ?
                    ORDER BY id ASC
                    LIMIT ?
                ", [$expiryDays, $pendingCursor, $limit])->fetchAll(\PDO::FETCH_OBJ);

                // 2. KYCهایی که بیش از X ساعت در وضعیت under_review مانده‌اند (ادمین بررسی نکرده)
                // 🛡️ FIX-CH12: قدمت از review_started_at (لحظهٔ واقعی شروع بررسی —
                // lockForReview آن را NOW() می‌گذارد) نه created_at؛ درخواستی که
                // همین امروز وارد under_review شده ولی رکوردش قدیمی است دیگر فوراً
                // auto-reject نمی‌شود. ردیف بدون review_started_at fail-safe skip می‌شود.
                $expiredReview = $this->db->query("
                    SELECT id, user_id, status, created_at
                    FROM kyc_verifications
                    WHERE status = 'under_review'
                      AND review_started_at IS NOT NULL
                      AND review_started_at < DATE_SUB(NOW(), INTERVAL ? HOUR)
                      AND id > ?
                    ORDER BY id ASC
                    LIMIT ?
                ", [$reviewHours, $reviewCursor, $limit])->fetchAll(\PDO::FETCH_OBJ);

                $pendingCount = count($expiredPending);
                $reviewCount  = count($expiredReview);
                foreach ($expiredPending as $__r) { if ((int)$__r->id > $pendingCursor) $pendingCursor = (int)$__r->id; }
                foreach ($expiredReview as $__r) { if ((int)$__r->id > $reviewCursor) $reviewCursor = (int)$__r->id; }

                $allExpired = array_merge($expiredPending, $expiredReview);
                $scanned += count($allExpired);

            foreach ($allExpired as $kyc) {
                try {
                    $this->db->beginTransaction();

                    // 🛡️ FIX-M10-H8 (گزارش جامع M10 — بحرانیِ رفتاری): timeout دیگر
                    // «کاربر را رد نمی‌کند». pending قدیمی یعنی صفِ ادمین عقب مانده؛
                    // under_review قدیمی یعنی بررسیِ ادمین طول کشیده — هیچ‌کدام تقصیر
                    // کاربر نیست. به‌جای rejected: علامت‌گذاری escalation یک‌باره روی
                    // خودِ رکورد (admin_note) بدونِ تغییرِ وضعیت، بدونِ جریمهٔ users
                    // (kyc_status/kyc_level دست‌نخورده) و بدونِ اعلانِ ردِ کاذب به کاربر.
                    // رکوردهای verifiedِ منقضی (deadline واقعیِ اعتبار) همچنان در بخشِ
                    // FIX-M10-01 به expired می‌روند — آن یگانه deadline واقعیِ کاربر است.
                    $escalationNote = $kyc->status === 'pending'
                        ? '⏰ escalation خودکار: بیش از ' . (int)$expiryDays . ' روز در انتظارِ اولین بررسی است'
                        : '⏰ escalation خودکار: بیش از ' . (int)$reviewHours . ' ساعت در وضعیت بررسی است';
                    $stmt = $this->db->query(
                        "UPDATE kyc_verifications
                            SET admin_note = CONCAT(COALESCE(admin_note, ''), ?),
                                updated_at = NOW()
                          WHERE id = ? AND status = ?
                            AND (admin_note IS NULL OR admin_note NOT LIKE '%⏰ escalation خودکار%')",
                        ["\n" . $escalationNote, (int)$kyc->id, $kyc->status]
                    );
                    $updated = (int)$stmt->rowCount();

                    $this->db->commit();

                    // 🛡️ FIX-R18-M13: فقط وقتی UPDATE واقعاً یک ردیف را تغییر داده
                    // (rowCount === 1) شمرده می‌شود؛ اجرای بعدیِ job (یا رقابت) به‌خاطر
                    // گاردِ NOT LIKE دیگر علائم تکراری یا اعلانِ مضاعف تولید نمی‌کند.
                    if ($updated !== 1) {
                        $this->logger->info('kyc.timeout_race_lost', [
                            'kyc_id' => (int)$kyc->id,
                            'expected_status' => (string)$kyc->status,
                        ]);
                        continue;
                    }

                    $this->logger->warning('kyc.timeout.escalated', [
                        'kyc_id' => (int)$kyc->id,
                        'status' => (string)$kyc->status,
                        'user_id' => (int)$kyc->user_id,
                    ]);
                    $autoRejected++; // شمارندهٔ سازگاریِ خروجی (escalation، نه رد)

                } catch (\Throwable $e) {
                    if ($this->db->inTransaction()) {
                        $this->db->rollback();
                    }
                    $this->logger->error('kyc.timeout_reject_failed', [
                        'kyc_id' => $kyc->id,
                        'error' => $e->getMessage(),
                    ]);
                }
            }

            } while ($pendingCount === $limit || $reviewCount === $limit);

            // 🛡️ FIX-M10-01 (بحرانی — گزارش ماژول ۱۰): انقضای KYCهای verified که expires_at
            // آنها گذشته. قبلاً هیچ jobی verifiedهای منقضی را پردازش نمی‌کرد و gیت‌های
            // صلاحیت هم expires_at را نمی‌سنجیدند — تأییدِ یک‌ساله برای همیشه معتبر می‌ماند.
            // اکنون: status → 'expired' (enum توسعه‌یافته) + هم‌سازی users.kyc_status/kyc_level
            // + اعلانِ unit. (صحتِ هم‌زمانه حتی قبل از اجرای job با KycEligibilityService
            // تضمین شده است — expires_at در همان query صلاحیت سنجیده می‌شود.)
            $expiredVerified = 0;
            $expiryCursor = 0;
            $expiryGuard = 0;
            do {
                if (++$expiryGuard > 100000) { break; }
                $rows = $this->db->query("
                    SELECT id, user_id, status
                    FROM kyc_verifications
                    WHERE status = 'verified'
                      AND expires_at IS NOT NULL
                      AND expires_at < NOW()
                      AND id > ?
                    ORDER BY id ASC
                    LIMIT ?
                ", [$expiryCursor, $limit])->fetchAll(\PDO::FETCH_OBJ);

                foreach ($rows as $kyc) {
                    try {
                        $this->db->beginTransaction();

                        $stmt = $this->db->query(
                            "UPDATE kyc_verifications
                                SET status = 'expired', reviewed_at = COALESCE(reviewed_at, NOW()), updated_at = NOW()
                              WHERE id = ? AND status = 'verified'
                                AND expires_at IS NOT NULL AND expires_at < NOW()",
                            [(int)$kyc->id]
                        );
                        $updated = (int)$stmt->rowCount();

                        if ($updated === 1) {
                            // هم‌سازی users — همان قرارداد مسیرِ reject (سطح صفر + تاریخ پاک)
                            // اما kyc_status = 'expired' برای تفکیکِ نمایشی از ردِ صریح
                            $this->db->query(
                                'UPDATE users SET kyc_status=?, kyc_level=0, kyc_verified_at=NULL, updated_at=NOW() WHERE id=? AND kyc_status = \'verified\'',
                                ['expired', (int)$kyc->user_id]
                            );
                        }

                        $this->db->commit();

                        if ($updated !== 1) {
                            $this->logger->info('kyc.expiry_race_lost', ['kyc_id' => (int)$kyc->id]);
                            continue;
                        }

                        try {
                            $this->outbox?->record('kyc', (string)$kyc->id, 'notification.requested', [
                                'event_id'      => 'kyc_expired_' . (int)$kyc->id,
                                'user_id'       => (int)$kyc->user_id,
                                'template'      => 'kyc_rejected',
                                'template_vars' => [
                                    'reason'   => 'اعتبار احراز هویت شما منقضی شده است؛ لطفاً مدارک را مجدداً ارسال کنید.',
                                    'event_id' => 'kyc_expired_' . (int)$kyc->id,
                                ],
                                'priority'      => 'urgent',
                                'action_url'    => '/kyc/upload',
                                'action_text'   => 'ارسال مجدد مدارک',
                            ]);
                        } catch (\Throwable $notifyError) {
                            $this->logger->warning('kyc.expiry.notification_request_failed', ['kyc_id' => $kyc->id, 'error' => $notifyError->getMessage()]);
                        }
                        $expiredVerified++;
                    } catch (\Throwable $e) {
                        if ($this->db->inTransaction()) { $this->db->rollback(); }
                        $this->logger->error('kyc.expiry_failed', ['kyc_id' => $kyc->id, 'error' => $e->getMessage()]);
                    }
                    if ((int)$kyc->id > $expiryCursor) $expiryCursor = (int)$kyc->id;
                }
                $scanned += count($rows);
            } while (count($rows) === $limit);

            if ($expiredVerified > 0) {
                $this->logger->info('kyc.verified_expired', ['expired' => $expiredVerified]);
            }

            if ($autoRejected > 0) {
                $this->logger->info('kyc.auto_rejected_timeout', [
                    'total_expired' => $scanned,
                    'auto_rejected' => $autoRejected,
                ]);
            }

            return [
                'scanned'       => $scanned,
                'auto_rejected' => $autoRejected,
                'expired_verified' => $expiredVerified,
                'message'       => "{$autoRejected} KYC به صورت خودکار رد شد و {$expiredVerified} تأییدشده منقضی شد",
            ];

        } catch (\Throwable $e) {
            $this->logger->error('kyc.timeout_scan_failed', ['error' => $e->getMessage()]);
            return ['scanned' => 0, 'auto_rejected' => 0, 'error' => $e->getMessage()];
        }
    }
}
