<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use App\Contracts\LoggerInterface;

/**
 * KycTimeoutJob
 * 
 * رد خودکار درخواست‌های KYC که بیش از X روز در وضعیت 'pending' یا 'under_review'
 * مانده‌اند و ادمین به آن‌ها رسیدگی نکرده است.
 * 
 * در Cron: هر ساعت اجرا می‌شود
 * 
 * 🛡️ Bug Fix: قبلاً هیچ cron ای برای timeout KYC وجود نداشت
 * و درخواست‌های KYC تا ابد pending می‌ماندند.
 */
class KycTimeoutJob
{
    #[ \Core\Attributes\Inject ]
    private Database $db;

    #[ \Core\Attributes\Inject ]
    private LoggerInterface $logger;

    #[ \Core\Attributes\Inject ]
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;

    #[ \Core\Attributes\Inject ]
    private ?\App\Services\Notification\NotificationService $notificationService = null;

    private const EXPIRY_DAYS = 7;
    private const MAX_PROCESS = 50;
    private const REVIEW_HOURS = 72;

    public function __construct(?\App\Contracts\OutboxServiceInterface $outbox = null) {
        if ($outbox !== null) {
            $this->outbox = $outbox;
        }
    }

    public function handle(array $data = []): array
    {
        $expiryDays = (int)($data['expiry_days'] ?? self::EXPIRY_DAYS);
        $reviewHours = (int)($data['review_hours'] ?? self::REVIEW_HOURS);
        $limit = (int)($data['limit'] ?? self::MAX_PROCESS);

        try {
            // 1. KYCهایی که بیش از X روز در وضعیت pending مانده‌اند (کاربر هنوز مدارک کامل نفرستاده)
            // اصلاح حیاتی معماری همزمانی: استفاده از FOR UPDATE جهت قفل‌گذاری اتمیک و جلوگیری از تداخل ورکرهای کرون
            $expiredPending = $this->db->query("
                SELECT id, user_id, status, created_at
                FROM kyc_verifications
                WHERE status = 'pending'
                  AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                LIMIT ? FOR UPDATE
            ", [$expiryDays, $limit])->fetchAll(\PDO::FETCH_OBJ);

            // 2. KYCهایی که بیش از X ساعت در وضعیت under_review مانده‌اند (ادمین بررسی نکرده)
            $expiredReview = $this->db->query("
                SELECT id, user_id, status, created_at
                FROM kyc_verifications
                WHERE status = 'under_review'
                  AND created_at < DATE_SUB(NOW(), INTERVAL ? HOUR)
                LIMIT ? FOR UPDATE
            ", [$reviewHours, $limit])->fetchAll(\PDO::FETCH_OBJ);

            $allExpired = array_merge($expiredPending, $expiredReview);
            $autoRejected = 0;

            foreach ($allExpired as $kyc) {
                try {
                    $this->db->beginTransaction();

                    // به‌روزرسانی وضعیت KYC به rejected (منقضی شده)
                    $this->db->query(
                        "UPDATE kyc_verifications SET 
                         status = 'rejected', 
                         rejection_reason = 'auto_rejected_timeout',
                         reviewed_at = NOW(),
                         updated_at = NOW()
                         WHERE id = ? AND status = ?",
                        [(int)$kyc->id, $kyc->status]
                    );

                    // dispatch ایونت برای اطلاع‌رسانی
                    $this->outbox?->record('kyc', (int)$kyc->id, 'kyc.status_changed', [
                        'kyc_id'     => (int)$kyc->id,
                        'user_id'    => (int)$kyc->user_id,
                        'old_status' => $kyc->status,
                        'new_status' => 'rejected',
                        'reason'     => 'timeout',
                    ]);

                    $this->db->commit();
                    $this->notificationService?->kycRejected((int)$kyc->user_id, 'درخواست احراز هویت به دلیل عدم رسیدگی در بازه مجاز منقضی شد.');
                    $autoRejected++;

                } catch (\Throwable $e) {
                    $this->db->rollback();
                    $this->logger->error('kyc.timeout_reject_failed', [
                        'kyc_id' => $kyc->id,
                        'error' => $e->getMessage(),
                    ]);
                }
            }

            if ($autoRejected > 0) {
                $this->logger->info('kyc.auto_rejected_timeout', [
                    'total_expired' => count($allExpired),
                    'auto_rejected' => $autoRejected,
                ]);
            }

            return [
                'scanned'       => count($allExpired),
                'auto_rejected' => $autoRejected,
                'message'       => "{$autoRejected} KYC به صورت خودکار رد شد",
            ];

        } catch (\Throwable $e) {
            $this->logger->error('kyc.timeout_scan_failed', ['error' => $e->getMessage()]);
            return ['scanned' => 0, 'auto_rejected' => 0, 'error' => $e->getMessage()];
        }
    }
}
