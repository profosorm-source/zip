<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Scheduler;

/**
 * RunCronTaskJob
 * 
 * این جاب توسط Queue Worker دریافت می‌شود و مسئول اجرای واقعی کلوژرهای کرون‌جاب‌ها در پس‌زمینه است.
 */
class RunCronTaskJob
{
    private Scheduler $scheduler;

    public function __construct(Scheduler $scheduler) {
        $this->scheduler = $scheduler;
    }

    /**
     * @param array $data باید شامل کلید 'task_name' باشد
     */
    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data): void
    {
        $taskNameValue = $data['task_name'] ?? null;
        if (!is_string($taskNameValue) || trim($taskNameValue) === '') {
            logger()->error('run_cron_task_job_failed', ['reason' => 'missing_task_name']);
            return;
        }
        $taskName = trim($taskNameValue);

        try {
            
            // اطمینان از اینکه Kernel بارگذاری شده و وظایف ثبت شده‌اند
            if (class_exists(\App\Console\Kernel::class)) {
                // BUGFIX-PHASE3-P315: فلگ مردهٔ forceRegisterJobs حذف شد — از FIX-X147
                // به بعد جاب‌ها همیشه رجیستر می‌شوند و گیت زمان‌بندی در run()/dispatchAllAsync است.
                \App\Console\Kernel::schedule($this->scheduler);
            } else {
                throw new \Core\Exceptions\ApplicationException("کلاس App\\Console\\Kernel یافت نشد");
            }

            // اجرای مستقیم متد متناظر با این تسک
            // 🛡️ FIX-P34: مسیر ورکر با گیت lastRun — کپی‌های تکراریِ صف (backlog)
            // پس از یک اجرای موفقِ همین بازه، callback را دوباره اجرا نمی‌کنند.
            $this->scheduler->executeJobByName($taskName, true);

            // FIX-X210: تازه‌سازی تب «سیستم» صفحهٔ لاگ‌ها — یک ردیف INFO به‌ازای هر اجرای موفق
            // جاب کرون (جدول system_logs از روز اول بدون نویسنده بود). fail-safe.
            try {
                (new \App\Models\SystemLog(db()))->insert([
                    'level' => 'INFO',
                    'channel' => 'cron',
                    'message' => 'جاب زمان‌بندی‌شده اجرا شد: ' . $taskName,
                    'context' => json_encode(['task' => $taskName], JSON_UNESCAPED_UNICODE),
                ]);
            } catch (\Throwable $sysLogEx) {
                @error_log('[RunCronTaskJob] system_log insert failed: ' . $sysLogEx->getMessage());
            }

        } catch (\Throwable $e) {
            logger()->error('run_cron_task_job_exception', [
                'task_name' => $taskName,
                'error'     => $e->getMessage(),
                'file'      => $e->getFile(),
                'line'      => $e->getLine()
            ]);
            // FIX-X210: شکست جاب کرون در system_logs با سطح ERROR (چرخهٔ کامل سیستم)
            try {
                (new \App\Models\SystemLog(db()))->insert([
                    'level' => 'ERROR',
                    'channel' => 'cron',
                    'message' => 'شکست جاب زمان‌بندی‌شده: ' . $taskName . ' — ' . $e->getMessage(),
                    'context' => json_encode(['task' => $taskName, 'file' => $e->getFile(), 'line' => $e->getLine()], JSON_UNESCAPED_UNICODE),
                ]);
            } catch (\Throwable $sysLogEx2) {
                @error_log('[RunCronTaskJob] system_log(fail) insert failed: ' . $sysLogEx2->getMessage());
            }
            throw $e; // Throwing it allows the Queue system to handle retries/DLQ
        }
    }
}
