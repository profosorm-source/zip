<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Contracts\LoggerInterface;
use App\Services\InvestmentService;
use App\Services\Settings\AppSettings;
use Core\Database;

/**
 * InvestmentProfitDistributionJob
 *
 * توزیع سود/ضرر سرمایه‌گذاری‌ها به صورت دوره‌ای.
 * - لیست سرمایه‌گذاری‌های فعال را فراخوانی می‌کند.
 * - در صورت عدم ارسال داده، از آخرین ترید بسته‌شده و تنظیمات پیش‌فرض استفاده می‌کند.
 */
class InvestmentProfitDistributionJob
{
    /**
     * FIX-R18-M9: بدترین زمان اجرای موردانتظار (توزیع سود/زیان per-trading-record).
     * QueueWorker از این مقدار برای گسترش visibility (timeoutSeconds*2) استفاده می‌کند.
     */
    public int $timeoutSeconds = 900;

    private const SYSTEM_ADMIN_ID = 0;

    private InvestmentService $investmentService;
    private Database $db;
    private AppSettings $appSettings;
    private LoggerInterface $logger;
    private ?\App\Services\Shared\IdempotencyService $idempotencyService;
    public function __construct(
        InvestmentService $investmentService,
        Database $db,
        AppSettings $appSettings,
        LoggerInterface $logger,
        ?\App\Services\Shared\IdempotencyService $idempotencyService = null
    ) {        $this->investmentService = $investmentService;
        $this->db = $db;
        $this->appSettings = $appSettings;
        $this->logger = $logger;
        $this->idempotencyService = $idempotencyService;
}

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data = []): void
    {
        $tradingRecordId = is_scalar($data['trading_record_id'] ?? null) && is_numeric((string)$data['trading_record_id']) ? (int)$data['trading_record_id'] : 0;
        $profitLossPercent = array_key_exists('profit_loss_percent', $data) && is_scalar($data['profit_loss_percent']) ? (string)$data['profit_loss_percent'] : null;
        $period = is_string($data['period'] ?? null) ? $data['period'] : 'weekly';
        $adminId = is_scalar($data['admin_id'] ?? null) && is_numeric((string)$data['admin_id']) ? (int)$data['admin_id'] : self::SYSTEM_ADMIN_ID;

        if ($tradingRecordId <= 0) {
            $tradingRecordId = $this->getLatestClosedTradingRecordId();
        }

        if ($profitLossPercent === null) {
            $configuredPercent = $this->appSettings->get('investment_default_profit_loss_percent', '0');
            $profitLossPercent = is_scalar($configuredPercent) ? (string)$configuredPercent : '0';
        }

        if ($tradingRecordId <= 0 || !is_numeric($profitLossPercent) || bccomp($profitLossPercent, '0', 8) === 0) {
            $this->logger->warning('investment.profit_distribution_skipped', [
                'trading_record_id'   => $tradingRecordId,
                'profit_loss_percent' => $profitLossPercent,
                'period'              => $period,
            ]);
            return;
        }

        // 🔐 FIX-R18-M12: claim per (trading_record_id, period) قبل از اولین batch —
        // قبلاً هیچ claim سطح جاب وجود نداشت و re-delivery/اجرای همزمان همان ترید را
        // دوباره اعمال می‌کرد (سود/زیان مضاعف). اجرای کاملِ توزیع داخل wrap
        // idempotency است: pending در حین اجرا، completed پس از موفقیت، failed_retryable
        // پس از شکست → تلاش مجذ‌اِ (پس از RETRY_DELAY_SECONDS) دوباره اجرا می‌شود،
        // ولی delivery تکراریِ یک اجرایِ موفق فقط نتیجهٔ ذخیره‌شده را برمی‌گرداند (skip).
        $claimKey = 'profit_dist_' . $tradingRecordId . '_' . preg_replace('/[^A-Za-z0-9_]/', '_', (string)$period);

        $ranLocally = false;
        $distribute = function () use ($tradingRecordId, $profitLossPercent, $period, $adminId, &$ranLocally) {
            $ranLocally = true;

            // cursor: idهای active را به‌جای یک‌جا، batch‌به‌batch با cursorِ id می‌خوانیم و هر chunk را
            // جداگانه اعمال می‌کنیم تا مصرف حافظه مهار شود. چون پردازش status را عوض نمی‌کند
            // (همچنان active می‌ماند)، حتماً باید cursorِ id باشد تا هر سرمایه‌گذاری دقیقاً یک‌بار
            // و بدون تکرار پردازش شود. رفتار نهایی مثل قبل است، فقط تکه‌تکه.
            $batchSize   = 500;
            $lastId      = 0;
            $guard       = 0;
            $totalCount  = 0;
            $results     = [];

            do {
                if (++$guard > 100000) {
                    $this->logger->warning('investment.profit_distribution_guard_tripped', ['last_id' => $lastId]);
                    break;
                }

                $rows = $this->db->fetchAll(
                    "SELECT id FROM investments
                     WHERE status = 'active'
                       AND id > ?
                     ORDER BY id ASC
                     LIMIT {$batchSize}",
                    [$lastId]
                ) ?: [];
                $fetched = count($rows);

                if ($fetched === 0) {
                    break;
                }

                $investmentIds = array_map(static fn($row): int => (int) $row->id, $rows);
                $lastId = (int) end($investmentIds);
                $totalCount += $fetched;

                $results[] = $this->investmentService->applyProfitLossToBatch(
                    $investmentIds,
                    $tradingRecordId,
                    $profitLossPercent,
                    $period,
                    $adminId
                );
            } while ($fetched === $batchSize);

            if ($totalCount === 0) {
                $this->logger->info('investment.profit_distribution_no_active_investments', [
                    'period' => $period,
                ]);
                return ['processed_count' => 0];
            }

            $this->logger->info('investment.profit_distribution_job_completed', [
                'trading_record_id'   => $tradingRecordId,
                'profit_loss_percent' => $profitLossPercent,
                'period'              => $period,
                'admin_id'            => $adminId,
                'processed_count'     => $totalCount,
                'batches'             => count($results),
            ]);

            return ['processed_count' => $totalCount, 'batches' => count($results)];
        };

        // FIX-R18-M12: قطعِ catch-all قبلی — استثنای پردازش باید log + rethrow شود تا
        // QueueWorker طبقه‌بندی/retry کند (کامنت زیر در مسیر claim هم رعایت شده است).

        $idem = $this->idempotencyService;
        if ($idem === null) {
            // سازگاری با ساخت‌های ۴آرگومانی قدیمی: تلاش برای resolve از کانتینر.
            try {
                $idem = \Core\Container::getInstance()->make(\App\Services\Shared\IdempotencyService::class);
            } catch (\Throwable $resolveEx) {
                $idem = null;
            }
        }

        if ($idem !== null) {
            try {
                $idem->execute(
                    'investment_profit_distribution',
                    self::SYSTEM_ADMIN_ID,
                    ['trading_record_id' => $tradingRecordId, 'period' => $period, 'profit_loss_percent' => $profitLossPercent, 'admin_id' => $adminId],
                    $distribute,
                    $claimKey
                );
                if (!$ranLocally) {
                    // claim از قبل موجود (اجرای موفق قبلی) → skip با لاگ؛ بدون پردازشِ مجدد.
                    $this->logger->warning('investment.profit_distribution_claim_exists_skip', [
                        'claim_key'         => $claimKey,
                        'trading_record_id' => $tradingRecordId,
                        'period'            => $period,
                    ]);
                }
                return;
            } catch (\Throwable $claimEx) {
                if ($ranLocally) {
                    // استثنای «پردازش» (callback آغاز شده بود) → log + rethrow تا QueueWorker
                    // طبقه‌بندی/retry کند. wrapInstance خودش fail(retryable) را روی کلید ثبت کرده است.
                    $this->logger->error('investment.profit_distribution_job_failed', [
                        'error'               => $claimEx->getMessage(),
                        'claim_key'           => $claimKey,
                        'trading_record_id'   => $tradingRecordId,
                        'profit_loss_percent' => $profitLossPercent,
                        'period'              => $period,
                    ]);
                    throw $claimEx;
                }
                // شکستِ خودِ claim (قفل concurrency/رکورد pending زنده/collision)
                // → برقراری دستور ممیزی: log + return (بدون اجرایِ بدون‌claim).
                $this->logger->error('investment.profit_distribution_claim_failed', [
                    'claim_key'           => $claimKey,
                    'trading_record_id'   => $tradingRecordId,
                    'period'              => $period,
                    'error'               => $claimEx->getMessage(),
                    'note'                => 'claim not acquired — distribution not executed (anti-double-apply guard)',
                ]);
                return;
            }
        }

        // Fallback (سرویس idempotency در دسترس نیست): claim با Cache::add (SETNX) —
        // ۶ ساعت؛ از اجرای همزمان/دوبل جلوگیری می‌کند اما لجرِ دائمی DB را ندارد.
        try {
            $claimed = cache()->add('profit_dist_claim_' . md5($claimKey), 1, 21600);
        } catch (\Throwable $cacheEx) {
            $this->logger->error('investment.profit_distribution_cache_claim_failed', ['error' => $cacheEx->getMessage()]);
            return;
        }
        if (!$claimed) {
            $this->logger->warning('investment.profit_distribution_claim_exists_skip', [
                'claim_key'         => $claimKey,
                'trading_record_id' => $tradingRecordId,
                'period'            => $period,
            ]);
            return;
        }
        $distribute();
    }

    private function getLatestClosedTradingRecordId(): int
    {
        try {
            $row = $this->db->fetch(
                "SELECT id FROM trading_records
                 WHERE status IN (?, ?) AND is_deleted = 0
                 ORDER BY close_time DESC
                 LIMIT 1",
                ['closed', 'stopped']
            );

            return $row ? (int) $row->id : 0;
        } catch (\Throwable $e) {
            $this->logger->warning('investment.profit_distribution_no_trading_record', ['error' => $e->getMessage()]);
            return 0;
        }
    }
}
