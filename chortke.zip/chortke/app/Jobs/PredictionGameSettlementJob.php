<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Services\PredictionService;
use App\Contracts\LoggerInterface;
use App\Models\PredictionGame;
use Core\Database;

/**
 * PredictionGameSettlementJob
 *
 * COMPATIBILITY_JOB / SCHEDULED_GUARD:
 * مسیر اصلی تسویه از پنل ادمین و PredictionService انجام می‌شود. این Job حذف نشده، چون در
 * Kernel هر ۱۵ دقیقه صف می‌شود و برای سازگاری با سناریوهای قدیمی/داخلی که بازی را
 * به status='closed' همراه result اما بدون winners_paid می‌گذارند، همان مسیر اصلی
 * PredictionService::settleGameOrFail را صدا می‌زند.
 *
 * نکته مهم: Job خودش هیچ پرداخت مستقیمی انجام نمی‌دهد و مسیر مالی را دور نمی‌زند.
 */
class PredictionGameSettlementJob
{
    /**
     * FIX-R18-M9: بدترین زمان اجرای موردانتظار (تسویهٔ کامل بازی‌های پیش‌بینی).
     * QueueWorker از این مقدار برای گسترش visibility (timeoutSeconds*2) استفاده می‌کند.
     */
    public int $timeoutSeconds = 900;

    private const SYSTEM_ADMIN_ID = 0;

    public function __construct(
        private PredictionService $predictionService,
        private Database $db,
        private LoggerInterface $logger
    ) {}

    /**
     * @return array{success:bool,settled:int,failed:int,skipped:int}
     */
/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
public function handle(array $data = []): array
    {
        $settled = 0;
        $failed = 0;
        $skipped = 0;
        $errors = [];

        try {
            $games = $this->db->fetchAll(
                "SELECT id, result
                 FROM prediction_games
                 WHERE status = '" . PredictionGame::STATUS_CLOSED . "'
                   AND result IS NOT NULL
                   AND result != ''
                   AND winners_paid = 0
                   AND finished_at IS NULL
                   AND deleted_at IS NULL
                 ORDER BY bet_deadline ASC
                 LIMIT 50"
            );

            foreach ($games as $game) {
                try {
                    $result = $this->predictionService->settleGameOrFail(
                        (int)$game->id,
                        (string)$game->result,
                        self::SYSTEM_ADMIN_ID
                    );

                    if (!empty($result['success'])) {
                        $settled++;
                        $this->logger->info('prediction.auto_settled', [
                            'game_id' => (int)$game->id,
                            'result'  => (string)$game->result,
                            'summary' => $result['summary'] ?? [],
                        ]);
                    } else {
                        $failed++;
                        $this->logger->warning('prediction.auto_settle_rejected', [
                            'game_id' => (int)$game->id,
                            'result'  => (string)$game->result,
                            'message' => $result['message'] ?? 'تسویه خودکار انجام نشد.',
                        ]);
                    }
                } catch (\Throwable $e) {
                    $failed++;
                    $errors[] = [
                        'game_id' => (int)$game->id,
                        'error' => $e->getMessage(),
                    ];
                    $this->logger->error('prediction.auto_settle_failed', [
                        'game_id' => (int)$game->id,
                        'error'   => $e->getMessage(),
                    ]);
                }
            }

            if (empty($games)) {
                $skipped = 0;
            }

            if ($failed > 0) {
                throw new \RuntimeException(
                    'تسویه خودکار حداقل یک بازی ناموفق بود: ' . json_encode($errors, JSON_UNESCAPED_UNICODE)
                );
            }

            $payload = [
                'success' => true,
                'settled' => $settled,
                'failed'  => $failed,
                'skipped' => $skipped,
            ];
            $this->logger->info('prediction.settlement_job_completed', $payload);
            return $payload;
        } catch (\Throwable $e) {
            $this->logger->error('prediction.settlement_job_fatal', ['error' => $e->getMessage()]);
            throw $e;
        }
    }
}
