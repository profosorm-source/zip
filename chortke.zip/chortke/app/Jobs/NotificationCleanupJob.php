<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Contracts\LoggerInterface;
use Core\Database;

/**
 * NotificationCleanupJob
 *
 * حذف اعلان‌های قدیمی از جدول notifications طبق سیاست نگهداری.
 */
class NotificationCleanupJob
{
    private const DEFAULT_RETENTION_DAYS = 365;

    private Database $db;
    private LoggerInterface $logger;
    public function __construct(
        Database $db,
        LoggerInterface $logger
    ) {        $this->db = $db;
        $this->logger = $logger;
}

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data = []): void
    {
        $retentionDays = int_value($data['retention_days'] ?? self::DEFAULT_RETENTION_DAYS);
        $retentionDays = max(30, min(3650, $retentionDays));

        try {
            // 🛡️ FIX-R64-A2 (بازرسی چرخهٔ حیات — بخش A): DELETE قبلاً یک‌جا و
            // بدون LIMIT بود؛ اولین اجرا روی جدولِ انباشتهٔ legacy (یا بعد از
            // تغییر retention) ردیف‌های میلیون‌هاگانه‌ای را با یک قفل طولانی
            // حذف می‌کرد و کل جدول را برای کاربران قفل می‌ساخت. اکنون تکه‌ای:
            // حداکثر ۵۰۰۰ ردیف در هر گام (پاکسازی روزانه به‌طور طبیعی فقط یک
            // روز داده دارد و در یک-دو گام تمام می‌شود؛ گام‌بندی فقط سپرِ
            // اولین اجراست). ایندکس idx_notifications_created_at
            // (مایگریشن 2026_11_19_0001) پیمایش را index-range می‌کند.
            $deleted = 0;
            do {
                $step = (int) $this->db->execute(
                    "DELETE FROM notifications
                      WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
                      LIMIT 5000",
                    [$retentionDays]
                );
                $deleted += $step;
            } while ($step >= 5000);

            $this->logger->info('notification.cleanup_completed', [
                'deleted'        => $deleted,
                'retention_days' => $retentionDays,
            ]);
        } catch (\Throwable $e) {
            $this->logger->error('notification.cleanup_failed', [
                'error'          => $e->getMessage(),
                'retention_days' => $retentionDays,
            ]);
        }
    }
}
