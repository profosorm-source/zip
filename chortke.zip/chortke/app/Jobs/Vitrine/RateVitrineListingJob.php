<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Contracts\LoggerInterface;
use App\Contracts\OutboxServiceInterface;
use App\Models\VitrineListing;
use App\Models\VitrineRating;
use Core\Database;
use Core\EventDispatcher;

/**
 * RateVitrineListingJob
 *
 * ثبت امتیاز به لیستینگ ویترین توسط خریدار پس از تحویل.
 * این Job امتیاز را در جدول vitrine_ratings ثبت می‌کند
 * و میانگین امتیاز seller را به‌روزرسانی می‌کند.
 */
class RateVitrineListingJob
{
    private Database $db;
    private LoggerInterface $logger;
    private VitrineListing $listing;
    private VitrineRating $rating;
    private EventDispatcher $eventDispatcher;
    private ?OutboxServiceInterface $outbox;

    public function __construct(
        Database $db,
        LoggerInterface $logger,
        VitrineListing $listing,
        VitrineRating $rating,
        EventDispatcher $eventDispatcher,
        ?OutboxServiceInterface $outbox = null
    ) {
        $this->db = $db;
        $this->logger = $logger;
        $this->listing = $listing;
        $this->rating = $rating;
        $this->eventDispatcher = $eventDispatcher;
        $this->outbox = $outbox;
    }

    public function handle(int $raterId, int $listingId, int $stars, string $comment = ''): array
    {
        // اعتبارسنجی امتیاز
        if ($stars < 1 || $stars > 5) {
            return ['success' => false, 'message' => 'امتیاز باید بین ۱ تا ۵ باشد'];
        }

        // بررسی وجود لیستینگ
        $listing = $this->listing->find($listingId);
        if (!$listing || !isset($listing->id)) {
            return ['success' => false, 'message' => 'آگهی یافت نشد'];
        }

        // بررسی اینکه کاربر ردهنده، خریدار باشد
        if ((int) $listing->seller_id === $raterId) {
            return ['success' => false, 'message' => 'فروشنده نمی‌تواند به آگهی خودش امتیاز دهد'];
        }

        // بررسی اینکه قبلاً امتیاز نداده باشد
        $existingRating = $this->rating->findByUserAndListing($raterId, $listingId);
        if ($existingRating && isset($existingRating->id)) {
            return ['success' => false, 'message' => 'شما قبلاً به این آگهی امتیاز داده‌اید'];
        }

        $this->db->beginTransaction();
        try {
            // ثبت امتیاز
            $stmt = $this->db->query(
                "INSERT INTO vitrine_ratings (user_id, listing_id, seller_id, stars, comment, created_at)
                 VALUES (?, ?, ?, ?, ?, NOW())",
                [$raterId, $listingId, $listing->seller_id, $stars, $comment ?: null]
            );

            if (!$stmt) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'خطا در ثبت امتیاز'];
            }

            $ratingId = (int) $this->db->lastInsertId();

            // به‌روزرسانی میانگین امتیاز seller
            $avgStmt = $this->db->query(
                "UPDATE vitrine_listings SET avg_rating = (SELECT AVG(stars) FROM vitrine_ratings WHERE seller_id = ?) WHERE id = ?",
                [(int) $listing->seller_id, $listingId]
            );

            $this->db->commit();

            // ثبت در outbox/event
            if ($this->outbox) {
                $this->outbox->record('vitrine', $listingId, 'vitrine.listing_rated', [
                    'rating_id' => $ratingId,
                    'rater_id' => $raterId,
                    'listing_id' => $listingId,
                    'stars' => $stars,
                ]);
            } else {
                $this->eventDispatcher->dispatch('vitrine.listing_rated', [
                    'rating_id' => $ratingId,
                    'rater_id' => $raterId,
                    'listing_id' => $listingId,
                    'stars' => $stars,
                ]);
            }

            $this->logger->info('vitrine.listing_rated', [
                'rating_id' => $ratingId,
                'rater_id' => $raterId,
                'listing_id' => $listingId,
                'stars' => $stars,
            ]);

            return [
                'success' => true,
                'rating_id' => $ratingId,
                'message' => 'امتیاز با موفقیت ثبت شد',
            ];
        } catch (\Throwable $e) {
            $this->db->rollback();
            $this->logger->error('vitrine.rating_failed', [
                'listing_id' => $listingId,
                'rater_id' => $raterId,
                'error' => $e->getMessage()
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی: ' . $e->getMessage()];
        }
    }
}
