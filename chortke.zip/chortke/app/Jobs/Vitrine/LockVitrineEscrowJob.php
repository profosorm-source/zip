<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Services\VitrineService;

class LockVitrineEscrowJob
{
    public function __construct(
        private VitrineService $vitrineService
    ) {}

    /** @return array<string, mixed> */
public function handle(int $buyerId, int $listingId): array
    {
        try {
            return $this->vitrineService->lockEscrow($buyerId, $listingId);
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
