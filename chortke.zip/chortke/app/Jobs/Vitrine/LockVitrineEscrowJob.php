<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Services\VitrineService;

class LockVitrineEscrowJob
{
    public function __construct(
        private VitrineService $vitrineService
    ) {}

    public function handle(int $buyerId, int $listingId): array
    {
        try {
            return $this->vitrineService->lockEscrow($buyerId, $listingId);
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
