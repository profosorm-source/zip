<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Models\VitrineListing;
use App\Contracts\OutboxServiceInterface;
use Core\EventDispatcher;
use App\Contracts\LoggerInterface;

/**
 * AdminApproveVitrineListingJob
 *
 * تأیید آگهی ویترین توسط ادمین
 * وضعیت: pending → active
 */
class AdminApproveVitrineListingJob
{
    private VitrineListing $listing;
    private EventDispatcher $eventDispatcher;
    private LoggerInterface $logger;
    private ?OutboxServiceInterface $outbox;

    public function __construct(
        VitrineListing $listing,
        EventDispatcher $eventDispatcher,
        LoggerInterface $logger,
        ?OutboxServiceInterface $outbox = null
    ) {
        $this->eventDispatcher = $eventDispatcher;
        $this->listing = $listing;
        $this->logger = $logger;
        $this->outbox = $outbox;
    }

    /** @return array<string, mixed> */
public function handle(int $listingId, int $adminId): array
    {
        $listing = $this->listing->find($listingId);
        if (!$listing) {
            return ['success' => false, 'message' => 'آگهی یافت نشد.'];
        }

        if ($listing->status !== VitrineListing::STATUS_PENDING) {
            return ['success' => false, 'message' => 'این آگهی در وضعیت قابل تایید نیست.'];
        }

        try {
            // 🔒 AUDIT-FIX (financial audit R10-P2 — CAS): گذار با expectedStatus انجام
            // می‌شود؛ قبلاً دو درخواست هم‌زمان هر دو pre-check را رد می‌کردند و هر دو
            // event موفق منتشر می‌کردند (last-writer-wins) — status نهایی می‌توانست با
            // تصمیم ثبت‌شده در event/audit متفاوت باشد.
            if (!$this->listing->updateStatus($listingId, VitrineListing::STATUS_ACTIVE, [], VitrineListing::STATUS_PENDING)) {
                return ['success' => false, 'message' => 'این آگهی هم‌اکنون توسط فرایند دیگری تغییر کرده است (تداخل وضعیت).'];
            }

            if ($this->outbox) {
                $this->outbox->record('vitrine', $listingId, 'vitrine.listing_approved', [
                    'listing_id' => $listingId,
                    'seller_id'  => (int)$listing->seller_id,
                    'admin_id'   => $adminId,
                ]);
            } else {
                $this->eventDispatcher->dispatch('vitrine.listing_approved', [
                    'listing_id' => $listingId,
                    'seller_id'  => (int)$listing->seller_id,
                    'admin_id'   => $adminId,
                ]);
            }

            $this->logger->info('vitrine.admin_approved', [
                'listing_id' => $listingId,
                'admin_id'   => $adminId,
            ]);

            return ['success' => true, 'message' => 'آگهی با موفقیت تایید شد.'];
        } catch (\Throwable $e) {
            $this->logger->error('vitrine.admin_approve_failed', [
                'listing_id' => $listingId,
                'error'      => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در تایید آگهی: ' . $e->getMessage()];
        }
    }
}
