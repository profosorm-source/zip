<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Contracts\LoggerInterface;
use App\Contracts\OutboxServiceInterface;
use App\Services\EscrowService;
use Core\Database;
use Core\EventDispatcher;

/**
 * ProcessExpiredVitrineEscrowsJob
 *
 * پردازش اسکروهای منقضی شده ویترین - وجه را به خریدار برمی‌گرداند
 * و وضعیت اسکرو را به refunded تغییر می‌دهد.
 */
class ProcessExpiredVitrineEscrowsJob
{
    /**
     * FIX-R18-M9: بدترین زمان اجرای موردانتظار (تسویهٔ اسکروهای منقضی ویترین).
     * QueueWorker از این مقدار برای گسترش visibility (timeoutSeconds*2) استفاده می‌کند.
     */
    public int $timeoutSeconds = 900;

    private Database $db;
    private LoggerInterface $logger;
    private EventDispatcher $eventDispatcher;
    private ?OutboxServiceInterface $outbox;
    private ?\App\Domain\Financial\Services\FinancialEscrowService $financialEscrowService;

    public function __construct(
        Database $db,
        LoggerInterface $logger,
        EventDispatcher $eventDispatcher,
        ?OutboxServiceInterface $outbox = null,
        ?\App\Domain\Financial\Services\FinancialEscrowService $financialEscrowService = null
    ) {
        $this->eventDispatcher = $eventDispatcher;
        $this->db = $db;
        $this->logger = $logger;
        $this->outbox = $outbox;
        // 🧹 DI-CLEANUP (2026-08-24): FinancialEscrowService با تزریق سازنده
        // (autowire بدون چرخه) به‌جای Service Locator.
        $this->financialEscrowService = $financialEscrowService;
    }

    /** @return array<string, mixed> */
public function handle(): array
    {
        $processed = 0;
        $failed = 0;

        try {
            // یافتن اسکروهای منقضی شده ویترین — 🛡️ FIX-CH07: ردیف‌های
            // refund_pending (claim شده اما refund ناتمام — مثلاً crash بین claim و
            // refund مالی) هم دوباره مصرف می‌شوند تا وجه هرگز stranded نماند.
            $stmt = $this->db->query(
                "SELECT e.*, l.expires_at 
                 FROM escrow_transactions e
                 JOIN vitrine_listings l ON l.id = e.order_id
                 WHERE e.order_type = 'vitrine_listing'
                   AND e.status = 'in_escrow'
                   AND (l.status = 'refund_pending'
                        OR (l.expires_at < NOW() AND l.expires_at IS NOT NULL
                            AND l.status IN ('in_escrow','disputed')))
                 ORDER BY l.expires_at ASC
                 LIMIT 50"
            );

            $expiredEscrows = $stmt->fetchAll(\PDO::FETCH_OBJ);

            foreach ($expiredEscrows as $escrow) {
                try {
                    // 🛡️ FIX-CH07 — claim durable با state میانی refund_pending:
                    // قبلاً claim مستقیم به terminal (refunded) خارج از مرز تراکنشِ
                    // refund انجام می‌شد؛ crash بین claim و refund ⇒ listing refunded
                    // ولی وجه هنوز قفل، و نه retry بعدی (فیلتر status) نه refund
                    // ادمین (guard terminal) می‌توانست آن را نجات دهد.
                    // اکنون: claim فقط وضعیت میانی refund_pending می‌سازد؛ در
                    // موفقیت به refunded و در شکست/crash در refund_pending می‌ماند
                    // تا اجرای بعدی (کوئری بالا) دقیقاً همان را دوباره مصرف کند؛
                    // refundEscrowToBuyer با کلید idempotency پایدار خودش دقیقاً
                    // یک‌بار اثر مالی دارد.
                    $claimed = $this->db->execute(
                        "UPDATE vitrine_listings SET status = 'refund_pending', updated_at = NOW()
                          WHERE id = ? AND status IN ('in_escrow', 'disputed', 'refund_pending')",
                        [(int)$escrow->order_id]
                    );
                    if ($claimed !== 1) {
                        // رقابت با refund ادمین/تسویهٔ دیگر — این اجرا از دسترسی می‌بازد
                        $this->logger->warning('vitrine.escrow_expiry_listing_claim_skipped', [
                            'escrow_id' => $escrow->id,
                            'order_id' => $escrow->order_id,
                        ]);
                        continue;
                    }

                    // 🧹 DI-CLEANUP: تزریق سازنده به‌جای Service Locator؛ غیبت = fail-closed
                    $financialEscrow = $this->financialEscrowService ?? throw new \RuntimeException('FinancialEscrowService در دسترس نیست؛ استرداد وجه ویترین متوقف شد.');
                    $result = $financialEscrow->refundEscrowToBuyer(
                        (int) $escrow->id,
                        (int) $escrow->buyer_id,
                        'انقضای آگهی ویترین و استرداد وجه',
                        'system_cron',
                        'vitrine_expiry_refund:' . (int)$escrow->id
                    );

                    if (!($result['ok'] ?? false)) {
                        // 🛡️ FIX-CH07: در شکستِ نرم، claim در refund_pending می‌ماند
                        // (نه بازگشت به in_escrow) — escrow هنوز in_escrow است و
                        // اجرای بعدی با همان کلید idempotency retry می‌کند.
                        throw new \RuntimeException(is_string($result['error'] ?? null) ? $result['error'] : 'استرداد اسکروی منقضی ناموفق بود');
                    }

                    // 🛡️ FIX-CH07: refund موفق ⇒ حالا terminal می‌شویم
                    $this->db->execute(
                        "UPDATE vitrine_listings SET status = 'refunded', updated_at = NOW()
                          WHERE id = ? AND status = 'refund_pending'",
                        [(int)$escrow->order_id]
                    );

                    $processed++;

                    if ($this->outbox) {
                        $this->outbox->record('vitrine', (int) $escrow->order_id, 'vitrine.escrow_expired', [
                            'escrow_id' => $escrow->id,
                            'buyer_id' => $escrow->buyer_id,
                            'amount' => $escrow->amount,
                        ]);
                    } else {
                        $this->eventDispatcher->dispatch('vitrine.escrow_expired', [
                            'escrow_id' => $escrow->id,
                            'buyer_id' => $escrow->buyer_id,
                            'amount' => $escrow->amount,
                        ]);
                    }
                } catch (\Throwable $e) {
                    $failed++;
                    $this->logger->error('vitrine.escrow_expiry_failed', [
                        'escrow_id' => $escrow->id,
                        'error' => $e->getMessage()
                    ]);
                }
            }

            $this->logger->info('vitrine.expired_escrows_processed', [
                'processed' => $processed,
                'failed' => $failed,
            ]);

            return [
                'success' => true,
                'processed' => $processed,
                'failed' => $failed,
            ];
        } catch (\Throwable $e) {
            $this->logger->error('vitrine.expired_escrows_job_failed', [
                'error' => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی: ' . $e->getMessage()];
        }
    }
}
