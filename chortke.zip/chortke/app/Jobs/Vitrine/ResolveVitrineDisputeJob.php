<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Models\VitrineListing;
use App\Services\VitrineService;
use Core\Database;
use Core\EventDispatcher;
use App\Contracts\LoggerInterface;

class ResolveVitrineDisputeJob
{
    private Database $db;
    private LoggerInterface $logger;
    private VitrineListing $listing;
    private VitrineService $vitrineService;
    private EventDispatcher $eventDispatcher;

    public function __construct(
        Database $db,
        LoggerInterface $logger,
        VitrineListing $listing,
        VitrineService $vitrineService,
        EventDispatcher $eventDispatcher
    ) {
        $this->db = $db;
        $this->logger = $logger;
        $this->listing = $listing;
        $this->vitrineService = $vitrineService;
        $this->eventDispatcher = $eventDispatcher;
    }

    public function handle(int $listingId, string $winner, int $adminId): array
    {
        $listing = $this->listing->find($listingId);
        if (!$listing) return ['success' => false, 'message' => 'آگهی یافت نشد.'];

        if ($winner === 'seller') {
            $result = $this->vitrineService->releaseFundsToSeller($listing, 'admin_resolve');
        } else {
            $amount = $listing->offer_price_usdt ?? $listing->price_usdt;
            $this->db->beginTransaction();
            try {
                $saga = \Core\Container::getInstance()->make(\App\Services\SagaOrchestrator::class);
                $saga->setSaga('vitrine_resolve_dispute', ['listing_id' => $listingId]);

                $saga->addStep(
                    'refund_buyer',
                    function () use ($listing, $amount, $listingId) {
                        $escrowService = app(\App\Services\EscrowService::class);
                        $escrow = $escrowService->getByOrder((string)$listingId, 'vitrine_purchase');
                        if ($escrow) {
                            $escrowService->refundFunds((int)$escrow->id, (int)$listing->buyer_id, 'حل اختلاف به نفع خریدار', 'admin', "vt_ref_disp_" . ($escrow->id ?? 0) . "_" . time());
                        }

                        $this->eventDispatcher->dispatch('vitrine.refund_requested', [
                            'buyer_id' => (int)$listing->buyer_id,
                            'amount' => $amount,
                            'listing_id' => $listingId
                        ]);
                        return true;
                    },
                    function (\Throwable $e) use ($listingId) {
                        $this->logger->warning('saga.compensating.vitrine_refund_buyer', ['listing_id' => $listingId]);
                    }
                )->addStep(
                    'cancel_listing',
                    function () use ($listingId) {
                        $this->listing->updateStatus($listingId, 'cancelled');
                        return true;
                    },
                    function () {}
                );

                $saga->execute();
                $this->db->commit();
            } catch (\Throwable $e) {
                $this->db->rollBack();
                return ['success' => false, 'message' => 'خطای سیستمی.'];
            }

            $result = ['success' => true];
        }

        $this->eventDispatcher->dispatch('vitrine.dispute_resolved', [
            'admin_id' => $adminId,
            'listing_id' => $listingId,
            'decision' => $winner
        ]);

        $this->logger->info('vitrine.dispute_resolved', [
            'listing_id' => $listingId,
            'winner'     => $winner,
            'admin_id'   => $adminId,
        ]);

        return $result;
    }
}
