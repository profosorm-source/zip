<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Models\VitrineListing;
use App\Models\VitrineRequest;
use App\Contracts\OutboxServiceInterface;
use Core\EventDispatcher;
use App\Contracts\LoggerInterface;

/**
 * AcceptVitrineRequestJob
 *
 * پذیرش درخواست خرید توسط فروشنده
 * درخواست: pending → accepted
 * آگهی: active → in_escrow
 * خریدار = requester
 */
class AcceptVitrineRequestJob
{
    private VitrineListing $listing;
    private VitrineRequest $request;
    private EventDispatcher $eventDispatcher;
    private LoggerInterface $logger;
    private ?OutboxServiceInterface $outbox;

    public function __construct(
        VitrineListing $listing,
        VitrineRequest $request,
        EventDispatcher $eventDispatcher,
        LoggerInterface $logger,
        ?OutboxServiceInterface $outbox = null
    ) {
        $this->listing = $listing;
        $this->request = $request;
        $this->eventDispatcher = $eventDispatcher;
        $this->logger = $logger;
        $this->outbox = $outbox;
    }

    public function handle(int $sellerId, int $requestId): array
    {
        $req = $this->request->findById($requestId);
        if (!$req) {
            return ['success' => false, 'message' => 'درخواست یافت نشد.'];
        }

        if ((int) $req->seller_id !== $sellerId) {
            return ['success' => false, 'message' => 'دسترسی غیرمجاز. فقط فروشنده می‌تواند درخواست را بپذیرد.'];
        }

        if ($req->status !== VitrineRequest::STATUS_PENDING) {
            return ['success' => false, 'message' => 'این درخواست قبلاً پردازش شده است.'];
        }

        $listing = $this->listing->find((int) $req->listing_id);
        if (!$listing || $listing->status !== VitrineListing::STATUS_ACTIVE) {
            return ['success' => false, 'message' => 'آگهی در وضعیت قابل پذیرش نیست.'];
        }

        try {
            // Accept request
            $this->request->updateStatus($requestId, VitrineRequest::STATUS_ACCEPTED);

            // Move listing to in_escrow with buyer set
            $this->listing->update($req->listing_id, [
                'status'           => VitrineListing::STATUS_IN_ESCROW,
                'buyer_id'         => (int) $req->requester_id,
                'offer_price_usdt' => $req->offer_price,
            ]);

            // Reject all other pending requests for this listing
            $this->request->rejectOtherPending($requestId, (int) $req->listing_id);

            // ✅ Outbox: تضمین delivery حتی در صورت خرابی
            if ($this->outbox) {
                $this->outbox->record('vitrine', (int)$req->listing_id, 'vitrine.request_accepted', [
                    'listing_id'   => (int)$req->listing_id,
                    'request_id'   => $requestId,
                    'seller_id'    => $sellerId,
                    'requester_id' => (int)$req->requester_id,
                    'offer_price'  => $req->offer_price,
                ]);
            } else {
                $this->eventDispatcher->dispatch('vitrine.request_accepted', [
                    'listing_id'   => (int)$req->listing_id,
                    'request_id'   => $requestId,
                    'seller_id'    => $sellerId,
                    'requester_id' => (int)$req->requester_id,
                    'offer_price'  => $req->offer_price,
                ]);
            }

            $this->logger->info('vitrine.request_accepted', [
                'listing_id'   => (int) $req->listing_id,
                'request_id'   => $requestId,
                'seller_id'    => $sellerId,
                'requester_id' => (int) $req->requester_id,
            ]);

            return ['success' => true, 'message' => 'درخواست پذیرفته شد. آگهی وارد مرحله انتقال شد.'];
        } catch (\Throwable $e) {
            $this->logger->error('vitrine.accept_request_failed', [
                'request_id' => $requestId,
                'error'      => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در پذیرش درخواست: ' . $e->getMessage()];
        }
    }
}
