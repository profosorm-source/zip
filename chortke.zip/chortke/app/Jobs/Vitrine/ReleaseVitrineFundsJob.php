<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Models\VitrineListing;
use App\Services\Settings\AppSettings;
use App\Services\ScoreService;
use Core\Database;
use Core\EventDispatcher;
use App\Contracts\LoggerInterface;

class ReleaseVitrineFundsJob
{
    private Database $db;
    private LoggerInterface $logger;
    private ScoreService $scoreService;
    private AppSettings $settings;
    private EventDispatcher $eventDispatcher;
    private VitrineListing $listing;
    private \App\Services\SagaOrchestrator $sagaOrchestrator;

    public function __construct(
        Database $db,
        LoggerInterface $logger,
        ScoreService $scoreService,
        AppSettings $settings,
        EventDispatcher $eventDispatcher,
        VitrineListing $listing,
        \App\Services\SagaOrchestrator $sagaOrchestrator
    ) {
        $this->db = $db;
        $this->logger = $logger;
        $this->scoreService = $scoreService;
        $this->settings = $settings;
        $this->eventDispatcher = $eventDispatcher;
        $this->listing = $listing;
        $this->sagaOrchestrator = $sagaOrchestrator;
    }

    public function handle(object $listing, string $reason = 'manual'): array
    {
        // PRECISION FIX: محاسبه کمیسیون ویترین با Money/bcmath
        $commissionPercent = (string)$this->settings->get('vitrine_commission_percent', '5');
        $amount     = (string)($listing->offer_price_usdt ?? $listing->price_usdt ?? '0');
        $priceMoney = \Core\ValueObjects\Money::of($amount, 'USDT');
        $feeMoney   = $priceMoney->percentage($commissionPercent);
        $net        = $priceMoney->subtract($feeMoney)->getAmount();

        $this->db->beginTransaction();
        try {
            $saga = $this->sagaOrchestrator;
            $saga->setSaga('vitrine_release_funds', ['listing_id' => $listing->id]);

            $saga->addStep(
                'pay_seller',
                function () use ($listing, $net) {
                    $walletService = app(\App\Contracts\WalletServiceInterface::class);
                    $credit = $walletService->deposit((int)$listing->seller_id, $net, $listing->currency ?? 'usdt', [
                        'type' => 'vitrine_payout',
                        'description' => "درآمد فروش آگهی ویترین #" . ($listing->id ?? 0),
                        'idempotency_key' => "vitrine_payout_" . ($listing->id ?? 0) . "_" . time(),
                    ]);
                    if (empty($credit['success'])) throw new \Core\Exceptions\ApplicationException($credit['message'] ?? 'خطا در واریز وجه');

                    $escrowService = app(\App\Services\EscrowService::class);
                    $escrow = $escrowService->getByOrder((string)$listing->id, 'vitrine_purchase');
                    if ($escrow) {
                        $escrowService->releaseFunds((int)$escrow->id, (int)$listing->seller_id, 'buyer_confirm');
                    }

                    $this->eventDispatcher->dispatch('vitrine.release_funds_requested', [
                        'seller_id' => (int)$listing->seller_id,
                        'amount' => $net,
                        'listing_id' => (int)$listing->id
                    ]);
                    return true;
                },
                function (\Throwable $e) use ($listing) {
                    $this->logger->warning('saga.compensating.vitrine_release_seller', ['listing_id' => $listing->id]);
                }
            )->addStep(
                'update_listing_status',
                function () use ($listing, $reason) {
                    $extra = ['auto_confirmed' => ($reason === 'auto_cron') ? 1 : 0];
                    $ok    = $this->listing->updateStatus((int) $listing->id, 'sold', $extra);
                    if (!$ok) {
                        throw new \Core\Exceptions\ApplicationException('خطا در بروزرسانی وضعیت.');
                    }
                    return true;
                },
                function () {}
            );

            $saga->execute();
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            $this->logger->error('vitrine.escrow.release_failed', ['id' => $listing->id, 'err' => $e->getMessage()]);
            return ['success' => false, 'message' => 'خطای سیستمی.'];
        }

        $this->eventDispatcher->dispatch('vitrine.escrow.released', [
            'seller_id' => (int)$listing->seller_id,
            'listing_id' => $listing->id
        ]);
        
        if (isset($this->scoreService)) {
            // Reward seller for successful trade
            $this->scoreService->applyDelta('user', (int)$listing->seller_id, 'vitrine_rating', 5.0, 'vitrine_sale_success_'.$listing->id);
        }

        return ['success' => true, 'net_amount' => $net];
    }
}
