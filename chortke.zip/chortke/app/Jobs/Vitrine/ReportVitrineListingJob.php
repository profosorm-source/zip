<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Contracts\LoggerInterface;
use App\Contracts\OutboxServiceInterface;
use App\Models\VitrineListing;
use Core\Database;

/**
 * ReportVitrineListingJob
 *
 * ثبت گزارش تخلف برای لیستینگ ویترین.
 * کاربران می‌توانند لیستینگ‌های متخلف را گزارش دهند
 * و این گزارش به پنل مدیران ارسال می‌شود.
 */
class ReportVitrineListingJob
{
    private Database $db;
    private LoggerInterface $logger;
    private VitrineListing $listing;
    private ?OutboxServiceInterface $outbox;

    public function __construct(
        Database $db,
        LoggerInterface $logger,
        VitrineListing $listing,
        ?OutboxServiceInterface $outbox = null
    ) {
        $this->db = $db;
        $this->logger = $logger;
        $this->listing = $listing;
        $this->outbox = $outbox;
    }

    /** @return array<string, mixed> */
public function handle(int $reporterId, int $listingId, string $reason, string $description = ''): array
    {
        // اعتبارسنجی دلیل
        $validReasons = [
            'spam',
            'fraud',
            'inappropriate_content',
            'copyright_violation',
            'fake_listing',
            'price_manipulation',
            'other'
        ];

        if (!in_array($reason, $validReasons, true)) {
            return ['success' => false, 'message' => 'دلیل گزارش نامعتبر است'];
        }

        // بررسی وجود لیستینگ
        $listing = $this->listing->find($listingId);
        if (!$listing || !isset($listing->id)) {
            return ['success' => false, 'message' => 'آگهی یافت نشد'];
        }

        // بررسی اینکه گزارش‌دهنده فروشنده نباشد
        if ((int) $listing->seller_id === $reporterId) {
            return ['success' => false, 'message' => 'شما نمی‌توانید آگهی خودتان را گزارش کنید'];
        }

        // بررسی اینکه قبلاً گزارش نداده باشد
        $stmt = $this->db->query(
            "SELECT id FROM vitrine_reports 
             WHERE reporter_id = ? AND listing_id = ? AND status = 'pending'
             LIMIT 1",
            [$reporterId, $listingId]
        );

        $existingReportRow = $stmt->fetch(\PDO::FETCH_OBJ);
        $existingReport = $existingReportRow instanceof \stdClass ? $existingReportRow : null;
        if ($existingReport !== null && isset($existingReport->id)) {
            return ['success' => false, 'message' => 'شما قبلاً این آگهی را گزارش کرده‌اید و در انتظار بررسی است'];
        }

        $this->db->beginTransaction();
        try {
            // L-گاپ Fix (TOCTOU): درج اتمیک با شرط عدم وجود گزارش pending تکراری.
            // چون MySQL از unique جزئی روی status='pending' پشتیبانی نمی‌کند، شرط داخل خودِ INSERT اعمال می‌شود.
            $stmt = $this->db->query(
                "INSERT INTO vitrine_reports (reporter_id, listing_id, seller_id, reason, description, status, created_at)
                 SELECT ?, ?, ?, ?, ?, 'pending', NOW()
                 FROM DUAL
                 WHERE NOT EXISTS (
                     SELECT 1 FROM vitrine_reports
                     WHERE reporter_id = ? AND listing_id = ? AND status = 'pending'
                 )",
                [$reporterId, $listingId, $listing->seller_id, $reason, $description ?: null, $reporterId, $listingId]
            );

            if ($stmt->rowCount() < 1) {
                // شرط رقابتی: گزارش pending تکراری هم‌زمان ثبت شده است.
                $this->db->rollback();
                return ['success' => false, 'message' => 'شما قبلاً این آگهی را گزارش کرده‌اید و در انتظار بررسی است'];
            }

            $reportId = (int) $this->db->lastInsertId();

            $this->db->commit();

            // 🛡️ FIX-DEAD-EVENT-ADMIN-VISIBILITY (P1 — pre-existing):
            // رویداد vitrine.listing_reported هیچ listener ای ندارد و جدول vitrine_reports
            // هم هیچ خواننده‌ای در پروژه ندارد → گزارش کاربر عملاً دیده نمی‌شد، در حالی که
            // به او «بررسی خواهد شد» قول داده می‌شود. اصلاح ریشه‌ای با الگوی استاندارد
            // هشدار ادمین (همان مسیر sendToAdmins که ReconciliationService برای برداشت‌های
            // گیرکرده استفاده می‌کند): نوتیفیکیشن in-app برای همهٔ ادمین‌ها ثبت می‌شود.
            $listingTitle = str_value($listing->title ?? '');
            $reportTitle = 'گزارش تخلف آگهی ویترین #' . $listingId;
            $reportMessage = sprintf(
                'آگهی «%s» (کد %d) توسط کاربر #%d گزارش شد.%s دلیل: %s',
                $listingTitle !== '' ? $listingTitle : 'بدون عنوان',
                $listingId,
                $reporterId,
                $description !== null && $description !== '' ? ' توضیحات: ' . mb_substr($description, 0, 300) . '.' : '',
                $reason
            );
            try {
                if ($this->outbox) {
                    $this->outbox->record('vitrine_report', (string)$reportId, 'notification.listing_reported', [
                        'notification' => [
                            'method' => 'sendToAdmins',
                            'args'   => [
                                'vitrine_listing_reported',
                                $reportTitle,
                                $reportMessage,
                                [
                                    'report_id'   => $reportId,
                                    'reporter_id' => $reporterId,
                                    'listing_id'  => $listingId,
                                    'seller_id'   => (int)$listing->seller_id,
                                    'reason'      => $reason,
                                    'action_url'  => '/admin/vitrine?search=' . urlencode($listingTitle),
                                    'action_text' => 'مشاهدهٔ آگهی',
                                ],
                                'high',
                            ],
                        ],
                    ]);
                } else {
                    // بدون outbox، حداقل اعلان sync برای ادمین‌ها ارسال می‌شود
                    // (همان قرارداد sendToAdmins؛ الگوی ReconciliationService).
                    try {
                        $notificationService = \Core\Container::getInstance()
                            ->make(\App\Contracts\NotificationServiceInterface::class);
                        $notificationService->sendToAdmins(
                            'vitrine_listing_reported',
                            $reportTitle,
                            $reportMessage,
                            [
                                'report_id'   => $reportId,
                                'reporter_id' => $reporterId,
                                'listing_id'  => $listingId,
                                'reason'      => $reason,
                            ],
                            'high'
                        );
                    } catch (\Throwable $e) {
                        $this->logger->warning('vitrine.report_admin_alert_sync_failed', [
                            'report_id' => $reportId,
                            'error' => $e->getMessage(),
                        ]);
                    }
                }
            } catch (\Throwable $e) {
                // ثبت گزارش در DB انجام شده؛ هشدار ادمین نباید جریان گزارش‌دهی را بشکند.
                $this->logger->warning('vitrine.report_admin_alert_failed', [
                    'report_id' => $reportId,
                    'error' => $e->getMessage(),
                ]);
            }

            $this->logger->info('vitrine.listing_reported', [
                'report_id' => $reportId,
                'reporter_id' => $reporterId,
                'listing_id' => $listingId,
                'reason' => $reason,
            ]);

            return [
                'success' => true,
                'report_id' => $reportId,
                'message' => 'گزارش شما با موفقیت ثبت شد و در اسرع وقت بررسی خواهد شد',
            ];
        } catch (\Throwable $e) {
            $this->db->rollback();
            $this->logger->error('vitrine.report_failed', [
                'listing_id' => $listingId,
                'reporter_id' => $reporterId,
                'error' => $e->getMessage()
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی: ' . $e->getMessage()];
        }
    }
}
