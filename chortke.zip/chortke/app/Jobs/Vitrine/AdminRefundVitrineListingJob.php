<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Models\VitrineListing;
use App\Contracts\WalletServiceInterface;
use Core\EventDispatcher;
use App\Contracts\LoggerInterface;

/**
 * AdminRefundVitrineListingJob
 *
 * بازپرداخت آگهی ویترین توسط ادمین
 * وضعیت: in_escrow/disputed → cancelled
 * وجه به خریدار برگشت داده می‌شود
 */
class AdminRefundVitrineListingJob
{
    private VitrineListing $listing;
    private WalletServiceInterface $wallet;
    private EventDispatcher $eventDispatcher;
    private LoggerInterface $logger;

    public function __construct(
        VitrineListing $listing,
        WalletServiceInterface $wallet,
        EventDispatcher $eventDispatcher,
        LoggerInterface $logger
    ) {
        $this->listing = $listing;
        $this->wallet = $wallet;
        $this->eventDispatcher = $eventDispatcher;
        $this->logger = $logger;
    }

    public function handle(int $listingId, int $adminId): array
    {
        $listing = $this->listing->find($listingId);
        if (!$listing) {
            return ['success' => false, 'message' => 'آگهی یافت نشد.'];
        }

        $refundableStatuses = [
            VitrineListing::STATUS_IN_ESCROW,
            VitrineListing::STATUS_DISPUTED,
        ];

        if (!in_array($listing->status, $refundableStatuses, true)) {
            return ['success' => false, 'message' => 'این آگهی در وضعیت قابل بازپرداخت نیست.'];
        }

        try {
            // Refund buyer if one exists
            $buyerId = (int) ($listing->buyer_id ?? 0);
            $amount  = (string) ($listing->offer_price_usdt ?? $listing->price_usdt ?? '0');
            $currency = $listing->currency ?? 'usdt';

            if ($buyerId > 0 && $amount !== '0') {
                $this->wallet->deposit($buyerId, $amount, $currency, [
                    'type'        => 'vitrine_admin_refund',
                    'description' => "بازپرداخت آگهی #{$listingId} توسط ادمین",
                    'listing_id'  => $listingId,
                ]);
            }

            $this->listing->updateStatus($listingId, VitrineListing::STATUS_CANCELLED);

            $this->eventDispatcher->dispatch('vitrine.admin_refunded', [
                'listing_id' => $listingId,
                'buyer_id'   => $buyerId,
                'amount'     => $amount,
            ]);

            $this->logger->info('vitrine.admin_refunded', [
                'listing_id' => $listingId,
                'admin_id'   => $adminId,
                'buyer_id'   => $buyerId,
                'amount'     => $amount,
            ]);

            return ['success' => true, 'message' => 'بازپرداخت با موفقیت انجام شد.'];
        } catch (\Throwable $e) {
            $this->logger->error('vitrine.admin_refund_failed', [
                'listing_id' => $listingId,
                'error'      => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در بازپرداخت: ' . $e->getMessage()];
        }
    }
}
