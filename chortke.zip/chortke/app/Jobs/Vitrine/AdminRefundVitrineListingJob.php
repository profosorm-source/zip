<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Models\VitrineListing;
use App\Contracts\WalletServiceInterface;
use App\Contracts\OutboxServiceInterface;
use Core\EventDispatcher;
use App\Contracts\LoggerInterface;

/**
 * AdminRefundVitrineListingJob
 *
 * بازپرداخت آگهی ویترین توسط ادمین
 * وضعیت: in_escrow/disputed → cancelled
 * وجه به خریدار برگشت داده می‌شود
 */
class AdminRefundVitrineListingJob
{
    private VitrineListing $listing;
    private WalletServiceInterface $wallet;
    private EventDispatcher $eventDispatcher;
    private LoggerInterface $logger;
    private ?OutboxServiceInterface $outbox;
    private ?\App\Services\EscrowService $escrowService;

    public function __construct(
        VitrineListing $listing,
        WalletServiceInterface $wallet,
        EventDispatcher $eventDispatcher,
        LoggerInterface $logger,
        ?OutboxServiceInterface $outbox = null,
        ?\App\Services\EscrowService $escrowService = null
    ) {
        $this->listing = $listing;
        $this->wallet = $wallet;
        $this->eventDispatcher = $eventDispatcher;
        $this->logger = $logger;
        $this->outbox = $outbox;
        $this->escrowService = $escrowService;
    }

    public function handle(int $listingId, int $adminId): array
    {
        $listing = $this->listing->find($listingId);
        if (!$listing) {
            return ['success' => false, 'message' => 'آگهی یافت نشد.'];
        }

        $refundableStatuses = [
            VitrineListing::STATUS_IN_ESCROW,
            VitrineListing::STATUS_DISPUTED,
        ];

        if (!in_array($listing->status, $refundableStatuses, true)) {
            return ['success' => false, 'message' => 'این آگهی در وضعیت قابل بازپرداخت نیست.'];
        }

        try {
            // Refund buyer if one exists
            $buyerId = (int) ($listing->buyer_id ?? 0);
            $amount  = (string) ($listing->offer_price_usdt ?? $listing->price_usdt ?? '0');
            $currency = $listing->currency ?? 'usdt';

            if ($buyerId > 0 && $amount !== '0') {
                $this->wallet->deposit($buyerId, $amount, $currency, [
                    'type'        => 'vitrine_admin_refund',
                    'description' => "بازپرداخت آگهی #{$listingId} توسط ادمین",
                    'listing_id'  => $listingId,
                    'idempotency_key' => 'vitrine_admin_refund_' . $listingId,
                ]);
            }

            $db = \Core\Database::getInstance();
            $escrow = $db->fetch(
                "SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'vitrine_purchase' ORDER BY id DESC LIMIT 1",
                [(string)$listingId]
            );
            if ($escrow && in_array((string)($escrow->status ?? ''), ['pending', 'in_escrow', 'disputed'], true)) {
                $db->query(
                    "UPDATE escrow_transactions SET status = 'refunded', refunded_at = NOW(), refund_reason = ?, refunded_by = ?, updated_at = NOW() WHERE id = ? AND status IN ('pending','in_escrow','disputed')",
                    ['بازپرداخت ادمین ویترین', 'admin', (int)$escrow->id]
                );
                $db->query(
                    "INSERT INTO escrow_audit (escrow_id, action, amount, performed_by, note, created_at) VALUES (?, 'refunded', ?, 'admin', ?, NOW())",
                    [(int)$escrow->id, (string)$escrow->amount, 'بازپرداخت ادمین ویترین']
                );
            }

            $this->listing->updateStatus($listingId, VitrineListing::STATUS_CANCELLED);

            if ($this->outbox) {
                $this->outbox->record('vitrine', $listingId, 'vitrine.admin_refunded', [
                    'listing_id' => $listingId,
                    'buyer_id'   => $buyerId,
                    'amount'     => $amount,
                ]);
            } else {
                $this->eventDispatcher->dispatch('vitrine.admin_refunded', [
                    'listing_id' => $listingId,
                    'buyer_id'   => $buyerId,
                    'amount'     => $amount,
                ]);
            }

            $this->logger->info('vitrine.admin_refunded', [
                'listing_id' => $listingId,
                'admin_id'   => $adminId,
                'buyer_id'   => $buyerId,
                'amount'     => $amount,
            ]);

            return ['success' => true, 'message' => 'بازپرداخت با موفقیت انجام شد.'];
        } catch (\Throwable $e) {
            $this->logger->error('vitrine.admin_refund_failed', [
                'listing_id' => $listingId,
                'error'      => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در بازپرداخت: ' . $e->getMessage()];
        }
    }
}
