<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Models\VitrineListing;
use App\Contracts\WalletServiceInterface;
use App\Contracts\OutboxServiceInterface;
use Core\EventDispatcher;
use App\Contracts\LoggerInterface;

/**
 * AdminRefundVitrineListingJob
 *
 * بازپرداخت آگهی ویترین توسط ادمین
 * وضعیت: in_escrow/disputed → cancelled
 * وجه به خریدار برگشت داده می‌شود
 */
class AdminRefundVitrineListingJob
{
    private VitrineListing $listing;
    private WalletServiceInterface $wallet;
    private EventDispatcher $eventDispatcher;
    private LoggerInterface $logger;
    private ?OutboxServiceInterface $outbox;
    private ?\App\Domain\Financial\Services\FinancialEscrowService $financialEscrowService;

    public function __construct(
        VitrineListing $listing,
        WalletServiceInterface $wallet,
        EventDispatcher $eventDispatcher,
        LoggerInterface $logger,
        ?OutboxServiceInterface $outbox = null,
        ?\App\Domain\Financial\Services\FinancialEscrowService $financialEscrowService = null
    ) {
        $this->eventDispatcher = $eventDispatcher;
        $this->listing = $listing;
        $this->wallet = $wallet;
        $this->logger = $logger;
        $this->outbox = $outbox;
        $this->financialEscrowService = $financialEscrowService;
    }

    /** @return array<string, mixed> */
public function handle(int $listingId, int $adminId): array
    {
        $listing = $this->listing->find($listingId);
        if (!$listing) {
            return ['success' => false, 'message' => 'آگهی یافت نشد.'];
        }

        $refundableStatuses = [
            VitrineListing::STATUS_IN_ESCROW,
            VitrineListing::STATUS_DISPUTED,
        ];

        if (!in_array($listing->status, $refundableStatuses, true)) {
            return ['success' => false, 'message' => 'این آگهی در وضعیت قابل بازپرداخت نیست.'];
        }

        $buyerId = (int) ($listing->buyer_id ?? 0);
        $amount  = (string) ($listing->offer_price_usdt ?? $listing->price_usdt ?? '0');
        $currency = $listing->currency ?? 'usdt';

        $db = \Core\Database::getInstance();

        // 🔒 AUDIT-FIX (financial audit R10-P1 fail-closed): اگر برای این listing
        // escrowی وجود دارد که «terminal» شده (refunded/released/cancelled)، وجه آن
        // قبلاً از مسیر اسکرو به خریدار رسیده است — مسیر direct deposit هرگز نباید
        // اجرا شود (double-refund کلاسیکِ انقضای اسکرو + بازپرداخت ادمین).
        $existingEscrow = $db->fetch(
            "SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'vitrine_listing' ORDER BY id DESC LIMIT 1",
            [(string)$listingId]
        );
        if ($existingEscrow !== null
            && !in_array((string)($existingEscrow->status ?? ''), ['pending', 'in_escrow', 'partial', 'disputed'], true)) {
            $this->logger->error('vitrine.admin_refund.escrow_terminal_fail_closed', [
                'listing_id' => $listingId,
                'admin_id'   => $adminId,
                'escrow_id'  => (int)($existingEscrow->id ?? 0),
                'escrow_status' => (string)($existingEscrow->status ?? ''),
            ]);
            return ['success' => false, 'message' => 'وجه این آگهی قبلاً از مسیر اسکرو تسویه شده است؛ بازپرداخت دوباره مجاز نیست.'];
        }

        // M-01 FIX (root cause): the listing state was read, then money was moved, then the
        // status was overwritten unconditionally and outside any transaction. Two concurrent
        // admin refunds therefore both passed the status check and both credited the buyer.
        // The refund is now fenced by an atomic compare-and-swap on the listing status: only
        // the caller whose UPDATE affects exactly one row owns the refund.
        //
        // 🔒 AUDIT-FIX (financial audit R10-P3 — atomic claim+settlement): claim و
        // settlement حالا داخل یک تراکنش ریشه انجام می‌شوند. قبلاً claim در یک UPDATE
        // جداگانه به cancelled تغییر می‌داد و refund بعد از آن؛ crash/kill شدنِ worker
        // بین دو مرحله، listing را cancelled با اسکروی in_escrow رها می‌کرد و retry
        // endpoint به‌دلیل وضعیت terminal رد می‌شد → وجه برای همیشه locked می‌ماند.
        // (catch قبلی فقط استثناهای PHP را برمی‌گرداند؛ kill را پوشش نمی‌داد.)
        // اکنون هر شکست/kill → rollback اتمیک کل claim؛ وضعیت durable لیستینگ هیچ‌وقت
        // با اسکرو ناسازگار نمی‌شود.
        try {
            /** @var array<string, mixed> $result */
            $result = $db->transactional(function () use ($db, $listingId, $adminId, $buyerId, $amount, $currency) {
                $claimed = $db->execute(
                    "UPDATE vitrine_listings SET status = ?, updated_at = NOW()
                      WHERE id = ? AND status IN (?, ?)",
                    [
                        VitrineListing::STATUS_CANCELLED,
                        $listingId,
                        VitrineListing::STATUS_IN_ESCROW,
                        VitrineListing::STATUS_DISPUTED,
                    ]
                );

                if ($claimed !== 1) {
                    $this->logger->warning('vitrine.admin_refund.claim_skipped', [
                        'listing_id' => $listingId,
                        'admin_id'   => $adminId,
                    ]);
                    return ['success' => false, 'message' => 'این آگهی هم‌اکنون توسط فرایند دیگری پردازش شده است.'];
                }

                $escrow = $db->fetch(
                    "SELECT * FROM escrow_transactions WHERE order_id = ? AND order_type = 'vitrine_listing' ORDER BY id DESC LIMIT 1 FOR UPDATE",
                    [(string)$listingId]
                );
                $escrowRefundable = $escrow !== null
                    && in_array((string)($escrow->status ?? ''), ['pending', 'in_escrow', 'partial', 'disputed'], true);

                // M-01 FIX: previously the buyer was credited from the wallet AND the escrow row was
                // flipped to `refunded` — for an escrow-backed listing that released the held amount
                // twice (double refund). Exactly one settlement path runs now: the escrow service
                // when the funds are actually held in escrow, a direct deposit only when no escrow
                // row exists at all (AUDIT-FIX R10-P1: escrow terminal → fail-closed بالاتر).
                if ($escrowRefundable) {
                    // P0 FIX (S33-B1/B2 audit): the escrow-backed refund previously called the
                    // state-only EscrowService::refundFunds — it flipped escrow.status to `refunded`
                    // while the buyer's locked funds were never released and no ledger leg was
                    // written, permanently stranding the money behind a `refunded` escrow.
                    // The canonical financial API (same contract the dispute-resolve job already
                    // uses) performs the state flip AND the wallet release AND the hold
                    // finalization atomically, under an idempotency key.
                    $financialEscrow = $this->financialEscrowService ?? throw new \RuntimeException('FinancialEscrowService در دسترس نیست؛ بازپرداخت ادمین ویترین متوقف شد.');
                    $refund = $financialEscrow->refundEscrowToBuyer(
                        (int)$escrow->id,
                        $buyerId,
                        'بازپرداخت ادمین ویترین',
                        // M-tier FIX: record WHICH admin initiated the refund (audit trail).
                        'admin:' . $adminId,
                        'vitrine_admin_refund_' . $listingId
                    );
                    if (empty($refund['ok'])) {
                        throw new \RuntimeException(
                            is_string($refund['error'] ?? null) ? $refund['error'] : 'بازگشت وجه امانی ناموفق بود'
                        );
                    }
                } elseif ($buyerId > 0 && $amount !== '0' && $escrow === null) {
                    $this->wallet->deposit($buyerId, $amount, $currency, [
                        'type'        => 'vitrine_admin_refund',
                        'description' => "بازپرداخت آگهی #{$listingId} توسط ادمین",
                        'listing_id'  => $listingId,
                        'idempotency_key' => 'vitrine_admin_refund_' . $listingId,
                    ]);
                }

                if ($this->outbox) {
                    $this->outbox->record('vitrine', $listingId, 'vitrine.admin_refunded', [
                        'listing_id' => $listingId,
                        'buyer_id'   => $buyerId,
                        'amount'     => $amount,
                    ]);
                } else {
                    $this->eventDispatcher->dispatch('vitrine.admin_refunded', [
                        'listing_id' => $listingId,
                        'buyer_id'   => $buyerId,
                        'amount'     => $amount,
                    ]);
                }

                $this->logger->info('vitrine.admin_refunded', [
                    'listing_id' => $listingId,
                    'admin_id'   => $adminId,
                    'buyer_id'   => $buyerId,
                    'amount'     => $amount,
                ]);

                return ['success' => true, 'message' => 'بازپرداخت با موفقیت انجام شد.'];
            });
            return $result;
        } catch (\Throwable $e) {
            // AUDIT-FIX R10-P3: claim داخل تراکنش ریشه بود — rollback اتمیک، وضعیت
            // لیستینگ دست‌نخورده باقی می‌ماند و refund قابل retry است.
            $this->logger->error('vitrine.admin_refund_failed', [
                'listing_id' => $listingId,
                'error'      => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در بازپرداخت: ' . $e->getMessage()];
        }
    }
}
