<?php

declare(strict_types=1);

namespace App\Jobs\Vitrine;

use App\Models\VitrineListing;
use App\Contracts\OutboxServiceInterface;
use App\Services\Settings\AppSettings;
use App\Services\VitrineService;
use Core\Database;
use Core\EventDispatcher;

class CreateVitrineListingJob
{
    private VitrineListing $listing;
    private AppSettings $settings;
    private VitrineService $vitrineService;
    private EventDispatcher $eventDispatcher;
    private ?OutboxServiceInterface $outbox;
    private Database $db;

    public function __construct(
        VitrineListing $listing,
        AppSettings $settings,
        VitrineService $vitrineService,
        EventDispatcher $eventDispatcher,
        ?OutboxServiceInterface $outbox = null,
        ?Database $db = null
    ) {
        $this->eventDispatcher = $eventDispatcher;
        $this->listing = $listing;
        $this->settings = $settings;
        $this->vitrineService = $vitrineService;
        $this->outbox = $outbox;
        // 🛡️ FIX-CH24: غیبت DB = fail-closed (نگه‌داشتن سقف آگهی بدون قفل بی‌معناست)
        $this->db = $db ?? \Core\Container::getInstance()->make(Database::class);
    }

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
public function handle(int $userId, array $data): array
    {
        $check = $this->vitrineService->canTrade($userId);
        if (!$check['ok']) return ['success' => false, 'message' => $check['message']];

        // محدودیت تعداد آگهی فعال
        $maxActive = int_value($this->settings->get('vitrine_max_active_per_user', '5'));

        $minPrice = str_value($this->settings->get('vitrine_min_price_usdt', '1'));
        $maxPrice = str_value($this->settings->get('vitrine_max_price_usdt', '100000'));
        $price    = str_value($data['price_usdt'] ?? '0');

        if (!is_numeric($price) || bccomp($price, $minPrice, 8) < 0 || bccomp($price, $maxPrice, 8) > 0) {
            return ['success' => false, 'message' => "قیمت باید بین {$minPrice} و {$maxPrice} USDT باشد."];
        }

        $data['seller_id'] = $userId;

        // 🛡️ FIX-CH24: سقف آگهی فعال اکنون اتمیک است — شمارش + ایجاد در یک
        // تراکنش با قفل قطعی ردیف users؛ قبلاً check-then-insert جدا بود و دو
        // درخواست هم‌زمان با یک slot باقی‌مانده هر دو می‌ساختند.
        $result = $this->db->transactional(function () use ($userId, $maxActive, $data) {
            $this->db->query("SELECT id FROM users WHERE id = ? FOR UPDATE", [$userId])->fetch();
            $activeCount = $this->listing->countActiveByUser($userId);
            if ($activeCount >= $maxActive) {
                return ['__limit_reached' => true];
            }
            return $this->listing->createListing($data);
        });

        if (is_array($result) && ($result['__limit_reached'] ?? false)) {
            return ['success' => false, 'message' => "حداکثر {$maxActive} آگهی فعال می‌توانید داشته باشید."];
        }

        if (!$result) {
            return ['success' => false, 'message' => 'خطا در ثبت آگهی. لطفاً دوباره تلاش کنید.'];
        }

        if ($this->outbox) {
            // 🛡️ FIX-VITRINE-DEAD-EVENTS: listing_id به payload اضافه شد تا
            // VitrineNotificationListener بتواند لینک اعلان بسازد.
            $this->outbox->record('vitrine', (int)($result->id ?? 0), 'vitrine.listing_created', [
                'user_id'    => $userId,
                'listing_id' => (int)($result->id ?? 0),
                'amount'     => $price,
                'currency'   => 'usdt',
            ]);
        } else {
            $this->eventDispatcher->dispatch('vitrine.listing_created', [
                'user_id'    => $userId,
                'listing_id' => (int)($result->id ?? 0),
                'amount'     => $price,
                'currency' => 'usdt',
            ]);
        }

        return ['success' => true, 'listing' => $result];
    }
}
