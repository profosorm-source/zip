<?php

declare(strict_types=1);

namespace App\Jobs\Referral;

use App\Services\Shared\ReferralService;

class ProcessMultiTierReferralCommissionsJob
{
    public function __construct(
        private ReferralService $referralService
    ) {}

    public function handle(int $userId, string $amount, string $currency): array
    {
        try {
            return $this->referralService->processMultiTierCommissions($userId, $amount, $currency);
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
