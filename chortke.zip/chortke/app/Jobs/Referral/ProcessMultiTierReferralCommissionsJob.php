<?php

declare(strict_types=1);

namespace App\Jobs\Referral;

use App\Services\Shared\ReferralService;

class ProcessMultiTierReferralCommissionsJob
{
    public function __construct(
        private ReferralService $referralService
    ) {}

    /** @return array<string, mixed> */
public function handle(int $userId, string $amount, string $currency): array
    {
        try {
            return $this->referralService->processMultiTierCommissions($userId, $amount, $currency);
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
