<?php

declare(strict_types=1);

namespace App\Jobs\Referral;

class DistributeMonthlyReferralRewardsJob
{
    private \App\Models\ReferralCommission $commissionModel;
    private \App\Services\Settings\AppSettings $appSettings;
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;
    public function __construct(
        \App\Models\ReferralCommission $commissionModel,
        \App\Services\Settings\AppSettings $appSettings
    ,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {        $this->commissionModel = $commissionModel;
        $this->appSettings = $appSettings;
        $this->outbox = $outbox;
}

    /** @return array<string, mixed> */
public function handle(): array
    {
        $top = $this->commissionModel->getTopMonthlyReferrer();

        if ($top) {
            $bonusPercent = (float)$this->appSettings->get('referral_top_bonus_percent', 5) / 100;
            $bonus = $top->total * $bonusPercent;
            $sysCurrency = strtolower((string)$this->appSettings->get('currency_mode', 'irt'));
            $targetCurrency = in_array($sysCurrency, ['irt', 'usdt'], true) ? $sysCurrency : 'irt';
            $this->outbox?->record('referral', (int)$top->id, \App\Events\Registry\EventRegistry::REFERRAL_COMMISSION_EARNED, [
                'user_id' => (int)$top->id,
                'amount' => $bonus,
                'currency' => $targetCurrency,
                'metadata' => [
                    'type' => 'referral_bonus',
                    'description' => 'Referral leaderboard bonus'
                ]
            ]);
            return ['bonus_percent' => $bonusPercent];
        }

        return ['bonus_percent' => 0.05];
    }
}
