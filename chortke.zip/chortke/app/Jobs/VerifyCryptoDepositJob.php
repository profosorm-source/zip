<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Services\CryptoDeposit\CryptoDepositService;

/**
 * S4-C1 FIX (S33-B4 audit): this job previously called fulfillCryptoDeposit()
 * directly — it credited USDT for any row whose `status` column said 'pending'
 * with ZERO on-chain verification (free money, ~1 cron-minute delay). The cron
 * now routes through CryptoDepositService::tryAutoVerify, which performs the
 * real on-chain verification first and only then approves (credit), rejects a
 * provable mismatch, or escalates to manual review on provider errors.
 */
class VerifyCryptoDepositJob
{
    public function __construct(
        private CryptoDepositService $cryptoDepositService
    ) {}

    /** @return array<string, mixed> */
    public function handle(int $depositId): array
    {
        try {
            return $this->cryptoDepositService->tryAutoVerify($depositId);
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
