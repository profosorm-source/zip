<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Services\CryptoDeposit\CryptoDepositService;

/**
 * S4-C1 FIX (S33-B4 audit): this job previously called fulfillCryptoDeposit()
 * directly — it credited USDT for any row whose `status` column said 'pending'
 * with ZERO on-chain verification (free money, ~1 cron-minute delay). The cron
 * now routes through CryptoDepositService::tryAutoVerify, which performs the
 * real on-chain verification first and only then approves (credit), rejects a
 * provable mismatch, or escalates to manual review on provider errors.
 */
class VerifyCryptoDepositJob
{
    public function __construct(
        private CryptoDepositService $cryptoDepositService,
        // FIX-R36-W3 (F-A17-09): لاگر اختیاری (autowire container) — نریختنِ
        // شکست در catch زیر بی‌صدا بود؛ حلقهٔ کرون crypto_verify فقط
        // result['auto'] را می‌شمارد و خطا هیچ‌جا ثبت نمی‌شد.
        private ?\App\Contracts\LoggerInterface $logger = null
    ) {}

    /** @return array<string, mixed> */
    public function handle(int $depositId): array
    {
        try {
            return $this->cryptoDepositService->tryAutoVerify($depositId);
        } catch (\Throwable $e) {
            $this->logger?->warning('crypto_deposit.verify.job_failed', [
                'deposit_id' => $depositId,
                'error'      => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
