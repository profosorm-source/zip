<?php

declare(strict_types=1);

namespace App\Jobs\Notification;

use App\Models\Notification;
use App\Services\Notification\NotificationPolicyService;
use App\Contracts\LoggerInterface;
use App\Services\Notification\NotificationTracker;
use Core\Queue;
use App\Contracts\OutboxServiceInterface;
use Core\Cache;
use Core\Database;

/**
 * SendToAllNotificationJob
 *
 * ارسال اعلان همگانی به تمام کاربران فعال.
 * از همان الگوی bulk-insert + cache-invalidation + push مشابه SendToAdminsNotificationJob استفاده می‌کند.
 */
class SendToAllNotificationJob
{
    private Database $db;
    private NotificationPolicyService $policyService;
    private LoggerInterface $logger;
    private NotificationTracker $tracker;
    private Queue $queue;
    private OutboxServiceInterface $outbox;
    private Cache $cache;

    private const BATCH_SIZE = 500;

    public function __construct(
        Database $db,
        NotificationPolicyService $policyService,
        LoggerInterface $logger,
        NotificationTracker $tracker,
        Queue $queue,
        OutboxServiceInterface $outbox,
        Cache $cache
    ) {
        $this->db = $db;
        $this->policyService = $policyService;
        $this->logger = $logger;
        $this->tracker = $tracker;
        $this->queue = $queue;
        $this->outbox = $outbox;
        $this->cache = $cache;
    }

    /** @param array<string, mixed> $data */
    /** @return array<string, mixed> */
/** @param array<string, mixed> $data */
/**
 * @param array<string, mixed>|null $data
 * @return array<string, mixed>
 */
public function handle(
        string  $title,
        string  $message,
        string  $type       = 'system',
        ?string $actionUrl  = null,
        ?string $actionText = null,
        string  $priority   = 'normal',
        ?array  $data       = null,
        ?string $scheduledAt = null
    ): array {
        $type    = $this->sanitizeType($type);
        $title   = mb_substr(trim(strip_tags($title)), 0, 255);
        $message = mb_substr(trim(strip_tags($message)), 0, 1200);
        // 🛡️ FIX-S17-7: action_url مشابه SendToAdminsNotificationJob ضدعفونی می‌شود —
        // قبلاً بدون sanitizeUrl درج می‌شد (مثلاً javascript: در اعلان in-app).
        $actionUrl = $this->sanitizeUrl($actionUrl);

        // 🛡️ FIX-R18-M10: entry dedupe gate — این جاب‌ها sync و بدون idempotency اجرا
        // می‌شدند؛ دوبار کلیک ادمین = اعلان همگانی مضاعف + فن‌فروشی FCM دوبرابر.
        // Cache::add دلالت SETNX دارد: فقط نخستین فراخوان true برمی‌گرداند.
        $claimKey = 'bulk_notif_' . hash('sha256', static::class . '|' . md5((string)json_encode([
            'title' => $title, 'message' => $message, 'type' => $type,
            'action_url' => $actionUrl, 'action_text' => $actionText,
            'priority' => $priority, 'data' => $data, 'scheduled_at' => $scheduledAt,
        ], JSON_UNESCAPED_UNICODE)));
        try {
            $claimed = $this->cache->add($claimKey, 1, 600);
        } catch (\Throwable $cacheEx) {
            // Cache در دسترس نیست → fail-open (رفتار پیش از فیکس) + لاگ.
            $this->logger->warning('notif.bulk_claim_cache_failed', ['error' => $cacheEx->getMessage()]);
            $claimed = true;
        }
        if (!$claimed) {
            $this->logger->warning('notif.bulk_dedupe_skip', ['job' => static::class, 'claim_key' => $claimKey]);
            return ['sent' => 0, 'batches' => 0, 'deduped' => true];
        }

        // FIX-R18-M10: event_id در خودِ payload اعلان — هم JSON اعلان in-app و هم
        // پیلود FCM → NotificationDispatcher claim-dedupe (notif_sent:{channel}:{event_id}:{user}) فعال می‌شود.
        $data = array_merge(is_array($data) ? $data : [], ['event_id' => $claimKey]);

        $totalSent  = 0;
        $batchCount = 0;
        $lastId     = 0;

        // FIX-R36-W3 (F-A18-04): صفحه‌بندی cursor-based (id > lastId) به‌جای
        // LIMIT/OFFSET — درج/حذف کاربر حین اجرای blast دیگر باعث پرش یا تکرار
        // کاربر نمی‌شود (الگوی KycTimeoutJob).
        while (true) {
            $userIds = $this->db->fetchAll(
                "SELECT id FROM users WHERE deleted_at IS NULL AND id > ? ORDER BY id ASC LIMIT ?",
                [$lastId, self::BATCH_SIZE]
            );
            if (empty($userIds)) break;

            $ids = array_map(fn($row) => (int) (is_object($row) ? $row->id : $row['id']), $userIds);
            $sentInBatch = $this->processBatch($ids, $type, $title, $message, $data, $actionUrl, $actionText, $priority, $scheduledAt);
            $totalSent  += $sentInBatch;
            $batchCount++;
            $lastId = max($ids);
        }

        return ['sent' => $totalSent, 'batches' => $batchCount];
    }

    /**
     * 🛡️ FIX-S17-7: ضدعفونی URL — فقط http/https مطلق (هم‌سنگ نسخهٔ SendToAdmins).
     */
    private function sanitizeUrl(?string $url): ?string
    {
        if ($url === null || $url === '') {
            return null;
        }
        $url = trim((string)$url);
        $sanitized = filter_var($url, FILTER_SANITIZE_URL);
        if ($sanitized === false || !filter_var($sanitized, FILTER_VALIDATE_URL)) {
            return null;
        }
        if (!preg_match('/^https?:\/\//i', $sanitized)) {
            return null;
        }
        return $sanitized;
    }

        /** @param list<int> $userIds */
    /** @param list<int> $userIds */
/**
 * @param list<int> $userIds
 * @param array<string, mixed>|null $data
 */
private function processBatch(
        array $userIds, string $type, string $title, string $message,
        ?array $data, ?string $actionUrl, ?string $actionText, string $priority, ?string $scheduledAt
    ): int {
        $this->policyService->prefetchPreferences($userIds);

        $inAppRecords  = [];
        $pushUserIds   = [];
        $allowedIds    = [];

        // FIX-R36-W3 (F-A18-04): چک نرخ دسته‌ای — یک SELECT به‌ازای هر batch
        // به‌جای SELECT به‌ازای هر کاربر (N+1 روی blast). fail-open مثل قبل.
        $rateLimited = array_flip($this->recentlyNotifiedUserIds($userIds));

        foreach ($userIds as $uid) {
            if (isset($rateLimited[$uid])) continue;
            $allowedIds[] = $uid;

            if ($this->policyService->canSendInApp($uid, $type)) {
                $sched = $this->policyService->resolveScheduledTime($uid, $priority, $scheduledAt);
                $inAppRecords[] = ['user_id' => $uid, 'scheduled_at' => $sched];
            }
            if ($this->policyService->canSendPush($uid, $type)) {
                $pushUserIds[] = $uid;
            }
        }

        $inserted = 0;
        if (!empty($inAppRecords)) {
            $inserted = $this->bulkInsert($inAppRecords, $type, $title, $message, $data, $actionUrl, $actionText, $priority);
        }

        if (!empty($allowedIds)) {
            try { $this->tracker->invalidateUnreadCacheBulk($allowedIds); } catch (\Throwable $e) {
                $this->logger->warning('notif.all_bulk_cache_failed', ['error' => $e->getMessage()]);
            }
        }

        if (!empty($pushUserIds)) {
            $this->dispatchPush($pushUserIds, $title, $message, $data, $actionUrl);
        }

        return $inserted;
    }

        /** @param array<string, mixed> $records */
    /** @param array<string, mixed> $records */
/**
 * @param list<array<string, mixed>> $records
 * @param array<string, mixed>|null $data
 */
private function bulkInsert(array $records, string $type, string $title, string $message, ?array $data, ?string $actionUrl, ?string $actionText, string $priority): int
    {
        $now       = date('Y-m-d H:i:s');
        $dataJson  = $data ? json_encode($data, JSON_UNESCAPED_UNICODE) : null;
        $groupKey  = md5($type . $title);
        $placeholders = [];
        $params       = [];

        foreach ($records as $r) {
            $placeholders[] = '(?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?)';
            $params[] = $r['user_id'];
            $params[] = $type;
            $params[] = $title;
            $params[] = $message;
            $params[] = $dataJson;
            $params[] = $actionUrl;
            $params[] = $actionText;
            $params[] = $priority;
            $params[] = null;
            $params[] = $now;
            $params[] = $r['scheduled_at'];
            $params[] = Notification::CHANNEL_IN_APP;
            // 🛡️ FIX-X219: ستون group_key در جدول notifications وجود ندارد — حذف از INSERT
        }

        $sql = "INSERT INTO notifications 
                (user_id, type, title, message, data, action_url, action_text, priority, is_read, is_archived, expires_at, created_at, scheduled_at, channel)
                VALUES " . implode(', ', $placeholders);

        $this->db->execute($sql, $params);
        return count($records);
    }

    /**
     * @param list<int> $userIds
     * @param array<string, mixed>|null $data
     */
    private function dispatchPush(array $userIds, string $title, string $message, ?array $data, ?string $actionUrl): void
    {
        try {
            // 🛡️ FIX-OUTBOX-JOB-CONTRACT (P0 — pre-existing): دادهٔ جاب زیر کلید «data»
            // (قرارداد شاخهٔ job در OutboxPublisher)؛ قبلاً زیر «notification» بود →
            // send() بدون آرگومان → TypeError → DLQ؛ پوش FCM هرگز ارسال نمی‌شد.
            $this->outbox->record('notification', 0, 'notification.all_users_fcm', [
                'job'          => \App\Jobs\ProcessNotificationJob::class,
                'data'         => [
                    'channel'    => 'fcm',
                    'user_ids'   => $userIds,
                    'title'      => $title,
                    'message'    => $message,
                    'data'       => $data,
                    'action_url' => $actionUrl,
                ],
            ]);
        } catch (\Throwable $e) {
            $this->queue->pushUnique(
                \App\Jobs\ProcessNotificationJob::class,
                ['channel' => 'fcm', 'user_ids' => $userIds, 'title' => $title, 'message' => $message, 'data' => $data, 'action_url' => $actionUrl],
                'notif:all_fcm:' . md5($title . implode(',', array_slice($userIds, 0, 3))),
                null, 0, 86400
            );
        }
    }

    /**
     * FIX-R36-W3 (F-A18-04): جایگزین checkRate تک‌کاربره — یک کوئری به‌ازای هر
     * batch؛ خروجی = کاربرانی که در ۶۰ ثانیه اخیر نوتیفیکیشن داشته‌اند (skip).
     * @param list<int> $userIds
     * @return list<int>
     */
    private function recentlyNotifiedUserIds(array $userIds): array
    {
        if ($userIds === []) {
            return [];
        }
        try {
            $ph = implode(',', array_fill(0, count($userIds), '?'));
            $rows = $this->db->fetchAll(
                "SELECT DISTINCT user_id FROM notifications
                 WHERE user_id IN ({$ph}) AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)",
                $userIds
            );
            $recent = [];
            foreach ($rows as $row) {
                $recent[] = is_object($row) ? (int)$row->user_id : (int)$row['user_id'];
            }
            return $recent;
        } catch (\Throwable $e) {
            // fail-open — همان قرارداد checkRate قبلی
            $this->logger->warning('notif.all_rate_check_failed', ['error' => $e->getMessage()]);
            return [];
        }
    }

    private function sanitizeType(string $type): string
    {
        $type = trim((string)$type);
        $type = (string)preg_replace('/[^A-Za-z0-9_]/', '', $type);
        return $type !== '' ? $type : 'system';
    }
}
