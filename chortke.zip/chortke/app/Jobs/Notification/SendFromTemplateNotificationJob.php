<?php

namespace App\Jobs\Notification;

use App\Contracts\JobInterface;
use App\Services\Notification\NotificationTemplateService;

class SendFromTemplateNotificationJob implements JobInterface
{
    public function __construct(
        private NotificationTemplateService $templateService,
        private SendNotificationJob $sender
    ) {}

    public function handle(
        int    $userId,
        string $templateKey,
        array  $vars       = [],
        string $priority   = 'normal',
        ?string $actionUrl = null,
        ?string $actionText= null,
        ?string $groupKey  = null,
        ?string $scheduledAt = null
    ): ?int
    {
        
        $rendered = $templateService->renderTemplate($templateKey, $vars);
        $prefix = strtolower(preg_replace('/[^A-Za-z0-9_]/', '', explode('_', $templateKey)[0] ?? ''));
        
        $allowedTypes = [
            'deposit' => 'deposit',
            'withdrawal' => 'withdrawal',
            'task' => 'task',
            'kyc' => 'kyc',
            'lottery' => 'lottery',
            'referral' => 'referral',
            'security' => 'security',
            'investment' => 'investment',
            'info' => 'info',
            'marketing' => 'marketing',
        ];

        $type = $allowedTypes[$prefix] ?? 'system';

        return $sender->handle(
            $userId,
            $type,
            $rendered['title'],
            $rendered['message'],
            $vars,
            $actionUrl,
            $actionText,
            $priority,
            null,
            null,
            $groupKey ?? $templateKey,
            $scheduledAt
        );
    }
}
