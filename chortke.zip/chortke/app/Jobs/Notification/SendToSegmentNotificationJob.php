<?php

declare(strict_types=1);

namespace App\Jobs\Notification;

use App\Models\Notification;
use App\Services\Notification\NotificationPolicyService;
use App\Contracts\LoggerInterface;
use App\Services\Notification\NotificationTracker;
use Core\Queue;
use App\Contracts\OutboxServiceInterface;
use Core\Cache;
use Core\Database;

/**
 * SendToSegmentNotificationJob
 *
 * ارسال اعلان به بخش خاصی از کاربران (VIP، کاربران جدید، و...)
 * از همان الگوی bulk-insert + cache-invalidation + push مشابه SendToAdminsNotificationJob استفاده می‌کند.
 *
 * FIX-A6-F4 (Audit Task 6-a): blast اکنون «بچ‌های مستقل با cursor پایدار» است
 * (قرارداد همان SendToAllNotificationJob): پیشرفت در جدول
 * notification_blast_progress (مایگریشن 2026_09_25_0003) ذخیره می‌شود؛ retry
 * از last_user_id ادامه می‌یابد و فقط blastِ «completed» dedup می‌شود —
 * قبلاً claim ده‌دقیقه‌ای کش باعث می‌شد blastِ نیمه‌کاره در retry دوباره
 * dedup شود و کاربرانِ باقی‌مانده هرگز پردازش نشوند.
 */
class SendToSegmentNotificationJob
{
    private Database $db;
    private NotificationPolicyService $policyService;
    private LoggerInterface $logger;
    private NotificationTracker $tracker;
    private Queue $queue;
    private OutboxServiceInterface $outbox;
    private Cache $cache;

    private const BATCH_SIZE = 500;

    public function __construct(
        Database $db,
        NotificationPolicyService $policyService,
        LoggerInterface $logger,
        NotificationTracker $tracker,
        Queue $queue,
        OutboxServiceInterface $outbox,
        Cache $cache
    ) {
        $this->db = $db;
        $this->policyService = $policyService;
        $this->logger = $logger;
        $this->tracker = $tracker;
        $this->queue = $queue;
        $this->outbox = $outbox;
        $this->cache = $cache;
    }

        /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $filters */
    /** @return array<string, mixed> */
/** @param array<string, mixed> $data */
/** @param array<string, mixed> $filters */
/**
 * @param array<string, mixed>|null $data
 * @param array<string, mixed> $filters
 * @return array<string, mixed>
 */
public function handle(
        string  $segment,
        string  $title,
        string  $message,
        string  $type        = 'system',
        ?string $actionUrl   = null,
        ?string $actionText  = null,
        string  $priority    = 'normal',
        ?array  $data        = null,
        ?string $scheduledAt = null,
        array   $filters     = []
    ): array {
        $type    = $this->sanitizeType($type);
        $title   = mb_substr(trim(strip_tags($title)), 0, 255);
        $message = mb_substr(trim(strip_tags($message)), 0, 1200);
        // 🛡️ FIX-S17-7: action_url مشابه SendToAdminsNotificationJob ضدعفونی می‌شود —
        // قبلاً بدون sanitizeUrl درج می‌شد (مثلاً javascript: در اعلان in-app).
        $actionUrl = $this->sanitizeUrl($actionUrl);

        // 🛡️ FIX-R18-M10: entry dedupe gate (SETNX) — همان قرارداد SendToAll؛
        // دوبار dispatch/کلیک نباید اعلان سگمنت مضاعف بسازد.
        // FIX-A6-F4: این claim فقط «قفل اجرای هم‌زمان» است؛ منبع حقیقتِ اتمام/
        // cursor ردیف پایدار notification_blast_progress است.
        $claimKey = 'bulk_notif_' . hash('sha256', static::class . '|' . md5((string)json_encode([
            'segment' => $segment, 'title' => $title, 'message' => $message, 'type' => $type,
            'action_url' => $actionUrl, 'action_text' => $actionText,
            'priority' => $priority, 'data' => $data, 'scheduled_at' => $scheduledAt,
            'filters' => $filters,
        ], JSON_UNESCAPED_UNICODE)));
        $blastKey = substr($claimKey, strlen('bulk_notif_'));

        // FIX-A6-F4: وضعیت پایدار blast — completed ⇒ dedup (اتمام‌شده)؛
        // running/failed ⇒ resume از cursor.
        $progress = $this->loadBlastProgress($blastKey);
        if ($progress !== null && (string)$progress->status === 'completed') {
            $this->logger->info('notif.bulk_already_completed', [
                'job' => static::class, 'blast_key' => $blastKey,
                'total_sent' => (int)$progress->total_sent,
            ]);
            return [
                'sent' => 0, 'batches' => 0, 'deduped' => true,
                'segment' => $segment, 'total_sent' => (int)$progress->total_sent,
            ];
        }

        try {
            $claimed = $this->cache->add($claimKey, 1, 600);
        } catch (\Throwable $cacheEx) {
            // Cache در دسترس نیست → fail-open (رفتار پیش از فیکس) + لاگ.
            $this->logger->warning('notif.bulk_claim_cache_failed', ['error' => $cacheEx->getMessage()]);
            $claimed = true;
        }
        if (!$claimed) {
            $this->logger->warning('notif.bulk_dedupe_skip', ['job' => static::class, 'claim_key' => $claimKey]);
            return ['sent' => 0, 'batches' => 0, 'segment' => $segment, 'deduped' => true];
        }

        // FIX-R18-M10: event_id در خودِ payload اعلان — هم JSON اعلان in-app و هم
        // پیلود FCM → NotificationDispatcher claim-dedupe فعال می‌شود.
        $data = array_merge(is_array($data) ? $data : [], ['event_id' => $claimKey]);

        // 🛡️ FIX-S17-6: کوئری و bind مرتب هم‌تراز — قبلاً فیلترهای سفارشی به ترتیب
        // SQL ساخته ولی به ترتیب array_values($filters) بسته می‌شدند (mis-binding)
        // و سگمنت ناشناخته به کوئری «همهٔ کاربران» سقوط می‌کرد (fail-open).
        $segmentQuery = $this->buildSegmentQuery($segment, $filters);
        if ($segmentQuery === null) {
            $this->logger->warning('notification.segment_unknown', ['segment' => mb_substr($segment, 0, 50)]);
            return ['sent' => 0, 'batches' => 0, 'segment' => $segment, 'blocked' => true];
        }
        [$segmentSql, $segmentBindings] = $segmentQuery;

        $resumed = $progress !== null;
        $lastId  = $resumed ? max(0, (int)$progress->last_user_id) : 0;
        $totalSent  = $resumed ? max(0, (int)$progress->total_sent) : 0;
        $batchCount = $resumed ? max(0, (int)$progress->batches_done) : 0;

        if ($resumed) {
            $this->logger->warning('notif.bulk_resume_from_cursor', [
                'job' => static::class, 'blast_key' => $blastKey,
                'segment' => mb_substr($segment, 0, 50),
                'resume_from_user_id' => $lastId,
                'batches_done_before' => $batchCount,
                'total_sent_before' => $totalSent,
            ]);
            $this->markBlastStatus($blastKey, 'running');
        } else {
            $this->initBlastProgress($blastKey);
        }

        try {
            // FIX-R36-W3 (F-A18-04): cursor-based (id > lastId) به‌جای LIMIT/OFFSET —
            // درج/حذف کاربر حین blast دیگر پرش/تکرار نمی‌سازد. همهٔ شاخه‌های
            // buildSegmentQuery از base یکسان «SELECT id FROM users WHERE deleted_at
            // IS NULL» + AND می‌سازند پس افزودن «AND id > ?» بی‌خطر است.
            // FIX-A6-F4: cursor پس از هر batch به‌صورت پایدار ثبت می‌شود.
            while (true) {
                $userIds = $this->db->fetchAll(
                    $segmentSql . " AND id > ? ORDER BY id ASC LIMIT ?",
                    array_merge($segmentBindings, [$lastId, self::BATCH_SIZE])
                );
                if (empty($userIds)) break;

                $ids = array_map(fn($row) => (int) (is_object($row) ? $row->id : $row['id']), $userIds);
                $sentInBatch = $this->processBatch($ids, $type, $title, $message, $data, $actionUrl, $actionText, $priority, $scheduledAt);
                $lastId = max($ids);
                $batchCount++;
                $totalSent += $sentInBatch;
                $this->advanceBlastProgress($blastKey, $lastId, $sentInBatch);
            }

            $this->completeBlastProgress($blastKey, $lastId, $batchCount, $totalSent);
        } catch (\Throwable $e) {
            // FIX-A6-F4: شکست → claim کش آزاد می‌شود تا retry دوباره dedup نشود؛
            // cursor پایدار سر جای خودش مانده و ادامه از آنجا می‌رود.
            try { $this->cache->forget($claimKey); } catch (\Throwable $ignore) {}
            $this->markBlastStatus($blastKey, 'failed');
            throw $e;
        }

        return [
            'sent' => $totalSent - ($resumed ? max(0, (int)$progress->total_sent) : 0),
            'batches' => $batchCount,
            'segment' => $segment,
            'total_sent' => $totalSent,
            'resumed' => $resumed,
        ];
    }

    // ─────────────────────────────────────────────────────────────────
    // FIX-A6-F4 — پیشرفت پایدار blast (notification_blast_progress)
    // fail-open: اگر جدول هنوز مایگریت نشده باشد، رفتار قدیمی حفظ می‌شود.
    // ─────────────────────────────────────────────────────────────────

    private function loadBlastProgress(string $blastKey): ?\stdClass
    {
        try {
            $row = $this->db->selectOne(
                "SELECT blast_key, last_user_id, batches_done, total_sent, status
                 FROM notification_blast_progress WHERE blast_key = ?",
                [$blastKey]
            );
            return $row instanceof \stdClass ? $row : null;
        } catch (\Throwable $e) {
            $this->logger->warning('notif.blast_progress_unavailable', [
                'job' => static::class, 'error' => $e->getMessage(),
            ]);
            return null;
        }
    }

    private function initBlastProgress(string $blastKey): void
    {
        try {
            // INSERT IGNORE: امن در برابر رقابت دو ورکر (claim کش هم پوشش می‌دهد).
            $this->db->execute(
                "INSERT IGNORE INTO notification_blast_progress (blast_key, last_user_id, batches_done, total_sent, status)
                 VALUES (?, 0, 0, 0, 'running')",
                [$blastKey]
            );
        } catch (\Throwable $e) {
            $this->logger->warning('notif.blast_progress_init_failed', ['error' => $e->getMessage()]);
        }
    }

    private function advanceBlastProgress(string $blastKey, int $lastUserId, int $sentInBatch): void
    {
        try {
            $this->db->execute(
                "UPDATE notification_blast_progress
                 SET last_user_id = GREATEST(last_user_id, ?),
                     batches_done = batches_done + 1,
                     total_sent   = total_sent + ?,
                     status       = 'running'
                 WHERE blast_key = ?",
                [$lastUserId, max(0, $sentInBatch), $blastKey]
            );
        } catch (\Throwable $e) {
            // cursor فقط بهینه‌ساز resume است؛ شکست ثبتش نباید blast را بشکند.
            $this->logger->warning('notif.blast_progress_advance_failed', ['error' => $e->getMessage()]);
        }
    }

    private function completeBlastProgress(string $blastKey, int $lastUserId, int $batches, int $totalSent): void
    {
        try {
            $this->db->execute(
                "UPDATE notification_blast_progress
                 SET status = 'completed', last_user_id = GREATEST(last_user_id, ?),
                     batches_done = GREATEST(batches_done, ?), total_sent = GREATEST(total_sent, ?)
                 WHERE blast_key = ?",
                [$lastUserId, $batches, $totalSent, $blastKey]
            );
        } catch (\Throwable $e) {
            $this->logger->warning('notif.blast_progress_complete_failed', ['error' => $e->getMessage()]);
        }
    }

    /** @param 'running'|'completed'|'failed' $status */
    private function markBlastStatus(string $blastKey, string $status): void
    {
        try {
            $this->db->execute(
                "UPDATE notification_blast_progress SET status = ? WHERE blast_key = ?",
                [$status, $blastKey]
            );
        } catch (\Throwable $e) {
            $this->logger->warning('notif.blast_progress_status_failed', ['status' => $status, 'error' => $e->getMessage()]);
        }
    }

    /**
     * 🛡️ FIX-S17-6: بازگشت [sql, bindings] با bind هم‌ترازِ ترتیب ساخت SQL.
     * سگمنت ناشناخته یا سگمنت سفارشی بدون هیچ فیلتر معتبری ⇒ null (fail-closed،
     * به‌جای سقوط به «همهٔ کاربران»).
     *
     * 🛡️ FIX-R36-W2-F1 (F-A18-01): قرارداد سگمنت با اسکیمای واقعی users هم‌تراز شد —
     *  - ستون شبح last_login_at → ستون واقعی last_login (۴۲S22 → ۵۰۰ در مسیر ادمین).
     *  - فیلتر شبح level_id/level → ستون واقعی level_slug (سطح از جدول user_levels
     *    با slugهای bronze/silver/gold/vip/platinum/diamond می‌آید؛ role='vip' وجود ندارد —
     *    enum نقش فقط user/admin/super_admin/support است).
     *  - کلیدهای دراپ‌داون ادمین (GetAvailableSegments) حالا واقعاً پشتیبانی می‌شوند:
     *    kyc_verified/kyc_pending/kyc_none/level_silver/level_gold/level_vip.
     *  - وایت‌لیست سفارشی هم‌تراز فرم ادمین: status/kyc_status/level/role/registered_after
     *    (مقادیر با enumهای واقعی ستون‌ها وایت‌لیست می‌شوند؛ کلید ناشناخته = fail-closed).
     * @param array<string, mixed> $filters
     * @return array{0:string,1:list<mixed>}|null
     */
    private function buildSegmentQuery(string $segment, array $filters): ?array
    {
        $base = "SELECT id FROM users WHERE deleted_at IS NULL";
        // سطحِ خریداری‌شده منقضی‌شده دیگر «سطح فعلی» نیست (سطح auto بدون انقضا).
        $activeLevel = " AND (level_type = 'auto' OR level_expires_at IS NULL OR level_expires_at > NOW())";

        switch ($segment) {
            case 'all':
                return [$base, []];
            case 'vip':
            case 'level_vip':
                return [$base . $activeLevel . " AND level_slug = 'vip'", []];
            case 'verified':
            case 'kyc_verified':
                return [$base . " AND kyc_status = 'verified'", []];
            case 'kyc_pending':
                return [$base . " AND kyc_status = 'pending'", []];
            case 'kyc_none':
                return [$base . " AND (kyc_status IS NULL OR kyc_status IN ('', 'none', 'unverified'))", []];
            case 'new_users':
                // هم‌تراز برچسب دراپ‌داون ادمین: «کاربران جدید (۳۰ روز اخیر)»
                return [$base . " AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)", []];
            case 'active':
                return [$base . " AND last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY)", []];
            case 'inactive':
                // هم‌تراز برچسب دراپ‌داون ادمین: «کاربران غیرفعال (۶۰+ روز)»
                return [$base . " AND (last_login IS NULL OR last_login < DATE_SUB(NOW(), INTERVAL 60 DAY))", []];
            case 'level_silver':
                return [$base . $activeLevel . " AND level_slug = 'silver'", []];
            case 'level_gold':
                return [$base . $activeLevel . " AND level_slug = 'gold'", []];
            case 'admins':
                return [$base . " AND role IN ('admin', 'super_admin')", []];
        }

        // سگمنت سفارشی — فقط کلیدهای وایت‌لیست؛ bindings دقیقاً هم‌تراز با ساخت SQL
        $extra = '';
        $bindings = [];
        if (isset($filters['role']) && is_string($filters['role']) && in_array($filters['role'], ['user', 'admin', 'super_admin', 'support'], true)) {
            $extra .= " AND role = ?";
            $bindings[] = $filters['role'];
        }
        if (isset($filters['status']) && is_string($filters['status']) && in_array($filters['status'], ['active', 'inactive', 'suspended', 'locked', 'locked_2fa', 'banned'], true)) {
            $extra .= " AND status = ?";
            $bindings[] = $filters['status'];
        }
        if (isset($filters['kyc_status']) && is_string($filters['kyc_status']) && in_array($filters['kyc_status'], ['verified', 'pending', 'rejected', 'unverified'], true)) {
            $extra .= " AND kyc_status = ?";
            $bindings[] = $filters['kyc_status'];
        }
        if (isset($filters['level']) && is_string($filters['level']) && preg_match('/^[a-z_]{1,30}$/', $filters['level']) === 1) {
            $extra .= " AND level_slug = ?";
            $bindings[] = $filters['level'];
        }
        if (isset($filters['registered_after']) && is_string($filters['registered_after']) && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $filters['registered_after']) === 1) {
            $extra .= " AND created_at >= ?";
            $bindings[] = $filters['registered_after'];
        }
        if ($extra === '') {
            // بدون فیلتر معتبر، ارسال سفارشی = blast به همهٔ کاربران — مسدود
            return null;
        }
        return [$base . $extra, $bindings];
    }

    /**
     * 🛡️ FIX-S17-7: ضدعفونی URL — فقط http/https مطلق (هم‌سنگ نسخهٔ SendToAdmins).
     */
    private function sanitizeUrl(?string $url): ?string
    {
        if ($url === null || $url === '') {
            return null;
        }
        $url = trim((string)$url);
        $sanitized = filter_var($url, FILTER_SANITIZE_URL);
        if ($sanitized === false || !filter_var($sanitized, FILTER_VALIDATE_URL)) {
            return null;
        }
        if (!preg_match('/^https?:\/\//i', $sanitized)) {
            return null;
        }
        return $sanitized;
    }

        /** @param list<int> $userIds */
    /** @param list<int> $userIds */
/**
 * @param list<int> $userIds
 * @param array<string, mixed>|null $data
 */
private function processBatch(
        array $userIds, string $type, string $title, string $message,
        ?array $data, ?string $actionUrl, ?string $actionText, string $priority, ?string $scheduledAt
    ): int {
        $this->policyService->prefetchPreferences($userIds);

        $inAppRecords = [];
        $pushUserIds  = [];
        $allowedIds   = [];

        // FIX-R36-W3 (F-A18-04): چک نرخ دسته‌ای — یک SELECT به‌ازای هر batch
        // به‌جای SELECT به‌ازای هر کاربر (N+1 روی blast). fail-open مثل قبل.
        $rateLimited = array_flip($this->recentlyNotifiedUserIds($userIds));

        foreach ($userIds as $uid) {
            if (isset($rateLimited[$uid])) continue;
            $allowedIds[] = $uid;

            if ($this->policyService->canSendInApp($uid, $type)) {
                $sched = $this->policyService->resolveScheduledTime($uid, $priority, $scheduledAt);
                $inAppRecords[] = ['user_id' => $uid, 'scheduled_at' => $sched];
            }
            if ($this->policyService->canSendPush($uid, $type)) {
                $pushUserIds[] = $uid;
            }
        }

        $inserted = 0;
        if (!empty($inAppRecords)) {
            $inserted = $this->bulkInsert($inAppRecords, $type, $title, $message, $data, $actionUrl, $actionText, $priority);
        }

        if (!empty($allowedIds)) {
            try { $this->tracker->invalidateUnreadCacheBulk($allowedIds); } catch (\Throwable $e) {
                $this->logger->warning('notif.segment_bulk_cache_failed', ['error' => $e->getMessage()]);
            }
        }

        if (!empty($pushUserIds)) {
            $this->dispatchPush($pushUserIds, $title, $message, $data, $actionUrl);
        }

        return $inserted;
    }

    /**
     * @param list<array<string, mixed>> $records
     * @param array<string, mixed>|null $data
     */
    private function bulkInsert(array $records, string $type, string $title, string $message, ?array $data, ?string $actionUrl, ?string $actionText, string $priority): int
    {
        $now      = date('Y-m-d H:i:s');
        // FIX-A6-F3: کلید idempotency blast — از event_id payload (همان claimKey)
        // استخراج می‌شود و در ستون یگانه (idempotency_key, user_id, channel) می‌نشیند؛
        // تکرارِ batch (شکست بعد از INSERT، قبل از ثبت cursor) ردیف مضاعف نمی‌سازد.
        $idempotencyKey = is_array($data) ? ($data['event_id'] ?? null) : null;
        $idempotencyKey = (is_string($idempotencyKey) || is_int($idempotencyKey))
            ? mb_substr(trim((string)$idempotencyKey), 0, 128)
            : null;
        $dataJson = $data ? json_encode($data, JSON_UNESCAPED_UNICODE) : null;
        $placeholders = [];
        $params       = [];

        foreach ($records as $r) {
            if ($idempotencyKey !== null) {
                $placeholders[] = '(?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?, ?)';
                $params[] = $r['user_id'];
                $params[] = $type;
                $params[] = $title;
                $params[] = $message;
                $params[] = $dataJson;
                $params[] = $actionUrl;
                $params[] = $actionText;
                $params[] = $priority;
                $params[] = null;
                $params[] = $now;
                $params[] = $r['scheduled_at'];
                $params[] = Notification::CHANNEL_IN_APP;
                $params[] = $idempotencyKey;
            } else {
                $placeholders[] = '(?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?)';
                $params[] = $r['user_id'];
                $params[] = $type;
                $params[] = $title;
                $params[] = $message;
                $params[] = $dataJson;
                $params[] = $actionUrl;
                $params[] = $actionText;
                $params[] = $priority;
                $params[] = null;
                $params[] = $now;
                $params[] = $r['scheduled_at'];
                $params[] = Notification::CHANNEL_IN_APP;
            }
            // 🛡️ FIX-X219: ستون group_key در جدول notifications وجود ندارد — حذف از INSERT
        }

        $sql = "INSERT INTO notifications 
                (user_id, type, title, message, data, action_url, action_text, priority, is_read, is_archived, expires_at, created_at, scheduled_at, channel" . ($idempotencyKey !== null ? ", idempotency_key" : "") . ")
                VALUES " . implode(', ', $placeholders);

        if ($idempotencyKey !== null) {
            // FIX-A6-F3: UPSERT بدون‌اثر روی تکراری‌ها — rowCount = تعداد ردیف‌های واقعاً جدید.
            $sql .= " ON DUPLICATE KEY UPDATE id = id";
        }

        return $this->db->execute($sql, $params);
    }

    /**
     * @param list<int> $userIds
     * @param array<string, mixed>|null $data
     */
    private function dispatchPush(array $userIds, string $title, string $message, ?array $data, ?string $actionUrl): void
    {
        try {
            // 🛡️ FIX-OUTBOX-JOB-CONTRACT (P0 — pre-existing): دادهٔ جاب زیر کلید «data»
            // (قرارداد شاخهٔ job در OutboxPublisher)؛ قبلاً زیر «notification» بود →
            // send() بدون آرگومان → TypeError → DLQ؛ پوش FCM هرگز ارسال نمی‌شد.
            //
            // FIX-A6-F5 (Audit Task 6-a): false از record() = قطعیِ ثبت outbox است،
            // نه موفقیت — throw می‌شود تا fallback صف همیشه فعال شود.
            $recorded = $this->outbox->record('notification', 0, 'notification.segment_fcm', [
                'job'          => \App\Jobs\ProcessNotificationJob::class,
                'data'         => [
                    'channel'    => 'fcm',
                    'user_ids'   => $userIds,
                    'title'      => $title,
                    'message'    => $message,
                    'data'       => $data,
                    'action_url' => $actionUrl,
                ],
            ]);
            if (!$recorded) {
                throw new \RuntimeException('OutboxService::record returned false for notification.segment_fcm.');
            }
        } catch (\Throwable $e) {
            $this->logger->warning('notif.seg_fcm_outbox_failed_fallback_queue', ['error' => $e->getMessage()]);
            $this->queue->pushUnique(
                \App\Jobs\ProcessNotificationJob::class,
                ['channel' => 'fcm', 'user_ids' => $userIds, 'title' => $title, 'message' => $message, 'data' => $data, 'action_url' => $actionUrl],
                'notif:seg_fcm:' . md5($title . implode(',', array_slice($userIds, 0, 3))),
                null, 0, 86400
            );
        }
    }

    /**
     * FIX-R36-W3 (F-A18-04): جایگزین checkRate تک‌کاربره — یک کوئری به‌ازای هر
     * batch؛ خروجی = کاربرانی که در ۶۰ ثانیه اخیر نوتیفیکیشن داشته‌اند (skip).
     * @param list<int> $userIds
     * @return list<int>
     */
    private function recentlyNotifiedUserIds(array $userIds): array
    {
        if ($userIds === []) {
            return [];
        }
        try {
            $ph = implode(',', array_fill(0, count($userIds), '?'));
            $rows = $this->db->fetchAll(
                "SELECT DISTINCT user_id FROM notifications
                 WHERE user_id IN ({$ph}) AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)",
                $userIds
            );
            $recent = [];
            foreach ($rows as $row) {
                $recent[] = is_object($row) ? (int)$row->user_id : (int)$row['user_id'];
            }
            return $recent;
        } catch (\Throwable $e) {
            // fail-open — همان قرارداد checkRate قبلی
            $this->logger->warning('notif.seg_rate_check_failed', ['error' => $e->getMessage()]);
            return [];
        }
    }

    private function sanitizeType(string $type): string
    {
        $type = trim((string)$type);
        $type = (string)preg_replace('/[^A-Za-z0-9_]/', '', $type);
        return $type !== '' ? $type : 'system';
    }
}
