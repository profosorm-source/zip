<?php

declare(strict_types=1);

namespace App\Jobs\Notification;

use App\Models\Notification;
use App\Services\Notification\NotificationPolicyService;
use App\Contracts\LoggerInterface;
use App\Services\Notification\NotificationTracker;
use Core\Queue;
use App\Contracts\OutboxServiceInterface;
use Core\Database;

/**
 * SendToSegmentNotificationJob
 *
 * ارسال اعلان به بخش خاصی از کاربران (VIP، کاربران جدید، و...)
 * از همان الگوی bulk-insert + cache-invalidation + push مشابه SendToAdminsNotificationJob استفاده می‌کند.
 */
class SendToSegmentNotificationJob
{
    private Database $db;
    private NotificationPolicyService $policyService;
    private LoggerInterface $logger;
    private NotificationTracker $tracker;
    private Queue $queue;
    private OutboxServiceInterface $outbox;

    private const BATCH_SIZE = 500;

    public function __construct(
        Database $db,
        NotificationPolicyService $policyService,
        LoggerInterface $logger,
        NotificationTracker $tracker,
        Queue $queue,
        OutboxServiceInterface $outbox
    ) {
        $this->db = $db;
        $this->policyService = $policyService;
        $this->logger = $logger;
        $this->tracker = $tracker;
        $this->queue = $queue;
        $this->outbox = $outbox;
    }

        /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $filters */
    /** @return array<string, mixed> */
/** @param array<string, mixed> $data */
/** @param array<string, mixed> $filters */
/**
 * @param array<string, mixed>|null $data
 * @param array<string, mixed> $filters
 * @return array<string, mixed>
 */
public function handle(
        string  $segment,
        string  $title,
        string  $message,
        string  $type        = 'system',
        ?string $actionUrl   = null,
        ?string $actionText  = null,
        string  $priority    = 'normal',
        ?array  $data        = null,
        ?string $scheduledAt = null,
        array   $filters     = []
    ): array {
        $type    = $this->sanitizeType($type);
        $title   = mb_substr(trim(strip_tags($title)), 0, 255);
        $message = mb_substr(trim(strip_tags($message)), 0, 1200);
        // 🛡️ FIX-S17-7: action_url مشابه SendToAdminsNotificationJob ضدعفونی می‌شود —
        // قبلاً بدون sanitizeUrl درج می‌شد (مثلاً javascript: در اعلان in-app).
        $actionUrl = $this->sanitizeUrl($actionUrl);

        $totalSent  = 0;
        $batchCount = 0;
        $offset     = 0;

        // 🛡️ FIX-S17-6: کوئری و bind مرتب هم‌تراز — قبلاً فیلترهای سفارشی به ترتیب
        // SQL ساخته ولی به ترتیب array_values($filters) بسته می‌شدند (mis-binding)
        // و سگمنت ناشناخته به کوئری «همهٔ کاربران» سقوط می‌کرد (fail-open).
        $segmentQuery = $this->buildSegmentQuery($segment, $filters);
        if ($segmentQuery === null) {
            $this->logger->warning('notification.segment_unknown', ['segment' => mb_substr($segment, 0, 50)]);
            return ['sent' => 0, 'batches' => 0, 'segment' => $segment, 'blocked' => true];
        }
        [$segmentSql, $segmentBindings] = $segmentQuery;

        while (true) {
            $userIds = $this->db->fetchAll(
                $segmentSql . " ORDER BY id ASC LIMIT ? OFFSET ?",
                array_merge($segmentBindings, [self::BATCH_SIZE, $offset])
            );
            if (empty($userIds)) break;

            $ids = array_map(fn($row) => (int) (is_object($row) ? $row->id : $row['id']), $userIds);
            $sentInBatch = $this->processBatch($ids, $type, $title, $message, $data, $actionUrl, $actionText, $priority, $scheduledAt);
            $totalSent  += $sentInBatch;
            $batchCount++;
            $offset     += self::BATCH_SIZE;
        }

        return ['sent' => $totalSent, 'batches' => $batchCount, 'segment' => $segment];
    }

    /** @param array<string, mixed> $filters */
    /**
     * 🛡️ FIX-S17-6: بازگشت [sql, bindings] با bind هم‌ترازِ ترتیب ساخت SQL.
     * سگمنت ناشناخته یا سگمنت سفارشی بدون هیچ فیلتر معتبری ⇒ null (fail-closed،
     * به‌جای سقوط به «همهٔ کاربران»).
     * @param array<string, mixed> $filters
     * @return array{0:string,1:list<mixed>}|null
     */
    private function buildSegmentQuery(string $segment, array $filters): ?array
    {
        $base = "SELECT id FROM users WHERE deleted_at IS NULL";

        switch ($segment) {
            case 'all':
                return [$base, []];
            case 'vip':
                return [$base . " AND role = 'vip'", []];
            case 'verified':
                return [$base . " AND kyc_status = 'verified'", []];
            case 'new_users':
                return [$base . " AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)", []];
            case 'active':
                return [$base . " AND last_login_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)", []];
            case 'inactive':
                return [$base . " AND (last_login_at IS NULL OR last_login_at < DATE_SUB(NOW(), INTERVAL 30 DAY))", []];
            case 'admins':
                return [$base . " AND role IN ('admin', 'super_admin')", []];
        }

        // سگمنت سفارشی — فقط کلیدهای وایت‌لیست؛ bindings دقیقاً هم‌تراز با ساخت SQL
        $extra = '';
        $bindings = [];
        if (isset($filters['role']) && is_string($filters['role']) && preg_match('/^[a-z_]{1,30}$/', $filters['role']) === 1) {
            $extra .= " AND role = ?";
            $bindings[] = $filters['role'];
        }
        if (isset($filters['min_level']) && is_numeric($filters['min_level'])) {
            $extra .= " AND level_id >= ?";
            $bindings[] = (int)$filters['min_level'];
        }
        if (isset($filters['registered_after']) && is_string($filters['registered_after']) && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $filters['registered_after']) === 1) {
            $extra .= " AND created_at >= ?";
            $bindings[] = $filters['registered_after'];
        }
        if ($extra === '') {
            // بدون فیلتر معتبر، ارسال سفارشی = blast به همهٔ کاربران — مسدود
            return null;
        }
        return [$base . $extra, $bindings];
    }

    /**
     * 🛡️ FIX-S17-7: ضدعفونی URL — فقط http/https مطلق (هم‌سنگ نسخهٔ SendToAdmins).
     */
    private function sanitizeUrl(?string $url): ?string
    {
        if ($url === null || $url === '') {
            return null;
        }
        $url = trim((string)$url);
        $sanitized = filter_var($url, FILTER_SANITIZE_URL);
        if ($sanitized === false || !filter_var($sanitized, FILTER_VALIDATE_URL)) {
            return null;
        }
        if (!preg_match('/^https?:\/\//i', $sanitized)) {
            return null;
        }
        return $sanitized;
    }

        /** @param list<int> $userIds */
    /** @param list<int> $userIds */
/**
 * @param list<int> $userIds
 * @param array<string, mixed>|null $data
 */
private function processBatch(
        array $userIds, string $type, string $title, string $message,
        ?array $data, ?string $actionUrl, ?string $actionText, string $priority, ?string $scheduledAt
    ): int {
        $this->policyService->prefetchPreferences($userIds);

        $inAppRecords = [];
        $pushUserIds  = [];
        $allowedIds   = [];

        foreach ($userIds as $uid) {
            if (!$this->checkRate($uid)) continue;
            $allowedIds[] = $uid;

            if ($this->policyService->canSendInApp($uid, $type)) {
                $sched = $this->policyService->resolveScheduledTime($uid, $priority, $scheduledAt);
                $inAppRecords[] = ['user_id' => $uid, 'scheduled_at' => $sched];
            }
            if ($this->policyService->canSendPush($uid, $type)) {
                $pushUserIds[] = $uid;
            }
        }

        $inserted = 0;
        if (!empty($inAppRecords)) {
            $inserted = $this->bulkInsert($inAppRecords, $type, $title, $message, $data, $actionUrl, $actionText, $priority);
        }

        if (!empty($allowedIds)) {
            try { $this->tracker->invalidateUnreadCacheBulk($allowedIds); } catch (\Throwable $e) {
                $this->logger->warning('notif.segment_bulk_cache_failed', ['error' => $e->getMessage()]);
            }
        }

        if (!empty($pushUserIds)) {
            $this->dispatchPush($pushUserIds, $title, $message, $data, $actionUrl);
        }

        return $inserted;
    }

    /**
     * @param list<array<string, mixed>> $records
     * @param array<string, mixed>|null $data
     */
    private function bulkInsert(array $records, string $type, string $title, string $message, ?array $data, ?string $actionUrl, ?string $actionText, string $priority): int
    {
        $now      = date('Y-m-d H:i:s');
        $dataJson = $data ? json_encode($data, JSON_UNESCAPED_UNICODE) : null;
        $groupKey = md5($type . $title);
        $placeholders = [];
        $params       = [];

        foreach ($records as $r) {
            $placeholders[] = '(?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?)';
            $params[] = $r['user_id'];
            $params[] = $type;
            $params[] = $title;
            $params[] = $message;
            $params[] = $dataJson;
            $params[] = $actionUrl;
            $params[] = $actionText;
            $params[] = $priority;
            $params[] = null;
            $params[] = $now;
            $params[] = $r['scheduled_at'];
            $params[] = Notification::CHANNEL_IN_APP;
            // 🛡️ FIX-X219: ستون group_key در جدول notifications وجود ندارد — حذف از INSERT
        }

        $sql = "INSERT INTO notifications 
                (user_id, type, title, message, data, action_url, action_text, priority, is_read, is_archived, expires_at, created_at, scheduled_at, channel)
                VALUES " . implode(', ', $placeholders);

        $this->db->execute($sql, $params);
        return count($records);
    }

    /**
     * @param list<int> $userIds
     * @param array<string, mixed>|null $data
     */
    private function dispatchPush(array $userIds, string $title, string $message, ?array $data, ?string $actionUrl): void
    {
        try {
            // 🛡️ FIX-OUTBOX-JOB-CONTRACT (P0 — pre-existing): دادهٔ جاب زیر کلید «data»
            // (قرارداد شاخهٔ job در OutboxPublisher)؛ قبلاً زیر «notification» بود →
            // send() بدون آرگومان → TypeError → DLQ؛ پوش FCM هرگز ارسال نمی‌شد.
            $this->outbox->record('notification', 0, 'notification.segment_fcm', [
                'job'          => \App\Jobs\ProcessNotificationJob::class,
                'data'         => [
                    'channel'    => 'fcm',
                    'user_ids'   => $userIds,
                    'title'      => $title,
                    'message'    => $message,
                    'data'       => $data,
                    'action_url' => $actionUrl,
                ],
            ]);
        } catch (\Throwable $e) {
            $this->queue->pushUnique(
                \App\Jobs\ProcessNotificationJob::class,
                ['channel' => 'fcm', 'user_ids' => $userIds, 'title' => $title, 'message' => $message, 'data' => $data, 'action_url' => $actionUrl],
                'notif:seg_fcm:' . md5($title . implode(',', array_slice($userIds, 0, 3))),
                null, 0, 86400
            );
        }
    }

    private function checkRate(int $userId): bool
    {
        try {
            $last = $this->db->fetchColumn(
                "SELECT MAX(created_at) FROM notifications WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)",
                [$userId]
            );
            return $last === false || $last === null;
        } catch (\Throwable $e) {
            $this->logger->warning('notif.seg_rate_check_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
            return true;
        }
    }

    private function sanitizeType(string $type): string
    {
        $type = trim((string)$type);
        $type = (string)preg_replace('/[^A-Za-z0-9_]/', '', $type);
        return $type !== '' ? $type : 'system';
    }
}
