<?php

namespace App\Jobs\Notification;

use App\Contracts\JobInterface;
use App\Services\Notification\NotificationPreferenceService;
use App\Contracts\LoggerInterface;
use Core\RateLimiter;
use Core\Database;
use App\Models\Notification;

class SendNotificationJob implements JobInterface
{
    public function __construct(
        private NotificationPreferenceService $preferenceService,
        private LoggerInterface $logger,
        private RateLimiter $rateLimiter,
        private Database $db,
        private \App\Services\Notification\NotificationTracker $tracker
    ) {}

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(
        int $userId,
        string $type,
        string $title,
        string $message,
        ?array $data = null,
        ?string $actionUrl = null,
        ?string $actionText = null,
        string $priority = 'normal',
        ?string $expiresAt = null,
        ?string $imageUrl = null,
        ?string $groupKey = null,
        ?string $scheduledAt = null
    ): ?int
    {
        try {
            // 🛡️ FIX-R66-D2 (راند ۶۶ — مشاهدهٔ O-R65-3): چک موجودبودن کاربر در
            // مصرف‌کنندهٔ اعلان. این جاب «نویسندهٔ مرکزی» اعلان in-app است اما هیچ
            // چکی روی موجودبودن/وضعیت کاربر نداشت:
            //   ① کاربرِ حذف‌شدهٔ نرم (ساگای رسمی حساب: status='deleted' + ناشناس‌سازی
            //      — ردیف می‌ماند) ⇒ اعلان برای حساب حذف‌شده نوشته می‌شد (دادهٔ زائد
            //      و نقض هدف حذف حساب)؛ bulk-senderها «deleted_at IS NULL» دارند
            //      (SendToAll:154) اما این مسیرِ تک‌گیرنده استثنا بود.
            //   ② کاربرِ کاملاً حذف‌شده (ردیف غایب) ⇒ INSERT با خطای FK 1452 ⇒
            //      re-throw ⇒ retry ×۵ ⇒ DLQ (پیام سمی — الگوی O-R62).
            // بازگشت null = skip تجاری (نه شکست زیرساختی) — هم‌قرارداد با گیت‌های
            // preference/rate-limiter پایین‌تر. چک پیش از همهٔ گیت‌ها تا «حساب حذف‌شده»
            // حتی با ترجیحات فعال هم skip شود. شاخه‌های ایمیلی/FCM جدا هستند و
            // گیت‌های خودشان را دارند (این جاب فقط نویسندهٔ in-app است).
            $userRow = $this->db->selectOne("SELECT id, status, deleted_at FROM users WHERE id = ?", [$userId]);
            if (!$userRow || (string)($userRow->status ?? '') === 'deleted' || !empty($userRow->deleted_at)) {
                $this->logger->info('notification.skipped_user_unavailable', [
                    'user_id' => $userId,
                    'type'    => $type,
                    'reason'  => $userRow ? 'user_deleted' : 'user_not_found',
                ]);
                return null;
            }

            if (!$this->preferenceService->isNotificationEnabled($userId, $type)) {
                return null;
            }

            // 🛡️ FIX-S45-D2 (راند ۴۵ — P2): گیت کانال in-app. این جاب «نویسندهٔ
            // مرکزی» اعلان درون‌برنامه‌ای است (channel='in_app') اما قبلاً فقط
            // isNotificationEnabled (یعنی «حداقل یک کانال — مثلاً email — روشن»)
            // بررسی می‌شد ⇒ کاربری که in-app را کاملاً خاموش کرده بود (master
            // in_app_enabled=0 یا granular in_app_{type}=0) همچنان اعلان in-app
            // می‌گرفت. هر سه خواهر (SendToAll/SendToSegment/SendToAdmins با
            // policyService::canSendInApp) همین گیت را دارند — این مسیر تنها
            // استثنا بود. isInAppEnabled همان قرارداد است (delegation) و
            // نرمال‌سازی نوع (payment→deposit و…) را هم اعمال می‌کند.
            if (!$this->preferenceService->isInAppEnabled($userId, $type)) {
                return null;
            }

            if (!$this->rateLimiter->attempt("notif_limit:{$userId}:{$type}", 5, 60)) {
                $this->logger->warning('notification.rate_limited', ['user_id' => $userId, 'type' => $type]);
                return null;
            }

            // We need a way to persist the notification.
            $model = new Notification($this->db);
            
            // 🛡️ FIX-S18-8 (Low — S18-AUDIT): پارتی sanitizeUrl — این جاب «نویسندهٔ
            // مرکزی» اعلان in-app است و برخلاف سه خواهرش (SendToSegment/SendToAll/
            // SendToAdmins با FIX-S17-7) action_url را بدون گارد می‌نوشت ⇒
            // javascript:/data: در اعلان in-app ممکن بود. همان قرارداد: URL نامعتبر
            // یا غیر-http(s) → null.
            $actionUrl = $this->sanitizeUrl($actionUrl);

            $notifId = $model->create([
                'user_id'      => $userId,
                'type'         => $type,
                'title'        => $title,
                'message'      => $message,
                'data'         => $data,
                'action_url'   => $actionUrl,
                'action_text'  => $actionText,
                'priority'     => $priority,
                'expires_at'   => $expiresAt,
                'image_url'    => $imageUrl,
                'idempotency_key' => $this->resolveIdempotencyKey($data),
                // 🛡️ FIX-X219: ستون group_key در جدول notifications وجود ندارد —
                // INSERT با آن = PDOException (ایسوی ۲۷). هم‌ترازی با شمای واقعی.
                'scheduled_at' => $scheduledAt,
                'channel'      => 'in_app',
            ]);

            if (!$notifId) {
                throw new \RuntimeException('Notification persistence failed.');
            }

            if ($scheduledAt === null) {
                try {
                    $this->tracker->invalidateUnreadCache($userId);
                } catch (\Throwable $cacheError) {
                    // Cache invalidation must not duplicate an already-persisted notification.
                    $this->logger->warning('notification.unread_cache_invalidation_failed', [
                        'user_id' => $userId,
                        'notification_id' => $notifId,
                        'error' => $cacheError->getMessage(),
                    ]);
                }
            }

            return $notifId;
        } catch (\Throwable $e) {
            $this->logger->error('notification.send_failed', [
                'user_id' => $userId,
                'error'   => $e->getMessage()
            ]);
            // A persistence/infrastructure failure is not a business skip. Re-throw
            // so an outbox delivery can retry and eventually enter the DLQ.
            throw $e;
        }
    }

    /**
     * 🛡️ FIX-S18-8 — گارد action_url برای نویسندهٔ مرکزی in-app:
     *   - مطلق http(s) فقط (فیلتر VALIDATE_URL)
     *   - مسیر نسبی same-site با پیشوند «/» تکی («//host» پروتکل-نسبی رد می‌شود)
     *     — پنل ادمین و لیسنرها مسیرهای داخلی مثل /tickets/show/5 می‌فرستند؛
     *     حفظ رفتارِ pre-S18 برای این جاب (جاب‌های bulk قرارداد سخت‌گیرِ
     *     FIX-S17-7 را دارند و در v22 قفل شده‌اند — تفاوت عمدی و مستند)
     *   - جاوااسکریپت/data:/هر scheme دیگر، بک‌اسلش، whitespace/کنترل‌کاراکتر
     *     (bypass نوع java\tscript:) → null
     */
    private function sanitizeUrl(?string $url): ?string
    {
        if ($url === null || $url === '') {
            return null;
        }
        $url = trim((string)$url);
        if ($url === '' || preg_match('/[\x00-\x1f\x7f]/', $url) === 1) {
            return null;
        }
        if (preg_match('/^https?:\/\//i', $url) === 1) {
            $sanitized = filter_var($url, FILTER_SANITIZE_URL);
            if ($sanitized === false || !filter_var($sanitized, FILTER_VALIDATE_URL)) {
                return null;
            }
            return $sanitized;
        }
        if (
            $url[0] === '/' && ($url[1] ?? '') !== '/'
            && !str_contains($url, '\\')
            && preg_match('/[\s:]/', $url) !== 1
        ) {
            return $url;
        }
        return null;
    }

    /** @param array<string, mixed>|null $data */
    private function resolveIdempotencyKey(?array $data): ?string
    {
        $raw = is_array($data)
            ? ($data['idempotency_key'] ?? ($data['event_id'] ?? ($data['notif_id'] ?? ($data['message_id'] ?? null))))
            : null;

        if (!is_string($raw) && !is_int($raw)) {
            return null;
        }

        $key = trim((string)$raw);
        return $key === '' ? null : mb_substr($key, 0, 128);
    }
}
