<?php

namespace App\Jobs\Notification;

use App\Contracts\JobInterface;
use App\Models\Notification;

class GetUsersBySegmentNotificationJob implements JobInterface
{
    public function __construct(
        private Notification $model
    ) {}

    /**
     * FIX-R69-D1 (O-R69-1 — راند ۶۹، deep-dive اعلان):
     * سازنده پیش‌تر `object $model` بود. سیاست Container برای پارامترهای
     * built-in (شامل `object`) فقط مقدار پیش‌فرض یا nullable را می‌پذیرد —
     * نتیجه: ساخت این جاب همیشه RuntimeException می‌داد و سرویس عمومی
     * NotificationService::getUsersBySegment() ۱۰۰٪ شکست‌خورده بود
     * (بدون فراخوانندهٔ زنده در تولید؛ مین DI برای هر اتصال آینده).
     *
     * اصلاح دو لایه:
     *  ۱) type-hint کلاس Notification — هم‌الگوی جاب‌های همسایه
     *     (RecordClickNotificationJob، FindForUserNotificationJob،
     *     SendToAdminsNotificationJob) که Container بدون مشکل resolve می‌کند.
     *  ۲) واگذاری به حل‌کنندهٔ رسمی سگمنت (chunkUsersBySegment — رفع BUG-04،
     *     امن از OOM با چانک ۵۰۰) به‌جای گارد متدِ همیشه‌نادرستِ
     *     method_exists(getUsersBySegment) که همیشه [] برمی‌گرداند.
     *     نگاشت سگمنت‌ها (all، kyc_…، level_…، new_users، inactive، custom)
     *     همان نگاشت SendToSegmentNotificationJob است.
     *
     * @param array<string, mixed> $filters
     * @return list<int>
     */
    public function handle(string $segment, array $filters = []): array
    {
        $ids = [];
        $this->model->chunkUsersBySegment(
            $segment,
            500,
            static function (array $chunk) use (&$ids): void {
                foreach ($chunk as $id) {
                    $ids[] = (int)$id;
                }
            },
            $filters
        );
        return $ids;
    }
}
