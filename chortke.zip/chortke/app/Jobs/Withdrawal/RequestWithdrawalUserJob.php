<?php

declare(strict_types=1);

namespace App\Jobs\Withdrawal;

use App\Events\WithdrawalCreatedEvent;
use Core\EventDispatcher;
use App\Services\Withdrawal\WithdrawalUserService;

class RequestWithdrawalUserJob
{
    private WithdrawalUserService $userService;
    private EventDispatcher $events;
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;

    public function __construct(
        WithdrawalUserService $userService,
        EventDispatcher $events,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {
        $this->userService = $userService;
        $this->events = $events;
        $this->outbox = $outbox;
    }

    public function handle(int $userId, array $payload): array
    {
        try {
            $result = $this->userService->requestFromUser($userId, $payload);

            $this->outbox?->record('withdrawal', $result['withdrawal_id'], WithdrawalCreatedEvent::class, [
                'user_id' => $userId,
                'withdrawal_id' => $result['withdrawal_id'],
                'amount' => (string)$payload['amount'],
                'currency' => $payload['currency'],
                'status' => 'pending',
            ]);

            return [
                'success' => true,
                'message' => 'درخواست برداشت با موفقیت ثبت شد.',
                'data' => ['withdrawal_id' => $result['withdrawal_id']]
            ];
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'خطا در ثبت درخواست: ' . $e->getMessage()
            ];
        }
    }
}
