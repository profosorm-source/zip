<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

use App\Models\SeoExecution;
use App\Services\Seo\AdsSeoService;
use App\Services\Settings\AppSettings;
use Core\Logger;

/**
 * 🛡️ FIX-R52-T23-12: کرون انقضای اجراهای started رهاشدهٔ سئو.
 *
 * پیشینه (گزارش ماژول ۲۳، یافتهٔ ۱۲ — باقیماندهٔ راند ۵۱): اجرایی که شروع
 * می‌شد ولی هرگز تکمیل نمی‌شد، هیچ انقضایی نداشت ⇒ جایگاه روزِ کاربر
 * (UNIQUE ad_id,user_id,slot_date) تا ابد اشغال می‌ماند (کاربر همان روز
 * نمی‌توانست دوباره همان آگهی را اجرا کند) و در شمارنده‌های سقف می‌ماند.
 *
 * طراحی:
 *   - ساعتِ انقضا از تنظیم «seo_execution_expire_hours» (پیش‌فرض ۲۴؛ ۰ = خاموش).
 *   - انتقال وضعیت با همان AdsSeoService::cancelExecution (CAS: فقط از
 *     status='started'؛ slot_date=NULL آزاد می‌شود؛ rowCount صادق) — هیچ
 *     منطق مالی درگیر نیست: در «شروع» پولی حرکت نمی‌کند (کسر بودجه فقط
 *     هنگام تسویهٔ complete انجام می‌شود) پس انقضا فقط آزادسازی جایگاه است.
 *   - الگوی CronSubmissionsJob: جاب خودکفا با DI کامل؛ نتیجه برای لاگ Kernel
 *     برمی‌گردد. شکست هر ردیف isolat می‌شود (لاگ + ادامه).
 *   - idempotent: سقف ۵۰۰ ردیف در هر اجرا؛ ردیف claim نشده (هم‌زمان تکمیل/
 *     لغو شده) با rowCount=0 نادیده گرفته می‌شود.
 */
class ExpireAbandonedSeoExecutionsJob
{
    private const BATCH_LIMIT = 500;

    public function __construct(
        private readonly SeoExecution $executionModel,
        private readonly AdsSeoService $adsService,
        private readonly AppSettings $appSettings,
        private readonly Logger $logger
    ) {
    }

    /** @return array{success: bool, expired: int} */
    public function handle(): array
    {
        return ['success' => true, 'expired' => $this->expireAbandoned()];
    }

    public function expireAbandoned(): int
    {
        $hours = int_value($this->appSettings->get('seo_execution_expire_hours', 24));
        if ($hours <= 0) {
            return 0; // قرارداد یکسان با سایر تنظیم‌های سقف: ۰ = خاموش
        }

        $rows = $this->executionModel->getAbandonedStarted($hours, self::BATCH_LIMIT);
        $expired = 0;
        foreach ($rows as $row) {
            try {
                // CAS داخل cancelExecution: فقط status='started'؛ slot_date=NULL
                if ($this->adsService->cancelExecution((int)$row->id, "انقضای خودکار اجرای رهاشده ({$hours} ساعت)")) {
                    $expired++;
                }
            } catch (\Throwable $e) {
                $this->logger->error('seo.expire_abandoned_execution_failed', [
                    'execution_id' => (int)($row->id ?? 0),
                    'error'        => $e->getMessage(),
                ]);
            }
        }
        return $expired;
    }
}
