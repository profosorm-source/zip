<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

/**
 * ثبت گزارش تخلف برای آگهی سئو (نسل فعال‌شده — 🛡️ FIX-SEO3-01، تصمیم ۱).
 *
 * زنجیرهٔ کامل (کنترلر/سرویس/جاب) از ابتدا موجود بود ولی روت و UI نداشت
 * (یافتهٔ SEO-23-07: «کامل ولی مرده»). این بچ آن را فعال می‌کند با همان
 * گاردهای مصوب Q4 (SEO-23-12) که در آشتی‌بنی نوامبر از دست رفته بودند:
 *   ۱) آگهی باید type='seo' باشد — ad_id دستکاری‌شده از ماژول دیگر
 *      (social/custom/…) دیگر به‌عنوان seo_task ثبت نمی‌شود.
 *   ۲) گزارش‌دهنده باید اجرای started|completedِ همین آگهی را داشته باشد
 *      (هم‌الگوی SocialTaskService::reportTask — فقط مجری واقعی).
 * کنترلر وب مالکیت اجرا را از URL می‌سنجد؛ این گارد دومِ مستقلِ سمت جاب است.
 */
class ReportSeoTaskJob
{
    private \App\Services\Seo\AdsSeoService $adsService;
    private \App\Services\Interaction\ReportService $reportService;
    private \App\Models\SeoExecution $executions;
    public function __construct(
        \App\Services\Seo\AdsSeoService $adsService,
        \App\Services\Interaction\ReportService $reportService,
        \App\Models\SeoExecution $executions,
        private ?\App\Contracts\LoggerInterface $logger = null
    ) {        $this->adsService = $adsService;
        $this->reportService = $reportService;
        $this->executions = $executions;
}

    /** @return array<string, mixed> */
public function handle(int $reporterId, int $adId, string $reason, string $description = ''): array
    {
        $ad = $this->adsService->getAd($adId);
        if (!$ad) {
            return ['success' => false, 'message' => 'تسک یافت نشد'];
        }

        // 🛡️ FIX-SEO3-01: گیت نوع — فقط آگهی سئو از این کانال گزارش می‌شود.
        if ((string)($ad->type ?? '') !== 'seo') {
            return ['success' => false, 'message' => 'تسک یافت نشد'];
        }

        // 🛡️ FIX-SEO3-01: فقط مجریِ همین تسک (اجرای started یا completed).
        if (!$this->executions->userHasExecutionForAd($reporterId, $adId, ['started', 'completed'])) {
            return ['success' => false, 'message' => 'فقط مجری این تسک می‌تواند گزارش ثبت کند'];
        }

        $trimmedReason = trim($reason);
        $trimmedDescription = trim($description);
        if ($trimmedReason === '') {
            return ['success' => false, 'message' => 'دلیل گزارش الزامی است'];
        }
        // 🛡️ whitelist کلید دلیل + سقف طول توضیح (قبلاً متن آزاد و نامحدود ذخیره می‌شد)
        if (!in_array($trimmedReason, ['site_broken', 'mismatch', 'malware', 'adult', 'other'], true)) {
            return ['success' => false, 'message' => 'دلیل گزارش نامعتبر است'];
        }
        if (mb_strlen($trimmedDescription) > 1000) {
            $trimmedDescription = mb_substr($trimmedDescription, 0, 1000);
        }

        // گزارش تکراری: dedupe کشی ۲۴ساعته منقضی می‌شود؛ پایگاه‌داده مرجع نهایی است
        if ($this->reportService->hasReported($reporterId, 'seo_task', $adId)) {
            return ['success' => false, 'message' => 'شما قبلاً برای این تسک گزارش ثبت کرده‌اید'];
        }

        try {
            $ok = $this->reportService->submit(
                $reporterId,
                'seo_task',
                $adId,
                \App\Enums\ModuleContext::GLOBAL,
                $trimmedReason,
                $trimmedDescription !== '' ? $trimmedDescription : null
            );

            if (!$ok) {
                return ['success' => false, 'message' => 'خطا در ثبت گزارش'];
            }

            // توقف خودکار: رسیدن تعداد گزارش‌دهندگان متمایز به آستانه (۰ = غیرفعال)
            $threshold = (int)config('anti_fraud.seo_report_autopause_threshold', 5);
            if ($threshold > 0 && $this->reportService->getReportCount('seo_task', $adId) >= $threshold) {
                try {
                    if ($this->adsService->pauseForReports($adId)) {
                        $this->logger?->warning('seo_task.auto_paused_by_reports', ['ad_id' => $adId, 'threshold' => $threshold]);
                    }
                } catch (\Throwable $pe) {
                    $this->logger?->error('seo_task.auto_pause_failed', ['ad_id' => $adId, 'error' => $pe->getMessage()]);
                }
            }

            return ['success' => true, 'message' => 'گزارش با موفقیت ثبت شد'];
        } catch (\Throwable $e) {
            // 🛡️ FIX-SEO-23-02: پیام عمومی ثابت — جزئیات فقط در لاگ.
            $this->logger?->error('seo_task.report_failed', [
                'reporter_id' => $reporterId,
                'ad_id' => $adId,
                'error' => $e->getMessage(),
                'exception' => \get_class($e),
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی در ثبت گزارش. لطفاً دوباره تلاش کنید.'];
        }
    }
}
