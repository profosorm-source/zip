<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

class ReportSeoTaskJob
{
    private \App\Services\Seo\AdsSeoService $adsService;
    private \App\Services\Interaction\ReportService $reportService;
    public function __construct(
        \App\Services\Seo\AdsSeoService $adsService,
        \App\Services\Interaction\ReportService $reportService,
        private ?\App\Contracts\LoggerInterface $logger = null
    ) {        $this->adsService = $adsService;
        $this->reportService = $reportService;
}

    /** @return array<string, mixed> */
public function handle(int $reporterId, int $adId, string $reason, string $description = ''): array
    {
        $ad = $this->adsService->getAd($adId);
        if (!$ad) {
            return ['success' => false, 'message' => 'تسک یافت نشد'];
        }

        try {
            $ok = $this->reportService->submit(
                $reporterId,
                'seo_task',
                $adId,
                \App\Enums\ModuleContext::GLOBAL,
                $reason,
                $description
            );

            if (!$ok) {
                return ['success' => false, 'message' => 'خطا در ثبت گزارش'];
            }

            return ['success' => true, 'message' => 'گزارش با موفقیت ثبت شد'];
        } catch (\Throwable $e) {
            // 🛡️ FIX-SEO-23-02: پیام عمومی ثابت — جزئیات فقط در لاگ.
            $this->logger?->error('seo_task.report_failed', [
                'reporter_id' => $reporterId,
                'ad_id' => $adId,
                'error' => $e->getMessage(),
                'exception' => \get_class($e),
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی در ثبت گزارش. لطفاً دوباره تلاش کنید.'];
        }
    }
}
