<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

use App\Models\SeoExecution;

class CompleteSeoTaskJob
{
    // 🛡️ FIX-DEAD-EVENT: وابستگی outbox حذف شد — تنها مصرف‌کننده‌اش رویداد مردهٔ seo.task.completed بود.
    public function __construct(
        private SeoExecution $executionModel,
        private ProcessSeoTaskAsyncJob $processAsyncJob
    ) {}

/**
 * @param array<string, mixed> $engagementData
 * @return array<string, mixed>
 */
public function handle(int $executionId, int $userId, array $engagementData): array
    {
        try {
            $execution = $this->executionModel->findByUser($executionId, $userId);
            if (!$execution) {
                return ['success' => false, 'message' => 'اجرای تسک یافت نشد.'];
            }

            if ((string)$execution->status !== 'started') {
                return ['success' => false, 'message' => 'این تسک در حال پردازش یا قبلاً تکمیل شده است.'];
            }

            $result = $this->processAsyncJob->handle($executionId, $userId, (int)$execution->ad_id, $engagementData);

            // 🛡️ FIX-DEAD-EVENT: رویداد seo.task.completed هیچ listener ای ندارد
            // (پرداخت پاداش داخل ProcessSeoTaskAsyncJob انجام می‌شود و کاربر خودش
            // عمل را آغاز کرده و نتیجه را همان لحظه می‌بیند) → رکورد بی‌اثر حذف شد.

            return $result;
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => 'خطا در تکمیل تسک SEO: ' . $e->getMessage()];
        }
    }
}
