<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

use App\Contracts\LoggerInterface;
use App\Contracts\WalletServiceInterface;
use App\Models\SeoExecution;
use App\Services\AntiFraud\FraudGuardService;
use App\Services\AntiFraud\SeoFraudDetector;
use App\Services\Seo\AdsSeoService;
use App\Services\SeoPayoutService;
use App\Services\Settings\AppSettings;
use Core\EventDispatcher;
use Core\TransactionWrapper;

class ProcessSeoTaskAsyncJob
{
    public function __construct(
        private AdsSeoService $adsService,
        private FraudGuardService $fraudGuard,
        private SeoFraudDetector $fraudDetector,
        private LoggerInterface $logger,
        private SeoPayoutService $payoutService,
        private AppSettings $appSettings,
        private WalletServiceInterface $walletService,
        private EventDispatcher $eventDispatcher,
        private TransactionWrapper $transactionWrapper,
        private SeoExecution $executionModel,
        private ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {}

    public function handle(int $executionId, int $userId, int $adId, array $engagementData): array
    {
        try {
            return $this->transactionWrapper->runWithRetry(function () use ($executionId, $userId, $adId, $engagementData) {
                $execution = $this->executionModel->findByIdForUpdate($executionId);
                if (!$execution || (int)$execution->user_id !== $userId || (int)$execution->ad_id !== $adId) {
                    return ['success' => false, 'message' => 'اجرای تسک یافت نشد.'];
                }

                if ((string)$execution->status !== 'started') {
                    return ['success' => false, 'message' => 'این تسک قبلاً پردازش شده یا قابل تکمیل نیست.'];
                }

                $ad = $this->adsService->getAdForUpdate($adId);
                if (!$ad || (string)$ad->status !== 'active') {
                    return ['success' => false, 'message' => 'آگهی فعال یافت نشد.'];
                }

                if (!isset($engagementData['duration'], $engagementData['scroll_depth'], $engagementData['interactions'])) {
                    $this->adsService->rejectExecution($executionId, 'داده‌های تعامل ناقص است');
                    return ['success' => false, 'message' => 'داده‌های تعامل ناقص است.'];
                }

                $scores = $this->calculateEngagementScore($engagementData, $ad);

                $risk = $this->fraudGuard->checkAction($userId, 'task.seo', [
                    'ad_id'           => (int)$ad->id,
                    'execution_id'    => $executionId,
                    'session_id'      => '',
                    'engagement_data' => $engagementData,
                ]);

                $seoFraud = $risk['details']['seo_fraud'] ?? null;
                $isFraud = is_array($seoFraud) && !empty($seoFraud['is_fraud']);

                if (empty($risk['allowed']) || $isFraud) {
                    $flags = is_array($seoFraud['flags'] ?? null) ? $seoFraud['flags'] : ['blocked_by_security_policy'];
                    $this->adsService->markExecutionAsFraud($executionId, $flags);
                    $this->fraudDetector->addToBlacklist($userId, implode(', ', $flags));
                    $this->logger->warning('seo_task.blocked_by_fraud_guard', [
                        'user_id'      => $userId,
                        'execution_id' => $executionId,
                        'reason'       => $risk['reason'] ?? 'fraud_detected',
                    ]);
                    return ['success' => false, 'message' => 'تعامل شما معتبر تشخیص داده نشد.', 'fraud_detected' => true];
                }

                if ((int)($scores['fraud_score'] ?? 0) >= 85) {
                    $flags = $scores['fraud_flags'] ?? ['seo_severe_behavior_anomaly'];
                    $this->adsService->markExecutionAsFraud($executionId, $flags);
                    return [
                        'success' => false,
                        'message' => 'تعامل شما برای این تسک معتبر تشخیص داده نشد.',
                        'fraud_detected' => true,
                        'score_breakdown' => $scores,
                    ];
                }

                $minScore = (float)($ad->min_score ?? 40);
                if ((float)$scores['final_score'] < $minScore) {
                    $this->adsService->rejectExecution($executionId, "امتیاز کمتر از حد مجاز ({$minScore})", (int)($scores['fraud_score'] ?? 0));
                    return ['success' => false, 'message' => "امتیاز شما ({$scores['final_score']}) کمتر از حداقل مجاز است."];
                }

                $payoutResult = $this->payoutService->calculatePayout((int)$ad->id, (float)$scores['final_score']);
                if (empty($payoutResult['can_pay'])) {
                    $this->adsService->rejectExecution($executionId, (string)($payoutResult['message'] ?? 'امکان پرداخت وجود ندارد'));
                    return ['success' => false, 'message' => $payoutResult['message'] ?? 'امکان پرداخت وجود ندارد.'];
                }

                $payout = (string)$payoutResult['payout'];

                if (!$this->adsService->completeExecution($executionId, $scores, (float)$payout)) {
                    throw new \RuntimeException('این تسک قبلاً تکمیل یا لغو شده است.');
                }

                if (!$this->payoutService->deductFromBudget((int)$ad->id, (float)$payout)) {
                    throw new \RuntimeException('موجودی امانی آگهی کافی نیست.');
                }

                $adCurrency = strtolower((string)($ad->currency ?? $this->appSettings->get('currency_mode', 'irt')));
                if (!in_array($adCurrency, ['irt', 'usdt'], true)) {
                    $adCurrency = 'irt';
                }

                $walletResult = null;
                $escrowService = \Core\Container::getInstance()->make(\App\Services\EscrowService::class);
                $escrow = $escrowService->getByOrder((int)$ad->id, 'seo_ad_budget');
                if ($escrow) {
                    $release = $escrowService->partialRelease((int)$escrow->id, $userId, $payout, 'seo_task_reward_' . $executionId);
                    if (empty($release['ok'])) {
                        throw new \RuntimeException($release['error'] ?? 'خطا در آزادسازی وجه SEO از escrow.');
                    }
                    $walletResult = ['success' => true, 'transaction_id' => 'escrow_seo_release_' . (int)$escrow->id . '_' . $executionId];
                } else {
                    $walletResult = $this->walletService->depositInTransaction(
                        $userId,
                        $payout,
                        $adCurrency,
                        [
                            'source' => 'seo_task_reward',
                            'description' => 'تسک SEO - ' . (string)($ad->title ?? ''),
                            'execution_id' => $executionId,
                            'ad_id' => (int)$ad->id,
                            'idempotency_key' => 'seo_task_reward_' . $executionId,
                        ]
                    );
                }

                if (empty($walletResult['success'])) {
                    throw new \RuntimeException('خطا در واریز پاداش.');
                }

                $userRecord = $this->adsService->getUser($userId);
                if ($userRecord && !empty($userRecord->referred_by)) {
                    $this->outbox?->record('referral', $userId, 'referral.commission.process', [
                        'referrer_id' => (int)$userRecord->referred_by,
                        'amount' => $payout,
                        'currency' => $adCurrency,
                        'source_user_id' => $userId,
                        'context' => [
                            'action' => 'seo_task_reward',
                            'executor_id' => $userId,
                            'execution_id' => $executionId,
                        ],
                    ]);
                }

                return [
                    'success' => true,
                    'message' => 'تسک با موفقیت تایید شد و پاداش واریز گردید.',
                    'payout' => (float)$payout,
                    'score' => (float)$scores['final_score'],
                ];
            });
        } catch (\Throwable $e) {
            $this->logger->error('seo_task.process_failed', [
                'user_id' => $userId,
                'execution_id' => $executionId,
                'ad_id' => $adId,
                'error' => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در پردازش تسک SEO: ' . $e->getMessage()];
        }
    }

    private function calculateEngagementScore(array $data, object $ad): array
    {
        $targetDuration = max(10, (int)($ad->target_duration ?? 60));
        $duration = max(0, min(3600, (int)($data['duration'] ?? 0)));
        $activeTime = max($duration, (int)($data['active_time'] ?? 0));
        $scrollDepth = max(0.0, min(100.0, (float)($data['scroll_depth'] ?? $data['scrollDepth'] ?? 0)));
        $interactions = max(0, (int)($data['interactions'] ?? 0));
        $scrollSpeed = max(0.0, (float)($data['scroll_speed'] ?? ($data['behavior']['scroll_speed'] ?? 0)));
        $mousePattern = (string)($data['mouse_pattern'] ?? ($data['behavior']['mouse_pattern'] ?? 'normal'));
        $pauseCount = max(0, (int)($data['pause_count'] ?? ($data['behavior']['pause_count'] ?? 0)));
        $focusBlurCount = max(0, (int)($data['focus_blur_count'] ?? ($data['behavior']['focus_blur_count'] ?? 0)));
        $clientMode = (string)($data['client_mode'] ?? ($data['behavior']['client_mode'] ?? 'web'));
        $targetOpened = !empty($data['target_opened']) || !empty($data['behavior']['target_opened']);
        $interactionTypes = $data['interaction_types'] ?? ($data['behavior']['interaction_types'] ?? []);
        if (!is_array($interactionTypes)) {
            $interactionTypes = [];
        }
        $interactionTypes = array_values(array_unique(array_map('strval', $interactionTypes)));
        if (in_array('external_open', $interactionTypes, true) || in_array('return_to_task', $interactionTypes, true)) {
            $targetOpened = true;
        }

        $ratio = min(1.0, $duration / max(1, $targetDuration));
        $timeScore = round($ratio * 30.0, 2);

        $scrollScore = match (true) {
            $scrollDepth >= 80 => 25.0,
            $scrollDepth >= 50 => 18.0,
            $scrollDepth >= 20 => 10.0,
            default => 0.0,
        };

        $typeBonus = min(8.0, count($interactionTypes) * 2.0);
        $interactionScore = min(25.0, match (true) {
            $interactions >= 7 => 18.0,
            $interactions >= 4 => 13.0,
            $interactions >= 1 => 7.0,
            default => 0.0,
        } + $typeBonus);

        $qualityScore = 20.0;
        $fraudScore = 0;
        $flags = [];

        if (!$targetOpened) {
            $qualityScore -= 8.0;
            $fraudScore += 15;
            $flags[] = 'target_not_opened';
        }
        if ($duration < max(5, (int)floor($targetDuration * 0.25))) {
            $qualityScore -= 7.0;
            $fraudScore += 30;
            $flags[] = 'too_short_duration';
        }
        if ($scrollSpeed > 5000) {
            $qualityScore -= 7.0;
            $fraudScore += 25;
            $flags[] = 'unnatural_scroll_speed';
        } elseif ($scrollSpeed > 3000) {
            $qualityScore -= 3.0;
            $fraudScore += 10;
            $flags[] = 'high_scroll_speed';
        }
        if ($mousePattern === 'linear') {
            $qualityScore -= 5.0;
            $fraudScore += 15;
            $flags[] = 'linear_mouse_pattern';
        }
        if ($pauseCount < 1 && $duration >= 20) {
            $qualityScore -= 4.0;
            $fraudScore += 10;
            $flags[] = 'no_pause';
        }
        if (count($interactionTypes) < 1) {
            $qualityScore -= 4.0;
            $fraudScore += 10;
            $flags[] = 'no_interaction_type';
        }
        if ($focusBlurCount > 8) {
            $qualityScore -= 4.0;
            $fraudScore += 10;
            $flags[] = 'excessive_focus_switch';
        }
        $qualityScore = max(0.0, $qualityScore);

        $finalScore = max(0.0, min(100.0, $timeScore + $scrollScore + $interactionScore + $qualityScore));
        $fraudScore = max(0, min(100, $fraudScore + (int)(max(0, 40 - $finalScore) / 2)));

        return [
            'time_score' => $timeScore,
            'scroll_score' => $scrollScore,
            'interaction_score' => $interactionScore,
            'quality_score' => round($qualityScore, 2),
            'final_score' => round($finalScore, 2),
            'fraud_score' => (int)round($fraudScore),
            'fraud_flags' => $flags,
            'target_duration' => $targetDuration,
            'engagement_data' => [
                'duration' => $duration,
                'active_time' => $activeTime,
                'target_duration' => $targetDuration,
                'scroll_depth' => $scrollDepth,
                'interactions' => $interactions,
                'scroll_speed' => $scrollSpeed,
                'mouse_pattern' => $mousePattern,
                'pause_count' => $pauseCount,
                'interaction_types' => $interactionTypes,
                'target_opened' => $targetOpened,
                'focus_blur_count' => $focusBlurCount,
                'client_mode' => $clientMode,
            ],
        ];
    }

}
