<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

use App\Contracts\LoggerInterface;
use App\Models\SeoExecution;
use App\Services\AntiFraud\FraudGuardService;
use App\Services\AntiFraud\SeoFraudDetector;
use App\Services\Seo\AdsSeoService;
use App\Services\SeoPayoutService;
use App\Services\Settings\AppSettings;
use Core\EventDispatcher;
use Core\TransactionWrapper;
use Core\ValueObjects\Money;

/**
 * 🛡️ FIX-SEO-FEE-BURN (pre-existing): مثل تسک اجتماعی — کارمزد کمپین‌های
 * SEO قبلاً هرگز جمع نمی‌شد؛ فقط payout از اسکرو partialRelease می‌شد و سهم
 * کارمزد تا انتهای کمپین در اسکرو می‌ماند و موقع بستن به تبلیغ‌دهنده برمی‌گشت.
 * الان کارمزد متناظر هر payout (payout × درصد ذخیره‌شده در رکورد کمپین)
 * قبل از release burn می‌شود (consumeHeldBudget → platform_revenue).
 */
class ProcessSeoTaskAsyncJob
{
    public function __construct(
        private AdsSeoService $adsService,
        private FraudGuardService $fraudGuard,
        private SeoFraudDetector $fraudDetector,
        private LoggerInterface $logger,
        private SeoPayoutService $payoutService,
        private AppSettings $appSettings,
        private TransactionWrapper $transactionWrapper,
        private SeoExecution $executionModel,
        private ?\App\Contracts\OutboxServiceInterface $outbox = null,
        private ?\App\Services\EscrowService $escrowService = null,
        private ?\App\Domain\Financial\Services\FinancialEscrowService $financialEscrow = null
    ) {}

/**
 * @param array<string, mixed> $engagementData
 * @return array<string, mixed>
 */
public function handle(int $executionId, int $userId, int $adId, array $engagementData): array
    {
        try {
            return $this->transactionWrapper->runWithRetry(function () use ($executionId, $userId, $adId, $engagementData) {
                $execution = $this->executionModel->findByIdForUpdate($executionId);
                if (!$execution || (int)$execution->user_id !== $userId || (int)$execution->ad_id !== $adId) {
                    return ['success' => false, 'message' => 'اجرای تسک یافت نشد.'];
                }

                if ((string)$execution->status !== 'started') {
                    return ['success' => false, 'message' => 'این تسک قبلاً پردازش شده یا قابل تکمیل نیست.'];
                }

                $ad = $this->adsService->getAdForUpdate($adId);
                if (!$ad || (string)$ad->status !== 'active') {
                    return ['success' => false, 'message' => 'آگهی فعال یافت نشد.'];
                }

                // 🛡️ FIX-M23R-07 (T23-07 — گیت نوع): تکمیل تسک سئو فقط برای آگهی
                // type=seo — هم‌الگوی گیت شروع (StartSeoTaskJob) و rate/report.
                // قبلاً اجرای شروع‌شده روی آگهی غیرسئو (مسیرهای legacy) تا آخرین
                // لحظه پرداخت پیش می‌رفت و فقط fail-closed بودن escrow می‌ایستاد.
                if ((string)($ad->type ?? '') !== 'seo') {
                    $this->adsService->rejectExecution($executionId, 'این آگهی یک تسک سئو نیست', null, 'not_seo');
                    return ['success' => false, 'message' => 'این آگهی یک تسک سئو نیست.'];
                }

                if (!isset($engagementData['duration'], $engagementData['scroll_depth'], $engagementData['interactions'])) {
                    $this->adsService->rejectExecution($executionId, 'داده‌های تعامل ناقص است', null, 'incomplete_data');
                    return ['success' => false, 'message' => 'داده‌های تعامل ناقص است.'];
                }

                // Root fix (H-10): the payout-driving score must be anchored to a
                // server-observed source, not solely to client-reported metrics.
                // The server authoritatively knows when the execution started, so we
                // (a) reject completions that arrive faster than the required minimum
                // real elapsed time, and (b) clamp the client-reported duration to the
                // real server-measured elapsed time so it cannot be inflated for payout.
                $targetDurationSec = max(10, (int)($ad->target_duration ?? 60));
                $minRealSeconds = max(5, (int)floor($targetDurationSec * 0.25));
                $serverElapsed = $this->executionModel->secondsSinceStart($executionId);
                if ($serverElapsed < $minRealSeconds) {
                    $this->adsService->rejectExecution(
                        $executionId,
                        "زمان واقعی سپری‌شده ({$serverElapsed}s) کمتر از حد مجاز ({$minRealSeconds}s) است",
                        30,
                        'too_fast'
                    );
                    $this->logger->warning('seo_task.server_elapsed_too_short', [
                        'user_id'        => $userId,
                        'execution_id'   => $executionId,
                        'server_elapsed' => $serverElapsed,
                        'min_required'   => $minRealSeconds,
                    ]);
                    return ['success' => false, 'message' => 'زمان کافی روی این تسک سپری نشده است.'];
                }

                // Clamp client-claimed timings to the server-measured elapsed time so a
                // manipulated client cannot inflate the time-based portion of the score.
                $engagementData['duration'] = min(int_value($engagementData['duration'] ?? 0), $serverElapsed);
                if (isset($engagementData['active_time'])) {
                    $engagementData['active_time'] = min(int_value($engagementData['active_time']), $serverElapsed);
                }

                // 🛡️ FIX-SEO-23-01 (فاز ۱ — اثبات سرورمحور کلیک): «باز کردن سایت
                // هدف» دیگر ادعای کلاینت نیست. دکمهٔ باز کردن از ریدایرکت
                // شمارندهٔ سرور (‎/seo/{id}/go/{token}‎) عبور می‌کند و
                // click_counted_at مهرِ سرور است؛ ادعای target_opened و انواعِ
                // تعاملِ «external_open/return_to_task» وقتی مهر وجود ندارد،
                // ادعاهای نادرست‌اند و سرور بازنویسی/حذفشان می‌کند.
                $clickProven = $execution->click_counted_at !== null;
                $behavior = isset($engagementData['behavior']) && is_array($engagementData['behavior'])
                    ? $engagementData['behavior']
                    : [];
                $claimedTypes = isset($engagementData['interaction_types']) && is_array($engagementData['interaction_types'])
                    ? $engagementData['interaction_types']
                    : [];
                $claimedOpened = !empty($engagementData['target_opened'])
                    || !empty($behavior['target_opened'] ?? null)
                    || in_array('external_open', $claimedTypes, true)
                    || in_array('return_to_task', $claimedTypes, true);
                $engagementData['target_opened'] = $clickProven ? 1 : 0;
                $behavior['target_opened'] = $clickProven ? 1 : 0;
                if (!$clickProven) {
                    // این دو type دقیقاً ادعای «باز کردن سایت هدف» هستند — بدون مهر سرور، حذف می‌شوند
                    $engagementData['interaction_types'] = array_values(array_filter(
                        $claimedTypes,
                        static fn($t): bool => $t !== 'external_open' && $t !== 'return_to_task'
                    ));
                    if (is_array($behavior['interaction_types'] ?? null)) {
                        $behavior['interaction_types'] = $engagementData['interaction_types'];
                    }
                }
                $engagementData['behavior'] = $behavior;
                // 🛡️ FIX-SEO-23-SCORE: شواهد سرور (نه ادعای کلاینت) پایهٔ امتیاز تعامل‌اند.
                $engagementData['click_proven'] = $clickProven ? 1 : 0;
                $engagementData['landing_proven'] = $execution->landing_verified_at !== null ? 1 : 0;

                $scores = $this->calculateEngagementScore($engagementData, $ad);
                if (isset($scores['engagement_data']) && is_array($scores['engagement_data'])) {
                    /** @var array<string, mixed> $engData */
                    $engData = $scores['engagement_data'];
                    $engData['click_proven'] = $clickProven; // شواهد ممیزی: مهر سرور در دادهٔ ثبت‌شده
                    // 🛡️ فاز ۲: شاهد فرود (پیکسل/پست‌بک) + پلهٔ نهایی پاداش — ممیزی
                    // پله‌ای بدون حدس‌زدن از روی payout_amount
                    $engData['landing_proven'] = $execution->landing_verified_at !== null;
                    $scores['engagement_data'] = $engData;
                }

                // 🛡️ FIX-SEO-23-01 (فاز ۱): کلاینتِ وب که «باز کردن سایت» را ادعا
                // کرده ولی مهر سرور وجود ندارد ⇒ ادعای متناقض با شاهد سرور — سیگنال
                // قوی دستکاری؛ مثل context_mismatch به امتیاز تقلب اضافه می‌کند.
                // (mobile_app هم دیگر مستثنا نیست: API لینک /seo/{id}/go/{token} را صادر می‌کند.)
                if (!$clickProven && $claimedOpened
                    && in_array(str_value($engagementData['client_mode'] ?? 'web'), ['web', 'mobile_web', 'mobile_app'], true)) {
                    $existingFlags = is_array($scores['fraud_flags'] ?? null) ? $scores['fraud_flags'] : [];
                    $existingFlags[] = 'target_open_claim_unproven';
                    $scores['fraud_flags'] = $existingFlags;
                    $scores['fraud_score'] = min(100, int_value($scores['fraud_score'] ?? 0) + 20);
                    $this->logger->warning('seo_task.target_open_claim_unproven', [
                        'user_id'      => $userId,
                        'execution_id' => $executionId,
                    ]);
                }

                // Root fix (H-10, completion): validate start→complete context continuity
                // on the server side and thread the server-issued session token into the
                // fraud evaluation (evidence binding). A completion arriving from a
                // materially different client context than the one that started the task
                // is a strong manipulation/replay signal, so it raises the server-computed
                // fraud score. Fingerprint is masked (/24 + session + app salt), so a
                // legitimate network change alone stays below the block threshold.
                $currentFingerprint = function_exists('generate_device_fingerprint')
                    ? generate_device_fingerprint()
                    : md5(get_user_agent() . get_client_ip());
                $startFingerprint = (string)($execution->device_fingerprint ?? '');
                $contextMismatch = $startFingerprint !== '' && !hash_equals($startFingerprint, $currentFingerprint);
                if ($contextMismatch) {
                    $existingFlags = is_array($scores['fraud_flags'] ?? null) ? $scores['fraud_flags'] : [];
                    $existingFlags[] = 'context_fingerprint_mismatch';
                    $scores['fraud_flags'] = $existingFlags;
                    $scores['fraud_score'] = min(100, int_value($scores['fraud_score'] ?? 0) + 40);
                    $this->logger->warning('seo_task.context_mismatch', [
                        'user_id'      => $userId,
                        'execution_id' => $executionId,
                    ]);
                }

                $risk = $this->fraudGuard->checkAction($userId, 'task.seo', [
                    'ad_id'            => (int)$ad->id,
                    'execution_id'     => $executionId,
                    'session_id'       => (string)($execution->session_id ?? ''),
                    'engagement_data'  => $engagementData,
                    'context_mismatch' => $contextMismatch,
                    'server_elapsed'   => $serverElapsed,
                ]);

                $riskDetails = $risk['details'];
                $seoFraud = $riskDetails['seo_fraud'] ?? null;
                if (!is_array($seoFraud)
                    || !is_bool($seoFraud['is_fraud'] ?? null)
                    || !is_array($seoFraud['flags'] ?? null)
                    || array_filter($seoFraud['flags'], 'is_string') !== $seoFraud['flags']) {
                    throw new \UnexpectedValueException('FraudGuard violated the task.seo result contract.');
                }
                $isFraud = $seoFraud['is_fraud'];

                // 🛡️ FIX-M23R-05 (T23-05 — تفکیک تقلب از رد سیاستی): قبلاً
                // «هر» allowed=false (حتی بدون هیچ is_fraud) اجرا را fraud
                // می‌کرد و کاربر را blacklist می‌زد — false-positive سیاست، حساب
                // کاربر را می‌بست. اکنون:
                //   • is_fraud=true ⇒ برچسب fraud + blacklist (دقیقاً مثل قبل)؛
                //   • فقط رد سیاستی ⇒ اجرا rejected با دلیل داخلی، بدون blacklist
                //     و بدون برچسب تقلب — پیام کاربر همان می‌ماند.
                if ($isFraud) {
                    $flags = is_array($seoFraud['flags'] ?? null) ? $seoFraud['flags'] : ['blocked_by_security_policy'];
                    $this->adsService->markExecutionAsFraud($executionId, $flags);
                    $this->fraudDetector->addToBlacklist($userId, implode(', ', $flags));
                    $this->logger->warning('seo_task.blocked_by_fraud_guard', [
                        'user_id'      => $userId,
                        'execution_id' => $executionId,
                        'reason'       => $risk['reason'] ?? 'fraud_detected',
                    ]);
                    return ['success' => false, 'message' => 'تعامل شما معتبر تشخیص داده نشد.', 'fraud_detected' => true];
                }

                if (empty($risk['allowed'])) {
                    $this->adsService->rejectExecution($executionId, 'رد توسط سیاست امنیتی (بدون تشخیص تقلب)', null, 'security_policy');
                    $this->logger->warning('seo_task.blocked_by_security_policy', [
                        'user_id'      => $userId,
                        'execution_id' => $executionId,
                        'reason'       => $risk['reason'] ?? 'security_policy',
                    ]);
                    return ['success' => false, 'message' => 'تعامل شما معتبر تشخیص داده نشد.', 'fraud_detected' => false];
                }

                if (int_value($scores['fraud_score'] ?? 0) >= 85) {
                    $flagsData = is_array($scores['fraud_flags'] ?? null) ? $scores['fraud_flags'] : ['seo_severe_behavior_anomaly'];
                    $this->adsService->markExecutionAsFraud($executionId, $flagsData);
                    return [
                        'success' => false,
                        'message' => 'تعامل شما برای این تسک معتبر تشخیص داده نشد.',
                        'fraud_detected' => true,
                        'score_breakdown' => $scores,
                    ];
                }

                $minScore = float_value($ad->min_score ?? 40);
                $finalScore = float_value($scores['final_score'] ?? 0);
                if ($finalScore < $minScore) {
                    $this->adsService->rejectExecution($executionId, "امتیاز کمتر از حد مجاز ({$minScore})", int_value($scores['fraud_score'] ?? 0), 'low_score');
                    return ['success' => false, 'message' => "امتیاز شما ({$finalScore}) کمتر از حداقل مجاز است."];
                }

                $payoutResult = $this->payoutService->calculatePayout(int_value($ad->id), $finalScore);
                if (empty($payoutResult['can_pay'])) {
                    $this->adsService->rejectExecution($executionId, str_value($payoutResult['message'] ?? 'امکان پرداخت وجود ندارد'), null, 'payout_unavailable');
                    return ['success' => false, 'message' => $payoutResult['message'] ?? 'امکان پرداخت وجود ندارد.'];
                }

                $payout = str_value($payoutResult['payout']);

                // 🛡️ FIX-SEO-23-01 (فاز ۲ — پلهٔ پاداش سه‌پله‌ای): همهٔ سیگنال‌های
                // تعامل (scroll/interactions) همچنان ادعای کلاینت‌اند؛ سقف پاداش
                // بر اساس قوی‌ترین شاهدِ سرور پله‌بندی می‌شود (مشخصهٔ مصوب ②):
                //   بدون‌اثبات    → seo_unverified_payout_cap_percent    (پیش‌فرض ۶۰٪ بازه)
                //   کلیک‌اثبات‌شده → seo_click_proven_payout_cap_percent   (پیش‌فرض ۸۵٪ — فاز ۱ ۱۰۰ بود؛
                //                     فاز ۲ پلهٔ فرود اضافه کرد؛ از تنظیمات قابل برگرداندن به ۱۰۰)
                //   فرود‌اثبات‌شده → seo_landing_proven_payout_cap_percent (پیش‌فرض ۱۰۰٪ = فقط بازهٔ آگهی)
                // وعدهٔ صادقانه (④): هیچ رد سختی اضافه نمی‌شود — فقط اقتصاد پله‌ای؛
                // جعلِ پلهٔ فرود نیازمند بارگذاری واقعی صفحه یا راز سرور تبلیغ‌دهنده است.
                $landingProven = $execution->landing_verified_at !== null;
                $payoutTier = !$clickProven ? 'unverified' : ($landingProven ? 'landing_proven' : 'click_proven');
                $capSettingKey = [
                    'unverified'     => 'seo_unverified_payout_cap_percent',
                    'click_proven'   => 'seo_click_proven_payout_cap_percent',
                    'landing_proven' => 'seo_landing_proven_payout_cap_percent',
                ][$payoutTier];
                $capDefault = ['unverified' => 60, 'click_proven' => 85, 'landing_proven' => 100][$payoutTier];
                $unverifiedCapPercent = max(0, min(100, int_value($this->appSettings->get($capSettingKey, $capDefault))));
                $capResult = $this->payoutService->capUnverifiedPayout(
                    $payout,
                    str_value($ad->min_payout ?? '0'),
                    str_value($ad->max_payout ?? '0'),
                    $unverifiedCapPercent
                );
                $payout = str_value($capResult['payout']);
                if (!empty($capResult['capped'])) {
                    $this->logger->info('seo_task.payout_capped_unverified', [
                        'execution_id' => $executionId,
                        'ad_id' => (int)$ad->id,
                        'cap_percent' => $unverifiedCapPercent,
                        'cap_amount' => $capResult['cap_amount'] ?? null,
                        'click_proven' => $clickProven,
                        'landing_proven' => $landingProven,
                        'payout_tier' => $payoutTier,
                    ]);
                }

                if (!$this->adsService->completeExecution($executionId, $scores, $payout)) {
                    throw new \RuntimeException('این تسک قبلاً تکمیل یا لغو شده است.');
                }

                if (!$this->payoutService->deductFromBudget((int)$ad->id, $payout)) {
                    throw new \RuntimeException('موجودی امانی آگهی کافی نیست.');
                }

                $adCurrency = strtolower((string)($ad->currency ?? $this->appSettings->get('currency_mode', 'irt')));
                if (!in_array($adCurrency, ['irt', 'usdt'], true)) {
                    $adCurrency = 'irt';
                }

                $escrowService = $this->escrowService;
                $escrow = $escrowService?->getByOrder((int)$ad->id, 'seo_ad_budget');
                if ($escrow && $escrowService) {
                    // 🛡️ FIX-SEO-FEE-BURN: کارمزد متناظر این payout، قبل از release
                    // burn می‌شود (بعد از release ممکن است اسکرو 'released' شود و
                    // دیگر consumable نباشد). درصد = مقدار قفل‌شده در رکورد کمپین.
                    $advertiserId = (int)($ad->user_id ?? 0);
                    if ($advertiserId <= 0) {
                        throw new \RuntimeException('شناسه تبلیغ‌دهنده برای تسویه کارمزد SEO نامعتبر است.');
                    }
                    $feePercent = $this->seoFeePercent($ad);
                    if (bccomp($feePercent, '0', 8) > 0) {
                        $fee = Money::fromString($payout, $adCurrency)->percentage($feePercent)->getAmount();
                        if (bccomp($fee, '0', 8) > 0) {
                            if ($this->financialEscrow === null) {
                                throw new \RuntimeException('سرویس مالی اسکرو برای تسویه کارمزد SEO در دسترس نیست؛ پرداخت متوقف شد.');
                            }
                            $consume = $this->financialEscrow->consumeHeldBudget(
                                (int)$escrow->id,
                                $advertiserId,
                                $fee,
                                $adCurrency,
                                'کارمزد سایت کمپین SEO',
                                'seo_settlement',
                                \App\Services\Shared\IdempotencyKeys::seoTaskFee($executionId)
                            );
                            if (empty($consume['ok'])) {
                                throw new \RuntimeException(is_string($consume['error'] ?? null) ? $consume['error'] : 'خطا در تسویه کارمزد کمپین SEO.');
                            }
                        }
                    }

                    $release = $escrowService->partialRelease((int)$escrow->id, $userId, $payout, 'پاداش تسک SEO #' . (int)$executionId, \App\Services\Shared\IdempotencyKeys::seoTaskReward((int)$executionId));
                    if (empty($release['ok'])) {
                        throw new \RuntimeException($release['error'] ?? 'خطا در آزادسازی وجه SEO از escrow.');
                    }
                } else {
                    // ── FAIL-CLOSED (تصمیم محصول): بدون escrow پرداختی وجود ندارد ──
                    // شاخه‌ی قبلی برای «کمپین‌های legacy بدون escrow» پول را با
                    // depositInTransaction از هیچ‌جا ضرب می‌کرد (کیف تبلیغ‌دهنده
                    // بی‌تغییر می‌ماند). مسیر زنده‌ی ساخت (AdSystemManager) همیشه
                    // escrow ی seo_ad_budget می‌سازد؛ نبودِ escrow یعنی وضعیت
                    // غیرعادی که باید متوقف و بررسی شود، نه اینکه پول چاپ شود.
                    $this->logger->error('seo_task.payout.no_escrow_fail_closed', [
                        'execution_id' => $executionId,
                        'ad_id' => (int)$ad->id,
                    ]);
                    throw new \RuntimeException('escrow بودجه‌ی کمپین SEO یافت نشد؛ پرداخت متوقف شد (نیازمند بررسی ادمین).');
                }

                // پاداش از طریق EscrowService::partialRelease واریز شده است؛
                // آن متد داخلاً walletService->deposit(seller) را با کلید idempotency
                // صدا می‌زند و مبلغ را از بودجه‌ی قفل‌شده‌ی تبلیغ‌دهنده کسر می‌کند
                // (مسیر قبلیِ walletService مستقیم، پول را از هیچ‌جا واریز می‌کرد).

                $userRecord = $this->adsService->getUser($userId);
                if ($userRecord && !empty($userRecord->referred_by)) {
                    $this->outbox?->record('referral', $userId, 'referral.commission.process', [
                        'referrer_id' => (int)$userRecord->referred_by,
                        'amount' => $payout,
                        'currency' => $adCurrency,
                        'source_user_id' => $userId,
                        'context' => [
                            'action' => 'seo_task_reward',
                            'executor_id' => $userId,
                            'execution_id' => $executionId,
                        ],
                    ]);
                }

                return [
                    'success' => true,
                    'message' => 'تسک با موفقیت تایید شد و پاداش واریز گردید.',
                    'payout' => $payout,
                    // 🛡️ FIX-M23R-10 (T23-10): ارز پاداش در پاسخ — نمایش سمت
                    // کلاینت (userseoexecute.js) دیگر «تومان» هاردکد نمی‌زند.
                    'payout_currency' => $adCurrency,
                    'score' => $finalScore,
                    'payout_capped' => !empty($capResult['capped']),
                ];
            });
        } catch (\Throwable $e) {
            // 🛡️ FIX-SEO-23-02: متن خام استثنا هرگز به پاسخ کاربر نمی‌رسد — پیام
            // عمومی ثابت؛ جزئیات (پیام/کلاس/کد) فقط در لاگ با execution_id همبسته
            // ثبت می‌شود. قبلاً «خطا ...: » + getMessage() از لایه‌های پایین
            // (SQL/PDO، اسکرو، کیف پول) مستقیم در JSON عمومی ظاهر می‌شد.
            $this->logger->error('seo_task.process_failed', [
                'user_id' => $userId,
                'execution_id' => $executionId,
                'ad_id' => $adId,
                'error' => $e->getMessage(),
                'exception' => \get_class($e),
            ]);
            return ['success' => false, 'message' => 'خطا در پردازش تسک سئو. لطفاً دوباره تلاش کنید؛ در صورت تکرار با پشتیبانی تماس بگیرید.'];
        }
    }

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
private function calculateEngagementScore(array $data, object $ad): array
    {
        $targetDuration = max(10, (int)($ad->target_duration ?? 60));
        $duration = max(0, min(3600, int_value($data['duration'] ?? 0)));
        $activeTime = max($duration, int_value($data['active_time'] ?? 0));
        $scrollDepth = max(0.0, min(100.0, float_value($data['scroll_depth'] ?? $data['scrollDepth'] ?? 0)));
        $interactions = max(0, int_value($data['interactions'] ?? 0));
        $behavior = is_array($data['behavior'] ?? null) ? $data['behavior'] : [];
        $scrollSpeed = max(0.0, float_value($data['scroll_speed'] ?? ($behavior['scroll_speed'] ?? 0)));
        $mousePattern = str_value($data['mouse_pattern'] ?? ($behavior['mouse_pattern'] ?? 'normal'));
        $pauseCount = max(0, int_value($data['pause_count'] ?? ($behavior['pause_count'] ?? 0)));
        $focusBlurCount = max(0, int_value($data['focus_blur_count'] ?? ($behavior['focus_blur_count'] ?? 0)));
        $clientMode = str_value($data['client_mode'] ?? ($behavior['client_mode'] ?? 'web'));
        $targetOpened = !empty($data['target_opened']) || !empty($behavior['target_opened']);
        $interactionTypes = $data['interaction_types'] ?? ($behavior['interaction_types'] ?? []);
        if (!is_array($interactionTypes)) {
            $interactionTypes = [];
        }
        // 🛡️ FIX-SEO-23-SCORE: سقف اندازه/طول — آرایهٔ بی‌حدِ ارسالی کلاینت ذخیره نمی‌شود
        $interactionTypes = array_map(static fn($t): string => mb_substr((string)$t, 0, 32), array_slice($interactionTypes, 0, 20));
        $interactionTypes = array_values(array_unique($interactionTypes));
        if (in_array('external_open', $interactionTypes, true) || in_array('return_to_task', $interactionTypes, true)) {
            $targetOpened = true;
        }
        $clickProven = !empty($data['click_proven']);
        $landingProven = !empty($data['landing_proven']);

        $ratio = min(1.0, $duration / max(1, $targetDuration));
        $timeScore = round($ratio * 30.0, 2);

        // 🛡️ FIX-SEO-23-SCORE: از FIX-R12-1 سایت هدف در تب جدید باز می‌شود و کلاینت
        // اسکرول/کلیک آن را نمی‌بیند؛ سیگنال‌های ادعایی همیشه ۰ بودند و کاربر صادق
        // ≈۴۲ می‌گرفت در حالی که ادعای جعلی ۱۰۰ می‌گرفت (انگیزهٔ معکوس). اکنون
        // اسکرول/تعامل از شواهد سرور (مهر کلیک و اثبات فرود) استخراج می‌شود و ادعای
        // کلاینت در امتیاز اثری ندارد (فقط ثبت می‌شود).
        $scrollScore = $landingProven ? 25.0 : ($clickProven ? 18.0 : 0.0);
        $interactionScore = $landingProven ? 18.0 : ($clickProven ? 13.0 : 0.0);

        $qualityScore = 20.0;
        $fraudScore = 0;
        $flags = [];

        if (!$targetOpened) {
            $qualityScore -= 8.0;
            $fraudScore += 15;
            $flags[] = 'target_not_opened';
        }
        if ($duration < max(5, (int)floor($targetDuration * 0.25))) {
            $qualityScore -= 7.0;
            $fraudScore += 30;
            $flags[] = 'too_short_duration';
        }
        if ($scrollSpeed > 5000) {
            $qualityScore -= 7.0;
            $fraudScore += 25;
            $flags[] = 'unnatural_scroll_speed';
        } elseif ($scrollSpeed > 3000) {
            $qualityScore -= 3.0;
            $fraudScore += 10;
            $flags[] = 'high_scroll_speed';
        }
        if ($mousePattern === 'linear') {
            $qualityScore -= 5.0;
            $fraudScore += 15;
            $flags[] = 'linear_mouse_pattern';
        }
        // no_pause / no_interaction_type حذف شد: رفتار تب هدف برای کلاینت قابل مشاهده
        // نیست و کاربر صادق را بی‌دلیل جریمه/مشکوک می‌کرد (FIX-SEO-23-SCORE).
        if ($focusBlurCount > 20) {
            $qualityScore -= 4.0;
            $fraudScore += 10;
            $flags[] = 'excessive_focus_switch';
        }
        $qualityScore = max(0.0, $qualityScore);

        $finalScore = max(0.0, min(100.0, $timeScore + $scrollScore + $interactionScore + $qualityScore));
        $fraudScore = max(0, min(100, $fraudScore + (int)(max(0, 40 - $finalScore) / 2)));

        return [
            'time_score' => $timeScore,
            'scroll_score' => $scrollScore,
            'interaction_score' => $interactionScore,
            'quality_score' => round($qualityScore, 2),
            'final_score' => round($finalScore, 2),
            'fraud_score' => (int)round($fraudScore),
            'fraud_flags' => $flags,
            'target_duration' => $targetDuration,
            'engagement_data' => [
                'duration' => $duration,
                'active_time' => $activeTime,
                'target_duration' => $targetDuration,
                'scroll_depth' => $scrollDepth,
                'interactions' => $interactions,
                'scroll_speed' => $scrollSpeed,
                'mouse_pattern' => $mousePattern,
                'pause_count' => $pauseCount,
                'interaction_types' => $interactionTypes,
                'target_opened' => $targetOpened,
                'focus_blur_count' => $focusBlurCount,
                'client_mode' => $clientMode,
            ],
        ];
    }

    /**
     * 🛡️ FIX-SEO-FEE-BURN — درصد کارمزد کمپین: اول site_commission_percent
     * ذخیره‌شده روی رکورد (که آداپتر هنگام ساخت — یا کوپن هنگام تخفیف —
     * نوشته)، وگرنه تنظیم رسمی seo_ad_site_fee_percent با پیش‌فرض ۱۵
     * (همان SeoAdAdapter::calculateCost).
     */
    private function seoFeePercent(object $ad): string
    {
        $stored = $ad->site_commission_percent ?? null;
        if (is_scalar($stored) && is_numeric((string)$stored) && bccomp((string)$stored, '0', 8) >= 0) {
            return (string)$stored;
        }
        $setting = $this->appSettings->get('seo_ad_site_fee_percent', 15) ?? 15;
        return is_numeric($setting) ? str_value($setting) : '15';
    }

}
