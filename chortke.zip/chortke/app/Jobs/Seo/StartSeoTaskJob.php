<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

class StartSeoTaskJob
{
    private \Core\TransactionWrapper $transactionWrapper;
    private \App\Services\Seo\AdsSeoService $adsService;
    private \App\Services\Settings\AppSettings $appSettings;
    private \App\Contracts\LoggerInterface $logger;
    public function __construct(
        \Core\TransactionWrapper $transactionWrapper,
        \App\Services\Seo\AdsSeoService $adsService,
        \App\Services\Settings\AppSettings $appSettings,
        \App\Contracts\LoggerInterface $logger
    ) {        $this->transactionWrapper = $transactionWrapper;
        $this->adsService = $adsService;
        $this->appSettings = $appSettings;
        $this->logger = $logger;
}

    /** @return array<string, mixed> */
public function handle(int $adId, int $userId): array
    {
        try {
            return $this->transactionWrapper->runWithRetry(function() use ($adId, $userId) {
                // قفل کردن آگهی برای جلوگیری از Race Condition
                $ad = $this->adsService->getAdForUpdate($adId);
                
                if (!$ad) {
                    return ['success' => false, 'message' => 'آگهی یافت نشد'];
                }
        
                if ($ad->status !== 'active') {
                    return ['success' => false, 'message' => 'آگهی فعال نیست'];
                }

                // 🛡️ FIX-M23R-07 (T23-07 — گیت نوع): شروع تسک سئو فقط برای آگهی
                // type=seo. قبلاً هر آگهیِ active از هر ماژولی را می‌شد به‌عنوان
                // تسک سئو «شروع» کرد و فقط fail-closed بودن escrow جلوی پرداخت را
                // می‌گرفت (ردیف‌های زائد + وابستگی به rollback). هم‌الگوی گیت
                // RateSeoTaskJob/ReportSeoTaskJob که از بچ قبل فقط به rate/report
                // اضافه شده بود.
                if ((string)($ad->type ?? '') !== 'seo') {
                    return ['success' => false, 'message' => 'این آگهی یک تسک سئو نیست.'];
                }

                if ((int)($ad->user_id ?? 0) === $userId) {
                    return ['success' => false, 'message' => 'امکان اجرای تسک SEO خودتان وجود ندارد.'];
                }

                // 🛡️ FIX-M23R-03 (T23-03 — حذف کف ۱٫۰): قبلاً max(1.0, min_payout)
                // کمپین‌های USDT با پاداش کمتر از ۱ را همیشه «بودجه تمام شده»
                // می‌کرد (ولی آگهی active می‌ماند). مرزِ واقعی همان min_payoutِ
                // آگهی است (با fallback به price_per_click) و مقایسه bccomp روی
                // رشتهٔ decimal بدون گذر از float (هم‌سیاست FIX-Q4-SEO23-09).
                $minPayoutRaw = trim((string)($ad->min_payout ?? ''));
                if ($minPayoutRaw === '' || !is_numeric($minPayoutRaw)) {
                    $fallbackRaw = trim((string)($ad->price_per_click ?? ''));
                    $minPayoutRaw = ($fallbackRaw !== '' && is_numeric($fallbackRaw)) ? $fallbackRaw : '0';
                }
                $remainingBudget = (string)($ad->remaining_budget ?? '0');
                if (!is_numeric($remainingBudget)) {
                    $remainingBudget = '0';
                }
                if (bccomp($remainingBudget, $minPayoutRaw, 8) < 0) {
                    return ['success' => false, 'message' => 'بودجه آگهی تمام شده است'];
                }
        
                // بررسی تکراری (🛡️ FIX-Q4-SEO23-04: فقط اجراهای started/completed
                // مانع تکرارند — لغو، امکان شروع مجدد همان روز را برمی‌گرداند)
                if ($this->adsService->executionExistsToday($adId, $userId)) {
                    return ['success' => false, 'message' => 'شما امروز این تسک را قبلاً انجام داده‌اید'];
                }

                // 🛡️ FIX-M23R-02 (T23-02 — سقف روزانهٔ کمپین): قبلاً سقف
                // max_per_day با شمارشِ «اجراهای همین کاربر روی همین آگهی» سنجیده
                // می‌شد؛ گیت یک‌بار-در-روزِ بالا (executionExistsToday) همان شمارش
                // را همیشه ۰/۱ نگه می‌داشت و شرط هرگز برقرار نمی‌شد — سقفِ کمپین
                // عملاً وجود نداشت و بودجه بدون کنترل سرعت مصرف می‌شد. اکنون
                // «کل اجراهای امروزِ همین آگهی» (همهٔ کاربران، started/completed)
                // زیر همین قفلِ آگهی شمرده می‌شود — معنای واقعی ستون max_per_day.
                // ۱) سقف روزانهٔ «همین کمپین» (معنای واقعی ستون max_per_day):
                $adDailyCount = $this->adsService->countAdExecutionsToday($adId);
                $adMaxPerDay = (int)($ad->max_per_day ?? 10);
                if ($adMaxPerDay > 0 && $adDailyCount >= $adMaxPerDay) {
                    return ['success' => false, 'message' => "امروز سقف {$adMaxPerDay} اجرا برای این کمپین پر شده است"];
                }
                // ۲) سقف روزانهٔ سراسری کاربر از تنظیمات (جدید؛ پیش‌فرض ۱۰ مثل قبلی):
                $userDailyLimit = int_value($this->appSettings->get('seo_max_tasks_per_day', 10));
                if ($userDailyLimit > 0) {
                    $userTodayCount = $this->adsService->countUserExecutionsToday($userId);
                    if ($userTodayCount >= $userDailyLimit) {
                        return ['success' => false, 'message' => "حداکثر {$userDailyLimit} تسک سئو در روز مجاز است"];
                    }
                }
        
                // بررسی محدودیت ساعتی
                // 🛡️ FIX-M23R-12 (T23-12 — معنای ۰ یکدست): سقف روزانهٔ کاربر بالا
                // گارد «>0 یعنی فعال، 0/منفی یعنی نامحدود» دارد؛ ساعتی و IP همین
                // قرارداد را می‌گیرند — قبلاً مقدار ۰ یعنی «همه برای همیشه بسته»
                // بود (ناسازگار با سقف روزانه و با مستندات تنظیمات).
                $hourlyLimit = int_value($this->appSettings->get('seo_max_tasks_per_hour', 5));
                $hourlyCount = $this->adsService->countUserExecutionsLastHour($userId);
                if ($hourlyLimit > 0 && $hourlyCount >= $hourlyLimit) {
                    return ['success' => false, 'message' => "حداکثر {$hourlyLimit} تسک در ساعت مجاز است. لطفاً کمی صبر کنید"];
                }
        
                // بررسی IP
                $ip = get_client_ip();
                $ipLimit = int_value($this->appSettings->get('seo_max_ip_tasks_per_hour', 10));
                $ipHourly = $this->adsService->countIpExecutionsLastHour($ip);
                if ($ipLimit > 0 && $ipHourly >= $ipLimit) {
                    return ['success' => false, 'message' => 'محدودیت IP. لطفاً بعداً تلاش کنید'];
                }
        
                $fingerprint = function_exists('generate_device_fingerprint') 
                    ? generate_device_fingerprint() 
                    : md5(get_user_agent() . $ip);
    
                $sessionId = bin2hex(random_bytes(16));
    
                $executionId = $this->adsService->createExecution([
                    'ad_id' => $adId,
                    'user_id' => $userId,
                    'session_id' => $sessionId,
                    'status' => 'started',
                    'ip_address' => $ip,
                    'device_fingerprint' => $fingerprint,
                    'started_at' => date('Y-m-d H:i:s'),
                    'target_keyword' => $ad->keyword,
                ]);

                if (!$executionId) {
                    throw new \RuntimeException('خطا در ایجاد رکورد اجرای تسک.');
                }
    
                return [
                    'success' => true,
                    'message' => 'تسک SEO شروع شد.',
                    'execution_id' => (int)$executionId,
                    'execution' => ['id' => (int)$executionId],
                    'session_id' => $sessionId,
                ];
            });
        } catch (\Exception $e) {
            $this->logger->error('seo_task.start_failed', ['error' => $e->getMessage()]);
            // 🛡️ FIX-X194: تشخیص duplicate فقط برای PDOException واقعی (SQLSTATE 23000 /
            // خطای 1062) — نه بوسی متن پیام هر استثنایی؛ قبلاً هر خطایی که در متنش
            // «1062/Duplicate entry» داشت پیام گمراه‌کنندهٔ «قبلاً انجام داده‌اید» می‌دید.
            $pdo = $e instanceof \PDOException ? $e : ($e->getPrevious() instanceof \PDOException ? $e->getPrevious() : null);
            $sqlState = (string)($pdo->errorInfo[0] ?? '');
            $drvCode  = (string)($pdo->errorInfo[1] ?? '');
            $isDuplicate = $pdo !== null
                && ((string)$pdo->getCode() === '23000' || $sqlState === '23000' || $drvCode === '1062' || $drvCode === '1586');
            if ($isDuplicate) {
                return ['success' => false, 'message' => 'شما امروز این تسک را قبلاً انجام داده‌اید'];
            }
            return ['success' => false, 'message' => 'خطای سیستمی'];
        }
    }
}
