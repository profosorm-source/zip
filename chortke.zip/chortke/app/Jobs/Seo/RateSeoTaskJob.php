<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

class RateSeoTaskJob
{
    private \App\Services\Seo\AdsSeoService $adsService;
    private \App\Services\Interaction\RatingService $ratingService;
    public function __construct(
        \App\Services\Seo\AdsSeoService $adsService,
        \App\Services\Interaction\RatingService $ratingService,
        private ?\App\Contracts\LoggerInterface $logger = null
    ) {        $this->adsService = $adsService;
        $this->ratingService = $ratingService;
}

    /** @return array<string, mixed> */
public function handle(int $raterId, int $adId, int $stars, string $comment = ''): array
    {
        $ad = $this->adsService->getAd($adId);
        if (!$ad) {
            return ['success' => false, 'message' => 'تسک یافت نشد'];
        }

        $stars = max(1, min(5, $stars));

        try {
            // FIX-R15C: کامنت به لایهٔ rating منتقل شد (قبلاً drop می‌شد)
            $ok = $this->ratingService->rate(
                $raterId,
                'seo_task',
                $adId,
                \App\Enums\ModuleContext::GLOBAL,
                $stars,
                $comment
            );

            if (!$ok) {
                return ['success' => false, 'message' => 'خطا در ثبت امتیاز'];
            }

            return ['success' => true, 'message' => 'امتیاز با موفقیت ثبت شد'];
        } catch (\Throwable $e) {
            // 🛡️ FIX-SEO-23-02: پیام عمومی ثابت — جزئیات فقط در لاگ.
            $this->logger?->error('seo_task.rate_failed', [
                'rater_id' => $raterId,
                'ad_id' => $adId,
                'error' => $e->getMessage(),
                'exception' => \get_class($e),
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی در ثبت امتیاز. لطفاً دوباره تلاش کنید.'];
        }
    }
}
