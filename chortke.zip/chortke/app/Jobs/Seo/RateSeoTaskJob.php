<?php

declare(strict_types=1);

namespace App\Jobs\Seo;

/**
 * ثبت امتیاز (۱..۵ ستاره) برای آگهی سئو (نسل فعال‌شده — 🛡️ FIX-SEO3-01، تصمیم ۱).
 *
 * زنجیرهٔ کامل از ابتدا موجود بود ولی روت و UI نداشت (SEO-23-07). این بچ با
 * گاردهای مصوب Q4 (SEO-23-12) فعالش می‌کند — قرینهٔ SocialTaskService::rateTask:
 *   ۱) آگهی باید type='seo' باشد (گیت نوع — ad_id ماژول دیگر رد می‌شود).
 *   ۲) مالک کمپین به تسک خودش امتیاز نمی‌دهد (تضاد منافع/تورم امتیاز).
 *   ۳) فقط مجریِ اجرای «completed»ٔ همین آگهی حق امتیاز دارد (نه لغوشده/ردشده).
 * امتیاز نمایش داده می‌شود: کارت فهرست آگهی‌ها، جزئیات تبلیغ‌دهنده و API.
 */
class RateSeoTaskJob
{
    private \App\Services\Seo\AdsSeoService $adsService;
    private \App\Services\Interaction\RatingService $ratingService;
    private \App\Models\SeoExecution $executions;
    public function __construct(
        \App\Services\Seo\AdsSeoService $adsService,
        \App\Services\Interaction\RatingService $ratingService,
        \App\Models\SeoExecution $executions,
        private ?\App\Contracts\LoggerInterface $logger = null
    ) {        $this->adsService = $adsService;
        $this->ratingService = $ratingService;
        $this->executions = $executions;
}

    /** @return array<string, mixed> */
public function handle(int $raterId, int $adId, int $stars, string $comment = ''): array
    {
        $ad = $this->adsService->getAd($adId);
        if (!$ad) {
            return ['success' => false, 'message' => 'تسک یافت نشد'];
        }

        // 🛡️ FIX-SEO3-01: گیت نوع — فقط آگهی سئو از این کانال امتیاز می‌گیرد.
        if ((string)($ad->type ?? '') !== 'seo') {
            return ['success' => false, 'message' => 'تسک یافت نشد'];
        }

        // 🛡️ FIX-SEO3-01 (هم‌الگوی S27D-F3): تضاد منافع — مالک کمپین نمی‌تواند
        // به کمپین خودش امتیاز بدهد.
        if ((int)($ad->user_id ?? 0) === $raterId) {
            return ['success' => false, 'message' => 'امتیاز دادن به تسک خودتان مجاز نیست'];
        }

        // 🛡️ FIX-SEO3-01: فقط مجریِ اجرای تکمیل‌شده (نه اجرای لغوشده/ردشده).
        if (!$this->executions->userHasExecutionForAd($raterId, $adId, ['completed'])) {
            return ['success' => false, 'message' => 'فقط مجریِ اجرای تکمیل‌شده می‌تواند به این تسک امتیاز بدهد'];
        }

        $stars = max(1, min(5, $stars));

        try {
            // FIX-R15C: کامنت به لایهٔ rating منتقل شد (قبلاً drop می‌شد)
            $ok = $this->ratingService->rate(
                $raterId,
                'seo_task',
                $adId,
                \App\Enums\ModuleContext::GLOBAL,
                $stars,
                $comment
            );

            if (!$ok) {
                return ['success' => false, 'message' => 'ثبت امتیاز انجام نشد؛ اگر همین الان امتیاز داده‌اید، یک دقیقه صبر کنید و دوباره تلاش کنید'];
            }

            return ['success' => true, 'message' => 'امتیاز با موفقیت ثبت شد'];
        } catch (\Throwable $e) {
            // 🛡️ FIX-SEO-23-02: پیام عمومی ثابت — جزئیات فقط در لاگ.
            $this->logger?->error('seo_task.rate_failed', [
                'rater_id' => $raterId,
                'ad_id' => $adId,
                'error' => $e->getMessage(),
                'exception' => \get_class($e),
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی در ثبت امتیاز. لطفاً دوباره تلاش کنید.'];
        }
    }
}
