<?php

declare(strict_types=1);

namespace App\Jobs\Payment;

use App\Services\Payment\PaymentCommandService;
use App\Contracts\LoggerInterface;

class ProcessPaymentCallbackJob
{
    public function __construct(
        private PaymentCommandService $paymentService,
        private LoggerInterface $logger
    ) {}

/**
 * @param array<string, mixed> $callbackData
 * @return array<string, mixed>
 */
public function handle(string $gatewayName, array $callbackData, ?int $sessionUserId = null, string $clientIp = '', string $userAgent = '', bool $isInternal = false): array
    {
        try {
            // FIX-R18-M2b: $isInternal برای مسیر server-to-server (کرون reconcile) —
            // دورزدن rate-limit/whitelistِ عمومی فقط برای این مسیر داخلی.
            return $this->paymentService->callback($gatewayName, $callbackData, $sessionUserId, $clientIp, $userAgent, $isInternal);
        } catch (\Throwable $e) {
            $this->logger->error('payment.callback.job.failed', [
                'gateway' => $gatewayName,
                'error' => $e->getMessage()
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی در پردازش بازگشت پرداخت'];
        }
    }
}

