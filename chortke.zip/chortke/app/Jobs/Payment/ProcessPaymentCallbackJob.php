<?php

declare(strict_types=1);

namespace App\Jobs\Payment;

use App\Services\Payment\PaymentCommandService;
use App\Contracts\LoggerInterface;

/**
 * FIX-R36-W3 (F-A17-04) — قرارداد شکست مستندشده (premise اصلاح شد):
 *
 * 1) «جاب مرده» نیست: فراخوان زندهٔ sync دارد — ReconcilePaymentsJob:93 هر
 *    پرداخت stuck را از این‌جا عبور می‌دهد. بلعِ catch زیر **قرارداد طراحی‌شدهٔ
 *    همان حلقه است**: success:false ⇒ reconcile شمارندهٔ retry را بالا می‌برد و
 *    در سقف ۵ تلاش، terminal-failure + هشدار ادمین (FIX-R18-M2a/M-05) می‌نویسد.
 *    rethrow کردن این‌جا مسیر retry/alert را می‌شکند — عمداً انجام نشد.
 * 2) خطِ صف (allowlist config/queue.php): امضای handle چندآرگومانی با payload
 *    صف سازگار نیست؛ push فرضی → TypeError → بلافاصله dead-letter (پولی از دست
 *    نمی‌رود، فقط DLQ noise). این کلاس هرگز نباید به صف وصل شود — پیشنهاد:
 *    حذفِ آگاهانهٔ entry از allowlist + خود کلاس در یک پاسِ پاک‌سازی آینده
 *    (deletion در این موج ممنوع بود).
 */
class ProcessPaymentCallbackJob
{
    public function __construct(
        private PaymentCommandService $paymentService,
        private LoggerInterface $logger
    ) {}

/**
 * @param array<string, mixed> $callbackData
 * @return array<string, mixed>
 */
public function handle(string $gatewayName, array $callbackData, ?int $sessionUserId = null, string $clientIp = '', string $userAgent = '', bool $isInternal = false): array
    {
        try {
            // FIX-R18-M2b: $isInternal برای مسیر server-to-server (کرون reconcile) —
            // دورزدن rate-limit/whitelistِ عمومی فقط برای این مسیر داخلی.
            return $this->paymentService->callback($gatewayName, $callbackData, $sessionUserId, $clientIp, $userAgent, $isInternal);
        } catch (\Throwable $e) {
            $this->logger->error('payment.callback.job.failed', [
                'gateway' => $gatewayName,
                'error' => $e->getMessage()
            ]);
            return ['success' => false, 'message' => 'خطای سیستمی در پردازش بازگشت پرداخت'];
        }
    }
}

