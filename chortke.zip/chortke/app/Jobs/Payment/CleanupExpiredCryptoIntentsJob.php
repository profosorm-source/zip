<?php

declare(strict_types=1);

namespace App\Jobs\Payment;

class CleanupExpiredCryptoIntentsJob
{
    public function __construct(
        
    ) {}

    public function handle(): int
    {
        // TODO: Implement via CryptoDepositService::cleanupExpiredIntents()
        // This job previously had infinite recursion (calling itself via Container).
        return 0;
    }
}
