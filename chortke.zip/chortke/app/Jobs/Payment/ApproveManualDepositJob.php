<?php

declare(strict_types=1);

namespace App\Jobs\Payment;

use App\Services\Payment\PaymentService;
use App\Contracts\LoggerInterface;

class ApproveManualDepositJob
{
    public function __construct(
        private PaymentService $paymentService,
        private LoggerInterface $logger
    ) {}

    /** @return array<string, mixed> */
public function handle(int $depositId, int $adminId): array
    {
        try {
            return $this->paymentService->approveManualDeposit($depositId, $adminId);
        } catch (\Throwable $e) {
            $this->logger->error('manual_deposit.job.failed', ['id' => $depositId, 'error' => $e->getMessage()]);
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
