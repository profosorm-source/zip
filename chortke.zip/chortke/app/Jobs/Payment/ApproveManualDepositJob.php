<?php

declare(strict_types=1);

namespace App\Jobs\Payment;

use App\Services\Payment\PaymentService;
use App\Contracts\LoggerInterface;

class ApproveManualDepositJob
{
    public function __construct(
        private PaymentService $paymentService,
        private LoggerInterface $logger
    ) {}

    public function handle(int $depositId, int $adminId): array
    {
        try {
            return $this->paymentService->approveManualDeposit($depositId, $adminId);
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->logger->error('manual_deposit.job.failed', ['id' => $depositId, 'error' => $e->getMessage()]);
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
