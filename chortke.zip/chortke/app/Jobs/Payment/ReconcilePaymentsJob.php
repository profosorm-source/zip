<?php

declare(strict_types=1);

namespace App\Jobs\Payment;

class ReconcilePaymentsJob
{
    private \Core\Database $db;
    private \App\Contracts\LoggerInterface $logger;
    private \App\Models\PaymentLog $log;
    private \App\Jobs\Payment\ProcessPaymentCallbackJob $processPaymentCallbackJob;
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;
    public function __construct(
        \Core\Database $db,
        \App\Contracts\LoggerInterface $logger,
        \App\Models\PaymentLog $log,
        \App\Jobs\Payment\ProcessPaymentCallbackJob $processPaymentCallbackJob,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {        $this->db = $db;
        $this->logger = $logger;
        $this->log = $log;
        $this->processPaymentCallbackJob = $processPaymentCallbackJob;
        $this->outbox = $outbox;
}

    /** @return array<string, mixed> */
public function handle(): array
    {
        $results = ['total' => 0, 'completed' => 0, 'failed' => 0, 'skipped' => 0];

        try {
            $stuckPayments = $this->db->query(
                "SELECT * FROM payment_logs 
                 WHERE status = 'pending' 
                   AND created_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE)
                 ORDER BY created_at ASC LIMIT 50"
            )->fetchAll(\PDO::FETCH_OBJ) ?: [];

            foreach ($stuckPayments as $pay) {
                $results['total']++;
                
                $responseData = @(array)(json_decode($pay->response_data ?? '{}', true) ?? []) ?: [];
                $retryCount = int_value($responseData['retry_count'] ?? 0);

                if ($retryCount >= 5) {
                    $responseData['error_message'] = 'Max retry attempts reached (skipped)';
                    // FIX-R18-M2a: نوشتن قطعی failed هرگز روی completed/verified نمی‌نشیند.
                    $this->writeTerminalFailure((int)$pay->id, $responseData);
                    $results['skipped']++;
                    continue;
                }

                $responseData['retry_count'] = $retryCount + 1;
                $responseData['last_retry_at'] = date('Y-m-d H:i:s');

                // M-05 FIX (root cause): read-modify-write on retry_count with no lock meant two
                // reconciler runs (cron overlap / multiple workers) both read the same counter and
                // both re-processed the SAME pending payment. The counter bump is now an atomic
                // compare-and-swap: the row is only claimed if it is still `pending` AND still at
                // the retry_count we observed, so exactly one worker proceeds per attempt.
                $claimed = $this->db->execute(
                    "UPDATE payment_logs SET response_data = ?, updated_at = NOW()
                      WHERE id = ? AND status = 'pending'
                        AND COALESCE(
                              CAST(JSON_UNQUOTE(JSON_EXTRACT(response_data, '$.retry_count')) AS UNSIGNED),
                              0
                            ) = ?",
                    [json_encode($responseData, JSON_UNESCAPED_UNICODE), (int)$pay->id, $retryCount]
                );

                if ($claimed !== 1) {
                    $results['skipped']++;
                    $this->logger->info('payment.reconciliation.claim_skipped', [
                        'payment_id' => (int)$pay->id,
                    ]);
                    continue;
                }

                try {
                    $storedRequestData = @(array)(json_decode($pay->request_data ?? '', true) ?? []) ?: [];
                    $storedNonce = str_value($storedRequestData['callback_nonce'] ?? '');

                    // M-05 FIX (root cause): reconciliation used to FABRICATE a successful gateway
                    // response ('status' => 'OK'). That is gateway data the system never received,
                    // and it made the callback path treat an unknown payment as user-confirmed.
                    // No status is injected any more: the callback pipeline decides purely from the
                    // authoritative server-to-server verifyPayment() inquiry, which is exactly what
                    // reconciliation is supposed to rely on.
                    // FIX-R18-M2b: isInternal=true — این فراخوان server-to-server از کرون است؛
                    // بدون این فلگ، IPِ CLI هرگز با whitelist تولید مطابقت نمی‌کرد و reconcile
                    // واقعی در production همیشه «دسترسی غیرمجاز» می‌گرفت.
                    $res = $this->processPaymentCallbackJob->handle((string)$pay->gateway, [
                        'authority' => (string)$pay->authority,
                        'nonce' => $storedNonce,
                    ], (int)$pay->user_id, '', '', true);

                    if (!empty($res['success'])) {
                        $results['completed']++;
                    } else {
                        $results['failed']++;
                        
                        // If it has now been retried 5 times, mark as failed strictly and alert admin
                        if ($retryCount >= 4) {
                            $responseData['error_message'] = 'Max retry attempts reached';
                            // FIX-R18-M2a: پیش از نوشتن قطعی status='failed'، وضعیتِ فعلی زیر
                            // قلب (FOR UPDATE داخل تراکنش) دوباره خوانده می‌شود؛ callback موازی
                            // می‌تواند در همین فاصله پرداخت را تکمیل/وریفای کرده باشد و نوشتن
                            // failed روی ردیف completed/verified اثر مالی موفق را از بین می‌برد.
                            if (!$this->writeTerminalFailure((int)$pay->id, $responseData)) {
                                continue;
                            }
                            
                            // 🛡️ FIX-DEAD-EVENT-ADMIN-ALERT (P0 — pre-existing): رویداد
                            // admin_notification.requested هیچ listener و مسیر پردازشی ندارد
                            // → خطای بحرانی «۵ بار تلاش ناموفق پرداخت» هرگز به ادمین‌ها
                            // گزارش نمی‌شد.
                            // 🛡️ FIX-S18-6N (S18.6 — وحدت اعلان‌ها): شکل RPC قدیمی حذف شد؛
                            // هشدار ادمین از درِ واحد notification.requested (target=admins).
                            $this->outbox?->record('payment_review', (int)$pay->id, 'notification.requested', [
                                'target'     => 'admins',
                                'type'       => 'payment_failed_max_retries',
                                'title'      => 'خطای بحرانی پرداخت',
                                'message'    => "پرداخت شماره {$pay->id} پس از ۵ بار تلاش ناموفق بود. کاربر: {$pay->user_id}، مبلغ: {$pay->amount}",
                                'data'       => [
                                    'payment_id' => (int)$pay->id,
                                    'user_id'    => (int)$pay->user_id,
                                    'amount'     => $pay->amount,
                                    'action_url' => '/admin/payments/review?id=' . (int)$pay->id,
                                    'action_text' => 'بررسی پرداخت',
                                ],
                                'priority'   => 'urgent',
                            ]);
                        }
                    }
                } catch (\Throwable $innerEx) {
                    if ($this->db->inTransaction()) {
                        $this->db->rollback();
                    }
                    $results['failed']++;
                    $this->logger->error('payment.reconciliation.inner_failed', [
                        'payment_id' => $pay->id,
                        'error' => $innerEx->getMessage()
                    ]);
                }
            }
        } catch (\Throwable $e) {
            $this->logger->error('payment.reconciliation.failed', [
                'error' => $e->getMessage()
            ]);
        }

        return $results;
    }

    /**
     * FIX-R18-M2a: نوشتن قطعی status='failed' با گارد re-check زیر قلب.
     *
     * وضعیت فعلی ردیف داخل یک تراکنش کوتاه با FOR UPDATE خوانده می‌شود؛ اگر ردیف
     * در همین فاصله completed/verified شده باشد (callback موازی/مسیر ادمین)،
     * هیچ نوشتنی انجام نمی‌شود و false برمی‌گردد — ردیف موفق هرگز failed نمی‌شود.
     *
     * @param array<string, mixed> $responseData
     */
    private function writeTerminalFailure(int $paymentId, array $responseData): bool
    {
        $result = $this->db->transactional(function () use ($paymentId, $responseData) {
            $current = $this->db->fetch(
                "SELECT status FROM payment_logs WHERE id = ? FOR UPDATE",
                [$paymentId]
            );
            $status = (string)($current->status ?? '');
            if (in_array($status, ['completed', 'verified'], true)) {
                $this->logger->warning('payment.reconciliation.terminal_failed_prevented', [
                    'payment_id'     => $paymentId,
                    'current_status' => $status,
                    'note'           => 'row was completed/verified concurrently — failed write skipped',
                ]);
                return false;
            }

            $this->log->update($paymentId, [
                'status'        => 'failed',
                'response_data' => json_encode($responseData, JSON_UNESCAPED_UNICODE),
            ]);
            return true;
        });

        return $result === true;
    }
}
