<?php

declare(strict_types=1);

namespace App\Jobs\Payment;

use App\Services\Payment\PaymentService;
use App\Contracts\LoggerInterface;

class CreatePaymentJob
{
    #[ \Core\Attributes\Inject ]
    private PaymentService $paymentService;

    #[ \Core\Attributes\Inject ]
    private LoggerInterface $logger;

    public function __construct() {}

    public function handle(int $userId, string $gatewayName, float $amount, int $bankCardId, string $idempotencyKey, string $clientIp = '', string $userAgent = ''): array
    {
        try {
            return $this->paymentService->create($userId, $gatewayName, $amount, $bankCardId, $idempotencyKey, $clientIp, $userAgent);
        } catch (\Throwable $e) {
            $this->logger->error('payment.create.job.failed', [
                'user_id' => $userId,
                'gateway' => $gatewayName,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }
}
