<?php

declare(strict_types=1);

namespace App\Jobs\Payment;

use App\Services\Payment\PaymentService;
use App\Contracts\LoggerInterface;

class CreatePaymentJob
{
    public function __construct(
        private ?PaymentService $paymentService = null,
        private ?LoggerInterface $logger = null
    ) {}

    public function handle(int $userId, string $gatewayName, float $amount, int $bankCardId, string $idempotencyKey, string $clientIp = '', string $userAgent = ''): array
    {
        try {
            $service = $this->paymentService ?? \Core\Container::getInstance()->make(PaymentService::class);
            return $service->create($userId, $gatewayName, $amount, $bankCardId, $idempotencyKey, $clientIp, $userAgent);
        } catch (\Throwable $e) {
            if ($this->logger) {
                $this->logger->error('payment.create.job.failed', [
                    'user_id' => $userId,
                    'gateway' => $gatewayName,
                    'error' => $e->getMessage()
                ]);
            }
            throw $e;
        }
    }
}
