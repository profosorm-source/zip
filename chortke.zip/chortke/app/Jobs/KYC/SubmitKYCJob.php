<?php

declare(strict_types=1);

namespace App\Jobs\KYC;

use App\Services\KYC\KYCCommandService;

/**
 * Thin Job — delegate به KYCCommandService
 */
class SubmitKYCJob
{
    public function handle(int $userId, array $data, array $files, KYCCommandService $service): array
    {
        return $service->submit($userId, $data, $files);
    }
}
