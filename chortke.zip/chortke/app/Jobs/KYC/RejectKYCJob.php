<?php

declare(strict_types=1);

namespace App\Jobs\KYC;

use App\Services\KYC\KYCCommandService;

class RejectKYCJob
{
    public function handle(int $kycId, int $adminId, string $reason, KYCCommandService $service): array
    {
        return $service->reject($kycId, $adminId, $reason);
    }
}
