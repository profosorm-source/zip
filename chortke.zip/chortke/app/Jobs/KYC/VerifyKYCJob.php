<?php

declare(strict_types=1);

namespace App\Jobs\KYC;

use App\Services\KYC\KYCCommandService;

class VerifyKYCJob
{
    /** @return array<string, mixed> */
public function handle(int $kycId, int $adminId, KYCCommandService $service): array
    {
        return $service->verify($kycId, $adminId);
    }
}
