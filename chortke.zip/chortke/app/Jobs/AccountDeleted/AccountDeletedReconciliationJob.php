<?php

declare(strict_types=1);

namespace App\Jobs\AccountDeleted;

use App\Listeners\HandleAccountDeleted;

/**
 * AccountDeletedReconciliationJob — اجرای بازTRYABLEِ کارِ پس‌حذف حساب.
 *
 * S7-FIX (EVT-001): قبلاً رویدادِ AccountDeletedEvent بلافاصله پس از commitِ ساگای
 * حذف به‌صورت in-process dispatch می‌شد و شنوندهٔ HandleAccountDeleted هر شکستِ
 * داخلی را swallow می‌کرد ⇒ escrow/تبلیغ/سرمایه‌گذاری باز یا audit نهایی می‌توانست
 * بدون هیچ recovery پایداری بماند. اکنون ساگا رویداد را در outbox تراکنشی ثبت
 * می‌کند (داخل همان تراکنش حذف) و OutboxPublisher این job را از صف اجرا می‌کند؛
 * شکست → retry خودکار صف/outbox و در نهایت DLQ + alert — بدون گم‌شدن رویداد.
 *
 * قرارداد ورودی: همان payload['data'] ثبت‌شده در outbox (+ _outbox_event_id که
 * ناشر برای idempotency سمتِ consumer اضافه می‌کند — FIX-M6-02).
 */
class AccountDeletedReconciliationJob
{
    public function __construct(private HandleAccountDeleted $listener)
    {
    }

    /** @param array<string, mixed> $data */
    public function handle(array $data): void
    {
        $userId = int_value($data['user_id'] ?? 0);
        if ($userId <= 0) {
            return;
        }

        $email  = str_value($data['email'] ?? '');
        $reason = str_value($data['reason'] ?? 'account deletion');
        $outboxEventId = int_value($data['_outbox_event_id'] ?? 0);

        // idempotency anchor سمت consumer: اجرای دوبارهٔ همان رویداد (re-publication
        // پس از crash-window) با log قابل‌ممیزی، بی‌خطر است — خودِ شنونده هم
        // عملیاتش idempotent است (UPDATEهای شرطی + audit با گارد تکرار).
        if ($outboxEventId > 0) {
            logger()->info('account_deleted.reconciliation_job_start', [
                'user_id'          => $userId,
                '_outbox_event_id' => $outboxEventId,
            ]);
        }

        // شنونده در شکستِ مراحلِ بحرانی (بستن escrow/audit نهایی) exception
        // پرتاب می‌کند ⇒ این job fail می‌شود ⇒ retry/outbox/DLQ فعال می‌ماند.
        $this->listener->handle(
            new \App\Events\AccountDeletedEvent($userId, $email, $reason)
        );
    }
}
