<?php

declare(strict_types=1);

namespace App\Jobs\Prediction;

use App\Contracts\WalletServiceInterface;
use App\Models\PredictionBet;
use App\Models\PredictionGame;
use App\Services\StateMachineService;
use Core\Database;

class CancelGameJob
{
    #[ \Core\Attributes\Inject ]
    private Database $db;

    #[ \Core\Attributes\Inject ]
    private StateMachineService $stateMachine;

    #[ \Core\Attributes\Inject ]
    private PredictionBet $betModel;

    #[ \Core\Attributes\Inject ]
    private WalletServiceInterface $walletService;

    #[ \Core\Attributes\Inject ]
    private \App\Models\PredictionGame $gameModel;

    public function __construct(
        Database $db,
        StateMachineService $stateMachine,
        PredictionBet $betModel,
        WalletServiceInterface $walletService,
        ?\App\Models\PredictionGame $gameModel = null
    ) {
        $this->db = $db;
        $this->stateMachine = $stateMachine;
        $this->betModel = $betModel;
        $this->walletService = $walletService;
        if ($gameModel !== null) {
            $this->gameModel = $gameModel;
        }
    }

    /** @return array<string, mixed> */
public function handle(int $gameId, int $adminId): array
    {
        try {
            $this->db->beginTransaction();

            $game = $this->db->fetch("SELECT * FROM prediction_games WHERE id = ? FOR UPDATE", [$gameId]);
            if (!$game) {
                throw new \RuntimeException('بازی یافت نشد.');
            }
            if (!in_array((string)$game->status, [PredictionGame::STATUS_OPEN, PredictionGame::STATUS_CLOSED], true)) {
                throw new \RuntimeException('فقط بازی‌های باز یا بسته قابل لغو هستند.');
            }
            if (!$this->stateMachine->canTransition('prediction_game', (string)$game->status, PredictionGame::STATUS_CANCELLED)) {
                throw new \RuntimeException('تغییر وضعیت بازی به cancelled مجاز نیست.');
            }

            $this->db->execute(
                "UPDATE prediction_games SET status = '" . PredictionGame::STATUS_CANCELLED . "', cancelled_at = NOW(), cancelled_by = ?, updated_at = NOW() WHERE id = ?",
                [$adminId, $gameId]
            );

            $bets = $this->betModel->getPendingByGame($gameId);
            $refunded = 0;
            foreach ($bets as $bet) {
                $txId = $this->cancelBetHold($bet, $gameId);
                $this->betModel->markRefunded((int)$bet->id, $txId);
                $refunded++;
            }

            // FIX-R36-W3 (F-A6b-06): the game's bonus_pool_usdt was consumed from the
            // prediction_rollover_reserve_usdt setting at creation (PredictionGame::
            // consumeRolloverReserve). Cancellation refunds every player hold but previously
            // left the consumed reserve stranded — players' rolled-over stake silently vanished
            // from reserve accounting. Return it inside the same transaction. This is a
            // settings-counter correction only: the reserve is not a ledger account and
            // consumeRolloverReserve writes no ledger legs, so no ledger entry belongs here.
            $bonusPoolToRestore = (string)($game->bonus_pool_usdt ?? '0');
            if (is_numeric($bonusPoolToRestore) && bccomp($bonusPoolToRestore, '0', 8) > 0) {
                $this->gameModel->addRolloverReserve($bonusPoolToRestore);
            }

            $this->db->commit();

            return [
                'success' => true,
                'message' => "بازی لغو شد و {$refunded} پیش‌بینی برگشت داده شد.",
                'refunded_count' => $refunded,
            ];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollback();
            }
            throw $e;
        }
    }

    private function cancelBetHold(\stdClass $bet, int $gameId): string
    {
        $txId = $this->findPaymentTransactionId($bet, $gameId);
        if (!$txId) {
            throw new \RuntimeException('تراکنش نگهداری مبلغ پیش‌بینی یافت نشد.');
        }
        if (!$this->walletService->cancelWithdrawal((int)$bet->user_id, (string)$bet->amount_usdt, 'usdt', $txId)) {
            throw new \RuntimeException('لغو مبلغ نگهداری‌شده پیش‌بینی انجام نشد.');
        }
        return $txId;
    }

    private function findPaymentTransactionId(\stdClass $bet, int $gameId): ?string
    {
        if (!empty($bet->payment_transaction_id)) {
            return (string)$bet->payment_transaction_id;
        }

        $row = $this->db->fetch(
            "SELECT transaction_id FROM transactions
             WHERE user_id = ? AND type = 'withdraw' AND currency = 'usdt'
               AND status IN ('pending','processing','completed','cancelled')
               AND ABS(amount - ?) < 0.00000001
               -- M-tier FIX: the prediction_bet_hold marker must be scoped to THIS game.
               -- Previously it was a standalone OR, so a hold for a DIFFERENT game with an
               -- identical amount could be matched and paid against the wrong transaction.
               AND (ref_id = ? OR (metadata LIKE ? AND metadata LIKE ?))
             ORDER BY id DESC LIMIT 1",
            [
                (int)$bet->user_id,
                (string)$bet->amount_usdt,
                (string)$gameId,
                '%"game_id":' . (int)$gameId . '%',
                '%"type":"prediction_bet_hold"%',
            ]
        );

        return $row->transaction_id ?? null;
    }
}
