<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Services\Notification\NotificationDispatcher;
use App\Services\Notification\SmsNotificationService;
use App\Contracts\LoggerInterface;
use App\Contracts\JobInterface;

/**
 * ProcessNotificationJob
 * 
 * این کلاس وظیفه ارسال پیام‌ها به APIهای خارجی (FCM, SMS, Email)
 * را در پس‌زمینه بر عهده دارد تا از کندی و Deadlock در سیستم جلوگیری شود.
 */
class ProcessNotificationJob implements JobInterface
{
    private NotificationDispatcher $dispatcher;
    private LoggerInterface $logger;
    private ?SmsNotificationService $smsService;
    public function __construct(
        NotificationDispatcher $dispatcher,
        LoggerInterface $logger,
        ?SmsNotificationService $smsService = null
    ) {        $this->dispatcher = $dispatcher;
        $this->logger = $logger;
        $this->smsService = $smsService;
}

    /** @param array<string, mixed> $payload */
    /** @param array<string, mixed> $payload */
public function handle(array $payload): void
    {
        $channelValue = $payload['channel'] ?? null;
        $userIdsValue = $payload['user_ids'] ?? null;
        if (!is_string($channelValue) || !in_array($channelValue, ['fcm', 'sms'], true)) {
            throw new \InvalidArgumentException('Notification channel must be fcm or sms.');
        }
        if (!is_array($userIdsValue) || $userIdsValue === []) {
            throw new \InvalidArgumentException('Notification user_ids must be a non-empty array.');
        }
        $channel = $channelValue;
        $userIds = array_map(static fn(mixed $value): int => int_value($value), $userIdsValue);

        $cache = cache();
        $cbKey = "circuit_breaker:notif_{$channel}";
        
        if ($cache->get("{$cbKey}:open")) {
            $this->logger->warning('notif.circuit_breaker_open', ['channel' => $channel]);
            // Throw exception to let the queue worker release/delay the job
            throw new \RuntimeException("Circuit breaker is OPEN for {$channel}. Deferring execution.");
        }

        try {
            switch ($channel) {
                case 'fcm':
                    // FIX-A6-F1 (Audit Task 6-a): نتیجهٔ واقعی dispatchBulk بررسی می‌شود.
                    // قبلاً خروجی نادیده گرفته می‌شد → حتی شکست کامل گیرندگان جاب را
                    // «موفق» می‌کرد و جاب بدون retry/DLQ از صف حذف می‌شد.
                    $bulkResult = $this->dispatcher->dispatchBulk(
                        'fcm',
                        $userIds,
                        str_value($payload['title'] ?? ''),
                        str_value($payload['message'] ?? ''),
                        is_array($payload['data'] ?? null) ? $payload['data'] : null,
                        null,
                        // FIX-C73 (یافتهٔ ۷۳): ‎$payload['action_url'] بدون ‎?? null خوانده
                        // می‌شد → warning کلید-تعریف‌نشده برای payloadهای فاقد این کلید.
                        ($payload['action_url'] ?? null) === null ? null : str_value($payload['action_url']),
                        // FIX-R36-W3 (F-A12-19): ارسال type برای گارد ترجیح per-user
                        // (در صورت نبود type در payload قدیمی، رفتار قبلی حفظ می‌شود).
                        ($payload['type'] ?? null) === null ? null : str_value($payload['type'])
                    );
                    if (!is_array($bulkResult) || !($bulkResult['success'] ?? false)) {
                        $failed = is_array($bulkResult) ? int_value($bulkResult['failed'] ?? 0) : count($userIds);
                        $total = is_array($bulkResult) ? int_value($bulkResult['total'] ?? count($userIds)) : count($userIds);
                        $failedIds = is_array($bulkResult) && is_array($bulkResult['failed_user_ids'] ?? null)
                            ? array_slice(array_map('intval', $bulkResult['failed_user_ids']), 0, 50)
                            : [];
                        // شکست موقت (شبکه/سرویس خارجی) → پرتاب استثنا تا ورکر جاب را
                        // retry کند و در نهایت به DLQ ببرد (وضعیت per-batch در پیام
                        // خطا به‌صورت پایدار در failed_jobs ثبت می‌شود). گیرندگانِ
                        // تحویل‌شده در تلاش بعدی با claim اتمیک dedup دوباره ارسال نمی‌شوند.
                        throw new \RuntimeException(
                            "FCM bulk delivery failed for {$failed}/{$total} recipients"
                            . ($failedIds !== [] ? ' (failed_user_ids: ' . implode(',', $failedIds) . ')' : '')
                        );
                    }
                    break;
    
                case 'sms':
                    $userIds = $userIds;
                    if (count($userIds) === 1) {
                        $userId = $userIds[0];
                        $smsType = str_value($payload['sms_type'] ?? 'generic');
                        
                        if ($smsType === 'security' && $this->smsService) {
                            $this->smsService->sendSecurityAlertToUser(int_value($userId), str_value($payload['message']));
                        } elseif ($smsType === 'withdrawal' && $this->smsService) {
                            $this->smsService->sendWithdrawalAlertToUser(int_value($userId), str_value($payload['amount']), str_value($payload['currency']));
                        } else {
                            // FIX-A6-F1: false از dispatch = شکست واقعی ارسال → retry
                            if (!$this->dispatcher->dispatch('sms', int_value($userId), str_value($payload['title'] ?? ''), str_value($payload['message'] ?? ''))) {
                                throw new \RuntimeException("SMS delivery failed for user {$userId}");
                            }
                        }
                    }
                    break;
            }
            
            // Success -> Reset errors
            $cache->forget("{$cbKey}:errors");

        } catch (\Throwable $e) {
            // Failure -> Increment errors
            // FIX-C8 (یافتهٔ ۵۸): increment طبق CacheInterface مقدار int|false برمی‌گرداند —
            // false یعنی «مخزن شمارنده در دسترس نیست» نه «صفر خطا». قبلاً false
            // بی‌صدا مثل ۰ رفتار می‌شد و breakeri هرگز تریپ نمی‌شد (fail-open).
            $errors = $cache->increment("{$cbKey}:errors", 1, 60);
            $shouldTrip = is_int($errors) && $errors >= 30;
            if (!is_int($errors)) {
                // مخزن شمارنده down → شکست واقعی جاب را از دست نمی‌دهیم (همان پایین throw می‌شود)
                // اما وضعیت را شفاف لاگ می‌کنیم تا گیرندهٔ دوگانه false/0 رخ ندهد.
                $this->logger->warning('job.process_notification_counter_unavailable', [
                    'channel' => $channel,
                    'error' => $e->getMessage(),
                ]);
            } elseif ($shouldTrip) {
                // FIX-C9 (یافتهٔ ۵۹): واحد TTL — قبلاً put(...,300) یعنی ۳۰۰ «دقیقه»
                // (۵ ساعت) بود در حالی که قصد ۵ دقیقه بود.
                // FIX-C73 (یافتهٔ ۷۳): ناهمگونی واحد set() بین دو پیاده‌سازی —
                // CacheManager::set(key,val,ttlSeconds) ثانیه است (مسیر کانتینر)، ولی
                // Core\Cache::set(key,val,minutes) دقیقه است (مسیر fallback بدون کانتینر
                // در helpers/functions.php). برای هر دو، دقیقاً ۳۰۰ «ثانیه»:
                //  - Core\Cache → putSeconds (صریح ثانیه)
                //  - CacheManager/CacheInterface → set با ttlSeconds (دقیق — FIX-8a)
                if ($cache instanceof \Core\Cache) {
                    $cache->putSeconds("{$cbKey}:open", true, 300);
                } else {
                    $cache->set("{$cbKey}:open", true, 300);
                }
            }

            $this->logger->error('job.process_notification_failed', [
                'channel' => $channel,
                'error' => $e->getMessage(),
                'consecutive_errors' => $errors
            ]);
            
            throw $e;
        }
    }
}
