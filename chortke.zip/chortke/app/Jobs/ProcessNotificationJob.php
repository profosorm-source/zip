<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Services\Notification\NotificationDispatcher;
use App\Services\Notification\SmsNotificationService;
use App\Contracts\LoggerInterface;
use App\Contracts\JobInterface;
use App\Contracts\FinalFailureAwareInterface;

/**
 * ProcessNotificationJob
 * 
 * این کلاس وظیفه ارسال پیام‌ها به APIهای خارجی (FCM, SMS, Email)
 * را در پس‌زمینه بر عهده دارد تا از کندی و Deadlock در سیستم جلوگیری شود.
 *
 * 🛡️ FIX-CH10: جاب‌های دارای attribution تبلیغاتی (ad_id + charged_units در data)
 * نتیجهٔ تحویلِ per-recipient را durable ثبت می‌کنند (ad_delivery_events با
 * event_type='deliver') و در شکستِ قطعی (ورود terminal به DLQ) مابه‌التفاوت
 * «شارژشده − تحویل‌شده» را idempotent استرداد می‌کنند — شارژِ پیشینی دیگر
 * «تحویل‌شده» تلقی نمی‌شود.
 */
class ProcessNotificationJob implements JobInterface, FinalFailureAwareInterface
{
    private NotificationDispatcher $dispatcher;
    private LoggerInterface $logger;
    private ?SmsNotificationService $smsService;
    private ?\App\Services\Ads\AdsBudgetSettlementService $adsSettlement;
    private ?\Core\Database $db;
    public function __construct(
        NotificationDispatcher $dispatcher,
        LoggerInterface $logger,
        ?SmsNotificationService $smsService = null,
        ?\App\Services\Ads\AdsBudgetSettlementService $adsSettlement = null,
        ?\Core\Database $db = null
    ) {        $this->dispatcher = $dispatcher;
        $this->logger = $logger;
        $this->smsService = $smsService;
        $this->adsSettlement = $adsSettlement;
        $this->db = $db;
}

    /** @param array<string, mixed> $payload */
    /** @param array<string, mixed> $payload */
public function handle(array $payload): void
    {
        $channelValue = $payload['channel'] ?? null;
        $userIdsValue = $payload['user_ids'] ?? null;
        if (!is_string($channelValue) || !in_array($channelValue, ['fcm', 'sms'], true)) {
            throw new \InvalidArgumentException('Notification channel must be fcm or sms.');
        }
        if (!is_array($userIdsValue) || $userIdsValue === []) {
            throw new \InvalidArgumentException('Notification user_ids must be a non-empty array.');
        }
        $channel = $channelValue;
        $userIds = array_map(static fn(mixed $value): int => int_value($value), $userIdsValue);

        $cache = cache();
        $cbKey = "circuit_breaker:notif_{$channel}";
        
        if ($cache->get("{$cbKey}:open")) {
            $this->logger->warning('notif.circuit_breaker_open', ['channel' => $channel]);
            // Throw exception to let the queue worker release/delay the job
            throw new \RuntimeException("Circuit breaker is OPEN for {$channel}. Deferring execution.");
        }

        try {
            switch ($channel) {
                case 'fcm':
                    // FIX-A6-F1 (Audit Task 6-a): نتیجهٔ واقعی dispatchBulk بررسی می‌شود.
                    // قبلاً خروجی نادیده گرفته می‌شد → حتی شکست کامل گیرندگان جاب را
                    // «موفق» می‌کرد و جاب بدون retry/DLQ از صف حذف می‌شد.
                    $bulkResult = $this->dispatcher->dispatchBulk(
                        'fcm',
                        $userIds,
                        str_value($payload['title'] ?? ''),
                        str_value($payload['message'] ?? ''),
                        is_array($payload['data'] ?? null) ? $payload['data'] : null,
                        null,
                        // FIX-C73 (یافتهٔ ۷۳): ‎$payload['action_url'] بدون ‎?? null خوانده
                        // می‌شد → warning کلید-تعریف‌نشده برای payloadهای فاقد این کلید.
                        ($payload['action_url'] ?? null) === null ? null : str_value($payload['action_url']),
                        // FIX-R36-W3 (F-A12-19): ارسال type برای گارد ترجیح per-user
                        // (در صورت نبود type در payload قدیمی، رفتار قبلی حفظ می‌شود).
                        ($payload['type'] ?? null) === null ? null : str_value($payload['type'])
                    );
                    if (!is_array($bulkResult) || !($bulkResult['success'] ?? false)) {
                        $failed = is_array($bulkResult) ? int_value($bulkResult['failed'] ?? 0) : count($userIds);
                        $total = is_array($bulkResult) ? int_value($bulkResult['total'] ?? count($userIds)) : count($userIds);
                        $failedIds = is_array($bulkResult) && is_array($bulkResult['failed_user_ids'] ?? null)
                            ? array_slice(array_map('intval', $bulkResult['failed_user_ids']), 0, 50)
                            : [];
                        // شکست موقت (شبکه/سرویس خارجی) → پرتاب استثنا تا ورکر جاب را
                        // retry کند و در نهایت به DLQ ببرد (وضعیت per-batch در پیام
                        // خطا به‌صورت پایدار در failed_jobs ثبت می‌شود). گیرندگانِ
                        // تحویل‌شده در تلاش بعدی با claim اتمیک dedup دوباره ارسال نمی‌شوند.
                        throw new \RuntimeException(
                            "FCM bulk delivery failed for {$failed}/{$total} recipients"
                            . ($failedIds !== [] ? ' (failed_user_ids: ' . implode(',', $failedIds) . ')' : '')
                        );
                    }
                    // 🛡️ FIX-CH10: ثبت durable تحویلِ per-recipient برای بچ‌های
                    // دارای attribution تبلیغاتی — مبنای تسویهٔ «شارژشده − تحویل‌شده».
                    $adData = is_array($payload['data'] ?? null) ? $payload['data'] : [];
                    $adIdCh = int_value($adData['ad_id'] ?? 0);
                    if ($adIdCh > 0) {
                        $failedAll = is_array($bulkResult) && is_array($bulkResult['failed_user_ids'] ?? null)
                            ? array_map('intval', $bulkResult['failed_user_ids'])
                            : [];
                        $deliveredIds = array_values(array_diff($userIds, $failedAll));
                        $this->recordAdDeliveries($adIdCh, str_value($adData['idempotency_key_prefix'] ?? ''), $deliveredIds);
                    }

                    break;

                case 'sms':
                    $userIds = $userIds;
                    if (count($userIds) === 1) {
                        $userId = $userIds[0];
                        $smsType = str_value($payload['sms_type'] ?? 'generic');
                        
                        if ($smsType === 'security' && $this->smsService) {
                            $this->smsService->sendSecurityAlertToUser(int_value($userId), str_value($payload['message']));
                        } elseif ($smsType === 'withdrawal' && $this->smsService) {
                            $this->smsService->sendWithdrawalAlertToUser(int_value($userId), str_value($payload['amount']), str_value($payload['currency']));
                        } else {
                            // FIX-A6-F1: false از dispatch = شکست واقعی ارسال → retry
                            if (!$this->dispatcher->dispatch('sms', int_value($userId), str_value($payload['title'] ?? ''), str_value($payload['message'] ?? ''))) {
                                throw new \RuntimeException("SMS delivery failed for user {$userId}");
                            }
                        }
                    }
                    break;
            }
            
            // Success -> Reset errors
            $cache->forget("{$cbKey}:errors");

        } catch (\Throwable $e) {
            // Failure -> Increment errors
            // FIX-C8 (یافتهٔ ۵۸): increment طبق CacheInterface مقدار int|false برمی‌گرداند —
            // false یعنی «مخزن شمارنده در دسترس نیست» نه «صفر خطا». قبلاً false
            // بی‌صدا مثل ۰ رفتار می‌شد و breakeri هرگز تریپ نمی‌شد (fail-open).
            $errors = $cache->increment("{$cbKey}:errors", 1, 60);
            $shouldTrip = is_int($errors) && $errors >= 30;
            if (!is_int($errors)) {
                // مخزن شمارنده down → شکست واقعی جاب را از دست نمی‌دهیم (همان پایین throw می‌شود)
                // اما وضعیت را شفاف لاگ می‌کنیم تا گیرندهٔ دوگانه false/0 رخ ندهد.
                $this->logger->warning('job.process_notification_counter_unavailable', [
                    'channel' => $channel,
                    'error' => $e->getMessage(),
                ]);
            } elseif ($shouldTrip) {
                // FIX-C9 (یافتهٔ ۵۹): واحد TTL — قبلاً put(...,300) یعنی ۳۰۰ «دقیقه»
                // (۵ ساعت) بود در حالی که قصد ۵ دقیقه بود.
                // FIX-C73 (یافتهٔ ۷۳): ناهمگونی واحد set() بین دو پیاده‌سازی —
                // CacheManager::set(key,val,ttlSeconds) ثانیه است (مسیر کانتینر)، ولی
                // Core\Cache::set(key,val,minutes) دقیقه است (مسیر fallback بدون کانتینر
                // در helpers/functions.php). برای هر دو، دقیقاً ۳۰۰ «ثانیه»:
                //  - Core\Cache → putSeconds (صریح ثانیه)
                //  - CacheManager/CacheInterface → set با ttlSeconds (دقیق — FIX-8a)
                if ($cache instanceof \Core\Cache) {
                    $cache->putSeconds("{$cbKey}:open", true, 300);
                } else {
                    $cache->set("{$cbKey}:open", true, 300);
                }
            }

            $this->logger->error('job.process_notification_failed', [
                'channel' => $channel,
                'error' => $e->getMessage(),
                'consecutive_errors' => $errors
            ]);
            
            throw $e;
        }
    }

    /**
     * 🛡️ FIX-CH10: ثبت durable تحویل per-recipient (idempotent با UNIQUE
     * uq_ad_delivery_idempotency). بدون این ledger، تفاوت «شارژشده» و
     * «تحویل‌شده» در شکست async هرگز قابل‌حساب نمی‌شد.
     *
     * @param list<int> $deliveredIds
     */
    private function recordAdDeliveries(int $adId, string $batch, array $deliveredIds): void
    {
        if ($deliveredIds === [] || $this->db === null) {
            return;
        }
        foreach ($deliveredIds as $recipientId) {
            $recipientId = int_value($recipientId);
            if ($recipientId <= 0) {
                continue;
            }
            try {
                $key = 'adfcm:' . ($batch !== '' ? $batch : (string)$adId) . ':u' . $recipientId;
                $this->db->execute(
                    "INSERT IGNORE INTO ad_delivery_events
                     (ad_id, ad_type, event_type, user_id, units, idempotency_key, metadata, created_at)
                     VALUES (?, 'notification', 'deliver', ?, 1.0000, ?, ?, NOW())",
                    [$adId, $recipientId, $key, json_encode(['batch' => $batch, 'source' => 'fcm_bulk'], JSON_UNESCAPED_UNICODE)]
                );
            } catch (\Throwable $ledgerError) {
                // ledger هرگز ارسال را متوقف نمی‌کند؛ تسویه در settle مستقل انجام می‌شود
                $this->logger->warning('ad_fcm_deliver_ledger_failed', [
                    'ad_id' => $adId,
                    'user_id' => $recipientId,
                    'error' => $ledgerError->getMessage(),
                ]);
                break; // خطای DB تکراری است — بقیه هم شکست می‌خورد
            }
        }
    }

    /**
     * 🛡️ FIX-CH10: شکستِ قطعی (terminal DLQ) ⇒ تسویهٔ idempotent مابه‌التفاوت
     * «شارژشده − تحویل‌شده» (قرارداد FinalFailureAwareInterface از QueueWorker).
     * کلید تسویه پایدارِ بچ است ⇒ اجرای مضاعف = duplicate (no-op اتمیک در
     * refundDeliveryUnits). خطای جبران فقط لاگ می‌شود.
     *
     * @param array<string, mixed> $payload
     */
    public function onFinalFailure(array $payload, \Throwable $e): void
    {
        $adData = is_array($payload['data'] ?? null) ? $payload['data'] : [];
        $adId = int_value($adData['ad_id'] ?? 0);
        $chargedUnits = int_value($adData['charged_units'] ?? 0);
        $batch = str_value($adData['idempotency_key_prefix'] ?? '');
        if ($adId <= 0 || $chargedUnits <= 0 || $this->adsSettlement === null || $this->db === null) {
            return;
        }

        try {
            $batchKey = $batch !== '' ? $batch : (string)$adId;
            $delivered = (int)$this->db->fetchColumn(
                "SELECT COALESCE(SUM(units), 0) FROM ad_delivery_events
                 WHERE ad_id = ? AND event_type = 'deliver' AND idempotency_key LIKE ?",
                [$adId, 'adfcm:' . $batchKey . ':u%']
            );
            $undelivered = max(0, $chargedUnits - $delivered);
            if ($undelivered <= 0) {
                return;
            }
            $refund = $this->adsSettlement->refundDeliveryUnits(
                $adId,
                'notification',
                (float)$undelivered,
                'fcm_terminal_failure_settle',
                'system',
                'adfcm_settle:' . $batchKey,
                ['batch' => $batch, 'charged_units' => $chargedUnits, 'delivered_units' => $delivered]
            );
            $this->logger->warning('ad_fcm_terminal_settle_done', [
                'ad_id' => $adId,
                'batch' => $batch,
                'charged_units' => $chargedUnits,
                'delivered_units' => $delivered,
                'refunded_units' => $undelivered,
                'refund' => $refund,
            ]);
        } catch (\Throwable $settleError) {
            $this->logger->error('ad_fcm_terminal_settle_failed', [
                'ad_id' => $adId,
                'batch' => $batch,
                'error' => $settleError->getMessage(),
            ]);
        }
    }
}
