<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;
use App\Contracts\LoggerInterface;

/**
 * AggregateAnalyticsJob
 * تجمیع داده‌های روزانه در جدول analytics_daily_summary برای جلوگیری از بار N+1
 */
class AggregateAnalyticsJob
{
    private Database $db;
    private LoggerInterface $logger;

    public function __construct(Database $db, LoggerInterface $logger) {
        $this->db = $db;
        $this->logger = $logger;
    }

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data = []): void
    {
        // اصلاح کلیدی معماری همزمانی در تجمیع آمار (Analytics Aggregation Mutex Guard):
        // استفاده از قفل همزمانی کش جهت جلوگیری از اجرای موازی کوئری‌های سنگین COUNT/SUM توسط ورکرهای کرون در کلاسترها
        $lockKey = 'mutex:analytics_aggregation:' . date('Ymd');
        if (!function_exists('cache') || !cache()->lock($lockKey, 300, 2)) {
            $this->logger->info('analytics.aggregation_skipped_locked', ['date' => date('Y-m-d')]);
            return;
        }

        try {
            $date = date('Y-m-d');

            // float→decimal: مجموع درآمد به‌صورت رشتهٔ decimal حفظ می‌شود (بدون گذر از float)
            $revenueIrt  = $this->db->query("SELECT SUM(amount) FROM transactions WHERE DATE(created_at) = ? AND currency = 'IRT' AND status = 'completed'", [$date])->fetchColumn();
            $revenueUsdt = $this->db->query("SELECT SUM(amount) FROM transactions WHERE DATE(created_at) = ? AND currency = 'USDT' AND status = 'completed'", [$date])->fetchColumn();

            // Daily summary collection — EAV: هر متریک یک ردیف (uq_date_metric)
            $summaryRows = [
                ['new_users', (string)(int)$this->db->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = ?", [$date])->fetchColumn()],
                ['total_transactions', (string)(int)$this->db->query("SELECT COUNT(*) FROM transactions WHERE DATE(created_at) = ?", [$date])->fetchColumn()],
                ['revenue_irt', is_numeric($revenueIrt) ? (string)$revenueIrt : '0'],
                ['revenue_usdt', is_numeric($revenueUsdt) ? (string)$revenueUsdt : '0'],
                ['tasks_completed', (string)(int)$this->db->query("SELECT COUNT(*) FROM custom_tasks WHERE DATE(updated_at) = ? AND status = 'completed'", [$date])->fetchColumn()],
                ['active_users', (string)(int)$this->db->query("SELECT COUNT(DISTINCT user_id) FROM activity_logs WHERE DATE(created_at) = ?", [$date])->fetchColumn()],
            ];

            // FIX راند ۷۷ (ستون شبح): جدول analytics_daily_summary ساختار EAV دارد
            // (date, metric_key, metric_value, context_json) — ستون‌های wide مانند new_users
            // هرگز وجود نداشتند (42S22). Upsert به‌ازای هر متریک روی uq_date_metric.
            $sql = "INSERT INTO analytics_daily_summary 
                    (date, metric_key, metric_value, updated_at) 
                    VALUES 
                    (?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE 
                    metric_value = VALUES(metric_value), 
                    updated_at = NOW()";

            foreach ($summaryRows as [$metricKey, $metricValue]) {
                $this->db->query($sql, [$date, $metricKey, $metricValue]);
            }

            $this->logger->info('analytics.aggregated', [
                'date' => $date,
                'metrics' => array_column($summaryRows, 1, 0),
            ]);
            
        } catch (\Exception $e) {
            $this->logger->error('analytics.aggregation_failed', ['error' => $e->getMessage()]);
            throw $e;
        } finally {
            if (function_exists('cache')) {
                try { cache()->unlock($lockKey); } catch (\Throwable $err) { /* intentional: non-blocking operation */ }
            }
        }
    }
}
