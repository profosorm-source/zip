<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Contracts\LoggerInterface;
use App\Services\Notification\NotificationService;

/**
 * PersistBulkInAppNotificationJob - پردازش و درج غیرهمزمان نوتیفیکیشن‌های درون‌برنامه‌ای در دیتابیس
 *
 * FIX-A6-F7 (Audit Task 6-a): payload نامعتبر دیگر «بی‌صدا موفق» نیست.
 * قبلاً برای user_ids/title/message خالی silently return می‌شد و QueueWorker
 * آن را موفق می‌دانست و جاب را حذف می‌کرد — دادهٔ خراب هرگز دیده نمی‌شد.
 * اکنون خطای اعتبارسنجی با استثنایِ نوعِ دائمی (\InvalidArgumentException)
 * پرتاب می‌شود؛ طبق قرارداد QueueWorker::isFatalException این نوع مستقیم به
 * DLQ می‌رود (بدون retry بی‌فایده) و Sentry/متریک مجزا هم ثبت می‌شود.
 * (کاربرانِ opt-out/تحت rate-limit مسیر عمدیِ رهاشدن‌اند و داخل
 * processSinglePersist با گاردهای خودش هندل می‌شوند — خارج از این جاب.)
 */
class PersistBulkInAppNotificationJob
{
    private NotificationService $service;
    private LoggerInterface $logger;

    public function __construct(NotificationService $service, ?LoggerInterface $logger = null) {
        $this->service = $service;
        // پارامتر اختیاری: سازگاری کامل با سازندهٔ قدیمی `new PersistBulkInAppNotificationJob($service)`.
        if ($logger !== null) {
            $this->logger = $logger;
        } else {
            try {
                $this->logger = \Core\Container::getInstance()->make(LoggerInterface::class);
            } catch (\Throwable $containerError) {
                // آخرین سپر: لاگر اصلی در دسترس نیست — FallbackLogger هرگز کرش نمی‌کند.
                $this->logger = new \App\Support\FallbackLogger();
            }
        }
    }

    /**
     * اجرای تسک ثبت نوتیفیکیشن در دیتابیس برای دسته‌ای از کاربران
     */
    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data): void
    {
        $userIds = is_array($data['user_ids'] ?? null) ? array_map(static fn($v) => int_value($v), $data['user_ids']) : [];
        $type = str_value($data['type'] ?? '');
        $title = str_value($data['title'] ?? '');
        $message = str_value($data['message'] ?? '');
        $extraData = is_array($data['data'] ?? null) ? $data['data'] : null;
        $actionUrl = $data['action_url'] === null ? null : str_value($data['action_url']);
        $actionText = $data['action_text'] === null ? null : str_value($data['action_text']);
        $priority = str_value($data['priority'] ?? 'normal');
        $scheduledAt = $data['scheduled_at'] === null ? null : str_value($data['scheduled_at']);

        // FIX-A6-F7: اعتبارسنجی سخت‌گیرانهٔ payload — خالی = پیام معیوب (poison
        // payload) نه «کاری برای انجام دادن نیست». استثنای دائمی → DLQ + متریک.
        if (empty($userIds) || trim($title) === '' || trim($message) === '') {
            $reason = [];
            if (empty($userIds)) { $reason[] = 'user_ids_empty'; }
            if (trim($title) === '') { $reason[] = 'title_empty'; }
            if (trim($message) === '') { $reason[] = 'message_empty'; }

            // متریک مجزای payload نامعتبر — فقط خلاصهٔ allowlist (نه کل payload
            // خام؛ title/message ممکن است حاوی محتوای حساس باشد).
            $this->logger->error('notif.bulk_persist_invalid_payload', [
                'reason' => implode(',', $reason),
                'user_count' => count($userIds),
                'has_type' => $type !== '',
                'has_action_url' => $actionUrl !== null,
                'priority' => $priority,
            ]);
            \App\Services\Sentry\SentryExceptionHandler::captureException(
                new \RuntimeException('Invalid PersistBulkInAppNotificationJob payload: ' . implode(',', $reason)),
                null,
                ['operation' => 'app.Jobs.PersistBulkInAppNotificationJob.validate']
            );

            throw new \InvalidArgumentException(
                'PersistBulkInAppNotificationJob requires non-empty user_ids, title and message (reason: ' . implode(',', $reason) . ').'
            );
        }

        // 🚀 Bulk pre-fetch preferences to avoid N+1 database queries
        $this->service->prefetchPreferences($userIds);

        // FIX-N04: هویت پایدار per-user — dispatcher کلید بچ را زیر
        // 'idempotency_key_prefix' می‌فرستد؛ اینجا به کلید یکتای per-user
        // (prefix:u:{uid}) تبدیل می‌شود تا retryهای outbox (bulk_persist) به‌جای
        // ردیف in-app تکراری، از dedupe UNIQUE notifications.idempotency_key عبور کنند.
        $idempotencyPrefix = is_array($extraData) && isset($extraData['idempotency_key_prefix'])
            && is_scalar($extraData['idempotency_key_prefix'])
            ? trim((string)$extraData['idempotency_key_prefix'])
            : '';

        foreach ($userIds as $uid) {
            $userData = $extraData;
            if ($idempotencyPrefix !== '') {
                $userData = is_array($extraData) ? $extraData : [];
                $userData['idempotency_key'] = mb_substr($idempotencyPrefix . ':u:' . $uid, 0, 128);
            }
            $this->service->processSinglePersist(
                $uid,
                $type,
                $title,
                $message,
                $userData,
                $actionUrl,
                $actionText,
                $priority,
                $scheduledAt
            );
        }
    }
}
