<?php

declare(strict_types=1);

namespace App\Jobs\Auth;

use App\Traits\ClientInfoTrait;
use App\Traits\ExternalCallTrait;

/**
 * OAuthHelperTrait — متدهای مشترک بین OAuth Jobs
 *
 * این trait متدهای کمکی مشترک (HTTP calls, IP matching, user linking) رو
 * بین HandleGoogleCallbackJob, HandleFacebookCallbackJob و غیره به اشتراک میذاره.
 *
 * clientIp() و userAgent() از ClientInfoTrait ارث‌بری میشن.
 *
 * Jobs باید پراپرتی‌های زیر رو داشته باشن:
 * - $this->session (Core\Session)
 * - $this->logger (LoggerInterface)
 * - $this->googleClientId, $this->googleClientSecret, $this->googleRedirectUri
 * - $this->facebookClientId, $this->facebookClientSecret, $this->facebookRedirectUri
 */
trait OAuthHelperTrait
{
    use ClientInfoTrait;
    use ExternalCallTrait;

    // ─── OAuth HTTP timeouts ─────────────────────────
    private const OAUTH_CONNECT_TIMEOUT = 5;  // connection timeout (s)
    private const OAUTH_READ_TIMEOUT    = 15; // read timeout (s)


    #[ \Core\Attributes\Inject ]
    private \App\Services\Auth\GoogleJwtVerifier $googleVerifier;

    #[ \Core\Attributes\Inject ]
    private \Core\Database $db;

    #[ \Core\Attributes\Inject ]
    private \App\Models\User $userModel;

    #[ \Core\Attributes\Inject ]
    private \App\Services\Auth\AuthService $authService;

    #[ \Core\Attributes\Inject ]
    private \Core\UrlGenerator $urlGenerator;

    #[ \Core\Attributes\Inject ]
    private LinkSocialAccountJob $linkSocialAccountJob;

    /**
     * FIX-R18B (Task 18-B): گیت ضد-فارمینگ R90 — تا راند ۱۷ فقط مسیر عادی
     * (AuthController::register) آن را اجرا می‌کرد و ثبت‌نام‌های OAuth سقف
     * per-IP / آستانهٔ فارمینگ معرف را دور می‌زدند. همان سرویسِ مشترک با همین
     * ترتیبِ call-site (پیش از AuthService::register) وایر می‌شود.
     */
    #[ \Core\Attributes\Inject ]
    private \App\Services\Auth\ReferralAntiFarmingGate $referralAntiFarmingGate;

    /**
     * FIX-R18N (Task 18-N — P1 REVIEW_ROUND18 #14): گارد ضد-تقلب ثبت‌نام —
     * مسیر عادی (AuthController::register:418-434) checkAction(0,'auth.register')
     * را برای شناسایی ربات/ایمیل یک‌بارمصرف/ATO اجرا می‌کند؛ ثبت‌نام‌های OAuth
     * از این هوشِ امنیتی عبور می‌کردند. Nullable-DI: نبودِ سرویس (ساخت دستی/تست)
     * گارد را بی‌صدا skip می‌کند تا ورود/لینک OAuth هرگز نشکند.
     */
    #[ \Core\Attributes\Inject ]
    private ?\App\Services\AntiFraud\FraudGuardService $fraudGuard = null;

    /**
     * مقایسه دو IP — حتی اگه پشت NAT/VPN تغییر کرده باشن
     * IPv4: مقایسه /24 subnet
     * IPv6: مقایسه /48 prefix
     */
    private function matchIpSubnet(string $ip1, string $ip2): bool
    {
        if ($ip1 === $ip2) {
            return true;
        }

        // IPv4: مقایسه 3 اکتت اول (/24)
        if (filter_var($ip1, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) &&
            filter_var($ip2, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $parts1 = explode('.', $ip1);
            $parts2 = explode('.', $ip2);
            return $parts1[0] === $parts2[0] && $parts1[1] === $parts2[1] && $parts1[2] === $parts2[2];
        }

        // IPv6: مقایسه /48
        if (filter_var($ip1, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) &&
            filter_var($ip2, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $p1 = inet_pton($ip1);
            $p2 = inet_pton($ip2);
            if ($p1 === false || $p2 === false) return false;
            return substr($p1, 0, 6) === substr($p2, 0, 6);
        }

        return false;
    }

    /**
     * Google: exchange authorization code for tokens
     */
    /** @return array<string, mixed> */
private function getGoogleToken(string $code): array
    {
        $redirectUri = $this->googleRedirectUri ?: $this->buildRedirectUri('/auth/callback/google');

        // ✅ Circuit Breaker + Timeout — جلوگیری از hang در صورت کند بودن Google
        try {
            [$response, $httpCode] = $this->callWithBreaker('oauth_google', function () use ($code, $redirectUri): array {
                $ch = curl_init('https://oauth2.googleapis.com/token');
                curl_setopt_array($ch, [
                    CURLOPT_POST            => true,
                    CURLOPT_RETURNTRANSFER  => true,
                    CURLOPT_CONNECTTIMEOUT  => self::OAUTH_CONNECT_TIMEOUT,
                    CURLOPT_TIMEOUT         => self::OAUTH_READ_TIMEOUT,
                    CURLOPT_POSTFIELDS      => http_build_query([
                        'code'          => $code,
                        'client_id'     => $this->googleClientId,
                        'client_secret' => $this->googleClientSecret,
                        'redirect_uri'  => $redirectUri,
                        'grant_type'    => 'authorization_code',
                    ]),
                ]);
                $resp     = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                return [$resp, $httpCode];
            });
        } catch (\Throwable $cbEx) {
            $this->logger->error('oauth.google.circuit_open', ['error' => $cbEx->getMessage()]);
            return ['success' => false, 'message' => 'سرویس احراز هویت موقتاً در دسترس نیست'];
        }

        if ($response === false || $httpCode !== 200) {
            $this->logger->error('oauth.google.token_exchange_failed', ['http_code' => $httpCode]);
            return ['success' => false, 'message' => 'خطا در دریافت توکن از گوگل'];
        }

        $data = (array)(json_decode((string) $response, true) ?? []);
        if (empty($data['access_token'])) {
            return ['success' => false, 'message' => 'توکن دسترسی از گوگل دریافت نشد'];
        }

        return array_merge(['success' => true], $data);
    }

    /**
     * Google: verify ID Token using GoogleJwtVerifier
     */
    /** @return array<string, mixed> */
private function verifyGoogleIdToken(string $idToken): array
    {
        try {
            $payload = $this->googleVerifier->verifyIdToken(
                $idToken,
                $this->googleClientId,
                ['https://accounts.google.com', 'accounts.google.com']
            );

            if (!$payload || empty($payload['sub'])) {
                return ['success' => false, 'message' => 'ID Token نامعتبر است'];
            }

            return [
                'success' => true,
                'data' => [
                    'id' => $payload['sub'],
                    'email' => $payload['email'] ?? null,
                    'name' => $payload['name'] ?? null,
                    'picture' => $payload['picture'] ?? null,
                    'email_verified' => $payload['email_verified'] ?? false,
                    'nonce' => $payload['nonce'] ?? null,
                ],
            ];
        } catch (\Throwable $e) {
            $this->logger->error('oauth.google.id_token_verify_failed', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => 'خطا در تأیید هویت گوگل'];
        }
    }

    /**
     * Facebook: exchange code for access token
     */
    /** @return array<string, mixed> */
private function getFacebookToken(string $code): array
    {
        $redirectUri = $this->facebookRedirectUri ?: $this->buildRedirectUri('/auth/callback/facebook');

        $url = 'https://graph.facebook.com/v18.0/oauth/access_token?' . http_build_query([
            'client_id' => $this->facebookClientId,
            'client_secret' => $this->facebookClientSecret,
            'redirect_uri' => $redirectUri,
            'code' => $code,
        ]);

        // ✅ Circuit Breaker برای Facebook token exchange
        try {
            [$response, $httpCode] = $this->callWithBreaker('oauth_facebook', function () use ($url): array {
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => self::OAUTH_CONNECT_TIMEOUT,
                    CURLOPT_TIMEOUT        => self::OAUTH_READ_TIMEOUT,
                ]);
                $resp     = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                return [$resp, $httpCode];
            });
        } catch (\Throwable $cbEx) {
            $this->logger->error('oauth.facebook.circuit_open', ['error' => $cbEx->getMessage()]);
            return ['success' => false, 'message' => 'سرویس احراز هویت موقتاً در دسترس نیست'];
        }

        if ($response === false || $httpCode !== 200) {
            $this->logger->error('oauth.facebook.token_exchange_failed', ['http_code' => $httpCode]);
            return ['success' => false, 'message' => 'خطا در دریافت توکن از فیسبوک'];
        }

        $data = (array)(json_decode((string) $response, true) ?? []);
        if (empty($data['access_token'])) {
            return ['success' => false, 'message' => 'توکن دسترسی از فیسبوک دریافت نشد'];
        }

        return array_merge(['success' => true], $data);
    }

    /**
     * Facebook: verify access token validity
     */
    /** @return array<string, mixed> */
private function verifyFacebookAccessToken(string $accessToken): array
    {
        $appToken = $this->facebookClientId . '|' . $this->facebookClientSecret;
        $url = "https://graph.facebook.com/debug_token?" . http_build_query([
            'input_token' => $accessToken,
            'access_token' => $appToken,
        ]);

        // ✅ Circuit Breaker برای Facebook token verification
        try {
            $response = $this->callWithBreaker('oauth_facebook', function () use ($url): string {
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => self::OAUTH_CONNECT_TIMEOUT,
                    CURLOPT_TIMEOUT        => self::OAUTH_READ_TIMEOUT,
                ]);
                $resp = curl_exec($ch);
                curl_close($ch);
                return is_string($resp) ? $resp : '';
            });
        } catch (\Throwable $cbEx) {
            $this->logger->error('oauth.facebook.verify_circuit_open', ['error' => $cbEx->getMessage()]);
            return ['success' => false, 'message' => 'سرویس احراز هویت موقتاً در دسترس نیست'];
        }

        $data = (array)(json_decode($response ?: '', true) ?? []);

        $tokenData = is_array($data['data'] ?? null) ? $data['data'] : [];
        if (empty($tokenData['is_valid'])) {
            $this->logger->warning('oauth.facebook.token_invalid', ['response' => $data]);
            return ['success' => false, 'message' => 'توکن فیسبوک نامعتبر است'];
        }

        return ['success' => true, 'data' => $tokenData];
    }

    /**
     * Facebook: get user profile
     */
    /** @return array<string, mixed> */
private function getFacebookUserInfo(string $accessToken): array
    {
        $url = "https://graph.facebook.com/v18.0/me?" . http_build_query([
            'fields' => 'id,name,email,picture.type(large)',
            'access_token' => $accessToken,
        ]);

        // ✅ Circuit Breaker برای Facebook user info
        try {
            $response = $this->callWithBreaker('oauth_facebook', function () use ($url): string {
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => self::OAUTH_CONNECT_TIMEOUT,
                    CURLOPT_TIMEOUT        => self::OAUTH_READ_TIMEOUT,
                ]);
                $resp = curl_exec($ch);
                curl_close($ch);
                return is_string($resp) ? $resp : '';
            });
        } catch (\Throwable $cbEx) {
            $this->logger->error('oauth.facebook.userinfo_circuit_open', ['error' => $cbEx->getMessage()]);
            return ['success' => false, 'message' => 'سرویس احراز هویت موقتاً در دسترس نیست'];
        }

        $data = (array)(json_decode($response ?: '', true) ?? []);

        if (empty($data['id'])) {
            return ['success' => false, 'message' => 'اطلاعات کاربر از فیسبوک دریافت نشد'];
        }

        return [
            'success' => true,
            'data' => [
                'id' => $data['id'],
                'email' => $data['email'] ?? null,
                'name' => $data['name'] ?? null,
                'picture' => $data['picture']['data']['url'] ?? null,
            ],
        ];
    }

    /**
     * Link social account to existing user or create new user
     */
/**
 * @param array<string, mixed> $userData
 * @return array<string, mixed>
 */
private function linkOrCreateUser(string $provider, array $userData): array
    {
        try {
            $providerId = str_value($userData['id'] ?? '');
            $emailValue = $userData['email'] ?? null;
            $email = is_string($emailValue) && $emailValue !== '' ? $emailValue : null;

            if (empty($providerId)) {
                return ['success' => false, 'message' => 'شناسه ارائه‌دهنده نامعتبر است'];
            }

            // بررسی linking user (اگه کاربر لاگین شده و میخواد حساب رو link کنه)
            $session = \Core\Session::getInstance();
            $linkingUserId = $session->get(\App\Constants\SessionKeys::OAUTH_LINKING_USER_ID);
            $session->remove(\App\Constants\SessionKeys::OAUTH_LINKING_USER_ID);

            // آیا این social account قبلاً ثبت شده؟
            // FIX-X295 (راند ۷۱): ستون واقعی platform است نه provider
            $existing = $this->db->table('social_accounts')
                ->where('platform', '=', $provider)
                ->where('provider_id', '=', $providerId)
                ->first();

            if ($existing) {
                // حساب موجوده — login
                $user = $this->userModel->find((int)$existing->user_id);
                if (!$user) {
                    return ['success' => false, 'message' => 'حساب کاربری مرتبط یافت نشد'];
                }
                return $this->authService->loginDirectly($user);
            }

            // اگه linking
            if ($linkingUserId) {
                $linkingUserIdInt = is_int($linkingUserId)
                    ? $linkingUserId
                    : (is_numeric($linkingUserId) ? (int)$linkingUserId : 0);
                if ($linkingUserIdInt <= 0) {
                    return ['success' => false, 'message' => 'شناسه کاربر برای اتصال حساب نامعتبر است'];
                }
                return $this->linkSocialAccountJob->handle($linkingUserIdInt, $provider, $userData);
            }

            // کاربر جدید — اگه email داره ببینیم قبلاً ثبت شده یا نه
            if ($email) {
                $existingUser = $this->userModel->findByEmail($email);
                if ($existingUser) {
                    // 🛡️ FIX-S17-5 (Medium — ATO): لینک خودکار به حساب محلیِ موجود فقط
                    // با تأییدیهٔ ارائه‌دهندهٔ OAuth مجاز است. فلگ email_verified فقط در
                    // مسیر ثبت‌نام جدید مصرف می‌شد و فیسبوک اصلاً آن را برنمی‌گرداند ⇒
                    // ثبت OAuth با ایمیل قربانی = لینک + ورود کامل (تصاحب حساب).
                    // fail-closed: بدون تأییدیهٔ صریح provider، لینک خودکار ممنوع؛
                    // مسیر مشروع: ورود با رمز عبور یا لینک از تنظیمات (کاربرِ لاگین‌شده).
                    if (empty($userData['email_verified'])) {
                        $this->logger->warning('oauth.email_link_blocked_unverified', [
                            'provider' => $provider,
                        ]);
                        return [
                            'success' => false,
                            'message' => 'ورود خودکار با این ایمیل ممکن نیست؛ لطفاً با رمز عبور وارد شوید یا ابتدا ایمیل حساب OAuth خود را نزد ارائه‌دهنده تأیید کنید.',
                        ];
                    }
                    // Link + login
                    $this->db->table('social_accounts')->insert([
                        'user_id' => (int)$existingUser->id,
                        'platform' => $provider,
                        // FIX-X295 (راند ۷۱): username NOT NULL بدون پیش‌فرض است
                        'username' => str_value($userData['name'] ?? ('user_' . $providerId)),
                        'provider_id' => $providerId,
                        'avatar' => $userData['picture'] ?? null,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                    return $this->authService->loginDirectly($existingUser);
                }
            }

            // ثبت‌نام جدید
            // FIX-R17F (Task 17-F): انتقال اتریبیوشن معرف به ثبت‌نام OAuth.
            // پیش از این registerData هیچ referral_code_used ای نمی‌گرفت ⇒ referred_by
            // هرگز ست نمی‌شد و پاداش معرفِ ثبت‌نام OAuth (تصمیم #3 دور ۱۶: «معلق تا
            // اولین تسک واقعی») هرگز ثبت نمی‌شد. مکانیزم = همان مسیر عادی ثبت‌نام
            // (AuthController::register:380-381): سشن register_referral_code که
            // showRegister هنگام ورود با ?ref=CODE ست می‌کند و سراسر ریدایرکت OAuth
            // زنده می‌ماند (همان PHP session؛ callback با state+session-binding
            // محافظت می‌شود). اعتبارسنجی واقعی کد (وجود معرف، عدم self-referral) و
            // ست‌شدن referred_by همان‌جا در UserService::register انجام می‌شود —
            // دقیقاً مثل فرم ثبت‌نام عادی؛ کد نامعتبر = شکست ثبت‌نام با همان پیام.
            // (ProcessRegistrationJob سمت دیگر با فیلد oauth_provider این فلو را
            // تشخیص می‌دهد و شاخهٔ pending را اجرا می‌کند.)
            $oauthReferralCode = trim(str_value($session->get('register_referral_code')));

            $registerData = [
                'email' => $email,
                'full_name' => $userData['name'] ?? '',
                'password' => bin2hex(random_bytes(16)),
                'oauth_provider' => $provider,
                'oauth_provider_id' => $providerId,
                'avatar' => $userData['picture'] ?? null,
                'email_verified_at' => ($userData['email_verified'] ?? false) ? date('Y-m-d H:i:s') : null,
            ];
            if ($oauthReferralCode !== '') {
                // FIX-R17F: در REGISTER_ALLOWED_FIELDS مجاز است؛ مقدار خالی = بدون معرف
                $registerData['referral_code_used'] = $oauthReferralCode;
            }

            // FIX-R18N (Task 18-N): گارد ضد-تقلب ثبت‌نام OAuth — دقیقاً هم‌تراز با مسیر
            // عادی (AuthController::register:418-434): فقط برای «ساخت کاربر جدید»؛
            // ورودِ حساب موجود (loginDirectly) و لینک حساب (linkSocialAccountJob و
            // شاخهٔ link + login) از این گارد عبور نمی‌کنند تا login-by-OAuth نشکند.
            // اکشن برگشتی مثل مسیر عادی محترم شمرده می‌شود: block ⇒ قطع فلوِ ثبت‌نام
            // با همان پیام کاربر-رو؛ challenge/limit از دید مسیر عادی allowed=true
            // هستند و ثبت‌نام ادامه می‌یابد. خطای infra داخل checkAction fail-closed
            // می‌شود (خودِ سرویس)؛ ترتیب: پیش از گیت R90 و پیش از register.
            if ($this->fraudGuard !== null) {
                $risk = $this->fraudGuard->checkAction(0, 'auth.register', [
                    'email'      => str_value($registerData['email'] ?? ''),
                    'phone'      => '',
                    'ip'         => $this->clientIp(),
                    'user_agent' => $this->userAgent(),
                    'provider'   => $provider,
                    'flow'       => 'oauth_registration',
                ]);
                if (empty($risk['allowed'])) {
                    $this->logger->warning('auth.oauth_registration_blocked_by_fraud_guard', [
                        'provider' => $provider,
                        'reason'   => $risk['reason'] ?? 'unknown',
                    ]);
                    return [
                        'success' => false,
                        'message' => 'امکان ثبت‌نام به دلیل تشخیص رفتارهای مشکوک مسدود گردید.',
                    ];
                }
            }

            // FIX-R18B: گیت R90 ضد-فارمینگ — قرینهٔ AuthController::register:426-430؛
            // سقف per-IP و آستانهٔ فارمینگ per-معرف، با حذف attribution (by-reference
            // روی $registerData) در سقف/block/ban. IP = IP کال‌بک OAuth (همان ورودی
            // request در مسیر عادی؛ ClientInfoTrait در محیط CLI/worker به 127.0.0.1
            // fail-open می‌شود) و سشن = همان سشن PHP کال‌بک (state+session-binding).
            // best-effort: گیت هرگز ثبت‌نام را نمی‌شکند (catch کامل داخل سرویس).
            $this->referralAntiFarmingGate->apply($registerData, $this->clientIp(), $session);

            $result = $this->authService->register($registerData);
            if (!($result['success'] ?? false)) {
                return $result;
            }

            // FIX-R17F: مصرف یک‌بارهٔ اتریبیوشن — قرینهٔ AuthController::register:440؛
            // فقط روی ثبت‌نام موفق (خطا = سشن برای تلاش بعدی می‌ماند، مثل مسیر عادی).
            // غیرمسدودکننده: شکست پاک‌سازی سشن هیچ‌گاه نتیجهٔ موفق ثبت‌نام را برنمی‌گرداند.
            try {
                if ($oauthReferralCode !== '') {
                    $session->remove('register_referral_code');
                }
            } catch (\Throwable $sessionEx) {
                $this->logger->warning('oauth.referral_session_cleanup_failed', ['error' => $sessionEx->getMessage()]);
            }

            // FIX-R18B: قرینهٔ AuthController::recordSignupActivity (FIX-R89-SIGNUPLOG) —
            // ردیف action='signup' در referral_activity_logs، منبع دادهٔ شمارندهٔ
            // per-IP گیت R90 (todaySignupCountByIp) است؛ بدون این ردیف، ثبت‌نام‌های
            // OAuth از سقف per-IP نامرئی می‌ماندند. best-effort — هیچ‌گاه نتیجهٔ
            // موفق ثبت‌نام را برنمی‌گرداند. پرچم referral = attributionِ سالمِ پس از گیت.
            try {
                $registeredUser = $result['user'] ?? null;
                $registeredUserId = int_value(is_object($registeredUser) ? ($registeredUser->id ?? 0) : 0);
                if ($registeredUserId > 0) {
                    $signupIp = $this->clientIp();
                    \App\Models\ReferralActivityLog::log(
                        $registeredUserId,
                        'signup',
                        $signupIp !== '' ? $signupIp : null,
                        ['referral' => !empty($registerData['referral_code_used'])],
                        $this->db,
                        $this->logger
                    );
                }
            } catch (\Throwable $signupLogEx) {
                $this->logger->warning('oauth.signup_activity_log_failed', ['error' => $signupLogEx->getMessage()]);
            }

            // link social account
            // FIX-R19-A6-1 (P1): پیش از این درجِ ردیف social_accounts روی «داشتن ایمیل»
            // گیت شده بود ($email !== null → findByEmail) و oauth_provider_id در users
            // هیچ قاری‌ای نداشت ⇒ برای provider بدون ایمیل (مثلاً فیسبوک بدون email
            // scope) جستجوی platform+provider_id (:343-346) در هر ورود بعدی miss
            // می‌شد و دوباره «کاربر جدید» ساخته می‌شد (حساب تکراری + کیف پول جدید در
            // هر لاگین). اکنون درجِ ردیف بدون شرط ایمیل انجام می‌شود: شناسهٔ کاربرِ
            // تازه از $result['user'] (نتیجهٔ register) و fallback findByEmail
            // خوانده می‌شود؛ فیلدها عیناً همان مسیر link + login (:388-396) است.
            // برخورد UNIQUE (رقابت هم‌زمان روی همان identity، FIX-R19-A6-2)
            // best-effort خنثی می‌شود تا ورودِ ثبت‌نامِ موفق نشکند؛ غیر آن rethrow.
            $newUser = $email !== null ? $this->userModel->findByEmail($email) : null;
            $newUserId = is_object($newUser) ? int_value($newUser->id ?? 0) : 0;
            if ($newUserId <= 0) {
                $registeredUser = $result['user'] ?? null;
                $newUserId = int_value(is_object($registeredUser) ? ($registeredUser->id ?? 0) : 0);
            }
            if ($newUserId > 0) {
                try {
                    $this->db->table('social_accounts')->insert([
                        'user_id' => $newUserId,
                        'platform' => $provider,
                        // FIX-X295 (راند ۷۱): username NOT NULL بدون پیش‌فرض است
                        'username' => str_value($userData['name'] ?? ('user_' . $providerId)),
                        'provider_id' => $providerId,
                        'avatar' => $userData['picture'] ?? null,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                } catch (\PDOException $linkDup) {
                    // FIX-R19-A6-1: ردیف social_accounts از قبل (توسط مسیر هم‌زمان)
                    // ساخته شده — ثبت‌نام موفق را با خطای لینک نمی‌شکنیم.
                    $isDup = ((string)$linkDup->getCode() === '23000')
                        || (isset($linkDup->errorInfo[1]) && (int)$linkDup->errorInfo[1] === 1062);
                    if (!$isDup) {
                        throw $linkDup;
                    }
                    $this->logger->warning('oauth.social_account_insert_duplicate', [
                        'provider' => $provider,
                        'user_id'  => $newUserId,
                    ]);
                }
                return $newUser ? $this->authService->loginDirectly($newUser) : $result;
            }

            return $result;
        } catch (\Throwable $e) {
            $this->logger->error("oauth.{$provider}.link_or_create_failed", ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => 'خطا در ایجاد یا اتصال حساب'];
        }
    }

    private function buildRedirectUri(string $path): string
    {
        return $this->urlGenerator->to($path);
    }
}
