<?php

declare(strict_types=1);

namespace App\Jobs\Auth;

class UnlinkSocialAccountJob
{
    private string $googleClientId;
    private string $googleClientSecret;
    private string $googleRedirectUri;
    private string $facebookClientId;
    private string $facebookClientSecret;
    private string $facebookRedirectUri;

    private \Core\Database $db;
    /** @var array<string, mixed> */
    private array $oAuthConfig;
    /** @param array<string, mixed> $oAuthConfig */
    /** @param array<string, mixed> $oAuthConfig */
public function __construct(
        \Core\Database $db,
        array $oAuthConfig = []
    ) {        $this->db = $db;
        $this->oAuthConfig = $oAuthConfig;

        $this->googleClientId = str_value($this->oAuthConfig['google_client_id'] ?? '');
        $this->googleClientSecret = str_value($this->oAuthConfig['google_client_secret'] ?? '');
        $this->googleRedirectUri = str_value($this->oAuthConfig['google_redirect_uri'] ?? '');
        $this->facebookClientId = str_value($this->oAuthConfig['facebook_client_id'] ?? '');
        $this->facebookClientSecret = str_value($this->oAuthConfig['facebook_client_secret'] ?? '');
        $this->facebookRedirectUri = str_value($this->oAuthConfig['facebook_redirect_uri'] ?? '');
    }

/** @return array<string, mixed> */
public function handle(int $userId, string $provider): array
    {
        $ok = $this->db->table('social_accounts')
            ->where('user_id', '=', $userId)
            ->where('provider', '=', $provider)
            ->delete();
        return ['success' => $ok, 'message' => $ok ? 'اتصال حساب با موفقیت جدا شد.' : 'خطا در جدا کردن اتصال حساب.'];
    }
}
