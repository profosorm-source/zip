<?php

declare(strict_types=1);

namespace App\Jobs\Auth;

class UnlinkSocialAccountJob
{
    private \Core\Database $db;

    public function __construct(\Core\Database $db)
    {
        $this->db = $db;
    }

/** @return array<string, mixed> */
public function handle(int $userId, string $provider): array
    {
        // FIX-R36-W3 (F-A18-05): گارد آخرین-اعتبارنامه — کاربرِ social-only که
        // رمزش را هرگز ندیده (پسورد OAuth = placeholder تصادفی، OAuthHelperTrait)
        // و ایمیل بازیابی ندارد، با unlinkِ تنها اتصالش برای همیشه بیرون می‌ماند
        // (کلاس عینی: Facebook-بدون-ایمیل). اگر این تنها اتصالِ کاربر باشد و
        // users.email خالی/ناموجود باشد، unlink رد می‌شود؛ کاربرِ دارای ایمیل
        // از مسیر بازیابی ایمیلی به‌دلیل پوشش داده می‌شود (تحلیل audit A18).
        // گارد در خود جاب (تک‌نقطهٔ حذف) تا هر caller آینده هم پوشیده باشد.
        $countStmt = $this->db->prepare(
            "SELECT COUNT(*) FROM social_accounts WHERE user_id = ?"
        );
        $countStmt->execute([$userId]);
        $socialCount = (int)$countStmt->fetchColumn();

        if ($socialCount === 1) {
            $userStmt = $this->db->prepare(
                "SELECT email FROM users WHERE id = ? LIMIT 1"
            );
            $userStmt->execute([$userId]);
            $email = (string)($userStmt->fetchColumn() ?: '');

            if (trim($email) === '') {
                return [
                    'success' => false,
                    'message' => 'این حساب تنها راه ورود شماست و ایمیل بازیابی ثبت نشده است؛ ابتدا ایمیل خود را در تنظیمات ثبت و تأیید کنید یا رمز عبور تنظیم کنید.',
                ];
            }
        }

        $ok = $this->db->table('social_accounts')
            ->where('user_id', '=', $userId)
            // FIX-X295 (راند ۷۱): ستون واقعی platform است نه provider
            ->where('platform', '=', $provider)
            ->delete();
        return ['success' => $ok, 'message' => $ok ? 'اتصال حساب با موفقیت جدا شد.' : 'خطا در جدا کردن اتصال حساب.'];
    }
}
