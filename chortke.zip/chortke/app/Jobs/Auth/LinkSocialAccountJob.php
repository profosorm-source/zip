<?php

declare(strict_types=1);

namespace App\Jobs\Auth;

class LinkSocialAccountJob
{
    private \App\Models\User $userModel;
    private \Core\Database $db;

    public function __construct(
        \App\Models\User $userModel,
        \Core\Database $db
    ) {
        $this->userModel = $userModel;
        $this->db = $db;
    }

/**
 * @param array<string, mixed> $userData
 * @return array<string, mixed>
 */
public function handle(int $userId, string $provider, array $userData): array
    {
        $user = $this->userModel->find($userId);
        if (!$user || in_array($user->status, ['locked', 'banned', 'suspended'], true)) {
            return ['success' => false, 'message' => 'امکان اتصال حساب برای این کاربر وجود ندارد.'];
        }

        // Check if this social account is already linked to ANOTHER user
        $existing = $this->db->table('social_accounts')
            // FIX-X295 (راند ۷۱): ستون واقعی platform است نه provider
            ->where('platform', '=', $provider)
            ->where('provider_id', '=', str_value($userData['id']))
            ->first();
            
        if ($existing) {
            if ((int)$existing->user_id === $userId) {
                return ['success' => true, 'message' => 'این حساب قبلاً به اکانت شما متصل شده است.'];
            }
            return ['success' => false, 'message' => 'این حساب اجتماعی قبلاً به اکانت دیگری متصل شده است.'];
        }

        // FIX-R19-A6-2: قبلاً check-then-insert خالص بود (TOCTOU) و جدول هیچ UNIQUE
        // نداشت؛ دو فلو هم‌زمان می‌توانستند همان identity را به دو کاربر ببندند.
        // UNIQUE(platform, provider_id) — مایگریشن 2026_09_20_0006 — حصار واقعی است و
        // نقض آن (23000/1062) به همان پاسخ «قبلاً متصل شده» ترجمه می‌شود
        // (الگوی RateVitrineListingJob:84-93).
        try {
            $ok = $this->db->table('social_accounts')->insert([
                'user_id'     => $userId,
                'platform'    => $provider,
                // FIX-X295 (راند ۷۱): username NOT NULL بدون پیش‌فرض است
                'username'    => str_value($userData['name'] ?? ('user_' . str_value($userData['id'] ?? ''))),
                'provider_id' => str_value($userData['id']),
                'avatar'      => $userData['picture'] ?? null,
                'created_at'  => date('Y-m-d H:i:s')
            ]);
        } catch (\PDOException $dupCandidate) {
            $isDuplicate = ((string)$dupCandidate->getCode() === '23000')
                || (isset($dupCandidate->errorInfo[1]) && (int)$dupCandidate->errorInfo[1] === 1062);
            if (!$isDuplicate) {
                throw $dupCandidate;
            }
            // رقابت هم‌زمان باخته است — بازخوانی برای پاسخ دقیق (هم‌کاربر = موفق مهربان).
            $winner = $this->db->table('social_accounts')
                ->where('platform', '=', $provider)
                ->where('provider_id', '=', str_value($userData['id']))
                ->first();
            if ($winner && (int)$winner->user_id === $userId) {
                return ['success' => true, 'message' => 'این حساب قبلاً به اکانت شما متصل شده است.'];
            }
            return ['success' => false, 'message' => 'این حساب اجتماعی قبلاً به اکانت دیگری متصل شده است.'];
        }

        return ['success' => $ok, 'message' => $ok ? 'حساب با موفقیت متصل شد.' : 'خطا در اتصال حساب.'];
    }
}
