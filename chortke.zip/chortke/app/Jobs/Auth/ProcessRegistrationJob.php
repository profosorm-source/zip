<?php

declare(strict_types=1);

namespace App\Jobs\Auth;

use App\Services\User\UserService;

class ProcessRegistrationJob
{
    #[ \Core\Attributes\Inject ]
    private UserService $userService;

    // 🛡️ FIX-DEAD-EVENT: وابستگی outbox حذف شد — تنها مصرف‌کننده‌اش رویداد مردهٔ
    // auth.register بود که حذف شد.

    #[ \Core\Attributes\Inject ]
    private \App\Contracts\WalletServiceInterface $walletService;

    #[ \Core\Attributes\Inject ]
    private \App\Contracts\LoggerInterface $logger;

    #[ \Core\Attributes\Inject ]
    private \App\Models\User $userModel;

    #[ \Core\Attributes\Inject ]
    private \App\Services\Shared\ReferralService $referralService;

    public function __construct(
        UserService $userService,
        \App\Contracts\WalletServiceInterface $walletService,
        \App\Contracts\LoggerInterface $logger,
        \App\Models\User $userModel,
        \App\Services\Shared\ReferralService $referralService
    ) {
        $this->userService = $userService;
        $this->walletService = $walletService;
        $this->logger = $logger;
        $this->userModel = $userModel;
        $this->referralService = $referralService;
    }

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
public function handle(array $data): array
    {
        try {
            $result = $this->userService->register($data);
        } catch (\InvalidArgumentException $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        } catch (\Throwable $e) {
            $this->logger->error('auth.registration.failed', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.'];
        }

        if (!$result) {
            return ['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.'];
        }

        $userId = int_value($result['id'] ?? 0);

        // GUARANTEE: Create wallet immediately to prevent financial paralysis
        try {
            $this->walletService->getOrCreateWallet($userId);
        } catch (\Throwable $e) {
            $this->logger->critical('wallet.creation_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        // RF-01: Apply signup referral bonus (fixed amount) once the referred user and wallet exist.
        try {
            $createdUser = $this->userModel->find($userId);
            $referrerId = (int)($createdUser->referred_by ?? 0);
            if ($referrerId > 0) {
                // R12 راند ۸۸ — اتصال کلیک بی‌نام به کاربر جدید (log-only؛ مانع بونوس نمی‌شود)
                try {
                    $this->markReferralConverted(int_value($userId), (int)$referrerId);
                } catch (\Throwable $e) {
                    $this->logger->warning('referral.click_conversion_failed', [
                        'user_id'     => $userId,
                        'referrer_id' => $referrerId,
                        'error'       => $e->getMessage(),
                    ]);
                }
                $this->referralService->awardSignupBonus(int_value($userId), 'irt');
            }
        } catch (\Throwable $e) {
            $this->logger->error('referral.signup_bonus_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        // Dispatch UserRegisteredEvent for other welcome flows (emails, bonuses, etc.)
        \Core\EventDispatcher::getInstance()->dispatch(
            \App\Events\UserRegisteredEvent::class, 
            new \App\Events\UserRegisteredEvent(
                int_value($userId), 
                str_value($data['email'] ?? ''), 
                client_ip()
            )
        );

        // 🛡️ FIX-DEAD-EVENT: رویداد auth.register هیچ listener ای ندارد؛
        // UserRegisteredEvent هم‌زمان sync دیسپچ می‌شود و رکورد کاربر منبع حقیقت است
        // → رکورد بی‌اثر حذف شد.

        return ['success' => true, 'message' => 'ثبت‌نام با موفقیت انجام شد.', 'user' => $this->userModel->find($userId)];
    }

    /**
     * R12 راند ۸۸ — اتصال کلیک بی‌نام به کاربر جدید.
     *
     * تا پیش از این، کلیک‌های رفرال بی‌نام (click_user_id NULL) هیچ‌گاه به
     * کاربر واقعی متصل نمی‌شدند و JOIN آماری
     *   referral_commissions ⋈ referral_clicks (referrer_id, referred_user_id = click_user_id)
     * برای کاربرانِ ثبت‌نام‌شده همیشه خالی می‌ماند. این متد آخرین کلیک بی‌نامِ
     * همین معرف را به کاربر تازه‌وارد نسبت می‌دهد و پرچم converted را ۱ می‌کند؛
     * اگر هیچ کلیک بی‌نامی وجود نداشت (مثلاً لندینگِ پیش از پیاده‌سازی R12-a
     * یا پرش مستقیم به ثبت‌نام)، fallback: یک ردیف کاملِ تبدیل‌شده INSERT می‌شود
     * تا داشبورد معرف «تبدیل» را ببیند.
     *
     * راهبرد اتمی: یک UPDATE با ORDER BY referred_at DESC LIMIT 1 (rowCount =
     * تعداد اثرشده) — بدون پنجرهٔ رقابتِ SELECT-then-UPDATE؛ مسیر fallback
     * فقط وقتی اجرا می‌شود که صفر ردیف اثر شده باشد.
     */
    public function markReferralConverted(int $newUserId, int $referrerId): void
    {
        $db = $this->userModel->getDb();

        $affected = $db->execute(
            "UPDATE referral_clicks
             SET click_user_id = ?, converted = 1
             WHERE referrer_id = ? AND click_user_id IS NULL
             ORDER BY referred_at DESC
             LIMIT 1",
            [$newUserId, $referrerId]
        );

        if ($affected > 0) {
            return;
        }

        // fallback: کلیک بی‌نامی وجود ندارد → ردیف تبدیل کامل (بدون ip/ua) ثبت شود
        $db->table('referral_clicks')->insert([
            'referrer_id'   => $referrerId,
            'click_user_id' => $newUserId,
            'converted'     => 1,
        ]);
    }

}
