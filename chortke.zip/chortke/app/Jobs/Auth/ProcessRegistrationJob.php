<?php

declare(strict_types=1);

namespace App\Jobs\Auth;

use App\Services\User\UserService;

class ProcessRegistrationJob
{
    #[ \Core\Attributes\Inject ]
    private UserService $userService;

    // 🛡️ FIX-DEAD-EVENT: وابستگی outbox حذف شد — تنها مصرف‌کننده‌اش رویداد مردهٔ
    // auth.register بود که حذف شد.

    #[ \Core\Attributes\Inject ]
    private \App\Contracts\WalletServiceInterface $walletService;

    #[ \Core\Attributes\Inject ]
    private \App\Contracts\LoggerInterface $logger;

    #[ \Core\Attributes\Inject ]
    private \App\Models\User $userModel;

    #[ \Core\Attributes\Inject ]
    private \App\Services\Shared\ReferralService $referralService;

    public function __construct(
        UserService $userService,
        \App\Contracts\WalletServiceInterface $walletService,
        \App\Contracts\LoggerInterface $logger,
        \App\Models\User $userModel,
        \App\Services\Shared\ReferralService $referralService
    ) {
        $this->userService = $userService;
        $this->walletService = $walletService;
        $this->logger = $logger;
        $this->userModel = $userModel;
        $this->referralService = $referralService;
    }

/**
 * @param array<string, mixed> $data
 * @return array<string, mixed>
 */
public function handle(array $data): array
    {
        try {
            $result = $this->userService->register($data);
        } catch (\InvalidArgumentException $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        } catch (\Throwable $e) {
            $this->logger->error('auth.registration.failed', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.'];
        }

        if (!$result) {
            return ['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.'];
        }

        $userId = int_value($result['id'] ?? 0);

        // GUARANTEE: Create wallet immediately to prevent financial paralysis
        try {
            $this->walletService->getOrCreateWallet($userId);
        } catch (\Throwable $e) {
            $this->logger->critical('wallet.creation_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        // RF-01: Apply signup referral bonus (fixed amount) once the referred user and wallet exist.
        try {
            $createdUser = $this->userModel->find($userId);
            $referrerId = (int)($createdUser->referred_by ?? 0);
            if ($referrerId > 0) {
                // R12 راند ۸۸ — اتصال کلیک بی‌نام به کاربر جدید (log-only؛ مانع بونوس نمی‌شود)
                try {
                    $this->markReferralConverted(int_value($userId), (int)$referrerId);
                } catch (\Throwable $e) {
                    $this->logger->warning('referral.click_conversion_failed', [
                        'user_id'     => $userId,
                        'referrer_id' => $referrerId,
                        'error'       => $e->getMessage(),
                    ]);
                }
                // FIX-R14 (آیتم ۲ دور ۱۴): پاداش معرف دیگر در لحظهٔ ثبت‌نام پرداخت
                // نمی‌شود — گیت صریح تأیید ایمیل: تنها وقتی معرفی‌شده از قبل
                // تأییدشده است (لبهٔ نادر: ادمین/OAuth) همان‌جا اعطا می‌شد؛
                // در حالت عادی (تازه‌ثبت‌نام = email_verified_at NULL) اعطا به
                // مسیر تأیید ایمیل منتقل می‌شود — قلاب ReferralService::
                // onReferredUserVerified از UserService::verifyEmail.
                //
                // ── FIX-R16A (Task 16-A) — بازنویسی شاخهٔ تأییدشده-پیش-از-ثبت‌نام ──
                // سیاست مالک پروژه (2026-09-20):
                // "OAuth-referred users: referrer reward deferred until referred
                //  user's first completed task (anti-fraud holding). Email-verified
                //  users: reward on verification."
                // در این شاخه دیگر «پرداخت فوری» انجام نمی‌شود (پرداخت فوری از قلاب
                // گذار تأیید ایمیل عبور می‌کرد و ضدکلاهبرداری نبود). به‌جایش فقط یک
                // ردیف کمیسیون pending در referral_commissions ثبت می‌شود (ساختار
                // موجود، بدون مایگریشن) و اعتبار واقعی وقتی انجام می‌شود که
                // معرفی‌شده اولین تسک واقعی‌اش را کامل کند — قلاب
                // ReferralService::creditPendingReferralRewardOnFirstTask از
                // ApproveSocialTaskExecutionJob (نقطهٔ increment شدن
                // completed_count) صدا زده می‌شود. مستند کامل سیاست در
                // ReferralService::recordPendingReferralRewardForVerifiedUser.
                //
                // ── FIX-R17F (Task 17-F) — شاخهٔ OAuth: همیشه مسیر معلق ──
                // سیاست مالک پروژه (تصمیم #3 دور ۱۶): پاداش معرفِ ثبت‌نام OAuth همیشه
                // تا «اولین تسک واقعی» معلق است — مستقل از وضعیت تأیید ایمیل. گیت قبلی
                // (!empty($createdUser->email_verified_at)) برای OAuth هرگز برقرار نبود:
                // UserService::register:127 مقدار email_verified_at را بی‌قید و شرط null
                // می‌کند (Mass Assignment Protection) ⇒ شاخهٔ pending غیرقابل‌رسیدن بود
                // (شکاف مستند 17-B). تشخیص فلو OAuth: تنها فراخوانِ دیگرِ
                // AuthService::register، یعنی OAuthHelperTrait::linkOrCreateUser، فیلد
                // oauth_provider را پاس می‌دهد؛ مسیر عادی (AuthController::register با
                // request->only ۸ فیلدی) هرگز آن را ندارد. تداخل پرداخت ناممکن است:
                // ردیف pending با همان کلید referral_signup_{ref}_{user} نوشته می‌شود ⇒
                // قلاب بعدیِ تأیید ایمیل (onReferredUserVerified → awardSignupBonus)
                // duplicate=true می‌گیرد و واریز فوری انجام نمی‌شود؛ تنها
                // creditPendingReferralRewardOnFirstTask (اولین تسک) آن را پرداخت می‌کند.
                $isOauthRegistration = !empty($data['oauth_provider']); // FIX-R17F
                if ($isOauthRegistration || !empty($createdUser->email_verified_at)) {
                    try {
                        $this->referralService->recordPendingReferralRewardForVerifiedUser(int_value($userId));
                    } catch (\Throwable $pendingRewardError) {
                        // غیرمسدودکننده: ثبت پاداش معلق هرگز ثبت‌نام OAuth را نمی‌شکند
                        $this->logger->warning('referral.oauth_pending_reward_dispatch_failed', [
                            'user_id'     => int_value($userId),
                            'referrer_id' => $referrerId,
                            'error'       => $pendingRewardError->getMessage(),
                        ]);
                    }
                } else {
                    $this->logger->info('referral.signup_bonus_deferred_until_email_verification', [
                        'user_id'     => $userId,
                        'referrer_id' => $referrerId,
                    ]);
                }
            }
        } catch (\Throwable $e) {
            $this->logger->error('referral.signup_bonus_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        // Dispatch UserRegisteredEvent for other welcome flows (emails, bonuses, etc.)
        // 🛡️ FIX-S18-5 (Medium — S18-AUDIT): plainToken به رویداد پاس می‌شود —
        // قبلاً سازنده بدون plainToken صدا زده می‌شد و LogUserRegisteredActivity
        // به fallback «هشِ ذخیره‌شده» می‌افتاد ⇒ ایمیل تأییدِ ثبت‌نام لینکِ
        // هرگز-معتبر نمی‌فرستاد (hash(hmac) ≠ رکورد). دیسپچ sync و in-memory
        // است؛ توکن خام هیچ‌جا persist نمی‌شود (ستون DB هش است — FIX-S18-5a).
        \Core\EventDispatcher::getInstance()->dispatch(
            \App\Events\UserRegisteredEvent::class, 
            new \App\Events\UserRegisteredEvent(
                int_value($userId), 
                str_value($data['email'] ?? ''), 
                client_ip(),
                (str_value($result['plain_token'] ?? '') !== '' ? str_value($result['plain_token']) : null)
            )
        );

        // 🛡️ FIX-DEAD-EVENT: رویداد auth.register هیچ listener ای ندارد؛
        // UserRegisteredEvent هم‌زمان sync دیسپچ می‌شود و رکورد کاربر منبع حقیقت است
        // → رکورد بی‌اثر حذف شد.

        return ['success' => true, 'message' => 'ثبت‌نام با موفقیت انجام شد.', 'user' => $this->userModel->find($userId)];
    }

    /**
     * R12 راند ۸۸ — اتصال کلیک بی‌نام به کاربر جدید.
     *
     * تا پیش از این، کلیک‌های رفرال بی‌نام (click_user_id NULL) هیچ‌گاه به
     * کاربر واقعی متصل نمی‌شدند و JOIN آماری
     *   referral_commissions ⋈ referral_clicks (referrer_id, referred_user_id = click_user_id)
     * برای کاربرانِ ثبت‌نام‌شده همیشه خالی می‌ماند. این متد آخرین کلیک بی‌نامِ
     * همین معرف را به کاربر تازه‌وارد نسبت می‌دهد و پرچم converted را ۱ می‌کند؛
     * اگر هیچ کلیک بی‌نامی وجود نداشت (مثلاً لندینگِ پیش از پیاده‌سازی R12-a
     * یا پرش مستقیم به ثبت‌نام)، fallback: یک ردیف کاملِ تبدیل‌شده INSERT می‌شود
     * تا داشبورد معرف «تبدیل» را ببیند.
     *
     * راهبرد اتمی: یک UPDATE با ORDER BY referred_at DESC LIMIT 1 (rowCount =
     * تعداد اثرشده) — بدون پنجرهٔ رقابتِ SELECT-then-UPDATE؛ مسیر fallback
     * فقط وقتی اجرا می‌شود که صفر ردیف اثر شده باشد.
     */
    public function markReferralConverted(int $newUserId, int $referrerId): void
    {
        $db = $this->userModel->getDb();

        $affected = $db->execute(
            "UPDATE referral_clicks
             SET click_user_id = ?, converted = 1
             WHERE referrer_id = ? AND click_user_id IS NULL
             ORDER BY referred_at DESC
             LIMIT 1",
            [$newUserId, $referrerId]
        );

        if ($affected > 0) {
            return;
        }

        // fallback: کلیک بی‌نامی وجود ندارد → ردیف تبدیل کامل (بدون ip/ua) ثبت شود
        $db->table('referral_clicks')->insert([
            'referrer_id'   => $referrerId,
            'click_user_id' => $newUserId,
            'converted'     => 1,
        ]);
    }

}
