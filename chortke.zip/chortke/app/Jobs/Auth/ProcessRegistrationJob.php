<?php

declare(strict_types=1);

namespace App\Jobs\Auth;

use App\Services\User\UserService;

class ProcessRegistrationJob
{
    private UserService $userService;
    private ?\App\Contracts\OutboxServiceInterface $outbox;
    private \App\Contracts\WalletServiceInterface $walletService;
    private \App\Contracts\LoggerInterface $logger;
    private \App\Models\User $userModel;

    public function __construct(
        UserService $userService,
        \App\Contracts\WalletServiceInterface $walletService,
        \App\Contracts\LoggerInterface $logger,
        \App\Models\User $userModel,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {
        $this->userService = $userService;
        $this->walletService = $walletService;
        $this->logger = $logger;
        $this->userModel = $userModel;
        $this->outbox = $outbox;
    }

    public function handle(array $data): array
    {
        try {
            $result = $this->userService->register($data);
        } catch (\InvalidArgumentException $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        } catch (\Throwable $e) {
            $this->logger->error('auth.registration.failed', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.'];
        }

        if (!$result) {
            return ['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.'];
        }

        $userId = $result['id'];

        // GUARANTEE: Create wallet immediately to prevent financial paralysis
        try {
            $this->walletService->getOrCreateWallet($userId);
        } catch (\Throwable $e) {
            $this->logger->critical('wallet.creation_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        // RF-01: Apply signup referral commission once the referred user and wallet exist.
        try {
            $createdUser = $this->userModel->find($userId);
            $referrerId = (int)($createdUser->referred_by ?? 0);
            if ($referrerId > 0) {
                $baseAmount = (string)(setting('referral_signup_commission_base', setting('referral_signup_bonus_base', 1000)) ?: 1000);
                \Core\Container::getInstance()
                    ->make(\App\Services\Shared\ReferralService::class)
                    ->processCommission($referrerId, $baseAmount, 'irt', [
                        'user_id' => (int)$userId,
                        'source_type' => 'signup',
                        'idempotency_key' => "ref_signup_{$referrerId}_{$userId}",
                    ]);
            }
        } catch (\Throwable $e) {
            $this->logger->error('referral.signup_commission_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        // Dispatch UserRegisteredEvent for other welcome flows (emails, bonuses, etc.)
        \Core\EventDispatcher::getInstance()->dispatch(
            \App\Events\UserRegisteredEvent::class, 
            new \App\Events\UserRegisteredEvent(
                (int)$userId, 
                $data['email'] ?? '', 
                client_ip()
            )
        );

        $this->outbox?->record('auth', $userId, 'auth.register', [
            'user_id' => $userId,
            'email' => $data['email'] ?? '',
            'ip' => client_ip(),
        ]);

        return ['success' => true, 'message' => 'ثبت‌نام با موفقیت انجام شد.', 'user' => $this->userModel->find($userId)];
    }

}
