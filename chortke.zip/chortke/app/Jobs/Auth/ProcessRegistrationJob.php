<?php

declare(strict_types=1);

namespace App\Jobs\Auth;

use App\Services\User\UserService;

class ProcessRegistrationJob
{
    #[ \Core\Attributes\Inject ]
    private UserService $userService;

    #[ \Core\Attributes\Inject ]
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;

    #[ \Core\Attributes\Inject ]
    private \App\Contracts\WalletServiceInterface $walletService;

    #[ \Core\Attributes\Inject ]
    private \App\Contracts\LoggerInterface $logger;

    #[ \Core\Attributes\Inject ]
    private \App\Models\User $userModel;

    #[ \Core\Attributes\Inject ]
    private \App\Services\Shared\ReferralService $referralService;

    public function __construct(?\App\Contracts\OutboxServiceInterface $outbox = null)
    {
        if ($outbox !== null) {
            $this->outbox = $outbox;
        }
    }

    public function handle(array $data): array
    {
        try {
            $result = $this->userService->register($data);
        } catch (\InvalidArgumentException $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->logger->error('auth.registration.failed', ['error' => $e->getMessage()]);
            return ['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.'];
        }

        if (!$result) {
            return ['success' => false, 'message' => 'ثبت‌نام با خطا مواجه شد.'];
        }

        $userId = $result['id'];

        // GUARANTEE: Create wallet immediately to prevent financial paralysis
        try {
            $this->walletService->getOrCreateWallet($userId);
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->logger->critical('wallet.creation_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        // RF-01: Apply signup referral commission once the referred user and wallet exist.
        try {
            $createdUser = $this->userModel->find($userId);
            $referrerId = (int)($createdUser->referred_by ?? 0);
            if ($referrerId > 0) {
                $baseAmount = (string)(setting('referral_signup_commission_base', setting('referral_signup_bonus_base', 1000)) ?: 1000);
                $this->referralService
                    ->processCommission($referrerId, $baseAmount, 'irt', [
                        'user_id' => (int)$userId,
                        'source_type' => 'signup',
                        'idempotency_key' => "ref_signup_{$referrerId}_{$userId}",
                    ]);
            }
        } catch (\Throwable $e) { error_log(__FILE__ . ":" . __LINE__ . " suppressed: " . $e->getMessage());
            $this->logger->error('referral.signup_commission_failed', ['user_id' => $userId, 'error' => $e->getMessage()]);
        }

        // Dispatch UserRegisteredEvent for other welcome flows (emails, bonuses, etc.)
        \Core\EventDispatcher::getInstance()->dispatch(
            \App\Events\UserRegisteredEvent::class, 
            new \App\Events\UserRegisteredEvent(
                (int)$userId, 
                $data['email'] ?? '', 
                client_ip()
            )
        );

        $this->outbox?->record('auth', $userId, 'auth.register', [
            'user_id' => $userId,
            'email' => $data['email'] ?? '',
            'ip' => client_ip(),
        ]);

        return ['success' => true, 'message' => 'ثبت‌نام با موفقیت انجام شد.', 'user' => $this->userModel->find($userId)];
    }

}
