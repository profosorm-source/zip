<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Contracts\LoggerInterface;
use Core\Cache;
use Core\Database;

/**
 * CacheWarmupJob
 *
 * FIX-R36-W3 (F-A18-02): چهار خانوادهٔ کلیدیِ نوشته‌شدهٔ قبلی هیچ خواننده‌ای نداشتند
 * (feature_flag:{name} / sys_config:{key} / user_active_state:{id} / dummy tagهای
 * search:module:* + کلید admin_dashboard_summary) — گرمِ مرده = اسکن کامل
 * feature_flags/system_settings + حلقهٔ ۱۰۰۰کاربره در هر اجرا بدون هیچ Hit.
 * اکنون تنها خوانندهٔ واقعیِ قابل پیش‌گرم گرم می‌شود: اسنپ‌شات
 * AppSettings::load() (کلید واقعی خواننده، شکل درست، stampede-protected،
 * secretها رمزنگاری‌شده). فلگ‌ها قابل پیش‌گرم مؤثر نیستند (کلید خواننده
 * per-user/context با TTL ۵ثانیه‌ای است) و متدهای مرده به stub مستند تبدیل
 * شدند (بدون اسکن/نوشتن). پیشنهاد cross-domain: حذف کامل stubها + همین جاب
 * در پاس پاک‌سازی آینده اگر مصرف‌کنندهٔ واقعی تعریف نشد.
 *
 * گرم کردن کش‌های حیاتی پس از cold start یا هنگامی که TTL منقضی می‌شود:
 * - اسنپ‌شات تنظیمات سیستم (AppSettings)
 */
class CacheWarmupJob
{
    private const FEATURE_FLAG_TTL  = 600;  // 10 دقیقه
    private const CONFIG_TTL        = 3600; // 1 ساعت
    private const DASHBOARD_TTL     = 300;  // 5 دقیقه

    private Database $db;
    private Cache $cache;
    private LoggerInterface $logger;
    private ?\App\Services\Settings\AppSettings $appSettings;
    public function __construct(
        Database $db,
        Cache $cache,
        LoggerInterface $logger,
        ?\App\Services\Settings\AppSettings $appSettings = null
    ) {        $this->db = $db;
        $this->cache = $cache;
        $this->logger = $logger;
        $this->appSettings = $appSettings;
}

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data = []): void
    {
        // اصلاح کلیدی معماری همزمانی در گرمایش کش (Cache Warmup Mutex Guard):
        // استفاده از قفل همزمانی کش جهت جلوگیری از اجرای موازی واکشی‌های سنگین جداول تنظیمات و جلوگیری از پدیده هجوم به کش (Cache Stampede)
        $lockKey = 'mutex:cache_warmup_execution';
        if (!$this->cache->lock($lockKey, 180, 2)) {
            $this->logger->info('cache.warmup_skipped_locked', []);
            return;
        }

        try {
            $warmed = 0;

            // FIX-R36-W3 (F-A18-02): فقط گرم‌کردنِ واقعی باقی مانده — خانواده‌های
            // مرده (feature_flag:* / user_active_state:* / dummy tags / dashboard
            // summary) دیگر اسکن و نوشته نمی‌شوند.
            $warmed += $this->warmSystemConfigs();

            $this->logger->info('cache.warmup.completed', ['warmed_keys' => $warmed]);
        } finally {
            try { $this->cache->unlock($lockKey); } catch (\Throwable $err) {}
        }
    }

    /**
     * FIX-R36-W3 (F-A18-02): stub مستند — قبلاً کلیدهای feature_flag:{name} را
     * می‌نوشت که هیچ خواننده‌ای ندارد؛ خوانندهٔ واقعی (FeatureFlagService::isEnabled)
     * کلید per-user/context با TTL ۵ثانیه‌ای می‌خواند که پیش‌گرم‌پذیر نیست.
     * اسکن و نوشتنِ مرده حذف شد.
     */
    private function warmFeatureFlags(): int
    {
        return 0;
    }

    /**
     * گرم کردن اسنپ‌شات تنظیمات سیستم از مسیرِ خوانندهٔ واقعی (AppSettings::load)
     * FIX-R36-W3 (F-A18-02): قبلاً sys_config:{key} می‌نوشت (خوانندهٔ صفر).
     * اکنون snapshot واقعیِ stampede-protected خوانندهٔ اصلی populate می‌شود —
     * شکل/کلید/TTL همیشه دقیقاً همان چیزی است که مصرف‌کنندگان می‌خوانند.
     */
    private function warmSystemConfigs(): int
    {
        try {
            if ($this->appSettings === null) {
                return 0;
            }
            $snapshot = $this->appSettings->load();
            return is_array($snapshot) ? count($snapshot) : 0;
        } catch (\Throwable $e) {
            $this->logger->warning('cache.warmup.system_settings_failed', ['error' => $e->getMessage()]);
            return 0;
        }
    }

    /**
     * FIX-R36-W3 (F-A18-02): stub مستند — کلید admin_dashboard_summary هیچ
     * خواننده‌ای ندارد (فقط همین جاب می‌نوشت) و هر اجرا ۴ COUNT سنگین بود.
     * پیشنهاد: یا خوانندهٔ واقعی تعریف شود یا کل جاب در پاس پاک‌سازی حذف گردد.
     */
    private function warmDashboardSummary(): int
    {
        return 0;
    }

    /**
     * FIX-R36-W3 (F-A18-02): stub مستند — کلیدهای user_active_state:{id} هیچ
     * خواننده‌ای ندارند؛ اسکن last_login + حلقهٔ ۱۰۰۰ نوشتهٔ مرده حذف شد.
     */
    private function warmUserSessions(): int
    {
        return 0;
    }

    /**
     * FIX-R36-W3 (F-A18-02): stub مستند — ساخت tag-structure با کلید dummy
     * (search:module:* → warmup_dummy) هیچ مصرف‌کننده‌ای ندارد.
     */
    private function warmSearchCache(): int
    {
        return 0;
    }
}
