<?php

declare(strict_types=1);

namespace App\Jobs\SocialTask;

use App\Models\SocialTaskExecutionModel;
use App\Services\Shared\IdempotencyService;
use App\Services\SocialTask\BehaviorAnalysisService;
use App\Services\SocialTask\CameraVerificationService;

class SubmitSocialTaskExecutionJob
{
    // 🛡️ FIX-10a-F1 (R10 audit P1): عبور از آستانهٔ auto-approve «لازم» است اما «کافی»
    // نیست — آزادسازی خودکار اسکرو/پاداش فقط با اثباتِ قابل‌راستی‌آزماییِ پلتفرم
    // مجاز می‌شود؛ تلومتری خوداظهاری کلاینت هرگز به‌تنهایی تصمیمِ پرداخت نمی‌گیرد
    // (برچسب/پیام تصمیم در calculateFinalScore و گیتِ شاخهٔ approve در handle با
    // همین قرارداد هم‌خوانند).
    //
    // 🛡️ FIX-S21-01 (بازبینی بخش ۲۱، P2): منبعِ فعلیِ آن اثبات (سهمِ مؤثرِ
    // دوربین > 0) خودش از دو عددِ خوداظهاریِ کلاینت می‌آید (camera_score +
    // frame_count) و رکوردِ server-createdِ «completed» فقط تکمیلِ فلو را
    // اثبات می‌کند نه صحتِ capture را — بنابراین تا فرود وریفایر سمت‌سرورِ
    // واقعی، هیچ مسیرِ کلاینتی proof تولید نمی‌کند (fail-closed؛ رفعِ
    // بینابینیِ توصیه‌شدهٔ گزارش).
    // 🎯 D4 (تصمیم مالک ۲۰۲۶-۱۰-۲۶ — کاهش سخت‌گیری برای کوچک‌شدن صف بررسی):
    // آستانهٔ auto-approve از ۷۰ به ۶۰ کاهش یافت. با سقف نظری مسیر دوربین
    // (0.35×behavior(65) + 0.20×time(100) + 0.15×interaction(100) + 15 = 72.75)
    // نوار ۷۰ عملاً دست‌نیافتنی بود و تقریباً همهٔ اجراهای صادقانه به
    // manual_review می‌رفتند. سپرهای ضدتقلب همگی دست‌نخورده‌اند: گیت اثبات
    // سروری (hasTrustedVerdict)، بازبینی تصادفی camera_pass_audit_ratio،
    // سقف روزانهٔ camera_pass_daily_limit و گارد ضدتقلب سراسری.
    private const AUTO_APPROVE_SCORE = 60.0;
    private const REJECT_SCORE = 45.0;

    public function __construct(
        private SocialTaskExecutionModel $executionModel,
        private IdempotencyService $idempotencyService,
        private BehaviorAnalysisService $behaviorAnalysis,
        private CameraVerificationService $cameraVerification,
        private ApproveSocialTaskExecutionJob $approveJob,
        private RejectSocialTaskExecutionJob $rejectJob,
        // FIX-R18N (Task 18-N — P0 REVIEW_ROUND18 #1/11): گارد ضد-تقلب سراسری (اختیاری) —
        // پیش از این، موتور ضد-فارمینگِ task.social (CheckTaskFraudJob شاخهٔ Silent)
        // یتیم بود و امتیاز فقط از سیگنال‌های کلاینت محاسبه می‌شد (auto-approve پول).
        // Nullable-DI هم‌الگوی سایر وابستگی‌های nullable این فایل.
        private ?\App\Services\AntiFraud\FraudGuardService $fraudGuard = null
    ) {}

/**
 * @param array<string, mixed> $payload
 * @return array<string, mixed>
 */
public function handle(int $userId, int $executionId, array $payload = []): array
    {
        $explicitKey = str_value($payload['idempotency_key'] ?? '');
        if ($explicitKey === '') {
            $explicitKey = 'social_task_complete_' . $userId . '_' . $executionId . '_' . md5((string)json_encode([
                'active_time' => $payload['active_time'] ?? null,
                'behavior_signals' => $payload['behavior_signals'] ?? null,
                'camera_token' => $payload['camera_token'] ?? null,
            ], JSON_UNESCAPED_UNICODE));
        }

        return $this->idempotencyService->execute(
            'social_task.complete',
            $userId,
            ['execution_id' => $executionId, 'idempotency_key' => $explicitKey],
            function () use ($userId, $executionId, $payload) {
                $exec = $this->executionModel->getExecutionWithAd($executionId, $userId, false);
                if (!$exec) {
                    return ['success' => false, 'message' => 'رکورد اجرا یافت نشد.'];
                }
                if (!in_array((string)$exec->status, ['in_progress', 'started'], true)) {
                    return ['success' => false, 'message' => 'وضعیت اجرا برای محاسبه نتیجه مناسب نیست.'];
                }

                // SocialTask در معماری جدید proofless است: کاربر متن/لینک/اسکرین‌شات ارسال نمی‌کند.
                // تصمیم بر اساس الگوی انسانی، زمان فعال، تعامل، و در صورت نیاز camera verification گرفته می‌شود.
                // FIX-R18N (#5c): دادهٔ ذخیره‌شدهٔ رفتاری (سرور) جدا نگه داشته می‌شود تا
                // مقادیر authoritative (active_time/fingerprint) با ادعاهای کلاینت max() نشوند.
                $storedBehaviorData = $this->decodeBehaviorData($exec->behavior_data ?? null);
                $behaviorData = $storedBehaviorData;
                if (!empty($payload['behavior_signals']) && is_array($payload['behavior_signals'])) {
                    $behaviorData = array_merge($behaviorData, $payload['behavior_signals']);
                }

                $started = strtotime((string)($exec->started_at ?? $exec->created_at));
                // FIX-R18N (#5c): active_time ذخیره‌شدهٔ سرویس مرجع است — مقدارِ اعلامی
                // کلاینت (payload/behavior_signals) هرگز با آن max() نمی‌شود (تورم امتیاز زمان).
                $storedActiveTime = max(0, int_value($storedBehaviorData['active_time'] ?? 0), int_value($storedBehaviorData['session_duration'] ?? 0));
                $serverElapsed = max(0, time() - ($started ?: time()));
                // FIX-R36-W1 (F-A10-01): active_time ذخیره‌شده خودش جمعِ سیگنال‌های
                // ادعایی کلاینت است → هرگز از زمان سپری‌شدهٔ واقعیِ سمت سرور بزرگ‌تر
                // نمی‌شود؛ پمپاژ active_time دیگر time_score=100 نمی‌خرد مگر کاربر
                // واقعاً به اندازهٔ expected_time زمان سپرده باشد.
                $activeTime = $storedActiveTime > 0
                    ? ($serverElapsed > 0 ? min($storedActiveTime, $serverElapsed) : $storedActiveTime)
                    : $serverElapsed;
                $expectedTime = max(1, int_value($exec->expected_time ?? $behaviorData['expected_time'] ?? 30));
                $behaviorData['active_time'] = $activeTime;
                // FIX-CAMERA-E2E-BEACON (بازبینی وریفایر دوربین ۲۰۲۶-۱۰-۲۶): session_duration
                // نیز مانند active_time به زمان سپری‌شدهٔ واقعیِ سرور clamp می‌شود. قبلاً
                // max(stored, activeTime) بود و ادعای (یا انباشتِ بیکن‌های) session بزرگ،
                // farm_exact_timing را دور می‌زد — همان پمپاژی که کپشن سقف‌های
                // BEHAVIOR_SIGNAL_CALL_CAPS ادعای مهارش را در submit داشت.
                $behaviorData['session_duration'] = max(1, min(
                    max(int_value($storedBehaviorData['session_duration'] ?? 0), $activeTime),
                    $serverElapsed > 0 ? $serverElapsed : max(int_value($storedBehaviorData['session_duration'] ?? 0), $activeTime)
                ));
                $behaviorData['expected_time'] = $expectedTime;

                // ── FIX-R18N (Task 18-N — P0 REVIEW_ROUND18 #5a) ────────────────────
                // وایر کردن موتور ضد-فارمینگ یتیم: checkAction('task.social') — همان
                // الگوی task.custom (CustomTaskExecutorService::startTask) و task.seo
                // (ProcessSeoTaskAsyncJob). اگر گارد تزریق نشده باشد (ساخت دستی/تست)
                // مثل سایر وابستگی‌های nullable بی‌صدا skip می‌شود؛ خودِ FraudGuard
                // روی خطای سیستمی fail-closed است (حساسیت پول‌ساز).
                $fraudChallenge = false;
                if ($this->fraudGuard !== null) {
                    $risk = $this->fraudGuard->checkAction($userId, 'task.social', [
                        'execution_id'       => $executionId,
                        'ip'                 => get_client_ip(),
                        'session_id'         => (string)($exec->session_id ?? '') ?: (session_id() ?: ''),
                        'device_fingerprint' => (string)($exec->device_fingerprint ?? ''),
                        'behavior_data'      => $behaviorData,
                        'automation_signals' => $behaviorData['automation_signals'] ?? null,
                    ]);
                    $riskAction = str_value($risk['action'] ?? 'allow');
                    if (empty($risk['allowed']) && $riskAction === 'block') {
                        // block → اجرا رد/لغو می‌شود (بدون هیچ پرداختی) + لاگ دلیل.
                        // نکته: گذار in_progress/started → 'rejected' در STATE_TRANSITIONS
                        // مدل مجاز نیست؛ معادلِ مجازِ «خروج بدون پاداش» یعنی cancelled
                        // استفاده می‌شود و flag_note دلیل گارد را نگه می‌دارد.
                        $this->executionModel->updateExecutionStatus($executionId, 'cancelled', [
                            'flag_review' => 1,
                            'flag_note'   => 'fraud_guard_block_' . str_value($risk['reason'] ?? 'unknown'),
                        ]);
                        $this->executionModel->getDb()->query(
                            "UPDATE ads SET pending_count = GREATEST(COALESCE(pending_count,0)-1,0), remaining_count = COALESCE(remaining_count,0)+1, updated_at = NOW() WHERE id = ?",
                            [(int)$exec->ad_id]
                        );
                        return [
                            'success' => false,
                            'message' => 'ثبت نتیجه تسک به دلیل تشخیص رفتار مشکوک مسدود شد.',
                            'status' => 'cancelled',
                            'execution_id' => $executionId,
                            'fraud_blocked' => true,
                            'reason' => str_value($risk['reason'] ?? 'fraud_guard_block'),
                        ];
                    }
                    if (empty($risk['allowed']) || $riskAction === 'challenge' || $riskAction === 'limit') {
                        // challenge/limit → مسیر pay_reward=false: اجرا ثبت و برای
                        // بررسی دستی فلگ می‌شود؛ هرگز auto-approve/escrow-release نمی‌گیرد.
                        $fraudChallenge = true;
                    }
                }

                $analysis = $this->behaviorAnalysis->analyze($behaviorData);
                $behaviorScore = float_value($analysis['behavior_score'] ?? 50);
                $patterns = $analysis['patterns'] ?? [];
                $isMobileApp = ($behaviorData['client_mode'] ?? '') === 'mobile_app' || !empty($behaviorData['is_mobile']);
                $cameraScore = isset($behaviorData['camera_score']) ? (int)$behaviorData['camera_score'] : null;

                // 🛡️ FIX-R36-W2-E2 (F-A10-02): camera_score عدد ادعایی کلاینت است.
                // سهمِ مؤثر آن در نمرهٔ نهایی فقط با گیتِ سمت‌سرور محاسبه می‌شود:
                // رکوردِ دوربینِ server-createdِ completed + متادیتای capture معقول
                // (frame_count>0) + سقف config-محور ('anti_fraud.camera_contribution_cap').
                // ادعای inline کلاینت در behavior_signals بدون رکورد سروری = صفر.
                $cameraContribution = $this->cameraVerification->effectiveCameraContribution($executionId, $cameraScore);

                // FIX-R18N (#5c): نیاز به دوربین تصمیمِ سمت سرور است — camera_scoreِ
                // اعلامی کلاینت برای دورزدنِ فلوِ دوربینِ اجباری قابل‌اعتماد نیست؛
                // وقتی سرویسِ تأیید دوربین requirement را صادر کرد، امتیازِ کلاینت
                // نادیده گرفته می‌شود و فلوِ دوربین اجرا می‌شود.
                if ($isMobileApp && $this->cameraVerification->isRequired($executionId, $behaviorScore, $behaviorData)) {
                    $requestId = $this->cameraVerification->createRequest($executionId, $userId, 'mobile_camera', [
                        'client_mode' => $behaviorData['client_mode'] ?? 'mobile_app',
                        'client_version' => $behaviorData['client_version'] ?? null,
                    ]);
                    $this->executionModel->updateExecutionStatus($executionId, (string)$exec->status, [
                        'behavior_data' => json_encode($behaviorData, JSON_UNESCAPED_UNICODE),
                        'behavior_score' => $behaviorScore,
                        'verification_required' => 1,
                        'verification_method' => 'mobile_camera',
                        'verification_requested_at' => date('Y-m-d H:i:s'),
                        'flag_review' => 1,
                        'flag_note' => 'mobile_camera_required',
                    ]);
                    // 🛡️ FIX-IDEM-PAUSE-WIRING (بازبینی وریفایر دوربین ۲۰۲۶-۱۰-۲۶):
                    // پاسخِ camera_required یک «توقفِ عادی در انتظار اقدام کاربر» است،
                    // نه شکستِ کسب‌وکاری. بدون کلیدهای قراردادِ pause، wrapInstance این
                    // پاسخ را failed_retryable ذخیره می‌کرد: (۱) ردیف یتیمِ ۹۰روزه،
                    // (۲) ریسابمیتِ بعد از تأیید دوربین داخلِ کوئل‌داونِ ۶۰ ثانیه‌ای با
                    // RuntimeException → ۵۰۰ INTERNAL_ERROR برای کاربر صادق.
                    // قرارداد هسته (core/IdempotencyKey::isPauseCallbackResult) همین
                    // مورد را هدف‌گذاری کرده بود — اینجا رعایت می‌شود تا کلید release شود.
                    return [
                        'success' => false,
                        'pause' => true,
                        'pause_reason' => 'camera_verification_required',
                        'message' => 'رفتار این اجرا نیاز به تأیید دوربین موبایل دارد. تصویر خام ذخیره یا ارسال نمی‌شود؛ فقط نتیجه تحلیل به امتیاز اضافه می‌شود.',
                        'camera_required' => true,
                        'camera_request_id' => $requestId,
                        'behavior_score' => $behaviorScore,
                        'patterns' => $patterns,
                    ];
                }

                $score = $this->calculateFinalScore(
                    behaviorScore: $behaviorScore,
                    activeTime: $activeTime,
                    expectedTime: $expectedTime,
                    behaviorData: $behaviorData,
                    cameraScore: $cameraScore,
                    cameraContribution: $cameraContribution
                );

                // 🛡️ FIX-10a-F1 (R10 audit P1): نمره‌های behavior/time/interaction
                // همگی از سیگنال‌های خوداظهاری کلاینت می‌آیند و «کمکی» محسوب
                // می‌شوند — به‌تنهایی (بدون اثبات) هرگز auto-approve نمی‌خرند.
                // تعریفِ آن‌زمانیِ «اثبات» در FIX-10a-F1 «سهمِ مؤثرِ دوربین» بود
                // (رکورد server-created + متادیتای فریم + سقف config)؛ FIX-S21-01
                // در ادامه همین تعریف را ابطال می‌کند.
                //
                // 🛡️ FIX-S21-01 (بازبینی بخش ۲۱، P2 — رفعِ بینابینی طبق توصیهٔ گزارش):
                // سهمِ مؤثرِ دوربین خودش از دو عددِ خوداظهاریِ کلاینت می‌آید
                // (camera_score + frame_count فقط clamp می‌شوند؛ نه فریمی آپلود می‌شود
                // نه ML/HMAC/attestation سمت‌سرور هست). رکوردِ server-createdِ
                // «completed» فقط «فلو اجرا شد» را اثبات می‌کند، نه «capture معتبر
                // بود» را؛ پس contribution دیگر نشانِ proof نمی‌خرد و فقط ورودیِ
                // کمکیِ امتیاز (سقف ۱۵) می‌ماند. نتیجهٔ قراردادی: نمرهٔ بالای آستانه
                // بدون اثباتِ مستقل = بررسی دستی (pay_reward=false) — هرگز آزادسازی
                // خودکار.
                //
                // 🛡️ FIX-F21-01 (گزینهٔ C + R2/R3): وریفایر واقعی فرود آمده است؛
                // «اثبات» فقط و فقط حکم trusted سروری است: nonce یک‌بارمصرفِ
                // مصرف‌شده + تحلیل آماری سمت‌سرور با server_verdict='pass'
                // (CameraVerificationService::hasTrustedVerdict). ادعای کلاینت،
                // حکم weak/fail و رکوردهای legacy هرگز اثبات نیستند (fail-closed).
                $hasVerifiableProof = $this->cameraVerification->hasTrustedVerdict($executionId);

                $finalScore = float_value($score['final_score'] ?? 0.0);
                $data = [
                    'active_time' => $activeTime,
                    'behavior_data' => json_encode($behaviorData, JSON_UNESCAPED_UNICODE),
                    'task_score' => (int)round($finalScore),
                    'anti_fraud_score' => (int)round(100.0 - $finalScore),
                    'decision' => $score['decision'],
                    'submitted_at' => date('Y-m-d H:i:s'),
                    'behavior_score' => $score['behavior_score'],
                    'time_score' => $score['time_score'],
                    'interaction_score' => $score['interaction_score'],
                    'camera_score' => $cameraScore,
                    'final_score' => $score['final_score'],
                    'score_breakdown' => json_encode($score, JSON_UNESCAPED_UNICODE),
                    // 🛡️ FIX-R36-W2-E2 (F-A10-02): این سه ستون فقط با تاییدِ سمت‌سرورِ
                    // واقعی (سهمِ مؤثر > 0) پر می‌شوند؛ ادعای inline کلاینت دیگر خودش را
                    // «verification.completed» جا نمی‌زند.
                    'verification_required' => $cameraContribution > 0.0 ? 1 : 0,
                    'verification_method' => $cameraContribution > 0.0 ? 'mobile_camera' : null,
                    'verification_completed_at' => $cameraContribution > 0.0 ? date('Y-m-d H:i:s') : null,
                    'client_mode' => $behaviorData['client_mode'] ?? ($isMobileApp ? 'mobile_app' : 'web'),
                    'client_version' => $behaviorData['client_version'] ?? null,
                ];

                if ($score['final_score'] >= self::AUTO_APPROVE_SCORE) {
                    // FIX-R18N (#5b): پاداش پرچم‌گذاری‌شدهٔ گارد (challenge/limit یا هر
                    // risk-decision غیرمجاز) هرگز auto-approve/escrow-release نمی‌گیرد —
                    // هم‌قرارداد payReward=false در DecideSilentAntiFraudJob: اجرا برای
                    // بررسی دستی فلگ می‌شود.
                    //
                    // 🛡️ FIX-10a-F1 (R10 audit P1): همین قرارداد برای «نبودِ اثباتِ
                    // قابل‌راستی‌آزمایی» هم برقرار است — پیش از این نمرهٔ ~88 برآمده از
                    // سیگنال‌های جعلیِ کلاینت (variance/delay ساختگی + انتظار واقعی ~45s)
                    // به auto-approve و آزادسازی اسکرو می‌رسید. اکنون: نمرهٔ بالای آستانه
                    // بدون سهمِ مؤثرِ دوربینِ سمت‌سرور → بررسی دستی (pay_reward=false)،
                    // هرگز آزادسازی خودکار.
                    // 🛡️ FIX-F21-01-R4: حتی با حکم pass، نمونهٔ تصادفی (پیش‌فرض ۵٪) و
                    // کاربرِ پرتکرار (سقف pass روزانه) به بازبینی ادمین می‌روند.
                    $auditReason = ($hasVerifiableProof && !$fraudChallenge)
                        ? $this->cameraVerification->passAuditReason($executionId, $userId)
                        : null;
                    if ($fraudChallenge || !$hasVerifiableProof || $auditReason !== null) {
                        $flagNote = $fraudChallenge
                            ? 'fraud_guard_challenge_pay_reward_false'
                            : ($auditReason ?? 'manual_review_no_verifiable_proof');
                        // 🛡️ FIX-CAM-PATH-MSG (چرخهٔ اصلاحی 2026-10-28 — رفع یافتهٔ 17-RV):
                        // تمایز پیام بر اساس مسیر کلاینت: کاربرِ موبایل می‌تواند فلوِ دوربین را
                        // کامل کند (پیام دوربین‌محور)؛ کاربرِ وب از مرورگر نمی‌تواند — پیام عمومی
                        // بدون وعدهٔ دوربین + راهنمای تکمیل از اپ موبایل.
                        $noProofMessage = $isMobileApp
                            ? 'نتیجه تسک ثبت شد؛ آزادسازی خودکار پاداش نیازمند تأیید دوربین (اثبات سمت‌سرور) است و برای بررسی دستی ارجاع شد.'
                            : 'نتیجه تسک ثبت شد؛ به دلیل نبود اثبات قابل‌راستی‌آزمایی برای بررسی دستی به ادمین ارجاع شد. در صورت نیاز به تأیید تکمیلی، تسک را از اپلیکیشن موبایل کامل کنید.';
                        $message = $fraudChallenge
                            ? 'نتیجه تسک ثبت شد اما به دلیل سیگنال‌های امنیتی برای بررسی دستی ارجاع شد.'
                            : ($auditReason !== null
                                ? 'نتیجه تسک ثبت شد و برای بازبینی تصادفی/کنترل نرخ توسط ادمین ارجاع شد.'
                                : $noProofMessage);
                        $this->executionModel->updateExecutionStatus($executionId, 'submitted', array_merge($data, [
                            'flag_review' => 1,
                            'flag_note' => $flagNote,
                        ]));
                        return [
                            'success' => true,
                            'message' => $message,
                            'status' => 'submitted',
                            'execution_id' => $executionId,
                            'task_score' => $score['final_score'],
                            'score_breakdown' => $score,
                            'pay_reward' => false,
                            'manual_review' => true,
                        ];
                    }
                    $this->executionModel->updateExecutionStatus($executionId, 'submitted', $data);
                    $approve = $this->approveJob->handle((int)$exec->user_id, $executionId);
                    return array_merge($approve, [
                        'status' => !empty($approve['success']) ? 'approved' : 'submitted',
                        'execution_id' => $executionId,
                        'task_score' => $score['final_score'],
                        'score_breakdown' => $score,
                    ]);
                }

                if ($score['final_score'] < self::REJECT_SCORE) {
                    $this->executionModel->updateExecutionStatus($executionId, 'submitted', array_merge($data, [
                        'flag_review' => 1,
                        'flag_note' => 'auto_reject_low_score',
                    ]));
                    $reject = $this->rejectJob->handle((int)$exec->user_id, $executionId, 'امتیاز اعتبارسنجی تسک اجتماعی کمتر از حد مجاز بود.');
                    return array_merge($reject, [
                        'status' => !empty($reject['success']) ? 'rejected' : 'submitted',
                        'execution_id' => $executionId,
                        'task_score' => $score['final_score'],
                        'score_breakdown' => $score,
                    ]);
                }

                $this->executionModel->updateExecutionStatus($executionId, 'submitted', array_merge($data, [
                    'flag_review' => 1,
                    'flag_note' => 'manual_review_score_' . round($finalScore, 2),
                ]));

                return [
                    'success' => true,
                    'message' => 'نتیجه تسک بدون نیاز به مدرک کاربر محاسبه شد و برای بررسی تکمیلی ثبت شد.',
                    'status' => 'submitted',
                    'execution_id' => $executionId,
                    'task_score' => $score['final_score'],
                    'score_breakdown' => $score,
                ];
            },
            $explicitKey
        );
    }

    /** @return array<string, mixed> */
private function decodeBehaviorData(?string $json): array
    {
        if (!$json) return [];
        $data = (array)(json_decode($json, true) ?? []);
        return is_array($data) ? $data : [];
    }

    /**
     * @param array<string, mixed> $behaviorData
     * @return array<string, mixed>
     */
    private function calculateFinalScore(float $behaviorScore, int $activeTime, int $expectedTime, array $behaviorData, ?int $cameraScore, float $cameraContribution = 0.0): array
    {
        $timeRatio = min(1.0, $activeTime / max(1, $expectedTime));
        $timeScore = $timeRatio * 100;

        $tap = int_value($behaviorData['tap_count'] ?? 0);
        $scroll = int_value($behaviorData['scroll_count'] ?? 0);
        $swipe = int_value($behaviorData['swipe_count'] ?? 0);
        $hesitation = int_value($behaviorData['hesitation_count'] ?? 0);
        $naturalDelay = int_value($behaviorData['natural_delay_count'] ?? 0);
        $interactionTypes = ($tap > 0 ? 1 : 0) + ($scroll > 0 ? 1 : 0) + ($swipe > 0 ? 1 : 0);
        $interactionScore = min(100.0, ($interactionTypes * 25.0) + min(25.0, ($tap + $scroll + $swipe) * 3.0) + min(25.0, ($hesitation + $naturalDelay) * 5.0));

        if ($cameraScore !== null) {
            // 🛡️ FIX-R36-W2-E2 (F-A10-02): سهم دوربین دیگر «عدد خام کلاینت × 0.30» نیست؛
            // سهمِ مؤثرِ سقف‌خورده (سروری-گیت‌شده) جایگزین شده است. سایر ضرایب نامتغیر.
            $final = ($behaviorScore * 0.35) + ($timeScore * 0.20) + ($interactionScore * 0.15) + $cameraContribution;
            // 🛡️ FIX-LABEL-ROUNDING (چرخهٔ اصلاحی 2026-10-28 — رفع یافتهٔ 17-RV):
            // برچسب تصمیم از مقدار «گردشده» محاسبه می‌شود — همان چیزی که
            // شاخه‌های handle() می‌خوانند ($score['final_score']). پنجرهٔ
            // ~44.996..45 که در آن برچسب auto_rejected ولی شاخه رد نبود، بسته شد.
            $finalScore = round(max(0.0, min(100.0, $final)), 2);
            // 🛡️ FIX-10a-F1 (R10 audit P1) + FIX-S21-01 (بازبینی بخش ۲۱): برچسب تصمیم
            // با گیتِ اثبات هم‌خوان است — تا وقتی وریفایر سمت‌سروریِ capture وجود
            // ندارد (FIX-S21-01)، هیچ مسیرِ کلاینتی «auto_approved» تولید نمی‌کند؛
            // نمرهٔ بالای آستانه = بررسی دستی. برچسب auto-approveِ قدیمی حذف شد تا
            // با شاخهٔ approve هم‌قرارداد بماند (قانون ۶: برچسبِ دروغ ممنوع).
            // (auto_rejected/* دست‌نخورده: ردِ خودکار پول آزاد نمی‌کند.)
            $decision = $finalScore >= self::AUTO_APPROVE_SCORE
                ? 'manual_review_no_verifiable_proof'
                : ($finalScore < self::REJECT_SCORE ? 'auto_rejected_with_mobile_camera' : 'manual_review_with_mobile_camera');
        } else {
            $final = ($behaviorScore * 0.55) + ($timeScore * 0.25) + ($interactionScore * 0.20);
            // 🛡️ FIX-LABEL-ROUNDING: هم‌قرارداد با شاخهٔ دوربین — برچسب از گردشده.
            $finalScore = round(max(0.0, min(100.0, $final)), 2);
            // 🛡️ FIX-10a-F1: بدون هیچ اثباتِ سروری، نوارِ approve هرگز آزادسازی خودکار
            // نمی‌گیرد — برچسب تصمیم هم «manual_review» است (دست‌نخورده: auto_rejected).
            $decision = $finalScore < self::REJECT_SCORE ? 'auto_rejected' : 'manual_review';
        }

        return [
            'final_score' => $finalScore, // FIX-LABEL-ROUNDING: همان متغیرِ برچسب/شاخه
            'behavior_score' => round($behaviorScore, 2),
            'time_score' => round($timeScore, 2),
            'interaction_score' => round($interactionScore, 2),
            'camera_score' => $cameraScore,
            // 🛡️ FIX-R36-W2-E2 (F-A10-02): شفافیت breakdown — سهم مؤثر و سقفِ آن.
            'camera_contribution' => round($cameraContribution, 2),
            'camera_contribution_cap' => int_value(config('anti_fraud.camera_contribution_cap', 15)),
            'decision' => $decision,
            'thresholds' => [
                'auto_approve' => self::AUTO_APPROVE_SCORE,
                'reject' => self::REJECT_SCORE,
            ],
        ];
    }
}
