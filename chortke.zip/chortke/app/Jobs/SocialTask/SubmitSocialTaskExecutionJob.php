<?php

declare(strict_types=1);

namespace App\Jobs\SocialTask;

use App\Models\SocialTaskExecutionModel;
use App\Services\Shared\IdempotencyService;

class SubmitSocialTaskExecutionJob
{
    public function __construct(
        private SocialTaskExecutionModel $executionModel,
        private IdempotencyService $idempotencyService
    ) {}

    public function handle(int $userId, int $executionId, array $payload = []): array
    {
        return $this->idempotencyService->execute(
            'social_task.submit',
            $userId,
            ['execution_id' => $executionId],
            function () use ($userId, $executionId, $payload) {
                $exec = $this->executionModel->getExecutionWithAd($executionId, $userId, false);
                if (!$exec) {
                    return ['success' => false, 'message' => 'رکورد اجرا یافت نشد.'];
                }
                if (!in_array((string)$exec->status, ['in_progress', 'started'], true)) {
                    return ['success' => false, 'message' => 'وضعیت اجرا برای ارسال نتیجه مناسب نیست.'];
                }

                $proofUrl = trim((string)($payload['proof_url'] ?? ''));
                $proofText = trim((string)($payload['proof_text'] ?? ''));
                if ($proofUrl === '' && $proofText === '') {
                    return ['success' => false, 'message' => 'مدرک انجام تسک الزامی است.'];
                }

                $started = strtotime((string)($exec->started_at ?? $exec->created_at));
                $activeTime = max(0, time() - ($started ?: time()));
                $data = [
                    'proof_url' => $proofUrl ?: null,
                    'proof_text' => $proofText ?: null,
                    'active_time' => $activeTime,
                ];
                if (!empty($payload['behavior_signals'])) {
                    $data['behavior_data'] = json_encode($payload['behavior_signals'], JSON_UNESCAPED_UNICODE);
                }

                $this->executionModel->updateExecutionStatus($executionId, 'submitted', $data);
                return ['success' => true, 'message' => 'نتیجه تسک ارسال شد.', 'status' => 'submitted', 'execution_id' => $executionId];
            },
            'social_task_submit_' . $userId . '_' . $executionId
        );
    }
}
