<?php

declare(strict_types=1);

namespace App\Jobs\SocialTask;

use App\Models\SocialTaskExecutionModel;
use App\Models\SocialTaskModel;
use Core\Database;

class RejectSocialTaskExecutionJob
{
    public function __construct(
        private Database $db,
        private SocialTaskExecutionModel $execModel,
        private SocialTaskModel $taskModel,
        private ?\App\Contracts\OutboxServiceInterface $outbox = null,
        private ?\App\Contracts\LoggerInterface $logger = null
    ) {}

    /** @return array<string, mixed> */
public function handle(int $advertiserId, int $executionId, string $reason): array
    {
        $reason = trim((string)$reason);
        if ($reason === '') return ['success' => false, 'message' => 'دلیل رد الزامی است'];

        try {
            $this->db->beginTransaction();
            $exec = $this->execModel->getExecutionById($executionId, true);
            if (!$exec) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'اجرا یافت نشد'];
            }
            $ad = $this->taskModel->getAdById((int)$exec->ad_id, true);
            if (!$ad || (int)$ad->user_id !== $advertiserId) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'دسترسی مجاز نیست'];
            }
            if ((string)$exec->status !== 'submitted') {
                $this->db->rollback();
                return ['success' => false, 'message' => 'این اجرا در وضعیت قابل رد نیست.'];
            }

            $this->execModel->updateExecutionStatus($executionId, 'rejected', [
                'reject_reason' => $reason,
                'decision' => 'rejected',
                'reviewed_by' => $advertiserId,
                'reviewed_at' => date('Y-m-d H:i:s'),
            ]);
            // 🛡️ FIX-DEAD-EVENT-EXECUTOR-NOTIFY (P1 — pre-existing): رویداد
            // social_task.rejected هیچ listener ای ندارد → مجری از رد شدن اجرا و
            // دلیل آن بی‌خبر می‌ماند. اصلاح با الگوی استاندارد notification.requested
            // (رویداد بی‌اثر حذف شد).
            // S3-M7 FIX (S33-B3 audit): تولید رویداد social_task.rejected — تنها
            // listener آن (SocialTaskEventListeners::handleTaskRejected، اکنون
            // ثبت‌شده در AppServiceProvider) جریمهٔ trust را با dedup_id
            // per-execution اعمال می‌کند (تکمیل FIX-S18-6).
            try {
                $this->outbox?->record('social_task', (int)$executionId, 'social_task.rejected', [
                    'executor_id'  => (int)$exec->executor_id,
                    'execution_id' => (int)$executionId,
                    'ad_id'        => (int)$exec->ad_id,
                    'reason'       => $reason,
                ]);
            } catch (\Throwable $e) {
                error_log('[RejectSocialTaskExecutionJob] rejected-event failed: ' . $e->getMessage());
            }
            try {
                $this->outbox?->record('notification', (int)$exec->executor_id, 'notification.requested', [
                    'user_id'    => (int)$exec->executor_id,
                    'type'       => 'social_task_rejected',
                    'title'      => 'اجرای شما رد شد ❌',
                    // PS-fix: $reason پس از گارد خط ۲۳ (return در صورت '') همیشه غیرخالی است؛
                    // شاخهٔ else سه‌تایی مرده بود (یافتهٔ PHPStan) — حذف، رفتار یکسان.
                    'message'    => "اجرای شما از تسک #{$exec->ad_id} رد شد. دلیل: " . $reason,
                    'data'       => [
                        'execution_id' => (int)$executionId,
                        'ad_id'        => (int)$exec->ad_id,
                        'reason'       => $reason,
                    ],
                ]);
            } catch (\Throwable $e) {
                error_log('[RejectSocialTaskExecutionJob] notify failed: ' . $e->getMessage());
            }
            $this->db->query("UPDATE ads SET pending_count = GREATEST(COALESCE(pending_count,0)-1,0), remaining_count = COALESCE(remaining_count,0)+1, updated_at = NOW() WHERE id = ?", [(int)$exec->ad_id]);
            $this->db->query("INSERT INTO social_user_trust (user_id, trust_score, created_at, updated_at) VALUES (?, 45, NOW(), NOW()) ON DUPLICATE KEY UPDATE trust_score = GREATEST(0, trust_score - 5), updated_at = NOW()", [(int)$exec->executor_id]);
            $this->db->commit();
            return ['success' => true, 'message' => 'اجرا رد شد'];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollback();
            // FIX-R36-W3 (F-A17-09): شکست مسیر sync بدون لاگ بود — رد صوتیِ
            // ناپدیدشونده. (قرارداد صف: این کلاس allowlist است؛ اگر روزی push
            // شود، این catch باید به rethrow-after-log تبدیل شود.)
            $this->logger?->warning('social_task.reject.execution_failed', [
                'execution_id' => $executionId,
                'error'        => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در رد اجرا: ' . $e->getMessage()];
        }
    }

    /**
     * 🛡️ S27D-F1 (FIX-R18B — restore): رد اجباری ادمین داخل همان موتور تراکنشی
     * handle() — بدون گارد مالکیت (پرایویج ادمین؛ caller:
     * SocialTaskService::adminOverrideExecution) و بدون قید status، با متادیتای
     * override (overridden_by/override_reason) و رویداد social_task.rejected
     * برای زنجیرهٔ جریمهٔ trust (S27D-F16: داخل تراکنش رد).
     *
     * @return array<string, mixed>
     */
    public function handleAdminOverride(int $executionId, int $adminId, string $reason): array
    {
        $reason = trim((string)$reason);
        if ($reason === '') {
            return ['success' => false, 'message' => 'دلیل override الزامی است'];
        }

        try {
            $this->db->beginTransaction();
            $exec = $this->execModel->getExecutionById($executionId, true);
            if (!$exec) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'اجرا یافت نشد'];
            }

            // ── FIX-R18N (Task 18-N — CAS status guard، طراحی REVIEW_ROUND18 #16) ──
            // ردیف زیر قفل FOR UPDATE خوانده شده است؛ اگر وضعیت فعلی همان تصمیمِ
            // هدف ('rejected') باشد یعنی bookkeepingِ رد قبلاً اعمال شده و اجرای
            // دوبارهٔ override نباید pending_count را دوباره -، remaining_count را
            // دوباره + و trust را دوباره -5 کند. متادیتای override تازه می‌شود ولی
            // بوک‌کیپینگ کمپین/trust و رویداد/اعلان فقط برای گذارِ واقعی اجرا می‌شوند.
            $oldStatus = (string)$exec->status;
            if ($oldStatus === 'rejected') {
                $this->execModel->updateExecutionStatus($executionId, 'rejected', [
                    'reject_reason'   => $reason,
                    'override_reason' => $reason,
                    'overridden_by'   => $adminId,
                    'overridden_at'   => date('Y-m-d H:i:s'),
                    'reviewed_by'     => $adminId,
                    'reviewed_at'     => date('Y-m-d H:i:s'),
                ]);
                $this->db->commit();
                $this->logger?->info('social_task.admin_override_reject.already_applied_skipped_bookkeeping', [
                    'execution_id' => $executionId,
                    'admin_id'     => $adminId,
                ]);
                return [
                    'success'      => true,
                    'message'      => 'این تصمیم قبلاً اعمال شده است؛ بوک‌کیپینگ دوباره اعمال نشد.',
                    'old_decision' => $exec->decision ?? null,
                    'new_decision' => 'rejected',
                ];
            }

            $this->execModel->updateExecutionStatus($executionId, 'rejected', [
                'reject_reason'   => $reason,
                'override_reason' => $reason,
                'decision'        => 'rejected',
                'overridden_by'   => $adminId,
                'overridden_at'   => date('Y-m-d H:i:s'),
                'reviewed_by'     => $adminId,
                'reviewed_at'     => date('Y-m-d H:i:s'),
            ]);

            // S3-M7 parity: رویداد social_task.rejected → listener جریمهٔ trust
            // با dedup_id per-execution؛ + اطلاع‌رسانی مجری (notification.requested).
            try {
                $this->outbox?->record('social_task', (int)$executionId, 'social_task.rejected', [
                    'executor_id'  => (int)$exec->executor_id,
                    'execution_id' => (int)$executionId,
                    'ad_id'        => (int)$exec->ad_id,
                    'reason'       => $reason,
                ]);
            } catch (\Throwable $e) {
                $this->logger?->warning('social_task.admin_override_reject_event_failed', ['error' => $e->getMessage()]);
            }
            try {
                $this->outbox?->record('notification', (int)$exec->executor_id, 'notification.requested', [
                    'user_id'    => (int)$exec->executor_id,
                    'type'       => 'social_task_rejected',
                    'title'      => 'اجرای شما رد شد ❌',
                    'message'    => "اجرای شما از تسک #{$exec->ad_id} توسط پشتیبانی رد شد. دلیل: " . $reason,
                    'data'       => [
                        'execution_id'  => (int)$executionId,
                        'ad_id'         => (int)$exec->ad_id,
                        'reason'        => $reason,
                        'overridden_by' => $adminId,
                    ],
                ]);
            } catch (\Throwable $e) {
                $this->logger?->warning('social_task.admin_override_reject_notify_failed', ['error' => $e->getMessage()]);
            }

            // بوک‌کیپینگ کمپین + trust — عیناً همان handle()
            //
            // 🛡️ FIX-R36-W4 (F-A17-ORCH-01): گارد گذرِ عرضیِ approve→reject —
            // آینهٔ FIX-R36-W3 (F-A17-03) در ApproveSocialTaskExecutionJob.
            // CASِ بالا فقط replay هم‌تصمیم ('rejected'→'rejected') را می‌بندد؛
            // اگر اجرا قبلاً approved/soft_approved شده باشد (reward_paid=1)،
            // بوک‌کیپینگ آن در خانوادهٔ completed_count اعمال شده و اجرا دیگر
            // pending نیست — مسیر عادیِ زیر (pending_count-1) شمارندهٔ کمپینِ
            // یک اجرای دیگرِ درانتظار را می‌سوزاند و اسلاتِ مصرف‌شده را
            // دوباره به استخر برمی‌گرداند (ریزش شمارنده + over-execution).
            // برای این گذر: completed_count-1 + remaining_count+1؛ بودجه دست
            // نمی‌خورد (پاداش پرداخت شده؛ clawback تصمیم محصولِ جداگانه است)؛
            // trust-5 طبق روال رد باقی می‌ماند.
            if ((int)($exec->reward_paid ?? 0) === 1 || in_array($oldStatus, ['approved', 'soft_approved'], true)) {
                $this->db->query("UPDATE ads SET completed_count = GREATEST(COALESCE(completed_count,0)-1,0), remaining_count = COALESCE(remaining_count,0)+1, updated_at = NOW() WHERE id = ?", [(int)$exec->ad_id]);
                $this->logger?->info('social_task.admin_override_reject.approved_transition_bookkeeping', [
                    'execution_id' => $executionId,
                    'admin_id'     => $adminId,
                    'old_status'   => $oldStatus,
                ]);
            } else {
                $this->db->query("UPDATE ads SET pending_count = GREATEST(COALESCE(pending_count,0)-1,0), remaining_count = COALESCE(remaining_count,0)+1, updated_at = NOW() WHERE id = ?", [(int)$exec->ad_id]);
            }
            $this->db->query("INSERT INTO social_user_trust (user_id, trust_score, created_at, updated_at) VALUES (?, 45, NOW(), NOW()) ON DUPLICATE KEY UPDATE trust_score = GREATEST(0, trust_score - 5), updated_at = NOW()", [(int)$exec->executor_id]);
            $this->db->commit();

            return [
                'success'      => true,
                'message'      => 'تصمیم با موفقیت override شد',
                'old_decision' => $exec->decision ?? null,
                'new_decision' => 'rejected',
            ];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollback();
            $this->logger?->error('social_task.admin_override_reject.failed', [
                'execution_id' => $executionId,
                'admin_id'     => $adminId,
                'error'        => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در override تصمیم: ' . $e->getMessage()];
        }
    }
}
