<?php

declare(strict_types=1);

namespace App\Jobs\SocialTask;

class RejectSocialTaskExecutionJob
{
    private \App\Models\CryptoDeposit $model;
    private \Core\EventDispatcher $eventDispatcher;
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;
    public function __construct(
        \App\Models\CryptoDeposit $model,
        \Core\EventDispatcher $eventDispatcher
    ,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {        $this->model = $model;
        $this->eventDispatcher = $eventDispatcher;
        $this->outbox = $outbox;
}

    public function handle(int $advertiserId, int $executionId, string $reason): array
    {
        if (empty(trim($reason))) return ['success' => false, 'message' => 'دلیل رد الزامی است'];

        $exec = $this->model->getExecutionById($executionId);
        if (!$exec || (int)$exec->user_id !== $advertiserId) {
            return ['success' => false, 'message' => 'دسترسی مجاز نیست'];
        }

        $this->model->updateExecutionStatus($executionId, 'rejected', ['reject_reason' => $reason]);
        
        $this->eventDispatcher->dispatch('social_task.rejected', [
            'execution_id' => $executionId,
            'executor_id'  => $exec->executor_id,
            'ad_id'        => (int)($exec->ad_id ?? 0),
            'reason'       => $reason,
        ]);

        // همچنین ایونت مجزای execution.rejected برای ScoreOrchestrator
        $this->outbox?->record('social_task', $executionId, 'social_task.execution.rejected', [
            'executor_id'  => (int)($exec->executor_id ?? $exec->user_id ?? 0),
            'ad_id'        => (int)($exec->ad_id ?? 0),
            'execution_id' => $executionId,
            'reason'       => $reason,
        ]);

        return ['success' => true, 'message' => 'اجرا رد شد'];
    }
}
