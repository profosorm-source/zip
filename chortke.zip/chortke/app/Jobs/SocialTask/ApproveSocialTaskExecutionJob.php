<?php

declare(strict_types=1);

namespace App\Jobs\SocialTask;

use App\Models\SocialTaskExecutionModel;
use App\Models\SocialTaskModel;
use Core\EventDispatcher;
use App\Contracts\OutboxServiceInterface;

class ApproveSocialTaskExecutionJob
{
    private SocialTaskExecutionModel $execModel;
    private SocialTaskModel $taskModel;
    private EventDispatcher $eventDispatcher;
    private ?OutboxServiceInterface $outbox = null;

    public function __construct(
        SocialTaskExecutionModel $execModel,
        SocialTaskModel $taskModel,
        EventDispatcher $eventDispatcher,
        ?OutboxServiceInterface $outbox = null
    ) {
        $this->execModel = $execModel;
        $this->taskModel = $taskModel;
        $this->eventDispatcher = $eventDispatcher;
        $this->outbox = $outbox;
    }

    public function handle(int $advertiserId, int $executionId): array
    {
        $exec = $this->execModel->getExecutionById($executionId);
        if (!$exec) {
            return ['success' => false, 'message' => 'اجرا یافت نشد'];
        }

        // بررسی اینکه آیا کاربر درخواست دهنده، همان تبلیغ کننده (Advertiser) است
        $ad = $this->taskModel->getAdById((int)$exec->ad_id);
        if (!$ad || (int)$ad->user_id !== $advertiserId) {
            return ['success' => false, 'message' => 'دسترسی مجاز نیست'];
        }

        $this->execModel->updateExecutionStatus($executionId, 'approved');

        // Dispatch ایونت برای افزایش Score اجراکننده تسک و پرداخت پاداش
        $this->outbox?->record('social_task', $executionId, 'social_task.execution.approved', [
            'executor_id'  => (int)($exec->executor_id ?? 0),
            'ad_id'        => (int)($exec->ad_id ?? 0),
            'execution_id' => $executionId,
            'decision'     => 'approved',
            'reward_amount' => $exec->reward_amount ?? 0,
            'currency' => $exec->currency ?? 'irt',
        ]);

        return ['success' => true, 'message' => 'اجرا تأیید شد و دستور پرداخت صادر گردید'];
    }
}


