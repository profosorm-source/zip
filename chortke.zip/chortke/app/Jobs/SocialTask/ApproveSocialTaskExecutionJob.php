<?php

declare(strict_types=1);

namespace App\Jobs\SocialTask;

use App\Models\SocialTaskExecutionModel;
use App\Models\SocialTaskModel;
use Core\Database;
use Core\ValueObjects\Money;

/**
 * 🛡️ FIX-SOCIAL-FEE-BURN (pre-existing): کارمزد کمپین‌های تسک اجتماعی
 * قبلاً هرگز جمع نمی‌شد — فقط پاداش از اسکرو partialRelease می‌شد و کل
 * سهم کارمزد (F) تا انتهای کمپین در اسکرو می‌ماند و موقع بستن به
 * تبلیغ‌دهنده «برگشت داده می‌شد». یعنی پلتفرم از این کمپین‌ها صفر تومان
 * کارمزد می‌گرفت در حالی که ویزارد «کارمزد سایت X%» را از کاربر برمی‌داشت.
 * الگوی درست همان الگوی AdTube/CustomTask است: قبل از release پاداش،
 * کارمزد متناظر (reward × درصد ذخیره‌شده در رکورد کمپین) از اسکرو burn
 * می‌شود (consumeHeldBudget → platform_revenue).
 */
class ApproveSocialTaskExecutionJob
{
    private ?\App\Contracts\LoggerInterface $logger = null;
    public function __construct(
        private Database $db,
        private SocialTaskExecutionModel $execModel,
        private SocialTaskModel $taskModel,
        private ?\App\Contracts\OutboxServiceInterface $outbox = null,
        private ?\App\Services\EscrowService $escrowService = null,
        private ?\App\Domain\Financial\Services\FinancialEscrowService $financialEscrow = null,
        private ?\App\Services\Settings\AppSettings $appSettings = null
    ) {
        // 🧹 DI-CLEANUP (2026-08-24): تزریق WalletServiceInterface حذف شد.
        // مسیر legacy که با wallet->deposit پاداش را «بدون کسر بودجه‌ی قفل‌شده»
        // واریز می‌کرد، با EscrowService::partialRelease جایگزین شده است که
        // داخلاً هم هزینه را از escrow می‌کاهد و هم پاداش را با کلید idempotency
        // به کیف کارگر واریز می‌کند (partialRelease → walletService->deposit).
        // 🛡️ FIX-SOCIAL-FEE-BURN: FinancialEscrowService برای burn کارمزد اضافه شد.
    }

    /** @return array<string, mixed> */
public function handle(int $advertiserId, int $executionId): array
    {
        try {
            $this->db->beginTransaction();
            $exec = $this->execModel->getExecutionById($executionId, true);
            if (!$exec) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'اجرا یافت نشد'];
            }
            $ad = $this->taskModel->getAdById((int)$exec->ad_id, true);
            if (!$ad || (int)$ad->user_id !== $advertiserId) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'دسترسی مجاز نیست'];
            }
            if ((string)$exec->status !== 'submitted') {
                $this->db->rollback();
                return ['success' => false, 'message' => 'این اجرا در وضعیت قابل تأیید نیست.'];
            }

            $amount = (string)($ad->price_per_task ?? '0');
            $currency = (string)($ad->currency ?? 'irt');
            $txId = null;
            $escrowService = $this->escrowService;
            if ($escrowService === null) {
                // ── FAIL-CLOSED: قبلاً این‌جا تسک «بدون هیچ پرداختی» approved
                // می‌شد (کارگر هرگز پول نمی‌گرفت ولی تسک تأییدشده ثبت می‌شد).
                // نبودِ EscrowService یعنی پیکربندی خراب است — باید متوقف شود.
                $this->db->rollback();
                $this->logger?->error('social_task.approve.no_escrow_service_fail_closed', ['execution_id' => $executionId]);
                return ['success' => false, 'message' => 'سرویس Escrow در دسترس نیست؛ تأیید متوقف شد (نیازمند بررسی).'];
            }
            $escrow = $escrowService->getByOrder((int)$exec->ad_id, 'social_task_budget');
            if ($escrow && in_array((string)$escrow->status, ['pending', 'in_escrow', 'partial'], true)) {
                // PRIMARY: social task campaign budget is held in one central escrow.
                // Release the worker reward from that escrow so advertiser locked balance is reduced.

                // 🛡️ FIX-SOCIAL-FEE-BURN: کارمزد متناظر این پاداش، قبل از release
                // burn می‌شود (بعد از release ممکن است اسکرو 'released' شود و
                // دیگر consumable نباشد). درصد = مقدار قفل‌شده در رکورد کمپین.
                $feePercent = $this->socialFeePercent($ad);
                if (bccomp($feePercent, '0', 8) > 0) {
                    $fee = Money::fromString($amount, $currency)->percentage($feePercent)->getAmount();
                    if (bccomp($fee, '0', 8) > 0) {
                        if ($this->financialEscrow === null) {
                            $this->db->rollback();
                            $this->logger?->error('social_task.approve.no_financial_escrow_fail_closed', ['execution_id' => $executionId]);
                            return ['success' => false, 'message' => 'سرویس مالی اسکرو در دسترس نیست؛ تأیید متوقف شد.'];
                        }
                        $consume = $this->financialEscrow->consumeHeldBudget(
                            (int)$escrow->id,
                            (int)$advertiserId,
                            $fee,
                            $currency,
                            'کارمزد سایت تسک اجتماعی',
                            'social_task_settlement',
                            \App\Services\Shared\IdempotencyKeys::socialTaskFee($executionId)
                        );
                        if (empty($consume['ok'])) {
                            throw new \RuntimeException(is_string($consume['error'] ?? null) ? $consume['error'] : 'خطا در تسویه کارمزد تسک اجتماعی.');
                        }
                    }
                }

                $release = $escrowService->partialRelease((int)$escrow->id, (int)$exec->executor_id, $amount, \App\Services\Shared\IdempotencyKeys::socialTaskReward((int)$executionId));
                if (empty($release['ok'])) {
                    throw new \RuntimeException(str_value($release['error'] ?? 'خطا در آزادسازی پاداش اجتماعی از escrow.'));
                }
                $txId = 'escrow_social_release_' . (int)$escrow->id . '_' . $executionId;
            } else {
                // ── FAIL-CLOSED (تصمیم محصول): بدون escrow پرداختی وجود ندارد ──
                // شاخه‌ی قبلی (COMPATIBILITY_REDIRECT برای تسک‌های legacy) پاداش را
                // با deposit از هیچ‌جا ضرب می‌کرد و کیف/بودجه‌ی قفل‌شده‌ی
                // تبلیغ‌دهنده دست‌نخورده می‌ماند. مسیر زنده‌ی ساخت همیشه escrow ی
                // social_task_budget می‌سازد؛ نبودش وضعیت غیرعادی است.
                $this->logger?->error('social_task.approve.no_escrow_fail_closed', [
                    'execution_id' => $executionId,
                    'ad_id' => (int)$exec->ad_id,
                ]);
                throw new \RuntimeException('escrow بودجه‌ی تسک اجتماعی یافت نشد؛ پرداخت متوقف شد (نیازمند بررسی ادمین).');
            }

            $approvalData = [
                'reward_paid' => 1,
                'reward_amount' => $amount,
                'decision' => 'approved',
                'reviewed_by' => $advertiserId,
                'reviewed_at' => date('Y-m-d H:i:s'),
            ];
            $this->execModel->updateExecutionStatus($executionId, 'approved', $approvalData);
            $this->outbox?->record('social_task', $executionId, 'social_task.approved', [
                'execution_id' => $executionId,
                'status' => 'approved',
            ]);
            $this->db->query(
                "UPDATE ads
                 SET completed_count = COALESCE(completed_count,0)+1,
                     pending_count = GREATEST(COALESCE(pending_count,0)-1,0),
                     remaining_budget = GREATEST(COALESCE(remaining_budget,0)-?,0),
                     status = CASE
                         WHEN GREATEST(COALESCE(remaining_budget,0)-?,0) <= 0
                           OR (COALESCE(total_count,0) > 0 AND COALESCE(completed_count,0)+1 >= COALESCE(total_count,0))
                         THEN 'completed' ELSE status END,
                     is_active = CASE
                         WHEN GREATEST(COALESCE(remaining_budget,0)-?,0) <= 0
                           OR (COALESCE(total_count,0) > 0 AND COALESCE(completed_count,0)+1 >= COALESCE(total_count,0))
                         THEN 0 ELSE is_active END,
                     updated_at = NOW()
                 WHERE id = ?",
                [(float)$amount, (float)$amount, (float)$amount, (int)$exec->ad_id]
            );
            $this->db->query("INSERT INTO social_user_trust (user_id, trust_score, created_at, updated_at) VALUES (?, 55, NOW(), NOW()) ON DUPLICATE KEY UPDATE trust_score = LEAST(100, trust_score + 5), updated_at = NOW()", [(int)$exec->executor_id]);
            $this->db->commit();
            return ['success' => true, 'message' => 'اجرا تأیید و پاداش پرداخت شد.'];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollback();
            return ['success' => false, 'message' => 'خطا در تأیید اجرا: ' . $e->getMessage()];
        }
    }

    /**
     * 🛡️ FIX-SOCIAL-FEE-BURN — درصد کارمزد کمپین: اول site_commission_percent
     * ذخیره‌شده روی رکورد (که آداپتر هنگام ساخت — یا کوپن هنگام تخفیف —
     * نوشته)، وگرنه تنظیم رسمی social_task_site_fee_percent با پیش‌فرض
     * PercentageConstants::SOCIAL_TASK_FEE_PERCENT (همان AdSocialAdapter).
     */
    private function socialFeePercent(object $ad): string
    {
        $stored = $ad->site_commission_percent ?? null;
        if (is_scalar($stored) && is_numeric((string)$stored) && bccomp((string)$stored, '0', 8) >= 0) {
            return (string)$stored;
        }
        $setting = $this->appSettings?->get('social_task_site_fee_percent', \App\Constants\PercentageConstants::SOCIAL_TASK_FEE_PERCENT)
            ?? \App\Constants\PercentageConstants::SOCIAL_TASK_FEE_PERCENT;
        return is_numeric((string)$setting) ? (string)$setting : (string)\App\Constants\PercentageConstants::SOCIAL_TASK_FEE_PERCENT;
    }
}
