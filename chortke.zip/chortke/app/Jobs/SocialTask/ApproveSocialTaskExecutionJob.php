<?php

declare(strict_types=1);

namespace App\Jobs\SocialTask;

use App\Models\SocialTaskExecutionModel;
use App\Models\SocialTaskModel;
use Core\Database;
use Core\ValueObjects\Money;

/**
 * 🛡️ FIX-SOCIAL-FEE-BURN (pre-existing): کارمزد کمپین‌های تسک اجتماعی
 * قبلاً هرگز جمع نمی‌شد — فقط پاداش از اسکرو partialRelease می‌شد و کل
 * سهم کارمزد (F) تا انتهای کمپین در اسکرو می‌ماند و موقع بستن به
 * تبلیغ‌دهنده «برگشت داده می‌شد». یعنی پلتفرم از این کمپین‌ها صفر تومان
 * کارمزد می‌گرفت در حالی که ویزارد «کارمزد سایت X%» را از کاربر برمی‌داشت.
 * الگوی درست همان الگوی AdTube/CustomTask است: قبل از release پاداش،
 * کارمزد متناظر (reward × درصد ذخیره‌شده در رکورد کمپین) از اسکرو burn
 * می‌شود (consumeHeldBudget → platform_revenue).
 */
class ApproveSocialTaskExecutionJob
{
    private ?\App\Contracts\LoggerInterface $logger = null;
    public function __construct(
        private Database $db,
        private SocialTaskExecutionModel $execModel,
        private SocialTaskModel $taskModel,
        private ?\App\Contracts\OutboxServiceInterface $outbox = null,
        private ?\App\Services\EscrowService $escrowService = null,
        private ?\App\Domain\Financial\Services\FinancialEscrowService $financialEscrow = null,
        private ?\App\Services\Settings\AppSettings $appSettings = null,
        // FIX-R16A (Task 16-A): سرویس رفرال (اختیاری) — قلابِ اعتبار پاداش معرفِ
        // معلقِ کاربران OAuth روی «اولین تسک کامل‌شده» (سیاست مالک پروژه 2026-09-20؛
        // مستند در ReferralService::creditPendingReferralRewardOnFirstTask). Nullable-DI:
        // core/Container.php خودش پارامترهای nullable class را resolve می‌کند.
        private ?\App\Services\Shared\ReferralService $referralService = null,
        // FIX-R18N (Task 18-N — R90 pay-time gate): گیت ضد-فارمینگ (اختیاری) — پیش از
        // اعتبارِ پاداشِ معلقِ مسیر OAuth دوباره ارزیابی می‌شود (kill-switch / وضعیت
        // معرف / آستانهٔ فارمینگ). Nullable-DI هم‌الگوی referralService بالا.
        private ?\App\Services\Auth\ReferralAntiFarmingGate $referralGate = null
    ) {
        // 🧹 DI-CLEANUP (2026-08-24): تزریق WalletServiceInterface حذف شد.
        // مسیر legacy که با wallet->deposit پاداش را «بدون کسر بودجه‌ی قفل‌شده»
        // واریز می‌کرد، با EscrowService::partialRelease جایگزین شده است که
        // داخلاً هم هزینه را از escrow می‌کاهد و هم پاداش را با کلید idempotency
        // به کیف کارگر واریز می‌کند (partialRelease → walletService->deposit).
        // 🛡️ FIX-SOCIAL-FEE-BURN: FinancialEscrowService برای burn کارمزد اضافه شد.
    }

    /** @return array<string, mixed> */
public function handle(int $advertiserId, int $executionId): array
    {
        try {
            $this->db->beginTransaction();
            $exec = $this->execModel->getExecutionById($executionId, true);
            if (!$exec) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'اجرا یافت نشد'];
            }
            $ad = $this->taskModel->getAdById((int)$exec->ad_id, true);
            if (!$ad || (int)$ad->user_id !== $advertiserId) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'دسترسی مجاز نیست'];
            }
            if ((string)$exec->status !== 'submitted') {
                $this->db->rollback();
                return ['success' => false, 'message' => 'این اجرا در وضعیت قابل تأیید نیست.'];
            }

            $amount = (string)($ad->price_per_task ?? '0');
            $currency = (string)($ad->currency ?? 'irt');
            $txId = null;
            $escrowService = $this->escrowService;
            if ($escrowService === null) {
                // ── FAIL-CLOSED: قبلاً این‌جا تسک «بدون هیچ پرداختی» approved
                // می‌شد (کارگر هرگز پول نمی‌گرفت ولی تسک تأییدشده ثبت می‌شد).
                // نبودِ EscrowService یعنی پیکربندی خراب است — باید متوقف شود.
                $this->db->rollback();
                $this->logger?->error('social_task.approve.no_escrow_service_fail_closed', ['execution_id' => $executionId]);
                return ['success' => false, 'message' => 'سرویس Escrow در دسترس نیست؛ تأیید متوقف شد (نیازمند بررسی).'];
            }
            $escrow = $escrowService->getByOrder((int)$exec->ad_id, 'social_task_budget');
            if ($escrow && in_array((string)$escrow->status, ['pending', 'in_escrow', 'partial'], true)) {
                // PRIMARY: social task campaign budget is held in one central escrow.
                // Release the worker reward from that escrow so advertiser locked balance is reduced.

                // 🛡️ FIX-SOCIAL-FEE-BURN: کارمزد متناظر این پاداش، قبل از release
                // burn می‌شود (بعد از release ممکن است اسکرو 'released' شود و
                // دیگر consumable نباشد). درصد = مقدار قفل‌شده در رکورد کمپین.
                $feePercent = $this->socialFeePercent($ad);
                if (bccomp($feePercent, '0', 8) > 0) {
                    $fee = Money::fromString($amount, $currency)->percentage($feePercent)->getAmount();
                    if (bccomp($fee, '0', 8) > 0) {
                        if ($this->financialEscrow === null) {
                            $this->db->rollback();
                            $this->logger?->error('social_task.approve.no_financial_escrow_fail_closed', ['execution_id' => $executionId]);
                            return ['success' => false, 'message' => 'سرویس مالی اسکرو در دسترس نیست؛ تأیید متوقف شد.'];
                        }
                        $consume = $this->financialEscrow->consumeHeldBudget(
                            (int)$escrow->id,
                            (int)$advertiserId,
                            $fee,
                            $currency,
                            'کارمزد سایت تسک اجتماعی',
                            'social_task_settlement',
                            \App\Services\Shared\IdempotencyKeys::socialTaskFee($executionId)
                        );
                        if (empty($consume['ok'])) {
                            throw new \RuntimeException(is_string($consume['error'] ?? null) ? $consume['error'] : 'خطا در تسویه کارمزد تسک اجتماعی.');
                        }
                    }
                }

                $release = $escrowService->partialRelease((int)$escrow->id, (int)$exec->executor_id, $amount, \App\Services\Shared\IdempotencyKeys::socialTaskReward((int)$executionId));
                if (empty($release['ok'])) {
                    throw new \RuntimeException(str_value($release['error'] ?? 'خطا در آزادسازی پاداش اجتماعی از escrow.'));
                }
                $txId = 'escrow_social_release_' . (int)$escrow->id . '_' . $executionId;

                // 🛡️ FIX-X140b (D3 — راند 37): پاداش درصدی سطح مجری — جدا از بودجهٔ
                // escrow تبلیغ‌دهنده (تأمین پلتفرم) با outbox-first و کلید مستقل.
                // شکستِ هر مرحله از این بخش هرگز تأیید/پرداخت پایه را نمی‌شکند.
                try {
                    if ($this->outbox !== null && bccomp($amount, '0', 2) > 0) {
                        $bonusPercentStmt = $this->db->prepare(
                            "SELECT l.earning_bonus_percent FROM users u
                             JOIN user_levels l ON l.slug = u.level_slug AND l.is_active = 1
                             WHERE u.id = ? LIMIT 1"
                        );
                        $bonusPercentStmt->execute([(int)$exec->executor_id]);
                        $bonusPercentRaw = $bonusPercentStmt->fetchColumn();
                        $bonusPercent = $bonusPercentRaw === null ? 0.0 : (float)$bonusPercentRaw;
                        if ($bonusPercent > 0) {
                            $bonusAmount = bcmul($amount, bcdiv((string)$bonusPercent, '100', 8), 8);
                            if (bccomp($bonusAmount, '0', 2) > 0) {
                                $this->outbox->record('wallet', (int)$exec->executor_id, 'wallet.deposit.requested', [
                                    'user_id' => (int)$exec->executor_id,
                                    'amount' => $bonusAmount,
                                    'currency' => $currency,
                                    'metadata' => [
                                        'type' => 'level_earning_bonus',
                                        'description' => "پاداش درصدی سطح ({$bonusPercent}٪) برای درآمد تسک اجتماعی #{$executionId}",
                                        'idempotency_key' => 'level_bonus_social_' . $executionId,
                                        'source_execution_id' => $executionId,
                                    ],
                                ]);
                            }
                        }
                    }
                } catch (\Throwable $levelBonusError) {
                    $this->logger?->warning('social_task.approve.level_bonus_failed', [
                        'execution_id' => $executionId,
                        'error' => $levelBonusError->getMessage(),
                    ]);
                }
            } else {
                // ── FAIL-CLOSED (تصمیم محصول): بدون escrow پرداختی وجود ندارد ──
                // شاخه‌ی قبلی (COMPATIBILITY_REDIRECT برای تسک‌های legacy) پاداش را
                // با deposit از هیچ‌جا ضرب می‌کرد و کیف/بودجه‌ی قفل‌شده‌ی
                // تبلیغ‌دهنده دست‌نخورده می‌ماند. مسیر زنده‌ی ساخت همیشه escrow ی
                // social_task_budget می‌سازد؛ نبودش وضعیت غیرعادی است.
                $this->logger?->error('social_task.approve.no_escrow_fail_closed', [
                    'execution_id' => $executionId,
                    'ad_id' => (int)$exec->ad_id,
                ]);
                throw new \RuntimeException('escrow بودجه‌ی تسک اجتماعی یافت نشد؛ پرداخت متوقف شد (نیازمند بررسی ادمین).');
            }

            $approvalData = [
                'reward_paid' => 1,
                'reward_amount' => $amount,
                'decision' => 'approved',
                'reviewed_by' => $advertiserId,
                'reviewed_at' => date('Y-m-d H:i:s'),
            ];
            $this->execModel->updateExecutionStatus($executionId, 'approved', $approvalData);
            // 🛡️ FIX-DEAD-EVENT-EXECUTOR-NOTIFY (P1 — pre-existing): رویداد
            // social_task.approved هیچ listener ای ندارد → مجری از تأیید اجرا و
            // پرداخت پاداشش بی‌خبر می‌ماند. اصلاح با الگوی استاندارد
            // notification.requested (رویداد بی‌اثر حذف شد).
            try {
                $this->outbox?->record('notification', (int)$exec->executor_id, 'notification.requested', [
                    'user_id'    => (int)$exec->executor_id,
                    'type'       => 'social_task_approved',
                    'title'      => 'اجرای شما تأیید شد ✅',
                    'message'    => "اجرای شما از تسک #{$exec->ad_id} تأیید شد و پاداش " . str_value($amount) . ' ' . str_value($currency) . ' به کیف پول شما واریز شد.', // 🛡️ FIX-PS-C2: $currency همیشه رشته است — ?? مرده
                    'data'       => [
                        'execution_id' => (int)$executionId,
                        'ad_id'        => (int)$exec->ad_id,
                        'amount'       => str_value($amount),
                    ],
                    'action_url' => '/wallet',
                ]);
            } catch (\Throwable $e) {
                $this->logger?->warning('social_task.approve_notify_failed', [
                    'execution_id' => $executionId,
                    'error' => $e->getMessage(),
                ]);
            }
            $this->db->query(
                "UPDATE ads
                 SET completed_count = COALESCE(completed_count,0)+1,
                     pending_count = GREATEST(COALESCE(pending_count,0)-1,0),
                     remaining_budget = GREATEST(COALESCE(remaining_budget,0)-?,0),
                     status = CASE
                         WHEN GREATEST(COALESCE(remaining_budget,0)-?,0) <= 0
                           OR (COALESCE(total_count,0) > 0 AND COALESCE(completed_count,0)+1 >= COALESCE(total_count,0))
                         THEN 'completed' ELSE status END,
                     is_active = CASE
                         WHEN GREATEST(COALESCE(remaining_budget,0)-?,0) <= 0
                           OR (COALESCE(total_count,0) > 0 AND COALESCE(completed_count,0)+1 >= COALESCE(total_count,0))
                         THEN 0 ELSE is_active END,
                     updated_at = NOW()
                 WHERE id = ?",
                [(string)$amount, (string)$amount, (string)$amount, (int)$exec->ad_id] // FIX-R19-A6-5: DECIMAL binding — (float) representation noise نمی‌سازد
            );
            $this->db->query("INSERT INTO social_user_trust (user_id, trust_score, created_at, updated_at) VALUES (?, 55, NOW(), NOW()) ON DUPLICATE KEY UPDATE trust_score = LEAST(100, trust_score + 5), updated_at = NOW()", [(int)$exec->executor_id]);
            $this->db->commit();

            // ── FIX-R16A (Task 16-A) — قلابِ «اولین تسک کامل‌شده» ──────────────
            // این همان نقطهٔ increment شدن completed_count است (UPDATE بالا).
            // اگر مجری، کاربرِ معرفی‌شده‌ای باشد که پاداش معرفش به‌صورت pending
            // نگه داشته شده (مسیر OAuth — سیاست anti-fraud مالک پروژه)، اکنون
            // اولین فعالیت واقعی‌اش کامل شده و کمیسیون به معرف پرداخت می‌شود.
            // غیرمسدودکننده: بعد از commit و درون try/catch مستقل — هر خطایی فقط
            // لاگ می‌شود و تأیید/پرداختِ خودِ تسک را تحت‌تأثیر قرار نمی‌دهد.
            // Idempotency در خودِ سرویس تضمین شده (FOR UPDATE + UNIQUE کلید).
            //
            // ── FIX-R18N (Task 18-N — R90 pay-time gate) ─────────────────────
            // پیش از اعتبار، گیتِ ضد-فارمینگ دوباره ارزیابی می‌شود: kill-switch،
            // وضعیت معرف (ban/suspend/delete) و آستانهٔ فارمینگ. اگر گیت اجازه
            // ندهد، اعتبار SKIP می‌شود (لاگ warning) و ردیف pending برای بازبینی
            // ادمین باقی می‌ماند. اگر ردیف pending‌ای وجود نداشته باشد یا گیت
            // تزریق نشده باشد (ساخت دستی/تست)، مسیر عادیِ today حفظ می‌شود.
            // گارد FOR UPDATE داخلیِ سرویس همچنان backstop اتمی است.
            try {
                $executorId = (int)$exec->executor_id;
                $referralCreditGated = false;
                if ($this->referralGate !== null) {
                    $pendingReferrerRow = $this->db->fetch(
                        "SELECT referrer_id FROM referral_commissions
                         WHERE referred_user_id = ? AND status = 'pending' AND source_type = 'signup'
                         ORDER BY id ASC LIMIT 1",
                        [$executorId]
                    );
                    $pendingReferrerId = (int)($pendingReferrerRow?->referrer_id ?? 0);
                    if ($pendingReferrerId > 0) {
                        $gateVerdict = $this->referralGate->guardRewardCredit($pendingReferrerId);
                        if (empty($gateVerdict['allowed'])) {
                            $this->logger?->warning('social_task.approve.referral_credit_gated', [
                                'execution_id' => $executionId,
                                'executor_id'  => $executorId,
                                'referrer_id'  => $pendingReferrerId,
                                'reason'       => str_value($gateVerdict['reason'] ?? 'unknown'),
                            ]);
                            $referralCreditGated = true;
                        }
                    }
                }
                if (!$referralCreditGated) {
                    $this->referralService?->creditPendingReferralRewardOnFirstTask($executorId);
                }
            } catch (\Throwable $referralCreditError) {
                $this->logger?->warning('social_task.approve.referral_first_task_credit_failed', [
                    'execution_id' => $executionId,
                    'executor_id'  => (int)$exec->executor_id,
                    'error'        => $referralCreditError->getMessage(),
                ]);
            }

            return ['success' => true, 'message' => 'اجرا تأیید و پاداش پرداخت شد.'];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollback();
            return ['success' => false, 'message' => 'خطا در تأیید اجرا: ' . $e->getMessage()];
        }
    }

    /**
     * 🛡️ S27D-F1 (FIX-R18B — restore): override ادمین از همان موتور تراکنشی
     * escrow-محورِ handle() می‌گذرد — پاداش فقط از بودجهٔ قفل‌شدهٔ اسکرو
     * تبلیغ‌دهنده (EscrowService::partialRelease با کلید socialTaskReward)
     * با burn کارمزد (FinancialEscrowService::consumeHeldBudget با کلید
     * socialTaskFee) پرداخت می‌شود؛ هیچ ضربِ «از هیچ‌جا» و رویداد فانتوم
     * reward_approved وجود ندارد (emit قدیمی مسیر override حذف شد).
     * fail-closed: اسکرو ناموجود → rollback + شکست (پرداخت بدون پشتوانه ممنوع).
     *
     * تفاوت‌های عمدی با handle():
     *  - بدون گارد مالکیت (پرایویج ادمین — caller: Admin\SocialTaskController
     *    از طریق SocialTaskService::adminOverrideExecution)؛
     *  - بدون قید status==='submitted' (معنای override = تصمیم‌گیری مجدد روی
     *    هر وضعیت؛ کلیدهای idempotency از پرداخت دوم جلوگیری می‌کنند)؛
     *  - متادیتای overridden_by/override_reason/overridden_at روی رکورد اجرا؛
     *  - پذیرش 'soft_approved' هم‌راستا با تصمیم فعلی محصول در سرویس.
     */
    /** @return array<string, mixed> */
    public function handleAdminOverride(int $executionId, int $adminId, string $decision, string $reason): array
    {
        $reason = trim((string)$reason);
        if (!in_array($decision, ['approved', 'soft_approved'], true)) {
            return ['success' => false, 'message' => 'تصمیم معتبر نیست'];
        }
        if ($reason === '') {
            return ['success' => false, 'message' => 'دلیل override الزامی است'];
        }

        try {
            $this->db->beginTransaction();
            $exec = $this->execModel->getExecutionById($executionId, true);
            if (!$exec) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'اجرا یافت نشد'];
            }
            $ad = $this->taskModel->getAdById((int)$exec->ad_id, true);
            if (!$ad) {
                $this->db->rollback();
                return ['success' => false, 'message' => 'کمپین یافت نشد'];
            }

            // ── FIX-R18N (Task 18-N — CAS status guard، طراحی REVIEW_ROUND18 #16) ──
            // ردیف زیر قفل FOR UPDATE خوانده شده است؛ اگر وضعیت فعلی همان تصمیمِ
            // هدف باشد یعنی bookkeepingِ این تصمیم قبلاً اعمال شده و اجرای دوبارهٔ
            // override نباید completed_count را دوباره +1، بودجه را دوباره - و
            // trust را دوباره +5 کند (پرداخت خودش با کلید idempotency ایمن است،
            // اما شمارنده‌ها/trust نیستند). re-decide واقعی روی وضعیتِ متفاوت
            // (مثلاً submitted→approved یا rejected→approved) همچنان مجاز است.
            $oldStatus = (string)$exec->status;
            if ($oldStatus === $decision) {
                $this->execModel->updateExecutionStatus($executionId, $decision, [
                    'overridden_by'   => $adminId,
                    'override_reason' => $reason,
                    'overridden_at'   => date('Y-m-d H:i:s'),
                    'reviewed_by'     => $adminId,
                    'reviewed_at'     => date('Y-m-d H:i:s'),
                ]);
                $this->db->commit();
                $this->logger?->info('social_task.admin_override.already_applied_skipped_bookkeeping', [
                    'execution_id' => $executionId,
                    'admin_id'     => $adminId,
                    'status'       => $oldStatus,
                ]);
                return [
                    'success'      => true,
                    'message'      => 'این تصمیم قبلاً اعمال شده است؛ بوک‌کیپینگ دوباره اعمال نشد.',
                    'old_decision' => $exec->decision ?? null,
                    'new_decision' => $decision,
                ];
            }

            $amount   = (string)($ad->price_per_task ?? '0');
            $currency = (string)($ad->currency ?? 'irt');

            $escrowService = $this->escrowService;
            if ($escrowService === null) {
                // ── FAIL-CLOSED: همان قرارداد handle() — بدون سرویس اسکرو پرداخت ممنوع ──
                $this->db->rollback();
                $this->logger?->error('social_task.admin_override.no_escrow_service_fail_closed', ['execution_id' => $executionId]);
                return ['success' => false, 'message' => 'سرویس Escrow در دسترس نیست؛ override متوقف شد (نیازمند بررسی).'];
            }

            $escrow = $escrowService->getByOrder((int)$exec->ad_id, 'social_task_budget');
            if (!$escrow || !in_array((string)$escrow->status, ['pending', 'in_escrow', 'partial'], true)) {
                // ── FAIL-CLOSED (S27D-F1): بدون اسکرو، پاداش پرداخت نمی‌شود ──
                $this->db->rollback();
                $this->logger?->error('social_task.admin_override.no_escrow_fail_closed', [
                    'execution_id' => $executionId,
                    'ad_id'        => (int)$exec->ad_id,
                ]);
                return ['success' => false, 'message' => 'escrow بودجه‌ی تسک اجتماعی یافت نشد؛ پرداخت متوقف شد (نیازمند بررسی ادمین).'];
            }

            // 🛡️ FIX-SOCIAL-FEE-BURN parity: کارمزد قبل از release burn می‌شود
            // (بعد از release ممکن است اسکرو 'released' شود و consumable نباشد).
            $feePercent = $this->socialFeePercent($ad);
            if (bccomp($feePercent, '0', 8) > 0) {
                $fee = Money::fromString($amount, $currency)->percentage($feePercent)->getAmount();
                if (bccomp($fee, '0', 8) > 0) {
                    if ($this->financialEscrow === null) {
                        $this->db->rollback();
                        $this->logger?->error('social_task.admin_override.no_financial_escrow_fail_closed', ['execution_id' => $executionId]);
                        return ['success' => false, 'message' => 'سرویس مالی اسکرو در دسترس نیست؛ override متوقف شد.'];
                    }
                    $consume = $this->financialEscrow->consumeHeldBudget(
                        (int)$escrow->id,
                        (int)$ad->user_id,
                        $fee,
                        $currency,
                        'کارمزد سایت تسک اجتماعی',
                        'social_task_settlement',
                        \App\Services\Shared\IdempotencyKeys::socialTaskFee($executionId)
                    );
                    if (empty($consume['ok'])) {
                        throw new \RuntimeException(is_string($consume['error'] ?? null) ? $consume['error'] : 'خطا در تسویه کارمزد تسک اجتماعی.');
                    }
                }
            }

            $release = $escrowService->partialRelease(
                (int)$escrow->id,
                (int)$exec->executor_id,
                $amount,
                \App\Services\Shared\IdempotencyKeys::socialTaskReward((int)$executionId)
            );
            if (empty($release['ok'])) {
                throw new \RuntimeException(str_value($release['error'] ?? 'خطا در آزادسازی پاداش اجتماعی از escrow.'));
            }

            // 🛡️ FIX-X140b parity: پاداش درصدی سطح مجری — best-effort، جدا از
            // بودجهٔ escrow (تأمین پلتفرم) با کلید مستقل؛ هرگز override نمی‌شکند.
            try {
                if ($this->outbox !== null && bccomp($amount, '0', 2) > 0) {
                    $bonusPercentStmt = $this->db->prepare(
                        "SELECT l.earning_bonus_percent FROM users u
                         JOIN user_levels l ON l.slug = u.level_slug AND l.is_active = 1
                         WHERE u.id = ? LIMIT 1"
                    );
                    $bonusPercentStmt->execute([(int)$exec->executor_id]);
                    $bonusPercentRaw = $bonusPercentStmt->fetchColumn();
                    $bonusPercent = $bonusPercentRaw === null ? 0.0 : (float)$bonusPercentRaw;
                    if ($bonusPercent > 0) {
                        $bonusAmount = bcmul($amount, bcdiv((string)$bonusPercent, '100', 8), 8);
                        if (bccomp($bonusAmount, '0', 2) > 0) {
                            $this->outbox->record('wallet', (int)$exec->executor_id, 'wallet.deposit.requested', [
                                'user_id' => (int)$exec->executor_id,
                                'amount' => $bonusAmount,
                                'currency' => $currency,
                                'metadata' => [
                                    'type' => 'level_earning_bonus',
                                    'description' => "پاداش درصدی سطح ({$bonusPercent}٪) برای درآمد تسک اجتماعی #{$executionId}",
                                    'idempotency_key' => 'level_bonus_social_' . $executionId,
                                    'source_execution_id' => $executionId,
                                ],
                            ]);
                        }
                    }
                }
            } catch (\Throwable $levelBonusError) {
                $this->logger?->warning('social_task.admin_override.level_bonus_failed', [
                    'execution_id' => $executionId,
                    'error' => $levelBonusError->getMessage(),
                ]);
            }

            $overrideData = [
                'reward_paid'     => 1,
                'reward_amount'   => $amount,
                'decision'        => $decision,
                'overridden_by'   => $adminId,
                'override_reason' => $reason,
                'overridden_at'   => date('Y-m-d H:i:s'),
                'reviewed_by'     => $adminId,
                'reviewed_at'     => date('Y-m-d H:i:s'),
            ];
            $this->execModel->updateExecutionStatus($executionId, $decision, $overrideData);

            // اطلاع‌رسانی مجری — الگوی notification.requested (بدون رویداد فانتوم)
            try {
                $this->outbox?->record('notification', (int)$exec->executor_id, 'notification.requested', [
                    'user_id'    => (int)$exec->executor_id,
                    'type'       => 'social_task_approved',
                    'title'      => 'اجرای شما تأیید شد ✅',
                    'message'    => "اجرای شما از تسک #{$exec->ad_id} توسط پشتیبانی تأیید شد و پاداش " . str_value($amount) . ' ' . str_value($currency) . ' به کیف پول شما واریز شد.',
                    'data'       => [
                        'execution_id' => (int)$executionId,
                        'ad_id'        => (int)$exec->ad_id,
                        'amount'       => str_value($amount),
                        'overridden_by' => $adminId,
                    ],
                    'action_url' => '/wallet',
                ]);
            } catch (\Throwable $e) {
                $this->logger?->warning('social_task.admin_override_notify_failed', [
                    'execution_id' => $executionId,
                    'error' => $e->getMessage(),
                ]);
            }

            // بوک‌کیپینگ کمپین + trust — عیناً همان handle()
            $this->db->query(
                "UPDATE ads
                 SET completed_count = COALESCE(completed_count,0)+1,
                     pending_count = GREATEST(COALESCE(pending_count,0)-1,0),
                     remaining_budget = GREATEST(COALESCE(remaining_budget,0)-?,0),
                     status = CASE
                         WHEN GREATEST(COALESCE(remaining_budget,0)-?,0) <= 0
                           OR (COALESCE(total_count,0) > 0 AND COALESCE(completed_count,0)+1 >= COALESCE(total_count,0))
                         THEN 'completed' ELSE status END,
                     is_active = CASE
                         WHEN GREATEST(COALESCE(remaining_budget,0)-?,0) <= 0
                           OR (COALESCE(total_count,0) > 0 AND COALESCE(completed_count,0)+1 >= COALESCE(total_count,0))
                         THEN 0 ELSE is_active END,
                     updated_at = NOW()
                 WHERE id = ?",
                [(string)$amount, (string)$amount, (string)$amount, (int)$exec->ad_id] // FIX-R19-A6-5: DECIMAL binding — (float) representation noise نمی‌سازد
            );
            $this->db->query("INSERT INTO social_user_trust (user_id, trust_score, created_at, updated_at) VALUES (?, 55, NOW(), NOW()) ON DUPLICATE KEY UPDATE trust_score = LEAST(100, trust_score + 5), updated_at = NOW()", [(int)$exec->executor_id]);
            $this->db->commit();

            // ── FIX-R19-A6-4: extend R90 gate + pending credit to admin-override path
            // (FIX-R18N mirror) ────────────────────────────────────────────────────
            // عیناً قرینهٔ handle():237-270 — اینجا هم نقطهٔ increment شدن
            // completed_count است (UPDATE بالای کمپین)، پس پاداشِ معلقِ معرفِ مجریِ
            // OAuth-معرفی‌شده باید دقیقاً همین‌جا قفل‌گشایی شود؛ وگرنه اولین (یا تنها)
            // تسکِ تأییدشده با override ادمین، کمیسیون pending معرف را برای همیشه
            // معلق می‌گذارد. گیت R90 (ReferralAntiFarmingGate، همان تزریقِ سازنده)
            // پیش از اعتبار دوباره ارزیابی می‌شود؛ !allowed ⇒ لاگ warning + SKIP و
            // ردیف pending برای بازبینی ادمین باقی می‌ماند. کل بلوک try/catch مستقل —
            // هر خطایی فقط لاگ می‌شود و مسیر override را نمی‌شکند (قرارداد handle()).
            try {
                $executorId = (int)$exec->executor_id;
                $referralCreditGated = false;
                if ($this->referralGate !== null) {
                    $pendingReferrerRow = $this->db->fetch(
                        "SELECT referrer_id FROM referral_commissions
                         WHERE referred_user_id = ? AND status = 'pending' AND source_type = 'signup'
                         ORDER BY id ASC LIMIT 1",
                        [$executorId]
                    );
                    $pendingReferrerId = (int)($pendingReferrerRow?->referrer_id ?? 0);
                    if ($pendingReferrerId > 0) {
                        $gateVerdict = $this->referralGate->guardRewardCredit($pendingReferrerId);
                        if (empty($gateVerdict['allowed'])) {
                            $this->logger?->warning('social_task.admin_override.referral_credit_gated', [
                                'execution_id' => $executionId,
                                'executor_id'  => $executorId,
                                'referrer_id'  => $pendingReferrerId,
                                'reason'       => str_value($gateVerdict['reason'] ?? 'unknown'),
                            ]);
                            $referralCreditGated = true;
                        }
                    }
                }
                if (!$referralCreditGated) {
                    $this->referralService?->creditPendingReferralRewardOnFirstTask($executorId);
                }
            } catch (\Throwable $referralCreditError) {
                $this->logger?->warning('social_task.admin_override.referral_first_task_credit_failed', [
                    'execution_id' => $executionId,
                    'executor_id'  => (int)$exec->executor_id,
                    'error'        => $referralCreditError->getMessage(),
                ]);
            }

            return [
                'success'      => true,
                'message'      => 'تصمیم با موفقیت override شد',
                'old_decision' => $exec->decision ?? null,
                'new_decision' => $decision,
            ];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollback();
            $this->logger?->error('social_task.admin_override.failed', [
                'execution_id' => $executionId,
                'admin_id'     => $adminId,
                'error'        => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در override تصمیم: ' . $e->getMessage()];
        }
    }

    /**
     * 🛡️ FIX-SOCIAL-FEE-BURN — درصد کارمزد کمپین: اول site_commission_percent
     * ذخیره‌شده روی رکورد (که آداپتر هنگام ساخت — یا کوپن هنگام تخفیف —
     * نوشته)، وگرنه تنظیم رسمی social_task_site_fee_percent با پیش‌فرض
     * PercentageConstants::SOCIAL_TASK_FEE_PERCENT (همان AdSocialAdapter).
     */
    private function socialFeePercent(object $ad): string
    {
        $stored = $ad->site_commission_percent ?? null;
        if (is_scalar($stored) && is_numeric((string)$stored) && bccomp((string)$stored, '0', 8) >= 0) {
            return (string)$stored;
        }
        $setting = $this->appSettings?->get('social_task_site_fee_percent', \App\Constants\PercentageConstants::SOCIAL_TASK_FEE_PERCENT)
            ?? \App\Constants\PercentageConstants::SOCIAL_TASK_FEE_PERCENT;
        return is_numeric($setting) ? str_value($setting) : (string)\App\Constants\PercentageConstants::SOCIAL_TASK_FEE_PERCENT;
    }
}
