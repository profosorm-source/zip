<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Services\ScoreService;
use Core\Cache;

/**
 * UpdateFraudScoreJob — ثبت ناهمگام تغییرات امتیاز فراد در دیتابیس برای مقابله با DoS
 */
class UpdateFraudScoreJob
{
    private ScoreService $scoreService;

    public function __construct(ScoreService $scoreService) {
        $this->scoreService = $scoreService;
    }

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data): void
    {
        $userId = int_value($data['user_id'] ?? 0);
        $delta  = float_value($data['delta'] ?? 0);
        $domainValue = $data['domain'] ?? 'fraud';
        $sourceValue = $data['source'] ?? 'unknown';
        if (!is_string($domainValue) || $domainValue === '' || !is_string($sourceValue) || $sourceValue === '') {
            throw new \InvalidArgumentException('Fraud score domain and source must be non-empty strings.');
        }
        $domain = $domainValue;
        $source = $sourceValue;
        $meta   = $data['meta'] ?? [];

        if ($userId <= 0 || $delta == 0.0) {
            return;
        }

        // Physical writes executed inside background context using Unified ScoreService
        $metaData = is_array($meta) ? $meta : [];

        // 🛡️ FIX-R18-M15: کلید idempotency مشتق از پیلود جاب — الگوی WithdrawalListener:128.
        // بدون آن، re-delivery/at-least-once صف همان دلتا را دوباره به لجر اعمال می‌کرد.
        // (user_id|domain|source|delta|meta) قطعی است؛ همان delivery تکراری با همان
        // پیلود skip می‌شود، ولی دلتای مشروع بعدی (پیلود متفاوت) مسیرش باز است.
        $idemKey = 'fraud_score_' . hash('sha256', (string)$userId . '|' . $domain . '|' . $source . '|' .
            var_export($delta, true) . '|' . md5((string)json_encode($metaData, JSON_UNESCAPED_UNICODE)));

        $this->scoreService->applyDelta('user', $userId, $domain, $delta, $source, $metaData, $idemKey);
    }
}
