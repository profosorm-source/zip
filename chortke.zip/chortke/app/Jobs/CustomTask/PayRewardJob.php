<?php

declare(strict_types=1);

namespace App\Jobs\CustomTask;

use App\Models\CustomTaskSubmissionModel;
use App\Models\User;
use App\Contracts\WalletServiceInterface;
use App\Services\Shared\ReferralService;
use App\Services\Shared\IdempotencyService;
use Core\Logger;
use App\Services\OutboxService;

/**
 * FIX-R36-W3 (F-A17-05) — یتیمِ C06-باگ۲ (مستند؛ حذف ممنوع در این موج):
 * تنها نقطهٔ ورود عمومی‌اش CustomTaskModerationService::payWorkerReward() است که
 * پس از C06-باگ۲ صفر فراخوان دارد (پرداخت فقط از settleCustomTaskReward = escrow
 * fail-closed + fee burn می‌گذرد). منطق داخلی خودش سالم است (P0-19: کلید واحد +
 * بازخوانی reward_paid) و در صورت enqueue فرضی با payload آرایه‌ای، TypeError
 * همین‌جا → dead-letter (fail-safe؛ DLQ noise، نه ضرر پولی).
 * پیشنهاد (cross-domain): حذف آگاهانهٔ کلاس + entry آن از config/queue.php:40 در
 * یک پاس پاک‌سازی آینده، یا rewire عمدی با payload آرایه‌ای و تأمین escrow.
 */
class PayRewardJob
{
    private CustomTaskSubmissionModel $submissionModel;
    private User $userModel;
    private WalletServiceInterface $walletService;
    private Logger $logger;
    private ?OutboxService $outbox;
    private IdempotencyService $idempotencyService;
    public function __construct(
        CustomTaskSubmissionModel $submissionModel,
        User $userModel,
        WalletServiceInterface $walletService,
        Logger $logger,
        IdempotencyService $idempotencyService,
        ?OutboxService $outbox = null
    ) {        $this->submissionModel = $submissionModel;
        $this->userModel = $userModel;
        $this->walletService = $walletService;
        $this->logger = $logger;
        $this->idempotencyService = $idempotencyService;
        $this->outbox = $outbox;
}

    public function handle(\stdClass $submission): void
    {
        // ── P0-19 FIX (بخش ۱: یکسان‌سازی کلید idempotency) ──────────────────
        // مسیر ماژول Moderation برای همین پرداخت از کلید
        // 'custom_task_reward_{id}' استفاده می‌کند؛ این جاب 'ctask_reward_{id}'
        // می‌ساخت — دو کلید متفاوت برای یک عملیات یعنی حصار UNIQUE بی‌اثر و
        // امکان پرداخت دوبل. اکنون هر دو موتور یک کلید واحد دارند.
        $idempotencyKey = \App\Services\Shared\IdempotencyKeys::customTaskReward((int)$submission->id);

        // ── P0-19 FIX (بخش ۲: گارد reward_paid با خواندن تازه) ─────────────
        // این جاب ممکن است replay شود (retry صف/کرون) در حالی که آبجکت ورودی
        // stale است. وضعیت پرداخت از DB بازخوانی می‌شود؛ اگر قبلاً ثبت شده،
        // هیچ عملیات مالی/outbox جدیدی انجام نمی‌شود.
        $fresh = $this->submissionModel->submission_find((int)$submission->id);
        if ($fresh && !empty($fresh->reward_paid)) {
            $this->logger->info('custom_task.reward_already_paid_skip', ['submission_id' => $submission->id]);
            return;
        }

        // Use transactional outbox to enqueue async wallet deposit so it's durable with DB transaction
        try {
            $payload = [
                'user_id' => $submission->worker_id,
                'amount' => $submission->reward_amount,
                'currency' => $submission->reward_currency,
                'metadata' => [
                    'type' => 'task_reward',
                    'description' => "پاداش وظیفه #{$submission->task_id}",
                    'idempotency_key' => $idempotencyKey,
                    'submission_id' => $submission->id,
                ],
            ];

            if ($this->outbox) {
                $ok = $this->outbox->record('custom_task_submission', (int)$submission->id, 'wallet.deposit.requested', $payload);
                if ($ok) {
                    $this->submissionModel->submission_update($submission->id, [
                        'reward_paid' => 1,
                        'reward_transaction_id' => null,
                    ]);
                } else {
                    $this->logger->error('custom_task.outbox_record_failed', ['submission_id' => $submission->id]);
                }
            } else {
                // Fallback: synchronous deposit via IdempotencyService
                $payload['metadata']['idempotency_key'] = $idempotencyKey;
                $txId = $this->idempotencyService->executeWithTransaction(
                    'wallet.deposit',
                    $submission->worker_id,
                    $payload,
                    function () use ($submission, $payload) {
                        return $this->walletService->deposit($submission->worker_id, $submission->reward_amount, $submission->reward_currency, $payload['metadata']);
                    },
                    $idempotencyKey
                );

                if (isset($txId['success']) && $txId['success']) {
                    $this->submissionModel->submission_update($submission->id, [
                        'reward_paid' => 1,
                        'reward_transaction_id' => $txId['transaction_id'],
                    ]);
                }
            }

            // 🛡️ FIX-X141 (D3 — راند 37): پاداش درصدی سطح کارگر — جدا از پاداش پایه
            // (بودجهٔ تبلیغ‌دهنده دست نمی‌خورد؛ تأمین پلتفرم) با کلید idempotency مستقل.
            // شکستِ این بخش هرگز پرداخت پایه را نمی‌شکند.
            try {
                $bonusPercent = app(\App\Services\User\UserLevelQueryService::class)->getEarningBonusPercent((int)$submission->worker_id);
                if ($bonusPercent > 0 && is_numeric((string)$submission->reward_amount) && bccomp((string)$submission->reward_amount, '0', 2) > 0) {
                    $bonusAmount = bcmul((string)$submission->reward_amount, bcdiv((string)$bonusPercent, '100', 8), 8);
                    if (bccomp($bonusAmount, '0', 2) > 0) {
                        $bonusKey = 'level_bonus_ctask_' . (int)$submission->id;
                        $bonusMetadata = [
                            'type' => 'level_earning_bonus',
                            'description' => "پاداش درصدی سطح ({$bonusPercent}٪) برای درآمد تسک سفارشی #{$submission->id}",
                            'idempotency_key' => $bonusKey,
                            'submission_id' => $submission->id,
                        ];
                        if ($this->outbox) {
                            $this->outbox->record('custom_task_submission', (int)$submission->id, 'wallet.deposit.requested', [
                                'user_id' => (int)$submission->worker_id,
                                'amount' => $bonusAmount,
                                'currency' => $submission->reward_currency,
                                'metadata' => $bonusMetadata,
                            ]);
                        } else {
                            $this->idempotencyService->executeWithTransaction(
                                'wallet.deposit',
                                (int)$submission->worker_id,
                                ['metadata' => $bonusMetadata],
                                function () use ($submission, $bonusAmount, $bonusMetadata) {
                                    return $this->walletService->deposit((int)$submission->worker_id, $bonusAmount, $submission->reward_currency, $bonusMetadata);
                                },
                                $bonusKey
                            );
                        }
                        $this->logger->info('custom_task.level_bonus_paid', [
                            'submission_id' => $submission->id,
                            'worker_id' => $submission->worker_id,
                            'bonus_percent' => $bonusPercent,
                            'bonus_amount' => $bonusAmount,
                        ]);
                    }
                }
            } catch (\Throwable $levelBonusError) {
                $this->logger->warning('custom_task.level_bonus_failed', [
                    'submission_id' => $submission->id,
                    'error' => $levelBonusError->getMessage(),
                ]);
            }

            $userRecord = $this->userModel->findById($submission->worker_id);
            if ($userRecord && !empty($userRecord->referred_by)) {
                // 🛡️ Outbox-first pattern (consistent with ProcessSeoTaskAsyncJob)
                $this->outbox?->record('referral', $submission->worker_id, 'referral.commission.process', [
                    'referrer_id' => (int)$userRecord->referred_by,
                    'amount' => (string)$submission->reward_amount,
                    'currency' => $submission->reward_currency,
                    'source_user_id' => $submission->worker_id,
                    'context' => [
                        'action' => 'custom_task_reward',
                        'executor_id' => $submission->worker_id,
                        'execution_id' => $submission->id
                    ]
                ]);
            }
        } catch (\Throwable $e) {
            $this->logger->error('custom_task.pay_worker_outbox_failed', ['submission_id' => $submission->id, 'error' => $e->getMessage()]);
        }
    }
}
