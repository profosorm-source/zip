<?php

declare(strict_types=1);

namespace App\Jobs\CustomTask;

use App\Models\CustomTaskSubmissionModel;
use App\Models\Ads;
use Core\Database;
use App\Services\CustomTask\CustomTaskModerationService;
use App\Services\Settings\AppSettings;
use Core\Logger;
use Core\EventDispatcher;

class CronSubmissionsJob
{
    private CustomTaskSubmissionModel $submissionModel;
    private CustomTaskModerationService $moderationService;
    private AppSettings $appSettings;
    private Logger $logger;
    private Database $db;
    private Ads $taskModel;
    private \App\Services\Notification\NotificationTemplateService $templateService;
    private ?\App\Contracts\OutboxServiceInterface $outbox = null;
    public function __construct(
        CustomTaskSubmissionModel $submissionModel,
        CustomTaskModerationService $moderationService,
        AppSettings $appSettings,
        Logger $logger,
        Database $db,
        Ads $taskModel,
        \App\Services\Notification\NotificationTemplateService $templateService,
        ?\App\Contracts\OutboxServiceInterface $outbox = null
    ) {        $this->submissionModel = $submissionModel;
        $this->moderationService = $moderationService;
        $this->appSettings = $appSettings;
        $this->logger = $logger;
        $this->db = $db;
        $this->taskModel = $taskModel;
        $this->templateService = $templateService;
        $this->outbox = $outbox;
}

    /**
     * FIX-R36-W3 (F-A17-06): این کلاس در config/queue.php:39 allowlist است ولی
     * handle() نداشت — اگر روزی push می‌شد QueueWorker:170 «no handle method»
     * می‌انداخت → ۵ retry → DLQ noise دائمی. handle() حالا هر دو sweep را صدا
     * می‌زند؛ هر دو سمت خودشان idempotent/CAS هستند (approveSubmission =
     * FOR UPDATE + whitelist + escrow fail-closed؛ expire = FIX-S17-4 CAS) پس
     * اجرای at-least-once صف ایمن است. فراخوانی‌های sync فعلی
     * (AdminCustomTaskService:656,662) مستقیم متدهای sweep را صدا می‌زنند و
     * دست‌نخورده‌اند. شکست infra این‌جا rethrow می‌شود (قرارداد FIX-R18-M14) —
     * صف‌نمایان، retry/DLQ؛ بلعِ سطح sweep self-healing خودش داخل متدهاست.
     */
     /** @return array{success: bool, auto_approved: int, expired: int} */
     public function handle(): array
    {
        $autoApproved = $this->autoApproveOldSubmissions();
        $expired = $this->expireOldSubmissions();
        return ['success' => true, 'auto_approved' => $autoApproved, 'expired' => $expired];
    }

    public function autoApproveOldSubmissions(): int
    {
        $hours = int_value($this->appSettings->get('custom_task_auto_approve_hours', 48));
        // 🧹 FIX-COSMET-14 (A1-N7/پایین): ۰ یعنی غیرفعال، نه تأیید آنی — قبلاً
        // INTERVAL COALESCE(ct.auto_approve_hours, 0) یعنی «همهٔ submitted ها
        // همین حالا تأیید شوند» بود؛ هم‌راستا با آداپتر که برای ≤۰ NULL ذخیره می‌کند.
        // 🛡️ FIX-V22-03b (بازبینی ۲۲): گاردِ «return 0 اگر تنظیم سراسری ≤۰» حذف شد —
        // این گارد وعدهٔ T22-16 را می‌شکست: تسک‌هایی که ساعتِ اختصاصیِ خودشان را
        // (موقع ساخت، از سراسریِ روشنِ آن زمان) ذخیره کرده‌اند، با خاموش‌کردن
        // تنظیم سراسری بی‌صدا بی‌اعتبار می‌شدند. اکنون گاه‌بندی به SQL منتقل شد:
        // COALESCE(ct.auto_approve_hours, ?) > 0 — سراسریِ ≤۰ فقط فالبکِ تسک‌های
        // بی‌ساعت را خاموش می‌کند و ساعتِ اختصاصی هر تسک مستقل اجرا می‌شود.
        $submissions = $this->submissionModel->getOldSubmissionsForAutoApproval($hours);

        $approved = 0;
        foreach ($submissions as $sub) {
            $result = $this->moderationService->approveSubmission($sub);
            if (empty($result['success'])) {
                // 🛡️ FIX-M22-MED (N9/D1-N8): شکست‌های تأیید بی‌صدا قورت داده می‌شدند —
                // ردیفِ همیشه‌شکست‌خورده (مثلاً escrow گمشده) هر ساعت تا ابد retry
                // می‌شد بدون حتی یک خط لاگ.
                // 🛡️ FIX-V22-03c (بازبینی ۲۲ — ضدگرسنگی sweep): هر شکست شمارندهٔ
                // auto_approve_attempts را زیاد می‌کند؛ ردیف‌های همیشه‌شکست‌خورده با
                // ORDER BY attempts ASC به انتهای صف می‌روند و پس از سقف
                // AUTO_APPROVE_PARK_THRESHOLD از کوئری حذف می‌شوند (پارک) تا
                // ردیف‌های سالمِ جدیدتر گرسنه نمانند. لاگ «پارک» فقط یک‌بار
                // (روی نفسِ عبور از آستانه) ثبت می‌شود.
                $attempts = (int)$this->submissionModel->submission_incrementAutoApproveAttempts((int)($sub->id ?? 0));
                $this->logger->warning('custom_task.auto_approve_failed', [
                    'submission_id' => $sub->id ?? null,
                    'task_id' => $sub->task_id ?? null,
                    'message' => is_string($result['message'] ?? null) ? $result['message'] : '',
                    'attempts' => $attempts,
                ]);
                if ($attempts >= CustomTaskSubmissionModel::AUTO_APPROVE_PARK_THRESHOLD) {
                    $this->logger->error('custom_task.auto_approve_parked', [
                        'submission_id' => $sub->id ?? null,
                        'task_id' => $sub->task_id ?? null,
                        'attempts' => $attempts,
                        'message' => is_string($result['message'] ?? null) ? $result['message'] : '',
                        'hint' => 'ردیف پس از شکست‌های مکرر از sweep پارک شد؛ نیازمند بررسی/تعیین تکلیف دستی است.',
                    ]);
                }
                continue;
            }
            $this->submissionModel->submission_update((int)$sub->id, ['auto_approved_at' => date('Y-m-d H:i:s')]);
            $approved++;

            // 🛡️ FIX-M22-MED (N9): گام نوتیفیکیشن بدون محافظ بود — یک قالب/کش خراب
            // با استثنا، باقی ارسال‌های همان دور و فاز expire بعدی را تا ساعت بعد
            // از کار می‌انداخت.
            try {
                $tpl = $this->templateService->renderTemplate('submission_auto_approved', ['task_title' => $sub->task_title]);
                $this->outbox?->record('notification', $sub->worker_id, 'notification.requested', [
                    'user_id' => $sub->worker_id,
                    'type' => 'auto_approved',
                    'title' => $tpl['title'],
                    'message' => $tpl['message'],
                    'data' => [
                        'submission_id' => $sub->id,
                        'task_id' => $sub->task_id
                    ]
                ]);
            } catch (\Throwable $notifyErr) {
                $this->logger->warning('custom_task.auto_approve_notify_failed', [
                    'submission_id' => $sub->id,
                    'error' => $notifyErr->getMessage(),
                ]);
            }
        }

        return $approved;
    }
    public function expireOldSubmissions(): int
    {
        $expired = 0;
        $submissions = $this->submissionModel->submission_getExpiredSubmissions();

        foreach ($submissions as $sub) {
            try {
                $this->db->beginTransaction();

                // 🛡️ FIX-S17-4 (Race — CAS): به‌روزرسانی بدون گارد وضعیت، تصویبِ هم‌زمان
                // (ادمین یا اتو-اپروو) را بازنویسی می‌کرد (approved→expired) و
                // pending_count/remaining_count را خراب می‌کرد. انتقال اتمیک فقط از
                // in_progress → expired؛ در غیر این صورت شمارندهٔ تسک هم لمس نمی‌شود.
                $expiredClaimed = $this->submissionModel->submission_expireIfInProgress((int)$sub->id);
                if (!$expiredClaimed) {
                    $this->db->commit();
                    continue;
                }

                $this->taskModel->decrementPendingCount($sub->task_id);

                $this->db->commit();
                $expired++;

            } catch (\Throwable $e) { // FIX-M22-MED (T22-17c): \Exception → \Throwable
                if ($this->db->inTransaction()) { $this->db->rollback(); }
                $this->logger->error('expire_submission_failed', [
                    'submission_id' => $sub->id,
                    'error' => $e->getMessage()
                ]);
            }
        }

        return $expired;
    }
}
