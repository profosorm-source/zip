<?php
declare(strict_types=1);

namespace App\Jobs\CustomTask;

use Core\Logger;
use Core\RateLimiter;
use App\Models\CustomTaskSubmissionModel;
use App\Models\Ads;
use App\Services\Settings\AppSettings;

class SubmitProofJob
{
    public function __construct(
        private RateLimiter $rateLimiter,
        private CustomTaskSubmissionModel $submissionModel,
        private Ads $taskModel,
        private AppSettings $appSettings,
        private Logger $logger,
        private ?\App\Contracts\OutboxServiceInterface $outbox = null,
        // 🛡️ FIX-S19-VFP: اتصال اثر انگشت ویدیو به چرخهٔ ارسال مدرک (nullable برای
        // سازگاری فراخوانی‌های فعلی؛ کانتینر آن را autowire می‌کند)
        private ?\App\Services\AntiFraud\VideoFingerprintService $videoFingerprint = null
    ) {}

/**
 * @param array<string, mixed> $payload
 * @return array<string, mixed>
 */
public function handle(array $payload): array
    {
        $submissionId = int_value($payload['submission_id'] ?? 0);
        $workerId = int_value($payload['worker_id'] ?? 0);
        $proofData = is_array($payload['proof_data'] ?? null) ? $payload['proof_data'] : [];
        $proofData['task_execution_id'] = $submissionId;

        if ($workerId <= 0 || $submissionId <= 0) {
            return ['success' => false, 'message' => 'شناسه کاربر یا اجرا نامعتبر است.'];
        }

        if (!$this->rateLimiter->attempt('custom_task:submit:' . $workerId, 10, 10)) {
            $wait = ceil($this->rateLimiter->availableIn('custom_task:submit:' . $workerId) / 60);
            return ['success' => false, 'message' => "تعداد درخواست‌های شما بیش از حد مجاز است. لطفا {$wait} دقیقه دیگر امتحان کنید."];
        }

        try {
            $submission = $this->submissionModel->submission_findById($submissionId);
            if (!$submission || (int)$submission->worker_id !== $workerId) {
                return ['success' => false, 'message' => 'دسترسی غیرمجاز.'];
            }
            if ((string)$submission->status !== 'in_progress') {
                return ['success' => false, 'message' => 'وضعیت نامعتبر.'];
            }
            if (!empty($submission->deadline_at) && strtotime((string)$submission->deadline_at) < time()) {
                return ['success' => false, 'message' => 'مهلت ارسال مدرک پایان یافته.'];
            }

            $proofType = $this->normalizeProofType((string)($submission->proof_type ?? 'text'));
            $schemaError = $this->validateProofSchema($proofType, $proofData);
            if ($schemaError !== null) {
                return ['success' => false, 'message' => $schemaError];
            }

            $request = new \App\Validators\Requests\SubmitCustomTaskProofRequest($proofData);
            if (!$request->validate()) {
                return ['success' => false, 'message' => 'خطای اعتبارسنجی', 'errors' => $request->errors()];
            }
            $validated = array_merge($proofData, $request->validated());

            // 🛡️ FIX-S17-2 (الگوی FIX-S15-10 — IDOR write primitive): proof_file باید
            // مسیر تولیدشدهٔ UploadService باشد (task-proofs/24hex.ext). ورودی JSON خام
            // فقط nullable|string بود ⇒ رشتهٔ دلخواه (مثلاً مسیر فایل کاربر دیگر) در
            // رکورد ثبت و مسیر فایل دیگری مصادره می‌شد. مغایرت ⇒ drop + لاگ (fail-closed).
            $proofFile = trim(str_value($validated['proof_file'] ?? ''));
            if ($proofFile !== '' && preg_match('#^task-proofs/[0-9a-f]{24}\.[A-Za-z0-9]{1,8}$#', $proofFile) !== 1) {
                $this->logger->warning('customtask.proof_file.path_rejected', [
                    'submission_id' => $submissionId,
                    'path_prefix' => mb_substr($proofFile, 0, 64),
                ]);
                $validated['proof_file'] = null;
                $validated['proof_file_hash'] = null;
            }
            // proof_file_hash خارج از قواعد فرم است (فقط از نتیجهٔ آپلود سرچشمه می‌گیرد) — 64 hex
            $proofHash = trim(str_value($validated['proof_file_hash'] ?? ''));
            if ($proofHash !== '' && preg_match('/^[0-9a-f]{64}$/i', $proofHash) !== 1) {
                $validated['proof_file_hash'] = null;
            }

            $duplicate = $this->checkDuplicateProof($submission, $proofType, $validated);
            if ($duplicate !== null) {
                return ['success' => false, 'message' => $duplicate];
            }

            // 🛡️ FIX-S19-VFP — گیت cross-task اثر انگشت ویدیو: همان ویدیو (حتی با
            // variant های URL) برای تسک دیگر پذیرفته نمی‌شود؛ هش نرمال‌شده هم روی
            // رکورد لنگر و هم در corpus سراسری video_fingerprints تغذیه می‌شود.
            $proofUrlHash = null;
            if ($proofType === 'video' && !empty($validated['proof_url'])) {
                $videoGate = $this->resolveVideoFingerprintGate($submission, trim(str_value($validated['proof_url'])));
                if ($videoGate['error'] !== null) {
                    return ['success' => false, 'message' => $videoGate['error']];
                }
                $proofUrlHash = $videoGate['hash'];
            }

            $updateData = [
                'proof_url' => $validated['proof_url'] ?? null,
                'proof_text' => $validated['proof_text'] ?? null,
                'proof_code' => $validated['proof_code'] ?? null,
                'proof_file' => $validated['proof_file'] ?? null,
                'proof_file_hash' => $validated['proof_file_hash'] ?? null,
                'proof_url_hash' => $proofUrlHash,
                'proof_data' => $validated['proof_data'] ?? null,
                'submitted_at' => date('Y-m-d H:i:s'),
                'status' => 'submitted',
            ];

            // FIX-R19-A6-8: نوشتنِ وضعیت قبلاً unconditional بود (check-then-write؛
            // گارد :51-53 فقط خواندنی است) ⇒ دو submit هم‌زمان هر دو عبور می‌کردند و
            // آخرین نوشتن می‌برد (مدرک overwrite می‌شد). اکنون انتقالِ وضعیت CAS است:
            // UPDATE ... WHERE id = ? AND status = 'in_progress' — صفر شدن rowCount
            // یعنی اجرا دیگر in_progress نیست (قبلاً ارسال/انقضا/رد شده).
            $casStmt = $this->submissionModel->getDb()->prepare(
                "UPDATE custom_task_submissions
                 SET proof_url = ?, proof_text = ?, proof_code = ?, proof_file = ?, proof_file_hash = ?,
                     proof_url_hash = ?, proof_data = ?, submitted_at = ?, status = 'submitted'
                 WHERE id = ? AND status = 'in_progress'"
            );
            $casStmt->execute([
                $updateData['proof_url'],
                $updateData['proof_text'],
                $updateData['proof_code'],
                $updateData['proof_file'],
                $updateData['proof_file_hash'],
                $updateData['proof_url_hash'],
                $updateData['proof_data'],
                $updateData['submitted_at'],
                $submissionId,
            ]);
            if ($casStmt->rowCount() === 0) {
                return ['success' => false, 'message' => 'این اجرا قبلاً ارسال شده است.'];
            }

            // 🛡️ FIX-DEAD-EVENT: رویداد custom_task.submission_created هیچ listener ای
            // ندارد؛ نوتیفیکیشن سازندهٔ تسک پایین‌تر ثبت می‌شود → رکورد بی‌اثر حذف شد.

            $this->logger->info('Proof submitted', [
                'submission_id' => $submissionId,
                'worker_id' => $workerId,
                'proof_type' => $proofType,
            ]);

            $task = $this->taskModel->find((int)$submission->task_id);
            if ($task) {
                $this->outbox?->record('notification', (int)$task->user_id, 'notification.requested', [
                    'user_id' => (int)$task->user_id,
                    'type' => 'task_proof_submitted',
                    'title' => 'مدرک جدید دریافت شد',
                    'message' => 'مدرک جدیدی برای وظیفه «' . ($task->title ?? '') . '» ارسال شد و منتظر بررسی است.',
                    'data' => [
                        'task_id' => $task->id ?? 0,
                        'submission_id' => $submissionId,
                        'url' => '/user/custom-tasks/submissions/' . $submissionId,
                    ],
                ]);
            }

            $autoApproveHours = int_value($this->appSettings->get('custom_task_auto_approve_hours', 48));
            return [
                'success' => true,
                'message' => 'مدرک شما با موفقیت ارسال شد.',
                'auto_approve_info' => "در صورتی که کارفرما تا {$autoApproveHours} ساعت آینده بررسی نکند، بصورت خودکار تایید خواهد شد.",
            ];
        } catch (\Throwable $e) {
            $this->logger->error('task.proof_submission.failed', [
                'channel' => 'task',
                'error' => $e->getMessage(),
            ]);
            return ['success' => false, 'message' => 'خطا در ارسال مدرک.'];
        }
    }

    private function normalizeProofType(string $type): string
    {
        $type = strtolower(trim((string)$type));
        return match ($type) {
            'link' => 'url',
            'image' => 'screenshot',
            default => in_array($type, ['text', 'code', 'url', 'screenshot', 'file', 'video'], true) ? $type : 'text',
        };
    }

    /**
     * @param array<string, mixed> $data
     */
private function validateProofSchema(string $proofType, array $data): ?string
    {
        $text = trim(str_value($data['proof_text'] ?? ''));
        $url = trim(str_value($data['proof_url'] ?? ''));
        $code = trim(str_value($data['proof_code'] ?? ''));
        $file = trim(str_value($data['proof_file'] ?? ''));

        return match ($proofType) {
            'text' => mb_strlen((string)$text) >= 10 ? null : 'برای این تسک، توضیح متنی حداقل ۱۰ کاراکتر الزامی است.',
            'code' => mb_strlen((string)$code) >= 2 ? null : 'برای این تسک، کد یا شناسه مدرک الزامی است.',
            'url' => filter_var($url, FILTER_VALIDATE_URL) ? null : 'برای این تسک، لینک مدرک معتبر الزامی است.',
            'screenshot' => $file !== '' ? null : 'برای این تسک، اسکرین‌شات الزامی است.',
            'file' => $file !== '' ? null : 'برای این تسک، فایل مدرک الزامی است.',
            'video' => (filter_var($url, FILTER_VALIDATE_URL) || $file !== '') ? null : 'برای مدرک ویدیویی، لینک معتبر یا فایل ویدیو الزامی است.',
            default => ($text !== '' || $url !== '' || $code !== '' || $file !== '') ? null : 'مدرک انجام تسک الزامی است.',
        };
    }

    /**
     * 🛡️ FIX-S19-VFP — گیتِ اثر انگشت ویدیو.
     *
     *  ۱) دقیق: proof_url_hash (محصول VideoFingerprintService) روی تسکِ دیگرِ
     *     غیر-rejected دیده شود → رد.
     *  ۲) فازی: variant های URL (پروتکل/www/حروف/پارامتر کوئری) با video_id+
     *     platform از corpus سراسری کشف و با انتسابِ رکوردِ مالک رد می‌شوند؛
     *     ردیفِ متعلق به همان تسک یا rejected آزاد است (عدالتِ ریسابمیت).
     *
     * @return array{error: ?string, hash: ?string}
     */
    private function resolveVideoFingerprintGate(\stdClass $submission, string $proofUrl): array
    {
        try {
            if ($this->videoFingerprint === null) {
                return ['error' => null, 'hash' => null];
            }
            $fingerprint = $this->videoFingerprint->generateFingerprint($proofUrl, $this->resolveVideoPlatform($proofUrl));
            $combinedHash = str_value($fingerprint['combined_hash'] ?? '');
            if ($combinedHash === '') {
                return ['error' => null, 'hash' => null];
            }

            $db = $this->submissionModel->getDb();

            // ۱) تطابق دقیق اثر انگشت روی تسکِ دیگر
            $exact = $db->fetch(
                "SELECT id FROM custom_task_submissions WHERE proof_url_hash = ? AND task_id <> ? AND id <> ? AND status != 'rejected' LIMIT 1",
                [$combinedHash, (int)$submission->task_id, (int)$submission->id]
            );
            if ($exact) {
                return ['error' => 'این ویدیو قبلاً برای تسک دیگری استفاده شده است.', 'hash' => null];
            }

            // ۲) کشفِ فازی variant ها از corpus (checkDuplicate سمتِ unique خودش
            // corpus را تغذیه می‌کند — تغذیهٔ سراسری در پذیرشِ نخست)
            $dup = $this->videoFingerprint->checkDuplicate($fingerprint);
            if (($dup['is_duplicate'] ?? false) === true) {
                // 🛡️ FIX-R18D: کشِ checkDuplicate گاهی خودِ fingerprintِ کاندید را
                // برمی‌گرداند (آرتیفکت کلیدِ hash) — اثر انگشتِ خود کاندید مدرکِ
                // «تسک دیگر» نیست؛ به‌علاوه، هویتِ (platform,video_id) مستقیماً از
                // corpus پرسیده می‌شود تا نتیجه مستقل از وضعیت کش باشد.
                $suspectHashes = [];
                foreach ((array)($dup['matches'] ?? []) as $match) {
                    $matchHash = is_array($match)
                        ? str_value($match['combined_hash'] ?? '')
                        : str_value($match->combined_hash ?? '');
                    if ($matchHash !== '' && $matchHash !== $combinedHash) {
                        $suspectHashes[] = $matchHash;
                    }
                }
                try {
                    $identityRows = $db->fetchAll(
                        "SELECT combined_hash FROM video_fingerprints WHERE platform = ? AND video_id = ? AND combined_hash <> ? LIMIT 10",
                        [str_value($fingerprint['platform'] ?? ''), str_value($fingerprint['video_id'] ?? ''), $combinedHash]
                    ) ?: [];
                    foreach ($identityRows as $row) {
                        $h = is_object($row) ? str_value($row->combined_hash ?? '') : str_value((string)($row['combined_hash'] ?? ''));
                        if ($h !== '' && $h !== $combinedHash) {
                            $suspectHashes[] = $h;
                        }
                    }
                } catch (\Throwable) {
                    // پرس‌وجوی corpus بهترین‌تلاش است؛ تطابق دقیق بالا پوشش داده شده
                }
                foreach (array_unique($suspectHashes) as $suspectHash) {
                    $owner = $db->fetch(
                        "SELECT id FROM custom_task_submissions WHERE proof_url_hash = ? AND task_id <> ? AND status != 'rejected' LIMIT 1",
                        [$suspectHash, (int)$submission->task_id]
                    );
                    if ($owner) {
                        return ['error' => 'این ویدیو قبلاً برای تسک دیگری استفاده شده است.', 'hash' => null];
                    }
                }
                // مالکِ یافت‌نشده: همان تسک یا rejected — آزاد است (عدالت ریسابمیت)
                return ['error' => null, 'hash' => $combinedHash];
            }

            return ['error' => null, 'hash' => $combinedHash];
        } catch (\Throwable $e) {
            // قرارداد migration (FIX-S19-VFP): fail-open محدود برای زیرساخت/دادهٔ قدیمی —
            // شکستِ سرویس اثر انگشت مسیر ارسال مدرک را نمی‌شکند (فقط لاگ)
            $this->logger->warning('customtask.video_fingerprint.gate_error', [
                'submission_id' => (int)$submission->id,
                'error' => $e->getMessage(),
            ]);
            return ['error' => null, 'hash' => null];
        }
    }

    /** پلتفرم ویدیو از میزبانِ URL (برای video_id extraction واقعی به‌جای fallback) */
    private function resolveVideoPlatform(string $url): string
    {
        $host = strtolower((string)(parse_url($url, PHP_URL_HOST) ?: ''));
        if ($host !== '' && str_contains($host, 'youtu')) {
            return 'youtube';
        }
        if ($host !== '' && str_contains($host, 'aparat')) {
            return 'aparat';
        }
        return $host !== '' ? $host : 'generic';
    }

    /**
     * @param array<string, mixed> $data
     */
    private function checkDuplicateProof(\stdClass $submission, string $proofType, array $data): ?string
    {
        $taskId = (int)$submission->task_id;
        $submissionId = (int)$submission->id;
        $db = $this->submissionModel->getDb();

        if (!empty($data['proof_file_hash'])) {
            $row = $db->fetch(
                "SELECT id FROM custom_task_submissions WHERE task_id = ? AND proof_file_hash = ? AND id <> ? AND status != 'rejected' LIMIT 1",
                [$taskId, str_value($data['proof_file_hash']), $submissionId]
            );
            if ($row) return 'این فایل مدرک قبلاً برای این تسک ارسال شده است.';
        }
        if ($proofType === 'code' && !empty($data['proof_code'])) {
            $row = $db->fetch(
                "SELECT id FROM custom_task_submissions WHERE task_id = ? AND proof_code = ? AND id <> ? AND status != 'rejected' LIMIT 1",
                [$taskId, trim(str_value($data['proof_code'])), $submissionId]
            );
            if ($row) return 'این کد/شناسه قبلاً برای این تسک ارسال شده است.';
        }
        if (in_array($proofType, ['url', 'video'], true) && !empty($data['proof_url'])) {
            $row = $db->fetch(
                "SELECT id FROM custom_task_submissions WHERE task_id = ? AND proof_url = ? AND id <> ? AND status != 'rejected' LIMIT 1",
                [$taskId, trim(str_value($data['proof_url'])), $submissionId]
            );
            if ($row) return 'این لینک مدرک قبلاً برای این تسک ارسال شده است.';
        }

        return null;
    }
}
