<?php
declare(strict_types=1);

namespace App\Jobs\CustomTask;

use Core\Logger;
use Core\RateLimiter;
use App\Models\CustomTaskSubmissionModel;
use App\Models\Ads;
use App\Services\Settings\AppSettings;
// FIX-M22-MED (T22-18): قرارداد مشترک normalize/validate مدرک — حذف کپیِ تکراری
use App\Services\CustomTask\CustomTaskProofSchema;

class SubmitProofJob
{
    public function __construct(
        private RateLimiter $rateLimiter,
        private CustomTaskSubmissionModel $submissionModel,
        private Ads $taskModel,
        private AppSettings $appSettings,
        private Logger $logger,
        private ?\App\Contracts\OutboxServiceInterface $outbox = null,
        // 🛡️ FIX-S19-VFP: اتصال اثر انگشت ویدیو به چرخهٔ ارسال مدرک (nullable برای
        // سازگاری فراخوانی‌های فعلی؛ کانتینر آن را autowire می‌کند)
        private ?\App\Services\AntiFraud\VideoFingerprintService $videoFingerprint = null,
        // 🛡️ FIX-BEHAV1-09 (D2-N13r): پاک‌سازی فایلِ orphan در شکست‌های پس از
        // آپلود (nullable برای سازگاری فراخوانی‌های فعلی؛ کانتینر autowire می‌کند)
        private ?\App\Services\UploadService $uploadService = null
    ) {}

/**
 * @param array<string, mixed> $payload
 * @return array<string, mixed>
 */
public function handle(array $payload): array
    {
        $submissionId = int_value($payload['submission_id'] ?? 0);
        $workerId = int_value($payload['worker_id'] ?? 0);
        $proofData = is_array($payload['proof_data'] ?? null) ? $payload['proof_data'] : [];
        $proofData['task_execution_id'] = $submissionId;

        if ($workerId <= 0 || $submissionId <= 0) {
            $this->cleanupOrphanProofFile(str_value($proofData['proof_file'] ?? ''));
            return ['success' => false, 'message' => 'شناسه کاربر یا اجرا نامعتبر است.'];
        }

        if (!$this->rateLimiter->attempt('custom_task:submit:' . $workerId, 10, 10)) {
            $wait = ceil($this->rateLimiter->availableIn('custom_task:submit:' . $workerId) / 60);
            $this->cleanupOrphanProofFile(str_value($proofData['proof_file'] ?? ''));
            return ['success' => false, 'message' => "تعداد درخواست‌های شما بیش از حد مجاز است. لطفا {$wait} دقیقه دیگر امتحان کنید."];
        }

        // 🛡️ FIX-BEHAV1-09 (D2-N13r): پرچم «فایل به رکورد ارجاع داده شد» —
        // فقط پس از CAS موفق true می‌شود؛ catch فقط در false حذف می‌کند.
        $filePersisted = false;

        try {
            $submission = $this->submissionModel->submission_findById($submissionId);
            if (!$submission || (int)$submission->worker_id !== $workerId) {
                $this->cleanupOrphanProofFile(str_value($proofData['proof_file'] ?? ''));
                return ['success' => false, 'message' => 'دسترسی غیرمجاز.'];
            }
            if ((string)$submission->status !== 'in_progress') {
                $this->cleanupOrphanProofFile(str_value($proofData['proof_file'] ?? ''));
                return ['success' => false, 'message' => 'وضعیت نامعتبر.'];
            }
            if (!empty($submission->deadline_at) && strtotime((string)$submission->deadline_at) < time()) {
                $this->cleanupOrphanProofFile(str_value($proofData['proof_file'] ?? ''));
                return ['success' => false, 'message' => 'مهلت ارسال مدرک پایان یافته.'];
            }

            $proofType = CustomTaskProofSchema::normalizeType((string)($submission->proof_type ?? 'text'));
            // 🧾 FIX-M22-CLOSE (D2-edge): نوع مدرکِ محاسبه‌شدهٔ سرور برای قاعدهٔ
            // مشروط proof_text در SubmitCustomTaskProofRequest — مقدار کلاینت
            // (اگر در proof_data باشد) overwrite می‌شود.
            $proofData['proof_type'] = $proofType;
            $schemaError = CustomTaskProofSchema::validateSchema($proofType, $proofData);
            if ($schemaError !== null) {
                $this->cleanupOrphanProofFile(str_value($proofData['proof_file'] ?? ''));
                return ['success' => false, 'message' => $schemaError];
            }

            $request = new \App\Validators\Requests\SubmitCustomTaskProofRequest($proofData);
            if (!$request->validate()) {
                $this->cleanupOrphanProofFile(str_value($proofData['proof_file'] ?? ''));
                return ['success' => false, 'message' => 'خطای اعتبارسنجی', 'errors' => $request->errors()];
            }
            $validated = array_merge($proofData, $request->validated());

            // 🛡️ FIX-S17-2 (الگوی FIX-S15-10 — IDOR write primitive): proof_file باید
            // مسیر تولیدشدهٔ UploadService باشد (task-proofs/24hex.ext). ورودی JSON خام
            // فقط nullable|string بود ⇒ رشتهٔ دلخواه (مثلاً مسیر فایل کاربر دیگر) در
            // رکورد ثبت و مسیر فایل دیگری مصادره می‌شد. مغایرت ⇒ drop + لاگ (fail-closed).
            // 🛡️ FIX-M22-MED (T22-18): کانال فایل فقط از payload کنترلر می‌آید (نتیجهٔ
            // آپلود سرور + هش sha256 محاسبه‌شدهٔ سرور)؛ کلاینت دیگر هیچ راهی برای
            // تزریق رشتهٔ خام/هش جعلی به‌عنوان کلید دِداپ ندارد.
            $proofFile = trim(str_value($validated['proof_file'] ?? ''));
            if ($proofFile !== '' && preg_match('#^task-proofs/[0-9a-f]{24}\.[A-Za-z0-9]{1,8}$#', $proofFile) !== 1) {
                $this->logger->warning('customtask.proof_file.path_rejected', [
                    'submission_id' => $submissionId,
                    'path_prefix' => mb_substr($proofFile, 0, 64),
                ]);
                $validated['proof_file'] = null;
                $validated['proof_file_hash'] = null;
            }
            // proof_file_hash خارج از قواعد فرم است (فقط از نتیجهٔ آپلود سرچشمه می‌گیرد) — 64 hex.
            // FIX-M22-MED (T22-18): هشِ «بدون کانال فایل» هم رها می‌شود — هشِ معتبرِ
            // ۶۴hex به‌تنهایی دیگر به‌عنوان کلید دِداپ پذیرفته نمی‌شود (جعل کلاینت).
            $proofHash = trim(str_value($validated['proof_file_hash'] ?? ''));
            if ($proofHash !== '' && (preg_match('/^[0-9a-f]{64}$/i', $proofHash) !== 1 || $proofFile === '')) {
                $validated['proof_file_hash'] = null;
            }

            $duplicate = $this->checkDuplicateProof($submission, $proofType, $validated);
            if ($duplicate !== null) {
                $this->cleanupOrphanProofFile(str_value($validated['proof_file'] ?? ''));
                return ['success' => false, 'message' => $duplicate];
            }

            // 🛡️ FIX-S19-VFP — گیت cross-task اثر انگشت ویدیو: همان ویدیو (حتی با
            // variant های URL) برای تسک دیگر پذیرفته نمی‌شود؛ هش نرمال‌شده هم روی
            // رکورد لنگر و هم در corpus سراسری video_fingerprints تغذیه می‌شود.
            $proofUrlHash = null;
            if ($proofType === 'video' && !empty($validated['proof_url'])) {
                $videoGate = $this->resolveVideoFingerprintGate($submission, trim(str_value($validated['proof_url'])));
                if ($videoGate['error'] !== null) {
                    $this->cleanupOrphanProofFile(str_value($validated['proof_file'] ?? ''));
                    return ['success' => false, 'message' => $videoGate['error']];
                }
                $proofUrlHash = $videoGate['hash'];
            }

            $updateData = [
                'proof_url' => $validated['proof_url'] ?? null,
                'proof_text' => $validated['proof_text'] ?? null,
                'proof_code' => $validated['proof_code'] ?? null,
                'proof_file' => $validated['proof_file'] ?? null,
                'proof_file_hash' => $validated['proof_file_hash'] ?? null,
                'proof_url_hash' => $proofUrlHash,
                'proof_data' => $validated['proof_data'] ?? null,
                'submitted_at' => date('Y-m-d H:i:s'),
                'status' => 'submitted',
            ];

            // FIX-R19-A6-8: نوشتنِ وضعیت قبلاً unconditional بود (check-then-write؛
            // گارد :51-53 فقط خواندنی است) ⇒ دو submit هم‌زمان هر دو عبور می‌کردند و
            // آخرین نوشتن می‌برد (مدرک overwrite می‌شد). اکنون انتقالِ وضعیت CAS است:
            // UPDATE ... WHERE id = ? AND status = 'in_progress' — صفر شدن rowCount
            // یعنی اجرا دیگر in_progress نیست (قبلاً ارسال/انقضا/رد شده).
            $casStmt = $this->submissionModel->getDb()->prepare(
                "UPDATE custom_task_submissions
                 SET proof_url = ?, proof_text = ?, proof_code = ?, proof_file = ?, proof_file_hash = ?,
                     proof_url_hash = ?, proof_data = ?, submitted_at = ?, status = 'submitted'
                 WHERE id = ? AND status = 'in_progress'"
            );
            $casStmt->execute([
                $updateData['proof_url'],
                $updateData['proof_text'],
                $updateData['proof_code'],
                $updateData['proof_file'],
                $updateData['proof_file_hash'],
                $updateData['proof_url_hash'],
                $updateData['proof_data'],
                $updateData['submitted_at'],
                $submissionId,
            ]);
            if ($casStmt->rowCount() === 0) {
                // 🛡️ FIX-BEHAV1-09: مسابقهٔ CAS — ردیف، این فایل را نگرفت؛
                // فایلِ آپلودشدهٔ هم‌زمان در دیسک orphan است.
                $this->cleanupOrphanProofFile(str_value($validated['proof_file'] ?? ''));
                return ['success' => false, 'message' => 'این اجرا قبلاً ارسال شده است.'];
            }
            // 🛡️ FIX-BEHAV1-09: از این نقطه به بعد فایل به رکورد ارسال اشاره می‌کند؛
            // شکست‌های بعدی (outbox و…) نباید آن را حذف کنند.
            $filePersisted = true;

            // 🛡️ FIX-DEAD-EVENT: رویداد custom_task.submission_created هیچ listener ای
            // ندارد؛ نوتیفیکیشن سازندهٔ تسک پایین‌تر ثبت می‌شود → رکورد بی‌اثر حذف شد.

            $this->logger->info('Proof submitted', [
                'submission_id' => $submissionId,
                'worker_id' => $workerId,
                'proof_type' => $proofType,
            ]);

            $task = $this->taskModel->find((int)$submission->task_id);
            if ($task) {
                $this->outbox?->record('notification', (int)$task->user_id, 'notification.requested', [
                    'user_id' => (int)$task->user_id,
                    'type' => 'task_proof_submitted',
                    'title' => 'مدرک جدید دریافت شد',
                    'message' => 'مدرک جدیدی برای وظیفه «' . ($task->title ?? '') . '» ارسال شد و منتظر بررسی است.',
                    'data' => [
                        'task_id' => $task->id ?? 0,
                        'submission_id' => $submissionId,
                        // 🧹 FIX-COSMET-11 (A1-N5/پایین): روت واقعی ثبت شد — قبلاً
                        // /user/custom-tasks/submissions/{id} (بدون پیشوندِ درست و بدون
                        // /proof) به ۴۰۴ می‌رفت؛ روت زنده: routes/user.php
                        // GET /custom-tasks/submissions/{id}/proof (proofForm).
                        'url' => '/custom-tasks/submissions/' . $submissionId . '/proof',
                    ],
                ]);
            }

            // 🧹 FIX-COSMET-13 (A1-N6/پایین): وعدهٔ ساعتِ تأیید خودکار از مقدار مؤثرِ همین
            // تسک محاسبه می‌شود — همان فرمول کرون (COALESCE(ads.auto_approve_hours,
            // تنظیم سراسری) در getOldSubmissionsForAutoApproval)؛ قبلاً همیشه عدد سراسریِ
            // لحظهٔ ارسال چاپ می‌شد و با تغییر تنظیم، وعدهٔ تسک‌های موجود غلط می‌شد.
            // مقدار ≤۰ = غیرفعال ⇒ وعده حذف می‌شود (هم‌راستا با گارد کرون FIX-COSMET-14).
            $globalAutoApproveHours = int_value($this->appSettings->get('custom_task_auto_approve_hours', 48));
            $taskAutoApproveHours = $task !== null && is_numeric($task->auto_approve_hours ?? null)
                ? (int)$task->auto_approve_hours
                : $globalAutoApproveHours;
            $autoApproveInfo = null;
            if ($taskAutoApproveHours > 0) {
                $autoApproveInfo = "در صورتی که کارفرما تا {$taskAutoApproveHours} ساعت آینده بررسی نکند، بصورت خودکار تایید خواهد شد.";
            }
            return [
                'success' => true,
                'message' => 'مدرک شما با موفقیت ارسال شد.',
                'auto_approve_info' => $autoApproveInfo,
            ];
        } catch (\Throwable $e) {
            $this->logger->error('task.proof_submission.failed', [
                'channel' => 'task',
                'error' => $e->getMessage(),
            ]);
            // 🛡️ FIX-BEHAV1-09 (D2-N13r): استثنای پس از آپلود ولی پیش از write —
            // فایل هنوز بی‌مرجع است؛ فقط وقتی حذف می‌شود که CAS نگذشته باشد
            // ($filePersisted). بهترین‌تلاش؛ خودِ حذف هم نباید result را عوض کند.
            if (empty($filePersisted)) {
                $this->cleanupOrphanProofFile(str_value($proofData['proof_file'] ?? ''));
            }
            return ['success' => false, 'message' => 'خطا در ارسال مدرک.'];
        }
    }

    /**
     * 🛡️ FIX-S19-VFP — گیتِ اثر انگشت ویدیو.
     *
     *  ۱) دقیق: proof_url_hash (محصول VideoFingerprintService) روی تسکِ دیگرِ
     *     غیر-rejected دیده شود → رد.
     *  ۲) فازی: variant های URL (پروتکل/www/حروف/پارامتر کوئری) با video_id+
     *     platform از corpus سراسری کشف و با انتسابِ رکوردِ مالک رد می‌شوند؛
     *     ردیفِ متعلق به همان تسک یا rejected آزاد است (عدالتِ ریسابمیت).
     *
     * @return array{error: ?string, hash: ?string}
     */
    private function resolveVideoFingerprintGate(\stdClass $submission, string $proofUrl): array
    {
        try {
            if ($this->videoFingerprint === null) {
                return ['error' => null, 'hash' => null];
            }
            $fingerprint = $this->videoFingerprint->generateFingerprint($proofUrl, $this->resolveVideoPlatform($proofUrl));
            $combinedHash = str_value($fingerprint['combined_hash'] ?? '');
            if ($combinedHash === '') {
                return ['error' => null, 'hash' => null];
            }

            $db = $this->submissionModel->getDb();

            // ۱) تطابق دقیق اثر انگشت روی تسکِ دیگر
            $exact = $db->fetch(
                "SELECT id FROM custom_task_submissions WHERE proof_url_hash = ? AND task_id <> ? AND id <> ? AND status != 'rejected' LIMIT 1",
                [$combinedHash, (int)$submission->task_id, (int)$submission->id]
            );
            if ($exact) {
                return ['error' => 'این ویدیو قبلاً برای تسک دیگری استفاده شده است.', 'hash' => null];
            }

            // ۲) کشفِ فازی variant ها از corpus (checkDuplicate سمتِ unique خودش
            // corpus را تغذیه می‌کند — تغذیهٔ سراسری در پذیرشِ نخست)
            $dup = $this->videoFingerprint->checkDuplicate($fingerprint);
            if (($dup['is_duplicate'] ?? false) === true) {
                // 🛡️ FIX-R18D: کشِ checkDuplicate گاهی خودِ fingerprintِ کاندید را
                // برمی‌گرداند (آرتیفکت کلیدِ hash) — اثر انگشتِ خود کاندید مدرکِ
                // «تسک دیگر» نیست؛ به‌علاوه، هویتِ (platform,video_id) مستقیماً از
                // corpus پرسیده می‌شود تا نتیجه مستقل از وضعیت کش باشد.
                $suspectHashes = [];
                foreach ((array)($dup['matches'] ?? []) as $match) {
                    $matchHash = is_array($match)
                        ? str_value($match['combined_hash'] ?? '')
                        : (is_object($match) ? str_value(get_object_vars($match)['combined_hash'] ?? '') : '');
                    if ($matchHash !== '' && $matchHash !== $combinedHash) {
                        $suspectHashes[] = $matchHash;
                    }
                }
                try {
                    $identityRows = $db->fetchAll(
                        "SELECT combined_hash FROM video_fingerprints WHERE platform = ? AND video_id = ? AND combined_hash <> ? LIMIT 10",
                        [str_value($fingerprint['platform'] ?? ''), str_value($fingerprint['video_id'] ?? ''), $combinedHash]
                    ) ?: [];
                    foreach ($identityRows as $row) {
                        $h = is_object($row) ? str_value($row->combined_hash ?? '') : str_value((string)($row['combined_hash'] ?? ''));
                        if ($h !== '' && $h !== $combinedHash) {
                            $suspectHashes[] = $h;
                        }
                    }
                } catch (\Throwable) {
                    // پرس‌وجوی corpus بهترین‌تلاش است؛ تطابق دقیق بالا پوشش داده شده
                }
                foreach (array_unique($suspectHashes) as $suspectHash) {
                    $owner = $db->fetch(
                        "SELECT id FROM custom_task_submissions WHERE proof_url_hash = ? AND task_id <> ? AND status != 'rejected' LIMIT 1",
                        [$suspectHash, (int)$submission->task_id]
                    );
                    if ($owner) {
                        return ['error' => 'این ویدیو قبلاً برای تسک دیگری استفاده شده است.', 'hash' => null];
                    }
                }
                // مالکِ یافت‌نشده: همان تسک یا rejected — آزاد است (عدالت ریسابمیت)
                return ['error' => null, 'hash' => $combinedHash];
            }

            return ['error' => null, 'hash' => $combinedHash];
        } catch (\Throwable $e) {
            // قرارداد migration (FIX-S19-VFP): fail-open محدود برای زیرساخت/دادهٔ قدیمی —
            // شکستِ سرویس اثر انگشت مسیر ارسال مدرک را نمی‌شکند (فقط لاگ)
            $this->logger->warning('customtask.video_fingerprint.gate_error', [
                'submission_id' => (int)$submission->id,
                'error' => $e->getMessage(),
            ]);
            return ['error' => null, 'hash' => null];
        }
    }

    /** پلتفرم ویدیو از میزبانِ URL (برای video_id extraction واقعی به‌جای fallback) */
    private function resolveVideoPlatform(string $url): string
    {
        $host = strtolower((string)(parse_url($url, PHP_URL_HOST) ?: ''));
        if ($host !== '' && str_contains($host, 'youtu')) {
            return 'youtube';
        }
        if ($host !== '' && str_contains($host, 'aparat')) {
            return 'aparat';
        }
        return $host !== '' ? $host : 'generic';
    }

    /**
     * @param array<string, mixed> $data
     */
    private function checkDuplicateProof(\stdClass $submission, string $proofType, array $data): ?string
    {
        $taskId = (int)$submission->task_id;
        $submissionId = (int)$submission->id;
        $db = $this->submissionModel->getDb();

        if (!empty($data['proof_file_hash'])) {
            $row = $db->fetch(
                "SELECT id FROM custom_task_submissions WHERE task_id = ? AND proof_file_hash = ? AND id <> ? AND status != 'rejected' LIMIT 1",
                [$taskId, str_value($data['proof_file_hash']), $submissionId]
            );
            if ($row) return 'این فایل مدرک قبلاً برای این تسک ارسال شده است.';
        }
        if ($proofType === 'code' && !empty($data['proof_code'])) {
            $row = $db->fetch(
                "SELECT id FROM custom_task_submissions WHERE task_id = ? AND proof_code = ? AND id <> ? AND status != 'rejected' LIMIT 1",
                [$taskId, trim(str_value($data['proof_code'])), $submissionId]
            );
            if ($row) return 'این کد/شناسه قبلاً برای این تسک ارسال شده است.';
        }
        if (in_array($proofType, ['url', 'video'], true) && !empty($data['proof_url'])) {
            $row = $db->fetch(
                "SELECT id FROM custom_task_submissions WHERE task_id = ? AND proof_url = ? AND id <> ? AND status != 'rejected' LIMIT 1",
                [$taskId, trim(str_value($data['proof_url'])), $submissionId]
            );
            if ($row) return 'این لینک مدرک قبلاً برای این تسک ارسال شده است.';
        }

        return null;
    }

    /**
     * 🛡️ FIX-BEHAV1-09 (D2-N13r — باقی‌ماندهٔ واقعی): کنترلرِ وب در خطاهای
     * اعتبارسنجی خودش فایل را پاک می‌کند (D2-N13 در M22-MED) ولی پس از
     * سپردن به جاب، هیچ مسیر شکستیِ جاب فایلِ آپلودشده را حذف نمی‌کرد ⇒
     * دیسک با فایل‌های بی‌مرجع پر می‌شد (duplicate/video-gate/CAS-race/
     * schema/deadline/استثنا). فقط مسیرِ الگوی امنِ UploadService حذف می‌شود
     * (task-proofs/24hex.ext — هم‌الگوی گارد S17-2)؛ مسیر تزریقی هرگز
     * حذف نمی‌شود (S17-2 فقط مرجع را رها می‌کند). حذف بهترین‌تلاش است و
     * نتیجهٔ جاب را عوض نمی‌کند.
     */
    private function cleanupOrphanProofFile(string $rawPath): void
    {
        $path = trim($rawPath);
        if ($path === '' || $this->uploadService === null) {
            return;
        }
        if (preg_match('#^task-proofs/[0-9a-f]{24}\.[A-Za-z0-9]{1,8}$#', $path) !== 1) {
            return;
        }
        try {
            if ($this->uploadService->delete($path)) {
                $this->logger->info('customtask.proof_file.orphan_deleted', ['path' => $path]);
            }
        } catch (\Throwable $e) {
            $this->logger->warning('customtask.proof_file.orphan_delete_failed', [
                'path' => $path,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
