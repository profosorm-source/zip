<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Services\InfluencerService;
use App\Contracts\LoggerInterface;

class InfluencerOrderTimeoutJob
{
    public function __construct(
        private InfluencerService $influencerService,
        private LoggerInterface $logger
    ) {}

    /** @param array<string, mixed> $data */
    /** @param array<string, mixed> $data */
public function handle(array $data = []): void
    {
        try {
            $cancelled = $this->influencerService->processExpiredPendingAcceptance();
            $autoApproved = $this->influencerService->processExpiredBuyerChecks();
            $this->logger->info('influencer.timeout_job.completed', [
                'cancelled' => $cancelled,
                'auto_approved' => $autoApproved,
            ]);
        } catch (\Throwable $e) {
            // FIX-R19-A6-10: بلعیدنِ catch-all حذف شد — قرارداد FIX-R18-M14 (الگوی
            // EscrowTimeoutJob): خطا log و سپس rethrow می‌شود تا QueueWorker بتواند
            // استثنا را طبقه‌بندی و جاب را retry/DLQ کند (شکست پردازش انقضاها از
            // دید صف پنهان نمی‌ماند؛ self-heal کرن بعدی همچنان برقرار است).
            $this->logger->error('influencer.timeout_job.failed', ['error' => $e->getMessage()]);
            \App\Services\Sentry\SentryExceptionHandler::captureException($e, null, [
                'operation' => 'influencer.timeout_job',
            ]);
            throw $e;
        }
    }
}
