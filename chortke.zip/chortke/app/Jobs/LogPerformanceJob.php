<?php

declare(strict_types=1);

namespace App\Jobs;

use Core\Database;

/**
 * LogPerformanceJob — ثبت لاگ عملکرد برنامه‌ به صورت پس‌زمینه از طریق صف (Queue)
 */
class LogPerformanceJob
{
    private Database $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    /**
     * اجرای تسک ذخیره‌سازی لاگ پرفورمنس
     *
     * FIX-X291 (راند ۷۱): اسکیمای واقعی performance_logs از روز اول EAV است؛
     * شاخهٔ «detailed schema» (endpoint/execution_time/memory_usage/... به‌عنوان ستون)
     * هرگز قابل‌رسیدن نبود و کل INSERT با PDO 1054 می‌مرد. اکنون فقط شکل EAV
     * نوشته می‌شود: execution_time → value، بقیهٔ فیلدها → context (JSON).
     *
     * @param array<string, mixed> $data
     */
    public function handle(array $data): void
    {
        try {
            $this->db->query(
                "INSERT INTO performance_logs
                (request_id, metric, value, context, created_at)
                VALUES (?, ?, ?, ?, NOW())",
                [
                    $data['request_id'] ?? (app()->request->header('x-request-id') ?? 'cli'),
                    'request_duration_ms',
                    $data['execution_time'] ?? 0,
                    json_encode([
                        'endpoint' => $data['endpoint'] ?? null,
                        'method' => $data['method'] ?? null,
                        'status_code' => $data['status_code'] ?? 200,
                        'ip_address' => $data['ip_address'] ?? null,
                        'is_slow' => $data['is_slow'] ?? 0,
                        'user_id' => $data['user_id'] ?? null,
                        'memory_usage' => $data['memory_usage'] ?? null,
                    ], JSON_UNESCAPED_UNICODE),
                ]
            );
        } catch (\Throwable $e) {
            // در صورت بروز خطا در درایور پس‌زمینه، خطا در سیستم لاگر ثبت می‌شود
            if (function_exists('logger')) {
                logger()->error('jobs.log_performance.failed', [
                    'channel' => 'queue',
                    'error' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]);
            }
        }
    }
}
