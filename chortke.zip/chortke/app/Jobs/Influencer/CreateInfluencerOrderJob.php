<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\InfluencerService;

/**
 * COMPATIBILITY_WRAPPER / LEFTOVER_REFACTOR_CLEANUP
 *
 * مسیر اصلی ثبت سفارش اینفلوئنسر از فاز ۱ به بعد:
 *   InfluencerService::createOrder → InfluencerCommandService → FinancialEscrowService
 *
 * نسخه قدیمی این Job به مدل ناموجود InfluencerOrder و سرویس‌های قدیمی اشاره داشت و
 * از refactor ناقص باقی مانده بود. برای اینکه اگر job قدیمی در queue/outbox مانده باشد
 * سیستم نشکند، این کلاس فقط به مسیر canonical فعلی delegate می‌کند.
 */
class CreateInfluencerOrderJob
{
    public function __construct(private InfluencerService $influencerService) {}

    public function handle(array $payload = []): array
    {
        $customerId = (int)($payload['customer_id'] ?? $payload['user_id'] ?? 0);
        $influencerId = (int)($payload['influencer_id'] ?? $payload['profile_id'] ?? 0);
        $data = (array)($payload['data'] ?? $payload['order_data'] ?? $payload);

        unset($data['customer_id'], $data['user_id'], $data['influencer_id'], $data['profile_id'], $data['data'], $data['order_data']);

        if ($customerId <= 0 || $influencerId <= 0) {
            return ['success' => false, 'message' => 'شناسه تبلیغ‌دهنده یا اینفلوئنسر نامعتبر است.'];
        }

        return $this->influencerService->createOrder($customerId, $influencerId, $data);
    }
}
