<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\InfluencerService;
use App\Contracts\OutboxServiceInterface;

/**
 * COMPATIBILITY_WRAPPER / LEFTOVER_REFACTOR_CLEANUP
 *
 * مسیر اصلی ثبت سفارش اینفلوئنسر از فاز ۱ به بعد:
 *   InfluencerService::createOrder → InfluencerCommandService → FinancialEscrowService
 *
 * نسخه قدیمی این Job به مدل ناموجود InfluencerOrder و سرویس‌های قدیمی اشاره داشت و
 * از refactor ناقص باقی مانده بود. برای اینکه اگر job قدیمی در queue/outbox مانده باشد
 * سیستم نشکند، این کلاس فقط به مسیر canonical فعلی delegate می‌کند.
 */
class CreateInfluencerOrderJob
{
    public function __construct(
        private InfluencerService $influencerService,
        private ?OutboxServiceInterface $outbox = null
    ) {}

    public function handle(array $payload = []): array
    {
        $customerId = (int)($payload['customer_id'] ?? $payload['user_id'] ?? 0);
        $influencerId = (int)($payload['influencer_id'] ?? $payload['profile_id'] ?? 0);
        $data = (array)($payload['data'] ?? $payload['order_data'] ?? $payload);

        unset($data['customer_id'], $data['user_id'], $data['influencer_id'], $data['profile_id'], $data['data'], $data['order_data']);

        // Fraud guard check
        if (function_exists('assert_fraud_allowed') && $customerId > 0) {
            assert_fraud_allowed($customerId, 'influencer_order_create', ['influencer_id' => $influencerId]);
        }

        if ($customerId <= 0 || $influencerId <= 0) {
            return ['success' => false, 'message' => 'شناسه تبلیغ‌دهنده یا اینفلوئنسر نامعتبر است.'];
        }

        $result = $this->influencerService->createOrder($customerId, $influencerId, $data);

        if ($result['success'] ?? false) {
            $this->outbox?->record('influencer_order', $customerId, 'influencer.order.created', [
                'customer_id'   => $customerId,
                'influencer_id' => $influencerId,
            ]);
        }

        return $result;
    }
}
