<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\InfluencerService;

/** COMPATIBILITY_WRAPPER: buyer confirmation delegates to canonical escrow flow. */
class ConfirmInfluencerOrderJob
{
    public function __construct(private InfluencerService $influencerService) {}

    public function handle(array $payload = []): array
    {
        $orderId = (int)($payload['order_id'] ?? $payload['id'] ?? 0);
        $customerId = (int)($payload['customer_id'] ?? $payload['user_id'] ?? 0);

        if ($orderId <= 0 || $customerId <= 0) {
            return ['success' => false, 'message' => 'شناسه سفارش یا تبلیغ‌دهنده نامعتبر است.'];
        }

        return $this->influencerService->buyerConfirm($orderId, $customerId);
    }
}
