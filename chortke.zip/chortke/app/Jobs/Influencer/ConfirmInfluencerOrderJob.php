<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\Influencer\InfluencerCommandService;

class ConfirmInfluencerOrderJob
{
    public function handle(
        int $orderId,
        int $customerId,
        InfluencerCommandService $service
    ): array {
        return $service->buyerConfirm($orderId, $customerId);
    }
}
