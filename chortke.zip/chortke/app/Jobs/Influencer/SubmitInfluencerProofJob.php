<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\InfluencerService;

/** COMPATIBILITY_WRAPPER: proof submission delegates to canonical influencer command flow. */
class SubmitInfluencerProofJob
{
    public function __construct(private InfluencerService $influencerService) {}

/**
 * @param array<string, mixed> $payload
 * @return array<string, mixed>
 */
public function handle(array $payload = []): array
    {
        $orderId = (int)($payload['order_id'] ?? $payload['id'] ?? 0);
        $influencerUserId = (int)($payload['influencer_user_id'] ?? $payload['user_id'] ?? 0);
        $proofData = (array)($payload['proof_data'] ?? $payload['data'] ?? $payload);
        unset($proofData['order_id'], $proofData['id'], $proofData['influencer_user_id'], $proofData['user_id'], $proofData['proof_data'], $proofData['data']);

        if ($orderId <= 0 || $influencerUserId <= 0) {
            return ['success' => false, 'message' => 'شناسه سفارش یا اینفلوئنسر نامعتبر است.'];
        }

        return $this->influencerService->submitProof($orderId, $influencerUserId, $proofData);
    }
}
