<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\Influencer\InfluencerCommandService;

class SubmitInfluencerProofJob
{
    public function handle(
        int $orderId,
        int $influencerUserId,
        array $proofData,
        InfluencerCommandService $service
    ): array {
        return $service->submitProof($orderId, $influencerUserId, $proofData);
    }
}
