<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\InfluencerService;
use App\Contracts\OutboxServiceInterface;

/**
 * COMPATIBILITY_WRAPPER / LEGACY_FINANCE_BYPASS_REMOVED
 *
 * نسخه قدیمی این Job مسیر مالی موازی داشت و می‌توانست با منطق escrow جدید ناسازگار شود.
 * اکنون فقط به InfluencerService::completeOrder delegate می‌کند تا پرداخت از
 * FinancialEscrowService::releaseInfluencerOrderFunds انجام شود.
 */
class CompleteInfluencerOrderJob
{
    public const SYSTEM_ACTOR_ID = 0;

    public function __construct(
        private InfluencerService $influencerService,
        private ?OutboxServiceInterface $outbox = null
    ) {}

    /** @param array<string, mixed> $payload */
    /** @return array<string, mixed> */
/** @param array<string, mixed> $payload */
public function handle(array $payload = []): array
    {
        $orderId = (int)($payload['order_id'] ?? $payload['id'] ?? 0);
        $actorId = (int)($payload['actor_id'] ?? $payload['customer_id'] ?? self::SYSTEM_ACTOR_ID);
        $reason = (string)($payload['reason'] ?? 'completed');

        if ($orderId <= 0) {
            return ['success' => false, 'message' => 'شناسه سفارش نامعتبر است.'];
        }

        $result = $this->influencerService->completeOrder($orderId, $actorId, $reason);

        if ($result['success'] ?? false) {
            $this->outbox?->record('influencer_order', $orderId, 'influencer.order.completed', [
                'order_id' => $orderId,
                'actor_id' => $actorId,
                'reason'   => $reason,
            ]);
        }

        return $result;
    }
}
