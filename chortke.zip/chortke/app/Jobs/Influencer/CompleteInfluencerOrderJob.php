<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Models\StoryOrder;
use App\Contracts\WalletServiceInterface;
use App\Services\Settings\AppSettings;
use App\Contracts\LoggerInterface;
use Core\TransactionWrapper;
use App\Contracts\OutboxServiceInterface;

class CompleteInfluencerOrderJob
{
    private StoryOrder $orderModel;
    private WalletServiceInterface $walletService;
    private AppSettings $appSettings;
    private LoggerInterface $logger;
    private TransactionWrapper $transactionWrapper;
    private OutboxServiceInterface $outboxService;

    public const SYSTEM_ACTOR_ID = 0;

    public function __construct(
        StoryOrder $orderModel,
        WalletServiceInterface $walletService,
        AppSettings $appSettings,
        LoggerInterface $logger,
        TransactionWrapper $transactionWrapper,
        OutboxServiceInterface $outboxService
    ) {        $this->orderModel = $orderModel;
        $this->walletService = $walletService;
        $this->appSettings = $appSettings;
        $this->logger = $logger;
        $this->transactionWrapper = $transactionWrapper;
        $this->outboxService = $outboxService;
}

    public function handle(int $orderId, int $actorId, string $reason = 'completed'): array
{
    $order = $this->orderModel->find($orderId);
    if (!$order) {
        return ['success' => false, 'message' => 'سفارش یافت نشد.'];
    }

    // ✅ FIX: تشخیص اینکه عملیات توسط سیستم انجام شده یا ادمین
    $isSystemAction = ($actorId === self::SYSTEM_ACTOR_ID || $actorId === 0);
    $actorType = $isSystemAction ? 'system' : 'admin';

    try {
        $this->transactionWrapper->runWithRetry(function() use ($order, $orderId, $isSystemAction, $actorId, $reason) {
            $payload = [
                'user_id' => (int)$order->influencer_user_id,
                'amount' => (string)$order->influencer_earning,
                'currency' => $order->currency,
                'metadata' => [
                    'type' => 'earning',
                    'description' => "درآمد سفارش #{$orderId}",
                    'idempotency_key' => "story_payout_{$orderId}",
                    'order_id' => $orderId,
                ],
            ];

            if ($this->outboxService) {
                $ok = $this->outboxService->record('influencer_order', $orderId, \App\Events\Registry\EventRegistry::INFLUENCER_ORDER_COMPLETED, $payload);
                if (!$ok) {
                    throw new \Exception('خطا در ثبت رکورد خروجی پرداخت');
                }
                $this->orderModel->update($orderId, [
                    'status'                => 'completed',
                    'buyer_confirmed_at'    => date('Y-m-d H:i:s'),
                    'payout_transaction_id' => null,
                ]);
            } else {
                $payoutResult = $this->walletService->deposit(
                    (int)$order->influencer_user_id,
                    (string)$order->influencer_earning,
                    $order->currency,
                    ['type' => 'earning', 'description' => "درآمد سفارش #{$orderId}", 'idempotency_key' => "story_payout_{$orderId}"]
                );
                if (!($payoutResult['success'] ?? false)) {
                    throw new \Exception('خطا در پرداخت به اینفلوئنسر.');
                }
                $this->orderModel->update($orderId, [
                    'status'                => 'completed',
                    'buyer_confirmed_at'    => date('Y-m-d H:i:s'),
                    'payout_transaction_id' => $payoutResult['transaction_id'] ?? null,
                ]);
            }
        });

        $this->outboxService->record('influencer_order', $orderId, 'influencer.order_completed', [
            'order_id'           => $orderId,
            'influencer_user_id' => (int)$order->influencer_user_id,
            'influencer_id'      => (int)$order->influencer_id,
            'amount'             => $order->influencer_earning,
            'actor_id'           => $actorId,
            'actor_type'         => $actorType,
            'points'             => (int)$this->appSettings->get('influencer_rep_complete_points', 10)
        ]);

        return ['success' => true, 'message' => 'سفارش تکمیل و درآمد واریز شد.'];
    } catch (\Exception $e) {
        $this->logger->error('story.complete_order_failed', ['order_id' => $orderId, 'error' => $e->getMessage()]);
        return ['success' => false, 'message' => $e->getMessage() === 'خطا در پرداخت به اینفلوئنسر.' ? $e->getMessage() : 'خطای سیستمی در تسویه.'];
    }
}
}

