<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\Influencer\InfluencerCommandService;

class DisputeInfluencerOrderJob
{
    public function handle(
        int $orderId,
        int $customerId,
        string $reason,
        InfluencerCommandService $service
    ): array {
        return $service->buyerDispute($orderId, $customerId, $reason);
    }
}
