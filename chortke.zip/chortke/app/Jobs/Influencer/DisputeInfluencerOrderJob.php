<?php

declare(strict_types=1);

namespace App\Jobs\Influencer;

use App\Services\InfluencerService;

/** COMPATIBILITY_WRAPPER: buyer dispute delegates to canonical influencer dispute flow. */
class DisputeInfluencerOrderJob
{
    public function __construct(private InfluencerService $influencerService) {}

    public function handle(array $payload = []): array
    {
        $orderId = (int)($payload['order_id'] ?? $payload['id'] ?? 0);
        $customerId = (int)($payload['customer_id'] ?? $payload['user_id'] ?? 0);
        $reason = trim((string)($payload['reason'] ?? ''));

        if ($orderId <= 0 || $customerId <= 0 || $reason === '') {
            return ['success' => false, 'message' => 'شناسه سفارش، تبلیغ‌دهنده یا دلیل اعتراض نامعتبر است.'];
        }

        return $this->influencerService->buyerDispute($orderId, $customerId, $reason);
    }
}
