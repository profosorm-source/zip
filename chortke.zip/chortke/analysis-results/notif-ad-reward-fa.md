# گزارش — بررسی چرخه + شکافِ واریز پاداش به بیننده

## پاسخ به پرسش شما

### ۱. آیا تست‌های حرفه‌ای ساختم؟ — بله
- `tests/Unit/Services/NotificationAdAnalyticsTest.php` (۱۰ تست، ۱۶ assertion): engagement، fallback مدت، دسته‌بندی زود/دیر، آمار per-ad، مالکیت، aggregation.
- `tests/Unit/Services/AdsBudgetSettlementNotificationTest.php` (۴ تست، ۹ assertion): **واریز پاداش به بیننده، مصرف بودجه، ایدمپوتنسی، لبه‌ها**.

### ۲. آیا چرخه کامل است؟ — با این مرحله کامل شد
زنجیره‌ی کامل اکنون:
1. تبلیغ‌دهنده تبلیغ `type=notification` ثبت می‌کند (escrow + بودجه).
2. `AdNotificationDispatcher` (کرون `ad_notification_push`) نوتیف را با `data[ad_id]` به کاربران هدف می‌فرستد.
3. کاربر نوتیف را می‌بیند → `POST /notifications/events/shown` → `recordShown` + **واریز پاداش**.
4. کاربر باز می‌کند → `events/opened` → `recordOpened` + پاداش؛ می‌بندد → `events/closed` → `recordClosed` (مدت خواندن).
5. کلیک → `recordClick` + `trackAdNotificationClick` → پاداش کلیک.
6. آمار per-ad تبلیغ‌دهنده: `GET /ads/{id}/notification-stats` و پنل داخل اپ.
7. aggregation ادمین: کرون `notification_analytics` → جدول `notification_analytics`.

### ۳. آیا هنگام دیدن نوتیف به کاربر پول واریز می‌شود؟ — قبل از این مرحله: **خیر**، اکنون: **بله**
- **قبل:** مسیر `notification` فقط `consumeDeliveryBudget` (کسر بودجه‌ی تبلیغ‌دهنده) را داشت و هیچ reward به بیننده نمی‌داد — برخلاف `adtube` که `settleAdTubeView` پاداش واریز می‌کرد. این یک **نقص مالی واقعی** بود.
- **رفع:** متد جدید `AdsBudgetSettlementService::settleNotificationView(...)` افزوده و در `trackAdNotificationClick` و رویدادهای `shown/opened` متصل شد. این متد هم بودجه‌ی تبلیغ‌دهنده را مصرف و هم پاداش (= هزینه‌ی delivery) را با `walletService->deposit` به بیننده واریز می‌کند؛ **ایدمپوتنت** (هر نوتیف یک‌بار).

## تأیید
- PHPStan لول-۹ بدون ignore: **۵۶۹۹** (بدون رگرسیون؛ متدهای پاداش صفر خطا).
- PHPUnit کل: **۲۳۱۰ تست، ۰ شکست** (۵ skip محیطی)، شامل ۱۴ تست حرفه‌ی جدید برای این قابلیت.
- تست واحدِ پاداش: واریز به بیننده + مصرف بودجه + ایدمپوتنسی تأیید شد.
- نکته: در تست انتگراسیونِ زنده، پیام «سیستم در حال حاضر شلوغ است» از `IdempotencyService` (قفل/Redis محیط) می‌آید — خطای محیطی، نه نقص منطق.

## فایل‌های تغییر یافته
- `app/Services/Ads/AdsBudgetSettlementService.php` (متد `settleNotificationView`)
- `app/Controllers/User/NotificationController.php` (اتصال پاداش به shown/opened/click)
- `tests/Unit/Services/AdsBudgetSettlementNotificationTest.php` (جدید)
- `RULES-AND-STANDARDS-fa.md`
