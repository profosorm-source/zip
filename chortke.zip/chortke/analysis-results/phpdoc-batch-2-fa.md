# تکمیل تایپداک — دسته دوم (گزارش فارسی)

## رویکرد
ادامهی تدریجی. این نوبت ۳ فایل پراستفاده کاملاً تمیز شد + باگهای واقعی حین کار رفع شد.

## فایلهای تمیزشده (تا ۰ خطا)
### ۱. app/Models/Notification.php (۲۴ مورد no-value-type + ~۱۲ خطای پنهان)
- نوعهای list<\stdClass> برای getLatestForUser/getUserNotifications/getPendingScheduled/...
- array<string,mixed>|null برای getOverviewStats/getFunnelStats/getFatigueSummary
- array<int, array{latest,count,unread,ids}> برای getGroupedForUser
- iterable<list<int>> برای getActiveUsersIdsInBatches

**باگهای واقعی رفعشده:**
- updateBatchAnalytics: object $row → \stdClass $row (property ها شناخته شدند)
- ۱۱ مورد `$stmt instanceof \PDOStatement` که dead-code بود (چون Database::query() همیشه PDOStatement برمیگرداند) → ساده شد
- `if (!$stmt) return false` زائد در create() → حذف شد

### ۲. app/Services/TicketService.php (۲۳ مورد no-value-type + ~۱۰ خطای پنهان)
- type های list<\stdClass>، array<string,mixed>، array{tickets,total}

**باگهای واقعی رفعشده:**
- `if (!$ok) return error` در submitBugReport زائد بود (query همیشه موفق/exception) → ساده شد
- `strval($data['x'])` روی mixed → با is_scalar درست شد
- دسترسی `$r->status`/`$r->priority` روی stdClass → با @var object{...}

## تأیید
- php -l: همه فایلها OK
- PHPStan بدون-ignore: هر ۳ فایل → ۰ خطا
- تستها: TicketService (7), NotificationTemplate (8) → OK
- بدون ignoreErrors جدید، بدون DTO، بدون فایل سورس جدید

## عدد
- ۳ فایل کاملاً تمیز شد
- کل خطاها: ۶۲۸۴ → ۶۲۲۸ (کاهش ۵۶ در این نوبت)
- no-value-type: ۲۱۱۱ → ۲۰۶۴
- از ۷۰۲۲ اولیه: حذف ۷۹۴ خطا
