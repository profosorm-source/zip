# گزارش — بازبینی کامل چرخه‌ی رفرال

## چرخه‌ی کامل (که بررسی شد)
1. **ثبت‌نام:** کاربر با کد معرف ثبت‌نام می‌کند → `UserService::register` `referred_by` را تنظیم می‌کند → `AuthService` → `ProcessRegistrationJob` → بونوس به referrer.
2. **تأیید محتوا:** `ContentEventListeners::processReferralBonus` → `checkAndAwardBonus` → بونوس به referrer.
3. **سایر کمیسیون‌ها:** `ReferralCommissionListener`/`HandlePaymentCompleted`/`InvestmentEventListeners` → `processCommission`/`processModularCommission`.
4. **میلستون:** `checkAndAwardMilestones` — باید با رسیدن به threshold اهدا شود.

## نقص‌های پیدا و رفع‌شده
### ۱) بونوس ثبت‌نام (نقص جدی)
- **قبل:** `ProcessRegistrationJob` از `processCommission` (درصدی → فقط ۵٪ از ۱۰۰۰ = ۵۰) و کلید ناهماهنگِ `referral_signup_commission_base` استفاده می‌کرد. پنل ادمین کلید `referral_signup_bonus` را ذخیره می‌کرد ولی جاب کلید دیگری می‌خواند → همیشه fallback به ۱۰۰۰ و درصدی.
- **بعد:** متد `ReferralService::awardSignupBonus()` — بونوس ثابت کامل (۱۰۰۰) با idempotency و واریز مستقیم. از کلید صحیح `referral_signup_bonus` می‌خواند. seed در migration 0005.

### ۲) میلستون فقط هنگام بازکردن صفحه اهدا می‌شد
- **قبل:** `checkAndAwardMilestones` فقط در `ReferralController::milestones()` و `ReferralManagementService::checkMilestones()` صدا می‌شد → اگر کاربر صفحه را باز نمی‌کرد، میلستون اهدا نمی‌شد.
- **بعد:** `maybeAwardMilestones()` بعد از هر `processCommission`/`checkAndAwardBonus`/`awardSignupBonus` صدا می‌شود → میلستون‌ها خودکار با هر اعطا بررسی/اهدای می‌شوند.

### ۳) میلستون از قبل اصلاح شده بود (در batch قبل)
- `checkAndAwardMilestones` و `getUserAchievedMilestones` بازنویسی شده بودند (منطق واقعی + idempotency + جدول `referral_user_milestones`).

## تأیید
- **PHPStan لول-۹ بدون ignore:** ۵۶۹۸ (بدون رگرسیون)
- **PHPUnit:** ۲۳۲۶ تست، ۰ شکست (۵ skip محیطی) — شامل ۷ تست `ReferralBonusMilestoneTest`
- **تست زنده:** ۵ معرف → ۵ بونوس ۱۰۰۰ کامل → میلستون‌های threshold ۱ و ۵ خودکار اهدا شدند و دوباره اهدا نشدند (idempotent).
- بونوس محتوا (checkAndAwardBonus) → ۵۰۰۰ کامل.

## فایل‌های تغییر یافته
- `app/Services/Shared/ReferralService.php` (awardSignupBonus + maybeAwardMilestones)
- `app/Jobs/Auth/ProcessRegistrationJob.php` (استفاده از awardSignupBonus)
- `database/migrations/2026_08_03_0005_referral_signup_settings.sql` (seed تنظیمات signup)
- `tests/Unit/Services/ReferralBonusMilestoneTest.php` (+۳ تست)
