# گزارش پیشرفت — دسته‌ی «undefined property» (دور ۶)

> تاریخ: ۲۰۲۶-۰۸-۰۳ | وضعیت: **کاملاً رفع شد (از ۱۸۰ به ۰)**

## خلاصه
در این دور، کل خطاهای **`Access to an undefined property object::$xxx`** (PHPStan Level 9 بدون ignore) به صفر رسید.

| معیار | قبل از این دور | بعد از این دور |
|---|---|---|
| تعداد «undefined property» | ۱۸۰ | **۰** |
| تعداد کل خطاهای PHPStan (بدون-ignore) | ۴۸۴۳ | **۴۶۵۹** |
| تست‌های PHPUnit | ۲۳۳۸ / ۴۸۲۳ | **۲۳۶۳ / ۴۸۷۲** |
| شکست / skip محیطی | ۰ / ۵ | **۰ / ۵** |

---

## الگوهای به‌کاررفته (ریشه‌ای، بدون ignore و بدون DTO)
1. **مدل‌ها / متدهایی که `db->fetch()` / `FETCH_OBJ` / `normalizeToObject` برمی‌گردانند** → تایپ بازگشتی `?object` به `?\stdClass` (و `list<object>` → `list<\stdClass>` برای `fetchAll`).
   - نمونه‌ها: `UserLevelHistory`، `IpAndDeviceModel`، `AdTubeExecutionModel`، `TicketMessage`، `PaymentGateway`، `ReferralCommission`، `PredictionBet`، `PredictionGame`، `CryptoDepositIntent`، `InteractionModel`، `SentryModel`، `UserVerification`، `Setting`، `Notification::getTemplateFromDb`، `Wallet::findByUserId`...
2. **`toObject(mixed): ?object` در سرویس‌ها** → به `?\stdClass` با بدنه‌ی استاندارد (`instanceof \stdClass` اول، بعد cast به `(object)(array)`).
   - نمونه‌ها: `ApiTokenService`، `SeoPayoutService`، `TicketCommandService`، `Lottery*Service`، `PaymentDepositService`، `MessageModerationService`، `WithdrawalQueryService`، `WalletQueryService`، `ManualDepositService`، `CouponService`، `AppSettings`، `UserDashboardService`، `AuthSessionManager`، `EscalationManager`، `SocialAccountService`...
3. **پارامتر `object $x`** → به نوع واقعی (معمولاً `\stdClass`، یا `\App\Models\User` در TrustService).
   - `FeatureFlagPolicy` (پارامترهای `object $featureFlag` → `FeatureFlag`)، `CancelGameJob`، `SubmitProofJob`، `AlertDispatcher`، `AuthSessionManager`...
4. **متد `create()` مشتق که آبجکت برمی‌گرداند (ناسازگار با قرارداد `int|false` والد)** → تغییر نام به نام دامنه‌ای + به‌روزرسانی callerها.
   - `UserLevelHistory::create` → `createHistory` (callers در `UserLevelCommandService`)
   - `PredictionBet::create` → `createBet` (caller در `PlaceBetJob`)
   - `PredictionGame::create` → `createGame` (caller در `PredictionController`)
5. **زنجیره‌ی رابط/پراپرتی** — `WalletServiceInterface::getWalletSummary()/findTransactionById()` و `$config` در درگاه‌ها → `\stdClass`/`?\stdClass`.

## باگ‌های واقعی کشف‌شده و رفع‌شده
- **`MessageModerationService::dismissReport`**: `toObject($db->query(...)->fetchColumn())` رشته‌ی وضعیت را به `stdClass` تبدیل می‌کرد و مقایسه‌ی `$status !== 'pending'` همیشه درست بود → `dismissReport` همیشه `false` و `rollback` می‌شد. اصلاح: مقایسه‌ی مستقیم خروجی `fetchColumn()`.
- **`ApiTokenService`** و چند سرویس دیگر: حذف کد مرده/تنظیم دقیق تایپ.

## تست‌ها (طبق بند ۴ بخش ۲ قوانین)
- **جدید:** `tests/Unit/Commands/DLQRetryCommandTest` (۶ تست) — requeue در تراکنش، rollback، skip فایل مهلک، purge.
- **جدید:** `tests/Unit/Services/SeoPayoutServiceTest` (۱۰ تست) — محاسبه پاداش پویا، بودجه ناکافی، امتیاز زیر حداقل، refund/بازفعال‌سازی، تخمین.
- **ارتقا:** `tests/Unit/Services/UserLevelHistoryTest` (۵ تست) — اعتبارسنجی فیلد الزامی، null در شکست insert، تأیید امضای ردیف، امضای خالی.
- **ارتقا:** `tests/Unit/Services/MessageModerationServiceTest` (۷ تست) — guardهای approve (ناموجود/غیر-pending/action نامعتبر)، مسیر موفق delete، dismiss (شامل لبه‌ی باگ).

## پیش‌نیاز اجرا
- کل `phpunit` سبز است (فقط ۵ skip محیطی: ۳ تست RedisGraceful + ۲ تست HealthEndpoints نیازمند وب‌سرور روی ۸۰۹۰).

## گام بعدی
- دسته‌ی بعدی: **no-value-type** (~۱۷۰۰ مورد) و سپس نویزها (unused/never/always/Unreachable، `Redis|null`).
