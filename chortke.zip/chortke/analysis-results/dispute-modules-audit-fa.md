# گزارش — تکمیل listForAdmin + ممیزی جامع ماژول‌های dispute

## ۱) listForAdmin یکپارچه شد
- `DisputeService::listForAdmin()` حالا همه‌ی ref_typeها را نشان می‌دهد (نه فقط custom_task_submission).
- `DisputeQueryService` دو متد یکپارچه گرفت: `unifiedAdminDisputeList`/`unifiedAdminDisputeCount` با LEFT JOIN به `story_orders`, `vitrine_listings`, `custom_task_submissions` و ستون‌های عام `ref_type`/`task_title`/`raised_by_role`.
- فیلتر `ref_type` (اختیاری) + `status` پشتیبانی می‌شود.
- پنل ادمین (`views/admin/custom-tasks/disputes.php`): ستون «ماژول» + دراپ‌داون فیلتر ماژول + pagination با ref_type.
- `ExecutorTaskController::disputes()` فیلتر ref_type را از request می‌گیرد.
- تأیید زنده: همه‌ی ماژول‌ها در یک لیست + فیلتر vitrine_listing به‌درستی کار کرد.
- تست: +۳ تست به `DisputeServiceTest` (همه ماژول‌ها، فیلتر ref_type، فیلتر status-resolved).

## ۲) ممیزی جامع ماژول‌های dispute

| ماژول | ref_type | جدول | باز کردن | پیام | escalate | داوری ادمین | بازگشت وجه | وضعیت |
|---|---|---|---|---|---|---|---|---|
| **اینفلوئنسر/سفارش** | `order/story_order/influencer_order/influencer` | `disputes` | ✅ | ✅ | ✅ | ✅ (escrow) | ✅ | **کامل** |
| **تسک سفارشی** | `custom_task_submission` | `disputes` | ✅ | ✅ | ✅ | ✅ (executor/advertiser/split) | ✅ | **کامل** |
| **ویترین** | `vitrine_listing` | `disputes` (یکپارچه) | ✅ | ⚠️ خیر | ⚠️ خیر | ✅ (ResolveVitrineDisputeJob + resolveByRef) | ✅ | **کامل (بازگشت وجه دارد)** |
| **وظیفه اجتماعی** | — | حذف (`task_disputes`) | — | — | — | — | — | **حذف (مکانیزم خودکار)** |

## ۳) جدول‌های dispute
- `disputes` + `dispute_messages` — یکپارچه (مؤثر)
- `task_disputes` — **حذف شد** (migration 0002)
- `vitrine_disputes` — **حذف شد** (migration 0003)؛ `getUserDisputesCount` به `disputes` وصل شد

## ۴) نکات/کمبودهای باقی‌مانده (گزارش‌دهی — منتظر دستور شما)
1. **ویترین مکالمه/پیام dispute ندارد** (برخلاف اینفلوئنسر و تسک سفارشی که `dispute_messages` دارند). اگر لازم است، باید `addMessageWithContext`/پیام در مسیر ویترین اضافه شود.
2. **`Dispute::hasOpenTaskDispute` (ref_type='task') dead code است** — هیچ caller ندارد؛ می‌توان حذفش کرد.
3. **`adminResolve` داوریِ generic** برای ref_typeهای غیر-اینفلوئنسر فقط وضعیت را عوض می‌کند و settlement مخصوص دامنه را ندارد (ویترین از مسیرِ جداگانه‌ی خودش `ResolveVitrineDisputeJob` داوری می‌شود). این طراحیِ فعلی عمدی و سالم است.
4. **داوریِ یکپارچه‌ی ادمین** برای ویترین از دکمه‌ی «داوری» در پنل `admin/custom-tasks/disputes` استفاده نمی‌کند (چون resolve ویترین از طریق جابِ ویترین است). اگر می‌خواهید همه‌ی ماژول‌ها در یک پنل با یک دکمه داوری شوند، باید resolve مخصوص ویترین هم به همان پنل وصل شود.

## ۵) تأیید نهایی
- PHPStan لول-۹ بدون ignore: **۵۶۹۵** (بدون رگرسیون)
- PHPUnit: **۲۳۱۶ تست، ۰ شکست** (۵ skip محیطی)
- جدول‌های `task_disputes` و `vitrine_disputes` حذف شدند؛ هیچ ارجاع شکسته‌ای نماند.
