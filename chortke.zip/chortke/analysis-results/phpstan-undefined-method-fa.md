# گزارش — رفع کامل «undefined method object::xxx» (دسته‌ی الف)

## نتیجه
**همه‌ی ۱۳۲ خطای `undefined method object::xxx()` در کل پروژه به صفر رسید** (و هیچ مورد جدیدی جایگزین نشد).

## ریشه‌یابی و اصلاحات ریشه‌ای
مشکل اصلی این بود که `Container::make()` نوع `object` برمی‌گرداند، بنابراین هر سرویس/مدلی که از `container->make()` یا `app()` می‌آمد، به‌عنوان `object` شناخته می‌شد و PHPStan هیچ متدی روی آن نمی‌شناخت.

### ۱. `core/Container::make()` → generic
```php
/** @template T of object
 *  @param class-string<T> $abstract
 *  @return T */
public function make(string $abstract): object
```
با یک متغیر `$result` و `@var T` در return بازنویسی شد تا body با `@return T` سازگار شود.

### ۲. `BaseUserController` properties → تایپ واقعی
`$authService`→`AuthService`، `$userService`→`UserService`، `$captchaService`→`CaptchaService` (قبلاً `object` بودند) + `resolveFromContainer` generic شد.

### ۳. `UserService::find/findById/findByEmail/findByMobile/findByCredentials` → `?\App\Models\User`
(قبلاً `?object` بودند؛ همه `User` مدل برمی‌گرداندند.)

### ۴. `User` مدل docblock `@property` تکمیل شد
`id, email, mobile, avatar, username, two_factor_secret, two_factor_enabled, two_factor_method` اضافه شد تا dynamic properties شناخته شوند.

### ۵. `GeoIPService::$reader` → `?\GeoIp2\Database\Reader`
(قبلاً `?object` بود.)

### ۶. `SagaRecoveryWorker` + interface جدید `App\Contracts\SagaCompensatableStep`
برای `make($className)` (متغیر) یک interface با متد `compensate(array, mixed, ?Throwable)` تعریف شد.

### ۷. باگ‌های آشکارشده (پنهان قبلاً) رفع شدند
با تایپ دقیق‌تر، چند باگ واقعی آشکار و رفع شد:
- `AuditTrail` داشت `private log()` ولی ۶ Listener آن را با `log([...])` صدا می‌زدند → متد public `logEvent(array)` اضافه و Listener ها به آن وصل شدند (private log با قرارداد تست حفظ ماند).
- `Api/UserController` `UserSettingsService::set()` را با ۴ پارامتر صدا می‌زد (فقط ۳ می‌پذیرد) → اصلاح شد.
- چند cast/تایپ دیگر.

## اعداد
| شاخص | قبل | بعد |
|---|---|---|
| undefined method | ۱۳۲ | **۰** |
| PHPStan کل | ۵۶۹۸ | **۵۵۶۱** |
| PHPUnit | ۲۳۲۶ (۰ شکست) | **۲۳۲۶ (۰ شکست)** |

## فایل‌های تغییر یافته
- `core/Container.php`, `app/Controllers/User/BaseUserController.php`, `app/Services/User/UserService.php`, `app/Models/User.php`, `app/Services/AntiFraud/GeoIPService.php`, `app/Services/SagaRecoveryWorker.php`, `app/Contracts/SagaCompensatableStep.php` (جدید), `app/Services/AuditTrail.php`, ۶ Listener, `app/Controllers/Api/UserController.php`.
