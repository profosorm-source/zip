# گزارش وضعیتِ اصلاحات PHPStan — ۲۰۲۶-۰۸-۰۵

**خلاصه:** دستهی `no-value-type` به‌طور کامل به **صفر** رسید (از ۱۷۲۹ شروع). کل خطاهای پروژه از ۴۴۱۹ به **۴۳۳۲** کاهش یافت. تست‌ها سبز است.

---

## ۱) معیار سلامت (قابل تأیید)

| معیار | وضعیت |
|---|---|
| PHPUnit کامل | ✅ **۲۳۷۷ تست / ۴۸۹۷ assertion / ۰ شکست / ۵ skip محیطی** |
| `php -l` روی همه‌ی فایل‌های ویرایش‌شده | ✅ بدون خطا |
| docblock خراب (inline یا تک‌خطیِ `@param … @return`) | ✅ ۰ مورد (grep سراسری) |
| docblock انباشته‌شده (stacked) | ✅ تلفیق شد |
| خطای `no-value-type` در اسکن کامل | ✅ **۰** |

> ۵ تست skip همگی محیطی/ارادی‌اند: ۳ مورد RedisGraceful (چون Redis در دسترس است، مسیر unavailable قابل تست نیست) و ۲ مورد HealthEndpoints (نیازمند وب‌سرور روی پورت ۸۰۹۰).

---

## ۲) شمارش نهایی (PHPStan Level 9 بدون ignore، اسکن تازه)

**مجموع: ۴۳۳۲ خطا** (شروع پروژه: ۴۴۱۹)

### دسته‌بندی اصلی
| خطا | تعداد |
|---|---|
| **Cannot cast mixed** (مجموع) | **۱۴۱۸** |
| └ به int | ۷۲۱ |
| └ به string | ۵۳۵ |
| └ به float | ۱۶۲ |
| نوع‌متناسب/expects (type-mismatch) | ۱۰۳۰ |
| Cannot access (property/offset روی mixed) | ۵۰۳ |
| Property never-read | ۱۷۴ |
| بدون return type | ۱۷۱ |
| همیشه true | ۱۳۹ |
| Unreachable statement | ۱۰۵ |
| encapsed-string (دارای mixed) | ۸۴ |
| unused | ۷۷ |
| همیشه false | ۲۷ |
| misc | ۲۳۶ |

---

## ۳) کارِ انجام‌شده در این جلسه (رساندن no-value-type از ۱۹۷ به ۰)

### الف) ریشه‌یابی یک باگِ گسترده: docblockهای انباشته (Stacked)
- کشف شد که اسکریپتِ قدیمیِ درج docblock، خط docblock را **بالای** docblock قبلی اضافه می‌کرد و در ~۳۵ فایل Job به‌همراه `core/Model.php` و `core/Validator.php` چند docblock روی هم انباشته بود.
- چون PHPStan **فقط docblockِ بلافاصله قبل از متد** را می‌خواند، `@return`های قبلی نادیده گرفته می‌شد و خطای no-value-type با وجود docblockِ به‌ظاهر کامل، باقی می‌ماند.
- رفع ریشه‌ای: **تلفیق دستی** همه به یک docblock چندخطیِ واحد (شامل تمام `@param`ها + `@return`).

### ب) دسته‌هایی که تمیز شد
- **Events/Exceptions:** `AlertRequestedEvent`، `AuditRecordedEvent`، `CriticalFeatureChangedEvent`، `SettingsUpdated`، `EventRegistry`، `BusinessException`، `PaymentVerificationException`.
- **Jobs (~۳۸ فایل):** همه‌ی `handle()`ها + متدهای کمکی (تلفیق docblock + تکمیل `@return`/`@param`).
- **core:** `Application`، `Blueprint`، `CircuitBreaker`، `MaintenanceMode`، `Model`، `PathResolver`، `Pipeline`، `Redis`، `Response`، `Session`، `Validator`.
- **Middleware/Policies/Listeners:** `ApiAuthMiddleware`، `ApiRequestMiddleware`، `RateLimitMiddleware`، `TaskFraudGuardMiddleware`، `RateLimitPolicy`، و ۶ Listener (Influencer/Investment/PersistAudit/Referral/Vitrine/WalletDeposit).
- **سرویس‌ها:** AntiFraud (RiskPolicy, RiskDecision, FraudManagement, IPQuality, SessionAnomaly, TaskExecutionEvaluator, TorListUpdater, FraudStrategyResolver, دو Strategy)؛ AdminDashboard؛ User؛ Shared؛ Sentry/Alerting؛ Search؛ ScheduledPayment؛ Outbox؛ Notification؛ Gamification؛ Content؛ Contact؛ Auth؛ SocialTask؛ Score؛ Cache؛ AdNotificationDispatcher؛ FallbackLogger.
- **Trait:** `ExternalCallTrait::classifyHttpFailure` (۱۱ خطا از یک متد).

---

## ۴) گام بعدی پیشنهادی
بزرگ‌ترین دسته‌ی باقی‌مانده: **Cannot cast mixed (۱۴۱۸)** و **type-mismatch (۱۰۳۰)**.
- این‌ها عمدتاً cast کور روی مقادیر `mixed` حاصل از `array<string,mixed>` و `fetchAll` هستند.
- طبق قوانین پروژه، رفع باید **ریشه‌ای** باشد (با `is_scalar()`/narrow کردن روی منبع، یا `@var` دقیق، یا اصلاح قرارداد بازگشتی) — نه cast خام که PHPStan لول-۹ رد می‌کند.
- همراه هر اصلاح: `php -l` → PHPStan همان فایل → PHPUnit کامل، و ارتقای تست‌های مرتبط (بند ۴ بخش ۲ قوانین).

---
*این گزارش در `analysis-results/` ذخیره شده و با اسکن کاملِ بدون-cache و PHPUnit سبز تأیید شده است.*
