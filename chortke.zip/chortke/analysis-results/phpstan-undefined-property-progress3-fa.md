# گزارش پیشرفت ۳ — رفع undefined property

## اعداد
| شاخص | شروع | الان |
|---|---|---|
| undefined property | ۸۵۹ | **۲۵۸** |
| PHPStan کل | ۵۶۹۸ | **۴۹۳۱** |
| PHPUnit | ۲۳۲۶ (۰ شکست) | **۲۳۳۵ (۰ شکست)** |

## فایلهای پاکشده در این بخش
OutboxPublisher, SessionService/SecurityModel, ApproveSocialTaskExecutionJob, SocialTaskModel/ExecutionModel/AnalyticsModel, FeatureFlagService (object $feature→FeatureFlag), SettleGameJob/PredictionBet, CronSubmissionsJob/CustomTaskSubmissionModel, UpdateLotteryChanceScoresJob + LotteryVote/Round/Participation/DailyNumber, core/Request (تغییر مرکزی getUser/setUser → stdClass).

## نکات
- پارامترهای `object $feature`/`object $bet`/`object $event`/`object $participation` به نوع واقعی (stdClass یا مدل) تغییر یافتند.
- متدهای `fetchAll(FETCH_OBJ)` بدون docblock → `@return list<\stdClass>` اضافه شد.
- `$stmt->fetch(FETCH_OBJ)` که PHPStan `mixed` میداند → `@var \stdClass|false $row` روی نتیجه.
- `db->query()` همیشه PDOStatement → dead code های `if(!$stmt)`/ternary حذف/ساده شدند.

## نویزهای باقیمانده (در فایلهای تمیز شده)
- `Ternary always true`/`$total on mixed` در LotteryParticipation، `cancelBetHold never returns null` در SettleGameJob — اینها نویز pre-existing هستند (نه باگ)، و هنگام رفعِ دستهی نویز جداگانه مدیریت میشوند.

## وضعیت
~۲۵۸ undefined property باقی است (SocialTaskApiController, ProfileController, AccountDeletionService, AdsSeoService, CustomTaskExecutorService, SagaRecoveryWorker, Admin/UserController, SessionService باقیمانده و...). با همین الگو ادامه مییابد.
