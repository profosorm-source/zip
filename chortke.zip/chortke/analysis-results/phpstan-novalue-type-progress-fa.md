# گزارش پیشرفت — دستهی «no-value-type» (PHPStan Level 9 بدون ignore)

> وضعیت: **در جریان** | کل اولیه: **۱۷۲۹** خطا در ~۱۵۰ فایل

## واقعیتِ اسکوپ (صداقت فنی)
این دسته بسیار بزرگتر و پرهزینهتر از دستهی «undefined property» است:
- تایپ `array<string, mixed>` برای دادهی ناهمگن (پارامتر/پیکربندی/بدنهی درخواست) درست و صادقانه است، اما **در مصرفکنندهها، دسترسی به فیلدها را `mixed` آشکار میکند** و خطاهای «Cannot cast mixed to int/string» بهوجود میآورد.
- همچنین **بخش بزرگی از خطاهای «Cannot cast mixed» از قبل در baseline موجودند** (دستهی جداگانه) و شمارهخطشان با افزودن docblock جابهجا میشود.
- **نتیجه:** هر فایل علاوه بر تایپدهی، نیازمند narrow کردن `mixed` در محل مصرف (با `@var`/`is_string`) است. این کارِ فایلبهفایل و دقیق است.

## فایلهای تکمیلشده
| فایل | خطا | توضیح |
|---|---|---|
| `core/Sql/SafeExpression.php` | ۱۸→۰ | AST ناهمگن؛ افزودن `@var` به پراپرتیها، `@return array<string,mixed>` به متدهای parse، و هلپرهای `nodeStr`/`nodeAst`/`nodeList` برای narrow کردن فیلدهای AST در emitNode. (الگوی بازگشتی `@phpstan-type` در PHPStan 1.12 رد شد → circular) |
| `core/Request.php` | ۱۳→۰ | `array<string,mixed>` برای parsedBody/attributes/all/json/files؛ `array<string,string>` برای headers؛ `array<int,string>` برای only(). تغییر `array_merge`→`array_replace` برای حفظ کلیدهای رشته در merge بدنه. |
| `core/Router.php` | ۱۸→۰ | `$routes` → `array<string, list<array{uri:string, route:Route}>>`؛ `$groupAttributes` → `array{prefix?:string, middleware?: array<int,string>}`؛ `$middlewarePriority` → `list<class-string>`؛ `matchRoute` → `@return array<string,string>\|false` (اعلان قبلی `array|false` نادرست بود). |
| `core/Queue.php` | ۱۱→۰ | payload/request → `array<string,mixed>`؛ args → `array<int,mixed>`؛ pop/popDlq → `array<string,mixed>\|null`؛ retryBatch ها → `list<array<string,mixed>>`. |
| `core/IdempotencyKey.php` | ۱۴→۰ | requestData/context/metadata/error/payload → `array<string,mixed>`؛ `fail($error)` → `string\|array<string,mixed>`. |

### مدلهای `app/Models/` (دور بعدی)
| فایل | خطا | توضیح |
|---|---|---|
| `Transaction.php` | ۱۴→۰ | `$filterable` → `array<string, array{string,string}>`؛ fetchAll ها → `list<array<string,mixed>>`؛ `$data/filters/eventMetadata` → `array<string,mixed>`. |
| `VitrineListing.php` | ۲۲→۰ | `$filterable` → shape؛ categories/platforms/statuses → `array<string,string>`؛ getWatcherIds → `list<int>`؛ getAllowedTransitions → `list<string>`؛ بقیه list → `list<array<string,mixed>>`. |
| `SocialTaskModel.php` | ۱۹→۰ | params → `array<string,mixed>`/`list<string>`؛ list بازگشتی → `list<\stdClass>`. |
| `KpiStatistics.php` | ۱۶→۰ | متدهای list (fetchAll) → `list<array<string,mixed>>`؛ متدهای aggregate → `array<string,mixed>`. |
| `ExportData.php` | ۱۶→۰ | mask/sanitizeRow → `array<string,mixed>`؛ sanitizeRows و export ها → `list<array<string,mixed>>`. |
| `IpAndDeviceModel.php` | ۱۴→۰ | params → `array<string,mixed>`؛ fetchAll ها → `list<\stdClass>`. |
| `ReferralCommission.php` | ۱۴→۰ | هلپرهای `fetchOne/fetchAllRows/fetchColumnValue` و list ها → `list<\stdClass>`؛ `$filters/params` → `array<string,mixed>`/`array<int|string,mixed>`. |
| `Ticket.php` | ۱۳→۰ | `$filterable` → shape؛ هلپرها؛ `searchNative` → `array{items, total}`؛ `getStats` → `array<string,mixed>`. |
| `Investment.php` | ۱۱→۰ | `create` (→ `?int` سازگار)؛ `$filterable`؛ list ها → `list<\stdClass>`؛ `findInIdsForUpdate` → `list<int>`. |
| `User.php` | ۱۰→۰ | `$filterable`؛ `searchWithFilters` → `array{items,total}`؛ stats → `array<string,mixed>`؛ `getUserPermissions` → `list<string>`. |
| `InteractionModel.php` | ۱۰→۰ | list ها → `list<\stdClass>`؛ reason/status labels → `array<string,string>`. |
| `AuditTrail.php` | ۱۰→۰ | `createEntry`(mixed)؛ list ها → `list<\stdClass>`؛ `getStats` → `array<string,mixed>`؛ `findById` → `array<string,mixed>\|null`. |

### تکمیل همهی مدلهای `app/Models/` (بیش از ۵۰ فایل)
همهی مدلهای `app/Models/*` از دستهی no-value-type پاک شدند (مجموعاً بیش از ۳۵۰ خطا). برای مدلهای تکراری از دو اسکریپت batchِ امن استفاده شد (فقط افزودن docblock، بدون تغییر منطق) + بازبینی دستی متدهای خاص:
- `batch_novalue2.py`: افزودن `@param array<string,mixed>` برای پارامترهای شناختهشده (`$data/$filters/$metadata/...`) و `list<int>`/`list<string>` برای `$ids/$userIds/$statuses`.
- `batch_returns.py`: افزودن `@return list<\stdClass>` برای متدهایی که بدنهشان `fetchAll(FETCH_OBJ)`/`$this->db->fetchAll` دارد.
- متدهای aggregate/`searchNative`/`$filterable` بهصورت دستی (با بررسی بدنه) اصلاح شدند.

### سرویسها (شروع)
| فایل | خطا | توضیح |
|---|---|---|
| `AnalyticsQueryService.php` | ۲۲→۰ | aggregate ها → `array<string,mixed>`؛ list ها → `list<array<string,mixed>>`؛ `$sections` → `array<int,string>`. |
| `AntiFraud/DeviceIntelligenceService.php` | ۱۹→۰ | detect* / comprehensiveAnalysis / verifyMobileAppAttestation → `array<string,mixed>`؛ `$deviceInfo/$headers` → `array<string,mixed>`. |
| `AntiFraud/GeolocationIntelligenceService.php` | ۱۵→۰ | lookup* / getFromCache → `array<string,mixed>\|null`؛ aggregate ها → `array<string,mixed>`. |
| `AntiFraud/FraudDetectionService.php` | ۱۵→۰ | پراپرتیهای config → `array<string,mixed>`؛ getHighRiskUsers/getFraudLogs → `list<\stdClass>`. |
| `AntiFraud/VelocityCheckService.php` | ۱۴→۰ | `$activeLocks` → `array<string,bool>`؛ check*/getStatus/getRules → `array<string,mixed>`. |
| `Search/AdminSearchGateway.php` | ۲۹→۰ | متدهای `->toArray()` → `list<\stdClass>`؛ `$filters/$columns` تایپ شد؛ هلپرها (`buildSearchWhere/applyAllowedFilters/safeOrderBy`). |
| `Search/ModuleSearchGateway.php` | ۲۸→۰ | search* → `list<\stdClass>`؛ `searchVitrineRead` → `array{items,total,facets}`. |
| `Search/AdminSearchProvider.php` | ۲۸→۰ | searchAdmin → `array<string,mixed>`؛ search* / quickSearch* → `list<\stdClass>`؛ registeredModules → `list<string>`. |
| `Search/SearchProjectionListener.php` | ۲۲→۰ | همهی index* → `@param array<string,mixed> $d`؛ normalize → `array<string,mixed>`. |
| `Sentry/PerformanceMonitoring/SentryPerformanceMonitor.php` | ۲۰→۰ | `$currentTransaction` → `?array<string,mixed>`؛ `$spans/$queries` → `list<array<string,mixed>>`؛ `$config` → `array<string,mixed>`. |
| `Sentry/ErrorMonitoring/SentryErrorMonitor.php` | ۱۹→۰ | `$config` → `array<string,mixed>`؛ buildEvent/getUserContext/getHeaders/getTags/getStatistics → `array<string,mixed>`. |
| `Sentry/Alerting/AlertDispatcher.php` | ۱۸→۰ | `$throttleConfig` → `array<string,int>`؛ `$alert/$config` → `array<string,mixed>`؛ normalizeAlert → `array<string,mixed>`. |
| `Sentry/Analytics/TrendAnalyzer.php` | ۱۷→۰ | متدهای سری زمانی → `array<int, array<string,mixed>>`؛ aggregate ها → `array<string,mixed>`؛ getHistoricalData/getErrorHotspots → `list<array<string,mixed>>`. |
| `Sentry/Analytics/DashboardService.php` | ۱۶→۰ | aggregate ها → `array<string,mixed>`؛ getFailedJobsList/getOutboxDLQList/getIssuesList → `array{items,total,total_pages}`؛ getTimeSeriesData/getTop* → `list<array<string,mixed>>`؛ calculateChange → `array{value,direction}`. |
| `PerformanceOptimizationService.php` | ۱۶→۰ | `$queryTimes` → `list<array<string,mixed>>`؛ batchInsert/batchUpdate/bulkUpdateWithCase → `array<string,mixed>`؛ bulkFetch → `list<\stdClass>`؛ getAggregates/getQueryStats → `array<string,mixed>`. |
| `ReferralManagementService.php` | ۱۴→۰ | getAllTiers/leaderboard ها → `list<\stdClass>`؛ dashboard/تiers/میلستون → `array<string,mixed>`. |
| `SocialTask/SilentAntiFraudService.php` | ۱۳→۰ | همهی متدها → `array<string,mixed>`؛ `$context/$riskResult/$payload/$score` → `array<string,mixed>`. |
| `FileAccessService.php` | ۱۳→۰ | همهی access* / allow / deny_result → `array<string,mixed>`. |
| `CustomTask/CustomTaskService.php` | ۱۳→۰ | createTask/toggleFavorite/getTaskAnalytics → `array<string,mixed>`؛ list ها → `list<\stdClass>`. |
| `AntiFraud/GeoIPService.php` | ۱۳→۰ | lookup*/check/getGeolocation → `array<string,mixed>\|null`؛ calculateDistance → `float`. |
| `TicketCommandService.php` | ۱۲→۰ | create/reply/close → `array<string,mixed>`؛ validate → `array<string,mixed>`؛ $attachments → `list<array<string,mixed>>`. |
| `Lottery/LotteryService.php` | ۱۲→۰ | listRounds → `array{items,total}`؛ getParticipationCounts → `array<int,int>`؛ بقیه → `array<string,mixed>`. |
| `DatabaseAnalyzerService.php` | ۱۲→۰ | getIndexRecommendations/getTableStats/getSlowQueries → `list<array<string,mixed>>`؛ بقیه → `array<string,mixed>`. |
| `AntiFraud/TaskExecutionEvaluatorService.php` | ۱۲→۰ | متدهای score* → `int`؛ calculate/calculatePenalties → `array<string,mixed>`. |
| `VerificationService.php` | ۱۱→۰ | getVerificationRequests → `list<\stdClass>`؛ approve/reject/status → `array<string,mixed>`. |
| `Auth/OAuthService.php` | ۱۱→۰ | `$oAuthConfig` → `array<string,mixed>`؛ callback/link/unlink → `array<string,mixed>`. |
| `Auth/AuthService.php` | ۱۱→۰ | login*/register/reset → `array<string,mixed>`؛ `$data` → `array<string,mixed>`. |
| `SocialTask/BehaviorAnalysisService.php` | ۱۰→۰ | analyze/detectPatterns/summarize → `array<string,mixed>`؛ isBotLike/isFarmLike → `bool`. |
| `Shared/CouponService.php` | ۱۰→۰ | validateAndCalculate/Redeem/statistics → `array<string,mixed>`؛ paginate → `array{data,total,page,per_page}`؛ all/getRedemptions → `list<\stdClass>`. |
| `MessageModerationService.php` | ۱۰→۰ | getReports → `array{reports,total}`؛ list ها → `list<\stdClass>`؛ approveReport/blockUser/getStats → `array<string,mixed>`. |
| `KYC/KYCCommandService.php` | ۱۰→۰ | submit/handle → `array<string,mixed>`؛ `$files` → `array<int|string,mixed>`. |
| `FeatureFlagService.php` | ۱۰→۰ | getUserContext/update/create → `array<string,mixed>`؛ getHistory/getMetrics → `list<\stdClass>`. |
| `DatabaseService.php` | ۱۰→۰ | همهی متدها → `array<string,mixed>`؛ getBackupById → `array<string,mixed>\|null`. |
| `CaptchaService.php` | ۱۰→۰ | generate*/pingBehavioral → `array<string,mixed>`؛ parseBehavioralToken → `array<string,mixed>\|null`. |
| `BankCardService.php` | ۱۰→۰ | create/updateByUser/adminVerify → `array<string,mixed>`؛ getUserCards/listForUser/getPendingCards → `list<\stdClass>`. |
| `ApiTokenService.php` | ۱۰→۰ | getTokensForAdmin/searchTokens → `array{items,total}`؛ listTokensForUser → `list<\stdClass>`؛ issueToken/refreshToken → `array<string,mixed>`. |
| `User/UserService.php` | ۹→۰ | register → `array<string,mixed>\|false`؛ quickSearch/searchWithFilters → `list<\stdClass>`. |
| `User/ProfileService.php` | ۹→۰ | validateProfileUpdate/updateProfileWithValidation → `array<string,mixed>`؛ getUserSocialAccounts → `list<array<string,mixed>>`. |
| `KYCService.php` | ۹→۰ | submitKYC/verifyKYC/... → `array<string,mixed>`؛ count → `int`. |
| `CustomTask/AdminCustomTaskService.php` | ۹→۰ | همه → `array<string,mixed>`؛ getTaskDetailsForAdmin → `array<string,mixed>\|null`. |
| `Cache/CacheInvalidationService.php` | ۹→۰ | `$event` → `object\|array<string,mixed>`؛ `$userIds` → `list<int>`. |
| `core/Container.php` | ۹→۰ | پراپرتیها → `array<string,mixed>`؛ traceStack → `list<string>`؛ resolveDependencies → `list<mixed>`؛ tagged → `iterable<object>`. |
| `Validators/BaseFormRequest.php` | ۹→۰ | data/errors/validated → `array<string,mixed>`؛ rules/messages/validated/errors → `array<string,mixed>`. |
| `AntiFraud/SeoFraudDetector.php` | ۹→۰ | detect/check* → `array<string,mixed>`؛ smoothScore → `float`. |
| `core/Logger.php` | ۸→۰ | `$defaultContext` → `array<string,mixed>`؛ withContext/enrich/system/... → `array<string,mixed>`. |
| `core/ExceptionHandler.php` | ۸→۰ | enrichSqlContext/sanitizeErrorData/getJsonPayload → `array<string,mixed>`. |
| `core/EventDispatcher.php` | ۸→۰ | listeners → `array<string, list<callable>>`؛ dispatchingStack → `list<string>`؛ getListeners → `list<callable>`. |
| `Utils/Sentry/StackTraceAnalyzer.php` | ۸→۰ | analyze/extractContext/sanitizeVars → `array<string,mixed>`؛ `$vendorPaths` → `list<string>`. |
| `Utils/Sentry/BreadcrumbCollector.php` | ۸→۰ | `$breadcrumbs` → `list<array<string,mixed>>`؛ getAll/getRecent/filterByCategory → `list<array<string,mixed>>`. |
| `Seo/SeoService.php` | ۸→۰ | startTask/completeTask/... → `array<string,mixed>`؛ `$engagementData` → `array<string,mixed>`. |
| `Sentry/SentryExceptionHandler.php` | ۸→۰ | readCircuitFile → `array<string,mixed>\|null`؛ captureException/captureMessage/... → `array<string,mixed>`. |
| `LogService.php` | ۸→۰ | query/cleanup → `array<string,mixed>`؛ logSystem/logActivity/... → `array<string,mixed>`. |
| `CustomTask/CustomTaskModerationService.php` | ۸→۰ | review/approve/reject/moderate → `array<string,mixed>`. |
| `AntiFraud/MLFraudDetectionService.php` | ۸→۰ | analyzeUser/extractFeatures/identifySuspiciousFactors → `array<string,mixed>`. |
| `core/Console/CliDispatcher.php` | ۷→۰ | `$commands` → `array<string,mixed>`؛ `$argv/$args` → `list<string>`؛ resolveCommand → `array<string,mixed>\|null`. |
| `Utils/Sentry/ContextEnricher.php` | ۷→۰ | enrich/get*Context → `array<string,mixed>`؛ getGeolocation → `array<string,mixed>\|null`. |
| `Wallet/WalletQueryService.php` | ۷→۰ | getWalletBalances/canWithdraw → `array<string,mixed>`؛ list ها → `list<\stdClass>`. |
| `SocialTask/CameraVerificationService.php` | ۷→۰ | isRequired/createRequest/processResult/scoreContribution → `array<string,mixed>`. |
| `Search/SearchResult.php` | ۷→۰ | `$items` → `list<\stdClass>`؛ `$metadata` → `array<string,mixed>`؛ toArray → shape. |
| `QueueWorker.php` | ۷→۰ | work → `array<string,mixed>`؛ `$allowedJobs` → `list<string>`؛ `$job` → `array<string,mixed>`. |
| `Notification/NotificationTemplateService.php` | ۷→۰ | renderTemplate/getTemplate/... → `array<string,mixed>`. |
| `Lottery/LotteryCommandService.php` | ۷→۰ | createRound/participate/selectWinner/... → `array<string,mixed>`. |
| `EmailDeliveryStore.php` | ۷→۰ | save/findAndLock/getStats → `array<string,mixed>`؛ getPending → `list<\stdClass>`؛ getEmailsForAdmin → shape. |
| `DirectMessageService.php` | ۷→۰ | sendMessage/getUserInfo → `array<string,mixed>`؛ getConversation/getConversations/getTypingUsers → `list<\stdClass>`. |
| `Jobs/Notification/SendToSegmentNotificationJob.php` | ۷→۰ | handle/processBatch/bulkInsert/dispatchPush → `array<string,mixed>`/`list<int>`. |
| `core/Exceptions.php` | ۶→۰ | ValidationException/BusinessException `$errors` → `array<string,mixed>`. |
| `Seo/AdsSeoService.php` | ۶→۰ | createAd/closeAndRefundBudget → `array<string,mixed>`؛ $data/$scores/$flags. |
| `Search/BaseSearchProvider.php` | ۶→۰ | generateCacheKey/cacheGet/... → `array<string,mixed>`/`list<string>`. |

### ارتقای تستها (بند ۴ بخش ۲ — بهموازات اصلاح)
| تست | تغییر | پوشش |
|---|---|---|
| `FraudDetectionServiceBehaviorTest` | ۳→۸ | رفتار requiresReview (KYC/suspended/در انتظار/بدون) + executeAutomatedActions (suspend/review/کمریسک) |
| `FraudDetectionServiceTest` | ۲→۵ | رفتار calculateFraudScore (ریسک پایین/بالا/clamping) + ضبط outbox |
| `PerformanceAndOptimizationTest` | ۴→۷ | لبههای batchInsert/batchUpdate (خالی/نام جدول نامعتبر/ناسازگاری) |
| `AlertDispatcherThrottleBehaviorTest` | جدید (۳) | رفتار throttle و store در handleAlertRequest |

> نکتهی آموختهشده: در docblock باید `\stdClass` با **یک** backslash باشد؛ و docblock باید **قبل از `public/private function`** قرار گیرد، نه در میانهی آن (درج با اسکریپت باعث شکست `public /** ... */ function` شد و بهصورت دستی تعمیر شد).

## شمار پیشرفت
| نقطه | no-value-type |
|---|---|
| شروع دسته | ۱۷۲۹ |
| پس از ۵ فایل core | ۱۶۵۵ |
| پس از Transaction + VitrineListing | ۱۶۲۱ |
| پس از ۶ فایل مدل اول | ۱۵۵۶ |
| پس از ۶ مدل دیگر | ۱۴۸۸ |
| پس از تکمیل همهی مدلها | ۱۲۹۳ |
| پس از ۴ سرویس AntiFraud | ۱۲۰۸ |
| پس از ۳ سرویس Search | ۱۱۲۳ |
| پس از SearchProjectionListener + ۳ سرویس Sentry | ۱۰۴۴ |
| پس از TrendAnalyzer + DashboardService | ۱۰۱۱ |
| پس از PerformanceOptimization + ReferralManagement + SilentAntiFraud + FileAccess | ۹۵۵ |
| پس از CustomTask + GeoIP + TicketCommand + Lottery | ۹۰۵ |
| پس از DatabaseAnalyzer + TaskExecutionEvaluator | ۸۸۳ |
| پس از Verification + OAuth + Auth | ۸۵۰ |
| پس از BehaviorAnalysis + Coupon + MessageModeration + KYCCommand + FeatureFlag | ۸۰۰ |
| پس از DatabaseService + Captcha + BankCard + ApiToken | ۷۶۰ |
| پس از UserService + ProfileService + KYCService + AdminCustomTask + CacheInvalidation | ۷۳۳ |
| پس از Container + BaseFormRequest | ۶۲۸ |
| پس از SeoFraudDetector + Logger + ExceptionHandler + EventDispatcher | ۵۸۲ |
| پس از StackTraceAnalyzer + BreadcrumbCollector + SeoService + SentryExceptionHandler | ۵۶۶ |
| پس از LogService + CustomTaskModeration + MLFraudDetection | ۵۴۲ |
| پس از CliDispatcher + ContextEnricher + WalletQueryService | ۵۲۱ |
| پس از CameraVerification + SearchResult + QueueWorker | ۵۰۷ |
| پس از NotificationTemplate + LotteryCommand | ۴۸۶ |
| پس از EmailDeliveryStore + DirectMessage + SendToSegmentJob | ۴۷۲ |
| پس از Exceptions + AdsSeoService + BaseSearchProvider | **۴۴۵** (۰ undefined property) |

## نکات الگو
- docblock تکخطی با `@param ... @return ...` توسط PHPStan درست پارس نمیشود → باید چندخطی باشد.
- cast کور `(string)$mixed`/`(int)$mixed` زیر این کانفیگ و PHPStan لول-۹ ممنوع است → باید با `@var` narrow شود (نه cast).
- alias بازگشتی نوع (`@phpstan-type N ... expr?:N`) به دلیل «Circular definition» پشتیبانی نمیشود.

## معیار سلامت
- PHPUnit کامل پس از هر فایل: **سبز** (۲۳۶۳ تست / ۴۸۷۲ assertion / ۰ شکست / ۵ skip محیطی).

## گام بعدی
ادامهی فایلبهفایل با اولویت `core/` (Router، Queue، IdempotencyKey) سپس فایلهای پرخطای `app/`.
