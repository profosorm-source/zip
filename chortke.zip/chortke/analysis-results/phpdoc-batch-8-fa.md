# تکمیل تایپداک + ساخت تست — دسته هشتم (گزارش فارسی)

## رویکرد
ادامهی تدریجی + رعایت مرزها (رفع ریشهای) + **ساخت فایل تست برای هر فایل بدون تست**.

## رفعهای ریشهای
### ۱. app/Models/InfluencerModel.php
- **باگ واقعی ریشهای**: `create()` متد مردهای بود که override ناسازگار با `Core\Model::create()`
  (که به int|false اصلاح شده بود) داشت. هیچ call-site نداشت → حذف شد.

### ۲. app/Models/Notification.php
- `create(array $data)` → @param array<string,mixed>

## تستهای جدید ساختهشده (برای فایلهای بدون تست)
1. **DashboardStatsServiceTest** (7 تست): getCount، graceful degradation، isDatabaseUp
2. **InfluencerModelTest** (5 تست): state-machine (transitions, terminal status)
3. **NotificationModelTest** (5 تست): create، markAsRead، ثابتها
4. **FeatureFlagSDKTest** (6 تست): allEnabled/anyEnabled/when/unless/withContext
5. **ExportServiceTest** (2 تست): prepareUsersExport (formatting، handling missing fields)
6. **AdvancedAuditTrailTest** (3 تست): compareChanges (record missing، context diff)

## تأیید
- ۶ تست جدید همه پاس (مجموعاً ۲۸ تست)
- php -l همه فایلها OK
- بدون ignoreErrors جدید، بدون DTO، بدون فایل سورس جدید (فقط فایل تست)

## عدد
- کل خطاها: ۵۹۷۳ → ۵۹۷۰
- no-value-type: ۱۸۱۶ → ۱۸۱۴
- از ۷۰۲۲ اولیه: حذف ۱۰۵۲ خطا
