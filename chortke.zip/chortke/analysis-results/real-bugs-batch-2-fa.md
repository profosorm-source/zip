# رفع خطاهای واقعی — دسته دوم (گزارش فارسی)

## رویکرد
ادامه از دسته اول، تمرکز بر «خطاهای واقعی» باقیمانده (کرش/باگ نوع)، نه نویز تایپداک.
اصل: رفع ریشهای، بدون ignoreErrors جدید، بدون DTO، بدون فایل سورس جدید.

## موارد رفعشده در این نوبت

### ۱. ۶۳ مورد «Result of json()/redirect() (void) is used»
- ریشه: `return $this->response->json(...)` / `return $response->json(...)` / `return $this->json(...)`
  که در آن json/redirect/back همگی void هستند و `Response::send()` همیشه HttpResponseException
  شلیک میکند → return هرگز اجرا نمیشود (مرده).
- راهحل: حذف `return ` مرده. در RateLimitMiddleware که بعد از json به end متد میرسید،
  یک `return $response` (که هرگز اجرا نمیشود) برای تکمیل امضای `: mixed` اضافه شد.
- فایلها: AuthController(admin), TicketController(admin), InvestmentController,
  LotteryController, ContentController, KpiController, SocialAccountController,
  AdminMiddleware, AuthMiddleware, AdvancedFraudMiddleware, CSRFMiddleware,
  ConcurrentRequestMiddleware, PermissionMiddleware, RateLimitMiddleware,
  RequireFeature, SafeModeMiddleware.

### ۲. باگ واقعی: TicketController (IDOR)
- ریشه: بعد از `if (!$ticket) { $this->response->json(...); }` ادامه مییافت و از
  `$ticket->assigned_to` استفاده میشد (json throw میکند ولی PHPStan نمیداند).
- راهحل: بعد از json در هر دو شاخهی null-ticket، `return;` اضافه شد.

### ۳. ۷ مورد «should return array but returns null» (باگ واقعی)
- ApiTokenService::createTokenForUser → return null در نبودِ کاربر → به
  ['success'=>false,'message'=>...,'status'=>404] تبدیل شد (سازگار با بقیه متد).
- CryptoDepositService::approve/reject/tryAutoVerify → return null در نبودِ واریز →
  به ['success'=>false,'message'=>...] تبدیل شد.
- FeatureFlagService::getUserContext → `return null` اضافی در if (!$kyc) حذف شد
  (kyc نبودن نباید کل context را null کند).

### ۴. باگ واقعی: CreateCryptoDepositIntentJob (fraud reason)
- `$risk['reason']` بدون null-safe خوانده میشد → با `?? 'security_block'` و متغیر
  `$reason` اصلاح شد.

### ۵. باگ واقعی: FeatureFlagController::create
- `$data = $this->request->json()` (که ?array است) بدون `?? []` → `$data[$field]`
  روی null خطا میداد → به `?? []` تبدیل شد (مطابق الگوی سراسری پروژه).

### ۶. ناهماهنگی return type (نه cast، تطبیق با واقعیت)
- InfluencerController::formatPricing → annotation از array<string,mixed> به
  list<array{type,hours,price,label}> اصلاح شد (خروجی واقعاً لیست است).
- NotificationService::getNewNotifications و job → annotation دقیق
  array{success,notifications,unread_count,last_id?} داده شد تا زنجیره تایپ درست شود.

## تأیید
- php -l: همه فایلهای تغییر یافته OK
- phpstan.neon (اصلی): No errors
- tests/Unit: 2147 تست — فقط ۱ شکست محیطی (RedisGracefulTest) + ۳ skip، بدون رگرسیون
- ApiToken/CryptoDeposit/Influencer تستها: OK
- runtime: /health, /health/ready, / = 200، بدون خطای 500

## نکته: دستههای باقیمانده که «نویز» هستند (نیاز به تکمیل PHPDoc، نه رفع باگ)
- object::undefined method (134) — متدها واقعاً وجود دارند ولی container->make به object تایپ
  میشود (بررسی نمونهها: Ticket::findForUser, VitrineRequest::create, CronSubmissionsJob,
  CacheInvalidationService::invalidateWallet, ReferralService::processCommission همه موجودند).
- should return ... but returns mixed (183) — fetch DB است، به toObject نیاز دارد.
- Instanceof always false / Else unreachable (else در ternary) — الگوهای دفاعی که
  PHPStan آنها را مرده میداند.
- property never read / method unused / has no type/return — نیاز به تایپداک.
