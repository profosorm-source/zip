# رفع خطاهای واقعی — دسته ششم (گزارش فارسی)

## رویکرد
ادامه از دستههای قبل؛ تمرکز بر «رفعهای معنایی پراکنده» — مواردی که میتوانستند
خطا/کرش بدهند یا باگ منطقی داشتند. بدون ignoreErrors جدید.

## موارد رفعشده

### ۱. باگ واقعی: implode روی errors تو در تو (۳ مورد در InteractionApiController)
- `implode(', ', $validator->errors())` که errors آرایهی تو در تو است و implode روی آن
  TypeError میداد → با flatten کردن به آرایهی تخت پیامها اصلاح شد.

### ۲. باگ واقعی: count() روی object در DatabaseAnalyzerService
- `toObject()` آرایهی indexes را به object تبدیل میکرد و count روی object تعداد
  property ها را میشمرد (نه ردیفها) → به آرایه نگه داشته شد.

### ۳. باگ واقعی: FeatureFlagService::getHistory/getMetrics پارامتر دوم را نادیده میگرفت
- ۴ call-site با ۲ پارامتر (limit/hours) صدا میزدند ولی سرویس فقط ۱ پارامتر داشت و
  پارامتر دوم را به مدل نمیرساند → پارامتر دوم به سرویس و مدل اضافه شد.

### ۴. باگ واقعی: explode/implode/preg_replace با string|false|mixed
- InfluencerModel (explode با mixed), ApiTokenService (preg_replace string|null),
  DatabaseAnalyzerService

### ۵. باگ واقعی: request->body() mixed (چند فایل)
- UserController (8 جا), FingerprintController, WalletDepositRequestListener,
  OAuthController → `(array)$this->request->body()`

### ۶. باگ واقعی: core offset-on-mixed
- RetryPolicy (config nested), IdempotencyKey (PDO fetch), Event (data → array),
  GenericEvent, Queue (json_decode), Cache (safeUnserialize), Session (config) →
  همه با cast به آرایه درست شد.

### ۷. Anonymous function unused use (۲ مورد)
- PlaceBetJob ($explicitKey), ProfileService ($accessToken) → از use حذف شد.

## تأیید
- php -l: همه فایلهای تغییر یافته OK
- تستها: InfluencerService, Stability (42), SplitServices (18), DependencyIntegrity (6) → OK
- runtime: /health, /health/ready, / = 200

## نتیجه عددی
- کل خطاها: ۶۴۰۹ → ۶۳۵۹ (کاهش ۵۰ در این نوبت)
- از ۷۰۲۲ اولیه: حذف ۶۶۳ خطا

## نکته
باقیماندهی ۶۳۵۹ خطا عمدتاً نویز تایپداک است. مواردی که بررسی شد (Instanceof always
false در core، Unable to resolve template type، Unsafe new static) نویز تحلیل هستند
نه باگ منطقی — در runtime کار میکنند. رفع آنها نیازمند تکمیل PHPDoc است.
