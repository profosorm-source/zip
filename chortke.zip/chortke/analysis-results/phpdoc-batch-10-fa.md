# تکمیل تایپداک + ساخت تست — دسته دهم (گزارش فارسی)

## رویکرد
ادامهی تدریجی + رعایت مرزها + ساخت تست برای هر فایل بدون تست.

## فایل تمیزشده
### app/Services/WebSocketService.php (۱۷ مورد no-value-type + ~۱۰ خطای پنهان)
- getRoomMembers/getOnlineInRoom: list<int>
- getUserRooms: list<string>
- publishToRoom/sendToUser/broadcastToUsers: array<string,mixed>
- collectMessages/getQueueMessages: list<mixed>
- (int)config / (string)$msg cast با is_scalar/is_numeric امن شد
- helper getPendingMessageCount برای getStats (رفع $count on mixed)

## تست جدید ساختهشده
- **WebSocketServiceTest** (7 تست): joinRoom (موفق + خطا)، leaveRoom، getRoomMembers، isOnline، getOnlineInRoom
  → همه پاس

## تأیید
- تست WebSocketServiceTest → OK (7 tests)
- php -l → OK
- بدون ignoreErrors جدید، بدون DTO

## عدد
- کل خطاها: ۵۹۵۲ → ۵۹۳۲
- no-value-type: ۱۷۹۷ → ۱۷۸۰
- از ۷۰۲۲ اولیه: حذف ۱۰۹۰ خطا
