# گزارش — گام بعدی: رفع «undefined property object::xxx» (در حال انجام)

## الگوی ریشهای شناساییشده
اکثر undefined property ها از یکی از این دو منبع میآیند:
1. **مدل** متدهایی که `?object` برمیگردانند ولی در واقع `\stdClass` برمیگردانند (از `fetch(FETCH_OBJ)`, `first()`, `db->fetch()`, `db->fetchAll()`).
2. **سرویس/جاب** متدهایی که پارامتر `object $x` میگیرند ولی stdClass دریافت میکنند، یا `toObject()` که `?object` برمیگرداند.

## اصلاحات انجامشده (این گام)
- `app/Models/CustomTaskSubmissionModel` — ۶ متد `?object` → `?\stdClass`
- `app/Services/CustomTask/CustomTaskModerationService` — پارامترهای `object $submission` → `\stdClass`
- `app/Models/Coupon` — ۳ متد `?object` → `?\stdClass`؛ `CouponService::isCouponActive` → `\stdClass`
- `app/Jobs/CustomTask/PayRewardJob` — `handle(object)` → `\stdClass`
- `app/Models/InfluencerVerification` — همهی `?object` → `?\stdClass`
- `app/Models/SocialTaskExecutionModel`/`SocialTaskModel` — `getCameraRequestForUser` → `?\stdClass`
- `app/Models/SentryModel` — ۱۷ متد `?object` → `?\stdClass` (getActiveRules هم `@return list<\stdClass>`)
- `app/Services/Sentry/Alerting/AlertRulesEngine` — پارامترهای `object $rule` → `\stdClass`
- `app/Models/Withdrawal` — `lockForUpdate` → `?\stdClass`
- `app/Models/DirectMessage` — `getConversation`/`getConversations` → `list<\stdClass>`، `getUserInfo`/`findMessageById` → `?\stdClass`
- `app/Services/Withdrawal/WithdrawalAdminService` — `toObject` → `?\stdClass`

## اعداد
| شاخص | شروع گام | الان |
|---|---|---|
| undefined property | ۸۵۹ | **۵۹۲** |
| PHPStan کل | ۵۶۹۸ | **۵۲۹۶** |
| PHPUnit | ۲۳۲۶ (۰ شکست) | **۲۳۲۶ (۰ شکست)** |

> بدون هیچ رگرسیون (PHPUnit همیشه سبز).

## نکته (درسآموخته)
تغییر `Core\Model::find` به `?\stdClass` **امتحان شد ولی بازگردانده شد** — چون ۲۰+ مدل آن را با `?object` override کردهاند و خطای «not covariant» میداد. بهجای آن، الگوی درست این است که **سرویس/مدلِ هر فایل** را بهصورت فردی ریشهای اصلاح کنیم، نه parent مرکزی.

## وضعیت
این گام هنوز در جریان است (~۵۹۲ undefined property باقی). الگوی ثابتشده مؤثر است و فایلهای بعدی (ContentService, UserLevelCommandService, AcceptVitrineRequestJob, BankCardService, AuthService, PolicyService, KYCCommandService, EmailService...) به همین روش رفع خواهند شد.
