# رفع خطاهای واقعی — دسته اول (گزارش فارسی)

## اصل کلیدی
رفع از ریشه و استاندارد، نه راهمیانبر. هیچ `ignoreErrors` جدید، هیچ `@phpstan-ignore`،
هیچ DTO جدید، و هیچ فایل سورس جدیدی ساخته نشد. همه تغییرات سمانتیک/معماری هستند.

## نتیجه عددی (اسکن لول ۹ بدون ignore)
- قبل: 7022 خطا در 652 فایل
- بعد: 6799 خطا (حذف 223 خطای واقعی)
- undefined method کلاس واقعی: 21 → 0 (اینها کرش runtime واقعی بودند)
- Offset does not exist: 41 → 0
- Required param بعد از optional: 1 → 0
- Anonymous fn / string|false|true: ~12 → 0

## فایل‌های اصلاح‌شده (خلاصه)
- app/Controllers/Api/BaseApiController.php (paginationParams)
- app/Services/MessageModerationService.php + تست (ترتیب پارامتر)
- 4 کنترلر Admin (FeatureFlag, FraudManagement, Investment, Lottery) -> : void
- app/Controllers/User/ContentController.php (store/buildJsonError -> void)
- app/Middleware/AdvancedFraudMiddleware.php (: mixed)
- app/Controllers/Admin/LogController.php, User/NotificationController.php (تایپ ردیف)
- app/Controllers/User/TwoFactorController.php, Jobs/Auth/Verify2FAJob.php,
  Jobs/Auth/OAuthHelperTrait.php (string|false|true)
- app/Models/Notification.php, SystemTelemetryModel.php, Transaction.php (bool/int, ?object)
- Jobs/Notification/SendNotificationJob, SendToAll/SendToSegment (null/false, preg_replace)
- app/Services/SocialTask/SocialTaskService.php + SocialTaskModel.php
  (11 متد گم‌شده پیاده‌سازی شد)
- app/Services/AdNotificationDispatcher.php (finance -> adsBudgetSettlementService)
- app/Services/VitrineSettingsService.php (AppSettings->Setting برای persist واقعی)
- app/Services/User/UserLevelService.php (حذف متد مرده + adminChangeLevel)
- app/Services/User/UserService.php (findByMobile)
- app/Services/Shared/ReferralService.php (getCommissionTrend + checkAndAwardBonus)
- app/Models/TicketMessage.php + app/Services/TicketService.php (getAttachmentMessage)
- app/Services/Notification/NotificationService.php (sendToChannel)

## تأییدها (همه سبز)
- php -l: 867 فایل OK
- 5 کانفیگ PHPStan: No errors
- Unit + Integration + Financial: OK
- Runtime: health/ready/root = 200، route:audit = 658

## باقی‌مانده (6799)
عمدتاً «نویز تایپداک»: آرایه بدون generic (~2100)، stdClass از DB (~1100)، mixed از config/DB (~1100).
نیاز به تکمیل PHPDoc دارد، نه cast کور.
