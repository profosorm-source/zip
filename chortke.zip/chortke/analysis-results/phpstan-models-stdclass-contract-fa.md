# گزارش — اصلاح قرارداد `?object → ?\stdClass` در همهی مدلها

> تاریخ: ۲۰۲۶-۰۸-۰۳ | وضعیت: **کامل — بدون خطای باقیمانده**

## خلاصه
بر اساس درخواست کاربر («`?object → ?\stdClass` در همهی مدلها = اصلاح قرارداد نادرست به قرارداد درست»)، تمام متدهای مدل که در عمل `\stdClass` برمیگردانند ولی `?object` اعلان کرده بودند، به `?\stdClass` (یا `list<\stdClass>`) اصلاح شدند. این با `universalObjectCratesClasses: [stdClass]` در کانفیگ PHPStan هماهنگ است و منشأ «undefined property» را از بین میبرد.

## اعداد نهایی
| معیار | قبل از این بخش | بعد از این بخش |
|---|---|---|
| «undefined property» | ۰ | **۰** |
| «should be compatible» | ۰ | **۰** (۹ مورد جدید resolved شد) |
| «undefined method» | ۰ | **۰** |
| تستهای PHPUnit | ۲۳۶۳ / ۴۸۷۲ | **۲۳۶۳ / ۴۸۷۲** (۰ شکست / ۵ skip محیطی) |

## تغییرات انجامشده

### ۱) تبدیل `?object → ?\stdClass` در مدلها
- **۶۵ متد** در فایلهای `app/Models/*` که نوع بازگشتی `?object` داشتند و منبعشان `db->fetch()`/`FETCH_OBJ`/`normalizeToObject` (که تضمینی `?\stdClass` است) بود → به `?\stdClass` تبدیل شدند.
- موارد کلیدی: `ActivityLog`، `ApiToken`، `BankCard`، `BannerPlacement`، `ContentAgreement`، `CouponRedemption`، `CryptoDeposit(Intent)`، `Investment*`، `Permission`، `Page`، `RiskPolicy`، `Score`، `ScheduledPayment`، `TradingRecord`، `TransactionQuery`، `UserVacation`، `UserVerification`، `VelocityAndScoreModel`، `VitrineRating` و...

### ۲) تغییر نام متدهای `create()` که override والد (`@return int|false`) بودند ولی آبجکت برمیگرداندند
طبق الگوی تثبیتشده (قانون ۳ بخش ۳)، اینها به نام دامنهای تغییر نام یافتند تا هم با قرارداد والد سازگار شوند و هم «undefined property» از بین برود:

| مدل | نام جدید | caller(های) بهروزرسانیشده |
|---|---|---|
| `BankCard::create` | `createBankCard` | `BankCardService` |
| `LedgerEntry::create` | `createEntry` | `LedgerService` |
| `ReferralCommission::create` | `createCommission` | `ReferralService` (۸)، `ProcessReferralCommissionJob` |
| `SeoExecution::create` | `createExecution` | `AdsSeoService` |
| `SocialAccount::create` | `createAccount` | `SocialAccountService` |
| `VitrineRequest::create` | `createRequest` | `InteractionApiController`، `SendVitrineRequestJob` |
| `Withdrawal::create` | `createWithdrawal` | `WithdrawalUserService` |
| `ManualDeposit::create` | `createDeposit` | (بدون caller — dead) |
| `CustomTaskTransaction::create` | `createTransaction` | (بدون caller — dead) |

> نکته: `ManualDeposit::create` و `CustomTaskTransaction::create` هیچ caller ندارند (سرویسها از raw SQL استفاده میکنند)؛ برای رفع ناسازگاری و ایمنی، فقط تغییر نام داده شدند، نه حذف.

### ۳) تستهای بهروزرسانیشده (بهخاطر rename)
- `tests/Unit/Services/BankCardServiceTest` — expectation به `createBankCard`
- `tests/Unit/FinancialIntegrityTest` — `createEntry`
- `tests/Unit/Services/SecurityHardeningTest` — `createEntry` (۳ محل)

## محیط
- محیط پس از reset بازسازی شد: PHP 8.4.23، Composer، MariaDB (root+DB chortk)، Redis، `/etc/hosts`، migrate (۱۳۱ migration) و seed انجام شد.
- PHPStan Level 9 بدون-ignore با کانفیگ `/tmp/phpstan-noignore.neon`.

## وضعیت کل دستهها
- ✅ undefined property: **۰**
- ✅ should be compatible (create overrides): **۰**
- 🔜 دستهی بعدی: **no-value-type** (~۱۷۰۰) و سپس نویزها.
