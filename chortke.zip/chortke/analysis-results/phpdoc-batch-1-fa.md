# تکمیل تایپداک — دسته اول (گزارش فارسی)

## رویکرد
شروع تکمیل اصولی PHPDoc/تایپداک بهصورت تدریجی، دستهبندیشده، با تأیید بعد از هر
فایل. تمرکز: دسته «آرایه بدون generic» (no value type specified in iterable).
برای هر فایل: تحلیل بدنه برای تشخیص نوع درست، افزودن docblock، سپس lint + PHPStan
+ تست. هنگام سفتکردن تایپ، خطاهای پنهان زیر تایپ آزاد قبلی ظاهر شدند که همگی رفع شدند.

## فایلهای تمیزشده (کاملاً بدون خطا)
### ۱. app/Data/CommonPasswords.php (۵ مورد)
- $normalizedCache: array<string,true>|null
- $passwords: list<string>
- getNormalizedPasswords(): array<string,true>
- buildBloomFilter(array $passwords): list<string>
- benchmarkMethods(): array<string,string>
- isKeyboardPattern: @var list<string>
- + رفع `$bloom` از cache با is_string

### ۲. app/Services/InfluencerService.php (۲۲ مورد)
- متدهای command: @return array<string,mixed> + @param
- Query delegates (getOrdersByCustomer, searchInfluencers, listVerifiedProfiles): @return list<\stdClass>

### ۳. app/Services/Shared/DashboardStatsService.php (۲۴ مورد)
- getGlobalStats: array<string,int> (با @var روی result از cache)
- getTrend/getDistribution/getAggregates/getTrendData/comparePeriods/...: array<string,mixed>
- getCount/buildWhere: param array<string,mixed> / return array{0:string,1:array<int,mixed>}
- getAggregates: @var array<string,mixed>
- getCustomTaskStats: array<int|string,mixed>

### ۴. app/Models/InfluencerModel.php (۲۵ مورد + ۱۵ خطای پنهان)
- $searchable: list<string>, $filterable: array<string, array{0:string,1:string}>
- createProfile/updateProfile/getVerified/...: @param array<string,mixed>
- getVerified/getVerifiedProfiles/adminListProfiles/getSubmittedVerifications/getReputationHistory: list<\stdClass>
- searchNative: array{total:int, items:list<\stdClass>}
- calculateReputationGrade: array{letter,label,color,stars}
- getReputationStatsBatch: array<int, object{...}>
- findProfile/getProfileSafe: ?\stdClass
- cast های $filters و @var روی fetch objects

## تأیید
- php -l: همه فایلها OK
- PHPStan بدون-ignore: هر ۴ فایل → ۰ خطا
- تست InfluencerService: OK (2 tests)
- بدون ignoreErrors جدید، بدون DTO، بدون فایل سورس جدید

## نکته مهم (شفافسازی)
هنگام سفتکردن تایپها، خطاهایی که قبلاً زیر تایپِ آزاد `array` پنهان بودند ظاهر شدند
(مثل cast روی $filters['x'], property روی fetch(FETCH_OBJ)). این طبیعی است و همگی
با cast/چک/@var رفع شدند. یعنی هر فایل تا «کاملاً بدون خطا» تمیز شد، نه فقط
no-value-type.

## عدد
- 4 فایل کاملاً تمیز شد (مجموع ~۷۶ مورد no-value-type + ~۲۵ خطای پنهان)
