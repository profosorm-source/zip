# گزارش اجرای پروژه و PHPStan — Chortke

تاریخ اجرا: 2026-07-31  
مسیر پروژه در workspace: `/home/user/chortke`  
منبع دریافت‌شده: `https://github.com/profosorm-source/zip` — ریپازیتوری فقط شامل `chortke.zip` بود و پروژه از آن استخراج شد.

## 1) وضعیت محیط و نصب وابستگی‌ها

- OS: Debian GNU/Linux 13
- PHP: `8.4.23`
- Composer: `2.8.8`
- PHPStan: `1.12.33`
- افزونه‌های نصب‌شده برای PHP/PHPStan: `pdo`, `pdo_mysql`, `pdo_sqlite`, `bcmath`, `mbstring`, `xml`, `curl`, `zip`, `intl`, ...
- `composer install` موفق بود و چیزی برای نصب/آپدیت نداشت؛ `vendor/` داخل ZIP وجود داشت.
- `composer validate` فقط هشدار license داد.
- هشدار مهم Composer: `49` مورد عدم انطباق PSR-4/autoloading گزارش شد. اینها فعلاً fatal نیستند ولی برای testability/CI و autoload پایدار مشکل‌زا هستند.

## 2) نتیجه بالا آوردن پروژه / Smoke Test

با PHP built-in server روی `127.0.0.1` تست شد.

| Endpoint | نتیجه | توضیح |
|---|---:|---|
| `/health` | 200 | liveness ساده OK |
| `/ping` | 200 | `pong` |
| `/health/live` | 200 | وضعیت memory OK |
| `/health/ready` | 503 | DB و queue/outbox/dlq/saga به‌خاطر نبود MySQL آماده نیستند |
| `/health/distributed` | 503 | وابستگی‌های distributed به DB وصل نمی‌شوند |
| `/` | 500 | `HomeController` هنگام resolve به DB نیاز دارد و DB connection refused می‌شود |

خطای runtime اصلی:

```text
Database reconnection failed: SQLSTATE[HY000] [2002] Connection refused
[Router] Cannot resolve Controller 'App\Controllers\HomeController'
```

نکته معماری: حتی endpointهای health که باید lightweight باشند، در لاگ چند بار تلاش ناموفق DB ثبت می‌کنند (`settings.load_failed`, `Failed to store transaction`, `middleware.performance_logging.failed`). این نشان می‌دهد bootstrap/global middleware یا loading تنظیمات side-effect دارد و liveness کاملاً از DB جدا نیست.

Docker در این محیط نصب نبود؛ بنابراین `docker-compose.yml` قابل اجرا نبود. برای بالا آمدن کامل، باید MySQL/MariaDB و Redis مطابق `.env` یا Docker Compose اجرا شوند و migrations اعمال شوند.

## 3) نتیجه اجرای PHPStan با کانفیگ‌های موجود

| Config | Scope | تعداد ignoreErrors تقریبی | نتیجه |
|---|---|---:|---:|
| `phpstan.neon` | `app/`, `core/` | 99 | 0 خطا / PASS |
| `phpstan_core_check.neon` | `app/`, `core/` | 142 | 0 خطا / PASS |
| `phpstan_check.neon` | `app/Services/` | 160 | 1 خطا |
| `phpstan_core.neon` | `core/` | 101 | 1 خطا |
| `phpstan_full.neon` | `app/Services/`, `core/` | 88 | 137 خطا |
| config موقت بدون `ignoreErrors` | `app/`, `core/` | 0 | 7169 finding در 652 فایل |

جمع‌بندی مهم: پاس شدن `phpstan.neon` به‌تنهایی نشانه سلامت نیست؛ چون تعداد زیادی issue در `ignoreErrors` پنهان شده‌اند. اجرای بدون ignore نشان داد بدهی تحلیل استاتیک بسیار بزرگ است.

### 3.1 خطاهای مستقیم کانفیگ‌های check/core

- `app/Services/DataExportService.php:192` — `realpath()` مقدار `mixed` می‌گیرد درحالی‌که `string` می‌خواهد.
- `core/QueryBuilder.php:925` — استفاده از `??` روی offsetی که PHPStan آن را `*NEVER*` و همیشه موجود/غیر-null تشخیص داده است.

## 4) تحلیل 137 خطای `phpstan_full.neon`

### 4.1 توزیع بر اساس identifier

| مورد | تعداد |
|---|---:|
| `argument.type` | 64 |
| `nullCoalesce.offset` | 14 |
| `return.type` | 12 |
| `method.nonObject` | 11 |
| `property.onlyRead` | 10 |
| `encapsedStringPart.nonString` | 7 |
| `property.nonObject` | 6 |
| `method.notFound` | 4 |
| `assign.propertyType` | 3 |
| `property.private` | 2 |
| `function.impossibleType` | 2 |
| `offsetAccess.notFound` | 1 |
| `empty.variable` | 1 |

### 4.2 توزیع دسته‌ای

| مورد | تعداد |
|---|---:|
| `Mixed value passed to typed API` | 57 |
| `Dead/invalid conditional or array offset` | 18 |
| `Return type mismatch` | 12 |
| `Nullable service dependency call` | 11 |
| `Property lifecycle / unused DI property` | 10 |
| `Unsafe interpolation/cast of mixed` | 7 |
| `Wrong argument type` | 7 |
| `Nullable/dynamic object property access` | 6 |
| `Undefined method / broken contract` | 4 |
| `Generic/static singleton typing` | 3 |
| `Other` | 2 |

### 4.3 فایل‌های پرتکرار

| مورد | تعداد |
|---|---:|
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 10 |
| `app/Services/ContentService.php` | 10 |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 9 |
| `core/QueryBuilder.php` | 9 |
| `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php` | 7 |
| `app/Services/Search/SearchProjectionListener.php` | 7 |
| `core/EventDispatcher.php` | 5 |
| `app/Services/Influencer/InfluencerCommandService.php` | 4 |
| `app/Services/Sentry/Alerting/AlertDispatcher.php` | 4 |
| `app/Services/Withdrawal/WithdrawalAdminService.php` | 4 |
| `app/Services/Auth/AuthService.php` | 3 |
| `app/Services/EmailService.php` | 3 |
| `app/Services/Search/ModuleSearchProvider.php` | 3 |
| `app/Services/WebSocketService.php` | 3 |
| `app/Services/Withdrawal/WithdrawalUserService.php` | 3 |
| `core/Cache.php` | 3 |
| `app/Services/AntiFraud/RiskPolicyService.php` | 2 |
| `app/Services/Auth/TwoFactorService.php` | 2 |
| `app/Services/BankCardService.php` | 2 |
| `app/Services/BulkOperationsService.php` | 2 |

## 5) مهم‌ترین مشکلات کشف‌شده

### A) قراردادهای شکسته و متدهای undefined

اینها بیشترین ریسک runtime fatal دارند:

- `app/Services/Auth/AuthService.php:176` — `EmailService::sendAccountLockedAlert()` وجود ندارد.
- `app/Services/BulkOperationsService.php:638` — `Redis::scanKeys()` وجود ندارد.
- `app/Services/User/UserService.php:281` — `UserService::getTransactionWrapper()` وجود ندارد.
- چند مورد call روی سرویس nullable: `OutboxServiceInterface|null`, `WalletServiceInterface|null`, `TransactionWrapper|null`.

### B) عبور `mixed` از مرزهای حساس سرویس‌ها

بخش بزرگی از خطاها از نوع `argument.type` است؛ یعنی داده‌هایی از request/DB/config بدون normalizer/DTO/validator وارد APIهای تایپ‌شده می‌شوند. بیشترین نمونه‌ها در:

- AntiFraud strategies: IP, userAgent, email, phone, deviceInfo همگی `mixed` هستند.
- ContentService: platform/url/title/text/aggregateId از نوع `mixed` وارد validator/outbox می‌شوند.
- Search/Sentry/Cache modules: config/entityId/query/metric/operator بدون shape مشخص هستند.

این الگو در سیستم Enterprise خطرناک است چون validation مرزی منسجم وجود ندارد و خطاها در runtime، نه compile/static-time، رخ می‌دهند.

### C) ضعف در QueryBuilder/Core

- `core/QueryBuilder.php:762` — `increment()` باید `int` برگرداند ولی `bool` برمی‌گرداند.
- `core/QueryBuilder.php:1211` و `1299` — اجزای join/condition از `mixed` داخل string interpolate می‌شوند.
- `core/Application.php:67` — generic contract متد `make()` می‌گوید `T of object` ولی `object` برمی‌گردد.
- `core/Cache.php` و `core/EventDispatcher.php` — singleton/static typing با `object` و `static` ناسازگار است.

### D) Nullability و object-shape

چندین property access روی `object|null` یا سرویس nullable دیده شد:

- `AuthService.php:202-203` — `$id` روی `object|null`.
- `WithdrawalUserService.php:247/251/258` — `$id` روی `object|null`.
- `MigrationService.php:390` — `$max_batch` روی `object|null`.

### E) Return type mismatch / false|string

چند متد/closure مقدار `false` یا `null` برمی‌گردانند درحالی‌که قرارداد strictتر است:

- `Auth/LoginRiskService.php:455` — `normalizeIp()` باید `string` بدهد ولی `string|false` می‌دهد.
- `Auth/TwoFactorService.php:136` — باید `bool` بدهد ولی `null` ممکن است برگردد.
- `AntiFraud/RiskPolicyService.php:180` — closure باید `non-empty-string` بدهد ولی `false` ممکن است.
- `Interaction/ReportService.php:60` — `json_encode` می‌تواند `false` بدهد ولی متد `string` می‌خواهد.

## 6) اجرای خام بدون ignoreErrors

برای سنجش بدهی واقعی، یک config موقت ساخته شد و `app/` و `core/` بدون `ignoreErrors` در level 9 بررسی شدند.

نتیجه: **7169 finding در 652 فایل**.

### 6.1 پرتکرارترین identifierها در اجرای خام

| مورد | تعداد |
|---|---:|
| `missingType.iterableValue` | 2184 |
| `property.notFound` | 1106 |
| `cast.int` | 641 |
| `argument.type` | 543 |
| `cast.string` | 360 |
| `return.type` | 290 |
| `offsetAccess.nonOffsetAccessible` | 262 |
| `missingType.return` | 194 |
| `property.onlyWritten` | 176 |
| `method.notFound` | 159 |
| `method.void` | 156 |
| `property.nonObject` | 124 |
| `cast.double` | 114 |
| `deadCode.unreachable` | 108 |
| `method.nonObject` | 97 |
| `ternary.alwaysTrue` | 92 |
| `missingType.parameter` | 80 |
| `method.unused` | 75 |
| `offsetAccess.notFound` | 44 |
| `encapsedStringPart.nonString` | 43 |

### 6.2 پرتکرارترین فایل‌ها در اجرای خام

| مورد | تعداد |
|---|---:|
| `app/Controllers/Admin/FeatureFlagController.php` | 114 |
| `core/Lib/QRCode.php` | 104 |
| `app/Services/Influencer/InfluencerCommandService.php` | 78 |
| `app/Services/CustomTask/CustomTaskModerationService.php` | 66 |
| `app/Controllers/Api/InfluencerController.php` | 65 |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 60 |
| `app/Controllers/User/InfluencerController.php` | 59 |
| `core/Queue.php` | 55 |
| `app/Services/ContentService.php` | 52 |
| `app/Services/CryptoDeposit/CryptoDepositService.php` | 52 |
| `app/Controllers/Api/SocialTaskApiController.php` | 51 |
| `app/Controllers/Admin/LevelController.php` | 47 |
| `app/Services/FeatureFlagService.php` | 46 |
| `app/Services/BannerService.php` | 45 |
| `app/Services/Shared/CouponService.php` | 45 |
| `app/Services/Shared/ReferralService.php` | 45 |
| `app/Controllers/Admin/InfluencerController.php` | 43 |
| `app/Controllers/Api/UserController.php` | 43 |
| `app/Services/Analytics/AnalyticsQueryService.php` | 43 |
| `app/Controllers/Admin/ExecutorTaskController.php` | 42 |

این عدد نشان می‌دهد پروژه از نظر static typing در وضعیت «پاس‌شده با suppression» قرار دارد، نه «واقعاً clean».

## 7) پیشنهاد اولویت‌بندی برای رفع، بدون اعمال تغییر فعلاً

1. اول خطاهای fatal-contract را رفع کنیم: undefined method، call روی سرویس nullable، return type mismatchهای core.
2. سپس boundary normalization برای request/DB/config اضافه کنیم: DTO یا value normalizer برای IP/userAgent/email/phone/deviceInfo/content/search.
3. بعد core typing را اصلاح کنیم: `Application::make`, `Cache::getInstance`, `EventDispatcher::getInstance`, `QueryBuilder::increment` و shapeهای QueryBuilder.
4. سپس PSR-4/autoload warnings را تمیز کنیم چون CI و تست‌ها را ناپایدار می‌کند.
5. در نهایت ignoreErrors را مرحله‌ای کم کنیم و baseline واقعی بسازیم.

## 8) فایل‌های خروجی تولیدشده

- `analysis-results/phpstan-summary.md` — همین گزارش.
- `analysis-results/phpstan_full_errors.csv` — لیست کامل 137 خطای strict/full.
- `analysis-results/phpstan_no_ignore_errors.csv` — لیست کامل 7169 finding خام.
- `analysis-results/phpstan-main.table.log`
- `analysis-results/phpstan_check.table.log`
- `analysis-results/phpstan_core.table.log`
- `analysis-results/phpstan_full.table.log`
- `analysis-results/smoke-*.txt` — نتایج curlهای smoke-test.

## Appendix A — لیست کامل 137 خطای `phpstan_full.neon`

| File | Line | Identifier | Message |
|---|---:|---|---|
| `app/Services/AdminDashboard/DashboardQueryService.php` | 179 | `argument.type` | Parameter #2 $token of method App\Services\DistributedLockService::release() expects string, mixed given. |
| `app/Services/AntiFraud/RiskPolicyService.php` | 51 | `argument.type` | Parameter #2 $type of method App\Services\AntiFraud\RiskPolicyService::castValue() expects string, mixed given. |
| `app/Services/AntiFraud/RiskPolicyService.php` | 180 | `return.type` | Anonymous function should return non-empty-string but returns non-empty-string\|false. |
| `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php` | 68 | `argument.type` | Parameter #2 $ip of method App\Services\AntiFraud\AccountTakeoverService::detect() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php` | 68 | `argument.type` | Parameter #3 $userAgent of method App\Services\AntiFraud\AccountTakeoverService::detect() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php` | 71 | `argument.type` | Parameter #1 $ip of method App\Services\AntiFraud\IPQualityService::check() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php` | 77 | `argument.type` | Parameter #1 $deviceInfo of method App\Services\AntiFraud\DeviceIntelligenceService::comprehensiveAnalysis() expects array, mixed given. |
| `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php` | 82 | `argument.type` | Parameter #1 $email of method App\Services\AntiFraud\EmailPhoneIntelligenceService::analyzeEmail() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php` | 85 | `argument.type` | Parameter #1 $phone of method App\Services\AntiFraud\EmailPhoneIntelligenceService::analyzePhone() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php` | 89 | `argument.type` | Parameter #2 $ip of method App\Services\AntiFraud\GeolocationIntelligenceService::analyze() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 77 | `argument.type` | Parameter #2 $ip of method App\Services\AntiFraud\GeolocationIntelligenceService::analyze() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 79 | `argument.type` | Parameter #2 $ip of method App\Services\AntiFraud\AccountTakeoverService::detect() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 79 | `argument.type` | Parameter #3 $userAgent of method App\Services\AntiFraud\AccountTakeoverService::detect() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 86 | `argument.type` | Parameter #2 $ip of method App\Services\AntiFraud\GeolocationIntelligenceService::analyze() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 88 | `argument.type` | Parameter #2 $ip of method App\Services\AntiFraud\AccountTakeoverService::detect() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 88 | `argument.type` | Parameter #3 $userAgent of method App\Services\AntiFraud\AccountTakeoverService::detect() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 99 | `argument.type` | Parameter #1 $deviceInfo of method App\Services\AntiFraud\DeviceIntelligenceService::comprehensiveAnalysis() expects array, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 118 | `argument.type` | Parameter #2 $ip of method App\Services\AntiFraud\GeolocationIntelligenceService::analyze() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 119 | `argument.type` | Parameter #2 $ip of method App\Services\AntiFraud\AccountTakeoverService::detect() expects string, mixed given. |
| `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php` | 119 | `argument.type` | Parameter #3 $userAgent of method App\Services\AntiFraud\AccountTakeoverService::detect() expects string, mixed given. |
| `app/Services/AntiFraud/VideoFingerprintService.php` | 86 | `encapsedStringPart.nonString` | Part $fingerprint['combined_hash'] (mixed) of encapsed string cannot be cast to string. |
| `app/Services/Auth/AuthService.php` | 176 | `method.notFound` | Call to an undefined method App\Services\EmailService::sendAccountLockedAlert(). |
| `app/Services/Auth/AuthService.php` | 202 | `property.nonObject` | Cannot access property $id on object\|null. |
| `app/Services/Auth/AuthService.php` | 203 | `property.nonObject` | Cannot access property $id on object\|null. |
| `app/Services/Auth/AuthSessionManager.php` | 93 | `argument.type` | Parameter #5 $acceptLanguage of method App\Services\Auth\SessionService::recordSession() expects string, mixed given. |
| `app/Services/Auth/LoginRiskService.php` | 455 | `return.type` | Method App\Services\Auth\LoginRiskService::normalizeIp() should return string but returns string\|false. |
| `app/Services/Auth/SessionService.php` | 187 | `argument.type` | Parameter #2 $token of method App\Services\DistributedLockService::release() expects string, mixed given. |
| `app/Services/Auth/TwoFactorService.php` | 136 | `return.type` | Method App\Services\Auth\TwoFactorService::verifyTOTPCode() should return bool but returns null. |
| `app/Services/Auth/TwoFactorService.php` | 245 | `argument.type` | Parameter #2 $token of method App\Services\DistributedLockService::release() expects string, mixed given. |
| `app/Services/BankCardService.php` | 125 | `argument.type` | Parameter #1 $cardNumber of method App\Services\BankCardService::detectBankName() expects string, string\|null given. |
| `app/Services/BankCardService.php` | 159 | `offsetAccess.notFound` | Offset 1 does not exist on array\|null. |
| `app/Services/BannerService.php` | 173 | `method.nonObject` | Cannot call method run() on Core\TransactionWrapper\|null. |
| `app/Services/BulkOperationsService.php` | 480 | `argument.type` | Parameter #2 $aggregateId of method App\Contracts\OutboxServiceInterface::record() expects int\|string, mixed given. |
| `app/Services/BulkOperationsService.php` | 638 | `method.notFound` | Call to an undefined method Redis::scanKeys(). |
| `app/Services/Cache/CacheInvalidationService.php` | 104 | `argument.type` | Parameter #2 $domain of method App\Services\Cache\CacheInvalidationService::invalidateScore() expects string, mixed given. |
| `app/Services/Cache/CacheInvalidationService.php` | 117 | `argument.type` | Parameter #1 $module of method App\Services\Cache\CacheInvalidationService::invalidateModuleSearch() expects string, mixed given. |
| `app/Services/ContentService.php` | 119 | `argument.type` | Parameter #1 $platform of method App\Services\ContentService::isValidPlatform() expects string, mixed given. |
| `app/Services/ContentService.php` | 124 | `argument.type` | Parameter #1 $url of method App\Services\ContentService::sanitizeUrl() expects string, mixed given. |
| `app/Services/ContentService.php` | 125 | `argument.type` | Parameter #2 $platform of method App\Services\ContentService::validateVideoUrl() expects string, mixed given. |
| `app/Services/ContentService.php` | 128 | `argument.type` | Parameter #2 ...$values of function sprintf expects bool\|float\|int\|string\|null, mixed given. |
| `app/Services/ContentService.php` | 160 | `argument.type` | Parameter #2 $aggregateId of method App\Contracts\OutboxServiceInterface::record() expects int\|string, mixed given. |
| `app/Services/ContentService.php` | 408 | `argument.type` | Parameter #1 $period of method App\Services\ContentService::validatePeriod() expects string, mixed given. |
| `app/Services/ContentService.php` | 570 | `method.nonObject` | Cannot call method deposit() on App\Contracts\WalletServiceInterface\|null. |
| `app/Services/ContentService.php` | 841 | `argument.type` | Parameter #1 $text of method App\Services\ContentService::sanitizeText() expects string, mixed given. |
| `app/Services/ContentService.php` | 842 | `argument.type` | Parameter #1 $text of method App\Services\ContentService::sanitizeText() expects string, mixed given. |
| `app/Services/ContentService.php` | 843 | `argument.type` | Parameter #1 $text of method App\Services\ContentService::sanitizeText() expects string, mixed given. |
| `app/Services/CryptoDeposit/CryptoDepositService.php` | 65 | `property.onlyRead` | Property App\Services\CryptoDeposit\CryptoDepositService::$container is never written, only read. |
| `app/Services/CryptoDeposit/CryptoDepositService.php` | 382 | `argument.type` | Parameter #3 $reason of method App\Services\CryptoDeposit\CryptoDepositService::reject() expects string, mixed given. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 55 | `property.onlyRead` | Property App\Services\CustomTask\AdminCustomTaskService::$container is never written, only read. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 133 | `method.nonObject` | Cannot call method record() on App\Contracts\OutboxServiceInterface\|null. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 210 | `method.nonObject` | Cannot call method record() on App\Contracts\OutboxServiceInterface\|null. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 494 | `nullCoalesce.offset` | Offset 'remaining_budget' on *NEVER* on left side of ?? always exists and is not nullable. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 499 | `nullCoalesce.offset` | Offset 'site_commission…' on *NEVER* on left side of ?? always exists and is not nullable. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 501 | `nullCoalesce.offset` | Offset 'currency' on *NEVER* on left side of ?? always exists and is not nullable. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 503 | `nullCoalesce.offset` | Offset 'id' on *NEVER* on left side of ?? always exists and is not nullable. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 521 | `method.nonObject` | Cannot call method record() on App\Contracts\OutboxServiceInterface\|null. |
| `app/Services/CustomTask/AdminCustomTaskService.php` | 535 | `nullCoalesce.offset` | Offset 'id' on *NEVER* on left side of ?? always exists and is not nullable. |
| `app/Services/CustomTask/CustomTaskExecutorService.php` | 39 | `property.onlyRead` | Property App\Services\CustomTask\CustomTaskExecutorService::$container is never written, only read. |
| `app/Services/CustomTask/CustomTaskExecutorService.php` | 89 | `method.nonObject` | Cannot call method synchronized() on App\Services\DistributedLockService\|null. |
| `app/Services/CustomTask/CustomTaskModerationService.php` | 41 | `property.onlyRead` | Property App\Services\CustomTask\CustomTaskModerationService::$container is never written, only read. |
| `app/Services/CustomTask/CustomTaskModerationService.php` | 152 | `method.nonObject` | Cannot call method deposit() on App\Contracts\WalletServiceInterface\|null. |
| `app/Services/CustomTask/CustomTaskService.php` | 51 | `property.onlyRead` | Property App\Services\CustomTask\CustomTaskService::$container is never written, only read. |
| `app/Services/CustomTask/CustomTaskService.php` | 179 | `method.notFound` | Call to an undefined method App\Services\Interaction\RatingService::getRatingsByRef(). |
| `app/Services/DirectMessageCommandService.php` | 368 | `argument.type` | Parameter #1 $text of method App\Services\DirectMessageCommandService::convertToEnglishDigits() expects string, string\|null given. |
| `app/Services/DistributedLockService.php` | 448 | `argument.type` | Parameter #2 $token of method App\Services\DistributedLockService::release() expects string, mixed given. |
| `app/Services/DlqWorker.php` | 32 | `property.onlyRead` | Property App\Services\DlqWorker::$container is never written, only read. |
| `app/Services/EmailDeliveryStore.php` | 333 | `argument.type` | Parameter #1 $payload of method App\Services\EmailDeliveryStore::saveToDatabase() expects array, mixed given. |
| `app/Services/EmailService.php` | 322 | `return.type` | Method App\Services\EmailService::sendVerificationEmail() should return bool but returns null. |
| `app/Services/EmailService.php` | 426 | `return.type` | Method App\Services\EmailService::sendPasswordResetEmail() should return bool but returns null. |
| `app/Services/EmailService.php` | 604 | `return.type` | Anonymous function should return string but returns string\|false. |
| `app/Services/ExportService.php` | 66 | `argument.type` | Parameter #1 $row of method App\Services\ExportService::maskSensitiveData() expects array, mixed given. |
| `app/Services/ExportService.php` | 68 | `argument.type` | Parameter #1 $row of method App\Services\ExportService::sanitizeRowForCsv() expects array, mixed given. |
| `app/Services/FeatureFlagService.php` | 410 | `argument.type` | Parameter #2 $definition of method App\Services\FeatureFlagService::makeFeatureObjectFromConfig() expects array, array\|null given. |
| `app/Services/Influencer/InfluencerCommandService.php` | 125 | `method.nonObject` | Cannot call method record() on App\Contracts\OutboxServiceInterface\|null. |
| `app/Services/Influencer/InfluencerCommandService.php` | 295 | `method.nonObject` | Cannot call method record() on App\Contracts\OutboxServiceInterface\|null. |
| `app/Services/Influencer/InfluencerCommandService.php` | 337 | `method.nonObject` | Cannot call method record() on App\Contracts\OutboxServiceInterface\|null. |
| `app/Services/Influencer/InfluencerCommandService.php` | 352 | `method.nonObject` | Cannot call method record() on App\Contracts\OutboxServiceInterface\|null. |
| `app/Services/Interaction/ReportService.php` | 60 | `argument.type` | Parameter #6 $metaJson of method App\Models\InteractionModel::createReport() expects string, string\|false given. |
| `app/Services/KYC/KYCQueryService.php` | 238 | `nullCoalesce.offset` | Offset 'status' on *NEVER* on left side of ?? always exists and is not nullable. |
| `app/Services/KYC/KYCQueryService.php` | 239 | `nullCoalesce.offset` | Offset 'count' on *NEVER* on left side of ?? always exists and is not nullable. |
| `app/Services/MigrationService.php` | 390 | `property.nonObject` | Cannot access property $max_batch on object\|null. |
| `app/Services/OutboxPublisher.php` | 164 | `argument.type` | Parameter #1 $notification of method App\Services\OutboxPublisher::publishNotification() expects array, mixed given. |
| `app/Services/Payment/DgPayGateway.php` | 113 | `encapsedStringPart.nonString` | Part $result['token'] (mixed) of encapsed string cannot be cast to string. |
| `app/Services/QueueWorker.php` | 38 | `property.onlyRead` | Property App\Services\QueueWorker::$container is never written, only read. |
| `app/Services/Score/ScoreCommandService.php` | 309 | `argument.type` | Parameter #2 $token of method App\Services\DistributedLockService::release() expects string, mixed given. |
| `app/Services/Search/ModuleSearchProvider.php` | 62 | `argument.type` | Parameter #2 $query of method App\Services\Search\BaseSearchProvider::logSearch() expects string, string\|false given. |
| `app/Services/Search/ModuleSearchProvider.php` | 113 | `property.private` | Access to private property $logger of parent class App\Services\Search\BaseSearchProvider. |
| `app/Services/Search/ModuleSearchProvider.php` | 118 | `property.private` | Access to private property $logger of parent class App\Services\Search\BaseSearchProvider. |
| `app/Services/Search/SearchProjectionListener.php` | 60 | `argument.type` | Parameter #2 $entityId of method App\Services\Search\SearchProjectionListener::deactivate() expects int\|string, mixed given. |
| `app/Services/Search/SearchProjectionListener.php` | 75 | `argument.type` | Parameter #2 $entityId of method App\Services\Search\SearchProjectionListener::deactivate() expects int\|string, mixed given. |
| `app/Services/Search/SearchProjectionListener.php` | 80 | `argument.type` | Parameter #2 $entityId of method App\Services\Search\SearchProjectionListener::deactivate() expects int\|string, mixed given. |
| `app/Services/Search/SearchProjectionListener.php` | 85 | `argument.type` | Parameter #2 $entityId of method App\Services\Search\SearchProjectionListener::deactivate() expects int\|string, mixed given. |
| `app/Services/Search/SearchProjectionListener.php` | 90 | `argument.type` | Parameter #2 $entityId of method App\Services\Search\SearchProjectionListener::deactivate() expects int\|string, mixed given. |
| `app/Services/Search/SearchProjectionListener.php` | 110 | `argument.type` | Parameter #2 $entityId of method App\Services\Search\SearchProjectionListener::deactivate() expects int\|string, mixed given. |
| `app/Services/Search/SearchProjectionListener.php` | 124 | `argument.type` | Parameter #2 $entityId of method App\Services\Search\SearchProjectionListener::deactivate() expects int\|string, mixed given. |
| `app/Services/Sentry/Alerting/AlertDispatcher.php` | 267 | `argument.type` | Parameter #1 $config of method App\Services\Sentry\Alerting\AlertDispatcher::sendTelegram() expects array, mixed given. |
| `app/Services/Sentry/Alerting/AlertDispatcher.php` | 268 | `argument.type` | Parameter #1 $config of method App\Services\Sentry\Alerting\AlertDispatcher::sendEmail() expects array, mixed given. |
| `app/Services/Sentry/Alerting/AlertDispatcher.php` | 269 | `argument.type` | Parameter #1 $config of method App\Services\Sentry\Alerting\AlertDispatcher::sendSlack() expects array, mixed given. |
| `app/Services/Sentry/Alerting/AlertDispatcher.php` | 270 | `argument.type` | Parameter #1 $config of method App\Services\Sentry\Alerting\AlertDispatcher::sendWebhook() expects array, mixed given. |
| `app/Services/Sentry/Alerting/AlertRulesEngine.php` | 74 | `argument.type` | Parameter #1 $metric of method App\Services\Sentry\Alerting\AlertRulesEngine::getMetricValue() expects string, mixed given. |
| `app/Services/Sentry/Alerting/AlertRulesEngine.php` | 76 | `argument.type` | Parameter #2 $operator of method App\Services\Sentry\Alerting\AlertRulesEngine::compareValues() expects string, mixed given. |
| `app/Services/Sentry/Audit/AdvancedAuditTrail.php` | 290 | `argument.type` | Parameter #1 $old of method App\Services\Sentry\Audit\AdvancedAuditTrail::arrayDiff() expects array, mixed given. |
| `app/Services/Sentry/Audit/AdvancedAuditTrail.php` | 290 | `argument.type` | Parameter #2 $new of method App\Services\Sentry\Audit\AdvancedAuditTrail::arrayDiff() expects array, mixed given. |
| `app/Services/Sentry/ErrorMonitoring/SentryErrorMonitor.php` | 47 | `property.onlyRead` | Property App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::$container is never written, only read. |
| `app/Services/SocialTask/SilentAntiFraudService.php` | 42 | `property.onlyRead` | Property App\Services\SocialTask\SilentAntiFraudService::$container is never written, only read. |
| `app/Services/SocialTask/SilentAntiFraudService.php` | 165 | `argument.type` | Parameter #2 ...$arrays of function array_merge expects array, mixed given. |
| `app/Services/User/AccountDeletionService.php` | 112 | `nullCoalesce.offset` | Offset int on array{} on left side of ?? does not exist. |
| `app/Services/User/UserDashboardService.php` | 189 | `nullCoalesce.offset` | Offset non-falsy-string on array{} on left side of ?? does not exist. |
| `app/Services/User/UserService.php` | 281 | `method.notFound` | Call to an undefined method App\Services\User\UserService::getTransactionWrapper(). |
| `app/Services/WebSocketService.php` | 471 | `empty.variable` | Variable $messages in empty() always exists and is always falsy. |
| `app/Services/WebSocketService.php` | 753 | `argument.type` | Parameter #5 ...$options of method Core\Redis::scan() expects string, int given. |
| `app/Services/WebSocketService.php` | 767 | `argument.type` | Parameter #5 ...$options of method Core\Redis::scan() expects string, int given. |
| `app/Services/Withdrawal/WithdrawalAdminService.php` | 299 | `nullCoalesce.offset` | Offset 'user_id' on array on left side of ?? always exists and is not nullable. |
| `app/Services/Withdrawal/WithdrawalAdminService.php` | 302 | `nullCoalesce.offset` | Offset 'user_id' on array on left side of ?? always exists and is not nullable. |
| `app/Services/Withdrawal/WithdrawalAdminService.php` | 321 | `nullCoalesce.offset` | Offset 'user_id' on array on left side of ?? always exists and is not nullable. |
| `app/Services/Withdrawal/WithdrawalAdminService.php` | 324 | `nullCoalesce.offset` | Offset 'user_id' on array on left side of ?? always exists and is not nullable. |
| `app/Services/Withdrawal/WithdrawalUserService.php` | 247 | `property.nonObject` | Cannot access property $id on object\|null. |
| `app/Services/Withdrawal/WithdrawalUserService.php` | 251 | `property.nonObject` | Cannot access property $id on object\|null. |
| `app/Services/Withdrawal/WithdrawalUserService.php` | 258 | `property.nonObject` | Cannot access property $id on object\|null. |
| `core/Application.php` | 67 | `return.type` | Method Core\Application::make() should return T of object but returns object. |
| `core/Cache.php` | 58 | `return.type` | Method Core\Cache::getInstance() should return static(Core\Cache) but returns Core\Cache. |
| `core/Cache.php` | 61 | `assign.propertyType` | Static property Core\Cache::$instance (Core\Cache\|null) does not accept object. |
| `core/Cache.php` | 66 | `return.type` | Method Core\Cache::getInstance() should return static(Core\Cache) but returns object. |
| `core/EventDispatcher.php` | 18 | `property.onlyRead` | Property Core\EventDispatcher::$container is never written, only read. |
| `core/EventDispatcher.php` | 50 | `assign.propertyType` | Static property Core\EventDispatcher::$instance (Core\EventDispatcher\|null) does not accept object. |
| `core/EventDispatcher.php` | 55 | `assign.propertyType` | Static property Core\EventDispatcher::$instance (Core\EventDispatcher\|null) does not accept object. |
| `core/EventDispatcher.php` | 59 | `return.type` | Method Core\EventDispatcher::getInstance() should return Core\EventDispatcher but returns object. |
| `core/EventDispatcher.php` | 500 | `return.type` | Method Core\EventDispatcher::reconstructEvent() should return Core\Event\|null but returns object. |
| `core/QueryBuilder.php` | 84 | `function.impossibleType` | Call to function is_array() with string will always evaluate to false. |
| `core/QueryBuilder.php` | 711 | `function.impossibleType` | Call to function is_array() with string will always evaluate to false. |
| `core/QueryBuilder.php` | 762 | `return.type` | Method Core\QueryBuilder::increment() should return int but returns bool. |
| `core/QueryBuilder.php` | 925 | `nullCoalesce.offset` | Offset string on *NEVER* on left side of ?? always exists and is not nullable. |
| `core/QueryBuilder.php` | 1211 | `encapsedStringPart.nonString` | Part $join['first'] (mixed) of encapsed string cannot be cast to string. |
| `core/QueryBuilder.php` | 1211 | `encapsedStringPart.nonString` | Part $join['operator'] (mixed) of encapsed string cannot be cast to string. |
| `core/QueryBuilder.php` | 1211 | `encapsedStringPart.nonString` | Part $join['second'] (mixed) of encapsed string cannot be cast to string. |
| `core/QueryBuilder.php` | 1211 | `encapsedStringPart.nonString` | Part $join['type'] (mixed) of encapsed string cannot be cast to string. |
| `core/QueryBuilder.php` | 1299 | `encapsedStringPart.nonString` | Part $condition['type'] (mixed) of encapsed string cannot be cast to string. |
