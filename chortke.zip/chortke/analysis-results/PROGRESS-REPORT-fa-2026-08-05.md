# گزارش پیشرفت PHPStan Level 9 — ۲۰۲۶-۰۸-۰۵

## خلاصهی کل
| معیار | شروع | اکنون | رفعشده | مانده |
|---|---|---|---|---|
| **کل خطاها** | ۴۴۱۹ | **۴۰۷۲** | ۳۴۷ | ۴۰۷۲ |
| no-value-type | ۱۷۲۹ | **۰** | ۱۷۲۹ | ۰ ✅ |
| cast-mixed (int/string/float) | ۱۴۱۸ | **۱۱۶۳** | ۲۵۵ | ۱۱۶۳ |
| undefined-property | ۱۸۰ | **۰** | ۱۸۰ | ۰ ✅ |
| undefined-method | (چند) | **۰** | — | ۰ ✅ |

**PHPUnit:** ۲۳۹۶ تست / ۴۹۷۱ assertion / ۰ شکست / ۵ skip محیطی

---

## ۱) چقدر رفع شد — دستهبندی

### کاملاً صفرشده ✅
- **no-value-type**: ۱۷۲۹ → ۰ (دستهی تکمیلشده در جلسات قبل؛ شامل تلفیق docblockهای انباشته در ~۳۵ فایل Job + core).
- **undefined-property**: ۱۸۰ → ۰
- **undefined-method / should-be-compatible**: ۰

### در حال انجام (cast-mixed)
- **cast-mixed**: ۱۴۱۸ → **۱۱۶۳** (−۲۵۵، یعنی ~۱۸٪ از دسته)
  - to int: ۷۲۱ → **۶۰۲**
  - to string: ۵۳۵ → **۴۲۸**
  - to float: ۱۶۲ → **۱۳۳**

### دستههای بزرگِ باقیمانده (هنوز شروع نشده)
| دسته | تعداد | وضعیت |
|---|---|---|
| type-mismatch/expects | ۱۰۲۶ | جدا |
| cannot-access | ۵۰۳ | جدا |
| return-type-mismatch | ۳۰۱ | جدا |
| never-read-property | ۱۷۴ | جدا |
| no-return-type | ۱۷۱ | جدا |
| always-true | ۱۳۹ | جدا |
| unreachable | ۱۰۵ | جدا |
| encapsed-string | ۸۴ | جدا |
| unused | ۷۷ | جدا |

---

## ۲) چطور رفع شد — الگوهای تثبیتشده

### الف) دستهی no-value-type
- **تکمیل PHPDoc** با انواع دقیق از بدنه: `fetchAll(FETCH_OBJ)` → `list<\stdClass>`، `fetchAll(FETCH_ASSOC)` → `list<array<string,mixed>>`، aggregate → `array<string,mixed>`، `list<int>`/`list<string>` برای آرایههای اتمی.
- **رفع docblockهای انباشته (Stacked):** اسکریپت قدیمی docblock را بالای قبلی درج کرده بود؛ PHPStan فقط docblockِ بلاواسطهی قبل از متد را میخواند، پس `@return` نادیده گرفته میشد. همه به یک docblock چندخطی تلفیف شد.
- **باگهای واقعی کشفشده:** چند `create()` که override والد (`int|false`) بودند و آبجکت برمیگرداندند → rename به نام دامنهای؛ و `toObject(fetchColumn())` که رشته را stdClass میکرد → مقایسهی مستقیم.

### ب) دستهی cast-mixed (جاری)
**استراتژی: تبدیل در مرز شکلگیری داده (قانون ۱-۵)** — بهجای cast کور در هر محل مصرف:

1. **متدهای امن به `Core\Request`:** `str()`, `int()`, `float()` با `is_scalar`/`is_numeric` guard.
   - `(string)$request->get('x')` → `$request->str('x')`
   - `(int)$request->get('id')` → `$request->int('id')`
2. **متدهای امن به `Core\Validator`:** `$validator->int('x')` برای دادهی اعتبارسنجیشده (چون `Validator` تبدیل نمیکند، فقط اعتبارسنجی میکند و `data()` همچنان `array<string,mixed>` است).
3. **توابع سراسری امن:** `str_value`, `int_value`, `float_value` در `helpers/functions.php` برای منابع واقعاً `mixed` (config، session، json_decode، fetchAll، property های stdClass).
4. **الگوی null-safe:** `user_id ? (int)$req->get('user_id') : null` → `$req->int('user_id') ?: null`.

**فایلهای تمیزشده (cast-mixed):** AuthController، LevelController، AdsController، CustomTaskController، SocialTaskController، ContentController، SeoController، NotificationController، VitrineController، InfluencerController، FraudManagementController، PredictionController، LogController + خودِ `Core\Request`, `Core\Validator`, `helpers/functions.php`.

**بازبینی/تصحیح (جواب به نگرانی نرمالیزه):** مشخص شد `int_value($data['x'])` روی `Validator::data()` نرمالیزه نیست (چون Validator تبدیل نمیکند و مقدار واقعاً mixed است)؛ برای پیروی بهتر از قانون ۱-۵، متدهای `int/float/str` به خود Validator اضافه و LevelController به آنها مهاجرت کرد.

---

## ۳) چقدر مانده — گام بعدی
- ادامهی **cast-mixed (۱۱۶۳)**: فایلهای بعدی Controller (TwoFactorController، OAuthController، Api/UserController، CouponController، Admin/AuthController) سپس Models/Services/Jobs/core که از fetchAll و بازگشتِ mixed تغذیه میشوند.
- سپس دستههای جداگانه: **type-mismatch (۱۰۲۶)**، **cannot-access (۵۰۳)**, return-type-mismatch، never-read، no-return-type و بقیه.

## جزئیات فایلبهفایل
فایلهای کاملِ تفصیلی: `ERRORS-DETAILED-fa.md` (خطبهخط) و `ERRORS-DETAILED-fa.csv` (جدولی).
