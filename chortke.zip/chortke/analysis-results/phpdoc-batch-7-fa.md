# تکمیل تایپداک — دسته هفتم (گزارش فارسی)

## رویکرد
ادامهی تدریجی + اجرای تست PHPUnit بعد از هر اصلاح.

## فایل تمیزشده
### app/Services/ExportService.php (۱۶ مورد no-value-type + ~۳۰ خطای پنهان)
- exportCsvStream/exportCsv: list<string> $headers
- maskSensitiveData/sanitizeRowForCsv: array<string,mixed>
- prepareUsersExport/prepareTransactionsExport: array{filters} → array{headers, rows}
- cast های $filters با is_scalar/is_numeric امن شد
- fputcsv: مقادیر با json_encode برای مقادیر غیرscalar امن شد

## تأیید
- تست DataExportServiceTest → OK (5 tests)
- php -l → OK
- بدون ignoreErrors جدید، بدون DTO، بدون فایل سورس جدید

## عدد
- کل خطاها: ۵۹۸۶ → ۵۹۷۳
- no-value-type: ۱۸۳۲ → ۱۸۱۶
- از ۷۰۲۲ اولیه: حذف ۱۰۴۹ خطا
