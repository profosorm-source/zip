# گزارش اصلاحات — Batch: اِعمال قواعد مرجع + InfluencerController و مدلهای مرتبط

## فایل مرجع قوانین
- ساخته شد: `RULES-AND-STANDARDS-fa.md` در ریشهی پروژه — تمام قواعدِ کاربر در یک فایل جمع شد و بهعنوان مرجعِ الزامآور برای هر اصلاح.

## اصلاحات این مرحله (همه دستی با ویرایشگر، بدون Python)
تمرکز: `app/Controllers/Api/InfluencerController.php` (۶۸ خطا → ۰) و رفعِ ریشهایِ ریشهها.

### ۱. نوع بازگشتی مدلها (مرزِ شکلگیری داده) — `?object` → `?\stdClass`
- `app/Models/InfluencerModel.php`: `findProfileForUpdate`، `findByUserId`، `findProfileByUserId`، `findProfileOwnedByUser`، `getProfileByUserSafe`، `findPendingVerificationByProfile`، `findVerificationById`، `findVerificationByIdForUpdate`، `findSubmittedVerificationByProfile`، `findLatestVerificationByProfile`.
- `app/Models/StoryOrder.php`: `find`، و `@return list<\stdClass>` برای `getByCustomer`/`getByInfluencer`/`adminList`.
- `app/Models/Dispute.php`: `find`، `findByRef`، `findByOrderId`، `getSafe`، `findDetailWithSubmission`، `objectOrNull`، و `@return list<\stdClass>` برای `getByUser`/`getMessages`/`adminList`.
- `app/Services/InfluencerService.php`: `getProfileByUserId`/`getProfileById` → `?\stdClass`.

### ۲. مرزِ ورودی HTTP — `Request::param()` → `?string`
مسیرهای route همیشه رشته هستند؛ خروجیِ `param()` با guard مقدارِ غیررشتهای به default میافتد.

### ۳. shape دقیقِ بازگشتیِ command services (رفع `$result['message']`/`$result['profile']` در محل مصرف)
- `InfluencerCommandService`: `registerInfluencer`، `createOrder`، `respondToOrder`، `submitProof`، `buyerConfirm`، `buyerDispute`، `completeOrder` → `array{success: bool, message: string, ...}`.
- `InfluencerService` (facade) هماهنگ شد؛ `createOrder` قبل از return موفقیت، null بودنِ `$order` را تضمین میکند.

### ۴. رفع override ناسازگار `create()` (الگوی تثبیتشده)
- `Dispute::create` → `createDispute`؛ `StoryOrder::create` → `createStoryOrder` (چون قراردادِ والد `int|false` را نقض میکردند). Callers بهروزرسانی شدند.

### ۵. باگ واقعیِ آشکارشده در `User/InfluencerController`
تایپِ دقیقترِ `findByUserId`، null-dereference واقعی را در `submitVerificationProof` آشکار کرد → guard اضافه شد.

## تأیید
- `php -l` روی همه فایلهای تغییر یافته: OK.
- PHPStan لول-۹ بدون ignore: `app/Controllers/Api/InfluencerController.php` → ۰ خطا.
- کل پروژه: **۵۸۶۴ → ۵۷۰۷** (کاهش ۱۵۷؛ no-value-type: ۱۷۶۴ → ۱۷۵۴). بدون رگرسیونِ جدید (فقط خطاهای نویزِ pre-existing که در فایلهای جداگانه نگهداری میشوند).
- تستها: همه تستهای مرتبط پاس؛ تست جدید `StoryOrderModelTest` (۱۳ تست، ۱۹۰ assertion) و کل `tests/Unit/Services` (۸۷۷ تست) سبز.

## تست جدید
- `tests/Unit/Services/StoryOrderModelTest.php` — قراردادِ statusLabels/statusClasses، فرمت/یکتایی `generateVerificationCode`، رفتار `find`، موفقیت/شکست `createStoryOrder`، لیستها، شمارندهها، و **قرارداد امنیتی whitelist در `update`** (جلوگیری از column injection).
