# تکمیل تایپداک — دسته ششم (گزارش فارسی)

## رویکرد
ادامهی تدریجی + اجرای تست PHPUnit بعد از هر اصلاح (طبق نکتهی کاربر).

## فایلهای تمیزشده
### ۱. app/Services/CryptoDeposit/CryptoDepositService.php (۱۷ مورد no-value-type + ~۳۰ خطای پنهان)
- toObject → ?\stdClass
- cast های mixed با is_scalar/is_numeric
- CryptoDepositIntent/CryptoDeposit مدلها → ?\stdClass
- **باگ واقعی رفع شد**: `$deposit = $this->depositModel->create($data)` سپس `$deposit->id`
  خوانده میشد، ولی create حالا `int|false` برمیگرداند → `$deposit` int بود و `->id` روی
  int میخواند. با اصلاح Model::create → int|false آشکار شد و به `$depositId` اصلاح شد.

### ۲. app/Services/Sentry/Audit/AdvancedAuditTrail.php (۱۶ مورد no-value-type + ~۲۵ خطای پنهان)
- $config → array<string,mixed>
- getActivityTimeline/getCriticalEvents → list<\stdClass>
- intval/cast های mixed امن شد
- getAuditRecordById (SentryModel) → ?\stdClass

## تأیید (طبق نکتهی کاربر: تست بعد از هر اصلاح)
- تست CryptoDepositServiceTest → OK (3 tests)
- php -l همه فایلها → OK
- بدون ignoreErrors جدید، بدون DTO، بدون فایل سورس جدید

## عدد
- کل خطاها: ۶۰۴۹ → ۵۹۸۶ (زیر ۶۰۰۰!)
- no-value-type: ۱۸۶۵ → ۱۸۳۲
- از ۷۰۲۲ اولیه: حذف ۱۰۳۶ خطا
