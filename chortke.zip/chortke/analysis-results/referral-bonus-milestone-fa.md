# گزارش — تکمیل سیستم رفرال (بونوس + میلستون)

## تحلیل اولیه (که بخش مرجع به آن اشاره کرد)
- `checkAndAwardBonus` از `processCommission` (درصدی) استفاده می‌کرد → با «بونوس ثابت» ناسازگار بود.
- `checkAndAwardMilestones` فقط `SELECT * FROM referral_milestones` را برمی‌گرداند و هیچ منطق چک/اهدایی نداشت.
- `getUserAchievedMilestones` همه‌ی میلستون‌های فعال را برمی‌گرداند (اشتباه).
- جدول `referral_milestones` خالی بود؛ تنظیمات referral seed نشده بودند.

## تغییرات (اصولی، با idempotency)
### migration `2026_08_03_0004_referral_milestone_tracking.sql`
- جدول `referral_user_milestones` (ردیابی دستیابی + idempotency).
- seed تنظیمات: `referral_content_approval_amount=5000`, `referral_content_approval_currency=irt`, `referral_commission_percent=5`, `referral_daily_limit=50`.
- seed ۴ میلستون: ۱/۵/۱۰/۵۰ معرف موفق با پاداش ۱۰/۲۵/۵۰/۱۵۰ هزار تومان.

### `ReferralService`
- **`checkAndAwardBonus`:** بازنویسی — بونوس ثابت کامل (نه درصد) با `depositInTransaction` + idempotency (از طریق `referral_commissions.idempotency_key`). اگر قبلاً اعطا شده، `duplicate=true` برمی‌گرداند.
- **`checkAndAwardMilestones`:** بازنویسی — میلستون‌های تازه‌رسیده را (بر اساس `countReferredUsers` ≥ threshold) شناسایی و پاداش می‌دهد؛ هر میلستون فقط یک‌بار (از طریق `referral_user_milestones`).
- **`getUserAchievedMilestones`:** رفع — فقط میلستون‌های واقعاً دست‌یافته را برمی‌گرداند.

## تأیید
- PHPStan لول-۹ بدون ignore: **۵۶۹۶** (بدون رگرسیون؛ متدهای جدید صفر خطا)
- PHPUnit: **۲۳۲۳ تست، ۰ شکست** (۵ skip محیطی) + ۴ تست جدید `ReferralBonusMilestoneTest`
- تست زنده:
  - `checkAndAwardBonus` → success=true, commission=5000 (بونوس کامل)، فراخوانی دوم duplicate=1
  - `checkAndAwardMilestones` با ۳ معرف → میلستون threshold=1 اهدا شد؛ فراخوانی دوم awarded_count=0 (idempotent)
- نکته: مشکل قبلی «پیکربندی نشده» به‌دلیل کش تنظیمات بود؛ پس از seed و پاک‌کردن کش (یا با کش جدید) برطرف می‌شود.
