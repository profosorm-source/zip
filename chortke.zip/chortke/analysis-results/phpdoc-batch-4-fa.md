# تکمیل تایپداک — دسته چهارم (گزارش فارسی)

## رویکرد
ادامهی تدریجی. تمیزکاری کامل چند فایل ایزوله + پیشرفت در BannerService.

## فایلهای کاملاً تمیزشده
### ۱. app/Services/SocialAccountService.php (۱۶ مورد no-value-type + ~۴۳ خطای پنهان)
- toObject → ?\stdClass (با @var) تا property های stdClass شناخته شوند
- normalizeAccountData: cast ها با is_scalar/is_numeric امن شد
- intval/floatval($data['x']) → با is_numeric امن شد
- register/verify/reject/updateByUser/... → array<string,mixed> و list<self>/list<\stdClass>

### ۲. app/SDK/FeatureFlagSDK.php (۲۳ مورد no-value-type + ۱۲ خطای پنهان)
- $context property → array<string,mixed>
- variant()/getMetadata() → cast امن
- FeatureFlagService::getAll → list<\stdClass>، findByName → ?\stdClass

### ۳. دایرکتوری app/Enums (۷ مورد) — کاملاً صفر
- ScoreDomain/TicketPriority/TicketStatus/TransactionStatus/UserStatus → list<string>

### ۴. app/Services/BannerService.php (۲۴ مورد no-value-type رفع شد؛ ۳۳ خطای پنهان در حال انجام)

## تأیید
- php -l: همه فایلها OK
- PHPStan بدون-ignore: SocialAccountService، FeatureFlagSDK، app/Enums → ۰ خطا
- تست SocialAccountService: OK
- بدون ignoreErrors جدید، بدون DTO، بدون فایل سورس جدید

## عدد
- کل خطاها: ۶۱۷۳ → ۶۰۹۰ (کاهش ۸۳ در این نوبت)
- no-value-type: ۲۰۴۱ → ۱۹۷۱ (زیر ۲۰۰۰)
- از ۷۰۲۲ اولیه: حذف ۹۳۲ خطا
