# تکمیل تایپداک + ساخت تست حرفهای — دسته یازدهم (گزارش فارسی)

## رویکرد
ادامهی تدریجی + رعایت مرزها + ساخت تست حرفهای (رفتار/لبه/قرارداد، نه فقط کارکرد).

## فایل تمیزشده
### app/Services/Influencer/InfluencerCommandService.php (۱۷+ مورد no-value-type + ~۳۰ خطای پنهان)
- toObject → ?\stdClass
- docblock های array<string,mixed> / list
- **باگ واقعی ریشهای**: `$profileModel->create(...)` که از Model::create (int|false) میآمد ولی
  `$profile->id` خوانده میشد → به `createProfile()` (که ?\stdClass برمیگرداند) اصلاح شد.
- **بوی کد ریشهای**: `influencer_min_followers` دو بار get میشد → یک بار خوانده و بازاستفاده شد.
- StoryOrder/BatchLoader/InfluencerModel → ?\stdClass / list<\stdClass>
- refundCustomer(?\stdClass)

## تست جدید ساختهشده (حرفهای)
- **InfluencerCommandServiceTest** (5 تست): feature disabled، duplicate profile، low followers،
  موفق + قرارداد outbox-event (بررسی aggregateType/aggregateId/eventType/payload)، throw وقتی outbox missing.
  → همه پاس

## تأیید
- تست InfluencerCommandServiceTest → OK (5 tests, 11 assertions)
- php -l → OK
- بدون ignoreErrors جدید، بدون DTO

## عدد
- کل خطاها: ۵۹۳۲ → ۵۸۶۴ (کاهش ۶۸ — باگهای مدل هم اصلاح شد)
- no-value-type: ۱۷۸۰ → ۱۷۶۴
- از ۷۰۲۲ اولیه: حذف ۱۱۵۸ خطا
