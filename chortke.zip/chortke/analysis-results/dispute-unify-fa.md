# گزارش — یکپارچه‌سازی Dispute بر اساس تصمیم کاربر

## پیش‌زمینه (بررسی)
چند مکانیزم موازی dispute در پروژه وجود داشت:
- `disputes` (DisputeService) — اینفلوئنسر + تسک سفارشی (کامل، polymorphic)
- `task_disputes` — وظیفه اجتماعی (فقط open+list، بدون resolve)
- `vitrine_disputes` — ویترین (جدا؛ عملاً خالی/مرده)
- ویترین escrow-based جدا

## تصمیم کاربر
- **SocialTask:** مکانیزم چرخش خودکار است (یا انجام می‌شود یا رد)؛ بخش داوری اعتراض ندارد → **کل بخش dispute آن حذف و تمیز شود.**
- **Vitrine:** به سرویس مربوطه (`DisputeService`) وصل شود و چرخه کامل شود.

## اجرا

### مرحله ۱ — تمیزکاری SocialTask dispute (حذف کامل)
- `SocialTaskApiController`: حذف `openDispute()` و `disputes()` (+ docblock)
- `routes/api.php`: حذف `POST /social/executions/{id}/dispute` و `GET /social/disputes`
- `SocialTaskService`: حذف `openDispute()` و `getUserDisputes()`
- `SocialTaskModel`: حذف `openTaskDispute()`, `getUserTaskDisputes()`, `getTaskDisputeByExecution()`
- migration: حذف CREATE TABLE `task_disputes` از `2026_06_10_0042...` + migration جدید `2026_08_03_0002_remove_task_disputes.sql` (DROP) — اجرا شد، جدول حذف شد.

### مرحله ۲ — اتصال Vitrine به DisputeService + تکمیل چرخه
- `VitrineService::openDispute` → بعد از escrow/status، `DisputeService::openCase([...ref_type='vitrine_listing'...])` رکورد در جدول `disputes` می‌سازد (طرفین از listing تعیین می‌شوند).
- `VitrineService::resolveDispute` → بعد از settlement، `Dispute::resolveByRef('vitrine_listing', ...)` پرونده را `resolved_admin` می‌کند.
- `Dispute::resolveByRef()` — متد جدید idempotent برای بستن پرونده بر اساس ref_type+ref_id.

## تأیید
- PHPStan لول-۹ بدون ignore: **۵۶۹۵** (کاهش؛ بدون رگرسیون)
- PHPUnit کل: **۲۳۱۰ تست، ۰ شکست** (۵ skip محیطی) + ۳ تست جدید `DisputeResolveByRefTest`
- تست عملکردی زنده: openCase برای `vitrine_listing` → dispute در جدول `disputes` ساخته شد → resolveByRef → `resolved_admin`.
- جدول `task_disputes` حذف شد؛ هیچ ارجاع شکسته‌ای نمانده.

## نکته‌ی باز (کارِ آتی)
`DisputeService::listForAdmin()` فعلاً فقط `custom_task_submission` را فیلتر می‌کند؛ برای پنل ادمینِ واقعاً یکپارچه (نمایش همه ref_typeها) باید generalize شود.

## تست جدید
- `tests/Unit/Services/DisputeResolveByRefTest.php` (۳ تست): بستن پرونده، idempotency، صحت پارامترها.
