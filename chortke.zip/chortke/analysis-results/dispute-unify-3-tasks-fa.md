# گزارش — تکمیل ۳ وظیفه: داوری یکپارچه، پیام ویترین، حذف dead code

## ۱) داوریِ یکپارچه‌ی ادمین
- متد جدید `DisputeService::resolveForAdmin($adminId, $disputeId, $meta)` اضافه شد که بر اساس `ref_type` dispatch می‌کند:
  - اینفلوئنسر/سفارش (`order/story_order/influencer_order/influencer`) → `commandService->adminResolve` (با escrow)
  - ویترین (`vitrine_listing`) → `VitrineService::resolveDispute` (seller/buyer)
  - تسک سفارشی (default) → `resolveByAdmin` (executor/advertiser/split)
- `ExecutorTaskController::resolveDispute` حالا از `resolveForAdmin` استفاده می‌کند.
- JS پنل ادمین (`customtasks.js`) + view: اگر ref_type ویترین باشد، گزینه‌های داوری «حق با خریدار/فروشنده» نشان داده می‌شود (به‌جای executor/advertiser/split).

## ۲) پیام/مکالمه‌ی dispute ویترین
- `VitrineService` سه متد گرفت: `findListingDispute`، `sendDisputeMessage`، `getDisputeMessages` (همه از جدول یکپارچه‌ی `disputes`/`dispute_messages`).
- `VitrineController` دو اندپوینت گرفت: `GET /vitrine/{id}/dispute/messages` و `POST /vitrine/{id}/dispute/message`.
- route ها در `routes/missing.php` ثبت شدند.
- تأیید زنده: `sendDisputeMessage` → success=true، `getDisputeMessages` → count=1.

## ۳) حذف dead code
- `Dispute::hasOpenTaskDispute` (ref_type='task') — هیچ caller نداشت → حذف شد.
- `DisputeQueryService::rawCustomTaskDisputeList` / `rawCustomTaskDisputeCount` — بعد از یکپارچه‌سازی listForAdmin دیگر استفاده نمی‌شدند → حذف شدند.

## تأیید
- PHPStan لول-۹ بدون ignore: **۵۶۹۶** (بدون رگرسیون؛ متدهای جدید صفر خطا)
- PHPUnit: **۲۳۱۹ تست، ۰ شکست** (۵ skip محیطی) — شامل +۳ تست `resolveForAdmin` به `DisputeServiceTest`
- تست زنده: پیام ویترین + dispatch داوری کار کرد.

## تست‌های جدید/ارتقا
- `DisputeServiceTest`: +۳ تست برای `resolveForAdmin` (خطای dispute یافت‌نشده، validation برنده‌ی ویترین، dispatch سفارش).
