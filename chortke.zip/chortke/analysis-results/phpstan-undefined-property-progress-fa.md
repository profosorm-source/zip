# گزارش پیشرفت — رفع «undefined property object::xxx» (گام در حال انجام)

## روش
الگوی ریشهای: در مدلها، متدهای `?object` که در واقع `\stdClass` برمیگردانند (از `fetch(FETCH_OBJ)`/`first()`/`db->fetch()`) به `?\stdClass` تغییر مییابند. در سرویسها، پارامترهای `object $x` به نوع واقعی (stdClass یا User) و `toObject()` به `?\stdClass` تغییر مییابند.

## اعداد
| شاخص | شروع گام | الان |
|---|---|---|
| undefined property | ۸۵۹ | **۴۲۴** |
| PHPStan کل | ۵۶۹۸ | **۵۱۲۸** |
| PHPUnit | ۲۳۲۶ (۰ شکست) | **۲۳۲۶ (۰ شکست)** — بدون رگرسیون |

## فایلهای پاکشده در این بخش
CustomTaskModerationService, CouponService, PayRewardJob, InfluencerVerification, SocialTaskModel/ExecutionModel, SentryModel, AlertRulesEngine, Withdrawal/WithdrawalAdminService, DirectMessage/QueryService, ContentService/ContentSubmission/ContentRevenue, FeatureFlagService/Model/Interface/ApiController, UserLevel/CommandService, VitrineRequest/VitrineListing/AcceptVitrine/ReleaseVitrine/VitrineService, BankCardService, AuthService/User model, AdminCustomTaskService, PolicyService/Role.

## نکات
- تغییر `Core\Model::find` به `?\stdClass` امتحان شد ولی ۲۰+ override را میشکست → بازگردانده شد؛ راهِ درست اصلاحِ فردیِ هر مدل است.
- `UserLevel::create` و `Role::create` (override ناسازگار با parent) به `createLevel`/`createRole` تغییر نام یافتند.
- `AuthController` برای `isAdmin($user)` با `@var User` تایپ شد.
