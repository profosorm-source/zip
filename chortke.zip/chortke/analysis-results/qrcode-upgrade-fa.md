# ارتقای کتابخانه QRCode (گزارش فارسی)

## مشکل
`core/Lib/QRCode.php` یک پورت در-پروژه (vendored) از `splitbrain/php-qrcode` (MIT) بود
که دیگر نگهداری نمیشود و ۱۰۴ خطای PHPStan بدون-ignore تولید میکرد. در کانفیگهای
اصلی هم بهعنوان «کتابخانه شخص ثالث» exclude شده بود.

## راهحل (ریشهای، نه وصله)
بهجای وصلهزدن روی کتابخانه قدیمی، کتابخانه مدرن `chillerlan/php-qrcode` نسخه
6.0.1 (MIT, PHP 8.2+) از Composer نصب شد و کلاس `Core\Lib\QRCode` به یک wrapper
سبک (thin adapter) تبدیل شد که همان `svg()` را برمیگرداند.

- API سازگار: `\Core\Lib\QRCode::svg($data, $options = [])` → SVG خام
- بدون تغییر نقطه مصرف (فقط `TwoFactorController.php:376` از آن استفاده میکند)
- `outputBase64=false` → SVG خام (نه data-URI) همانند قبل
- کلاس vendor (`chillerlan\QRCode\QRCode`) با کلاس پروژه (`Core\Lib\QRCode`)
  هیچ تداخل نامی ندارد.

## تغییرات
- `composer.json`: اضافه شدن `chillerlan/php-qrcode: ^6.0`
- `core/Lib/QRCode.php`: بازنویسی به wrapper مدرن (۸۵۷ → ~۸۵ خط)
- کانفیگهای PHPStan: حذف exclude های `core/Lib` و `core/Lib/QRCode.php` از
  `phpstan.neon`، `phpstan_core.neon`، `phpstan_core_check.neon`، `phpstan_full.neon`
  (دیگر نیازی به حذف آن نیست؛ حالا واقعاً تحت پوشش است)

## نتیجه
- QRCode: ۱۰۴ → ۰ خطا
- کل خطاها: ۷۰۲۲ → ۶۶۱۹ (حذف ۴۰۳)
- همه ۵ کانفیگ PHPStan: No errors
- runtime: /health, / = 200، تولید SVG خام درست است
- TwoFactorServiceTest: OK (4 tests)
