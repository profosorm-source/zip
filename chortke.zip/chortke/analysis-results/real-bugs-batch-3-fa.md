# رفع خطاهای واقعی — دسته سوم (گزارش فارسی)

## رویکرد
ادامه از دستههای قبل؛ تمرکز بر «رفعهای معنایی واقعی» — مواردی که بازگشتیهای
PHP (resource|false، string|false، int|false) را هندل نمیکردند و میتوانستند
خطا/کرش بدهند. همه بهصورت ریشهای و بدون ignoreErrors جدید.

## موارد رفعشده

### ۱. دسته resource|false (fopen/fputcsv/fwrite/fclose/fgetcsv) — ۵۱ مورد
ریشه: `fopen()` برمیگرداند `resource|false` ولی کد بدون چک، `fputcsv/fwrite/fclose`
را روی آن صدا میزد. در فایلهای:
- AnalyticsExporter::generateCSV → چک false + return
- BulkOperationsService (exportToCSV/exportToJSON/importFromCSV) → چک false + throw
- ExportService (دو متد CSV) → چک false + return
- LogController::exportCsv → چک false + return
- AdvancedAuditTrail::exportToCSV → چک false + throw

### ۲. دسته json_decode string|false — ۱۹ مورد
ریشه: `json_decode(file_get_contents('php://input'), true)` که file_get_contents
میتواند false برگرداند. در ۹ فایل کنترلر با `(file_get_contents(...) ?: '')` اصلاح شد.
- GoogleJwtVerifier → decode با `?: ''`
- MaintenanceMode::isAllowedIP → با `?: ''`

### ۳. دسته date()/strtotime() int|false — ۲۰ مورد
ریشه: `strtotime()` خروجی int|false که به date() میرفت. در ۲۷ فایل با
`strtotime(...) ?: time()` اصلاح شد (fallback امن به زمان فعلی).

### ۴. باگ واقعی: logger->error(..., $e) — ۵ مورد
ریشه: `$this->logger->error('msg', $e)` که context باید آرایه باشد نه Exception.
در BulkOperationsService به `['error' => $e->getMessage(), 'exception' => get_class($e)]`
تبدیل شد.

### ۵. باگ واقعی: Dead catch HttpResponseException — ۲ مورد
ریشه: `HttpResponseException extends AppException extends RuntimeException`، پس
`catch (\RuntimeException)` آن را میبلعید و `catch (HttpResponseException)` بعدی dead
بود → response دوبار ارسال میشد. در PredictionController::settle/cancel ترتیب catch ها
اصلاح شد (HttpResponseException اول).

### ۶. Dead catch مضاعف — ۱ مورد
ریشه: try/catch تو در تو در ExceptionHandler::logFatalError → catch بیرونی dead بود.
کد تمیز شد.

### ۷. وابستگی GeoIp2 نصب نشده — ۲ مورد
ریشه: `new GeoIp2\Database\Reader` بدون اینکه package نصب باشد (کرش اگر کتابخانه نبود).
`geoip2/geoip2` به Composer اضافه شد → کلاس شناخته شد و خطای unknown class رفع شد.

## تأیید
- php -l: همه فایلهای تغییر یافته OK
- کانفیگهای PHPStan (main/full/core/check): No errors
- تستها: BulkOperations (5+4), DataExport (5) → OK
- runtime: /health, /health/ready, / = 200

## نتیجه عددی
- کل خطاها: ۷۰۲۲ → ۶۵۱۷ (حذف ۵۰۵)
- QRCode: ۱۰۴ → ۰
- resource|false: ۵۱ → ۰
- json_decode string|false: ۱۹ → ۰
- date int|false: ۲۰ → ۰
- Dead catch: ۳ → ۰
- Logger error Exception: ۵ → ۰
- GeoIp2 unknown class: ۲ → ۰
