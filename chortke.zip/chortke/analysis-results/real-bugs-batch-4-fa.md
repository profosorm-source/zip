# رفع خطاهای واقعی — دسته چهارم (گزارش فارسی)

## رویکرد
ادامه از دستههای قبل؛ تمرکز بر گامهای پیشنهادی: (۱) constructor unused parameter،
(۲) دسترسی property روی object|null، (۳) count/array_keys با array|false.

## موارد رفعشده

### ۱. دسته array|false از explode/preg_split/file/scandir — ~۱۲ مورد
ریشه: `preg_split()`, `file()`, `scandir()` برمیگردانند array|false ولی کد count/index
را بدون چک صدا میزد. در:
- core/QueryBuilder (۴ مورد preg_split) → `?: []`
- app/Utils/Sentry/StackTraceAnalyzer (file) → `?: []`
- app/Services/AntiFraud/GeoIPService (scandir) → `?: []`

### ۲. باگ واقعی: current() روی ساختار errors — ۲ مورد
ریشه: BankCardService `current(current($result['errors']))` که به ساختار شکننده
errors وابسته بود و از نوع mixed میآمد → به `$result['message'] ?? '...'` تبدیل شد
(مطمئن و پایدار).

### ۳. باگ واقعی DI: walletService در CreateCustomTaskJob — ۱ مورد
ریشه: `$walletService` در constructor تزریق میشد ولی `$this->walletService` هرگز
مقداردهی نمیشد (فراموش شده) → همیشه از app() fallback استفاده میشد و تزریق بیاثر بود.
با اضافهکردن `$this->walletService = $walletService;` ریشهای رفع شد.

### ۴. constructor unused parameter — ۳ مورد
ریشه: پارامترهایی که تزریق میشدند ولی استفاده نمیشدند. چون container بهنوع
تزریق میکند، حذف آنها امن است. حذف شد + use های مربوط:
- InfluencerService::$eventDispatcher
- KYCService::$eventDispatcher
- CouponController::$couponModel

## تأیید
- php -l: همه فایلهای تغییر یافته OK
- تستها: InfluencerService (2), SplitServices (18), DependencyIntegrity (6),
  Stability (42), BulkOperations, DataExport → همگی OK
- کانفیگ اصلی PHPStan روی فایلهای تغییر یافته: No errors
- runtime: /health, /health/ready, / = 200

## نتیجه عددی
- کل خطاها: ۶۵۱۷ → ۶۴۹۴ (کاهش ۲۳)
- دسته array|false (preg_split/file/scandir): → ۰
- constructor unused parameter: ۴ → ۰ (با رفع یک باگ DI واقعی)

## نکته
دسته «Cannot access property on object|null» در نوبتهای قبل به ۰ رسیده بود و این نوبت
نیز ۰ ماند. دستههای «unused method/property» که باقی ماندهاند نویز تایپداک/پاکسازی
اختیاری هستند، نه باگ.
