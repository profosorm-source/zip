# گزارش — تکمیل قابلیت «تبلیغ نوتیفیکیشنی + آمار دقیق خواندن»

## بررسی بخش مرجع شما
بخش `runBatchAggregation`/`notification_analytics` **مربوط به همین قابلیت است ولی فقط لایه‌ی aggregation ادمین** بود و از چند جهت ناقص:
- کرون `notification_analytics` در `Console/Kernel.php` در واقع **کد DLQ auto-retry (کپی‌پیست اشتباه)** را اجرا می‌کرد — هیچ aggregation واقعی‌ای صدا زده نمی‌شد.
- `NotificationService::runBatchAggregation()` **وجود نداشت**.
- جدول `notification_analytics` **migration نداشت** → در دیتابیس وجود نداشت → هر INSERT خطای table-not-found می‌داد.
- `getDailyAggregationData()`/`updateBatchAnalytics()` متدهای یتیم (بدون caller).
- مهم‌تر: کلِ مسیر فقط بر اساس `type`+`channel` جمع می‌زد؛ **برای پاسخ به «چند نفر تبلیغِ من را خواندند» به آمار per-ad نیاز بود** که نبود.

## تغییرات انجام‌شده (همه اصولی، بدون وصله)
### مهاجرت
- `database/migrations/2026_08_03_0001_notification_ad_analytics.sql`:
  - ستون‌های جدید `notifications`: `ad_id, campaign_id, shown_at, opened_at, closed_at, dismissed_at, read_duration_sec, engagement_source` + ایندکس‌ها.
  - جدول `notification_analytics` با PK (date,type,channel) و ستون‌های ad.

### مدل `Notification`
- `create()` حالا `ad_id/campaign_id/channel` را می‌ستد.
- متدهای engagement: `recordShown/recordOpened/recordClosed/recordDismissed` (با fallback محاسبه‌ی مدت).
- `getAdAnalytics()`: آمار کامل per-ad + دسته‌بندی زود(<5s)/متوسط/دیر(>30s) + نرخ‌های تفسیری.
- `getAdNotifications()`، `belongsToAd()`.
- `getDailyAggregationData()`/`updateBatchAnalytics()` برای ستون‌های ad گسترش یافتند + `aggregateDailyAnalytics()` جدید.

### سرویس `NotificationService`
- `runBatchAggregation()` (کرون ساعتی) + پروکسی‌های `recordShown/Opened/Closed/Dismissed`.
- `processSinglePersist` مقدار `ad_id`/`campaign_id` را از `data` استخراج می‌کند.

### کرون
- `Console/Kernel.php`: اسلات `notification_analytics` به `runBatchAggregation()` واقعی متصل شد (جایگزین DLQ-copy).

### اندپوینت‌ها
- `POST /notifications/events/{shown|opened|closed|dismissed}` (User\NotificationController) برای گزارش اپ.
- `GET /ads/{id}/notification-stats` (User\AdsController) برای آمار JSON تبلیغ‌دهنده.

### داشبورد داخل اپ
- `views/user/ads/show.php`: پنل آمار خواندن نوتیفیکیشن برای تبلیغ‌های type=notification.

### رفع باگ همراه
- `NotificationRequestListener.php`: پس از رفع Fatal قبلی، PHPStan ۱۲ خطای این listener را آشکار کرد (param بدون نوع، nullsafe غیرضروری، offset روی mixed، undefined method از container) — همه ریش‌های رفع شدند.

## تأیید
- `php -l` همه فایل‌ها: OK.
- PHPStan لول-۹ بدون ignore: **۵۶۹۹** (بهتر از baseline ۵۷۰۴؛ بدون رگرسیون).
- PHPUnit کل: **۲۳۰۶ تست، ۰ شکست، ۵ skip محیطی** (شامل ۱۰ تست جدید `NotificationAdAnalyticsTest`).
- تست عملکردی دستی روی DB واقعی: ایجاد نوتیف ad → ثبت shown/opened/closed/click → `getAdAnalytics` مقادیر صحیح + دسته‌بندی زود/دیر را برگرداند.

## تست جدید
- `tests/Unit/Services/NotificationAdAnalyticsTest.php` (۱۰ تست، ۱۶ assertion): پوشش رفتار engagement، fallback مدت، clamp منفی، آمار per-ad + نرخ‌های تفسیری، مالکیت، و aggregation upsert.
