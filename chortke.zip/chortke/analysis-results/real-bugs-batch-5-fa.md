# رفع خطاهای واقعی — دسته پنجم (گزارش فارسی)

## رویکرد
ادامه از دستههای قبل؛ تمرکز بر «رفعهای معنایی پراکنده کوچک» — هندل بازگشتیهای
PHP که میتوانند خطا/کرش بدهند. همه بهصورت ریشهای و بدون ignoreErrors جدید.

## موارد رفعشده

### ۱. array_keys با mixed (۳ مورد)
- Console/Kernel, BulkOperationsService: `array_keys($row)` → `array_keys((array)$row)`
- HealthCheckService: استفاده از `$services` (که قبلاً is_array چک شده بود) بهجای `$cb['services']`

### ۲. in_array haystack با mixed (۴ مورد)
- HealthCheckController, MetricsController (x2), SafeModeMiddleware:
  `$allowedIps`/`$allowedPaths` از config که mixed بود → با `is_array(...) ? ... : []` امن شد.

### ۳. hydrate با mixed (۵ مورد)
- SeoExecution (x3), SocialAccount (x2): `hydrate($row)` → `hydrate((array)$row)`

### ۴. WithdrawalListener data mixed (۶ مورد)
- `$event->getData()` که mixed بود → `(array)$event->getData()` (event آرایه میسازد)

### ۵. RoleController syncPermissions (۲ مورد)
- `$permissionIds = $this->request->post('permissions') ?? []` → `(array)(...)`

### ۶. intval/floatval/strval با mixed (۷ مورد در ContentService)
- `intval($data['x'] ?? 0)` → `(int)($data['x'] ?? 0)` و مشابه (cast مستقیم)

### ۷. fetchColumn روی PDOStatement|false (۷ مورد در HealthCheckService)
- `(int)$pdo->query(...)->fetchColumn()` → جدا کردن query و چک `$stmt === false`

### ۸. finfo_open|false (۸ مورد)
- BugReportController, CustomTaskController, InfluencerController, TicketController (x2),
  DirectMessageCommandService, UploadService (x2): بعد از finfo_open چک false + return/throw/continue
- پارامتر دوم finfo_file: `(string)$file['tmp_name']`

### ۹. curl_close با CurlHandle|false (۳ مورد در AlertDispatcher)
- بعد از curl_init چک `$ch === false` و در finally `$ch !== false`

### ۱۰. setcookie با session_name()|false (۲ مورد)
- SessionService, core/Session: `(string)session_name()`

### ۱۱. hash/md5/hash_hmac/json_encode string|false (حدود ۱۵ مورد)
- `hash('sha256', json_encode(...))`, `md5(json_encode(...))` → `(string)json_encode(...)`
- در AdtubeController, CreateTradeJob, ProcessReferralCommissionJob, BrowserFingerprintService,
  DeviceIntelligenceService, VideoFingerprintService, ReferralService, WithdrawalUserService,
  CalculateSilentRiskScoreJob, SubmitSocialTaskExecutionJob, OutboxService, BaseSearchProvider,
  InfluencerCommandService, CaptchaService, PermissionMiddleware, LoginRiskService

### ۱۲. fwrite با json_encode string|false (۵ مورد)
- DistributedLockService (x2), SentryExceptionHandler, core/Cache (x2): `(string)json_encode`

### ۱۳. متفرقه
- AdvancedAuditTrail (gzencode), SentryErrorMonitor (trim file_get_contents),
  VerificationService (strtolower parse_url), CreateBugReportRequest (preg_match filter_var),
  Minifier (file_get_contents string|false), WebSocketService (redis->publish, strtotime)

### ۱۴. strpos/str_contains/str_starts_with با mixed (حدود ۱۶ مورد)
- ریشه: `$this->request->header()` که mixed بود → `(string)` cast در ۱۱ فایل
  (HealthCheckController, TokenController, BaseController, SearchController, TicketController,
  RealTimeController, ApiRequestMiddleware, GlobalExceptionMiddleware, MaintenanceMiddleware,
  RateLimitPolicy)

## تأیید
- php -l: همه فایلهای تغییر یافته OK
- تستها: BulkOperations (5), InfluencerService (2), ContentService (4), CaptchaService (8) → OK
- runtime: /health, /health/ready, / = 200

## نتیجه عددی
- کل خطاها: ۶۴۹۴ → ۶۴۰۹ (کاهش ۸۵ در این نوبت)
- از ۷۰۲۲ اولیه: حذف ۶۱۳ خطا
- دستههای هدف این نوبت: finfo|false=0, curl_close=0, fetchColumn=0, array_keys=0, intval/floatval=0
