# گزارش نهایی اصلاح PHPStan

تاریخ: 2026-07-31

## نتیجه

هدف این مرحله، صفر کردن خطاهای PHPStan در کانفیگ‌های موجود پروژه بود. انجام شد.

| کانفیگ | نتیجه نهایی |
|---|---:|
| `phpstan_full.neon` | 0 خطا |
| `phpstan.neon` | 0 خطا |
| `phpstan_check.neon` | 0 خطا |
| `phpstan_core.neon` | 0 خطا |
| `phpstan_core_check.neon` | 0 خطا |

## اعتبارسنجی syntax

- `php -l` روی کل `app/` و `core/`: 867 فایل، همه OK.

## Smoke-test

- `/health`: 200 OK
- `/ping`: 200 OK

نکته: مثل قبل، به‌دلیل نبود MySQL در محیط فعلی، لاگ health هنوز خطای `Database reconnection failed` برای loading/observability دارد؛ readiness کامل نیازمند DB/Redis و migrations است.

## نوع اصلاحات انجام‌شده

- حذف/رفع متدهای undefined و contractهای شکسته.
- اضافه کردن guard برای dependencyهای nullable مثل outbox/wallet/transaction wrapper.
- normalizer مرزی برای داده‌های `mixed` در request/event/config/DB result.
- اصلاح return typeهای `false|string`, `null|bool`, و affected rows.
- اصلاح singleton typing در Core.
- اصلاح QueryBuilder برای join/where/cursor/increment.
- اصلاح Search/Sentry/AntiFraud/Content/CustomTask/Withdrawal typing بدون اضافه کردن ignore جدید.

## فایل‌های تغییرکرده

تعداد فایل‌های تغییرکرده: 52

- `app/Services/AntiFraud/RiskPolicyService.php`
- `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php`
- `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php`
- `app/Services/AntiFraud/VideoFingerprintService.php`
- `app/Services/Auth/AuthService.php`
- `app/Services/Auth/AuthSessionManager.php`
- `app/Services/Auth/LoginRiskService.php`
- `app/Services/Auth/TwoFactorService.php`
- `app/Services/BankCardService.php`
- `app/Services/BannerService.php`
- `app/Services/BulkOperationsService.php`
- `app/Services/Cache/CacheInvalidationService.php`
- `app/Services/ContentService.php`
- `app/Services/CryptoDeposit/CryptoDepositService.php`
- `app/Services/CustomTask/AdminCustomTaskService.php`
- `app/Services/CustomTask/CustomTaskExecutorService.php`
- `app/Services/CustomTask/CustomTaskModerationService.php`
- `app/Services/CustomTask/CustomTaskService.php`
- `app/Services/DataExportService.php`
- `app/Services/DirectMessageCommandService.php`
- `app/Services/DistributedLockService.php`
- `app/Services/DlqWorker.php`
- `app/Services/EmailDeliveryStore.php`
- `app/Services/EmailService.php`
- `app/Services/ExportService.php`
- `app/Services/FeatureFlagService.php`
- `app/Services/Influencer/InfluencerCommandService.php`
- `app/Services/Interaction/RatingService.php`
- `app/Services/Interaction/ReportService.php`
- `app/Services/KYC/KYCQueryService.php`
- `app/Services/MigrationService.php`
- `app/Services/OutboxPublisher.php`
- `app/Services/Payment/DgPayGateway.php`
- `app/Services/QueueWorker.php`
- `app/Services/Search/BaseSearchProvider.php`
- `app/Services/Search/ModuleSearchProvider.php`
- `app/Services/Search/SearchProjectionListener.php`
- `app/Services/Sentry/Alerting/AlertDispatcher.php`
- `app/Services/Sentry/Alerting/AlertRulesEngine.php`
- `app/Services/Sentry/Audit/AdvancedAuditTrail.php`
- `app/Services/Sentry/ErrorMonitoring/SentryErrorMonitor.php`
- `app/Services/SocialTask/SilentAntiFraudService.php`
- `app/Services/User/AccountDeletionService.php`
- `app/Services/User/UserDashboardService.php`
- `app/Services/User/UserService.php`
- `app/Services/WebSocketService.php`
- `app/Services/Withdrawal/WithdrawalAdminService.php`
- `app/Services/Withdrawal/WithdrawalUserService.php`
- `core/Application.php`
- `core/Cache.php`
- `core/EventDispatcher.php`
- `core/QueryBuilder.php`


## فایل‌های خروجی

- `analysis-results/phpstan-fixes.patch` — patch کامل تغییرات نسبت به ZIP اولیه.
- `analysis-results/phpstan-fixes-summary.md` — همین گزارش.
- `analysis-results/*.final.json` — خروجی JSON نهایی PHPStan.
- `analysis-results/php-lint-after-fixes.log` — نتیجه lint کل app/core.
