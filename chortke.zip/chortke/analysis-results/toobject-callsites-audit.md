# Audit: همه‌ی call-site های `->toObject(...)`

> اگر آرگومان از منبعی می‌آید که مستقیم `?\stdClass`/`list<\stdClass>` برمی‌گرداند، `toObject` زائد است.

## REDUNDANT — db->fetch/query/selectOne (منبع ?\stdClass)

`app/Services/AdminDashboard/DashboardQueryService.php:220` → $this->db->fetch("SELECT total_transactions as fin_coun
`app/Services/AdminDashboard/DashboardQueryService.php:344` → $this->db->fetchAll($sql, $params
`app/Services/Ads/AdsBudgetSettlementService.php:229` → $this->db->fetch("SELECT * FROM ads WHERE id = ? AND ty
`app/Services/Ads/AdsBudgetSettlementService.php:280` → $this->db->fetch("SELECT * FROM ads WHERE id = ? AND ty
`app/Services/Ads/AdsBudgetSettlementService.php:331` → $this->db->fetch("SELECT remaining_budget, spent_budget
`app/Services/Ads/AdsBudgetSettlementService.php:376` → $this->db->fetch("SELECT * FROM ads WHERE id = ? AND ty
`app/Services/Ads/AdsBudgetSettlementService.php:431` → $this->db->fetch("SELECT remaining_budget, status FROM 
`app/Services/Ads/AdsBudgetSettlementService.php:511` → $this->db->fetch("SELECT remaining_budget, status FROM 
`app/Services/Ads/AdsBudgetSettlementService.php:543` → $this->db->fetch("SELECT * FROM ads WHERE id = ? FOR UP
`app/Services/Ads/AdsBudgetSettlementService.php:611` → $this->db->fetch("SELECT * FROM ads WHERE id = ? FOR UP
`app/Services/AntiFraud/FraudDetectionService.php:447` → $this->db->fetch("SELECT id FROM kyc_verifications WHER
`app/Services/BannerService.php:718` → $this->db->fetch("SELECT COALESCE(SUM(impressions
`app/Services/Cron/CronService.php:59` → $this->db->fetchAll($sql
`app/Services/DatabaseAnalyzerService.php:334` → $this->db->query("SHOW TABLES"
`app/Services/DatabaseAnalyzerService.php:337` → $this->db->query("SHOW KEYS FROM `{$table}` WHERE Key_n
`app/Services/DatabaseAnalyzerService.php:81` → $this->db->query("SHOW STATUS LIKE 'Threads%'"
`app/Services/Dispute/DisputeCommandService.php:475` → $this->db->fetch("SELECT * FROM story_orders WHERE id =
`app/Services/Gamification/XpService.php:82` → $this->db->query("SELECT * FROM users WHERE id = ?", [$
`app/Services/Influencer/InfluencerCommandService.php:169` → $this->db->fetch("SELECT id FROM influencer_verificatio
`app/Services/Influencer/InfluencerCommandService.php:470` → $this->db->fetch("SELECT id FROM disputes WHERE ref_typ
`app/Services/Influencer/InfluencerCommandService.php:98` → $this->db->fetchColumn("SELECT `value` FROM system_sett
`app/Services/Lottery/LotteryCommandService.php:181` → $this->db->fetch("SELECT * FROM lottery_rounds WHERE id
`app/Services/Lottery/LotteryCommandService.php:197` → $this->db->fetch("SELECT id FROM lottery_participations
`app/Services/Lottery/LotteryCommandService.php:277` → $this->db->selectOne("SELECT * FROM lottery_rounds WHER
`app/Services/MessageModerationService.php:286` → $this->db->query("SELECT warning_count FROM users WHERE
`app/Services/MessageModerationService.php:423` → $this->db->query("SELECT id FROM users WHERE id = ?", [
`app/Services/MigrationService.php:389` → $this->db->fetch("SELECT COALESCE(MAX(batch
`app/Services/Notification/FcmService.php:61` → $this->db->fetchColumn("SELECT id FROM user_devices WHE
`app/Services/Payment/PaymentDepositService.php:92` → $this->db->selectOne("SELECT * FROM manual_deposits WHE
`app/Services/Search/AdminSearchGateway.php:208` → $this->db->fetchAll("SELECT {$select} FROM {$table} {$a
`app/Services/Search/ModuleSearchGateway.php:170` → $this->db->fetchAll("SELECT vl.* FROM vitrine_listings 
`app/Services/Search/SearchProjectionRepository.php:91` → $this->db->fetchColumn("SELECT MAX(updated_at
`app/Services/Search/UserSearchGateway.php:146` → $this->db->fetchAll("SELECT {$select} FROM {$table} {$a
`app/Services/Shared/BatchLoader.php:18` → $this->db->fetch("SELECT * FROM users WHERE id = ?", [$
`app/Services/Shared/ReferralService.php:102` → $this->db->fetchAll($sql, [$userId, $days]
`app/Services/Shared/ReferralService.php:115` → $this->db->fetch($sql, [$userId, $days]
`app/Services/Shared/ReferralService.php:129` → $this->db->fetch($sql, [$userId, $currency]
`app/Services/Shared/ReferralService.php:525` → $this->db->fetch($sql, [$referrerId]
`app/Services/Shared/ReferralService.php:537` → $this->db->fetch($sql, [$referrerId]
`app/Services/Shared/ReferralService.php:549` → $this->db->fetch($sql, [$ip]
`app/Services/Shared/ReferralService.php:691` → $this->db->fetch("SELECT tier_name FROM referral_tiers 
`app/Services/Shared/ReferralService.php:90` → $this->db->fetchAll($sql, [$userId, $days]
`app/Services/TicketCommandService.php:200` → $this->db->fetch("SELECT * FROM tickets WHERE id = ? FO
`app/Services/UnifiedTaskService.php:206` → $this->db->fetch($sql, $params
`app/Services/User/AccountDeletionService.php:166` → $this->db->selectOne("SELECT balance_irt, balance_usdt 

## VERIFY — Service->find (اغلب ?\stdClass)

`app/Controllers/Admin/UserController.php:112` → $this->userService->find((int
`app/Controllers/Admin/UserController.php:176` → $this->userService->find($id
`app/Controllers/Admin/UserController.php:192` → $this->userService->find($id
`app/Controllers/Admin/UserController.php:208` → $this->userService->find((int
`app/Controllers/Admin/UserController.php:273` → $this->userService->find($id
`app/Controllers/Admin/UserController.php:284` → $this->userService->find((int
`app/Controllers/Admin/UserController.php:313` → $this->userService->find($id
`app/Controllers/Admin/UserController.php:324` → $this->userService->find($currentAdminId
`app/Controllers/Admin/UserController.php:373` → $this->userService->find($id
`app/Controllers/Admin/UserController.php:389` → $this->userService->find((int
`app/Controllers/Admin/UserController.php:431` → $this->userService->find($id
`app/Controllers/Admin/UserController.php:450` → $this->userService->find($id

## VERIFY — Model->find/findBy/get (اغلب ?\stdClass)

`app/Services/ApiTokenService.php:153` → $this->userModel->findById($userId
`app/Services/ApiTokenService.php:218` → $this->userModel->findById($userId
`app/Services/ApiTokenService.php:330` → $this->userModel->findByEmail($email
`app/Services/ApiTokenService.php:460` → $this->apiTokenModel->findByRefreshToken($plainRefreshT
`app/Services/Auth/AuthSessionManager.php:142` → $this->userModel->findByRememberToken($hashedToken
`app/Services/Auth/AuthSessionManager.php:233` → $this->userModel->find($userId
`app/Services/Auth/TwoFactorService.php:135` → $this->userModel->find($userId
`app/Services/Auth/TwoFactorService.php:211` → $this->userModel->find($userId
`app/Services/Auth/TwoFactorService.php:252` → $this->userModel->find($userId
`app/Services/BankCardService.php:206` → $this->userModel->find($userId
`app/Services/BankCardService.php:293` → $this->userModel->find((int
`app/Services/BankCardService.php:90` → $this->userModel->find($userId
`app/Services/BannerService.php:328` → $this->bannerModel->find($id
`app/Services/BannerService.php:366` → $this->bannerModel->find($id
`app/Services/BannerService.php:409` → $this->bannerModel->find($id
`app/Services/BannerService.php:425` → $this->bannerModel->find($bannerId
`app/Services/BannerService.php:516` → $this->placementModel->find($id
`app/Services/BannerService.php:533` → $this->placementModel->find($id
`app/Services/BannerService.php:644` → $this->placementModel->find($id
`app/Services/BannerService.php:92` → $this->placementModel->findBySlug($placement
`app/Services/ContentService.php:224` → $this->submissionModel->find((int
`app/Services/ContentService.php:282` → $this->submissionModel->find((int
`app/Services/ContentService.php:343` → $this->submissionModel->find((int
`app/Services/ContentService.php:411` → $this->submissionModel->find((int
`app/Services/ContentService.php:647` → $this->submissionModel->find((int
`app/Services/CryptoDeposit/CryptoDepositService.php:212` → $this->depositModel->find($depositId
`app/Services/CryptoDeposit/CryptoDepositService.php:295` → $this->depositModel->find($depositId
`app/Services/CryptoDeposit/CryptoDepositService.php:348` → $this->depositModel->find($depositId
`app/Services/CryptoDeposit/CryptoDepositService.php:579` → $this->depositModel->find($depositId
`app/Services/CustomTask/AdminCustomTaskService.php:124` → $this->taskModel->find($taskId
`app/Services/CustomTask/AdminCustomTaskService.php:162` → $this->taskModel->find($taskId
`app/Services/CustomTask/AdminCustomTaskService.php:239` → $this->taskModel->find($taskId
`app/Services/CustomTask/AdminCustomTaskService.php:268` → $this->taskModel->find($taskId
`app/Services/CustomTask/CustomTaskService.php:94` → $this->taskModel->find($id
`app/Services/Dispute/DisputeCommandService.php:197` → $this->disputeModel->find((int
`app/Services/Dispute/DisputeCommandService.php:235` → $this->disputeModel->getSafe($disputeId
`app/Services/Dispute/DisputeCommandService.php:281` → $this->disputeModel->getSafe($disputeId
`app/Services/Dispute/DisputeCommandService.php:332` → $this->disputeModel->getSafe($disputeId
`app/Services/Dispute/DisputeCommandService.php:612` → $this->disputeModel->find((int
`app/Services/Dispute/DisputeCommandService.php:93` → $this->disputeModel->findByRef('custom_task_submission'
`app/Services/EmailService.php:202` → $this->userModel->find($userId
`app/Services/EmailService.php:323` → $this->userModel->find($userId
`app/Services/EmailService.php:348` → $this->userModel->find($userId
`app/Services/EmailService.php:365` → $this->userModel->find($userId
`app/Services/EmailService.php:383` → $this->userModel->find($userId
`app/Services/EmailService.php:403` → $this->userModel->find($userId
`app/Services/EmailService.php:426` → $this->userModel->find($userId
`app/Services/EmailService.php:444` → $this->userModel->find($userId
`app/Services/EmailService.php:465` → $this->userModel->find($userId
`app/Services/FeatureFlagService.php:337` → $this->userModel->find($userId
`app/Services/FeatureFlagService.php:346` → $this->kycModel->findByUserId($userId
`app/Services/Influencer/InfluencerCommandService.php:155` → $this->profileModel->findByUserId($userId
`app/Services/Influencer/InfluencerCommandService.php:221` → $this->profileModel->find($influencerId
`app/Services/Influencer/InfluencerCommandService.php:347` → $this->orderModel->find($orderId
`app/Services/Influencer/InfluencerCommandService.php:391` → $this->orderModel->find($orderId
`app/Services/Influencer/InfluencerCommandService.php:428` → $this->orderModel->find($orderId
`app/Services/Influencer/InfluencerCommandService.php:444` → $this->orderModel->find($orderId
`app/Services/Influencer/InfluencerCommandService.php:495` → $this->orderModel->find($orderId
`app/Services/Influencer/InfluencerCommandService.php:555` → $this->orderModel->find($orderId
`app/Services/Influencer/InfluencerCommandService.php:857` → $this->orderModel->find($orderId
`app/Services/Influencer/InfluencerCommandService.php:890` → $this->orderModel->find($orderId
`app/Services/Investment/InvestmentCommandService.php:273` → $this->withdrawalModel->find(intval($ctx['w_id']
`app/Services/Investment/InvestmentCommandService.php:342` → $this->investmentModel->findForUpdate($investmentId
`app/Services/KYC/KYCCommandService.php:103` → $this->kycModel->findByUserId($userId
`app/Services/KYC/KYCCommandService.php:264` → $this->kycModel->findForUpdate($kycId
`app/Services/KYC/KYCCommandService.php:349` → $this->kycModel->findForUpdate($kycId
`app/Services/KYC/KYCCommandService.php:418` → $this->kycModel->findByUserId($userId
`app/Services/KYC/KYCQueryService.php:183` → $this->kycModel->find($id
`app/Services/KYC/KYCQueryService.php:252` → $this->kycModel->find($id
`app/Services/KYC/KYCQueryService.php:64` → $this->kycModel->findByUserId($userId

## VERIFY — Service->find (اغلب ?\stdClass)

`app/Services/KYCService.php:127` → $this->queryService->find($id, $maskPII

## VERIFY — Model->find/findBy/get (اغلب ?\stdClass)

`app/Services/Lottery/LotteryQueryService.php:70` → $this->roundModel->find($roundId
`app/Services/Payment/IDPayGateway.php:194` → $this->paymentGatewayModel->getDb(

## VERIFY — Service->find (اغلب ?\stdClass)

`app/Services/ReferralManagementService.php:145` → $this->userService->find($userId

## VERIFY — Model->find/findBy/get (اغلب ?\stdClass)

`app/Services/Seo/AdsSeoService.php:116` → $this->adModel->find($adId
`app/Services/Seo/AdsSeoService.php:125` → $this->adModel->findByIdForUpdate($adId
`app/Services/Seo/AdsSeoService.php:196` → $this->adModel->find($adId
`app/Services/Seo/AdsSeoService.php:261` → $this->adModel->findByIdForUpdate($adId
`app/Services/Seo/AdsSeoService.php:370` → $this->adModel->find($adId
`app/Services/SeoPayoutService.php:149` → $this->seoAdModel->find($adId
`app/Services/SeoPayoutService.php:232` → $this->seoAdModel->find($adId
`app/Services/SeoPayoutService.php:45` → $this->seoAdModel->find($adId
`app/Services/Shared/CouponService.php:364` → $this->couponModel->find($couponId
`app/Services/Shared/CouponService.php:410` → $this->couponModel->find($id
`app/Services/Shared/CouponService.php:455` → $this->couponModel->find($id
`app/Services/Shared/CouponService.php:491` → $this->couponModel->find($id
`app/Services/Shared/CouponService.php:515` → $this->couponModel->find($id

## VERIFY — Service->find (اغلب ?\stdClass)

`app/Services/Shared/DisputeService.php:348` → $this->queryService->find($id

## VERIFY — Model->find/findBy/get (اغلب ?\stdClass)

`app/Services/SocialAccountService.php:234` → $this->socialAccountModel->find($accountId
`app/Services/SocialAccountService.php:271` → $this->socialAccountModel->find($accountId
`app/Services/SocialAccountService.php:318` → $this->socialAccountModel->find($accountId
`app/Services/SocialAccountService.php:372` → $this->socialAccountModel->find($accountId
`app/Services/SocialAccountService.php:413` → $this->socialAccountModel->find($id
`app/Services/SocialAccountService.php:90` → $this->userModel->find($userId
`app/Services/User/UserSettingsService.php:342` → $this->userModel->find($userId
`app/Services/VerificationService.php:182` → $this->profileModel->find($profileId
`app/Services/VerificationService.php:325` → $this->verificationModel->findById($verificationId
`app/Services/Wallet/WalletQueryService.php:179` → $this->transactionModel->find($id

## OTHER — باید دستی بررسی شود (validator/Repo/... )

`app/Controllers/Admin/UserController.php:110` → $validator->data(
`app/Controllers/Admin/UserController.php:206` → $validatedData
`app/Services/AdSystemManager.php:245` → $this->adsRepository->find($adId
`app/Services/BankCardService.php:181` → $rawCard
`app/Services/BankCardService.php:248` → $rawCard
`app/Services/BankCardService.php:269` → $rawCard
`app/Services/BankCardService.php:452` → $this->model->find($cardId
`app/Services/BankCardService.php:486` → $raw
`app/Services/BankCardService.php:522` → $raw
`app/Services/Dispute/DisputeCommandService.php:146` → $this->db->table('story_orders'
`app/Services/Dispute/DisputeCommandService.php:318` → $this->db->table('users'
`app/Services/Dispute/DisputeCommandService.php:586` → $this->disputeModel->createDispute($data
`app/Services/Influencer/InfluencerCommandService.php:83` → $model->find($id
`app/Services/ManualDepositService.php:114` → $model->find($depositId
`app/Services/ManualDepositService.php:119` → (new BankCard($this->db
`app/Services/Payment/PaymentAdminService.php:71` → $this->log->where('id', '=', $paymentId
`app/Services/Payment/PaymentCommandService.php:238` → $this->log->where('authority', $authority
`app/Services/Payment/PaymentCommandService.php:631` → $this->toObject($this->log->where('id', '=', $pay->id
`app/Services/Settings/AppSettings.php:213` → $this->model->find($id
`app/Services/Settings/SettingsManager.php:122` → $this->model->find($id
`app/Services/Shared/CouponService.php:549` → $query->orderBy('created_at', 'DESC'
`app/Services/Shared/DashboardStatsService.php:181` → $this->db->table('seo_ads'
`app/Services/Shared/DisputeService.php:186` → $submissionModel->submission_find((int
`app/Services/Shared/DisputeService.php:297` → $submissionModel->submission_findByIdForUpdate((int
`app/Services/Shared/DisputeService.php:303` → $escrowService->getByOrder((int
`app/Services/User/ProfileService.php:249` → $this->toObject($this->model->where('mobile', '=', $mob
`app/Services/User/ProfileService.php:58` → $this->model->find($userId
`app/Services/User/UserService.php:237` → $this->model->find($id
`app/Services/User/UserService.php:250` → $row
`app/Services/User/UserService.php:256` → $row
`app/Services/User/UserService.php:272` → $row
`app/Services/Withdrawal/WithdrawalAdminService.php:178` → $this->model->find($withdrawalId
`app/Services/Withdrawal/WithdrawalAdminService.php:194` → $this->model->find($ctx['withdrawal_id']
`app/Services/Withdrawal/WithdrawalAdminService.php:225` → $this->model->find($res['withdrawal_id']
`app/Services/Withdrawal/WithdrawalQueryService.php:168` → $this->model->find($withdrawalId

---
**جمع: 190 call-site**
