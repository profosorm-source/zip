# گزارش کامل و تفصیلی خطاهای PHPStan (Level 9 بدون ignore) — بهروز ۲۰۲۶-۰۸-۰۵

**مجموع:** 4072 خطا در 550 فایل

## ۱) خلاصهی دستهبندی کل

| دسته | تعداد |
|---|---|
| type-mismatch/expects | 1026 |
| cast-mixed(int) | 602 |
| cannot-access | 503 |
| cast-mixed(string) | 428 |
| return-type-mismatch(array) | 208 |
| never-read-property | 174 |
| no-return-type | 171 |
| always-true | 139 |
| cast-mixed(float) | 133 |
| unreachable | 105 |
| OTHER | 90 |
| encapsed-string | 84 |
| cannot-call-on-nullable | 82 |
| unused | 77 |
| return-type-mismatch(stdClass) | 50 |
| return-type-mismatch | 43 |
| always-condition | 41 |
| always-evaluate | 40 |
| nullsafe-on-non-nullable | 29 |
| always-false | 27 |
| no-type-specified | 10 |
| generic-template-unresolved | 10 |

## ۲) فهرست ۲۰ فایل پرخطاترین

| # | فایل | تعداد |
|---|---|---|
| 1 | `app/Services/Search/SearchProjectionListener.php` | 91 |
| 2 | `app/Controllers/Admin/FeatureFlagController.php` | 53 |
| 3 | `app/Services/Sentry/ErrorMonitoring/SentryErrorMonitor.php` | 49 |
| 4 | `app/Services/Analytics/AnalyticsService.php` | 47 |
| 5 | `app/Models/ContentSubmission.php` | 45 |
| 6 | `core/Queue.php` | 44 |
| 7 | `app/Controllers/Admin/NotificationController.php` | 43 |
| 8 | `app/Models/SeoExecution.php` | 40 |
| 9 | `app/Jobs/CustomTask/CreateCustomTaskJob.php` | 37 |
| 10 | `app/Services/SocialTask/BehaviorAnalysisService.php` | 35 |
| 11 | `app/Listeners/ContentEventListeners.php` | 33 |
| 12 | `app/Controllers/Admin/BannerController.php` | 32 |
| 13 | `app/Controllers/Admin/ExecutorTaskController.php` | 32 |
| 14 | `app/Listeners/VitrineEventListeners.php` | 32 |
| 15 | `app/Services/AntiFraud/TaskExecutionEvaluatorService.php` | 30 |
| 16 | `app/Controllers/OAuthController.php` | 29 |
| 17 | `app/Listeners/SocialTaskEventListeners.php` | 29 |
| 18 | `app/Controllers/User/InfluencerController.php` | 28 |
| 19 | `app/Jobs/Seo/ProcessSeoTaskAsyncJob.php` | 28 |
| 20 | `app/Models/FileAccess.php` | 28 |

## ۳) فهرست کامل فایلها (به تفکیک تعداد خطا)

- **91** — `app/Services/Search/SearchProjectionListener.php`
- **53** — `app/Controllers/Admin/FeatureFlagController.php`
- **49** — `app/Services/Sentry/ErrorMonitoring/SentryErrorMonitor.php`
- **47** — `app/Services/Analytics/AnalyticsService.php`
- **45** — `app/Models/ContentSubmission.php`
- **44** — `core/Queue.php`
- **43** — `app/Controllers/Admin/NotificationController.php`
- **40** — `app/Models/SeoExecution.php`
- **37** — `app/Jobs/CustomTask/CreateCustomTaskJob.php`
- **35** — `app/Services/SocialTask/BehaviorAnalysisService.php`
- **33** — `app/Listeners/ContentEventListeners.php`
- **32** — `app/Controllers/Admin/BannerController.php`
- **32** — `app/Controllers/Admin/ExecutorTaskController.php`
- **32** — `app/Listeners/VitrineEventListeners.php`
- **30** — `app/Services/AntiFraud/TaskExecutionEvaluatorService.php`
- **29** — `app/Controllers/OAuthController.php`
- **29** — `app/Listeners/SocialTaskEventListeners.php`
- **28** — `app/Controllers/User/InfluencerController.php`
- **28** — `app/Jobs/Seo/ProcessSeoTaskAsyncJob.php`
- **28** — `app/Models/FileAccess.php`
- **26** — `app/Controllers/Api/UserController.php`
- **26** — `app/Services/Search/ModuleSearchGateway.php`
- **26** — `core/Cache.php`
- **25** — `app/Controllers/User/BugReportController.php`
- **25** — `app/Controllers/User/CryptoDepositController.php`
- **25** — `app/Controllers/User/TicketController.php`
- **25** — `app/Controllers/User/VitrineController.php`
- **25** — `app/Services/SocialTask/SilentAntiFraudService.php`
- **24** — `app/Controllers/Admin/AccountDeletionManagementController.php`
- **24** — `app/Controllers/Admin/SentryAdminController.php`
- **24** — `app/Models/ReferralCommission.php`
- **23** — `app/Services/AntiFraud/SeoFraudDetector.php`
- **23** — `app/Services/FeatureFlagService.php`
- **22** — `app/Controllers/Api/TokenController.php`
- **22** — `app/Models/SocialAccount.php`
- **22** — `app/Services/AntiFraud/VelocityCheckService.php`
- **22** — `app/Services/Sentry/Alerting/AlertDispatcher.php`
- **22** — `app/Services/Sentry/PerformanceMonitoring/SentryPerformanceMonitor.php`
- **21** — `app/Controllers/User/ManualDepositController.php`
- **21** — `app/Models/Transaction.php`
- **21** — `app/Services/Analytics/AnalyticsQueryService.php`
- **21** — `app/Services/AntiFraud/DeviceIntelligenceService.php`
- **20** — `app/Controllers/Admin/AuditTrailController.php`
- **20** — `app/Controllers/Admin/CouponController.php`
- **20** — `app/Models/KpiStatistics.php`
- **20** — `app/Services/ContentService.php`
- **20** — `core/EventDispatcher.php`
- **19** — `app/Console/Kernel.php`
- **19** — `app/Controllers/Admin/WithdrawalController.php`
- **19** — `app/Services/CaptchaService.php`
- **19** — `core/Container.php`
- **18** — `app/Controllers/Admin/AuthController.php`
- **18** — `app/Controllers/Admin/InvestmentController.php`
- **18** — `app/Controllers/Admin/ReferralController.php`
- **18** — `app/Controllers/Admin/RoleController.php`
- **18** — `app/Controllers/Admin/TicketController.php`
- **18** — `app/Middleware/AuthMiddleware.php`
- **18** — `app/Policies/RateLimitPolicy.php`
- **18** — `app/Services/Search/AdminSearchGateway.php`
- **18** — `app/Services/Search/AdminSearchProvider.php`
- **17** — `app/Controllers/Api/InteractionApiController.php`
- **17** — `app/Controllers/User/AdtubeController.php`
- **17** — `app/Jobs/ProcessNotificationJob.php`
- **17** — `app/Listeners/WithdrawalListener.php`
- **17** — `app/Services/AntiFraud/FraudDetectionService.php`
- **17** — `app/Services/AntiFraud/GeolocationIntelligenceService.php`
- **17** — `app/Services/Auth/LoginRiskService.php`
- **17** — `app/Services/Health/HealthCheckService.php`
- **17** — `app/Services/Withdrawal/WithdrawalUserService.php`
- **16** — `app/Controllers/Admin/BackupManagementController.php`
- **16** — `app/Controllers/Api/WalletController.php`
- **16** — `app/Models/Investment.php`
- **16** — `app/Services/AdminDashboard/DashboardQueryService.php`
- **16** — `app/Services/QueueWorker.php`
- **16** — `app/Services/User/UserService.php`
- **15** — `app/Controllers/User/TwoFactorController.php`
- **15** — `app/Services/SagaOrchestrator.php`
- **14** — `app/Commands/DatabaseAnalyzerCommand.php`
- **14** — `app/Controllers/Admin/AdTaskController.php`
- **14** — `app/Controllers/User/ContentController.php`
- **14** — `app/Jobs/Auth/LinkSocialAccountJob.php`
- **14** — `app/Models/Escrow.php`
- **14** — `app/Services/Auth/OAuthService.php`
- **14** — `app/Services/MessageModerationService.php`
- **14** — `core/ExceptionHandler.php`
- **13** — `app/Controllers/Admin/BugReportController.php`
- **13** — `app/Controllers/Admin/InfluencerController.php`
- **13** — `app/Controllers/Admin/LevelController.php`
- **13** — `app/Controllers/Admin/ScoreManagementController.php`
- **13** — `app/Controllers/Api/SocialTaskApiController.php`
- **13** — `app/Controllers/User/InvestmentController.php`
- **13** — `app/Controllers/User/SocialAccountController.php`
- **13** — `app/Models/LotteryRound.php`
- **13** — `app/Models/PerformanceLog.php`
- **13** — `app/Services/DataExportService.php`
- **13** — `core/Scheduler.php`
- **12** — `app/Controllers/Admin/FraudController.php`
- **12** — `app/Controllers/Admin/ManualDepositController.php`
- **12** — `app/Controllers/User/MessageController.php`
- **12** — `app/Jobs/Auth/ProcessRegistrationJob.php`
- **12** — `app/Jobs/Auth/UnlinkSocialAccountJob.php`
- **12** — `app/Models/InvestmentWithdrawal.php`
- **12** — `app/Services/EmailDeliveryStore.php`
- **12** — `core/QueryBuilder.php`
- **11** — `app/Controllers/Admin/AdminAdsController.php`
- **11** — `app/Controllers/Admin/LogController.php`
- **11** — `app/Controllers/User/DashboardController.php`
- **11** — `app/Jobs/Auth/HandleGoogleCallbackJob.php`
- **11** — `app/Jobs/CustomTask/SubmitProofJob.php`
- **11** — `app/Jobs/PersistBulkInAppNotificationJob.php`
- **11** — `app/Models/AuditTrail.php`
- **11** — `app/Models/KYCVerification.php`
- **11** — `app/Models/LotteryParticipation.php`
- **11** — `app/Services/BankCardService.php`
- **11** — `app/Services/User/ProfileService.php`
- **11** — `app/Services/Withdrawal/WithdrawalAdminService.php`
- **10** — `app/Controllers/Admin/PlacementController.php`
- **10** — `app/Controllers/Admin/PredictionController.php`
- **10** — `app/Controllers/Admin/TransactionController.php`
- **10** — `app/Controllers/Api/FeatureFlagApiController.php`
- **10** — `app/Jobs/SocialTask/SubmitSocialTaskExecutionJob.php`
- **10** — `app/Middleware/ApiAuthMiddleware.php`
- **10** — `app/Models/TradingRecord.php`
- **10** — `app/Services/AntiFraud/GeoIPService.php`
- **10** — `app/Services/AntiFraud/RiskPolicyService.php`
- **10** — `app/Services/ContactService.php`
- **10** — `app/Services/Payment/DgPayGateway.php`
- **10** — `app/Services/Payment/IDPayGateway.php`
- **10** — `app/Validators/LoginRequest.php`
- **9** — `app/Controllers/Admin/AdminAnalyticsController.php`
- **9** — `app/Controllers/Admin/BankCardController.php`
- **9** — `app/Controllers/Admin/CryptoDepositController.php`
- **9** — `app/Controllers/Admin/LotteryController.php`
- **9** — `app/Controllers/SearchController.php`
- **9** — `app/Controllers/User/ApiTokenController.php`
- **9** — `app/Controllers/User/CouponController.php`
- **9** — `app/Controllers/User/ProfileController.php`
- **9** — `app/Jobs/Auth/HandleFacebookCallbackJob.php`
- **9** — `app/Listeners/ReferralCommissionListener.php`
- **9** — `app/Listeners/WalletDepositRequestListener.php`
- **9** — `app/Middleware/AdvancedFraudMiddleware.php`
- **9** — `app/Models/Score.php`
- **9** — `app/Models/TicketMessage.php`
- **9** — `app/Models/VitrineRating.php`
- **9** — `app/Services/CustomTask/CustomTaskService.php`
- **9** — `app/Services/Notification/NotificationTemplateService.php`
- **9** — `app/Services/Payment/NextPayGateway.php`
- **9** — `app/Services/Payment/ZarinPalGateway.php`
- **9** — `app/Services/Shared/CouponService.php`
- **9** — `app/Services/UnifiedTaskService.php`
- **8** — `app/Commands/IdempotencyCommand.php`
- **8** — `app/Controllers/Admin/KpiController.php`
- **8** — `app/Controllers/Admin/MessageModerationController.php`
- **8** — `app/Controllers/Api/VerificationController.php`
- **8** — `app/Controllers/User/AdsApiController.php`
- **8** — `app/Controllers/User/EscrowController.php`
- **8** — `app/Controllers/User/LotteryController.php`
- **8** — `app/Controllers/User/SeoController.php`
- **8** — `app/Jobs/Payment/CreateCryptoDepositJob.php`
- **8** — `app/Jobs/Prediction/SettleGameJob.php`
- **8** — `app/Listeners/InfluencerEventListeners.php`
- **8** — `app/Models/VitrineListing.php`
- **8** — `app/Services/BackupService.php`
- **8** — `app/Services/CacheAdminService.php`
- **8** — `app/Services/SagaRecoveryWorker.php`
- **8** — `app/Services/Sentry/Analytics/TrendAnalyzer.php`
- **8** — `app/Services/User/UserDashboardService.php`
- **8** — `app/Services/User/UserSettingsService.php`
- **8** — `app/Services/Wallet/WalletQueryService.php`
- **8** — `app/Utils/Sentry/StackTraceAnalyzer.php`
- **8** — `app/Validators/Requests/CreateWithdrawalRequest.php`
- **7** — `app/Controllers/Admin/KYCController.php`
- **7** — `app/Controllers/Admin/SeoAdController.php`
- **7** — `app/Controllers/Admin/SocialAccountController.php`
- **7** — `app/Controllers/Admin/SocialTaskController.php`
- **7** — `app/Controllers/Admin/SystemSettingController.php`
- **7** — `app/Controllers/MetricsController.php`
- **7** — `app/Controllers/User/AuthController.php`
- **7** — `app/Controllers/User/SocialTaskController.php`
- **7** — `app/Controllers/User/WithdrawalController.php`
- **7** — `app/Jobs/CustomTask/RateSubmissionJob.php`
- **7** — `app/Listeners/InvestmentEventListeners.php`
- **7** — `app/Middleware/RateLimitMiddleware.php`
- **7** — `app/Models/LotteryVote.php`
- **7** — `app/Models/PredictionBet.php`
- **7** — `app/Models/PredictionGame.php`
- **7** — `app/Services/AntiFraud/AccountTakeoverService.php`
- **7** — `app/Services/BulkOperationsService.php`
- **7** — `app/Services/DatabaseAnalyzerService.php`
- **7** — `app/Services/DirectMessageCommandService.php`
- **7** — `app/Services/EmailService.php`
- **7** — `app/Services/KYC/KYCCommandService.php`
- **7** — `app/Services/ManualDepositService.php`
- **7** — `app/Services/Notification/NotificationRetryPolicy.php`
- **7** — `app/Services/Notification/NotificationService.php`
- **7** — `app/Services/PerformanceOptimizationService.php`
- **7** — `app/Services/Search/UserSearchProvider.php`
- **7** — `app/Services/Sentry/Alerting/AlertRulesEngine.php`
- **7** — `app/Services/Shared/ReferralService.php`
- **6** — `app/Controllers/Admin/DashboardController.php`
- **6** — `app/Controllers/Admin/RiskPolicyController.php`
- **6** — `app/Controllers/Admin/UserController.php`
- **6** — `app/Controllers/Api/AppConfigController.php`
- **6** — `app/Controllers/Api/HealthCheckController.php`
- **6** — `app/Controllers/Api/RealTimeController.php`
- **6** — `app/Controllers/ContactController.php`
- **6** — `app/Controllers/FileController.php`
- **6** — `app/Controllers/User/PredictionController.php`
- **6** — `app/Controllers/User/ReferralController.php`
- **6** — `app/Domain/Financial/Services/LedgerService.php`
- **6** — `app/Jobs/AntiFraud/CheckTaskFraudJob.php`
- **6** — `app/Jobs/Auth/LinkSocialAccountSafeJob.php`
- **6** — `app/Jobs/Referral/ProcessReferralCommissionJob.php`
- **6** — `app/Jobs/SocialTask/CalculateSilentRiskScoreJob.php`
- **6** — `app/Jobs/SocialTask/DecideSilentAntiFraudJob.php`
- **6** — `app/Jobs/UpdateFraudScoreJob.php`
- **6** — `app/Middleware/ConcurrentRequestMiddleware.php`
- **6** — `app/Models/ExportData.php`
- **6** — `app/Models/InvestmentProfit.php`
- **6** — `app/Models/SocialTaskAnalyticsModel.php`
- **6** — `app/Services/AntiFraud/VideoFingerprintService.php`
- **6** — `app/Services/Auth/AuthSessionManager.php`
- **6** — `app/Services/CryptoDeposit/CryptoDepositService.php`
- **6** — `app/Services/CustomTask/AdminCustomTaskService.php`
- **6** — `app/Services/DistributedLockService.php`
- **6** — `app/Services/Influencer/InfluencerCommandService.php`
- **6** — `app/Services/LogService.php`
- **6** — `app/Services/Notification/NotificationAnalyticsService.php`
- **6** — `app/Services/ReferralManagementService.php`
- **6** — `app/Services/Sentry/SentryExceptionHandler.php`
- **6** — `app/Services/Settings/SettingsManager.php`
- **6** — `app/Services/UploadService.php`
- **6** — `app/Services/User/UserLevelCommandService.php`
- **6** — `app/Validators/Requests/CreateCustomTaskRequest.php`
- **6** — `core/CircuitBreaker.php`
- **6** — `core/Console/CliDispatcher.php`
- **6** — `core/RedisSessionHandler.php`
- **6** — `core/ValueObjects/Money.php`
- **5** — `app/Controllers/Admin/ApiTokenAdminController.php`
- **5** — `app/Controllers/Admin/EmailQueueController.php`
- **5** — `app/Controllers/Admin/VitrineController.php`
- **5** — `app/Controllers/BannerController.php`
- **5** — `app/Controllers/User/KYCController.php`
- **5** — `app/Controllers/User/LevelController.php`
- **5** — `app/Controllers/User/SettingsController.php`
- **5** — `app/Controllers/User/TransferController.php`
- **5** — `app/Jobs/KycTimeoutJob.php`
- **5** — `app/Jobs/SendEmailJob.php`
- **5** — `app/Jobs/Vitrine/ReleaseVitrineFundsJob.php`
- **5** — `app/Middleware/MaintenanceMiddleware.php`
- **5** — `app/Models/InfluencerVerification.php`
- **5** — `app/Services/Auth/AuthService.php`
- **5** — `app/Services/Auth/GoogleJwtVerifier.php`
- **5** — `app/Services/DirectMessageQueryService.php`
- **5** — `app/Services/DirectMessageService.php`
- **5** — `app/Services/Investment/InvestmentQueryService.php`
- **5** — `app/Services/Lottery/LotteryCommandService.php`
- **5** — `app/Services/Lottery/LotteryService.php`
- **5** — `app/Services/Payment/BasePaymentGateway.php`
- **5** — `app/Services/Score/ScoreCommandService.php`
- **5** — `app/Services/Search/SearchQuery.php`
- **5** — `app/Services/Sentry/Analytics/DashboardService.php`
- **5** — `app/Services/SitemapService.php`
- **5** — `app/Services/TicketCommandService.php`
- **5** — `app/Services/VerificationService.php`
- **5** — `app/Validators/PasswordPolicy.php`
- **5** — `app/Validators/RegisterRequest.php`
- **5** — `core/CSRF.php`
- **5** — `core/RetryPolicy.php`
- **4** — `app/Commands/StuckWithdrawalReviewCommand.php`
- **4** — `app/Controllers/Admin/CacheAdminController.php`
- **4** — `app/Controllers/Admin/FraudManagementController.php`
- **4** — `app/Controllers/Api/FingerprintController.php`
- **4** — `app/Controllers/BaseController.php`
- **4** — `app/Controllers/CaptchaController.php`
- **4** — `app/Controllers/HomeController.php`
- **4** — `app/Controllers/User/DisputeController.php`
- **4** — `app/Jobs/Auth/OAuthHelperTrait.php (in context of class App\Jobs\Auth\HandleFacebookCallbackJob)`
- **4** — `app/Jobs/Auth/OAuthHelperTrait.php (in context of class App\Jobs\Auth\HandleGoogleCallbackJob)`
- **4** — `app/Jobs/Auth/OAuthHelperTrait.php (in context of class App\Jobs\Auth\LinkSocialAccountSafeJob)`
- **4** — `app/Jobs/Notification/SendToAdminsNotificationJob.php`
- **4** — `app/Jobs/Prediction/CancelGameJob.php`
- **4** — `app/Jobs/Prediction/PlaceBetJob.php`
- **4** — `app/Jobs/SystemCleanupJob.php`
- **4** — `app/Jobs/Vitrine/CreateVitrineListingJob.php`
- **4** — `app/Middleware/AdminMiddleware.php`
- **4** — `app/Middleware/CSRFMiddleware.php`
- **4** — `app/Middleware/CorsMiddleware.php`
- **4** — `app/Middleware/GlobalExceptionMiddleware.php`
- **4** — `app/Models/Role.php`
- **4** — `app/Models/ScheduledPayment.php`
- **4** — `app/Models/Ticket.php`
- **4** — `app/Models/Withdrawal.php`
- **4** — `app/Services/AntiFraud/FraudGuardService.php`
- **4** — `app/Services/AntiFraud/RateLimitingService.php`
- **4** — `app/Services/ApiTokenService.php`
- **4** — `app/Services/BannerService.php`
- **4** — `app/Services/CustomTask/CustomTaskModerationService.php`
- **4** — `app/Services/DlqWorker.php`
- **4** — `app/Services/Gamification/TrustService.php`
- **4** — `app/Services/KYC/KYCQueryService.php`
- **4** — `app/Services/Notification/NotificationPreferenceService.php`
- **4** — `app/Services/ScheduledPaymentService.php`
- **4** — `app/Services/Search/SchemaInspector.php`
- **4** — `app/Services/Seo/AdsSeoService.php`
- **4** — `app/Services/Shared/DisputeService.php`
- **4** — `app/Services/User/AccountDeletionService.php`
- **4** — `app/Validators/Requests/CreatePredictionGameRequest.php`
- **4** — `core/IdempotencyKey.php`
- **3** — `app/Commands/DlqWorkCommand.php`
- **3** — `app/Commands/FeatureFlagCommand.php`
- **3** — `app/Commands/OutboxPublishCommand.php`
- **3** — `app/Commands/QueueFailedCommand.php`
- **3** — `app/Controllers/Admin/ContentController.php`
- **3** — `app/Controllers/Api/InfluencerController.php`
- **3** — `app/Controllers/FaviconController.php`
- **3** — `app/Controllers/User/AdsController.php`
- **3** — `app/Controllers/User/BaseUserController.php`
- **3** — `app/Controllers/User/CustomTaskController.php`
- **3** — `app/Controllers/User/NotificationController.php`
- **3** — `app/Jobs/Influencer/CompleteInfluencerOrderJob.php`
- **3** — `app/Jobs/Influencer/CreateInfluencerOrderJob.php`
- **3** — `app/Jobs/Influencer/DisputeInfluencerOrderJob.php`
- **3** — `app/Jobs/Influencer/SubmitInfluencerProofJob.php`
- **3** — `app/Jobs/Notification/SendFromTemplateNotificationJob.php`
- **3** — `app/Jobs/Payment/CreateCryptoDepositIntentJob.php`
- **3** — `app/Jobs/Payment/ReconcilePaymentsJob.php`
- **3** — `app/Jobs/Vitrine/ReportVitrineListingJob.php`
- **3** — `app/Jobs/Withdrawal/RequestWithdrawalUserJob.php`
- **3** — `app/Jobs/WithdrawalTimeoutJob.php`
- **3** — `app/Middleware/CaptchaMiddleware.php`
- **3** — `app/Middleware/TaskFraudGuardMiddleware.php`
- **3** — `app/Middleware/TracingMiddleware.php`
- **3** — `app/Models/InteractionModel.php`
- **3** — `app/Models/LedgerEntry.php`
- **3** — `app/Models/ManualDeposit.php`
- **3** — `app/Models/NotificationPreference.php`
- **3** — `app/Models/Permission.php`
- **3** — `app/Models/SecurityLog.php`
- **3** — `app/Models/SecurityModel.php`
- **3** — `app/Models/User.php`
- **3** — `app/Providers/AppServiceProvider.php`
- **3** — `app/Services/AdminDashboard/SystemMonitoringService.php`
- **3** — `app/Services/AntiFraud/BrowserFingerprintService.php`
- **3** — `app/Services/AntiFraud/MLFraudDetectionService.php`
- **3** — `app/Services/AuditTrail.php`
- **3** — `app/Services/Auth/SessionService.php`
- **3** — `app/Services/Auth/TwoFactorService.php`
- **3** — `app/Services/CustomTask/CustomTaskExecutorService.php`
- **3** — `app/Services/DatabaseService.php`
- **3** — `app/Services/MigrationService.php`
- **3** — `app/Services/Search/BaseSearchProvider.php`
- **3** — `app/Services/Search/ModuleSearchProvider.php`
- **3** — `app/Services/Search/SearchOrchestrator.php`
- **3** — `app/Services/Search/UserSearchGateway.php`
- **3** — `app/Services/User/UserLevelQueryService.php`
- **3** — `app/Validators/ChangePasswordRequest.php`
- **3** — `app/Validators/Requests/CreateBugReportRequest.php`
- **3** — `core/Model.php`
- **3** — `core/Pipeline.php`
- **3** — `core/Response.php`
- **3** — `core/Router.php`
- **3** — `core/Strategies/FixedWindowStrategy.php`
- **2** — `app/Commands/QueueWorkCommand.php`
- **2** — `app/Controllers/Admin/BaseAdminController.php`
- **2** — `app/Controllers/Admin/DatabaseHealthController.php`
- **2** — `app/Controllers/Api/BaseApiController.php`
- **2** — `app/Controllers/User/BankCardController.php`
- **2** — `app/Controllers/User/SessionController.php`
- **2** — `app/Domain/Gamification/Strategies/DailySynergyStrategy.php`
- **2** — `app/Domain/Gamification/Strategies/InactivityDecayStrategy.php`
- **2** — `app/Domain/Gamification/Strategies/TrustEvaluationStrategy.php`
- **2** — `app/Exceptions/OAuthException.php`
- **2** — `app/Exceptions/PaymentGatewayConnectionException.php`
- **2** — `app/Exceptions/PaymentGatewayException.php`
- **2** — `app/Exceptions/PaymentVerificationException.php`
- **2** — `app/Exceptions/SessionException.php`
- **2** — `app/Jobs/BackfillSearchProjectionJob.php`
- **2** — `app/Jobs/CustomTask/CronSubmissionsJob.php`
- **2** — `app/Jobs/CustomTask/PayRewardJob.php`
- **2** — `app/Jobs/Influencer/ConfirmInfluencerOrderJob.php`
- **2** — `app/Jobs/Investment/CreateTradeJob.php`
- **2** — `app/Jobs/Referral/DistributeMonthlyReferralRewardsJob.php`
- **2** — `app/Jobs/Seo/CompleteSeoTaskJob.php`
- **2** — `app/Jobs/Seo/StartSeoTaskJob.php`
- **2** — `app/Jobs/Vitrine/ProcessExpiredVitrineEscrowsJob.php`
- **2** — `app/Jobs/Vitrine/SendVitrineRequestJob.php`
- **2** — `app/Listeners/CacheInvalidateListener.php`
- **2** — `app/Listeners/EscrowListener.php`
- **2** — `app/Listeners/LogFeatureFlagChange.php`
- **2** — `app/Listeners/ScoreProjectionListener.php`
- **2** — `app/Middleware/ApiRequestMiddleware.php`
- **2** — `app/Middleware/HttpsMiddleware.php`
- **2** — `app/Middleware/PermissionMiddleware.php`
- **2** — `app/Middleware/SafeModeMiddleware.php`
- **2** — `app/Models/BankCard.php`
- **2** — `app/Models/FeatureFlag.php`
- **2** — `app/Models/Page.php`
- **2** — `app/Models/PaymentGateway.php`
- **2** — `app/Models/Setting.php`
- **2** — `app/Models/SettingsAuditTrail.php`
- **2** — `app/Models/SocialTaskModel.php`
- **2** — `app/Models/SystemLog.php`
- **2** — `app/Models/TransactionQuery.php`
- **2** — `app/Models/UserLevel.php`
- **2** — `app/SDK/FeatureFlagSDK.php`
- **2** — `app/Services/AdNotificationDispatcher.php`
- **2** — `app/Services/AdminDashboard/AdminDashboardService.php`
- **2** — `app/Services/AntiFraud/FraudStrategyResolver.php`
- **2** — `app/Services/AntiFraud/Strategies/TaskFraudStrategy.php`
- **2** — `app/Services/Auth/PasswordRecoveryService.php`
- **2** — `app/Services/Cache/CacheManager.php`
- **2** — `app/Services/CurrencyService.php`
- **2** — `app/Services/InfluencerService.php`
- **2** — `app/Services/Lottery/LotteryParticipationService.php`
- **2** — `app/Services/Lottery/LotteryQueryService.php`
- **2** — `app/Services/Metrics/MetricsCollector.php`
- **2** — `app/Services/Notification/NotificationDispatcher.php`
- **2** — `app/Services/Notification/NotificationPolicyService.php`
- **2** — `app/Services/Payment/PaymentDepositService.php`
- **2** — `app/Services/Search/SearchProjectionRepository.php`
- **2** — `app/Services/Shared/PolicyService.php`
- **2** — `app/Services/SocialTask/SocialTaskService.php`
- **2** — `app/Services/VitrineSettingsService.php`
- **2** — `app/Services/WebSocketService.php`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\AdapterBase)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\CryptoApiAdapter)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\CryptoExplorerAdapter)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\DeepFaceKycAdapter)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\JibitInquiryAdapter)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\Notification\FcmNotificationAdapter)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\Notification\LogNotificationAdapter)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\Notification\SmsNotificationAdapter)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Jobs\Auth\HandleFacebookCallbackJob)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Jobs\Auth\HandleGoogleCallbackJob)`
- **2** — `app/Traits/ExternalCallTrait.php (in context of class App\Jobs\Auth\LinkSocialAccountSafeJob)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\Ads)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\CryptoDeposit)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\InfluencerModel)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\Investment)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\ManualDeposit)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\SocialTaskModel)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\Ticket)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\Transaction)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\VitrineListing)`
- **2** — `app/Traits/Filterable.php (in context of class App\Models\Withdrawal)`
- **2** — `app/Validators/Requests/CreateManualDepositRequest.php`
- **2** — `app/Validators/Requests/CreateTransferRequest.php`
- **2** — `app/Validators/Requests/ExecuteSocialTaskRequest.php`
- **2** — `app/Validators/Requests/Verify2FARequest.php`
- **2** — `core/Application.php`
- **2** — `core/Minifier.php`
- **2** — `core/PathResolver.php`
- **2** — `core/Validator.php`
- **1** — `app/Controllers/Admin/CronController.php`
- **1** — `app/Controllers/Admin/FraudDashboardController.php`
- **1** — `app/Controllers/Admin/OnlinePaymentController.php`
- **1** — `app/Controllers/DebugController.php`
- **1** — `app/Controllers/RobotsController.php`
- **1** — `app/Controllers/TestCaptchaController.php`
- **1** — `app/Controllers/User/TaskFeedController.php`
- **1** — `app/Controllers/User/WalletController.php`
- **1** — `app/Jobs/Auth/Verify2FAJob.php`
- **1** — `app/Jobs/Investment/CreateInvestmentJob.php`
- **1** — `app/Jobs/Investment/RequestWithdrawalJob.php`
- **1** — `app/Jobs/Notification/GetUserNotificationsNotificationJob.php`
- **1** — `app/Jobs/Notification/LatestNotificationJob.php`
- **1** — `app/Jobs/Notification/SendToAllNotificationJob.php`
- **1** — `app/Jobs/Notification/SendToSegmentNotificationJob.php`
- **1** — `app/Jobs/NotificationCleanupJob.php`
- **1** — `app/Jobs/RunCronTaskJob.php`
- **1** — `app/Jobs/ScoreRecalculationJob.php`
- **1** — `app/Jobs/SocialTask/ApproveSocialTaskExecutionJob.php`
- **1** — `app/Jobs/SocialTaskApprovalReminderJob.php`
- **1** — `app/Jobs/Vitrine/AdminRefundVitrineListingJob.php`
- **1** — `app/Jobs/Vitrine/RateVitrineListingJob.php`
- **1** — `app/Jobs/Vitrine/ResolveVitrineDisputeJob.php`
- **1** — `app/Jobs/VitrineListingExpiryJob.php`
- **1** — `app/Listeners/FraudGuardListener.php`
- **1** — `app/Listeners/InvalidateSearchCacheListener.php`
- **1** — `app/Listeners/PersistAuditRecordListener.php`
- **1** — `app/Middleware/BaseMiddleware.php`
- **1** — `app/Middleware/GuestMiddleware.php`
- **1** — `app/Middleware/LoggingMiddleware.php`
- **1** — `app/Models/ApiToken.php`
- **1** — `app/Models/ContentAgreement.php`
- **1** — `app/Models/ContentRevenue.php`
- **1** — `app/Models/CryptoDeposit.php`
- **1** — `app/Models/CryptoDepositIntent.php`
- **1** — `app/Models/CustomTaskTransaction.php`
- **1** — `app/Models/IpAndDeviceModel.php`
- **1** — `app/Models/SystemTelemetryModel.php`
- **1** — `app/Models/UserVacation.php`
- **1** — `app/Models/UserVerification.php`
- **1** — `app/Models/VitrineRequest.php`
- **1** — `app/Models/WithdrawalLimit.php`
- **1** — `app/Services/AdSystemManager.php`
- **1** — `app/Services/Analytics/AnalyticsExporter.php`
- **1** — `app/Services/AntiFraud/IPQualityService.php`
- **1** — `app/Services/AntiFraud/RiskDecisionService.php`
- **1** — `app/Services/AntiFraud/SessionAnomalyService.php`
- **1** — `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php`
- **1** — `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php`
- **1** — `app/Services/Cron/CronService.php`
- **1** — `app/Services/Dispute/DisputeQueryService.php`
- **1** — `app/Services/ExportService.php`
- **1** — `app/Services/FileAccessService.php`
- **1** — `app/Services/Gamification/XpService.php`
- **1** — `app/Services/Influencer/InfluencerQueryService.php`
- **1** — `app/Services/Interaction/ReportService.php`
- **1** — `app/Services/KYCService.php`
- **1** — `app/Services/MaintenanceService.php`
- **1** — `app/Services/Notification/Channels/FcmChannel.php`
- **1** — `app/Services/Notification/Channels/LogChannel.php`
- **1** — `app/Services/Notification/Channels/PushChannel.php`
- **1** — `app/Services/Notification/Channels/SmsChannel.php`
- **1** — `app/Services/Notification/FcmService.php`
- **1** — `app/Services/Notification/NotificationTracker.php`
- **1** — `app/Services/OutboxService.php`
- **1** — `app/Services/PredictionService.php`
- **1** — `app/Services/Score/ScoreQueryService.php`
- **1** — `app/Services/ScoreService.php`
- **1** — `app/Services/Sentry/Alerting/EscalationManager.php`
- **1** — `app/Services/Sentry/Audit/AdvancedAuditTrail.php`
- **1** — `app/Services/Settings/AppSettings.php`
- **1** — `app/Services/Shared/BatchLoader.php`
- **1** — `app/Services/SocialAccountService.php`
- **1** — `app/Services/SocialTask/CameraVerificationService.php`
- **1** — `app/Services/SocialTask/SocialTaskScoringService.php`
- **1** — `app/Services/TicketQueryService.php`
- **1** — `app/Services/TicketService.php`
- **1** — `app/Services/ValidatorFactory.php`
- **1** — `app/Services/VitrineService.php`
- **1** — `app/Services/Wallet/WalletService.php`
- **1** — `app/Traits/ClientInfoTrait.php (in context of class App\Controllers\User\TwoFactorController)`
- **1** — `app/Traits/ClientInfoTrait.php (in context of class App\Jobs\Auth\HandleFacebookCallbackJob)`
- **1** — `app/Traits/ClientInfoTrait.php (in context of class App\Jobs\Auth\HandleGoogleCallbackJob)`
- **1** — `app/Traits/ClientInfoTrait.php (in context of class App\Jobs\Auth\LinkSocialAccountSafeJob)`
- **1** — `app/Traits/ClientInfoTrait.php (in context of class App\Services\AuditTrail)`
- **1** — `app/Traits/ClientInfoTrait.php (in context of class App\Services\Auth\OAuthService)`
- **1** — `app/Traits/ClientInfoTrait.php (in context of class App\Services\Auth\TwoFactorService)`
- **1** — `app/Utils/Sentry/BreadcrumbCollector.php`
- **1** — `app/Validators/Requests/SendNotificationRequest.php`
- **1** — `app/Validators/Requests/UserUpdateRequest.php`
- **1** — `core/Blueprint.php`
- **1** — `core/GenericEvent.php`
- **1** — `core/Logger.php`
- **1** — `core/Redis.php`
- **1** — `core/Session.php`
- **1** — `core/Sql/SafeExpression.php`

## ۴) خطاها به تفکیک فایل (خطبهخط)

> فرمت: `- L<خط>: <پیام>   (دسته)`

### `app/Services/Search/SearchProjectionListener.php`  (91 خطا)
<sub>دستهها: type-mismatch/expects=77, cannot-access=9, return-type-mismatch(array)=3, OTHER=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L53: `Offset 0 does not exist on array<string, mixed>.` <sub>(OTHER)</sub>
- L53: `Offset 1 does not exist on array<string, mixed>.` <sub>(OTHER)</sub>
- L165: `Cannot access offset 'transaction_db_id' on mixed.` <sub>(cannot-access)</sub>
- L165: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L166: `Cannot access offset 'transaction_id' on mixed.` <sub>(cannot-access)</sub>
- L166: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L167: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L172: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L172: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L173: `Cannot access offset 'description' on mixed.` <sub>(cannot-access)</sub>
- L177: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L178: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L179: `Cannot access offset 'status' on mixed.` <sub>(cannot-access)</sub>
- L180: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L187: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L191: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L192: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L207: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L211: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L212: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L223: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L227: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L228: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L229: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L230: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L230: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L238: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L245: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L246: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L246: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L254: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L257: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L263: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L267: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L268: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L269: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L270: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L270: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L278: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L283: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L284: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L285: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L307: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L313: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L314: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L314: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L314: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L317: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L320: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L326: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L329: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L330: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L331: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L332: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L345: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L348: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L349: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L350: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L351: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L352: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L365: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L368: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L369: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L370: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L457: `Method App\Services\Search\SearchProjectionListener::normalize() should return array<string, mixed> but returns array<int, array|string>.` <sub>(return-type-mismatch(array))</sub>
- L462: `Method App\Services\Search\SearchProjectionListener::normalize() should return array<string, mixed> but returns array<int, array|string>.` <sub>(return-type-mismatch(array))</sub>
- L465: `Method App\Services\Search\SearchProjectionListener::normalize() should return array<string, mixed> but returns array<int, array<string, mixed>|string>.` <sub>(return-type-mismatch(array))</sub>
- L471: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L473: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L474: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L474: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L480: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L482: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L483: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L483: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L489: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L491: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L492: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L498: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L500: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L501: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L507: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L509: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L510: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L516: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L518: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L519: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L525: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L527: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L528: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L528: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/FeatureFlagController.php`  (53 خطا)
<sub>دستهها: type-mismatch/expects=41, cast-mixed(int)=5, no-return-type=4, cannot-access=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Method App\Controllers\Admin\FeatureFlagController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L69: `Parameter #1 $name of method App\Services\FeatureFlagService::findByName() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L78: `Parameter #1 $user of method App\Policies\FeatureFlagPolicy::update() expects App\Models\User|null, object|null given.` <sub>(type-mismatch/expects)</sub>
- L78: `Parameter #2 $featureFlag of method App\Policies\FeatureFlagPolicy::update() expects App\Models\FeatureFlag, App\Models\FeatureFlag|null given.` <sub>(type-mismatch/expects)</sub>
- L85: `Parameter #1 $name of method App\Services\FeatureFlagService::toggle() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L86: `Cannot access property $enabled on App\Models\FeatureFlag|null.` <sub>(cannot-access)</sub>
- L92: `Cannot access property $enabled on App\Models\FeatureFlag|null.` <sub>(cannot-access)</sub>
- L93: `Cannot access property $enabled on App\Models\FeatureFlag|null.` <sub>(cannot-access)</sub>
- L125: `Method App\Controllers\Admin\FeatureFlagController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L138: `Parameter #1 $name of method App\Services\FeatureFlagService::findByName() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L147: `Parameter #1 $user of method App\Policies\FeatureFlagPolicy::update() expects App\Models\User|null, object|null given.` <sub>(type-mismatch/expects)</sub>
- L147: `Parameter #2 $featureFlag of method App\Policies\FeatureFlagPolicy::update() expects App\Models\FeatureFlag, App\Models\FeatureFlag|null given.` <sub>(type-mismatch/expects)</sub>
- L157: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L161: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L183: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'trim' given.` <sub>(type-mismatch/expects)</sub>
- L183: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L197: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'intval' given.` <sub>(type-mismatch/expects)</sub>
- L197: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L208: `Parameter #1 $name of method App\Services\FeatureFlagService::update() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L252: `Method App\Controllers\Admin\FeatureFlagController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L275: `Parameter #2 $subject of function preg_match expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L321: `Method App\Controllers\Admin\FeatureFlagController::delete() has no return type specified.` <sub>(no-return-type)</sub>
- L334: `Parameter #1 $name of method App\Services\FeatureFlagService::findByName() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L343: `Parameter #1 $user of method App\Policies\FeatureFlagPolicy::delete() expects App\Models\User|null, object|null given.` <sub>(type-mismatch/expects)</sub>
- L343: `Parameter #2 $featureFlag of method App\Policies\FeatureFlagPolicy::delete() expects App\Models\FeatureFlag, App\Models\FeatureFlag|null given.` <sub>(type-mismatch/expects)</sub>
- L350: `Parameter #1 $name of method App\Services\FeatureFlagService::delete() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L425: `Parameter #1 $name of method App\Services\FeatureFlagService::findByName() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L434: `Parameter #1 $user of method App\Policies\FeatureFlagPolicy::update() expects App\Models\User|null, object|null given.` <sub>(type-mismatch/expects)</sub>
- L434: `Parameter #2 $featureFlag of method App\Policies\FeatureFlagPolicy::update() expects App\Models\FeatureFlag, App\Models\FeatureFlag|null given.` <sub>(type-mismatch/expects)</sub>
- L445: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L453: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L472: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'trim' given.` <sub>(type-mismatch/expects)</sub>
- L472: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L483: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'intval' given.` <sub>(type-mismatch/expects)</sub>
- L483: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L494: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'trim' given.` <sub>(type-mismatch/expects)</sub>
- L494: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L505: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'trim' given.` <sub>(type-mismatch/expects)</sub>
- L505: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L516: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'trim' given.` <sub>(type-mismatch/expects)</sub>
- L516: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L520: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L531: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L543: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L554: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L573: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'trim' given.` <sub>(type-mismatch/expects)</sub>
- L573: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L584: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'trim' given.` <sub>(type-mismatch/expects)</sub>
- L584: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L595: `Parameter #1 $callback of function array_map expects (callable(mixed): mixed)|null, 'trim' given.` <sub>(type-mismatch/expects)</sub>
- L595: `Parameter #2 $array of function array_map expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L610: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L627: `Parameter #1 $name of method App\Services\FeatureFlagService::update() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Sentry/ErrorMonitoring/SentryErrorMonitor.php`  (49 خطا)
<sub>دستهها: cannot-access=26, type-mismatch/expects=14, return-type-mismatch=4, unused=1, encapsed-string=1, cast-mixed(float)=1, cast-mixed(int)=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::toObject() is unused.` <sub>(unused)</sub>
- L249: `Parameter #2 $stackTrace of method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::generateFingerprint() expects array<int, array<string, mixed>>, array<string, mixed> given.` <sub>(type-mismatch/expects)</sub>
- L295: `Parameter #1 $fingerprint of method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::isRateLimited() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L296: `Method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::storeEvent() should return string but returns mixed.` <sub>(return-type-mismatch)</sub>
- L299: `Parameter #1 $fingerprint of method App\Models\SentryModel::findExistingIssue() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L299: `Parameter #2 $environment of method App\Models\SentryModel::findExistingIssue() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L302: `Parameter #2 $level of method App\Models\SentryModel::updateIssueStats() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L313: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L323: `Cannot access offset 'value' on mixed.` <sub>(cannot-access)</sub>
- L324: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L325: `Cannot access offset 'stacktrace' on mixed.` <sub>(cannot-access)</sub>
- L334: `Cannot access offset 'id' on mixed.` <sub>(cannot-access)</sub>
- L336: `Cannot access offset 'ip' on mixed.` <sub>(cannot-access)</sub>
- L337: `Cannot access offset 'user_agent' on mixed.` <sub>(cannot-access)</sub>
- L340: `Method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::storeEvent() should return string but returns mixed.` <sub>(return-type-mismatch)</sub>
- L349: `Method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::storeEvent() should return string but returns mixed.` <sub>(return-type-mismatch)</sub>
- L362: `Parameter #1 $level of method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::mapLevelToSeverity() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L364: `Cannot access offset 'value' on mixed.` <sub>(cannot-access)</sub>
- L368: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L369: `Cannot access offset 'file' on mixed.` <sub>(cannot-access)</sub>
- L369: `Cannot access offset 'frames' on mixed.` <sub>(cannot-access)</sub>
- L369: `Cannot access offset 'stacktrace' on mixed.` <sub>(cannot-access)</sub>
- L369: `Cannot access offset 0 on mixed.` <sub>(cannot-access)</sub>
- L370: `Cannot access offset 'frames' on mixed.` <sub>(cannot-access)</sub>
- L370: `Cannot access offset 'line' on mixed.` <sub>(cannot-access)</sub>
- L370: `Cannot access offset 'stacktrace' on mixed.` <sub>(cannot-access)</sub>
- L370: `Cannot access offset 0 on mixed.` <sub>(cannot-access)</sub>
- L405: `Cannot access offset 'value' on mixed.` <sub>(cannot-access)</sub>
- L406: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L407: `Parameter #1 $message of method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::normalizeMessage() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L413: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L414: `Parameter #1 $haystack of function strrchr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L414: `Parameter #1 $string of function substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L415: `Cannot access offset 'value' on mixed.` <sub>(cannot-access)</sub>
- L415: `Parameter #1 $string of function substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L417: `Parameter #1 $string of function substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L423: `Cannot access offset 'frames' on mixed.` <sub>(cannot-access)</sub>
- L423: `Cannot access offset 'stacktrace' on mixed.` <sub>(cannot-access)</sub>
- L423: `Cannot access offset 0 on mixed.` <sub>(cannot-access)</sub>
- L425: `Cannot access offset 'file' on mixed.` <sub>(cannot-access)</sub>
- L425: `Parameter #1 $path of function basename expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L426: `Cannot access offset 'function' on mixed.` <sub>(cannot-access)</sub>
- L427: `Part $function (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L508: `Method App\Services\Sentry\ErrorMonitoring\SentryErrorMonitor::detectRelease() should return string|null but returns mixed.` <sub>(return-type-mismatch)</sub>
- L513: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L536: `Parameter #2 $haystack of function in_array expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L557: `Parameter #2 $environment of method App\Models\SentryModel::getErrorStats() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L577: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L622: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/Analytics/AnalyticsService.php`  (47 خطا)
<sub>دستهها: type-mismatch/expects=29, return-type-mismatch(array)=10, cannot-access=6, cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L50: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L51: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L52: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L53: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L54: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L65: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L66: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L67: `Parameter #1 $rows of method App\Services\Analytics\AnalyticsService::normalizeLevelRows() expects array<int|string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L86: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L86: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L87: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L87: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L89: `Cannot access offset 'count' on mixed.` <sub>(cannot-access)</sub>
- L89: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L90: `Cannot access offset 'count' on mixed.` <sub>(cannot-access)</sub>
- L90: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L91: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L91: `Cannot access offset 'count' on mixed.` <sub>(cannot-access)</sub>
- L91: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L91: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L92: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L93: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L105: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L180: `Method App\Services\Analytics\AnalyticsService::getTasksByPlatform() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L186: `Method App\Services\Analytics\AnalyticsService::getHourlyActivity() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L193: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L194: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L195: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L197: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L198: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L199: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L213: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L214: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L215: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L216: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L224: `Method App\Services\Analytics\AnalyticsService::getTopUsers() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L290: `Method App\Services\Analytics\AnalyticsService::getTrendingTasks() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L306: `Parameter #1 $data of method App\Services\Analytics\AnalyticsExporter::generateCSV() expects array<int, array<string, mixed>>, array<int|string, mixed> given.` <sub>(type-mismatch/expects)</sub>
- L307: `Parameter #1 $data of method App\Services\Analytics\AnalyticsExporter::generateExcel() expects array<int, array<string, mixed>>, array<int|string, mixed> given.` <sub>(type-mismatch/expects)</sub>
- L308: `Parameter #1 $data of method App\Services\Analytics\AnalyticsExporter::generatePDF() expects array<int, array<string, mixed>>, array<int|string, mixed> given.` <sub>(type-mismatch/expects)</sub>
- L309: `Parameter #1 $data of method App\Services\Analytics\AnalyticsExporter::generateCSV() expects array<int, array<string, mixed>>, array<int|string, mixed> given.` <sub>(type-mismatch/expects)</sub>
- L363: `Method App\Services\Analytics\AnalyticsService::getDailyRegistrations() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L372: `Method App\Services\Analytics\AnalyticsService::getDailyRevenue() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L381: `Method App\Services\Analytics\AnalyticsService::getDailyDepositsWithdrawals() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L390: `Method App\Services\Analytics\AnalyticsService::getDailyCompletedTasks() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L415: `Method App\Services\Analytics\AnalyticsService::getUserGrowthChart() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L421: `Method App\Services\Analytics\AnalyticsService::getTransactionVolumeChart() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Models/ContentSubmission.php`  (45 خطا)
<sub>دستهها: always-true=12, cannot-access=12, cast-mixed(string)=6, cast-mixed(int)=5, type-mismatch/expects=3, OTHER=2, return-type-mismatch(stdClass)=2, return-type-mismatch(array)=1, unreachable=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L72: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L73: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L74: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L75: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L76: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L80: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L98: `PHPDoc tag @return with type object|null is not subtype of native type stdClass|null.` <sub>(OTHER)</sub>
- L105: `Method App\Models\ContentSubmission::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L105: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L114: `PHPDoc tag @return with type object|null is not subtype of native type stdClass|null.` <sub>(OTHER)</sub>
- L127: `Method App\Models\ContentSubmission::findWithUser() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L127: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L163: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L186: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L188: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L230: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L233: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L234: `Cannot access property $pending on mixed.` <sub>(cannot-access)</sub>
- L235: `Cannot access property $approved on mixed.` <sub>(cannot-access)</sub>
- L236: `Cannot access property $published on mixed.` <sub>(cannot-access)</sub>
- L237: `Cannot access property $rejected on mixed.` <sub>(cannot-access)</sub>
- L250: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L256: `Cannot access property $total_paid on mixed.` <sub>(cannot-access)</sub>
- L257: `Cannot access property $total_pending on mixed.` <sub>(cannot-access)</sub>
- L264: `Method App\Models\ContentSubmission::getUserContentData() should return array<int, stdClass> but returns array<string, array<int|string, int|stdClass>|float|int>.` <sub>(return-type-mismatch(array))</sub>
- L313: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L317: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L332: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L341: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L373: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L377: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L389: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L391: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L446: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L477: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L478: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L501: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L503: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L528: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L530: `Cannot access property $first_approved on mixed.` <sub>(cannot-access)</sub>
- L573: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L574: `Method App\Models\ContentSubmission::getStats() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L601: `Parameter #1 $string of function strlen expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L609: `Parameter #1 $string of function strlen expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L613: `Parameter #1 $string of function strlen expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `core/Queue.php`  (44 خطا)
<sub>دستهها: cannot-call-on-nullable=23, type-mismatch/expects=8, encapsed-string=7, cast-mixed(int)=4, return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L50: `Part $prefix (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L141: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L171: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L172: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L173: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L196: `Cannot call method incr() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L218: `Cannot call method setEx() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L221: `Cannot call method zAdd() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L336: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L385: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L388: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L391: `Cannot call method zRem() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L395: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L406: `Cannot call method setEx() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L432: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L496: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L498: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L501: `Cannot call method zRem() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L501: `Part $queue (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L502: `Cannot call method zRem() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L502: `Part $queue (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L503: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L530: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L532: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L539: `Cannot call method zScore() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L539: `Part $queue (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L541: `Cannot call method zAdd() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L541: `Part $queue (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L572: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L574: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L591: `Cannot call method setEx() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L592: `Cannot call method zRem() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L592: `Part $queue (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L593: `Cannot call method zAdd() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L593: `Part $queue (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L650: `Cannot call method zCard() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L651: `Cannot call method zCard() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L680: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L682: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L893: `Method Core\Queue::retryEligibleFailedJobs() should return array<int, array<string, mixed>> but returns array<string, int>.` <sub>(return-type-mismatch(array))</sub>
- L940: `Method Core\Queue::retryEligibleFailedJobs() should return array<int, array<string, mixed>> but returns array<string, int<0, max>>.` <sub>(return-type-mismatch(array))</sub>
- L1016: `Cannot call method zCount() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L1017: `Cannot call method zCount() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L1018: `Cannot call method zCard() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `app/Controllers/Admin/NotificationController.php`  (43 خطا)
<sub>دستهها: type-mismatch/expects=31, cast-mixed(int)=4, cast-mixed(string)=4, unreachable=2, encapsed-string=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L73: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L74: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L75: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L76: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L77: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L78: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L79: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L80: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L81: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L82: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L98: `Parameter #1 $array of function reset is passed by reference, so it expects variables only.` <sub>(type-mismatch/expects)</sub>
- L101: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L109: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L124: `Parameter #1 $segment of method App\Services\Notification\NotificationService::sendToSegment() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L124: `Parameter #2 $title of method App\Services\Notification\NotificationService::sendToSegment() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L124: `Parameter #3 $message of method App\Services\Notification\NotificationService::sendToSegment() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L124: `Parameter #4 $type of method App\Services\Notification\NotificationService::sendToSegment() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L125: `Parameter #5 $actionUrl of method App\Services\Notification\NotificationService::sendToSegment() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L125: `Parameter #6 $actionText of method App\Services\Notification\NotificationService::sendToSegment() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L125: `Parameter #7 $priority of method App\Services\Notification\NotificationService::sendToSegment() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L125: `Parameter #9 $scheduledAt of method App\Services\Notification\NotificationService::sendToSegment() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L131: `Parameter #2 $type of method App\Services\Notification\NotificationService::send() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L131: `Parameter #3 $title of method App\Services\Notification\NotificationService::send() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L131: `Parameter #4 $message of method App\Services\Notification\NotificationService::send() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L132: `Parameter #6 $actionUrl of method App\Services\Notification\NotificationService::send() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L132: `Parameter #7 $actionText of method App\Services\Notification\NotificationService::send() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L132: `Parameter #8 $priority of method App\Services\Notification\NotificationService::send() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L133: `Parameter #12 $scheduledAt of method App\Services\Notification\NotificationService::send() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L140: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L144: `Part $sent (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L145: `Part $sent (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L161: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L176: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L205: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L206: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L207: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L211: `Parameter #1 $array of function reset is passed by reference, so it expects variables only.` <sub>(type-mismatch/expects)</sub>
- L216: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L217: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L218: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L235: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L239: `Parameter #1 $array of function reset is passed by reference, so it expects variables only.` <sub>(type-mismatch/expects)</sub>
- L244: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/SeoExecution.php`  (40 خطا)
<sub>دستهها: type-mismatch/expects=18, cast-mixed(float)=11, cast-mixed(int)=7, return-type-mismatch=2, cannot-access=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L50: `Parameter #1 $row of method App\Models\SeoExecution::hydrate() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L59: `Parameter #1 $row of method App\Models\SeoExecution::hydrate() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L70: `Parameter #1 $row of method App\Models\SeoExecution::hydrate() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L159: `Method App\Models\SeoExecution::getUserStats() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L181: `Method App\Models\SeoExecution::getAdStats() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L204: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L205: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L220: `Parameter #1 $data of method App\Models\SeoExecution::validateEngagementData() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L241: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L242: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L243: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L244: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L245: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L249: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L250: `Cannot access offset 'client_mode' on mixed.` <sub>(cannot-access)</sub>
- L250: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L314: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L315: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L316: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L317: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L318: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L319: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L320: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L321: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L322: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L323: `Property App\Models\SeoExecution::$status (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L324: `Property App\Models\SeoExecution::$engagement_data (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L325: `Property App\Models\SeoExecution::$fraud_flags (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L326: `Property App\Models\SeoExecution::$ip_address (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L327: `Property App\Models\SeoExecution::$device_fingerprint (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L328: `Property App\Models\SeoExecution::$session_id (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L329: `Property App\Models\SeoExecution::$target_keyword (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L330: `Property App\Models\SeoExecution::$rejection_reason (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L331: `Property App\Models\SeoExecution::$cancel_reason (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L332: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L333: `Property App\Models\SeoExecution::$score_breakdown (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L334: `Property App\Models\SeoExecution::$started_at (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L335: `Property App\Models\SeoExecution::$completed_at (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L336: `Property App\Models\SeoExecution::$created_at (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L337: `Property App\Models\SeoExecution::$updated_at (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/CustomTask/CreateCustomTaskJob.php`  (37 خطا)
<sub>دستهها: cannot-access=26, cast-mixed(float)=4, cast-mixed(int)=3, never-read-property=1, cast-mixed(string)=1, always-evaluate=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Jobs\CustomTask\CreateCustomTaskJob::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L59: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L83: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L85: `Cannot access offset 'price_per_task' on mixed.` <sub>(cannot-access)</sub>
- L85: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L86: `Cannot access offset 'quantity' on mixed.` <sub>(cannot-access)</sub>
- L86: `Cannot access offset 'total_count' on mixed.` <sub>(cannot-access)</sub>
- L86: `Cannot access offset 'total_quantity' on mixed.` <sub>(cannot-access)</sub>
- L86: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L89: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L90: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L99: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L112: `Cannot access offset 'title' on mixed.` <sub>(cannot-access)</sub>
- L125: `Cannot access offset 'title' on mixed.` <sub>(cannot-access)</sub>
- L126: `Cannot access offset 'description' on mixed.` <sub>(cannot-access)</sub>
- L127: `Cannot access offset 'link' on mixed.` <sub>(cannot-access)</sub>
- L127: `Cannot access offset 'target_link' on mixed.` <sub>(cannot-access)</sub>
- L127: `Cannot access offset 'target_url' on mixed.` <sub>(cannot-access)</sub>
- L128: `Cannot access offset 'link' on mixed.` <sub>(cannot-access)</sub>
- L128: `Cannot access offset 'target_link' on mixed.` <sub>(cannot-access)</sub>
- L128: `Cannot access offset 'target_url' on mixed.` <sub>(cannot-access)</sub>
- L129: `Cannot access offset 'task_type' on mixed.` <sub>(cannot-access)</sub>
- L130: `Cannot access offset 'proof_type' on mixed.` <sub>(cannot-access)</sub>
- L131: `Cannot access offset 'proof_description' on mixed.` <sub>(cannot-access)</sub>
- L132: `Cannot access offset 'proof_description' on mixed.` <sub>(cannot-access)</sub>
- L132: `Cannot access offset 'proof_type' on mixed.` <sub>(cannot-access)</sub>
- L133: `Cannot access offset 'sample_image' on mixed.` <sub>(cannot-access)</sub>
- L142: `Cannot access offset 'deadline_hours' on mixed.` <sub>(cannot-access)</sub>
- L143: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L144: `Cannot access offset 'country_restriction' on mixed.` <sub>(cannot-access)</sub>
- L145: `Cannot access offset 'device_restriction' on mixed.` <sub>(cannot-access)</sub>
- L146: `Cannot access offset 'os_restriction' on mixed.` <sub>(cannot-access)</sub>
- L150: `Cannot access offset 'daily_limit_per_user' on mixed.` <sub>(cannot-access)</sub>
- L160: `Call to function is_object() with mixed will always evaluate to false.` <sub>(always-evaluate)</sub>
- L169: `Cannot access offset 'title' on mixed.` <sub>(cannot-access)</sub>
- L213: `Parameter #5 $explicitKey of method App\Services\Shared\IdempotencyService::executeWithTransaction() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/SocialTask/BehaviorAnalysisService.php`  (35 خطا)
<sub>دستهها: type-mismatch/expects=32, cast-mixed(int)=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L66: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L67: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L69: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L81: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L82: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L83: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L84: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L85: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L88: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L105: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L106: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L107: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L108: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L109: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L110: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L111: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L112: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L113: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L114: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L115: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L116: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L118: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L141: `Method App\Services\SocialTask\BehaviorAnalysisService::detectPatterns() should return array<string, mixed> but returns array<int, string>.` <sub>(return-type-mismatch(array))</sub>
- L163: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L164: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L165: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L166: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L167: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L168: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L169: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L170: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L171: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L172: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L173: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Listeners/ContentEventListeners.php`  (33 خطا)
<sub>دستهها: cannot-access=17, cast-mixed(int)=12, always-condition=2, type-mismatch/expects=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L62: `Cannot access offset 'submission_id' on mixed.` <sub>(cannot-access)</sub>
- L63: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L76: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L76: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L79: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L79: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L82: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L82: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L112: `Cannot access offset 'submission_id' on mixed.` <sub>(cannot-access)</sub>
- L113: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L114: `Cannot access offset 'reason' on mixed.` <sub>(cannot-access)</sub>
- L127: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L127: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L127: `Parameter #3 $reason of method App\Listeners\ContentEventListeners::notifyContentRejected() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L155: `Cannot access offset 'submission_id' on mixed.` <sub>(cannot-access)</sub>
- L156: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L172: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L172: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L199: `Cannot access offset 'submission_id' on mixed.` <sub>(cannot-access)</sub>
- L200: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L201: `Cannot access offset 'revenue_id' on mixed.` <sub>(cannot-access)</sub>
- L202: `Cannot access offset 'period' on mixed.` <sub>(cannot-access)</sub>
- L237: `Cannot access offset 'revenue_id' on mixed.` <sub>(cannot-access)</sub>
- L237: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L238: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L238: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L239: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L239: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L273: `Cannot access offset 'revenue_id' on mixed.` <sub>(cannot-access)</sub>
- L274: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L275: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L322: `Variable $userId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L350: `Variable $userId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>

</details>

### `app/Controllers/Admin/BannerController.php`  (32 خطا)
<sub>دستهها: no-return-type=15, cast-mixed(int)=10, type-mismatch/expects=5, never-read-property=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L15: `Property App\Controllers\Admin\BannerController::$searchService is never read, only written.` <sub>(never-read-property)</sub>
- L37: `Method App\Controllers\Admin\BannerController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L39: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L50: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L67: `Method App\Controllers\Admin\BannerController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L73: `Method App\Controllers\Admin\BannerController::showCreate() has no return type specified.` <sub>(no-return-type)</sub>
- L78: `Method App\Controllers\Admin\BannerController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L95: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L96: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L124: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L125: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L140: `Method App\Controllers\Admin\BannerController::edit() has no return type specified.` <sub>(no-return-type)</sub>
- L142: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L154: `Method App\Controllers\Admin\BannerController::showEdit() has no return type specified.` <sub>(no-return-type)</sub>
- L159: `Method App\Controllers\Admin\BannerController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L164: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L203: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L205: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L207: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L208: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L225: `Method App\Controllers\Admin\BannerController::approve() has no return type specified.` <sub>(no-return-type)</sub>
- L235: `Method App\Controllers\Admin\BannerController::reject() has no return type specified.` <sub>(no-return-type)</sub>
- L240: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L246: `Method App\Controllers\Admin\BannerController::delete() has no return type specified.` <sub>(no-return-type)</sub>
- L256: `Method App\Controllers\Admin\BannerController::toggle() has no return type specified.` <sub>(no-return-type)</sub>
- L271: `Method App\Controllers\Admin\BannerController::placements() has no return type specified.` <sub>(no-return-type)</sub>
- L277: `Method App\Controllers\Admin\BannerController::updatePlacement() has no return type specified.` <sub>(no-return-type)</sub>
- L280: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L286: `Method App\Controllers\Admin\BannerController::togglePlacement() has no return type specified.` <sub>(no-return-type)</sub>
- L289: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L297: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L300: `Method App\Controllers\Admin\BannerController::stats() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/Admin/ExecutorTaskController.php`  (32 خطا)
<sub>دستهها: cannot-access=19, cast-mixed(int)=6, cast-mixed(string)=4, no-return-type=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L38: `Cannot access offset 'submission_id' on mixed.` <sub>(cannot-access)</sub>
- L38: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L66: `Cannot access offset 'submission_id' on mixed.` <sub>(cannot-access)</sub>
- L66: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L67: `Cannot access offset 'reason' on mixed.` <sub>(cannot-access)</sub>
- L67: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L94: `Method App\Controllers\Admin\ExecutorTaskController::disputes() has no return type specified.` <sub>(no-return-type)</sub>
- L102: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L122: `Method App\Controllers\Admin\ExecutorTaskController::disputeDetail() has no return type specified.` <sub>(no-return-type)</sub>
- L141: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L164: `Cannot access offset 'dispute_id' on mixed.` <sub>(cannot-access)</sub>
- L164: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L165: `Cannot access offset 'decision' on mixed.` <sub>(cannot-access)</sub>
- L166: `Cannot access offset 'admin_note' on mixed.` <sub>(cannot-access)</sub>
- L167: `Cannot access offset 'executor_percent' on mixed.` <sub>(cannot-access)</sub>
- L167: `Cannot access offset 'executor_percent' on mixed.` <sub>(cannot-access)</sub>
- L167: `Cannot access offset 'worker_percent' on mixed.` <sub>(cannot-access)</sub>
- L167: `Cannot access offset 'worker_percent' on mixed.` <sub>(cannot-access)</sub>
- L167: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L203: `Method App\Controllers\Admin\ExecutorTaskController::reports() has no return type specified.` <sub>(no-return-type)</sub>
- L210: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L234: `Cannot access offset 'report_id' on mixed.` <sub>(cannot-access)</sub>
- L234: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L235: `Cannot access offset 'status' on mixed.` <sub>(cannot-access)</sub>
- L236: `Cannot access offset 'admin_note' on mixed.` <sub>(cannot-access)</sub>
- L237: `Cannot access offset 'executor_percent' on mixed.` <sub>(cannot-access)</sub>
- L237: `Cannot access offset 'executor_percent' on mixed.` <sub>(cannot-access)</sub>
- L237: `Cannot access offset 'worker_percent' on mixed.` <sub>(cannot-access)</sub>
- L237: `Cannot access offset 'worker_percent' on mixed.` <sub>(cannot-access)</sub>
- L237: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L280: `Cannot access offset 'action' on mixed.` <sub>(cannot-access)</sub>
- L281: `Cannot access offset 'ids' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Listeners/VitrineEventListeners.php`  (32 خطا)
<sub>دستهها: cannot-access=14, cast-mixed(int)=5, cast-mixed(string)=4, encapsed-string=4, type-mismatch/expects=3, cast-mixed(float)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L45: `Cannot access offset 'buyer_id' on mixed.` <sub>(cannot-access)</sub>
- L45: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L46: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L46: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L47: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L47: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L48: `Cannot access offset 'listing_id' on mixed.` <sub>(cannot-access)</sub>
- L57: `Part $listingId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L61: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L80: `Cannot access offset 'buyer_id' on mixed.` <sub>(cannot-access)</sub>
- L80: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L81: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L81: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L82: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L82: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L83: `Cannot access offset 'listing_id' on mixed.` <sub>(cannot-access)</sub>
- L91: `Part $listingId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L92: `Part $listingId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L96: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L115: `Cannot access offset 'listing_id' on mixed.` <sub>(cannot-access)</sub>
- L116: `Cannot access offset 'seller_id' on mixed.` <sub>(cannot-access)</sub>
- L116: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L119: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L139: `Cannot access offset 'seller_id' on mixed.` <sub>(cannot-access)</sub>
- L139: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L140: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L140: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L141: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L141: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L142: `Cannot access offset 'listing_id' on mixed.` <sub>(cannot-access)</sub>
- L150: `Part $listingId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L154: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/AntiFraud/TaskExecutionEvaluatorService.php`  (30 خطا)
<sub>دستهها: type-mismatch/expects=22, cast-mixed(float)=4, cannot-access=2, cast-mixed(int)=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L63: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L64: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L66: `Parameter #1 $interactions of method App\Services\AntiFraud\TaskExecutionEvaluatorService::calculateInteractionScore() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L69: `Parameter #1 $signals of method App\Services\AntiFraud\TaskExecutionEvaluatorService::calculateBehaviorScore() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L71: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L85: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L86: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L87: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L159: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L160: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L161: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L162: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L175: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L176: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L177: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L190: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L191: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L192: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L207: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L208: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L220: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L221: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L222: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L242: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L243: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L247: `Cannot access offset 'touch_timing…' on mixed.` <sub>(cannot-access)</sub>
- L247: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L248: `Cannot access offset 'tap_count' on mixed.` <sub>(cannot-access)</sub>
- L248: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L252: `Method App\Services\AntiFraud\TaskExecutionEvaluatorService::calculatePenalties() should return array<string, mixed> but returns array<int, array<string, int|string>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Controllers/OAuthController.php`  (29 خطا)
<sub>دستهها: cast-mixed(string)=12, type-mismatch/expects=10, cannot-access=7</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L59: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L60: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L67: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L68: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L77: `Cannot access property $id on mixed.` <sub>(cannot-access)</sub>
- L101: `Parameter #1 $message of method App\Controllers\BaseController::jsonSuccess() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L110: `Parameter #1 $message of method App\Controllers\BaseController::jsonError() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L124: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L125: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L132: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L133: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L142: `Cannot access property $id on mixed.` <sub>(cannot-access)</sub>
- L166: `Parameter #1 $message of method App\Controllers\BaseController::jsonSuccess() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L175: `Parameter #1 $message of method App\Controllers\BaseController::jsonError() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L205: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L231: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L242: `Parameter #1 $message of method App\Controllers\BaseController::jsonSuccess() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L245: `Parameter #1 $message of method App\Controllers\BaseController::jsonError() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L254: `Cannot access offset 'email' on mixed.` <sub>(cannot-access)</sub>
- L254: `Cannot access offset 'provider' on mixed.` <sub>(cannot-access)</sub>
- L273: `Cannot access offset 'data' on mixed.` <sub>(cannot-access)</sub>
- L273: `Cannot access offset 'email' on mixed.` <sub>(cannot-access)</sub>
- L273: `Cannot access offset 'provider' on mixed.` <sub>(cannot-access)</sub>
- L284: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L298: `Parameter #1 $email of method App\Models\User::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L324: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L324: `Parameter #3 $userData of method App\Services\Auth\OAuthService::linkSocialAccountSafe() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L327: `Parameter #1 $message of method App\Controllers\BaseController::jsonError() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L343: `Parameter #1 $message of method App\Controllers\BaseController::jsonError() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Listeners/SocialTaskEventListeners.php`  (29 خطا)
<sub>دستهها: cannot-access=15, cast-mixed(int)=4, cast-mixed(string)=3, cast-mixed(float)=2, type-mismatch/expects=2, nullsafe-on-non-nullable=2, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L51: `Cannot access offset 'executor_id' on mixed.` <sub>(cannot-access)</sub>
- L51: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L51: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L52: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L52: `Cannot access offset 'reward_amount' on mixed.` <sub>(cannot-access)</sub>
- L52: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L53: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L53: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L54: `Cannot access offset 'execution_id' on mixed.` <sub>(cannot-access)</sub>
- L55: `Cannot access offset 'ad_id' on mixed.` <sub>(cannot-access)</sub>
- L56: `Cannot access offset 'decision' on mixed.` <sub>(cannot-access)</sub>
- L57: `Cannot access offset 'risk_score' on mixed.` <sub>(cannot-access)</sub>
- L63: `Part $executionId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L89: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L115: `Cannot access offset 'executor_id' on mixed.` <sub>(cannot-access)</sub>
- L115: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L140: `Cannot access offset 'ad_id' on mixed.` <sub>(cannot-access)</sub>
- L140: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L141: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L141: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L142: `Cannot access offset 'refund' on mixed.` <sub>(cannot-access)</sub>
- L142: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L143: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L143: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L166: `Using nullsafe method call on non-nullable type App\Contracts\OutboxServiceInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L181: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L200: `Cannot access offset 'execution_id' on mixed.` <sub>(cannot-access)</sub>
- L202: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L202: `Using nullsafe method call on non-nullable type App\Contracts\OutboxServiceInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Controllers/User/InfluencerController.php`  (28 خطا)
<sub>دستهها: unreachable=11, type-mismatch/expects=10, cast-mixed(string)=3, cast-mixed(int)=2, always-false=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L145: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L156: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L165: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L176: `Parameter #2 $platform of method App\Controllers\User\InfluencerController::extractPrices() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L230: `Parameter #1 $filename of function is_uploaded_file expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L238: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L259: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L264: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L271: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L280: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L299: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L307: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L312: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L339: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L339: `Parameter #3 $decision of method App\Services\InfluencerService::respondToOrder() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L358: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L359: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L394: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L404: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L434: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L476: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L477: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L505: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L513: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L532: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L558: `If condition is always false.` <sub>(always-false)</sub>
- L601: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L688: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Jobs/Seo/ProcessSeoTaskAsyncJob.php`  (28 خطا)
<sub>دستهها: cannot-access=9, cast-mixed(int)=7, cast-mixed(float)=5, cast-mixed(string)=4, never-read-property=1, type-mismatch/expects=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Property App\Jobs\Seo\ProcessSeoTaskAsyncJob::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L71: `Cannot access offset 'seo_fraud' on mixed.` <sub>(cannot-access)</sub>
- L75: `Cannot access offset 'flags' on mixed.` <sub>(cannot-access)</sub>
- L86: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L88: `Parameter #2 $flags of method App\Services\Seo\AdsSeoService::markExecutionAsFraud() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L98: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L99: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L100: `Part $scores['final_score'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L103: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L105: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L109: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L175: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L196: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L197: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L198: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L199: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L200: `Cannot access offset 'scroll_speed' on mixed.` <sub>(cannot-access)</sub>
- L200: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L201: `Cannot access offset 'mouse_pattern' on mixed.` <sub>(cannot-access)</sub>
- L201: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L202: `Cannot access offset 'pause_count' on mixed.` <sub>(cannot-access)</sub>
- L202: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L203: `Cannot access offset 'focus_blur_count' on mixed.` <sub>(cannot-access)</sub>
- L203: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L204: `Cannot access offset 'client_mode' on mixed.` <sub>(cannot-access)</sub>
- L204: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L205: `Cannot access offset 'target_opened' on mixed.` <sub>(cannot-access)</sub>
- L206: `Cannot access offset 'interaction_types' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Models/FileAccess.php`  (28 خطا)
<sub>دستهها: always-true=14, cannot-access=14</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L30: `Cannot access property $user_id on mixed.` <sub>(cannot-access)</sub>
- L43: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L44: `Cannot access property $user_id on mixed.` <sub>(cannot-access)</sub>
- L59: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L60: `Cannot access property $executor_id on mixed.` <sub>(cannot-access)</sub>
- L60: `Cannot access property $user_id on mixed.` <sub>(cannot-access)</sub>
- L73: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L75: `Cannot access property $creator_id on mixed.` <sub>(cannot-access)</sub>
- L87: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L101: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L102: `Cannot access property $user_id on mixed.` <sub>(cannot-access)</sub>
- L114: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L130: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L131: `Cannot access property $executor_id on mixed.` <sub>(cannot-access)</sub>
- L131: `Cannot access property $user_id on mixed.` <sub>(cannot-access)</sub>
- L145: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L146: `Cannot access property $customer_id on mixed.` <sub>(cannot-access)</sub>
- L146: `Cannot access property $influencer_user_id on mixed.` <sub>(cannot-access)</sub>
- L161: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L162: `Cannot access property $customer_id on mixed.` <sub>(cannot-access)</sub>
- L162: `Cannot access property $influencer_user_id on mixed.` <sub>(cannot-access)</sub>
- L175: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L176: `Cannot access property $user_id on mixed.` <sub>(cannot-access)</sub>
- L192: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L193: `Cannot access property $user_id on mixed.` <sub>(cannot-access)</sub>
- L206: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>
- L219: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Controllers/Api/UserController.php`  (26 خطا)
<sub>دستهها: type-mismatch/expects=14, cast-mixed(int)=6, cast-mixed(string)=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L90: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L107: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L122: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L132: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L147: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L149: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L152: `Parameter #5 $attachments of method App\Services\TicketService::reply() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L156: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L166: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L172: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L210: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L215: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L223: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L228: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L243: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L248: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L290: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L296: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L323: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L336: `Parameter #1 $items of method App\Controllers\Api\BaseApiController::paginated() expects array<int, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L336: `Parameter #2 $total of method App\Controllers\Api\BaseApiController::paginated() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L344: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L345: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L352: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L366: `Parameter #2 $message of method App\Controllers\Api\BaseApiController::success() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L368: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Search/ModuleSearchGateway.php`  (26 خطا)
<sub>دستهها: type-mismatch/expects=14, return-type-mismatch(array)=10, cast-mixed(string)=1, always-condition=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L59: `Method App\Services\Search\ModuleSearchGateway::searchSocialTasks() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L59: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L77: `Method App\Services\Search\ModuleSearchGateway::searchVitrine() should return array<int, stdClass> but returns array<string, array|int>.` <sub>(return-type-mismatch(array))</sub>
- L77: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L87: `Method App\Services\Search\ModuleSearchGateway::searchCustomTasks() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L87: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L96: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L105: `Method App\Services\Search\ModuleSearchGateway::searchPredictions() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L105: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L114: `Method App\Services\Search\ModuleSearchGateway::searchLotteries() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L114: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L123: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L132: `Method App\Services\Search\ModuleSearchGateway::searchCoupons() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L132: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L141: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L151: `Method App\Services\Search\ModuleSearchGateway::searchSeoAds() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L151: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L160: `Method App\Services\Search\ModuleSearchGateway::searchDirectMessages() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L160: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L169: `Method App\Services\Search\ModuleSearchGateway::searchRegistered() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L210: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L216: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L220: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L228: `Method App\Services\Search\ModuleSearchGateway::searchVitrineRead() should return array{items: array<int, stdClass>, total: int, facets: array} but returns array{items: null, total: int, facets: array{}, source: 'live'}.` <sub>(return-type-mismatch(array))</sub>
- L235: `Variable $total on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>

</details>

### `core/Cache.php`  (26 خطا)
<sub>دستهها: cannot-call-on-nullable=17, type-mismatch/expects=4, always-evaluate=2, OTHER=1, cast-mixed(int)=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L72: `Unsafe usage of new static().` <sub>(OTHER)</sub>
- L242: `Cannot call method setEx() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L304: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L327: `Cannot call method exists() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L336: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L348: `Cannot call method scan() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L350: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L423: `Cannot call method setex() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L456: `Cannot call method eval() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L457: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L534: `Cannot call method eval() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L535: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L595: `Cannot call method ttl() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L604: `Strict comparison using === between array and false will always evaluate to false.` <sub>(always-evaluate)</sub>
- L675: `Cannot call method set() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L682: `Property Core\Cache::$redisLocks (array<string, bool>) does not accept array<string, bool|string>.` <sub>(type-mismatch/expects)</sub>
- L711: `Property Core\Cache::$fileLocks (array<string, bool>) does not accept array<string, bool|resource>.` <sub>(type-mismatch/expects)</sub>
- L742: `Cannot call method eval() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L751: `Parameter #1 $stream of function flock expects resource, bool given.` <sub>(type-mismatch/expects)</sub>
- L752: `Parameter #1 $stream of function fclose expects resource, bool given.` <sub>(type-mismatch/expects)</sub>
- L831: `Strict comparison using === between array and false will always evaluate to false.` <sub>(always-evaluate)</sub>
- L1031: `Cannot call method sMembers() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L1033: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L1035: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L1069: `Cannot call method sAdd() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L1104: `Cannot call method sRem() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `app/Controllers/User/BugReportController.php`  (25 خطا)
<sub>دستهها: type-mismatch/expects=11, cast-mixed(string)=8, no-return-type=3, cast-mixed(int)=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L26: `Method App\Controllers\User\BugReportController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L43: `Parameter #2 $subject of function preg_match expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L57: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L58: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L59: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L60: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L61: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L65: `Parameter #1 $array of function reset is passed by reference, so it expects variables only.` <sub>(type-mismatch/expects)</sub>
- L70: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L71: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L72: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L78: `Parameter #1 $string of function strtolower expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L88: `Parameter #1 $string of function htmlspecialchars expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L90: `Parameter #1 $string of function htmlspecialchars expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L91: `Parameter #1 $string of function htmlspecialchars expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L93: `Parameter #1 $string of function substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L100: `Parameter #1 $path of function basename expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L114: `Parameter #1 $filename of function file_exists expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L120: `Parameter #2 $filename of function finfo_file expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L163: `Method App\Controllers\User\BugReportController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L183: `Method App\Controllers\User\BugReportController::show() has no return type specified.` <sub>(no-return-type)</sub>
- L187: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L211: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L221: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/CryptoDepositController.php`  (25 خطا)
<sub>دستهها: cannot-access=7, unreachable=6, cast-mixed(string)=5, no-return-type=2, cast-mixed(float)=2, never-read-property=1, cast-mixed(int)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L11: `Property App\Controllers\User\CryptoDepositController::$idempotencyService is never read, only written.` <sub>(never-read-property)</sub>
- L51: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L58: `Method App\Controllers\User\CryptoDepositController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L67: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L80: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L88: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L91: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L108: `Cannot access offset 'network' on mixed.` <sub>(cannot-access)</sub>
- L108: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L109: `Cannot access offset 'requested_amount' on mixed.` <sub>(cannot-access)</sub>
- L109: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L123: `Method App\Controllers\User\CryptoDepositController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L127: `Cannot access offset 'tx_hash' on mixed.` <sub>(cannot-access)</sub>
- L127: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L128: `Cannot access offset 'network' on mixed.` <sub>(cannot-access)</sub>
- L128: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L129: `Cannot access offset 'tx_hash' on mixed.` <sub>(cannot-access)</sub>
- L157: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L166: `Cannot access offset 'intent_id' on mixed.` <sub>(cannot-access)</sub>
- L166: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L175: `Cannot access offset 'from_wallet' on mixed.` <sub>(cannot-access)</sub>
- L175: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L182: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L184: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L201: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Controllers/User/TicketController.php`  (25 خطا)
<sub>دستهها: type-mismatch/expects=8, cast-mixed(int)=4, cannot-access=4, never-read-property=3, no-return-type=3, cast-mixed(string)=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L14: `Property App\Controllers\User\TicketController::$ticketModel is never read, only written.` <sub>(never-read-property)</sub>
- L15: `Property App\Controllers\User\TicketController::$messageModel is never read, only written.` <sub>(never-read-property)</sub>
- L16: `Property App\Controllers\User\TicketController::$categoryModel is never read, only written.` <sub>(never-read-property)</sub>
- L41: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L71: `Method App\Controllers\User\TicketController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L86: `Method App\Controllers\User\TicketController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L92: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L125: `Parameter #1 $string of function htmlspecialchars expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L128: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L133: `Parameter #1 $string of function htmlspecialchars expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L160: `Parameter #1 $path of function basename expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L162: `Parameter #1 $string of function htmlspecialchars expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L186: `Method App\Controllers\User\TicketController::show() has no return type specified.` <sub>(no-return-type)</sub>
- L223: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L252: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L256: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L302: `Cannot access offset (int|string) on mixed.` <sub>(cannot-access)</sub>
- L303: `Cannot access offset (int|string) on mixed.` <sub>(cannot-access)</sub>
- L304: `Cannot access offset (int|string) on mixed.` <sub>(cannot-access)</sub>
- L305: `Cannot access offset (int|string) on mixed.` <sub>(cannot-access)</sub>
- L317: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L342: `Parameter #1 $string of function htmlspecialchars expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L354: `Parameter #5 $attachments of method App\Services\TicketService::reply() expects array<string, mixed>, array<int<0, max>, array<string, string>> given.` <sub>(type-mismatch/expects)</sub>
- L366: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/VitrineController.php`  (25 خطا)
<sub>دستهها: type-mismatch/expects=6, unreachable=5, cast-mixed(float)=5, cast-mixed(int)=4, no-return-type=2, cannot-access=2, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Controllers\User\VitrineController::$flags is never read, only written.` <sub>(never-read-property)</sub>
- L54: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L79: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L95: `Method App\Controllers\User\VitrineController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L102: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L120: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L135: `Method App\Controllers\User\VitrineController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L148: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L152: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L153: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L154: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L159: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L167: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L168: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L169: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L170: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L171: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L174: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L192: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L197: `Cannot access property $status on mixed.` <sub>(cannot-access)</sub>
- L203: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L207: `Cannot access property $title on mixed.` <sub>(cannot-access)</sub>
- L258: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L259: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L313: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/SocialTask/SilentAntiFraudService.php`  (25 خطا)
<sub>دستهها: cast-mixed(float)=13, type-mismatch/expects=6, cast-mixed(int)=5, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L80: `Method App\Services\SocialTask\SilentAntiFraudService::_calculateRiskScore() is unused.` <sub>(unused)</sub>
- L82: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L83: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L84: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L90: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L91: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L92: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L93: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L98: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L109: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L159: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L160: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L161: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L194: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L208: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L209: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L290: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L291: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L292: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L293: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L295: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L296: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L297: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L298: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L299: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Controllers/Admin/AccountDeletionManagementController.php`  (24 خطا)
<sub>دستهها: always-evaluate=8, always-condition=8, cast-mixed(int)=4, no-return-type=3, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L88: `Method App\Controllers\Admin\AccountDeletionManagementController::stats() has no return type specified.` <sub>(no-return-type)</sub>
- L130: `Method App\Controllers\Admin\AccountDeletionManagementController::forceDelete() has no return type specified.` <sub>(no-return-type)</sub>
- L133: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L161: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L171: `Method App\Controllers\Admin\AccountDeletionManagementController::cancelDeletion() has no return type specified.` <sub>(no-return-type)</sub>
- L174: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L207: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L229: `Call to function is_array() with App\Models\User will always evaluate to false.` <sub>(always-evaluate)</sub>
- L229: `Offset 'email' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L230: `Call to function is_array() with App\Models\User will always evaluate to false.` <sub>(always-evaluate)</sub>
- L230: `Offset 'mobile' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L231: `Call to function is_array() with App\Models\User will always evaluate to false.` <sub>(always-evaluate)</sub>
- L231: `Offset 'national_id' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L232: `Call to function is_array() with App\Models\User will always evaluate to false.` <sub>(always-evaluate)</sub>
- L232: `Offset 'full_name' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L233: `Call to function is_array() with App\Models\User will always evaluate to false.` <sub>(always-evaluate)</sub>
- L233: `Offset 'username' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L234: `Call to function is_array() with App\Models\User will always evaluate to false.` <sub>(always-evaluate)</sub>
- L234: `Offset 'id' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L235: `Call to function is_array() with App\Models\User will always evaluate to false.` <sub>(always-evaluate)</sub>
- L235: `Offset 'created_at' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L236: `Call to function is_array() with App\Models\User will always evaluate to false.` <sub>(always-evaluate)</sub>
- L236: `Offset 'last_activity_at' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L335: `Method App\Controllers\Admin\AccountDeletionManagementController::calculateUserDataSize() is unused.` <sub>(unused)</sub>

</details>

### `app/Controllers/Admin/SentryAdminController.php`  (24 خطا)
<sub>دستهها: type-mismatch/expects=13, cast-mixed(int)=8, cast-mixed(string)=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L64: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L67: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L69: `Parameter #2 $status of method App\Services\Sentry\Analytics\DashboardService::getIssuesList() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L101: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L103: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L120: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L183: `Parameter #2 $period of method App\Services\Sentry\Analytics\DashboardService::getTimeSeriesData() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L196: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L199: `Parameter #1 $metric of method App\Services\Sentry\Analytics\TrendAnalyzer::analyzeTrends() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L202: `Parameter #1 $metric of method App\Services\Sentry\Analytics\DashboardService::getTimeSeriesData() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L227: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L229: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L250: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L271: `Parameter #1 $startDate of method App\Services\Sentry\Audit\AdvancedAuditTrail::generateComplianceReport() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L271: `Parameter #2 $endDate of method App\Services\Sentry\Audit\AdvancedAuditTrail::generateComplianceReport() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L271: `Parameter #3 $type of method App\Services\Sentry\Audit\AdvancedAuditTrail::generateComplianceReport() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L302: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L307: `Parameter #3 $note of method App\Services\Sentry\Analytics\DashboardService::resolveIssue() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L319: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L322: `Parameter #2 $duration of method App\Services\Sentry\Analytics\DashboardService::muteIssue() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L338: `Parameter #1 $metric of method App\Services\Sentry\Analytics\DashboardService::getTimeSeriesData() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L338: `Parameter #2 $period of method App\Services\Sentry\Analytics\DashboardService::getTimeSeriesData() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L338: `Parameter #3 $interval of method App\Services\Sentry\Analytics\DashboardService::getTimeSeriesData() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L340: `Parameter #1 $data of method Core\Response::json() expects array<string, mixed>, array<int, array<string, mixed>> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Models/ReferralCommission.php`  (24 خطا)
<sub>دستهها: cast-mixed(int)=7, cast-mixed(string)=5, always-false=4, cast-mixed(float)=2, always-true=2, return-type-mismatch(stdClass)=1, unreachable=1, cannot-access=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L15: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L18: `Method App\Models\ReferralCommission::fetchOne() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L28: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L37: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L81: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L85: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L86: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L87: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L88: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L90: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L91: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L92: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L93: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L99: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L118: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L206: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L264: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L275: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L286: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L377: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L379: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L394: `Method App\Models\ReferralCommission::globalStats() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L394: `Ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/AntiFraud/SeoFraudDetector.php`  (23 خطا)
<sub>دستهها: type-mismatch/expects=11, cannot-access=7, never-read-property=2, cast-mixed(int)=2, OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L15: `Property App\Services\AntiFraud\SeoFraudDetector::$fingerprintService is never read, only written.` <sub>(never-read-property)</sub>
- L16: `Property App\Services\AntiFraud\SeoFraudDetector::$anomalyService is never read, only written.` <sub>(never-read-property)</sub>
- L60: `Parameter #2 ...$arrays of function array_merge expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L150: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L151: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L160: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L168: `Cannot access offset 'click_timings' on mixed.` <sub>(cannot-access)</sub>
- L169: `Parameter #1 $value of function count expects array|Countable, mixed given.` <sub>(type-mismatch/expects)</sub>
- L171: `Parameter #1 $value of function count expects array|Countable, mixed given.` <sub>(type-mismatch/expects)</sub>
- L172: `Cannot access offset int<0, max> on mixed.` <sub>(cannot-access)</sub>
- L172: `Cannot access offset int<1, max> on mixed.` <sub>(cannot-access)</sub>
- L191: `Cannot access offset 'mouse_speeds' on mixed.` <sub>(cannot-access)</sub>
- L192: `Parameter #1 $value of function count expects array|Countable, mixed given.` <sub>(type-mismatch/expects)</sub>
- L193: `Parameter #1 $array of function array_sum expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L193: `Parameter #1 $value of function count expects array|Countable, mixed given.` <sub>(type-mismatch/expects)</sub>
- L195: `Argument of an invalid type mixed supplied for foreach, only iterables are supported.` <sub>(OTHER)</sub>
- L198: `Parameter #1 $value of function count expects array|Countable, mixed given.` <sub>(type-mismatch/expects)</sub>
- L209: `Cannot access offset 'scroll_pattern' on mixed.` <sub>(cannot-access)</sub>
- L217: `Cannot access offset 'mouse_events_count' on mixed.` <sub>(cannot-access)</sub>
- L217: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L218: `Cannot access offset 'key_events_count' on mixed.` <sub>(cannot-access)</sub>
- L218: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L277: `Parameter #1 $fingerprint of method App\Models\IpAndDeviceModel::isBlacklisted() expects string, int given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/FeatureFlagService.php`  (23 خطا)
<sub>دستهها: type-mismatch/expects=16, return-type-mismatch(array)=3, never-read-property=1, unused=1, cast-mixed(int)=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Property App\Services\FeatureFlagService::$cacheInvalidation is never read, only written.` <sub>(never-read-property)</sub>
- L180: `Method App\Services\FeatureFlagService::getEnabled() should return array<int, object> but returns array<int<0, max>, string>.` <sub>(return-type-mismatch(array))</sub>
- L194: `Parameter #1 $json of function json_decode expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L272: `Parameter #1 $haystack of function strpos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L272: `Parameter #1 $haystack of function strpos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L374: `Method App\Services\FeatureFlagService::calculateAge() is unused.` <sub>(unused)</sub>
- L473: `Property App\Models\FeatureFlag::$description (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L475: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L481: `Property App\Models\FeatureFlag::$metadata (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L482: `Property App\Models\FeatureFlag::$enabled_from (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L483: `Property App\Models\FeatureFlag::$enabled_until (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L486: `Property App\Models\FeatureFlag::$priority (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L488: `Property App\Models\FeatureFlag::$min_age (int|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L489: `Property App\Models\FeatureFlag::$max_age (int|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L490: `Property App\Models\FeatureFlag::$created_at (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L491: `Property App\Models\FeatureFlag::$updated_at (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L586: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L636: `Parameter #1 $name of method App\Models\FeatureFlag::findByName() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L637: `Part $data['name'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L665: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L674: `Parameter #1 $featureName of class App\Events\FeatureFlagChanged constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L714: `Method App\Services\FeatureFlagService::getHistory() should return array<int, stdClass> but returns array<int, object>.` <sub>(return-type-mismatch(array))</sub>
- L730: `Method App\Services\FeatureFlagService::getMetrics() should return array<int, stdClass> but returns array<int, object>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Controllers/Api/TokenController.php`  (22 خطا)
<sub>دستهها: type-mismatch/expects=13, cast-mixed(string)=8, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L43: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L54: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L55: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L56: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L62: `Parameter #1 $errors of method App\Controllers\Api\BaseApiController::validationError() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L66: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L66: `Parameter #2 $code of method App\Controllers\Api\BaseApiController::error() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L66: `Parameter #3 $errorCode of method App\Controllers\Api\BaseApiController::error() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L81: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L91: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L91: `Parameter #2 $code of method App\Controllers\Api\BaseApiController::error() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L91: `Parameter #3 $errorCode of method App\Controllers\Api\BaseApiController::error() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L109: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L120: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L120: `Parameter #2 $code of method App\Controllers\Api\BaseApiController::error() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L120: `Parameter #3 $errorCode of method App\Controllers\Api\BaseApiController::error() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L142: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L151: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L151: `Parameter #2 $code of method App\Controllers\Api\BaseApiController::error() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L151: `Parameter #3 $errorCode of method App\Controllers\Api\BaseApiController::error() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L161: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/SocialAccount.php`  (22 خطا)
<sub>دستهها: type-mismatch/expects=12, cast-mixed(int)=7, return-type-mismatch(array)=2, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L49: `Parameter #1 $row of method App\Models\SocialAccount::hydrate() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L65: `Parameter #1 $row of method App\Models\SocialAccount::hydrate() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L82: `Method App\Models\SocialAccount::getByUser() should return array<int, array<string, mixed>> but returns array<App\Models\SocialAccount>.` <sub>(return-type-mismatch(array))</sub>
- L99: `Method App\Models\SocialAccount::getVerifiedByUser() should return array<int, array<string, mixed>> but returns array<App\Models\SocialAccount>.` <sub>(return-type-mismatch(array))</sub>
- L354: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L355: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L356: `Property App\Models\SocialAccount::$platform (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L357: `Property App\Models\SocialAccount::$username (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L358: `Property App\Models\SocialAccount::$profile_url (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L359: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L360: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L361: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L362: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L363: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L364: `Property App\Models\SocialAccount::$status (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L365: `Property App\Models\SocialAccount::$rejection_reason (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L366: `Property App\Models\SocialAccount::$rejection_history (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L367: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L368: `Property App\Models\SocialAccount::$verified_at (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L370: `Property App\Models\SocialAccount::$created_at (string) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L371: `Property App\Models\SocialAccount::$updated_at (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>
- L372: `Property App\Models\SocialAccount::$deleted_at (string|null) does not accept mixed.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/AntiFraud/VelocityCheckService.php`  (22 خطا)
<sub>دستهها: type-mismatch/expects=11, cannot-access=7, cast-mixed(float)=2, cast-mixed(int)=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L123: `Property App\Services\AntiFraud\VelocityCheckService::$activeLocks (array<string, bool>) does not accept array<string, bool|string|null>.` <sub>(type-mismatch/expects)</sub>
- L135: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L170: `Cannot access offset 'limit' on mixed.` <sub>(cannot-access)</sub>
- L171: `Cannot access offset 'period' on mixed.` <sub>(cannot-access)</sub>
- L177: `Parameter #3 $seconds of method App\Models\VelocityAndScoreModel::getTransactionCount() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L179: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L180: `Parameter #3 $minutes of method Core\Cache::set() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L220: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L237: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L268: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L286: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L338: `Cannot access offset 'period' on mixed.` <sub>(cannot-access)</sub>
- L338: `Parameter #3 $minutes of method Core\Cache::set() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L356: `Parameter #2 $token of method App\Services\DistributedLockService::release() expects string, bool given.` <sub>(type-mismatch/expects)</sub>
- L364: `Parameter #2 $token of method App\Services\DistributedLockService::release() expects string, bool given.` <sub>(type-mismatch/expects)</sub>
- L398: `Cannot access offset 'period' on mixed.` <sub>(cannot-access)</sub>
- L398: `Parameter #3 $seconds of method App\Models\VelocityAndScoreModel::getTransactionCount() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L399: `Cannot access offset 'limit' on mixed.` <sub>(cannot-access)</sub>
- L419: `Method App\Services\AntiFraud\VelocityCheckService::getRules() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L443: `Cannot access offset 'period' on mixed.` <sub>(cannot-access)</sub>
- L443: `Parameter #3 $seconds of method App\Models\VelocityAndScoreModel::getTransactionCount() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L444: `Cannot access offset 'limit' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Sentry/Alerting/AlertDispatcher.php`  (22 خطا)
<sub>دستهها: encapsed-string=12, type-mismatch/expects=9, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Method App\Services\Sentry\Alerting\AlertDispatcher::toObject() is unused.` <sub>(unused)</sub>
- L185: `Parameter #1 $severity of method App\Models\SentryModel::getActiveChannels() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L239: `Parameter #2 $severity of method App\Models\SentryModel::getLastAlert() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L303: `Part $config['bot_token'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L356: `Part $alert['severity'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L356: `Part $alert['title'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L388: `Parameter #1 $severity of method App\Services\Sentry\Alerting\AlertDispatcher::getSeverityColor() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L391: `Parameter #1 $string of function strtoupper expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L400: `Parameter #1 $url of method App\Services\Sentry\Alerting\AlertDispatcher::isSafeUrl() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L407: `Parameter #1 $url of function curl_init expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L443: `Parameter #1 $url of method App\Services\Sentry\Alerting\AlertDispatcher::isSafeUrl() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L450: `Parameter #1 $url of function curl_init expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L487: `Part $alert['title'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L488: `Part $alert['message'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L489: `Part $alert['severity'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L490: `Part $alert['environment'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L492: `Part $alert['event_id'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L501: `Parameter #1 $severity of method App\Services\Sentry\Alerting\AlertDispatcher::getSeverityColor() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L505: `Part $alert['title'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L506: `Part $alert['message'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L508: `Part $alert['severity'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L509: `Part $alert['environment'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Services/Sentry/PerformanceMonitoring/SentryPerformanceMonitor.php`  (22 خطا)
<sub>دستهها: cannot-access=8, type-mismatch/expects=6, return-type-mismatch(array)=3, unused=1, never-read-property=1, encapsed-string=1, OTHER=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Method App\Services\Sentry\PerformanceMonitoring\SentryPerformanceMonitor::toObject() is unused.` <sub>(unused)</sub>
- L35: `Property App\Services\Sentry\PerformanceMonitoring\SentryPerformanceMonitor::$startTime is never read, only written.` <sub>(never-read-property)</sub>
- L138: `Property App\Services\Sentry\PerformanceMonitoring\SentryPerformanceMonitor::$spans (array<int, array<string, mixed>>) does not accept array<int|string, array<string, mixed>>.` <sub>(type-mismatch/expects)</sub>
- L161: `Property App\Services\Sentry\PerformanceMonitoring\SentryPerformanceMonitor::$spans (array<int, array<string, mixed>>) does not accept array<int|string, array<string, mixed>>.` <sub>(type-mismatch/expects)</sub>
- L163: `Parameter #1 ...$arrays of function array_merge expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L203: `Parameter #1 $num of function round expects float|int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L219: `Cannot access offset 'count' on mixed.` <sub>(cannot-access)</sub>
- L219: `Part $nPlusOne['count'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L220: `Cannot access offset 'pattern' on mixed.` <sub>(cannot-access)</sub>
- L221: `Cannot access offset 'count' on mixed.` <sub>(cannot-access)</sub>
- L222: `Cannot access offset 'total_duration' on mixed.` <sub>(cannot-access)</sub>
- L256: `Method App\Services\Sentry\PerformanceMonitoring\SentryPerformanceMonitor::detectPerformanceIssues() should return array<string, mixed> but returns array<int<0, max>, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L291: `Argument of an invalid type mixed supplied for foreach, only iterables are supported.` <sub>(OTHER)</sub>
- L292: `Cannot access offset 'severity' on mixed.` <sub>(cannot-access)</sub>
- L296: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L297: `Cannot access offset 'message' on mixed.` <sub>(cannot-access)</sub>
- L301: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L326: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L355: `Parameter #2 $callback of function array_filter expects (callable(array<string, mixed>): bool)|null, Closure(mixed): mixed given.` <sub>(type-mismatch/expects)</sub>
- L399: `Method App\Services\Sentry\PerformanceMonitoring\SentryPerformanceMonitor::getSlowestTransactions() should return array<int, array<string, mixed>> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L407: `Parameter #1 $query of method App\Services\Sentry\PerformanceMonitoring\SentryPerformanceMonitor::getQueryPattern() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L424: `Method App\Services\Sentry\PerformanceMonitoring\SentryPerformanceMonitor::detectNPlusOneQueries() should return array<string, mixed> but returns array<int<0, max>, array<string, float|int|string>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Controllers/User/ManualDepositController.php`  (21 خطا)
<sub>دستهها: unreachable=7, cast-mixed(string)=3, no-return-type=2, cast-mixed(int)=2, type-mismatch/expects=2, always-condition=2, never-read-property=1, always-evaluate=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Property App\Controllers\User\ManualDepositController::$idempotencyService is never read, only written.` <sub>(never-read-property)</sub>
- L37: `Method App\Controllers\User\ManualDepositController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L48: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L60: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L86: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L93: `Method App\Controllers\User\ManualDepositController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L129: `Call to function is_string() with array{}|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L137: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L142: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L170: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L171: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L172: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L173: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L178: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L181: `Part $data['amount'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L190: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L199: `Variable $requestId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L203: `Variable $ipAddress on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L213: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L226: `Parameter #2 $operatorOrValue of method Core\Model::where() expects string, int given.` <sub>(type-mismatch/expects)</sub>
- L245: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Models/Transaction.php`  (21 خطا)
<sub>دستهها: cast-mixed(string)=8, return-type-mismatch(stdClass)=4, cannot-access=3, type-mismatch/expects=2, return-type-mismatch(array)=2, always-true=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L53: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L57: `Parameter #1 $key of method App\Models\Transaction::findByIdempotencyKey() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L101: `Parameter #1 $key of method App\Models\Transaction::findByIdempotencyKey() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L127: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L323: `Method App\Models\Transaction::getLatestEvent() should return array<string, mixed>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L344: `Method App\Models\Transaction::findByTransactionId() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L362: `Method App\Models\Transaction::findById() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L392: `Method App\Models\Transaction::findByExternalId() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L404: `Method App\Models\Transaction::findByIdempotencyKey() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L467: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>
- L542: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>
- L558: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L559: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L560: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L561: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L562: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L563: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L564: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L633: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L651: `Method App\Models\Transaction::getDailyReport() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L690: `Method App\Models\Transaction::searchNative() should return array<int, array<string, mixed>> but returns array<string, array<int, stdClass>|int>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Analytics/AnalyticsQueryService.php`  (21 خطا)
<sub>دستهها: return-type-mismatch(array)=19, return-type-mismatch=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L66: `Method App\Services\Analytics\AnalyticsQueryService::getUserStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L102: `Method App\Services\Analytics\AnalyticsQueryService::getFinancialStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L116: `Method App\Services\Analytics\AnalyticsQueryService::getTaskStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L123: `Method App\Services\Analytics\AnalyticsQueryService::getTicketStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L130: `Method App\Services\Analytics\AnalyticsQueryService::getFraudStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L136: `Method App\Services\Analytics\AnalyticsQueryService::getChurnRate() should return float but returns mixed.` <sub>(return-type-mismatch)</sub>
- L142: `Method App\Services\Analytics\AnalyticsQueryService::getConversionRate() should return float but returns mixed.` <sub>(return-type-mismatch)</sub>
- L149: `Method App\Services\Analytics\AnalyticsQueryService::getTasksByPlatform() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L156: `Method App\Services\Analytics\AnalyticsQueryService::getHourlyActivity() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L163: `Method App\Services\Analytics\AnalyticsQueryService::getInvestmentStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L170: `Method App\Services\Analytics\AnalyticsQueryService::getReferralStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L177: `Method App\Services\Analytics\AnalyticsQueryService::getTopUsers() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L184: `Method App\Services\Analytics\AnalyticsQueryService::getLotteryStats() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L223: `Method App\Services\Analytics\AnalyticsQueryService::getCustomTaskStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L235: `Method App\Services\Analytics\AnalyticsQueryService::getCreatorDashboard() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L247: `Method App\Services\Analytics\AnalyticsQueryService::getWorkerDashboard() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L259: `Method App\Services\Analytics\AnalyticsQueryService::getTrendingTasks() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L275: `Method App\Services\Analytics\AnalyticsQueryService::getDailyRegistrations() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L286: `Method App\Services\Analytics\AnalyticsQueryService::getDailyRevenue() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L297: `Method App\Services\Analytics\AnalyticsQueryService::getDailyDepositsWithdrawals() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L307: `Method App\Services\Analytics\AnalyticsQueryService::getDailyCompletedTasks() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/AntiFraud/DeviceIntelligenceService.php`  (21 خطا)
<sub>دستهها: type-mismatch/expects=15, cast-mixed(string)=4, cannot-access=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L81: `Parameter #1 $haystack of function stripos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L108: `Parameter #1 $haystack of function stripos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L114: `Parameter #1 $haystack of function stripos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L122: `Parameter #1 $haystack of function stripos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L133: `Parameter #1 $haystack of function stripos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L133: `Parameter #1 $haystack of function stripos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L181: `Parameter #2 $subject of function preg_match expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L221: `Parameter #2 $haystack of function in_array expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L275: `Parameter #1 $haystack of function stripos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L300: `Parameter #1 $ua of method App\Services\AntiFraud\DeviceIntelligenceService::extractPlatformFromUA() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L316: `Parameter #1 $haystack of function stripos expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L431: `Parameter #1 $highestRisk of method App\Services\AntiFraud\DeviceIntelligenceService::getRecommendation() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L450: `Parameter #2 $array of function implode expects array<string>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L450: `Parameter #2 $array of function implode expects array|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L464: `Cannot access offset 'level' on mixed.` <sub>(cannot-access)</sub>
- L465: `Cannot access offset 'charging' on mixed.` <sub>(cannot-access)</sub>
- L487: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L544: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L549: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L552: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L557: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/Admin/AuditTrailController.php`  (20 خطا)
<sub>دستهها: cast-mixed(int)=6, no-return-type=5, cast-mixed(string)=5, always-false=2, never-read-property=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Property App\Controllers\Admin\AuditTrailController::$searchService is never read, only written.` <sub>(never-read-property)</sub>
- L41: `Method App\Controllers\Admin\AuditTrailController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L45: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L46: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L47: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L48: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L49: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L50: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L115: `Method App\Controllers\Admin\AuditTrailController::show() has no return type specified.` <sub>(no-return-type)</sub>
- L118: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L148: `Method App\Controllers\Admin\AuditTrailController::stats() has no return type specified.` <sub>(no-return-type)</sub>
- L150: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L150: `Ternary operator condition is always false.` <sub>(always-false)</sub>
- L152: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L152: `Ternary operator condition is always false.` <sub>(always-false)</sub>
- L177: `Method App\Controllers\Admin\AuditTrailController::userHistory() has no return type specified.` <sub>(no-return-type)</sub>
- L180: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L182: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L209: `Method App\Controllers\Admin\AuditTrailController::export() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/Admin/CouponController.php`  (20 خطا)
<sub>دستهها: cast-mixed(int)=12, no-return-type=4, unreachable=2, never-read-property=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Property App\Controllers\Admin\CouponController::$redemptionModel is never read, only written.` <sub>(never-read-property)</sub>
- L48: `Method App\Controllers\Admin\CouponController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L59: `Method App\Controllers\Admin\CouponController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L77: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L95: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L132: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L133: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L139: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L152: `Method App\Controllers\Admin\CouponController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L154: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L155: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L187: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L218: `Method App\Controllers\Admin\CouponController::delete() has no return type specified.` <sub>(no-return-type)</sub>
- L220: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L221: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L247: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L248: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L280: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L281: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L287: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Models/KpiStatistics.php`  (20 خطا)
<sub>دستهها: cannot-access=8, return-type-mismatch(array)=6, cast-mixed(int)=5, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L128: `Cannot access offset 'by_platform' on mixed.` <sub>(cannot-access)</sub>
- L134: `Cannot access offset 'by_type' on mixed.` <sub>(cannot-access)</sub>
- L136: `Method App\Models\KpiStatistics::getTaskStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L162: `Cannot access offset 'total' on mixed.` <sub>(cannot-access)</sub>
- L162: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L163: `Cannot access offset 'open' on mixed.` <sub>(cannot-access)</sub>
- L163: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L164: `Cannot access offset 'in_progress' on mixed.` <sub>(cannot-access)</sub>
- L164: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L165: `Cannot access offset 'avg_hours' on mixed.` <sub>(cannot-access)</sub>
- L165: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L226: `Cannot access offset 'reports' on mixed.` <sub>(cannot-access)</sub>
- L226: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L227: `Cannot access offset 'detected' on mixed.` <sub>(cannot-access)</sub>
- L227: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L338: `Method App\Models\KpiStatistics::getHourlyActivity() should return array<int, array<string, mixed>> but returns array<int, int>.` <sub>(return-type-mismatch(array))</sub>
- L356: `Method App\Models\KpiStatistics::getInvestmentStats() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L373: `Method App\Models\KpiStatistics::getReferralStats() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L418: `Method App\Models\KpiStatistics::getLotteryStats() should return array<int, array<string, mixed>> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L477: `Method App\Models\KpiStatistics::getDailyDepositsWithdrawals() should return array<int, array<string, mixed>> but returns array<string, array>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/ContentService.php`  (20 خطا)
<sub>دستهها: cast-mixed(float)=10, cast-mixed(int)=6, never-read-property=1, cast-mixed(string)=1, always-condition=1, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L55: `Property App\Services\ContentService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L446: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L500: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L505: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L510: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L538: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L544: `Variable $adminId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L546: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L717: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L718: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L721: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L735: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L798: `Method App\Services\ContentService::escapeText() is unused.` <sub>(unused)</sub>
- L901: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L904: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L905: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L950: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L951: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L961: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L962: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `core/EventDispatcher.php`  (20 خطا)
<sub>دستهها: cannot-access=10, type-mismatch/expects=7, encapsed-string=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L84: `Cannot access offset 'listener' on callable(): mixed.` <sub>(cannot-access)</sub>
- L89: `Property Core\EventDispatcher::$listeners (array<string, array<int, callable(): mixed>>) does not accept non-empty-array<array<int, array{listener: mixed, priority: int}|(callable(): mixed)>>.` <sub>(type-mismatch/expects)</sub>
- L96: `Cannot access offset 'priority' on array{listener: mixed, priority: int}|(callable(): mixed).` <sub>(cannot-access)</sub>
- L96: `Cannot access offset 'priority' on array{listener: mixed, priority: int}|(callable(): mixed).` <sub>(cannot-access)</sub>
- L112: `Cannot access offset 'listener' on callable(): mixed.` <sub>(cannot-access)</sub>
- L117: `Property Core\EventDispatcher::$patternListeners (array<string, array<int, callable(): mixed>>) does not accept non-empty-array<string, array<int, array{listener: mixed, priority: int}|(callable(): mixed)>>.` <sub>(type-mismatch/expects)</sub>
- L123: `Cannot access offset 'priority' on array{listener: mixed, priority: int}|(callable(): mixed).` <sub>(cannot-access)</sub>
- L123: `Cannot access offset 'priority' on array{listener: mixed, priority: int}|(callable(): mixed).` <sub>(cannot-access)</sub>
- L167: `Property Core\EventDispatcher::$dispatchingStack (array<int, string>) does not accept array<int, mixed>.` <sub>(type-mismatch/expects)</sub>
- L180: `Parameter #2 $filename of function fnmatch expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L197: `Cannot access offset 'listener' on callable(): mixed.` <sub>(cannot-access)</sub>
- L401: `Cannot access offset 'event_name' on mixed.` <sub>(cannot-access)</sub>
- L402: `Cannot access offset 'event_data' on mixed.` <sub>(cannot-access)</sub>
- L403: `Cannot access offset 'event_class' on mixed.` <sub>(cannot-access)</sub>
- L421: `Parameter #1 $class of function class_exists expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L431: `Part $eventClass (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L431: `Part $eventName (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L440: `Parameter #1 $data of class Core\GenericEvent constructor expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L521: `Parameter #1 $string of function strtolower expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L570: `Method Core\EventDispatcher::getListeners() should return array<int, callable(): mixed> but returns array<string, array<int, callable(): mixed>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Console/Kernel.php`  (19 خطا)
<sub>دستهها: cast-mixed(int)=13, always-true=4, encapsed-string=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L34: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L55: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L80: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L81: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L159: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L166: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L170: `Part $result['ads_processed'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L170: `Part $result['total_sent'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L205: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L235: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L430: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L503: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>
- L504: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>
- L622: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>
- L660: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L670: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L1033: `Comparison operation ">" between int<1, max> and 0 is always true.` <sub>(always-true)</sub>
- L1069: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/WithdrawalController.php`  (19 خطا)
<sub>دستهها: cast-mixed(string)=5, always-condition=5, cast-mixed(int)=4, never-read-property=2, no-return-type=2, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Property App\Controllers\Admin\WithdrawalController::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L21: `Property App\Controllers\Admin\WithdrawalController::$reconciliationService is never read, only written.` <sub>(never-read-property)</sub>
- L48: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L49: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L50: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L75: `Variable $summary on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L101: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L109: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L131: `Variable $withdrawalId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L150: `Method App\Controllers\Admin\WithdrawalController::process() has no return type specified.` <sub>(no-return-type)</sub>
- L182: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L183: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L215: `Variable $withdrawalId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L234: `Method App\Controllers\Admin\WithdrawalController::reject() has no return type specified.` <sub>(no-return-type)</sub>
- L265: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L266: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L274: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L292: `Variable $withdrawalId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L293: `Variable $adminId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>

</details>

### `app/Services/CaptchaService.php`  (19 خطا)
<sub>دستهها: cast-mixed(int)=8, type-mismatch/expects=5, cast-mixed(string)=4, unused=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\CaptchaService::toObject() is unused.` <sub>(unused)</sub>
- L56: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L134: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L142: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L211: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L299: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L300: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L307: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L310: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L408: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L416: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L511: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L515: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L525: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L539: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L576: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L660: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L702: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L705: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `core/Container.php`  (19 خطا)
<sub>دستهها: type-mismatch/expects=8, generic-template-unresolved=6, cannot-call-on-nullable=3, never-read-property=1, always-evaluate=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L37: `Property Core\Container::$isLoggingMissing is never read, only written.` <sub>(never-read-property)</sub>
- L218: `Instanceof between object and Closure will always evaluate to false.` <sub>(always-evaluate)</sub>
- L224: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, string given.` <sub>(type-mismatch/expects)</sub>
- L224: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>
- L254: `Property Core\Container::$reflectionCacheUsage (array<string, int>) does not accept array<string, float|int>.` <sub>(type-mismatch/expects)</sub>
- L257: `Cannot call method isInstantiable() on mixed.` <sub>(cannot-call-on-nullable)</sub>
- L261: `Cannot call method getConstructor() on mixed.` <sub>(cannot-call-on-nullable)</sub>
- L264: `Cannot call method newInstanceArgs() on mixed.` <sub>(cannot-call-on-nullable)</sub>
- L267: `Parameter #2 $reflector of method Core\Container::injectProperties() expects ReflectionClass<object>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L299: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, string given.` <sub>(type-mismatch/expects)</sub>
- L299: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>
- L360: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, string given.` <sub>(type-mismatch/expects)</sub>
- L360: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>
- L380: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, string given.` <sub>(type-mismatch/expects)</sub>
- L380: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>
- L435: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, string given.` <sub>(type-mismatch/expects)</sub>
- L435: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>
- L483: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, string given.` <sub>(type-mismatch/expects)</sub>
- L483: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>

</details>

### `app/Controllers/Admin/AuthController.php`  (18 خطا)
<sub>دستهها: cast-mixed(int)=8, no-return-type=5, cast-mixed(string)=4, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Method App\Controllers\Admin\AuthController::showLogin() has no return type specified.` <sub>(no-return-type)</sub>
- L46: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L58: `Method App\Controllers\Admin\AuthController::login() has no return type specified.` <sub>(no-return-type)</sub>
- L62: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L63: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L200: `Method App\Controllers\Admin\AuthController::showVerify2FA() has no return type specified.` <sub>(no-return-type)</sub>
- L210: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L238: `Method App\Controllers\Admin\AuthController::verify2FA() has no return type specified.` <sub>(no-return-type)</sub>
- L248: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L268: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L279: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L308: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L316: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L323: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L328: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L336: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L342: `Parameter #2 $message of method App\Controllers\BaseController::json() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L348: `Method App\Controllers\Admin\AuthController::logout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/Admin/InvestmentController.php`  (18 خطا)
<sub>دستهها: cast-mixed(int)=9, no-return-type=6, type-mismatch/expects=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L44: `Method App\Controllers\Admin\InvestmentController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L53: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L54: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L88: `Method App\Controllers\Admin\InvestmentController::show() has no return type specified.` <sub>(no-return-type)</sub>
- L90: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L116: `Method App\Controllers\Admin\InvestmentController::trades() has no return type specified.` <sub>(no-return-type)</sub>
- L121: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L143: `Method App\Controllers\Admin\InvestmentController::tradeCreate() has no return type specified.` <sub>(no-return-type)</sub>
- L181: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L206: `Method App\Controllers\Admin\InvestmentController::applyProfitForm() has no return type specified.` <sub>(no-return-type)</sub>
- L239: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L241: `Parameter #4 $period of method App\Services\InvestmentService::applyWeeklyProfitLoss() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L250: `Method App\Controllers\Admin\InvestmentController::withdrawals() has no return type specified.` <sub>(no-return-type)</sub>
- L255: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L277: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L289: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L302: `Parameter #3 $reason of method App\Services\InvestmentService::rejectWithdrawal() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L312: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/ReferralController.php`  (18 خطا)
<sub>دستهها: no-return-type=4, never-read-property=3, cast-mixed(int)=3, encapsed-string=3, cannot-access=2, type-mismatch/expects=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L14: `Property App\Controllers\Admin\ReferralController::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L16: `Property App\Controllers\Admin\ReferralController::$referralCommissionModel is never read, only written.` <sub>(never-read-property)</sub>
- L18: `Property App\Controllers\Admin\ReferralController::$db is never read, only written.` <sub>(never-read-property)</sub>
- L35: `Method App\Controllers\Admin\ReferralController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L71: `Method App\Controllers\Admin\ReferralController::settings() has no return type specified.` <sub>(no-return-type)</sub>
- L82: `Method App\Controllers\Admin\ReferralController::saveSettings() has no return type specified.` <sub>(no-return-type)</sub>
- L111: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L126: `Method App\Controllers\Admin\ReferralController::userDetail() has no return type specified.` <sub>(no-return-type)</sub>
- L128: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L159: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L161: `Cannot access offset 'reason' on mixed.` <sub>(cannot-access)</sub>
- L164: `Parameter #2 $reason of method App\Services\Shared\ReferralService::cancelCommission() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L191: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L199: `Parameter #1 $currency of method App\Services\Shared\ReferralService::batchPay() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L214: `Part $results['failed'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L214: `Part $results['skipped'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L214: `Part $results['success'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Controllers/Admin/RoleController.php`  (18 خطا)
<sub>دستهها: no-return-type=6, cannot-access=5, cast-mixed(int)=4, type-mismatch/expects=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L31: `Method App\Controllers\Admin\RoleController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L45: `Method App\Controllers\Admin\RoleController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L60: `Method App\Controllers\Admin\RoleController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L80: `Parameter #1 $slug of method App\Models\Role::slugExists() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L103: `Cannot access property $id on int<min, -1>|int<1, max>.` <sub>(cannot-access)</sub>
- L103: `Parameter #2 $permissionIds of method App\Models\Role::syncPermissions() expects array<int, int>, array given.` <sub>(type-mismatch/expects)</sub>
- L107: `Cannot access property $id on int<min, -1>|int<1, max>.` <sub>(cannot-access)</sub>
- L108: `Cannot access property $name on int<min, -1>|int<1, max>.` <sub>(cannot-access)</sub>
- L109: `Cannot access property $slug on int<min, -1>|int<1, max>.` <sub>(cannot-access)</sub>
- L112: `Cannot access property $name on int<min, -1>|int<1, max>.` <sub>(cannot-access)</sub>
- L119: `Method App\Controllers\Admin\RoleController::edit() has no return type specified.` <sub>(no-return-type)</sub>
- L121: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L150: `Method App\Controllers\Admin\RoleController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L152: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L190: `Parameter #2 $permissionIds of method App\Models\Role::syncPermissions() expects array<int, int>, array given.` <sub>(type-mismatch/expects)</sub>
- L209: `Method App\Controllers\Admin\RoleController::delete() has no return type specified.` <sub>(no-return-type)</sub>
- L213: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L270: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/TicketController.php`  (18 خطا)
<sub>دستهها: no-return-type=5, cast-mixed(int)=5, type-mismatch/expects=4, never-read-property=3, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L15: `Property App\Controllers\Admin\TicketController::$ticketModel is never read, only written.` <sub>(never-read-property)</sub>
- L16: `Property App\Controllers\Admin\TicketController::$messageModel is never read, only written.` <sub>(never-read-property)</sub>
- L17: `Property App\Controllers\Admin\TicketController::$categoryModel is never read, only written.` <sub>(never-read-property)</sub>
- L38: `Method App\Controllers\Admin\TicketController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L47: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L48: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L86: `Method App\Controllers\Admin\TicketController::show() has no return type specified.` <sub>(no-return-type)</sub>
- L126: `Method App\Controllers\Admin\TicketController::reply() has no return type specified.` <sub>(no-return-type)</sub>
- L132: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L134: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L198: `Parameter #1 $string of function substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L205: `Method App\Controllers\Admin\TicketController::changeStatus() has no return type specified.` <sub>(no-return-type)</sub>
- L211: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L246: `Parameter #2 $status of method App\Services\TicketService::updateStatus() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L247: `Part $status (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L264: `Method App\Controllers\Admin\TicketController::assign() has no return type specified.` <sub>(no-return-type)</sub>
- L278: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L279: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Middleware/AuthMiddleware.php`  (18 خطا)
<sub>دستهها: cast-mixed(int)=10, OTHER=6, always-true=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Property App\Middleware\AuthMiddleware::$session is never written, only read.` <sub>(OTHER)</sub>
- L28: `Property App\Middleware\AuthMiddleware::$redis is never written, only read.` <sub>(OTHER)</sub>
- L31: `Property App\Middleware\AuthMiddleware::$appSettings is never written, only read.` <sub>(OTHER)</sub>
- L34: `Property App\Middleware\AuthMiddleware::$userModel is never written, only read.` <sub>(OTHER)</sub>
- L37: `Property App\Middleware\AuthMiddleware::$logger is never written, only read.` <sub>(OTHER)</sub>
- L40: `Property App\Middleware\AuthMiddleware::$userSettings is never written, only read.` <sub>(OTHER)</sub>
- L61: `Left side of && is always true.` <sub>(always-true)</sub>
- L65: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L69: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L71: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L129: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L138: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L163: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L171: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L194: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L216: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L222: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L249: `Cannot access property $email on stdClass|null.` <sub>(cannot-access)</sub>

</details>

### `app/Policies/RateLimitPolicy.php`  (18 خطا)
<sub>دستهها: cast-mixed(int)=9, cannot-call-on-nullable=3, type-mismatch/expects=2, cannot-access=2, always-true=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L81: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L81: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L83: `Parameter #2 $maxAttempts of method Core\RateLimiter::attempt() expects int|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L83: `Parameter #3 $decayMinutes of method Core\RateLimiter::attempt() expects int|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L180: `Cannot access offset 'max_attempts' on mixed.` <sub>(cannot-access)</sub>
- L180: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L181: `Cannot access offset 'decay_minutes' on mixed.` <sub>(cannot-access)</sub>
- L181: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L214: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L215: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L216: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L224: `Left side of && is always true.` <sub>(always-true)</sub>
- L226: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L226: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L230: `Cannot call method incr() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L232: `Cannot call method expire() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L251: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L262: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/Search/AdminSearchGateway.php`  (18 خطا)
<sub>دستهها: type-mismatch/expects=11, return-type-mismatch(array)=7</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L62: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L67: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L72: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L77: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L92: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L114: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L132: `Method App\Services\Search\AdminSearchGateway::searchBanners() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L132: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L141: `Method App\Services\Search\AdminSearchGateway::searchContent() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L168: `Method App\Services\Search\AdminSearchGateway::searchEmails() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L168: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L177: `Method App\Services\Search\AdminSearchGateway::searchInvestments() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L186: `Method App\Services\Search\AdminSearchGateway::searchTicketsAdmin() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L195: `Method App\Services\Search\AdminSearchGateway::searchInfluencersAdmin() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L195: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L202: `Method App\Services\Search\AdminSearchGateway::quickSearchSubmissions() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L202: `Parameter #6 $allowedFilters of method App\Services\Search\AdminSearchGateway::searchTable() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L240: `Parameter #4 $allowedFilters of method App\Services\Search\AdminSearchGateway::applyAllowedFilters() expects array<int, string>, array<string, mixed> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Search/AdminSearchProvider.php`  (18 خطا)
<sub>دستهها: return-type-mismatch(array)=12, type-mismatch/expects=5, always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L33: `Parameter #1 $haystack of function str_starts_with expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L34: `Parameter #3 $subject of function str_replace expects array|string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L41: `Parameter #1 $items of class App\Services\Search\SearchResult constructor expects array<int, stdClass>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L42: `Parameter #2 $total of class App\Services\Search\SearchResult constructor expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L43: `Parameter #3 $metadata of class App\Services\Search\SearchResult constructor expects array<string, mixed>, array<int|string, mixed> given.` <sub>(type-mismatch/expects)</sub>
- L65: `Method App\Services\Search\AdminSearchProvider::searchAdmin() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L117: `Method App\Services\Search\AdminSearchProvider::searchBanners() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L139: `Method App\Services\Search\AdminSearchProvider::searchContent() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L161: `Method App\Services\Search\AdminSearchProvider::searchContentForExport() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L183: `Method App\Services\Search\AdminSearchProvider::searchTokens() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L205: `Method App\Services\Search\AdminSearchProvider::searchEmails() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L227: `Method App\Services\Search\AdminSearchProvider::searchInvestments() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L249: `Method App\Services\Search\AdminSearchProvider::searchTickets() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L271: `Method App\Services\Search\AdminSearchProvider::searchInfluencers() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L294: `Method App\Services\Search\AdminSearchProvider::searchRegisteredModule() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L297: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>
- L299: `Method App\Services\Search\AdminSearchProvider::searchRegisteredModule() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>
- L350: `Method App\Services\Search\AdminSearchProvider::quickSearchAds() should return array<int, stdClass> but returns array<string, array<int|string, mixed>|int>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Controllers/Api/InteractionApiController.php`  (17 خطا)
<sub>دستهها: type-mismatch/expects=9, cast-mixed(int)=8</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L64: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L114: `Parameter #1 $value of static method App\Enums\ModuleContext::tryFrom() expects int|string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L118: `Parameter #2 $interactableType of method App\Services\Interaction\FavoriteService::toggle() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L119: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L124: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L124: `Parameter #2 $interactableType of method App\Services\Interaction\FavoriteService::hasFavorited() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L155: `Parameter #1 $value of static method App\Enums\ModuleContext::tryFrom() expects int|string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L159: `Parameter #2 $interactableType of method App\Services\Interaction\RatingService::rate() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L160: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L162: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L166: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L166: `Parameter #1 $interactableType of method App\Services\Interaction\RatingService::getAverageRating() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L198: `Parameter #1 $value of static method App\Enums\ModuleContext::tryFrom() expects int|string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L202: `Parameter #2 $interactableType of method App\Services\Interaction\ReportService::submit() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L203: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L205: `Parameter #5 $reason of method App\Services\Interaction\ReportService::submit() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/AdtubeController.php`  (17 خطا)
<sub>دستهها: cast-mixed(int)=6, nullsafe-on-non-nullable=6, unreachable=2, never-read-property=1, cast-mixed(float)=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Property App\Controllers\User\AdtubeController::$adManager is never read, only written.` <sub>(never-read-property)</sub>
- L86: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L128: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L146: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L153: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L185: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L186: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L187: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L212: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L223: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L245: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L255: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L273: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L276: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L308: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L309: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L316: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Jobs/ProcessNotificationJob.php`  (17 خطا)
<sub>دستهها: type-mismatch/expects=10, cast-mixed(int)=3, encapsed-string=2, cannot-access=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L44: `Part $channel (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L49: `Part $channel (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L57: `Parameter #2 $userIds of method App\Services\Notification\NotificationDispatcher::dispatchBulk() expects array<int, int>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L58: `Parameter #3 $title of method App\Services\Notification\NotificationDispatcher::dispatchBulk() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L59: `Parameter #4 $message of method App\Services\Notification\NotificationDispatcher::dispatchBulk() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L60: `Parameter #5 $data of method App\Services\Notification\NotificationDispatcher::dispatchBulk() expects array<string, mixed>|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L62: `Parameter #7 $actionUrl of method App\Services\Notification\NotificationDispatcher::dispatchBulk() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L67: `Parameter #1 $value of function count expects array|Countable, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Cannot access offset 0 on mixed.` <sub>(cannot-access)</sub>
- L72: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L72: `Parameter #2 $message of method App\Services\Notification\SmsNotificationService::sendSecurityAlertToUser() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L74: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L74: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L74: `Parameter #3 $currency of method App\Services\Notification\SmsNotificationService::sendWithdrawalAlertToUser() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L76: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L76: `Parameter #3 $title of method App\Services\Notification\NotificationDispatcher::dispatch() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L76: `Parameter #4 $message of method App\Services\Notification\NotificationDispatcher::dispatch() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Listeners/WithdrawalListener.php`  (17 خطا)
<sub>دستهها: encapsed-string=9, type-mismatch/expects=7, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L77: `Parameter #1 $data of method App\Listeners\WithdrawalListener::processWithdrawalCreated() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L92: `Parameter #1 $data of method App\Listeners\WithdrawalListener::processWithdrawalApproved() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L131: `Parameter #1 $userId of method App\Services\Notification\NotificationService::send() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L134: `Part $amount (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L134: `Part $currency (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L134: `Part $withdrawalId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L152: `Parameter #2 $entityId of method App\Services\ScoreService::applyDelta() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L164: `Parameter #1 $userId of method App\Services\Notification\NotificationService::send() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L167: `Part $withdrawalId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L199: `Parameter #1 $userId of method App\Services\Notification\NotificationService::send() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L202: `Part $amount (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L202: `Part $currency (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L202: `Part $withdrawalId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L236: `Parameter #1 $userId of method App\Services\Notification\NotificationService::send() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L239: `Part $amount (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L239: `Part $currency (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Services/AntiFraud/FraudDetectionService.php`  (17 خطا)
<sub>دستهها: type-mismatch/expects=8, cast-mixed(int)=5, never-read-property=1, cast-mixed(float)=1, unused=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L93: `Property App\Services\AntiFraud\FraudDetectionService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L181: `Parameter #1 $days of method App\Services\AntiFraud\FraudDetectionService::calculateAccountAgeFactor() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L182: `Parameter #1 $reputation of method App\Services\AntiFraud\FraudDetectionService::calculateReputationFactor() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L183: `Parameter #1 $velocity of method App\Services\AntiFraud\FraudDetectionService::calculateVelocityFactor() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L184: `Parameter #1 $geo of method App\Services\AntiFraud\FraudDetectionService::calculateGeographicFactor() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L258: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L259: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L260: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L263: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L265: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L269: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L271: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L276: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L277: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L355: `Method App\Services\AntiFraud\FraudDetectionService::updateFraudScore() is unused.` <sub>(unused)</sub>
- L366: `Parameter #2 $factors of method App\Models\VelocityAndScoreModel::logFraudCalculation() expects array<string, float|int>, array<string, mixed> given.` <sub>(type-mismatch/expects)</sub>
- L390: `Method App\Services\AntiFraud\FraudDetectionService::executeAutomatedActions() should return array<string, mixed> but returns array<int, string>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/AntiFraud/GeolocationIntelligenceService.php`  (17 خطا)
<sub>دستهها: type-mismatch/expects=12, cannot-access=4, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L69: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L70: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L71: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L72: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L75: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L182: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L263: `Parameter #1 $anomalies of method App\Services\AntiFraud\GeolocationIntelligenceService::calculateVelocityRiskScore() expects array<string, mixed>, array<int<0, max>, array<string, array<string, mixed>|float|string>> given.` <sub>(type-mismatch/expects)</sub>
- L479: `Cannot access offset 'city' on mixed.` <sub>(cannot-access)</sub>
- L479: `Cannot access offset 'country' on mixed.` <sub>(cannot-access)</sub>
- L480: `Cannot access offset 'city' on mixed.` <sub>(cannot-access)</sub>
- L480: `Cannot access offset 'country' on mixed.` <sub>(cannot-access)</sub>
- L481: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L482: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L483: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L523: `Parameter #1 $countryCode of method App\Services\AntiFraud\GeolocationIntelligenceService::getCountryRiskScore() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L531: `Parameter #1 $ipTimezone of method App\Services\AntiFraud\GeolocationIntelligenceService::detectTimezoneAnomaly() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L532: `Parameter #2 $browserTimezone of method App\Services\AntiFraud\GeolocationIntelligenceService::detectTimezoneAnomaly() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Auth/LoginRiskService.php`  (17 خطا)
<sub>دستهها: cast-mixed(int)=9, always-true=4, return-type-mismatch(array)=2, type-mismatch/expects=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L92: `Left side of && is always true.` <sub>(always-true)</sub>
- L171: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L172: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L173: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L174: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L176: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L177: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L178: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L179: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L212: `Left side of && is always true.` <sub>(always-true)</sub>
- L295: `Left side of && is always true.` <sub>(always-true)</sub>
- L324: `Left side of && is always true.` <sub>(always-true)</sub>
- L394: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L407: `Method App\Services\Auth\LoginRiskService::decodeSignedPayload() should return array<string, mixed>|null but returns array|null.` <sub>(return-type-mismatch(array))</sub>
- L416: `Method App\Services\Auth\LoginRiskService::decodeSignedPayload() should return array<string, mixed>|null but returns array|null.` <sub>(return-type-mismatch(array))</sub>
- L423: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L443: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/Health/HealthCheckService.php`  (17 خطا)
<sub>دستهها: cast-mixed(int)=6, cannot-access=6, never-read-property=2, cast-mixed(float)=1, type-mismatch/expects=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Property App\Services\Health\HealthCheckService::$sagaModel is never read, only written.` <sub>(never-read-property)</sub>
- L19: `Property App\Services\Health\HealthCheckService::$failedJobModel is never read, only written.` <sub>(never-read-property)</sub>
- L36: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L173: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L173: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L173: `Parameter #1 $host of method Redis::connect() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L242: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L243: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L244: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L247: `Cannot access offset 'crypto_api'|'crypto_explorer_btc'|'crypto_explorer_eth'|'crypto_explorer_usdt'|'deepface_kyc'|'fcm'|'fcm_oauth'|'jibit'|'log_notif_telegram'|'notif_sms'|'notif_telegram'|'payment_gateway…' on mixed.` <sub>(cannot-access)</sub>
- L247: `Cannot access offset 'threshold' on mixed.` <sub>(cannot-access)</sub>
- L247: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L248: `Cannot access offset 'failure_threshold' on mixed.` <sub>(cannot-access)</sub>
- L250: `Cannot access offset 'crypto_api'|'crypto_explorer_btc'|'crypto_explorer_eth'|'crypto_explorer_usdt'|'deepface_kyc'|'fcm'|'fcm_oauth'|'jibit'|'log_notif_telegram'|'notif_sms'|'notif_telegram'|'payment_gateway…' on mixed.` <sub>(cannot-access)</sub>
- L250: `Cannot access offset 'timeout' on mixed.` <sub>(cannot-access)</sub>
- L250: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L251: `Cannot access offset 'retry_timeout…' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Withdrawal/WithdrawalUserService.php`  (17 خطا)
<sub>دستهها: type-mismatch/expects=10, cannot-access=4, never-read-property=1, return-type-mismatch(array)=1, nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L37: `Property App\Services\Withdrawal\WithdrawalUserService::$logger is never read, only written.` <sub>(never-read-property)</sub>
- L78: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L83: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L90: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L109: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L110: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L123: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L124: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L136: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L137: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L163: `Method App\Services\Withdrawal\WithdrawalUserService::cancelPendingWithdrawal() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L255: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L277: `Cannot access offset 'withdrawal_id' on mixed.` <sub>(cannot-access)</sub>
- L278: `Cannot access offset 'tx_id' on mixed.` <sub>(cannot-access)</sub>
- L281: `Cannot access offset 'withdrawal_id' on mixed.` <sub>(cannot-access)</sub>
- L282: `Cannot access offset 'tx_id' on mixed.` <sub>(cannot-access)</sub>
- L284: `Parameter #5 $explicitKey of method App\Services\Shared\IdempotencyService::execute() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/BackupManagementController.php`  (16 خطا)
<sub>دستهها: unreachable=5, encapsed-string=4, cast-mixed(int)=3, type-mismatch/expects=2, no-return-type=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L26: `Method App\Controllers\Admin\BackupManagementController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L53: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L62: `Part $result['filename'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L64: `Part $result['error'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L90: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L93: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L97: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L100: `Parameter #1 $filename of method App\Services\DatabaseService::restoreBackup() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L135: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L138: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L142: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L145: `Parameter #1 $filename of method App\Services\DatabaseService::verifyBackupIntegrity() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L185: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L195: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L207: `Part $result['deleted'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L209: `Part $result['error'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Controllers/Api/WalletController.php`  (16 خطا)
<sub>دستهها: type-mismatch/expects=10, cast-mixed(int)=3, cast-mixed(string)=2, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L99: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L108: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L111: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L120: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L123: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L138: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L164: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L166: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L176: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L177: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L182: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L218: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L235: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L268: `Parameter #1 $items of method App\Controllers\Api\BaseApiController::paginated() expects array<int, mixed>, array<string, array<int, stdClass>|int> given.` <sub>(type-mismatch/expects)</sub>
- L276: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L283: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Models/Investment.php`  (16 خطا)
<sub>دستهها: always-true=7, return-type-mismatch(stdClass)=3, cannot-access=2, cast-mixed(int)=2, unreachable=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L110: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L111: `Method App\Models\Investment::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L130: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L131: `Method App\Models\Investment::findWithUser() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L146: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L147: `Method App\Models\Investment::getActiveByUser() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L185: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L186: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L213: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L251: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L262: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L264: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L307: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L388: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L389: `Method App\Models\Investment::getStats() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L408: `Ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/AdminDashboard/DashboardQueryService.php`  (16 خطا)
<sub>دستهها: cannot-access=13, return-type-mismatch(array)=2, always-evaluate=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L99: `Cannot access property $users_total on mixed.` <sub>(cannot-access)</sub>
- L100: `Cannot access property $users_active on mixed.` <sub>(cannot-access)</sub>
- L101: `Cannot access property $users_pending_kyc on mixed.` <sub>(cannot-access)</sub>
- L102: `Cannot access property $users_with_2fa on mixed.` <sub>(cannot-access)</sub>
- L104: `Cannot access property $disputes_total on mixed.` <sub>(cannot-access)</sub>
- L105: `Cannot access property $disputes_open on mixed.` <sub>(cannot-access)</sub>
- L106: `Cannot access property $disputes_resolved on mixed.` <sub>(cannot-access)</sub>
- L108: `Cannot access property $fin_count on mixed.` <sub>(cannot-access)</sub>
- L109: `Cannot access property $fin_volume on mixed.` <sub>(cannot-access)</sub>
- L111: `Cannot access property $tickets_total on mixed.` <sub>(cannot-access)</sub>
- L112: `Cannot access property $tickets_pending on mixed.` <sub>(cannot-access)</sub>
- L114: `Cannot access property $appeals_total on mixed.` <sub>(cannot-access)</sub>
- L115: `Cannot access property $appeals_pending on mixed.` <sub>(cannot-access)</sub>
- L369: `Call to function is_array() with object|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L375: `Method App\Services\AdminDashboard\DashboardQueryService::getRecentActivity() should return array<int, stdClass> but returns array<string, array<string, array<string, int>|int>|object|null>.` <sub>(return-type-mismatch(array))</sub>
- L384: `Method App\Services\AdminDashboard\DashboardQueryService::getRecentActivity() should return array<int, stdClass> but returns array<string, array<string, array|int>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/QueueWorker.php`  (16 خطا)
<sub>دستهها: type-mismatch/expects=9, cannot-access=3, cast-mixed(int)=2, unused=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L23: `Method App\Services\QueueWorker::toObject() is unused.` <sub>(unused)</sub>
- L83: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L104: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L127: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L132: `Cannot access offset 'correlation_id' on mixed.` <sub>(cannot-access)</sub>
- L133: `Cannot access offset 'trace_id' on mixed.` <sub>(cannot-access)</sub>
- L173: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L174: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L200: `Cannot access offset '_dlq_retry_count' on mixed.` <sub>(cannot-access)</sub>
- L200: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L217: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L217: `Parameter #3 $errorClass of method Core\Queue::fail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L217: `Parameter #4 $status of method Core\Queue::fail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L249: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L272: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L358: `Method App\Services\QueueWorker::defaultAllowedJobs() should return array<int, string> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/User/UserService.php`  (16 خطا)
<sub>دستهها: type-mismatch/expects=10, return-type-mismatch=4, always-false=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L74: `Parameter #2 $string of function explode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L75: `Parameter #1 $password of function hash_password expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L77: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L87: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L89: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L116: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L117: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L243: `Method App\Services\User\UserService::find() should return App\Models\User|null but returns object.` <sub>(return-type-mismatch)</sub>
- L254: `Method App\Services\User\UserService::findByEmail() should return App\Models\User|null but returns object|null.` <sub>(return-type-mismatch)</sub>
- L260: `Method App\Services\User\UserService::findByMobile() should return App\Models\User|null but returns object|null.` <sub>(return-type-mismatch)</sub>
- L276: `Method App\Services\User\UserService::findByCredentials() should return App\Models\User|null but returns object|null.` <sub>(return-type-mismatch)</sub>
- L302: `Parameter #1 $email of method App\Services\User\UserService::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L356: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L362: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L397: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L424: `Method App\Services\User\UserService::searchWithFilters() should return array<int, stdClass> but returns array<string, array<int, stdClass>|int>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Controllers/User/TwoFactorController.php`  (15 خطا)
<sub>دستهها: cast-mixed(int)=8, cast-mixed(string)=4, never-read-property=1, no-return-type=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L26: `Property App\Controllers\User\TwoFactorController::$activityLog is never read, only written.` <sub>(never-read-property)</sub>
- L64: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L94: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L140: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L152: `Method App\Controllers\User\TwoFactorController::verify() has no return type specified.` <sub>(no-return-type)</sub>
- L157: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L167: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L172: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L207: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L230: `Parameter #1 $ip of closure expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L255: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L316: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L326: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L407: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/SagaOrchestrator.php`  (15 خطا)
<sub>دستهها: OTHER=8, always-evaluate=3, type-mismatch/expects=2, unused=1, always-condition=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Method App\Services\SagaOrchestrator::toObject() is unused.` <sub>(unused)</sub>
- L79: `Parameter #1 $callback of function call_user_func expects callable(): mixed, mixed given.` <sub>(type-mismatch/expects)</sub>
- L85: `Property App\Services\SagaOrchestrator::$executedSteps (array<int, string>) does not accept array<int, array<string, mixed>|string>.` <sub>(type-mismatch/expects)</sub>
- L129: `Offset 'compensate' does not exist on string.` <sub>(OTHER)</sub>
- L130: `Offset 'name' does not exist on string.` <sub>(OTHER)</sub>
- L135: `Offset 'name' does not exist on string.` <sub>(OTHER)</sub>
- L155: `Offset 'name' does not exist on string.` <sub>(OTHER)</sub>
- L160: `Offset 'name' does not exist on string.` <sub>(OTHER)</sub>
- L172: `Offset 'compensate' on string on left side of ?? does not exist.` <sub>(OTHER)</sub>
- L176: `Call to function is_array() with null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L176: `Offset 0 on *NEVER* in isset() always exists and is not nullable.` <sub>(always-condition)</sub>
- L179: `Call to function is_string() with null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L182: `Instanceof between null and Closure will always evaluate to false.` <sub>(always-evaluate)</sub>
- L187: `Offset 'name' does not exist on string.` <sub>(OTHER)</sub>
- L190: `Offset 'result' on string on left side of ?? does not exist.` <sub>(OTHER)</sub>

</details>

### `app/Commands/DatabaseAnalyzerCommand.php`  (14 خطا)
<sub>دستهها: cannot-access=8, type-mismatch/expects=4, encapsed-string=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L91: `Part $val (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L114: `Cannot access property $TABLE_NAME on array<string, mixed>.` <sub>(cannot-access)</sub>
- L114: `Cannot access property $table_name on array<string, mixed>.` <sub>(cannot-access)</sub>
- L115: `Cannot access property $TABLE_ROWS on array<string, mixed>.` <sub>(cannot-access)</sub>
- L115: `Cannot access property $row_count on array<string, mixed>.` <sub>(cannot-access)</sub>
- L116: `Cannot access property $SIZE_MB on array<string, mixed>.` <sub>(cannot-access)</sub>
- L116: `Cannot access property $size_mb on array<string, mixed>.` <sub>(cannot-access)</sub>
- L145: `Parameter #2 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L145: `Parameter #3 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L162: `Cannot access offset 'index_name' on mixed.` <sub>(cannot-access)</sub>
- L162: `Cannot access offset 'score' on mixed.` <sub>(cannot-access)</sub>
- L162: `Parameter #2 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L162: `Parameter #3 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L237: `Part $val (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Controllers/Admin/AdTaskController.php`  (14 خطا)
<sub>دستهها: no-return-type=3, type-mismatch/expects=3, cannot-access=3, never-read-property=2, cast-mixed(int)=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Property App\Controllers\Admin\AdTaskController::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L18: `Property App\Controllers\Admin\AdTaskController::$searchService is never read, only written.` <sub>(never-read-property)</sub>
- L38: `Method App\Controllers\Admin\AdTaskController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L45: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L46: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L56: `Parameter #2 $status of method App\Models\Ads::adminList() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L57: `Parameter #2 $status of method App\Models\Ads::adminCount() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L76: `Method App\Controllers\Admin\AdTaskController::show() has no return type specified.` <sub>(no-return-type)</sub>
- L101: `Cannot access offset 'task_id' on mixed.` <sub>(cannot-access)</sub>
- L101: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L102: `Cannot access offset 'decision' on mixed.` <sub>(cannot-access)</sub>
- L103: `Cannot access offset 'reason' on mixed.` <sub>(cannot-access)</sub>
- L112: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L135: `Method App\Controllers\Admin\AdTaskController::analytics() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/User/ContentController.php`  (14 خطا)
<sub>دستهها: OTHER=6, cast-mixed(string)=3, unreachable=2, type-mismatch/expects=1, unused=1, always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Property App\Controllers\BaseController::$logger (App\Contracts\LoggerInterface) does not accept App\Contracts\LoggerInterface|null.` <sub>(type-mismatch/expects)</sub>
- L60: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L81: `Offset 'submissions' does not exist on array<int, stdClass>.` <sub>(OTHER)</sub>
- L82: `Offset 'stats' does not exist on array<int, stdClass>.` <sub>(OTHER)</sub>
- L83: `Offset 'totalRevenue' does not exist on array<int, stdClass>.` <sub>(OTHER)</sub>
- L84: `Offset 'pendingRevenue' does not exist on array<int, stdClass>.` <sub>(OTHER)</sub>
- L85: `Offset 'total' does not exist on array<int, stdClass>.` <sub>(OTHER)</sub>
- L86: `Offset 'totalPages' does not exist on array<int, stdClass>.` <sub>(OTHER)</sub>
- L116: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L170: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L171: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L172: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L402: `Method App\Controllers\User\ContentController::buildJsonError() is unused.` <sub>(unused)</sub>
- L438: `If condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Jobs/Auth/LinkSocialAccountJob.php`  (14 خطا)
<sub>دستهها: cast-mixed(string)=8, never-read-property=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L9: `Property App\Jobs\Auth\LinkSocialAccountJob::$googleClientId is never read, only written.` <sub>(never-read-property)</sub>
- L10: `Property App\Jobs\Auth\LinkSocialAccountJob::$googleClientSecret is never read, only written.` <sub>(never-read-property)</sub>
- L11: `Property App\Jobs\Auth\LinkSocialAccountJob::$googleRedirectUri is never read, only written.` <sub>(never-read-property)</sub>
- L12: `Property App\Jobs\Auth\LinkSocialAccountJob::$facebookClientId is never read, only written.` <sub>(never-read-property)</sub>
- L13: `Property App\Jobs\Auth\LinkSocialAccountJob::$facebookClientSecret is never read, only written.` <sub>(never-read-property)</sub>
- L14: `Property App\Jobs\Auth\LinkSocialAccountJob::$facebookRedirectUri is never read, only written.` <sub>(never-read-property)</sub>
- L29: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L31: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L32: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L33: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L34: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L51: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L64: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/Escrow.php`  (14 خطا)
<sub>دستهها: always-true=7, return-type-mismatch(stdClass)=6, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L23: `Method App\Models\Escrow::findByOrderId() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L64: `Method App\Models\Escrow::findPendingForConfirm() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L64: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L117: `Method App\Models\Escrow::findReleasable() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L117: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L194: `Method App\Models\Escrow::findRefundable() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L194: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L265: `Method App\Models\Escrow::getStatus() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L265: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L277: `Method App\Models\Escrow::getByOrder() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L277: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L287: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L288: `Cannot access property $expires_at on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Auth/OAuthService.php`  (14 خطا)
<sub>دستهها: never-read-property=6, cast-mixed(string)=6, return-type-mismatch(array)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Property App\Services\Auth\OAuthService::$googleClientSecret is never read, only written.` <sub>(never-read-property)</sub>
- L21: `Property App\Services\Auth\OAuthService::$facebookClientSecret is never read, only written.` <sub>(never-read-property)</sub>
- L25: `Property App\Services\Auth\OAuthService::$logger is never read, only written.` <sub>(never-read-property)</sub>
- L26: `Property App\Services\Auth\OAuthService::$model is never read, only written.` <sub>(never-read-property)</sub>
- L27: `Property App\Services\Auth\OAuthService::$userModel is never read, only written.` <sub>(never-read-property)</sub>
- L28: `Property App\Services\Auth\OAuthService::$authService is never read, only written.` <sub>(never-read-property)</sub>
- L64: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L65: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L66: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L67: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L68: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L69: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L197: `Method App\Services\Auth\OAuthService::getLinkedAccounts() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L232: `Parameter #1 $url of function parse_url expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/MessageModerationService.php`  (14 خطا)
<sub>دستهها: type-mismatch/expects=6, return-type-mismatch(array)=4, never-read-property=1, always-condition=1, cannot-access=1, always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Property App\Services\MessageModerationService::$notificationService is never read, only written.` <sub>(never-read-property)</sub>
- L60: `Variable $eventDispatcher on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L77: `Method App\Services\MessageModerationService::getReportDetail() should return array<string, mixed>|null but returns array<int, stdClass>|null.` <sub>(return-type-mismatch(array))</sub>
- L185: `Parameter #2 $string of function explode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L191: `Parameter #1 $string of function substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L191: `Parameter #1 $string of function substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L194: `Parameter #1 $string of function substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L197: `Parameter #3 $subject of function preg_replace expects array|string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L201: `Method App\Services\MessageModerationService::getBlockedUsers() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L207: `Cannot access property $cnt on mixed.` <sub>(cannot-access)</sub>
- L477: `Method App\Services\MessageModerationService::getMessage() should return array<string, mixed>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L535: `Method App\Services\MessageModerationService::getReportedMessageThread() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L562: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L574: `Parameter #1 $string of function base64_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `core/ExceptionHandler.php`  (14 خطا)
<sub>دستهها: always-condition=4, type-mismatch/expects=3, OTHER=3, always-evaluate=2, cannot-access=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L100: `Cannot access offset 'trace_id' on mixed.` <sub>(cannot-access)</sub>
- L125: `Parameter #2 $errorCode of static method Core\ExceptionHandler::logToAdvancedSystem() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L142: `Instanceof between Throwable and Core\Exceptions\InsufficientBalanceException will always evaluate to false.` <sub>(always-evaluate)</sub>
- L231: `Offset 0 does not exist on array<string, mixed>.` <sub>(OTHER)</sub>
- L231: `Offset 1 does not exist on array<string, mixed>.` <sub>(OTHER)</sub>
- L231: `Offset 2 does not exist on array<string, mixed>.` <sub>(OTHER)</sub>
- L314: `Method Core\ExceptionHandler::extractAppOriginFromTrace() should return array<string, mixed> but returns array<int, array<int<0, max>, string>|int|string|null>.` <sub>(return-type-mismatch(array))</sub>
- L377: `Instanceof between Exception and ParseError will always evaluate to false.` <sub>(always-evaluate)</sub>
- L436: `Offset 'message' on array{type: int, message: string, file: string, line: int} on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L437: `Offset 'file' on array{type: int, message: string, file: string, line: int} on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L438: `Offset 'line' on array{type: int, message: string, file: string, line: int} on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L439: `Offset 'type' on array{type: int, message: string, file: string, line: int} on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L505: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L779: `Parameter #1 $response_code of function http_response_code expects int, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/BugReportController.php`  (13 خطا)
<sub>دستهها: cast-mixed(int)=6, no-return-type=3, never-read-property=2, type-mismatch/expects=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L14: `Property App\Controllers\Admin\BugReportController::$uploadService is never read, only written.` <sub>(never-read-property)</sub>
- L15: `Property App\Controllers\Admin\BugReportController::$searchService is never read, only written.` <sub>(never-read-property)</sub>
- L31: `Method App\Controllers\Admin\BugReportController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L41: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L45: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L80: `Method App\Controllers\Admin\BugReportController::show() has no return type specified.` <sub>(no-return-type)</sub>
- L90: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L120: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L159: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L199: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L223: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L251: `Method App\Controllers\Admin\BugReportController::delete() has no return type specified.` <sub>(no-return-type)</sub>
- L262: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/InfluencerController.php`  (13 خطا)
<sub>دستهها: cannot-access=10, never-read-property=2, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Property App\Controllers\Admin\InfluencerController::$promotionService is never read, only written.` <sub>(never-read-property)</sub>
- L25: `Property App\Controllers\Admin\InfluencerController::$searchService is never read, only written.` <sub>(never-read-property)</sub>
- L104: `Cannot access offset 'profile_id' on mixed.` <sub>(cannot-access)</sub>
- L105: `Cannot access offset 'decision' on mixed.` <sub>(cannot-access)</sub>
- L106: `Cannot access offset 'reason' on mixed.` <sub>(cannot-access)</sub>
- L194: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L205: `Cannot access offset 'dispute_id' on mixed.` <sub>(cannot-access)</sub>
- L206: `Cannot access offset 'verdict' on mixed.` <sub>(cannot-access)</sub>
- L207: `Cannot access offset 'note' on mixed.` <sub>(cannot-access)</sub>
- L208: `Cannot access offset 'refund_percent' on mixed.` <sub>(cannot-access)</sub>
- L240: `Cannot access offset 'verification_id' on mixed.` <sub>(cannot-access)</sub>
- L252: `Cannot access offset 'verification_id' on mixed.` <sub>(cannot-access)</sub>
- L253: `Cannot access offset 'reason' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Controllers/Admin/LevelController.php`  (13 خطا)
<sub>دستهها: no-return-type=6, cannot-access=3, never-read-property=2, type-mismatch/expects=1, OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Property App\Controllers\Admin\LevelController::$referralService is never read, only written.` <sub>(never-read-property)</sub>
- L14: `Property App\Controllers\Admin\LevelController::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L39: `Method App\Controllers\Admin\LevelController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L57: `Method App\Controllers\Admin\LevelController::edit() has no return type specified.` <sub>(no-return-type)</sub>
- L77: `Method App\Controllers\Admin\LevelController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L135: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L136: `Cannot access offset 'level' on mixed.` <sub>(cannot-access)</sub>
- L137: `Cannot access offset 'reason' on mixed.` <sub>(cannot-access)</sub>
- L185: `Method App\Controllers\Admin\LevelController::history() has no return type specified.` <sub>(no-return-type)</sub>
- L218: `Method App\Controllers\Admin\LevelController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L227: `Method App\Controllers\Admin\LevelController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L252: `Parameter #1 $string of function strtolower expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L328: `Binary operation "." between 'این سطح دارای ' and stdClass results in an error.` <sub>(OTHER)</sub>

</details>

### `app/Controllers/Admin/ScoreManagementController.php`  (13 خطا)
<sub>دستهها: cast-mixed(string)=5, unused=3, type-mismatch/expects=2, cast-mixed(float)=1, cast-mixed(int)=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L66: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L67: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L68: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L69: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L70: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L100: `Parameter #2 $message of method App\Controllers\Admin\ScoreManagementController::flash() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L102: `Parameter #2 $message of method App\Controllers\Admin\ScoreManagementController::flash() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L117: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L159: `Method App\Controllers\Admin\ScoreManagementController::ensureAdmin() is unused.` <sub>(unused)</sub>
- L177: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L181: `Method App\Controllers\Admin\ScoreManagementController::render() is unused.` <sub>(unused)</sub>
- L199: `Method App\Controllers\Admin\ScoreManagementController::redirect() is unused.` <sub>(unused)</sub>
- L203: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Controllers/Api/SocialTaskApiController.php`  (13 خطا)
<sub>دستهها: cast-mixed(int)=4, type-mismatch/expects=4, cast-mixed(string)=3, never-read-property=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L40: `Property App\Controllers\Api\SocialTaskApiController::$antiFraud is never read, only written.` <sub>(never-read-property)</sub>
- L90: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L91: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L92: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L330: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L350: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L407: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L408: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L410: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L419: `Parameter #4 $verifiedSignals of method App\Services\SocialTask\CameraVerificationService::processResult() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L419: `Parameter #6 $frameSignals of method App\Services\SocialTask\CameraVerificationService::processResult() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L419: `Parameter #7 $clientContext of method App\Services\SocialTask\CameraVerificationService::processResult() expects array<string, mixed>, array given.` <sub>(type-mismatch/expects)</sub>
- L421: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/InvestmentController.php`  (13 خطا)
<sub>دستهها: cannot-call-on-nullable=4, cast-mixed(int)=3, no-return-type=3, never-read-property=2, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Property App\Controllers\User\InvestmentController::$notificationService is never read, only written.` <sub>(never-read-property)</sub>
- L18: `Property App\Controllers\User\InvestmentController::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L48: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L88: `Method App\Controllers\User\InvestmentController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L116: `Method App\Controllers\User\InvestmentController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L128: `Cannot call method exists() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L128: `Cannot call method exists() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L135: `Cannot call method set() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L164: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L165: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L173: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L181: `Method App\Controllers\User\InvestmentController::withdraw() has no return type specified.` <sub>(no-return-type)</sub>
- L212: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/SocialAccountController.php`  (13 خطا)
<sub>دستهها: no-return-type=6, cast-mixed(string)=3, cast-mixed(int)=3, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Property App\Controllers\User\SocialAccountController::$socialAccountService is never read, only written.` <sub>(never-read-property)</sub>
- L27: `Method App\Controllers\User\SocialAccountController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L49: `Method App\Controllers\User\SocialAccountController::showCreate() has no return type specified.` <sub>(no-return-type)</sub>
- L67: `Method App\Controllers\User\SocialAccountController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L88: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L90: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L91: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L103: `Method App\Controllers\User\SocialAccountController::showEdit() has no return type specified.` <sub>(no-return-type)</sub>
- L105: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L126: `Method App\Controllers\User\SocialAccountController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L128: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L157: `Method App\Controllers\User\SocialAccountController::delete() has no return type specified.` <sub>(no-return-type)</sub>
- L159: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Models/LotteryRound.php`  (13 خطا)
<sub>دستهها: always-true=8, cast-mixed(int)=2, cannot-access=1, unreachable=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L45: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L59: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L60: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L75: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L76: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L90: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L91: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L145: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L147: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L177: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L212: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L213: `Method App\Models\LotteryRound::getStats() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Models/PerformanceLog.php`  (13 خطا)
<sub>دستهها: cannot-access=5, cast-mixed(float)=4, return-type-mismatch(array)=2, always-true=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L26: `Left side of && is always true.` <sub>(always-true)</sub>
- L134: `Method App\Models\PerformanceLog::getPaginated() should return array<int, array<string, mixed>> but returns array<string, array|int>.` <sub>(return-type-mismatch(array))</sub>
- L151: `Method App\Models\PerformanceLog::findById() should return array<string, mixed>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L249: `Cannot access offset 'count' on mixed.` <sub>(cannot-access)</sub>
- L249: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L250: `Cannot access offset 'avg' on mixed.` <sub>(cannot-access)</sub>
- L250: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L251: `Cannot access offset 'min' on mixed.` <sub>(cannot-access)</sub>
- L251: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L252: `Cannot access offset 'max' on mixed.` <sub>(cannot-access)</sub>
- L252: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L253: `Cannot access offset 'stddev' on mixed.` <sub>(cannot-access)</sub>
- L253: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Services/DataExportService.php`  (13 خطا)
<sub>دستهها: cannot-access=11, unused=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Method App\Services\DataExportService::toObject() is unused.` <sub>(unused)</sub>
- L135: `Cannot access offset 'amount' on stdClass.` <sub>(cannot-access)</sub>
- L238: `Method App\Services\DataExportService::getUserTransactions() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L292: `Cannot access offset 'setting_key' on stdClass.` <sub>(cannot-access)</sub>
- L292: `Cannot access offset 'setting_value' on stdClass.` <sub>(cannot-access)</sub>
- L305: `Cannot access offset 'id' on mixed.` <sub>(cannot-access)</sub>
- L306: `Cannot access offset 'username' on mixed.` <sub>(cannot-access)</sub>
- L307: `Cannot access offset 'full_name' on mixed.` <sub>(cannot-access)</sub>
- L308: `Cannot access offset 'email' on mixed.` <sub>(cannot-access)</sub>
- L309: `Cannot access offset 'mobile' on mixed.` <sub>(cannot-access)</sub>
- L310: `Cannot access offset 'kyc_status' on mixed.` <sub>(cannot-access)</sub>
- L311: `Cannot access offset 'created_at' on mixed.` <sub>(cannot-access)</sub>
- L312: `Cannot access offset 'updated_at' on mixed.` <sub>(cannot-access)</sub>

</details>

### `core/Scheduler.php`  (13 خطا)
<sub>دستهها: type-mismatch/expects=5, encapsed-string=4, cast-mixed(int)=2, OTHER=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L141: `Parameter #1 $string of function md5 expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L142: `Parameter #1 $string of function md5 expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L147: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L161: `Part $job['name'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L168: `Trying to invoke mixed but it's not a callable.` <sub>(OTHER)</sub>
- L183: `Part $job['name'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L211: `Part $job['name'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L219: `Parameter #1 $string of function md5 expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L240: `Parameter #1 $string of function md5 expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L244: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L258: `Part $job['name'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L272: `Parameter #1 $string of function md5 expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L282: `Trying to invoke mixed but it's not a callable.` <sub>(OTHER)</sub>

</details>

### `app/Controllers/Admin/FraudController.php`  (12 خطا)
<sub>دستهها: cast-mixed(int)=10, cast-mixed(string)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L31: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L54: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L80: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L106: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L107: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L126: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L128: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L129: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L147: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L170: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L171: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L202: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/ManualDepositController.php`  (12 خطا)
<sub>دستهها: cast-mixed(int)=4, never-read-property=3, cast-mixed(string)=2, type-mismatch/expects=1, unreachable=1, always-condition=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Property App\Controllers\Admin\ManualDepositController::$BankCardModel is never read, only written.` <sub>(never-read-property)</sub>
- L18: `Property App\Controllers\Admin\ManualDepositController::$depositModel is never read, only written.` <sub>(never-read-property)</sub>
- L19: `Property App\Controllers\Admin\ManualDepositController::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L51: `Parameter #1 $status of method App\Services\ManualDepositService::listByStatus() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L90: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L98: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L117: `Variable $depositId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L137: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L146: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L183: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L184: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/User/MessageController.php`  (12 خطا)
<sub>دستهها: cast-mixed(int)=6, type-mismatch/expects=3, cast-mixed(string)=2, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L46: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L77: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L138: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L139: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L150: `Parameter #1 $array of function reset is passed by reference, so it expects variables only.` <sub>(type-mismatch/expects)</sub>
- L155: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L156: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L174: `Parameter #1 $message of method App\Controllers\BaseController::jsonError() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L204: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L253: `Method App\Controllers\User\MessageController::delete() has no return type specified.` <sub>(no-return-type)</sub>
- L291: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L383: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/Auth/ProcessRegistrationJob.php`  (12 خطا)
<sub>دستهها: OTHER=5, type-mismatch/expects=5, cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L12: `Property App\Jobs\Auth\ProcessRegistrationJob::$userService is never written, only read.` <sub>(OTHER)</sub>
- L18: `Property App\Jobs\Auth\ProcessRegistrationJob::$walletService is never written, only read.` <sub>(OTHER)</sub>
- L21: `Property App\Jobs\Auth\ProcessRegistrationJob::$logger is never written, only read.` <sub>(OTHER)</sub>
- L24: `Property App\Jobs\Auth\ProcessRegistrationJob::$userModel is never written, only read.` <sub>(OTHER)</sub>
- L27: `Property App\Jobs\Auth\ProcessRegistrationJob::$referralService is never written, only read.` <sub>(OTHER)</sub>
- L58: `Parameter #1 $userId of method App\Contracts\WalletServiceInterface::getOrCreateWallet() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L65: `Parameter #1 $id of method Core\Model::find() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L78: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L79: `Parameter #2 $email of class App\Events\UserRegisteredEvent constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L84: `Parameter #2 $aggregateId of method App\Contracts\OutboxServiceInterface::record() expects int|string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L90: `Parameter #1 $id of method Core\Model::find() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Auth/UnlinkSocialAccountJob.php`  (12 خطا)
<sub>دستهها: never-read-property=6, cast-mixed(string)=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L9: `Property App\Jobs\Auth\UnlinkSocialAccountJob::$googleClientId is never read, only written.` <sub>(never-read-property)</sub>
- L10: `Property App\Jobs\Auth\UnlinkSocialAccountJob::$googleClientSecret is never read, only written.` <sub>(never-read-property)</sub>
- L11: `Property App\Jobs\Auth\UnlinkSocialAccountJob::$googleRedirectUri is never read, only written.` <sub>(never-read-property)</sub>
- L12: `Property App\Jobs\Auth\UnlinkSocialAccountJob::$facebookClientId is never read, only written.` <sub>(never-read-property)</sub>
- L13: `Property App\Jobs\Auth\UnlinkSocialAccountJob::$facebookClientSecret is never read, only written.` <sub>(never-read-property)</sub>
- L14: `Property App\Jobs\Auth\UnlinkSocialAccountJob::$facebookRedirectUri is never read, only written.` <sub>(never-read-property)</sub>
- L27: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L28: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L29: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L31: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L32: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/InvestmentWithdrawal.php`  (12 خطا)
<sub>دستهها: always-true=4, return-type-mismatch(stdClass)=4, cannot-access=2, cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L72: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L73: `Method App\Models\InvestmentWithdrawal::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L88: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L89: `Method App\Models\InvestmentWithdrawal::findWithDetails() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L126: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L127: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L157: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L189: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L193: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L195: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L240: `Method App\Models\InvestmentWithdrawal::findByRequestId() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L263: `Method App\Models\InvestmentWithdrawal::findForUpdate() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Services/EmailDeliveryStore.php`  (12 خطا)
<sub>دستهها: cannot-call-on-nullable=5, encapsed-string=2, type-mismatch/expects=2, never-read-property=1, return-type-mismatch(array)=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L46: `Property App\Services\EmailDeliveryStore::$metrics is never read, only written.` <sub>(never-read-property)</sub>
- L62: `Part $prefix (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L92: `Cannot call method setEx() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L131: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L133: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L165: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L205: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L207: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L211: `Cannot call method setEx() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L302: `Method App\Services\EmailDeliveryStore::getEmailsForAdmin() should return array{items: array<int, stdClass>, total: int, page: int, per_page: int} but returns array{items: array{}|object, total: int, page: int, per_page: int}.` <sub>(return-type-mismatch(array))</sub>
- L400: `Part $payload['id'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L402: `Method App\Services\EmailDeliveryStore::saveToFile() should return string|false but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `core/QueryBuilder.php`  (12 خطا)
<sub>دستهها: always-condition=6, type-mismatch/expects=2, unused=2, cannot-access=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L88: `Property Core\QueryBuilder::$select (array<int, string>) does not accept array<int|string, string>.` <sub>(type-mismatch/expects)</sub>
- L182: `Method Core\QueryBuilder::validateRawSql_LEGACY_HEURISTIC() is unused.` <sub>(unused)</sub>
- L755: `Variable $sql on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L786: `Cannot access property $avg on mixed.` <sub>(cannot-access)</sub>
- L822: `Variable $sql on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L857: `Parameter #2 $operator of method Core\QueryBuilder::where() expects string, int given.` <sub>(type-mismatch/expects)</sub>
- L960: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>
- L1000: `Variable $sql on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L1064: `Variable $sql on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L1065: `Variable $data on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L1108: `Variable $sql on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L1269: `Method Core\QueryBuilder::buildSelectQuerySimple() is unused.` <sub>(unused)</sub>

</details>

### `app/Controllers/Admin/AdminAdsController.php`  (11 خطا)
<sub>دستهها: cast-mixed(int)=4, cast-mixed(string)=4, never-read-property=1, type-mismatch/expects=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Property App\Controllers\Admin\AdminAdsController::$searchService is never read, only written.` <sub>(never-read-property)</sub>
- L49: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L56: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L99: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L105: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L146: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L147: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L187: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L188: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L189: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L201: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/LogController.php`  (11 خطا)
<sub>دستهها: unreachable=4, type-mismatch/expects=4, cannot-access=1, OTHER=1, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L188: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L191: `Parameter #2 $type of method App\Services\LogService::findById() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L195: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L212: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L220: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L227: `Parameter #2 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L269: `Cannot access offset 0 on mixed.` <sub>(cannot-access)</sub>
- L269: `Parameter #1 $array of function array_keys expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L270: `Argument of an invalid type mixed supplied for foreach, only iterables are supported.` <sub>(OTHER)</sub>
- L271: `Parameter #2 $fields of function fputcsv expects array<int|string, bool|float|int|string|null>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L414: `Method App\Controllers\Admin\LogController::tableExists() is unused.` <sub>(unused)</sub>

</details>

### `app/Controllers/User/DashboardController.php`  (11 خطا)
<sub>دستهها: cannot-access=8, cast-mixed(float)=2, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L92: `Cannot access offset 'wallet' on mixed.` <sub>(cannot-access)</sub>
- L97: `Cannot access offset 'tasks' on mixed.` <sub>(cannot-access)</sub>
- L101: `Cannot access offset 'transactions' on mixed.` <sub>(cannot-access)</sub>
- L105: `Cannot access offset 'today_deposit' on mixed.` <sub>(cannot-access)</sub>
- L105: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L106: `Cannot access offset 'today_withdraw' on mixed.` <sub>(cannot-access)</sub>
- L106: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L107: `Cannot access offset 'pending_tx' on mixed.` <sub>(cannot-access)</sub>
- L107: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L108: `Cannot access offset 'last_transactions' on mixed.` <sub>(cannot-access)</sub>
- L114: `Cannot access offset 'campaigns'|'charts'|'level'|'notifications'|'referral' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Jobs/Auth/HandleGoogleCallbackJob.php`  (11 خطا)
<sub>دستهها: cast-mixed(string)=7, type-mismatch/expects=2, cannot-access=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L37: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L38: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L39: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L40: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L41: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L136: `Parameter #1 $idToken of method App\Jobs\Auth\HandleGoogleCallbackJob::verifyGoogleIdToken() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L140: `Cannot access offset 'nonce' on mixed.` <sub>(cannot-access)</sub>
- L140: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L143: `Cannot access offset 'nonce' on mixed.` <sub>(cannot-access)</sub>
- L148: `Parameter #2 $userData of method App\Jobs\Auth\HandleGoogleCallbackJob::linkOrCreateUser() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/CustomTask/SubmitProofJob.php`  (11 خطا)
<sub>دستهها: cast-mixed(string)=7, cast-mixed(int)=3, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Jobs\CustomTask\SubmitProofJob::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L30: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L31: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L117: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L147: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L148: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L149: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L150: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L175: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L182: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L189: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/PersistBulkInAppNotificationJob.php`  (11 خطا)
<sub>دستهها: type-mismatch/expects=9, OTHER=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Parameter #1 $userIds of method App\Services\Notification\NotificationService::prefetchPreferences() expects array<int, int>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L44: `Argument of an invalid type mixed supplied for foreach, only iterables are supported.` <sub>(OTHER)</sub>
- L46: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L47: `Parameter #2 $type of method App\Services\Notification\NotificationService::processSinglePersist() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L48: `Parameter #3 $title of method App\Services\Notification\NotificationService::processSinglePersist() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L49: `Parameter #4 $message of method App\Services\Notification\NotificationService::processSinglePersist() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L50: `Parameter #5 $data of method App\Services\Notification\NotificationService::processSinglePersist() expects array<string, mixed>|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L51: `Parameter #6 $actionUrl of method App\Services\Notification\NotificationService::processSinglePersist() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L52: `Parameter #7 $actionText of method App\Services\Notification\NotificationService::processSinglePersist() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L53: `Parameter #8 $priority of method App\Services\Notification\NotificationService::processSinglePersist() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L54: `Parameter #9 $scheduledAt of method App\Services\Notification\NotificationService::processSinglePersist() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Models/AuditTrail.php`  (11 خطا)
<sub>دستهها: type-mismatch/expects=4, return-type-mismatch(array)=2, always-evaluate=1, always-condition=1, cast-mixed(string)=1, cannot-access=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Call to function is_array() with null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L24: `Offset 'hash' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L32: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L114: `Method App\Models\AuditTrail::getAll() should return array<int, stdClass> but returns array<string, array|int>.` <sub>(return-type-mismatch(array))</sub>
- L149: `Parameter #2 $params of method App\Models\AuditTrail::fetchCount() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L155: `Parameter #2 $params of method App\Models\AuditTrail::fetchCount() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L162: `Parameter #2 $params of method App\Models\AuditTrail::fetchCount() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L169: `Parameter #2 $params of method App\Models\AuditTrail::fetchCount() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L284: `Method App\Models\AuditTrail::findById() should return array<string, mixed>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L404: `Cannot access offset 'count' on mixed.` <sub>(cannot-access)</sub>
- L404: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Models/KYCVerification.php`  (11 خطا)
<sub>دستهها: always-true=5, unreachable=3, cast-mixed(int)=1, cast-mixed(string)=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L45: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L60: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L69: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L79: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L92: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L146: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L183: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L204: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L291: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L293: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Models/LotteryParticipation.php`  (11 خطا)
<sub>دستهها: always-true=7, cannot-access=2, return-type-mismatch(array)=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L57: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L71: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L110: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L111: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L134: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L139: `Method App\Models\LotteryParticipation::getCountsByRounds() should return array<int, stdClass> but returns array<int, int>.` <sub>(return-type-mismatch(array))</sub>
- L152: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L164: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L165: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L224: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L269: `Ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/BankCardService.php`  (11 خطا)
<sub>دستهها: type-mismatch/expects=10, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Property App\Services\BankCardService::$inquiryAdapter is never read, only written.` <sub>(never-read-property)</sub>
- L67: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L69: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L174: `Parameter #5 $explicitKey of method App\Services\Shared\IdempotencyService::executeWithTransaction() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L184: `Parameter #2 $operatorOrValue of method Core\Model::where() expects string, int given.` <sub>(type-mismatch/expects)</sub>
- L185: `Parameter #2 $operator of method Core\QueryBuilder::where() expects string, int given.` <sub>(type-mismatch/expects)</sub>
- L194: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L195: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L252: `Parameter #2 $operatorOrValue of method Core\Model::where() expects string, int given.` <sub>(type-mismatch/expects)</sub>
- L253: `Parameter #2 $operator of method Core\QueryBuilder::where() expects string, int given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/User/ProfileService.php`  (11 خطا)
<sub>دستهها: type-mismatch/expects=6, cannot-access=2, cast-mixed(string)=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L140: `Parameter #2 $value of method App\Services\User\ProfileService::maskPII() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L164: `Method App\Services\User\ProfileService::getSettings() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L170: `Cannot access offset 'setting_key' on stdClass.` <sub>(cannot-access)</sub>
- L170: `Cannot access offset 'setting_value' on stdClass.` <sub>(cannot-access)</sub>
- L226: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L237: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L265: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L291: `Parameter #2 $datetime of static method DateTime::createFromFormat() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L317: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L325: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L404: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/Withdrawal/WithdrawalAdminService.php`  (11 خطا)
<sub>دستهها: type-mismatch/expects=6, nullsafe-on-non-nullable=2, cast-mixed(int)=2, always-evaluate=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L155: `Call to function is_array() with stdClass|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L297: `Using nullsafe method call on non-nullable type App\Services\Notification\NotificationService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L298: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L299: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L300: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L309: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L321: `Using nullsafe method call on non-nullable type App\Services\Notification\NotificationService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L322: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L323: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L324: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L332: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/PlacementController.php`  (10 خطا)
<sub>دستهها: cast-mixed(int)=7, no-return-type=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Method App\Controllers\Admin\PlacementController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L23: `Method App\Controllers\Admin\PlacementController::toggle() has no return type specified.` <sub>(no-return-type)</sub>
- L25: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L36: `Method App\Controllers\Admin\PlacementController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L38: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L41: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L42: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L43: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L46: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/PredictionController.php`  (10 خطا)
<sub>دستهها: no-return-type=3, unreachable=3, cannot-access=3, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L69: `Method App\Controllers\Admin\PredictionController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L79: `Method App\Controllers\Admin\PredictionController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L95: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L110: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L133: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L165: `Parameter #4 $metadata of method App\Contracts\LoggerInterface::activity() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L168: `Cannot access offset 'winners_paid' on mixed.` <sub>(cannot-access)</sub>
- L169: `Cannot access offset 'no_winners' on mixed.` <sub>(cannot-access)</sub>
- L171: `Cannot access offset 'all_winners' on mixed.` <sub>(cannot-access)</sub>
- L224: `Method App\Controllers\Admin\PredictionController::update() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/Admin/TransactionController.php`  (10 خطا)
<sub>دستهها: cast-mixed(string)=4, cast-mixed(int)=3, always-condition=2, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L34: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L37: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L38: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L39: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L50: `Variable $transactions on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L94: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L102: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L124: `Variable $transactionId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L137: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L138: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/Api/FeatureFlagApiController.php`  (10 خطا)
<sub>دستهها: type-mismatch/expects=4, no-return-type=2, cannot-access=2, unused=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Method App\Controllers\Api\FeatureFlagApiController::toObject() is unused.` <sub>(unused)</sub>
- L49: `Parameter #1 $known_string of function hash_equals expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L49: `Parameter #2 $user_string of function hash_equals expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L57: `Method App\Controllers\Api\FeatureFlagApiController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L127: `Parameter #2 $userId of method App\Services\FeatureFlagService::isEnabled() expects int|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L144: `Method App\Controllers\Api\FeatureFlagApiController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L196: `Cannot access property $enabled on App\Models\FeatureFlag|null.` <sub>(cannot-access)</sub>
- L216: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L270: `Cannot access property $enabled on App\Models\FeatureFlag|null.` <sub>(cannot-access)</sub>
- L310: `Parameter #2 $userId of method App\Services\FeatureFlagService::isEnabled() expects int|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/SocialTask/SubmitSocialTaskExecutionJob.php`  (10 خطا)
<sub>دستهها: cast-mixed(int)=6, type-mismatch/expects=2, cast-mixed(string)=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L32: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L62: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L70: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L110: `Parameter #1 $num of function round expects float|int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L154: `Parameter #1 $num of function round expects float|int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L187: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L188: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L189: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L190: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L191: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Middleware/ApiAuthMiddleware.php`  (10 خطا)
<sub>دستهها: cast-mixed(string)=5, cast-mixed(int)=3, type-mismatch/expects=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L55: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L136: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L137: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L156: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L157: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L179: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L189: `Parameter #1 $string of function strlen expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L221: `Cannot access offset mixed on mixed.` <sub>(cannot-access)</sub>
- L399: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L423: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/TradingRecord.php`  (10 خطا)
<sub>دستهها: always-true=5, return-type-mismatch(stdClass)=2, cannot-access=1, unreachable=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L56: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L57: `Method App\Models\TradingRecord::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L71: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L72: `Method App\Models\TradingRecord::findWithAdmin() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L137: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L139: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L155: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L213: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L234: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L235: `Method App\Models\TradingRecord::getStats() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Services/AntiFraud/GeoIPService.php`  (10 خطا)
<sub>دستهها: type-mismatch/expects=6, never-read-property=1, cast-mixed(string)=1, return-type-mismatch(array)=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L27: `Property App\Services\AntiFraud\GeoIPService::$db is never read, only written.` <sub>(never-read-property)</sub>
- L43: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L203: `Method App\Services\AntiFraud\GeoIPService::getCachedLocation() should return array<string, mixed>|null but returns array|null.` <sub>(return-type-mismatch(array))</sub>
- L203: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L288: `Method App\Services\AntiFraud\GeoIPService::getCountryCode() should return string but returns mixed.` <sub>(return-type-mismatch)</sub>
- L308: `Parameter #1 $num of function deg2rad expects float, mixed given.` <sub>(type-mismatch/expects)</sub>
- L309: `Parameter #1 $num of function deg2rad expects float, mixed given.` <sub>(type-mismatch/expects)</sub>
- L310: `Parameter #1 $num of function deg2rad expects float, mixed given.` <sub>(type-mismatch/expects)</sub>
- L311: `Parameter #1 $num of function deg2rad expects float, mixed given.` <sub>(type-mismatch/expects)</sub>
- L526: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/AntiFraud/RiskPolicyService.php`  (10 خطا)
<sub>دستهها: OTHER=4, no-return-type=2, cannot-access=2, never-read-property=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Property App\Services\AntiFraud\RiskPolicyService::$logger is never read, only written.` <sub>(never-read-property)</sub>
- L29: `Method App\Services\AntiFraud\RiskPolicyService::get() has no return type specified.` <sub>(no-return-type)</sub>
- L29: `Method App\Services\AntiFraud\RiskPolicyService::get() has parameter $default with no type specified.` <sub>(OTHER)</sub>
- L51: `Cannot access offset 'value_type' on mixed.` <sub>(cannot-access)</sub>
- L52: `Cannot access offset 'value' on mixed.` <sub>(cannot-access)</sub>
- L102: `Method App\Services\AntiFraud\RiskPolicyService::set() has parameter $value with no type specified.` <sub>(OTHER)</sub>
- L175: `Method App\Services\AntiFraud\RiskPolicyService::getPoliciesWithDefaults() should return array<string, mixed> but returns array<int<0, max>, mixed>.` <sub>(return-type-mismatch(array))</sub>
- L221: `Method App\Services\AntiFraud\RiskPolicyService::castValue() has no return type specified.` <sub>(no-return-type)</sub>
- L221: `Method App\Services\AntiFraud\RiskPolicyService::castValue() has parameter $value with no type specified.` <sub>(OTHER)</sub>
- L246: `Method App\Services\AntiFraud\RiskPolicyService::stringifyValue() has parameter $value with no type specified.` <sub>(OTHER)</sub>

</details>

### `app/Services/ContactService.php`  (10 خطا)
<sub>دستهها: type-mismatch/expects=8, unused=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Method App\Services\ContactService::toObject() is unused.` <sub>(unused)</sub>
- L64: `Parameter #1 $token of method App\Services\ContactService::verifyCaptcha() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L64: `Parameter #2 $response of method App\Services\ContactService::verifyCaptcha() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L64: `Parameter #4 $challengeAnswer of method App\Services\ContactService::verifyCaptcha() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L92: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L107: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L108: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L109: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L110: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L162: `Cannot access offset 'answer' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Payment/DgPayGateway.php`  (10 خطا)
<sub>دستهها: cannot-access=8, never-read-property=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L27: `Property App\Services\Payment\DgPayGateway::$paymentGatewayModel is never read, only written.` <sub>(never-read-property)</sub>
- L29: `Property App\Services\Payment\DgPayGateway::$appSettings is never read, only written.` <sub>(never-read-property)</sub>
- L104: `Cannot access offset 'status' on mixed.` <sub>(cannot-access)</sub>
- L105: `Cannot access offset 'token' on mixed.` <sub>(cannot-access)</sub>
- L124: `Cannot access offset 'message' on mixed.` <sub>(cannot-access)</sub>
- L201: `Cannot access offset 'status' on mixed.` <sub>(cannot-access)</sub>
- L204: `Cannot access offset 'ref_id' on mixed.` <sub>(cannot-access)</sub>
- L207: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L214: `Cannot access offset 'ref_id' on mixed.` <sub>(cannot-access)</sub>
- L222: `Cannot access offset 'message' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Payment/IDPayGateway.php`  (10 خطا)
<sub>دستهها: cannot-access=9, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Property App\Services\Payment\IDPayGateway::$appSettings is never read, only written.` <sub>(never-read-property)</sub>
- L121: `Cannot access offset 'id' on mixed.` <sub>(cannot-access)</sub>
- L122: `Cannot access offset 'link' on mixed.` <sub>(cannot-access)</sub>
- L142: `Cannot access offset 'error_message' on mixed.` <sub>(cannot-access)</sub>
- L200: `Cannot access offset 'order_id' on mixed.` <sub>(cannot-access)</sub>
- L239: `Cannot access offset 'status' on mixed.` <sub>(cannot-access)</sub>
- L246: `Cannot access offset 'track_id' on mixed.` <sub>(cannot-access)</sub>
- L249: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L256: `Cannot access offset 'track_id' on mixed.` <sub>(cannot-access)</sub>
- L264: `Cannot access offset 'error_message' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Validators/LoginRequest.php`  (10 خطا)
<sub>دستهها: cast-mixed(string)=5, cannot-access=5</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L28: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L33: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L38: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L39: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L43: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L48: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L52: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L53: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Controllers/Admin/AdminAnalyticsController.php`  (9 خطا)
<sub>دستهها: cast-mixed(string)=9</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L31: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L58: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L108: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L131: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L154: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L177: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L201: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L224: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/Admin/BankCardController.php`  (9 خطا)
<sub>دستهها: no-return-type=3, cast-mixed(int)=3, unreachable=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L27: `Method App\Controllers\Admin\BankCardController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L48: `Method App\Controllers\Admin\BankCardController::verify() has no return type specified.` <sub>(no-return-type)</sub>
- L50: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L109: `Method App\Controllers\Admin\BankCardController::reject() has no return type specified.` <sub>(no-return-type)</sub>
- L111: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L112: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L179: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L180: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L182: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Controllers/Admin/CryptoDepositController.php`  (9 خطا)
<sub>دستهها: cast-mixed(int)=4, cast-mixed(string)=3, never-read-property=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Property App\Controllers\Admin\CryptoDepositController::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L41: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L43: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L99: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L107: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L154: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L199: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L200: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/Admin/LotteryController.php`  (9 خطا)
<sub>دستهها: no-return-type=4, cast-mixed(int)=4, OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Method App\Controllers\Admin\LotteryController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L38: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L51: `Empty array passed to foreach.` <sub>(OTHER)</sub>
- L69: `Method App\Controllers\Admin\LotteryController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L74: `Method App\Controllers\Admin\LotteryController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L91: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L109: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L118: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L131: `Method App\Controllers\Admin\LotteryController::show() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/SearchController.php`  (9 خطا)
<sub>دستهها: cast-mixed(int)=5, type-mismatch/expects=3, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L33: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L62: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L63: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L85: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L113: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L114: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L134: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L139: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L166: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/ApiTokenController.php`  (9 خطا)
<sub>دستهها: type-mismatch/expects=5, cast-mixed(int)=2, no-return-type=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L44: `Method App\Controllers\User\ApiTokenController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L50: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L51: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L64: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L67: `Parameter #1 $message of method App\Controllers\BaseController::redirectWithError() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L71: `Cannot access offset 'token' on mixed.` <sub>(cannot-access)</sub>
- L82: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L90: `Parameter #1 $message of method App\Controllers\BaseController::jsonError() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L90: `Parameter #3 $code of method App\Controllers\BaseController::jsonError() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/CouponController.php`  (9 خطا)
<sub>دستهها: cannot-access=4, type-mismatch/expects=4, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Cannot access offset 'code' on mixed.` <sub>(cannot-access)</sub>
- L35: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L36: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L36: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L37: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L38: `Cannot access offset 'applicable_to' on mixed.` <sub>(cannot-access)</sub>
- L52: `Parameter #3 $currency of method App\Services\Shared\CouponService::validateAndCalculate() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L54: `Parameter #5 $applicableTo of method App\Services\Shared\CouponService::validateAndCalculate() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Parameter #1 $num of function number_format expects float, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/ProfileController.php`  (9 خطا)
<sub>دستهها: unreachable=5, type-mismatch/expects=3, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L48: `Method App\Controllers\User\ProfileController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L58: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L211: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L227: `Parameter #2 $subject of function preg_match expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L230: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L236: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L240: `Parameter #1 $password of function verify_password expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L243: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L247: `Parameter #1 $password of function hash_password expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Auth/HandleFacebookCallbackJob.php`  (9 خطا)
<sub>دستهها: cast-mixed(string)=6, type-mismatch/expects=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L37: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L38: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L39: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L40: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L41: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L111: `Parameter #1 $accessToken of method App\Jobs\Auth\HandleFacebookCallbackJob::verifyFacebookAccessToken() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L114: `Parameter #1 $accessToken of method App\Jobs\Auth\HandleFacebookCallbackJob::getFacebookUserInfo() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L117: `Parameter #2 $userData of method App\Jobs\Auth\HandleFacebookCallbackJob::linkOrCreateUser() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Listeners/ReferralCommissionListener.php`  (9 خطا)
<sub>دستهها: OTHER=2, cast-mixed(string)=2, nullsafe-on-non-nullable=1, cannot-access=1, cast-mixed(int)=1, type-mismatch/expects=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L40: `Method App\Listeners\ReferralCommissionListener::handle() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L46: `Using nullsafe method call on non-nullable type Core\Request. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L64: `Cannot access offset 'correlation_id' on mixed.` <sub>(cannot-access)</sub>
- L67: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L68: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L69: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L70: `Parameter #4 $context of method App\Services\Shared\ReferralService::processCommission() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L105: `Method App\Listeners\ReferralCommissionListener::extractPayload() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L112: `Method App\Listeners\ReferralCommissionListener::extractPayload() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Listeners/WalletDepositRequestListener.php`  (9 خطا)
<sub>دستهها: nullsafe-on-non-nullable=4, cast-mixed(string)=2, never-read-property=1, OTHER=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Listeners\WalletDepositRequestListener::$dispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L40: `Method App\Listeners\WalletDepositRequestListener::handle() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L104: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L107: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L148: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L151: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L181: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L182: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L183: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Middleware/AdvancedFraudMiddleware.php`  (9 خطا)
<sub>دستهها: type-mismatch/expects=4, cast-mixed(float)=2, cast-mixed(int)=1, cannot-access=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L81: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L98: `Parameter $acceptLanguage of method App\Services\Auth\SessionService::recordSession() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L99: `Parameter $acceptEncoding of method App\Services\Auth\SessionService::recordSession() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L114: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L119: `Cannot access offset 'is_tor' on mixed.` <sub>(cannot-access)</sub>
- L137: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L157: `Parameter #3 $message of function notify expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L163: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L167: `Parameter #3 $message of function notify expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Models/Score.php`  (9 خطا)
<sub>دستهها: cast-mixed(string)=3, cannot-access=3, cast-mixed(int)=2, return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L135: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L183: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L249: `Method App\Models\Score::getWeeklyExecutionStats() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L339: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L339: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L340: `Cannot access offset 'domain' on mixed.` <sub>(cannot-access)</sub>
- L340: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L355: `Cannot access offset 'user_id' on mixed.` <sub>(cannot-access)</sub>
- L355: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Models/TicketMessage.php`  (9 خطا)
<sub>دستهها: always-false=3, cast-mixed(string)=2, cast-mixed(int)=2, return-type-mismatch(stdClass)=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L23: `Method App\Models\TicketMessage::fetchOne() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L35: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L49: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L66: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L72: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L73: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L74: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L80: `Negated boolean expression is always false.` <sub>(always-false)</sub>

</details>

### `app/Models/VitrineRating.php`  (9 خطا)
<sub>دستهها: always-false=5, cannot-access=2, cast-mixed(float)=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L50: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L52: `Cannot access offset 'avg_rating' on mixed.` <sub>(cannot-access)</sub>
- L52: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L64: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L66: `Cannot access offset 'cnt' on mixed.` <sub>(cannot-access)</sub>
- L66: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L84: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L98: `Negated boolean expression is always false.` <sub>(always-false)</sub>

</details>

### `app/Services/CustomTask/CustomTaskService.php`  (9 خطا)
<sub>دستهها: never-read-property=6, return-type-mismatch(array)=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L40: `Property App\Services\CustomTask\CustomTaskService::$escrowService is never read, only written.` <sub>(never-read-property)</sub>
- L44: `Property App\Services\CustomTask\CustomTaskService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L46: `Property App\Services\CustomTask\CustomTaskService::$logger is never read, only written.` <sub>(never-read-property)</sub>
- L47: `Property App\Services\CustomTask\CustomTaskService::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L48: `Property App\Services\CustomTask\CustomTaskService::$appSettings is never read, only written.` <sub>(never-read-property)</sub>
- L49: `Property App\Services\CustomTask\CustomTaskService::$rateLimiter is never read, only written.` <sub>(never-read-property)</sub>
- L123: `Method App\Services\CustomTask\CustomTaskService::getMySubmissions() should return array<int, stdClass> but returns array<int, object>.` <sub>(return-type-mismatch(array))</sub>
- L183: `Method App\Services\CustomTask\CustomTaskService::searchTasks() should return array<int, stdClass> but returns array<string, array<int, stdClass>|int>.` <sub>(return-type-mismatch(array))</sub>
- L189: `Method App\Services\CustomTask\CustomTaskService::getSubmissionsByTask() should return array<int, stdClass> but returns array<int, object>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Notification/NotificationTemplateService.php`  (9 خطا)
<sub>دستهها: cannot-access=3, type-mismatch/expects=2, return-type-mismatch(array)=2, cast-mixed(string)=1, OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L39: `Parameter #1 $text of method App\Services\Notification\NotificationTemplateService::interpolate() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L40: `Parameter #1 $text of method App\Services\Notification\NotificationTemplateService::interpolate() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L50: `Method App\Services\Notification\NotificationTemplateService::getTemplate() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L73: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L86: `Cannot access offset 'variables' on mixed.` <sub>(cannot-access)</sub>
- L88: `Argument of an invalid type mixed supplied for foreach, only iterables are supported.` <sub>(OTHER)</sub>
- L112: `Cannot access offset 'title' on mixed.` <sub>(cannot-access)</sub>
- L113: `Cannot access offset 'message' on mixed.` <sub>(cannot-access)</sub>
- L155: `Method App\Services\Notification\NotificationTemplateService::getDefaultTemplate() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Payment/NextPayGateway.php`  (9 خطا)
<sub>دستهها: cannot-access=6, never-read-property=2, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L27: `Property App\Services\Payment\NextPayGateway::$paymentGatewayModel is never read, only written.` <sub>(never-read-property)</sub>
- L29: `Property App\Services\Payment\NextPayGateway::$appSettings is never read, only written.` <sub>(never-read-property)</sub>
- L100: `Cannot access offset 'code' on mixed.` <sub>(cannot-access)</sub>
- L101: `Cannot access offset 'trans_id' on mixed.` <sub>(cannot-access)</sub>
- L110: `Part $transId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L190: `Cannot access offset 'code' on mixed.` <sub>(cannot-access)</sub>
- L193: `Cannot access offset 'Shaparak_Ref_Id' on mixed.` <sub>(cannot-access)</sub>
- L196: `Cannot access offset 'amount' on mixed.` <sub>(cannot-access)</sub>
- L203: `Cannot access offset 'Shaparak_Ref_Id' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Payment/ZarinPalGateway.php`  (9 خطا)
<sub>دستهها: cannot-access=5, never-read-property=2, encapsed-string=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Property App\Services\Payment\ZarinPalGateway::$paymentGatewayModel is never read, only written.` <sub>(never-read-property)</sub>
- L27: `Property App\Services\Payment\ZarinPalGateway::$appSettings is never read, only written.` <sub>(never-read-property)</sub>
- L96: `Cannot access offset 'code' on mixed.` <sub>(cannot-access)</sub>
- L96: `Cannot access offset 'data' on mixed.` <sub>(cannot-access)</sub>
- L97: `Cannot access offset 'authority' on mixed.` <sub>(cannot-access)</sub>
- L99: `Part $authority (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L100: `Part $authority (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L117: `Cannot access offset 'errors' on mixed.` <sub>(cannot-access)</sub>
- L117: `Cannot access offset 'message' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Shared/CouponService.php`  (9 خطا)
<sub>دستهها: return-type-mismatch(array)=3, unreachable=3, type-mismatch/expects=2, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L396: `Method App\Services\Shared\CouponService::all() should return array<int, stdClass> but returns array<int, object>.` <sub>(return-type-mismatch(array))</sub>
- L399: `Method App\Services\Shared\CouponService::all() should return array<int, stdClass> but returns array<int, object>.` <sub>(return-type-mismatch(array))</sub>
- L432: `Parameter #1 $code of method App\Models\Coupon::findByCode() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L438: `Parameter #1 $string of function strtoupper expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L449: `Method App\Services\Shared\CouponService::create() should return int|null but returns int|false.` <sub>(return-type-mismatch)</sub>
- L468: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L503: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L526: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L565: `Method App\Services\Shared\CouponService::paginate() should return array{data: array<int, stdClass>, total: int, page: int, per_page: int} but returns array{data: array{}|stdClass, total: int, page: int, per_page: int, total_pages: float}.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/UnifiedTaskService.php`  (9 خطا)
<sub>دستهها: type-mismatch/expects=9</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L72: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L91: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L96: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L101: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L128: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L177: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L194: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L198: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L202: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Commands/IdempotencyCommand.php`  (8 خطا)
<sub>دستهها: cast-mixed(int)=4, cannot-access=3, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L55: `Part $stats['error'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L58: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L66: `Cannot access offset 'count' on mixed.` <sub>(cannot-access)</sub>
- L66: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L67: `Cannot access offset 'last_hour' on mixed.` <sub>(cannot-access)</sub>
- L67: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L68: `Cannot access offset 'last_24h' on mixed.` <sub>(cannot-access)</sub>
- L68: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/KpiController.php`  (8 خطا)
<sub>دستهها: no-return-type=4, type-mismatch/expects=3, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L26: `Method App\Controllers\Admin\KpiController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L50: `Method App\Controllers\Admin\KpiController::chartData() has no return type specified.` <sub>(no-return-type)</sub>
- L54: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L73: `Method App\Controllers\Admin\KpiController::financial() has no return type specified.` <sub>(no-return-type)</sub>
- L93: `Method App\Controllers\Admin\KpiController::users() has no return type specified.` <sub>(no-return-type)</sub>
- L119: `Parameter #2 $rows of method App\Services\ExportService::exportCsv() expects array<int, array<string, mixed>>, array<int, array<int, mixed>> given.` <sub>(type-mismatch/expects)</sub>
- L135: `Parameter #2 $rows of method App\Services\ExportService::exportCsv() expects array<int, array<string, mixed>>, array<int, array<int, mixed>> given.` <sub>(type-mismatch/expects)</sub>
- L145: `Parameter #1 $data of method App\Services\ExportService::exportJson() expects array<string, mixed>, array<int|string, mixed> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/MessageModerationController.php`  (8 خطا)
<sub>دستهها: cast-mixed(int)=8</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L40: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L73: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L83: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L85: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L86: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L117: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L166: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L203: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Api/VerificationController.php`  (8 خطا)
<sub>دستهها: cast-mixed(int)=5, type-mismatch/expects=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L32: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L46: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L78: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L118: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L119: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L134: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L165: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L166: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/AdsApiController.php`  (8 خطا)
<sub>دستهها: cast-mixed(float)=5, nullsafe-on-non-nullable=2, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Controllers\User\AdsApiController::$adModel is never read, only written.` <sub>(never-read-property)</sub>
- L103: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L132: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L133: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L134: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L135: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L136: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L166: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Controllers/User/EscrowController.php`  (8 خطا)
<sub>دستهها: cast-mixed(string)=3, no-return-type=2, cast-mixed(int)=2, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L15: `Property App\Controllers\User\EscrowController::$escrowService is never read, only written.` <sub>(never-read-property)</sub>
- L56: `Method App\Controllers\User\EscrowController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L69: `Method App\Controllers\User\EscrowController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L73: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L74: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L75: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L108: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L122: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/LotteryController.php`  (8 خطا)
<sub>دستهها: cast-mixed(int)=4, no-return-type=3, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L46: `Method App\Controllers\User\LotteryController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L92: `Method App\Controllers\User\LotteryController::join() has no return type specified.` <sub>(no-return-type)</sub>
- L110: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L111: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L119: `Method App\Controllers\User\LotteryController::vote() has no return type specified.` <sub>(no-return-type)</sub>
- L138: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L139: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L140: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/SeoController.php`  (8 خطا)
<sub>دستهها: unreachable=4, never-read-property=2, type-mismatch/expects=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Property App\Controllers\User\SeoController::$searchService is never read, only written.` <sub>(never-read-property)</sub>
- L20: `Property App\Controllers\User\SeoController::$analytics is never read, only written.` <sub>(never-read-property)</sub>
- L98: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L104: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L112: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L194: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L212: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L213: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Payment/CreateCryptoDepositJob.php`  (8 خطا)
<sub>دستهها: type-mismatch/expects=2, cannot-access=2, encapsed-string=2, OTHER=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L31: `Return type of call to method Core\TransactionWrapper::runWithRetry() contains unresolvable type.` <sub>(OTHER)</sub>
- L33: `Parameter #1 $txHash of method App\Models\CryptoDeposit::findByHashAndNetworkForUpdate() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L33: `Parameter #2 $network of method App\Models\CryptoDeposit::findByHashAndNetworkForUpdate() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L52: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L66: `Cannot access property $id on int<min, -1>|int<1, max>.` <sub>(cannot-access)</sub>
- L66: `Part $data['amount'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L66: `Part $data['network'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L71: `Cannot access property $id on int<min, -1>|int<1, max>.` <sub>(cannot-access)</sub>

</details>

### `app/Jobs/Prediction/SettleGameJob.php`  (8 خطا)
<sub>دستهها: OTHER=6, unused=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Property App\Jobs\Prediction\SettleGameJob::$db is never written, only read.` <sub>(OTHER)</sub>
- L21: `Property App\Jobs\Prediction\SettleGameJob::$stateMachine is never written, only read.` <sub>(OTHER)</sub>
- L24: `Property App\Jobs\Prediction\SettleGameJob::$betModel is never written, only read.` <sub>(OTHER)</sub>
- L27: `Property App\Jobs\Prediction\SettleGameJob::$auditTrail is never written, only read.` <sub>(OTHER)</sub>
- L33: `Property App\Jobs\Prediction\SettleGameJob::$walletService is never written, only read.` <sub>(OTHER)</sub>
- L229: `Method App\Jobs\Prediction\SettleGameJob::cancelBetHold() is unused.` <sub>(unused)</sub>
- L229: `Method App\Jobs\Prediction\SettleGameJob::cancelBetHold() never returns null so it can be removed from the return type.` <sub>(OTHER)</sub>
- L281: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Listeners/InfluencerEventListeners.php`  (8 خطا)
<sub>دستهها: OTHER=5, type-mismatch/expects=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L39: `Method App\Listeners\InfluencerEventListeners::handleInfluencerOrderCreated() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L82: `Method App\Listeners\InfluencerEventListeners::handleInfluencerOrderCompleted() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L156: `Method App\Listeners\InfluencerEventListeners::handleInfluencerOrderRejected() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L232: `Method App\Listeners\InfluencerEventListeners::handleInfluencerOrderRefunded() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L286: `Method App\Listeners\InfluencerEventListeners::handleInfluencerProfileVerified() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L332: `Parameter #1 $userId of method App\Services\Gamification\XpService::award() expects int, App\Models\User given.` <sub>(type-mismatch/expects)</sub>
- L391: `Parameter #2 $aggregateId of method App\Services\OutboxService::record() expects int|string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L405: `Parameter #5 $explicitKey of method App\Services\Shared\IdempotencyService::executeWithTransaction() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Models/VitrineListing.php`  (8 خطا)
<sub>دستهها: cast-mixed(float)=4, return-type-mismatch(stdClass)=1, cast-mixed(int)=1, return-type-mismatch=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L66: `Method App\Models\VitrineListing::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L98: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L102: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L106: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L143: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L144: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L374: `Method App\Models\VitrineListing::adminStats() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L690: `Method App\Models\VitrineListing::searchNative() should return array<int, array<string, mixed>> but returns array<string, array<int, stdClass>|int>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/BackupService.php`  (8 خطا)
<sub>دستهها: cast-mixed(string)=4, type-mismatch/expects=3, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Method App\Services\BackupService::toObject() is unused.` <sub>(unused)</sub>
- L82: `Parameter #1 $command of function escapeshellcmd expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L115: `Parameter #1 $command of function escapeshellcmd expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L136: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L139: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L340: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L343: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L408: `Parameter #1 $command of function escapeshellcmd expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/CacheAdminService.php`  (8 خطا)
<sub>دستهها: cannot-call-on-nullable=5, type-mismatch/expects=2, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Method App\Services\CacheAdminService::toObject() is unused.` <sub>(unused)</sub>
- L170: `Cannot call method info() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L175: `Cannot call method scan() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L186: `Cannot call method ttl() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L187: `Cannot call method type() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L194: `Cannot call method strlen() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L292: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L293: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/SagaRecoveryWorker.php`  (8 خطا)
<sub>دستهها: cannot-access=6, unused=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Method App\Services\SagaRecoveryWorker::toObject() is unused.` <sub>(unused)</sub>
- L96: `Cannot access offset 'class' on mixed.` <sub>(cannot-access)</sub>
- L96: `Cannot access offset 'type' on mixed.` <sub>(cannot-access)</sub>
- L98: `Parameter #1 $class of function class_exists expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L108: `Cannot access offset 'result' on mixed.` <sub>(cannot-access)</sub>
- L109: `Cannot access offset 'name' on mixed.` <sub>(cannot-access)</sub>
- L114: `Cannot access offset 'name' on mixed.` <sub>(cannot-access)</sub>
- L122: `Cannot access offset 'name' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Sentry/Analytics/TrendAnalyzer.php`  (8 خطا)
<sub>دستهها: return-type-mismatch(array)=5, unused=1, cast-mixed(string)=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Method App\Services\Sentry\Analytics\TrendAnalyzer::toObject() is unused.` <sub>(unused)</sub>
- L105: `Method App\Services\Sentry\Analytics\TrendAnalyzer::detectAnomalies() should return array<string, mixed> but returns array<int<0, max>, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L122: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L132: `Method App\Services\Sentry\Analytics\TrendAnalyzer::forecast() should return array<string, mixed> but returns array<int<0, max>, array<string, float|int|string>>.` <sub>(return-type-mismatch(array))</sub>
- L154: `Part $trend['direction'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L157: `Method App\Services\Sentry\Analytics\TrendAnalyzer::detectPatterns() should return array<string, mixed> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L176: `Method App\Services\Sentry\Analytics\TrendAnalyzer::detectSpikes() should return array<string, mixed> but returns array<int<0, max>, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L230: `Method App\Services\Sentry\Analytics\TrendAnalyzer::getErrorHotspots() should return array<int, array<string, mixed>> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/User/UserDashboardService.php`  (8 خطا)
<sub>دستهها: always-true=4, always-evaluate=2, return-type-mismatch(array)=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L45: `Left side of && is always true.` <sub>(always-true)</sub>
- L46: `Method App\Services\User\UserDashboardService::getStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L181: `Call to function is_array() with stdClass|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L211: `Call to function is_array() with stdClass|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L273: `If condition is always true.` <sub>(always-true)</sub>
- L318: `Left side of && is always true.` <sub>(always-true)</sub>
- L319: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L328: `If condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/User/UserSettingsService.php`  (8 خطا)
<sub>دستهها: OTHER=4, return-type-mismatch(array)=2, no-return-type=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L108: `Method App\Services\User\UserSettingsService::getSettings() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L118: `Method App\Services\User\UserSettingsService::getAll() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L151: `Method App\Services\User\UserSettingsService::get() has no return type specified.` <sub>(no-return-type)</sub>
- L151: `Method App\Services\User\UserSettingsService::get() has parameter $default with no type specified.` <sub>(OTHER)</sub>
- L160: `Method App\Services\User\UserSettingsService::set() has parameter $value with no type specified.` <sub>(OTHER)</sub>
- L395: `Method App\Services\User\UserSettingsService::serializeValue() has parameter $value with no type specified.` <sub>(OTHER)</sub>
- L407: `Method App\Services\User\UserSettingsService::deserializeValue() has no return type specified.` <sub>(no-return-type)</sub>
- L430: `Method App\Services\User\UserSettingsService::validateSetting() has parameter $value with no type specified.` <sub>(OTHER)</sub>

</details>

### `app/Services/Wallet/WalletQueryService.php`  (8 خطا)
<sub>دستهها: type-mismatch/expects=4, cast-mixed(string)=2, return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L120: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L121: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L163: `Method App\Services\Wallet\WalletQueryService::getUserTransactions() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L163: `Parameter #2 $type of method App\Models\Transaction::getUserTransactions() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L163: `Parameter #3 $currency of method App\Models\Transaction::getUserTransactions() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L171: `Parameter #2 $type of method App\Models\Transaction::countUserTransactions() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L171: `Parameter #3 $currency of method App\Models\Transaction::countUserTransactions() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L177: `Method App\Services\Wallet\WalletQueryService::getAllTransactions() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Utils/Sentry/StackTraceAnalyzer.php`  (8 خطا)
<sub>دستهها: type-mismatch/expects=7, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L53: `Parameter #2 $callback of function array_filter expects (callable(non-empty-array<string, mixed>): bool)|null, Closure(mixed): mixed given.` <sub>(type-mismatch/expects)</sub>
- L74: `Parameter #1 $file of method App\Utils\Sentry\StackTraceAnalyzer::getRelativePath() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L77: `Parameter #1 $file of method App\Utils\Sentry\StackTraceAnalyzer::isVendorCode() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L80: `Parameter #1 $file of method App\Utils\Sentry\StackTraceAnalyzer::extractContext() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L80: `Parameter #2 $line of method App\Utils\Sentry\StackTraceAnalyzer::extractContext() expects int|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L87: `Parameter #1 $file of method App\Utils\Sentry\StackTraceAnalyzer::extractModule() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L92: `Parameter #1 $vars of method App\Utils\Sentry\StackTraceAnalyzer::sanitizeVars() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L140: `Method App\Utils\Sentry\StackTraceAnalyzer::formatFunction() should return string but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Validators/Requests/CreateWithdrawalRequest.php`  (8 خطا)
<sub>دستهها: cannot-access=4, type-mismatch/expects=2, cast-mixed(float)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Parameter #1 $string of function strtoupper expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L70: `Parameter #1 $string of function strtoupper expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L71: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L74: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L80: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L83: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L89: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L94: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Controllers/Admin/KYCController.php`  (7 خطا)
<sub>دستهها: unreachable=4, cast-mixed(int)=1, cannot-access=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L77: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L83: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L92: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L101: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L104: `Cannot access property $user_id on object|null.` <sub>(cannot-access)</sub>
- L171: `Parameter #3 $reason of method App\Services\KYCService::rejectKYC() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/SeoAdController.php`  (7 خطا)
<sub>دستهها: cast-mixed(int)=3, never-read-property=2, type-mismatch/expects=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L14: `Property App\Controllers\Admin\SeoAdController::$executionModel is never read, only written.` <sub>(never-read-property)</sub>
- L16: `Property App\Controllers\Admin\SeoAdController::$seoService is never read, only written.` <sub>(never-read-property)</sub>
- L38: `Parameter #2 $status of method App\Models\Ads::adminList() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L60: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L70: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L71: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L81: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/SocialAccountController.php`  (7 خطا)
<sub>دستهها: cast-mixed(int)=4, no-return-type=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Method App\Controllers\Admin\SocialAccountController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L23: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L49: `Method App\Controllers\Admin\SocialAccountController::show() has no return type specified.` <sub>(no-return-type)</sub>
- L51: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L70: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L84: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L95: `Parameter #3 $reason of method App\Services\SocialAccountService::reject() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/SocialTaskController.php`  (7 خطا)
<sub>دستهها: unreachable=4, never-read-property=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Property App\Controllers\Admin\SocialTaskController::$searchService is never read, only written.` <sub>(never-read-property)</sub>
- L25: `Property App\Controllers\Admin\SocialTaskController::$wallet is never read, only written.` <sub>(never-read-property)</sub>
- L26: `Property App\Controllers\Admin\SocialTaskController::$db is never read, only written.` <sub>(never-read-property)</sub>
- L90: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L218: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L262: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L380: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Controllers/Admin/SystemSettingController.php`  (7 خطا)
<sub>دستهها: cast-mixed(string)=3, cast-mixed(int)=3, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L37: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L62: `Method App\Controllers\Admin\SystemSettingController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L65: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L66: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L67: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L109: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L185: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/MetricsController.php`  (7 خطا)
<sub>دستهها: cast-mixed(string)=4, cannot-access=2, cannot-call-on-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L45: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L45: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L254: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L254: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L282: `Cannot call method ping() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L299: `Cannot access offset 'pending' on mixed.` <sub>(cannot-access)</sub>
- L300: `Cannot access offset 'failed' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Controllers/User/AuthController.php`  (7 خطا)
<sub>دستهها: type-mismatch/expects=3, cannot-access=2, no-return-type=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L79: `Cannot access offset 'email' on mixed.` <sub>(cannot-access)</sub>
- L218: `Cannot access property $id on mixed.` <sub>(cannot-access)</sub>
- L421: `Parameter #2 $data of function hash expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L444: `Parameter #1 $email of method App\Services\User\UserService::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L487: `Method App\Controllers\User\AuthController::resendVerification() has no return type specified.` <sub>(no-return-type)</sub>
- L500: `Part $email (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L508: `Parameter #1 $email of method App\Services\User\UserService::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/SocialTaskController.php`  (7 خطا)
<sub>دستهها: cast-mixed(string)=4, cast-mixed(int)=2, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L34: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L35: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L36: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L37: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L62: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L73: `Method App\Controllers\User\SocialTaskController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L86: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/WithdrawalController.php`  (7 خطا)
<sub>دستهها: no-return-type=2, cast-mixed(float)=2, never-read-property=1, always-true=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Controllers\User\WithdrawalController::$riskDecisionService is never read, only written.` <sub>(never-read-property)</sub>
- L49: `Method App\Controllers\User\WithdrawalController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L78: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L87: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L88: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L117: `Method App\Controllers\User\WithdrawalController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L263: `Parameter #1 $string of function strtoupper expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/CustomTask/RateSubmissionJob.php`  (7 خطا)
<sub>دستهها: cannot-access=3, cast-mixed(int)=2, never-read-property=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L23: `Property App\Jobs\CustomTask\RateSubmissionJob::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L71: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L76: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L77: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L85: `Cannot access property $user_id on stdClass|null.` <sub>(cannot-access)</sub>
- L90: `Cannot access property $user_id on stdClass|null.` <sub>(cannot-access)</sub>
- L101: `Cannot access property $id on stdClass|null.` <sub>(cannot-access)</sub>

</details>

### `app/Listeners/InvestmentEventListeners.php`  (7 خطا)
<sub>دستهها: OTHER=5, no-return-type=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L39: `Method App\Listeners\InvestmentEventListeners::handleInvestmentCreated() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L82: `Method App\Listeners\InvestmentEventListeners::handleInvestmentProfitApplied() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L133: `Method App\Listeners\InvestmentEventListeners::handleInvestmentWithdrawn() has no return type specified.` <sub>(no-return-type)</sub>
- L133: `Method App\Listeners\InvestmentEventListeners::handleInvestmentWithdrawn() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L232: `Method App\Listeners\InvestmentEventListeners::handleInvestmentCompleted() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L277: `Method App\Listeners\InvestmentEventListeners::handleInvestmentFrozen() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L331: `Parameter #2 $amount of method App\Services\Shared\ReferralService::processCommission() expects string, float given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Middleware/RateLimitMiddleware.php`  (7 خطا)
<sub>دستهها: cast-mixed(int)=2, cannot-access=2, cast-mixed(string)=2, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L39: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L40: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L150: `Cannot access offset 0 on mixed.` <sub>(cannot-access)</sub>
- L150: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L151: `Cannot access offset 1 on mixed.` <sub>(cannot-access)</sub>
- L151: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L211: `Method App\Middleware\RateLimitMiddleware::normalizeIp() is unused.` <sub>(unused)</sub>

</details>

### `app/Models/LotteryVote.php`  (7 خطا)
<sub>دستهها: always-true=4, cannot-access=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L88: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L89: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L104: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L111: `Method App\Models\LotteryVote::getVoteCounts() should return array<int, stdClass> but returns array<string, int>.` <sub>(return-type-mismatch(array))</sub>
- L123: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L124: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L139: `Ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Models/PredictionBet.php`  (7 خطا)
<sub>دستهها: cast-mixed(int)=4, cast-mixed(float)=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L29: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L31: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L32: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L56: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L56: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Models/PredictionGame.php`  (7 خطا)
<sub>دستهها: cast-mixed(float)=3, cast-mixed(string)=3, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L59: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L60: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L61: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L64: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L375: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L376: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L377: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/AntiFraud/AccountTakeoverService.php`  (7 خطا)
<sub>دستهها: type-mismatch/expects=5, OTHER=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L92: `Parameter #2 $array of function implode expects array<string>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L92: `Parameter #2 $array of function implode expects array|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L135: `Argument of an invalid type mixed supplied for foreach, only iterables are supported.` <sub>(OTHER)</sub>
- L136: `Part $anomaly (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L304: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L305: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L331: `Parameter #6 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/BulkOperationsService.php`  (7 خطا)
<sub>دستهها: unused=3, type-mismatch/expects=2, never-read-property=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Method App\Services\BulkOperationsService::toObject() is unused.` <sub>(unused)</sub>
- L46: `Property App\Services\BulkOperationsService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L291: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L602: `Method App\Services\BulkOperationsService::updateBatch() is unused.` <sub>(unused)</sub>
- L608: `Parameter #2 $ids of method App\Models\BulkOperation::applyBatchUpdate() expects array<int, int|string>, array<int, mixed> given.` <sub>(type-mismatch/expects)</sub>
- L615: `Method App\Services\BulkOperationsService::deleteBatch() is unused.` <sub>(unused)</sub>
- L617: `Parameter #2 $ids of method App\Models\BulkOperation::applyBatchDelete() expects array<int, int|string>, array<int, mixed> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/DatabaseAnalyzerService.php`  (7 خطا)
<sub>دستهها: return-type-mismatch(array)=3, always-evaluate=2, never-read-property=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L33: `Property App\Services\DatabaseAnalyzerService::$logSlowQueries is never read, only written.` <sub>(never-read-property)</sub>
- L44: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L85: `Call to function is_array() with object|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L100: `Method App\Services\DatabaseAnalyzerService::getCachingRecommendations() should return array<string, mixed> but returns array<int, array<string, int|string>>.` <sub>(return-type-mismatch(array))</sub>
- L253: `Method App\Services\DatabaseAnalyzerService::suggestIndexes() should return array<string, mixed> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L336: `Method App\Services\DatabaseAnalyzerService::getDeadlockInfo() should return array<string, mixed> but returns array<int, array<string, string>>.` <sub>(return-type-mismatch(array))</sub>
- L349: `Call to function is_array() with object|null will always evaluate to false.` <sub>(always-evaluate)</sub>

</details>

### `app/Services/DirectMessageCommandService.php`  (7 خطا)
<sub>دستهها: type-mismatch/expects=3, cast-mixed(int)=2, unused=1, always-condition=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Method App\Services\DirectMessageCommandService::toObject() is unused.` <sub>(unused)</sub>
- L87: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L164: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L172: `Parameter #1 $path of function storage_path expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L229: `Variable $senderId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L327: `Parameter #1 $string of function base64_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L358: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/EmailService.php`  (7 خطا)
<sub>دستهها: always-false=5, always-condition=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L261: `Variable $userId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L351: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L368: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L386: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L406: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L468: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L669: `Part $bodyContent (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Services/KYC/KYCCommandService.php`  (7 خطا)
<sub>دستهها: type-mismatch/expects=4, cannot-access=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L121: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L137: `Cannot access property $user_id on mixed.` <sub>(cannot-access)</sub>
- L146: `Parameter #1 $file of method App\Services\UploadService::upload() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L167: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L173: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L183: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L199: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/ManualDepositService.php`  (7 خطا)
<sub>دستهها: type-mismatch/expects=5, never-read-property=1, always-evaluate=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Property App\Services\ManualDepositService::$outbox is never read, only written.` <sub>(never-read-property)</sub>
- L65: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L66: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L67: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L99: `Parameter #5 $explicitKey of method App\Services\Shared\IdempotencyService::executeWithTransaction() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L127: `Instanceof between stdClass and App\Models\BankCard will always evaluate to false.` <sub>(always-evaluate)</sub>

</details>

### `app/Services/Notification/NotificationRetryPolicy.php`  (7 خطا)
<sub>دستهها: type-mismatch/expects=6, nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L79: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L96: `Using nullsafe method call on non-nullable type Throwable. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L99: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L99: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L100: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L104: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L104: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Notification/NotificationService.php`  (7 خطا)
<sub>دستهها: return-type-mismatch(array)=5, cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L146: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L147: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L292: `Method App\Services\Notification\NotificationService::latest() should return array<int, stdClass> but returns array<string, mixed>.` <sub>(return-type-mismatch(array))</sub>
- L299: `Method App\Services\Notification\NotificationService::getUserNotifications() should return array<int, stdClass> but returns array<string, mixed>.` <sub>(return-type-mismatch(array))</sub>
- L389: `Method App\Services\Notification\NotificationService::getAllTemplatesWithVariables() should return array<int, stdClass> but returns array<string, mixed>.` <sub>(return-type-mismatch(array))</sub>
- L423: `Method App\Services\Notification\NotificationService::getUsersBySegment() should return array<int, stdClass> but returns array<string, mixed>.` <sub>(return-type-mismatch(array))</sub>
- L430: `Method App\Services\Notification\NotificationService::getAvailableSegments() should return array<int, string> but returns array<string, mixed>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/PerformanceOptimizationService.php`  (7 خطا)
<sub>دستهها: unused=2, type-mismatch/expects=2, never-read-property=1, cast-mixed(float)=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Method App\Services\PerformanceOptimizationService::toObject() is unused.` <sub>(unused)</sub>
- L42: `Property App\Services\PerformanceOptimizationService::$logSlowQueries is never read, only written.` <sub>(never-read-property)</sub>
- L53: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L252: `Parameter #1 $name of method App\Services\PerformanceOptimizationService::isValidIdentifier() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L253: `Parameter #1 $name of method App\Services\PerformanceOptimizationService::quoteIdentifier() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L273: `Method App\Services\PerformanceOptimizationService::getAggregates() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L327: `Method App\Services\PerformanceOptimizationService::logSlowQuery() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Search/UserSearchProvider.php`  (7 خطا)
<sub>دستهها: type-mismatch/expects=4, return-type-mismatch(array)=2, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L34: `Parameter #1 $items of class App\Services\Search\SearchResult constructor expects array<int, stdClass>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L35: `Parameter #1 $value of function count expects array|Countable, mixed given.` <sub>(type-mismatch/expects)</sub>
- L35: `Parameter #2 $total of class App\Services\Search\SearchResult constructor expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L57: `Method App\Services\Search\UserSearchProvider::searchUser() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L80: `Parameter #1 $value of function count expects array|Countable, mixed given.` <sub>(type-mismatch/expects)</sub>
- L110: `Method App\Services\Search\UserSearchProvider::searchDomain() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Sentry/Alerting/AlertRulesEngine.php`  (7 خطا)
<sub>دستهها: cannot-access=3, unused=1, return-type-mismatch(array)=1, type-mismatch/expects=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Method App\Services\Sentry\Alerting\AlertRulesEngine::toObject() is unused.` <sub>(unused)</sub>
- L59: `Method App\Services\Sentry\Alerting\AlertRulesEngine::evaluateAllRules() should return array<int, array<string, mixed>> but returns array<int<0, max>, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L95: `Cannot access offset 'timestamp' on mixed.` <sub>(cannot-access)</sub>
- L96: `Cannot access offset 'value' on mixed.` <sub>(cannot-access)</sub>
- L96: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L166: `Cannot access offset 'metric' on mixed.` <sub>(cannot-access)</sub>
- L167: `Part $metric (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Services/Shared/ReferralService.php`  (7 خطا)
<sub>دستهها: never-read-property=3, always-true=2, unused=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L39: `Property App\Services\Shared\ReferralService::$outboxService is never read, only written.` <sub>(never-read-property)</sub>
- L41: `Property App\Services\Shared\ReferralService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L45: `Property App\Services\Shared\ReferralService::$auditTrail is never read, only written.` <sub>(never-read-property)</sub>
- L74: `Method App\Services\Shared\ReferralService::getTransactionWrapper() is unused.` <sub>(unused)</sub>
- L262: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L644: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L662: `Ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Controllers/Admin/DashboardController.php`  (6 خطا)
<sub>دستهها: unreachable=2, cast-mixed(int)=2, always-false=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L27: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L42: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L73: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L74: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L77: `Parameter #1 $type of method App\Services\AdminDashboard\AdminDashboardService::getRecentActivity() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/RiskPolicyController.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=4, no-return-type=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Method App\Controllers\Admin\RiskPolicyController::update() has no return type specified.` <sub>(no-return-type)</sub>
- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L31: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L33: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L34: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L47: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/UserController.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=3, cast-mixed(int)=1, always-false=1, always-evaluate=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L48: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L49: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L50: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L51: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L66: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L74: `Call to function is_array() with object will always evaluate to false.` <sub>(always-evaluate)</sub>

</details>

### `app/Controllers/Api/AppConfigController.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=4, type-mismatch/expects=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L34: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L35: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L38: `Parameter #1 $version1 of function version_compare expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L62: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L80: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Api/HealthCheckController.php`  (6 خطا)
<sub>دستهها: type-mismatch/expects=2, cast-mixed(int)=1, always-true=1, cast-mixed(string)=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L59: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L73: `If condition is always true.` <sub>(always-true)</sub>
- L114: `Parameter #1 $known_string of function hash_equals expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L114: `Parameter #2 $user_string of function hash_equals expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L165: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L187: `Part $value (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Controllers/Api/RealTimeController.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=4, cast-mixed(int)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L45: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L63: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L66: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L71: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L101: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L140: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/ContactController.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=4, type-mismatch/expects=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L45: `Parameter #1 $array of function reset is passed by reference, so it expects variables only.` <sub>(type-mismatch/expects)</sub>
- L54: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L55: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L56: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L57: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L72: `Parameter #2 $statusCode of method Core\Response::json() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/FileController.php`  (6 خطا)
<sub>دستهها: type-mismatch/expects=2, unused=2, always-condition=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L92: `Variable $folder on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>
- L115: `Parameter #1 $reason of method App\Controllers\FileController::deny() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L190: `Parameter #1 $string of function rawurlencode expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L243: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L248: `Method App\Controllers\FileController::allow() is unused.` <sub>(unused)</sub>
- L255: `Method App\Controllers\FileController::deny_result() is unused.` <sub>(unused)</sub>

</details>

### `app/Controllers/User/PredictionController.php`  (6 خطا)
<sub>دستهها: cast-mixed(float)=2, cast-mixed(string)=2, cast-mixed(int)=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L50: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L57: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L63: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L111: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L112: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L113: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/User/ReferralController.php`  (6 خطا)
<sub>دستهها: no-return-type=4, cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L32: `Method App\Controllers\User\ReferralController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L89: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L120: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L167: `Method App\Controllers\User\ReferralController::dashboard() has no return type specified.` <sub>(no-return-type)</sub>
- L214: `Method App\Controllers\User\ReferralController::analytics() has no return type specified.` <sub>(no-return-type)</sub>
- L230: `Method App\Controllers\User\ReferralController::milestones() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Domain/Financial/Services/LedgerService.php`  (6 خطا)
<sub>دستهها: cannot-access=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L121: `Cannot access property $total_debit on mixed.` <sub>(cannot-access)</sub>
- L122: `Cannot access property $total_credit on mixed.` <sub>(cannot-access)</sub>
- L168: `Cannot access property $total_debit on mixed.` <sub>(cannot-access)</sub>
- L169: `Cannot access property $total_credit on mixed.` <sub>(cannot-access)</sub>
- L202: `Cannot access property $total_debit on mixed.` <sub>(cannot-access)</sub>
- L203: `Cannot access property $total_credit on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Jobs/AntiFraud/CheckTaskFraudJob.php`  (6 خطا)
<sub>دستهها: type-mismatch/expects=5, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L39: `Parameter #1 $ip of method App\Services\AntiFraud\IPQualityService::check() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L41: `Parameter #2 $sessionId of method App\Services\AntiFraud\SessionAnomalyService::analyze() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L47: `Parameter #2 $behaviorData of method App\Services\AntiFraud\BehavioralBiometricsService::comprehensiveAnalysis() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L65: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L66: `Parameter #3 $engagementData of method App\Services\AntiFraud\SeoFraudDetector::detect() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Parameter #2 $sessionId of method App\Services\AntiFraud\SessionAnomalyService::analyze() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Auth/LinkSocialAccountSafeJob.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L33: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L34: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L35: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L36: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L37: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L38: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/Referral/ProcessReferralCommissionJob.php`  (6 خطا)
<sub>دستهها: cast-mixed(int)=4, cast-mixed(string)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L50: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L50: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L55: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L63: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L74: `Parameter #1 $key of method App\Models\ReferralCommission::findByIdempotencyKey() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/SocialTask/CalculateSilentRiskScoreJob.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=3, cast-mixed(int)=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Method App\Jobs\SocialTask\CalculateSilentRiskScoreJob::handle() should return array<string, mixed> but returns array.` <sub>(return-type-mismatch(array))</sub>
- L33: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L34: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L35: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L40: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L46: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/SocialTask/DecideSilentAntiFraudJob.php`  (6 خطا)
<sub>دستهها: cast-mixed(int)=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L31: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L33: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L34: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L35: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L36: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L64: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/UpdateFraudScoreJob.php`  (6 خطا)
<sub>دستهها: type-mismatch/expects=3, never-read-property=1, cast-mixed(int)=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Property App\Jobs\UpdateFraudScoreJob::$cache is never read, only written.` <sub>(never-read-property)</sub>
- L27: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L28: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L38: `Parameter #3 $domain of method App\Services\ScoreService::applyDelta() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L38: `Parameter #5 $source of method App\Services\ScoreService::applyDelta() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L38: `Parameter #6 $meta of method App\Services\ScoreService::applyDelta() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Middleware/ConcurrentRequestMiddleware.php`  (6 خطا)
<sub>دستهها: cannot-call-on-nullable=3, always-true=2, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Left side of && is always true.` <sub>(always-true)</sub>
- L31: `Part $userId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L37: `Cannot call method exists() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L40: `Cannot call method set() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L65: `Right side of && is always true.` <sub>(always-true)</sub>
- L67: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `app/Models/ExportData.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=5, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L33: `Method App\Models\ExportData::maskSensitiveRow() is unused.` <sub>(unused)</sub>
- L36: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L45: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L45: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/InvestmentProfit.php`  (6 خطا)
<sub>دستهها: always-true=3, return-type-mismatch(stdClass)=1, cannot-access=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L53: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L54: `Method App\Models\InvestmentProfit::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L118: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L119: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L137: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L139: `Method App\Models\InvestmentProfit::getTotalByInvestment() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Models/SocialTaskAnalyticsModel.php`  (6 خطا)
<sub>دستهها: type-mismatch/expects=3, return-type-mismatch(array)=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L33: `Parameter #1 $executionId of method App\Models\SocialTaskAnalyticsModel::hasUserRated() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L33: `Parameter #2 $raterId of method App\Models\SocialTaskAnalyticsModel::hasUserRated() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L33: `Parameter #3 $raterType of method App\Models\SocialTaskAnalyticsModel::hasUserRated() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L65: `Method App\Models\SocialTaskAnalyticsModel::getUserRatingHistory() should return array<int, array<string, mixed>> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L79: `Method App\Models\SocialTaskAnalyticsModel::getPendingRatings() should return array<int, array<string, mixed>> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L134: `Method App\Models\SocialTaskAnalyticsModel::getRatingHistoryFull() should return array<int, array<string, mixed>> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/AntiFraud/VideoFingerprintService.php`  (6 خطا)
<sub>دستهها: always-true=3, return-type-mismatch(array)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L194: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L196: `Method App\Services\AntiFraud\VideoFingerprintService::findExactMatch() should return array<string, mixed>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L224: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L339: `Parameter #1 $string of function trim expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L419: `Method App\Services\AntiFraud\VideoFingerprintService::getStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L430: `Ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/Auth/AuthSessionManager.php`  (6 خطا)
<sub>دستهها: cast-mixed(int)=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L161: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L165: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L232: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L243: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L248: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L250: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/CryptoDeposit/CryptoDepositService.php`  (6 خطا)
<sub>دستهها: never-read-property=2, unused=2, nullsafe-on-non-nullable=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Property App\Services\CryptoDeposit\CryptoDepositService::$reconciliationService is never read, only written.` <sub>(never-read-property)</sub>
- L30: `Property App\Services\CryptoDeposit\CryptoDepositService::$fraudGuard is never read, only written.` <sub>(never-read-property)</sub>
- L442: `Method App\Services\CryptoDeposit\CryptoDepositService::isAllowedNetwork() is unused.` <sub>(unused)</sub>
- L447: `Method App\Services\CryptoDeposit\CryptoDepositService::isValidTxHash() is unused.` <sub>(unused)</sub>
- L460: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L621: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Services/CustomTask/AdminCustomTaskService.php`  (6 خطا)
<sub>دستهها: never-read-property=3, always-true=2, return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Services\CustomTask\AdminCustomTaskService::$notificationService is never read, only written.` <sub>(never-read-property)</sub>
- L26: `Property App\Services\CustomTask\AdminCustomTaskService::$appSettings is never read, only written.` <sub>(never-read-property)</sub>
- L32: `Property App\Services\CustomTask\AdminCustomTaskService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L46: `Method App\Services\CustomTask\AdminCustomTaskService::toObject() should return stdClass|null but returns object.` <sub>(return-type-mismatch(stdClass))</sub>
- L195: `Right side of && is always true.` <sub>(always-true)</sub>
- L299: `Right side of && is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/DistributedLockService.php`  (6 خطا)
<sub>دستهها: cannot-call-on-nullable=4, unused=1, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Method App\Services\DistributedLockService::toObject() is unused.` <sub>(unused)</sub>
- L30: `Property App\Services\DistributedLockService::$useRedis is never read, only written.` <sub>(never-read-property)</sub>
- L120: `Cannot call method set() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L242: `Cannot call method eval() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L320: `Cannot call method eval() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L385: `Cannot call method exists() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `app/Services/Influencer/InfluencerCommandService.php`  (6 خطا)
<sub>دستهها: unreachable=5, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Services\Influencer\InfluencerCommandService::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L158: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L498: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L559: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L861: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L894: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Services/LogService.php`  (6 خطا)
<sub>دستهها: type-mismatch/expects=2, unused=1, return-type-mismatch=1, cast-mixed(string)=1, always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\LogService::toObject() is unused.` <sub>(unused)</sub>
- L38: `Method App\Services\LogService::getCorrelationId() should return string|null but returns mixed.` <sub>(return-type-mismatch)</sub>
- L88: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L91: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>
- L119: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L158: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Notification/NotificationAnalyticsService.php`  (6 خطا)
<sub>دستهها: return-type-mismatch(array)=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Method App\Services\Notification\NotificationAnalyticsService::getAnalyticsOverview() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L40: `Method App\Services\Notification\NotificationAnalyticsService::getAnalyticsByType() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L50: `Method App\Services\Notification\NotificationAnalyticsService::getAnalyticsDailyTrend() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L60: `Method App\Services\Notification\NotificationAnalyticsService::getAnalyticsSegmentStats() should return array<int, stdClass> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L70: `Method App\Services\Notification\NotificationAnalyticsService::getAnalyticsFunnelStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L80: `Method App\Services\Notification\NotificationAnalyticsService::getAnalyticsFatigueReport() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/ReferralManagementService.php`  (6 خطا)
<sub>دستهها: always-true=3, return-type-mismatch(array)=1, cannot-access=1, always-evaluate=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L121: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L138: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L200: `Method App\Services\ReferralManagementService::checkMilestones() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L249: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L250: `Cannot access property $total on mixed.` <sub>(cannot-access)</sub>
- L271: `Call to function is_array() with object will always evaluate to false.` <sub>(always-evaluate)</sub>

</details>

### `app/Services/Sentry/SentryExceptionHandler.php`  (6 خطا)
<sub>دستهها: cast-mixed(int)=3, cast-mixed(string)=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L185: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L211: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L250: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L275: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L276: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L393: `Method App\Services\Sentry\SentryExceptionHandler::readCircuitFile() should return array<string, mixed>|null but returns array|null.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Settings/SettingsManager.php`  (6 خطا)
<sub>دستهها: always-true=3, type-mismatch/expects=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L66: `If condition is always true.` <sub>(always-true)</sub>
- L67: `Parameter #1 $changedKeys of class App\Events\SettingsUpdated constructor expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L105: `If condition is always true.` <sub>(always-true)</sub>
- L106: `Parameter #1 $changedKeys of class App\Events\SettingsUpdated constructor expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L138: `Right side of && is always true.` <sub>(always-true)</sub>
- L140: `Parameter #1 $changedKeys of class App\Events\SettingsUpdated constructor expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/UploadService.php`  (6 خطا)
<sub>دستهها: cast-mixed(string)=3, cast-mixed(int)=2, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L51: `Method App\Services\UploadService::toObject() is unused.` <sub>(unused)</sub>
- L517: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L518: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L601: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L604: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L626: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/User/UserLevelCommandService.php`  (6 خطا)
<sub>دستهها: cannot-access=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L64: `Cannot access property $last_active_date on mixed.` <sub>(cannot-access)</sub>
- L151: `Cannot access property $level_slug on mixed.` <sub>(cannot-access)</sub>
- L182: `Cannot access property $level_slug on mixed.` <sub>(cannot-access)</sub>
- L219: `Cannot access property $level_slug on mixed.` <sub>(cannot-access)</sub>
- L226: `Cannot access property $level_slug on mixed.` <sub>(cannot-access)</sub>
- L235: `Cannot access property $level_slug on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Validators/Requests/CreateCustomTaskRequest.php`  (6 خطا)
<sub>دستهها: cannot-access=3, cast-mixed(float)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L76: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L79: `Parameter #1 $string of function strtoupper expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L80: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L87: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L93: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L99: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `core/CircuitBreaker.php`  (6 خطا)
<sub>دستهها: cast-mixed(int)=3, cannot-access=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L41: `Cannot access offset 'threshold' on mixed.` <sub>(cannot-access)</sub>
- L41: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L46: `Cannot access offset 'timeout' on mixed.` <sub>(cannot-access)</sub>
- L46: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L58: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L155: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `core/Console/CliDispatcher.php`  (6 خطا)
<sub>دستهها: type-mismatch/expects=2, generic-template-unresolved=1, return-type-mismatch(array)=1, cannot-access=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L42: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>
- L44: `Parameter #4 $className of method Core\Console\CliDispatcher::executeCommand() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L59: `Method Core\Console\CliDispatcher::resolveCommand() should return array<string, mixed>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L135: `Cannot access offset 'description' on mixed.` <sub>(cannot-access)</sub>
- L141: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `core/RedisSessionHandler.php`  (6 خطا)
<sub>دستهها: cannot-call-on-nullable=4, cast-mixed(int)=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L102: `Cannot call method get() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L109: `Cannot call method expire() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L115: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L129: `Cannot call method setEx() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L147: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `core/ValueObjects/Money.php`  (6 خطا)
<sub>دستهها: always-evaluate=6</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L51: `Call to function is_double() with int|string will always evaluate to false.` <sub>(always-evaluate)</sub>
- L51: `Call to function is_float() with int|string will always evaluate to false.` <sub>(always-evaluate)</sub>
- L129: `Call to function is_double() with int|string will always evaluate to false.` <sub>(always-evaluate)</sub>
- L129: `Call to function is_float() with int|string will always evaluate to false.` <sub>(always-evaluate)</sub>
- L142: `Call to function is_double() with int|string will always evaluate to false.` <sub>(always-evaluate)</sub>
- L142: `Call to function is_float() with int|string will always evaluate to false.` <sub>(always-evaluate)</sub>

</details>

### `app/Controllers/Admin/ApiTokenAdminController.php`  (5 خطا)
<sub>دستهها: cast-mixed(int)=2, type-mismatch/expects=1, cast-mixed(string)=1, OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L29: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L46: `Offset 'tokens' does not exist on array{items: array<int, stdClass>, total: int}.` <sub>(OTHER)</sub>
- L65: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/EmailQueueController.php`  (5 خطا)
<sub>دستهها: cast-mixed(int)=2, never-read-property=1, cast-mixed(string)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L12: `Property App\Controllers\Admin\EmailQueueController::$model is never read, only written.` <sub>(never-read-property)</sub>
- L32: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L35: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L36: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L78: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/VitrineController.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=2, never-read-property=1, OTHER=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Property App\Controllers\Admin\VitrineController::$wallet is never read, only written.` <sub>(never-read-property)</sub>
- L23: `Property App\Controllers\Admin\VitrineController::$listingModel is never written, only read.` <sub>(OTHER)</sub>
- L172: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L326: `Parameter #1 $ok of method App\Controllers\Admin\VitrineController::jsonOrRedirect() expects bool, mixed given.` <sub>(type-mismatch/expects)</sub>
- L326: `Parameter #2 $msg of method App\Controllers\Admin\VitrineController::jsonOrRedirect() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/BannerController.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=4, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L23: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L32: `Parameter #1 $url of function parse_url expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L36: `Parameter #1 $string of function strtolower expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L49: `Parameter #2 $subject of function preg_match expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L50: `Parameter #1 $path of function redirect expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/KYCController.php`  (5 خطا)
<sub>دستهها: no-return-type=2, never-read-property=1, type-mismatch/expects=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L15: `Property App\Controllers\User\KYCController::$uploadService is never read, only written.` <sub>(never-read-property)</sub>
- L105: `Method App\Controllers\User\KYCController::submit() has no return type specified.` <sub>(no-return-type)</sub>
- L156: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L201: `Method App\Controllers\User\KYCController::status() has no return type specified.` <sub>(no-return-type)</sub>
- L241: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/LevelController.php`  (5 خطا)
<sub>دستهها: cannot-access=2, type-mismatch/expects=2, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Method App\Controllers\User\LevelController::index() has no return type specified.` <sub>(no-return-type)</sub>
- L57: `Cannot access offset 'level' on mixed.` <sub>(cannot-access)</sub>
- L58: `Cannot access offset 'currency' on mixed.` <sub>(cannot-access)</sub>
- L63: `Parameter #2 $levelSlug of method App\Services\User\UserLevelService::purchaseLevel() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L63: `Parameter #3 $currency of method App\Services\User\UserLevelService::purchaseLevel() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/SettingsController.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=2, cast-mixed(int)=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L82: `Parameter #1 $array of function reset is passed by reference, so it expects variables only.` <sub>(type-mismatch/expects)</sub>
- L94: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L229: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L255: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L378: `Parameter #2 $password of method App\Services\User\UserSettingsService::requestAccountDeletion() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/TransferController.php`  (5 خطا)
<sub>دستهها: no-return-type=2, cast-mixed(string)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Method App\Controllers\User\TransferController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L41: `Method App\Controllers\User\TransferController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L49: `Parameter #1 $array of function reset is passed by reference, so it expects variables only.` <sub>(type-mismatch/expects)</sub>
- L54: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L55: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/KycTimeoutJob.php`  (5 خطا)
<sub>دستهها: cast-mixed(int)=3, OTHER=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Jobs\KycTimeoutJob::$db is never written, only read.` <sub>(OTHER)</sub>
- L27: `Property App\Jobs\KycTimeoutJob::$logger is never written, only read.` <sub>(OTHER)</sub>
- L51: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L52: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L53: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/SendEmailJob.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=4, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L47: `Parameter #1 $toEmail of method App\Services\EmailService::sendDirect() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L47: `Parameter #2 $toName of method App\Services\EmailService::sendDirect() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L47: `Parameter #3 $subject of method App\Services\EmailService::sendDirect() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L47: `Parameter #4 $bodyHtml of method App\Services\EmailService::sendDirect() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Vitrine/ReleaseVitrineFundsJob.php`  (5 خطا)
<sub>دستهها: never-read-property=2, cast-mixed(string)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Property App\Jobs\Vitrine\ReleaseVitrineFundsJob::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L26: `Property App\Jobs\Vitrine\ReleaseVitrineFundsJob::$escrowService is never read, only written.` <sub>(never-read-property)</sub>
- L56: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L81: `Parameter #1 $message of class Core\Exceptions\ApplicationException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L84: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Middleware/MaintenanceMiddleware.php`  (5 خطا)
<sub>دستهها: cast-mixed(string)=5</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L32: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L36: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L50: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L74: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L103: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/InfluencerVerification.php`  (5 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=5</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Method App\Models\InfluencerVerification::findPendingByProfile() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L66: `Method App\Models\InfluencerVerification::findById() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L76: `Method App\Models\InfluencerVerification::findByIdForUpdate() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L91: `Method App\Models\InfluencerVerification::findSubmittedByProfile() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L167: `Method App\Models\InfluencerVerification::findLatestByProfile() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Services/Auth/AuthService.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=3, return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L285: `Method App\Services\Auth\AuthService::validateRegister() should return array<string, mixed> but returns array<int<0, max>, mixed>.` <sub>(return-type-mismatch(array))</sub>
- L289: `Parameter #1 $email of method App\Services\User\UserService::emailExists() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L293: `Parameter #1 $password of static method App\Validators\PasswordPolicy::validate() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L302: `Method App\Services\Auth\AuthService::validateRegister() should return array<string, mixed> but returns array<int|string, mixed>.` <sub>(return-type-mismatch(array))</sub>
- L358: `Parameter #1 $user of method App\Services\Auth\AuthSessionManager::finalizeSessionAfter2FA() expects stdClass, object given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Auth/GoogleJwtVerifier.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=5</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L182: `Parameter #1 $value of method App\Services\Auth\GoogleJwtVerifier::base64UrlDecode() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L183: `Parameter #1 $value of method App\Services\Auth\GoogleJwtVerifier::base64UrlDecode() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L193: `Parameter #1 $elements of method App\Services\Auth\GoogleJwtVerifier::encodeSequence() expects array<int, array<string, mixed>>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L204: `Parameter #1 $elements of method App\Services\Auth\GoogleJwtVerifier::encodeSequence() expects array<int, array<string, mixed>>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>
- L217: `Parameter #2 $array of function implode expects array<string>, array<int, array<string, mixed>> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/DirectMessageQueryService.php`  (5 خطا)
<sub>دستهها: cast-mixed(int)=2, unused=1, always-true=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Method App\Services\DirectMessageQueryService::toObject() is unused.` <sub>(unused)</sub>
- L189: `Left side of && is always true.` <sub>(always-true)</sub>
- L198: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L218: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L249: `Parameter #1 $string of function base64_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/DirectMessageService.php`  (5 خطا)
<sub>دستهها: return-type-mismatch(array)=3, unused=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Method App\Services\DirectMessageService::toObject() is unused.` <sub>(unused)</sub>
- L63: `Parameter #4 $attachments of method App\Services\DirectMessageCommandService::sendMessage() expects array<int, array<string, mixed>>|null, array<int|string, mixed>|null given.` <sub>(type-mismatch/expects)</sub>
- L73: `Method App\Services\DirectMessageService::getConversation() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L79: `Method App\Services\DirectMessageService::getConversations() should return array<int, stdClass> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L107: `Method App\Services\DirectMessageService::getTypingUsers() should return array<int, stdClass> but returns array<int, int>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Investment/InvestmentQueryService.php`  (5 خطا)
<sub>دستهها: cast-mixed(float)=4, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Services\Investment\InvestmentQueryService::$db is never read, only written.` <sub>(never-read-property)</sub>
- L113: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L114: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L115: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L116: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Services/Lottery/LotteryCommandService.php`  (5 خطا)
<sub>دستهها: never-read-property=4, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L41: `Property App\Services\Lottery\LotteryCommandService::$voteModel is never read, only written.` <sub>(never-read-property)</sub>
- L42: `Property App\Services\Lottery\LotteryCommandService::$chanceLogModel is never read, only written.` <sub>(never-read-property)</sub>
- L44: `Property App\Services\Lottery\LotteryCommandService::$cache is never read, only written.` <sub>(never-read-property)</sub>
- L48: `Property App\Services\Lottery\LotteryCommandService::$escrow is never read, only written.` <sub>(never-read-property)</sub>
- L386: `Method App\Services\Lottery\LotteryCommandService::cancelRound() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Lottery/LotteryService.php`  (5 خطا)
<sub>دستهها: never-read-property=5</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Property App\Services\Lottery\LotteryService::$logger is never read, only written.` <sub>(never-read-property)</sub>
- L30: `Property App\Services\Lottery\LotteryService::$cache is never read, only written.` <sub>(never-read-property)</sub>
- L31: `Property App\Services\Lottery\LotteryService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L32: `Property App\Services\Lottery\LotteryService::$walletService is never read, only written.` <sub>(never-read-property)</sub>
- L33: `Property App\Services\Lottery\LotteryService::$idempotencyService is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Services/Payment/BasePaymentGateway.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=3, return-type-mismatch=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L102: `Method App\Services\Payment\BasePaymentGateway::getCallbackSecret() should return string|null but returns mixed.` <sub>(return-type-mismatch)</sub>
- L111: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L130: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L132: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L388: `Method App\Services\Payment\BasePaymentGateway::executeWithCircuitBreaker() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Score/ScoreCommandService.php`  (5 خطا)
<sub>دستهها: never-read-property=2, always-true=1, cast-mixed(int)=1, nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Property App\Services\Score\ScoreCommandService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L29: `Property App\Services\Score\ScoreCommandService::$rateLimiter is never read, only written.` <sub>(never-read-property)</sub>
- L126: `Comparison operation "<" between 0.35|0.48999999999999994|0.5|0.7 and 1.0 is always true.` <sub>(always-true)</sub>
- L142: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L277: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Services/Search/SearchQuery.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=5</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L46: `Parameter #1 $term of class App\Services\Search\SearchQuery constructor expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L47: `Parameter #2 $filters of class App\Services\Search\SearchQuery constructor expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L48: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L49: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L50: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Sentry/Analytics/DashboardService.php`  (5 خطا)
<sub>دستهها: return-type-mismatch(array)=4, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Method App\Services\Sentry\Analytics\DashboardService::toObject() is unused.` <sub>(unused)</sub>
- L45: `Method App\Services\Sentry\Analytics\DashboardService::getOverview() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L307: `Method App\Services\Sentry\Analytics\DashboardService::getTopSlowestEndpoints() should return array<int, array<string, mixed>> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L316: `Method App\Services\Sentry\Analytics\DashboardService::getTopErrorSources() should return array<int, array<string, mixed>> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L363: `Method App\Services\Sentry\Analytics\DashboardService::calculateChange() should return array{value: int, direction: string} but returns array{value: float, direction: 'down'|'stable'|'up'}.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/SitemapService.php`  (5 خطا)
<sub>دستهها: return-type-mismatch=2, unused=1, type-mismatch/expects=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\SitemapService::toObject() is unused.` <sub>(unused)</sub>
- L58: `Parameter #1 $string of function rtrim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L105: `Method App\Services\SitemapService::getXml() should return string but returns mixed.` <sub>(return-type-mismatch)</sub>
- L115: `Method App\Services\SitemapService::getXml() should return string but returns mixed.` <sub>(return-type-mismatch)</sub>
- L128: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/TicketCommandService.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=4, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L38: `Property App\Services\TicketCommandService::$transactionWrapper is never read, only written.` <sub>(never-read-property)</sub>
- L119: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L127: `Parameter #1 $string of function strip_tags expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L160: `Parameter #1 $string of function strip_tags expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L183: `Parameter #5 $explicitKey of method App\Services\Shared\IdempotencyService::executeWithTransaction() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/VerificationService.php`  (5 خطا)
<sub>دستهها: cast-mixed(int)=2, type-mismatch/expects=1, return-type-mismatch(array)=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L112: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L145: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L284: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L491: `Method App\Services\VerificationService::getVerificationHistory() should return array<string, mixed> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>
- L540: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Validators/PasswordPolicy.php`  (5 خطا)
<sub>دستهها: cast-mixed(int)=2, type-mismatch/expects=1, return-type-mismatch(array)=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L31: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L32: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L90: `Parameter #1 $num of function number_format expects float, mixed given.` <sub>(type-mismatch/expects)</sub>
- L94: `Method App\Validators\PasswordPolicy::validate() should return array<string, mixed> but returns array<int, string>.` <sub>(return-type-mismatch(array))</sub>
- L170: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Validators/RegisterRequest.php`  (5 خطا)
<sub>دستهها: cast-mixed(int)=2, cast-mixed(string)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L29: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L37: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L44: `Parameter #1 ...$arrays of function array_merge expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L53: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `core/CSRF.php`  (5 خطا)
<sub>دستهها: type-mismatch/expects=5</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L46: `Parameter #1 $known_string of function hash_equals expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L88: `Parameter #1 $url of function parse_url expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L96: `Parameter #1 $url of function parse_url expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L99: `Parameter #1 $url of function parse_url expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L104: `Parameter #1 $url of function parse_url expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `core/RetryPolicy.php`  (5 خطا)
<sub>دستهها: cast-mixed(int)=2, always-evaluate=2, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L47: `Method Core\RetryPolicy::executeWithContext() has no return type specified.` <sub>(no-return-type)</sub>
- L137: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L138: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L179: `Instanceof between Exception and TypeError will always evaluate to false.` <sub>(always-evaluate)</sub>
- L180: `Instanceof between Exception and ParseError will always evaluate to false.` <sub>(always-evaluate)</sub>

</details>

### `app/Commands/StuckWithdrawalReviewCommand.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L96: `Parameter #2 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L96: `Parameter #3 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L96: `Parameter #4 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L96: `Parameter #5 ...$values of function sprintf expects bool|float|int|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/CacheAdminController.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Parameter #1 $type of method App\Services\CacheAdminService::clear() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L35: `Parameter #2 $tag of method App\Services\CacheAdminService::clear() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L46: `Parameter #1 $key of method App\Services\CacheAdminService::forget() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L68: `Parameter #1 $name of method App\Services\CacheAdminService::resetCircuitBreaker() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Admin/FraudManagementController.php`  (4 خطا)
<sub>دستهها: no-return-type=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Method App\Controllers\Admin\FraudManagementController::ipBlacklist() has no return type specified.` <sub>(no-return-type)</sub>
- L78: `Method App\Controllers\Admin\FraudManagementController::deviceBlacklist() has no return type specified.` <sub>(no-return-type)</sub>
- L121: `Method App\Controllers\Admin\FraudManagementController::fraudLogs() has no return type specified.` <sub>(no-return-type)</sub>
- L138: `Method App\Controllers\Admin\FraudManagementController::resetFraudScore() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/Api/FingerprintController.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=3, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L26: `Method App\Controllers\Api\FingerprintController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L44: `Parameter #1 $data of method App\Services\AntiFraud\BrowserFingerprintService::generate() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L46: `Parameter #2 $user_string of function hash_equals expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L53: `Parameter #3 $metadata of method App\Services\AntiFraud\BrowserFingerprintService::store() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/BaseController.php`  (4 خطا)
<sub>دستهها: cast-mixed(string)=2, cast-mixed(int)=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L91: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L175: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L180: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L239: `Cannot access offset 0 on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Controllers/CaptchaController.php`  (4 خطا)
<sub>دستهها: cast-mixed(string)=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L27: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L40: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L61: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L72: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/HomeController.php`  (4 خطا)
<sub>دستهها: cannot-access=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L50: `Cannot access offset 'total' on mixed.` <sub>(cannot-access)</sub>
- L51: `Cannot access offset 'total_completed' on mixed.` <sub>(cannot-access)</sub>
- L52: `Cannot access offset 'total_count' on mixed.` <sub>(cannot-access)</sub>
- L53: `Cannot access offset 'total_winners' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Controllers/User/DisputeController.php`  (4 خطا)
<sub>دستهها: cast-mixed(int)=3, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L50: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L77: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L80: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Auth/OAuthHelperTrait.php (in context of class App\Jobs\Auth\HandleFacebookCallbackJob)`  (4 خطا)
<sub>دستهها: type-mismatch/expects=2, cannot-access=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L241: `Cannot access offset 'is_valid' on mixed.` <sub>(cannot-access)</sub>
- L305: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L345: `Parameter #1 $email of method App\Models\User::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L376: `Parameter #1 $email of method App\Models\User::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Auth/OAuthHelperTrait.php (in context of class App\Jobs\Auth\HandleGoogleCallbackJob)`  (4 خطا)
<sub>دستهها: type-mismatch/expects=2, cannot-access=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L241: `Cannot access offset 'is_valid' on mixed.` <sub>(cannot-access)</sub>
- L305: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L345: `Parameter #1 $email of method App\Models\User::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L376: `Parameter #1 $email of method App\Models\User::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Auth/OAuthHelperTrait.php (in context of class App\Jobs\Auth\LinkSocialAccountSafeJob)`  (4 خطا)
<sub>دستهها: type-mismatch/expects=2, cannot-access=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L241: `Cannot access offset 'is_valid' on mixed.` <sub>(cannot-access)</sub>
- L305: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L345: `Parameter #1 $email of method App\Models\User::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L376: `Parameter #1 $email of method App\Models\User::findByEmail() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Notification/SendToAdminsNotificationJob.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Parameter #1 $url of method App\Jobs\Notification\SendToAdminsNotificationJob::sanitizeUrl() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L53: `Parameter #1 $text of method App\Jobs\Notification\SendToAdminsNotificationJob::sanitizeNotificationText() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L72: `Parameter #2 $type of method App\Services\Notification\NotificationPolicyService::canSendInApp() expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L82: `Parameter #2 $type of method App\Services\Notification\NotificationPolicyService::canSendPush() expects string, string|null given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Prediction/CancelGameJob.php`  (4 خطا)
<sub>دستهها: OTHER=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L15: `Property App\Jobs\Prediction\CancelGameJob::$db is never written, only read.` <sub>(OTHER)</sub>
- L18: `Property App\Jobs\Prediction\CancelGameJob::$stateMachine is never written, only read.` <sub>(OTHER)</sub>
- L21: `Property App\Jobs\Prediction\CancelGameJob::$betModel is never written, only read.` <sub>(OTHER)</sub>
- L24: `Property App\Jobs\Prediction\CancelGameJob::$walletService is never written, only read.` <sub>(OTHER)</sub>

</details>

### `app/Jobs/Prediction/PlaceBetJob.php`  (4 خطا)
<sub>دستهها: cannot-call-on-nullable=2, never-read-property=1, OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Property App\Jobs\Prediction\PlaceBetJob::$escrowService is never read, only written.` <sub>(never-read-property)</sub>
- L68: `Anonymous function has an unused use $explicitKey.` <sub>(OTHER)</sub>
- L68: `Cannot call method execute() on App\Services\Shared\IdempotencyService|null.` <sub>(cannot-call-on-nullable)</sub>
- L75: `Cannot call method synchronized() on App\Services\DistributedLockService|null.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `app/Jobs/SystemCleanupJob.php`  (4 خطا)
<sub>دستهها: cast-mixed(int)=2, always-true=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L30: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L89: `Result of || is always true.` <sub>(always-true)</sub>
- L90: `If condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Jobs/Vitrine/CreateVitrineListingJob.php`  (4 خطا)
<sub>دستهها: cast-mixed(float)=3, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L45: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L51: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L52: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L53: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Middleware/AdminMiddleware.php`  (4 خطا)
<sub>دستهها: cast-mixed(int)=3, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L67: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L68: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L78: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L84: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Middleware/CSRFMiddleware.php`  (4 خطا)
<sub>دستهها: cast-mixed(string)=3, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L78: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L194: `Parameter #2 $user_string of function hash_equals expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L214: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L218: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Middleware/CorsMiddleware.php`  (4 خطا)
<sub>دستهها: cast-mixed(string)=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L41: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L50: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L60: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L77: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Middleware/GlobalExceptionMiddleware.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=2, cast-mixed(string)=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L47: `Parameter #1 $code of method Core\Response::setStatusCode() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L62: `Parameter #1 $code of method Core\Response::setStatusCode() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L80: `Part $statusCode (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Models/Role.php`  (4 خطا)
<sub>دستهها: cast-mixed(string)=2, return-type-mismatch(stdClass)=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Method App\Models\Role::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L82: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L86: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Models/ScheduledPayment.php`  (4 خطا)
<sub>دستهها: cast-mixed(string)=2, cast-mixed(int)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L14: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L15: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L16: `Parameter #1 $string of function strtolower expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L28: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/Ticket.php`  (4 خطا)
<sub>دستهها: cast-mixed(int)=3, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L59: `Method App\Models\Ticket::fetchAllRows() is unused.` <sub>(unused)</sub>
- L215: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L220: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L266: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Models/Withdrawal.php`  (4 خطا)
<sub>دستهها: cannot-access=2, return-type-mismatch(stdClass)=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L54: `Method App\Models\Withdrawal::lockForUpdate() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L69: `Method App\Models\Withdrawal::getSummaryStats() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L246: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>
- L311: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/AntiFraud/FraudGuardService.php`  (4 خطا)
<sub>دستهها: cannot-access=3, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L94: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L143: `Cannot access offset 'allowed' on mixed.` <sub>(cannot-access)</sub>
- L146: `Cannot access offset 'reason' on mixed.` <sub>(cannot-access)</sub>
- L149: `Cannot access offset 'allowed' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/AntiFraud/RateLimitingService.php`  (4 خطا)
<sub>دستهها: cannot-access=2, type-mismatch/expects=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L59: `Cannot access offset 'action' on mixed.` <sub>(cannot-access)</sub>
- L59: `Cannot access offset 'key' on mixed.` <sub>(cannot-access)</sub>
- L59: `Parameter #1 $action of method App\Policies\RateLimitPolicy::check() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L59: `Parameter #2 $identifier of method App\Policies\RateLimitPolicy::check() expects int|string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/ApiTokenService.php`  (4 خطا)
<sub>دستهها: return-type-mismatch(array)=2, always-false=1, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L81: `Method App\Services\ApiTokenService::getTokensForAdmin() should return array{items: array<int, stdClass>, total: int} but returns array{tokens: array<int, object>, total: int, page: int<1, max>, perPage: int<1, 100>, stats: array<string, int>, totalPages: int}.` <sub>(return-type-mismatch(array))</sub>
- L116: `Method App\Services\ApiTokenService::listTokensForUser() should return array<int, stdClass> but returns array<object>.` <sub>(return-type-mismatch(array))</sub>
- L161: `Negated boolean expression is always false.` <sub>(always-false)</sub>
- L281: `Method App\Services\ApiTokenService::getDummyHash() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/BannerService.php`  (4 خطا)
<sub>دستهها: cannot-call-on-nullable=3, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Services\BannerService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L108: `Cannot call method hIncrBy() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L683: `Cannot call method hGetAll() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L701: `Cannot call method hIncrBy() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `app/Services/CustomTask/CustomTaskModerationService.php`  (4 خطا)
<sub>دستهها: never-read-property=3, nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Property App\Services\CustomTask\CustomTaskModerationService::$appSettings is never read, only written.` <sub>(never-read-property)</sub>
- L29: `Property App\Services\CustomTask\CustomTaskModerationService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L33: `Property App\Services\CustomTask\CustomTaskModerationService::$sagaOrchestrator is never read, only written.` <sub>(never-read-property)</sub>
- L293: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Services/DlqWorker.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=3, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Method App\Services\DlqWorker::toObject() is unused.` <sub>(unused)</sub>
- L109: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L111: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L124: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Gamification/TrustService.php`  (4 خطا)
<sub>دستهها: always-evaluate=2, never-read-property=1, always-condition=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Property App\Services\Gamification\TrustService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L137: `Call to function is_array() with object|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L169: `Call to function is_array() with object|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L172: `Offset 'reject_count' on *NEVER* on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>

</details>

### `app/Services/KYC/KYCQueryService.php`  (4 خطا)
<sub>دستهها: unreachable=2, always-true=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L66: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L189: `Left side of && is always true.` <sub>(always-true)</sub>
- L204: `Left side of && is always true.` <sub>(always-true)</sub>
- L258: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Services/Notification/NotificationPreferenceService.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=2, return-type-mismatch=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L53: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L55: `Property App\Services\Notification\NotificationPreferenceService::$localCache (array<int, object>) does not accept array<int, mixed>.` <sub>(type-mismatch/expects)</sub>
- L56: `Method App\Services\Notification\NotificationPreferenceService::getPreferences() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L160: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/ScheduledPaymentService.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=2, unused=1, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Method App\Services\ScheduledPaymentService::toObject() is unused.` <sub>(unused)</sub>
- L30: `Property App\Services\ScheduledPaymentService::$escrowService is never read, only written.` <sub>(never-read-property)</sub>
- L78: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L90: `Parameter #5 $explicitKey of method App\Services\Shared\IdempotencyService::executeWithTransaction() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Search/SchemaInspector.php`  (4 خطا)
<sub>دستهها: return-type-mismatch=1, return-type-mismatch(array)=1, always-evaluate=1, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Method App\Services\Search\SchemaInspector::tableExists() should return bool but returns mixed.` <sub>(return-type-mismatch)</sub>
- L71: `Method App\Services\Search\SchemaInspector::getColumns() should return array<int, string> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L79: `Call to function is_array() with object|null will always evaluate to false.` <sub>(always-evaluate)</sub>
- L111: `Constant App\Services\Search\SchemaInspector::STATIC_FULLTEXT_INDEXES is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Seo/AdsSeoService.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=3, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Services\Seo\AdsSeoService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L98: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L99: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L100: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Shared/DisputeService.php`  (4 خطا)
<sub>دستهها: cast-mixed(string)=4</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L236: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L237: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L245: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L266: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/User/AccountDeletionService.php`  (4 خطا)
<sub>دستهها: never-read-property=3, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Property App\Services\User\AccountDeletionService::$walletModel is never read, only written.` <sub>(never-read-property)</sub>
- L44: `Property App\Services\User\AccountDeletionService::$emailService is never read, only written.` <sub>(never-read-property)</sub>
- L46: `Property App\Services\User\AccountDeletionService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L293: `Method App\Services\User\AccountDeletionService::getDeletionHistory() should return array<int, stdClass> but returns array<int, object>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Validators/Requests/CreatePredictionGameRequest.php`  (4 خطا)
<sub>دستهها: cast-mixed(string)=2, cast-mixed(float)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L51: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L52: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L64: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L65: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `core/IdempotencyKey.php`  (4 خطا)
<sub>دستهها: type-mismatch/expects=1, cast-mixed(string)=1, no-return-type=1, always-condition=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L213: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L450: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L697: `Method Core\IdempotencyKey::wrap() has no return type specified.` <sub>(no-return-type)</sub>
- L756: `Variable $userId on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>

</details>

### `app/Commands/DlqWorkCommand.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L55: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L56: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L57: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Commands/FeatureFlagCommand.php`  (3 خطا)
<sub>دستهها: encapsed-string=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L66: `Part $stats['disabled'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L66: `Part $stats['enabled'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L66: `Part $stats['total'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Commands/OutboxPublishCommand.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L43: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L48: `Part $skipped (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Commands/QueueFailedCommand.php`  (3 خطا)
<sub>دستهها: OTHER=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L87: `Offset 'errors' does not exist on array<int, array<string, mixed>>.` <sub>(OTHER)</sub>
- L87: `Offset 'requeued' does not exist on array<int, array<string, mixed>>.` <sub>(OTHER)</sub>
- L87: `Offset 'skipped' does not exist on array<int, array<string, mixed>>.` <sub>(OTHER)</sub>

</details>

### `app/Controllers/Admin/ContentController.php`  (3 خطا)
<sub>دستهها: no-return-type=1, unreachable=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L249: `Method App\Controllers\Admin\ContentController::export() has no return type specified.` <sub>(no-return-type)</sub>
- L264: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>
- L286: `Parameter #1 $filename of function readfile expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/Api/InfluencerController.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L163: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L169: `Parameter #1 $message of method App\Controllers\Api\BaseApiController::error() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L171: `Parameter #2 $message of method App\Controllers\Api\BaseApiController::success() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/FaviconController.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Parameter #1 $string of function ltrim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L37: `Parameter #1 $string of function mb_substr expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L45: `Part $color (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Controllers/User/AdsController.php`  (3 خطا)
<sub>دستهها: no-return-type=2, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L61: `Method App\Controllers\User\AdsController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L72: `Method App\Controllers\User\AdsController::store() has no return type specified.` <sub>(no-return-type)</sub>
- L154: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Controllers/User/BaseUserController.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L75: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L121: `If condition is always true.` <sub>(always-true)</sub>
- L160: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/CustomTaskController.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Controllers\User\CustomTaskController::$analyticsService is never read, only written.` <sub>(never-read-property)</sub>
- L183: `Parameter #2 $message of method App\Controllers\User\CustomTaskController::finishDisputeResponse() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L184: `Parameter #3 $disputeId of method App\Controllers\User\CustomTaskController::finishDisputeResponse() expects int|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/User/NotificationController.php`  (3 خطا)
<sub>دستهها: nullsafe-on-non-nullable=1, no-return-type=1, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L358: `Using nullsafe method call on non-nullable type App\Contracts\LoggerInterface. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>
- L387: `Method App\Controllers\User\NotificationController::delete() has no return type specified.` <sub>(no-return-type)</sub>
- L444: `Method App\Controllers\User\NotificationController::getNewNotifications() is unused.` <sub>(unused)</sub>

</details>

### `app/Jobs/Influencer/CompleteInfluencerOrderJob.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L32: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L33: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L34: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/Influencer/CreateInfluencerOrderJob.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L33: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L34: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L48: `Parameter #3 $data of method App\Services\InfluencerService::createOrder() expects array<string, mixed>, array<mixed, mixed> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Influencer/DisputeInfluencerOrderJob.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L21: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L22: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/Influencer/SubmitInfluencerProofJob.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L21: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L29: `Parameter #3 $proofData of method App\Services\InfluencerService::submitProof() expects array<string, mixed>, array<mixed, mixed> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Notification/SendFromTemplateNotificationJob.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Parameter #1 $string of function strtolower expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L50: `Parameter #3 $title of method App\Jobs\Notification\SendNotificationJob::handle() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L51: `Parameter #4 $message of method App\Jobs\Notification\SendNotificationJob::handle() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Payment/CreateCryptoDepositIntentJob.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=1, cast-mixed(string)=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L73: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L128: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L227: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Jobs/Payment/ReconcilePaymentsJob.php`  (3 خطا)
<sub>دستهها: never-read-property=1, cast-mixed(int)=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L12: `Property App\Jobs\Payment\ReconcilePaymentsJob::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L47: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L68: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/Vitrine/ReportVitrineListingJob.php`  (3 خطا)
<sub>دستهها: always-true=1, cannot-access=1, always-false=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L79: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L80: `Cannot access property $id on mixed.` <sub>(cannot-access)</sub>
- L93: `Negated boolean expression is always false.` <sub>(always-false)</sub>

</details>

### `app/Jobs/Withdrawal/RequestWithdrawalUserJob.php`  (3 خطا)
<sub>دستهها: never-read-property=1, type-mismatch/expects=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L14: `Property App\Jobs\Withdrawal\RequestWithdrawalUserJob::$events is never read, only written.` <sub>(never-read-property)</sub>
- L36: `Parameter #2 $aggregateId of method App\Contracts\OutboxServiceInterface::record() expects int|string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L39: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/WithdrawalTimeoutJob.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Jobs\WithdrawalTimeoutJob::$cache is never read, only written.` <sub>(never-read-property)</sub>
- L52: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L53: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Middleware/CaptchaMiddleware.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L44: `Parameter #1 $url of function is_safe_redirect expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L46: `Parameter #1 $url of method Core\Response::redirect() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L63: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Middleware/TaskFraudGuardMiddleware.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L43: `Parameter #1 $userId of method App\Services\AntiFraud\FraudGuardService::checkAction() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L43: `Parameter #2 $action of method App\Services\AntiFraud\FraudGuardService::checkAction() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L43: `Parameter #3 $context of method App\Services\AntiFraud\FraudGuardService::checkAction() expects array<string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Middleware/TracingMiddleware.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Property App\Middleware\TracingMiddleware::$logService is never written, only read.` <sub>(OTHER)</sub>
- L47: `Parameter #1 $id of method App\Services\LogService::setCorrelationId() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L73: `Parameter #2 $value of method Core\Response::header() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Models/InteractionModel.php`  (3 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1, cannot-access=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L126: `Method App\Models\InteractionModel::findTaskReport() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L329: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>
- L343: `Method App\Models\InteractionModel::findMessageReportById() should return array<int, stdClass>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Models/LedgerEntry.php`  (3 خطا)
<sub>دستهها: cast-mixed(string)=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L14: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L21: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L22: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Models/ManualDeposit.php`  (3 خطا)
<sub>دستهها: cannot-access=2, return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L156: `Method App\Models\ManualDeposit::findForUpdate() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L197: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>
- L252: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Models/NotificationPreference.php`  (3 خطا)
<sub>دستهها: return-type-mismatch(array)=2, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L61: `Method App\Models\NotificationPreference::getOrCreate() should return object but returns mixed.` <sub>(return-type-mismatch)</sub>
- L109: `Method App\Models\NotificationPreference::getNotificationTypes() should return array<string, string> but returns array<int, string>.` <sub>(return-type-mismatch(array))</sub>
- L115: `Method App\Models\NotificationPreference::getChannels() should return array<string, string> but returns array<int, string>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Models/Permission.php`  (3 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Method App\Models\Permission::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L37: `Method App\Models\Permission::findBySlug() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L112: `Property App\Models\Permission::$userPermissionsCache (array<string, bool>) does not accept array<int|string, array<int, string>|bool>.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Models/SecurityLog.php`  (3 خطا)
<sub>دستهها: return-type-mismatch(array)=2, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L88: `Part $filters['search'] (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>
- L121: `Method App\Models\SecurityLog::getPaginated() should return array<int, stdClass> but returns array<string, array|int>.` <sub>(return-type-mismatch(array))</sub>
- L138: `Method App\Models\SecurityLog::findById() should return array<string, mixed>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Models/SecurityModel.php`  (3 خطا)
<sub>دستهها: always-true=3</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L108: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>
- L228: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>
- L237: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Models/User.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L263: `Parameter #2 $term of method App\Models\User::applySearch() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L268: `Method App\Models\User::searchWithFilters() should return array{items: array<int, stdClass>, total: int} but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L280: `Parameter #2 $term of method App\Models\User::applySearch() expects string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Providers/AppServiceProvider.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L34: `Cannot access offset 'database' on mixed.` <sub>(cannot-access)</sub>
- L34: `Parameter #1 $dbConfig of static method Core\Database::getInstance() expects array{host: string, port: int|string, name: string, charset: string, user: string, pass: string, read?: array<string, mixed>}|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L261: `Parameter #2 $logger of class App\Services\Sentry\Alerting\AlertDispatcher constructor expects Core\Logger, App\Contracts\LoggerInterface given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/AdminDashboard/SystemMonitoringService.php`  (3 خطا)
<sub>دستهها: cannot-access=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L45: `Method App\Services\AdminDashboard\SystemMonitoringService::getSystemStatus() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>
- L221: `Cannot access offset 'percentage' on mixed.` <sub>(cannot-access)</sub>
- L232: `Cannot access offset 'percentage' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/AntiFraud/BrowserFingerprintService.php`  (3 خطا)
<sub>دستهها: cannot-access=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L122: `Cannot access property $metadata on mixed.` <sub>(cannot-access)</sub>
- L123: `Cannot access property $metadata on mixed.` <sub>(cannot-access)</sub>
- L204: `Parameter #2 $score of method App\Models\IpAndDeviceModel::logSuspicion() expects int, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/AntiFraud/MLFraudDetectionService.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L135: `Parameter #1 $value of function floatval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>
- L363: `Parameter #1 $num of function round expects float|int, mixed given.` <sub>(type-mismatch/expects)</sub>
- L369: `Method App\Services\AntiFraud\MLFraudDetectionService::identifySuspiciousFactors() should return array<string, mixed> but returns array<int<0, max>, array<string, float|string>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/AuditTrail.php`  (3 خطا)
<sub>دستهها: unused=1, cannot-access=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Method App\Services\AuditTrail::toObject() is unused.` <sub>(unused)</sub>
- L291: `Cannot access offset 'id' on stdClass.` <sub>(cannot-access)</sub>
- L419: `Method App\Services\AuditTrail::getAll() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Auth/SessionService.php`  (3 خطا)
<sub>دستهها: never-read-property=1, cast-mixed(int)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Property App\Services\Auth\SessionService::$notificationService is never read, only written.` <sub>(never-read-property)</sub>
- L145: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L369: `Parameter #4 $anomalies of method App\Services\Auth\SessionService::logAnalysisResult() expects array<string, mixed>, array<int, string> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Auth/TwoFactorService.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L122: `Parameter #1 $string of function rawurlencode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L123: `Parameter #1 $string of function rawurlencode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L137: `Left side of && is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/CustomTask/CustomTaskExecutorService.php`  (3 خطا)
<sub>دستهها: never-read-property=2, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Property App\Services\CustomTask\CustomTaskExecutorService::$notificationService is never read, only written.` <sub>(never-read-property)</sub>
- L33: `Property App\Services\CustomTask\CustomTaskExecutorService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L116: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/DatabaseService.php`  (3 خطا)
<sub>دستهها: cast-mixed(string)=2, unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Method App\Services\DatabaseService::toObject() is unused.` <sub>(unused)</sub>
- L169: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L257: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/MigrationService.php`  (3 خطا)
<sub>دستهها: cannot-call-on-nullable=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L60: `Cannot call method set() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L259: `Cannot call method del() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L294: `Method App\Services\MigrationService::getExecutedMigrations() should return array<int, array<string, mixed>> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Search/BaseSearchProvider.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Parameter #1 $string of function trim expects string, string|null given.` <sub>(type-mismatch/expects)</sub>
- L82: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L85: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/Search/ModuleSearchProvider.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L37: `Parameter #1 $modules of method App\Services\Search\ModuleSearchProvider::searchModules() expects array<int, string>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L47: `Parameter #1 $items of class App\Services\Search\SearchResult constructor expects array<int, stdClass>, array<string, array<int, stdClass>> given.` <sub>(type-mismatch/expects)</sub>
- L100: `Method App\Services\Search\ModuleSearchProvider::searchModules() should return array<string, array<int, stdClass>> but returns array<string, mixed>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Search/SearchOrchestrator.php`  (3 خطا)
<sub>دستهها: cast-mixed(string)=1, cast-mixed(int)=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L61: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L62: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L102: `Method App\Services\Search\SearchOrchestrator::searchAdminModule() should return array<string, mixed> but returns array<int|string, array|int|stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Search/UserSearchGateway.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=2, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L79: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L149: `Parameter #2 $params of method Core\Database::fetchColumn() expects array<int|string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>
- L150: `Parameter #2 $params of method Core\Database::fetchAll() expects array<int|string, mixed>, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/User/UserLevelQueryService.php`  (3 خطا)
<sub>دستهها: never-read-property=1, return-type-mismatch(array)=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Property App\Services\User\UserLevelQueryService::$appSettings is never read, only written.` <sub>(never-read-property)</sub>
- L28: `Method App\Services\User\UserLevelQueryService::getUserLevels() should return array<int, stdClass> but returns array<object>.` <sub>(return-type-mismatch(array))</sub>
- L73: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Validators/ChangePasswordRequest.php`  (3 خطا)
<sub>دستهها: cast-mixed(string)=1, type-mismatch/expects=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L32: `Parameter #1 ...$arrays of function array_merge expects array, mixed given.` <sub>(type-mismatch/expects)</sub>
- L37: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Validators/Requests/CreateBugReportRequest.php`  (3 خطا)
<sub>دستهها: cast-mixed(string)=2, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L35: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>
- L40: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `core/Model.php`  (3 خطا)
<sub>دستهها: return-type-mismatch=1, always-true=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L133: `Method Core\Model::create() should return int|false but returns bool|int.` <sub>(return-type-mismatch)</sub>
- L684: `Comparison operation "<=" between 1|2 and 2 is always true.` <sub>(always-true)</sub>
- L738: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `core/Pipeline.php`  (3 خطا)
<sub>دستهها: type-mismatch/expects=1, generic-template-unresolved=1, cannot-call-on-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L85: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, string given.` <sub>(type-mismatch/expects)</sub>
- L85: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>
- L101: `Cannot call method handle() on class-string|object.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `core/Response.php`  (3 خطا)
<sub>دستهها: cast-mixed(string)=2, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L120: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L216: `Parameter #1 $url of function parse_url expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L407: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `core/Router.php`  (3 خطا)
<sub>دستهها: never-read-property=1, always-true=1, generic-template-unresolved=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L34: `Property Core\Router::$response is never read, only written.` <sub>(never-read-property)</sub>
- L126: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L295: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>

</details>

### `core/Strategies/FixedWindowStrategy.php`  (3 خطا)
<sub>دستهها: cast-mixed(int)=2, cannot-call-on-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L51: `Cannot call method eval() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>
- L51: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L69: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Commands/QueueWorkCommand.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L59: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L60: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/Admin/BaseAdminController.php`  (2 خطا)
<sub>دستهها: cast-mixed(string)=1, nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L38: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L38: `Using nullsafe method call on non-nullable type Core\Session. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Controllers/Admin/DatabaseHealthController.php`  (2 خطا)
<sub>دستهها: cannot-access=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L65: `Cannot access property $TABLE_NAME on array<string, mixed>.` <sub>(cannot-access)</sub>
- L65: `Cannot access property $table_name on array<string, mixed>.` <sub>(cannot-access)</sub>

</details>

### `app/Controllers/Api/BaseApiController.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L98: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L99: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/BankCardController.php`  (2 خطا)
<sub>دستهها: no-return-type=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L53: `Method App\Controllers\User\BankCardController::create() has no return type specified.` <sub>(no-return-type)</sub>
- L75: `Method App\Controllers\User\BankCardController::store() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/User/SessionController.php`  (2 خطا)
<sub>دستهها: never-read-property=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Controllers\User\SessionController::$encryption is never read, only written.` <sub>(never-read-property)</sub>
- L21: `Property App\Controllers\User\SessionController::$db is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Domain/Gamification/Strategies/DailySynergyStrategy.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L20: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Domain/Gamification/Strategies/InactivityDecayStrategy.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L20: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Domain/Gamification/Strategies/TrustEvaluationStrategy.php`  (2 خطا)
<sub>دستهها: cast-mixed(string)=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L26: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Exceptions/OAuthException.php`  (2 خطا)
<sub>دستهها: no-type-specified=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Exceptions\OAuthException::$code has no type specified.` <sub>(no-type-specified)</sub>
- L21: `Property App\Exceptions\OAuthException::$message has no type specified.` <sub>(no-type-specified)</sub>

</details>

### `app/Exceptions/PaymentGatewayConnectionException.php`  (2 خطا)
<sub>دستهها: no-type-specified=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Property App\Exceptions\PaymentGatewayConnectionException::$code has no type specified.` <sub>(no-type-specified)</sub>
- L18: `Property App\Exceptions\PaymentGatewayConnectionException::$message has no type specified.` <sub>(no-type-specified)</sub>

</details>

### `app/Exceptions/PaymentGatewayException.php`  (2 خطا)
<sub>دستهها: no-type-specified=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Property App\Exceptions\PaymentGatewayException::$code has no type specified.` <sub>(no-type-specified)</sub>
- L18: `Property App\Exceptions\PaymentGatewayException::$message has no type specified.` <sub>(no-type-specified)</sub>

</details>

### `app/Exceptions/PaymentVerificationException.php`  (2 خطا)
<sub>دستهها: no-type-specified=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Property App\Exceptions\PaymentVerificationException::$code has no type specified.` <sub>(no-type-specified)</sub>
- L19: `Property App\Exceptions\PaymentVerificationException::$message has no type specified.` <sub>(no-type-specified)</sub>

</details>

### `app/Exceptions/SessionException.php`  (2 خطا)
<sub>دستهها: no-type-specified=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Exceptions\SessionException::$code has no type specified.` <sub>(no-type-specified)</sub>
- L21: `Property App\Exceptions\SessionException::$message has no type specified.` <sub>(no-type-specified)</sub>

</details>

### `app/Jobs/BackfillSearchProjectionJob.php`  (2 خطا)
<sub>دستهها: cast-mixed(string)=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L53: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L54: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/CustomTask/CronSubmissionsJob.php`  (2 خطا)
<sub>دستهها: never-read-property=1, cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Property App\Jobs\CustomTask\CronSubmissionsJob::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L49: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/CustomTask/PayRewardJob.php`  (2 خطا)
<sub>دستهها: never-read-property=1, nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Jobs\CustomTask\PayRewardJob::$referralService is never read, only written.` <sub>(never-read-property)</sub>
- L59: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Jobs/Influencer/ConfirmInfluencerOrderJob.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L21: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/Investment/CreateTradeJob.php`  (2 خطا)
<sub>دستهها: cast-mixed(float)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L37: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Referral/DistributeMonthlyReferralRewardsJob.php`  (2 خطا)
<sub>دستهها: cast-mixed(float)=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L30: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/Seo/CompleteSeoTaskJob.php`  (2 خطا)
<sub>دستهها: never-read-property=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L14: `Property App\Jobs\Seo\CompleteSeoTaskJob::$adsService is never read, only written.` <sub>(never-read-property)</sub>
- L15: `Property App\Jobs\Seo\CompleteSeoTaskJob::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Jobs/Seo/StartSeoTaskJob.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L63: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L71: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/Vitrine/ProcessExpiredVitrineEscrowsJob.php`  (2 خطا)
<sub>دستهها: never-read-property=1, always-false=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L23: `Property App\Jobs\Vitrine\ProcessExpiredVitrineEscrowsJob::$escrowService is never read, only written.` <sub>(never-read-property)</sub>
- L61: `Negated boolean expression is always false.` <sub>(always-false)</sub>

</details>

### `app/Jobs/Vitrine/SendVitrineRequestJob.php`  (2 خطا)
<sub>دستهها: cast-mixed(float)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L62: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L63: `Parameter #1 $string of function trim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Listeners/CacheInvalidateListener.php`  (2 خطا)
<sub>دستهها: OTHER=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L23: `Method App\Listeners\CacheInvalidateListener::handle() has parameter $event with no type specified.` <sub>(OTHER)</sub>
- L29: `Cannot access offset 'key' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Listeners/EscrowListener.php`  (2 خطا)
<sub>دستهها: never-read-property=1, nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Property App\Listeners\EscrowListener::$idempotencyService is never read, only written.` <sub>(never-read-property)</sub>
- L52: `Using nullsafe method call on non-nullable type Core\Request. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Listeners/LogFeatureFlagChange.php`  (2 خطا)
<sub>دستهها: cannot-access=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L80: `Cannot access offset 'old' on mixed.` <sub>(cannot-access)</sub>
- L81: `Cannot access offset 'new' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Listeners/ScoreProjectionListener.php`  (2 خطا)
<sub>دستهها: never-read-property=1, OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Listeners\ScoreProjectionListener::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>
- L26: `Property App\Listeners\ScoreProjectionListener::$logger is never written, only read.` <sub>(OTHER)</sub>

</details>

### `app/Middleware/ApiRequestMiddleware.php`  (2 خطا)
<sub>دستهها: type-mismatch/expects=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L54: `Parameter #1 $contentType of method App\Middleware\ApiRequestMiddleware::isValidContentType() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L63: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Middleware/HttpsMiddleware.php`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L68: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Middleware/PermissionMiddleware.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L79: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L98: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Middleware/SafeModeMiddleware.php`  (2 خطا)
<sub>دستهها: type-mismatch/expects=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Parameter #1 $str of function strtok expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L51: `Parameter #1 $url of method Core\Response::redirect() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Models/BankCard.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L160: `Method App\Models\BankCard::getDefaultCard() should return stdClass|null but returns object|null.` <sub>(return-type-mismatch(stdClass))</sub>
- L332: `Method App\Models\BankCard::findByIdAndUser() should return stdClass|null but returns object|null.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/FeatureFlag.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(array)=1, return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L176: `Method App\Models\FeatureFlag::getAll() should return array<int, App\Models\FeatureFlag> but returns array<int, object>.` <sub>(return-type-mismatch(array))</sub>
- L182: `Method App\Models\FeatureFlag::findByName() should return App\Models\FeatureFlag|null but returns object|null.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Models/Page.php`  (2 خطا)
<sub>دستهها: always-true=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L141: `If condition is always true.` <sub>(always-true)</sub>
- L154: `If condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Models/PaymentGateway.php`  (2 خطا)
<sub>دستهها: cannot-access=1, return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L27: `Cannot access property $config on mixed.` <sub>(cannot-access)</sub>
- L36: `Method App\Models\PaymentGateway::getActiveGateway() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/Setting.php`  (2 خطا)
<sub>دستهها: type-mismatch/expects=1, unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L81: `Parameter #2 $value of method App\Models\Setting::set() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>
- L131: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Models/SettingsAuditTrail.php`  (2 خطا)
<sub>دستهها: always-true=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L47: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L60: `Ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Models/SocialTaskModel.php`  (2 خطا)
<sub>دستهها: cast-mixed(string)=1, always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L81: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L156: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Models/SystemLog.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L119: `Method App\Models\SystemLog::getPaginated() should return array<int, array<string, mixed>> but returns array<string, array|int>.` <sub>(return-type-mismatch(array))</sub>
- L136: `Method App\Models\SystemLog::findById() should return array<string, mixed>|null but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Models/TransactionQuery.php`  (2 خطا)
<sub>دستهها: always-true=1, return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L34: `Ternary operator condition is always true.` <sub>(always-true)</sub>
- L43: `Method App\Models\TransactionQuery::findByTransactionId() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/UserLevel.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Method App\Models\UserLevel::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>
- L182: `Method App\Models\UserLevel::getUserCountPerLevel() should return array<int, stdClass> but returns array<int>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/SDK/FeatureFlagSDK.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L301: `Method App\SDK\FeatureFlagSDK::stats() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L310: `Method App\SDK\FeatureFlagSDK::history() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/AdNotificationDispatcher.php`  (2 خطا)
<sub>دستهها: unused=1, never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Method App\Services\AdNotificationDispatcher::toObject() is unused.` <sub>(unused)</sub>
- L33: `Property App\Services\AdNotificationDispatcher::$performanceService is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Services/AdminDashboard/AdminDashboardService.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Method App\Services\AdminDashboard\AdminDashboardService::getAdminAccessLog() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L41: `Method App\Services\AdminDashboard\AdminDashboardService::getRecentActivity() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/AntiFraud/FraudStrategyResolver.php`  (2 خطا)
<sub>دستهها: type-mismatch/expects=1, generic-template-unresolved=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L62: `Parameter #1 $abstract of method Core\Container::make() expects class-string<object>, string given.` <sub>(type-mismatch/expects)</sub>
- L62: `Unable to resolve the template type T in call to method Core\Container::make()` <sub>(generic-template-unresolved)</sub>

</details>

### `app/Services/AntiFraud/Strategies/TaskFraudStrategy.php`  (2 خطا)
<sub>دستهها: unused=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Method App\Services\AntiFraud\Strategies\TaskFraudStrategy::toObject() is unused.` <sub>(unused)</sub>
- L55: `Method App\Services\AntiFraud\Strategies\TaskFraudStrategy::skipHeavyChecks() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Auth/PasswordRecoveryService.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L123: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L133: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/Cache/CacheManager.php`  (2 خطا)
<sub>دستهها: never-read-property=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Property App\Services\Cache\CacheManager::$logger is never read, only written.` <sub>(never-read-property)</sub>
- L114: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/CurrencyService.php`  (2 خطا)
<sub>دستهها: unused=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Method App\Services\CurrencyService::toObject() is unused.` <sub>(unused)</sub>
- L43: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/InfluencerService.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L167: `Method App\Services\InfluencerService::searchInfluencers() should return array<int, stdClass> but returns array<string, array<int, stdClass>|int>.` <sub>(return-type-mismatch(array))</sub>
- L172: `Method App\Services\InfluencerService::searchInfluencersAdmin() should return array<int, stdClass> but returns array<string, array<int, stdClass>|int>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Lottery/LotteryParticipationService.php`  (2 خطا)
<sub>دستهها: never-read-property=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L9: `Property App\Services\Lottery\LotteryParticipationService::$db is never read, only written.` <sub>(never-read-property)</sub>
- L10: `Property App\Services\Lottery\LotteryParticipationService::$logger is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Services/Lottery/LotteryQueryService.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L66: `Method App\Services\Lottery\LotteryQueryService::getParticipationCounts() should return array<int, int> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>
- L76: `Method App\Services\Lottery\LotteryQueryService::getRoundStatistics() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Metrics/MetricsCollector.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L27: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L55: `Parameter #1 $json of function json_decode expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Notification/NotificationDispatcher.php`  (2 خطا)
<sub>دستهها: never-read-property=1, encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L32: `Property App\Services\Notification\NotificationDispatcher::$queue is never read, only written.` <sub>(never-read-property)</sub>
- L185: `Part $msgId (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `app/Services/Notification/NotificationPolicyService.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L44: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L45: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/Payment/PaymentDepositService.php`  (2 خطا)
<sub>دستهها: cannot-access=1, return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L128: `Cannot access offset 'tx_id' on mixed.` <sub>(cannot-access)</sub>
- L138: `Method App\Services\Payment\PaymentDepositService::fulfillCryptoDeposit() should return array<string, mixed> but returns mixed.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Search/SearchProjectionRepository.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L139: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L228: `Parameter #1 $items of class App\Services\Search\SearchResult constructor expects array<int, stdClass>, array<int, array<string, mixed>> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Shared/PolicyService.php`  (2 خطا)
<sub>دستهها: return-type-mismatch=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L89: `Method App\Services\Shared\PolicyService::hasPermission() should return bool but returns mixed.` <sub>(return-type-mismatch)</sub>
- L131: `Method App\Services\Shared\PolicyService::authorizeById() should return bool but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Services/SocialTask/SocialTaskService.php`  (2 خطا)
<sub>دستهها: return-type-mismatch(array)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L641: `Method App\Services\SocialTask\SocialTaskService::getUserAccounts() should return array<int, stdClass> but returns array<int, App\Services\SocialAccountService>.` <sub>(return-type-mismatch(array))</sub>
- L1146: `Method App\Services\SocialTask\SocialTaskService::updateUserAccount() should return array{success: bool, message: string} but returns array<string, mixed>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/VitrineSettingsService.php`  (2 خطا)
<sub>دستهها: unused=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L23: `Method App\Services\VitrineSettingsService::toObject() is unused.` <sub>(unused)</sub>
- L75: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/WebSocketService.php`  (2 خطا)
<sub>دستهها: unused=1, always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L31: `Method App\Services\WebSocketService::toObject() is unused.` <sub>(unused)</sub>
- L315: `Left side of && is always true.` <sub>(always-true)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\AdapterBase)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Adapters\AdapterBase::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\CryptoApiAdapter)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Adapters\CryptoApiAdapter::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\CryptoExplorerAdapter)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Adapters\CryptoExplorerAdapter::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\DeepFaceKycAdapter)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Adapters\DeepFaceKycAdapter::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\JibitInquiryAdapter)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Adapters\JibitInquiryAdapter::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\Notification\FcmNotificationAdapter)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Adapters\Notification\FcmNotificationAdapter::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\Notification\LogNotificationAdapter)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Adapters\Notification\LogNotificationAdapter::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Adapters\Notification\SmsNotificationAdapter)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Adapters\Notification\SmsNotificationAdapter::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Jobs\Auth\HandleFacebookCallbackJob)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Jobs\Auth\HandleFacebookCallbackJob::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Jobs\Auth\HandleGoogleCallbackJob)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Jobs\Auth\HandleGoogleCallbackJob::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/ExternalCallTrait.php (in context of class App\Jobs\Auth\LinkSocialAccountSafeJob)`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L168: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L195: `Method App\Jobs\Auth\LinkSocialAccountSafeJob::getStreamContextWithTimeout() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\Ads)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\CryptoDeposit)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\InfluencerModel)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\Investment)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\ManualDeposit)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\SocialTaskModel)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\Ticket)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\Transaction)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\VitrineListing)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Traits/Filterable.php (in context of class App\Models\Withdrawal)`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L83: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L89: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Validators/Requests/CreateManualDepositRequest.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L48: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L50: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Validators/Requests/CreateTransferRequest.php`  (2 خطا)
<sub>دستهها: cast-mixed(float)=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L25: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>
- L27: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Validators/Requests/ExecuteSocialTaskRequest.php`  (2 خطا)
<sub>دستهها: cast-mixed(string)=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L78: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L79: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Validators/Requests/Verify2FARequest.php`  (2 خطا)
<sub>دستهها: cast-mixed(string)=1, cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>
- L26: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `core/Application.php`  (2 خطا)
<sub>دستهها: cast-mixed(int)=1, cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L105: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>
- L135: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `core/Minifier.php`  (2 خطا)
<sub>دستهها: never-read-property=1, cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L12: `Property Core\Minifier::$publicPath is never read, only written.` <sub>(never-read-property)</sub>
- L16: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `core/PathResolver.php`  (2 خطا)
<sub>دستهها: never-read-property=1, type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L9: `Property Core\PathResolver::$basePath is never read, only written.` <sub>(never-read-property)</sub>
- L19: `Parameter #1 $string of function rtrim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `core/Validator.php`  (2 خطا)
<sub>دستهها: cannot-access=2</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L370: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>
- L394: `Cannot access property $count on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Controllers/Admin/CronController.php`  (1 خطا)
<sub>دستهها: cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/Admin/FraudDashboardController.php`  (1 خطا)
<sub>دستهها: no-return-type=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Method App\Controllers\Admin\FraudDashboardController::index() has no return type specified.` <sub>(no-return-type)</sub>

</details>

### `app/Controllers/Admin/OnlinePaymentController.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L53: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/DebugController.php`  (1 خطا)
<sub>دستهها: cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Controllers/RobotsController.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L15: `Parameter #1 $string of function rtrim expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Controllers/TestCaptchaController.php`  (1 خطا)
<sub>دستهها: never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L10: `Property App\Controllers\TestCaptchaController::$captchaService is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Controllers/User/TaskFeedController.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L40: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Controllers/User/WalletController.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L54: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/Auth/Verify2FAJob.php`  (1 خطا)
<sub>دستهها: never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Property App\Jobs\Auth\Verify2FAJob::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Jobs/Investment/CreateInvestmentJob.php`  (1 خطا)
<sub>دستهها: cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/Investment/RequestWithdrawalJob.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Parameter #1 $message of class Core\Exceptions\InvalidStateException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/Notification/GetUserNotificationsNotificationJob.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Method App\Jobs\Notification\GetUserNotificationsNotificationJob::handle() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Jobs/Notification/LatestNotificationJob.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L17: `Method App\Jobs\Notification\LatestNotificationJob::handle() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Jobs/Notification/SendToAllNotificationJob.php`  (1 خطا)
<sub>دستهها: never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Jobs\Notification\SendToAllNotificationJob::$model is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Jobs/Notification/SendToSegmentNotificationJob.php`  (1 خطا)
<sub>دستهها: never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Property App\Jobs\Notification\SendToSegmentNotificationJob::$model is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Jobs/NotificationCleanupJob.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L32: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Jobs/RunCronTaskJob.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L47: `Parameter #1 $name of method Core\Scheduler::executeJobByName() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/ScoreRecalculationJob.php`  (1 خطا)
<sub>دستهها: cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L42: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Jobs/SocialTask/ApproveSocialTaskExecutionJob.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L71: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/SocialTaskApprovalReminderJob.php`  (1 خطا)
<sub>دستهها: OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L31: `Property App\Jobs\SocialTaskApprovalReminderJob::$container is never written, only read.` <sub>(OTHER)</sub>

</details>

### `app/Jobs/Vitrine/AdminRefundVitrineListingJob.php`  (1 خطا)
<sub>دستهها: never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L27: `Property App\Jobs\Vitrine\AdminRefundVitrineListingJob::$escrowService is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Jobs/Vitrine/RateVitrineListingJob.php`  (1 خطا)
<sub>دستهها: always-false=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L80: `Negated boolean expression is always false.` <sub>(always-false)</sub>

</details>

### `app/Jobs/Vitrine/ResolveVitrineDisputeJob.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L76: `Parameter #1 $message of class RuntimeException constructor expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Jobs/VitrineListingExpiryJob.php`  (1 خطا)
<sub>دستهها: nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L62: `Using nullsafe method call on non-nullable type App\Services\OutboxService. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Listeners/FraudGuardListener.php`  (1 خطا)
<sub>دستهها: OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Method App\Listeners\FraudGuardListener::handle() has parameter $event with no type specified.` <sub>(OTHER)</sub>

</details>

### `app/Listeners/InvalidateSearchCacheListener.php`  (1 خطا)
<sub>دستهها: OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Method App\Listeners\InvalidateSearchCacheListener::handle() has parameter $event with no type specified.` <sub>(OTHER)</sub>

</details>

### `app/Listeners/PersistAuditRecordListener.php`  (1 خطا)
<sub>دستهها: nullsafe-on-non-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L26: `Using nullsafe method call on non-nullable type Core\Request. Use -> instead.` <sub>(nullsafe-on-non-nullable)</sub>

</details>

### `app/Middleware/BaseMiddleware.php`  (1 خطا)
<sub>دستهها: cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Middleware/GuestMiddleware.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L28: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Middleware/LoggingMiddleware.php`  (1 خطا)
<sub>دستهها: cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L71: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Models/ApiToken.php`  (1 خطا)
<sub>دستهها: OTHER=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L356: `PHPDoc tag @return with type object{row: object, hashed: string, version: string}|null is not subtype of native type stdClass|null.` <sub>(OTHER)</sub>

</details>

### `app/Models/ContentAgreement.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L57: `Method App\Models\ContentAgreement::findBySubmission() should return stdClass|null but returns object|null.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/ContentRevenue.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L9: `Method App\Models\ContentRevenue::objectOrNull() should return stdClass|null but returns object|null.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/CryptoDeposit.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L12: `Method App\Models\CryptoDeposit::objectOrNull() should return stdClass|null but returns object|null.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/CryptoDepositIntent.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L11: `Method App\Models\CryptoDepositIntent::objectOrNull() should return stdClass|null but returns object|null.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/CustomTaskTransaction.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L24: `Method App\Models\CustomTaskTransaction::findByIdempotencyKey() should return stdClass|null but returns object|null.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/IpAndDeviceModel.php`  (1 خطا)
<sub>دستهها: always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L413: `Else branch is unreachable because ternary operator condition is always true.` <sub>(always-true)</sub>

</details>

### `app/Models/SystemTelemetryModel.php`  (1 خطا)
<sub>دستهها: always-condition=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L96: `Variable $recentErrors on left side of ?? always exists and is not nullable.` <sub>(always-condition)</sub>

</details>

### `app/Models/UserVacation.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L114: `Method App\Models\UserVacation::find() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/UserVerification.php`  (1 خطا)
<sub>دستهها: unreachable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L85: `Unreachable statement - code above always terminates.` <sub>(unreachable)</sub>

</details>

### `app/Models/VitrineRequest.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(stdClass)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Method App\Models\VitrineRequest::findById() should return stdClass|null but returns mixed.` <sub>(return-type-mismatch(stdClass))</sub>

</details>

### `app/Models/WithdrawalLimit.php`  (1 خطا)
<sub>دستهها: cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L44: `Cannot access property $withdrawal_count on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/AdSystemManager.php`  (1 خطا)
<sub>دستهها: cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L177: `Cannot access offset 'id' on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Services/Analytics/AnalyticsExporter.php`  (1 خطا)
<sub>دستهها: cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L194: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/AntiFraud/IPQualityService.php`  (1 خطا)
<sub>دستهها: cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L71: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `app/Services/AntiFraud/RiskDecisionService.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Parameter #1 $value of function strval expects bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/AntiFraud/SessionAnomalyService.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L164: `Parameter #1 $value of function intval expects array|bool|float|int|resource|string|null, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/AntiFraud/Strategies/IdentityFraudStrategy.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Method App\Services\AntiFraud\Strategies\IdentityFraudStrategy::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/AntiFraud/Strategies/TransactionFraudStrategy.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Method App\Services\AntiFraud\Strategies\TransactionFraudStrategy::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Cron/CronService.php`  (1 خطا)
<sub>دستهها: always-evaluate=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L67: `Call to function is_array() with object|null will always evaluate to false.` <sub>(always-evaluate)</sub>

</details>

### `app/Services/Dispute/DisputeQueryService.php`  (1 خطا)
<sub>دستهها: never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L30: `Property App\Services\Dispute\DisputeQueryService::$logger is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Services/ExportService.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L18: `Method App\Services\ExportService::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/FileAccessService.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Method App\Services\FileAccessService::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Gamification/XpService.php`  (1 خطا)
<sub>دستهها: cast-mixed(float)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L93: `Cannot cast mixed to float.` <sub>(cast-mixed(float))</sub>

</details>

### `app/Services/Influencer/InfluencerQueryService.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Parameter #1 $q of method App\Models\InfluencerModel::searchNative() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/Interaction/ReportService.php`  (1 خطا)
<sub>دستهها: never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L20: `Property App\Services\Interaction\ReportService::$eventDispatcher is never read, only written.` <sub>(never-read-property)</sub>

</details>

### `app/Services/KYCService.php`  (1 خطا)
<sub>دستهها: always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L140: `Left side of && is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/MaintenanceService.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L110: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/Notification/Channels/FcmChannel.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\Notification\Channels\FcmChannel::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Notification/Channels/LogChannel.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\Notification\Channels\LogChannel::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Notification/Channels/PushChannel.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\Notification\Channels\PushChannel::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Notification/Channels/SmsChannel.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\Notification\Channels\SmsChannel::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Notification/FcmService.php`  (1 خطا)
<sub>دستهها: return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L93: `Method App\Services\Notification\FcmService::getUserToken() should return string|null but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Services/Notification/NotificationTracker.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L85: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/OutboxService.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L23: `Method App\Services\OutboxService::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/PredictionService.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L13: `Method App\Services\PredictionService::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Score/ScoreQueryService.php`  (1 خطا)
<sub>دستهها: always-true=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L65: `Right side of && is always true.` <sub>(always-true)</sub>

</details>

### `app/Services/ScoreService.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L22: `Method App\Services\ScoreService::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Sentry/Alerting/EscalationManager.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L19: `Method App\Services\Sentry\Alerting\EscalationManager::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Sentry/Audit/AdvancedAuditTrail.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L21: `Method App\Services\Sentry\Audit\AdvancedAuditTrail::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/Settings/AppSettings.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L208: `Method App\Services\Settings\AppSettings::getByCategory() should return array<string, mixed> but returns array<int, stdClass>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Shared/BatchLoader.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Method App\Services\Shared\BatchLoader::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/SocialAccountService.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L408: `Method App\Services\SocialAccountService::getByUser() should return array<int, App\Services\SocialAccountService> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/SocialTask/CameraVerificationService.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L64: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/SocialTask/SocialTaskScoringService.php`  (1 خطا)
<sub>دستهها: cast-mixed(int)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L85: `Cannot cast mixed to int.` <sub>(cast-mixed(int))</sub>

</details>

### `app/Services/TicketQueryService.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\TicketQueryService::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/TicketService.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L87: `Parameter #5 $attachments of method App\Services\TicketCommandService::reply() expects array<int, array<string, mixed>>, array<string, mixed> given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Services/ValidatorFactory.php`  (1 خطا)
<sub>دستهها: unused=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L16: `Method App\Services\ValidatorFactory::toObject() is unused.` <sub>(unused)</sub>

</details>

### `app/Services/VitrineService.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L620: `Method App\Services\VitrineService::searchVitrine() should return array<string, mixed> but returns array<int, array<string, mixed>>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Services/Wallet/WalletService.php`  (1 خطا)
<sub>دستهها: return-type-mismatch(array)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L459: `Method App\Services\Wallet\WalletService::getWalletBalances() should return array<string, string|null> but returns array<string, mixed>.` <sub>(return-type-mismatch(array))</sub>

</details>

### `app/Traits/ClientInfoTrait.php (in context of class App\Controllers\User\TwoFactorController)`  (1 خطا)
<sub>دستهها: return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Method App\Controllers\User\TwoFactorController::currentUserId() should return int|null but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Traits/ClientInfoTrait.php (in context of class App\Jobs\Auth\HandleFacebookCallbackJob)`  (1 خطا)
<sub>دستهها: return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Method App\Jobs\Auth\HandleFacebookCallbackJob::currentUserId() should return int|null but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Traits/ClientInfoTrait.php (in context of class App\Jobs\Auth\HandleGoogleCallbackJob)`  (1 خطا)
<sub>دستهها: return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Method App\Jobs\Auth\HandleGoogleCallbackJob::currentUserId() should return int|null but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Traits/ClientInfoTrait.php (in context of class App\Jobs\Auth\LinkSocialAccountSafeJob)`  (1 خطا)
<sub>دستهها: return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Method App\Jobs\Auth\LinkSocialAccountSafeJob::currentUserId() should return int|null but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Traits/ClientInfoTrait.php (in context of class App\Services\AuditTrail)`  (1 خطا)
<sub>دستهها: return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Method App\Services\AuditTrail::currentUserId() should return int|null but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Traits/ClientInfoTrait.php (in context of class App\Services\Auth\OAuthService)`  (1 خطا)
<sub>دستهها: return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Method App\Services\Auth\OAuthService::currentUserId() should return int|null but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Traits/ClientInfoTrait.php (in context of class App\Services\Auth\TwoFactorService)`  (1 خطا)
<sub>دستهها: return-type-mismatch=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L52: `Method App\Services\Auth\TwoFactorService::currentUserId() should return int|null but returns mixed.` <sub>(return-type-mismatch)</sub>

</details>

### `app/Utils/Sentry/BreadcrumbCollector.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L108: `Parameter #1 $string of function substr expects string, string|null given.` <sub>(type-mismatch/expects)</sub>

</details>

### `app/Validators/Requests/SendNotificationRequest.php`  (1 خطا)
<sub>دستهها: cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L36: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `app/Validators/Requests/UserUpdateRequest.php`  (1 خطا)
<sub>دستهها: cannot-access=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L35: `Cannot access an offset on mixed.` <sub>(cannot-access)</sub>

</details>

### `core/Blueprint.php`  (1 خطا)
<sub>دستهها: encapsed-string=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L188: `Part $value (mixed) of encapsed string cannot be cast to string.` <sub>(encapsed-string)</sub>

</details>

### `core/GenericEvent.php`  (1 خطا)
<sub>دستهها: cast-mixed(string)=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L29: `Cannot cast mixed to string.` <sub>(cast-mixed(string))</sub>

</details>

### `core/Logger.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L149: `Parameter #1 $type of method App\Services\LogService::logSecurity() expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `core/Redis.php`  (1 خطا)
<sub>دستهها: cannot-call-on-nullable=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L157: `Cannot call method scan() on Redis|null.` <sub>(cannot-call-on-nullable)</sub>

</details>

### `core/Session.php`  (1 خطا)
<sub>دستهها: type-mismatch/expects=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L84: `Parameter #1 $url of function parse_url expects string, mixed given.` <sub>(type-mismatch/expects)</sub>

</details>

### `core/Sql/SafeExpression.php`  (1 خطا)
<sub>دستهها: never-read-property=1</sub>

<details><summary>مشاهدهی خطبهخط</summary>

- L128: `Property Core\Sql\SafeExpression::$bindings is never read, only written.` <sub>(never-read-property)</sub>

</details>
