<?php

declare(strict_types=1);

namespace App\Commands;

use App\Contracts\CommandInterface;
use Core\Container;
use App\Services\Health\HealthCheckService;

/**
 * Distributed Systems Health Check (refactored to reuse HealthCheckService).
 * 
 * Usage: php cli.php distributed:health
 * 
 * This command now reuses the centralized probes in HealthCheckService
 * instead of duplicating SQL logic. It still has a standalone PDO fallback
 * for robustness when full bootstrap fails.
 */
class DistributedHealthCommand implements CommandInterface
{
    #[\Core\Attributes\Inject]
    private Container $container;

    public function __construct($dependencies = []) {}

    public function run(array $args = []): void
    {
        echo "=== Chortke Distributed Systems Health Check ===\n\n";

        $healthService = null;
        try {
            $healthService = $this->container->make(HealthCheckService::class);
        } catch (\Throwable $e) {
            // Fall through to standalone mode
        }

        if ($healthService) {
            // Preferred path: reuse existing service
            $this->printUsingService($healthService);
        } else {
            // Robust standalone fallback (direct PDO)
            $this->printStandalone();
        }

        echo "\n✅ Health check finished at " . date('Y-m-d H:i:s') . "\n";
    }

    private function printUsingService(HealthCheckService $svc): void
    {
        echo "📊 Using centralized HealthCheckService\n\n";

        $outbox = $svc->probeOutbox();
        printf("📤 Outbox: pending=%d failed/dlq=%d (status: %s)\n",
            $outbox['pending'] ?? 0, $outbox['failed_or_dlq'] ?? 0, $outbox['status'] ?? 'unknown');

        $dlq = $svc->probeDLQ();
        printf("💀 DLQ (failed_jobs): %d (status: %s)\n",
            $dlq['total_failed_jobs'] ?? 0, $dlq['status'] ?? 'unknown');

        $saga = $svc->probeSaga();
        printf("🔄 Saga: running=%d failed=%d (status: %s)\n",
            $saga['running'] ?? 0, $saga['failed'] ?? 0, $saga['status'] ?? 'unknown');

        $idemp = $svc->probeIdempotency();
        printf("🔁 Idempotency pending keys: %d\n", $idemp['pending_keys'] ?? 0);

        echo "\n";
    }

    private function printStandalone(): void
    {
        echo "⚠️  Using standalone PDO fallback (HealthCheckService not available)\n\n";

        $pdo = $this->getPdo();
        if (!$pdo) {
            echo "❌ Could not connect to database.\n";
            return;
        }

        // Same queries as before for robustness
        try {
            $pending = (int)$pdo->query("SELECT COUNT(*) FROM outbox_events WHERE status='pending'")->fetchColumn();
            $bad = (int)$pdo->query("SELECT COUNT(*) FROM outbox_events WHERE status IN ('failed','dlq')")->fetchColumn();
            printf("📤 Outbox: Pending=%d Failed/DLQ=%d\n", $pending, $bad);
        } catch (\Throwable $e) { echo "📤 Outbox: (error)\n"; }

        try {
            $c = (int)$pdo->query("SELECT COUNT(*) FROM failed_jobs")->fetchColumn();
            printf("💀 DLQ (failed_jobs): %d\n", $c);
        } catch (\Throwable $e) { echo "💀 DLQ: (error)\n"; }

        try {
            $run = (int)$pdo->query("SELECT COUNT(*) FROM saga_executions WHERE status='running'")->fetchColumn();
            $fail = (int)$pdo->query("SELECT COUNT(*) FROM saga_executions WHERE status='failed'")->fetchColumn();
            printf("🔄 Saga: running=%d failed=%d\n", $run, $fail);
        } catch (\Throwable $e) { echo "🔄 Saga: (error)\n"; }

        try {
            $p = (int)$pdo->query("SELECT COUNT(*) FROM idempotency_keys WHERE status='pending'")->fetchColumn();
            printf("🔁 Idempotency pending: %d\n", $p);
        } catch (\Throwable $e) { echo "🔁 Idempotency: (error)\n"; }
    }

    private function getPdo(): ?\PDO
    {
        try {
            $db = $this->container->make(\Core\Database::class);
            if (method_exists($db, 'getPdo')) {
                return $db->getPdo();
            }
        } catch (\Throwable $e) {
            @error_log('[DistributedHealthCommand\] ' . $e->getMessage());
        }

        $envPath = __DIR__ . '/../../.env';
        if (!file_exists($envPath)) return null;

        $env = parse_ini_file($envPath, false, INI_SCANNER_RAW);
        $host = $env['DB_HOST'] ?? '127.0.0.1';
        $port = $env['DB_PORT'] ?? '3306';
        $db   = $env['DB_NAME'] ?? 'chortke';
        $user = $env['DB_USER'] ?? 'chortke_user';
        $pass = $env['DB_PASS'] ?? 'chortke_pass_123';

        try {
            $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4";
            return new \PDO($dsn, $user, $pass, [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_OBJ,
            ]);
        } catch (\Throwable $e) {
            return null;
        }
    }
}
