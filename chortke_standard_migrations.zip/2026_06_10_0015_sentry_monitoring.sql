-- CHORTKE MIGRATION PART 15: SENTRY & MONITORING
SET FOREIGN_KEY_CHECKS = 0;

-- [REMOVED DUPLICATE sentry_issues]
DROP TABLE IF EXISTS `sentry_events`;
CREATE TABLE `sentry_events` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `issue_id` INT(10) UNSIGNED NOT NULL,
    `event_id` VARCHAR(64) UNIQUE NOT NULL,
    `message` LONGTEXT,
    `payload` JSON,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `user_id` INT(10) UNSIGNED,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_se_issue` (`issue_id`),
    KEY `idx_se_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;-- [REMOVED DUPLICATE system_telemetry]


SET FOREIGN_KEY_CHECKS = 1;
