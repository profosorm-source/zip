/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: chortk
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `account_deletion_logs`
--

DROP TABLE IF EXISTS `account_deletion_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_deletion_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `reason` text DEFAULT NULL,
  `requested_at` timestamp NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(10) unsigned DEFAULT NULL,
  `status` enum('pending','completed','cancelled','deleted','requested') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_deletion_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `account_deletion_logs` WRITE;
/*!40000 ALTER TABLE `account_deletion_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_deletion_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `activity_type` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activities_user` (`user_id`),
  KEY `idx_activities_type_created` (`activity_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `event` varchar(100) NOT NULL,
  `action` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `channel` varchar(50) DEFAULT 'system',
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ad_delivery_events`
--

DROP TABLE IF EXISTS `ad_delivery_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ad_delivery_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned NOT NULL,
  `ad_type` varchar(50) NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `units` decimal(16,4) NOT NULL DEFAULT 1.0000,
  `unit_cost` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `amount` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `platform_fee` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `currency` varchar(10) NOT NULL DEFAULT 'irt',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `reference_id` varchar(100) DEFAULT NULL,
  `reference_type` varchar(100) DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  `idempotency_key` varchar(128) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ad_delivery_idempotency` (`idempotency_key`),
  KEY `idx_ad_delivery_ad` (`ad_id`,`event_type`,`created_at`),
  KEY `idx_ad_delivery_type` (`ad_type`,`event_type`),
  KEY `idx_ad_delivery_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ad_delivery_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ad_delivery_events` WRITE;
/*!40000 ALTER TABLE `ad_delivery_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `ad_delivery_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `admin_access_logs`
--

DROP TABLE IF EXISTS `admin_access_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_access_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `action` varchar(100) DEFAULT NULL,
  `resource` varchar(100) DEFAULT NULL,
  `resource_id` varchar(64) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin_logs_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_access_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `admin_access_logs` WRITE;
/*!40000 ALTER TABLE `admin_access_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_access_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `admin_audit_log`
--

DROP TABLE IF EXISTS `admin_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `session_id` varchar(128) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `admin_audit_log` WRITE;
/*!40000 ALTER TABLE `admin_audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_audit_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ads`
--

DROP TABLE IF EXISTS `ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `keyword` varchar(100) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `task_type` varchar(100) DEFAULT NULL,
  `price_per_task` decimal(24,4) DEFAULT 0.0000,
  `price_per_click` decimal(24,4) DEFAULT 0.0000,
  `total_budget` decimal(24,4) DEFAULT 0.0000,
  `remaining_budget` decimal(24,4) DEFAULT 0.0000,
  `spent_budget` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `last_delivery_at` timestamp NULL DEFAULT NULL,
  `delivery_pricing` longtext DEFAULT NULL,
  `total_count` int(10) unsigned DEFAULT 0,
  `remaining_count` int(10) unsigned DEFAULT 0,
  `pending_count` int(10) unsigned DEFAULT 0,
  `completed_count` int(10) unsigned DEFAULT 0,
  `clicks_count` int(10) unsigned DEFAULT 0,
  `impressions` int(10) unsigned DEFAULT 0,
  `clicks` int(10) unsigned DEFAULT 0,
  `ctr` decimal(5,2) DEFAULT 0.00,
  `placement` varchar(50) DEFAULT NULL,
  `banner_type` varchar(50) DEFAULT 'system',
  `category` varchar(100) DEFAULT NULL,
  `sort_order` int(10) NOT NULL DEFAULT 0,
  `target` varchar(20) DEFAULT '_blank',
  `alt_text` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `is_active` tinyint(1) DEFAULT 1,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `deadline` timestamp NULL DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `link` varchar(2048) DEFAULT NULL,
  `proof_type` varchar(50) DEFAULT 'screenshot',
  `proof_description` text DEFAULT NULL,
  `sample_image` varchar(255) DEFAULT NULL,
  `currency` varchar(10) DEFAULT 'irt',
  `deadline_hours` int(10) unsigned DEFAULT 24,
  `country_restriction` varchar(100) DEFAULT NULL,
  `device_restriction` varchar(50) DEFAULT 'all',
  `os_restriction` varchar(50) DEFAULT NULL,
  `site_commission_percent` decimal(5,2) DEFAULT 10.00,
  `restrictions` longtext DEFAULT NULL,
  `target_url` varchar(2048) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `reject_reason` text DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `site_url` varchar(2048) DEFAULT NULL,
  `min_payout` decimal(24,8) DEFAULT 0.00000000,
  `max_payout` decimal(24,8) DEFAULT 0.00000000,
  `target_duration` int(10) unsigned DEFAULT 60,
  `min_score` int(10) unsigned DEFAULT 40,
  `max_per_day` int(10) unsigned DEFAULT 10,
  `executions_count` int(10) unsigned DEFAULT 0,
  `budget` decimal(24,8) DEFAULT 0.00000000,
  `proof_schema` longtext DEFAULT NULL,
  `auto_approve_hours` int(10) unsigned DEFAULT NULL,
  `reject_rules` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ad_user` (`user_id`),
  KEY `idx_ad_type` (`type`),
  KEY `idx_ad_status` (`status`),
  KEY `idx_ads_phase4_finance` (`type`,`status`,`remaining_budget`,`last_delivery_at`),
  KEY `idx_ads_banner_admin` (`type`,`banner_type`,`placement`,`status`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ads`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ads` WRITE;
/*!40000 ALTER TABLE `ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `ads` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `adtube_views`
--

DROP TABLE IF EXISTS `adtube_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `adtube_views` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned NOT NULL,
  `executor_id` int(10) unsigned NOT NULL,
  `status` varchar(50) DEFAULT 'pending' COMMENT 'pending, watching, completed, rejected, disputed',
  `watch_time` int(10) unsigned DEFAULT 0 COMMENT 'seconds actually watched',
  `progress_percent` tinyint(3) unsigned DEFAULT 0 COMMENT '0-100 playback progress',
  `video_duration` int(10) unsigned DEFAULT 0 COMMENT 'total video length in seconds',
  `playback_speed` decimal(3,2) DEFAULT 1.00 COMMENT 'detected playback speed',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `idempotency_key` varchar(100) DEFAULT NULL,
  `reward_amount` decimal(24,4) DEFAULT 0.0000,
  `reward_currency` varchar(10) DEFAULT 'irt',
  `reward_paid` tinyint(1) DEFAULT 0,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `reject_reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `active_executor_id` int(10) unsigned GENERATED ALWAYS AS (if(`status` in ('pending','watching'),`executor_id`,NULL)) VIRTUAL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  UNIQUE KEY `idx_adtube_views_unique_active` (`ad_id`,`active_executor_id`),
  KEY `idx_adtube_views_ad_executor` (`ad_id`,`executor_id`),
  KEY `idx_adtube_views_status` (`status`),
  KEY `idx_adtube_views_executor` (`executor_id`),
  CONSTRAINT `fk_adtube_views_ad_id` FOREIGN KEY (`ad_id`) REFERENCES `ads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Execution records for AdTube (video watch) advertisements — separate from social_task_executions due to domain-specific metrics (watch_time, progress_percent)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adtube_views`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `adtube_views` WRITE;
/*!40000 ALTER TABLE `adtube_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `adtube_views` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `alert_rules`
--

DROP TABLE IF EXISTS `alert_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(191) NOT NULL,
  `condition` varchar(100) NOT NULL COMMENT 'threshold, percentage',
  `severity` enum('low','medium','high','warning','critical') NOT NULL DEFAULT 'medium',
  `threshold_value` decimal(10,2) DEFAULT NULL,
  `time_window_minutes` int(11) DEFAULT 60,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_rules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `alert_rules` WRITE;
/*!40000 ALTER TABLE `alert_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `alert_rules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `analytics`
--

DROP TABLE IF EXISTS `analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `metric_name` varchar(100) NOT NULL,
  `metric_value` decimal(24,8) DEFAULT NULL,
  `dimension` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `analytics` WRITE;
/*!40000 ALTER TABLE `analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `analytics_snapshots`
--

DROP TABLE IF EXISTS `analytics_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_snapshots` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `metric` varchar(100) NOT NULL,
  `value` decimal(24,4) DEFAULT NULL,
  `dimension` varchar(50) DEFAULT NULL,
  `dimension_value` varchar(255) DEFAULT NULL,
  `snapshot_date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `metric_snapshot` (`metric`,`snapshot_date`,`dimension`,`dimension_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_snapshots`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `analytics_snapshots` WRITE;
/*!40000 ALTER TABLE `analytics_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics_snapshots` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `api_tokens`
--

DROP TABLE IF EXISTS `api_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(100) NOT NULL,
  `refresh_token` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `secret_version` varchar(20) DEFAULT 'v2',
  `scopes` varchar(255) DEFAULT '*',
  `revoked` tinyint(1) DEFAULT 0,
  `use_count` int(10) unsigned DEFAULT 0,
  `expires_at` timestamp NULL DEFAULT NULL,
  `secret_version_expires_at` timestamp NULL DEFAULT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  UNIQUE KEY `refresh_token` (`refresh_token`),
  KEY `idx_api_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `api_tokens` WRITE;
/*!40000 ALTER TABLE `api_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `appeals`
--

DROP TABLE IF EXISTS `appeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `appeals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_appeal_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appeals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `appeals` WRITE;
/*!40000 ALTER TABLE `appeals` DISABLE KEYS */;
/*!40000 ALTER TABLE `appeals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `audit_trail`
--

DROP TABLE IF EXISTS `audit_trail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_trail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `actor_id` int(10) unsigned DEFAULT NULL,
  `event` varchar(255) DEFAULT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `hash` varchar(100) DEFAULT NULL,
  `request_id` varchar(64) DEFAULT NULL COMMENT 'Request correlation id (Sentry/trace).',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IPv4 / IPv6 of the actor at audit time.',
  `user_agent` text DEFAULT NULL COMMENT 'Verbatim User-Agent header.',
  `prev_hash` varchar(128) DEFAULT NULL COMMENT 'Chain link to previous audit row (hash integrity).',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `idx_audit_trail_event_fulltext` (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_trail`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `audit_trail` WRITE;
/*!40000 ALTER TABLE `audit_trail` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_trail` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `request_id` varchar(64) DEFAULT NULL,
  `type` varchar(50) DEFAULT 'manual',
  `file_path` varchar(255) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned DEFAULT 0,
  `checksum` varchar(64) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bank_cards`
--

DROP TABLE IF EXISTS `bank_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `card_number` varchar(255) NOT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `sheba` varchar(30) DEFAULT NULL,
  `iban` varchar(30) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `status` enum('pending','verified','rejected') DEFAULT 'pending',
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `card_hash` varchar(128) DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_card_unique` (`user_id`,`card_number`),
  KEY `idx_bank_cards_card_hash` (`card_hash`),
  CONSTRAINT `fk_bank_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_cards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bank_cards` WRITE;
/*!40000 ALTER TABLE `bank_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_cards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `banner` WRITE;
/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `banner_ads`
--

DROP TABLE IF EXISTS `banner_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banner_ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creator_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `image_url` varchar(500) NOT NULL,
  `link_url` varchar(500) NOT NULL,
  `placement` varchar(50) NOT NULL,
  `price_per_day` decimal(24,4) NOT NULL,
  `total_budget` decimal(24,4) NOT NULL,
  `remaining_budget` decimal(24,4) NOT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_banner_creator` (`creator_id`),
  KEY `idx_banner_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner_ads`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `banner_ads` WRITE;
/*!40000 ALTER TABLE `banner_ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner_ads` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `banner_clicks`
--

DROP TABLE IF EXISTS `banner_clicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banner_clicks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `banner_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `referer` varchar(500) DEFAULT NULL,
  `device_fingerprint` varchar(64) DEFAULT NULL,
  `clicked_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner_clicks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `banner_clicks` WRITE;
/*!40000 ALTER TABLE `banner_clicks` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner_clicks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `banner_placements`
--

DROP TABLE IF EXISTS `banner_placements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banner_placements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner_placements`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `banner_placements` WRITE;
/*!40000 ALTER TABLE `banner_placements` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner_placements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL,
  `placement` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `clicks` int(10) unsigned DEFAULT 0,
  `impressions` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blacklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('ip','email','mobile','fingerprint') NOT NULL,
  `value` varchar(191) NOT NULL,
  `reason` text DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `blacklist_val` (`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blacklist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `blacklist` WRITE;
/*!40000 ALTER TABLE `blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `blacklist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `block_appeals`
--

DROP TABLE IF EXISTS `block_appeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `block_appeals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `appeal_text` text NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `block_appeals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `block_appeals` WRITE;
/*!40000 ALTER TABLE `block_appeals` DISABLE KEYS */;
/*!40000 ALTER TABLE `block_appeals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bug_report_comments`
--

DROP TABLE IF EXISTS `bug_report_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bug_report_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bug_report_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_bug_report_comments_report` (`bug_report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bug_report_comments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bug_report_comments` WRITE;
/*!40000 ALTER TABLE `bug_report_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `bug_report_comments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bug_reports`
--

DROP TABLE IF EXISTS `bug_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bug_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `page_url` varchar(2048) NOT NULL DEFAULT '',
  `page_title` varchar(255) NOT NULL DEFAULT '',
  `category` varchar(50) NOT NULL DEFAULT 'other',
  `description` text NOT NULL,
  `screenshot_path` varchar(500) DEFAULT NULL,
  `screen_resolution` varchar(30) NOT NULL DEFAULT '',
  `device_fingerprint` varchar(255) NOT NULL DEFAULT '',
  `user_agent` varchar(500) NOT NULL DEFAULT '',
  `ip_address` varchar(45) DEFAULT NULL,
  `status` enum('open','answered','in_progress','on_hold','closed') NOT NULL DEFAULT 'open',
  `priority` enum('low','normal','high','urgent','critical') NOT NULL DEFAULT 'normal',
  `is_suspicious` tinyint(1) NOT NULL DEFAULT 0,
  `admin_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_bug_report_user` (`user_id`),
  KEY `idx_bug_report_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bug_reports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bug_reports` WRITE;
/*!40000 ALTER TABLE `bug_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `bug_reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `bulk_operations`
--

DROP TABLE IF EXISTS `bulk_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulk_operations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL COMMENT 'payout, message, status_update',
  `total_items` int(10) unsigned DEFAULT NULL,
  `processed_items` int(10) unsigned DEFAULT 0,
  `status` enum('pending','processing','completed','failed') DEFAULT 'pending',
  `log_file` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulk_operations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `bulk_operations` WRITE;
/*!40000 ALTER TABLE `bulk_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `bulk_operations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `captcha_attempts`
--

DROP TABLE IF EXISTS `captcha_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `captcha_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `session_id` varchar(128) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `challenge` varchar(255) DEFAULT NULL,
  `response` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `is_success` tinyint(1) DEFAULT 0,
  `score` decimal(8,4) DEFAULT NULL,
  `solved_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_captcha_user_created` (`user_id`,`created_at`),
  KEY `idx_captcha_session_created` (`session_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captcha_attempts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `captcha_attempts` WRITE;
/*!40000 ALTER TABLE `captcha_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `captcha_attempts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `common_passwords`
--

DROP TABLE IF EXISTS `common_passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `common_passwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password_hash` char(64) NOT NULL COMMENT 'SHA256 hash of password',
  `password_text` varchar(255) DEFAULT NULL COMMENT 'Original password (optional, for reference)',
  `frequency` int(11) DEFAULT 1 COMMENT 'Times seen in breaches',
  `source` varchar(100) DEFAULT NULL COMMENT 'Source: HIBP, RockYou, OWASP, etc',
  `severity` int(11) DEFAULT 1 COMMENT '1-5: danger level',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `password_hash` (`password_hash`),
  KEY `idx_hash` (`password_hash`),
  KEY `idx_frequency` (`frequency` DESC),
  KEY `idx_severity` (`severity` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common_passwords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `common_passwords` WRITE;
/*!40000 ALTER TABLE `common_passwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `common_passwords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `content_agreements`
--

DROP TABLE IF EXISTS `content_agreements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_agreements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` int(10) unsigned DEFAULT NULL,
  `submission_id` int(10) unsigned DEFAULT NULL,
  `agreed_at` timestamp NULL DEFAULT current_timestamp(),
  `agreement_text` text DEFAULT NULL,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `device_fingerprint` varchar(128) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ca_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_agreements`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `content_agreements` WRITE;
/*!40000 ALTER TABLE `content_agreements` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_agreements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `content_revenues`
--

DROP TABLE IF EXISTS `content_revenues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_revenues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `content_id` int(10) unsigned DEFAULT NULL,
  `submission_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(24,8) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `period` varchar(20) DEFAULT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT 0,
  `total_revenue` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `gross_amount` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `site_share_percent` decimal(6,2) NOT NULL DEFAULT 0.00,
  `site_share_amount` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `platform_fee` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `user_share_percent` decimal(6,2) NOT NULL DEFAULT 0.00,
  `user_share_amount` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `tax_percent` decimal(6,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `net_user_amount` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `currency` varchar(10) NOT NULL DEFAULT 'irt',
  `metadata` longtext DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `paid_by_admin` int(10) unsigned DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_revenues_user_status` (`user_id`,`status`,`is_deleted`),
  KEY `idx_content_revenues_submission_period` (`submission_id`,`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_revenues`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `content_revenues` WRITE;
/*!40000 ALTER TABLE `content_revenues` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_revenues` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `content_submissions`
--

DROP TABLE IF EXISTS `content_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_submissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `video_url` varchar(500) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `agreement_accepted` tinyint(1) NOT NULL DEFAULT 0,
  `agreement_accepted_at` timestamp NULL DEFAULT NULL,
  `agreement_ip` varchar(45) DEFAULT NULL,
  `agreement_fingerprint` varchar(128) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `rejected_by` int(10) unsigned DEFAULT NULL,
  `rejected_at` timestamp NULL DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `published_url` varchar(500) DEFAULT NULL,
  `published_by` int(10) unsigned DEFAULT NULL,
  `channel_name` varchar(255) DEFAULT NULL,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `suspended_by` int(10) unsigned DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_content_user` (`user_id`),
  KEY `idx_content_submissions_user_status` (`user_id`,`status`,`is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_submissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `content_submissions` WRITE;
/*!40000 ALTER TABLE `content_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_submissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `coupon_redemptions`
--

DROP TABLE IF EXISTS `coupon_redemptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_redemptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `coupon_id` int(10) unsigned NOT NULL,
  `redeemed_at` timestamp NULL DEFAULT current_timestamp(),
  `original_amount` decimal(24,4) DEFAULT 0.0000,
  `discount_amount` decimal(24,4) DEFAULT 0.0000,
  `final_amount` decimal(24,4) DEFAULT 0.0000,
  `currency` varchar(10) DEFAULT 'irt',
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cr_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_redemptions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `coupon_redemptions` WRITE;
/*!40000 ALTER TABLE `coupon_redemptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_redemptions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `type` enum('fixed','percent') DEFAULT 'fixed',
  `value` decimal(24,4) NOT NULL,
  `min_amount` decimal(24,4) DEFAULT 0.0000,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `usage_limit` int(10) unsigned DEFAULT NULL,
  `usage_count` int(10) unsigned DEFAULT 0,
  `applicable_to` varchar(50) DEFAULT 'all',
  `max_discount` decimal(24,4) DEFAULT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `min_purchase` decimal(24,4) DEFAULT 0.0000,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cron_jobs`
--

DROP TABLE IF EXISTS `cron_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cron_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `last_run` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cron_jobs` WRITE;
/*!40000 ALTER TABLE `cron_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cron_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `crypto_deposit_intents`
--

DROP TABLE IF EXISTS `crypto_deposit_intents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crypto_deposit_intents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `network` varchar(20) DEFAULT NULL,
  `currency` varchar(10) NOT NULL,
  `requested_amount` decimal(24,8) DEFAULT NULL,
  `expected_amount` decimal(24,8) DEFAULT NULL,
  `to_wallet` varchar(255) DEFAULT NULL,
  `amount` decimal(24,8) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tag` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `expires_at` datetime DEFAULT NULL,
  `claimed_at` datetime DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cdi_user` (`user_id`),
  KEY `idx_crypto_intents_open_user` (`user_id`,`status`,`expires_at`),
  KEY `idx_crypto_intents_amount` (`network`,`expected_amount`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crypto_deposit_intents`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `crypto_deposit_intents` WRITE;
/*!40000 ALTER TABLE `crypto_deposit_intents` DISABLE KEYS */;
/*!40000 ALTER TABLE `crypto_deposit_intents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `crypto_deposits`
--

DROP TABLE IF EXISTS `crypto_deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `crypto_deposits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `intent_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(24,8) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'usdt',
  `tx_hash` varchar(255) DEFAULT NULL,
  `network` varchar(50) DEFAULT NULL,
  `wallet_address` varchar(255) DEFAULT NULL,
  `from_wallet` varchar(255) DEFAULT NULL,
  `deposit_date` date DEFAULT NULL,
  `deposit_time` time DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `verification_status` varchar(20) DEFAULT 'unverified',
  `auto_check_deadline` datetime DEFAULT NULL,
  `auto_check_attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `transaction_id` varchar(64) DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `explorer_data` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `verification_attempts` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tx_hash` (`tx_hash`),
  KEY `idx_cd_user` (`user_id`),
  KEY `idx_status_created` (`verification_status`,`created_at`),
  KEY `idx_crypto_deposit_intent` (`intent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crypto_deposits`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `crypto_deposits` WRITE;
/*!40000 ALTER TABLE `crypto_deposits` DISABLE KEYS */;
/*!40000 ALTER TABLE `crypto_deposits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `custom_task_analytics`
--

DROP TABLE IF EXISTS `custom_task_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_task_analytics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `total_submissions` int(10) unsigned DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_analytics_unique` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_task_analytics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `custom_task_analytics` WRITE;
/*!40000 ALTER TABLE `custom_task_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_task_analytics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `custom_task_submissions`
--

DROP TABLE IF EXISTS `custom_task_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_task_submissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `worker_id` int(10) unsigned NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `proof_url` text DEFAULT NULL,
  `proof_text` text DEFAULT NULL,
  `reward_amount` decimal(24,4) DEFAULT NULL,
  `reward_currency` varchar(10) DEFAULT 'irt',
  `idempotency_key` varchar(100) DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` int(10) unsigned DEFAULT NULL,
  `deadline_at` timestamp NULL DEFAULT NULL,
  `worker_ip` varchar(45) DEFAULT NULL,
  `worker_fingerprint` varchar(128) DEFAULT NULL,
  `proof_file` varchar(255) DEFAULT NULL,
  `proof_file_hash` varchar(100) DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `reward_paid` tinyint(1) NOT NULL DEFAULT 0,
  `reward_transaction_id` varchar(100) DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  `proof_code` varchar(255) DEFAULT NULL,
  `proof_data` longtext DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `auto_approved_at` timestamp NULL DEFAULT NULL,
  `dispute_id` int(10) unsigned DEFAULT NULL,
  `paid_amount` decimal(24,4) DEFAULT NULL,
  `resolution_type` varchar(50) DEFAULT NULL,
  `resolution_note` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `idx_cts_task` (`task_id`),
  KEY `idx_cts_worker` (`worker_id`),
  KEY `idx_cts_status_deadline` (`status`,`deadline_at`),
  KEY `idx_cts_worker_status` (`worker_id`,`status`),
  KEY `idx_cts_task_worker_status` (`task_id`,`worker_id`,`status`),
  KEY `idx_cts_task_proof_code` (`task_id`,`proof_code`),
  KEY `idx_cts_task_proof_url` (`task_id`,`proof_url`(191)),
  KEY `idx_cts_auto_approve` (`status`,`submitted_at`),
  KEY `idx_cts_expire` (`status`,`deadline_at`),
  KEY `idx_cts_resolution_type` (`resolution_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_task_submissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `custom_task_submissions` WRITE;
/*!40000 ALTER TABLE `custom_task_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_task_submissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `custom_task_transactions`
--

DROP TABLE IF EXISTS `custom_task_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_task_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `transaction_id` varchar(64) DEFAULT NULL,
  `amount` decimal(24,4) DEFAULT NULL,
  `type` enum('payout','refund','fee') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_task_transactions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `custom_task_transactions` WRITE;
/*!40000 ALTER TABLE `custom_task_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_task_transactions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `custom_tasks`
--

DROP TABLE IF EXISTS `custom_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creator_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `proof_type` enum('screenshot','text','video','code','file') DEFAULT 'screenshot',
  `price_per_task` decimal(24,4) NOT NULL,
  `total_budget` decimal(24,4) NOT NULL,
  `remaining_budget` decimal(24,4) NOT NULL,
  `total_count` int(10) unsigned NOT NULL,
  `remaining_count` int(10) unsigned NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ct_creator` (`creator_id`),
  KEY `idx_ct_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_tasks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `custom_tasks` WRITE;
/*!40000 ALTER TABLE `custom_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_tasks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `data_exports`
--

DROP TABLE IF EXISTS `data_exports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_exports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `format` enum('json','csv','excel') NOT NULL,
  `status` enum('pending','processing','completed','failed') DEFAULT 'pending',
  `file_path` varchar(255) DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_export_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_exports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `data_exports` WRITE;
/*!40000 ALTER TABLE `data_exports` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_exports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `data_migration_logs`
--

DROP TABLE IF EXISTS `data_migration_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_migration_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration_name` varchar(255) DEFAULT NULL,
  `batch` int(10) unsigned DEFAULT NULL,
  `applied_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_migration_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `data_migration_logs` WRITE;
/*!40000 ALTER TABLE `data_migration_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_migration_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `device_blacklist`
--

DROP TABLE IF EXISTS `device_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_blacklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fingerprint` varchar(64) NOT NULL,
  `reason` text DEFAULT NULL,
  `blocked_by` int(10) unsigned DEFAULT NULL,
  `auto_blocked` tinyint(1) DEFAULT 0,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_blacklist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `device_blacklist` WRITE;
/*!40000 ALTER TABLE `device_blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_blacklist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `direct_messages`
--

DROP TABLE IF EXISTS `direct_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `direct_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(10) unsigned NOT NULL,
  `recipient_id` int(10) unsigned NOT NULL,
  `message` text NOT NULL,
  `is_encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `deleted_by` int(10) unsigned DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_dm_users` (`sender_id`,`recipient_id`),
  KEY `idx_direct_messages_recipient_read` (`recipient_id`,`read_at`),
  KEY `idx_direct_messages_deleted_by` (`deleted_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `direct_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `direct_messages` WRITE;
/*!40000 ALTER TABLE `direct_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `direct_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `disposable_domains`
--

DROP TABLE IF EXISTS `disposable_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `disposable_domains` (
  `domain` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disposable_domains`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `disposable_domains` WRITE;
/*!40000 ALTER TABLE `disposable_domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `disposable_domains` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `dispute_evidence`
--

DROP TABLE IF EXISTS `dispute_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispute_evidence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dispute_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_de_dispute` (`dispute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispute_evidence`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `dispute_evidence` WRITE;
/*!40000 ALTER TABLE `dispute_evidence` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispute_evidence` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `dispute_messages`
--

DROP TABLE IF EXISTS `dispute_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispute_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dispute_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `role` varchar(50) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_dm_dispute` (`dispute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispute_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `dispute_messages` WRITE;
/*!40000 ALTER TABLE `dispute_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispute_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `disputes`
--

DROP TABLE IF EXISTS `disputes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `disputes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ref_type` varchar(50) NOT NULL,
  `ref_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `target_user_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(50) DEFAULT 'open',
  `reason` text NOT NULL,
  `admin_id` int(10) unsigned DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `role` varchar(50) DEFAULT 'customer',
  `admin_note` text DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `peer_deadline` timestamp NULL DEFAULT NULL,
  `resolution_note` text DEFAULT NULL,
  `admin_decision` varchar(50) DEFAULT NULL,
  `penalty_amount` decimal(24,4) DEFAULT NULL,
  `penalty_currency` varchar(10) DEFAULT NULL,
  `penalty_target` varchar(50) DEFAULT NULL,
  `site_tax_amount` decimal(24,4) DEFAULT NULL,
  `refund_percent` decimal(5,2) DEFAULT NULL,
  `resolved_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_d_ref` (`ref_type`,`ref_id`),
  KEY `idx_d_user` (`user_id`),
  KEY `idx_disputes_ref_status` (`ref_type`,`ref_id`,`status`),
  KEY `idx_disputes_user_status` (`user_id`,`target_user_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disputes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `disputes` WRITE;
/*!40000 ALTER TABLE `disputes` DISABLE KEYS */;
/*!40000 ALTER TABLE `disputes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `email_intelligence`
--

DROP TABLE IF EXISTS `email_intelligence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_intelligence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `domain` varchar(191) NOT NULL,
  `is_disposable` tinyint(1) NOT NULL DEFAULT 0,
  `is_free_provider` tinyint(1) NOT NULL DEFAULT 0,
  `mx_records_valid` tinyint(1) NOT NULL DEFAULT 0,
  `domain_reputation_score` int(10) NOT NULL DEFAULT 0,
  `last_checked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_intelligence`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `email_intelligence` WRITE;
/*!40000 ALTER TABLE `email_intelligence` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_intelligence` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `email_queue`
--

DROP TABLE IF EXISTS `email_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `to_email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `status` enum('pending','sent','failed') DEFAULT 'pending',
  `attempts` tinyint(3) unsigned DEFAULT 0,
  `last_error` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `scheduled_at` timestamp NULL DEFAULT current_timestamp(),
  `priority` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_queue`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `email_queue` WRITE;
/*!40000 ALTER TABLE `email_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_queue` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `error_logs`
--

DROP TABLE IF EXISTS `error_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `error_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `exception_class` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `line` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `url` varchar(2048) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `trace` text DEFAULT NULL,
  `status` varchar(50) DEFAULT 'unresolved',
  `status_code` smallint(5) unsigned DEFAULT NULL,
  `resolved_by` int(10) unsigned DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `resolution_note` text DEFAULT NULL,
  `occurrences` int(10) unsigned DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_error_logs_user_created` (`user_id`,`created_at`),
  KEY `idx_error_logs_status_updated` (`status`,`updated_at`),
  KEY `idx_error_logs_status_code` (`status_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `error_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `error_logs` WRITE;
/*!40000 ALTER TABLE `error_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `error_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `escrow_audit`
--

DROP TABLE IF EXISTS `escrow_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `escrow_audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `escrow_id` int(10) unsigned NOT NULL,
  `action` varchar(100) NOT NULL,
  `amount` decimal(24,8) NOT NULL,
  `performed_by` varchar(100) NOT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrow_audit`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `escrow_audit` WRITE;
/*!40000 ALTER TABLE `escrow_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `escrow_audit` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `escrow_logs`
--

DROP TABLE IF EXISTS `escrow_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `escrow_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `escrow_id` int(10) unsigned NOT NULL,
  `action` varchar(100) NOT NULL,
  `actor_id` int(10) unsigned DEFAULT NULL,
  `actor_type` varchar(50) DEFAULT NULL,
  `details` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_escrow_logs_escrow` (`escrow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrow_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `escrow_logs` WRITE;
/*!40000 ALTER TABLE `escrow_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `escrow_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `escrow_transactions`
--

DROP TABLE IF EXISTS `escrow_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `escrow_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(100) NOT NULL,
  `order_type` varchar(100) NOT NULL,
  `buyer_id` int(10) unsigned NOT NULL,
  `seller_id` int(10) unsigned NOT NULL,
  `amount` decimal(24,8) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'USDT',
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `held_at` timestamp NULL DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `released_at` timestamp NULL DEFAULT NULL,
  `released_by` varchar(100) DEFAULT NULL,
  `refunded_at` timestamp NULL DEFAULT NULL,
  `refund_reason` text DEFAULT NULL,
  `refunded_by` varchar(100) DEFAULT NULL,
  `disputed_at` timestamp NULL DEFAULT NULL,
  `dispute_reason` text DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `partial_released` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `transaction_id` varchar(64) DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_escrow_buyer` (`buyer_id`),
  KEY `fk_escrow_seller` (`seller_id`),
  CONSTRAINT `fk_escrow_buyer` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_escrow_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrow_transactions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `escrow_transactions` WRITE;
/*!40000 ALTER TABLE `escrow_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `escrow_transactions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `escrows`
--

DROP TABLE IF EXISTS `escrows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `escrows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(64) DEFAULT NULL,
  `buyer_id` int(10) unsigned NOT NULL,
  `seller_id` int(10) unsigned NOT NULL,
  `amount` decimal(24,8) NOT NULL,
  `currency` varchar(10) DEFAULT 'irt',
  `status` enum('held','released','refunded','disputed') DEFAULT 'held',
  `release_reason` varchar(255) DEFAULT NULL,
  `released_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `idx_escrow_users` (`buyer_id`,`seller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrows`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `escrows` WRITE;
/*!40000 ALTER TABLE `escrows` DISABLE KEYS */;
/*!40000 ALTER TABLE `escrows` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `event_failures`
--

DROP TABLE IF EXISTS `event_failures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_failures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_name` varchar(255) NOT NULL,
  `listener` varchar(255) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `error_message` text NOT NULL,
  `failed_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_failures`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `event_failures` WRITE;
/*!40000 ALTER TABLE `event_failures` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_failures` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_type` varchar(100) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text DEFAULT NULL,
  `queue` text DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  `exception` longtext DEFAULT NULL,
  `failed_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `feature_flag_cache`
--

DROP TABLE IF EXISTS `feature_flag_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature_flag_cache` (
  `cache_key` varchar(191) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL,
  `cached_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`cache_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_flag_cache`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `feature_flag_cache` WRITE;
/*!40000 ALTER TABLE `feature_flag_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `feature_flag_cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `feature_flag_history`
--

DROP TABLE IF EXISTS `feature_flag_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature_flag_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `feature_name` varchar(100) NOT NULL,
  `action` varchar(50) NOT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `changed_by` int(10) unsigned NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_flag_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `feature_flag_history` WRITE;
/*!40000 ALTER TABLE `feature_flag_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `feature_flag_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `feature_flag_metrics`
--

DROP TABLE IF EXISTS `feature_flag_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature_flag_metrics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `feature_name` varchar(100) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `check_result` tinyint(1) NOT NULL,
  `check_reason` varchar(50) DEFAULT NULL,
  `checked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `response_time_ms` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_flag_metrics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `feature_flag_metrics` WRITE;
/*!40000 ALTER TABLE `feature_flag_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `feature_flag_metrics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `feature_flags`
--

DROP TABLE IF EXISTS `feature_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature_flags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `enabled` tinyint(1) DEFAULT 0,
  `config_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config_values`)),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `description` text DEFAULT NULL,
  `enabled_percentage` int(11) DEFAULT 100,
  `enabled_for_roles` text DEFAULT NULL,
  `enabled_for_users` text DEFAULT NULL,
  `enabled_for_countries` text DEFAULT NULL,
  `enabled_for_devices` text DEFAULT NULL,
  `enabled_for_routes` text DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  `enabled_from` timestamp NULL DEFAULT NULL,
  `enabled_until` timestamp NULL DEFAULT NULL,
  `depends_on` text DEFAULT NULL,
  `environments` text DEFAULT NULL,
  `priority` int(11) DEFAULT 0,
  `tags` text DEFAULT NULL,
  `min_age` int(11) DEFAULT NULL,
  `max_age` int(11) DEFAULT NULL,
  `targeted_user_ids` text DEFAULT NULL,
  `targeted_roles` text DEFAULT NULL,
  `targeted_countries` text DEFAULT NULL,
  `targeted_plans` text DEFAULT NULL,
  `targeted_devices` text DEFAULT NULL,
  `targeted_routes` text DEFAULT NULL,
  `target_age_min` int(11) DEFAULT NULL,
  `target_age_max` int(11) DEFAULT NULL,
  `percentage_rollout` int(11) DEFAULT 100,
  `rollout_seed` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_flags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `feature_flags` WRITE;
/*!40000 ALTER TABLE `feature_flags` DISABLE KEYS */;
INSERT INTO `feature_flags` VALUES
(1,'lottery',1,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی سیستم قرعه‌کشی و بخت‌آزمایی برای کاربران.',100,NULL,NULL,NULL,NULL,NULL,'{\"min_participants\":10,\"max_participants\":1000,\"entry_price\":10000}',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(2,'investment',1,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی سیستم سرمایه‌گذاری و صندوق سوددهی.',100,NULL,NULL,NULL,NULL,NULL,'{\"min_amount\":100000,\"max_amount\":10000000,\"commission_rate\":10}',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(3,'tasks',1,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی سیستم تسک‌های شبکه‌های اجتماعی (Like، Follow، Comment).',100,NULL,NULL,NULL,NULL,NULL,'{\"platforms\":{\"instagram\":true,\"telegram\":true,\"youtube\":true,\"twitter\":true,\"tiktok\":false}}',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(4,'referral',1,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی سیستم دعوت از دوستان و پاداش ارجاع.',100,NULL,NULL,NULL,NULL,NULL,'{\"commission_rates\":{\"tasks\":10,\"investment\":5,\"lottery\":3,\"content\":5}}',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(5,'coupons',0,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی سیستم کدهای تخفیف و کوپن‌های بازاریابی.',100,NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(6,'oauth_strict_ip_binding',0,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی strict IP binding برای ورود اجتماعی (OAuth) در محیط‌های امنیتی خاص. این گزینه برای جلوگیری از تکمیل callback توسط IP متفاوت استفاده می‌شود.',100,NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(7,'crypto_wallet',0,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی کیف پول و نگهداری موجودی رمزارز (USDT).',100,NULL,NULL,NULL,NULL,NULL,'{\"networks\":{\"bnb20\":true,\"trc20\":true,\"ton\":false,\"sol\":false}}',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(8,'crypto_deposit',0,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی قابلیت دریافت واریز رمزارز (crypto deposit) در مسیرهای کیف پول.',100,NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(9,'vitrine_enabled',1,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی ویترین و بازارچه کاربران (خرید/فروش بین کاربران).',100,NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(10,'investment_fees',1,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی سیستم کارمزد و مالیات محاسبه سود/ضرر سرمایه‌گذاری.',100,NULL,NULL,NULL,NULL,NULL,'{\"site_fee_percent\":2,\"tax_percent\":0,\"fee_tiers\":[]}',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(11,'investment_v2_calculation',0,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی نسخه ۲ محاسبه سود/ضرر سرمایه‌گذاری (به‌صورت تدریجی per-user).',100,NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(12,'beta',0,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی مجموعه‌ی فیچرهای آزمایشی (Beta): AI task verification، auto KYC، gamification.',100,NULL,NULL,NULL,NULL,NULL,'{\"ai_task_verification\":false,\"auto_kyc_verification\":false,\"gamification\":false}',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(25,'db_query_tracking',1,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','ارسال همه queryهای دیتابیس به Sentry Performance Monitor برای تشخیص N+1 patterns. Production: false پیش‌فرض.',100,NULL,NULL,NULL,NULL,NULL,'{\"sample_rate\":1}',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL),
(26,'analytics_cache_enabled',1,NULL,'2026-08-06 08:36:31','2026-08-06 08:36:31','فعال‌سازی cache نتایج aggregate در Redis (dashboard queries). کاهش 10x فشار روی DB.',100,NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100,NULL);
/*!40000 ALTER TABLE `feature_flags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `file_access_logs`
--

DROP TABLE IF EXISTS `file_access_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_access_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `access_type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_access_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `file_access_logs` WRITE;
/*!40000 ALTER TABLE `file_access_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_access_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `file_logs`
--

DROP TABLE IF EXISTS `file_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `folder` varchar(100) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `viewer_id` int(10) unsigned DEFAULT NULL,
  `file_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_file_logs_folder_file` (`folder`,`filename`),
  KEY `idx_file_logs_viewer` (`viewer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `file_logs` WRITE;
/*!40000 ALTER TABLE `file_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `financial_snapshots`
--

DROP TABLE IF EXISTS `financial_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_snapshots` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `total_users_balance_irt` decimal(30,4) DEFAULT NULL,
  `total_users_balance_usdt` decimal(30,8) DEFAULT NULL,
  `system_revenue_total` decimal(30,4) DEFAULT NULL,
  `ledger_balance_status` enum('balanced','unbalanced') DEFAULT 'balanced',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_snapshots`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `financial_snapshots` WRITE;
/*!40000 ALTER TABLE `financial_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `financial_snapshots` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_alerts`
--

DROP TABLE IF EXISTS `fraud_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_alerts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alert_type` varchar(100) NOT NULL,
  `severity` varchar(20) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fraud_alerts_assigned_status` (`assigned_to`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_alerts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_alerts` WRITE;
/*!40000 ALTER TABLE `fraud_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_alerts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_analytics`
--

DROP TABLE IF EXISTS `fraud_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_analytics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `risk_score` decimal(10,2) DEFAULT 0.00,
  `trust_level` enum('trusted','neutral','suspicious','banned') DEFAULT 'neutral',
  `last_check_at` timestamp NULL DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_analytics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_analytics` WRITE;
/*!40000 ALTER TABLE `fraud_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_analytics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_calculation_logs`
--

DROP TABLE IF EXISTS `fraud_calculation_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_calculation_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `account_age_factor` int(10) NOT NULL DEFAULT 0,
  `reputation_factor` int(10) NOT NULL DEFAULT 0,
  `velocity_factor` int(10) NOT NULL DEFAULT 0,
  `geographic_factor` int(10) NOT NULL DEFAULT 0,
  `final_score` int(10) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_calculation_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_calculation_logs` WRITE;
/*!40000 ALTER TABLE `fraud_calculation_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_calculation_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_graph_analysis`
--

DROP TABLE IF EXISTS `fraud_graph_analysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_graph_analysis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `session_id` varchar(128) DEFAULT NULL,
  `component_id` varchar(64) DEFAULT NULL,
  `connected_nodes` int(10) unsigned NOT NULL DEFAULT 0,
  `suspicious_edges` int(10) unsigned NOT NULL DEFAULT 0,
  `centrality_score` decimal(10,6) NOT NULL DEFAULT 0.000000,
  `anomaly_score` decimal(10,6) NOT NULL DEFAULT 0.000000,
  `risk_score` int(10) NOT NULL DEFAULT 0,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_graph_analysis`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_graph_analysis` WRITE;
/*!40000 ALTER TABLE `fraud_graph_analysis` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_graph_analysis` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_graph_edges`
--

DROP TABLE IF EXISTS `fraud_graph_edges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_graph_edges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_node_id` int(10) unsigned NOT NULL,
  `to_node_id` int(10) unsigned NOT NULL,
  `relation_type` varchar(50) NOT NULL,
  `weight` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `evidence` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`evidence`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_graph_edges`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_graph_edges` WRITE;
/*!40000 ALTER TABLE `fraud_graph_edges` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_graph_edges` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_graph_nodes`
--

DROP TABLE IF EXISTS `fraud_graph_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_graph_nodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `node_type` varchar(30) NOT NULL,
  `node_key` varchar(191) NOT NULL,
  `risk_score` int(10) NOT NULL DEFAULT 0,
  `attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attributes`)),
  `first_seen` timestamp NULL DEFAULT current_timestamp(),
  `last_seen` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_graph_nodes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_graph_nodes` WRITE;
/*!40000 ALTER TABLE `fraud_graph_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_graph_nodes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_logs`
--

DROP TABLE IF EXISTS `fraud_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `fraud_type` varchar(50) NOT NULL,
  `risk_score` int(10) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `action_taken` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_logs` WRITE;
/*!40000 ALTER TABLE `fraud_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_reports`
--

DROP TABLE IF EXISTS `fraud_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reporter_id` int(10) unsigned NOT NULL,
  `reported_user_id` int(10) unsigned NOT NULL,
  `reason` text NOT NULL,
  `evidence` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`evidence`)),
  `status` enum('pending','reviewed','dismissed') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_fraud_rep_reported` (`reported_user_id`),
  CONSTRAINT `fk_fraud_rep_reported` FOREIGN KEY (`reported_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_reports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_reports` WRITE;
/*!40000 ALTER TABLE `fraud_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fraud_rules`
--

DROP TABLE IF EXISTS `fraud_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fraud_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `rule_type` varchar(50) NOT NULL COMMENT 'ip_velocity, session_count, geo_change, etc.',
  `condition_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'شرایط قانون' CHECK (json_valid(`condition_json`)),
  `risk_score` int(10) NOT NULL COMMENT 'امتیاز ریسک اگر match شد',
  `action` varchar(50) NOT NULL COMMENT 'notify, challenge, block',
  `is_active` tinyint(1) DEFAULT 1,
  `priority` int(10) DEFAULT 0 COMMENT 'اولویت اجرا',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fraud_rules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fraud_rules` WRITE;
/*!40000 ALTER TABLE `fraud_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `fraud_rules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `idempotency_keys`
--

DROP TABLE IF EXISTS `idempotency_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `idempotency_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `action` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `request_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_data`)),
  `result` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_key` (`key`),
  KEY `idx_user_action` (`user_id`,`action`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `idempotency_keys`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `idempotency_keys` WRITE;
/*!40000 ALTER TABLE `idempotency_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `idempotency_keys` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `influencer_categories`
--

DROP TABLE IF EXISTS `influencer_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `influencer_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `influencer_categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `influencer_categories` WRITE;
/*!40000 ALTER TABLE `influencer_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `influencer_categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `influencer_orders`
--

DROP TABLE IF EXISTS `influencer_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `influencer_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `buyer_id` int(10) unsigned NOT NULL,
  `influencer_id` int(10) unsigned NOT NULL,
  `amount` decimal(24,8) NOT NULL,
  `influencer_earnings` decimal(24,8) NOT NULL,
  `status` enum('pending_acceptance','pending_buyer_review','completed','cancelled') DEFAULT 'pending_acceptance',
  `deadline` timestamp NULL DEFAULT NULL,
  `content_submitted_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` varchar(255) DEFAULT NULL,
  `auto_approved` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_inf_order_influencer` (`influencer_id`),
  CONSTRAINT `fk_inf_order_influencer` FOREIGN KEY (`influencer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `influencer_orders`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `influencer_orders` WRITE;
/*!40000 ALTER TABLE `influencer_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `influencer_orders` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `influencer_profiles`
--

DROP TABLE IF EXISTS `influencer_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `influencer_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `platform` varchar(50) NOT NULL,
  `followers_count` int(10) unsigned DEFAULT 0,
  `price_story` decimal(24,4) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `priority` int(10) unsigned NOT NULL DEFAULT 0,
  `completed_orders` int(10) unsigned NOT NULL DEFAULT 0,
  `follower_count` int(10) unsigned DEFAULT 0,
  `story_price_24h` decimal(24,4) DEFAULT 0.0000,
  `bio` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `verification_code` varchar(50) DEFAULT NULL,
  `verification_post_url` varchar(2048) DEFAULT NULL,
  `page_url` varchar(2048) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `engagement_rate` decimal(5,2) DEFAULT 0.00,
  `post_price_24h` decimal(24,4) DEFAULT 0.0000,
  `post_price_48h` decimal(24,4) DEFAULT 0.0000,
  `post_price_72h` decimal(24,4) DEFAULT 0.0000,
  `currency` varchar(10) DEFAULT 'irt',
  `total_orders` int(10) unsigned DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 5.00,
  `rejection_reason` text DEFAULT NULL,
  `verified_by` int(10) unsigned DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `suspended_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_inf_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `influencer_profiles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `influencer_profiles` WRITE;
/*!40000 ALTER TABLE `influencer_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `influencer_profiles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `influencer_verifications`
--

DROP TABLE IF EXISTS `influencer_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `influencer_verifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `influencer_id` int(10) unsigned NOT NULL,
  `profile_id` int(10) unsigned DEFAULT NULL,
  `verification_type` varchar(50) DEFAULT NULL,
  `proof_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`proof_data`)),
  `status` varchar(20) DEFAULT 'pending',
  `admin_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `code` varchar(50) DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `proof_url` varchar(2048) DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `post_url` varchar(2048) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_iv_influencer` (`influencer_id`),
  KEY `idx_influencer_verifications_profile` (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `influencer_verifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `influencer_verifications` WRITE;
/*!40000 ALTER TABLE `influencer_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `influencer_verifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `interactions`
--

DROP TABLE IF EXISTS `interactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `interactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `interactable_type` varchar(191) NOT NULL,
  `interactable_id` int(10) unsigned NOT NULL,
  `interaction_type` varchar(50) NOT NULL COMMENT 'like, favorite, view',
  `value` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `context` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_interact_target` (`interactable_type`,`interactable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interactions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `interactions` WRITE;
/*!40000 ALTER TABLE `interactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `interactions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `investment_plans`
--

DROP TABLE IF EXISTS `investment_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_plans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `min_amount` decimal(24,4) NOT NULL,
  `max_amount` decimal(24,4) DEFAULT NULL,
  `profit_percent` decimal(5,2) NOT NULL,
  `duration_days` int(10) unsigned NOT NULL,
  `risk_level` enum('low','medium','high') DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_plans`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `investment_plans` WRITE;
/*!40000 ALTER TABLE `investment_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `investment_plans` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `investment_profits`
--

DROP TABLE IF EXISTS `investment_profits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_profits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `investment_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(24,8) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_profits`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `investment_profits` WRITE;
/*!40000 ALTER TABLE `investment_profits` DISABLE KEYS */;
/*!40000 ALTER TABLE `investment_profits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `investment_withdrawals`
--

DROP TABLE IF EXISTS `investment_withdrawals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `investment_withdrawals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `investment_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(24,8) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(30) DEFAULT 'profit_only',
  `request_id` varchar(100) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `processed_by` int(10) unsigned DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investment_withdrawals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `investment_withdrawals` WRITE;
/*!40000 ALTER TABLE `investment_withdrawals` DISABLE KEYS */;
/*!40000 ALTER TABLE `investment_withdrawals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `investments`
--

DROP TABLE IF EXISTS `investments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `investments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `amount` decimal(24,4) NOT NULL,
  `current_balance` decimal(24,4) DEFAULT 1025.5000,
  `plan_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `profit_earned` decimal(24,4) DEFAULT 0.0000,
  `profit` decimal(24,4) NOT NULL DEFAULT 0.0000,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_profit_date` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `transaction_id` varchar(64) DEFAULT NULL,
  `total_profit` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `total_loss` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `last_withdrawal_date` datetime DEFAULT NULL,
  `deposit_lock_until` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_inv_user` (`user_id`),
  CONSTRAINT `fk_investment_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `investments` WRITE;
/*!40000 ALTER TABLE `investments` DISABLE KEYS */;
/*!40000 ALTER TABLE `investments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ip_blacklist`
--

DROP TABLE IF EXISTS `ip_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_blacklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `reason` text DEFAULT NULL,
  `blocked_by` int(10) unsigned DEFAULT NULL,
  `auto_blocked` tinyint(1) DEFAULT 0,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_blacklist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ip_blacklist` WRITE;
/*!40000 ALTER TABLE `ip_blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_blacklist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ip_intelligence`
--

DROP TABLE IF EXISTS `ip_intelligence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_intelligence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `country` char(2) DEFAULT NULL,
  `is_vpn` tinyint(1) DEFAULT 0,
  `is_proxy` tinyint(1) DEFAULT 0,
  `is_tor` tinyint(1) DEFAULT 0,
  `risk_score` int(10) DEFAULT 0,
  `last_updated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_intelligence`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ip_intelligence` WRITE;
/*!40000 ALTER TABLE `ip_intelligence` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_intelligence` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ip_locations`
--

DROP TABLE IF EXISTS `ip_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_start` varbinary(16) NOT NULL,
  `ip_end` varbinary(16) NOT NULL,
  `country_code` varchar(2) DEFAULT NULL,
  `country_name` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,6) DEFAULT NULL,
  `longitude` decimal(10,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_locations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ip_locations` WRITE;
/*!40000 ALTER TABLE `ip_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_locations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `kpi_metrics`
--

DROP TABLE IF EXISTS `kpi_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kpi_metrics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `metric_key` varchar(100) NOT NULL,
  `metric_value` decimal(24,4) DEFAULT NULL,
  `recorded_date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `metric_day` (`metric_key`,`recorded_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kpi_metrics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `kpi_metrics` WRITE;
/*!40000 ALTER TABLE `kpi_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `kpi_metrics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `kyc_documents`
--

DROP TABLE IF EXISTS `kyc_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kyc_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kyc_id` int(10) unsigned NOT NULL,
  `doc_type` varchar(50) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `ocr_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ocr_data`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_kd_kyc` (`kyc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kyc_documents`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `kyc_documents` WRITE;
/*!40000 ALTER TABLE `kyc_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `kyc_documents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `kyc_verifications`
--

DROP TABLE IF EXISTS `kyc_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kyc_verifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `verification_image` varchar(255) DEFAULT NULL,
  `national_code` text DEFAULT NULL,
  `birth_date` varchar(255) DEFAULT NULL,
  `status` enum('pending','under_review','verified','rejected') DEFAULT 'pending',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `device_fingerprint` varchar(128) DEFAULT NULL,
  `encryption_version` tinyint(4) DEFAULT 2,
  `encryption_algorithm` varchar(50) DEFAULT 'AES-256-GCM',
  `rejection_reason` text DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `documents_deleted` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `admin_note` text DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `national_code_hash` varchar(128) DEFAULT NULL,
  `under_review_by` int(10) unsigned DEFAULT NULL,
  `review_started_at` timestamp NULL DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `front_image` varchar(255) DEFAULT NULL,
  `back_image` varchar(255) DEFAULT NULL,
  `selfie_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_kyc_status` (`status`),
  CONSTRAINT `fk_kyc_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kyc_verifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `kyc_verifications` WRITE;
/*!40000 ALTER TABLE `kyc_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `kyc_verifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ledger_entries`
--

DROP TABLE IF EXISTS `ledger_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ledger_entries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(64) NOT NULL,
  `account` varchar(100) NOT NULL,
  `debit` decimal(24,8) DEFAULT 0.00000000,
  `credit` decimal(24,8) DEFAULT 0.00000000,
  `currency` varchar(10) DEFAULT 'irt',
  `description` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_le_tx` (`transaction_id`),
  CONSTRAINT `fk_le_tx` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`transaction_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ledger_entries`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ledger_entries` WRITE;
/*!40000 ALTER TABLE `ledger_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `ledger_entries` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(191) NOT NULL COMMENT 'email or mobile',
  `ip_address` varchar(45) DEFAULT NULL,
  `status` enum('success','failed') NOT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_login_id` (`identifier`),
  KEY `idx_login_ip` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lottery_chance_logs`
--

DROP TABLE IF EXISTS `lottery_chance_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_chance_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `change_amount` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_chance_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lottery_chance_logs` WRITE;
/*!40000 ALTER TABLE `lottery_chance_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `lottery_chance_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lottery_daily_numbers`
--

DROP TABLE IF EXISTS `lottery_daily_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_daily_numbers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `winning_number` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `round_id` int(10) unsigned NOT NULL DEFAULT 0,
  `number1` int(11) DEFAULT NULL,
  `number2` int(11) DEFAULT NULL,
  `number3` int(11) DEFAULT NULL,
  `selected_number` int(11) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `seed_hash` varchar(128) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_lottery_daily_round_date_active` (`round_id`,`date`,`is_deleted`),
  KEY `idx_lottery_daily_round` (`round_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_daily_numbers`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lottery_daily_numbers` WRITE;
/*!40000 ALTER TABLE `lottery_daily_numbers` DISABLE KEYS */;
/*!40000 ALTER TABLE `lottery_daily_numbers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lottery_participations`
--

DROP TABLE IF EXISTS `lottery_participations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_participations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `round_id` int(10) unsigned NOT NULL,
  `ticket_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(50) DEFAULT 'active',
  `chance_score` decimal(24,4) DEFAULT 100.0000,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_lottery_participation_user_round_active` (`user_id`,`round_id`,`is_deleted`),
  KEY `idx_lp_round` (`round_id`),
  KEY `idx_lp_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_participations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lottery_participations` WRITE;
/*!40000 ALTER TABLE `lottery_participations` DISABLE KEYS */;
/*!40000 ALTER TABLE `lottery_participations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lottery_rounds`
--

DROP TABLE IF EXISTS `lottery_rounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_rounds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `prize_pool` decimal(24,4) DEFAULT 0.0000,
  `status` varchar(50) DEFAULT 'active',
  `winner_user_id` int(10) unsigned DEFAULT NULL,
  `draw_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `prize_amount` decimal(24,4) DEFAULT 0.0000,
  `ticket_price` decimal(24,4) DEFAULT 5000.0000,
  `max_capacity` int(10) unsigned DEFAULT 1000,
  `currency` varchar(10) NOT NULL DEFAULT 'irt',
  `entry_fee` decimal(24,4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_rounds`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lottery_rounds` WRITE;
/*!40000 ALTER TABLE `lottery_rounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `lottery_rounds` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lottery_votes`
--

DROP TABLE IF EXISTS `lottery_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_votes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `round_id` int(10) unsigned NOT NULL,
  `voted_number` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `daily_number_id` int(10) unsigned DEFAULT NULL,
  `participation_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'cast',
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_lottery_vote_user_daily_active` (`user_id`,`daily_number_id`,`is_deleted`),
  KEY `idx_lv_round` (`round_id`),
  KEY `idx_lottery_votes_daily` (`daily_number_id`),
  KEY `idx_lottery_votes_user_daily` (`user_id`,`daily_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_votes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lottery_votes` WRITE;
/*!40000 ALTER TABLE `lottery_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lottery_votes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `manual_deposits`
--

DROP TABLE IF EXISTS `manual_deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `manual_deposits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `card_id` int(10) unsigned DEFAULT NULL,
  `bank_card_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(24,8) NOT NULL,
  `currency` varchar(10) DEFAULT 'irt',
  `tracking_code` varchar(128) DEFAULT NULL,
  `user_description` text DEFAULT NULL,
  `receipt_path` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `admin_id` int(10) unsigned DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `transaction_id` varchar(64) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracking_code` (`tracking_code`),
  KEY `idx_md_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manual_deposits`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `manual_deposits` WRITE;
/*!40000 ALTER TABLE `manual_deposits` DISABLE KEYS */;
/*!40000 ALTER TABLE `manual_deposits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `message_attachments`
--

DROP TABLE IF EXISTS `message_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_attachments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_size` int(10) unsigned NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_attachments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `message_attachments` WRITE;
/*!40000 ALTER TABLE `message_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_attachments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `message_moderation_logs`
--

DROP TABLE IF EXISTS `message_moderation_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_moderation_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_type` varchar(50) DEFAULT NULL COMMENT 'dm, ticket, comment',
  `message_id` int(10) unsigned NOT NULL,
  `admin_id` int(10) unsigned NOT NULL,
  `action` enum('approved','rejected','hidden','edited') DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_moderation_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `message_moderation_logs` WRITE;
/*!40000 ALTER TABLE `message_moderation_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_moderation_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `message_reports`
--

DROP TABLE IF EXISTS `message_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reporter_id` int(10) unsigned NOT NULL,
  `message_id` int(10) unsigned NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mr_reporter` (`reporter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_reports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `message_reports` WRITE;
/*!40000 ALTER TABLE `message_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ml_feature_store`
--

DROP TABLE IF EXISTS `ml_feature_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_feature_store` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(30) NOT NULL,
  `entity_id` varchar(191) NOT NULL,
  `feature_name` varchar(100) NOT NULL,
  `feature_value` decimal(20,8) NOT NULL DEFAULT 0.00000000,
  `feature_text` varchar(255) DEFAULT NULL,
  `feature_time` timestamp NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_feature_store`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ml_feature_store` WRITE;
/*!40000 ALTER TABLE `ml_feature_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_feature_store` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ml_fraud_predictions`
--

DROP TABLE IF EXISTS `ml_fraud_predictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_fraud_predictions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `risk_score` decimal(8,4) DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `session_id` varchar(128) DEFAULT NULL,
  `model_name` varchar(100) NOT NULL,
  `model_version` varchar(50) NOT NULL,
  `probability` decimal(8,6) NOT NULL,
  `predicted_label` varchar(20) NOT NULL,
  `threshold_used` decimal(8,6) NOT NULL DEFAULT 0.500000,
  `top_features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`top_features`)),
  `raw_output` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`raw_output`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ml_fraud_user_risk` (`user_id`,`risk_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_fraud_predictions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ml_fraud_predictions` WRITE;
/*!40000 ALTER TABLE `ml_fraud_predictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_fraud_predictions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ml_models`
--

DROP TABLE IF EXISTS `ml_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ml_models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `model_name` varchar(100) NOT NULL,
  `version` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `auc` decimal(8,6) DEFAULT NULL,
  `precision_score` decimal(8,6) DEFAULT NULL,
  `recall_score` decimal(8,6) DEFAULT NULL,
  `f1_score` decimal(8,6) DEFAULT NULL,
  `trained_at` timestamp NULL DEFAULT NULL,
  `deployed_at` timestamp NULL DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml_models`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ml_models` WRITE;
/*!40000 ALTER TABLE `ml_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml_models` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `mobile_intelligence`
--

DROP TABLE IF EXISTS `mobile_intelligence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_intelligence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mobile` varchar(32) NOT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `carrier` varchar(100) DEFAULT NULL,
  `line_type` varchar(30) DEFAULT NULL,
  `is_voip` tinyint(1) NOT NULL DEFAULT 0,
  `is_valid` tinyint(1) NOT NULL DEFAULT 1,
  `last_checked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_intelligence`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `mobile_intelligence` WRITE;
/*!40000 ALTER TABLE `mobile_intelligence` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_intelligence` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `mv_dashboard_stats`
--

DROP TABLE IF EXISTS `mv_dashboard_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mv_dashboard_stats` (
  `currency` varchar(10) NOT NULL,
  `total_deposits` decimal(24,8) DEFAULT 0.00000000,
  `total_withdrawals` decimal(24,8) DEFAULT 0.00000000,
  `today_deposits` decimal(24,8) DEFAULT 0.00000000,
  `today_withdrawals` decimal(24,8) DEFAULT 0.00000000,
  `pending_transactions` int(11) DEFAULT 0,
  `site_revenue` decimal(24,8) DEFAULT 0.00000000,
  `today_revenue` decimal(24,8) DEFAULT 0.00000000,
  `weekly_revenue` decimal(24,8) DEFAULT 0.00000000,
  `monthly_revenue` decimal(24,8) DEFAULT 0.00000000,
  `total_transactions` int(11) DEFAULT 0,
  `active_users` int(11) DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mv_dashboard_stats`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `mv_dashboard_stats` WRITE;
/*!40000 ALTER TABLE `mv_dashboard_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `mv_dashboard_stats` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notification_analytics`
--

DROP TABLE IF EXISTS `notification_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_analytics` (
  `date` date NOT NULL,
  `type` varchar(50) NOT NULL,
  `channel` varchar(50) NOT NULL DEFAULT 'in_app',
  `sent` int(10) unsigned NOT NULL DEFAULT 0,
  `read_count` int(10) unsigned NOT NULL DEFAULT 0,
  `click_count` int(10) unsigned NOT NULL DEFAULT 0,
  `unique_users` int(10) unsigned NOT NULL DEFAULT 0,
  `ad_sent` int(10) unsigned NOT NULL DEFAULT 0,
  `ad_read` int(10) unsigned NOT NULL DEFAULT 0,
  `ad_click` int(10) unsigned NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`date`,`type`,`channel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_analytics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notification_analytics` WRITE;
/*!40000 ALTER TABLE `notification_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_analytics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notification_channels`
--

DROP TABLE IF EXISTS `notification_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_channels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `channel_type` enum('telegram','email','sms','webhook') DEFAULT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `is_active` tinyint(1) DEFAULT 1,
  `alert_levels` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`alert_levels`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_channels`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notification_channels` WRITE;
/*!40000 ALTER TABLE `notification_channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_channels` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notification_history`
--

DROP TABLE IF EXISTS `notification_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `channel_id` int(10) unsigned DEFAULT NULL,
  `status` enum('sent','failed','delivered') DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notif_hist_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notification_history` WRITE;
/*!40000 ALTER TABLE `notification_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notification_preferences_v2`
--

DROP TABLE IF EXISTS `notification_preferences_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_preferences_v2` (
  `user_id` int(10) unsigned NOT NULL,
  `in_app_enabled` tinyint(1) DEFAULT 1,
  `email_enabled` tinyint(1) DEFAULT 1,
  `push_enabled` tinyint(1) DEFAULT 1,
  `sms_enabled` tinyint(1) DEFAULT 0,
  `dnd_enabled` tinyint(1) DEFAULT 0,
  `dnd_start` time DEFAULT '23:00:00',
  `dnd_end` time DEFAULT '07:00:00',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `in_app_deposit` tinyint(1) DEFAULT 1,
  `in_app_withdrawal` tinyint(1) DEFAULT 1,
  `in_app_task` tinyint(1) DEFAULT 1,
  `in_app_investment` tinyint(1) DEFAULT 1,
  `in_app_lottery` tinyint(1) DEFAULT 1,
  `in_app_referral` tinyint(1) DEFAULT 1,
  `in_app_security` tinyint(1) DEFAULT 1,
  `in_app_kyc` tinyint(1) DEFAULT 1,
  `in_app_system` tinyint(1) DEFAULT 1,
  `in_app_marketing` tinyint(1) DEFAULT 0,
  `email_deposit` tinyint(1) DEFAULT 1,
  `email_withdrawal` tinyint(1) DEFAULT 1,
  `email_task` tinyint(1) DEFAULT 1,
  `email_investment` tinyint(1) DEFAULT 1,
  `email_lottery` tinyint(1) DEFAULT 1,
  `email_referral` tinyint(1) DEFAULT 1,
  `email_security` tinyint(1) DEFAULT 1,
  `email_kyc` tinyint(1) DEFAULT 1,
  `email_system` tinyint(1) DEFAULT 1,
  `email_marketing` tinyint(1) DEFAULT 0,
  `push_deposit` tinyint(1) DEFAULT 1,
  `push_withdrawal` tinyint(1) DEFAULT 1,
  `push_task` tinyint(1) DEFAULT 1,
  `push_investment` tinyint(1) DEFAULT 1,
  `push_lottery` tinyint(1) DEFAULT 1,
  `push_referral` tinyint(1) DEFAULT 1,
  `push_security` tinyint(1) DEFAULT 1,
  `push_kyc` tinyint(1) DEFAULT 1,
  `push_system` tinyint(1) DEFAULT 1,
  `push_marketing` tinyint(1) DEFAULT 0,
  `sms_deposit` tinyint(1) DEFAULT 0,
  `sms_withdrawal` tinyint(1) DEFAULT 1,
  `sms_task` tinyint(1) DEFAULT 0,
  `sms_investment` tinyint(1) DEFAULT 0,
  `sms_lottery` tinyint(1) DEFAULT 0,
  `sms_referral` tinyint(1) DEFAULT 0,
  `sms_security` tinyint(1) DEFAULT 1,
  `sms_kyc` tinyint(1) DEFAULT 1,
  `sms_system` tinyint(1) DEFAULT 0,
  `sms_marketing` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_preferences_v2`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notification_preferences_v2` WRITE;
/*!40000 ALTER TABLE `notification_preferences_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_preferences_v2` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notification_templates`
--

DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `body` text NOT NULL,
  `sms_body` text DEFAULT NULL,
  `push_body` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_templates`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `action_url` varchar(2048) DEFAULT NULL,
  `action_text` varchar(255) DEFAULT NULL,
  `priority` varchar(20) DEFAULT 'normal',
  `is_read` tinyint(1) DEFAULT 0,
  `is_archived` tinyint(1) DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `expires_at` datetime DEFAULT NULL,
  `channel` varchar(50) DEFAULT 'in_app',
  `read_at` datetime DEFAULT NULL,
  `clicked_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `ad_id` int(10) unsigned DEFAULT NULL COMMENT 'کمپین تبلیغاتی (ads.id) که این نوتیف را ارسال کرده',
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `shown_at` datetime DEFAULT NULL COMMENT 'زمان نمایش نوتیف روی گوشی',
  `opened_at` datetime DEFAULT NULL COMMENT 'زمان باز کردن / شروع خواندن',
  `closed_at` datetime DEFAULT NULL COMMENT 'زمان بسته شدن / خروج از نوتیف',
  `dismissed_at` datetime DEFAULT NULL COMMENT 'بسته شدن بدون تعامل (swipe away)',
  `read_duration_sec` int(10) unsigned DEFAULT NULL COMMENT 'مدت حضور در نوتیف (opened_at تا closed_at)',
  `engagement_source` varchar(30) DEFAULT NULL COMMENT 'منبع رویداد: app/mobile/web',
  PRIMARY KEY (`id`),
  KEY `idx_notif_user_read` (`user_id`,`is_read`),
  KEY `idx_notifications_deleted` (`user_id`,`is_deleted`,`deleted_at`),
  KEY `idx_notif_ad_eng` (`ad_id`,`is_read`),
  KEY `idx_notif_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `online_listings`
--

DROP TABLE IF EXISTS `online_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `online_listings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price_usdt` decimal(24,8) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ol_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_listings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `online_listings` WRITE;
/*!40000 ALTER TABLE `online_listings` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_listings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `outbox_events`
--

DROP TABLE IF EXISTS `outbox_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbox_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aggregate_type` varchar(80) NOT NULL,
  `aggregate_id` varchar(128) NOT NULL,
  `event_type` varchar(120) NOT NULL,
  `payload` longtext DEFAULT NULL,
  `status` enum('pending','processing','published','failed','dlq') NOT NULL DEFAULT 'pending',
  `attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `last_error` varchar(2000) DEFAULT NULL,
  `available_at` datetime NOT NULL,
  `published_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_outbox_pickup` (`status`,`available_at`,`attempts`),
  KEY `idx_outbox_aggregate` (`aggregate_type`,`aggregate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbox_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `outbox_events` WRITE;
/*!40000 ALTER TABLE `outbox_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `outbox_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `content` longtext DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `show_in_footer` tinyint(1) DEFAULT 1,
  `display_order` int(11) DEFAULT 0,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`email`),
  KEY `idx_reset_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateways` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `slug` varchar(50) DEFAULT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `is_active` tinyint(1) DEFAULT 1,
  `callback_ips` longtext DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `payment_gateways` WRITE;
/*!40000 ALTER TABLE `payment_gateways` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `payment_logs`
--

DROP TABLE IF EXISTS `payment_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `gateway` varchar(50) DEFAULT NULL,
  `amount` decimal(24,8) DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `status` varchar(20) DEFAULT NULL,
  `authority` varchar(128) DEFAULT NULL,
  `ref_id` varchar(128) DEFAULT NULL,
  `request_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_data`)),
  `response_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_data`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `paid_at` timestamp NULL DEFAULT NULL,
  `bank_card_id` int(10) unsigned DEFAULT NULL,
  `idempotency_key` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authority` (`authority`),
  KEY `idx_pay_user` (`user_id`),
  KEY `idx_pay_status` (`status`),
  KEY `idx_pay_auth` (`authority`),
  KEY `idx_payment_logs_idempotency` (`idempotency_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `payment_logs` WRITE;
/*!40000 ALTER TABLE `payment_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `performance_logs`
--

DROP TABLE IF EXISTS `performance_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `request_id` varchar(64) DEFAULT NULL,
  `metric` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `context` text DEFAULT NULL,
  `duration_ms` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `performance_logs` WRITE;
/*!40000 ALTER TABLE `performance_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `performance_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `performance_transactions`
--

DROP TABLE IF EXISTS `performance_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(64) NOT NULL,
  `request_id` varchar(64) DEFAULT NULL,
  `name` varchar(255) NOT NULL COMMENT 'Route or Job Name',
  `op` varchar(100) DEFAULT NULL,
  `duration_ms` decimal(10,2) DEFAULT NULL,
  `db_queries_count` int(11) DEFAULT NULL,
  `memory_peak_mb` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'ok',
  `spans` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`spans`)),
  `queries` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`queries`)),
  `issues` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`issues`)),
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `duration` decimal(10,2) DEFAULT 50.00,
  `memory_used` bigint(20) DEFAULT NULL,
  `peak_memory` bigint(20) DEFAULT NULL,
  `query_count` int(11) DEFAULT 2,
  `slow_queries_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_perf_tx_id` (`transaction_id`),
  KEY `idx_perf_request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_transactions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `performance_transactions` WRITE;
/*!40000 ALTER TABLE `performance_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `performance_transactions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `group_name` varchar(100) DEFAULT 'other',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'مشاهده واریز دستی','finance.deposit.view','finance','View manual deposits','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(2,'تأیید واریز دستی','finance.deposit.approve','finance','Approve/reject manual deposits','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(3,'مشاهده واریز کریپتو','finance.crypto.view','finance','View crypto deposits','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(4,'تأیید واریز کریپتو','finance.crypto.approve','finance','Approve/reject crypto deposits','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(5,'مشاهده برداشت‌ها','finance.withdrawal.view','finance','View withdrawals','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(6,'تأیید برداشت‌ها','finance.withdrawal.approve','finance','Approve/reject withdrawals','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(7,'مشاهده تراکنش‌ها','finance.transaction.view','finance','View transactions','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(8,'تأیید/برگشت تراکنش‌ها','finance.transaction.approve','finance','Approve/reverse transactions','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(9,'مشاهده کارت‌ها','finance.card.view','finance','View bank cards','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(10,'خروجی کاربران','admin.export.users','admin','Export users data (CSV)','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(11,'خروجی تراکنش‌ها','admin.export.transactions','admin','Export transactions data (CSV)','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(12,'خروجی برداشت‌ها','admin.export.withdrawals','admin','Export withdrawals data (CSV)','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(13,'خروجی حسابرسی','admin.export.audit','admin','Export audit trail (CSV)','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(14,'مشاهده کرون‌جاب‌ها','admin.view_cron_jobs','admin','View cron job list','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(15,'اجرای کرون‌جاب‌ها','admin.execute_cron_jobs','admin','Execute cron jobs manually','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(16,'مشاهده گزارش‌های باگ','bug_reports.view','bug_reports','View bug reports','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(17,'تغییر وضعیت گزارش باگ','bug_reports.update_status','bug_reports','Update bug report status','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(18,'تغییر اولویت گزارش باگ','bug_reports.update_priority','bug_reports','Update bug report priority','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(19,'مشاهده همه تیکت‌ها','tickets.view_all','tickets','View all tickets (not just own)','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(20,'ارجاع تیکت','tickets.assign','tickets','Assign tickets to operators','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(21,'مدیریت پیام‌ها','messages.moderate','messages','Moderate user messages','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(22,'مدیریت شبکه‌های اجتماعی','user.manage_social_accounts','user','Manage user social accounts','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(23,'مدیریت کاربران — مشاهده','user.manage.view','admin','View user management pages','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(24,'مدیریت کاربران — ویرایش','user.manage.edit','admin','Edit user profiles','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(25,'مسدودسازی کاربران','user.manage.ban','admin','Ban/suspend/unsuspend users','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(26,'ویرایش کاربران (legacy)','users.edit','admin','Edit users (legacy slug)','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(27,'مشاهده تنظیمات','settings.view','admin','View system settings','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(28,'ویرایش تنظیمات','settings.edit','admin','Edit system settings','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(29,'مشاهده تنظیمات (legacy)','admin.view_settings','admin','View settings (legacy slug)','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(30,'ویرایش تنظیمات (legacy)','admin.edit_settings','admin','Edit settings (legacy slug)','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(31,'مشاهده اینفلوئنسرها','influencer.view','admin','View influencer management','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(32,'مدیریت اینفلوئنسرها','influencer.manage','admin','Manage influencers','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(33,'مشاهده نقش‌ها','roles.view','admin','View roles','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(34,'مدیریت نقش‌ها','roles.manage','admin','Manage roles','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(35,'مشاهده ارجاعات','referrals.view','admin','View referrals','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(36,'مدیریت ارجاعات','referrals.manage','admin','Manage referrals','2026-08-06 08:36:31','2026-08-06 08:36:31'),
(37,'تأیید/رد کارت‌های بانکی','finance.card.approve','finance','Approve or reject user bank cards','2026-08-06 08:36:32','2026-08-06 08:36:32');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `phone_intelligence`
--

DROP TABLE IF EXISTS `phone_intelligence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_intelligence` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(32) NOT NULL,
  `country_code` varchar(8) DEFAULT NULL,
  `line_type` varchar(50) DEFAULT NULL,
  `is_voip` tinyint(1) DEFAULT 0,
  `is_valid` tinyint(1) DEFAULT 1,
  `last_checked_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  KEY `idx_phone_intelligence_checked` (`last_checked_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_intelligence`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `phone_intelligence` WRITE;
/*!40000 ALTER TABLE `phone_intelligence` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone_intelligence` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `platform_stats`
--

DROP TABLE IF EXISTS `platform_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `platform_stats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(50) NOT NULL,
  `metric_name` varchar(100) NOT NULL,
  `metric_value` decimal(24,4) DEFAULT 0.0000,
  `recorded_at` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ps_plat_metric` (`platform`,`metric_name`,`recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platform_stats`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `platform_stats` WRITE;
/*!40000 ALTER TABLE `platform_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `platform_stats` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `prediction_bets`
--

DROP TABLE IF EXISTS `prediction_bets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prediction_bets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `game_id` int(10) unsigned NOT NULL,
  `prediction` varchar(50) DEFAULT NULL,
  `amount` decimal(24,4) NOT NULL,
  `currency` varchar(10) DEFAULT 'irt',
  `payment_transaction_id` varchar(128) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `payout_amount` decimal(24,4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `amount_usdt` decimal(24,4) DEFAULT 10.0000,
  `payout_usdt` decimal(24,4) DEFAULT 0.0000,
  `payout_transaction_id` varchar(128) DEFAULT NULL,
  `refund_transaction_id` varchar(128) DEFAULT NULL,
  `settled_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pb_user` (`user_id`),
  KEY `idx_pb_game` (`game_id`),
  KEY `idx_prediction_bets_payment_tx` (`payment_transaction_id`),
  KEY `idx_prediction_bets_game_status_prediction` (`game_id`,`status`,`prediction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prediction_bets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `prediction_bets` WRITE;
/*!40000 ALTER TABLE `prediction_bets` DISABLE KEYS */;
/*!40000 ALTER TABLE `prediction_bets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `prediction_games`
--

DROP TABLE IF EXISTS `prediction_games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prediction_games` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `sport_type` varchar(50) DEFAULT 'football',
  `team_home` varchar(100) DEFAULT NULL,
  `team_away` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `status` varchar(50) DEFAULT 'open',
  `result` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `team1_logo` varchar(255) DEFAULT NULL,
  `team2_logo` varchar(255) DEFAULT NULL,
  `total_pool` decimal(24,4) DEFAULT 10000000.0000,
  `bonus_pool_usdt` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `bet_deadline` timestamp NULL DEFAULT (current_timestamp() + interval 2 day),
  `match_date` timestamp NULL DEFAULT current_timestamp(),
  `min_bet_usdt` decimal(24,4) DEFAULT 1.0000,
  `max_bet_usdt` decimal(24,4) DEFAULT 1000.0000,
  `commission_percent` decimal(5,2) DEFAULT 5.00,
  `site_fee_usdt` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `rollover_amount_usdt` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `settlement_policy` varchar(80) DEFAULT NULL,
  `settlement_summary` longtext DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` int(10) unsigned DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `finished_at` timestamp NULL DEFAULT NULL,
  `settled_by` int(10) unsigned DEFAULT NULL,
  `winners_paid` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prediction_games`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `prediction_games` WRITE;
/*!40000 ALTER TABLE `prediction_games` DISABLE KEYS */;
/*!40000 ALTER TABLE `prediction_games` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `queues`
--

DROP TABLE IF EXISTS `queues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `queues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL DEFAULT 'default',
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `reserved_at` timestamp NULL DEFAULT NULL,
  `available_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queues`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `queues` WRITE;
/*!40000 ALTER TABLE `queues` DISABLE KEYS */;
/*!40000 ALTER TABLE `queues` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rate_limit_requests`
--

DROP TABLE IF EXISTS `rate_limit_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rate_limit_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier_key` varchar(191) NOT NULL,
  `action` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limit_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rate_limit_requests` WRITE;
/*!40000 ALTER TABLE `rate_limit_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `rate_limit_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rate_limit_whitelist`
--

DROP TABLE IF EXISTS `rate_limit_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rate_limit_whitelist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(191) NOT NULL,
  `identifier_type` varchar(30) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limit_whitelist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rate_limit_whitelist` WRITE;
/*!40000 ALTER TABLE `rate_limit_whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `rate_limit_whitelist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `rate_limits`
--

DROP TABLE IF EXISTS `rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rate_limits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier_key` varchar(191) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `exceeded` tinyint(1) NOT NULL DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `route` varchar(255) DEFAULT NULL,
  `method` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_rate_limits_created_at` (`created_at`),
  KEY `idx_rate_limits_exceeded` (`exceeded`),
  KEY `idx_rate_limits_identifier` (`identifier_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limits`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `rate_limits` WRITE;
/*!40000 ALTER TABLE `rate_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `rate_limits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `target_id` int(10) unsigned NOT NULL,
  `ad_id` int(10) unsigned DEFAULT NULL,
  `ad_type` varchar(50) DEFAULT NULL,
  `target_type` varchar(50) NOT NULL,
  `rating` tinyint(3) unsigned DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `moderated_by` int(10) unsigned DEFAULT NULL,
  `moderated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_rating_unique` (`user_id`,`target_id`,`target_type`),
  KEY `idx_ratings_ad` (`ad_id`,`ad_type`),
  KEY `idx_ratings_status` (`status`),
  KEY `idx_ratings_moderated` (`moderated_by`,`moderated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `realtime_messages`
--

DROP TABLE IF EXISTS `realtime_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `realtime_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room` varchar(100) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(100) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `is_read` tinyint(1) DEFAULT 0,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realtime_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `realtime_messages` WRITE;
/*!40000 ALTER TABLE `realtime_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `realtime_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `referral_activity_logs`
--

DROP TABLE IF EXISTS `referral_activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_activity_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `action` varchar(50) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ral_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_activity_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `referral_activity_logs` WRITE;
/*!40000 ALTER TABLE `referral_activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_activity_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `referral_clicks`
--

DROP TABLE IF EXISTS `referral_clicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_clicks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referrer_id` int(10) unsigned NOT NULL,
  `click_user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `referred_at` timestamp NULL DEFAULT current_timestamp(),
  `converted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_rc_referrer` (`referrer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_clicks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `referral_clicks` WRITE;
/*!40000 ALTER TABLE `referral_clicks` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_clicks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `referral_commissions`
--

DROP TABLE IF EXISTS `referral_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_commissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `referrer_id` int(10) unsigned NOT NULL,
  `referred_id` int(10) unsigned NOT NULL,
  `amount` decimal(24,8) NOT NULL,
  `commission_amount` decimal(24,8) NOT NULL,
  `currency` varchar(10) DEFAULT 'irt',
  `status` varchar(50) DEFAULT 'pending',
  `idempotency_key` varchar(128) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `referred_user_id` int(10) unsigned DEFAULT NULL,
  `source_type` varchar(50) DEFAULT 'general',
  `context` longtext DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `paid_at` timestamp NULL DEFAULT NULL,
  `commission_date` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `idx_rc_ref` (`referrer_id`),
  KEY `idx_referral_commissions_referred` (`referred_user_id`),
  KEY `idx_referral_commissions_status_currency` (`status`,`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_commissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `referral_commissions` WRITE;
/*!40000 ALTER TABLE `referral_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_commissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `referral_milestones`
--

DROP TABLE IF EXISTS `referral_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_milestones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `threshold_value` int(10) unsigned NOT NULL,
  `milestone_type` varchar(50) DEFAULT NULL,
  `reward_amount` decimal(24,8) DEFAULT 0.00000000,
  `currency` enum('irt','usdt') DEFAULT 'irt',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_milestones`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `referral_milestones` WRITE;
/*!40000 ALTER TABLE `referral_milestones` DISABLE KEYS */;
INSERT INTO `referral_milestones` VALUES
(1,'اولین معرف موفق',1,'referrals',10000.00000000,'irt',1,'2026-08-06 08:36:32'),
(2,'۵ معرف موفق',5,'referrals',25000.00000000,'irt',1,'2026-08-06 08:36:32'),
(3,'۱۰ معرف موفق',10,'referrals',50000.00000000,'irt',1,'2026-08-06 08:36:32'),
(4,'۵۰ معرف موفق',50,'referrals',150000.00000000,'irt',1,'2026-08-06 08:36:32');
/*!40000 ALTER TABLE `referral_milestones` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `referral_tiers`
--

DROP TABLE IF EXISTS `referral_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_tiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `tier_name` varchar(50) DEFAULT NULL,
  `bonus_percent` decimal(5,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `upgraded_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_tiers`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `referral_tiers` WRITE;
/*!40000 ALTER TABLE `referral_tiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_tiers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `referral_user_milestones`
--

DROP TABLE IF EXISTS `referral_user_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_user_milestones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `milestone_id` int(10) unsigned NOT NULL,
  `reward_amount` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `currency` enum('irt','usdt') NOT NULL DEFAULT 'irt',
  `awarded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_milestone` (`user_id`,`milestone_id`),
  KEY `idx_um_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_user_milestones`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `referral_user_milestones` WRITE;
/*!40000 ALTER TABLE `referral_user_milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_user_milestones` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `risk_policies`
--

DROP TABLE IF EXISTS `risk_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `risk_policies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(50) NOT NULL COMMENT 'fraud, payment, auth',
  `key_name` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `value_type` varchar(20) NOT NULL DEFAULT 'string',
  `description` text DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `risk_key` (`domain`,`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risk_policies`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `risk_policies` WRITE;
/*!40000 ALTER TABLE `risk_policies` DISABLE KEYS */;
/*!40000 ALTER TABLE `risk_policies` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `fk_rp_permission` (`permission_id`),
  CONSTRAINT `fk_rp_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(2,1),
(3,1),
(2,2),
(3,2),
(2,3),
(3,3),
(2,4),
(3,4),
(2,5),
(3,5),
(2,6),
(3,6),
(2,7),
(3,7),
(2,8),
(3,8),
(2,9),
(3,9),
(2,10),
(3,10),
(2,11),
(3,11),
(2,12),
(3,12),
(2,13),
(3,13),
(2,14),
(3,14),
(2,15),
(3,15),
(2,16),
(3,16),
(2,17),
(3,17),
(2,18),
(3,18),
(2,19),
(3,19),
(2,20),
(3,20),
(2,21),
(3,21),
(2,22),
(3,22),
(2,23),
(3,23),
(2,24),
(3,24),
(2,25),
(3,25),
(2,26),
(3,26),
(2,27),
(3,27),
(2,28),
(3,28),
(2,29),
(3,29),
(2,30),
(3,30),
(2,31),
(3,31),
(2,32),
(3,32),
(2,33),
(3,33),
(2,34),
(3,34),
(2,35),
(3,35),
(2,36),
(3,36),
(2,37),
(3,37);
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'کاربر عادی','user','Default user role',1,1,'2026-08-06 08:36:31','2026-08-06 08:36:32',NULL),
(2,'مدیر','admin','Administrator role',1,1,'2026-08-06 08:36:31','2026-08-06 08:36:32',NULL),
(3,'سوپر مدیر','super_admin','Super administrator role',1,1,'2026-08-06 08:36:31','2026-08-06 08:36:32',NULL),
(5,'پشتیبانی','support','Support operator role',1,1,'2026-08-06 08:36:31','2026-08-06 08:36:32',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `saga_executions`
--

DROP TABLE IF EXISTS `saga_executions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `saga_executions` (
  `id` varchar(64) NOT NULL,
  `saga_name` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `executed_steps` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`executed_steps`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_saga_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saga_executions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `saga_executions` WRITE;
/*!40000 ALTER TABLE `saga_executions` DISABLE KEYS */;
/*!40000 ALTER TABLE `saga_executions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `scheduled_payments`
--

DROP TABLE IF EXISTS `scheduled_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `amount` decimal(24,8) NOT NULL,
  `currency` varchar(10) DEFAULT 'irt',
  `frequency` varchar(50) DEFAULT 'one_time',
  `next_run_at` timestamp NULL DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `description` varchar(255) DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  `idempotency_key` varchar(128) DEFAULT NULL,
  `last_run_at` timestamp NULL DEFAULT NULL,
  `processed_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_scheduled_payment_idempotency` (`idempotency_key`),
  KEY `idx_sp_user` (`user_id`),
  KEY `idx_scheduled_payments_due` (`status`,`next_run_at`),
  CONSTRAINT `fk_sp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_payments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `scheduled_payments` WRITE;
/*!40000 ALTER TABLE `scheduled_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `scheduled_payments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  `checksum` varchar(64) DEFAULT NULL,
  `executed_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration` (`migration`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES
(1,'2026_04_27_0001_database_recovery.sql',1,NULL,'2026-08-06 08:36:29'),
(2,'2026_04_28_0001_social_accounts_table.sql',1,NULL,'2026-08-06 08:36:29'),
(3,'2026_06_08_0001_create_system_settings.php',1,NULL,'2026-08-06 08:36:29'),
(4,'2026_06_10_0001_identity_real.sql',1,NULL,'2026-08-06 08:36:29'),
(5,'2026_06_10_0002_financial_real.sql',1,NULL,'2026-08-06 08:36:29'),
(6,'2026_06_10_0003_influencers_disputes.sql',1,NULL,'2026-08-06 08:36:29'),
(7,'2026_06_10_0004_tasks_real.sql',1,NULL,'2026-08-06 08:36:29'),
(8,'2026_06_10_0005_support_real.sql',1,NULL,'2026-08-06 08:36:29'),
(9,'2026_06_10_0006_referral_real.sql',1,NULL,'2026-08-06 08:36:29'),
(10,'2026_06_10_0007_support_messaging.sql',1,NULL,'2026-08-06 08:36:29'),
(11,'2026_06_10_0008_extended_financial.sql',1,NULL,'2026-08-06 08:36:29'),
(12,'2026_06_10_0009_settings_infra.sql',1,NULL,'2026-08-06 08:36:29'),
(13,'2026_06_10_0010_engagement_gaming.sql',1,NULL,'2026-08-06 08:36:29'),
(14,'2026_06_10_0011_investments_gaming.sql',1,NULL,'2026-08-06 08:36:29'),
(15,'2026_06_10_0012_content_logs.sql',1,NULL,'2026-08-06 08:36:29'),
(16,'2026_06_10_0013_marketing_content.sql',1,NULL,'2026-08-06 08:36:29'),
(17,'2026_06_10_0014_infrastructure.sql',1,NULL,'2026-08-06 08:36:29'),
(18,'2026_06_10_0015_notif_coupons_risk.sql',1,NULL,'2026-08-06 08:36:29'),
(19,'2026_06_10_0016_specialized_analytics.sql',1,NULL,'2026-08-06 08:36:29'),
(20,'2026_06_10_0017_escrow_bank_bulk.sql',1,NULL,'2026-08-06 08:36:29'),
(21,'2026_06_10_0018_final_system.sql',1,NULL,'2026-08-06 08:36:29'),
(22,'2026_06_10_0019_final_cleanup.sql',1,NULL,'2026-08-06 08:36:29'),
(23,'2026_06_10_0020_rbac_social_seo.sql',1,NULL,'2026-08-06 08:36:29'),
(24,'2026_06_10_0021_extended_rewards.sql',1,NULL,'2026-08-06 08:36:29'),
(25,'2026_06_10_0022_sentry_monitoring.sql',1,NULL,'2026-08-06 08:36:29'),
(26,'2026_06_10_0023_adv_settings_security.sql',1,NULL,'2026-08-06 08:36:29'),
(27,'2026_06_10_0024_payment_trading.sql',1,NULL,'2026-08-06 08:36:29'),
(28,'2026_06_10_0025_task_analytics.sql',1,NULL,'2026-08-06 08:36:29'),
(29,'2026_06_10_0026_ai_anti_fraud.sql',1,NULL,'2026-08-06 08:36:29'),
(30,'2026_06_10_0027_legal_marketing.sql',1,NULL,'2026-08-06 08:36:29'),
(31,'2026_06_10_0028_forensic_detailed_analytics.sql',1,NULL,'2026-08-06 08:36:29'),
(32,'2026_06_10_0029_final_infrastructure.sql',1,NULL,'2026-08-06 08:36:29'),
(33,'2026_06_10_0030_auth_security_hardened.sql',1,NULL,'2026-08-06 08:36:29'),
(34,'2026_06_10_0031_integrity_final.sql',1,NULL,'2026-08-06 08:36:29'),
(35,'2026_06_10_0032_advanced_analytics.sql',1,NULL,'2026-08-06 08:36:29'),
(36,'2026_06_10_0033_plans_and_docs.sql',1,NULL,'2026-08-06 08:36:29'),
(37,'2026_06_10_0034_final_invariants.sql',1,NULL,'2026-08-06 08:36:29'),
(38,'2026_06_10_0035_intelligence_graph.sql',1,NULL,'2026-08-06 08:36:29'),
(39,'2026_06_10_0036_analytics_search_ml.sql',1,NULL,'2026-08-06 08:36:29'),
(40,'2026_06_10_0037_ads_banners_extended.sql',1,NULL,'2026-08-06 08:36:29'),
(41,'2026_06_10_0038_audit_failures_system.sql',1,NULL,'2026-08-06 08:36:29'),
(42,'2026_06_10_0039_archive_forensics_final.sql',1,NULL,'2026-08-06 08:36:29'),
(43,'2026_06_10_0040_user_social_comm.sql',1,NULL,'2026-08-06 08:36:30'),
(44,'2026_06_10_0041_final_schema_hardening.sql',1,NULL,'2026-08-06 08:36:30'),
(45,'2026_06_10_0042_task_ticket_level_ext.sql',1,NULL,'2026-08-06 08:36:30'),
(46,'2026_06_10_0043_realtime_rate_limiting.sql',1,NULL,'2026-08-06 08:36:30'),
(47,'2026_06_10_0044_sync_missing.sql',1,NULL,'2026-08-06 08:36:30'),
(48,'2026_06_10_0045_blacklists_views.sql',1,NULL,'2026-08-06 08:36:30'),
(49,'2026_06_10_0046_final_missing_tables.sql',1,NULL,'2026-08-06 08:36:30'),
(50,'2026_06_10_0047_infrastructure_missing.sql',1,NULL,'2026-08-06 08:36:30'),
(51,'2026_06_10_0048_independent_tasks.sql',1,NULL,'2026-08-06 08:36:30'),
(52,'2026_06_10_0049_missing_business_tables.sql',1,NULL,'2026-08-06 08:36:30'),
(53,'2026_06_11_0001_fix_risk_policies_schema.sql',1,NULL,'2026-08-06 08:36:30'),
(54,'2026_06_12_0001_full_enterprise_schema_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(55,'2026_06_13_0001_finance_schema_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(56,'2026_06_14_0001_lottery_schema_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(57,'2026_06_14_0002_referral_schema_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(58,'2026_06_14_0003_referral_ui_admin_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(59,'2026_06_14_0004_scheduled_payments_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(60,'2026_06_14_0005_influencer_marketplace_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(61,'2026_06_14_0006_dispute_influencer_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(62,'2026_06_14_0007_social_task_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(63,'2026_06_14_0008_financial_deep_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(64,'2026_06_14_0009_users_auth_gaming_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(65,'2026_06_14_0010_wave3_schema_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(66,'2026_06_14_0011_wave3_state_schema_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(67,'2026_06_14_0012_wave3_final_missing_columns.sql',1,NULL,'2026-08-06 08:36:31'),
(68,'2026_06_14_0013_wave4_kyc_investment_escrow_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(69,'2026_06_14_0014_currency_normalize_to_irt.sql',1,NULL,'2026-08-06 08:36:31'),
(70,'2026_06_14_0015_users_kyc_level_columns.sql',1,NULL,'2026-08-06 08:36:31'),
(71,'2026_06_14_0016_users_level_lifecycle_columns.sql',1,NULL,'2026-08-06 08:36:31'),
(72,'2026_06_14_0017_audit_trail_observability_columns.sql',1,NULL,'2026-08-06 08:36:31'),
(73,'2026_06_15_0001_create_adtube_views.sql',1,NULL,'2026-08-06 08:36:31'),
(74,'2026_06_15_0002_seed_feature_flags.sql',1,NULL,'2026-08-06 08:36:31'),
(75,'2026_06_15_0003_feature_flags_add_created_at.sql',1,NULL,'2026-08-06 08:36:31'),
(76,'2026_06_15_0004_users_add_kyc_status_tier.sql',1,NULL,'2026-08-06 08:36:31'),
(77,'2026_06_15_0005_users_add_kyc_level_verified_at.sql',1,NULL,'2026-08-06 08:36:31'),
(78,'2026_06_15_0006_create_rate_limits_table.sql',1,NULL,'2026-08-06 08:36:31'),
(79,'2026_06_15_0007_ratings_add_moderation_columns.sql',1,NULL,'2026-08-06 08:36:31'),
(80,'2026_06_16_0001_fix_distributed_tables.sql',1,NULL,'2026-08-06 08:36:31'),
(81,'2026_06_16_0002_final_catch_all_tables.sql',1,NULL,'2026-08-06 08:36:31'),
(82,'2026_06_16_0003_add_all_foreign_keys.sql',1,NULL,'2026-08-06 08:36:31'),
(83,'2026_06_16_0004_complete_missing_schema.sql',1,NULL,'2026-08-06 08:36:31'),
(84,'2026_06_16_0005_seed_initial_data.php',1,NULL,'2026-08-06 08:36:31'),
(85,'2026_06_16_0006_seed_config_to_db.php',1,NULL,'2026-08-06 08:36:31'),
(86,'2026_06_16_0007_create_common_passwords_table.php',1,NULL,'2026-08-06 08:36:31'),
(87,'2026_06_18_0001_create_tasks_view.sql',1,NULL,'2026-08-06 08:36:31'),
(88,'2026_06_19_0001_notification_granular_preferences.sql',1,NULL,'2026-08-06 08:36:31'),
(89,'2026_06_19_0002_social_task_mobile_scoring.sql',1,NULL,'2026-08-06 08:36:31'),
(90,'2026_06_19_0003_custom_task_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(91,'2026_06_20_0001_custom_task_proof_schema_indexes.sql',1,NULL,'2026-08-06 08:36:31'),
(92,'2026_06_20_0002_custom_task_phase3_auto_dispute.sql',1,NULL,'2026-08-06 08:36:31'),
(93,'2026_06_20_0003_custom_task_split_video.sql',1,NULL,'2026-08-06 08:36:31'),
(94,'2026_06_20_0004_seo_task_reconciliation.sql',1,NULL,'2026-08-06 08:36:31'),
(95,'2026_06_20_0005_ads_phase4_finance_delivery.sql',1,NULL,'2026-08-06 08:36:31'),
(96,'2026_06_20_0006_ads_phase6_legacy_surface_cleanup.sql',1,NULL,'2026-08-06 08:36:31'),
(97,'2026_06_20_0007_content_phase1_schema_route_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(98,'2026_06_21_0001_prediction_phase1_finance_rules.sql',1,NULL,'2026-08-06 08:36:31'),
(99,'2026_06_28_0001_add_refresh_token_to_api_tokens.sql',1,NULL,'2026-08-06 08:36:31'),
(100,'2026_07_16_0001_sentry_performance_transactions_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(101,'2026_07_16_0002_ml_fraud_predictions_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(102,'2026_07_16_0003_captcha_attempts_observability_compat.sql',1,NULL,'2026-08-06 08:36:31'),
(103,'2026_07_16_0004_tickets_workflow_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(104,'2026_07_16_0005_ticket_messages_workflow_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(105,'2026_07_16_0006_users_profile_fields_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(106,'2026_07_16_0007_file_logs_access_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(107,'2026_07_16_0008_phone_intelligence_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(108,'2026_07_16_0009_bank_cards_hash_index_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(109,'2026_07_16_0010_direct_messages_encryption_soft_delete_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(110,'2026_07_16_0011_crypto_deposits_currency_default_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(111,'2026_07_16_0012_user_flags_fraud_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(112,'2026_07_16_0013_task_reports_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(113,'2026_07_16_0014_user_settings_timestamps_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(114,'2026_07_16_0015_users_account_deletion_timestamps_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(115,'2026_07_16_0016_observability_admin_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(116,'2026_07_16_0017_error_logs_status_code_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(117,'2026_07_16_0018_finance_card_approve_permission_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(118,'2026_07_16_0019_tickets_status_workflow_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(119,'2026_07_23_0023_tickets_assignment_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(120,'2026_07_23_0024_notifications_soft_delete_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(121,'2026_07_23_0025_adtube_reject_reason_compat.sql',1,NULL,'2026-08-06 08:36:32'),
(122,'2026_07_24_0002_crypto_deposits_intent_link.sql',1,NULL,'2026-08-06 08:36:32'),
(123,'2026_07_24_0003_crypto_deposits_sender_wallet.sql',1,NULL,'2026-08-06 08:36:32'),
(124,'2026_07_26_0001_fraud_dashboard_runtime_contracts.sql',1,NULL,'2026-08-06 08:36:32'),
(125,'2026_07_26_0002_user_typing_patterns.sql',1,NULL,'2026-08-06 08:36:32'),
(126,'2026_08_03_0001_notification_ad_analytics.sql',1,NULL,'2026-08-06 08:36:32'),
(127,'2026_08_03_0002_remove_task_disputes.sql',1,NULL,'2026-08-06 08:36:32'),
(128,'2026_08_03_0003_remove_vitrine_disputes.sql',1,NULL,'2026-08-06 08:36:32'),
(129,'2026_08_03_0004_referral_milestone_tracking.sql',1,NULL,'2026-08-06 08:36:32'),
(130,'2026_08_03_0005_referral_signup_settings.sql',1,NULL,'2026-08-06 08:36:32'),
(131,'9999_0001_final_add_foreign_keys.sql',1,NULL,'2026-08-06 08:36:32');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `score_events`
--

DROP TABLE IF EXISTS `score_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `score_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entity_id` int(10) unsigned NOT NULL,
  `domain` varchar(50) NOT NULL,
  `entity_type` varchar(50) NOT NULL DEFAULT 'user',
  `delta` decimal(24,8) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_se_entity` (`entity_id`,`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `score_events` WRITE;
/*!40000 ALTER TABLE `score_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `score_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `domain` varchar(50) NOT NULL,
  `score` decimal(24,4) DEFAULT 0.0000,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_score_domain` (`user_id`,`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `scores` WRITE;
/*!40000 ALTER TABLE `scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `scores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `search_projections`
--

DROP TABLE IF EXISTS `search_projections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_projections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `owner_id` int(10) unsigned DEFAULT NULL,
  `scope` varchar(50) NOT NULL DEFAULT 'module',
  `module` varchar(50) DEFAULT NULL,
  `ref` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entity_type_id_unique` (`entity_type`,`entity_id`),
  KEY `owner_scope_module_idx` (`owner_id`,`scope`,`module`),
  FULLTEXT KEY `projection_fulltext` (`title`,`content`,`ref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_projections`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `search_projections` WRITE;
/*!40000 ALTER TABLE `search_projections` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_projections` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `security_events`
--

DROP TABLE IF EXISTS `security_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `event_type` varchar(100) NOT NULL,
  `severity` enum('low','medium','high','critical') DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sec_event_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `security_events` WRITE;
/*!40000 ALTER TABLE `security_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `security_logs`
--

DROP TABLE IF EXISTS `security_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `security_logs` WRITE;
/*!40000 ALTER TABLE `security_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sentry_breadcrumbs`
--

DROP TABLE IF EXISTS `sentry_breadcrumbs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sentry_breadcrumbs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` varchar(64) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `level` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_breadcrumb_event` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sentry_breadcrumbs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sentry_breadcrumbs` WRITE;
/*!40000 ALTER TABLE `sentry_breadcrumbs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sentry_breadcrumbs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sentry_events`
--

DROP TABLE IF EXISTS `sentry_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sentry_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` int(10) unsigned NOT NULL,
  `event_id` varchar(64) NOT NULL,
  `request_id` varchar(128) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `culprit` varchar(255) DEFAULT NULL,
  `exception_type` varchar(255) DEFAULT NULL,
  `stack_trace` longtext DEFAULT NULL,
  `breadcrumbs` longtext DEFAULT NULL,
  `user_context` longtext DEFAULT NULL,
  `request_context` longtext DEFAULT NULL,
  `device_context` longtext DEFAULT NULL,
  `tags` longtext DEFAULT NULL,
  `extra` longtext DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `release_version` varchar(100) DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_id` (`event_id`),
  KEY `idx_se_issue` (`issue_id`),
  KEY `idx_se_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sentry_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sentry_events` WRITE;
/*!40000 ALTER TABLE `sentry_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `sentry_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sentry_issue_events`
--

DROP TABLE IF EXISTS `sentry_issue_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sentry_issue_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` int(10) unsigned NOT NULL,
  `event_type` varchar(50) NOT NULL COMMENT 'assigned, resolved, reopened',
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sie_issue` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sentry_issue_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sentry_issue_events` WRITE;
/*!40000 ALTER TABLE `sentry_issue_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `sentry_issue_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sentry_issues`
--

DROP TABLE IF EXISTS `sentry_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sentry_issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fingerprint` varchar(64) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `culprit` varchar(255) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `release_version` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `count` int(10) unsigned DEFAULT 1,
  `first_seen` timestamp NULL DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `acknowledged_at` datetime DEFAULT NULL,
  `acknowledged_by` int(10) unsigned DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fingerprint` (`fingerprint`),
  KEY `idx_status` (`status`),
  KEY `idx_sentry_issues_acknowledged_at` (`acknowledged_at`),
  KEY `idx_sentry_issues_acknowledged_by` (`acknowledged_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sentry_issues`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sentry_issues` WRITE;
/*!40000 ALTER TABLE `sentry_issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `sentry_issues` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `seo_ads`
--

DROP TABLE IF EXISTS `seo_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `site_url` varchar(500) NOT NULL,
  `title` varchar(150) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `budget` decimal(14,2) NOT NULL,
  `remaining_budget` decimal(14,2) NOT NULL,
  `price_per_click` decimal(10,2) NOT NULL DEFAULT 500.00,
  `clicks_count` int(10) unsigned NOT NULL DEFAULT 0,
  `status` enum('pending','active','paused','rejected','exhausted') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_ads`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `seo_ads` WRITE;
/*!40000 ALTER TABLE `seo_ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_ads` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `seo_blacklist`
--

DROP TABLE IF EXISTS `seo_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_blacklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rule_type` varchar(30) NOT NULL,
  `rule_value` varchar(255) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_blacklist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `seo_blacklist` WRITE;
/*!40000 ALTER TABLE `seo_blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_blacklist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `seo_executions`
--

DROP TABLE IF EXISTS `seo_executions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_executions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `time_score` decimal(10,2) DEFAULT 0.00,
  `scroll_score` decimal(10,2) DEFAULT 0.00,
  `interaction_score` decimal(10,2) DEFAULT 0.00,
  `quality_score` decimal(10,2) DEFAULT 0.00,
  `final_score` decimal(10,2) DEFAULT 0.00,
  `payout_amount` decimal(24,8) DEFAULT 0.00000000,
  `engagement_data` longtext DEFAULT NULL,
  `fraud_flags` longtext DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `device_fingerprint` varchar(191) DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `execution_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `session_id` varchar(64) DEFAULT NULL,
  `target_keyword` varchar(255) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `cancel_reason` text DEFAULT NULL,
  `fraud_score` int(10) DEFAULT NULL,
  `client_mode` varchar(50) DEFAULT NULL,
  `score_breakdown` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_se_user` (`user_id`),
  KEY `idx_seo_exec_ad_user_date` (`ad_id`,`user_id`,`execution_date`),
  KEY `idx_seo_exec_status_date` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_executions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `seo_executions` WRITE;
/*!40000 ALTER TABLE `seo_executions` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_executions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `seo_executions_legacy_bak`
--

DROP TABLE IF EXISTS `seo_executions_legacy_bak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_executions_legacy_bak` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `earned_amount` decimal(24,4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_executions_legacy_bak`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `seo_executions_legacy_bak` WRITE;
/*!40000 ALTER TABLE `seo_executions_legacy_bak` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_executions_legacy_bak` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `seo_fraud_events`
--

DROP TABLE IF EXISTS `seo_fraud_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_fraud_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `session_id` varchar(128) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `landing_url` varchar(500) DEFAULT NULL,
  `event_type` varchar(100) NOT NULL,
  `risk_score` int(10) NOT NULL DEFAULT 0,
  `is_bot` tinyint(1) NOT NULL DEFAULT 0,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_fraud_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `seo_fraud_events` WRITE;
/*!40000 ALTER TABLE `seo_fraud_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_fraud_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `seo_keywords`
--

DROP TABLE IF EXISTS `seo_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_keywords` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(200) NOT NULL,
  `target_url` varchar(500) NOT NULL,
  `target_position` int(10) unsigned NOT NULL DEFAULT 0,
  `scroll_min_seconds` int(10) unsigned NOT NULL DEFAULT 25,
  `scroll_max_seconds` int(10) unsigned NOT NULL DEFAULT 40,
  `pause_min_seconds` int(10) unsigned NOT NULL DEFAULT 3,
  `pause_max_seconds` int(10) unsigned NOT NULL DEFAULT 8,
  `total_browse_seconds` int(10) unsigned NOT NULL DEFAULT 60,
  `reward_amount` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `currency` enum('irt','usdt') NOT NULL DEFAULT 'irt',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_keywords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `seo_keywords` WRITE;
/*!40000 ALTER TABLE `seo_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_keywords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `seo_tasks`
--

DROP TABLE IF EXISTS `seo_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creator_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `target_url` varchar(500) NOT NULL,
  `price_per_click` decimal(24,4) NOT NULL,
  `total_budget` decimal(24,4) NOT NULL,
  `remaining_budget` decimal(24,4) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deadline` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_seo_creator` (`creator_id`),
  KEY `idx_seo_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_tasks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `seo_tasks` WRITE;
/*!40000 ALTER TABLE `seo_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_tasks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) NOT NULL,
  `value` longtext DEFAULT NULL,
  `group` varchar(50) DEFAULT 'general',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'site_irt_card_number','6037991122334455','general','2026-08-06 08:36:30','2026-08-06 08:36:30',0),
(2,'site_irt_account_number','0123456789','general','2026-08-06 08:36:30','2026-08-06 08:36:30',0),
(3,'site_irt_sheba','IR120140040000012345678901','general','2026-08-06 08:36:30','2026-08-06 08:36:30',0),
(4,'site_irt_bank_name','بانک ملی ایران','general','2026-08-06 08:36:30','2026-08-06 08:36:30',0),
(5,'site_usdt_bnb20_address','0x1234567890123456789012345678901234567890','general','2026-08-06 08:36:30','2026-08-06 08:36:30',0),
(6,'site_usdt_trc20_address','T12345678901234567890123456789012','general','2026-08-06 08:36:30','2026-08-06 08:36:30',0);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `settings_audit_trail`
--

DROP TABLE IF EXISTS `settings_audit_trail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_audit_trail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `setting_key` varchar(191) NOT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_audit_trail`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `settings_audit_trail` WRITE;
/*!40000 ALTER TABLE `settings_audit_trail` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings_audit_trail` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_accounts`
--

DROP TABLE IF EXISTS `social_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `platform` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `provider_id` varchar(191) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sa_user` (`user_id`),
  CONSTRAINT `fk_social_accounts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_accounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_accounts` WRITE;
/*!40000 ALTER TABLE `social_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_accounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_ads`
--

DROP TABLE IF EXISTS `social_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `advertiser_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `platform` varchar(50) NOT NULL,
  `task_type` varchar(50) NOT NULL,
  `reward` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_slots` int(10) unsigned NOT NULL DEFAULT 0,
  `remaining_slots` int(10) unsigned NOT NULL DEFAULT 0,
  `status` enum('pending','active','paused','cancelled','rejected','completed') NOT NULL DEFAULT 'pending',
  `reject_reason` text DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_ads`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_ads` WRITE;
/*!40000 ALTER TABLE `social_ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_ads` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_camera_requests`
--

DROP TABLE IF EXISTS `social_camera_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_camera_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `camera_score` int(10) DEFAULT NULL,
  `verified_signals` longtext DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `method` varchar(50) NOT NULL DEFAULT 'mobile_camera',
  `frame_count` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_signals` longtext DEFAULT NULL,
  `raw_image_stored` tinyint(1) NOT NULL DEFAULT 0,
  `client_context` longtext DEFAULT NULL,
  `verification_score` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_camera_exec` (`execution_id`),
  KEY `idx_scr_method_status` (`method`,`status`,`expires_at`),
  CONSTRAINT `fk_camera_exec` FOREIGN KEY (`execution_id`) REFERENCES `social_task_executions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_camera_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_camera_requests` WRITE;
/*!40000 ALTER TABLE `social_camera_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_camera_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_ratings`
--

DROP TABLE IF EXISTS `social_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_ratings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `execution_id` int(10) unsigned NOT NULL,
  `rater_id` int(10) unsigned NOT NULL,
  `rated_id` int(10) unsigned NOT NULL,
  `rater_type` enum('executor','advertiser') NOT NULL,
  `stars` tinyint(3) unsigned NOT NULL,
  `comment` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'approved',
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_ratings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_ratings` WRITE;
/*!40000 ALTER TABLE `social_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_ratings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_task_analytics`
--

DROP TABLE IF EXISTS `social_task_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_task_analytics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned NOT NULL,
  `total_views` int(10) unsigned DEFAULT 0,
  `total_completions` int(10) unsigned DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ad_analytics_unique` (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_task_analytics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_task_analytics` WRITE;
/*!40000 ALTER TABLE `social_task_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_task_analytics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_task_executions`
--

DROP TABLE IF EXISTS `social_task_executions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_task_executions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(10) unsigned NOT NULL,
  `executor_id` int(10) unsigned NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `proof_url` text DEFAULT NULL,
  `proof_text` text DEFAULT NULL,
  `reward_amount` decimal(24,4) DEFAULT NULL,
  `reward_currency` varchar(10) DEFAULT 'irt',
  `idempotency_key` varchar(100) DEFAULT NULL,
  `reminder_sent` timestamp NULL DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `auto_approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `expected_time` int(10) unsigned DEFAULT 60,
  `active_time` int(10) unsigned DEFAULT 0,
  `task_score` int(10) DEFAULT NULL,
  `decision` varchar(50) DEFAULT NULL,
  `behavior_data` longtext DEFAULT NULL,
  `flag_review` tinyint(1) NOT NULL DEFAULT 0,
  `flag_note` text DEFAULT NULL,
  `anti_fraud_score` int(10) DEFAULT NULL,
  `reward_paid` tinyint(1) NOT NULL DEFAULT 0,
  `override_reason` text DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reject_reason` text DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `client_mode` varchar(50) DEFAULT NULL,
  `client_version` varchar(50) DEFAULT NULL,
  `device_context` longtext DEFAULT NULL,
  `behavior_score` decimal(5,2) DEFAULT NULL,
  `time_score` decimal(5,2) DEFAULT NULL,
  `interaction_score` decimal(5,2) DEFAULT NULL,
  `camera_score` decimal(5,2) DEFAULT NULL,
  `final_score` decimal(5,2) DEFAULT NULL,
  `score_breakdown` longtext DEFAULT NULL,
  `verification_required` tinyint(1) NOT NULL DEFAULT 0,
  `verification_method` varchar(50) DEFAULT NULL,
  `verification_requested_at` timestamp NULL DEFAULT NULL,
  `verification_completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `idx_ste_ad` (`ad_id`),
  KEY `idx_ste_user` (`executor_id`),
  KEY `idx_ste_status_updated` (`status`,`updated_at`),
  KEY `idx_ste_executor_type_time` (`executor_id`,`created_at`),
  KEY `idx_ste_mobile_scoring` (`status`,`final_score`,`verification_required`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_task_executions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_task_executions` WRITE;
/*!40000 ALTER TABLE `social_task_executions` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_task_executions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_task_settings`
--

DROP TABLE IF EXISTS `social_task_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_task_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key_name` varchar(100) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `median_reward` decimal(12,2) NOT NULL DEFAULT 0.00,
  `min_reward` decimal(12,2) DEFAULT NULL,
  `max_reward` decimal(12,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_task_settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_task_settings` WRITE;
/*!40000 ALTER TABLE `social_task_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_task_settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_tasks`
--

DROP TABLE IF EXISTS `social_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creator_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `platform` enum('instagram','telegram','youtube','twitter','tiktok','aparat','linkedin','other') NOT NULL,
  `task_type` varchar(100) DEFAULT NULL,
  `target_url` varchar(500) NOT NULL,
  `price_per_task` decimal(24,4) NOT NULL,
  `total_budget` decimal(24,4) NOT NULL,
  `remaining_budget` decimal(24,4) NOT NULL,
  `total_count` int(10) unsigned NOT NULL,
  `remaining_count` int(10) unsigned NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_st_creator` (`creator_id`),
  KEY `idx_st_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_tasks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_tasks` WRITE;
/*!40000 ALTER TABLE `social_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_tasks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `social_user_trust`
--

DROP TABLE IF EXISTS `social_user_trust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_user_trust` (
  `user_id` int(10) unsigned NOT NULL,
  `trust_score` decimal(5,2) NOT NULL DEFAULT 50.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_user_trust`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `social_user_trust` WRITE;
/*!40000 ALTER TABLE `social_user_trust` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_user_trust` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `startup_banners`
--

DROP TABLE IF EXISTS `startup_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `startup_banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(500) NOT NULL,
  `link_url` varchar(500) DEFAULT NULL,
  `duration_days` int(10) unsigned NOT NULL DEFAULT 7,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `views` int(10) unsigned NOT NULL DEFAULT 0,
  `clicks` int(10) unsigned NOT NULL DEFAULT 0,
  `status` enum('pending','active','paused','rejected','expired') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `startup_banners`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `startup_banners` WRITE;
/*!40000 ALTER TABLE `startup_banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `startup_banners` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `story_orders`
--

DROP TABLE IF EXISTS `story_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `story_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `influencer_id` int(10) unsigned NOT NULL,
  `influencer_user_id` int(10) unsigned NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `price` decimal(24,4) NOT NULL,
  `currency` varchar(10) DEFAULT 'irt',
  `verification_code` varchar(50) DEFAULT NULL,
  `idempotency_key` varchar(128) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_type` varchar(50) DEFAULT 'story',
  `duration_hours` int(10) unsigned DEFAULT 24,
  `media_path` varchar(255) DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `link` varchar(2048) DEFAULT NULL,
  `preferred_publish_time` varchar(100) DEFAULT NULL,
  `site_fee_percent` decimal(5,2) DEFAULT 15.00,
  `site_fee_amount` decimal(24,4) DEFAULT 0.0000,
  `influencer_earning` decimal(24,4) DEFAULT 0.0000,
  `payment_transaction_id` varchar(100) DEFAULT NULL,
  `payout_transaction_id` varchar(100) DEFAULT NULL,
  `peer_resolution_started_at` timestamp NULL DEFAULT NULL,
  `proof_screenshot` varchar(255) DEFAULT NULL,
  `proof_link` varchar(2048) DEFAULT NULL,
  `proof_notes` text DEFAULT NULL,
  `proof_submitted_at` timestamp NULL DEFAULT NULL,
  `buyer_check_notified_at` timestamp NULL DEFAULT NULL,
  `buyer_check_deadline` timestamp NULL DEFAULT NULL,
  `buyer_confirmed_at` timestamp NULL DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `actual_publish_time` timestamp NULL DEFAULT NULL,
  `proof_video` varchar(255) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `customer_rating` tinyint(4) DEFAULT NULL,
  `customer_review` text DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `idx_so_customer` (`customer_id`),
  KEY `idx_so_influencer` (`influencer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `story_orders`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `story_orders` WRITE;
/*!40000 ALTER TABLE `story_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `story_orders` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_alerts`
--

DROP TABLE IF EXISTS `system_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_alerts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alert_type` varchar(50) NOT NULL COMMENT 'security, performance, financial',
  `severity` enum('low','medium','high','critical') DEFAULT 'medium',
  `title` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `fingerprint` varchar(64) DEFAULT NULL,
  `event_id` varchar(64) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `is_sent` tinyint(1) DEFAULT 0,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_alert_severity` (`severity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_alerts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_alerts` WRITE;
/*!40000 ALTER TABLE `system_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_alerts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(20) DEFAULT NULL,
  `channel` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_maintenance_log`
--

DROP TABLE IF EXISTS `system_maintenance_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_maintenance_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `performed_by` int(10) unsigned DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_maintenance_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_maintenance_log` WRITE;
/*!40000 ALTER TABLE `system_maintenance_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_maintenance_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) NOT NULL,
  `value` longtext DEFAULT NULL,
  `group` varchar(50) DEFAULT 'general',
  `type` varchar(20) DEFAULT 'string',
  `description` text DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES
(1,'site_irt_card_number','6037991122334455','general','string',NULL,0,'2026-08-06 08:36:30','2026-08-06 08:36:30'),
(2,'site_irt_account_number','0123456789','general','string',NULL,0,'2026-08-06 08:36:30','2026-08-06 08:36:30'),
(3,'site_irt_sheba','IR120140040000012345678901','general','string',NULL,0,'2026-08-06 08:36:30','2026-08-06 08:36:30'),
(4,'site_irt_bank_name','بانک ملی ایران','general','string',NULL,0,'2026-08-06 08:36:30','2026-08-06 08:36:30'),
(5,'site_usdt_bnb20_address','0x1234567890123456789012345678901234567890','general','string',NULL,0,'2026-08-06 08:36:30','2026-08-06 08:36:30'),
(6,'site_usdt_trc20_address','T12345678901234567890123456789012','general','string',NULL,0,'2026-08-06 08:36:30','2026-08-06 08:36:30'),
(7,'app.name','Chortke','app','string','app.name',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(8,'app.timezone','Asia/Tehran','app','string','app.timezone',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(9,'session.lifetime','1800','session','int','session.lifetime',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(10,'currency.default','IRT','currency','string','currency.default',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(11,'payment.min_deposit','10000','payment','int','payment.min_deposit',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(12,'payment.max_withdrawal_daily','50000000','payment','int','payment.max_withdrawal_daily',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(13,'prediction_rollover_reserve_usdt','0','prediction','numeric','ذخیره انتقالی پیش‌بینی‌ها برای بازی‌های بعدی در حالت بدون برنده',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(14,'prediction_no_winner_rollover_percent','50','prediction','numeric','درصد انتقال به چرخه بعدی وقتی هیچ برنده‌ای وجود ندارد',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(15,'prediction_no_winner_site_percent','50','prediction','numeric','درصد سهم سایت وقتی هیچ برنده‌ای وجود ندارد',0,'2026-08-06 08:36:31','2026-08-06 08:36:31'),
(16,'referral_content_approval_amount','5000','referral','string',NULL,0,'2026-08-06 08:36:32','2026-08-06 08:36:32'),
(17,'referral_content_approval_currency','irt','referral','string',NULL,0,'2026-08-06 08:36:32','2026-08-06 08:36:32'),
(18,'referral_commission_percent','5','referral','string',NULL,0,'2026-08-06 08:36:32','2026-08-06 08:36:32'),
(19,'referral_daily_limit','50','referral','string',NULL,0,'2026-08-06 08:36:32','2026-08-06 08:36:32'),
(20,'referral_signup_bonus','1000','referral','string',NULL,0,'2026-08-06 08:36:32','2026-08-06 08:36:32'),
(21,'referral_signup_bonus_usdt','0','referral','string',NULL,0,'2026-08-06 08:36:32','2026-08-06 08:36:32');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_telemetry`
--

DROP TABLE IF EXISTS `system_telemetry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_telemetry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `metric_name` varchar(100) DEFAULT NULL,
  `metric_value` decimal(24,8) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_telemetry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_telemetry` WRITE;
/*!40000 ALTER TABLE `system_telemetry` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_telemetry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `talent_contents`
--

DROP TABLE IF EXISTS `talent_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `talent_contents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'submitted',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `talent_contents`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `talent_contents` WRITE;
/*!40000 ALTER TABLE `talent_contents` DISABLE KEYS */;
/*!40000 ALTER TABLE `talent_contents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `talent_profiles`
--

DROP TABLE IF EXISTS `talent_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `talent_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `expertise` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tp_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `talent_profiles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `talent_profiles` WRITE;
/*!40000 ALTER TABLE `talent_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `talent_profiles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `task_analytics`
--

DROP TABLE IF EXISTS `task_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_analytics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `views` int(10) unsigned DEFAULT 0,
  `completions` int(10) unsigned DEFAULT 0,
  `last_activity_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_analytics`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `task_analytics` WRITE;
/*!40000 ALTER TABLE `task_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_analytics` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `task_executions`
--

DROP TABLE IF EXISTS `task_executions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_executions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `advertisement_id` int(10) unsigned NOT NULL,
  `executor_id` int(10) unsigned NOT NULL,
  `executor_social_account_id` int(10) unsigned DEFAULT NULL,
  `reward_amount` decimal(24,4) NOT NULL,
  `reward_currency` enum('irt','usdt') NOT NULL DEFAULT 'irt',
  `idempotency_key` varchar(100) NOT NULL,
  `status` enum('started','submitted','approved','rejected','expired','disputed','cancelled') NOT NULL DEFAULT 'started',
  `proof_image` varchar(500) DEFAULT NULL,
  `proof_text` text DEFAULT NULL,
  `reward_transaction_id` varchar(64) DEFAULT NULL,
  `reviewed_by` int(10) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_executions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `task_executions` WRITE;
/*!40000 ALTER TABLE `task_executions` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_executions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `task_favorites`
--

DROP TABLE IF EXISTS `task_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_favorites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_task` (`user_id`,`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_favorites`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `task_favorites` WRITE;
/*!40000 ALTER TABLE `task_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_favorites` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `task_ratings`
--

DROP TABLE IF EXISTS `task_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_ratings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_task_rating_ad` (`task_id`),
  CONSTRAINT `fk_task_rating_ad` FOREIGN KEY (`task_id`) REFERENCES `ads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_ratings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `task_ratings` WRITE;
/*!40000 ALTER TABLE `task_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_ratings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `task_rechecks`
--

DROP TABLE IF EXISTS `task_rechecks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_rechecks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `original_execution_id` int(10) unsigned NOT NULL,
  `advertisement_id` int(10) unsigned NOT NULL,
  `executor_id` int(10) unsigned NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `penalty_amount` decimal(24,4) NOT NULL DEFAULT 0.0000,
  `penalty_currency` enum('irt','usdt') NOT NULL DEFAULT 'irt',
  `refunded_to_advertiser` tinyint(1) NOT NULL DEFAULT 0,
  `checked_at` timestamp NULL DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_rechecks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `task_rechecks` WRITE;
/*!40000 ALTER TABLE `task_rechecks` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_rechecks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `task_reports`
--

DROP TABLE IF EXISTS `task_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `reporter_id` int(10) unsigned NOT NULL,
  `reason` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `admin_id` int(10) unsigned DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_task_reports_task` (`task_id`),
  KEY `idx_task_reports_reporter` (`reporter_id`),
  KEY `idx_task_reports_status` (`status`),
  KEY `idx_task_reports_reason` (`reason`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_reports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `task_reports` WRITE;
/*!40000 ALTER TABLE `task_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Temporary table structure for view `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!50001 DROP VIEW IF EXISTS `tasks`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tasks` AS SELECT
 1 AS `id`,
  1 AS `creator_id`,
  1 AS `title`,
  1 AS `description`,
  1 AS `type`,
  1 AS `status`,
  1 AS `completed_at`,
  1 AS `link`,
  1 AS `amount`,
  1 AS `platform`,
  1 AS `deleted_at` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `ticket_assignment_history`
--

DROP TABLE IF EXISTS `ticket_assignment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_assignment_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(10) unsigned NOT NULL,
  `old_admin_id` int(10) unsigned DEFAULT NULL,
  `new_admin_id` int(10) unsigned DEFAULT NULL,
  `changed_by` int(10) unsigned NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_assignment_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ticket_assignment_history` WRITE;
/*!40000 ALTER TABLE `ticket_assignment_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_assignment_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ticket_categories`
--

DROP TABLE IF EXISTS `ticket_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `icon` varchar(50) DEFAULT 'support_agent',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ticket_categories` WRITE;
/*!40000 ALTER TABLE `ticket_categories` DISABLE KEYS */;
INSERT INTO `ticket_categories` VALUES
(1,'پشتیبانی فنی','technical',1,'support_agent'),
(2,'مالی','billing',1,'payments'),
(3,'حساب کاربری','account',1,'person'),
(4,'سایر موارد','other',1,'help');
/*!40000 ALTER TABLE `ticket_categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ticket_messages`
--

DROP TABLE IF EXISTS `ticket_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message` text NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attachments`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tm_ticket` (`ticket_id`),
  KEY `idx_ticket_messages_read` (`ticket_id`,`is_admin`,`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ticket_messages` WRITE;
/*!40000 ALTER TABLE `ticket_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ticket_status_history`
--

DROP TABLE IF EXISTS `ticket_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_status_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(10) unsigned NOT NULL,
  `old_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL,
  `changed_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_status_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ticket_status_history` WRITE;
/*!40000 ALTER TABLE `ticket_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_status_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `ticket_id` varchar(20) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `priority` enum('low','normal','medium','high','urgent','critical') DEFAULT 'normal',
  `status` enum('open','pending','replied','answered','in_progress','on_hold','closed') NOT NULL DEFAULT 'open',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_reply_by` varchar(50) DEFAULT 'user',
  `last_reply_at` timestamp NULL DEFAULT current_timestamp(),
  `closed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_id` (`ticket_id`),
  KEY `idx_tk_user` (`user_id`),
  KEY `idx_tickets_category` (`category_id`),
  KEY `idx_tickets_status_updated` (`status`,`updated_at`),
  KEY `idx_tickets_assigned_to` (`assigned_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tor_exit_nodes`
--

DROP TABLE IF EXISTS `tor_exit_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tor_exit_nodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `last_verified` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tor_exit_nodes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tor_exit_nodes` WRITE;
/*!40000 ALTER TABLE `tor_exit_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tor_exit_nodes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `trading_records`
--

DROP TABLE IF EXISTS `trading_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trading_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `admin_id` int(10) unsigned DEFAULT NULL,
  `investment_id` int(10) unsigned DEFAULT NULL,
  `symbol` varchar(20) DEFAULT NULL,
  `pair` varchar(20) DEFAULT NULL,
  `type` enum('buy','sell') DEFAULT NULL,
  `direction` enum('buy','sell') DEFAULT NULL,
  `amount` decimal(24,8) DEFAULT NULL,
  `price` decimal(24,8) DEFAULT NULL,
  `open_price` decimal(24,8) DEFAULT NULL,
  `close_price` decimal(24,8) DEFAULT NULL,
  `stop_loss` decimal(24,8) DEFAULT NULL,
  `take_profit` decimal(24,8) DEFAULT NULL,
  `profit_loss` decimal(24,8) DEFAULT NULL,
  `profit_loss_amount` decimal(24,8) NOT NULL DEFAULT 0.00000000,
  `profit_loss_percent` decimal(10,4) DEFAULT 0.0000,
  `currency` varchar(10) DEFAULT 'usdt',
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(50) DEFAULT 'open',
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `open_time` timestamp NULL DEFAULT current_timestamp(),
  `close_time` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_trade_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trading_records`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `trading_records` WRITE;
/*!40000 ALTER TABLE `trading_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `trading_records` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `transaction_events`
--

DROP TABLE IF EXISTS `transaction_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(64) NOT NULL,
  `event_type` varchar(80) NOT NULL,
  `previous_status` varchar(30) DEFAULT NULL,
  `new_status` varchar(30) NOT NULL,
  `reason` text DEFAULT NULL,
  `changed_by` int(10) unsigned DEFAULT NULL,
  `metadata` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_transaction_events_tx` (`transaction_id`),
  KEY `idx_transaction_events_status` (`new_status`),
  KEY `idx_transaction_events_created` (`created_at`),
  CONSTRAINT `fk_te_tx` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`transaction_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `transaction_events` WRITE;
/*!40000 ALTER TABLE `transaction_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `transaction_queries`
--

DROP TABLE IF EXISTS `transaction_queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_queries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `query_hash` varchar(64) DEFAULT NULL,
  `results_count` int(10) unsigned DEFAULT NULL,
  `execution_time_ms` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_queries`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `transaction_queries` WRITE;
/*!40000 ALTER TABLE `transaction_queries` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_queries` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(64) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `currency` enum('irt','usdt') DEFAULT 'irt',
  `amount` decimal(24,8) NOT NULL,
  `balance_before` decimal(24,8) DEFAULT NULL,
  `balance_after` decimal(24,8) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `description` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `gateway` varchar(50) DEFAULT NULL,
  `gateway_transaction_id` varchar(128) DEFAULT NULL,
  `ref_id` varchar(128) DEFAULT NULL,
  `ref_type` varchar(100) DEFAULT NULL,
  `request_id` varchar(64) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `device_fingerprint` varchar(128) DEFAULT NULL,
  `idempotency_key` varchar(128) DEFAULT NULL,
  `reference_id` varchar(100) DEFAULT NULL,
  `reference_type` varchar(80) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `external_id` varchar(128) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `idx_tx_user` (`user_id`),
  KEY `idx_tx_type` (`type`),
  KEY `idx_tx_status` (`status`),
  KEY `idx_tx_created_at` (`created_at`),
  CONSTRAINT `fk_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `transactions_archive`
--

DROP TABLE IF EXISTS `transactions_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions_archive` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(64) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `amount` decimal(24,8) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `idempotency_key` varchar(128) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `device_fingerprint` varchar(128) DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions_archive`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `transactions_archive` WRITE;
/*!40000 ALTER TABLE `transactions_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions_archive` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `trusted_devices`
--

DROP TABLE IF EXISTS `trusted_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trusted_devices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `fingerprint` varchar(128) NOT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_device` (`user_id`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trusted_devices`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `trusted_devices` WRITE;
/*!40000 ALTER TABLE `trusted_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `trusted_devices` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `two_factor_codes`
--

DROP TABLE IF EXISTS `two_factor_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `code` varchar(255) NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_2fa_user_active` (`user_id`,`used`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor_codes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `two_factor_codes` WRITE;
/*!40000 ALTER TABLE `two_factor_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor_codes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_banner_requests`
--

DROP TABLE IF EXISTS `user_banner_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_banner_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `placement_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `image_path` varchar(500) DEFAULT NULL,
  `link_url` varchar(500) DEFAULT NULL,
  `days` int(10) unsigned NOT NULL DEFAULT 1,
  `total_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','active','rejected','cancelled','expired') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_banner_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_banner_requests` WRITE;
/*!40000 ALTER TABLE `user_banner_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_banner_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_blocks`
--

DROP TABLE IF EXISTS `user_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_blocks` (
  `blocker_id` int(10) unsigned NOT NULL,
  `blocked_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`blocker_id`,`blocked_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_blocks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_blocks` WRITE;
/*!40000 ALTER TABLE `user_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_blocks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_conversations`
--

DROP TABLE IF EXISTS `user_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_conversations` (
  `user1_id` int(10) unsigned NOT NULL,
  `user2_id` int(10) unsigned NOT NULL,
  `last_message_id` int(10) unsigned NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user1_id`,`user2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_conversations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_conversations` WRITE;
/*!40000 ALTER TABLE `user_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_conversations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_devices`
--

DROP TABLE IF EXISTS `user_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_devices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `fcm_token` text NOT NULL,
  `platform` varchar(20) DEFAULT 'web',
  `last_activity` timestamp NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_devices`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_devices` WRITE;
/*!40000 ALTER TABLE `user_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_devices` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_fingerprints`
--

DROP TABLE IF EXISTS `user_fingerprints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_fingerprints` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `fingerprint` varchar(64) NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `seen_count` int(10) DEFAULT 1,
  `last_seen` timestamp NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_fingerprints`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_fingerprints` WRITE;
/*!40000 ALTER TABLE `user_fingerprints` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_fingerprints` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_flags`
--

DROP TABLE IF EXISTS `user_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_flags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `requires_review` tinyint(1) NOT NULL DEFAULT 0,
  `requires_kyc` tinyint(1) NOT NULL DEFAULT 0,
  `requires_manual_review` tinyint(1) NOT NULL DEFAULT 0,
  `is_blacklisted` tinyint(1) NOT NULL DEFAULT 0,
  `blacklist_reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_flags_user` (`user_id`),
  KEY `idx_user_flags_review` (`requires_review`,`requires_manual_review`),
  KEY `idx_user_flags_blacklisted` (`is_blacklisted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_flags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_flags` WRITE;
/*!40000 ALTER TABLE `user_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_flags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_fraud_flags`
--

DROP TABLE IF EXISTS `user_fraud_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_fraud_flags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `flag_type` varchar(100) DEFAULT NULL,
  `severity` int(10) DEFAULT 1,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_uff_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_fraud_flags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_fraud_flags` WRITE;
/*!40000 ALTER TABLE `user_fraud_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_fraud_flags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_fraud_scores`
--

DROP TABLE IF EXISTS `user_fraud_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_fraud_scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `category` varchar(50) NOT NULL COMMENT 'velocity, proxy, behavior',
  `score_delta` decimal(10,2) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ufs_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_fraud_scores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_fraud_scores` WRITE;
/*!40000 ALTER TABLE `user_fraud_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_fraud_scores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_interactions`
--

DROP TABLE IF EXISTS `user_interactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_interactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `target_id` int(10) unsigned DEFAULT NULL,
  `interaction_type` varchar(50) DEFAULT NULL COMMENT 'click, view, hover',
  `duration_seconds` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_interactions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_interactions` WRITE;
/*!40000 ALTER TABLE `user_interactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_interactions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_level_history`
--

DROP TABLE IF EXISTS `user_level_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_level_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `from_level` varchar(50) DEFAULT NULL,
  `to_level` varchar(50) NOT NULL,
  `change_type` varchar(50) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_level_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_level_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_level_history` WRITE;
/*!40000 ALTER TABLE `user_level_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_level_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_level_purchases`
--

DROP TABLE IF EXISTS `user_level_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_level_purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `level_slug` varchar(60) NOT NULL,
  `amount` decimal(24,4) NOT NULL,
  `currency` enum('irt','usdt') NOT NULL DEFAULT 'irt',
  `duration_days` int(10) unsigned NOT NULL DEFAULT 30,
  `status` enum('active','expired','cancelled') NOT NULL DEFAULT 'active',
  `transaction_id` varchar(64) DEFAULT NULL,
  `idempotency_key` varchar(100) NOT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_level_purchases`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_level_purchases` WRITE;
/*!40000 ALTER TABLE `user_level_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_level_purchases` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_levels`
--

DROP TABLE IF EXISTS `user_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_levels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `sort_order` int(10) DEFAULT 0,
  `min_score` decimal(24,4) DEFAULT 0.0000,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_levels`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_levels` WRITE;
/*!40000 ALTER TABLE `user_levels` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_levels` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_oauth`
--

DROP TABLE IF EXISTS `user_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_oauth` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `provider` varchar(50) NOT NULL,
  `provider_user_id` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_oauth_provider` (`provider`,`provider_user_id`),
  KEY `idx_oauth_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_oauth`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_oauth` WRITE;
/*!40000 ALTER TABLE `user_oauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_oauth` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_ur_role` (`role_id`),
  CONSTRAINT `fk_ur_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ur_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES
(1,1),
(3,2),
(4,3),
(2,5);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_score_adjustments`
--

DROP TABLE IF EXISTS `user_score_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_score_adjustments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `score_adjustment` decimal(10,2) NOT NULL,
  `operation` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `domain` varchar(32) NOT NULL DEFAULT 'fraud',
  `status` enum('active','revoked') NOT NULL DEFAULT 'active',
  `expires_at` datetime DEFAULT NULL,
  `revoked_by` int(10) unsigned DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `revoked_reason` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_score_adjustments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_score_adjustments` WRITE;
/*!40000 ALTER TABLE `user_score_adjustments` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_score_adjustments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_score_events`
--

DROP TABLE IF EXISTS `user_score_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_score_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `domain` varchar(32) NOT NULL,
  `source` varchar(64) NOT NULL,
  `delta` decimal(24,4) NOT NULL DEFAULT 0.0000,
  `meta_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta_json`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_score_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_score_events` WRITE;
/*!40000 ALTER TABLE `user_score_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_score_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_scores`
--

DROP TABLE IF EXISTS `user_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `domain` varchar(100) NOT NULL,
  `score` decimal(24,4) NOT NULL DEFAULT 0.0000,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_scores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_scores` WRITE;
/*!40000 ALTER TABLE `user_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_scores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `session_id` varchar(191) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `browser` varchar(50) DEFAULT NULL,
  `os` varchar(50) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `fingerprint` varchar(128) DEFAULT NULL,
  `last_activity` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `device_fingerprint` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `idx_session_user` (`user_id`),
  KEY `idx_session_active` (`is_active`),
  KEY `idx_user_sessions_device_fp` (`user_id`,`device_fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `setting_key` varchar(191) DEFAULT NULL,
  `setting_value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `us_unique` (`user_id`,`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_settings` WRITE;
/*!40000 ALTER TABLE `user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_social_accounts`
--

DROP TABLE IF EXISTS `user_social_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_social_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `platform` enum('instagram','telegram','youtube','twitter','tiktok','aparat','linkedin','other') NOT NULL,
  `username` varchar(100) NOT NULL,
  `profile_url` varchar(500) DEFAULT NULL,
  `follower_count` int(10) unsigned NOT NULL DEFAULT 0,
  `status` enum('pending','verified','rejected','inactive') NOT NULL DEFAULT 'pending',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_social_user` (`user_id`),
  CONSTRAINT `fk_social_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_social_accounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_social_accounts` WRITE;
/*!40000 ALTER TABLE `user_social_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_social_accounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_ticket_scores`
--

DROP TABLE IF EXISTS `user_ticket_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_ticket_scores` (
  `user_id` int(10) unsigned NOT NULL,
  `score` int(10) NOT NULL DEFAULT 100,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_ticket_scores`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_ticket_scores` WRITE;
/*!40000 ALTER TABLE `user_ticket_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_ticket_scores` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_typing_patterns`
--

DROP TABLE IF EXISTS `user_typing_patterns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_typing_patterns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `avg_interval` decimal(12,4) NOT NULL,
  `stddev_interval` decimal(12,4) NOT NULL,
  `avg_hold_time` decimal(12,4) NOT NULL,
  `keystroke_count` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_typing_patterns_user_created` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_typing_patterns`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_typing_patterns` WRITE;
/*!40000 ALTER TABLE `user_typing_patterns` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_typing_patterns` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_vacations`
--

DROP TABLE IF EXISTS `user_vacations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_vacations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `duration_days` int(10) unsigned DEFAULT 3,
  `cost_paid` decimal(24,8) DEFAULT 0.00000000,
  `status` varchar(50) DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_vacations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_vacations` WRITE;
/*!40000 ALTER TABLE `user_vacations` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_vacations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user_verifications`
--

DROP TABLE IF EXISTS `user_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_verifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` enum('email','mobile','identity') NOT NULL,
  `token` varchar(128) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_uv_token` (`token`),
  KEY `idx_uv_user` (`user_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_verifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user_verifications` WRITE;
/*!40000 ALTER TABLE `user_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_verifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `national_id` varchar(20) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `oauth_only` tinyint(1) DEFAULT 0,
  `role` enum('user','admin','super_admin','support') DEFAULT 'user',
  `role_id` int(10) unsigned DEFAULT NULL,
  `status` enum('active','inactive','suspended','locked','locked_2fa','banned','deleted') DEFAULT 'active',
  `is_admin` tinyint(1) DEFAULT 0,
  `two_factor_enabled` tinyint(1) DEFAULT 0,
  `two_factor_method` varchar(50) DEFAULT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `last_2fa_timeslice` bigint(20) unsigned DEFAULT NULL,
  `referral_code` varchar(20) DEFAULT NULL,
  `referred_by` int(10) unsigned DEFAULT NULL,
  `referral_quality_score` decimal(5,2) NOT NULL DEFAULT 85.00,
  `email_verification_token` varchar(128) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `mobile_verified_at` timestamp NULL DEFAULT NULL,
  `country_code` char(2) DEFAULT 'IR',
  `country_name` varchar(100) DEFAULT 'Iran',
  `avatar` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT 'Asia/Tehran',
  `fraud_score` int(11) DEFAULT 0,
  `device_fingerprint` varchar(64) DEFAULT NULL,
  `active_days_count` int(10) DEFAULT 0,
  `is_blacklisted` tinyint(1) DEFAULT 0,
  `blacklist_reason` text DEFAULT NULL,
  `blacklisted_at` datetime DEFAULT NULL,
  `level_slug` varchar(60) DEFAULT 'silver',
  `level_type` enum('auto','purchased') DEFAULT 'auto',
  `remember_token` varchar(100) DEFAULT NULL,
  `remember_expires_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT NULL,
  `last_user_agent` text DEFAULT NULL,
  `last_active_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `account_deletion_requested_at` datetime DEFAULT NULL,
  `account_deletion_expires_at` datetime DEFAULT NULL,
  `kyc_status` varchar(50) DEFAULT 'unverified',
  `tier` varchar(50) DEFAULT 'SILVER',
  `kyc_level` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT 'KYC tier: 0=unverified, 1=basic, 2=full, 3=enhanced',
  `kyc_verified_at` timestamp NULL DEFAULT NULL COMMENT 'Set by KYCListener on kyc.approved events.',
  `level_expires_at` timestamp NULL DEFAULT NULL COMMENT 'When a purchased level expires (NULL = no expiry).',
  `monthly_active_days` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Cumulative active-day counter, reset monthly by ChangeUserLevelJob.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `mobile` (`mobile`),
  UNIQUE KEY `referral_code` (`referral_code`),
  KEY `idx_user_email` (`email`),
  KEY `idx_user_mobile` (`mobile`),
  KEY `idx_user_status` (`status`),
  KEY `idx_user_referral` (`referral_code`),
  KEY `idx_users_kyc_level` (`kyc_level`),
  KEY `idx_users_level_expires_at` (`level_expires_at`),
  KEY `idx_users_national_id` (`national_id`),
  KEY `idx_users_account_deletion_expires` (`account_deletion_expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'seed_user','user@chortke.ir',NULL,NULL,NULL,NULL,NULL,'کاربر تست','$2y$12$fYnKk0PCvuYuZTr4l0.dcOhPz1a2bZ0.7X.LcF845rOXsl6SGk9de',0,'user',1,'active',0,0,NULL,NULL,NULL,NULL,NULL,85.00,NULL,'2026-08-06 08:36:32',NULL,'IR','Iran',NULL,NULL,NULL,NULL,'Asia/Tehran',0,NULL,0,0,NULL,NULL,'silver','auto',NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-06 08:36:32','2026-08-06 08:36:32',NULL,NULL,NULL,'unverified','SILVER',0,NULL,NULL,0),
(2,'seed_support','support@chortke.ir',NULL,NULL,NULL,NULL,NULL,'پشتیبان تست','$2y$12$fYnKk0PCvuYuZTr4l0.dcOhPz1a2bZ0.7X.LcF845rOXsl6SGk9de',0,'support',5,'active',1,0,NULL,NULL,NULL,NULL,NULL,85.00,NULL,'2026-08-06 08:36:32',NULL,'IR','Iran',NULL,NULL,NULL,NULL,'Asia/Tehran',0,NULL,0,0,NULL,NULL,'silver','auto',NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-06 08:36:32','2026-08-06 08:36:32',NULL,NULL,NULL,'verified','SILVER',0,NULL,NULL,0),
(3,'seed_admin','admin@chortke.ir',NULL,NULL,NULL,NULL,NULL,'مدیر تست','$2y$12$fYnKk0PCvuYuZTr4l0.dcOhPz1a2bZ0.7X.LcF845rOXsl6SGk9de',0,'admin',2,'active',1,0,NULL,NULL,NULL,NULL,NULL,85.00,NULL,'2026-08-06 08:36:32',NULL,'IR','Iran',NULL,NULL,NULL,NULL,'Asia/Tehran',0,NULL,0,0,NULL,NULL,'silver','auto',NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-06 08:36:32','2026-08-06 08:36:32',NULL,NULL,NULL,'verified','SILVER',0,NULL,NULL,0),
(4,'seed_superadmin','superadmin@chortke.ir',NULL,NULL,NULL,NULL,NULL,'مدیر ارشد تست','$2y$12$fYnKk0PCvuYuZTr4l0.dcOhPz1a2bZ0.7X.LcF845rOXsl6SGk9de',0,'super_admin',3,'active',1,0,NULL,NULL,NULL,NULL,NULL,85.00,NULL,'2026-08-06 08:36:32',NULL,'IR','Iran',NULL,NULL,NULL,NULL,'Asia/Tehran',0,NULL,0,0,NULL,NULL,'silver','auto',NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-06 08:36:32','2026-08-06 08:36:32',NULL,NULL,NULL,'verified','SILVER',0,NULL,NULL,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Temporary table structure for view `v_fraud_correlation_analysis`
--

DROP TABLE IF EXISTS `v_fraud_correlation_analysis`;
/*!50001 DROP VIEW IF EXISTS `v_fraud_correlation_analysis`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_fraud_correlation_analysis` AS SELECT
 1 AS `user_a`,
  1 AS `user_b`,
  1 AS `fingerprint`,
  1 AS `ip_address`,
  1 AS `name_a`,
  1 AS `name_b` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_high_risk_users`
--

DROP TABLE IF EXISTS `v_high_risk_users`;
/*!50001 DROP VIEW IF EXISTS `v_high_risk_users`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_high_risk_users` AS SELECT
 1 AS `id`,
  1 AS `full_name`,
  1 AS `email`,
  1 AS `fraud_score`,
  1 AS `is_blacklisted`,
  1 AS `fraud_incidents`,
  1 AS `last_fraud_incident` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_today_suspicious_activities`
--

DROP TABLE IF EXISTS `v_today_suspicious_activities`;
/*!50001 DROP VIEW IF EXISTS `v_today_suspicious_activities`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `v_today_suspicious_activities` AS SELECT
 1 AS `id`,
  1 AS `user_id`,
  1 AS `session_id`,
  1 AS `fraud_type`,
  1 AS `risk_score`,
  1 AS `details`,
  1 AS `action_taken`,
  1 AS `ip_address`,
  1 AS `user_agent`,
  1 AS `created_at`,
  1 AS `full_name`,
  1 AS `email`,
  1 AS `fraud_score` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `velocity_limits`
--

DROP TABLE IF EXISTS `velocity_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `velocity_limits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(191) NOT NULL COMMENT 'ip, user_id, fingerprint',
  `action` varchar(100) NOT NULL,
  `hit_count` int(10) unsigned DEFAULT 1,
  `decay_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `velocity_unique` (`identifier`,`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `velocity_limits`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `velocity_limits` WRITE;
/*!40000 ALTER TABLE `velocity_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `velocity_limits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `video_fingerprints`
--

DROP TABLE IF EXISTS `video_fingerprints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_fingerprints` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(50) NOT NULL,
  `video_id` varchar(255) NOT NULL,
  `url_hash` char(64) NOT NULL,
  `metadata_hash` char(64) DEFAULT NULL,
  `combined_hash` char(64) NOT NULL,
  `method` varchar(50) NOT NULL DEFAULT 'url_hash',
  `confidence` decimal(3,2) NOT NULL DEFAULT 0.50,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_combined` (`combined_hash`),
  KEY `idx_v_platform_video` (`platform`,`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_fingerprints`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `video_fingerprints` WRITE;
/*!40000 ALTER TABLE `video_fingerprints` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_fingerprints` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `vitrine_category_alerts`
--

DROP TABLE IF EXISTS `vitrine_category_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vitrine_category_alerts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `category` varchar(50) NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vitrine_category_alerts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `vitrine_category_alerts` WRITE;
/*!40000 ALTER TABLE `vitrine_category_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `vitrine_category_alerts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `vitrine_listings`
--

DROP TABLE IF EXISTS `vitrine_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vitrine_listings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `price` decimal(24,8) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `platform` varchar(100) DEFAULT NULL,
  `type` varchar(50) DEFAULT 'sell',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `escrow_hold_id` varchar(100) DEFAULT NULL,
  `escrow_status` varchar(50) DEFAULT NULL,
  `buyer_id` int(10) unsigned DEFAULT NULL,
  `bought_at` timestamp NULL DEFAULT NULL,
  `seller_id` int(10) unsigned DEFAULT NULL,
  `price_usdt` decimal(24,4) DEFAULT 100.0000,
  `member_count` int(10) unsigned DEFAULT 50000,
  `listing_type` varchar(50) DEFAULT 'sell',
  `specs` text DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `creation_date` varchar(100) DEFAULT NULL,
  `min_price_usdt` decimal(24,4) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `admin_note` text DEFAULT NULL,
  `escrow_locked_at` timestamp NULL DEFAULT NULL,
  `escrow_deadline` timestamp NULL DEFAULT NULL,
  `seller_info_sent` tinyint(1) NOT NULL DEFAULT 0,
  `auto_confirmed` tinyint(1) NOT NULL DEFAULT 0,
  `offer_price_usdt` decimal(24,4) DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `hold_amount` decimal(24,4) NOT NULL DEFAULT 0.0000,
  `currency` varchar(10) NOT NULL DEFAULT 'usdt',
  `hold_released` tinyint(1) NOT NULL DEFAULT 0,
  `hold_released_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vitrine_listings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `vitrine_listings` WRITE;
/*!40000 ALTER TABLE `vitrine_listings` DISABLE KEYS */;
/*!40000 ALTER TABLE `vitrine_listings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `vitrine_requests`
--

DROP TABLE IF EXISTS `vitrine_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vitrine_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `listing_id` int(10) unsigned NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `requester_id` int(10) unsigned DEFAULT NULL,
  `offer_price` decimal(24,4) DEFAULT NULL,
  `responded_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_vr_listing` (`listing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vitrine_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `vitrine_requests` WRITE;
/*!40000 ALTER TABLE `vitrine_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `vitrine_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `vitrine_watchlist`
--

DROP TABLE IF EXISTS `vitrine_watchlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vitrine_watchlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `listing_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_listing_unique` (`user_id`,`listing_id`),
  KEY `fk_watchlist_listing` (`listing_id`),
  CONSTRAINT `fk_watchlist_listing` FOREIGN KEY (`listing_id`) REFERENCES `vitrine_listings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vitrine_watchlist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `vitrine_watchlist` WRITE;
/*!40000 ALTER TABLE `vitrine_watchlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `vitrine_watchlist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `vpn_ranges`
--

DROP TABLE IF EXISTS `vpn_ranges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vpn_ranges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_range` varchar(50) NOT NULL COMMENT 'CIDR format: 52.0.0.0/8',
  `provider` varchar(100) DEFAULT NULL COMMENT 'AWS, Google Cloud, DigitalOcean, etc.',
  `range_type` varchar(50) NOT NULL COMMENT 'vpn, datacenter, proxy, hosting',
  `risk_level` int(10) DEFAULT 50 COMMENT 'سطح ریسک (0-100)',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vpn_ranges`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `vpn_ranges` WRITE;
/*!40000 ALTER TABLE `vpn_ranges` DISABLE KEYS */;
/*!40000 ALTER TABLE `vpn_ranges` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `wallets`
--

DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `balance_irt` decimal(24,8) DEFAULT 0.00000000,
  `balance_usdt` decimal(24,8) DEFAULT 0.00000000,
  `locked_irt` decimal(24,8) DEFAULT 0.00000000,
  `locked_usdt` decimal(24,8) DEFAULT 0.00000000,
  `is_frozen` tinyint(1) DEFAULT 0,
  `last_withdrawal_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_wallets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
INSERT INTO `wallets` VALUES
(1,3,0.00000000,0.00000000,0.00000000,0.00000000,0,NULL,'2026-08-06 08:36:32','2026-08-06 08:36:32'),
(2,4,0.00000000,0.00000000,0.00000000,0.00000000,0,NULL,'2026-08-06 08:36:32','2026-08-06 08:36:32'),
(3,2,0.00000000,0.00000000,0.00000000,0.00000000,0,NULL,'2026-08-06 08:36:32','2026-08-06 08:36:32'),
(4,1,1000000.00000000,0.00000000,0.00000000,0.00000000,0,NULL,'2026-08-06 08:36:32','2026-08-06 08:36:32');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `withdrawal_limits`
--

DROP TABLE IF EXISTS `withdrawal_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdrawal_limits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `daily_limit` decimal(24,8) DEFAULT NULL,
  `monthly_limit` decimal(24,8) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdrawal_limits`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `withdrawal_limits` WRITE;
/*!40000 ALTER TABLE `withdrawal_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdrawal_limits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `withdrawal_reviews`
--

DROP TABLE IF EXISTS `withdrawal_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdrawal_reviews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `withdrawal_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(24,8) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `stuck_hours` int(10) unsigned DEFAULT NULL,
  `detected_at` datetime DEFAULT NULL,
  `admin_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdrawal_reviews`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `withdrawal_reviews` WRITE;
/*!40000 ALTER TABLE `withdrawal_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdrawal_reviews` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `withdrawals`
--

DROP TABLE IF EXISTS `withdrawals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdrawals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `transaction_id` varchar(64) DEFAULT NULL,
  `amount` decimal(24,8) NOT NULL,
  `currency` varchar(10) DEFAULT 'irt',
  `card_id` int(10) unsigned DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL COMMENT 'card, crypto, sheba',
  `status` enum('pending','processing','completed','rejected','cancelled') DEFAULT 'pending',
  `fee` decimal(24,8) DEFAULT 0.00000000,
  `final_amount` decimal(24,8) DEFAULT NULL,
  `tracking_code` varchar(100) DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `processed_by` int(10) unsigned DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `idx_w_user` (`user_id`),
  KEY `idx_w_status` (`status`),
  CONSTRAINT `fk_withdrawal_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdrawals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `withdrawals` WRITE;
/*!40000 ALTER TABLE `withdrawals` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdrawals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'chortk'
--

--
-- Final view structure for view `tasks`
--

/*!50001 DROP VIEW IF EXISTS `tasks`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `tasks` AS select `social_tasks`.`id` AS `id`,`social_tasks`.`creator_id` AS `creator_id`,`social_tasks`.`title` AS `title`,`social_tasks`.`description` AS `description`,'social' AS `type`,`social_tasks`.`status` AS `status`,`social_tasks`.`updated_at` AS `completed_at`,`social_tasks`.`target_url` AS `link`,`social_tasks`.`price_per_task` AS `amount`,`social_tasks`.`platform` AS `platform`,`social_tasks`.`deleted_at` AS `deleted_at` from `social_tasks` union all select `custom_tasks`.`id` AS `id`,`custom_tasks`.`creator_id` AS `creator_id`,`custom_tasks`.`title` AS `title`,`custom_tasks`.`description` AS `description`,'custom' AS `type`,`custom_tasks`.`status` AS `status`,`custom_tasks`.`updated_at` AS `completed_at`,'' AS `link`,`custom_tasks`.`price_per_task` AS `amount`,'custom' AS `platform`,`custom_tasks`.`deleted_at` AS `deleted_at` from `custom_tasks` union all select `seo_tasks`.`id` AS `id`,`seo_tasks`.`creator_id` AS `creator_id`,`seo_tasks`.`title` AS `title`,concat('Keyword: ',`seo_tasks`.`keyword`) AS `description`,'seo' AS `type`,`seo_tasks`.`status` AS `status`,`seo_tasks`.`updated_at` AS `completed_at`,`seo_tasks`.`target_url` AS `link`,`seo_tasks`.`price_per_click` AS `amount`,'google' AS `platform`,`seo_tasks`.`deleted_at` AS `deleted_at` from `seo_tasks` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_fraud_correlation_analysis`
--

/*!50001 DROP VIEW IF EXISTS `v_fraud_correlation_analysis`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_fraud_correlation_analysis` AS select `f1`.`user_id` AS `user_a`,`f2`.`user_id` AS `user_b`,`f1`.`fingerprint` AS `fingerprint`,`f1`.`ip_address` AS `ip_address`,`u1`.`full_name` AS `name_a`,`u2`.`full_name` AS `name_b` from (((`user_sessions` `f1` join `user_sessions` `f2` on(`f1`.`fingerprint` = `f2`.`fingerprint` and `f1`.`user_id` < `f2`.`user_id`)) join `users` `u1` on(`f1`.`user_id` = `u1`.`id`)) join `users` `u2` on(`f2`.`user_id` = `u2`.`id`)) where `f1`.`is_active` = 1 and `f2`.`is_active` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_high_risk_users`
--

/*!50001 DROP VIEW IF EXISTS `v_high_risk_users`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_high_risk_users` AS select `u`.`id` AS `id`,`u`.`full_name` AS `full_name`,`u`.`email` AS `email`,`u`.`fraud_score` AS `fraud_score`,`u`.`is_blacklisted` AS `is_blacklisted`,count(distinct `fl`.`id`) AS `fraud_incidents`,max(`fl`.`created_at`) AS `last_fraud_incident` from (`users` `u` left join `fraud_logs` `fl` on(`u`.`id` = `fl`.`user_id`)) where `u`.`fraud_score` >= 50 or `u`.`is_blacklisted` = 1 group by `u`.`id`,`u`.`full_name`,`u`.`email`,`u`.`fraud_score`,`u`.`is_blacklisted` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_today_suspicious_activities`
--

/*!50001 DROP VIEW IF EXISTS `v_today_suspicious_activities`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_today_suspicious_activities` AS select `fl`.`id` AS `id`,`fl`.`user_id` AS `user_id`,`fl`.`session_id` AS `session_id`,`fl`.`fraud_type` AS `fraud_type`,`fl`.`risk_score` AS `risk_score`,`fl`.`details` AS `details`,`fl`.`action_taken` AS `action_taken`,`fl`.`ip_address` AS `ip_address`,`fl`.`user_agent` AS `user_agent`,`fl`.`created_at` AS `created_at`,`u`.`full_name` AS `full_name`,`u`.`email` AS `email`,`u`.`fraud_score` AS `fraud_score` from (`fraud_logs` `fl` left join `users` `u` on(`fl`.`user_id` = `u`.`id`)) where cast(`fl`.`created_at` as date) = cast('now' as date) order by `fl`.`created_at` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-06  8:36:33
