-- CHORTKE MIGRATION PART 11: ESCROW & FINAL FINANCIALS
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `escrows`;
CREATE TABLE `escrows` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64) UNIQUE,
    `buyer_id` INT(10) UNSIGNED NOT NULL,
    `seller_id` INT(10) UNSIGNED NOT NULL,
    `amount` DECIMAL(24,8) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `status` ENUM('held', 'released', 'refunded', 'disputed') DEFAULT 'held',
    `release_reason` VARCHAR(255),
    `released_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_escrow_users` (`buyer_id`, `seller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `bank_cards`;
CREATE TABLE `bank_cards` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `card_number` VARCHAR(20) NOT NULL,
    `sheba` VARCHAR(30),
    `bank_name` VARCHAR(100),
    `status` ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    `is_default` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `user_card` (`user_id`, `card_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `bulk_operations`;
CREATE TABLE `bulk_operations` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `admin_id` INT(10) UNSIGNED NOT NULL,
    `type` VARCHAR(50) NOT NULL COMMENT 'payout, message, status_update',
    `total_items` INT UNSIGNED,
    `processed_items` INT UNSIGNED DEFAULT 0,
    `status` ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
    `log_file` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
