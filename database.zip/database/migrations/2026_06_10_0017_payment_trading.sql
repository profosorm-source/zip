-- CHORTKE MIGRATION PART 17: PAYMENT & TRADING
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `payment_gateways`;
CREATE TABLE `payment_gateways` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `slug` VARCHAR(50) UNIQUE NOT NULL,
    `config` JSON,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `payment_logs`;
CREATE TABLE `payment_logs` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `gateway_id` INT(10) UNSIGNED NOT NULL,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `amount` DECIMAL(24,4),
    `order_id` VARCHAR(100),
    `transaction_id` VARCHAR(100),
    `payload` JSON,
    `status` VARCHAR(20),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `scheduled_payments`;
CREATE TABLE `scheduled_payments` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `amount` DECIMAL(24,4) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `frequency` ENUM('once', 'daily', 'weekly', 'monthly'),
    `next_run_at` TIMESTAMP NULL,
    `status` VARCHAR(20) DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `trading_records`;
CREATE TABLE `trading_records` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `symbol` VARCHAR(20),
    `type` ENUM('buy', 'sell'),
    `amount` DECIMAL(24,8),
    `price` DECIMAL(24,8),
    `profit_loss` DECIMAL(24,8),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_trade_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `investment_withdrawals`;
CREATE TABLE `investment_withdrawals` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `investment_id` INT(10) UNSIGNED NOT NULL,
    `amount` DECIMAL(24,4) NOT NULL,
    `status` VARCHAR(20) DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
