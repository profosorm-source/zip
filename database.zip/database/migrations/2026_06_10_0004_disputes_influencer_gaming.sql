-- ---------------------------------------------------------
-- CHORTKE SYSTEM SCHEMA MIGRATION - PART 4 (FINAL)
-- Senior QA Architect Standardized
-- Date: 2026-06-10
-- ---------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- =========================================================
-- 10. DISPUTES & RESOLUTION
-- =========================================================

DROP TABLE IF EXISTS `disputes`;
CREATE TABLE `disputes` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `ref_type` VARCHAR(50) NOT NULL COMMENT 'task, order, user',
    `ref_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'The reporter',
    `target_user_id` BIGINT UNSIGNED COMMENT 'The respondent',
    `reason` TEXT NOT NULL,
    `status` VARCHAR(50) DEFAULT 'open',
    `peer_deadline` TIMESTAMP NULL,
    `resolution_note` TEXT,
    `admin_decision` TEXT,
    `admin_id` BIGINT UNSIGNED,
    `admin_note` TEXT,
    `penalty_amount` DECIMAL(24,8) DEFAULT 0,
    `penalty_currency` VARCHAR(10),
    `penalty_target` BIGINT UNSIGNED,
    `site_tax_amount` DECIMAL(24,8) DEFAULT 0,
    `refund_percent` DECIMAL(10,2) DEFAULT 0,
    `resolved_at` TIMESTAMP NULL,
    `resolved_by` BIGINT UNSIGNED,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_dispute_ref` (`ref_type`, `ref_id`),
    KEY `idx_dispute_users` (`user_id`, `target_user_id`),
    KEY `idx_dispute_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `dispute_messages`;
CREATE TABLE `dispute_messages` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `dispute_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `role` VARCHAR(50) COMMENT 'customer, provider, admin',
    `message` TEXT NOT NULL,
    `attachment` VARCHAR(255),
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_dis_msg_id` (`dispute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 11. INFLUENCER & STORY ORDERS
-- =========================================================

DROP TABLE IF EXISTS `influencer_profiles`;
CREATE TABLE `influencer_profiles` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED UNIQUE NOT NULL,
    `username` VARCHAR(100) NOT NULL,
    `platform` VARCHAR(50) NOT NULL,
    `category` VARCHAR(100),
    `followers_count` INT UNSIGNED DEFAULT 0,
    `engagement_rate` DECIMAL(10,2) DEFAULT 0,
    `page_url` TEXT,
    `profile_image` TEXT,
    `bio` TEXT,
    `price_story` DECIMAL(24,4),
    `price_post` DECIMAL(24,4),
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `rejection_reason` TEXT,
    `verified_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    KEY `idx_inf_platform` (`platform`),
    KEY `idx_inf_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `story_orders`;
CREATE TABLE `story_orders` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `customer_id` BIGINT UNSIGNED NOT NULL,
    `influencer_id` BIGINT UNSIGNED NOT NULL,
    `influencer_user_id` BIGINT UNSIGNED NOT NULL,
    `order_type` VARCHAR(50) DEFAULT 'story',
    `duration_hours` INT DEFAULT 24,
    `media_path` TEXT,
    `caption` TEXT,
    `link` TEXT,
    `preferred_publish_time` TIMESTAMP NULL,
    `actual_publish_time` TIMESTAMP NULL,
    `verification_code` VARCHAR(50),
    `proof_screenshot` TEXT,
    `proof_video` TEXT,
    `proof_submitted_at` TIMESTAMP NULL,
    `proof_link` TEXT,
    `proof_notes` TEXT,
    `price` DECIMAL(24,4) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `site_fee_percent` DECIMAL(10,2) DEFAULT 0,
    `site_fee_amount` DECIMAL(24,4) DEFAULT 0,
    `influencer_earning` DECIMAL(24,4) DEFAULT 0,
    `status` VARCHAR(50) DEFAULT 'pending_payment',
    `rejection_reason` TEXT,
    `buyer_check_notified_at` TIMESTAMP NULL,
    `buyer_confirmed_at` TIMESTAMP NULL,
    `buyer_check_deadline` TIMESTAMP NULL,
    `peer_resolution_started_at` TIMESTAMP NULL,
    `customer_rating` TINYINT UNSIGNED,
    `customer_review` TEXT,
    `payment_transaction_id` VARCHAR(64),
    `payout_transaction_id` VARCHAR(64),
    `idempotency_key` VARCHAR(128) UNIQUE,
    `reviewed_by` BIGINT UNSIGNED,
    `reviewed_at` TIMESTAMP NULL,
    `admin_note` TEXT,
    `metadata` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_story_customer` (`customer_id`),
    KEY `idx_story_influencer` (`influencer_id`),
    KEY `idx_story_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 12. PREDICTION & GAMING
-- =========================================================

DROP TABLE IF EXISTS `prediction_games`;
CREATE TABLE `prediction_games` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `sport_type` VARCHAR(50) DEFAULT 'football',
    `team_home` VARCHAR(100),
    `team_away` VARCHAR(100),
    `start_time` TIMESTAMP NULL,
    `bet_deadline` TIMESTAMP NULL,
    `status` ENUM('open', 'locked', 'finished', 'cancelled') DEFAULT 'open',
    `result` VARCHAR(50),
    `settled_by` BIGINT UNSIGNED,
    `cancelled_by` BIGINT UNSIGNED,
    `cancelled_at` TIMESTAMP NULL,
    `finished_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `prediction_bets`;
CREATE TABLE `prediction_bets` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `game_id` BIGINT UNSIGNED NOT NULL,
    `prediction` VARCHAR(50) NOT NULL COMMENT 'home, away, draw',
    `amount` DECIMAL(24,4) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `status` ENUM('pending', 'won', 'lost', 'refunded') DEFAULT 'pending',
    `potential_win` DECIMAL(24,4),
    `payout_amount` DECIMAL(24,4),
    `payout_transaction_id` VARCHAR(64),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_bet_user` (`user_id`),
    KEY `idx_bet_game` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 13. BANNERS & PLACEMENTS
-- =========================================================

DROP TABLE IF EXISTS `banner_placements`;
CREATE TABLE `banner_placements` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(100) UNIQUE NOT NULL,
    `page` VARCHAR(100),
    `dimensions` VARCHAR(50),
    `max_banners` INT DEFAULT 1,
    `is_active` TINYINT(1) DEFAULT 1,
    `show_on_mobile` TINYINT(1) DEFAULT 1,
    `show_on_desktop` TINYINT(1) DEFAULT 1,
    `description` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 14. VITRINE & REQUESTS
-- =========================================================

DROP TABLE IF EXISTS `vitrine_listings`;
CREATE TABLE `vitrine_listings` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `price` DECIMAL(24,4),
    `currency` VARCHAR(10) DEFAULT 'irt',
    `status` ENUM('pending', 'active', 'sold', 'expired', 'rejected') DEFAULT 'pending',
    `expires_at` TIMESTAMP NULL,
    `hold_released` TINYINT(1) DEFAULT 0,
    `hold_released_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_vitrine_user` (`user_id`),
    KEY `idx_vitrine_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
