-- CHORTKE MIGRATION: IDENTITY (STRICT CODE-FIRST)
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(64) UNIQUE,
    `email` VARCHAR(255) UNIQUE NOT NULL,
    `mobile` VARCHAR(15) UNIQUE,
    `full_name` VARCHAR(255),
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('user', 'admin', 'super_admin', 'support') DEFAULT 'user',
    `status` ENUM('active', 'inactive', 'suspended', 'locked', 'locked_2fa', 'banned', 'deleted') DEFAULT 'active',
    `two_factor_enabled` TINYINT(1) DEFAULT 0,
    `two_factor_secret` TEXT,
    `last_2fa_timeslice` BIGINT(20) UNSIGNED,
    `referral_code` VARCHAR(20) UNIQUE,
    `referred_by` INT(10) UNSIGNED,
    `email_verified_at` TIMESTAMP NULL,
    `email_verification_token` VARCHAR(128),
    `avatar` VARCHAR(255),
    `remember_token` VARCHAR(100),
    `remember_expires_at` TIMESTAMP NULL,
    `last_login` TIMESTAMP NULL,
    `last_ip` VARCHAR(45),
    `last_user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    KEY `idx_u_email` (`email`),
    KEY `idx_u_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_sessions`;
CREATE TABLE `user_sessions` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `session_id` VARCHAR(191) UNIQUE NOT NULL,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `last_activity` INT(11),
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_sess_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
