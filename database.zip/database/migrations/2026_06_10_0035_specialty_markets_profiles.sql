-- CHORTKE MIGRATION PART 35: SPECIALTY MARKETS & PROFILES
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `talent_profiles`;
CREATE TABLE `talent_profiles` (
  `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `status` VARCHAR(20) DEFAULT 'pending',
  `tier` VARCHAR(20) DEFAULT 'bronze',
  `revenue_share_pct` DECIMAL(5,2) DEFAULT 60.00,
  `expertise` VARCHAR(255) DEFAULT NULL,
  `total_earned` DECIMAL(24,4) DEFAULT 0.00,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `talent_contents`;
CREATE TABLE `talent_contents` (
  `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `external_link` TEXT NOT NULL,
  `status` VARCHAR(20) DEFAULT 'submitted',
  `total_views` BIGINT UNSIGNED DEFAULT 0,
  `total_revenue` DECIMAL(24,4) DEFAULT 0.00,
  `published_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `talent_revenue_logs`;
CREATE TABLE `talent_revenue_logs` (
  `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `content_id` INT(10) UNSIGNED NOT NULL,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `period_start` DATE NOT NULL,
  `period_end` DATE NOT NULL,
  `views` INT(10) UNSIGNED DEFAULT 0,
  `gross_revenue_usdt` DECIMAL(24,8) NOT NULL,
  `user_share_usdt` DECIMAL(24,8) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `online_listings`;
CREATE TABLE `online_listings` (
  `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `seller_id` INT(10) UNSIGNED NOT NULL,
  `buyer_id` INT(10) UNSIGNED DEFAULT NULL,
  `platform` ENUM('instagram','telegram','youtube','twitter','tiktok','other') NOT NULL,
  `page_url` VARCHAR(500) NOT NULL,
  `username` VARCHAR(200) NOT NULL,
  `title` VARCHAR(300) NOT NULL,
  `price_usdt` DECIMAL(24,8) NOT NULL,
  `status` ENUM('pending_verification','active','sold','in_escrow','disputed','rejected','cancelled') NOT NULL DEFAULT 'pending_verification',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `withdrawal_reviews`;
CREATE TABLE `withdrawal_reviews` (
  `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `withdrawal_id` INT(10) UNSIGNED NOT NULL,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `detected_status` VARCHAR(32) NOT NULL,
  `review_status` ENUM('open','in_progress','auto_resolved','admin_resolved','dismissed') NOT NULL DEFAULT 'open',
  `severity` ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  `reason_code` VARCHAR(80) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `bug_reports`;
CREATE TABLE `bug_reports` (
  `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT(10) UNSIGNED DEFAULT NULL,
  `title` VARCHAR(200) NOT NULL,
  `description` TEXT NOT NULL,
  `priority` ENUM('low','normal','high','critical') NOT NULL DEFAULT 'normal',
  `status` ENUM('open','in_progress','resolved','closed','duplicate') NOT NULL DEFAULT 'open',
  `ip_address` VARCHAR(45),
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `bug_report_comments`;
CREATE TABLE `bug_report_comments` (
  `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `bug_report_id` INT(10) UNSIGNED NOT NULL,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `comment` TEXT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
