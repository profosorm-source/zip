-- CHORTKE MIGRATION PART 7: INVESTMENTS & GAMING
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `investments`;
CREATE TABLE `investments` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `amount` DECIMAL(24,4) NOT NULL,
    `plan_id` INT(10) UNSIGNED,
    `status` VARCHAR(20) DEFAULT 'active',
    `profit_earned` DECIMAL(24,4) DEFAULT 0,
    `expires_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_inv_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lottery_rounds`;
CREATE TABLE `lottery_rounds` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255),
    `prize_pool` DECIMAL(24,4) DEFAULT 0,
    `status` ENUM('open', 'closed', 'finished') DEFAULT 'open',
    `winner_user_id` INT(10) UNSIGNED,
    `draw_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `prediction_games`;
CREATE TABLE `prediction_games` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(255) NOT NULL,
    `home_team` VARCHAR(100),
    `away_team` VARCHAR(100),
    `start_time` TIMESTAMP NULL,
    `status` VARCHAR(20) DEFAULT 'open',
    `result` VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `prediction_bets`;
CREATE TABLE `prediction_bets` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `game_id` INT(10) UNSIGNED NOT NULL,
    `amount` DECIMAL(24,4) NOT NULL,
    `prediction` VARCHAR(50),
    `status` VARCHAR(20) DEFAULT 'pending',
    KEY `idx_bet_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
