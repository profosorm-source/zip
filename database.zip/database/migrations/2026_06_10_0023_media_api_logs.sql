-- CHORTKE MIGRATION PART 23: MEDIA & ATTACHMENTS HUB
-- Senior QA Architect Standardized
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `attachments`;
CREATE TABLE `attachments` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `ref_type` VARCHAR(50) NOT NULL COMMENT 'ticket, task_proof, kyc, avatar',
    `ref_id` INT(10) UNSIGNED NOT NULL,
    `file_name` VARCHAR(255) NOT NULL,
    `file_path` VARCHAR(255) NOT NULL,
    `file_type` VARCHAR(100),
    `file_size` BIGINT UNSIGNED,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_attachment_ref` (`ref_type`, `ref_id`),
    KEY `idx_attachment_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `api_logs`;
CREATE TABLE `api_logs` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `direction` ENUM('inbound', 'outbound') NOT NULL,
    `provider` VARCHAR(50) COMMENT 'google, gateway, sms_panel',
    `endpoint` TEXT,
    `request_payload` JSON,
    `response_payload` JSON,
    `status_code` INT(5),
    `duration_ms` INT(10),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
