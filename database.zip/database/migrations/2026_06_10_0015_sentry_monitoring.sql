-- CHORTKE MIGRATION PART 15: SENTRY & MONITORING
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `sentry_issues`;
CREATE TABLE `sentry_issues` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `fingerprint` VARCHAR(255) NOT NULL,
    `level` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `culprit` TEXT,
    `count` INT(10) UNSIGNED DEFAULT 1,
    `status` ENUM('unresolved', 'resolved', 'ignored') DEFAULT 'unresolved',
    `last_seen` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_sentry_fingerprint` (`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `sentry_events`;
CREATE TABLE `sentry_events` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `issue_id` INT(10) UNSIGNED NOT NULL,
    `event_id` VARCHAR(64) UNIQUE NOT NULL,
    `message` LONGTEXT,
    `payload` JSON,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `user_id` INT(10) UNSIGNED,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_se_issue` (`issue_id`),
    KEY `idx_se_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `system_telemetry`;
CREATE TABLE `system_telemetry` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `metric_name` VARCHAR(100) NOT NULL,
    `metric_value` DECIMAL(24,4),
    `tags` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_telemetry_name` (`metric_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
