-- Migration to ensure all referral system tables exist
-- Created on 2026-06-09

-- 1. Referral Commissions Table
-- Stores every commission payout to referrers
CREATE TABLE IF NOT EXISTS referral_commissions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    referrer_id BIGINT UNSIGNED NOT NULL,
    referred_user_id BIGINT UNSIGNED NOT NULL,
    amount DECIMAL(20,4) NOT NULL,
    commission_amount DECIMAL(20,4) NOT NULL,
    currency VARCHAR(10) NOT NULL,
    status ENUM('pending', 'paid', 'cancelled', 'rejected') DEFAULT 'pending',
    source_type VARCHAR(50), -- e.g., 'deposit', 'task', 'subscription'
    idempotency_key VARCHAR(255) UNIQUE,
    context JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (referrer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (referred_user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX (referrer_id, status),
    INDEX (referred_user_id),
    INDEX (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Referral Clicks / Interaction Table
-- Tracks clicks on referral links before conversion
CREATE TABLE IF NOT EXISTS referral_clicks (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    referrer_id BIGINT UNSIGNED NOT NULL,
    click_user_id BIGINT UNSIGNED NULL, -- If user is already logged in
    ip_address VARCHAR(45),
    user_agent TEXT,
    referred_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    converted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (referrer_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX (referrer_id),
    INDEX (ip_address),
    INDEX (referred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Referral Activity Logs
-- General audit log for referral actions
CREATE TABLE IF NOT EXISTS referral_activity_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    action VARCHAR(50) NOT NULL, -- e.g., 'signup', 'click', 'bonus_claim'
    ip_address VARCHAR(45),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX (user_id),
    INDEX (action),
    INDEX (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
