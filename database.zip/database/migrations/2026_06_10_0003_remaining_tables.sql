-- ---------------------------------------------------------
-- CHORTKE SYSTEM SCHEMA MIGRATION - PART 3
-- Senior QA Architect Standardized
-- Date: 2026-06-10
-- ---------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- =========================================================
-- 7. REMAINING FINANCIAL & REFERRAL
-- =========================================================

DROP TABLE IF EXISTS `referral_commissions`;
CREATE TABLE `referral_commissions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `referrer_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(24,8) NOT NULL,
    `commission_amount` DECIMAL(24,8) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `status` ENUM('pending', 'paid', 'cancelled') DEFAULT 'pending',
    `idempotency_key` VARCHAR(128) UNIQUE,
    `context` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_ref_comm_user` (`referrer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `withdrawal_limits`;
CREATE TABLE `withdrawal_limits` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED UNIQUE NOT NULL,
    `daily_limit_irt` DECIMAL(24,4) DEFAULT 0,
    `monthly_limit_irt` DECIMAL(24,4) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `manual_deposits`;
CREATE TABLE `manual_deposits` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(24,4) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `tracking_code` VARCHAR(128) UNIQUE,
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `admin_id` BIGINT UNSIGNED,
    `transaction_id` VARCHAR(64),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_manual_dep_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `crypto_deposits`;
CREATE TABLE `crypto_deposits` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(24,8) NOT NULL,
    `currency` VARCHAR(10) NOT NULL,
    `tx_hash` VARCHAR(255) UNIQUE,
    `network` VARCHAR(50),
    `status` VARCHAR(20) DEFAULT 'pending',
    `verification_status` VARCHAR(20) DEFAULT 'unverified',
    `transaction_id` VARCHAR(64),
    `confirmed_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_crypto_dep_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `crypto_deposit_intents`;
CREATE TABLE `crypto_deposit_intents` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(24,8) NOT NULL,
    `currency` VARCHAR(10) NOT NULL,
    `network` VARCHAR(50) NOT NULL,
    `address` VARCHAR(255) NOT NULL,
    `status` VARCHAR(20) DEFAULT 'active',
    `expires_at` TIMESTAMP NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_crypto_intent_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `escrows`;
CREATE TABLE `escrows` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64) UNIQUE,
    `buyer_id` BIGINT UNSIGNED NOT NULL,
    `seller_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(24,8) NOT NULL,
    `currency` VARCHAR(10) NOT NULL,
    `status` ENUM('held', 'released', 'refunded', 'disputed') DEFAULT 'held',
    `release_reason` TEXT,
    `held_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `released_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_escrow_buyer` (`buyer_id`),
    KEY `idx_escrow_seller` (`seller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `bank_cards`;
CREATE TABLE `bank_cards` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `card_number` VARCHAR(20) NOT NULL,
    `sheba` VARCHAR(30),
    `bank_name` VARCHAR(100),
    `status` ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    UNIQUE KEY `user_card` (`user_id`, `card_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 8. CUSTOM TASKS & MILESTONES
-- =========================================================

DROP TABLE IF EXISTS `custom_tasks`;
CREATE TABLE `custom_tasks` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `creator_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `category` VARCHAR(100),
    `budget` DECIMAL(24,4) DEFAULT 0,
    `status` VARCHAR(20) DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_custom_task_creator` (`creator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `custom_task_submissions`;
CREATE TABLE `custom_task_submissions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `task_id` BIGINT UNSIGNED NOT NULL,
    `worker_id` BIGINT UNSIGNED NOT NULL,
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `proof_url` TEXT,
    `proof_text` TEXT,
    `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `approved_at` TIMESTAMP NULL,
    `rating` TINYINT UNSIGNED,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_custom_sub_task` (`task_id`),
    KEY `idx_custom_sub_worker` (`worker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_milestones`;
CREATE TABLE `user_milestones` (
    `user_id` BIGINT UNSIGNED NOT NULL,
    `milestone` VARCHAR(100) NOT NULL,
    `awarded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`, `milestone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 9. LOGS & ANALYTICS
-- =========================================================

DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED,
    `event` VARCHAR(100) NOT NULL,
    `description` TEXT,
    `context` JSON,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_act_log_user` (`user_id`),
    KEY `idx_act_log_event` (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `system_logs`;
CREATE TABLE `system_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `level` VARCHAR(20) NOT NULL,
    `message` TEXT NOT NULL,
    `context` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_sys_log_level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `security_logs`;
CREATE TABLE `security_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `level` VARCHAR(20) NOT NULL,
    `message` TEXT NOT NULL,
    `user_id` BIGINT UNSIGNED,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_sec_log_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `performance_logs`;
CREATE TABLE `performance_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64),
    `request_id` VARCHAR(100),
    `name` VARCHAR(255),
    `op` VARCHAR(50),
    `duration` DECIMAL(12,4),
    `memory_used` BIGINT,
    `peak_memory` BIGINT,
    `query_count` INT,
    `status` VARCHAR(20),
    `context` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `mv_dashboard_stats`;
CREATE TABLE `mv_dashboard_stats` (
    `currency` VARCHAR(10) PRIMARY KEY,
    `total_deposits` DECIMAL(24,8) DEFAULT 0,
    `total_withdrawals` DECIMAL(24,8) DEFAULT 0,
    `today_deposits` DECIMAL(24,8) DEFAULT 0,
    `today_withdrawals` DECIMAL(24,8) DEFAULT 0,
    `pending_transactions` INT DEFAULT 0,
    `site_revenue` DECIMAL(24,8) DEFAULT 0,
    `today_revenue` DECIMAL(24,8) DEFAULT 0,
    `weekly_revenue` DECIMAL(24,8) DEFAULT 0,
    `monthly_revenue` DECIMAL(24,8) DEFAULT 0,
    `total_transactions` INT DEFAULT 0,
    `active_users` INT DEFAULT 0,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
