-- CHORTKE MIGRATION PART 10: NOTIFICATIONS & HARDENING
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `type` VARCHAR(50),
    `title` VARCHAR(255),
    `message` TEXT,
    `data` JSON,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_notif_user_read` (`user_id`, `is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `notification_preferences`;
CREATE TABLE `notification_preferences` (
    `user_id` INT(10) UNSIGNED PRIMARY KEY,
    `email_enabled` TINYINT(1) DEFAULT 1,
    `sms_enabled` TINYINT(1) DEFAULT 1,
    `push_enabled` TINYINT(1) DEFAULT 1,
    `marketing_enabled` TINYINT(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(50) UNIQUE NOT NULL,
    `type` ENUM('fixed', 'percent') DEFAULT 'fixed',
    `value` DECIMAL(24,4) NOT NULL,
    `min_order_amount` DECIMAL(24,4) DEFAULT 0,
    `max_discount` DECIMAL(24,4),
    `starts_at` TIMESTAMP NULL,
    `expires_at` TIMESTAMP NULL,
    `usage_limit` INT DEFAULT 1,
    `used_count` INT DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `account_deletion_logs`;
CREATE TABLE `account_deletion_logs` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `reason` TEXT,
    `requested_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    `status` ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `risk_policies`;
CREATE TABLE `risk_policies` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `domain` VARCHAR(50) NOT NULL COMMENT 'fraud, payment, auth',
    `key_name` VARCHAR(100) NOT NULL,
    `value` TEXT,
    `description` TEXT,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `risk_key` (`domain`, `key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
