-- ---------------------------------------------------------
-- CHORTKE FULL SYSTEM SCHEMA MIGRATION
-- Senior QA Architect Standardized
-- Date: 2026-06-10
-- ---------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- =========================================================
-- 1. IDENTITY & ACCESS MANAGEMENT
-- =========================================================

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(64) UNIQUE,
    `email` VARCHAR(255) UNIQUE NOT NULL,
    `mobile` VARCHAR(15) UNIQUE,
    `full_name` VARCHAR(255),
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('user', 'admin', 'super_admin', 'support') DEFAULT 'user',
    `status` ENUM('active', 'inactive', 'suspended', 'locked', 'locked_2fa', 'banned', 'deleted') DEFAULT 'active',
    `is_admin` TINYINT(1) DEFAULT 0,
    `two_factor_enabled` TINYINT(1) DEFAULT 0,
    `two_factor_method` VARCHAR(50),
    `two_factor_secret` TEXT,
    `last_2fa_timeslice` INT UNSIGNED,
    `referral_code` VARCHAR(20) UNIQUE,
    `referred_by` BIGINT UNSIGNED,
    `email_verification_token` VARCHAR(128),
    `email_verified_at` TIMESTAMP NULL,
    `country_code` CHAR(2) DEFAULT 'IR',
    `country_name` VARCHAR(100) DEFAULT 'Iran',
    `country_flag` VARCHAR(10),
    `avatar` VARCHAR(255),
    `bio` TEXT,
    `website` VARCHAR(255),
    `location` VARCHAR(255),
    `remember_token` VARCHAR(100),
    `remember_expires_at` TIMESTAMP NULL,
    `fraud_score` INT DEFAULT 0,
    `is_blacklisted` TINYINT(1) DEFAULT 0,
    `warning_count` INT DEFAULT 0,
    `last_login` TIMESTAMP NULL,
    `last_ip` VARCHAR(45),
    `last_user_agent` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    KEY `idx_user_email` (`email`),
    KEY `idx_user_mobile` (`mobile`),
    KEY `idx_user_status` (`status`),
    KEY `idx_user_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_sessions`;
CREATE TABLE `user_sessions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `session_id` VARCHAR(191) UNIQUE NOT NULL,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `device_type` VARCHAR(50),
    `browser` VARCHAR(50),
    `os` VARCHAR(50),
    `country` CHAR(2),
    `city` VARCHAR(100),
    `fingerprint` VARCHAR(128),
    `last_activity` TIMESTAMP NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_session_user` (`user_id`),
    KEY `idx_session_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
    `email` VARCHAR(255) NOT NULL,
    `token` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`email`),
    KEY `idx_reset_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_oauth`;
CREATE TABLE `user_oauth` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `provider` VARCHAR(50) NOT NULL,
    `provider_user_id` VARCHAR(191) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `oauth_provider_user` (`provider`, `provider_user_id`),
    KEY `idx_oauth_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `two_factor_codes`;
CREATE TABLE `two_factor_codes` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `code` VARCHAR(255) NOT NULL,
    `used` TINYINT(1) DEFAULT 0,
    `expires_at` TIMESTAMP NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_2fa_user_active` (`user_id`, `used`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 2. FINANCIAL CORE
-- =========================================================

DROP TABLE IF EXISTS `wallets`;
CREATE TABLE `wallets` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED UNIQUE NOT NULL,
    `balance_irt` DECIMAL(24,4) DEFAULT 0.0000,
    `balance_usdt` DECIMAL(24,8) DEFAULT 0.00000000,
    `locked_irt` DECIMAL(24,4) DEFAULT 0.0000,
    `locked_usdt` DECIMAL(24,8) DEFAULT 0.00000000,
    `is_frozen` TINYINT(1) DEFAULT 0,
    `last_withdrawal_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64) UNIQUE NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `currency` ENUM('irt', 'usdt') DEFAULT 'irt',
    `amount` DECIMAL(24,8) NOT NULL,
    `balance_before` DECIMAL(24,8),
    `balance_after` DECIMAL(24,8),
    `status` VARCHAR(20) DEFAULT 'pending',
    `description` TEXT,
    `gateway` VARCHAR(50),
    `gateway_transaction_id` VARCHAR(128),
    `ref_id` VARCHAR(128),
    `ref_type` VARCHAR(100),
    `request_id` VARCHAR(64),
    `ip_address` VARCHAR(45),
    `device_fingerprint` VARCHAR(128),
    `idempotency_key` VARCHAR(128) UNIQUE,
    `metadata` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `completed_at` TIMESTAMP NULL,
    KEY `idx_tx_user` (`user_id`),
    KEY `idx_tx_type` (`type`),
    KEY `idx_tx_status` (`status`),
    KEY `idx_tx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `ledger_entries`;
CREATE TABLE `ledger_entries` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64) NOT NULL,
    `account` VARCHAR(100) NOT NULL,
    `debit` DECIMAL(24,8) DEFAULT 0,
    `credit` DECIMAL(24,8) DEFAULT 0,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `description` TEXT,
    `metadata` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_ledger_tx` (`transaction_id`),
    KEY `idx_ledger_account` (`account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `transaction_events`;
CREATE TABLE `transaction_events` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64) NOT NULL,
    `event_type` VARCHAR(50) NOT NULL,
    `previous_status` VARCHAR(20),
    `new_status` VARCHAR(20),
    `reason` TEXT,
    `changed_by` BIGINT UNSIGNED,
    `metadata` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_tx_event_id` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 3. ADS & TASKS
-- =========================================================

DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `keyword` VARCHAR(100),
    `type` ENUM('social', 'seo', 'custom_task', 'banner', 'youtube') NOT NULL,
    `platform` VARCHAR(50),
    `task_type` VARCHAR(100),
    `price_per_task` DECIMAL(24,4) NOT NULL,
    `total_budget` DECIMAL(24,4) NOT NULL,
    `remaining_budget` DECIMAL(24,4) NOT NULL,
    `total_count` INT UNSIGNED NOT NULL,
    `remaining_count` INT UNSIGNED NOT NULL,
    `status` ENUM('active', 'paused', 'completed', 'cancelled', 'pending_approval', 'rejected') DEFAULT 'pending_approval',
    `metadata` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    KEY `idx_ad_user` (`user_id`),
    KEY `idx_ad_type` (`type`),
    KEY `idx_ad_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `social_task_executions`;
CREATE TABLE `social_task_executions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `ad_id` BIGINT UNSIGNED NOT NULL,
    `executor_id` BIGINT UNSIGNED NOT NULL,
    `status` ENUM('pending', 'approved', 'rejected', 'cancelled', 'expired', 'in_progress') DEFAULT 'pending',
    `proof_url` TEXT,
    `proof_text` TEXT,
    `reward_amount` DECIMAL(24,4),
    `reminder_sent` TIMESTAMP NULL,
    `auto_approved_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_social_exec_ad` (`ad_id`),
    KEY `idx_social_exec_user` (`executor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `seo_executions`;
CREATE TABLE `seo_executions` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `ad_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `status` VARCHAR(20) DEFAULT 'pending',
    `reward_amount` DECIMAL(24,4),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_seo_exec_ad` (`ad_id`),
    KEY `idx_seo_exec_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
