-- ---------------------------------------------------------
-- CHORTKE SYSTEM SCHEMA MIGRATION - PART 2
-- Senior QA Architect Standardized
-- Date: 2026-06-10
-- ---------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- =========================================================
-- 4. GAMIFICATION & LEVELS
-- =========================================================

DROP TABLE IF EXISTS `user_levels`;
CREATE TABLE `user_levels` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `slug` VARCHAR(50) UNIQUE NOT NULL,
    `icon` VARCHAR(100) DEFAULT 'workspace_premium',
    `color` VARCHAR(20) DEFAULT '#c0c0c0',
    `sort_order` INT DEFAULT 0,
    `min_score` DECIMAL(24,4) DEFAULT 0,
    `min_active_days` INT DEFAULT 0,
    `min_completed_tasks` INT DEFAULT 0,
    `min_total_earning` DECIMAL(24,4) DEFAULT 0,
    `purchase_price_irt` DECIMAL(24,4) DEFAULT 0,
    `purchase_price_usdt` DECIMAL(24,8) DEFAULT 0,
    `purchase_duration_days` INT DEFAULT 30,
    `earning_bonus_percent` DECIMAL(10,2) DEFAULT 0,
    `referral_bonus_percent` DECIMAL(10,2) DEFAULT 0,
    `daily_task_limit_bonus` INT DEFAULT 0,
    `withdrawal_limit_bonus` DECIMAL(24,4) DEFAULT 0,
    `priority_support` TINYINT(1) DEFAULT 0,
    `special_badge` TINYINT(1) DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `user_level_history`;
CREATE TABLE `user_level_history` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `from_level` VARCHAR(50),
    `to_level` VARCHAR(50) NOT NULL,
    `change_type` ENUM('upgrade', 'downgrade', 'purchase', 'expire', 'admin', 'reset') NOT NULL,
    `reason` TEXT,
    `metadata` JSON,
    `ip_address` VARCHAR(45),
    `signature` VARCHAR(128),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_level_history_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `scores`;
CREATE TABLE `scores` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `domain` VARCHAR(50) NOT NULL COMMENT 'task, referral, activity, reputation',
    `score` DECIMAL(24,4) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `user_domain` (`user_id`, `domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `score_events`;
CREATE TABLE `score_events` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `entity_id` BIGINT UNSIGNED NOT NULL,
    `entity_type` VARCHAR(50) NOT NULL COMMENT 'user, influencer, task',
    `domain` VARCHAR(50) NOT NULL,
    `delta` DECIMAL(24,4) NOT NULL,
    `reason` VARCHAR(100),
    `metadata` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_score_event_entity` (`entity_id`, `entity_type`),
    KEY `idx_score_event_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 5. SUPPORT & MESSAGING
-- =========================================================

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE `tickets` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `ticket_id` VARCHAR(20) UNIQUE NOT NULL,
    `subject` VARCHAR(255) NOT NULL,
    `category_id` INT UNSIGNED,
    `priority` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    `status` ENUM('open', 'pending', 'replied', 'closed', 'resolved') DEFAULT 'open',
    `assigned_to` BIGINT UNSIGNED,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_ticket_user` (`user_id`),
    KEY `idx_ticket_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `ticket_messages`;
CREATE TABLE `ticket_messages` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `ticket_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `message` TEXT NOT NULL,
    `is_admin` TINYINT(1) DEFAULT 0,
    `attachments` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_msg_ticket` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `direct_messages`;
CREATE TABLE `direct_messages` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `sender_id` BIGINT UNSIGNED NOT NULL,
    `recipient_id` BIGINT UNSIGNED NOT NULL,
    `message` TEXT NOT NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    `deleted_by` BIGINT UNSIGNED,
    KEY `idx_dm_sender` (`sender_id`),
    KEY `idx_dm_recipient` (`recipient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- 6. SYSTEM & LOGS
-- =========================================================

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(191) UNIQUE NOT NULL,
    `setting_value` LONGTEXT,
    `group` VARCHAR(100) DEFAULT 'general',
    `type` VARCHAR(50) DEFAULT 'string',
    `description` TEXT,
    `is_public` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `audit_trail`;
CREATE TABLE `audit_trail` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `event` VARCHAR(191) NOT NULL,
    `category` VARCHAR(50) DEFAULT 'general',
    `user_id` BIGINT UNSIGNED,
    `actor_id` BIGINT UNSIGNED,
    `ip_address` VARCHAR(45),
    `request_id` VARCHAR(64),
    `context` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_audit_event` (`event`),
    KEY `idx_audit_user` (`user_id`),
    KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `outbox_events`;
CREATE TABLE `outbox_events` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `aggregate_type` VARCHAR(80) NOT NULL,
    `aggregate_id` VARCHAR(128) NOT NULL,
    `event_type` VARCHAR(120) NOT NULL,
    `payload` JSON,
    `status` ENUM('pending', 'processing', 'published', 'failed', 'dlq') DEFAULT 'pending',
    `attempts` INT DEFAULT 0,
    `available_at` TIMESTAMP NULL,
    `published_at` TIMESTAMP NULL,
    `last_error` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_outbox_status_available` (`status`, `available_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `connection` TEXT NOT NULL,
    `queue` TEXT NOT NULL,
    `payload` LONGTEXT NOT NULL,
    `exception` LONGTEXT NOT NULL,
    `failed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `idempotency_keys`;
CREATE TABLE `idempotency_keys` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(191) NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `action` VARCHAR(100),
    `status` VARCHAR(20) DEFAULT 'pending',
    `result` JSON,
    `request_data` JSON,
    `completed_at` TIMESTAMP NULL,
    `expires_at` TIMESTAMP NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `user_key` (`user_id`, `key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `saga_executions`;
CREATE TABLE `saga_executions` (
    `id` VARCHAR(64) PRIMARY KEY,
    `saga_name` VARCHAR(255) NOT NULL,
    `status` ENUM('started', 'completed', 'compensated', 'failed') DEFAULT 'started',
    `payload` JSON,
    `executed_steps` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_saga_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `feature_flags`;
CREATE TABLE `feature_flags` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(191) UNIQUE NOT NULL,
    `description` TEXT,
    `enabled` TINYINT(1) DEFAULT 0,
    `enabled_percentage` INT DEFAULT 100,
    `targeted_user_ids` JSON,
    `targeted_roles` JSON,
    `targeted_countries` JSON,
    `targeted_plans` JSON,
    `targeted_devices` JSON,
    `targeted_routes` JSON,
    `target_age_min` INT,
    `target_age_max` INT,
    `rollout_seed` VARCHAR(64),
    `config_values` JSON,
    `enabled_from` TIMESTAMP NULL,
    `enabled_until` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
