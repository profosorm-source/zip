-- CHORTKE MASTER MIGRATION: TALENT & SPECIALIZED TABLES
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `talent_profiles`;
CREATE TABLE `talent_profiles` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `status` VARCHAR(20) DEFAULT 'pending',
  `tier` VARCHAR(20) DEFAULT 'bronze',
  `revenue_share_pct` DECIMAL(5,2) DEFAULT 60.00,
  `agreement_signed_at` TIMESTAMP NULL,
  `bio` TEXT DEFAULT NULL,
  `expertise` VARCHAR(255) DEFAULT NULL,
  `total_earned` DECIMAL(24,4) DEFAULT 0.00,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `talent_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `talent_contents`;
CREATE TABLE `talent_contents` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `external_link` TEXT NOT NULL,
  `status` VARCHAR(20) DEFAULT 'submitted',
  `published_links` TEXT DEFAULT NULL,
  `total_views` BIGINT(20) UNSIGNED DEFAULT 0,
  `total_revenue` DECIMAL(24,4) DEFAULT 0.00,
  `admin_note` TEXT DEFAULT NULL,
  `published_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `talent_revenue_logs`;
CREATE TABLE `talent_revenue_logs` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `content_id` INT(10) UNSIGNED NOT NULL,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `period_start` DATE NOT NULL,
  `period_end` DATE NOT NULL,
  `views` INT(10) UNSIGNED DEFAULT 0,
  `gross_revenue_usdt` DECIMAL(24,8) NOT NULL,
  `user_share_usdt` DECIMAL(24,8) NOT NULL,
  `admin_note` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `online_listings`;
CREATE TABLE `online_listings` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `seller_id` INT(10) UNSIGNED NOT NULL,
  `buyer_id` INT(10) UNSIGNED DEFAULT NULL,
  `platform` ENUM('instagram','telegram','youtube','twitter','tiktok','other') NOT NULL,
  `page_url` VARCHAR(500) NOT NULL,
  `username` VARCHAR(200) NOT NULL,
  `title` VARCHAR(300) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `member_count` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `creation_date` DATE DEFAULT NULL,
  `price_usdt` DECIMAL(24,4) NOT NULL,
  `proof_text` TEXT DEFAULT NULL,
  `screenshots` JSON DEFAULT NULL,
  `bio_verified` TINYINT(1) NOT NULL DEFAULT 0,
  `status` ENUM('pending_verification','active','sold','in_escrow','disputed','rejected','cancelled') NOT NULL DEFAULT 'pending_verification',
  `admin_note` TEXT DEFAULT NULL,
  `rejection_reason` TEXT DEFAULT NULL,
  `access_info_hash` VARCHAR(500) DEFAULT NULL,
  `escrow_tx` VARCHAR(200) DEFAULT NULL,
  `deleted_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `user_level_history`;
CREATE TABLE `user_level_history` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `from_level` VARCHAR(60),
  `to_level` VARCHAR(60) NOT NULL,
  `change_type` ENUM('auto','purchase','admin','reset','downgrade') DEFAULT 'auto',
  `reason` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_ulh_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
