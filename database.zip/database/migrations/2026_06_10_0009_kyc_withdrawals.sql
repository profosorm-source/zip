-- CHORTKE MIGRATION PART 9: KYC & WITHDRAWALS
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `kyc_verifications`;
CREATE TABLE `kyc_verifications` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED UNIQUE NOT NULL,
    `first_name` VARCHAR(100),
    `last_name` VARCHAR(100),
    `national_id` VARCHAR(20) UNIQUE,
    `birth_date` DATE,
    `id_card_image` VARCHAR(255),
    `selfie_image` VARCHAR(255),
    `status` ENUM('pending', 'under_review', 'verified', 'rejected') DEFAULT 'pending',
    `rejection_reason` TEXT,
    `verified_at` TIMESTAMP NULL,
    `admin_id` INT(10) UNSIGNED,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_kyc_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `withdrawals`;
CREATE TABLE `withdrawals` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `transaction_id` VARCHAR(64) UNIQUE,
    `amount` DECIMAL(24,8) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `card_id` INT(10) UNSIGNED,
    `method` VARCHAR(50) COMMENT 'card, crypto, sheba',
    `status` ENUM('pending', 'processing', 'completed', 'rejected', 'cancelled') DEFAULT 'pending',
    `fee` DECIMAL(24,8) DEFAULT 0,
    `final_amount` DECIMAL(24,8),
    `tracking_code` VARCHAR(100),
    `admin_note` TEXT,
    `processed_by` INT(10) UNSIGNED,
    `processed_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_withdraw_user` (`user_id`),
    KEY `idx_withdraw_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `withdrawal_limits`;
CREATE TABLE `withdrawal_limits` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED UNIQUE NOT NULL,
    `daily_limit` DECIMAL(24,4),
    `monthly_limit` DECIMAL(24,4),
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
