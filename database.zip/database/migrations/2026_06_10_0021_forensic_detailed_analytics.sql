-- CHORTKE MIGRATION PART 21: FORENSIC & FORENSIC ANALYTICS
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `file_access_logs`;
CREATE TABLE `file_access_logs` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED,
    `file_path` VARCHAR(255),
    `access_type` ENUM('read', 'write', 'delete'),
    `ip_address` VARCHAR(45),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `influencer_verifications`;
CREATE TABLE `influencer_verifications` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `influencer_id` INT(10) UNSIGNED NOT NULL,
    `verification_type` VARCHAR(50),
    `proof_data` JSON,
    `status` VARCHAR(20) DEFAULT 'pending',
    `admin_id` INT(10) UNSIGNED,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_iv_influencer` (`influencer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lottery_chance_logs`;
CREATE TABLE `lottery_chance_logs` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `chance_delta` INT(10),
    `reason` VARCHAR(100),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lottery_daily_numbers`;
CREATE TABLE `lottery_daily_numbers` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `winning_number` INT(10),
    `draw_date` DATE UNIQUE,
    `total_winners` INT(10) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `message_moderation_logs`;
CREATE TABLE `message_moderation_logs` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `message_type` VARCHAR(50) COMMENT 'dm, ticket, comment',
    `message_id` INT(10) UNSIGNED NOT NULL,
    `admin_id` INT(10) UNSIGNED NOT NULL,
    `action` ENUM('approved', 'rejected', 'hidden', 'edited'),
    `reason` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `vitrine_requests`;
CREATE TABLE `vitrine_requests` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `listing_id` INT(10) UNSIGNED NOT NULL,
    `status` VARCHAR(20) DEFAULT 'pending',
    `message` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_vr_listing` (`listing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `user_fraud_flags`;
CREATE TABLE `user_fraud_flags` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `flag_type` VARCHAR(100),
    `severity` INT(10) DEFAULT 1,
    `metadata` JSON,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_uff_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
