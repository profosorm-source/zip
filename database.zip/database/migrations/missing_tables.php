<?php

// CLI Migration Script

require_once __DIR__ . '/../../bootstrap/app.php';

$app = \Core\Application::getInstance();
$db = $app->db()->getPdo();

$sql = "
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `system_settings` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `key` varchar(191) NOT NULL,
    `value` longtext DEFAULT NULL,
    `group` varchar(100) DEFAULT 'general',
    `type` varchar(50) DEFAULT 'string' COMMENT 'string, int, bool, json, float',
    `description` text DEFAULT NULL,
    `is_public` tinyint(1) NOT NULL DEFAULT 0,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `system_settings_key_unique` (`key`),
    KEY `system_settings_group_index` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sentry_issues` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `fingerprint` varchar(255) NOT NULL,
    `level` varchar(50) NOT NULL,
    `title` varchar(255) NOT NULL,
    `culprit` text DEFAULT NULL,
    `first_seen` datetime NOT NULL,
    `last_seen` datetime NOT NULL,
    `count` int(11) NOT NULL DEFAULT 1,
    `environment` varchar(50) NOT NULL DEFAULT 'production',
    `release_version` varchar(100) DEFAULT NULL,
    `status` varchar(50) NOT NULL DEFAULT 'unresolved',
    `metadata` longtext DEFAULT NULL,
    `acknowledged_at` datetime DEFAULT NULL,
    `acknowledged_by` bigint(20) unsigned DEFAULT NULL,
    `is_acknowledged` tinyint(1) NOT NULL DEFAULT 0,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `sentry_issues_fingerprint_env` (`fingerprint`, `environment`),
    KEY `sentry_issues_status` (`status`),
    KEY `sentry_issues_level` (`level`),
    KEY `sentry_issues_last_seen` (`last_seen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sentry_events` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `event_id` varchar(64) NOT NULL,
    `request_id` varchar(100) DEFAULT NULL,
    `issue_id` bigint(20) unsigned NOT NULL,
    `level` varchar(50) NOT NULL,
    `message` longtext NOT NULL,
    `exception_type` varchar(255) DEFAULT NULL,
    `stack_trace` longtext DEFAULT NULL,
    `breadcrumbs` longtext DEFAULT NULL,
    `user_context` longtext DEFAULT NULL,
    `request_context` longtext DEFAULT NULL,
    `device_context` longtext DEFAULT NULL,
    `tags` longtext DEFAULT NULL,
    `extra` longtext DEFAULT NULL,
    `environment` varchar(50) NOT NULL DEFAULT 'production',
    `release_version` varchar(100) DEFAULT NULL,
    `user_id` bigint(20) unsigned DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` text DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `sentry_events_event_id_unique` (`event_id`),
    KEY `sentry_events_issue_id` (`issue_id`),
    KEY `sentry_events_created_at` (`created_at`),
    KEY `sentry_events_level` (`level`),
    KEY `sentry_events_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sentry_issue_events` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `issue_id` bigint(20) unsigned NOT NULL,
    `event_type` varchar(50) NOT NULL,
    `details` longtext DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `sentry_issue_events_issue_id` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `system_alerts` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `alert_type` varchar(50) NOT NULL,
    `severity` varchar(20) NOT NULL DEFAULT 'medium',
    `title` varchar(255) NOT NULL,
    `message` longtext DEFAULT NULL,
    `metadata` longtext DEFAULT NULL,
    `fingerprint` varchar(255) DEFAULT NULL,
    `event_id` varchar(64) DEFAULT NULL,
    `environment` varchar(50) DEFAULT 'production',
    `is_active` tinyint(1) NOT NULL DEFAULT 1,
    `is_sent` tinyint(1) NOT NULL DEFAULT 0,
    `sent_at` datetime DEFAULT NULL,
    `acknowledged_at` datetime DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `system_alerts_severity` (`severity`),
    KEY `system_alerts_fingerprint` (`fingerprint`),
    KEY `system_alerts_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `alert_rules` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `rule_name` varchar(191) NOT NULL,
    `rule_type` varchar(50) NOT NULL,
    `condition` longtext DEFAULT NULL COMMENT 'JSON condition',
    `threshold` decimal(10,2) NOT NULL DEFAULT 0,
    `time_window` int(11) DEFAULT 60 COMMENT 'minutes',
    `severity` varchar(20) NOT NULL DEFAULT 'medium',
    `is_active` tinyint(1) NOT NULL DEFAULT 1,
    `last_triggered_at` datetime DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `alert_rules_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notification_channels` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `channel_type` varchar(50) NOT NULL COMMENT 'telegram, email, slack, webhook',
    `config` longtext DEFAULT NULL COMMENT 'JSON config',
    `alert_levels` longtext DEFAULT NULL COMMENT 'JSON array of severity levels',
    `is_active` tinyint(1) NOT NULL DEFAULT 1,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notification_history` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `channel_id` bigint(20) unsigned NOT NULL,
    `alert_id` bigint(20) unsigned NOT NULL,
    `status` varchar(20) NOT NULL DEFAULT 'pending',
    `sent_at` datetime DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `notification_history_channel_id` (`channel_id`),
    KEY `notification_history_alert_id` (`alert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `performance_transactions` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `transaction_id` varchar(64) NOT NULL,
    `request_id` varchar(100) DEFAULT NULL,
    `name` varchar(255) NOT NULL,
    `op` varchar(50) NOT NULL DEFAULT 'http.request',
    `duration` decimal(10,2) NOT NULL DEFAULT 0 COMMENT 'milliseconds',
    `memory_used` bigint(20) DEFAULT 0,
    `peak_memory` bigint(20) DEFAULT 0,
    `query_count` int(11) DEFAULT 0,
    `slow_queries_count` int(11) DEFAULT 0,
    `status` varchar(50) DEFAULT 'ok',
    `spans` longtext DEFAULT NULL,
    `queries` longtext DEFAULT NULL,
    `issues` longtext DEFAULT NULL,
    `context` longtext DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `perf_tx_name` (`name`(100)),
    KEY `perf_tx_created_at` (`created_at`),
    KEY `perf_tx_duration` (`duration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `audit_trail` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `event` varchar(191) NOT NULL,
    `category` varchar(50) DEFAULT 'general',
    `user_id` bigint(20) unsigned DEFAULT NULL,
    `actor_id` bigint(20) unsigned DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `context` longtext DEFAULT NULL COMMENT 'JSON',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `audit_trail_event` (`event`),
    KEY `audit_trail_user_id` (`user_id`),
    KEY `audit_trail_actor_id` (`actor_id`),
    KEY `audit_trail_created_at` (`created_at`),
    FULLTEXT KEY `ft_audit_event` (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `risk_policies` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `domain` varchar(50) NOT NULL COMMENT 'fraud, session, payment, etc',
    `key_name` varchar(100) NOT NULL,
    `value` text NOT NULL,
    `value_type` varchar(20) NOT NULL DEFAULT 'string' COMMENT 'string, int, float, bool, json, array',
    `description` text DEFAULT NULL,
    `updated_by` bigint(20) unsigned DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `risk_policies_domain_key` (`domain`, `key_name`),
    KEY `risk_policies_domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
";

try {
    $db->exec($sql);
    echo "Migration completed successfully!\n";
} catch (\PDOException $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
}
