-- CHORTKE MIGRATION PART 2: ADS & TASKS
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `keyword` VARCHAR(100),
    `type` ENUM('social', 'seo', 'custom_task', 'banner', 'youtube') NOT NULL,
    `platform` VARCHAR(50),
    `task_type` VARCHAR(100),
    `price_per_task` DECIMAL(24,4) NOT NULL,
    `total_budget` DECIMAL(24,4) NOT NULL,
    `remaining_budget` DECIMAL(24,4) NOT NULL,
    `total_count` INT(10) UNSIGNED NOT NULL,
    `remaining_count` INT(10) UNSIGNED NOT NULL,
    `status` VARCHAR(20) DEFAULT 'pending_approval',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    KEY `idx_ad_user` (`user_id`),
    KEY `idx_ad_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `social_task_executions`;
CREATE TABLE `social_task_executions` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `ad_id` INT(10) UNSIGNED NOT NULL,
    `executor_id` INT(10) UNSIGNED NOT NULL,
    `status` VARCHAR(20) DEFAULT 'pending',
    `proof_url` TEXT,
    `proof_text` TEXT,
    `reward_amount` DECIMAL(24,4),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_ste_ad` (`ad_id`),
    KEY `idx_ste_user` (`executor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `custom_task_submissions`;
CREATE TABLE `custom_task_submissions` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `task_id` INT(10) UNSIGNED NOT NULL,
    `worker_id` INT(10) UNSIGNED NOT NULL,
    `status` VARCHAR(20) DEFAULT 'pending',
    `proof_text` TEXT,
    `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `approved_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_cts_task` (`task_id`),
    KEY `idx_cts_worker` (`worker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
