-- CHORTKE MASTER MIGRATION: FINAL COMPLETENESS & HARDENING
-- Senior QA Architect Standardized
-- Covers all missing tables from models, source SQL, and fixes naming inconsistencies.
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Naming Consistency Fixes (Matching Models)
-- DataExport model uses 'data_exports'
DROP TABLE IF EXISTS `data_exports`;
CREATE TABLE `data_exports` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `format` VARCHAR(20) NOT NULL,
    `file_path` VARCHAR(255),
    `status` VARCHAR(20) DEFAULT 'pending',
    `error_message` TEXT,
    `requested_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `completed_at` TIMESTAMP NULL,
    `expires_at` TIMESTAMP NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_de_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- FileAccess model uses 'file_logs'
DROP TABLE IF EXISTS `file_logs`;
CREATE TABLE `file_logs` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `folder` VARCHAR(100),
    `filename` VARCHAR(255),
    `viewer_id` INT(10) UNSIGNED,
    `action` VARCHAR(50),
    `ip_address` VARCHAR(45),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Interaction Model Dependencies
DROP TABLE IF EXISTS `task_favorites`;
CREATE TABLE `task_favorites` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `task_id` INT(10) UNSIGNED NOT NULL,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `user_task_fav` (`user_id`, `task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `task_reports`;
CREATE TABLE `task_reports` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `task_id` INT(10) UNSIGNED NOT NULL,
    `reporter_id` INT(10) UNSIGNED NOT NULL,
    `reason` VARCHAR(100) NOT NULL,
    `description` TEXT,
    `status` ENUM('pending', 'reviewed', 'resolved', 'rejected') DEFAULT 'pending',
    `admin_id` INT(10) UNSIGNED,
    `admin_note` TEXT,
    `resolved_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `message_reports`;
CREATE TABLE `message_reports` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `message_id` INT(10) UNSIGNED NOT NULL,
    `reporter_id` INT(10) UNSIGNED NOT NULL,
    `reason` VARCHAR(100),
    `status` VARCHAR(20) DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Views from Source SQL (Standardized)
DROP VIEW IF EXISTS `v_high_risk_users`;
CREATE VIEW `v_high_risk_users` AS 
SELECT `u`.`id`, `u`.`full_name`, `u`.`email`, `u`.`fraud_score`, `u`.`is_blacklisted`, count(distinct `fl`.`id`) AS `fraud_incidents`, max(`fl`.`created_at`) AS `last_fraud_incident` 
FROM (`users` `u` left join `fraud_logs` `fl` on(`u`.`id` = `fl`.`user_id`)) 
WHERE `u`.`fraud_score` >= 50 OR `u`.`is_blacklisted` = 1 
GROUP BY `u`.`id`, `u`.`full_name`, `u`.`email`, `u`.`fraud_score`, `u`.`is_blacklisted`;

DROP VIEW IF EXISTS `v_today_suspicious_activities`;
CREATE VIEW `v_today_suspicious_activities` AS 
SELECT `fl`.`id`, `fl`.`user_id`, `fl`.`session_id`, `fl`.`fraud_type`, `fl`.`risk_score`, `fl`.`details`, `fl`.`action_taken`, `fl`.`ip_address`, `fl`.`user_agent`, `fl`.`created_at`, `u`.`full_name`, `u`.`email`, `u`.`fraud_score` 
FROM (`fraud_logs` `fl` left join `users` `u` on(`fl`.`user_id` = `u`.`id`)) 
WHERE DATE(`fl`.`created_at`) = CURRENT_DATE()
ORDER BY `fl`.`created_at` DESC;

-- 4. Additional Tables found in Audit
DROP TABLE IF EXISTS `captcha_attempts`;
CREATE TABLE `captcha_attempts` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT(10) UNSIGNED NULL,
  `session_id` VARCHAR(128) NULL,
  `type` VARCHAR(50) NOT NULL,
  `challenge` TEXT NULL,
  `response` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` VARCHAR(255) NULL,
  `is_success` TINYINT(1) NOT NULL DEFAULT 0,
  `score` DOUBLE NULL,
  `solved_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_cap_user` (`user_id`),
  KEY `idx_cap_ip` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `withdrawal_reviews`;
CREATE TABLE `withdrawal_reviews` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `withdrawal_id` INT(10) UNSIGNED NOT NULL,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `detected_status` VARCHAR(32) NOT NULL,
  `transaction_status` VARCHAR(32) DEFAULT NULL,
  `stuck_minutes` INT(10) UNSIGNED NOT NULL DEFAULT 0,
  `review_status` ENUM('open','in_progress','auto_resolved','admin_resolved','dismissed') NOT NULL DEFAULT 'open',
  `severity` ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  `reason_code` VARCHAR(80) NOT NULL,
  `details` JSON DEFAULT NULL,
  `notified_admin_at` TIMESTAMP NULL,
  `assigned_admin_id` INT(10) UNSIGNED DEFAULT NULL,
  `resolved_at` TIMESTAMP NULL,
  `resolved_by` INT(10) UNSIGNED DEFAULT NULL,
  `resolution_note` VARCHAR(1000) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
