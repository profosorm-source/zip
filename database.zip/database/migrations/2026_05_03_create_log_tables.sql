CREATE TABLE IF NOT EXISTS `system_logs` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT,
    `level` varchar(20) NOT NULL,
    `type` varchar(20) NOT NULL DEFAULT 'system',
    `message` text NOT NULL,
    `context` longtext DEFAULT NULL,
    `user_id` bigint unsigned DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` text DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `level_idx` (`level`),
    KEY `type_idx` (`type`),
    KEY `created_at_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `security_logs` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT,
    `level` varchar(20) NOT NULL,
    `type` varchar(20) NOT NULL DEFAULT 'security',
    `message` text NOT NULL,
    `context` longtext DEFAULT NULL,
    `user_id` bigint unsigned DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` text DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `level_idx` (`level`),
    KEY `created_at_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `performance_logs` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT,
    `request_id` varchar(100) DEFAULT NULL,
    `metric` varchar(100) NOT NULL DEFAULT 'unknown',
    `value` decimal(10,4) NOT NULL DEFAULT 0,
    `endpoint` varchar(500) DEFAULT NULL,
    `method` varchar(10) DEFAULT NULL,
    `status_code` smallint unsigned DEFAULT 200,
    `duration_ms` int unsigned DEFAULT NULL,
    `user_id` bigint unsigned DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `metric_idx` (`metric`),
    KEY `created_at_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT,
    `user_id` bigint unsigned DEFAULT NULL,
    `action` varchar(100) NOT NULL,
    `description` text DEFAULT NULL,
    `model` varchar(100) DEFAULT NULL,
    `model_id` bigint unsigned DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `metadata` longtext DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` datetime DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `user_id_idx` (`user_id`),
    KEY `action_idx` (`action`),
    KEY `created_at_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
