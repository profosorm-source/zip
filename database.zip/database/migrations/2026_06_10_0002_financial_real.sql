-- CHORTKE MIGRATION: FINANCIAL CORE (STRICT CODE-FIRST)
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `wallets`;
CREATE TABLE `wallets` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED UNIQUE NOT NULL,
    `balance_irt` DECIMAL(24,4) DEFAULT 0.0000,
    `balance_usdt` DECIMAL(24,8) DEFAULT 0.00000000,
    `locked_irt` DECIMAL(24,4) DEFAULT 0.0000,
    `locked_usdt` DECIMAL(24,8) DEFAULT 0.00000000,
    `is_frozen` TINYINT(1) DEFAULT 0,
    `last_withdrawal_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64) UNIQUE NOT NULL,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `currency` ENUM('irt', 'usdt') DEFAULT 'irt',
    `amount` DECIMAL(24,8) NOT NULL,
    `balance_before` DECIMAL(24,8),
    `balance_after` DECIMAL(24,8),
    `status` VARCHAR(20) DEFAULT 'pending',
    `description` TEXT,
    `idempotency_key` VARCHAR(128) UNIQUE,
    `metadata` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_t_user` (`user_id`),
    KEY `idx_t_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `ledger_entries`;
CREATE TABLE `ledger_entries` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64) NOT NULL,
    `account` VARCHAR(100) NOT NULL,
    `debit` DECIMAL(24,8) DEFAULT 0,
    `credit` DECIMAL(24,8) DEFAULT 0,
    `currency` VARCHAR(10) DEFAULT 'irt',
    `description` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_le_tx` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
