-- CHORTKE MIGRATION PART 13: EXTENDED REWARDS
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `lottery_participations`;
CREATE TABLE `lottery_participations` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `round_id` INT(10) UNSIGNED NOT NULL,
    `ticket_number` VARCHAR(50),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_lot_round_user` (`round_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lottery_votes`;
CREATE TABLE `lottery_votes` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `round_id` INT(10) UNSIGNED NOT NULL,
    `voted_number` INT(10),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `investment_profits`;
CREATE TABLE `investment_profits` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `investment_id` INT(10) UNSIGNED NOT NULL,
    `amount` DECIMAL(24,4) NOT NULL,
    `currency` VARCHAR(10),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_profit_inv` (`investment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `user_level_history`;
CREATE TABLE `user_level_history` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `from_level` VARCHAR(50),
    `to_level` VARCHAR(50) NOT NULL,
    `change_type` VARCHAR(50),
    `reason` TEXT,
    `signature` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_level_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `ratings`;
CREATE TABLE `ratings` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `target_id` INT(10) UNSIGNED NOT NULL,
    `target_type` VARCHAR(50) NOT NULL COMMENT 'task, influencer',
    `rating` TINYINT UNSIGNED,
    `comment` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `user_target_rate` (`user_id`, `target_id`, `target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
