-- CHORTKE MIGRATION: SUPPORT & DISPUTES (STRICT CODE-FIRST)
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE `tickets` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `ticket_id` VARCHAR(20) UNIQUE NOT NULL,
    `subject` VARCHAR(255) NOT NULL,
    `priority` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    `status` ENUM('open', 'pending', 'replied', 'closed') DEFAULT 'open',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_tk_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `disputes`;
CREATE TABLE `disputes` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `ref_type` VARCHAR(50) NOT NULL COMMENT 'task, order',
    `ref_id` INT(10) UNSIGNED NOT NULL,
    `user_id` INT(10) UNSIGNED NOT NULL COMMENT 'The reporter',
    `target_user_id` INT(10) UNSIGNED,
    `reason` TEXT NOT NULL,
    `status` VARCHAR(50) DEFAULT 'open',
    `admin_id` INT(10) UNSIGNED,
    `resolved_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_dp_ref` (`ref_type`, `ref_id`),
    KEY `idx_dp_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
