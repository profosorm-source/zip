-- CHORTKE MIGRATION PART 26: ANALYTICS & SOCIAL ENGINE
-- Senior QA Architect Standardized
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `social_task_analytics`;
CREATE TABLE `social_task_analytics` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `ad_id` INT(10) UNSIGNED NOT NULL,
    `total_clicks` INT(10) UNSIGNED DEFAULT 0,
    `total_submissions` INT(10) UNSIGNED DEFAULT 0,
    `approved_count` INT(10) UNSIGNED DEFAULT 0,
    `rejected_count` INT(10) UNSIGNED DEFAULT 0,
    `spend_amount` DECIMAL(24,4) DEFAULT 0,
    `last_activity_at` TIMESTAMP NULL,
    UNIQUE KEY `idx_sta_ad` (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `custom_task_analytics`;
CREATE TABLE `custom_task_analytics` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `task_id` INT(10) UNSIGNED NOT NULL,
    `view_count` INT(10) UNSIGNED DEFAULT 0,
    `start_count` INT(10) UNSIGNED DEFAULT 0,
    `completion_rate` DECIMAL(5,2) DEFAULT 0,
    `average_rating` DECIMAL(3,2) DEFAULT 0,
    UNIQUE KEY `idx_cta_task` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `platform_stats`;
CREATE TABLE `platform_stats` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `platform` VARCHAR(50) NOT NULL,
    `metric_name` VARCHAR(100) NOT NULL,
    `metric_value` DECIMAL(24,4) DEFAULT 0,
    `recorded_at` DATE NOT NULL,
    UNIQUE KEY `idx_ps_plat_metric` (`platform`, `metric_name`, `recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
