-- CHORTKE MIGRATION PART 1: IDENTITY & WALLET
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(64) UNIQUE,
    `email` VARCHAR(255) UNIQUE NOT NULL,
    `mobile` VARCHAR(15) UNIQUE,
    `full_name` VARCHAR(255),
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('user', 'admin', 'super_admin', 'support') DEFAULT 'user',
    `status` ENUM('active', 'inactive', 'suspended', 'locked', 'locked_2fa', 'banned', 'deleted') DEFAULT 'active',
    `is_admin` TINYINT(1) DEFAULT 0,
    `two_factor_enabled` TINYINT(1) DEFAULT 0,
    `two_factor_method` VARCHAR(50),
    `two_factor_secret` TEXT,
    `last_2fa_timeslice` INT(10) UNSIGNED,
    `referral_code` VARCHAR(20) UNIQUE,
    `referred_by` INT(10) UNSIGNED,
    `email_verification_token` VARCHAR(128),
    `email_verified_at` TIMESTAMP NULL,
    `country_code` CHAR(2) DEFAULT 'IR',
    `avatar` VARCHAR(255),
    `remember_token` VARCHAR(100),
    `remember_expires_at` TIMESTAMP NULL,
    `fraud_score` INT(10) DEFAULT 0,
    `last_login` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL,
    KEY `idx_u_email` (`email`),
    KEY `idx_u_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `wallets`;
CREATE TABLE `wallets` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(10) UNSIGNED UNIQUE NOT NULL,
    `balance_irt` DECIMAL(24,4) DEFAULT 0.0000,
    `balance_usdt` DECIMAL(24,8) DEFAULT 0.00000000,
    `locked_irt` DECIMAL(24,4) DEFAULT 0.0000,
    `locked_usdt` DECIMAL(24,8) DEFAULT 0.00000000,
    `is_frozen` TINYINT(1) DEFAULT 0,
    `last_withdrawal_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
    `id` INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(64) UNIQUE NOT NULL,
    `user_id` INT(10) UNSIGNED NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `currency` ENUM('irt', 'usdt') DEFAULT 'irt',
    `amount` DECIMAL(24,8) NOT NULL,
    `balance_before` DECIMAL(24,8),
    `balance_after` DECIMAL(24,8),
    `status` VARCHAR(20) DEFAULT 'pending',
    `description` TEXT,
    `gateway` VARCHAR(50),
    `gateway_transaction_id` VARCHAR(128),
    `idempotency_key` VARCHAR(128) UNIQUE,
    `metadata` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_t_user` (`user_id`),
    KEY `idx_t_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
