-- Migration: Create risk_policies table
-- Created: 2026-06-08

CREATE TABLE IF NOT EXISTS `risk_policies` (
    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    `domain` varchar(50) NOT NULL COMMENT 'fraud, session, payment, etc',
    `key_name` varchar(100) NOT NULL,
    `value` text NOT NULL,
    `value_type` varchar(20) NOT NULL DEFAULT 'string' COMMENT 'string, int, float, bool, json, array',
    `description` text DEFAULT NULL,
    `updated_by` bigint(20) unsigned DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `risk_policies_domain_key` (`domain`, `key_name`),
    KEY `risk_policies_domain_index` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
