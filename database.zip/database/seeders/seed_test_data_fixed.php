<?php
require_once __DIR__ . '/../../bootstrap/app.php';
use Core\Database;

try {
    $db = \Core\Container::getInstance()->make(Database::class);
    echo "Connecting to database...\n";

    $passwordHash = password_hash('123456', PASSWORD_DEFAULT);

    $users = [
        ['email' => 'testuser@chortke.ir', 'name' => 'Test User', 'password' => $passwordHash, 'status' => 'active'],
        ['email' => 'admin@chortke.ir', 'name' => 'Administrator', 'password' => $passwordHash, 'status' => 'active'],
    ];

    foreach ($users as $u) {
        $exists = $db->fetch("SELECT id FROM users WHERE email = ? LIMIT 1", [$u['email']]);
        if (!$exists) {
            $db->query("INSERT INTO users (email, name, password, status, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())", 
                       [$u['email'], $u['name'], $u['password'], $u['status']]);
            echo "Created user: {$u['email']}\n";
        } else {
            $db->query("UPDATE users SET name = ?, password = ?, status = ? WHERE id = ?", 
                       [$u['name'], $u['password'], $u['status'], $exists->id]);
            echo "Updated user: {$u['email']}\n";
        }
    }

    echo "\n✅ Seeding completed successfully! (Password: 123456)\n";
} catch (\Exception $e) {
    echo "❌ Seeding Error: " . $e->getMessage() . "\n";
    exit(1);
}
